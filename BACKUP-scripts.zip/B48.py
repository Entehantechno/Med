# -*- coding: utf-8 -*-
"""Micro-lessons, batch 48 — C. difficile control and treatment, and the
Shigella treatment cluster.

TWO GUIDELINES THAT MOVED, HANDLED THE USUAL HONEST WAY
---------------------------------------------------------
This batch contains the clearest example in the whole book of a printed key
that was correct when it was printed and is no longer first-line practice. The
bank's standing rule applies: the key is NOT corrected, because the key was
right for its era and the question is internally consistent; instead the lesson
STATES BOTH, so the student is caught out by neither the exam nor the ward.

  METRONIDAZOLE FOR C. DIFFICILE. For decades oral metronidazole was first-line
  for non-severe disease, and the book keys it. Since the 2017-2018 IDSA/SHEA
  revision, and confirmed by the 2021 ESCMID and IDSA/SHEA updates,
  METRONIDAZOLE IS NO LONGER FIRST LINE. Today:
      initial episode, any severity   FIDAXOMICIN preferred, ORAL VANCOMYCIN an
                                      acceptable alternative
      metronidazole                   only when neither is available
      FULMINANT disease               high-dose ORAL VANCOMYCIN plus
                                      INTRAVENOUS metronidazole
  The change rests on sustained cure at one month, which is markedly better
  with vancomycin and fidaxomicin.

  Note that the book's own answer for FULMINANT or FAILING disease — oral
  vancomycin — agrees with today's guidance exactly. Only the mild-disease
  answer has moved.

WHY ORAL, AND WHY THE ROUTES ARE OPPOSITE
-------------------------------------------
This is the most elegant pharmacology in the chapter and it explains two
answers at once:

  VANCOMYCIN IS NOT ABSORBED FROM THE GUT. Given orally it stays in the lumen
      and reaches very high colonic concentrations — which is exactly what is
      wanted. Given INTRAVENOUSLY it does NOT enter the bowel lumen and is
      therefore USELESS for C. difficile.
  METRONIDAZOLE IS ABSORBED ALMOST COMPLETELY. It reaches the colon through
      the inflamed mucosa and the biliary route, which is why it works at all —
      and why it works LESS WELL as the colitis settles and the mucosa heals.
      This is also why the intravenous route is the one that makes sense for
      metronidazole in fulminant disease with ileus.

So: VANCOMYCIN ORAL, METRONIDAZOLE INTRAVENOUS. The routes are opposite, and
each for a reason rooted in absorption.

INFECTION CONTROL — THE ONE PLACE ALCOHOL GEL IS THE WRONG ANSWER
-------------------------------------------------------------------
C. difficile is a SPORE-FORMER, and alcohol does not kill spores. Therefore:
    HANDS: soap and water, mechanically removing spores. NOT alcohol rub.
    SURFACES: a chlorine-based agent (hypochlorite / bleach).
    CONTACT PRECAUTIONS: gloves and gown, single room.
    ANTIBIOTIC STEWARDSHIP: restricting clindamycin, cephalosporins and
        fluoroquinolones is the single most effective outbreak measure.
    AND ASYMPTOMATIC CARRIERS ARE NOT SCREENED OR TREATED — treating carriage
        does not reduce transmission and drives resistance.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022) —
Clostridioides difficile infection; Johnson S et al., IDSA/SHEA 2021 focused
update (Clin Infect Dis 2021;73:e1029); van Prehn J et al., ESCMID 2021
treatment guidance (Clin Microbiol Infect 2021;27 Suppl 2:S1).
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — "
     "acute infectious diarrhoeal diseases")
HCD = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — "
       "Clostridioides difficile infection, including pseudomembranous colitis")
IDSA21 = ("Johnson S et al. — Clinical Practice Guideline by IDSA and SHEA: "
          "2021 Focused Update Guidelines on Management of Clostridioides "
          "difficile Infection in Adults (Clin Infect Dis 2021;73:e1029)")
ESCMID21 = ("van Prehn J et al. — European Society of Clinical Microbiology and "
            "Infectious Diseases: 2021 update on the treatment guidance document "
            "for Clostridioides difficile infection in adults "
            "(Clin Microbiol Infect 2021;27 Suppl 2:S1)")
CDREFS = [HCD, IDSA21, ESCMID21]
REFS = [H]

# ============================================ INFECTION CONTROL: SHARED
IC_FA = [
    "⚠️ **کلستریدیوم دیفیسیل اسپور می‌سازد، و همه‌ی کنترل عفونت آن از همین یک واقعیت می‌آید.**",
    "**اسپور یک پوسته‌ی مقاوم است که باکتری در شرایط نامساعد به آن پناه می‌برد.**",
    "**اسپور در برابر حرارت، خشکی، اسید و بیشتر ضدعفونی‌کننده‌ها مقاوم است.**",
    "**و ماه‌ها روی سطوح بیمارستان زنده می‌ماند.**",
    "⚠️ **و مهم‌ترین پیامد: الکل اسپور را نمی‌کشد.**",
    "**پس در کلستریدیوم دیفیسیل، ژل الکلی پاسخ غلط است — و این تنها جای چنین استثنایی است.**",
    "**دست‌ها باید با آب و صابون شسته شوند.**",
    "**چون صابون اسپور را نمی‌کشد، بلکه آن را به‌طور مکانیکی از دست جدا می‌کند.**",
    "**و سطوح با ماده‌ی کلردار (هیپوکلریت یا وایتکس) گندزدایی می‌شوند.**",
    "**احتیاطات تماسی هم لازم است: دستکش، گان، و اتاق تک‌نفره.**",
    "⚠️ **و مؤثرترین اقدام در کنترل طغیان، محدود کردن آنتی‌بیوتیک است.**",
    "**به‌ویژه کلیندامایسین، سفالوسپورین‌ها و فلوروکینولون‌ها.**",
    "**چون ریشه‌ی مشکل، از بین رفتن فلور طبیعی است، نه صرفاً انتقال.**",
    "**و ناقلان بی‌علامت غربالگری و درمان نمی‌شوند.**",
    "**چون درمان ناقلی، انتقال را کم نمی‌کند و فقط مقاومت می‌سازد.**",
]
IC_EN = [
    "WARNING: C. DIFFICILE FORMS SPORES, and all of its infection control follows from that one fact.",
    "A spore is a resistant coat into which the bacterium retreats in hostile conditions.",
    "The spore resists heat, drying, acid and most disinfectants.",
    "And it survives for MONTHS on hospital surfaces.",
    "WARNING, AND THE KEY CONSEQUENCE: ALCOHOL DOES NOT KILL SPORES.",
    "So in C. difficile, alcohol gel is the WRONG answer — and this is the only such exception.",
    "Hands must be washed with SOAP AND WATER.",
    "Because soap does not kill the spore; it MECHANICALLY REMOVES it from the hand.",
    "And surfaces are disinfected with a CHLORINE-BASED agent (hypochlorite, bleach).",
    "Contact precautions are also needed: gloves, gown and a single room.",
    "WARNING, AND THE MOST EFFECTIVE OUTBREAK MEASURE IS ANTIBIOTIC RESTRICTION.",
    "Especially clindamycin, cephalosporins and fluoroquinolones.",
    "Because the root of the problem is loss of the normal flora, not transmission alone.",
    "And asymptomatic carriers are NOT screened or treated.",
    "Because treating carriage does not reduce transmission and merely drives resistance.",
]

add("book:315", "vignette", "hard",
    "**ژل الکلی روی اسپور کلستریدیوم دیفیسیل کار نمی‌کند — کم‌اثرترین اقدام در کنترل طغیان.**",
    "Alcohol gel does not work on C. difficile spores — the least effective outbreak measure.",
    IC_FA,
    IC_EN,
    "این یکی از **کاربردی‌ترین سؤال‌های کل کتاب** است، چون یک **عادت درست** را در یک موقعیت "
    "خاص **غلط** می‌کند.\n\n"
    "**موقعیت: در بیمارستان منطقه‌ای شما موارد زیادی از اسهال مرتبط با کلستریدیوم دیفیسیل "
    "گزارش شده و از شما مشاوره خواسته‌اند. کدام اقدام را کمتر مؤثر می‌دانید؟**\n\n"
    "⚠️ **پاسخ: تأکید بر ضدعفونی کردن دست‌ها با محلول الکلی به‌جای آب و صابون.**\n\n"
    "**چرا؟ همه‌چیز از یک واقعیت میکروبیولوژیک می‌آید: کلستریدیوم دیفیسیل اسپور می‌سازد.**\n\n"
    "**اسپور چیست؟** یک **پوسته‌ی فوق‌العاده مقاوم** که باکتری در شرایط نامساعد به آن پناه "
    "می‌برد. اسپور در برابر **حرارت، خشکی، اسید معده و بیشتر ضدعفونی‌کننده‌ها** مقاوم است، و "
    "**ماه‌ها روی سطوح بیمارستان زنده می‌ماند**.\n\n"
    "⚠️ **و نکته‌ی حیاتی: الکل اسپور را نمی‌کشد.**\n\n"
    "**الکل چگونه کار می‌کند؟** با **دناتوره کردن پروتئین‌ها و حل کردن غشای لیپیدی**. این "
    "روی باکتری‌های رویشی و بیشتر ویروس‌ها عالی است. **ولی اسپور غشای لیپیدی در دسترس ندارد** "
    "— پوسته‌ی آن از لایه‌های پروتئینی متراکم و دی‌پیکولینات کلسیم ساخته شده که **نفوذناپذیر** "
    "است.\n\n"
    "**پس چرا آب و صابون کار می‌کند؟** ⚠️ **چون صابون هم اسپور را نمی‌کشد — بلکه آن را "
    "به‌طور مکانیکی از پوست جدا می‌کند و با آب می‌شوید.** یعنی سازوکار **حذف فیزیکی** است، "
    "نه کشتن.\n\n"
    "**و این تنها موقعیت رایجی است که ژل الکلی — که در بقیه‌ی موارد بهترین انتخاب است — "
    "پاسخ غلط می‌شود.**\n\n"
    "**چرا سه گزینه‌ی دیگر مؤثرند؟**\n\n"
    "**محدود کردن کلیندامایسین و سفالوسپورین‌ها** — ⚠️ **این در واقع مؤثرترین اقدام کنترل "
    "طغیان است.** چون **ریشه‌ی مشکل، از بین رفتن فلور طبیعی است**، نه فقط انتقال اسپور. "
    "برنامه‌های مدیریت مصرف آنتی‌بیوتیک، بیشترین کاهش را در بروز کلستریدیوم دیفیسیل نشان "
    "داده‌اند.\n\n"
    "**ضدعفونی سطوح با هیپوکلریت (وایتکس)** — کاملاً درست. **ترکیبات کلردار از معدود موادی "
    "هستند که اسپور را از بین می‌برند**. ضدعفونی‌کننده‌های معمولی چهارتایی آمونیوم کافی نیستند.\n\n"
    "**استفاده از دستکش توسط پرسنل** — بخش استاندارد **احتیاطات تماسی**، و مؤثر در جلوگیری "
    "از آلوده شدن دست‌ها از ابتدا.",
    "This is one of THE MOST PRACTICALLY USEFUL QUESTIONS IN THE WHOLE BOOK, because it makes A CORRECT "
    "HABIT WRONG in one specific situation.\n\n"
    "THE SITUATION: many cases of C. difficile-associated diarrhoea have been reported in your regional "
    "hospital and you are asked to advise. Which measure do you consider LEAST effective?\n\n"
    "WARNING, THE ANSWER: EMPHASISING ALCOHOL HAND RUB INSTEAD OF SOAP AND WATER.\n\n"
    "WHY? Everything follows from one microbiological fact: C. DIFFICILE FORMS SPORES.\n\n"
    "WHAT IS A SPORE? An EXTRAORDINARILY RESISTANT COAT into which the bacterium retreats in hostile "
    "conditions. The spore resists HEAT, DRYING, GASTRIC ACID AND MOST DISINFECTANTS, and it SURVIVES "
    "FOR MONTHS ON HOSPITAL SURFACES.\n\n"
    "WARNING, AND THE VITAL POINT: ALCOHOL DOES NOT KILL SPORES.\n\n"
    "HOW DOES ALCOHOL WORK? By DENATURING PROTEINS AND DISSOLVING THE LIPID MEMBRANE. That is excellent "
    "against vegetative bacteria and most viruses. BUT A SPORE HAS NO ACCESSIBLE LIPID MEMBRANE — its "
    "coat is built of dense protein layers and calcium dipicolinate and is IMPERMEABLE.\n\n"
    "SO WHY DOES SOAP AND WATER WORK? WARNING, BECAUSE SOAP DOES NOT KILL THE SPORE EITHER — IT "
    "MECHANICALLY DETACHES IT FROM THE SKIN AND WASHES IT AWAY. The mechanism is PHYSICAL REMOVAL, not "
    "killing.\n\n"
    "AND THIS IS THE ONLY COMMON SITUATION IN WHICH ALCOHOL GEL — the best choice in every other "
    "setting — BECOMES THE WRONG ANSWER.\n\n"
    "WHY ARE THE OTHER THREE EFFECTIVE?\n\n"
    "RESTRICTING CLINDAMYCIN AND CEPHALOSPORINS — WARNING, THIS IS IN FACT THE MOST EFFECTIVE OUTBREAK "
    "MEASURE. Because THE ROOT OF THE PROBLEM IS LOSS OF THE NORMAL FLORA, not merely spore "
    "transmission. Antibiotic stewardship programmes have produced the largest reductions in C. "
    "difficile incidence.\n\n"
    "DISINFECTING SURFACES WITH HYPOCHLORITE (bleach) — entirely correct. CHLORINE-BASED AGENTS ARE "
    "AMONG THE FEW THAT DESTROY SPORES. Ordinary quaternary ammonium disinfectants are not enough.\n\n"
    "GLOVES FOR STAFF — a standard part of CONTACT PRECAUTIONS, and effective in preventing hands from "
    "becoming contaminated in the first place.",
    ["مؤثرترین اقدام کنترل طغیان است، چون ریشه‌ی مشکل از بین رفتن فلور طبیعی است.",
     "کاملاً مؤثر — ترکیبات کلردار از معدود موادی هستند که اسپور را از بین می‌برند.",
     "پاسخ صحیح — الکل اسپور را نمی‌کشد؛ دست‌ها باید با آب و صابون شسته شوند.",
     "بخش استاندارد احتیاطات تماسی و مؤثر در جلوگیری از آلوده شدن دست‌ها."],
    ["The most effective outbreak measure, because the root of the problem is loss of the normal flora.",
     "Fully effective — chlorine-based agents are among the few that destroy spores.",
     "Correct — alcohol does not kill spores; hands must be washed with soap and water.",
     "A standard part of contact precautions, effective in preventing hand contamination."],
    "**الکل اسپور را نمی‌کشد — صابون آن را می‌شوید. سازوکار حذف است، نه کشتن.**",
    "Alcohol does not kill the spore — soap washes it away. The mechanism is removal, not killing.",
    CDREFS)

add("book:317", "vignette", "medium",
    "**گندزدایی محیط و دستکش: دو اقدامی که واقعاً انتقال اسپور را قطع می‌کنند.**",
    "Environmental disinfection and gloves: the two measures that genuinely interrupt spore transmission.",
    IC_FA + [
        "**این بیمار پس از آنتی‌بیوتیک وسیع‌الطیف در بخش مراقبت ویژه اسهال گرفته است.**",
        "**پس تشخیص محتمل کلستریدیوم دیفیسیل است، و سؤال درباره‌ی پیشگیری از انتقال است.**",
        "⚠️ **و دو اقدامی که واقعاً کار می‌کنند، در یک گزینه با هم آمده‌اند.**",
        "**گندزدایی محیط: چون اسپور ماه‌ها روی سطوح زنده می‌ماند.**",
        "**و دستکش: چون از آلوده شدن دست پرسنل از ابتدا جلوگیری می‌کند.**",
        "**در برابر آن، ضدعفونی دست با الکل روی اسپور بی‌اثر است.**",
        "**و غربالگری یا درمان ناقلان بی‌علامت هم توصیه نمی‌شود.**",
        "⚠️ **چون درمان ناقلی انتقال را کم نمی‌کند و مقاومت می‌سازد.**",
    ],
    IC_EN + [
        "This patient developed diarrhoea after broad-spectrum antibiotics in intensive care.",
        "So C. difficile is the likely diagnosis, and the question is about preventing transmission.",
        "WARNING, AND THE TWO MEASURES THAT GENUINELY WORK are combined in one option.",
        "Environmental disinfection: because spores survive for months on surfaces.",
        "And gloves: because they prevent staff hands becoming contaminated in the first place.",
        "Against these, alcohol hand disinfection is ineffective on spores.",
        "And screening or treating asymptomatic carriers is not recommended either.",
        "WARNING, BECAUSE TREATING CARRIAGE does not reduce transmission and drives resistance.",
    ],
    "این سؤال همان قاعده‌ی قبلی را از **زاویه‌ی مثبت** می‌پرسد: نه «کدام کم‌اثر است»، بلکه "
    "**«کدام توصیه می‌شود»**.\n\n"
    "**بیمار: به دنبال دریافت آنتی‌بیوتیک‌های وسیع‌الطیف در بخش مراقبت ویژه، دچار اسهال بدون "
    "خون شده است.**\n\n"
    "**تشخیص محتمل: کلستریدیوم دیفیسیل** (آنتی‌بیوتیک وسیع‌الطیف + بستری در ICU + اسهال "
    "غیرخونی).\n\n"
    "**و سؤال: علاوه بر درمان بیمار، برای پیشگیری از انتقال چه توصیه می‌شود؟**\n\n"
    "⚠️ **پاسخ: گندزدایی محیط و پوشیدن دستکش توسط پرسنل.**\n\n"
    "**چرا این دو با هم درست‌اند؟ هر کدام یک حلقه از زنجیره‌ی انتقال را می‌شکند:**\n\n"
    "**گندزدایی محیط** — اسپور کلستریدیوم دیفیسیل **ماه‌ها روی سطوح زنده می‌ماند**: تخت، "
    "میله‌های کنار تخت، توالت، ترمومتر، گوشی پزشکی. **بدون گندزدایی با ماده‌ی کلردار، محیط "
    "خودش منبع دائمی آلودگی می‌شود** — و بیمار بعدی همان تخت را می‌گیرد.\n\n"
    "**پوشیدن دستکش** — **از آلوده شدن دست پرسنل از ابتدا جلوگیری می‌کند**. این مؤثرتر از "
    "تلاش برای پاک کردن دست آلوده است. (و پس از درآوردن دستکش، **باز هم باید دست‌ها با آب و "
    "صابون شسته شوند**، چون دستکش می‌تواند سوراخ نامرئی داشته باشد.)\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**شناسایی بیماران ناقل تخت‌های مجاور:** ⚠️ **غربالگری ناقلان بی‌علامت توصیه نمی‌شود.** "
    "دلیل: تا **۲۰ تا ۳۰ درصد بیماران بستری** بدون علامت کلونیزه‌اند. غربالگری آن‌ها **هزینه‌ی "
    "زیاد و سود اثبات‌نشده** دارد، و منجر به **درمان بی‌مورد** می‌شود.\n\n"
    "**ضدعفونی دست‌های پرسنل با الکل:** **این اشتباه کلیدی است.** الکل **اسپور را نمی‌کشد**. "
    "در کلستریدیوم دیفیسیل، **آب و صابون** لازم است، نه ژل الکلی.\n\n"
    "⚠️ **شناسایی و درمان پرسنل ناقل بدون علامت:** این هم **توصیه نمی‌شود**، و دلیلش مهم "
    "است: **درمان ناقلی، انتقال را کاهش نمی‌دهد**. مطالعات نشان داده‌اند که درمان ناقلان "
    "بی‌علامت **مؤثر نیست** و فقط **فشار انتخابی برای مقاومت** ایجاد می‌کند. به‌علاوه، پس از "
    "قطع درمان، کلونیزاسیون اغلب برمی‌گردد.\n\n"
    "**قاعده‌ی کلی: در کلستریدیوم دیفیسیل، بیماریِ علامت‌دار را درمان کنید، نه کلونیزاسیون را.**",
    "This question asks the same rule FROM THE POSITIVE SIDE: not 'which is least effective' but 'which "
    "is recommended'.\n\n"
    "THE PATIENT: has developed non-bloody diarrhoea after receiving broad-spectrum antibiotics in "
    "intensive care.\n\n"
    "THE LIKELY DIAGNOSIS: C. DIFFICILE (broad-spectrum antibiotics plus ICU admission plus non-bloody "
    "diarrhoea).\n\n"
    "AND THE QUESTION: besides treating the patient, what is recommended to prevent transmission?\n\n"
    "WARNING, THE ANSWER: ENVIRONMENTAL DISINFECTION AND GLOVES FOR STAFF.\n\n"
    "WHY ARE THESE TWO RIGHT TOGETHER? Each breaks one link in the transmission chain:\n\n"
    "ENVIRONMENTAL DISINFECTION — C. difficile spores SURVIVE FOR MONTHS ON SURFACES: the bed, the "
    "bed rails, the toilet, the thermometer, the stethoscope. WITHOUT DISINFECTION WITH A "
    "CHLORINE-BASED AGENT, THE ENVIRONMENT ITSELF BECOMES A PERMANENT SOURCE — and the next patient "
    "takes that same bed.\n\n"
    "GLOVES — they PREVENT STAFF HANDS FROM BECOMING CONTAMINATED IN THE FIRST PLACE. That is more "
    "effective than trying to clean an already contaminated hand. (And after removing gloves, HANDS "
    "MUST STILL BE WASHED WITH SOAP AND WATER, since gloves can have invisible perforations.)\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "IDENTIFYING CARRIERS IN NEIGHBOURING BEDS: WARNING, SCREENING ASYMPTOMATIC CARRIERS IS NOT "
    "RECOMMENDED. The reason: up to 20 TO 30% OF INPATIENTS are asymptomatically colonised. Screening "
    "them is EXPENSIVE WITH UNPROVEN BENEFIT and leads to UNNECESSARY TREATMENT.\n\n"
    "ALCOHOL HAND DISINFECTION FOR STAFF: THIS IS THE KEY ERROR. Alcohol DOES NOT KILL SPORES. In C. "
    "difficile, SOAP AND WATER is required, not alcohol gel.\n\n"
    "WARNING, IDENTIFYING AND TREATING ASYMPTOMATIC CARRIER STAFF: also NOT RECOMMENDED, and the reason "
    "matters: TREATING CARRIAGE DOES NOT REDUCE TRANSMISSION. Studies have shown that treating "
    "asymptomatic carriers IS NOT EFFECTIVE and merely creates SELECTIVE PRESSURE FOR RESISTANCE. "
    "Moreover colonisation usually returns after treatment stops.\n\n"
    "THE GENERAL RULE: IN C. DIFFICILE, TREAT SYMPTOMATIC DISEASE, NOT COLONISATION.",
    ["غربالگری ناقلان بی‌علامت توصیه نمی‌شود؛ تا ۳۰ درصد بیماران بستری کلونیزه‌اند.",
     "اشتباه کلیدی — الکل اسپور را نمی‌کشد؛ آب و صابون لازم است.",
     "پاسخ صحیح — گندزدایی محیط و دستکش، دو حلقه‌ی اصلی زنجیره‌ی انتقال را می‌شکنند.",
     "درمان ناقلان بی‌علامت انتقال را کم نمی‌کند و فقط مقاومت می‌سازد."],
    ["Screening asymptomatic carriers is not recommended; up to 30% of inpatients are colonised.",
     "The key error — alcohol does not kill spores; soap and water is required.",
     "Correct — environmental disinfection and gloves break the two main links of transmission.",
     "Treating asymptomatic carriers does not reduce transmission and merely drives resistance."],
    "**بیماریِ علامت‌دار را درمان کنید، نه کلونیزاسیون را.**",
    "Treat symptomatic disease, not colonisation.",
    CDREFS)

# ============================================ C. DIFFICILE TREATMENT
TX_FA = [
    "⚠️ **درمان کلستریدیوم دیفیسیل، نمونه‌ی روشن یک راهنمای جابه‌جاشده است.**",
    "**در دوران این آزمون‌ها، مترونیدازول خوراکی خط اول بیماری خفیف بود.**",
    "**و کتاب همان را کلید زده است، که برای زمان خودش درست بود.**",
    "**ولی از بازنگری IDSA/SHEA در ۲۰۱۷ و ۲۰۱۸، و تأیید ESCMID در ۲۰۲۱، این تغییر کرده است.**",
    "⚠️ **امروز: فیداکسومایسین ارجح، و وانکومایسین خوراکی جایگزین قابل قبول.**",
    "**و مترونیدازول فقط وقتی که هیچ‌کدام در دسترس نباشد.**",
    "**دلیل تغییر: درمان پایدار در یک ماه، که با وانکومایسین و فیداکسومایسین بهتر است.**",
    "**حالا نکته‌ی دارویی که دو پاسخ را هم‌زمان توضیح می‌دهد.**",
    "**وانکومایسین از روده جذب نمی‌شود.**",
    "**پس خوراکی که داده شود، در لومن می‌ماند و غلظت بسیار بالایی در کولون می‌سازد.**",
    "⚠️ **و همین یعنی وانکومایسین وریدی در کلستریدیوم دیفیسیل کاملاً بی‌فایده است.**",
    "**چون وریدی وارد لومن روده نمی‌شود.**",
    "**مترونیدازول برعکس، تقریباً کامل جذب می‌شود.**",
    "**و از راه مخاط ملتهب و ترشح صفراوی به کولون می‌رسد.**",
    "**پس هرچه کولیت بهبود یابد، رسیدن مترونیدازول به کولون کمتر می‌شود.**",
    "⚠️ **نتیجه: وانکومایسین خوراکی، مترونیدازول وریدی — دو مسیر متضاد، هر کدام با دلیل.**",
    "**و در بیماری فولمینانت: وانکومایسین خوراکی با دوز بالا به‌علاوه‌ی مترونیدازول وریدی.**",
]
TX_EN = [
    "WARNING: THE TREATMENT OF C. DIFFICILE IS THE CLEAREST EXAMPLE OF A GUIDELINE THAT HAS MOVED.",
    "In the era of these examinations, oral metronidazole was first line for non-severe disease.",
    "And the book keys exactly that, which was correct for its time.",
    "But since the IDSA/SHEA revision of 2017-2018, confirmed by ESCMID in 2021, this has changed.",
    "WARNING, TODAY: FIDAXOMICIN IS PREFERRED, with ORAL VANCOMYCIN an acceptable alternative.",
    "And metronidazole only when neither of those is available.",
    "The reason for the change: SUSTAINED CURE AT ONE MONTH, which is better with vancomycin and fidaxomicin.",
    "Now the pharmacological point that explains two answers at once.",
    "VANCOMYCIN IS NOT ABSORBED FROM THE GUT.",
    "So given orally it stays in the lumen and reaches a very high concentration in the colon.",
    "WARNING, AND THAT MEANS INTRAVENOUS VANCOMYCIN IS COMPLETELY USELESS in C. difficile.",
    "Because the intravenous route does not enter the bowel lumen.",
    "Metronidazole is the opposite: it is absorbed almost completely.",
    "And reaches the colon through the inflamed mucosa and biliary secretion.",
    "So as the colitis improves, less metronidazole reaches the colon.",
    "WARNING, THE RESULT: VANCOMYCIN ORAL, METRONIDAZOLE INTRAVENOUS — opposite routes, each for a reason.",
    "And in fulminant disease: high-dose oral vancomycin PLUS intravenous metronidazole.",
]

add("book:318", "vignette", "medium",
    "**اسهال پس از کلیندامایسین: قطع آنتی‌بیوتیک و مترونیدازول خوراکی — با یادآوری راهنمای امروز.**",
    "Diarrhoea after clindamycin: stop the antibiotic and give oral metronidazole — with today's guideline noted.",
    TX_FA,
    TX_EN,
    "این سؤال **درمان بیماری خفیف** را می‌سنجد، و بهترین جای این فصل برای گفتن یک حقیقت "
    "است: **این کلید برای زمان خودش درست بود، و امروز جابه‌جا شده.**\n\n"
    "**بیمار: خانم ۳۵ ساله با تشخیص PID تحت درمان با سفتریاکسون و کلیندامایسین. روز سوم "
    "درمان، اسهال غیرخونی ۶ اپیزود در روز با تب خفیف، بدون استفراغ و درد شکم.**\n\n"
    "**تشخیص روشن است: کلستریدیوم دیفیسیل.** ⚠️ **و زمینه دوبرابر قوی است: هم کلیندامایسین "
    "(کلاسیک‌ترین راه‌اندازنده) و هم سفتریاکسون (سفالوسپورین).**\n\n"
    "**گام اول درمان — که سؤال آن را فرض گرفته: قطع آنتی‌بیوتیک مسبب.** این به‌تنهایی در "
    "موارد خفیف می‌تواند کافی باشد، چون به فلور طبیعی اجازه‌ی بازسازی می‌دهد.\n\n"
    "**گام دوم: درمان اختصاصی.**\n\n"
    "**پاسخ کتاب: مترونیدازول خوراکی ۵۰۰ میلی‌گرم سه بار در روز.** و **این برای دوران این "
    "آزمون کاملاً درست بود** — مترونیدازول دهه‌ها خط اول بیماری خفیف تا متوسط بود.\n\n"
    "⚠️ **ولی راهنما جابه‌جا شده است، و باید هر دو را بدانید:**\n\n"
    "**از بازنگری IDSA/SHEA در ۲۰۱۷–۲۰۱۸، و تأیید ESCMID و IDSA/SHEA در ۲۰۲۱:**\n\n"
    "**مترونیدازول دیگر خط اول نیست.** امروز **فیداکسومایسین ارجح** است و **وانکومایسین "
    "خوراکی جایگزین قابل قبول**. مترونیدازول **فقط وقتی** توصیه می‌شود که **هیچ‌کدام در دسترس "
    "نباشد**.\n\n"
    "**چرا تغییر کرد؟** به دلیل **درمان پایدار در یک ماه**. مطالعات نشان دادند که با "
    "مترونیدازول، **نرخ عود بالاتر** است و بیماران کمتری یک ماه بعد همچنان بهبودیافته‌اند.\n\n"
    "**پس در امتحان این دوره، مترونیدازول پاسخ است؛ و در بالین امروز، وانکومایسین خوراکی یا "
    "فیداکسومایسین.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**وانکومایسین خوراکی ۵۰۰ میلی‌گرم دو بار در روز:** ⚠️ **دو نکته.** یک: **دوز اشتباه "
    "است** — دوز استاندارد **۱۲۵ میلی‌گرم چهار بار در روز** است؛ دوز ۵۰۰ فقط برای بیماری "
    "**فولمینانت** است. دو: در آن دوره، برای بیماری خفیف خط اول نبود. (**ولی امروز خودِ دارو "
    "— با دوز درست — انتخاب مناسبی است.**)\n\n"
    "**سیپروفلوکساسین:** ⚠️ **این نه‌فقط بی‌فایده بلکه مضر است.** فلوروکینولون‌ها از "
    "**راه‌اندازنده‌های اصلی** کلستریدیوم دیفیسیل‌اند. دادن آن یعنی **ریختن بنزین روی آتش**.\n\n"
    "**کوتریموکسازول:** هیچ فعالیتی روی کلستریدیوم دیفیسیل ندارد، و مثل هر آنتی‌بیوتیک دیگری "
    "می‌تواند فلور را بیشتر به هم بریزد.",
    "This question tests THE TREATMENT OF MILD DISEASE, and it is the best place in this chapter to "
    "state a fact plainly: THIS KEY WAS CORRECT FOR ITS TIME, AND IT HAS SINCE MOVED.\n\n"
    "THE PATIENT: a 35-year-old woman with PID being treated with ceftriaxone and clindamycin. On the "
    "third day of treatment she has 6 episodes a day of non-bloody diarrhoea with a low-grade fever, "
    "without vomiting or abdominal pain.\n\n"
    "THE DIAGNOSIS IS CLEAR: C. DIFFICILE. WARNING, AND THE SETTING IS DOUBLY STRONG: both CLINDAMYCIN "
    "(the most classic trigger) AND CEFTRIAXONE (a cephalosporin).\n\n"
    "STEP ONE OF TREATMENT — which the question presupposes: STOP THE CAUSATIVE ANTIBIOTIC. In mild "
    "cases this alone can suffice, because it lets the normal flora recover.\n\n"
    "STEP TWO: SPECIFIC TREATMENT.\n\n"
    "THE BOOK'S ANSWER: ORAL METRONIDAZOLE 500 mg THREE TIMES DAILY. And THIS WAS ENTIRELY CORRECT FOR "
    "THE ERA OF THIS EXAMINATION — metronidazole was first line for mild to moderate disease for decades.\n\n"
    "WARNING, BUT THE GUIDELINE HAS MOVED, AND YOU MUST KNOW BOTH:\n\n"
    "SINCE THE IDSA/SHEA REVISION OF 2017-2018, CONFIRMED BY ESCMID AND IDSA/SHEA IN 2021:\n\n"
    "METRONIDAZOLE IS NO LONGER FIRST LINE. Today FIDAXOMICIN IS PREFERRED with ORAL VANCOMYCIN an "
    "ACCEPTABLE ALTERNATIVE. Metronidazole is recommended ONLY WHEN NEITHER IS AVAILABLE.\n\n"
    "WHY DID IT CHANGE? Because of SUSTAINED CURE AT ONE MONTH. Studies showed that with metronidazole "
    "the RECURRENCE RATE IS HIGHER and fewer patients remain well a month later.\n\n"
    "SO IN THIS ERA'S EXAM, METRONIDAZOLE IS THE ANSWER; AND ON TODAY'S WARD, ORAL VANCOMYCIN OR "
    "FIDAXOMICIN.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ORAL VANCOMYCIN 500 mg TWICE DAILY: WARNING, TWO POINTS. One: THE DOSE IS WRONG — the standard "
    "dose is 125 mg FOUR TIMES DAILY; 500 mg is reserved for FULMINANT disease. Two: in that era it was "
    "not first line for mild disease. (BUT TODAY THE DRUG ITSELF — at the correct dose — IS A SUITABLE "
    "CHOICE.)\n\n"
    "CIPROFLOXACIN: WARNING, THIS IS NOT MERELY USELESS BUT HARMFUL. Fluoroquinolones are among the "
    "MAIN TRIGGERS of C. difficile. Giving it is POURING PETROL ON THE FIRE.\n\n"
    "CO-TRIMOXAZOLE: it has no activity against C. difficile and, like any antibiotic, can disturb the "
    "flora further.",
    ["دوز اشتباه است — دوز استاندارد ۱۲۵ چهار بار در روز است؛ ۵۰۰ فقط برای بیماری فولمینانت.",
     "پاسخ صحیح برای این دوره — و امروز فیداکسومایسین یا وانکومایسین خوراکی ارجح‌اند.",
     "نه‌فقط بی‌فایده بلکه مضر — فلوروکینولون خود از راه‌اندازنده‌های اصلی دیفیسیل است.",
     "هیچ فعالیتی روی کلستریدیوم دیفیسیل ندارد و فلور را بیشتر به هم می‌ریزد."],
    ["The dose is wrong — the standard is 125 mg four times daily; 500 mg is for fulminant disease only.",
     "Correct for this era — and today fidaxomicin or oral vancomycin are preferred.",
     "Not merely useless but harmful — a fluoroquinolone is itself a main C. difficile trigger.",
     "Has no activity against C. difficile and disturbs the flora further."],
    "**مترونیدازول برای آن دوره درست بود؛ امروز وانکومایسین خوراکی یا فیداکسومایسین.**",
    "Metronidazole was right for that era; today it is oral vancomycin or fidaxomicin.",
    CDREFS)

add("book:319", "vignette", "medium",
    "**غشای کاذب در کولونوسکوپی: قطع آنتی‌بیوتیک و مترونیدازول خوراکی — و وانکومایسین وریدی هرگز.**",
    "Pseudomembranes at colonoscopy: stop the antibiotic and give oral metronidazole — and never intravenous vancomycin.",
    TX_FA + [
        "**اینجا کولونوسکوپی غشای کاذب را دیده، پس تشخیص قطعی است.**",
        "**و زمینه هم کلاسیک است: سیپروفلوکساسین و کلیندامایسین.**",
        "⚠️ **مهم‌ترین دام این سؤال، وانکومایسین تزریقی است.**",
        "**وانکومایسین وریدی وارد لومن روده نمی‌شود.**",
        "**پس در کلستریدیوم دیفیسیل، وریدی کاملاً بی‌فایده است.**",
        "**و این یکی از معدود مواردی است که راه تجویز، دارو را بی‌اثر می‌کند.**",
        "**وانکومایسین باید خوراکی باشد تا در لومن بماند.**",
    ],
    TX_EN + [
        "Here colonoscopy has shown pseudomembranes, so the diagnosis is definitive.",
        "And the setting is classic too: ciprofloxacin and clindamycin.",
        "WARNING, THE MAIN TRAP IN THIS QUESTION IS INTRAVENOUS VANCOMYCIN.",
        "Intravenous vancomycin does not enter the bowel lumen.",
        "So in C. difficile the intravenous route is completely useless.",
        "And this is one of the few situations where the ROUTE renders the drug ineffective.",
        "Vancomycin must be ORAL so that it stays in the lumen.",
    ],
    "این سؤال یک **دام دارویی زیبا** دارد که ارزش امتحانی بالایی دارد.\n\n"
    "**بیمار: با زخم پای دیابتی، پس از درمان با سیپروفلوکساسین و کلیندامایسین دچار اسهال "
    "شده. در بررسی مدفوع عامل خاصی مطرح نشده و کولونوسکوپی غشای کاذب گزارش کرده است.**\n\n"
    "**تشخیص قطعی است: کولیت پسودوممبران از کلستریدیوم دیفیسیل.** غشای کاذب **اختصاصیت "
    "بسیار بالایی** دارد.\n\n"
    "**و زمینه هم کلاسیک است: سیپروفلوکساسین (فلوروکینولون) + کلیندامایسین — دو تا از سه "
    "راه‌اندازنده‌ی اصلی.**\n\n"
    "**درمان: قطع آنتی‌بیوتیک‌ها + مترونیدازول خوراکی** (برای دوران این آزمون؛ امروز "
    "وانکومایسین خوراکی یا فیداکسومایسین).\n\n"
    "⚠️ **حالا دام اصلی: وانکومایسین تزریقی.**\n\n"
    "**چرا وانکومایسین وریدی در کلستریدیوم دیفیسیل کاملاً بی‌فایده است؟**\n\n"
    "**پاسخ در فارماکوکینتیک است، و این یکی از زیباترین نکات این فصل است:**\n\n"
    "**وانکومایسین از دستگاه گوارش جذب نمی‌شود.** این معمولاً یک **عیب** محسوب می‌شود — به "
    "همین دلیل برای عفونت‌های سیستمیک باید وریدی داده شود. **ولی در کلستریدیوم دیفیسیل، "
    "همین عیب به بزرگ‌ترین مزیت تبدیل می‌شود:** وانکومایسین خوراکی **در لومن روده می‌ماند** و "
    "**غلظت بسیار بالایی در کولون** می‌سازد — دقیقاً جایی که باکتری هست.\n\n"
    "**و برعکس: وانکومایسین وریدی در خون می‌ماند و به بافت‌ها می‌رود، ولی به لومن روده "
    "نمی‌رسد.** پس **هیچ اثری روی کلستریدیوم دیفیسیل ندارد.**\n\n"
    "⚠️ **این یکی از معدود مواردی در کل طب است که راه تجویز، دارو را از مؤثر به کاملاً "
    "بی‌اثر تبدیل می‌کند.**\n\n"
    "**و نکته‌ی مکمل: مترونیدازول برعکس است.** مترونیدازول **تقریباً کامل جذب می‌شود** و از "
    "راه **مخاط ملتهب و ترشح صفراوی** به کولون می‌رسد. به همین دلیل **وریدی هم مؤثر است** — "
    "و در بیماری فولمینانت با ایلئوس، **دقیقاً همان راه وریدی است که به کار می‌آید**.\n\n"
    "**پس: وانکومایسین خوراکی، مترونیدازول وریدی. دو مسیر متضاد، هر کدام با دلیلی ریشه‌دار "
    "در جذب.**\n\n"
    "**چرا دو گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**دیفنوکسیلات:** **داروی ضدحرکت روده** — و در کولیت کلستریدیوم دیفیسیل **ممنوع** است. "
    "کند کردن روده، **تماس با سم را طولانی می‌کند** و خطر **مگاکولون توکسیک** را بالا می‌برد.\n\n"
    "**سفتریاکسون تزریقی:** سفالوسپورین‌ها از **راه‌اندازنده‌های اصلی** کلستریدیوم "
    "دیفیسیل‌اند. دادن آن، بیماری را بدتر می‌کند.",
    "This question contains AN ELEGANT PHARMACOLOGICAL TRAP with high exam value.\n\n"
    "THE PATIENT: with a diabetic foot ulcer, has developed diarrhoea after treatment with "
    "ciprofloxacin and clindamycin. Stool examination identified no specific organism and colonoscopy "
    "has reported PSEUDOMEMBRANES.\n\n"
    "THE DIAGNOSIS IS DEFINITIVE: pseudomembranous colitis from C. difficile. Pseudomembranes have VERY "
    "HIGH SPECIFICITY.\n\n"
    "AND THE SETTING IS CLASSIC TOO: ciprofloxacin (a fluoroquinolone) plus clindamycin — two of the "
    "three main triggers.\n\n"
    "TREATMENT: STOP THE ANTIBIOTICS plus ORAL METRONIDAZOLE (for the era of this exam; today oral "
    "vancomycin or fidaxomicin).\n\n"
    "WARNING, NOW THE MAIN TRAP: INTRAVENOUS VANCOMYCIN.\n\n"
    "WHY IS INTRAVENOUS VANCOMYCIN COMPLETELY USELESS IN C. DIFFICILE?\n\n"
    "THE ANSWER IS PHARMACOKINETIC, and it is one of the most elegant points in this chapter:\n\n"
    "VANCOMYCIN IS NOT ABSORBED FROM THE GASTROINTESTINAL TRACT. That is usually considered A "
    "DISADVANTAGE — which is why systemic infections require the intravenous route. BUT IN C. "
    "DIFFICILE THAT VERY DISADVANTAGE BECOMES THE GREATEST ADVANTAGE: oral vancomycin STAYS IN THE "
    "BOWEL LUMEN and reaches A VERY HIGH CONCENTRATION IN THE COLON — precisely where the organism is.\n\n"
    "AND CONVERSELY: intravenous vancomycin stays in the blood and distributes to tissues, BUT DOES NOT "
    "REACH THE BOWEL LUMEN. So IT HAS NO EFFECT ON C. DIFFICILE AT ALL.\n\n"
    "WARNING, THIS IS ONE OF THE FEW SITUATIONS IN ALL OF MEDICINE WHERE THE ROUTE OF ADMINISTRATION "
    "TURNS A DRUG FROM EFFECTIVE TO ENTIRELY INEFFECTIVE.\n\n"
    "AND THE COMPLEMENTARY POINT: METRONIDAZOLE IS THE OPPOSITE. It is ABSORBED ALMOST COMPLETELY and "
    "reaches the colon through the INFLAMED MUCOSA AND BILIARY SECRETION. That is why THE INTRAVENOUS "
    "ROUTE ALSO WORKS for it — and in fulminant disease with ileus, IT IS PRECISELY THE INTRAVENOUS "
    "ROUTE THAT IS USEFUL.\n\n"
    "SO: VANCOMYCIN ORAL, METRONIDAZOLE INTRAVENOUS. Opposite routes, each for a reason rooted in "
    "absorption.\n\n"
    "WHY ARE THE OTHER TWO REJECTED?\n\n"
    "DIPHENOXYLATE: AN ANTIMOTILITY DRUG — and it is FORBIDDEN in C. difficile colitis. Slowing the "
    "bowel PROLONGS CONTACT WITH THE TOXIN and raises the risk of TOXIC MEGACOLON.\n\n"
    "INTRAVENOUS CEFTRIAXONE: cephalosporins are among the MAIN TRIGGERS of C. difficile. Giving it "
    "makes the disease worse.",
    ["داروی ضدحرکت روده و در کولیت دیفیسیل ممنوع؛ خطر مگاکولون توکسیک دارد.",
     "دام سؤال — وانکومایسین وریدی وارد لومن روده نمی‌شود و کاملاً بی‌فایده است.",
     "سفالوسپورین از راه‌اندازنده‌های اصلی دیفیسیل است و بیماری را بدتر می‌کند.",
     "پاسخ صحیح برای این دوره — و امروز وانکومایسین خوراکی یا فیداکسومایسین ارجح است."],
    ["An antimotility drug, forbidden in C. difficile colitis; it risks toxic megacolon.",
     "The trap — intravenous vancomycin does not enter the bowel lumen and is completely useless.",
     "A cephalosporin, one of the main C. difficile triggers; it makes the disease worse.",
     "Correct for this era — and today oral vancomycin or fidaxomicin are preferred."],
    "**وانکومایسین خوراکی، مترونیدازول وریدی — دو مسیر متضاد، هر کدام با دلیل جذب.**",
    "Vancomycin oral, metronidazole intravenous — opposite routes, each justified by absorption.",
    CDREFS)

add("book:322", "vignette", "hard",
    "**بیماری در حال بدتر شدن با وجود قطع آنتی‌بیوتیک: وانکومایسین خوراکی — و امروز هم همین.**",
    "Disease worsening despite stopping antibiotics: ORAL VANCOMYCIN — and the same today.",
    TX_FA + [
        "**این بیمار برخلاف موارد قبلی، در حال بدتر شدن است.**",
        "**آنتی‌بیوتیک‌ها قطع شده و اسهال با شدت بیشتر ادامه دارد.**",
        "⚠️ **و بیمار بدحال‌تر می‌شود، که یعنی بیماری شدید یا فولمینانت.**",
        "**در این وضعیت، مترونیدازول کافی نیست.**",
        "**و وانکومایسین خوراکی انتخاب درست است، هم آن زمان و هم امروز.**",
        "**چون در کولیت شدید، غلظت لومنی بالا لازم است.**",
        "**و وانکومایسین خوراکی دقیقاً همان را می‌دهد.**",
        "⚠️ **در بیماری فولمینانت، دوز آن به ۵۰۰ میلی‌گرم چهار بار در روز می‌رسد.**",
        "**و مترونیدازول وریدی هم به آن اضافه می‌شود.**",
        "**کشت مدفوع منفی هم تشخیص را رد نمی‌کند، چون کشت روتین دیفیسیل را نمی‌جوید.**",
    ],
    TX_EN + [
        "Unlike the earlier cases, this patient is DETERIORATING.",
        "The antibiotics have been stopped and the diarrhoea continues, more severely.",
        "WARNING, AND THE PATIENT IS BECOMING SICKER, meaning severe or fulminant disease.",
        "In this situation metronidazole is not enough.",
        "And oral vancomycin is the right choice, both then and today.",
        "Because severe colitis requires a high luminal concentration.",
        "And oral vancomycin delivers exactly that.",
        "WARNING, IN FULMINANT DISEASE its dose rises to 500 mg four times daily.",
        "And intravenous metronidazole is added to it.",
        "A negative stool culture does not exclude the diagnosis, because routine culture does not look for C. difficile.",
    ],
    "این سخت‌ترین سؤال درمانی این خوشه است، چون **شدت بیماری، پاسخ را عوض می‌کند**.\n\n"
    "**بیمار: پس از جراحی لگن بستری شده. ۱۰ روز بعد از بستری دچار اسهال خونی می‌شود. در "
    "آزمایش مدفوع گلبول سفید ۲۰ تا ۲۵ و گلبول قرمز ۳۰ تا ۴۰، بدون انگل. آنتی‌بیوتیک‌ها قطع "
    "می‌شود و کشت مدفوع ۴۸ ساعت بعد منفی است. در عرض ۴۸ تا ۷۲ ساعت اسهال با شدت بیشتر ادامه "
    "می‌یابد و بیمار بدحال‌تر می‌شود.**\n\n"
    "**سه نکته را از این تابلو بگیرید:**\n\n"
    "**یک — زمینه: بستری + جراحی + آنتی‌بیوتیک (پروفیلاکسی جراحی).** کلستریدیوم دیفیسیل در صدر.\n\n"
    "⚠️ **دو — کشت مدفوع منفی است، ولی این تشخیص را رد نمی‌کند.** چرا؟ **کشت روتین مدفوع "
    "به‌دنبال شیگلا، سالمونلا و کمپیلوباکتر می‌گردد — نه کلستریدیوم دیفیسیل.** کشت دیفیسیل "
    "**محیط بی‌هوازی اختصاصی** می‌خواهد و به‌طور روتین انجام نمی‌شود. پس «کشت منفی» یعنی "
    "**آن سه عامل نیستند**، نه اینکه دیفیسیل نیست.\n\n"
    "**سه — و مهم‌ترین: بیمار در حال بدتر شدن است.** آنتی‌بیوتیک‌ها قطع شده‌اند و با این حال "
    "**اسهال شدیدتر شده و بیمار بدحال‌تر**. این یعنی **بیماری شدید یا فولمینانت**.\n\n"
    "**و اینجا پاسخ عوض می‌شود: وانکومایسین خوراکی.**\n\n"
    "**چرا در این بیمار وانکومایسین و نه مترونیدازول؟**\n\n"
    "⚠️ **حتی در دوران این آزمون هم، در بیماری شدید یا در شکست درمان، وانکومایسین خوراکی "
    "انتخاب بود.** و **امروز هم همین است** — پس این گزینه **هم با کلید کتاب و هم با راهنمای "
    "امروز هم‌خوان است**.\n\n"
    "**دلیل دارویی:** در **کولیت شدید**، مخاط به‌شدت ملتهب و آسیب‌دیده است و **غلظت بسیار "
    "بالای دارو در لومن** لازم است. وانکومایسین خوراکی — که جذب نمی‌شود — **دقیقاً همان را "
    "می‌دهد**. در حالی که مترونیدازول باید از راه مخاط ملتهب و صفرا برسد، که **قابل اتکا "
    "نیست**، به‌ویژه وقتی بیماری پیشرفته است.\n\n"
    "**و در بیماری فولمینانت (هیپوتانسیون، ایلئوس، مگاکولون): وانکومایسین خوراکی ۵۰۰ "
    "میلی‌گرم چهار بار در روز + مترونیدازول وریدی.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**مترونیدازول خوراکی:** در بیماری خفیف مناسب بود، ولی **این بیمار در حال بدتر شدن است** "
    "— یعنی همان وضعیتی که مترونیدازول در آن ناکافی است.\n\n"
    "**سیپروفلوکساسین خوراکی:** ⚠️ **فلوروکینولون از راه‌اندازنده‌های اصلی دیفیسیل است.** "
    "دادن آن بیماری را بدتر می‌کند.\n\n"
    "**مترونیدازول + وانکومایسین خوراکی با هم:** ترکیب این دو **به‌صورت خوراکی** رژیم "
    "استاندارد نیست. **ترکیب استاندارد در بیماری فولمینانت، وانکومایسین خوراکی + مترونیدازول "
    "وریدی است** — و تفاوت راه تجویز اینجا حیاتی است.",
    "This is the hardest treatment question in the cluster, because THE SEVERITY OF THE DISEASE CHANGES "
    "THE ANSWER.\n\n"
    "THE PATIENT: admitted for pelvic surgery. Ten days after admission he develops bloody diarrhoea. "
    "Stool shows white cells 20 to 25 and red cells 30 to 40, with no parasites. The antibiotics are "
    "stopped and a stool culture 48 hours later is negative. Over the next 48 to 72 hours the diarrhoea "
    "continues MORE SEVERELY and the patient becomes SICKER.\n\n"
    "TAKE THREE POINTS FROM THIS PICTURE:\n\n"
    "ONE — THE SETTING: admission plus surgery plus antibiotics (surgical prophylaxis). C. difficile "
    "heads the list.\n\n"
    "WARNING, TWO — THE STOOL CULTURE IS NEGATIVE, BUT THAT DOES NOT EXCLUDE THE DIAGNOSIS. Why? A "
    "ROUTINE STOOL CULTURE LOOKS FOR SHIGELLA, SALMONELLA AND CAMPYLOBACTER — NOT FOR C. DIFFICILE. "
    "Culturing C. difficile requires SPECIFIC ANAEROBIC MEDIA and is not done routinely. So 'negative "
    "culture' means THOSE THREE ARE ABSENT, not that C. difficile is.\n\n"
    "THREE — AND MOST IMPORTANTLY: THE PATIENT IS DETERIORATING. The antibiotics have been stopped and "
    "yet THE DIARRHOEA IS WORSE AND THE PATIENT SICKER. That means SEVERE OR FULMINANT DISEASE.\n\n"
    "AND HERE THE ANSWER CHANGES: ORAL VANCOMYCIN.\n\n"
    "WHY VANCOMYCIN RATHER THAN METRONIDAZOLE IN THIS PATIENT?\n\n"
    "WARNING, EVEN IN THE ERA OF THIS EXAM, ORAL VANCOMYCIN WAS THE CHOICE IN SEVERE DISEASE OR "
    "TREATMENT FAILURE. AND IT REMAINS SO TODAY — so this option AGREES WITH BOTH THE BOOK'S KEY AND "
    "CURRENT GUIDANCE.\n\n"
    "THE PHARMACOLOGICAL REASON: in SEVERE COLITIS the mucosa is intensely inflamed and damaged, and A "
    "VERY HIGH LUMINAL DRUG CONCENTRATION is needed. Oral vancomycin — which is not absorbed — DELIVERS "
    "EXACTLY THAT. Whereas metronidazole must arrive via the inflamed mucosa and the bile, which is "
    "UNRELIABLE, especially in advanced disease.\n\n"
    "AND IN FULMINANT DISEASE (hypotension, ileus, megacolon): ORAL VANCOMYCIN 500 mg FOUR TIMES DAILY "
    "PLUS INTRAVENOUS METRONIDAZOLE.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ORAL METRONIDAZOLE: suitable in mild disease, but THIS PATIENT IS DETERIORATING — precisely the "
    "situation in which metronidazole is inadequate.\n\n"
    "ORAL CIPROFLOXACIN: WARNING, A FLUOROQUINOLONE IS A MAIN C. DIFFICILE TRIGGER. Giving it makes the "
    "disease worse.\n\n"
    "ORAL METRONIDAZOLE PLUS ORAL VANCOMYCIN TOGETHER: that combination BY THE ORAL ROUTE is not a "
    "standard regimen. THE STANDARD COMBINATION IN FULMINANT DISEASE IS ORAL VANCOMYCIN PLUS "
    "INTRAVENOUS METRONIDAZOLE — and the difference in route is vital here.",
    ["در بیماری خفیف مناسب بود، ولی این بیمار در حال بدتر شدن است و مترونیدازول ناکافی است.",
     "پاسخ صحیح — در بیماری شدید یا شکست درمان، وانکومایسین خوراکی انتخاب است، آن زمان و امروز.",
     "فلوروکینولون از راه‌اندازنده‌های اصلی دیفیسیل است و بیماری را بدتر می‌کند.",
     "ترکیب خوراکی این دو استاندارد نیست؛ رژیم فولمینانت، وانکومایسین خوراکی + مترونیدازول وریدی است."],
    ["Suitable in mild disease, but this patient is deteriorating and metronidazole is inadequate.",
     "Correct — in severe disease or treatment failure, oral vancomycin is the choice, then and now.",
     "A fluoroquinolone is a main C. difficile trigger and makes the disease worse.",
     "That oral combination is not standard; the fulminant regimen is oral vancomycin plus IV metronidazole."],
    "**کشت روتین مدفوع، کلستریدیوم دیفیسیل را نمی‌جوید — پس منفی بودنش آن را رد نمی‌کند.**",
    "A routine stool culture does not look for C. difficile — so a negative one does not exclude it.",
    CDREFS)

# ================================================== SHIGELLA TREATMENT
SH_FA = [
    "⚠️ **شیگلا سه ویژگی دارد که کل رفتار بالینی آن را توضیح می‌دهد.**",
    "**یک: دوز عفونی فوق‌العاده پایین، فقط ده تا صد ارگانیسم.**",
    "**پس مستقیماً از فرد به فرد منتقل می‌شود، و طغیان خانوادگی می‌سازد.**",
    "**دو: تهاجم به مخاط کولون، که دیسانتری و تنسموس می‌دهد.**",
    "**سه: سم شیگا در تیپ ۱ دیسانتریه، که HUS می‌دهد.**",
    "⚠️ **و درمان شیگلا سه هدف دارد، نه یکی.**",
    "**هدف یک: کوتاه کردن مدت بیماری.**",
    "**هدف دو: کوتاه کردن مدت دفع باکتری، که انتقال را قطع می‌کند.**",
    "**هدف سه: پیشگیری از عوارض در بیمار پرخطر.**",
    "**درمان انتخابی در بزرگ‌سال: فلوروکینولون، معمولاً سیپروفلوکساسین.**",
    "**و در بارداری و کودکان: آزیترومایسین، چون فلوروکینولون پرهیز می‌شود.**",
    "⚠️ **و مدت درمان با وضعیت ایمنی بیمار تعیین می‌شود.**",
    "**فرد با ایمنی سالم: سه تا پنج روز کافی است.**",
    "**فرد دچار سرکوب ایمنی: هفت تا ده روز، چون خطر باکتریمی و عود بیشتر است.**",
    "**و آمپی‌سیلین و آموکسی‌سیلین به‌دلیل مقاومت گسترده کنار گذاشته شده‌اند.**",
]
SH_EN = [
    "WARNING: SHIGELLA HAS THREE PROPERTIES that explain all of its clinical behaviour.",
    "ONE: an extraordinarily low infective dose, only ten to a hundred organisms.",
    "So it transmits directly person to person and produces household outbreaks.",
    "TWO: invasion of the colonic mucosa, giving dysentery and tenesmus.",
    "THREE: Shiga toxin in S. dysenteriae type 1, which causes HUS.",
    "WARNING, AND TREATING SHIGELLA HAS THREE AIMS, not one.",
    "AIM ONE: shortening the illness.",
    "AIM TWO: shortening the shedding, which interrupts transmission.",
    "AIM THREE: preventing complications in a high-risk patient.",
    "The treatment of choice in an adult: a fluoroquinolone, usually ciprofloxacin.",
    "And in pregnancy and in children: azithromycin, because fluoroquinolones are avoided.",
    "WARNING, AND THE DURATION IS SET BY THE PATIENT'S IMMUNE STATUS.",
    "An immunocompetent person: three to five days suffice.",
    "An immunosuppressed person: seven to ten days, because bacteraemia and relapse are likelier.",
    "And ampicillin and amoxicillin have been abandoned because of widespread resistance.",
]

add("book:329", "vignette", "medium",
    "**شیگلا در گیرنده‌ی پیوند کبد: درمان لازم است و طولانی‌تر — سیپروفلوکساسین هفت روز.**",
    "Shigella in a liver transplant recipient: treatment is required and prolonged — ciprofloxacin for seven days.",
    SH_FA,
    SH_EN,
    "این سؤال یک اصل مهم را می‌سنجد: **سرکوب ایمنی، هم ضرورت درمان و هم مدت آن را تغییر "
    "می‌دهد.**\n\n"
    "**بیمار: آقای ۵۲ ساله، گیرنده‌ی پیوند کبد از یک سال قبل، با تب و درد شکم و اسهال از سه "
    "روز قبل، و رگه‌های خونی در مدفوع. کشت مدفوع از نظر شیگلا مثبت است.**\n\n"
    "**دو تصمیم لازم است: آیا درمان کنیم؟ و چه مدت؟**\n\n"
    "**تصمیم اول — درمان؟ قطعاً بله.**\n\n"
    "**نکته‌ی مهم: شیگلا حتی در فرد سالم هم معمولاً درمان می‌شود** (برخلاف سالمونلای غیرتیفی) "
    "— چون **درمان مدت دفع باکتری را کوتاه می‌کند** و از انتقال جلوگیری می‌کند. ⚠️ **ولی در "
    "این بیمار، درمان اجباری است**: او **گیرنده‌ی پیوند** است و **داروی سرکوب‌کننده‌ی ایمنی** "
    "می‌گیرد. در چنین بیماری، شیگلا می‌تواند به **باکتریمی، بیماری منتشر و عوارض شدید** برسد.\n\n"
    "**تصمیم دوم — چه مدت؟ اینجا نکته‌ی کلیدی است:**\n\n"
    "**در فرد با ایمنی سالم: سه تا پنج روز کافی است.**\n\n"
    "⚠️ **در فرد دچار سرکوب ایمنی: هفت تا ده روز.**\n\n"
    "**چرا طولانی‌تر؟** چون سیستم ایمنی بیمار **نمی‌تواند سهم خودش را در پاک‌سازی باکتری "
    "انجام دهد**. در فرد سالم، آنتی‌بیوتیک فقط **کمک** می‌کند و ایمنی کار را تمام می‌کند. در "
    "فرد دچار سرکوب ایمنی، **آنتی‌بیوتیک باید تقریباً همه‌ی کار را انجام دهد** — پس دوره باید "
    "طولانی‌تر باشد تا **عود و باکتریمی** رخ ندهد.\n\n"
    "**پس پاسخ: سیپروفلوکساسین ۷ روز.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**آزیترومایسین تک‌دوز:** ⚠️ **آزیترومایسین داروی مناسبی برای شیگلاست** (به‌ویژه در "
    "بارداری و کودکان)، **ولی تک‌دوز در بیمار پیوندی کافی نیست**. مدت درمان با وضعیت ایمنی "
    "تعیین می‌شود، و یک دوز برای بیمار دچار سرکوب ایمنی **بسیار کوتاه** است.\n\n"
    "**مترونیدازول سه روز:** مترونیدازول **روی شیگلا اثری ندارد** — داروی بی‌هوازی‌ها و "
    "تک‌یاخته‌هاست. شیگلا یک باسیل گرم منفی **هوازی اختیاری** است.\n\n"
    "⚠️ **بیمار نیازی به آنتی‌بیوتیک ندارد:** **خطرناک‌ترین گزینه.** ممکن است کسی فکر کند "
    "شیگلا خودمحدود است — و در فرد سالم تا حدی درست است. **ولی در گیرنده‌ی پیوند، رها کردن "
    "شیگلای اثبات‌شده می‌تواند به باکتریمی و مرگ برسد.**",
    "This question tests an important principle: IMMUNOSUPPRESSION CHANGES BOTH WHETHER TO TREAT AND "
    "FOR HOW LONG.\n\n"
    "THE PATIENT: a 52-year-old liver transplant recipient of one year, with three days of fever, "
    "abdominal pain and diarrhoea, and streaks of blood in the stool. The stool culture is positive for "
    "Shigella.\n\n"
    "TWO DECISIONS ARE NEEDED: do we treat? And for how long?\n\n"
    "FIRST DECISION — TREAT? DEFINITELY YES.\n\n"
    "AN IMPORTANT POINT: SHIGELLA IS USUALLY TREATED EVEN IN A HEALTHY PERSON (unlike non-typhoidal "
    "Salmonella) — because TREATMENT SHORTENS THE SHEDDING and prevents transmission. WARNING, BUT IN "
    "THIS PATIENT TREATMENT IS MANDATORY: he is A TRANSPLANT RECIPIENT on IMMUNOSUPPRESSIVE DRUGS. In "
    "such a patient Shigella can progress to BACTERAEMIA, DISSEMINATED DISEASE AND SEVERE COMPLICATIONS.\n\n"
    "SECOND DECISION — FOR HOW LONG? Here is the key point:\n\n"
    "IN AN IMMUNOCOMPETENT PERSON: THREE TO FIVE DAYS suffice.\n\n"
    "WARNING, IN AN IMMUNOSUPPRESSED PERSON: SEVEN TO TEN DAYS.\n\n"
    "WHY LONGER? Because the patient's immune system CANNOT DO ITS SHARE OF CLEARING THE ORGANISM. In a "
    "healthy person the antibiotic merely HELPS and immunity finishes the job. In an immunosuppressed "
    "person THE ANTIBIOTIC MUST DO ALMOST ALL THE WORK — so the course must be longer to prevent "
    "RELAPSE AND BACTERAEMIA.\n\n"
    "SO THE ANSWER: CIPROFLOXACIN FOR 7 DAYS.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "SINGLE-DOSE AZITHROMYCIN: WARNING, AZITHROMYCIN IS A SUITABLE DRUG FOR SHIGELLA (especially in "
    "pregnancy and children), BUT A SINGLE DOSE IS NOT ENOUGH IN A TRANSPLANT PATIENT. Duration is set "
    "by immune status, and one dose is FAR TOO SHORT for an immunosuppressed host.\n\n"
    "METRONIDAZOLE FOR THREE DAYS: metronidazole HAS NO EFFECT ON SHIGELLA — it is a drug for anaerobes "
    "and protozoa. Shigella is a FACULTATIVELY AEROBIC gram-negative bacillus.\n\n"
    "WARNING, 'THE PATIENT NEEDS NO ANTIBIOTIC': THE MOST DANGEROUS OPTION. One might reason that "
    "Shigella is self-limited — and in a healthy person that is partly true. BUT IN A TRANSPLANT "
    "RECIPIENT, LEAVING PROVEN SHIGELLA UNTREATED CAN LEAD TO BACTERAEMIA AND DEATH.",
    ["آزیترومایسین داروی مناسبی است ولی تک‌دوز در بیمار پیوندی بسیار کوتاه است.",
     "پاسخ صحیح — در فرد دچار سرکوب ایمنی، دوره‌ی هفت تا ده روزه لازم است.",
     "مترونیدازول روی شیگلا اثری ندارد؛ داروی بی‌هوازی‌ها و تک‌یاخته‌هاست.",
     "خطرناک‌ترین گزینه — در گیرنده‌ی پیوند، شیگلای درمان‌نشده به باکتریمی می‌رسد."],
    ["Azithromycin is a suitable drug but a single dose is far too short in a transplant patient.",
     "Correct — an immunosuppressed patient needs a seven to ten day course.",
     "Metronidazole has no effect on Shigella; it is a drug for anaerobes and protozoa.",
     "The most dangerous option — in a transplant recipient, untreated Shigella leads to bacteraemia."],
    "**در فرد سالم آنتی‌بیوتیک کمک می‌کند؛ در سرکوب ایمنی باید همه‌ی کار را بکند.**",
    "In a healthy person the antibiotic helps; in immunosuppression it must do all the work.",
    REFS)

add("book:331", "recall", "medium",
    "**شیگلا در بیمار تحت شیمی‌درمانی: هفت تا ده روز، نه سه تا پنج روز.**",
    "Shigella in a patient on chemotherapy: seven to ten days, not three to five.",
    SH_FA + [
        "**این سؤال دقیقاً مدت درمان را می‌پرسد و هیچ چیز دیگری.**",
        "**بیمار مبتلا به لوسمی لنفوبلاستیک حاد و تحت شیمی‌درمانی است.**",
        "⚠️ **پس نوتروپنی و سرکوب شدید ایمنی دارد.**",
        "**و در کشت مدفوع، شیگلا دیسانتریه تیپ ۱ جدا شده است.**",
        "**تیپ ۱ همان تیپی است که سم شیگا می‌سازد و می‌تواند HUS بدهد.**",
        "**پس دو دلیل مستقل برای درمان طولانی‌تر هست.**",
        "**یک: سرکوب ایمنی، که خطر باکتریمی و عود را بالا می‌برد.**",
        "**دو: تیپ ۱، که خطرناک‌ترین سروتیپ است.**",
        "⚠️ **پس هفت تا ده روز، نه سه روز و نه پنج روز.**",
    ],
    SH_EN + [
        "This question asks precisely about DURATION and nothing else.",
        "The patient has acute lymphoblastic leukaemia and is on chemotherapy.",
        "WARNING, SO HE IS NEUTROPENIC AND PROFOUNDLY IMMUNOSUPPRESSED.",
        "And the stool culture has grown Shigella dysenteriae type 1.",
        "Type 1 is the one that makes Shiga toxin and can cause HUS.",
        "So there are two independent reasons for a longer course.",
        "ONE: immunosuppression, which raises the risk of bacteraemia and relapse.",
        "TWO: type 1, the most dangerous serotype.",
        "WARNING, SO SEVEN TO TEN DAYS, not three and not five.",
    ],
    "این سؤال **فقط مدت درمان** را می‌پرسد، و پاسخ آن از **وضعیت ایمنی بیمار** می‌آید.\n\n"
    "**بیمار: مرد جوان ۲۵ ساله مبتلا به ALL-L2 تحت شیمی‌درمانی. از سه روز قبل دچار دیسانتری "
    "شده. در کشت مدفوع، Shigella dysenteriae type 1 جدا شده است.**\n\n"
    "**دو عامل، هر دو به سمت درمان طولانی‌تر:**\n\n"
    "⚠️ **عامل یک — سرکوب شدید ایمنی.** بیمار **لوسمی لنفوبلاستیک حاد** دارد و **تحت "
    "شیمی‌درمانی** است. یعنی احتمالاً **نوتروپنیک** است و **ایمنی سلولی و هومورال هر دو "
    "سرکوب شده‌اند**.\n\n"
    "**چرا این مدت را عوض می‌کند؟** در فرد سالم، آنتی‌بیوتیک فقط **شریک** سیستم ایمنی است؛ "
    "بخش عمده‌ی پاک‌سازی را خودِ ایمنی انجام می‌دهد، پس **سه تا پنج روز کافی است**. در بیمار "
    "دچار سرکوب ایمنی، **آنتی‌بیوتیک تقریباً تنهاست** — پس دوره باید **طولانی‌تر** باشد تا "
    "**عود و باکتریمی** رخ ندهد.\n\n"
    "**عامل دو — سروتیپ.** **Shigella dysenteriae type 1** خطرناک‌ترین سروتیپ شیگلاست: تنها "
    "سروتیپی که **سم شیگا** می‌سازد، و بیشترین مرگ‌ومیر و بیشترین خطر **HUS** را دارد.\n\n"
    "**پس پاسخ: ۷ تا ۱۰ روز.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**۳ روز:** این دوره‌ی **کوتاه استاندارد برای فرد کاملاً سالم** است. در بیمار نوتروپنیک "
    "با تیپ ۱، **بسیار کوتاه** است و خطر عود بالاست.\n\n"
    "**۵ روز:** باز هم دوره‌ی **فرد سالم**. کمی طولانی‌تر، ولی همچنان برای بیمار دچار سرکوب "
    "ایمنی ناکافی.\n\n"
    "⚠️ **۱۴ روز:** این **بیش‌ازحد** است. دوره‌ی ۱۴ روزه برای شیگلای روده‌ای — حتی در بیمار "
    "دچار سرکوب ایمنی — توصیه نمی‌شود. **درمان طولانی‌تر از لازم، سود اضافی نمی‌دهد** ولی "
    "**عوارض دارویی، اختلال فلور روده (و خطر کلستریدیوم دیفیسیل) و فشار مقاومت** را بالا "
    "می‌برد. (دوره‌های طولانی‌تر از ده روز برای **باکتریمی اثبات‌شده** یا **عفونت کانونی خارج "
    "روده‌ای** کنار گذاشته می‌شوند.)\n\n"
    "**درس کلی: مدت درمان را نه با شدت علائم، بلکه با وضعیت ایمنی میزبان تعیین کنید.**",
    "This question asks ONLY ABOUT DURATION, and the answer comes from THE PATIENT'S IMMUNE STATUS.\n\n"
    "THE PATIENT: a 25-year-old man with ALL-L2 on chemotherapy. He has had dysentery for three days. "
    "The stool culture has grown SHIGELLA DYSENTERIAE TYPE 1.\n\n"
    "TWO FACTORS, BOTH POINTING TO A LONGER COURSE:\n\n"
    "WARNING, FACTOR ONE — PROFOUND IMMUNOSUPPRESSION. The patient has ACUTE LYMPHOBLASTIC LEUKAEMIA "
    "and is ON CHEMOTHERAPY. He is probably NEUTROPENIC with BOTH CELLULAR AND HUMORAL IMMUNITY "
    "SUPPRESSED.\n\n"
    "WHY DOES THAT CHANGE THE DURATION? In a healthy person the antibiotic is merely A PARTNER to the "
    "immune system; immunity does most of the clearance, so THREE TO FIVE DAYS SUFFICE. In an "
    "immunosuppressed patient THE ANTIBIOTIC IS ALMOST ALONE — so the course must be LONGER to prevent "
    "RELAPSE AND BACTERAEMIA.\n\n"
    "FACTOR TWO — THE SEROTYPE. SHIGELLA DYSENTERIAE TYPE 1 is the most dangerous Shigella serotype: "
    "the only one that makes SHIGA TOXIN, with the highest mortality and the greatest risk of HUS.\n\n"
    "SO THE ANSWER: 7 TO 10 DAYS.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "3 DAYS: the SHORT STANDARD COURSE FOR A FULLY HEALTHY PERSON. In a neutropenic patient with type "
    "1 it is FAR TOO SHORT and the relapse risk is high.\n\n"
    "5 DAYS: again a HEALTHY-PERSON course. Slightly longer, but still inadequate for an "
    "immunosuppressed host.\n\n"
    "WARNING, 14 DAYS: this is EXCESSIVE. A 14-day course for intestinal shigellosis — even in an "
    "immunosuppressed patient — is not recommended. TREATING LONGER THAN NECESSARY ADDS NO BENEFIT but "
    "does add DRUG TOXICITY, DISRUPTION OF THE BOWEL FLORA (and the risk of C. difficile) AND "
    "RESISTANCE PRESSURE. (Courses beyond ten days are reserved for PROVEN BACTERAEMIA or an "
    "EXTRAINTESTINAL FOCUS.)\n\n"
    "THE GENERAL LESSON: SET THE DURATION BY THE HOST'S IMMUNE STATUS, NOT BY THE SEVERITY OF SYMPTOMS.",
    ["دوره‌ی کوتاه استاندارد فرد کاملاً سالم است؛ در بیمار نوتروپنیک بسیار کوتاه است.",
     "باز هم دوره‌ی فرد سالم؛ برای بیمار دچار سرکوب ایمنی ناکافی است.",
     "پاسخ صحیح — سرکوب ایمنی و سروتیپ تیپ ۱، هر دو دوره‌ی هفت تا ده روزه را می‌طلبند.",
     "بیش‌ازحد است؛ سود اضافی ندارد ولی عوارض و فشار مقاومت را بالا می‌برد."],
    ["The short standard course for a fully healthy person; far too short in a neutropenic patient.",
     "Again a healthy-person course; inadequate for an immunosuppressed host.",
     "Correct — immunosuppression and type 1 serotype both call for a seven to ten day course.",
     "Excessive; it adds no benefit but increases toxicity and resistance pressure."],
    "**مدت درمان را وضعیت ایمنی میزبان تعیین می‌کند، نه شدت علائم.**",
    "The duration is set by the host's immune status, not by the severity of symptoms.",
    REFS)

add("book:330", "vignette", "medium",
    "**دیسانتری در بارداری: آزیترومایسین — چون فلوروکینولون و کوتریموکسازول پرهیز می‌شوند.**",
    "Dysentery in pregnancy: AZITHROMYCIN — because fluoroquinolones and co-trimoxazole are avoided.",
    SH_FA + [
        "**در بارداری، فهرست داروهای مجاز کوتاه‌تر می‌شود و همین پاسخ را تعیین می‌کند.**",
        "**فلوروکینولون در بارداری پرهیز می‌شود: نگرانی از آسیب غضروف در مطالعات حیوانی.**",
        "⚠️ **کوتریموکسازول هم پرهیز می‌شود، و در دو انتهای بارداری به دو دلیل متفاوت.**",
        "**در سه‌ماهه‌ی اول: تری‌متوپریم آنتاگونیست فولات است و خطر نقص لوله‌ی عصبی دارد.**",
        "**در سه‌ماهه‌ی سوم: سولفامتوکسازول خطر کرن‌ایکتروس نوزادی دارد.**",
        "**داکسی‌سیکلین هم که تتراسایکلین است و ممنوع.**",
        "**پس چه می‌ماند؟ آزیترومایسین.**",
        "⚠️ **آزیترومایسین در بارداری بی‌خطر است و روی شیگلا مؤثر.**",
        "**و همین آن را به انتخاب استاندارد دیسانتری در بارداری تبدیل می‌کند.**",
    ],
    SH_EN + [
        "In pregnancy the list of permitted drugs shortens, and that decides the answer.",
        "Fluoroquinolones are avoided in pregnancy: concern about cartilage damage in animal studies.",
        "WARNING, CO-TRIMOXAZOLE IS ALSO AVOIDED, at the two ends of pregnancy for two different reasons.",
        "In the first trimester: trimethoprim is a folate antagonist, risking neural tube defects.",
        "In the third trimester: sulfamethoxazole risks neonatal kernicterus.",
        "Doxycycline is a tetracycline and therefore contraindicated.",
        "So what remains? AZITHROMYCIN.",
        "WARNING, AZITHROMYCIN IS SAFE IN PREGNANCY and effective against Shigella.",
        "And that makes it the standard choice for dysentery in pregnancy.",
    ],
    "این سؤال قاعده‌ی درمان شیگلا را با **قید بارداری** ترکیب می‌کند.\n\n"
    "**بیمار: خانم ۲۸ ساله با سن حاملگی ۳۲ هفته، با تب، اسهال خونی، درد شکم و بی‌اشتهایی از "
    "روز قبل. در آزمایش مستقیم مدفوع، گلبول سفید و قرمز فراوان.**\n\n"
    "**تشخیص: دیسانتری باکتریایی** (احتمالاً شیگلا). **و در بارداری، درمان اهمیت بیشتری "
    "دارد**، چون عفونت شدید می‌تواند به **زایمان زودرس** منجر شود.\n\n"
    "⚠️ **حالا فهرست داروها را با فیلتر بارداری بگذرانیم:**\n\n"
    "**فلوروکینولون (سیپروفلوکساسین)** — انتخاب استاندارد در بزرگ‌سال **غیرباردار**، ولی در "
    "بارداری **پرهیز می‌شود** به‌دلیل نگرانی از **آسیب غضروف** در مطالعات حیوانی.\n\n"
    "**کوتریموکسازول** — ⚠️ **در بارداری پرهیز می‌شود، و جالب اینکه در دو انتهای بارداری به "
    "دو دلیل کاملاً متفاوت:** در **سه‌ماهه‌ی اول**، **تری‌متوپریم آنتاگونیست فولات** است و خطر "
    "**نقص لوله‌ی عصبی** دارد. در **سه‌ماهه‌ی سوم**، **سولفامتوکسازول بیلی‌روبین را از آلبومین "
    "جدا می‌کند** و خطر **کرن‌ایکتروس نوزادی** دارد. (این بیمار در هفته‌ی ۳۲ است، یعنی همان "
    "خطر دوم.)\n\n"
    "**داکسی‌سیکلین** — تتراسایکلین است و در بارداری **ممنوع** (دندان و استخوان جنین).\n\n"
    "**پس چه می‌ماند؟ آزیترومایسین.**\n\n"
    "**آزیترومایسین در بارداری بی‌خطر است** (رده‌ی B) و **روی شیگلا مؤثر** است. و همین آن "
    "را به **انتخاب استاندارد دیسانتری در بارداری** تبدیل می‌کند.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**آموکسی‌سیلین:** ⚠️ **در بارداری بی‌خطر است**، ولی مشکل جای دیگری است: **شیگلا مقاومت "
    "گسترده‌ای به آمپی‌سیلین و آموکسی‌سیلین دارد**. دارویی که بی‌خطر باشد ولی **بی‌اثر**، انتخاب "
    "درستی نیست.\n\n"
    "**کلیندامایسین:** روی **بی‌هوازی‌ها و گرم مثبت‌ها** مؤثر است، نه روی **باسیل‌های گرم "
    "منفی روده‌ای** مثل شیگلا. به‌علاوه خودش از **راه‌اندازنده‌های اصلی کلستریدیوم دیفیسیل** است.\n\n"
    "**سفوروکسیم:** سفالوسپورین نسل دوم. **پوشش آن روی شیگلا قابل اتکا نیست**، و "
    "سفالوسپورین‌های خوراکی به‌طور کلی برای دیسانتری شیگلایی توصیه نمی‌شوند.",
    "This question combines the Shigella treatment rule with THE CONSTRAINT OF PREGNANCY.\n\n"
    "THE PATIENT: a 28-year-old woman at 32 weeks' gestation with fever, bloody diarrhoea, abdominal "
    "pain and anorexia since yesterday. Direct stool examination shows abundant white and red cells.\n\n"
    "THE DIAGNOSIS: bacterial dysentery (probably Shigella). AND IN PREGNANCY TREATMENT MATTERS MORE, "
    "because severe infection can precipitate PRETERM LABOUR.\n\n"
    "WARNING, NOW PASS THE DRUG LIST THROUGH THE PREGNANCY FILTER:\n\n"
    "A FLUOROQUINOLONE (ciprofloxacin) — the standard choice in a NON-PREGNANT adult, but AVOIDED in "
    "pregnancy because of concern about CARTILAGE DAMAGE in animal studies.\n\n"
    "CO-TRIMOXAZOLE — WARNING, AVOIDED IN PREGNANCY, and interestingly at the two ends of pregnancy for "
    "two entirely different reasons: in the FIRST TRIMESTER, TRIMETHOPRIM IS A FOLATE ANTAGONIST "
    "risking NEURAL TUBE DEFECTS. In the THIRD TRIMESTER, SULFAMETHOXAZOLE DISPLACES BILIRUBIN FROM "
    "ALBUMIN, risking NEONATAL KERNICTERUS. (This patient is at 32 weeks, so the second risk applies.)\n\n"
    "DOXYCYCLINE — a tetracycline, CONTRAINDICATED in pregnancy (fetal teeth and bone).\n\n"
    "SO WHAT REMAINS? AZITHROMYCIN.\n\n"
    "AZITHROMYCIN IS SAFE IN PREGNANCY (category B) and EFFECTIVE against Shigella. And that makes it "
    "THE STANDARD CHOICE FOR DYSENTERY IN PREGNANCY.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "AMOXICILLIN: WARNING, IT IS SAFE IN PREGNANCY, but the problem lies elsewhere: SHIGELLA HAS "
    "WIDESPREAD RESISTANCE TO AMPICILLIN AND AMOXICILLIN. A drug that is safe but INEFFECTIVE is not "
    "the right choice.\n\n"
    "CLINDAMYCIN: effective against ANAEROBES AND GRAM POSITIVES, not against ENTERIC GRAM-NEGATIVE "
    "BACILLI such as Shigella. And it is itself one of the MAIN C. DIFFICILE TRIGGERS.\n\n"
    "CEFUROXIME: a second-generation cephalosporin. ITS COVERAGE OF SHIGELLA IS NOT RELIABLE, and oral "
    "cephalosporins are generally not recommended for shigellosis.",
    ["در بارداری بی‌خطر است ولی شیگلا مقاومت گسترده‌ای به آن دارد؛ بی‌خطر ولی بی‌اثر.",
     "پاسخ صحیح — در بارداری بی‌خطر و روی شیگلا مؤثر؛ انتخاب استاندارد دیسانتری بارداری.",
     "روی بی‌هوازی‌ها و گرم مثبت‌ها مؤثر است نه باسیل گرم منفی روده‌ای؛ و خود راه‌انداز دیفیسیل است.",
     "پوشش آن روی شیگلا قابل اتکا نیست؛ سفالوسپورین خوراکی برای شیگلوز توصیه نمی‌شود."],
    ["Safe in pregnancy but Shigella has widespread resistance to it; safe but ineffective.",
     "Correct — safe in pregnancy and effective against Shigella; the standard choice in pregnancy.",
     "Effective against anaerobes and gram positives, not enteric gram-negative bacilli; and a C. difficile trigger.",
     "Its Shigella coverage is unreliable; oral cephalosporins are not recommended for shigellosis."],
    "**کوتریموکسازول در سه‌ماهه‌ی اول فولات را می‌زند، در سوم کرن‌ایکتروس می‌دهد.**",
    "Co-trimoxazole antagonises folate in the first trimester and risks kernicterus in the third.",
    REFS)

add("book:323", "vignette", "medium",
    "**تشنج و پرولاپس مقعد در کودک با دیسانتری: شیگلا — و تشنج امضای عصبی آن است.**",
    "Seizure and rectal prolapse in a child with dysentery: SHIGELLA — and the seizure is its neurological signature.",
    SH_FA + [
        "**شیگلا در کودکان دو عارضه‌ی مشخص دارد که این سؤال هر دو را آورده است.**",
        "⚠️ **عارضه‌ی یک: تشنج، که در شیگلوز کودکان شایع است.**",
        "**و جالب اینکه لزوماً از تب بالا نیست.**",
        "**سازوکار آن کاملاً روشن نیست، ولی اثر نوروتوکسیک مطرح است.**",
        "**تشنج می‌تواند حتی پیش از اسهال ظاهر شود و تشخیص را گمراه کند.**",
        "**عارضه‌ی دو: پرولاپس رکتوم، از تنسموس و زور زدن مداوم.**",
        "**التهاب شدید رکتوم، احساس دائمی نیاز به اجابت مزاج می‌سازد.**",
        "⚠️ **و زور زدن مکرر در کودک، رکتوم را بیرون می‌اندازد.**",
        "**پس هر دو عارضه از یک ویژگی می‌آیند: شدت درگیری کولون و رکتوم.**",
    ],
    SH_EN + [
        "Shigella has two characteristic complications in children, and this question has both.",
        "WARNING, COMPLICATION ONE: SEIZURES, which are common in childhood shigellosis.",
        "And interestingly they are not necessarily from the high fever.",
        "Their mechanism is not fully understood, but a neurotoxic effect is proposed.",
        "A seizure can even precede the diarrhoea and mislead the diagnosis.",
        "COMPLICATION TWO: rectal prolapse, from tenesmus and constant straining.",
        "Intense rectal inflammation creates a permanent urge to defaecate.",
        "WARNING, AND REPEATED STRAINING IN A CHILD pushes the rectum out.",
        "So both complications arise from one feature: the severity of colonic and rectal involvement.",
    ],
    "این سؤال دو **عارضه‌ی اختصاصی شیگلا در کودکان** را کنار هم گذاشته است.\n\n"
    "**بیمار: کودکی که به دنبال تب و اسهال دچار تشنج شده است. از شکم‌درد و تنسموس هم شاکی "
    "است. و در روند بیماری دچار پرولاپس مقعد شده.**\n\n"
    "**سه سرنخ، همه به شیگلا:**\n\n"
    "⚠️ **سرنخ یک — تشنج.** **تشنج یکی از شایع‌ترین عوارض خارج‌روده‌ای شیگلوز در کودکان است.** "
    "و نکته‌ی جالب: **لزوماً از تب بالا نیست** — تشنج می‌تواند حتی با تب متوسط رخ دهد، و "
    "گاهی **پیش از شروع اسهال** ظاهر می‌شود و تشخیص را گمراه می‌کند. سازوکار آن کاملاً روشن "
    "نیست، ولی **اثر نوروتوکسیک** مطرح است.\n\n"
    "**سرنخ دو — تنسموس.** یعنی **رکتیت**؛ التهاب به رکتوم رسیده است. این امضای دیسانتری "
    "شیگلایی است.\n\n"
    "**سرنخ سه — پرولاپس مقعد.** و این از تنسموس می‌آید: **التهاب شدید رکتوم، احساس دائمی "
    "نیاز به اجابت مزاج می‌سازد** → کودک **مدام زور می‌زند** → و **رکتوم بیرون می‌افتد**.\n\n"
    "**پس هر دو عارضه از یک ریشه می‌آیند: شدت درگیری کولون و رکتوم.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**سالمونلا تیفی:** تابلوی آن **تب روده‌ای** است — تب پلکانی، برادی‌کاردی نسبی، راش "
    "رزئولا، هپاتواسپلنومگالی، و اغلب **یبوست** در ابتدا (نه اسهال خونی). و **تنسموس و "
    "پرولاپس رکتوم از عوارض آن نیستند**.\n\n"
    "**ای‌کلای انتروهموراژیک (EHEC):** ⚠️ **اسهال خونی می‌دهد**، ولی **معمولاً بدون تب یا با "
    "تب خفیف** — و این سؤال صریحاً تب دارد. عارضه‌ی مشخص EHEC **سندرم همولیتیک اورمیک** است، "
    "نه تشنج و پرولاپس. (البته HUS خودش می‌تواند تشنج بدهد، ولی در آن صورت نارسایی کلیه و "
    "آنمی هم می‌داشت.)\n\n"
    "**آمیب هیستولیتیکا:** دیسانتری و گاهی پرولاپس می‌دهد، ولی **شروع آن تدریجی‌تر** است، "
    "**تب بارز کمتر** دارد، و **تشنج از عوارض شناخته‌شده‌ی آن نیست**.\n\n"
    "**پس تنها گزینه‌ای که هر سه سرنخ را با هم توضیح می‌دهد، شیگلاست.**",
    "This question places TWO COMPLICATIONS SPECIFIC TO CHILDHOOD SHIGELLOSIS side by side.\n\n"
    "THE PATIENT: a child who has had a seizure following fever and diarrhoea. He also complains of "
    "abdominal pain and tenesmus. And in the course of the illness he has developed rectal prolapse.\n\n"
    "THREE CLUES, ALL TO SHIGELLA:\n\n"
    "WARNING, CLUE ONE — THE SEIZURE. SEIZURES ARE AMONG THE COMMONEST EXTRAINTESTINAL COMPLICATIONS OF "
    "SHIGELLOSIS IN CHILDREN. And an interesting point: THEY ARE NOT NECESSARILY DUE TO HIGH FEVER — a "
    "seizure can occur with only moderate fever, and it sometimes PRECEDES THE DIARRHOEA and misleads "
    "the diagnosis. Its mechanism is not fully understood, but A NEUROTOXIC EFFECT is proposed.\n\n"
    "CLUE TWO — TENESMUS. That means PROCTITIS; the inflammation has reached the rectum. This is the "
    "signature of shigellosis.\n\n"
    "CLUE THREE — RECTAL PROLAPSE. And this arises from the tenesmus: INTENSE RECTAL INFLAMMATION "
    "CREATES A PERMANENT URGE TO DEFAECATE, the child STRAINS CONSTANTLY, and THE RECTUM PROLAPSES.\n\n"
    "SO BOTH COMPLICATIONS SHARE ONE ROOT: the severity of colonic and rectal involvement.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "SALMONELLA TYPHI: its picture is ENTERIC FEVER — stepwise fever, relative bradycardia, rose spots, "
    "hepatosplenomegaly, and often CONSTIPATION at first (not bloody diarrhoea). And TENESMUS AND "
    "RECTAL PROLAPSE ARE NOT ITS COMPLICATIONS.\n\n"
    "ENTEROHAEMORRHAGIC E. COLI (EHEC): WARNING, IT CAUSES BLOODY DIARRHOEA, but USUALLY WITHOUT FEVER "
    "OR WITH ONLY A MILD ONE — and this question states fever explicitly. EHEC's characteristic "
    "complication is HAEMOLYTIC URAEMIC SYNDROME, not seizures and prolapse. (HUS can itself cause "
    "seizures, but then renal failure and anaemia would also be present.)\n\n"
    "ENTAMOEBA HISTOLYTICA: it causes dysentery and sometimes prolapse, but ITS ONSET IS MORE GRADUAL, "
    "IT CAUSES LESS PROMINENT FEVER, and SEIZURES ARE NOT A RECOGNISED COMPLICATION.\n\n"
    "SO THE ONLY OPTION THAT EXPLAINS ALL THREE CLUES TOGETHER IS SHIGELLA.",
    ["تابلوی آن تب روده‌ای است: تب پلکانی، برادی‌کاردی نسبی و اغلب یبوست، نه دیسانتری با تشنج.",
     "پاسخ صحیح — تشنج و پرولاپس رکتوم هر دو از عوارض شناخته‌شده‌ی شیگلوز کودکان‌اند.",
     "اسهال خونی می‌دهد ولی معمولاً بدون تب؛ عارضه‌ی مشخص آن HUS است نه تشنج و پرولاپس.",
     "دیسانتری می‌دهد ولی شروع تدریجی‌تر، تب کمتر، و تشنج از عوارض آن نیست."],
    ["Its picture is enteric fever: stepwise fever, relative bradycardia and often constipation.",
     "Correct — seizures and rectal prolapse are both recognised complications of childhood shigellosis.",
     "Causes bloody diarrhoea but usually without fever; its complication is HUS, not seizures and prolapse.",
     "Causes dysentery but with a more gradual onset, less fever, and seizures are not a complication."],
    "**تشنج در کودک با دیسانتری = شیگلا، حتی بدون تب بسیار بالا.**",
    "A seizure in a child with dysentery means Shigella, even without very high fever.",
    REFS)

add("book:325", "vignette", "easy",
    "**اسهال آبکی که به خونی با حجم کم تبدیل می‌شود: تکامل کلاسیک شیگلا.**",
    "Watery diarrhoea evolving into small-volume bloody stool: the classic Shigella evolution.",
    SH_FA + [
        "**این سؤال یک الگوی زمانی را می‌سنجد، نه یک یافته‌ی منفرد.**",
        "**روز اول: تب و اسهال آبکی.**",
        "**روز دوم: حجم کم شده ولی خونی شده است.**",
        "⚠️ **و این دقیقاً تکامل دومرحله‌ای شیگلاست، که سازوکار دارد.**",
        "**مرحله‌ی اول: شیگلا در روده‌ی باریک سم ترشح می‌کند و اسهال آبکی می‌دهد.**",
        "**مرحله‌ی دوم: به کولون می‌رسد و مخاط را تهاجم می‌کند.**",
        "**و تهاجم کولون یعنی حجم کم، خون، بلغم و تنسموس.**",
        "**پس کاهش حجم همراه با خونی شدن، نشانه‌ی حرکت بیماری از روده‌ی باریک به کولون است.**",
    ],
    SH_EN + [
        "This question tests A TEMPORAL PATTERN rather than a single finding.",
        "Day one: fever and watery diarrhoea.",
        "Day two: the volume has fallen but the stool has become bloody.",
        "WARNING, AND THAT IS EXACTLY THE TWO-STAGE SHIGELLA EVOLUTION, and it has a mechanism.",
        "STAGE ONE: Shigella secretes toxin in the small bowel, giving watery diarrhoea.",
        "STAGE TWO: it reaches the colon and invades the mucosa.",
        "And colonic invasion means small volume, blood, mucus and tenesmus.",
        "So a falling volume with the appearance of blood signals movement from small bowel to colon.",
    ],
    "این سؤال کوتاه است ولی یک **الگوی زمانی** را می‌سنجد که ارزش تشخیصی واقعی دارد.\n\n"
    "**بیمار: کودک هفت ساله. از روز گذشته تب و اسهال آبکی پیدا کرده. امروز حجم اسهال کاهش "
    "یافته ولی خونی شده است.**\n\n"
    "⚠️ **این تکامل دومرحله‌ای، امضای شیگلاست — و سازوکار روشنی دارد:**\n\n"
    "**مرحله‌ی اول (روز اول): اسهال آبکی.** شیگلا ابتدا در **روده‌ی باریک** مستقر می‌شود و "
    "**سم انتروتوکسیک** ترشح می‌کند. روده‌ی باریک سطح جذب بزرگی دارد، پس اختلال آن **اسهال "
    "آبکی با حجم زیاد** می‌دهد.\n\n"
    "**مرحله‌ی دوم (روز دوم): دیسانتری.** باکتری به **کولون** می‌رسد و **مخاط را تهاجم "
    "می‌کند**. سلول‌های اپیتلیال را می‌کشد، زخم می‌سازد، و التهاب شدید ایجاد می‌کند.\n\n"
    "**و تهاجم کولون تابلوی کاملاً متفاوتی می‌دهد:** **حجم کم** (چون کولون ظرفیت کمی دارد "
    "و ملتهب است)، **خون** (از زخم‌های مخاطی)، **بلغم**، و **تنسموس**.\n\n"
    "⚠️ **پس «کاهش حجم همراه با خونی شدن» یک بدتر شدن است، نه بهبود** — و این نکته‌ی بالینی "
    "مهمی است. والدین ممکن است فکر کنند «اسهال کمتر شده، پس بهتر شده»، در حالی که **بیماری "
    "از روده‌ی باریک به کولون پیشرفت کرده است**.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**کمپیلوباکتر ژژونی:** ⚠️ **نزدیک‌ترین رقیب**، چون آن هم اسهال خونی می‌دهد و می‌تواند "
    "با فاز آبکی شروع شود. ولی **دوره‌ی نهفتگی آن ۲ تا ۵ روز** است و تابلوی آن اغلب با "
    "**درد شکمی شدید و پرودروم شبه‌آنفلوانزا** همراه است. **تکامل سریع یک‌روزه‌ی آبکی به خونی، "
    "بیشتر مشخصه‌ی شیگلاست.**\n\n"
    "**آنتاموبا هیستولیتیکا:** شروع آن **تدریجی و در طول هفته‌ها** است، نه یک روز. و **تب "
    "بارز** معمولاً ندارد.\n\n"
    "**ویبریوکلرا:** ⚠️ **از پایه رد می‌شود.** وبا **هرگز خونی نمی‌شود** و **حجم آن کاهش "
    "نمی‌یابد بلکه افزایش می‌یابد**. تابلوی آن **اسهال آبکی بسیار حجیم بدون خون و بدون تب** "
    "است — یعنی **دقیقاً برعکس** آنچه در روز دوم این بیمار رخ داده.",
    "This question is short but tests A TEMPORAL PATTERN with real diagnostic value.\n\n"
    "THE PATIENT: a seven-year-old child. Since yesterday he has had fever and watery diarrhoea. Today "
    "the volume has fallen but the stool has become bloody.\n\n"
    "WARNING, THIS TWO-STAGE EVOLUTION IS THE SHIGELLA SIGNATURE — and it has a clear mechanism:\n\n"
    "STAGE ONE (day one): WATERY DIARRHOEA. Shigella first establishes itself in the SMALL BOWEL and "
    "secretes an ENTEROTOXIC toxin. The small bowel has a large absorptive surface, so disturbing it "
    "gives LARGE-VOLUME WATERY DIARRHOEA.\n\n"
    "STAGE TWO (day two): DYSENTERY. The organism reaches the COLON and INVADES THE MUCOSA. It kills "
    "epithelial cells, creates ulcers and provokes intense inflammation.\n\n"
    "AND COLONIC INVASION GIVES AN ENTIRELY DIFFERENT PICTURE: SMALL VOLUME (the colon has little "
    "capacity and is inflamed), BLOOD (from mucosal ulcers), MUCUS, and TENESMUS.\n\n"
    "WARNING, SO 'FALLING VOLUME WITH THE APPEARANCE OF BLOOD' IS A DETERIORATION, NOT AN IMPROVEMENT — "
    "and this is an important clinical point. Parents may think 'the diarrhoea has lessened, so he is "
    "better', when in fact THE DISEASE HAS ADVANCED FROM SMALL BOWEL TO COLON.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "CAMPYLOBACTER JEJUNI: WARNING, THE CLOSEST COMPETITOR, since it too causes bloody diarrhoea and "
    "can begin with a watery phase. But ITS INCUBATION IS 2 TO 5 DAYS and its picture often includes "
    "SEVERE ABDOMINAL PAIN AND AN INFLUENZA-LIKE PRODROME. A RAPID ONE-DAY EVOLUTION FROM WATERY TO "
    "BLOODY IS MORE CHARACTERISTIC OF SHIGELLA.\n\n"
    "ENTAMOEBA HISTOLYTICA: its onset is GRADUAL, OVER WEEKS, not one day. And it usually causes NO "
    "PROMINENT FEVER.\n\n"
    "VIBRIO CHOLERAE: WARNING, REJECTED FROM THE START. Cholera IS NEVER BLOODY and its volume DOES NOT "
    "FALL BUT RISES. Its picture is VERY LARGE-VOLUME WATERY DIARRHOEA WITHOUT BLOOD OR FEVER — that "
    "is, PRECISELY THE OPPOSITE of what happened to this patient on day two.",
    ["نزدیک‌ترین رقیب، ولی نهفتگی ۲ تا ۵ روزه دارد و تکامل یک‌روزه بیشتر مشخصه‌ی شیگلاست.",
     "پاسخ صحیح — تکامل آبکی به خونی با کاهش حجم، یعنی حرکت از روده‌ی باریک به کولون.",
     "شروع آن تدریجی و در طول هفته‌هاست، نه یک روز، و تب بارز ندارد.",
     "از پایه رد می‌شود — وبا هرگز خونی نمی‌شود و حجم آن افزایش می‌یابد نه کاهش."],
    ["The closest competitor, but its incubation is 2 to 5 days and a one-day evolution favours Shigella.",
     "Correct — watery evolving to bloody with falling volume means movement from small bowel to colon.",
     "Its onset is gradual over weeks, not one day, and it causes no prominent fever.",
     "Rejected outright — cholera is never bloody and its volume rises rather than falls."],
    "**کاهش حجم با خونی شدن = بدتر شدن، نه بهبود.**",
    "Falling volume with the appearance of blood means deterioration, not improvement.",
    REFS)

json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book48.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 48 lessons:', len(L))
