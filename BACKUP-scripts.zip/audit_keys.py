# -*- coding: utf-8 -*-
"""Audit the book's printed answer keys against clinical rules.

Why
---
The book prints an answer under every question, and extraction of those letters
is faithful (verified line-by-line against the PDF). But spot-checking revealed
that a few printed keys are themselves medically wrong — for example a typhoid
vignette whose printed answer is "meningitis" when the classic complication is
intestinal perforation and haemorrhage.

That matters more than a parsing bug. A wrong key teaches the student the wrong
medicine and, worse, does it with the authority of a printed answer. So before
any of these questions gets a lesson and goes on the learning path, its key has
to be checked rather than trusted.

This script does the mechanical part of that check: it flags questions whose
printed key contradicts a small set of high-confidence, explicitly-stated rules
drawn from Harrison 21e. It is deliberately narrow — it only fires when the
stem clearly matches a pattern AND the printed answer clearly contradicts it.
Everything it flags is then read by hand; nothing is rewritten automatically.
"""
import json, io, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
BANK = '/home/user/project/tools/infectious-bank'


def load():
    qs = []
    for i in range(1, 6):
        p = os.path.join(BANK, f'import-payload.book.part{i:02d}.json')
        if os.path.exists(p):
            qs += json.load(io.open(p, encoding='utf-8'))['questions']
    return qs


def has(s, *words):
    return all(w in s for w in words)


def any_of(s, *words):
    return any(w in s for w in words)


# Each rule: (name, does the stem match?, which option SHOULD be right?)
# `expect` returns a predicate over option text, or None to skip.
RULES = []


def rule(name):
    def deco(fn):
        RULES.append((name, fn))
        return fn
    return deco


@rule('typhoid complication')
def _typhoid(stem, opts):
    """Enteric fever: the classic severe complications are intestinal
       perforation and GI haemorrhage in week 3, not meningitis."""
    if not (any_of(stem, 'صورتی کمرنگ', 'رزئولا', 'Rose spot') and
            any_of(stem, 'یبوست', 'تیفوئید', 'حصبه', 'درد شکم')):
        return None
    if 'عوارض' not in stem:
        return None
    return lambda o: 'پرفوراسیون' in o or 'خونریزی' in o


@rule('HIV ELISA confirmation')
def _hiv(stem, opts):
    """A reactive screening immunoassay is confirmed, not simply repeated.
       Modern algorithms use an antibody-differentiation assay or HIV RNA;
       older ones used Western blot. Repeating the same ELISA is not the
       confirmatory step."""
    if not (has(stem, 'ELISA') and any_of(stem, 'HIV')):
        return None
    if 'اقدام بعدی' not in stem:
        return None
    return lambda o: any_of(o, 'Western', 'blot', 'PCR', 'RNA')


@rule('gonococcal urethritis: cover chlamydia too')
def _gc(stem, opts):
    """Presumptive urethritis is treated for gonorrhoea AND chlamydia.
       Restricted to the FIRST presentation: once ceftriaxone has already been
       given and symptoms recur without re-exposure, the residual pathogen is
       chlamydia and azithromycin alone is correct, so those stems are excluded."""
    if not (any_of(stem, 'یورترا', 'مجرا') and 'ترشح' in stem):
        return None
    if 'درمان' not in stem:
        return None
    if any_of(stem, 'مجدد', 'بهبودی پید', 'یک هفته بعد', 'بعد از یک هفته'):
        return None          # recurrence scenario, different logic
    return lambda o: ('Ceftriax' in o or 'سفتریاکسون' in o) and \
                     any_of(o, 'Azithromycin', 'Doxicyclin', 'Doxycyclin', 'آزیترو', 'داکسی')


@rule('post-splenectomy sepsis needs immediate antibiotics')
def _asplenia(stem, opts):
    if not (any_of(stem, 'طحال\u200cبردار', 'طحا لبردار', 'اسپلنکتومی', 'طحال برداری')
            and any_of(stem, 'تب', 'شوک')):
        return None
    if 'اقدام' not in stem and 'درمان' not in stem:
        return None
    return lambda o: any_of(o, 'سفتریاکسون', 'آنتی\u200cبیوتیک', 'آنت یبیوتیک', 'وانکومایسین')


@rule('meningitis: do not delay antibiotics for imaging')
def _mening(stem, opts):
    if not (any_of(stem, 'سفتی گردن', 'مننژیت') and any_of(stem, 'اقدام', 'ترتیب')):
        return None
    if 'CT' not in stem and 'سی\u200cتی' not in stem:
        return None
    return None          # ordering varies by stem; report only, no auto-rule


def main():
    qs = load()
    flagged = []
    for n, q in enumerate(qs):
        stem = q['question_fa']
        opts = q['options_fa']
        ci = q['correct_index']
        for name, fn in RULES:
            pred = fn(stem, opts)
            if pred is None:
                continue
            # which options satisfy the clinical rule?
            good = [i for i, o in enumerate(opts) if pred(o)]
            if good and ci not in good:
                flagged.append({
                    'idx': n, 'rule': name,
                    'year': q['year'], 'month': q['month'],
                    'chapter': q['chapter_fa'],
                    'stem': stem[:160],
                    'printed': f"{ci}: {opts[ci][:70]}",
                    'expected': [f"{i}: {opts[i][:70]}" for i in good],
                })
    print(f'questions scanned: {len(qs)}')
    print(f'printed keys contradicting a clinical rule: {len(flagged)}')
    for f in flagged:
        print()
        print(f"  [{f['rule']}] idx={f['idx']}  {f['year']}-{f['month']}  {f['chapter']}")
        print(f"    Q: {f['stem']}")
        print(f"    printed key -> {f['printed']}")
        for e in f['expected']:
            print(f"    should be   -> {e}")
    dest = os.path.join(HERE, 'out', 'key_audit.json')
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    json.dump(flagged, io.open(dest, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(f'\n-> {dest}')


if __name__ == '__main__':
    main()
