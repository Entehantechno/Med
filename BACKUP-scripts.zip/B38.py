# -*- coding: utf-8 -*-
"""Micro-lessons, batch 38 — varicella zoster, measles/rubella/mumps, hepatitis C.

This batch finishes the viral and STI chapter, the largest in the book.

THE FOUR VARICELLA POST-EXPOSURE QUESTIONS AND WHY THEIR KEYS LOOK WRONG
-------------------------------------------------------------------------
q9626, q9629, q9630 and q9634 all key ORAL ACICLOVIR rather than VZIG, and a
student who learned "VZIG for the immunocompromised" from an older source will
be certain the keys are mistaken. They are not, and the reason is one of the
most instructive facts in the chapter:

A randomised comparison in healthy children showed that aciclovir started
IMMEDIATELY after exposure FAILED — 10 of 13 (77%) still developed varicella —
while aciclovir started at DAY 7 WORKED, with only 3 of 14 (21%) becoming ill.
The variable is TIMING, not the drug: the antiviral must be present at the
peak of viral replication, and in the first days there is nothing to inhibit.

On that evidence UKHSA (2023, reviewed 2025) and the RCOG Green-top 13
(updated 2024) made oral antivirals from day 7 to 14 the FIRST CHOICE for
susceptible pregnant women at any gestation, with VZIG reserved for those who
cannot take oral drugs. So the printed keys agree with CURRENT guidance, and
the lessons say so explicitly rather than leaving the student confused.

A SOURCE DEFECT ANNOTATED IN THIS BATCH
----------------------------------------
q9599 prints a platelet count of 1,350,000 — not a human value. Glyph geometry
confirms page 223 prints exactly that, so it is the BOOK's error and not our
extraction; the intended figure is almost certainly 135,000, the mild
thrombocytopenia of mononucleosis. The text is left alone and annotated (see
flag_source_errors_viral.py) and the lesson tells the student openly.

Reference: UKHSA — Guidelines on post-exposure prophylaxis (PEP) for varicella
or shingles (2023, reviewed 2025); RCOG Green-top Guideline No. 13 (2024);
CDC Pink Book Ch. 13 (Measles) and Ch. 15 (Mumps); AAP Red Book; Harrison's
Principles of Internal Medicine, 21st ed (2022).
"""
import json, io, os
import importlib.util

_spec = importlib.util.spec_from_file_location(
    "b37", os.path.join(os.path.dirname(os.path.abspath(__file__)), "B37.py"))

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — the viral infection chapters")
UKHSA = ("UK Health Security Agency — Guidelines on post-exposure prophylaxis (PEP) for "
         "varicella or shingles (2023, reviewed 2025)")
RCOG = ("Royal College of Obstetricians and Gynaecologists — Green-top Guideline No. 13: "
        "Chickenpox in Pregnancy (updated 2024)")
CDCMUMPS = ("CDC — Epidemiology and Prevention of Vaccine-Preventable Diseases (Pink Book), "
            "Ch. 15: Mumps; and Manual for the Surveillance of Vaccine-Preventable Diseases, "
            "Ch. 9: Mumps")
CDCMEASLES = ("CDC — Epidemiology and Prevention of Vaccine-Preventable Diseases (Pink Book), "
              "Ch. 13: Measles")
REDBOOK = ("American Academy of Pediatrics — Red Book: Report of the Committee on Infectious "
           "Diseases (varicella-zoster and Epstein-Barr virus)")
AASLD = ("AASLD-IDSA — Recommendations for Testing, Managing and Treating Hepatitis C")

# ===================================================== MONONUCLEOSIS
MONO_FA = [
    "⚠️ **مونونوکلئوز را از استرپتوکوک با سه یافته جدا کنید، و هر سه در این فصل پرسیده شده‌اند.**",
    "**یک — محل غدد: در مونونوکلئوز، گردنی خلفی یا ژنرالیزه؛ در استرپتوکوک، گردنی قدامی.**",
    "⚠️ **دو — اسپلنومگالی: استرپتوکوک طحال را بزرگ نمی‌کند. مونونوکلئوز در نیمی از موارد می‌کند.**",
    "**سه — لام خون: لنفوسیتوز با بیش از ۱۰ درصد لنفوسیت آتیپیک.**",
    "**این لنفوسیت‌های آتیپیک سلول‌های آلوده نیستند — سلول‌های T واکنشی علیه سلول B آلوده‌اند.**",
    "**پس تابلوی مونونوکلئوز بیشتر یک واکنش ایمنی است تا تهاجم مستقیم ویروس.**",
    "⚠️ **درمان مونونوکلئوز بدون عارضه: هیچ. استراحت، مایعات، مسکن و تب‌بر.**",
    "**آسیکلوویر بار ویروسی حلق را کم می‌کند ولی سیر بالینی را کوتاه نمی‌کند، پس توصیه نمی‌شود.**",
    "⚠️ **و دامی که این فصل چند بار می‌آزماید: آمپی‌سیلین یا آموکسی‌سیلین ندهید.**",
    "**در اکثریت قاطع بیماران مونونوکلئوزی این داروها راش ماکولوپاپولر وسیعی می‌سازند.**",
    "**این راش آلرژی به پنی‌سیلین نیست و نباید در پرونده به‌عنوان آلرژی ثبت شود.**",
    "⚠️ **و توصیه‌ی عملی کلیدی: پرهیز از ورزش‌های برخوردی تا ۳ تا ۴ هفته.**",
    "**چون پارگی طحال، هرچند نادر، کشنده‌ترین عارضه‌ی مونونوکلئوز است.**",
]
MONO_EN = [
    "WARNING: SEPARATE MONONUCLEOSIS FROM STREPTOCOCCUS BY THREE FINDINGS, all examined in this chapter.",
    "ONE — the site of the nodes: posterior cervical or generalised in mononucleosis; anterior cervical in streptococcus.",
    "WARNING, TWO — SPLENOMEGALY: streptococcus does not enlarge the spleen. Mononucleosis does in half of cases.",
    "THREE — the blood film: lymphocytosis with more than 10 per cent ATYPICAL LYMPHOCYTES.",
    "Those atypical lymphocytes are not infected cells — they are reactive T cells attacking infected B cells.",
    "So the picture of mononucleosis is more an immune reaction than a direct viral invasion.",
    "WARNING, THE TREATMENT OF UNCOMPLICATED MONONUCLEOSIS IS NOTHING: rest, fluids, analgesia, antipyretics.",
    "Aciclovir reduces pharyngeal shedding but does not shorten the illness, so it is not recommended.",
    "WARNING, AND THE TRAP THIS CHAPTER TESTS REPEATEDLY: DO NOT GIVE AMPICILLIN OR AMOXICILLIN.",
    "In the great majority of patients with mononucleosis these drugs produce a florid maculopapular rash.",
    "That rash is NOT a penicillin allergy and must not be recorded as one.",
    "WARNING, AND THE KEY PRACTICAL ADVICE: avoid contact sports for 3 to 4 weeks.",
    "Because SPLENIC RUPTURE, though rare, is the most lethal complication of mononucleosis.",
]

# ===================================================== VARICELLA ZOSTER
VZV_FA = [
    "⚠️ **آبله‌مرغان را از سه‌گانه‌اش بشناسید، و هر سه جزء لازم است.**",
    "**یک — ضایعات در مراحل مختلف تکامل: ماکول و پاپول و وزیکول و پوستول و کراست، هم‌زمان.**",
    "⚠️ **این «چندمرحله‌ای بودن» مهم‌ترین نکته است و آبله‌مرغان را از آبله جدا می‌کند.**",
    "**در آبله (اسمال‌پاکس) همه‌ی ضایعات هم‌مرحله بودند؛ در آبله‌مرغان هرگز.**",
    "**دو — انتشار مرکزگرا: تنه بیشتر از اندام‌ها درگیر است، برخلاف آبله.**",
    "**سه — درگیری مخاط دهان، که در سؤال‌های این فصل بارها ذکر شده است.**",
    "**وزیکول کلاسیک آبله‌مرغان را «قطره‌ی شبنم روی گلبرگ گل رز» توصیف می‌کنند.**",
    "⚠️ **دوره‌ی سرایت: از ۲۴ تا ۴۸ ساعت پیش از راش تا خشک شدن کامل همه‌ی ضایعات.**",
    "**پس معیار پایان ایزولاسیون، کراست شدن ضایعات است، نه گذشت تعداد معینی روز.**",
    "**زونا همان ویروس است که از گانگلیون حسی دوباره فعال شده و یک درماتوم را می‌گیرد.**",
    "**درد سوزشی معمولاً چند روز پیش از ظهور وزیکول‌ها شروع می‌شود و گمراه‌کننده است.**",
    "⚠️ **و سندرم رامسی‌هانت: زونای گانگلیون زانویی — وزیکول در کانال گوش به‌علاوه‌ی فلج عصب هفتم.**",
    "**افتراقش از فلج بل همین وزیکول‌ها و درد شدید گوش است، و درمانش فوری‌تر.**",
    "**عوارض آبله‌مرغان در بالغ: پنومونی واریسلایی، آتاکسی مخچه‌ای، عفونت ثانویه‌ی پوستی.**",
    "**و آتاکسی مخچه‌ای پس از آبله‌مرغان، خودمحدودشونده است و درمان حمایتی می‌خواهد.**",
]
VZV_EN = [
    "WARNING: RECOGNISE CHICKENPOX BY ITS TRIAD, and all three parts are needed.",
    "ONE — lesions in DIFFERENT STAGES of evolution: macules, papules, vesicles, pustules and crusts together.",
    "WARNING, THIS SIMULTANEOUS MULTI-STAGE APPEARANCE is the key point and separates it from smallpox.",
    "In smallpox all lesions were at the SAME stage; in chickenpox never.",
    "TWO — a CENTRIPETAL distribution: the trunk more than the limbs, again unlike smallpox.",
    "THREE — involvement of the ORAL MUCOSA, mentioned repeatedly in this chapter's stems.",
    "The classic chickenpox vesicle is described as a DEWDROP ON A ROSE PETAL.",
    "WARNING, THE INFECTIOUS PERIOD: from 24 to 48 hours BEFORE the rash until every lesion has crusted.",
    "So the criterion for ending isolation is CRUSTING, not the passage of a fixed number of days.",
    "Zoster is the same virus reactivating from a sensory ganglion and occupying one dermatome.",
    "A burning pain usually begins days before the vesicles appear and is a classic source of misdiagnosis.",
    "WARNING, AND RAMSAY HUNT SYNDROME: zoster of the geniculate ganglion — ear-canal vesicles plus a seventh nerve palsy.",
    "What separates it from Bell's palsy is exactly those vesicles and the severe ear pain, and it is more urgent.",
    "Complications of chickenpox in adults: varicella pneumonia, cerebellar ataxia, secondary skin infection.",
    "And post-varicella cerebellar ataxia is self-limiting and needs only supportive care.",
]

# ===================================================== VZV POST-EXPOSURE
PEP_FA = [
    "⚠️ **چهار سؤال این فصل درباره‌ی پروفیلاکسی پس از تماس با آبله‌مرغان است و کلید همه آسیکلوویر خوراکی است.**",
    "**دانشجویی که «VZIG برای فرد پرخطر» را از منبع قدیمی حفظ کرده، این کلیدها را غلط می‌پندارد.**",
    "**ولی کلیدها با راهنمای امروز سازگارند، و دلیلش ارزش دانستن دارد.**",
    "⚠️ **یک کارآزمایی نشان داد زمان شروع آسیکلوویر تعیین‌کننده است، نه خودِ دارو.**",
    "**شروع فوری پس از تماس شکست خورد: ۱۰ نفر از ۱۳ نفر (۷۷٪) باز هم آبله‌مرغان گرفتند.**",
    "**ولی شروع از روز هفتم مؤثر بود: فقط ۳ نفر از ۱۴ نفر (۲۱٪) بیمار شدند.**",
    "⚠️ **چرا؟ چون آسیکلوویر باید در زمان اوج تکثیر ویروس حاضر باشد، نه پیش از آن.**",
    "**در روزهای اول ویروس هنوز در حال تکثیر نیست و دارو چیزی برای مهار کردن ندارد.**",
    "**پس رژیم استاندارد: آسیکلوویر خوراکی از روز ۷ تا روز ۱۴ پس از تماس.**",
    "**و UKHSA و RCOG آن را انتخاب اول برای زن باردار مستعد در هر سن بارداری کرده‌اند.**",
    "⚠️ **VZIG امروز فقط وقتی است که بیمار نتواند داروی خوراکی بخورد، یا در نوزاد پرخطر.**",
    "**و اگر VZIG داده شود، باید ظرف ۹۶ ساعت باشد و حداکثر تا ۱۰ روز پس از تماس.**",
    "**پنجره‌ی خطرناک نوزادی: تولد از ۵ روز پیش تا ۲ روز پس از شروع آبله‌مرغان مادر.**",
    "⚠️ **و زونای مادر برای نوزاد خطر آبله‌مرغان منتشر ندارد، چون مادر آنتی‌بادی دارد و آن را منتقل کرده است.**",
    "**واکسن آبله‌مرغان هم پس از تماس مؤثر است، ولی فقط در فرد ایمن‌سالم و ظرف ۳ تا ۵ روز.**",
    "**و در فرد با نقص ایمنی و در بارداری، واکسن زنده کنتراندیکه است.**",
]
PEP_EN = [
    "WARNING: FOUR QUESTIONS IN THIS CHAPTER ASK ABOUT VARICELLA POST-EXPOSURE PROPHYLAXIS, and all key ORAL ACICLOVIR.",
    "A student who memorised 'VZIG for the high-risk' from an older source will think these keys are wrong.",
    "But the keys agree with current guidance, and the reason is worth knowing.",
    "WARNING, A TRIAL SHOWED THAT THE TIMING OF ACICLOVIR IS DECISIVE, not the drug itself.",
    "Starting immediately after exposure FAILED: 10 of 13 (77 per cent) still developed varicella.",
    "But starting on DAY 7 WORKED: only 3 of 14 (21 per cent) became ill.",
    "WARNING, WHY? Because aciclovir must be present at the PEAK of viral replication, not before it.",
    "In the first days the virus is not yet replicating and the drug has nothing to inhibit.",
    "So the standard regimen is ORAL ACICLOVIR FROM DAY 7 TO DAY 14 after exposure.",
    "And UKHSA and the RCOG have made it the FIRST CHOICE for a susceptible pregnant woman at any gestation.",
    "WARNING, VZIG TODAY IS ONLY FOR THOSE WHO CANNOT TAKE ORAL DRUGS, or for a high-risk neonate.",
    "And if VZIG is given it should be within 96 hours, and at the latest within 10 days of exposure.",
    "The dangerous neonatal window: birth from 5 days before to 2 days after the onset of maternal chickenpox.",
    "WARNING, AND MATERNAL ZOSTER CARRIES NO RISK OF DISSEMINATED NEONATAL VARICELLA, because the mother has antibody and has passed it on.",
    "The varicella vaccine also works after exposure, but only in an immunocompetent person and within 3 to 5 days.",
    "And in immunodeficiency and in pregnancy a live vaccine is contraindicated.",
]

# ===================================================== MEASLES / RUBELLA / MUMPS
MMR_FA = [
    "⚠️ **سرخک را از مخاط بشناسید، نه از راش. لکه‌های کوپلیک تشخیصی‌اند و راش نیست.**",
    "**لکه‌های کوپلیک: نقاط سفید مایل به آبی روی مخاط گونه، در محاذات دندان آسیای دوم.**",
    "**آن‌ها ۱ تا ۲ روز پیش از راش ظاهر می‌شوند و ظرف ۲ روز محو می‌شوند — پنجره‌ی کوتاهی دارند.**",
    "⚠️ **و سه C پیش‌درآمد سرخک: سرفه، کوریزا، کونژنکتیویت — به‌علاوه‌ی تب بالا.**",
    "**راش سرخک ماکولوپاپولر و به‌هم‌پیوسته است و از پیشانی و پشت گوش شروع می‌شود.**",
    "**سپس به پایین گسترش می‌یابد و به همان ترتیب هم محو می‌شود، با پوسته‌ریزی قهوه‌ای.**",
    "⚠️ **شایع‌ترین عارضه‌ی سرخک اوتیت مدیای حاد است — شایع‌تر از پنومونی و بسیار شایع‌تر از انسفالیت.**",
    "**ولی شایع‌ترین علت مرگ، پنومونی است. «شایع‌ترین عارضه» با «کشنده‌ترین» فرق دارد.**",
    "**و ویتامین A تنها مداخله‌ای است که مرگ‌ومیر سرخک را کاهش می‌دهد.**",
    "**سرخجه: راش خفیف‌تر، تب کمتر، و لنفادنوپاتی پس‌گوشی و پس‌سری که مشخصه‌ی آن است.**",
    "⚠️ **خطر واقعی سرخجه برای جنین است، نه برای خود بیمار — سندرم سرخجه‌ی مادرزادی.**",
    "**و در بارداری، IgG مثبت با IgM منفی یعنی ایمنی قدیمی — یعنی خبر خوب و نیاز به هیچ اقدام.**",
    "**اوریون: تورم دردناک پاروتید، اغلب یک‌طرفه در شروع و سپس دوطرفه.**",
    "⚠️ **و دوره‌ی سرایت اوریون را با توصیه‌ی ایزولاسیون اشتباه نگیرید — این دو عدد متفاوت‌اند.**",
    "**ویروس از ۷ روز پیش تا ۹ روز پس از پاروتیت جدا شده است، و کتاب همین بازه را می‌پرسد.**",
    "**ولی توصیه‌ی عملی امروز ایزولاسیون تا ۵ روز پس از شروع پاروتیت است.**",
]
MMR_EN = [
    "WARNING: RECOGNISE MEASLES FROM THE MUCOSA, NOT THE RASH. Koplik spots are diagnostic and the rash is not.",
    "KOPLIK SPOTS: bluish-white dots on the buccal mucosa, opposite the second molars.",
    "They appear 1 to 2 days BEFORE the rash and fade within 2 days — a short window.",
    "WARNING, AND THE THREE Cs OF THE MEASLES PRODROME: cough, coryza, conjunctivitis — plus high fever.",
    "The measles rash is maculopapular and CONFLUENT, beginning on the forehead and behind the ears.",
    "It then spreads downwards and fades in the same order, with brownish desquamation.",
    "WARNING, THE COMMONEST COMPLICATION OF MEASLES IS ACUTE OTITIS MEDIA — commoner than pneumonia and far commoner than encephalitis.",
    "But the commonest CAUSE OF DEATH is pneumonia. 'Commonest complication' is not 'most lethal'.",
    "And vitamin A is the only intervention that reduces measles mortality.",
    "RUBELLA: a milder rash, less fever, and the characteristic POSTAURICULAR AND SUBOCCIPITAL lymphadenopathy.",
    "WARNING, RUBELLA'S REAL DANGER IS TO THE FETUS, not to the patient — congenital rubella syndrome.",
    "And in pregnancy, IgG positive with IgM negative means OLD IMMUNITY — good news, and no action needed.",
    "MUMPS: painful parotid swelling, often unilateral at onset and then bilateral.",
    "WARNING, AND DO NOT CONFUSE THE INFECTIOUS PERIOD WITH THE ISOLATION ADVICE — they are different numbers.",
    "Virus has been isolated from 7 days before to 9 days after parotitis, and the book asks about that interval.",
    "But today's practical advice is isolation until 5 days after parotitis onset.",
]

# ===================================================== HEPATITIS C
HCV_FA = [
    "⚠️ **هپاتیت C دو نشانگر دارد و باید بدانید هرکدام چه سؤالی را جواب می‌دهند.**",
    "**آنتی‌بادی ضد HCV: آیا تماس رخ داده است؟ ولی ۸ تا ۱۲ هفته طول می‌کشد تا مثبت شود.**",
    "**HCV RNA: آیا ویروس همین حالا در خون هست؟ و از ۱ تا ۲ هفته پس از تماس مثبت است.**",
    "⚠️ **پس در عفونت حاد و زودهنگام، آنتی‌بادی منفی است و فقط RNA جواب می‌دهد.**",
    "**همان منطق پنجره‌ای که در HIV یاد گرفتید، این‌بار در بیماری دیگری.**",
    "**و آنتی‌بادی مثبت به‌تنهایی عفونت فعال را ثابت نمی‌کند: در بهبودیافته هم مثبت می‌ماند.**",
    "**حدود ۱۵ تا ۲۵ درصد افراد ویروس را خودبه‌خود پاک می‌کنند ولی آنتی‌بادی‌شان مثبت می‌ماند.**",
    "⚠️ **پس هر آنتی‌بادی مثبت باید با RNA پیگیری شود تا عفونت فعال از عفونت گذشته جدا شود.**",
    "**RIBA یک تست تأییدی قدیمی برای آنتی‌بادی بود و امروز کاملاً کنار گذاشته شده است.**",
    "**چون RNA هم زودتر مثبت می‌شود و هم به سؤال مهم‌تری پاسخ می‌دهد: آیا ویروس فعال است؟**",
    "**و آنتی‌بادی ضد LKM در تابلوی هپاتیت، دو تفسیر دارد و باید هر دو را در نظر گرفت.**",
    "⚠️ **هپاتیت خودایمن تیپ ۲ آن را می‌سازد، ولی در هپاتیت C هم به‌طور غیراختصاصی مثبت می‌شود.**",
    "**پس پیش از تشخیص خودایمنی و شروع سرکوب ایمنی، باید عفونت ویروسی رد شود.**",
    "⚠️ **و این ترتیب حیاتی است: کورتیکواستروئید در هپاتیت C فعال، تکثیر ویروس را تشدید می‌کند.**",
]
HCV_EN = [
    "WARNING: HEPATITIS C HAS TWO MARKERS, and you must know which question each answers.",
    "ANTI-HCV ANTIBODY: has exposure occurred? But it takes 8 to 12 weeks to turn positive.",
    "HCV RNA: is the virus in the blood right now? And it is positive from 1 to 2 weeks after exposure.",
    "WARNING, SO IN EARLY ACUTE INFECTION THE ANTIBODY IS NEGATIVE and only RNA answers.",
    "The same window logic you learned in HIV, now in a different disease.",
    "And a positive antibody alone does not prove active infection: it stays positive after recovery too.",
    "About 15 to 25 per cent of people clear the virus spontaneously yet remain antibody positive.",
    "WARNING, SO EVERY POSITIVE ANTIBODY MUST BE FOLLOWED BY RNA to separate active from past infection.",
    "RIBA was an old confirmatory antibody test and has been abandoned entirely.",
    "Because RNA turns positive earlier AND answers the more important question: is the virus active?",
    "And an anti-LKM antibody in a hepatitis picture has two readings, both of which must be considered.",
    "WARNING, TYPE 2 AUTOIMMUNE HEPATITIS PRODUCES IT, but it also turns non-specifically positive in hepatitis C.",
    "So before diagnosing autoimmunity and starting immunosuppression, viral infection must be excluded.",
    "WARNING, AND THAT ORDER IS VITAL: corticosteroids in active hepatitis C accelerate viral replication.",
]


# =========================================================== MONONUCLEOSIS
add("book:597", "case", "easy",
 "«شدیدترین گلودرد عمرم» + **اگزودای خاکستری** + لنفادنوپاتی ژنرالیزه ← **اپشتین-بار**.",
 "'The worst sore throat of my life' with a GREY EXUDATE and generalised lymphadenopathy: EPSTEIN-BARR VIRUS.",
 MONO_FA + [
  "**دو سرنخ این سؤال را از فارنژیت استرپتوکوکی جدا می‌کنند.**",
  "⚠️ **یک — لنفادنوپاتی ژنرالیزه: استرپتوکوک فقط غدد گردنی قدامی را بزرگ می‌کند.**",
  "**لنفادنوپاتی منتشر یعنی یک عفونت سیستمیک، نه یک عفونت موضعی حلق.**",
  "**دو — شدت گلودرد: مونونوکلئوز به‌خاطر شدت بی‌سابقه‌اش شناخته می‌شود.**",
  "**و اگزودای خاکستری یا سفید ضخیم روی لوزه‌ها، در مونونوکلئوز شایع است.**",
 ],
 MONO_EN + [
  "Two clues separate this from streptococcal pharyngitis.",
  "WARNING, ONE — GENERALISED LYMPHADENOPATHY: streptococcus enlarges only the anterior cervical nodes.",
  "Widespread lymphadenopathy means a SYSTEMIC infection, not a localised throat infection.",
  "TWO — the severity: mononucleosis is known for an unprecedented degree of sore throat.",
  "And a grey or thick white tonsillar exudate is common in mononucleosis.",
 ],
 "**آقای ۲۰ ساله** با **تب، گلودرد و لنفادنوپاتی ژنرالیزه**، که می‌گوید "
 "**«شدیدترین گلودردی است که تاکنون تجربه کرده‌ام»**. در معاینه **اگزودای خاکستری** "
 "با تورم لوزه‌ها.\n\n"
 "⚠️ **پاسخ: ویروس اپشتین-بار. و دو سرنخ این را از استرپتوکوک جدا می‌کنند.**\n\n"
 "**سرنخ یک — لنفادنوپاتی ژنرالیزه.** ⚠️ **این تعیین‌کننده‌ترین یافته است.**\n\n"
 "**فارنژیت استرپتوکوکی یک عفونت موضعی حلق است، پس فقط غدد گردنی قدامی را بزرگ "
 "می‌کند.** ولی **لنفادنوپاتی منتشر** یعنی ویروس در **کل سیستم رتیکولواندوتلیال** "
 "پخش شده — یعنی یک **عفونت سیستمیک**. و EBV دقیقاً همین کار را می‌کند: سلول‌های B "
 "را در سراسر بدن آلوده می‌کند.\n\n"
 "**سرنخ دو — شدت بی‌سابقه‌ی گلودرد.** این توصیف بیمار تصادفی نیست. **مونونوکلئوز "
 "به‌خاطر شدت گلودردش شناخته می‌شود** و بیماران اغلب آن را بدترین گلودرد عمرشان "
 "توصیف می‌کنند.\n\n"
 "**و اگزودای خاکستری؟** در مونونوکلئوز اگزودای ضخیم سفید یا خاکستری روی لوزه‌ها "
 "شایع است و گاه به سختی از دیفتری افتراق داده می‌شود.\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**آدنوویروس** — فارنژیت می‌دهد، اغلب همراه با **کونژنکتیویت** (تب فارنگوکونژنکتیوال). "
 "ولی **لنفادنوپاتی ژنرالیزه** نمی‌دهد و شدتش معمولاً کمتر است.\n\n"
 "**استرپتوکوک گروه A** — ⚠️ نزدیک‌ترین رقیب و همان دامی که سؤال ساخته شده تا "
 "بگیردش. ولی **غدد قدامی و موضعی** می‌دهد، **طحال را بزرگ نمی‌کند**، و "
 "**لنفوسیت آتیپیک** نمی‌سازد.\n\n"
 "**نیسریا گنوره** — فارنژیت گنوکوکی وجود دارد (و در همین فصل سؤال دارد!) ولی "
 "معمولاً **بی‌علامت** است و **لنفادنوپاتی ژنرالیزه** نمی‌دهد. ضمناً متن **هیچ سابقه‌ی "
 "تماس جنسی** ذکر نکرده — و آن جمله همان چیزی است که در سؤال فارنژیت گنوکوکی "
 "حاضر بود.",
 "A 20-YEAR-OLD MAN with FEVER, SORE THROAT and GENERALISED LYMPHADENOPATHY, who says it is 'THE "
 "WORST SORE THROAT I HAVE EVER HAD'. On examination there is a GREY EXUDATE with tonsillar "
 "swelling.\n\n"
 "WARNING, THE ANSWER: EPSTEIN-BARR VIRUS. Two clues separate it from streptococcus.\n\n"
 "CLUE ONE — GENERALISED LYMPHADENOPATHY. WARNING, THE MOST DECISIVE FINDING.\n\n"
 "STREPTOCOCCAL PHARYNGITIS IS A LOCALISED THROAT INFECTION, so it enlarges only the anterior "
 "cervical nodes. But WIDESPREAD LYMPHADENOPATHY means the virus has spread through the whole "
 "RETICULOENDOTHELIAL SYSTEM — a SYSTEMIC infection. And that is exactly what EBV does: it infects "
 "B cells throughout the body.\n\n"
 "CLUE TWO — THE UNPRECEDENTED SEVERITY. The patient's description is not incidental. MONONUCLEOSIS "
 "IS KNOWN FOR THE SEVERITY OF ITS SORE THROAT, and patients often describe it as the worst of "
 "their lives.\n\n"
 "AND THE GREY EXUDATE? A thick white or grey tonsillar exudate is common in mononucleosis and is "
 "sometimes hard to distinguish from diphtheria.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "ADENOVIRUS — causes pharyngitis, often with CONJUNCTIVITIS (pharyngoconjunctival fever). But it "
 "does not cause GENERALISED LYMPHADENOPATHY and is usually less severe.\n\n"
 "GROUP A STREPTOCOCCUS — WARNING, the closest competitor and the very trap this question was built "
 "to catch. But it gives ANTERIOR, LOCALISED nodes, DOES NOT ENLARGE THE SPLEEN, and produces NO "
 "ATYPICAL LYMPHOCYTES.\n\n"
 "NEISSERIA GONORRHOEAE — gonococcal pharyngitis exists (and is examined elsewhere in this "
 "chapter), but it is usually ASYMPTOMATIC and does not cause GENERALISED LYMPHADENOPATHY. The stem "
 "also mentions NO SEXUAL HISTORY — and that sentence is exactly what was present in the gonococcal "
 "pharyngitis question.",
 ["پاسخ صحیح — لنفادنوپاتی ژنرالیزه یعنی عفونت سیستمیک، و شدت بی‌سابقه‌ی گلودرد امضای مونونوکلئوز است.",
  "آدنوویروس فارنژیت می‌دهد، اغلب با کونژنکتیویت، ولی لنفادنوپاتی ژنرالیزه نمی‌سازد.",
  "استرپتوکوک غدد گردنی قدامی و موضعی می‌دهد، نه لنفادنوپاتی منتشر.",
  "فارنژیت گنوکوکی معمولاً بی‌علامت است و متن هیچ سابقه‌ی تماس جنسی ذکر نکرده است."],
 ["Correct — generalised lymphadenopathy means a systemic infection, and the unprecedented severity is mononucleosis's signature.",
  "Adenovirus causes pharyngitis, often with conjunctivitis, but not generalised lymphadenopathy.",
  "Streptococcus gives localised anterior cervical nodes, not widespread lymphadenopathy.",
  "Gonococcal pharyngitis is usually asymptomatic and the stem mentions no sexual history."],
 "**لنفادنوپاتی ژنرالیزه = عفونت سیستمیک. استرپتوکوک فقط غدد قدامی می‌دهد.**",
 "Generalised lymphadenopathy means systemic infection; streptococcus gives only anterior nodes.",
 [REDBOOK, H])

add("book:599", "case", "medium",
 "غدد **بدون درد** + آنزیم کبدی بالا + شکست پنی‌سیلین ← مونونوکلئوز ← **درمان حمایتی**.",
 "PAINLESS nodes, raised transaminases and penicillin failure: mononucleosis, treated with SUPPORTIVE CARE.",
 MONO_FA + [
  "**این سؤال یک خطای چاپی در پنل آزمایشگاهی دارد که در درسنامه صریح گفته می‌شود.**",
  "⚠️ **پلاکت ۱٬۳۵۰٬۰۰۰ یک عدد انسانی نیست؛ محدوده‌ی طبیعی ۱۵۰ تا ۴۵۰ هزار است.**",
  "**عدد موردنظر تقریباً به‌قطع ۱۳۵٬۰۰۰ بوده، یعنی ترومبوسیتوپنی خفیف مونونوکلئوز.**",
  "**و این خطا پاسخ را عوض نمی‌کند، چون سؤال با تابلوی بالینی حل می‌شود.**",
  "**افزایش خفیف آنزیم‌های کبدی در مونونوکلئوز بسیار شایع است و در استرپتوکوک نیست.**",
  "⚠️ **و لنفادنوپاتی بدون درد یک سرنخ ظریف ولی مهم است.**",
  "**غدد استرپتوکوکی دردناک و حساس‌اند؛ غدد مونونوکلئوز اغلب کم‌درد یا بدون دردند.**",
 ],
 MONO_EN + [
  "This stem contains a misprint in the laboratory panel, stated openly in the lesson.",
  "WARNING: A PLATELET COUNT OF 1,350,000 IS NOT A HUMAN VALUE; the normal range is 150 to 450 thousand.",
  "The intended figure was almost certainly 135,000 — the mild thrombocytopenia of mononucleosis.",
  "And the error does not change the answer, because the question is settled by the clinical picture.",
  "A mild rise in transaminases is very common in mononucleosis and does not occur in streptococcus.",
  "WARNING, AND PAINLESS LYMPHADENOPATHY IS A SUBTLE BUT IMPORTANT CLUE.",
  "Streptococcal nodes are painful and tender; mononucleosis nodes are often minimally tender or painless.",
 ],
 "**پسر جوان** با **تب، لرز، ضعف، تعریق و فارنژیت اگزوداتیو از یک هفته قبل**، و در "
 "معاینه **آدنوپاتی سرویکال متعدد دوطرفه و بدون درد**. آزمایش‌ها: **لکوسیتوز ۱۵۰۰۰** "
 "و **افزایش خفیف آنزیم‌های کبدی**.\n\n"
 "⚠️ **پیش از هر چیز، یک خطای چاپی در کتاب: پلاکت این بیمار ۱٬۳۵۰٬۰۰۰ چاپ شده "
 "است، در حالی که محدوده‌ی طبیعی پلاکت ۱۵۰٬۰۰۰ تا ۴۵۰٬۰۰۰ است.**\n\n"
 "**عدد ۱٬۳۵۰٬۰۰۰ یک ترومبوسیتوز شدید است که در بیماری‌های میلوپرولیفراتیو دیده "
 "می‌شود — نه در یک بیماری خوش‌خیم.** هندسه‌ی گلیف نشان می‌دهد صفحه ۲۲۳ واقعاً همین "
 "را چاپ کرده، پس **متن ما وفادار است و خطا از کتاب است**. **عدد موردنظر تقریباً "
 "به‌قطع ۱۳۵٬۰۰۰ بوده** — یعنی **ترومبوسیتوپنی خفیف**، که دقیقاً همان چیزی است که "
 "مونونوکلئوز می‌سازد. **یک صفر اضافه.**\n\n"
 "**و خوشبختانه این پاسخ را عوض نمی‌کند. حالا به تشخیص برسیم:**\n\n"
 "**سه سرنخ به مونونوکلئوز اشاره می‌کنند:**\n\n"
 "⚠️ **۱) لنفادنوپاتی بدون درد.** این سرنخ ظریفی است که بسیاری از دست می‌دهند. "
 "**غدد استرپتوکوکی دردناک و حساس‌اند؛ غدد مونونوکلئوز اغلب کم‌درد یا بدون دردند.**\n\n"
 "**۲) افزایش آنزیم‌های کبدی.** ⚠️ **این یافته استرپتوکوک را عملاً رد می‌کند.** "
 "EBV یک **عفونت سیستمیک** است و **کبد را درگیر می‌کند** — افزایش خفیف "
 "ترانس‌آمینازها در **اکثریت** بیماران مونونوکلئوزی دیده می‌شود. فارنژیت استرپتوکوکی "
 "**هرگز** آنزیم کبدی را بالا نمی‌برد.\n\n"
 "**۳) سیر یک‌هفته‌ای با تعریق و ضعف.** فارنژیت استرپتوکوکی معمولاً ظرف **۳ تا ۵ "
 "روز** و با درمان سریع‌تر فروکش می‌کند.\n\n"
 "**پس پاسخ: درمان حمایتی، استراحت و مسکن.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**پنی‌سیلین G بنزاتین** — ⚠️ **خطرناک‌ترین گزینه، و دقیقاً همان دامی که این فصل "
 "بارها می‌آزماید.** پنی‌سیلین در مونونوکلئوز **بی‌فایده** است (چون ویروس است)، و "
 "اگر آمینوپنی‌سیلین باشد **راش وسیع** می‌سازد که به‌اشتباه **آلرژی** ثبت می‌شود.\n\n"
 "**آسیکلوویر خوراکی** — ⚠️ گزینه‌ی وسوسه‌انگیز، چون EBV یک هرپس‌ویروس است. ولی "
 "**آسیکلوویر بار ویروسی حلق را کم می‌کند و سیر بالینی را کوتاه نمی‌کند** — پس در "
 "مونونوکلئوز بدون عارضه **توصیه نمی‌شود**.\n\n"
 "**کلیندامایسین ۱۴ روز** — یک آنتی‌بیوتیک است و در بیماری **ویروسی** جایی ندارد.",
 "A YOUNG MAN with FEVER, CHILLS, WEAKNESS, SWEATS AND EXUDATIVE PHARYNGITIS FOR A WEEK, and on "
 "examination MULTIPLE BILATERAL PAINLESS CERVICAL NODES. Tests: LEUCOCYTOSIS 15000 and a MILD RISE "
 "IN TRANSAMINASES.\n\n"
 "WARNING, FIRST A MISPRINT IN THE BOOK: this patient's platelet count is printed as 1,350,000, "
 "whereas the NORMAL RANGE IS 150,000 TO 450,000.\n\n"
 "A value of 1,350,000 is EXTREME THROMBOCYTOSIS, seen in myeloproliferative disease — not in a "
 "benign illness. Glyph geometry shows page 223 really prints that, so OUR TEXT IS FAITHFUL AND THE "
 "ERROR IS THE BOOK'S. THE INTENDED FIGURE WAS ALMOST CERTAINLY 135,000 — a MILD THROMBOCYTOPENIA, "
 "exactly what mononucleosis produces. ONE EXTRA ZERO.\n\n"
 "Fortunately that does not change the answer. Now to the diagnosis:\n\n"
 "THREE CLUES POINT TO MONONUCLEOSIS:\n\n"
 "WARNING, 1) PAINLESS LYMPHADENOPATHY. A subtle clue many miss. STREPTOCOCCAL NODES ARE PAINFUL "
 "AND TENDER; MONONUCLEOSIS NODES ARE OFTEN MINIMALLY TENDER OR PAINLESS.\n\n"
 "2) RAISED TRANSAMINASES. WARNING, THIS FINDING PRACTICALLY EXCLUDES STREPTOCOCCUS. EBV is a "
 "SYSTEMIC infection that INVOLVES THE LIVER — a mild transaminase rise occurs in MOST patients "
 "with mononucleosis. Streptococcal pharyngitis NEVER raises liver enzymes.\n\n"
 "3) A ONE-WEEK COURSE with sweats and weakness. Streptococcal pharyngitis usually settles within 3 "
 "TO 5 DAYS, and faster with treatment.\n\n"
 "SO THE ANSWER IS SUPPORTIVE CARE, REST AND ANALGESIA.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "BENZATHINE PENICILLIN G — WARNING, THE MOST DANGEROUS OPTION, and precisely the trap this chapter "
 "tests repeatedly. Penicillin is USELESS in mononucleosis (it is a virus), and an aminopenicillin "
 "produces a FLORID RASH that gets wrongly recorded as an ALLERGY.\n\n"
 "ORAL ACICLOVIR — WARNING, a tempting option because EBV is a herpesvirus. But ACICLOVIR REDUCES "
 "PHARYNGEAL SHEDDING WITHOUT SHORTENING THE ILLNESS, so it is NOT RECOMMENDED in uncomplicated "
 "mononucleosis.\n\n"
 "CLINDAMYCIN FOR 14 DAYS — an antibiotic, with no place in a VIRAL illness.",
 ["پاسخ صحیح — غدد بدون درد، آنزیم کبدی بالا و سیر یک‌هفته‌ای، همگی مونونوکلئوز را نشان می‌دهند.",
  "خطرناک‌ترین گزینه — پنی‌سیلین در مونونوکلئوز بی‌فایده است و آمینوپنی‌سیلین راش وسیع می‌سازد.",
  "آسیکلوویر بار ویروسی حلق را کم می‌کند ولی سیر بالینی را کوتاه نمی‌کند، پس توصیه نمی‌شود.",
  "کلیندامایسین یک آنتی‌بیوتیک است و در بیماری ویروسی هیچ جایی ندارد."],
 ["Correct — painless nodes, raised transaminases and a one-week course all indicate mononucleosis.",
  "The most dangerous option — penicillin is useless in mononucleosis and an aminopenicillin causes a florid rash.",
  "Aciclovir reduces pharyngeal shedding but does not shorten the illness, so it is not recommended.",
  "Clindamycin is an antibiotic and has no place in a viral illness."],
 "**آنزیم کبدی بالا در فارنژیت = مونونوکلئوز. استرپتوکوک هرگز کبد را درگیر نمی‌کند.**",
 "Raised transaminases with pharyngitis means mononucleosis; streptococcus never involves the liver.",
 [REDBOOK, H])

add("book:600", "case", "easy",
 "لنفوسیت **۹۰ درصد** + طحال ملموس + شکست درمان قبلی ← مونونوکلئوز ← **فقط درمان حمایتی**.",
 "LYMPHOCYTES AT 90 PER CENT with a palpable spleen and previous treatment failure: mononucleosis, SUPPORTIVE CARE ONLY.",
 MONO_FA + [
  "**این سؤال قاطع‌ترین پنل آزمایشگاهی بلوک را دارد و نیازی به حدس نمی‌گذارد.**",
  "⚠️ **لنفوسیت ۹۰ درصد با نوتروفیل ۱۰ درصد، یک وارونگی کامل فرمول طبیعی است.**",
  "**در بالغ سالم نوتروفیل حدود ۶۰ درصد و لنفوسیت حدود ۳۰ درصد است.**",
  "**عفونت باکتریال این نسبت را به نفع نوتروفیل بیشتر می‌کند، نه برعکس.**",
  "⚠️ **پس غلبه‌ی شدید لنفوسیت یعنی عفونت ویروسی، و در این تابلو یعنی EBV.**",
  "**و طحال ملموس، استرپتوکوک را قطعاً کنار می‌گذارد.**",
  "**شکست درمان قبلی هم سرنخ سوم است: آنتی‌بیوتیک روی ویروس اثر ندارد.**",
 ],
 MONO_EN + [
  "This stem has the most decisive laboratory panel in the block and leaves nothing to guess.",
  "WARNING: 90 PER CENT LYMPHOCYTES WITH 10 PER CENT NEUTROPHILS is a complete inversion of the normal formula.",
  "In a healthy adult neutrophils are about 60 per cent and lymphocytes about 30 per cent.",
  "A bacterial infection shifts that further TOWARDS neutrophils, not away from them.",
  "WARNING, SO A MARKED LYMPHOCYTE PREDOMINANCE MEANS A VIRAL INFECTION, and in this picture EBV.",
  "And a palpable spleen definitively sets streptococcus aside.",
  "The failure of previous treatment is a third clue: antibiotics do nothing to a virus.",
 ],
 "**خانم ۱۹ ساله** از ۷ روز قبل با **تب، ضعف، بی‌حالی، میالژی، گلودرد و سردرد**. "
 "**یک بار به پزشک مراجعه کرده ولی بهبود نداشته است.** در معاینه **لوزه‌های بزرگ با "
 "اگزودای دوطرفه** و **طحال ملموس**. آزمایش: **WBC=14700 با PMN=10% و "
 "لنفوسیت=90%**.\n\n"
 "⚠️ **پاسخ: استراحت + تب‌بر + مایعات گرم. و این سؤال قاطع‌ترین پنل بلوک را دارد.**\n\n"
 "**سرنخ یک — و تعیین‌کننده‌ترین: فرمول شمارش افتراقی.**\n\n"
 "**در بالغ سالم: نوتروفیل حدود ۶۰ درصد، لنفوسیت حدود ۳۰ درصد.**\n\n"
 "**اینجا: نوتروفیل ۱۰ درصد، لنفوسیت ۹۰ درصد.** ⚠️ **این یک وارونگی کامل است.**\n\n"
 "**و منطقش را بفهمید:** عفونت **باکتریال** نوتروفیل‌ها را بسیج می‌کند، پس نسبت را "
 "**بیشتر به نفع نوتروفیل** می‌برد (مثلاً ۸۰ درصد). ⚠️ **غلبه‌ی شدید لنفوسیت دقیقاً "
 "خلاف آن است و یعنی عفونت ویروسی.** و در این تابلوی بالینی، یعنی **EBV**.\n\n"
 "**سرنخ دو — طحال ملموس.** ⚠️ **این استرپتوکوک را قطعاً کنار می‌گذارد.** طحال در "
 "بالغ سالم **لمس نمی‌شود**؛ برای ملموس شدن باید حدود **دو تا سه برابر** بزرگ شود. "
 "**فارنژیت استرپتوکوکی هرگز طحال را بزرگ نمی‌کند.**\n\n"
 "**سرنخ سه — شکست درمان قبلی.** بیمار **یک بار مراجعه کرده و بهبود نیافته**. اگر "
 "استرپتوکوک بود و آنتی‌بیوتیک گرفته بود، باید بهتر می‌شد.\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟ هر سه یک آنتی‌بیوتیک دارند، و همه در بیماری ویروسی "
 "بی‌فایده‌اند:**\n\n"
 "**آزیترومایسین** — ماکرولید، بی‌اثر بر ویروس.\n\n"
 "**اریترومایسین** — همان.\n\n"
 "**پنی‌سیلین بنزاتین** — ⚠️ **بدترین انتخاب**، و همان دامی که این فصل بارها "
 "می‌آزماید.\n\n"
 "⚠️ **و توصیه‌ای که سؤال نپرسیده ولی برای این بیمار حیاتی است: با طحال ملموس، "
 "باید از ورزش‌های برخوردی و بلند کردن اجسام سنگین تا ۳ تا ۴ هفته پرهیز کند** — چون "
 "**پارگی طحال** کشنده‌ترین عارضه‌ی مونونوکلئوز است.",
 "A 19-YEAR-OLD WOMAN, 7 days of FEVER, WEAKNESS, MALAISE, MYALGIA, SORE THROAT AND HEADACHE. SHE "
 "HAS SEEN A DOCTOR ONCE WITHOUT IMPROVEMENT. On examination, LARGE TONSILS WITH BILATERAL EXUDATE "
 "and a PALPABLE SPLEEN. Tests: WBC 14,700 with PMN 10% and LYMPHOCYTES 90%.\n\n"
 "WARNING, THE ANSWER: rest, antipyretics and warm fluids. This stem has the most decisive panel in "
 "the block.\n\n"
 "CLUE ONE — AND THE MOST DECISIVE: THE DIFFERENTIAL COUNT.\n\n"
 "In a healthy adult: neutrophils about 60 per cent, lymphocytes about 30 per cent.\n\n"
 "HERE: neutrophils 10 per cent, lymphocytes 90 per cent. WARNING, A COMPLETE INVERSION.\n\n"
 "AND UNDERSTAND THE LOGIC: a BACTERIAL infection mobilises neutrophils, pushing the ratio FURTHER "
 "TOWARDS neutrophils (say 80 per cent). WARNING, A MARKED LYMPHOCYTE PREDOMINANCE IS THE OPPOSITE "
 "AND MEANS A VIRAL INFECTION. In this clinical picture, EBV.\n\n"
 "CLUE TWO — A PALPABLE SPLEEN. WARNING, THIS DEFINITIVELY SETS STREPTOCOCCUS ASIDE. A healthy "
 "adult spleen is NOT PALPABLE; to become palpable it must roughly DOUBLE OR TRIPLE in size. "
 "STREPTOCOCCAL PHARYNGITIS NEVER ENLARGES THE SPLEEN.\n\n"
 "CLUE THREE — FAILURE OF PREVIOUS TREATMENT. She has SEEN A DOCTOR ONCE WITHOUT IMPROVING. Had "
 "this been streptococcus treated with an antibiotic, she should have improved.\n\n"
 "AND WHY NOT THE OTHER THREE? All three contain an antibiotic, and all are useless in a viral "
 "illness:\n\n"
 "AZITHROMYCIN — a macrolide, inactive against viruses.\n\n"
 "ERYTHROMYCIN — the same.\n\n"
 "BENZATHINE PENICILLIN — WARNING, THE WORST CHOICE, and the very trap this chapter tests "
 "repeatedly.\n\n"
 "WARNING, AND ADVICE THE QUESTION DOES NOT ASK BUT WHICH IS VITAL FOR THIS PATIENT: with a "
 "palpable spleen she must AVOID CONTACT SPORTS AND HEAVY LIFTING FOR 3 TO 4 WEEKS — because "
 "SPLENIC RUPTURE is the most lethal complication of mononucleosis.",
 ["آزیترومایسین یک ماکرولید است و بر ویروس اپشتین-بار هیچ اثری ندارد.",
  "اریترومایسین هم آنتی‌بیوتیک است و در بیماری ویروسی بی‌فایده است.",
  "بدترین انتخاب — پنی‌سیلین در مونونوکلئوز بی‌اثر است و می‌تواند راش وسیع بسازد.",
  "پاسخ صحیح — لنفوسیت ۹۰ درصد با طحال ملموس یعنی مونونوکلئوز، و درمانش حمایتی است."],
 ["Azithromycin is a macrolide and has no effect on Epstein-Barr virus.",
  "Erythromycin is likewise an antibiotic and useless in a viral illness.",
  "The worst choice — penicillin is ineffective in mononucleosis and can produce a florid rash.",
  "Correct — 90 per cent lymphocytes with a palpable spleen means mononucleosis, treated supportively."],
 "**وارونگی فرمول به نفع لنفوسیت = ویروس. باکتری نوتروفیل را بالا می‌برد.**",
 "An inverted differential favouring lymphocytes means a virus; bacteria raise the neutrophils.",
 [REDBOOK, H])


# =========================================================== VARICELLA
add("book:612", "case", "medium",
 "آبله‌مرغان در **بالغ** ← آسیکلوویر خوراکی، چون بالغ‌ها عوارض بسیار بیشتری می‌گیرند.",
 "Chickenpox in an ADULT needs oral aciclovir, because adults suffer far more complications.",
 VZV_FA + [
  "**در کودک سالم، آبله‌مرغان معمولاً خودمحدودشونده است و درمان ضدویروسی روتین نیست.**",
  "⚠️ **ولی در بالغ داستان کاملاً فرق می‌کند، و همین پاسخ این سؤال است.**",
  "**خطر پنومونی واریسلایی در بالغ بسیار بیشتر است و مرگ‌ومیر قابل توجهی دارد.**",
  "**و مرگ‌ومیر آبله‌مرغان در بالغ ده‌ها برابر کودک است.**",
  "**پس آسیکلوویر خوراکی برای هر بالغ با آبله‌مرغان توصیه می‌شود.**",
  "⚠️ **و شرط اثربخشی: شروع ظرف ۲۴ ساعت از ظهور راش.**",
  "**در این بیمار راش از دیروز شروع شده، پس هنوز در پنجره‌ی مؤثر است.**",
  "**درمان سیر بیماری را کوتاه می‌کند و تعداد ضایعات را کم می‌کند.**",
 ],
 VZV_EN + [
  "In a healthy child chickenpox is usually self-limiting and antiviral treatment is not routine.",
  "WARNING, BUT IN AN ADULT THE STORY IS ENTIRELY DIFFERENT, and that is this question's answer.",
  "The risk of varicella pneumonia is far higher in adults and carries appreciable mortality.",
  "And chickenpox mortality in adults is tens of times that in children.",
  "So oral aciclovir is recommended for any adult with chickenpox.",
  "WARNING, AND THE CONDITION FOR EFFICACY: starting within 24 hours of the rash appearing.",
  "In this patient the rash began yesterday, so he is still inside the effective window.",
  "Treatment shortens the illness and reduces the number of lesions.",
 ],
 "**جوان ۲۰ ساله** با **تب و گلودرد از ۲ روز پیش**، و **از دیروز** ضایعات "
 "**ماکولوپاپولر و وزیکولر روی زمینه‌ی اریتماتو** روی صورت و تنه، به‌همراه "
 "**ضایعات مخاط دهان**.\n\n"
 "**تشخیص روشن است: آبله‌مرغان.** سه‌گانه کامل است — ضایعات در **مراحل مختلف** "
 "(ماکولوپاپولر و وزیکولر با هم)، انتشار **مرکزگرا** (صورت و تنه)، و **درگیری "
 "مخاط دهان**.\n\n"
 "⚠️ **ولی سؤال تشخیص را نمی‌پرسد — درمان را می‌پرسد. و اینجا سن بیمار همه‌چیز "
 "است.**\n\n"
 "**در کودک سالم، آبله‌مرغان معمولاً خودمحدودشونده است و آسیکلوویر روتین نیست.**\n\n"
 "⚠️ **ولی این بیمار ۲۰ ساله است — یک بالغ. و در بالغ داستان کاملاً فرق می‌کند:**\n\n"
 "**۱) پنومونی واریسلایی** — جدی‌ترین عارضه، که در **بالغ بسیار شایع‌تر** است و "
 "مرگ‌ومیر قابل توجهی دارد. سیگاری‌ها و باردارها بیشترین خطر را دارند.\n\n"
 "**۲) مرگ‌ومیر کلی** — آبله‌مرغان در بالغ **ده‌ها برابر** کودک کشنده است.\n\n"
 "**۳) شدت بیشتر** — تعداد ضایعات بیشتر، تب بالاتر، بهبود کندتر.\n\n"
 "**پس آسیکلوویر خوراکی برای هر بالغ با آبله‌مرغان توصیه می‌شود.**\n\n"
 "⚠️ **و شرط اثربخشی حیاتی است: شروع ظرف ۲۴ ساعت از ظهور راش.** پس از آن، "
 "تکثیر ویروس به اوج رسیده و دارو سود کمی دارد. **در این بیمار راش از دیروز شروع "
 "شده — یعنی هنوز در پنجره‌ی مؤثر است.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**تنها آنتی‌هیستامین** — خارش را کم می‌کند و **بخشی از درمان حمایتی است**، ولی "
 "**در بالغ کافی نیست**. این گزینه برای **کودک سالم** درست بود.\n\n"
 "**سفالکسین ۱۰ روز** — آنتی‌بیوتیک، و بیماری **ویروسی** است. (سفالکسین فقط اگر "
 "**عفونت ثانویه‌ی باکتریایی** رخ دهد اندیکاسیون دارد.)\n\n"
 "**بیوپسی از ضایعات** — ⚠️ تشخیص **کاملاً بالینی** است و بیوپسی **تهاجمی و "
 "غیرضروری** است. اگر تأیید آزمایشگاهی لازم باشد، **PCR از مایع وزیکول** روش انتخابی "
 "است، نه بیوپسی.",
 "A 20-YEAR-OLD MAN with FEVER AND SORE THROAT FOR 2 DAYS and, SINCE YESTERDAY, MACULOPAPULAR AND "
 "VESICULAR LESIONS ON AN ERYTHEMATOUS BASE on the face and trunk, with ORAL MUCOSAL LESIONS.\n\n"
 "THE DIAGNOSIS IS CLEAR: CHICKENPOX. The triad is complete — lesions in DIFFERENT STAGES "
 "(maculopapular and vesicular together), a CENTRIPETAL distribution (face and trunk), and ORAL "
 "MUCOSAL INVOLVEMENT.\n\n"
 "WARNING, BUT THE STEM DOES NOT ASK THE DIAGNOSIS — IT ASKS THE TREATMENT. And here the patient's "
 "AGE is everything.\n\n"
 "IN A HEALTHY CHILD chickenpox is usually self-limiting and aciclovir is not routine.\n\n"
 "WARNING, BUT THIS PATIENT IS 20 — AN ADULT. And in adults the story is entirely different:\n\n"
 "1) VARICELLA PNEUMONIA — the most serious complication, FAR COMMONER IN ADULTS and carrying "
 "appreciable mortality. Smokers and pregnant women are at greatest risk.\n\n"
 "2) OVERALL MORTALITY — chickenpox in adults is TENS OF TIMES more lethal than in children.\n\n"
 "3) GREATER SEVERITY — more lesions, higher fever, slower recovery.\n\n"
 "SO ORAL ACICLOVIR IS RECOMMENDED FOR ANY ADULT WITH CHICKENPOX.\n\n"
 "WARNING, AND THE CONDITION FOR EFFICACY IS VITAL: START WITHIN 24 HOURS OF THE RASH. After that "
 "viral replication has peaked and the drug adds little. IN THIS PATIENT THE RASH BEGAN YESTERDAY — "
 "he is still inside the effective window.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "ANTIHISTAMINE ALONE — it reduces itch and IS PART OF SUPPORTIVE CARE, but IS NOT ENOUGH IN AN "
 "ADULT. This option would have been right for a HEALTHY CHILD.\n\n"
 "CEPHALEXIN FOR 10 DAYS — an antibiotic, and this is a VIRAL illness. (Cephalexin is indicated "
 "only if SECONDARY BACTERIAL INFECTION develops.)\n\n"
 "BIOPSY OF THE LESIONS — WARNING, the diagnosis is ENTIRELY CLINICAL and biopsy is INVASIVE AND "
 "UNNECESSARY. If laboratory confirmation were needed, PCR OF VESICLE FLUID is the method of "
 "choice, not biopsy.",
 ["آنتی‌هیستامین بخشی از درمان حمایتی است ولی در بالغ به‌تنهایی کافی نیست.",
  "پاسخ صحیح — آبله‌مرغان در بالغ عوارض جدی دارد و آسیکلوویر ظرف ۲۴ ساعت اول توصیه می‌شود.",
  "سفالکسین آنتی‌بیوتیک است و فقط در صورت عفونت ثانویه‌ی باکتریایی اندیکاسیون دارد.",
  "تشخیص کاملاً بالینی است؛ بیوپسی تهاجمی و غیرضروری است و روش تأیید PCR مایع وزیکول است."],
 ["An antihistamine is part of supportive care but is not sufficient alone in an adult.",
  "Correct — chickenpox in adults carries serious complications and aciclovir is advised within the first 24 hours.",
  "Cephalexin is an antibiotic and is indicated only if secondary bacterial infection develops.",
  "The diagnosis is entirely clinical; biopsy is invasive and unnecessary, and PCR of vesicle fluid is the confirmatory method."],
 "**آبله‌مرغان در کودک خودمحدود است؛ در بالغ آسیکلوویر ظرف ۲۴ ساعت.**",
 "Chickenpox is self-limiting in a child; in an adult, aciclovir within 24 hours.",
 [REDBOOK, H])

add("book:614", "recall", "easy",
 "ضایعات **هم‌زمان** ماکول و پاپول و وزیکول و پوستول ← **آبله‌مرغان**، و فقط آبله‌مرغان.",
 "Macules, papules, vesicles and pustules ALL AT ONCE means CHICKENPOX, and only chickenpox.",
 VZV_FA + [
  "**این سؤال کوتاه‌ترین و ناب‌ترین شکل مفهوم چندمرحله‌ای بودن است.**",
  "⚠️ **هیچ‌کدام از سه بیماری دیگر ضایعه‌ی وزیکولر نمی‌سازند.**",
  "**راش سرخک ماکولوپاپولر است و هرگز وزیکولی نمی‌شود.**",
  "**راش سرخجه هم ماکولوپاپولر و خفیف‌تر است، بدون وزیکول.**",
  "**و روزئولا راش ماکولر صورتی است که پس از قطع تب ظاهر می‌شود.**",
  "**پس همین که کلمه‌ی وزیکول در متن بیاید، سه گزینه یک‌جا حذف می‌شوند.**",
 ],
 VZV_EN + [
  "This is the shortest and purest form of the multi-stage concept.",
  "WARNING: NONE OF THE OTHER THREE DISEASES PRODUCES A VESICULAR LESION.",
  "The measles rash is maculopapular and never becomes vesicular.",
  "The rubella rash is also maculopapular and milder, without vesicles.",
  "And roseola is a pink macular rash appearing AFTER the fever breaks.",
  "So the moment the word 'vesicle' appears in a stem, three options vanish at once.",
 ],
 "**آقای ۲۵ ساله** با **تب** و ضایعات پوستی به اشکال **ماکول، پاپول، وزیکول و "
 "پوستول**.\n\n"
 "⚠️ **پاسخ: آبله‌مرغان. و این کوتاه‌ترین و ناب‌ترین شکل مفهوم «چندمرحله‌ای بودن» "
 "است.**\n\n"
 "**متن چهار نوع ضایعه را هم‌زمان فهرست کرده: ماکول، پاپول، وزیکول، پوستول.** این "
 "دقیقاً همان چیزی است که آبله‌مرغان را تعریف می‌کند.\n\n"
 "**چرا این‌قدر مشخصه است؟** چون در آبله‌مرغان ویروس **موج به موج** پوست را درگیر "
 "می‌کند. هر موج جدید ضایعات تازه می‌سازد، در حالی که موج قبلی هنوز در حال تکامل "
 "است. **نتیجه: در یک لحظه، ضایعات در همه‌ی مراحل کنار هم دیده می‌شوند.**\n\n"
 "⚠️ **و این دقیقاً همان چیزی است که آبله‌مرغان را از آبله (اسمال‌پاکس) جدا می‌کرد — "
 "افتراقی که زمانی مرگ و زندگی بود.** در آبله، **همه‌ی ضایعات هم‌مرحله** بودند، "
 "چون ویروس در یک موج واحد پخش می‌شد.\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟ همه یک اشکال مشترک دارند: هیچ‌کدام وزیکول نمی‌سازند.**\n\n"
 "**سرخک** — راش **ماکولوپاپولر و به‌هم‌پیوسته**، از پیشانی به پایین. **هرگز وزیکولی "
 "نمی‌شود.** و پیش از راش، **سه C** (سرفه، کوریزا، کونژنکتیویت) و **لکه‌های کوپلیک** "
 "دارد که هیچ‌کدام در این متن نیست.\n\n"
 "**سرخجه** — راش **ماکولوپاپولر خفیف‌تر** و پراکنده‌تر، با **لنفادنوپاتی پس‌گوشی**. "
 "**بدون وزیکول.**\n\n"
 "**روزئولا** — ⚠️ الگوی زمانی‌اش کاملاً متفاوت است: **تب بالای سه روزه که ناگهان "
 "قطع می‌شود، و سپس راش ماکولر صورتی ظاهر می‌شود.** یعنی **راش پس از قطع تب** — در "
 "حالی که این بیمار **هم‌زمان تب و راش** دارد. ضمناً روزئولا بیماری **شیرخواران** "
 "است، نه بالغ ۲۵ ساله.",
 "A 25-YEAR-OLD MAN with FEVER and skin lesions in the form of MACULES, PAPULES, VESICLES AND "
 "PUSTULES.\n\n"
 "WARNING, THE ANSWER: CHICKENPOX. And this is the shortest, purest form of the MULTI-STAGE "
 "concept.\n\n"
 "The stem lists four lesion types simultaneously: macule, papule, vesicle, pustule. That is "
 "precisely what defines chickenpox.\n\n"
 "WHY IS IT SO CHARACTERISTIC? Because in chickenpox the virus seeds the skin IN SUCCESSIVE WAVES. "
 "Each new wave creates fresh lesions while the previous wave is still evolving. THE RESULT: at any "
 "one moment, lesions at every stage are seen side by side.\n\n"
 "WARNING, AND THAT IS EXACTLY WHAT SEPARATED CHICKENPOX FROM SMALLPOX — a distinction that was "
 "once a matter of life and death. In smallpox ALL LESIONS WERE AT THE SAME STAGE, because the "
 "virus seeded in a single wave.\n\n"
 "AND WHY NOT THE OTHER THREE? All share one flaw: NONE PRODUCES VESICLES.\n\n"
 "MEASLES — a MACULOPAPULAR, CONFLUENT rash spreading from the forehead downwards. IT NEVER BECOMES "
 "VESICULAR. And before the rash come the THREE Cs (cough, coryza, conjunctivitis) and KOPLIK "
 "SPOTS, none of which is in this stem.\n\n"
 "RUBELLA — a MILDER, more discrete MACULOPAPULAR rash with POSTAURICULAR lymphadenopathy. NO "
 "VESICLES.\n\n"
 "ROSEOLA — WARNING, its time pattern is entirely different: THREE DAYS OF HIGH FEVER THAT BREAKS "
 "ABRUPTLY, AND THEN a pink macular rash appears. That is a rash AFTER the fever ends — whereas "
 "this patient has FEVER AND RASH TOGETHER. Roseola is also a disease of INFANTS, not of a "
 "25-year-old.",
 ["پاسخ صحیح — ضایعات هم‌زمان در مراحل مختلف، تعریف آبله‌مرغان است و آن را از آبله جدا می‌کرد.",
  "راش سرخک ماکولوپاپولر و به‌هم‌پیوسته است و هرگز وزیکولی نمی‌شود.",
  "راش سرخجه ماکولوپاپولر خفیف است، بدون وزیکول، و با لنفادنوپاتی پس‌گوشی همراه است.",
  "در روزئولا راش پس از قطع تب ظاهر می‌شود و بیماری شیرخواران است، نه بالغ."],
 ["Correct — lesions at different stages simultaneously define chickenpox and once separated it from smallpox.",
  "The measles rash is maculopapular and confluent and never becomes vesicular.",
  "The rubella rash is a mild maculopapular one without vesicles, with postauricular lymphadenopathy.",
  "In roseola the rash appears after the fever breaks, and it is a disease of infants, not adults."],
 "**ضایعات هم‌مرحله = آبله. ضایعات چندمرحله‌ای = آبله‌مرغان.**",
 "Lesions all at one stage meant smallpox; lesions at many stages mean chickenpox.",
 [REDBOOK, H])

add("book:619", "recall", "medium",
 "میان عوارض آبله‌مرغان، **هپاتیت علامت‌دار** کمتر از همه محتمل است.",
 "Among the complications of chickenpox, SYMPTOMATIC HEPATITIS is the least likely.",
 VZV_FA + [
  "**سه گزینه‌ی دیگر عوارض شناخته‌شده و نسبتاً شایع آبله‌مرغان‌اند.**",
  "⚠️ **شایع‌ترین عارضه‌ی آبله‌مرغان در کودک، عفونت ثانویه‌ی باکتریایی پوست است.**",
  "**چون خاراندن ضایعات، راه ورود استافیلوکوک و استرپتوکوک را باز می‌کند.**",
  "**عوارض عصبی هم شناخته‌شده‌اند: آتاکسی مخچه‌ای حاد و انسفالیت.**",
  "**و آتاکسی مخچه‌ای شایع‌ترین عارضه‌ی عصبی است و خودمحدودشونده.**",
  "**پنومونی هم رخ می‌دهد، هرچند در کودک بسیار کمتر از بالغ.**",
  "⚠️ **ولی افزایش خفیف و بی‌علامت آنزیم‌های کبدی شایع است — هپاتیت علامت‌دار نه.**",
  "**پس تفاوت میان «اختلال آزمایشگاهی» و «بیماری بالینی» همان چیزی است که سؤال می‌آزماید.**",
 ],
 VZV_EN + [
  "The other three are recognised and relatively common complications of chickenpox.",
  "WARNING: THE COMMONEST COMPLICATION IN A CHILD IS SECONDARY BACTERIAL SKIN INFECTION.",
  "Because scratching the lesions opens a route for staphylococci and streptococci.",
  "Neurological complications are also recognised: acute cerebellar ataxia and encephalitis.",
  "And cerebellar ataxia is the commonest neurological complication, and self-limiting.",
  "Pneumonia occurs too, though far less often in children than in adults.",
  "WARNING, BUT A MILD ASYMPTOMATIC RISE IN LIVER ENZYMES IS COMMON — symptomatic hepatitis is not.",
  "So the difference between a LABORATORY ABNORMALITY and a CLINICAL DISEASE is what this question tests.",
 ],
 "**دانش‌آموزی** با تب و ضایعات **ماکولوپاپولی و وزیکولی در مراحل مختلف** به اندازه‌ی "
 "**۵ تا ۱۰ میلی‌متر** در تنه، صورت و مخاط دهان. سؤال می‌پرسد کدام عارضه **کمتر "
 "محتمل** است.\n\n"
 "**تشخیص روشن است: آبله‌مرغان.** حالا عوارض را بسنجیم.\n\n"
 "⚠️ **پاسخ: هپاتیت علامت‌دار — و ظرافت سؤال دقیقاً در کلمه‌ی «علامت‌دار» است.**\n\n"
 "**بیایید سه گزینه‌ی دیگر را ببینیم:**\n\n"
 "**عفونت ثانویه‌ی پوست** ✅ — ⚠️ **شایع‌ترین عارضه‌ی آبله‌مرغان در کودک.** ضایعات "
 "**به‌شدت خارش‌دارند**، کودک می‌خاراند، و **استافیلوکوک اورئوس و استرپتوکوک گروه A** "
 "وارد می‌شوند. از ایمپتیگوی ساده تا سلولیت و به‌ندرت فاشئیت نکروزان.\n\n"
 "**عوارض عصبی** ✅ — شناخته‌شده و در کتاب‌ها فهرست شده. **آتاکسی مخچه‌ای حاد** "
 "شایع‌ترین آن‌هاست (حدود ۱ در ۴۰۰۰ کودک) و **خودمحدودشونده** است. **انسفالیت** "
 "نادرتر ولی جدی‌تر است.\n\n"
 "**پنومونی** ✅ — رخ می‌دهد. در **کودک نادر** است ولی در **بالغ، سیگاری و باردار** "
 "شایع و خطرناک.\n\n"
 "⚠️ **و حالا هپاتیت: اینجا یک تمایز ظریف ولی مهم وجود دارد.**\n\n"
 "**افزایش خفیف و گذرای آنزیم‌های کبدی در آبله‌مرغان نسبتاً شایع است** — اگر آزمایش "
 "بگیرید، ممکن است ALT کمی بالا باشد. **ولی هپاتیت علامت‌دار** — یعنی زردی، درد "
 "شکم، نارسایی کبد — **بسیار نادر** است.\n\n"
 "**پس سؤال تفاوت میان «اختلال آزمایشگاهی» و «بیماری بالینی» را می‌آزماید.** و کلمه‌ی "
 "**«علامت‌دار»** همان چیزی است که گزینه را به پاسخ تبدیل می‌کند.\n\n"
 "⚠️ **و یک نکته‌ی مهم که ورای سؤال است: سندرم ری.** در گذشته، دادن **آسپیرین** به "
 "کودک مبتلا به آبله‌مرغان یا آنفلوانزا باعث **سندرم ری** می‌شد — یک انسفالوپاتی "
 "همراه با **کبد چرب** و مرگ‌ومیر بالا. **به همین دلیل آسپیرین در کودکان با بیماری "
 "ویروسی ممنوع است.** این تنها راهی است که «کبد» و «آبله‌مرغان» به‌طور جدی به هم "
 "مربوط می‌شوند.",
 "A SCHOOLCHILD with fever and MACULOPAPULAR AND VESICULAR LESIONS AT DIFFERENT STAGES, 5 TO 10 MM "
 "in size, on the trunk, face and oral mucosa. The stem asks which complication is LEAST LIKELY.\n\n"
 "THE DIAGNOSIS IS CLEAR: CHICKENPOX. Now weigh the complications.\n\n"
 "WARNING, THE ANSWER: SYMPTOMATIC HEPATITIS — and the subtlety lies precisely in the word "
 "'SYMPTOMATIC'.\n\n"
 "LOOK AT THE OTHER THREE:\n\n"
 "SECONDARY SKIN INFECTION — WARNING, THE COMMONEST COMPLICATION OF CHICKENPOX IN A CHILD. The "
 "lesions ITCH INTENSELY, the child scratches, and STAPHYLOCOCCUS AUREUS AND GROUP A STREPTOCOCCUS "
 "enter. From simple impetigo to cellulitis and rarely necrotising fasciitis.\n\n"
 "NEUROLOGICAL COMPLICATIONS — recognised and listed in the textbooks. ACUTE CEREBELLAR ATAXIA is "
 "the commonest (about 1 in 4000 children) and is SELF-LIMITING. ENCEPHALITIS is rarer but more "
 "serious.\n\n"
 "PNEUMONIA — it occurs. RARE IN CHILDREN but common and dangerous in ADULTS, SMOKERS AND PREGNANT "
 "WOMEN.\n\n"
 "WARNING, AND NOW HEPATITIS: here lies a subtle but important distinction.\n\n"
 "A MILD, TRANSIENT RISE IN LIVER ENZYMES IS FAIRLY COMMON in chickenpox — take bloods and the ALT "
 "may be slightly up. BUT SYMPTOMATIC HEPATITIS — jaundice, abdominal pain, liver failure — IS VERY "
 "RARE.\n\n"
 "SO THE QUESTION TESTS THE DIFFERENCE BETWEEN A LABORATORY ABNORMALITY AND A CLINICAL DISEASE. And "
 "the word 'SYMPTOMATIC' is what turns the option into the answer.\n\n"
 "WARNING, AND ONE IMPORTANT POINT BEYOND THE QUESTION: REYE SYNDROME. Historically, giving ASPIRIN "
 "to a child with chickenpox or influenza caused REYE SYNDROME — an encephalopathy with FATTY LIVER "
 "and high mortality. THAT IS WHY ASPIRIN IS FORBIDDEN IN CHILDREN WITH VIRAL ILLNESS. It is the "
 "only way in which 'liver' and 'chickenpox' are seriously connected.",
 ["عوارض عصبی شناخته‌شده‌اند؛ آتاکسی مخچه‌ای شایع‌ترین آن‌هاست و انسفالیت نادرتر ولی جدی‌تر.",
  "عفونت ثانویه‌ی پوست شایع‌ترین عارضه‌ی آبله‌مرغان در کودک است، به‌دلیل خاراندن ضایعات.",
  "پاسخ صحیح — افزایش خفیف آنزیم کبدی شایع است، ولی هپاتیت علامت‌دار بسیار نادر است.",
  "پنومونی رخ می‌دهد؛ در کودک نادر است ولی در بالغ و باردار شایع و خطرناک."],
 ["Neurological complications are recognised; cerebellar ataxia is the commonest and encephalitis rarer but graver.",
  "Secondary skin infection is the commonest complication in a child, because the lesions are scratched.",
  "Correct — a mild enzyme rise is common, but symptomatic hepatitis is very rare.",
  "Pneumonia occurs; it is rare in children but common and dangerous in adults and in pregnancy."],
 "**اختلال آزمایشگاهی با بیماری بالینی یکی نیست — و کلمه‌ی «علامت‌دار» همین را می‌گوید.**",
 "A laboratory abnormality is not a clinical disease — and the word 'symptomatic' says exactly that.",
 [REDBOOK, H])

add("book:622", "case", "medium",
 "آتاکسی **سه هفته پس از** آبله‌مرغان ← آتاکسی مخچه‌ای پس‌عفونی ← **درمان حمایتی**.",
 "Ataxia THREE WEEKS AFTER chickenpox is post-infectious cerebellar ataxia: SUPPORTIVE CARE.",
 VZV_FA + [
  "**فاصله‌ی زمانی در این سؤال همه‌چیز را تعیین می‌کند و عمداً ذکر شده است.**",
  "⚠️ **سه هفته پس از بهبود ضایعات، یعنی ویروس دیگر در حال تکثیر نیست.**",
  "**پس این یک عفونت فعال نیست — یک واکنش ایمنی پس‌عفونی است.**",
  "**بدن علیه ویروس آنتی‌بادی ساخته، و آن آنتی‌بادی‌ها با بافت مخچه واکنش متقاطع می‌دهند.**",
  "**همین منطق در سندرم گیلن-باره و ADEM هم حاکم است.**",
  "⚠️ **و نتیجه‌ی درمانی: داروی ضدویروسی بی‌فایده است، چون ویروسی برای کشتن نمانده.**",
  "**آتاکسی مخچه‌ای پس از آبله‌مرغان شایع‌ترین عارضه‌ی عصبی آن است.**",
  "**سیر آن خوش‌خیم و خودمحدودشونده است و معمولاً ظرف ۲ تا ۴ هفته کامل بهبود می‌یابد.**",
  "**پس درمان حمایتی و اطمینان‌بخشی به خانواده کافی است.**",
 ],
 VZV_EN + [
  "The time interval decides everything here and is mentioned deliberately.",
  "WARNING: THREE WEEKS AFTER THE LESIONS HEALED, the virus is no longer replicating.",
  "So this is not an active infection — it is a POST-INFECTIOUS IMMUNE reaction.",
  "The body made antibody against the virus, and that antibody cross-reacts with cerebellar tissue.",
  "The same logic governs Guillain-Barre syndrome and ADEM.",
  "WARNING, AND THE THERAPEUTIC CONSEQUENCE: an antiviral is useless, because no virus remains to kill.",
  "Post-varicella cerebellar ataxia is its commonest neurological complication.",
  "Its course is benign and self-limiting, usually resolving completely within 2 to 4 weeks.",
  "So supportive care and reassurance of the family suffice.",
 ],
 "**دختربچه‌ی ۸ ساله** که آبله‌مرغان گرفت (ضایعات ماکولوپاپولر و وزیکولی در مراحل "
 "مختلف)، **ضایعات بهبود یافتند**، ولی **حدود سه هفته بعد** دچار **تهوع، اختلال "
 "تعادل و راه رفتن** شد.\n\n"
 "⚠️ **پاسخ: درمان حمایتی. و کلید فهم این سؤال، فاصله‌ی زمانی است.**\n\n"
 "**«سه هفته بعد» تصادفی نیست — طراح آن را گذاشته تا کل ماهیت بیماری را روشن "
 "کند.**\n\n"
 "**بیایید فکر کنیم:** ضایعات **بهبود یافته‌اند** و **سه هفته** گذشته. ⚠️ **یعنی "
 "ویروس دیگر در حال تکثیر نیست.** پس آنچه حالا رخ داده **نمی‌تواند تهاجم مستقیم "
 "ویروس باشد**.\n\n"
 "**پس چیست؟ یک واکنش ایمنی پس‌عفونی.**\n\n"
 "**سازوکارش زیباست:** بدن برای مبارزه با ویروس **آنتی‌بادی** ساخته است. برخی از آن "
 "آنتی‌بادی‌ها، به‌طور تصادفی، با **پروتئین‌های بافت مخچه** هم **واکنش متقاطع** "
 "می‌دهند. نتیجه: **التهاب خودایمن مخچه**.\n\n"
 "**و همین منطق در چند بیماری دیگر هم حاکم است:** **سندرم گیلن-باره** (پس از "
 "کامپیلوباکتر)، **ADEM** (انسفالومیلیت منتشر حاد)، **تب روماتیسمی** (پس از "
 "استرپتوکوک). ⚠️ **همه‌ی این‌ها «بیماری‌های پس‌عفونی» هستند: عفونت رفته، ولی پاسخ "
 "ایمنی مانده و به خودِ بدن حمله می‌کند.**\n\n"
 "**آتاکسی مخچه‌ای پس از آبله‌مرغان:**\n\n"
 "**شایع‌ترین عارضه‌ی عصبی آبله‌مرغان است** (حدود ۱ در ۴۰۰۰ کودک). معمولاً **۱ تا ۳ "
 "هفته پس از راش** شروع می‌شود. تابلویش: **آتاکسی راه رفتن، دیس‌آرتری، نیستاگموس**. "
 "⚠️ **و مهم‌ترین نکته: خوش‌خیم و خودمحدودشونده است و معمولاً ظرف ۲ تا ۴ هفته کامل "
 "بهبود می‌یابد.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**آسیکلوویر وریدی یا خوراکی** — ⚠️ **بی‌فایده، و دلیلش را باید دقیق فهمید.** "
 "آسیکلوویر **تکثیر ویروس را مهار می‌کند**. ولی اینجا **ویروسی در حال تکثیر نیست** — "
 "مشکل **پاسخ ایمنی** است. **دارویی که ویروس را هدف می‌گیرد، وقتی ویروس رفته، هیچ "
 "کاری نمی‌کند.**\n\n"
 "**کورتیکواستروئید** — ⚠️ **این وسوسه‌انگیزترین گزینه است**، چون منطقی به‌نظر "
 "می‌رسد: اگر مشکل ایمنی است، ایمنی را سرکوب کنیم. ولی **شواهد از آن حمایت "
 "نمی‌کند**: بیماری **خودبه‌خود و کامل** بهبود می‌یابد، و استروئید **عوارض واقعی** "
 "دارد. **تحمیل عارضه بر بیماری‌ای که خودش خوب می‌شود، منطقی نیست.**",
 "AN 8-YEAR-OLD GIRL who had chickenpox (maculopapular and vesicular lesions at different stages), "
 "WHOSE LESIONS HEALED, but who ABOUT THREE WEEKS LATER developed NAUSEA AND DISTURBANCE OF BALANCE "
 "AND GAIT.\n\n"
 "WARNING, THE ANSWER: SUPPORTIVE CARE. And the key to this question is the TIME INTERVAL.\n\n"
 "'THREE WEEKS LATER' is not incidental — the examiner placed it to reveal the whole nature of the "
 "illness.\n\n"
 "THINK IT THROUGH: the lesions HAVE HEALED and THREE WEEKS have passed. WARNING, SO THE VIRUS IS "
 "NO LONGER REPLICATING. Therefore what has happened now CANNOT BE DIRECT VIRAL INVASION.\n\n"
 "SO WHAT IS IT? A POST-INFECTIOUS IMMUNE REACTION.\n\n"
 "THE MECHANISM IS ELEGANT: the body made ANTIBODY to fight the virus. Some of that antibody, by "
 "chance, CROSS-REACTS with proteins in CEREBELLAR TISSUE. The result: AUTOIMMUNE INFLAMMATION OF "
 "THE CEREBELLUM.\n\n"
 "AND THE SAME LOGIC GOVERNS SEVERAL OTHER DISEASES: GUILLAIN-BARRE SYNDROME (after "
 "Campylobacter), ADEM (acute disseminated encephalomyelitis), RHEUMATIC FEVER (after "
 "streptococcus). WARNING, ALL ARE 'POST-INFECTIOUS DISEASES': the infection has gone, but the "
 "immune response remains and attacks the body itself.\n\n"
 "POST-VARICELLA CEREBELLAR ATAXIA:\n\n"
 "It is the COMMONEST NEUROLOGICAL COMPLICATION of chickenpox (about 1 in 4000 children). It "
 "usually begins 1 TO 3 WEEKS AFTER THE RASH. Its picture: GAIT ATAXIA, DYSARTHRIA, NYSTAGMUS. "
 "WARNING, AND THE KEY POINT: IT IS BENIGN AND SELF-LIMITING, usually resolving completely within 2 "
 "TO 4 WEEKS.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "INTRAVENOUS OR ORAL ACICLOVIR — WARNING, USELESS, and the reason must be understood precisely. "
 "Aciclovir INHIBITS VIRAL REPLICATION. But HERE NO VIRUS IS REPLICATING — the problem is the "
 "IMMUNE RESPONSE. A DRUG THAT TARGETS THE VIRUS DOES NOTHING ONCE THE VIRUS HAS GONE.\n\n"
 "CORTICOSTEROID — WARNING, THE MOST TEMPTING OPTION, because it sounds logical: if the problem is "
 "immune, suppress the immunity. But THE EVIDENCE DOES NOT SUPPORT IT: the illness resolves "
 "SPONTANEOUSLY AND COMPLETELY, and steroids carry REAL ADVERSE EFFECTS. IMPOSING HARM ON A DISEASE "
 "THAT CURES ITSELF IS NOT RATIONAL.",
 ["آسیکلوویر وریدی بی‌فایده است، چون ویروسی در حال تکثیر نمانده و مشکل پاسخ ایمنی است.",
  "آسیکلوویر خوراکی هم همان اشکال را دارد؛ دارو وقتی ویروس رفته کاری نمی‌کند.",
  "وسوسه‌انگیزترین گزینه — ولی بیماری خودبه‌خود بهبود می‌یابد و استروئید عوارض واقعی دارد.",
  "پاسخ صحیح — آتاکسی مخچه‌ای پس‌عفونی خوش‌خیم است و ظرف ۲ تا ۴ هفته کامل بهبود می‌یابد."],
 ["Intravenous aciclovir is useless, because no virus is replicating and the problem is the immune response.",
  "Oral aciclovir has the same flaw; the drug does nothing once the virus has gone.",
  "The most tempting option — but the illness resolves spontaneously and steroids carry real harms.",
  "Correct — post-infectious cerebellar ataxia is benign and resolves completely within 2 to 4 weeks."],
 "**عفونت رفته، پاسخ ایمنی مانده — پس داروی ضدویروسی کاری نمی‌کند.**",
 "The infection has gone and the immune response remains, so an antiviral does nothing.",
 [REDBOOK, H])

add("book:624", "recall", "easy",
 "معیار پایان ایزولاسیون آبله‌مرغان: **خشک شدن همه‌ی ضایعات**، نه گذشت تعداد روز.",
 "The criterion for ending varicella isolation is that EVERY LESION HAS CRUSTED, not a number of days.",
 VZV_FA + [
  "**این سؤال یک قاعده‌ی بهداشت عمومی را می‌آزماید که در عمل روزانه به کار می‌آید.**",
  "⚠️ **معیار، وضعیت ضایعات است نه تقویم — و همین آن را از بقیه‌ی بیماری‌ها جدا می‌کند.**",
  "**تا وقتی وزیکولی باز باشد، مایع داخلش پر از ویروس زنده است.**",
  "**با کراست شدن، ویروس دیگر از سطح پوست آزاد نمی‌شود.**",
  "**پس گزینه‌هایی که تعداد روز می‌گویند، ذاتاً غلط‌اند، هرچند عددشان بزرگ باشد.**",
  "⚠️ **و دوره‌ی سرایت از ۲۴ تا ۴۸ ساعت پیش از راش شروع می‌شود، یعنی پیش از تشخیص.**",
  "**به همین دلیل آبله‌مرغان در مدرسه و خانواده به‌سرعت پخش می‌شود.**",
  "**در فرد سالم معمولاً همه‌ی ضایعات ظرف ۵ تا ۷ روز کراست می‌شوند.**",
  "**ولی در فرد با نقص ایمنی، ضایعات موج‌های جدید می‌سازند و این مدت طولانی‌تر می‌شود.**",
 ],
 VZV_EN + [
  "This question tests a public-health rule that is used in daily practice.",
  "WARNING: THE CRITERION IS THE STATE OF THE LESIONS, NOT THE CALENDAR — and that sets it apart from other diseases.",
  "As long as any vesicle remains open, the fluid inside is full of live virus.",
  "Once crusted, the virus is no longer shed from the skin surface.",
  "So options that state a number of days are inherently wrong, however large the number.",
  "WARNING, AND THE INFECTIOUS PERIOD BEGINS 24 TO 48 HOURS BEFORE THE RASH, that is, before diagnosis.",
  "That is why chickenpox spreads so rapidly through a school or household.",
  "In a healthy person all lesions usually crust within 5 to 7 days.",
  "But in an immunocompromised person new waves keep appearing and the period lengthens.",
 ],
 "**دختر ۱۲ ساله** با تب و ضایعات پوستی به اشکال **ماکول، پاپول، وزیکول و پوستول** "
 "از دو روز قبل. سؤال می‌پرسد تا **چند روز** باید از تماس نزدیک پرهیز کند.\n\n"
 "⚠️ **پاسخ: پس از خشک شدن تمام ضایعات جلدی. و ظرافت سؤال این است که پاسخ اصلاً یک "
 "عدد نیست.**\n\n"
 "**سؤال می‌پرسد «تا چند روز دیگر»، ولی پاسخ درست می‌گوید «تا وقتی که...» — یعنی "
 "معیار، وضعیت ضایعات است نه تقویم.**\n\n"
 "**چرا؟ سازوکارش را بفهمید:**\n\n"
 "**ویروس واریسلا زوستر در مایع وزیکول‌ها به مقدار زیاد وجود دارد.** تا وقتی "
 "وزیکولی **باز** باشد، آن مایع می‌تواند به دیگران منتقل شود — چه با تماس مستقیم، "
 "چه با ذرات معلق در هوا. ⚠️ **با کراست (دلمه) شدن، سد فیزیکی ایجاد می‌شود و ویروس "
 "دیگر از سطح پوست آزاد نمی‌شود.**\n\n"
 "**پس معیار، بیولوژیک است نه زمانی.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟ همه یک اشکال مشترک دارند: یک عدد ثابت می‌دهند.**\n\n"
 "**«دو روز از بروز عوارض پوستی»** — بسیار زود. در روز دوم، **موج‌های جدید ضایعه "
 "هنوز در حال ظهورند**.\n\n"
 "**«ده روز پس از خشک شدن تمام ضایعات»** — ⚠️ این جالب‌ترین گزینه است، چون **بیش از "
 "حد محتاط** است. نیمه‌ی اولش درست است (خشک شدن ضایعات) ولی **ده روز اضافه هیچ "
 "توجیه علمی ندارد** و فقط کودک را بی‌جهت از مدرسه محروم می‌کند.\n\n"
 "**«ده روز پس از پایان تب»** — تب و ضایعات **الزاماً هم‌زمان تمام نمی‌شوند**. تب "
 "معمولاً **زودتر** فروکش می‌کند، در حالی که ضایعات هنوز فعال‌اند.\n\n"
 "⚠️ **و یک نکته‌ی بهداشت عمومی که سؤال نپرسیده ولی مهم است: دوره‌ی سرایت از ۲۴ تا "
 "۴۸ ساعت پیش از ظهور راش شروع می‌شود** — یعنی **پیش از آنکه کسی بداند بیمار است**. "
 "**به همین دلیل آبله‌مرغان در مدرسه و خانواده به‌سرعت پخش می‌شود، و ایزولاسیون پس از "
 "تشخیص هرگز نمی‌تواند کاملاً جلوی انتشار را بگیرد.**\n\n"
 "**در فرد سالم معمولاً همه‌ی ضایعات ظرف ۵ تا ۷ روز کراست می‌شوند.**",
 "A 12-YEAR-OLD GIRL with fever and skin lesions as MACULES, PAPULES, VESICLES AND PUSTULES for two "
 "days. The stem asks FOR HOW MANY DAYS she should avoid close contact.\n\n"
 "WARNING, THE ANSWER: UNTIL ALL SKIN LESIONS HAVE CRUSTED. And the subtlety is that the answer is "
 "not a number at all.\n\n"
 "The stem asks 'for how many more days', but the right answer says 'until...' — the criterion is "
 "THE STATE OF THE LESIONS, NOT THE CALENDAR.\n\n"
 "WHY? Understand the mechanism:\n\n"
 "VARICELLA ZOSTER VIRUS IS PRESENT IN LARGE QUANTITIES IN VESICLE FLUID. As long as any vesicle "
 "remains OPEN, that fluid can reach others, by direct contact or as airborne particles. WARNING, "
 "ONCE CRUSTED, A PHYSICAL BARRIER FORMS AND THE VIRUS IS NO LONGER SHED FROM THE SKIN.\n\n"
 "SO THE CRITERION IS BIOLOGICAL, NOT TEMPORAL.\n\n"
 "AND WHY NOT THE OTHER THREE? All share one flaw: they give a FIXED NUMBER.\n\n"
 "'TWO DAYS FROM THE APPEARANCE OF THE SKIN LESIONS' — far too early. On day two NEW WAVES OF "
 "LESIONS ARE STILL APPEARING.\n\n"
 "'TEN DAYS AFTER ALL LESIONS HAVE CRUSTED' — WARNING, the most interesting option, because it is "
 "EXCESSIVELY CAUTIOUS. Its first half is right (crusting) but THE EXTRA TEN DAYS HAVE NO "
 "SCIENTIFIC JUSTIFICATION and merely keep a child needlessly out of school.\n\n"
 "'TEN DAYS AFTER THE FEVER ENDS' — fever and lesions DO NOT NECESSARILY END TOGETHER. The fever "
 "usually settles EARLIER while lesions are still active.\n\n"
 "WARNING, AND A PUBLIC HEALTH POINT THE QUESTION DOES NOT ASK BUT WHICH MATTERS: THE INFECTIOUS "
 "PERIOD BEGINS 24 TO 48 HOURS BEFORE THE RASH — that is, BEFORE ANYONE KNOWS THE PATIENT IS ILL. "
 "THAT IS WHY CHICKENPOX SPREADS SO FAST THROUGH SCHOOLS AND HOUSEHOLDS, and why isolation after "
 "diagnosis can never fully prevent transmission.\n\n"
 "In a healthy person all lesions usually crust within 5 to 7 days.",
 ["بسیار زود است — در روز دوم موج‌های جدید ضایعه هنوز در حال ظهورند.",
  "نیمه‌ی اولش درست است ولی ده روز اضافه هیچ توجیه علمی ندارد و بی‌جهت محدودکننده است.",
  "تب و ضایعات الزاماً هم‌زمان تمام نمی‌شوند؛ تب معمولاً زودتر فروکش می‌کند.",
  "پاسخ صحیح — معیار بیولوژیک است: تا وقتی وزیکولی باز باشد ویروس منتقل می‌شود."],
 ["Far too early — on day two new waves of lesions are still appearing.",
  "Its first half is right, but the extra ten days have no scientific basis and are needlessly restrictive.",
  "Fever and lesions do not necessarily end together; the fever usually settles earlier.",
  "Correct — the criterion is biological: while any vesicle remains open the virus is transmitted."],
 "**معیار، کراست شدن ضایعات است نه تقویم.**",
 "The criterion is the crusting of the lesions, not the calendar.",
 [REDBOOK, H])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book38.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 38 lessons:', len(L))
