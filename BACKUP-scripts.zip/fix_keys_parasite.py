# -*- coding: utf-8 -*-
"""Three printed keys in the parasitology / malaria chapter that are wrong.

The rule this project follows is the conservative one: a printed key is
presumed right, and is only overturned when a primary source says plainly that
it is wrong AND the reasoning survives being written out for a student. Two of
my earlier flags (the HIV ELISA pair) were withdrawn under exactly that test.
These three do not withdraw.

------------------------------------------------------------------ q9761
"A 19-year-old soldier ... each of the following indicates SEVERE disease
EXCEPT" — printed key (A) haemoglobin 4.5 g/dL.

That cannot be right. A haemoglobin of 4.5 g/dL is severe malarial anaemia on
every version of the criteria ever published: < 5 g/dL in children, < 7 g/dL in
adults. It is the textbook example of a severity criterion, not the exception.

The option that is NOT a criterion is (B), a platelet count of 90 000. The
literature is unusually explicit about this, because it is a common error:

  "Profound thrombocytopenia is associated with an increased mortality in
   severe malaria, but it is not an independent risk factor and, contrary to
   some reports, IT IS NOT REGARDED AS A CRITERION OF SEVERE MALARIA."
   — White NJ et al., Severe malaria. Malar J 2022;21:284

  "Despite NOT BEING A CRITERION FOR SEVERE MALARIA, thrombocytopenia is one of
   the most common complications of both P. vivax and P. falciparum malaria."
   — Lacerda MVG et al., Thrombocytopenia in malaria: who cares?
     Mem Inst Oswaldo Cruz 2011;106(Suppl 1):52

The other two options are criteria and confirm the reading: red urine is
haemoglobinuria, and a urine output of 250 mL/24 h is below the 400 mL/24 h
renal-impairment threshold.

  Correction: A -> B.

------------------------------------------------------------------ q9790
"Pyrimethamine acts on which stage of the malaria cycle?" — printed key (B)
the gametocytes of falciparum.

Pyrimethamine is an antifolate: it blocks dihydrofolate reductase, so the
parasite cannot make thymidylate, so NUCLEAR DIVISION FAILS AT SCHIZOGONY. That
is a description of a dividing stage, and the dividing stage inside the human
is the asexual erythrocytic one. Gametocytes do not divide, so an antifolate
has nothing to bite on:

  "Blood schizonticidal agent active against asexual erythrocytic forms of
   susceptible P. falciparum, P. malariae, P. ovale and P. vivax."
   — Pyrimethamine monograph, AHFS/Drugs.com

  "It DOES NOT DESTROY GAMETOCYTES, but arrests sporogony in the mosquito."
   — Pyrimethamine drug monograph

The one grain of truth behind the printed key is sporontocidal activity — the
drug does stop the gametocyte developing further ONCE IT IS INSIDE THE MOSQUITO.
That is an effect in the vector, not on the gametocyte in the patient's blood,
and the question asks about the stage of the cycle the drug ACTS ON. The lesson
teaches both halves so the student is not merely told the book is wrong.

  Correction: B -> C (the erythrocytic stage).

------------------------------------------------------------------ q9823
"A 50-year-old herder ... ultrasound shows a cystic lesion WITH SEPTATION,
hydatid serology positive. What do you advise?" — printed key (A) "surgery by
the PAIR method".

Septation means daughter cysts: WHO-IWGE stage CE2, the multivesicular
honeycomb cyst. CE2 is precisely the stage in which PAIR is contraindicated,
because the needle drains one locule and leaves the rest, and the recurrence
rate is high:

  "PAIR is contraindicated for CE2, CE3b, CE4 and CE5 cysts, as well as for
   lung cysts. Some authors have reported high rates of repeated failures of
   PAIR in multivesiculated cysts."  — Ann Ital Chir / PMC3354352

  WHO-IWGE stage-directed table: CE1 and CE3a -> PAIR + albendazole;
  CE2 and CE3b -> SURGERY or (modified) catheterization + albendazole.

  ACG Clinical Guideline, Focal Liver Lesions (2024): surgery is indicated for
  complicated hydatid cysts — "cysts communicating with the biliary tree,
  MULTISEPTATED CYSTS, rupture or haemorrhage, secondary infection..."

The option's own wording gives it away too: PAIR is a percutaneous procedure,
so "surgery by the PAIR method" is a contradiction in terms. The consistent
answer is (B), open surgery with pericystectomy. Albendazole alone (C) is not
recommended as monotherapy, and observation (D) ignores a symptomatic active
cyst in a patient with two months of fever and pain.

  Correction: A -> B.

Every question also keeps the printed key in `key_original_index` and the
reasoning in `key_correction_note_fa/en`, so nothing is hidden from the student.
"""
import json, io, os

HERE = os.path.dirname(os.path.abspath(__file__))

FIXES = {
    9761: {
        'to': 1,
        'expect_from': 0,
        'fa': 'کلید چاپی گزینه‌ی «هموگلوبین ۴٫۵» را استثنا دانسته است، ولی هموگلوبین زیر ۵ '
              'دقیقاً تعریف کم‌خونی شدید مالاریایی است. آنچه جزو معیارهای شدت **نیست**، '
              'ترومبوسیتوپنی است: مقالات مرجع صریحاً می‌گویند پلاکت پایین در مالاریا بسیار '
              'شایع است اما معیار شدت به شمار نمی‌رود. ادرار قرمز (هموگلوبینوری) و برون‌ده '
              'ادراری ۲۵۰ میلی‌لیتر در شبانه‌روز (زیر آستانه‌ی ۴۰۰) هر دو معیار شدت‌اند.',
        'en': 'The printed key names haemoglobin 4.5 g/dL as the exception, but a haemoglobin '
              'below 5 is the definition of severe malarial anaemia. The option that is NOT a '
              'severity criterion is the platelet count: the reference literature states '
              'explicitly that thrombocytopenia, though very common in malaria, is not regarded '
              'as a criterion of severe disease. Red urine (haemoglobinuria) and a urine output '
              'of 250 mL/24 h (below the 400 mL threshold) are both criteria.',
        'refs': ['White NJ et al. Severe malaria. Malar J 2022;21:284',
                 'Lacerda MVG et al. Thrombocytopenia in malaria: who cares? '
                 'Mem Inst Oswaldo Cruz 2011;106(Suppl 1):52',
                 "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 227"],
    },
    9790: {
        'to': 2,
        'expect_from': 1,
        'fa': 'کلید چاپی «گامتوسیت‌های فالسیپاروم» را انتخاب کرده است، ولی پیریمتامین یک '
              'آنتی‌فولات است: دی‌هیدروفولات‌ردوکتاز را مهار می‌کند و در نتیجه **تقسیم هسته '
              'در مرحله‌ی شیزوگونی** متوقف می‌شود. گامتوسیت تقسیم نمی‌شود، پس آنتی‌فولات روی '
              'آن اثر کشنده ندارد؛ منابع دارویی صریحاً می‌گویند پیریمتامین گامتوسیت‌ها را از '
              'بین نمی‌برد. اثر واقعی دارو روی **فرم غیرجنسی داخل گلبول قرمز** است. تنها '
              'حقیقتِ پشت کلید چاپی، اثر اسپورونتوسیدال است: دارو رشد گامتوسیت را **پس از '
              'ورود به بدن پشه** متوقف می‌کند، که اثری در ناقل است نه روی گامتوسیت خون بیمار.',
        'en': 'The printed key chooses the gametocytes of falciparum, but pyrimethamine is an '
              'antifolate: it inhibits dihydrofolate reductase, so NUCLEAR DIVISION FAILS AT '
              'SCHIZOGONY. Gametocytes do not divide, so an antifolate has nothing to act on, '
              'and the drug monographs state plainly that pyrimethamine does not destroy '
              'gametocytes. Its real action is on the ASEXUAL ERYTHROCYTIC form. The grain of '
              'truth behind the printed key is sporontocidal activity: the drug arrests the '
              'gametocyte AFTER it is taken up by the mosquito — an effect in the vector, not '
              "on the gametocyte in the patient's blood.",
        'refs': ['Pyrimethamine monograph (AHFS Drug Information) — blood schizonticidal agent '
                 'active against asexual erythrocytic forms',
                 "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 227"],
    },
    9823: {
        'to': 1,
        'expect_from': 0,
        'fa': 'کلید چاپی «عمل جراحی به روش PAIR» را انتخاب کرده است. اما وجود **سپتاسیون** '
              'یعنی کیست دختر و مرحله‌ی **CE2** طبقه‌بندی WHO-IWGE — و CE2 دقیقاً همان '
              'مرحله‌ای است که PAIR در آن **منع** دارد، چون سوزن یک حفره را تخلیه می‌کند و '
              'بقیه‌ی حفره‌ها دست‌نخورده می‌مانند و عود بالا است. جدول مرحله‌محور WHO: CE1 و '
              'CE3a → PAIR؛ CE2 و CE3b → **جراحی یا کاتتریزاسیون** به‌علاوه‌ی آلبندازول. '
              'راهنمای ACG هم «کیست چندسپتومی» را صریحاً از اندیکاسیون‌های جراحی می‌شمارد. '
              'ضمناً خودِ عبارت گزینه متناقض است: PAIR روش **پوستی** است، نه جراحی.',
        'en': 'The printed key chooses "surgery by the PAIR method". But SEPTATION means daughter '
              'cysts — WHO-IWGE stage CE2 — and CE2 is precisely the stage in which PAIR is '
              'CONTRAINDICATED, because the needle drains one locule and leaves the rest, with a '
              'high recurrence rate. The WHO stage-directed table reads: CE1 and CE3a -> PAIR; '
              'CE2 and CE3b -> SURGERY or catheterization, plus albendazole. The ACG guideline '
              'likewise lists "multiseptated cysts" among the indications for surgery. The '
              "option's own wording is self-contradictory too: PAIR is a percutaneous procedure, "
              'not an operation.',
        'refs': ['WHO-IWGE stage-specific management of cystic echinococcosis (CE1/CE3a -> PAIR; '
                 'CE2/CE3b -> surgery or catheterization + albendazole)',
                 'ACG Clinical Guideline: Focal Liver Lesions (2024) — surgery for multiseptated '
                 'hydatid cysts',
                 "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 233"],
    },
}


def main():
    done = []
    for i in range(1, 6):
        p = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        body = json.load(io.open(p, encoding='utf-8'))
        dirty = False
        for q in body['questions']:
            spec = FIXES.get(q['question_no'])
            if not spec:
                continue
            # Guard against re-running on an already-corrected payload, and
            # against the option order having shifted underneath us.
            if q['correct_index'] == spec['to'] and q.get('key_corrected'):
                continue
            assert q['correct_index'] == spec['expect_from'], (
                f"q{q['question_no']}: expected printed key "
                f"{spec['expect_from']}, found {q['correct_index']}")
            # Use exactly the field names the rest of the bank already uses
            # (see fix_key_382.py and fix_keys_uti.py), so the existing guard
            # tests in server/test/api.test.js cover these three too rather
            # than silently skipping a second, parallel convention.
            q['original_correct_index'] = q['correct_index']
            q['correct_index'] = spec['to']
            q['key_corrected'] = True
            q['key_correction_fa'] = spec['fa']
            q['key_correction_en'] = spec['en']
            q['key_correction_source'] = '; '.join(spec['refs'])
            done.append(f"q{q['question_no']}: {spec['expect_from'] + 1} -> {spec['to'] + 1}  "
                        f"({q['options_fa'][spec['to']][:48]})")
            dirty = True
        if dirty:
            json.dump(body, io.open(p, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)
    for d in done:
        print('key fixed', d)
    print(f'\n{len(done)} keys corrected')


if __name__ == '__main__':
    main()
