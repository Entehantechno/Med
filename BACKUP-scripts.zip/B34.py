# -*- coding: utf-8 -*-
"""Micro-lessons, batch 34 — mononucleosis and herpes simplex.

Two clusters that between them account for most of the remaining questions in
the viral chapter, and both are decided by a single discriminating idea rather
than by a list.

CLUSTER ONE — MONONUCLEOSIS IS RECOGNISED, THEN LEFT ALONE
Seven questions describe the same young adult with exudative pharyngitis and
ask either "which organism?" or "what treatment?". The answer to the second is
almost always NOTHING, and the questions exist to catch the student who
reaches for penicillin. Three features separate mononucleosis from
streptococcal pharyngitis, and all three appear in these stems:

    posterior cervical or generalised lymphadenopathy, not just anterior
    SPLENOMEGALY, which streptococcus does not cause
    ATYPICAL LYMPHOCYTES above 10 per cent on the film

And one iatrogenic trap that the chapter tests twice: giving amoxicillin or
ampicillin to a patient with mononucleosis produces a florid morbilliform rash
in the great majority. That rash is NOT a penicillin allergy and must not be
recorded as one, because it mislabels the patient for life.

CLUSTER TWO — HERPES SIMPLEX IS RECOGNISED BY GROUPED VESICLES ON AN
ERYTHEMATOUS BASE, WHEREVER THEY APPEAR
The examiners move the same lesion around the body — genitals, finger, face,
neonate — and expect the student to name it each time:

    genital, painful, with systemic symptoms and bilateral tender nodes
        -> primary genital herpes
    a painful vesiculopustular finger in a health worker or dentist
        -> herpetic whitlow, which must not be incised
    vesicles on a background of atopic eczema
        -> eczema herpeticum, a dermatological emergency
    a sick neonate of a mother with genital herpes
        -> neonatal herpes, intravenous aciclovir without waiting

A NOTE ON THE CORRECTED KEY IN THIS BATCH
q9604's printed key chose the anti-EBNA antibody as the best test to establish
acute mononucleosis. That is the inverse of what the marker means: EBNA
antibody appears 6 to 12 weeks AFTER onset, and its presence early in the
illness EXCLUDES acute EBV infection. The key was corrected to IgM anti-VCA;
see fix_key_ebna.py for the full argument and sources. The lesson for that
question says plainly that the key was corrected, and also explains why the
heterophile test — the practical first test — is not the answer to a question
asking what ESTABLISHES the diagnosis.

Reference: American Academy of Pediatrics Red Book, Epstein-Barr virus
infections; CDC — Epstein-Barr Virus and Infectious Mononucleosis; Workowski KA
et al., CDC STI Treatment Guidelines 2021 (genital herpes); Harrison's
Principles of Internal Medicine, 21st ed (2022), Ch. 191 (Herpes Simplex Virus
Infections) and Ch. 194 (Epstein-Barr Virus Infections).
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


REDBOOK = ("American Academy of Pediatrics — Red Book: Report of the Committee on Infectious "
           "Diseases, Epstein-Barr virus infections (infectious mononucleosis)")
CDCEBV = ("CDC — Epstein-Barr Virus and Infectious Mononucleosis: laboratory testing and "
          "interpretation of the EBV antibody panel")
CDC2021 = ("Workowski KA et al. — Sexually Transmitted Infections Treatment Guidelines, 2021. "
           "MMWR Recomm Rep 2021;70(4):1-187 (Centers for Disease Control and Prevention)")
H191 = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 191: Herpes Simplex "
        "Virus Infections")
H194 = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 194: Epstein-Barr "
        "Virus Infections, Including Infectious Mononucleosis")

# ------------------------------------------------------------- mononucleosis
MONO_FA = [
    "⚠️ **مونونوکلئوز را از استرپتوکوک با سه یافته جدا کنید — و هر سه در همین فصل پرسیده شده‌اند.**",
    "**یک — محل غدد: در مونونوکلئوز، غدد گردنی خلفی یا لنفادنوپاتی ژنرالیزه.**",
    "**در فارنژیت استرپتوکوکی، غدد گردنی قدامی و معمولاً موضعی است.**",
    "⚠️ **دو — بزرگی طحال: استرپتوکوک اسپلنومگالی نمی‌سازد. مونونوکلئوز در نیمی از موارد می‌سازد.**",
    "**سه — لام خون محیطی: لنفوسیتوز با بیش از ۱۰ درصد لنفوسیت آتیپیک.**",
    "**این لنفوسیت‌های آتیپیک، خودِ ویروس نیستند — سلول‌های T واکنشی علیه سلول B آلوده‌اند.**",
    "**و همین توضیح می‌دهد چرا بیماری یک واکنش ایمنی است، نه صرفاً یک تهاجم ویروسی.**",
    "⚠️ **درمان مونونوکلئوز ساده: هیچ. استراحت، مایعات، مسکن و تب‌بر.**",
    "**آسیکلوویر بار ویروسی حلق را کم می‌کند ولی سیر بالینی را کوتاه نمی‌کند — پس توصیه نمی‌شود.**",
    "⚠️ **و دام درمانی که این فصل دو بار می‌آزماید: آمپی‌سیلین یا آموکسی‌سیلین ندهید.**",
    "**در اکثریت قاطع بیماران مونونوکلئوزی، این داروها راش ماکولوپاپولر وسیعی می‌سازند.**",
    "**این راش آلرژی به پنی‌سیلین نیست و نباید در پرونده به‌عنوان آلرژی ثبت شود.**",
    "**چون برچسب اشتباه «آلرژی به پنی‌سیلین» تا آخر عمر انتخاب‌های درمانی بیمار را محدود می‌کند.**",
    "⚠️ **و مهم‌ترین توصیه‌ی عملی: پرهیز از ورزش‌های برخوردی تا ۳ تا ۴ هفته.**",
    "**چون پارگی طحال، هرچند نادر، کشنده‌ترین عارضه‌ی مونونوکلئوز است.**",
    "**کورتیکواستروئید در مونونوکلئوز ساده جایی ندارد و روتین تجویز نمی‌شود.**",
    "**ولی سه اندیکاسیون استثنایی دارد: انسداد راه هوایی، آنمی همولیتیک، و ترومبوسیتوپنی شدید.**",
]
MONO_EN = [
    "WARNING: SEPARATE MONONUCLEOSIS FROM STREPTOCOCCUS BY THREE FINDINGS — all three are examined in this chapter.",
    "ONE — THE SITE OF THE NODES: in mononucleosis, posterior cervical or generalised lymphadenopathy.",
    "In streptococcal pharyngitis the nodes are anterior cervical and usually localised.",
    "WARNING, TWO — SPLENOMEGALY: streptococcus does not cause it. Mononucleosis does in half of cases.",
    "THREE — THE BLOOD FILM: lymphocytosis with more than 10 per cent ATYPICAL LYMPHOCYTES.",
    "Those atypical lymphocytes are not the virus itself — they are reactive T cells attacking infected B cells.",
    "And that explains why the illness is an IMMUNE REACTION rather than merely a viral invasion.",
    "WARNING, THE TREATMENT OF UNCOMPLICATED MONONUCLEOSIS IS NOTHING: rest, fluids, analgesia and antipyretics.",
    "Aciclovir reduces pharyngeal viral shedding but does not shorten the illness, so it is not recommended.",
    "WARNING, AND THE THERAPEUTIC TRAP THIS CHAPTER TESTS TWICE: DO NOT GIVE AMPICILLIN OR AMOXICILLIN.",
    "In the great majority of patients with mononucleosis these drugs produce a florid maculopapular rash.",
    "THAT RASH IS NOT A PENICILLIN ALLERGY and must not be recorded as one in the notes.",
    "Because a mistaken 'penicillin allergy' label narrows the patient's treatment options for life.",
    "WARNING, AND THE MOST IMPORTANT PRACTICAL ADVICE: avoid contact sports for 3 to 4 weeks.",
    "Because SPLENIC RUPTURE, though rare, is the most lethal complication of mononucleosis.",
    "Corticosteroids have no place in uncomplicated mononucleosis and are not given routinely.",
    "But they have three exceptional indications: airway obstruction, haemolytic anaemia, and severe thrombocytopenia.",
]

# --------------------------------------------------------------- herpes simplex
HSV_FA = [
    "⚠️ **هرپس سیمپلکس را از یک نشانه بشناسید: وزیکول‌های گروهی روی زمینه‌ی اریتماتو.**",
    "**این الگو هرجای بدن که ظاهر شود، همان معنا را دارد — و سؤال‌ها همین را جابه‌جا می‌کنند.**",
    "**حمله‌ی اولیه‌ی تناسلی: زخم‌های متعدد و بسیار دردناک، با علائم سیستمیک.**",
    "**تب، سردرد و میالژی در حمله‌ی اول شایع است و در عودها تقریباً وجود ندارد.**",
    "⚠️ **و لنفادنوپاتی اینگوینال در هرپس اولیه، دوطرفه و دردناک است.**",
    "**این با شانکروئید (یک‌طرفه و چرکی) و سیفلیس (دوطرفه و بدون درد) فرق دارد.**",
    "**ویتلوی هرپسی: ضایعه‌ی وزیکولوپوستولر دردناک روی انگشت، در کادر درمان و دندان‌پزشک.**",
    "⚠️ **و مهم‌ترین نکته‌اش: ویتلوی هرپسی را هرگز جراحی و درناژ نکنید.**",
    "**چون یک عفونت ویروسی است نه آبسه، و برش فقط باعث انتشار و عفونت ثانویه می‌شود.**",
    "**اگزمای هرپتیکوم: وزیکول‌های منتشر روی زمینه‌ی اگزمای آتوپیک — یک فوریت پوستی.**",
    "**پوست آسیب‌دیده‌ی اگزمایی سد دفاعی ندارد، پس ویروس به‌سرعت گسترش می‌یابد.**",
    "⚠️ **هرپس نوزادی: بدحالی نوزاد مادرِ با سابقه‌ی هرپس تناسلی ← آسیکلوویر وریدی فوری.**",
    "**بدون انتظار برای تأیید آزمایشگاهی، چون مرگ‌ومیر فرم منتشرش بسیار بالاست.**",
    "**تشخیص قطعی: PCR از خودِ ضایعه — حساس‌ترین و سریع‌ترین روش.**",
    "**و سرولوژی نوع‌اختصاصی جای دیگری دارد: تعیین اینکه این حمله‌ی اول است یا عود.**",
    "⚠️ **چون در حمله‌ی اولِ واقعی، سرولوژی هنوز منفی است؛ در عود، از قبل مثبت است.**",
    "**و این تمایز برای مشاوره‌ی بیمار و شریک جنسی‌اش اهمیت زیادی دارد.**",
    "**درمان: آسیکلوویر، والاسیکلوویر یا فامسیکلوویر خوراکی — و در حمله‌ی اول ۷ تا ۱۰ روز.**",
]
HSV_EN = [
    "WARNING: RECOGNISE HERPES SIMPLEX BY ONE SIGN — GROUPED VESICLES ON AN ERYTHEMATOUS BASE.",
    "Wherever on the body that pattern appears it means the same thing — and the questions simply move it around.",
    "A PRIMARY GENITAL ATTACK: multiple, very painful ulcers with systemic symptoms.",
    "Fever, headache and myalgia are common in the first attack and virtually absent in recurrences.",
    "WARNING, AND THE INGUINAL NODES IN PRIMARY HERPES ARE BILATERAL AND TENDER.",
    "That differs from chancroid (unilateral and suppurative) and syphilis (bilateral and painless).",
    "HERPETIC WHITLOW: a painful vesiculopustular finger lesion in a health worker or dentist.",
    "WARNING, AND ITS KEY POINT: NEVER INCISE AND DRAIN A HERPETIC WHITLOW.",
    "Because it is a viral infection and not an abscess; incision only spreads it and invites secondary infection.",
    "ECZEMA HERPETICUM: disseminated vesicles on a background of atopic eczema — a dermatological emergency.",
    "Damaged eczematous skin has no barrier, so the virus spreads rapidly.",
    "WARNING, NEONATAL HERPES: an unwell neonate of a mother with genital herpes needs INTRAVENOUS ACICLOVIR AT ONCE.",
    "Without waiting for laboratory confirmation, because the mortality of the disseminated form is very high.",
    "DEFINITIVE DIAGNOSIS: PCR from the lesion itself — the most sensitive and fastest method.",
    "And type-specific serology has a different role: deciding whether this is a first attack or a recurrence.",
    "WARNING, BECAUSE IN A TRUE FIRST ATTACK THE SEROLOGY IS STILL NEGATIVE; in a recurrence it is already positive.",
    "And that distinction matters greatly for counselling the patient and the sexual partner.",
    "TREATMENT: oral aciclovir, valaciclovir or famciclovir — and 7 to 10 days for a first attack.",
]


# =========================================================== book:596
add("book:596", "case", "easy",
 "فارنژیت اگزوداتیو + **اسپلنومگالی** + **لنفوسیت آتیپیک بالای ۲۰٪** ← **اپشتین-بار**.",
 "Exudative pharyngitis with SPLENOMEGALY and OVER 20% ATYPICAL LYMPHOCYTES: EPSTEIN-BARR VIRUS.",
 MONO_FA + [
  "**سه یافته‌ی این سؤال، تشخیص را قطعی می‌کنند و هر سه عمداً آمده‌اند.**",
  "**یک — لنفادنوپاتی و اسپلنومگالی با هم.**",
  "**دو — فارنژیت اگزوداتیو، که به‌تنهایی به استرپتوکوک هم می‌خورد.**",
  "⚠️ **سه — و یافته‌ی قاطع: لنفوسیت آتیپیک بیش از ۲۰ درصد.**",
  "**آستانه‌ی متعارف ۱۰ درصد است؛ بیش از ۲۰ درصد عملاً تشخیصی است.**",
  "**راش پاپولر روی تنه و اندام‌ها هم در مونونوکلئوز دیده می‌شود.**",
  "⚠️ **و چرا سیتومگالوویروس نه، با آنکه تابلوی مشابهی می‌سازد؟**",
  "**سیتومگالوویروس سندرم شبه‌مونونوکلئوز می‌دهد ولی معمولاً بدون فارنژیت اگزوداتیو برجسته.**",
  "**و لنفادنوپاتی در آن خفیف‌تر است. تست هتروفیل هم در آن منفی است.**",
  "**پس در حضور فارنژیت اگزوداتیو شدید و لنفادنوپاتی برجسته، EBV محتمل‌تر است.**",
 ],
 MONO_EN + [
  "Three findings in this stem settle the diagnosis, and all three are there deliberately.",
  "ONE — lymphadenopathy and splenomegaly together.",
  "TWO — exudative pharyngitis, which on its own would also fit streptococcus.",
  "WARNING, THREE — AND THE DECISIVE FINDING: over 20 per cent atypical lymphocytes.",
  "The conventional threshold is 10 per cent; above 20 per cent is effectively diagnostic.",
  "A papular rash on the trunk and limbs is also seen in mononucleosis.",
  "WARNING, AND WHY NOT CYTOMEGALOVIRUS, which produces a similar picture?",
  "CMV gives a mononucleosis-like syndrome but usually WITHOUT prominent exudative pharyngitis.",
  "And its lymphadenopathy is milder. Its heterophile test is also negative.",
  "So with severe exudative pharyngitis and prominent lymphadenopathy, EBV is likelier.",
 ],
 "این ساده‌ترین سؤال بلوک مونونوکلئوز است و باید مثل یک رفلکس پاسخ داده شود.\n\n"
 "**آقای ۲۰ ساله** با گلودرد، بی‌حالی، درد شکم، تهوع و استفراغ. در معاینه: **لنفادنوپاتی**، "
 "**اسپلنومگالی**، **فارنژیت اگزوداتیو**، و **راش پاپولر** روی تنه و اندام‌ها. "
 "لام خون محیطی: **لنفوسیت آتیپیک بیش از ۲۰ درصد**.\n\n"
 "⚠️ **سه یافته، یک تشخیص:**\n\n"
 "**۱) اسپلنومگالی.** این یافته به‌تنهایی **استرپتوکوک را کنار می‌گذارد** — فارنژیت "
 "استرپتوکوکی بزرگی طحال نمی‌سازد. و «درد شکم» بیمار هم احتمالاً از همین بزرگی طحال "
 "می‌آید.\n\n"
 "**۲) فارنژیت اگزوداتیو.** این یافته **به‌تنهایی افتراقی نیست** — هم به استرپتوکوک "
 "می‌خورد و هم به EBV. به همین دلیل است که خیلی از بیماران مونونوکلئوزی به‌اشتباه "
 "پنی‌سیلین می‌گیرند.\n\n"
 "⚠️ **۳) و یافته‌ی قاطع: لنفوسیت آتیپیک بیش از ۲۰ درصد.**\n\n"
 "**آستانه‌ی متعارف ۱۰ درصد است؛ بیش از ۲۰ درصد عملاً تشخیصی است.**\n\n"
 "**و یک نکته‌ی مفهومی زیبا:** این لنفوسیت‌های آتیپیک **سلول‌های آلوده نیستند**. ویروس "
 "**سلول B** را آلوده می‌کند؛ آنچه در لام می‌بینیم **سلول‌های T واکنشی** هستند که به "
 "سلول‌های B آلوده حمله می‌کنند. **پس تابلوی بالینی مونونوکلئوز، بیشتر واکنش ایمنی بدن "
 "است تا خودِ تهاجم ویروس** — و همین توضیح می‌دهد چرا آسیکلوویر سیر بیماری را عوض نمی‌کند.\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**استرپتوکوک** — اسپلنومگالی نمی‌سازد و لنفوسیت آتیپیک هم نمی‌دهد.\n\n"
 "**هرپس ویروس** — استوماتیت وزیکولر می‌دهد، نه فارنژیت اگزوداتیو با اسپلنومگالی.\n\n"
 "⚠️ **سیتومگالوویروس** — این نزدیک‌ترین رقیب است و **سندرم شبه‌مونونوکلئوز** می‌سازد. "
 "ولی تفاوت‌هایش را بدانید: **CMV معمولاً فارنژیت اگزوداتیو برجسته ندارد**، لنفادنوپاتی‌اش "
 "**خفیف‌تر** است، و **تست هتروفیل در آن منفی** است. در حضور فارنژیت شدید و لنفادنوپاتی "
 "برجسته، **EBV محتمل‌تر** است.",
 "This is the simplest question in the mononucleosis block and should be answered as a reflex.\n\n"
 "A 20-YEAR-OLD MAN with sore throat, malaise, abdominal pain, nausea and vomiting. On "
 "examination: LYMPHADENOPATHY, SPLENOMEGALY, EXUDATIVE PHARYNGITIS and a PAPULAR RASH on the "
 "trunk and limbs. Blood film: OVER 20 PER CENT ATYPICAL LYMPHOCYTES.\n\n"
 "WARNING, THREE FINDINGS, ONE DIAGNOSIS:\n\n"
 "1) SPLENOMEGALY. This finding alone SETS STREPTOCOCCUS ASIDE — streptococcal pharyngitis does "
 "not enlarge the spleen. And the patient's abdominal pain probably comes from that very "
 "splenomegaly.\n\n"
 "2) EXUDATIVE PHARYNGITIS. On its own this is NOT DISCRIMINATING — it fits both streptococcus "
 "and EBV. That is exactly why so many patients with mononucleosis are mistakenly given "
 "penicillin.\n\n"
 "WARNING, 3) AND THE DECISIVE FINDING: OVER 20 PER CENT ATYPICAL LYMPHOCYTES.\n\n"
 "The conventional threshold is 10 per cent; above 20 per cent is effectively diagnostic.\n\n"
 "AND AN ELEGANT CONCEPTUAL POINT: those atypical lymphocytes ARE NOT THE INFECTED CELLS. The "
 "virus infects B CELLS; what we see on the film are REACTIVE T CELLS attacking the infected B "
 "cells. SO THE CLINICAL PICTURE OF MONONUCLEOSIS IS MORE THE BODY'S IMMUNE REACTION THAN THE "
 "VIRAL INVASION ITSELF — and that explains why aciclovir does not alter the course.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "STREPTOCOCCUS — does not cause splenomegaly and does not produce atypical lymphocytes.\n\n"
 "HERPES VIRUS — causes vesicular stomatitis, not exudative pharyngitis with splenomegaly.\n\n"
 "WARNING, CYTOMEGALOVIRUS — the closest competitor, producing a MONONUCLEOSIS-LIKE SYNDROME. But "
 "know the differences: CMV USUALLY LACKS PROMINENT EXUDATIVE PHARYNGITIS, its lymphadenopathy is "
 "MILDER, and its HETEROPHILE TEST IS NEGATIVE. With severe pharyngitis and prominent "
 "lymphadenopathy, EBV IS LIKELIER.",
 ["هرپس ویروس استوماتیت وزیکولر می‌دهد، نه فارنژیت اگزوداتیو همراه با اسپلنومگالی.",
  "استرپتوکوک نه اسپلنومگالی می‌سازد و نه لنفوسیت آتیپیک بالای ۲۰ درصد.",
  "پاسخ صحیح — فارنژیت اگزوداتیو با اسپلنومگالی و لنفوسیت آتیپیک بالا: مونونوکلئوز EBV.",
  "سیتومگالوویروس سندرم شبه‌مونونوکلئوز می‌دهد ولی معمولاً بدون فارنژیت اگزوداتیو برجسته."],
 ["Herpes virus causes vesicular stomatitis, not exudative pharyngitis with splenomegaly.",
  "Streptococcus causes neither splenomegaly nor atypical lymphocytes above 20 per cent.",
  "Correct — exudative pharyngitis with splenomegaly and high atypical lymphocytes is EBV mononucleosis.",
  "Cytomegalovirus gives a mononucleosis-like syndrome but usually without prominent exudative pharyngitis."],
 "**اسپلنومگالی + لنفوسیت آتیپیک = مونونوکلئوز، نه استرپتوکوک.**",
 "Splenomegaly plus atypical lymphocytes means mononucleosis, not streptococcus.",
 [H194, REDBOOK])


# =========================================================== book:604
add("book:604", "case", "hard",
 "⚠️ **کلید تصحیح شد:** برای اثبات مونونوکلئوز حاد، **IgM ضد VCA** — نه EBNA که عفونت حاد را رد می‌کند.",
 "WARNING, THE KEY WAS CORRECTED: acute mononucleosis is proven by IgM ANTI-VCA, not by EBNA, whose presence excludes acute infection.",
 MONO_FA + [
  "⚠️ **کلید چاپی این سؤال «آنتی‌بادی ضد EBNA» بود و تصحیح شد. دلیلش را کامل بدانید.**",
  "**EBNA آنتی‌ژنی است که ویروس فقط هنگام ورود به فاز نهفتگی می‌سازد.**",
  "**یعنی وقتی بیماری حاد تمام شده و ویروس در سلول B خفته است.**",
  "⚠️ **پس آنتی‌بادی ضد EBNA حدود ۶ تا ۱۲ هفته پس از شروع علائم ظاهر می‌شود.**",
  "**و نتیجه دقیقاً برعکس کلید است: حضور زودهنگام EBNA، عفونت حاد را رد می‌کند.**",
  "**آزمایشگاه‌های بریتانیا از EBNA به‌عنوان تست غربالگری استفاده می‌کنند، دقیقاً به همین دلیل.**",
  "**نشانگر درست IgM ضد VCA است: در زمان مراجعه از قبل مثبت است.**",
  "**چون کمون EBV طولانی است (۴ تا ۸ هفته) و آنتی‌بادی پیش از شروع علائم بالا آمده.**",
  "**و ظرف حدود ۳ ماه محو می‌شود، پس نشانگر قابل اتکای عفونت حاد است.**",
  "⚠️ **و چرا تست هتروفیل نه، با آنکه در عمل اولین تست است؟**",
  "**چون آنتی‌بادی ضد یک آنتی‌ژن گلبول قرمز حیوانیِ بی‌ربط است و اختصاصی ویروس نیست.**",
  "**در حدود ۲۵ درصد بزرگسالان در هفته‌ی اول کاذباً منفی است و در کودکان زیر ۴ سال اغلب منفی.**",
  "**سؤال «اثبات تشخیص» را می‌خواهد، و اثبات کار یک نشانگر اختصاصی است.**",
 ],
 MONO_EN + [
  "WARNING: THE PRINTED KEY FOR THIS QUESTION WAS THE ANTI-EBNA ANTIBODY AND IT WAS CORRECTED. Know the reason fully.",
  "EBNA is the antigen the virus expresses only as it enters LATENCY.",
  "That is, once the acute illness is over and the virus lies dormant in B cells.",
  "WARNING, SO ANTI-EBNA ANTIBODY APPEARS 6 TO 12 WEEKS AFTER THE ONSET OF SYMPTOMS.",
  "And the consequence is the exact inverse of the key: EBNA present early EXCLUDES acute infection.",
  "UK laboratories use EBNA as a screening test for precisely that reason.",
  "The correct marker is IgM ANTI-VCA: it is already positive at presentation.",
  "Because EBV's incubation is long (4 to 8 weeks) and antibody has risen before symptoms begin.",
  "And it wanes over about 3 months, making it a reliable marker of acute infection.",
  "WARNING, AND WHY NOT THE HETEROPHILE TEST, which is in practice the first test?",
  "Because it is antibody to an UNRELATED animal red-cell antigen and is not virus-specific.",
  "It is falsely negative in about 25 per cent of adults in the first week, and usually negative in children under 4.",
  "The question asks what ESTABLISHES the diagnosis, and establishing it is the job of a specific marker.",
 ],
 "⚠️ **پیش از هر چیز: کلید چاپی این سؤال تصحیح شده است.**\n\n"
 "کتاب گزینه‌ی **«آنتی‌بادی IgM ضد EBNA»** را به‌عنوان مفیدترین تست انتخاب کرده بود. "
 "**این انتخاب دقیقاً عکسِ معنای این نشانگر است** و کلید به **IgM ضد VCA** اصلاح شد.\n\n"
 "**خانم ۱۸ ساله** با تب و گلودرد، **فارنژیت اگزوداتیو**، **لنفادنوپاتی گردنی**، "
 "**هپاتواسپلنومگالی**، و **بیش از ۱۲ درصد لنفوسیت آتیپیک**. تشخیص بالینی روشن است: "
 "**مونونوکلئوز عفونی**. سؤال می‌پرسد **کدام تست آن را اثبات می‌کند**.\n\n"
 "⚠️ **چرا EBNA غلط است؟ این را عمیق بفهمید، چون یک مفهوم پایه‌ای ایمنی‌شناسی است.**\n\n"
 "**EBNA (آنتی‌ژن هسته‌ای اپشتین-بار) پروتئینی است که ویروس فقط هنگام ورود به فاز نهفتگی "
 "می‌سازد** — یعنی **وقتی بیماری حاد تمام شده** و ویروس در سلول B خفته است.\n\n"
 "**پس آنتی‌بادی ضد آن دیر می‌آید: ۶ تا ۱۲ هفته پس از شروع علائم.** و بعد **مادام‌العمر** "
 "می‌ماند.\n\n"
 "**و نتیجه‌ی این تأخیر، دقیقاً برعکس چیزی است که کلید ادعا می‌کرد:**\n\n"
 "> **کتاب Red Book: «حضور آنتی‌بادی EBNA در مراحل اولیه‌ی بیماری، عفونت حاد EBV را "
 "عملاً رد می‌کند.»**\n\n"
 "آزمایشگاه‌های بریتانیا **از EBNA به‌عنوان تست غربالگری** استفاده می‌کنند، با این تفسیر: "
 "«نتیجه‌ی مثبت یعنی **عفونت گذشته**، و عفونت اولیه در ۶ هفته‌ی اخیر را **رد می‌کند**».\n\n"
 "**پس در بیماری که امروز حاد بیمار است، مثبت شدن EBNA علیه تشخیص است، نه به نفع آن.**\n\n"
 "✅ **و نشانگر درست: IgM ضد VCA.**\n\n"
 "**چرا کار می‌کند؟** چون **دوره‌ی کمون EBV طولانی است (۴ تا ۸ هفته)**. یعنی تا وقتی "
 "علائم شروع شوند، **سیستم ایمنی مدت‌هاست ویروس را دیده و آنتی‌بادی ساخته**. پس "
 "**IgM ضد VCA در همان روز اول مراجعه مثبت است**. و چون ظرف حدود **۳ ماه محو می‌شود**، "
 "مثبت بودنش یعنی **عفونت حاد یا اخیر**.\n\n"
 "⚠️ **و حالا سؤال منصفانه: چرا تست هتروفیل نه؟**\n\n"
 "این گزینه **بهترین رقیب** است و دانشجوی دقیق آن را انتخاب می‌کند. **در عمل، تست هتروفیل "
 "(مونواسپات) اولین تستی است که درخواست می‌شود** — ارزان، سریع، در دسترس.\n\n"
 "**ولی سؤال «مفیدترین تست جهت اثبات تشخیص» را می‌خواهد، و هتروفیل نمی‌تواند اثبات کند:**\n\n"
 "• **اصلاً اختصاصی ویروس نیست** — آنتی‌بادی‌ای است علیه یک آنتی‌ژن **گلبول قرمز حیوانیِ "
 "بی‌ربط** که در مونونوکلئوز به‌طور اتفاقی تولید می‌شود\n\n"
 "• **در حدود ۲۵ درصد بزرگسالان در هفته‌ی اول کاذباً منفی** است\n\n"
 "• **در کودکان زیر ۴ سال اغلب منفی** است\n\n"
 "**پس: هتروفیل را اول درخواست کنید، ولی IgM ضد VCA است که تشخیص را اثبات می‌کند.**\n\n"
 "**و چرا IgM ضد EA نه؟** آنتی‌بادی ضد آنتی‌ژن زودرس در بخش قابل توجهی از بیماران **اصلاً "
 "تولید نمی‌شود**، پس **نبودنش بیماری را رد نمی‌کند** و برای اثبات قابل اتکا نیست.",
 "WARNING, FIRST OF ALL: THE PRINTED KEY FOR THIS QUESTION HAS BEEN CORRECTED.\n\n"
 "The book chose 'IgM antibody to EBNA' as the most useful test. THAT CHOICE IS THE EXACT INVERSE "
 "of what the marker means, and the key was corrected to IgM ANTI-VCA.\n\n"
 "AN 18-YEAR-OLD WOMAN with fever and sore throat, EXUDATIVE PHARYNGITIS, CERVICAL "
 "LYMPHADENOPATHY, HEPATOSPLENOMEGALY and MORE THAN 12 PER CENT ATYPICAL LYMPHOCYTES. The clinical "
 "diagnosis is clear: INFECTIOUS MONONUCLEOSIS. The question asks WHICH TEST PROVES IT.\n\n"
 "WARNING, WHY IS EBNA WRONG? Understand this deeply, because it is a basic immunological "
 "concept.\n\n"
 "EBNA (Epstein-Barr NUCLEAR ANTIGEN) is a protein the virus expresses only as it ENTERS LATENCY — "
 "that is, ONCE THE ACUTE ILLNESS IS OVER and the virus lies dormant in B cells.\n\n"
 "SO ANTIBODY TO IT ARRIVES LATE: 6 TO 12 WEEKS AFTER THE ONSET OF SYMPTOMS. And then it persists "
 "FOR LIFE.\n\n"
 "AND THE CONSEQUENCE OF THAT DELAY IS PRECISELY THE OPPOSITE OF WHAT THE KEY CLAIMED:\n\n"
 "> The Red Book: 'their presence early in the course of illness EFFECTIVELY EXCLUDES ACUTE EBV "
 "INFECTION.'\n\n"
 "UK laboratories use EBNA AS A SCREENING TEST with exactly this interpretation: a positive result "
 "means PAST infection and EXCLUDES primary infection within the preceding 6 weeks.\n\n"
 "SO IN A PATIENT ACUTELY ILL TODAY, A POSITIVE EBNA ARGUES AGAINST THE DIAGNOSIS, NOT FOR IT.\n\n"
 "AND THE CORRECT MARKER: IgM ANTI-VCA.\n\n"
 "WHY DOES IT WORK? Because EBV'S INCUBATION IS LONG (4 TO 8 WEEKS). By the time symptoms begin, "
 "THE IMMUNE SYSTEM HAS LONG SINCE SEEN THE VIRUS AND MADE ANTIBODY. So IgM ANTI-VCA IS POSITIVE ON "
 "THE VERY FIRST DAY OF PRESENTATION. And because it wanes over about 3 MONTHS, its presence means "
 "ACUTE OR RECENT infection.\n\n"
 "WARNING, AND NOW THE FAIR QUESTION: WHY NOT THE HETEROPHILE TEST?\n\n"
 "That option is THE BEST COMPETITOR and a careful student will choose it. IN PRACTICE THE "
 "HETEROPHILE (MONOSPOT) TEST IS THE FIRST TEST ORDERED — cheap, quick, available.\n\n"
 "BUT THE QUESTION ASKS FOR THE MOST USEFUL TEST TO ESTABLISH THE DIAGNOSIS, AND THE HETEROPHILE "
 "TEST CANNOT ESTABLISH IT:\n\n"
 "• IT IS NOT VIRUS-SPECIFIC AT ALL — it is an antibody against an UNRELATED ANIMAL RED-CELL "
 "ANTIGEN, produced incidentally in mononucleosis\n\n"
 "• IT IS FALSELY NEGATIVE IN ABOUT 25 PER CENT OF ADULTS IN THE FIRST WEEK\n\n"
 "• AND IT IS USUALLY NEGATIVE IN CHILDREN UNDER 4\n\n"
 "SO: ORDER THE HETEROPHILE FIRST, BUT IT IS IgM ANTI-VCA THAT PROVES THE DIAGNOSIS.\n\n"
 "AND WHY NOT IgM ANTI-EA? Antibody to early antigen IS SIMPLY NOT PRODUCED in a substantial share "
 "of patients, so ITS ABSENCE DOES NOT EXCLUDE THE DISEASE and it cannot be relied on to prove it.",
 ["کلید چاپی همین بود و تصحیح شد: EBNA ۶ تا ۱۲ هفته بعد ظاهر می‌شود و حضور زودهنگامش عفونت حاد را رد می‌کند.",
  "تست هتروفیل در عمل اولین تست است، ولی اختصاصی ویروس نیست و در هفته‌ی اول تا ۲۵ درصد کاذباً منفی است.",
  "پاسخ صحیح (کلید تصحیح‌شده) — IgM ضد VCA در زمان مراجعه مثبت است و عفونت حاد را اثبات می‌کند.",
  "آنتی‌بادی ضد آنتی‌ژن زودرس در بخش قابل توجهی از بیماران تولید نمی‌شود، پس برای اثبات قابل اتکا نیست."],
 ["This was the printed key and it was corrected: EBNA appears 6 to 12 weeks later and its early presence excludes acute infection.",
  "The heterophile test is the first test in practice, but it is not virus-specific and is falsely negative in up to 25 per cent in week one.",
  "Correct (the corrected key) — IgM anti-VCA is positive at presentation and establishes acute infection.",
  "Antibody to early antigen is not produced in a substantial share of patients, so it cannot be relied on to prove the diagnosis."],
 "**EBNA دیر می‌آید، پس حضورش عفونت حاد را رد می‌کند.** برای اثبات حاد: IgM ضد VCA.",
 "EBNA arrives late, so its presence excludes acute infection; to prove acute disease use IgM anti-VCA.",
 [REDBOOK, CDCEBV, H194])


# =========================================================== book:601
add("book:601", "case", "medium",
 "گلودرد ۱۰ روزه که به **پنی‌سیلین پاسخ نداده** + لنفوسیتوز ← مونونوکلئوز ← **درمان علامتی**.",
 "A 10-day sore throat UNRESPONSIVE TO PENICILLIN with lymphocytosis is mononucleosis: SYMPTOMATIC TREATMENT.",
 MONO_FA + [
  "**دو سرنخ در این سؤال، تشخیص را از استرپتوکوک دور می‌کنند.**",
  "⚠️ **سرنخ یک — پنی‌سیلین بنزاتین ۵ روز پیش داده شده و بیمار بهتر نشده.**",
  "**فارنژیت استرپتوکوکی به پنی‌سیلین ظرف ۲۴ تا ۴۸ ساعت پاسخ می‌دهد.**",
  "**عدم پاسخ به پنی‌سیلین، یعنی عامل استرپتوکوک نبوده است.**",
  "**سرنخ دو — لکوسیت ۲۵۰۰۰ با ارجحیت لنفوسیت.**",
  "⚠️ **در عفونت باکتریال، غلبه با نوتروفیل است؛ غلبه‌ی لنفوسیت یعنی ویروسی.**",
  "**و لنفادنوپاتی گردنی به‌همراه زیربغلی، یعنی درگیری ژنرالیزه — نه موضعی استرپتوکوکی.**",
  "**پس تشخیص مونونوکلئوز است و درمانش علامتی.**",
  "⚠️ **و ادامه دادن آنتی‌بیوتیک نه‌تنها بی‌فایده، که خطرناک است.**",
  "**چون آمپی‌سیلین و آموکسی‌سیلین در مونونوکلئوز راش وسیع ماکولوپاپولر می‌سازند.**",
  "**و پردنیزولون هم در مونونوکلئوز ساده اندیکاسیون ندارد و روتین تجویز نمی‌شود.**",
  "**استروئید فقط در انسداد راه هوایی، آنمی همولیتیک یا ترومبوسیتوپنی شدید جا دارد.**",
 ],
 MONO_EN + [
  "Two clues in this stem move the diagnosis away from streptococcus.",
  "WARNING, CLUE ONE — benzathine penicillin was given 5 days ago and the patient has not improved.",
  "Streptococcal pharyngitis responds to penicillin within 24 to 48 hours.",
  "Failure to respond to penicillin means the agent was not streptococcus.",
  "CLUE TWO — a white count of 25,000 with a lymphocyte predominance.",
  "WARNING: IN BACTERIAL INFECTION NEUTROPHILS PREDOMINATE; a lymphocyte predominance means viral.",
  "And cervical plus axillary lymphadenopathy means generalised involvement, not localised streptococcal disease.",
  "So the diagnosis is mononucleosis and its treatment is symptomatic.",
  "WARNING, AND CONTINUING ANTIBIOTICS IS NOT MERELY USELESS BUT DANGEROUS.",
  "Because ampicillin and amoxicillin produce a florid maculopapular rash in mononucleosis.",
  "And prednisolone is not indicated in uncomplicated mononucleosis and is not given routinely.",
  "Steroids have a place only in airway obstruction, haemolytic anaemia or severe thrombocytopenia.",
 ],
 "این سؤال یک الگوی بالینی بسیار واقعی را می‌سنجد: **بیماری که با تشخیص فارنژیت "
 "استرپتوکوکی درمان شده و خوب نشده است.**\n\n"
 "**نوجوان ۱۵ ساله** با **گلودرد ۱۰ روزه**، که **۵ روز پیش یک دوز پنی‌سیلین بنزاتین گرفته**. "
 "اکنون: **اگزودای مشخص روی لوزه‌ها**، **آدنوپاتی گردنی و زیربغلی**، و "
 "**لکوسیت ۲۵۰۰۰ با ارجحیت لنفوسیت**.\n\n"
 "⚠️ **سرنخ یک — و مهم‌ترین سرنخ: عدم پاسخ به پنی‌سیلین.**\n\n"
 "**فارنژیت استرپتوکوکی به پنی‌سیلین ظرف ۲۴ تا ۴۸ ساعت پاسخ می‌دهد** — تب می‌افتد و "
 "گلودرد بهتر می‌شود. اگر ۵ روز گذشته و بیمار **هیچ بهبودی نداشته**، یعنی "
 "**عامل بیماری استرپتوکوک نبوده است**.\n\n"
 "⚠️ **سرنخ دو — الگوی شمارش سلولی.**\n\n"
 "**لکوسیت ۲۵۰۰۰ با ارجحیت لنفوسیت.** این ترکیب مهم است:\n\n"
 "• **عدد بالا** ممکن است ذهن را به سمت عفونت باکتریال ببرد\n"
 "• **ولی غلبه‌ی لنفوسیت، الگوی ویروسی است**، نه باکتریال\n\n"
 "**در عفونت باکتریال، غلبه با نوتروفیل است.** لکوسیتوز لنفوسیتی در یک نوجوان با فارنژیت، "
 "**تقریباً امضای مونونوکلئوز** است.\n\n"
 "**سرنخ سه — لنفادنوپاتی گردنی به‌همراه زیربغلی.** استرپتوکوک **غدد گردنی قدامی موضعی** "
 "می‌دهد. درگیری **زیربغل** یعنی **لنفادنوپاتی ژنرالیزه** — که به مونونوکلئوز می‌خورد.\n\n"
 "**پس تشخیص مونونوکلئوز است و پاسخ: درمان علامتی کفایت می‌کند.** ✅\n\n"
 "⚠️ **و حالا چرا سه گزینه‌ی دیگر نه‌تنها بی‌فایده، که بعضی خطرناک‌اند:**\n\n"
 "**«۱۰ روز پنی‌سیلین خوراکی»** — همان دارویی که **قبلاً شکست خورده**. تکرار یک درمان "
 "ناموفق، منطقی نیست.\n\n"
 "⚠️ **و خطر پنهانش: اگر به‌جای پنی‌سیلین، آموکسی‌سیلین یا آمپی‌سیلین داده شود، در اکثریت "
 "قاطع بیماران مونونوکلئوزی یک راش ماکولوپاپولر وسیع ظاهر می‌شود.** این راش "
 "**آلرژی به پنی‌سیلین نیست** — ولی اگر در پرونده به‌عنوان آلرژی ثبت شود، **تا آخر عمر "
 "انتخاب‌های درمانی بیمار را محدود می‌کند**.\n\n"
 "**«آزیترومایسین ۵ روز»** — بیماری ویروسی است؛ ماکرولید هم کاری نمی‌کند.\n\n"
 "**«پردنیزولون ۵ روز»** — این وسوسه‌انگیزترین گزینه‌ی غلط است. **کورتیکواستروئید در "
 "مونونوکلئوز ساده اندیکاسیون ندارد** و روتین تجویز نمی‌شود. **سه اندیکاسیون استثنایی** "
 "دارد که این بیمار هیچ‌کدام را ندارد: **انسداد راه هوایی** (لوزه‌های چنان بزرگ که تنفس را "
 "مختل کنند)، **آنمی همولیتیک**، و **ترومبوسیتوپنی شدید**.\n\n"
 "**و توصیه‌ی عملی که باید به بیمار داد: پرهیز از ورزش‌های برخوردی تا ۳ تا ۴ هفته**، "
 "به‌خاطر خطر **پارگی طحال**.",
 "This question tests a very real clinical pattern: A PATIENT TREATED FOR STREPTOCOCCAL "
 "PHARYNGITIS WHO HAS NOT IMPROVED.\n\n"
 "A 15-YEAR-OLD with a 10-DAY SORE THROAT who received A DOSE OF BENZATHINE PENICILLIN 5 DAYS AGO. "
 "Now: OBVIOUS TONSILLAR EXUDATE, CERVICAL AND AXILLARY ADENOPATHY, and a WHITE COUNT OF 25,000 "
 "WITH LYMPHOCYTE PREDOMINANCE.\n\n"
 "WARNING, CLUE ONE — AND THE MOST IMPORTANT: FAILURE TO RESPOND TO PENICILLIN.\n\n"
 "STREPTOCOCCAL PHARYNGITIS RESPONDS TO PENICILLIN WITHIN 24 TO 48 HOURS — the fever settles and "
 "the throat improves. If five days have passed with NO IMPROVEMENT AT ALL, then THE AGENT WAS NOT "
 "STREPTOCOCCUS.\n\n"
 "WARNING, CLUE TWO — THE PATTERN OF THE COUNT.\n\n"
 "A WHITE COUNT OF 25,000 WITH LYMPHOCYTE PREDOMINANCE. That combination matters:\n\n"
 "• THE HIGH NUMBER may push the mind towards bacterial infection\n"
 "• BUT A LYMPHOCYTE PREDOMINANCE IS A VIRAL PATTERN, not a bacterial one\n\n"
 "IN BACTERIAL INFECTION NEUTROPHILS PREDOMINATE. A lymphocytic leucocytosis in an adolescent with "
 "pharyngitis is ALMOST THE SIGNATURE OF MONONUCLEOSIS.\n\n"
 "CLUE THREE — CERVICAL PLUS AXILLARY LYMPHADENOPATHY. Streptococcus gives LOCALISED ANTERIOR "
 "CERVICAL nodes. AXILLARY involvement means GENERALISED lymphadenopathy — which fits "
 "mononucleosis.\n\n"
 "SO THE DIAGNOSIS IS MONONUCLEOSIS AND THE ANSWER IS: SYMPTOMATIC TREATMENT SUFFICES.\n\n"
 "WARNING, AND NOW WHY THE OTHER THREE ARE NOT MERELY USELESS BUT SOME OF THEM DANGEROUS:\n\n"
 "'TEN DAYS OF ORAL PENICILLIN' — the very drug that HAS ALREADY FAILED. Repeating an unsuccessful "
 "treatment is not rational.\n\n"
 "WARNING, AND ITS HIDDEN DANGER: if amoxicillin or ampicillin is given instead of penicillin, THE "
 "GREAT MAJORITY OF PATIENTS WITH MONONUCLEOSIS DEVELOP A FLORID MACULOPAPULAR RASH. That rash IS "
 "NOT A PENICILLIN ALLERGY — but if it is recorded as one, IT NARROWS THE PATIENT'S TREATMENT "
 "OPTIONS FOR LIFE.\n\n"
 "'AZITHROMYCIN FOR 5 DAYS' — the illness is viral; a macrolide achieves nothing either.\n\n"
 "'PREDNISOLONE FOR 5 DAYS' — the most tempting wrong option. CORTICOSTEROIDS ARE NOT INDICATED IN "
 "UNCOMPLICATED MONONUCLEOSIS and are not given routinely. They have THREE EXCEPTIONAL INDICATIONS, "
 "none of which this patient has: AIRWAY OBSTRUCTION (tonsils so large they impede breathing), "
 "HAEMOLYTIC ANAEMIA, and SEVERE THROMBOCYTOPENIA.\n\n"
 "AND THE PRACTICAL ADVICE THE PATIENT MUST BE GIVEN: AVOID CONTACT SPORTS FOR 3 TO 4 WEEKS, "
 "because of the risk of SPLENIC RUPTURE.",
 ["پنی‌سیلین قبلاً داده شده و شکست خورده؛ تکرار همان درمان ناموفق منطقی نیست.",
  "بیماری ویروسی است و آزیترومایسین هم مثل پنی‌سیلین هیچ اثری ندارد.",
  "پاسخ صحیح — عدم پاسخ به پنی‌سیلین با لکوسیتوز لنفوسیتی: مونونوکلئوز، و درمان علامتی کافی است.",
  "کورتیکواستروئید در مونونوکلئوز ساده اندیکاسیون ندارد؛ فقط در انسداد راه هوایی یا عوارض خونی."],
 ["Penicillin has already been given and failed; repeating an unsuccessful treatment is not rational.",
  "The illness is viral and azithromycin, like penicillin, achieves nothing.",
  "Correct — failure to respond to penicillin with a lymphocytic leucocytosis is mononucleosis; symptomatic care suffices.",
  "Corticosteroids are not indicated in uncomplicated mononucleosis; only for airway obstruction or haematological complications."],
 "**عدم پاسخ به پنی‌سیلین + لنفوسیتوز = مونونوکلئوز.** و آمپی‌سیلین در آن راش می‌سازد.",
 "No response to penicillin plus lymphocytosis means mononucleosis, and ampicillin in it produces a rash.",
 [H194, REDBOOK])


# =========================================================== book:602
add("book:602", "case", "hard",
 "مونونوکلئوز با **آنمی همولیتیک** ← یکی از سه اندیکاسیون استثنایی **کورتیکواستروئید**.",
 "Mononucleosis with HAEMOLYTIC ANAEMIA is one of the three exceptional indications for CORTICOSTEROIDS.",
 MONO_FA + [
  "**این سؤال دقیقاً استثنا را می‌سنجد، پس اول قاعده را محکم کنید.**",
  "⚠️ **قاعده: در مونونوکلئوز ساده، کورتیکواستروئید تجویز نمی‌شود.**",
  "**چون بیماری خودمحدودشونده است و سرکوب ایمنی، فایده‌ای بر ضررش ندارد.**",
  "**ولی سه استثنا وجود دارد و هر سه را باید بشناسید:**",
  "**یک — انسداد راه هوایی از بزرگی شدید لوزه‌ها و بافت لنفاوی حلق.**",
  "**دو — آنمی همولیتیک اتوایمیون.**",
  "**سه — ترومبوسیتوپنی شدید.**",
  "⚠️ **وجه مشترک هر سه: عارضه‌ای که ایمنی‌واسطه است و خودش تهدید حیات می‌کند.**",
  "**آنمی همولیتیک در مونونوکلئوز از آگلوتینین سرد (ضد آنتی‌ژن i) می‌آید.**",
  "**سرولوژی این بیمار هم تشخیص را تأیید می‌کند: IgM ضد VCA مثبت و IgG منفی.**",
  "**یعنی عفونت حاد اولیه — همان الگویی که در سؤال قبلی توضیح داده شد.**",
  "⚠️ **و آسیکلوویر اینجا هم کمکی نمی‌کند: مشکل ویروس نیست، پاسخ ایمنی است.**",
 ],
 MONO_EN + [
  "This question tests precisely the exception, so first fix the rule firmly in mind.",
  "WARNING, THE RULE: IN UNCOMPLICATED MONONUCLEOSIS, CORTICOSTEROIDS ARE NOT GIVEN.",
  "Because the illness is self-limiting and immunosuppression offers no net benefit.",
  "But three exceptions exist and all three must be known:",
  "ONE — AIRWAY OBSTRUCTION from massive tonsillar and pharyngeal lymphoid enlargement.",
  "TWO — AUTOIMMUNE HAEMOLYTIC ANAEMIA.",
  "THREE — SEVERE THROMBOCYTOPENIA.",
  "WARNING, WHAT THE THREE SHARE: an IMMUNE-MEDIATED complication that is itself life-threatening.",
  "The haemolytic anaemia of mononucleosis arises from COLD AGGLUTININS (anti-i antibodies).",
  "This patient's serology confirms the diagnosis too: IgM anti-VCA positive with IgG negative.",
  "That is acute primary infection — the very pattern explained in the previous question.",
  "WARNING, AND ACICLOVIR DOES NOT HELP HERE EITHER: the problem is not the virus but the immune response.",
 ],
 "این سؤال **استثنا** را می‌سنجد — و برای پاسخ درست، اول باید **قاعده** را محکم بدانید.\n\n"
 "**دختر ۷ ساله** با تب، گلودرد و بی‌حالی شدید، با شواهد **آنمی همولیتیک**. سرولوژی: "
 "**EBV IgM مثبت، EBV IgG منفی**.\n\n"
 "⚠️ **گام یک — سرولوژی را بخوانید.**\n\n"
 "**IgM مثبت با IgG منفی = عفونت حاد اولیه.** این دقیقاً همان الگویی است که در سؤال "
 "سرولوژی EBV توضیح داده شد: **IgM اول می‌آید، IgG بعد**. پس تشخیص **مونونوکلئوز حاد** "
 "قطعی است.\n\n"
 "⚠️ **گام دو — قاعده‌ی درمان را یادآوری کنید:**\n\n"
 "> **در مونونوکلئوز ساده، کورتیکواستروئید تجویز نمی‌شود.**\n\n"
 "چرا؟ چون بیماری **خودمحدودشونده** است و **سرکوب ایمنی در یک عفونت ویروسی فعال**، "
 "فایده‌ای بر ضررش ندارد.\n\n"
 "⚠️ **گام سه — ولی این بیمار ساده نیست. سه استثنا را بشناسید:**\n\n"
 "**۱) انسداد راه هوایی** — وقتی لوزه‌ها و بافت لنفاوی حلق چنان بزرگ شوند که تنفس را "
 "تهدید کنند.\n\n"
 "**۲) آنمی همولیتیک اتوایمیون** ← **همین بیمار.** ✅\n\n"
 "**۳) ترومبوسیتوپنی شدید.**\n\n"
 "**وجه مشترک هر سه:** عارضه‌ای که **ایمنی‌واسطه** است و **خودش تهدید حیات** می‌کند. در "
 "این موارد، **سرکوب همان پاسخ ایمنیِ بیش‌ازحد، درمان است**.\n\n"
 "**و مکانیسم آنمی همولیتیک در مونونوکلئوز جالب است:** از **آگلوتینین سرد** می‌آید — "
 "آنتی‌بادی‌های IgM علیه **آنتی‌ژن i** روی گلبول قرمز، که در جریان پاسخ ایمنی گسترده‌ی "
 "مونونوکلئوز تولید می‌شوند. **یعنی باز هم مشکل، خودِ ویروس نیست؛ واکنش ایمنی است.**\n\n"
 "**و همین توضیح می‌دهد چرا سه گزینه‌ی دیگر غلط‌اند:**\n\n"
 "**آسیکلوویر** — روی ویروس اثر دارد، ولی **مشکل این بیمار ویروس نیست، آنتی‌بادی است**. "
 "ضمناً آسیکلوویر در مونونوکلئوز حتی سیر بیماری اصلی را هم کوتاه نمی‌کند.\n\n"
 "**ریتوکسی‌ماب** — یک آنتی‌بادی مونوکلونال ضد CD20 است که در آنمی همولیتیک **مقاوم به "
 "درمان** جا دارد، نه به‌عنوان **خط اول**.\n\n"
 "**ایمونوگلوبولین** — در ITP جایگاه بهتری دارد و در آنمی همولیتیک اتوایمیون خط اول "
 "نیست.\n\n"
 "**پس: کورتیکواستروئید، خط اول آنمی همولیتیک اتوایمیون در این زمینه.**",
 "This question tests THE EXCEPTION — and to answer it you must first know THE RULE firmly.\n\n"
 "A 7-YEAR-OLD GIRL with fever, sore throat and marked malaise, with evidence of HAEMOLYTIC "
 "ANAEMIA. Serology: EBV IgM POSITIVE, EBV IgG NEGATIVE.\n\n"
 "WARNING, STEP ONE — READ THE SEROLOGY.\n\n"
 "IgM POSITIVE WITH IgG NEGATIVE = ACUTE PRIMARY INFECTION. This is exactly the pattern explained "
 "in the EBV serology question: IgM COMES FIRST, IgG FOLLOWS. So ACUTE MONONUCLEOSIS is certain.\n\n"
 "WARNING, STEP TWO — RECALL THE TREATMENT RULE:\n\n"
 "> IN UNCOMPLICATED MONONUCLEOSIS, CORTICOSTEROIDS ARE NOT GIVEN.\n\n"
 "Why? Because the illness is SELF-LIMITING and IMMUNOSUPPRESSION DURING AN ACTIVE VIRAL INFECTION "
 "offers no net benefit.\n\n"
 "WARNING, STEP THREE — BUT THIS PATIENT IS NOT UNCOMPLICATED. Know the three exceptions:\n\n"
 "1) AIRWAY OBSTRUCTION — when the tonsils and pharyngeal lymphoid tissue enlarge enough to "
 "threaten breathing.\n\n"
 "2) AUTOIMMUNE HAEMOLYTIC ANAEMIA -> THIS PATIENT.\n\n"
 "3) SEVERE THROMBOCYTOPENIA.\n\n"
 "WHAT THE THREE SHARE: a complication that is IMMUNE-MEDIATED and ITSELF LIFE-THREATENING. In "
 "those, SUPPRESSING THE EXCESSIVE IMMUNE RESPONSE IS THE TREATMENT.\n\n"
 "AND THE MECHANISM OF HAEMOLYTIC ANAEMIA IN MONONUCLEOSIS IS INTERESTING: it comes from COLD "
 "AGGLUTININS — IgM antibodies against the i ANTIGEN on red cells, produced during the sweeping "
 "immune response of mononucleosis. SO AGAIN THE PROBLEM IS NOT THE VIRUS BUT THE IMMUNE "
 "REACTION.\n\n"
 "AND THAT EXPLAINS WHY THE OTHER THREE ARE WRONG:\n\n"
 "ACICLOVIR — acts on the virus, but THIS PATIENT'S PROBLEM IS NOT THE VIRUS, IT IS THE ANTIBODY. "
 "Aciclovir does not even shorten the underlying illness in mononucleosis.\n\n"
 "RITUXIMAB — an anti-CD20 monoclonal with a place in REFRACTORY haemolytic anaemia, not as FIRST "
 "LINE.\n\n"
 "IMMUNOGLOBULIN — has a better place in ITP and is not first line in autoimmune haemolytic "
 "anaemia.\n\n"
 "SO: CORTICOSTEROIDS, the first-line treatment for autoimmune haemolytic anaemia in this setting.",
 ["پاسخ صحیح — آنمی همولیتیک یکی از سه استثنای تجویز کورتیکواستروئید در مونونوکلئوز است.",
  "آسیکلوویر روی ویروس اثر دارد ولی مشکل این بیمار ایمنی‌واسطه است، نه تهاجم ویروسی.",
  "ریتوکسی‌ماب در آنمی همولیتیک مقاوم به درمان جا دارد، نه به‌عنوان خط اول.",
  "ایمونوگلوبولین در ITP جایگاه بهتری دارد و در آنمی همولیتیک اتوایمیون خط اول نیست."],
 ["Correct — haemolytic anaemia is one of the three exceptions permitting corticosteroids in mononucleosis.",
  "Aciclovir acts on the virus, but this patient's problem is immune-mediated, not viral invasion.",
  "Rituximab has a place in refractory haemolytic anaemia, not as first-line therapy.",
  "Immunoglobulin has a better place in ITP and is not first line in autoimmune haemolytic anaemia."],
 "**استروئید فقط در سه حالت: انسداد راه هوایی، آنمی همولیتیک، ترومبوسیتوپنی شدید.**",
 "Steroids only in three situations: airway obstruction, haemolytic anaemia and severe thrombocytopenia.",
 [H194, REDBOOK])


# =========================================================== book:607
add("book:607", "case", "medium",
 "زخم‌های **وزیکولوپوستولر دردناک** + علائم سیستمیک + غدد **دوطرفه دردناک** ← **هرپس تناسلی اولیه**.",
 "PAINFUL VESICULOPUSTULAR ulcers with systemic symptoms and BILATERAL TENDER nodes: PRIMARY GENITAL HERPES.",
 HSV_FA + [
  "**سه ویژگی این سؤال، حمله‌ی اولیه‌ی هرپس را از بقیه جدا می‌کنند.**",
  "**یک — ضایعات وزیکولوپوستولر متعدد، نه یک زخم منفرد.**",
  "⚠️ **وزیکول کلمه‌ی کلیدی است: سیفلیس و شانکروئید هرگز با وزیکول شروع نمی‌شوند.**",
  "**دو — علائم سیستمیک: تب، سردرد و بدن‌درد چهار روز پیش از ضایعات.**",
  "**این ویرمی حمله‌ی اولیه است و در عودها تقریباً هرگز دیده نمی‌شود.**",
  "**سه — لنفادنوپاتی اینگوینال دوطرفه و دردناک.**",
  "⚠️ **و همین سه، «اولیه» را از «عود» جدا می‌کنند — که سؤال دقیقاً همین را می‌پرسد.**",
  "**در عود: ضایعات کمتر، بدون علائم سیستمیک، و بهبود سریع‌تر (۵ تا ۷ روز).**",
  "**و اغلب یک پرودروم موضعی دارد: سوزش یا گزگز پیش از ظاهر شدن وزیکول.**",
  "**درمان حمله‌ی اولیه: آسیکلوویر ۴۰۰ میلی‌گرم سه بار در روز، ۷ تا ۱۰ روز.**",
  "⚠️ **و درمان، ویروس را ریشه‌کن نمی‌کند: ویروس در گانگلیون ساکرال مادام‌العمر می‌ماند.**",
  "**پس مشاوره درباره‌ی عود و انتقال، بخشی جدانشدنی از درمان است.**",
 ],
 HSV_EN + [
  "Three features in this stem separate a primary herpes attack from everything else.",
  "ONE — multiple vesiculopustular lesions, not a single ulcer.",
  "WARNING, 'VESICLE' IS THE KEY WORD: syphilis and chancroid never begin as vesicles.",
  "TWO — systemic symptoms: fever, headache and body aches four days before the lesions.",
  "That is the viraemia of a primary attack and is virtually never seen in recurrences.",
  "THREE — bilateral tender inguinal lymphadenopathy.",
  "WARNING, AND THOSE THREE SEPARATE 'PRIMARY' FROM 'RECURRENT' — which is exactly what the question asks.",
  "In a recurrence: fewer lesions, no systemic symptoms, and faster healing (5 to 7 days).",
  "And often a local prodrome: burning or tingling before the vesicles appear.",
  "TREATMENT OF A FIRST ATTACK: aciclovir 400 mg three times daily for 7 to 10 days.",
  "WARNING, AND TREATMENT DOES NOT ERADICATE THE VIRUS: it remains for life in the sacral ganglion.",
  "So counselling about recurrence and transmission is an inseparable part of treatment.",
 ],
 "این سؤال دو کار می‌خواهد: **تشخیص هرپس**، و سپس **تمایز اولیه از عود**.\n\n"
 "**مرد ۲۰ ساله** که **از چهار روز قبل** دچار **تب، سردرد و بدن‌درد** شده، همراه با "
 "**زخم‌های دردناک روی آلت تناسلی**. در معاینه: **زخم‌های متعدد وزیکولوپوستولر** روی تنه‌ی "
 "پنیس و **لنفادنوپاتی دردناک اینگوینال دوطرفه**.\n\n"
 "⚠️ **گام یک — تشخیص: چرا هرپس؟**\n\n"
 "**کلمه‌ی کلیدی «وزیکولوپوستولر» است.**\n\n"
 "به شبکه‌ی زخم تناسلی برگردید: **سیفلیس و شانکروئید هرگز با وزیکول شروع نمی‌شوند**. "
 "سیفلیس یک **پاپول** است که زخمی می‌شود؛ شانکروئید یک **پوستول چرکی** است. "
 "**فقط هرپس با وزیکول‌های گروهی شروع می‌شود** که بعد پوستولی و سپس زخمی می‌شوند.\n\n"
 "**و «دردناک» بودن، سیفلیس را قطعاً حذف می‌کند** (شانکر بی‌درد است).\n\n"
 "⚠️ **گام دو — و حالا سؤال واقعی: اولیه یا عود؟**\n\n"
 "**سه یافته، «اولیه» را قطعی می‌کنند:**\n\n"
 "**۱) علائم سیستمیک.** تب، سردرد و بدن‌درد **چهار روز پیش از ضایعات**. این **ویرمی** است — "
 "بدن برای اولین بار ویروس را می‌بیند و پاسخ سیستمیک می‌دهد. **در عود، ویروس فقط از "
 "گانگلیون به یک درماتوم می‌آید و ویرمی سیستمیک ندارد**، پس تب و بدن‌درد تقریباً هرگز "
 "دیده نمی‌شود.\n\n"
 "**۲) ضایعات متعدد و گسترده.** در عود، ضایعات **کمتر و محدودتر**ند.\n\n"
 "**۳) لنفادنوپاتی دوطرفه و دردناک.** در عود، معمولاً لنفادنوپاتی خفیف یا وجود ندارد.\n\n"
 "**و یک نکته‌ی چهارم که در صورت سؤال هست: «سابقه‌ی بیماری خاصی ندارد»** — یعنی حمله‌ی "
 "قبلی‌ای وجود نداشته.\n\n"
 "**پس: هرپس ژنیتال اولیه.** ✅\n\n"
 "**درمان: آسیکلوویر ۴۰۰ میلی‌گرم سه بار در روز به مدت ۷ تا ۱۰ روز** (یا والاسیکلوویر "
 "۱ گرم دو بار در روز).\n\n"
 "⚠️ **و مهم‌ترین بخش مشاوره، که اغلب فراموش می‌شود:**\n\n"
 "**درمان ویروس را ریشه‌کن نمی‌کند.** ویروس پس از حمله‌ی اولیه به **گانگلیون ساکرال** "
 "می‌رود و **مادام‌العمر** آنجا می‌ماند. بیمار باید بداند:\n\n"
 "• **عود ممکن است** (به‌ویژه در سال اول)\n"
 "• **انتقال حتی بدون ضایعه هم ممکن است** (ریزش بدون علامت)\n"
 "• **در صورت عودهای مکرر (بیش از ۶ بار در سال)، درمان سرکوبگر روزانه گزینه‌ی خوبی است**",
 "This question asks two things: DIAGNOSE THE HERPES, then SEPARATE PRIMARY FROM RECURRENT.\n\n"
 "A 20-YEAR-OLD MAN who FOUR DAYS AGO developed FEVER, HEADACHE AND BODY ACHES, together with "
 "PAINFUL ULCERS ON THE PENIS. On examination: MULTIPLE VESICULOPUSTULAR lesions on the shaft and "
 "BILATERAL TENDER INGUINAL LYMPHADENOPATHY.\n\n"
 "WARNING, STEP ONE — THE DIAGNOSIS: WHY HERPES?\n\n"
 "THE KEY WORD IS 'VESICULOPUSTULAR'.\n\n"
 "Return to the genital-ulcer grid: SYPHILIS AND CHANCROID NEVER BEGIN AS VESICLES. Syphilis is a "
 "PAPULE that ulcerates; chancroid is a PURULENT PUSTULE. ONLY HERPES BEGINS AS GROUPED VESICLES "
 "that then become pustular and ulcerate.\n\n"
 "AND THE LESIONS BEING PAINFUL DEFINITIVELY EXCLUDES SYPHILIS (a chancre is painless).\n\n"
 "WARNING, STEP TWO — AND NOW THE REAL QUESTION: PRIMARY OR RECURRENT?\n\n"
 "THREE FINDINGS MAKE 'PRIMARY' CERTAIN:\n\n"
 "1) SYSTEMIC SYMPTOMS. Fever, headache and body aches FOUR DAYS BEFORE the lesions. That is "
 "VIRAEMIA — the body is meeting the virus for the first time and mounts a systemic response. IN A "
 "RECURRENCE THE VIRUS TRAVELS ONLY FROM THE GANGLION TO ONE DERMATOME AND CAUSES NO SYSTEMIC "
 "VIRAEMIA, so fever and body aches are virtually never seen.\n\n"
 "2) MULTIPLE, EXTENSIVE LESIONS. In a recurrence the lesions are FEWER AND MORE LIMITED.\n\n"
 "3) BILATERAL TENDER LYMPHADENOPATHY. In a recurrence the nodes are usually mild or absent.\n\n"
 "AND A FOURTH POINT IS IN THE STEM: 'no significant past medical history' — meaning there has been "
 "no previous attack.\n\n"
 "SO: PRIMARY GENITAL HERPES.\n\n"
 "TREATMENT: aciclovir 400 mg three times daily for 7 to 10 days (or valaciclovir 1 g twice "
 "daily).\n\n"
 "WARNING, AND THE MOST IMPORTANT PART OF THE COUNSELLING, WHICH IS OFTEN FORGOTTEN:\n\n"
 "TREATMENT DOES NOT ERADICATE THE VIRUS. After the primary attack the virus travels to the SACRAL "
 "GANGLION and remains there FOR LIFE. The patient must know:\n\n"
 "• RECURRENCE IS POSSIBLE (especially in the first year)\n"
 "• TRANSMISSION CAN OCCUR EVEN WITHOUT LESIONS (asymptomatic shedding)\n"
 "• WITH FREQUENT RECURRENCES (more than six a year), DAILY SUPPRESSIVE THERAPY is a good option",
 ["شانکر سیفلیس اولیه بدون درد، سفت و منفرد است و هرگز با وزیکول شروع نمی‌شود.",
  "سیفلیس ثانویه راش منتشر کف دست و پا می‌دهد، نه زخم‌های وزیکولر موضعی دردناک.",
  "پاسخ صحیح — وزیکول‌های دردناک با علائم سیستمیک و غدد دوطرفه: هرپس تناسلی اولیه.",
  "در عود، علائم سیستمیک و لنفادنوپاتی دوطرفه‌ی برجسته تقریباً هرگز دیده نمی‌شود."],
 ["A primary syphilitic chancre is painless, firm and solitary, and never begins as a vesicle.",
  "Secondary syphilis gives a disseminated palmoplantar rash, not localised painful vesicular ulcers.",
  "Correct — painful vesicles with systemic symptoms and bilateral nodes: primary genital herpes.",
  "In a recurrence, systemic symptoms and prominent bilateral lymphadenopathy are virtually never seen."],
 "**وزیکول = هرپس. علائم سیستمیک = حمله‌ی اولیه.** عود ویرمی سیستمیک ندارد.",
 "Vesicles mean herpes, and systemic symptoms mean a primary attack; recurrences have no systemic viraemia.",
 [H191, CDC2021])


# =========================================================== book:611
add("book:611", "case", "hard",
 "**ویتلوی هرپسی** در دندان‌پزشک ← **آسیکلوویر**؛ و هرگز درناژ جراحی نکنید.",
 "HERPETIC WHITLOW in a dentist: ACICLOVIR — and never drain it surgically.",
 HSV_FA + [
  "**سه داده در این سؤال، تشخیص را قطعی می‌کنند و همه عمداً آمده‌اند.**",
  "**یک — شغل: دندان‌پزشک، یعنی تماس مکرر دست با بزاق و مخاط دهان.**",
  "**دو — محل: انگشت. سه — نما: وزیکولوپوستولر و دردناک.**",
  "⚠️ **این ترکیب نام دارد: ویتلوی هرپسی (herpetic whitlow).**",
  "**در کادر درمان، دندان‌پزشک و بهیار شایع است، چون HSV از بزاق منتقل می‌شود.**",
  "**و درد آن معمولاً بسیار شدیدتر از ظاهر ضایعه است — یک سرنخ مهم.**",
  "⚠️ **و مهم‌ترین نکته‌ی این سؤال یک کار است که نباید کرد: درناژ جراحی.**",
  "**ویتلوی هرپسی آبسه نیست؛ یک عفونت ویروسی داخل اپیدرم است.**",
  "**برش زدن آن، ویروس را منتشر می‌کند، بهبود را کند می‌کند و راه عفونت باکتریال ثانویه را باز می‌کند.**",
  "**و گاهی به عوارض جدی مثل انتشار سیستمیک در فرد دچار نقص ایمنی می‌انجامد.**",
  "**درمان: آسیکلوویر خوراکی، و پوشاندن ضایعه برای جلوگیری از انتقال.**",
  "⚠️ **و چون HSV در گانگلیون می‌ماند، عود در همان انگشت ممکن است — دقیقاً مثل سؤال قبلی.**",
 ],
 HSV_EN + [
  "Three data in this stem settle the diagnosis, and all are there deliberately.",
  "ONE — the occupation: a dentist, meaning repeated hand contact with saliva and oral mucosa.",
  "TWO — the site: a finger. THREE — the appearance: vesiculopustular and painful.",
  "WARNING, THAT COMBINATION HAS A NAME: HERPETIC WHITLOW.",
  "It is common in health workers, dentists and nurses, because HSV is carried in saliva.",
  "And its pain is usually far out of proportion to the appearance — an important clue.",
  "WARNING, AND THE MOST IMPORTANT POINT HERE IS SOMETHING NOT TO DO: SURGICAL DRAINAGE.",
  "A herpetic whitlow is not an abscess; it is a viral infection within the epidermis.",
  "Incising it spreads the virus, delays healing and opens the way to secondary bacterial infection.",
  "And it can occasionally lead to serious complications such as systemic spread in an immunocompromised person.",
  "TREATMENT: oral aciclovir, and covering the lesion to prevent transmission.",
  "WARNING, AND BECAUSE HSV PERSISTS IN THE GANGLION, RECURRENCE IN THE SAME FINGER IS POSSIBLE — exactly as in the previous question.",
 ],
 "این سؤال یک تشخیص خاص را می‌سنجد که اگر ندانید، **درمان اشتباهِ خطرناکی** انتخاب "
 "می‌کنید.\n\n"
 "**آقای دندان‌ساز تجربی** با **ضایعه‌ی دردناک انگشت سبابه** با **نمای وزیکولوپوستولر "
 "متورم**، تب مختصر و تندرنس موضعی.\n\n"
 "⚠️ **سه داده، یک تشخیص:**\n\n"
 "**۱) شغل — دندان‌ساز.** یعنی **تماس مکرر انگشتان با بزاق و مخاط دهان** بیماران. و "
 "**HSV در بزاق حضور دارد** — حتی در افرادی که هیچ ضایعه‌ی فعالی ندارند (ریزش بدون علامت).\n\n"
 "**۲) محل — انگشت.**\n\n"
 "**۳) نما — وزیکولوپوستولر و دردناک.**\n\n"
 "**این ترکیب نام دارد: ویتلوی هرپسی (herpetic whitlow).**\n\n"
 "**و یک سرنخ بالینی مهم: درد آن معمولاً بسیار شدیدتر از ظاهر ضایعه است** — یعنی بیمار "
 "درد زیادی دارد در حالی که ضایعه کوچک به نظر می‌رسد.\n\n"
 "⚠️ **و حالا مهم‌ترین بخش این سؤال: کاری که نباید کرد.**\n\n"
 "> **ویتلوی هرپسی را هرگز درناژ جراحی نکنید.**\n\n"
 "**چرا این‌قدر مهم است؟** چون ضایعه‌ی وزیکولوپوستولر و متورم روی انگشت، **دقیقاً شبیه یک "
 "آبسه‌ی باکتریال (پاروناشیا یا فلون) به نظر می‌رسد** — و واکنش غریزی هر پزشکی برش و "
 "درناژ است.\n\n"
 "**ولی این یک آبسه نیست.** یک **عفونت ویروسی داخل اپیدرم** است، بدون چرک تحت فشار. "
 "برش زدن:\n\n"
 "• **ویروس را منتشر می‌کند**\n"
 "• **بهبود را کند می‌کند**\n"
 "• **راه عفونت باکتریال ثانویه را باز می‌کند**\n"
 "• و در فرد دچار نقص ایمنی، می‌تواند به **انتشار سیستمیک** بینجامد\n\n"
 "**پس درمان: آسیکلوویر خوراکی.** ✅ (به‌همراه **پوشاندن ضایعه** برای جلوگیری از انتقال به "
 "بیماران و اطرافیان.)\n\n"
 "**و چرا دو گزینه‌ی دیگر نه؟** **کلیندامایسین** یک آنتی‌بیوتیک است و روی ویروس بی‌اثر. "
 "**فلوکونازول** ضدقارچ است و اینجا اصلاً مطرح نیست.\n\n"
 "⚠️ **و یک نکته‌ی تکمیلی که سؤال دیگری در همین فصل می‌پرسد:** چون HSV در **گانگلیون** "
 "باقی می‌ماند، **عود در همان انگشت ممکن است** — و بیمار با سابقه‌ی «ضایعه‌ی مشابه سال "
 "گذشته» دقیقاً همین را نشان می‌دهد.",
 "This question tests a specific diagnosis, and if you do not know it you will choose A DANGEROUS "
 "WRONG TREATMENT.\n\n"
 "AN INFORMALLY TRAINED DENTIST with a PAINFUL INDEX FINGER LESION of SWOLLEN VESICULOPUSTULAR "
 "appearance, slight fever and local tenderness.\n\n"
 "WARNING, THREE DATA, ONE DIAGNOSIS:\n\n"
 "1) THE OCCUPATION — a dentist. That means REPEATED FINGER CONTACT WITH PATIENTS' SALIVA AND ORAL "
 "MUCOSA. And HSV IS PRESENT IN SALIVA — even in people with no active lesion (asymptomatic "
 "shedding).\n\n"
 "2) THE SITE — a finger.\n\n"
 "3) THE APPEARANCE — vesiculopustular and painful.\n\n"
 "THAT COMBINATION HAS A NAME: HERPETIC WHITLOW.\n\n"
 "AND AN IMPORTANT CLINICAL CLUE: ITS PAIN IS USUALLY FAR OUT OF PROPORTION TO THE APPEARANCE — the "
 "patient hurts a great deal while the lesion looks small.\n\n"
 "WARNING, AND NOW THE MOST IMPORTANT PART OF THIS QUESTION: WHAT NOT TO DO.\n\n"
 "> NEVER SURGICALLY DRAIN A HERPETIC WHITLOW.\n\n"
 "WHY DOES THIS MATTER SO MUCH? Because a swollen vesiculopustular finger lesion LOOKS EXACTLY LIKE "
 "A BACTERIAL ABSCESS (a paronychia or felon) — and every clinician's instinct is to incise and "
 "drain.\n\n"
 "BUT IT IS NOT AN ABSCESS. It is a VIRAL INFECTION WITHIN THE EPIDERMIS, with no pus under "
 "pressure. Incising it:\n\n"
 "• SPREADS THE VIRUS\n"
 "• DELAYS HEALING\n"
 "• OPENS THE WAY TO SECONDARY BACTERIAL INFECTION\n"
 "• and in an immunocompromised person can lead to SYSTEMIC SPREAD\n\n"
 "SO THE TREATMENT IS: ORAL ACICLOVIR (together with COVERING THE LESION to prevent transmission to "
 "patients and contacts).\n\n"
 "AND WHY NOT THE OTHER TWO? CLINDAMYCIN is an antibiotic and inactive against a virus. FLUCONAZOLE "
 "is an antifungal and has no place here at all.\n\n"
 "WARNING, AND A FURTHER POINT ANOTHER QUESTION IN THIS CHAPTER ASKS: because HSV persists in the "
 "GANGLION, RECURRENCE IN THE SAME FINGER IS POSSIBLE — and a patient reporting 'a similar lesion "
 "last year' is showing exactly that.",
 ["فلوکونازول ضدقارچ است و در عفونت هرپسی هیچ جایگاهی ندارد.",
  "کلیندامایسین آنتی‌بیوتیک است و روی ویروس هرپس سیمپلکس بی‌اثر است.",
  "درناژ جراحی خطای خطرناکی است: ویتلوی هرپسی آبسه نیست و برش، ویروس را منتشر می‌کند.",
  "پاسخ صحیح — ویتلوی هرپسی با آسیکلوویر خوراکی درمان می‌شود، نه با جراحی یا آنتی‌بیوتیک."],
 ["Fluconazole is an antifungal and has no place in a herpetic infection.",
  "Clindamycin is an antibiotic and inactive against herpes simplex virus.",
  "Surgical drainage is a dangerous error: a herpetic whitlow is not an abscess and incision spreads the virus.",
  "Correct — herpetic whitlow is treated with oral aciclovir, not with surgery or antibiotics."],
 "**ویتلوی هرپسی آبسه نیست — برش نزنید.** آسیکلوویر، و ضایعه را بپوشانید.",
 "A herpetic whitlow is not an abscess, so do not incise it; give aciclovir and cover the lesion.",
 [H191, CDC2021])


# =========================================================== book:605
add("book:605", "case", "medium",
 "وزیکول‌های منتشر روی زمینه‌ی **اگزمای آتوپیک** ← **اگزمای هرپتیکوم** ← هرپس سیمپلکس.",
 "Disseminated vesicles on a background of ATOPIC ECZEMA: ECZEMA HERPETICUM, caused by herpes simplex.",
 HSV_FA + [
  "**دو داده در این سؤال کنار هم، یک سندرم نام‌دار می‌سازند.**",
  "**داده‌ی یک — سابقه‌ی اگزمای آتوپیک. داده‌ی دو — وزیکول‌های متعدد روی زمینه‌ی اریتماتو.**",
  "⚠️ **این ترکیب نام دارد: اگزمای هرپتیکوم (یا اروپسیون واریسلی‌فرم کاپوزی).**",
  "**عاملش ویروس هرپس سیمپلکس است که روی پوست اگزمایی منتشر می‌شود.**",
  "**چرا روی پوست اگزمایی؟ چون سد دفاعی پوست شکسته است.**",
  "**اپیدرم اگزمایی نقص در سد چربی و پپتیدهای ضدمیکروبی دارد، پس ویروس آزادانه گسترش می‌یابد.**",
  "⚠️ **و این یک فوریت پوستی است، نه یک بیماری خفیف.**",
  "**می‌تواند به عفونت باکتریال ثانویه، از دست دادن مایعات، و در کودک به سپسیس بینجامد.**",
  "**درمان: آسیکلوویر — و در بیمار بدحال یا کودک کوچک، وریدی.**",
  "**و درگیری چشم را حتماً بررسی کنید: کراتیت هرپسی می‌تواند به کوری بینجامد.**",
  "⚠️ **و یک تمایز مهم: استاف اورئوس هم پوست اگزمایی را عفونی می‌کند، ولی با پوسچول و کراست عسلی، نه وزیکول گروهی.**",
 ],
 HSV_EN + [
  "Two data in this stem, together, define a named syndrome.",
  "DATUM ONE — a history of atopic eczema. DATUM TWO — multiple vesicles on an erythematous base.",
  "WARNING, THAT COMBINATION HAS A NAME: ECZEMA HERPETICUM (Kaposi's varicelliform eruption).",
  "Its agent is HERPES SIMPLEX VIRUS disseminating across eczematous skin.",
  "Why on eczematous skin? BECAUSE THE SKIN BARRIER IS BROKEN.",
  "Eczematous epidermis is deficient in lipid barrier and antimicrobial peptides, so the virus spreads freely.",
  "WARNING, AND THIS IS A DERMATOLOGICAL EMERGENCY, not a trivial illness.",
  "It can lead to secondary bacterial infection, fluid loss, and in a child to sepsis.",
  "TREATMENT: aciclovir — intravenously in an unwell patient or a small child.",
  "And always check for eye involvement: herpetic keratitis can end in blindness.",
  "WARNING, AND AN IMPORTANT DISTINCTION: S. aureus also infects eczematous skin, but with pustules and honey-coloured crusts, not grouped vesicles.",
 ],
 "این سؤال یک سندرم نام‌دار را می‌سنجد که **از ترکیب دو داده** ساخته می‌شود.\n\n"
 "**کودکی با سابقه‌ی اگزمای آتوپیک**، با **ضایعات وزیکولر متعدد روی زمینه‌ی اریتماتو در "
 "ناحیه‌ی صورت**.\n\n"
 "⚠️ **دو داده، یک سندرم:**\n\n"
 "**داده‌ی یک — اگزمای آتوپیک.**\n\n"
 "**داده‌ی دو — وزیکول‌های متعدد روی زمینه‌ی اریتماتو.**\n\n"
 "**این ترکیب نام دارد: اگزمای هرپتیکوم** — که به آن **اروپسیون واریسلی‌فرم کاپوزی** هم "
 "می‌گویند. **عاملش ویروس هرپس سیمپلکس است.**\n\n"
 "⚠️ **چرا HSV روی پوست اگزمایی این‌قدر راحت منتشر می‌شود؟**\n\n"
 "این بخش مفهومی است و ارزش فهمیدن دارد. **پوست سالم یک سد دفاعی چندلایه دارد:**\n\n"
 "• **سد فیزیکی** لایه‌ی شاخی\n"
 "• **سد چربی** (سرامیدها)\n"
 "• **پپتیدهای ضدمیکروبی** (دفنسین‌ها و کاتلیسیدین‌ها)\n\n"
 "**در اگزمای آتوپیک، هر سه نقص دارند.** به‌ویژه **کاهش تولید پپتیدهای ضدمیکروبی** در "
 "پوست آتوپیک اثبات شده است. پس وقتی HSV به این پوست می‌رسد، **هیچ مانعی برای گسترش "
 "ندارد** و به‌جای یک ضایعه‌ی موضعی، **صدها وزیکول منتشر** می‌سازد.\n\n"
 "⚠️ **و این یک فوریت پوستی است، نه یک بیماری خفیف:**\n\n"
 "• **عفونت باکتریال ثانویه** (اغلب استاف اورئوس)\n"
 "• **از دست دادن مایعات و الکترولیت** از سطح وسیع پوست آسیب‌دیده\n"
 "• **در کودک کوچک، سپسیس و ویرمی منتشر**\n"
 "• **و اگر نزدیک چشم باشد، کراتیت هرپسی که می‌تواند به کوری بینجامد**\n\n"
 "**درمان: آسیکلوویر.** در بیمار بدحال یا کودک کوچک، **وریدی**.\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "⚠️ **استافیلوکوک اورئوس** — این **بهترین رقیب** است، چون **پوست اگزمایی واقعاً مستعد "
 "عفونت استافی است**. ولی تفاوت در **ریخت ضایعه** است: استاف **پوسچول و کراست عسلی‌رنگ** "
 "می‌سازد (ایمپتیگو)، نه **وزیکول‌های گروهی روی زمینه‌ی اریتماتو**.\n\n"
 "**سودوموناس** — عفونت پوستی‌اش در سوختگی و اوتیت خارجی مطرح است، نه این تابلو.\n\n"
 "**واریسلا زوستر** — آبله‌مرغان راشی **منتشر در کل بدن** با **ضایعات در مراحل مختلف** "
 "می‌سازد، نه ضایعه‌ای که **روی زمینه‌ی اگزمای قبلی و محدود به همان ناحیه** باشد.",
 "This question tests a named syndrome built from THE COMBINATION OF TWO DATA.\n\n"
 "A CHILD WITH A HISTORY OF ATOPIC ECZEMA, with MULTIPLE VESICULAR LESIONS ON AN ERYTHEMATOUS BASE "
 "ON THE FACE.\n\n"
 "WARNING, TWO DATA, ONE SYNDROME:\n\n"
 "DATUM ONE — ATOPIC ECZEMA.\n\n"
 "DATUM TWO — MULTIPLE VESICLES ON AN ERYTHEMATOUS BASE.\n\n"
 "THAT COMBINATION HAS A NAME: ECZEMA HERPETICUM, also called KAPOSI'S VARICELLIFORM ERUPTION. ITS "
 "AGENT IS HERPES SIMPLEX VIRUS.\n\n"
 "WARNING, WHY DOES HSV SPREAD SO EASILY ACROSS ECZEMATOUS SKIN?\n\n"
 "This part is conceptual and worth understanding. HEALTHY SKIN HAS A MULTILAYERED BARRIER:\n\n"
 "• THE PHYSICAL BARRIER of the stratum corneum\n"
 "• THE LIPID BARRIER (ceramides)\n"
 "• ANTIMICROBIAL PEPTIDES (defensins and cathelicidins)\n\n"
 "IN ATOPIC ECZEMA ALL THREE ARE DEFICIENT. In particular, REDUCED ANTIMICROBIAL PEPTIDE PRODUCTION "
 "in atopic skin is well documented. So when HSV reaches such skin it MEETS NO OBSTACLE TO SPREAD, "
 "and instead of one localised lesion it produces HUNDREDS OF DISSEMINATED VESICLES.\n\n"
 "WARNING, AND THIS IS A DERMATOLOGICAL EMERGENCY, NOT A TRIVIAL ILLNESS:\n\n"
 "• SECONDARY BACTERIAL INFECTION (often S. aureus)\n"
 "• FLUID AND ELECTROLYTE LOSS from a large area of damaged skin\n"
 "• IN A SMALL CHILD, SEPSIS AND DISSEMINATED VIRAEMIA\n"
 "• AND IF NEAR THE EYE, HERPETIC KERATITIS, which can end in blindness\n\n"
 "TREATMENT: ACICLOVIR. In an unwell patient or small child, INTRAVENOUSLY.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "WARNING, STAPHYLOCOCCUS AUREUS — THE BEST COMPETITOR, because eczematous skin really is prone to "
 "staphylococcal infection. But the difference is in THE MORPHOLOGY: staphylococcus produces "
 "PUSTULES AND HONEY-COLOURED CRUSTS (impetigo), not GROUPED VESICLES ON AN ERYTHEMATOUS BASE.\n\n"
 "PSEUDOMONAS — its skin infections arise in burns and otitis externa, not this picture.\n\n"
 "VARICELLA ZOSTER — chickenpox produces a rash DISSEMINATED OVER THE WHOLE BODY with LESIONS IN "
 "DIFFERENT STAGES, not an eruption CONFINED TO PRE-EXISTING ECZEMATOUS SKIN.",
 ["استاف اورئوس پوست اگزمایی را عفونی می‌کند ولی با پوسچول و کراست عسلی‌رنگ، نه وزیکول گروهی.",
  "عفونت پوستی سودوموناس در سوختگی و اوتیت خارجی مطرح است، نه این تابلو.",
  "پاسخ صحیح — وزیکول‌های منتشر روی زمینه‌ی اگزمای آتوپیک: اگزمای هرپتیکوم از هرپس سیمپلکس.",
  "آبله‌مرغان راش منتشر در کل بدن با ضایعات در مراحل مختلف می‌دهد، نه ضایعه‌ی محدود به پوست اگزمایی."],
 ["S. aureus infects eczematous skin but with pustules and honey-coloured crusts, not grouped vesicles.",
  "Pseudomonas skin infection arises in burns and otitis externa, not in this picture.",
  "Correct — disseminated vesicles on atopic eczema is eczema herpeticum, caused by herpes simplex.",
  "Chickenpox gives a whole-body rash with lesions in different stages, not an eruption confined to eczematous skin."],
 "**اگزما + وزیکول منتشر = اگزمای هرپتیکوم.** یک فوریت، نه یک راش ساده.",
 "Eczema plus disseminated vesicles means eczema herpeticum: an emergency, not a simple rash.",
 [H191, CDC2021])


# =========================================================== book:613
add("book:613", "case", "medium",
 "شک به **هرپس نوزادی** ← **آسیکلوویر وریدی** فوری، بدون انتظار برای تأیید.",
 "Suspected NEONATAL HERPES: INTRAVENOUS ACICLOVIR at once, without waiting for confirmation.",
 HSV_FA + [
  "**در هرپس نوزادی، سرعت تصمیم مهم‌تر از قطعیت تشخیص است.**",
  "⚠️ **چون مرگ‌ومیر فرم منتشر بدون درمان به بیش از ۸۰ درصد می‌رسد.**",
  "**و نوزاد سیستم ایمنی بالغی ندارد که ویروس را مهار کند.**",
  "**سه شکل بالینی هرپس نوزادی را بشناسید، چون پیش‌آگهی‌شان کاملاً متفاوت است:**",
  "**یک — محدود به پوست، چشم و دهان: بهترین پیش‌آگهی، ولی بدون درمان پیشرفت می‌کند.**",
  "**دو — درگیری سیستم عصبی مرکزی: انسفالیت، با عوارض عصبی ماندگار در بازماندگان.**",
  "**سه — منتشر: درگیری کبد و ریه و انعقاد، با بالاترین مرگ‌ومیر.**",
  "⚠️ **و نکته‌ی مهم: در نیمی از موارد، مادر هیچ سابقه یا ضایعه‌ی شناخته‌شده‌ای ندارد.**",
  "**چون انتقال اغلب از ریزش بدون علامت هنگام زایمان است.**",
  "**پس نبودن ضایعه در مادر، هرپس نوزادی را رد نمی‌کند.**",
  "**داروی انتخابی آسیکلوویر وریدی است، با دوز بالا و مدت ۱۴ تا ۲۱ روز.**",
  "⚠️ **و گان‌سیکلوویر، والاسیکلوویر و فامسیکلوویر هیچ‌کدام جایگزین آن نیستند.**",
 ],
 HSV_EN + [
  "In neonatal herpes, SPEED OF DECISION matters more than certainty of diagnosis.",
  "WARNING, BECAUSE THE MORTALITY OF THE DISSEMINATED FORM UNTREATED EXCEEDS 80 PER CENT.",
  "And a neonate has no mature immune system to contain the virus.",
  "Know the three clinical forms of neonatal herpes, because their prognoses differ completely:",
  "ONE — confined to SKIN, EYE AND MOUTH: the best prognosis, but it progresses if untreated.",
  "TWO — CENTRAL NERVOUS SYSTEM disease: encephalitis, with lasting neurological damage in survivors.",
  "THREE — DISSEMINATED: liver, lung and coagulation involvement, with the highest mortality.",
  "WARNING, AND AN IMPORTANT POINT: in half of cases the mother has NO known history or lesion.",
  "Because transmission is usually from ASYMPTOMATIC SHEDDING at delivery.",
  "So the absence of maternal lesions does not exclude neonatal herpes.",
  "The drug of choice is INTRAVENOUS ACICLOVIR, at high dose for 14 to 21 days.",
  "WARNING, AND GANCICLOVIR, VALACICLOVIR AND FAMCICLOVIR ARE NONE OF THEM SUBSTITUTES.",
 ],
 "این سؤال یک تصمیم فوری را می‌سنجد، و پاسخش کوتاه است — ولی دلایلش را باید بدانید.\n\n"
 "**نوزاد مادری با سابقه‌ی هرپس ژنیتال**، در ICU بستری، **تب‌دار و بدحال**. "
 "**در صورت شک به هرپس نوزادی، چه می‌دهید؟**\n\n"
 "**پاسخ: آسیکلوویر وریدی — فوراً و بدون انتظار برای تأیید آزمایشگاهی.**\n\n"
 "⚠️ **چرا این‌قدر فوری؟**\n\n"
 "**چون مرگ‌ومیر فرم منتشر هرپس نوزادی، بدون درمان، به بیش از ۸۰ درصد می‌رسد.** و "
 "**نوزاد سیستم ایمنی بالغی ندارد** که ویروس را مهار کند. **هر ساعت تأخیر، پیامد را "
 "بدتر می‌کند.**\n\n"
 "**سه شکل بالینی هرپس نوزادی را بشناسید، چون پیش‌آگهی‌شان کاملاً متفاوت است:**\n\n"
 "**۱) محدود به پوست، چشم و دهان (SEM)** — بهترین پیش‌آگهی. **ولی اگر درمان نشود، در "
 "۷۵ درصد موارد به فرم‌های شدیدتر پیشرفت می‌کند.**\n\n"
 "**۲) درگیری سیستم عصبی مرکزی** — انسفالیت، با **عوارض عصبی ماندگار** در بازماندگان.\n\n"
 "**۳) منتشر** — درگیری **کبد، ریه و انعقاد** (شبیه سپسیس باکتریال). **بالاترین "
 "مرگ‌ومیر.**\n\n"
 "**بیمار ما «تب‌دار و بدحال» است — که به فرم منتشر می‌خورد و فوری‌ترین حالت است.**\n\n"
 "⚠️ **و مهم‌ترین نکته‌ی عملی این بلوک:**\n\n"
 "> **در حدود نیمی از موارد هرپس نوزادی، مادر هیچ سابقه یا ضایعه‌ی شناخته‌شده‌ای ندارد.**\n\n"
 "**چرا؟** چون انتقال اغلب از **ریزش بدون علامت** ویروس در دستگاه تناسلی هنگام زایمان "
 "است. **پس نبودن ضایعه در مادر، هرپس نوزادی را رد نمی‌کند** — و در هر نوزاد بدحال با "
 "تابلوی شبه‌سپسیس که به آنتی‌بیوتیک پاسخ نمی‌دهد، **باید به هرپس فکر کرد**.\n\n"
 "**در این بیمار، مادر سابقه‌ی شناخته‌شده دارد — که احتمال را بسیار بالا می‌برد.**\n\n"
 "**دوز: آسیکلوویر وریدی با دوز بالا (۶۰ میلی‌گرم بر کیلوگرم در روز، در سه دوز منقسم)، "
 "به مدت ۱۴ روز در فرم SEM و ۲۱ روز در فرم CNS یا منتشر.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**گان‌سیکلوویر** — داروی **سیتومگالوویروس** است، نه HSV، و **سمیت مغز استخوان** قابل "
 "توجهی دارد.\n\n"
 "**والاسیکلوویر و فامسیکلوویر** — هر دو **پیش‌داروهای خوراکی** هستند. اصلاً **فرم وریدی "
 "ندارند**، و در نوزاد بدحال که به غلظت‌های بالای فوری نیاز دارد، **راه خوراکی پذیرفتنی "
 "نیست**. ضمناً ایمنی‌شان در نوزاد اثبات نشده است.",
 "This question tests an urgent decision, and its answer is short — but you should know the "
 "reasons.\n\n"
 "THE NEONATE OF A MOTHER WITH A HISTORY OF GENITAL HERPES, admitted to intensive care, FEBRILE AND "
 "UNWELL. WITH SUSPECTED NEONATAL HERPES, WHAT DO YOU GIVE?\n\n"
 "THE ANSWER: INTRAVENOUS ACICLOVIR — at once, without waiting for laboratory confirmation.\n\n"
 "WARNING, WHY SO URGENT?\n\n"
 "BECAUSE THE MORTALITY OF DISSEMINATED NEONATAL HERPES, UNTREATED, EXCEEDS 80 PER CENT. And A "
 "NEONATE HAS NO MATURE IMMUNE SYSTEM to contain the virus. EVERY HOUR OF DELAY WORSENS THE "
 "OUTCOME.\n\n"
 "KNOW THE THREE CLINICAL FORMS, because their prognoses differ completely:\n\n"
 "1) CONFINED TO SKIN, EYE AND MOUTH (SEM) — the best prognosis. BUT IF UNTREATED IT PROGRESSES TO "
 "MORE SEVERE FORMS IN 75 PER CENT.\n\n"
 "2) CENTRAL NERVOUS SYSTEM DISEASE — encephalitis, with LASTING NEUROLOGICAL DAMAGE in survivors.\n\n"
 "3) DISSEMINATED — involving LIVER, LUNG AND COAGULATION (resembling bacterial sepsis). THE HIGHEST "
 "MORTALITY.\n\n"
 "Our patient is 'febrile and unwell', which fits the disseminated form and is the most urgent.\n\n"
 "WARNING, AND THE MOST IMPORTANT PRACTICAL POINT IN THIS BLOCK:\n\n"
 "> IN ABOUT HALF OF NEONATAL HERPES CASES THE MOTHER HAS NO KNOWN HISTORY OR LESION.\n\n"
 "WHY? Because transmission is usually from ASYMPTOMATIC GENITAL SHEDDING at delivery. SO THE "
 "ABSENCE OF MATERNAL LESIONS DOES NOT EXCLUDE NEONATAL HERPES — and in any unwell neonate with a "
 "sepsis-like picture unresponsive to antibiotics, HERPES MUST BE CONSIDERED.\n\n"
 "In this patient the mother has a known history, which raises the probability considerably.\n\n"
 "DOSE: high-dose intravenous aciclovir (60 mg/kg/day in three divided doses), for 14 DAYS in SEM "
 "disease and 21 DAYS in CNS or disseminated disease.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "GANCICLOVIR — a CYTOMEGALOVIRUS drug, not an HSV drug, with considerable MARROW TOXICITY.\n\n"
 "VALACICLOVIR AND FAMCICLOVIR — both are ORAL PRODRUGS. They HAVE NO INTRAVENOUS FORM at all, and "
 "in an unwell neonate needing immediate high concentrations THE ORAL ROUTE IS NOT ACCEPTABLE. Their "
 "safety in neonates is also not established.",
 ["پاسخ صحیح — هرپس نوزادی با آسیکلوویر وریدی و بدون انتظار برای تأیید درمان می‌شود.",
  "گان‌سیکلوویر داروی سیتومگالوویروس است، نه هرپس سیمپلکس، و سمیت مغز استخوان دارد.",
  "والاسیکلوویر یک پیش‌داروی خوراکی است و اصلاً فرم وریدی ندارد؛ در نوزاد بدحال مناسب نیست.",
  "فامسیکلوویر نیز خوراکی است و ایمنی و اثربخشی‌اش در نوزاد اثبات نشده است."],
 ["Correct — neonatal herpes is treated with intravenous aciclovir without waiting for confirmation.",
  "Ganciclovir is a cytomegalovirus drug, not an HSV drug, and is marrow toxic.",
  "Valaciclovir is an oral prodrug with no intravenous form; it is unsuitable in an unwell neonate.",
  "Famciclovir is likewise oral and its safety and efficacy in neonates are not established."],
 "**نوزاد بدحال + شک به هرپس = آسیکلوویر وریدی فوری.** نیمی از مادران سابقه ندارند.",
 "An unwell neonate with suspected herpes needs immediate intravenous aciclovir; half the mothers have no history.",
 [H191, CDC2021])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book34.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 34 lessons:', len(L))
