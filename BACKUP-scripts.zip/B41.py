# -*- coding: utf-8 -*-
"""Micro-lessons, batch 41 — the amoeba, giardia and leishmania block.

This opens the parasitology and malaria chapter, the largest chapter still
untaught (81 of 101 questions had no lesson before this batch).

THE ONE RULE THAT DECIDES EIGHT QUESTIONS IN A ROW
---------------------------------------------------
Amoebiasis is asked over and over in this book, and every single item is
decided by ONE two-part rule:

    KILL THE TISSUE FORM, THEN KILL WHAT IS LEFT IN THE LUMEN.

    invasive disease (dysentery, liver abscess)
        a nitroimidazole  (metronidazole or tinidazole)
        FOLLOWED BY a luminal agent (paromomycin or iodoquinol)

    asymptomatic cyst passer
        a LUMINAL AGENT ALONE (paromomycin or iodoquinol) — no nitroimidazole,
        because there is no tissue invasion to treat

The reason the second drug is never optional is pharmacological, not
ceremonial: metronidazole is absorbed almost completely in the small bowel, so
very little of it ever reaches the colonic lumen where the cysts sit. A patient
treated with metronidazole alone is cured of the dysentery and still passes
infective cysts in about one case in ten.

WHY AN ASYMPTOMATIC CYST PASSER IS TREATED AT ALL
--------------------------------------------------
Two separate reasons, and questions in this book test both:
  * PUBLIC HEALTH — a food handler shedding cysts infects the people he cooks
    for. Two items here are explicitly about a kitchen worker applying for a
    health card.
  * THE PATIENT'S OWN RISK — a carrier who is later immunosuppressed can
    convert to invasive disease. One item here is a man on prednisolone for
    pemphigus, and that is exactly why he is treated rather than watched.

SEROLOGY IS WHAT SEPARATES AN AMOEBIC FROM A PYOGENIC LIVER ABSCESS
--------------------------------------------------------------------
Imaging cannot do it: both are round hypodense liver lesions. Stool microscopy
cannot do it either — the stool is NEGATIVE in most amoebic liver abscesses,
because the bowel phase is long over by the time the abscess forms. Amoebic
SEROLOGY is positive in more than 90 % of them, and that is the answer.

And the same fact settles the treatment question: an amoebic liver abscess is
a MEDICAL disease. Drainage is reserved for a large left-lobe abscess
threatening the pericardium, for imminent rupture, or for failure to respond
after several days.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022) —
the chapters on amoebiasis and other protozoal intestinal infections, on
giardiasis, and on leishmaniasis.
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — "
     "the protozoal infection chapters")
HGI = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — "
       "amebiasis and infection with free-living amebas")
HLEISH = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — "
          "leishmaniasis")

# ======================================================== AMOEBA: THE CORE RULE
AMB_FA = [
    "⚠️ **کل بلوک آمیب با یک قاعده‌ی دوقسمتی حل می‌شود: اول فرم بافتی، بعد فرم داخل روده.**",
    "**بیماری مهاجم (دیسانتری یا آبسه‌ی کبد): نیتروایمیدازول + سپس داروی لومینال.**",
    "**نیتروایمیدازول یعنی مترونیدازول یا تینیدازول؛ لومینال یعنی پارومومایسین یا یدوکینول.**",
    "**ناقل بدون علامت: فقط داروی لومینال — نیتروایمیدازول لازم نیست.**",
    "⚠️ **چرا داروی دوم هرگز اختیاری نیست؟ دلیلش دارویی است، نه تشریفاتی.**",
    "**مترونیدازول تقریباً به‌طور کامل در روده‌ی باریک جذب می‌شود.**",
    "**پس مقدار بسیار کمی از آن به لومن کولون می‌رسد، همان جایی که کیست‌ها هستند.**",
    "**نتیجه: بیمار از دیسانتری خوب می‌شود ولی همچنان کیست عفونی دفع می‌کند.**",
    "⚠️ **در حدود یک نفر از هر ده بیمار که فقط مترونیدازول گرفته، این اتفاق می‌افتد.**",
    "**و به همین دلیل درمان تک‌دارویی بیماری مهاجم، درمان ناقص شمرده می‌شود.**",
    "**برعکس، در ناقل بدون علامت هیچ بافتی درگیر نیست که نیتروایمیدازول بخواهد.**",
    "**پس دادن مترونیدازول به او فقط عارضه است بدون سود.**",
    "**آنتاموبا هیستولیتیکا از راه خوردن کیست در آب یا غذای آلوده منتقل می‌شود.**",
    "**تروفوزوئیت شکل مهاجم است؛ کیست شکل مقاوم و انتقال‌دهنده.**",
    "⚠️ **تروفوزوئیتِ حاوی گلبول قرمز بلعیده‌شده، نشانه‌ی قطعی گونه‌ی مهاجم است.**",
]
AMB_EN = [
    "WARNING: THE WHOLE AMOEBA BLOCK IS SOLVED BY ONE TWO-PART RULE — tissue form first, then the luminal form.",
    "INVASIVE DISEASE (dysentery or liver abscess): a NITROIMIDAZOLE, FOLLOWED BY a LUMINAL AGENT.",
    "Nitroimidazole means metronidazole or tinidazole; luminal agent means paromomycin or iodoquinol.",
    "ASYMPTOMATIC CARRIER: a LUMINAL AGENT ALONE — no nitroimidazole is needed.",
    "WARNING, WHY IS THE SECOND DRUG NEVER OPTIONAL? The reason is pharmacological, not ceremonial.",
    "Metronidazole is absorbed almost completely in the small bowel.",
    "So very little of it ever reaches the colonic lumen, which is exactly where the cysts sit.",
    "The result: the patient is cured of the dysentery and still passes infective cysts.",
    "WARNING, THIS HAPPENS IN ROUGHLY ONE IN TEN PATIENTS treated with metronidazole alone.",
    "And that is why single-drug therapy of invasive disease counts as INCOMPLETE treatment.",
    "Conversely, in an asymptomatic carrier there is no invaded tissue for a nitroimidazole to treat.",
    "So giving him metronidazole is toxicity without benefit.",
    "Entamoeba histolytica is acquired by swallowing CYSTS in contaminated water or food.",
    "The TROPHOZOITE is the invasive form; the CYST is the hardy, transmitting form.",
    "WARNING: A TROPHOZOITE CONTAINING INGESTED RED CELLS is the definitive sign of the invasive species.",
]

AMB_REFS = [HGI]

add("book:728", "recall", "medium",
    "**در افتراق آبسه‌ی آمیبی از آبسه‌ی چرکی کبد، سرولوژی آمیب پاسخ می‌دهد — تصویربرداری نه.**",
    "In separating an amoebic from a pyogenic liver abscess, AMOEBIC SEROLOGY is what answers — imaging is not.",
    [
        "⚠️ **دو آبسه‌ی کبدی روی سونوگرافی و س‌ی‌تی عملاً یکسان دیده می‌شوند.**",
        "**هر دو ضایعه‌ی گرد و هیپودنس‌اند؛ شکل ضایعه تشخیص را نمی‌دهد.**",
        "**پس چیزی لازم است که خود ارگانیسم را نشان دهد، نه شکل حفره را.**",
        "⚠️ **سرولوژی آمیب در بیش از ۹۰ درصد آبسه‌های آمیبی کبد مثبت است.**",
        "**و همین آن را به تست انتخابی برای این افتراق تبدیل می‌کند.**",
        "**اسمیر مدفوع اینجا کمکی نمی‌کند و دلیلش مهم است.**",
        "**در زمان تشکیل آبسه، مرحله‌ی روده‌ای معمولاً مدت‌هاست تمام شده است.**",
        "**پس مدفوع در بیشتر آبسه‌های آمیبی کبد از نظر انگل منفی است.**",
        "⚠️ **یعنی مدفوع منفی، آبسه‌ی آمیبی را رد نمی‌کند — این تله‌ی رایج امتحان است.**",
        "**آبسه‌ی آمیبی معمولاً منفرد و در لوب راست کبد است.**",
        "**محتوای آن به رنگ «خمیر آنچوی» توصیف می‌شود و معمولاً استریل است.**",
        "**در مقابل، آبسه‌ی چرکی اغلب چندتایی است و کشت خون یا چرک مثبت می‌دهد.**",
        "**نکته‌ی محدودیت سرولوژی: در منطقه‌ی اندمیک، تیتر مثبت ممکن است باقی‌مانده‌ی عفونت قدیمی باشد.**",
        "**ولی در ایران و در بیمار با تابلوی حاد، سرولوژی مثبت ارزش تشخیصی بالایی دارد.**",
    ],
    [
        "WARNING: THE TWO LIVER ABSCESSES LOOK PRACTICALLY IDENTICAL on ultrasound and CT.",
        "Both are round hypodense lesions; the SHAPE of the lesion does not make the diagnosis.",
        "So something is needed that shows the ORGANISM, not the shape of the cavity.",
        "WARNING: AMOEBIC SEROLOGY IS POSITIVE IN MORE THAN 90% of amoebic liver abscesses.",
        "And that makes it the test of choice for this particular distinction.",
        "A stool smear does not help here, and the reason matters.",
        "By the time the abscess forms, the intestinal phase is usually long over.",
        "So the stool is NEGATIVE for the parasite in most amoebic liver abscesses.",
        "WARNING, THAT MEANS A NEGATIVE STOOL DOES NOT EXCLUDE an amoebic abscess — the classic exam trap.",
        "An amoebic abscess is usually SOLITARY and in the RIGHT lobe.",
        "Its contents are described as 'anchovy paste' and are usually sterile.",
        "A pyogenic abscess, by contrast, is often MULTIPLE and yields positive blood or pus cultures.",
        "One limitation of serology: in an endemic area a positive titre may be residue of an old infection.",
        "But in Iran, in a patient with an acute picture, a positive serology carries high diagnostic value.",
    ],
    "این سؤال یک افتراق بالینی روزمره را می‌پرسد: بیماری با آبسه‌ی کبد آمده و باید بدانیم "
    "آمیبی است یا چرکی، چون **درمان این دو کاملاً فرق می‌کند** — آمیبی با دارو حل می‌شود و "
    "چرکی معمولاً نیاز به تخلیه و آنتی‌بیوتیک وسیع‌الطیف دارد.\n\n"
    "⚠️ **چرا تصویربرداری جواب نمی‌دهد؟** چون هر دو روی سونوگرافی و س‌ی‌تی به شکل **ضایعه‌ی "
    "گرد و هیپودنس** دیده می‌شوند. MRI با کنتراست هم همین را با وضوح بیشتر نشان می‌دهد ولی "
    "**ماهیت** ضایعه را روشن نمی‌کند. تصویربرداری به ما می‌گوید آبسه **هست**، نه اینکه **چیست**.\n\n"
    "⚠️ **چرا اسمیر مدفوع جواب نمی‌دهد؟** این نکته‌ی کلیدی سؤال است. آبسه‌ی آمیبی کبد "
    "**هفته‌ها تا ماه‌ها پس از مرحله‌ی روده‌ای** شکل می‌گیرد. تا آن زمان انگل معمولاً از روده "
    "پاک شده است، بنابراین **در بیشتر آبسه‌های آمیبی کبد، مدفوع منفی است**. اگر دانشجو این را "
    "نداند، با دیدن مدفوع منفی تشخیص درست را کنار می‌گذارد.\n\n"
    "**پس چه می‌ماند؟ سرولوژی آمیب.** آنتی‌بادی ضد آنتاموبا هیستولیتیکا **در بیش از ۹۰ درصد** "
    "موارد آبسه‌ی آمیبی کبد مثبت است، و این حساسیت بالا دقیقاً همان چیزی است که برای رد کردن "
    "یک تشخیص لازم داریم.\n\n"
    "**تفاوت‌های کمکی دیگر که خوب است بدانید:**\n\n"
    "آبسه‌ی آمیبی معمولاً **منفرد** و در **لوب راست** است؛ محتوای آن **«خمیر آنچوی»** و "
    "معمولاً **استریل** است. آبسه‌ی چرکی بیشتر **چندتایی** است، اغلب منشأ صفراوی یا شکمی دارد، "
    "و **کشت خون یا کشت چرک مثبت** می‌شود.",
    "This question asks an everyday clinical distinction: a patient has a liver abscess and we must "
    "know whether it is amoebic or pyogenic, because THE TREATMENTS ARE COMPLETELY DIFFERENT — the "
    "amoebic one is solved with drugs, while the pyogenic one usually needs drainage plus "
    "broad-spectrum antibiotics.\n\n"
    "WARNING, WHY DOES IMAGING NOT ANSWER IT? Because both appear as A ROUND HYPODENSE LESION on "
    "ultrasound and CT. Contrast MRI shows the same thing more sharply but still does not reveal the "
    "NATURE of the lesion. Imaging tells us an abscess IS THERE, not WHAT IT IS.\n\n"
    "WARNING, WHY DOES A STOOL SMEAR NOT ANSWER IT? This is the key point of the question. An amoebic "
    "liver abscess forms WEEKS TO MONTHS AFTER the intestinal phase. By then the parasite has usually "
    "cleared from the bowel, so THE STOOL IS NEGATIVE IN MOST AMOEBIC LIVER ABSCESSES. A student who "
    "does not know this will see a negative stool and discard the correct diagnosis.\n\n"
    "SO WHAT IS LEFT? AMOEBIC SEROLOGY. Antibody against Entamoeba histolytica is positive in MORE "
    "THAN 90% of amoebic liver abscesses, and that high sensitivity is exactly what is needed to rule "
    "a diagnosis out.\n\n"
    "OTHER USEFUL DIFFERENCES WORTH KNOWING:\n\n"
    "The amoebic abscess is usually SOLITARY and in the RIGHT lobe; its contents are 'ANCHOVY PASTE' "
    "and usually STERILE. The pyogenic abscess is more often MULTIPLE, frequently of biliary or "
    "abdominal origin, and yields POSITIVE BLOOD OR PUS CULTURES.",
    ["مدفوع در زمان تشکیل آبسه معمولاً منفی است، چون مرحله‌ی روده‌ای مدت‌هاست تمام شده.",
     "سونوگرافی وجود آبسه را نشان می‌دهد ولی ماهیت آمیبی یا چرکی را روشن نمی‌کند.",
     "MRI با کنتراست هم فقط تصویر بهتری می‌دهد؛ ماهیت ضایعه را تعیین نمی‌کند.",
     "پاسخ صحیح — سرولوژی آمیب در بیش از ۹۰ درصد آبسه‌های آمیبی کبد مثبت است."],
    ["The stool is usually negative when the abscess forms, because the intestinal phase is long over.",
     "Ultrasound shows that an abscess exists but does not tell amoebic from pyogenic.",
     "Contrast MRI likewise only gives a better picture; it does not determine the nature of the lesion.",
     "Correct — amoebic serology is positive in more than 90% of amoebic liver abscesses."],
    "**آبسه‌ی آمیبی کبد: مدفوع منفی، سرولوژی مثبت.**",
    "Amoebic liver abscess: stool negative, serology positive.",
    AMB_REFS)

add("book:729", "recall", "easy",
    "**تروفوزوئیت آنتاموبا هیستولیتیکا یعنی بیماری مهاجم — و درمان آن مترونیدازول است.**",
    "A trophozoite of Entamoeba histolytica means INVASIVE disease — and the treatment is METRONIDAZOLE.",
    AMB_FA + [
        "**در این بیمار، دیدن تروفوزوئیت یعنی انگل به دیواره‌ی روده حمله کرده است.**",
        "**پس گام اول قطعاً یک نیتروایمیدازول است: مترونیدازول.**",
        "⚠️ **و پس از آن، داروی لومینال برای ریشه‌کنی کیست‌های باقی‌مانده لازم است.**",
        "**آنتی‌بیوتیک‌های ضدباکتریایی مثل سیپروفلوکساسین روی آمیب اثری ندارند.**",
        "**چون آمیب یک تک‌یاخته است، نه باکتری — هدف دارویی کاملاً متفاوتی دارد.**",
    ],
    AMB_EN + [
        "In this patient, seeing a trophozoite means the parasite has invaded the bowel wall.",
        "So the first step is definitely a nitroimidazole: METRONIDAZOLE.",
        "WARNING, AND AFTER IT a luminal agent is needed to eradicate the remaining cysts.",
        "Antibacterial antibiotics such as ciprofloxacin have no effect on amoebae.",
        "Because an amoeba is a protozoan, not a bacterium — an entirely different drug target.",
    ],
    "این ساده‌ترین سؤال بلوک آمیب است و به همین دلیل ارزش دارد که قاعده را از روی آن محکم یاد بگیرید.\n\n"
    "**تروفوزوئیت آنتاموبا هیستولیتیکا در مدفوع بیماری که اسهال خونی دارد یعنی: بیماری مهاجم.** "
    "تروفوزوئیت شکلی است که به مخاط حمله می‌کند و زخم‌های «فلاسک‌شکل» کلاسیک را می‌سازد؛ "
    "خونریزی از همین زخم‌ها همان دیسانتری است.\n\n"
    "⚠️ **درمان بیماری مهاجم همیشه با یک نیتروایمیدازول شروع می‌شود** — مترونیدازول یا "
    "تینیدازول. اینجا مترونیدازول تنها گزینه‌ی این خانواده در میان چهار گزینه است، پس پاسخ روشن است.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟** هر سه آنتی‌بیوتیک ضدباکتریایی‌اند: سیپروفلوکساسین، "
    "سفکسیم و کوتریموکسازول. **آمیب باکتری نیست، تک‌یاخته است**، و این داروها اصلاً هدف دارویی "
    "روی آن ندارند. دادن آن‌ها بیمار را درمان نمی‌کند و فقط فلور طبیعی روده را به‌هم می‌ریزد.\n\n"
    "⚠️ **و نکته‌ای که سؤال نپرسیده ولی امتحان بعدی خواهد پرسید:** مترونیدازول به‌تنهایی کافی "
    "نیست. چون تقریباً کامل در روده‌ی باریک جذب می‌شود، به لومن کولون نمی‌رسد و **کیست‌ها زنده "
    "می‌مانند**. پس پس از مترونیدازول باید **پارومومایسین یا یدوکینول** داد.",
    "This is the simplest question in the amoeba block, and for that reason it is worth using it to fix "
    "the rule firmly.\n\n"
    "A TROPHOZOITE OF ENTAMOEBA HISTOLYTICA in the stool of a patient with bloody diarrhoea means: "
    "INVASIVE DISEASE. The trophozoite is the form that invades the mucosa and creates the classic "
    "'flask-shaped' ulcers; bleeding from those ulcers is the dysentery itself.\n\n"
    "WARNING, TREATMENT OF INVASIVE DISEASE ALWAYS STARTS WITH A NITROIMIDAZOLE — metronidazole or "
    "tinidazole. Here metronidazole is the only member of that family among the four options, so the "
    "answer is clear.\n\n"
    "WHY ARE THE OTHER THREE REJECTED? All three are ANTIBACTERIAL antibiotics: ciprofloxacin, "
    "cefixime and co-trimoxazole. AN AMOEBA IS NOT A BACTERIUM, IT IS A PROTOZOAN, and these drugs "
    "have no drug target on it at all. Giving them does not treat the patient and merely disrupts the "
    "normal bowel flora.\n\n"
    "WARNING, AND THE POINT THIS QUESTION DID NOT ASK BUT THE NEXT EXAM WILL: metronidazole alone is "
    "not enough. Because it is absorbed almost completely in the small bowel, it does not reach the "
    "colonic lumen and THE CYSTS SURVIVE. So metronidazole must be followed by PAROMOMYCIN OR "
    "IODOQUINOL.",
    ["پاسخ صحیح — تروفوزوئیت یعنی بیماری مهاجم، و درمان آن نیتروایمیدازول است.",
     "آنتی‌بیوتیک ضدباکتریایی است و روی تک‌یاخته اثری ندارد.",
     "سفالوسپورین خوراکی است؛ هیچ فعالیت ضدآمیبی ندارد.",
     "برای اسهال‌های باکتریایی و پنوموسیستیس کاربرد دارد، نه برای آمیب."],
    ["Correct — a trophozoite means invasive disease, and its treatment is a nitroimidazole.",
     "An antibacterial agent with no effect on a protozoan.",
     "An oral cephalosporin; it has no antiamoebic activity whatsoever.",
     "Used for bacterial diarrhoea and for Pneumocystis, not for amoebae."],
    "**تروفوزوئیت = مهاجم = مترونیدازول، و بعد داروی لومینال.**",
    "Trophozoite = invasive = metronidazole, then a luminal agent.",
    AMB_REFS)

add("book:731", "vignette", "medium",
    "**دیسانتری آمیبی با تروفوزوئیت مهاجم: مترونیدازول + یدوکینول — درمان دومرحله‌ای کامل.**",
    "Amoebic dysentery with an invasive trophozoite: METRONIDAZOLE PLUS IODOQUINOL — the complete two-stage treatment.",
    AMB_FA + [
        "**در این بیمار هم گلبول سفید و هم گلبول قرمز فراوان در مدفوع هست: التهاب مهاجم.**",
        "**و تروفوزوئیت هیستولیتیکا تشخیص را قطعی می‌کند.**",
        "⚠️ **پس هر دو مرحله لازم است، و تنها گزینه‌ای که هر دو را دارد پاسخ است.**",
        "**یدوکینول یک داروی لومینال است که جذب سیستمیک ناچیزی دارد.**",
        "**همین جذب‌نشدن، خاصیت اصلی آن است: در لومن می‌ماند و کیست‌ها را می‌کشد.**",
    ],
    AMB_EN + [
        "In this patient the stool shows both abundant white cells and red cells: invasive inflammation.",
        "And the histolytica trophozoite makes the diagnosis definitive.",
        "WARNING, SO BOTH STAGES ARE REQUIRED, and the only option carrying both is the answer.",
        "Iodoquinol is a luminal agent with negligible systemic absorption.",
        "That very lack of absorption is its point: it stays in the lumen and kills the cysts.",
    ],
    "این سؤال همان قاعده‌ی دومرحله‌ای را می‌سنجد، ولی این بار **هر دو مرحله را در یک گزینه** "
    "می‌خواهد.\n\n"
    "**تابلوی بیمار: بیماری مهاجم است.** مرد ۶۰ ساله با تب و دیسانتری، و در مدفوع هم گلبول سفید "
    "فراوان (نشانه‌ی التهاب) و هم گلبول قرمز فراوان (نشانه‌ی زخم) دیده می‌شود. **تروفوزوئیت "
    "آنتاموبا هیستولیتیکا** تشخیص را قطعی می‌کند.\n\n"
    "⚠️ **درمان کامل یعنی: مترونیدازول (فرم بافتی) + یدوکینول (فرم لومینال).** گزینه‌ی اول "
    "دقیقاً همین است.\n\n"
    "**چرا بقیه رد می‌شوند؟**\n\n"
    "**سیپروفلوکساسین + پارومومایسین:** پارومومایسین درست است ولی سیپروفلوکساسین جای "
    "نیتروایمیدازول را نمی‌گیرد — فرم بافتی بدون درمان می‌ماند.\n\n"
    "**تینیدازول + اسپکتینومایسین:** تینیدازول یک نیتروایمیدازول درست است، ولی **اسپکتینومایسین "
    "داروی گنوکوک است** و هیچ نقشی در آمیبیازیس ندارد.\n\n"
    "⚠️ **درمان علامتی و مایع‌درمانی:** این خطرناک‌ترین گزینه است. آمیبیازیس مهاجم درمان‌نشده "
    "می‌تواند به **کولیت فولمینانت، مگاکولون توکسیک، پرفوراسیون یا آبسه‌ی کبد** برسد. "
    "مایع‌درمانی درمان حمایتی است، نه درمان انگل.",
    "This question tests the same two-stage rule, but this time it wants BOTH STAGES IN ONE OPTION.\n\n"
    "THE PICTURE: this is invasive disease. A 60-year-old man with fever and dysentery, and the stool "
    "shows both abundant white cells (inflammation) and abundant red cells (ulceration). The ENTAMOEBA "
    "HISTOLYTICA TROPHOZOITE makes the diagnosis definitive.\n\n"
    "WARNING, COMPLETE TREATMENT MEANS: METRONIDAZOLE (tissue form) PLUS IODOQUINOL (luminal form). "
    "The first option is exactly that.\n\n"
    "WHY ARE THE OTHERS REJECTED?\n\n"
    "CIPROFLOXACIN PLUS PAROMOMYCIN: the paromomycin is right, but ciprofloxacin does not substitute "
    "for a nitroimidazole — the tissue form is left untreated.\n\n"
    "TINIDAZOLE PLUS SPECTINOMYCIN: tinidazole is a correct nitroimidazole, but SPECTINOMYCIN IS A "
    "GONOCOCCAL DRUG and has no role in amoebiasis.\n\n"
    "WARNING, SYMPTOMATIC TREATMENT AND ORAL REHYDRATION: this is the most dangerous option. Untreated "
    "invasive amoebiasis can progress to FULMINANT COLITIS, TOXIC MEGACOLON, PERFORATION OR LIVER "
    "ABSCESS. Rehydration is supportive care, not treatment of the parasite.",
    ["پاسخ صحیح — نیتروایمیدازول برای فرم بافتی به‌علاوه‌ی داروی لومینال برای کیست‌ها.",
     "پارومومایسین درست است ولی سیپروفلوکساسین جایگزین نیتروایمیدازول نمی‌شود.",
     "اسپکتینومایسین داروی گنوکوک است و در آمیبیازیس هیچ نقشی ندارد.",
     "آمیبیازیس مهاجم درمان‌نشده می‌تواند به کولیت فولمینانت و آبسه‌ی کبد برسد."],
    ["Correct — a nitroimidazole for the tissue form plus a luminal agent for the cysts.",
     "The paromomycin is right, but ciprofloxacin does not substitute for a nitroimidazole.",
     "Spectinomycin is a gonococcal drug and has no role in amoebiasis.",
     "Untreated invasive amoebiasis can progress to fulminant colitis and liver abscess."],
    "**بیماری مهاجم = نیتروایمیدازول + داروی لومینال، هر دو با هم.**",
    "Invasive disease = nitroimidazole PLUS luminal agent, both together.",
    AMB_REFS)

add("book:732", "vignette", "medium",
    "**تروفوزوئیت حاوی گلبول قرمز، امضای گونه‌ی مهاجم است — و درمان همان دو مرحله را می‌خواهد.**",
    "A trophozoite CONTAINING RED CELLS is the signature of the invasive species — and the treatment is the same two stages.",
    AMB_FA + [
        "⚠️ **گلبول قرمز بلعیده‌شده داخل تروفوزوئیت، هیستولیتیکا را از گونه‌های بی‌آزار جدا می‌کند.**",
        "**آنتاموبا دیسپار از نظر شکلی با هیستولیتیکا یکسان است ولی بیماری‌زا نیست.**",
        "**تنها هیستولیتیکای مهاجم است که گلبول قرمز می‌بلعد.**",
        "**پس این یافته درمان را توجیه می‌کند، نه فقط تشخیص را.**",
        "**داکسی‌سیکلین و تینیدازول-داکسی‌سیکلین هیچ‌کدام پوشش لومینال ندارند.**",
    ],
    AMB_EN + [
        "WARNING: AN INGESTED RED CELL INSIDE THE TROPHOZOITE separates histolytica from the harmless species.",
        "Entamoeba dispar is morphologically identical to histolytica but is not pathogenic.",
        "Only invasive histolytica ingests red cells.",
        "So this finding justifies the treatment, not merely the diagnosis.",
        "Neither doxycycline nor tinidazole-plus-doxycycline provides any luminal cover.",
    ],
    "این سؤال یک نکته‌ی میکروسکوپی را وارد قاعده می‌کند که ارزش امتحانی بالایی دارد.\n\n"
    "⚠️ **تروفوزوئیت حاوی گلبول قرمز (اریتروفاگوسیتوز) امضای آنتاموبا هیستولیتیکای مهاجم است.** "
    "چرا مهم است؟ چون **آنتاموبا دیسپار** از نظر شکلی زیر میکروسکوپ **دقیقاً شبیه** هیستولیتیکا "
    "است ولی **بیماری‌زا نیست و درمان نمی‌خواهد**. تنها چیزی که در میکروسکوپ نوری این دو را جدا "
    "می‌کند، همین بلعیدن گلبول قرمز است.\n\n"
    "**پس این کوهنورد جوان با دو روز اسهال خونی، بیماری مهاجم قطعی دارد** و همان قاعده‌ی "
    "دومرحله‌ای اجرا می‌شود: **مترونیدازول + یدوکینول**.\n\n"
    "**چرا بقیه رد می‌شوند؟**\n\n"
    "**داکسی‌سیکلین ۳۰۰ میلی‌گرم تک‌دوز:** داکسی‌سیکلین ضدآمیب نیست و تک‌دوز بودن آن هم با "
    "هیچ رژیم ضدانگلی هم‌خوان نیست.\n\n"
    "**مترونیدازول + سیپروفلوکساسین:** مرحله‌ی بافتی پوشش دارد ولی **مرحله‌ی لومینال پوشش "
    "ندارد** — سیپروفلوکساسین کیست‌کش نیست.\n\n"
    "**تینیدازول + داکسی‌سیکلین:** تینیدازول درست است ولی داکسی‌سیکلین باز هم پوشش لومینال "
    "نمی‌دهد. **دقت کنید که فقط پارومومایسین و یدوکینول (و فورواید) داروی لومینال‌اند.**",
    "This question folds a microscopic detail into the rule, and it carries high exam value.\n\n"
    "WARNING: A TROPHOZOITE CONTAINING RED CELLS (erythrophagocytosis) IS THE SIGNATURE OF INVASIVE "
    "ENTAMOEBA HISTOLYTICA. Why does it matter? Because ENTAMOEBA DISPAR looks EXACTLY THE SAME under "
    "the microscope but IS NOT PATHOGENIC AND NEEDS NO TREATMENT. The only thing that separates the "
    "two on light microscopy is precisely this ingestion of red cells.\n\n"
    "SO THIS YOUNG CLIMBER WITH TWO DAYS OF BLOODY DIARRHOEA HAS DEFINITE INVASIVE DISEASE, and the "
    "same two-stage rule applies: METRONIDAZOLE PLUS IODOQUINOL.\n\n"
    "WHY ARE THE OTHERS REJECTED?\n\n"
    "DOXYCYCLINE 300 mg SINGLE DOSE: doxycycline is not antiamoebic, and a single dose fits no "
    "antiparasitic regimen at all.\n\n"
    "METRONIDAZOLE PLUS CIPROFLOXACIN: the tissue stage is covered but THE LUMINAL STAGE IS NOT — "
    "ciprofloxacin is not cysticidal.\n\n"
    "TINIDAZOLE PLUS DOXYCYCLINE: the tinidazole is right, but doxycycline again gives no luminal "
    "cover. NOTE THAT ONLY PAROMOMYCIN AND IODOQUINOL (and diloxanide furoate) ARE LUMINAL AGENTS.",
    ["داکسی‌سیکلین ضدآمیب نیست و رژیم تک‌دوز با هیچ درمان ضدانگلی هم‌خوان نیست.",
     "فرم بافتی پوشش دارد ولی فرم لومینال بدون درمان می‌ماند.",
     "پاسخ صحیح — نیتروایمیدازول برای فرم بافتی و یدوکینول برای فرم لومینال.",
     "تینیدازول درست است ولی داکسی‌سیکلین داروی لومینال نیست."],
    ["Doxycycline is not antiamoebic, and a single-dose regimen fits no antiparasitic treatment.",
     "The tissue form is covered but the luminal form is left untreated.",
     "Correct — a nitroimidazole for the tissue form and iodoquinol for the luminal form.",
     "The tinidazole is right, but doxycycline is not a luminal agent."],
    "**گلبول قرمز داخل تروفوزوئیت = هیستولیتیکای مهاجم، نه دیسپار بی‌آزار.**",
    "Red cells inside the trophozoite = invasive histolytica, not harmless dispar.",
    AMB_REFS)

add("book:733", "vignette", "hard",
    "**آبسه‌ی آمیبی کبد یک بیماری دارویی است — تخلیه استثناست، نه قاعده.**",
    "An amoebic liver abscess is a MEDICAL disease — drainage is the exception, not the rule.",
    [
        "⚠️ **قاعده‌ی اصلی: آبسه‌ی آمیبی کبد با دارو درمان می‌شود، نه با چاقو.**",
        "**نیتروایمیدازول (مترونیدازول یا تینیدازول) در بیش از ۹۰ درصد موارد به‌تنهایی کافی است.**",
        "**و پس از آن، داروی لومینال برای پاک‌سازی روده لازم است.**",
        "⚠️ **تخلیه فقط در چند وضعیت خاص انجام می‌شود، و بهتر است آن‌ها را بشمارید.**",
        "**یک: آبسه‌ی بزرگ لوب چپ که پریکارد را تهدید می‌کند.**",
        "**دو: خطر پارگی قریب‌الوقوع.**",
        "**سه: عدم پاسخ به درمان دارویی پس از حدود سه تا پنج روز.**",
        "**چهار: تردید جدی در تشخیص، یعنی احتمال آبسه‌ی چرکی.**",
        "**در این بیمار هیچ‌کدام از این چهار وجود ندارد: ضایعه‌ی ۳ سانتی‌متری لوب راست.**",
        "⚠️ **پس افزودن تخلیه به درمان، ریسک بدون سود است.**",
        "**پرازی‌کوانتل داروی ترماتودها و سستودهاست و ضدآمیب نیست.**",
        "**پس هر گزینه‌ای که پرازی‌کوانتل دارد، از پایه غلط است.**",
        "**تینیدازول سه روزه معادل مترونیدازول ده روزه است و راحت‌تر تحمل می‌شود.**",
        "**پارومومایسین ده روزه همان مرحله‌ی لومینال است که دفع کیست را متوقف می‌کند.**",
    ],
    [
        "WARNING, THE CORE RULE: an amoebic liver abscess is treated with DRUGS, not with a knife.",
        "A nitroimidazole (metronidazole or tinidazole) alone suffices in more than 90% of cases.",
        "And after it, a luminal agent is needed to clear the bowel.",
        "WARNING, DRAINAGE IS DONE ONLY IN A FEW SPECIFIC SITUATIONS, and it is worth counting them.",
        "ONE: a large LEFT-lobe abscess threatening the pericardium.",
        "TWO: imminent rupture.",
        "THREE: failure to respond to drug therapy after about three to five days.",
        "FOUR: serious diagnostic doubt, meaning a possible pyogenic abscess.",
        "This patient has NONE of the four: a 3 cm lesion in the right lobe.",
        "WARNING, SO ADDING DRAINAGE HERE IS RISK WITHOUT BENEFIT.",
        "Praziquantel is a drug for trematodes and cestodes and is not antiamoebic.",
        "So any option containing praziquantel is wrong from the start.",
        "Three days of tinidazole is equivalent to ten days of metronidazole and is better tolerated.",
        "Ten days of paromomycin is the luminal stage that stops cyst shedding.",
    ],
    "این سؤال یکی از پرتکرارترین اشتباهات بالینی را هدف گرفته است: **فرستادن بیمار مبتلا به "
    "آبسه‌ی آمیبی کبد به اتاق عمل.**\n\n"
    "**تابلوی بیمار کلاسیک است:** آقای ۳۰ ساله، درد ربع فوقانی راست، تب، بی‌اشتهایی، تندرنس "
    "موضعی، لکوسیتوز و آلکالین فسفاتاز بالا، و در سونوگرافی **ضایعه‌ی مدور منفرد در لوب راست "
    "با قطر ۳ سانتی‌متر**.\n\n"
    "⚠️ **قاعده‌ی اصلی را حفظ کنید: آبسه‌ی آمیبی کبد یک بیماری دارویی است.** بیش از ۹۰ درصد "
    "بیماران فقط با نیتروایمیدازول کاملاً خوب می‌شوند، و تب معمولاً ظرف ۷۲ ساعت می‌افتد.\n\n"
    "**پس تخلیه کِی لازم است؟ چهار وضعیت را بشمارید:**\n\n"
    "**یک** — آبسه‌ی بزرگ **لوب چپ** که خطر پارگی به داخل **پریکارد** دارد (کشنده‌ترین عارضه). "
    "**دو** — خطر پارگی قریب‌الوقوع. **سه** — **عدم پاسخ** به درمان دارویی پس از سه تا پنج روز. "
    "**چهار** — تردید جدی در تشخیص و احتمال آبسه‌ی **چرکی**.\n\n"
    "**بیمار ما هیچ‌کدام را ندارد.** ضایعه‌ی ۳ سانتی‌متری در لوب **راست** است، تازه تشخیص "
    "داده شده و هنوز درمانی نگرفته تا بتوان گفت پاسخ نداده.\n\n"
    "**پس گزینه‌ی درست: تینیدازول سه روزه + پارومومایسین ده روزه.** تینیدازول کوتاه‌مدت "
    "معادل مترونیدازول طولانی‌تر است و بهتر تحمل می‌شود؛ پارومومایسین همان مرحله‌ی لومینال است.\n\n"
    "⚠️ **و دو گزینه‌ای که پرازی‌کوانتل دارند از پایه غلط‌اند:** پرازی‌کوانتل داروی **کرم‌های "
    "پهن** (ترماتود و سستود) است و روی تک‌یاخته‌ای مثل آمیب هیچ اثری ندارد.",
    "This question targets one of the commonest clinical mistakes: SENDING A PATIENT WITH AN AMOEBIC "
    "LIVER ABSCESS TO THE OPERATING ROOM.\n\n"
    "THE PICTURE IS CLASSIC: a 30-year-old man, right upper quadrant pain, fever, anorexia, local "
    "tenderness, leucocytosis and a raised alkaline phosphatase, and on ultrasound A SOLITARY ROUND "
    "3 cm LESION IN THE RIGHT LOBE.\n\n"
    "WARNING, MEMORISE THE CORE RULE: AN AMOEBIC LIVER ABSCESS IS A MEDICAL DISEASE. More than 90% of "
    "patients recover completely on a nitroimidazole alone, and the fever usually settles within 72 hours.\n\n"
    "SO WHEN IS DRAINAGE NEEDED? COUNT THE FOUR SITUATIONS:\n\n"
    "ONE — a large LEFT-LOBE abscess at risk of rupturing into the PERICARDIUM (the most lethal "
    "complication). TWO — imminent rupture. THREE — FAILURE TO RESPOND to drug therapy after three to "
    "five days. FOUR — serious diagnostic doubt with a possible PYOGENIC abscess.\n\n"
    "OUR PATIENT HAS NONE OF THEM. The lesion is 3 cm, in the RIGHT lobe, newly diagnosed, and he has "
    "not yet had treatment that could be said to have failed.\n\n"
    "SO THE CORRECT OPTION IS: THREE DAYS OF TINIDAZOLE PLUS TEN DAYS OF PAROMOMYCIN. Short-course "
    "tinidazole is equivalent to the longer metronidazole course and is better tolerated; paromomycin "
    "is the luminal stage.\n\n"
    "WARNING, AND THE TWO OPTIONS CONTAINING PRAZIQUANTEL ARE WRONG FROM THE START: praziquantel is a "
    "drug for FLATWORMS (trematodes and cestodes) and has no effect at all on a protozoan such as an "
    "amoeba.",
    ["پرازی‌کوانتل داروی کرم‌های پهن است و روی آمیب هیچ اثری ندارد.",
     "تخلیه‌ی جراحی در آبسه‌ی ۳ سانتی‌متری لوب راست بدون عارضه، ریسک بدون سود است.",
     "تینیدازول درست است ولی تخلیه‌ی تحت گاید در این بیمار اندیکاسیون ندارد.",
     "پاسخ صحیح — نیتروایمیدازول کوتاه‌مدت به‌علاوه‌ی داروی لومینال، بدون هیچ تخلیه‌ای."],
    ["Praziquantel is a drug for flatworms and has no effect on amoebae.",
     "Surgical drainage of an uncomplicated 3 cm right-lobe abscess is risk without benefit.",
     "The tinidazole is right, but guided drainage is not indicated in this patient.",
     "Correct — a short nitroimidazole course plus a luminal agent, with no drainage at all."],
    "**آبسه‌ی آمیبی کبد: دارو، نه چاقو — مگر لوب چپ، پارگی، یا عدم پاسخ.**",
    "Amoebic liver abscess: drugs, not a knife — unless left lobe, rupture, or no response.",
    AMB_REFS)

add("book:734", "vignette", "medium",
    "**کیست و تروفوزوئیت با هم، یعنی هم بیماری مهاجم و هم بار لومینال — پس هر دو دارو، هر کدام با مدت درست.**",
    "Cysts AND trophozoites together mean both invasive disease and a luminal burden — so both drugs, each for its correct duration.",
    AMB_FA + [
        "**اینجا کتاب مدت درمان را هم می‌سنجد، نه فقط انتخاب دارو.**",
        "**تینیدازول: سه روز کافی است — دوز بالاتر و نیمه‌عمر طولانی‌تر.**",
        "**مترونیدازول: هفت تا ده روز لازم دارد، چون نیمه‌عمر کوتاه‌تری دارد.**",
        "⚠️ **و داروی لومینال، هر کدام که باشد، معمولاً ده روز داده می‌شود.**",
        "**پارومومایسین ده روز و یدوکینول بیست روز، مدت‌های استاندارد لومینال‌اند.**",
    ],
    AMB_EN + [
        "Here the book tests DURATION as well as drug choice.",
        "TINIDAZOLE: three days suffice — a higher dose and a longer half-life.",
        "METRONIDAZOLE: needs seven to ten days, because its half-life is shorter.",
        "WARNING, AND THE LUMINAL AGENT, whichever it is, is usually given for about ten days.",
        "Paromomycin for ten days and iodoquinol for twenty days are the standard luminal courses.",
    ],
    "این سؤال یک لایه به قاعده اضافه می‌کند: **مدت درمان**.\n\n"
    "**آقای ۳۵ ساله با اسهال خونی، و در مدفوع هم کیست و هم تروفوزوئیت دیده شده.** یعنی هم "
    "**بیماری مهاجم** دارد (تروفوزوئیت) و هم **بار لومینال** (کیست). پس مثل همیشه هر دو دارو "
    "لازم است.\n\n"
    "⚠️ **ولی چهار گزینه همگی ترکیب دارند و اختلافشان در مدت است. پس مدت‌ها را باید بلد باشید:**\n\n"
    "**تینیدازول: سه روز.** دوز بالاتر و نیمه‌عمر طولانی‌تر دارد، پس دوره‌ی کوتاه‌تری کافی است.\n\n"
    "**مترونیدازول: هفت تا ده روز.** نیمه‌عمر کوتاه‌تر، پس دوره‌ی طولانی‌تر.\n\n"
    "**پارومومایسین: ده روز.** **یدوکینول: بیست روز.**\n\n"
    "**پس گزینه‌ی دوم — تینیدازول سه روز + پارومومایسین ده روز — تنها گزینه‌ای است که هر دو "
    "دارو را با مدت درست خودشان دارد.**\n\n"
    "**چرا بقیه رد می‌شوند؟** «مترونیدازول + یدوکینول ده روز» مرحله‌ی لومینال را کوتاه گرفته "
    "(یدوکینول بیست روز است). «مترونیدازول + پارومومایسین پنج روز» هر دو را کوتاه گرفته. "
    "«تینیدازول + یدوکینول ده روز» باز هم یدوکینول را نصف کرده است.\n\n"
    "⚠️ **چرا مدت مهم است و صرفاً جزئیات نیست؟ چون کوتاه کردن مرحله‌ی لومینال یعنی بیمار "
    "همچنان کیست دفع می‌کند و می‌تواند دیگران را آلوده کند** — یعنی همان چیزی که کل مرحله‌ی "
    "دوم برای آن وجود دارد.",
    "This question adds one layer to the rule: DURATION.\n\n"
    "A 35-YEAR-OLD MAN WITH BLOODY DIARRHOEA, and the stool shows BOTH cysts AND trophozoites. So he "
    "has both INVASIVE DISEASE (trophozoites) and a LUMINAL BURDEN (cysts). As always, both drugs are "
    "needed.\n\n"
    "WARNING, BUT ALL FOUR OPTIONS ARE COMBINATIONS AND THEY DIFFER IN DURATION. So the durations must "
    "be known:\n\n"
    "TINIDAZOLE: THREE DAYS. Higher dose and longer half-life, so a shorter course suffices.\n\n"
    "METRONIDAZOLE: SEVEN TO TEN DAYS. Shorter half-life, so a longer course.\n\n"
    "PAROMOMYCIN: TEN DAYS. IODOQUINOL: TWENTY DAYS.\n\n"
    "SO THE SECOND OPTION — three days of tinidazole plus ten days of paromomycin — IS THE ONLY ONE "
    "GIVING BOTH DRUGS FOR THEIR CORRECT DURATIONS.\n\n"
    "WHY ARE THE OTHERS REJECTED? 'Metronidazole plus iodoquinol for ten days' shortens the luminal "
    "stage (iodoquinol is twenty days). 'Metronidazole plus paromomycin for five days' shortens both. "
    "'Tinidazole plus iodoquinol for ten days' again halves the iodoquinol.\n\n"
    "WARNING, WHY DOES DURATION MATTER RATHER THAN BEING A DETAIL? BECAUSE SHORTENING THE LUMINAL "
    "STAGE MEANS THE PATIENT KEEPS SHEDDING CYSTS AND CAN INFECT OTHERS — precisely what the whole "
    "second stage exists to prevent.",
    ["مرحله‌ی لومینال کوتاه گرفته شده: یدوکینول دوره‌ی بیست‌روزه دارد، نه ده‌روزه.",
     "پاسخ صحیح — تینیدازول سه روز و پارومومایسین ده روز، هر دو با مدت استاندارد خود.",
     "پنج روز برای پارومومایسین کوتاه است؛ دوره‌ی استاندارد ده روز است.",
     "یدوکینول باید بیست روز داده شود، نه ده روز."],
    ["The luminal stage is cut short: iodoquinol is a twenty-day course, not ten.",
     "Correct — tinidazole for three days and paromomycin for ten, each at its standard duration.",
     "Five days is too short for paromomycin; the standard course is ten days.",
     "Iodoquinol must be given for twenty days, not ten."],
    "**تینیدازول ۳ روز · مترونیدازول ۷ تا ۱۰ روز · پارومومایسین ۱۰ روز · یدوکینول ۲۰ روز.**",
    "Tinidazole 3 days; metronidazole 7 to 10 days; paromomycin 10 days; iodoquinol 20 days.",
    AMB_REFS)

# ==================================== ASYMPTOMATIC CYST PASSERS: THREE ITEMS
CYST_FA = [
    "⚠️ **ناقل بدون علامت آمیب درمان می‌شود — و این نکته‌ای است که خیلی‌ها اشتباه می‌کنند.**",
    "**ولی داروی او فقط لومینال است: پارومومایسین یا یدوکینول، بدون نیتروایمیدازول.**",
    "**چرا نیتروایمیدازول نه؟ چون هیچ بافتی درگیر نیست که آن را بخواهد.**",
    "**دادن مترونیدازول به ناقل بی‌علامت یعنی عارضه بدون سود.**",
    "⚠️ **و چرا اصلاً درمان می‌شود؟ دو دلیل مستقل دارد، و امتحان هر دو را می‌پرسد.**",
    "**دلیل اول، بهداشت عمومی: ناقل کیست دفع می‌کند و دیگران را آلوده می‌کند.**",
    "**به همین دلیل کارگر آشپزخانه حتماً باید درمان شود.**",
    "**دلیل دوم، خطر خودِ بیمار: ناقل می‌تواند بعداً به بیماری مهاجم تبدیل شود.**",
    "⚠️ **و این خطر در فرد تحت سرکوب ایمنی به‌مراتب بیشتر است.**",
    "**پس بیمار تحت کورتیکواستروئید نباید فقط تحت نظر گرفته شود.**",
    "**پارومومایسین یک آمینوگلیکوزید خوراکی است که جذب سیستمیک ناچیزی دارد.**",
    "**همین جذب‌نشدن مزیت اوست: در لومن می‌ماند و همان‌جا کار می‌کند.**",
]
CYST_EN = [
    "WARNING: AN ASYMPTOMATIC AMOEBIC CARRIER IS TREATED — and many people get this wrong.",
    "But his drug is LUMINAL ONLY: paromomycin or iodoquinol, with NO nitroimidazole.",
    "Why no nitroimidazole? Because no tissue is invaded that would need one.",
    "Giving metronidazole to an asymptomatic carrier is toxicity without benefit.",
    "WARNING, AND WHY TREAT AT ALL? There are two independent reasons, and the exam asks both.",
    "REASON ONE, PUBLIC HEALTH: the carrier sheds cysts and infects other people.",
    "That is why a kitchen worker must certainly be treated.",
    "REASON TWO, THE PATIENT'S OWN RISK: a carrier can later convert to invasive disease.",
    "WARNING, AND THAT RISK IS FAR HIGHER IN SOMEONE WHO IS IMMUNOSUPPRESSED.",
    "So a patient on corticosteroids must not merely be watched.",
    "Paromomycin is an oral aminoglycoside with negligible systemic absorption.",
    "That lack of absorption is its advantage: it stays in the lumen and works right there.",
]

add("book:735", "vignette", "hard",
    "**ناقل بی‌علامتِ تحت کورتیکواستروئید، فوری‌ترین اندیکاسیون درمان لومینال است.**",
    "An asymptomatic carrier ON CORTICOSTEROIDS is the most urgent indication for luminal treatment.",
    CYST_FA + [
        "**این بیمار پردنیزولون خوراکی برای پمفیگوس می‌گیرد: ایمنی سلولی او سرکوب شده است.**",
        "**و ایمنی سلولی همان چیزی است که جلوی تهاجم آمیب را می‌گیرد.**",
        "⚠️ **پس در او خطر تبدیل ناقلی به کولیت مهاجم یا آبسه‌ی کبد واقعی است.**",
        "**«تحت نظر گرفتن» در این زمینه یعنی منتظر ماندن برای عارضه.**",
        "**پارومومایسین ۵۰۰ میلی‌گرم سه بار در روز به مدت هفت روز، رژیم استاندارد لومینال است.**",
    ],
    CYST_EN + [
        "This patient takes oral prednisolone for pemphigus: his cell-mediated immunity is suppressed.",
        "And cell-mediated immunity is exactly what holds amoebic invasion back.",
        "WARNING, SO IN HIM THE RISK of a carrier state converting to invasive colitis or a liver abscess is real.",
        "'Watchful waiting' in this setting means waiting for the complication.",
        "Paromomycin 500 mg three times daily for seven days is the standard luminal regimen.",
    ],
    "این سؤال ترکیب دو مفهوم است و به همین دلیل سخت‌تر از بقیه‌ی بلوک است: **ناقلی بی‌علامت** "
    "به‌علاوه‌ی **سرکوب ایمنی**.\n\n"
    "**بیمار: آقای ۴۲ ساله که به علت پمفیگوس پردنیزولون خوراکی می‌گیرد.** در مدفوع **کیست** "
    "آمیب هیستولیتیکا دیده شده و **هیچ علامت گوارشی ندارد**.\n\n"
    "**پس دو سؤال جدا باید پاسخ بگیرد: آیا درمان کنیم؟ و اگر بله، با چه دارویی؟**\n\n"
    "⚠️ **آیا درمان کنیم؟ بله، و در این بیمار قاطعانه بله.** ناقل بی‌علامت به دو دلیل درمان "
    "می‌شود، و دلیل دوم اینجا بسیار پررنگ است: **ناقل می‌تواند به بیماری مهاجم تبدیل شود، و "
    "این تبدیل در فرد تحت سرکوب ایمنی به‌مراتب محتمل‌تر است.** کورتیکواستروئید ایمنی سلولی را "
    "سرکوب می‌کند و ایمنی سلولی دقیقاً همان سدی است که جلوی تهاجم آمیب را می‌گیرد. آمیبیازیس "
    "مهاجم در بیمار تحت استروئید می‌تواند به **کولیت فولمینانت** برسد که مرگ‌ومیر بالایی دارد.\n\n"
    "**با چه دارویی؟ فقط داروی لومینال.** چون هیچ تهاجم بافتی وجود ندارد، نیتروایمیدازول "
    "اندیکاسیون ندارد. **پارومومایسین ۵۰۰ میلی‌گرم سه بار در روز به مدت هفت روز** رژیم "
    "استاندارد است.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**«تکرار آزمایش یک ماه بعد»:** یک ماه تأخیر در بیمار تحت استروئید، یک ماه فرصت برای تهاجم است.\n\n"
    "**«در صورت بروز اسهال، مترونیدازول»:** یعنی صبر کنیم تا بیماری مهاجم شود — دقیقاً همان "
    "چیزی که می‌خواهیم از آن جلوگیری کنیم.\n\n"
    "⚠️ **«چون بی‌علامت است تحت نظر می‌گیریم»:** این گزینه در فرد **دارای ایمنی سالم** هم "
    "نادرست است (چون بهداشت عمومی)، و در فرد **تحت سرکوب ایمنی** خطرناک است.",
    "This question combines two concepts and is therefore harder than the rest of the block: AN "
    "ASYMPTOMATIC CARRIER STATE plus IMMUNOSUPPRESSION.\n\n"
    "THE PATIENT: a 42-year-old man on oral prednisolone for pemphigus. The stool shows CYSTS of "
    "Entamoeba histolytica and he has NO GASTROINTESTINAL SYMPTOMS.\n\n"
    "SO TWO SEPARATE QUESTIONS MUST BE ANSWERED: do we treat? And if so, with what?\n\n"
    "WARNING, DO WE TREAT? YES, AND IN THIS PATIENT EMPHATICALLY YES. An asymptomatic carrier is "
    "treated for two reasons, and the second is very prominent here: A CARRIER CAN CONVERT TO INVASIVE "
    "DISEASE, AND THAT CONVERSION IS FAR MORE LIKELY IN SOMEONE IMMUNOSUPPRESSED. Corticosteroids "
    "suppress cell-mediated immunity, and cell-mediated immunity is precisely the barrier that holds "
    "amoebic invasion back. Invasive amoebiasis in a steroid-treated patient can reach FULMINANT "
    "COLITIS, which carries a high mortality.\n\n"
    "WITH WHAT? A LUMINAL AGENT ONLY. Since there is no tissue invasion, a nitroimidazole is not "
    "indicated. PAROMOMYCIN 500 mg THREE TIMES DAILY FOR SEVEN DAYS is the standard regimen.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "'REPEAT THE STOOL IN ONE MONTH': a month's delay in a steroid-treated patient is a month of "
    "opportunity for invasion.\n\n"
    "'TREAT WITH METRONIDAZOLE IF DIARRHOEA APPEARS': that means waiting for the disease to become "
    "invasive — exactly what we are trying to prevent.\n\n"
    "WARNING, 'HE IS ASYMPTOMATIC SO WE WATCH HIM': this option is wrong even in an IMMUNOCOMPETENT "
    "person (because of public health), and in an IMMUNOSUPPRESSED one it is dangerous.",
    ["پاسخ صحیح — ناقل بی‌علامت داروی لومینال می‌گیرد، و در فرد تحت استروئید فوریت دارد.",
     "یک ماه تأخیر در بیمار تحت سرکوب ایمنی، یک ماه فرصت برای تهاجم است.",
     "یعنی منتظر بمانیم تا بیماری مهاجم شود — همان چیزی که باید از آن جلوگیری کرد.",
     "تحت نظر گرفتن حتی در فرد سالم هم به دلیل بهداشت عمومی نادرست است."],
    ["Correct — an asymptomatic carrier receives a luminal agent, and in a steroid-treated patient it is urgent.",
     "A month's delay in an immunosuppressed patient is a month of opportunity for invasion.",
     "That means waiting for the disease to turn invasive — exactly what must be prevented.",
     "Watchful waiting is wrong even in a healthy person, on public health grounds."],
    "**ناقل بی‌علامت + سرکوب ایمنی = درمان لومینال فوری، نه انتظار.**",
    "Asymptomatic carrier plus immunosuppression = prompt luminal treatment, not waiting.",
    AMB_REFS)

add("book:737", "vignette", "medium",
    "**کارگر آشپزخانه‌ی ناقل کیست: داروی لومینال به‌تنهایی — یدوکینول.**",
    "A kitchen worker carrying cysts: a LUMINAL AGENT ALONE — iodoquinol.",
    CYST_FA + [
        "**این بیمار کارگر آشپزخانه است، پس بُعد بهداشت عمومی در او پررنگ‌ترین است.**",
        "**یک ناقل در آشپزخانه می‌تواند ده‌ها نفر را آلوده کند.**",
        "⚠️ **پس «اقدام خاصی لازم نیست» در این شغل قطعاً غلط است.**",
        "**یدوکینول داروی لومینال است و دقیقاً همان چیزی است که لازم است.**",
        "**افزودن مترونیدازول به آن، درمان بافتی‌ای است که بیماری بافتی ندارد.**",
    ],
    CYST_EN + [
        "This patient is a KITCHEN WORKER, so the public health dimension is at its strongest in him.",
        "One carrier in a kitchen can infect dozens of people.",
        "WARNING, SO 'NO ACTION IS NEEDED' IS DEFINITELY WRONG in this occupation.",
        "Iodoquinol is a luminal agent and is exactly what is required.",
        "Adding metronidazole to it treats a tissue disease that does not exist.",
    ],
    "این سؤال همان قاعده‌ی ناقل بی‌علامت را می‌سنجد، ولی این بار **از زاویه‌ی بهداشت عمومی**.\n\n"
    "**بیمار: مرد جوان، کارگر آشپزخانه، بدون علائم گوارشی، و در مدفوع فقط کیست آمیب هیستولیتیکا "
    "دیده شده — هیچ یافته‌ی دیگری نیست.**\n\n"
    "**پس این یک ناقل بی‌علامت خالص است.** نه گلبول سفید، نه گلبول قرمز، نه تروفوزوئیت. "
    "**یعنی هیچ تهاجم بافتی وجود ندارد.**\n\n"
    "⚠️ **قاعده: ناقل بی‌علامت = فقط داروی لومینال.** یدوکینول یکی از دو داروی لومینال اصلی "
    "است (کنار پارومومایسین)، پس گزینه‌ی «یدوکینول باید تجویز شود» درست است.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**«اقدام خاصی لازم نیست»:** در **هر** ناقلی غلط است، و در **کارگر آشپزخانه** به‌شدت غلط. "
    "او هر روز غذای ده‌ها نفر را دست می‌زند و کیست دفع می‌کند.\n\n"
    "**«کشت مدفوع باید انجام شود»:** کشت مدفوع **باکتری** را می‌یابد، نه انگل. برای آمیب "
    "کشت روتین جایی ندارد؛ تشخیص با میکروسکوپ و در صورت لزوم آنتی‌ژن یا PCR است. تازه تشخیص "
    "هم که از قبل روشن است.\n\n"
    "⚠️ **«مترونیدازول + یدوکینول»:** یدوکینولش درست است ولی **مترونیدازول اضافه است**. "
    "این رژیم برای بیماری **مهاجم** است. در ناقل بی‌علامت، مترونیدازول فقط عوارض دارویی "
    "(تهوع، طعم فلزی، نوروپاتی در دوره‌های طولانی) اضافه می‌کند بدون هیچ سود.",
    "This question tests the same asymptomatic-carrier rule, but this time FROM THE PUBLIC HEALTH ANGLE.\n\n"
    "THE PATIENT: a young man, a kitchen worker, with no gastrointestinal symptoms, and the stool "
    "shows ONLY cysts of Entamoeba histolytica — there is no other finding.\n\n"
    "SO THIS IS A PURE ASYMPTOMATIC CARRIER. No white cells, no red cells, no trophozoites. THAT MEANS "
    "THERE IS NO TISSUE INVASION.\n\n"
    "WARNING, THE RULE: ASYMPTOMATIC CARRIER = LUMINAL AGENT ONLY. Iodoquinol is one of the two main "
    "luminal drugs (alongside paromomycin), so 'iodoquinol should be prescribed' is correct.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "'NO PARTICULAR ACTION IS NEEDED': wrong in ANY carrier, and severely wrong in a KITCHEN WORKER. "
    "He handles the food of dozens of people every day while shedding cysts.\n\n"
    "'A STOOL CULTURE SHOULD BE DONE': stool culture finds BACTERIA, not parasites. Routine culture "
    "has no place for amoebae; the diagnosis is by microscopy and, if needed, antigen testing or PCR. "
    "And in any case the diagnosis is already established.\n\n"
    "WARNING, 'METRONIDAZOLE PLUS IODOQUINOL': the iodoquinol is right but THE METRONIDAZOLE IS "
    "SUPERFLUOUS. That regimen is for INVASIVE disease. In an asymptomatic carrier metronidazole only "
    "adds drug toxicity (nausea, metallic taste, neuropathy on long courses) with no benefit at all.",
    ["در کارگر آشپزخانه‌ای که کیست دفع می‌کند، بی‌اقدام ماندن یک خطر بهداشت عمومی است.",
     "کشت مدفوع باکتری را می‌یابد نه انگل، و تشخیص هم از قبل روشن است.",
     "پاسخ صحیح — ناقل بی‌علامت فقط داروی لومینال می‌گیرد و یدوکینول همان است.",
     "مترونیدازول برای بیماری مهاجم است؛ اینجا عارضه بدون سود اضافه می‌کند."],
    ["In a kitchen worker shedding cysts, doing nothing is a public health hazard.",
     "Stool culture finds bacteria, not parasites, and the diagnosis is already established.",
     "Correct — an asymptomatic carrier receives a luminal agent only, and iodoquinol is one.",
     "Metronidazole is for invasive disease; here it adds toxicity without benefit."],
    "**ناقل بی‌علامت: فقط لومینال. مترونیدازول اضافه، عارضه‌ی بی‌سود است.**",
    "Asymptomatic carrier: luminal only. Added metronidazole is toxicity without benefit.",
    AMB_REFS)

add("book:738", "vignette", "easy",
    "**کارت بهداشتی و کیست آمیب: باز هم داروی لومینال تنها — یدوکینول.**",
    "A health card and amoebic cysts: again, a LUMINAL AGENT ALONE — iodoquinol.",
    CYST_FA + [
        "**این سؤال عملاً همان قبلی است، از زاویه‌ی صدور کارت بهداشتی.**",
        "**کارگر علامتی ندارد و فقط کیست دفع می‌کند.**",
        "⚠️ **پس نه مترونیدازول تنها، نه ترکیب — فقط یدوکینول.**",
        "**«پارومومایسین + تینیدازول» هم همان اشتباه است: نیتروایمیدازول اضافه.**",
        "**بلد بودن این دوتایی — لومینال تنها در برابر ترکیب — نیمی از این فصل را حل می‌کند.**",
    ],
    CYST_EN + [
        "This question is essentially the previous one, seen from the health-card angle.",
        "The worker has no symptoms and is simply shedding cysts.",
        "WARNING, SO NEITHER METRONIDAZOLE ALONE NOR A COMBINATION — iodoquinol only.",
        "'Paromomycin plus tinidazole' is the same mistake: a superfluous nitroimidazole.",
        "Knowing this pair — luminal alone versus the combination — solves half of this chapter.",
    ],
    "این سؤال تقریباً تکرار قبلی است و دقیقاً به همین دلیل ارزش دارد: **کتاب این قاعده را "
    "بارها می‌پرسد، پس یک بار درست یاد بگیرید و همه‌ی این سؤال‌ها را ببرید.**\n\n"
    "**موقعیت: کارگر آشپزخانه، بدون علامت، برای صدور کارت بهداشتی آزمایش داده و کیست آنتاموبا "
    "هیستولیتیکا گزارش شده است.**\n\n"
    "⚠️ **ناقل بی‌علامت = فقط داروی لومینال.** پس **یدوکینول** به‌تنهایی پاسخ است.\n\n"
    "**چرا بقیه رد می‌شوند؟**\n\n"
    "**«پارومومایسین + تینیدازول»:** پارومومایسین لومینال درستی است ولی **تینیدازول اضافه است** — "
    "نیتروایمیدازول برای بیماری بافتی است و اینجا بیماری بافتی وجود ندارد.\n\n"
    "**«مترونیدازول» تنها:** این دقیقاً **برعکس** جواب درست است. مترونیدازول تنها، فرم بافتی "
    "را می‌کشد (که وجود ندارد) و **کیست‌ها را زنده می‌گذارد** — یعنی همان چیزی که کارگر برای آن "
    "درمان می‌شود، درمان‌نشده می‌ماند. **این بدترین گزینه است.**\n\n"
    "**«یدوکینول + مترونیدازول»:** یدوکینولش درست است ولی مترونیدازول اضافه است.\n\n"
    "⚠️ **نکته‌ی حرفه‌ای که ارزش امتحانی دارد: مترونیدازولِ تنها در ناقل بی‌علامت نه‌فقط بی‌فایده، "
    "بلکه گمراه‌کننده است** — چون پزشک فکر می‌کند بیمار را درمان کرده در حالی که او همچنان "
    "کیست دفع می‌کند.",
    "This question is almost a repeat of the previous one, and that is exactly why it matters: THE "
    "BOOK ASKS THIS RULE REPEATEDLY, so learn it properly once and take all these marks.\n\n"
    "THE SITUATION: a kitchen worker, asymptomatic, tested for a health card, with cysts of Entamoeba "
    "histolytica reported.\n\n"
    "WARNING, ASYMPTOMATIC CARRIER = LUMINAL AGENT ONLY. So IODOQUINOL alone is the answer.\n\n"
    "WHY ARE THE OTHERS REJECTED?\n\n"
    "'PAROMOMYCIN PLUS TINIDAZOLE': paromomycin is a correct luminal agent but THE TINIDAZOLE IS "
    "SUPERFLUOUS — a nitroimidazole is for tissue disease, and there is no tissue disease here.\n\n"
    "'METRONIDAZOLE' ALONE: this is precisely the OPPOSITE of the right answer. Metronidazole alone "
    "kills the tissue form (which does not exist) and LEAVES THE CYSTS ALIVE — meaning the very thing "
    "the worker is being treated for goes untreated. THIS IS THE WORST OPTION.\n\n"
    "'IODOQUINOL PLUS METRONIDAZOLE': the iodoquinol is right but the metronidazole is superfluous.\n\n"
    "WARNING, A PROFESSIONAL POINT WITH EXAM VALUE: METRONIDAZOLE ALONE IN AN ASYMPTOMATIC CARRIER IS "
    "NOT MERELY USELESS BUT MISLEADING — the doctor believes the patient has been treated while he "
    "goes on shedding cysts.",
    ["پارومومایسین درست است ولی تینیدازول اضافه است؛ بیماری بافتی وجود ندارد.",
     "بدترین گزینه — مترونیدازول تنها کیست‌ها را زنده می‌گذارد، یعنی همان چیزی که باید درمان شود.",
     "یدوکینولش درست است ولی مترونیدازول در ناقل بی‌علامت اندیکاسیون ندارد.",
     "پاسخ صحیح — ناقل بی‌علامت فقط داروی لومینال می‌گیرد."],
    ["Paromomycin is right but the tinidazole is superfluous; there is no tissue disease.",
     "The worst option — metronidazole alone leaves the cysts alive, the very thing needing treatment.",
     "The iodoquinol is right, but metronidazole is not indicated in an asymptomatic carrier.",
     "Correct — an asymptomatic carrier receives a luminal agent only."],
    "**مترونیدازولِ تنها در ناقل بی‌علامت: کیست‌ها زنده می‌مانند.**",
    "Metronidazole alone in an asymptomatic carrier: the cysts survive.",
    AMB_REFS)

# ============================================================ REFRACTORY GIARDIA
add("book:742", "vignette", "hard",
    "**ژیاردیای مقاوم در بیمار با نقص ایمنی هومورال: همان دارو، ولی دوره‌ی طولانی‌تر و دوز بالاتر.**",
    "Refractory giardiasis in a patient with a humoral immune defect: THE SAME DRUG, but a longer course at a higher dose.",
    [
        "⚠️ **ژیاردیا با IgA ترشحی روده کنترل می‌شود، نه با ایمنی سلولی.**",
        "**پس بیمار CVID که آنتی‌بادی نمی‌سازد، ژیاردیای مقاوم و عودکننده می‌گیرد.**",
        "**CVID یعنی نقص ایمنی متغیر شایع: کاهش IgG، IgA و اغلب IgM.**",
        "**و ژیاردیازیس مزمن یکی از شناخته‌شده‌ترین تظاهرات گوارشی CVID است.**",
        "⚠️ **تابلوی ژیاردیا: اسهال چرب و بدبو، نفخ، آروغ گوگردی، و سوءجذب.**",
        "**استئاتوره یعنی انگل جذب چربی را در روده‌ی باریک مختل کرده است.**",
        "**درمان استاندارد: مترونیدازول ۲۵۰ میلی‌گرم سه بار در روز به مدت پنج تا هفت روز.**",
        "**یا تینیدازول دو گرم تک‌دوز، که راحتی مصرف بیشتری دارد.**",
        "⚠️ **ولی در شکست درمان، راهبرد اصلی طولانی‌تر و پرقدرت‌تر کردن همان خانواده است.**",
        "**یعنی مترونیدازول با دوز بالاتر و دوره‌ی سه هفته‌ای.**",
        "**ترکیب مترونیدازول با کینکرین هم راهکار دیگری در موارد واقعاً مقاوم است.**",
        "**آلبندازول روی ژیاردیا فعالیت دارد ولی ضعیف‌تر از نیتروایمیدازول است.**",
        "**ایورمکتین اصلاً روی ژیاردیا اثر ندارد؛ داروی نماتودهاست.**",
        "⚠️ **و نکته‌ی مهم CVID: بیمار ممکن است هرگز آنتی‌بادی محافظ نسازد، پس عود شایع است.**",
    ],
    [
        "WARNING: GIARDIA IS CONTROLLED BY SECRETORY IgA in the gut, not by cell-mediated immunity.",
        "So a CVID patient who makes no antibody gets refractory, relapsing giardiasis.",
        "CVID means common variable immunodeficiency: low IgG, low IgA and often low IgM.",
        "And chronic giardiasis is one of the best-recognised gastrointestinal manifestations of CVID.",
        "WARNING, THE GIARDIA PICTURE: greasy foul diarrhoea, bloating, sulphurous belching, malabsorption.",
        "Steatorrhoea means the parasite has disrupted fat absorption in the small bowel.",
        "Standard treatment: metronidazole 250 mg three times daily for five to seven days.",
        "Or tinidazole 2 g as a single dose, which is more convenient.",
        "WARNING, BUT ON TREATMENT FAILURE the main strategy is to lengthen and intensify the SAME family.",
        "That means metronidazole at a higher dose for a three-week course.",
        "Combining metronidazole with quinacrine is another approach in genuinely refractory cases.",
        "Albendazole has activity against giardia but is weaker than a nitroimidazole.",
        "Ivermectin has no effect on giardia at all; it is a nematode drug.",
        "WARNING, AND THE KEY CVID POINT: the patient may never make protective antibody, so relapse is common.",
    ],
    "این سؤال دو چیز را با هم می‌سنجد: **چرا این بیمار ژیاردیای مقاوم دارد**، و **در شکست "
    "درمان چه می‌کنیم**.\n\n"
    "⚠️ **چرا CVID و ژیاردیا این‌قدر به هم مربوط‌اند؟** چون **ژیاردیا با IgA ترشحی روده کنترل "
    "می‌شود، نه با ایمنی سلولی.** بیمار CVID (نقص ایمنی متغیر شایع) نمی‌تواند آنتی‌بادی کافی "
    "بسازد، پس **ژیاردیای مزمن، عودکننده و مقاوم** می‌گیرد. ژیاردیازیس مزمن یکی از "
    "شناخته‌شده‌ترین تظاهرات گوارشی CVID است و دیدن آن باید ما را به فکر نقص ایمنی هومورال بیندازد.\n\n"
    "**تابلوی بیمار هم کاملاً ژیاردیایی است:** درد شکم، **استئاتوره** (چون انگل جذب چربی را "
    "در روده‌ی باریک مختل می‌کند) و **نفخ**.\n\n"
    "**درمان استاندارد ژیاردیا:** مترونیدازول ۲۵۰ میلی‌گرم سه بار در روز، پنج تا هفت روز؛ یا "
    "تینیدازول دو گرم تک‌دوز.\n\n"
    "⚠️ **ولی این بیمار چندین نوبت درمان گرفته و همچنان مثبت است. راهبرد در شکست درمان چیست؟** "
    "**طولانی‌تر و پرقدرت‌تر کردن همان خانواده‌ی دارویی.** یعنی مترونیدازول با **دوز بالاتر "
    "(۷۵۰ میلی‌گرم)** و **دوره‌ی طولانی‌تر (۲۱ روز)**. این دقیقاً همان گزینه‌ی سوم است.\n\n"
    "**چرا بقیه رد می‌شوند؟**\n\n"
    "**آلبندازول ۴۰۰ میلی‌گرم ۱۴ روز:** آلبندازول روی ژیاردیا فعالیت **دارد** ولی **ضعیف‌تر** "
    "از نیتروایمیدازول است. وقتی نیتروایمیدازول با دوز استاندارد شکست خورده، رفتن به دارویی "
    "**ضعیف‌تر** منطقی نیست.\n\n"
    "**تینیدازول ۵۰۰ میلی‌گرم هر ۱۲ ساعت، ۱۰ روز:** تینیدازول هم نیتروایمیدازول است، ولی این "
    "دوز از دوز استاندارد آن (دو گرم تک‌دوز) هم کمتر است — یعنی تشدید واقعی نیست.\n\n"
    "**ایورمکتین:** داروی **نماتودها** (استرونژیلوئیدس، انکوسرکا) است و **روی ژیاردیا هیچ "
    "اثری ندارد**.",
    "This question tests two things at once: WHY this patient has refractory giardiasis, and WHAT TO "
    "DO ON TREATMENT FAILURE.\n\n"
    "WARNING, WHY ARE CVID AND GIARDIA SO CLOSELY LINKED? Because GIARDIA IS CONTROLLED BY SECRETORY "
    "IgA IN THE GUT, NOT BY CELL-MEDIATED IMMUNITY. A CVID (common variable immunodeficiency) patient "
    "cannot make enough antibody, so he gets CHRONIC, RELAPSING, REFRACTORY GIARDIASIS. Chronic "
    "giardiasis is one of the best-recognised gastrointestinal manifestations of CVID, and seeing it "
    "should raise the thought of a humoral immune defect.\n\n"
    "THE PICTURE IS ALSO PURE GIARDIA: abdominal pain, STEATORRHOEA (because the parasite disrupts fat "
    "absorption in the small bowel) and BLOATING.\n\n"
    "STANDARD GIARDIA TREATMENT: metronidazole 250 mg three times daily for five to seven days; or "
    "tinidazole 2 g as a single dose.\n\n"
    "WARNING, BUT THIS PATIENT HAS BEEN TREATED SEVERAL TIMES AND REMAINS POSITIVE. WHAT IS THE "
    "STRATEGY ON FAILURE? LENGTHEN AND INTENSIFY THE SAME DRUG FAMILY. That means metronidazole at a "
    "HIGHER DOSE (750 mg) for a LONGER COURSE (21 days). That is exactly the third option.\n\n"
    "WHY ARE THE OTHERS REJECTED?\n\n"
    "ALBENDAZOLE 400 mg FOR 14 DAYS: albendazole DOES have activity against giardia but is WEAKER than "
    "a nitroimidazole. When a nitroimidazole at standard dose has already failed, moving to a WEAKER "
    "drug makes no sense.\n\n"
    "TINIDAZOLE 500 mg TWELVE-HOURLY FOR 10 DAYS: tinidazole is also a nitroimidazole, but this dose is "
    "even lower than its standard (2 g single dose) — so it is not a genuine escalation.\n\n"
    "IVERMECTIN: a drug for NEMATODES (strongyloides, onchocerca) with NO EFFECT ON GIARDIA AT ALL.",
    ["آلبندازول روی ژیاردیا فعالیت دارد ولی ضعیف‌تر از نیتروایمیدازول است؛ در شکست درمان منطقی نیست.",
     "این دوز تینیدازول حتی از دوز استاندارد آن هم کمتر است؛ تشدید واقعی محسوب نمی‌شود.",
     "پاسخ صحیح — در ژیاردیای مقاوم، همان نیتروایمیدازول با دوز بالاتر و دوره‌ی طولانی‌تر.",
     "ایورمکتین داروی نماتودهاست و روی ژیاردیا هیچ اثری ندارد."],
    ["Albendazole has activity against giardia but is weaker than a nitroimidazole; illogical after failure.",
     "This tinidazole dose is even below its standard dose; it is not a genuine escalation.",
     "Correct — in refractory giardiasis, the same nitroimidazole at a higher dose for a longer course.",
     "Ivermectin is a nematode drug and has no effect on giardia."],
    "**CVID یعنی IgA ندارد، و ژیاردیا با IgA کنترل می‌شود — پس عود می‌کند.**",
    "CVID means no IgA, and giardia is controlled by IgA — so it relapses.",
    [H])

# ================================================================= LEISHMANIASIS
LEISH_FA = [
    "⚠️ **لیشمانیا را با یک تقسیم دوتایی یاد بگیرید: پوستی در برابر احشایی.**",
    "**لیشمانیای پوستی (سالک) در ایران عمدتاً با تروپیکا و ماژور است.**",
    "**تروپیکا شکل شهری و خشک؛ ماژور شکل روستایی و مرطوب.**",
    "**آاتیوپیکا هم پوستی است، ولی در شاخ آفریقا نه در ایران.**",
    "⚠️ **اینفانتوم فرق دارد: عامل لیشمانیای احشایی (کالاآزار) است، نه پوستی.**",
    "**در حوضه‌ی مدیترانه و ایران، کالاآزار کودکان با اینفانتوم است.**",
    "**و دونووانی عامل کالاآزار در شبه‌قاره‌ی هند و شرق آفریقاست.**",
    "**تابلوی کالاآزار: تب طولانی، اسپلنومگالی بارز، پان‌سیتوپنی و کاهش وزن.**",
    "⚠️ **و تشخیص قطعی با دیدن آماستیگوت در بافت رتیکولواندوتلیال است.**",
    "**حساسیت نمونه‌برداری بر اساس بار انگلی بافت مرتب می‌شود.**",
    "**طحال بالاترین حساسیت را دارد: بیش از ۹۵ درصد.**",
    "**مغز استخوان حدود ۷۰ تا ۸۵ درصد، و غده‌ی لنفاوی حدود ۶۰ درصد.**",
    "⚠️ **ولی آسپیراسیون طحال خطر خونریزی دارد، پس در عمل مغز استخوان امن‌تر است.**",
    "**پس «حساس‌ترین» و «اولین انتخاب عملی» در این بیماری یکی نیستند — و امتحان همین را می‌پرسد.**",
]
LEISH_EN = [
    "WARNING: LEARN LEISHMANIA BY ONE BINARY SPLIT — cutaneous versus visceral.",
    "Cutaneous leishmaniasis (oriental sore) in Iran is mainly L. tropica and L. major.",
    "L. tropica is the urban, dry form; L. major the rural, wet form.",
    "L. aethiopica is also cutaneous, but in the Horn of Africa, not in Iran.",
    "WARNING, L. INFANTUM IS DIFFERENT: it causes VISCERAL leishmaniasis (kala-azar), not cutaneous disease.",
    "In the Mediterranean basin and Iran, childhood kala-azar is due to L. infantum.",
    "And L. donovani causes kala-azar in the Indian subcontinent and East Africa.",
    "The kala-azar picture: prolonged fever, marked splenomegaly, pancytopenia and weight loss.",
    "WARNING, AND THE DEFINITIVE DIAGNOSIS is seeing amastigotes in reticuloendothelial tissue.",
    "The sensitivity of a biopsy follows the parasite load of the tissue.",
    "The SPLEEN has the highest sensitivity: over 95%.",
    "Bone marrow is about 70 to 85%, and lymph node about 60%.",
    "WARNING, BUT SPLENIC ASPIRATION CARRIES A BLEEDING RISK, so in practice bone marrow is safer.",
    "So 'most sensitive' and 'first practical choice' are not the same thing here — and the exam asks exactly that.",
]

add("book:743", "recall", "medium",
    "**اینفانتوم عامل لیشمانیای احشایی است، نه پوستی — تنها گزینه‌ای که از این فهرست بیرون است.**",
    "L. infantum causes VISCERAL leishmaniasis, not cutaneous — the only member that does not belong on this list.",
    LEISH_FA,
    LEISH_EN,
    "این سؤال یک تفکیک ساده ولی پرارزش را می‌سنجد: **کدام گونه‌های لیشمانیا پوستی‌اند و کدام "
    "احشایی.**\n\n"
    "⚠️ **سه گونه‌ی اول همگی عامل لیشمانیای پوستی (سالک) هستند:**\n\n"
    "**لیشمانیا تروپیکا** — شکل **شهری و خشک** سالک، شایع در شهرهای ایران مثل مشهد و شیراز.\n\n"
    "**لیشمانیا ماژور** — شکل **روستایی و مرطوب** سالک، با مخزن جوندگان صحرایی.\n\n"
    "**لیشمانیا آاتیوپیکا** — هم پوستی است، ولی جغرافیای آن **شاخ آفریقا** (اتیوپی و کنیا) است، "
    "نه ایران. با این حال همچنان **عامل بیماری پوستی** است، پس در فهرست پوستی می‌ماند.\n\n"
    "**لیشمانیا اینفانتوم اما فرق دارد:** این گونه عامل **لیشمانیای احشایی (کالاآزار)** است. "
    "در حوضه‌ی مدیترانه، خاورمیانه و ایران، **کالاآزار کودکان** عمدتاً با اینفانتوم است. "
    "(همتای آن در شبه‌قاره‌ی هند و شرق آفریقا، **لیشمانیا دونووانی** است.)\n\n"
    "**پس پاسخ: لیشمانیا اینفانتوم.**\n\n"
    "⚠️ **نکته‌ای که ارزش دانستن دارد و امتحان‌ها گاهی از آن سؤال ساخته‌اند:** اینفانتوم "
    "**می‌تواند** به‌ندرت ضایعه‌ی پوستی هم بدهد، ولی **بیماری تعریف‌کننده‌ی آن احشایی است**. "
    "در سؤال چهارگزینه‌ای، همیشه به **بیماری اصلی و شناخته‌شده‌ی** هر گونه فکر کنید، نه به "
    "استثناهای نادر.\n\n"
    "**و تابلوی کالاآزار را حفظ کنید:** تب طولانی، **اسپلنومگالی بارز**، پان‌سیتوپنی، کاهش وزن "
    "و هیپرگاماگلوبولینمی.",
    "This question tests a simple but valuable split: WHICH LEISHMANIA SPECIES ARE CUTANEOUS AND WHICH "
    "ARE VISCERAL.\n\n"
    "WARNING, THE FIRST THREE ARE ALL CAUSES OF CUTANEOUS LEISHMANIASIS (oriental sore):\n\n"
    "LEISHMANIA TROPICA — the URBAN, DRY form, common in Iranian cities such as Mashhad and Shiraz.\n\n"
    "LEISHMANIA MAJOR — the RURAL, WET form, with desert rodents as the reservoir.\n\n"
    "LEISHMANIA AETHIOPICA — also cutaneous, but its geography is the HORN OF AFRICA (Ethiopia and "
    "Kenya), not Iran. It nevertheless still causes CUTANEOUS disease, so it stays on the cutaneous list.\n\n"
    "LEISHMANIA INFANTUM IS DIFFERENT: this species causes VISCERAL LEISHMANIASIS (KALA-AZAR). In the "
    "Mediterranean basin, the Middle East and Iran, CHILDHOOD KALA-AZAR is mainly due to L. infantum. "
    "(Its counterpart in the Indian subcontinent and East Africa is L. DONOVANI.)\n\n"
    "SO THE ANSWER IS LEISHMANIA INFANTUM.\n\n"
    "WARNING, A POINT WORTH KNOWING that exams have occasionally built questions on: L. infantum CAN "
    "rarely produce a skin lesion too, but ITS DEFINING DISEASE IS VISCERAL. In a multiple-choice "
    "question always think of each species' MAIN, RECOGNISED disease, not its rare exceptions.\n\n"
    "AND MEMORISE THE KALA-AZAR PICTURE: prolonged fever, MARKED SPLENOMEGALY, pancytopenia, weight "
    "loss and hypergammaglobulinaemia.",
    ["شکل شهری و خشک سالک است و قطعاً از علل لیشمانیای پوستی به شمار می‌رود.",
     "شکل روستایی و مرطوب سالک با مخزن جوندگان است؛ پوستی است.",
     "پوستی است، هرچند جغرافیای آن شاخ آفریقاست نه ایران.",
     "پاسخ صحیح — اینفانتوم عامل لیشمانیای احشایی (کالاآزار) است، نه پوستی."],
    ["The urban, dry form of oriental sore and certainly a cause of cutaneous leishmaniasis.",
     "The rural, wet form with a rodent reservoir; cutaneous.",
     "Cutaneous, although its geography is the Horn of Africa rather than Iran.",
     "Correct — L. infantum causes visceral leishmaniasis (kala-azar), not cutaneous disease."],
    "**تروپیکا · ماژور · آاتیوپیکا = پوستی. اینفانتوم · دونووانی = احشایی.**",
    "Tropica, major, aethiopica = cutaneous. Infantum, donovani = visceral.",
    [HLEISH])

add("book:744", "recall", "medium",
    "**آسپیراسیون طحال حساس‌ترین روش تشخیص کالاآزار است — چون بیشترین بار انگلی آنجاست.**",
    "SPLENIC aspiration is the most sensitive test for kala-azar — because the parasite load is highest there.",
    LEISH_FA + [
        "**منطق ساده است: هرچه بار انگلی بافت بیشتر باشد، حساسیت نمونه بیشتر است.**",
        "**و طحال ارگان اصلی تجمع آماستیگوت‌ها در لیشمانیای احشایی است.**",
        "⚠️ **دقت کنید سؤال «حساس‌ترین» را پرسیده، نه «امن‌ترین» یا «اولین انتخاب».**",
        "**اگر «اولین انتخاب عملی» را می‌پرسید، پاسخ مغز استخوان بود.**",
        "**کبد حساسیت پایین‌تری دارد و بیوپسی آن هم خطر خونریزی دارد.**",
    ],
    LEISH_EN + [
        "The logic is simple: the higher the parasite load of a tissue, the higher the yield of its sample.",
        "And the spleen is the main organ where amastigotes accumulate in visceral leishmaniasis.",
        "WARNING, NOTE THAT THE QUESTION ASKS 'MOST SENSITIVE', not 'safest' or 'first choice'.",
        "Had it asked for the first practical choice, the answer would be bone marrow.",
        "The liver has lower sensitivity and its biopsy also carries a bleeding risk.",
    ],
    "این سؤال دقیقاً یک کلمه را می‌سنجد: **«حساسیت بالاتر»**. و همین کلمه پاسخ را از آنچه "
    "در عمل بیشتر انجام می‌دهیم جدا می‌کند.\n\n"
    "⚠️ **قاعده‌ی ساده: حساسیت نمونه‌برداری با بار انگلی بافت تعیین می‌شود.** در لیشمانیای "
    "احشایی، آماستیگوت‌ها در سیستم رتیکولواندوتلیال تجمع می‌کنند و **طحال بیشترین بار انگلی را "
    "دارد**.\n\n"
    "**ترتیب حساسیت را حفظ کنید:**\n\n"
    "**طحال: بیش از ۹۵ درصد** — بالاترین.\n\n"
    "**مغز استخوان: حدود ۷۰ تا ۸۵ درصد.**\n\n"
    "**غده‌ی لنفاوی: حدود ۶۰ درصد** — کمترین.\n\n"
    "**کبد:** حساسیت متوسط و کمتر از طحال، و بیوپسی آن هم خطر خونریزی دارد.\n\n"
    "⚠️ **ولی یک نکته‌ی بالینی مهم که سؤال آن را نپرسیده و باید بدانید:** آسپیراسیون طحال "
    "**خطر خونریزی جدی** دارد، به‌ویژه در بیمار کالاآزار که **ترومبوسیتوپنی** و اختلال انعقاد "
    "دارد. به همین دلیل **در عمل، مغز استخوان انتخاب اول است** و آسپیراسیون طحال فقط در مراکز "
    "مجرب و با پلاکت و PT قابل قبول انجام می‌شود.\n\n"
    "**پس این دو را با هم اشتباه نگیرید:**\n\n"
    "**«حساس‌ترین» = طحال.** **«اولین انتخاب عملی و امن» = مغز استخوان.**\n\n"
    "**و روش‌های غیرتهاجمی امروز:** تست سریع **rK39** با حساسیت بالا در شبه‌قاره‌ی هند، که "
    "در بسیاری از موارد نیاز به نمونه‌برداری را برطرف می‌کند.",
    "This question tests exactly one phrase: 'HIGHER SENSITIVITY'. And that phrase separates the answer "
    "from what we more often do in practice.\n\n"
    "WARNING, THE SIMPLE RULE: THE YIELD OF A BIOPSY IS SET BY THE PARASITE LOAD OF THE TISSUE. In "
    "visceral leishmaniasis the amastigotes accumulate in the reticuloendothelial system, and THE "
    "SPLEEN CARRIES THE HIGHEST PARASITE LOAD.\n\n"
    "MEMORISE THE ORDER OF SENSITIVITY:\n\n"
    "SPLEEN: OVER 95% — the highest.\n\n"
    "BONE MARROW: about 70 to 85%.\n\n"
    "LYMPH NODE: about 60% — the lowest.\n\n"
    "LIVER: intermediate and below the spleen, and its biopsy also carries a bleeding risk.\n\n"
    "WARNING, BUT AN IMPORTANT CLINICAL POINT THE QUESTION DID NOT ASK AND YOU MUST KNOW: splenic "
    "aspiration carries a SERIOUS BLEEDING RISK, especially in a kala-azar patient who has "
    "THROMBOCYTOPENIA and clotting derangement. That is why IN PRACTICE BONE MARROW IS THE FIRST "
    "CHOICE, and splenic aspiration is done only in experienced centres with an acceptable platelet "
    "count and PT.\n\n"
    "SO DO NOT CONFUSE THE TWO:\n\n"
    "'MOST SENSITIVE' = SPLEEN. 'FIRST PRACTICAL AND SAFE CHOICE' = BONE MARROW.\n\n"
    "AND THE MODERN NON-INVASIVE OPTION: the rK39 rapid test, highly sensitive in the Indian "
    "subcontinent, which removes the need for a biopsy in many cases.",
    ["حساسیت حدود ۷۰ تا ۸۵ درصد؛ در عمل انتخاب اول است ولی حساس‌ترین نیست.",
     "پاسخ صحیح — طحال بیشترین بار انگلی را دارد و حساسیت آن بیش از ۹۵ درصد است.",
     "حساسیت کمتری از طحال دارد و بیوپسی آن هم خطر خونریزی دارد.",
     "کمترین حساسیت را در میان این چهار دارد، حدود ۶۰ درصد."],
    ["Sensitivity about 70 to 85%; the practical first choice but not the most sensitive.",
     "Correct — the spleen carries the highest parasite load, with sensitivity over 95%.",
     "Lower sensitivity than the spleen, and its biopsy also carries a bleeding risk.",
     "The lowest sensitivity of the four, around 60%."],
    "**حساس‌ترین = طحال (بیش از ۹۵٪). امن‌ترین انتخاب عملی = مغز استخوان.**",
    "Most sensitive = spleen (over 95%). Safest practical choice = bone marrow.",
    [HLEISH])

json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book41.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 41 lessons:', len(L))
