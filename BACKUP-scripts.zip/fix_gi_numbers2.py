# -*- coding: utf-8 -*-
"""Seven numeric repairs in the gastrointestinal chapter, all of one kind.

METHOD, UNCHANGED FROM THE THIRTEEN EARLIER CHAPTERS
-----------------------------------------------------
pdfplumber gives the x coordinate of every glyph. A number is always DRAWN
left to right even inside right-to-left Persian text, so sorting a line's
characters by x0 recovers the digits in the order the typesetter placed them.

HOW THESE SEVEN WERE FOUND
---------------------------
By `audit_chapter_numbers.py`, the generalised second-pass auditor. Its first
run over this chapter reported:

    agree=108   disagree=7   unlocated=0

Every one of the seven is the SAME failure mode — the two digits of a value
swapped — and every one was then confirmed against the printed glyph run of
its own page before being written here. Nothing is repaired on the auditor's
word alone.

WHY THESE PARTICULAR NUMBERS MATTER MEDICALLY
----------------------------------------------
Six of the seven are laboratory or vital-sign values that a student is
explicitly asked to interpret, and in four of them the mirrored value is not
merely wrong but CHANGES THE ANSWER:

  q9294  "WBC 52" is not a number a stool report produces; the page prints
         WBC 20-25, an inflammatory picture, which is the whole basis for
         excluding Vibrio cholerae.
  q9307  "BP 05" is not a blood pressure at all. The page prints WBC 40-50
         with RBC 10 — again the inflammatory picture the question turns on.
  q9322  stored "RBC 04-30" and "WBC 52-20" are both back to front and both
         are also in the WRONG ORDER (a range must ascend). The page prints
         WBC 20-25 and RBC 30-40.
  q9327  stored "00052" is not a white count. The page prints 25,000 — a
         leucocytosis, which together with the anaemia, the thrombocytopenia
         and the raised creatinine completes the HUS triad the question asks
         the student to name.
  q9348  "systolic 08 mmHg" is impossible. The page prints 80 mmHg, which is
         the hypotension that makes this severe cholera.
  q9437  "pulse 08/min" is impossible. The page prints 80/min, and that
         matters more than it looks: a pulse of 80 with a fever of 39 is
         RELATIVE BRADYCARDIA, which is a positive diagnostic finding for
         typhoid — the very answer the question wants.

That last one is worth stating plainly: a student reading "pulse 08" learns
that the figure is meaningless noise and skips it. The repaired value is a
diagnostic clue.
"""
import collections
import io
import json
import os
import re

import pdfplumber

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = '/home/user/uploads/بیماری عفونی.pdf'

# question_no -> [(page, old, new, expected_printed_run, kind, why_fa, why_en), ...]
#
# WHY EACH ENTRY CARRIES AN ENGLISH NOTE AS WELL
# -----------------------------------------------
# An OLDER guard in the suite caught this script's first version:
#
#     q9294: original stem not kept
#     q9294: no Persian note
#     q9294: no English note
#
# The bank has a standing contract for any repaired stem, enforced by
# "every repaired stem keeps the original and explains itself": the untouched
# original must be preserved in `stem_original_fa`, and the repair must
# explain itself in BOTH languages via `stem_repair_note_fa` and
# `stem_repair_note_en`. The first version of this script wrote its notes to a
# field of its own invention and never kept the original at all.
#
# That is the fifth time in this bank that a guard written for one chapter has
# caught a defect introduced in another, and it is the reason the whole suite
# is re-run after every chapter rather than only the new tests.
FIXES = {
    9294: [
        (114, '20 =WBC -52', 'WBC=20-25', '25', 'reorder',
         'شمارش گلبول سفید مدفوع: صفحه ۱۱۴ عبارت **WBC= 20-25** را چاپ کرده است. '
         'مختصات گلیف‌ها قطعی است: ارقام «۲»، «۵»، «۲»، «۰» به‌ترتیب در x برابر '
         '۴۴۶٫۹ · ۴۵۶٫۹ · ۵۳۶٫۴ · ۵۴۶٫۵ چاپ شده‌اند، یعنی صفحه از چپ به راست '
         '**۲۰ تا ۲۵** را نشان می‌دهد.\n\n'
         '**چرا این عدد اهمیت دارد؟** چون کل سؤال بر پایه‌ی همین یافته است: '
         '**گلبول سفید فراوان در مدفوع یعنی اسهال التهابی**، و اسهال التهابی است '
         'که ویبریوکلرا را رد می‌کند. عدد «۵۲» در گزارش مدفوع اصلاً معنا ندارد و '
         'دانشجو را وامی‌دارد آن را نادیده بگیرد.',
         'Stool white cell count: page 114 prints WBC= 20-25. The glyph coordinates settle it: the digits 2, 5, 2 and 0 are drawn at x = 446.9, 456.9, 536.4 and 546.5, so the page reads 20 TO 25 from left to right. WHY THIS NUMBER MATTERS: the whole question rests on this finding. ABUNDANT STOOL WHITE CELLS MEAN INFLAMMATORY DIARRHOEA, and it is the inflammatory picture that excludes Vibrio cholerae. A figure of 52 is meaningless in a stool report and teaches the student to skip it.'),
    ],
    9307: [
        (118, '-40=WBC=E/S 05', 'E/S: WBC=40-50', '40', 'reorder',
         'پنل مدفوع: صفحه ۱۱۸ عبارت **S/E= WBC= 40-50, RBC= 10** را چاپ کرده است. '
         'گلیف‌ها: «۴»، «۰» در x برابر ۱۶۲٫۳ و ۱۷۲٫۳، و «۱»، «۰» در ۲۶۱٫۹ و ۲۷۱٫۹.\n\n'
         '**چرا مهم است؟** «BP: 05» اصلاً فشار خون نیست، و «WBC=40-05» عددی '
         'نیست که آزمایشگاه گزارش کند. مقدار درست **۴۰ تا ۵۰ گلبول سفید** است — '
         'یعنی **اسهال التهابی**، که مبنای انتخاب آنتی‌بیوتیک و رد کردن '
         'آنتی‌موتیلیتی در همین سؤال است.',
         'Stool panel: page 118 prints S/E= WBC= 40-50, RBC= 10. The glyphs: 4 and 0 at x 162.3 and 172.3, and 1 and 0 at 261.9 and 271.9. WHY IT MATTERS: BP: 05 is not a blood pressure at all, and WBC=40-05 is not a value any laboratory reports. The correct figure is 40 TO 50 WHITE CELLS, an INFLAMMATORY diarrhoea, which is the basis for the antibiotic choice and for rejecting an antimotility agent in this very question.'),
    ],
    9322: [
        (123, '04 -30 =RBC', 'RBC=30-40', '30', 'reorder',
         'گلبول قرمز مدفوع: صفحه ۱۲۳ عبارت **RBC= 30-40** را چاپ کرده است '
         '(گلیف‌ها: «۳»،«۰» در ۳۳۲٫۴ و ۳۴۲٫۴ · «۴»،«۰» در ۳۶۳٫۴ و ۳۷۳٫۴).\n\n'
         '⚠️ **دو خرابی هم‌زمان:** هم رقم‌ها معکوس شده بودند («۰۴» به‌جای «۴۰») و '
         'هم **ترتیب بازه وارونه** شده بود. یک بازه‌ی آزمایشگاهی همیشه صعودی '
         'نوشته می‌شود؛ «۰۴ تا ۳۰» از هر دو جهت نادرست است.',
         'Stool red cells: page 123 prints RBC= 30-40 (glyphs 3 and 0 at 332.4 and 342.4; 4 and 0 at 363.4 and 373.4). WARNING, TWO DEFECTS AT ONCE: the digits were mirrored (04 for 40) AND THE RANGE RAN BACKWARDS. A laboratory range is always written ascending; 04 to 30 is wrong in both directions.'),
        (123, '52 -20 =WBC', 'WBC=20-25', '25', 'reorder',
         'گلبول سفید مدفوع: صفحه ۱۲۳ عبارت **WBC= 20-25** را چاپ کرده است '
         '(گلیف‌ها: «۲»،«۰» در ۲۱۶٫۱ و ۲۲۶٫۱ · «۲»،«۵» در ۲۴۷٫۱ و ۲۵۷٫۱).',
         'Stool white cells: page 123 prints WBC= 20-25 (glyphs 2 and 0 at 216.1 and 226.1; 2 and 5 at 247.1 and 257.1).'),
    ],
    9327: [
        (125, '00052', '25000', '25000', 'reorder',
         'شمارش گلبول سفید: صفحه ۱۲۵ عبارت **WBC 25000** را چاپ کرده است. '
         'گلیف‌ها به‌ترتیب x: «۲» ۴۳۸٫۴ · «۵» ۴۴۸٫۴ · «۰» ۴۵۸٫۴ · «۰» ۴۶۸٫۴ · '
         '«۰» ۴۷۸٫۴ — یعنی صفحه از چپ به راست **۲۵٬۰۰۰** را نشان می‌دهد.\n\n'
         '**چرا این عدد کلید سؤال است؟** بیمار سندرم همولیتیک اورمیک دارد، و '
         'سؤال می‌خواهد دانشجو سه‌گانه را بشناسد. **۲۵٬۰۰۰ یک لکوسیتوز واقعی '
         'است** که در HUS پس از شیگلا شایع است و با پیش‌آگهی بدتر همراه است. '
         '«۰۰۰۵۲» هیچ عددی نیست و دانشجو را از یافته‌ی بالینی محروم می‌کند.',
         'White cell count: page 125 prints WBC 25000. The glyphs in ascending x: 2 at 438.4, 5 at 448.4, 0 at 458.4, 0 at 468.4, 0 at 478.4, so the page reads 25,000 left to right. WHY THIS IS THE KEY TO THE QUESTION: the patient has haemolytic uraemic syndrome and the question asks the student to name the triad. 25,000 IS A GENUINE LEUCOCYTOSIS, common in post-Shigella HUS and associated with a worse prognosis. 00052 is not a number at all and robs the student of a clinical finding.'),
    ],
    9348: [
        (133, 'mmHg08', '80mmHg', '80', 'reorder',
         'فشار خون سیستولیک: صفحه ۱۳۳ عبارت **80mmHg** را چاپ کرده است '
         '(گلیف‌ها: «۸» در x=۳۷۶٫۱ و «۰» در x=۳۸۶٫۲).\n\n'
         '**چرا مهم است؟** «فشار سیستولیک ۰۸» ناممکن است. **۸۰ میلی‌متر جیوه در '
         'کودک ۵ ساله یعنی شوک هیپوولمیک** — و همین شدت دهیدراتاسیون است که '
         'وبای شدید را تعریف می‌کند و مایع‌درمانی وریدی فوری را ضروری می‌سازد.',
         'Systolic blood pressure: page 133 prints 80mmHg (glyphs 8 at x=376.1 and 0 at x=386.2). WHY IT MATTERS: a systolic of 08 is impossible. 80 mmHg IN A 5-YEAR-OLD MEANS HYPOVOLAEMIC SHOCK, and it is that degree of dehydration which defines severe cholera and makes immediate intravenous fluid essential.'),
    ],
    9437: [
        (165, 'min08', '80/min', '80', 'reorder',
         'تعداد نبض: صفحه ۱۶۵ عبارت **80min** را چاپ کرده است (گلیف‌ها: «۸» در '
         'x=۴۰۰٫۲ و «۰» در x=۴۱۰٫۲).\n\n'
         '⚠️ **این مهم‌ترین تصحیح این فصل است، و دلیلش ظریف است.** «نبض ۰۸» '
         'ناممکن است و دانشجو از آن می‌گذرد. ولی **نبض ۸۰ در بیمار با تب ۳۹ '
         'درجه یعنی برادی‌کاردی نسبی** — و برادی‌کاردی نسبی یکی از یافته‌های '
         '**تشخیصی مثبت تب تیفوئید** است، یعنی دقیقاً همان پاسخی که سؤال '
         'می‌خواهد. عدد خراب، یک سرنخ تشخیصی را به نویز بی‌معنا تبدیل کرده بود.',
         'Pulse rate: page 165 prints 80min (glyphs 8 at x=400.2 and 0 at x=410.2). WARNING, THIS IS THE MOST IMPORTANT REPAIR IN THE CHAPTER, and the reason is subtle. A pulse of 08 is impossible and a student simply skips it. But A PULSE OF 80 IN A PATIENT WITH A FEVER OF 39 IS RELATIVE BRADYCARDIA, and relative bradycardia is a POSITIVE DIAGNOSTIC FINDING FOR TYPHOID, which is precisely the answer the question wants. The corrupted number had turned a diagnostic clue into meaningless noise.'),
    ],
}

FOLD = {}
for _i in range(10):
    FOLD[chr(0x0660 + _i)] = str(_i)   # Arabic-Indic
    FOLD[chr(0x06F0 + _i)] = str(_i)   # Persian


def page_digit_runs(pdf, pno):
    """Digit runs of a page in PRINTED (x-ascending) order."""
    page = pdf.pages[pno - 1]
    rows = collections.defaultdict(list)
    for c in page.chars:
        rows[round(c['top'])].append(c)
    runs = []
    for top in sorted(rows):
        cs = sorted(rows[top], key=lambda c: c['x0'])
        cur = ''
        for c in cs:
            t = FOLD.get(c['text'], c['text'])
            # a space must NOT close an open run: kerning sometimes splits a
            # number, and closing on the space invents two numbers out of one
            if t.isspace() and cur:
                continue
            if t.isdigit():
                cur += t
            else:
                if cur:
                    runs.append(cur)
                cur = ''
        if cur:
            runs.append(cur)
    return runs


def main():
    pages = {p for specs in FIXES.values() for (p, *_r) in specs}
    with pdfplumber.open(SRC) as pdf:
        printed = {p: page_digit_runs(pdf, p) for p in pages}

    applied, missing, unproven = [], [], []
    for i in range(1, 6):
        path = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        if not os.path.exists(path):
            continue
        body = json.load(io.open(path, encoding='utf-8'))
        dirty = False
        for q in body['questions']:
            specs = FIXES.get(q['question_no'])
            if not specs:
                continue
            for (pno, old, new, expect, kind, why_fa, why_en) in specs:
                # GUARD ONE: the repaired value must actually be on the page.
                # Without it this script would be a list of assertions rather
                # than a set of evidenced corrections.
                if expect not in printed[pno]:
                    unproven.append(f'q{q["question_no"]}: {expect} not printed on p{pno}')
                    continue
                # GUARD TWO: the text we are replacing must be present. A
                # silent no-op here once let a whole flagging script report
                # success while changing nothing.
                if old not in q['question_fa']:
                    missing.append(f'q{q["question_no"]}: {old!r} not in stem')
                    continue
                # THE BANK'S CONTRACT FOR A REPAIRED STEM, enforced by the
                # suite: keep the untouched original, and explain the repair
                # in BOTH languages. The first version of this script kept
                # neither and was caught by that older guard.
                q.setdefault('stem_original_fa', q['question_fa'])
                q['question_fa'] = q['question_fa'].replace(old, new)
                fixes = q.setdefault('stem_number_corrections', {})
                fixes[old] = new
                prev_fa = q.get('stem_repair_note_fa') or ''
                q['stem_repair_note_fa'] = (prev_fa + '\n\n' + why_fa).strip()
                prev_en = q.get('stem_repair_note_en') or ''
                q['stem_repair_note_en'] = (prev_en + '\n\n' + why_en).strip()
                q['stem_repaired'] = True
                applied.append(f'q{q["question_no"]}: {old!r} -> {new!r} (p{pno}, {kind})')
                dirty = True
        if dirty:
            json.dump(body, io.open(path, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)

    for a in applied:
        print('fixed  ', a)
    for m in missing:
        print('SKIP   ', m)
    for u in unproven:
        print('UNPROVEN', u)
    print(f'\napplied={len(applied)}  skipped={len(missing)}  unproven={len(unproven)}')
    # An empty run means the script silently did nothing, which is the failure
    # mode this bank has been bitten by before.
    assert applied, 'no repair applied — the script would have reported success while doing nothing'


if __name__ == '__main__':
    main()
