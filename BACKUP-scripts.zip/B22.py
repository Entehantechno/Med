# -*- coding: utf-8 -*-
"""Micro-lessons, batch 22 — community-acquired pneumonia.

The first half of the respiratory chapter. Twenty-four of its fifty-seven
questions are pneumonia, and they cluster into three decisions that the
examiners ask over and over:

1. WHICH ORGANISM? The stem always contains one host clue that names the
   pathogen. An epileptic who aspirates gets oral anaerobes; an asplenic
   patient gets the pneumococcus; an air-conditioner repairman with
   hyponatraemia and diarrhoea gets Legionella; a sickle-cell child with cold
   agglutinins gets Mycoplasma. Learn the clue-to-organism map and a whole
   block of questions collapses into one skill.

2. WHERE DOES THE PATIENT GO? CURB-65, and nothing else. Five criteria, one
   point each, and the score maps onto a place of care. Students lose these
   marks by scoring creatinine instead of urea, or by treating age 65 as an
   automatic admission.

3. WHICH ANTIBIOTIC? The 2019 ATS/IDSA split, which the book follows exactly:
   a healthy outpatient gets amoxicillin, doxycycline or a macrolide; a
   comorbid outpatient or a ward inpatient gets a beta-lactam plus a macrolide,
   or a RESPIRATORY fluoroquinolone alone.

The single most repeated trap in this chapter
---------------------------------------------
Four separate questions (q9081, q9082, q9083, q9084) are the same question:
"which drug is NOT appropriate?" and the answer is always CIPROFLOXACIN. The
reason is one fact: CIPROFLOXACIN IS NOT A RESPIRATORY QUINOLONE. Its activity
against Streptococcus pneumoniae is poor, and pneumococcal pneumonia treated
with ciprofloxacin fails. Levofloxacin and moxifloxacin are the respiratory
quinolones; ciprofloxacin is not one, and no amount of familiarity makes it so.

Reference: Metlay JP et al., "Diagnosis and Treatment of Adults with
Community-acquired Pneumonia. An Official Clinical Practice Guideline of the
American Thoracic Society and Infectious Diseases Society of America",
Am J Respir Crit Care Med 2019;200:e45-e67; Harrison's Principles of Internal
Medicine, 21st ed (2022), Ch. 126 (Pneumonia); Lim WS et al., Thorax
2003;58:377 (CURB-65).
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


ATS = ("Metlay JP et al. — Diagnosis and Treatment of Adults with Community-acquired "
       "Pneumonia: An Official ATS/IDSA Clinical Practice Guideline. "
       "Am J Respir Crit Care Med 2019;200(7):e45-e67")
H126 = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 126: Pneumonia"
CURB = "Lim WS et al. — Defining community acquired pneumonia severity on presentation to hospital. Thorax 2003;58:377-382"

# ---------------------------------------------------------------------------
# The clue-to-organism map. Shared by the aetiology questions.
# ---------------------------------------------------------------------------
BUGS_FA = [
    "⚠️ **در سؤالات پنومونی، همیشه یک سرنخ در شرح حال هست که ارگانیسم را نام می‌برد.**",
    "این نقشه را حفظ کنید؛ یک بلوک کامل از سؤالات با همین یک مهارت حل می‌شود:",
    "**استرپتوکوک پنومونیه** ← شایع‌ترین علت در همه‌ی گروه‌ها؛ **شروع ناگهانی**، **لرز تکان‌دهنده**،",
    "**دیپلوکوک گرم‌مثبت** در اسمیر خلط، و **کنسولیداسیون لوبار** در گرافی.",
    "⚠️ **بی‌هوازی‌های دهانی** ← هر چیزی که **آسپیراسیون** را محتمل کند:",
    "**صرع، الکلیسم، کاهش هوشیاری، بهداشت بد دهان، اختلال بلع**.",
    "درگیری در **سگمان‌های وابسته به جاذبه** است و خلط **بدبو** می‌شود.",
    "⚠️ **لژیونلا** ← **سیستم خنک‌کننده و کولر و آب گرم**، همراه با تابلوی **خارج‌ریوی**:",
    "**اسهال**، **کاهش هوشیاری/گیجی**، **هیپوناترمی** و افزایش آنزیم‌های کبدی.",
    "هیپوناترمی سرنخ کلاسیک لژیونلاست و در امتحان تقریباً همیشه معنادار است.",
    "⚠️ **مایکوپلاسما** ← **جوان**، سیر **تدریجی**، **سرفه‌ی خشک**، تابلوی خفیف‌تر از گرافی،",
    "و دو نشانه‌ی خاص: **آگلوتینین سرد مثبت** و **آنمی همولیتیک**.",
    "در **آنمی داسی‌شکل**، مایکوپلاسما می‌تواند **بحران وازواکلوزیو** بسازد.",
    "**استافیلوکوک اورئوس** ← **پس از آنفلوانزا**، و در گرافی **کاویته‌های جدارنازک متعدد**.",
    "**کلبسیلا** ← **الکلی**، خلط **ژله‌ی توت‌فرنگی**، درگیری لوب فوقانی با **بولژینگ فیشر**.",
    "⚠️ **بیمار اسپلنکتومی‌شده** ← **باکتری‌های کپسول‌دار**، و در رأسشان **پنوموکوک**؛",
    "سپس هموفیلوس آنفولانزا و نایسریا مننژیتیدیس.",
    "چرا؟ چون **طحال محل اصلی پاکسازی باکتری‌های اپسونیزه‌ی کپسول‌دار از خون** است.",
]
BUGS_EN = [
    "WARNING: IN PNEUMONIA QUESTIONS THERE IS ALWAYS ONE CLUE IN THE HISTORY THAT NAMES THE ORGANISM.",
    "Memorise this map; a whole block of questions collapses into this single skill:",
    "STREPTOCOCCUS PNEUMONIAE — the commonest cause in every group; ABRUPT ONSET, A SHAKING RIGOR,",
    "GRAM-POSITIVE DIPLOCOCCI on the sputum smear, and LOBAR CONSOLIDATION on the film.",
    "WARNING, ORAL ANAEROBES — anything that makes ASPIRATION likely:",
    "EPILEPSY, ALCOHOLISM, REDUCED CONSCIOUSNESS, POOR DENTAL HYGIENE, SWALLOWING DISORDERS.",
    "The disease sits in the GRAVITY-DEPENDENT SEGMENTS and the sputum becomes FOUL-SMELLING.",
    "WARNING, LEGIONELLA — COOLING SYSTEMS, AIR CONDITIONERS AND HOT WATER, with an EXTRAPULMONARY picture:",
    "DIARRHOEA, CONFUSION, HYPONATRAEMIA and raised liver enzymes.",
    "Hyponatraemia is the classical Legionella clue and in an exam it is almost always meaningful.",
    "WARNING, MYCOPLASMA — A YOUNG patient, GRADUAL onset, a DRY COUGH, looking better than the film,",
    "and two specific markers: POSITIVE COLD AGGLUTININS and HAEMOLYTIC ANAEMIA.",
    "In SICKLE CELL DISEASE, Mycoplasma can precipitate a VASO-OCCLUSIVE CRISIS.",
    "STAPHYLOCOCCUS AUREUS — AFTER INFLUENZA, with MULTIPLE THIN-WALLED CAVITIES on the film.",
    "KLEBSIELLA — the ALCOHOLIC, REDCURRANT-JELLY sputum, upper lobe disease with a BULGING FISSURE.",
    "WARNING, THE ASPLENIC PATIENT — ENCAPSULATED ORGANISMS, and above all THE PNEUMOCOCCUS;",
    "then Haemophilus influenzae and Neisseria meningitidis.",
    "Why? Because THE SPLEEN IS THE MAIN SITE FOR CLEARING OPSONISED ENCAPSULATED BACTERIA FROM THE BLOOD.",
]

RX_FA = [
    "⚠️ **درمان پنومونی اکتسابی از جامعه، دقیقاً بر پایه‌ی دو سؤال تصمیم‌گیری می‌شود:**",
    "**یک — بیمار سرپایی است یا بستری؟** **دو — بیماری زمینه‌ای دارد یا نه؟**",
    "**سرپاییِ سالم (بدون بیماری زمینه‌ای و بدون آنتی‌بیوتیک اخیر):**",
    "**آموکسی‌سیلین ۱ گرم هر ۸ ساعت**، یا **داکسی‌سیکلین ۱۰۰ میلی‌گرم دو بار در روز**،",
    "یا **ماکرولید** (آزیترومایسین/کلاریترومایسین) اگر مقاومت پنوموکوک منطقه زیر ۲۵٪ باشد.",
    "**سرپاییِ دارای بیماری زمینه‌ای** (قلبی، ریوی، کلیوی، کبدی، دیابت، الکلیسم، بدخیمی، اسپلنکتومی)",
    "**یا مصرف آنتی‌بیوتیک در سه ماه اخیر:**",
    "**بتالاکتام (کوآموکسی‌کلاو یا سفالوسپورین خوراکی) + ماکرولید یا داکسی‌سیکلین**،",
    "**یا تک‌درمانی با کینولون تنفسی** (لووفلوکساسین ۷۵۰ یا موکسی‌فلوکساسین ۴۰۰).",
    "**بستری در بخش (غیرشدید):** **سفتریاکسون + آزیترومایسین**، یا **کینولون تنفسی تنها**.",
    "**بستری در ICU (شدید):** **بتالاکتام + ماکرولید** یا **بتالاکتام + کینولون تنفسی**.",
    "⚠️ **و مهم‌ترین تله‌ی کل این فصل، که چهار بار پرسیده شده:**",
    "**سیپروفلوکساسین کینولون تنفسی نیست و در پنومونی جایی ندارد.**",
    "چرا؟ چون **اثرش روی استرپتوکوک پنومونیه ضعیف است** و پنوموکوک شایع‌ترین عامل است.",
    "**کینولون‌های تنفسی فقط دو تا هستند: لووفلوکساسین و موکسی‌فلوکساسین.**",
    "⚠️ قاعده‌ی دوم که فراموش می‌شود: **اگر بیمار در سه ماه اخیر آنتی‌بیوتیک گرفته،**",
    "**باید از یک کلاس متفاوت استفاده کرد** — این خودش بیمار را از دسته‌ی «سالم» بیرون می‌برد.",
]
RX_EN = [
    "WARNING: TREATMENT OF COMMUNITY-ACQUIRED PNEUMONIA TURNS ON EXACTLY TWO QUESTIONS:",
    "ONE — IS THE PATIENT AN OUTPATIENT OR AN INPATIENT? TWO — ARE THERE COMORBIDITIES?",
    "THE HEALTHY OUTPATIENT (no comorbidity, no recent antibiotics):",
    "AMOXICILLIN 1 G EVERY 8 HOURS, or DOXYCYCLINE 100 MG TWICE DAILY,",
    "or a MACROLIDE (azithromycin/clarithromycin) where local pneumococcal resistance is under 25%.",
    "THE OUTPATIENT WITH COMORBIDITY (heart, lung, kidney, liver, diabetes, alcoholism, malignancy, asplenia)",
    "OR WHO HAS TAKEN ANTIBIOTICS IN THE LAST THREE MONTHS:",
    "A BETA-LACTAM (co-amoxiclav or an oral cephalosporin) PLUS A MACROLIDE OR DOXYCYCLINE,",
    "OR MONOTHERAPY WITH A RESPIRATORY QUINOLONE (levofloxacin 750 or moxifloxacin 400).",
    "WARD INPATIENT (non-severe): CEFTRIAXONE PLUS AZITHROMYCIN, or a RESPIRATORY QUINOLONE alone.",
    "ICU INPATIENT (severe): BETA-LACTAM PLUS MACROLIDE, or BETA-LACTAM PLUS RESPIRATORY QUINOLONE.",
    "WARNING, AND THE MOST REPEATED TRAP IN THIS WHOLE CHAPTER, ASKED FOUR TIMES:",
    "CIPROFLOXACIN IS NOT A RESPIRATORY QUINOLONE AND HAS NO PLACE IN PNEUMONIA.",
    "Why? Because ITS ACTIVITY AGAINST STREPTOCOCCUS PNEUMONIAE IS POOR, and the pneumococcus is the commonest cause.",
    "THERE ARE ONLY TWO RESPIRATORY QUINOLONES: LEVOFLOXACIN AND MOXIFLOXACIN.",
    "WARNING, a second rule that gets forgotten: IF THE PATIENT HAD ANTIBIOTICS IN THE LAST THREE MONTHS,",
    "A DIFFERENT CLASS MUST BE USED — and that fact alone moves them out of the 'healthy' category.",
]

CURB_FA = [
    "⚠️ **CURB-65 تصمیم می‌گیرد بیمار کجا درمان شود — و فقط پنج معیار دارد.**",
    "**C — Confusion**: گیجی تازه (یا افت سطح هوشیاری).",
    "⚠️ **U — Urea بالای ۷ میلی‌مول بر لیتر** (معادل BUN بالای ۱۹).",
    "**توجه: اوره، نه کراتینین.** امتیاز دادن به کراتینین یکی از شایع‌ترین خطاهاست.",
    "**R — Respiratory rate ≥ ۳۰** در دقیقه.",
    "**B — Blood pressure**: سیستولیک **زیر ۹۰** یا دیاستولیک **۶۰ یا کمتر**.",
    "**۶۵ — سن ۶۵ سال یا بیشتر**.",
    "**هر معیار یک امتیاز. حالا نمره را به محل درمان ترجمه کنید:**",
    "**۰ تا ۱ ← درمان سرپایی** (مرگ‌ومیر زیر ۳ درصد).",
    "**۲ ← بستری در بخش** (مرگ‌ومیر حدود ۹ درصد).",
    "**۳ تا ۵ ← بستری، و در ۴ تا ۵ به ICU فکر کنید** (مرگ‌ومیر ۱۵ تا ۴۰ درصد).",
    "⚠️ **سه تله‌ی رایج را بشناسید:**",
    "**یک — سن ۶۵ سال به‌تنهایی بستری نمی‌آورد**؛ فقط یک امتیاز است.",
    "**دو — کراتینین امتیاز ندارد؛ فقط اوره.**",
    "**سه — CURB-65 مرگ‌ومیر را پیش‌بینی می‌کند، نه نیاز به اکسیژن را.**",
    "**بیمار هیپوکسمیک با CURB-65 پایین هم ممکن است بستری لازم داشته باشد** — قضاوت بالینی کنار امتیاز می‌ایستد.",
]
CURB_EN = [
    "WARNING: CURB-65 DECIDES WHERE THE PATIENT IS TREATED, and it has only five criteria.",
    "C — CONFUSION: new confusion (or a fall in conscious level).",
    "WARNING, U — UREA ABOVE 7 MMOL/L (equivalent to a BUN above 19).",
    "NOTE: UREA, NOT CREATININE. Scoring the creatinine is one of the commonest errors.",
    "R — RESPIRATORY RATE 30 OR MORE per minute.",
    "B — BLOOD PRESSURE: systolic BELOW 90 or diastolic 60 OR LESS.",
    "65 — AGE 65 YEARS OR OVER.",
    "ONE POINT EACH. Now translate the score into a place of care:",
    "0 TO 1 — OUTPATIENT TREATMENT (mortality under 3%).",
    "2 — ADMIT TO A GENERAL WARD (mortality about 9%).",
    "3 TO 5 — ADMIT, and consider ICU at 4 to 5 (mortality 15 to 40%).",
    "WARNING, RECOGNISE THE THREE COMMON TRAPS:",
    "ONE — AGE 65 ALONE DOES NOT MANDATE ADMISSION; it is one point.",
    "TWO — CREATININE SCORES NOTHING; only urea does.",
    "THREE — CURB-65 PREDICTS MORTALITY, NOT THE NEED FOR OXYGEN.",
    "A HYPOXAEMIC PATIENT WITH A LOW CURB-65 MAY STILL NEED ADMISSION — clinical judgement stands beside the score.",
]


# =========================================================== book:73
add("book:73", "case", "medium",
 "**صرع** ← آسپیراسیون ← **بی‌هوازی‌های دهانی**.",
 "EPILEPSY means aspiration, and aspiration means ORAL ANAEROBES.",
 BUGS_FA + [
  "در این بیمار یک کلمه همه‌چیز را تعیین می‌کند: **سابقه‌ی اپی‌لپسی**.",
  "⚠️ **تشنج یعنی دوره‌های کاهش هوشیاری، و کاهش هوشیاری یعنی خطر آسپیراسیون.**",
  "محتویات دهان و حلق وارد راه هوایی می‌شود، و فلور آنجا **بی‌هوازی** است.",
  "پس پاتوژن محتمل، **بی‌هوازی‌های دهانی** است: پپتواسترپتوکوک، فوزوباکتریوم، پرووتلا، باکتروئیدس.",
  "**کراکل در ریه‌ی راست** هم با همین می‌خواند: **برونش اصلی راست عمودی‌تر و پهن‌تر است**،",
  "پس مواد آسپیره‌شده بیشتر به سمت راست می‌روند.",
  "و سگمان‌های درگیر، **وابسته به وضعیت بدن هنگام آسپیراسیون**‌اند:",
  "در حالت خوابیده به پشت ← **سگمان فوقانی لوب تحتانی** و **سگمان خلفی لوب فوقانی**.",
  "⚠️ **نشانه‌ی بالینی که در سؤالات دیگر می‌آید: خلط بدبو (putrid).**",
  "و اگر درمان نشود، به **آبسه‌ی ریه** و سپس **آمپیم** پیش می‌رود.",
  "**درمان: کلیندامایسین یا آموکسی‌سیلین-کلاوولانات** — هر دو بی‌هوازی را می‌پوشانند.",
  "⚠️ **دقت کنید: مترونیدازول به‌تنهایی کافی نیست**، چون استرپتوکوک‌های هوازی دهان را نمی‌گیرد.",
 ],
 BUGS_EN + [
  "In this patient one word settles everything: A HISTORY OF EPILEPSY.",
  "WARNING: SEIZURES MEAN EPISODES OF REDUCED CONSCIOUSNESS, AND THAT MEANS A RISK OF ASPIRATION.",
  "The contents of mouth and pharynx enter the airway, and that flora is ANAEROBIC.",
  "So the likely pathogen is ORAL ANAEROBES: peptostreptococci, Fusobacterium, Prevotella, Bacteroides.",
  "The CRACKLES IN THE RIGHT LUNG fit too: THE RIGHT MAIN BRONCHUS IS MORE VERTICAL AND WIDER,",
  "so aspirated material tends to go to the right.",
  "And the segments involved depend on THE POSITION OF THE BODY AT THE MOMENT OF ASPIRATION:",
  "lying supine gives the SUPERIOR SEGMENT OF THE LOWER LOBE and the POSTERIOR SEGMENT OF THE UPPER LOBE.",
  "WARNING, the clinical sign that appears in other questions: FOUL-SMELLING (PUTRID) SPUTUM.",
  "And untreated it progresses to a LUNG ABSCESS and then an EMPYEMA.",
  "TREATMENT: CLINDAMYCIN OR AMOXICILLIN-CLAVULANATE — both cover anaerobes.",
  "WARNING, note: METRONIDAZOLE ALONE IS NOT ENOUGH, because it misses the aerobic oral streptococci.",
 ],
 "در این سؤال یک کلمه همه‌چیز را تعیین می‌کند: **«سابقه‌ی اپی‌لپسی»**.\n\n"
 "⚠️ **زنجیره‌ی استدلال را بفهمید تا هرگز فراموش نکنید:**\n\n"
 "**تشنج ← دوره‌های کاهش هوشیاری ← آسپیراسیون محتویات دهان ← فلور بی‌هوازی دهان وارد ریه می‌شود.**\n\n"
 "پس پاتوژن محتمل **بی‌هوازی‌های دهانی** است: پپتواسترپتوکوک، فوزوباکتریوم، پرووتلا و باکتروئیدس.\n\n"
 "**دو نکته‌ی آناتومیک که سؤال را کامل می‌کنند:**\n\n"
 "⚠️ **چرا ریه‌ی راست؟** چون **برونش اصلی راست عمودی‌تر، کوتاه‌تر و پهن‌تر** است؛ مواد آسپیره‌شده به‌طور طبیعی به آن سمت می‌روند.\n\n"
 "**کدام سگمان‌ها؟** آن‌هایی که هنگام آسپیراسیون **وابسته به جاذبه** بوده‌اند: در حالت خوابیده به پشت، **سگمان فوقانی لوب تحتانی** و **سگمان خلفی لوب فوقانی**.\n\n"
 "**چرا گزینه‌های دیگر رد می‌شوند؟**\n\n"
 "**لژیونلا** ← سرنخش تماس با **کولر و سیستم آب** به‌همراه **اسهال، گیجی و هیپوناترمی** است؛ هیچ‌کدام اینجا نیست.\n\n"
 "**استافیلوکوک** ← معمولاً **پس از آنفلوانزا** و با **کاویته‌های جدارنازک**.\n\n"
 "**انتروکوک** ← عملاً پاتوژن ریوی نیست؛ جایش عفونت ادراری، داخل‌شکمی و اندوکاردیت است.\n\n"
 "⚠️ **درمان:** **کلیندامایسین** یا **آموکسی‌سیلین-کلاوولانات**. و توجه کنید که **مترونیدازول به‌تنهایی کافی نیست**، چون استرپتوکوک‌های هوازی دهان را پوشش نمی‌دهد.",
 "One word settles this question: 'A HISTORY OF EPILEPSY'.\n\n"
 "WARNING, UNDERSTAND THE CHAIN OF REASONING AND YOU WILL NEVER FORGET IT:\n\n"
 "SEIZURES leads to EPISODES OF REDUCED CONSCIOUSNESS leads to ASPIRATION OF MOUTH CONTENTS leads to ORAL ANAEROBIC FLORA ENTERING THE LUNG.\n\n"
 "So the likely pathogen is ORAL ANAEROBES: peptostreptococci, Fusobacterium, Prevotella and Bacteroides.\n\n"
 "TWO ANATOMICAL POINTS THAT COMPLETE THE QUESTION:\n\n"
 "WARNING, WHY THE RIGHT LUNG? Because THE RIGHT MAIN BRONCHUS IS MORE VERTICAL, SHORTER AND WIDER; aspirated material naturally travels that way.\n\n"
 "WHICH SEGMENTS? Those that were GRAVITY-DEPENDENT at the moment of aspiration: lying supine, the SUPERIOR SEGMENT OF THE LOWER LOBE and the POSTERIOR SEGMENT OF THE UPPER LOBE.\n\n"
 "WHY THE OTHER OPTIONS FAIL:\n\n"
 "LEGIONELLA — its clue is exposure to AIR CONDITIONING OR WATER SYSTEMS together with DIARRHOEA, CONFUSION AND HYPONATRAEMIA; none of that is here.\n\n"
 "STAPHYLOCOCCUS — usually AFTER INFLUENZA and with THIN-WALLED CAVITIES.\n\n"
 "ENTEROCOCCUS — essentially not a lung pathogen; its place is urinary, intra-abdominal and endocardial infection.\n\n"
 "WARNING, TREATMENT: CLINDAMYCIN or AMOXICILLIN-CLAVULANATE. And note that METRONIDAZOLE ALONE IS NOT ENOUGH, because it does not cover the aerobic oral streptococci.",
 ["لژیونلا سرنخ خودش را دارد: تماس با کولر و سیستم آب، همراه با اسهال، گیجی و هیپوناترمی.",
  "استافیلوکوک اورئوس معمولاً پس از آنفلوانزا و با کاویته‌های جدارنازک متعدد مطرح می‌شود.",
  "انتروکوک عملاً پاتوژن ریوی نیست؛ جایگاهش عفونت ادراری، داخل‌شکمی و اندوکاردیت است.",
  "پاسخ صحیح — سابقه‌ی صرع یعنی خطر آسپیراسیون، و آسپیراسیون یعنی بی‌هوازی‌های دهانی."],
 ["Legionella has its own clue: exposure to air conditioning or water systems, with diarrhoea, confusion and hyponatraemia.",
  "Staphylococcus aureus is usually considered after influenza and with multiple thin-walled cavities.",
  "Enterococcus is essentially not a lung pathogen; its place is urinary, intra-abdominal and endocardial infection.",
  "Correct — a history of epilepsy means a risk of aspiration, and aspiration means oral anaerobes."],
 "**صرع/الکل/کاهش هوشیاری = آسپیراسیون = بی‌هوازی دهانی.** درمان: **کلیندامایسین یا کوآموکسی‌کلاو**.",
 "Epilepsy, alcohol or reduced consciousness means aspiration, which means oral anaerobes. Treat with clindamycin or co-amoxiclav.",
 [H126, ATS])


# =========================================================== book:75
add("book:75", "case", "medium",
 "**اسپلنکتومی** ← باکتری کپسول‌دار ← شایع‌ترین: **پنوموکوک**.",
 "SPLENECTOMY means encapsulated organisms, and the commonest is THE PNEUMOCOCCUS.",
 BUGS_FA + [
  "بیمار **دو ماه پس از طحال‌برداری** با تب ۳۹، تاکی‌کاردی، تاکی‌پنه و **افت فشار خون** آمده است.",
  "⚠️ **این تابلوی OPSI است: عفونت فراگیر پس از اسپلنکتومی (Overwhelming Post-Splenectomy Infection).**",
  "**چرا طحال این‌قدر مهم است؟** دو کار می‌کند که جای دیگری جبران نمی‌شود:",
  "**یک — فیلتر مکانیکی خون**: باکتری‌های اپسونیزه‌شده را از گردش خون بیرون می‌کشد.",
  "**دو — تولید آنتی‌بادی IgM** علیه آنتی‌ژن‌های پلی‌ساکاریدی کپسول.",
  "⚠️ پس بدونِ طحال، **باکتری کپسول‌دار می‌تواند در خون تکثیر شود بدون آنکه متوقف شود**.",
  "**نتیجه: سپسیس فولمینانت که در عرض ساعت‌ها پیش می‌رود و مرگ‌ومیرش بسیار بالاست.**",
  "**سه ارگانیسم اصلی را به ترتیب حفظ کنید:**",
  "⚠️ **یک — استرپتوکوک پنومونیه** (بیش از نیمی از موارد، و پاسخ این سؤال).",
  "**دو — هموفیلوس آنفولانزا تیپ b**. **سه — نایسریا مننژیتیدیس**.",
  "**پیشگیری، سه ستون دارد و هر سه پرسیده می‌شوند:**",
  "**واکسیناسیون** علیه هر سه ارگانیسم، ترجیحاً **دو هفته پیش از جراحی انتخابی**.",
  "**پروفیلاکسی آنتی‌بیوتیکی** (پنی‌سیلین خوراکی) به‌ویژه در کودکان و سال‌های اول.",
  "⚠️ **آموزش بیمار: هر تبی یک فوریت است** و باید فوراً آنتی‌بیوتیک شروع شود.",
  "**پسودوموناس** در این تابلو مطرح نیست؛ جایش بیمار **نوتروپنیک، سوختگی و بستری طولانی** است.",
 ],
 BUGS_EN + [
  "The patient presents TWO MONTHS AFTER SPLENECTOMY with a fever of 39, tachycardia, tachypnoea and HYPOTENSION.",
  "WARNING: THIS IS OPSI — OVERWHELMING POST-SPLENECTOMY INFECTION.",
  "WHY DOES THE SPLEEN MATTER SO MUCH? It does two things nothing else replaces:",
  "ONE — IT IS A MECHANICAL BLOOD FILTER, pulling opsonised bacteria out of the circulation.",
  "TWO — IT PRODUCES IgM ANTIBODY against the polysaccharide antigens of capsules.",
  "WARNING, so without a spleen AN ENCAPSULATED ORGANISM CAN MULTIPLY IN THE BLOOD UNCHECKED.",
  "THE RESULT: FULMINANT SEPSIS THAT PROGRESSES IN HOURS, with very high mortality.",
  "MEMORISE THE THREE MAIN ORGANISMS IN ORDER:",
  "WARNING, ONE — STREPTOCOCCUS PNEUMONIAE (more than half of cases, and the answer here).",
  "TWO — HAEMOPHILUS INFLUENZAE TYPE B. THREE — NEISSERIA MENINGITIDIS.",
  "PREVENTION HAS THREE PILLARS, and all three get asked:",
  "VACCINATION against all three organisms, ideally TWO WEEKS BEFORE ELECTIVE SURGERY.",
  "ANTIBIOTIC PROPHYLAXIS (oral penicillin), especially in children and in the first years.",
  "WARNING, PATIENT EDUCATION: ANY FEVER IS AN EMERGENCY and antibiotics must be started at once.",
  "PSEUDOMONAS does not belong to this picture; its place is the NEUTROPENIC, BURNED OR LONG-ADMITTED patient.",
 ],
 "بیمار **دو ماه پس از طحال‌برداری** با تب ۳۹ درجه، ضربان ۱۱۰، تنفس ۳۰ و **افت فشار خون** آمده است.\n\n"
 "⚠️ **این تابلوی OPSI است — عفونت فراگیر پس از اسپلنکتومی**، یکی از معدود فوریت‌های واقعی عفونی که ظرف ساعت‌ها می‌تواند بیمار را از پا دربیاورد.\n\n"
 "**چرا طحال این‌قدر مهم است؟** دو کار می‌کند که هیچ عضو دیگری جبرانشان نمی‌کند:\n\n"
 "**۱. فیلتر مکانیکی خون** — باکتری‌های اپسونیزه‌شده را از گردش خون بیرون می‌کشد.\n"
 "**۲. تولید آنتی‌بادی IgM** علیه آنتی‌ژن‌های **پلی‌ساکاریدی کپسول**.\n\n"
 "⚠️ نتیجه‌ی نبود طحال: **باکتری کپسول‌دار می‌تواند در خون بدون مانع تکثیر شود** و سپسیس فولمینانت بسازد.\n\n"
 "**سه ارگانیسم اصلی، به ترتیب فراوانی:**\n\n"
 "⚠️ **۱. استرپتوکوک پنومونیه** ← بیش از نیمی از موارد، و پاسخ این سؤال\n"
 "**۲. هموفیلوس آنفولانزا تیپ b**\n"
 "**۳. نایسریا مننژیتیدیس**\n\n"
 "همه‌ی این سه **کپسول‌دار**‌اند، و همین ویژگی مشترک، کل منطق را می‌سازد.\n\n"
 "**چرا پسودوموناس نه؟** چون پسودوموناس پاتوژن **نوتروپنی، سوختگی، فیبروز سیستیک و بستری طولانی** است، نه اسپلنکتومی.\n\n"
 "⚠️ **و سه ستون پیشگیری را بدانید، چون جداگانه هم پرسیده می‌شوند:** **واکسیناسیون** علیه هر سه ارگانیسم (ترجیحاً **دو هفته پیش از جراحی انتخابی**)، **پروفیلاکسی آنتی‌بیوتیکی** به‌ویژه در کودکان، و **آموزش بیمار** که **هر تبی یک فوریت است**.",
 "The patient presents TWO MONTHS AFTER SPLENECTOMY with a fever of 39, a pulse of 110, a respiratory rate of 30 and HYPOTENSION.\n\n"
 "WARNING: THIS IS OPSI — OVERWHELMING POST-SPLENECTOMY INFECTION, one of the few true infectious emergencies that can kill within hours.\n\n"
 "WHY DOES THE SPLEEN MATTER SO MUCH? It does two things no other organ replaces:\n\n"
 "1. IT IS A MECHANICAL BLOOD FILTER, removing opsonised bacteria from the circulation.\n"
 "2. IT PRODUCES IgM ANTIBODY against the POLYSACCHARIDE CAPSULAR antigens.\n\n"
 "WARNING, the consequence of having no spleen: AN ENCAPSULATED ORGANISM CAN MULTIPLY UNCHECKED IN THE BLOOD and produce fulminant sepsis.\n\n"
 "THE THREE MAIN ORGANISMS, IN ORDER OF FREQUENCY:\n\n"
 "WARNING, 1. STREPTOCOCCUS PNEUMONIAE — more than half of cases, and the answer here\n"
 "2. HAEMOPHILUS INFLUENZAE TYPE B\n"
 "3. NEISSERIA MENINGITIDIS\n\n"
 "All three are ENCAPSULATED, and that shared property is the whole logic.\n\n"
 "WHY NOT PSEUDOMONAS? Because Pseudomonas is the pathogen of NEUTROPENIA, BURNS, CYSTIC FIBROSIS AND PROLONGED ADMISSION, not of splenectomy.\n\n"
 "WARNING, AND KNOW THE THREE PILLARS OF PREVENTION, because they are asked separately: VACCINATION against all three organisms (ideally TWO WEEKS BEFORE ELECTIVE SURGERY), ANTIBIOTIC PROPHYLAXIS especially in children, and PATIENT EDUCATION that ANY FEVER IS AN EMERGENCY.",
 ["پاسخ صحیح — پنوموکوک شایع‌ترین عامل عفونت فراگیر پس از اسپلنکتومی است.",
  "هموفیلوس آنفولانزا هم کپسول‌دار و مطرح است، ولی از پنوموکوک بسیار کمتر شایع است.",
  "استافیلوکوک اورئوس کپسول‌دار کلاسیک نیست و عامل شاخص OPSI محسوب نمی‌شود.",
  "پسودوموناس پاتوژن نوتروپنی، سوختگی و بستری طولانی است، نه اسپلنکتومی."],
 ["Correct — the pneumococcus is the commonest cause of overwhelming post-splenectomy infection.",
  "Haemophilus influenzae is encapsulated and relevant, but far less common than the pneumococcus.",
  "Staphylococcus aureus is not a classical encapsulated organism and is not the hallmark cause of OPSI.",
  "Pseudomonas is the pathogen of neutropenia, burns and prolonged admission, not of splenectomy."],
 "**اسپلنکتومی ← کپسول‌دارها ← پنوموکوک اول.** هر تبی در بیمار بی‌طحال یک **فوریت** است.",
 "Splenectomy means encapsulated organisms, pneumococcus first. Any fever in an asplenic patient is an emergency.",
 [H126])


# =========================================================== book:76
add("book:76", "case", "hard",
 "**تعمیرکار کولر + هیپوناترمی + اسهال** ← **لژیونلا**.",
 "AN AIR-CONDITIONER REPAIRMAN with HYPONATRAEMIA and DIARRHOEA has LEGIONELLA.",
 BUGS_FA + [
  "این سؤال سه سرنخ می‌دهد و هر سه به یک ارگانیسم می‌رسند:",
  "⚠️ **یک — شغل: تعمیرکار کولر.** لژیونلا در **آب راکد و ولرم** رشد می‌کند:",
  "**برج‌های خنک‌کننده، کولرهای آبی، سیستم آب گرم، جکوزی و فواره‌ها**.",
  "انتقال با **آئروسل** است و **از فردی به فرد دیگر منتقل نمی‌شود**.",
  "⚠️ **دو — هیپوناترمی (Na=126).** این کلاسیک‌ترین سرنخ آزمایشگاهی لژیونلاست.",
  "**سه — تابلوی خارج‌ریوی: سردرد، میالژی، تهوع و اسهال** در کنار پنومونی.",
  "**همین «پنومونی به‌علاوه‌ی علائم گوارشی و عصبی» امضای لژیونلاست.**",
  "به این‌ها اضافه کنید: **افزایش آنزیم‌های کبدی**، **بالا بودن CPK** و **گیجی**.",
  "⚠️ و یک نکته‌ی مهم: **علی‌رغم تب بالا، ضربان قلب نسبتاً پایین است (برادی‌کاردی نسبی)**.",
  "**تشخیص: آنتی‌ژن ادراری لژیونلا** — سریع و در دسترس، ولی فقط **سروگروپ ۱** را می‌گیرد.",
  "⚠️ لژیونلا در **رنگ‌آمیزی گرم دیده نمی‌شود** و روی محیط‌های معمول رشد نمی‌کند؛",
  "کشتش **محیط BCYE** می‌خواهد. پس «کشت منفی» آن را رد نمی‌کند.",
  "**درمان: ماکرولید (آزیترومایسین) یا کینولون تنفسی (لووفلوکساسین).**",
  "چرا این دو؟ چون لژیونلا **داخل‌سلولی** است و دارو باید **داخل ماکروفاژ** نفوذ کند.",
  "⚠️ **و به همین دلیل بتالاکتام‌ها — از جمله سفتریاکسون — روی لژیونلا بی‌اثرند.**",
 ],
 BUGS_EN + [
  "This question gives three clues and all three converge on one organism:",
  "WARNING, ONE — THE OCCUPATION: AN AIR-CONDITIONER REPAIRMAN. Legionella grows in STAGNANT, TEPID WATER:",
  "COOLING TOWERS, EVAPORATIVE COOLERS, HOT-WATER SYSTEMS, WHIRLPOOLS AND FOUNTAINS.",
  "It spreads by AEROSOL and DOES NOT PASS FROM PERSON TO PERSON.",
  "WARNING, TWO — HYPONATRAEMIA (Na 126). This is the classical laboratory clue to Legionella.",
  "THREE — THE EXTRAPULMONARY PICTURE: headache, myalgia, nausea and DIARRHOEA alongside the pneumonia.",
  "THAT COMBINATION — PNEUMONIA PLUS GASTROINTESTINAL AND NEUROLOGICAL SYMPTOMS — IS THE SIGNATURE.",
  "Add to it: RAISED LIVER ENZYMES, a HIGH CPK and CONFUSION.",
  "WARNING, and an important point: DESPITE THE HIGH FEVER THE PULSE IS RELATIVELY SLOW (relative bradycardia).",
  "DIAGNOSIS: THE LEGIONELLA URINARY ANTIGEN — fast and available, but it detects only SEROGROUP 1.",
  "WARNING, Legionella IS NOT SEEN ON GRAM STAIN and does not grow on ordinary media;",
  "culture needs BCYE AGAR. So a negative routine culture does not exclude it.",
  "TREATMENT: A MACROLIDE (azithromycin) OR A RESPIRATORY QUINOLONE (levofloxacin).",
  "Why those two? Because Legionella is INTRACELLULAR and the drug must penetrate INTO THE MACROPHAGE.",
  "WARNING, AND THAT IS WHY BETA-LACTAMS — CEFTRIAXONE INCLUDED — ARE INEFFECTIVE AGAINST LEGIONELLA.",
 ],
 "این سؤال سه سرنخ می‌دهد و هر سه به یک ارگانیسم می‌رسند:\n\n"
 "⚠️ **۱. شغل: «تعمیرکار کولر»** — لژیونلا در **آب راکد و ولرم** رشد می‌کند: برج‌های خنک‌کننده، کولرهای آبی، سیستم آب گرم، جکوزی. انتقالش با **آئروسل** است و **از فرد به فرد منتقل نمی‌شود**.\n\n"
 "⚠️ **۲. هیپوناترمی (Na=126)** — کلاسیک‌ترین سرنخ آزمایشگاهی لژیونلا.\n\n"
 "**۳. تابلوی خارج‌ریوی** — سردرد، میالژی، تهوع و **اسهال** در کنار پنومونی.\n\n"
 "**همین ترکیبِ «پنومونی + علائم گوارشی + علائم عصبی + هیپوناترمی» امضای لژیونلاست.** به این‌ها **افزایش آنزیم‌های کبدی**، **CPK بالا** و **برادی‌کاردی نسبی** (نبض پایین‌تر از انتظار برای درجه‌ی تب) را هم اضافه کنید.\n\n"
 "**چرا گزینه‌های دیگر رد می‌شوند؟**\n\n"
 "**آسپرژیلوس** ← بیمار **نوتروپنیک یا شدیداً ایمنی‌سرکوب‌شده** می‌خواهد؛ این بیمار سالم است.\n\n"
 "**مایکوپلاسما** ← جوان‌ها، سیر تدریجی، سرفه‌ی خشک، بیمار **کم‌توکسیک**؛ نه این تابلوی توکسیک با هیپوناترمی.\n\n"
 "**پنومونی ازدیاد حساسیتی** ← معمولاً **بدون لکوسیتوز و بدون توکسیسیته** و با تماس مکرر آنتی‌ژنی.\n\n"
 "⚠️ **دو نکته‌ی حیاتی درباره‌ی تشخیص و درمان:**\n\n"
 "**لژیونلا در رنگ‌آمیزی گرم دیده نمی‌شود** و روی محیط معمول رشد نمی‌کند (نیازمند **BCYE**). پس «اسمیر و کشت منفی» آن را رد نمی‌کند. ابزار عملی، **آنتی‌ژن ادراری** است.\n\n"
 "**درمان: ماکرولید یا کینولون تنفسی** — چون لژیونلا **داخل‌سلولی** است و دارو باید به داخل ماکروفاژ نفوذ کند. ⚠️ **به همین دلیل بتالاکتام‌ها، از جمله سفتریاکسون، روی آن بی‌اثرند** — نکته‌ای که در سؤال بعدی همین فصل دوباره تعیین‌کننده می‌شود.",
 "This question gives three clues and all three converge on one organism:\n\n"
 "WARNING, 1. THE OCCUPATION: 'AN AIR-CONDITIONER REPAIRMAN' — Legionella grows in STAGNANT, TEPID WATER: cooling towers, evaporative coolers, hot-water systems, whirlpools. It spreads by AEROSOL and DOES NOT PASS FROM PERSON TO PERSON.\n\n"
 "WARNING, 2. HYPONATRAEMIA (Na 126) — the classical laboratory clue to Legionella.\n\n"
 "3. THE EXTRAPULMONARY PICTURE — headache, myalgia, nausea and DIARRHOEA alongside the pneumonia.\n\n"
 "THAT COMBINATION — PNEUMONIA PLUS GASTROINTESTINAL PLUS NEUROLOGICAL SYMPTOMS PLUS HYPONATRAEMIA — IS THE SIGNATURE. Add RAISED LIVER ENZYMES, a HIGH CPK, and RELATIVE BRADYCARDIA (a pulse lower than the fever would predict).\n\n"
 "WHY THE OTHER OPTIONS FAIL:\n\n"
 "ASPERGILLUS — needs a NEUTROPENIC OR SEVERELY IMMUNOSUPPRESSED host; this patient is healthy.\n\n"
 "MYCOPLASMA — young patients, gradual onset, dry cough, a patient who looks WELL; not this toxic picture with hyponatraemia.\n\n"
 "HYPERSENSITIVITY PNEUMONITIS — usually WITHOUT leucocytosis or toxicity, and with repeated antigen exposure.\n\n"
 "WARNING, TWO CRUCIAL POINTS ABOUT DIAGNOSIS AND TREATMENT:\n\n"
 "LEGIONELLA IS NOT SEEN ON GRAM STAIN and does not grow on ordinary media (it needs BCYE). So a negative smear and culture does not exclude it. The practical tool is the URINARY ANTIGEN.\n\n"
 "TREATMENT: A MACROLIDE OR A RESPIRATORY QUINOLONE — because Legionella is INTRACELLULAR and the drug must reach inside the macrophage. WARNING, THAT IS WHY BETA-LACTAMS, CEFTRIAXONE INCLUDED, ARE INEFFECTIVE — a point that becomes decisive again in the next question of this chapter.",
 ["پاسخ صحیح — تماس شغلی با کولر، هیپوناترمی، اسهال و تابلوی توکسیک، مجموعاً لژیونلا را مطرح می‌کند.",
  "آسپرژیلوس میزبان نوتروپنیک یا شدیداً ایمنی‌سرکوب‌شده می‌خواهد؛ این بیمار زمینه‌ی سالمی دارد.",
  "مایکوپلاسما سیر تدریجی و بیمار کم‌توکسیک دارد و هیپوناترمی و اسهال از ویژگی‌های آن نیست.",
  "پنومونی ازدیاد حساسیتی معمولاً بدون لکوسیتوز و بدون این درجه از توکسیسیته است."],
 ["Correct — occupational exposure to a cooler, hyponatraemia, diarrhoea and a toxic picture together point to Legionella.",
  "Aspergillus requires a neutropenic or severely immunosuppressed host; this patient has a healthy background.",
  "Mycoplasma has a gradual course in a non-toxic patient, and hyponatraemia and diarrhoea are not its features.",
  "Hypersensitivity pneumonitis is usually without leucocytosis and without this degree of toxicity."],
 "**کولر + هیپوناترمی + اسهال + گیجی = لژیونلا.** درمان: **ماکرولید یا کینولون تنفسی**؛ بتالاکتام بی‌اثر است.",
 "Cooler plus hyponatraemia plus diarrhoea plus confusion means Legionella. Treat with a macrolide or respiratory quinolone; beta-lactams do not work.",
 [H126, ATS])


# =========================================================== book:88
add("book:88", "case", "hard",
 "پنومونی + **اسهال و گیجی** + **سدیم ۱۲۸** ← لژیونلا ← **آزیترومایسین**، نه سفتریاکسون.",
 "Pneumonia with DIARRHOEA, CONFUSION and a SODIUM OF 128 is Legionella: give AZITHROMYCIN, not ceftriaxone.",
 BUGS_FA + [
  "⚠️ **توجه: پنل آزمایشگاهی این سؤال تصحیح شده است** و همین تصحیح، سؤال را قابل حل کرد.",
  "متن استخراج‌شده «Na=75» و «PLT=128» داشت؛ ولی صفحه‌ی ۳۴ در واقع جدولی دوستونی چاپ کرده",
  "که در آن **Na=128** و **PLT=245000** است. رقم‌ها با هم قاطی شده بودند.",
  "**چرا این تصحیح تعیین‌کننده است؟ چون هیپوناترمی همان چیزی است که پاسخ را می‌سازد.**",
  "با سدیم ۷۵ (که اصلاً با حیات سازگار نیست) سرنخ اصلی سؤال نابود شده بود.",
  "**حالا بیمار را بخوانید:** مرد **۶۵ ساله** با تب بالا، سرفه، **اسهال** و **کاهش سطح هوشیاری**.",
  "**در گرافی: درگیری یک‌طرفه که علی‌رغم درمان به سمت مقابل هم گسترش یافته.**",
  "⚠️ **پیشرفت درگیری علی‌رغم درمان، یعنی درمان اولیه ارگانیسم را پوشش نمی‌داده است.**",
  "و آزمایش‌ها: **Na=128** (هیپوناترمی)، **AST=40 و ALT=75** (اختلال خفیف کبدی).",
  "**همه‌ی این‌ها لژیونلاست: پنومونی + اسهال + گیجی + هیپوناترمی + اختلال کبدی.**",
  "⚠️ **پس چرا سفتریاکسون پاسخ نیست، با اینکه داروی رایج پنومونی است؟**",
  "چون **لژیونلا داخل‌سلولی است و بتالاکتام‌ها به داخل سلول نفوذ نمی‌کنند**.",
  "همین توضیح می‌دهد چرا بیماری **علی‌رغم درمان پیشرفت کرده**: احتمالاً بتالاکتام گرفته بوده.",
  "**آزیترومایسین (یا لووفلوکساسین) داخل ماکروفاژ متمرکز می‌شود و لژیونلا را می‌کشد.**",
  "**وانکومایسین** برای گرم‌مثبت‌های مقاوم است و **کولیستین** برای گرم‌منفی‌های بسیار مقاوم؛",
  "هیچ‌کدام روی یک ارگانیسم داخل‌سلولی کاری نمی‌کنند.",
 ],
 BUGS_EN + [
  "WARNING, NOTE: THE LABORATORY PANEL OF THIS QUESTION HAS BEEN CORRECTED, and the correction is what makes it answerable.",
  "The extracted text read 'Na=75' and 'PLT=128'; but page 34 actually prints a two-column table",
  "in which Na=128 AND PLT=245000. The digits had been scrambled together.",
  "WHY DOES THAT MATTER? BECAUSE THE HYPONATRAEMIA IS WHAT MAKES THE ANSWER.",
  "With a sodium of 75 — a value incompatible with life — the question's central clue had been destroyed.",
  "NOW READ THE PATIENT: a 65-YEAR-OLD man with high fever, cough, DIARRHOEA and REDUCED CONSCIOUSNESS.",
  "ON THE FILM: unilateral disease that has SPREAD TO THE OTHER SIDE DESPITE TREATMENT.",
  "WARNING: PROGRESSION DESPITE TREATMENT MEANS THE INITIAL THERAPY DID NOT COVER THE ORGANISM.",
  "And the laboratory: Na 128 (HYPONATRAEMIA), AST 40 and ALT 75 (mild hepatic derangement).",
  "ALL OF THAT IS LEGIONELLA: pneumonia plus diarrhoea plus confusion plus hyponatraemia plus liver derangement.",
  "WARNING, SO WHY IS CEFTRIAXONE NOT THE ANSWER, WHEN IT IS THE USUAL PNEUMONIA DRUG?",
  "Because LEGIONELLA IS INTRACELLULAR AND BETA-LACTAMS DO NOT PENETRATE INTO CELLS.",
  "That also explains why the disease PROGRESSED DESPITE TREATMENT: a beta-lactam was probably given.",
  "AZITHROMYCIN (OR LEVOFLOXACIN) CONCENTRATES INSIDE THE MACROPHAGE and kills Legionella.",
  "VANCOMYCIN is for resistant gram-positives and COLISTIN for highly resistant gram-negatives;",
  "neither does anything to an intracellular organism.",
 ],
 "⚠️ **پیش از هر چیز: پنل آزمایشگاهی این سؤال تصحیح شده است، و همین تصحیح سؤال را قابل حل کرد.**\n\n"
 "متن استخراج‌شده «Na=75» و «PLT=128» داشت. اما صفحه‌ی ۳۴ کتاب در واقع یک **جدول دوستونی** چاپ کرده که در آن **Na = 128** و **PLT = 245000** است؛ استخراج، برچسب‌ها را جابه‌جا کرده و شمارش پلاکت را کلاً انداخته بود.\n\n"
 "**چرا این مهم است؟ چون هیپوناترمی همان سرنخی است که پاسخ را می‌سازد.** با «سدیم ۷۵» — عددی که اصلاً با حیات سازگار نیست — قلب سؤال از بین رفته بود.\n\n"
 "**حالا بیمار را بخوانید:**\n\n"
 "مرد ۶۵ ساله، تب بالا، سرفه، **اسهال**، **کاهش سطح هوشیاری**\n"
 "گرافی: درگیری یک‌طرفه که **علی‌رغم درمان به سمت مقابل هم گسترش یافته**\n"
 "آزمایش: **Na=128**، AST=40، ALT=75\n\n"
 "**این دقیقاً لژیونلاست:** پنومونی + علائم گوارشی + علائم عصبی + هیپوناترمی + اختلال خفیف کبدی.\n\n"
 "⚠️ **و نکته‌ی درمانی که سؤال روی آن دست گذاشته:**\n\n"
 "**چرا سفتریاکسون پاسخ نیست، با آنکه داروی رایج پنومونی بستری است؟** چون **لژیونلا ارگانیسمی داخل‌سلولی است و بتالاکتام‌ها به داخل سلول نفوذ نمی‌کنند**. همین هم توضیح می‌دهد که چرا بیماری **علی‌رغم درمان پیشرفت کرده است** — به احتمال زیاد بیمار بتالاکتام گرفته بوده.\n\n"
 "**پس درمان درست: آزیترومایسین** (یا لووفلوکساسین)، که **داخل ماکروفاژ متمرکز می‌شود**.\n\n"
 "**وانکومایسین** برای گرم‌مثبت‌های مقاوم و **کولیستین** برای گرم‌منفی‌های بسیار مقاوم است؛ هیچ‌کدام روی یک ارگانیسم داخل‌سلولی کاری از پیش نمی‌برند.",
 "WARNING, FIRST OF ALL: THE LABORATORY PANEL OF THIS QUESTION HAS BEEN CORRECTED, and that correction is what makes it answerable.\n\n"
 "The extracted text read 'Na=75' and 'PLT=128'. But page 34 of the book actually prints a TWO-COLUMN TABLE in which Na = 128 and PLT = 245000; the extraction swapped the labels and dropped the platelet count entirely.\n\n"
 "WHY DOES THAT MATTER? BECAUSE THE HYPONATRAEMIA IS THE CLUE THAT MAKES THE ANSWER. With 'sodium 75' — a value incompatible with life — the heart of the question had been destroyed.\n\n"
 "NOW READ THE PATIENT:\n\n"
 "A 65-year-old man, high fever, cough, DIARRHOEA, REDUCED CONSCIOUSNESS\n"
 "Film: unilateral disease that HAS SPREAD TO THE OTHER SIDE DESPITE TREATMENT\n"
 "Laboratory: Na 128, AST 40, ALT 75\n\n"
 "THIS IS EXACTLY LEGIONELLA: pneumonia plus gastrointestinal symptoms plus neurological symptoms plus hyponatraemia plus mild hepatic derangement.\n\n"
 "WARNING, AND THE THERAPEUTIC POINT THE QUESTION PRESSES ON:\n\n"
 "WHY IS CEFTRIAXONE NOT THE ANSWER, when it is the usual drug for inpatient pneumonia? Because LEGIONELLA IS AN INTRACELLULAR ORGANISM AND BETA-LACTAMS DO NOT PENETRATE INTO CELLS. That also explains why the disease PROGRESSED DESPITE TREATMENT — the patient had probably been given a beta-lactam.\n\n"
 "SO THE RIGHT TREATMENT IS AZITHROMYCIN (or levofloxacin), which CONCENTRATES INSIDE THE MACROPHAGE.\n\n"
 "VANCOMYCIN is for resistant gram-positives and COLISTIN for highly resistant gram-negatives; neither achieves anything against an intracellular organism.",
 ["پاسخ صحیح — تابلوی لژیونلا (اسهال، گیجی، هیپوناترمی) درمان با ماکرولید یا کینولون تنفسی می‌خواهد.",
  "سفتریاکسون یک بتالاکتام است و به داخل سلول نفوذ نمی‌کند؛ روی لژیونلای داخل‌سلولی بی‌اثر است.",
  "کولیستین برای گرم‌منفی‌های بسیار مقاوم است و در این تابلو هیچ جایگاهی ندارد.",
  "وانکومایسین برای گرم‌مثبت‌های مقاوم است و روی ارگانیسم داخل‌سلولی اثری ندارد."],
 ["Correct — a Legionella picture (diarrhoea, confusion, hyponatraemia) needs a macrolide or respiratory quinolone.",
  "Ceftriaxone is a beta-lactam and does not enter cells; it is ineffective against intracellular Legionella.",
  "Colistin is for highly resistant gram-negatives and has no place in this picture.",
  "Vancomycin is for resistant gram-positives and does nothing against an intracellular organism."],
 "**پیشرفت پنومونی علی‌رغم بتالاکتام + هیپوناترمی + اسهال = لژیونلا.** درمان **داخل‌سلولی‌رس** لازم است.",
 "Pneumonia progressing despite a beta-lactam, with hyponatraemia and diarrhoea, means Legionella. It needs a drug that gets inside cells.",
 [H126, ATS])


# =========================================================== book:77
add("book:77", "case", "medium",
 "**آگلوتینین سرد** + جوان + سرفه‌ی خشک + **آنمی داسی‌شکل** ← **مایکوپلاسما**.",
 "COLD AGGLUTININS in a young patient with a dry cough and SICKLE CELL DISEASE means MYCOPLASMA.",
 BUGS_FA + [
  "دختر **۱۲ ساله** با **آنمی داسی‌شکل**، تب، **سرفه‌ی بدون خلط**، تهوع، استفراغ و اسهال.",
  "⚠️ **تست آگلوتیناسیون سرد مثبت** — و همین یک یافته تقریباً تشخیص را می‌گذارد.",
  "**آگلوتینین سرد چیست؟** آنتی‌بادی **IgM** که علیه **آنتی‌ژن I گلبول قرمز** ساخته می‌شود.",
  "چرا در مایکوپلاسما؟ چون **آنتی‌ژن سطحی مایکوپلاسما شباهت ساختاری با آنتی‌ژن I دارد**",
  "و آنتی‌بادی ضدمیکروب، به‌اشتباه گلبول قرمز خود بیمار را هم هدف می‌گیرد — یک **تقلید مولکولی**.",
  "**در دمای پایین این آنتی‌بادی به گلبول می‌چسبد و آگلوتیناسیون و همولیز می‌سازد.**",
  "⚠️ **و حالا نکته‌ی حیاتی این سؤال: نکروز انگشتان پا.**",
  "در بیمار **داسی‌شکل**، آگلوتیناسیون سرد و همولیز، **بحران وازواکلوزیو** را شعله‌ور می‌کند:",
  "گلبول‌ها در عروق کوچک انتهایی به هم می‌چسبند و **ایسکمی و نکروز دیجیتال** می‌سازند.",
  "**پس مایکوپلاسما در بیمار داسی‌شکل خطرناک‌تر از جمعیت عمومی است.**",
  "**بقیه‌ی تابلوی مایکوپلاسما را هم بدانید:** سن **۵ تا ۲۰ سال**، شروع **تدریجی**،",
  "**سرفه‌ی خشک و مقاوم**، و **ناهماهنگی معاینه با گرافی** (گرافی بدتر از بیمار).",
  "⚠️ **درمان: ماکرولید یا داکسی‌سیکلین.**",
  "**چرا بتالاکتام هرگز؟ چون مایکوپلاسما اصلاً دیواره‌ی سلولی ندارد** —",
  "و بتالاکتام‌ها دقیقاً سنتز دیواره را مهار می‌کنند. **هدفی وجود ندارد که مهار شود.**",
 ],
 BUGS_EN + [
  "A 12-YEAR-OLD GIRL with SICKLE CELL DISEASE, fever, a NON-PRODUCTIVE COUGH, nausea, vomiting and diarrhoea.",
  "WARNING: A POSITIVE COLD AGGLUTININ TEST — and that finding alone nearly makes the diagnosis.",
  "WHAT ARE COLD AGGLUTININS? IgM ANTIBODY directed against the I ANTIGEN OF THE RED CELL.",
  "Why in Mycoplasma? Because THE ORGANISM'S SURFACE ANTIGEN RESEMBLES THE I ANTIGEN STRUCTURALLY,",
  "so the antimicrobial antibody mistakenly targets the patient's own red cells — MOLECULAR MIMICRY.",
  "AT LOW TEMPERATURES THIS ANTIBODY BINDS THE RED CELL, causing agglutination and haemolysis.",
  "WARNING, AND NOW THE CRUCIAL POINT OF THIS QUESTION: NECROSIS OF THE TOES.",
  "In a SICKLE CELL patient, cold agglutination and haemolysis IGNITE A VASO-OCCLUSIVE CRISIS:",
  "cells clump in the small distal vessels and produce DIGITAL ISCHAEMIA AND NECROSIS.",
  "SO MYCOPLASMA IS MORE DANGEROUS IN A SICKLE CELL PATIENT THAN IN THE GENERAL POPULATION.",
  "KNOW THE REST OF THE MYCOPLASMA PICTURE TOO: age 5 TO 20, GRADUAL onset,",
  "a DRY, PERSISTENT COUGH, and A MISMATCH BETWEEN EXAMINATION AND FILM (the film looks worse than the patient).",
  "WARNING, TREATMENT: A MACROLIDE OR DOXYCYCLINE.",
  "WHY NEVER A BETA-LACTAM? BECAUSE MYCOPLASMA HAS NO CELL WALL AT ALL —",
  "and beta-lactams work precisely by inhibiting cell wall synthesis. THERE IS NO TARGET TO INHIBIT.",
 ],
 "دختر **۱۲ ساله** با **آنمی داسی‌شکل**، تب، **سرفه‌ی بدون خلط**، و علائم گوارشی. و یک یافته که تقریباً به‌تنهایی تشخیص را می‌گذارد: ⚠️ **تست آگلوتیناسیون سرد مثبت**.\n\n"
 "**آگلوتینین سرد چیست و چرا در مایکوپلاسما مثبت می‌شود؟**\n\n"
 "آنتی‌بادی **IgM** است که علیه **آنتی‌ژن I گلبول قرمز** ساخته می‌شود. علتش **تقلید مولکولی** است: آنتی‌ژن سطحی مایکوپلاسما شباهت ساختاری با آنتی‌ژن I دارد، پس آنتی‌بادی‌ای که بدن علیه میکروب می‌سازد، **گلبول قرمز خودِ بیمار را هم هدف می‌گیرد**. در دمای پایین، این آنتی‌بادی به گلبول می‌چسبد و آگلوتیناسیون و همولیز می‌سازد.\n\n"
 "⚠️ **و حالا کلیدی‌ترین بخش این سؤال: چرا نکروز انگشتان پا؟**\n\n"
 "در بیمار **داسی‌شکل**، آگلوتیناسیون سرد و همولیز، **بحران وازواکلوزیو** را شعله‌ور می‌کند. گلبول‌ها در عروق کوچک انتهایی به هم می‌چسبند و **ایسکمی و نکروز دیجیتال** می‌سازند. یعنی مایکوپلاسما در بیمار داسی‌شکل **به‌مراتب خطرناک‌تر** از جمعیت عمومی است.\n\n"
 "**بقیه‌ی تابلوی مایکوپلاسما:** سن **۵ تا ۲۰ سال**، شروع **تدریجی**، **سرفه‌ی خشک و مقاوم**، و **ناهماهنگی معاینه با گرافی** (گرافی بدتر از حال بیمار به نظر می‌رسد).\n\n"
 "⚠️ **درمان: ماکرولید یا داکسی‌سیکلین. و هرگز بتالاکتام.**\n\n"
 "**چرا؟ چون مایکوپلاسما اصلاً دیواره‌ی سلولی ندارد** و بتالاکتام‌ها دقیقاً سنتز دیواره را مهار می‌کنند. هدفی وجود ندارد که مهار شود — این یکی از تمیزترین نمونه‌های «مکانیسم دارو، درمان را تعیین می‌کند» در کل عفونی است.",
 "A 12-YEAR-OLD GIRL with SICKLE CELL DISEASE, fever, a NON-PRODUCTIVE COUGH and gastrointestinal symptoms. And one finding that nearly makes the diagnosis on its own: WARNING, A POSITIVE COLD AGGLUTININ TEST.\n\n"
 "WHAT ARE COLD AGGLUTININS AND WHY ARE THEY POSITIVE IN MYCOPLASMA?\n\n"
 "They are IgM ANTIBODY against the I ANTIGEN OF THE RED CELL. The cause is MOLECULAR MIMICRY: the surface antigen of Mycoplasma structurally resembles the I antigen, so the antibody the body makes against the microbe ALSO TARGETS THE PATIENT'S OWN RED CELLS. At low temperature this antibody binds the cell and causes agglutination and haemolysis.\n\n"
 "WARNING, AND NOW THE KEY PART OF THIS QUESTION: WHY NECROSIS OF THE TOES?\n\n"
 "In a SICKLE CELL patient, cold agglutination and haemolysis IGNITE A VASO-OCCLUSIVE CRISIS. Cells clump in the small distal vessels and produce DIGITAL ISCHAEMIA AND NECROSIS. Mycoplasma is therefore FAR MORE DANGEROUS in a sickle cell patient than in the general population.\n\n"
 "THE REST OF THE MYCOPLASMA PICTURE: age 5 TO 20, GRADUAL onset, a DRY PERSISTENT COUGH, and A MISMATCH BETWEEN EXAMINATION AND FILM (the film looks worse than the patient does).\n\n"
 "WARNING, TREATMENT: A MACROLIDE OR DOXYCYCLINE. AND NEVER A BETA-LACTAM.\n\n"
 "WHY? BECAUSE MYCOPLASMA HAS NO CELL WALL AT ALL, and beta-lactams work precisely by inhibiting cell wall synthesis. There is no target to inhibit — one of the cleanest examples in all of infectious disease of a drug's mechanism dictating the treatment.",
 ["کلامیدیا پنومونیه هم پنومونی آتیپیک می‌دهد ولی آگلوتینین سرد از ویژگی‌های شاخص آن نیست.",
  "لژیونلا با هیپوناترمی، اسهال و گیجی مطرح می‌شود و آگلوتینین سرد نمی‌سازد.",
  "استافیلوکوک اورئوس معمولاً پس از آنفلوانزا و با کاویته مطرح است، نه با آگلوتینین سرد.",
  "پاسخ صحیح — آگلوتینین سرد مثبت در نوجوان با سرفه‌ی خشک، و بحران وازواکلوزیو در بیمار داسی‌شکل: مایکوپلاسما."],
 ["Chlamydia pneumoniae also causes atypical pneumonia, but cold agglutinins are not its hallmark.",
  "Legionella presents with hyponatraemia, diarrhoea and confusion, and does not produce cold agglutinins.",
  "Staphylococcus aureus is considered after influenza and with cavitation, not with cold agglutinins.",
  "Correct — positive cold agglutinins in an adolescent with a dry cough, and vaso-occlusive crisis in sickle cell disease: Mycoplasma."],
 "**آگلوتینین سرد = مایکوپلاسما.** بدون دیواره‌ی سلولی، پس **بتالاکتام بی‌فایده**؛ ماکرولید یا داکسی‌سیکلین.",
 "Cold agglutinins mean Mycoplasma. It has no cell wall, so beta-lactams are useless; give a macrolide or doxycycline.",
 [H126])


# =========================================================== book:82
add("book:82", "recall", "easy",
 "**سیپروفلوکساسین کینولون تنفسی نیست** و در پنومونی جایی ندارد.",
 "CIPROFLOXACIN IS NOT A RESPIRATORY QUINOLONE and has no place in pneumonia.",
 RX_FA + [
  "این سؤال، و سه سؤال دیگر همین فصل، **یک سؤال‌اند با چهار صورت متفاوت**.",
  "بیمار: **۵۰ ساله، بدون بیماری زمینه‌ای، بدون آنتی‌بیوتیک در سه ماه گذشته**، پنومونی لوب تحتانی.",
  "**پس در دسته‌ی «سرپاییِ سالم» قرار می‌گیرد** و سه انتخاب دارد:",
  "**آموکسی‌سیلین**، **داکسی‌سیکلین**، یا **ماکرولید** (آزیترومایسین/کلاریترومایسین).",
  "سه گزینه‌ی درست همین‌ها هستند و **سیپروفلوکساسین تنها گزینه‌ی نامناسب است**.",
  "⚠️ **چرا سیپروفلوکساسین نه؟ یک دلیل، و همان کافی است:**",
  "**اثر سیپروفلوکساسین روی استرپتوکوک پنومونیه ضعیف است.**",
  "و پنوموکوک **شایع‌ترین عامل پنومونی اکتسابی از جامعه** است.",
  "پس دارویی که شایع‌ترین عامل را پوشش نمی‌دهد، برای درمان تجربی مناسب نیست.",
  "⚠️ **اصطلاح «کینولون تنفسی» را دقیق بدانید — فقط دو دارو در آن می‌گنجند:**",
  "**لووفلوکساسین** و **موکسی‌فلوکساسین**. (جمی‌فلوکساسین هم در برخی منابع افزوده می‌شود.)",
  "**سیپروفلوکساسین جزو آن‌ها نیست.** جایگاه سیپرو: **گرم‌منفی‌ها، پسودوموناس، ادراری و گوارشی**.",
  "**یک نکته‌ی عملی: چرا در پنومونیِ سرپاییِ سالم اصلاً کینولون ندهیم؟**",
  "چون راهنمای ATS/IDSA کینولون‌ها را برای **بیمار دارای بیماری زمینه‌ای** نگه می‌دارد،",
  "تا هم مقاومت کمتر شود و هم عوارضشان (تاندونیت، QT، اثرات CNS) بیهوده تحمیل نشود.",
 ],
 RX_EN + [
  "This question, and three others in this chapter, ARE ONE QUESTION IN FOUR DISGUISES.",
  "The patient: 50 YEARS OLD, NO COMORBIDITY, NO ANTIBIOTICS IN THREE MONTHS, lower lobe pneumonia.",
  "SO HE FALLS IN THE 'HEALTHY OUTPATIENT' CATEGORY, with three choices:",
  "AMOXICILLIN, DOXYCYCLINE, or a MACROLIDE (azithromycin/clarithromycin).",
  "Those are the three correct options, and CIPROFLOXACIN IS THE ONE THAT DOES NOT BELONG.",
  "WARNING, WHY NOT CIPROFLOXACIN? One reason, and it is enough:",
  "CIPROFLOXACIN HAS POOR ACTIVITY AGAINST STREPTOCOCCUS PNEUMONIAE.",
  "And the pneumococcus is THE COMMONEST CAUSE OF COMMUNITY-ACQUIRED PNEUMONIA.",
  "A drug that misses the commonest cause is not suitable for empirical therapy.",
  "WARNING, KNOW THE TERM 'RESPIRATORY QUINOLONE' PRECISELY — only two drugs fit it:",
  "LEVOFLOXACIN and MOXIFLOXACIN. (Some sources add gemifloxacin.)",
  "CIPROFLOXACIN IS NOT ONE OF THEM. Its place is GRAM-NEGATIVES, PSEUDOMONAS, URINARY AND GUT INFECTION.",
  "A PRACTICAL POINT: why avoid quinolones altogether in the healthy outpatient?",
  "Because the ATS/IDSA guideline RESERVES them for patients WITH COMORBIDITIES,",
  "both to limit resistance and to avoid imposing their harms (tendinitis, QT, CNS effects) needlessly.",
 ],
 "⚠️ **این سؤال، به‌همراه سه سؤال دیگر همین فصل، در واقع یک سؤال است با چهار صورت متفاوت. و پاسخ هر چهار تا یکی است: سیپروفلوکساسین.**\n\n"
 "**اول بیمار را دسته‌بندی کنید:** ۵۰ ساله، **بدون بیماری زمینه‌ای**، **بدون مصرف آنتی‌بیوتیک در سه ماه گذشته**، پنومونی لوب تحتانی.\n\n"
 "**پس «سرپاییِ سالم» است**، و طبق راهنمای ATS/IDSA سال ۲۰۱۹ سه انتخاب دارد:\n\n"
 "**آموکسی‌سیلین ۱ گرم هر ۸ ساعت**\n"
 "**داکسی‌سیکلین ۱۰۰ میلی‌گرم دو بار در روز**\n"
 "**ماکرولید** (آزیترومایسین یا کلاریترومایسین) اگر مقاومت پنوموکوک منطقه زیر ۲۵٪ باشد\n\n"
 "سه گزینه‌ی سؤال دقیقاً همین‌ها هستند، و **سیپروفلوکساسین تنها موردی است که در این فهرست جا ندارد**.\n\n"
 "⚠️ **چرا؟ یک دلیل، و همان کافی است:**\n\n"
 "**اثر سیپروفلوکساسین روی استرپتوکوک پنومونیه ضعیف است** — و پنوموکوک **شایع‌ترین عامل پنومونی اکتسابی از جامعه** است. دارویی که شایع‌ترین عامل را نمی‌پوشاند، برای درمان تجربی مناسب نیست.\n\n"
 "⚠️ **اصطلاح «کینولون تنفسی» را دقیق بدانید:** فقط **لووفلوکساسین** و **موکسی‌فلوکساسین** (و در برخی منابع جمی‌فلوکساسین) در آن می‌گنجند. **سیپروفلوکساسین جزو آن‌ها نیست.** جایگاه واقعی سیپرو: **گرم‌منفی‌ها، پسودوموناس، عفونت ادراری و گوارشی**.\n\n"
 "و یک نکته‌ی سیاست درمانی: حتی کینولون تنفسی هم در بیمار **سالم** توصیه نمی‌شود؛ راهنما آن را برای بیمار **دارای بیماری زمینه‌ای** نگه می‌دارد تا مقاومت کمتر شود و عوارض (تاندونیت، طولانی شدن QT، اثرات عصبی) بیهوده تحمیل نشود.",
 "WARNING: THIS QUESTION, TOGETHER WITH THREE OTHERS IN THIS CHAPTER, IS ONE QUESTION IN FOUR DISGUISES. And the answer to all four is the same: CIPROFLOXACIN.\n\n"
 "FIRST CATEGORISE THE PATIENT: 50 years old, NO COMORBIDITY, NO ANTIBIOTICS IN THE LAST THREE MONTHS, lower lobe pneumonia.\n\n"
 "SO HE IS A 'HEALTHY OUTPATIENT', and by the 2019 ATS/IDSA guideline he has three choices:\n\n"
 "AMOXICILLIN 1 g every 8 hours\n"
 "DOXYCYCLINE 100 mg twice daily\n"
 "A MACROLIDE (azithromycin or clarithromycin) where local pneumococcal resistance is under 25%\n\n"
 "Those are exactly three of the options, and CIPROFLOXACIN IS THE ONE THAT DOES NOT BELONG.\n\n"
 "WARNING, WHY? One reason, and it is enough:\n\n"
 "CIPROFLOXACIN HAS POOR ACTIVITY AGAINST STREPTOCOCCUS PNEUMONIAE — and the pneumococcus is THE COMMONEST CAUSE of community-acquired pneumonia. A drug that misses the commonest cause is unsuitable for empirical therapy.\n\n"
 "WARNING, KNOW THE TERM 'RESPIRATORY QUINOLONE' PRECISELY: only LEVOFLOXACIN and MOXIFLOXACIN (and in some sources gemifloxacin) qualify. CIPROFLOXACIN IS NOT ONE OF THEM. Its real place is GRAM-NEGATIVES, PSEUDOMONAS, AND URINARY AND GASTROINTESTINAL INFECTION.\n\n"
 "And a point of therapeutic policy: even a respiratory quinolone is not recommended in the HEALTHY patient; the guideline reserves it for those WITH COMORBIDITIES, to limit resistance and to avoid imposing its harms (tendinitis, QT prolongation, CNS effects) needlessly.",
 ["آزیترومایسین یکی از سه انتخاب درست برای پنومونی سرپایی در فرد بدون بیماری زمینه‌ای است.",
  "کلاریترومایسین هم مانند آزیترومایسین یک ماکرولید و انتخاب پذیرفته‌شده است.",
  "پاسخ صحیح — سیپروفلوکساسین کینولون تنفسی نیست و پوشش ضعیفی روی پنوموکوک دارد.",
  "داکسی‌سیکلین یکی از سه انتخاب اول برای بیمار سرپایی بدون بیماری زمینه‌ای است."],
 ["Azithromycin is one of the three correct choices for outpatient pneumonia without comorbidity.",
  "Clarithromycin, like azithromycin, is a macrolide and an accepted choice.",
  "Correct — ciprofloxacin is not a respiratory quinolone and covers the pneumococcus poorly.",
  "Doxycycline is one of the three first-line choices for an outpatient without comorbidity."],
 "**کینولون تنفسی = لووفلوکساسین و موکسی‌فلوکساسین.** سیپروفلوکساسین **پنوموکوک را نمی‌پوشاند**.",
 "The respiratory quinolones are levofloxacin and moxifloxacin. Ciprofloxacin does not cover the pneumococcus.",
 [ATS, H126])


# =========================================================== book:86
add("book:86", "case", "medium",
 "**آنتی‌بیوتیک در ماه گذشته** ← بیمار دیگر «سالم» نیست ← **کینولون تنفسی**.",
 "ANTIBIOTICS IN THE PAST MONTH means the patient is no longer 'healthy': give a RESPIRATORY QUINOLONE.",
 RX_FA + [
  "این سؤال آینه‌ی سؤال قبلی است و **یک تفاوت کوچک، پاسخ را کاملاً برمی‌گرداند**.",
  "بیمار: **۵۰ ساله بدون بیماری زمینه‌ای** — تا اینجا شبیه بیمار «سالم» است.",
  "⚠️ **ولی یک جمله همه‌چیز را عوض می‌کند: «سابقه‌ی مصرف آنتی‌بیوتیک در یک ماه گذشته دارد».**",
  "**چرا مصرف اخیر آنتی‌بیوتیک این‌قدر مهم است؟**",
  "چون **فشار انتخابی** ایجاد کرده و احتمال **پنوموکوک مقاوم به آن کلاس** را بالا برده است.",
  "**قاعده‌ی ATS/IDSA: اگر بیمار اخیراً آنتی‌بیوتیک گرفته، باید از یک کلاس متفاوت استفاده شود.**",
  "و همین بیمار را از دسته‌ی «سرپاییِ سالم» به دسته‌ی **«دارای عامل خطر»** منتقل می‌کند.",
  "**پس گزینه‌های دسته‌ی سالم دیگر مناسب نیستند:**",
  "**اریترومایسین** و **داکسی‌سیکلین** ← درمان دسته‌ی سالم؛ اینجا خطر شکست بالاتر است.",
  "⚠️ **کوآموکسی‌کلاو** ← درست‌نماست، ولی **به‌تنهایی پوشش آتیپیک ندارد**؛",
  "طبق راهنما باید **ماکرولید یا داکسی‌سیکلین به آن اضافه شود** — که در گزینه‌ها نیست.",
  "**پس تنها گزینه‌ی کاملِ تک‌دارویی، لووفلوکساسین است.**",
  "**کینولون تنفسی به‌تنهایی هم پنوموکوک و هم آتیپیک‌ها را می‌پوشاند** و دقیقاً برای همین گروه است.",
  "⚠️ **قاعده‌ی امتحانی:** واژه‌های **«بیماری زمینه‌ای»** یا **«آنتی‌بیوتیک اخیر»** یعنی از دسته‌ی سالم خارج شو.",
 ],
 RX_EN + [
  "This question mirrors the previous one, and ONE SMALL DIFFERENCE COMPLETELY REVERSES THE ANSWER.",
  "The patient: 50 YEARS OLD WITH NO UNDERLYING DISEASE — so far he looks like the 'healthy' patient.",
  "WARNING, BUT ONE SENTENCE CHANGES EVERYTHING: 'HE HAS TAKEN ANTIBIOTICS IN THE PAST MONTH'.",
  "WHY DOES RECENT ANTIBIOTIC USE MATTER SO MUCH?",
  "Because it has applied SELECTION PRESSURE and raised the chance of a PNEUMOCOCCUS RESISTANT TO THAT CLASS.",
  "THE ATS/IDSA RULE: IF THE PATIENT HAS HAD RECENT ANTIBIOTICS, A DIFFERENT CLASS MUST BE USED.",
  "And that moves him out of 'healthy outpatient' and into the RISK-FACTOR category.",
  "SO THE HEALTHY-CATEGORY OPTIONS ARE NO LONGER APPROPRIATE:",
  "ERYTHROMYCIN and DOXYCYCLINE are healthy-category therapy; here the failure risk is higher.",
  "WARNING, CO-AMOXICLAV looks right, but ALONE IT HAS NO ATYPICAL COVER;",
  "the guideline requires A MACROLIDE OR DOXYCYCLINE ADDED TO IT — which is not among the options.",
  "SO THE ONLY COMPLETE SINGLE-AGENT OPTION IS LEVOFLOXACIN.",
  "A RESPIRATORY QUINOLONE ALONE COVERS BOTH THE PNEUMOCOCCUS AND THE ATYPICALS, and exists for exactly this group.",
  "WARNING, THE EXAM RULE: the words 'COMORBIDITY' or 'RECENT ANTIBIOTICS' mean leave the healthy category.",
 ],
 "این سؤال **آینه‌ی سؤال قبلی** است، و یک تفاوت کوچک پاسخ را کاملاً برمی‌گرداند. مقایسه‌ی این دو، بهترین راه یادگیری کل بلوک درمان است.\n\n"
 "بیمار **۵۰ ساله و بدون بیماری زمینه‌ای** است — تا اینجا شبیه بیمار «سالم».\n\n"
 "⚠️ **ولی یک جمله همه‌چیز را عوض می‌کند: «سابقه‌ی مصرف آنتی‌بیوتیک در یک ماه گذشته».**\n\n"
 "**چرا این‌قدر مهم است؟** چون مصرف اخیر آنتی‌بیوتیک **فشار انتخابی** ایجاد کرده و احتمال **پنوموکوک مقاوم به همان کلاس** را بالا برده است. قاعده‌ی ATS/IDSA صریح است: **اگر بیمار اخیراً آنتی‌بیوتیک گرفته، باید از یک کلاس متفاوت استفاده شود** — و همین، بیمار را از دسته‌ی «سرپاییِ سالم» بیرون می‌برد.\n\n"
 "**حالا گزینه‌ها را با این دسته‌بندی جدید بسنجید:**\n\n"
 "**اریترومایسین** ← ماکرولید، درمان دسته‌ی سالم؛ اینجا خطر شکست بالاتر است.\n\n"
 "**داکسی‌سیکلین** ← همان دسته؛ همان اشکال.\n\n"
 "⚠️ **کوآموکسی‌کلاو** ← اینجا تله‌ی ظریف سؤال است. کوآموکسی‌کلاو **بتالاکتام مناسبی** برای این گروه است، **ولی به‌تنهایی پوشش آتیپیک (مایکوپلاسما، کلامیدیا، لژیونلا) ندارد**. راهنما می‌گوید باید **ماکرولید یا داکسی‌سیکلین به آن اضافه شود** — و در گزینه‌ها چنین ترکیبی نیست.\n\n"
 "**پس تنها گزینه‌ای که به‌تنهایی کامل است، لووفلوکساسین است:** یک **کینولون تنفسی** که هم پنوموکوک و هم آتیپیک‌ها را می‌پوشاند، و دقیقاً برای همین گروه از بیماران کنار گذاشته شده است.\n\n"
 "⚠️ **قاعده‌ی امتحانی را بسپارید:** هرجا واژه‌ی **«بیماری زمینه‌ای»** یا **«آنتی‌بیوتیک اخیر»** دیدید، بیمار دیگر در دسته‌ی سالم نیست.",
 "This question MIRRORS THE PREVIOUS ONE, and one small difference completely reverses the answer. Comparing the two is the best way to learn the whole treatment block.\n\n"
 "The patient is 50 YEARS OLD WITH NO UNDERLYING DISEASE — so far, the 'healthy' patient.\n\n"
 "WARNING, BUT ONE SENTENCE CHANGES EVERYTHING: 'HE HAS TAKEN ANTIBIOTICS IN THE PAST MONTH'.\n\n"
 "WHY DOES THAT MATTER SO MUCH? Because recent antibiotic use has applied SELECTION PRESSURE and raised the chance of a PNEUMOCOCCUS RESISTANT TO THAT CLASS. The ATS/IDSA rule is explicit: IF THE PATIENT HAS HAD RECENT ANTIBIOTICS, A DIFFERENT CLASS MUST BE USED — and that alone takes him out of the 'healthy outpatient' category.\n\n"
 "NOW TEST THE OPTIONS AGAINST THAT NEW CATEGORY:\n\n"
 "ERYTHROMYCIN — a macrolide, healthy-category therapy; the failure risk here is higher.\n\n"
 "DOXYCYCLINE — same category, same problem.\n\n"
 "WARNING, CO-AMOXICLAV — this is the subtle trap. Co-amoxiclav IS an appropriate beta-lactam for this group, BUT ALONE IT HAS NO ATYPICAL COVER (Mycoplasma, Chlamydia, Legionella). The guideline requires A MACROLIDE OR DOXYCYCLINE ADDED TO IT — and no such combination is offered.\n\n"
 "SO THE ONLY OPTION THAT IS COMPLETE ON ITS OWN IS LEVOFLOXACIN: a RESPIRATORY QUINOLONE covering both the pneumococcus and the atypicals, reserved for exactly this group of patients.\n\n"
 "WARNING, REMEMBER THE EXAM RULE: wherever you see 'COMORBIDITY' or 'RECENT ANTIBIOTICS', the patient has left the healthy category.",
 ["اریترومایسین درمان دسته‌ی سرپاییِ سالم است؛ با سابقه‌ی آنتی‌بیوتیک اخیر خطر شکست بالاتر می‌رود.",
  "داکسی‌سیکلین هم در همان دسته قرار می‌گیرد و برای بیمار با مصرف اخیر آنتی‌بیوتیک انتخاب اول نیست.",
  "کوآموکسی‌کلاو بتالاکتام مناسبی است ولی به‌تنهایی پوشش آتیپیک ندارد و باید با ماکرولید همراه شود.",
  "پاسخ صحیح — لووفلوکساسین کینولون تنفسی است و به‌تنهایی هم پنوموکوک و هم آتیپیک‌ها را می‌پوشاند."],
 ["Erythromycin is healthy-outpatient therapy; with recent antibiotics the failure risk rises.",
  "Doxycycline belongs to the same category and is not first choice after recent antibiotic use.",
  "Co-amoxiclav is an appropriate beta-lactam but alone lacks atypical cover and needs a macrolide added.",
  "Correct — levofloxacin is a respiratory quinolone and alone covers both the pneumococcus and the atypicals."],
 "**«آنتی‌بیوتیک اخیر» = بیمار دیگر سالم نیست** ← بتالاکتام+ماکرولید، یا **کینولون تنفسی تنها**.",
 "'Recent antibiotics' means the patient is no longer healthy: give a beta-lactam plus a macrolide, or a respiratory quinolone alone.",
 [ATS])


# =========================================================== book:90
add("book:90", "case", "hard",
 "CURB-65 برابر **۲** (سن ۶۸ و RR=34) ← **بستری در بخش** با سفتریاکسون + آزیترومایسین.",
 "A CURB-65 of TWO (age 68 and RR 34) means WARD ADMISSION with ceftriaxone plus azithromycin.",
 CURB_FA + RX_FA + [
  "بیایید امتیاز این بیمار را قدم‌به‌قدم بشماریم — این مهارت اصلی سؤال است.",
  "**C (گیجی)؟** صورت سؤال می‌گوید «**هشیار است**» ← **صفر امتیاز**.",
  "**U (اوره)؟** عددی داده نشده ← قابل امتیازدهی نیست ← **صفر**.",
  "⚠️ **R (تعداد تنفس)؟ RR=34 که ≥ ۳۰ است ← یک امتیاز.**",
  "**B (فشار خون)؟** ۱۱۰/۷۰ — نه سیستولیک زیر ۹۰، نه دیاستولیک ≤۶۰ ← **صفر**.",
  "⚠️ **۶۵ (سن)؟ ۶۸ ساله است ← یک امتیاز.**",
  "**مجموع: CURB-65 = ۲.**",
  "**و نمره‌ی ۲ یعنی: بستری در بخش عمومی** (مرگ‌ومیر حدود ۹ درصد).",
  "**حالا رژیم بخش را انتخاب کنید: بتالاکتام + ماکرولید ← سفتریاکسون + آزیترومایسین.**",
  "چرا **دو دارو** و نه یکی؟ چون پوشش باید **هم پنوموکوک و هم آتیپیک‌ها** را در بر بگیرد؛",
  "سفتریاکسون پنوموکوک را می‌گیرد و آزیترومایسین لژیونلا و مایکوپلاسما را.",
  "⚠️ **چرا ICU نه؟** چون معیارهای پنومونی شدید برقرار نیست:",
  "نه شوک، نه نیاز به تهویه‌ی مکانیکی، و نه **سه معیار مینور یا بیشتر**.",
  "و **درمان سرپایی** هم رد می‌شود، چون نمره ۲ است نه ۰ یا ۱.",
  "⚠️ **دقت کنید سن ۶۸ به‌تنهایی بستری نمی‌آورد؛ RR=34 بود که نمره را به ۲ رساند.**",
 ],
 CURB_EN + RX_EN + [
  "Let us count this patient's score step by step — that is the skill being tested.",
  "C (CONFUSION)? The stem says 'HE IS ALERT' — ZERO.",
  "U (UREA)? No value is given, so it cannot be scored — ZERO.",
  "WARNING, R (RESPIRATORY RATE)? RR 34, which is 30 or more — ONE POINT.",
  "B (BLOOD PRESSURE)? 110/70 — neither systolic under 90 nor diastolic 60 or less — ZERO.",
  "WARNING, 65 (AGE)? He is 68 — ONE POINT.",
  "TOTAL: CURB-65 = 2.",
  "AND A SCORE OF 2 MEANS: ADMIT TO A GENERAL WARD (mortality about 9%).",
  "NOW CHOOSE THE WARD REGIMEN: BETA-LACTAM PLUS MACROLIDE — CEFTRIAXONE PLUS AZITHROMYCIN.",
  "Why TWO drugs rather than one? Because cover must include BOTH THE PNEUMOCOCCUS AND THE ATYPICALS;",
  "ceftriaxone takes the pneumococcus and azithromycin takes Legionella and Mycoplasma.",
  "WARNING, WHY NOT ICU? Because the criteria for severe pneumonia are not met:",
  "no shock, no need for mechanical ventilation, and not THREE OR MORE MINOR CRITERIA.",
  "And OUTPATIENT treatment is excluded, because the score is 2 and not 0 or 1.",
  "WARNING, note that AGE 68 ALONE DOES NOT MANDATE ADMISSION; it was the RR of 34 that took the score to 2.",
 ],
 "این سؤال یک مهارت را می‌سنجد: **شمردن درست CURB-65**. پس قدم‌به‌قدم بشماریم.\n\n"
 "**C — گیجی؟** صورت سؤال می‌گوید «**هشیار است**» ← **۰**\n"
 "**U — اوره؟** عددی داده نشده ← قابل امتیازدهی نیست ← **۰**\n"
 "⚠️ **R — تعداد تنفس؟ RR=34 که ≥۳۰ است ← ۱**\n"
 "**B — فشار خون؟** ۱۱۰/۷۰؛ نه سیستولیک زیر ۹۰، نه دیاستولیک ۶۰ یا کمتر ← **۰**\n"
 "⚠️ **۶۵ — سن؟ ۶۸ سال ← ۱**\n\n"
 "**مجموع: CURB-65 = ۲**\n\n"
 "**و نمره‌ی ۲ یعنی بستری در بخش عمومی** (مرگ‌ومیر حدود ۹ درصد).\n\n"
 "**حالا رژیم بخش را انتخاب کنید:** **بتالاکتام + ماکرولید** ← **سفتریاکسون + آزیترومایسین**.\n\n"
 "**چرا دو دارو؟** چون پوشش باید **هم پنوموکوک و هم آتیپیک‌ها** را در بر بگیرد: سفتریاکسون پنوموکوک را می‌گیرد و آزیترومایسین **لژیونلا و مایکوپلاسما** را — که بتالاکتام هرگز نمی‌گیرد.\n\n"
 "**چرا گزینه‌های دیگر رد می‌شوند؟**\n\n"
 "**درمان سرپایی** ← نمره ۲ است نه ۰ یا ۱.\n\n"
 "**ICU** ← معیارهای پنومونی شدید برقرار نیست: نه شوک، نه نیاز به تهویه‌ی مکانیکی، نه سه معیار مینور یا بیشتر. بستری بی‌مورد در ICU هم منابع را هدر می‌دهد و هم بیمار را در معرض عفونت بیمارستانی می‌گذارد.\n\n"
 "⚠️ **و نکته‌ای که باید از این سؤال با خود ببرید:** **سن ۶۸ به‌تنهایی بستری نمی‌آورد** — یک امتیاز است. این **RR=34** بود که نمره را به ۲ رساند و تصمیم را عوض کرد.",
 "This question tests one skill: COUNTING CURB-65 CORRECTLY. So let us count step by step.\n\n"
 "C — CONFUSION? The stem says 'HE IS ALERT' — 0\n"
 "U — UREA? No value given, so it cannot be scored — 0\n"
 "WARNING, R — RESPIRATORY RATE? RR 34, which is 30 or more — 1\n"
 "B — BLOOD PRESSURE? 110/70; neither systolic under 90 nor diastolic 60 or less — 0\n"
 "WARNING, 65 — AGE? 68 years — 1\n\n"
 "TOTAL: CURB-65 = 2\n\n"
 "AND A SCORE OF 2 MEANS ADMISSION TO A GENERAL WARD (mortality about 9%).\n\n"
 "NOW CHOOSE THE WARD REGIMEN: BETA-LACTAM PLUS MACROLIDE — CEFTRIAXONE PLUS AZITHROMYCIN.\n\n"
 "WHY TWO DRUGS? Because cover must include BOTH THE PNEUMOCOCCUS AND THE ATYPICALS: ceftriaxone takes the pneumococcus and azithromycin takes LEGIONELLA AND MYCOPLASMA, which a beta-lactam never covers.\n\n"
 "WHY THE OTHER OPTIONS FAIL:\n\n"
 "OUTPATIENT TREATMENT — the score is 2, not 0 or 1.\n\n"
 "ICU — the criteria for severe pneumonia are not met: no shock, no need for mechanical ventilation, not three or more minor criteria. Needless ICU admission wastes resources and exposes the patient to hospital-acquired infection.\n\n"
 "WARNING, AND THE POINT TO TAKE AWAY: AGE 68 ALONE DOES NOT MANDATE ADMISSION — it is one point. It was the RESPIRATORY RATE OF 34 that took the score to 2 and changed the decision.",
 ["نمره‌ی CURB-65 برابر ۲ است و درمان سرپایی فقط برای نمره‌ی ۰ تا ۱ مناسب است.",
  "معیارهای پنومونی شدید برقرار نیست؛ بستری در ICU با نمره‌ی ۲ توجیهی ندارد.",
  "مروپنم و وانکومایسین پوشش بسیار وسیعی است و بدون عامل خطر MRSA یا پسودوموناس لازم نیست.",
  "پاسخ صحیح — نمره‌ی ۲ یعنی بستری در بخش، و رژیم بخش بتالاکتام به‌همراه ماکرولید است."],
 ["The CURB-65 score is 2, and outpatient treatment is appropriate only for a score of 0 to 1.",
  "The criteria for severe pneumonia are not met; ICU admission is not justified at a score of 2.",
  "Meropenem plus vancomycin is far too broad and is unnecessary without MRSA or Pseudomonas risk factors.",
  "Correct — a score of 2 means ward admission, and the ward regimen is a beta-lactam plus a macrolide."],
 "**CURB-65: ۰–۱ سرپایی، ۲ بخش، ۳–۵ بستری/ICU.** بخش = **سفتریاکسون + آزیترومایسین**.",
 "CURB-65: 0-1 outpatient, 2 ward, 3-5 admission or ICU. The ward regimen is ceftriaxone plus azithromycin.",
 [CURB, ATS])


# =========================================================== book:95
add("book:95", "case", "hard",
 "**pH زیر ۷** در مایع پلور ← آمپیم ← **تعبیه‌ی چست‌تیوب**، نه تعویض آنتی‌بیوتیک.",
 "A PLEURAL FLUID pH BELOW 7 means empyema: INSERT A CHEST TUBE, do not change the antibiotic.",
 RX_FA + [
  "بیمار **۵ روز پس از شروع درمان پنومونی** دوباره تب و لکوسیتوز پیدا کرده،",
  "و در گرافی **تجمع مایع پلور** دارد. در آنالیز مایع: **pH زیر ۷** و **دیپلوکوک گرم‌مثبت**.",
  "⚠️ **این آمپیم است، و آمپیم یک مشکل جراحی است نه یک مشکل دارویی.**",
  "**افیوژن پاراپنومونیک را به سه دسته تقسیم کنید — همین تقسیم‌بندی، درمان را می‌سازد:**",
  "**یک — افیوژن ساده (uncomplicated):** مایع رقیق، **pH بالای ۷٫۲**، گلوکز طبیعی،",
  "کشت منفی ← **فقط آنتی‌بیوتیک؛ خودبه‌خود جذب می‌شود**.",
  "⚠️ **دو — افیوژن پیچیده (complicated): pH زیر ۷٫۲**، **گلوکز زیر ۶۰**، **LDH بالا**",
  "← **نیاز به درناژ دارد**، حتی اگر چرک آشکار نباشد.",
  "**سه — آمپیم: چرک آشکار یا ارگانیسم در اسمیر یا کشت مثبت ← درناژ قطعی است.**",
  "**بیمار ما هر دو معیار دسته‌ی سوم را دارد: pH زیر ۷ و ارگانیسم در اسمیر.**",
  "⚠️ **چرا آنتی‌بیوتیک به‌تنهایی کافی نیست؟** سه دلیل:",
  "**یک — محیط اسیدی و چرکی، نفوذ و اثر بسیاری از آنتی‌بیوتیک‌ها را کم می‌کند.**",
  "**دو — فضای پلور عملاً یک آبسه‌ی بسته است؛ آبسه تخلیه می‌خواهد نه فقط دارو.**",
  "**سه — تأخیر در درناژ به تشکیل سپتا و لوکولاسیون می‌انجامد** و آنگاه چست‌تیوب هم کافی نیست",
  "و بیمار **VATS یا دکورتیکاسیون** لازم پیدا می‌کند.",
  "⚠️ **پس «تعویض آنتی‌بیوتیک» یا «۴۸ ساعت صبر» هر دو، از دست دادن پنجره‌ی درمانی‌اند.**",
  "**تاپ مکرر** هم روش قابل قبولی برای آمپیم نیست؛ درناژ باید **پیوسته** باشد.",
 ],
 RX_EN + [
  "The patient developed fever and leucocytosis again FIVE DAYS AFTER STARTING PNEUMONIA TREATMENT,",
  "and the film shows A PLEURAL COLLECTION. Fluid analysis: pH BELOW 7 and GRAM-POSITIVE DIPLOCOCCI.",
  "WARNING: THIS IS AN EMPYEMA, AND AN EMPYEMA IS A SURGICAL PROBLEM, NOT A DRUG PROBLEM.",
  "DIVIDE PARAPNEUMONIC EFFUSIONS IN THREE — that division IS the treatment:",
  "ONE — UNCOMPLICATED EFFUSION: thin fluid, pH ABOVE 7.2, normal glucose,",
  "negative culture — ANTIBIOTICS ALONE; it resorbs by itself.",
  "WARNING, TWO — COMPLICATED EFFUSION: pH BELOW 7.2, GLUCOSE BELOW 60, HIGH LDH",
  "— IT NEEDS DRAINAGE, even without frank pus.",
  "THREE — EMPYEMA: frank pus, or organisms on smear, or a positive culture — DRAINAGE IS MANDATORY.",
  "OUR PATIENT MEETS BOTH CRITERIA OF THE THIRD GROUP: pH below 7 and organisms on the smear.",
  "WARNING, WHY ARE ANTIBIOTICS ALONE INSUFFICIENT? Three reasons:",
  "ONE — THE ACID, PURULENT ENVIRONMENT REDUCES THE PENETRATION AND ACTIVITY OF MANY ANTIBIOTICS.",
  "TWO — THE PLEURAL SPACE IS EFFECTIVELY A CLOSED ABSCESS; an abscess needs drainage, not only drugs.",
  "THREE — DELAY LEADS TO SEPTATION AND LOCULATION, after which even a chest tube is not enough",
  "and the patient needs VATS OR DECORTICATION.",
  "WARNING, SO 'CHANGE THE ANTIBIOTIC' OR 'WAIT 48 HOURS' BOTH MEAN LOSING THE THERAPEUTIC WINDOW.",
  "REPEATED TAPS are likewise not acceptable for an empyema; drainage must be CONTINUOUS.",
 ],
 "بیمار **۵ روز پس از شروع درمان پنومونی** دوباره تب و لکوسیتوز پیدا کرده و در گرافی **تجمع مایع پلور** دارد. در آنالیز مایع: **pH زیر ۷** و **دیپلوکوک گرم‌مثبت در اسمیر**.\n\n"
 "⚠️ **این آمپیم است — و آمپیم یک مشکل جراحی است، نه یک مشکل دارویی.**\n\n"
 "**افیوژن پاراپنومونیک را همیشه به سه دسته تقسیم کنید، چون همین تقسیم‌بندی درمان را تعیین می‌کند:**\n\n"
 "**۱. افیوژن ساده** ← مایع رقیق، **pH بالای ۷٫۲**، گلوکز طبیعی، کشت منفی ← **فقط آنتی‌بیوتیک**؛ خودبه‌خود جذب می‌شود.\n\n"
 "⚠️ **۲. افیوژن پیچیده** ← **pH زیر ۷٫۲**، **گلوکز زیر ۶۰**، **LDH بالا** ← **نیاز به درناژ دارد**، حتی اگر چرک آشکاری نباشد.\n\n"
 "**۳. آمپیم** ← چرک آشکار، یا **ارگانیسم در اسمیر**، یا کشت مثبت ← **درناژ قطعی است**.\n\n"
 "**بیمار ما هر دو معیار دسته‌ی سوم را دارد.**\n\n"
 "⚠️ **چرا آنتی‌بیوتیک به‌تنهایی کافی نیست؟ سه دلیل که باید بدانید:**\n\n"
 "**۱.** محیط **اسیدی و چرکی**، نفوذ و اثربخشی بسیاری از آنتی‌بیوتیک‌ها را کاهش می‌دهد.\n\n"
 "**۲.** فضای پلور در این حالت عملاً یک **آبسه‌ی بسته** است — و اصل کهنه‌ی جراحی می‌گوید آبسه **تخلیه** می‌خواهد.\n\n"
 "**۳.** تأخیر در درناژ به **تشکیل سپتا و لوکولاسیون** می‌انجامد؛ آنگاه حتی چست‌تیوب هم کافی نیست و بیمار به **VATS یا دکورتیکاسیون** نیاز پیدا می‌کند.\n\n"
 "**پس چرا گزینه‌های دیگر رد می‌شوند؟** «تعویض آنتی‌بیوتیک» و «۴۸ ساعت ارزیابی مجدد» هر دو یعنی **از دست دادن پنجره‌ی درمانی**، و «تاپ مکرر» هم روش پذیرفته‌شده‌ای برای آمپیم نیست، چون درناژ باید **پیوسته** باشد.",
 "Five days after starting treatment for pneumonia the patient again has fever and leucocytosis, and the film shows A PLEURAL COLLECTION. Fluid analysis: pH BELOW 7 and GRAM-POSITIVE DIPLOCOCCI on smear.\n\n"
 "WARNING: THIS IS AN EMPYEMA — AND AN EMPYEMA IS A SURGICAL PROBLEM, NOT A DRUG PROBLEM.\n\n"
 "ALWAYS DIVIDE PARAPNEUMONIC EFFUSIONS IN THREE, because that division determines the treatment:\n\n"
 "1. UNCOMPLICATED EFFUSION — thin fluid, pH ABOVE 7.2, normal glucose, negative culture — ANTIBIOTICS ALONE; it resorbs spontaneously.\n\n"
 "WARNING, 2. COMPLICATED EFFUSION — pH BELOW 7.2, GLUCOSE BELOW 60, HIGH LDH — IT NEEDS DRAINAGE, even without frank pus.\n\n"
 "3. EMPYEMA — frank pus, ORGANISMS ON SMEAR, or a positive culture — DRAINAGE IS MANDATORY.\n\n"
 "OUR PATIENT MEETS BOTH CRITERIA OF THE THIRD GROUP.\n\n"
 "WARNING, WHY ARE ANTIBIOTICS ALONE INSUFFICIENT? Three reasons worth knowing:\n\n"
 "1. The ACID, PURULENT environment reduces the penetration and effectiveness of many antibiotics.\n\n"
 "2. The pleural space here is effectively a CLOSED ABSCESS — and the old surgical principle says an abscess must be DRAINED.\n\n"
 "3. Delay leads to SEPTATION AND LOCULATION; then even a chest tube is insufficient and the patient needs VATS OR DECORTICATION.\n\n"
 "SO WHY DO THE OTHER OPTIONS FAIL? 'Change the antibiotic' and 'reassess in 48 hours' both mean LOSING THE THERAPEUTIC WINDOW, and 'repeated taps' is not an accepted method for empyema, because drainage must be CONTINUOUS.",
 ["تعویض آنتی‌بیوتیک مشکل را حل نمی‌کند؛ فضای چرکی پلور یک آبسه‌ی بسته است و تخلیه می‌خواهد.",
  "پاسخ صحیح — pH زیر ۷ به‌همراه ارگانیسم در اسمیر یعنی آمپیم، و آمپیم درناژ پیوسته لازم دارد.",
  "تاپ مکرر برای آمپیم روش پذیرفته‌شده‌ای نیست؛ درناژ باید پیوسته باشد نه متناوب.",
  "۴۸ ساعت انتظار یعنی از دست دادن پنجره‌ی درمانی و خطر لوکولاسیون و نیاز به جراحی بازتر."],
 ["Changing the antibiotic does not solve it; a purulent pleural space is a closed abscess and needs drainage.",
  "Correct — a pH below 7 with organisms on smear means empyema, and empyema requires continuous drainage.",
  "Repeated taps are not an accepted method for empyema; drainage must be continuous, not intermittent.",
  "Waiting 48 hours means losing the therapeutic window and risking loculation and more extensive surgery."],
 "مایع پلور: **pH<7.2 یا گلوکز<60 یا ارگانیسم = درناژ.** آبسه با دارو تنها درمان نمی‌شود.",
 "Pleural fluid: pH below 7.2, glucose below 60, or organisms present means drainage. An abscess is not cured by drugs alone.",
 [H126])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book22.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 22 lessons:', len(L))
