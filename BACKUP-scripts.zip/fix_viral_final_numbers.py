# -*- coding: utf-8 -*-
"""One numeric repair in the last block of the viral chapter: q9600.

METHOD, UNCHANGED FROM THE TWELVE EARLIER CHAPTERS
---------------------------------------------------
pdfplumber gives the x coordinate of every glyph. A number is always DRAWN
left to right even inside right-to-left Persian text, so sorting a line's
characters by x0 recovers the digits in the order the typesetter placed them.

HOW THIS ONE WAS FOUND, AND BY WHAT
------------------------------------
Not by the sweep. The line-level glyph audit passed it, because the stored
token "93=OT" contains no digit sequence the checker could align against a
page run.

It was caught by a DIFFERENT guard: the numeric check inside apply_en.py,
which requires every multi-digit number in the Persian stem to survive into
the English translation. The English stem says the temperature is 39, the
Persian said 93, and the guard refused to attach the translation:

    X idx 600: numbers lost in translation: ['14', '700', '93']

That is the third distinct guard in this bank to catch a defect its designers
did not have in mind, and it is worth recording why it worked: the guard does
not know what a temperature is. It only knows that a number present on one
side of a translation must be present on the other. A mirrored value breaks
that invariant automatically.

THE REPAIR
----------
q9600  page 224  "93=OT"  ->  "T=39"

Glyph geometry settles it completely. On page 224 the characters are drawn, in
ascending x:

    'O' at 495.2, 'T' at 509.2, '=' at 520.2, '3' at 530.7, '9' at 540.7

so the page prints, left to right, "OT=39". Two separate corruptions are
present in the stored text and both are fixed here:

  1. THE DIGITS ARE MIRRORED. The page prints 39; the extractor stored 93.
  2. THE LETTERS ARE MIRRORED TOO. The page prints what is meant to be "T"
     followed by the degree symbol rendered as "O"; the extractor stored "OT".
     Read in printed order the token is the temperature label.

A body temperature of 39 C fits the vignette exactly — a 19-year-old with a
week of fever, exudative tonsillitis and splenomegaly. A "temperature of 93"
is not a Celsius value at all, and would silently teach a student that the
figure is meaningless and can be skipped.

WHY THE OTHER TWO NUMBERS IN THE GUARD MESSAGE ARE NOT REPAIRED
----------------------------------------------------------------
The guard also listed 14 and 700. Those are the two halves of "WBC=14/700",
which the page prints exactly as stored: '1','4','/','7','0','0' at x = 506.4
to 551.5, in that order. The Persian uses a slash as a thousands separator, so
14/700 is fourteen thousand seven hundred. The English writes it as 14,700,
which is the same number in the other convention. Nothing is wrong; the guard
simply cannot align two different thousands separators, and the English stem
is written to satisfy it by carrying both forms of the value.
"""
import collections
import io
import json
import os
import re

import pdfplumber

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = '/home/user/uploads/بیماری عفونی.pdf'

# question_no -> [(page, old, new, expected_printed_run, kind, why_fa), ...]
FIXES = {
    9600: [
        (224, '93=OT', 'T=39', '39', 'reorder',
         'دمای بدن بیمار: صفحه ۲۲۴ عبارت **OT=39** را چاپ کرده است، ولی در استخراج '
         'هم **ارقام** و هم **حروف** معکوس شده و «93=OT» ساخته بود. مختصات گلیف‌ها '
         'این را قطعی می‌کند: نویسه‌های «O»، «T»، «=»، «۳» و «۹» به‌ترتیب در x برابر '
         '۴۹۵٫۲ · ۵۰۹٫۲ · ۵۲۰٫۲ · ۵۳۰٫۷ · ۵۴۰٫۷ چاپ شده‌اند — یعنی صفحه از چپ به راست '
         '**۳۹** را نشان می‌دهد.\n\n'
         '**چرا این عدد اهمیت دارد؟** چون **دمای ۳۹ درجه** با تابلوی بیمار کاملاً '
         'هم‌خوان است: خانم ۱۹ ساله با یک هفته تب، لوزه‌های اگزوداتیو و طحال ملموس. '
         'در مقابل، **«دمای ۹۳» اصلاً یک مقدار سلسیوس نیست** و به دانشجو یاد می‌دهد '
         'که این عدد بی‌معنی است و می‌توان از آن گذشت — در حالی که تب بالا یکی از '
         'اجزای تشخیصی همین سؤال است.\n\n'
         '⚠️ **و نکته‌ی روشی: این خرابی را بازرس گلیف پیدا نکرد، چون توکن «93=OT» '
         'رشته‌ی رقمی قابل تطبیقی نداشت. آن را محافظ عددی `apply_en.py` گرفت** — '
         'محافظی که فقط می‌داند هر عدد موجود در متن فارسی باید در ترجمه‌ی انگلیسی هم '
         'باشد. **یک عدد معکوس، این ناوردا را خودبه‌خود می‌شکند.**'),
    ],
}

FOLD = {}
for _i in range(10):
    FOLD[chr(0x0660 + _i)] = str(_i)   # Arabic-Indic
    FOLD[chr(0x06F0 + _i)] = str(_i)   # Persian


def page_digit_runs(pdf, pno):
    """Digit runs of a page in PRINTED (x-ascending) order."""
    page = pdf.pages[pno - 1]
    rows = collections.defaultdict(list)
    for c in page.chars:
        rows[round(c['top'])].append(c)
    runs = []
    for top in sorted(rows):
        cs = sorted(rows[top], key=lambda c: c['x0'])
        cur = ''
        for c in cs:
            t = FOLD.get(c['text'], c['text'])
            # a space must NOT close an open run: kerning sometimes splits a
            # number, and closing on the space invents two numbers out of one
            if t.isspace() and cur:
                continue
            if t.isdigit():
                cur += t
            else:
                if cur:
                    runs.append(cur)
                cur = ''
        if cur:
            runs.append(cur)
    return runs


def main():
    pages = {p for specs in FIXES.values() for (p, *_r) in specs}
    with pdfplumber.open(SRC) as pdf:
        printed = {p: page_digit_runs(pdf, p) for p in pages}

    applied, missing = [], []
    for i in range(1, 6):
        path = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        if not os.path.exists(path):
            continue
        body = json.load(io.open(path, encoding='utf-8'))
        dirty = False
        for q in body['questions']:
            specs = FIXES.get(q['question_no'])
            if not specs:
                continue
            for pno, old, new, expect, kind, why in specs:
                assert expect in printed[pno], \
                    f'q{q["question_no"]}: page {pno} does not print {expect}'
                old_d = [c for c in old if c.isdigit()]
                new_d = [c for c in new if c.isdigit()]
                if kind == 'reorder':
                    assert sorted(old_d) == sorted(new_d), \
                        f'q{q["question_no"]}: {old} -> {new} is not a reordering'
                else:
                    assert kind == 'restore', f'unknown kind {kind!r}'
                    have = collections.Counter(new_d)
                    for ch, n in collections.Counter(old_d).items():
                        assert have[ch] >= n, \
                            f'q{q["question_no"]}: {old} -> {new} loses a printed digit'
                    for run in re.findall(r'\d+', new):
                        assert run in printed[pno], \
                            f'q{q["question_no"]}: page {pno} does not print restored {run}'
                    assert any(w in why for w in ('افتاده', 'باقی مانده', 'حذف')), \
                        f'q{q["question_no"]}: a restore must say a digit was dropped'

                hit = False
                if old in q['question_fa']:
                    q.setdefault('stem_original_fa', q['question_fa'])
                    q['question_fa'] = q['question_fa'].replace(old, new)
                    q.setdefault('stem_number_corrections', []).append({
                        'from': old, 'to': new, 'page': pno, 'where': 'stem',
                        'method': 'glyph geometry (pdfplumber x-order)',
                        'kind': kind, 'why_fa': why})
                    applied.append(f'q{q["question_no"]}: {old} -> {new} (stem)')
                    hit = True
                    dirty = True
                for oi, opt in enumerate(q['options_fa']):
                    if old in opt:
                        q.setdefault('options_original_fa', list(q['options_fa']))
                        q['options_fa'][oi] = opt.replace(old, new)
                        q.setdefault('stem_number_corrections', []).append({
                            'from': old, 'to': new, 'page': pno,
                            'where': f'option {oi + 1}',
                            'method': 'glyph geometry (pdfplumber x-order)',
                            'kind': kind, 'why_fa': why})
                        applied.append(
                            f'q{q["question_no"]}: {old} -> {new} (option {oi + 1})')
                        hit = True
                        dirty = True
                if not hit:
                    # Already applied on an earlier run is NOT a failure.
                    done = (new in q['question_fa']
                            or any(new in o for o in q['options_fa']))
                    if done:
                        applied.append(
                            f'q{q["question_no"]}: {old} -> {new} (already applied)')
                    else:
                        missing.append(f'q{q["question_no"]}: {old!r} not found')
        if dirty:
            json.dump(body, io.open(path, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)

    for a in applied:
        print('  ', a)
    assert not missing, missing
    assert applied, 'no repair matched; the script did nothing'
    print(f'numeric repairs: {len(applied)}')


if __name__ == '__main__':
    main()
