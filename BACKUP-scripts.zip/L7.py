# -*- coding: utf-8 -*-
"""Infectious micro-lessons, batch 7 — Khordad-1400 (items 122-130).
Reference: Harrison's Principles of Internal Medicine, 21st ed."""
import json, io
L = {}

L["1400-03:122"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "در STI شریک جنسی همیشه و تجربی درمان می‌شود، حتی بی‌علامت. وگرنه چرخه‌ی پینگ‌پنگ ادامه می‌یابد.",
  "lead_en": "In STIs the partner is always treated empirically, even if asymptomatic; otherwise ping-pong reinfection continues.",
  "points_fa": [
   "سرویسیت موکوپورولنت با ترشح چرکی از سرویکس و خون‌ریزی تماسی هنگام سواب شناخته می‌شود.",
   "خون‌ریزی تماسی نشانه‌ی التهاب و شکنندگی مخاط اندوسرویکس است.",
   "دو عامل اصلی آن نایسریا گونوره و کلامیدیا تراکوماتیس هستند.",
   "درمان همیشه هر دو را با هم پوشش می‌دهد چون هم‌عفونتی شایع است.",
   "سفتریاکسون تک‌دوز عضلانی برای گونوره و داکسی‌سایکلین هفت روزه برای کلامیدیا.",
   "در بارداری به‌جای داکسی‌سایکلین از آزیترومایسین استفاده می‌شود.",
   "شریک جنسی باید همزمان و به‌صورت تجربی درمان شود، حتی بدون هیچ علامتی.",
   "در مردان، عفونت کلامیدیایی در حدود نیمی از موارد کاملاً بی‌علامت است.",
   "پدیده‌ی پینگ‌پنگ: اگر فقط یکی درمان شود، بلافاصله دوباره مبتلا می‌شود.",
   "منتظر ماندن برای نتیجه‌ی اسمیر هم پذیرفتنی نیست چون تأخیر یعنی ادامه‌ی انتقال.",
   "درمان تجربی شریک ارزان، بی‌خطر و قطعی است.",
   "عوارض درمان‌نشدن در زن: بیماری التهابی لگن، ناباروری لوله‌ای و حاملگی نابه‌جا.",
   "در هر STI باید غربالگری HIV، سیفلیس و هپاتیت B هم پیشنهاد شود.",
   "پرهیز از تماس جنسی تا هفت روز پس از درمان هر دو نفر توصیه می‌شود."
  ],
  "points_en": [
   "Mucopurulent cervicitis is recognised by purulent cervical discharge and contact bleeding on swabbing.",
   "Contact bleeding indicates an inflamed, friable endocervical mucosa.",
   "The two principal organisms are Neisseria gonorrhoeae and Chlamydia trachomatis.",
   "Treatment always covers both because co-infection is common.",
   "A single intramuscular dose of ceftriaxone for gonorrhoea and seven days of doxycycline for chlamydia.",
   "In pregnancy azithromycin replaces doxycycline.",
   "The sexual partner must be treated at the same time and empirically, even without symptoms.",
   "In men, chlamydial infection is entirely asymptomatic in roughly half of cases.",
   "The ping-pong phenomenon: if only one partner is treated, reinfection follows immediately.",
   "Waiting for a smear result is not acceptable either, because delay means ongoing transmission.",
   "Empirical partner treatment is cheap, safe and definitive.",
   "Untreated consequences in women: pelvic inflammatory disease, tubal infertility and ectopic pregnancy.",
   "Every STI encounter should include an offer of HIV, syphilis and hepatitis B screening.",
   "Abstinence is advised for seven days after both partners have been treated."
  ]
 },
 "explanation_fa": "تابلو سرویسیت موکوپورولنت است: ترشح چرکی از سرویکس به‌علاوه‌ی خون‌ریزی تماسی هنگام سواب، که نشانه‌ی التهاب و شکنندگی مخاط سرویکس است. دو عامل اصلی آن نایسریا گونوره و کلامیدیا تراکوماتیس هستند و درمان بیمار هم دقیقاً همین را پوشش داده. اما سؤال درباره‌ی همسر است و اینجا اصل کلیدی طب عفونی مطرح می‌شود: در عفونت‌های منتقله از راه جنسی، شریک جنسی باید همزمان و به‌صورت تجربی درمان شود، حتی اگر کاملاً بی‌علامت باشد. دلیلش دو چیز است. اول اینکه در مردان، عفونت کلامیدیایی در حدود نیمی از موارد بدون هیچ علامتی است. دوم پدیده‌ی پینگ‌پنگ: اگر فقط یکی از دو نفر درمان شود، بیمار درمان‌شده بلافاصله از شریک درمان‌نشده دوباره مبتلا می‌شود.",
 "explanation_en": "The picture is mucopurulent cervicitis: purulent cervical discharge plus contact bleeding on swabbing, indicating an inflamed and friable cervical mucosa. The two main organisms are Neisseria gonorrhoeae and Chlamydia trachomatis, and the patient's treatment covers exactly those. But the question is about the partner, and here a key principle of infectious disease applies: in sexually transmitted infections the partner must be treated at the same time and empirically, even if entirely asymptomatic. There are two reasons. First, chlamydial infection in men is completely asymptomatic in about half of cases. Second, the ping-pong phenomenon: if only one of the two is treated, the treated patient is promptly reinfected by the untreated partner.",
 "why_fa": [
  "منتظر بروز علائم ماندن یعنی نادیده گرفتن اکثریت موارد، چون کلامیدیا در مردان اغلب بی‌علامت است.",
  "ارسال سواب و انتظار برای نتیجه، درمان را به تأخیر می‌اندازد و انتقال در این فاصله ادامه می‌یابد.",
  "پاسخ صحیح — شریک جنسی همیشه و به‌صورت تجربی درمان می‌شود، حتی در غیاب کامل علائم.",
  "درمان اختصاصی بر پایه‌ی اسمیر، همان تأخیر را ایجاد می‌کند و چرخه‌ی پینگ‌پنگ را نمی‌بندد."
 ],
 "why_en": [
  "Waiting for symptoms means missing most cases, since chlamydia in men is usually asymptomatic.",
  "Sending a swab and awaiting the result delays treatment while transmission continues.",
  "Correct — the sexual partner is always treated empirically, even with no symptoms at all.",
  "Targeting therapy to the smear introduces the same delay and fails to break the ping-pong cycle."
 ],
 "golden_fa": "STI = درمان همزمان و تجربی شریک، بی‌توجه به علائم. کلامیدیا در مرد نیمی از موارد بی‌علامت.",
 "golden_en": "STI means simultaneous empirical partner treatment regardless of symptoms. Chlamydia is asymptomatic in half of men.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 135: Sexually Transmitted Infections"]
}

L["1400-03:123"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "دریچه‌ی مصنوعی = پروفیلاکسی لازم. آلرژی پنی‌سیلین ← کلیندامایسین ۶۰۰ تک‌دوز.",
  "lead_en": "A prosthetic valve needs prophylaxis. With penicillin allergy, clindamycin 600 mg as a single dose.",
  "points_fa": [
   "از سال ۲۰۰۷ اندیکاسیون‌های پروفیلاکسی اندوکاردیت به‌شدت محدود شد.",
   "فقط چهار گروه پرخطر باقی ماندند و پرولاپس میترال از فهرست حذف شد.",
   "گروه اول و مهم‌ترین: دریچه‌ی مصنوعی یا مواد پروتزی به‌کاررفته در ترمیم دریچه.",
   "گروه دوم: سابقه‌ی اندوکاردیت عفونی قبلی.",
   "گروه سوم: بیماری مادرزادی قلبی سیانوتیک ترمیم‌نشده یا ناقص‌ترمیم‌شده.",
   "گروه چهارم: گیرنده‌ی پیوند قلب که والوپاتی پیدا کرده است.",
   "پروسیجرهای مشمول: دستکاری لثه یا ناحیه‌ی پری‌اپیکال دندان و سوراخ کردن مخاط دهان.",
   "ارتودنسی با دستکاری لثه در همین دسته قرار می‌گیرد.",
   "رژیم استاندارد: آموکسی‌سیلین دو گرم تک‌دوز، سی تا شصت دقیقه پیش از پروسیجر.",
   "در آلرژی به پنی‌سیلین: کلیندامایسین ششصد میلی‌گرم تک‌دوز.",
   "جایگزین‌های دیگر: آزیترومایسین یا کلاریترومایسین پانصد میلی‌گرم.",
   "سفالکسین فقط در آلرژی غیرآنافیلاکتیک قابل استفاده است.",
   "کلیندامایسین پوشش خوبی روی استرپتوکوک‌های ویریدانس دهانی دارد.",
   "پروفیلاکسی همیشه تک‌دوز است و هرگز چندروزه تجویز نمی‌شود.",
   "راهنماهای جدیدتر به‌دلیل خطر کولیت کلستریدیوم دیفیسیل، ماکرولید را ترجیح می‌دهند."
  ],
  "points_en": [
   "Since 2007 the indications for endocarditis prophylaxis have been sharply narrowed.",
   "Only four high-risk groups remain, and mitral valve prolapse was removed from the list.",
   "The first and most important: a prosthetic valve or prosthetic material used in valve repair.",
   "Second: previous infective endocarditis.",
   "Third: unrepaired or incompletely repaired cyanotic congenital heart disease.",
   "Fourth: a heart transplant recipient who has developed valvulopathy.",
   "Covered procedures involve manipulating the gingiva or periapical region, or perforating oral mucosa.",
   "Orthodontic work involving gingival manipulation falls into this category.",
   "Standard regimen: amoxicillin 2 g as a single dose, 30 to 60 minutes before the procedure.",
   "For penicillin allergy: clindamycin 600 mg as a single dose.",
   "Other alternatives: azithromycin or clarithromycin 500 mg.",
   "Cephalexin may be used only for non-anaphylactic allergy.",
   "Clindamycin provides good cover against oral viridans streptococci.",
   "Prophylaxis is always a single dose and is never prescribed for several days.",
   "Newer guidelines prefer a macrolide because of Clostridioides difficile colitis risk."
  ]
 },
 "explanation_fa": "این سؤال دو مرحله دارد و باید هر دو را درست رد کرد. مرحله‌ی اول: آیا اصلاً پروفیلاکسی لازم است؟ از سال ۲۰۰۷ فهرست اندیکاسیون‌ها به‌شدت محدود شد و فقط چهار گروه باقی ماندند، که اولین و مهم‌ترین‌شان دریچه‌ی مصنوعی قلب است. این بیمار دقیقاً در همان گروه است، پس گزینه‌ی نیاز ندارد غلط است. مرحله‌ی دوم: کدام دارو؟ رژیم استاندارد آموکسی‌سیلین دو گرم تک‌دوز است، اما صورت سؤال صریحاً می‌گوید بیمار به پنی‌سیلین حساسیت دارد. در آلرژی به پنی‌سیلین، جایگزین‌های پذیرفته‌شده کلیندامایسین ششصد میلی‌گرم، آزیترومایسین یا کلاریترومایسین پانصد میلی‌گرم هستند. بین دو گزینه‌ی باقی‌مانده، کلیندامایسین به‌طور سنتی جایگزین اصلی محسوب می‌شود، چون پوشش خوبی روی استرپتوکوک‌های ویریدانس دهانی دارد.",
 "explanation_en": "This question has two stages and both must be cleared. First: is prophylaxis needed at all? Since 2007 the indication list has been sharply narrowed to four groups, the first and most important being a prosthetic heart valve. This patient falls squarely into that group, so the no-prophylaxis option is wrong. Second: which drug? The standard regimen is amoxicillin 2 g as a single dose, but the stem states she is allergic to penicillin. For penicillin allergy the accepted alternatives are clindamycin 600 mg, or azithromycin or clarithromycin 500 mg. Between the two remaining options, clindamycin is traditionally the principal alternative because it covers oral viridans streptococci well.",
 "why_fa": [
  "آموکسی‌سیلین رژیم استاندارد است ولی بیمار به پنی‌سیلین حساسیت دارد، پس ممنوع است.",
  "پاسخ صحیح — کلیندامایسین ششصد میلی‌گرم تک‌دوز، جایگزین استاندارد در آلرژی به پنی‌سیلین است.",
  "آزیترومایسین جایگزین قابل قبولی است ولی کلیندامایسین انتخاب سنتی و اصلی این سناریو محسوب می‌شود.",
  "بیمار دریچه‌ی مصنوعی دارد و دقیقاً در گروه پرخطری است که پروفیلاکسی برایش الزامی است."
 ],
 "why_en": [
  "Amoxicillin is the standard regimen but the patient is penicillin-allergic, so it is contraindicated.",
  "Correct — clindamycin 600 mg as a single dose is the standard alternative in penicillin allergy.",
  "Azithromycin is an acceptable alternative, but clindamycin is the traditional principal choice here.",
  "She has a prosthetic valve and is precisely in the high-risk group for whom prophylaxis is mandatory."
 ],
 "golden_fa": "۴ گروه پرخطر: دریچه مصنوعی، اندوکاردیت قبلی، CHD سیانوتیک، پیوند قلب با والوپاتی. آلرژی ← کلیندامایسین ۶۰۰.",
 "golden_en": "Four high-risk groups: prosthetic valve, prior endocarditis, cyanotic CHD, transplant valvulopathy. Allergy: clindamycin 600 mg.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 124: Infective Endocarditis"]
}

L["1400-03:124"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "آبکی + بدون خون + بدون تب + بدون لکوسیت = غیرالتهابی. شیگلا در این دسته نمی‌گنجد.",
  "lead_en": "Watery, no blood, no fever, no leukocytes means non-inflammatory. Shigella does not belong in that group.",
  "points_fa": [
   "اسهال‌ها را اول به دو دسته‌ی التهابی و غیرالتهابی تقسیم کنید؛ این کار اکثر سؤالات را حل می‌کند.",
   "اسهال غیرالتهابی: آبکی و پرحجم، بدون خون، بدون تب و بدون لکوسیت در مدفوع.",
   "مکانیسم آن ترشحی یا توکسینی است و مخاط روده دست‌نخورده می‌ماند.",
   "اسهال التهابی: کم‌حجم و مکرر، با خون و موکوس، همراه تب و تنسموس و لکوسیت فراوان.",
   "مکانیسم آن تهاجم مستقیم به اپیتلیوم کولون است.",
   "ETEC شایع‌ترین علت اسهال مسافران است و با توکسین LT و ST عمل می‌کند.",
   "ویبریو کلرا نمونه‌ی کلاسیک اسهال ترشحی است و مدفوع آب‌برنجی می‌دهد.",
   "استافیلوکوک اورئوس مسمومیت غذایی با توکسین از پیش ساخته‌شده است.",
   "شروع استاف اورئوس بسیار سریع است: یک تا شش ساعت، با استفراغ غالب.",
   "شیگلا برعکس، به اپیتلیوم کولون تهاجم می‌کند و دیسانتری می‌سازد.",
   "دوز عفونی شیگلا بسیار پایین است و انتقال فرد به فرد دارد.",
   "در اسهال غیرالتهابی معمولاً درمان حمایتی و مایع‌درمانی کافی است.",
   "در اسهال التهابی با تب، آنتی‌بیوتیک اندیکاسیون پیدا می‌کند.",
   "استثنای مهم: در شک به EHEC آنتی‌بیوتیک ممنوع است چون خطر HUS را بالا می‌برد."
  ],
  "points_en": [
   "Divide diarrhoea first into inflammatory and non-inflammatory; that alone solves most questions.",
   "Non-inflammatory: watery and high-volume, without blood, fever or faecal leukocytes.",
   "The mechanism is secretory or toxin-mediated and the mucosa stays intact.",
   "Inflammatory: small-volume and frequent, with blood and mucus, fever, tenesmus and many leukocytes.",
   "The mechanism is direct invasion of the colonic epithelium.",
   "ETEC is the commonest cause of traveller's diarrhoea, acting through LT and ST toxins.",
   "Vibrio cholerae is the classic secretory diarrhoea, producing rice-water stool.",
   "Staphylococcus aureus causes food poisoning through a pre-formed toxin.",
   "Its onset is very rapid, one to six hours, with vomiting predominating.",
   "Shigella by contrast invades the colonic epithelium and produces dysentery.",
   "Shigella has a very low infectious dose and spreads person to person.",
   "Non-inflammatory diarrhoea usually needs only supportive care and fluids.",
   "Inflammatory diarrhoea with fever is where antibiotics become indicated.",
   "Important exception: antibiotics are contraindicated in suspected EHEC because they raise HUS risk."
  ]
 },
 "explanation_fa": "کل سؤال روی یک تقسیم‌بندی می‌چرخد: اسهال التهابی در برابر غیرالتهابی. سه یافته‌ی صورت سؤال هر سه به یک سمت اشاره می‌کنند: اسهال آبکی و حجیم، بدون خون، بدون تب، و آزمایش ساده‌ی مدفوع نرمال یعنی بدون لکوسیت. این یعنی مخاط روده دست‌نخورده مانده و مکانیسم بیماری ترشحی یا توکسینی است، نه تهاجمی. ETEC شایع‌ترین علت اسهال مسافران است و بدون حمله به مخاط عمل می‌کند. ویبریو کلرا نمونه‌ی کلاسیک همین مکانیسم است. استافیلوکوک اورئوس مسمومیت غذایی توکسینی است که ظرف چند ساعت بروز می‌کند. اما شیگلا کاملاً در دسته‌ی مقابل است: باکتری به اپیتلیوم کولون تهاجم می‌کند و تابلوی دیسانتری می‌سازد با خون، تنسموس، تب و لکوسیت فراوان.",
 "explanation_en": "The whole question turns on one classification: inflammatory versus non-inflammatory diarrhoea. Three findings in the stem all point the same way: watery high-volume stool, no blood, no fever, and a normal routine stool examination meaning no leukocytes. The mucosa is intact and the mechanism is secretory or toxin-mediated rather than invasive. ETEC is the commonest cause of traveller's diarrhoea and works without attacking the mucosa. Vibrio cholerae is the classic example of the same mechanism. Staphylococcus aureus is a toxin-mediated food poisoning appearing within hours. Shigella, however, is firmly in the opposite category: it invades the colonic epithelium and produces dysentery with blood, tenesmus, fever and abundant leukocytes.",
 "why_fa": [
  "پاسخ صحیح — شیگلا اسهال التهابی و خونی با تب و لکوسیت فراوان می‌دهد، نه اسهال آبکی بدون تب.",
  "ETEC شایع‌ترین علت اسهال مسافران است و دقیقاً اسهال آبکی غیرالتهابی ایجاد می‌کند.",
  "استافیلوکوک اورئوس مسمومیت غذایی توکسینی با شروع سریع و اسهال آبکی بدون تب است.",
  "ویبریو کلرا نمونه‌ی کلاسیک اسهال ترشحی پرحجم بدون خون و بدون لکوسیت محسوب می‌شود."
 ],
 "why_en": [
  "Correct — Shigella causes inflammatory bloody diarrhoea with fever and many leukocytes, not afebrile watery stool.",
  "ETEC is the commonest cause of traveller's diarrhoea and produces exactly this non-inflammatory watery picture.",
  "Staphylococcus aureus causes rapid-onset toxin-mediated food poisoning with watery, afebrile diarrhoea.",
  "Vibrio cholerae is the classic high-volume secretory diarrhoea without blood or leukocytes."
 ],
 "golden_fa": "غیرالتهابی: ETEC، کلرا، استاف (توکسین). التهابی: شیگلا، سالمونلا، کمپیلوباکتر (تهاجم).",
 "golden_en": "Non-inflammatory: ETEC, cholera, staph toxin. Inflammatory: Shigella, Salmonella, Campylobacter (invasion).",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 128: Acute Infectious Diarrhoea"]
}

L["1400-03:125"] = {
 "style": "case", "difficulty": "easy",
 "micro": {
  "lead_fa": "زخم آلوده + ایمنی کامل + فقط ۳ سال از آخرین دوز = هیچ پروفیلاکسی ایمونولوژیک لازم نیست.",
  "lead_en": "Dirty wound plus full immunity plus only three years since the last dose means no immunological prophylaxis.",
  "points_fa": [
   "پیشگیری کزاز دو متغیر دارد: تعداد دوزهای قبلی و تمیز یا آلوده بودن زخم.",
   "زخم عمیق و آلوده به خاک قطعاً در دسته‌ی آلوده قرار می‌گیرد.",
   "در فرد با سه دوز واکسن یا بیشتر، زخم آلوده تا پنج سال یادآور نمی‌خواهد.",
   "در همان فرد، زخم تمیز تا ده سال یادآور نمی‌خواهد.",
   "این بیمار سه سال از آخرین دوز فاصله دارد، یعنی زیر هر دو آستانه.",
   "ایمونوگلوبولین کزاز فقط برای زخم آلوده در فرد با کمتر از سه دوز یا سابقه‌ی نامعلوم است.",
   "این بیمار سری کامل دارد، پس ایمونوگلوبولین اضافه و بی‌مورد است.",
   "«اقدام خاصی لازم نیست» فقط به پروفیلاکسی ایمونولوژیک اشاره دارد، نه به مراقبت از زخم.",
   "شست‌وشوی فراوان و دبریدمان بافت نکروزه در هر زخم آلوده‌ای واجب است.",
   "کلستریدیوم تتانی بی‌هوازی اجباری است و در بافت زنده و اکسیژن‌دار رشد نمی‌کند.",
   "بافت مرده و جسم خارجی همان محیط بی‌اکسیژنی را می‌سازند که برای جوانه زدن اسپور لازم است.",
   "پس دبریدمان خودش یک اقدام پیشگیرانه‌ی واقعی است، نه صرفاً بهداشت.",
   "توکسین کزاز رهاسازی مهارکننده‌های عصبی را مسدود می‌کند و اسپاسم و تریسموس می‌دهد.",
   "کزاز بیماری قابل پیشگیری صددرصدی است و هر مورد آن نشانه‌ی نقص در واکسیناسیون است."
  ],
  "points_en": [
   "Tetanus prophylaxis depends on two variables: the number of prior doses and whether the wound is dirty.",
   "A deep, soil-contaminated wound is definitively in the dirty category.",
   "With three or more doses, a dirty wound needs no booster for five years.",
   "In the same person, a clean wound needs none for ten years.",
   "This patient is three years from his last dose, below both thresholds.",
   "Tetanus immunoglobulin is only for a dirty wound with fewer than three doses or unknown history.",
   "This patient has the complete series, so immunoglobulin is superfluous.",
   "'No specific measure' refers only to immunological prophylaxis, not to wound care.",
   "Copious irrigation and debridement of necrotic tissue are mandatory for any dirty wound.",
   "Clostridium tetani is an obligate anaerobe and cannot grow in living, oxygenated tissue.",
   "Dead tissue and foreign bodies create the very anaerobic niche its spores need to germinate.",
   "So debridement is itself genuine prophylaxis, not merely hygiene.",
   "Tetanus toxin blocks release of inhibitory neurotransmitters, causing spasm and trismus.",
   "Tetanus is entirely preventable, and every case reflects a failure of vaccination."
  ]
 },
 "explanation_fa": "دو عدد را کنار هم بگذارید و قاعده خودش را نشان می‌دهد. زخم عمیق و آلوده به خاک قطعاً آلوده طبقه‌بندی می‌شود. بیمار بیست و سه ساله است و آخرین دوز را در بیست سالگی زده، یعنی فقط سه سال گذشته. قاعده در فرد با سه دوز واکسن یا بیشتر این است: زخم آلوده تا پنج سال و زخم تمیز تا ده سال از آخرین دوز یادآور نمی‌خواهد. سه سال از آستانه‌ی پنج‌ساله کمتر است، پس نه واکسن لازم است و نه ایمونوگلوبولین. ایمونوگلوبولین کزاز فقط برای زخم آلوده در فردی است که کمتر از سه دوز گرفته یا سابقه‌اش نامعلوم است. البته اقدام خاصی لازم نیست فقط به پروفیلاکسی ایمونولوژیک اشاره دارد، نه به مراقبت از زخم که در هر حالتی واجب است.",
 "explanation_en": "Put two numbers together and the rule declares itself. A deep, soil-contaminated wound is certainly dirty. The patient is twenty-three and had his last dose at twenty, so only three years have passed. The rule for someone with three or more doses is that a dirty wound needs no booster within five years and a clean wound none within ten. Three years is below the five-year threshold, so neither vaccine nor immunoglobulin is required. Tetanus immunoglobulin is reserved for a dirty wound in someone with fewer than three doses or an unknown history. Of course, 'no specific measure' refers only to immunological prophylaxis, not to wound care, which is mandatory regardless.",
 "why_fa": [
  "یادآور واکسن وقتی لازم است که بیش از پنج سال از آخرین دوز در زخم آلوده گذشته باشد؛ اینجا سه سال است.",
  "ایمونوگلوبولین فقط برای ایمنی ناقص یا نامعلوم است و در فرد با سری کامل جایگاهی ندارد.",
  "پاسخ صحیح — با ایمنی کامل و فاصله‌ی سه‌ساله، هیچ پروفیلاکسی ایمونولوژیکی لازم نیست.",
  "ترکیب واکسن و ایمونوگلوبولین بیش‌درمانی است و هیچ‌کدام از دو جزء آن در این بیمار اندیکاسیون ندارد."
 ],
 "why_en": [
  "A booster is needed when more than five years have passed for a dirty wound; here only three have.",
  "Immunoglobulin is only for incomplete or unknown immunity and has no place in a fully immunised person.",
  "Correct — with full immunity and a three-year interval no immunological prophylaxis is required.",
  "Vaccine plus immunoglobulin is over-treatment; neither component is indicated in this patient."
 ],
 "golden_fa": "≥۳ دوز: آلوده تا ۵ سال، تمیز تا ۱۰ سال بدون یادآور. شست‌وشو و دبریدمان همیشه واجب.",
 "golden_en": "Three or more doses: no booster for five years (dirty) or ten (clean). Irrigation and debridement always mandatory.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 148: Tetanus"]
}

L["1400-03:126"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "بالای ۵۰ سال = لیستریا هم مطرح است ← آمپی‌سیلین + سفتریاکسون + وانکومایسین.",
  "lead_en": "Over 50 means Listeria is in play: ampicillin plus ceftriaxone plus vancomycin.",
  "points_fa": [
   "درمان تجربی مننژیت باکتریال بر پایه‌ی سن و وضعیت ایمنی انتخاب می‌شود.",
   "در بالغ سالم زیر پنجاه سال، دو عامل غالب پنوموکوک و مننگوکوک هستند.",
   "رژیم آن گروه: سفتریاکسون به‌علاوه‌ی وانکومایسین.",
   "وانکومایسین برای پوشش پنوموکوک مقاوم به سفالوسپورین اضافه می‌شود، نه برای استاف.",
   "بالای پنجاه سال یک عامل سوم وارد می‌شود: لیستریا مونوسیتوژنز.",
   "لیستریا به تمام سفالوسپورین‌ها ذاتاً مقاوم است.",
   "پس هیچ‌کدام از داروهای رژیم پایه آن را پوشش نمی‌دهد و آمپی‌سیلین جداگانه لازم است.",
   "سه گروه نیازمند آمپی‌سیلین: بالای پنجاه سال، نوزادان، و نقص ایمنی سلولی یا بارداری.",
   "سفتازیدیم پوشش ضعیفی روی پنوموکوک دارد و برای مننژیت جامعه انتخاب نمی‌شود.",
   "وانکومایسین با سفپیم رژیم مننژیت بیمارستانی یا پس از جراحی مغز است.",
   "آنتی‌بیوتیک نباید برای انجام LP یا CT به تعویق بیفتد؛ اول کشت خون، بعد دارو.",
   "دگزامتازون باید همزمان یا کمی پیش از اولین دوز آنتی‌بیوتیک شروع شود.",
   "دگزامتازون عوارض عصبی و کاهش شنوایی در مننژیت پنوموکوکی را کم می‌کند.",
   "اگر آنتی‌بیوتیک زودتر داده شود، پنجره‌ی اثر دگزامتازون از دست می‌رود.",
   "CT پیش از LP فقط در نقص ایمنی، تشنج، پاپی‌ادم یا علامت کانونی لازم است."
  ],
  "points_en": [
   "Empirical therapy for bacterial meningitis is selected by age and immune status.",
   "In a healthy adult under fifty the dominant organisms are pneumococcus and meningococcus.",
   "That group's regimen is ceftriaxone plus vancomycin.",
   "Vancomycin covers cephalosporin-resistant pneumococcus, not staphylococci.",
   "Above fifty a third organism enters: Listeria monocytogenes.",
   "Listeria is intrinsically resistant to all cephalosporins.",
   "So no drug in the base regimen covers it and separate ampicillin is required.",
   "Three groups need ampicillin: over fifty, neonates, and impaired cellular immunity or pregnancy.",
   "Ceftazidime covers pneumococcus poorly and is not chosen for community-acquired meningitis.",
   "Vancomycin with cefepime is the regimen for nosocomial or post-neurosurgical meningitis.",
   "Antibiotics must not be delayed for LP or CT; take blood cultures, then treat.",
   "Dexamethasone should be started with or just before the first antibiotic dose.",
   "It reduces neurological sequelae and hearing loss in pneumococcal meningitis.",
   "If antibiotics are given first, the window for dexamethasone benefit is lost.",
   "CT before LP is needed only for immunosuppression, seizures, papilloedema or focal signs."
  ]
 },
 "explanation_fa": "درمان تجربی مننژیت باکتریال بر پایه‌ی سن انتخاب می‌شود و تنها عددی که در این سؤال اهمیت دارد شصت و پنج سال است. در بالغ سالم زیر پنجاه سال، رژیم استاندارد سفتریاکسون به‌علاوه‌ی وانکومایسین است. اما بالای پنجاه سال یک عامل سوم وارد می‌شود: لیستریا مونوسیتوژنز. لیستریا به تمام سفالوسپورین‌ها ذاتاً مقاوم است، پس هیچ‌کدام از داروهای رژیم پایه آن را پوشش نمی‌دهند و باید آمپی‌سیلین جداگانه اضافه شود. همین یک نکته پاسخ را تعیین می‌کند: رژیم سه‌دارویی. سفتازیدیم پوشش ضعیفی روی پنوموکوک دارد. وانکومایسین با سفپیم رژیم مننژیت بیمارستانی است. وانکومایسین با سفتریاکسون همان رژیم بالغ جوان است و آمپی‌سیلین کم دارد.",
 "explanation_en": "Empirical therapy for bacterial meningitis is chosen by age, and the only number that matters here is sixty-five. In a healthy adult under fifty the standard regimen is ceftriaxone plus vancomycin. But above fifty a third organism enters the picture: Listeria monocytogenes. Listeria is intrinsically resistant to every cephalosporin, so nothing in the base regimen covers it and ampicillin must be added separately. That single point decides the answer: the three-drug regimen. Ceftazidime covers pneumococcus poorly. Vancomycin with cefepime is the nosocomial meningitis regimen. Vancomycin with ceftriaxone is the young-adult regimen and lacks ampicillin.",
 "why_fa": [
  "سفتازیدیم پوشش ضعیفی روی پنوموکوک دارد و برای مننژیت اکتسابی از جامعه انتخاب نمی‌شود.",
  "پاسخ صحیح — بالای پنجاه سال، آمپی‌سیلین برای لیستریا به رژیم سفتریاکسون و وانکومایسین اضافه می‌شود.",
  "وانکومایسین با سفپیم رژیم مننژیت بیمارستانی است و لیستریا را هم پوشش نمی‌دهد.",
  "این همان رژیم بالغ جوان است و در بیمار شصت و پنج ساله پوشش لیستریا را جا انداخته است."
 ],
 "why_en": [
  "Ceftazidime covers pneumococcus poorly and is not chosen for community-acquired meningitis.",
  "Correct — above fifty, ampicillin is added to ceftriaxone and vancomycin to cover Listeria.",
  "Vancomycin with cefepime is the nosocomial regimen and also fails to cover Listeria.",
  "This is the young-adult regimen and omits Listeria cover in a 65-year-old."
 ],
 "golden_fa": "<۵۰: سفتریاکسون + وانکو. >۵۰ یا نوزاد یا نقص ایمنی: + آمپی‌سیلین (لیستریا). دگزامتازون همزمان.",
 "golden_en": "Under 50: ceftriaxone plus vancomycin. Over 50, neonate or immunocompromised: add ampicillin for Listeria. Dexamethasone with the first dose.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 133: Acute Bacterial Meningitis"]
}

L["1400-03:127"] = {
 "style": "case", "difficulty": "hard",
 "micro": {
  "lead_fa": "واکسن بروسلوز دامی زنده است. needle stick با آن = تلقیح مستقیم ← پروفیلاکسی دودارویی.",
  "lead_en": "The animal brucellosis vaccine is live. A needle stick with it is direct inoculation: give dual prophylaxis.",
  "points_fa": [
   "واکسن‌های بروسلوز دامی، سویه‌های RB51 و S19، حاوی باکتری زنده‌ی ضعیف‌شده هستند.",
   "پس needle stick با آن‌ها یک تلقیح مستقیم بروسلای زنده به بافت انسان است.",
   "این با یک تماس شغلی احتمالی فرق دارد و پروفیلاکسی قطعاً اندیکاسیون دارد.",
   "بروسلا باکتری داخل‌سلولی است، پس تک‌دارو در پیشگیری هم کافی نیست.",
   "رژیم پیشگیری: ریفامپین به‌علاوه‌ی داکسی‌سایکلین، معمولاً سه تا شش هفته.",
   "نکته‌ی مهم: سویه‌ی RB51 ذاتاً به ریفامپین مقاوم است.",
   "در تماس با RB51 معمولاً داکسی‌سایکلین به‌علاوه‌ی کوتریموکسازول توصیه می‌شود.",
   "منتظر بروز علائم ماندن انتخاب بدی است چون کمون بروسلوز هفته‌ها تا ماه‌ها است.",
   "درمان پس از استقرار عفونت طولانی‌تر، پرعارضه‌تر و با خطر عود بالاتر است.",
   "استرپتومایسین تک‌دوز نه رژیم پیشگیری است و نه درمان کامل.",
   "علاوه بر دارو، باید سرولوژی پایه گرفته شود.",
   "سرولوژی باید در هفته‌های شش، دوازده و بیست و چهار تکرار گردد.",
   "کارکنان آزمایشگاه هم در معرض خطرند؛ بروسلا از شایع‌ترین عفونت‌های آزمایشگاهی است.",
   "پیشگیری اولیه: استفاده از دستکش، عینک محافظ و تکنیک ایمن هنگام واکسیناسیون دام."
  ],
  "points_en": [
   "Animal brucellosis vaccines, strains RB51 and S19, contain live attenuated organisms.",
   "So a needle stick with one is a direct inoculation of live Brucella into human tissue.",
   "This differs from a possible occupational exposure and prophylaxis is definitely indicated.",
   "Brucella is intracellular, so monotherapy is insufficient even for prophylaxis.",
   "Prophylactic regimen: rifampin plus doxycycline, usually three to six weeks.",
   "An important caveat: strain RB51 is intrinsically resistant to rifampin.",
   "For RB51 exposure, doxycycline plus co-trimoxazole is usually recommended.",
   "Waiting for symptoms is a poor choice because the incubation runs weeks to months.",
   "Treatment after established infection is longer, more complicated and relapses more often.",
   "A single dose of streptomycin is neither prophylaxis nor complete therapy.",
   "Besides drugs, a baseline serology must be taken.",
   "Serology should be repeated at six, twelve and twenty-four weeks.",
   "Laboratory staff are also at risk; Brucella is among the commonest laboratory-acquired infections.",
   "Primary prevention: gloves, eye protection and safe technique when vaccinating livestock."
  ]
 },
 "explanation_fa": "نکته‌ای که این سؤال را از یک تماس شغلی معمولی جدا می‌کند این است که واکسن بروسلوز دامی حاوی باکتری زنده‌ی ضعیف‌شده است. یعنی needle stick با آن یک تلقیح مستقیم بروسلای زنده به داخل بافت انسان است، نه صرفاً یک تماس احتمالی. به همین دلیل این وضعیت جزو معدود مواردی است که پروفیلاکسی پس از تماس در بروسلوز قطعاً اندیکاسیون دارد. رژیم پیشگیری همان منطق درمان را دنبال می‌کند: چون بروسلا داخل‌سلولی است، تک‌دارو کافی نیست و ترکیب دودارویی لازم است. منتظر بروز علائم ماندن انتخاب بدی است چون دوره‌ی کمون بروسلوز می‌تواند هفته‌ها تا ماه‌ها باشد و درمان پس از استقرار عفونت طولانی‌تر و پرعارضه‌تر است.",
 "explanation_en": "What separates this from an ordinary occupational exposure is that the animal brucellosis vaccine contains live attenuated organisms. A needle stick with it is therefore a direct inoculation of live Brucella into human tissue, not merely a possible contact. That makes it one of the few situations where post-exposure prophylaxis for brucellosis is clearly indicated. The prophylactic regimen follows the same logic as treatment: because Brucella is intracellular, monotherapy is inadequate and a dual combination is required. Waiting for symptoms is a poor choice, since the incubation period can run weeks to months and treating established infection is longer and more troublesome.",
 "why_fa": [
  "تلقیح مستقیم باکتری زنده هرگز بی‌خطر نیست و رها کردن بیمار بدون پروفیلاکسی پذیرفتنی نمی‌باشد.",
  "پاسخ صحیح — ریفامپین به‌همراه داکسی‌سایکلین، رژیم دودارویی پیشگیری پس از تماس با واکسن زنده است.",
  "کمون بروسلوز هفته‌ها تا ماه‌هاست؛ انتظار برای علائم یعنی از دست دادن پنجره‌ی پیشگیری مؤثر.",
  "استرپتومایسین تک‌دوز نه پروفیلاکسی استاندارد است و نه درمان کامل بروسلوز محسوب می‌شود."
 ],
 "why_en": [
  "Direct inoculation of a live organism is never harmless and leaving the patient without prophylaxis is unacceptable.",
  "Correct — rifampin plus doxycycline is the dual post-exposure regimen after a live-vaccine needle stick.",
  "Brucellosis incubates over weeks to months; waiting for symptoms forfeits the effective prophylaxis window.",
  "A single dose of streptomycin is neither standard prophylaxis nor complete treatment."
 ],
 "golden_fa": "واکسن دامی بروسلوز = باکتری زنده. needle stick ← ریفامپین + داکسی ۳–۶ هفته + سرولوژی پیگیری.",
 "golden_en": "The animal brucellosis vaccine is live. Needle stick means rifampin plus doxycycline for three to six weeks with follow-up serology.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 169: Brucellosis"]
}

L["1400-03:128"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "آنفلوانزا → بهبود نسبی → بدتر شدن با کانسالیدیشن = پنومونی باکتریال ثانویه.",
  "lead_en": "Influenza, partial recovery, then deterioration with consolidation equals secondary bacterial pneumonia.",
  "points_fa": [
   "الگوی زمانی مهم‌ترین سرنخ است و باید آن را به‌عنوان یک امضا حفظ کرد.",
   "بیماری آنفلوانزایی، سپس بهبودی نسبی، سپس بدتر شدن دوباره با تب و علائم تنفسی.",
   "این بدتر شدن دوفازی تعریف پنومونی باکتریال ثانویه پس از آنفلوانزاست.",
   "ویروس اپیتلیوم مژک‌دار مجرای تنفسی را تخریب می‌کند و پاکسازی موکوسیلیاری از کار می‌افتد.",
   "همچنین عملکرد نوتروفیل و ماکروفاژ آلوئولار مختل می‌شود.",
   "در نتیجه باکتری‌های کلونیزه‌کننده‌ی نازوفارنکس راه ورود به آلوئول پیدا می‌کنند.",
   "شایع‌ترین عامل استرپتوکوک پنومونیه است.",
   "خطرناک‌ترین استافیلوکوک اورئوس است که کاویتاسیون، نکروز و امپیم می‌دهد.",
   "هموفیلوس آنفلوانزا عامل کلاسیک سوم است، به‌ویژه در بیماران ریوی.",
   "دیابت عامل خطر مستقلی است که هم احتمال و هم شدت را بالا می‌برد.",
   "پنومونی ویروسی اولیه بدون فاصله‌ی بهبودی و به‌صورت پیوسته بدتر می‌شود.",
   "در پنومونی ویروسی سرفه خشک است و انفیلتراسیون منتشر دوطرفه دیده می‌شود، نه کانسالیدیشن لوبار.",
   "آمبولی ریه تنگی نفس ناگهانی می‌دهد و معمولاً تب بالا و کانسالیدیشن واضح ندارد.",
   "ادم ریه نان‌کاردیوژنیک انفیلتراسیون منتشر دوطرفه می‌سازد نه یک کانون لوبار.",
   "واکسیناسیون سالانه آنفلوانزا و واکسن پنوموکوک بهترین پیشگیری از این عارضه است."
  ],
  "points_en": [
   "The temporal pattern is the key clue and should be memorised as a signature.",
   "An influenza-like illness, then partial recovery, then renewed deterioration with fever and respiratory signs.",
   "This biphasic worsening defines secondary bacterial pneumonia after influenza.",
   "The virus destroys the ciliated respiratory epithelium and mucociliary clearance fails.",
   "Neutrophil and alveolar macrophage function are also impaired.",
   "Nasopharyngeal colonising bacteria consequently gain access to the alveoli.",
   "The commonest organism is Streptococcus pneumoniae.",
   "The most dangerous is Staphylococcus aureus, causing cavitation, necrosis and empyema.",
   "Haemophilus influenzae is the classic third agent, especially in patients with lung disease.",
   "Diabetes is an independent risk factor raising both the likelihood and the severity.",
   "Primary viral pneumonia worsens continuously without an interval of recovery.",
   "In viral pneumonia the cough is dry with diffuse bilateral infiltrates, not lobar consolidation.",
   "Pulmonary embolism causes sudden dyspnoea, usually without high fever or clear consolidation.",
   "Non-cardiogenic pulmonary oedema produces diffuse bilateral infiltrates, not a lobar focus.",
   "Annual influenza vaccination and pneumococcal vaccine are the best prevention."
  ]
 },
 "explanation_fa": "الگوی زمانی همه‌چیز را روشن می‌کند و باید آن را به‌عنوان یک امضا حفظ کرد: بیماری آنفلوانزایی، سپس بهبودی نسبی، سپس بدتر شدن دوباره با تب و علائم تنفسی. این بدتر شدن دوفازی تعریف پنومونی باکتریال ثانویه است. مکانیسمش هم منطقی است: ویروس آنفلوانزا اپیتلیوم مژک‌دار را تخریب می‌کند و پاکسازی موکوسیلیاری از کار می‌افتد، پس باکتری‌های کلونیزه‌کننده‌ی نازوفارنکس راه ورود به آلوئول پیدا می‌کنند. دیابت هم عامل خطر مستقلی است. سه گزینه‌ی دیگر با این الگو نمی‌خوانند: پنومونی ویروسی اولیه بدون فاصله‌ی بهبودی و با انفیلتراسیون منتشر دوطرفه است؛ آمبولی ریه تنگی نفس ناگهانی می‌دهد بدون کانسالیدیشن واضح؛ و ادم ریه نان‌کاردیوژنیک هم انفیلتراسیون منتشر می‌سازد نه کانون لوبار.",
 "explanation_en": "The temporal pattern makes everything clear and should be memorised as a signature: an influenza-like illness, then partial recovery, then renewed deterioration with fever and respiratory signs. That biphasic worsening defines secondary bacterial pneumonia. The mechanism follows logically: influenza destroys the ciliated epithelium and mucociliary clearance fails, so nasopharyngeal colonising bacteria reach the alveoli. Diabetes is an independent risk factor. The other three options do not fit: primary viral pneumonia comes without an interval of recovery and with diffuse bilateral infiltrates; pulmonary embolism causes sudden dyspnoea without clear consolidation; and non-cardiogenic pulmonary oedema also produces diffuse infiltrates rather than a lobar focus.",
 "why_fa": [
  "پنومونی ویروسی اولیه بدون فاصله‌ی بهبودی و به‌صورت پیوسته بدتر می‌شود و انفیلتراسیون منتشر دارد.",
  "پاسخ صحیح — الگوی دوفازی با کانسالیدیشن لوبار، تعریف پنومونی باکتریال ثانویه پس از آنفلوانزاست.",
  "آمبولی ریه تنگی نفس ناگهانی می‌دهد و معمولاً تب بالا و کانسالیدیشن لوبار واضح ایجاد نمی‌کند.",
  "ادم ریه نان‌کاردیوژنیک انفیلتراسیون منتشر دوطرفه می‌سازد، نه یک کانون کانسالیدیشن در یک لوب."
 ],
 "why_en": [
  "Primary viral pneumonia worsens continuously without an interval of recovery and shows diffuse infiltrates.",
  "Correct — the biphasic pattern with lobar consolidation defines secondary bacterial pneumonia after influenza.",
  "Pulmonary embolism causes sudden dyspnoea, usually without high fever or clear lobar consolidation.",
  "Non-cardiogenic pulmonary oedema produces diffuse bilateral infiltrates, not a single lobar focus."
 ],
 "golden_fa": "آنفلوانزا → بهتر → بدتر + کانسالیدیشن = پنومونی ثانویه: پنوموکوک > استاف > هموفیلوس.",
 "golden_en": "Influenza, better, then worse with consolidation equals secondary pneumonia: pneumococcus, staph, Haemophilus.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 195: Influenza; Ch. 126: Pneumonia"]
}

L["1400-03:129"] = {
 "style": "recall", "difficulty": "hard",
 "micro": {
  "lead_fa": "سل ستون فقرات تخریب می‌کند؛ بروسلوز ترمیم می‌کند. استئوفیت parrot beak امضای بروسلوز است.",
  "lead_en": "Spinal TB destroys; brucellosis repairs. The parrot-beak osteophyte is the brucellar signature.",
  "points_fa": [
   "افتراق اسپوندیلودیسکیت سلی از بروسلایی را بهتر است از روی رفتار دو بیماری به خاطر سپرد.",
   "سل ستون فقرات یا بیماری پات مخرب است و مهره را تخریب می‌کند.",
   "نتیجه‌ی این تخریب Anterior wedging و در نهایت دفورمیتی گیبوس است.",
   "آبسه‌ی سرد پاراورتبرال و گسترش به عضله‌ی پسواس از مشخصات سل است.",
   "این کالکشن‌ها اغلب بزرگ‌اند و انهنسمنت حلقوی دارند.",
   "سل زودتر و شدیدتر به دیسک بین‌مهره‌ای حمله می‌کند و آن را از بین می‌برد.",
   "محل شایع سل ستون فقرات ناحیه‌ی توراسیک تحتانی و توراکولومبار است.",
   "بروسلوز برعکس، تخریب کمتری ایجاد می‌کند و بدن فرصت پاسخ ترمیمی پیدا می‌کند.",
   "نتیجه‌اش تشکیل استئوفیت در لبه‌ی قدامی‌فوقانی مهره است.",
   "این استئوفیت به‌خاطر شکل منحنی‌اش منقار طوطی یا parrot beak نامیده می‌شود.",
   "علامت منقار طوطی نسبتاً اختصاصی اسپوندیلیت بروسلایی محسوب می‌شود.",
   "محل شایع بروسلوز ستون فقرات، ناحیه‌ی لومبار و به‌ویژه L4-L5 است.",
   "در بروسلوز ارتفاع مهره معمولاً حفظ می‌شود و دفورمیتی شدید نادر است.",
   "در بیمار دامدار با کمردرد مزمن و تب، هر دو تشخیص باید همزمان در نظر گرفته شوند.",
   "سرولوژی بروسلا و بررسی سل باید با هم درخواست شوند و بیوپسی در موارد مبهم کمک می‌کند."
  ],
  "points_en": [
   "Distinguishing tuberculous from brucellar spondylodiscitis is best remembered from how the two behave.",
   "Spinal tuberculosis, or Pott disease, is destructive and erodes the vertebral body.",
   "That destruction produces anterior wedging and ultimately a gibbus deformity.",
   "Cold paravertebral abscess with extension into the psoas muscle is characteristic of tuberculosis.",
   "These collections are often large and show rim enhancement.",
   "Tuberculosis attacks and destroys the intervertebral disc earlier and more severely.",
   "The common site for spinal tuberculosis is the lower thoracic and thoracolumbar region.",
   "Brucellosis by contrast causes less destruction and allows a reparative response.",
   "The result is osteophyte formation at the anterosuperior vertebral margin.",
   "Because of its curved shape this osteophyte is called a parrot beak.",
   "The parrot-beak sign is relatively specific for brucellar spondylitis.",
   "The common site for spinal brucellosis is the lumbar region, especially L4-L5.",
   "In brucellosis vertebral height is usually preserved and severe deformity is rare.",
   "In a livestock worker with chronic back pain and fever, consider both diagnoses together.",
   "Brucella serology and tuberculosis work-up should be requested together, with biopsy in unclear cases."
  ]
 },
 "explanation_fa": "این سؤال یک جدول افتراقی کلاسیک است و بهتر است آن را از روی رفتار دو بیماری به خاطر سپرد، نه با حفظ کردن. سل ستون فقرات مخرب است: مهره را تخریب می‌کند، بنابراین Anterior wedging و در نهایت دفورمیتی گیبوس می‌سازد. آبسه‌ی سرد پاراورتبرال و گسترش به عضله‌ی پسواس هم مشخصه‌ی آن است. سل همچنین زودتر و شدیدتر به دیسک بین‌مهره‌ای حمله می‌کند. پس هر سه گزینه‌ی اول واقعاً به نفع سل هستند. بروسلوز برعکس، بیماری‌ای است که تخریب کمتری ایجاد می‌کند و بدن فرصت پاسخ ترمیمی و استخوان‌سازی پیدا می‌کند. نتیجه‌اش تشکیل استئوفیت در لبه‌ی قدامی‌فوقانی مهره است که منقار طوطی نامیده می‌شود و علامت نسبتاً اختصاصی اسپوندیلیت بروسلایی محسوب می‌گردد.",
 "explanation_en": "This is a classic comparison table, best remembered from how the two diseases behave rather than by rote. Spinal tuberculosis is destructive: it erodes the vertebral body, producing anterior wedging and ultimately a gibbus deformity. Cold paravertebral abscess extending into the psoas is also characteristic, and tuberculosis attacks the intervertebral disc earlier and more severely. So all three of the first options genuinely favour tuberculosis. Brucellosis, by contrast, causes less destruction and allows the body a reparative, bone-forming response. The result is an osteophyte at the anterosuperior vertebral margin, called a parrot beak, which is relatively specific for brucellar spondylitis.",
 "why_fa": [
  "Anterior wedging از تخریب جسم مهره می‌آید و مشخصه‌ی سل ستون فقرات است، نه بروسلوز.",
  "آبسه‌ی سرد پاراورتبرال با گسترش به عضله‌ی پسواس یافته‌ی کلاسیک بیماری پات محسوب می‌شود.",
  "درگیری زودرس و شدید دیسک بین‌مهره‌ای در سل بسیار بیشتر از بروسلوز دیده می‌شود.",
  "پاسخ صحیح — استئوفیت منقار طوطی پاسخ ترمیمی است و به نفع بروسلوز، نه سل."
 ],
 "why_en": [
  "Anterior wedging results from vertebral body destruction and characterises spinal tuberculosis, not brucellosis.",
  "A cold paravertebral abscess extending into the psoas is a classic finding of Pott disease.",
  "Early, severe involvement of the intervertebral disc is far commoner in tuberculosis than brucellosis.",
  "Correct — the parrot-beak osteophyte is a reparative response favouring brucellosis, not tuberculosis."
 ],
 "golden_fa": "سل = تخریب (wedging، آبسه پسواس، دیسک زودرس). بروسلوز = ترمیم (استئوفیت منقار طوطی، L4-L5).",
 "golden_en": "TB destroys (wedging, psoas abscess, early disc). Brucellosis repairs (parrot-beak osteophyte, L4-L5).",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 169: Brucellosis; Ch. 178: Tuberculosis"]
}

L["1400-03:130"] = {
 "style": "case", "difficulty": "hard",
 "micro": {
  "lead_fa": "ترومبوسیتوپنی با خون‌ریزی در رژیم ضدسل = ریفامپین. قطع دائمی، هرگز شروع مجدد.",
  "lead_en": "Thrombocytopenia with bleeding on anti-TB therapy means rifampin. Stop permanently and never rechallenge.",
  "points_fa": [
   "هر یک از چهار داروی خط اول سل یک عارضه‌ی امضایی دارد.",
   "ترومبوسیتوپنی شدید با خون‌ریزی، عارضه‌ی اختصاصی ریفامپین است.",
   "مکانیسم آن ایمونولوژیک است، نه سرکوب مستقیم مغز استخوان.",
   "ریفامپین باعث تولید آنتی‌بادی وابسته به دارو علیه پلاکت می‌شود.",
   "این آنتی‌بادی‌ها پلاکت‌ها را نشانه‌گذاری و تخریب می‌کنند.",
   "عارضه اغلب در هفته‌های اول درمان یا پس از مصرف منقطع و نامنظم رخ می‌دهد.",
   "مصرف نامنظم خطر را بالا می‌برد چون هر بار مواجهه‌ی مجدد پاسخ ایمنی را تقویت می‌کند.",
   "ترومبوسیتوپنی ناشی از ریفامپین یک منع مطلق و دائمی است.",
   "دارو باید فوراً قطع شود و هرگز دوباره شروع نگردد.",
   "مواجهه‌ی مجدد می‌تواند خون‌ریزی شدید و کشنده ایجاد کند.",
   "این با هپاتوتوکسیسیته فرق دارد که در آن داروها پس از بهبود یکی‌یکی برمی‌گردند.",
   "قطع کل داروها لازم نیست و حتی مضر است چون سل اسمیر مثبت مسری و خطرناک است.",
   "وقفه‌ی بی‌مورد در درمان سل خطر مقاومت دارویی را بالا می‌برد.",
   "سه داروی دیگر عوارض متفاوتی دارند: ایزونیازید نوروپاتی و هپاتیت، پیرازینامید هایپراوریسمی، اتامبوتول نوریت اپتیک.",
   "پس از قطع ریفامپین، رژیم باید بازطراحی و طول درمان معمولاً طولانی‌تر شود."
  ],
  "points_en": [
   "Each of the four first-line TB drugs has a signature adverse effect.",
   "Severe thrombocytopenia with bleeding is the specific toxicity of rifampin.",
   "The mechanism is immunological rather than direct marrow suppression.",
   "Rifampin induces drug-dependent antibodies directed against platelets.",
   "These antibodies tag the platelets for destruction.",
   "It occurs most often in the first weeks of therapy or after intermittent, irregular dosing.",
   "Irregular dosing raises the risk because each re-exposure boosts the immune response.",
   "Rifampin-induced thrombocytopenia is an absolute and permanent contraindication.",
   "The drug must be stopped immediately and never restarted.",
   "Rechallenge can cause severe and fatal bleeding.",
   "This differs from hepatotoxicity, where drugs are reintroduced one by one after recovery.",
   "Stopping all drugs is unnecessary and even harmful, since smear-positive TB is infectious and dangerous.",
   "An unnecessary interruption in TB therapy increases the risk of drug resistance.",
   "The other three have different toxicities: isoniazid neuropathy and hepatitis, pyrazinamide hyperuricaemia, ethambutol optic neuritis.",
   "After stopping rifampin the regimen must be redesigned and treatment is usually prolonged."
  ]
 },
 "explanation_fa": "ترومبوسیتوپنی شدید با خون‌ریزی، دو هفته پس از شروع رژیم چهاردارویی، یک عارضه‌ی شناخته‌شده و اختصاصی دارد: ریفامپین. مکانیسم آن ایمونولوژیک است — ریفامپین باعث تولید آنتی‌بادی وابسته به دارو علیه پلاکت می‌شود و پلاکت‌ها تخریب می‌گردند. این عارضه اغلب در هفته‌های اول درمان یا پس از مصرف منقطع رخ می‌دهد. نکته‌ی حیاتی این است که ترومبوسیتوپنی ناشی از ریفامپین یک منع مطلق و دائمی است: دارو نه‌تنها باید فوراً قطع شود، بلکه هرگز نباید دوباره شروع گردد، چون مواجهه‌ی مجدد می‌تواند خون‌ریزی کشنده ایجاد کند. این با هپاتوتوکسیسیته فرق دارد. قطع کل داروها لازم نیست و حتی مضر است، چون سل اسمیر مثبت درمان‌نشده هم خطرناک است و هم مسری.",
 "explanation_en": "Severe thrombocytopenia with bleeding two weeks after starting four-drug therapy has one well-recognised and specific culprit: rifampin. The mechanism is immunological — rifampin induces drug-dependent antiplatelet antibodies and the platelets are destroyed. It occurs most often in the first weeks of treatment or after intermittent dosing. The critical point is that rifampin-induced thrombocytopenia is an absolute, permanent contraindication: the drug must not only be stopped at once but never restarted, because rechallenge can cause fatal bleeding. This differs from hepatotoxicity. Stopping all drugs is unnecessary and even harmful, since untreated smear-positive tuberculosis is both dangerous and contagious.",
 "why_fa": [
  "قطع کامل درمان لازم نیست و حتی مضر است، چون سل اسمیر مثبت مسری است و وقفه خطر مقاومت را بالا می‌برد.",
  "پاسخ صحیح — ترومبوسیتوپنی ایمونولوژیک عارضه‌ی اختصاصی ریفامپین است و قطع آن دائمی می‌باشد.",
  "پیرازینامید هایپراوریسمی و هپاتوتوکسیسیته می‌دهد، نه ترومبوسیتوپنی ایمونولوژیک.",
  "ایزونیازید نوروپاتی محیطی و هپاتیت ایجاد می‌کند و عارضه‌ی پلاکتی کلاسیک ندارد."
 ],
 "why_en": [
  "Stopping everything is unnecessary and even harmful; smear-positive TB is contagious and interruption breeds resistance.",
  "Correct — immunological thrombocytopenia is the specific toxicity of rifampin and its withdrawal is permanent.",
  "Pyrazinamide causes hyperuricaemia and hepatotoxicity, not immune thrombocytopenia.",
  "Isoniazid causes peripheral neuropathy and hepatitis and has no classic platelet toxicity."
 ],
 "golden_fa": "ریفامپین = ترومبوسیتوپنی ایمنی. قطع فوری و دائمی، هرگز rechallenge نکن.",
 "golden_en": "Rifampin means immune thrombocytopenia. Stop immediately and permanently; never rechallenge.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 178: Tuberculosis, drug toxicity"]
}

json.dump(L, io.open('/home/user/work/infectious/lessons/L7.json', 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('infectious L7:', len(L))
