# -*- coding: utf-8 -*-
"""Infectious micro-lessons, batch 6 — Esfand-1401 (items 122-130).
Reference: Harrison's Principles of Internal Medicine, 21st ed."""
import json, io
L = {}

L["1401-12:122"] = {
 "style": "case", "difficulty": "hard",
 "micro": {
  "lead_fa": "باکتریمی استاف اورئوس که با درمان مناسب >۷۲ ساعت پایدار بماند = کانون داخل‌عروقی = اکو.",
  "lead_en": "S. aureus bacteraemia persisting beyond 72 hours on adequate therapy means an intravascular focus: get an echo.",
  "points_fa": [
   "باکتریمی استافیلوکوک اورئوس هرگز آلودگی نمونه فرض نمی‌شود و همیشه جدی گرفته می‌شود.",
   "حدود یک‌چهارم موارد آن به اندوکاردیت عفونی منجر می‌شود.",
   "پرسش کلیدی در هر مورد این است: آیا کانون متاستاتیک یا داخل‌عروقی وجود دارد؟",
   "قوی‌ترین پیش‌بینی‌کننده‌ی اندوکاردیت، پایدار ماندن باکتریمی با وجود درمان مؤثر است.",
   "منطق ماجرا مکانیکی است: وژتاسیون دریچه‌ای محلی است که دارو به‌خوبی به آن نفوذ نمی‌کند.",
   "کشت خون باید ۴۸ تا ۷۲ ساعت پس از شروع درمان تکرار شود؛ همین یک آزمایش مسیر را تعیین می‌کند.",
   "سایر شواهد له اندوکاردیت: دریچه‌ی مصنوعی، ضایعات پوستی آمبولیک، سوفل جدید و تب پایدار.",
   "بیماری دریچه‌ای قبلی عامل خطر است ولی زمینه‌ای و ثابت است، نه شاهد فعال عفونت کنونی.",
   "محل اکتساب عفونت و طول علائم اختصاصیت کافی برای تصمیم‌گیری ندارند.",
   "اکوکاردیوگرافی ترانس‌توراسیک اولین گام است ولی حساسیتش حدود شصت درصد می‌باشد.",
   "اکوی ترانس‌ازوفاژیال حساسیت بالای نود درصد دارد و در شک بالا یا اکوی سطحی منفی لازم است.",
   "تشخیص اندوکاردیت طول درمان را از دو هفته به چهار تا شش هفته تغییر می‌دهد.",
   "در سالمندان تابلوی اندوکاردیت اغلب مبهم است و ممکن است فقط با تب طولانی بروز کند.",
   "معیارهای دوک چارچوب رسمی تشخیص است و کشت خون مثبت مکرر یکی از معیارهای اصلی آن است."
  ],
  "points_en": [
   "S. aureus bacteraemia is never assumed to be a contaminant and is always taken seriously.",
   "About a quarter of cases lead to infective endocarditis.",
   "The key question in every case is whether a metastatic or intravascular focus exists.",
   "The strongest predictor of endocarditis is bacteraemia persisting despite effective therapy.",
   "The reasoning is mechanical: a valvular vegetation is a site drugs penetrate poorly.",
   "Repeat blood cultures 48 to 72 hours after starting therapy; that single test directs everything.",
   "Other evidence favouring endocarditis: prosthetic valve, embolic skin lesions, new murmur, persistent fever.",
   "Pre-existing valve disease is a risk factor but is background and fixed, not live evidence of current infection.",
   "Where the infection was acquired and how long symptoms lasted lack the specificity to decide.",
   "Transthoracic echocardiography is the first step but its sensitivity is only about sixty per cent.",
   "Transoesophageal echo exceeds ninety per cent sensitivity and is needed when suspicion is high or TTE is negative.",
   "A diagnosis of endocarditis changes treatment from two weeks to four to six weeks.",
   "In the elderly the picture is often vague and may present only as prolonged fever.",
   "The Duke criteria provide the formal framework, with repeatedly positive blood cultures as a major criterion."
  ]
 },
 "explanation_fa": "باکتریمی استافیلوکوک اورئوس هرگز بی‌اهمیت نیست، ولی سؤال دنبال قوی‌ترین پیش‌بینی‌کننده‌ی اندوکاردیت می‌گردد. همه‌ی گزینه‌ها عوامل خطرند، اما پایدار ماندن باکتریمی با وجود درمان مناسب از همه قوی‌تر است، و دلیلش مکانیکی است: اگر با آنتی‌بیوتیک مؤثر باز هم باکتری در خون بماند، یعنی یک کانون درون‌عروقی وجود دارد که دارو به‌خوبی به آن نفوذ نمی‌کند، و شایع‌ترین چنین کانونی وژتاسیون دریچه‌ای است. بیماری دریچه‌ای قبلی هم عامل خطر است ولی زمینه‌ای و ثابت است، در حالی که باکتریمی پایدار شاهد فعال و زنده‌ی همین لحظه است. نکته‌ی عملی: در باکتریمی استاف اورئوس، کشت خون را ۴۸ تا ۷۲ ساعت پس از شروع درمان تکرار کنید.",
 "explanation_en": "S. aureus bacteraemia is never trivial, but the question asks for the strongest predictor of endocarditis. All the options are risk factors, yet bacteraemia persisting despite adequate therapy outweighs them, and the reason is mechanical: if the organism remains in the blood on an effective antibiotic, there must be an intravascular focus the drug penetrates poorly, and the commonest such focus is a valvular vegetation. Pre-existing valve disease is also a risk factor, but it is background and fixed, whereas persistent bacteraemia is live evidence of what is happening now. The practical point: in S. aureus bacteraemia, repeat blood cultures 48 to 72 hours after starting treatment.",
 "why_fa": [
  "طول علائم بیش از هفت روز غیراختصاصی است و در بسیاری از عفونت‌های دیگر هم دیده می‌شود.",
  "پاسخ صحیح — باکتریمی پایدار بیش از ۷۲ ساعت با درمان مناسب، قوی‌ترین شاهد کانون داخل‌عروقی است.",
  "بیماری دریچه‌ای قبلی عامل خطر زمینه‌ای است، نه شاهد فعال عفونت کنونی دریچه.",
  "عفونت کسب‌شده از اجتماع در برابر بیمارستانی، اختصاصیت لازم برای پیش‌بینی اندوکاردیت را ندارد."
 ],
 "why_en": [
  "Symptoms lasting over seven days is non-specific and occurs in many other infections.",
  "Correct — bacteraemia persisting beyond 72 hours on adequate therapy is the strongest evidence of an intravascular focus.",
  "Pre-existing valve disease is a background risk factor, not live evidence of current valvular infection.",
  "Community versus hospital acquisition lacks the specificity needed to predict endocarditis."
 ],
 "golden_fa": "استاف اورئوس در خون = کشت را ۴۸–۷۲ ساعت بعد تکرار کن. پایدار ماند ← اکو (ترجیحاً TEE).",
 "golden_en": "S. aureus in blood: repeat the culture at 48-72 hours. If still positive, echo (preferably TEE).",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 124: Infective Endocarditis"]
}

L["1401-12:123"] = {
 "style": "case", "difficulty": "hard",
 "micro": {
  "lead_fa": "سل در بارداری: پیرازینامید حذف می‌شود، پس درمان ۹ ماهه می‌شود — ۲ماه HRE و ۷ماه HR.",
  "lead_en": "TB in pregnancy: pyrazinamide is omitted, so therapy runs nine months — 2 months HRE then 7 months HR.",
  "points_fa": [
   "درمان سل فعال در بارداری هرگز به تعویق نمی‌افتد؛ خودِ بیماری برای مادر و جنین خطرناک‌تر است.",
   "رژیم استاندارد غیرباردار شش ماه است: دو ماه چهاردارویی و چهار ماه ایزونیازید و ریفامپین.",
   "ایزونیازید، ریفامپین و اتامبوتول هر سه در بارداری بی‌خطر تلقی می‌شوند.",
   "بی‌خطری پیرازینامید در بارداری به‌طور کامل اثبات نشده است.",
   "بسیاری از راهنماهای ملی، از جمله رویه‌ی رایج در ایران، پیرازینامید را در بارداری حذف می‌کنند.",
   "حذف پیرازینامید فاز فشرده را ضعیف‌تر می‌کند و باید با طولانی‌تر شدن فاز نگهدارنده جبران شود.",
   "رژیم حاصل: دو ماه ایزونیازید، ریفامپین و اتامبوتول، سپس هفت ماه ایزونیازید و ریفامپین.",
   "مجموع درمان نُه ماه می‌شود، نه شش ماه.",
   "ویتامین B6 برای پیشگیری از نوروپاتی محیطی ایزونیازید در بارداری الزامی است.",
   "استرپتومایسین در بارداری کاملاً ممنوع است؛ سمیت گوش داخلی و ناشنوایی مادرزادی می‌دهد.",
   "سایر آمینوگلیکوزیدها و کاپرئومایسین هم به همین دلیل کنار گذاشته می‌شوند.",
   "شیردهی در حین درمان سل مجاز است؛ غلظت داروها در شیر ناچیز و بی‌خطر است.",
   "مادر با سل ریوی اسمیر مثبت باید تا منفی شدن اسمیر از نوزاد جدا شود یا ماسک بزند.",
   "نوزاد مادر مبتلا باید از نظر سل مادرزادی و نهفته ارزیابی شود."
  ],
  "points_en": [
   "Active TB in pregnancy is never postponed; the disease itself is more dangerous to mother and fetus.",
   "The standard non-pregnant regimen is six months: two months of four drugs then four of isoniazid and rifampin.",
   "Isoniazid, rifampin and ethambutol are all considered safe in pregnancy.",
   "The safety of pyrazinamide in pregnancy has not been fully established.",
   "Many national guidelines, including common practice in Iran, omit pyrazinamide in pregnancy.",
   "Omitting it weakens the intensive phase, which must be offset by lengthening the continuation phase.",
   "The resulting regimen: two months of isoniazid, rifampin and ethambutol, then seven months of isoniazid and rifampin.",
   "Total therapy is nine months, not six.",
   "Vitamin B6 is mandatory in pregnancy to prevent isoniazid peripheral neuropathy.",
   "Streptomycin is absolutely contraindicated: fetal ototoxicity and congenital deafness.",
   "Other aminoglycosides and capreomycin are avoided for the same reason.",
   "Breastfeeding during TB treatment is permitted; drug levels in milk are negligible and safe.",
   "A mother with smear-positive pulmonary TB should be separated from the infant or masked until smear conversion.",
   "The infant of an affected mother must be assessed for congenital and latent tuberculosis."
  ]
 },
 "explanation_fa": "درمان سل در بارداری یک تفاوت کلیدی با حالت معمول دارد و همان تفاوت پاسخ سؤال است. رژیم استاندارد شش‌ماهه شامل پیرازینامید است، اما بی‌خطری پیرازینامید در بارداری به‌طور کامل اثبات نشده و بسیاری از راهنماهای ملی آن را حذف می‌کنند. وقتی پیرازینامید را بردارید، فاز فشرده ضعیف‌تر می‌شود و باید با طولانی‌تر کردن فاز نگهدارنده جبران شود: دو ماه ایزونیازید، ریفامپین و اتامبوتول، سپس هفت ماه ایزونیازید و ریفامپین، یعنی مجموعاً نُه ماه. گزینه‌ای که رژیم شش‌ماهه‌ی معمول را پیشنهاد می‌دهد پیرازینامید دارد؛ گزینه‌ی نُه‌ماهه‌ی نگهدارنده فاز نگهدارنده را بیش از حد طولانی می‌کند؛ و رژیم بدون فاز فشرده برای سل فعالِ اسمیر مثبت ناکافی است.",
 "explanation_en": "Treating tuberculosis in pregnancy differs from the usual approach in one key way, and that difference is the answer. The standard six-month regimen contains pyrazinamide, but its safety in pregnancy is not fully established and many national guidelines omit it. Removing pyrazinamide weakens the intensive phase, which must be compensated by lengthening the continuation phase: two months of isoniazid, rifampin and ethambutol, then seven months of isoniazid and rifampin, nine months in all. The option offering the usual six-month course contains pyrazinamide; the nine-month continuation option prolongs that phase excessively; and a regimen without an intensive phase is inadequate for active smear-positive disease.",
 "why_fa": [
  "این رژیم فاز نگهدارنده را نُه ماه می‌کند که مجموعاً یازده ماه می‌شود و طولانی‌تر از استاندارد بارداری است.",
  "این همان رژیم شش‌ماهه‌ی معمول است که پیرازینامید دارد و در بارداری معمولاً حذف می‌شود.",
  "پاسخ صحیح — دو ماه HRE سپس هفت ماه HR، مجموعاً نُه ماه، رژیم استاندارد سل در بارداری است.",
  "رژیم بدون فاز فشرده برای سل فعال اسمیر مثبت ناکافی است و خطر شکست درمان و مقاومت دارد."
 ],
 "why_en": [
  "This makes the continuation phase nine months, eleven in total, longer than the pregnancy standard.",
  "This is the usual six-month regimen containing pyrazinamide, which is normally omitted in pregnancy.",
  "Correct — two months of HRE then seven of HR, nine months in all, is the standard pregnancy regimen.",
  "A regimen without an intensive phase is inadequate for active smear-positive disease and risks failure and resistance."
 ],
 "golden_fa": "بارداری: پیرازینامید حذف ← ۲ماه HRE + ۷ماه HR = ۹ ماه. B6 الزامی. استرپتومایسین ممنوع.",
 "golden_en": "Pregnancy: omit pyrazinamide, so 2 months HRE plus 7 months HR equals nine. B6 mandatory. Streptomycin forbidden.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 178: Tuberculosis",
          "درمان سل — مصوبه ۱۴۰۳ کمیته کشوری سل، وزارت بهداشت"]
}

L["1401-12:124"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "اسهال آبکی که خونی می‌شود + تنسموس + انتقال خانوادگی = شیگلا. درمان: سیپروفلوکساسین.",
  "lead_en": "Watery diarrhoea turning bloody, with tenesmus and household spread, is Shigella. Treat with ciprofloxacin.",
  "points_fa": [
   "شیگلا دوز عفونی بسیار پایینی دارد: ده تا صد باکتری برای ایجاد بیماری کافی است.",
   "همین ویژگی باعث انتقال آسان فرد به فرد در خانواده، مهدکودک و مدرسه می‌شود.",
   "سیر کلاسیک دومرحله‌ای است: ابتدا اسهال آبکی، سپس تبدیل به اسهال خونی ظرف یک تا دو روز.",
   "دلیلش این است که باکتری ابتدا روده‌ی باریک را درگیر و سپس به کولون تهاجم می‌کند.",
   "تنسموس نشانه‌ی درگیری رکتوسیگموئید است و در اسهال روده‌ی باریک دیده نمی‌شود.",
   "شیگلوز از معدود اسهال‌هایی است که آنتی‌بیوتیک واقعاً در آن اندیکاسیون دارد.",
   "آنتی‌بیوتیک هم طول بیماری را کوتاه می‌کند و هم دفع باکتری و انتقال به دیگران را کم می‌کند.",
   "داروی انتخابی در بالغین فلوروکینولون است، معمولاً سیپروفلوکساسین سه تا پنج روز.",
   "در کودکان آزیترومایسین یا سفتریاکسون ترجیح داده می‌شود.",
   "کوتریموکسازول زمانی خط اول بود ولی امروز مقاومت گسترده دارد.",
   "داروهای ضدحرکتی در شیگلوز ممنوع‌اند چون خطر مگاکولون توکسیک را بالا می‌برند.",
   "عوارض: تشنج در کودکان، سندرم اورمیک همولیتیک با شیگلا دیسانتری تیپ یک، و آرتریت راکتیو.",
   "افتراق از آمیبیازیس: آمیب سیر تدریجی‌تر دارد و معمولاً تب بالا و انتقال سریع خانوادگی ندارد.",
   "در بیمار HIV مثبت یا سوءتغذیه، کشت خون هم بفرستید چون خطر باکتریمی بالاست."
  ],
  "points_en": [
   "Shigella has a very low infectious dose: ten to a hundred organisms suffice.",
   "That property drives easy person-to-person spread within households, nurseries and schools.",
   "The classic course has two stages: watery diarrhoea first, turning bloody within a day or two.",
   "This reflects initial small-bowel involvement followed by invasion of the colon.",
   "Tenesmus indicates rectosigmoid involvement and is absent in small-bowel diarrhoea.",
   "Shigellosis is one of the few diarrhoeas in which antibiotics are genuinely indicated.",
   "They shorten the illness and reduce shedding and onward transmission.",
   "The drug of choice in adults is a fluoroquinolone, usually ciprofloxacin for three to five days.",
   "In children azithromycin or ceftriaxone is preferred.",
   "Co-trimoxazole was once first-line but resistance is now widespread.",
   "Antimotility agents are contraindicated because they raise the risk of toxic megacolon.",
   "Complications: seizures in children, haemolytic uraemic syndrome with S. dysenteriae type 1, and reactive arthritis.",
   "Distinguishing amoebiasis: it runs a more gradual course, usually without high fever or rapid household spread.",
   "In HIV or malnutrition send blood cultures too, as the risk of bacteraemia is high."
  ]
 },
 "explanation_fa": "سه سرنخ به شیگلوز اشاره می‌کنند: اسهالی که از آبکی به خونی تبدیل می‌شود، تنسموس که نشانه‌ی درگیری رکتوسیگموئید است، و انتقال فرد به فرد در خانواده. شیگلا دوز عفونی بسیار پایینی دارد — ده تا صد باکتری کافی است — و به همین دلیل ابتلای خواهر کوچک‌تر سه روز قبل کاملاً با آن می‌خواند. شیگلوز از معدود اسهال‌هایی است که آنتی‌بیوتیک واقعاً در آن اندیکاسیون دارد: هم طول بیماری را کوتاه می‌کند و هم دفع باکتری و انتقال به دیگران را. داروی انتخابی در بالغین فلوروکینولون است. کوتریموکسازول زمانی خط اول بود ولی امروز مقاومت گسترده دارد. مترونیدازول برای آمیبیازیس است که سیر تدریجی‌تری دارد.",
 "explanation_en": "Three clues point to shigellosis: diarrhoea that changes from watery to bloody, tenesmus indicating rectosigmoid involvement, and person-to-person spread within the family. Shigella has a very low infectious dose, ten to a hundred organisms, which is exactly why the five-year-old sister fell ill three days earlier. Shigellosis is one of the few diarrhoeas where antibiotics are genuinely indicated: they shorten the illness and reduce shedding and transmission. The drug of choice in adults is a fluoroquinolone. Co-trimoxazole was once first-line but resistance is now widespread. Metronidazole treats amoebiasis, which follows a more gradual course.",
 "why_fa": [
  "پاسخ صحیح — سیپروفلوکساسین داروی انتخابی شیگلوز در بالغین است و انتقال به دیگران را هم کم می‌کند.",
  "کوتریموکسازول زمانی خط اول بود ولی مقاومت گسترده‌ی امروزی آن را از انتخاب اول خارج کرده است.",
  "سفکسیم پوشش ضعیف‌تری در برابر شیگلا دارد و در بالغین انتخاب اول محسوب نمی‌شود.",
  "مترونیدازول برای آمیبیازیس است؛ آمیب سیر تدریجی‌تر و بدون این الگوی انتقال سریع خانوادگی دارد."
 ],
 "why_en": [
  "Correct — ciprofloxacin is the drug of choice for shigellosis in adults and also reduces onward transmission.",
  "Co-trimoxazole was once first-line but widespread resistance has removed it from first choice.",
  "Cefixime provides weaker cover against Shigella and is not first choice in adults.",
  "Metronidazole treats amoebiasis, which runs a more gradual course without this rapid household spread."
 ],
 "golden_fa": "شیگلا: دوز عفونی ۱۰–۱۰۰، انتقال خانوادگی، آبکی←خونی + تنسموس. درمان: سیپرو (بالغ)، آزیترومایسین (کودک).",
 "golden_en": "Shigella: infectious dose 10-100, household spread, watery turning bloody with tenesmus. Treat with cipro (adult) or azithromycin (child).",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 166: Shigellosis"]
}

L["1401-12:125"] = {
 "style": "recall", "difficulty": "medium",
 "micro": {
  "lead_fa": "هتروفیل در هفته‌ی اول منفی کاذب و زیر ۵ سال کم‌حساس است. بهترین زمان: هفته‌های ۲ تا ۵.",
  "lead_en": "Heterophile is falsely negative in week one and insensitive under age five. Best window: weeks two to five.",
  "points_fa": [
   "مونونوکلئوز عفونی عمدتاً از ویروس اپشتین-بار ناشی می‌شود.",
   "سه‌گانه‌ی کلاسیک: تب، فارنژیت اگزوداتیو و لنفادنوپاتی، به‌ویژه خلفی گردنی.",
   "لنفوسیتوز با لنفوسیت آتیپیک در لام خون محیطی یافته‌ی حمایتی مهمی است.",
   "اسپلنومگالی در حدود نیمی از بیماران دیده می‌شود و خطر پارگی طحال دارد.",
   "به همین دلیل ورزش‌های برخوردی تا سه تا چهار هفته ممنوع است.",
   "تست هتروفیل یا مونواسپات آنتی‌بادی‌های واکنش‌دهنده با گلبول قرمز حیوانی را می‌سنجد.",
   "در هفته‌ی اول بیماری آنتی‌بادی هتروفیل هنوز تولید نشده و منفی کاذب شایع است.",
   "اوج حساسیت تست در هفته‌های دوم تا پنجم بیماری است.",
   "در کودکان زیر چهار تا پنج سال پاسخ هتروفیل ضعیف است و تا نیمی از موارد منفی می‌شود.",
   "در این گروه سنی باید سراغ سرولوژی اختصاصی EBV رفت: VCA IgM و IgG و EBNA.",
   "بیماری‌های بافت همبند، لنفوم و برخی عفونت‌ها می‌توانند مثبت کاذب بدهند.",
   "در افراد مسن مونونوکلئوز نادر است و تابلو اغلب آتیپیک با زردی و تب طولانی است.",
   "تجویز آمپی‌سیلین یا آموکسی‌سیلین در مونونوکلئوز راش ماکولوپاپولر منتشر می‌دهد.",
   "درمان حمایتی است؛ کورتیکواستروئید فقط در انسداد راه هوایی یا سیتوپنی شدید اندیکاسیون دارد."
  ],
  "points_en": [
   "Infectious mononucleosis is mostly caused by Epstein-Barr virus.",
   "The classic triad: fever, exudative pharyngitis and lymphadenopathy, especially posterior cervical.",
   "Lymphocytosis with atypical lymphocytes on the smear is an important supporting finding.",
   "Splenomegaly occurs in about half of patients and carries a risk of splenic rupture.",
   "For that reason contact sports are prohibited for three to four weeks.",
   "The heterophile or monospot test detects antibodies reacting with animal red cells.",
   "In the first week of illness heterophile antibody has not yet appeared and false negatives are common.",
   "Sensitivity peaks in weeks two to five of the illness.",
   "In children under four or five the heterophile response is weak and up to half test negative.",
   "In that age group use EBV-specific serology: VCA IgM and IgG, and EBNA.",
   "Connective-tissue disease, lymphoma and some infections can cause false positives.",
   "Mononucleosis is rare in the elderly and often presents atypically with jaundice and prolonged fever.",
   "Giving ampicillin or amoxicillin in mononucleosis produces a diffuse maculopapular rash.",
   "Management is supportive; corticosteroids are indicated only for airway obstruction or severe cytopenia."
  ]
 },
 "explanation_fa": "تست هتروفیل محدودیت‌های مشخصی دارد و سؤال دقیقاً همان‌ها را می‌سنجد. اول زمان: آنتی‌بادی هتروفیل در هفته‌ی اول بیماری اغلب هنوز تولید نشده و منفی کاذب می‌دهد؛ اوج آن هفته‌های دوم تا پنجم است، پس «طی هفته سوم» دقیقاً پنجره‌ی بیشترین حساسیت است. دوم سن: در کودکان زیر چهار تا پنج سال پاسخ هتروفیل ضعیف است و تا پنجاه درصد موارد منفی می‌شود؛ در این گروه باید سراغ سرولوژی اختصاصی EBV رفت. سوم مثبت کاذب: بیماری‌های بافت همبند، لنفوم و برخی عفونت‌های دیگر می‌توانند تست را مثبت کنند، پس در آن زمینه ارزش تشخیصی‌اش افت می‌کند. در افراد مسن هم مونونوکلئوز اساساً نادر است و تابلو اغلب آتیپیک دارد.",
 "explanation_en": "The heterophile test has specific limitations and the question tests exactly those. First, timing: heterophile antibody has often not yet appeared in the first week and gives false negatives; it peaks in weeks two to five, so the third week is precisely the window of maximum sensitivity. Second, age: in children under four or five the response is weak and up to half test negative, so EBV-specific serology is needed in that group. Third, false positives: connective-tissue disease, lymphoma and some other infections can turn the test positive, undermining its value in that setting. In the elderly, mononucleosis is inherently rare and usually presents atypically.",
 "why_fa": [
  "در کودکان زیر پنج سال پاسخ هتروفیل ضعیف است و تا نیمی از موارد منفی کاذب می‌دهد.",
  "مونونوکلئوز در افراد مسن نادر است و تابلوی آتیپیک دارد، پس تست در این گروه کم‌ارزش است.",
  "پاسخ صحیح — هفته‌های دوم تا پنجم پنجره‌ی اوج تولید آنتی‌بادی هتروفیل و بیشترین حساسیت تست است.",
  "بیماری‌های بافت همبند از علل شناخته‌شده‌ی مثبت کاذب هستند و ارزش تشخیصی تست را کم می‌کنند."
 ],
 "why_en": [
  "In children under five the heterophile response is weak and up to half are falsely negative.",
  "Mononucleosis is rare and atypical in the elderly, so the test has little value in that group.",
  "Correct — weeks two to five are the peak window for heterophile antibody and maximum test sensitivity.",
  "Connective-tissue disease is a recognised cause of false positives and reduces the test's diagnostic value."
 ],
 "golden_fa": "مونواسپات: هفته ۱ منفی کاذب، هفته ۲–۵ بهترین، زیر ۵ سال کم‌حساس ← سرولوژی EBV.",
 "golden_en": "Monospot: false negative in week one, best in weeks two to five, insensitive under age five: use EBV serology.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 193: Epstein-Barr Virus Infections"]
}

L["1401-12:126"] = {
 "style": "case", "difficulty": "hard",
 "micro": {
  "lead_fa": "سابقه‌ی بروسلوز درمان‌شده = سرولوژی برای سال‌ها مثبت می‌ماند. عفونت فعال را با کشت یا PCR اثبات کن.",
  "lead_en": "Treated brucellosis leaves serology positive for years. Prove active infection with culture or PCR.",
  "points_fa": [
   "آنتی‌بادی ضدبروسلا پس از یک عفونت درمان‌شده ماه‌ها تا سال‌ها در خون باقی می‌ماند.",
   "پس تیتر مثبت در فردی با سابقه‌ی بروسلوز، بین عفونت فعال و خاطره‌ی ایمنی تمایز نمی‌گذارد.",
   "همین ابهام، رایت و کومبس رایت را در این بیمار خاص بی‌فایده می‌کند.",
   "کومبس رایت برای یافتن آنتی‌بادی ناقص در بروسلوز مزمن ساخته شده، ولی همین مشکل را دارد.",
   "برای اثبات عفونت فعال باید خودِ باکتری یا DNA آن نشان داده شود.",
   "کشت خون استاندارد طلایی است ولی کند است و ممکن است تا چند هفته طول بکشد.",
   "آزمایشگاه باید از شک به بروسلا مطلع شود تا پلیت را طولانی‌تر نگه دارد.",
   "PCR روی خون محیطی سریع‌تر است و حساسیت خوبی دارد، به‌ویژه در عود.",
   "تابلوی این بیمار — تب، بای‌سیتوپنی و اسپلنومگالی — با بروسلوز فعال کاملاً سازگار است.",
   "بروسلا داخل سلول‌های رتیکولواندوتلیال زندگی می‌کند و همین اسپلنومگالی و سیتوپنی را توضیح می‌دهد.",
   "بیوپسی مغز استخوان در بروسلوز حساسیت بالایی دارد ولی تهاجمی است و گام اول نیست.",
   "با این حال بای‌سیتوپنی خودش اندیکاسیون مستقل بیوپسی است اگر کشت و PCR منفی بمانند.",
   "عود بروسلوز معمولاً در شش ماه اول پس از درمان رخ می‌دهد و اغلب از درمان ناکافی می‌آید.",
   "در عود، همان رژیم دودارویی با طول درمان بیشتر تکرار می‌شود."
  ],
  "points_en": [
   "Anti-Brucella antibody persists for months to years after a treated infection.",
   "So a positive titre in someone with previous brucellosis cannot separate active infection from immunological memory.",
   "That ambiguity makes Wright and Coombs-Wright useless in this particular patient.",
   "Coombs-Wright was designed to detect incomplete antibody in chronic brucellosis but shares the same problem.",
   "Proving active infection requires demonstrating the organism itself or its DNA.",
   "Blood culture is the gold standard but is slow and may take several weeks.",
   "The laboratory must be told Brucella is suspected so the plates are held longer.",
   "PCR on peripheral blood is faster and has good sensitivity, particularly in relapse.",
   "This patient's picture — fever, bicytopenia and splenomegaly — fits active brucellosis well.",
   "Brucella lives inside reticuloendothelial cells, which explains the splenomegaly and cytopenias.",
   "Bone marrow biopsy has high sensitivity in brucellosis but is invasive and not the first step.",
   "That said, bicytopenia is itself an independent indication for biopsy if culture and PCR stay negative.",
   "Relapse usually occurs within six months of treatment and often follows inadequate therapy.",
   "In relapse the same dual regimen is repeated for a longer duration."
  ]
 },
 "explanation_fa": "نکته‌ی کلیدی در صورت سؤال، سابقه‌ی بروسلوز درمان‌شده است و همین همه‌چیز را عوض می‌کند. تیتر آنتی‌بادی پس از یک عفونت درمان‌شده ماه‌ها تا سال‌ها مثبت می‌ماند، پس رایت و حتی کومبس رایت نمی‌توانند بگویند این تب تازه از بروسلوز است یا صرفاً بازتاب عفونت گذشته. آزمون سرولوژیک اینجا ذاتاً مبهم است. برای اثبات عفونت فعال باید خودِ باکتری یا DNA آن را نشان داد: کشت خون که استاندارد طلایی است ولی کند، یا PCR که سریع‌تر است. بیوپسی مغز استخوان تهاجمی است و هرچند در بروسلوز حساسیت خوبی دارد، به‌عنوان گام اول انتخاب نمی‌شود، هرچند در همین بیمار با بای‌سیتوپنی اندیکاسیون مستقل خودش را دارد اگر کشت و PCR منفی بمانند.",
 "explanation_en": "The key detail in the stem is the history of treated brucellosis, and it changes everything. Antibody titres stay positive for months to years after treatment, so neither Wright nor Coombs-Wright can tell whether this new fever is brucellosis or merely an echo of the past infection. Serology here is inherently ambiguous. Proving active infection requires showing the organism or its DNA: blood culture, the gold standard but slow, or PCR, which is faster. Bone marrow biopsy is invasive and, although sensitive in brucellosis, is not the first step — though in this patient with bicytopenia it has its own independent indication if culture and PCR come back negative.",
 "why_fa": [
  "تست رایت پس از عفونت درمان‌شده سال‌ها مثبت می‌ماند و بین عفونت فعال و گذشته تمایز نمی‌گذارد.",
  "کومبس رایت هم همین محدودیت را دارد و در فرد با سابقه‌ی بروسلوز ابهام را برطرف نمی‌کند.",
  "پاسخ صحیح — کشت خون یا PCR خودِ باکتری یا DNA آن را نشان می‌دهد و عفونت فعال را اثبات می‌کند.",
  "بیوپسی مغز استخوان حساس است ولی تهاجمی و گام اول نیست؛ فقط اگر کشت و PCR منفی بماند مطرح می‌شود."
 ],
 "why_en": [
  "The Wright test stays positive for years after treatment and cannot distinguish active from past infection.",
  "Coombs-Wright shares that limitation and does not resolve the ambiguity in a previously infected patient.",
  "Correct — blood culture or PCR demonstrates the organism or its DNA and proves active infection.",
  "Marrow biopsy is sensitive but invasive and not first-line; consider it only if culture and PCR are negative."
 ],
 "golden_fa": "بروسلوز قبلی درمان‌شده ← سرولوژی بی‌فایده. عفونت فعال = کشت خون یا PCR.",
 "golden_en": "With previously treated brucellosis serology is useless. Prove active infection with blood culture or PCR.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 169: Brucellosis"]
}

L["1401-12:127"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "زخم آلوده + ایمنی کامل + ۶ سال از آخرین دوز = فقط یک دوز یادآور واکسن. TIG لازم نیست.",
  "lead_en": "Dirty wound plus full immunity plus six years since the last dose means one booster only; no TIG.",
  "points_fa": [
   "گازگرفتگی همیشه زخم آلوده محسوب می‌شود، چون بزاق و فلور دهان وارد بافت می‌شود.",
   "در فرد با سه دوز واکسن یا بیشتر، آستانه‌ی یادآور برای زخم آلوده پنج سال است.",
   "برای زخم تمیز همان آستانه ده سال می‌باشد.",
   "این بیمار شش سال از آخرین دوز گذشته، پس از آستانه‌ی پنج‌ساله عبور کرده و یادآور لازم است.",
   "ایمونوگلوبولین کزاز فقط برای کسی است که کمتر از سه دوز گرفته یا سابقه‌اش نامعلوم است.",
   "این بیمار سری کامل کودکی را دارد، پس حافظه‌ی ایمنی‌اش با یک یادآور به‌سرعت فعال می‌شود.",
   "دادن ایمونوگلوبولین به فرد با ایمنی کامل نه لازم است نه بی‌هزینه.",
   "گازگرفتگی سگ فقط بحث کزاز نیست؛ سه تصمیم دیگر هم همزمان لازم است.",
   "اول ارزیابی هاری: وضعیت واکسیناسیون حیوان و امکان مشاهده‌ی ده‌روزه‌ی آن.",
   "در سگ خانگی واکسینه و قابل مشاهده، معمولاً می‌توان منتظر ماند و پروفیلاکسی نداد.",
   "دوم شست‌وشوی فراوان زخم با آب و صابون که خودش خطر هاری و عفونت را کم می‌کند.",
   "سوم تصمیم درباره‌ی آنتی‌بیوتیک پروفیلاکسی با کوآموکسی‌کلاو.",
   "گاز سگ زخم پهن‌تری می‌سازد و میزان عفونتش از گاز گربه و انسان کمتر است.",
   "پس پروفیلاکسی آنتی‌بیوتیکی در گاز سگ انتخابی است: زخم دست، عمیق، یا میزبان پرخطر."
  ],
  "points_en": [
   "A bite always counts as a dirty wound, because saliva and oral flora enter the tissue.",
   "In someone with three or more doses, the booster threshold for a dirty wound is five years.",
   "For a clean wound the same threshold is ten years.",
   "Six years have passed here, crossing the five-year threshold, so a booster is required.",
   "Tetanus immunoglobulin is only for those with fewer than three doses or an unknown history.",
   "This patient completed the childhood series, so a booster will rapidly recall his immunity.",
   "Giving immunoglobulin to a fully immunised person is neither necessary nor free of cost.",
   "A dog bite is not only about tetanus; three other decisions are needed at the same time.",
   "First, rabies assessment: the animal's vaccination status and whether it can be observed for ten days.",
   "For a vaccinated, observable household dog one can usually wait and withhold prophylaxis.",
   "Second, copious irrigation with soap and water, which itself lowers rabies and infection risk.",
   "Third, the decision about antibiotic prophylaxis with co-amoxiclav.",
   "Dog bites create wider wounds and have a lower infection rate than cat or human bites.",
   "So antibiotic prophylaxis for dog bites is selective: hand wounds, deep wounds, or a high-risk host."
  ]
 },
 "explanation_fa": "دو عدد را کنار هم بگذارید: زخم گازگرفتگی آلوده محسوب می‌شود، و آخرین دوز واکسن شش سال پیش بوده. قاعده این است که در فرد با ایمنی کامل، برای زخم تمیز تا ده سال و برای زخم آلوده تا پنج سال نیازی به یادآور نیست. شش سال از آستانه‌ی پنج‌ساله‌ی زخم آلوده گذشته، پس یک دوز یادآور واکسن لازم است. ایمونوگلوبولین کزاز لازم نیست، چون آن فقط برای کسی است که کمتر از سه دوز واکسن گرفته یا سابقه‌اش نامعلوم است؛ این بیمار سری کامل را دارد و حافظه‌ی ایمنی‌اش با یک یادآور به‌سرعت فعال می‌شود. و البته گازگرفتگی سگ فقط بحث کزاز نیست: ارزیابی هاری، شست‌وشوی فراوان زخم و تصمیم درباره‌ی کوآموکسی‌کلاو هم باید همزمان انجام شود.",
 "explanation_en": "Put two numbers together: a bite counts as a dirty wound, and the last vaccine dose was six years ago. The rule is that in a fully immunised person no booster is needed within ten years for a clean wound or five years for a dirty one. Six years has crossed the five-year threshold, so a single booster dose is required. Tetanus immunoglobulin is not needed, since it is reserved for those with fewer than three doses or an unknown history; this man completed the series and a booster will rapidly recall his immunity. And of course a dog bite is not only about tetanus: rabies assessment, copious wound irrigation and the co-amoxiclav decision must all happen at the same time.",
 "why_fa": [
  "شش سال از آخرین دوز گذشته و زخم آلوده است، پس آستانه‌ی پنج‌ساله رد شده و پروفیلاکسی لازم است.",
  "پاسخ صحیح — یک دوز یادآور واکسن کزاز کافی است، چون بیمار ایمنی پایه‌ی کامل دارد.",
  "ایمونوگلوبولین فقط برای ایمنی ناقص یا نامعلوم است و در این بیمار با سری کامل اضافه محسوب می‌شود.",
  "ایمونوگلوبولین به‌تنهایی هرگز رژیم صحیح نیست و ایمنی بلندمدت هم ایجاد نمی‌کند."
 ],
 "why_en": [
  "Six years have passed and the wound is dirty, so the five-year threshold is crossed and prophylaxis is needed.",
  "Correct — a single tetanus booster suffices because the patient has complete baseline immunity.",
  "Immunoglobulin is only for incomplete or unknown immunity and is superfluous in a fully immunised patient.",
  "Immunoglobulin alone is never a correct regimen and confers no lasting immunity."
 ],
 "golden_fa": "زخم آلوده: یادآور اگر >۵ سال. زخم تمیز: اگر >۱۰ سال. TIG فقط وقتی <۳ دوز یا نامعلوم.",
 "golden_en": "Dirty wound: booster if over five years. Clean wound: if over ten. TIG only when fewer than three doses or unknown.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 148: Tetanus",
          "Ch. 141: Infectious Complications of Bites"]
}

L["1401-12:128"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "پیلونفریت حاد: کشت ادرار پیش از آنتی‌بیوتیک الزامی است. بستری و تصویربرداری انتخابی‌اند.",
  "lead_en": "Acute pyelonephritis: a urine culture before antibiotics is mandatory. Admission and imaging are selective.",
  "points_fa": [
   "پیلونفریت حاد با سه‌گانه‌ی درد پهلو، تب و علائم ادراری شناخته می‌شود.",
   "حساسیت زاویه‌ی دنده‌ای-مهره‌ای در معاینه یافته‌ی کلیدی است.",
   "برخلاف سیستیت ساده که می‌توان تجربی درمان کرد، در پیلونفریت کشت ادرار الزامی است.",
   "دلیل اول: درمان طولانی‌تر است و انتخاب اشتباه هزینه‌ی بیشتری دارد.",
   "دلیل دوم: مقاومت آنتی‌بیوتیکی، به‌ویژه به فلوروکینولون‌ها، در حال افزایش است.",
   "کشت باید حتماً پیش از اولین دوز آنتی‌بیوتیک گرفته شود وگرنه بازده‌اش می‌ریزد.",
   "شایع‌ترین عامل اشریشیاکلی است؛ سپس کلبسیلا، پروتئوس و انتروکوک.",
   "کشت خون فقط در بیمار بستری، سپتیک یا با نقص ایمنی ارزش افزوده دارد.",
   "اندیکاسیون بستری: استفراغ و ناتوانی از مصرف خوراکی، ناپایداری همودینامیک، بارداری.",
   "همچنین شک به انسداد، نقص ایمنی، یا شکست درمان سرپایی.",
   "این بیمار جوان، غیرباردار و پایدار است، پس بستری الزامی نیست.",
   "تصویربرداری فقط برای کسی است که پس از ۴۸ تا ۷۲ ساعت درمان مناسب بهبود نیافته.",
   "هدف تصویربرداری رد آبسه‌ی کلیه یا اطراف کلیه، سنگ و انسداد است.",
   "طول درمان پیلونفریت سرپایی معمولاً هفت تا چهارده روز است، بسته به دارو."
  ],
  "points_en": [
   "Acute pyelonephritis is recognised by the triad of flank pain, fever and urinary symptoms.",
   "Costovertebral angle tenderness is the key examination finding.",
   "Unlike simple cystitis, which may be treated empirically, a urine culture is mandatory here.",
   "First reason: treatment is longer, so a wrong choice costs more.",
   "Second reason: antimicrobial resistance, particularly to fluoroquinolones, is rising.",
   "The culture must be taken before the first antibiotic dose or its yield collapses.",
   "Escherichia coli is the commonest organism, followed by Klebsiella, Proteus and Enterococcus.",
   "Blood cultures add value only in admitted, septic or immunocompromised patients.",
   "Admission criteria: vomiting preventing oral therapy, haemodynamic instability, pregnancy.",
   "Also suspected obstruction, immunosuppression, or failure of outpatient therapy.",
   "This patient is young, non-pregnant and stable, so admission is not mandatory.",
   "Imaging is reserved for those not improving after 48 to 72 hours of appropriate therapy.",
   "Its purpose is to exclude renal or perinephric abscess, stones and obstruction.",
   "Outpatient pyelonephritis is usually treated for seven to fourteen days depending on the agent."
  ]
 },
 "explanation_fa": "تشخیص پیلونفریت حاد است: درد پهلو، تب و علائم ادراری. سؤال می‌پرسد کدام اقدام ضروری است، پس باید بین کارهای لازم و کارهای انتخابی تفکیک کنیم. کشت ادرار پیش از شروع آنتی‌بیوتیک در هر مورد پیلونفریت الزامی است، برخلاف سیستیت ساده که می‌توان تجربی درمان کرد. دلیلش این است که درمان طولانی‌تر است و مقاومت آنتی‌بیوتیکی شایع، پس باید بتوان رژیم را بر پایه‌ی آنتی‌بیوگرام تنظیم کرد. بقیه‌ی گزینه‌ها انتخابی‌اند: کشت خون فقط در بیمار بستری یا سپتیک ارزش افزوده دارد؛ بستری زمانی لازم است که بیمار استفراغ کند و نتواند دارو بخورد یا ناپایدار یا باردار باشد؛ و تصویربرداری برای کسی است که پس از ۴۸ تا ۷۲ ساعت درمان مناسب بهبود نیافته.",
 "explanation_en": "The diagnosis is acute pyelonephritis: flank pain, fever and urinary symptoms. The question asks which step is necessary, so we must separate the mandatory from the selective. A urine culture before starting antibiotics is mandatory in every case of pyelonephritis, unlike simple cystitis which can be treated empirically. The reason is that treatment is longer and resistance is common, so the regimen must be adjustable on sensitivities. The rest are selective: blood cultures add value only in an admitted or septic patient; admission is required when the patient cannot keep medication down, is unstable, or is pregnant; and imaging is for those failing to improve after 48 to 72 hours of appropriate therapy.",
 "why_fa": [
  "پاسخ صحیح — کشت ادرار پیش از شروع آنتی‌بیوتیک در هر مورد پیلونفریت الزامی است.",
  "کشت خون فقط در بیمار بستری، سپتیک یا با نقص ایمنی ارزش افزوده دارد، نه در این بیمار پایدار.",
  "بستری وقتی لازم است که بیمار نتواند دارو بخورد، ناپایدار باشد یا باردار؛ هیچ‌کدام اینجا نیست.",
  "سونوگرافی برای بیماری است که پس از ۴۸ تا ۷۲ ساعت درمان مناسب بهبود نیافته باشد."
 ],
 "why_en": [
  "Correct — a urine culture before starting antibiotics is mandatory in every case of pyelonephritis.",
  "Blood cultures add value only in admitted, septic or immunocompromised patients, not in this stable woman.",
  "Admission is needed when oral therapy is impossible, the patient is unstable, or pregnant; none applies here.",
  "Ultrasound is for a patient who has not improved after 48 to 72 hours of appropriate therapy."
 ],
 "golden_fa": "پیلونفریت: کشت ادرار همیشه و قبل از آنتی‌بیوتیک. تصویربرداری فقط اگر ۴۸–۷۲ ساعت بهبود نیافت.",
 "golden_en": "Pyelonephritis: always culture the urine, and before antibiotics. Image only if no improvement at 48-72 hours.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 130: Urinary Tract Infections"]
}

L["1401-12:129"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "بدتر شدن دوفازی پس از آنفلوانزا = پنومونی باکتریال ثانویه. پنوموکوک، استاف، هموفیلوس.",
  "lead_en": "Biphasic worsening after influenza means secondary bacterial pneumonia: pneumococcus, staph, Haemophilus.",
  "points_fa": [
   "الگوی زمانی مهم‌ترین سرنخ است: علائم آنفلوانزا، بهبود نسبی، سپس بدتر شدن دوباره.",
   "این «بدتر شدن دوفازی» تعریف پنومونی باکتریال ثانویه پس از آنفلوانزاست.",
   "مکانیسم روشن است: ویروس اپیتلیوم مژک‌دار مجرای تنفسی را تخریب می‌کند.",
   "با از کار افتادن پاکسازی موکوسیلیاری، باکتری‌های کلونیزه‌ی نازوفارنکس راه ورود پیدا می‌کنند.",
   "آنفلوانزا همچنین عملکرد نوتروفیل و ماکروفاژ آلوئولار را مختل می‌کند.",
   "شایع‌ترین عامل پنومونی ثانویه استرپتوکوک پنومونیه است.",
   "خطرناک‌ترین آن استافیلوکوک اورئوس است که کاویتاسیون و نکروز و امپیم می‌دهد.",
   "استاف اورئوس پس از آنفلوانزا مرگ‌ومیر بالایی دارد و سیر برق‌آسا می‌تواند داشته باشد.",
   "هموفیلوس آنفلوانزا هم عامل شناخته‌شده‌ی سوم است، به‌ویژه در COPD.",
   "پنومونی مستقیم ویروسی هم وجود دارد ولی الگوی متفاوتی دارد.",
   "در پنومونی ویروسی، بیماری بدون فاصله‌ی بهبودی و به‌صورت پیوسته بدتر می‌شود.",
   "سرفه در پنومونی ویروسی معمولاً خشک است، نه با خلط چرکی.",
   "درمان تجربی باید پوشش استاف اورئوس را در نظر بگیرد، به‌ویژه اگر کاویتاسیون باشد.",
   "واکسیناسیون سالانه آنفلوانزا و واکسن پنوموکوک بهترین پیشگیری از این عارضه است."
  ],
  "points_en": [
   "The temporal pattern is the key clue: influenza symptoms, partial recovery, then worsening again.",
   "This biphasic deterioration defines secondary bacterial pneumonia after influenza.",
   "The mechanism is clear: the virus destroys the ciliated respiratory epithelium.",
   "With mucociliary clearance lost, nasopharyngeal colonising bacteria gain entry.",
   "Influenza also impairs neutrophil and alveolar macrophage function.",
   "The commonest secondary pathogen is Streptococcus pneumoniae.",
   "The most dangerous is Staphylococcus aureus, causing cavitation, necrosis and empyema.",
   "Post-influenza S. aureus pneumonia carries high mortality and can run a fulminant course.",
   "Haemophilus influenzae is the recognised third agent, especially in COPD.",
   "Primary viral pneumonia also exists but follows a different pattern.",
   "In viral pneumonia the illness worsens continuously, without an interval of improvement.",
   "The cough in viral pneumonia is usually dry rather than purulent.",
   "Empirical therapy should consider S. aureus cover, especially if cavitation is present.",
   "Annual influenza vaccination and pneumococcal vaccine are the best prevention."
  ]
 },
 "explanation_fa": "الگوی زمانی سؤال را حل می‌کند. بیمار پنج روز پیش علائم آنفلوانزا داشته، بعد بهتر شده، و حالا دوباره با تب و لرز و خلط چرکی برگشته است. این بدتر شدن دوفازی تعریف پنومونی باکتریال ثانویه پس از آنفلوانزاست. مکانیسمش هم روشن است: ویروس اپیتلیوم مژک‌دار مجرای تنفسی را تخریب می‌کند و پاکسازی موکوسیلیاری از کار می‌افتد، پس باکتری‌های کلونیزه‌کننده‌ی نازوفارنکس راه ورود پیدا می‌کنند. سه عامل کلاسیک این پنومونی ثانویه عبارت‌اند از استرپتوکوک پنومونیه که شایع‌ترین است، استافیلوکوک اورئوس که خطرناک‌ترین است، و هموفیلوس آنفلوانزا. پس آنچه کمتر مطرح است خودِ ویروس آنفلوانزاست: پنومونی مستقیم ویروسی وجود دارد ولی بدون فاصله‌ی بهبودی و با سرفه‌ی خشک بروز می‌کند.",
 "explanation_en": "The temporal pattern solves this. The patient had influenza symptoms five days ago, improved, and has now returned with fever, chills and purulent sputum. That biphasic deterioration defines secondary bacterial pneumonia after influenza. The mechanism is clear: the virus destroys the ciliated respiratory epithelium, mucociliary clearance fails, and nasopharyngeal colonising bacteria gain entry. The three classic agents are Streptococcus pneumoniae, the commonest, Staphylococcus aureus, the most dangerous, and Haemophilus influenzae. So the least likely is influenza virus itself: primary viral pneumonia does occur, but without an interval of recovery and with a dry cough rather than purulent sputum.",
 "why_fa": [
  "استاف اورئوس عامل کلاسیک و خطرناک پنومونی ثانویه پس از آنفلوانزاست و کاملاً مطرح است.",
  "هموفیلوس آنفلوانزا هم از عوامل شناخته‌شده‌ی پنومونی ثانویه است، به‌ویژه در بیماران ریوی.",
  "استرپتوکوک پنومونیه شایع‌ترین عامل پنومونی ثانویه پس از آنفلوانزا محسوب می‌شود.",
  "پاسخ صحیح — پنومونی مستقیم ویروسی بدون فاصله‌ی بهبودی و با سرفه‌ی خشک است، نه این الگوی دوفازی."
 ],
 "why_en": [
  "S. aureus is the classic and dangerous agent of post-influenza secondary pneumonia and is very much in play.",
  "Haemophilus influenzae is another recognised secondary pathogen, especially in patients with lung disease.",
  "Streptococcus pneumoniae is the commonest cause of secondary pneumonia after influenza.",
  "Correct — primary viral pneumonia comes without an interval of recovery and with a dry cough, not this biphasic pattern."
 ],
 "golden_fa": "آنفلوانزا → بهبود → بدتر شدن = پنومونی باکتریال ثانویه: پنوموکوک > استاف > هموفیلوس.",
 "golden_en": "Influenza, then improvement, then worsening equals secondary bacterial pneumonia: pneumococcus, then staph, then Haemophilus.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 195: Influenza; Ch. 126: Pneumonia"]
}

L["1401-12:130"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "بالغ سالم ۳۲ ساله: سفتریاکسون + وانکومایسین. آمپی‌سیلین فقط بالای ۵۰ سال یا نقص ایمنی.",
  "lead_en": "Healthy 32-year-old adult: ceftriaxone plus vancomycin. Ampicillin only over 50 or if immunocompromised.",
  "points_fa": [
   "درمان تجربی مننژیت باکتریال بر پایه‌ی سن و وضعیت ایمنی انتخاب می‌شود.",
   "در بالغ سالم بین ۱۸ تا ۵۰ سال، دو عامل غالب پنوموکوک و مننگوکوک هستند.",
   "رژیم استاندارد این گروه: سفالوسپورین نسل سوم به‌علاوه‌ی وانکومایسین.",
   "وانکومایسین به‌خاطر پنوموکوک مقاوم به سفالوسپورین اضافه می‌شود، نه به‌خاطر استاف.",
   "آمپی‌سیلین فقط برای پوشش لیستریا مونوسیتوژنز است.",
   "لیستریا در سه گروه مطرح است: بالای پنجاه سال، نوزادان، و نقص ایمنی سلولی یا بارداری.",
   "این بیمار سی‌ودو ساله و بدون زمینه است، پس آمپی‌سیلین بیش‌درمانی محسوب می‌شود.",
   "لیستریا به سفالوسپورین‌ها ذاتاً مقاوم است و به همین دلیل آمپی‌سیلین جداگانه لازم می‌شود.",
   "دگزامتازون باید همزمان یا کمی پیش از اولین دوز آنتی‌بیوتیک شروع شود.",
   "دگزامتازون عوارض عصبی و کاهش شنوایی در مننژیت پنوموکوکی را کم می‌کند.",
   "اگر آنتی‌بیوتیک زودتر داده شود، اثر دگزامتازون از بین می‌رود.",
   "آنتی‌بیوتیک نباید برای انجام LP یا CT به تعویق بیفتد؛ اول کشت خون، بعد دارو.",
   "CT پیش از LP فقط در نقص ایمنی، تشنج، پاپی‌ادم یا علامت نورولوژیک کانونی لازم است.",
   "پس از مشخص شدن عامل، درمان باریک و هدفمند می‌شود."
  ],
  "points_en": [
   "Empirical therapy for bacterial meningitis is chosen by age and immune status.",
   "In a healthy adult aged 18 to 50 the dominant organisms are pneumococcus and meningococcus.",
   "The standard regimen for this group is a third-generation cephalosporin plus vancomycin.",
   "Vancomycin is added for cephalosporin-resistant pneumococcus, not for staphylococci.",
   "Ampicillin is included solely to cover Listeria monocytogenes.",
   "Listeria matters in three groups: over 50, neonates, and impaired cellular immunity or pregnancy.",
   "This 32-year-old has none of these, so ampicillin would be over-treatment.",
   "Listeria is intrinsically resistant to cephalosporins, which is why separate ampicillin is required.",
   "Dexamethasone should be given with or shortly before the first antibiotic dose.",
   "It reduces neurological sequelae and hearing loss in pneumococcal meningitis.",
   "If the antibiotic is given first, the benefit of dexamethasone is lost.",
   "Antibiotics must not be delayed for LP or CT; take blood cultures, then treat.",
   "CT before LP is needed only for immunosuppression, seizures, papilloedema or focal signs.",
   "Once the organism is identified, therapy is narrowed and targeted."
  ]
 },
 "explanation_fa": "درمان تجربی مننژیت باکتریال بر پایه‌ی سن و وضعیت ایمنی بیمار انتخاب می‌شود و همین تفاوت گزینه‌هاست. این بیمار سی‌ودو ساله و بدون زمینه است، یعنی در گروه بالغ سالم قرار می‌گیرد. در این گروه دو عامل غالب استرپتوکوک پنومونیه و نایسریا مننژیتیدیس هستند، و رژیم استاندارد سفالوسپورین نسل سوم به‌علاوه‌ی وانکومایسین است. وانکومایسین به‌خاطر پنوموکوک مقاوم به سفالوسپورین اضافه می‌شود، نه به‌خاطر استاف. آمپی‌سیلین صرفاً برای پوشش لیستریا مونوسیتوژنز است و فقط در سه گروه لازم می‌شود: بالای پنجاه سال، نوزادان، و افراد با نقص ایمنی سلولی یا بارداری. این بیمار در هیچ‌کدام نیست. فراموش نشود که دگزامتازون باید همزمان یا کمی پیش از اولین دوز آنتی‌بیوتیک شروع شود.",
 "explanation_en": "Empirical therapy for bacterial meningitis is chosen by age and immune status, and that is exactly what separates these options. This 32-year-old has no comorbidity, placing him in the healthy adult group where pneumococcus and meningococcus dominate, and the standard regimen is a third-generation cephalosporin plus vancomycin. Vancomycin covers cephalosporin-resistant pneumococcus, not staphylococci. Ampicillin exists purely to cover Listeria monocytogenes and is needed in only three groups: over 50, neonates, and those with impaired cellular immunity or pregnancy. This patient is in none of them. And do not forget that dexamethasone should be started with or just before the first antibiotic dose.",
 "why_fa": [
  "آمپی‌سیلین برای پوشش لیستریا است و در بالغ سالم زیر پنجاه سال اندیکاسیون ندارد.",
  "پاسخ صحیح — سفتریاکسون به‌همراه وانکومایسین رژیم استاندارد مننژیت باکتریال در بالغ سالم است.",
  "این رژیم هم آمپی‌سیلین بی‌مورد دارد و هم سفپیم که برای مننژیت بیمارستانی یا پس از جراحی است.",
  "پوشش بی‌هوازی با مترونیدازول در مننژیت باکتریال اکتسابی از جامعه جایگاهی ندارد."
 ],
 "why_en": [
  "Ampicillin covers Listeria and has no indication in a healthy adult under fifty.",
  "Correct — ceftriaxone plus vancomycin is the standard regimen for bacterial meningitis in a healthy adult.",
  "This regimen adds both unnecessary ampicillin and cefepime, which is for nosocomial or post-surgical meningitis.",
  "Anaerobic cover with metronidazole has no place in community-acquired bacterial meningitis."
 ],
 "golden_fa": "مننژیت بالغ سالم: سفتریاکسون + وانکومایسین. +آمپی‌سیلین اگر >۵۰ سال، نوزاد، نقص ایمنی یا بارداری. دگزامتازون همزمان.",
 "golden_en": "Healthy adult meningitis: ceftriaxone plus vancomycin. Add ampicillin if over 50, neonate, immunocompromised or pregnant. Dexamethasone with the first dose.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 133: Acute Bacterial Meningitis"]
}

json.dump(L, io.open('/home/user/work/infectious/lessons/L6.json', 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('infectious L6:', len(L))
