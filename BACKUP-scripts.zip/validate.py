# -*- coding: utf-8 -*-
"""Quality gate for the infectious bank. Fails loudly rather than warning."""
import json, io, re, os, sys, collections

HERE = os.path.dirname(os.path.abspath(__file__))
body = json.load(io.open(os.path.join(HERE, 'import-payload.json'), encoding='utf-8'))
qs = body['questions']
errors, warns = [], []

DIG = str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', '01234567890123456789')


def norm(s):
    s = (s or '').translate(DIG)
    s = s.replace('\u200c', '').replace('ي', 'ی').replace('ك', 'ک')
    s = re.sub(r'[^\w\s]', ' ', s)
    return re.sub(r'\s+', ' ', s).strip()


# ---- 1. structural completeness
for q in qs:
    tag = f"{q['year']}-{q['month']} q{q['question_no']}"
    for f in ('question_fa', 'question_en', 'explanation_fa', 'explanation_en',
              'golden_fa', 'golden_en', 'concept', 'chapter_fa', 'chapter_en'):
        if not q.get(f):
            errors.append(f'{tag}: empty {f}')
    for f in ('options_fa', 'options_en', 'options_why_fa', 'options_why_en'):
        v = q.get(f) or []
        if len(v) != 4:
            errors.append(f'{tag}: {f} has {len(v)} entries, expected 4')
        if any(not (x or '').strip() for x in v):
            errors.append(f'{tag}: {f} contains a blank entry')
    ci = q.get('correct_index')
    if not isinstance(ci, int) or not 0 <= ci <= 3:
        errors.append(f'{tag}: bad correct_index {ci!r}')
    m = q.get('micro') or {}
    pf, pe = m.get('points_fa') or [], m.get('points_en') or []
    if len(pf) < 10 or len(pf) != len(pe):
        errors.append(f'{tag}: micro points {len(pf)}/{len(pe)} (need >=10 and equal)')
    if not m.get('lead_fa') or not m.get('lead_en'):
        errors.append(f'{tag}: missing micro lead')
    if not q.get('refs'):
        errors.append(f'{tag}: no reference')

# ---- 2. the correct option's rationale must actually mark it correct
for q in qs:
    tag = f"{q['year']}-{q['month']} q{q['question_no']}"
    why = (q.get('options_why_fa') or [''] * 4)[q['correct_index']]
    if 'صحیح' not in why and 'پاسخ' not in why:
        errors.append(f'{tag}: correct option rationale does not mark it correct')
    for i, w in enumerate(q.get('options_why_fa') or []):
        if i != q['correct_index'] and w.startswith('پاسخ صحیح'):
            errors.append(f'{tag}: distractor {i} is labelled correct')

# ---- 2b. no distractor may be conceded as also-correct
# A rationale that calls a wrong option "valid/correct/right" means the question
# has two defensible answers. That is the single most damaging defect in a
# question bank, so it is an error rather than a warning.
# A concession is only a defect when nothing takes it back. "The drug is right
# but the dose is wrong" is a legitimate rejection; "this is also a valid answer"
# is not. So we require a rejection cue somewhere after the concession.
CONCEDE = ('رژیم درستی است', 'گزینه‌ی درستی است', 'هم درست است', 'نیز صحیح است',
           'هم صحیح است', 'درست است', 'صحیح است', 'قابل قبول است', 'مؤثر است')
REJECT = ('ولی', 'اما', 'نیست', 'نادرست', 'اشتباه', 'غلط', 'بجز', 'کافی نیست',
          'توصیه نمی', 'بیش‌درمانی', 'خطرناک', 'نه ', 'بی‌مورد', 'کنترااندیکه',
          'ناکافی', 'رد می‌شود', 'انتخاب اول نیست', 'ترجیح', 'به‌ندرت', 'پایین')
for q in qs:
    tag = f"{q['year']}-{q['month']} q{q['question_no']}"
    for i, w in enumerate(q.get('options_why_fa') or []):
        if i == q['correct_index']:
            continue
        for c in CONCEDE:
            # word-boundary-ish: "نادرست است" must not match "درست است",
            # and "غیرصحیح" must not match "صحیح"
            m = re.search(r'(?<![\u0600-\u06FF])' + re.escape(c), w)
            if not m:
                continue
            pos = m.start()
            tail = w[pos:]
            if not any(r in tail for r in REJECT):
                errors.append(f'{tag}: distractor {i} conceded as correct with no rebuttal ("{c}")')
            break

# ---- 3. no duplicate questions (exact and near)
seen = {}
for q in qs:
    k = norm(q['question_fa'])
    tag = f"{q['year']}-{q['month']} q{q['question_no']}"
    if k in seen:
        errors.append(f'{tag}: exact duplicate of {seen[k]}')
    seen[k] = tag

keys = list(seen)


def tri(s):
    return {s[i:i + 3] for i in range(len(s) - 2)}


tris = {k: tri(k) for k in keys}
for i in range(len(keys)):
    for j in range(i + 1, len(keys)):
        a, b = tris[keys[i]], tris[keys[j]]
        if not a or not b:
            continue
        ov = len(a & b) / min(len(a), len(b))
        if ov >= 0.80:
            warns.append(f'near-duplicate {ov:.2f}: {seen[keys[i]]} vs {seen[keys[j]]}')

# ---- 4. duplicate option sets within a question
for q in qs:
    tag = f"{q['year']}-{q['month']} q{q['question_no']}"
    o = [norm(x) for x in q['options_fa']]
    if len(set(o)) != 4:
        errors.append(f'{tag}: repeated options')

# ---- 5. plausible ages
for q in qs:
    tag = f"{q['year']}-{q['month']} q{q['question_no']}"
    for m in re.finditer(r'(\d{1,3})\s*ساله', q['question_fa'].translate(DIG)):
        a = int(m.group(1))
        if a > 100 or a == 0:
            errors.append(f'{tag}: implausible age {a}')

# ---- 6. no broken glyphs / control chars
for q in qs:
    tag = f"{q['year']}-{q['month']} q{q['question_no']}"
    blob = q['question_fa'] + ' '.join(q['options_fa']) + q['explanation_fa']
    if '\x00' in blob or '□' in blob or '\ufffd' in blob:
        errors.append(f'{tag}: broken glyph')

# ---- 7. English side complete
for q in qs:
    tag = f"{q['year']}-{q['month']} q{q['question_no']}"
    if not re.search(r'[A-Za-z]', q['question_en'] or ''):
        errors.append(f'{tag}: English stem is not English')
    for i, o in enumerate(q.get('options_en') or []):
        if not re.search(r'[A-Za-z]', o):
            errors.append(f'{tag}: English option {i} is not English')

# ---- 8. answer-key distribution sanity
dist = collections.Counter(q['correct_index'] for q in qs)
sit = collections.Counter(f"{q['year']}-{q['month']}" for q in qs)
src = collections.Counter(q.get('key_source') for q in qs)
chap = collections.Counter(q['chapter_fa'] for q in qs)

print(f'questions: {len(qs)}')
print(f'sittings ({len(sit)}): ' + ', '.join(f'{k}={v}' for k, v in sorted(sit.items())))
print(f'chapters ({len(chap)}): ' + ', '.join(f'{k}={v}' for k, v in chap.most_common()))
print(f'answer spread: ' + ', '.join(f'{k}={dist[k]}' for k in range(4)))
print(f'key source: ' + ', '.join(f'{k}={v}' for k, v in src.items()))
print(f'bilingual: {sum(1 for q in qs if q["question_en"] and q["explanation_en"])}/{len(qs)}')
print(f'micro lessons: {sum(1 for q in qs if q.get("micro"))}/{len(qs)}')

if warns:
    print(f'\n{len(warns)} warning(s):')
    for w in warns[:20]:
        print('  ⚠️ ', w)
if errors:
    print(f'\n{len(errors)} ERROR(s):')
    for e in errors[:40]:
        print('  ❌', e)
    sys.exit(1)
print('\n✅ all checks passed')
