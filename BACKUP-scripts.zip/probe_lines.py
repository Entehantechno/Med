# -*- coding: utf-8 -*-
"""Print the printed-order digits of specific book lines, found by letter probe.

Usage: probe_lines.py <first-page> <last-page> <persian-letter-probe> ...
The probe is matched against the line's letters only, so mirrored digits and
stray spaces inside the extracted text cannot hide the line.
"""
import re, sys, collections
import pdfplumber

SRC = '/home/user/uploads/بیماری عفونی.pdf'


def letters(s):
    s = re.sub(r'[\u0660-\u0669\u06F0-\u06F9]', '', s or '')
    return re.sub(r'[^\u0600-\u06FF]', '', s)


def main():
    p0, p1 = int(sys.argv[1]), int(sys.argv[2])
    probes = [letters(a) for a in sys.argv[3:]]
    with pdfplumber.open(SRC) as pdf:
        for pno in range(p0, p1 + 1):
            page = pdf.pages[pno - 1]
            rows = collections.defaultdict(list)
            for c in page.chars:
                rows[round(c['top'])].append(c)
            for top in sorted(rows):
                cs = sorted(rows[top], key=lambda c: c['x0'])
                text = ''.join(c['text'] for c in cs)[::-1]
                key = letters(text)
                if any(pr and pr in key for pr in probes):
                    digits = ''.join(c['text'] for c in cs if c['text'].isdigit())
                    print(f'p{pno} digits={digits!r}')
                    print(f'    {text}')


if __name__ == '__main__':
    main()
