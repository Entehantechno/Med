# -*- coding: utf-8 -*-
"""Infectious micro-lessons, batch 5 — Shahrivar-1400 (items 122-130).
Reference: Harrison's Principles of Internal Medicine, 21st ed."""
import json, io
L = {}

L["1400-06:122"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "ایمنی کامل + آخرین دوز کمتر از ۵ سال = فقط مراقبت از زخم. واکسن و ایمونوگلوبولین لازم نیست.",
  "lead_en": "Full immunity plus a booster under five years ago means wound care only; no vaccine, no immunoglobulin.",
  "points_fa": [
   "پیشگیری کزاز دو متغیر دارد: سابقه‌ی واکسیناسیون بیمار و تمیز یا آلوده بودن زخم.",
   "زخم تمیز یعنی سطحی، تازه و بدون آلودگی به خاک، مدفوع یا بزاق.",
   "زخم آلوده شامل زخم عمیق، له‌شده، سوختگی، سرمازدگی و زخم آلوده به خاک است.",
   "در فرد با سه دوز واکسن یا بیشتر: زخم تمیز تا ده سال یادآور نمی‌خواهد.",
   "در همان فرد: زخم آلوده تا پنج سال از آخرین دوز یادآور نمی‌خواهد.",
   "ایمونوگلوبولین کزاز فقط برای زخم آلوده در فرد با کمتر از سه دوز یا سابقه‌ی نامعلوم است.",
   "این بیمار سری کامل کودکی و یادآور سه سال پیش دارد، پس هر دو آستانه رعایت شده است.",
   "کلستریدیوم تتانی بی‌هوازی اجباری است و در بافت زنده و اکسیژن‌دار رشد نمی‌کند.",
   "بافت نکروزه و جسم خارجی همان محیط بی‌اکسیژن لازم برای جوانه زدن اسپور را می‌سازند.",
   "پس دبریدمان و شست‌وشو صرفاً بهداشت نیست؛ خودش یک اقدام پیشگیرانه‌ی واقعی است.",
   "توکسین کزاز مهار نورون‌های مهاری را از بین می‌برد و اسپاسم و تریسموس می‌دهد.",
   "پس از هر زخم آلوده، وضعیت واکسیناسیون را بپرسید — نپرسیدن شایع‌ترین خطاست."
  ],
  "points_en": [
   "Tetanus prophylaxis depends on two variables: the vaccination history and whether the wound is clean.",
   "A clean wound is superficial, fresh and free of soil, faeces or saliva.",
   "Dirty wounds include deep, crushed, burnt or frostbitten tissue and soil-contaminated wounds.",
   "With three or more prior doses, a clean wound needs no booster for ten years.",
   "In the same person, a dirty wound needs no booster for five years since the last dose.",
   "Tetanus immunoglobulin is only for a dirty wound in someone with fewer than three doses or unknown history.",
   "This patient completed the childhood series and had a booster three years ago, clearing both thresholds.",
   "Clostridium tetani is an obligate anaerobe and cannot grow in living, oxygenated tissue.",
   "Necrotic tissue and foreign bodies create exactly the anaerobic niche the spores need to germinate.",
   "So debridement and irrigation are not mere hygiene; they are genuine prophylaxis.",
   "Tetanus toxin blocks inhibitory neurons, producing spasm and trismus.",
   "Always ask about vaccination status after a dirty wound; failing to ask is the commonest error."
  ]
 },
 "explanation_fa": "دو چیز را باید همزمان بسنجید: وضعیت ایمنی بیمار و نوع زخم. این بیمار سری کامل واکسن کودکی را دارد و یادآورش هم در هجده سالگی، یعنی سه سال پیش، زده شده. قاعده روشن است: در فرد با سه دوز یا بیشتر، اگر زخم آلوده باشد تا پنج سال و اگر تمیز باشد تا ده سال از آخرین دوز نیازی به یادآور نیست. سه سال از هر دو آستانه کمتر است، پس واکسن لازم نیست. ایمونوگلوبولین هم فقط برای زخم آلوده در فردی است که ایمنی‌اش ناقص یا نامعلوم است، که اینجا صدق نمی‌کند. آنچه می‌ماند و در هر زخمی واجب است، مراقبت از خود زخم است: شست‌وشوی فراوان و برداشتن بافت نکروزه. نکته‌ی پاتوفیزیولوژیک: کلستریدیوم تتانی بی‌هوازی اجباری است و بافت مرده همان محیط بی‌اکسیژنی را می‌سازد که برای جوانه زدن اسپور لازم است.",
 "explanation_en": "Two things must be assessed together: the patient's immune status and the nature of the wound. This man completed the childhood series and had a booster at eighteen, three years ago. The rule is clear: with three or more doses, a dirty wound needs no booster within five years and a clean wound none within ten. Three years clears both thresholds, so no vaccine is required. Immunoglobulin is reserved for a dirty wound in someone whose immunity is incomplete or unknown, which is not the case here. What remains, and is mandatory for every wound, is care of the wound itself: copious irrigation and removal of necrotic tissue. The pathophysiology explains why: Clostridium tetani is an obligate anaerobe, and dead tissue creates precisely the oxygen-free niche its spores need to germinate.",
 "why_fa": [
  "یادآور واکسن وقتی لازم است که بیش از پنج سال از آخرین دوز در زخم آلوده گذشته باشد؛ اینجا فقط سه سال گذشته.",
  "ترکیب واکسن و ایمونوگلوبولین برای فرد با ایمنی ناقص یا نامعلوم است، نه کسی که سری کامل و یادآور اخیر دارد.",
  "ایمونوگلوبولین به‌تنهایی هیچ‌گاه رژیم صحیح نیست و در این بیمار با ایمنی کامل اصلاً اندیکاسیون ندارد.",
  "پاسخ صحیح — با ایمنی کامل و فاصله‌ی سه‌ساله، تنها اقدام لازم شست‌وشو و دبریدمان زخم است."
 ],
 "why_en": [
  "A booster is needed when more than five years have passed for a dirty wound; only three years have passed here.",
  "Vaccine plus immunoglobulin is for incomplete or unknown immunity, not for someone with a full series and recent booster.",
  "Immunoglobulin alone is never a correct regimen and has no indication in a fully immunised patient.",
  "Correct — with full immunity and a three-year interval, wound irrigation and debridement are all that is required."
 ],
 "golden_fa": "۳ دوز یا بیشتر: زخم تمیز تا ۱۰ سال، زخم آلوده تا ۵ سال یادآور نمی‌خواهد. TIG فقط برای ایمنی ناقص.",
 "golden_en": "Three or more doses: no booster for 10 years (clean) or 5 years (dirty). TIG only for incomplete immunity.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 148: Tetanus"]
}

L["1400-06:123"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "FUO: تب >۳۸.۳ بیش از ۳ هفته بدون تشخیص. غربالگری اول با آزمون‌های پربازده، نه دی‌دایمر.",
  "lead_en": "FUO means fever above 38.3 °C for over three weeks without a diagnosis. Screen with high-yield tests, not D-dimer.",
  "points_fa": [
   "تعریف کلاسیک تب با منشأ نامعلوم: دمای بالای ۳۸.۳ درجه، بیش از سه هفته، بدون تشخیص پس از ارزیابی اولیه.",
   "سه دسته‌ی بزرگ علل: عفونت، بدخیمی و بیماری‌های التهابی یا کلاژن-واسکولار.",
   "در ایران سل و بروسلوز سهم بزرگی از علل عفونی FUO دارند.",
   "کشت خون سه‌نوبته برای اندوکاردیت با کشت منفی و باکتریمی مخفی ضروری است.",
   "کشت باید پیش از شروع هر آنتی‌بیوتیکی گرفته شود، وگرنه بازده به‌شدت افت می‌کند.",
   "گرافی قفسه سینه سل، لنفوم مدیاستن، آبسه و ساركوئیدوز را غربال می‌کند.",
   "آنزیم‌های کبدی پربازده‌اند: هپاتیت گرانولوماتو، سل منتشر و لنفوم اغلب فقط با اختلال خفیف کبدی بروز می‌کنند.",
   "ESR و CRP جهت می‌دهند اما اختصاصی نیستند و به‌تنهایی تشخیص نمی‌سازند.",
   "دی‌دایمر آزمون رد ترومبوآمبولی است و در احتمال بالینی پایین فقط مثبت کاذب می‌سازد.",
   "مثبت شدن دی‌دایمر در بیمار FUO زنجیره‌ای از تصویربرداری غیرضروری راه می‌اندازد.",
   "درمان تجربی کورتون یا آنتی‌بیوتیک پیش از تشخیص، تصویر را مخدوش می‌کند و توصیه نمی‌شود.",
   "اگر ارزیابی اولیه منفی بماند، گام بعدی CT شکم و لگن و سپس PET-CT است."
  ],
  "points_en": [
   "Classic FUO: temperature above 38.3 °C, longer than three weeks, undiagnosed after initial evaluation.",
   "Three broad categories: infection, malignancy, and inflammatory or connective-tissue disease.",
   "In Iran, tuberculosis and brucellosis account for a large share of infectious FUO.",
   "Three sets of blood cultures are essential for culture-negative endocarditis and occult bacteraemia.",
   "Cultures must be drawn before any antibiotic, or the yield falls sharply.",
   "The chest film screens for tuberculosis, mediastinal lymphoma, abscess and sarcoidosis.",
   "Liver enzymes are high-yield: granulomatous hepatitis, miliary TB and lymphoma often show only mild derangement.",
   "ESR and CRP give direction but are non-specific and never diagnostic alone.",
   "D-dimer is a rule-out test for thromboembolism and produces false positives when clinical probability is low.",
   "A positive D-dimer in an FUO patient triggers a cascade of unnecessary imaging.",
   "Empirical steroids or antibiotics before a diagnosis obscure the picture and are discouraged.",
   "If the initial work-up is negative, the next steps are CT of abdomen and pelvis, then PET-CT."
  ]
 },
 "explanation_fa": "این بیمار تعریف کلاسیک تب با منشأ نامعلوم را دارد: تب بالای ۳۸.۳ درجه، بیش از سه هفته و بدون تشخیص پس از ارزیابی اولیه. سؤال می‌پرسد کدام آزمایش در گام اول جایی ندارد، پس باید بدانیم غربالگری استاندارد چیست. کشت خون سه‌نوبته برای اندوکاردیت و باکتریمی مخفی ضروری است. گرافی قفسه سینه سل، لنفوم مدیاستن و آبسه را غربال می‌کند. آنزیم‌های کبدی هم بسیار پربازده‌اند، چون هپاتیت گرانولوماتو، سل منتشر، بروسلوز و لنفوم همگی می‌توانند تنها با اختلال خفیف کبدی خودشان را نشان دهند. اما دی‌دایمر یک آزمون غیراختصاصی برای رد ترومبوآمبولی است و در بیماری با احتمال بالینی پایین، فقط منجر به تصویربرداری غیرضروری می‌شود.",
 "explanation_en": "This patient meets the classic definition of fever of unknown origin: above 38.3 °C, for more than three weeks, undiagnosed after initial assessment. The question asks which test has no place in the first round, so we need to know the standard screen. Three sets of blood cultures are essential for endocarditis and occult bacteraemia. The chest film screens for tuberculosis, mediastinal lymphoma and abscess. Liver enzymes are also high-yield, because granulomatous hepatitis, miliary TB, brucellosis and lymphoma can all declare themselves through nothing more than mild derangement. D-dimer, by contrast, is a non-specific rule-out test for thromboembolism; in a patient with low clinical probability it only leads to unnecessary imaging.",
 "why_fa": [
  "کشت خون سه‌نوبته پایه‌ی ارزیابی FUO است و اندوکاردیت و باکتریمی مخفی را غربال می‌کند.",
  "گرافی قفسه سینه ارزان و پربازده است و سل، لنفوم مدیاستن و آبسه را نشان می‌دهد.",
  "تست‌های کبدی در بسیاری از علل FUO تنها ناهنجاری آزمایشگاهی هستند و حذفشان خطاست.",
  "پاسخ صحیح — دی‌دایمر برای رد ترومبوآمبولی است و در ارزیابی اولیه‌ی FUO نقشی ندارد."
 ],
 "why_en": [
  "Three sets of blood cultures are the backbone of FUO work-up, screening for endocarditis and occult bacteraemia.",
  "The chest film is cheap and high-yield, revealing tuberculosis, mediastinal lymphoma and abscess.",
  "Liver tests are the only laboratory abnormality in many FUO causes, so omitting them is a mistake.",
  "Correct — D-dimer is a thromboembolism rule-out test and has no role in the initial FUO evaluation."
 ],
 "golden_fa": "FUO = >۳۸.۳ + >۳ هفته + بدون تشخیص. اول: کشت خون ×۳، CXR، تست کبدی، ESR/CRP.",
 "golden_en": "FUO equals above 38.3 °C plus over three weeks plus undiagnosed. First: 3 blood cultures, CXR, LFTs, ESR/CRP.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 21: Fever of Unknown Origin"]
}

L["1400-06:124"] = {
 "style": "case", "difficulty": "hard",
 "micro": {
  "lead_fa": "آب شیرین + شکست سفالکسین = آئروموناس. آب شور + سیروز = ویبریو وولنیفیکوس.",
  "lead_en": "Fresh water plus cephalexin failure means Aeromonas. Salt water plus cirrhosis means Vibrio vulnificus.",
  "points_fa": [
   "سلولیت معمولی را استرپتوکوک پیوژن و استافیلوکوک اورئوس حساس به متی‌سیلین می‌سازند.",
   "سفالکسین سفالوسپورین نسل اول است و دقیقاً همین دو عامل را پوشش می‌دهد.",
   "پس شکست درمان با سفالکسین یعنی عامل بیماری خارج از این پوشش است.",
   "همین استدلال به‌تنهایی استاف اورئوس و استرپتوکوک پیوژن را از گزینه‌ها حذف می‌کند.",
   "آئروموناس هیدروفیلا در آب شیرین زندگی می‌کند: رودخانه، دریاچه، مرداب و زالوی طبی.",
   "آئروموناس بتالاکتاماز می‌سازد و به پنی‌سیلین و سفالوسپورین نسل اول ذاتاً مقاوم است.",
   "درمان آئروموناس فلوروکینولون یا سفالوسپورین نسل سوم یا کوتریموکسازول است.",
   "ویبریو وولنیفیکوس آب شور گرم می‌خواهد، نه رودخانه.",
   "ویبریو وولنیفیکوس تقریباً همیشه در سیروز یا اضافه‌بار آهن دیده می‌شود.",
   "تابلوی ویبریو وولنیفیکوس برق‌آسا است: بولای هموراژیک، سپسیس و مرگ ظرف ساعت‌ها.",
   "در سلولیت مقاوم به درمان، همیشه بپرسید بیمار کجا و در چه آبی بوده است.",
   "افتراق دیگر: مایکوباکتریوم مارینوم آکواریوم و ندول آرام، نه سلولیت وسیع حاد."
  ],
  "points_en": [
   "Ordinary cellulitis is caused by Streptococcus pyogenes and methicillin-sensitive Staphylococcus aureus.",
   "Cephalexin is a first-generation cephalosporin and covers exactly those two organisms.",
   "So failure on cephalexin means the pathogen lies outside that cover.",
   "That reasoning alone eliminates S. aureus and S. pyogenes from the options.",
   "Aeromonas hydrophila lives in fresh water: rivers, lakes, marshes and medicinal leeches.",
   "Aeromonas produces beta-lactamase and is intrinsically resistant to penicillins and first-generation cephalosporins.",
   "Treat Aeromonas with a fluoroquinolone, a third-generation cephalosporin or co-trimoxazole.",
   "Vibrio vulnificus needs warm salt water, not a river.",
   "Vibrio vulnificus is almost always seen in cirrhosis or iron overload.",
   "Its presentation is fulminant: haemorrhagic bullae, sepsis and death within hours.",
   "In treatment-refractory cellulitis, always ask where and in what water the patient has been.",
   "One more contrast: Mycobacterium marinum means an aquarium and an indolent nodule, not acute spreading cellulitis."
  ]
 },
 "explanation_fa": "دو سرنخ سؤال را حل می‌کنند: آب شیرین و شکست درمان. سفالکسین یک سفالوسپورین نسل اول است و دقیقاً همان دو عاملی را پوشش می‌دهد که سلولیت معمولی می‌سازند، یعنی استافیلوکوک اورئوس حساس به متی‌سیلین و استرپتوکوک پیوژن. پس اگر بیمار بهبود نیافته، منطقاً عامل بیماری باید چیزی خارج از این پوشش باشد و همین به‌تنهایی دو گزینه را حذف می‌کند. حالا بین دو باکتری آبزی باقی‌مانده انتخاب کنید: آئروموناس هیدروفیلا ساکن آب شیرین است، در حالی که ویبریو وولنیفیکوس آب شور گرم می‌خواهد و تقریباً همیشه در بیمار سیروتیک دیده می‌شود. صورت سؤال صریحاً می‌گوید رودخانه و بیمار هم زمینه‌ای ندارد، پس آئروموناس پاسخ است.",
 "explanation_en": "Two clues solve this: fresh water and treatment failure. Cephalexin is a first-generation cephalosporin covering precisely the two organisms that cause ordinary cellulitis, methicillin-sensitive S. aureus and S. pyogenes. If the patient has not improved, the pathogen must lie outside that cover, which eliminates two options outright. Now choose between the two waterborne organisms: Aeromonas hydrophila inhabits fresh water, whereas Vibrio vulnificus requires warm salt water and is almost always seen in a cirrhotic host. The stem specifies a river and gives no comorbidity, so Aeromonas is the answer.",
 "why_fa": [
  "ویبریو وولنیفیکوس آب شور گرم و میزبان سیروتیک می‌خواهد و تابلویی بسیار برق‌آساتر از این بیمار دارد.",
  "استاف اورئوس حساس به متی‌سیلین با سفالکسین پوشش داده می‌شود، پس نمی‌تواند علت شکست درمان باشد.",
  "پاسخ صحیح — آئروموناس هیدروفیلا باکتری آب شیرین است و به سفالوسپورین نسل اول ذاتاً مقاوم می‌باشد.",
  "استرپتوکوک پیوژن هم کاملاً در پوشش سفالکسین است و با آن بهبود می‌یافت."
 ],
 "why_en": [
  "Vibrio vulnificus requires warm salt water and a cirrhotic host, and presents far more fulminantly than this patient.",
  "Methicillin-sensitive S. aureus is covered by cephalexin, so it cannot explain the treatment failure.",
  "Correct — Aeromonas hydrophila is a fresh-water organism intrinsically resistant to first-generation cephalosporins.",
  "Streptococcus pyogenes is fully covered by cephalexin and would have responded."
 ],
 "golden_fa": "رودخانه = آئروموناس • آب شور + سیروز = ویبریو وولنیفیکوس • آکواریوم = M. marinum.",
 "golden_en": "River means Aeromonas • salt water plus cirrhosis means V. vulnificus • aquarium means M. marinum.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 122: Skin and Soft Tissue Infections"]
}

L["1400-06:125"] = {
 "style": "case", "difficulty": "hard",
 "micro": {
  "lead_fa": "بروسلوز در بارداری: داکسی‌سایکلین و آمینوگلیکوزید ممنوع. ریفامپین + کوتریموکسازول.",
  "lead_en": "Brucellosis in pregnancy: doxycycline and aminoglycosides are contraindicated. Use rifampin plus co-trimoxazole.",
  "points_fa": [
   "بروسلوز از شیر و لبنیات غیرپاستوریزه یا تماس شغلی با دام منتقل می‌شود.",
   "استان‌های مرکزی و غربی ایران، از جمله چهارمحال و بختیاری، آندمیک محسوب می‌شوند.",
   "تابلو مبهم است: تب موجی، تعریق شبانه، ضعف، درد مفاصل و کمردرد.",
   "کمردرد در بروسلوز اغلب از ساکروایلییت یا اسپوندیلیت می‌آید و شایع‌ترین عارضه‌ی موضعی است.",
   "تیتر رایت ۱/۱۶۰ یا بالاتر در زمینه‌ی بالینی مناسب معنادار است.",
   "تست 2ME آنتی‌بادی IgG را می‌سنجد و مثبت بودنش به نفع عفونت فعال یا مزمن است.",
   "بروسلا باکتری داخل‌سلولی است، پس درمان باید همیشه دودارویی و طولانی باشد.",
   "تک‌دارو میزان عود را به‌شدت بالا می‌برد؛ حداقل شش هفته درمان لازم است.",
   "رژیم استاندارد در بالغ غیرباردار: داکسی‌سایکلین به‌علاوه‌ی ریفامپین یا استرپتومایسین.",
   "در بارداری تتراسایکلین‌ها ممنوع‌اند: رسوب در دندان و استخوان جنین و اختلال رشد.",
   "آمینوگلیکوزیدها هم به‌دلیل سمیت گوش داخلی جنین کنار گذاشته می‌شوند.",
   "پس رژیم ایمن در بارداری ریفامپین به‌علاوه‌ی کوتریموکسازول است.",
   "کوتریموکسازول را نزدیک زایمان قطع کنید تا خطر کرن‌ایکتروس نوزادی ایجاد نشود.",
   "بروسلوز درمان‌نشده در بارداری خطر سقط و زایمان زودرس را بالا می‌برد."
  ],
  "points_en": [
   "Brucellosis is acquired from unpasteurised dairy or occupational contact with livestock.",
   "Central and western provinces of Iran, including Chaharmahal-Bakhtiari, are endemic.",
   "The presentation is vague: undulant fever, night sweats, weakness, arthralgia and back pain.",
   "Back pain usually reflects sacroiliitis or spondylitis, the commonest focal complication.",
   "A Wright titre of 1/160 or higher is meaningful in the right clinical context.",
   "The 2ME test measures IgG and its positivity favours active or chronic infection.",
   "Brucella is intracellular, so treatment must always be dual-agent and prolonged.",
   "Monotherapy sharply increases relapse; at least six weeks of therapy is required.",
   "Standard regimen in non-pregnant adults: doxycycline plus rifampin or streptomycin.",
   "In pregnancy tetracyclines are contraindicated: deposition in fetal teeth and bone with growth impairment.",
   "Aminoglycosides are also avoided because of fetal inner-ear toxicity.",
   "The safe regimen in pregnancy is therefore rifampin plus co-trimoxazole.",
   "Stop co-trimoxazole near term to avoid neonatal kernicterus.",
   "Untreated brucellosis in pregnancy increases the risk of miscarriage and preterm birth."
  ]
 },
 "explanation_fa": "تشخیص بروسلوز است: منطقه‌ی آندمیک، تب طولانی، کمردرد که به ساکروایلییت بروسلایی مشکوک است و تیتر رایت و 2ME مثبت. درمان استاندارد بروسلوز همیشه دودارویی است، چون باکتری داخل‌سلولی است و تک‌دارو میزان عود را به‌شدت بالا می‌برد؛ این گزینه‌ی ریفامپین تنها را حذف می‌کند. رژیم معمول داکسی‌سایکلین به‌علاوه‌ی ریفامپین یا استرپتومایسین است، اما اینجا بیمار باردار است و همین همه‌چیز را عوض می‌کند: تتراسایکلین‌ها در بارداری ممنوع‌اند چون در دندان و استخوان جنین رسوب می‌کنند، و آمینوگلیکوزیدها هم به‌خاطر سمیت گوش جنین کنار می‌روند. پس ترکیب ایمن و مؤثر، ریفامپین به‌علاوه‌ی کوتریموکسازول است.",
 "explanation_en": "The diagnosis is brucellosis: an endemic area, prolonged fever, back pain suggesting brucellar sacroiliitis, and positive Wright and 2ME titres. Treatment is always dual-agent because the organism is intracellular and monotherapy greatly increases relapse, which rules out rifampin alone. The usual regimen is doxycycline plus rifampin or streptomycin, but this patient is pregnant and that changes everything: tetracyclines are contraindicated because they deposit in fetal teeth and bone, and aminoglycosides are avoided for fetal ototoxicity. The safe, effective combination is therefore rifampin plus co-trimoxazole.",
 "why_fa": [
  "کوتریموکسازول به‌تنهایی تک‌دارو است و در بروسلوز میزان عود را به‌شدت بالا می‌برد.",
  "داکسی‌سایکلین در بارداری ممنوع است؛ در دندان و استخوان جنین رسوب می‌کند و رشد را مختل می‌سازد.",
  "ریفامپین به‌تنهایی هم تک‌دارو است و برای بروسلوز هرگز کافی نیست.",
  "پاسخ صحیح — ترکیب دودارویی ایمن در بارداری، کوتریموکسازول به‌همراه ریفامپین است."
 ],
 "why_en": [
  "Co-trimoxazole alone is monotherapy and markedly increases relapse in brucellosis.",
  "Doxycycline is contraindicated in pregnancy; it deposits in fetal teeth and bone and impairs growth.",
  "Rifampin alone is also monotherapy and is never sufficient for brucellosis.",
  "Correct — the safe dual regimen in pregnancy is co-trimoxazole plus rifampin."
 ],
 "golden_fa": "بروسلوز = همیشه دودارویی ≥۶ هفته. بارداری: داکسی و آمینوگلیکوزید ممنوع ← ریفامپین + کوتریموکسازول.",
 "golden_en": "Brucellosis is always dual therapy for six weeks or more. In pregnancy avoid doxycycline and aminoglycosides: use rifampin plus co-trimoxazole.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 169: Brucellosis"]
}

L["1400-06:126"] = {
 "style": "recall", "difficulty": "medium",
 "micro": {
  "lead_fa": "CD4 < ۲۰۰ → کوتریموکسازول برای PCP. همان دارو زیر ۱۰۰ توکسوپلاسما را هم می‌پوشاند.",
  "lead_en": "CD4 below 200 means co-trimoxazole for PCP; the same drug also covers toxoplasmosis below 100.",
  "points_fa": [
   "پروفیلاکسی در HIV بر پایه‌ی شمارش CD4 پله‌پله اضافه می‌شود.",
   "زیر ۲۰۰ سلول: پروفیلاکسی پنوموسیستیس ژیرووسی با کوتریموکسازول شروع می‌شود.",
   "پنوموسیستیس شایع‌ترین عفونت فرصت‌طلب تعریف‌کننده‌ی ایدز بوده و بدون پروفیلاکسی مرگ‌ومیر بالایی دارد.",
   "زیر ۱۰۰ سلول با سرولوژی توکسوپلاسما مثبت: همان کوتریموکسازول پوشش توکسوپلاسموز مغزی را هم می‌دهد.",
   "همین دو کاره بودن، کوتریموکسازول را به گسترده‌ترین پروفیلاکسی در HIV تبدیل کرده است.",
   "زیر ۵۰ سلول: پروفیلاکسی مایکوباکتریوم اویوم با آزیترومایسین هفتگی یا کلاریترومایسین.",
   "در آلرژی به سولفا، داپسون یا آتوواکون یا پنتامیدین استنشاقی جایگزین می‌شوند.",
   "آسیکلوویر پروفیلاکسی روتین نیست و فقط در عود مکرر هرپس تجویز می‌شود.",
   "پنی‌سیلین هیچ جایگاهی در پروفیلاکسی روتین HIV ندارد.",
   "غربالگری سل نهفته در همه‌ی بیماران HIV الزامی است؛ آستانه‌ی PPD مثبت ۵ میلی‌متر است.",
   "با شروع درمان ضدرتروویروسی و بالا رفتن پایدار CD4، پروفیلاکسی‌ها به‌ترتیب معکوس قطع می‌شوند.",
   "قطع پروفیلاکسی وقتی مجاز است که CD4 بیش از سه تا شش ماه بالای آستانه بماند."
  ],
  "points_en": [
   "HIV prophylaxis is added in steps according to the CD4 count.",
   "Below 200 cells: start co-trimoxazole against Pneumocystis jirovecii.",
   "Pneumocystis has been the commonest AIDS-defining opportunistic infection and is highly lethal without prophylaxis.",
   "Below 100 cells with positive toxoplasma serology, the same co-trimoxazole also covers cerebral toxoplasmosis.",
   "That dual role makes co-trimoxazole the broadest prophylaxis in HIV care.",
   "Below 50 cells: prophylaxis against Mycobacterium avium with weekly azithromycin or clarithromycin.",
   "For sulfa allergy, dapsone, atovaquone or inhaled pentamidine are alternatives.",
   "Acyclovir is not routine prophylaxis and is given only for frequently recurring herpes.",
   "Penicillin has no place in routine HIV prophylaxis.",
   "Screening for latent tuberculosis is mandatory in every HIV patient; the PPD threshold is 5 mm.",
   "As antiretroviral therapy raises the CD4 count durably, the prophylaxes are withdrawn in reverse order.",
   "Withdrawal is permitted once the CD4 stays above threshold for three to six months."
  ]
 },
 "explanation_fa": "پروفیلاکسی در HIV بر پایه‌ی شمارش CD4 پله‌پله اضافه می‌شود و اولین پله‌ی آن کوتریموکسازول است. زیر دویست سلول، پروفیلاکسی علیه پنوموسیستیس ژیرووسی شروع می‌شود و داروی انتخابی کوتریموکسازول است. همین دارو اگر CD4 زیر صد برود و سرولوژی توکسوپلاسما مثبت باشد، پوشش توکسوپلاسموز مغزی را هم می‌دهد؛ دو پرنده با یک سنگ، و همین آن را به گسترده‌ترین پروفیلاکسی در HIV تبدیل می‌کند. کلاریترومایسین یا آزیترومایسین برای مایکوباکتریوم اویوم است، ولی فقط زیر پنجاه سلول، یعنی پله‌ی بعدی و بسیار پایین‌تر. آسیکلوویر پروفیلاکسی روتین نیست و پنی‌سیلین هم هیچ جایگاهی ندارد.",
 "explanation_en": "HIV prophylaxis is layered on according to the CD4 count, and the first layer is co-trimoxazole. Below 200 cells, prophylaxis against Pneumocystis jirovecii begins and co-trimoxazole is the drug of choice. If the count falls below 100 with positive toxoplasma serology, the same drug also covers cerebral toxoplasmosis: two birds with one stone, which is what makes it the broadest prophylaxis in HIV. Clarithromycin or azithromycin targets Mycobacterium avium, but only below 50 cells, a much later step. Acyclovir is not routine prophylaxis, and penicillin has no role at all.",
 "why_fa": [
  "کلاریترومایسین برای مایکوباکتریوم اویوم است و فقط زیر پنجاه سلول CD4 اندیکاسیون پیدا می‌کند.",
  "پنی‌سیلین در پروفیلاکسی روتین HIV هیچ جایگاهی ندارد.",
  "آسیکلوویر فقط در عود مکرر هرپس داده می‌شود، نه به‌عنوان پروفیلاکسی استاندارد بر پایه‌ی CD4.",
  "پاسخ صحیح — کوتریموکسازول اولین پروفیلاکسی است و هم پنوموسیستیس و هم توکسوپلاسما را پوشش می‌دهد."
 ],
 "why_en": [
  "Clarithromycin targets Mycobacterium avium and is indicated only below 50 CD4 cells.",
  "Penicillin has no role in routine HIV prophylaxis.",
  "Acyclovir is given only for frequently recurring herpes, not as standard CD4-based prophylaxis.",
  "Correct — co-trimoxazole is the first prophylaxis and covers both Pneumocystis and toxoplasmosis."
 ],
 "golden_fa": "CD4 <۲۰۰ کوتریموکسازول (PCP) • <۱۰۰ همان دارو + توکسو • <۵۰ آزیترومایسین (MAC).",
 "golden_en": "CD4 under 200: co-trimoxazole (PCP) • under 100: same drug plus toxoplasma • under 50: azithromycin (MAC).",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 202: HIV Disease, opportunistic infection prophylaxis"]
}

L["1400-06:127"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "درد گوش + وزیکول در کانال + فلج فاسیال همان‌سمت = رمزی هانت. ضدویروس + کورتون، هرچه زودتر.",
  "lead_en": "Ear pain plus vesicles in the canal plus ipsilateral facial palsy is Ramsay Hunt. Give antiviral plus steroid, early.",
  "points_fa": [
   "سندرم رمزی هانت از فعال شدن مجدد ویروس واریسلا-زوستر در گانگلیون ژنیکوله ناشی می‌شود.",
   "سه‌گانه‌ی کلاسیک: درد گوش، وزیکول در کانال گوش یا لاله، و فلج محیطی عصب فاسیال همان سمت.",
   "از دست رفتن چشایی دو-سوم قدامی زبان از درگیری شاخه‌ی کوردا تیمپانی می‌آید.",
   "ممکن است هایپراکوزیس، سرگیجه و وزوز هم همراه باشد چون عصب هشتم مجاور است.",
   "فلج عصب فاسیال اینجا محیطی است، یعنی پیشانی هم درگیر می‌شود؛ این آن را از سکته جدا می‌کند.",
   "تفاوت کلیدی با بل‌پالسی ایدیوپاتیک: پیش‌آگهی بهبود کامل در رمزی هانت به‌مراتب بدتر است.",
   "بدون درمان، تنها حدود نیمی از بیماران بهبود کامل عصب فاسیال پیدا می‌کنند.",
   "درمان استاندارد ترکیبی است: ضدویروس خوراکی به‌علاوه‌ی کورتیکواستروئید.",
   "والاسیکلوویر یا آسیکلوویر یا فامسیکلوویر هر سه قابل استفاده‌اند.",
   "بیشترین بازده درمان در ۷۲ ساعت اول است، پس تشخیص سریع اهمیت حیاتی دارد.",
   "کورتیکواستروئید تنها برای بل‌پالسی ایدیوپاتیک کافی است ولی اینجا عفونت فعال را بی‌پوشش می‌گذارد.",
   "گان‌سیکلوویر داروی سیتومگالوویروس است و در VZV جایگاه درمان اول ندارد.",
   "پره‌گابالین فقط برای نورالژی پس‌هرپسی است، یعنی عارضه‌ی بعدی نه درمان بیماری.",
   "مراقبت از قرنیه در فلج فاسیال ضروری است: اشک مصنوعی و بستن پلک هنگام خواب."
  ],
  "points_en": [
   "Ramsay Hunt syndrome is reactivation of varicella-zoster virus in the geniculate ganglion.",
   "The classic triad: ear pain, vesicles in the canal or pinna, and ipsilateral peripheral facial palsy.",
   "Loss of taste over the anterior two-thirds of the tongue reflects chorda tympani involvement.",
   "Hyperacusis, vertigo and tinnitus may accompany it because the eighth nerve lies adjacent.",
   "The facial palsy is peripheral, so the forehead is involved; that separates it from a stroke.",
   "The key contrast with idiopathic Bell palsy is that full recovery is considerably less likely.",
   "Untreated, only about half of patients regain full facial nerve function.",
   "Standard treatment is combined: an oral antiviral plus a corticosteroid.",
   "Valacyclovir, acyclovir or famciclovir are all acceptable.",
   "Benefit is greatest within the first 72 hours, so prompt recognition is critical.",
   "A steroid alone suffices for idiopathic Bell palsy but leaves active viral infection uncovered here.",
   "Ganciclovir is a cytomegalovirus drug and is not first-line for VZV.",
   "Pregabalin treats post-herpetic neuralgia, a later complication, not the disease itself.",
   "Corneal care is essential in facial palsy: artificial tears and taping the lid at night."
  ]
 },
 "explanation_fa": "سه‌گانه‌ی درد گوش، وزیکول در کانال گوش و فلج صورت همان‌سمت، سندرم رمزی هانت است: فعال شدن مجدد ویروس واریسلا-زوستر در گانگلیون ژنیکوله. از دست رفتن چشایی دو-سوم قدامی زبان هم منطقی است، چون شاخه‌ی کوردا تیمپانی عصب فاسیال همان مسیر را می‌پیماید. نکته‌ی مهم افتراقی این است که این بل‌پالسی ایدیوپاتیک نیست و پیش‌آگهی بهبود کامل آن به‌مراتب بدتر است، پس درمان باید تهاجمی‌تر باشد. درمان استاندارد ترکیبی است: ضدویروس خوراکی به‌علاوه‌ی کورتیکواستروئید، و هرچه زودتر بهتر؛ بازده درمان در هفتاد و دو ساعت اول بیشترین است. کورتیکواستروئید تنها برای بل‌پالسی ایدیوپاتیک کافی است ولی اینجا عفونت فعال ویروسی را بدون پوشش می‌گذارد.",
 "explanation_en": "The triad of ear pain, vesicles in the ear canal and ipsilateral facial palsy is Ramsay Hunt syndrome: reactivation of varicella-zoster virus in the geniculate ganglion. Loss of taste over the anterior two-thirds of the tongue fits, because the chorda tympani branch of the facial nerve runs the same course. The important distinction is that this is not idiopathic Bell palsy and its prospects for full recovery are considerably worse, so treatment must be more aggressive. Standard therapy is combined: an oral antiviral plus a corticosteroid, started as early as possible, since benefit is greatest in the first 72 hours. A steroid alone suffices for idiopathic Bell palsy but would leave the active viral infection uncovered here.",
 "why_fa": [
  "کورتیکواستروئید تنها برای بل‌پالسی ایدیوپاتیک مناسب است و در رمزی هانت عفونت فعال ویروسی را بی‌پوشش می‌گذارد.",
  "گان‌سیکلوویر داروی سیتومگالوویروس است و برای واریسلا-زوستر انتخاب اول محسوب نمی‌شود.",
  "پاسخ صحیح — والاسیکلوویر به‌همراه کورتیکواستروئید، درمان استاندارد سندرم رمزی هانت است.",
  "پره‌گابالین برای نورالژی پس‌هرپسی است، یعنی عارضه‌ی دیرهنگام، نه درمان مرحله‌ی حاد."
 ],
 "why_en": [
  "A steroid alone suits idiopathic Bell palsy and leaves the active viral infection of Ramsay Hunt uncovered.",
  "Ganciclovir is a cytomegalovirus drug and is not first choice for varicella-zoster.",
  "Correct — valacyclovir plus a corticosteroid is the standard treatment of Ramsay Hunt syndrome.",
  "Pregabalin treats post-herpetic neuralgia, a late complication, not the acute illness."
 ],
 "golden_fa": "رمزی هانت = VZV در گانگلیون ژنیکوله. درمان: ضدویروس + کورتون، ترجیحاً در ۷۲ ساعت اول.",
 "golden_en": "Ramsay Hunt is VZV in the geniculate ganglion. Treat with antiviral plus steroid, ideally within 72 hours.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 192: Varicella-Zoster Virus Infections"]
}

L["1400-06:128"] = {
 "style": "case", "difficulty": "hard",
 "micro": {
  "lead_fa": "سیر دوفازی + زردی + نارسایی کلیه پس از جنگل شمال = سندرم وایل. درمان شدید: پنی‌سیلین وریدی.",
  "lead_en": "A biphasic course with jaundice and renal failure after the northern forests is Weil syndrome. Severe disease needs IV penicillin.",
  "points_fa": [
   "لپتوسپیروز زئونوز اسپیروکتی است که از ادرار حیوانات آلوده، به‌ویژه جوندگان، منتقل می‌شود.",
   "ورود از پوست خراشیده یا مخاط در تماس با آب یا خاک آلوده صورت می‌گیرد.",
   "در ایران گیلان و مازندران آندمیک‌اند و بیشترین موارد در فصل کشت برنج گزارش می‌شود.",
   "دوره‌ی کمون معمولاً یک تا دو هفته است، که با ده روز پس از سفر می‌خواند.",
   "بیماری دوفازی است و همین الگو مهم‌ترین سرنخ تشخیصی محسوب می‌شود.",
   "فاز اول سپتیسمیک: تب، لرز، سردرد شدید و میالژی که چند روز طول می‌کشد و خودبه‌خود فروکش می‌کند.",
   "فاز دوم ایمنی: بازگشت تب همراه با زردی، نارسایی کلیه، خون‌ریزی و گاهی مننژیت آسپتیک.",
   "میالژی به‌طور مشخص در ساق پا شدید است و لمس ساق دردناک می‌باشد.",
   "تزریق ملتحمه یعنی قرمزی چشم بدون ترشح چرکی، یافته‌ای بسیار کمک‌کننده است.",
   "شکل شدید بیماری سندرم وایل نام دارد: زردی، نارسایی کلیه و دیاتز خون‌ریزی‌دهنده.",
   "زردی در لپتوسپیروز اغلب بدون نکروز شدید کبدی است و آنزیم‌ها فقط کمی بالا می‌روند.",
   "بیماری خفیف با داکسی‌سایکلین خوراکی درمان می‌شود.",
   "بیماری شدید نیازمند درمان وریدی است: پنی‌سیلین G یا سفتریاکسون.",
   "پس از شروع درمان ممکن است واکنش یاریش-هرکسهایمر رخ دهد، پس بیمار باید تحت نظر باشد."
  ],
  "points_en": [
   "Leptospirosis is a spirochaetal zoonosis transmitted in the urine of infected animals, especially rodents.",
   "Entry is through abraded skin or mucosa contacting contaminated water or soil.",
   "In Iran, Gilan and Mazandaran are endemic and most cases occur in the rice-planting season.",
   "The incubation period is usually one to two weeks, fitting ten days after the trip.",
   "The illness is biphasic, and that pattern is the single most useful diagnostic clue.",
   "First, a septicaemic phase: fever, chills, severe headache and myalgia lasting days, resolving spontaneously.",
   "Second, an immune phase: recurrent fever with jaundice, renal failure, bleeding and sometimes aseptic meningitis.",
   "Myalgia is characteristically worst in the calves, which are tender to palpation.",
   "Conjunctival suffusion, red eyes without purulent discharge, is a very helpful sign.",
   "The severe form is Weil syndrome: jaundice, renal failure and a bleeding diathesis.",
   "Jaundice usually occurs without severe hepatic necrosis and transaminases rise only modestly.",
   "Mild disease is treated with oral doxycycline.",
   "Severe disease requires intravenous therapy: penicillin G or ceftriaxone.",
   "A Jarisch-Herxheimer reaction may follow the first dose, so the patient must be observed."
  ]
 },
 "explanation_fa": "الگوی دوفازی کلید تشخیص است: یک فاز سپتیسمیک با تب و میالژی که خودبه‌خود فروکش می‌کند، و سپس فاز دوم ایمنی که این بار با زردی و درگیری کلیه برمی‌گردد. این تابلوی لپتوسپیروز است و شکل شدید آن سندرم وایل نام دارد. زمینه هم کاملاً می‌خواند: جنگل مرطوب شمال ایران منطقه‌ی آندمیک است و اسپیروکت از پوست خراشیده در تماس با آب یا خاک آلوده به ادرار جوندگان وارد می‌شود. در بیماری خفیف داکسی‌سایکلین خوراکی می‌دهیم، اما این بیمار زردی و افزایش کراتینین دارد، یعنی بیماری شدید است و درمان وریدی می‌خواهد: پنی‌سیلین G یا سفتریاکسون. نکته‌ای که نباید فراموش شود: پس از شروع درمان ممکن است واکنش یاریش-هرکسهایمر رخ دهد.",
 "explanation_en": "The biphasic pattern is the diagnostic key: a septicaemic phase with fever and myalgia that settles by itself, then a second immune phase returning with jaundice and renal involvement. This is leptospirosis, and its severe form is Weil syndrome. The setting fits perfectly: the humid forests of northern Iran are endemic, and the spirochaete enters through abraded skin in contact with water or soil contaminated by rodent urine. Mild disease is treated with oral doxycycline, but this patient has jaundice and a rising creatinine, meaning severe disease requiring intravenous therapy: penicillin G or ceftriaxone. One caveat worth remembering is the Jarisch-Herxheimer reaction that may follow the first dose.",
 "why_fa": [
  "آزیترومایسین در لپتوسپیروز خفیف جایگزین قابل قبولی است ولی برای بیماری شدید با زردی و نارسایی کلیه انتخاب نمی‌شود.",
  "پاسخ صحیح — پنی‌سیلین G وریدی درمان استاندارد لپتوسپیروز شدید یا سندرم وایل است.",
  "آمپی‌سیلین در فهرست درمان استاندارد لپتوسپیروز قرار ندارد و پوشش مناسبی محسوب نمی‌شود.",
  "آموکسی‌سیلین خوراکی برای بیماری شدید با درگیری چنداُرگانی کافی نیست."
 ],
 "why_en": [
  "Azithromycin is an acceptable alternative in mild leptospirosis but is not chosen for severe disease with jaundice and renal failure.",
  "Correct — intravenous penicillin G is standard therapy for severe leptospirosis or Weil syndrome.",
  "Ampicillin is not part of the standard leptospirosis regimen and does not provide appropriate cover.",
  "Oral amoxicillin is inadequate for severe multi-organ disease."
 ],
 "golden_fa": "لپتوسپیروز دوفازی • ساق پای دردناک • تزریق ملتحمه. خفیف: داکسی خوراکی؛ شدید (وایل): پنی‌سیلین وریدی.",
 "golden_en": "Leptospirosis is biphasic with calf tenderness and conjunctival suffusion. Mild: oral doxycycline; severe (Weil): IV penicillin.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 184: Leptospirosis"]
}

L["1400-06:129"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "اسهال خونی با لکوسیت فراوان ولی بدون تب = EHEC. آنتی‌بیوتیک ممنوع؛ خطر HUS.",
  "lead_en": "Bloody diarrhoea with many leukocytes but no fever suggests EHEC. Antibiotics are contraindicated: HUS risk.",
  "points_fa": [
   "اسهال‌ها را اول به التهابی و غیرالتهابی تقسیم کنید؛ خون و لکوسیت در مدفوع نشانه‌ی التهابی بودن است.",
   "اسهال غیرالتهابی آبکی و پرحجم است و مخاط را دست‌نخورده باقی می‌گذارد.",
   "ویبریو کلرا نمونه‌ی کلاسیک غیرالتهابی است: مدفوع آب‌برنجی بدون خون و بدون لکوسیت.",
   "استافیلوکوک اورئوس مسمومیت غذایی توکسینی است که ظرف چند ساعت با استفراغ غالب بروز می‌کند.",
   "ژیاردیا تک‌یاخته‌ی روده‌ی باریک است و اسهال چرب و مزمن بدون خون می‌دهد.",
   "پس هر سه گزینه‌ی دیگر با اسهال خونی و لکوسیت فراوان نمی‌خوانند.",
   "EHEC یا اشریشیاکلی O157:H7 با توکسین شیگا مخاط کولون را آسیب می‌زند.",
   "نکته‌ی افتراقی مهم: EHEC معمولاً بدون تب یا با تب خفیف است، برخلاف شیگلا و کمپیلوباکتر.",
   "دلیلش این است که آسیب از توکسین می‌آید نه از تهاجم عمقی و پاسخ التهابی سیستمیک.",
   "منبع شایع، گوشت نیم‌پخته‌ی گاو، شیر غیرپاستوریزه و سبزی آلوده است.",
   "خطرناک‌ترین عارضه سندرم اورمیک همولیتیک است: آنمی همولیتیک، ترومبوسیتوپنی و نارسایی کلیه.",
   "آنتی‌بیوتیک در EHEC ممنوع است چون آزادسازی توکسین و خطر HUS را افزایش می‌دهد.",
   "داروهای ضدحرکتی مانند لوپرامید هم ممنوع‌اند چون زمان تماس توکسین را طولانی می‌کنند.",
   "درمان صرفاً حمایتی است: مایع‌درمانی و پایش عملکرد کلیه و شمارش پلاکت."
  ],
  "points_en": [
   "Divide diarrhoea first into inflammatory and non-inflammatory; blood and leukocytes in stool mark the inflammatory type.",
   "Non-inflammatory diarrhoea is watery and high-volume and leaves the mucosa intact.",
   "Vibrio cholerae is the classic non-inflammatory example: rice-water stool without blood or leukocytes.",
   "Staphylococcus aureus causes toxin-mediated food poisoning within hours, dominated by vomiting.",
   "Giardia is a small-bowel protozoan causing chronic fatty diarrhoea without blood.",
   "So none of the other three options fits bloody diarrhoea with abundant leukocytes.",
   "EHEC, or E. coli O157:H7, damages the colonic mucosa through Shiga toxin.",
   "An important discriminator: EHEC usually causes little or no fever, unlike Shigella and Campylobacter.",
   "That is because the injury is toxin-mediated rather than deeply invasive with a systemic response.",
   "Common sources are undercooked beef, unpasteurised milk and contaminated produce.",
   "The feared complication is haemolytic uraemic syndrome: haemolytic anaemia, thrombocytopenia and renal failure.",
   "Antibiotics are contraindicated in EHEC because they increase toxin release and HUS risk.",
   "Antimotility agents such as loperamide are also contraindicated as they prolong toxin contact.",
   "Management is purely supportive: fluids plus monitoring of renal function and platelet count."
  ]
 },
 "explanation_fa": "دو نکته را کنار هم بگذارید: اسهال خونی با لکوسیت فراوان در مدفوع، و نبودِ تب. اسهال خونی یعنی عامل مهاجم یا توکسین‌ساز است، پس سه گزینه‌ی دیگر فوراً کنار می‌روند: ویبریو کلرا اسهال آبکی بدون خون و بدون لکوسیت می‌دهد چون مخاط را دست‌نخورده باقی می‌گذارد؛ استافیلوکوک اورئوس مسمومیت غذایی توکسینی است که ظرف چند ساعت با استفراغ غالب و بدون خون بروز می‌کند؛ و ژیاردیا اسهال چرب و مزمن بدون خون می‌سازد. می‌ماند EHEC، و نبودِ تب دقیقاً همان چیزی است که آن را از شیگلا و کمپیلوباکتر جدا می‌کند: EHEC مخاط را با توکسین شیگا آسیب می‌زند نه با تهاجم عمقی. هشدار حیاتی: در شک به EHEC آنتی‌بیوتیک ندهید.",
 "explanation_en": "Put two facts side by side: bloody diarrhoea with abundant faecal leukocytes, and the absence of fever. Bloody diarrhoea means an invasive or toxin-producing organism, so the other three options fall away at once: Vibrio cholerae gives watery stool without blood or leukocytes because it leaves the mucosa intact; Staphylococcus aureus is a toxin-mediated food poisoning appearing within hours with vomiting predominating and no blood; and Giardia causes chronic fatty diarrhoea without blood. That leaves EHEC, and the absence of fever is precisely what separates it from Shigella and Campylobacter: EHEC injures the mucosa with Shiga toxin rather than by deep invasion. The critical warning: do not give antibiotics when EHEC is suspected.",
 "why_fa": [
  "پاسخ صحیح — EHEC با توکسین شیگا اسهال خونی می‌دهد و مشخصاً بدون تب یا با تب خفیف است.",
  "ویبریو کلرا اسهال آبکی و پرحجم بدون خون و بدون لکوسیت ایجاد می‌کند و مخاط را آسیب نمی‌زند.",
  "استافیلوکوک اورئوس مسمومیت غذایی توکسینی با استفراغ غالب و شروع چندساعته است، نه اسهال خونی.",
  "ژیاردیا اسهال مزمن و چرب روده‌ی باریک می‌دهد و خون و لکوسیت در مدفوع ایجاد نمی‌کند."
 ],
 "why_en": [
  "Correct — EHEC causes bloody diarrhoea via Shiga toxin and characteristically produces little or no fever.",
  "Vibrio cholerae causes high-volume watery stool without blood or leukocytes and does not damage the mucosa.",
  "Staphylococcus aureus causes toxin-mediated food poisoning with vomiting within hours, not bloody diarrhoea.",
  "Giardia causes chronic fatty small-bowel diarrhoea without blood or faecal leukocytes."
 ],
 "golden_fa": "اسهال خونی بدون تب = EHEC. آنتی‌بیوتیک و ضدحرکتی ممنوع — خطر HUS.",
 "golden_en": "Bloody diarrhoea without fever means EHEC. No antibiotics, no antimotility agents: HUS risk.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 128/160: Infectious Diarrhoea"]
}

L["1400-06:130"] = {
 "style": "recall", "difficulty": "medium",
 "micro": {
  "lead_fa": "از چهار داروی خط اول سل، فقط اتامبوتول کبد را درگیر نمی‌کند. عارضه‌اش نوریت اپتیک است.",
  "lead_en": "Of the four first-line TB drugs only ethambutol spares the liver; its toxicity is optic neuritis.",
  "points_fa": [
   "رژیم استاندارد سل چهار دارو دارد: ایزونیازید، ریفامپین، پیرازینامید و اتامبوتول.",
   "سه داروی اول همگی می‌توانند هپاتوتوکسیسیته بدهند؛ فقط اتامبوتول عملاً کبد را درگیر نمی‌کند.",
   "ایزونیازید شایع‌ترین علت هپاتیت دارویی در این رژیم است و خطرش با افزایش سن بالا می‌رود.",
   "پیرازینامید سمی‌ترین آن‌ها برای کبد است و معمولاً اولین دارویی است که حذف می‌شود.",
   "ریفامپین بیشتر الگوی کلستاتیک می‌دهد و از دو داروی دیگر کمتر هپاتوتوکسیک است.",
   "عارضه‌ی امضایی اتامبوتول نوریت اپتیک است: کاهش حدت بینایی و اختلال تمایز رنگ سبز و قرمز.",
   "این عارضه وابسته به دوز است و با قطع زودهنگام معمولاً برگشت‌پذیر می‌باشد.",
   "پیش از شروع و سپس ماهانه باید حدت بینایی و دید رنگی سنجیده شود.",
   "تعریف هپاتوتوکسیسیته: ALT بیش از سه برابر با علامت، یا بیش از پنج برابر بدون علامت.",
   "در این حالت همه‌ی داروهای هپاتوتوکسیک قطع می‌شوند تا آنزیم‌ها به پایه برگردند.",
   "اما در سل شدید یا منتشر، قطع کامل درمان خطرناک است و بیماری پیشرفت می‌کند.",
   "پس رژیم موقت و بدون سمیت کبدی ساخته می‌شود: اتامبوتول به‌علاوه‌ی فلوروکینولون و آمینوگلیکوزید.",
   "پس از نرمال شدن آنزیم‌ها، داروها یکی‌یکی و با پایش دقیق دوباره اضافه می‌شوند.",
   "پیرازینامید معمولاً پس از هپاتوتوکسیسیته شدید به رژیم برنمی‌گردد."
  ],
  "points_en": [
   "The standard TB regimen has four drugs: isoniazid, rifampin, pyrazinamide and ethambutol.",
   "The first three can all cause hepatotoxicity; only ethambutol essentially spares the liver.",
   "Isoniazid is the commonest cause of drug-induced hepatitis in this regimen and risk rises with age.",
   "Pyrazinamide is the most hepatotoxic and is usually the first drug dropped.",
   "Rifampin tends to produce a cholestatic pattern and is less hepatotoxic than the other two.",
   "Ethambutol's signature toxicity is optic neuritis: reduced acuity and loss of green-red discrimination.",
   "It is dose-dependent and usually reversible if the drug is stopped early.",
   "Visual acuity and colour vision must be checked before starting and monthly thereafter.",
   "Hepatotoxicity is defined as ALT above three times normal with symptoms, or above five times without.",
   "All hepatotoxic drugs are then stopped until the enzymes return to baseline.",
   "But in severe or disseminated tuberculosis, stopping everything is dangerous and the disease progresses.",
   "A temporary non-hepatotoxic regimen is therefore built: ethambutol plus a fluoroquinolone and an aminoglycoside.",
   "Once enzymes normalise, drugs are reintroduced one at a time with close monitoring.",
   "Pyrazinamide is usually not reintroduced after severe hepatotoxicity."
  ]
 },
 "explanation_fa": "از چهار داروی خط اول سل، سه‌تا کبد را درگیر می‌کنند و فقط یکی نه. ایزونیازید شایع‌ترین علت هپاتیت دارویی در این رژیم است و خطرش با افزایش سن بالا می‌رود. پیرازینامید سمی‌ترین آن‌ها برای کبد است و معمولاً اولین دارویی است که در هپاتوتوکسیسیته حذف می‌شود و دیگر برنمی‌گردد. ریفامپین هم می‌تواند هپاتیت کلستاتیک بدهد، هرچند کمتر. اتامبوتول تنها دارویی است که عملاً کبد را درگیر نمی‌کند؛ عارضه‌ی امضایی آن نوریت اپتیک است، نه هپاتیت. به همین دلیل وقتی بیمار سلِ شدید دچار هپاتیت دارویی می‌شود و نمی‌توان درمان را کاملاً قطع کرد، رژیم موقت و بدون سمیت کبدی از داروهایی مثل اتامبوتول به‌علاوه‌ی یک فلوروکینولون و یک آمینوگلیکوزید ساخته می‌شود.",
 "explanation_en": "Of the four first-line TB drugs, three affect the liver and one does not. Isoniazid is the commonest cause of drug-induced hepatitis in this regimen and its risk rises with age. Pyrazinamide is the most hepatotoxic and is usually the first drug removed, rarely to be reintroduced. Rifampin can also cause a cholestatic hepatitis, though less often. Ethambutol is the only one that essentially spares the liver; its signature toxicity is optic neuritis, not hepatitis. That is why, when a patient with severe tuberculosis develops drug-induced hepatitis and treatment cannot simply be stopped, a temporary non-hepatotoxic regimen is assembled from drugs such as ethambutol together with a fluoroquinolone and an aminoglycoside.",
 "why_fa": [
  "ایزونیازید شایع‌ترین علت هپاتیت دارویی در رژیم ضدسل است و در هپاتوتوکسیسیته باید قطع شود.",
  "ریفامپین می‌تواند هپاتیت کلستاتیک بدهد و جزو داروهای هپاتوتوکسیک محسوب می‌شود.",
  "پیرازینامید سمی‌ترین داروی این رژیم برای کبد است و اولین گزینه‌ی حذف در هپاتوتوکسیسیته می‌باشد.",
  "پاسخ صحیح — اتامبوتول عملاً عارضه‌ی کبدی ندارد و در رژیم موقت بدون سمیت کبدی استفاده می‌شود."
 ],
 "why_en": [
  "Isoniazid is the commonest cause of drug-induced hepatitis in the anti-TB regimen and must be stopped.",
  "Rifampin can cause cholestatic hepatitis and counts among the hepatotoxic drugs.",
  "Pyrazinamide is the most hepatotoxic drug in the regimen and the first to be withdrawn.",
  "Correct — ethambutol has virtually no hepatic toxicity and is used in the temporary non-hepatotoxic regimen."
 ],
 "golden_fa": "H، R، Z کبد را می‌زنند؛ E نه. اتامبوتول = نوریت اپتیک، پایه‌ی رژیم بدون سمیت کبدی.",
 "golden_en": "H, R and Z hit the liver; E does not. Ethambutol means optic neuritis and anchors the non-hepatotoxic regimen.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 178: Tuberculosis, drug toxicity"]
}

json.dump(L, io.open('/home/user/work/infectious/lessons/L5.json', 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('infectious L5:', len(L))
