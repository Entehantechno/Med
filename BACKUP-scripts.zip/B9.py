# -*- coding: utf-8 -*-
"""Micro-lessons, batch 9 — the urinary tract infection chapter.

Why this chapter next
---------------------
Twenty-nine questions with only two taught, and — like the tetanus block — it
is dominated by a single decision that the ministry asks over and over:

    given bacteria in the urine, do I treat or not?

Nine of the untaught questions are that one question, dressed differently: a
catheterised stroke patient, a spinal-cord-injured man, a diabetic office
worker, a pregnant woman at screening, an elderly woman with two positive
cultures. The answer is "no" in almost all of them and "yes" in exactly two
situations. So this batch teaches the RULE, not nine separate vignettes.

The rule (IDSA 2019, Asymptomatic Bacteriuria; Harrison's 21e Ch. 130):

    TREAT asymptomatic bacteriuria in only TWO groups
      1. pregnancy
      2. before an endoscopic urologic procedure with expected mucosal bleeding

    DO NOT TREAT in: healthy non-pregnant women, diabetics, the elderly,
    long-term-care residents, indwelling catheters (short or long term),
    spinal cord injury, renal transplant beyond one month, other solid organ
    transplants, non-urologic surgery.

    And the trap that catches everyone: PYURIA IS NOT AN INDICATION. White
    cells in the urine of an asymptomatic patient do not convert asymptomatic
    bacteriuria into a urinary tract infection.

The second half of the chapter is symptomatic disease: uncomplicated cystitis
(treat empirically, no culture needed), cystitis in pregnancy (culture AND
treat, with a pregnancy-safe agent), and pyelonephritis.

Two printed keys in this chapter are medically wrong and are handled explicitly
rather than taught as printed: idx 500 and idx 525. Both are documented in the
lesson text and corrected by fix_keys_uti.py.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022),
Chapter 130; IDSA Clinical Practice Guideline for the Management of
Asymptomatic Bacteriuria (2019).
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 130"
IDSA = "IDSA Clinical Practice Guideline: Asymptomatic Bacteriuria (2019)"

# The core rule, repeated verbatim across the asymptomatic-bacteriuria lessons
# so the student meets identical wording every time.
ASB_FA = [
    "«باکتریوری بدون علامت» یعنی رشد معنادار باکتری در ادرار **بدون** هیچ علامت ادراری یا سیستمیک.",
    "قاعده‌ی کلی: باکتریوری بدون علامت را **درمان نمی‌کنیم** — مگر در دو وضعیت.",
    "وضعیت اول: **بارداری** — چون خطر پیلونفریت، زایمان زودرس و وزن کم هنگام تولد را بالا می‌برد.",
    "وضعیت دوم: **پیش از اقدام اورولوژیک آندوسکوپیک** که انتظار خونریزی مخاطی می‌رود (مثل TURP یا بیوپسی مثانه).",
    "در این دو مورد درمان **پیامد را بهتر می‌کند**؛ در بقیه فقط ضرر می‌رساند.",
    "گروه‌هایی که درمان **نمی‌شوند**: زن سالم غیرباردار، دیابتی، سالمند، ساکن آسایشگاه.",
    "همچنین: سوند ادراری (کوتاه‌مدت یا بلندمدت)، آسیب نخاعی، پیوند کلیه پس از یک ماه.",
    "⚠️ مهم‌ترین تله: **پیوری (گلبول سفید در ادرار) اندیکاسیون درمان نیست.**",
    "در فرد بدون علامت، وجود چرک در ادرار، «باکتریوری بدون علامت» را به «عفونت» تبدیل نمی‌کند.",
    "چرا درمان نکنیم؟ چون مطالعات نشان داده‌اند پیامد بیمار بهتر نمی‌شود.",
    "و ضررها واقعی‌اند: مقاومت آنتی‌بیوتیکی، کولیت کلستریدیوئیدس دیفیسیل، عوارض دارویی.",
    "درمان باکتریوری بدون علامت، باکتری حساس را می‌کشد و جای آن را به باکتری مقاوم می‌دهد.",
    "پس دفعه‌ی بعد که واقعاً عفونت علامت‌دار شود، درمانش سخت‌تر خواهد بود.",
]
ASB_EN = [
    "'Asymptomatic bacteriuria' means significant bacterial growth in urine WITHOUT any urinary or systemic symptoms.",
    "The general rule: do NOT treat asymptomatic bacteriuria — except in two situations.",
    "First: PREGNANCY, because it raises the risk of pyelonephritis, preterm labour and low birth weight.",
    "Second: BEFORE an endoscopic urologic procedure where mucosal bleeding is expected (such as TURP or bladder biopsy).",
    "In those two, treatment improves outcomes; everywhere else it only causes harm.",
    "Groups NOT to treat: healthy non-pregnant women, diabetics, the elderly, long-term-care residents.",
    "Also: urinary catheters (short or long term), spinal cord injury, renal transplant beyond one month.",
    "WARNING, the biggest trap: PYURIA (white cells in the urine) is NOT an indication to treat.",
    "In an asymptomatic person, pus in the urine does not convert asymptomatic bacteriuria into an infection.",
    "Why not treat? Because trials show patient outcomes do not improve.",
    "And the harms are real: antimicrobial resistance, Clostridioides difficile colitis, drug adverse effects.",
    "Treating asymptomatic bacteriuria kills the susceptible organism and lets a resistant one take its place.",
    "So the next time a genuinely symptomatic infection occurs, it will be harder to treat.",
]

# ---------------------------------------------------------------- idx 507
add("book:507", "recall", "easy",
 "کاتتر ادراری تنها موردی است که **درمان نمی‌خواهد**؛ سه گزینه‌ی دیگر همگی اندیکاسیون دارند.",
 "The urinary catheter is the only one NOT needing treatment; the other three are all indications.",
 ASB_FA + [
  "این سؤال، فهرست استثناها را مستقیم می‌پرسد، پس باید حفظ و دقیق باشد.",
  "بارداری: درمان می‌شود — از پیلونفریت و زایمان زودرس جلوگیری می‌کند.",
  "دستکاری اورولوژیک با خونریزی مخاطی: درمان می‌شود — از باکتریمی پس از عمل جلوگیری می‌کند.",
  "پیوند کلیه: در **ماه اول** پس از پیوند، بیشتر مراکز درمان می‌کنند.",
  "ولی پس از یک ماه از پیوند، دیگر درمان توصیه **نمی‌شود**.",
  "کاتتر ادراری: **هرگز** درمان نمی‌شود، نه کوتاه‌مدت و نه بلندمدت.",
  "دلیلش ساده است: هر سوند بلندمدت عملاً صددرصد کلونیزه می‌شود.",
  "بیوفیلم روی سطح سوند تشکیل می‌شود و آنتی‌بیوتیک آن را ریشه‌کن نمی‌کند.",
  "پس درمان فقط باکتری را با گونه‌ی مقاوم‌تر عوض می‌کند و کلونیزاسیون برمی‌گردد.",
  "تنها راه واقعی حذف باکتریوری سوند، **برداشتن خود سوند** است، نه آنتی‌بیوتیک.",
 ],
 ASB_EN + [
  "This question asks the exception list directly, so it must be known precisely.",
  "Pregnancy: treat — it prevents pyelonephritis and preterm delivery.",
  "Urologic instrumentation with mucosal bleeding: treat — it prevents post-procedure bacteraemia.",
  "Renal transplant: within the FIRST MONTH most centres treat.",
  "But beyond one month post-transplant, treatment is no longer recommended.",
  "Urinary catheter: NEVER treated, whether short-term or long-term.",
  "The reason is simple: essentially 100% of long-term catheters become colonised.",
  "A biofilm forms on the catheter surface and antibiotics cannot eradicate it.",
  "So treatment merely swaps the organism for a more resistant one and colonisation returns.",
  "The only real way to clear catheter bacteriuria is to REMOVE THE CATHETER, not to give antibiotics.",
 ],
 "این سؤال فهرست استثناها را مستقیم می‌پرسد. بارداری و دستکاری اورولوژیک، دو اندیکاسیون کلاسیک درمان‌اند؛ پیوند کلیه در ماه اول هم در بیشتر مراکز درمان می‌شود. اما **کاتتر ادراری هرگز درمان نمی‌شود** و دلیلش آموزنده است: هر سوند بلندمدت عملاً به‌طور صددرصد کلونیزه می‌شود و روی سطح آن **بیوفیلم** می‌سازد. آنتی‌بیوتیک نمی‌تواند باکتری داخل بیوفیلم را ریشه‌کن کند، پس درمان فقط فلور حساس را با فلور مقاوم عوض می‌کند و ظرف چند روز کلونیزاسیون برمی‌گردد — این بار با میکروبی که درمانش سخت‌تر است. تنها مداخله‌ی مؤثر، **برداشتن یا تعویض خود سوند** است.",
 "This question asks the exception list directly. Pregnancy and urologic instrumentation are the two classic indications; renal transplant within the first month is also treated at most centres. But a urinary CATHETER is never treated, and the reason is instructive: essentially every long-term catheter becomes colonised and forms a BIOFILM on its surface. Antibiotics cannot eradicate organisms inside a biofilm, so treatment simply replaces susceptible flora with resistant flora and colonisation returns within days — this time with a harder organism. The only effective intervention is removing or changing the catheter itself.",
 ["پیوند کلیه (به‌ویژه در ماه اول) از موارد درمان باکتریوری بدون علامت است.",
  "حاملگی یکی از دو اندیکاسیون قطعی درمان است؛ خطر پیلونفریت و زایمان زودرس را کم می‌کند.",
  "پاسخ صحیح — کاتتر ادراری درمان نمی‌خواهد؛ بیوفیلم با آنتی‌بیوتیک پاک نمی‌شود.",
  "دستکاری اورولوژیک با خونریزی مخاطی، دومین اندیکاسیون قطعی درمان است."],
 ["Renal transplant (especially within the first month) is a setting where treatment is given.",
  "Pregnancy is one of the two definite indications; it reduces pyelonephritis and preterm delivery.",
  "Correct — a urinary catheter needs no treatment; a biofilm is not cleared by antibiotics.",
  "Urologic instrumentation with mucosal bleeding is the second definite indication."],
 "درمان باکتریوری بدون علامت فقط در **بارداری** و **پیش از اقدام اورولوژیک خونریزی‌دهنده**. سوند هرگز.",
 "Treat asymptomatic bacteriuria only in PREGNANCY and BEFORE a bleeding urologic procedure. Never for a catheter.",
 [H, IDSA])

# ---------------------------------------------------------------- idx 506
add("book:506", "recall", "medium",
 "خانمی که **ترمیم مجرای ادرار** لازم دارد ← اقدام اورولوژیک ← تنها موردی که درمان می‌خواهد.",
 "The woman needing URETHRAL REPAIR is having a urologic procedure — the only one needing treatment.",
 ASB_FA + [
  "این سؤال، آینه‌ی سؤال قبلی است: آنجا استثنا را می‌خواست، اینجا اندیکاسیون را.",
  "سنگ کلیوی: اندیکاسیون درمان باکتریوری بدون علامت **نیست**.",
  "دیابت: در فهرست صریحِ «درمان نکنید» IDSA است، حتی با کنترل ضعیف قند.",
  "پیوند کلیه از یک سال قبل: بیش از یک ماه گذشته، پس درمان توصیه نمی‌شود.",
  "ترمیم مجرای ادرار یک **عمل اورولوژیک با آسیب مخاطی** است — پس درمان لازم است.",
  "منطق: دستکاری مخاط ملتهب و کلونیزه، باکتری را مستقیم وارد جریان خون می‌کند.",
  "نتیجه می‌تواند باکتریمی و سپسیس پس از عمل باشد که مرگ‌ومیر واقعی دارد.",
  "پس اینجا درمان، پیشگیری از یک عارضه‌ی مشخص و اثبات‌شده است، نه پاک کردن کشت.",
  "نحوه‌ی درمان هم مهم است: بر پایه‌ی **کشت** و **کوتاه‌مدت** (یک تا دو دوز پیش از عمل).",
  "درمان طولانی پیش از عمل توصیه نمی‌شود و فقط مقاومت می‌سازد.",
 ],
 ASB_EN + [
  "This mirrors the previous question: that one asked for the exception, this one for the indication.",
  "Kidney stone: NOT an indication to treat asymptomatic bacteriuria.",
  "Diabetes: explicitly on IDSA's 'do not treat' list, even when glycaemic control is poor.",
  "Renal transplant one year ago: more than a month has passed, so treatment is not recommended.",
  "Urethral repair is a UROLOGIC PROCEDURE WITH MUCOSAL INJURY, so treatment IS needed.",
  "The logic: instrumenting inflamed, colonised mucosa drives bacteria straight into the bloodstream.",
  "The result can be post-procedure bacteraemia and sepsis, which carries real mortality.",
  "So here treatment prevents a specific, demonstrated complication rather than just clearing a culture.",
  "How to treat matters too: guided by CULTURE and given SHORT-COURSE (one or two doses before the procedure).",
  "Prolonged pre-operative treatment is not recommended and only breeds resistance.",
 ],
 "این سؤال جفتِ معکوس سؤال قبلی است. سه گزینه‌ی سنگ کلیه، دیابت و پیوند کلیه‌ی یک‌ساله همگی در فهرست **«درمان نکنید»** هستند — دیابت به‌صراحت، و پیوند کلیه چون بیش از یک ماه از آن گذشته. تنها گزینه‌ای که اندیکاسیون دارد، خانمی است که **ترمیم مجرای ادرار** لازم دارد: این یک اقدام اورولوژیک با آسیب مخاطی است. منطق درمان اینجا کاملاً مشخص است — دستکاری مخاطِ کلونیزه، باکتری را مستقیم وارد جریان خون می‌کند و می‌تواند باکتریمی و سپسیس پس از عمل بسازد. توجه کنید که حتی در این مورد، درمان باید **بر پایه‌ی کشت** و **کوتاه‌مدت** (یک تا دو دوز درست پیش از عمل) باشد، نه یک دوره‌ی طولانی.",
 "This is the mirror of the previous question. Kidney stone, diabetes and a one-year-old renal transplant are all on the 'do not treat' list — diabetes explicitly, and the transplant because more than a month has passed. The only option that IS an indication is the woman needing URETHRAL REPAIR: that is a urologic procedure involving mucosal injury. The logic is clear — instrumenting colonised mucosa drives bacteria directly into the bloodstream and can cause post-procedure bacteraemia and sepsis. Note that even here, treatment should be CULTURE-GUIDED and SHORT-COURSE (one or two doses immediately before the procedure), not a prolonged course.",
 ["سنگ کلیوی به‌تنهایی اندیکاسیون درمان باکتریوری بدون علامت نیست.",
  "پاسخ صحیح — ترمیم مجرای ادرار یک اقدام اورولوژیک با آسیب مخاطی است، پس درمان لازم است.",
  "دیابت صریحاً در فهرست «درمان نکنید» IDSA است.",
  "پیوند کلیه از یک سال قبل: بیش از یک ماه گذشته و درمان توصیه نمی‌شود."],
 ["A kidney stone alone is not an indication to treat asymptomatic bacteriuria.",
  "Correct — urethral repair is a urologic procedure with mucosal injury, so treatment is indicated.",
  "Diabetes is explicitly on IDSA's 'do not treat' list.",
  "A renal transplant a year ago is beyond one month, so treatment is not recommended."],
 "اقدام اورولوژیک با خونریزی مخاطی ← درمان کن (بر پایه‌ی کشت، کوتاه‌مدت). دیابت و سنگ ← نه.",
 "Urologic procedure with mucosal bleeding means treat (culture-guided, short course). Diabetes and stones do not.",
 [H, IDSA])

# ---------------------------------------------------------------- idx 503
add("book:503", "case", "medium",
 "سوند دارد و **بدون علامت** است ← نه کشت مجدد لازم است، نه آنتی‌بیوتیک.",
 "He has a catheter and NO symptoms, so neither a repeat culture nor an antibiotic is needed.",
 ASB_FA + [
  "در این بیمار سه چیز را کنار هم بگذارید: سوند دائم، کشت مثبت، و **نبود تب و علائم سیستمیک**.",
  "همین «نبود علامت» است که تشخیص را از عفونت به باکتریوری بدون علامت می‌برد.",
  "سوند دائم در فهرست «درمان نکنید» است، چه کوتاه‌مدت و چه بلندمدت.",
  "گزینه‌های دیگر پیشنهاد می‌کنند با کشت مجدد یا پونکسیون سوپراپوبیک «تأیید» کنیم و بعد درمان.",
  "ولی تکرار آزمایش وقتی درمان تغییر نمی‌کند، فقط هزینه و اضطراب اضافه می‌کند.",
  "قاعده‌ی کلی آزمایش: آزمایشی را بفرست که پاسخش **تصمیم تو را عوض کند**.",
  "چون در فرد بدون علامت با سوند در هیچ حالتی درمان نمی‌کنیم، کشت مجدد بی‌فایده است.",
  "در واقع در چنین بیماری اصلاً نباید کشت روتین فرستاد؛ همین کشت هم اضافی بوده است.",
  "اگر روزی همین بیمار تب یا علائم سیستمیک پیدا کند، داستان کاملاً عوض می‌شود.",
  "آن وقت باید سوند را تعویض کرد، کشت فرستاد و درمان را شروع کرد.",
  "نکته‌ی بالینی مهم: در بیمار سوند‌دار، تشخیص عفونت **بالینی** است نه آزمایشگاهی.",
 ],
 ASB_EN + [
  "Put three things together in this patient: an indwelling catheter, a positive culture, and NO fever or systemic signs.",
  "It is that absence of symptoms which makes this asymptomatic bacteriuria rather than infection.",
  "An indwelling catheter is on the 'do not treat' list, short-term or long-term.",
  "The other options propose 'confirming' with a repeat culture or suprapubic aspiration, then treating.",
  "But repeating a test that will not change management only adds cost and anxiety.",
  "A general rule of testing: order the test whose result would CHANGE YOUR DECISION.",
  "Since we never treat an asymptomatic catheterised patient, a repeat culture is pointless.",
  "In fact such a patient should not have had a routine culture at all; even this one was unnecessary.",
  "If this same patient later develops fever or systemic signs, the story changes completely.",
  "Then the catheter should be changed, cultures sent and treatment started.",
  "Key clinical point: in a catheterised patient, infection is a CLINICAL diagnosis, not a laboratory one.",
 ],
 "بیمار سوند دائم دارد، کشت ادرارش مثبت است، و **تب و علائم سیستمیک ندارد** — یعنی دقیقاً تعریف باکتریوری بدون علامت در بیمار کاتتریزه، که در فهرست «درمان نکنید» است. سه گزینه‌ی دیگر همگی پیشنهاد می‌کنند اول با کشت مجدد یا پونکسیون سوپراپوبیک «تأیید» کنیم و بعد درمان. اما اینجا یک اصل عمومی طب کار می‌کند: **آزمایشی بفرست که پاسخش تصمیمت را عوض کند.** چون در بیمار بی‌علامتِ سوند‌دار در هیچ حالتی درمان نمی‌کنیم، هیچ نتیجه‌ای از کشت مجدد رفتار ما را تغییر نمی‌دهد؛ پس فرستادنش فقط هزینه و اضطراب می‌سازد. البته اگر همین بیمار تب یا علائم سیستمیک پیدا کند، تشخیص عوض می‌شود و باید سوند تعویض، کشت ارسال و درمان شروع شود.",
 "The patient has an indwelling catheter, a positive urine culture, and NO fever or systemic signs — precisely asymptomatic bacteriuria in a catheterised patient, which is on the 'do not treat' list. The other three options all propose 'confirming' first with a repeat culture or suprapubic aspiration and then treating. But a general principle of medicine applies: order the test whose result would CHANGE your decision. Since we never treat an asymptomatic catheterised patient, no culture result would alter management; sending it only adds cost and anxiety. If he later develops fever or systemic signs the diagnosis changes, and then the catheter should be changed, cultures sent and treatment begun.",
 ["درمان ۱۴ روزه در بیمار بدون علامت با سوند، درمان بیش از حد و مضر است.",
  "پونکسیون سوپراپوبیک تصمیم را عوض نمی‌کند؛ در فرد بی‌علامت باز هم درمان نمی‌کنیم.",
  "تکرار کشت هم تصمیم را عوض نمی‌کند و آزمایش بی‌فایده است.",
  "پاسخ صحیح — بیمار بی‌علامت با سوند: نه کشت مجدد، نه آنتی‌بیوتیک."],
 ["A 14-day course in an asymptomatic catheterised patient is over-treatment and harmful.",
  "Suprapubic aspiration would not change the decision; we still would not treat an asymptomatic patient.",
  "A repeat culture would not change the decision either and is a pointless test.",
  "Correct — asymptomatic with a catheter: no repeat culture and no antibiotic."],
 "بیمار سوند‌دار بدون علامت = درمان نکن، کشت هم نفرست. آزمایشی بفرست که تصمیمت را عوض کند.",
 "Asymptomatic catheterised patient: do not treat and do not culture. Order tests that change decisions.",
 [H, IDSA])

# ---------------------------------------------------------------- idx 500  KEY CORRECTED
add("book:500", "case", "hard",
 "⚠️ **کلید این سؤال تصحیح شده است.** زن دیابتیِ **بدون علامت** ← درمان **لازم نیست**.",
 "WARNING: the printed key has been CORRECTED. An ASYMPTOMATIC diabetic woman needs NO treatment.",
 ASB_FA + [
  "این سناریو خیلی شایع است: آزمایش ادرار برای استخدام، بدون هیچ شکایتی.",
  "صورت سؤال صریح می‌گوید بیمار **«علامتی ندارد»** — این کلیدواژه‌ی تعیین‌کننده است.",
  "پس تشخیص «باکتریوری بدون علامت» است، نه عفونت ادراری.",
  "⚠️ کلید چاپی کتاب «شروع درمان آنتی‌بیوتیکی» است که با راهنمای IDSA در تضاد است.",
  "IDSA ۲۰۱۹ صریحاً توصیه می‌کند بیماران **دیابتی** را غربالگری و درمان **نکنید**.",
  "این توصیه‌ی «قوی» با شواهد «با کیفیت متوسط» است، یعنی مبتنی بر کارآزمایی.",
  "مطالعات نشان داده‌اند درمان، خطر عفونت علامت‌دار یا پیلونفریت را در دیابتی کم نمی‌کند.",
  "دیابت باکتریوری بدون علامت را **شایع‌تر** می‌کند (تا ۲۷٪ در زنان)، ولی درمان‌پذیرتر نمی‌کند.",
  "«شایع‌تر بودن» با «نیاز به درمان داشتن» یکی نیست — این هسته‌ی خطای این سؤال است.",
  "تله‌ی دوم سؤال: آزمایش پیوری فراوان و نیتریت مثبت نشان می‌دهد.",
  "ولی همان‌طور که گفتیم، **پیوری در فرد بی‌علامت اندیکاسیون درمان نیست**.",
  "نیتریت مثبت هم فقط می‌گوید باکتری گرم‌منفی حضور دارد، نه اینکه بیماری هست.",
  "کار درست: به بیمار توضیح دهید که این یافته بیماری نیست و درمان لازم ندارد.",
  "و اصلاً بهتر بود این کشت ادرار روتین برای استخدام گرفته نمی‌شد.",
 ],
 ASB_EN + [
  "This scenario is very common: a urinalysis for employment, with no complaints at all.",
  "The stem states explicitly that the patient 'has no symptoms' — the decisive keyword.",
  "So the diagnosis is asymptomatic bacteriuria, not urinary tract infection.",
  "WARNING: the book's printed key is 'start antibiotics', which contradicts IDSA guidance.",
  "IDSA 2019 explicitly recommends AGAINST screening and treating patients with DIABETES.",
  "It is a 'strong' recommendation with 'moderate-quality' evidence, meaning it rests on trials.",
  "Studies show treatment does not reduce symptomatic infection or pyelonephritis in diabetics.",
  "Diabetes makes asymptomatic bacteriuria MORE COMMON (up to 27% of women) but no more treatable.",
  "'More common' is not the same as 'needs treating' — that is the core error in this question.",
  "A second trap: the report shows heavy pyuria and a positive nitrite.",
  "But as stated above, PYURIA IS NOT AN INDICATION in an asymptomatic person.",
  "A positive nitrite merely indicates a gram-negative organism is present, not that disease exists.",
  "The right action: explain to the patient that this finding is not a disease and needs no treatment.",
  "And ideally this routine pre-employment urine culture should never have been sent.",
 ],
 "⚠️ **توجه: کلید چاپی کتاب در این سؤال تصحیح شده است.**\n\nصورت سؤال صریح می‌گوید بیمار **«علامتی ندارد»**. پس با وجود کشت مثبت، پیوری فراوان و نیتریت مثبت، تشخیص **باکتریوری بدون علامت** است نه عفونت ادراری. کتاب «شروع درمان آنتی‌بیوتیکی» را درست دانسته، ولی راهنمای IDSA سال ۲۰۱۹ با **توصیه‌ی قوی و شواهد با کیفیت متوسط** می‌گوید بیماران دیابتی را نه غربالگری و نه درمان کنید. کارآزمایی‌ها نشان داده‌اند درمان، خطر عفونت علامت‌دار و پیلونفریت را در این گروه کم نمی‌کند.\n\nدو تله در این سؤال هست. اول اینکه دیابت باکتریوری بدون علامت را **شایع‌تر** می‌کند (تا ۲۷٪ زنان دیابتی) و ذهن این را با «پس باید درمان شود» اشتباه می‌گیرد؛ شایع بودن یک یافته، دلیل درمانش نیست. دوم اینکه پیوری فراوان دیده می‌شود، ولی **پیوری در فرد بی‌علامت اندیکاسیون درمان نیست** — این را IDSA صریحاً نوشته است. درمان اینجا فقط مقاومت آنتی‌بیوتیکی و خطر کولیت کلستریدیوئیدس دیفیسیل می‌سازد.",
 "WARNING: the book's printed key for this question has been CORRECTED.\n\nThe stem states explicitly that the patient 'has no symptoms'. So despite a positive culture, heavy pyuria and a positive nitrite, the diagnosis is ASYMPTOMATIC BACTERIURIA, not urinary tract infection. The book marks 'start antibiotics' as correct, but the 2019 IDSA guideline gives a STRONG recommendation on MODERATE-quality evidence against screening or treating patients with diabetes. Trials show treatment does not reduce symptomatic infection or pyelonephritis in this group.\n\nThere are two traps. First, diabetes makes asymptomatic bacteriuria MORE COMMON (up to 27% of diabetic women), and the mind slides from 'common' to 'therefore treat'; the frequency of a finding is not a reason to treat it. Second, heavy pyuria is reported, but PYURIA IS NOT AN INDICATION in an asymptomatic person — IDSA states this explicitly. Treating here produces only antimicrobial resistance and a risk of Clostridioides difficile colitis.",
 ["کلید چاپی کتاب؛ درمان در دیابتیِ بی‌علامت با توصیه‌ی قوی IDSA در تضاد است.",
  "کشت مجدد هم تصمیم را عوض نمی‌کند، چون در هر صورت درمان نمی‌کنیم.",
  "سونوگرافی در باکتریوری بدون علامتِ بدون شواهد انسداد، اندیکاسیون ندارد.",
  "پاسخ صحیح (کلید تصحیح‌شده) — بیمار بی‌علامت است و دیابت اندیکاسیون درمان نیست."],
 ["This is the book's printed key; treating an asymptomatic diabetic contradicts a strong IDSA recommendation.",
  "A repeat culture would not change the decision, since we would not treat either way.",
  "Ultrasound is not indicated for asymptomatic bacteriuria without evidence of obstruction.",
  "Correct (corrected key) — the patient is asymptomatic and diabetes is not an indication to treat."],
 "دیابت + بدون علامت = **درمان نکن**، هرچقدر هم پیوری و نیتریت مثبت باشد.",
 "Diabetes plus no symptoms means DO NOT TREAT, however impressive the pyuria and nitrite.",
 [H, IDSA])

# ---------------------------------------------------------------- idx 508
add("book:508", "case", "medium",
 "بارداری یکی از **دو استثنا** است ← باکتریوری بدون علامت در بارداری **حتماً درمان می‌شود**.",
 "Pregnancy is one of the TWO exceptions, so asymptomatic bacteriuria in pregnancy IS treated.",
 ASB_FA + [
  "این بیمار بدون علامت است، ولی **باردار** — و همین همه‌چیز را عوض می‌کند.",
  "چرا؟ چون فیزیولوژی بارداری، ادرار را به سمت پیلونفریت هل می‌دهد.",
  "پروژسترون تون عضله‌ی صاف حالب را کم می‌کند و باعث اتساع و رکود ادرار می‌شود.",
  "رحمِ بزرگ‌شده هم حالب‌ها را (به‌ویژه سمت راست) فشرده می‌کند.",
  "نتیجه: باکتری راحت‌تر از مثانه به کلیه صعود می‌کند.",
  "بدون درمان، حدود **۲۰ تا ۳۰ درصد** این زنان به پیلونفریت مبتلا می‌شوند.",
  "با درمان، این خطر به حدود سه درصد می‌رسد — یک کاهش چشمگیر.",
  "پیلونفریت بارداری خودش با زایمان زودرس، وزن کم هنگام تولد و سپسیس مادر همراه است.",
  "پس درمان اینجا هم مادر و هم جنین را محافظت می‌کند.",
  "طول درمان طبق IDSA: **چهار تا هفت روز** — نه تک‌دوز و نه دوره‌ی طولانی.",
  "داروهای بی‌خطر بارداری: نیتروفورانتوئین، آموکسی‌سیلین، سفالکسین.",
  "به همین دلیل غربالگری کشت ادرار در اوایل بارداری **روتین** است.",
 ],
 ASB_EN + [
  "This patient is asymptomatic, but PREGNANT — and that changes everything.",
  "Why? Because the physiology of pregnancy pushes urine towards pyelonephritis.",
  "Progesterone reduces ureteric smooth muscle tone, causing dilatation and urinary stasis.",
  "The enlarged uterus also compresses the ureters, especially on the right.",
  "The result is that bacteria ascend more easily from bladder to kidney.",
  "Untreated, about 20 to 30 per cent of these women develop pyelonephritis.",
  "With treatment that risk falls to roughly three per cent — a striking reduction.",
  "Pyelonephritis in pregnancy itself brings preterm labour, low birth weight and maternal sepsis.",
  "So treatment here protects both mother and fetus.",
  "Duration per IDSA: FOUR to SEVEN days — neither a single dose nor a prolonged course.",
  "Pregnancy-safe agents include nitrofurantoin, amoxicillin and cephalexin.",
  "This is why screening urine culture in early pregnancy is ROUTINE.",
 ],
 "همه‌ی درسنامه‌های قبلی گفتند «درمان نکن»؛ این یکی استثناست و باید دلیلش را فهمید نه حفظ کرد. بارداری فیزیولوژی دستگاه ادراری را عوض می‌کند: **پروژسترون** تون عضله‌ی صاف حالب را کاهش می‌دهد و رحمِ بزرگ‌شده حالب‌ها را فشرده می‌کند؛ نتیجه اتساع، رکود ادرار و صعود آسان‌تر باکتری از مثانه به کلیه است. عدد ماجرا قانع‌کننده است: بدون درمان **۲۰ تا ۳۰ درصد** این زنان پیلونفریت می‌گیرند، و با درمان این رقم به حدود **۳ درصد** می‌رسد. پیلونفریت بارداری هم با زایمان زودرس، وزن کم هنگام تولد و سپسیس مادر گره خورده است. پس درمان اینجا نه «پاک کردن کشت»، بلکه پیشگیری از یک عارضه‌ی شایع و خطرناک است. طول درمان طبق IDSA **چهار تا هفت روز** است با دارویی که در بارداری بی‌خطر باشد.",
 "Every previous lesson said 'do not treat'; this one is the exception, and the reason must be understood rather than memorised. Pregnancy alters urinary tract physiology: PROGESTERONE reduces ureteric smooth muscle tone and the enlarged uterus compresses the ureters, producing dilatation, stasis and easier ascent of bacteria from bladder to kidney. The numbers are persuasive: untreated, 20 to 30 per cent of these women develop pyelonephritis; treated, about 3 per cent. Pyelonephritis in pregnancy is in turn linked to preterm labour, low birth weight and maternal sepsis. So treatment here is not 'clearing a culture' but preventing a common and dangerous complication. IDSA recommends FOUR to SEVEN days with an agent safe in pregnancy.",
 ["پاسخ صحیح — بارداری یکی از دو اندیکاسیون قطعی درمان باکتریوری بدون علامت است.",
  "عدم اقدام در بارداری خطرناک است: تا ۳۰٪ به پیلونفریت پیشرفت می‌کنند.",
  "تکرار کشت درمان را به تعویق می‌اندازد؛ کشت غربالگری مثبت کافی است.",
  "سونوگرافی در باکتریوری بدون علامت بارداری اندیکاسیون روتین ندارد."],
 ["Correct — pregnancy is one of the two definite indications for treating asymptomatic bacteriuria.",
  "Doing nothing in pregnancy is dangerous: up to 30% progress to pyelonephritis.",
  "Repeating the culture only delays treatment; a positive screening culture suffices.",
  "Ultrasound is not routinely indicated for asymptomatic bacteriuria in pregnancy."],
 "بارداری = استثنا. درمان ۴ تا ۷ روزه با داروی بی‌خطر. بدون درمان تا ۳۰٪ پیلونفریت.",
 "Pregnancy is the exception. Treat for 4-7 days with a pregnancy-safe agent; untreated, up to 30% get pyelonephritis.",
 [H, IDSA])

# ---------------------------------------------------------------- idx 513
CYST_FA = [
  "سیستیت بدون عارضه یعنی: زن غیرباردار، بدون بیماری زمینه‌ای، بدون تب و بدون درد پهلو.",
  "تابلوی کلاسیک: دیزوری، تکرر و فوریت ادراری، گاهی درد سوپراپوبیک.",
  "در چنین زنی، ارزش اخباری مثبت شرح حال به‌تنهایی بسیار بالاست (بیش از ۹۰٪).",
  "به همین دلیل **درمان تجربی بدون کشت** رویکرد استاندارد است.",
  "کشت ادرار روتین در سیستیت بدون عارضه توصیه **نمی‌شود** — هزینه دارد و تصمیم را عوض نمی‌کند.",
  "کشت را برای این موارد نگه دارید: بارداری، شکست درمان، عود زودرس، شک به پیلونفریت.",
  "علائم هشدار که ما را از «سیستیت ساده» بیرون می‌برد: تب، لرز، تهوع و استفراغ، درد پهلو، تندرنس CVA.",
  "خط اول‌های سیستیت بدون عارضه: نیتروفورانتوئین ۵ روز، کوتریموکسازول ۳ روز، فسفومایسین تک‌دوز.",
  "فلوروکینولون‌ها (سیپروفلوکساسین) **خط اول نیستند** و باید برای موارد جدی‌تر ذخیره شوند.",
  "دلیلش هم عوارض جدی (تاندونیت، پارگی تاندون، نوروپاتی) و هم حفظ حساسیت است.",
  "سونوگرافی در اولین اپیزود سیستیت بدون عارضه هیچ اندیکاسیونی ندارد.",
]
CYST_EN = [
  "Uncomplicated cystitis means a non-pregnant woman with no underlying disease, no fever and no flank pain.",
  "The classic picture is dysuria, frequency and urgency, sometimes with suprapubic pain.",
  "In such a woman the positive predictive value of the history alone exceeds 90 per cent.",
  "That is why EMPIRICAL TREATMENT WITHOUT CULTURE is the standard approach.",
  "Routine urine culture is NOT recommended in uncomplicated cystitis: it costs money and changes nothing.",
  "Reserve culture for pregnancy, treatment failure, early recurrence, or suspected pyelonephritis.",
  "Red flags that take us out of 'simple cystitis': fever, rigors, nausea and vomiting, flank pain, CVA tenderness.",
  "First-line options: nitrofurantoin for 5 days, co-trimoxazole for 3 days, or single-dose fosfomycin.",
  "Fluoroquinolones such as ciprofloxacin are NOT first line and should be saved for more serious infection.",
  "The reasons are both serious adverse effects (tendinitis, tendon rupture, neuropathy) and preserving susceptibility.",
  "Ultrasound has no place in a first episode of uncomplicated cystitis.",
]

add("book:513", "case", "easy",
 "سیستیت بدون عارضه در زن جوان ← **درمان تجربی**، بدون نیاز به کشت.",
 "Uncomplicated cystitis in a young woman means EMPIRICAL TREATMENT, with no culture needed.",
 CYST_FA + [
  "در این بیمار همه‌چیز به نفع سیستیت ساده است: دیزوری و فرکوئنسی از دیروز، بدون تب.",
  "بدون تاکی‌کاردی و بدون تندرنس CVA — یعنی هیچ نشانه‌ای از درگیری کلیه.",
  "تست نواری هم نیتریت مثبت داده که احتمال باکتری گرم‌منفی را تقویت می‌کند.",
  "نیتریت مثبت اختصاصیت بالایی دارد، هرچند حساسیتش پایین است.",
  "یعنی نیتریت منفی عفونت را رد نمی‌کند، ولی نیتریت مثبت آن را بسیار محتمل می‌سازد.",
  "پس با شرح حال کلاسیک و نوار مثبت، هیچ آزمایش دیگری تصمیم را عوض نمی‌کند.",
  "گزینه‌ی «آنالیز ادراری» اضافی است، چون نوار ادرار همان کار را کرده است.",
 ],
 CYST_EN + [
  "Everything here favours simple cystitis: dysuria and frequency since yesterday, no fever.",
  "No tachycardia and no CVA tenderness — so no sign of renal involvement.",
  "The dipstick is nitrite positive, which strengthens the case for a gram-negative organism.",
  "A positive nitrite is highly specific, though its sensitivity is low.",
  "So a negative nitrite would not exclude infection, but a positive one makes it very likely.",
  "With a classic history and a positive dipstick, no further test would change the decision.",
  "The 'urinalysis' option is redundant, because the dipstick has already done that job.",
 ],
 "این سؤال ساده به‌نظر می‌رسد ولی یک عادت غلط رایج را هدف گرفته است: فرستادن کشت ادرار برای هر بیمار با سوزش ادرار. در **زن جوان غیرباردار بدون بیماری زمینه‌ای** که تابلوی کلاسیک دیزوری و فرکوئنسی دارد و **تب، تهوع، درد پهلو و تندرنس CVA ندارد**، ارزش اخباری مثبت شرح حال به‌تنهایی بیش از ۹۰٪ است. نوار ادرار با نیتریت مثبت هم آن را تقویت می‌کند (نیتریت حساسیت پایین ولی اختصاصیت بالا دارد). در چنین وضعیتی هیچ آزمایش دیگری تصمیم درمانی را عوض نمی‌کند، پس **درمان تجربی** شروع می‌شود. کشت ادرار را برای بارداری، شکست درمان، عود زودرس یا شک به پیلونفریت نگه دارید.",
 "This looks simple but targets a common bad habit: sending a urine culture for every patient with dysuria. In a YOUNG, NON-PREGNANT woman with no underlying disease, a classic history of dysuria and frequency and NO fever, nausea, flank pain or CVA tenderness, the positive predictive value of the history alone exceeds 90%. A nitrite-positive dipstick strengthens it further (nitrite has low sensitivity but high specificity). In that situation no further test would change management, so EMPIRICAL TREATMENT is started. Save urine culture for pregnancy, treatment failure, early recurrence or suspected pyelonephritis.",
 ["کشت ادرار در سیستیت بدون عارضه روتین نیست و درمان را بی‌دلیل به تعویق می‌اندازد.",
  "آنالیز ادراری اضافی است؛ تست نواری همین اطلاعات را داده است.",
  "پاسخ صحیح — تابلوی کلاسیک سیستیت ساده، پس درمان تجربی بدون کشت.",
  "سونوگرافی در اولین اپیزود سیستیت بدون عارضه هیچ اندیکاسیونی ندارد."],
 ["Urine culture is not routine in uncomplicated cystitis and needlessly delays treatment.",
  "A urinalysis is redundant; the dipstick has already provided that information.",
  "Correct — a classic picture of simple cystitis, so empirical treatment without culture.",
  "Ultrasound has no indication in a first episode of uncomplicated cystitis."],
 "سیستیت ساده در زن جوان: شرح حال کافی است ← درمان تجربی. کشت را برای بارداری و شکست درمان نگه دار.",
 "Simple cystitis in a young woman: the history suffices, so treat empirically. Save culture for pregnancy and treatment failure.",
 [H])

# ---------------------------------------------------------------- idx 517
add("book:517", "case", "hard",
 "سیستیت در بارداری ← **هم کشت بگیر و هم درمان کن**؛ داروی انتخابی نیتروفورانتوئین است نه کوتریموکسازول.",
 "Cystitis in pregnancy: BOTH culture AND treat; the agent of choice is nitrofurantoin, not co-trimoxazole.",
 [
  "بارداری، سیستیت را از «بدون عارضه» به «با عارضه» می‌برد، پس قواعد عوض می‌شود.",
  "تفاوت اول: در بارداری **کشت ادرار می‌گیریم**، برخلاف زن غیرباردار.",
  "دلیلش این است که باید از ریشه‌کنی کامل مطمئن شویم و حساسیت را بدانیم.",
  "تفاوت دوم: انتخاب دارو محدود می‌شود، چون باید برای جنین بی‌خطر باشد.",
  "کشت را می‌گیریم ولی **منتظر جوابش نمی‌مانیم**؛ درمان تجربی همان روز شروع می‌شود.",
  "داروهای بی‌خطر در بارداری: نیتروفورانتوئین، آموکسی‌سیلین، سفالکسین، فسفومایسین.",
  "⚠️ کوتریموکسازول در بارداری مشکل‌دار است و در سه‌ماهه‌ی اول و سوم باید پرهیز شود.",
  "در سه‌ماهه‌ی اول: تری‌متوپریم آنتاگونیست فولات است و خطر نقص لوله‌ی عصبی دارد.",
  "در سه‌ماهه‌ی سوم: سولفامتوکسازول بیلی‌روبین را از آلبومین جدا می‌کند و خطر **کرن‌ایکتروس** دارد.",
  "این بیمار در **ماه دوم** بارداری است، یعنی دقیقاً در سه‌ماهه‌ی اولِ پرخطر برای فولات.",
  "پس گزینه‌ای که کوتریموکسازول می‌دهد، از نظر انتخاب دارو غلط است.",
  "⚠️ نکته‌ی متقارن: نیتروفورانتوئین در **هفته‌ی ۳۸ تا ۴۲** (نزدیک زایمان) باید پرهیز شود.",
  "دلیلش خطر همولیز در نوزاد، به‌ویژه در کمبود G6PD است.",
  "پس نیتروفورانتوئین اوایل بارداری خوب است و اواخر بارداری نه — عکس کوتریموکسازول در سه‌ماهه‌ی سوم.",
  "گزینه‌های سفالکسین و آمپی‌سیلین به‌تنهایی بد نیستند، ولی جزء «کشت + درمان» را ندارند.",
 ],
 [
  "Pregnancy moves cystitis from 'uncomplicated' to 'complicated', so the rules change.",
  "First difference: in pregnancy we DO send a urine culture, unlike in a non-pregnant woman.",
  "The reason is that we must confirm complete eradication and know the susceptibilities.",
  "Second difference: drug choice narrows, because the agent must be safe for the fetus.",
  "We take the culture but do NOT wait for it; empirical treatment starts the same day.",
  "Pregnancy-safe agents: nitrofurantoin, amoxicillin, cephalexin, fosfomycin.",
  "WARNING: co-trimoxazole is problematic in pregnancy and should be avoided in the first and third trimesters.",
  "In the first trimester, trimethoprim is a folate antagonist and risks neural tube defects.",
  "In the third, sulfamethoxazole displaces bilirubin from albumin and risks KERNICTERUS.",
  "This patient is in her SECOND MONTH, precisely the first-trimester folate-sensitive window.",
  "So the option offering co-trimoxazole is wrong on drug choice.",
  "WARNING, the symmetric point: nitrofurantoin should be avoided at 38 to 42 weeks, near delivery.",
  "The reason is a risk of neonatal haemolysis, particularly with G6PD deficiency.",
  "So nitrofurantoin suits early pregnancy but not late — the mirror of co-trimoxazole in the third trimester.",
  "Cephalexin and ampicillin are not bad drugs, but those options omit the culture component.",
 ],
 "بارداری، سیستیت را از دسته‌ی «بدون عارضه» بیرون می‌آورد و دو چیز را عوض می‌کند. اول اینکه **کشت ادرار می‌گیریم** (برخلاف زن غیرباردار) تا از ریشه‌کنی مطمئن شویم؛ ولی منتظر جوابش نمی‌مانیم و درمان تجربی را همان روز شروع می‌کنیم. دوم اینکه انتخاب دارو محدود می‌شود.\n\nنکته‌ی طلایی، **تقارن زمانی** دو داروست:\n\n- **کوتریموکسازول** در سه‌ماهه‌ی **اول** خطرناک است (تری‌متوپریم آنتاگونیست فولات ← نقص لوله‌ی عصبی) و در سه‌ماهه‌ی **سوم** هم خطرناک است (سولفامتوکسازول بیلی‌روبین را از آلبومین جدا می‌کند ← کرن‌ایکتروس).\n- **نیتروفورانتوئین** در بیشتر بارداری بی‌خطر است ولی در **هفته‌ی ۳۸ تا ۴۲** باید پرهیز شود (خطر همولیز نوزادی، به‌ویژه در کمبود G6PD).\n\nاین بیمار در **ماه دوم** است، یعنی درست در پنجره‌ی پرخطر فولات. پس نیتروفورانتوئین انتخاب درست و کوتریموکسازول انتخاب غلط است. گزینه‌های سفالکسین و آمپی‌سیلین هم جزء «کشت» را جا انداخته‌اند.",
 "Pregnancy takes cystitis out of the 'uncomplicated' category and changes two things. First, we DO send a urine culture (unlike in a non-pregnant woman) to confirm eradication — but we do not wait for it, and start empirical treatment the same day. Second, drug choice narrows.\n\nThe golden point is the TIMING SYMMETRY of two drugs:\n\n- Co-trimoxazole is hazardous in the FIRST trimester (trimethoprim is a folate antagonist, risking neural tube defects) and again in the THIRD (sulfamethoxazole displaces bilirubin from albumin, risking kernicterus).\n- Nitrofurantoin is safe through most of pregnancy but must be avoided at 38 to 42 weeks (risk of neonatal haemolysis, especially with G6PD deficiency).\n\nThis patient is in her SECOND MONTH, squarely in the folate-sensitive window. So nitrofurantoin is right and co-trimoxazole is wrong. The cephalexin and ampicillin options also omit the culture.",
 ["کوتریموکسازول در سه‌ماهه‌ی اول به دلیل آنتاگونیسم فولات و خطر نقص لوله‌ی عصبی پرهیز می‌شود.",
  "پاسخ صحیح — در بارداری هم کشت می‌گیریم و هم با داروی بی‌خطر (نیتروفورانتوئین) درمان می‌کنیم.",
  "سفالکسین دارویی بی‌خطر است ولی این گزینه جزء کشت ادرار را ندارد.",
  "آمپی‌سیلین هم بی‌خطر است ولی بدون کشت، رویکرد در بارداری ناقص است."],
 ["Co-trimoxazole is avoided in the first trimester for folate antagonism and neural tube defect risk.",
  "Correct — in pregnancy we both culture and treat with a safe agent such as nitrofurantoin.",
  "Cephalexin is a safe drug, but this option omits the urine culture.",
  "Ampicillin is also safe, but without a culture the approach in pregnancy is incomplete."],
 "بارداری: **کشت + درمان**. کوتریموکسازول در سه‌ماهه‌ی ۱ و ۳ ممنوع؛ نیتروفورانتوئین در هفته‌ی ۳۸-۴۲ ممنوع.",
 "Pregnancy means CULTURE plus TREAT. Avoid co-trimoxazole in trimesters 1 and 3; avoid nitrofurantoin at 38-42 weeks.",
 [H])

# ---------------------------------------------------------------- idx 525  KEY CORRECTED
add("book:525", "case", "hard",
 "⚠️ **کلید این سؤال تصحیح شده است.** در میاستنی گراو، **سیپروفلوکساسین** ممنوع است — نه کوتریموکسازول.",
 "WARNING: the printed key has been CORRECTED. In myasthenia gravis CIPROFLOXACIN is the drug to avoid, not co-trimoxazole.",
 [
  "میاستنی گراو یک بیماری خودایمنی محل اتصال عصب-عضله است.",
  "آنتی‌بادی علیه گیرنده‌ی استیل‌کولین، تعداد گیرنده‌های فعال را کم می‌کند.",
  "نتیجه: «حاشیه‌ی امنیت» انتقال عصبی-عضلانی باریک می‌شود.",
  "پس هر دارویی که کمی این انتقال را مختل کند، در این بیمار ضعف آشکار می‌سازد.",
  "سه دسته‌ی آنتی‌بیوتیک بیشترین خطر را دارند و باید به خاطر سپرده شوند.",
  "**فلوروکینولون‌ها** (سیپروفلوکساسین، لووفلوکساسین، موکسی‌فلوکساسین) — خطرناک‌ترین گروه.",
  "سازمان غذا و داروی آمریکا از سال ۲۰۱۱ برای این گروه **هشدار جعبه‌سیاه** گذاشته است.",
  "این بالاترین سطح هشدار FDA است و صریحاً به تشدید میاستنی گراو اشاره دارد.",
  "**آمینوگلیکوزیدها** (جنتامایسین، آمیکاسین) — آزادسازی استیل‌کولین را مهار می‌کنند.",
  "**ماکرولیدها** (اریترومایسین، آزیترومایسین، کلاریترومایسین) و تلیترومایسین.",
  "⚠️ کلید چاپی کتاب «کوتریموکسازول» است که با منابع میاستنی در تضاد است.",
  "منابع تخصصی میاستنی، **سولفونامیدها از جمله کوتریموکسازول را بی‌خطر** می‌دانند.",
  "مرور Narayanaswami و همکاران صریح می‌نویسد: با سفالوسپورین‌ها، سولفاها و کلیندامایسین تشدید گزارش نشده است.",
  "فهرست داروهای احتیاطی MGFA هم سولفاها را در دسته‌ی «جایگزین‌های خوب» می‌گذارد.",
  "پس در این سؤال، سفکسیم و آمپی‌سیلین و کوتریموکسازول هر سه قابل استفاده‌اند.",
  "و تنها دارویی که **نباید** داده شود، سیپروفلوکساسین است.",
  "منطق بالینی: عفونت خودش می‌تواند بحران میاستنیک بسازد، پس باید سریع درمان شود.",
  "ولی درمان را باید از دسته‌ای انتخاب کرد که خودش ضعف را بدتر نکند.",
 ],
 [
  "Myasthenia gravis is an autoimmune disease of the neuromuscular junction.",
  "Antibodies against the acetylcholine receptor reduce the number of functioning receptors.",
  "The result is that the 'safety factor' of neuromuscular transmission becomes narrow.",
  "So any drug that slightly impairs transmission will unmask weakness in these patients.",
  "Three antibiotic classes carry the greatest risk and must be memorised.",
  "FLUOROQUINOLONES (ciprofloxacin, levofloxacin, moxifloxacin) are the most dangerous group.",
  "The FDA has carried a BOXED WARNING for this class since 2011.",
  "That is the FDA's highest level of warning and refers explicitly to exacerbation of myasthenia gravis.",
  "AMINOGLYCOSIDES (gentamicin, amikacin) inhibit acetylcholine release.",
  "MACROLIDES (erythromycin, azithromycin, clarithromycin) and telithromycin also.",
  "WARNING: the book prints 'co-trimoxazole', which contradicts the myasthenia literature.",
  "Specialist myasthenia sources regard SULFONAMIDES, INCLUDING CO-TRIMOXAZOLE, AS SAFE.",
  "The Narayanaswami review states plainly that no exacerbation has been reported with cephalosporins, sulfa drugs or clindamycin.",
  "The MGFA cautionary drug list likewise places sulfa drugs among the 'good alternatives'.",
  "So in this question cefixime, ampicillin and co-trimoxazole are all usable.",
  "The one drug that must NOT be given is ciprofloxacin.",
  "Clinical logic: the infection itself can precipitate myasthenic crisis, so it must be treated promptly.",
  "But the treatment must come from a class that will not worsen the weakness.",
 ],
 "⚠️ **توجه: کلید چاپی کتاب در این سؤال تصحیح شده است.**\n\nدر میاستنی گراو، آنتی‌بادی ضد گیرنده‌ی استیل‌کولین «حاشیه‌ی امنیت» انتقال عصبی-عضلانی را باریک می‌کند؛ پس داروهایی که این انتقال را حتی کمی مختل می‌کنند، ضعف را آشکار یا تشدید می‌کنند. سه دسته‌ی پرخطر عبارت‌اند از **فلوروکینولون‌ها، آمینوگلیکوزیدها و ماکرولیدها**.\n\nکتاب «کوتریموکسازول» را پاسخ دانسته، ولی این با منابع تخصصی میاستنی در تضاد است. سازمان غذا و داروی آمریکا از سال ۲۰۱۱ برای **فلوروکینولون‌ها هشدار جعبه‌سیاه** درباره‌ی تشدید میاستنی گراو گذاشته است — بالاترین سطح هشدار. در مقابل، منابع میاستنی (از جمله مرور Narayanaswami و فهرست داروهای احتیاطی MGFA) **سولفونامیدها را جزو جایگزین‌های بی‌خطر** فهرست می‌کنند.\n\nپس در این بیمار، سفکسیم و آمپی‌سیلین و کوتریموکسازول همگی قابل استفاده‌اند و تنها دارویی که باید حذف شود **سیپروفلوکساسین** است.\n\nچرا این تصحیح مهم است: دانشجویی که این سؤال را حفظ کند یاد می‌گیرد «در میاستنی کوتریموکسازول ندهید» و ناخودآگاه نتیجه می‌گیرد سیپروفلوکساسین بی‌خطر است — که دقیقاً معکوس واقعیت است و می‌تواند به بحران میاستنیک و نیاز به تهویه‌ی مکانیکی منجر شود.",
 "WARNING: the book's printed key for this question has been CORRECTED.\n\nIn myasthenia gravis, anti-acetylcholine-receptor antibodies narrow the safety factor of neuromuscular transmission, so drugs that impair that transmission even slightly will unmask or worsen weakness. The three high-risk classes are FLUOROQUINOLONES, AMINOGLYCOSIDES and MACROLIDES.\n\nThe book gives 'co-trimoxazole' as the answer, but this contradicts the specialist literature. Since 2011 the FDA has carried a BOXED WARNING on fluoroquinolones for exacerbation of myasthenia gravis — its highest level of warning. By contrast, myasthenia sources (including the Narayanaswami review and the MGFA cautionary drug list) place SULFONAMIDES among the SAFE alternatives.\n\nSo in this patient cefixime, ampicillin and co-trimoxazole are all usable, and the one drug to exclude is CIPROFLOXACIN.\n\nWhy this correction matters: a student who memorises the printed key learns 'avoid co-trimoxazole in myasthenia' and infers that ciprofloxacin is safe — the exact inverse of the truth, and a route to myasthenic crisis and mechanical ventilation.",
 ["پاسخ صحیح (کلید تصحیح‌شده) — فلوروکینولون‌ها هشدار جعبه‌سیاه FDA برای میاستنی گراو دارند.",
  "سفکسیم یک سفالوسپورین است و در میاستنی گراو بی‌خطر شمرده می‌شود.",
  "کلید چاپی کتاب؛ ولی سولفونامیدها در منابع میاستنی جزو جایگزین‌های بی‌خطرند.",
  "آمپی‌سیلین در میاستنی گراو قابل استفاده است و تشدید با آن نادر است."],
 ["Correct (corrected key) — fluoroquinolones carry an FDA boxed warning for myasthenia gravis.",
  "Cefixime is a cephalosporin and is regarded as safe in myasthenia gravis.",
  "This is the book's printed key, but sulfonamides are listed among the safe alternatives in myasthenia sources.",
  "Ampicillin can be used in myasthenia gravis and exacerbation with it is rare."],
 "میاستنی گراو: از **فلوروکینولون، آمینوگلیکوزید و ماکرولید** بپرهیز. سفالوسپورین و سولفا بی‌خطرند.",
 "In myasthenia gravis avoid FLUOROQUINOLONES, AMINOGLYCOSIDES and MACROLIDES. Cephalosporins and sulfa drugs are safe.",
 ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 130 and Ch. 441 (Myasthenia Gravis)",
  "FDA boxed warning (2011): fluoroquinolones may exacerbate muscle weakness in myasthenia gravis",
  "Myasthenia Gravis Foundation of America — Cautionary Drugs list",
  "Narayanaswami P et al., J Clin Med 2021;10:1537"])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book9.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 9 lessons:', len(L))
