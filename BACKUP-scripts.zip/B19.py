# -*- coding: utf-8 -*-
"""Micro-lessons, batch 19 — rabies post-exposure prophylaxis and bite wounds.

The first half of the zoonoses chapter. Twenty of its eighty-one questions are
about rabies, and they are unusually uniform: almost every one of them is the
same clinical decision asked from a different angle. That makes the chapter
ideal for micro-learning, because ONE correctly learned algorithm answers all
twenty — and a student who half-learns it gets all twenty wrong in the same way.

The algorithm, stated once so the lessons can lean on it
--------------------------------------------------------
Everything turns on a single question asked FIRST: HAS THIS PERSON BEEN
VACCINATED AGAINST RABIES BEFORE?

  NEVER VACCINATED  ->  rabies immune globulin (RIG) 20 IU/kg, infiltrated into
                        and around the wound, PLUS a full vaccine course on
                        days 0, 3, 7 and 14 (a fifth dose on day 28 is added
                        only for the immunocompromised).

  PREVIOUSLY VACCINATED -> TWO doses of vaccine only, on days 0 and 3.
                        NO RIG. Ever. Not a reduced dose, not "to be safe".

The second rule, which four of these questions test on its own: RIG IS USEFUL
ONLY UNTIL DAY 7 OF THE VACCINE COURSE. After that the patient is making their
own antibody, and giving RIG can actually blunt that response.

The third rule, and the one students most often get wrong out of kindness:
PREGNANCY IS NOT A CONTRAINDICATION. Rabies is essentially one hundred per cent
fatal; there is no exposure severe enough to justify waiting and no pregnancy
that changes the schedule.

Bite wounds as bacterial wounds
-------------------------------
Three questions leave rabies aside and ask what antibiotic prevents wound
infection. The answer is always AMOXICILLIN-CLAVULANATE, and the reason is
worth teaching rather than memorising: a bite is polymicrobial, and the one
organism that must not be missed — Pasteurella multocida — is exactly the one
that first-generation cephalosporins, macrolides and clindamycin all miss.

One printed key in this batch is corrected: q9421. See fix_key_bite.py.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022), Ch. 46
(Infectious Complications of Bites) and Ch. 204 (Rabies and Other Rhabdovirus
Infections); WHO Expert Consultation on Rabies, third report (2018) and the WHO
position paper of 2018; CDC ACIP rabies recommendations; IDSA Skin and Soft
Tissue Infections 2014.
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H46 = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 46: Infectious Complications of Bites"
H204 = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 204: Rabies and Other Rhabdovirus Infections"
WHO = "WHO Expert Consultation on Rabies, third report (2018) — WHO Technical Report Series 1012"
CDC = "CDC / ACIP — Use of a Reduced (4-Dose) Vaccine Schedule for Postexposure Prophylaxis to Prevent Human Rabies"
IDSA = "IDSA — Practice Guidelines for the Diagnosis and Management of Skin and Soft Tissue Infections, 2014 update (Table 5)"
IR = "دستورالعمل کشوری پیشگیری و کنترل هاری، وزارت بهداشت، درمان و آموزش پزشکی"

# ---------------------------------------------------------------------------
# The shared spine. Every rabies lesson starts from the same twelve facts, so a
# student who meets these questions in any order builds one algorithm and not
# twenty fragments.
# ---------------------------------------------------------------------------
CORE_FA = [
    "هاری تقریباً **صد درصد کشنده** است — به‌محض شروع علائم، هیچ درمانی جواب نمی‌دهد.",
    "به همین دلیل، پروفیلاکسی پس از تماس (PEP) یک **فوریت** است، نه یک تصمیم قابل تعویق.",
    "⚠️ **اولین سؤالی که باید بپرسید این است: آیا این فرد قبلاً واکسن هاری زده است؟**",
    "همه‌ی الگوریتم روی همین یک سؤال می‌چرخد و بقیه‌ی جزئیات از آن بیرون می‌آید.",
    "**حالت اول — فرد قبلاً واکسینه نشده:**",
    "**ایمونوگلوبولین ضدهاری (RIG) با دوز ۲۰ واحد بر کیلوگرم** + **واکسن در روزهای ۰، ۳، ۷ و ۱۴**.",
    "دوز پنجم (روز ۲۸) فقط برای **افراد دچار نقص ایمنی** اضافه می‌شود.",
    "⚠️ **حالت دوم — فرد قبلاً واکسینه شده (پیش از تماس یا پس از تماس):**",
    "**فقط دو دوز واکسن، در روزهای ۰ و ۳** — و **هیچ ایمونوگلوبولینی داده نمی‌شود**.",
    "چرا RIG نه؟ چون فرد واکسینه‌شده **سلول خاطره** دارد و ظرف چند روز تیتر محافظ می‌سازد؛",
    "و RIG اضافی می‌تواند همین پاسخ خاطره‌ای را **سرکوب** کند.",
    "⚠️ **قاعده‌ی زمانی RIG: تا روز هفتم پس از اولین دوز واکسن، و نه بعد از آن.**",
    "پس از روز هفتم، آنتی‌بادی فعال خودِ بیمار در راه است و RIG دیگر سودی ندارد.",
    "**محل تزریق RIG**: تا جای ممکن **داخل و اطراف خود زخم** انفیلتره می‌شود، نه در عضله‌ی دور.",
    "چون کار RIG **خنثی کردن ویروس در همان محل ورود** است، پیش از آنکه به عصب برسد.",
    "⚠️ **بارداری هرگز منع مصرف نیست** — نه برای واکسن، نه برای ایمونوگلوبولین.",
    "**شست‌وشوی فوری زخم با آب و صابون به مدت ۱۵ دقیقه**، مؤثرترین تک‌اقدام است.",
    "⚠️ زخم گازگرفتگی **بخیه نمی‌شود** (مگر صورت، آن هم پس از شست‌وشوی فراوان و با تأخیر).",
]
CORE_EN = [
    "Rabies is essentially ONE HUNDRED PER CENT FATAL: once symptoms begin, no treatment works.",
    "That is why post-exposure prophylaxis (PEP) is an EMERGENCY, not a decision that can wait.",
    "WARNING: THE FIRST QUESTION TO ASK IS — HAS THIS PERSON EVER BEEN VACCINATED AGAINST RABIES?",
    "The whole algorithm turns on that one question; everything else follows from it.",
    "CASE ONE — THE PERSON HAS NEVER BEEN VACCINATED:",
    "RABIES IMMUNE GLOBULIN (RIG) 20 IU/KG plus VACCINE ON DAYS 0, 3, 7 AND 14.",
    "A fifth dose on day 28 is added only for the IMMUNOCOMPROMISED.",
    "WARNING, CASE TWO — THE PERSON HAS BEEN VACCINATED BEFORE (pre- or post-exposure):",
    "TWO DOSES OF VACCINE ONLY, ON DAYS 0 AND 3 — and NO IMMUNE GLOBULIN AT ALL.",
    "Why no RIG? Because a vaccinated person has MEMORY CELLS and makes a protective titre within days,",
    "and extra RIG can actually SUPPRESS that anamnestic response.",
    "WARNING, THE TIMING RULE FOR RIG: useful UP TO DAY 7 AFTER THE FIRST VACCINE DOSE, and not after.",
    "Beyond day 7 the patient's own active antibody is on its way and RIG no longer helps.",
    "WHERE RIG GOES: infiltrated INTO AND AROUND THE WOUND ITSELF as far as anatomically possible.",
    "Because RIG's job is to NEUTRALISE VIRUS AT THE POINT OF ENTRY before it reaches a nerve.",
    "WARNING: PREGNANCY IS NEVER A CONTRAINDICATION — neither to the vaccine nor to the immune globulin.",
    "IMMEDIATE WASHING OF THE WOUND WITH SOAP AND WATER FOR 15 MINUTES is the single most effective measure.",
    "WARNING: a bite wound IS NOT SUTURED (except on the face, and then only after copious irrigation and with delay).",
]

BITE_FA = [
    "**زخم گازگرفتگی یک عفونت پلی‌میکروبیال است** — به‌طور متوسط پنج گونه‌ی باکتری در هر زخم.",
    "⚠️ ارگانیسمی که هرگز نباید از قلم بیفتد **پاستورلا مولتوسیدا** است.",
    "پاستورلا در حدود **نیمی از گازگرفتگی‌های سگ** و **سه‌چهارم گازگرفتگی‌های گربه** جدا می‌شود.",
    "علامتش سرعت است: سلولیت دردناک ظرف **۱۲ تا ۲۴ ساعت** (گاهی ۳ تا ۶ ساعت).",
    "کنار آن: **استرپتوکوک‌ها، استافیلوکوک‌ها و بی‌هوازی‌های دهانی** حیوان.",
    "⚠️ **داروی انتخابی برای پروفیلاکسی و درمان: آموکسی‌سیلین-کلاوولانات.**",
    "چرا دقیقاً همین؟ چون تنها انتخاب خوراکیِ رایجی است که **هم پاستورلا، هم استرپ/استاف، هم بی‌هوازی‌ها** را می‌پوشاند.",
    "**داروهایی که برای گازگرفتگی نامناسب‌اند و باید بشناسید:**",
    "**سفالوسپورین نسل اول (سفالکسین، سفازولین)** ← پاستورلا را **نمی‌پوشاند**.",
    "**ماکرولیدها (اریترومایسین)** ← پوشش ناکافی برای فلور گازگرفتگی.",
    "**کلیندامایسین به‌تنهایی** ← بی‌هوازی‌ها را عالی می‌پوشاند ولی **پاستورلا را از دست می‌دهد**.",
    "**کوتریموکسازول به‌تنهایی** ← روی هوازی‌ها خوب است ولی روی **بی‌هوازی‌ها ضعیف**.",
    "⚠️ در آلرژی به پنی‌سیلین: **داکسی‌سیکلین**، یا **کینولون + مترونیدازول**، یا **موکسی‌فلوکساسین به‌تنهایی**.",
    "**چه کسی حتماً پروفیلاکسی می‌گیرد؟** زخم **دست** یا صورت یا ناحیه‌ی تناسلی،",
    "زخم **عمیق یا سوراخ‌شونده** (به‌ویژه گاز گربه)، درگیری استخوان/تاندون/مفصل،",
    "و بیمار **نقص‌ایمنی، اسپلنکتومی‌شده، سیروتیک یا دیابتی**.",
    "⚠️ و همیشه دو چیز دیگر را هم چک کنید: **وضعیت کزاز** و **خطر هاری**.",
]
BITE_EN = [
    "A BITE WOUND IS A POLYMICROBIAL INFECTION — on average five bacterial species per wound.",
    "WARNING: the organism that must never be missed is PASTEURELLA MULTOCIDA.",
    "Pasteurella is isolated from about HALF of dog bites and THREE QUARTERS of cat bites.",
    "Its signature is speed: painful cellulitis within 12 TO 24 HOURS (sometimes 3 to 6).",
    "Alongside it: STREPTOCOCCI, STAPHYLOCOCCI and the animal's ORAL ANAEROBES.",
    "WARNING: THE DRUG OF CHOICE FOR BOTH PROPHYLAXIS AND TREATMENT IS AMOXICILLIN-CLAVULANATE.",
    "Why exactly this one? It is the common oral agent that covers PASTEURELLA, STREP/STAPH AND ANAEROBES together.",
    "DRUGS THAT ARE WRONG FOR A BITE, AND YOU SHOULD RECOGNISE THEM:",
    "FIRST-GENERATION CEPHALOSPORINS (cephalexin, cefazolin) DO NOT COVER PASTEURELLA.",
    "MACROLIDES (erythromycin) give inadequate cover of bite flora.",
    "CLINDAMYCIN ALONE covers anaerobes beautifully but MISSES PASTEURELLA.",
    "CO-TRIMOXAZOLE ALONE is good against aerobes but POOR AGAINST ANAEROBES.",
    "WARNING, in penicillin allergy: DOXYCYCLINE, or a QUINOLONE PLUS METRONIDAZOLE, or MOXIFLOXACIN ALONE.",
    "WHO DEFINITELY GETS PROPHYLAXIS? Wounds of the HAND, face or genitals,",
    "DEEP OR PUNCTURE wounds (especially cat bites), involvement of bone, tendon or joint,",
    "and patients who are IMMUNOCOMPROMISED, ASPLENIC, CIRRHOTIC OR DIABETIC.",
    "WARNING, and always check two more things: TETANUS STATUS and RABIES RISK.",
]


# =========================================================== book:403
add("book:403", "case", "medium",
 "جنگلبانِ **کاملاً واکسینه‌شده** پس از حمله‌ی گرگ ← **فقط دو دوز واکسن (روز ۰ و ۳)، بدون ایمونوگلوبولین**.",
 "A FULLY VACCINATED forester after a wolf attack needs TWO DOSES OF VACCINE ONLY (days 0 and 3), WITHOUT immune globulin.",
 CORE_FA + [
  "در این سؤال، بیمار **سال گذشته دوره‌ی کامل واکسن هاری** را گرفته است.",
  "پس مستقیماً وارد **حالت دوم** الگوریتم می‌شویم: دو دوز واکسن در روزهای ۰ و ۳.",
  "⚠️ و **ایمونوگلوبولین داده نمی‌شود**، هرچند زخم عمیق و حیوان وحشی باشد.",
  "همین جاست که بیشتر دانشجویان اشتباه می‌کنند: فکر می‌کنند «گرگ» و «پارگی» یعنی خطر بیشتر یعنی RIG.",
  "ولی شدت زخم تعیین‌کننده‌ی **دسته‌ی تماس** است، نه تعیین‌کننده‌ی نیاز به RIG در فرد واکسینه.",
  "در فرد واکسینه، سیستم ایمنی **قبلاً آموزش دیده** و ظرف چند روز پاسخ خاطره‌ای می‌سازد.",
  "دادن RIG به چنین فردی نه‌تنها لازم نیست، بلکه می‌تواند همان پاسخ را **کند** کند.",
  "⚠️ نکته‌ی مکمل: اگر تماس **کمتر از سه ماه** پس از یک دوره‌ی کامل PEP رخ دهد،",
  "حتی همان دو دوز هم لازم نیست و تنها مراقبت زخم کافی است.",
  "**گرگ، شغال و روباه در ایران از مخازن مهم هاری‌اند** و گازگرفتگی‌شان همیشه تماس جدی است.",
  "ولی «جدی بودن تماس» یعنی **حتماً PEP بده**، نه «الگوریتم را عوض کن».",
 ],
 CORE_EN + [
  "In this question the patient completed A FULL COURSE OF RABIES VACCINE LAST YEAR.",
  "So we go straight to CASE TWO of the algorithm: two doses of vaccine on days 0 and 3.",
  "WARNING, and NO IMMUNE GLOBULIN, however deep the wound and however wild the animal.",
  "This is where most students go wrong: they read 'wolf' and 'laceration' as 'more danger, therefore RIG'.",
  "But wound severity determines the EXPOSURE CATEGORY, not the need for RIG in a vaccinated person.",
  "In a vaccinated person the immune system is ALREADY PRIMED and mounts a memory response within days.",
  "Giving RIG to such a person is not merely unnecessary — it can BLUNT that very response.",
  "WARNING, a supplementary point: if the exposure occurs LESS THAN THREE MONTHS after a full PEP course,",
  "even those two doses are unnecessary and wound care alone suffices.",
  "WOLVES, JACKALS AND FOXES ARE IMPORTANT RABIES RESERVOIRS IN IRAN, so their bites are always serious exposures.",
  "But 'serious exposure' means DEFINITELY GIVE PEP, not 'change the algorithm'.",
 ],
 "بیمار **سال قبل دوره‌ی کامل واکسیناسیون هاری** را گرفته است، و همین یک جمله تکلیف کل سؤال را روشن می‌کند.\n\n"
 "⚠️ **قاعده‌ی مرکزی هاری:** پیش از هر چیز بپرسید **آیا فرد قبلاً واکسینه شده است؟**\n\n"
 "**اگر واکسینه نشده:** ایمونوگلوبولین ضدهاری **۲۰ واحد بر کیلوگرم** داخل و اطراف زخم + واکسن در روزهای **۰، ۳، ۷ و ۱۴**.\n\n"
 "**اگر واکسینه شده:** **فقط دو دوز واکسن در روزهای ۰ و ۳** و **بدون هیچ ایمونوگلوبولینی**.\n\n"
 "چرا در فرد واکسینه RIG نمی‌دهیم؟ چون او **سلول خاطره** دارد؛ ظرف چند روز تیتر محافظ می‌سازد و ایمونوگلوبولین اضافی می‌تواند همین پاسخ خاطره‌ای را **سرکوب** کند. ایمونوگلوبولین برای کسی است که هنوز هیچ ایمنی‌ای ندارد و باید در فاصله‌ی بین گزش تا ساخته شدن آنتی‌بادی، ویروس را در محل زخم خنثی کند.\n\n"
 "⚠️ **تله‌ی این سؤال:** «حمله‌ی گرگ» و «پارگی ساق» ذهن را به سمت «خطر بیشتر، پس ایمونوگلوبولین هم بدهیم» می‌برد. اما شدت زخم فقط **دسته‌ی تماس** را تعیین می‌کند و تعیین می‌کند که **حتماً** باید PEP داد؛ الگوریتم را عوض نمی‌کند.\n\n"
 "و فراموش نکنید که مؤثرترین تک‌اقدام، **شست‌وشوی فوری زخم با آب و صابون به مدت ۱۵ دقیقه** است — کاری که پیش از هر تزریقی انجام می‌شود.",
 "The patient COMPLETED A FULL RABIES VACCINE COURSE LAST YEAR, and that single sentence settles the question.\n\n"
 "WARNING, THE CENTRAL RABIES RULE: first ask, HAS THIS PERSON BEEN VACCINATED BEFORE?\n\n"
 "IF NOT VACCINATED: rabies immune globulin 20 IU/kg into and around the wound, plus vaccine on days 0, 3, 7 and 14.\n\n"
 "IF PREVIOUSLY VACCINATED: TWO DOSES OF VACCINE ONLY, on days 0 and 3, and NO immune globulin.\n\n"
 "Why no RIG in a vaccinated person? Because they have MEMORY CELLS, produce a protective titre within days, and extra immune globulin can SUPPRESS that anamnestic response. RIG exists for the person with no immunity at all, to neutralise virus at the wound during the gap before antibody appears.\n\n"
 "WARNING, THE TRAP IN THIS QUESTION: 'wolf attack' and 'leg laceration' pull the mind towards 'more danger, so add immune globulin too'. But wound severity only sets the EXPOSURE CATEGORY and tells you that PEP is definitely required; it does not change the algorithm.\n\n"
 "And do not forget the single most effective measure: IMMEDIATE WASHING OF THE WOUND WITH SOAP AND WATER FOR 15 MINUTES, done before any injection.",
 ["ایمونوگلوبولین در فرد قبلاً واکسینه‌شده اندیکاسیون ندارد و می‌تواند پاسخ خاطره‌ای را سرکوب کند.",
  "پاسخ صحیح — فرد واکسینه‌شده فقط دو دوز واکسن در روزهای ۰ و ۳ می‌گیرد.",
  "دوره‌ی پنج‌دوزی برای فرد واکسینه‌نشده (و آن هم امروزه چهار دوز) است، نه برای فرد واکسینه.",
  "هم پنج دوز اضافی است و هم ایمونوگلوبولین در فرد واکسینه‌شده اندیکاسیون ندارد."],
 ["Immune globulin is not indicated in a previously vaccinated person and may suppress the memory response.",
  "Correct — a previously vaccinated person receives only two vaccine doses, on days 0 and 3.",
  "The five-dose course belongs to the unvaccinated (and is four doses in modern practice), not to the vaccinated.",
  "Both wrong: five doses is excessive and immune globulin is not indicated in a vaccinated person."],
 "واکسینه‌ی قبلی ← **دو دوز، روز ۰ و ۳، بدون RIG**. واکسینه‌نشده ← **RIG ۲۰ IU/kg + واکسن روز ۰، ۳، ۷، ۱۴**.",
 "Previously vaccinated: TWO doses, days 0 and 3, NO RIG. Never vaccinated: RIG 20 IU/kg plus vaccine on days 0, 3, 7, 14.",
 [H204, WHO, IR])


# =========================================================== book:409
add("book:409", "recall", "medium",
 "فرد **واکسینه‌نشده** ← **چهار نوبت واکسن (۰، ۳، ۷، ۱۴) به‌علاوه‌ی ایمونوگلوبولین**.",
 "An UNVACCINATED person needs FOUR VACCINE DOSES (0, 3, 7, 14) PLUS immune globulin.",
 CORE_FA + [
  "این سؤال چهار جمله‌ی کلی درباره‌ی پروفیلاکسی می‌گذارد و از شما می‌خواهد **درستش را بشناسید**.",
  "گزینه‌ی درست همان **حالت اول** الگوریتم است: واکسینه‌نشده ← **چهار نوبت واکسن + ایمونوگلوبولین**.",
  "⚠️ چرا امروز **چهار** دوز و نه پنج؟ این یک تغییر مهم و نسبتاً جدید است.",
  "تا سال ۲۰۱۰ رژیم استاندارد **پنج دوز** بود: روزهای ۰، ۳، ۷، ۱۴ و ۲۸.",
  "بررسی داده‌ها نشان داد **تیتر محافظ عملاً تا روز ۱۴ ساخته می‌شود** و دوز پنجم چیزی اضافه نمی‌کند.",
  "پس ACIP رژیم را به **چهار دوز** کوتاه کرد — با یک استثنای مهم.",
  "⚠️ **استثنا: در فرد دچار نقص ایمنی همچنان پنج دوز (تا روز ۲۸) داده می‌شود**،",
  "چون پاسخ ایمنی او کندتر و ضعیف‌تر است و به تحریک بیشتری نیاز دارد.",
  "گزینه‌ای که «پنج نوبت واکسن» را **بدون ایمونوگلوبولین** پیشنهاد می‌کند دو خطا دارد،",
  "و مهم‌ترینش نبودن RIG است: در فرد واکسینه‌نشده، **حذف RIG خطرناک‌ترین اشتباه** است.",
  "چون در هفته‌ی اول هنوز هیچ آنتی‌بادی فعالی وجود ندارد و ویروس همان‌جا فرصت ورود به عصب دارد.",
 ],
 CORE_EN + [
  "This question offers four general statements about prophylaxis and asks which is TRUE.",
  "The right one is simply CASE ONE of the algorithm: unvaccinated -> FOUR VACCINE DOSES PLUS IMMUNE GLOBULIN.",
  "WARNING, why FOUR doses today and not five? This is an important and fairly recent change.",
  "Until 2010 the standard regimen was FIVE doses: days 0, 3, 7, 14 and 28.",
  "Review of the data showed that A PROTECTIVE TITRE IS ESSENTIALLY REACHED BY DAY 14 and the fifth dose adds nothing.",
  "So ACIP shortened the schedule to FOUR doses — with one important exception.",
  "WARNING, THE EXCEPTION: THE IMMUNOCOMPROMISED STILL RECEIVE FIVE DOSES, through day 28,",
  "because their immune response is slower and weaker and needs the extra stimulus.",
  "The option offering five doses WITHOUT immune globulin contains two errors,",
  "and the graver one is the missing RIG: in an unvaccinated person, OMITTING RIG IS THE MOST DANGEROUS MISTAKE.",
  "Because in the first week there is still no active antibody, and the virus has its chance to enter a nerve.",
 ],
 "این سؤال از شما می‌خواهد **قاعده‌ی کلی** را بشناسید، بدون بیمار و بدون داستان.\n\n"
 "**فرد واکسینه‌نشده:** **ایمونوگلوبولین ضدهاری** + **چهار نوبت واکسن در روزهای ۰، ۳، ۷ و ۱۴**.\n\n"
 "**فرد واکسینه‌شده:** **دو نوبت واکسن در روزهای ۰ و ۳**، **بدون ایمونوگلوبولین**.\n\n"
 "⚠️ **چرا چهار دوز و نه پنج؟** تا سال ۲۰۱۰ رژیم پنج‌دوزی (۰، ۳، ۷، ۱۴، ۲۸) استاندارد بود. بازبینی داده‌های ایمنی‌زایی نشان داد **تیتر محافظ عملاً تا روز ۱۴ ساخته می‌شود** و دوز روز ۲۸ سودی اضافه نمی‌کند؛ پس حذف شد. **استثنا:** فرد دچار **نقص ایمنی** همچنان پنج دوز می‌گیرد.\n\n"
 "⚠️ **و مهم‌ترین نکته‌ی این سؤال:** در فرد واکسینه‌نشده، **حذف ایمونوگلوبولین بدترین خطاست**. در هفته‌ی اول هیچ آنتی‌بادی فعالی وجود ندارد؛ RIG دقیقاً برای همین پنجره‌ی خالی ساخته شده و باید **داخل و اطراف خود زخم** انفیلتره شود تا ویروس را پیش از رسیدن به انتهای عصبی خنثی کند.\n\n"
 "پس گزینه‌ای که «پنج نوبت واکسن به‌تنهایی» را پیشنهاد می‌دهد، نه‌فقط از نظر تعداد دوز قدیمی است، بلکه از نظر بالینی **ناقص و خطرناک** است.",
 "This question asks you to recognise THE GENERAL RULE, with no patient and no story.\n\n"
 "UNVACCINATED PERSON: rabies immune globulin PLUS four vaccine doses on days 0, 3, 7 and 14.\n\n"
 "PREVIOUSLY VACCINATED PERSON: two vaccine doses on days 0 and 3, with NO immune globulin.\n\n"
 "WARNING, WHY FOUR DOSES AND NOT FIVE? Until 2010 the five-dose schedule (0, 3, 7, 14, 28) was standard. Review of immunogenicity data showed that A PROTECTIVE TITRE IS ESSENTIALLY REACHED BY DAY 14 and the day-28 dose adds nothing, so it was dropped. THE EXCEPTION: the IMMUNOCOMPROMISED still receive five doses.\n\n"
 "WARNING, AND THE KEY POINT OF THIS QUESTION: in an unvaccinated person, OMITTING THE IMMUNE GLOBULIN IS THE WORST ERROR. In the first week there is no active antibody at all; RIG exists precisely for that empty window and must be infiltrated INTO AND AROUND THE WOUND to neutralise virus before it reaches a nerve ending.\n\n"
 "So the option offering 'five doses of vaccine' alone is not merely out of date on the dose count — it is clinically INCOMPLETE AND DANGEROUS.",
 ["در فرد کاملاً واکسینه‌شده ایمونوگلوبولین اندیکاسیون ندارد؛ فقط دو دوز واکسن کافی است.",
  "پاسخ صحیح — واکسینه‌نشده: چهار نوبت واکسن در روزهای ۰، ۳، ۷ و ۱۴ به‌علاوه‌ی ایمونوگلوبولین.",
  "پنج نوبت واکسن بدون ایمونوگلوبولین، در فرد واکسینه‌نشده ناقص و خطرناک است.",
  "سه نوبت واکسن رژیم شناخته‌شده‌ی پروفیلاکسی پس از تماس نیست؛ سه‌دوزی رژیم پیش از تماس است."],
 ["In a fully vaccinated person immune globulin is not indicated; two vaccine doses suffice.",
  "Correct — unvaccinated: four vaccine doses on days 0, 3, 7 and 14 plus immune globulin.",
  "Five doses without immune globulin is incomplete and dangerous in an unvaccinated person.",
  "A three-dose course is not a recognised post-exposure regimen; three doses is the pre-exposure schedule."],
 "واکسینه‌نشده ← **RIG + واکسن ۰/۳/۷/۱۴**. نقص ایمنی ← دوز پنجم روز **۲۸** هم اضافه می‌شود.",
 "Unvaccinated: RIG plus vaccine on days 0/3/7/14. Immunocompromised: add a fifth dose on day 28.",
 [H204, CDC, WHO])


# =========================================================== book:410
add("book:410", "case", "easy",
 "کودک واکسینه‌نشده با گزش **سگ ولگردِ فراری** ← **سرم ضدهاری + دوره‌ی کامل واکسن**.",
 "An unvaccinated child bitten by a STRAY DOG THAT HAS RUN AWAY needs BOTH immune globulin AND a full vaccine course.",
 CORE_FA + [
  "کودک **۱۰ ساله**، گزش **دو ساعت پیش**، **پارگی پوست ساعد**، و **سگ فرار کرده است**.",
  "سه نکته‌ی این داستان هر سه در یک جهت‌اند:",
  "یک — **سابقه‌ی واکسیناسیون ذکر نشده** ← فرض بر واکسینه‌نبودن ← حالت اول الگوریتم.",
  "دو — **پارگی پوست** یعنی تماس **دسته‌ی سه** (خراش یا گاز نافذ پوست) ← **RIG لازم است**.",
  "سه — ⚠️ **سگ فرار کرده** ← امکان **مشاهده‌ی ده‌روزه‌ی حیوان** وجود ندارد.",
  "قاعده‌ی مشاهده‌ی ده‌روزه را بدانید: اگر سگ یا گربه‌ی **خانگیِ در دسترس** باشد،",
  "می‌توان حیوان را ۱۰ روز تحت نظر گرفت؛ اگر سالم ماند، در لحظه‌ی گاز گرفتن ناقل نبوده است.",
  "⚠️ ولی حتی در آن حالت هم **PEP بلافاصله شروع می‌شود** و در صورت سالم ماندن حیوان قطع می‌گردد.",
  "وقتی حیوان **در دسترس نیست**، هیچ راهی برای رد کردن هاری نمی‌ماند و درمان کامل قطعی است.",
  "پس پاسخ: **سرم (ایمونوگلوبولین) ضدهاری + شروع و تکمیل دوره‌ی کامل واکسیناسیون**.",
  "⚠️ و نکته‌ای که گزینه‌ی «ترمیم زخم» را رد می‌کند: زخم گازگرفتگی **بخیه نمی‌شود**.",
  "بخیه، ویروس و باکتری را در فضای بسته حبس می‌کند و هم خطر هاری و هم خطر عفونت را بالا می‌برد.",
 ],
 CORE_EN + [
  "A 10-YEAR-OLD CHILD, bitten TWO HOURS AGO, with a SKIN LACERATION of the forearm, and THE DOG HAS RUN AWAY.",
  "Three features of the story all point the same way:",
  "One — NO VACCINATION HISTORY IS MENTIONED, so assume unvaccinated: case one of the algorithm.",
  "Two — BROKEN SKIN means a CATEGORY III exposure (scratch or bite penetrating the skin), so RIG IS REQUIRED.",
  "Three — WARNING, THE DOG HAS ESCAPED, so THE TEN-DAY OBSERVATION OF THE ANIMAL IS IMPOSSIBLE.",
  "Know the ten-day rule: if the dog or cat is DOMESTIC AND AVAILABLE,",
  "it can be observed for 10 days; if it stays well, it was not shedding virus at the moment of the bite.",
  "WARNING, but even then PEP IS STARTED IMMEDIATELY and stopped only if the animal remains healthy.",
  "When the animal is NOT AVAILABLE there is no way to exclude rabies, and full treatment is mandatory.",
  "So the answer is: RABIES IMMUNE GLOBULIN PLUS starting and completing a full vaccine course.",
  "WARNING, and the point that rules out 'repair the wound': A BITE WOUND IS NOT SUTURED.",
  "Suturing traps virus and bacteria in a closed space and raises both the rabies risk and the infection risk.",
 ],
 "این سؤال ساده به نظر می‌رسد ولی سه اطلاعات کلیدی را کنار هم گذاشته است:\n\n"
 "**۱. سابقه‌ی واکسیناسیون ذکر نشده** ← فرض بر واکسینه‌نبودن ← نیاز به **رژیم کامل**.\n"
 "**۲. پوست پاره شده** ← تماس **دسته‌ی سه** ← **ایمونوگلوبولین الزامی است**.\n"
 "**۳. سگ فرار کرده** ← **مشاهده‌ی ده‌روزه‌ی حیوان ممکن نیست** ← راهی برای رد کردن هاری نمانده.\n\n"
 "پس درمان کامل: **سرم (ایمونوگلوبولین) ضدهاری ۲۰ واحد بر کیلوگرم داخل و اطراف زخم + واکسن در روزهای ۰، ۳، ۷ و ۱۴**.\n\n"
 "⚠️ **قاعده‌ی مشاهده‌ی ده‌روزه را دقیق بدانید:** فقط برای **سگ و گربه‌ی در دسترس** کاربرد دارد. اگر حیوان ۱۰ روز سالم بماند، در لحظه‌ی گاز گرفتن ویروس دفع نمی‌کرده و پروفیلاکسی قطع می‌شود. اما **شروع پروفیلاکسی هرگز منتظر این ده روز نمی‌ماند** — شروع می‌کنیم و در صورت سالم ماندن حیوان قطع می‌کنیم.\n\n"
 "⚠️ **و نکته‌ی جراحی مهم:** زخم گازگرفتگی **بخیه نمی‌شود**. بستن زخم، ویروس و باکتری‌های بی‌هوازی را در فضای بسته محبوس می‌کند. تنها استثنای نسبی، زخم‌های صورت است، آن هم پس از **شست‌وشوی بسیار فراوان** و ترجیحاً با تأخیر.",
 "This looks like an easy question but it places three key facts side by side:\n\n"
 "1. NO VACCINATION HISTORY is given, so assume unvaccinated: a FULL regimen is required.\n"
 "2. THE SKIN IS BROKEN, so this is a CATEGORY III exposure: IMMUNE GLOBULIN IS MANDATORY.\n"
 "3. THE DOG HAS ESCAPED, so TEN-DAY OBSERVATION IS IMPOSSIBLE and rabies cannot be excluded.\n\n"
 "Hence full treatment: RABIES IMMUNE GLOBULIN 20 IU/kg into and around the wound PLUS vaccine on days 0, 3, 7 and 14.\n\n"
 "WARNING, KNOW THE TEN-DAY RULE PRECISELY: it applies only to an AVAILABLE DOG OR CAT. If the animal is still well after 10 days it was not shedding virus when it bit, and prophylaxis is stopped. But PROPHYLAXIS IS NEVER DELAYED WAITING FOR THOSE TEN DAYS — you start, and you stop if the animal stays healthy.\n\n"
 "WARNING, AND AN IMPORTANT SURGICAL POINT: a bite wound IS NOT SUTURED. Closing it traps virus and anaerobic bacteria in a sealed space. The only partial exception is a facial wound, and then only after very copious irrigation and preferably with delay.",
 ["پاسخ صحیح — بیمار واکسینه‌نشده با پارگی پوست و حیوان غیرقابل‌دسترس، هم سرم و هم دوره‌ی کامل واکسن می‌خواهد.",
  "واکسن به‌تنهایی کافی نیست؛ در تماس دسته‌ی سه در فرد واکسینه‌نشده، ایمونوگلوبولین حذف‌شدنی نیست.",
  "ترمیم و بخیه‌ی زخم گازگرفتگی توصیه نمی‌شود و ویروس و باکتری را در زخم حبس می‌کند.",
  "سرم به‌تنهایی فقط ایمنی گذرا می‌دهد؛ بدون واکسن، ایمنی فعال و پایدار ساخته نمی‌شود."],
 ["Correct — an unvaccinated patient with broken skin and an unavailable animal needs both serum and a full vaccine course.",
  "Vaccine alone is not enough; in a category III exposure in an unvaccinated person, immune globulin cannot be omitted.",
  "Suturing a bite wound is not recommended and traps virus and bacteria inside the wound.",
  "Serum alone gives only transient immunity; without vaccine no durable active immunity is generated."],
 "حیوان **در دسترس نیست** ← هاری قابل رد کردن نیست ← **رژیم کامل**. زخم گازگرفتگی **بخیه نمی‌شود**.",
 "Animal not available means rabies cannot be excluded, so give the full regimen. And a bite wound is not sutured.",
 [H204, WHO, IR])


# =========================================================== book:411
add("book:411", "case", "medium",
 "**بارداری هرگز منع تجویز واکسن هاری نیست** — همان **چهار دوز روزهای ۰، ۳، ۷ و ۱۴**.",
 "PREGNANCY IS NEVER A CONTRAINDICATION to rabies vaccine — the same FOUR DOSES on days 0, 3, 7 and 14.",
 CORE_FA + [
  "این سؤال یک چیز را می‌سنجد: آیا **بارداری** الگوریتم را عوض می‌کند؟ پاسخ: **نه**.",
  "⚠️ **واکسن هاری یک واکسن غیرفعال (inactivated) است** و ویروس زنده ندارد.",
  "پس هیچ خطر تئوریکی برای جنین از راه عفونت واکسنی وجود ندارد.",
  "ایمونوگلوبولین هم فرآورده‌ی آنتی‌بادی است و برای جنین بی‌خطر.",
  "در مقابل، هاری در مادر یعنی **مرگ حتمی مادر و در نتیجه‌ی آن، جنین**.",
  "پس محاسبه‌ی سود و زیان اصلاً محاسبه نیست: پروفیلاکسی **بی‌درنگ و کامل** انجام می‌شود.",
  "⚠️ همین منطق درباره‌ی **شیردهی** هم صادق است — منعی وجود ندارد.",
  "**شماره‌ی روزها را دقیق حفظ کنید: ۰، ۳، ۷ و ۱۴.**",
  "گزینه‌ای که روزهای ۰، ۳ و ۷ (سه دوز) را می‌دهد رژیم **پیش از تماس** را با پس از تماس اشتباه گرفته.",
  "گزینه‌ی پنج‌دوزی (تا روز ۲۸) رژیم قدیمی است و امروز فقط برای **نقص ایمنی** می‌ماند.",
  "⚠️ توجه: این سؤال درباره‌ی **واکسن** پرسیده است؛ در تماس دسته‌ی سه، ایمونوگلوبولین هم لازم است.",
 ],
 CORE_EN + [
  "This question tests one thing: does PREGNANCY change the algorithm? The answer is NO.",
  "WARNING: THE RABIES VACCINE IS AN INACTIVATED VACCINE and contains no live virus.",
  "So there is no theoretical risk of vaccine infection reaching the fetus.",
  "Immune globulin is likewise an antibody product and is safe in pregnancy.",
  "Against that, rabies in the mother means CERTAIN DEATH OF THE MOTHER AND THEREFORE OF THE FETUS.",
  "So the risk-benefit calculation is not really a calculation: give prophylaxis IMMEDIATELY AND IN FULL.",
  "WARNING, the same logic applies to BREASTFEEDING — there is no contraindication.",
  "MEMORISE THE DAYS EXACTLY: 0, 3, 7 AND 14.",
  "The option offering days 0, 3 and 7 (three doses) confuses the PRE-EXPOSURE schedule with post-exposure.",
  "The five-dose option (through day 28) is the older regimen, now reserved for the IMMUNOCOMPROMISED.",
  "WARNING, note: this question asks about the VACCINE; in a category III exposure immune globulin is also needed.",
 ],
 "⚠️ **بارداری هیچ‌گاه منع مصرف پروفیلاکسی هاری نیست** — نه واکسن، نه ایمونوگلوبولین.\n\n"
 "دلیلش دو چیز است:\n\n"
 "**۱. واکسن هاری غیرفعال (inactivated) است** و ویروس زنده ندارد؛ پس خطر عفونت واکسنی برای جنین وجود ندارد. ایمونوگلوبولین هم صرفاً یک فرآورده‌ی آنتی‌بادی است.\n\n"
 "**۲. هاری تقریباً صد درصد کشنده است.** مرگ مادر یعنی مرگ جنین. هیچ ملاحظه‌ی تئوریکی نمی‌تواند با این وزنه برابری کند.\n\n"
 "**پس رژیم دقیقاً همان رژیم فرد غیرباردار است:**\n\n"
 "**واکسینه‌نشده:** ایمونوگلوبولین **۲۰ واحد بر کیلوگرم** + واکسن روزهای **۰، ۳، ۷ و ۱۴**\n"
 "**واکسینه‌شده:** فقط دو دوز، روزهای **۰ و ۳**\n\n"
 "⚠️ **دو گزینه‌ی انحرافی این سؤال را بشناسید:**\n\n"
 "**«سه دوز در روزهای ۰، ۳ و ۷»** ← این رژیم **پیش از تماس** (pre-exposure) است، نه پس از تماس. اشتباه گرفتن این دو یکی از شایع‌ترین خطاهای دانشجویی است.\n\n"
 "**«پنج دوز تا روز ۲۸»** ← رژیم قدیمی. از سال ۲۰۱۰ به چهار دوز کوتاه شد، چون تیتر محافظ تا روز ۱۴ ساخته می‌شود. دوز پنجم امروز فقط برای **افراد دچار نقص ایمنی** باقی مانده است.",
 "WARNING: PREGNANCY IS NEVER A CONTRAINDICATION to rabies prophylaxis — neither vaccine nor immune globulin.\n\n"
 "Two reasons:\n\n"
 "1. THE RABIES VACCINE IS INACTIVATED and contains no live virus, so there is no risk of vaccine infection to the fetus. Immune globulin is simply an antibody preparation.\n\n"
 "2. RABIES IS ESSENTIALLY ONE HUNDRED PER CENT FATAL. The mother's death is the fetus's death. No theoretical concern can outweigh that.\n\n"
 "SO THE REGIMEN IS EXACTLY THAT OF A NON-PREGNANT PERSON:\n\n"
 "UNVACCINATED: immune globulin 20 IU/kg plus vaccine on days 0, 3, 7 and 14.\n"
 "PREVIOUSLY VACCINATED: two doses only, days 0 and 3.\n\n"
 "WARNING, RECOGNISE THE TWO DISTRACTORS:\n\n"
 "'THREE DOSES ON DAYS 0, 3 AND 7' is the PRE-EXPOSURE schedule, not post-exposure. Confusing the two is one of the commonest student errors.\n\n"
 "'FIVE DOSES THROUGH DAY 28' is the old regimen. It was shortened to four doses in 2010 because a protective titre is reached by day 14; the fifth dose now remains only for the IMMUNOCOMPROMISED.",
 ["واکسن هاری در بارداری ممنوع نیست؛ واکسن غیرفعال است و هاری بدون درمان کشنده است.",
  "سه دوز در روزهای ۰، ۳ و ۷ رژیم پیش از تماس است، نه پروفیلاکسی پس از تماس.",
  "رژیم پنج‌دوزی تا روز ۲۸ رژیم قدیمی است و امروز فقط برای افراد دچار نقص ایمنی به کار می‌رود.",
  "پاسخ صحیح — چهار دوز در روزهای ۰، ۳، ۷ و ۱۴، دقیقاً مانند فرد غیرباردار."],
 ["The rabies vaccine is not forbidden in pregnancy; it is inactivated, and untreated rabies is fatal.",
  "Three doses on days 0, 3 and 7 is the pre-exposure schedule, not post-exposure prophylaxis.",
  "The five-dose schedule through day 28 is the older regimen, now used only for the immunocompromised.",
  "Correct — four doses on days 0, 3, 7 and 14, exactly as in a non-pregnant person."],
 "بارداری الگوریتم هاری را **عوض نمی‌کند**. پس از تماس = **۰، ۳، ۷، ۱۴**؛ پیش از تماس = **۰، ۷، ۲۱ یا ۲۸**.",
 "Pregnancy does not change the rabies algorithm. Post-exposure is days 0, 3, 7, 14; pre-exposure is days 0, 7 and 21 or 28.",
 [H204, WHO, IR])


# =========================================================== book:412
add("book:412", "recall", "easy",
 "واکسینه‌نشده ← **چهار نوبت واکسن (۰، ۳، ۷، ۱۴)** + **یک نوبت ایمونوگلوبولین در روز اول**.",
 "Unvaccinated: FOUR vaccine doses (0, 3, 7, 14) plus ONE dose of immune globulin on day one.",
 CORE_FA + [
  "این سؤال دقیقاً همان قاعده‌ی حالت اول را می‌پرسد، ولی روی **تعداد دوز ایمونوگلوبولین** حساس است.",
  "⚠️ **ایمونوگلوبولین ضدهاری فقط یک بار در تمام عمر داده می‌شود** — همان روز صفر.",
  "چرا فقط یک بار؟ چون کارش پر کردن **یک پنجره‌ی زمانی مشخص** است، نه ایمن‌سازی مداوم.",
  "آن پنجره از لحظه‌ی گزش تا زمانی است که واکسن آنتی‌بادی فعال بسازد (حدود ۷ تا ۱۴ روز).",
  "گزینه‌ای که **دو نوبت ایمونوگلوبولین در روزهای ۰ و ۳** می‌دهد، همین را نمی‌داند.",
  "⚠️ و خطر واقعی دارد: **RIG اضافی پاسخ آنتی‌بادی واکسن را سرکوب می‌کند**.",
  "به همین دلیل هم دوز **۲۰ واحد بر کیلوگرم** یک سقف است، نه یک پیشنهاد؛ بیشتر از آن ضرر دارد.",
  "**تمام دوز محاسبه‌شده تا جای ممکن داخل و اطراف زخم انفیلتره می‌شود.**",
  "اگر زخم کوچک است، همان مقدار که جا می‌شود تزریق می‌شود (بدون ایجاد سندرم کمپارتمان).",
  "اگر زخم‌ها بزرگ یا متعددند، RIG را می‌توان با **نرمال سالین رقیق** کرد تا همه‌ی زخم‌ها پوشش یابند.",
  "⚠️ RIG و واکسن **هرگز در یک سرنگ یا یک محل** تزریق نمی‌شوند.",
 ],
 CORE_EN + [
  "This question asks the same case-one rule, but it is sensitive to THE NUMBER OF IMMUNE GLOBULIN DOSES.",
  "WARNING: RABIES IMMUNE GLOBULIN IS GIVEN ONLY ONCE IN A LIFETIME — on day zero.",
  "Why only once? Because its job is to fill A SINGLE DEFINED TIME WINDOW, not to immunise continuously.",
  "That window runs from the moment of the bite until the vaccine generates active antibody (about 7 to 14 days).",
  "The option offering TWO doses of immune globulin on days 0 and 3 does not know this.",
  "WARNING, and it carries real harm: EXCESS RIG SUPPRESSES THE VACCINE'S ANTIBODY RESPONSE.",
  "That is also why 20 IU/KG is a CEILING and not a suggestion; more than that does damage.",
  "THE WHOLE CALCULATED DOSE IS INFILTRATED INTO AND AROUND THE WOUND as far as possible.",
  "If the wound is small, inject as much as fits without creating a compartment syndrome.",
  "If wounds are large or multiple, RIG may be DILUTED WITH SALINE so every wound is covered.",
  "WARNING: RIG and vaccine are NEVER given in the same syringe or at the same site.",
 ],
 "پاسخ همان قاعده‌ی پایه است: **فرد واکسینه‌نشده ← چهار نوبت واکسن در روزهای ۰، ۳، ۷ و ۱۴ + یک نوبت ایمونوگلوبولین در روز اول**.\n\n"
 "اما نکته‌ای که این سؤال روی آن دست گذاشته، **تعداد دوز ایمونوگلوبولین** است.\n\n"
 "⚠️ **ایمونوگلوبولین ضدهاری فقط یک بار، آن هم در روز صفر، تجویز می‌شود.** دلیلش را بفهمید تا حفظ نکنید: کار RIG پر کردن **پنجره‌ی زمانیِ بین گزش و ساخته شدن آنتی‌بادی فعال** است. آن پنجره حدود ۷ تا ۱۴ روز طول می‌کشد و با یک تزریق پوشیده می‌شود.\n\n"
 "**دادن دوز دوم نه‌تنها بی‌فایده، بلکه مضر است:** آنتی‌بادی غیرفعال اضافی، آنتی‌ژن واکسن را خنثی می‌کند و **پاسخ ایمنی فعال بیمار را سرکوب می‌کند**. به همین دلیل دوز **۲۰ واحد بر کیلوگرم** یک **سقف** است، نه یک حداقل.\n\n"
 "**نحوه‌ی تزریق:** تمام دوز محاسبه‌شده تا جای ممکن **داخل و اطراف خود زخم** انفیلتره می‌شود، چون هدف خنثی کردن ویروس در محل ورود است. اگر زخم‌ها بزرگ یا متعددند، می‌توان RIG را با **نرمال سالین رقیق** کرد. ⚠️ و هرگز RIG و واکسن را در **یک سرنگ یا یک محل** تزریق نکنید.",
 "The answer is the basic rule: AN UNVACCINATED PERSON RECEIVES FOUR VACCINE DOSES ON DAYS 0, 3, 7 AND 14 PLUS ONE DOSE OF IMMUNE GLOBULIN ON DAY ONE.\n\n"
 "But the point this question presses on is THE NUMBER OF IMMUNE GLOBULIN DOSES.\n\n"
 "WARNING: RABIES IMMUNE GLOBULIN IS GIVEN ONCE ONLY, ON DAY ZERO. Understand why rather than memorising it: RIG's job is to fill THE WINDOW BETWEEN THE BITE AND THE APPEARANCE OF ACTIVE ANTIBODY. That window lasts about 7 to 14 days and is covered by a single injection.\n\n"
 "A SECOND DOSE IS NOT MERELY USELESS BUT HARMFUL: excess passive antibody neutralises vaccine antigen and SUPPRESSES THE PATIENT'S OWN ACTIVE RESPONSE. That is why 20 IU/KG IS A CEILING, not a minimum.\n\n"
 "HOW IT IS GIVEN: the whole calculated dose is infiltrated INTO AND AROUND THE WOUND as far as possible, because the aim is to neutralise virus at the point of entry. For large or multiple wounds RIG may be DILUTED WITH SALINE. WARNING, and never give RIG and vaccine in the same syringe or at the same site.",
 ["سه نوبت واکسن رژیم پس از تماس نیست؛ سه‌دوزی مربوط به پروفیلاکسی پیش از تماس است.",
  "پنج نوبت واکسن رژیم قدیمی است و امروز فقط برای افراد دچار نقص ایمنی به کار می‌رود.",
  "پاسخ صحیح — چهار نوبت واکسن در روزهای ۰، ۳، ۷ و ۱۴ به‌همراه یک نوبت ایمونوگلوبولین در روز اول.",
  "دو نوبت ایمونوگلوبولین نادرست است؛ RIG فقط یک بار داده می‌شود و دوز اضافی پاسخ واکسن را سرکوب می‌کند."],
 ["Three vaccine doses is not a post-exposure regimen; three doses belongs to pre-exposure prophylaxis.",
  "Five doses is the older regimen, now used only for the immunocompromised.",
  "Correct — four vaccine doses on days 0, 3, 7 and 14 with one dose of immune globulin on day one.",
  "Two doses of immune globulin is wrong; RIG is given once only, and extra doses suppress the vaccine response."],
 "RIG **یک بار، روز صفر، ۲۰ IU/kg، داخل زخم**. دوز اضافی، پاسخ واکسن را سرکوب می‌کند.",
 "RIG: once, day zero, 20 IU/kg, into the wound. An extra dose suppresses the vaccine response.",
 [H204, WHO, CDC])


# =========================================================== book:414
add("book:414", "case", "hard",
 "**نه روز** پس از اولین دوز واکسن، پنجره‌ی RIG بسته شده ← فقط **ادامه‌ی برنامه‌ی واکسن**.",
 "NINE DAYS after the first vaccine dose the RIG window has closed: simply CONTINUE THE VACCINE SCHEDULE.",
 CORE_FA + [
  "کودک ۱۲ ساله در منطقه‌ی دورافتاده گزیده شده، **ایمونوگلوبولین در دسترس نبوده**،",
  "و **نه روز پس از اولین دوز واکسن** به مرکز درمانی رسیده است.",
  "⚠️ **قاعده‌ی کلیدی: RIG فقط تا روز هفتم پس از اولین دوز واکسن سودمند است.**",
  "پس از روز هفتم، بدن خودش شروع به ساخت آنتی‌بادی خنثی‌کننده کرده است.",
  "در آن مرحله، تزریق آنتی‌بادی غیرفعال **نه کمکی می‌کند و نه بی‌ضرر است** —",
  "می‌تواند پاسخ ایمنی فعالی را که تازه شکل گرفته **مهار** کند.",
  "پس در روز نهم، پاسخ درست این است: **RIG را فراموش کن و برنامه‌ی واکسن را کامل کن**.",
  "یعنی دوزهای روز **۱۴** (و در صورت اندیکاسیون **۲۸**) طبق زمان‌بندی زده شوند.",
  "⚠️ نکته‌ی مهم دیگر: اگر دوزی از واکسن عقب بیفتد، برنامه **از سر گرفته نمی‌شود** (restart)،",
  "بلکه از همان‌جا **ادامه** می‌یابد (resume)، با رعایت حداقل فاصله‌ی بین دوزها.",
  "دوز درست RIG را هم بدانید تا فریب گزینه‌ها را نخورید: **انسانی ۲۰ و اسبی ۴۰ واحد بر کیلوگرم**.",
  "⚠️ و **IVIG معمولی هیچ نقشی در هاری ندارد** — آنتی‌بادی اختصاصی ضدهاری ندارد.",
 ],
 CORE_EN + [
  "A 12-year-old was bitten in a remote area, IMMUNE GLOBULIN WAS UNAVAILABLE,",
  "and he reaches a health centre NINE DAYS AFTER THE FIRST VACCINE DOSE.",
  "WARNING, THE KEY RULE: RIG IS USEFUL ONLY UP TO DAY 7 AFTER THE FIRST VACCINE DOSE.",
  "Beyond day 7 the body has begun producing its own neutralising antibody.",
  "At that stage injecting passive antibody NEITHER HELPS NOR IS HARMLESS —",
  "it can INHIBIT the active response that has just started.",
  "So on day nine the right answer is: FORGET THE RIG AND COMPLETE THE VACCINE SCHEDULE.",
  "That means giving the DAY 14 dose (and day 28 if indicated) on schedule.",
  "WARNING, another important point: if a vaccine dose is delayed, the course is NOT RESTARTED",
  "but RESUMED from where it stopped, respecting the minimum intervals between doses.",
  "Know the correct RIG doses so the distractors cannot fool you: HUMAN 20 and EQUINE 40 IU/KG.",
  "WARNING, and ORDINARY IVIG HAS NO ROLE IN RABIES — it contains no specific antirabies antibody.",
 ],
 "این سخت‌ترین سؤال بلوک هاری است، چون درباره‌ی **زمان** می‌پرسد، نه درباره‌ی دارو.\n\n"
 "⚠️ **قاعده‌ی زمانی RIG:** ایمونوگلوبولین ضدهاری **فقط تا روز هفتم پس از اولین دوز واکسن** اندیکاسیون دارد.\n\n"
 "**چرا؟** RIG برای پر کردن یک پنجره‌ی خالی ساخته شده: از لحظه‌ی گزش تا زمانی که واکسن آنتی‌بادی فعال بسازد. تا روز هفتم، بدن هنوز آنتی‌بادی خودش را ندارد و RIG جای آن را می‌گیرد. **از روز هفتم به بعد، آنتی‌بادی فعال در راه است** و تزریق آنتی‌بادی غیرفعال نه‌تنها بی‌فایده است، بلکه می‌تواند پاسخ ایمنی نوپا را **سرکوب** کند.\n\n"
 "بیمار ما **در روز نهم** مراجعه کرده است. پس پنجره بسته شده و کار درست، **ادامه‌ی برنامه‌ی واکسن — دوزهای روز ۱۴ (و در صورت اندیکاسیون ۲۸)** — است.\n\n"
 "⚠️ **قاعده‌ی مکمل که بسیار پرسیده می‌شود:** اگر دوزی از واکسن عقب بیفتد، دوره **از اول شروع نمی‌شود**؛ از همان‌جا **ادامه** می‌یابد. ترس از «خراب شدن دوره» باعث می‌شود پزشکان به‌اشتباه همه‌چیز را از نو شروع کنند.\n\n"
 "**دوزها را هم به یاد بسپارید تا گزینه‌های عددی فریبتان ندهند:** ایمونوگلوبولین **انسانی ۲۰ واحد بر کیلوگرم**، **اسبی ۴۰ واحد بر کیلوگرم**. و ⚠️ **IVIG معمولی هیچ جایی در هاری ندارد**، چون آنتی‌بادی اختصاصی ضدهاری در آن وجود ندارد.",
 "This is the hardest question in the rabies block, because it asks about TIME rather than about a drug.\n\n"
 "WARNING, THE TIMING RULE FOR RIG: rabies immune globulin is indicated ONLY UP TO DAY 7 AFTER THE FIRST VACCINE DOSE.\n\n"
 "WHY? RIG exists to fill an empty window: from the bite until the vaccine produces active antibody. Up to day 7 the body has none of its own and RIG stands in for it. FROM DAY 7 ONWARDS ACTIVE ANTIBODY IS ON ITS WAY, and injecting passive antibody is not only useless but can SUPPRESS that nascent response.\n\n"
 "Our patient presents ON DAY NINE. The window has closed, and the correct action is to CONTINUE THE VACCINE SCHEDULE — the day 14 dose, and day 28 if indicated.\n\n"
 "WARNING, A COMPANION RULE THAT IS ASKED OFTEN: if a vaccine dose is delayed, the course is NOT RESTARTED; it is RESUMED from where it stopped. Fear of 'ruining the course' makes clinicians wrongly begin again from scratch.\n\n"
 "REMEMBER THE DOSES so the numerical options cannot mislead you: HUMAN immune globulin 20 IU/kg, EQUINE 40 IU/kg. And WARNING, ORDINARY IVIG HAS NO PLACE IN RABIES, because it contains no specific antirabies antibody.",
 ["دوز درست RIG انسانی همین است، ولی در روز نهم پنجره‌ی زمانی بسته شده و تزریق آن دیگر اندیکاسیون ندارد.",
  "چهل واحد بر کیلوگرم دوز ایمونوگلوبولین اسبی است، و در هر حال در روز نهم اندیکاسیون ندارد.",
  "پاسخ صحیح — پس از روز هفتم، RIG کنار گذاشته می‌شود و فقط برنامه‌ی واکسن (روز ۱۴ و ۲۸) ادامه می‌یابد.",
  "IVIG معمولی آنتی‌بادی اختصاصی ضدهاری ندارد و هیچ نقشی در پروفیلاکسی هاری ایفا نمی‌کند."],
 ["That is the correct human RIG dose, but on day nine the window has closed and it is no longer indicated.",
  "Forty units per kilogram is the equine dose, and in any case it is not indicated on day nine.",
  "Correct — after day 7 RIG is abandoned and only the vaccine schedule (days 14 and 28) is continued.",
  "Ordinary IVIG contains no specific antirabies antibody and has no role in rabies prophylaxis."],
 "RIG **فقط تا روز ۷** پس از اولین واکسن. دوز عقب‌افتاده‌ی واکسن **ادامه** می‌یابد، نه از نو.",
 "RIG only up to day 7 after the first vaccine dose. A delayed vaccine dose is resumed, not restarted.",
 [H204, WHO, CDC])


# =========================================================== book:415
add("book:415", "recall", "medium",
 "اگر RIG در روز صفر داده نشده، **تا یک هفته پس از اولین دوز واکسن** هنوز می‌توان تزریقش کرد.",
 "If RIG was not given on day zero, it can still be given UP TO ONE WEEK AFTER THE FIRST VACCINE DOSE.",
 CORE_FA + [
  "این سؤال روی همان **پنجره‌ی هفت‌روزه** تمرکز می‌کند، ولی از سمت دیگرش.",
  "سناریو: بیمار در پروفیلاکسی اولیه **فقط واکسن** گرفته و RIG به او نرسیده است.",
  "سؤال: **دیرترین زمان قابل قبول برای جبران این کمبود چه وقت است؟**",
  "⚠️ **پاسخ: تا یک هفته (روز هفتم) پس از تزریق اولین دوز واکسن.**",
  "منطق فیزیولوژیک: واکسن حدود **۷ تا ۱۴ روز** طول می‌کشد تا آنتی‌بادی خنثی‌کننده بسازد.",
  "در آن فاصله، RIG همان محافظت را به‌صورت **غیرفعال** فراهم می‌کند.",
  "پس از روز هفتم، آنتی‌بادی فعال ظاهر شده و افزودن آنتی‌بادی غیرفعال فقط آن را رقیق و مهار می‌کند.",
  "⚠️ گزینه‌ی «هر زمان که مراجعه کند» خطرناک‌ترین گزینه است، چون **قاعده را انکار می‌کند**.",
  "و گزینه‌ی «هرگز مجاز نیست» هم غلط است: تزریق دیرهنگام تا روز هفتم کاملاً مجاز و مفید است.",
  "حتی اگر زخم **بهبود یافته و بسته شده** باشد، RIG در همان محل قبلی زخم انفیلتره می‌شود.",
  "⚠️ و یادآوری: در فرد **قبلاً واکسینه‌شده**، RIG اصلاً اندیکاسیون ندارد — نه در روز صفر، نه در روز هفتم.",
 ],
 CORE_EN + [
  "This question focuses on the same SEVEN-DAY WINDOW, but from the other side.",
  "The scenario: the patient received VACCINE ONLY at first presentation and never got RIG.",
  "The question: WHAT IS THE LATEST ACCEPTABLE TIME TO MAKE GOOD THAT OMISSION?",
  "WARNING, THE ANSWER: UP TO ONE WEEK (DAY SEVEN) AFTER THE FIRST VACCINE DOSE.",
  "The physiological logic: the vaccine takes about 7 TO 14 DAYS to generate neutralising antibody.",
  "During that gap RIG supplies the same protection PASSIVELY.",
  "After day 7 active antibody has appeared, and adding passive antibody merely dilutes and inhibits it.",
  "WARNING: 'whenever the patient turns up' is the most dangerous option because it DENIES THE RULE.",
  "And 'never permitted' is also wrong: late administration up to day 7 is entirely permitted and useful.",
  "Even if the wound HAS HEALED AND CLOSED, the RIG is infiltrated at the site of the former wound.",
  "WARNING, and a reminder: in a PREVIOUSLY VACCINATED person RIG is not indicated at all — not on day 0, not on day 7.",
 ],
 "این سؤال دیگر روی «چه دارویی» نیست، روی **«تا کِی»** است — و همین آن را از سؤالات پرتکرار و پرخطای امتحانی می‌کند.\n\n"
 "⚠️ **پاسخ: ایمونوگلوبولین ضدهاری را می‌توان تا روز هفتم پس از اولین دوز واکسن تزریق کرد، و نه بعد از آن.**\n\n"
 "**منطق پشت این عدد:**\n\n"
 "واکسن هاری حدود **۷ تا ۱۴ روز** طول می‌کشد تا آنتی‌بادی خنثی‌کننده‌ی قابل اتکا بسازد. RIG برای پوشاندن همین فاصله ساخته شده است — یک **پل ایمنی غیرفعال**. تا روز هفتم، پل هنوز لازم است. از روز هفتم به بعد، ساحل مقابل ساخته شده و **آنتی‌بادی غیرفعالِ اضافی، پاسخ فعال بیمار را مهار می‌کند**.\n\n"
 "**دو تله‌ی این سؤال:**\n\n"
 "**«هر زمان مراجعه کرد می‌توان داد»** ← خطرناک‌ترین گزینه، چون کاملاً قاعده را انکار می‌کند و به تصور «RIG همیشه بهتر از هیچ است» دامن می‌زند.\n\n"
 "**«تزریق بعدی مجاز نیست»** ← بیش از حد سخت‌گیرانه. جبران دیرهنگام تا روز هفتم کاملاً درست و مفید است، حتی اگر زخم بسته شده باشد؛ در آن حالت RIG در **محل قبلی زخم** انفیلتره می‌شود.\n\n"
 "⚠️ و فراموش نکنید: تمام این بحث فقط درباره‌ی فرد **واکسینه‌نشده** است. در فرد قبلاً واکسینه‌شده، RIG **در هیچ روزی** اندیکاسیون ندارد.",
 "This question is no longer about which drug but about HOW LONG — which is exactly why it recurs and is often answered wrongly.\n\n"
 "WARNING, THE ANSWER: rabies immune globulin may be given up to DAY SEVEN after the first vaccine dose, and not after.\n\n"
 "THE LOGIC BEHIND THAT NUMBER:\n\n"
 "The rabies vaccine takes about 7 TO 14 DAYS to produce reliable neutralising antibody. RIG exists to bridge exactly that gap — a PASSIVE IMMUNOLOGICAL BRIDGE. Up to day 7 the bridge is still needed. From day 7 onwards the far bank has been built, and EXTRA PASSIVE ANTIBODY INHIBITS THE PATIENT'S OWN ACTIVE RESPONSE.\n\n"
 "TWO TRAPS HERE:\n\n"
 "'IT CAN BE GIVEN WHENEVER THEY PRESENT' is the most dangerous option, because it denies the rule outright and feeds the idea that RIG is always better than nothing.\n\n"
 "'LATER ADMINISTRATION IS NEVER PERMITTED' is too strict. Late catch-up up to day 7 is entirely correct and useful, even if the wound has closed; the RIG is then infiltrated at the SITE OF THE FORMER WOUND.\n\n"
 "WARNING, and do not forget: this whole discussion concerns the UNVACCINATED. In a previously vaccinated person RIG is not indicated ON ANY DAY.",
 ["تزریق دیرهنگام تا روز هفتم کاملاً مجاز و مفید است؛ این گزینه بیش از حد سخت‌گیرانه است.",
  "دو هفته از پنجره‌ی مؤثر گذشته است؛ پس از روز هفتم، RIG پاسخ فعال را مهار می‌کند.",
  "«هر زمان» قاعده‌ی هفت‌روزه را انکار می‌کند و می‌تواند پاسخ ایمنی ساخته‌شده را سرکوب کند.",
  "پاسخ صحیح — تا یک هفته پس از اولین دوز واکسن، پنجره‌ی مؤثر ایمونوگلوبولین باز است."],
 ["Late administration up to day 7 is entirely permitted and useful; this option is too strict.",
  "Two weeks is past the effective window; after day 7, RIG inhibits the active response.",
  "'Any time' denies the seven-day rule and may suppress the immunity already generated.",
  "Correct — the effective window for immune globulin stays open up to one week after the first vaccine dose."],
 "پنجره‌ی RIG = **روز صفر تا روز هفت** پس از اولین واکسن. بعد از آن، آنتی‌بادی فعال جایش را گرفته است.",
 "The RIG window runs from day zero to day seven after the first vaccine dose; after that active antibody has taken over.",
 [H204, WHO, CDC])


# =========================================================== book:416
add("book:416", "case", "hard",
 "**نه روز** پس از سه دوز واکسن، RIG **دیگر توصیه نمی‌شود** — پنجره بسته است.",
 "NINE DAYS after three vaccine doses, RIG IS NO LONGER RECOMMENDED — the window has closed.",
 CORE_FA + [
  "این سؤال همان قاعده‌ی هفت‌روزه را می‌پرسد، ولی جوری که **جواب غریزی غلط باشد**.",
  "بیمار **۹ روز پیش** گزیده شده، **سه دوز واکسن (روزهای ۰، ۳ و ۷)** را کامل گرفته،",
  "و حالا خودش RIG را تهیه کرده و آمده است تا تزریق کند.",
  "غریزه می‌گوید: «حالا که دارو هست، پس بزنیم — ضرری ندارد.» ⚠️ **این غریزه غلط است.**",
  "پس از روز هفتم، بیمار **آنتی‌بادی فعال خودش** را ساخته است.",
  "تزریق آنتی‌بادی غیرفعال در این مرحله **پاسخ فعال را مهار می‌کند** — یعنی وضع را بدتر می‌کند.",
  "⚠️ پس پاسخ صحیح: **تزریق RIG توصیه نمی‌شود.**",
  "دو گزینه‌ی دیگر درباره‌ی **محل تزریق** بحث می‌کنند و هر دو فرض غلط را می‌پذیرند.",
  "ولی چون اصل تزریق منتفی است، بحث محل تزریق بی‌معنی می‌شود.",
  "با این حال، قاعده‌ی محل را هم بدانید چون جداگانه پرسیده می‌شود:",
  "**تا جای ممکن داخل و اطراف زخم**؛ توصیه‌ی قدیمیِ «بقیه را در گلوتئال بزن» دیگر توصیه نمی‌شود.",
  "⚠️ دلیل کنار گذاشتنش: RIG در عضله‌ی دور، ویروس را در محل زخم خنثی نمی‌کند و فقط اثر سیستمیک ناچیزی دارد.",
 ],
 CORE_EN + [
  "This question asks the same seven-day rule, but framed so that THE INSTINCTIVE ANSWER IS WRONG.",
  "The patient was bitten NINE DAYS AGO, has completed THREE VACCINE DOSES (days 0, 3 and 7),",
  "and has now obtained RIG himself and come in to have it injected.",
  "Instinct says: 'the drug is here now, so give it — it can do no harm.' WARNING, THAT INSTINCT IS WRONG.",
  "After day 7 the patient has generated HIS OWN ACTIVE ANTIBODY.",
  "Injecting passive antibody at this stage INHIBITS THAT ACTIVE RESPONSE — it makes things worse.",
  "WARNING, so the correct answer is: RIG IS NOT RECOMMENDED.",
  "Two other options argue about WHERE to inject, and both accept the wrong premise.",
  "Since the injection itself is off the table, the site question becomes meaningless.",
  "Even so, know the site rule, because it is asked in its own right:",
  "AS MUCH AS POSSIBLE INTO AND AROUND THE WOUND; the old advice to 'put the rest in the gluteus' is no longer recommended.",
  "WARNING, why it was abandoned: RIG in a distant muscle does not neutralise virus at the wound and adds little systemically.",
 ],
 "این سؤال عمداً طوری چیده شده که **جواب مهربانانه، جواب غلط** باشد.\n\n"
 "بیمار ۹ روز پیش گاز گرفته شده، **سه دوز واکسن در روزهای ۰، ۳ و ۷** را کامل گرفته، ایمونوگلوبولین در آن زمان موجود نبوده، و حالا خودش آن را تهیه کرده و آمده است.\n\n"
 "غریزه می‌گوید «حالا که هست، بزنیم؛ بدتر که نمی‌شود». ⚠️ **اما بدتر می‌شود.**\n\n"
 "**قاعده:** ایمونوگلوبولین ضدهاری **فقط تا روز هفتم پس از اولین دوز واکسن** اندیکاسیون دارد. در روز نهم، بیمار **آنتی‌بادی فعال خودش** را ساخته است و تزریق آنتی‌بادی غیرفعال، آنتی‌ژن واکسن را خنثی می‌کند و **پاسخ ایمنی فعال را سرکوب می‌کند**. یعنی کاری که «برای اطمینان بیشتر» انجام می‌شود، دقیقاً ایمنی بیمار را کم می‌کند.\n\n"
 "**پس پاسخ: تزریق RIG توصیه نمی‌شود.**\n\n"
 "دو گزینه‌ی دیگر درباره‌ی **محل تزریق** بحث می‌کنند («نصف کنار زخم، بقیه در گلوتئال» یا «همه در گلوتئال»). چون اصل تزریق منتفی است، این بحث بی‌موضوع می‌شود. با این حال قاعده‌ی محل را بدانید چون جداگانه هم پرسیده می‌شود: ⚠️ **تمام دوز تا جای ممکن داخل و اطراف خود زخم**. توصیه‌ی قدیمیِ تزریق باقی‌مانده در عضله‌ی دور کنار گذاشته شده، چون RIG در گلوتئال ویروس را در محل ورود خنثی نمی‌کند.",
 "This question is deliberately built so that THE KIND ANSWER IS THE WRONG ANSWER.\n\n"
 "The patient was bitten nine days ago, completed THREE VACCINE DOSES ON DAYS 0, 3 AND 7, had no immune globulin available at the time, and has now bought it himself and come in.\n\n"
 "Instinct says 'it is here now, let us give it; it cannot make things worse'. WARNING, IT CAN.\n\n"
 "THE RULE: rabies immune globulin is indicated ONLY UP TO DAY 7 AFTER THE FIRST VACCINE DOSE. On day nine the patient has made HIS OWN ACTIVE ANTIBODY, and injecting passive antibody neutralises vaccine antigen and SUPPRESSES THAT ACTIVE RESPONSE. The gesture made 'for extra safety' actually reduces the patient's immunity.\n\n"
 "SO THE ANSWER IS: RIG IS NOT RECOMMENDED.\n\n"
 "Two other options debate the SITE of injection ('half beside the wound, the rest in the gluteus', or 'all in the gluteus'). Since the injection itself is off the table, that debate is moot. Still, know the site rule, because it is asked separately: WARNING, THE WHOLE DOSE GOES INTO AND AROUND THE WOUND as far as anatomically possible. The old advice to put the remainder in a distant muscle has been dropped, because gluteal RIG does not neutralise virus at the point of entry.",
 ["تقسیم دوز بین محل زخم و گلوتئال، توصیه‌ی قدیمی است و در اینجا اصل تزریق هم اندیکاسیون ندارد.",
  "پاسخ صحیح — نه روز پس از اولین دوز واکسن، پنجره‌ی مؤثر RIG بسته شده و تزریق آن پاسخ فعال را مهار می‌کند.",
  "تزریق تمام دوز در گلوتئال حتی در زمان مناسب هم نادرست است، چون ویروس را در محل ورود خنثی نمی‌کند.",
  "گذشت ۹ روز دقیقاً دلیل نزدن RIG است، نه دلیل تزریق تمام دوز در محل گازگرفتگی."],
 ["Splitting the dose between wound and gluteus is the old advice, and here the injection itself is not indicated.",
  "Correct — nine days after the first vaccine dose the effective RIG window has closed, and giving it inhibits the active response.",
  "Giving the whole dose in the gluteus is wrong even when RIG is timely, because it fails to neutralise virus at the entry site.",
  "The passage of nine days is precisely the reason NOT to give RIG, not a reason to put it all in the bite site."],
 "پس از **روز هفتم**، RIG نه‌فقط بی‌فایده بلکه **مضر** است. محل درست RIG هم **داخل زخم** است، نه گلوتئال.",
 "After day seven RIG is not merely useless but harmful. And the right place for RIG is inside the wound, not the gluteus.",
 [H204, WHO, CDC])


# =========================================================== book:419
add("book:419", "recall", "easy",
 "پروفیلاکسی آنتی‌بیوتیکی گازگرفتگی حیوان = **آموکسی‌سیلین-کلاوولانات**.",
 "Antibiotic prophylaxis for an animal bite is AMOXICILLIN-CLAVULANATE.",
 BITE_FA + [
  "این سؤال کوتاه‌ترین شکل ممکن قاعده است: **گازگرفتگی دست ← چه پروفیلاکسی‌ای؟**",
  "پاسخ **آموکسی‌سیلین-کلاوولانات** است، و دلیلش پوشش هم‌زمان سه گروه ارگانیسم.",
  "⚠️ **گازگرفتگی دست از پرخطرترین محل‌هاست** و تقریباً همیشه پروفیلاکسی می‌گیرد.",
  "چرا دست؟ چون بافت زیرجلدی دست نازک است و دندان به‌راحتی به **غلاف تاندون و مفصل** می‌رسد.",
  "عفونت غلاف تاندون (تنوسینوویت چرکی) یک **فوریت جراحی** است، نه یک سلولیت ساده.",
  "چهار علامت کاناول را بشناسید: انگشت در **فلکسیون خفیف**، تورم **دوکی**،",
  "**تندرنس در مسیر غلاف تاندون**، و **درد شدید با اکستانسیون غیرفعال**.",
  "⚠️ اریترومایسین برای گازگرفتگی نامناسب است: پوشش ضعیف پاستورلا و فلور دهانی.",
  "⚠️ کلیندامایسین بی‌هوازی‌ها را عالی می‌گیرد ولی **پاستورلا را از دست می‌دهد**.",
  "⚠️ سیپروفلوکساسین پاستورلا را می‌گیرد ولی **بی‌هوازی‌ها را نمی‌پوشاند** و به‌تنهایی کافی نیست.",
  "پس تنها گزینه‌ای که هر سه گروه را می‌پوشاند **آموکسی‌سیلین-کلاوولانات** است.",
  "**مدت پروفیلاکسی ۳ تا ۵ روز؛ مدت درمان عفونت مستقر ۷ تا ۱۰ روز.**",
 ],
 BITE_EN + [
  "This is the rule in its shortest form: A BITE TO THE HAND — WHAT PROPHYLAXIS?",
  "The answer is AMOXICILLIN-CLAVULANATE, because it covers all three groups of organisms at once.",
  "WARNING: A BITE TO THE HAND IS AMONG THE HIGHEST-RISK SITES and almost always gets prophylaxis.",
  "Why the hand? Because its subcutaneous tissue is thin and a tooth easily reaches THE TENDON SHEATH AND JOINT.",
  "Infection of the tendon sheath (pyogenic tenosynovitis) is A SURGICAL EMERGENCY, not a simple cellulitis.",
  "Know Kanavel's four signs: the finger held in SLIGHT FLEXION, FUSIFORM swelling,",
  "TENDERNESS ALONG THE TENDON SHEATH, and SEVERE PAIN ON PASSIVE EXTENSION.",
  "WARNING: erythromycin is wrong for a bite — poor cover of Pasteurella and oral flora.",
  "WARNING: clindamycin covers anaerobes beautifully but MISSES PASTEURELLA.",
  "WARNING: ciprofloxacin covers Pasteurella but NOT ANAEROBES, and is inadequate alone.",
  "So the only option covering all three groups is AMOXICILLIN-CLAVULANATE.",
  "PROPHYLAXIS LASTS 3 TO 5 DAYS; TREATMENT OF ESTABLISHED INFECTION 7 TO 10 DAYS.",
 ],
 "این سؤال ساده است ولی دلیلش را باید فهمید تا در سؤالات سخت‌تر گم نشوید.\n\n"
 "**زخم گازگرفتگی پلی‌میکروبیال است** و سه گروه ارگانیسم در آن حضور دارند:\n\n"
 "**۱. پاستورلا مولتوسیدا** (نیمی از گازگرفتگی‌های سگ، سه‌چهارم گازگرفتگی‌های گربه)\n"
 "**۲. استرپتوکوک و استافیلوکوک**\n"
 "**۳. بی‌هوازی‌های دهانی حیوان**\n\n"
 "⚠️ **آموکسی‌سیلین-کلاوولانات تنها انتخاب خوراکیِ رایجی است که هر سه را می‌پوشاند** — و به همین دلیل داروی انتخابی است، هم برای پروفیلاکسی و هم برای درمان.\n\n"
 "**چرا گزینه‌های دیگر رد می‌شوند؟**\n\n"
 "**اریترومایسین** ← پوشش ناکافی برای فلور گازگرفتگی\n"
 "**کلیندامایسین** ← بی‌هوازی‌ها را عالی می‌گیرد ولی **پاستورلا را از دست می‌دهد**\n"
 "**سیپروفلوکساسین** ← پاستورلا را می‌گیرد ولی **بی‌هوازی ندارد**؛ به‌تنهایی ناکافی است\n\n"
 "⚠️ **و چرا دست مهم است؟** بافت زیرجلدی پشت دست نازک است و دندان به‌راحتی به **غلاف تاندون** می‌رسد. تنوسینوویت چرکی یک **فوریت جراحی** است. چهار علامت کاناول را حفظ کنید: انگشت در فلکسیون خفیف، تورم دوکی، تندرنس در مسیر غلاف، و **درد شدید با اکستانسیون غیرفعال**.\n\n"
 "**مدت:** پروفیلاکسی ۳ تا ۵ روز، درمان عفونت مستقر ۷ تا ۱۰ روز. و همیشه **کزاز و هاری** را هم بررسی کنید.",
 "This is an easy question, but you must understand the reason so you do not get lost in the harder ones.\n\n"
 "A BITE WOUND IS POLYMICROBIAL, with three groups of organisms present:\n\n"
 "1. PASTEURELLA MULTOCIDA (half of dog bites, three quarters of cat bites)\n"
 "2. STREPTOCOCCI AND STAPHYLOCOCCI\n"
 "3. THE ANIMAL'S ORAL ANAEROBES\n\n"
 "WARNING: AMOXICILLIN-CLAVULANATE IS THE ONE COMMON ORAL AGENT THAT COVERS ALL THREE — which is why it is the drug of choice for both prophylaxis and treatment.\n\n"
 "WHY THE OTHERS FAIL:\n\n"
 "ERYTHROMYCIN — inadequate cover of bite flora\n"
 "CLINDAMYCIN — excellent against anaerobes but MISSES PASTEURELLA\n"
 "CIPROFLOXACIN — covers Pasteurella but HAS NO ANAEROBIC ACTIVITY; inadequate alone\n\n"
 "WARNING, AND WHY THE HAND MATTERS: the subcutaneous tissue over the hand is thin and a tooth easily reaches THE TENDON SHEATH. Pyogenic tenosynovitis is A SURGICAL EMERGENCY. Memorise Kanavel's four signs: finger in slight flexion, fusiform swelling, tenderness along the sheath, and SEVERE PAIN ON PASSIVE EXTENSION.\n\n"
 "DURATION: prophylaxis 3 to 5 days, treatment of established infection 7 to 10 days. And always check TETANUS AND RABIES as well.",
 ["اریترومایسین پوشش ناکافی برای پاستورلا و فلور دهانی حیوان دارد.",
  "کلیندامایسین بی‌هوازی‌ها را خوب می‌گیرد ولی پاستورلا مولتوسیدا را پوشش نمی‌دهد.",
  "سیپروفلوکساسین پاستورلا را می‌گیرد ولی بی‌هوازی‌ها را نمی‌پوشاند و به‌تنهایی کافی نیست.",
  "پاسخ صحیح — آموکسی‌سیلین-کلاوولانات هم‌زمان پاستورلا، استرپ و استاف و بی‌هوازی‌ها را می‌پوشاند."],
 ["Erythromycin gives inadequate cover of Pasteurella and the animal's oral flora.",
  "Clindamycin covers anaerobes well but does not cover Pasteurella multocida.",
  "Ciprofloxacin covers Pasteurella but not anaerobes, and is inadequate as monotherapy.",
  "Correct — amoxicillin-clavulanate covers Pasteurella, streptococci and staphylococci, and anaerobes together."],
 "گازگرفتگی = **پاستورلا + استرپ/استاف + بی‌هوازی** ← **کوآموکسی‌کلاو**. سفالکسین و کلیندامایسین **پاستورلا را می‌بازند**.",
 "A bite means Pasteurella plus strep/staph plus anaerobes, so co-amoxiclav. Cephalexin and clindamycin both miss Pasteurella.",
 [H46, IDSA])


# =========================================================== book:421
add("book:421", "case", "hard",
 "میان چهار کینولون، تنها **موکسی‌فلوکساسین** به‌تنهایی هم پاستورلا و هم **بی‌هوازی‌ها** را می‌پوشاند.",
 "Among four quinolones, only MOXIFLOXACIN covers both Pasteurella AND ANAEROBES as a single agent.",
 BITE_FA + [
  "⚠️ **توجه: کلید چاپی این سؤال تصحیح شده است** و دلیلش را کامل بخوانید.",
  "سؤال چهار کینولون جلوی شما می‌گذارد: سیپروفلوکساسین، لووفلوکساسین، جمی‌فلوکساسین، موکسی‌فلوکساسین.",
  "کلید کتاب **سیپروفلوکساسین** را انتخاب کرده است، ولی این انتخاب با قاعده‌ی خود کتاب نمی‌خواند.",
  "قاعده این است: پروفیلاکسی گازگرفتگی باید **هم هوازی و هم بی‌هوازی** را بپوشاند.",
  "⚠️ **سیپروفلوکساسین پاستورلا را خوب می‌گیرد ولی روی بی‌هوازی‌ها عملاً بی‌اثر است.**",
  "به همین دلیل راهنمای IDSA می‌گوید اگر سیپروفلوکساسین یا لووفلوکساسین انتخاب شود،",
  "**باید کلیندامایسین یا مترونیدازول به آن اضافه شود** — یعنی به‌تنهایی ناکافی است.",
  "⚠️ در همان جدول، IDSA درباره‌ی موکسی‌فلوکساسین می‌نویسد: «**تک‌دارویی؛ برای بی‌هوازی‌ها هم خوب است**».",
  "موکسی‌فلوکساسین تنها فلوروکینولونی است که فعالیت بی‌هوازی معنادار دارد.",
  "جمی‌فلوکساسین یک کینولون تنفسی است و برای فلور گازگرفتگی جایگاهی ندارد.",
  "لووفلوکساسین هم مثل سیپرو، بدون افزودن پوشش بی‌هوازی ناکافی است.",
  "پس در سؤالی که **فقط کینولون‌ها** را پیش می‌گذارد، پاسخ درست **موکسی‌فلوکساسین** است.",
  "⚠️ و یادآوری همیشگی: اگر آموکسی‌سیلین-کلاوولانات در گزینه‌ها بود، **آن انتخاب اول است** (مثل q9419 و q9420).",
 ],
 BITE_EN + [
  "WARNING, NOTE: THE PRINTED KEY OF THIS QUESTION HAS BEEN CORRECTED — read the reason in full.",
  "The question offers four quinolones: ciprofloxacin, levofloxacin, gemifloxacin, moxifloxacin.",
  "The book's key chooses CIPROFLOXACIN, but that choice contradicts the book's own rule.",
  "The rule is that bite prophylaxis must cover BOTH AEROBES AND ANAEROBES.",
  "WARNING: CIPROFLOXACIN COVERS PASTEURELLA WELL BUT IS ESSENTIALLY INACTIVE AGAINST ANAEROBES.",
  "That is why the IDSA guideline states that if ciprofloxacin or levofloxacin is used,",
  "CLINDAMYCIN OR METRONIDAZOLE MUST BE ADDED — that is, it is insufficient alone.",
  "WARNING, in the same table IDSA writes of moxifloxacin: 'MONOTHERAPY; GOOD FOR ANAEROBES ALSO'.",
  "Moxifloxacin is the only fluoroquinolone with meaningful anaerobic activity.",
  "Gemifloxacin is a respiratory quinolone with no place in bite flora.",
  "Levofloxacin, like ciprofloxacin, is inadequate without added anaerobic cover.",
  "So in a question offering ONLY QUINOLONES, the correct answer is MOXIFLOXACIN.",
  "WARNING, and the standing reminder: if amoxicillin-clavulanate is among the options, IT IS FIRST CHOICE (as in q9419 and q9420).",
 ],
 "⚠️ **کلید چاپی این سؤال «سیپروفلوکساسین» است و ما آن را به «موکسی‌فلوکساسین» تصحیح کرده‌ایم.** دلیل این اصلاح را کامل بخوانید، چون خودِ استدلال یک درس است.\n\n"
 "**قاعده‌ی پروفیلاکسی گازگرفتگی:** پوشش باید **هم هوازی (به‌ویژه پاستورلا مولتوسیدا و استرپ/استاف) و هم بی‌هوازی‌های دهانی** را در بر بگیرد. به همین دلیل داروی انتخابی **آموکسی‌سیلین-کلاوولانات** است — که در این سؤال اصلاً در گزینه‌ها نیست و فقط چهار کینولون پیش رو داریم.\n\n"
 "**حالا کینولون‌ها را با همان قاعده بسنجید:**\n\n"
 "**سیپروفلوکساسین** ← پاستورلا بله، **بی‌هوازی خیر**\n"
 "**لووفلوکساسین** ← پاستورلا بله، **بی‌هوازی خیر**\n"
 "**جمی‌فلوکساسین** ← کینولون تنفسی؛ در فلور گازگرفتگی جایگاهی ندارد\n"
 "⚠️ **موکسی‌فلوکساسین** ← پاستورلا بله، **بی‌هوازی بله** — تنها کینولونی با فعالیت بی‌هوازی معنادار\n\n"
 "**راهنمای IDSA (۲۰۱۴) این را صریح می‌گوید:** اگر کوتریموکسازول یا لووفلوکساسین به کار رود، **باید کلیندامایسین یا مترونیدازول اضافه شود**؛ و در جدول داروها، کنار موکسی‌فلوکساسین نوشته است «**تک‌دارویی؛ برای بی‌هوازی‌ها هم خوب است**».\n\n"
 "پس در سؤالی که فقط کینولون‌ها را پیش می‌گذارد و هیچ‌کدام را با مترونیدازول ترکیب نکرده، تنها گزینه‌ای که به‌تنهایی کافی است **موکسی‌فلوکساسین** است.\n\n"
 "⚠️ **و قاعده‌ی همیشگی را فراموش نکنید:** هر وقت **آموکسی‌سیلین-کلاوولانات** در گزینه‌ها باشد، همان انتخاب اول است — همان‌طور که در q9419 و q9420 همین کتاب درست پاسخ داده شده است.",
 "WARNING: THE PRINTED KEY OF THIS QUESTION IS 'CIPROFLOXACIN' AND WE HAVE CORRECTED IT TO 'MOXIFLOXACIN'. Read the reasoning in full, because the argument is itself the lesson.\n\n"
 "THE RULE FOR BITE PROPHYLAXIS: cover must include BOTH AEROBES (especially Pasteurella multocida and strep/staph) AND ORAL ANAEROBES. That is why the drug of choice is AMOXICILLIN-CLAVULANATE — which is not among the options here; we are given four quinolones only.\n\n"
 "NOW TEST THE QUINOLONES AGAINST THAT RULE:\n\n"
 "CIPROFLOXACIN — Pasteurella yes, ANAEROBES NO\n"
 "LEVOFLOXACIN — Pasteurella yes, ANAEROBES NO\n"
 "GEMIFLOXACIN — a respiratory quinolone with no place in bite flora\n"
 "WARNING, MOXIFLOXACIN — Pasteurella yes, ANAEROBES YES: the only quinolone with meaningful anaerobic activity\n\n"
 "THE IDSA 2014 GUIDELINE SAYS THIS EXPLICITLY: if co-trimoxazole or levofloxacin is used, CLINDAMYCIN OR METRONIDAZOLE MUST BE ADDED; and in its drug table it notes beside moxifloxacin, 'MONOTHERAPY; GOOD FOR ANAEROBES ALSO'.\n\n"
 "So in a question offering only quinolones, none of them combined with metronidazole, the single agent that suffices is MOXIFLOXACIN.\n\n"
 "WARNING, AND DO NOT FORGET THE STANDING RULE: whenever AMOXICILLIN-CLAVULANATE appears among the options it is first choice — exactly as this same book answers correctly in q9419 and q9420.",
 ["کلید چاپی کتاب همین گزینه است، ولی سیپروفلوکساسین بی‌هوازی‌های دهانی را نمی‌پوشاند و برای گازگرفتگی به‌تنهایی ناکافی است.",
  "لووفلوکساسین هم مانند سیپروفلوکساسین فاقد پوشش بی‌هوازی است و باید با مترونیدازول یا کلیندامایسین همراه شود.",
  "جمی‌فلوکساسین یک کینولون تنفسی است و در فلور زخم گازگرفتگی جایگاهی ندارد.",
  "پاسخ صحیح (پس از تصحیح کلید) — موکسی‌فلوکساسین تنها کینولونی است که به‌تنهایی هم پاستورلا و هم بی‌هوازی‌ها را می‌پوشاند."],
 ["This is the book's printed key, but ciprofloxacin does not cover oral anaerobes and is inadequate alone for a bite.",
  "Levofloxacin, like ciprofloxacin, lacks anaerobic cover and must be combined with metronidazole or clindamycin.",
  "Gemifloxacin is a respiratory quinolone with no place in bite wound flora.",
  "Correct (after key correction) — moxifloxacin is the only quinolone covering both Pasteurella and anaerobes as a single agent."],
 "کینولون‌ها در گازگرفتگی: **فقط موکسی‌فلوکساسین** تک‌دارویی کافی است؛ سیپرو و لوو **مترونیدازول** لازم دارند.",
 "Quinolones in bites: only moxifloxacin suffices alone; cipro and levo need metronidazole added.",
 [IDSA, H46])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book19.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 19 lessons:', len(L))
