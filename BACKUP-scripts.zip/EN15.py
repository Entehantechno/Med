# -*- coding: utf-8 -*-
"""English stems and options for the batch-32 and batch-33 questions.

Varicella zoster, the vaccine-preventable exanthems, and hepatitis serology.

Rule 16 checked first, as always: these items come from sittings 93 to 98, for
which the ministry published no English booklet, so these are hand-written
translations rather than official ones.

Translation decisions worth recording
-------------------------------------
THE TIME INTERVALS ARE THE ANSWER in the varicella block, so every one is
carried across exactly. Six of these questions are decided by how many days
have passed since the exposure — 5, 6, 7, 10 — and by which agent that
interval permits. A stem that rounded '6 days' to 'about a week' would destroy
the question, because day 6 and day 7 select different drugs.

'PAINFUL' AND 'DERMATOMAL' ARE LOAD-BEARING WORDS. In q9633, q9635 and q9637
the whole answer turns on recognising shingles rather than chickenpox, and the
Persian signals it with دردناک (painful) and a named dermatome. Both are
preserved literally; neither is smoothed into 'uncomfortable' or 'localised'.

q9646 (idx 646): the vitamin B12 dose was repaired from 'mg0001' to 1000 mg
before this file was written, and the English carries 1000 mg. It sits in a
WRONG option, and is translated faithfully anyway, because a student must be
able to read every option in order to reject it for the right reason.

q9851 (idx 851): the whole laboratory panel is preserved — AST 1300, ALT 1700,
ALP 480, LDH 450, PT 13.1 — because the question is answered by COMPARING
them. ALT far above ALP means hepatocellular rather than cholestatic, and a
near-normal PT means synthetic function is preserved. Dropping any one of them
would leave the reasoning unreachable.

q9848 and q9853: the serological markers keep their standard English names
(HBsAg, anti-HBc, anti-HBs) rather than being spelled out, because that is how
they appear on a real request form and in every guideline.
"""

EN15 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    assert all(o.strip() for o in options), idx
    EN15[idx] = {"stem_en": stem, "options_en": options}


# =============================== varicella zoster (batch 32)
add(620,
    "A 25-year-old pregnant woman presents with macular and papular lesions together with vesicles "
    "and occasional pustules, severe itching and fever for the past 3 days. Which of the following "
    "complications is more serious in this patient?",
    ["Encephalitis",
     "Hepatitis",
     "Skin infection",
     "Pneumonia"])

add(621,
    "Which of the following complications occurring during chickenpox is benign and carries no "
    "mortality?",
    ["Varicella encephalitis",
     "Varicella pneumonitis",
     "Acute cerebellar ataxia",
     "Perinatal varicella"])

add(623,
    "A 16-year-old adolescent presents with itchy skin lesions in the form of macules, papules, "
    "vesicles and pustules. He had a mild fever for 2 days before the lesions appeared. The lesions "
    "began on the trunk and face. For how many days after the lesions appear should close contact "
    "with the patient be avoided?",
    ["2 days",
     "3 days",
     "5 days",
     "14 days"])

add(627,
    "A 25-year-old pregnant woman attends for advice. She reports contact 5 days ago with a child "
    "who had chickenpox, for which she has taken no action. Given that she has no history of "
    "previous chickenpox and no history of varicella vaccination, which of the following is "
    "correct?",
    ["Give VZIG",
     "Give varicella vaccine as soon as possible",
     "Give aciclovir from day 7 after the exposure",
     "Post-exposure prophylaxis is not recommended"])

add(628,
    "A child with ALL is receiving chemotherapy and had close contact six days ago with his brother, "
    "who had chickenpox. He has no history of previous chickenpox. Which preventive measure is "
    "correct for him?",
    ["Give VZIG",
     "Give varicella vaccine",
     "Give IVIG",
     "Give aciclovir"])

add(631,
    "You review a 25-year-old woman who received a kidney transplant one year ago, presenting with "
    "a generalised itchy pleomorphic papulovesicular rash. You decide to admit her to hospital for "
    "intravenous treatment. To prevent transmission to other patients and to staff, under which "
    "precautions should the patient be isolated?",
    ["Droplet",
     "Contact",
     "Airborne (respiratory)",
     "Standard precautions are sufficient"])

add(632,
    "A 17-year-old girl developed fever, sore throat and nasal discharge yesterday and today has "
    "noticed several skin lesions on the face and trunk. She is on heavy immunosuppressive treatment "
    "following a kidney transplant. Her 3-year-old sister developed a similar illness about 10 days "
    "ago and is recovering. What is the most appropriate action?",
    ["Serological investigation of the suspected disease and starting oral aciclovir after confirmation",
     "Admit the patient and start intravenous aciclovir",
     "Give oral cephalexin",
     "Admit the patient and start intravenous cefazolin"])

add(633,
    "On examining a mother the day after delivery you notice vesicular eruptions on the lower "
    "abdomen and right flank. She reports that they are painful. Which of the following measures is "
    "necessary?",
    ["Intravenous aciclovir for the neonate and the mother",
     "Oral aciclovir taken by the mother",
     "VZIG for the neonate",
     "Starting VZV vaccination for the neonate"])

add(635,
    "A 29-year-old man with a history of HIV who is taking no medication presents afebrile, with "
    "painful red lesions in the phalanx region which have not crossed the midline. The lesions have "
    "worsened over the past 3 days. Which is the most effective treatment for him?",
    ["Doxycycline",
     "Ganciclovir",
     "Piperacillin-tazobactam",
     "Valaciclovir"])

add(636,
    "A 32-year-old woman is 30 weeks pregnant and developed thoracic shingles 5 days before the "
    "pregnancy began. What is the appropriate action regarding her neonate?",
    ["No specific action is needed",
     "Give VZIG",
     "Give aciclovir",
     "Give famciclovir"])

add(638,
    "Which statement about varicella-zoster virus (VZV) infection is FALSE?",
    ["The incubation period of primary infection is 5 to 8 days",
     "In seronegative pregnant women, varicella-zoster immune globulin (VZIg) can be used as prophylaxis",
     "The varicella-zoster vaccine is effective in preventing shingles in people over 60 years of age",
     "Aciclovir is recommended as prophylaxis in high-risk seronegative individuals"])


# ================= measles, rubella and hepatitis serology (batch 33)
add(640,
    "A young woman presents with fever and a maculopapular eruption that began on the forehead and "
    "then spread. She reports that for the past week she has had fever, nasal discharge, cough and "
    "red eyes. On examination of the oral mucosa there are white lesions surrounded by a red halo. "
    "What is the most likely diagnosis?",
    ["Measles",
     "Rubella",
     "Scarlet fever",
     "Chickenpox"])

add(644,
    "A young man is receiving chemotherapy for leukaemia. Yesterday he had contact with a patient who "
    "has measles. He reports complete vaccination in childhood. Given the patient's condition, which "
    "of the following do you recommend to prevent measles?",
    ["Oral aciclovir",
     "Measles vaccine",
     "Measles immunoglobulin",
     "No specific action is needed"])

add(646,
    "A 20-year-old man has had fever, nasal discharge, headache and a dry cough for 4 days, "
    "accompanied by body aches and nausea. From today he has developed a rash on the face, trunk and "
    "limbs. He has no significant past medical history and his childhood and pre-school vaccinations "
    "are complete. On examination he is ill, T = 39 °C, and there are erythematous macular rashes on "
    "the face and the front and back of the trunk and the proximal limbs. The conjunctivae are "
    "congested and bluish-white lesions are visible on the buccal cavity mucosa. Which of the "
    "following treatments is appropriate for this patient?",
    ["Vitamin A, two hundred thousand units daily for 2 days",
     "Vitamin B12, 1000 mg daily for one week",
     "Immunoglobulin serum",
     "IVIG"])

add(648,
    "A woman in the eleventh week of pregnancy who was exposed to a patient with rubella attends "
    "your clinic. Rubella serology performed 2 days after the exposure is reported as IgM negative "
    "and IgG positive. What is the most appropriate action for this pregnant woman?",
    ["Give rubella-specific immunoglobulin",
     "Recommend termination of the pregnancy",
     "Reassure the patient",
     "Repeat rubella IgM and IgG serology 2 weeks later"])

add(649,
    "In the tests of a 21-year-old woman in the sixth week of pregnancy, performed after a recent "
    "fever and arthralgia, the rubella IgM antibody is reported positive. Which of the following "
    "measures do you explain to her?",
    ["Give ribavirin",
     "Rubella vaccination",
     "Give immediate intravenous immunoglobulin",
     "Assessment for an indication to terminate the pregnancy"])

add(848,
    "A nurse sustains a needlestick injury while taking a sample from a patient with chronic "
    "hepatitis B. She was vaccinated against hepatitis B about three years ago and had a high "
    "protective titre. What do you advise her?",
    ["You advise her to receive a booster dose of vaccine",
     "She needs no action at all",
     "Her antibody titre must be checked immediately",
     "It is essential that she receives HBIG and one dose of vaccine"])

add(851,
    "A 16-year-old girl attends after 2 to 3 days of fever, headache, nausea and anorexia, followed "
    "by dark urine and the onset of jaundice. Her investigations are: AST 1300, ALT 1700, ALP 480, "
    "LDH 450, PT 13.1. Which tests do you request?",
    ["HBV DNA PCR and anti-HBs",
     "Ultrasound of the liver and biliary tract",
     "HBeAg and anti-HBe",
     "IgM anti-HAV and IgM anti-HBc"])

add(853,
    "An injecting drug user is admitted with a diagnosis of endocarditis. His investigations show "
    "HIV negative, anti-HBc IgM negative, HBsAg positive and anti-HBc IgG positive. For his wife, "
    "whose HBsAg is negative, which of the following do you do?",
    ["Hepatitis B vaccine in 3 doses",
     "HBIG together with hepatitis B vaccine",
     "HBIG within the first two weeks after sexual contact",
     "Two doses of HBIG one month apart"])

add(855,
    "A patient becomes jaundiced after a week of fever, weakness, fatigue, nausea and vomiting. To "
    "assess the SEVERITY, which of the following tests would you NOT request?",
    ["SGOT/SGPT",
     "PT",
     "Bilirubin",
     "Blood sugar"])
