# -*- coding: utf-8 -*-
"""Micro-lessons, batch 42 — the toxoplasmosis cluster (twelve questions).

This is the densest single cluster in the parasitology chapter, and the book
asks it from six different angles. Almost every item is decided by ONE decision
tree, so the tree is taught once and then reused.

THE TOXOPLASMOSIS DECISION TREE
--------------------------------
STEP 1 — WHO IS THE PATIENT?

  IMMUNOCOMPETENT AND NOT PREGNANT
      lymphadenopathy alone -> NO TREATMENT, follow-up only.
      Treat only if the symptoms are severe, persistent, or visceral.

  PREGNANT
      go to step 2.

  IMMUNOCOMPROMISED (HIV, transplant) OR OCULAR OR CONGENITAL
      ALWAYS TREAT.

STEP 2 — IN PREGNANCY, WHAT DOES THE SEROLOGY SAY?

  IgG POSITIVE, IgM NEGATIVE, and this pattern predates the pregnancy
      OLD, IMMUNE. Nothing to do. Reassure. No repeat testing, no PCR.

  IgG POSITIVE, IgM POSITIVE
      possibly acute; IgM can persist for a year or more, so an IgG AVIDITY
      test is the discriminator. High avidity in the first 12 to 16 weeks
      effectively excludes an infection acquired in this pregnancy.

STEP 3 — IF ACUTE MATERNAL INFECTION IS ESTABLISHED, IS THE FETUS INFECTED?

  NOT YET KNOWN (normal ultrasound, no amniocentesis result)
      SPIRAMYCIN. It concentrates in the placenta and reduces transmission,
      but it barely crosses the placenta, so it does NOT treat an already
      infected fetus.

  FETUS INFECTED — positive amniotic-fluid PCR OR an ultrasound suggestive of
  congenital toxoplasmosis
      SWITCH to PYRIMETHAMINE + SULFADIAZINE + FOLINIC ACID, and continue to
      delivery. Pyrimethamine is teratogenic and is not used before 14 weeks.

THE TRANSMISSION PARADOX, WHICH THE BOOK ASKS TWICE
-----------------------------------------------------
Two facts run in OPPOSITE directions across gestation, and the exam exploits
the confusion:

    RATE of transmission RISES with gestational age
        first trimester about 10 to 15 %, third trimester 60 % or more.

    SEVERITY of fetal disease FALLS with gestational age
        first-trimester infection causes the devastating cases; third-trimester
        infection usually produces a baby who looks normal at birth and
        declares itself later with chorioretinitis.

The reason is placental: the placenta grows and becomes more permeable, while
the fetus becomes progressively more able to withstand the insult.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022) —
toxoplasma infection; Merck/MSD Manual Professional, Toxoplasmosis (2025);
Montoya JG & Remington JS, congenital toxoplasmosis management tables.
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — "
     "toxoplasma infection")
MERCK = ("Merck Manual / MSD Manual Professional Edition — Toxoplasmosis, "
         "treatment section (2025 revision)")
MONTOYA = ("Montoya JG, Remington JS — management of Toxoplasma gondii "
           "infection in pregnancy and congenital toxoplasmosis: the standard "
           "treatment tables (indications for spiramycin versus "
           "pyrimethamine-sulfadiazine-folinic acid)")

# ============================================== THE CORE TREE, SHARED
TREE_FA = [
    "⚠️ **کل خوشه‌ی توکسوپلاسموز با یک درخت تصمیم سه‌مرحله‌ای حل می‌شود.**",
    "**مرحله‌ی یک — بیمار کیست؟ این تعیین می‌کند اصلاً درمان لازم است یا نه.**",
    "**فرد سالم و غیرباردار با فقط لنفادنوپاتی: درمان نمی‌خواهد، فقط پیگیری.**",
    "**درمان او فقط وقتی لازم است که علائم شدید، طول‌کشیده یا احشایی باشد.**",
    "⚠️ **ولی سه گروه همیشه درمان می‌شوند: نقص ایمنی، درگیری چشمی، و مادرزادی.**",
    "**و باردار مبتلا به عفونت حاد هم همیشه درمان می‌شود.**",
    "**مرحله‌ی دو — در بارداری، سرولوژی چه می‌گوید؟**",
    "**IgG مثبت با IgM منفی از پیش از بارداری: ایمنی قدیمی، هیچ اقدامی لازم نیست.**",
    "**IgG و IgM هر دو مثبت: ممکن است حاد باشد، ولی قطعی نیست.**",
    "⚠️ **چون IgM می‌تواند یک سال یا بیشتر مثبت بماند — این تله‌ی اصلی است.**",
    "**تست تفکیک‌کننده، اویدیتی IgG است.**",
    "**اویدیتی بالا در ۱۲ تا ۱۶ هفته‌ی اول، عفونت حین همین بارداری را عملاً رد می‌کند.**",
    "**مرحله‌ی سه — اگر عفونت حاد مادر ثابت شد، جنین درگیر است یا نه؟**",
    "**هنوز نمی‌دانیم (سونوگرافی طبیعی، PCR نداریم): اسپیرامایسین.**",
    "⚠️ **اسپیرامایسین در جفت تغلیظ می‌شود ولی از جفت عبور نمی‌کند.**",
    "**پس انتقال را کم می‌کند ولی جنینِ از قبل آلوده را درمان نمی‌کند.**",
    "**جنین آلوده (PCR مثبت یا سونوگرافی مطرح‌کننده): پیریمتامین + سولفادیازین + فولینیک اسید.**",
    "**فولینیک اسید برای جلوگیری از سرکوب مغز استخوان ناشی از پیریمتامین است.**",
    "⚠️ **و پیریمتامین تراتوژن است، پس پیش از هفته‌ی ۱۴ داده نمی‌شود.**",
]
TREE_EN = [
    "WARNING: THE WHOLE TOXOPLASMOSIS CLUSTER IS SOLVED BY ONE THREE-STEP DECISION TREE.",
    "STEP ONE — WHO IS THE PATIENT? This decides whether treatment is needed at all.",
    "A healthy, non-pregnant person with lymphadenopathy alone: NO TREATMENT, follow-up only.",
    "He is treated only if the symptoms are severe, persistent or visceral.",
    "WARNING, BUT THREE GROUPS ARE ALWAYS TREATED: immunodeficiency, ocular disease, congenital disease.",
    "And a pregnant woman with acute infection is always treated too.",
    "STEP TWO — IN PREGNANCY, WHAT DOES THE SEROLOGY SAY?",
    "IgG positive with IgM negative, dating from before the pregnancy: OLD IMMUNITY, nothing to do.",
    "IgG and IgM both positive: possibly acute, but not certain.",
    "WARNING, BECAUSE IgM CAN STAY POSITIVE FOR A YEAR OR MORE — this is the main trap.",
    "The discriminating test is IgG AVIDITY.",
    "High avidity in the first 12 to 16 weeks effectively excludes infection during this pregnancy.",
    "STEP THREE — IF ACUTE MATERNAL INFECTION IS ESTABLISHED, IS THE FETUS INVOLVED?",
    "NOT YET KNOWN (normal ultrasound, no PCR result): SPIRAMYCIN.",
    "WARNING, SPIRAMYCIN CONCENTRATES IN THE PLACENTA BUT DOES NOT CROSS IT.",
    "So it reduces transmission but does NOT treat a fetus that is already infected.",
    "FETUS INFECTED (positive PCR or suggestive ultrasound): PYRIMETHAMINE + SULFADIAZINE + FOLINIC ACID.",
    "The folinic acid prevents the bone marrow suppression caused by pyrimethamine.",
    "WARNING, AND PYRIMETHAMINE IS TERATOGENIC, so it is not given before week 14.",
]

REFS = [H, MERCK, MONTOYA]

# ================================================= CONGENITAL CHORIORETINITIS
add("book:745", "vignette", "medium",
    "**کوریورتینیت در کودک + بیماری شبه‌مونونوکلئوز مادر در بارداری = توکسوپلاسموز مادرزادی.**",
    "Chorioretinitis in a child plus a mononucleosis-like illness in the mother during pregnancy = CONGENITAL TOXOPLASMOSIS.",
    [
        "⚠️ **سه‌گانه‌ی کلاسیک توکسوپلاسموز مادرزادی را حفظ کنید.**",
        "**یک: کوریورتینیت. دو: کلسیفیکاسیون‌های پراکنده‌ی داخل مغزی. سه: هیدروسفالی.**",
        "**و شایع‌ترین و ماندگارترین جزء آن، همان درگیری چشم است.**",
        "**ضایعه‌ی چشمی: پلاک سفید با لبه‌های مشخص و رنگدانه‌ی سیاه در حاشیه.**",
        "⚠️ **همین «لبه‌ی مشخص با رنگدانه‌ی سیاه» امضای توکسوپلاسماست.**",
        "**بسیاری از نوزادان مبتلا هنگام تولد کاملاً طبیعی به نظر می‌رسند.**",
        "**و بیماری سال‌ها بعد با تاری دید یا افت بینایی خود را نشان می‌دهد.**",
        "**در مادر، عفونت حاد معمولاً فقط تب و لنفادنوپاتی گردنی است.**",
        "**که خودبه‌خود خوب می‌شود — دقیقاً همان چیزی که مادر این بیمار توصیف می‌کند.**",
        "⚠️ **پس سرنخ تشخیصی، بیماری خفیف مادر در بارداری است، نه علامت خود کودک.**",
        "**سیتومگالوویروس هم کوریورتینیت می‌دهد ولی الگوی آن متفاوت است.**",
        "**در CMV کلسیفیکاسیون‌ها اطراف بطنی‌اند و میکروسفالی و کری حسی-عصبی شایع است.**",
        "**در توکسوپلاسما کلسیفیکاسیون‌ها پراکنده‌اند و هیدروسفالی دیده می‌شود.**",
        "**EBV عملاً عفونت مادرزادی مهمی نمی‌سازد.**",
        "**و واریسلای مادرزادی تابلوی کاملاً متفاوتی دارد: اسکار پوستی و هیپوپلازی اندام.**",
    ],
    [
        "WARNING: MEMORISE THE CLASSIC TRIAD OF CONGENITAL TOXOPLASMOSIS.",
        "ONE: chorioretinitis. TWO: SCATTERED intracranial calcifications. THREE: hydrocephalus.",
        "And its commonest and most enduring component is the eye involvement.",
        "The eye lesion: a white plaque with well-defined edges and BLACK PIGMENT at the margin.",
        "WARNING, THAT 'SHARP EDGE WITH BLACK PIGMENT' IS THE TOXOPLASMA SIGNATURE.",
        "Many affected newborns look entirely normal at birth.",
        "And the disease declares itself years later with blurred or failing vision.",
        "In the mother, acute infection is usually just fever and cervical lymphadenopathy.",
        "Which resolves on its own — exactly what this patient's mother describes.",
        "WARNING, SO THE DIAGNOSTIC CLUE IS THE MOTHER'S MILD ILLNESS IN PREGNANCY, not the child's sign.",
        "Cytomegalovirus also causes chorioretinitis, but its pattern differs.",
        "In CMV the calcifications are PERIVENTRICULAR, with microcephaly and sensorineural deafness common.",
        "In toxoplasma the calcifications are SCATTERED and hydrocephalus is seen.",
        "EBV essentially produces no significant congenital infection.",
        "And congenital varicella has a completely different picture: skin scarring and limb hypoplasia.",
    ],
    "این سؤال یک تشخیص را از **تاریخچه‌ی مادر** می‌خواهد، نه از یافته‌ی خود کودک — و همین "
    "آن را آموزنده می‌کند.\n\n"
    "**تابلوی کودک:** هشت ساله، تاری دید، و در افتالموسکوپی **پلاک‌های سفید با لبه‌های مشخص "
    "و لکه‌های سیاه** در شبکیه، با تشخیص کوریورتینیت.\n\n"
    "⚠️ **این توصیف، امضای اسکار کوریورتینیت توکسوپلاسمایی است:** ضایعه‌ی سفید (اسکار "
    "آتروفیک) با **حاشیه‌ی رنگدانه‌دار سیاه**.\n\n"
    "**سرنخ قطعی‌کننده اما در تاریخچه‌ی مادر است:** «در حین بارداری به مدت یک ماه دچار تب و "
    "تورم غده‌ی لنفاوی گردن شده که **بدون درمان بهبود یافته**». این دقیقاً تابلوی **توکسوپلاسموز "
    "حاد در فرد دارای ایمنی سالم** است — بیماری شبه‌مونونوکلئوز که خودبه‌خود خوب می‌شود.\n\n"
    "**پس زنجیره کامل است:** مادر در بارداری عفونت حاد گرفته ← انگل از جفت عبور کرده ← "
    "**توکسوپلاسموز مادرزادی** ← کودک در تولد ظاهراً سالم بوده ← سال‌ها بعد با کوریورتینیت "
    "مراجعه کرده.\n\n"
    "**سه‌گانه‌ی کلاسیک توکسوپلاسموز مادرزادی را حفظ کنید:** **کوریورتینیت** + **کلسیفیکاسیون "
    "پراکنده‌ی داخل مغزی** + **هیدروسفالی**.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "⚠️ **سیتومگالوویروس** نزدیک‌ترین رقیب است و **هم کوریورتینیت می‌دهد**. ولی الگوی آن "
    "فرق دارد: **کلسیفیکاسیون اطراف بطنی** (نه پراکنده)، **میکروسفالی** (نه هیدروسفالی)، و "
    "**کری حسی-عصبی** که شایع‌ترین عارضه‌ی آن است. به‌علاوه عفونت CMV مادر معمولاً کاملاً "
    "بی‌علامت است، نه یک ماه تب و لنفادنوپاتی.\n\n"
    "**EBV** عملاً سندرم مادرزادی مهمی ندارد، هرچند در مادر می‌تواند مونونوکلئوز بدهد.\n\n"
    "**واریسلا زوستر** سندرم واریسلای مادرزادی دارد که تابلوی کاملاً متفاوتی است: "
    "**اسکارهای پوستی به شکل درماتوم، هیپوپلازی اندام، و آسیب چشمی**.",
    "This question asks for a diagnosis from THE MOTHER'S HISTORY rather than the child's finding — "
    "and that is what makes it instructive.\n\n"
    "THE CHILD'S PICTURE: eight years old, blurred vision, and on ophthalmoscopy WHITE PLAQUES WITH "
    "WELL-DEFINED EDGES AND BLACK SPOTS in the retina, diagnosed as chorioretinitis.\n\n"
    "WARNING, THAT DESCRIPTION IS THE SIGNATURE OF A TOXOPLASMIC CHORIORETINAL SCAR: a white lesion "
    "(atrophic scar) with a BLACK PIGMENTED MARGIN.\n\n"
    "BUT THE DECIDING CLUE IS IN THE MOTHER'S HISTORY: 'during the pregnancy she had a month of fever "
    "and cervical lymph node swelling which RESOLVED WITHOUT TREATMENT'. That is exactly the picture "
    "of ACUTE TOXOPLASMOSIS IN AN IMMUNOCOMPETENT PERSON — a mononucleosis-like illness that settles "
    "by itself.\n\n"
    "SO THE CHAIN IS COMPLETE: the mother acquired acute infection in pregnancy, the parasite crossed "
    "the placenta, CONGENITAL TOXOPLASMOSIS followed, the child looked healthy at birth, and years "
    "later he presents with chorioretinitis.\n\n"
    "MEMORISE THE CLASSIC TRIAD OF CONGENITAL TOXOPLASMOSIS: CHORIORETINITIS plus SCATTERED "
    "INTRACRANIAL CALCIFICATION plus HYDROCEPHALUS.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "WARNING, CYTOMEGALOVIRUS is the closest competitor and DOES cause chorioretinitis. But its "
    "pattern differs: PERIVENTRICULAR calcification (not scattered), MICROCEPHALY (not hydrocephalus), "
    "and SENSORINEURAL DEAFNESS as its commonest sequela. Moreover maternal CMV infection is usually "
    "entirely asymptomatic, not a month of fever and lymphadenopathy.\n\n"
    "EBV has essentially no significant congenital syndrome, although it can cause mononucleosis in "
    "the mother.\n\n"
    "VARICELLA ZOSTER has a congenital varicella syndrome with a completely different picture: "
    "DERMATOMAL SKIN SCARRING, LIMB HYPOPLASIA and eye damage.",
    ["پاسخ صحیح — کوریورتینیت کودک به‌علاوه‌ی بیماری خودمحدود مادر در بارداری، توکسوپلاسموز مادرزادی است.",
     "کوریورتینیت می‌دهد ولی با کلسیفیکاسیون اطراف بطنی، میکروسفالی و کری؛ و مادر معمولاً بی‌علامت است.",
     "سندرم مادرزادی مهمی ندارد، هرچند در مادر مونونوکلئوز می‌سازد.",
     "واریسلای مادرزادی با اسکار پوستی درماتومی و هیپوپلازی اندام تظاهر می‌کند، نه این تابلو."],
    ["Correct — the child's chorioretinitis plus the mother's self-limited illness in pregnancy is congenital toxoplasmosis.",
     "Causes chorioretinitis but with periventricular calcification, microcephaly and deafness; and the mother is usually asymptomatic.",
     "Has no significant congenital syndrome, though it causes mononucleosis in the mother.",
     "Congenital varicella presents with dermatomal skin scarring and limb hypoplasia, not this picture."],
    "**اسکار سفید با حاشیه‌ی سیاه در شبکیه + بیماری خفیف مادر در بارداری = توکسوی مادرزادی.**",
    "A white retinal scar with a black margin plus a mild maternal illness in pregnancy = congenital toxo.",
    REFS)

# ============================ IMMUNOCOMPETENT LYMPHADENOPATHY: FOUR ITEMS
LN_FA = TREE_FA + [
    "**لنفادنوپاتی توکسوپلاسمایی شایع‌ترین تظاهر بالینی این عفونت است.**",
    "**غدد معمولاً گردنی، مجزا، غیرچسبنده و بدون درد یا با درد خفیف‌اند.**",
    "**و خودبه‌خود ظرف چند هفته تا چند ماه فروکش می‌کنند.**",
    "⚠️ **درمان با پیریمتامین + سولفادیازین سمّی است: سرکوب مغز استخوان و آسیب کلیه.**",
    "**پس دادن آن به بیماری که خودبه‌خود خوب می‌شود، آسیب بدون سود است.**",
]
LN_EN = TREE_EN + [
    "Toxoplasmic lymphadenopathy is the commonest clinical manifestation of this infection.",
    "The nodes are usually cervical, discrete, non-matted, and painless or only mildly tender.",
    "And they subside spontaneously over weeks to months.",
    "WARNING, PYRIMETHAMINE PLUS SULFADIAZINE IS TOXIC: marrow suppression and renal injury.",
    "So giving it to a patient who will recover anyway is harm without benefit.",
]

add("book:751", "vignette", "medium",
    "**مرد سالم با لنفادنوپاتی و IgM مثبت: فقط پیگیری — درمان سمّی برای بیماری خودمحدود لازم نیست.**",
    "A healthy man with lymphadenopathy and a positive IgM: FOLLOW-UP ONLY — toxic treatment is not needed for a self-limited disease.",
    LN_FA,
    LN_EN,
    "این سؤال ساده‌ترین شاخه‌ی درخت تصمیم را می‌سنجد و بیشترین اشتباه هم در همین‌جا رخ می‌دهد.\n\n"
    "**بیمار: آقای ۳۵ ساله، بدون سابقه‌ی بیماری خاص (یعنی ایمنی سالم)، غیرباردار (مرد است)، "
    "با تورم غدد لنفاوی پشت گوش و درد خفیف، و IgM ضد توکسو مثبت.**\n\n"
    "⚠️ **قاعده: در فرد دارای ایمنی سالم و غیرباردار، لنفادنوپاتی توکسوپلاسمایی درمان "
    "نمی‌خواهد.** این بیماری خودمحدود است و غدد ظرف چند هفته تا چند ماه خودبه‌خود فروکش می‌کنند.\n\n"
    "**درمان فقط در سه حالت لازم است:** علائم **شدید**، علائم **طول‌کشیده و آزاردهنده**، یا "
    "**درگیری احشایی** (مثل میوکاردیت، پنومونیت، هپاتیت).\n\n"
    "**هیچ‌کدام از این‌ها در بیمار ما وجود ندارد.** او فقط لنفادنوپاتی با **درد خفیف** دارد.\n\n"
    "⚠️ **چرا درمان نکردن مهم است و صرفاً «کاری نکردن» نیست؟** چون **پیریمتامین + سولفادیازین "
    "داروهای سمّی‌اند**: پیریمتامین آنتاگونیست فولات است و **سرکوب مغز استخوان** می‌دهد "
    "(نوتروپنی، ترومبوسیتوپنی، آنمی)؛ سولفادیازین می‌تواند **کریستالوری و نارسایی کلیه** و "
    "واکنش‌های آلرژیک شدید بدهد. دادن این داروها به بیماری که خودبه‌خود خوب می‌شود، **آسیب "
    "بدون سود** است.\n\n"
    "**پس هر سه گزینه‌ی درمانی رد می‌شوند:**\n\n"
    "**پیریمتامین + سولفادیازین:** درمان استاندارد است ولی اندیکاسیون ندارد.\n\n"
    "**پیریمتامین + کلیندامایسین:** رژیم جایگزین برای بیمار **حساس به سولفا** است؛ باز هم "
    "اندیکاسیون ندارد.\n\n"
    "**پیریمتامین + سولفادیازین + پردنیزولون:** افزودن استروئید فقط در **توکسوپلاسموز چشمی "
    "با تهدید ماکولا یا عصب بینایی** یا در انسفالیت با ادم شدید جایی دارد. اینجا نه.\n\n"
    "**پاسخ: فقط پیگیری بیمار.**",
    "This question tests the simplest branch of the decision tree, and it is also where most mistakes "
    "are made.\n\n"
    "THE PATIENT: a 35-year-old man, with no significant medical history (so immunocompetent), not "
    "pregnant (he is male), with swollen post-auricular nodes and mild pain, and a positive anti-toxo IgM.\n\n"
    "WARNING, THE RULE: IN AN IMMUNOCOMPETENT, NON-PREGNANT PERSON, TOXOPLASMIC LYMPHADENOPATHY NEEDS "
    "NO TREATMENT. The disease is self-limited and the nodes subside spontaneously over weeks to months.\n\n"
    "TREATMENT IS NEEDED ONLY IN THREE SITUATIONS: SEVERE symptoms, PERSISTENT and distressing "
    "symptoms, or VISCERAL involvement (myocarditis, pneumonitis, hepatitis).\n\n"
    "NONE OF THESE IS PRESENT IN OUR PATIENT. He has lymphadenopathy with MILD pain only.\n\n"
    "WARNING, WHY DOES NOT TREATING MATTER, RATHER THAN BEING MERE INACTION? Because PYRIMETHAMINE AND "
    "SULFADIAZINE ARE TOXIC DRUGS: pyrimethamine is a folate antagonist and causes BONE MARROW "
    "SUPPRESSION (neutropenia, thrombocytopenia, anaemia); sulfadiazine can cause CRYSTALLURIA AND "
    "RENAL FAILURE and severe allergic reactions. Giving them to a patient who will recover anyway is "
    "HARM WITHOUT BENEFIT.\n\n"
    "SO ALL THREE TREATMENT OPTIONS ARE REJECTED:\n\n"
    "PYRIMETHAMINE PLUS SULFADIAZINE: the standard regimen, but not indicated here.\n\n"
    "PYRIMETHAMINE PLUS CLINDAMYCIN: the alternative regimen for a SULFA-ALLERGIC patient; again not "
    "indicated.\n\n"
    "PYRIMETHAMINE PLUS SULFADIAZINE PLUS PREDNISOLONE: adding a steroid has a place only in OCULAR "
    "TOXOPLASMOSIS THREATENING THE MACULA OR OPTIC NERVE, or in encephalitis with severe oedema. Not here.\n\n"
    "THE ANSWER: FOLLOW THE PATIENT ONLY.",
    ["درمان استاندارد است ولی در فرد سالم با لنفادنوپاتی خفیف اندیکاسیون ندارد.",
     "رژیم جایگزین برای بیمار حساس به سولفاست؛ اینجا هیچ اندیکاسیون درمانی وجود ندارد.",
     "افزودن پردنیزولون فقط در درگیری چشمی تهدیدکننده یا ادم شدید مغزی جایی دارد.",
     "پاسخ صحیح — لنفادنوپاتی توکسوپلاسمایی در فرد سالم خودمحدود است و فقط پیگیری می‌خواهد."],
    ["The standard regimen, but not indicated in a healthy person with mild lymphadenopathy.",
     "The alternative for a sulfa-allergic patient; there is no treatment indication here at all.",
     "Adding prednisolone has a place only in sight-threatening ocular disease or severe cerebral oedema.",
     "Correct — toxoplasmic lymphadenopathy in a healthy person is self-limited and needs follow-up only."],
    "**ایمنی سالم + غیرباردار + فقط لنفادنوپاتی = بدون درمان.**",
    "Immunocompetent, not pregnant, lymphadenopathy only = no treatment.",
    REFS)

add("book:752", "vignette", "easy",
    "**نوجوان با لنفادنیت توکسوپلاسمایی: پیگیری بالینی بدون درمان — همان قاعده، بار دوم.**",
    "An adolescent with toxoplasmic lymphadenitis: clinical follow-up without treatment — the same rule, a second time.",
    LN_FA + [
        "**توصیف غدد در این سؤال دقیقاً توصیف کتابی لنفادنیت توکسوپلاسمایی است.**",
        "**مجزا (نه به هم چسبیده)، غیرحساس، و با سفتی مختصر.**",
        "⚠️ **و همین توصیف، لنفوم و سل غدد را کم‌احتمال‌تر می‌کند.**",
        "**در لنفوم غدد معمولاً بدون درد ولی سفت‌تر و پیشرونده‌اند.**",
        "**در سل غدد به هم می‌چسبند و می‌توانند فیستوله شوند.**",
    ],
    LN_EN + [
        "The description of the nodes here is the textbook description of toxoplasmic lymphadenitis.",
        "Discrete (not matted), non-tender, and only slightly firm.",
        "WARNING, AND THAT DESCRIPTION makes lymphoma and tuberculous nodes less likely.",
        "In lymphoma the nodes are usually painless but firmer and progressive.",
        "In tuberculosis the nodes become matted and can fistulate.",
    ],
    "این سؤال عملاً همان قبلی است، و کتاب آن را دوباره پرسیده — یعنی **این قاعده ارزش امتحانی "
    "بالایی دارد و باید بی‌درنگ در ذهن بیاید.**\n\n"
    "**بیمار: نوجوان با بزرگی غدد لنفاوی گردنی. غدد مجزا، غیرحساس، با سفتی مختصر. سرولوژی "
    "با توکسوپلاسموز حاد مطابقت دارد.**\n\n"
    "**نکته‌ی مهم: هیچ نشانه‌ای از نقص ایمنی، بارداری، یا درگیری احشایی وجود ندارد.** پس این "
    "یک **فرد سالم غیرباردار** است.\n\n"
    "⚠️ **پاسخ: پیگیری بالینی بدون نیاز به درمان.**\n\n"
    "**توصیف غدد را هم دقت کنید، چون آموزنده است:** «مجزا بوده، حساس نیستند و سفتی مختصر "
    "دارند». این دقیقاً توصیف کتابی لنفادنیت توکسوپلاسمایی است، و همین توصیف دو رقیب مهم را "
    "کم‌احتمال می‌کند: در **لنفوم** غدد سفت‌تر و پیشرونده‌اند و علائم B (تب، تعریق شبانه، کاهش "
    "وزن) دارند؛ در **لنفادنیت سلی** غدد به هم می‌چسبند و ممکن است فیستول بدهند.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**«استروئید + بیوپسی غده»:** بیوپسی وقتی لازم است که تشخیص روشن نباشد. اینجا سرولوژی "
    "تشخیص را داده است. و استروئید بدون اندیکاسیون، سرکوب ایمنی بی‌مورد است.\n\n"
    "**«پیریمتامین + سولفادیازین»:** درمان استاندارد است ولی اندیکاسیون ندارد.\n\n"
    "**«پیریمتامین + کلیندامایسین + استروئید»:** ترکیب پرعارضه‌ای است که فقط در توکسوپلاسموز "
    "**چشمی** یا **مغزی** جایی دارد.",
    "This question is essentially the previous one, and the book has asked it again — meaning THIS "
    "RULE CARRIES HIGH EXAM VALUE AND MUST COME TO MIND IMMEDIATELY.\n\n"
    "THE PATIENT: an adolescent with enlarged cervical nodes. The nodes are discrete, non-tender and "
    "slightly firm. The serology is consistent with acute toxoplasmosis.\n\n"
    "THE KEY POINT: there is no sign of immunodeficiency, pregnancy or visceral involvement. So this "
    "is an IMMUNOCOMPETENT, NON-PREGNANT person.\n\n"
    "WARNING, THE ANSWER: CLINICAL FOLLOW-UP WITHOUT TREATMENT.\n\n"
    "NOTE THE DESCRIPTION OF THE NODES TOO, BECAUSE IT IS INSTRUCTIVE: 'discrete, non-tender and "
    "slightly firm'. That is the textbook description of toxoplasmic lymphadenitis, and it makes two "
    "important competitors unlikely: in LYMPHOMA the nodes are firmer and progressive with B symptoms "
    "(fever, night sweats, weight loss); in TUBERCULOUS LYMPHADENITIS they become matted and may fistulate.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "'STEROID PLUS NODE BIOPSY': biopsy is needed when the diagnosis is unclear. Here the serology has "
    "made it. And an unindicated steroid is pointless immunosuppression.\n\n"
    "'PYRIMETHAMINE PLUS SULFADIAZINE': the standard regimen, but not indicated.\n\n"
    "'PYRIMETHAMINE PLUS CLINDAMYCIN PLUS STEROID': a toxic combination with a place only in OCULAR or "
    "CEREBRAL toxoplasmosis.",
    ["بیوپسی وقتی لازم است که تشخیص روشن نباشد؛ اینجا سرولوژی تشخیص را داده است.",
     "درمان استاندارد است ولی در فرد سالم با لنفادنیت خودمحدود اندیکاسیون ندارد.",
     "این ترکیب پرعارضه فقط در توکسوپلاسموز چشمی یا مغزی جایی دارد.",
     "پاسخ صحیح — لنفادنیت توکسوپلاسمایی در فرد سالم خودبه‌خود فروکش می‌کند."],
    ["Biopsy is needed when the diagnosis is unclear; here the serology has made it.",
     "The standard regimen, but not indicated in a healthy person with self-limited lymphadenitis.",
     "This toxic combination has a place only in ocular or cerebral toxoplasmosis.",
     "Correct — toxoplasmic lymphadenitis in a healthy person subsides on its own."],
    "**غدد مجزا و غیرحساس + سرولوژی حاد + فرد سالم = فقط پیگیری.**",
    "Discrete non-tender nodes plus acute serology plus a healthy host = follow-up only.",
    REFS)

add("book:754", "recall", "medium",
    "**سه مورد از چهار مورد حتماً درمان می‌شوند؛ استثنا لنفادنوپاتی فرد سالم است.**",
    "Three of the four MUST be treated; the exception is lymphadenopathy in an immunocompetent host.",
    LN_FA + [
        "**این سؤال چهار موقعیت را کنار هم گذاشته تا استثنا را پیدا کنید.**",
        "**انسفالیت توکسوپلاسمایی در ایدز: بدون درمان کشنده است.**",
        "**توکسوپلاسموز چشمی: بینایی را تهدید می‌کند، پس درمان می‌شود.**",
        "⚠️ **و توکسوپلاسموز مادرزادی: نوزاد یک سال کامل درمان می‌گیرد.**",
        "**تنها فرد ۱۷ ساله‌ی سالم با لنفادنوپاتی است که درمان نمی‌خواهد.**",
    ],
    LN_EN + [
        "This question lines up four situations so that you find the exception.",
        "Toxoplasmic encephalitis in AIDS: fatal without treatment.",
        "Ocular toxoplasmosis: sight-threatening, so it is treated.",
        "WARNING, AND CONGENITAL TOXOPLASMOSIS: the newborn is treated for a full year.",
        "Only the healthy 17-year-old with lymphadenopathy needs no treatment.",
    ],
    "این سؤال از نوع «همه به‌جز» است و دقیقاً همان درخت تصمیم را می‌سنجد، ولی این بار **همه‌ی "
    "شاخه‌ها را با هم**.\n\n"
    "**سه موردی که حتماً درمان می‌شوند:**\n\n"
    "⚠️ **انسفالیت توکسوپلاسمایی در فرد ایدزی:** این شایع‌ترین علت ضایعه‌ی حلقوی مغز در ایدز "
    "است و **بدون درمان کشنده است**. رژیم: پیریمتامین + سولفادیازین + فولینیک اسید، حداقل شش "
    "هفته، سپس درمان نگهدارنده تا بازسازی ایمنی.\n\n"
    "**توکسوپلاسموز چشمی:** کوریورتینیت فعال **بینایی را تهدید می‌کند** و می‌تواند به از دست "
    "رفتن دائمی دید منجر شود. درمان می‌شود، و اگر ضایعه نزدیک ماکولا یا عصب بینایی باشد، "
    "استروئید هم اضافه می‌شود.\n\n"
    "**توکسوپلاسموز مادرزادی:** نوزاد مبتلا **یک سال کامل** پیریمتامین + سولفادیازین + فولینیک "
    "اسید می‌گیرد. حتی نوزاد بدون علامت هم درمان می‌شود، چون درمان از بروز کوریورتینیت دیررس "
    "و آسیب عصبی جلوگیری می‌کند.\n\n"
    "**و استثنا:** **لنفادنوپاتی حاد گردنی در فرد ۱۷ ساله با ایمنی سالم.** این بیماری "
    "**خودمحدود** است، ظرف چند هفته تا چند ماه خودبه‌خود فروکش می‌کند، و درمان سمّی برای آن "
    "**آسیب بدون سود** است.\n\n"
    "⚠️ **درس روش‌شناختی این سؤال: در سؤال‌های «به‌جز»، به‌جای گشتن دنبال پاسخ، سه گزینه‌ی "
    "دیگر را تأیید کنید.** اگر مطمئن شدید سه مورد قطعاً درمان می‌خواهند، چهارمی خودبه‌خود "
    "پاسخ است.",
    "This is an 'all except' question and it tests exactly the same decision tree, but this time ALL "
    "THE BRANCHES AT ONCE.\n\n"
    "THE THREE THAT MUST BE TREATED:\n\n"
    "WARNING, TOXOPLASMIC ENCEPHALITIS IN AIDS: this is the commonest cause of a ring-enhancing brain "
    "lesion in AIDS and is FATAL WITHOUT TREATMENT. The regimen: pyrimethamine plus sulfadiazine plus "
    "folinic acid, for at least six weeks, then maintenance therapy until immune reconstitution.\n\n"
    "OCULAR TOXOPLASMOSIS: active chorioretinitis IS SIGHT-THREATENING and can cause permanent visual "
    "loss. It is treated, and if the lesion is near the macula or optic nerve a steroid is added.\n\n"
    "CONGENITAL TOXOPLASMOSIS: the affected newborn receives A FULL YEAR of pyrimethamine plus "
    "sulfadiazine plus folinic acid. Even an asymptomatic newborn is treated, because treatment "
    "prevents late chorioretinitis and neurological damage.\n\n"
    "AND THE EXCEPTION: ACUTE CERVICAL LYMPHADENOPATHY IN AN IMMUNOCOMPETENT 17-YEAR-OLD. This disease "
    "is SELF-LIMITED, subsides on its own within weeks to months, and toxic treatment for it is HARM "
    "WITHOUT BENEFIT.\n\n"
    "WARNING, THE METHODOLOGICAL LESSON HERE: IN 'EXCEPT' QUESTIONS, INSTEAD OF HUNTING FOR THE ANSWER, "
    "CONFIRM THE OTHER THREE. If you are sure three definitely need treatment, the fourth is the "
    "answer automatically.",
    ["بدون درمان کشنده است؛ شایع‌ترین علت ضایعه‌ی حلقوی مغز در ایدز.",
     "کوریورتینیت فعال بینایی را تهدید می‌کند، پس حتماً درمان می‌شود.",
     "پاسخ صحیح — لنفادنوپاتی در فرد سالم خودمحدود است و درمان اختصاصی نمی‌خواهد.",
     "نوزاد مبتلا یک سال کامل درمان می‌گیرد، حتی اگر بی‌علامت باشد."],
    ["Fatal without treatment; the commonest cause of a ring-enhancing brain lesion in AIDS.",
     "Active chorioretinitis is sight-threatening, so it is certainly treated.",
     "Correct — lymphadenopathy in a healthy host is self-limited and needs no specific treatment.",
     "The affected newborn is treated for a full year, even if asymptomatic."],
    "**درمان همیشه: نقص ایمنی · چشم · مادرزادی · باردار حاد. استثنا: لنفادنوپاتی فرد سالم.**",
    "Always treat: immunodeficiency, eye, congenital, acute in pregnancy. The exception: lymphadenopathy in a healthy host.",
    REFS)

add("book:747", "vignette", "hard",
    "**IgG و IgM مثبت در زن غیرباردار سالم: پیگیری سرولوژیک — نه درمان، نه تصویربرداری مغز.**",
    "IgG and IgM positive in a healthy non-pregnant woman: SEROLOGICAL FOLLOW-UP — not treatment, not brain imaging.",
    LN_FA + [
        "**این بیمار سه ویژگی دارد که همه‌ی گزینه‌های تهاجمی را حذف می‌کند.**",
        "**سالم است، دارو نمی‌گیرد، و باردار نیست — خودش در سؤال تصریح شده.**",
        "⚠️ **پس نه اندیکاسیون درمان دارد و نه اندیکاسیون بررسی نقص ایمنی.**",
        "**ولی «نیاز به اقدام خاصی ندارد» هم درست نیست، و دلیلش ظریف است.**",
        "**چون IgM مثبت است و این زن در سن باروری است.**",
        "**پیگیری سرولوژیک تعیین می‌کند عفونت چه زمانی رخ داده است.**",
        "⚠️ **و همین برای مشاوره‌ی بارداری آینده حیاتی است.**",
    ],
    LN_EN + [
        "This patient has three features that eliminate every invasive option.",
        "She is healthy, on no medication, and not pregnant — the question states this explicitly.",
        "WARNING, SO SHE HAS NEITHER a treatment indication NOR an indication to hunt for immunodeficiency.",
        "But 'no action is needed' is not right either, and the reason is subtle.",
        "Because the IgM is positive and this woman is of childbearing age.",
        "Serological follow-up establishes WHEN the infection occurred.",
        "WARNING, AND THAT IS VITAL for counselling about a future pregnancy.",
    ],
    "این سؤال از بقیه‌ی بلوک سخت‌تر است، چون **گزینه‌ی «هیچ اقدامی لازم نیست» وسوسه‌انگیز "
    "ولی نادرست است.**\n\n"
    "**بیمار: خانم جوان با لنفادنوپاتی متعدد و بدون درد در مثلث خلفی گردن، بدون سابقه‌ی "
    "بیماری، بدون مصرف دارو، و صریحاً غیرباردار. IgG و IgM ضد توکسو هر دو مثبت.**\n\n"
    "**اول ببینیم چه چیزی رد می‌شود:**\n\n"
    "**«درمان و بررسی از نظر نقص ایمنی زمینه‌ای»:** سؤال صریحاً گفته سابقه‌ی بیماری طبی و "
    "مصرف دارو ندارد. لنفادنوپاتی توکسوپلاسمایی در **فرد کاملاً سالم** بسیار شایع است و "
    "**به‌خودی‌خود نشانه‌ی نقص ایمنی نیست**. گشتن دنبال نقص ایمنی بدون هیچ سرنخ، هزینه و "
    "اضطراب بی‌مورد است.\n\n"
    "**«تصویربرداری از مغز و تست HIV»:** تصویربرداری مغز وقتی معنا دارد که علامت عصبی وجود "
    "داشته باشد یا بیمار نقص ایمنی داشته باشد. این بیمار هیچ‌کدام را ندارد.\n\n"
    "⚠️ **«نیاز به اقدام خاصی ندارد» — چرا این هم غلط است؟** این ظریف‌ترین بخش سؤال است. "
    "درست است که **درمان** لازم نیست، ولی **«اقدام» با «درمان» یکی نیست**. این خانم **در سن "
    "باروری** است و **IgM مثبت** دارد.\n\n"
    "**چرا این ترکیب مهم است؟** چون اگر عفونت او **تازه** باشد و ظرف چند ماه آینده باردار "
    "شود، **خطر انتقال به جنین وجود دارد**. اگر عفونت **قدیمی** باشد (و IgM فقط باقی‌مانده "
    "باشد — که تا یک سال یا بیشتر ممکن است)، هیچ خطری نیست.\n\n"
    "**پیگیری سرولوژیک تا ۶ ماه دقیقاً همین را روشن می‌کند:** سیر تیترها و در صورت لزوم تست "
    "**اویدیتی IgG** نشان می‌دهد عفونت چه زمانی رخ داده، و بر اساس آن می‌توان به بیمار گفت "
    "از چه زمانی بارداری بی‌خطر است.\n\n"
    "**پس پاسخ: پیگیری سرولوژیک تا ۶ ماه.**",
    "This question is harder than the rest of the block, because THE OPTION 'NO ACTION IS NEEDED' IS "
    "TEMPTING BUT WRONG.\n\n"
    "THE PATIENT: a young woman with multiple painless nodes in the posterior cervical triangle, no "
    "medical history, on no medication, and explicitly not pregnant. Anti-toxo IgG and IgM both positive.\n\n"
    "FIRST, WHAT IS REJECTED:\n\n"
    "'TREAT AND INVESTIGATE FOR UNDERLYING IMMUNODEFICIENCY': the question states she has no medical "
    "history and takes no drugs. Toxoplasmic lymphadenopathy is very common IN COMPLETELY HEALTHY "
    "PEOPLE and IS NOT IN ITSELF A SIGN OF IMMUNODEFICIENCY. Hunting for immunodeficiency without any "
    "clue is cost and anxiety for nothing.\n\n"
    "'BRAIN IMAGING AND AN HIV TEST': brain imaging makes sense when there is a neurological sign or "
    "the patient is immunosuppressed. She has neither.\n\n"
    "WARNING, 'NO PARTICULAR ACTION IS NEEDED' — WHY IS THIS ALSO WRONG? This is the subtlest part of "
    "the question. It is true that TREATMENT is not needed, but 'ACTION' IS NOT THE SAME AS "
    "'TREATMENT'. This woman is OF CHILDBEARING AGE and has a POSITIVE IgM.\n\n"
    "WHY DOES THAT COMBINATION MATTER? Because if her infection is RECENT and she conceives within the "
    "next few months, THERE IS A RISK OF TRANSMISSION TO THE FETUS. If the infection is OLD (with the "
    "IgM merely residual — which can persist a year or more), there is no risk at all.\n\n"
    "SEROLOGICAL FOLLOW-UP TO SIX MONTHS SETTLES EXACTLY THAT: the trend of the titres and, if needed, "
    "an IgG AVIDITY test show when the infection occurred, and on that basis she can be told from when "
    "pregnancy is safe.\n\n"
    "SO THE ANSWER: SEROLOGICAL FOLLOW-UP FOR UP TO SIX MONTHS.",
    ["سؤال صریحاً گفته بیمار سالم است؛ لنفادنوپاتی توکسو به‌خودی‌خود نشانه‌ی نقص ایمنی نیست.",
     "پاسخ صحیح — پیگیری سرولوژیک زمان عفونت را روشن می‌کند، که برای مشاوره‌ی بارداری حیاتی است.",
     "درمان لازم نیست، ولی «اقدام» با «درمان» یکی نیست؛ زمان‌بندی عفونت باید روشن شود.",
     "تصویربرداری مغز وقتی معنا دارد که علامت عصبی یا نقص ایمنی وجود داشته باشد."],
    ["The question states she is healthy; toxoplasmic lymphadenopathy is not in itself a sign of immunodeficiency.",
     "Correct — serological follow-up establishes when the infection occurred, which is vital for pregnancy counselling.",
     "Treatment is not needed, but 'action' is not the same as 'treatment'; the timing must be established.",
     "Brain imaging makes sense only with a neurological sign or immunosuppression."],
    "**IgM مثبت در زن سن باروری: درمان نه، ولی زمان‌بندی عفونت باید روشن شود.**",
    "Positive IgM in a woman of childbearing age: no treatment, but the timing of infection must be established.",
    REFS)

# ============================================ PRE-CONCEPTION AND OLD IMMUNITY
add("book:748", "vignette", "easy",
    "**IgG مثبت با IgM منفی پیش از بارداری: ایمنی قدیمی — جنین در امان است.**",
    "IgG positive with IgM negative before pregnancy: OLD IMMUNITY — the fetus is safe.",
    TREE_FA + [
        "**این ساده‌ترین و پرتکرارترین الگوی سرولوژیک بارداری است.**",
        "**IgG مثبت یعنی بدن قبلاً انگل را دیده و آنتی‌بادی ساخته است.**",
        "**IgM منفی یعنی عفونت تازه نیست.**",
        "⚠️ **ترکیب این دو یعنی: عفونت گذشته، ایمنی برقرار، خطر انتقال عملاً صفر.**",
        "**توکسوپلاسموز فقط در عفونت اولیه‌ی حین بارداری به جنین منتقل می‌شود.**",
        "**زنی که از قبل ایمن است، تاکیزوئیت در خون گردش نمی‌دهد.**",
        "**و بدون پارازیتمی، جفت آلوده نمی‌شود.**",
        "⚠️ **استثنا فقط مادر شدیداً دچار نقص ایمنی است که کیست‌های نهفته فعال می‌شوند.**",
    ],
    TREE_EN + [
        "This is the simplest and commonest serological pattern in pregnancy.",
        "A positive IgG means the body has met the parasite before and made antibody.",
        "A negative IgM means the infection is not recent.",
        "WARNING, THE COMBINATION MEANS: past infection, established immunity, essentially zero transmission risk.",
        "Toxoplasmosis is transmitted to the fetus only in PRIMARY infection during pregnancy.",
        "A woman already immune does not circulate tachyzoites in her blood.",
        "And without parasitaemia the placenta is not infected.",
        "WARNING, THE ONLY EXCEPTION is a severely immunosuppressed mother in whom latent cysts reactivate.",
    ],
    "این پرتکرارترین سؤال سرولوژی توکسوپلاسما در بارداری است و **پاسخ آن اطمینان دادن است، "
    "نه اقدام.**\n\n"
    "**الگوی سرولوژیک: IgG مثبت، IgM منفی — و این آزمایش «قبل از بارداری» انجام شده است.**\n\n"
    "**معنای این دو با هم:**\n\n"
    "**IgG مثبت** = بدن قبلاً توکسوپلاسما را دیده و آنتی‌بادی ساخته است.\n\n"
    "**IgM منفی** = عفونت **تازه نیست**.\n\n"
    "⚠️ **پس نتیجه قطعی است: عفونت گذشته، ایمنی برقرار.**\n\n"
    "**چرا این یعنی جنین در امان است؟ منطق را یاد بگیرید، نه فقط نتیجه را:**\n\n"
    "توکسوپلاسموز **فقط در عفونت اولیه‌ی حین بارداری** به جنین منتقل می‌شود. انتقال از راه "
    "**پارازیتمی** (گردش تاکیزوئیت در خون مادر) رخ می‌دهد که جفت را آلوده می‌کند. زنی که از "
    "قبل ایمن است، **پارازیتمی ندارد** — آنتی‌بادی‌های موجود انگل را فوراً مهار می‌کنند. "
    "**بدون پارازیتمی، جفت آلوده نمی‌شود.**\n\n"
    "**پس پاسخ: به مادر اطمینان می‌دهیم که خطری جنین را تهدید نمی‌کند.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**«تکرار سرولوژی در هر تریمستر»:** تکرار سرولوژی برای زن **سرونگاتیو** (IgG منفی) لازم "
    "است، چون او در معرض خطر است و باید سروکانورژن پایش شود. زن **سروپازیتیو** ایمن است و "
    "تکرار آزمایش هیچ اطلاعات جدیدی نمی‌دهد.\n\n"
    "**«PCR مایع آمنیوتیک در هفته‌ی ۱۸»:** آمنیوسنتز یک اقدام **تهاجمی** با خطر سقط است و "
    "فقط وقتی انجام می‌شود که **عفونت حاد مادر ثابت شده باشد**. اینجا عفونت حادی وجود ندارد.\n\n"
    "⚠️ **«شروع اسپیرامایسین»:** اسپیرامایسین برای کاهش انتقال در **عفونت حاد** است. در زن "
    "ایمن، چیزی برای کاهش دادن وجود ندارد.\n\n"
    "**استثنا که ارزش دانستن دارد:** در مادر **شدیداً دچار نقص ایمنی** (مثلاً ایدز پیشرفته)، "
    "کیست‌های نهفته می‌توانند فعال شوند و انتقال رخ دهد. ولی این استثنای نادری است و در این "
    "بیمار مطرح نیست.",
    "This is the commonest toxoplasma serology question in pregnancy, and ITS ANSWER IS REASSURANCE, "
    "NOT ACTION.\n\n"
    "THE SEROLOGICAL PATTERN: IgG positive, IgM negative — and the test was done BEFORE pregnancy.\n\n"
    "WHAT THE TWO MEAN TOGETHER:\n\n"
    "IgG POSITIVE = the body has met toxoplasma before and made antibody.\n\n"
    "IgM NEGATIVE = the infection IS NOT RECENT.\n\n"
    "WARNING, SO THE CONCLUSION IS DEFINITE: PAST INFECTION, ESTABLISHED IMMUNITY.\n\n"
    "WHY DOES THAT MEAN THE FETUS IS SAFE? LEARN THE LOGIC, NOT JUST THE CONCLUSION:\n\n"
    "Toxoplasmosis is transmitted to the fetus ONLY IN PRIMARY INFECTION DURING PREGNANCY. Transmission "
    "occurs through PARASITAEMIA (tachyzoites circulating in the mother's blood) which infects the "
    "placenta. A woman already immune HAS NO PARASITAEMIA — her existing antibodies contain the "
    "parasite at once. WITHOUT PARASITAEMIA THE PLACENTA IS NOT INFECTED.\n\n"
    "SO THE ANSWER: REASSURE THE MOTHER THAT NO RISK THREATENS THE FETUS.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "'REPEAT THE SEROLOGY EACH TRIMESTER': repeat serology is needed for a SERONEGATIVE woman (IgG "
    "negative), because she is at risk and seroconversion must be monitored. A SEROPOSITIVE woman is "
    "immune and repeating the test adds no information.\n\n"
    "'AMNIOTIC FLUID PCR AT 18 WEEKS': amniocentesis is an INVASIVE procedure carrying a miscarriage "
    "risk, and it is done only when ACUTE MATERNAL INFECTION HAS BEEN ESTABLISHED. There is no acute "
    "infection here.\n\n"
    "WARNING, 'START SPIRAMYCIN': spiramycin is for reducing transmission in ACUTE infection. In an "
    "immune woman there is nothing to reduce.\n\n"
    "THE EXCEPTION WORTH KNOWING: in a SEVERELY IMMUNOSUPPRESSED mother (for example advanced AIDS), "
    "latent cysts can reactivate and transmission can occur. But that is a rare exception and is not "
    "in question in this patient.",
    ["تکرار سرولوژی برای زن سرونگاتیو لازم است تا سروکانورژن پایش شود، نه برای زن ایمن.",
     "آمنیوسنتز تهاجمی است و فقط با عفونت حاد ثابت‌شده‌ی مادر انجام می‌شود.",
     "اسپیرامایسین برای کاهش انتقال در عفونت حاد است؛ در زن ایمن چیزی برای کاهش نیست.",
     "پاسخ صحیح — IgG مثبت با IgM منفی یعنی ایمنی قدیمی، و جنین در امان است."],
    ["Repeat serology is for a seronegative woman to monitor seroconversion, not for an immune one.",
     "Amniocentesis is invasive and is done only with established acute maternal infection.",
     "Spiramycin reduces transmission in acute infection; in an immune woman there is nothing to reduce.",
     "Correct — IgG positive with IgM negative means old immunity, and the fetus is safe."],
    "**IgG مثبت + IgM منفی = ایمنی قدیمی = جنین در امان.**",
    "IgG positive plus IgM negative = old immunity = the fetus is safe.",
    REFS)

add("book:749", "vignette", "easy",
    "**همان الگو، این بار با سند مکتوب از پنج سال پیش: قطعاً ایمنی قدیمی.**",
    "The same pattern, this time with written evidence from five years ago: definitely old immunity.",
    TREE_FA + [
        "**اینجا کتاب یک سند اضافه داده تا هیچ تردیدی نماند.**",
        "**در حاملگی قبلی، پنج سال پیش، همین الگو ثبت شده است.**",
        "⚠️ **یعنی IgG دست‌کم پنج سال است مثبت و IgM دست‌کم پنج سال است منفی.**",
        "**پس حتی احتمال IgM باقی‌مانده هم منتفی است.**",
        "**این قوی‌ترین شکل اثبات ایمنی قدیمی در سرولوژی است: دو نقطه‌ی زمانی دور از هم.**",
        "**و پیام بالینی روشن است: هیچ اقدام اضافی لازم نیست.**",
    ],
    TREE_EN + [
        "Here the book adds a document so that no doubt remains.",
        "In her previous pregnancy, five years ago, the very same pattern was recorded.",
        "WARNING, THAT MEANS the IgG has been positive for at least five years and the IgM negative for at least five years.",
        "So even the possibility of residual IgM is excluded.",
        "This is the strongest form of serological proof of old immunity: two widely separated time points.",
        "And the clinical message is clear: no additional action is needed.",
    ],
    "این سؤال همان قاعده‌ی قبلی است، ولی کتاب **یک سند مکتوب** اضافه کرده تا پاسخ کاملاً "
    "قطعی شود.\n\n"
    "**بیمار: خانم جوان، بارداری ۱۲ هفته، IgG ضد توکسوپلاسما مثبت و IgM منفی. و در پرونده‌ی "
    "حاملگی قبلی — پنج سال پیش — دقیقاً همین الگو ثبت شده است.**\n\n"
    "⚠️ **چرا این سند اهمیت دارد؟** چون تنها ابهام ممکن در الگوی «IgG مثبت، IgM منفی» را "
    "هم برطرف می‌کند. **IgG دست‌کم پنج سال است مثبت است و IgM دست‌کم پنج سال است منفی.** "
    "پس عفونت **قطعاً** سال‌ها پیش رخ داده و **ایمنی کاملاً برقرار** است.\n\n"
    "**در سرولوژی، دو نقطه‌ی زمانی دور از هم قوی‌ترین شکل اثبات است.** یک آزمایش تنها همیشه "
    "یک عکس لحظه‌ای است؛ دو آزمایش با فاصله‌ی پنج سال، یک روند را نشان می‌دهد.\n\n"
    "**پاسخ: نیاز به اقدام اضافی دیگری نیست.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**«شروع اسپیرامایسین»:** اسپیرامایسین برای کاهش انتقال در **عفونت حاد مادر** است. اینجا "
    "عفونت حادی وجود ندارد و انتقالی هم در کار نیست.\n\n"
    "**«پیریمتامین + سولفادیازین + فولینیک اسید»:** این رژیم برای **جنین اثبات‌شده آلوده** "
    "است. و نکته‌ی مهم‌تر: **پیریمتامین تراتوژن است و پیش از هفته‌ی ۱۴ اصلاً داده نمی‌شود** — "
    "این بیمار در هفته‌ی ۱۲ است. پس این گزینه نه‌فقط بی‌مورد بلکه **خطرناک** است.\n\n"
    "⚠️ **«تکرار آزمایش خون ۴ هفته بعد»:** تکرار آزمایش وقتی معنا دارد که بخواهیم **سروکانورژن** "
    "یا **افزایش تیتر** را بگیریم. در زنی که پنج سال است سروپازیتیو با IgM منفی است، تکرار "
    "آزمایش هیچ اطلاعات جدیدی نمی‌دهد — فقط هزینه و اضطراب اضافه می‌کند.",
    "This question is the same rule as the previous one, but the book adds A WRITTEN DOCUMENT so the "
    "answer becomes entirely certain.\n\n"
    "THE PATIENT: a young woman, 12 weeks pregnant, anti-toxoplasma IgG positive and IgM negative. And "
    "her record from her previous pregnancy — five years ago — shows exactly the same pattern.\n\n"
    "WARNING, WHY DOES THAT DOCUMENT MATTER? Because it removes the only possible ambiguity in an 'IgG "
    "positive, IgM negative' pattern. THE IgG HAS BEEN POSITIVE FOR AT LEAST FIVE YEARS AND THE IgM "
    "NEGATIVE FOR AT LEAST FIVE YEARS. So the infection DEFINITELY occurred years ago and immunity is "
    "fully established.\n\n"
    "IN SEROLOGY, TWO WIDELY SEPARATED TIME POINTS ARE THE STRONGEST FORM OF PROOF. A single test is "
    "always a snapshot; two tests five years apart show a trend.\n\n"
    "THE ANSWER: NO FURTHER ACTION IS NEEDED.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "'START SPIRAMYCIN': spiramycin reduces transmission in ACUTE MATERNAL INFECTION. There is no acute "
    "infection here and no transmission to prevent.\n\n"
    "'PYRIMETHAMINE PLUS SULFADIAZINE PLUS FOLINIC ACID': this regimen is for a PROVEN INFECTED FETUS. "
    "And more importantly: PYRIMETHAMINE IS TERATOGENIC AND IS NOT GIVEN AT ALL BEFORE WEEK 14 — this "
    "patient is at 12 weeks. So this option is not merely unnecessary but DANGEROUS.\n\n"
    "WARNING, 'REPEAT THE BLOOD TEST IN FOUR WEEKS': repeating makes sense when we want to catch "
    "SEROCONVERSION or a RISING TITRE. In a woman seropositive with a negative IgM for five years, "
    "repeating adds no information — only cost and anxiety.",
    ["اسپیرامایسین برای عفونت حاد مادر است؛ اینجا عفونت حادی وجود ندارد.",
     "این رژیم برای جنین اثبات‌شده آلوده است، و پیریمتامین پیش از هفته‌ی ۱۴ تراتوژن و ممنوع است.",
     "تکرار آزمایش وقتی معنا دارد که سروکانورژن محتمل باشد؛ اینجا الگو پنج سال ثابت است.",
     "پاسخ صحیح — الگوی ثابت پنج ساله یعنی ایمنی قدیمی قطعی؛ هیچ اقدامی لازم نیست."],
    ["Spiramycin is for acute maternal infection; there is none here.",
     "That regimen is for a proven infected fetus, and pyrimethamine is teratogenic and banned before week 14.",
     "Repeating makes sense when seroconversion is possible; here the pattern has been stable for five years.",
     "Correct — a stable five-year pattern means definite old immunity; no action is needed."],
    "**دو آزمایش با فاصله‌ی پنج سال، قوی‌ترین سند ایمنی قدیمی است.**",
    "Two tests five years apart are the strongest evidence of old immunity.",
    REFS)

# ================================== PRE-CONCEPTION COUNSELLING: TWO ITEMS
DELAY_FA = TREE_FA + [
    "**وقتی عفونت حاد در زن غیرباردار رخ دهد، سؤال بعدی «کی باردار شود؟» است.**",
    "⚠️ **پاسخ: شش ماه صبر — و این عدد را دقیق حفظ کنید.**",
    "**دلیلش پارازیتمی است: تاکیزوئیت‌ها فقط در فاز حاد در خون گردش می‌کنند.**",
    "**پس از چند ماه، انگل به کیست بافتی تبدیل می‌شود و از خون پاک می‌شود.**",
    "**و انگلِ محبوس در کیست بافتی، از جفت عبور نمی‌کند.**",
    "⚠️ **پس شش ماه، فاصله‌ی امنی است که پارازیتمی قطعاً تمام شده باشد.**",
    "**و در این فاصله هیچ درمانی لازم نیست، چون فرد سالم است.**",
]
DELAY_EN = TREE_EN + [
    "When acute infection occurs in a non-pregnant woman, the next question is 'when may she conceive?'",
    "WARNING, THE ANSWER: WAIT SIX MONTHS — and memorise that number precisely.",
    "The reason is parasitaemia: tachyzoites circulate in the blood only during the acute phase.",
    "After some months the parasite converts to tissue cysts and clears from the blood.",
    "And a parasite locked inside a tissue cyst does not cross the placenta.",
    "WARNING, SO SIX MONTHS IS A SAFE INTERVAL by which parasitaemia has certainly ended.",
    "And no treatment is needed in the meantime, because the person is healthy.",
]

add("book:757", "vignette", "hard",
    "**لنفادنیت توکسو دو ماه پیش: بدون درمان، و بارداری چهار ماه دیگر تا مجموع شش ماه کامل شود.**",
    "Toxoplasmic lymphadenitis two months ago: no treatment, and delay pregnancy another four months so the total reaches six.",
    DELAY_FA + [
        "**این سؤال حساب ساده‌ای دارد که باید انجامش دهید، نه اینکه عدد را حفظ کنید.**",
        "**عفونت دو ماه پیش تشخیص داده شده است.**",
        "⚠️ **قاعده شش ماه است، پس چهار ماه دیگر باقی مانده.**",
        "**و همین «۴ ماه» گزینه را از بقیه جدا می‌کند.**",
        "**تکرار سریال IgM تا منفی شدن، بی‌فایده است چون ممکن است سال‌ها مثبت بماند.**",
    ],
    DELAY_EN + [
        "This question requires a small calculation, not the recall of a number.",
        "The infection was diagnosed two months ago.",
        "WARNING, THE RULE IS SIX MONTHS, so four months remain.",
        "And that '4 months' is what separates the correct option from the rest.",
        "Serial IgM testing until it turns negative is futile, because it can stay positive for years.",
    ],
    "این سؤال از بقیه‌ی خوشه سخت‌تر است چون **یک محاسبه** می‌خواهد، نه فقط یادآوری یک قاعده.\n\n"
    "**موقعیت: خانم جوان برای مشاوره‌ی قبل از بارداری آمده. دو ماه پیش برای او تشخیص لنفادنیت "
    "توکسوپلاسما مطرح شده و IgG و IgM هر دو مثبت بوده‌اند.**\n\n"
    "**دو سؤال باید پاسخ بگیرد: درمان لازم است؟ و کی می‌تواند باردار شود؟**\n\n"
    "**سؤال اول — درمان؟ نه.** او **غیرباردار و دارای ایمنی سالم** است و فقط لنفادنیت دارد. "
    "همان قاعده‌ی همیشگی: **درمان لازم نیست.**\n\n"
    "⚠️ **سؤال دوم — کی باردار شود؟ اینجا قاعده‌ی شش ماه وارد می‌شود.**\n\n"
    "**چرا شش ماه؟ منطق را بدانید، نه فقط عدد را:** انتقال توکسوپلاسما به جنین از راه "
    "**پارازیتمی** رخ می‌دهد — یعنی گردش تاکیزوئیت‌ها در خون مادر. تاکیزوئیت‌ها **فقط در فاز "
    "حاد** در خون هستند. پس از چند ماه، انگل به **کیست بافتی** تبدیل می‌شود (عمدتاً در عضله و "
    "مغز) و از خون پاک می‌شود. **انگلِ محبوس در کیست بافتی از جفت عبور نمی‌کند.** شش ماه فاصله‌ی "
    "امنی است که مطمئن باشیم پارازیتمی تمام شده.\n\n"
    "**حالا محاسبه:** عفونت **دو ماه پیش** بوده. شش منهای دو می‌شود **چهار ماه دیگر**.\n\n"
    "**پس پاسخ: بدون نیاز به درمان + به تأخیر انداختن بارداری تا ۴ ماه دیگر.**\n\n"
    "**چرا بقیه رد می‌شوند؟**\n\n"
    "**«پیریمتامین و سولفادیازین»:** درمان سمّی برای بیماری خودمحدود در فرد سالم.\n\n"
    "⚠️ **«تکرار سریال تست تا منفی شدن IgM»:** این گزینه‌ی وسوسه‌انگیز و **کاملاً غلط** است. "
    "**IgM ضد توکسوپلاسما می‌تواند یک سال، دو سال یا حتی بیشتر مثبت بماند.** منتظر منفی شدن آن "
    "ماندن یعنی ممکن است بیمار سال‌ها بارداری را به تعویق بیندازد بدون هیچ دلیل پزشکی.\n\n"
    "**«اسپیرامایسین و تکرار IgM»:** اسپیرامایسین برای **زن باردار** با عفونت حاد است تا انتقال "
    "به جنین کم شود. این خانم **باردار نیست** — جنینی وجود ندارد که از او محافظت شود.",
    "This question is harder than the rest of the cluster because it requires A CALCULATION, not just "
    "recall of a rule.\n\n"
    "THE SITUATION: a young woman comes for pre-conception counselling. Two months ago she was "
    "diagnosed with toxoplasmic lymphadenitis, with IgG and IgM both positive.\n\n"
    "TWO QUESTIONS MUST BE ANSWERED: is treatment needed? And when may she conceive?\n\n"
    "FIRST QUESTION — TREATMENT? NO. She is NON-PREGNANT AND IMMUNOCOMPETENT with lymphadenitis alone. "
    "The usual rule: NO TREATMENT IS NEEDED.\n\n"
    "WARNING, SECOND QUESTION — WHEN MAY SHE CONCEIVE? Here the six-month rule enters.\n\n"
    "WHY SIX MONTHS? KNOW THE LOGIC, NOT JUST THE NUMBER: transmission of toxoplasma to the fetus "
    "occurs through PARASITAEMIA — tachyzoites circulating in the mother's blood. Tachyzoites are in "
    "the blood ONLY DURING THE ACUTE PHASE. After some months the parasite converts to TISSUE CYSTS "
    "(mainly in muscle and brain) and clears from the blood. A PARASITE LOCKED IN A TISSUE CYST DOES "
    "NOT CROSS THE PLACENTA. Six months is a safe interval by which parasitaemia has certainly ended.\n\n"
    "NOW THE CALCULATION: the infection was TWO MONTHS AGO. Six minus two leaves FOUR MORE MONTHS.\n\n"
    "SO THE ANSWER: NO TREATMENT NEEDED, PLUS DELAYING PREGNANCY FOR ANOTHER FOUR MONTHS.\n\n"
    "WHY ARE THE OTHERS REJECTED?\n\n"
    "'PYRIMETHAMINE AND SULFADIAZINE': toxic treatment for a self-limited disease in a healthy person.\n\n"
    "WARNING, 'SERIAL TESTING UNTIL THE IgM TURNS NEGATIVE': this is the tempting and COMPLETELY WRONG "
    "option. ANTI-TOXOPLASMA IgM CAN STAY POSITIVE FOR ONE YEAR, TWO YEARS OR EVEN LONGER. Waiting for "
    "it to turn negative could delay her pregnancy for years with no medical reason at all.\n\n"
    "'SPIRAMYCIN AND REPEAT IgM': spiramycin is for A PREGNANT WOMAN with acute infection, to reduce "
    "transmission to the fetus. This woman IS NOT PREGNANT — there is no fetus to protect.",
    ["درمان سمّی برای بیماری خودمحدود در فرد سالم غیرباردار؛ اندیکاسیون ندارد.",
     "IgM می‌تواند سال‌ها مثبت بماند؛ انتظار برای منفی شدن آن بارداری را بی‌دلیل به تعویق می‌اندازد.",
     "پاسخ صحیح — بدون درمان، و چهار ماه دیگر صبر تا مجموع شش ماه از عفونت کامل شود.",
     "اسپیرامایسین برای زن باردار با عفونت حاد است؛ این خانم باردار نیست."],
    ["Toxic treatment for a self-limited disease in a healthy non-pregnant woman; not indicated.",
     "IgM can stay positive for years; waiting for it to clear delays pregnancy for no reason.",
     "Correct — no treatment, and another four months' wait so six months from the infection are complete.",
     "Spiramycin is for a pregnant woman with acute infection; this woman is not pregnant."],
    "**عفونت حاد در زن غیرباردار: شش ماه از زمان عفونت صبر، نه از امروز.**",
    "Acute infection in a non-pregnant woman: wait six months FROM THE INFECTION, not from today.",
    REFS)

add("book:758", "vignette", "medium",
    "**IgG و IgM مثبت در زن غیرباردار: بدون درمان، و شش ماه تأخیر در بارداری.**",
    "IgG and IgM positive in a non-pregnant woman: no treatment, and a six-month delay before conceiving.",
    DELAY_FA + [
        "**این سؤال دقیقاً همان قاعده است، ولی بدون محاسبه.**",
        "**عفونت تازه تشخیص داده شده، پس شش ماه کامل باقی است.**",
        "⚠️ **و «سه ماه» عدد اشتباه رایج است که کتاب آن را به‌عنوان دام گذاشته.**",
        "**سه ماه برای پاک شدن پارازیتمی تضمین‌شده نیست.**",
        "**و دو گزینه‌ی «درمان توکسوپلاسموز» هم همان اشتباه همیشگی است.**",
    ],
    DELAY_EN + [
        "This question is exactly the same rule, but without the calculation.",
        "The infection has just been diagnosed, so the full six months remain.",
        "WARNING, AND 'THREE MONTHS' IS THE COMMON WRONG NUMBER the book plants as a trap.",
        "Three months does not guarantee that parasitaemia has cleared.",
        "And the two 'treat the toxoplasmosis' options repeat the usual mistake.",
    ],
    "این سؤال همان قاعده‌ی شش ماه است، ولی این بار **مستقیم** — بدون نیاز به محاسبه.\n\n"
    "**بیمار: خانم ۳۰ ساله با آدنوپاتی گردنی از یک هفته قبل، بدون هیچ علامت بالینی دیگر. "
    "IgM و IgG هر دو مثبت.**\n\n"
    "**پس دو تصمیم لازم است:**\n\n"
    "**تصمیم اول — درمان؟ نه.** فرد سالم، غیرباردار، فقط لنفادنوپاتی و **فاقد هرگونه علائم "
    "بالینی**. سؤال خودش تصریح کرده که بیمار بی‌علامت است. **بیماری خودمحدود است.**\n\n"
    "⚠️ **تصمیم دوم — بارداری؟ شش ماه تأخیر.**\n\n"
    "**چرا شش و نه سه؟** چون **پارازیتمی** (گردش تاکیزوئیت در خون) باید کاملاً تمام شده باشد. "
    "تبدیل تاکیزوئیت به کیست بافتی چند ماه طول می‌کشد، و **سه ماه فاصله‌ی مطمئنی نیست**. شش "
    "ماه توصیه‌ی استاندارد است که در آن پارازیتمی قطعاً پایان یافته و انگل در کیست‌های بافتی "
    "محبوس شده است. **انگلِ داخل کیست بافتی از جفت عبور نمی‌کند.**\n\n"
    "**پس پاسخ: بدون درمان، عدم بارداری تا شش ماه.**\n\n"
    "**چهار گزینه‌ی این سؤال دقیقاً دو در دو چیده شده‌اند** (درمان یا نه × سه ماه یا شش ماه)، "
    "و همین آن را به سؤال خوبی برای سنجش تبدیل کرده: باید **هر دو** بخش را درست بدانید.\n\n"
    "**«بدون درمان، سه ماه»:** بخش درمان درست، بخش زمان غلط.\n\n"
    "**«درمان، شش ماه»:** بخش زمان درست، بخش درمان غلط.\n\n"
    "**«درمان، سه ماه»:** هر دو غلط.\n\n"
    "⚠️ **و یادآوری: پیریمتامین + سولفادیازین سمّی است — سرکوب مغز استخوان و آسیب کلیه. "
    "دادن آن به فرد سالمی که خودبه‌خود خوب می‌شود، آسیب بدون سود است.**",
    "This question is the same six-month rule, but this time DIRECTLY — with no calculation needed.\n\n"
    "THE PATIENT: a 30-year-old woman with cervical adenopathy for one week and NO other clinical "
    "features. IgM and IgG both positive.\n\n"
    "SO TWO DECISIONS ARE NEEDED:\n\n"
    "FIRST DECISION — TREATMENT? NO. Healthy, non-pregnant, lymphadenopathy alone and NO CLINICAL "
    "SYMPTOMS AT ALL. The question states explicitly that she is asymptomatic. THE DISEASE IS "
    "SELF-LIMITED.\n\n"
    "WARNING, SECOND DECISION — PREGNANCY? DELAY SIX MONTHS.\n\n"
    "WHY SIX AND NOT THREE? Because PARASITAEMIA (tachyzoites circulating in the blood) must have "
    "ended completely. Conversion of tachyzoites into tissue cysts takes several months, and THREE "
    "MONTHS IS NOT A RELIABLE INTERVAL. Six months is the standard recommendation, by which "
    "parasitaemia has certainly finished and the parasite is locked inside tissue cysts. A PARASITE "
    "INSIDE A TISSUE CYST DOES NOT CROSS THE PLACENTA.\n\n"
    "SO THE ANSWER: NO TREATMENT, NO PREGNANCY FOR SIX MONTHS.\n\n"
    "THE FOUR OPTIONS ARE ARRANGED EXACTLY TWO BY TWO (treat or not, times three or six months), which "
    "makes this a good discriminating question: BOTH parts must be right.\n\n"
    "'NO TREATMENT, THREE MONTHS': treatment part right, timing wrong.\n\n"
    "'TREAT, SIX MONTHS': timing right, treatment part wrong.\n\n"
    "'TREAT, THREE MONTHS': both wrong.\n\n"
    "WARNING, AND A REMINDER: PYRIMETHAMINE PLUS SULFADIAZINE IS TOXIC — marrow suppression and renal "
    "injury. Giving it to a healthy person who will recover anyway is harm without benefit.",
    ["پاسخ صحیح — بدون درمان چون فرد سالم و بی‌علامت است، و شش ماه تأخیر تا پارازیتمی تمام شود.",
     "بخش درمان درست است ولی سه ماه فاصله‌ی مطمئنی برای پاک شدن پارازیتمی نیست.",
     "زمان درست است ولی درمان سمّی در فرد سالم بی‌علامت اندیکاسیون ندارد.",
     "هر دو بخش نادرست است: نه درمان لازم است و نه سه ماه کافی است."],
    ["Correct — no treatment because she is healthy and asymptomatic, and six months' delay for parasitaemia to clear.",
     "The treatment part is right but three months is not a reliable interval for parasitaemia to clear.",
     "The timing is right but toxic treatment is not indicated in a healthy asymptomatic person.",
     "Both parts are wrong: no treatment is needed and three months is not enough."],
    "**شش ماه، نه سه — چون پارازیتمی باید کاملاً تمام شده باشد.**",
    "Six months, not three — because parasitaemia must have completely ended.",
    REFS)

# ============================================ ACUTE INFECTION IN PREGNANCY
add("book:753", "vignette", "medium",
    "**اسپیرامایسین انتقال از جفت را کم می‌کند — و دو حقیقتِ خلاف‌جهت درباره‌ی سن بارداری را باید بدانید.**",
    "Spiramycin reduces placental transmission — and you must know the TWO OPPOSING FACTS about gestational age.",
    TREE_FA + [
        "⚠️ **دو حقیقت درباره‌ی سن بارداری در جهت مخالف هم حرکت می‌کنند.**",
        "**میزان انتقال با افزایش سن بارداری بالا می‌رود.**",
        "**سه‌ماهه‌ی اول حدود ۱۰ تا ۱۵ درصد؛ سه‌ماهه‌ی سوم ۶۰ درصد یا بیشتر.**",
        "**ولی شدت بیماری جنین با افزایش سن بارداری پایین می‌آید.**",
        "⚠️ **یعنی عفونت سه‌ماهه‌ی اول کم‌احتمال ولی ویرانگر است.**",
        "**و عفونت سه‌ماهه‌ی سوم محتمل ولی خفیف است.**",
        "**دلیلش جفت است: با رشد جفت، نفوذپذیری آن بیشتر می‌شود.**",
        "**و همزمان جنین توانایی بیشتری برای تحمل آسیب پیدا می‌کند.**",
        "**نوزاد آلوده در سه‌ماهه‌ی سوم معمولاً در تولد طبیعی به نظر می‌رسد.**",
        "⚠️ **ولی سال‌ها بعد با کوریورتینیت خود را نشان می‌دهد — پس درمان نوزاد بی‌فایده نیست.**",
    ],
    TREE_EN + [
        "WARNING: TWO FACTS ABOUT GESTATIONAL AGE RUN IN OPPOSITE DIRECTIONS.",
        "The RATE of transmission RISES with gestational age.",
        "First trimester about 10 to 15%; third trimester 60% or more.",
        "But the SEVERITY of fetal disease FALLS with gestational age.",
        "WARNING, SO FIRST-TRIMESTER INFECTION IS UNLIKELY BUT DEVASTATING.",
        "And third-trimester infection is likely but mild.",
        "The reason is the placenta: as it grows it becomes more permeable.",
        "And at the same time the fetus becomes better able to withstand the insult.",
        "A baby infected in the third trimester usually looks normal at birth.",
        "WARNING, BUT DECLARES ITSELF YEARS LATER WITH CHORIORETINITIS — so treating the newborn is not futile.",
    ],
    "این سؤال چهار ادعا را کنار هم گذاشته و می‌خواهد **تنها ادعای درست** را پیدا کنید. سه تا "
    "از آن‌ها دقیقاً **برعکس** واقعیت‌اند، و همین آن را به سؤال آموزنده‌ای تبدیل می‌کند.\n\n"
    "**بیمار: خانم باردار دو ماهه با لنفادنوپاتی گردنی، و IgG و IgM هر دو مثبت** — یعنی احتمال "
    "عفونت حاد در بارداری.\n\n"
    "**گزینه‌ی درست: «درمان با اسپیرامایسین در مادر باردار انتقال توکسوپلاسما را از جفت "
    "کاهش می‌دهد.»**\n\n"
    "⚠️ **چرا این درست است و مکانیسمش چیست؟** اسپیرامایسین یک ماکرولید است که **در بافت جفت "
    "تغلیظ می‌شود**. با غلظت بالا در جفت، انگل را همان‌جا مهار می‌کند و **از عبور آن به جنین "
    "جلوگیری می‌کند**. ولی خودِ دارو **از جفت عبور نمی‌کند** — و همین دو ویژگی کنار هم، نقش و "
    "محدودیت آن را تعریف می‌کند: **انتقال را کم می‌کند، ولی جنینِ از قبل آلوده را درمان نمی‌کند.**\n\n"
    "**حالا سه ادعای نادرست:**\n\n"
    "**«در صورت عفونت جنین، درمان ضد توکسوپلاسما در نوزاد متولدشده بی‌فایده است»:** این "
    "**کاملاً غلط** است. نوزاد مبتلا **یک سال کامل** پیریمتامین + سولفادیازین + فولینیک اسید "
    "می‌گیرد، و این درمان **از بروز کوریورتینیت دیررس و آسیب عصبی جلوگیری می‌کند**. حتی نوزاد "
    "بی‌علامت هم درمان می‌شود.\n\n"
    "⚠️ **«در سه‌ماهه‌ی اول ابتلای جنین بیشتر است»:** این **برعکس** است. **میزان انتقال در "
    "سه‌ماهه‌ی اول کمترین است (حدود ۱۰ تا ۱۵ درصد)** و در سه‌ماهه‌ی سوم به **۶۰ درصد یا بیشتر** "
    "می‌رسد. علتش رشد جفت و افزایش نفوذپذیری آن است.\n\n"
    "**«در سه‌ماهه‌ی اول شدت بیماری در کودک کمتر است»:** این هم **برعکس** است. **عفونت "
    "سه‌ماهه‌ی اول ویرانگرترین است** — سقط، هیدروسفالی، کلسیفیکاسیون وسیع مغزی و آسیب شدید "
    "عصبی.\n\n"
    "**پس این دو حقیقت را با هم حفظ کنید و قاطی نکنید:**\n\n"
    "**احتمال انتقال ↑ با سن بارداری. شدت بیماری ↓ با سن بارداری.**",
    "This question lines up four claims and asks you to find THE ONLY TRUE ONE. Three of them are "
    "exactly THE REVERSE of reality, which is what makes it instructive.\n\n"
    "THE PATIENT: a woman two months pregnant with cervical lymphadenopathy and both IgG and IgM "
    "positive — so possible acute infection in pregnancy.\n\n"
    "THE CORRECT OPTION: 'treatment with spiramycin in the pregnant mother reduces transmission of "
    "toxoplasma across the placenta.'\n\n"
    "WARNING, WHY IS THAT TRUE AND WHAT IS THE MECHANISM? Spiramycin is a macrolide that CONCENTRATES "
    "IN PLACENTAL TISSUE. At a high concentration in the placenta it contains the parasite there and "
    "PREVENTS ITS PASSAGE TO THE FETUS. But the drug itself DOES NOT CROSS THE PLACENTA — and those "
    "two properties together define both its role and its limitation: IT REDUCES TRANSMISSION BUT DOES "
    "NOT TREAT A FETUS THAT IS ALREADY INFECTED.\n\n"
    "NOW THE THREE FALSE CLAIMS:\n\n"
    "'IF THE FETUS IS INFECTED, ANTI-TOXOPLASMA TREATMENT OF THE NEWBORN IS USELESS': this is "
    "COMPLETELY WRONG. An affected newborn receives A FULL YEAR of pyrimethamine plus sulfadiazine "
    "plus folinic acid, and that treatment PREVENTS LATE CHORIORETINITIS AND NEUROLOGICAL DAMAGE. Even "
    "an asymptomatic newborn is treated.\n\n"
    "WARNING, 'FETAL INFECTION IS MORE COMMON IN THE FIRST TRIMESTER': this is THE REVERSE. THE "
    "TRANSMISSION RATE IS LOWEST IN THE FIRST TRIMESTER (about 10 to 15%) and reaches 60% OR MORE in "
    "the third. The reason is the growth of the placenta and its rising permeability.\n\n"
    "'DISEASE IN THE CHILD IS MILDER AFTER FIRST-TRIMESTER INFECTION': also THE REVERSE. "
    "FIRST-TRIMESTER INFECTION IS THE MOST DEVASTATING — miscarriage, hydrocephalus, extensive "
    "cerebral calcification and severe neurological damage.\n\n"
    "SO MEMORISE THE TWO FACTS TOGETHER AND DO NOT MIX THEM UP:\n\n"
    "TRANSMISSION RISK RISES with gestational age. DISEASE SEVERITY FALLS with gestational age.",
    ["پاسخ صحیح — اسپیرامایسین در جفت تغلیظ می‌شود و انتقال به جنین را کاهش می‌دهد.",
     "کاملاً غلط — نوزاد مبتلا یک سال درمان می‌گیرد که از کوریورتینیت دیررس جلوگیری می‌کند.",
     "برعکس است — انتقال در سه‌ماهه‌ی اول کمترین (حدود ۱۰ تا ۱۵ درصد) و در سوم بیشترین است.",
     "برعکس است — عفونت سه‌ماهه‌ی اول ویرانگرترین شکل بیماری را می‌سازد."],
    ["Correct — spiramycin concentrates in the placenta and reduces transmission to the fetus.",
     "Completely wrong — the affected newborn is treated for a year, which prevents late chorioretinitis.",
     "The reverse — transmission is lowest in the first trimester (10 to 15%) and highest in the third.",
     "The reverse — first-trimester infection produces the most devastating disease."],
    "**احتمال انتقال با سن بارداری بالا می‌رود؛ شدت بیماری پایین می‌آید.**",
    "Transmission risk rises with gestational age; disease severity falls.",
    REFS)

add("book:755", "vignette", "hard",
    "**سروکانورژن اثبات‌شده در هفته‌ی ۲۸: عفونت حاد قطعی و بارداری پیشرفته — پیریمتامین + سولفادیازین.**",
    "Proven seroconversion at 28 weeks: definite acute infection in an advanced pregnancy — PYRIMETHAMINE PLUS SULFADIAZINE.",
    TREE_FA + [
        "⚠️ **کلید این سؤال یک جمله است: اسکرین پیش از بارداری منفی بوده.**",
        "**پس این یک سروکانورژن اثبات‌شده است، نه یک IgM مشکوک.**",
        "**یعنی عفونت قطعاً در همین بارداری رخ داده است.**",
        "**و بیمار در هفته‌ی ۲۸ است، یعنی سه‌ماهه‌ی سوم.**",
        "⚠️ **در سه‌ماهه‌ی سوم، میزان انتقال به جنین ۶۰ درصد یا بیشتر است.**",
        "**پس احتمال آلودگی جنین بسیار بالاست، نه فرضی.**",
        "**و اسپیرامایسین برای بارداری‌های پیش از هفته‌ی ۱۸ و جنین احتمالاً سالم است.**",
        "**چون از جفت عبور نمی‌کند، جنینِ آلوده را درمان نمی‌کند.**",
        "⚠️ **در هفته‌ی ۲۸ باید خودِ جنین درمان شود، و این یعنی رژیم عبورکننده از جفت.**",
        "**پیریمتامین + سولفادیازین از جفت عبور می‌کنند و جنین را درمان می‌کنند.**",
        "**و پیریمتامین در هفته‌ی ۲۸ کاملاً مجاز است؛ ممنوعیت آن فقط پیش از هفته‌ی ۱۴ است.**",
    ],
    TREE_EN + [
        "WARNING, THE KEY TO THIS QUESTION IS ONE SENTENCE: the pre-pregnancy screen was NEGATIVE.",
        "So this is a PROVEN SEROCONVERSION, not a doubtful IgM.",
        "That means the infection definitely occurred during this pregnancy.",
        "And the patient is at 28 weeks, so in the third trimester.",
        "WARNING, IN THE THIRD TRIMESTER THE TRANSMISSION RATE IS 60% OR MORE.",
        "So fetal infection is highly likely, not hypothetical.",
        "And spiramycin is for pregnancies before week 18 with a probably uninfected fetus.",
        "Because it does not cross the placenta, it does not treat an infected fetus.",
        "WARNING, AT 28 WEEKS THE FETUS ITSELF MUST BE TREATED, which means a placenta-crossing regimen.",
        "Pyrimethamine plus sulfadiazine crosses the placenta and treats the fetus.",
        "And pyrimethamine is entirely permitted at 28 weeks; its ban applies only before week 14.",
    ],
    "این سخت‌ترین سؤال خوشه است و **کلید آن در یک جمله‌ی به‌ظاهر فرعی پنهان شده**.\n\n"
    "**بیمار: خانم باردار در هفته‌ی ۲۸ با لنفادنوپاتی گردنی و IgM مثبت. و — این جمله‌ی "
    "کلیدی است — «در اسکرینینگ قبل از حاملگی، تست توکسو منفی بوده است».**\n\n"
    "⚠️ **چرا آن جمله همه‌چیز را عوض می‌کند؟** چون معمولاً بزرگ‌ترین مشکل با IgM مثبت این "
    "است که **نمی‌دانیم عفونت کِی رخ داده** — IgM می‌تواند یک سال یا بیشتر باقی بماند. ولی "
    "اینجا **سند منفی بودن پیش از بارداری** داریم. **پس این یک سروکانورژن اثبات‌شده است و "
    "عفونت قطعاً در همین بارداری رخ داده.** هیچ ابهامی باقی نمی‌ماند.\n\n"
    "**حالا دو پرسش: خطر انتقال چقدر است، و چه دارویی؟**\n\n"
    "**خطر انتقال:** بیمار در **هفته‌ی ۲۸** است، یعنی **سه‌ماهه‌ی سوم**، و در این مرحله "
    "**میزان انتقال ۶۰ درصد یا بیشتر** است. پس آلودگی جنین **بسیار محتمل** است، نه فرضی.\n\n"
    "**چه دارویی؟ اینجا باید تفاوت دو دارو را دقیق بدانید:**\n\n"
    "**اسپیرامایسین:** در جفت تغلیظ می‌شود، **از جفت عبور نمی‌کند**، انتقال را کم می‌کند، "
    "ولی **جنینِ از قبل آلوده را درمان نمی‌کند**. جای آن: بارداری‌های زودرس (پیش از هفته‌ی ۱۸) "
    "که هنوز نمی‌دانیم جنین آلوده است یا نه.\n\n"
    "⚠️ **پیریمتامین + سولفادیازین:** **از جفت عبور می‌کنند** و **خودِ جنین را درمان می‌کنند**. "
    "جای آن: وقتی آلودگی جنین ثابت یا بسیار محتمل است، یا عفونت مادر پس از هفته‌ی ۱۸ رخ داده.\n\n"
    "**در این بیمار، هر دو شرط برقرار است.** پس **پیریمتامین + سولفادیازین** پاسخ است. "
    "(در عمل فولینیک اسید هم همراه آن‌ها داده می‌شود تا سرکوب مغز استخوان رخ ندهد.)\n\n"
    "**و نگرانی تراتوژنیسیته؟** پیریمتامین **فقط پیش از هفته‌ی ۱۴** ممنوع است. **در هفته‌ی "
    "۲۸ کاملاً مجاز است.**\n\n"
    "**چرا بقیه رد می‌شوند؟**\n\n"
    "**«اسپیرامایسین تا آخر حاملگی»:** در سه‌ماهه‌ی سوم با احتمال بالای آلودگی جنین، این یعنی "
    "**جنینِ آلوده را بدون درمان رها کنیم**.\n\n"
    "**«توصیه به سقط»:** توکسوپلاسموز **به‌خودی‌خود اندیکاسیون سقط نیست**، به‌ویژه در هفته‌ی "
    "۲۸ که جنین **قابل حیات** است. بیماری قابل درمان است.\n\n"
    "**«اقدام درمانی لازم نیست»:** عفونت حاد در بارداری **همیشه** درمان می‌شود.",
    "This is the hardest question in the cluster, and ITS KEY IS HIDDEN IN AN APPARENTLY MINOR SENTENCE.\n\n"
    "THE PATIENT: a woman at 28 weeks with cervical lymphadenopathy and a positive IgM. And — this is "
    "the key sentence — 'the pre-pregnancy screening toxo test was NEGATIVE'.\n\n"
    "WARNING, WHY DOES THAT SENTENCE CHANGE EVERYTHING? Because normally the biggest problem with a "
    "positive IgM is that WE DO NOT KNOW WHEN THE INFECTION OCCURRED — IgM can persist for a year or "
    "more. But here we have DOCUMENTED NEGATIVITY BEFORE THE PREGNANCY. SO THIS IS A PROVEN "
    "SEROCONVERSION AND THE INFECTION DEFINITELY OCCURRED DURING THIS PREGNANCY. No ambiguity remains.\n\n"
    "NOW TWO QUESTIONS: how great is the transmission risk, and which drug?\n\n"
    "TRANSMISSION RISK: the patient is at WEEK 28, the THIRD TRIMESTER, and at this stage the "
    "TRANSMISSION RATE IS 60% OR MORE. So fetal infection is HIGHLY LIKELY, not hypothetical.\n\n"
    "WHICH DRUG? Here the difference between the two must be known precisely:\n\n"
    "SPIRAMYCIN: concentrates in the placenta, DOES NOT CROSS IT, reduces transmission, but DOES NOT "
    "TREAT AN ALREADY INFECTED FETUS. Its place: early pregnancy (before week 18) when we do not yet "
    "know whether the fetus is infected.\n\n"
    "WARNING, PYRIMETHAMINE PLUS SULFADIAZINE: THEY CROSS THE PLACENTA and TREAT THE FETUS ITSELF. "
    "Their place: when fetal infection is proven or highly likely, or when maternal infection occurred "
    "after week 18.\n\n"
    "IN THIS PATIENT BOTH CONDITIONS HOLD. So PYRIMETHAMINE PLUS SULFADIAZINE is the answer. (In "
    "practice folinic acid is given alongside them to prevent marrow suppression.)\n\n"
    "AND THE TERATOGENICITY CONCERN? Pyrimethamine is banned ONLY BEFORE WEEK 14. AT 28 WEEKS IT IS "
    "ENTIRELY PERMITTED.\n\n"
    "WHY ARE THE OTHERS REJECTED?\n\n"
    "'SPIRAMYCIN UNTIL DELIVERY': in the third trimester with a high probability of fetal infection, "
    "this means LEAVING AN INFECTED FETUS UNTREATED.\n\n"
    "'RECOMMEND TERMINATION': toxoplasmosis IS NOT IN ITSELF AN INDICATION FOR TERMINATION, especially "
    "at 28 weeks when the fetus is VIABLE. The disease is treatable.\n\n"
    "'NO TREATMENT IS NEEDED': acute infection in pregnancy is ALWAYS treated.",
    ["اسپیرامایسین از جفت عبور نمی‌کند؛ در سه‌ماهه‌ی سوم جنینِ محتملاً آلوده را بدون درمان رها می‌کند.",
     "پاسخ صحیح — این دو از جفت عبور می‌کنند و جنین را درمان می‌کنند، و در هفته‌ی ۲۸ مجازند.",
     "توکسوپلاسموز به‌خودی‌خود اندیکاسیون سقط نیست، به‌ویژه در جنین قابل حیات هفته‌ی ۲۸.",
     "عفونت حاد اثبات‌شده در بارداری همیشه درمان می‌شود؛ رها کردن آن غیرقابل قبول است."],
    ["Spiramycin does not cross the placenta; in the third trimester it leaves a probably infected fetus untreated.",
     "Correct — these two cross the placenta and treat the fetus, and are permitted at 28 weeks.",
     "Toxoplasmosis is not in itself an indication for termination, least of all in a viable 28-week fetus.",
     "Proven acute infection in pregnancy is always treated; leaving it is unacceptable."],
    "**اسپیرامایسین از جفت رد نمی‌شود؛ پیریمتامین + سولفادیازین رد می‌شوند.**",
    "Spiramycin does not cross the placenta; pyrimethamine plus sulfadiazine do.",
    REFS)

add("book:759", "vignette", "hard",
    "**سونوگرافی مطرح‌کننده‌ی درگیری جنین در هفته‌ی ۱۴: اسپیرامایسین شروع، آمنیوسنتز در هفته‌ی ۱۸، و ادامه بر اساس نتیجه.**",
    "Ultrasound suggesting fetal involvement at 14 weeks: START spiramycin, amniocentesis at 18 weeks, and continue according to the result.",
    TREE_FA + [
        "**در این بیمار دو محدودیت هم‌زمان وجود دارد و هر دو را باید رعایت کرد.**",
        "**محدودیت اول: هفته‌ی ۱۴ است، یعنی درست در مرز مجاز شدن پیریمتامین.**",
        "⚠️ **محدودیت دوم: آمنیوسنتز پیش از هفته‌ی ۱۸ قابل اعتماد نیست.**",
        "**چرا؟ چون کلیه‌ی جنین باید ادرار بسازد تا انگل وارد مایع آمنیوتیک شود.**",
        "**پیش از هفته‌ی ۱۸، PCR منفی می‌تواند منفی کاذب باشد.**",
        "**پس نه می‌توان آلودگی جنین را همین حالا اثبات کرد، نه رد.**",
        "⚠️ **در این وضعیت، اسپیرامایسین پل زمانی است تا نتیجه‌ی قطعی برسد.**",
        "**و پس از PCR هفته‌ی ۱۸، تصمیم قطعی گرفته می‌شود.**",
        "**PCR مثبت: تبدیل به پیریمتامین + سولفادیازین + فولینیک اسید تا زایمان.**",
        "**PCR منفی با سونوگرافی طبیعی: ادامه‌ی اسپیرامایسین تا زایمان.**",
        "**و سونوگرافی سریال در هر دو حالت ادامه می‌یابد.**",
    ],
    TREE_EN + [
        "In this patient TWO constraints apply at once and both must be respected.",
        "CONSTRAINT ONE: it is week 14, exactly the threshold at which pyrimethamine becomes permissible.",
        "WARNING, CONSTRAINT TWO: AMNIOCENTESIS IS NOT RELIABLE BEFORE WEEK 18.",
        "Why? Because the fetal kidney must be producing urine for the parasite to enter the amniotic fluid.",
        "Before week 18 a negative PCR may be a false negative.",
        "So fetal infection can be neither proven nor excluded right now.",
        "WARNING, IN THIS SITUATION SPIRAMYCIN IS THE BRIDGE until the definitive result arrives.",
        "And after the week-18 PCR the definitive decision is made.",
        "PCR POSITIVE: switch to pyrimethamine plus sulfadiazine plus folinic acid until delivery.",
        "PCR NEGATIVE with a normal ultrasound: continue spiramycin until delivery.",
        "And serial ultrasound continues in either case.",
    ],
    "این سؤال دو محدودیت زمانی را هم‌زمان می‌سنجد و به همین دلیل ظریف‌ترین سؤال خوشه است.\n\n"
    "**بیمار: حاملگی ۱۴ هفته، IgM و IgG مثبت از آزمایشگاه رفرانس، و در سونوگرافی «شواهدی از "
    "درگیری جنین» وجود دارد.**\n\n"
    "**اول ببینیم چه می‌دانیم و چه نمی‌دانیم:**\n\n"
    "**می‌دانیم:** مادر احتمالاً عفونت حاد دارد (سرولوژی از آزمایشگاه رفرانس تأیید شده)، و "
    "سونوگرافی نگران‌کننده است.\n\n"
    "**نمی‌دانیم:** آیا جنین **واقعاً** آلوده است یا یافته‌ی سونوگرافی علت دیگری دارد. و این "
    "تفاوت، انتخاب دارو را تعیین می‌کند.\n\n"
    "⚠️ **چرا همین حالا آمنیوسنتز نمی‌کنیم؟ این نکته‌ی کلیدی سؤال است.** **PCR مایع آمنیوتیک "
    "پیش از هفته‌ی ۱۸ قابل اعتماد نیست.** دلیلش فیزیولوژیک است: انگل از راه **ادرار جنین** "
    "وارد مایع آمنیوتیک می‌شود، و پیش از هفته‌ی ۱۸ تولید ادرار جنین هنوز کافی نیست. پس یک "
    "**PCR منفی زودهنگام می‌تواند منفی کاذب** باشد و ما را گمراه کند. به‌علاوه، آمنیوسنتز "
    "زودهنگام خطر سقط بیشتری دارد.\n\n"
    "**پس در این فاصله چه کنیم؟ اسپیرامایسین شروع کنیم.** اسپیرامایسین در جفت تغلیظ می‌شود و "
    "**انتقال بیشتر را کاهش می‌دهد** — یعنی در همین فاصله‌ی چهارهفته‌ای بی‌کار نمی‌نشینیم.\n\n"
    "**و در هفته‌ی ۱۸ آمنیوسنتز و PCR انجام می‌دهیم و تصمیم قطعی می‌گیریم:**\n\n"
    "**PCR مثبت** → **پیریمتامین + سولفادیازین + فولینیک اسید تا زایمان.**\n\n"
    "**PCR منفی با سونوگرافی طبیعی** → **ادامه‌ی اسپیرامایسین تا زایمان.**\n\n"
    "**پس گزینه‌ی سوم — اسپیرامایسین + آمنیوسنتز و PCR در هفته‌ی ۱۸ + ادامه بر اساس نتایج — "
    "دقیقاً همین راهبرد است.**\n\n"
    "**چرا بقیه رد می‌شوند؟**\n\n"
    "**«تا هفته‌ی ۱۸ صبر می‌کنیم و بعد درمان شروع می‌کنیم»:** بخش آمنیوسنتز درست است ولی "
    "**چهار هفته بدون هیچ درمانی** می‌گذرد. در حالی که اسپیرامایسین بی‌خطر است و در همین "
    "فاصله انتقال را کم می‌کند. **صبر منفعل، فرصت را از دست می‌دهد.**\n\n"
    "⚠️ **«پیریمتامین + سولفادیازین + فولینیک اسید»:** آلودگی جنین **هنوز اثبات نشده** است — "
    "یافته‌ی سونوگرافی مطرح‌کننده است، نه قطعی. شروع رژیم سمّی بدون اثبات، و آن هم در هفته‌ی "
    "۱۴ که تازه مرز مجاز بودن پیریمتامین است، عجولانه است. **راه درست، اثبات کردن است، نه "
    "فرض کردن.**\n\n"
    "**«اسپیرامایسین تا آخر حاملگی»:** اسپیرامایسین درست شروع شده ولی **آمنیوسنتز حذف شده**. "
    "اگر جنین آلوده باشد، اسپیرامایسین **درمانش نمی‌کند** (از جفت عبور نمی‌کند). این یعنی "
    "**رها کردن جنینِ احتمالاً آلوده**.",
    "This question tests two timing constraints at once, and is therefore the subtlest in the cluster.\n\n"
    "THE PATIENT: 14 weeks pregnant, IgM and IgG positive from a reference laboratory, and the "
    "ultrasound shows 'evidence of fetal involvement'.\n\n"
    "FIRST, WHAT WE KNOW AND WHAT WE DO NOT:\n\n"
    "WE KNOW: the mother probably has acute infection (serology confirmed by a reference laboratory), "
    "and the ultrasound is worrying.\n\n"
    "WE DO NOT KNOW: whether the fetus is REALLY infected or the ultrasound finding has another cause. "
    "And that difference decides the drug.\n\n"
    "WARNING, WHY NOT PERFORM AMNIOCENTESIS RIGHT NOW? THIS IS THE KEY POINT. AMNIOTIC FLUID PCR IS "
    "NOT RELIABLE BEFORE WEEK 18. The reason is physiological: the parasite enters the amniotic fluid "
    "through FETAL URINE, and before week 18 fetal urine production is not yet sufficient. So AN EARLY "
    "NEGATIVE PCR MAY BE A FALSE NEGATIVE and mislead us. Moreover early amniocentesis carries a "
    "higher miscarriage risk.\n\n"
    "SO WHAT DO WE DO IN THE MEANTIME? START SPIRAMYCIN. It concentrates in the placenta and REDUCES "
    "FURTHER TRANSMISSION — so we do not sit idle through those four weeks.\n\n"
    "AND AT WEEK 18 WE PERFORM AMNIOCENTESIS AND PCR AND MAKE THE DEFINITIVE DECISION:\n\n"
    "PCR POSITIVE -> PYRIMETHAMINE PLUS SULFADIAZINE PLUS FOLINIC ACID UNTIL DELIVERY.\n\n"
    "PCR NEGATIVE with a normal ultrasound -> CONTINUE SPIRAMYCIN UNTIL DELIVERY.\n\n"
    "SO THE THIRD OPTION — spiramycin, amniocentesis and PCR at week 18, continuing according to the "
    "result — IS EXACTLY THIS STRATEGY.\n\n"
    "WHY ARE THE OTHERS REJECTED?\n\n"
    "'WAIT UNTIL WEEK 18 AND THEN START TREATMENT': the amniocentesis part is right but FOUR WEEKS "
    "PASS WITH NO TREATMENT AT ALL, when spiramycin is safe and would reduce transmission in exactly "
    "that interval. PASSIVE WAITING WASTES THE OPPORTUNITY.\n\n"
    "WARNING, 'PYRIMETHAMINE PLUS SULFADIAZINE PLUS FOLINIC ACID': fetal infection is NOT YET PROVEN — "
    "the ultrasound finding is suggestive, not definitive. Starting a toxic regimen without proof, and "
    "at week 14 which is only just the threshold for pyrimethamine, is premature. THE RIGHT COURSE IS "
    "TO PROVE, NOT TO ASSUME.\n\n"
    "'SPIRAMYCIN UNTIL DELIVERY': the spiramycin is correctly started but THE AMNIOCENTESIS IS "
    "OMITTED. If the fetus is infected, spiramycin WILL NOT TREAT IT (it does not cross the placenta). "
    "That means ABANDONING A POSSIBLY INFECTED FETUS.",
    ["بخش آمنیوسنتز درست است ولی چهار هفته بدون درمان می‌گذرد، در حالی که اسپیرامایسین بی‌خطر است.",
     "آلودگی جنین هنوز اثبات نشده؛ شروع رژیم سمّی بدون اثبات و در هفته‌ی ۱۴ عجولانه است.",
     "پاسخ صحیح — اسپیرامایسین به‌عنوان پل، آمنیوسنتز در هفته‌ی ۱۸، و تصمیم قطعی بر اساس PCR.",
     "اسپیرامایسین از جفت عبور نمی‌کند؛ بدون آمنیوسنتز، جنینِ احتمالاً آلوده رها می‌شود."],
    ["The amniocentesis part is right but four weeks pass untreated, when spiramycin is safe.",
     "Fetal infection is not yet proven; starting a toxic regimen unproven and at week 14 is premature.",
     "Correct — spiramycin as a bridge, amniocentesis at week 18, and the definitive decision on the PCR.",
     "Spiramycin does not cross the placenta; without amniocentesis a possibly infected fetus is abandoned."],
    "**PCR مایع آمنیوتیک پیش از هفته‌ی ۱۸ منفی کاذب می‌دهد — چون ادرار جنین هنوز کافی نیست.**",
    "Amniotic fluid PCR gives false negatives before week 18 — because fetal urine output is not yet sufficient.",
    REFS)

# ============================================ SECONDARY PROPHYLAXIS IN HIV
add("book:756", "recall", "hard",
    "**قطع پروفیلاکسی ثانویه‌ی توکسو: CD4 بالای ۲۰۰ به مدت بیش از سه ماه، همراه با تکمیل درمان و بی‌علامتی.**",
    "Stopping secondary toxoplasma prophylaxis: CD4 above 200 for MORE THAN THREE MONTHS, with completed therapy and no symptoms.",
    [
        "⚠️ **در ایدز، دو نوع پروفیلاکسی داریم و نباید قاطی شوند.**",
        "**پروفیلاکسی اولیه: بیمار هرگز توکسو نگرفته و می‌خواهیم نگیرد.**",
        "**پروفیلاکسی ثانویه: بیمار توکسو گرفته، درمان شده، و می‌خواهیم عود نکند.**",
        "**پروفیلاکسی ثانویه را «درمان نگهدارنده‌ی مزمن» هم می‌نامند.**",
        "⚠️ **در دوران پیش از درمان ضدرتروویروسی، این پروفیلاکسی مادام‌العمر بود.**",
        "**چون ایمنی هرگز برنمی‌گشت و قطع دارو یعنی عود قطعی.**",
        "**ولی امروز با ART مؤثر، ایمنی بازسازی می‌شود و می‌توان آن را قطع کرد.**",
        "**شرط‌ها را بشمارید، چون سؤال دقیقاً همین‌ها را می‌خواهد.**",
        "**یک: بیمار درمان اولیه‌ی توکسوپلاسموز را کامل کرده باشد.**",
        "**دو: هیچ علامت یا نشانه‌ای از توکسوپلاسموز نداشته باشد.**",
        "⚠️ **سه: CD4 در پاسخ به ART به بالای ۲۰۰ رسیده و پایدار مانده باشد.**",
        "**و «پایدار» یعنی بیش از سه ماه — همان عددی که سؤال می‌خواهد.**",
        "**و اگر CD4 دوباره زیر ۲۰۰ بیفتد، پروفیلاکسی از سر گرفته می‌شود.**",
        "**منطق کلی روشن است: دارو تا زمانی که ایمنی خودش کار را انجام دهد.**",
    ],
    [
        "WARNING: IN AIDS THERE ARE TWO KINDS OF PROPHYLAXIS AND THEY MUST NOT BE CONFUSED.",
        "PRIMARY prophylaxis: the patient has never had toxoplasmosis and we want to keep it that way.",
        "SECONDARY prophylaxis: the patient has had it, has been treated, and we want to prevent relapse.",
        "Secondary prophylaxis is also called CHRONIC MAINTENANCE THERAPY.",
        "WARNING, IN THE PRE-ANTIRETROVIRAL ERA THIS PROPHYLAXIS WAS LIFELONG.",
        "Because immunity never recovered, and stopping the drug meant certain relapse.",
        "But today, with effective ART, immunity is reconstituted and it can be stopped.",
        "COUNT THE CONDITIONS, because the question asks for exactly these.",
        "ONE: the patient has completed initial therapy for toxoplasmosis.",
        "TWO: he has no symptoms or signs of toxoplasmosis.",
        "WARNING, THREE: the CD4 has risen above 200 in response to ART and has stayed there.",
        "And 'stayed there' means MORE THAN THREE MONTHS — the number the question wants.",
        "And if the CD4 falls below 200 again, prophylaxis is restarted.",
        "The overall logic is clear: the drug lasts until immunity itself can do the job.",
    ],
    "این سؤال یک آستانه‌ی عددی را می‌سنجد، ولی **منطق پشت آن مهم‌تر از خود عدد است**.\n\n"
    "**موقعیت: بیمار HIV مثبت، توکسوپلاسموز گرفته و درمان شده، و حالا برای جلوگیری از عود، "
    "سولفادیازین + پیریمتامین همراه با درمان ضدرتروویرال می‌گیرد.** یعنی این **پروفیلاکسی "
    "ثانویه** (درمان نگهدارنده‌ی مزمن) است.\n\n"
    "**سؤال: تا کی؟**\n\n"
    "⚠️ **منطق کلی را اول بفهمید:** پروفیلاکسی برای پوشاندن **شکاف ایمنی** است. تا وقتی "
    "سیستم ایمنی بیمار نتواند خودش انگل را مهار کند، دارو جای آن را می‌گیرد. **به‌محض اینکه "
    "ایمنی بازسازی شود، دارو دیگر لازم نیست.**\n\n"
    "**در دوران پیش از ART، این پروفیلاکسی مادام‌العمر بود** — چون ایمنی هرگز برنمی‌گشت. "
    "**امروز با ART مؤثر، CD4 بالا می‌رود و می‌توان دارو را قطع کرد.**\n\n"
    "**شرط‌های قطع را بشمارید:**\n\n"
    "**یک:** بیمار **درمان اولیه** را کامل کرده باشد.\n\n"
    "**دو:** **بدون علامت** باشد.\n\n"
    "**سه:** **CD4 بالای ۲۰۰** رسیده و **پایدار** مانده باشد.\n\n"
    "**و «پایدار» یعنی بیش از سه ماه** — پس گزینه‌ی اول («بیش از ۳ ماه پس از CD4 بالای ۲۰۰») "
    "درست است.\n\n"
    "**و اگر CD4 دوباره زیر ۲۰۰ بیفتد، پروفیلاکسی از سر گرفته می‌شود.**\n\n"
    "**چرا بقیه رد می‌شوند؟**\n\n"
    "**«بیش از ۲ ماه پس از CD4 بالای ۱۰۰»:** هر دو عدد اشتباه‌اند. آستانه‌ی CD4 برای "
    "توکسوپلاسما **۲۰۰** است (نه ۱۰۰ — آن آستانه‌ی MAC است) و مدت **بیش از سه ماه** است.\n\n"
    "**«تا ۱۲ ماه پس از CD4 بالای ۲۰۰»:** ۱۲ ماه بسیار طولانی است و بیمار را ماه‌ها بی‌دلیل "
    "در معرض سمّیت دارو نگه می‌دارد.\n\n"
    "⚠️ **«برای تمام عمر بدون در نظر گرفتن CD4»:** این **الگوریتم منسوخِ دوران پیش از ART** "
    "است. امروز با بازسازی ایمنی، ادامه‌ی مادام‌العمر یعنی سمّیت مزمن، بار قرص، و تداخل دارویی "
    "بدون هیچ سود.\n\n"
    "**نکته‌ی مقایسه‌ای که ارزش دانستن دارد:** برخی منابع برای پروفیلاکسی **ثانویه** بازه‌ی "
    "محتاطانه‌تر شش ماه را ذکر می‌کنند، در حالی که برای پروفیلاکسی **اولیه** اتفاق نظر روی "
    "سه ماه است. در چهار گزینه‌ی این سؤال، تنها گزینه‌ای که هم آستانه‌ی درست (۲۰۰) و هم "
    "منطق درست (قطع پس از پایداری، نه مادام‌العمر) را دارد، همان گزینه‌ی سه ماه است.",
    "This question tests a numerical threshold, but THE LOGIC BEHIND IT MATTERS MORE THAN THE NUMBER.\n\n"
    "THE SITUATION: an HIV-positive patient who developed toxoplasmosis, was treated, and is now on "
    "sulfadiazine plus pyrimethamine alongside antiretroviral therapy to prevent relapse. So this is "
    "SECONDARY PROPHYLAXIS (chronic maintenance therapy).\n\n"
    "THE QUESTION: for how long?\n\n"
    "WARNING, UNDERSTAND THE GENERAL LOGIC FIRST: prophylaxis exists to cover an IMMUNE GAP. As long "
    "as the patient's immune system cannot contain the parasite itself, the drug stands in for it. AS "
    "SOON AS IMMUNITY IS RECONSTITUTED, THE DRUG IS NO LONGER NEEDED.\n\n"
    "IN THE PRE-ART ERA THIS PROPHYLAXIS WAS LIFELONG — because immunity never returned. TODAY, WITH "
    "EFFECTIVE ART, THE CD4 RISES AND THE DRUG CAN BE STOPPED.\n\n"
    "COUNT THE CONDITIONS FOR STOPPING:\n\n"
    "ONE: the patient has completed INITIAL THERAPY.\n\n"
    "TWO: he is ASYMPTOMATIC.\n\n"
    "THREE: the CD4 has risen ABOVE 200 and has REMAINED there.\n\n"
    "AND 'REMAINED' MEANS MORE THAN THREE MONTHS — so the first option ('more than 3 months after CD4 "
    "above 200') is correct.\n\n"
    "AND IF THE CD4 FALLS BELOW 200 AGAIN, PROPHYLAXIS IS RESTARTED.\n\n"
    "WHY ARE THE OTHERS REJECTED?\n\n"
    "'MORE THAN 2 MONTHS AFTER CD4 ABOVE 100': both numbers are wrong. The CD4 threshold for "
    "toxoplasma is 200 (not 100 — that is the MAC threshold) and the duration is more than three months.\n\n"
    "'UP TO 12 MONTHS AFTER CD4 ABOVE 200': twelve months is far too long and keeps the patient "
    "exposed to drug toxicity for months without reason.\n\n"
    "WARNING, 'FOR LIFE REGARDLESS OF THE CD4': this is THE OBSOLETE PRE-ART ALGORITHM. Today, with "
    "immune reconstitution, continuing for life means chronic toxicity, pill burden and drug "
    "interactions with no benefit at all.\n\n"
    "A COMPARATIVE POINT WORTH KNOWING: some sources quote a more cautious six-month interval for "
    "SECONDARY prophylaxis, while for PRIMARY prophylaxis three months is agreed. Among the four "
    "options here, the only one with both the right threshold (200) and the right logic (stop after "
    "sustained recovery, rather than continue for life) is the three-month option.",
    ["پاسخ صحیح — CD4 بالای ۲۰۰ به مدت بیش از سه ماه، همراه با تکمیل درمان و بی‌علامتی.",
     "هر دو عدد اشتباه است: آستانه‌ی توکسو ۲۰۰ است نه ۱۰۰، و مدت بیش از سه ماه است.",
     "دوازده ماه بسیار طولانی است و بیمار را بی‌دلیل در معرض سمّیت دارو نگه می‌دارد.",
     "الگوریتم منسوخ دوران پیش از ART؛ با بازسازی ایمنی، ادامه‌ی مادام‌العمر سود ندارد."],
    ["Correct — CD4 above 200 for more than three months, with completed therapy and no symptoms.",
     "Both numbers are wrong: the toxoplasma threshold is 200 not 100, and the duration is over three months.",
     "Twelve months is far too long and needlessly exposes the patient to drug toxicity.",
     "The obsolete pre-ART algorithm; with immune reconstitution, lifelong therapy has no benefit."],
    "**پروفیلاکسی تا زمانی که ایمنی خودش کار را انجام دهد — نه یک روز بیشتر.**",
    "Prophylaxis lasts until immunity can do the job itself — not one day longer.",
    [H, ("NIH/CDC/IDSA — Guidelines for the Prevention and Treatment of Opportunistic Infections in "
         "Adults and Adolescents with HIV (clinicalinfo.hiv.gov), Toxoplasma gondii encephalitis "
         "section")])

json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book42.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 42 lessons:', len(L))
