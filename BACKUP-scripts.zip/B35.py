# -*- coding: utf-8 -*-
"""Micro-lessons, batch 35 — HIV part two: transmission, staging, and the
first half of the diagnostic algorithm.

Batch 31 taught the TESTING CHAIN and the CD4 LADDER. This batch takes the two
remaining pillars of the HIV block, both of which are pure list knowledge that
students routinely half-learn:

  * TRANSMISSION — nine questions, all answerable from one idea: HIV needs a
    fluid that CONTAINS the virus in quantity AND a route that delivers it to
    the bloodstream or a mucosa. Every distractor in the whole cluster fails
    one of those two conditions.

  * STAGING — seven questions, all answerable from a published LIST. Clinical
    categories A, B and C are not clinical judgement; they are the CDC 1993
    classification, reprinted verbatim in 2008. The exam keeps asking "which
    one is NOT category C", and there is exactly one right way to answer that:
    know the list.

A CORRECTED KEY IN THIS BATCH
-----------------------------
q9662 keyed cerebral toxoplasmosis as the option that is NOT category C.
Cerebral toxoplasmosis has been category C since the 1987 definition. The
option that is not category C is persistent generalised lymphadenopathy, which
is one of the three defining entries of category A. See
fix_key_hiv_category.py for the full argument and sources; the lesson for that
question says openly that the key was corrected and explains where the error
probably comes from.

A GUIDELINE THAT MOVED, HANDLED THE USUAL HONEST WAY
-----------------------------------------------------
q9672 keys the ELISA for a patient four weeks after exposure with an acute
retroviral picture, while three other questions in the same chapter (q9686,
q9688, q9689) key the p24 antigen for what is clinically the same patient. The
apparent contradiction dissolves once you know WHICH generation of assay is
meant: a modern fourth-generation combined antigen/antibody immunoassay
detects p24 itself and is positive from about two weeks, so at four weeks it is
the right first test; an older antibody-only EIA is not. The keys are NOT
changed — both are defensible on their own terms — and the lessons teach the
distinction explicitly, because that distinction is the actual medicine.

Reference: CDC — 1993 Revised Classification System for HIV Infection (MMWR
1992;41(RR-17)); CDC — Revised Surveillance Case Definitions for HIV Infection
(MMWR 2008;57(RR-10)); CDC — Laboratory Testing for the Diagnosis of HIV
Infection: Updated Recommendations (2014, revised 2018); CDC — Updated
Guidelines for Antiretroviral Postexposure Prophylaxis (2016); Harrison's
Principles of Internal Medicine, 21st ed (2022), Ch. 202.
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H202 = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 202: Human "
        "Immunodeficiency Virus Disease: AIDS and Related Disorders")
CDC93 = ("CDC — 1993 Revised Classification System for HIV Infection and Expanded "
         "Surveillance Case Definition for AIDS Among Adolescents and Adults. "
         "MMWR 1992;41(RR-17)")
CDC08 = ("CDC — Revised Surveillance Case Definitions for HIV Infection Among Adults, "
         "Adolescents, and Children. MMWR 2008;57(RR-10)")
CDCLAB = ("CDC — Laboratory Testing for the Diagnosis of HIV Infection: Updated "
          "Recommendations (2014, revised 2018)")
CDCPEP = ("CDC — Updated Guidelines for Antiretroviral Postexposure Prophylaxis After "
          "Sexual, Injection Drug Use, or Other Nonoccupational Exposure to HIV (2016); "
          "and Updated US Public Health Service Guidelines for the Management of "
          "Occupational Exposures to HIV")
WHOMTCT = ("World Health Organization — Consolidated guidelines on HIV prevention, "
           "testing, treatment, service delivery and monitoring (mother-to-child "
           "transmission and infant feeding)")

# ============================================================ TRANSMISSION
TRANS_FA = [
    "⚠️ **همه‌ی سؤال‌های انتقال HIV با یک قاعده‌ی دوشرطی حل می‌شوند. آن را حفظ کنید.**",
    "**شرط یک: مایع باید ویروس را به مقدار کافی داشته باشد.**",
    "**شرط دو: راهی وجود داشته باشد که آن مایع را به خون یا مخاط برساند.**",
    "**اگر حتی یکی از دو شرط برقرار نباشد، انتقال رخ نمی‌دهد — و هر گزینه‌ی نادرست همین‌جا می‌شکند.**",
    "⚠️ **مایعات پرخطر (شرط یک را دارند): خون، مایع منی، ترشحات واژن، شیر مادر.**",
    "**و مایعاتی که فقط در محیط بالینی مطرح‌اند: مایع مغزی‌نخاعی، سینوویال، پلور، پریتوئن، آمنیوتیک.**",
    "⚠️ **مایعات بی‌خطر — این فهرست را حفظ کنید چون گزینه‌های نادرست از همین‌جا می‌آیند:**",
    "**بزاق، اشک، عرق، ادرار، مدفوع، خلط و استفراغ — به‌شرطی که خون قابل‌رؤیت نداشته باشند.**",
    "**بزاق حتی مهارکننده‌ی طبیعی ویروس دارد و غلظت ویروس در آن ناچیز است.**",
    "**پس بوسه، هم‌غذا شدن، دست دادن، استخر و توالت مشترک ناقل نیستند.**",
    "⚠️ **و پشه HIV را منتقل نمی‌کند — نه به این دلیل که «خون کم است»، بلکه چون ویروس در پشه تکثیر نمی‌شود.**",
    "**در مالاریا انگل در پشه چرخه دارد؛ HIV در بدن پشه هضم می‌شود و به بزاق پشه نمی‌رسد.**",
    "**شایع‌ترین راه انتقال در جهان: تماس جنسی، و در آن هتروسکسوال بیش از هر شکل دیگر.**",
    "**بیشترین خطر در هر بار تماس اما مربوط به انتقال خون آلوده است: نزدیک ۹۰ درصد.**",
    "⚠️ **این دو را با هم اشتباه نگیرید: «شایع‌ترین» با «پرخطرترین» یکی نیست.**",
    "**شایع‌ترین یعنی بیشترین تعداد موارد؛ پرخطرترین یعنی بیشترین احتمال در یک بار مواجهه.**",
    "**ترتیب خطر در هر مواجهه: انتقال خون ≫ سوزن مشترک ≫ تماس جنسی مقعدی گیرنده ≫ واژینال ≫ نیدل‌استیک.**",
    "**نیدل‌استیک با سوزن توخالی و خون تازه حدود ۰٫۳ درصد؛ پاشیدن به مخاط حدود ۰٫۰۹ درصد.**",
]
TRANS_EN = [
    "WARNING: EVERY HIV TRANSMISSION QUESTION IS SOLVED BY ONE TWO-PART RULE. Memorise it.",
    "CONDITION ONE: the fluid must contain the virus in sufficient quantity.",
    "CONDITION TWO: there must be a route delivering that fluid to blood or mucosa.",
    "If either condition fails, transmission does not occur — and every wrong option in this cluster breaks exactly there.",
    "WARNING, HIGH-RISK FLUIDS (which satisfy condition one): blood, semen, vaginal secretions, breast milk.",
    "And fluids that matter only in a clinical setting: cerebrospinal, synovial, pleural, peritoneal, amniotic.",
    "WARNING, THE SAFE FLUIDS — memorise this list, because the wrong options are drawn from it:",
    "Saliva, tears, sweat, urine, faeces, sputum and vomit — provided they contain no visible blood.",
    "Saliva even contains natural inhibitors of the virus, and the viral concentration in it is negligible.",
    "So kissing, sharing food, shaking hands, swimming pools and shared toilets do not transmit.",
    "WARNING, AND MOSQUITOES DO NOT TRANSMIT HIV — not because the blood volume is small, but because the virus does not replicate in the mosquito.",
    "In malaria the parasite has a life cycle inside the mosquito; HIV is digested and never reaches the mosquito's saliva.",
    "The commonest route worldwide is SEXUAL, and within that, heterosexual contact more than any other form.",
    "But the highest risk PER EXPOSURE belongs to transfusion of infected blood: close to 90 per cent.",
    "WARNING, DO NOT CONFUSE THE TWO: 'commonest' is not the same as 'most efficient'.",
    "Commonest means the largest number of cases; most efficient means the highest probability in a single exposure.",
    "Risk order per exposure: transfusion, then shared needles, then receptive anal intercourse, then vaginal, then needlestick.",
    "A hollow-needle stick with fresh blood carries about 0.3 per cent; a mucosal splash about 0.09 per cent.",
]

# ==================================================== MOTHER TO CHILD + PEP
MTCT_FA = [
    "⚠️ **انتقال مادر به کودک سه پنجره دارد و هر سه در سؤال‌ها آمده‌اند: داخل رحم، حین زایمان، و شیردهی.**",
    "**بدون هیچ مداخله‌ای، خطر کلی حدود ۱۵ تا ۴۵ درصد است.**",
    "⚠️ **و بیشترین سهم مربوط به هنگام زایمان است، نه دوران بارداری.**",
    "**چون در زایمان نوزاد در معرض حجم زیادی از خون و ترشحات مادر قرار می‌گیرد.**",
    "**عامل خطر شماره‌یک در هر سه پنجره: بار ویروسی بالای مادر.**",
    "⚠️ **و در حین زایمان، عامل خطر ثابت‌شده‌ی دوم: پارگی طولانی‌مدت کیسه‌ی آب.**",
    "**هرچه فاصله‌ی پارگی پرده تا تولد بیشتر شود، تماس نوزاد با ترشحات طولانی‌تر می‌شود.**",
    "**شیردهی به‌تنهایی حدود ۵ تا ۲۰ درصد خطر اضافه می‌کند و در کل بارداری سهم قابل توجهی دارد.**",
    "**با درمان ضدرتروویروسی مادر و سرکوب کامل بار ویروسی، خطر به زیر ۱ تا ۲ درصد می‌رسد.**",
    "⚠️ **و در پروفیلاکسی پس از مواجهه (PEP)، همان قاعده‌ی دوشرطی حاکم است.**",
    "**اگر مایع بی‌خطر باشد یا پوست سالم باشد، مواجهه‌ای رخ نداده و PEP اندیکاسیون ندارد.**",
    "**پاشیدن بزاق روی پوست سالم = صفر خطر ثبت‌شده در تمام ادبیات پزشکی.**",
    "**پس نه آزمایش لازم است، نه دارو، نه پیگیری — و اطمینان‌بخشی به فرد، خودش یک مداخله‌ی درمانی است.**",
    "⚠️ **در مقابل، مواجهه‌ی واقعی (سوزن آلوده، مخاط، پوست آسیب‌دیده) نیازمند شروع سریع PEP است.**",
    "**ترجیحاً ظرف ۲ ساعت، حداکثر تا ۷۲ ساعت؛ بعد از آن اثربخشی اثبات‌شده‌ای ندارد.**",
    "**رژیم امروزی سه‌دارویی است و ۲۸ روز ادامه می‌یابد، با پیگیری سرولوژیک.**",
]
MTCT_EN = [
    "WARNING: MOTHER-TO-CHILD TRANSMISSION HAS THREE WINDOWS, all of them examined: in utero, intrapartum, and breastfeeding.",
    "With no intervention at all the overall risk is about 15 to 45 per cent.",
    "WARNING, AND THE LARGEST SHARE BELONGS TO DELIVERY ITSELF, not to pregnancy.",
    "Because at delivery the infant meets a large volume of maternal blood and secretions.",
    "The number-one risk factor in all three windows is a HIGH MATERNAL VIRAL LOAD.",
    "WARNING, AND INTRAPARTUM THE SECOND ESTABLISHED RISK FACTOR IS PROLONGED RUPTURE OF MEMBRANES.",
    "The longer the interval from rupture to birth, the longer the infant's exposure to secretions.",
    "Breastfeeding alone adds roughly 5 to 20 per cent and contributes substantially overall.",
    "With maternal antiretroviral therapy and full viral suppression the risk falls below 1 to 2 per cent.",
    "WARNING, AND POST-EXPOSURE PROPHYLAXIS OBEYS THE SAME TWO-PART RULE.",
    "If the fluid is a safe one, or the skin is intact, no exposure has occurred and PEP is not indicated.",
    "Saliva splashed on intact skin: ZERO recorded risk in the entire medical literature.",
    "So no test, no drug and no follow-up are needed — and reassuring the person is itself a therapeutic act.",
    "WARNING, BY CONTRAST A REAL EXPOSURE (contaminated needle, mucosa, broken skin) needs PEP started fast.",
    "Preferably within 2 hours and at the latest within 72 hours; beyond that there is no proven benefit.",
    "The modern regimen is three drugs for 28 days, with serological follow-up.",
]

# ================================================================= STAGING
STAGE_FA = [
    "⚠️ **مرحله‌بندی HIV را حدس نزنید — یک فهرست منتشرشده است و سؤال‌ها دقیقاً از روی آن ساخته می‌شوند.**",
    "**مرجع: طبقه‌بندی بازنگری‌شده‌ی CDC در سال ۱۹۹۳، که در بازنگری ۲۰۰۸ عیناً تکرار شد.**",
    "⚠️ **گروه A دقیقاً سه چیز است و بیشتر نه: بدون علامت، لنفادنوپاتی ژنرالیزه‌ی پایدار، عفونت حاد HIV.**",
    "**پس هر جا «لنفادنوپاتی ژنرالیزه‌ی دائمی» را دیدید، بدانید گروه A است، نه C.**",
    "**گروه B مواردی است که نه بی‌علامت است و نه تعریف‌کننده‌ی ایدز.**",
    "**نمونه‌های گروه B: برفک دهانی، لکوپلاکی مویی دهانی، زونا در دو درماتوم، کاندیدیای واژینال مقاوم، ITP.**",
    "⚠️ **و گروه C همان فهرست تعریف‌کننده‌ی ایدز است. مهم‌ترین اعضایش را بشناسید:**",
    "**کاندیدیازیس مری، نای یا برونش (ولی نه دهان — دهان گروه B است).**",
    "**پنومونی پنوموسیستیس · توکسوپلاسموز مغز · مننژیت کریپتوکوکی · کریپتوسپوریدیوز مزمن.**",
    "**رتینیت یا بیماری ارگانی سیتومگالوویروس · لکوانسفالوپاتی مولتی‌فوکال پیشرونده.**",
    "**سارکوم کاپوزی · لنفوم مغزی اولیه · لنفوم بورکیت · لنفوم ایمونوبلاستیک.**",
    "⚠️ **مایکوباکتریوم توبرکلوزیس در هر محل — ریوی یا خارج‌ریوی، هر دو گروه C.**",
    "**سل ریوی در سال ۱۹۹۳ به فهرست اضافه شد؛ در تعریف ۱۹۸۷ نبود و منشأ بسیاری از خطاهاست.**",
    "**MAC یا M. kansasii منتشر یا خارج‌ریوی · سپتی‌سمی راجعه‌ی سالمونلا.**",
    "⚠️ **پنومونی باکتریال راجعه: دو بار یا بیشتر در ۱۲ ماه — این هم در ۱۹۹۳ اضافه شد.**",
    "**پس یک اپیزود پنومونی پنوموکوکی تعریف‌کننده‌ی ایدز نیست؛ دو اپیزود در یک سال هست.**",
    "**کانسر مهاجم سرویکس (نه دیسپلازی) · سندرم تحلیل‌رونده‌ی HIV · انسفالوپاتی HIV.**",
    "**و شرط عددی مستقل: CD4 زیر ۲۰۰ یا زیر ۱۴ درصد، حتی بدون هیچ بیماری تعریف‌کننده.**",
]
STAGE_EN = [
    "WARNING: DO NOT GUESS HIV STAGING — it is a published list and the questions are built straight from it.",
    "The source: the CDC 1993 revised classification, reprinted verbatim in the 2008 revision.",
    "WARNING, CATEGORY A IS EXACTLY THREE THINGS AND NO MORE: asymptomatic, persistent generalised lymphadenopathy, acute HIV infection.",
    "So wherever you see 'persistent generalised lymphadenopathy', it is category A, not C.",
    "Category B is what is neither asymptomatic nor AIDS-defining.",
    "Examples of category B: oral thrush, oral hairy leucoplakia, zoster in two dermatomes, refractory vaginal candidiasis, ITP.",
    "WARNING, AND CATEGORY C IS THE AIDS-DEFINING LIST. Know its principal members:",
    "Candidiasis of oesophagus, trachea or bronchi (but NOT of the mouth — oral thrush is category B).",
    "Pneumocystis pneumonia; toxoplasmosis of brain; cryptococcal meningitis; chronic cryptosporidiosis.",
    "CMV retinitis or organ disease; progressive multifocal leucoencephalopathy.",
    "Kaposi sarcoma; primary cerebral lymphoma; Burkitt lymphoma; immunoblastic lymphoma.",
    "WARNING: MYCOBACTERIUM TUBERCULOSIS AT ANY SITE — pulmonary or extrapulmonary, both category C.",
    "Pulmonary TB was ADDED in 1993; it was absent from the 1987 definition, and that is the source of many errors.",
    "Disseminated or extrapulmonary MAC or M. kansasii; recurrent Salmonella septicaemia.",
    "WARNING, RECURRENT BACTERIAL PNEUMONIA: two or more episodes in 12 months — also added in 1993.",
    "So a single episode of pneumococcal pneumonia is NOT AIDS-defining; two in one year is.",
    "Invasive cervical cancer (not dysplasia); HIV wasting syndrome; HIV encephalopathy.",
    "And an independent numerical criterion: CD4 below 200, or below 14 per cent, even with no defining illness.",
]

# =========================================================== ACUTE HIV / DX
ACUTE_FA = [
    "⚠️ **عفونت حاد HIV یک تابلوی شبه‌مونونوکلئوز است که ۲ تا ۶ هفته پس از تماس ظاهر می‌شود.**",
    "**تب، گلودرد، لنفادنوپاتی منتشر، میالژی، آرترالژی، سردرد و راش ماکولوپاپولر.**",
    "**زخم‌های دهانی و لکوپنی نسبی هم شایع‌اند و به تشخیص کمک می‌کنند.**",
    "⚠️ **در همین دوره CD4 موقتاً و گاهی به‌شدت افت می‌کند و بار ویروسی بسیار بالاست.**",
    "**به همین دلیل بیمار در این مرحله بسیار مسری است و گاهی عفونت فرصت‌طلب گذرا هم دیده می‌شود.**",
    "⚠️ **و نکته‌ی کلیدی تشخیصی: در روزهای نخست، آنتی‌بادی هنوز ساخته نشده است.**",
    "**پس یک تست آنتی‌بادیِ صرف در این پنجره می‌تواند کاذباً منفی باشد.**",
    "**ترتیب مثبت شدن نشانگرها: RNA از حدود روز ۱۰، آنتی‌ژن p24 از حدود هفته‌ی ۲، آنتی‌بادی از هفته‌ی ۳ تا ۱۲.**",
    "⚠️ **و اینجا باید نسل تست را بشناسید، وگرنه پاسخ‌های ظاهراً متناقض این فصل گیج‌کننده می‌شوند:**",
    "**تست نسل سوم فقط آنتی‌بادی را می‌بیند؛ در هفته‌ی چهارم ممکن است هنوز منفی باشد.**",
    "**تست نسل چهارم (ترکیبی آنتی‌ژن/آنتی‌بادی) خودِ p24 را هم می‌بیند و از حدود هفته‌ی دوم مثبت می‌شود.**",
    "**الگوریتم امروز CDC با همین تست ترکیبی شروع می‌شود، و همین ناسازگاری ظاهری کلیدها را حل می‌کند.**",
    "**قاعده‌ی عملی: اگر تست ترکیبی در دسترس است، همان اقدام اول است.**",
    "⚠️ **و اگر فقط تست آنتی‌بادی دارید و شک به عفونت حاد قوی است، سراغ p24 یا RNA بروید.**",
    "**تا ۶ هفته اکثریت قاطع افراد سرم‌مثبت می‌شوند و تا ۱۲ هفته عملاً همه.**",
    "**پس یک آنتی‌بادی منفی در تماس تازه هیچ چیزی را رد نمی‌کند و باید تکرار شود.**",
]
ACUTE_EN = [
    "WARNING: ACUTE HIV INFECTION IS A MONONUCLEOSIS-LIKE PICTURE appearing 2 to 6 weeks after exposure.",
    "Fever, sore throat, generalised lymphadenopathy, myalgia, arthralgia, headache and a maculopapular rash.",
    "Oral ulcers and relative leucopenia are also common and help the diagnosis.",
    "WARNING, DURING THIS PERIOD THE CD4 COUNT FALLS TRANSIENTLY, sometimes steeply, and the viral load is very high.",
    "That is why the patient is extremely infectious at this stage, and why a transient opportunistic infection is occasionally seen.",
    "WARNING, AND THE KEY DIAGNOSTIC POINT: in the first days ANTIBODY HAS NOT YET BEEN MADE.",
    "So an antibody-only test in that window can be falsely negative.",
    "Order in which markers turn positive: RNA from about day 10, p24 antigen from about week 2, antibody from week 3 to 12.",
    "WARNING, AND HERE YOU MUST KNOW THE GENERATION OF THE ASSAY, or this chapter's keys look contradictory:",
    "A THIRD-generation test sees only antibody; at four weeks it may still be negative.",
    "A FOURTH-generation test (combined antigen/antibody) also detects p24 itself and turns positive from about week 2.",
    "Today's CDC algorithm begins with exactly that combined assay, and that resolves the apparent conflict between the keys.",
    "Practical rule: if the combined assay is available, it IS the first step.",
    "WARNING, AND IF YOU HAVE ONLY AN ANTIBODY TEST AND SUSPICION OF ACUTE INFECTION IS HIGH, go to p24 or RNA.",
    "By 6 weeks the great majority have seroconverted, and by 12 weeks essentially everyone.",
    "So a negative antibody after a recent exposure excludes nothing and must be repeated.",
]


# =========================================================== book:652
add("book:652", "recall", "easy",
 "**شایع‌ترین** راه انتقال HIV در جهان: **تماس جنسی هتروسکسوال** — «شایع‌ترین» با «پرخطرترین» فرق دارد.",
 "The COMMONEST route of HIV transmission worldwide is HETEROSEXUAL INTERCOURSE — and 'commonest' is not 'most efficient'.",
 TRANS_FA + [
  "**این سؤال «شایع‌ترین» را می‌خواهد، یعنی بیشترین تعداد موارد در جهان.**",
  "**بیش از سه‌چهارم عفونت‌های HIV در جهان از راه تماس جنسی منتقل شده‌اند.**",
  "⚠️ **و در میان اشکال تماس جنسی، هتروسکسوال بیشترین سهم جهانی را دارد.**",
  "**چون در بیشتر مناطق پرشیوع، اپیدمی عمدتاً هتروسکسوال است.**",
  "**اگر سؤال «پرخطرترین در هر مواجهه» را می‌پرسید، پاسخ انتقال خون بود، نه تماس جنسی.**",
 ],
 TRANS_EN + [
  "This question asks for the COMMONEST route, meaning the largest number of cases worldwide.",
  "More than three quarters of HIV infections worldwide have been acquired sexually.",
  "WARNING, AND AMONG SEXUAL ROUTES, HETEROSEXUAL CONTACT CARRIES THE LARGEST GLOBAL SHARE.",
  "Because in most high-prevalence regions the epidemic is predominantly heterosexual.",
  "Had the question asked for the highest risk PER EXPOSURE, the answer would be transfusion, not sex.",
 ],
 "این سؤال ساده به‌نظر می‌رسد ولی یک دام کلاسیک دارد که بسیاری در آن می‌افتند.\n\n"
 "⚠️ **دام: «شایع‌ترین» و «پرخطرترین» دو چیز کاملاً متفاوت‌اند.**\n\n"
 "**شایع‌ترین** یعنی **بیشترین تعداد موارد** در جمعیت. **پرخطرترین** یعنی **بیشترین احتمال "
 "ابتلا در یک بار مواجهه**. یک راه می‌تواند بسیار پرخطر باشد ولی چون به‌ندرت اتفاق می‌افتد، "
 "سهم کمی از کل موارد داشته باشد — و انتقال خون آلوده دقیقاً همین است.\n\n"
 "**آمار جهانی:** بیش از **سه‌چهارم** عفونت‌های HIV از راه **تماس جنسی** منتقل شده‌اند، و در "
 "مقیاس جهانی **هتروسکسوال** بیشترین سهم را دارد.\n\n"
 "**در مقابل، خطر در هر بار مواجهه:**\n\n"
 "**انتقال خون آلوده ≈ ۹۰ درصد** — بالاترین، چون حجم زیادی از ویروس مستقیم وارد جریان خون می‌شود.\n\n"
 "**سوزن مشترک ≈ ۰٫۶ تا ۱ درصد.**\n\n"
 "**تماس جنسی ≈ ۰٫۰۴ تا ۱٫۴ درصد** بسته به نوع تماس.\n\n"
 "**نیدل‌استیک شغلی ≈ ۰٫۳ درصد.**\n\n"
 "⚠️ **پس انتقال خون پرخطرترین است ولی چون امروز خون‌ها غربال می‌شوند، نادر است؛ و تماس "
 "جنسی کم‌خطرتر است ولی چون بی‌شمار بار تکرار می‌شود، شایع‌ترین است.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟** مادر به جنین حدود ۵ تا ۱۰ درصد موارد جهانی است، تماس شغلی "
 "بسیار نادر، و فرآورده‌های خونی از زمان غربالگری همگانی عملاً حذف شده‌اند.",
 "This looks like an easy question but contains a classic trap.\n\n"
 "WARNING, THE TRAP: 'COMMONEST' AND 'MOST EFFICIENT' ARE TWO DIFFERENT THINGS.\n\n"
 "Commonest means the LARGEST NUMBER OF CASES in a population. Most efficient means the HIGHEST "
 "PROBABILITY PER SINGLE EXPOSURE. A route can be very efficient yet contribute few cases because "
 "it happens rarely — and transfusion of infected blood is exactly that.\n\n"
 "GLOBAL FIGURES: more than THREE QUARTERS of HIV infections have been acquired SEXUALLY, and on "
 "a world scale HETEROSEXUAL contact carries the largest share.\n\n"
 "BY CONTRAST, RISK PER EXPOSURE:\n\n"
 "TRANSFUSION OF INFECTED BLOOD, about 90 per cent — the highest, because a large viral load "
 "enters the bloodstream directly.\n\n"
 "SHARED NEEDLES, about 0.6 to 1 per cent.\n\n"
 "SEXUAL CONTACT, about 0.04 to 1.4 per cent depending on the act.\n\n"
 "OCCUPATIONAL NEEDLESTICK, about 0.3 per cent.\n\n"
 "WARNING: SO TRANSFUSION IS THE MOST EFFICIENT BUT, NOW THAT BLOOD IS SCREENED, RARE; AND SEX IS "
 "LESS EFFICIENT BUT, BECAUSE IT IS REPEATED COUNTLESS TIMES, THE COMMONEST.\n\n"
 "AND WHY NOT THE OTHER THREE? Mother-to-child accounts for roughly 5 to 10 per cent of global "
 "cases, occupational exposure is very rare, and blood products have been all but eliminated since "
 "universal screening.",
 ["پاسخ صحیح — بیش از سه‌چهارم موارد جهانی از راه جنسی، و هتروسکسوال بیشترین سهم را دارد.",
  "انتقال مادر به کودک حدود ۵ تا ۱۰ درصد موارد جهانی است، نه شایع‌ترین راه.",
  "تماس شغلی بسیار نادر است و سهم ناچیزی از کل موارد جهانی دارد.",
  "فرآورده‌های خونی پرخطرترین راه در هر مواجهه‌اند، ولی با غربالگری همگانی دیگر شایع نیستند."],
 ["Correct — over three quarters of global cases are sexual, and heterosexual contact is the largest share.",
  "Mother-to-child transmission is about 5 to 10 per cent of global cases, not the commonest route.",
  "Occupational exposure is very rare and contributes a negligible share of global cases.",
  "Blood products are the most efficient route per exposure, but universal screening has made them uncommon."],
 "**شایع‌ترین = تماس جنسی هتروسکسوال؛ پرخطرترین در هر مواجهه = انتقال خون.**",
 "Commonest is heterosexual sex; most efficient per exposure is transfusion.",
 [H202, WHOMTCT])


# =========================================================== book:653
add("book:653", "recall", "easy",
 "از میان بزاق، «مایعات»، نیش پشه و شیر مادر — تنها **شیر مادر** ناقل است.",
 "Of saliva, 'fluids', a mosquito bite and breast milk, only BREAST MILK transmits.",
 TRANS_FA + [
  "**شیر مادر یکی از چهار مایع پرخطر است و در فهرست رسمی جای دارد.**",
  "⚠️ **و شیردهی به‌تنهایی ۵ تا ۲۰ درصد به خطر انتقال مادر به کودک اضافه می‌کند.**",
  "**به همین دلیل در کشورهایی با دسترسی به شیر مصنوعی سالم، شیردهی توصیه نمی‌شود.**",
  "**ولی سازمان جهانی بهداشت در مناطق کم‌درآمد شیردهی همراه با ART مادر را ترجیح می‌دهد.**",
  "**چون خطر مرگ نوزاد از اسهال و سوءتغذیه بیشتر از خطر انتقال ویروس تحت درمان است.**",
 ],
 TRANS_EN + [
  "Breast milk is one of the four high-risk fluids and appears on the official list.",
  "WARNING, AND BREASTFEEDING ALONE ADDS 5 TO 20 PER CENT to the risk of mother-to-child transmission.",
  "That is why breastfeeding is not advised where safe formula is available.",
  "But in low-income settings the WHO prefers breastfeeding together with maternal ART.",
  "Because the risk of infant death from diarrhoea and malnutrition exceeds the residual transmission risk under treatment.",
 ],
 "این سؤال مستقیماً **فهرست مایعات پرخطر** را می‌آزماید. قاعده‌ی دوشرطی را به کار ببرید.\n\n"
 "⚠️ **چهار مایع پرخطر: خون، منی، ترشحات واژن، شیر مادر.**\n\n"
 "**شیر مادر** هم ویروس آزاد دارد و هم سلول‌های آلوده، و مخاط گوارشی نوزاد نابالغ است — "
 "پس هر دو شرط انتقال برقرار است.\n\n"
 "**بار عددی این موضوع را بدانید:** شیردهی به‌تنهایی **۵ تا ۲۰ درصد** به خطر انتقال مادر "
 "به کودک اضافه می‌کند.\n\n"
 "**و یک تصمیم بالینی ظریف:** در کشورهایی با آب سالم و دسترسی به شیر مصنوعی، **شیردهی "
 "توصیه نمی‌شود**. ولی **سازمان جهانی بهداشت** در مناطق کم‌درآمد، **شیردهی همراه با درمان "
 "ضدرتروویروسی مادر** را ترجیح می‌دهد — چون در آن محیط، خطر مرگ نوزاد از **اسهال و "
 "سوءتغذیه** بیش از خطر باقی‌مانده‌ی انتقال ویروس است. این یک تصمیم مبتنی بر **موازنه‌ی "
 "خطر** است، نه تناقض.\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**بزاق** — غلظت ویروس در آن ناچیز است و **مهارکننده‌های طبیعی** دارد. هیچ مورد مستند "
 "انتقال با بوسه‌ی معمولی گزارش نشده است.\n\n"
 "**«مایعات»** — گزینه‌ای مبهم است؛ فقط مایعات فهرست‌شده ناقل‌اند، نه هر مایع بدن.\n\n"
 "⚠️ **نیش پشه** — این مهم‌ترین نکته‌ی این سؤال است و باید **دلیلش** را بدانید، نه فقط "
 "جوابش: پشه HIV را منتقل نمی‌کند **نه چون حجم خون کم است**، بلکه چون **ویروس در بدن پشه "
 "تکثیر نمی‌شود**. در مالاریا انگل در پشه چرخه‌ی زیستی دارد و به غدد بزاقی می‌رسد؛ HIV در "
 "دستگاه گوارش پشه **هضم می‌شود** و هرگز به بزاق نمی‌رسد.",
 "This question tests the LIST OF HIGH-RISK FLUIDS directly. Apply the two-part rule.\n\n"
 "WARNING, THE FOUR HIGH-RISK FLUIDS: blood, semen, vaginal secretions, breast milk.\n\n"
 "BREAST MILK contains both free virus and infected cells, and the infant's gut mucosa is immature "
 "— so both conditions for transmission are met.\n\n"
 "KNOW THE NUMBER: breastfeeding alone adds 5 TO 20 PER CENT to mother-to-child transmission risk.\n\n"
 "AND A SUBTLE CLINICAL DECISION: where water is safe and formula available, BREASTFEEDING IS NOT "
 "ADVISED. But in low-income settings the WORLD HEALTH ORGANIZATION prefers BREASTFEEDING WITH "
 "MATERNAL ANTIRETROVIRAL THERAPY — because there, the risk of infant death from DIARRHOEA AND "
 "MALNUTRITION exceeds the residual transmission risk. This is a RISK-BALANCE decision, not a "
 "contradiction.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "SALIVA — the viral concentration is negligible and it contains NATURAL INHIBITORS. No documented "
 "transmission by ordinary kissing has ever been reported.\n\n"
 "'FLUIDS' — a vague option; only the listed fluids transmit, not every body fluid.\n\n"
 "WARNING, THE MOSQUITO BITE — this is the most important point in the question, and you must know "
 "the REASON and not merely the answer: mosquitoes do not transmit HIV NOT BECAUSE THE BLOOD VOLUME "
 "IS SMALL, but because THE VIRUS DOES NOT REPLICATE IN THE MOSQUITO. In malaria the parasite has a "
 "life cycle in the insect and reaches its salivary glands; HIV is DIGESTED in the mosquito gut and "
 "never reaches saliva.",
 ["بزاق غلظت ویروسی ناچیز و مهارکننده‌ی طبیعی دارد؛ بوسه‌ی معمولی ناقل نیست.",
  "«مایعات» گزینه‌ای مبهم است؛ تنها مایعات فهرست‌شده ناقل‌اند، نه هر مایع بدن.",
  "نیش پشه ناقل نیست، چون ویروس در بدن پشه تکثیر نمی‌شود و به بزاق او نمی‌رسد.",
  "پاسخ صحیح — شیر مادر یکی از چهار مایع پرخطر است و ۵ تا ۲۰ درصد خطر اضافه می‌کند."],
 ["Saliva has a negligible viral concentration and natural inhibitors; ordinary kissing does not transmit.",
  "'Fluids' is a vague option; only the listed fluids transmit, not every body fluid.",
  "A mosquito bite does not transmit, because the virus does not replicate in the mosquito or reach its saliva.",
  "Correct — breast milk is one of the four high-risk fluids and adds 5 to 20 per cent of risk."],
 "**شیر مادر یکی از چهار مایع پرخطر است. پشه ناقل نیست چون ویروس در آن تکثیر نمی‌شود.**",
 "Breast milk is one of the four high-risk fluids; mosquitoes do not transmit because the virus does not replicate in them.",
 [H202, WHOMTCT])


# =========================================================== book:654
add("book:654", "recall", "easy",
 "میان گازگرفتگی انسان، عرق، اشک و ادرار — تنها **گازگرفتگی** می‌تواند خون را وارد کند.",
 "Of a human bite, sweat, tears and urine, only THE BITE can introduce blood.",
 TRANS_FA + [
  "**گازگرفتگی انسان به‌خودی‌خود پرخطر نیست؛ آنچه خطر می‌سازد حضور خون است.**",
  "⚠️ **اگر گازگرفتگی پوست را پاره کند و بزاق فرد آلوده خون داشته باشد، مواجهه‌ی واقعی است.**",
  "**مواردی از انتقال با گازگرفتگی گزارش شده، ولی همگی با خونِ قابل‌رؤیت همراه بوده‌اند.**",
  "**عرق، اشک و ادرار در فهرست مایعات بی‌خطر هستند و هیچ موردی از انتقال با آن‌ها ثبت نشده است.**",
  "**پس این سؤال در واقع می‌پرسد: کدام گزینه اصلاً می‌تواند خون را وارد ماجرا کند؟**",
 ],
 TRANS_EN + [
  "A human bite is not intrinsically high risk; what creates risk is the presence of BLOOD.",
  "WARNING, IF THE BITE BREAKS THE SKIN AND THE BITER'S SALIVA CONTAINS BLOOD, that is a real exposure.",
  "Transmission by biting has been reported, but always with visible blood involved.",
  "Sweat, tears and urine are on the safe list and no transmission by them has ever been recorded.",
  "So the question really asks: which option can introduce blood into the situation at all?",
 ],
 "این سؤال دوباره **قاعده‌ی دوشرطی** را می‌آزماید، ولی از زاویه‌ای متفاوت: **کدام گزینه "
 "اصلاً می‌تواند خون را وارد ماجرا کند؟**\n\n"
 "**عرق، اشک و ادرار** هر سه در **فهرست مایعات بی‌خطر** هستند: غلظت ویروس در آن‌ها آن‌قدر "
 "پایین است که هیچ مورد مستندی از انتقال با آن‌ها در ادبیات پزشکی وجود ندارد. پس هر سه "
 "**شرط اول** را رد می‌کنند.\n\n"
 "⚠️ **گازگرفتگی انسان تنها گزینه‌ای است که می‌تواند هر دو شرط را برآورده کند.**\n\n"
 "ولی این را دقیق بفهمید: **گازگرفتگی به‌خودی‌خود پرخطر نیست**. بزاق تنها، بی‌خطر است. "
 "آنچه خطر می‌سازد این است که **گاز گرفتن پوست را پاره می‌کند** (راه ورود) و **ممکن است "
 "بزاق فرد گازگیرنده خون داشته باشد** (مثلاً از خونریزی لثه یا زخم دهانی). در آن حالت "
 "عملاً **خون به خون** شده است.\n\n"
 "**در ادبیات پزشکی چند مورد انتقال با گازگرفتگی گزارش شده است**، و در همه‌ی آن‌ها **خون "
 "قابل‌رؤیت** در دهان گازگیرنده وجود داشته و پوست پاره شده بوده است. گازگرفتگی بدون پارگی "
 "پوست، خطر صفر دارد.\n\n"
 "**نتیجه‌ی عملی:** در ارزیابی گازگرفتگی، دو چیز را بپرسید — **آیا پوست پاره شده؟** و "
 "**آیا خون در کار بوده؟** اگر پاسخ هر دو مثبت است، این یک مواجهه‌ی واقعی است و باید "
 "پروفیلاکسی پس از مواجهه بررسی شود.",
 "This question tests the TWO-PART RULE again, from a different angle: WHICH OPTION CAN INTRODUCE "
 "BLOOD AT ALL?\n\n"
 "SWEAT, TEARS AND URINE are all on the SAFE LIST: their viral concentration is so low that no "
 "documented transmission by them exists in the literature. All three fail CONDITION ONE.\n\n"
 "WARNING: A HUMAN BITE IS THE ONLY OPTION THAT CAN SATISFY BOTH CONDITIONS.\n\n"
 "But understand it precisely: A BITE IS NOT INTRINSICALLY HIGH RISK. Saliva alone is safe. What "
 "creates risk is that BITING BREAKS THE SKIN (a route of entry) and THE BITER'S SALIVA MAY CONTAIN "
 "BLOOD (from bleeding gums or an oral lesion). In that case it has effectively become a "
 "BLOOD-TO-BLOOD exposure.\n\n"
 "A FEW CASES OF TRANSMISSION BY BITING HAVE BEEN REPORTED, and in all of them there was VISIBLE "
 "BLOOD in the biter's mouth and the skin was broken. A bite that does not break the skin carries "
 "zero risk.\n\n"
 "PRACTICAL CONSEQUENCE: when assessing a bite, ask two things — WAS THE SKIN BROKEN? and WAS "
 "BLOOD INVOLVED? If both answers are yes, this is a real exposure and post-exposure prophylaxis "
 "must be considered.",
 ["پاسخ صحیح — گازگرفتگی تنها گزینه‌ای است که با پاره کردن پوست و خونِ همراه، هر دو شرط را برآورده می‌کند.",
  "عرق در فهرست مایعات بی‌خطر است و هیچ مورد انتقالی با آن ثبت نشده است.",
  "اشک نیز مایع بی‌خطر است؛ غلظت ویروس در آن ناچیز است.",
  "ادرار هم بی‌خطر است، مگر آنکه خون قابل‌رؤیت داشته باشد."],
 ["Correct — the bite is the only option that can meet both conditions, by breaking skin with blood present.",
  "Sweat is on the safe list and no transmission by it has ever been recorded.",
  "Tears are likewise a safe fluid; the viral concentration in them is negligible.",
  "Urine is also safe, unless it contains visible blood."],
 "**بزاق بی‌خطر است؛ گازگرفتگی وقتی خطرناک می‌شود که پوست پاره شود و خون در کار باشد.**",
 "Saliva is safe; a bite becomes dangerous only when the skin is broken and blood is involved.",
 [H202, CDCPEP])


# =========================================================== book:655
add("book:655", "recall", "medium",
 "**پرخطرترین** راه در هر مواجهه: **انفوزیون خون آلوده** (حدود ۹۰٪) — بالاتر از هر سه پنجره‌ی مادر به کودک.",
 "The MOST EFFICIENT route per exposure is TRANSFUSION OF INFECTED BLOOD (about 90 per cent) — above all three mother-to-child windows.",
 TRANS_FA + MTCT_FA[:8] + [
  "⚠️ **این سؤال قرینه‌ی سؤال «شایع‌ترین» است و پاسخ متفاوتی دارد: انفوزیون خون.**",
  "**چون در انتقال خون، حجم بسیار زیادی ویروس مستقیماً وارد جریان خون می‌شود.**",
  "**هیچ سد مخاطی، هیچ رقت و هیچ فرصتی برای ایمنی ذاتی وجود ندارد.**",
 ],
 TRANS_EN + MTCT_EN[:8] + [
  "WARNING: THIS IS THE MIRROR OF THE 'COMMONEST' QUESTION and has a different answer: transfusion.",
  "Because in transfusion a very large viral load enters the bloodstream directly.",
  "There is no mucosal barrier, no dilution and no opportunity for innate immunity.",
 ],
 "⚠️ **این سؤال قرینه‌ی سؤال قبلی است: آنجا «شایع‌ترین» را پرسید، اینجا «بیشترین شانس» را "
 "می‌پرسد — و پاسخ متفاوت است.**\n\n"
 "**انفوزیون خون آلوده: حدود ۹۰ درصد در هر واحد.** این بالاترین عدد در تمام جدول انتقال "
 "HIV است. **چرا؟** چون در انتقال خون:\n\n"
 "**۱)** حجم بسیار زیادی ویروس **یک‌جا** وارد می‌شود.\n\n"
 "**۲)** ورود **مستقیم به جریان خون** است، بدون سد مخاطی.\n\n"
 "**۳)** ویروس **رقیق نمی‌شود** و فرصتی برای ایمنی ذاتی مخاطی وجود ندارد.\n\n"
 "**و سه گزینه‌ی دیگر همگی پنجره‌های انتقال مادر به کودک هستند.** ارقامشان را بدانید، "
 "چون سؤال‌های دیگری روی همین ارقام ساخته شده‌اند:\n\n"
 "**داخل رحمی: حدود ۵ تا ۱۰ درصد.** کمترین سهم از سه پنجره.\n\n"
 "**حین زایمان: حدود ۱۰ تا ۲۰ درصد.** ⚠️ **بیشترین سهم از سه پنجره** — چون نوزاد در معرض "
 "حجم زیادی از خون و ترشحات مادر قرار می‌گیرد.\n\n"
 "**شیردهی: حدود ۵ تا ۲۰ درصد** در کل دوره‌ی شیردهی.\n\n"
 "⚠️ **پس حتی پرخطرترین پنجره‌ی مادر به کودک (زایمان، ۱۰ تا ۲۰ درصد) هم به گرد ۹۰ درصد "
 "انتقال خون نمی‌رسد.**\n\n"
 "**و نکته‌ی امیدبخش:** با درمان ضدرتروویروسی مادر و سرکوب کامل بار ویروسی، مجموع خطر "
 "مادر به کودک از ۱۵ تا ۴۵ درصد به **زیر ۱ تا ۲ درصد** می‌رسد.",
 "WARNING: THIS IS THE MIRROR OF THE PREVIOUS QUESTION. That one asked for the COMMONEST route; "
 "this one asks for the GREATEST CHANCE — and the answer is different.\n\n"
 "TRANSFUSION OF INFECTED BLOOD: about 90 per cent per unit. That is the highest figure in the "
 "whole HIV transmission table. WHY? Because in transfusion:\n\n"
 "1) A very large viral load enters ALL AT ONCE.\n\n"
 "2) Entry is DIRECTLY INTO THE BLOODSTREAM, with no mucosal barrier.\n\n"
 "3) The virus is NOT DILUTED and there is no opportunity for mucosal innate immunity.\n\n"
 "THE OTHER THREE OPTIONS ARE ALL MOTHER-TO-CHILD WINDOWS. Know their figures, because other "
 "questions are built on them:\n\n"
 "IN UTERO: about 5 to 10 per cent. The smallest of the three windows.\n\n"
 "INTRAPARTUM: about 10 to 20 per cent. WARNING — THE LARGEST OF THE THREE, because the infant "
 "meets a large volume of maternal blood and secretions.\n\n"
 "BREASTFEEDING: about 5 to 20 per cent across the whole feeding period.\n\n"
 "WARNING: SO EVEN THE RISKIEST MOTHER-TO-CHILD WINDOW (delivery, 10 to 20 per cent) COMES NOWHERE "
 "NEAR THE 90 PER CENT OF TRANSFUSION.\n\n"
 "AND THE HOPEFUL POINT: with maternal antiretroviral therapy and full viral suppression, total "
 "mother-to-child risk falls from 15 to 45 per cent down to BELOW 1 TO 2 PER CENT.",
 ["انتقال داخل رحمی حدود ۵ تا ۱۰ درصد است و کمترین سهم سه پنجره‌ی مادر به کودک را دارد.",
  "انتقال حین زایمان حدود ۱۰ تا ۲۰ درصد است — بیشترین پنجره‌ی مادر به کودک، ولی باز هم زیر ۹۰ درصد.",
  "پاسخ صحیح — انفوزیون خون آلوده با حدود ۹۰ درصد، پرخطرترین راه در هر مواجهه است.",
  "شیردهی حدود ۵ تا ۲۰ درصد در کل دوره اضافه می‌کند، نه در یک مواجهه."],
 ["In-utero transmission is about 5 to 10 per cent, the smallest of the three mother-to-child windows.",
  "Intrapartum transmission is about 10 to 20 per cent — the largest maternal window, but still far below 90 per cent.",
  "Correct — transfusion of infected blood, at about 90 per cent, is the most efficient route per exposure.",
  "Breastfeeding adds about 5 to 20 per cent over the whole feeding period, not in a single exposure."],
 "**انتقال خون ۹۰٪ در هر مواجهه — بالاتر از هر سه پنجره‌ی مادر به کودک.**",
 "Transfusion carries 90 per cent per exposure — higher than all three mother-to-child windows.",
 [H202, WHOMTCT])


# =========================================================== book:656
add("book:656", "recall", "easy",
 "مدفوع، ادرار و خلط — **هر سه** بی‌خطرند، پس «همه‌ی موارد فوق» پاسخ است.",
 "Faeces, urine and sputum are ALL safe, so 'all of the above' is the answer.",
 TRANS_FA + [
  "**این سؤال فهرست مایعات بی‌خطر را مستقیم می‌آزماید و ساختار «همه‌ی موارد» دارد.**",
  "⚠️ **مدفوع، ادرار و خلط هر سه در فهرست بی‌خطر هستند — پس هیچ‌کدام در انتقال دخالت ندارند.**",
  "**تنها استثنا: اگر خونِ قابل‌رؤیت داشته باشند، دیگر آن مایع نیستند بلکه خون‌اند.**",
  "**این قید «خون قابل‌رؤیت» در همه‌ی دستورالعمل‌های شغلی تکرار شده است.**",
  "**پس در مراقبت روزمره از بیمار HIV مثبت، تماس با این ترشحات نیازی به احتیاط ویژه ندارد.**",
  "**احتیاطات استاندارد کافی است — و همین پیام، انگ‌زدایی از بیمار را هم آسان می‌کند.**",
 ],
 TRANS_EN + [
  "This question tests the safe-fluid list directly and uses an 'all of the above' structure.",
  "WARNING: FAECES, URINE AND SPUTUM ARE ALL ON THE SAFE LIST — so none of them plays a part in transmission.",
  "The only exception: if they contain VISIBLE BLOOD they are no longer that fluid but blood.",
  "That 'visible blood' proviso is repeated in every occupational guideline.",
  "So in routine care of an HIV-positive patient, contact with these secretions needs no special precaution.",
  "Standard precautions suffice — and that message also helps destigmatise the patient.",
 ],
 "این سؤال ساختار «همه‌ی موارد فوق» دارد و مستقیماً **فهرست مایعات بی‌خطر** را می‌آزماید.\n\n"
 "⚠️ **مدفوع، ادرار و خلط — هر سه در فهرست بی‌خطرند.**\n\n"
 "**چرا؟** چون **شرط اول** قاعده را رد می‌کنند: غلظت ویروس در آن‌ها آن‌قدر پایین است که "
 "برای انتقال کافی نیست. در تمام ادبیات پزشکی هیچ مورد مستندی از انتقال HIV با این سه "
 "مایع گزارش نشده است.\n\n"
 "**پس چون هر سه گزینه «در انتقال دخالت ندارند»، پاسخ «همه‌ی موارد فوق» است.**\n\n"
 "⚠️ **و تنها استثنا را حفظ کنید، چون در هر دستورالعمل شغلی تکرار می‌شود: خونِ قابل‌رؤیت.**\n\n"
 "اگر مدفوع خونی، ادرار خونی یا خلط خونی باشد، دیگر با «مدفوع» و «ادرار» و «خلط» طرف "
 "نیستید — **با خون طرفید**، و خون پرخطرترین مایع است. به همین دلیل است که دستورالعمل‌ها "
 "همیشه می‌گویند «مگر آنکه حاوی خون قابل‌رؤیت باشد».\n\n"
 "**و یک نتیجه‌ی عملی و انسانی:** در مراقبت روزمره از بیمار HIV مثبت — تعویض ملحفه، کمک "
 "به توالت، جمع‌آوری نمونه‌ی خلط — **احتیاطات استاندارد کافی است** و نیازی به اقدامات ویژه "
 "نیست. دانستن این نکته، هم پرسنل را از ترس بی‌مورد رها می‌کند و هم بیمار را از انزوایی "
 "که هیچ توجیه علمی ندارد.",
 "This question uses an 'all of the above' structure and tests the SAFE-FLUID LIST directly.\n\n"
 "WARNING: FAECES, URINE AND SPUTUM ARE ALL ON THE SAFE LIST.\n\n"
 "WHY? Because they fail CONDITION ONE of the rule: their viral concentration is too low for "
 "transmission. In the entire literature there is no documented case of HIV transmission by these "
 "three fluids.\n\n"
 "SO SINCE ALL THREE OPTIONS 'PLAY NO PART IN TRANSMISSION', THE ANSWER IS 'ALL OF THE ABOVE'.\n\n"
 "WARNING, AND MEMORISE THE ONE EXCEPTION, because it recurs in every occupational guideline: "
 "VISIBLE BLOOD.\n\n"
 "If the faeces, urine or sputum is bloody, you are no longer dealing with faeces, urine or sputum "
 "— YOU ARE DEALING WITH BLOOD, and blood is the highest-risk fluid. That is why guidelines always "
 "add 'unless they contain visible blood'.\n\n"
 "AND A PRACTICAL, HUMANE CONSEQUENCE: in routine care of an HIV-positive patient — changing "
 "sheets, helping to the toilet, collecting a sputum specimen — STANDARD PRECAUTIONS SUFFICE and "
 "nothing special is required. Knowing this frees staff from needless fear and spares the patient "
 "an isolation that has no scientific justification.",
 ["مدفوع در فهرست مایعات بی‌خطر است، پس به‌تنهایی پاسخ کامل سؤال «همه‌ی موارد» نیست.",
  "ادرار نیز بی‌خطر است، ولی سؤال هر سه مایع را با هم می‌پرسد.",
  "خلط هم بی‌خطر است؛ باز هم پاسخ باید هر سه را در بر بگیرد.",
  "پاسخ صحیح — هر سه مایع بی‌خطرند و هیچ‌یک در انتقال دخالت ندارد."],
 ["Faeces are on the safe list, but alone they are not the complete answer to an 'all of the above' stem.",
  "Urine is also safe, but the question asks about all three fluids together.",
  "Sputum is safe too; again the answer must include all three.",
  "Correct — all three fluids are safe and none plays any part in transmission."],
 "**مدفوع، ادرار و خلط بی‌خطرند — مگر آنکه خون قابل‌رؤیت داشته باشند.**",
 "Faeces, urine and sputum are safe — unless they contain visible blood.",
 [H202, CDCPEP])


# =========================================================== book:657
add("book:657", "recall", "medium",
 "عامل خطر **ثابت‌شده‌ی** انتقال حین زایمان: **فاصله‌ی طولانی بین پارگی پرده و زایمان**.",
 "The ESTABLISHED intrapartum risk factor is a PROLONGED INTERVAL FROM RUPTURE OF MEMBRANES TO DELIVERY.",
 MTCT_FA + [
  "**سؤال کلمه‌ی «ثابت‌شده» را عمداً آورده است — یعنی دنبال عامل اثبات‌شده در مطالعات می‌گردد.**",
  "⚠️ **پارگی طولانی پرده‌ها در متاآنالیزها به‌طور مستقل با افزایش انتقال همراه بوده است.**",
  "**قاعده‌ی تجربی کلاسیک: پس از ۴ ساعت، هر ساعت اضافه خطر را افزایش می‌دهد.**",
  "**سازوکار روشن است: نوزاد مدت طولانی‌تری در تماس با ترشحات آلوده می‌ماند.**",
  "**و همین است که پایه‌ی توصیه به سزارین برنامه‌ریزی‌شده در مادر با بار ویروسی بالا شد.**",
 ],
 MTCT_EN + [
  "The stem deliberately says 'ESTABLISHED' — it is looking for a factor proven in studies.",
  "WARNING: PROLONGED RUPTURE OF MEMBRANES IS INDEPENDENTLY ASSOCIATED WITH INCREASED TRANSMISSION in meta-analyses.",
  "The classic rule of thumb: beyond 4 hours, each additional hour raises the risk.",
  "The mechanism is plain: the infant remains in contact with infected secretions for longer.",
  "And that is the basis of planned caesarean section for a mother with a high viral load.",
 ],
 "کلمه‌ی کلیدی این سؤال **«ثابت‌شده»** است. سؤال دنبال عاملی می‌گردد که در **مطالعات** "
 "به‌عنوان عامل خطر مستقل تأیید شده باشد، نه هر چیزی که منطقی به‌نظر برسد.\n\n"
 "⚠️ **پاسخ: فاصله‌ی طولانی بین پارگی پرده‌ی آمنیون و زایمان.**\n\n"
 "**این عامل در متاآنالیزهای متعدد به‌طور مستقل با افزایش انتقال همراه بوده است**، و "
 "**قاعده‌ی تجربی کلاسیک** این است که **پس از حدود ۴ ساعت**، هر ساعت اضافه خطر را افزایش "
 "می‌دهد.\n\n"
 "**سازوکارش کاملاً روشن است:** تا وقتی پرده سالم است، نوزاد در محیط بسته‌ی آمنیوتیک محافظت "
 "می‌شود. با پارگی پرده، **آن سد از بین می‌رود** و نوزاد شروع به تماس با خون و ترشحات "
 "دستگاه تناسلی مادر می‌کند. **هرچه این تماس طولانی‌تر، خطر بیشتر.**\n\n"
 "**و این دقیقاً همان منطقی است که پشت توصیه‌ی سزارین برنامه‌ریزی‌شده** (پیش از شروع درد "
 "و پیش از پارگی پرده) در مادرانی با بار ویروسی بالا قرار دارد.\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**الکترود پوست سر جنین** — این یک اقدام **تهاجمی** است که پوست نوزاد را می‌خراشد و "
 "**منطقاً باید خطرناک باشد**؛ به همین دلیل هم **از آن پرهیز می‌شود**. ولی سؤال «عامل خطر "
 "ثابت‌شده» را می‌خواهد، و شواهد آن به قوت پارگی طولانی پرده نیست. این یک تمایز ظریف ولی "
 "واقعی است: **پرهیز احتیاطی** با **عامل خطر اثبات‌شده** یکی نیست.\n\n"
 "**مصرف مواد مخدر در بارداری** — عامل خطر برای **ابتلای خود مادر** است، نه عاملی که "
 "**حین زایمان** انتقال را زیاد کند.\n\n"
 "**کوریوآمنیونیت** — التهاب و شکستن سد جفتی می‌تواند خطر را زیاد کند و در برخی مطالعات "
 "همراهی نشان داده است، ولی معمولاً **همراه** پارگی طولانی پرده رخ می‌دهد و به‌عنوان عامل "
 "مستقلِ ثابت‌شده به قوت آن نیست.",
 "The key word in this stem is 'ESTABLISHED'. It is looking for a factor CONFIRMED IN STUDIES as an "
 "independent risk factor, not merely one that sounds plausible.\n\n"
 "WARNING, THE ANSWER: A PROLONGED INTERVAL BETWEEN RUPTURE OF THE MEMBRANES AND DELIVERY.\n\n"
 "This factor is INDEPENDENTLY ASSOCIATED WITH INCREASED TRANSMISSION in several meta-analyses, and "
 "the CLASSIC RULE OF THUMB is that BEYOND ABOUT 4 HOURS each additional hour raises the risk.\n\n"
 "THE MECHANISM IS PLAIN: while the membranes are intact the infant is protected inside the closed "
 "amniotic compartment. Once they rupture THAT BARRIER IS GONE and the infant begins to contact "
 "maternal blood and genital secretions. THE LONGER THAT CONTACT, THE GREATER THE RISK.\n\n"
 "AND THAT IS EXACTLY THE LOGIC BEHIND PLANNED CAESAREAN SECTION (before labour and before rupture) "
 "in mothers with a high viral load.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "FETAL SCALP ELECTRODES — an INVASIVE procedure that abrades the infant's skin and OUGHT logically "
 "to be dangerous, which is precisely why IT IS AVOIDED. But the stem asks for an ESTABLISHED risk "
 "factor, and the evidence is not as strong as for prolonged rupture. That is a subtle but real "
 "distinction: PRECAUTIONARY AVOIDANCE is not the same as a PROVEN RISK FACTOR.\n\n"
 "DRUG USE IN PREGNANCY — a risk factor for the MOTHER ACQUIRING HIV, not a factor that increases "
 "transmission DURING DELIVERY.\n\n"
 "CHORIOAMNIONITIS — inflammation and a broken placental barrier can increase risk and some studies "
 "show an association, but it usually occurs TOGETHER WITH prolonged rupture and is not as robustly "
 "established as an independent factor.",
 ["الکترود پوست سر جنین به‌صورت احتیاطی پرهیز می‌شود، ولی شواهدش به قوت پارگی طولانی پرده نیست.",
  "مصرف مواد مخدر عامل خطر ابتلای خود مادر است، نه عامل افزایش انتقال حین زایمان.",
  "پاسخ صحیح — فاصله‌ی طولانی پارگی پرده تا زایمان، عامل خطر مستقل و ثابت‌شده‌ی انتقال حین زایمان است.",
  "کوریوآمنیونیت معمولاً همراه پارگی طولانی رخ می‌دهد و به‌عنوان عامل مستقل ثابت‌شده به قوت آن نیست."],
 ["Fetal scalp electrodes are avoided as a precaution, but the evidence is weaker than for prolonged rupture.",
  "Drug use is a risk factor for the mother acquiring HIV, not for increased transmission at delivery.",
  "Correct — a prolonged interval from rupture of membranes to delivery is the established independent intrapartum risk factor.",
  "Chorioamnionitis usually accompanies prolonged rupture and is not as firmly established as an independent factor."],
 "**پارگی طولانی پرده = تماس طولانی‌تر نوزاد با ترشحات = خطر بیشتر.**",
 "Prolonged rupture means longer infant contact with secretions, and so greater risk.",
 [H202, WHOMTCT])


# =========================================================== book:658
add("book:658", "case", "easy",
 "بزاق روی **پوست سالم** = مواجهه‌ای رخ نداده. **نه تست، نه دارو، نه پیگیری.**",
 "Saliva on INTACT SKIN is not an exposure at all: no test, no drug, no follow-up.",
 TRANS_FA + MTCT_FA[9:] + [
  "**در این سناریو هر دو شرط قاعده شکسته‌اند، و همین کار را تمام می‌کند.**",
  "⚠️ **شرط یک شکسته: بزاق مایع بی‌خطر است و غلظت ویروس در آن ناچیز.**",
  "⚠️ **شرط دو شکسته: پوست سالم یک سد کامل است و راه ورودی وجود ندارد.**",
  "**پس درخواست تست برای فردی که مواجهه نداشته، هم بی‌فایده است و هم زیان‌بار.**",
  "**زیان‌بار چون اضطراب می‌سازد، انگ می‌زند، و احتمال مثبت کاذب را وارد ماجرا می‌کند.**",
 ],
 TRANS_EN + MTCT_EN[9:] + [
  "In this scenario BOTH conditions of the rule are broken, and that settles it.",
  "WARNING, CONDITION ONE FAILS: saliva is a safe fluid with a negligible viral concentration.",
  "WARNING, CONDITION TWO FAILS: intact skin is a complete barrier and there is no route of entry.",
  "So ordering a test for someone who has had no exposure is both useless and harmful.",
  "Harmful because it creates anxiety, stigmatises, and introduces the chance of a false positive.",
 ],
 "این سؤال یکی از مفیدترین سؤال‌های عملی این فصل است، چون **پاسخ درست، هیچ کاری نکردن است** "
 "— و «هیچ کاری نکردن» وقتی مبتنی بر دانش باشد، خودش یک تصمیم بالینی محکم است.\n\n"
 "**سناریو:** هنگام معاینه‌ی حلق بیمار HIV مثبت، **آب دهان او روی دست شما می‌ریزد**.\n\n"
 "⚠️ **قاعده‌ی دوشرطی را اجرا کنید — و ببینید هر دو شرط می‌شکنند:**\n\n"
 "**شرط یک (مایع پرخطر): شکسته.** بزاق در **فهرست مایعات بی‌خطر** است. غلظت ویروس در آن "
 "ناچیز است و بزاق حتی حاوی **مهارکننده‌های طبیعی** ویروس است.\n\n"
 "**شرط دو (راه ورود): شکسته.** پوست **سالم** یک سد کامل است. ویروس از پوست سالم عبور "
 "نمی‌کند.\n\n"
 "**وقتی هر دو شرط بشکنند، مواجهه‌ای رخ نداده است. نقطه.**\n\n"
 "**پس چرا سه گزینه‌ی دیگر نه‌تنها لازم نیستند، بلکه زیان‌بارند؟**\n\n"
 "**PCR** — برای فردی که مواجهه نداشته، یک آزمایش گران و بی‌معناست.\n\n"
 "**پروفیلاکسی دو دارویی** — ⚠️ این بدترین گزینه است. داروهای ضدرتروویروسی **عوارض واقعی** "
 "دارند: تهوع، اسهال، سمیت کبدی و کلیوی. تجویز ۲۸ روز دارو برای خطری که **صفر** است، "
 "آسیب محض است. ضمناً رژیم امروزی **سه‌دارویی** است، نه دو دارویی.\n\n"
 "**الایزا** — ⚠️ و این دام ظریف‌تر است. آزمایش برای فردی که مواجهه نداشته **احتمال مثبت "
 "کاذب** را وارد ماجرا می‌کند، و در جمعیت کم‌خطر بیشتر مثبت‌ها کاذب‌اند. یعنی آزمایش "
 "بی‌جهت می‌تواند **ماه‌ها اضطراب** بسازد برای خطری که وجود نداشته.\n\n"
 "**درس عملی:** در پزشکی، **اطمینان‌بخشی مبتنی بر دانش** خودش یک مداخله‌ی درمانی است. "
 "کاری که اینجا باید کرد، توضیح آرام و مستدل برای فرد است، نه سفارش آزمایش.",
 "This is one of the most practically useful questions in the chapter, because THE RIGHT ANSWER IS "
 "TO DO NOTHING — and doing nothing, when it rests on knowledge, is itself a firm clinical decision.\n\n"
 "THE SCENARIO: while examining the throat of an HIV-positive patient, SOME OF HIS SALIVA LANDS ON "
 "YOUR HAND.\n\n"
 "WARNING, RUN THE TWO-PART RULE — AND SEE THAT BOTH CONDITIONS FAIL:\n\n"
 "CONDITION ONE (high-risk fluid): FAILS. Saliva is on the SAFE LIST. Its viral concentration is "
 "negligible and it even contains NATURAL INHIBITORS of the virus.\n\n"
 "CONDITION TWO (route of entry): FAILS. INTACT skin is a complete barrier. The virus does not "
 "cross it.\n\n"
 "WHEN BOTH CONDITIONS FAIL, NO EXPOSURE HAS OCCURRED. Full stop.\n\n"
 "SO WHY ARE THE OTHER THREE OPTIONS NOT MERELY UNNECESSARY BUT HARMFUL?\n\n"
 "PCR — for someone who has had no exposure this is an expensive and meaningless test.\n\n"
 "TWO-DRUG PROPHYLAXIS — WARNING, this is the worst option. Antiretrovirals have REAL ADVERSE "
 "EFFECTS: nausea, diarrhoea, hepatic and renal toxicity. Prescribing 28 days of drugs against a "
 "risk that is ZERO is pure harm. Incidentally the modern regimen is THREE drugs, not two.\n\n"
 "ELISA — WARNING, and this is the subtler trap. Testing someone with no exposure introduces the "
 "CHANCE OF A FALSE POSITIVE, and in a low-risk population most positives are false. So a needless "
 "test can generate MONTHS OF ANXIETY over a risk that never existed.\n\n"
 "THE PRACTICAL LESSON: in medicine, REASSURANCE GROUNDED IN KNOWLEDGE is itself a therapeutic "
 "intervention. What is needed here is a calm, reasoned explanation, not a test request.",
 ["PCR برای فردی که اصلاً مواجهه نداشته، آزمایشی گران و بی‌معناست.",
  "پروفیلاکسی دارویی برای خطر صفر، فقط عوارض دارو را بدون هیچ سودی تحمیل می‌کند.",
  "پاسخ صحیح — بزاق روی پوست سالم مواجهه نیست؛ نه تست لازم است، نه دارو، نه پیگیری.",
  "الایزا در فردی بدون مواجهه، احتمال مثبت کاذب و اضطراب بی‌مورد را وارد ماجرا می‌کند."],
 ["PCR is an expensive, meaningless test for someone who has had no exposure at all.",
  "Drug prophylaxis against a zero risk imposes the drugs' adverse effects with no benefit whatsoever.",
  "Correct — saliva on intact skin is not an exposure; no test, no drug and no follow-up are needed.",
  "An ELISA in an unexposed person introduces the risk of a false positive and needless anxiety."],
 "**بزاق + پوست سالم = هر دو شرط انتقال شکسته. اطمینان‌بخشی، خودش درمان است.**",
 "Saliva plus intact skin breaks both transmission conditions; reassurance is itself the treatment.",
 [H202, CDCPEP])


# =========================================================== book:659
add("book:659", "case", "easy",
 "همان سناریو، همین پاسخ: بزاق روی پوست سالم ← **بدون اقدام خاص**، و پیگیری سرولوژیک هم لازم نیست.",
 "The same scenario, the same answer: saliva on intact skin needs NO ACTION — and no serological follow-up either.",
 TRANS_FA + MTCT_FA[9:] + [
  "**این سؤال تکرار عمدی همان سناریوست، ولی با یک گزینه‌ی وسوسه‌انگیزتر.**",
  "⚠️ **گزینه‌ی «آزمایش و تکرار در یک، سه و شش ماه» جدول پیگیری مواجهه‌ی واقعی است.**",
  "**آن جدول برای کسی است که واقعاً مواجهه داشته، نه کسی که فقط ترسیده است.**",
  "**اجرای آن برای مواجهه‌ی صفر یعنی شش ماه اضطراب تحمیلی بدون هیچ سود.**",
  "**و در محیط زندان که انگ اجتماعی شدیدتر است، این آسیب چند برابر می‌شود.**",
 ],
 TRANS_EN + MTCT_EN[9:] + [
  "This question deliberately repeats the same scenario, but with a more tempting distractor.",
  "WARNING: the option 'test and repeat at one, three and six months' IS THE FOLLOW-UP SCHEDULE FOR A REAL EXPOSURE.",
  "That schedule is for someone who actually had an exposure, not for someone who is merely frightened.",
  "Applying it to a zero exposure means six months of imposed anxiety for no benefit at all.",
  "And in a prison setting, where stigma is harsher, that harm is multiplied.",
 ],
 "این سؤال **تکرار عمدی** سناریوی قبلی است، و طراح آن را دوباره آورده چون **گزینه‌ی چهارم "
 "این‌بار وسوسه‌انگیزتر است**.\n\n"
 "**سناریو:** کارمند زندان، بزاق فرد HIV مثبت روی **دستش** پاشیده شده.\n\n"
 "**قاعده‌ی دوشرطی، همان پاسخ:** بزاق **مایع بی‌خطر** است (شرط یک شکسته)، و پوست **سالم** "
 "است (شرط دو شکسته). **مواجهه‌ای رخ نداده. پاسخ: بدون اقدام خاص.**\n\n"
 "⚠️ **و حالا دام واقعی این سؤال: گزینه‌ی «آزمایش HIV و تکرار یک، سه و شش ماه بعد».**\n\n"
 "**چرا این گزینه وسوسه‌انگیز است؟** چون **کاملاً درست به نظر می‌رسد** — و در واقع "
 "**جدول استاندارد پیگیری مواجهه‌ی شغلی واقعی** است. آزمایش پایه، سپس ۶ هفته، ۳ ماه و "
 "۶ ماه (یا با تست‌های نسل چهارم، ۴ ماه). یعنی گزینه، **دانش درست را در جای غلط** به کار "
 "برده است.\n\n"
 "**و چرا در اینجا غلط است؟** چون آن جدول برای کسی است که **واقعاً مواجهه داشته**. برای "
 "کسی که مواجهه نداشته، اجرای آن یعنی:\n\n"
 "**۱) شش ماه اضطراب** تحمیلی برای خطری که وجود ندارد.\n\n"
 "**۲) احتمال مثبت کاذب** در جمعیت کم‌خطر.\n\n"
 "**۳)** و در **محیط زندان** که انگ اجتماعی شدیدتر است، **آسیب چند برابر**.\n\n"
 "**و دو گزینه‌ی دارویی؟** رژیم دو دارویی امروزه منسوخ است و رژیم سه‌دارویی هم فقط برای "
 "**مواجهه‌ی واقعی** و **ظرف ۷۲ ساعت** تجویز می‌شود. تجویز آن برای خطر صفر، تحمیل عوارض "
 "بدون هیچ سود است.\n\n"
 "⚠️ **درس کلیدی: «دانستن اینکه چه زمانی نباید کاری کرد» به همان اندازه‌ی دانستن درمان "
 "اهمیت دارد.**",
 "This question DELIBERATELY REPEATS the previous scenario, and it is repeated because THE FOURTH "
 "OPTION IS MORE TEMPTING THIS TIME.\n\n"
 "THE SCENARIO: a prison officer has had the saliva of an HIV-positive person splashed ON HIS HAND.\n\n"
 "THE TWO-PART RULE, THE SAME ANSWER: saliva is a SAFE FLUID (condition one fails) and the skin is "
 "INTACT (condition two fails). NO EXPOSURE HAS OCCURRED. The answer: NO SPECIFIC ACTION.\n\n"
 "WARNING, AND NOW THE REAL TRAP: the option 'test for HIV and repeat at one, three and six months'.\n\n"
 "WHY IS IT TEMPTING? Because it LOOKS ENTIRELY CORRECT — and in fact it IS the standard follow-up "
 "schedule for a REAL occupational exposure: a baseline test, then 6 weeks, 3 months and 6 months "
 "(or 4 months with fourth-generation assays). The option applies CORRECT KNOWLEDGE IN THE WRONG "
 "PLACE.\n\n"
 "AND WHY IS IT WRONG HERE? Because that schedule is for someone who ACTUALLY HAD AN EXPOSURE. For "
 "someone who did not, applying it means:\n\n"
 "1) SIX MONTHS OF IMPOSED ANXIETY over a risk that does not exist.\n\n"
 "2) THE CHANCE OF A FALSE POSITIVE in a low-risk population.\n\n"
 "3) And IN A PRISON SETTING, where stigma is harsher, MULTIPLIED HARM.\n\n"
 "AND THE TWO DRUG OPTIONS? A two-drug regimen is obsolete, and even the three-drug regimen is given "
 "only for a REAL exposure and WITHIN 72 HOURS. Prescribing it against a zero risk imposes toxicity "
 "with no benefit.\n\n"
 "WARNING, THE KEY LESSON: KNOWING WHEN NOT TO ACT MATTERS AS MUCH AS KNOWING THE TREATMENT.",
 ["پاسخ صحیح — بزاق روی پوست سالم مواجهه نیست؛ هیچ اقدامی لازم نیست.",
  "رژیم دو دارویی امروزه منسوخ است و برای خطر صفر هیچ جایی ندارد.",
  "رژیم سه‌دارویی فقط برای مواجهه‌ی واقعی و ظرف ۷۲ ساعت است، نه برای بزاق روی پوست سالم.",
  "جدول پیگیری یک، سه و شش ماه برای مواجهه‌ی واقعی است؛ اینجا فقط شش ماه اضطراب بی‌مورد می‌سازد."],
 ["Correct — saliva on intact skin is not an exposure; no action is required.",
  "A two-drug regimen is obsolete and has no place against a zero risk.",
  "A three-drug regimen is only for a real exposure and within 72 hours, not for saliva on intact skin.",
  "The one, three and six month follow-up schedule is for a real exposure; here it only creates six months of needless anxiety."],
 "**دانستن اینکه چه زمانی نباید کاری کرد، به اندازه‌ی دانستن درمان مهم است.**",
 "Knowing when NOT to act matters as much as knowing the treatment.",
 [H202, CDCPEP])


# =========================================================== book:660
add("book:660", "case", "medium",
 "**سه نوبت پنومونی در یک سال** یک بیماری نشانگر است — پنومونی راجعه از ۱۹۹۳ تعریف‌کننده‌ی ایدز شد.",
 "THREE PNEUMONIAS IN ONE YEAR is an indicator illness — recurrent pneumonia became AIDS-defining in 1993.",
 STAGE_FA + [
  "**سؤال می‌پرسد کدام سابقه، آزمایش HIV را الزامی می‌کند.**",
  "⚠️ **پنومونی باکتریال راجعه یعنی دو بار یا بیشتر در ۱۲ ماه — و سه بار قطعاً در این تعریف است.**",
  "**این یک بیماری تعریف‌کننده‌ی ایدز است، پس به‌تنهایی اندیکاسیون آزمایش دارد.**",
  "**و تابلوی بالینی بیمار — تب، بی‌اشتهایی و کاهش وزن یک‌ماهه — با آن کاملاً هم‌خوان است.**",
  "**قاعده‌ی عملی: عفونت مکرر یا غیرمعمول در فرد جوان، تا خلاف آن ثابت نشود نقص ایمنی است.**",
 ],
 STAGE_EN + [
  "The stem asks which history makes an HIV test mandatory.",
  "WARNING: RECURRENT BACTERIAL PNEUMONIA MEANS TWO OR MORE EPISODES IN 12 MONTHS — and three is certainly within that.",
  "It is an AIDS-defining illness, so on its own it indicates testing.",
  "And the patient's picture — a month of fever, anorexia and weight loss — fits it exactly.",
  "Practical rule: recurrent or unusual infection in a young person is immunodeficiency until proven otherwise.",
 ],
 "**آقای ۲۷ ساله** با **تب، بی‌اشتهایی و کاهش وزن** از یک ماه قبل. سؤال می‌پرسد کدام "
 "**سابقه‌ی همراه**، بررسی از نظر HIV را الزامی می‌کند.\n\n"
 "⚠️ **پاسخ: سه نوبت پنومونی در یک سال اخیر.**\n\n"
 "**چرا؟ چون این دقیقاً یک بیماری تعریف‌کننده‌ی ایدز است.** در بازنگری **۱۹۹۳** CDC، "
 "**«پنومونی باکتریال راجعه — دو بار یا بیشتر در ۱۲ ماه»** به فهرست گروه C اضافه شد "
 "(همراه با سل ریوی و کانسر مهاجم سرویکس). **سه نوبت در یک سال** قطعاً در این تعریف "
 "می‌گنجد.\n\n"
 "**و منطق ایمنی‌شناختی‌اش را بدانید:** HIV علاوه بر تخریب لنفوسیت T، **عملکرد سلول B** "
 "را هم مختل می‌کند. نتیجه، **پاسخ آنتی‌بادی ناکارآمد به باکتری‌های کپسول‌دار** است — "
 "پنوموکوک و هموفیلوس. به همین دلیل **پنومونی باکتریال مکرر** یکی از زودرس‌ترین نشانه‌های "
 "HIV است و **حتی در CD4 نسبتاً بالا** هم رخ می‌دهد.\n\n"
 "**و همین توضیح می‌دهد چرا واکسن پنوموکوک در همه‌ی بیماران HIV مثبت توصیه می‌شود.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**مصرف استنشاقی تریاک** — ⚠️ این دام ظریفی است: **اعتیاد تزریقی** عامل خطر HIV است، ولی "
 "مصرف **استنشاقی** راه انتقال خونی ندارد. تفاوت در **راه مصرف** است، نه در ماده.\n\n"
 "**پسوریازیس** — یک بیماری پوستی شایع در جمعیت عمومی است. درست است که در HIV می‌تواند "
 "**شدیدتر** شود، ولی خودِ وجود پسوریازیس اندیکاسیون آزمایش نیست.\n\n"
 "**بستری به علت مننژیت ۶ ماه قبل** — یک اپیزود مننژیت **بدون ذکر نوع آن** اختصاصی نیست. "
 "اگر گفته بود **مننژیت کریپتوکوکی**، آنگاه بیماری تعریف‌کننده‌ی ایدز بود و پاسخ عوض "
 "می‌شد. **جزئیات مهم‌اند.**",
 "A 27-YEAR-OLD MAN with a month of FEVER, ANOREXIA AND WEIGHT LOSS. The stem asks which "
 "ACCOMPANYING HISTORY makes HIV testing mandatory.\n\n"
 "WARNING, THE ANSWER: THREE EPISODES OF PNEUMONIA IN THE PAST YEAR.\n\n"
 "WHY? BECAUSE THAT IS PRECISELY AN AIDS-DEFINING ILLNESS. In the CDC's 1993 revision, 'RECURRENT "
 "BACTERIAL PNEUMONIA — two or more episodes in 12 months' was added to the category C list "
 "(together with pulmonary TB and invasive cervical cancer). THREE episodes in one year clearly "
 "qualifies.\n\n"
 "AND KNOW THE IMMUNOLOGICAL LOGIC: besides destroying T lymphocytes, HIV also impairs B CELL "
 "FUNCTION. The result is an INEFFECTIVE ANTIBODY RESPONSE TO ENCAPSULATED BACTERIA — pneumococcus "
 "and Haemophilus. That is why RECURRENT BACTERIAL PNEUMONIA is one of the earliest signs of HIV "
 "and occurs EVEN AT A RELATIVELY HIGH CD4 COUNT.\n\n"
 "AND THAT ALSO EXPLAINS WHY PNEUMOCOCCAL VACCINE IS RECOMMENDED FOR EVERY HIV-POSITIVE PATIENT.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "SMOKING OPIUM — WARNING, a subtle trap: INJECTING drug use is an HIV risk factor, but INHALED use "
 "provides no blood-borne route. The difference lies in the ROUTE, not in the substance.\n\n"
 "PSORIASIS — a common skin disease in the general population. True, it can be MORE SEVERE in HIV, "
 "but its mere presence is not an indication to test.\n\n"
 "ADMISSION FOR MENINGITIS SIX MONTHS AGO — a single episode of meningitis WITH NO TYPE SPECIFIED is "
 "not specific. Had it said CRYPTOCOCCAL meningitis, that would be an AIDS-defining illness and the "
 "answer would change. THE DETAILS MATTER.",
 ["مصرف استنشاقی تریاک راه انتقال خونی ندارد؛ اعتیاد تزریقی است که عامل خطر محسوب می‌شود.",
  "پسوریازیس در جمعیت عمومی شایع است و به‌تنهایی اندیکاسیون آزمایش HIV نیست.",
  "پاسخ صحیح — پنومونی راجعه (دو بار یا بیشتر در ۱۲ ماه) از ۱۹۹۳ تعریف‌کننده‌ی ایدز است.",
  "یک اپیزود مننژیت بدون ذکر نوع اختصاصی نیست؛ اگر کریپتوکوکی بود پاسخ عوض می‌شد."],
 ["Smoking opium provides no blood-borne route; it is injecting drug use that is a risk factor.",
  "Psoriasis is common in the general population and alone is not an indication to test for HIV.",
  "Correct — recurrent pneumonia (two or more episodes in 12 months) has been AIDS-defining since 1993.",
  "A single episode of meningitis of unstated type is not specific; had it been cryptococcal the answer would change."],
 "**پنومونی راجعه = دو بار یا بیشتر در ۱۲ ماه = بیماری تعریف‌کننده‌ی ایدز.**",
 "Recurrent pneumonia means two or more episodes in 12 months and is AIDS-defining.",
 [H202, CDC93, CDC08])


# =========================================================== book:662  (KEY CORRECTED)
add("book:662", "recall", "hard",
 "⚠️ **کلید تصحیح شد:** گزینه‌ای که گروه C **نیست**، **لنفادنوپاتی ژنرالیزه‌ی دائمی** است — آن گروه A است.",
 "WARNING, THE KEY WAS CORRECTED: the option that is NOT category C is PERSISTENT GENERALISED LYMPHADENOPATHY, which is category A.",
 STAGE_FA + [
  "⚠️ **کلید چاپی «توکسوپلاسموز مغزی» را استثنا دانسته بود و این کلید تصحیح شد.**",
  "**توکسوپلاسموز مغز از سال ۱۹۸۷ در فهرست تعریف‌کننده‌ی ایدز بوده است — یعنی گروه C.**",
  "**پنومونی پنوموسیستیس هم از همان ابتدا در فهرست بوده و شاخص‌ترین عضو آن است.**",
  "**سل ریوی در بازنگری ۱۹۹۳ اضافه شد، ولی امروز قطعاً گروه C است.**",
  "⚠️ **و لنفادنوپاتی ژنرالیزه‌ی پایدار یکی از سه عضو گروه A است — پس تنها استثنای واقعی همین است.**",
  "**منشأ احتمالی خطای کلید: در فهرست ۱۹۸۷، سل ریوی تعریف‌کننده نبود.**",
  "**کسی که آن فهرست قدیمی را در ذهن داشته باشد، دنبال استثنا میان گزینه‌های ریوی می‌گردد.**",
  "**ولی حتی در فهرست ۱۹۸۷ هم توکسوپلاسموز مغزی گروه C بود — پس کلید با هر دو نسخه ناسازگار است.**",
 ],
 STAGE_EN + [
  "WARNING: THE PRINTED KEY TREATED CEREBRAL TOXOPLASMOSIS AS THE EXCEPTION, AND THAT KEY WAS CORRECTED.",
  "Toxoplasmosis of the brain has been on the AIDS-defining list since 1987 — that is, category C.",
  "Pneumocystis pneumonia has likewise been on the list from the beginning and is its most emblematic member.",
  "Pulmonary tuberculosis was added in the 1993 revision, but today it is certainly category C.",
  "WARNING, AND PERSISTENT GENERALISED LYMPHADENOPATHY IS ONE OF THE THREE MEMBERS OF CATEGORY A — so it is the only true exception.",
  "The likely origin of the key's error: in the 1987 list, pulmonary tuberculosis was NOT defining.",
  "Someone carrying that older list in mind would hunt for the exception among the respiratory options.",
  "But even on the 1987 list cerebral toxoplasmosis was category C — so the key conflicts with both editions.",
 ],
 "⚠️ **پیش از هر چیز: کلید چاپی این سؤال تصحیح شده است.**\n\n"
 "کتاب گزینه‌ی **«توکسوپلاسموز مغزی»** را به‌عنوان موردی که **منطبق بر گروه C نیست** انتخاب "
 "کرده بود. این انتخاب با **هر دو نسخه‌ی تعریف CDC** ناسازگار است و کلید به **«لنفادنوپاتی "
 "جنرالیزه دائمی»** اصلاح شد.\n\n"
 "**چرا این سؤال یک پاسخ قطعی و قابل استناد دارد؟** چون گروه‌های A، B و C موضوع سلیقه‌ی "
 "بالینی نیستند — یک **فهرست منتشرشده** هستند: **طبقه‌بندی بازنگری‌شده‌ی CDC، ۱۹۹۳** "
 "(MMWR 1992;41(RR-17))، که در بازنگری ۲۰۰۸ عیناً تکرار شد.\n\n"
 "⚠️ **گروه A دقیقاً و فقط سه چیز است:**\n\n"
 "**۱)** عفونت HIV **بدون علامت**\n\n"
 "**۲) لنفادنوپاتی ژنرالیزه‌ی پایدار (PGL)**\n\n"
 "**۳)** عفونت **حاد (اولیه‌ی)** HIV\n\n"
 "**و گروه C همان فهرست تعریف‌کننده‌ی ایدز است**، که در متن CDC این سه مورد را با همین "
 "نام‌ها دارد:\n\n"
 "**«توکسوپلاسموز مغز»** · **«پنومونی پنوموسیستیس»** · **«مایکوباکتریوم توبرکلوزیس، هر "
 "محل (ریوی یا خارج‌ریوی)»**\n\n"
 "**پس سه گزینه از چهار گزینه — از جمله گزینه‌ای که کتاب کلید کرده — گروه C هستند، و تنها "
 "استثنا لنفادنوپاتی ژنرالیزه‌ی دائمی است.**\n\n"
 "**ریشه‌ی احتمالی خطا کجاست؟** در تعریف **۱۹۸۷**، **سل ریوی جزو موارد تعریف‌کننده نبود** و "
 "در بازنگری **۱۹۹۳** به‌همراه «پنومونی راجعه» و «کانسر مهاجم سرویکس» اضافه شد. کسی که "
 "فهرست پیش از ۱۹۹۳ را در ذهن داشته باشد، دنبال استثنا **میان گزینه‌های ریوی** می‌گردد. "
 "⚠️ **ولی حتی در فهرست ۱۹۸۷ هم توکسوپلاسموز مغزی گروه C بود** — یعنی کلید چاپی با **هیچ "
 "نسخه‌ای** سازگار نیست، و PGL با **هر دو نسخه** استثناست.\n\n"
 "**و یک نکته‌ی مفهومی که این را ماندگار می‌کند:** PGL یعنی بزرگی غدد لنفاوی در **دو ناحیه "
 "یا بیشتر خارج از کشاله**، بیش از **سه ماه**، بدون علت دیگر. این **واکنش ایمنی فعال** بدن "
 "به ویروس است — نشانه‌ی **مقاومت** است، نه فروپاشی. به همین دلیل در گروه A جای دارد، در "
 "کنار «بدون علامت».",
 "WARNING, FIRST OF ALL: THE PRINTED KEY FOR THIS QUESTION WAS CORRECTED.\n\n"
 "The book chose CEREBRAL TOXOPLASMOSIS as the item that does NOT match category C. That choice "
 "conflicts with BOTH editions of the CDC definition, and the key was corrected to PERSISTENT "
 "GENERALISED LYMPHADENOPATHY.\n\n"
 "WHY DOES THIS QUESTION HAVE ONE VERIFIABLE ANSWER? Because categories A, B and C are not a matter "
 "of clinical taste — they are A PUBLISHED LIST: the CDC 1993 revised classification "
 "(MMWR 1992;41(RR-17)), reprinted verbatim in the 2008 revision.\n\n"
 "WARNING, CATEGORY A IS EXACTLY AND ONLY THREE THINGS:\n\n"
 "1) ASYMPTOMATIC HIV infection\n\n"
 "2) PERSISTENT GENERALISED LYMPHADENOPATHY (PGL)\n\n"
 "3) ACUTE (primary) HIV infection\n\n"
 "AND CATEGORY C IS THE AIDS-DEFINING LIST, which in the CDC text names these three by name:\n\n"
 "'TOXOPLASMOSIS OF BRAIN' · 'PNEUMOCYSTIS PNEUMONIA' · 'MYCOBACTERIUM TUBERCULOSIS, ANY SITE "
 "(pulmonary or extrapulmonary)'\n\n"
 "SO THREE OF THE FOUR OPTIONS — INCLUDING THE ONE THE BOOK KEYED — ARE CATEGORY C, AND THE ONLY "
 "EXCEPTION IS PERSISTENT GENERALISED LYMPHADENOPATHY.\n\n"
 "WHERE DOES THE ERROR PROBABLY COME FROM? In the 1987 definition PULMONARY TUBERCULOSIS WAS NOT "
 "DEFINING; it was added in the 1993 revision together with recurrent pneumonia and invasive "
 "cervical cancer. Someone carrying the pre-1993 list in mind would look for the exception AMONG "
 "THE RESPIRATORY OPTIONS. WARNING, BUT EVEN ON THE 1987 LIST CEREBRAL TOXOPLASMOSIS WAS CATEGORY C "
 "— so the printed key agrees with NO edition, while PGL is the exception under BOTH.\n\n"
 "AND A CONCEPTUAL POINT THAT MAKES THIS STICK: PGL means enlarged nodes at TWO OR MORE EXTRAINGUINAL "
 "SITES for MORE THAN THREE MONTHS with no other cause. It is the body's ACTIVE IMMUNE REACTION to "
 "the virus — a sign of RESISTANCE, not of collapse. That is why it sits in category A alongside "
 "'asymptomatic'.",
 ["کلید چاپی این گزینه بود و تصحیح شد؛ توکسوپلاسموز مغز از ۱۹۸۷ در فهرست گروه C است.",
  "پنومونی پنوموسیستیس از ابتدا در فهرست تعریف‌کننده‌ی ایدز بوده و شاخص‌ترین عضو گروه C است.",
  "سل ریوی در بازنگری ۱۹۹۳ اضافه شد و امروز قطعاً گروه C محسوب می‌شود.",
  "پاسخ صحیح (پس از اصلاح کلید) — لنفادنوپاتی ژنرالیزه‌ی پایدار یکی از سه عضو گروه A است، نه C."],
 ["This was the printed key and it was corrected; toxoplasmosis of the brain has been category C since 1987.",
  "Pneumocystis pneumonia has been on the AIDS-defining list from the start and is category C's emblem.",
  "Pulmonary tuberculosis was added in the 1993 revision and today is certainly category C.",
  "Correct (after key correction) — persistent generalised lymphadenopathy is one of the three members of category A, not C."],
 "**گروه A فقط سه چیز است: بدون علامت، PGL، و عفونت حاد. بقیه C است.**",
 "Category A is only three things: asymptomatic, PGL, and acute infection. The rest here is C.",
 [CDC93, CDC08, H202])


# =========================================================== book:663
add("book:663", "recall", "medium",
 "**سل ریوی** از بازنگری ۱۹۹۳ تعریف‌کننده‌ی ایدز است — سل در HIV در هر محل، گروه C.",
 "PULMONARY TUBERCULOSIS has been AIDS-defining since the 1993 revision — TB at any site in HIV is category C.",
 STAGE_FA + [
  "**این سؤال دقیقاً همان افزوده‌ی ۱۹۹۳ را می‌آزماید که منشأ خطای سؤال قبلی بود.**",
  "⚠️ **مایکوباکتریوم توبرکلوزیس در HIV، در هر محل — ریوی یا خارج‌ریوی — گروه C است.**",
  "**دلیل افزودنش: پیوند اپیدمیولوژیک بسیار قوی میان HIV و فعال شدن سل.**",
  "**در فرد HIV مثبت، خطر فعال شدن سل نهفته از حدود ۱۰ درصد در تمام عمر به حدود ۱۰ درصد در سال می‌رسد.**",
  "**و سل در HIV در هر CD4 رخ می‌دهد، حتی بالای ۵۰۰ — برخلاف بیشتر عفونت‌های فرصت‌طلب.**",
  "**پس سل شایع‌ترین عفونت هم‌زمان و شایع‌ترین علت مرگ در HIV در سطح جهان است.**",
 ],
 STAGE_EN + [
  "This question tests exactly the 1993 addition that caused the error in the previous item.",
  "WARNING: M. TUBERCULOSIS IN HIV, AT ANY SITE — pulmonary or extrapulmonary — IS CATEGORY C.",
  "The reason for adding it: the very strong epidemiological link between HIV and reactivation of TB.",
  "In an HIV-positive person the risk of reactivating latent TB rises from about 10 per cent per LIFETIME to about 10 per cent per YEAR.",
  "And TB in HIV occurs at ANY CD4 count, even above 500 — unlike most opportunistic infections.",
  "So TB is the commonest coinfection and the commonest cause of death in HIV worldwide.",
 ],
 "این سؤال **دقیقاً همان افزوده‌ی ۱۹۹۳** را می‌آزماید که منشأ خطای کلید در سؤال قبلی بود — "
 "و همین آن را به یک جفت آموزشی عالی تبدیل می‌کند.\n\n"
 "⚠️ **سل ریوی در فرد HIV مثبت، معیار پیشنهادکننده‌ی مرحله‌ی AIDS است.**\n\n"
 "**در متن CDC چنین آمده است: «مایکوباکتریوم توبرکلوزیس، هر محل (ریوی یا خارج‌ریوی)».** "
 "یعنی برخلاف بسیاری از عفونت‌ها که فقط شکل **منتشر** یا **خارج‌ریوی** آن‌ها تعریف‌کننده "
 "است (مثل MAC یا هیستوپلاسموز)، در مورد سل **هر محلی** کافی است.\n\n"
 "**چرا CDC آن را در ۱۹۹۳ اضافه کرد؟** به‌خاطر **پیوند اپیدمیولوژیک بسیار قوی**:\n\n"
 "**در فرد سالم، خطر فعال شدن سل نهفته حدود ۱۰ درصد در کل عمر است.**\n\n"
 "⚠️ **در فرد HIV مثبت، همین خطر به حدود ۱۰ درصد در سال می‌رسد** — یعنی تقریباً "
 "**صدبرابر**.\n\n"
 "**و یک تفاوت مهم با بقیه‌ی عفونت‌های فرصت‌طلب:** بیشتر آن‌ها منتظر می‌مانند تا CD4 به "
 "آستانه‌ی مشخصی برسد (PCP زیر ۲۰۰، توکسو زیر ۱۰۰، MAC زیر ۵۰). **ولی سل در هر شمارش "
 "CD4 رخ می‌دهد، حتی بالای ۵۰۰.** به همین دلیل سل **شایع‌ترین عفونت هم‌زمان** و "
 "**شایع‌ترین علت مرگ** در HIV در سطح جهان است.\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**کنسر پستان** — در فهرست تعریف‌کننده نیست. تنها بدخیمی‌های فهرست: **سارکوم کاپوزی**، "
 "**لنفوم‌های خاص** (مغزی اولیه، بورکیت، ایمونوبلاستیک)، و **کانسر مهاجم سرویکس**.\n\n"
 "**لوکمی لنفوسیتیک** — بدخیمی خونی است ولی در فهرست ایدز نیست.\n\n"
 "**پنومونی پنوموکوکی** — ⚠️ و این ظریف‌ترین گزینه است: **یک اپیزود** پنومونی پنوموکوکی "
 "تعریف‌کننده **نیست**؛ **دو اپیزود یا بیشتر در ۱۲ ماه** (پنومونی راجعه) هست. **تعداد، "
 "تفاوت را می‌سازد.**",
 "This question tests EXACTLY THE 1993 ADDITION that caused the key error in the previous item — "
 "which makes the two an excellent teaching pair.\n\n"
 "WARNING: PULMONARY TUBERCULOSIS IN AN HIV-POSITIVE PERSON IS AN AIDS-STAGE CRITERION.\n\n"
 "The CDC text reads: 'MYCOBACTERIUM TUBERCULOSIS, ANY SITE (pulmonary or extrapulmonary)'. So "
 "unlike many infections where only the DISSEMINATED or EXTRAPULMONARY form is defining (MAC, "
 "histoplasmosis), for TB ANY SITE suffices.\n\n"
 "WHY DID THE CDC ADD IT IN 1993? Because of the VERY STRONG EPIDEMIOLOGICAL LINK:\n\n"
 "In a healthy person the risk of reactivating latent TB is about 10 per cent over a LIFETIME.\n\n"
 "WARNING: IN AN HIV-POSITIVE PERSON THAT SAME RISK BECOMES ABOUT 10 PER CENT PER YEAR — roughly a "
 "HUNDREDFOLD increase.\n\n"
 "AND AN IMPORTANT DIFFERENCE FROM THE OTHER OPPORTUNISTIC INFECTIONS: most of them wait until the "
 "CD4 falls to a defined threshold (PCP below 200, toxoplasma below 100, MAC below 50). BUT TB "
 "OCCURS AT ANY CD4 COUNT, EVEN ABOVE 500. That is why TB is the COMMONEST COINFECTION and the "
 "COMMONEST CAUSE OF DEATH in HIV worldwide.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "BREAST CANCER — not on the defining list. The only malignancies on it are KAPOSI SARCOMA, "
 "SPECIFIC LYMPHOMAS (primary cerebral, Burkitt, immunoblastic) and INVASIVE CERVICAL CANCER.\n\n"
 "LYMPHOCYTIC LEUKAEMIA — a haematological malignancy, but not on the AIDS list.\n\n"
 "PNEUMOCOCCAL PNEUMONIA — WARNING, the subtlest option: a SINGLE episode is NOT defining; TWO OR "
 "MORE IN 12 MONTHS (recurrent pneumonia) is. THE COUNT MAKES THE DIFFERENCE.",
 ["پاسخ صحیح — سل ریوی از بازنگری ۱۹۹۳ تعریف‌کننده‌ی ایدز است؛ سل در HIV در هر محل گروه C است.",
  "کنسر پستان در فهرست بدخیمی‌های تعریف‌کننده‌ی ایدز نیست.",
  "لوکمی لنفوسیتیک بدخیمی خونی است ولی در فهرست ایدز جای ندارد.",
  "یک اپیزود پنومونی پنوموکوکی تعریف‌کننده نیست؛ دو اپیزود یا بیشتر در ۱۲ ماه هست."],
 ["Correct — pulmonary TB has been AIDS-defining since the 1993 revision; TB at any site in HIV is category C.",
  "Breast cancer is not among the AIDS-defining malignancies.",
  "Lymphocytic leukaemia is a haematological malignancy but is not on the AIDS list.",
  "A single episode of pneumococcal pneumonia is not defining; two or more in 12 months is."],
 "**سل در HIV در هر محل و هر CD4 — گروه C و شایع‌ترین علت مرگ در جهان.**",
 "TB in HIV, at any site and any CD4 count, is category C and the commonest cause of death worldwide.",
 [CDC93, CDC08, H202])


# =========================================================== book:664
add("book:664", "recall", "medium",
 "**لکوپلاکی مویی دهانی** گروه **B** است، نه C — تنها گزینه‌ای که تعریف‌کننده‌ی ایدز نیست.",
 "ORAL HAIRY LEUCOPLAKIA is category B, not C — the only option here that is not AIDS-defining.",
 STAGE_FA + [
  "**سؤال دنبال موردی می‌گردد که تعریف‌کننده‌ی ایدز نباشد، و سه گزینه‌ی دیگر همگی گروه C هستند.**",
  "⚠️ **لکوپلاکی مویی دهانی نمونه‌ی کلاسیک گروه B است: علامت‌دار، ولی نه تعریف‌کننده.**",
  "**ضایعه‌ای سفید و مخملی روی کناره‌ی زبان که با تراشیدن پاک نمی‌شود.**",
  "**عاملش ویروس اپشتین-بار است و در نقص ایمنی سلولی ظاهر می‌شود.**",
  "**درست مثل برفک دهانی که آن هم گروه B است، در حالی که کاندیدیازیس مری گروه C است.**",
  "⚠️ **قاعده‌ی طلایی دهان: هرچه در دهان بماند گروه B؛ هرچه از مری پایین‌تر برود گروه C.**",
 ],
 STAGE_EN + [
  "The stem seeks the item that is NOT AIDS-defining, and the other three options are all category C.",
  "WARNING: ORAL HAIRY LEUCOPLAKIA IS THE CLASSIC EXAMPLE OF CATEGORY B — symptomatic, but not defining.",
  "A white, velvety lesion on the lateral tongue that cannot be scraped off.",
  "It is caused by Epstein-Barr virus and appears with cellular immune deficiency.",
  "Just like oral thrush, which is also category B, whereas oesophageal candidiasis is category C.",
  "WARNING, THE GOLDEN ORAL RULE: what stays IN THE MOUTH is category B; what goes DOWN THE OESOPHAGUS is category C.",
 ],
 "سؤال دنبال موردی می‌گردد که **معرف مرحله‌ی ایدز نباشد**. سه گزینه‌ی دیگر همگی در فهرست "
 "گروه C هستند.\n\n"
 "⚠️ **پاسخ: لکوپلاکی مویی دهانی — نمونه‌ی کلاسیک گروه B.**\n\n"
 "**لکوپلاکی مویی دهانی چیست؟** ضایعه‌ای **سفید و مخملی** با سطح موج‌دار (به همین دلیل "
 "«مویی» نامیده می‌شود) روی **کناره‌ی زبان**، که **با تراشیدن پاک نمی‌شود** — و همین آن "
 "را از **برفک** جدا می‌کند که پاک می‌شود.\n\n"
 "**عاملش ویروس اپشتین-بار است** و نشانه‌ی نقص ایمنی سلولی است. یعنی **بی‌معنی نیست** — "
 "نشانه‌ی پیشرفت بیماری است — ولی در فهرست **گروه B** جای دارد، همان گروهی که «نه بی‌علامت "
 "است و نه تعریف‌کننده‌ی ایدز».\n\n"
 "⚠️ **و اینجا قاعده‌ی طلایی دهان را یاد بگیرید، چون این فصل چند بار روی آن سؤال دارد:**\n\n"
 "> **هرچه در دهان بماند، گروه B است. هرچه از مری پایین‌تر برود، گروه C است.**\n\n"
 "**برفک دهانی (کاندیدیازیس دهانی) → گروه B**\n\n"
 "**لکوپلاکی مویی دهانی → گروه B**\n\n"
 "**کاندیدیازیس مری، نای یا برونش → گروه C**\n\n"
 "**و چرا سه گزینه‌ی دیگر گروه C هستند؟**\n\n"
 "**کاندیدیازیس ازوفاژیال** — درست طبق همان قاعده: از دهان پایین‌تر رفته، پس گروه C.\n\n"
 "**انسفالیت توکسوپلاسمایی** — «توکسوپلاسموز مغز» با همین نام در فهرست است.\n\n"
 "**پنومونی ریکارنت** — «پنومونی باکتریال راجعه، دو بار یا بیشتر در ۱۲ ماه»، افزوده‌ی ۱۹۹۳.",
 "The stem looks for the item that is NOT an AIDS-stage marker. The other three are all on the "
 "category C list.\n\n"
 "WARNING, THE ANSWER: ORAL HAIRY LEUCOPLAKIA — the classic example of category B.\n\n"
 "WHAT IS ORAL HAIRY LEUCOPLAKIA? A WHITE, VELVETY lesion with a corrugated surface (hence 'hairy') "
 "on the LATERAL TONGUE, which CANNOT BE SCRAPED OFF — and that is what separates it from THRUSH, "
 "which can.\n\n"
 "IT IS CAUSED BY EPSTEIN-BARR VIRUS and signals cellular immune deficiency. So it is NOT MEANINGLESS "
 "— it marks disease progression — but it sits in CATEGORY B, the group that is 'neither "
 "asymptomatic nor AIDS-defining'.\n\n"
 "WARNING, AND LEARN THE GOLDEN ORAL RULE HERE, because this chapter asks about it repeatedly:\n\n"
 "> WHAT STAYS IN THE MOUTH IS CATEGORY B. WHAT GOES DOWN THE OESOPHAGUS IS CATEGORY C.\n\n"
 "ORAL THRUSH (oral candidiasis) -> CATEGORY B\n\n"
 "ORAL HAIRY LEUCOPLAKIA -> CATEGORY B\n\n"
 "CANDIDIASIS OF OESOPHAGUS, TRACHEA OR BRONCHI -> CATEGORY C\n\n"
 "AND WHY ARE THE OTHER THREE CATEGORY C?\n\n"
 "OESOPHAGEAL CANDIDIASIS — exactly by that rule: it has gone below the mouth, so category C.\n\n"
 "TOXOPLASMIC ENCEPHALITIS — 'toxoplasmosis of brain' appears on the list under that very name.\n\n"
 "RECURRENT PNEUMONIA — 'recurrent bacterial pneumonia, two or more episodes in 12 months', the "
 "1993 addition.",
 ["کاندیدیازیس مری گروه C است — طبق قاعده‌ی دهان: هرچه از مری پایین‌تر برود تعریف‌کننده است.",
  "انسفالیت توکسوپلاسمایی با نام «توکسوپلاسموز مغز» در فهرست گروه C آمده است.",
  "پنومونی راجعه (دو بار یا بیشتر در ۱۲ ماه) از افزوده‌های ۱۹۹۳ به فهرست گروه C است.",
  "پاسخ صحیح — لکوپلاکی مویی دهانی گروه B است: علامت‌دار، ولی تعریف‌کننده‌ی ایدز نیست."],
 ["Oesophageal candidiasis is category C — by the oral rule, what passes below the mouth is defining.",
  "Toxoplasmic encephalitis appears on the category C list as 'toxoplasmosis of brain'.",
  "Recurrent pneumonia (two or more episodes in 12 months) is one of the 1993 additions to category C.",
  "Correct — oral hairy leucoplakia is category B: symptomatic, but not AIDS-defining."],
 "**قاعده‌ی دهان: هرچه در دهان بماند B؛ هرچه از مری پایین‌تر برود C.**",
 "The oral rule: what stays in the mouth is B; what goes below the oesophagus is C.",
 [CDC93, CDC08, H202])


# =========================================================== book:665
add("book:665", "recall", "medium",
 "**یک** اپیزود پنومونی پنوموکوکی تعریف‌کننده نیست — **دو** بار در ۱۲ ماه هست.",
 "A SINGLE episode of pneumococcal pneumonia is not defining — TWO in 12 months is.",
 STAGE_FA + [
  "**سه گزینه‌ی دیگر — کاپوزی، کاندیدیاز مری و کانسر مهاجم سرویکس — همگی گروه C هستند.**",
  "⚠️ **و تنها گزینه‌ای که به‌تنهایی تعریف‌کننده نیست، پنومونی پنوموکوکی است.**",
  "**چون فهرست CDC می‌گوید «پنومونی راجعه»، یعنی دو اپیزود یا بیشتر در ۱۲ ماه.**",
  "**سارکوم کاپوزی مرتبط با هرپس‌ویروس انسانی نوع ۸ است و شاخص‌ترین بدخیمی ایدز.**",
  "**و کانسر سرویکس فقط در فرم مهاجم تعریف‌کننده است؛ دیسپلازی و CIN نه.**",
  "⚠️ **الگوی مشترک این سه استثنا را ببینید: دهان در برابر مری، یک‌بار در برابر دوبار، دیسپلازی در برابر تهاجم.**",
  "**فهرست CDC همیشه یک قید دارد — و سؤال‌ها دقیقاً روی همان قید ساخته می‌شوند.**",
 ],
 STAGE_EN + [
  "The other three — Kaposi sarcoma, oesophageal candidiasis and invasive cervical cancer — are all category C.",
  "WARNING, AND THE ONLY OPTION THAT IS NOT DEFINING ON ITS OWN IS PNEUMOCOCCAL PNEUMONIA.",
  "Because the CDC list says 'RECURRENT pneumonia', meaning two or more episodes in 12 months.",
  "Kaposi sarcoma is linked to human herpesvirus 8 and is the emblematic AIDS malignancy.",
  "And cervical cancer is defining only in its INVASIVE form; dysplasia and CIN are not.",
  "WARNING, SEE THE SHARED PATTERN OF THESE THREE EXCEPTIONS: mouth versus oesophagus, once versus twice, dysplasia versus invasion.",
  "The CDC list always carries a qualifier — and the questions are built precisely on that qualifier.",
 ],
 "سؤال می‌پرسد کدام مورد **به تظاهرات بیماری ایدز مربوط نمی‌شود**.\n\n"
 "⚠️ **پاسخ: پنومونی پنوموکوکی — چون یک اپیزود به‌تنهایی تعریف‌کننده نیست.**\n\n"
 "**متن CDC می‌گوید: «پنومونی، راجعه» — و در پانویس تعریفش می‌کند: دو اپیزود یا بیشتر در "
 "۱۲ ماه.** پس **یک** اپیزود پنومونی پنوموکوکی — که در جمعیت عمومی هم شایع است — "
 "تعریف‌کننده‌ی ایدز **نیست**.\n\n"
 "**و سه گزینه‌ی دیگر همگی گروه C هستند:**\n\n"
 "**سارکوم کاپوزی** — شاخص‌ترین بدخیمی ایدز، مرتبط با **هرپس‌ویروس انسانی نوع ۸**. "
 "ضایعات بنفش تا قهوه‌ای روی پوست، مخاط دهان، و گاهی احشاء.\n\n"
 "**کاندیدیاز مری** — طبق قاعده‌ی دهان: از مری پایین‌تر رفته، پس گروه C. تابلوی بالینی‌اش "
 "**اودینوفاژی** (درد هنگام بلع) در بیمار با برفک دهانی است.\n\n"
 "**کانسر مهاجم سرویکس** — افزوده‌ی ۱۹۹۳، مرتبط با HPV. ⚠️ **و قید «مهاجم» مهم است**: "
 "دیسپلازی سرویکس و CIN تعریف‌کننده نیستند، فقط **کارسینومای مهاجم**.\n\n"
 "⚠️ **و حالا الگوی مشترک را ببینید — این ارزشمندترین درس این سه سؤال پشت‌سرهم است:**\n\n"
 "**فهرست CDC تقریباً همیشه یک قید دارد، و سؤال‌ها دقیقاً روی همان قید ساخته می‌شوند:**\n\n"
 "**کاندیدیازیس: دهان (B) در برابر مری (C)**\n\n"
 "**پنومونی: یک بار (نه) در برابر دو بار در سال (بله)**\n\n"
 "**سرویکس: دیسپلازی (نه) در برابر مهاجم (بله)**\n\n"
 "**سل: تنها موردی که قید ندارد — «هر محل».**\n\n"
 "**اگر این چهار قید را حفظ کنید، عملاً تمام سؤال‌های مرحله‌بندی این فصل را می‌زنید.**",
 "The stem asks which item is NOT related to the manifestations of AIDS.\n\n"
 "WARNING, THE ANSWER: PNEUMOCOCCAL PNEUMONIA — because a single episode is not defining.\n\n"
 "The CDC text says 'PNEUMONIA, RECURRENT' and defines it in a footnote: two or more episodes in 12 "
 "months. So ONE episode of pneumococcal pneumonia — common in the general population too — is NOT "
 "AIDS-defining.\n\n"
 "AND THE OTHER THREE ARE ALL CATEGORY C:\n\n"
 "KAPOSI SARCOMA — the emblematic AIDS malignancy, linked to HUMAN HERPESVIRUS 8. Purple to brown "
 "lesions on skin, oral mucosa and sometimes viscera.\n\n"
 "OESOPHAGEAL CANDIDIASIS — by the oral rule: below the mouth, therefore category C. It presents as "
 "ODYNOPHAGIA (pain on swallowing) in a patient with oral thrush.\n\n"
 "INVASIVE CERVICAL CANCER — a 1993 addition, HPV-related. WARNING, THE WORD 'INVASIVE' MATTERS: "
 "cervical dysplasia and CIN are not defining, only INVASIVE CARCINOMA.\n\n"
 "WARNING, AND NOW SEE THE SHARED PATTERN — the most valuable lesson of these three consecutive "
 "questions:\n\n"
 "THE CDC LIST ALMOST ALWAYS CARRIES A QUALIFIER, AND THE QUESTIONS ARE BUILT ON THAT QUALIFIER:\n\n"
 "CANDIDIASIS: mouth (B) versus oesophagus (C)\n\n"
 "PNEUMONIA: once (no) versus twice in a year (yes)\n\n"
 "CERVIX: dysplasia (no) versus invasive (yes)\n\n"
 "TUBERCULOSIS: the only entry with NO qualifier — 'any site'.\n\n"
 "MEMORISE THOSE FOUR QUALIFIERS AND YOU WILL ANSWER VIRTUALLY EVERY STAGING QUESTION IN THIS CHAPTER.",
 ["سارکوم کاپوزی شاخص‌ترین بدخیمی تعریف‌کننده‌ی ایدز و مرتبط با هرپس‌ویروس انسانی نوع ۸ است.",
  "کاندیدیاز مری طبق قاعده‌ی دهان گروه C است، چون از مری پایین‌تر رفته است.",
  "پاسخ صحیح — یک اپیزود پنومونی پنوموکوکی تعریف‌کننده نیست؛ فهرست CDC «پنومونی راجعه» می‌گوید.",
  "کانسر مهاجم سرویکس از افزوده‌های ۱۹۹۳ و در فهرست گروه C است."],
 ["Kaposi sarcoma is the emblematic AIDS-defining malignancy, linked to human herpesvirus 8.",
  "Oesophageal candidiasis is category C by the oral rule, since it lies below the mouth.",
  "Correct — a single episode of pneumococcal pneumonia is not defining; the CDC list says 'recurrent pneumonia'.",
  "Invasive cervical cancer is one of the 1993 additions and is on the category C list."],
 "**قیدها را حفظ کنید: مری نه دهان، دو بار نه یک بار، مهاجم نه دیسپلازی، و سل در هر محل.**",
 "Memorise the qualifiers: oesophagus not mouth, twice not once, invasive not dysplasia, and TB at any site.",
 [CDC93, CDC08, H202])


# =========================================================== book:666
add("book:666", "recall", "easy",
 "دوباره **لکوپلاکی مویی دهانی** — گروه B، و این سؤال عملاً تکرار همان مفهوم با گزینه‌های دیگر است.",
 "Again ORAL HAIRY LEUCOPLAKIA — category B, and this item is effectively the same concept with different distractors.",
 STAGE_FA + [
  "**این سؤال همان مفهوم سؤال پیشین را با گزینه‌های متفاوت تکرار می‌کند.**",
  "⚠️ **و تکرارش تصادفی نیست: طراحان می‌دانند دانشجو لکوپلاکی مویی را با کاندیدیازیس مری قاطی می‌کند.**",
  "**رتینیت CMV یکی از اعضای گروه C است و در CD4 زیر ۵۰ ظاهر می‌شود.**",
  "**تابلویش کاهش بینایی بدون درد و تصویر «پنیر و کچاپ» در فوندوسکوپی است.**",
  "**و درمانش گان‌سیکلوویر یا والگان‌سیکلوویر است، نه آسیکلوویر.**",
  "**لکوپلاکی مویی در مقابل، هیچ درمان اختصاصی لازم ندارد و با شروع ART خودبه‌خود بهبود می‌یابد.**",
 ],
 STAGE_EN + [
  "This item repeats the previous concept with different distractors.",
  "WARNING, AND THE REPETITION IS NOT ACCIDENTAL: examiners know students confuse hairy leucoplakia with oesophageal candidiasis.",
  "CMV retinitis is a category C member and appears at CD4 below 50.",
  "It presents as painless visual loss with a 'cheese and ketchup' fundus.",
  "And it is treated with ganciclovir or valganciclovir, not aciclovir.",
  "Oral hairy leucoplakia, by contrast, needs no specific treatment and resolves on its own once ART begins.",
 ],
 "این سؤال **همان مفهوم سؤال پیشین** را با گزینه‌های متفاوت تکرار می‌کند، و پاسخ باز هم "
 "**لکوپلاکی مویی دهانی** است.\n\n"
 "⚠️ **تکرار این مفهوم در دو سیتینگ مختلف تصادفی نیست.** طراحان می‌دانند که دانشجو "
 "**لکوپلاکی مویی دهانی** را با **کاندیدیازیس مری** قاطی می‌کند — چون هر دو ضایعه‌ی سفید "
 "مخاطی‌اند، هر دو نشانه‌ی نقص ایمنی‌اند، ولی **یکی گروه B و دیگری گروه C است**.\n\n"
 "**قاعده‌ی دهان را دوباره مرور کنید:**\n\n"
 "> **هرچه در دهان بماند گروه B؛ هرچه از مری پایین‌تر برود گروه C.**\n\n"
 "**و سه گزینه‌ی دیگر همگی گروه C هستند:**\n\n"
 "**کاندیدیازیس ازوفاژیال** — از دهان پایین‌تر رفته.\n\n"
 "**سل ریوی** — افزوده‌ی ۱۹۹۳، «هر محل».\n\n"
 "**رتینیت CMV** — ⚠️ این را جداگانه بشناسید چون ویژگی‌های بالینی مهمی دارد:\n\n"
 "**آستانه‌ی CD4 آن زیر ۵۰ است** — یعنی نشانه‌ی ایمنی بسیار سرکوب‌شده.\n\n"
 "**تابلویش کاهش بینایی بدون درد** است — گاهی با «مگس پران» شروع می‌شود.\n\n"
 "**در فوندوسکوپی تصویر کلاسیک «پنیر و کچاپ»** دیده می‌شود: نواحی سفید نکروز رتین در کنار "
 "خونریزی‌های قرمز.\n\n"
 "**درمانش گان‌سیکلوویر یا والگان‌سیکلوویر است، نه آسیکلوویر** — و این نکته‌ای است که در "
 "سؤال‌های درمانی دیگر هم به کار می‌آید.\n\n"
 "**و در مقابل، لکوپلاکی مویی دهانی هیچ درمان اختصاصی لازم ندارد** و با شروع درمان "
 "ضدرتروویروسی و بازسازی ایمنی، خودبه‌خود برطرف می‌شود.",
 "This item repeats THE SAME CONCEPT as the previous question with different distractors, and the "
 "answer is again ORAL HAIRY LEUCOPLAKIA.\n\n"
 "WARNING: THE REPETITION ACROSS TWO SITTINGS IS NOT ACCIDENTAL. Examiners know students confuse "
 "ORAL HAIRY LEUCOPLAKIA with OESOPHAGEAL CANDIDIASIS — both are white mucosal lesions, both signal "
 "immune deficiency, but ONE IS CATEGORY B AND THE OTHER CATEGORY C.\n\n"
 "REVIEW THE ORAL RULE AGAIN:\n\n"
 "> WHAT STAYS IN THE MOUTH IS CATEGORY B; WHAT GOES BELOW THE OESOPHAGUS IS CATEGORY C.\n\n"
 "AND THE OTHER THREE OPTIONS ARE ALL CATEGORY C:\n\n"
 "OESOPHAGEAL CANDIDIASIS — below the mouth.\n\n"
 "PULMONARY TUBERCULOSIS — the 1993 addition, 'any site'.\n\n"
 "CMV RETINITIS — WARNING, learn this one separately because it has important clinical features:\n\n"
 "ITS CD4 THRESHOLD IS BELOW 50 — a marker of profound immunosuppression.\n\n"
 "IT PRESENTS AS PAINLESS VISUAL LOSS, sometimes beginning with floaters.\n\n"
 "FUNDOSCOPY SHOWS THE CLASSIC 'CHEESE AND KETCHUP' APPEARANCE: white areas of retinal necrosis "
 "beside red haemorrhages.\n\n"
 "IT IS TREATED WITH GANCICLOVIR OR VALGANCICLOVIR, NOT ACICLOVIR — a point that recurs in the "
 "treatment questions.\n\n"
 "BY CONTRAST ORAL HAIRY LEUCOPLAKIA NEEDS NO SPECIFIC TREATMENT and resolves by itself once "
 "antiretroviral therapy restores immunity.",
 ["کاندیدیازیس مری از دهان پایین‌تر رفته است و طبق قاعده‌ی دهان گروه C محسوب می‌شود.",
  "سل ریوی از بازنگری ۱۹۹۳ در فهرست گروه C است — سل در HIV در هر محل تعریف‌کننده است.",
  "رتینیت CMV گروه C است و در CD4 زیر ۵۰ با کاهش بینایی بدون درد ظاهر می‌شود.",
  "پاسخ صحیح — لکوپلاکی مویی دهانی گروه B است و تعریف‌کننده‌ی ایدز نیست."],
 ["Oesophageal candidiasis lies below the mouth and is category C by the oral rule.",
  "Pulmonary TB has been on the category C list since 1993 — TB at any site in HIV is defining.",
  "CMV retinitis is category C and appears at CD4 below 50 with painless visual loss.",
  "Correct — oral hairy leucoplakia is category B and is not AIDS-defining."],
 "**لکوپلاکی مویی دهانی = گروه B. رتینیت CMV = گروه C در CD4 زیر ۵۰.**",
 "Oral hairy leucoplakia is category B; CMV retinitis is category C at CD4 below 50.",
 [CDC93, CDC08, H202])


# =========================================================== book:667
add("book:667", "case", "medium",
 "پنومونی مزمن **بدون اپیزود قبلی** ← استرپتوکوک پنومونیه بیمار را در مرحله‌ی AIDS قرار **نمی‌دهد**.",
 "A chronic pneumonia with NO previous episode: Streptococcus pneumoniae would NOT place this patient at AIDS stage.",
 STAGE_FA + [
  "**این سؤال قاعده‌ی «پنومونی راجعه» را در قالب یک سناریوی بالینی می‌آزماید.**",
  "⚠️ **جمله‌ی کلیدی سؤال: «سابقه‌ی اپیزود قبلی از عفونت ریوی را ذکر نمی‌کند».**",
  "**این جمله عمداً آمده تا شرط «دو بار در ۱۲ ماه» را نقض کند.**",
  "**پس اگر عامل، پنوموکوک باشد، این اولین اپیزود است و تعریف‌کننده نیست.**",
  "**ولی سه عامل دیگر با یک اپیزود هم تعریف‌کننده‌اند.**",
  "**مایکوباکتریوم توبرکلوزیس در هر محل، MAC منتشر یا خارج‌ریوی، و پنوموسیستیس.**",
  "⚠️ **و در عمل، این بیمار با کاشکسی و برفک دهانی از قبل هم در مرحله‌ی پیشرفته است.**",
 ],
 STAGE_EN + [
  "This question tests the 'recurrent pneumonia' rule inside a clinical vignette.",
  "WARNING, THE KEY SENTENCE: 'he reports no previous episode of pulmonary infection'.",
  "That sentence is there deliberately to break the 'two episodes in 12 months' condition.",
  "So if the organism is pneumococcus, this is a FIRST episode and is not defining.",
  "But the other three organisms are defining even with a single episode.",
  "M. tuberculosis at any site, disseminated or extrapulmonary MAC, and Pneumocystis.",
  "WARNING, AND IN PRACTICE this patient, with cachexia and oral thrush, is already at an advanced stage.",
 ],
 "این سؤال **قاعده‌ی پنومونی راجعه** را در قالب یک سناریوی بالینی می‌آزماید، و یک جمله در "
 "متن سؤال، کل پاسخ را تعیین می‌کند.\n\n"
 "**بیمار: آقای ۳۸ ساله HIV مثبت، با کاشکسی مفرط و کاندیدیازیس دهانی، با تشخیص پنومونی "
 "مزمن از ۳ هفته قبل بستری شده.**\n\n"
 "⚠️ **جمله‌ی کلیدی: «سابقه‌ی اپیزود قبلی از عفونت ریوی را ذکر نمی‌کند».**\n\n"
 "**این جمله تصادفی نیست.** طراح آن را گذاشته تا شرط **«دو اپیزود یا بیشتر در ۱۲ ماه»** "
 "را صریحاً نقض کند.\n\n"
 "**پس اگر عامل بیماری استرپتوکوک پنومونیه باشد، این اولین اپیزود است، و یک اپیزود "
 "پنومونی پنوموکوکی بیمار را در مرحله‌ی AIDS قرار نمی‌دهد.**\n\n"
 "**و چرا سه عامل دیگر قرار می‌دهند؟**\n\n"
 "**مایکوباکتریوم توبرکلوزیس** — «هر محل، ریوی یا خارج‌ریوی». **بدون قید تعداد.**\n\n"
 "**مایکوباکتریوم آویوم کمپلکس** — در فرم **منتشر یا خارج‌ریوی** تعریف‌کننده است. ⚠️ **و "
 "این قید مهم است**: MAC صرفاً ریوی در فرد غیرHIV (مثلاً در بیمار COPD) تعریف‌کننده نیست؛ "
 "آنچه در ایدز دیده می‌شود شکل **منتشر** با تب، کاهش وزن و کم‌خونی است، معمولاً در CD4 "
 "زیر ۵۰.\n\n"
 "**پنوموسیستیس جیرووسی** — شاخص‌ترین عفونت تعریف‌کننده‌ی ایدز، در CD4 زیر ۲۰۰. یک اپیزود "
 "کافی است.\n\n"
 "⚠️ **و یک نکته‌ی بالینی که ورای سؤال است:** این بیمار با **کاشکسی مفرط** (که خودش "
 "می‌تواند «سندرم تحلیل‌رونده‌ی HIV» و تعریف‌کننده باشد) و **برفک دهانی** (گروه B)، از "
 "قبل هم در مرحله‌ی بسیار پیشرفته است. سؤال در واقع یک تمرین **تعریف‌شناسی** است، نه یک "
 "تصمیم بالینی.",
 "This question tests THE RECURRENT PNEUMONIA RULE inside a clinical vignette, and a single sentence "
 "in the stem determines the whole answer.\n\n"
 "THE PATIENT: a 38-year-old HIV-positive man with GROSS CACHEXIA and ORAL CANDIDIASIS, admitted "
 "three weeks ago with chronic pneumonia.\n\n"
 "WARNING, THE KEY SENTENCE: 'he reports no previous episode of pulmonary infection'.\n\n"
 "THAT SENTENCE IS NOT ACCIDENTAL. The examiner placed it to break the 'TWO OR MORE EPISODES IN 12 "
 "MONTHS' condition explicitly.\n\n"
 "SO IF THE ORGANISM IS STREPTOCOCCUS PNEUMONIAE, THIS IS A FIRST EPISODE, AND ONE EPISODE OF "
 "PNEUMOCOCCAL PNEUMONIA DOES NOT PLACE THE PATIENT AT AIDS STAGE.\n\n"
 "AND WHY DO THE OTHER THREE?\n\n"
 "MYCOBACTERIUM TUBERCULOSIS — 'any site, pulmonary or extrapulmonary'. WITH NO COUNT QUALIFIER.\n\n"
 "MYCOBACTERIUM AVIUM COMPLEX — defining in its DISSEMINATED OR EXTRAPULMONARY form. WARNING, THAT "
 "QUALIFIER MATTERS: purely pulmonary MAC in a non-HIV patient (say with COPD) is not defining; what "
 "is seen in AIDS is the DISSEMINATED form with fever, weight loss and anaemia, usually at CD4 below 50.\n\n"
 "PNEUMOCYSTIS JIROVECII — the emblematic AIDS-defining infection, at CD4 below 200. One episode "
 "suffices.\n\n"
 "WARNING, AND A CLINICAL POINT BEYOND THE QUESTION: this patient, with GROSS CACHEXIA (which can "
 "itself be 'HIV wasting syndrome' and defining) and ORAL THRUSH (category B), is already at a very "
 "advanced stage. The question is really an exercise in DEFINITIONS, not a clinical decision.",
 ["مایکوباکتریوم توبرکلوزیس در هر محل تعریف‌کننده است و نیازی به تکرار اپیزود ندارد.",
  "مایکوباکتریوم آویوم کمپلکس در فرم منتشر یا خارج‌ریوی تعریف‌کننده‌ی ایدز است.",
  "پاسخ صحیح — یک اپیزود پنومونی پنوموکوکی تعریف‌کننده نیست، و سؤال صریحاً می‌گوید اپیزود قبلی نداشته.",
  "پنوموسیستیس جیرووسی شاخص‌ترین عفونت تعریف‌کننده است و یک اپیزود آن کافی است."],
 ["M. tuberculosis at any site is defining and needs no repeat episode.",
  "Disseminated or extrapulmonary M. avium complex is AIDS-defining.",
  "Correct — a single episode of pneumococcal pneumonia is not defining, and the stem states there was no previous episode.",
  "Pneumocystis jirovecii is the emblematic defining infection and a single episode suffices."],
 "**«اپیزود قبلی ندارد» یعنی شرط پنومونی راجعه نقض شده — پس پنوموکوک تعریف‌کننده نیست.**",
 "'No previous episode' breaks the recurrent-pneumonia condition, so pneumococcus is not defining here.",
 [CDC93, CDC08, H202])


# =========================================================== book:668
add("book:668", "recall", "medium",
 "در عفونت **حاد** HIV، الایزای آنتی‌بادی هنوز می‌تواند منفی باشد — پس «با الایزا تشخیص داده می‌شود» غلط است.",
 "In ACUTE HIV infection the antibody ELISA may still be negative, so 'it is diagnosed by ELISA' is the false statement.",
 ACUTE_FA + [
  "**سؤال ساختار «همه درست است بجز» دارد و سه جمله‌ی درست را کنار یک جمله‌ی غلط گذاشته.**",
  "⚠️ **جمله‌ی غلط: «با آزمایش آنتی‌بادی HIV به روش الیزا تشخیص داده می‌شود».**",
  "**چون در عفونت حاد ممکن است هنوز آنتی‌بادی ساخته نشده باشد و تست کاذباً منفی شود.**",
  "**تب و لنفادنوپاتی از شایع‌ترین علائم این دوره‌اند و جمله‌ی درستی است.**",
  "**کاهش CD4 در این دوره واقعی و گاهی شدید است، هرچند موقتی.**",
  "⚠️ **و جمله‌ی «عفونت فرصت‌طلب رخ می‌دهد» هم درست است و بسیاری آن را غلط می‌پندارند.**",
  "**چون افت گذرای CD4 در سرکونورژن می‌تواند به‌قدری عمیق باشد که کاندیدیازیس یا حتی PCP گذرا بدهد.**",
 ],
 ACUTE_EN + [
  "The stem uses an 'all true except' structure, placing three true statements beside one false one.",
  "WARNING, THE FALSE STATEMENT: 'it is diagnosed by an HIV antibody ELISA'.",
  "Because in acute infection antibody may not yet have been made and the test can be falsely negative.",
  "Fever and lymphadenopathy are among the commonest features of this period, so that statement is true.",
  "The CD4 fall in this period is real and sometimes steep, though transient.",
  "WARNING, AND 'OPPORTUNISTIC INFECTION OCCURS' IS ALSO TRUE, though many students think it false.",
  "Because the transient CD4 drop at seroconversion can be deep enough to produce candidiasis or even transient PCP.",
 ],
 "این سؤال ساختار **«همه درست است بجز»** دارد، و هر چهار جمله را باید جداگانه بسنجید.\n\n"
 "⚠️ **جمله‌ی غلط: «با آزمایش HIV Ab به روش الیزا تشخیص داده می‌شود».**\n\n"
 "**چرا غلط است؟** چون در **عفونت حاد HIV** — یعنی ۲ تا ۶ هفته پس از تماس — **آنتی‌بادی "
 "ممکن است هنوز ساخته نشده باشد**. این همان **«دوره‌ی پنجره»** است.\n\n"
 "**ترتیب مثبت شدن نشانگرها را حفظ کنید:**\n\n"
 "**RNA ویروس: از حدود روز ۱۰**\n\n"
 "**آنتی‌ژن p24: از حدود هفته‌ی ۲**\n\n"
 "**آنتی‌بادی: از هفته‌ی ۳ تا ۱۲ (اکثریت تا ۶ هفته)**\n\n"
 "**پس یک تست آنتی‌بادیِ صرف در روزهای نخست می‌تواند کاذباً منفی باشد**، و تشخیص عفونت "
 "حاد بر عهده‌ی **بار ویروسی (RNA)** یا **آنتی‌ژن p24** یا **تست ترکیبی نسل چهارم** است.\n\n"
 "**و سه جمله‌ی دیگر چرا درست‌اند؟**\n\n"
 "**«تب و لنفادنوپاتی می‌تواند از علائم این دوره باشد»** — کاملاً درست. سندرم رتروویرال "
 "حاد یک تابلوی **شبه‌مونونوکلئوز** است: تب، گلودرد، لنفادنوپاتی منتشر، میالژی، سردرد، "
 "راش ماکولوپاپولر و زخم‌های دهانی.\n\n"
 "**«تعداد سلول‌های CD4 کاهش می‌یابد»** — درست. در فاز حاد، تکثیر انفجاری ویروس باعث "
 "**افت موقت و گاهی شدید CD4** می‌شود. سپس با پاسخ ایمنی، CD4 تا حدی برمی‌گردد و بیماری "
 "وارد فاز نهفتگی بالینی می‌شود.\n\n"
 "⚠️ **«عفونت فرصت‌طلب در این دوره رخ می‌دهد»** — و این جمله‌ای است که بسیاری از دانشجویان "
 "**به‌اشتباه غلط می‌پندارند**. ولی درست است: همان افت گذرای CD4 در سرکونورژن می‌تواند "
 "**آن‌قدر عمیق باشد** که عفونت فرصت‌طلب گذرا بدهد — موارد **کاندیدیازیس مری** و حتی "
 "**پنومونی پنوموسیستیس** در جریان عفونت حاد HIV گزارش شده است. نادر است، ولی واقعی.",
 "This stem uses an 'ALL TRUE EXCEPT' structure, and each of the four statements must be judged "
 "separately.\n\n"
 "WARNING, THE FALSE STATEMENT: 'it is diagnosed by an HIV antibody ELISA'.\n\n"
 "WHY IS IT FALSE? Because in ACUTE HIV INFECTION — 2 to 6 weeks after exposure — ANTIBODY MAY NOT "
 "YET HAVE BEEN MADE. This is the WINDOW PERIOD.\n\n"
 "MEMORISE THE ORDER IN WHICH MARKERS TURN POSITIVE:\n\n"
 "VIRAL RNA: from about day 10\n\n"
 "p24 ANTIGEN: from about week 2\n\n"
 "ANTIBODY: from week 3 to 12 (most by week 6)\n\n"
 "SO AN ANTIBODY-ONLY TEST IN THE FIRST DAYS CAN BE FALSELY NEGATIVE, and diagnosing acute infection "
 "falls to the VIRAL LOAD (RNA), the p24 ANTIGEN, or a FOURTH-GENERATION COMBINED ASSAY.\n\n"
 "AND WHY ARE THE OTHER THREE TRUE?\n\n"
 "'FEVER AND LYMPHADENOPATHY CAN BE FEATURES OF THIS PERIOD' — entirely true. Acute retroviral "
 "syndrome is a MONONUCLEOSIS-LIKE picture: fever, sore throat, generalised lymphadenopathy, "
 "myalgia, headache, maculopapular rash and oral ulcers.\n\n"
 "'THE CD4 COUNT FALLS' — true. In the acute phase explosive viral replication causes a TRANSIENT, "
 "SOMETIMES STEEP FALL IN CD4. The immune response then partly restores it and the illness enters "
 "clinical latency.\n\n"
 "WARNING: 'OPPORTUNISTIC INFECTION OCCURS IN THIS PERIOD' — and this is the statement many students "
 "WRONGLY BELIEVE TO BE FALSE. It is true: that transient CD4 drop at seroconversion can be DEEP "
 "ENOUGH to permit a transient opportunistic infection — cases of OESOPHAGEAL CANDIDIASIS and even "
 "PNEUMOCYSTIS PNEUMONIA during acute HIV infection have been reported. Rare, but real.",
 ["درست است — تب و لنفادنوپاتی منتشر از شایع‌ترین علائم سندرم رتروویرال حاد هستند.",
  "درست است — افت گذرای CD4 در سرکونورژن می‌تواند آن‌قدر عمیق باشد که عفونت فرصت‌طلب گذرا بدهد.",
  "درست است — تکثیر انفجاری ویروس در فاز حاد باعث کاهش موقت و گاهی شدید CD4 می‌شود.",
  "پاسخ صحیح (جمله‌ی نادرست) — در عفونت حاد آنتی‌بادی ممکن است هنوز ساخته نشده باشد و الایزا کاذباً منفی شود."],
 ["True — fever and generalised lymphadenopathy are among the commonest features of acute retroviral syndrome.",
  "True — the transient CD4 fall at seroconversion can be deep enough to permit a transient opportunistic infection.",
  "True — explosive viral replication in the acute phase causes a transient, sometimes steep CD4 fall.",
  "Correct (the false statement) — in acute infection antibody may not yet exist and the ELISA can be falsely negative."],
 "**در عفونت حاد، آنتی‌بادی هنوز نیست. RNA از روز ۱۰، p24 از هفته‌ی ۲، آنتی‌بادی از هفته‌ی ۳.**",
 "In acute infection antibody is not yet present: RNA from day 10, p24 from week 2, antibody from week 3.",
 [H202, CDCLAB])


# =========================================================== book:670
add("book:670", "recall", "easy",
 "پنجره‌ی آنتی‌بادی HIV: **۳ تا ۱۲ هفته** پس از آلودگی — اکثریت تا هفته‌ی ۶.",
 "The HIV antibody window is 3 TO 12 WEEKS after infection, with most seroconverting by week 6.",
 ACUTE_FA + [
  "**این سؤال مستقیماً بازه‌ی سرکونورژن آنتی‌بادی را می‌پرسد.**",
  "⚠️ **پاسخ ۳ تا ۱۲ هفته است، و هر دو کران آن معنای بالینی دارند.**",
  "**کران پایین ۳ هفته: زودترین زمانی که آنتی‌بادی قابل شناسایی می‌شود.**",
  "**کران بالا ۱۲ هفته: زمانی که عملاً همه‌ی افراد آلوده سرم‌مثبت شده‌اند.**",
  "**به همین دلیل، تست منفی در هفته‌ی ۱۲ عفونت را با اطمینان بالا رد می‌کند.**",
  "**و همین است که پایه‌ی جدول پیگیری پس از مواجهه‌ی شغلی شد.**",
 ],
 ACUTE_EN + [
  "This question asks directly for the antibody seroconversion interval.",
  "WARNING: THE ANSWER IS 3 TO 12 WEEKS, and both bounds carry clinical meaning.",
  "The lower bound of 3 weeks: the earliest antibody becomes detectable.",
  "The upper bound of 12 weeks: by then essentially everyone infected has seroconverted.",
  "That is why a negative test at week 12 excludes infection with high confidence.",
  "And that is the basis of the post-exposure follow-up schedule.",
 ],
 "این سؤال مستقیماً **پنجره‌ی سرکونورژن** را می‌پرسد و پاسخش عددی است که باید حفظ باشد.\n\n"
 "⚠️ **آنتی‌بادی ضد HIV از ۳ تا ۱۲ هفته پس از آلودگی قابل اندازه‌گیری می‌شود.**\n\n"
 "**و هر دو کران این بازه معنای بالینی دارند:**\n\n"
 "**کران پایین — ۳ هفته:** زودترین زمانی که ممکن است آنتی‌بادی به سطح قابل شناسایی برسد. "
 "**پیش از آن، تست آنتی‌بادی حتی در فرد واقعاً آلوده منفی است.**\n\n"
 "**کران بالا — ۱۲ هفته:** زمانی که **عملاً همه‌ی افراد آلوده** سرم‌مثبت شده‌اند. "
 "⚠️ **پس یک تست منفی در هفته‌ی ۱۲، عفونت را با اطمینان بسیار بالا رد می‌کند** — و همین "
 "است که پایه‌ی جدول پیگیری پس از مواجهه‌ی شغلی شد (تست پایه، ۶ هفته، ۳ ماه، ۶ ماه).\n\n"
 "**و آماری که تصویر را کامل می‌کند: اکثریت قاطع افراد تا هفته‌ی ۶ سرم‌مثبت می‌شوند.** پس "
 "بازه‌ی ۳ تا ۱۲ هفته یک **دامنه** است، نه یک توزیع یکنواخت؛ بیشتر افراد در نیمه‌ی اول "
 "آن قرار می‌گیرند.\n\n"
 "**و چرا دو گزینه‌ی دیگر نه؟**\n\n"
 "**۱ تا ۸ هفته** — کران پایین آن **خیلی زود** است. در هفته‌ی اول هیچ آنتی‌بادی وجود ندارد؛ "
 "در آن مقطع فقط **RNA** (از روز ۱۰) و **p24** (از هفته‌ی ۲) قابل شناسایی‌اند.\n\n"
 "**۲ تا ۵ هفته** — هم کران پایین آن زود است و هم **کران بالایش خطرناک کوتاه**: اگر کسی "
 "باور کند در هفته‌ی ۵ همه سرم‌مثبت شده‌اند، ممکن است یک تست منفی را **زودهنگام قطعی** "
 "بداند و بیمار واقعاً آلوده را از دست بدهد.\n\n"
 "⚠️ **و به‌روزرسانی مهم:** این ارقام مربوط به **تست‌های آنتی‌بادی** است. با **تست‌های "
 "ترکیبی نسل چهارم** (آنتی‌ژن/آنتی‌بادی) که امروز استاندارد CDC هستند، پنجره به حدود "
 "**۲ هفته** کوتاه شده و بسیاری از مراکز پیگیری را به **۴ ماه** به‌جای ۶ ماه کاهش داده‌اند.",
 "This question asks directly for the SEROCONVERSION WINDOW, and the answer is a figure to be "
 "memorised.\n\n"
 "WARNING: ANTI-HIV ANTIBODY BECOMES MEASURABLE 3 TO 12 WEEKS AFTER INFECTION.\n\n"
 "AND BOTH BOUNDS CARRY CLINICAL MEANING:\n\n"
 "THE LOWER BOUND, 3 WEEKS: the earliest antibody may reach a detectable level. BEFORE THAT, AN "
 "ANTIBODY TEST IS NEGATIVE EVEN IN A TRULY INFECTED PERSON.\n\n"
 "THE UPPER BOUND, 12 WEEKS: by then ESSENTIALLY EVERYONE INFECTED has seroconverted. WARNING, SO A "
 "NEGATIVE TEST AT WEEK 12 EXCLUDES INFECTION WITH VERY HIGH CONFIDENCE — and that is the basis of "
 "the occupational post-exposure follow-up schedule (baseline, 6 weeks, 3 months, 6 months).\n\n"
 "AND THE STATISTIC THAT COMPLETES THE PICTURE: the great majority seroconvert by week 6. So 3 to 12 "
 "weeks is a RANGE, not a uniform distribution; most people fall in its first half.\n\n"
 "AND WHY NOT THE OTHER TWO?\n\n"
 "1 TO 8 WEEKS — its lower bound is FAR TOO EARLY. In the first week there is no antibody at all; at "
 "that point only RNA (from day 10) and p24 (from week 2) are detectable.\n\n"
 "2 TO 5 WEEKS — its lower bound is too early AND ITS UPPER BOUND IS DANGEROUSLY SHORT: someone who "
 "believed everyone had seroconverted by week 5 might treat a negative test as DEFINITIVE TOO SOON "
 "and miss a truly infected patient.\n\n"
 "WARNING, AN IMPORTANT UPDATE: these figures apply to ANTIBODY tests. With FOURTH-GENERATION "
 "COMBINED assays (antigen/antibody), today's CDC standard, the window shortens to about 2 WEEKS, and "
 "many centres have reduced follow-up to 4 MONTHS instead of 6.",
 ["بازه‌ی ۱ تا ۸ هفته کران پایین بسیار زودی دارد؛ در هفته‌ی اول هیچ آنتی‌بادی وجود ندارد.",
  "بازه‌ی ۲ تا ۵ هفته هم زود شروع می‌شود و هم کران بالای خطرناک کوتاهی دارد.",
  "پاسخ صحیح — آنتی‌بادی ضد HIV از ۳ تا ۱۲ هفته پس از آلودگی قابل اندازه‌گیری می‌شود.",
  "گزینه‌ی «هیچ‌کدام» نادرست است، چون بازه‌ی ۳ تا ۱۲ هفته بازه‌ی پذیرفته‌شده است."],
 ["The 1 to 8 week range starts far too early; in the first week there is no antibody at all.",
  "The 2 to 5 week range both starts too early and has a dangerously short upper bound.",
  "Correct — anti-HIV antibody becomes measurable 3 to 12 weeks after infection.",
  "'None of the above' is wrong, because 3 to 12 weeks is the accepted interval."],
 "**پنجره‌ی آنتی‌بادی ۳ تا ۱۲ هفته؛ با تست نسل چهارم حدود ۲ هفته.**",
 "The antibody window is 3 to 12 weeks; with a fourth-generation assay it is about 2 weeks.",
 [H202, CDCLAB])


# =========================================================== book:671
add("book:671", "case", "medium",
 "زخم آفتی + متادون + دو پنومونی + برفک ← الگوی **نقص ایمنی**؛ اقدام اول **الایزای HIV**.",
 "Aphthous ulcers plus methadone plus two pneumonias plus thrush is a pattern of IMMUNODEFICIENCY; the first step is an HIV ELISA.",
 ACUTE_FA + [
  "**این سؤال یک تمرین در تشخیص الگو است، نه یک سؤال حفظی.**",
  "⚠️ **چهار سرنخ در متن پراکنده شده‌اند و باید کنار هم گذاشته شوند.**",
  "**یک: درمان نگهدارنده با متادون، یعنی سابقه‌ی اعتیاد و احتمال مصرف تزریقی در گذشته.**",
  "**دو: دو نوبت پنومونی باکتریال در ۵ سال، یعنی عفونت باکتریال مکرر.**",
  "**سه: برفک دهانی در فرد بالغ بدون آنتی‌بیوتیک یا استروئید — این هرگز طبیعی نیست.**",
  "**چهار: زخم آفتوس دهانی، که در HIV شایع و گاه اولین تظاهر است.**",
  "⚠️ **و قاعده‌ی طلایی: برفک دهانی در بالغ سالم‌نما تا خلاف آن ثابت نشود یعنی نقص ایمنی.**",
 ],
 ACUTE_EN + [
  "This question is an exercise in pattern recognition, not recall.",
  "WARNING: FOUR CLUES ARE SCATTERED THROUGH THE STEM and must be put together.",
  "One: maintenance methadone, implying addiction and possible past injecting use.",
  "Two: two episodes of bacterial pneumonia in 5 years, that is recurrent bacterial infection.",
  "Three: oral thrush in an adult on no antibiotic or steroid — that is never normal.",
  "Four: aphthous oral ulcers, common in HIV and sometimes its first manifestation.",
  "WARNING, THE GOLDEN RULE: oral thrush in an apparently healthy adult means immunodeficiency until proven otherwise.",
 ],
 "این سؤال یک تمرین **تشخیص الگو** است: چهار سرنخ در متن پراکنده شده‌اند و هیچ‌کدام "
 "به‌تنهایی تشخیصی نیست، ولی **کنار هم یک تصویر واحد می‌سازند**.\n\n"
 "**بیمار: مرد ۴۲ ساله با زخم‌های دهانی، تحت درمان با دوز نگهدارنده‌ی متادون.**\n\n"
 "⚠️ **سرنخ‌ها را کنار هم بگذارید:**\n\n"
 "**۱) متادون نگهدارنده** — یعنی **سابقه‌ی اعتیاد به مواد مخدر**، و احتمال قابل توجه "
 "**مصرف تزریقی در گذشته**. این یک عامل خطر شناخته‌شده‌ی HIV است.\n\n"
 "**۲) دو نوبت بستری به علت پنومونی باکتریال طی ۵ سال** — **عفونت باکتریال مکرر** در فرد "
 "میان‌سال بدون بیماری زمینه‌ای، غیرعادی است. (توجه: دو بار در **۵ سال** شرط «دو بار در "
 "**۱۲ ماه**» را برآورده نمی‌کند، پس این **تعریف‌کننده‌ی ایدز نیست** — ولی همچنان یک "
 "**پرچم قرمز** است.)\n\n"
 "**۳) برفک دهانی سال گذشته** — ⚠️ **و این قوی‌ترین سرنخ است.** کاندیدیازیس دهانی در "
 "**بالغ**، **بدون** مصرف آنتی‌بیوتیک وسیع‌الطیف، **بدون** کورتیکواستروئید استنشاقی، و "
 "**بدون** دیابت کنترل‌نشده، **هرگز طبیعی نیست**.\n\n"
 "**۴) زخم آفتوس دهانی فعلی** — آفت‌های راجعه و شدید در HIV شایع‌اند و گاه اولین تظاهر "
 "بالینی‌اند.\n\n"
 "⚠️ **قاعده‌ی طلایی: برفک دهانی در بالغِ ظاهراً سالم، تا خلاف آن ثابت نشود، یعنی نقص "
 "ایمنی — و در ایران شایع‌ترین علت اکتسابی نقص ایمنی سلولی، HIV است.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**ANA و anti-DNA** — بررسی **لوپوس**. لوپوس هم می‌تواند زخم دهانی بدهد، ولی معمولاً "
 "**بدون درد** است و با آرترالژی، راش پروانه‌ای و درگیری کلیه همراه است — که هیچ‌کدام "
 "اینجا نیست. ضمناً لوپوس **برفک دهانی مکرر** نمی‌دهد.\n\n"
 "**تست پاترژی** — بررسی **بیماری بهجت**. بهجت با آفت دهانی **و** آفت تناسلی **و** "
 "یووئیت مشخص می‌شود؛ اینجا فقط آفت دهانی داریم و آن **الگوی عفونی** پررنگ‌تر است.\n\n"
 "**اندازه‌گیری ایمونوگلوبولین‌های سرم** — بررسی **نقص ایمنی هومورال** (مثل CVID). این "
 "منطقی به‌نظر می‌رسد چون پنومونی مکرر می‌دهد، ولی **برفک دهانی نشانه‌ی نقص ایمنی "
 "سلولی** است نه هومورال، و در ضمن CVID معمولاً **زودتر** تشخیص داده می‌شود.",
 "This is an exercise in PATTERN RECOGNITION: four clues are scattered through the stem, none "
 "diagnostic alone, but TOGETHER THEY FORM ONE PICTURE.\n\n"
 "THE PATIENT: a 42-year-old man with oral ulcers, on maintenance methadone.\n\n"
 "WARNING, PUT THE CLUES TOGETHER:\n\n"
 "1) MAINTENANCE METHADONE — implying A HISTORY OF DRUG ADDICTION and a considerable chance of PAST "
 "INJECTING USE. That is a recognised HIV risk factor.\n\n"
 "2) TWO ADMISSIONS FOR BACTERIAL PNEUMONIA IN 5 YEARS — RECURRENT BACTERIAL INFECTION in a "
 "middle-aged man with no underlying disease is abnormal. (Note: twice in FIVE YEARS does not meet "
 "the 'twice in 12 MONTHS' condition, so this is NOT AIDS-defining — but it remains a RED FLAG.)\n\n"
 "3) ORAL THRUSH LAST YEAR — WARNING, AND THIS IS THE STRONGEST CLUE. Oral candidiasis in an ADULT, "
 "WITHOUT broad-spectrum antibiotics, WITHOUT inhaled corticosteroids and WITHOUT uncontrolled "
 "diabetes, IS NEVER NORMAL.\n\n"
 "4) CURRENT APHTHOUS ORAL ULCERS — recurrent severe aphthae are common in HIV and are sometimes its "
 "first clinical manifestation.\n\n"
 "WARNING, THE GOLDEN RULE: ORAL THRUSH IN AN APPARENTLY HEALTHY ADULT MEANS IMMUNODEFICIENCY UNTIL "
 "PROVEN OTHERWISE — and the commonest acquired cause of cellular immunodeficiency is HIV.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "ANA AND ANTI-DNA — a lupus work-up. Lupus can cause oral ulcers, but they are usually PAINLESS and "
 "come with arthralgia, a malar rash and renal involvement, none of which is present. Lupus also does "
 "not cause RECURRENT ORAL THRUSH.\n\n"
 "PATHERGY TEST — a Behcet work-up. Behcet requires oral aphthae PLUS genital aphthae PLUS uveitis; "
 "here there are only oral ulcers, and the INFECTIOUS PATTERN is far stronger.\n\n"
 "SERUM IMMUNOGLOBULINS — a humoral immunodeficiency work-up (such as CVID). It sounds plausible "
 "because of the recurrent pneumonia, but ORAL THRUSH INDICATES CELLULAR, not humoral, deficiency, "
 "and CVID is usually diagnosed earlier in life.",
 ["ANA و anti-DNA بررسی لوپوس است؛ زخم دهانی لوپوس معمولاً بدون درد است و برفک مکرر نمی‌دهد.",
  "تست پاترژی بررسی بهجت است، ولی اینجا آفت تناسلی و یووئیت وجود ندارد و الگوی عفونی غالب است.",
  "پاسخ صحیح — الگوی متادون، پنومونی مکرر و برفک دهانی، الایزای HIV را در اولویت قرار می‌دهد.",
  "ایمونوگلوبولین‌های سرم نقص ایمنی هومورال را می‌سنجند، ولی برفک نشانه‌ی نقص ایمنی سلولی است."],
 ["ANA and anti-DNA screen for lupus; lupus oral ulcers are usually painless and it does not cause recurrent thrush.",
  "The pathergy test screens for Behcet, but there are no genital aphthae or uveitis here and the infectious pattern dominates.",
  "Correct — the pattern of methadone, recurrent pneumonia and oral thrush makes an HIV ELISA the priority.",
  "Serum immunoglobulins assess humoral deficiency, but thrush indicates a cellular immune defect."],
 "**برفک دهانی در بالغ سالم‌نما = نقص ایمنی تا خلاف آن ثابت شود.**",
 "Oral thrush in an apparently healthy adult means immunodeficiency until proven otherwise.",
 [H202, CDCLAB])


# =========================================================== book:672
add("book:672", "case", "hard",
 "چهار هفته پس از تماس با تابلوی رتروویرال حاد: **الایزا (EIA)** — چون تست امروزی خودِ p24 را هم می‌بیند.",
 "Four weeks after exposure with an acute retroviral picture: the ELISA (EIA) — because a modern assay also detects p24 itself.",
 ACUTE_FA + [
  "**این سؤال در نگاه اول با سه سؤال دیگر همین فصل ناسازگار به‌نظر می‌رسد و باید حل شود.**",
  "⚠️ **سه سؤال دیگر برای بیمار مشابه، آنتی‌ژن p24 را کلید کرده‌اند؛ این یکی الایزا را.**",
  "**تناقض ظاهری با شناختن نسل تست حل می‌شود، و همین درس اصلی این سؤال است.**",
  "**تست نسل سوم فقط آنتی‌بادی را می‌بیند و در هفته‌ی چهارم ممکن است هنوز منفی باشد.**",
  "**تست نسل چهارم ترکیبی، آنتی‌ژن p24 و آنتی‌بادی را با هم می‌بیند و از هفته‌ی دوم مثبت است.**",
  "⚠️ **در هفته‌ی چهارم، اکثریت افراد از قبل سرم‌مثبت شده‌اند و تست ترکیبی قطعاً مثبت است.**",
  "**پس شروع با تست غربالگری هم درست است و هم ارزان‌تر و در دسترس‌تر.**",
  "**قاعده‌ی عملی: اگر غربالگری منفی بود ولی شک بالینی قوی ماند، آنگاه سراغ RNA بروید.**",
 ],
 ACUTE_EN + [
  "At first sight this question conflicts with three others in the same chapter, and the conflict must be resolved.",
  "WARNING: THE OTHER THREE KEY THE p24 ANTIGEN for a similar patient; this one keys the ELISA.",
  "The apparent contradiction dissolves once you know the GENERATION of the assay, and that is the real lesson here.",
  "A third-generation test sees only antibody and may still be negative at four weeks.",
  "A fourth-generation combined test sees p24 antigen AND antibody and is positive from week 2.",
  "WARNING, AT FOUR WEEKS most people have already seroconverted and a combined assay is certainly positive.",
  "So starting with the screening test is both correct and cheaper and more available.",
  "Practical rule: if screening is negative but clinical suspicion remains strong, then go to RNA.",
 ],
 "⚠️ **این سؤال در نگاه اول با سه سؤال دیگر همین فصل ناسازگار به‌نظر می‌رسد، و حل کردن این "
 "ناسازگاری، ارزشمندترین چیزی است که از این سؤال یاد می‌گیرید.**\n\n"
 "**بیمار: آقای ۲۴ ساله، ۴ هفته پس از تماس جنسی محافظت‌نشده، با گلودرد، تب بالا، "
 "لنفادنوپاتی متعدد گردنی و بدن‌درد.** این تابلوی کلاسیک **سندرم رتروویرال حاد** است.\n\n"
 "**کلید این سؤال: انجام تست الایزا (EIA).**\n\n"
 "**ولی سه سؤال دیگر همین فصل (q9686، q9688، q9689) برای بیمار تقریباً مشابهی، "
 "«آنتی‌ژن p24» را کلید کرده‌اند. کدام درست است؟**\n\n"
 "⚠️ **پاسخ: هر دو — و تفاوت در دو چیز است: نسل تست، و فاصله‌ی زمانی از تماس.**\n\n"
 "**نسل تست:**\n\n"
 "**تست نسل سوم** فقط **آنتی‌بادی** را می‌بیند. در هفته‌ی چهارم ممکن است هنوز منفی باشد.\n\n"
 "**تست نسل چهارم (ترکیبی آنتی‌ژن/آنتی‌بادی)** هم **آنتی‌ژن p24** را می‌بیند و هم "
 "آنتی‌بادی را — و **از حدود هفته‌ی دوم مثبت می‌شود**. این همان تستی است که **الگوریتم "
 "امروز CDC** با آن شروع می‌شود، و امروز وقتی می‌گوییم «EIA»، معمولاً همین منظور است.\n\n"
 "**فاصله‌ی زمانی:**\n\n"
 "**در هفته‌ی چهارم**، اکثریت قابل توجهی از افراد **از قبل سرم‌مثبت شده‌اند** (یادآوری: "
 "آنتی‌بادی از هفته‌ی ۳ تا ۱۲، اکثریت تا ۶). پس تست غربالگری در این مقطع منطقی است.\n\n"
 "**در سؤال‌های دیگر** که بیمار **۳ هفته** یا **۸ روز** پس از تماس مراجعه کرده، پنجره "
 "تنگ‌تر است و p24 منطقی‌تر می‌شود.\n\n"
 "**قاعده‌ی عملی که هر دو را می‌پوشاند:**\n\n"
 "> **با تست غربالگری ترکیبی شروع کنید. اگر منفی بود ولی شک بالینی قوی ماند، سراغ "
 "RNA بروید.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**وسترن بلات** — ⚠️ بدترین انتخاب در این مرحله. وسترن بلات فقط **IgG** را می‌بیند و "
 "**۲ تا ۳ هفته دیرتر** از تست غربالگری مثبت می‌شود. یعنی دقیقاً در عفونت حاد **کاذباً "
 "منفی** است. ضمناً CDC از ۲۰۱۴ آن را کاملاً کنار گذاشته.\n\n"
 "**HIV RNA PCR** — از نظر بیولوژیک زودترین تست است (از روز ۱۰)، ولی **گران** و **در همه "
 "جا در دسترس نیست**، و **اقدام اول** غربالگری نیست. جای آن وقتی است که غربالگری منفی "
 "باشد و شک بماند.\n\n"
 "**شمارش CD4** — ⚠️ این اصلاً یک تست تشخیصی نیست. CD4 برای **مرحله‌بندی و پیگیری** فرد "
 "**تشخیص‌داده‌شده** است، نه برای تشخیص. CD4 پایین علل بی‌شماری دارد.",
 "WARNING: AT FIRST SIGHT THIS QUESTION CONFLICTS WITH THREE OTHERS IN THE SAME CHAPTER, and "
 "resolving that conflict is the most valuable thing you will take from it.\n\n"
 "THE PATIENT: a 24-year-old man, FOUR WEEKS after unprotected intercourse, with sore throat, high "
 "fever, multiple cervical nodes and body aches. That is classic ACUTE RETROVIRAL SYNDROME.\n\n"
 "THE KEY HERE: perform the ELISA (EIA).\n\n"
 "BUT THREE OTHER QUESTIONS IN THIS CHAPTER (q9686, q9688, q9689) KEY THE p24 ANTIGEN FOR AN ALMOST "
 "IDENTICAL PATIENT. WHICH IS RIGHT?\n\n"
 "WARNING, THE ANSWER: BOTH — and the difference lies in two things: THE GENERATION OF THE ASSAY and "
 "THE INTERVAL SINCE EXPOSURE.\n\n"
 "THE GENERATION:\n\n"
 "A THIRD-GENERATION test sees only ANTIBODY. At four weeks it may still be negative.\n\n"
 "A FOURTH-GENERATION test (combined antigen/antibody) sees BOTH the p24 ANTIGEN and antibody, and "
 "IS POSITIVE FROM ABOUT WEEK 2. That is the assay TODAY'S CDC ALGORITHM begins with, and it is "
 "usually what 'EIA' means now.\n\n"
 "THE INTERVAL:\n\n"
 "AT FOUR WEEKS a substantial majority HAVE ALREADY SEROCONVERTED (recall: antibody from week 3 to "
 "12, most by 6). So a screening test is reasonable at this point.\n\n"
 "IN THE OTHER QUESTIONS the patient presents at THREE WEEKS or EIGHT DAYS, where the window is "
 "tighter and p24 makes more sense.\n\n"
 "THE PRACTICAL RULE THAT COVERS BOTH:\n\n"
 "> START WITH THE COMBINED SCREENING ASSAY. IF IT IS NEGATIVE BUT CLINICAL SUSPICION REMAINS "
 "STRONG, GO TO RNA.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "WESTERN BLOT — WARNING, the worst choice at this stage. It sees only IgG and turns positive 2 TO 3 "
 "WEEKS LATER than the screening test, so in acute infection it is FALSELY NEGATIVE. The CDC also "
 "abandoned it entirely in 2014.\n\n"
 "HIV RNA PCR — biologically the earliest test (from day 10), but EXPENSIVE and NOT UNIVERSALLY "
 "AVAILABLE, and not the FIRST step. Its place is when screening is negative and doubt persists.\n\n"
 "CD4 COUNT — WARNING, this is not a diagnostic test at all. CD4 is for STAGING AND FOLLOW-UP of "
 "someone ALREADY DIAGNOSED. A low CD4 has countless causes.",
 ["وسترن بلات فقط IgG را می‌بیند و ۲ تا ۳ هفته دیرتر مثبت می‌شود؛ در عفونت حاد کاذباً منفی است.",
  "HIV RNA PCR زودترین تست است ولی گران و کم‌دسترس، و اقدام غربالگری اول نیست.",
  "شمارش CD4 تست تشخیصی نیست؛ برای مرحله‌بندی و پیگیری فرد تشخیص‌داده‌شده است.",
  "پاسخ صحیح — در هفته‌ی چهارم اکثریت سرم‌مثبت شده‌اند و تست ترکیبی امروزی p24 را هم می‌بیند."],
 ["The Western blot sees only IgG and turns positive 2 to 3 weeks later; in acute infection it is falsely negative.",
  "HIV RNA PCR is the earliest test but is expensive and not widely available, and is not the first screening step.",
  "A CD4 count is not a diagnostic test; it is for staging and follow-up of someone already diagnosed.",
  "Correct — by week four most have seroconverted, and a modern combined assay also detects p24."],
 "**تست غربالگری ترکیبی اول؛ اگر منفی بود و شک ماند، RNA.**",
 "Combined screening assay first; if negative and suspicion persists, then RNA.",
 [CDCLAB, H202])


# =========================================================== book:673
add("book:673", "recall", "medium",
 "الگوریتم آن دوره: **دو الایزای مثبت + یک وسترن بلات تأییدی** — و امروز وسترن بلات کنار گذاشته شده است.",
 "The algorithm of that era: TWO positive ELISAs plus ONE confirmatory Western blot — and today the Western blot has been abandoned.",
 ACUTE_FA + [
  "**این سؤال ساختار کامل الگوریتم تشخیصی آن دوره را می‌آزماید.**",
  "⚠️ **دو بار الایزای مثبت، سپس یک بار تأیید با وسترن بلات — این کلید آزمون است.**",
  "**منطقش روشن است: غربالگری حساس ولی غیراختصاصی، تأییدی اختصاصی ولی کم‌حساس‌تر.**",
  "**تکرار الایزا خطای فنی و آلودگی نمونه را حذف می‌کند و هزینه‌ی ناچیزی دارد.**",
  "**تست تأییدی گران است، پس فقط برای نمونه‌هایی که دوبار مثبت شده‌اند به کار می‌رود.**",
  "⚠️ **و به‌روزرسانی: CDC از ۲۰۱۴ وسترن بلات را از الگوریتم حذف کرد.**",
  "**جایگزین: تست تفکیک آنتی‌بادی HIV-1 از HIV-2، و در ابهام، RNA.**",
  "**دلیل حذف: وسترن بلات در عفونت حاد کاذباً منفی است و HIV-2 را هم به‌خوبی نمی‌بیند.**",
 ],
 ACUTE_EN + [
  "This question tests the full structure of the diagnostic algorithm of that period.",
  "WARNING: TWO POSITIVE ELISAs, THEN ONE CONFIRMATORY WESTERN BLOT — that is the exam key.",
  "The logic is clear: screening is sensitive but not specific; confirmation is specific but less sensitive.",
  "Repeating the ELISA removes technical error and sample mix-up at negligible cost.",
  "The confirmatory test is expensive, so it is reserved for samples that have tested positive twice.",
  "WARNING, THE UPDATE: the CDC removed the Western blot from the algorithm in 2014.",
  "Its replacement: an HIV-1/HIV-2 antibody differentiation assay, and RNA if unresolved.",
  "The reason for removal: the Western blot is falsely negative in acute infection and detects HIV-2 poorly.",
 ],
 "این سؤال **ساختار کامل الگوریتم تشخیصی** را می‌آزماید، و پاسخش ساختار سه‌مرحله‌ای است.\n\n"
 "⚠️ **کلید: دو بار تست ELISA مثبت + یک بار تأییدیه با وسترن بلات.**\n\n"
 "**چرا این ساختار؟ منطق آن را بفهمید تا هرگز فراموش نکنید:**\n\n"
 "**مرحله‌ی یک — غربالگری:** الایزا **بسیار حساس** است (بالای ۹۹ درصد) ولی **اختصاصی "
 "نیست**. پس تقریباً هیچ مورد واقعی را از دست نمی‌دهد، ولی **مثبت کاذب زیاد** می‌دهد — "
 "به‌ویژه در بارداری، بیماری خودایمن، واکسیناسیون اخیر و دیالیز.\n\n"
 "**مرحله‌ی دو — تکرار همان الایزا:** این مرحله **خطای فنی** و **جابه‌جایی نمونه** را "
 "حذف می‌کند و **هزینه‌ی ناچیزی** دارد. اگر تکرار منفی شد، ماجرا تمام است.\n\n"
 "**مرحله‌ی سه — تست تأییدی:** وسترن بلات **بسیار اختصاصی** است ولی **گران** و **کندتر**. "
 "پس فقط برای نمونه‌هایی به کار می‌رود که **دو بار** مثبت شده‌اند.\n\n"
 "**این معماری — غربالگری حساس، سپس تأیید اختصاصی — الگوی عمومی تشخیص آزمایشگاهی در همه‌ی "
 "پزشکی است، نه فقط در HIV.**\n\n"
 "⚠️ **و حالا به‌روزرسانی مهمی که باید بدانید: CDC از سال ۲۰۱۴ وسترن بلات را کاملاً از "
 "الگوریتم حذف کرد.**\n\n"
 "**الگوریتم امروز:**\n\n"
 "**۱)** تست ترکیبی **آنتی‌ژن/آنتی‌بادی** HIV-1/2\n\n"
 "**۲)** در صورت واکنشی بودن: تست **تفکیک آنتی‌بادی HIV-1 از HIV-2**\n\n"
 "**۳)** اگر تفکیک منفی یا نامشخص بود: **HIV-1 RNA**\n\n"
 "**دو دلیل حذف وسترن بلات:** ⚠️ **اول** اینکه فقط IgG را می‌بیند و در **عفونت حاد کاذباً "
 "منفی** است — دقیقاً وقتی بیمار بیشترین سرایت را دارد. **دوم** اینکه **HIV-2 را به‌خوبی "
 "تشخیص نمی‌دهد**. سازمان جهانی بهداشت هم در ۲۰۱۹ استفاده از آن را توصیه نکرد.\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟** «یک الایزا + دو وسترن بلات» ترتیب را وارونه کرده و تست "
 "گران را دو بار انجام می‌دهد. «یک + یک» مرحله‌ی تکرار ارزان را حذف کرده. و «سه بار "
 "الایزا» هرگز به تأیید اختصاصی نمی‌رسد — سه بار تکرار یک تست غیراختصاصی، آن را اختصاصی "
 "نمی‌کند.",
 "This question tests THE FULL STRUCTURE OF THE DIAGNOSTIC ALGORITHM, and the answer is a "
 "three-step structure.\n\n"
 "WARNING, THE KEY: TWO POSITIVE ELISA TESTS PLUS ONE CONFIRMATORY WESTERN BLOT.\n\n"
 "WHY THAT STRUCTURE? Understand the logic and you will never forget it:\n\n"
 "STEP ONE — SCREENING: the ELISA is HIGHLY SENSITIVE (over 99 per cent) but NOT SPECIFIC. So it "
 "misses almost no true case but produces MANY FALSE POSITIVES — especially in pregnancy, autoimmune "
 "disease, recent vaccination and dialysis.\n\n"
 "STEP TWO — REPEATING THE SAME ELISA: this removes TECHNICAL ERROR and SAMPLE MIX-UP at NEGLIGIBLE "
 "COST. If the repeat is negative, the matter ends.\n\n"
 "STEP THREE — THE CONFIRMATORY TEST: the Western blot is HIGHLY SPECIFIC but EXPENSIVE and SLOWER, "
 "so it is used only on samples that have tested positive TWICE.\n\n"
 "THIS ARCHITECTURE — a sensitive screen followed by a specific confirmation — IS THE GENERAL PATTERN "
 "OF LABORATORY DIAGNOSIS THROUGHOUT MEDICINE, not just in HIV.\n\n"
 "WARNING, AND NOW THE IMPORTANT UPDATE: THE CDC REMOVED THE WESTERN BLOT FROM THE ALGORITHM "
 "ENTIRELY IN 2014.\n\n"
 "TODAY'S ALGORITHM:\n\n"
 "1) A combined HIV-1/2 ANTIGEN/ANTIBODY assay\n\n"
 "2) If reactive: an HIV-1/HIV-2 ANTIBODY DIFFERENTIATION assay\n\n"
 "3) If that is negative or indeterminate: HIV-1 RNA\n\n"
 "TWO REASONS FOR REMOVING THE WESTERN BLOT: WARNING, FIRST it sees only IgG and is FALSELY NEGATIVE "
 "IN ACUTE INFECTION — exactly when the patient is most infectious. SECOND, IT DETECTS HIV-2 POORLY. "
 "The WHO likewise recommended against it in 2019.\n\n"
 "AND WHY NOT THE OTHER THREE? 'One ELISA plus two Western blots' inverts the order and performs the "
 "expensive test twice. 'One plus one' drops the cheap repeat step. And 'three ELISAs' never reaches "
 "a specific confirmation — repeating a non-specific test three times does not make it specific.",
 ["پاسخ صحیح — دو الایزای مثبت سپس یک وسترن بلات تأییدی، الگوریتم آن دوره است.",
  "این ترتیب را وارونه کرده و تست گران و اختصاصی را دو بار انجام می‌دهد.",
  "این گزینه مرحله‌ی ارزان و مهم تکرار الایزا را حذف کرده است.",
  "سه بار تکرار یک تست غیراختصاصی، آن را اختصاصی نمی‌کند و هرگز تأیید محسوب نمی‌شود."],
 ["Correct — two positive ELISAs then one confirmatory Western blot was the algorithm of that period.",
  "This inverts the order and performs the expensive, specific test twice.",
  "This option drops the cheap but important repeat-ELISA step.",
  "Repeating a non-specific test three times does not make it specific and never counts as confirmation."],
 "**غربالگری حساس، تکرار ارزان، سپس تأیید اختصاصی — و امروز تأیید، تست تفکیک است نه وسترن بلات.**",
 "A sensitive screen, a cheap repeat, then a specific confirmation — and today confirmation is a differentiation assay, not a Western blot.",
 [CDCLAB, H202])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book35.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 35 lessons:', len(L))
