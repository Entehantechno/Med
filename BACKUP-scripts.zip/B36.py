# -*- coding: utf-8 -*-
"""Micro-lessons, batch 36 — HIV part three, plus the hepatitis serology block.

This batch finishes every remaining HIV question in the book and adds the
hepatitis items that turn on serology rather than on treatment. Three groups:

  * THE TESTING CHAIN, TWELVE MORE TIMES. The exam asks "the screening test is
    positive, what now?" over and over, and the answer alternates between
    REPEAT THE SCREEN and CONFIRM, depending on ONE WORD in the stem: how many
    positives have already happened. The lessons make that word the pivot.

  * OPPORTUNISTIC INFECTIONS AND PROPHYLAXIS. The CD4 ladder from batch 31,
    now applied: which organism at which rung, which prophylaxis at which
    threshold, and — the point most often missed — which prophylaxis covers
    more than one organism.

  * HEPATITIS SEROLOGY. Four questions, all decided by reading a panel rather
    than by knowing a drug.

A GUIDELINE THAT HAS MOVED, HANDLED THE USUAL HONEST WAY
---------------------------------------------------------
q9705 keys a four-drug prophylaxis (azithromycin + co-trimoxazole +
fluconazole + ganciclovir) for advanced AIDS with CD4 < 50. Today's
NIH/CDC/IDSA guidance withdraws three of those four:

    primary CMV prophylaxis          NOT recommended (AI)
    primary cryptococcal prophylaxis NOT recommended (DI)
    primary MAC prophylaxis          NOT recommended if ART is started (AII)

The key is NOT corrected — the question asks what the era's regimen was, the
keyed option is the most complete of the four offered, and rewriting it would
make the student answer the real exam wrongly. The lesson states the keyed
answer and then states plainly what today's guidance says and why. Same rule
as the clindamycin block in endocarditis and the Western blot block in batch 31.

TWO SOURCE DEFECTS ANNOTATED IN THIS BATCH
-------------------------------------------
q9854's printed panel has DIRECT bilirubin exceeding TOTAL, which is
arithmetically impossible, and q9852 prints IU/mL where mIU/mL belongs. Both
are errors of the BOOK, not of our extraction — glyph geometry confirms the
page prints what we stored — so the text is left alone and annotated. See
flag_source_errors_hiv.py. Both lessons tell the student openly.

Reference: Panel on Guidelines for the Prevention and Treatment of
Opportunistic Infections in Adults and Adolescents with HIV (NIH/CDC/IDSA);
CDC — Laboratory Testing for the Diagnosis of HIV Infection (2014, rev. 2018);
CDC/ACIP — Prevention of Hepatitis B Virus Infection: Recommendations of ACIP;
AASLD Practice Guidance on Chronic Hepatitis B (Hepatology 2018;67:1560);
Harrison's Principles of Internal Medicine, 21st ed (2022), Ch. 202 and the
hepatitis chapters.
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H202 = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 202: Human "
        "Immunodeficiency Virus Disease: AIDS and Related Disorders")
CDCLAB = ("CDC — Laboratory Testing for the Diagnosis of HIV Infection: Updated "
          "Recommendations (2014, revised 2018)")
OIG = ("Panel on Guidelines for the Prevention and Treatment of Opportunistic Infections "
       "in Adults and Adolescents with HIV — NIH, CDC and IDSA (clinicalinfo.hiv.gov)")
ACIP = ("CDC/ACIP — Prevention of Hepatitis B Virus Infection in the United States: "
        "Recommendations of the Advisory Committee on Immunization Practices")
AASLD = ("Terrault NA et al. — AASLD Guidance on Prevention, Diagnosis and Treatment of "
         "Chronic Hepatitis B. Hepatology 2018;67:1560")
ACIPMMR = ("CDC/ACIP — Prevention of Measles, Rubella, Congenital Rubella Syndrome and Mumps: "
           "recommendations on MMR in people with HIV")

# ==================================================== THE TESTING CHAIN, PART 2
CHAIN_FA = [
    "⚠️ **این خوشه دوازده بار یک سؤال را می‌پرسد، و پاسخ فقط به یک کلمه بستگی دارد: چند بار مثبت شده؟**",
    "**قاعده‌ی حاکم: تست غربالگری حساس است ولی اختصاصی نیست، پس هرگز به‌تنهایی تشخیص نمی‌دهد.**",
    "**الایزا حساسیت بالای ۹۹ درصد دارد — تقریباً هیچ مورد واقعی را از دست نمی‌دهد.**",
    "⚠️ **ولی در جمعیت کم‌خطر، بیشترِ مثبت‌ها کاذب‌اند — و این ریاضیات است، نه ضعف آزمایش.**",
    "**علل مثبت کاذب: بارداری، بیماری خودایمن، واکسیناسیون اخیر، عفونت ویروسی حاد، دیالیز، مولتی‌پاریتی.**",
    "⚠️ **پس شمردن یاد بگیرید — و کل خوشه حل می‌شود:**",
    "**یک بار مثبت ← تکرار همان الایزا روی همان نمونه. نه تست تأییدی، نه تشخیص.**",
    "**دو بار مثبت ← حالا و فقط حالا سراغ تست تأییدی می‌رویم.**",
    "**اگر تکرار منفی شد، مثبت اول یک خطای فنی بوده و ماجرا تمام است.**",
    "**تکرار الایزا ارزان است و خطای فنی و جابه‌جایی نمونه را حذف می‌کند؛ تست تأییدی گران است.**",
    "**همین معماری — غربالگری حساس، سپس تأیید اختصاصی — الگوی عمومی تشخیص در کل پزشکی است.**",
    "**پاسخ کلید این آزمون‌ها برای تأیید: وسترن بلات. این الگوریتم آن دوره است.**",
    "⚠️ **و به‌روزرسانی: CDC از سال ۲۰۱۴ وسترن بلات را کاملاً از الگوریتم حذف کرد.**",
    "**چون فقط IgG را می‌بیند و ۲ تا ۳ هفته دیرتر از تست غربالگری مثبت می‌شود.**",
    "**پس در عفونت حاد — وقتی بیمار بیشترین سرایت را دارد — کاذباً منفی است. HIV-2 را هم بد می‌بیند.**",
    "**الگوریتم امروز: تست ترکیبی آنتی‌ژن/آنتی‌بادی ← تست تفکیک HIV-1 از HIV-2 ← در ابهام، RNA.**",
    "⚠️ **و یک استثنای مهم که خوشه دو بار می‌پرسد: وسترن بلات نامشخص (indeterminate).**",
    "**نتیجه‌ی نامشخص یعنی چند باند دیده شده ولی به معیار کامل نرسیده.**",
    "**دو تفسیر دارد: یا سرکونورژن در حال وقوع است، یا یک واکنش غیراختصاصی.**",
    "**راه تفکیک: RNA یا p24 که همین حالا جواب می‌دهند، و تکرار سرولوژی ۴ تا ۶ هفته بعد.**",
]
CHAIN_EN = [
    "WARNING: THIS CLUSTER ASKS ONE QUESTION TWELVE TIMES, and the answer turns on a single word: how many positives so far?",
    "The governing rule: a screening test is sensitive but not specific, so it never diagnoses alone.",
    "The ELISA is over 99 per cent sensitive — it misses almost no true case.",
    "WARNING, BUT IN A LOW-RISK POPULATION MOST POSITIVES ARE FALSE — that is arithmetic, not a fault of the assay.",
    "Causes of a false positive: pregnancy, autoimmune disease, recent vaccination, acute viral infection, dialysis, multiparity.",
    "WARNING, SO LEARN TO COUNT — and the whole cluster dissolves:",
    "ONE positive: repeat the SAME ELISA on the same sample. Not a confirmatory test, and not a diagnosis.",
    "TWO positives: now, and only now, do we move to the confirmatory test.",
    "If the repeat is negative, the first positive was a technical error and the matter ends there.",
    "Repeating the ELISA is cheap and removes technical error and sample mix-up; the confirmatory test is expensive.",
    "This architecture — a sensitive screen then a specific confirmation — is the general pattern of diagnosis throughout medicine.",
    "The keyed confirmatory answer in these exams: the WESTERN BLOT. That was the algorithm of the period.",
    "WARNING, AN UPDATE: the CDC removed the Western blot from the algorithm entirely in 2014.",
    "Because it sees only IgG and turns positive 2 to 3 weeks LATER than the screening test.",
    "So in acute infection — when the patient is most infectious — it is falsely negative. It also detects HIV-2 poorly.",
    "Today's algorithm: a combined antigen/antibody assay, then an HIV-1/HIV-2 differentiation assay, then RNA if unresolved.",
    "WARNING, AND ONE IMPORTANT EXCEPTION THE CLUSTER ASKS TWICE: AN INDETERMINATE WESTERN BLOT.",
    "Indeterminate means some bands appeared but the full criteria were not met.",
    "It has two readings: either seroconversion is under way, or this is a non-specific reaction.",
    "How to separate them: RNA or p24, which answer today, plus repeat serology in 4 to 6 weeks.",
]

# =========================================== OPPORTUNISTIC INFECTION AND PROPHYLAXIS
OI_FA = [
    "⚠️ **در HIV، عدد CD4 یک آزمایش نیست — ساعتی است که می‌گوید کدام عفونت‌ها ممکن شده‌اند.**",
    "**آستانه‌ها را نردبانی نزولی حفظ کنید، چون سؤال‌ها دقیقاً روی پله‌ها می‌ایستند:**",
    "**بالای ۵۰۰: عملاً مثل فرد سالم؛ بیشتر عفونت‌های باکتریال معمولی.**",
    "**۲۰۰ تا ۵۰۰: برفک دهانی، لکوپلاکی مویی، زونا، سل ریوی، پنومونی باکتریال مکرر.**",
    "⚠️ **زیر ۲۰۰ — مهم‌ترین آستانه: پنوموسیستیس ژیرووسی (PCP)، و پروفیلاکسی از همین‌جا شروع می‌شود.**",
    "**زیر ۱۰۰: توکسوپلاسموز مغزی و مننژیت کریپتوکوکی.**",
    "**زیر ۵۰: مایکوباکتریوم آویوم منتشر و رتینیت سیتومگالوویروس.**",
    "⚠️ **و نکته‌ای که بیشترین امتیاز را در این خوشه می‌دهد: کوتریموکسازول دو کار می‌کند.**",
    "**همان قرصی که برای PCP شروع می‌شود، توکسوپلاسموز را هم پوشش می‌دهد.**",
    "**پس وقتی CD4 زیر ۱۰۰ می‌رود و IgG ضد توکسوپلاسما مثبت است، نیازی به داروی دوم نیست.**",
    "**و پروفیلاکسی سالمونلا و لیستریا هم به‌طور جانبی از همین دارو سود می‌برد.**",
    "⚠️ **پروفیلاکسی قابل قطع شدن است — و سؤال‌ها روی این حساب می‌کنند.**",
    "**اگر با درمان ضدرتروویروسی CD4 بالای آستانه برود و بیش از ۳ ماه بماند، پروفیلاکسی قطع می‌شود.**",
    "**برای PCP و توکسوپلاسما: CD4 بالای ۲۰۰ به مدت بیش از ۳ ماه.**",
    "**چون بازسازی ایمنی همان محافظتی را برمی‌گرداند که دارو جایگزینش شده بود.**",
    "⚠️ **و سل استثناست: در HIV در هر شمارش CD4 رخ می‌دهد، حتی بالای ۵۰۰.**",
    "**پس سل شایع‌ترین عفونت هم‌زمان و شایع‌ترین علت مرگ در HIV در جهان است.**",
    "**و هرچه CD4 پایین‌تر، تابلوی سل غیرتیپیک‌تر: بدون کاویته، منتشر، اسمیر منفی، شبیه سل اولیه.**",
]
OI_EN = [
    "WARNING: IN HIV THE CD4 COUNT IS NOT A TEST BUT A CLOCK, telling you which infections have become possible.",
    "Memorise the thresholds as a descending ladder, because the questions stand exactly on the rungs:",
    "ABOVE 500: essentially like a healthy person; mostly ordinary bacterial infections.",
    "200 TO 500: oral thrush, hairy leucoplakia, zoster, pulmonary TB, recurrent bacterial pneumonia.",
    "WARNING, BELOW 200 — THE MOST IMPORTANT THRESHOLD: Pneumocystis jirovecii (PCP), and prophylaxis begins here.",
    "BELOW 100: cerebral toxoplasmosis and cryptococcal meningitis.",
    "BELOW 50: disseminated Mycobacterium avium complex and CMV retinitis.",
    "WARNING, AND THE POINT THAT EARNS MOST MARKS IN THIS CLUSTER: CO-TRIMOXAZOLE DOES TWO JOBS.",
    "The very tablet started for PCP also covers TOXOPLASMOSIS.",
    "So when the CD4 falls below 100 with a positive anti-toxoplasma IgG, no second drug is needed.",
    "And prophylaxis against Salmonella and Listeria comes incidentally from the same drug.",
    "WARNING, PROPHYLAXIS CAN BE STOPPED — and the questions rely on this.",
    "If antiretroviral therapy lifts the CD4 above the threshold and holds it there for more than 3 months, prophylaxis stops.",
    "For PCP and toxoplasma: CD4 above 200 for more than 3 months.",
    "Because immune reconstitution restores the very protection the drug was substituting for.",
    "WARNING, AND TUBERCULOSIS IS THE EXCEPTION: in HIV it occurs at ANY CD4 count, even above 500.",
    "So TB is the commonest coinfection and the commonest cause of death in HIV worldwide.",
    "And the lower the CD4, the more atypical the TB: non-cavitary, disseminated, smear-negative, resembling primary TB.",
]

# ============================================================ HEPATITIS SEROLOGY
HEP_FA = [
    "⚠️ **سرولوژی هپاتیت را حفظ نکنید — بخوانید. هر نشانگر یک سؤال مشخص را جواب می‌دهد.**",
    "**HBsAg: آیا همین حالا ویروس در بدن هست؟ مثبت یعنی عفونت فعلی، حاد یا مزمن.**",
    "**anti-HBs: آیا ایمنی محافظ وجود دارد؟ مثبت یعنی بهبود یا واکسیناسیون.**",
    "⚠️ **و تنها نشانگری که واکسن نمی‌سازد: anti-HBc. پس تنها راه تفکیک واکسینه از بهبودیافته است.**",
    "**واکسینه: فقط anti-HBs مثبت. بهبودیافته: anti-HBs و anti-HBc هر دو مثبت.**",
    "**anti-HBc از نوع IgM: عفونت حاد یا تشدید حاد. از نوع IgG: تماس در گذشته.**",
    "⚠️ **و IgM ضد HBc تنها نشانگر «پنجره‌ی سرولوژیک» است.**",
    "**در آن پنجره HBsAg محو شده و anti-HBs هنوز نیامده؛ فقط IgM ضد HBc مثبت است.**",
    "**HBeAg: چقدر تکثیر و چقدر سرایت؟ مثبت یعنی تکثیر فعال و سرایت بالا.**",
    "**HBV DNA: همان سؤال، ولی کمّی و دقیق — و امروز معیار تصمیم درمان است.**",
    "⚠️ **و شدت هپاتیت با آنزیم سنجیده نمی‌شود، با عملکرد سنتزی کبد سنجیده می‌شود.**",
    "**ALT فقط می‌گوید سلول کبدی در حال مرگ است، نه اینکه چقدر کبد باقی مانده.**",
    "**نشانگرهای واقعی شدت: INR (یا PT) و آلبومین و آمونیاک و سطح هوشیاری.**",
    "**به همین دلیل در نارسایی حاد کبد، افت ALT می‌تواند نشانه‌ی بدتر شدن باشد نه بهتر شدن.**",
    "⚠️ **آستانه‌ی محافظت anti-HBs عدد ۱۰ mIU/mL است — این عدد را حفظ کنید.**",
    "**زیر ۱۰ یعنی نان‌رسپاندر، و پس از مواجهه به هر دو یعنی HBIG و تکرار واکسن نیاز است.**",
]
HEP_EN = [
    "WARNING: DO NOT MEMORISE HEPATITIS SEROLOGY — READ IT. Each marker answers one specific question.",
    "HBsAg: is the virus present right now? Positive means current infection, acute or chronic.",
    "anti-HBs: is there protective immunity? Positive means recovery or vaccination.",
    "WARNING, AND THE ONE MARKER A VACCINE NEVER MAKES: anti-HBc. So it is the only way to tell vaccinated from recovered.",
    "Vaccinated: anti-HBs alone. Recovered: anti-HBs AND anti-HBc both positive.",
    "anti-HBc of IgM class: acute infection or an acute flare. Of IgG class: past exposure.",
    "WARNING, AND IgM ANTI-HBc IS THE ONLY MARKER OF THE SEROLOGICAL WINDOW.",
    "In that window HBsAg has cleared and anti-HBs has not yet appeared; only IgM anti-HBc is positive.",
    "HBeAg: how much replication and how much infectivity? Positive means active replication and high infectivity.",
    "HBV DNA: the same question, but quantitative and precise — and today the basis of treatment decisions.",
    "WARNING, AND SEVERITY IS NOT MEASURED BY THE ENZYME BUT BY THE LIVER'S SYNTHETIC FUNCTION.",
    "The ALT tells you only that hepatocytes are dying, not how much liver remains.",
    "The real severity markers: INR (or PT), albumin, ammonia and conscious level.",
    "That is why in acute liver failure a FALLING ALT can mean deterioration, not improvement.",
    "WARNING, THE PROTECTIVE anti-HBs THRESHOLD IS 10 mIU/mL — memorise that number.",
    "Below 10 means non-responder, and after an exposure BOTH HBIG AND a repeat vaccine series are needed.",
]


# ======================================= testing chain: ONE positive -> repeat
def _one_positive(key, diff, extra_fa, extra_en, exp_fa, exp_en, why_fa, why_en):
    add(key, "case", diff,
        "**یک** الایزای مثبت ← اول **تکرار همان الایزا**. نه تست تأییدی، نه تشخیص.",
        "A SINGLE positive ELISA needs the ELISA REPEATED first — not a confirmatory test, and not a diagnosis.",
        CHAIN_FA + extra_fa, CHAIN_EN + extra_en, exp_fa, exp_en, why_fa, why_en,
        "**بشمارید: یک مثبت ← تکرار. دو مثبت ← تأیید.**",
        "Count them: one positive means repeat; two positives mean confirm.",
        [CDCLAB, H202])


_one_positive(
    "book:676", "medium",
    ["**این بیمار علائم بالینی کاملاً سازگار دارد، ولی این چیزی را عوض نمی‌کند.**",
     "⚠️ **حتی با تابلوی بالینی قوی، یک تست غربالگری مثبت هنوز یک تست غربالگری است.**",
     "**سابقه‌ی اعتیاد تزریقی احتمال پیش‌آزمون را بالا می‌برد، ولی الگوریتم را کوتاه نمی‌کند.**",
     "**چون خطای فنی و جابه‌جایی نمونه به احتمال پیش‌آزمون بیمار کاری ندارند.**"],
    ["This patient has a fully compatible clinical picture, but that changes nothing.",
     "WARNING: EVEN WITH A STRONG CLINICAL PICTURE, A POSITIVE SCREEN IS STILL ONLY A SCREEN.",
     "A history of injecting drug use raises the pre-test probability but does not shorten the algorithm.",
     "Because technical error and sample mix-up are indifferent to the patient's pre-test probability."],
    "**آقای ۲۶ ساله** با اعتیاد تزریقی، تب طول‌کشیده، لنفادنوپاتی ژنرالیزه و کاهش وزن. "
    "**HIV ELISA مثبت.**\n\n"
    "⚠️ **بشمارید: چند بار مثبت شده؟ یک بار. پس پاسخ تکرار الایزاست.**\n\n"
    "**و اینجا وسوسه‌ی واقعی این است:** تابلوی بالینی **کاملاً سازگار** است و بیمار "
    "**عامل خطر آشکار** دارد. طبیعی است که آدم فکر کند «دیگر روشن است، برویم سراغ تست "
    "تأییدی».\n\n"
    "**ولی این استدلال یک اشتباه پنهان دارد.** دلیل تکرار الایزا فقط «شاید بیمار مبتلا "
    "نباشد» نیست — **خطای فنی و جابه‌جایی نمونه** هم هست. آزمایشگاه ممکن است لوله را "
    "اشتباه بگیرد، یا واکنش‌گر معیوب باشد. **این خطاها به احتمال پیش‌آزمون بیمار کاری "
    "ندارند** و در بیمار پرخطر هم به همان اندازه ممکن‌اند.\n\n"
    "**و هزینه:** تکرار الایزا **ارزان و سریع** است؛ تست تأییدی **گران** است. انجام تست "
    "گران روی نمونه‌ای که ممکن است اصلاً مال این بیمار نباشد، منطقی نیست.\n\n"
    "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
    "**وسترن بلات** — گام درستی است ولی **در جای غلط**: بعد از **دو** مثبت، نه یکی.\n\n"
    "**آنتی‌ژن p24** — برای **عفونت حاد** با آنتی‌بادی منفی است. اینجا آنتی‌بادی از قبل "
    "مثبت شده و بیمار تابلوی **مزمن** دارد (کاهش وزن، لنفادنوپاتی طول‌کشیده).\n\n"
    "**PCR** — گران و بیش از حد لازم برای این مرحله؛ جایش وقتی است که سرولوژی ابهام دارد.",
    "A 26-YEAR-OLD MAN with injecting drug use, prolonged fever, generalised lymphadenopathy and "
    "weight loss. HIV ELISA POSITIVE.\n\n"
    "WARNING, COUNT THEM: HOW MANY POSITIVES? ONE. So the answer is to repeat the ELISA.\n\n"
    "AND HERE IS THE REAL TEMPTATION: the clinical picture is FULLY COMPATIBLE and the patient has "
    "an OBVIOUS RISK FACTOR. It is natural to think 'this is settled, move to confirmation'.\n\n"
    "BUT THAT REASONING HIDES A MISTAKE. The reason for repeating is not only 'perhaps the patient "
    "is not infected' — it is also TECHNICAL ERROR AND SAMPLE MIX-UP. The laboratory may pick the "
    "wrong tube, or a reagent may be faulty. THOSE ERRORS ARE INDIFFERENT TO THE PATIENT'S PRE-TEST "
    "PROBABILITY and are just as possible in a high-risk patient.\n\n"
    "AND THE COST: repeating the ELISA is CHEAP AND FAST; the confirmatory test is EXPENSIVE. "
    "Running an expensive test on a sample that may not even belong to this patient makes no sense.\n\n"
    "AND WHY NOT THE OTHER THREE?\n\n"
    "WESTERN BLOT — the right step IN THE WRONG PLACE: it comes after TWO positives, not one.\n\n"
    "p24 ANTIGEN — for ACUTE infection with negative antibody. Here antibody is already positive and "
    "the picture is CHRONIC (weight loss, prolonged lymphadenopathy).\n\n"
    "PCR — expensive and more than this stage requires; its place is when serology is unresolved.",
    ["وسترن بلات گام درستی در جای غلط است؛ جایش پس از دو مثبت است، نه یکی.",
     "پاسخ صحیح — یک الایزای مثبت باید ابتدا روی همان نمونه تکرار شود.",
     "آنتی‌ژن p24 برای عفونت حاد با آنتی‌بادی منفی است؛ اینجا آنتی‌بادی از قبل مثبت شده.",
     "PCR گران و بیش از نیاز این مرحله است؛ جایش وقتی است که سرولوژی مبهم بماند."],
    ["The Western blot is the right step in the wrong place; it comes after two positives, not one.",
     "Correct — a single positive ELISA must first be repeated on the same sample.",
     "The p24 antigen is for acute infection with negative antibody; here antibody is already positive.",
     "PCR is expensive and beyond what this stage needs; its place is when serology stays unresolved."])

_one_positive(
    "book:677", "easy",
    ["**این سؤال کوتاه‌ترین شکل همان مسئله است: یک EIA مثبت، اقدام بعدی چیست؟**",
     "**و یک گزینه‌ی خطرناک دارد که صریحاً می‌گوید یک تست کافی است.**",
     "⚠️ **هیچ تست غربالگری‌ای هرگز به‌تنهایی تشخیص HIV نمی‌دهد — این یک خط قرمز است.**",
     "**اعلام تشخیص HIV بر پایه‌ی یک تست، یک فاجعه‌ی انسانی و حقوقی است.**"],
    ["This is the shortest form of the same problem: one positive EIA, what next?",
     "And it contains a dangerous option that says outright that one test is enough.",
     "WARNING: NO SCREENING TEST EVER DIAGNOSES HIV ALONE — that is a red line.",
     "Declaring an HIV diagnosis on one test is a human and legal catastrophe."],
    "این کوتاه‌ترین شکل همان مسئله است: **یک آزمایش EIA مثبت. اقدام بعدی؟**\n\n"
    "⚠️ **بشمارید: یک مثبت ← تکرار همان EIA.**\n\n"
    "**ولی این سؤال یک گزینه‌ی خطرناک دارد که باید جداگانه دربارهٔ آن حرف زد:**\n\n"
    "> «با توجه به سابقه‌ی اعتیاد، همین یک تست برای تشخیص کافی است.»\n\n"
    "⚠️ **این گزینه نه‌فقط از نظر علمی غلط است، بلکه از نظر اخلاقی خطرناک است.**\n\n"
    "**چرا؟** چون اعلام تشخیص HIV به یک انسان بر پایه‌ی **یک تست غربالگری**:\n\n"
    "**۱)** ممکن است **کاذب** باشد — در جمعیت کم‌خطر بیشتر مثبت‌ها کاذب‌اند، و حتی در "
    "جمعیت پرخطر خطای فنی ممکن است.\n\n"
    "**۲)** پیامدهای **اجتماعی و روانی بازگشت‌ناپذیر** دارد: از دست دادن شغل، فروپاشی "
    "خانواده، انگ اجتماعی.\n\n"
    "**۳)** و «سابقه‌ی اعتیاد» **هیچ کمکی به این استدلال نمی‌کند**. عامل خطر احتمال "
    "پیش‌آزمون را بالا می‌برد، ولی **الگوریتم را کوتاه نمی‌کند**. اتفاقاً استفاده از "
    "قضاوت اجتماعی به‌جای الگوریتم آزمایشگاهی، دقیقاً همان چیزی است که پزشکی باید از آن "
    "بپرهیزد.\n\n"
    "**و دو گزینه‌ی دیگر؟** **وسترن بلات** گام درستی در جای غلط است (بعد از دو مثبت)، و "
    "**PCR** گران و زودهنگام است.",
    "This is the shortest form of the same problem: ONE POSITIVE EIA. WHAT NEXT?\n\n"
    "WARNING, COUNT THEM: ONE POSITIVE, so repeat the same EIA.\n\n"
    "BUT THIS QUESTION CONTAINS A DANGEROUS OPTION that deserves separate discussion:\n\n"
    "> 'Given the history of addiction, this single test is enough for the diagnosis.'\n\n"
    "WARNING: THAT OPTION IS NOT MERELY SCIENTIFICALLY WRONG BUT ETHICALLY DANGEROUS.\n\n"
    "WHY? Because announcing an HIV diagnosis to a human being on the basis of ONE SCREENING TEST:\n\n"
    "1) MAY BE FALSE — in a low-risk population most positives are false, and even in a high-risk "
    "one technical error remains possible.\n\n"
    "2) Has IRREVERSIBLE SOCIAL AND PSYCHOLOGICAL CONSEQUENCES: loss of employment, family "
    "breakdown, stigma.\n\n"
    "3) And 'a history of addiction' CONTRIBUTES NOTHING TO THE ARGUMENT. A risk factor raises the "
    "pre-test probability but DOES NOT SHORTEN THE ALGORITHM. Substituting social judgement for a "
    "laboratory algorithm is precisely what medicine must avoid.\n\n"
    "AND THE OTHER TWO? The WESTERN BLOT is the right step in the wrong place (after two positives), "
    "and PCR is expensive and premature.",
    ["پاسخ صحیح — یک EIA مثبت باید تکرار شود؛ شمردن تعداد مثبت‌ها کل خوشه را حل می‌کند.",
     "وسترن بلات گام درستی در جای غلط است؛ پس از دو مثبت جای آن است.",
     "PCR در این مرحله گران و زودهنگام است و اقدام غربالگری بعدی نیست.",
     "خطرناک‌ترین گزینه — هیچ تست غربالگری‌ای به‌تنهایی تشخیص HIV نمی‌دهد، و سابقه‌ی اعتیاد الگوریتم را کوتاه نمی‌کند."],
    ["Correct — a single positive EIA must be repeated; counting the positives solves the whole cluster.",
     "The Western blot is the right step in the wrong place; its place is after two positives.",
     "PCR at this stage is expensive and premature, and is not the next screening step.",
     "The most dangerous option — no screening test diagnoses HIV alone, and a history of addiction does not shorten the algorithm."])

_one_positive(
    "book:679", "medium",
    ["**بارداری یکی از شناخته‌شده‌ترین علل مثبت کاذب الایزاست — ولی گزینه‌ی «کاذب است» غلط است.**",
     "⚠️ **تفاوت ظریف: بارداری می‌تواند مثبت کاذب بسازد، ولی نمی‌توان از پیش فرض کرد که ساخته.**",
     "**اطمینان دادن به بیمار پیش از تکرار آزمایش، اطمینان‌بخشی نیست — بی‌مسئولیتی است.**",
     "**و در بارداری، تشخیص از دست رفته یعنی از دست دادن فرصت پیشگیری از انتقال به نوزاد.**",
     "**با درمان مادر، خطر انتقال از ۱۵ تا ۴۵ درصد به زیر ۱ تا ۲ درصد می‌رسد.**"],
    ["Pregnancy is one of the best-recognised causes of a false-positive ELISA — but the option 'it is false' is wrong.",
     "WARNING, A FINE DISTINCTION: pregnancy CAN cause a false positive, but you cannot assume in advance that it did.",
     "Reassuring the patient before repeating the test is not reassurance but irresponsibility.",
     "And in pregnancy a missed diagnosis means a lost opportunity to prevent transmission to the infant.",
     "With maternal treatment the transmission risk falls from 15 to 45 per cent to below 1 to 2 per cent."],
    "**خانم جوان باردار** با **EIA مثبت** در آزمایشات روتین بارداری، مضطرب مراجعه کرده است.\n\n"
    "⚠️ **بشمارید: یک مثبت ← تکرار EIA. پاسخ همین است.**\n\n"
    "**ولی این سؤال یک دام بسیار ظریف دارد که ارزش دقت دارد.**\n\n"
    "گزینه‌ی «مطمئن کردن وی از اینکه مثبت بودن تست به علت حاملگی و کاذب است» **نیمی از "
    "یک حقیقت** را می‌گوید. **بارداری واقعاً یکی از شناخته‌شده‌ترین علل مثبت کاذب الایزا "
    "است** — به‌ویژه در زنان مولتی‌پار، احتمالاً به‌دلیل آنتی‌بادی‌های ضد آنتی‌ژن‌های "
    "HLA جنین.\n\n"
    "⚠️ **پس چرا این گزینه غلط است؟ چون تفاوت میان «می‌تواند کاذب باشد» و «کاذب است» "
    "تفاوت میان علم و حدس است.**\n\n"
    "**اطمینان دادن به بیمار پیش از تکرار آزمایش، اطمینان‌بخشی نیست — بی‌مسئولیتی است.** "
    "و در بارداری این بی‌مسئولیتی هزینه‌ی مضاعف دارد:\n\n"
    "**اگر تشخیص از دست برود، فرصت پیشگیری از انتقال به نوزاد از دست می‌رود.** با درمان "
    "ضدرتروویروسی مادر و سرکوب بار ویروسی، خطر انتقال از **۱۵ تا ۴۵ درصد** به **زیر ۱ "
    "تا ۲ درصد** می‌رسد. **این یکی از موفق‌ترین مداخلات کل پزشکی است** و از دست دادنش "
    "به‌خاطر یک اطمینان‌بخشی زودهنگام، غیرقابل قبول است.\n\n"
    "**نکته‌ی عملی و انسانی:** کاری که باید کرد این است که به بیمار توضیح دهید تست "
    "غربالگری مثبت **تشخیص نیست**، که مثبت کاذب در بارداری شایع است، و که **آزمایش تکرار "
    "می‌شود** — یعنی هم امید بدهید و هم راستگو بمانید.\n\n"
    "**و دو گزینه‌ی دیگر؟** **وسترن بلات** پس از دو مثبت، و **PCR** گران و زودهنگام است.",
    "A YOUNG PREGNANT WOMAN with a POSITIVE EIA on routine antenatal testing, presenting anxious.\n\n"
    "WARNING, COUNT THEM: ONE POSITIVE, so repeat the EIA. That is the answer.\n\n"
    "BUT THIS QUESTION HIDES A VERY FINE TRAP worth attention.\n\n"
    "The option 'reassure her that the positive is due to pregnancy and is false' states HALF A "
    "TRUTH. PREGNANCY REALLY IS one of the best-recognised causes of a false-positive ELISA — "
    "particularly in multiparous women, probably through antibodies to fetal HLA antigens.\n\n"
    "WARNING, SO WHY IS THE OPTION WRONG? Because the difference between 'COULD BE false' and 'IS "
    "false' is the difference between science and guesswork.\n\n"
    "REASSURING A PATIENT BEFORE REPEATING THE TEST IS NOT REASSURANCE BUT IRRESPONSIBILITY. And in "
    "pregnancy that irresponsibility costs double:\n\n"
    "IF THE DIAGNOSIS IS MISSED, THE CHANCE TO PREVENT TRANSMISSION TO THE INFANT IS LOST. With "
    "maternal antiretroviral therapy and viral suppression, transmission risk falls from 15 TO 45 "
    "PER CENT to BELOW 1 TO 2 PER CENT. THAT IS ONE OF THE MOST SUCCESSFUL INTERVENTIONS IN ALL OF "
    "MEDICINE, and losing it to premature reassurance is unacceptable.\n\n"
    "THE PRACTICAL, HUMANE POINT: what you should do is explain that a positive screen IS NOT A "
    "DIAGNOSIS, that false positives are common in pregnancy, and that THE TEST WILL BE REPEATED — "
    "giving hope while staying truthful.\n\n"
    "AND THE OTHER TWO? The WESTERN BLOT after two positives, and PCR expensive and premature.",
    ["نیمی از یک حقیقت — بارداری می‌تواند مثبت کاذب بسازد، ولی نمی‌توان پیش از تکرار آزمایش آن را فرض کرد.",
     "پاسخ صحیح — یک EIA مثبت تکرار می‌شود؛ این هم امید می‌دهد و هم راستگو می‌ماند.",
     "وسترن بلات پس از دو مثبت جای دارد، نه پس از یکی.",
     "PCR در این مرحله گران و زودهنگام است و اقدام بعدی الگوریتم نیست."],
    ["Half a truth — pregnancy can cause a false positive, but you cannot assume it before repeating the test.",
     "Correct — a single positive EIA is repeated; that both gives hope and stays truthful.",
     "The Western blot belongs after two positives, not after one.",
     "PCR at this stage is expensive and premature and is not the algorithm's next step."])

_one_positive(
    "book:680", "easy",
    ["**سابقه‌ی رفتار پرخطر در دو سال گذشته، احتمال پیش‌آزمون را بالا می‌برد.**",
     "**ولی الگوریتم همان است: یک مثبت، یک تکرار.**",
     "⚠️ **و گزینه‌ی p24 اینجا یک دام زمانی است: تماس دو سال پیش بوده، نه دو هفته.**",
     "**آنتی‌ژن p24 فقط در پنجره‌ی عفونت حاد ارزش دارد و بعد از سرکونورژن محو می‌شود.**"],
    ["High-risk behaviour over the past two years raises the pre-test probability.",
     "But the algorithm is unchanged: one positive, one repeat.",
     "WARNING, AND THE p24 OPTION IS A TIMING TRAP: the exposure was two years ago, not two weeks.",
     "The p24 antigen is useful only in the acute window and disappears after seroconversion."],
    "**جوان ۲۵ ساله** با سابقه‌ی رفتارهای پرخطر **در دو سال گذشته**، الایزای HIV Ab **مثبت**.\n\n"
    "⚠️ **بشمارید: یک مثبت ← تکرار الایزا.**\n\n"
    "**و این سؤال یک دام زمانی دارد که ارزش دیدن دارد.** گزینه‌ی **p24** در نگاه اول "
    "علمی به‌نظر می‌رسد، ولی **زمان‌بندی آن را رد می‌کند**:\n\n"
    "**آنتی‌ژن p24 پروتئین هسته‌ی ویروس است و فقط در پنجره‌ی عفونت حاد در خون آزاد "
    "می‌چرخد** — از حدود هفته‌ی دوم تا زمانی که آنتی‌بادی ساخته شود. **پس از سرکونورژن، "
    "آنتی‌بادی‌ها p24 را به کمپلکس ایمنی تبدیل می‌کنند و از خون پاک می‌شود.**\n\n"
    "**اینجا تماس «دو سال گذشته» بوده و آنتی‌بادی از قبل مثبت شده است — یعنی سرکونورژن "
    "مدت‌هاست اتفاق افتاده. p24 در این مرحله احتمالاً منفی است و هیچ اطلاعاتی اضافه "
    "نمی‌کند.**\n\n"
    "**و دو گزینه‌ی دیگر؟** **HIV RNA PCR** حساس‌ترین است ولی گران، و اقدام غربالگری بعدی "
    "نیست. **وسترن بلات** گام درستی است ولی **پس از دو مثبت**.",
    "A 25-YEAR-OLD with high-risk behaviour OVER THE PAST TWO YEARS and a POSITIVE HIV Ab ELISA.\n\n"
    "WARNING, COUNT THEM: ONE POSITIVE, so repeat the ELISA.\n\n"
    "AND THIS QUESTION HIDES A TIMING TRAP WORTH SEEING. The p24 option looks scientific at first "
    "glance, but THE TIMING RULES IT OUT:\n\n"
    "THE p24 ANTIGEN IS THE VIRAL CORE PROTEIN AND CIRCULATES FREE IN BLOOD ONLY DURING THE ACUTE "
    "WINDOW — from about week two until antibody is made. AFTER SEROCONVERSION, ANTIBODIES BIND p24 "
    "INTO IMMUNE COMPLEXES AND IT CLEARS FROM THE BLOOD.\n\n"
    "HERE THE EXPOSURE WAS 'OVER THE PAST TWO YEARS' AND ANTIBODY IS ALREADY POSITIVE — so "
    "seroconversion happened long ago. p24 at this stage is probably negative and adds nothing.\n\n"
    "AND THE OTHER TWO? HIV RNA PCR is the most sensitive but expensive, and is not the next "
    "screening step. The WESTERN BLOT is the right step but AFTER TWO POSITIVES.",
    ["پاسخ صحیح — یک الایزای مثبت تکرار می‌شود، حتی وقتی احتمال پیش‌آزمون بالاست.",
     "HIV RNA PCR حساس‌ترین است ولی گران، و اقدام غربالگری بعدی نیست.",
     "وسترن بلات گام درستی در جای غلط است؛ جایش پس از دو مثبت است.",
     "دام زمانی — p24 پس از سرکونورژن از خون پاک می‌شود و تماس اینجا دو سال پیش بوده است."],
    ["Correct — a single positive ELISA is repeated, even when the pre-test probability is high.",
     "HIV RNA PCR is the most sensitive but expensive, and is not the next screening step.",
     "The Western blot is the right step in the wrong place; it belongs after two positives.",
     "A timing trap — p24 clears from the blood after seroconversion, and the exposure here was two years ago."])

_one_positive(
    "book:681", "easy",
    ["**کوتاه‌ترین صورت ممکن: رفتار پرخطر، الایزای مثبت، اقدام بعدی؟**",
     "⚠️ **و دو گزینه‌ی این سؤال اصلاً تست تشخیصی نیستند: شمارش CD4 و بار ویروسی.**",
     "**شمارش CD4 برای مرحله‌بندی فرد تشخیص‌داده‌شده است، نه برای تشخیص.**",
     "**CD4 پایین علل بی‌شماری دارد: عفونت حاد ویروسی، شیمی‌درمانی، سوءتغذیه، استروئید.**",
     "**و بار ویروسی برای پایش پاسخ به درمان است، نه ابزار غربالگری.**"],
    ["The shortest possible form: high-risk behaviour, positive ELISA, next step?",
     "WARNING, AND TWO OF THIS QUESTION'S OPTIONS ARE NOT DIAGNOSTIC TESTS AT ALL: the CD4 count and the viral load.",
     "The CD4 count is for staging someone already diagnosed, not for diagnosing.",
     "A low CD4 has countless causes: acute viral infection, chemotherapy, malnutrition, steroids.",
     "And the viral load is for monitoring the response to treatment, not a screening tool."],
    "کوتاه‌ترین صورت ممکن این مسئله: **رفتار پرخطر، الایزای HIV-1 مثبت، اقدام بعدی؟**\n\n"
    "⚠️ **بشمارید: یک مثبت ← تکرار الایزا.**\n\n"
    "**و این سؤال از زاویه‌ی تازه‌ای آموزنده است: دو گزینه از چهار گزینه اصلاً تست "
    "تشخیصی نیستند.**\n\n"
    "**شمارش CD4** — ⚠️ این **ابزار مرحله‌بندی و پیگیری** است، نه تشخیص. CD4 به شما "
    "می‌گوید **بیماری چقدر پیشرفته است**، نه اینکه **آیا وجود دارد**. و CD4 پایین "
    "**اختصاصی HIV نیست**: عفونت حاد ویروسی، شیمی‌درمانی، کورتیکواستروئید، سوءتغذیه‌ی "
    "شدید و بدخیمی‌های خونی همگی آن را پایین می‌آورند.\n\n"
    "**اندازه‌گیری بار ویروسی** — این هم ابزار **پایش پاسخ به درمان** است. درست است که "
    "می‌تواند در عفونت حاد کمک تشخیصی کند، ولی به‌عنوان **گام بعدیِ یک الایزای مثبت** "
    "جای آن نیست: گران است و در الگوریتم غربالگری قرار ندارد.\n\n"
    "**قاعده‌ی مفهومی که این را ماندگار می‌کند:**\n\n"
    "> **تست تشخیصی می‌گوید «آیا هست؟» · تست مرحله‌بندی می‌گوید «چقدر پیشرفته است؟» · "
    "تست پایش می‌گوید «درمان کار می‌کند؟»**\n\n"
    "**استفاده از هر کدام در جای دیگری، هم پول را هدر می‌دهد و هم می‌تواند گمراه کند.**\n\n"
    "**و گزینه‌ی وسترن بلات؟** گام درستی است ولی **پس از دو مثبت**، نه یکی.",
    "The shortest possible form of the problem: HIGH-RISK BEHAVIOUR, POSITIVE HIV-1 ELISA, NEXT STEP?\n\n"
    "WARNING, COUNT THEM: ONE POSITIVE, so repeat the ELISA.\n\n"
    "AND THIS QUESTION TEACHES FROM A NEW ANGLE: TWO OF THE FOUR OPTIONS ARE NOT DIAGNOSTIC TESTS "
    "AT ALL.\n\n"
    "THE CD4 COUNT — WARNING, this is a STAGING AND FOLLOW-UP tool, not a diagnostic one. CD4 tells "
    "you HOW ADVANCED the disease is, not WHETHER IT EXISTS. And a low CD4 IS NOT SPECIFIC TO HIV: "
    "acute viral infection, chemotherapy, corticosteroids, severe malnutrition and haematological "
    "malignancy all lower it.\n\n"
    "MEASURING THE VIRAL LOAD — likewise a MONITORING tool. True, it can help diagnostically in "
    "acute infection, but as the NEXT STEP AFTER A POSITIVE ELISA it has no place: it is expensive "
    "and not part of the screening algorithm.\n\n"
    "THE CONCEPTUAL RULE THAT MAKES THIS STICK:\n\n"
    "> A DIAGNOSTIC TEST ASKS 'IS IT THERE?' · A STAGING TEST ASKS 'HOW ADVANCED IS IT?' · A "
    "MONITORING TEST ASKS 'IS TREATMENT WORKING?'\n\n"
    "USING ANY OF THEM IN ANOTHER'S PLACE WASTES MONEY AND CAN MISLEAD.\n\n"
    "AND THE WESTERN BLOT OPTION? The right step, but AFTER TWO POSITIVES, not one.",
    ["وسترن بلات گام درستی در جای غلط است؛ جایش پس از دو مثبت است.",
     "شمارش CD4 ابزار مرحله‌بندی است نه تشخیص، و CD4 پایین اختصاصی HIV نیست.",
     "بار ویروسی ابزار پایش پاسخ به درمان است و در الگوریتم غربالگری جایی ندارد.",
     "پاسخ صحیح — یک الایزای مثبت باید تکرار شود؛ این ارزان‌ترین و منطقی‌ترین گام است."],
    ["The Western blot is the right step in the wrong place; it belongs after two positives.",
     "The CD4 count is a staging tool, not a diagnostic one, and a low CD4 is not specific to HIV.",
     "The viral load is a treatment-monitoring tool and has no place in the screening algorithm.",
     "Correct — a single positive ELISA must be repeated; it is the cheapest and most logical step."])

_one_positive(
    "book:682", "medium",
    ["**این سؤال همان قاعده را در بستر پیگیری پس از نیدل‌استیک می‌آزماید.**",
     "⚠️ **گزینه‌ی «شروع درمان آنتی‌رتروویرال» اینجا فاجعه‌بار است.**",
     "**شروع ART بر پایه‌ی یک تست غربالگری یعنی درمان مادام‌العمر برای تشخیص اثبات‌نشده.**",
     "**و سه ماه پس از مواجهه، پنجره بسته شده و سرولوژی قابل اتکاست — پس تفسیر ساده است.**",
     "**ولی «قابل اتکا» با «قطعی با یک بار» یکی نیست؛ الگوریتم همچنان دو مرحله دارد.**"],
    ["This item tests the same rule in the setting of post-needlestick follow-up.",
     "WARNING: the option 'start antiretroviral therapy' would be disastrous here.",
     "Starting ART on a single screening test means lifelong treatment for an unproven diagnosis.",
     "And three months after exposure the window has closed and serology is reliable, so interpretation is simple.",
     "But 'reliable' is not the same as 'definitive on one test'; the algorithm still has two stages."],
    "**خانم پرستار** که **۳ ماه قبل** نیدل‌استیک از بیمار HIV مثبت داشته، **پروفیلاکسی "
    "نگرفته**، و حالا **الایزای HIV-1 مثبت** دارد.\n\n"
    "⚠️ **بشمارید: یک مثبت ← تکرار الایزا.**\n\n"
    "**نکته‌ی زمانی مثبت این سناریو:** سه ماه پس از مواجهه، **پنجره‌ی سرولوژیک بسته شده "
    "است** (آنتی‌بادی از هفته‌ی ۳ تا ۱۲، اکثریت تا ۶). پس یک تست منفی در این مقطع "
    "معنادار بود، و یک تست مثبت هم **قابل اتکا** است.\n\n"
    "**ولی «قابل اتکا» با «قطعی با یک بار» یکی نیست.** الگوریتم همچنان دو مرحله دارد، "
    "چون خطای فنی و جابه‌جایی نمونه به زمان‌بندی کاری ندارند.\n\n"
    "⚠️ **و حالا خطرناک‌ترین گزینه: «شروع درمان آنتی‌رتروویرال».**\n\n"
    "**چرا فاجعه‌بار است؟**\n\n"
    "**۱)** ART یک درمان **مادام‌العمر** است. شروع آن یعنی تعهد به سال‌ها دارو.\n\n"
    "**۲)** داروها **عوارض واقعی** دارند: سمیت کلیوی، اختلال چربی، تداخل دارویی.\n\n"
    "**۳)** و مهم‌تر از همه: اگر تشخیص **غلط** باشد، این فرد برای بیماری‌ای که ندارد "
    "درمان می‌شود، با تمام پیامدهای روانی و اجتماعی‌اش.\n\n"
    "**قاعده: هرگز درمان مادام‌العمر را بر پایه‌ی یک تست غربالگری شروع نکنید.**\n\n"
    "**و دو گزینه‌ی دیگر؟** **وسترن بلات** پس از دو مثبت، و **بار ویروسی** ابزار پایش "
    "است نه گام بعدی الگوریتم.",
    "A NURSE who had a NEEDLESTICK THREE MONTHS AGO from an HIV-positive patient, TOOK NO "
    "PROPHYLAXIS, and now has a POSITIVE HIV-1 ELISA.\n\n"
    "WARNING, COUNT THEM: ONE POSITIVE, so repeat the ELISA.\n\n"
    "THE HELPFUL TIMING POINT HERE: three months after exposure THE SEROLOGICAL WINDOW HAS CLOSED "
    "(antibody from week 3 to 12, most by 6). So a negative test at this point would have been "
    "meaningful, and a positive one is RELIABLE.\n\n"
    "BUT 'RELIABLE' IS NOT 'DEFINITIVE ON ONE TEST'. The algorithm still has two stages, because "
    "technical error and sample mix-up are indifferent to timing.\n\n"
    "WARNING, AND NOW THE MOST DANGEROUS OPTION: 'START ANTIRETROVIRAL THERAPY'.\n\n"
    "WHY WOULD THAT BE DISASTROUS?\n\n"
    "1) ART is a LIFELONG treatment. Starting it commits the person to years of medication.\n\n"
    "2) The drugs have REAL ADVERSE EFFECTS: renal toxicity, lipid disturbance, drug interactions.\n\n"
    "3) And above all: if the diagnosis is WRONG, this person is treated for a disease she does not "
    "have, with every psychological and social consequence that follows.\n\n"
    "THE RULE: NEVER START A LIFELONG TREATMENT ON THE BASIS OF ONE SCREENING TEST.\n\n"
    "AND THE OTHER TWO? The WESTERN BLOT after two positives, and the VIRAL LOAD is a monitoring "
    "tool, not the algorithm's next step.",
    ["وسترن بلات گام درستی در جای غلط است؛ جایش پس از دو مثبت است.",
     "بار ویروسی ابزار پایش پاسخ به درمان است، نه گام بعدی الگوریتم تشخیصی.",
     "پاسخ صحیح — یک الایزای مثبت تکرار می‌شود، حتی سه ماه پس از مواجهه‌ی واقعی.",
     "خطرناک‌ترین گزینه — شروع درمان مادام‌العمر بر پایه‌ی یک تست غربالگری هرگز پذیرفتنی نیست."],
    ["The Western blot is the right step in the wrong place; it belongs after two positives.",
     "The viral load is a treatment-monitoring tool, not the diagnostic algorithm's next step.",
     "Correct — a single positive ELISA is repeated, even three months after a real exposure.",
     "The most dangerous option — starting a lifelong treatment on one screening test is never acceptable."])


# ================================== testing chain: TWO positives -> confirm
add("book:678", "case", "medium",
 "غربالگری بانک خون در فرد **کم‌خطر و بی‌علامت** ← تکرار الایزا، و **اگر باز مثبت بود**، تست تأییدی.",
 "A blood-bank screen in a LOW-RISK, ASYMPTOMATIC donor: repeat the ELISA, and IF STILL POSITIVE, confirm.",
 CHAIN_FA + [
  "**این سؤال کل الگوریتم را در یک گزینه می‌خواهد، نه فقط گام بعدی را.**",
  "⚠️ **و شرط «در صورت مثبت بودن» همان چیزی است که گزینه‌ی درست را می‌سازد.**",
  "**بیمار کم‌خطر و بی‌علامت است، پس احتمال مثبت کاذب اینجا بیشترین مقدار خود را دارد.**",
  "**ارزش اخباری مثبت در جمعیت اهداکننده‌ی خون بسیار پایین است — این ریاضیات بیز است.**",
  "**ولی گزینه‌ای که می‌گوید «در صورت منفی بودن تشخیص را رد کن» ناقص است، نه غلط.**",
  "**چون اگر تکرار مثبت شود، آن گزینه هیچ نمی‌گوید که بعد چه باید کرد.**",
 ],
 CHAIN_EN + [
  "This question asks for the WHOLE algorithm in one option, not merely the next step.",
  "WARNING, AND THE CONDITION 'IF STILL POSITIVE' IS WHAT MAKES THE RIGHT OPTION RIGHT.",
  "The donor is low-risk and asymptomatic, so the chance of a false positive is at its highest here.",
  "The positive predictive value in a blood-donor population is very low — that is Bayes' arithmetic.",
  "But the option saying 'exclude the diagnosis if negative' is INCOMPLETE rather than wrong.",
  "Because if the repeat is positive, that option says nothing about what to do next.",
 ],
 "**مرد ۴۵ ساله**، اهداکننده‌ی خون، **بی‌علامت** و **بدون سابقه‌ی رفتار پرخطر**، که "
 "غربالگری بانک خون ELISA HIV 1&2 او **مثبت** شده است.\n\n"
 "⚠️ **این سؤال با بقیه فرق دارد: کل الگوریتم را در یک گزینه می‌خواهد، نه فقط گام "
 "بعدی را.**\n\n"
 "**پاسخ: تکرار ELISA، و در صورت مثبت بودن، انجام وسترن بلات HIV-1.**\n\n"
 "**و اول بفهمیم چرا احتمال مثبت کاذب اینجا بیشترین مقدار خود را دارد:**\n\n"
 "این فرد **اهداکننده‌ی خون** است — یعنی از پیش غربال شده، سالم، بی‌علامت، و بدون "
 "عامل خطر. **شیوع HIV در این جمعیت بسیار پایین است.** و وقتی شیوع پایین باشد، حتی یک "
 "تست با اختصاصیت ۹۹٫۵ درصد هم **ارزش اخباری مثبت پایینی** دارد. ⚠️ **این ریاضیات بیز "
 "است، نه ضعف آزمایش** — و همان دلیلی است که غربالگری همگانی همیشه به تست تأییدی نیاز "
 "دارد.\n\n"
 "**حالا چهار گزینه را بسنجیم:**\n\n"
 "**«تکرار و رد تشخیص در صورت منفی بودن»** — ⚠️ این گزینه **ناقص است، نه غلط**. نیمه‌ی "
 "اولش درست است (تکرار کن) و نیمه‌ی دومش هم درست است (اگر منفی شد، تمام). **ولی هیچ "
 "نمی‌گوید اگر مثبت ماند چه کنیم** — و دقیقاً همان حالت است که کار پزشکی می‌طلبد. "
 "**یک الگوریتم ناقص، الگوریتم نیست.**\n\n"
 "**«تکرار و در صورت منفی بودن، PCR»** — این **وارونه** است. اگر تکرار منفی شود، ماجرا "
 "**تمام** است؛ انجام PCR گران روی نمونه‌ای که دو بار منفی شده، بی‌معنی است.\n\n"
 "**«انجام مستقیم وسترن بلات»** — گام تکرارِ ارزان را **حذف** کرده و مستقیم سراغ تست "
 "گران رفته است.\n\n"
 "**«تکرار، و در صورت مثبت بودن، وسترن بلات»** — ✅ **کامل و به‌ترتیب درست.**\n\n"
 "⚠️ **و به‌روزرسانی: امروز آن گام تأییدی، تست تفکیک آنتی‌بادی HIV-1 از HIV-2 است، نه "
 "وسترن بلات که CDC از ۲۰۱۴ کنارش گذاشت.**",
 "A 45-YEAR-OLD MAN, a blood donor, ASYMPTOMATIC and with NO HIGH-RISK HISTORY, whose blood-bank "
 "HIV 1&2 ELISA screen came back POSITIVE.\n\n"
 "WARNING, THIS QUESTION DIFFERS FROM THE OTHERS: it asks for THE WHOLE ALGORITHM in one option, "
 "not merely the next step.\n\n"
 "THE ANSWER: repeat the ELISA, and IF STILL POSITIVE, perform an HIV-1 Western blot.\n\n"
 "FIRST, UNDERSTAND WHY THE CHANCE OF A FALSE POSITIVE IS AT ITS HIGHEST HERE:\n\n"
 "This man is a BLOOD DONOR — pre-screened, healthy, asymptomatic and without risk factors. HIV "
 "PREVALENCE IN THAT POPULATION IS VERY LOW. And when prevalence is low, even a test with 99.5 per "
 "cent specificity has a LOW POSITIVE PREDICTIVE VALUE. WARNING: THAT IS BAYES' ARITHMETIC, NOT A "
 "FAULT OF THE ASSAY — and it is precisely why universal screening always needs confirmation.\n\n"
 "NOW WEIGH THE FOUR OPTIONS:\n\n"
 "'REPEAT AND EXCLUDE IF NEGATIVE' — WARNING, this option is INCOMPLETE RATHER THAN WRONG. Its "
 "first half is right (repeat) and its second half is right (if negative, done). BUT IT SAYS "
 "NOTHING ABOUT WHAT TO DO IF IT STAYS POSITIVE — which is exactly the case that requires medical "
 "work. AN INCOMPLETE ALGORITHM IS NOT AN ALGORITHM.\n\n"
 "'REPEAT, AND IF NEGATIVE, PCR' — this is INVERTED. If the repeat is negative the matter is "
 "CLOSED; running an expensive PCR on a twice-negative sample is meaningless.\n\n"
 "'GO STRAIGHT TO WESTERN BLOT' — this DROPS the cheap repeat step and goes straight to the "
 "expensive test.\n\n"
 "'REPEAT, AND IF POSITIVE, WESTERN BLOT' — CORRECT: complete and in the right order.\n\n"
 "WARNING, AND THE UPDATE: today that confirmatory step is an HIV-1/HIV-2 antibody differentiation "
 "assay, not the Western blot, which the CDC abandoned in 2014.",
 ["ناقص است نه غلط — نمی‌گوید اگر تکرار مثبت ماند چه باید کرد، و همان حالت کار می‌طلبد.",
  "وارونه است — اگر تکرار منفی شود ماجرا تمام است و PCR گران بی‌معنی است.",
  "پاسخ صحیح — تکرار الایزا و در صورت مثبت ماندن، تست تأییدی: الگوریتم کامل و به‌ترتیب.",
  "گام ارزان تکرار را حذف کرده و مستقیم سراغ تست گران رفته است."],
 ["Incomplete rather than wrong — it says nothing about a repeat that stays positive, and that is the case that matters.",
  "Inverted — if the repeat is negative the matter is closed and an expensive PCR is meaningless.",
  "Correct — repeat the ELISA and, if it stays positive, confirm: the complete algorithm in the right order.",
  "This drops the cheap repeat step and goes straight to the expensive test."],
 "**ارزش اخباری مثبت در اهداکننده‌ی خون پایین است — پس تکرار، و فقط بعد تأیید.**",
 "The positive predictive value in a blood donor is low, so repeat first and only then confirm.",
 [CDCLAB, H202])

add("book:692", "recall", "easy",
 "**دو** الایزای مثبت ← حالا و فقط حالا **تست تأییدی** (وسترن بلات در الگوریتم آن دوره).",
 "TWO positive ELISAs: now, and only now, the CONFIRMATORY TEST (the Western blot in that era's algorithm).",
 CHAIN_FA + [
  "**این قرینه‌ی سؤال‌های «یک مثبت» است و پاسخ متفاوتی دارد — کلمه‌ی کلیدی «دو نوبت» است.**",
  "⚠️ **دو الایزای مثبت یعنی خطای فنی و جابه‌جایی نمونه از میدان خارج شده‌اند.**",
  "**آنچه باقی می‌ماند احتمال واکنش متقاطع غیراختصاصی است، و آن را فقط تست اختصاصی رد می‌کند.**",
  "**تست تأییدی پروتئین‌های ویروسی را جدا می‌کند و آنتی‌بادی علیه هرکدام را جداگانه می‌بیند.**",
  "**pantibody علیه gp120، gp41 و p24 با هم، الگویی می‌سازد که واکنش متقاطع نمی‌سازد.**",
 ],
 CHAIN_EN + [
  "This is the mirror of the 'one positive' questions and has a different answer — the key words are 'on two occasions'.",
  "WARNING: TWO POSITIVE ELISAs MEAN TECHNICAL ERROR AND SAMPLE MIX-UP HAVE BEEN ELIMINATED.",
  "What remains is the possibility of non-specific cross-reaction, and only a specific test excludes that.",
  "The confirmatory test separates the viral proteins and looks for antibody to each one individually.",
  "Antibody to gp120, gp41 and p24 together forms a pattern that cross-reaction does not produce.",
 ],
 "**فردی با اعتیاد تزریقی، الایزای HIV در دو نوبت مثبت.**\n\n"
 "⚠️ **بشمارید: دو مثبت ← حالا و فقط حالا تست تأییدی. پاسخ: وسترن بلات.**\n\n"
 "**این سؤال قرینه‌ی همه‌ی سؤال‌های قبلی است، و تفاوتش در دو کلمه است: «دو نوبت».**\n\n"
 "**چرا دو مثبت وضعیت را عوض می‌کند؟ چون دو منبع خطا را حذف می‌کند:**\n\n"
 "**۱) خطای فنی** — واکنش‌گر معیوب یا اجرای اشتباه، به‌ندرت دو بار پشت سر هم تکرار "
 "می‌شود.\n\n"
 "**۲) جابه‌جایی نمونه** — احتمال اینکه دو بار لوله‌ی اشتباه برداشته شود ناچیز است.\n\n"
 "**آنچه باقی می‌ماند فقط یک احتمال است: واکنش متقاطع غیراختصاصی** — یعنی آنتی‌بادی‌های "
 "بیمار به چیزی در سیستم آزمایش می‌چسبند که HIV نیست.\n\n"
 "⚠️ **و تنها راه رد کردن آن، یک تست اختصاصی است، نه تکرار سوم همان تست غیراختصاصی.**\n\n"
 "**وسترن بلات چگونه این کار را می‌کند؟** پروتئین‌های ویروس را بر اساس وزن مولکولی "
 "**جدا می‌کند** و می‌بیند سرم بیمار علیه **کدام‌یک** آنتی‌بادی دارد. حضور هم‌زمان "
 "آنتی‌بادی علیه **gp120، gp41 و p24** الگویی می‌سازد که یک واکنش متقاطع تصادفی "
 "نمی‌تواند بسازد.\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟** **PCR** حساس است ولی گران و در الگوریتم آن دوره جای "
 "تأییدی نداشت. **شمارش CD4** ابزار مرحله‌بندی است نه تشخیص. **آنتی‌ژن p24** برای "
 "عفونت حاد است و پس از سرکونورژن پاک می‌شود.\n\n"
 "⚠️ **به‌روزرسانی: امروز گام تأییدی، تست تفکیک آنتی‌بادی HIV-1 از HIV-2 است.**",
 "SOMEONE WITH INJECTING DRUG USE and an HIV ELISA POSITIVE ON TWO OCCASIONS.\n\n"
 "WARNING, COUNT THEM: TWO POSITIVES, so now and only now the confirmatory test. Answer: the "
 "Western blot.\n\n"
 "THIS IS THE MIRROR OF EVERY PREVIOUS QUESTION, and the difference lies in two words: 'ON TWO "
 "OCCASIONS'.\n\n"
 "WHY DOES A SECOND POSITIVE CHANGE THINGS? Because it eliminates two sources of error:\n\n"
 "1) TECHNICAL ERROR — a faulty reagent or a mis-run rarely repeats twice in a row.\n\n"
 "2) SAMPLE MIX-UP — the chance of picking the wrong tube twice is negligible.\n\n"
 "ONLY ONE POSSIBILITY REMAINS: NON-SPECIFIC CROSS-REACTION — the patient's antibodies binding "
 "something in the assay that is not HIV.\n\n"
 "WARNING, AND THE ONLY WAY TO EXCLUDE THAT IS A SPECIFIC TEST, not a third run of the same "
 "non-specific one.\n\n"
 "HOW DOES THE WESTERN BLOT DO IT? It SEPARATES the viral proteins by molecular weight and sees "
 "WHICH of them the patient's serum has antibody against. Antibody to gp120, gp41 AND p24 together "
 "forms a pattern that a chance cross-reaction cannot produce.\n\n"
 "AND WHY NOT THE OTHER THREE? PCR is sensitive but expensive and was not the confirmatory step in "
 "that era's algorithm. The CD4 COUNT is a staging tool, not diagnostic. The p24 ANTIGEN is for "
 "acute infection and clears after seroconversion.\n\n"
 "WARNING, THE UPDATE: today the confirmatory step is an HIV-1/HIV-2 antibody differentiation assay.",
 ["پاسخ صحیح — پس از دو الایزای مثبت، تست تأییدی اختصاصی گام درست است.",
  "PCR حساس است ولی گران، و در الگوریتم آن دوره جایگاه تست تأییدی نداشت.",
  "شمارش CD4 ابزار مرحله‌بندی فرد تشخیص‌داده‌شده است، نه تست تأییدی تشخیص.",
  "آنتی‌ژن p24 برای پنجره‌ی عفونت حاد است و پس از سرکونورژن از خون پاک می‌شود."],
 ["Correct — after two positive ELISAs the specific confirmatory test is the right step.",
  "PCR is sensitive but expensive, and was not the confirmatory step in that era's algorithm.",
  "The CD4 count is a staging tool for someone already diagnosed, not a confirmatory test.",
  "The p24 antigen is for the acute window and clears from the blood after seroconversion."],
 "**دو مثبت یعنی خطای فنی حذف شده؛ آنچه می‌ماند واکنش متقاطع است و فقط تست اختصاصی ردش می‌کند.**",
 "Two positives eliminate technical error; what remains is cross-reaction, which only a specific test excludes.",
 [CDCLAB, H202])

add("book:693", "case", "medium",
 "غربالگری بانک خون + **تکرار مثبت** = دو مثبت ← گام تأییدی. **کلمه‌ی «تکرار» را در متن پیدا کنید.**",
 "A blood-bank screen PLUS A POSITIVE REPEAT is two positives, so the confirmatory step follows. FIND THE WORD 'REPEAT' IN THE STEM.",
 CHAIN_FA + [
  "**این سؤال دقیقاً همان سناریوی اهداکننده‌ی خون است، ولی یک گام جلوتر.**",
  "⚠️ **جمله‌ی کلیدی: «نتیجه‌ی تکرار تست EIA نیز مثبت گزارش شده است».**",
  "**آن یک جمله، سؤال را از خوشه‌ی «یک مثبت» به خوشه‌ی «دو مثبت» منتقل می‌کند.**",
  "**پس اینجا گزینه‌ی «تکرار چهار هفته بعد» دیگر درست نیست — تکرار انجام شده.**",
  "**و گزینه‌ی تست سریع هم بی‌معنی است: تست سریع خودش یک غربالگری دیگر است.**",
  "**سه تست غربالگری پشت سر هم، به اندازه‌ی یکی از آن‌ها اختصاصی است.**",
 ],
 CHAIN_EN + [
  "This is exactly the blood-donor scenario again, but one step further along.",
  "WARNING, THE KEY SENTENCE: 'the repeat EIA was also reported positive'.",
  "That one sentence moves the question from the 'one positive' cluster to the 'two positives' cluster.",
  "So the option 'repeat in four weeks' is no longer right — the repeat has already happened.",
  "And the rapid-test option is meaningless: a rapid test is itself another screening test.",
  "Three screening tests in a row are exactly as specific as one of them.",
 ],
 "**مرد جوان** از طرف بانک خون، **بدون رفتار پرخطر**، **بی‌علامت**، با تست غربالگری "
 "مثبت. ⚠️ **و جمله‌ی کلیدی: «نتیجه‌ی تکرار تست EIA نیز مثبت گزارش شده است».**\n\n"
 "**آن یک جمله کل سؤال را جابه‌جا می‌کند.**\n\n"
 "**بشمارید: غربالگری مثبت + تکرار مثبت = دو مثبت ← گام تأییدی. پاسخ: وسترن بلات "
 "HIV-1.**\n\n"
 "⚠️ **این سؤال را با سؤال اهداکننده‌ی خون قبلی (book:678) کنار هم بگذارید — یک جفت "
 "آموزشی عالی می‌سازند:**\n\n"
 "**آنجا فقط یک مثبت بود، پس پاسخ «تکرار کن و بعد تأیید کن» بود.**\n\n"
 "**اینجا تکرار انجام شده، پس پاسخ مستقیماً «تأیید کن» است.**\n\n"
 "**همان سناریو، همان بیمار، پاسخ متفاوت — و تنها تفاوت، یک جمله در متن است.** این "
 "دقیقاً همان مهارتی است که این خوشه می‌آزماید: **خواندن دقیق متن، نه حفظ کردن یک "
 "پاسخ.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**تست HIV Rapid** — ⚠️ این ظریف‌ترین گزینه است. تست سریع **خودش یک تست غربالگری "
 "دیگر** است، با همان محدودیت اختصاصیت. **سه تست غربالگری پشت سر هم، به اندازه‌ی یکی "
 "از آن‌ها اختصاصی است** — چون همگی همان نوع خطا را می‌کنند.\n\n"
 "**تکرار EIA چهار هفته بعد** — تکرار **از قبل انجام شده**. تکرار سوم چیزی اضافه "
 "نمی‌کند و فقط چهار هفته اضطراب می‌سازد.\n\n"
 "**آنتی‌ژن p24** — برای **عفونت حاد** است. این بیمار بی‌علامت است و آنتی‌بادی از قبل "
 "مثبت شده، یعنی سرکونورژن گذشته است.",
 "A YOUNG MAN referred by the blood bank, WITH NO HIGH-RISK BEHAVIOUR, ASYMPTOMATIC, with a "
 "positive screening test. WARNING, AND THE KEY SENTENCE: 'THE REPEAT EIA WAS ALSO REPORTED "
 "POSITIVE'.\n\n"
 "That one sentence moves the whole question.\n\n"
 "COUNT THEM: a positive screen PLUS a positive repeat is TWO POSITIVES, so the confirmatory step "
 "follows. Answer: HIV-1 Western blot.\n\n"
 "WARNING, PLACE THIS BESIDE THE EARLIER BLOOD-DONOR QUESTION (book:678) — together they make an "
 "excellent teaching pair:\n\n"
 "THERE, only one positive had happened, so the answer was 'repeat, then confirm'.\n\n"
 "HERE, the repeat has happened, so the answer is simply 'confirm'.\n\n"
 "THE SAME SCENARIO, THE SAME PATIENT, A DIFFERENT ANSWER — and the only difference is one sentence "
 "in the stem. That is precisely the skill this cluster tests: READING THE STEM CAREFULLY RATHER "
 "THAN MEMORISING AN ANSWER.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "A RAPID HIV TEST — WARNING, the subtlest option. A rapid test IS ITSELF ANOTHER SCREENING TEST "
 "with the same specificity limits. THREE SCREENING TESTS IN A ROW ARE EXACTLY AS SPECIFIC AS ONE, "
 "because they all make the same kind of error.\n\n"
 "REPEAT THE EIA IN FOUR WEEKS — the repeat HAS ALREADY BEEN DONE. A third adds nothing and merely "
 "creates four weeks of anxiety.\n\n"
 "p24 ANTIGEN — for ACUTE infection. This patient is asymptomatic and antibody is already positive, "
 "so seroconversion is past.",
 ["تست سریع خودش یک غربالگری دیگر است؛ سه تست غربالگری به اندازه‌ی یکی اختصاصی‌اند.",
  "تکرار از قبل انجام شده است؛ تکرار سوم چیزی اضافه نمی‌کند و فقط اضطراب می‌سازد.",
  "پاسخ صحیح — غربالگری مثبت به‌علاوه‌ی تکرار مثبت یعنی دو مثبت، پس گام تأییدی.",
  "آنتی‌ژن p24 برای عفونت حاد است؛ این بیمار بی‌علامت است و سرکونورژن گذشته است."],
 ["A rapid test is itself another screen; three screening tests are exactly as specific as one.",
  "The repeat has already been done; a third adds nothing and merely creates anxiety.",
  "Correct — a positive screen plus a positive repeat is two positives, so the confirmatory step follows.",
  "The p24 antigen is for acute infection; this patient is asymptomatic and seroconversion is past."],
 "**کلمه‌ی «تکرار» را در متن پیدا کنید — همان یک کلمه پاسخ را عوض می‌کند.**",
 "Find the word 'repeat' in the stem — that single word changes the answer.",
 [CDCLAB, H202])


# ================================== testing chain: the awkward results
add("book:683", "case", "medium",
 "مثبت، سپس منفی ← نتیجه **متناقض** است، نه منفی. **تکرار ۳ تا ۶ ماه بعد**، نه تست تأییدی.",
 "Positive then negative is a DISCORDANT result, not a negative one: repeat in 3 to 6 months, not a confirmatory test.",
 CHAIN_FA + [
  "**این سؤال حالت سومی را می‌آزماید که در خوشه فقط یک بار می‌آید: نتیجه‌ی متناقض.**",
  "⚠️ **یک نوبت مثبت و نوبت دوم منفی، یعنی مثبت اول به احتمال زیاد کاذب بوده.**",
  "**چون تست غربالگری بسیار حساس است: اگر واقعاً آنتی‌بادی وجود داشت، بار دوم هم می‌دید.**",
  "**پس تست تأییدی اینجا اندیکاسیون ندارد — چیزی برای تأیید کردن وجود ندارد.**",
  "⚠️ **ولی «به احتمال زیاد کاذب» با «قطعاً کاذب» یکی نیست، و اینجا یک احتمال باقی می‌ماند.**",
  "**اگر فرد در دوره‌ی پنجره باشد، آنتی‌بادی در حال ساخته شدن است و نتیجه‌ها نوسان می‌کنند.**",
  "**و این فرد معتاد تزریقی است، یعنی مواجهه‌ی مکرر و مداوم دارد.**",
  "**پس پیگیری لازم است: تکرار ۳ تا ۶ ماه بعد، که پنجره را کاملاً پوشش می‌دهد.**",
 ],
 CHAIN_EN + [
  "This item tests a third situation that appears only once in the cluster: a DISCORDANT result.",
  "WARNING: one positive followed by a negative means the first positive was probably false.",
  "Because the screening test is highly sensitive: if antibody were truly present, the second run would have seen it.",
  "So a confirmatory test is not indicated here — there is nothing to confirm.",
  "WARNING, BUT 'PROBABLY FALSE' IS NOT 'CERTAINLY FALSE', and one possibility remains.",
  "If the person is inside the window period, antibody is still rising and results can fluctuate.",
  "And this man injects drugs, meaning repeated and ongoing exposure.",
  "So follow-up is needed: repeat in 3 to 6 months, which covers the window completely.",
 ],
 "**آقای ۲۷ ساله معتاد تزریقی** که می‌گوید **یک نوبت آزمایش مثبت** داشته و **در نوبت "
 "دوم منفی** بوده.\n\n"
 "⚠️ **این حالت سوم است و در کل خوشه فقط یک بار می‌آید: نتیجه‌ی متناقض.**\n\n"
 "**پاسخ: تکرار تست ۳ تا ۶ ماه بعد.**\n\n"
 "**اول تفسیر کنیم:** تست غربالگری **بسیار حساس** است (بالای ۹۹ درصد). اگر واقعاً "
 "آنتی‌بادی در خون وجود داشت، **بار دوم هم آن را می‌دید**. پس مثبت اول **به احتمال "
 "زیاد کاذب** بوده — خطای فنی، جابه‌جایی نمونه، یا واکنش غیراختصاصی.\n\n"
 "**نتیجه‌ی اول: تست تأییدی اینجا اندیکاسیون ندارد.** وسترن بلات برای **تأیید یک نتیجه‌ی "
 "پایدارِ مثبت** است. وقتی نتیجه‌ها با هم نمی‌خوانند، **چیزی برای تأیید کردن وجود ندارد** "
 "و وسترن بلات به‌احتمال زیاد **نامشخص** درمی‌آید، که فقط سردرگمی اضافه می‌کند.\n\n"
 "⚠️ **ولی چرا «نیازی به پیگیری ندارد» هم غلط است؟ دو دلیل:**\n\n"
 "**۱) دوره‌ی پنجره.** اگر این فرد **همین اواخر** آلوده شده باشد، آنتی‌بادی **در حال "
 "ساخته شدن** است و سطحش نزدیک آستانه‌ی تشخیص نوسان می‌کند. در آن حالت نتیجه‌های "
 "متناقض دقیقاً همان چیزی است که انتظار می‌رود.\n\n"
 "**۲) مواجهه‌ی مداوم.** این فرد **معتاد تزریقی** است. حتی اگر امروز واقعاً منفی باشد، "
 "**فردا در معرض است**. پیگیری در این جمعیت یک اصل است، نه یک احتیاط.\n\n"
 "**و چرا بازه‌ی ۳ تا ۶ ماه؟** چون **پنجره‌ی سرولوژیک تا ۱۲ هفته (۳ ماه) طول می‌کشد** و "
 "تکرار در ۳ تا ۶ ماه آن را **کاملاً پوشش می‌دهد**.\n\n"
 "**و دو گزینه‌ی وسترن بلات؟** هر دو یک اشتباه را تکرار می‌کنند: تست تأییدی برای "
 "نتیجه‌ای که پایدار نیست.",
 "A 27-YEAR-OLD MAN WHO INJECTS DRUGS, reporting ONE POSITIVE TEST and a NEGATIVE SECOND ONE.\n\n"
 "WARNING, THIS IS THE THIRD SITUATION and it appears only once in the whole cluster: A DISCORDANT "
 "RESULT.\n\n"
 "THE ANSWER: repeat the test in 3 to 6 months.\n\n"
 "FIRST, INTERPRET IT: the screening test is HIGHLY SENSITIVE (over 99 per cent). If antibody were "
 "truly present in the blood, THE SECOND RUN WOULD HAVE SEEN IT TOO. So the first positive was "
 "PROBABLY FALSE — technical error, sample mix-up, or a non-specific reaction.\n\n"
 "FIRST CONSEQUENCE: A CONFIRMATORY TEST IS NOT INDICATED HERE. The Western blot exists to CONFIRM "
 "A CONSISTENTLY POSITIVE RESULT. When results disagree, THERE IS NOTHING TO CONFIRM, and the blot "
 "will most likely come back INDETERMINATE, adding only confusion.\n\n"
 "WARNING, BUT WHY IS 'NO FOLLOW-UP NEEDED' ALSO WRONG? Two reasons:\n\n"
 "1) THE WINDOW PERIOD. If this man was infected RECENTLY, antibody is STILL RISING and its level "
 "fluctuates around the detection threshold. In that case discordant results are exactly what one "
 "would expect.\n\n"
 "2) ONGOING EXPOSURE. He INJECTS DRUGS. Even if he is genuinely negative today, HE IS EXPOSED "
 "TOMORROW. Follow-up in this population is a principle, not a precaution.\n\n"
 "AND WHY 3 TO 6 MONTHS? Because THE SEROLOGICAL WINDOW LASTS UP TO 12 WEEKS (3 months), and a "
 "repeat at 3 to 6 months COVERS IT COMPLETELY.\n\n"
 "AND THE TWO WESTERN BLOT OPTIONS? Both repeat the same mistake: a confirmatory test for a result "
 "that is not consistent.",
 ["پاسخ صحیح — نتیجه‌ی متناقض تأیید نمی‌خواهد، پیگیری می‌خواهد؛ ۳ تا ۶ ماه پنجره را پوشش می‌دهد.",
  "وسترن بلات برای تأیید نتیجه‌ی پایدار مثبت است؛ اینجا احتمالاً نامشخص درمی‌آید.",
  "همان اشتباه با تست HIV-2 — وقتی نتیجه‌ها متناقض‌اند، چیزی برای تأیید وجود ندارد.",
  "غلط است — این فرد معتاد تزریقی است و مواجهه‌ی مداوم دارد؛ پیگیری در این جمعیت یک اصل است."],
 ["Correct — a discordant result needs follow-up, not confirmation; 3 to 6 months covers the window.",
  "The Western blot confirms a consistently positive result; here it would most likely be indeterminate.",
  "The same mistake with an HIV-2 blot — when results disagree there is nothing to confirm.",
  "Wrong — this man injects drugs and has ongoing exposure; follow-up in this population is a principle."],
 "**نتیجه‌ی متناقض تأیید نمی‌خواهد، پیگیری می‌خواهد.**",
 "A discordant result does not need confirmation; it needs follow-up.",
 [CDCLAB, H202])

add("book:690", "case", "hard",
 "وسترن بلات **نامشخص** ← هر کاری مفید است **بجز** تکرار الایزایی که از قبل مثبت است.",
 "An INDETERMINATE Western blot: everything helps EXCEPT repeating an ELISA that is already positive.",
 CHAIN_FA + [
  "**این سؤال ساختار «همه درست است بجز» دارد و سخت‌ترین سؤال خوشه است.**",
  "⚠️ **وسترن بلات نامشخص یعنی چند باند دیده شده ولی به معیار کامل نرسیده است.**",
  "**دو تفسیر دارد و باید هر دو را در نظر گرفت: سرکونورژن در حال وقوع، یا واکنش غیراختصاصی.**",
  "**اگر سرکونورژن در جریان باشد، باندها با گذشت زمان کامل می‌شوند — پس تکرار بلات منطقی است.**",
  "**اگر واکنش غیراختصاصی باشد، باندها هرگز کامل نمی‌شوند و ماه‌ها بعد هم همان‌اند.**",
  "⚠️ **و راه سریع تفکیک: تستی که به آنتی‌بادی وابسته نیست — یعنی p24 یا RNA.**",
  "**این دو همین امروز جواب می‌دهند و منتظر بلوغ پاسخ آنتی‌بادی نمی‌مانند.**",
  "**ولی تکرار الایزا هیچ اطلاعات تازه‌ای نمی‌دهد، چون از قبل مثبت است.**",
  "**تکرار یک تست غیراختصاصی که مثبت شده، فقط همان مثبت را دوباره نشان می‌دهد.**",
 ],
 CHAIN_EN + [
  "This item uses an 'all appropriate except' structure and is the hardest in the cluster.",
  "WARNING: AN INDETERMINATE WESTERN BLOT means some bands appeared but the full criteria were not met.",
  "It has two readings and both must be considered: seroconversion under way, or a non-specific reaction.",
  "If seroconversion is under way the bands complete with time — so repeating the blot is sensible.",
  "If it is a non-specific reaction the bands never complete and look the same months later.",
  "WARNING, AND THE FAST WAY TO SEPARATE THEM: a test that does not depend on antibody — p24 or RNA.",
  "Those two answer today and do not wait for the antibody response to mature.",
  "But repeating the ELISA adds no new information, because it is already positive.",
  "Repeating a non-specific test that came back positive simply shows the same positive again.",
 ],
 "**آقای ۳۷ ساله** پس از بازگشت از سفر با رفتار پرخطر: **ELISA مثبت**، و **وسترن بلات "
 "نامشخص (indeterminate)**. سؤال می‌پرسد **همه‌ی اقدامات مناسب است بجز** کدام.\n\n"
 "⚠️ **این سخت‌ترین سؤال خوشه است، چون باید سه گزینه را تأیید کنید و یکی را رد.**\n\n"
 "**اول: «نامشخص» یعنی چه؟** یعنی در وسترن بلات **چند باند ظاهر شده ولی به معیار کامل "
 "نرسیده است**. مثلاً فقط آنتی‌بادی علیه p24 دیده شده، بدون gp120 و gp41.\n\n"
 "**و این دو تفسیر کاملاً متفاوت دارد:**\n\n"
 "**تفسیر یک — سرکونورژن در حال وقوع:** بیمار **همین اواخر** آلوده شده و آنتی‌بادی‌ها "
 "**در حال ساخته شدن**اند. اول علیه پروتئین‌های هسته (p24)، بعد علیه پروتئین‌های پوششی "
 "(gp120، gp41). **در این حالت باندها با گذشت زمان کامل می‌شوند.**\n\n"
 "**تفسیر دو — واکنش غیراختصاصی:** یک واکنش متقاطع تصادفی. **در این حالت باندها هرگز "
 "کامل نمی‌شوند** و ماه‌ها بعد هم همان‌اند.\n\n"
 "⚠️ **پس هر اقدامی که این دو را از هم جدا کند، مناسب است. سه گزینه دقیقاً همین کار "
 "را می‌کنند:**\n\n"
 "**آنتی‌ژن p24** ✅ — به آنتی‌بادی **وابسته نیست** و همین امروز جواب می‌دهد. اگر مثبت "
 "باشد، عفونت اثبات می‌شود.\n\n"
 "**HIV RNA PCR کیفی** ✅ — حساس‌ترین و زودترین؛ از روز دهم مثبت است.\n\n"
 "**تکرار وسترن بلات ۴ تا ۶ هفته بعد** ✅ — به‌سرکونورژن **فرصت می‌دهد کامل شود**. اگر "
 "باندها کامل شدند، عفونت است؛ اگر همان ماندند، واکنش غیراختصاصی بوده.\n\n"
 "⚠️ **و گزینه‌ی نامناسب: «تکرار ELISA چهار تا شش هفته بعد».**\n\n"
 "**چرا بی‌فایده است؟ چون الایزا از قبل مثبت است.** تکرار یک تست **غیراختصاصی** که "
 "مثبت شده، فقط **همان مثبت را دوباره نشان می‌دهد**. هیچ اطلاعات تازه‌ای اضافه نمی‌کند "
 "و ابهام دقیقاً همان‌جا که بود باقی می‌ماند.\n\n"
 "**قاعده‌ی کلی که این را ماندگار می‌کند:** وقتی گیر کرده‌اید، **تست را عوض کنید، نه "
 "اینکه همان تست را تکرار کنید**.\n\n"
 "**و به‌روزرسانی امروزی:** چون CDC از ۲۰۱۴ وسترن بلات را کنار گذاشت، این وضعیت "
 "«نامشخص» عملاً حذف شده — الگوریتم امروز مستقیم از تست تفکیک به **HIV-1 RNA** می‌رود.",
 "A 37-YEAR-OLD MAN after a trip involving high-risk behaviour: POSITIVE ELISA and an INDETERMINATE "
 "WESTERN BLOT. The stem asks which action is NOT appropriate.\n\n"
 "WARNING, THIS IS THE HARDEST QUESTION IN THE CLUSTER, because you must validate three options and "
 "reject one.\n\n"
 "FIRST: WHAT DOES 'INDETERMINATE' MEAN? It means SOME BANDS APPEARED ON THE BLOT BUT THE FULL "
 "CRITERIA WERE NOT MET — for example antibody to p24 only, without gp120 and gp41.\n\n"
 "AND THAT HAS TWO ENTIRELY DIFFERENT READINGS:\n\n"
 "READING ONE — SEROCONVERSION UNDER WAY: the patient was infected RECENTLY and antibodies are "
 "STILL BEING MADE. First against core proteins (p24), later against envelope proteins (gp120, "
 "gp41). IN THAT CASE THE BANDS COMPLETE WITH TIME.\n\n"
 "READING TWO — A NON-SPECIFIC REACTION: a chance cross-reaction. IN THAT CASE THE BANDS NEVER "
 "COMPLETE and look identical months later.\n\n"
 "WARNING, SO ANY ACTION THAT SEPARATES THESE TWO IS APPROPRIATE. Three options do exactly that:\n\n"
 "p24 ANTIGEN — DOES NOT DEPEND ON ANTIBODY and answers today. If positive, infection is proven.\n\n"
 "QUALITATIVE HIV RNA PCR — the most sensitive and earliest; positive from day ten.\n\n"
 "REPEAT THE WESTERN BLOT IN 4 TO 6 WEEKS — GIVES SEROCONVERSION TIME TO COMPLETE. If the bands "
 "complete, it is infection; if they stay the same, it was non-specific.\n\n"
 "WARNING, AND THE INAPPROPRIATE OPTION: 'REPEAT THE ELISA IN FOUR TO SIX WEEKS'.\n\n"
 "WHY IS IT USELESS? BECAUSE THE ELISA IS ALREADY POSITIVE. Repeating a NON-SPECIFIC test that came "
 "back positive simply SHOWS THE SAME POSITIVE AGAIN. It adds no new information and leaves the "
 "ambiguity exactly where it was.\n\n"
 "THE GENERAL RULE THAT MAKES THIS STICK: when you are stuck, CHANGE THE TEST, do not repeat the "
 "same one.\n\n"
 "AND THE MODERN UPDATE: since the CDC abandoned the Western blot in 2014, this 'indeterminate' "
 "situation has largely disappeared — today's algorithm goes straight from the differentiation "
 "assay to HIV-1 RNA.",
 ["پاسخ صحیح (گزینه‌ی نامناسب) — الایزا از قبل مثبت است و تکرارش هیچ اطلاعات تازه‌ای نمی‌دهد.",
  "مناسب است — آنتی‌ژن p24 به آنتی‌بادی وابسته نیست و همین امروز ابهام را حل می‌کند.",
  "مناسب است — تکرار بلات به سرکونورژن فرصت می‌دهد باندها را کامل کند.",
  "مناسب است — RNA PCR حساس‌ترین و زودترین تست است و از روز دهم مثبت می‌شود."],
 ["Correct (the inappropriate option) — the ELISA is already positive and repeating it adds nothing new.",
  "Appropriate — the p24 antigen does not depend on antibody and resolves the ambiguity today.",
  "Appropriate — repeating the blot gives seroconversion time to complete the bands.",
  "Appropriate — RNA PCR is the most sensitive and earliest test, positive from day ten."],
 "**وقتی گیر کرده‌اید، تست را عوض کنید — نه اینکه همان تست را تکرار کنید.**",
 "When you are stuck, change the test — do not repeat the same one.",
 [CDCLAB, H202])


# ============================== acute infection: p24 is the answer, three times
def _p24(key, diff, extra_fa, extra_en, exp_fa, exp_en, why_fa, why_en):
    add(key, "case", diff,
        "تابلوی رتروویرال حاد در **پنجره‌ی آنتی‌بادی** ← نشانگری که به آنتی‌بادی وابسته نیست: **آنتی‌ژن p24**.",
        "An acute retroviral picture INSIDE THE ANTIBODY WINDOW needs a marker that does not depend on antibody: the p24 ANTIGEN.",
        CHAIN_FA[:6] + [
         "⚠️ **عفونت حاد HIV یک تابلوی شبه‌مونونوکلئوز است، ۲ تا ۶ هفته پس از تماس.**",
         "**تب، گلودرد، لنفادنوپاتی منتشر، میالژی، آرترالژی، سردرد و راش ماکولوپاپولر.**",
         "⚠️ **و نکته‌ی تعیین‌کننده: در روزهای نخست، آنتی‌بادی هنوز ساخته نشده است.**",
         "**پس یک تست آنتی‌بادیِ صرف در این پنجره کاذباً منفی می‌شود.**",
         "**ترتیب مثبت شدن: RNA از روز ۱۰، آنتی‌ژن p24 از هفته‌ی ۲، آنتی‌بادی از هفته‌ی ۳ تا ۱۲.**",
         "**آنتی‌ژن p24 پروتئین هسته‌ی ویروس است و مستقیماً خودِ ویروس را نشان می‌دهد.**",
         "⚠️ **و پس از سرکونورژن محو می‌شود، چون آنتی‌بادی‌ها آن را به کمپلکس ایمنی تبدیل می‌کنند.**",
         "**پس p24 دقیقاً همان پنجره‌ای را پوشش می‌دهد که تست آنتی‌بادی در آن کور است.**",
         "**در این مرحله بار ویروسی بسیار بالاست و بیمار بیشترین سرایت را دارد.**",
        ] + extra_fa,
        CHAIN_EN[:6] + [
         "WARNING: ACUTE HIV INFECTION IS A MONONUCLEOSIS-LIKE PICTURE, 2 to 6 weeks after exposure.",
         "Fever, sore throat, generalised lymphadenopathy, myalgia, arthralgia, headache and a maculopapular rash.",
         "WARNING, AND THE DECIDING POINT: in the first days ANTIBODY HAS NOT YET BEEN MADE.",
         "So an antibody-only test in that window is falsely negative.",
         "Order of positivity: RNA from day 10, p24 antigen from week 2, antibody from week 3 to 12.",
         "The p24 antigen is the viral core protein and shows the virus itself directly.",
         "WARNING, AND IT CLEARS AFTER SEROCONVERSION, because antibodies bind it into immune complexes.",
         "So p24 covers exactly the window in which an antibody test is blind.",
         "At this stage the viral load is very high and the patient is at their most infectious.",
        ] + extra_en,
        exp_fa, exp_en, why_fa, why_en,
        "**در پنجره‌ی آنتی‌بادی، نشانگری بخواهید که به آنتی‌بادی وابسته نیست.**",
        "Inside the antibody window, ask for a marker that does not depend on antibody.",
        [CDCLAB, H202])


_p24(
    "book:686", "medium",
    ["**در این سؤال فاصله‌ی زمانی ذکر نشده، ولی تابلوی حاد خودش زمان را می‌گوید.**",
     "**سندرم رتروویرال حاد تعریفاً در همان پنجره رخ می‌دهد که آنتی‌بادی هنوز کامل نیست.**",
     "⚠️ **و کشت سلولی ویروس، هرچند علمی به‌نظر می‌رسد، ابزار پژوهشی است نه بالینی.**"],
    ["The stem gives no interval, but the acute picture itself tells you the timing.",
     "Acute retroviral syndrome by definition occurs in the very window where antibody is incomplete.",
     "WARNING, AND VIRAL CELL CULTURE, though it sounds scientific, is a research tool and not a clinical one."],
    "**مرد جوان** با **تب، گلودرد، دردهای عضلانی و مفصلی** و سابقه‌ی **روابط جنسی آزاد**.\n\n"
    "⚠️ **این تابلوی کلاسیک سندرم رتروویرال حاد است — و خودِ تابلو زمان را می‌گوید، حتی "
    "اگر متن فاصله‌ی زمانی را ذکر نکرده باشد.**\n\n"
    "**سندرم رتروویرال حاد تعریفاً ۲ تا ۶ هفته پس از تماس رخ می‌دهد** — یعنی دقیقاً در "
    "همان پنجره‌ای که **آنتی‌بادی هنوز کامل نشده** است.\n\n"
    "**پاسخ: Ag P24 Capture Assay.**\n\n"
    "**چرا p24 دقیقاً برای این لحظه ساخته شده؟** چون **پروتئین هسته‌ی خودِ ویروس** است و "
    "**به پاسخ ایمنی بیمار وابسته نیست**. تست آنتی‌بادی می‌پرسد «آیا بدن واکنش نشان "
    "داده؟» — و در هفته‌ی دوم پاسخ ممکن است هنوز «نه» باشد، حتی در فرد کاملاً آلوده. "
    "**تست p24 می‌پرسد «آیا ویروس آنجاست؟» — و پاسخ آن از هفته‌ی دوم «بله» است.**\n\n"
    "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
    "**Anti HIV Ab ELISA** — همان تله. در پنجره‌ی حاد ممکن است **کاذباً منفی** باشد، و "
    "یک منفی کاذب در این مرحله بدترین نتیجه است: بیمار در **مسری‌ترین دوره‌ی عمرش** "
    "مرخص می‌شود با این باور که سالم است.\n\n"
    "**Anti HIV Ab Western blot** — ⚠️ **بدتر از الایزا**. وسترن بلات فقط **IgG** را "
    "می‌بیند و **۲ تا ۳ هفته دیرتر** از تست غربالگری مثبت می‌شود. یعنی در عفونت حاد "
    "**قطعاً منفی** است.\n\n"
    "**HIV cell culture** — ⚠️ این گزینه علمی به‌نظر می‌رسد ولی **ابزار پژوهشی** است: "
    "هفته‌ها طول می‌کشد، آزمایشگاه سطح ایمنی بالا می‌خواهد، گران است، و در تشخیص روتین "
    "**هیچ جایی ندارد**.",
    "A YOUNG MAN with FEVER, SORE THROAT AND MUSCLE AND JOINT PAINS, and a history of unprotected "
    "sexual activity.\n\n"
    "WARNING, THIS IS CLASSIC ACUTE RETROVIRAL SYNDROME — and the picture itself tells you the "
    "timing, even though the stem gives no interval.\n\n"
    "ACUTE RETROVIRAL SYNDROME BY DEFINITION OCCURS 2 TO 6 WEEKS AFTER EXPOSURE — that is, in "
    "exactly the window where ANTIBODY IS NOT YET COMPLETE.\n\n"
    "THE ANSWER: p24 Ag Capture Assay.\n\n"
    "WHY IS p24 MADE FOR THIS MOMENT? Because it is THE VIRUS'S OWN CORE PROTEIN and DOES NOT DEPEND "
    "ON THE PATIENT'S IMMUNE RESPONSE. An antibody test asks 'has the body reacted?' — and in week "
    "two the answer may still be 'no', even in someone fully infected. THE p24 TEST ASKS 'IS THE "
    "VIRUS THERE?' — and from week two the answer is yes.\n\n"
    "AND WHY NOT THE OTHER THREE?\n\n"
    "ANTI-HIV Ab ELISA — the trap itself. In the acute window it may be FALSELY NEGATIVE, and a "
    "false negative here is the worst possible outcome: the patient is discharged DURING THE MOST "
    "INFECTIOUS PERIOD OF THEIR LIFE believing they are well.\n\n"
    "ANTI-HIV Ab WESTERN BLOT — WARNING, WORSE THAN THE ELISA. It sees only IgG and turns positive "
    "2 TO 3 WEEKS LATER than the screening test, so in acute infection it is CERTAINLY negative.\n\n"
    "HIV CELL CULTURE — WARNING, this sounds scientific but is a RESEARCH TOOL: it takes weeks, "
    "requires a high-containment laboratory, is expensive, and HAS NO PLACE in routine diagnosis.",
    ["پاسخ صحیح — p24 پروتئین هسته‌ی ویروس است و در پنجره‌ی آنتی‌بادی، مستقیم خودِ ویروس را می‌بیند.",
     "الایزای آنتی‌بادی در پنجره‌ی حاد کاذباً منفی می‌شود، و منفی کاذب اینجا بدترین نتیجه است.",
     "کشت سلولی ویروس ابزار پژوهشی است: هفته‌ها طول می‌کشد و در تشخیص روتین جایی ندارد.",
     "وسترن بلات از الایزا هم بدتر است؛ فقط IgG را می‌بیند و ۲ تا ۳ هفته دیرتر مثبت می‌شود."],
    ["Correct — p24 is the viral core protein and, inside the antibody window, sees the virus directly.",
     "An antibody ELISA is falsely negative in the acute window, and a false negative here is the worst outcome.",
     "Viral cell culture is a research tool: it takes weeks and has no place in routine diagnosis.",
     "The Western blot is worse still; it sees only IgG and turns positive 2 to 3 weeks later."])

_p24(
    "book:688", "medium",
    ["**اینجا فاصله‌ها صریح‌اند و باید با هم خوانده شوند: تماس ۳ هفته قبل، علائم از ۸ روز قبل.**",
     "⚠️ **یعنی بیمار در هفته‌ی سوم است — درست وسط پنجره‌ای که p24 مثبت و آنتی‌بادی مرزی است.**",
     "**و تست سریع هم یک تست آنتی‌بادی است، پس همان محدودیت پنجره را دارد.**"],
    ["Here the intervals are explicit and must be read together: exposure 3 weeks ago, symptoms for 8 days.",
     "WARNING, SO THE PATIENT IS IN WEEK THREE — right inside the window where p24 is positive and antibody is borderline.",
     "And a rapid test is also an antibody test, so it shares the same window limitation."],
    "**خانم ۲۷ ساله** با **تب، گلودرد و لنفادنوپاتی از ۸ روز قبل**، و **رفتار جنسی پرخطر "
    "حدود ۳ هفته قبل**، با احتمال **سندرم رتروویرال**.\n\n"
    "⚠️ **این سؤال دو عدد دارد که باید با هم خوانده شوند، و همین آن را دقیق‌تر از "
    "بقیه می‌کند:**\n\n"
    "**تماس: ۳ هفته قبل.** **علائم: از ۸ روز قبل** (یعنی حدود ۲ هفته پس از تماس شروع "
    "شده‌اند).\n\n"
    "**پس بیمار الان در هفته‌ی سوم پس از تماس است. حالا نردبان نشانگرها را بگذارید "
    "کنارش:**\n\n"
    "**RNA (از روز ۱۰):** ✅ قطعاً مثبت است.\n\n"
    "**آنتی‌ژن p24 (از هفته‌ی ۲):** ✅ مثبت است.\n\n"
    "**آنتی‌بادی (از هفته‌ی ۳ تا ۱۲):** ⚠️ **درست روی مرز** — ممکن است مثبت باشد، ممکن "
    "است نباشد.\n\n"
    "**پس در میان گزینه‌های موجود، p24 تنها نشانگری است که در این مقطع قابل اتکاست.**\n\n"
    "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
    "**HIV Ab** — دقیقاً روی مرز پنجره. یک منفی در این مقطع **هیچ چیزی را رد نمی‌کند** و "
    "می‌تواند گمراه کند.\n\n"
    "**Rapid Test** — ⚠️ این ظریف‌ترین گزینه است. تست سریع **سریع** است، ولی **همچنان یک "
    "تست آنتی‌بادی است**. «سریع» به معنای «زودتر مثبت می‌شود» نیست — به معنای «نتیجه‌اش "
    "زودتر آماده است» است. **همان محدودیت پنجره را دارد.**\n\n"
    "**Western blot** — بدترین انتخاب در پنجره‌ی حاد: فقط IgG را می‌بیند و **۲ تا ۳ هفته "
    "دیرتر** از غربالگری مثبت می‌شود.\n\n"
    "**و یک نکته‌ی بالینی که ورای سؤال است:** تشخیص عفونت حاد **فوریت بهداشت عمومی** "
    "دارد. بیمار در این مرحله **بار ویروسی بسیار بالایی** دارد و **مسری‌ترین دوره‌ی "
    "عمرش** را می‌گذراند. تشخیص زودهنگام هم درمان را زودتر شروع می‌کند و هم زنجیره‌ی "
    "انتقال را قطع می‌کند.",
    "A 27-YEAR-OLD WOMAN with FEVER, SORE THROAT AND LYMPHADENOPATHY FOR 8 DAYS, and HIGH-RISK "
    "SEXUAL BEHAVIOUR ABOUT 3 WEEKS AGO, with suspected RETROVIRAL SYNDROME.\n\n"
    "WARNING, THIS STEM CARRIES TWO NUMBERS THAT MUST BE READ TOGETHER, and that makes it more "
    "precise than the others:\n\n"
    "EXPOSURE: 3 weeks ago. SYMPTOMS: for 8 days (so they began about 2 weeks after exposure).\n\n"
    "SO THE PATIENT IS NOW IN WEEK THREE AFTER EXPOSURE. Now lay the marker ladder beside that:\n\n"
    "RNA (from day 10): certainly positive.\n\n"
    "p24 ANTIGEN (from week 2): positive.\n\n"
    "ANTIBODY (from week 3 to 12): WARNING — RIGHT ON THE BOUNDARY. It may be positive, it may not.\n\n"
    "SO AMONG THE AVAILABLE OPTIONS, p24 IS THE ONLY MARKER THAT IS RELIABLE AT THIS POINT.\n\n"
    "AND WHY NOT THE OTHER THREE?\n\n"
    "HIV Ab — exactly on the boundary of the window. A negative here EXCLUDES NOTHING and can "
    "mislead.\n\n"
    "RAPID TEST — WARNING, the subtlest option. A rapid test is FAST, but IT IS STILL AN ANTIBODY "
    "TEST. 'Rapid' does not mean 'turns positive earlier'; it means 'the result is ready sooner'. IT "
    "HAS THE SAME WINDOW LIMITATION.\n\n"
    "WESTERN BLOT — the worst choice in the acute window: it sees only IgG and turns positive 2 to 3 "
    "weeks later than the screen.\n\n"
    "AND A CLINICAL POINT BEYOND THE QUESTION: diagnosing acute infection is a PUBLIC HEALTH "
    "URGENCY. At this stage the patient has a VERY HIGH VIRAL LOAD and is living through THE MOST "
    "INFECTIOUS PERIOD OF THEIR LIFE. Early diagnosis both starts treatment sooner and breaks the "
    "chain of transmission.",
    ["وسترن بلات بدترین انتخاب در پنجره‌ی حاد است؛ ۲ تا ۳ هفته دیرتر از غربالگری مثبت می‌شود.",
     "پاسخ صحیح — در هفته‌ی سوم پس از تماس، p24 مثبت است در حالی که آنتی‌بادی روی مرز است.",
     "آنتی‌بادی HIV دقیقاً روی مرز پنجره است؛ یک منفی در این مقطع هیچ چیزی را رد نمی‌کند.",
     "تست سریع هم یک تست آنتی‌بادی است؛ «سریع» یعنی نتیجه زودتر آماده است، نه زودتر مثبت می‌شود."],
    ["The Western blot is the worst choice in the acute window; it turns positive 2 to 3 weeks after the screen.",
     "Correct — in week three after exposure p24 is positive while antibody is on the boundary.",
     "HIV antibody is exactly on the window boundary; a negative at this point excludes nothing.",
     "A rapid test is also an antibody test; 'rapid' means the result is ready sooner, not that it turns positive earlier."])

_p24(
    "book:689", "medium",
    ["**«ماه گذشته» یعنی حدود ۴ هفته — همان مرز پنجره، پس نشانگر مستقل از آنتی‌بادی امن‌تر است.**",
     "⚠️ **و بیوپسی غدد لنفاوی اینجا یک تله‌ی تهاجمی است: پاسخ می‌دهد ولی به بهای زیاد.**",
     "**در لنفادنوپاتی HIV، بیوپسی هیپرپلازی فولیکولار غیراختصاصی نشان می‌دهد.**",
     "**قاعده: اگر یک تست خونی به همان سؤال پاسخ می‌دهد، هرگز سراغ اقدام تهاجمی نروید.**"],
    ["'Last month' means about 4 weeks — the very edge of the window, so an antibody-independent marker is safer.",
     "WARNING, AND LYMPH NODE BIOPSY IS AN INVASIVE TRAP HERE: it answers, but at a high price.",
     "In HIV lymphadenopathy, biopsy shows non-specific follicular hyperplasia.",
     "The rule: if a blood test answers the same question, never reach for an invasive procedure."],
    "**جوان ۲۶ ساله** با **تماس جنسی مشکوک در ماه گذشته** و حالا **تب، لرز، گلودرد، درد "
    "مفاصل و عضلات و لنفادنوپاتی منتشر**.\n\n"
    "⚠️ **«ماه گذشته» یعنی حدود ۴ هفته — همان مرز پنجره. پاسخ: آنتی‌ژن p24 سرم.**\n\n"
    "**در هفته‌ی چهارم، آنتی‌بادی در بسیاری از افراد مثبت شده ولی در برخی هنوز نه. "
    "p24 قطعاً مثبت است. پس در میان گزینه‌های موجود، انتخاب امن‌تر p24 است.**\n\n"
    "**ولی این سؤال یک گزینه‌ی خاص دارد که ارزش گفتگوی جداگانه دارد:**\n\n"
    "⚠️ **«بیوپسی از غدد لنفاوی» — یک تله‌ی تهاجمی.**\n\n"
    "**چرا وسوسه‌انگیز است؟** چون بیمار **لنفادنوپاتی منتشر** دارد، و در ذهن دانشجو "
    "«لنفادنوپاتی ← بیوپسی» یک رفلکس است.\n\n"
    "**چرا غلط است؟ سه دلیل:**\n\n"
    "**۱) نتیجه‌اش غیراختصاصی است.** در لنفادنوپاتی HIV، بیوپسی **هیپرپلازی فولیکولار "
    "غیراختصاصی** نشان می‌دهد — یعنی یافته‌ای که در ده‌ها بیماری دیگر هم دیده می‌شود و "
    "تشخیص را قطعی نمی‌کند.\n\n"
    "**۲) تهاجمی است.** بیهوشی موضعی، برش، خطر عفونت و خونریزی، اسکار.\n\n"
    "**۳) و مهم‌تر از همه: یک لوله خون همان سؤال را جواب می‌دهد.**\n\n"
    "**قاعده‌ی عمومی که فراتر از این سؤال است:**\n\n"
    "> **اگر یک تست خونی و یک اقدام تهاجمی به یک سؤال پاسخ می‌دهند، همیشه اول تست خون.**\n\n"
    "**جای بیوپسی غدد لنفاوی در HIV کجاست؟** وقتی که **لنفادنوپاتی نامتقارن، سریع‌الرشد "
    "یا همراه با علائم B** باشد و شک به **لنفوم** یا **سل** برود — نه در تابلوی کلاسیک "
    "سندرم رتروویرال حاد.\n\n"
    "**و دو گزینه‌ی دیگر؟** **شمارش CD4** ابزار مرحله‌بندی است نه تشخیص. **سرولوژی HIV** "
    "همان تست آنتی‌بادی است که در این مرحله ممکن است هنوز منفی باشد.",
    "A 26-YEAR-OLD with A SUSPICIOUS SEXUAL CONTACT LAST MONTH, now with FEVER, CHILLS, SORE THROAT, "
    "JOINT AND MUSCLE PAINS AND GENERALISED LYMPHADENOPATHY.\n\n"
    "WARNING, 'LAST MONTH' MEANS ABOUT 4 WEEKS — the very edge of the window. The answer: serum p24 "
    "antigen.\n\n"
    "At week four, antibody has turned positive in many people but not yet in some. p24 is certainly "
    "positive. So among the available options p24 is the safer choice.\n\n"
    "BUT THIS QUESTION CARRIES ONE OPTION THAT DESERVES SEPARATE DISCUSSION:\n\n"
    "WARNING: 'LYMPH NODE BIOPSY' — AN INVASIVE TRAP.\n\n"
    "WHY IS IT TEMPTING? Because the patient has GENERALISED LYMPHADENOPATHY, and in a student's "
    "mind 'lymphadenopathy leads to biopsy' is a reflex.\n\n"
    "WHY IS IT WRONG? Three reasons:\n\n"
    "1) THE RESULT IS NON-SPECIFIC. In HIV lymphadenopathy, biopsy shows NON-SPECIFIC FOLLICULAR "
    "HYPERPLASIA — a finding seen in dozens of other diseases that does not settle the diagnosis.\n\n"
    "2) IT IS INVASIVE. Local anaesthesia, an incision, risk of infection and bleeding, a scar.\n\n"
    "3) AND ABOVE ALL: A TUBE OF BLOOD ANSWERS THE SAME QUESTION.\n\n"
    "THE GENERAL RULE, WHICH REACHES BEYOND THIS QUESTION:\n\n"
    "> IF A BLOOD TEST AND AN INVASIVE PROCEDURE ANSWER THE SAME QUESTION, ALWAYS DO THE BLOOD TEST "
    "FIRST.\n\n"
    "WHERE DOES LYMPH NODE BIOPSY BELONG IN HIV? When the lymphadenopathy is ASYMMETRIC, RAPIDLY "
    "GROWING OR ACCOMPANIED BY B SYMPTOMS and LYMPHOMA or TUBERCULOSIS is suspected — not in a "
    "classic acute retroviral syndrome.\n\n"
    "AND THE OTHER TWO? The CD4 COUNT is a staging tool, not diagnostic. HIV SEROLOGY is the very "
    "antibody test that may still be negative at this stage.",
    ["شمارش CD4 ابزار مرحله‌بندی است نه تشخیص، و CD4 پایین اختصاصی HIV نیست.",
     "تله‌ی تهاجمی — بیوپسی هیپرپلازی فولیکولار غیراختصاصی می‌دهد، در حالی که یک لوله خون همان سؤال را جواب می‌دهد.",
     "سرولوژی HIV همان تست آنتی‌بادی است که در هفته‌ی چهارم ممکن است هنوز منفی باشد.",
     "پاسخ صحیح — p24 در هفته‌ی چهارم قطعاً مثبت است و به پاسخ آنتی‌بادی وابسته نیست."],
    ["The CD4 count is a staging tool, not diagnostic, and a low CD4 is not specific to HIV.",
     "An invasive trap — biopsy yields non-specific follicular hyperplasia, while a tube of blood answers the same question.",
     "HIV serology is the antibody test that may still be negative in week four.",
     "Correct — p24 is certainly positive by week four and does not depend on the antibody response."])


# =========================================================== book:694
add("book:694", "recall", "medium",
 "**HLA-B27** ربطی به HIV ندارد — سه گزینه‌ی دیگر بخشی از ارزیابی اولیه‌ی استاندارد هستند.",
 "HLA-B27 has nothing to do with HIV — the other three are part of the standard baseline assessment.",
 OI_FA + [
  "**ارزیابی اولیه‌ی فرد تازه‌تشخیص‌داده‌شده سه هدف دارد و همه‌ی تست‌ها زیر یکی از آن‌ها می‌آیند.**",
  "**هدف یک: تعیین مرحله — شمارش CD4 و بار ویروسی.**",
  "**هدف دو: یافتن هم‌عفونتی‌ها — VDRL یا RPR، سرولوژی هپاتیت B و C، توکسوپلاسما IgG، تست سل.**",
  "⚠️ **VDRL از همه مهم‌تر است، چون سیفلیس و HIV راه انتقال مشترک دارند و بسیار هم‌زمان‌اند.**",
  "**و سیفلیس در HIV سریع‌تر پیش می‌رود و نوروسیفلیس زودرس می‌دهد.**",
  "**هدف سه: پایه‌ی سنجش سمیت دارو — کراتینین، آنزیم‌های کبدی، بیلی‌روبین، قند، چربی، شمارش خون.**",
  "**قند ناشتا لازم است چون برخی داروهای ضدرتروویروسی مقاومت به انسولین و دیابت می‌دهند.**",
  "**بیلی‌روبین لازم است چون آتازاناویر هیپربیلی‌روبینمی غیرکونژوگه‌ی خوش‌خیم می‌دهد.**",
  "⚠️ **و HLA-B27 نشانگر اسپوندیلوآرتریت است و در هیچ‌کدام از سه هدف جایی ندارد.**",
  "**تنها HLAیی که در HIV اهمیت دارد HLA-B*5701 است، برای پیش‌بینی حساسیت به آباکاویر.**",
 ],
 OI_EN + [
  "The baseline assessment of a newly diagnosed patient has three aims, and every test falls under one of them.",
  "AIM ONE: staging — the CD4 count and the viral load.",
  "AIM TWO: finding coinfections — VDRL or RPR, hepatitis B and C serology, toxoplasma IgG, a TB test.",
  "WARNING, VDRL MATTERS MOST, because syphilis and HIV share transmission routes and coincide often.",
  "And syphilis progresses faster in HIV and causes early neurosyphilis.",
  "AIM THREE: a baseline for drug toxicity — creatinine, liver enzymes, bilirubin, glucose, lipids, blood count.",
  "Fasting glucose is needed because some antiretrovirals cause insulin resistance and diabetes.",
  "Bilirubin is needed because atazanavir causes a benign unconjugated hyperbilirubinaemia.",
  "WARNING, AND HLA-B27 IS A MARKER OF SPONDYLOARTHRITIS and belongs to none of the three aims.",
  "The only HLA that matters in HIV is HLA-B*5701, for predicting abacavir hypersensitivity.",
 ],
 "سؤال می‌پرسد کدام تست را در **ارزیابی اولیه‌ی فرد HIV مثبت درخواست نمی‌کنید**.\n\n"
 "⚠️ **برای پاسخ، اول بدانید ارزیابی اولیه اصلاً برای چیست. سه هدف دارد، و هر تستی "
 "زیر یکی از این سه می‌آید:**\n\n"
 "**هدف یک — تعیین مرحله:** شمارش CD4 و بار ویروسی. یعنی «بیماری کجاست؟»\n\n"
 "**هدف دو — یافتن هم‌عفونتی‌ها:** یعنی «چه چیز دیگری همراهش آمده؟»\n\n"
 "**هدف سه — پایه‌ی سنجش سمیت دارو:** یعنی «پیش از شروع دارو، عملکرد ارگان‌ها کجاست؟»\n\n"
 "**حالا هر گزینه را بسنجیم:**\n\n"
 "**VDRL** ✅ — **هدف دو**. ⚠️ **و این مهم‌ترین تست غربالگری هم‌زمان است**: سیفلیس و HIV "
 "**راه انتقال مشترک** دارند و بسیار با هم دیده می‌شوند. مهم‌تر اینکه **سیفلیس در فرد "
 "HIV مثبت رفتار متفاوتی دارد**: سریع‌تر پیش می‌رود و **نوروسیفلیس زودرس** می‌دهد. پس "
 "پیدا کردنش تصمیم درمانی را عوض می‌کند.\n\n"
 "**FBS (قند ناشتا)** ✅ — **هدف سه**. برخی داروهای ضدرتروویروسی، به‌ویژه **مهارکننده‌های "
 "پروتئاز**، **مقاومت به انسولین و دیابت** می‌دهند. بدون عدد پایه، بعداً نمی‌توان فهمید "
 "دیابت از دارو آمده یا از قبل بوده.\n\n"
 "**بیلی‌روبین** ✅ — **هدف سه**. ⚠️ نمونه‌ی مشخصش **آتازاناویر** است که "
 "**هیپربیلی‌روبینمی غیرکونژوگه‌ی خوش‌خیم** می‌دهد. اگر عدد پایه نداشته باشید، بالا "
 "رفتن بیلی‌روبین بعداً باعث قطع بی‌مورد یک داروی مؤثر می‌شود.\n\n"
 "**HLA-B27** ❌ — ⚠️ **پاسخ**. این نشانگر ژنتیکی **اسپوندیلوآرتریت‌ها** است: اسپوندیلیت "
 "آنکیلوزان، آرتریت واکنشی، یووئیت قدامی. **هیچ ربطی به HIV ندارد** و در هیچ‌کدام از "
 "سه هدف نمی‌گنجد.\n\n"
 "**و یک نکته‌ی ظریف که ارزش دانستن دارد:** ⚠️ **یک HLA در HIV اهمیت زیادی دارد، ولی "
 "آن HLA-B27 نیست — HLA-B*5701 است.** این ژن **حساسیت شدید به آباکاویر** را پیش‌بینی "
 "می‌کند، و امروز پیش از تجویز آباکاویر **اجباری** است. پس گزینه یک نام درست از "
 "خانواده‌ی غلط است.",
 "The stem asks which test you would NOT request in the baseline assessment of an HIV-positive "
 "person.\n\n"
 "WARNING, TO ANSWER, FIRST KNOW WHAT THE BASELINE ASSESSMENT IS FOR. It has three aims, and every "
 "test falls under one of them:\n\n"
 "AIM ONE — STAGING: the CD4 count and viral load. That is, 'where is the disease?'\n\n"
 "AIM TWO — FINDING COINFECTIONS: that is, 'what else came with it?'\n\n"
 "AIM THREE — A BASELINE FOR DRUG TOXICITY: 'before starting drugs, where is organ function?'\n\n"
 "NOW WEIGH EACH OPTION:\n\n"
 "VDRL — AIM TWO. WARNING, AND THIS IS THE MOST IMPORTANT CO-SCREENING TEST: syphilis and HIV SHARE "
 "TRANSMISSION ROUTES and are frequently found together. More importantly, SYPHILIS BEHAVES "
 "DIFFERENTLY IN HIV: it progresses faster and causes EARLY NEUROSYPHILIS. So finding it changes "
 "treatment.\n\n"
 "FBS (fasting glucose) — AIM THREE. Some antiretrovirals, particularly PROTEASE INHIBITORS, cause "
 "INSULIN RESISTANCE AND DIABETES. Without a baseline you cannot later tell whether diabetes came "
 "from the drug or preceded it.\n\n"
 "BILIRUBIN — AIM THREE. WARNING, the clear example is ATAZANAVIR, which causes a BENIGN "
 "UNCONJUGATED HYPERBILIRUBINAEMIA. Without a baseline, a later rise leads to needlessly stopping "
 "an effective drug.\n\n"
 "HLA-B27 — WARNING, THE ANSWER. This genetic marker belongs to the SPONDYLOARTHRITIDES: ankylosing "
 "spondylitis, reactive arthritis, anterior uveitis. IT HAS NOTHING TO DO WITH HIV and fits none of "
 "the three aims.\n\n"
 "AND A SUBTLE POINT WORTH KNOWING: WARNING, ONE HLA DOES MATTER GREATLY IN HIV, BUT IT IS NOT "
 "B27 — IT IS HLA-B*5701. That gene predicts SEVERE ABACAVIR HYPERSENSITIVITY and testing is "
 "MANDATORY today before prescribing abacavir. So the option is a right name from the wrong family.",
 ["VDRL بخشی از غربالگری هم‌عفونتی است؛ سیفلیس و HIV راه انتقال مشترک دارند.",
  "قند ناشتا پایه‌ی سنجش سمیت داروست، چون برخی ضدرتروویروس‌ها دیابت می‌دهند.",
  "بیلی‌روبین پایه لازم است، چون آتازاناویر هیپربیلی‌روبینمی خوش‌خیم می‌دهد.",
  "پاسخ صحیح — HLA-B27 نشانگر اسپوندیلوآرتریت است؛ HLAی مهم در HIV، B*5701 برای آباکاویر است."],
 ["VDRL is part of coinfection screening; syphilis and HIV share transmission routes.",
  "Fasting glucose is a drug-toxicity baseline, because some antiretrovirals cause diabetes.",
  "A baseline bilirubin is needed because atazanavir causes a benign hyperbilirubinaemia.",
  "Correct — HLA-B27 marks spondyloarthritis; the HLA that matters in HIV is B*5701, for abacavir."],
 "**HLAی مهم در HIV، B27 نیست — B*5701 است، برای پیش‌بینی حساسیت به آباکاویر.**",
 "The HLA that matters in HIV is not B27 but B*5701, predicting abacavir hypersensitivity.",
 [OIG, H202])


# =========================================================== book:696
add("book:696", "case", "medium",
 "برفک + کاهش وزن بیش از ۱۰٪ = **ایدز بالینی**. **بدون انتظار برای CD4، همین حالا ART شروع شود.**",
 "Thrush plus over 10 per cent weight loss is CLINICAL AIDS: start ART NOW, without waiting for a CD4 count.",
 OI_FA + [
  "**این سؤال یک اصل درمانی را می‌آزماید که در بیست سال گذشته کاملاً عوض شده است.**",
  "⚠️ **قدیم: منتظر می‌ماندند تا CD4 به آستانه‌ای برسد و بعد درمان را شروع می‌کردند.**",
  "**امروز: درمان در هر CD4 و هر بار ویروسی و برای همه توصیه می‌شود.**",
  "**دو مطالعه این را عوض کردند: START و TEMPRANO، هر دو در سال ۲۰۱۵.**",
  "**هر دو نشان دادند شروع زودهنگام، مرگ و بیماری جدی را به‌طور معنادار کم می‌کند.**",
  "⚠️ **و در این بیمار خاص، حتی بحث هم لازم نیست: او از قبل تابلوی ایدز دارد.**",
  "**برفک دهانی مقاوم و کاهش وزن بیش از ۱۰ درصد یعنی سندرم تحلیل‌رونده.**",
  "**پس CD4 او تقریباً به‌قطع پایین است و انتظار برای عدد فقط تأخیر است.**",
  "**CD4 و بار ویروسی همچنان گرفته می‌شوند، ولی به‌عنوان پایه‌ی پیگیری، نه شرط شروع.**",
 ],
 OI_EN + [
  "This question tests a therapeutic principle that has changed completely in the past twenty years.",
  "WARNING, THE OLD WAY: wait until the CD4 fell to a threshold, then start treatment.",
  "TODAY: treatment is recommended for everyone, at any CD4 count and any viral load.",
  "Two trials changed this: START and TEMPRANO, both in 2015.",
  "Both showed that early initiation significantly reduces death and serious illness.",
  "WARNING, AND IN THIS PARTICULAR PATIENT NO DEBATE IS EVEN NEEDED: he already has an AIDS picture.",
  "Persistent oral thrush with over 10 per cent weight loss is a wasting syndrome.",
  "So his CD4 is almost certainly low, and waiting for the number is nothing but delay.",
  "CD4 and viral load are still taken, but as a baseline for follow-up, not as a condition for starting.",
 ],
 "**بیمار ۳۶ ساله HIV مثبت** با **تب و برفک دهانی از دو ماه قبل** و **کاهش وزن بیش از "
 "۱۰ درصد**.\n\n"
 "⚠️ **پاسخ: شروع فوری درمان ضدرتروویروسی سه‌دارویی.**\n\n"
 "**این سؤال یک اصل درمانی را می‌آزماید که در بیست سال گذشته کاملاً وارونه شده است، و "
 "دانستن این تاریخچه پاسخ را ماندگار می‌کند:**\n\n"
 "**دوره‌ی قدیم:** درمان **گران، پرعارضه و پرقرص** بود. پس منتظر می‌ماندند تا CD4 به "
 "آستانه‌ای (اول ۲۰۰، بعد ۳۵۰، بعد ۵۰۰) برسد و آنگاه شروع می‌کردند. منطقش این بود که "
 "«ضرر دارو را تا وقتی لازم نشده تحمیل نکنیم».\n\n"
 "⚠️ **امروز: درمان برای همه، در هر CD4 و هر بار ویروسی.**\n\n"
 "**چه چیزی این را عوض کرد؟ دو مطالعه‌ی بزرگ در سال ۲۰۱۵:**\n\n"
 "**START** و **TEMPRANO** — هر دو نشان دادند شروع **زودهنگام** درمان، **مرگ و بیماری "
 "جدی را به‌طور معنادار کاهش می‌دهد**، حتی در افرادی که CD4 بالایی داشتند. به‌علاوه، "
 "داروهای امروزی **یک قرص در روز، کم‌عارضه** هستند — پس آن موازنه‌ی قدیمی دیگر برقرار "
 "نیست.\n\n"
 "**و دلیل دوم که کمتر گفته می‌شود:** فرد تحت درمان با **بار ویروسی سرکوب‌شده، ویروس را "
 "منتقل نمی‌کند** (اصل U=U). یعنی درمان، هم‌زمان **پیشگیری** هم هست.\n\n"
 "**و در این بیمار خاص، اصلاً بحث لازم نیست:**\n\n"
 "**برفک دهانی مقاوم دو ماهه** + **کاهش وزن بیش از ۱۰ درصد** = تابلوی **سندرم "
 "تحلیل‌رونده‌ی HIV**، که خودش یک بیماری تعریف‌کننده‌ی ایدز است. **CD4 این بیمار "
 "تقریباً به‌قطع بسیار پایین است.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**«شمارش CD4 و شروع در صورت زیر ۲۰۰»** — این **الگوریتم منسوخ** است. ضمناً در بیماری "
 "که از قبل تابلوی ایدز دارد، انتظار برای عدد فقط **تأخیر** است.\n\n"
 "**«بار ویروسی و شروع در صورت بالای ۱۰ به توان ۵»** — ⚠️ این **هرگز** معیار شروع نبوده "
 "است. بار ویروسی معیار **پایش پاسخ** است، نه شرط شروع.\n\n"
 "**«همه‌ی موارد فوق صحیح است»** — نمی‌تواند درست باشد وقتی دوتای آن‌ها غلط‌اند.\n\n"
 "**نکته‌ی عملی:** CD4 و بار ویروسی **همچنان گرفته می‌شوند** — ولی به‌عنوان **پایه‌ی "
 "پیگیری**، نه **شرط شروع**. تفاوت ظریف ولی حیاتی است.",
 "A 36-YEAR-OLD HIV-POSITIVE MAN with FEVER AND ORAL THRUSH FOR TWO MONTHS and OVER 10 PER CENT "
 "WEIGHT LOSS.\n\n"
 "WARNING, THE ANSWER: start three-drug antiretroviral therapy immediately.\n\n"
 "This question tests a therapeutic principle that has been completely inverted over twenty years, "
 "and knowing that history makes the answer stick:\n\n"
 "THE OLD ERA: treatment was EXPENSIVE, TOXIC AND PILL-HEAVY. So clinicians waited until the CD4 "
 "fell to a threshold (first 200, then 350, then 500) and started there. The logic was 'do not "
 "impose the drug's harm until it is needed'.\n\n"
 "WARNING, TODAY: TREATMENT FOR EVERYONE, AT ANY CD4 AND ANY VIRAL LOAD.\n\n"
 "WHAT CHANGED IT? Two large trials in 2015:\n\n"
 "START and TEMPRANO — both showed that EARLY initiation SIGNIFICANTLY REDUCES DEATH AND SERIOUS "
 "ILLNESS, even in people with high CD4 counts. In addition, today's drugs are ONE TABLET A DAY "
 "with few side effects — so the old trade-off no longer holds.\n\n"
 "AND A SECOND REASON LESS OFTEN STATED: a treated person with a SUPPRESSED VIRAL LOAD DOES NOT "
 "TRANSMIT THE VIRUS (the U=U principle). So treatment is simultaneously PREVENTION.\n\n"
 "AND IN THIS PARTICULAR PATIENT NO DEBATE IS NEEDED AT ALL:\n\n"
 "TWO MONTHS OF PERSISTENT ORAL THRUSH plus OVER 10 PER CENT WEIGHT LOSS is the picture of HIV "
 "WASTING SYNDROME, itself an AIDS-defining illness. THIS PATIENT'S CD4 IS ALMOST CERTAINLY VERY "
 "LOW.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "'COUNT THE CD4 AND START IF BELOW 200' — an OBSOLETE ALGORITHM. And in a patient who already has "
 "an AIDS picture, waiting for the number is nothing but DELAY.\n\n"
 "'MEASURE THE VIRAL LOAD AND START IF ABOVE 10 TO THE FIFTH' — WARNING, that has NEVER been a "
 "criterion for starting. Viral load is a MONITORING measure, not a starting condition.\n\n"
 "'ALL OF THE ABOVE ARE CORRECT' — cannot be true when two of them are wrong.\n\n"
 "THE PRACTICAL POINT: CD4 and viral load ARE STILL MEASURED — but as a BASELINE FOR FOLLOW-UP, not "
 "as a CONDITION FOR STARTING. The distinction is subtle but vital.",
 ["پاسخ صحیح — از مطالعات START و TEMPRANO به بعد، درمان در هر CD4 توصیه می‌شود؛ این بیمار هم تابلوی ایدز دارد.",
  "الگوریتم منسوخ — انتظار برای رسیدن CD4 به ۲۰۰، امروز فقط تأخیر در درمان است.",
  "بار ویروسی هرگز معیار شروع درمان نبوده است؛ ابزار پایش پاسخ به درمان است.",
  "نمی‌تواند درست باشد وقتی دو گزینه از سه گزینه‌ی دیگر نادرست‌اند."],
 ["Correct — since START and TEMPRANO treatment is recommended at any CD4, and this patient already has an AIDS picture.",
  "An obsolete algorithm — waiting for the CD4 to reach 200 is today simply a delay in treatment.",
  "The viral load has never been a criterion for starting treatment; it is a monitoring tool.",
  "This cannot be correct when two of the other three options are wrong."],
 "**از ۲۰۱۵ به بعد: درمان برای همه، در هر CD4 و هر بار ویروسی.**",
 "Since 2015: treatment for everyone, at any CD4 count and any viral load.",
 [OIG, H202])


# =========================================================== book:697
add("book:697", "recall", "medium",
 "واکسن **پنوموکوک** برای هر فرد HIV مثبت — چون HIV پاسخ آنتی‌بادی به باکتری‌های کپسول‌دار را خراب می‌کند.",
 "The PNEUMOCOCCAL vaccine for every HIV-positive person — because HIV wrecks the antibody response to encapsulated bacteria.",
 OI_FA + [
  "**واکسیناسیون در HIV دو قاعده دارد و هر دو در این سؤال حاضرند.**",
  "⚠️ **قاعده‌ی یک: واکسن پنوموکوک برای همه‌ی افراد HIV مثبت، در هر CD4، توصیه می‌شود.**",
  "**چون HIV علاوه بر لنفوسیت T، عملکرد سلول B را هم مختل می‌کند.**",
  "**نتیجه، پاسخ آنتی‌بادی ناکارآمد به باکتری‌های کپسول‌دار است: پنوموکوک و هموفیلوس.**",
  "**و همین توضیح می‌دهد چرا پنومونی باکتریال مکرر از زودرس‌ترین نشانه‌های HIV است.**",
  "⚠️ **قاعده‌ی دو: واکسن زنده در ایمنی سرکوب‌شده ممنوع است.**",
  "**آبله‌مرغان یک واکسن ویروس زنده‌ی ضعیف‌شده است و در CD4 پایین می‌تواند بیماری بسازد.**",
  "**آستانه‌ی متعارف برای واکسن‌های زنده در بالغ: CD4 بالای ۲۰۰.**",
  "**واکسن هموفیلوس آنفلوانزا تیپ b در بالغان روتین نیست، چون بیماری‌اش عمدتاً کودکان است.**",
  "**و مننگوکوک فقط با اندیکاسیون خاص است، هرچند راهنماهای امروزی آن را گسترده‌تر کرده‌اند.**",
 ],
 OI_EN + [
  "Vaccination in HIV has two rules, and both are present in this question.",
  "WARNING, RULE ONE: the pneumococcal vaccine is recommended for EVERY HIV-positive person, at any CD4.",
  "Because besides T lymphocytes, HIV also impairs B CELL FUNCTION.",
  "The result is an ineffective antibody response to ENCAPSULATED bacteria: pneumococcus and Haemophilus.",
  "And that explains why recurrent bacterial pneumonia is among the earliest signs of HIV.",
  "WARNING, RULE TWO: LIVE VACCINES ARE CONTRAINDICATED in immunosuppression.",
  "Varicella vaccine is a LIVE attenuated virus and at a low CD4 can cause disease.",
  "The conventional threshold for live vaccines in adults: CD4 above 200.",
  "Haemophilus influenzae type b vaccine is not routine in adults, because the disease is mainly paediatric.",
  "And meningococcus is given for specific indications, though modern guidance has widened them.",
 ],
 "**مردان جوان HIV مثبت با CD4 برابر ۳۰۰ در هر میکرولیتر.** کدام واکسن توصیه می‌شود؟\n\n"
 "⚠️ **پاسخ: واکسن پنوموکوک. و دلیلش یک مفهوم ایمنی‌شناختی زیباست که ارزش فهمیدن دارد.**\n\n"
 "**همه می‌دانند HIV لنفوسیت T را از بین می‌برد. ولی نکته‌ای که کمتر گفته می‌شود این "
 "است که HIV عملکرد سلول B را هم مختل می‌کند** — از طریق فعال‌سازی مزمن و بی‌نظم "
 "سلول‌های B و از دست رفتن کمک سلول T به آن‌ها.\n\n"
 "**نتیجه چیست؟ پاسخ آنتی‌بادی ناکارآمد.** و آنتی‌بادی دقیقاً همان چیزی است که برای "
 "**باکتری‌های کپسول‌دار** لازم است — چون کپسول پلی‌ساکاریدی مانع فاگوسیتوز می‌شود و "
 "**فقط اپسونیزاسیون با آنتی‌بادی** آن را ممکن می‌کند.\n\n"
 "⚠️ **پس فرد HIV مثبت در برابر پنوموکوک و هموفیلوس آسیب‌پذیر است، و همین توضیح می‌دهد "
 "چرا «پنومونی باکتریال مکرر» یکی از زودرس‌ترین نشانه‌های HIV است — حتی در CD4 نسبتاً "
 "بالا.**\n\n"
 "**به همین دلیل واکسن پنوموکوک برای همه‌ی افراد HIV مثبت، در هر CD4، توصیه می‌شود.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**هموفیلوس آنفلوانزا** — ⚠️ گزینه‌ی نزدیک، و منطق پشتش هم درست است (هموفیلوس هم "
 "کپسول‌دار است). ولی واکسن Hib در **بالغان روتین نیست**، چون بیماری مهاجم هموفیلوس "
 "تیپ b عمدتاً بیماری **کودکان زیر ۵ سال** است و در بالغان نادر.\n\n"
 "**مننگوکوک** — فقط با **اندیکاسیون خاص**: آسپلنی، نقص کمپلمان، سفر به کمربند مننژیت، "
 "خوابگاه. (نکته: راهنماهای امروزی مننگوکوک را برای HIV گسترده‌تر کرده‌اند، ولی در "
 "چارچوب این سؤال پنوموکوک اولویت روشن دارد.)\n\n"
 "**آبله‌مرغان** — ⚠️ **این خطرناک‌ترین گزینه است و باید دلیلش را بدانید.** واکسن "
 "آبله‌مرغان یک **ویروس زنده‌ی ضعیف‌شده** است. در فرد با ایمنی سرکوب‌شده، ویروس ضعیف‌شده "
 "می‌تواند **تکثیر کند و بیماری بسازد**. آستانه‌ی متعارف برای واکسن‌های زنده در بالغ "
 "**CD4 بالای ۲۰۰** است؛ این بیمار با CD4 برابر ۳۰۰ در مرز قابل قبول است، ولی همچنان "
 "**پنوموکوک اولویت روشن‌تری دارد** و آبله‌مرغان اندیکاسیون روتین ندارد.",
 "YOUNG HIV-POSITIVE MEN WITH A CD4 OF 300 per microlitre. Which vaccine is recommended?\n\n"
 "WARNING, THE ANSWER: the pneumococcal vaccine. And the reason is an elegant immunological concept "
 "worth understanding.\n\n"
 "EVERYONE KNOWS HIV DESTROYS T LYMPHOCYTES. But the point less often made is that HIV ALSO IMPAIRS "
 "B CELL FUNCTION — through chronic disordered B cell activation and the loss of T cell help.\n\n"
 "WHAT FOLLOWS? AN INEFFECTIVE ANTIBODY RESPONSE. And antibody is precisely what is needed against "
 "ENCAPSULATED BACTERIA — because the polysaccharide capsule blocks phagocytosis and ONLY "
 "OPSONISATION BY ANTIBODY makes it possible.\n\n"
 "WARNING, SO AN HIV-POSITIVE PERSON IS VULNERABLE TO PNEUMOCOCCUS AND HAEMOPHILUS, and that "
 "explains why 'recurrent bacterial pneumonia' is one of the earliest signs of HIV — even at a "
 "relatively high CD4.\n\n"
 "That is why the pneumococcal vaccine is recommended for every HIV-positive person, at any CD4.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "HAEMOPHILUS INFLUENZAE — WARNING, a near miss, and its underlying logic is right (Haemophilus is "
 "also encapsulated). But the Hib vaccine IS NOT ROUTINE IN ADULTS, because invasive Hib disease is "
 "mainly a disease of CHILDREN UNDER 5 and is rare in adults.\n\n"
 "MENINGOCOCCUS — only for SPECIFIC INDICATIONS: asplenia, complement deficiency, travel to the "
 "meningitis belt, dormitory living. (Note: modern guidance has widened meningococcal vaccination "
 "in HIV, but within this question pneumococcus is the clear priority.)\n\n"
 "VARICELLA — WARNING, THE MOST DANGEROUS OPTION, and you must know why. The varicella vaccine is a "
 "LIVE ATTENUATED VIRUS. In an immunosuppressed person the attenuated virus CAN REPLICATE AND CAUSE "
 "DISEASE. The conventional threshold for live vaccines in adults is CD4 ABOVE 200; this patient at "
 "300 is marginally acceptable, but PNEUMOCOCCUS REMAINS THE CLEAR PRIORITY and varicella has no "
 "routine indication.",
 ["منطقش درست است (هموفیلوس هم کپسول‌دار است) ولی واکسن Hib در بالغان روتین نیست.",
  "پاسخ صحیح — HIV پاسخ آنتی‌بادی به باکتری‌های کپسول‌دار را خراب می‌کند، پس پنوموکوک برای همه توصیه می‌شود.",
  "مننگوکوک فقط با اندیکاسیون خاص است: آسپلنی، نقص کمپلمان، سفر یا خوابگاه.",
  "خطرناک‌ترین گزینه — واکسن آبله‌مرغان زنده‌ی ضعیف‌شده است و در ایمنی سرکوب‌شده احتیاط جدی دارد."],
 ["Its logic is right (Haemophilus is also encapsulated) but the Hib vaccine is not routine in adults.",
  "Correct — HIV wrecks the antibody response to encapsulated bacteria, so pneumococcus is recommended for all.",
  "Meningococcus is for specific indications: asplenia, complement deficiency, travel or dormitory living.",
  "The most dangerous option — varicella vaccine is live attenuated and needs real caution in immunosuppression."],
 "**HIV پاسخ آنتی‌بادی را خراب می‌کند، و آنتی‌بادی همان چیزی است که باکتری کپسول‌دار می‌طلبد.**",
 "HIV wrecks the antibody response, and antibody is exactly what an encapsulated bacterium demands.",
 [OIG, H202])


# ================================================= PCP: recognise it, treat it
add("book:698", "case", "medium",
 "CD4 زیر ۲۰۰ + سرفه‌ی **خشک** + گرافی **نرمال** = **پنوموسیستیس**. گرافی نرمال آن را رد نمی‌کند.",
 "CD4 below 200 with a DRY cough and a NORMAL chest film is PNEUMOCYSTIS. A normal film does not exclude it.",
 OI_FA + [
  "⚠️ **پنوموسیستیس را از سه‌گانه‌ی بالینی‌اش بشناسید: سرفه‌ی خشک، تنگی نفس فعالیتی، تب.**",
  "**«خشک» بودن سرفه مهم است: پنومونی باکتریال خلط چرکی می‌دهد، PCP نمی‌دهد.**",
  "**شروع بیماری تدریجی و طی هفته‌ها است، برخلاف پنومونی باکتریال که روزها طول می‌کشد.**",
  "⚠️ **و مهم‌ترین دام تصویربرداری: گرافی ریه در تا یک‌چهارم موارد PCP نرمال است.**",
  "**پس گرافی نرمال، PCP را رد نمی‌کند — و این جمله را باید حفظ کرد.**",
  "**الگوی تیپیک وقتی غیرطبیعی است: انفیلتراسیون بینابینی دوطرفه و پروانه‌ای از ناف.**",
  "**و اگر شک بالینی بماند، CT با وضوح بالا الگوی شیشه‌مات را نشان می‌دهد.**",
  "**LDH بالا حساس است ولی اختصاصی نیست؛ نبودش احتمال را کم می‌کند.**",
  "⚠️ **و علامت بالینی کلاسیک: افت اشباع اکسیژن با فعالیت، بیش از آنچه گرافی توجیه می‌کند.**",
  "**تشخیص قطعی با رنگ‌آمیزی خلط القایی یا لاواژ برونکوآلوئولار است، چون ارگانیسم کشت نمی‌شود.**",
 ],
 OI_EN + [
  "WARNING: RECOGNISE PNEUMOCYSTIS BY ITS CLINICAL TRIAD — dry cough, exertional dyspnoea, fever.",
  "The DRYNESS of the cough matters: bacterial pneumonia produces purulent sputum, PCP does not.",
  "Onset is gradual over weeks, unlike bacterial pneumonia which takes days.",
  "WARNING, AND THE GREAT IMAGING TRAP: the chest film is NORMAL in up to a quarter of PCP cases.",
  "So A NORMAL FILM DOES NOT EXCLUDE PCP — memorise that sentence.",
  "The typical pattern when abnormal: bilateral interstitial infiltrates fanning out from the hila.",
  "And if clinical suspicion persists, high-resolution CT shows a ground-glass pattern.",
  "A raised LDH is sensitive but not specific; its absence lowers the probability.",
  "WARNING, AND THE CLASSIC CLINICAL SIGN: desaturation on exertion, out of proportion to the film.",
  "Definitive diagnosis is by staining induced sputum or bronchoalveolar lavage, because the organism cannot be cultured.",
 ],
 "**بیمار HIV مثبت، بدون درمان و بدون پروفیلاکسی**، با **سرفه‌های خشک**، **درد "
 "رترواسترنال** و **تب از یک ماه پیش**. **CD4 برابر ۱۸۰.** **گرافی ریه نرمال.**\n\n"
 "⚠️ **پاسخ: پنوموسیستیس جیرووسی — و هر جزء این متن عمداً آمده است.**\n\n"
 "**بیایید سرنخ‌ها را یکی‌یکی بخوانیم:**\n\n"
 "**۱) CD4 برابر ۱۸۰** — ⚠️ **زیر ۲۰۰. این همان آستانه‌ی PCP است**، و طراح آن را دقیقاً "
 "کمی زیر ۲۰۰ گذاشته تا پیام روشن باشد.\n\n"
 "**۲) بدون پروفیلاکسی** — یعنی کوتریموکسازولی که باید از CD4 زیر ۲۰۰ شروع می‌شد، شروع "
 "نشده. **در فرد تحت پروفیلاکسی، PCP بسیار کمتر محتمل است.**\n\n"
 "**۳) سرفه‌ی خشک** — پنومونی باکتریال **خلط چرکی** می‌دهد؛ PCP **خشک** است.\n\n"
 "**۴) سیر یک‌ماهه** — PCP **تدریجی و طی هفته‌ها** پیش می‌رود؛ پنومونی باکتریال طی "
 "**روزها**.\n\n"
 "**۵) و مهم‌ترین سرنخ: گرافی نرمال.**\n\n"
 "⚠️ **این را حفظ کنید: گرافی ریه در تا یک‌چهارم موارد PCP نرمال است. پس گرافی نرمال "
 "PCP را رد نمی‌کند.**\n\n"
 "**اینجا طراح یک تله گذاشته است:** دانشجویی که فکر می‌کند «گرافی نرمال یعنی ریه سالم "
 "است» به گزینه‌ی دیگری می‌رود. ولی گرافی نرمال در این بستر، **خودش یک سرنخ به نفع "
 "PCP است** — چون پنومونی باکتریال با یک ماه علامت، تقریباً همیشه گرافی غیرطبیعی دارد.\n\n"
 "**اگر شک بماند، گام بعدی CT با وضوح بالا است که الگوی شیشه‌مات را نشان می‌دهد.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**مایکوباکتریوم توبرکلوزیس** — نزدیک‌ترین رقیب و در فرد HIV مثبت همیشه باید در نظر "
 "باشد. ولی سل معمولاً **خلط چرکی یا خونی** می‌دهد و **گرافی غیرطبیعی** دارد (حتی در "
 "CD4 پایین، معمولاً لنفادنوپاتی هیلر یا انفیلتراسیون).\n\n"
 "**مایکوباکتریوم آویوم کمپلکس** — آستانه‌اش **CD4 زیر ۵۰** است، نه ۱۸۰. و تابلوی آن "
 "**منتشر** است: تب، کاهش وزن، اسهال، کم‌خونی — نه یک تابلوی ریوی خالص.\n\n"
 "**آسپرژیلوس** — در HIV نسبتاً **نادر** است و بیشتر در **نوتروپنی** یا مصرف طولانی "
 "**استروئید** دیده می‌شود. تابلوی آن معمولاً **تهاجمی و شدید** با ندول و کاویته است.",
 "AN HIV-POSITIVE PATIENT, ON NO TREATMENT AND NO PROPHYLAXIS, with a DRY COUGH, RETROSTERNAL PAIN "
 "and FEVER FOR A MONTH. CD4 = 180. THE CHEST FILM IS NORMAL.\n\n"
 "WARNING, THE ANSWER: Pneumocystis jirovecii — and every element of this stem is there "
 "deliberately.\n\n"
 "READ THE CLUES ONE BY ONE:\n\n"
 "1) CD4 = 180 — WARNING, BELOW 200. THAT IS THE PCP THRESHOLD, and the examiner placed it just "
 "below 200 to make the message clear.\n\n"
 "2) NO PROPHYLAXIS — the co-trimoxazole that should have started at CD4 below 200 was never "
 "started. IN SOMEONE ON PROPHYLAXIS, PCP IS FAR LESS LIKELY.\n\n"
 "3) A DRY COUGH — bacterial pneumonia produces PURULENT sputum; PCP is DRY.\n\n"
 "4) A ONE-MONTH COURSE — PCP progresses GRADUALLY OVER WEEKS; bacterial pneumonia over DAYS.\n\n"
 "5) AND THE MOST IMPORTANT CLUE: A NORMAL FILM.\n\n"
 "WARNING, MEMORISE THIS: THE CHEST FILM IS NORMAL IN UP TO A QUARTER OF PCP CASES. SO A NORMAL "
 "FILM DOES NOT EXCLUDE PCP.\n\n"
 "THE EXAMINER HAS SET A TRAP HERE: a student who thinks 'a normal film means healthy lungs' goes "
 "to another option. But in this context a normal film IS ITSELF A CLUE IN FAVOUR OF PCP — because "
 "bacterial pneumonia with a month of symptoms almost always has an abnormal film.\n\n"
 "IF DOUBT PERSISTS, the next step is high-resolution CT showing a ground-glass pattern.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "M. TUBERCULOSIS — the closest competitor, and always to be considered in HIV. But TB usually "
 "produces PURULENT OR BLOODY sputum and an ABNORMAL FILM (even at low CD4, usually hilar "
 "lymphadenopathy or infiltrate).\n\n"
 "M. AVIUM COMPLEX — its threshold is CD4 BELOW 50, not 180. And its picture is DISSEMINATED: "
 "fever, weight loss, diarrhoea, anaemia — not a purely pulmonary presentation.\n\n"
 "ASPERGILLUS — relatively RARE in HIV and seen mainly with NEUTROPENIA or prolonged STEROIDS. Its "
 "picture is usually INVASIVE AND SEVERE with nodules and cavitation.",
 ["سل نزدیک‌ترین رقیب است ولی معمولاً خلط چرکی یا خونی و گرافی غیرطبیعی دارد.",
  "مایکوباکتریوم آویوم آستانه‌اش CD4 زیر ۵۰ است و تابلوی منتشر می‌دهد، نه ریوی خالص.",
  "پاسخ صحیح — CD4 زیر ۲۰۰، سرفه‌ی خشک، سیر تدریجی و گرافی نرمال، همگی به PCP اشاره می‌کنند.",
  "آسپرژیلوس در HIV نادر است و بیشتر در نوتروپنی یا مصرف طولانی استروئید دیده می‌شود."],
 ["TB is the closest competitor but usually gives purulent or bloody sputum and an abnormal film.",
  "M. avium's threshold is CD4 below 50 and it gives a disseminated picture, not a purely pulmonary one.",
  "Correct — CD4 below 200, a dry cough, a gradual course and a normal film all point to PCP.",
  "Aspergillus is rare in HIV and is seen mainly with neutropenia or prolonged steroid use."],
 "**گرافی نرمال، PCP را رد نمی‌کند — در تا یک‌چهارم موارد نرمال است.**",
 "A normal chest film does not exclude PCP; it is normal in up to a quarter of cases.",
 [OIG, H202])

add("book:699", "case", "easy",
 "همان تابلو، این‌بار درمان: **کوتریموکسازول** — هم داروی درمان است و هم داروی پیشگیری.",
 "The same picture, now the treatment: CO-TRIMOXAZOLE — both the treatment drug and the prophylaxis drug.",
 OI_FA + [
  "**این سؤال قرینه‌ی سؤال قبلی است: آنجا تشخیص را پرسید، اینجا درمان را.**",
  "⚠️ **کوتریموکسازول هم درمان PCP است و هم پروفیلاکسی آن — فقط دوز فرق می‌کند.**",
  "**دوز درمانی بسیار بالاتر است و ۲۱ روز ادامه می‌یابد؛ دوز پیشگیری یک قرص روزانه است.**",
  "**و LDH بالا در این سؤال یک سرنخ اضافه است: حساس است ولی اختصاصی نیست.**",
  "⚠️ **و نکته‌ای که سؤال نپرسیده ولی حیاتی است: کورتیکواستروئید در PCP شدید.**",
  "**اگر فشار اکسیژن شریانی زیر ۷۰ میلی‌متر جیوه یا اختلاف آلوئولی-شریانی بالای ۳۵ باشد.**",
  "**استروئید مرگ‌ومیر را کم می‌کند و باید ظرف ۷۲ ساعت اول شروع شود.**",
  "**دلیلش این است که مرگ سریع ارگانیسم‌ها التهاب شدیدی می‌سازد که خودش ریه را آسیب می‌زند.**",
  "**و درمان ضدرتروویروسی هم باید ظرف دو هفته از تشخیص PCP شروع شود.**",
 ],
 OI_EN + [
  "This is the mirror of the previous question: that one asked the diagnosis, this one the treatment.",
  "WARNING: CO-TRIMOXAZOLE IS BOTH THE TREATMENT AND THE PROPHYLAXIS for PCP — only the dose differs.",
  "The treatment dose is far higher and runs for 21 days; the prophylactic dose is one tablet daily.",
  "And the raised LDH here is an extra clue: sensitive but not specific.",
  "WARNING, AND A POINT THE QUESTION DOES NOT ASK BUT WHICH IS VITAL: corticosteroids in severe PCP.",
  "If the arterial oxygen tension is below 70 mmHg or the alveolar-arterial gradient above 35.",
  "Steroids reduce mortality and must be started within the first 72 hours.",
  "The reason is that rapid killing of the organisms produces intense inflammation that itself injures the lung.",
  "And antiretroviral therapy should be started within two weeks of the PCP diagnosis.",
 ],
 "**بیمار HIV مثبت با CD4 برابر ۱۵۰**، **سرفه‌ی خشک**، **درد قفسه‌ی سینه هنگام دم**، "
 "**تب**، **LDH بالا** و **گرافی نرمال**.\n\n"
 "**این دقیقاً همان تابلوی سؤال قبلی است — و طراح این‌بار به‌جای تشخیص، درمان را "
 "می‌پرسد.**\n\n"
 "⚠️ **پاسخ: کوتریموکسازول (TMP-SMX).**\n\n"
 "**و اینجا زیباترین نکته‌ی این خوشه است:**\n\n"
 "> **کوتریموکسازول هم داروی درمان PCP است و هم داروی پیشگیری از آن. فقط دوز فرق "
 "می‌کند.**\n\n"
 "**دوز درمانی:** ۱۵ تا ۲۰ میلی‌گرم بر کیلوگرم در روز از جزء تری‌متوپریم، در دوزهای "
 "منقسم، برای **۲۱ روز**.\n\n"
 "**دوز پیشگیری:** **یک قرص دابل‌استرنت روزانه**.\n\n"
 "**همین یک دارو، همین یک ماده، در دو نقش کاملاً متفاوت.** و همین است که دانستن آن را "
 "این‌قدر پرارزش می‌کند.\n\n"
 "**و LDH بالا؟** یک سرنخ اضافه است. **در PCP حساس است ولی اختصاصی نیست** — یعنی "
 "**نبودش** احتمال را کم می‌کند، ولی **بودنش** تشخیص را قطعی نمی‌کند.\n\n"
 "⚠️ **و حالا نکته‌ای که سؤال نپرسیده ولی در بالین حیاتی است: کورتیکواستروئید.**\n\n"
 "**در PCP شدید — یعنی فشار اکسیژن شریانی زیر ۷۰ میلی‌متر جیوه یا اختلاف "
 "آلوئولی-شریانی بالای ۳۵ — باید کورتیکواستروئید اضافه کرد، و آن را ظرف ۷۲ ساعت اول "
 "شروع کرد.**\n\n"
 "**چرا؟ منطقش زیباست:** کوتریموکسازول ارگانیسم‌ها را **سریع می‌کشد**، و مرگ انبوه "
 "آن‌ها **التهاب شدیدی** در آلوئول‌ها می‌سازد که **خودش ریه را آسیب می‌زند**. استروئید "
 "جلوی همین التهاب را می‌گیرد و **مرگ‌ومیر را کاهش می‌دهد**.\n\n"
 "**و درمان ضدرتروویروسی هم باید ظرف دو هفته از تشخیص PCP شروع شود.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟** **سیپروفلوکساسین** پوشش پنوموسیستیس ندارد و در HIV "
 "خطر پنهان کردن سل را هم دارد. **ریفامپین** داروی سل است. **داکسی‌سیکلین** برای "
 "پاتوژن‌های آتیپیک است، نه پنوموسیستیس.",
 "AN HIV-POSITIVE PATIENT WITH A CD4 OF 150, a DRY COUGH, CHEST PAIN ON INSPIRATION, FEVER, A "
 "RAISED LDH and a NORMAL CHEST FILM.\n\n"
 "This is exactly the picture of the previous question — and this time the examiner asks the "
 "TREATMENT rather than the diagnosis.\n\n"
 "WARNING, THE ANSWER: CO-TRIMOXAZOLE (TMP-SMX).\n\n"
 "AND HERE IS THE MOST ELEGANT POINT IN THIS CLUSTER:\n\n"
 "> CO-TRIMOXAZOLE IS BOTH THE TREATMENT FOR PCP AND THE PROPHYLAXIS AGAINST IT. Only the dose "
 "differs.\n\n"
 "TREATMENT DOSE: 15 to 20 mg/kg/day of the trimethoprim component in divided doses, for 21 DAYS.\n\n"
 "PROPHYLACTIC DOSE: ONE DOUBLE-STRENGTH TABLET DAILY.\n\n"
 "One drug, one molecule, in two entirely different roles. And that is what makes knowing it so "
 "valuable.\n\n"
 "AND THE RAISED LDH? An extra clue. In PCP it is SENSITIVE BUT NOT SPECIFIC — so its ABSENCE "
 "lowers the probability, while its PRESENCE does not settle the diagnosis.\n\n"
 "WARNING, AND NOW A POINT THE QUESTION DOES NOT ASK BUT WHICH IS VITAL AT THE BEDSIDE: "
 "CORTICOSTEROIDS.\n\n"
 "IN SEVERE PCP — an arterial oxygen tension below 70 mmHg or an alveolar-arterial gradient above "
 "35 — CORTICOSTEROIDS MUST BE ADDED, AND STARTED WITHIN THE FIRST 72 HOURS.\n\n"
 "WHY? The logic is elegant: co-trimoxazole KILLS THE ORGANISMS RAPIDLY, and their mass death "
 "produces INTENSE ALVEOLAR INFLAMMATION that ITSELF INJURES THE LUNG. Steroids blunt that "
 "inflammation and REDUCE MORTALITY.\n\n"
 "AND ANTIRETROVIRAL THERAPY should be started within two weeks of the PCP diagnosis.\n\n"
 "AND WHY NOT THE OTHER THREE? CIPROFLOXACIN does not cover Pneumocystis and in HIV also risks "
 "masking TB. RIFAMPIN is a TB drug. DOXYCYCLINE is for atypical pathogens, not Pneumocystis.",
 ["سیپروفلوکساسین پوشش پنوموسیستیس ندارد و در HIV خطر پنهان کردن سل را هم دارد.",
  "پاسخ صحیح — کوتریموکسازول هم درمان PCP است و هم پیشگیری از آن؛ فقط دوز فرق می‌کند.",
  "ریفامپین داروی سل است و در پنوموسیستیس جایی ندارد.",
  "داکسی‌سیکلین برای پاتوژن‌های آتیپیک است، نه برای پنوموسیستیس."],
 ["Ciprofloxacin does not cover Pneumocystis and in HIV also risks masking TB.",
  "Correct — co-trimoxazole is both the treatment for PCP and the prophylaxis against it; only the dose differs.",
  "Rifampin is a TB drug and has no place against Pneumocystis.",
  "Doxycycline is for atypical pathogens, not for Pneumocystis."],
 "**یک دارو، دو نقش: کوتریموکسازول هم درمان PCP است و هم پیشگیری‌اش.**",
 "One drug, two roles: co-trimoxazole is both the treatment for PCP and its prophylaxis.",
 [OIG, H202])


# =========================================================== book:701
add("book:701", "recall", "easy",
 "کوتریموکسازولی که برای PCP شروع می‌شود، **توکسوپلاسما** را هم پوشش می‌دهد — یک قرص، دو محافظت.",
 "The co-trimoxazole started for PCP also covers TOXOPLASMA — one tablet, two protections.",
 OI_FA + [
  "**این سؤال مستقیم همان نکته‌ی دوگانگی کوتریموکسازول را می‌آزماید.**",
  "⚠️ **همان قرصی که برای PCP در CD4 زیر ۲۰۰ شروع می‌شود، توکسوپلاسما را هم می‌پوشاند.**",
  "**آستانه‌ی توکسوپلاسما CD4 زیر ۱۰۰ است، همراه با IgG مثبت ضد توکسوپلاسما.**",
  "**پس وقتی CD4 از ۲۰۰ به زیر ۱۰۰ می‌رسد، نیازی به افزودن داروی دوم نیست.**",
  "**و همین صرفه‌جویی، یکی از دلایل اصلی ترجیح کوتریموکسازول بر داپسون تنهاست.**",
  "⚠️ **اگر بیمار به کوتریموکسازول حساسیت داشته باشد، جایگزین باید هر دو را بپوشاند.**",
  "**داپسون تنها فقط PCP را می‌پوشاند؛ داپسون به‌علاوه‌ی پیریمتامین هر دو را.**",
  "**و آتوواکون هر دو را می‌پوشاند ولی بسیار گران است.**",
  "**پوشش جانبی سالمونلا، لیستریا و برخی عفونت‌های تنفسی هم از همین دارو می‌آید.**",
 ],
 OI_EN + [
  "This question tests the dual role of co-trimoxazole directly.",
  "WARNING: THE VERY TABLET STARTED FOR PCP AT CD4 BELOW 200 ALSO COVERS TOXOPLASMA.",
  "The toxoplasma threshold is CD4 below 100 together with a positive anti-toxoplasma IgG.",
  "So when the CD4 falls from 200 towards 100, no second drug needs adding.",
  "And that economy is one of the main reasons co-trimoxazole is preferred over dapsone alone.",
  "WARNING, IF THE PATIENT IS ALLERGIC TO CO-TRIMOXAZOLE, the substitute must cover both.",
  "Dapsone alone covers only PCP; dapsone plus pyrimethamine covers both.",
  "And atovaquone covers both but is very expensive.",
  "Incidental cover against Salmonella, Listeria and some respiratory infections comes from the same drug.",
 ],
 "**بیمار HIV مثبت با CD4 برابر ۹۵.** کوتریموکسازول برای پیشگیری از PCP شروع شده. "
 "**این رژیم برای کدام مورد دیگر هم اثر پیشگیرانه دارد؟**\n\n"
 "⚠️ **پاسخ: توکسوپلاسما. و این یکی از پرامتیازترین نکات کل فصل HIV است.**\n\n"
 "**چرا؟ چون یک دارو دو کار می‌کند، و این در بالین صرفه‌جویی بزرگی است:**\n\n"
 "**نردبان CD4 را دوباره بگذارید کنار هم:**\n\n"
 "**CD4 زیر ۲۰۰ ← آستانه‌ی PCP ← کوتریموکسازول شروع می‌شود.**\n\n"
 "**CD4 زیر ۱۰۰ ← آستانه‌ی توکسوپلاسموز مغزی (با IgG مثبت ضد توکسوپلاسما).**\n\n"
 "⚠️ **و نکته: وقتی CD4 از ۲۰۰ به زیر ۱۰۰ می‌رسد، لازم نیست داروی دومی اضافه کنید. "
 "همان کوتریموکسازولی که از قبل مصرف می‌شود، توکسوپلاسما را هم می‌پوشاند.**\n\n"
 "**این بیمار با CD4 برابر ۹۵ دقیقاً در همین وضعیت است: هر دو آستانه را رد کرده و "
 "یک دارو هر دو را پوشش می‌دهد.**\n\n"
 "**و نتیجه‌ی عملی مهم‌تر:** اگر بیمار به کوتریموکسازول **حساسیت** داشته باشد، جایگزین "
 "باید **هر دو را بپوشاند**:\n\n"
 "**داپسون تنها** → فقط PCP. ناکافی است اگر CD4 زیر ۱۰۰ و توکسو IgG مثبت باشد.\n\n"
 "**داپسون + پیریمتامین + لوکوورین** → هر دو. ✅\n\n"
 "**آتوواکون** → هر دو، ولی بسیار گران.\n\n"
 "**پنتامیدین استنشاقی** → فقط PCP، و حتی برای PCP هم ضعیف‌تر است چون فقط ریه را "
 "می‌پوشاند.\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**مایکوباکتریوم آویوم** — پروفیلاکسی‌اش **آزیترومایسین هفتگی** است، نه کوتریموکسازول. "
 "(و به‌روزرسانی: امروز در کسی که ART شروع می‌کند، اصلاً توصیه نمی‌شود.)\n\n"
 "**مایکوباکتریوم توبرکلوزیس** — پیشگیری‌اش **ایزونیازید** است.\n\n"
 "**سالمونلا** — ⚠️ گزینه‌ی ظریف: کوتریموکسازول **واقعاً پوشش جانبی سالمونلا دارد**، "
 "ولی این یک **اثر جانبی شناخته‌شده** است نه **اندیکاسیون پیشگیری**. توکسوپلاسما "
 "اندیکاسیون رسمی و مستند است.",
 "AN HIV-POSITIVE PATIENT WITH A CD4 OF 95. Co-trimoxazole has been started for PCP prophylaxis. "
 "AGAINST WHICH OTHER ORGANISM DOES THIS REGIMEN ALSO PROTECT?\n\n"
 "WARNING, THE ANSWER: TOXOPLASMA. And this is one of the highest-yield points in the whole HIV "
 "chapter.\n\n"
 "WHY? Because one drug does two jobs, and clinically that is a large economy:\n\n"
 "LAY THE CD4 LADDER OUT AGAIN:\n\n"
 "CD4 BELOW 200 — the PCP threshold — co-trimoxazole begins.\n\n"
 "CD4 BELOW 100 — the threshold for cerebral toxoplasmosis (with a positive anti-toxoplasma IgG).\n\n"
 "WARNING, AND THE POINT: WHEN THE CD4 FALLS FROM 200 TOWARDS 100, NO SECOND DRUG NEED BE ADDED. "
 "The co-trimoxazole already being taken covers toxoplasma too.\n\n"
 "This patient at CD4 95 is exactly in that position: both thresholds crossed, ONE DRUG covering "
 "both.\n\n"
 "AND THE MORE IMPORTANT PRACTICAL CONSEQUENCE: if the patient is ALLERGIC to co-trimoxazole, the "
 "substitute must COVER BOTH:\n\n"
 "DAPSONE ALONE covers only PCP. Insufficient if the CD4 is below 100 with positive toxo IgG.\n\n"
 "DAPSONE plus PYRIMETHAMINE plus LEUCOVORIN covers both.\n\n"
 "ATOVAQUONE covers both, but is very expensive.\n\n"
 "AEROSOLISED PENTAMIDINE covers only PCP, and even for PCP is weaker because it reaches only the "
 "lung.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "M. AVIUM — its prophylaxis is WEEKLY AZITHROMYCIN, not co-trimoxazole. (And an update: today it "
 "is not recommended at all in someone starting ART.)\n\n"
 "M. TUBERCULOSIS — its prevention is ISONIAZID.\n\n"
 "SALMONELLA — WARNING, a subtle option: co-trimoxazole DOES give incidental cover against "
 "Salmonella, but that is a RECOGNISED SIDE BENEFIT rather than a PROPHYLACTIC INDICATION. "
 "Toxoplasma is the formal, documented indication.",
 ["سالمونلا پوشش جانبی می‌گیرد، ولی این یک اثر جانبی است نه اندیکاسیون رسمی پیشگیری.",
  "پروفیلاکسی مایکوباکتریوم آویوم آزیترومایسین هفتگی است، نه کوتریموکسازول.",
  "پاسخ صحیح — همان کوتریموکسازولِ PCP، توکسوپلاسما را هم می‌پوشاند: یک قرص، دو محافظت.",
  "پیشگیری از مایکوباکتریوم توبرکلوزیس با ایزونیازید انجام می‌شود، نه کوتریموکسازول."],
 ["Salmonella gets incidental cover, but that is a side benefit rather than a formal prophylactic indication.",
  "M. avium prophylaxis is weekly azithromycin, not co-trimoxazole.",
  "Correct — the same co-trimoxazole given for PCP also covers toxoplasma: one tablet, two protections.",
  "M. tuberculosis is prevented with isoniazid, not co-trimoxazole."],
 "**یک قرص، دو محافظت: کوتریموکسازول هم PCP و هم توکسوپلاسما را می‌پوشاند.**",
 "One tablet, two protections: co-trimoxazole covers both PCP and toxoplasma.",
 [OIG, H202])


# =========================================================== book:703
add("book:703", "recall", "medium",
 "میان توکسوپلاسما، کریپتوکوک، هیستوپلاسموز و آمیبیاز — **هیستوپلاسموز** کمتر از همه مطرح است.",
 "Of toxoplasma, cryptococcus, histoplasmosis and amoebiasis, HISTOPLASMOSIS is the least likely.",
 OI_FA + [
  "**عفونت‌های فرصت‌طلب CNS در HIV یک فهرست کوتاه و قابل حفظ دارند.**",
  "⚠️ **دو مورد اول و شایع‌ترین: توکسوپلاسموز مغزی و مننژیت کریپتوکوکی.**",
  "**توکسوپلاسموز در CD4 زیر ۱۰۰: ضایعات حلقوی متعدد در گانگلیون‌های قاعده‌ای و اتصال خاکستری-سفید.**",
  "**کریپتوکوک در CD4 زیر ۱۰۰: مننژیت تحت‌حاد با سردرد و تب و کمترین علائم مننژیال.**",
  "**و آنتی‌ژن کریپتوکوکی در خون و مایع مغزی‌نخاعی، حساس‌ترین و سریع‌ترین راه تشخیص است.**",
  "**بقیه‌ی فهرست: لنفوم مغزی اولیه، لکوانسفالوپاتی مولتی‌فوکال پیشرونده، انسفالوپاتی HIV، CMV.**",
  "⚠️ **و هیستوپلاسموز در HIV یک بیماری منتشر است، نه یک بیماری CNS.**",
  "**تابلوی آن تب، کاهش وزن، هپاتواسپلنومگالی، پان‌سیتوپنی و ضایعات پوستی است.**",
  "**درگیری CNS در آن رخ می‌دهد ولی در اقلیت موارد و معمولاً در بستر بیماری منتشر.**",
  "**و توزیع جغرافیایی دارد: دره‌های اوهایو و می‌سی‌سی‌پی، نه یک تشخیص روزمره در ایران.**",
 ],
 OI_EN + [
  "The CNS opportunistic infections of HIV form a short, memorisable list.",
  "WARNING, THE FIRST TWO AND COMMONEST: cerebral toxoplasmosis and cryptococcal meningitis.",
  "Toxoplasmosis at CD4 below 100: multiple ring-enhancing lesions in the basal ganglia and grey-white junction.",
  "Cryptococcus at CD4 below 100: subacute meningitis with headache and fever and minimal meningism.",
  "And cryptococcal antigen in blood and CSF is the most sensitive and fastest route to diagnosis.",
  "The rest of the list: primary cerebral lymphoma, progressive multifocal leucoencephalopathy, HIV encephalopathy, CMV.",
  "WARNING, AND HISTOPLASMOSIS IN HIV IS A DISSEMINATED DISEASE, not a CNS disease.",
  "Its picture is fever, weight loss, hepatosplenomegaly, pancytopenia and skin lesions.",
  "CNS involvement does occur but in a minority, and usually within disseminated disease.",
  "And it is geographically restricted: the Ohio and Mississippi valleys, not an everyday diagnosis in Iran.",
 ],
 "سؤال می‌پرسد کدام مورد به‌عنوان **عفونت فرصت‌طلب CNS** در HIV **کمتر مطرح** است.\n\n"
 "⚠️ **پاسخ: هیستوپلاسموز.**\n\n"
 "**اول فهرست عفونت‌های فرصت‌طلب CNS در HIV را مرور کنیم، چون کوتاه و قابل حفظ است:**\n\n"
 "**۱) توکسوپلاسموز مغزی** — شایع‌ترین ضایعه‌ی فضاگیر مغز در ایدز. **آستانه: CD4 زیر "
 "۱۰۰.** تصویر: **ضایعات حلقوی متعدد** در **گانگلیون‌های قاعده‌ای** و **اتصال "
 "خاکستری-سفید**.\n\n"
 "**۲) مننژیت کریپتوکوکی** — **آستانه: CD4 زیر ۱۰۰.** تابلوی **تحت‌حاد**: سردرد و تب "
 "طی هفته‌ها، با **کمترین علائم مننژیال** (چون پاسخ التهابی ضعیف است). ⚠️ **و "
 "آنتی‌ژن کریپتوکوکی در خون و CSF حساس‌ترین و سریع‌ترین راه تشخیص است.**\n\n"
 "**۳) لنفوم مغزی اولیه** — مرتبط با EBV؛ در تصویربرداری ضایعه‌ی معمولاً **منفرد** و "
 "بزرگ‌تر، که افتراقش از توکسوپلاسموز کلاسیک است.\n\n"
 "**۴) لکوانسفالوپاتی مولتی‌فوکال پیشرونده (PML)** — ویروس JC؛ ضایعات ماده‌ی سفید "
 "**بدون** افزایش جذب کنتراست و **بدون** اثر فشاری.\n\n"
 "**۵) انسفالوپاتی HIV** و **۶) انسفالیت CMV** (در CD4 زیر ۵۰).\n\n"
 "⚠️ **حالا چرا هیستوپلاسموز در این فهرست نیست؟**\n\n"
 "**چون هیستوپلاسموز در HIV یک بیماری منتشر است، نه یک بیماری CNS.** تابلوی آن: "
 "**تب، کاهش وزن، هپاتواسپلنومگالی، پان‌سیتوپنی و ضایعات پوستی**. **درگیری CNS در آن "
 "رخ می‌دهد ولی در اقلیت موارد** و معمولاً در بستر بیماری منتشر — نه به‌عنوان تظاهر "
 "اصلی.\n\n"
 "**و یک عامل دوم: توزیع جغرافیایی.** هیستوپلاسموز در **دره‌های اوهایو و می‌سی‌سی‌پی** "
 "آندمیک است. در ایران یک تشخیص روزمره نیست.\n\n"
 "**و آمیبیاز؟** ⚠️ این گزینه ظریف است. **انتامبا هیستولیتیکا** عمدتاً کولیت و آبسه‌ی "
 "کبدی می‌دهد و به‌ندرت به مغز می‌رود. ولی **آمیب‌های آزادزی** — **آکانتامبا** و "
 "**بالاموتیا** — واقعاً **انسفالیت گرانولوماتوز آمیبی** می‌سازند، و این در بیماران "
 "ایدزی **گزارش شده است**. پس آمیبیاز، هرچند نادر، **در فهرست هست**؛ در حالی که "
 "هیستوپلاسموز اساساً یک بیماری **سیستمیک** طبقه‌بندی می‌شود. **همین تفاوت، پاسخ سؤال "
 "را می‌سازد.**",
 "The stem asks which is LEAST LIKELY as a CNS OPPORTUNISTIC INFECTION in HIV.\n\n"
 "WARNING, THE ANSWER: HISTOPLASMOSIS.\n\n"
 "FIRST REVIEW THE LIST OF CNS OPPORTUNISTIC INFECTIONS IN HIV, because it is short and "
 "memorisable:\n\n"
 "1) CEREBRAL TOXOPLASMOSIS — the commonest space-occupying brain lesion in AIDS. THRESHOLD: CD4 "
 "BELOW 100. Imaging: MULTIPLE RING-ENHANCING LESIONS in the BASAL GANGLIA and at the GREY-WHITE "
 "JUNCTION.\n\n"
 "2) CRYPTOCOCCAL MENINGITIS — THRESHOLD: CD4 BELOW 100. A SUBACUTE picture: headache and fever "
 "over weeks with MINIMAL MENINGISM (because the inflammatory response is weak). WARNING, AND "
 "CRYPTOCOCCAL ANTIGEN in blood and CSF is the most sensitive and fastest route to diagnosis.\n\n"
 "3) PRIMARY CEREBRAL LYMPHOMA — EBV-related; on imaging usually a SINGLE larger lesion, whose "
 "distinction from toxoplasmosis is a classic problem.\n\n"
 "4) PROGRESSIVE MULTIFOCAL LEUCOENCEPHALOPATHY (PML) — JC virus; white matter lesions WITHOUT "
 "enhancement and WITHOUT mass effect.\n\n"
 "5) HIV ENCEPHALOPATHY and 6) CMV ENCEPHALITIS (at CD4 below 50).\n\n"
 "WARNING, NOW WHY IS HISTOPLASMOSIS NOT ON THE LIST?\n\n"
 "BECAUSE HISTOPLASMOSIS IN HIV IS A DISSEMINATED DISEASE, NOT A CNS DISEASE. Its picture is FEVER, "
 "WEIGHT LOSS, HEPATOSPLENOMEGALY, PANCYTOPENIA AND SKIN LESIONS. CNS INVOLVEMENT DOES OCCUR BUT IN "
 "A MINORITY, usually within disseminated disease — not as the principal presentation.\n\n"
 "AND A SECOND FACTOR: GEOGRAPHY. Histoplasmosis is endemic in the OHIO AND MISSISSIPPI VALLEYS. In "
 "Iran it is not an everyday diagnosis.\n\n"
 "AND AMOEBIASIS? WARNING, a subtle option. ENTAMOEBA HISTOLYTICA mainly causes colitis and liver "
 "abscess and rarely reaches the brain. But the FREE-LIVING AMOEBAE — ACANTHAMOEBA and BALAMUTHIA — "
 "genuinely cause GRANULOMATOUS AMOEBIC ENCEPHALITIS, and this HAS BEEN REPORTED in AIDS patients. "
 "So amoebiasis, though rare, IS ON THE LIST; whereas histoplasmosis is fundamentally classified as "
 "a SYSTEMIC disease. THAT DIFFERENCE IS WHAT MAKES THE ANSWER.",
 ["توکسوپلاسموز شایع‌ترین ضایعه‌ی فضاگیر مغز در ایدز است، با ضایعات حلقوی متعدد در CD4 زیر ۱۰۰.",
  "مننژیت کریپتوکوکی در CD4 زیر ۱۰۰ رخ می‌دهد و آنتی‌ژن کریپتوکوکی سریع‌ترین راه تشخیص آن است.",
  "پاسخ صحیح — هیستوپلاسموز در HIV بیماری منتشر است نه CNS، و توزیع جغرافیایی محدودی هم دارد.",
  "آمیب‌های آزادزی مانند آکانتامبا انسفالیت گرانولوماتوز می‌سازند و در ایدز گزارش شده‌اند."],
 ["Toxoplasmosis is the commonest space-occupying brain lesion in AIDS, with multiple ring lesions at CD4 below 100.",
  "Cryptococcal meningitis occurs at CD4 below 100 and cryptococcal antigen is the fastest route to its diagnosis.",
  "Correct — histoplasmosis in HIV is a disseminated rather than a CNS disease, and is geographically restricted.",
  "Free-living amoebae such as Acanthamoeba cause granulomatous encephalitis and have been reported in AIDS."],
 "**هیستوپلاسموز در HIV منتشر است، نه CNS — و توزیع جغرافیایی محدودی دارد.**",
 "Histoplasmosis in HIV is disseminated rather than CNS, and is geographically restricted.",
 [OIG, H202])


# ======================================= book:705 — the guideline that moved
add("book:705", "recall", "hard",
 "کلید آن دوره: رژیم چهارتایی. ⚠️ **ولی امروز سه جزء از چهار جزء آن توصیه نمی‌شود** — هر دو را بدانید.",
 "The era's key was the four-drug regimen. WARNING, BUT TODAY THREE OF ITS FOUR COMPONENTS ARE NOT RECOMMENDED — know both.",
 OI_FA + [
  "⚠️ **این سؤال یکی از مواردی است که راهنما زیر پای کلید جابه‌جا شده است.**",
  "**کلید چاپی، کامل‌ترین گزینه از چهار گزینه‌ی موجود را انتخاب کرده و در چارچوب خودش درست است.**",
  "**پس کلید تصحیح نمی‌شود؛ ولی باید بدانید امروز چه چیزی عوض شده است.**",
  "**آنچه سر جایش مانده: کوتریموکسازول برای PCP و توکسوپلاسما. این هنوز پایه است.**",
  "⚠️ **پروفیلاکسی اولیه‌ی CMV با گان‌سیکلوویر امروز توصیه نمی‌شود.**",
  "**یک کارآزمایی تصادفی نشان داد سودی ندارد، و راه درست پیشگیری، خودِ درمان ضدرتروویروسی است.**",
  "⚠️ **پروفیلاکسی اولیه‌ی کریپتوکوک با فلوکونازول هم توصیه نمی‌شود.**",
  "**چون بقا را بهبود نداد و خطر مقاومت قارچی و هزینه را بالا برد.**",
  "⚠️ **و پروفیلاکسی MAC با آزیترومایسین، اگر بیمار ART شروع کند، دیگر توصیه نمی‌شود.**",
  "**فقط اگر ART شروع نشود یا سرکوب ویروسی حاصل نشود، آزیترومایسین اندیکاسیون دارد.**",
  "**مفهوم پشت هر سه تغییر یکی است: درمان ضدرتروویروسی بهترین پروفیلاکسی است.**",
  "**بازسازی ایمنی از هر دارویی که جای آن ایمنی را بگیرد، مؤثرتر و کم‌عارضه‌تر است.**",
 ],
 OI_EN + [
  "WARNING: THIS IS ONE OF THE ITEMS WHERE THE GUIDELINE MOVED UNDER THE KEY.",
  "The printed key chose the most complete of the four options offered and is right on its own terms.",
  "So the key is NOT corrected; but you must know what has changed today.",
  "WHAT STILL STANDS: co-trimoxazole for PCP and toxoplasma. That remains the foundation.",
  "WARNING: PRIMARY CMV PROPHYLAXIS WITH GANCICLOVIR IS NOT RECOMMENDED TODAY.",
  "A randomised trial showed no benefit, and the right prevention is antiretroviral therapy itself.",
  "WARNING: PRIMARY CRYPTOCOCCAL PROPHYLAXIS WITH FLUCONAZOLE IS ALSO NOT RECOMMENDED.",
  "Because it did not improve survival and it raised the risk of fungal resistance and the cost.",
  "WARNING, AND MAC PROPHYLAXIS WITH AZITHROMYCIN IS NO LONGER RECOMMENDED IF THE PATIENT STARTS ART.",
  "Only if ART is not started, or viral suppression is not achieved, is azithromycin indicated.",
  "The concept behind all three changes is the same: ANTIRETROVIRAL THERAPY IS THE BEST PROPHYLAXIS.",
  "Immune reconstitution is more effective and less toxic than any drug substituting for that immunity.",
 ],
 "**بیمار مبتلا به ایدز پیشرفته با CD4 زیر ۵۰.** کدام رژیم پروفیلاکسی بهتر است؟\n\n"
 "**کلید چاپی: آزیترومایسین + کوتریموکسازول + فلوکونازول + گان‌سیکلوویر.**\n\n"
 "⚠️ **این یکی از آن سؤال‌هایی است که راهنما زیر پای کلید جابه‌جا شده است — و روش ثابت "
 "این بانک در چنین مواردی این است: کلید را تصحیح نمی‌کنیم، ولی هر دو را صریح "
 "می‌گوییم.**\n\n"
 "**چرا کلید تصحیح نمی‌شود؟** چون سؤال می‌پرسد «کدام روش **بهتر** است» و از میان "
 "**چهار گزینه‌ی موجود**، گزینه‌ی چهارم **کامل‌ترین** است. هر سه گزینه‌ی دیگر زیرمجموعه‌ی "
 "آن‌اند. در چارچوب دانش زمان طرح سؤال، کلید درست است، و تصحیح آن دانشجو را در آزمون "
 "واقعی به پاسخ غلط می‌رساند.\n\n"
 "**حالا بیایید هر جزء را با راهنمای امروز بسنجیم:**\n\n"
 "**۱) کوتریموکسازول** ✅ **سر جایش است.** در CD4 زیر ۵۰، هم PCP (زیر ۲۰۰) و هم "
 "توکسوپلاسما (زیر ۱۰۰) اندیکاسیون دارند، و **یک قرص هر دو را می‌پوشاند**. این هنوز "
 "پایه‌ی پروفیلاکسی است.\n\n"
 "**۲) آزیترومایسین برای MAC** ⚠️ **مشروط شده است.** راهنمای امروز NIH/CDC/IDSA "
 "می‌گوید: **پروفیلاکسی اولیه‌ی MAC در کسی که فوراً ART شروع می‌کند، صرف‌نظر از CD4، "
 "توصیه نمی‌شود (AII).** فقط اگر ART شروع نشود، یا بیمار روی ART همچنان ویرمیک بماند، "
 "یا رژیم سرکوب‌کننده‌ی کاملی در دسترس نباشد، **آزیترومایسین ۱۲۰۰ میلی‌گرم هفتگی** "
 "اندیکاسیون دارد (AI).\n\n"
 "**۳) فلوکونازول برای کریپتوکوک** ❌ **پروفیلاکسی اولیه توصیه نمی‌شود (DI).** دلیلش: "
 "**بقا را بهبود نداد**، و در مقابل **خطر مقاومت قارچی** و **هزینه** را بالا برد.\n\n"
 "**۴) گان‌سیکلوویر برای CMV** ❌ **پروفیلاکسی اولیه توصیه نمی‌شود (AI).** یک کارآزمایی "
 "تصادفی شاهددار نشان داد **حتی در افراد با CD4 زیر ۱۰۰ و ویرمی CMV هم سودی ندارد**. "
 "راه درست: **حفظ CD4 بالای ۱۰۰ با ART**، و **آموزش بیمار برای شناختن علائم زودرس "
 "رتینیت** (مگس‌پران، تاری دید).\n\n"
 "⚠️ **و حالا مفهوم واحدی که پشت هر سه تغییر است، و ارزشمندترین چیزی است که از این "
 "سؤال یاد می‌گیرید:**\n\n"
 "> **درمان ضدرتروویروسی، خودش بهترین پروفیلاکسی است.**\n\n"
 "**در دوره‌ای که ART ضعیف و پرعارضه بود، پزشکان مجبور بودند برای هر عفونت فرصت‌طلب یک "
 "دارو اضافه کنند. امروز که ART قوی و کم‌عارضه است، بازسازی ایمنی از هر دارویی که جای "
 "آن ایمنی را بگیرد، مؤثرتر، ارزان‌تر و کم‌عارضه‌تر است.** هر داروی اضافه یعنی عارضه‌ی "
 "بیشتر، تداخل بیشتر، و پایبندی کمتر.\n\n"
 "**پس پاسخ آزمون، گزینه‌ی چهارم است؛ و پاسخ بالینی امروز، کوتریموکسازول به‌علاوه‌ی "
 "شروع فوری ART است.**",
 "A PATIENT WITH ADVANCED AIDS AND A CD4 BELOW 50. Which prophylactic regimen is better?\n\n"
 "THE PRINTED KEY: azithromycin + co-trimoxazole + fluconazole + ganciclovir.\n\n"
 "WARNING, THIS IS ONE OF THOSE QUESTIONS WHERE THE GUIDELINE MOVED UNDER THE KEY — and this bank's "
 "fixed method in such cases is: DO NOT CORRECT THE KEY, but state both plainly.\n\n"
 "WHY IS THE KEY NOT CORRECTED? Because the stem asks which method is BETTER, and among the FOUR "
 "OPTIONS OFFERED the fourth is the MOST COMPLETE; the other three are subsets of it. Within the "
 "knowledge of its time the key is right, and correcting it would lead the student to answer the "
 "real exam wrongly.\n\n"
 "NOW WEIGH EACH COMPONENT AGAINST TODAY'S GUIDANCE:\n\n"
 "1) CO-TRIMOXAZOLE — STILL STANDS. At CD4 below 50, both PCP (below 200) and toxoplasma (below "
 "100) are indicated, and ONE TABLET COVERS BOTH. This remains the foundation.\n\n"
 "2) AZITHROMYCIN FOR MAC — WARNING, NOW CONDITIONAL. Today's NIH/CDC/IDSA guidance says: PRIMARY "
 "MAC PROPHYLAXIS IS NOT RECOMMENDED FOR SOMEONE WHO IMMEDIATELY STARTS ART, REGARDLESS OF CD4 "
 "(AII). Only if ART is not started, or the patient remains viraemic on ART, or no fully suppressive "
 "regimen is available, is AZITHROMYCIN 1200 mg WEEKLY indicated (AI).\n\n"
 "3) FLUCONAZOLE FOR CRYPTOCOCCUS — PRIMARY PROPHYLAXIS IS NOT RECOMMENDED (DI). The reason: it DID "
 "NOT IMPROVE SURVIVAL, while raising the RISK OF FUNGAL RESISTANCE and the COST.\n\n"
 "4) GANCICLOVIR FOR CMV — PRIMARY PROPHYLAXIS IS NOT RECOMMENDED (AI). A randomised controlled "
 "trial showed NO BENEFIT EVEN IN PEOPLE WITH CD4 BELOW 100 AND CMV VIRAEMIA. The right approach: "
 "KEEP THE CD4 ABOVE 100 WITH ART, and TEACH THE PATIENT TO RECOGNISE EARLY RETINITIS (floaters, "
 "blurred vision).\n\n"
 "WARNING, AND NOW THE SINGLE CONCEPT BEHIND ALL THREE CHANGES, the most valuable thing you will "
 "take from this question:\n\n"
 "> ANTIRETROVIRAL THERAPY IS ITSELF THE BEST PROPHYLAXIS.\n\n"
 "IN THE ERA WHEN ART WAS WEAK AND TOXIC, clinicians had to add a drug for every opportunistic "
 "infection. TODAY, WITH ART STRONG AND WELL TOLERATED, IMMUNE RECONSTITUTION IS MORE EFFECTIVE, "
 "CHEAPER AND LESS TOXIC THAN ANY DRUG SUBSTITUTING FOR THAT IMMUNITY. Every extra drug means more "
 "side effects, more interactions and worse adherence.\n\n"
 "SO THE EXAM ANSWER IS THE FOURTH OPTION; AND TODAY'S CLINICAL ANSWER IS CO-TRIMOXAZOLE PLUS "
 "IMMEDIATE ART.",
 ["آزیترومایسین تنها فقط MAC را می‌پوشاند و PCP و توکسوپلاسما را بی‌محافظ می‌گذارد.",
  "این ترکیب PCP و توکسوپلاسما و MAC را می‌پوشاند ولی از گزینه‌ی چهارم کامل‌تر نیست.",
  "افزودن فلوکونازول هم آن را کامل‌تر نمی‌کند؛ گزینه‌ی چهارم در چارچوب سؤال جامع‌ترین است.",
  "پاسخ صحیح در چارچوب آن دوره — ولی امروز سه جزء از چهار جزء آن توصیه نمی‌شود، و درسنامه هر دو را می‌گوید."],
 ["Azithromycin alone covers only MAC and leaves PCP and toxoplasma unprotected.",
  "This combination covers PCP, toxoplasma and MAC but is less complete than the fourth option.",
  "Adding fluconazole still does not make it as complete; the fourth option is the most comprehensive as the question is framed.",
  "Correct within that era — but today three of its four components are not recommended, and the lesson states both."],
 "**درمان ضدرتروویروسی، خودش بهترین پروفیلاکسی است.**",
 "Antiretroviral therapy is itself the best prophylaxis.",
 [OIG, H202])


# =========================================================== book:708
add("book:708", "recall", "hard",
 "جمله‌ی نادرست: تست توبرکولین در **CD4 پایین** منفی می‌شود، نه در CD4 بالا. **جهت نامعادله را بخوانید.**",
 "The false statement: the tuberculin test becomes negative at a LOW CD4, not a high one. READ THE DIRECTION OF THE INEQUALITY.",
 OI_FA + [
  "**این سؤال چهار جمله درباره‌ی هم‌عفونتی HIV و سل دارد و سه‌تا درست‌اند.**",
  "⚠️ **اصل حاکم بر هر چهار جمله یکی است: هرچه CD4 پایین‌تر، تابلوی سل غیرتیپیک‌تر.**",
  "**در CD4 بالای ۲۰۰، ایمنی سلولی نسبتاً حفظ شده و سل مثل فرد غیرمبتلا رفتار می‌کند.**",
  "**یعنی الگوی رآکتیواسیون: لوب فوقانی، کاویته، اسمیر خلط مثبت، توبرکولین مثبت.**",
  "⚠️ **و در CD4 زیر ۲۰۰، ایمنی سلولی فرو می‌ریزد و همه‌چیز وارونه می‌شود.**",
  "**الگوی شبه‌اولیه: نواحی میانی و تحتانی، بدون کاویته، لنفادنوپاتی هیلر، اسمیر منفی.**",
  "**چرا بدون کاویته؟ چون کاویته محصول پاسخ ایمنی شدید است، نه محصول خودِ باکتری.**",
  "**و اسمیر منفی به همین دلیل: بدون کاویته، بار باکتریایی خلط کمتر است.**",
  "⚠️ **و تست توبرکولین یک آزمون ایمنی سلولی است، نه یک آزمون حضور باکتری.**",
  "**پس در CD4 پایین آنرژی رخ می‌دهد و توبرکولین کاذباً منفی می‌شود.**",
  "**در یک مطالعه، آنرژی در CD4 زیر ۲۰۰ حدود ۷۲ درصد بود و در CD4 حدود ۶۰۰ حدود ۲۵ درصد.**",
  "**قاعده‌ی عملی: توبرکولین منفی در فرد HIV مثبت سل را رد نمی‌کند.**",
 ],
 OI_EN + [
  "This question offers four statements about HIV-TB coinfection, three of which are true.",
  "WARNING, ONE PRINCIPLE GOVERNS ALL FOUR: the lower the CD4, the more atypical the TB.",
  "Above CD4 200, cellular immunity is relatively preserved and TB behaves as in an uninfected person.",
  "That is the reactivation pattern: upper lobe, cavitation, positive sputum smear, positive tuberculin.",
  "WARNING, AND BELOW CD4 200 CELLULAR IMMUNITY COLLAPSES AND EVERYTHING INVERTS.",
  "A primary-like pattern: mid and lower zones, no cavitation, hilar lymphadenopathy, negative smear.",
  "Why no cavitation? Because a cavity is the product of an intense immune response, not of the bacterium itself.",
  "And the smear is negative for the same reason: without a cavity the sputum bacterial load is lower.",
  "WARNING, AND THE TUBERCULIN TEST IS A TEST OF CELLULAR IMMUNITY, not a test for the bacterium.",
  "So at a low CD4 anergy occurs and the tuberculin becomes falsely negative.",
  "In one study anergy was about 72 per cent below CD4 200 and about 25 per cent at CD4 around 600.",
  "The practical rule: a negative tuberculin in an HIV-positive person does not exclude TB.",
 ],
 "این سؤال چهار جمله درباره‌ی **هم‌عفونتی HIV و سل** دارد و می‌پرسد کدام **نادرست** است. "
 "⚠️ **و هر چهار جمله حول یک اصل واحد می‌چرخند، پس اول آن اصل را بفهمید:**\n\n"
 "> **هرچه CD4 پایین‌تر، تابلوی سل غیرتیپیک‌تر — چون تابلوی «تیپیک» سل، محصول پاسخ "
 "ایمنی سلولی است، نه محصول خودِ باکتری.**\n\n"
 "**در CD4 بالای ۲۰۰:** ایمنی سلولی **نسبتاً حفظ شده** است، پس سل مثل فرد غیرHIV رفتار "
 "می‌کند — **الگوی رآکتیواسیون**: لوب فوقانی، **کاویته**، **اسمیر خلط مثبت**، "
 "**توبرکولین مثبت**.\n\n"
 "**در CD4 زیر ۲۰۰:** ایمنی سلولی **فرو ریخته** است، پس همه‌چیز وارونه می‌شود — "
 "**الگوی شبه‌اولیه**: نواحی میانی و تحتانی، **بدون کاویته**، لنفادنوپاتی هیلر، "
 "**اسمیر منفی**، **توبرکولین منفی**.\n\n"
 "**حالا چهار جمله را بسنجیم:**\n\n"
 "**«در CD4 بالای ۲۰۰، اسمیر خلط در اکثر موارد مثبت است»** ✅ **درست.** ایمنی حفظ شده "
 "کاویته می‌سازد، و کاویته بار باکتریایی بالایی در خلط ایجاد می‌کند.\n\n"
 "⚠️ **«تست پوستی توبرکولین در بیمارانی که CD4 بالای ۲۰۰ دارند در اکثر موارد منفی "
 "است»** ❌ **این جمله‌ی نادرست است — و جهت نامعادله را دقیق بخوانید.**\n\n"
 "**چرا؟ چون تست توبرکولین یک آزمون ایمنی سلولی است، نه آزمون حضور باکتری.** واکنش "
 "ازدیاد حساسیت تأخیری است که به **لنفوسیت T سالم** نیاز دارد. **پس هرچه CD4 بالاتر، "
 "احتمال مثبت شدن بیشتر — دقیقاً برعکس آنچه جمله می‌گوید.**\n\n"
 "**ارقام این را قطعی می‌کنند:** در یک مطالعه، **آنرژی** در بیماران با **CD4 زیر ۲۰۰** "
 "حدود **۷۲ درصد** بود، و در بیماران با **CD4 حدود ۶۰۰** حدود **۲۵ درصد**. یعنی آنرژی "
 "با **پایین آمدن** CD4 زیاد می‌شود، نه با بالا رفتنش.\n\n"
 "**قاعده‌ی عملی که از این می‌آید:** ⚠️ **توبرکولین منفی در فرد HIV مثبت، سل را رد "
 "نمی‌کند.** به همین دلیل آستانه‌ی مثبت بودن PPD در افراد HIV مثبت به **۵ میلی‌متر** "
 "کاهش داده شده است (به‌جای ۱۰ یا ۱۵ در سایرین).\n\n"
 "**«در CD4 زیر ۲۰۰، درگیری ریوی غالباً شبیه سل ریوی اولیه است»** ✅ **درست.** بدون "
 "ایمنی سلولی کافی، بدن نمی‌تواند گرانولوم محدودکننده بسازد، پس تصویر شبیه سل اولیه‌ی "
 "کودکان می‌شود.\n\n"
 "**«در CD4 زیر ۲۰۰، درگیری ریوی اغلب به‌صورت انفیلتراسیون بدون کاویته است»** ✅ "
 "**درست، و دلیلش زیباست:** ⚠️ **کاویته محصول پاسخ ایمنی شدید است، نه محصول باکتری.** "
 "نکروز کازئوز و تخریب بافت از **حمله‌ی ایمنی** می‌آید. وقتی ایمنی نباشد، **کاویته هم "
 "نیست** — و همین توضیح می‌دهد چرا اسمیر هم منفی می‌شود.",
 "This question gives four statements about HIV-TB COINFECTION and asks which is FALSE. WARNING, "
 "AND ALL FOUR TURN ON ONE PRINCIPLE, so understand that first:\n\n"
 "> THE LOWER THE CD4, THE MORE ATYPICAL THE TB — because the 'typical' picture of TB is the "
 "product of the CELLULAR IMMUNE RESPONSE, not of the bacterium itself.\n\n"
 "ABOVE CD4 200: cellular immunity is RELATIVELY PRESERVED, so TB behaves as in an HIV-negative "
 "person — THE REACTIVATION PATTERN: upper lobe, CAVITATION, POSITIVE SPUTUM SMEAR, POSITIVE "
 "TUBERCULIN.\n\n"
 "BELOW CD4 200: cellular immunity has COLLAPSED, so everything inverts — A PRIMARY-LIKE PATTERN: "
 "mid and lower zones, NO CAVITATION, hilar lymphadenopathy, NEGATIVE SMEAR, NEGATIVE TUBERCULIN.\n\n"
 "NOW WEIGH THE FOUR STATEMENTS:\n\n"
 "'ABOVE CD4 200 THE SPUTUM SMEAR IS POSITIVE IN MOST CASES' — TRUE. Preserved immunity makes "
 "cavities, and cavities produce a high sputum bacterial load.\n\n"
 "WARNING: 'THE TUBERCULIN SKIN TEST IS NEGATIVE IN MOST PATIENTS WITH CD4 ABOVE 200' — THIS IS THE "
 "FALSE STATEMENT, and read the direction of the inequality carefully.\n\n"
 "WHY? BECAUSE THE TUBERCULIN TEST IS A TEST OF CELLULAR IMMUNITY, NOT A TEST FOR THE BACTERIUM. It "
 "is a delayed hypersensitivity reaction requiring HEALTHY T LYMPHOCYTES. SO THE HIGHER THE CD4, THE "
 "MORE LIKELY IT IS POSITIVE — exactly the opposite of what the statement says.\n\n"
 "THE FIGURES SETTLE IT: in one study ANERGY was about 72 PER CENT in patients with CD4 BELOW 200, "
 "and about 25 PER CENT at CD4 AROUND 600. So anergy rises as the CD4 FALLS, not as it rises.\n\n"
 "THE PRACTICAL RULE THAT FOLLOWS: WARNING, A NEGATIVE TUBERCULIN IN AN HIV-POSITIVE PERSON DOES "
 "NOT EXCLUDE TB. That is why the positivity threshold for PPD in HIV-positive people is lowered to "
 "5 MILLIMETRES (instead of 10 or 15 in others).\n\n"
 "'BELOW CD4 200 THE PULMONARY INVOLVEMENT USUALLY RESEMBLES PRIMARY TB' — TRUE. Without adequate "
 "cellular immunity the body cannot build a containing granuloma, so the picture resembles childhood "
 "primary TB.\n\n"
 "'BELOW CD4 200 THE PULMONARY INVOLVEMENT IS USUALLY NON-CAVITARY INFILTRATION' — TRUE, and the "
 "reason is elegant: WARNING, A CAVITY IS THE PRODUCT OF AN INTENSE IMMUNE RESPONSE, NOT OF THE "
 "BACTERIUM. Caseous necrosis and tissue destruction come from the IMMUNE ATTACK. With no immunity "
 "there is NO CAVITY — and that also explains the negative smear.",
 ["درست است — در CD4 بالای ۲۰۰ ایمنی حفظ شده کاویته می‌سازد و بار باکتریایی خلط بالا می‌رود.",
  "پاسخ صحیح (جمله‌ی نادرست) — توبرکولین آزمون ایمنی سلولی است، پس در CD4 بالا مثبت‌تر است نه منفی‌تر.",
  "درست است — بدون ایمنی سلولی کافی، گرانولوم محدودکننده ساخته نمی‌شود و تصویر شبیه سل اولیه می‌شود.",
  "درست است — کاویته محصول پاسخ ایمنی شدید است، پس در CD4 پایین انفیلتراسیون بدون کاویته دیده می‌شود."],
 ["True — above CD4 200 preserved immunity forms cavities and raises the sputum bacterial load.",
  "Correct (the false statement) — tuberculin tests cellular immunity, so it is MORE positive at a high CD4, not less.",
  "True — without adequate cellular immunity no containing granuloma forms and the picture resembles primary TB.",
  "True — a cavity is the product of an intense immune response, so at low CD4 the infiltrate is non-cavitary."],
 "**کاویته و اسمیر مثبت و توبرکولین مثبت، همگی محصول ایمنی‌اند — نه محصول باکتری.**",
 "Cavitation, a positive smear and a positive tuberculin are all products of immunity, not of the bacterium.",
 [OIG, H202])


# =========================================================== book:709
add("book:709", "case", "medium",
 "CD4 برابر ۵۵۰ + خلط **آجری** + انفیلتراسیون **لوبار** = پنومونی پنوموکوکی معمولی. **مثل هر بیمار دیگری درمان کنید.**",
 "CD4 550 with RUSTY sputum and LOBAR consolidation is ordinary pneumococcal pneumonia: TREAT IT AS IN ANY OTHER PATIENT.",
 OI_FA + [
  "**این سؤال قرینه‌ی همه‌ی سؤال‌های عفونت فرصت‌طلب است و پیام مخالفی دارد.**",
  "⚠️ **CD4 برابر ۵۵۰ یعنی این بیمار عملاً ایمنی حفظ‌شده دارد.**",
  "**در آن ارتفاع از نردبان، هیچ عفونت فرصت‌طلب کلاسیکی محتمل نیست.**",
  "**و تابلوی بالینی هم کاملاً تیپیک است: شروع حاد سه‌روزه، خلط آجری، انفیلتراسیون لوبار.**",
  "**خلط آجری‌رنگ تقریباً امضای استرپتوکوک پنومونیه است.**",
  "⚠️ **و نکته‌ی اصلی: وجود HIV نباید باعث شود درمان استاندارد را تغییر دهید.**",
  "**سوگیری تشخیصی خطرناکی وجود دارد که هر علامتی را به تشخیص برجسته‌ی بیمار نسبت می‌دهد.**",
  "**بیمار HIV مثبت هم می‌تواند بیماری‌های معمولی بگیرد — و بیشتر اوقات همین‌طور است.**",
  "**بیمار از دو سال پیش تحت نظر است، پس ART احتمالاً از قبل شروع شده و CD4 خوبش گواه آن است.**",
  "**پس شروع دوباره‌ی ART در اورژانس نه لازم است و نه منطقی.**",
 ],
 OI_EN + [
  "This question is the mirror of every opportunistic-infection item and carries the opposite message.",
  "WARNING: A CD4 OF 550 MEANS THIS PATIENT EFFECTIVELY HAS PRESERVED IMMUNITY.",
  "At that height on the ladder, no classic opportunistic infection is likely.",
  "And the clinical picture is entirely typical: acute three-day onset, rusty sputum, lobar consolidation.",
  "Rusty-coloured sputum is almost the signature of Streptococcus pneumoniae.",
  "WARNING, AND THE CENTRAL POINT: the presence of HIV must not make you change standard treatment.",
  "There is a dangerous diagnostic bias that attributes every symptom to the patient's prominent diagnosis.",
  "An HIV-positive patient can also catch ordinary diseases — and most of the time that is what happens.",
  "This patient has been followed for two years, so ART has probably long been started, as his good CD4 attests.",
  "So restarting ART in the emergency department is neither necessary nor logical.",
 ],
 "**آقای ۲۶ ساله HIV مثبت** که **از ۲ سال پیش تحت نظر** است، با **تب، سرفه و خلط آجری "
 "از ۳ روز قبل**، **به‌شدت بدحال**، **دمای ۳۹٫۵ درجه**، **انفیلتراسیون لوبار در قاعده‌ی "
 "ریه‌ی راست**، و **CD4 برابر ۵۵۰** (ده روز قبل).\n\n"
 "⚠️ **پاسخ: درمان پنومونی بیمار بدون توجه به وضعیت HIV او.**\n\n"
 "**و این سؤال قرینه‌ی همه‌ی سؤال‌های قبلی است — پیام کاملاً مخالفی دارد و به همین دلیل "
 "ارزشمند است.**\n\n"
 "**بیایید سرنخ‌ها را بخوانیم:**\n\n"
 "**۱) CD4 برابر ۵۵۰** — ⚠️ **این عدد کل سؤال را تعیین می‌کند.** نردبان CD4 را به یاد "
 "بیاورید: **بالای ۵۰۰ یعنی عملاً مثل فرد سالم.** در این ارتفاع، **PCP** (زیر ۲۰۰)، "
 "**توکسوپلاسما** (زیر ۱۰۰) و **MAC** (زیر ۵۰) هیچ‌کدام محتمل نیستند.\n\n"
 "**۲) شروع حاد سه‌روزه** — عفونت‌های فرصت‌طلب **تدریجی** و طی هفته‌ها می‌آیند؛ پنومونی "
 "باکتریال طی **روزها**.\n\n"
 "**۳) خلط آجری‌رنگ** — تقریباً **امضای استرپتوکوک پنومونیه**.\n\n"
 "**۴) انفیلتراسیون لوبار** — الگوی **کلاسیک پنومونی باکتریال**؛ PCP الگوی **بینابینی "
 "دوطرفه** می‌دهد یا گرافی نرمال.\n\n"
 "**همه‌ی سرنخ‌ها یک چیز می‌گویند: این یک پنومونی پنوموکوکی معمولی است.**\n\n"
 "⚠️ **و حالا پیام اصلی این سؤال، که یک درس بالینی عمیق است:**\n\n"
 "> **وجود HIV نباید باعث شود درمان استاندارد یک بیماری معمولی را تغییر دهید.**\n\n"
 "**سوگیری تشخیصی خطرناکی وجود دارد که در آن پزشک هر علامتی را به «تشخیص برجسته‌ی» "
 "بیمار نسبت می‌دهد.** بیمار HIV مثبت با سرفه ← «حتماً PCP است». بیمار دیابتی با درد "
 "شکم ← «حتماً کتواسیدوز است». ⚠️ **این سوگیری بیماران را می‌کشد**، چون تشخیص ساده و "
 "درمان‌پذیر را از دست می‌دهد.\n\n"
 "**بیمار HIV مثبت هم می‌تواند آپاندیسیت بگیرد، هم سنگ کلیه، هم پنومونی پنوموکوکی — و "
 "در واقع بیشتر اوقات همین‌طور است.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**«کشت و اسمیر خلط + کوتریموکسازول خوراکی»** — کوتریموکسازول یعنی **درمان PCP**، که "
 "با CD4 برابر ۵۵۰ **بی‌معنی** است. ضمناً بیمار **به‌شدت بدحال** است و درمان **خوراکی** "
 "برای پنومونی شدید کافی نیست.\n\n"
 "**«درمان پنومونی + شروع هم‌زمان ART»** — ⚠️ ظریف‌ترین گزینه. **درمان پنومونی درست "
 "است**، ولی «شروع ART» فرض می‌کند بیمار ART نمی‌گیرد. **این بیمار از دو سال پیش تحت "
 "نظر است و CD4 برابر ۵۵۰ دارد** — این CD4 خوب **خودش گواه است که ART از قبل شروع شده "
 "و مؤثر است**. پس «شروع» ART بی‌معنی است.\n\n"
 "**«اسمیر و کشت خلط + شروع ART»** — همان اشکال، به‌علاوه‌ی اینکه **درمان آنتی‌بیوتیکی "
 "پنومونی را اصلاً ذکر نکرده** — در بیماری که به‌شدت بدحال است.",
 "A 26-YEAR-OLD HIV-POSITIVE MAN FOLLOWED FOR TWO YEARS, with FEVER, COUGH AND RUSTY SPUTUM FOR "
 "THREE DAYS, SEVERELY UNWELL, TEMPERATURE 39.5 C, LOBAR CONSOLIDATION AT THE RIGHT LUNG BASE, and "
 "a CD4 OF 550 (ten days ago).\n\n"
 "WARNING, THE ANSWER: treat his pneumonia without regard to his HIV status.\n\n"
 "AND THIS QUESTION IS THE MIRROR OF ALL THE PREVIOUS ONES — it carries the opposite message, and "
 "that is what makes it valuable.\n\n"
 "READ THE CLUES:\n\n"
 "1) CD4 = 550 — WARNING, THIS NUMBER DECIDES THE WHOLE QUESTION. Recall the CD4 ladder: ABOVE 500 "
 "MEANS EFFECTIVELY LIKE A HEALTHY PERSON. At that height, PCP (below 200), toxoplasma (below 100) "
 "and MAC (below 50) are all unlikely.\n\n"
 "2) AN ACUTE THREE-DAY ONSET — opportunistic infections come GRADUALLY over weeks; bacterial "
 "pneumonia over DAYS.\n\n"
 "3) RUSTY SPUTUM — almost the SIGNATURE of Streptococcus pneumoniae.\n\n"
 "4) LOBAR CONSOLIDATION — the CLASSIC bacterial pattern; PCP gives BILATERAL INTERSTITIAL change "
 "or a normal film.\n\n"
 "ALL THE CLUES SAY ONE THING: THIS IS ORDINARY PNEUMOCOCCAL PNEUMONIA.\n\n"
 "WARNING, AND NOW THE CENTRAL MESSAGE OF THIS QUESTION, which is a deep clinical lesson:\n\n"
 "> THE PRESENCE OF HIV MUST NOT MAKE YOU CHANGE THE STANDARD TREATMENT OF AN ORDINARY DISEASE.\n\n"
 "THERE IS A DANGEROUS DIAGNOSTIC BIAS in which a clinician attributes every symptom to the "
 "patient's 'prominent diagnosis'. An HIV-positive patient with a cough: 'it must be PCP'. A "
 "diabetic with abdominal pain: 'it must be ketoacidosis'. WARNING, THAT BIAS KILLS PATIENTS, "
 "because it misses the simple, treatable diagnosis.\n\n"
 "AN HIV-POSITIVE PATIENT CAN ALSO GET APPENDICITIS, RENAL COLIC AND PNEUMOCOCCAL PNEUMONIA — and "
 "in fact most of the time that is exactly what happens.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "'SPUTUM CULTURE AND SMEAR PLUS ORAL CO-TRIMOXAZOLE' — co-trimoxazole means TREATING PCP, which at "
 "a CD4 of 550 is MEANINGLESS. And the patient is SEVERELY UNWELL, so ORAL therapy is inadequate for "
 "severe pneumonia.\n\n"
 "'TREAT THE PNEUMONIA AND START ART SIMULTANEOUSLY' — WARNING, the subtlest option. TREATING THE "
 "PNEUMONIA IS RIGHT, but 'starting ART' assumes the patient is not on it. THIS PATIENT HAS BEEN "
 "FOLLOWED FOR TWO YEARS AND HAS A CD4 OF 550 — that good CD4 IS ITSELF EVIDENCE THAT ART WAS "
 "STARTED LONG AGO AND IS WORKING. So 'starting' ART is meaningless.\n\n"
 "'SPUTUM SMEAR AND CULTURE PLUS STARTING ART' — the same flaw, plus it DOES NOT MENTION ANTIBIOTIC "
 "TREATMENT AT ALL — in a patient who is severely unwell.",
 ["کوتریموکسازول یعنی درمان PCP، که با CD4 برابر ۵۵۰ بی‌معنی است؛ ضمناً درمان خوراکی برای بیمار بدحال کافی نیست.",
  "درمان پنومونی درست است، ولی «شروع ART» فرض می‌کند بیمار آن را نمی‌گیرد — CD4 برابر ۵۵۰ خلاف آن را می‌گوید.",
  "همان اشکال، به‌علاوه‌ی اینکه درمان آنتی‌بیوتیکی پنومونی را در بیمار بدحال اصلاً ذکر نکرده است.",
  "پاسخ صحیح — CD4 برابر ۵۵۰، خلط آجری و انفیلتراسیون لوبار یعنی پنومونی معمولی؛ مثل هر بیمار دیگری درمان شود."],
 ["Co-trimoxazole means treating PCP, which at a CD4 of 550 is meaningless; and oral therapy is inadequate for a severely unwell patient.",
  "Treating the pneumonia is right, but 'starting ART' assumes he is not on it — a CD4 of 550 says otherwise.",
  "The same flaw, plus it does not mention antibiotic treatment at all in a severely unwell patient.",
  "Correct — CD4 550, rusty sputum and lobar consolidation mean ordinary pneumonia; treat it as in any other patient."],
 "**بیمار HIV مثبت هم بیماری معمولی می‌گیرد — و بیشتر اوقات همین‌طور است.**",
 "An HIV-positive patient also catches ordinary diseases — and most of the time that is what happens.",
 [OIG, H202])


# =========================================================== book:645
add("book:645", "case", "hard",
 "MMR واکسن **زنده** است و در CD4 برابر ۹۹ (زیر ۱۵٪ در شیرخوار) **کنتراندیکه** است.",
 "MMR is a LIVE vaccine and at a CD4 of 99 (below 15 per cent in an infant) it is CONTRAINDICATED.",
 OI_FA + [
  "**واکسن‌های زنده در نقص ایمنی سلولی می‌توانند خودشان بیماری بسازند.**",
  "⚠️ **MMR یک واکسن ویروس زنده‌ی ضعیف‌شده است — این نقطه‌ی شروع تصمیم است.**",
  "**در فرد با ایمنی سالم، ویروس ضعیف‌شده کمی تکثیر می‌کند و ایمنی می‌سازد و مهار می‌شود.**",
  "**در نقص ایمنی سلولی، همان ویروس می‌تواند مهار نشود و بیماری منتشر بدهد.**",
  "⚠️ **و در کودکان، آستانه با درصد سنجیده می‌شود نه با عدد مطلق.**",
  "**چون شمارش مطلق لنفوسیت در شیرخواران به‌طور طبیعی بسیار بالاتر از بالغان است.**",
  "**آستانه‌ی ACIP برای MMR در کودک HIV مثبت: درصد CD4 برابر ۱۵ یا بیشتر.**",
  "**در شیرخوار ۱۵ ماهه، CD4 برابر ۹۹ بسیار زیر آن آستانه است — یعنی سرکوب شدید.**",
  "⚠️ **پس MMR کنتراندیکه است، نه صرفاً به تأخیر افتاده.**",
  "**و راه محافظت این کودک، ایمن‌سازی اطرافیان اوست: واکسیناسیون خانواده و مراقبان.**",
  "**MMR در فرد سالم به دیگران منتقل نمی‌شود، پس واکسیناسیون خانواده کاملاً ایمن است.**",
  "**و اگر تماس با سرخک رخ دهد، ایمونوگلوبولین تجویز می‌شود، نه واکسن.**",
 ],
 OI_EN + [
  "Live vaccines in cellular immunodeficiency can themselves cause disease.",
  "WARNING: MMR IS A LIVE ATTENUATED VIRUS VACCINE — that is the starting point of the decision.",
  "In someone with intact immunity the attenuated virus replicates a little, induces immunity and is contained.",
  "In cellular immunodeficiency that same virus may go uncontained and cause disseminated disease.",
  "WARNING, AND IN CHILDREN THE THRESHOLD IS MEASURED AS A PERCENTAGE, not as an absolute count.",
  "Because the absolute lymphocyte count in infants is naturally far higher than in adults.",
  "The ACIP threshold for MMR in an HIV-positive child: a CD4 percentage of 15 or above.",
  "In a 15-month-old, a CD4 of 99 is far below that threshold — that is severe suppression.",
  "WARNING, SO MMR IS CONTRAINDICATED, not merely postponed.",
  "And the way to protect this child is to immunise those around him: vaccinate the family and carers.",
  "MMR is not transmitted from a healthy vaccinated person, so vaccinating the family is entirely safe.",
  "And if measles exposure occurs, immunoglobulin is given, not the vaccine.",
 ],
 "**شیرخوار ۱۵ ماهه HIV مثبت** با **CD4 برابر ۹۹**، ارجاع شده برای تصمیم درباره‌ی "
 "**واکسن MMR**.\n\n"
 "⚠️ **پاسخ: واکسن MMR در این شیرخوار کنتراندیکه است.**\n\n"
 "**و برای رسیدن به این پاسخ باید دو چیز را کنار هم بگذارید.**\n\n"
 "**اول: MMR یک واکسن ویروس زنده‌ی ضعیف‌شده است.**\n\n"
 "**در فرد با ایمنی سالم، ویروس ضعیف‌شده کمی تکثیر می‌کند، پاسخ ایمنی می‌سازد، و بعد "
 "توسط همان ایمنی مهار می‌شود.** ⚠️ **ولی در نقص ایمنی سلولی، همان ویروس ممکن است "
 "مهار نشود و بیماری منتشر بدهد** — یعنی واکسن، خودش عامل بیماری شود.\n\n"
 "**دوم — و این نکته‌ی ظریفی است که بسیاری از دست می‌دهند: در کودکان، آستانه با درصد "
 "سنجیده می‌شود، نه با عدد مطلق.**\n\n"
 "**چرا؟ چون شمارش مطلق لنفوسیت در شیرخواران به‌طور طبیعی بسیار بالاتر از بالغان است.** "
 "یک شیرخوار سالم ممکن است CD4 بالای ۱۵۰۰ داشته باشد. **پس عدد مطلق ۲۰۰ که در بالغان "
 "معنادار است، در شیرخوار معنای متفاوتی دارد.**\n\n"
 "**آستانه‌ی ACIP برای MMR در کودک HIV مثبت: درصد CD4 برابر ۱۵ یا بیشتر.**\n\n"
 "**در شیرخوار ۱۵ ماهه، CD4 برابر ۹۹ بسیار زیر آن آستانه است — یعنی سرکوب ایمنی "
 "شدید.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**«بلافاصله تجویز شود»** — ⚠️ **خطرناک‌ترین گزینه.** در این سطح سرکوب، واکسن زنده "
 "می‌تواند بیماری واکسینال بدهد.\n\n"
 "**«تا ۲۴ ماهگی به تأخیر انداخته شود»** — ⚠️ **این ظریف‌ترین گزینه است و باید دلیل رد "
 "شدنش را دقیق فهمید.** مشکل این نیست که کودک **کوچک** است — مشکل این است که **ایمنی‌اش "
 "سرکوب شده**. **گذشت زمان به‌خودی‌خود CD4 را بالا نمی‌برد.** آنچه CD4 را بالا می‌برد "
 "**درمان ضدرتروویروسی** است. پس «تأخیر تا ۲۴ ماهگی» یک **تأخیر بی‌هدف** است؛ معیار "
 "درست **درصد CD4** است، نه **سن**.\n\n"
 "**«بر اساس سرولوژی تصمیم‌گیری شود»** — سرولوژی می‌گوید کودک **ایمن است یا نه**، ولی "
 "سؤال این نیست. سؤال این است که **آیا تجویز واکسن زنده امن است** — و آن را **وضعیت "
 "ایمنی** تعیین می‌کند، نه تیتر آنتی‌بادی.\n\n"
 "⚠️ **و مهم‌ترین نکته‌ی عملی که سؤال نپرسیده: پس این کودک چطور محافظت می‌شود؟**\n\n"
 "**با ایمن‌سازی اطرافیانش** — واکسیناسیون کامل **خانواده، خواهر و برادرها و "
 "مراقبان**. این «ایمنی حلقوی» نام دارد. ⚠️ **و نکته‌ی مهم: MMR در فرد سالم به دیگران "
 "منتقل نمی‌شود، پس واکسیناسیون خانواده کاملاً ایمن است** و هیچ خطری برای کودک "
 "ندارد.\n\n"
 "**و اگر تماس با سرخک رخ دهد؟ ایمونوگلوبولین تجویز می‌شود، نه واکسن.**\n\n"
 "**و در آینده:** اگر با ART درصد CD4 به بالای ۱۵ برسد و آنجا بماند، **آنگاه** MMR "
 "قابل تجویز است.",
 "A 15-MONTH-OLD HIV-POSITIVE INFANT with a CD4 OF 99, referred for a decision about the MMR "
 "VACCINE.\n\n"
 "WARNING, THE ANSWER: MMR is CONTRAINDICATED in this infant.\n\n"
 "AND TO REACH IT YOU MUST PUT TWO THINGS TOGETHER.\n\n"
 "FIRST: MMR IS A LIVE ATTENUATED VIRUS VACCINE.\n\n"
 "IN SOMEONE WITH INTACT IMMUNITY the attenuated virus replicates a little, induces an immune "
 "response, and is then contained by that same immunity. WARNING, BUT IN CELLULAR IMMUNODEFICIENCY "
 "THAT SAME VIRUS MAY GO UNCONTAINED AND CAUSE DISSEMINATED DISEASE — the vaccine itself becoming "
 "the pathogen.\n\n"
 "SECOND — AND THIS IS THE SUBTLETY MANY MISS: IN CHILDREN THE THRESHOLD IS A PERCENTAGE, NOT AN "
 "ABSOLUTE COUNT.\n\n"
 "WHY? BECAUSE THE ABSOLUTE LYMPHOCYTE COUNT IN INFANTS IS NATURALLY FAR HIGHER THAN IN ADULTS. A "
 "healthy infant may have a CD4 above 1500. So the absolute figure of 200, meaningful in adults, "
 "means something different in an infant.\n\n"
 "THE ACIP THRESHOLD FOR MMR IN AN HIV-POSITIVE CHILD: A CD4 PERCENTAGE OF 15 OR ABOVE.\n\n"
 "In a 15-month-old, a CD4 of 99 is far below that threshold — severe immunosuppression.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "'GIVE IT IMMEDIATELY' — WARNING, THE MOST DANGEROUS OPTION. At this level of suppression a live "
 "vaccine can cause vaccine-strain disease.\n\n"
 "'POSTPONE UNTIL 24 MONTHS' — WARNING, THE SUBTLEST OPTION, and you must understand exactly why it "
 "fails. The problem is not that the child is YOUNG — the problem is that his IMMUNITY IS "
 "SUPPRESSED. THE PASSAGE OF TIME DOES NOT BY ITSELF RAISE THE CD4. What raises it is ANTIRETROVIRAL "
 "THERAPY. So 'postpone to 24 months' is a PURPOSELESS DELAY; the right criterion is the CD4 "
 "PERCENTAGE, not AGE.\n\n"
 "'DECIDE BASED ON SEROLOGY' — serology tells you whether the child IS IMMUNE, but that is not the "
 "question. The question is WHETHER GIVING A LIVE VACCINE IS SAFE — and that is decided by IMMUNE "
 "STATUS, not by an antibody titre.\n\n"
 "WARNING, AND THE MOST IMPORTANT PRACTICAL POINT THE QUESTION DOES NOT ASK: SO HOW IS THIS CHILD "
 "PROTECTED?\n\n"
 "BY IMMUNISING THOSE AROUND HIM — full vaccination of the FAMILY, SIBLINGS AND CARERS. This is "
 "called RING IMMUNITY. WARNING, AND THE KEY POINT: MMR IS NOT TRANSMITTED FROM A HEALTHY VACCINATED "
 "PERSON, so vaccinating the family is entirely safe and poses no risk to the child.\n\n"
 "AND IF MEASLES EXPOSURE OCCURS? IMMUNOGLOBULIN is given, not the vaccine.\n\n"
 "AND IN FUTURE: if ART raises the CD4 percentage above 15 and holds it there, THEN MMR can be "
 "given.",
 ["خطرناک‌ترین گزینه — در این سطح سرکوب ایمنی، واکسن زنده می‌تواند بیماری واکسینال بدهد.",
  "تأخیر بی‌هدف — مشکل سن نیست، سرکوب ایمنی است؛ گذشت زمان به‌خودی‌خود CD4 را بالا نمی‌برد.",
  "سرولوژی می‌گوید کودک ایمن است یا نه، ولی ایمن بودنِ تجویز واکسن زنده را وضعیت ایمنی تعیین می‌کند.",
  "پاسخ صحیح — MMR واکسن زنده است و در درصد CD4 زیر ۱۵ در کودک کنتراندیکه است."],
 ["The most dangerous option — at this level of suppression a live vaccine can cause vaccine-strain disease.",
  "A purposeless delay — the problem is not age but immunosuppression; time alone does not raise the CD4.",
  "Serology says whether the child is immune, but the safety of a live vaccine is decided by immune status.",
  "Correct — MMR is a live vaccine and is contraindicated at a CD4 percentage below 15 in a child."],
 "**در کودکان آستانه درصد است نه عدد مطلق — و MMR واکسن زنده است.**",
 "In children the threshold is a percentage, not an absolute count — and MMR is a live vaccine.",
 [ACIPMMR, OIG])


# ============================================================== HEPATITIS
add("book:846", "case", "medium",
 "در **HBsAg مثبت**، تست anti-HBc چیزی اضافه نمی‌کند — از قبل می‌دانیم عفونت هست.",
 "In an HBsAg-POSITIVE patient, anti-HBc adds nothing — we already know the infection is there.",
 HEP_FA + [
  "**این سؤال می‌پرسد کدام تست به تعیین وضعیت کمک نمی‌کند، و سه‌تای دیگر کمک می‌کنند.**",
  "⚠️ **نکته‌ی محوری: HBsAg از قبل مثبت است، پس سؤال «آیا عفونت هست؟» جواب داده شده.**",
  "**و anti-HBc دقیقاً همان سؤال را دوباره می‌پرسد: آیا تماس با ویروس رخ داده؟**",
  "**در فرد HBsAg مثبت، پاسخ آن بدیهی است و تصمیمی را عوض نمی‌کند.**",
  "**در مقابل، HBeAg سؤال تازه‌ای می‌پرسد: چقدر تکثیر و چقدر خطر انتقال به نوزاد؟**",
  "⚠️ **و در بارداری این سؤال حیاتی است، چون HBeAg مثبت خطر انتقال را به بالای ۹۰ درصد می‌برد.**",
  "**ALT سؤال دیگری می‌پرسد: آیا التهاب فعال کبدی وجود دارد؟**",
  "**و INR مهم‌ترین را می‌پرسد: عملکرد سنتزی کبد سالم است؟**",
  "**سه سؤال متفاوت، سه تست متفاوت — و یکی که سؤالش از قبل جواب داده شده.**",
 ],
 HEP_EN + [
  "The stem asks which test does NOT help establish her status, and the other three do.",
  "WARNING, THE PIVOT: HBsAg is already positive, so the question 'is there infection?' has been answered.",
  "And anti-HBc asks precisely that same question again: has exposure to the virus occurred?",
  "In an HBsAg-positive person the answer is self-evident and changes no decision.",
  "By contrast HBeAg asks a NEW question: how much replication, and how great the risk to the infant?",
  "WARNING, AND IN PREGNANCY THAT QUESTION IS VITAL, because a positive HBeAg raises transmission above 90 per cent.",
  "ALT asks another question: is there active hepatic inflammation?",
  "And INR asks the most important one: is the liver's synthetic function intact?",
  "Three different questions, three different tests — and one whose question is already answered.",
 ],
 "**خانم جوان در سه‌ماهه‌ی دوم بارداری** با **HBsAg مثبت** در غربالگری، **بدون علامت** و "
 "**بدون سابقه‌ی زردی**. سؤال: کدام تست به تعیین وضعیت او **کمک نمی‌کند**؟\n\n"
 "⚠️ **پاسخ: anti-HBc. و منطقش زیباست.**\n\n"
 "**قاعده‌ی طلایی برای این نوع سؤال: هر تست را با سؤالی که پاسخ می‌دهد جایگزین کنید، "
 "و ببینید آن سؤال از قبل جواب داده شده یا نه.**\n\n"
 "**anti-HBc چه سؤالی می‌پرسد؟** «آیا این فرد **تماس با ویروس هپاتیت B** داشته است؟»\n\n"
 "⚠️ **ولی HBsAg از قبل مثبت است! یعنی می‌دانیم ویروس همین الان در بدنش هست. پس "
 "پرسیدن «آیا تماس داشته؟» یک سؤال بی‌معناست — پاسخش بدیهی و از پیش معلوم است.**\n\n"
 "**anti-HBc کجا واقعاً ارزشمند است؟** آنجا که باید **واکسینه** را از **بهبودیافته** "
 "جدا کنید (چون واکسن anti-HBc نمی‌سازد)، یا در **پنجره‌ی سرولوژیک** که HBsAg محو شده "
 "و anti-HBs هنوز نیامده. **هیچ‌کدام از این دو وضعیت اینجا برقرار نیست.**\n\n"
 "**و حالا ببینیم سه تست دیگر چه سؤال‌های تازه‌ای می‌پرسند:**\n\n"
 "**HBeAg** ✅ می‌پرسد: **«چقدر تکثیر و چقدر سرایت؟»** ⚠️ **و در بارداری این سؤال حیاتی "
 "است:** اگر HBeAg مثبت باشد، خطر انتقال به نوزاد به **بالای ۹۰ درصد** می‌رسد؛ اگر منفی "
 "باشد، حدود **۱۰ تا ۲۰ درصد**. **این عدد مستقیماً تصمیم درمانی را عوض می‌کند** — "
 "مادران با بار ویروسی بالا در سه‌ماهه‌ی سوم **تنوفوویر** می‌گیرند.\n\n"
 "**ALT** ✅ می‌پرسد: **«آیا التهاب فعال کبدی وجود دارد؟»** تفکیک **ناقل غیرفعال** از "
 "**هپاتیت مزمن فعال**.\n\n"
 "**INR** ✅ می‌پرسد: **«عملکرد سنتزی کبد سالم است؟»** ⚠️ **و این مهم‌ترین سؤال است**، "
 "چون **شدت بیماری کبدی با آنزیم سنجیده نمی‌شود، با عملکرد سنتزی سنجیده می‌شود.** ALT "
 "فقط می‌گوید سلول کبدی در حال مرگ است؛ **INR می‌گوید چقدر کبد باقی مانده.**\n\n"
 "**و نکته‌ی عملی که سؤال نپرسیده:** فارغ از همه‌ی این تست‌ها، **نوزاد این مادر باید "
 "ظرف ۱۲ ساعت پس از تولد هم واکسن هپاتیت B و هم HBIG دریافت کند** — و این کار خطر "
 "انتقال را حدود **۹۵ درصد** کاهش می‌دهد.",
 "A YOUNG WOMAN IN THE SECOND TRIMESTER with a POSITIVE HBsAg on screening, ASYMPTOMATIC and with "
 "NO HISTORY OF JAUNDICE. Which test does NOT help establish her status?\n\n"
 "WARNING, THE ANSWER: anti-HBc. And the logic is elegant.\n\n"
 "THE GOLDEN RULE FOR THIS KIND OF QUESTION: replace each test with the QUESTION IT ANSWERS, and "
 "see whether that question has already been answered.\n\n"
 "WHAT QUESTION DOES anti-HBc ASK? 'Has this person BEEN EXPOSED to hepatitis B?'\n\n"
 "WARNING, BUT HBsAg IS ALREADY POSITIVE! We know the virus is in her body right now. So asking "
 "'has she been exposed?' is a meaningless question — the answer is self-evident.\n\n"
 "WHERE IS anti-HBc GENUINELY VALUABLE? Where you must separate the VACCINATED from the RECOVERED "
 "(because a vaccine never makes anti-HBc), or in the SEROLOGICAL WINDOW where HBsAg has cleared and "
 "anti-HBs has not yet appeared. NEITHER SITUATION APPLIES HERE.\n\n"
 "NOW SEE WHAT NEW QUESTIONS THE OTHER THREE ASK:\n\n"
 "HBeAg asks: 'HOW MUCH REPLICATION AND HOW MUCH INFECTIVITY?' WARNING, AND IN PREGNANCY THAT "
 "QUESTION IS VITAL: with a positive HBeAg the risk of transmission to the infant rises ABOVE 90 PER "
 "CENT; with a negative one it is about 10 TO 20 PER CENT. THAT FIGURE DIRECTLY CHANGES TREATMENT — "
 "mothers with a high viral load receive TENOFOVIR in the third trimester.\n\n"
 "ALT asks: 'IS THERE ACTIVE HEPATIC INFLAMMATION?' — separating an INACTIVE CARRIER from ACTIVE "
 "CHRONIC HEPATITIS.\n\n"
 "INR asks: 'IS THE LIVER'S SYNTHETIC FUNCTION INTACT?' WARNING, AND THAT IS THE MOST IMPORTANT "
 "QUESTION, because SEVERITY OF LIVER DISEASE IS NOT MEASURED BY THE ENZYME BUT BY SYNTHETIC "
 "FUNCTION. ALT says only that hepatocytes are dying; INR SAYS HOW MUCH LIVER REMAINS.\n\n"
 "AND A PRACTICAL POINT THE QUESTION DOES NOT ASK: whatever these tests show, THIS MOTHER'S INFANT "
 "MUST RECEIVE BOTH HEPATITIS B VACCINE AND HBIG WITHIN 12 HOURS OF BIRTH — which reduces "
 "transmission by about 95 PER CENT.",
 ["HBeAg سؤال تازه‌ای می‌پرسد: میزان تکثیر و خطر انتقال به نوزاد، که تصمیم درمانی را عوض می‌کند.",
  "پاسخ صحیح — در فرد HBsAg مثبت، anti-HBc سؤالی می‌پرسد که از قبل جواب داده شده است.",
  "ALT می‌پرسد آیا التهاب فعال کبدی وجود دارد و ناقل غیرفعال را از هپاتیت فعال جدا می‌کند.",
  "INR مهم‌ترین را می‌پرسد: عملکرد سنتزی کبد، که معیار واقعی شدت بیماری است."],
 ["HBeAg asks a new question: replication and the risk to the infant, which changes treatment.",
  "Correct — in an HBsAg-positive person, anti-HBc asks a question that is already answered.",
  "ALT asks whether there is active hepatic inflammation, separating inactive carriage from active hepatitis.",
  "INR asks the most important question: synthetic function, the true measure of severity."],
 "**هر تست را با سؤالش جایگزین کنید — و ببینید آن سؤال از قبل جواب داده شده یا نه.**",
 "Replace each test with the question it asks, and see whether that question is already answered.",
 [AASLD, ACIP])

add("book:847", "case", "easy",
 "همان اصل با گزینه‌های متفاوت: **anti-HBc** در فرد HBsAg مثبت، سؤال از پیش پاسخ‌داده را تکرار می‌کند.",
 "The same principle with different options: in an HBsAg-positive person, anti-HBc repeats an already-answered question.",
 HEP_FA + [
  "**این سؤال تقریباً همان سؤال قبلی است، ولی HBV DNA را جایگزین HBeAg کرده است.**",
  "⚠️ **و همین جایگزینی، یک ارتقای مفهومی مهم را نشان می‌دهد.**",
  "**HBeAg یک پاسخ کیفی می‌دهد: تکثیر هست یا نیست.**",
  "**HBV DNA همان را کمّی می‌گوید: چند نسخه در هر میلی‌لیتر.**",
  "**و امروز HBV DNA معیار اصلی تصمیم درمان است، نه HBeAg.**",
  "⚠️ **مهم‌تر اینکه گونه‌ای از ویروس وجود دارد که HBeAg منفی است ولی فعالانه تکثیر می‌کند.**",
  "**این «هپاتیت B با HBeAg منفی» است، ناشی از جهش در ناحیه‌ی پره‌کور.**",
  "**در آن حالت اتکا به HBeAg تنها، بیمار را کاذباً کم‌خطر نشان می‌دهد.**",
  "**و در بارداری، آستانه‌ی درمان با تنوفوویر بر پایه‌ی همین بار ویروسی تعیین می‌شود.**",
 ],
 HEP_EN + [
  "This is almost the previous question, but it substitutes HBV DNA for HBeAg.",
  "WARNING, AND THAT SUBSTITUTION MARKS AN IMPORTANT CONCEPTUAL UPGRADE.",
  "HBeAg gives a qualitative answer: replication is present or absent.",
  "HBV DNA says the same thing quantitatively: how many copies per millilitre.",
  "And today HBV DNA, not HBeAg, is the main basis of treatment decisions.",
  "WARNING, MORE IMPORTANTLY, A VIRAL VARIANT EXISTS THAT IS HBeAg-NEGATIVE YET REPLICATES ACTIVELY.",
  "This is HBeAg-negative hepatitis B, caused by a precore mutation.",
  "In that case relying on HBeAg alone makes the patient look falsely low-risk.",
  "And in pregnancy the threshold for tenofovir is set by that very viral load.",
 ],
 "**خانم جوان در ماه سوم بارداری** با **HBsAg مثبت**، **بدون سابقه‌ی زردی** و **بدون "
 "علامت**. کدام تست **کمک‌کننده نیست**؟\n\n"
 "⚠️ **پاسخ باز هم anti-HBc — و همان منطق سؤال قبلی: در فرد HBsAg مثبت، این تست سؤالی "
 "را می‌پرسد که از قبل جواب داده شده است.**\n\n"
 "**تکرار این مفهوم در دو سیتینگ مختلف تصادفی نیست: طراحان می‌دانند دانشجو anti-HBc را "
 "به‌عنوان «تست مهم هپاتیت B» حفظ کرده و بدون فکر انتخابش می‌کند.**\n\n"
 "**ولی این سؤال یک تفاوت جالب با قبلی دارد: به‌جای HBeAg، گزینه‌ی HBV DNA را آورده "
 "است — و همین یک ارتقای مفهومی مهم را نشان می‌دهد.**\n\n"
 "**HBeAg** پاسخ **کیفی** می‌دهد: تکثیر **هست یا نیست**.\n\n"
 "**HBV DNA** همان را **کمّی** می‌گوید: **چند نسخه در هر میلی‌لیتر**.\n\n"
 "⚠️ **و امروز HBV DNA معیار اصلی تصمیم درمان است، نه HBeAg. دو دلیل:**\n\n"
 "**دلیل یک — دقت کمّی:** آستانه‌های درمانی امروز با **عدد** تعریف می‌شوند (مثلاً "
 "بالای ۲۰۰۰ یا ۲۰۰۰۰ واحد بین‌المللی در میلی‌لیتر، بسته به بستر)، نه با مثبت و منفی.\n\n"
 "**دلیل دو — و مهم‌تر: هپاتیت B با HBeAg منفی.** ⚠️ **گونه‌ای از ویروس وجود دارد که "
 "به‌دلیل جهش در ناحیه‌ی پره‌کور، HBeAg نمی‌سازد ولی فعالانه تکثیر می‌کند.** در آن "
 "بیمار، HBeAg منفی است ولی **HBV DNA بسیار بالاست** و کبد در حال تخریب. **اتکا به "
 "HBeAg تنها، چنین بیماری را کاذباً کم‌خطر نشان می‌دهد.**\n\n"
 "**و در بارداری این تصمیم کاملاً عملی است:** مادرانی که **بار ویروسی بالایی** دارند، "
 "در **سه‌ماهه‌ی سوم تنوفوویر** می‌گیرند تا خطر انتقال به نوزاد کم شود. **آستانه‌ی این "
 "تصمیم بر پایه‌ی HBV DNA تعیین می‌شود، نه HBeAg.**\n\n"
 "**و دو گزینه‌ی دیگر؟** **INR و ALT** همان دو سؤال قبلی را می‌پرسند: **عملکرد سنتزی** "
 "و **التهاب فعال**. **HBeAg** هم همچنان مفید است، هرچند HBV DNA جامع‌تر است.",
 "A YOUNG WOMAN IN THE THIRD MONTH OF PREGNANCY with a POSITIVE HBsAg, NO HISTORY OF JAUNDICE and "
 "NO SYMPTOMS. Which test is NOT helpful?\n\n"
 "WARNING, THE ANSWER IS AGAIN anti-HBc — and the same logic as the previous question: in an "
 "HBsAg-positive person this test asks something already answered.\n\n"
 "The repetition across two sittings is not accidental: examiners know students memorise anti-HBc as "
 "'an important hepatitis B test' and select it without thinking.\n\n"
 "BUT THIS QUESTION DIFFERS INTERESTINGLY FROM THE LAST: instead of HBeAg it offers HBV DNA — and "
 "that marks an important conceptual upgrade.\n\n"
 "HBeAg gives a QUALITATIVE answer: replication IS or IS NOT present.\n\n"
 "HBV DNA says the same QUANTITATIVELY: HOW MANY COPIES PER MILLILITRE.\n\n"
 "WARNING, AND TODAY HBV DNA, NOT HBeAg, IS THE MAIN BASIS OF TREATMENT DECISIONS. Two reasons:\n\n"
 "REASON ONE — QUANTITATIVE PRECISION: today's treatment thresholds are defined by a NUMBER (say "
 "above 2000 or 20000 IU/mL depending on context), not by positive or negative.\n\n"
 "REASON TWO — AND MORE IMPORTANT: HBeAg-NEGATIVE HEPATITIS B. WARNING, A VIRAL VARIANT EXISTS "
 "WHICH, THROUGH A PRECORE MUTATION, MAKES NO HBeAg YET REPLICATES ACTIVELY. In such a patient HBeAg "
 "is negative but HBV DNA IS VERY HIGH and the liver is being destroyed. RELYING ON HBeAg ALONE "
 "MAKES THAT PATIENT LOOK FALSELY LOW-RISK.\n\n"
 "AND IN PREGNANCY THE DECISION IS entirely practical: mothers with a HIGH VIRAL LOAD receive "
 "TENOFOVIR IN THE THIRD TRIMESTER to reduce transmission. THE THRESHOLD FOR THAT DECISION IS SET BY "
 "HBV DNA, NOT HBeAg.\n\n"
 "AND THE OTHER TWO? INR AND ALT ask the same two questions as before: SYNTHETIC FUNCTION and ACTIVE "
 "INFLAMMATION. HBeAg remains useful too, though HBV DNA is more comprehensive.",
 ["INR و ALT عملکرد سنتزی و التهاب فعال را می‌سنجند و هر دو تصمیم‌ساز هستند.",
  "HBV DNA پاسخ کمّی می‌دهد و امروز معیار اصلی تصمیم درمان است، به‌ویژه در هپاتیت با HBeAg منفی.",
  "پاسخ صحیح — در فرد HBsAg مثبت، anti-HBc سؤالی را می‌پرسد که از قبل جواب داده شده است.",
  "HBeAg میزان تکثیر و سرایت را می‌سنجد و در بارداری خطر انتقال به نوزاد را تخمین می‌زند."],
 ["INR and ALT measure synthetic function and active inflammation, and both drive decisions.",
  "HBV DNA gives a quantitative answer and is today's main basis for treatment, especially in HBeAg-negative disease.",
  "Correct — in an HBsAg-positive person, anti-HBc asks a question that is already answered.",
  "HBeAg measures replication and infectivity and, in pregnancy, estimates the risk to the infant."],
 "**HBeAg منفی، تکثیر را رد نمی‌کند — جهش پره‌کور همین را می‌سازد.**",
 "A negative HBeAg does not exclude replication; the precore mutant is exactly that.",
 [AASLD, ACIP])

add("book:852", "case", "hard",
 "تیتر **زیر ۱۰** = نان‌رسپاندر ← پس از مواجهه **هم HBIG و هم تکرار کامل سری واکسن**.",
 "A titre BELOW 10 means non-responder: after exposure, BOTH HBIG AND a full repeat vaccine series.",
 HEP_FA + [
  "**این سؤال روی یک عدد می‌چرخد، و آن عدد آستانه‌ی محافظت anti-HBs است.**",
  "⚠️ **آستانه ۱۰ mIU/mL است: بالای آن محافظت‌شده، زیر آن نان‌رسپاندر.**",
  "**حدود ۵ تا ۱۰ درصد افراد پس از سه دوز واکسن پاسخ کافی نمی‌دهند.**",
  "**عوامل خطر نان‌رسپاندری: سن بالا، چاقی، سیگار، دیالیز، نقص ایمنی، تزریق در باسن.**",
  "⚠️ **در نان‌رسپاندر پس از مواجهه، هیچ‌کدام از دو مداخله به‌تنهایی کافی نیست.**",
  "**HBIG محافظت فوری ولی گذرا می‌دهد: آنتی‌بادی آماده، با نیمه‌عمر حدود سه هفته.**",
  "**واکسن محافظت پایدار ولی کند می‌دهد: هفته‌ها طول می‌کشد تا آنتی‌بادی ساخته شود.**",
  "**پس هر دو با هم: یکی پل می‌زند تا دیگری برسد.**",
  "⚠️ **و زمان‌بندی حیاتی است: HBIG هرچه زودتر، ترجیحاً ظرف ۲۴ ساعت و حداکثر تا ۷ روز.**",
  "**در این سؤال، واحد چاپی کتاب اشتباه است و درسنامه آن را صریح می‌گوید.**",
 ],
 HEP_EN + [
  "This question turns on one number, and that number is the protective anti-HBs threshold.",
  "WARNING: THE THRESHOLD IS 10 mIU/mL — above it protected, below it a non-responder.",
  "About 5 to 10 per cent of people fail to respond adequately to three doses.",
  "Risk factors for non-response: older age, obesity, smoking, dialysis, immunodeficiency, gluteal injection.",
  "WARNING, IN A NON-RESPONDER AFTER EXPOSURE, NEITHER INTERVENTION ALONE IS ENOUGH.",
  "HBIG gives immediate but transient protection: ready-made antibody with a half-life of about three weeks.",
  "The vaccine gives durable but slow protection: weeks are needed to make antibody.",
  "So both together: one bridges the gap until the other arrives.",
  "WARNING, AND TIMING IS CRITICAL: HBIG as soon as possible, ideally within 24 hours and at most 7 days.",
  "In this question the book's printed unit is wrong, and the lesson says so openly.",
 ],
 "**کارورزی** که **سه نوبت واکسن هپاتیت B** زده و تیتر آنتی‌بادی یک ماه پس از آخرین دوز "
 "**۵** بوده، حالا **نیدل‌استیک از بیمار HBsAg مثبت** داشته است.\n\n"
 "⚠️ **پیش از هر چیز، یک خطای چاپی در کتاب را بدانید: واحد این عدد در متن «واحد "
 "بین‌المللی در هر میلی‌لیتر» (IU/mL) چاپ شده است، ولی anti-HBs همیشه با mIU/mL "
 "(میلی‌واحد بین‌المللی) گزارش می‌شود.**\n\n"
 "**چرا این تفاوت حیاتی است؟** اگر عدد را «۵ IU/mL» بخوانید، یعنی **۵۰۰۰ mIU/mL** — "
 "**پانصد برابر** سطح محافظ — و آنگاه این فرد یک **پاسخ‌دهنده‌ی کاملاً ایمن** است و کل "
 "سؤال وارونه می‌شود. **سؤال فقط با خوانش درست (۵ mIU/mL) معنا می‌دهد**، و کلید چاپی "
 "هم دقیقاً بر همین اساس درست است.\n\n"
 "**حالا به پزشکی برسیم:**\n\n"
 "⚠️ **عدد ۱۰ mIU/mL را حفظ کنید. این آستانه‌ی محافظت anti-HBs است.**\n\n"
 "**بالای ۱۰** → محافظت‌شده. پس از مواجهه **هیچ اقدامی لازم نیست**.\n\n"
 "**زیر ۱۰** → **نان‌رسپاندر**. حدود **۵ تا ۱۰ درصد** افراد پس از سه دوز کامل، پاسخ "
 "کافی نمی‌دهند. (عوامل خطر: **سن بالا، چاقی، سیگار، دیالیز، نقص ایمنی**، و تزریق "
 "اشتباه در **باسن** به‌جای دلتوئید.)\n\n"
 "**این کارورز با تیتر ۵، نان‌رسپاندر است.**\n\n"
 "⚠️ **و حالا مهم‌ترین مفهوم این سؤال: چرا هر دو مداخله لازم است؟**\n\n"
 "**HBIG** = **ایمنی غیرفعال**. آنتی‌بادی **آماده** به بیمار داده می‌شود. **محافظت فوری "
 "ولی گذرا** — نیمه‌عمر حدود **سه هفته**.\n\n"
 "**واکسن** = **ایمنی فعال**. بدن **خودش** آنتی‌بادی می‌سازد. **محافظت پایدار ولی کند** "
 "— **هفته‌ها** طول می‌کشد.\n\n"
 "**پس هر دو با هم: HBIG پل می‌زند تا واکسن برسد.**\n\n"
 "**تشبیه ساده:** HBIG مثل **چتر نجاتی** است که همین حالا باز می‌شود؛ واکسن مثل "
 "**آموزش پرواز** است که ماه‌ها طول می‌کشد ولی برای همیشه می‌ماند. **در سقوط، به هر دو "
 "نیاز دارید.**\n\n"
 "⚠️ **و زمان‌بندی حیاتی است: HBIG را هرچه زودتر، ترجیحاً ظرف ۲۴ ساعت و حداکثر تا "
 "۷ روز.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**«هیچ اقدامی لازم نیست»** — این فقط برای تیتر **بالای ۱۰** درست است.\n\n"
 "**«فقط سه دوز واکسن»** — ⚠️ محافظت پایدار می‌سازد ولی **هفته‌ها طول می‌کشد**، و در آن "
 "فاصله بیمار **بی‌دفاع** است. ضمناً این فرد قبلاً به واکسن **پاسخ نداده**، پس اتکای "
 "صرف به آن پرخطر است.\n\n"
 "**«فقط HBIG»** — محافظت فوری می‌دهد ولی **گذراست**، و این فرد همچنان **نان‌رسپاندر** "
 "می‌ماند و برای مواجهه‌ی بعدی هم بی‌دفاع است.",
 "AN INTERN who has had THREE DOSES OF HEPATITIS B VACCINE, whose antibody titre one month after "
 "the last dose was 5, has now had a NEEDLESTICK FROM AN HBsAg-POSITIVE PATIENT.\n\n"
 "WARNING, FIRST KNOW OF A MISPRINT IN THE BOOK: the unit here is printed as 'international units "
 "per millilitre' (IU/mL), but anti-HBs is always reported in mIU/mL (MILLI-international units).\n\n"
 "WHY DOES THAT MATTER? Read as '5 IU/mL' the value would be 5000 mIU/mL — FIVE HUNDRED TIMES the "
 "protective level — making this person a FULLY PROTECTED RESPONDER and inverting the whole "
 "question. THE QUESTION ONLY MAKES SENSE ON THE CORRECT READING (5 mIU/mL), and the printed key is "
 "right on exactly that basis.\n\n"
 "NOW TO THE MEDICINE:\n\n"
 "WARNING, MEMORISE THE NUMBER 10 mIU/mL. That is the protective anti-HBs threshold.\n\n"
 "ABOVE 10 — protected. After exposure NO ACTION IS NEEDED.\n\n"
 "BELOW 10 — a NON-RESPONDER. About 5 TO 10 PER CENT of people fail to respond adequately to three "
 "full doses. (Risk factors: OLDER AGE, OBESITY, SMOKING, DIALYSIS, IMMUNODEFICIENCY, and injection "
 "wrongly into the BUTTOCK instead of the deltoid.)\n\n"
 "THIS INTERN, WITH A TITRE OF 5, IS A NON-RESPONDER.\n\n"
 "WARNING, AND NOW THE CENTRAL CONCEPT: WHY ARE BOTH INTERVENTIONS NEEDED?\n\n"
 "HBIG = PASSIVE IMMUNITY. Ready-made antibody is given to the patient. IMMEDIATE BUT TRANSIENT "
 "protection — a half-life of about THREE WEEKS.\n\n"
 "VACCINE = ACTIVE IMMUNITY. The body makes its OWN antibody. DURABLE BUT SLOW protection — WEEKS "
 "are needed.\n\n"
 "SO BOTH TOGETHER: HBIG BRIDGES THE GAP UNTIL THE VACCINE ARRIVES.\n\n"
 "A SIMPLE ANALOGY: HBIG is a PARACHUTE that opens right now; the vaccine is FLYING LESSONS that "
 "take months but last for life. IN A FALL YOU NEED BOTH.\n\n"
 "WARNING, AND TIMING IS CRITICAL: give HBIG as soon as possible, ideally within 24 hours and at "
 "most within 7 days.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "'NO ACTION NEEDED' — true only for a titre ABOVE 10.\n\n"
 "'VACCINE ALONE' — WARNING, it builds durable protection but TAKES WEEKS, and in the meantime the "
 "person is DEFENCELESS. Besides, this person has ALREADY FAILED to respond to vaccine, so relying "
 "on it alone is risky.\n\n"
 "'HBIG ALONE' — gives immediate protection but is TRANSIENT, and this person remains a NON-RESPONDER, "
 "defenceless against the next exposure.",
 ["فقط برای تیتر بالای ۱۰ درست است؛ این کارورز با تیتر ۵ نان‌رسپاندر است.",
  "واکسن تنها محافظت پایدار می‌سازد ولی هفته‌ها طول می‌کشد و در آن فاصله بیمار بی‌دفاع است.",
  "HBIG تنها محافظت فوری می‌دهد ولی گذراست و فرد برای مواجهه‌ی بعدی همچنان بی‌دفاع می‌ماند.",
  "پاسخ صحیح — در نان‌رسپاندر، HBIG پل می‌زند تا واکسن برسد؛ هر دو با هم لازم‌اند."],
 ["True only for a titre above 10; this intern, at 5, is a non-responder.",
  "Vaccine alone builds durable protection but takes weeks, leaving the person defenceless meanwhile.",
  "HBIG alone gives immediate but transient protection, leaving the person defenceless against the next exposure.",
  "Correct — in a non-responder HBIG bridges the gap until the vaccine arrives; both are needed together."],
 "**HBIG چتر نجات است، واکسن آموزش پرواز — در سقوط به هر دو نیاز دارید.**",
 "HBIG is the parachute and the vaccine is flying lessons; in a fall you need both.",
 [ACIP, AASLD])

add("book:854", "case", "hard",
 "**IgM ضد HAV مثبت** و **IgM ضد HBc مثبت** با **HBsAg مثبت** = هپاتیت حاد A **و** حاد B، هم‌زمان.",
 "IgM anti-HAV POSITIVE plus IgM anti-HBc POSITIVE with HBsAg POSITIVE means SIMULTANEOUS acute A AND acute B.",
 HEP_FA + [
  "**این سؤال کاملاً با خواندن پنل سرولوژی حل می‌شود، بدون نیاز به هیچ دانش دیگری.**",
  "⚠️ **قاعده: IgM یعنی حاد. IgG یعنی گذشته. این تمام چیزی است که لازم دارید.**",
  "**IgM ضد HAV مثبت یعنی هپاتیت A همین حالا حاد است.**",
  "**IgM ضد HBc مثبت به‌علاوه‌ی HBsAg مثبت یعنی هپاتیت B هم همین حالا حاد است.**",
  "**پس هر دو حادند، و پاسخ ابتلای هم‌زمان است.**",
  "⚠️ **و چرا «ناقل غیرفعال B که دچار A شده» غلط است؟ چون ناقل مزمن IgM ضد HBc ندارد.**",
  "**ناقل مزمن IgG ضد HBc دارد؛ IgM نشانگر عفونت حاد یا تشدید حاد است.**",
  "**و چرا «سابقه‌ی قبلی A که دچار B شده» غلط است؟ چون سابقه‌ی قبلی IgG می‌سازد نه IgM.**",
  "**هم‌زمانی این دو غیرمعمول است ولی کاملاً ممکن، چون هر دو از راه‌های مشترک منتقل می‌شوند.**",
  "⚠️ **و در این سؤال پنل بیلی‌روبین کتاب اشتباه چاپ شده و درسنامه آن را صریح می‌گوید.**",
 ],
 HEP_EN + [
  "This question is solved entirely by reading the serology panel, with no other knowledge needed.",
  "WARNING, THE RULE: IgM means ACUTE. IgG means PAST. That is all you need.",
  "IgM anti-HAV positive means hepatitis A is acute right now.",
  "IgM anti-HBc positive together with HBsAg positive means hepatitis B is acute right now too.",
  "So both are acute, and the answer is simultaneous infection.",
  "WARNING, AND WHY IS 'AN INACTIVE B CARRIER WHO CAUGHT A' WRONG? Because a chronic carrier has no IgM anti-HBc.",
  "A chronic carrier has IgG anti-HBc; IgM marks acute infection or an acute flare.",
  "And why is 'past A who caught acute B' wrong? Because past infection makes IgG, not IgM.",
  "Their coincidence is unusual but entirely possible, since both share transmission routes.",
  "WARNING, AND IN THIS QUESTION THE BOOK'S BILIRUBIN PANEL IS MISPRINTED, and the lesson says so openly.",
 ],
 "**بیمار با بی‌اشتهایی و درد شکم از ۱۰ روز پیش.** پنل آزمایشگاهی:\n\n"
 "**ALT: ۱۳۰۰ · AST: ۱۱۰۰**\n\n"
 "**anti-HAV-IgM مثبت · anti-HBC-IgM مثبت · HBsAg مثبت · anti-HCV منفی**\n\n"
 "⚠️ **پیش از هر چیز، یک خطای چاپی در کتاب: پنل بیلی‌روبین این سؤال بیلی‌روبین "
 "مستقیم ۳٫۵ و توتال ۱٫۵ چاپ کرده — یعنی مستقیم از توتال بیشتر است، که از نظر ریاضی "
 "ناممکن است.** توتال **مجموع** کسر مستقیم و غیرمستقیم است. **پنل موردنظر تقریباً "
 "به‌قطع توتال ۳٫۵ و مستقیم ۱٫۵ بوده و حروف‌چین دو مقدار را جابه‌جا کرده است.** "
 "**خوشبختانه این پاسخ را عوض نمی‌کند، چون سؤال کاملاً با سرولوژی حل می‌شود.**\n\n"
 "**حالا سرولوژی را بخوانیم. و برای این کار فقط یک قاعده لازم دارید:**\n\n"
 "> ⚠️ **IgM یعنی حاد. IgG یعنی گذشته.**\n\n"
 "**قدم به قدم:**\n\n"
 "**anti-HAV-IgM مثبت** → هپاتیت A **همین حالا حاد است**. (اگر IgG بود، یعنی سابقه‌ی "
 "گذشته و ایمنی.)\n\n"
 "**anti-HBc-IgM مثبت** → هپاتیت B هم **همین حالا حاد است**.\n\n"
 "**HBsAg مثبت** → ویروس B **همین الان در بدن هست** و این را تأیید می‌کند.\n\n"
 "**anti-HCV منفی** → هپاتیت C در کار نیست.\n\n"
 "**نتیجه: بیمار هم‌زمان دچار هپاتیت حاد A و هپاتیت حاد B شده است.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟ هر کدام یک اشتباه سرولوژیک مشخص دارند:**\n\n"
 "**«فقط هپاتیت حاد A»** — این **HBsAg مثبت و IgM ضد HBc مثبت را نادیده می‌گیرد**. "
 "نمی‌توان نیمی از پنل را ندید.\n\n"
 "**«ناقل غیرفعال B که دچار هپاتیت حاد A شده»** — ⚠️ **این وسوسه‌انگیزترین گزینه است "
 "و ارزش دقت دارد.** در نگاه اول منطقی به‌نظر می‌رسد: HBsAg مثبت (ناقل) به‌علاوه‌ی IgM "
 "ضد HAV (حاد A). **ولی یک چیز آن را رد می‌کند: ناقل مزمن IgM ضد HBc ندارد.** ناقل "
 "مزمن **IgG ضد HBc** دارد. **حضور IgM دقیقاً همان چیزی است که می‌گوید عفونت B هم "
 "تازه است.**\n\n"
 "**«سابقه‌ی قبلی A که دچار هپاتیت حاد B شده»** — **سابقه‌ی قبلی A، IgG می‌سازد نه "
 "IgM.** حضور IgM ضد HAV یعنی A هم **حاد** است.\n\n"
 "⚠️ **و آیا هم‌زمانی دو هپاتیت حاد واقعاً ممکن است؟ بله.** غیرمعمول است ولی کاملاً "
 "ممکن، چون **هر دو ویروس در شرایط بهداشتی نامناسب و از راه‌های مشترک منتقل می‌شوند** "
 "— و ALT برابر ۱۳۰۰ نشان می‌دهد **آسیب کبدی شدیدی** در جریان است، سازگار با **دو "
 "حمله‌ی هم‌زمان**.",
 "A PATIENT with anorexia and abdominal pain for 10 days. The laboratory panel:\n\n"
 "ALT 1300 · AST 1100\n\n"
 "anti-HAV IgM POSITIVE · anti-HBc IgM POSITIVE · HBsAg POSITIVE · anti-HCV NEGATIVE\n\n"
 "WARNING, FIRST A MISPRINT IN THE BOOK: this stem's bilirubin panel prints DIRECT 3.5 and TOTAL "
 "1.5 — the direct exceeding the total, which is arithmetically impossible. The total is the SUM of "
 "the direct and indirect fractions. THE INTENDED PANEL WAS ALMOST CERTAINLY TOTAL 3.5 WITH DIRECT "
 "1.5, the typesetter having transposed them. Fortunately this does not change the answer, because "
 "the question is settled entirely by the serology.\n\n"
 "NOW READ THE SEROLOGY. For that you need only one rule:\n\n"
 "> WARNING: IgM MEANS ACUTE. IgG MEANS PAST.\n\n"
 "STEP BY STEP:\n\n"
 "anti-HAV IgM POSITIVE — hepatitis A IS ACUTE RIGHT NOW. (Were it IgG, it would mean past infection "
 "and immunity.)\n\n"
 "anti-HBc IgM POSITIVE — hepatitis B IS ALSO ACUTE RIGHT NOW.\n\n"
 "HBsAg POSITIVE — the B virus IS PRESENT IN THE BODY NOW, confirming it.\n\n"
 "anti-HCV NEGATIVE — hepatitis C is not involved.\n\n"
 "CONCLUSION: THE PATIENT HAS SIMULTANEOUS ACUTE HEPATITIS A AND ACUTE HEPATITIS B.\n\n"
 "AND WHY NOT THE OTHER THREE? Each contains a specific serological error:\n\n"
 "'ACUTE HEPATITIS A ONLY' — this IGNORES THE POSITIVE HBsAg AND THE POSITIVE IgM ANTI-HBc. You "
 "cannot unsee half the panel.\n\n"
 "'AN INACTIVE B CARRIER WHO HAS DEVELOPED ACUTE A' — WARNING, THE MOST TEMPTING OPTION, and worth "
 "care. At first glance it fits: HBsAg positive (carrier) plus IgM anti-HAV (acute A). BUT ONE THING "
 "REFUTES IT: A CHRONIC CARRIER HAS NO IgM ANTI-HBc. A chronic carrier has IgG ANTI-HBc. THE PRESENCE "
 "OF IgM IS PRECISELY WHAT SAYS THE B INFECTION IS ALSO NEW.\n\n"
 "'PAST HEPATITIS A WHO HAS DEVELOPED ACUTE B' — PAST HEPATITIS A MAKES IgG, NOT IgM. The presence "
 "of IgM anti-HAV means A IS ACUTE TOO.\n\n"
 "WARNING, AND IS SIMULTANEOUS ACUTE DUAL HEPATITIS REALLY POSSIBLE? YES. Unusual but entirely "
 "possible, because BOTH VIRUSES SPREAD IN POOR SANITARY CONDITIONS AND SHARE TRANSMISSION ROUTES — "
 "and an ALT of 1300 shows SEVERE HEPATIC INJURY, consistent with TWO SIMULTANEOUS INSULTS.",
 ["HBsAg مثبت و IgM ضد HBc مثبت را نادیده می‌گیرد؛ نمی‌توان نیمی از پنل را ندید.",
  "وسوسه‌انگیزترین گزینه — ولی ناقل مزمن IgM ضد HBc ندارد، بلکه IgG دارد.",
  "سابقه‌ی قبلی هپاتیت A، IgG می‌سازد نه IgM؛ حضور IgM یعنی A هم حاد است.",
  "پاسخ صحیح — IgM ضد HAV و IgM ضد HBc هر دو مثبت یعنی هر دو عفونت حادند."],
 ["This ignores the positive HBsAg and positive IgM anti-HBc; you cannot unsee half the panel.",
  "The most tempting option — but a chronic carrier has IgG anti-HBc, not IgM.",
  "Past hepatitis A makes IgG, not IgM; the presence of IgM means A is acute too.",
  "Correct — IgM anti-HAV and IgM anti-HBc both positive means both infections are acute."],
 "**IgM یعنی حاد، IgG یعنی گذشته — و همین یک قاعده کل پنل را می‌خواند.**",
 "IgM means acute and IgG means past — that single rule reads the whole panel.",
 [AASLD, ACIP])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book36.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 36 lessons:', len(L))
