# -*- coding: utf-8 -*-
"""Micro-lessons, batch 39 — the final block of the viral chapter.

Zoster and Ramsay Hunt, the four varicella post-exposure scenarios, measles,
mumps, rubella, and hepatitis C. With this batch the viral and sexually
transmitted infection chapter is complete.

THE FOUR POST-EXPOSURE KEYS THAT LOOK WRONG BUT ARE NOT
--------------------------------------------------------
q9626, q9629, q9630 and q9634 all key ORAL ACICLOVIR rather than VZIG. A
student taught "VZIG for the immunocompromised and the pregnant" will be sure
these keys are mistaken. They are not:

A randomised comparison in healthy children showed aciclovir started
IMMEDIATELY after exposure FAILED — 10 of 13 (77%) still developed varicella —
while aciclovir started at DAY 7 WORKED, with only 3 of 14 (21%) becoming ill.
The variable is TIMING: the antiviral must be present at the peak of viral
replication, and in the first days there is nothing to inhibit.

On that evidence UKHSA (2023, reviewed 2025) and RCOG Green-top 13 (updated
2024) made oral antivirals from day 7 to 14 the FIRST CHOICE for susceptible
pregnant women at any gestation, with VZIG reserved for those unable to take
oral drugs. A UKHSA study found no significant difference in chickenpox rates
between VZIG (53/145, 36.6%) and aciclovir (8/26, 30.8%), and 10 per cent of
VZIG recipients reported injection-site pain against none in the aciclovir
group. So the printed keys match CURRENT practice, and the lessons say so.

A SOURCE DEFECT ANNOTATED IN THIS BATCH
----------------------------------------
q9856 prints an antibody titre of "about 6" with NO UNIT AT ALL; page 315
prints the bare number. Anti-HBs is measured in mIU/mL with a protective
threshold of 10, so the intended reading is 6 mIU/mL — a non-responder. The
text is left alone and annotated (flag_source_errors_viral.py).

Reference: UKHSA — Guidelines on post-exposure prophylaxis for varicella or
shingles (2023, reviewed 2025); RCOG Green-top Guideline No. 13 (2024); CDC
Pink Book Ch. 13 (Measles) and Ch. 15 (Mumps); CDC/ACIP hepatitis B
recommendations; AASLD-IDSA hepatitis C guidance; Harrison's 21st ed (2022).
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = "Harrison's Principles of Internal Medicine, 21st ed (2022) — the viral infection chapters"
UKHSA = ("UK Health Security Agency — Guidelines on post-exposure prophylaxis (PEP) for "
         "varicella or shingles (2023, reviewed 2025)")
RCOG = ("Royal College of Obstetricians and Gynaecologists — Green-top Guideline No. 13: "
        "Chickenpox in Pregnancy (updated 2024)")
CDCMUMPS = ("CDC — Epidemiology and Prevention of Vaccine-Preventable Diseases (Pink Book), "
            "Ch. 15: Mumps; and Manual for the Surveillance of Vaccine-Preventable Diseases, "
            "Ch. 9: Mumps")
CDCMEASLES = ("CDC — Epidemiology and Prevention of Vaccine-Preventable Diseases (Pink Book), "
              "Ch. 13: Measles")
REDBOOK = ("American Academy of Pediatrics — Red Book: Report of the Committee on Infectious "
           "Diseases (varicella-zoster and rubella)")
ACIP = ("CDC/ACIP — Prevention of Hepatitis B Virus Infection in the United States: "
        "Recommendations of the Advisory Committee on Immunization Practices")
AASLD = "AASLD-IDSA — Recommendations for Testing, Managing and Treating Hepatitis C"

# ===================================================== ZOSTER
ZOS_FA = [
    "⚠️ **زونا همان ویروس آبله‌مرغان است که از گانگلیون حسی دوباره فعال شده است.**",
    "**پس زونا فقط در کسی رخ می‌دهد که قبلاً آبله‌مرغان گرفته باشد — ویروس آنجا خفته بود.**",
    "**و همیشه یک درماتوم را می‌گیرد و از خط وسط بدن عبور نمی‌کند.**",
    "⚠️ **درد سوزشی معمولاً ۲ تا ۳ روز پیش از ظهور وزیکول‌ها شروع می‌شود.**",
    "**و این «فاز پرودرومال دردناک» منشأ بسیاری از تشخیص‌های اشتباه است.**",
    "**درد قفسه‌ی سینه پیش از راش با انفارکتوس، و درد شکم با آپاندیسیت اشتباه گرفته می‌شود.**",
    "**پس در هر درد یک‌طرفه و درماتومی بدون علت روشن، به زونای پیش از راش فکر کنید.**",
    "⚠️ **و سندرم رامسی‌هانت: زونای گانگلیون زانویی عصب هفتم.**",
    "**سه‌گانه‌اش: وزیکول در کانال گوش، فلج محیطی صورت، و درد شدید گوش.**",
    "**و ممکن است کاهش شنوایی، وزوز و سرگیجه هم داشته باشد، چون عصب هشتم مجاور است.**",
    "**افتراقش از فلج بل حیاتی است: فلج بل وزیکول ندارد و درد شدید گوش ندارد.**",
    "⚠️ **و پیش‌آگهی رامسی‌هانت بدتر از فلج بل است، پس درمان فوری‌تری می‌طلبد.**",
    "**آسیکلوویر به‌علاوه‌ی کورتیکواستروئید، و هرچه زودتر بهتر — ترجیحاً ظرف ۷۲ ساعت.**",
    "**و شایع‌ترین عارضه‌ی زونا، نورالژی پس از هرپس است که ماه‌ها ادامه می‌یابد.**",
]
ZOS_EN = [
    "WARNING: ZOSTER IS THE CHICKENPOX VIRUS REACTIVATING from a sensory ganglion.",
    "So zoster occurs only in someone who has had chickenpox — the virus lay dormant there.",
    "And it always occupies ONE DERMATOME and does not cross the midline.",
    "WARNING, A BURNING PAIN USUALLY BEGINS 2 TO 3 DAYS BEFORE the vesicles appear.",
    "And that PAINFUL PRODROMAL PHASE is the source of many misdiagnoses.",
    "Chest pain before the rash is mistaken for infarction, and abdominal pain for appendicitis.",
    "So in any unexplained unilateral dermatomal pain, think of pre-eruptive zoster.",
    "WARNING, AND RAMSAY HUNT SYNDROME: zoster of the geniculate ganglion of the seventh nerve.",
    "Its triad: vesicles in the ear canal, peripheral facial palsy, and severe ear pain.",
    "It may also cause hearing loss, tinnitus and vertigo, because the eighth nerve lies adjacent.",
    "Distinguishing it from Bell's palsy is vital: Bell's palsy has no vesicles and no severe ear pain.",
    "WARNING, AND RAMSAY HUNT HAS A WORSE PROGNOSIS THAN BELL'S PALSY, so it demands more urgent treatment.",
    "Aciclovir plus a corticosteroid, and the sooner the better — ideally within 72 hours.",
    "And the commonest complication of zoster is post-herpetic neuralgia, lasting months.",
]

# ===================================================== VZV POST-EXPOSURE
PEP_FA = [
    "⚠️ **چهار سؤال این فصل پروفیلاکسی پس از تماس با آبله‌مرغان را می‌پرسند و کلید همه آسیکلوویر خوراکی است.**",
    "**دانشجویی که «VZIG برای فرد پرخطر» را از منبع قدیمی حفظ کرده، این کلیدها را غلط می‌پندارد.**",
    "**ولی کلیدها با راهنمای امروز سازگارند، و دلیلش ارزش دانستن دارد.**",
    "⚠️ **یک کارآزمایی نشان داد زمان شروع آسیکلوویر تعیین‌کننده است، نه خودِ دارو.**",
    "**شروع فوری پس از تماس شکست خورد: ۱۰ نفر از ۱۳ نفر (۷۷٪) باز هم آبله‌مرغان گرفتند.**",
    "**ولی شروع از روز هفتم مؤثر بود: فقط ۳ نفر از ۱۴ نفر (۲۱٪) بیمار شدند.**",
    "⚠️ **چرا؟ چون آسیکلوویر باید در زمان اوج تکثیر ویروس حاضر باشد، نه پیش از آن.**",
    "**در روزهای اول ویروس هنوز در حال تکثیر نیست و دارو چیزی برای مهار کردن ندارد.**",
    "**پس رژیم استاندارد: آسیکلوویر خوراکی از روز ۷ تا روز ۱۴ پس از تماس.**",
    "**و UKHSA و RCOG آن را انتخاب اول برای زن باردار مستعد در هر سن بارداری کرده‌اند.**",
    "⚠️ **در یک مطالعه، میزان ابتلا با VZIG و با آسیکلوویر تفاوت معناداری نداشت.**",
    "**ولی ۱۰ درصد دریافت‌کنندگان VZIG درد محل تزریق داشتند و در گروه آسیکلوویر هیچ عارضه‌ای گزارش نشد.**",
    "**پس VZIG امروز فقط وقتی است که بیمار نتواند داروی خوراکی بخورد، یا در نوزاد پرخطر.**",
    "**و اگر VZIG داده شود، باید ظرف ۹۶ ساعت باشد و حداکثر تا ۱۰ روز پس از تماس.**",
    "⚠️ **پنجره‌ی خطرناک نوزادی: تولد از ۵ روز پیش تا ۲ روز پس از شروع آبله‌مرغان مادر.**",
    "**و زونای مادر برای نوزاد خطر ندارد، چون مادر آنتی‌بادی دارد و آن را به جنین منتقل کرده است.**",
]
PEP_EN = [
    "WARNING: FOUR QUESTIONS IN THIS CHAPTER ASK ABOUT VARICELLA POST-EXPOSURE PROPHYLAXIS, and all key ORAL ACICLOVIR.",
    "A student who memorised 'VZIG for the high-risk' from an older source will think these keys are wrong.",
    "But the keys agree with current guidance, and the reason is worth knowing.",
    "WARNING, A TRIAL SHOWED THAT THE TIMING OF ACICLOVIR IS DECISIVE, not the drug itself.",
    "Starting immediately after exposure FAILED: 10 of 13 (77 per cent) still developed varicella.",
    "But starting on DAY 7 WORKED: only 3 of 14 (21 per cent) became ill.",
    "WARNING, WHY? Because aciclovir must be present at the PEAK of viral replication, not before it.",
    "In the first days the virus is not yet replicating and the drug has nothing to inhibit.",
    "So the standard regimen is ORAL ACICLOVIR FROM DAY 7 TO DAY 14 after exposure.",
    "And UKHSA and the RCOG have made it the FIRST CHOICE for a susceptible pregnant woman at any gestation.",
    "WARNING, IN ONE STUDY THE CHICKENPOX RATE DID NOT DIFFER SIGNIFICANTLY between VZIG and aciclovir.",
    "But 10 per cent of VZIG recipients reported injection-site pain, against no adverse effects in the aciclovir group.",
    "So VZIG today is only for those unable to take oral drugs, or for a high-risk neonate.",
    "And if VZIG is given it should be within 96 hours, and at the latest within 10 days of exposure.",
    "WARNING, THE DANGEROUS NEONATAL WINDOW: birth from 5 days before to 2 days after the onset of maternal chickenpox.",
    "And maternal zoster poses no risk to the neonate, because the mother has antibody and has passed it to the fetus.",
]

# ===================================================== MEASLES / RUBELLA / MUMPS
MMR_FA = [
    "⚠️ **سرخک را از مخاط بشناسید، نه از راش. لکه‌های کوپلیک تشخیصی‌اند و راش نیست.**",
    "**لکه‌های کوپلیک: نقاط سفید مایل به آبی روی مخاط گونه، در محاذات دندان آسیای دوم.**",
    "**آن‌ها ۱ تا ۲ روز پیش از راش ظاهر می‌شوند و ظرف ۲ روز محو می‌شوند — پنجره‌ی کوتاهی دارند.**",
    "⚠️ **و سه C پیش‌درآمد سرخک: سرفه، کوریزا، کونژنکتیویت — به‌علاوه‌ی تب بالا.**",
    "**راش سرخک ماکولوپاپولر و به‌هم‌پیوسته است و از پیشانی و پشت گوش شروع می‌شود.**",
    "**سپس به پایین گسترش می‌یابد و به همان ترتیب هم محو می‌شود، با پوسته‌ریزی قهوه‌ای.**",
    "⚠️ **شایع‌ترین عارضه‌ی سرخک اوتیت مدیای حاد است — شایع‌تر از پنومونی و بسیار شایع‌تر از انسفالیت.**",
    "**ولی شایع‌ترین علت مرگ، پنومونی است. «شایع‌ترین عارضه» با «کشنده‌ترین» فرق دارد.**",
    "**و ویتامین A تنها مداخله‌ای است که مرگ‌ومیر سرخک را کاهش می‌دهد.**",
    "**سرخجه: راش خفیف‌تر، تب کمتر، و لنفادنوپاتی پس‌گوشی و پس‌سری که مشخصه‌ی آن است.**",
    "⚠️ **خطر واقعی سرخجه برای جنین است، نه برای خود بیمار — سندرم سرخجه‌ی مادرزادی.**",
    "**و در بارداری، IgG مثبت با IgM منفی یعنی ایمنی قدیمی — یعنی خبر خوب و نیاز به هیچ اقدام.**",
    "**اوریون: تورم دردناک پاروتید، اغلب یک‌طرفه در شروع و سپس دوطرفه.**",
    "⚠️ **و دوره‌ی سرایت اوریون را با توصیه‌ی ایزولاسیون اشتباه نگیرید — این دو عدد متفاوت‌اند.**",
    "**ویروس از حدود ۷ روز پیش تا ۹ روز پس از پاروتیت جدا شده، و کتاب همین بازه را می‌پرسد.**",
    "**ولی توصیه‌ی عملی امروز CDC، ایزولاسیون تا ۵ روز پس از شروع پاروتیت است.**",
]
MMR_EN = [
    "WARNING: RECOGNISE MEASLES FROM THE MUCOSA, NOT THE RASH. Koplik spots are diagnostic and the rash is not.",
    "KOPLIK SPOTS: bluish-white dots on the buccal mucosa, opposite the second molars.",
    "They appear 1 to 2 days BEFORE the rash and fade within 2 days — a short window.",
    "WARNING, AND THE THREE Cs OF THE MEASLES PRODROME: cough, coryza, conjunctivitis — plus high fever.",
    "The measles rash is maculopapular and CONFLUENT, beginning on the forehead and behind the ears.",
    "It then spreads downwards and fades in the same order, with brownish desquamation.",
    "WARNING, THE COMMONEST COMPLICATION OF MEASLES IS ACUTE OTITIS MEDIA — commoner than pneumonia and far commoner than encephalitis.",
    "But the commonest CAUSE OF DEATH is pneumonia. 'Commonest complication' is not 'most lethal'.",
    "And vitamin A is the only intervention that reduces measles mortality.",
    "RUBELLA: a milder rash, less fever, and the characteristic POSTAURICULAR AND SUBOCCIPITAL lymphadenopathy.",
    "WARNING, RUBELLA'S REAL DANGER IS TO THE FETUS, not to the patient — congenital rubella syndrome.",
    "And in pregnancy, IgG positive with IgM negative means OLD IMMUNITY — good news, and no action needed.",
    "MUMPS: painful parotid swelling, often unilateral at onset and then bilateral.",
    "WARNING, AND DO NOT CONFUSE THE INFECTIOUS PERIOD WITH THE ISOLATION ADVICE — they are different numbers.",
    "Virus has been isolated from about 7 days before to 9 days after parotitis, and the book asks about that interval.",
    "But today's practical CDC advice is isolation until 5 days after parotitis onset.",
]

# ===================================================== HEPATITIS
HEP_FA = [
    "⚠️ **هپاتیت C دو نشانگر دارد و باید بدانید هرکدام چه سؤالی را جواب می‌دهند.**",
    "**آنتی‌بادی ضد HCV: آیا تماس رخ داده است؟ ولی ۸ تا ۱۲ هفته طول می‌کشد تا مثبت شود.**",
    "**HCV RNA: آیا ویروس همین حالا در خون هست؟ و از ۱ تا ۲ هفته پس از تماس مثبت است.**",
    "⚠️ **پس در عفونت حاد و زودهنگام، آنتی‌بادی منفی است و فقط RNA جواب می‌دهد.**",
    "**همان منطق پنجره‌ای که در HIV یاد گرفتید، این‌بار در بیماری دیگری.**",
    "**و آنتی‌بادی مثبت به‌تنهایی عفونت فعال را ثابت نمی‌کند: در بهبودیافته هم مثبت می‌ماند.**",
    "**حدود ۱۵ تا ۲۵ درصد افراد ویروس را خودبه‌خود پاک می‌کنند ولی آنتی‌بادی‌شان مثبت می‌ماند.**",
    "⚠️ **پس هر آنتی‌بادی مثبت باید با RNA پیگیری شود تا عفونت فعال از عفونت گذشته جدا شود.**",
    "**RIBA یک تست تأییدی قدیمی برای آنتی‌بادی بود و امروز کاملاً کنار گذاشته شده است.**",
    "**و آنتی‌بادی ضد LKM در تابلوی هپاتیت، دو تفسیر دارد و باید هر دو را در نظر گرفت.**",
    "⚠️ **هپاتیت خودایمن تیپ ۲ آن را می‌سازد، ولی در هپاتیت C هم به‌طور غیراختصاصی مثبت می‌شود.**",
    "**پس پیش از تشخیص خودایمنی و شروع سرکوب ایمنی، باید عفونت ویروسی رد شود.**",
    "⚠️ **و این ترتیب حیاتی است: کورتیکواستروئید در هپاتیت C فعال، تکثیر ویروس را تشدید می‌کند.**",
    "**در هپاتیت B هم آستانه‌ی محافظت anti-HBs عدد ۱۰ mIU/mL است — این عدد را حفظ کنید.**",
    "**زیر ۱۰ یعنی نان‌رسپاندر، و پس از مواجهه به HBIG نیاز است.**",
]
HEP_EN = [
    "WARNING: HEPATITIS C HAS TWO MARKERS, and you must know which question each answers.",
    "ANTI-HCV ANTIBODY: has exposure occurred? But it takes 8 to 12 weeks to turn positive.",
    "HCV RNA: is the virus in the blood right now? And it is positive from 1 to 2 weeks after exposure.",
    "WARNING, SO IN EARLY ACUTE INFECTION THE ANTIBODY IS NEGATIVE and only RNA answers.",
    "The same window logic you learned in HIV, now in a different disease.",
    "And a positive antibody alone does not prove active infection: it stays positive after recovery too.",
    "About 15 to 25 per cent of people clear the virus spontaneously yet remain antibody positive.",
    "WARNING, SO EVERY POSITIVE ANTIBODY MUST BE FOLLOWED BY RNA to separate active from past infection.",
    "RIBA was an old confirmatory antibody test and has been abandoned entirely.",
    "And an anti-LKM antibody in a hepatitis picture has two readings, both of which must be considered.",
    "WARNING, TYPE 2 AUTOIMMUNE HEPATITIS PRODUCES IT, but it also turns non-specifically positive in hepatitis C.",
    "So before diagnosing autoimmunity and starting immunosuppression, viral infection must be excluded.",
    "WARNING, AND THAT ORDER IS VITAL: corticosteroids in active hepatitis C accelerate viral replication.",
    "In hepatitis B the protective anti-HBs threshold is 10 mIU/mL — memorise that number.",
    "Below 10 means a non-responder, and after exposure HBIG is required.",
]


# =========================================================== ZOSTER
add("book:615", "case", "easy",
 "درد **پیش از راش**، سپس وزیکول روی زمینه‌ی اریتماتو ← **واریسلا زوستر**؛ درد پرودرومال کلاسیک است.",
 "PAIN BEFORE THE RASH, then vesicles on an erythematous base: VARICELLA ZOSTER; the prodromal pain is classic.",
 ZOS_FA + [
  "**این سؤال دقیقاً فاز پرودرومال دردناک زونا را به تصویر می‌کشد.**",
  "⚠️ **روز اول: فقط درد، بدون هیچ یافته‌ی معاینه‌ای. روز دوم: وزیکول‌ها ظاهر می‌شوند.**",
  "**همین توالی، تشخیص را قطعی می‌کند و هیچ بیماری دیگری آن را تقلید نمی‌کند.**",
  "**سن ۶۵ سالگی هم عامل خطر مهمی است، چون ایمنی سلولی با سن افت می‌کند.**",
  "**بروز زونا پس از ۵۰ سالگی به‌شدت افزایش می‌یابد و پس از ۸۰ سالگی به اوج می‌رسد.**",
 ],
 ZOS_EN + [
  "This stem depicts exactly the painful prodromal phase of zoster.",
  "WARNING, DAY ONE: pain alone with no physical finding. DAY TWO: the vesicles appear.",
  "That sequence settles the diagnosis, and no other disease imitates it.",
  "Age 65 is itself an important risk factor, because cellular immunity declines with age.",
  "Zoster incidence rises sharply after 50 and peaks after 80.",
 ],
 "**خانم ۶۵ ساله** با **درد ناحیه‌ی زیربغل**، که در معاینه‌ی **همان روز نکته‌ی خاصی "
 "نداشت**، ولی **فردا** چند **وزیکول روی زمینه‌ی اریتماتو** ظاهر شد.\n\n"
 "⚠️ **پاسخ: ویروس واریسلا زوستر. و این سؤال دقیقاً فاز پرودرومال دردناک زونا را به "
 "تصویر می‌کشد.**\n\n"
 "**توالی زمانی را ببینید — و این هسته‌ی سؤال است:**\n\n"
 "**روز اول: فقط درد.** معاینه **کاملاً طبیعی**. هیچ ضایعه‌ای نیست.\n\n"
 "**روز دوم: وزیکول‌ها ظاهر می‌شوند.**\n\n"
 "**این دقیقاً الگوی زوناست، و هیچ بیماری دیگری آن را تقلید نمی‌کند.**\n\n"
 "**چرا درد پیش از راش می‌آید؟ سازوکارش زیباست:**\n\n"
 "ویروس در **گانگلیون ریشه‌ی خلفی** خفته است. وقتی دوباره فعال می‌شود، **اول در "
 "خودِ عصب** تکثیر می‌کند و آن را ملتهب می‌سازد — و **این باعث درد می‌شود**. سپس "
 "**در طول آکسون به سمت پوست حرکت می‌کند** و وقتی به انتهای عصبی پوست می‌رسد، "
 "**وزیکول‌ها ظاهر می‌شوند**. ⚠️ **این سفر ۲ تا ۳ روز طول می‌کشد — و همان فاصله‌ای "
 "است که این سؤال نشان می‌دهد.**\n\n"
 "**و این فاز پرودرومال منشأ خطاهای تشخیصی جدی است:**\n\n"
 "**درد قفسه‌ی سینه پیش از راش** → با **انفارکتوس قلبی** اشتباه می‌شود.\n\n"
 "**درد شکم** → با **آپاندیسیت یا کولیک صفراوی**.\n\n"
 "**درد پهلو** → با **سنگ کلیه**.\n\n"
 "⚠️ **پس قاعده: در هر درد یک‌طرفه و درماتومی بدون علت روشن، به زونای پیش از راش "
 "فکر کنید و بیمار را ظرف چند روز دوباره ببینید.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**پاپیلوما ویروس انسانی** — **زگیل** می‌سازد: ضایعه‌ی **برجسته، مزمن و بدون درد**. "
 "نه وزیکول، نه درد حاد.\n\n"
 "**هرپس سیمپلکس** — ⚠️ نزدیک‌ترین رقیب، چون آن هم **وزیکول گروهی دردناک** می‌دهد. "
 "ولی HSV معمولاً **دور دهان یا ناحیه‌ی تناسلی** است، نه زیربغل. و در **سن ۶۵ سالگی** "
 "با **درد پرودرومال درماتومی**، زونا بسیار محتمل‌تر است.\n\n"
 "**استافیلوکوک اورئوس** — **پوستول و آبسه** می‌سازد، نه وزیکول شفاف روی زمینه‌ی "
 "اریتماتو. و **درد پیش از ضایعه** نمی‌دهد.\n\n"
 "**و سن؟** ⚠️ **۶۵ سالگی خودش یک عامل خطر مهم است.** ایمنی سلولی با سن افت می‌کند، "
 "و همین ویروس خفته را آزاد می‌کند. **بروز زونا پس از ۵۰ سالگی به‌شدت افزایش می‌یابد** "
 "— و به همین دلیل **واکسن زونا از ۵۰ سالگی توصیه می‌شود**.",
 "A 65-YEAR-OLD WOMAN with PAIN IN THE AXILLARY REGION, whose examination THAT DAY SHOWED NOTHING, "
 "but who THE NEXT DAY developed SEVERAL VESICLES ON AN ERYTHEMATOUS BASE.\n\n"
 "WARNING, THE ANSWER: VARICELLA ZOSTER VIRUS. This stem depicts exactly the painful prodromal "
 "phase of zoster.\n\n"
 "LOOK AT THE SEQUENCE — it is the core of the question:\n\n"
 "DAY ONE: PAIN ALONE. Examination COMPLETELY NORMAL. No lesion at all.\n\n"
 "DAY TWO: THE VESICLES APPEAR.\n\n"
 "THAT IS EXACTLY THE ZOSTER PATTERN, and no other disease imitates it.\n\n"
 "WHY DOES THE PAIN PRECEDE THE RASH? The mechanism is elegant:\n\n"
 "The virus lies dormant in the DORSAL ROOT GANGLION. On reactivation it FIRST REPLICATES IN THE "
 "NERVE ITSELF and inflames it — AND THAT CAUSES THE PAIN. It then TRAVELS DOWN THE AXON TOWARDS "
 "THE SKIN, and when it reaches the cutaneous nerve endings THE VESICLES APPEAR. WARNING, THAT "
 "JOURNEY TAKES 2 TO 3 DAYS — exactly the interval this question shows.\n\n"
 "AND THAT PRODROMAL PHASE IS THE SOURCE OF SERIOUS DIAGNOSTIC ERRORS:\n\n"
 "CHEST PAIN BEFORE THE RASH — mistaken for MYOCARDIAL INFARCTION.\n\n"
 "ABDOMINAL PAIN — for APPENDICITIS or BILIARY COLIC.\n\n"
 "FLANK PAIN — for RENAL STONE.\n\n"
 "WARNING, SO THE RULE: in any unexplained unilateral dermatomal pain, think of pre-eruptive zoster "
 "and review the patient within a few days.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "HUMAN PAPILLOMAVIRUS — makes WARTS: RAISED, CHRONIC, PAINLESS lesions. Neither vesicles nor acute "
 "pain.\n\n"
 "HERPES SIMPLEX — WARNING, the closest competitor, since it too makes PAINFUL GROUPED VESICLES. "
 "But HSV is usually PERIORAL OR GENITAL, not axillary. And at AGE 65 with DERMATOMAL PRODROMAL "
 "PAIN, zoster is far likelier.\n\n"
 "STAPHYLOCOCCUS AUREUS — makes PUSTULES AND ABSCESSES, not clear vesicles on an erythematous base. "
 "And it does not cause PAIN BEFORE THE LESION.\n\n"
 "AND THE AGE? WARNING, 65 IS ITSELF AN IMPORTANT RISK FACTOR. Cellular immunity declines with age "
 "and releases the dormant virus. ZOSTER INCIDENCE RISES SHARPLY AFTER 50 — which is why THE ZOSTER "
 "VACCINE IS RECOMMENDED FROM AGE 50.",
 ["پاپیلوما ویروس زگیل برجسته و بدون درد می‌سازد، نه وزیکول با درد پرودرومال.",
  "هرپس سیمپلکس نزدیک‌ترین رقیب است ولی معمولاً دور دهان یا تناسلی است، نه زیربغل در ۶۵ سالگی.",
  "استافیلوکوک پوستول و آبسه می‌سازد و درد پیش از ضایعه نمی‌دهد.",
  "پاسخ صحیح — درد پرودرومال سپس وزیکول درماتومی، الگوی قطعی زوناست."],
 ["Papillomavirus makes raised painless warts, not vesicles with prodromal pain.",
  "Herpes simplex is the closest competitor but is usually perioral or genital, not axillary at 65.",
  "Staphylococcus makes pustules and abscesses and does not cause pain before the lesion.",
  "Correct — prodromal pain followed by dermatomal vesicles is the definitive zoster pattern."],
 "**درد پیش از راش می‌آید، چون ویروس اول عصب را ملتهب می‌کند و بعد به پوست می‌رسد.**",
 "The pain precedes the rash because the virus inflames the nerve first and reaches the skin later.",
 [REDBOOK, H])

add("book:616", "case", "medium",
 "وزیکول در **کانال گوش** + فلج محیطی عصب هفتم ← **سندرم رامسی‌هانت**.",
 "Vesicles in the EAR CANAL with a peripheral seventh nerve palsy: RAMSAY HUNT SYNDROME.",
 ZOS_FA + [
  "**این سؤال سه‌گانه‌ی رامسی‌هانت را کامل آورده و هر سه جزء در متن هست.**",
  "⚠️ **وزیکول دردناک در کانال گوش، فلج محیطی صورت، و درد گوش.**",
  "**و بی‌حسی زبان هم توضیح دارد: عصب هفتم شاخه‌ی کوردا تیمپانی را می‌دهد.**",
  "**آن شاخه چشایی دوسوم قدامی زبان را حمل می‌کند، پس درگیری‌اش منطقی است.**",
  "⚠️ **افتراق از فلج بل حیاتی است و با دو چیز انجام می‌شود: وزیکول و درد شدید.**",
  "**فلج بل تعریفاً ایدیوپاتیک است و هیچ ضایعه‌ی پوستی ندارد.**",
  "**و پیش‌آگهی رامسی‌هانت بدتر است: بهبود کامل در حدود ۷۰ درصد فلج بل ولی کمتر در رامسی‌هانت.**",
  "**پس درمان فوری‌تر است: آسیکلوویر به‌علاوه‌ی کورتیکواستروئید، ترجیحاً ظرف ۷۲ ساعت.**",
 ],
 ZOS_EN + [
  "This stem gives the complete Ramsay Hunt triad, and all three parts are present.",
  "WARNING: painful vesicles in the ear canal, peripheral facial palsy, and ear pain.",
  "And the numb tongue is explained too: the seventh nerve gives off the chorda tympani.",
  "That branch carries taste from the anterior two thirds of the tongue, so its involvement makes sense.",
  "WARNING, DISTINGUISHING IT FROM BELL'S PALSY IS VITAL, and two things do it: the vesicles and the severe pain.",
  "Bell's palsy is by definition idiopathic and has no skin lesion.",
  "And Ramsay Hunt has the worse prognosis: full recovery in about 70 per cent of Bell's palsy but less in Ramsay Hunt.",
  "So treatment is more urgent: aciclovir plus a corticosteroid, ideally within 72 hours.",
 ],
 "**خانم ۵۵ ساله** با **انحراف صورت به سمت راست**، **درد گوش چپ** و **بی‌حسی زبان**. "
 "در معاینه: **وزیکول‌های دردناک در کانال گوش چپ** و **فلج محیطی عصب هفتم همان سمت**.\n\n"
 "⚠️ **پاسخ: سندرم رامسی‌هانت — و سه‌گانه‌اش کامل در متن آمده است.**\n\n"
 "**سندرم رامسی‌هانت چیست؟ زونای گانگلیون زانویی عصب هفتم.**\n\n"
 "**همان ویروس آبله‌مرغان که در گانگلیون زانویی (geniculate) خفته بود، دوباره فعال "
 "شده است.**\n\n"
 "**سه‌گانه‌ی تشخیصی:**\n\n"
 "**۱) وزیکول در کانال گوش خارجی** (یا لاله‌ی گوش یا کام) ✅ در متن هست.\n\n"
 "**۲) فلج محیطی عصب هفتم** ✅ در متن هست.\n\n"
 "**۳) درد شدید گوش** ✅ در متن هست.\n\n"
 "**و «بی‌حسی زبان» چطور توضیح داده می‌شود؟** ⚠️ **این جزئیات آناتومیک زیبایی است:** "
 "عصب هفتم شاخه‌ای به نام **کوردا تیمپانی** می‌دهد که **چشایی دوسوم قدامی زبان** را "
 "حمل می‌کند. **پس درگیری عصب هفتم می‌تواند اختلال چشایی و حس زبان بدهد** — و همین "
 "تشخیص را محکم‌تر می‌کند.\n\n"
 "⚠️ **و حالا مهم‌ترین بخش: افتراق از فلج بل.**\n\n"
 "**فلج بل** تعریفاً **ایدیوپاتیک** است: فلج محیطی صورت **بدون علت شناخته‌شده**.\n\n"
 "**دو چیز رامسی‌هانت را از آن جدا می‌کند:**\n\n"
 "**۱) وزیکول‌ها** — فلج بل **هیچ ضایعه‌ی پوستی ندارد**.\n\n"
 "**۲) درد شدید** — فلج بل معمولاً **بدون درد یا کم‌درد** است.\n\n"
 "**چرا این افتراق حیاتی است؟ دو دلیل:**\n\n"
 "⚠️ **پیش‌آگهی:** بهبود کامل در **حدود ۷۰ درصد** موارد فلج بل رخ می‌دهد، ولی در "
 "رامسی‌هانت **کمتر**.\n\n"
 "⚠️ **درمان:** رامسی‌هانت **آسیکلوویر + کورتیکواستروئید** می‌خواهد، و **هرچه زودتر "
 "بهتر** — ترجیحاً ظرف **۷۲ ساعت**. فلج بل فقط استروئید.\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**ترومبوز سینوس کاورنو** — درگیری اعصاب **۳، ۴، ۶ و شاخه‌ی اول ۵** می‌دهد: "
 "**افتالموپلژی، پروپتوز، ادم پلک**. **عصب هفتم اصلاً از سینوس کاورنو عبور نمی‌کند.**\n\n"
 "**اوتیت حاد** — درد گوش می‌دهد، ولی **وزیکول نمی‌سازد** و **فلج صورت** فقط در "
 "عارضه‌ی نادر آن رخ می‌دهد.\n\n"
 "**فلج بل** — ⚠️ همان دام اصلی، و **وزیکول‌ها آن را رد می‌کنند**.",
 "A 55-YEAR-OLD WOMAN with FACIAL DEVIATION TO THE RIGHT, LEFT EAR PAIN and a NUMB TONGUE. On "
 "examination: PAINFUL VESICLES IN THE LEFT EAR CANAL and a PERIPHERAL SEVENTH NERVE PALSY on the "
 "same side.\n\n"
 "WARNING, THE ANSWER: RAMSAY HUNT SYNDROME — and its complete triad is in the stem.\n\n"
 "WHAT IS RAMSAY HUNT SYNDROME? Zoster of the geniculate ganglion of the seventh nerve.\n\n"
 "The same chickenpox virus, dormant in the GENICULATE ganglion, has reactivated.\n\n"
 "THE DIAGNOSTIC TRIAD:\n\n"
 "1) VESICLES IN THE EXTERNAL EAR CANAL (or pinna or palate) — present.\n\n"
 "2) PERIPHERAL SEVENTH NERVE PALSY — present.\n\n"
 "3) SEVERE EAR PAIN — present.\n\n"
 "AND HOW IS THE NUMB TONGUE EXPLAINED? WARNING, an elegant anatomical detail: the seventh nerve "
 "gives off a branch called the CHORDA TYMPANI, which carries TASTE FROM THE ANTERIOR TWO THIRDS OF "
 "THE TONGUE. SO SEVENTH NERVE INVOLVEMENT CAN DISTURB TASTE AND TONGUE SENSATION — which "
 "strengthens the diagnosis.\n\n"
 "WARNING, AND NOW THE MOST IMPORTANT PART: DISTINGUISHING IT FROM BELL'S PALSY.\n\n"
 "BELL'S PALSY is by definition IDIOPATHIC: a peripheral facial palsy WITH NO KNOWN CAUSE.\n\n"
 "TWO THINGS SEPARATE RAMSAY HUNT FROM IT:\n\n"
 "1) THE VESICLES — Bell's palsy has NO SKIN LESION.\n\n"
 "2) SEVERE PAIN — Bell's palsy is usually PAINLESS OR MILDLY PAINFUL.\n\n"
 "WHY IS THE DISTINCTION VITAL? Two reasons:\n\n"
 "WARNING, PROGNOSIS: full recovery occurs in ABOUT 70 PER CENT of Bell's palsy but LESS in Ramsay "
 "Hunt.\n\n"
 "WARNING, TREATMENT: Ramsay Hunt needs ACICLOVIR PLUS A CORTICOSTEROID, and THE SOONER THE BETTER "
 "— ideally within 72 HOURS. Bell's palsy needs steroid alone.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "CAVERNOUS SINUS THROMBOSIS — involves nerves 3, 4, 6 AND THE FIRST DIVISION OF 5: "
 "OPHTHALMOPLEGIA, PROPTOSIS, LID OEDEMA. THE SEVENTH NERVE DOES NOT PASS THROUGH THE CAVERNOUS "
 "SINUS AT ALL.\n\n"
 "ACUTE OTITIS — causes ear pain, but MAKES NO VESICLES, and facial palsy occurs only as a rare "
 "complication.\n\n"
 "BELL'S PALSY — WARNING, the main trap, AND THE VESICLES EXCLUDE IT.",
 ["ترومبوز سینوس کاورنو اعصاب ۳ و ۴ و ۶ را درگیر می‌کند؛ عصب هفتم اصلاً از آنجا عبور نمی‌کند.",
  "پاسخ صحیح — وزیکول کانال گوش با فلج عصب هفتم و درد گوش، سه‌گانه‌ی رامسی‌هانت است.",
  "اوتیت حاد درد گوش می‌دهد ولی وزیکول نمی‌سازد و فلج صورت فقط عارضه‌ی نادر آن است.",
  "فلج بل تعریفاً ایدیوپاتیک است و هیچ ضایعه‌ی پوستی ندارد؛ وزیکول‌ها آن را رد می‌کنند."],
 ["Cavernous sinus thrombosis involves nerves 3, 4 and 6; the seventh nerve does not pass through it.",
  "Correct — ear-canal vesicles with a seventh nerve palsy and ear pain is the Ramsay Hunt triad.",
  "Acute otitis causes ear pain but makes no vesicles, and facial palsy is only a rare complication.",
  "Bell's palsy is by definition idiopathic with no skin lesion; the vesicles exclude it."],
 "**وزیکول در گوش + فلج صورت = رامسی‌هانت، نه فلج بل. و درمانش فوری‌تر است.**",
 "Ear vesicles plus facial palsy means Ramsay Hunt, not Bell's palsy — and it is more urgent.",
 [REDBOOK, H])

add("book:617", "case", "easy",
 "همان تابلو، این‌بار عامل را می‌پرسد: **واریسلا زوستر ویروس**.",
 "The same picture, now asking the organism: VARICELLA ZOSTER VIRUS.",
 ZOS_FA + [
  "**این سؤال قرینه‌ی سؤال قبلی است: آنجا نام سندرم را پرسید، اینجا عامل را.**",
  "⚠️ **و تکرار همان مفهوم در دو سیتینگ نشان می‌دهد چقدر برای طراحان مهم است.**",
  "**وزیکول در کانال گوش به‌علاوه‌ی فلج عصب هفتم، فقط یک عامل دارد.**",
  "**سیتومگالوویروس در فرد ایمن‌سالم چنین تابلویی نمی‌سازد.**",
  "**هرپس سیمپلکس فلج صورت با وزیکول گوش نمی‌دهد؛ محلش دور دهان است.**",
  "**و کوکساکی ویروس بیماری دست و پا و دهان می‌دهد، با وزیکول در کف دست و پا و دهان.**",
  "**که هرپانژینا هم می‌سازد، ولی هیچ‌کدام فلج عصب هفتم نمی‌دهند.**",
 ],
 ZOS_EN + [
  "This mirrors the previous question: that one asked the syndrome's name, this one the organism.",
  "WARNING, AND THE REPETITION ACROSS TWO SITTINGS shows how much it matters to the examiners.",
  "Ear-canal vesicles plus a seventh nerve palsy have only one cause.",
  "Cytomegalovirus does not produce this picture in an immunocompetent person.",
  "Herpes simplex does not cause facial palsy with ear vesicles; its site is perioral.",
  "And coxsackievirus causes hand, foot and mouth disease, with vesicles on palms, soles and mouth.",
  "It also causes herpangina, but neither produces a seventh nerve palsy.",
 ],
 "**آقای ۵۳ ساله** با **درد یک‌طرفه‌ی گوش**، و در معاینه **ضایعات وزیکولر دردناک در "
 "کانال خارجی گوش** به‌همراه **فلج عصب هفتم همان سمت**.\n\n"
 "⚠️ **پاسخ: واریسلا زوستر ویروس. و این سؤال قرینه‌ی سؤال قبلی است — آنجا نام سندرم "
 "را پرسید، اینجا عامل را.**\n\n"
 "**تکرار همین مفهوم در دو سیتینگ مختلف نشان می‌دهد چقدر برای طراحان مهم است. پس "
 "این دو را با هم حفظ کنید:**\n\n"
 "**نام سندرم: رامسی‌هانت. عامل: واریسلا زوستر ویروس.**\n\n"
 "**و منطق ماجرا:** ویروس آبله‌مرغان پس از عفونت اولیه در **گانگلیون‌های حسی** خفته "
 "می‌ماند. یکی از آن گانگلیون‌ها **گانگلیون زانویی عصب هفتم** است. وقتی ایمنی سلولی "
 "افت کند (با سن، استرس یا بیماری)، ویروس **دوباره فعال** می‌شود و در قلمرو همان "
 "عصب ظاهر می‌شود.\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**سیتومگالوویروس** — در فرد **ایمن‌سالم** معمولاً **بی‌علامت** است یا سندرم "
 "شبه‌مونونوکلئوز می‌دهد. **ضایعه‌ی وزیکولر پوستی و فلج عصب هفتم نمی‌سازد.** (در "
 "ایدز پیشرفته **رتینیت** می‌دهد، که ماجرای دیگری است.)\n\n"
 "**هرپس سیمپلکس** — ⚠️ نزدیک‌ترین رقیب چون **وزیکول** می‌سازد. ولی محل معمولش "
 "**دور دهان (HSV-1)** یا **تناسلی (HSV-2)** است، نه کانال گوش. و **فلج عصب هفتم "
 "نمی‌دهد**. (نکته‌ی ظریف: برخی معتقدند HSV در **پاتوژنز فلج بل** نقش دارد — ولی "
 "فلج بل **وزیکول ندارد**، و همین تفاوت است.)\n\n"
 "**کوکساکی ویروس** — بیماری **دست و پا و دهان** می‌دهد: وزیکول در **کف دست، کف پا "
 "و دهان**. و **هرپانژینا**: وزیکول و زخم در **کام نرم و حلق**. ⚠️ **هیچ‌کدام فلج "
 "عصب هفتم نمی‌دهند** و توزیعشان **درماتومی نیست**.\n\n"
 "⚠️ **و یک نکته‌ی درمانی که تکرارش می‌ارزد: رامسی‌هانت اورژانس نسبی است.** "
 "**آسیکلوویر + کورتیکواستروئید ظرف ۷۲ ساعت** بهترین شانس بازگشت عملکرد عصب را "
 "می‌دهد. **هر روز تأخیر، احتمال فلج دائمی را بالا می‌برد.**",
 "A 53-YEAR-OLD MAN with UNILATERAL EAR PAIN and, on examination, PAINFUL VESICULAR LESIONS IN THE "
 "EXTERNAL EAR CANAL with a SEVENTH NERVE PALSY on the same side.\n\n"
 "WARNING, THE ANSWER: VARICELLA ZOSTER VIRUS. This mirrors the previous question — that one asked "
 "the syndrome's name, this one the organism.\n\n"
 "The repetition across two sittings shows how much it matters to examiners, so memorise the pair:\n\n"
 "THE SYNDROME: RAMSAY HUNT. THE ORGANISM: VARICELLA ZOSTER VIRUS.\n\n"
 "AND THE LOGIC: after primary infection the chickenpox virus lies dormant in SENSORY GANGLIA. One "
 "of them is the GENICULATE GANGLION OF THE SEVENTH NERVE. When cellular immunity declines (with "
 "age, stress or illness) the virus REACTIVATES and appears in that nerve's territory.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "CYTOMEGALOVIRUS — in an IMMUNOCOMPETENT person it is usually ASYMPTOMATIC or causes a "
 "mononucleosis-like syndrome. IT DOES NOT MAKE VESICULAR SKIN LESIONS OR A SEVENTH NERVE PALSY. "
 "(In advanced AIDS it causes RETINITIS, which is a different story.)\n\n"
 "HERPES SIMPLEX — WARNING, the closest competitor because it makes VESICLES. But its usual sites "
 "are PERIORAL (HSV-1) or GENITAL (HSV-2), not the ear canal. And IT DOES NOT CAUSE A SEVENTH NERVE "
 "PALSY. (A subtle point: some believe HSV contributes to the PATHOGENESIS OF BELL'S PALSY — but "
 "Bell's palsy HAS NO VESICLES, and that is the difference.)\n\n"
 "COXSACKIEVIRUS — causes HAND, FOOT AND MOUTH DISEASE: vesicles on the PALMS, SOLES AND MOUTH. And "
 "HERPANGINA: vesicles and ulcers on the SOFT PALATE AND PHARYNX. WARNING, NEITHER CAUSES A SEVENTH "
 "NERVE PALSY and their distribution IS NOT DERMATOMAL.\n\n"
 "WARNING, AND A TREATMENT POINT WORTH REPEATING: RAMSAY HUNT IS A RELATIVE EMERGENCY. ACICLOVIR "
 "PLUS A CORTICOSTEROID WITHIN 72 HOURS gives the best chance of nerve recovery. EVERY DAY OF DELAY "
 "RAISES THE CHANCE OF PERMANENT PALSY.",
 ["سیتومگالوویروس در فرد ایمن‌سالم ضایعه‌ی وزیکولر پوستی و فلج عصب هفتم نمی‌سازد.",
  "هرپس سیمپلکس وزیکول می‌سازد ولی محلش دور دهان یا تناسلی است و فلج عصب هفتم نمی‌دهد.",
  "کوکساکی بیماری دست و پا و دهان و هرپانژینا می‌دهد، بدون فلج عصب هفتم و بدون توزیع درماتومی.",
  "پاسخ صحیح — واریسلا زوستر از گانگلیون زانویی فعال می‌شود و سندرم رامسی‌هانت می‌سازد."],
 ["Cytomegalovirus does not cause vesicular skin lesions or a seventh nerve palsy in an immunocompetent person.",
  "Herpes simplex makes vesicles but at perioral or genital sites, and causes no seventh nerve palsy.",
  "Coxsackievirus causes hand-foot-and-mouth disease and herpangina, without facial palsy or dermatomal distribution.",
  "Correct — varicella zoster reactivates from the geniculate ganglion and produces Ramsay Hunt syndrome."],
 "**سندرم: رامسی‌هانت. عامل: واریسلا زوستر. و ۷۲ ساعت طلایی است.**",
 "The syndrome is Ramsay Hunt, the organism is varicella zoster, and 72 hours is the golden window.",
 [REDBOOK, H])


# =============================================== VZV POST-EXPOSURE (4 items)
add("book:626", "case", "hard",
 "کودک پیوندی در تماس با آبله‌مرغان ← **آسیکلوویر از روز هفتم**، چون زمان شروع تعیین‌کننده است.",
 "A transplant child exposed to chickenpox: ACICLOVIR FROM DAY 7, because the timing of onset is decisive.",
 PEP_FA + [
  "**این کودک هر دو شرط پرخطر بودن را دارد: نقص ایمنی و نداشتن ایمنی قبلی.**",
  "**پیوند کلیه یعنی سرکوب ایمنی دارویی مداوم، پس آبله‌مرغان در او می‌تواند کشنده باشد.**",
  "⚠️ **و واکسن آبله‌مرغان زنده است، پس در او مطلقاً کنتراندیکه است.**",
  "**پس گزینه‌های حاوی واکسن، صرف‌نظر از هر چیز دیگر، حذف می‌شوند.**",
  "**می‌ماند انتخاب میان VZIG و آسیکلوویر، و کلید آسیکلوویر از روز هفتم است.**",
  "**و متن می‌گوید تماس ۶ روز پیش بوده — یعنی دقیقاً در آستانه‌ی روز هفتم.**",
  "⚠️ **این هماهنگی زمانی تصادفی نیست؛ طراح عمداً روز ششم را انتخاب کرده است.**",
 ],
 PEP_EN + [
  "This child meets both high-risk conditions: immunosuppression and no prior immunity.",
  "A renal transplant means continuous drug immunosuppression, so chickenpox could be fatal.",
  "WARNING, AND THE VARICELLA VACCINE IS LIVE, so it is absolutely contraindicated in him.",
  "So any option containing the vaccine is eliminated regardless of anything else.",
  "That leaves the choice between VZIG and aciclovir, and the key is aciclovir from day 7.",
  "And the stem says the exposure was 6 days ago — right on the threshold of day 7.",
  "WARNING, THAT TIMING IS NOT ACCIDENTAL; the examiner chose day six deliberately.",
 ],
 "**پسربچه‌ی ۹ ساله، مورد پیوند کلیه در سال گذشته**، که **خواهرش ۶ روز قبل "
 "آبله‌مرغان گرفته**. خودش **سابقه‌ی ابتلا یا واکسیناسیون ندارد**.\n\n"
 "⚠️ **پاسخ: قرص آسیکلوویر از روز ۷ پس از تماس. و بسیاری این کلید را غلط "
 "می‌پندارند — پس دقیق توضیح می‌دهیم.**\n\n"
 "**اول وضعیت بیمار را بسنجیم:**\n\n"
 "**۱) نقص ایمنی** — پیوند کلیه یعنی **سرکوب ایمنی دارویی مداوم**. آبله‌مرغان در او "
 "می‌تواند **منتشر و کشنده** باشد.\n\n"
 "**۲) بدون ایمنی قبلی** — نه بیماری گرفته، نه واکسن زده. یعنی **کاملاً مستعد**.\n\n"
 "**۳) تماس واقعی** — خواهر هم‌خانه، ۶ روز پیش.\n\n"
 "**پس این کودک قطعاً نیازمند پروفیلاکسی است. سؤال این است: کدام؟**\n\n"
 "⚠️ **اول دو گزینه‌ی حاوی واکسن را حذف کنید: واکسن آبله‌مرغان یک ویروس زنده‌ی "
 "ضعیف‌شده است و در فرد با سرکوب ایمنی مطلقاً کنتراندیکه است.** در او، ویروس "
 "واکسن می‌تواند **خودش بیماری بسازد**.\n\n"
 "**می‌ماند: VZIG یا آسیکلوویر.**\n\n"
 "**و اینجا همان نکته‌ای است که دانشجویان را گیج می‌کند. بسیاری «VZIG برای فرد "
 "نقص‌ایمنی» را حفظ کرده‌اند. ولی شواهد چیز دیگری می‌گوید:**\n\n"
 "⚠️ **یک کارآزمایی نشان داد زمان شروع آسیکلوویر تعیین‌کننده است، نه خودِ دارو:**\n\n"
 "**شروع فوری پس از تماس: ۱۰ نفر از ۱۳ نفر (۷۷٪) باز هم آبله‌مرغان گرفتند — یعنی "
 "شکست.**\n\n"
 "**شروع از روز هفتم: فقط ۳ نفر از ۱۴ نفر (۲۱٪) بیمار شدند — یعنی موفقیت.**\n\n"
 "**چرا؟** چون آسیکلوویر **تکثیر ویروس را مهار می‌کند**، و باید **در زمان اوج "
 "تکثیر** حاضر باشد. در روزهای اول، ویروس هنوز در حال **کمون** است و **چیزی برای "
 "مهار کردن وجود ندارد** — دارو بی‌جهت مصرف می‌شود و تا زمان اوج تکثیر تمام شده "
 "است.\n\n"
 "⚠️ **و توجه کنید متن می‌گوید تماس ۶ روز پیش بوده — یعنی دقیقاً در آستانه‌ی روز "
 "هفتم. این هماهنگی تصادفی نیست؛ طراح عمداً آن را انتخاب کرده تا گزینه دقیقاً "
 "اجرایی باشد.**\n\n"
 "**و بر همین اساس، UKHSA و RCOG امروز آسیکلوویر خوراکی از روز ۷ تا ۱۴ را "
 "انتخاب اول کرده‌اند، و VZIG را برای کسی گذاشته‌اند که نتواند داروی خوراکی "
 "بخورد.**",
 "A 9-YEAR-OLD BOY, a renal transplant recipient last year, whose SISTER DEVELOPED CHICKENPOX 6 "
 "DAYS AGO. He has NO HISTORY OF THE DISEASE OR OF VACCINATION.\n\n"
 "WARNING, THE ANSWER: ORAL ACICLOVIR FROM DAY 7 AFTER EXPOSURE. Many think this key is wrong, so "
 "let us explain it carefully.\n\n"
 "FIRST ASSESS THE PATIENT:\n\n"
 "1) IMMUNOSUPPRESSION — a renal transplant means CONTINUOUS DRUG IMMUNOSUPPRESSION. Chickenpox in "
 "him could be DISSEMINATED AND FATAL.\n\n"
 "2) NO PRIOR IMMUNITY — neither disease nor vaccine. He is FULLY SUSCEPTIBLE.\n\n"
 "3) A REAL EXPOSURE — a household sister, 6 days ago.\n\n"
 "SO THIS CHILD CERTAINLY NEEDS PROPHYLAXIS. The question is: which?\n\n"
 "WARNING, FIRST ELIMINATE THE TWO VACCINE-CONTAINING OPTIONS: the varicella vaccine is a LIVE "
 "ATTENUATED VIRUS and is ABSOLUTELY CONTRAINDICATED in an immunosuppressed person. In him the "
 "vaccine virus could ITSELF CAUSE DISEASE.\n\n"
 "THAT LEAVES VZIG OR ACICLOVIR.\n\n"
 "And here is what confuses students. Many memorised 'VZIG for the immunocompromised'. But the "
 "evidence says otherwise:\n\n"
 "WARNING, A TRIAL SHOWED THE TIMING OF ACICLOVIR IS DECISIVE, NOT THE DRUG:\n\n"
 "STARTED IMMEDIATELY AFTER EXPOSURE: 10 of 13 (77%) still developed chickenpox — a failure.\n\n"
 "STARTED ON DAY 7: only 3 of 14 (21%) became ill — a success.\n\n"
 "WHY? Because aciclovir INHIBITS VIRAL REPLICATION and must be present AT THE PEAK OF REPLICATION. "
 "In the first days the virus is still INCUBATING and THERE IS NOTHING TO INHIBIT — the drug is "
 "consumed pointlessly and is finished before replication peaks.\n\n"
 "WARNING, AND NOTE THAT THE STEM SAYS THE EXPOSURE WAS 6 DAYS AGO — right on the threshold of day "
 "7. That alignment is not accidental; the examiner chose it so the option is exactly actionable.\n\n"
 "AND ON THAT EVIDENCE, UKHSA AND THE RCOG NOW MAKE ORAL ACICLOVIR FROM DAY 7 TO 14 THE FIRST "
 "CHOICE, reserving VZIG for those who cannot take oral drugs.",
 ["واکسن آبله‌مرغان زنده است و در کودک با سرکوب ایمنی مطلقاً کنتراندیکه است.",
  "VZIG گزینه‌ی معقولی است ولی امروز جایگزین دوم است و باید ظرف ۹۶ ساعت داده می‌شد.",
  "این گزینه هم واکسن زنده دارد، که در فرد پیوندی ممنوع است.",
  "پاسخ صحیح — آسیکلوویر از روز هفتم مؤثر است، چون باید در اوج تکثیر ویروس حاضر باشد."],
 ["The varicella vaccine is live and absolutely contraindicated in an immunosuppressed child.",
  "VZIG is a reasonable option but is today the second choice and should have been given within 96 hours.",
  "This option also contains the live vaccine, which is forbidden in a transplant recipient.",
  "Correct — aciclovir from day 7 works, because it must be present at the peak of viral replication."],
 "**شروع فوری شکست خورد (۷۷٪)، شروع روز هفتم موفق شد (۲۱٪). زمان، متغیر است.**",
 "Immediate start failed (77%), day-seven start worked (21%). Timing is the variable.",
 [UKHSA, RCOG])

add("book:629", "case", "medium",
 "زن باردار مستعد، **۷ روز** پس از تماس ← **آسیکلوویر خوراکی**، دقیقاً در پنجره‌ی درست.",
 "A susceptible pregnant woman 7 DAYS after exposure: ORAL ACICLOVIR, exactly in the right window.",
 PEP_FA + [
  "**زن باردار مستعد یکی از گروه‌های پرخطر است و پروفیلاکسی برایش الزامی است.**",
  "⚠️ **و اینجا زمان‌بندی به‌طور کامل با راهنما هم‌خوان است: تماس دقیقاً ۷ روز پیش.**",
  "**پس امروز دقیقاً روز شروع آسیکلوویر است — نه زودتر و نه دیرتر.**",
  "**و واکسن آبله‌مرغان در بارداری کنتراندیکه است، چون ویروس زنده است.**",
  "**پس گزینه‌های حاوی واکسن، صرف‌نظر از هر چیز دیگر، حذف می‌شوند.**",
  "⚠️ **خطر آبله‌مرغان در بارداری دو بخش دارد و نباید قاطی شوند.**",
  "**خطر برای مادر: پنومونی واریسلایی، که در بارداری شدیدتر و کشنده‌تر است.**",
  "**خطر برای جنین: سندرم واریسلای مادرزادی، که فقط پیش از هفته‌ی ۲۰ رخ می‌دهد.**",
  "**و در این بیمار با ۲۴ هفته بارداری، پنجره‌ی سندرم مادرزادی گذشته است.**",
 ],
 PEP_EN + [
  "A susceptible pregnant woman is one of the high-risk groups and prophylaxis is mandatory.",
  "WARNING, AND THE TIMING HERE MATCHES THE GUIDELINE EXACTLY: exposure precisely 7 days ago.",
  "So today is exactly the day to start aciclovir — neither earlier nor later.",
  "And the varicella vaccine is contraindicated in pregnancy because it is a live virus.",
  "So any option containing the vaccine is eliminated regardless of anything else.",
  "WARNING, THE RISK OF CHICKENPOX IN PREGNANCY HAS TWO PARTS that must not be confused.",
  "The risk to the mother: varicella pneumonia, which is more severe and more lethal in pregnancy.",
  "The risk to the fetus: congenital varicella syndrome, which occurs only before week 20.",
  "And in this patient at 24 weeks, the congenital-syndrome window has passed.",
 ],
 "**زن حامله ۲۴ هفته** که **۷ روز قبل** با کودک مبتلا به آبله‌مرغان **فعال** تماس "
 "داشته، **بدون سابقه‌ی ابتلا و بدون واکسن**.\n\n"
 "⚠️ **پاسخ: تجویز قرص آسیکلوویر — و زمان‌بندی این سؤال کاملاً با راهنمای امروز "
 "هم‌خوان است.**\n\n"
 "**متن می‌گوید تماس دقیقاً ۷ روز پیش بوده. یعنی امروز دقیقاً روز شروع آسیکلوویر "
 "است — نه زودتر، نه دیرتر.**\n\n"
 "**و چرا روز هفتم؟** چون کارآزمایی نشان داد **شروع فوری شکست می‌خورد** (۷۷٪ باز "
 "هم بیمار شدند) ولی **شروع روز هفتم مؤثر است** (فقط ۲۱٪). ⚠️ **آسیکلوویر باید در "
 "اوج تکثیر ویروس حاضر باشد، و آن اوج حدود روز هفتم است.**\n\n"
 "**و راهنمای امروز:** UKHSA و RCOG **آسیکلوویر خوراکی ۸۰۰ میلی‌گرم چهار بار در "
 "روز، از روز ۷ تا ۱۴ پس از تماس** را **انتخاب اول برای زن باردار مستعد در هر سن "
 "بارداری** کرده‌اند.\n\n"
 "**حالا چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**تجویز VZIG** — ⚠️ **گزینه‌ی وسوسه‌انگیز، و روزگاری پاسخ درست بود.** ولی امروز:\n\n"
 "**۱)** یک مطالعه نشان داد **تفاوت معناداری** میان VZIG و آسیکلوویر در پیشگیری "
 "وجود ندارد (۳۶٫۶٪ در برابر ۳۰٫۸٪).\n\n"
 "**۲)** **۱۰ درصد** دریافت‌کنندگان VZIG **درد محل تزریق** داشتند، در حالی که در "
 "گروه آسیکلوویر **هیچ عارضه‌ای** گزارش نشد.\n\n"
 "**۳)** و VZIG باید **ظرف ۹۶ ساعت** داده می‌شد — الان **۷ روز** گذشته است.\n\n"
 "**دو نوبت واکسن آبله‌مرغان** ❌ — ⚠️ **خطرناک: واکسن آبله‌مرغان یک ویروس زنده است "
 "و در بارداری مطلقاً کنتراندیکه است.**\n\n"
 "**VZIG + نوبت اول واکسن** ❌ — همان مشکل واکسن زنده.\n\n"
 "⚠️ **و حالا نکته‌ای که این سؤال نپرسیده ولی برای فهم کامل لازم است: خطر آبله‌مرغان "
 "در بارداری دو بخش دارد و نباید قاطی شوند.**\n\n"
 "**خطر برای مادر: پنومونی واریسلایی.** در بارداری **شدیدتر و کشنده‌تر** است، "
 "به‌ویژه در سه‌ماهه‌ی سوم. **این خطر در هر سن بارداری وجود دارد.**\n\n"
 "**خطر برای جنین: سندرم واریسلای مادرزادی.** اسکار پوستی، هیپوپلازی اندام، "
 "آسیب چشمی و مغزی. ⚠️ **ولی این فقط پیش از هفته‌ی ۲۰ رخ می‌دهد** (و بیشترین خطر "
 "میان هفته‌ی ۱۳ تا ۲۰).\n\n"
 "**این بیمار ۲۴ هفته است — یعنی پنجره‌ی سندرم مادرزادی گذشته. پس پروفیلاکسی اینجا "
 "عمدتاً برای محافظت از خودِ مادر است، نه جنین.**",
 "A WOMAN AT 24 WEEKS' GESTATION who was exposed 7 DAYS AGO to a child with ACTIVE chickenpox, with "
 "NO HISTORY OF THE DISEASE AND NO VACCINE.\n\n"
 "WARNING, THE ANSWER: ORAL ACICLOVIR — and this question's timing matches current guidance exactly.\n\n"
 "The stem says the exposure was precisely 7 days ago. So TODAY IS EXACTLY THE DAY TO START "
 "ACICLOVIR — neither earlier nor later.\n\n"
 "AND WHY DAY SEVEN? Because a trial showed IMMEDIATE START FAILS (77% still fell ill) while a "
 "DAY-SEVEN START WORKS (only 21%). WARNING, ACICLOVIR MUST BE PRESENT AT THE PEAK OF VIRAL "
 "REPLICATION, and that peak is around day seven.\n\n"
 "AND TODAY'S GUIDANCE: UKHSA and the RCOG make ORAL ACICLOVIR 800 mg FOUR TIMES DAILY FROM DAY 7 "
 "TO 14 the FIRST CHOICE for a susceptible pregnant woman AT ANY GESTATION.\n\n"
 "NOW WHY NOT THE OTHER THREE?\n\n"
 "GIVE VZIG — WARNING, a tempting option, and once the right answer. But today:\n\n"
 "1) A study found NO SIGNIFICANT DIFFERENCE between VZIG and aciclovir in prevention (36.6% versus "
 "30.8%).\n\n"
 "2) 10 PER CENT of VZIG recipients reported INJECTION-SITE PAIN, while the aciclovir group "
 "reported NO ADVERSE EFFECTS.\n\n"
 "3) And VZIG should have been given WITHIN 96 HOURS — 7 DAYS have now passed.\n\n"
 "TWO DOSES OF VARICELLA VACCINE — WARNING, DANGEROUS: the varicella vaccine is a LIVE VIRUS and is "
 "ABSOLUTELY CONTRAINDICATED IN PREGNANCY.\n\n"
 "VZIG PLUS A FIRST VACCINE DOSE — the same live-vaccine problem.\n\n"
 "WARNING, AND NOW A POINT THE QUESTION DOES NOT ASK BUT WHICH COMPLETES THE PICTURE: THE RISK OF "
 "CHICKENPOX IN PREGNANCY HAS TWO PARTS THAT MUST NOT BE CONFUSED.\n\n"
 "RISK TO THE MOTHER: VARICELLA PNEUMONIA. More severe and more lethal in pregnancy, especially in "
 "the third trimester. THIS RISK EXISTS AT ANY GESTATION.\n\n"
 "RISK TO THE FETUS: CONGENITAL VARICELLA SYNDROME. Skin scarring, limb hypoplasia, eye and brain "
 "damage. WARNING, BUT THIS OCCURS ONLY BEFORE WEEK 20 (with greatest risk between weeks 13 and 20).\n\n"
 "This patient is at 24 weeks — the congenital-syndrome window has passed. So prophylaxis here is "
 "mainly to protect THE MOTHER, not the fetus.",
 ["روزگاری پاسخ درست بود، ولی VZIG باید ظرف ۹۶ ساعت داده می‌شد و اکنون ۷ روز گذشته است.",
  "پاسخ صحیح — تماس دقیقاً ۷ روز پیش بوده، یعنی امروز روز شروع آسیکلوویر است.",
  "خطرناک — واکسن آبله‌مرغان ویروس زنده است و در بارداری مطلقاً کنتراندیکه است.",
  "این گزینه هم واکسن زنده دارد، که در بارداری ممنوع است."],
 ["Once the right answer, but VZIG should have been given within 96 hours and 7 days have passed.",
  "Correct — the exposure was exactly 7 days ago, so today is the day to start aciclovir.",
  "Dangerous — the varicella vaccine is a live virus and is absolutely contraindicated in pregnancy.",
  "This option also contains the live vaccine, which is forbidden in pregnancy."],
 "**سندرم واریسلای مادرزادی فقط پیش از هفته‌ی ۲۰؛ ولی خطر مادر در هر سن بارداری.**",
 "Congenital varicella syndrome only before week 20; but the maternal risk exists at any gestation.",
 [UKHSA, RCOG])

add("book:630", "case", "medium",
 "همان سناریو با تماس **هفته‌ی گذشته** ← باز هم **آسیکلوویر خوراکی**.",
 "The same scenario with exposure LAST WEEK: again ORAL ACICLOVIR.",
 PEP_FA + [
  "**این سؤال تکرار عمدی همان سناریوست، با یک گزینه‌ی وسوسه‌انگیز متفاوت.**",
  "⚠️ **گزینه‌ی «کنترل علائم و شروع درمان در صورت بروز تب» یک دام مهم است.**",
  "**آن گزینه در واقع می‌گوید: کاری نکن و منتظر بمان تا بیمار شود.**",
  "**ولی تمام هدف پروفیلاکسی، جلوگیری از بیماری است، نه درمان پس از وقوع.**",
  "**و در بارداری، پنومونی واریسلایی می‌تواند سریع و کشنده باشد.**",
  "⚠️ **پس انتظار کشیدن، فرصت پیشگیری را از دست می‌دهد و خطر را می‌پذیرد.**",
  "**تماس «هفته‌ی گذشته» یعنی حدود ۷ روز، که دقیقاً پنجره‌ی شروع آسیکلوویر است.**",
  "**و بارداری ۲۰ هفته، درست روی مرز پنجره‌ی سندرم واریسلای مادرزادی است.**",
 ],
 PEP_EN + [
  "This item deliberately repeats the same scenario with a different tempting option.",
  "WARNING: 'monitor and start treatment if fever develops' IS AN IMPORTANT TRAP.",
  "That option effectively says: do nothing and wait until she becomes ill.",
  "But the whole point of prophylaxis is to PREVENT disease, not to treat it after the fact.",
  "And in pregnancy, varicella pneumonia can be rapid and lethal.",
  "WARNING, SO WAITING FORFEITS THE CHANCE TO PREVENT and accepts the risk.",
  "Exposure 'last week' means about 7 days, exactly the aciclovir window.",
  "And 20 weeks' gestation is right at the boundary of the congenital varicella syndrome window.",
 ],
 "**خانم باردار ۲۰ هفته** که **هفته‌ی گذشته** در جشن تولد فرزندش با کودکی تماس داشته "
 "که **بعداً معلوم شد آبله‌مرغان داشته**. او **سابقه‌ی ابتلا ندارد**.\n\n"
 "⚠️ **پاسخ: شروع آسیکلوویر خوراکی. و این سؤال تکرار عمدی سناریوی قبلی است، ولی با "
 "یک گزینه‌ی وسوسه‌انگیز متفاوت.**\n\n"
 "**زمان‌بندی: «هفته‌ی گذشته» یعنی حدود ۷ روز — دقیقاً پنجره‌ی شروع آسیکلوویر.**\n\n"
 "**و سن بارداری ۲۰ هفته: درست روی مرز پنجره‌ی سندرم واریسلای مادرزادی** (که تا "
 "هفته‌ی ۲۰ ادامه دارد). پس اینجا **هم خطر جنینی و هم خطر مادری** مطرح است.\n\n"
 "⚠️ **و حالا دام واقعی این سؤال، که با سؤال قبلی فرق دارد:**\n\n"
 "> **«توصیه به کنترل علائم حیاتی و شروع درمان فوری در صورت بروز تب»**\n\n"
 "**چرا وسوسه‌انگیز است؟** چون **محتاطانه و معقول** به‌نظر می‌رسد: مراقب باش، و اگر "
 "بیمار شد سریع درمان کن.\n\n"
 "⚠️ **چرا غلط است؟ چون این گزینه در واقع می‌گوید: هیچ کاری نکن و منتظر بمان تا "
 "بیمار شود.**\n\n"
 "**و این با کل فلسفه‌ی پروفیلاکسی در تضاد است:**\n\n"
 "**هدف پروفیلاکسی، جلوگیری از بیماری است — نه درمان پس از وقوع.** اگر قرار بود "
 "منتظر بمانیم، اصلاً چیزی به نام «پروفیلاکسی پس از تماس» وجود نداشت.\n\n"
 "**و در بارداری، این انتظار خطرناک‌تر است:** ⚠️ **پنومونی واریسلایی در بارداری "
 "می‌تواند سریع پیشرفت کند و کشنده باشد.** تا وقتی تب ظاهر شود، ویروس از قبل منتشر "
 "شده است.\n\n"
 "**و دو گزینه‌ی دیگر؟**\n\n"
 "**VZIG** — گزینه‌ی معقولی بود، ولی پنجره‌ی ۹۶ ساعته گذشته و امروز آسیکلوویر انتخاب "
 "اول است.\n\n"
 "**واکسن فوری آبله‌مرغان** ❌ — ⚠️ **خطرناک: ویروس زنده در بارداری مطلقاً ممنوع "
 "است.**\n\n"
 "⚠️ **و یک نکته‌ی عملی برای این بیمار: پیش از شروع، باید سرولوژی VZV بررسی شود.** "
 "**حدود ۹۰ درصد بالغان، حتی آن‌هایی که سابقه‌ی ابتلا به یاد نمی‌آورند، در واقع "
 "ایمن‌اند.** اگر IgG مثبت باشد، **هیچ اقدامی لازم نیست** و می‌توان بیمار را کاملاً "
 "مطمئن کرد. **این نکته هم اضطراب بی‌مورد را کم می‌کند و هم از درمان غیرضروری "
 "جلوگیری می‌کند.**",
 "A WOMAN AT 20 WEEKS' GESTATION who LAST WEEK was at her child's birthday party with a child who "
 "TURNED OUT TO HAVE CHICKENPOX. She HAS NO HISTORY OF THE DISEASE.\n\n"
 "WARNING, THE ANSWER: START ORAL ACICLOVIR. This deliberately repeats the previous scenario but "
 "with a different tempting option.\n\n"
 "TIMING: 'last week' means about 7 days — exactly the aciclovir window.\n\n"
 "AND 20 WEEKS' GESTATION sits right at the boundary of the congenital varicella syndrome window "
 "(which extends to week 20). So BOTH THE FETAL AND THE MATERNAL RISK are relevant here.\n\n"
 "WARNING, AND NOW THE REAL TRAP, which differs from the previous question:\n\n"
 "> 'MONITOR HER VITAL SIGNS AND START TREATMENT PROMPTLY IF FEVER DEVELOPS'\n\n"
 "WHY IS IT TEMPTING? Because it sounds CAUTIOUS AND SENSIBLE: watch her, and treat quickly if she "
 "falls ill.\n\n"
 "WARNING, WHY IS IT WRONG? BECAUSE THAT OPTION EFFECTIVELY SAYS: DO NOTHING AND WAIT UNTIL SHE "
 "BECOMES ILL.\n\n"
 "And that contradicts the entire philosophy of prophylaxis:\n\n"
 "THE PURPOSE OF PROPHYLAXIS IS TO PREVENT DISEASE, NOT TO TREAT IT AFTERWARDS. If waiting were "
 "acceptable, there would be no such thing as post-exposure prophylaxis.\n\n"
 "AND IN PREGNANCY THE WAIT IS MORE DANGEROUS: WARNING, VARICELLA PNEUMONIA IN PREGNANCY CAN "
 "PROGRESS RAPIDLY AND BE FATAL. By the time fever appears the virus has already disseminated.\n\n"
 "AND THE OTHER TWO?\n\n"
 "VZIG — a reasonable option, but the 96-hour window has passed and aciclovir is today's first "
 "choice.\n\n"
 "IMMEDIATE VARICELLA VACCINE — WARNING, DANGEROUS: a live virus is absolutely forbidden in "
 "pregnancy.\n\n"
 "WARNING, AND A PRACTICAL POINT FOR THIS PATIENT: BEFORE STARTING, VZV SEROLOGY SHOULD BE CHECKED. "
 "ABOUT 90 PER CENT OF ADULTS, EVEN THOSE WHO RECALL NO INFECTION, ARE IN FACT IMMUNE. If IgG is "
 "positive, NO ACTION IS NEEDED and the patient can be fully reassured. That both reduces needless "
 "anxiety and prevents unnecessary treatment.",
 ["VZIG معقول بود ولی پنجره‌ی ۹۶ ساعته گذشته و امروز آسیکلوویر انتخاب اول است.",
  "دام مهم — این گزینه یعنی هیچ کاری نکن و منتظر بمان تا بیمار شود، که با هدف پروفیلاکسی در تضاد است.",
  "پاسخ صحیح — تماس حدود ۷ روز پیش بوده و این دقیقاً پنجره‌ی شروع آسیکلوویر است.",
  "خطرناک — واکسن آبله‌مرغان ویروس زنده است و در بارداری مطلقاً ممنوع است."],
 ["VZIG was reasonable but the 96-hour window has passed and aciclovir is today's first choice.",
  "An important trap — this means do nothing and wait until she is ill, contradicting the purpose of prophylaxis.",
  "Correct — exposure was about 7 days ago, which is exactly the aciclovir window.",
  "Dangerous — the varicella vaccine is a live virus and is absolutely forbidden in pregnancy."],
 "**پروفیلاکسی یعنی جلوگیری، نه انتظار برای بیمار شدن و بعد درمان.**",
 "Prophylaxis means prevention, not waiting for illness and treating afterwards.",
 [UKHSA, RCOG])

add("book:634", "case", "hard",
 "**زونای** مادر در هفته‌ی آخر ← **آسیکلوویر برای مادر**؛ نوزاد VZIG لازم ندارد.",
 "MATERNAL ZOSTER in the last week of pregnancy: ACICLOVIR FOR THE MOTHER; the neonate needs no VZIG.",
 PEP_FA + [
  "**این سؤال ظریف‌ترین سؤال بلوک است، چون تشخیص خودش نصف پاسخ است.**",
  "⚠️ **ضایعات وزیکولوپاپولر در ناحیه‌ی شکم و پهلو، یعنی یک درماتوم — یعنی زونا، نه آبله‌مرغان.**",
  "**و تفاوت زونا با آبله‌مرغان در بارداری، تفاوت میان دو دنیاست.**",
  "**آبله‌مرغان یعنی عفونت اولیه: مادر آنتی‌بادی ندارد و ویرمی دارد.**",
  "⚠️ **زونا یعنی فعال شدن مجدد: مادر از قبل آنتی‌بادی دارد و آن را به جنین منتقل کرده است.**",
  "**پس نوزاد با آنتی‌بادی مادری محافظت می‌شود و در خطر آبله‌مرغان منتشر نوزادی نیست.**",
  "**و همین است که VZIG برای نوزاد را غیرضروری می‌کند.**",
  "**پنجره‌ی خطرناک نوزادی فقط برای آبله‌مرغان مادر است: ۵ روز پیش تا ۲ روز پس از زایمان.**",
  "⚠️ **و درمان مادر همچنان لازم است، تا شدت زونا کم شود و نورالژی پس از آن کاهش یابد.**",
 ],
 PEP_EN + [
  "This is the subtlest question in the block, because the diagnosis is half the answer.",
  "WARNING: vesiculopapular lesions on the abdomen and flank mean ONE DERMATOME — that is ZOSTER, not chickenpox.",
  "And the difference between zoster and chickenpox in pregnancy is the difference between two worlds.",
  "Chickenpox means PRIMARY infection: the mother has no antibody and is viraemic.",
  "WARNING, ZOSTER MEANS REACTIVATION: the mother already has antibody and has passed it to the fetus.",
  "So the neonate is protected by maternal antibody and is not at risk of disseminated neonatal varicella.",
  "And that is what makes VZIG for the neonate unnecessary.",
  "The dangerous neonatal window applies only to maternal CHICKENPOX: 5 days before to 2 days after delivery.",
  "WARNING, AND TREATING THE MOTHER IS STILL NEEDED, to reduce the severity of zoster and later neuralgia.",
 ],
 "**خانم باردار در هفته‌ی آخر بارداری** با **ضایعات دردناک وزیکولوپاپولر در ناحیه‌ی "
 "شکم و پهلو**.\n\n"
 "⚠️ **این ظریف‌ترین سؤال بلوک است، چون تشخیص خودش نصف پاسخ است.**\n\n"
 "**اول: این آبله‌مرغان است یا زونا؟**\n\n"
 "**«ناحیه‌ی شکم و پهلو» — یعنی یک ناحیه‌ی محدود، یک درماتوم.** ⚠️ **این زوناست، نه "
 "آبله‌مرغان.** آبله‌مرغان **منتشر** است: صورت، تنه، اندام‌ها، مخاط. زونا **محدود به "
 "یک درماتوم** است و **از خط وسط عبور نمی‌کند**.\n\n"
 "**و «دردناک» بودن هم به نفع زوناست: زونا دردناک است، آبله‌مرغان بیشتر خارش‌دار.**\n\n"
 "⚠️ **و حالا مهم‌ترین مفهوم این سؤال: تفاوت زونا با آبله‌مرغان در بارداری، تفاوت "
 "میان دو دنیاست.**\n\n"
 "**آبله‌مرغان (عفونت اولیه):** مادر **آنتی‌بادی ندارد**. ویروس در خونش **منتشر** "
 "می‌شود (ویرمی) و می‌تواند به جنین برسد. ⚠️ **و اگر زایمان در پنجره‌ی خطرناک رخ دهد "
 "— از ۵ روز پیش تا ۲ روز پس از شروع راش مادر — نوزاد در معرض آبله‌مرغان منتشر "
 "نوزادی است، که مرگ‌ومیر بالایی دارد.** چرا؟ چون نوزاد **هم ویروس را می‌گیرد و هم "
 "فرصت نمی‌کند آنتی‌بادی مادری بگیرد**.\n\n"
 "**زونا (فعال شدن مجدد):** ⚠️ **مادر از قبل آنتی‌بادی دارد** — به همین دلیل است که "
 "بیماری‌اش محدود به یک درماتوم مانده و منتشر نشده. **و آن آنتی‌بادی از هفته‌ها پیش "
 "از طریق جفت به جنین منتقل شده است.**\n\n"
 "**پس نوزاد از قبل محافظت‌شده است و VZIG لازم ندارد.**\n\n"
 "**حالا گزینه‌ها:**\n\n"
 "**شروع آسیکلوویر خوراکی جهت مادر** ✅ — درست. مادر **بیمار است** و درمان لازم "
 "دارد: **کاهش شدت، تسریع بهبود، و کاهش نورالژی پس از هرپس**.\n\n"
 "**تزریق VZIG به نوزاد** ❌ — غیرضروری؛ نوزاد آنتی‌بادی مادری دارد.\n\n"
 "**VZIG به مادر و نوزاد** ❌ — ⚠️ **بی‌معنی برای مادر: او خودش آنتی‌بادی دارد** (به "
 "همین دلیل زونا گرفته نه آبله‌مرغان). **دادن آنتی‌بادی به کسی که آنتی‌بادی دارد، "
 "کار بیهوده‌ای است.**\n\n"
 "**آسیکلوویر وریدی برای مادر و نوزاد** ❌ — **بیش از حد**. زونای موضعی در فرد "
 "ایمن‌سالم **خوراکی** درمان می‌شود؛ وریدی برای **زونای منتشر یا چشمی یا در فرد "
 "نقص‌ایمنی** است. و نوزاد **اصلاً درمان لازم ندارد**.\n\n"
 "⚠️ **قاعده‌ی نهایی که باید حفظ شود: پنجره‌ی خطرناک نوزادی (۵ روز پیش تا ۲ روز پس "
 "از زایمان) فقط برای آبله‌مرغان مادر است. زونای مادر هرگز چنین خطری ندارد.**",
 "A WOMAN IN THE LAST WEEK OF PREGNANCY with PAINFUL VESICULOPAPULAR LESIONS ON THE ABDOMEN AND "
 "FLANK.\n\n"
 "WARNING, THIS IS THE SUBTLEST QUESTION IN THE BLOCK, because the diagnosis is half the answer.\n\n"
 "FIRST: IS THIS CHICKENPOX OR ZOSTER?\n\n"
 "'THE ABDOMEN AND FLANK' — a limited area, ONE DERMATOME. WARNING, THIS IS ZOSTER, NOT CHICKENPOX. "
 "Chickenpox is WIDESPREAD: face, trunk, limbs, mucosa. Zoster is CONFINED TO ONE DERMATOME and "
 "DOES NOT CROSS THE MIDLINE.\n\n"
 "And its being PAINFUL also favours zoster: zoster is painful, chickenpox mainly itchy.\n\n"
 "WARNING, AND NOW THE KEY CONCEPT: THE DIFFERENCE BETWEEN ZOSTER AND CHICKENPOX IN PREGNANCY IS "
 "THE DIFFERENCE BETWEEN TWO WORLDS.\n\n"
 "CHICKENPOX (primary infection): the mother HAS NO ANTIBODY. The virus DISSEMINATES in her blood "
 "(viraemia) and can reach the fetus. WARNING, AND IF DELIVERY FALLS IN THE DANGEROUS WINDOW — from "
 "5 DAYS BEFORE TO 2 DAYS AFTER the onset of the mother's rash — THE NEONATE IS AT RISK OF "
 "DISSEMINATED NEONATAL VARICELLA, which carries high mortality. Why? Because the neonate RECEIVES "
 "THE VIRUS BUT HAS NO TIME TO RECEIVE MATERNAL ANTIBODY.\n\n"
 "ZOSTER (reactivation): WARNING, THE MOTHER ALREADY HAS ANTIBODY — which is precisely why her "
 "disease stayed confined to one dermatome instead of disseminating. AND THAT ANTIBODY CROSSED THE "
 "PLACENTA TO THE FETUS WEEKS AGO.\n\n"
 "SO THE NEONATE IS ALREADY PROTECTED AND NEEDS NO VZIG.\n\n"
 "NOW THE OPTIONS:\n\n"
 "START ORAL ACICLOVIR FOR THE MOTHER — correct. THE MOTHER IS ILL and needs treatment: reduced "
 "severity, faster healing, and less post-herpetic neuralgia.\n\n"
 "GIVE VZIG TO THE NEONATE — unnecessary; the neonate has maternal antibody.\n\n"
 "VZIG TO MOTHER AND NEONATE — WARNING, MEANINGLESS FOR THE MOTHER: SHE ALREADY HAS ANTIBODY (which "
 "is why she has zoster and not chickenpox). GIVING ANTIBODY TO SOMEONE WHO ALREADY HAS IT IS "
 "POINTLESS.\n\n"
 "INTRAVENOUS ACICLOVIR FOR MOTHER AND NEONATE — EXCESSIVE. Localised zoster in an immunocompetent "
 "person is treated ORALLY; intravenous therapy is for DISSEMINATED OR OPHTHALMIC zoster or the "
 "IMMUNOCOMPROMISED. And the neonate NEEDS NO TREATMENT AT ALL.\n\n"
 "WARNING, THE FINAL RULE TO MEMORISE: THE DANGEROUS NEONATAL WINDOW (5 DAYS BEFORE TO 2 DAYS AFTER "
 "DELIVERY) APPLIES ONLY TO MATERNAL CHICKENPOX. MATERNAL ZOSTER NEVER CARRIES THAT RISK.",
 ["پاسخ صحیح — این زوناست نه آبله‌مرغان؛ مادر درمان لازم دارد و نوزاد آنتی‌بادی مادری دارد.",
  "غیرضروری — نوزاد از قبل با آنتی‌بادی مادری محافظت شده است، چون مادر زونا دارد نه آبله‌مرغان.",
  "بی‌معنی برای مادر — او خودش آنتی‌بادی دارد و به همین دلیل زونا گرفته نه آبله‌مرغان.",
  "بیش از حد — زونای موضعی در فرد ایمن‌سالم خوراکی درمان می‌شود و نوزاد درمان لازم ندارد."],
 ["Correct — this is zoster, not chickenpox; the mother needs treatment and the neonate has maternal antibody.",
  "Unnecessary — the neonate is already protected by maternal antibody, because the mother has zoster not chickenpox.",
  "Meaningless for the mother — she already has antibody, which is why she has zoster rather than chickenpox.",
  "Excessive — localised zoster in an immunocompetent person is treated orally, and the neonate needs no treatment."],
 "**زونای مادر یعنی مادر آنتی‌بادی دارد — پس نوزاد از قبل محافظت‌شده است.**",
 "Maternal zoster means the mother has antibody, so the neonate is already protected.",
 [UKHSA, RCOG])

add("book:637", "case", "medium",
 "زونای مادر در درماتوم L1-L3 پس از زایمان ← **نیازی به اقدام خاصی نیست**.",
 "Maternal zoster in the L1-L3 dermatomes after delivery: NO SPECIFIC ACTION IS NEEDED.",
 PEP_FA + [
  "**این سؤال قرینه‌ی سؤال قبلی است و همان اصل را از زاویه‌ی دیگری می‌آزماید.**",
  "⚠️ **درماتوم L1 تا L3 صریحاً ذکر شده — پس تشخیص زونا قطعی است، نه آبله‌مرغان.**",
  "**و مادر «به‌غیر از ضایعات، علامت دیگری ندارد» — یعنی بیماری موضعی و خفیف است.**",
  "**پس نوزاد با آنتی‌بادی مادری محافظت شده و هیچ خطری ندارد.**",
  "**تنها احتیاط عملی: پوشاندن ضایعات، چون تماس مستقیم با مایع وزیکول می‌تواند منتقل شود.**",
  "⚠️ **ولی آن انتقال آبله‌مرغان می‌دهد، نه زونا — و نوزاد آنتی‌بادی مادری دارد.**",
  "**و شیردهی هم منعی ندارد، به‌شرطی که ضایعه روی پستان نباشد.**",
 ],
 PEP_EN + [
  "This mirrors the previous question and tests the same principle from another angle.",
  "WARNING: THE L1 TO L3 DERMATOMES ARE STATED EXPLICITLY — so the diagnosis is certainly zoster, not chickenpox.",
  "And the mother 'has no symptom other than the lesions' — so the disease is localised and mild.",
  "So the neonate is protected by maternal antibody and is at no risk.",
  "The only practical precaution: cover the lesions, because direct contact with vesicle fluid can transmit.",
  "WARNING, BUT THAT TRANSMISSION CAUSES CHICKENPOX, NOT ZOSTER — and the neonate has maternal antibody.",
  "And breastfeeding is permitted, provided no lesion is on the breast.",
 ],
 "**در بخش زنان، مادری یک روز پس از زایمان** دچار **ضایعات وزیکولر دردناک در "
 "درماتوم‌های L1 تا L3** شده، و **به‌غیر از ضایعات فوق علامت دیگری ندارد**.\n\n"
 "⚠️ **پاسخ: نیازی به اقدام خاصی نیست. و این سؤال قرینه‌ی سؤال قبلی است.**\n\n"
 "**اول تشخیص: متن صریحاً کلمه‌ی «درماتوم» را آورده و محدوده‌ی L1 تا L3 را مشخص "
 "کرده.** ⚠️ **پس این قطعاً زوناست، نه آبله‌مرغان.** طراح این‌بار هیچ ابهامی نگذاشته "
 "است.\n\n"
 "**و جمله‌ی «علامت دیگری ندارد» هم مهم است: یعنی بیماری موضعی و خفیف است، بدون "
 "انتشار و بدون علائم سیستمیک.**\n\n"
 "**حالا منطق را اجرا کنید:**\n\n"
 "**مادر زونا دارد → مادر از قبل آنتی‌بادی ضد VZV دارد → آن آنتی‌بادی از طریق جفت به "
 "نوزاد منتقل شده است → نوزاد محافظت‌شده است.**\n\n"
 "⚠️ **پس نوزاد در خطر آبله‌مرغان منتشر نوزادی نیست، و هیچ‌کدام از مداخلات پیشنهادی "
 "لازم نیست.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**IVIG در اسرع وقت** ❌ و **IVIG ظرف ۲ روز** ❌ — هر دو یک اشکال دارند: **دادن "
 "آنتی‌بادی به نوزادی که از قبل آنتی‌بادی مادری دارد.** ضمناً IVIG یک فرآورده‌ی خونی "
 "است با هزینه و خطر خاص خودش.\n\n"
 "**آسیکلوویر ظرف ۳ روز آینده** ❌ — **درمان ضدویروسی برای نوزادی که بیمار نیست و "
 "در خطر هم نیست.** آسیکلوویر در نوزاد فقط وقتی است که **هرپس نوزادی** مشکوک باشد یا "
 "مادر **آبله‌مرغان** (نه زونا) در پنجره‌ی خطرناک گرفته باشد.\n\n"
 "⚠️ **و حالا یک نکته‌ی عملی مهم که سؤال نپرسیده: «نیازی به اقدام خاصی نیست» به "
 "معنای «هیچ احتیاطی لازم نیست» نیست.**\n\n"
 "**مایع وزیکول‌های زونا حاوی ویروس زنده است، و تماس مستقیم با آن می‌تواند به فرد "
 "مستعد منتقل شود** — ⚠️ **و در او آبله‌مرغان بسازد، نه زونا** (چون زونا فقط از "
 "فعال شدن مجدد ویروس خودِ فرد می‌آید).\n\n"
 "**پس احتیاط عملی: ضایعات را بپوشانید و بهداشت دست را رعایت کنید.** و **شیردهی "
 "منعی ندارد**، مگر آنکه ضایعه‌ای روی خودِ پستان باشد.",
 "IN THE OBSTETRIC WARD, A MOTHER ONE DAY AFTER DELIVERY develops PAINFUL VESICULAR LESIONS IN THE "
 "L1 TO L3 DERMATOMES, and HAS NO SYMPTOM OTHER THAN THOSE LESIONS.\n\n"
 "WARNING, THE ANSWER: NO SPECIFIC ACTION IS NEEDED. This mirrors the previous question.\n\n"
 "FIRST THE DIAGNOSIS: the stem uses the word 'DERMATOME' explicitly and specifies L1 to L3. "
 "WARNING, SO THIS IS CERTAINLY ZOSTER, NOT CHICKENPOX. The examiner has left no ambiguity this "
 "time.\n\n"
 "And 'no other symptom' matters too: the disease is LOCALISED AND MILD, without dissemination or "
 "systemic features.\n\n"
 "NOW RUN THE LOGIC:\n\n"
 "THE MOTHER HAS ZOSTER, SO SHE ALREADY HAS ANTI-VZV ANTIBODY, SO THAT ANTIBODY CROSSED THE "
 "PLACENTA TO THE NEONATE, SO THE NEONATE IS PROTECTED.\n\n"
 "WARNING, SO THE NEONATE IS NOT AT RISK OF DISSEMINATED NEONATAL VARICELLA, and none of the "
 "proposed interventions is needed.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "IVIG AS SOON AS POSSIBLE and IVIG WITHIN 2 DAYS — both share one flaw: GIVING ANTIBODY TO A "
 "NEONATE WHO ALREADY HAS MATERNAL ANTIBODY. IVIG is also a blood product with its own cost and "
 "risk.\n\n"
 "ACICLOVIR WITHIN THE NEXT 3 DAYS — ANTIVIRAL TREATMENT FOR A NEONATE WHO IS NEITHER ILL NOR AT "
 "RISK. Aciclovir in a neonate is for suspected NEONATAL HERPES, or when the mother had CHICKENPOX "
 "(not zoster) within the dangerous window.\n\n"
 "WARNING, AND NOW AN IMPORTANT PRACTICAL POINT THE QUESTION DOES NOT ASK: 'NO SPECIFIC ACTION' "
 "DOES NOT MEAN 'NO PRECAUTIONS'.\n\n"
 "ZOSTER VESICLE FLUID CONTAINS LIVE VIRUS, and direct contact can transmit it to a susceptible "
 "person — WARNING, CAUSING CHICKENPOX IN THEM, NOT ZOSTER (because zoster arises only from "
 "reactivation of a person's own virus).\n\n"
 "SO THE PRACTICAL PRECAUTION: COVER THE LESIONS AND OBSERVE HAND HYGIENE. And BREASTFEEDING IS "
 "PERMITTED unless a lesion is on the breast itself.",
 ["دادن آنتی‌بادی به نوزادی که از قبل آنتی‌بادی مادری دارد، بی‌فایده است.",
  "آسیکلوویر برای نوزادی که نه بیمار است و نه در خطر، هیچ اندیکاسیونی ندارد.",
  "همان اشکال — IVIG برای نوزاد محافظت‌شده لازم نیست و یک فرآورده‌ی خونی است.",
  "پاسخ صحیح — زونای مادر یعنی آنتی‌بادی مادری از قبل به نوزاد رسیده و او محافظت‌شده است."],
 ["Giving antibody to a neonate who already has maternal antibody is pointless.",
  "Aciclovir has no indication for a neonate who is neither ill nor at risk.",
  "The same flaw — IVIG is unnecessary for a protected neonate and is a blood product.",
  "Correct — maternal zoster means maternal antibody has already reached the neonate, who is protected."],
 "**زونای مادر = آنتی‌بادی مادری موجود = نوزاد محافظت‌شده. ولی ضایعات را بپوشانید.**",
 "Maternal zoster means maternal antibody is present and the neonate is protected — but cover the lesions.",
 [UKHSA, RCOG])


# =============================================== MEASLES / MUMPS / RUBELLA
add("book:641", "case", "easy",
 "سه C + راش از **پیشانی** به پایین + کونژنکتیویت ← **سرخک**.",
 "The three Cs, a rash spreading DOWNWARD FROM THE FOREHEAD, and conjunctivitis: MEASLES.",
 MMR_FA + [
  "**این سؤال هر جزء پیش‌درآمد سرخک را صریحاً آورده و جای حدس نمی‌گذارد.**",
  "⚠️ **سرفه‌ی خشک، کوریزا و فتوفوبی — یعنی هر سه C، به‌علاوه‌ی تب ۳۹ درجه.**",
  "**و ترتیب زمانی کلاسیک است: پیش‌درآمد پنج‌روزه، سپس راش از سه روز پیش.**",
  "**راش سرخک همیشه پس از چند روز پیش‌درآمد می‌آید، نه هم‌زمان با شروع تب.**",
  "**و مسیر انتشار قاطع است: از پیشانی شروع می‌شود و به تنه و اندام‌ها می‌رود.**",
  "⚠️ **این «از سر به پایین» با سرخجه مشترک است، ولی شدت و سه C آن‌ها را جدا می‌کند.**",
  "**فتوفوبی هم توضیح دارد: کونژنکتیویت سرخک شدید است و به نور حساسیت می‌دهد.**",
 ],
 MMR_EN + [
  "This stem gives every part of the measles prodrome explicitly and leaves nothing to guess.",
  "WARNING: dry cough, coryza and photophobia — all three Cs, plus a temperature of 39 degrees.",
  "And the time sequence is classic: a five-day prodrome, then the rash three days ago.",
  "The measles rash always follows several days of prodrome, never appearing with the fever's onset.",
  "And the direction of spread is decisive: it begins on the forehead and moves to trunk and limbs.",
  "WARNING, THAT HEAD-TO-TOE SPREAD IS SHARED WITH RUBELLA, but the severity and the three Cs separate them.",
  "The photophobia is explained too: measles conjunctivitis is severe and causes light sensitivity.",
 ],
 "**دانشجوی ۲۳ ساله** با **سرفه‌های خشک، کوریزا، فتوفوبی و کسالت شدید از پنج روز "
 "قبل**، و **از سه روز قبل راش ماکولوپاپولر قرمز که از پیشانی شروع شده و سپس به تنه "
 "و اندام‌ها گسترش یافته**. در معاینه **تب ۳۹ درجه** و **کونژنکتیویت دوطرفه**.\n\n"
 "⚠️ **پاسخ: سرخک. و این سؤال هر جزء تشخیص را صریحاً آورده است.**\n\n"
 "**سه C را در متن پیدا کنید:**\n\n"
 "**Cough (سرفه)** ✅ «سرفه‌های خشک»\n\n"
 "**Coryza (آبریزش بینی)** ✅ «کوریزا»\n\n"
 "**Conjunctivitis (التهاب ملتحمه)** ✅ «کونژنکتیویت دوطرفه» — و **فتوفوبی** هم از "
 "همین می‌آید، چون کونژنکتیویت سرخک شدید است.\n\n"
 "**به‌علاوه‌ی تب بالا: ۳۹ درجه.**\n\n"
 "⚠️ **و حالا ترتیب زمانی، که به‌اندازه‌ی خودِ علائم مهم است:**\n\n"
 "**پیش‌درآمد پنج‌روزه، سپس راش از سه روز پیش.** یعنی راش **دو روز پس از شروع "
 "علائم** آمده است. **این کاملاً کلاسیک است: در سرخک، راش همیشه پس از چند روز "
 "پیش‌درآمد می‌آید، نه هم‌زمان با تب.**\n\n"
 "**و مسیر انتشار قاطع است: «از پیشانی شروع شده و سپس به تنه و اندام‌ها گسترش "
 "یافته» — یعنی از سر به پایین.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**سرخجه** — ⚠️ نزدیک‌ترین رقیب، چون **آن هم از سر به پایین** پخش می‌شود. ولی سه "
 "تفاوت دارد: **۱)** تب **بسیار خفیف‌تر** (اینجا ۳۹ درجه است). **۲)** **سه C ندارد** "
 "— نه سرفه‌ی برجسته، نه کونژنکتیویت شدید. **۳)** **لنفادنوپاتی پس‌گوشی و پس‌سری** "
 "دارد که اینجا ذکر نشده.\n\n"
 "**اریتم انفکشیوزوم (بیماری پنجم)** — راش کلاسیکش **«گونه‌ی سیلی‌خورده»** است: "
 "قرمزی شدید گونه‌ها، سپس راش توری‌شکل روی اندام‌ها. **الگویش کاملاً متفاوت است** و "
 "کودک معمولاً **پس از قطع تب** راش می‌گیرد.\n\n"
 "**روزئولا اینفانتوم** — ⚠️ **الگوی زمانی‌اش وارونه است**: تب بالای سه روزه که "
 "**ناگهان قطع می‌شود**، و **سپس** راش ظاهر می‌شود. اینجا بیمار **هم‌زمان تب ۳۹ و "
 "راش** دارد. ضمناً روزئولا بیماری **شیرخواران** است، نه دانشجوی ۲۳ ساله.\n\n"
 "⚠️ **و یک نکته‌ی بالینی مهم: این بیمار «مخاطات دهان به‌شدت دهیدراته» دارد.** در "
 "سرخک بالغ، **دهیدراتاسیون** یک عارضه‌ی جدی است و **درمان حمایتی با مایعات** لازم "
 "است. و **ویتامین A** تنها مداخله‌ای است که **مرگ‌ومیر سرخک را کاهش می‌دهد**.",
 "A 23-YEAR-OLD STUDENT with a DRY COUGH, CORYZA, PHOTOPHOBIA AND SEVERE MALAISE FOR FIVE DAYS, and "
 "FOR THREE DAYS a red maculopapular rash that BEGAN ON THE FOREHEAD and spread to trunk and limbs. "
 "On examination, a TEMPERATURE OF 39 DEGREES and BILATERAL CONJUNCTIVITIS.\n\n"
 "WARNING, THE ANSWER: MEASLES. This stem states every component of the diagnosis explicitly.\n\n"
 "FIND THE THREE Cs IN THE TEXT:\n\n"
 "COUGH — 'dry cough'.\n\n"
 "CORYZA — 'coryza'.\n\n"
 "CONJUNCTIVITIS — 'bilateral conjunctivitis' — and the PHOTOPHOBIA comes from it, because measles "
 "conjunctivitis is severe.\n\n"
 "Plus HIGH FEVER: 39 degrees.\n\n"
 "WARNING, AND NOW THE TIME SEQUENCE, as important as the symptoms themselves:\n\n"
 "A FIVE-DAY PRODROME, THEN THE RASH THREE DAYS AGO. So the rash came TWO DAYS AFTER symptom onset. "
 "THAT IS ENTIRELY CLASSIC: IN MEASLES THE RASH ALWAYS FOLLOWS SEVERAL DAYS OF PRODROME, never "
 "appearing with the fever.\n\n"
 "AND THE DIRECTION OF SPREAD IS DECISIVE: 'began on the forehead then spread to trunk and limbs' — "
 "head to toe.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "RUBELLA — WARNING, the closest competitor, because IT TOO spreads head to toe. But three "
 "differences: 1) MUCH MILDER FEVER (here it is 39). 2) NO THREE Cs — no prominent cough, no severe "
 "conjunctivitis. 3) POSTAURICULAR AND SUBOCCIPITAL LYMPHADENOPATHY, not mentioned here.\n\n"
 "ERYTHEMA INFECTIOSUM (fifth disease) — its classic rash is the SLAPPED CHEEK: intense facial "
 "redness, then a lacy rash on the limbs. A COMPLETELY DIFFERENT PATTERN, and the child usually "
 "develops the rash AFTER the fever ends.\n\n"
 "ROSEOLA INFANTUM — WARNING, ITS TIME PATTERN IS INVERTED: three days of high fever that BREAKS "
 "ABRUPTLY, and THEN the rash appears. Here the patient has FEVER OF 39 AND RASH TOGETHER. Roseola "
 "is also a disease of INFANTS, not of a 23-year-old student.\n\n"
 "WARNING, AND AN IMPORTANT CLINICAL POINT: this patient has 'severely dehydrated oral mucosa'. In "
 "adult measles DEHYDRATION is a serious complication and SUPPORTIVE FLUID THERAPY is needed. And "
 "VITAMIN A is the only intervention that REDUCES MEASLES MORTALITY.",
 ["نزدیک‌ترین رقیب — ولی سرخجه تب بسیار خفیف‌تری دارد و سه C ندارد.",
  "پاسخ صحیح — سه C به‌علاوه‌ی تب بالا و راش از پیشانی به پایین، تابلوی قطعی سرخک است.",
  "اریتم انفکشیوزوم راش «گونه‌ی سیلی‌خورده» و سپس توری‌شکل می‌دهد، با الگوی کاملاً متفاوت.",
  "در روزئولا راش پس از قطع ناگهانی تب می‌آید و بیماری شیرخواران است، نه بالغ ۲۳ ساله."],
 ["The closest competitor — but rubella has a much milder fever and lacks the three Cs.",
  "Correct — the three Cs with high fever and a rash spreading down from the forehead is definitive measles.",
  "Erythema infectiosum gives a slapped-cheek then lacy rash, an entirely different pattern.",
  "In roseola the rash follows an abrupt defervescence, and it is a disease of infants, not a 23-year-old."],
 "**سه C + تب بالا + راش از سر به پایین = سرخک.**",
 "Three Cs plus high fever plus a head-to-toe rash means measles.",
 [CDCMEASLES, H])

add("book:642", "recall", "easy",
 "**لکه‌های کوپلیک** پاتوگنومونیک سرخک‌اند — راش نیست که تشخیص می‌دهد، مخاط است.",
 "KOPLIK SPOTS are pathognomonic of measles — it is the mucosa that diagnoses it, not the rash.",
 MMR_FA + [
  "**این سؤال کوتاه‌ترین راه رسیدن به تشخیص سرخک است، چون یک یافته‌ی پاتوگنومونیک دارد.**",
  "⚠️ **لکه‌های کوپلیک در هیچ بیماری دیگری دیده نمی‌شوند — همین آن‌ها را قطعی می‌کند.**",
  "**و پنجره‌شان کوتاه است: ۱ تا ۲ روز پیش از راش تا ۲ روز پس از آن.**",
  "**پس اگر آن‌ها را ببینید، تشخیص قطعی است؛ اگر نبینید، سرخک رد نمی‌شود.**",
  "**متن هر سه C را هم آورده: تب، سرفه و کونژنکتیویت.**",
  "**و انتشار «از سر به پایین» را هم صریحاً ذکر کرده است.**",
  "⚠️ **پس چهار سرنخ مستقل به یک تشخیص می‌رسند و جای تردید نمی‌ماند.**",
 ],
 MMR_EN + [
  "This is the shortest route to a measles diagnosis, because it contains a pathognomonic sign.",
  "WARNING: KOPLIK SPOTS ARE SEEN IN NO OTHER DISEASE — that is what makes them definitive.",
  "And their window is short: 1 to 2 days before the rash to 2 days after it.",
  "So if you see them the diagnosis is certain; if you do not, measles is not excluded.",
  "The stem gives all three Cs too: fever, cough and conjunctivitis.",
  "And it states the head-to-toe spread explicitly.",
  "WARNING, SO FOUR INDEPENDENT CLUES CONVERGE ON ONE DIAGNOSIS, leaving no doubt.",
 ],
 "**کودک ۸ ساله** پس از دوره‌ی **تب و سرفه و کونژنکتیویت**، با **لکه‌های کوپلیک** در "
 "دهان، دچار **راش ماکولوپاپولر ژنرالیزه و به‌هم‌پیوسته با شروع از سر و انتشار به "
 "پایین** شده است.\n\n"
 "⚠️ **پاسخ: Measles (سرخک). و این سؤال کوتاه‌ترین راه به تشخیص است، چون یک یافته‌ی "
 "پاتوگنومونیک دارد.**\n\n"
 "**لکه‌های کوپلیک چیستند؟**\n\n"
 "**نقاط سفید مایل به آبی، به اندازه‌ی دانه‌ی نمک، روی زمینه‌ی قرمز مخاط گونه** — "
 "معمولاً **در محاذات دندان آسیای دوم**.\n\n"
 "⚠️ **و مهم‌ترین ویژگی‌شان: در هیچ بیماری دیگری دیده نمی‌شوند. یعنی پاتوگنومونیک "
 "سرخک‌اند.**\n\n"
 "**و همین دلیل قاعده‌ی طلایی است:**\n\n"
 "> **سرخک را از مخاط بشناسید، نه از راش. راش سرخک به ده‌ها بیماری دیگر شبیه است؛ "
 "لکه‌های کوپلیک به هیچ‌کدام.**\n\n"
 "⚠️ **ولی یک محدودیت مهم دارند: پنجره‌شان کوتاه است.** ۱ تا ۲ روز **پیش** از راش "
 "ظاهر می‌شوند و ظرف ۲ روز پس از راش **محو** می‌شوند. **پس اگر آن‌ها را ببینید تشخیص "
 "قطعی است؛ ولی اگر نبینید، سرخک رد نمی‌شود** — شاید فقط دیر رسیده‌اید.\n\n"
 "**و متن سه سرنخ دیگر هم دارد:** **تب و سرفه و کونژنکتیویت** (سه C)، و **انتشار از "
 "سر به پایین**. ⚠️ **پس چهار سرنخ مستقل به یک تشخیص می‌رسند.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**Rubella (سرخجه)** — راش هم از سر به پایین می‌رود، ولی **کوپلیک ندارد**، تبش "
 "**خفیف‌تر** است، و **لنفادنوپاتی پس‌گوشی** دارد.\n\n"
 "**Roseola** — ⚠️ راش **پس از قطع تب** می‌آید، و بیماری **شیرخواران** است.\n\n"
 "**Scarlet fever (مخملک)** — ⚠️ گزینه‌ی جالبی است چون آن هم **زبان و دهان** را "
 "درگیر می‌کند، ولی **به شکل کاملاً متفاوت**: **زبان توت‌فرنگی** (قرمز و برجسته)، نه "
 "لکه‌های سفید. و راشش **سنباده‌ای (خشن)** است، نه ماکولوپاپولر، و در **چین‌های "
 "بدن** تشدید می‌شود (خطوط پاستیا). ضمناً عاملش **استرپتوکوک** است، پس **کونژنکتیویت "
 "نمی‌دهد**.",
 "AN 8-YEAR-OLD CHILD, after a period of FEVER, COUGH AND CONJUNCTIVITIS, with KOPLIK SPOTS in the "
 "mouth, develops a GENERALISED CONFLUENT MACULOPAPULAR RASH BEGINNING ON THE HEAD AND SPREADING "
 "DOWNWARDS.\n\n"
 "WARNING, THE ANSWER: MEASLES. This is the shortest route to a diagnosis, because it contains a "
 "PATHOGNOMONIC sign.\n\n"
 "WHAT ARE KOPLIK SPOTS?\n\n"
 "BLUISH-WHITE DOTS THE SIZE OF A GRAIN OF SALT ON A RED BUCCAL MUCOSA — usually OPPOSITE THE "
 "SECOND MOLARS.\n\n"
 "WARNING, AND THEIR KEY PROPERTY: THEY ARE SEEN IN NO OTHER DISEASE. They are PATHOGNOMONIC of "
 "measles.\n\n"
 "And that is the basis of the golden rule:\n\n"
 "> RECOGNISE MEASLES FROM THE MUCOSA, NOT THE RASH. The measles rash resembles dozens of other "
 "diseases; Koplik spots resemble none.\n\n"
 "WARNING, BUT THEY HAVE ONE IMPORTANT LIMITATION: A SHORT WINDOW. They appear 1 to 2 days BEFORE "
 "the rash and FADE within 2 days after it. SO IF YOU SEE THEM THE DIAGNOSIS IS CERTAIN; BUT IF YOU "
 "DO NOT, MEASLES IS NOT EXCLUDED — you may simply have arrived late.\n\n"
 "And the stem gives three more clues: FEVER, COUGH AND CONJUNCTIVITIS (the three Cs), and the "
 "HEAD-TO-TOE SPREAD. WARNING, SO FOUR INDEPENDENT CLUES CONVERGE ON ONE DIAGNOSIS.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "RUBELLA — its rash also spreads head to toe, but it has NO KOPLIK SPOTS, a MILDER fever, and "
 "POSTAURICULAR LYMPHADENOPATHY.\n\n"
 "ROSEOLA — WARNING, its rash comes AFTER the fever breaks, and it is a disease of INFANTS.\n\n"
 "SCARLET FEVER — WARNING, an interesting option because it too involves the TONGUE AND MOUTH, but "
 "in a COMPLETELY DIFFERENT WAY: a STRAWBERRY TONGUE (red and papillated), not white spots. And its "
 "rash is SANDPAPER-LIKE rather than maculopapular, accentuated in the SKIN FOLDS (Pastia's lines). "
 "Its cause is STREPTOCOCCUS, so it produces NO CONJUNCTIVITIS.",
 ["پاسخ صحیح — لکه‌های کوپلیک پاتوگنومونیک سرخک‌اند و در هیچ بیماری دیگری دیده نمی‌شوند.",
  "سرخجه کوپلیک ندارد، تبش خفیف‌تر است و لنفادنوپاتی پس‌گوشی دارد.",
  "در روزئولا راش پس از قطع تب می‌آید و بیماری شیرخواران است.",
  "مخملک زبان توت‌فرنگی و راش سنباده‌ای می‌دهد، نه کوپلیک، و کونژنکتیویت هم ندارد."],
 ["Correct — Koplik spots are pathognomonic of measles and are seen in no other disease.",
  "Rubella has no Koplik spots, a milder fever, and postauricular lymphadenopathy.",
  "In roseola the rash follows defervescence, and it is a disease of infants.",
  "Scarlet fever gives a strawberry tongue and a sandpaper rash, not Koplik spots, and no conjunctivitis."],
 "**راش سرخک شبیه ده‌ها بیماری است؛ لکه‌های کوپلیک شبیه هیچ‌کدام.**",
 "The measles rash resembles dozens of diseases; Koplik spots resemble none.",
 [CDCMEASLES, H])

add("book:643", "case", "medium",
 "شایع‌ترین عارضه‌ی سرخک: **اوتیت مدیای حاد** — شایع‌تر از پنومونی و بسیار شایع‌تر از انسفالیت.",
 "The commonest complication of measles is ACUTE OTITIS MEDIA — commoner than pneumonia and far commoner than encephalitis.",
 MMR_FA + [
  "**تشخیص در این سؤال قطعی است و سؤال درباره‌ی عوارض می‌پرسد.**",
  "⚠️ **و کلمه‌ی کلیدی «بیشتر از بقیه ممکن است رخ بدهد» یعنی شایع‌ترین، نه شدیدترین.**",
  "**اوتیت مدیای حاد در حدود ۷ تا ۹ درصد موارد سرخک رخ می‌دهد.**",
  "**پنومونی در حدود ۱ تا ۶ درصد، و انسفالیت در حدود ۱ در هزار.**",
  "⚠️ **ولی ترتیب کشندگی وارونه است: پنومونی شایع‌ترین علت مرگ در سرخک است.**",
  "**پس «شایع‌ترین عارضه» با «کشنده‌ترین عارضه» دو سؤال متفاوت‌اند.**",
  "**و چرا اوتیت این‌قدر شایع است؟ چون سرخک مخاط تنفسی و شیپور استاش را ملتهب می‌کند.**",
  "**التهاب شیپور استاش، تخلیه‌ی گوش میانی را مسدود می‌کند و زمینه‌ی عفونت ثانویه می‌شود.**",
 ],
 MMR_EN + [
  "The diagnosis here is certain and the question is about complications.",
  "WARNING, AND THE PHRASE 'MOST LIKELY TO OCCUR' MEANS COMMONEST, not most severe.",
  "Acute otitis media occurs in about 7 to 9 per cent of measles cases.",
  "Pneumonia in about 1 to 6 per cent, and encephalitis in about 1 in 1000.",
  "WARNING, BUT THE ORDER OF LETHALITY IS INVERTED: pneumonia is the commonest cause of death in measles.",
  "So 'commonest complication' and 'most lethal complication' are two different questions.",
  "And why is otitis so common? Because measles inflames the respiratory mucosa and the Eustachian tube.",
  "Eustachian inflammation blocks middle-ear drainage and creates the setting for secondary infection.",
 ],
 "**سرباز ۲۰ ساله** در دوره‌ی آموزشی، با **تب شدید، بی‌اشتهایی، سرفه‌های شدید و "
 "کونژنکتیویت دوطرفه**. در معاینه **نقاط سفید مایل به آبی در محاذات دندان دوم آسیا** "
 "و **ضایعات ماکولوپاپولر** در صورت و تنه و اندام‌ها.\n\n"
 "**تشخیص قطعی است: سرخک** — لکه‌های کوپلیک پاتوگنومونیک‌اند.\n\n"
 "⚠️ **ولی سؤال تشخیص را نمی‌پرسد. می‌پرسد کدام عارضه «بیشتر از بقیه ممکن است رخ "
 "بدهد» — یعنی شایع‌ترین، نه شدیدترین.**\n\n"
 "**پاسخ: اوتیت مدیای حاد.**\n\n"
 "**ارقام را بدانید، چون همین سؤال را حل می‌کنند:**\n\n"
 "**اوتیت مدیای حاد: حدود ۷ تا ۹ درصد** ← شایع‌ترین\n\n"
 "**پنومونی: حدود ۱ تا ۶ درصد**\n\n"
 "**انسفالیت: حدود ۱ در ۱۰۰۰**\n\n"
 "⚠️ **و حالا نکته‌ی حیاتی که سؤال روی آن بنا شده: ترتیب کشندگی وارونه است.**\n\n"
 "**پنومونی شایع‌ترین علت مرگ در سرخک است** — نه اوتیت. **پس «شایع‌ترین عارضه» و "
 "«کشنده‌ترین عارضه» دو سؤال کاملاً متفاوت‌اند، و باید دقت کنید کدام پرسیده شده.**\n\n"
 "**و چرا اوتیت این‌قدر شایع است؟ سازوکارش را بفهمید:**\n\n"
 "**ویروس سرخک مخاط کل دستگاه تنفسی را ملتهب می‌کند** — از بینی تا برونش. و "
 "**شیپور استاش** بخشی از همین مسیر است. ⚠️ **التهاب شیپور استاش، تخلیه‌ی گوش میانی "
 "را مسدود می‌کند**، مایع جمع می‌شود، و **زمینه‌ی عفونت ثانویه‌ی باکتریایی** فراهم "
 "می‌شود.\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**لارنگوتراکئوبرونشیت (کروپ)** — ⚠️ در سرخک **رخ می‌دهد** و در کودکان می‌تواند جدی "
 "باشد، ولی **از اوتیت کمتر شایع است**. ضمناً کروپ عمدتاً بیماری **کودکان زیر ۳ سال** "
 "است، نه سرباز ۲۰ ساله.\n\n"
 "**پرفوراسیون روده** — **هیچ ربطی به سرخک ندارد**. این عارضه‌ی **تیفوئید** است "
 "(هفته‌ی سوم بیماری).\n\n"
 "**آنسفالیت** — ⚠️ **جدی‌ترین عارضه‌ی حاد است ولی بسیار نادرتر** (۱ در ۱۰۰۰). سؤال "
 "**شایع‌ترین** را می‌خواهد، نه **شدیدترین**.\n\n"
 "⚠️ **و یک نکته‌ی مهم درباره‌ی بستر سؤال: سرباز در دوره‌ی آموزشی.** پادگان‌ها و "
 "خوابگاه‌ها **محیط کلاسیک اپیدمی سرخک** هستند، چون **تراکم جمعیت بالا** و **افراد "
 "از مناطق مختلف با پوشش واکسیناسیون متفاوت** کنار هم‌اند. **سرخک یکی از مسری‌ترین "
 "بیماری‌های شناخته‌شده است** و در چنین محیطی به‌سرعت پخش می‌شود.",
 "A 20-YEAR-OLD SOLDIER in training, with HIGH FEVER, ANOREXIA, SEVERE COUGH and BILATERAL "
 "CONJUNCTIVITIS. On examination, BLUISH-WHITE SPOTS OPPOSITE THE SECOND MOLARS and MACULOPAPULAR "
 "LESIONS on face, trunk and limbs.\n\n"
 "THE DIAGNOSIS IS CERTAIN: MEASLES — Koplik spots are pathognomonic.\n\n"
 "WARNING, BUT THE STEM DOES NOT ASK THE DIAGNOSIS. It asks which complication is 'MOST LIKELY TO "
 "OCCUR' — that is, COMMONEST, not most severe.\n\n"
 "THE ANSWER: ACUTE OTITIS MEDIA.\n\n"
 "KNOW THE FIGURES, because they settle the question:\n\n"
 "ACUTE OTITIS MEDIA: about 7 to 9 per cent — the commonest.\n\n"
 "PNEUMONIA: about 1 to 6 per cent.\n\n"
 "ENCEPHALITIS: about 1 in 1000.\n\n"
 "WARNING, AND NOW THE VITAL POINT THE QUESTION IS BUILT ON: THE ORDER OF LETHALITY IS INVERTED.\n\n"
 "PNEUMONIA IS THE COMMONEST CAUSE OF DEATH IN MEASLES — not otitis. SO 'COMMONEST COMPLICATION' "
 "AND 'MOST LETHAL COMPLICATION' ARE TWO ENTIRELY DIFFERENT QUESTIONS, and you must note which is "
 "asked.\n\n"
 "AND WHY IS OTITIS SO COMMON? Understand the mechanism:\n\n"
 "MEASLES INFLAMES THE MUCOSA OF THE ENTIRE RESPIRATORY TRACT — from nose to bronchi. And the "
 "EUSTACHIAN TUBE is part of that tract. WARNING, EUSTACHIAN INFLAMMATION BLOCKS MIDDLE-EAR "
 "DRAINAGE, fluid accumulates, and the ground is prepared for SECONDARY BACTERIAL INFECTION.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "LARYNGOTRACHEOBRONCHITIS (CROUP) — WARNING, it DOES occur in measles and can be serious in "
 "children, but it is LESS COMMON THAN OTITIS. Croup is also mainly a disease of CHILDREN UNDER 3, "
 "not a 20-year-old soldier.\n\n"
 "INTESTINAL PERFORATION — HAS NOTHING TO DO WITH MEASLES. That is a complication of TYPHOID (in "
 "the third week).\n\n"
 "ENCEPHALITIS — WARNING, THE MOST SERIOUS ACUTE COMPLICATION BUT FAR RARER (1 in 1000). The stem "
 "asks for the COMMONEST, not the most severe.\n\n"
 "WARNING, AND AN IMPORTANT POINT ABOUT THE SETTING: a soldier in training. BARRACKS AND DORMITORIES "
 "ARE THE CLASSIC SETTING FOR MEASLES OUTBREAKS, because of HIGH POPULATION DENSITY and PEOPLE FROM "
 "DIFFERENT REGIONS WITH DIFFERENT VACCINATION COVERAGE living together. MEASLES IS ONE OF THE MOST "
 "CONTAGIOUS DISEASES KNOWN and spreads rapidly in such an environment.",
 ["کروپ در سرخک رخ می‌دهد ولی از اوتیت کمتر شایع است و عمدتاً بیماری کودکان زیر ۳ سال است.",
  "پرفوراسیون روده هیچ ربطی به سرخک ندارد؛ عارضه‌ی تیفوئید در هفته‌ی سوم است.",
  "پاسخ صحیح — اوتیت مدیای حاد در ۷ تا ۹ درصد موارد رخ می‌دهد و شایع‌ترین عارضه‌ی سرخک است.",
  "آنسفالیت جدی‌ترین عارضه است ولی بسیار نادرتر (۱ در ۱۰۰۰)؛ سؤال شایع‌ترین را می‌خواهد."],
 ["Croup occurs in measles but is less common than otitis and is mainly a disease of children under 3.",
  "Intestinal perforation has nothing to do with measles; it is a third-week complication of typhoid.",
  "Correct — acute otitis media occurs in 7 to 9 per cent and is the commonest complication of measles.",
  "Encephalitis is the most serious complication but far rarer (1 in 1000); the stem asks for the commonest."],
 "**شایع‌ترین عارضه اوتیت است؛ ولی شایع‌ترین علت مرگ پنومونی است.**",
 "The commonest complication is otitis; but the commonest cause of death is pneumonia.",
 [CDCMEASLES, H])

add("book:647", "case", "medium",
 "سرولوژی سرخجه: **IgG مثبت، IgM منفی** = ایمنی قدیمی ← **اطمینان‌بخشی و هیچ اقدام دیگر**.",
 "Rubella serology with IgG POSITIVE and IgM NEGATIVE means OLD IMMUNITY: REASSURE AND DO NOTHING FURTHER.",
 MMR_FA + [
  "**این سؤال با یک قاعده‌ی ساده حل می‌شود: IgM یعنی حاد، IgG یعنی گذشته.**",
  "⚠️ **IgG مثبت با IgM منفی یعنی تماس در گذشته و ایمنی پایدار — بهترین حالت ممکن.**",
  "**پس این زن باردار در برابر سرخجه ایمن است و جنینش در خطر نیست.**",
  "**و اقدام درست، اطمینان‌بخشی است — که خودش یک مداخله‌ی درمانی محسوب می‌شود.**",
  "⚠️ **و واکسن سرخجه در بارداری کنتراندیکه است، چون ویروس زنده‌ی ضعیف‌شده است.**",
  "**ضمناً واکسن زدن به کسی که از قبل ایمن است، هیچ سودی ندارد.**",
  "**سندرم سرخجه‌ی مادرزادی فقط در عفونت اولیه‌ی مادر رخ می‌دهد، نه در ایمنی قبلی.**",
  "**و بیشترین خطر آن در سه‌ماهه‌ی اول است: تا ۹۰ درصد پیش از هفته‌ی ۱۱.**",
 ],
 MMR_EN + [
  "This question is solved by one simple rule: IgM means acute, IgG means past.",
  "WARNING: IgG POSITIVE WITH IgM NEGATIVE means past exposure and lasting immunity — the best possible result.",
  "So this pregnant woman is immune to rubella and her fetus is not at risk.",
  "And the right action is REASSURANCE — itself a therapeutic intervention.",
  "WARNING, AND RUBELLA VACCINE IS CONTRAINDICATED IN PREGNANCY, because it is a live attenuated virus.",
  "Besides, vaccinating someone already immune achieves nothing.",
  "Congenital rubella syndrome occurs only with a mother's PRIMARY infection, not with existing immunity.",
  "And its greatest risk is in the first trimester: up to 90 per cent before week 11.",
 ],
 "**خانم باردار ۸ هفته** با سرولوژی سرخجه: **IgG مثبت، IgM منفی**.\n\n"
 "⚠️ **پاسخ: اطمینان‌بخشی به بیمار و عدم توصیه‌ی بیشتر تشخیصی و درمانی.**\n\n"
 "**و این سؤال با یک قاعده‌ی ساده حل می‌شود که در بلوک هپاتیت هم دیدید:**\n\n"
 "> **IgM یعنی حاد. IgG یعنی گذشته.**\n\n"
 "**پس بیایید پنل را بخوانیم:**\n\n"
 "**IgM منفی** → **عفونت حاد در کار نیست**. الان مبتلا نیست.\n\n"
 "**IgG مثبت** → **در گذشته تماس داشته** (یا بیماری یا واکسن) و **آنتی‌بادی محافظ "
 "ساخته است**.\n\n"
 "⚠️ **نتیجه: این زن در برابر سرخجه ایمن است. این بهترین حالت ممکن است.**\n\n"
 "**و چرا این خبر این‌قدر خوب است؟**\n\n"
 "**سندرم سرخجه‌ی مادرزادی یکی از فاجعه‌بارترین عفونت‌های بارداری است:** ناشنوایی، "
 "کاتاراکت، بیماری قلبی مادرزادی، عقب‌ماندگی ذهنی. ⚠️ **و خطرش در سه‌ماهه‌ی اول "
 "بیشترین است — تا ۹۰ درصد اگر عفونت پیش از هفته‌ی ۱۱ رخ دهد.**\n\n"
 "**این بیمار ۸ هفته باردار است — یعنی دقیقاً در خطرناک‌ترین پنجره. پس دانستن اینکه "
 "او ایمن است، خبر بسیار مهمی است.**\n\n"
 "⚠️ **و سندرم سرخجه‌ی مادرزادی فقط در عفونت اولیه‌ی مادر رخ می‌دهد. اگر مادر از قبل "
 "ایمن باشد، جنین در خطر نیست.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**تکرار آزمایش به فاصله‌ی دو هفته** — تکرار برای دیدن **افزایش تیتر** است، که "
 "نشانه‌ی **عفونت فعال** است. ولی **IgM منفی از قبل عفونت حاد را رد کرده**. تکرار "
 "فقط **اضطراب و هزینه** اضافه می‌کند.\n\n"
 "**PCR روی مایع آمنیوتیک در هفته‌ی ۲۰** — ⚠️ **یک اقدام تهاجمی جدی** (آمنیوسنتز، با "
 "خطر سقط) برای **جنینی که در خطر نیست**. این نمونه‌ی روشن **آسیب رساندن با اقدام "
 "غیرضروری** است.\n\n"
 "**تجویز واکسن و ایمونوگلوبولین** ❌ — ⚠️ **دو اشکال جدی**: **اول** اینکه واکسن "
 "سرخجه (بخشی از MMR) یک **ویروس زنده‌ی ضعیف‌شده** است و **در بارداری کنتراندیکه**. "
 "**دوم** اینکه واکسن زدن به کسی که **از قبل ایمن است**، هیچ سودی ندارد.\n\n"
 "⚠️ **و نکته‌ی انسانی که ارزش تکرار دارد: «اطمینان‌بخشی» یک اقدام واقعی است، نه "
 "«هیچ کاری نکردن».** زن باردار مضطربی که نگران سلامت جنینش است، با یک توضیح روشن و "
 "مستدل آرام می‌شود — و این خودش یک مداخله‌ی درمانی است.",
 "A WOMAN AT 8 WEEKS' GESTATION with rubella serology: IgG POSITIVE, IgM NEGATIVE.\n\n"
 "WARNING, THE ANSWER: reassure her and recommend nothing further, diagnostic or therapeutic.\n\n"
 "This question is solved by one simple rule you also met in the hepatitis block:\n\n"
 "> IgM MEANS ACUTE. IgG MEANS PAST.\n\n"
 "So read the panel:\n\n"
 "IgM NEGATIVE — NO ACUTE INFECTION. She is not infected now.\n\n"
 "IgG POSITIVE — SHE WAS EXPOSED IN THE PAST (by disease or vaccine) and HAS MADE PROTECTIVE "
 "ANTIBODY.\n\n"
 "WARNING, THE CONCLUSION: SHE IS IMMUNE TO RUBELLA. That is the best possible result.\n\n"
 "AND WHY IS THAT SUCH GOOD NEWS?\n\n"
 "CONGENITAL RUBELLA SYNDROME IS ONE OF THE MOST DEVASTATING INFECTIONS OF PREGNANCY: deafness, "
 "cataract, congenital heart disease, intellectual disability. WARNING, AND ITS RISK IS HIGHEST IN "
 "THE FIRST TRIMESTER — up to 90 per cent if infection occurs before week 11.\n\n"
 "This patient is at 8 weeks — precisely the most dangerous window. So knowing she is immune is "
 "very important news.\n\n"
 "WARNING, AND CONGENITAL RUBELLA SYNDROME OCCURS ONLY WITH A MOTHER'S PRIMARY INFECTION. If she is "
 "already immune, the fetus is not at risk.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "REPEAT THE TEST IN TWO WEEKS — repeating looks for a RISING TITRE, which indicates ACTIVE "
 "infection. But a NEGATIVE IgM HAS ALREADY EXCLUDED acute infection. Repeating adds only ANXIETY "
 "AND COST.\n\n"
 "PCR ON AMNIOTIC FLUID AT WEEK 20 — WARNING, A SERIOUSLY INVASIVE PROCEDURE (amniocentesis, with a "
 "risk of miscarriage) FOR A FETUS THAT IS NOT AT RISK. A clear example of DOING HARM THROUGH AN "
 "UNNECESSARY INTERVENTION.\n\n"
 "GIVE VACCINE AND IMMUNOGLOBULIN — WARNING, TWO SERIOUS FLAWS: FIRST, rubella vaccine (part of "
 "MMR) is a LIVE ATTENUATED VIRUS and is CONTRAINDICATED IN PREGNANCY. SECOND, vaccinating someone "
 "ALREADY IMMUNE achieves nothing.\n\n"
 "WARNING, AND A HUMANE POINT WORTH REPEATING: 'REASSURANCE' IS A REAL ACTION, not 'doing nothing'. "
 "An anxious pregnant woman worried about her baby is calmed by a clear, reasoned explanation — and "
 "that is itself a therapeutic intervention.",
 ["تکرار آزمایش برای دیدن افزایش تیتر است، ولی IgM منفی از قبل عفونت حاد را رد کرده است.",
  "آمنیوسنتز یک اقدام تهاجمی با خطر سقط است، برای جنینی که اصلاً در خطر نیست.",
  "پاسخ صحیح — IgG مثبت با IgM منفی یعنی ایمنی قدیمی، و اطمینان‌بخشی خودش یک مداخله است.",
  "واکسن سرخجه ویروس زنده است و در بارداری ممنوع؛ ضمناً فرد از قبل ایمن است."],
 ["Repeating looks for a rising titre, but a negative IgM has already excluded acute infection.",
  "Amniocentesis is an invasive procedure with a miscarriage risk, for a fetus that is not at risk.",
  "Correct — IgG positive with IgM negative means old immunity, and reassurance is itself an intervention.",
  "Rubella vaccine is a live virus forbidden in pregnancy; and she is already immune."],
 "**IgG مثبت + IgM منفی = ایمنی قدیمی = بهترین خبر ممکن در بارداری.**",
 "IgG positive with IgM negative means old immunity — the best possible news in pregnancy.",
 [REDBOOK, H])

add("book:650", "case", "medium",
 "زن باردار مستعد در تماس با سرخجه ← **ایمونوگلوبولین عضلانی**؛ واکسن در بارداری ممنوع است.",
 "A susceptible pregnant woman exposed to rubella: INTRAMUSCULAR IMMUNOGLOBULIN; the vaccine is forbidden in pregnancy.",
 MMR_FA + [
  "**این سؤال قرینه‌ی سؤال قبلی است: آنجا مادر ایمن بود، اینجا مستعد است.**",
  "⚠️ **و اولین کار، حذف واکسن است: واکسن سرخجه ویروس زنده‌ی ضعیف‌شده است.**",
  "**تجویز ویروس زنده در بارداری، خودش می‌تواند خطری بسازد که می‌خواستیم از آن پرهیز کنیم.**",
  "**و ریباویرین هم در بارداری مطلقاً ممنوع است، چون تراتوژن شناخته‌شده است.**",
  "**ضمناً ریباویرین اصلاً درمان سرخجه نیست؛ برای هپاتیت C و تب لاسا به کار می‌رود.**",
  "⚠️ **می‌ماند: ایمونوگلوبولین یا هیچ اقدام. و «هیچ اقدام» در مادر مستعد پذیرفتنی نیست.**",
  "**ایمونوگلوبولین ایمنی غیرفعال می‌دهد و می‌تواند شدت بیماری مادر را کم کند.**",
  "**ولی محدودیت مهمی دارد که باید صادقانه گفته شود: از سندرم مادرزادی جلوگیری نمی‌کند.**",
  "**پس مشاوره‌ی کامل درباره‌ی خطر باقی‌مانده و پیگیری سرولوژیک الزامی است.**",
 ],
 MMR_EN + [
  "This mirrors the previous question: there the mother was immune, here she is susceptible.",
  "WARNING, AND THE FIRST STEP IS TO ELIMINATE THE VACCINE: rubella vaccine is a live attenuated virus.",
  "Giving a live virus in pregnancy could itself create the very risk we are trying to avoid.",
  "And ribavirin is absolutely forbidden in pregnancy, being a recognised teratogen.",
  "Besides, ribavirin is not a treatment for rubella at all; it is used in hepatitis C and Lassa fever.",
  "WARNING, THAT LEAVES IMMUNOGLOBULIN OR NOTHING. And 'nothing' is not acceptable in a susceptible mother.",
  "Immunoglobulin gives passive immunity and may reduce the severity of the mother's illness.",
  "But it has an important limitation that must be stated honestly: it does not prevent congenital syndrome.",
  "So full counselling about the residual risk and serological follow-up are mandatory.",
 ],
 "**خانم باردار** که **قبلاً سرخجه نگرفته و واکسن هم نزده**، در **تماس با بیمار "
 "مبتلا به سرخجه** قرار گرفته است.\n\n"
 "⚠️ **پاسخ: تجویز ایمونوگلوبولین عضلانی. و این سؤال قرینه‌ی سؤال قبلی است — آنجا "
 "مادر ایمن بود، اینجا مستعد است.**\n\n"
 "**بیایید گزینه‌ها را یکی‌یکی حذف کنیم:**\n\n"
 "**تجویز واکسن سرخجه** ❌ — ⚠️ **اولین و روشن‌ترین حذف.** واکسن سرخجه (بخشی از MMR) "
 "یک **ویروس زنده‌ی ضعیف‌شده** است. **تجویز ویروس زنده در بارداری، خودش می‌تواند "
 "همان خطری را بسازد که می‌خواستیم از آن پرهیز کنیم.**\n\n"
 "**(نکته: در عمل، واکسن سرخجه پس از زایمان و پیش از ترخیص داده می‌شود، تا "
 "بارداری بعدی محافظت شود.)**\n\n"
 "**تجویز ریباویرین وریدی** ❌ — **دو اشکال جدی:** **اول** اینکه ریباویرین **اصلاً "
 "درمان سرخجه نیست** (برای هپاتیت C و تب لاسا و RSV به کار می‌رود). **دوم** و "
 "مهم‌تر: ⚠️ **ریباویرین یک تراتوژن شناخته‌شده است و در بارداری مطلقاً ممنوع.**\n\n"
 "**اقدامی لازم نیست** ❌ — در زن بارداری که **مستعد** است و **تماس واقعی** داشته، "
 "**رها کردن پذیرفتنی نیست**.\n\n"
 "**می‌ماند: ایمونوگلوبولین عضلانی** ✅\n\n"
 "**چطور کار می‌کند؟ ایمنی غیرفعال: آنتی‌بادی آماده به مادر داده می‌شود تا ویروس را "
 "پیش از انتشار خنثی کند.**\n\n"
 "⚠️ **ولی یک محدودیت مهم دارد که باید صادقانه گفته شود:**\n\n"
 "**ایمونوگلوبولین می‌تواند شدت بیماری مادر را کم کند، ولی از سندرم سرخجه‌ی مادرزادی "
 "به‌طور قطعی جلوگیری نمی‌کند.** مواردی از تولد نوزاد مبتلا با وجود تجویز "
 "ایمونوگلوبولین گزارش شده است.\n\n"
 "**پس چرا داده می‌شود؟** چون **بهترین گزینه‌ی موجود** است، و **هیچ کاری نکردن** بدتر "
 "است. **ولی مشاوره باید کامل و صادقانه باشد:** مادر باید بداند که **خطر باقی "
 "می‌ماند** و نیازمند **پیگیری سرولوژیک** است (تکرار IgM و IgG برای تشخیص "
 "سرکونورژن).\n\n"
 "⚠️ **و نکته‌ی پیشگیرانه‌ی اصلی: بهترین راه، پیشگیری پیش از بارداری است.** هر زن "
 "در سن باروری باید **پیش از بارداری** وضعیت ایمنی سرخجه‌اش بررسی شود و در صورت "
 "نیاز **واکسن بگیرد** — با رعایت **پرهیز از بارداری به مدت یک ماه** پس از واکسن.",
 "A PREGNANT WOMAN who HAS NEVER HAD RUBELLA AND HAS NOT BEEN VACCINATED has been EXPOSED to a "
 "patient with rubella.\n\n"
 "WARNING, THE ANSWER: INTRAMUSCULAR IMMUNOGLOBULIN. This mirrors the previous question — there the "
 "mother was immune, here she is susceptible.\n\n"
 "ELIMINATE THE OPTIONS ONE BY ONE:\n\n"
 "GIVE RUBELLA VACCINE — WARNING, THE FIRST AND CLEAREST ELIMINATION. Rubella vaccine (part of MMR) "
 "is a LIVE ATTENUATED VIRUS. GIVING A LIVE VIRUS IN PREGNANCY COULD CREATE THE VERY RISK WE ARE "
 "TRYING TO AVOID.\n\n"
 "(Note: in practice the rubella vaccine is given AFTER delivery, before discharge, to protect a "
 "future pregnancy.)\n\n"
 "GIVE INTRAVENOUS RIBAVIRIN — TWO SERIOUS FLAWS: FIRST, ribavirin IS NOT A TREATMENT FOR RUBELLA "
 "AT ALL (it is used in hepatitis C, Lassa fever and RSV). SECOND and more important: WARNING, "
 "RIBAVIRIN IS A RECOGNISED TERATOGEN AND IS ABSOLUTELY FORBIDDEN IN PREGNANCY.\n\n"
 "NO ACTION NEEDED — in a SUSCEPTIBLE pregnant woman with a REAL exposure, DOING NOTHING IS NOT "
 "ACCEPTABLE.\n\n"
 "THAT LEAVES INTRAMUSCULAR IMMUNOGLOBULIN.\n\n"
 "HOW DOES IT WORK? PASSIVE IMMUNITY: ready-made antibody is given to the mother to neutralise the "
 "virus before it disseminates.\n\n"
 "WARNING, BUT IT HAS AN IMPORTANT LIMITATION THAT MUST BE STATED HONESTLY:\n\n"
 "IMMUNOGLOBULIN MAY REDUCE THE SEVERITY OF THE MOTHER'S ILLNESS BUT DOES NOT RELIABLY PREVENT "
 "CONGENITAL RUBELLA SYNDROME. Cases of affected infants despite immunoglobulin have been reported.\n\n"
 "SO WHY GIVE IT? Because it is THE BEST AVAILABLE OPTION, and DOING NOTHING IS WORSE. BUT THE "
 "COUNSELLING MUST BE COMPLETE AND HONEST: the mother must know THE RISK REMAINS and that she needs "
 "SEROLOGICAL FOLLOW-UP (repeat IgM and IgG to detect seroconversion).\n\n"
 "WARNING, AND THE MAIN PREVENTIVE POINT: THE BEST APPROACH IS PREVENTION BEFORE PREGNANCY. Every "
 "woman of childbearing age should have her rubella immunity checked BEFORE conceiving and be "
 "VACCINATED if needed — avoiding pregnancy for one month afterwards.",
 ["واکسن سرخجه ویروس زنده‌ی ضعیف‌شده است و در بارداری کنتراندیکه؛ پس از زایمان داده می‌شود.",
  "ریباویرین اصلاً درمان سرخجه نیست و تراتوژن شناخته‌شده‌ای است که در بارداری ممنوع است.",
  "پاسخ صحیح — ایمونوگلوبولین ایمنی غیرفعال می‌دهد و بهترین گزینه‌ی موجود است.",
  "رها کردن زن باردار مستعد با تماس واقعی، پذیرفتنی نیست."],
 ["Rubella vaccine is a live attenuated virus contraindicated in pregnancy; it is given after delivery.",
  "Ribavirin is not a treatment for rubella and is a recognised teratogen forbidden in pregnancy.",
  "Correct — immunoglobulin gives passive immunity and is the best available option.",
  "Leaving a susceptible pregnant woman with a real exposure untreated is not acceptable."],
 "**ایمونوگلوبولین شدت را کم می‌کند ولی سندرم مادرزادی را قطعاً رد نمی‌کند — صادق باشید.**",
 "Immunoglobulin reduces severity but does not reliably prevent congenital syndrome — be honest about that.",
 [REDBOOK, H])

add("book:651", "case", "medium",
 "دوره‌ی سرایت اوریون طبق کتاب: **از یک هفته پیش تا یک هفته پس از شروع علائم**.",
 "The book's mumps infectious period: FROM ONE WEEK BEFORE TO ONE WEEK AFTER symptom onset.",
 MMR_FA + [
  "**تشخیص در متن داده شده و سؤال فقط درباره‌ی دوره‌ی سرایت است.**",
  "⚠️ **و اینجا باید میان دو عدد متفاوت تمایز بگذارید که اغلب قاطی می‌شوند.**",
  "**عدد اول — دوره‌ی جداسازی ویروس: از حدود ۷ روز پیش تا ۹ روز پس از پاروتیت.**",
  "**این همان بازه‌ای است که کتاب می‌پرسد و گزینه‌ی «یک هفته قبل تا یک هفته بعد» به آن نزدیک است.**",
  "⚠️ **عدد دوم — توصیه‌ی عملی ایزولاسیون: تا ۵ روز پس از شروع پاروتیت.**",
  "**چون بیشترین بار ویروسی و بیشترین انتقال، در روزهای نزدیک به شروع پاروتیت است.**",
  "**و پس از روز پنجم، هرچند ویروس گاهی جدا می‌شود، انتقال عملی بسیار کم است.**",
  "**پس هر دو عدد درست‌اند ولی به دو سؤال متفاوت پاسخ می‌دهند.**",
  "**و نکته‌ی مهم: سرایت پیش از شروع علائم آغاز می‌شود، یعنی پیش از آنکه کسی بداند بیمار است.**",
 ],
 MMR_EN + [
  "The diagnosis is given in the stem and the question is only about the infectious period.",
  "WARNING, AND HERE YOU MUST DISTINGUISH TWO DIFFERENT NUMBERS that are often confused.",
  "THE FIRST — the period of viral isolation: from about 7 days before to 9 days after parotitis.",
  "That is the interval the book asks about, and 'one week before to one week after' is close to it.",
  "WARNING, THE SECOND — the practical isolation advice: until 5 days after parotitis onset.",
  "Because the highest viral load and most transmission occur in the days around parotitis onset.",
  "And after day five, although virus is occasionally isolated, practical transmission is very low.",
  "So both numbers are correct but they answer two different questions.",
  "And the key point: infectivity begins BEFORE symptoms, that is, before anyone knows the patient is ill.",
 ],
 "**دختر ۵ ساله‌ی اهل افغانستان، بدون سابقه‌ی واکسیناسیون مشخص**، با **تب، میالژی و "
 "بی‌اشتهایی از ۳ روز قبل**، و **از روز قبل درد و تورم یک‌طرفه‌ی صورت** با **تندرنس و "
 "تورم ناحیه‌ی پاروتید**.\n\n"
 "**تشخیص در متن داده شده: اوریون (Mumps). سؤال فقط درباره‌ی دوره‌ی سرایت است.**\n\n"
 "⚠️ **پاسخ کتاب: از یک هفته قبل از شروع علائم تا یک هفته پس از شروع علائم.**\n\n"
 "**و اینجا باید میان دو عدد متفاوت تمایز بگذارید که اغلب قاطی می‌شوند — این "
 "مهم‌ترین چیزی است که از این سؤال یاد می‌گیرید:**\n\n"
 "**عدد اول — دوره‌ای که ویروس قابل جداسازی است:**\n\n"
 "**ویروس اوریون از حدود ۷ روز پیش از پاروتیت تا ۹ روز پس از آن از بزاق جدا شده "
 "است.** ⚠️ **این همان بازه‌ای است که کتاب می‌پرسد**، و گزینه‌ی «یک هفته قبل تا یک "
 "هفته بعد» به آن نزدیک‌ترین است.\n\n"
 "**عدد دوم — توصیه‌ی عملی ایزولاسیون:**\n\n"
 "⚠️ **CDC امروز می‌گوید: ایزولاسیون تا ۵ روز پس از شروع پاروتیت.**\n\n"
 "**چرا این دو متفاوت‌اند؟** چون **«جدا شدن ویروس در آزمایشگاه»** با **«انتقال واقعی "
 "به دیگران»** یکی نیست. **بیشترین بار ویروسی و بیشترین انتقال، در روزهای نزدیک به "
 "شروع پاروتیت است** و پس از آن **به‌سرعت افت می‌کند**. پس از روز پنجم، هرچند ویروس "
 "گاهی هنوز جدا می‌شود، **انتقال عملی بسیار کم است**.\n\n"
 "**پس هر دو عدد درست‌اند، ولی به دو سؤال متفاوت پاسخ می‌دهند:**\n\n"
 "**«ویروس تا کی در بدن هست؟»** → تا ۹ روز پس از پاروتیت.\n\n"
 "**«تا کی باید ایزوله بماند؟»** → ۵ روز پس از پاروتیت.\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**«از یک هفته قبل تا شروع پاروتید»** — نیمه‌ی اولش درست است، ولی **نیمه‌ی دومش "
 "خطرناک است**: سرایت **با شروع پاروتیت تمام نمی‌شود** بلکه **ادامه می‌یابد**.\n\n"
 "**«از زمان شروع پاروتیدیت تا بهبودی»** — ⚠️ **مهم‌ترین خطای این گزینه: دوره‌ی پیش "
 "از علائم را نادیده می‌گیرد.** و آن دوره **حیاتی‌ترین بخش** است، چون بیمار **نمی‌داند "
 "بیمار است** و هیچ احتیاطی نمی‌کند.\n\n"
 "**«با گذشت ۳ روز از شروع علائم ریسک انتقال وجود ندارد»** — ❌ **کاملاً غلط و "
 "خطرناک**. بیمار **دقیقاً الان** در مسری‌ترین دوره است.\n\n"
 "⚠️ **و نکته‌ی بهداشتی که این سؤال روی آن ساخته شده: کودک بدون سابقه‌ی واکسیناسیون "
 "است.** اوریون یک بیماری **قابل پیشگیری با واکسن** است، و طغیان‌های آن تقریباً همیشه "
 "در جمعیت‌های **با پوشش واکسیناسیون ناکافی** رخ می‌دهد.",
 "A 5-YEAR-OLD GIRL FROM AFGHANISTAN WITH NO CLEAR VACCINATION HISTORY, with FEVER, MYALGIA AND "
 "ANOREXIA FOR 3 DAYS and, SINCE YESTERDAY, UNILATERAL FACIAL PAIN AND SWELLING with PAROTID "
 "TENDERNESS AND SWELLING.\n\n"
 "THE DIAGNOSIS IS GIVEN IN THE STEM: MUMPS. The question is only about the infectious period.\n\n"
 "WARNING, THE BOOK'S ANSWER: from one week before symptom onset to one week after.\n\n"
 "AND HERE YOU MUST DISTINGUISH TWO DIFFERENT NUMBERS that are often confused — the most valuable "
 "thing you will take from this question:\n\n"
 "THE FIRST NUMBER — THE PERIOD IN WHICH VIRUS CAN BE ISOLATED:\n\n"
 "MUMPS VIRUS HAS BEEN ISOLATED FROM SALIVA FROM ABOUT 7 DAYS BEFORE PAROTITIS TO 9 DAYS AFTER IT. "
 "WARNING, THAT IS THE INTERVAL THE BOOK ASKS ABOUT, and 'one week before to one week after' is the "
 "closest option to it.\n\n"
 "THE SECOND NUMBER — THE PRACTICAL ISOLATION ADVICE:\n\n"
 "WARNING, THE CDC TODAY SAYS: ISOLATE UNTIL 5 DAYS AFTER PAROTITIS ONSET.\n\n"
 "WHY DO THEY DIFFER? Because 'VIRUS ISOLATED IN A LABORATORY' is not the same as 'ACTUAL "
 "TRANSMISSION TO OTHERS'. THE HIGHEST VIRAL LOAD AND MOST TRANSMISSION OCCUR IN THE DAYS AROUND "
 "PAROTITIS ONSET and then FALL RAPIDLY. After day five, although virus is sometimes still "
 "isolated, PRACTICAL TRANSMISSION IS VERY LOW.\n\n"
 "SO BOTH NUMBERS ARE CORRECT, BUT THEY ANSWER DIFFERENT QUESTIONS:\n\n"
 "'HOW LONG IS THE VIRUS PRESENT?' — until 9 days after parotitis.\n\n"
 "'HOW LONG SHOULD THEY BE ISOLATED?' — 5 days after parotitis.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "'FROM ONE WEEK BEFORE UNTIL PAROTITIS BEGINS' — its first half is right, but ITS SECOND HALF IS "
 "DANGEROUS: infectivity DOES NOT END when parotitis begins; it CONTINUES.\n\n"
 "'FROM THE ONSET OF PAROTITIS UNTIL RECOVERY' — WARNING, ITS KEY ERROR: IT IGNORES THE "
 "PRE-SYMPTOMATIC PERIOD. And that period is THE MOST CRITICAL PART, because the patient DOES NOT "
 "KNOW THEY ARE ILL and takes no precautions.\n\n"
 "'AFTER 3 DAYS OF SYMPTOMS THERE IS NO TRANSMISSION RISK' — COMPLETELY WRONG AND DANGEROUS. The "
 "patient is RIGHT NOW in the most infectious period.\n\n"
 "WARNING, AND THE PUBLIC HEALTH POINT THIS QUESTION IS BUILT ON: the child HAS NO VACCINATION "
 "HISTORY. Mumps is a VACCINE-PREVENTABLE disease, and its outbreaks almost always occur in "
 "populations with INADEQUATE VACCINATION COVERAGE.",
 ["نیمه‌ی اولش درست است ولی سرایت با شروع پاروتیت تمام نمی‌شود بلکه ادامه می‌یابد.",
  "پاسخ صحیح — بازه‌ی جداسازی ویروس از حدود یک هفته پیش تا حدود یک هفته پس از شروع علائم است.",
  "مهم‌ترین خطا — این گزینه دوره‌ی پیش از علائم را نادیده می‌گیرد، که حیاتی‌ترین بخش سرایت است.",
  "کاملاً غلط و خطرناک — بیمار دقیقاً در همین روزها در مسری‌ترین دوره است."],
 ["Its first half is right, but infectivity does not end when parotitis begins; it continues.",
  "Correct — virus is isolated from about a week before to about a week after symptom onset.",
  "The key error — this option ignores the pre-symptomatic period, the most critical part of infectivity.",
  "Completely wrong and dangerous — the patient is at this very moment in the most infectious period."],
 "**«ویروس تا کی هست» با «تا کی ایزوله بماند» دو سؤال متفاوت‌اند.**",
 "'How long is the virus present' and 'how long to isolate' are two different questions.",
 [CDCMUMPS, H])


# =============================================== HEPATITIS C
add("book:849", "case", "hard",
 "anti-LKM مثبت **به‌علاوه‌ی** HCVAb مثبت ← اول **HCV PCR**؛ پیش از سرکوب ایمنی، ویروس را رد کنید.",
 "Anti-LKM positive TOGETHER WITH HCVAb positive: do HCV PCR first — exclude the virus before immunosuppressing.",
 HEP_FA + [
  "**این سؤال یک تصمیم پرخطر را می‌آزماید: خودایمنی یا ویروس؟**",
  "⚠️ **آنتی‌بادی ضد LKM نشانگر هپاتیت خودایمن تیپ ۲ است — ولی نه فقط آن.**",
  "**در هپاتیت C هم به‌طور غیراختصاصی مثبت می‌شود، و همین ابهام را می‌سازد.**",
  "**و متن هر دو را با هم آورده: هم anti-LKM مثبت و هم HCVAb مثبت.**",
  "⚠️ **پس پیش از هر تصمیمی باید بدانیم آیا عفونت فعال HCV وجود دارد یا نه.**",
  "**و آنتی‌بادی ضد HCV این را نمی‌گوید، چون در بهبودیافته هم مثبت می‌ماند.**",
  "**فقط HCV RNA می‌گوید ویروس همین حالا فعال است یا نه.**",
  "⚠️ **و چرا ترتیب حیاتی است: کورتیکواستروئید در هپاتیت C فعال، تکثیر ویروس را تشدید می‌کند.**",
  "**پس شروع آزاتیوپرین و پردنیزون پیش از رد کردن ویروس، می‌تواند بیمار را بدتر کند.**",
 ],
 HEP_EN + [
  "This question tests a high-stakes decision: autoimmunity or virus?",
  "WARNING: ANTI-LKM ANTIBODY MARKS TYPE 2 AUTOIMMUNE HEPATITIS — but not only that.",
  "It also turns non-specifically positive in hepatitis C, and that is the source of the ambiguity.",
  "And the stem gives both together: anti-LKM positive AND HCVAb positive.",
  "WARNING, SO BEFORE ANY DECISION WE MUST KNOW WHETHER ACTIVE HCV INFECTION EXISTS.",
  "And the anti-HCV antibody does not tell us, because it stays positive after recovery too.",
  "Only HCV RNA says whether the virus is active right now.",
  "WARNING, AND WHY THE ORDER IS VITAL: corticosteroids in active hepatitis C accelerate viral replication.",
  "So starting azathioprine and prednisone before excluding the virus could make the patient worse.",
 ],
 "**خانم ۳۵ ساله** با ضعف، بی‌حالی، **درد مفصل و میالژی**، **بی‌اشتهایی، زردی و درد "
 "ربع فوقانی راست**. آزمایش‌ها: **AST=200، ALT=350**، **anti-LKM مثبت**، **HCVAb "
 "مثبت**، **ESR=80**.\n\n"
 "⚠️ **پاسخ: درخواست HCV PCR. و این سؤال یک تصمیم پرخطر را می‌آزماید.**\n\n"
 "**تابلوی بالینی می‌تواند دو چیز باشد، و هر دو در متن سرنخ دارند:**\n\n"
 "**احتمال یک — هپاتیت خودایمن.** ⚠️ **آنتی‌بادی ضد LKM نشانگر هپاتیت خودایمن تیپ "
 "۲ است.** و **درد مفصل، میالژی و ESR بالای ۸۰** همگی به نفع یک فرآیند خودایمن‌اند. "
 "زن جوان بودن هم با آن می‌خواند.\n\n"
 "**احتمال دو — هپاتیت C.** **HCVAb مثبت است.**\n\n"
 "⚠️ **و اینجا نکته‌ی کلیدی: این دو الزاماً رقیب هم نیستند. آنتی‌بادی ضد LKM در "
 "هپاتیت C هم به‌طور غیراختصاصی مثبت می‌شود.**\n\n"
 "**پس ابهام واقعی است و باید حل شود. چطور؟**\n\n"
 "**اول ببینیم HCVAb چه می‌گوید و چه نمی‌گوید:**\n\n"
 "**می‌گوید:** این فرد **در گذشته با ویروس C تماس داشته**.\n\n"
 "⚠️ **نمی‌گوید:** آیا **الان** عفونت فعال دارد. چون **حدود ۱۵ تا ۲۵ درصد افراد "
 "ویروس را خودبه‌خود پاک می‌کنند، ولی آنتی‌بادی‌شان مادام‌العمر مثبت می‌ماند**.\n\n"
 "**پس تنها راه: HCV RNA (PCR).** این می‌گوید **ویروس همین حالا در خون هست یا نه**.\n\n"
 "⚠️ **و حالا مهم‌ترین بخش: چرا ترتیب حیاتی است؟**\n\n"
 "**اگر مستقیم آزاتیوپرین و پردنیزون شروع کنیم و بیمار در واقع هپاتیت C فعال داشته "
 "باشد، فاجعه رخ می‌دهد:** **کورتیکواستروئید سیستم ایمنی را سرکوب می‌کند، و همان "
 "سیستم ایمنی است که ویروس را مهار می‌کند. نتیجه: تشدید تکثیر ویروس و بدتر شدن "
 "بیماری کبدی.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**آزاتیوپرین و پردنیزون** ❌ — ⚠️ **خطرناک‌ترین گزینه، به دلیلی که گفتیم.** درمان "
 "خودایمنی **پیش از رد کردن ویروس**، می‌تواند بیمار را بکشد.\n\n"
 "**بیوپسی کبد** — ⚠️ **گزینه‌ی وسوسه‌انگیز**، چون بیوپسی واقعاً در تشخیص هپاتیت "
 "خودایمن نقش دارد. ولی **تهاجمی** است (خطر خونریزی)، **گران** است، و **پیش از یک "
 "آزمایش خون ساده که ابهام را حل می‌کند، منطقی نیست**. **قاعده: اگر یک تست خونی و "
 "یک اقدام تهاجمی به یک سؤال پاسخ می‌دهند، اول تست خون.**\n\n"
 "**ریباویرین و اینترفرون** — درمان **قدیمی** هپاتیت C (امروز داروهای مستقیم‌الاثر "
 "جای آن را گرفته‌اند). ولی مهم‌تر: **شروع درمان پیش از اثبات عفونت فعال، همان اشتباه "
 "را از جهت دیگر تکرار می‌کند.**",
 "A 35-YEAR-OLD WOMAN with weakness, malaise, JOINT PAIN AND MYALGIA, ANOREXIA, JAUNDICE AND RIGHT "
 "UPPER QUADRANT PAIN. Tests: AST 200, ALT 350, ANTI-LKM POSITIVE, HCVAb POSITIVE, ESR 80.\n\n"
 "WARNING, THE ANSWER: REQUEST HCV PCR. This question tests a high-stakes decision.\n\n"
 "The picture could be either of two things, and both have clues in the stem:\n\n"
 "POSSIBILITY ONE — AUTOIMMUNE HEPATITIS. WARNING, ANTI-LKM ANTIBODY MARKS TYPE 2 AUTOIMMUNE "
 "HEPATITIS. And JOINT PAIN, MYALGIA AND AN ESR OF 80 all favour an autoimmune process. Being a "
 "young woman fits too.\n\n"
 "POSSIBILITY TWO — HEPATITIS C. HCVAb IS POSITIVE.\n\n"
 "WARNING, AND HERE IS THE KEY POINT: THESE TWO ARE NOT NECESSARILY RIVALS. ANTI-LKM ALSO TURNS "
 "NON-SPECIFICALLY POSITIVE IN HEPATITIS C.\n\n"
 "So the ambiguity is real and must be resolved. How?\n\n"
 "FIRST SEE WHAT HCVAb SAYS AND DOES NOT SAY:\n\n"
 "IT SAYS: this person HAS BEEN EXPOSED to hepatitis C in the past.\n\n"
 "WARNING, IT DOES NOT SAY: whether infection is ACTIVE NOW. Because ABOUT 15 TO 25 PER CENT CLEAR "
 "THE VIRUS SPONTANEOUSLY YET REMAIN ANTIBODY POSITIVE FOR LIFE.\n\n"
 "SO THE ONLY WAY IS HCV RNA (PCR). That says whether THE VIRUS IS IN THE BLOOD RIGHT NOW.\n\n"
 "WARNING, AND NOW THE MOST IMPORTANT PART: WHY IS THE ORDER VITAL?\n\n"
 "IF WE START AZATHIOPRINE AND PREDNISONE STRAIGHT AWAY AND THE PATIENT ACTUALLY HAS ACTIVE "
 "HEPATITIS C, DISASTER FOLLOWS: CORTICOSTEROIDS SUPPRESS THE IMMUNE SYSTEM, AND IT IS THE IMMUNE "
 "SYSTEM THAT HOLDS THE VIRUS IN CHECK. THE RESULT: ACCELERATED VIRAL REPLICATION AND WORSENING "
 "LIVER DISEASE.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "AZATHIOPRINE AND PREDNISONE — WARNING, THE MOST DANGEROUS OPTION, for the reason just given. "
 "Treating autoimmunity BEFORE EXCLUDING THE VIRUS could kill the patient.\n\n"
 "LIVER BIOPSY — WARNING, a tempting option, because biopsy does have a role in diagnosing "
 "autoimmune hepatitis. But it is INVASIVE (bleeding risk), EXPENSIVE, and NOT LOGICAL BEFORE A "
 "SIMPLE BLOOD TEST THAT RESOLVES THE AMBIGUITY. THE RULE: if a blood test and an invasive "
 "procedure answer the same question, do the blood test first.\n\n"
 "RIBAVIRIN AND INTERFERON — the OLD treatment for hepatitis C (direct-acting antivirals have "
 "replaced it). But more importantly: STARTING TREATMENT BEFORE PROVING ACTIVE INFECTION repeats "
 "the same mistake from the other direction.",
 ["خطرناک‌ترین گزینه — سرکوب ایمنی پیش از رد کردن هپاتیت C فعال، تکثیر ویروس را تشدید می‌کند.",
  "بیوپسی تهاجمی و گران است؛ اگر یک تست خونی همان سؤال را جواب می‌دهد، اول آن را انجام دهید.",
  "پاسخ صحیح — فقط HCV RNA می‌گوید عفونت فعال است یا گذشته، و این تصمیم را تعیین می‌کند.",
  "شروع درمان ضدویروسی پیش از اثبات عفونت فعال، همان اشتباه را از جهت دیگر تکرار می‌کند."],
 ["The most dangerous option — immunosuppression before excluding active hepatitis C accelerates viral replication.",
  "Biopsy is invasive and expensive; if a blood test answers the same question, do that first.",
  "Correct — only HCV RNA says whether infection is active or past, and that determines the decision.",
  "Starting antiviral treatment before proving active infection repeats the same mistake from the other side."],
 "**آنتی‌بادی می‌گوید تماس بوده؛ RNA می‌گوید ویروس هنوز هست. و ترتیب، جان بیمار است.**",
 "The antibody says exposure happened; RNA says the virus is still there. And the order can save a life.",
 [AASLD, H])

add("book:850", "recall", "medium",
 "حساس‌ترین تست در عفونت **زودهنگام** هپاتیت C: **HCV RNA** — پیش از آنکه آنتی‌بادی بیاید.",
 "The most sensitive test in EARLY hepatitis C is HCV RNA — before the antibody appears.",
 HEP_FA + [
  "**این سؤال مستقیماً پنجره‌ی سرولوژیک هپاتیت C را می‌آزماید.**",
  "⚠️ **آنتی‌بادی ضد HCV تا ۸ تا ۱۲ هفته پس از تماس مثبت نمی‌شود.**",
  "**ولی HCV RNA از ۱ تا ۲ هفته پس از تماس قابل شناسایی است.**",
  "**پس در بیماری که همین حالا علامت‌دار شده، RNA حساس‌ترین تست است.**",
  "**و RIBA یک تست تأییدی قدیمی برای آنتی‌بادی بود، پس همان پنجره را دارد.**",
  "⚠️ **ضمناً RIBA امروز کاملاً از الگوریتم‌ها حذف شده است.**",
  "**و anti-HBc IgM اصلاً مربوط به هپاتیت B است، نه C — سؤال درباره‌ی C است.**",
  "**سابقه‌ی اعتیاد تزریقی، عامل خطر شماره‌یک هپاتیت C در سراسر جهان است.**",
 ],
 HEP_EN + [
  "This question tests the hepatitis C serological window directly.",
  "WARNING: ANTI-HCV ANTIBODY DOES NOT TURN POSITIVE UNTIL 8 TO 12 WEEKS after exposure.",
  "But HCV RNA is detectable from 1 to 2 weeks after exposure.",
  "So in a patient who has just become symptomatic, RNA is the most sensitive test.",
  "And RIBA was an old confirmatory ANTIBODY test, so it shares the same window.",
  "WARNING, RIBA has also been removed from the algorithms entirely.",
  "And anti-HBc IgM belongs to hepatitis B, not C — and the question is about C.",
  "A history of injecting drug use is the number-one risk factor for hepatitis C worldwide.",
 ],
 "**آقای ۳۴ ساله معتاد تزریقی** با **درد پهلوی راست، بی‌اشتهایی و ایکتر خفیف**، با "
 "**سابقه‌ی واکسیناسیون هپاتیت B**. سؤال: **جهت بررسی هپاتیت C، کدام تست در این مرحله "
 "حساسیت بیشتری دارد؟**\n\n"
 "⚠️ **پاسخ: HCV RNA. و کلمه‌ی کلیدی «در این مرحله» است.**\n\n"
 "**این سؤال مستقیماً پنجره‌ی سرولوژیک هپاتیت C را می‌آزماید — همان مفهومی که در HIV "
 "یاد گرفتید، این‌بار در بیماری دیگری.**\n\n"
 "**ترتیب مثبت شدن نشانگرهای هپاتیت C:**\n\n"
 "⚠️ **HCV RNA: از ۱ تا ۲ هفته پس از تماس.** زودترین نشانگر.\n\n"
 "**آنتی‌بادی ضد HCV: از ۸ تا ۱۲ هفته پس از تماس.** بسیار دیرتر.\n\n"
 "**پس در بیماری که همین حالا علامت‌دار شده و در فاز حاد است، آنتی‌بادی ممکن است "
 "هنوز منفی باشد — و یک منفی کاذب در این مرحله یعنی از دست دادن تشخیص.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**RIBA** — ⚠️ **دو اشکال دارد.** **اول** اینکه RIBA یک **تست تأییدی برای "
 "آنتی‌بادی** است، پس **همان محدودیت پنجره** را دارد: اگر آنتی‌بادی هنوز نیامده باشد، "
 "RIBA هم چیزی نشان نمی‌دهد. **دوم** اینکه **امروز کاملاً از الگوریتم‌ها حذف شده "
 "است**، چون RNA هم زودتر مثبت می‌شود و هم به سؤال مهم‌تری پاسخ می‌دهد.\n\n"
 "**anti-HBc IgM** — ⚠️ **این گزینه اصلاً به سؤال ربط ندارد.** anti-HBc نشانگر "
 "**هپاتیت B** است، و سؤال صریحاً درباره‌ی **هپاتیت C** می‌پرسد. (هرچند در بستر "
 "بالینی این بیمار، بررسی هپاتیت B هم منطقی است — به‌ویژه چون **سابقه‌ی واکسیناسیون** "
 "دارد و باید بدانیم آیا پاسخ داده است یا نه.)\n\n"
 "**anti-HCV** — گزینه‌ی نزدیک ولی **دقیقاً همان تستی است که در پنجره کور است**.\n\n"
 "⚠️ **و نکته‌ی اپیدمیولوژیک: سابقه‌ی اعتیاد تزریقی، عامل خطر شماره‌یک هپاتیت C در "
 "سراسر جهان است.** حدود **۶۰ تا ۸۰ درصد** مصرف‌کنندگان تزریقی طولانی‌مدت، آلوده "
 "می‌شوند — چون HCV در برابر HIV **بسیار مسری‌تر** از راه خون است.\n\n"
 "**و یک نکته‌ی امیدبخش که ورای سؤال است:** ⚠️ **هپاتیت C امروز با داروهای "
 "مستقیم‌الاثر در ۸ تا ۱۲ هفته و با موفقیت بیش از ۹۵ درصد درمان می‌شود** — یکی از "
 "بزرگ‌ترین پیشرفت‌های پزشکی دهه‌های اخیر. **پس تشخیص زودهنگام واقعاً ارزش دارد.**",
 "A 34-YEAR-OLD MAN WHO INJECTS DRUGS, with RIGHT FLANK PAIN, ANOREXIA AND MILD JAUNDICE, and a "
 "HISTORY OF HEPATITIS B VACCINATION. The question: TO INVESTIGATE HEPATITIS C, WHICH TEST IS MORE "
 "SENSITIVE AT THIS STAGE?\n\n"
 "WARNING, THE ANSWER: HCV RNA. And the key phrase is 'AT THIS STAGE'.\n\n"
 "This question tests the hepatitis C serological window directly — the same concept you learned in "
 "HIV, now in another disease.\n\n"
 "THE ORDER IN WHICH HEPATITIS C MARKERS TURN POSITIVE:\n\n"
 "WARNING, HCV RNA: from 1 TO 2 WEEKS after exposure. The earliest marker.\n\n"
 "ANTI-HCV ANTIBODY: from 8 TO 12 WEEKS after exposure. Much later.\n\n"
 "SO IN A PATIENT WHO HAS JUST BECOME SYMPTOMATIC AND IS IN THE ACUTE PHASE, THE ANTIBODY MAY STILL "
 "BE NEGATIVE — and a false negative here means a missed diagnosis.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "RIBA — WARNING, TWO FLAWS. FIRST, RIBA is a CONFIRMATORY TEST FOR ANTIBODY, so it shares THE SAME "
 "WINDOW LIMITATION: if the antibody has not yet appeared, RIBA shows nothing either. SECOND, it "
 "has been REMOVED FROM THE ALGORITHMS ENTIRELY, because RNA turns positive earlier and answers a "
 "more important question.\n\n"
 "ANTI-HBc IgM — WARNING, this option is not relevant to the question at all. Anti-HBc marks "
 "HEPATITIS B, and the stem asks explicitly about HEPATITIS C. (Though in this patient's clinical "
 "context checking hepatitis B is reasonable — especially as he HAS A VACCINATION HISTORY and we "
 "should know whether he responded.)\n\n"
 "ANTI-HCV — the near option, but PRECISELY THE TEST THAT IS BLIND IN THE WINDOW.\n\n"
 "WARNING, AND THE EPIDEMIOLOGICAL POINT: INJECTING DRUG USE IS THE NUMBER-ONE RISK FACTOR FOR "
 "HEPATITIS C WORLDWIDE. About 60 TO 80 PER CENT of long-term injectors become infected — because "
 "HCV is FAR MORE TRANSMISSIBLE than HIV by the blood-borne route.\n\n"
 "AND A HOPEFUL POINT BEYOND THE QUESTION: WARNING, HEPATITIS C IS NOW CURED IN 8 TO 12 WEEKS WITH "
 "DIRECT-ACTING ANTIVIRALS, WITH SUCCESS ABOVE 95 PER CENT — one of the great medical advances of "
 "recent decades. SO EARLY DIAGNOSIS GENUINELY MATTERS.",
 ["پاسخ صحیح — HCV RNA از ۱ تا ۲ هفته پس از تماس مثبت است، در حالی که آنتی‌بادی ۸ تا ۱۲ هفته می‌برد.",
  "RIBA یک تست تأییدی آنتی‌بادی است، پس همان محدودیت پنجره را دارد و امروز حذف شده است.",
  "anti-HBc نشانگر هپاتیت B است و سؤال صریحاً درباره‌ی هپاتیت C می‌پرسد.",
  "anti-HCV دقیقاً همان تستی است که در پنجره‌ی زودهنگام کور است."],
 ["Correct — HCV RNA is positive from 1 to 2 weeks after exposure, while antibody takes 8 to 12 weeks.",
  "RIBA is a confirmatory antibody test, so it shares the window limitation, and it has been abandoned.",
  "Anti-HBc marks hepatitis B, and the question asks explicitly about hepatitis C.",
  "Anti-HCV is precisely the test that is blind in the early window."],
 "**در پنجره‌ی زودهنگام، RNA می‌بیند و آنتی‌بادی کور است.**",
 "In the early window RNA sees, and the antibody is blind.",
 [AASLD, H])

add("book:856", "case", "hard",
 "تیتر **زیر ۱۰** پس از **دو سری** واکسن ← نان‌رسپاندر واقعی ← **دو دوز HBIG**، نه سری سوم واکسن.",
 "A titre BELOW 10 after TWO FULL SERIES means a true non-responder: TWO DOSES OF HBIG, not a third series.",
 HEP_FA + [
  "**این سؤال ادامه‌ی منطقی سؤال نان‌رسپاندر است، ولی یک قدم جلوتر.**",
  "⚠️ **تفاوت کلیدی: این فرد دو سری کامل واکسن گرفته، نه یکی.**",
  "**و همین تفاوت، پاسخ را کاملاً عوض می‌کند.**",
  "**پس از یک سری ناموفق، تکرار سری دوم منطقی است و در بسیاری جواب می‌دهد.**",
  "⚠️ **ولی پس از دو سری ناموفق، فرد یک نان‌رسپاندر واقعی محسوب می‌شود.**",
  "**و شانس پاسخ به سری سوم بسیار پایین است، پس تکرارش منطقی نیست.**",
  "**چنین فردی پس از هر مواجهه، به ایمنی غیرفعال یعنی HBIG نیاز دارد.**",
  "**و رژیم استاندارد برای نان‌رسپاندر واقعی: دو دوز HBIG به فاصله‌ی یک ماه.**",
  "⚠️ **و متن این سؤال واحد تیتر را اصلاً چاپ نکرده، که خطای خودِ کتاب است.**",
 ],
 HEP_EN + [
  "This is the logical continuation of the non-responder question, one step further along.",
  "WARNING, THE KEY DIFFERENCE: this person has had TWO FULL SERIES, not one.",
  "And that difference changes the answer completely.",
  "After one failed series, repeating with a second is logical and works in many people.",
  "WARNING, BUT AFTER TWO FAILED SERIES the person is a TRUE NON-RESPONDER.",
  "And the chance of responding to a third series is very low, so repeating is not rational.",
  "Such a person needs PASSIVE IMMUNITY — that is, HBIG — after every exposure.",
  "And the standard regimen for a true non-responder: TWO DOSES OF HBIG ONE MONTH APART.",
  "WARNING, AND THIS STEM PRINTS NO UNIT FOR THE TITRE AT ALL, which is the book's own error.",
 ],
 "**جراح** که حین عمل **سوزن در دستش فرو رفته**. او **تا به حال دو سری واکسن علیه "
 "HBV** زده و **تیتر آنتی‌بادی در نهایت حدود ۶** گزارش شده است.\n\n"
 "⚠️ **پیش از هر چیز، یک نقص چاپی در کتاب: واحد این عدد اصلاً چاپ نشده است.** صفحه "
 "۳۱۵ فقط عدد برهنه‌ی «۶» را دارد. **واحد درست mIU/mL است**، و **آستانه‌ی محافظت "
 "۱۰ mIU/mL**. پس خوانش موردنظر **۶ mIU/mL** است — **زیر آستانه**. (خوشبختانه این "
 "پاسخ را عوض نمی‌کند، چون ۶ با هر خوانشی زیر ۱۰ است.)\n\n"
 "⚠️ **پاسخ: تزریق دو دوز HBIG به فاصله‌ی یک ماه.**\n\n"
 "**و این سؤال ادامه‌ی منطقی سؤال نان‌رسپاندر است، ولی یک قدم جلوتر. تفاوت کلیدی را "
 "ببینید:**\n\n"
 "**در سؤال قبلی (q9852): کارورز یک سری واکسن گرفته بود.** → پاسخ: **سری دوم واکسن "
 "+ HBIG**.\n\n"
 "⚠️ **در این سؤال: جراح دو سری کامل گرفته است.** → پاسخ متفاوت است.\n\n"
 "**چرا؟ منطقش را بفهمید:**\n\n"
 "**پس از یک سری ناموفق:** حدود **۵۰ تا ۷۰ درصد** افراد به **سری دوم** پاسخ می‌دهند. "
 "پس تکرار **منطقی** است.\n\n"
 "**پس از دو سری ناموفق:** ⚠️ **فرد یک «نان‌رسپاندر واقعی» محسوب می‌شود، و شانس "
 "پاسخ به سری سوم بسیار پایین است.** ادامه دادن واکسن، **تکرار کاری است که دو بار "
 "شکست خورده**.\n\n"
 "**پس چنین فردی چه باید بکند؟** ⚠️ **باید بپذیرد که هرگز ایمنی فعال نخواهد داشت، و "
 "پس از هر مواجهه به ایمنی غیرفعال یعنی HBIG نیاز دارد.**\n\n"
 "**و رژیم استاندارد برای نان‌رسپاندر واقعی: دو دوز HBIG به فاصله‌ی یک ماه.**\n\n"
 "**چرا دو دوز؟** چون **HBIG نیمه‌عمر حدود سه هفته** دارد. **یک دوز حدود یک ماه "
 "محافظت می‌دهد، ولی دوره‌ی کمون هپاتیت B تا ۶ ماه است.** پس دوز دوم، **پوشش را "
 "تمدید می‌کند** تا از پنجره‌ی پرخطر عبور کنیم.\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**واکسن + یک دوز HBIG** — ⚠️ این پاسخ **سؤال قبلی** بود، برای کسی که **یک سری** "
 "گرفته. اینجا واکسن **دو بار شکست خورده**.\n\n"
 "**شروع سری سوم واکسن** ❌ — تکرار کاری که **دو بار جواب نداده**، و **بدتر**: هیچ "
 "**محافظت فوری** نمی‌دهد. جراح **همین حالا** در معرض است.\n\n"
 "**پروفیلاکسی با تنوفوویر** ❌ — ⚠️ **تنوفوویر داروی درمان هپاتیت B مزمن است، نه "
 "پروفیلاکسی پس از مواجهه.** (در HIV به‌عنوان بخشی از PEP استفاده می‌شود، و همین "
 "منشأ سردرگمی است.)\n\n"
 "⚠️ **و یک نکته‌ی عملی برای چنین فردی: باید در پرونده‌ی پزشکی‌اش ثبت شود که "
 "نان‌رسپاندر است**، تا در هر مواجهه‌ی آینده **بدون اتلاف وقت** HBIG دریافت کند.",
 "A SURGEON who has sustained a NEEDLESTICK during an operation. He has had TWO SERIES OF HBV "
 "VACCINE and his antibody titre was FINALLY REPORTED AS ABOUT 6.\n\n"
 "WARNING, FIRST A PRINTING DEFECT IN THE BOOK: THE UNIT IS NOT PRINTED AT ALL. Page 315 gives only "
 "the bare number 6. THE CORRECT UNIT IS mIU/mL, and the PROTECTIVE THRESHOLD IS 10 mIU/mL. So the "
 "intended reading is 6 mIU/mL — BELOW THE THRESHOLD. (Fortunately this does not change the answer, "
 "since 6 on any reading is below 10.)\n\n"
 "WARNING, THE ANSWER: TWO DOSES OF HBIG ONE MONTH APART.\n\n"
 "This is the logical continuation of the non-responder question, one step further along. See the "
 "key difference:\n\n"
 "IN THE PREVIOUS QUESTION (q9852): the intern had had ONE series. The answer was A SECOND SERIES "
 "PLUS HBIG.\n\n"
 "WARNING, IN THIS QUESTION: the surgeon has had TWO FULL SERIES. The answer is different.\n\n"
 "WHY? Understand the logic:\n\n"
 "AFTER ONE FAILED SERIES: about 50 TO 70 PER CENT respond to A SECOND SERIES. So repeating is "
 "LOGICAL.\n\n"
 "AFTER TWO FAILED SERIES: WARNING, THE PERSON IS A 'TRUE NON-RESPONDER', AND THE CHANCE OF "
 "RESPONDING TO A THIRD SERIES IS VERY LOW. Continuing to vaccinate is REPEATING SOMETHING THAT HAS "
 "FAILED TWICE.\n\n"
 "SO WHAT SHOULD SUCH A PERSON DO? WARNING, THEY MUST ACCEPT THAT THEY WILL NEVER HAVE ACTIVE "
 "IMMUNITY, AND THAT AFTER EVERY EXPOSURE THEY NEED PASSIVE IMMUNITY — HBIG.\n\n"
 "AND THE STANDARD REGIMEN FOR A TRUE NON-RESPONDER: TWO DOSES OF HBIG ONE MONTH APART.\n\n"
 "WHY TWO DOSES? Because HBIG HAS A HALF-LIFE OF ABOUT THREE WEEKS. ONE DOSE PROTECTS FOR ABOUT A "
 "MONTH, BUT HEPATITIS B'S INCUBATION EXTENDS TO 6 MONTHS. So the second dose EXTENDS THE COVER "
 "through the high-risk window.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "VACCINE PLUS ONE DOSE OF HBIG — WARNING, that was the answer to the PREVIOUS question, for "
 "someone who had had ONE series. Here the vaccine HAS FAILED TWICE.\n\n"
 "START A THIRD VACCINE SERIES — repeating what has FAILED TWICE, and worse: it gives NO IMMEDIATE "
 "PROTECTION. The surgeon is exposed RIGHT NOW.\n\n"
 "TENOFOVIR PROPHYLAXIS — WARNING, TENOFOVIR TREATS CHRONIC HEPATITIS B; IT IS NOT POST-EXPOSURE "
 "PROPHYLAXIS. (It is used as part of HIV PEP, which is the source of the confusion.)\n\n"
 "WARNING, AND A PRACTICAL POINT FOR SUCH A PERSON: HIS NON-RESPONDER STATUS MUST BE RECORDED IN "
 "HIS MEDICAL FILE, so that at any future exposure he receives HBIG WITHOUT DELAY.",
 ["این پاسخ سؤال قبلی بود، برای کسی که یک سری واکسن گرفته؛ اینجا واکسن دو بار شکست خورده است.",
  "تکرار کاری که دو بار جواب نداده، و بدتر اینکه هیچ محافظت فوری نمی‌دهد.",
  "پاسخ صحیح — پس از دو سری ناموفق، فرد نان‌رسپاندر واقعی است و دو دوز HBIG لازم دارد.",
  "تنوفوویر داروی درمان هپاتیت B مزمن است، نه پروفیلاکسی پس از مواجهه."],
 ["That was the previous question's answer, for someone with one series; here the vaccine has failed twice.",
  "Repeating what has failed twice, and worse, it gives no immediate protection.",
  "Correct — after two failed series the person is a true non-responder and needs two doses of HBIG.",
  "Tenofovir treats chronic hepatitis B; it is not post-exposure prophylaxis."],
 "**یک سری ناموفق ← سری دوم. دو سری ناموفق ← نان‌رسپاندر واقعی و HBIG.**",
 "One failed series means try a second; two failed series means a true non-responder and HBIG.",
 [ACIP, H])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book39.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 39 lessons:', len(L))
