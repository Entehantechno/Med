# -*- coding: utf-8 -*-
"""Micro-lessons, batch 50 — salmonella and enteric fever, completing the
gastrointestinal chapter (84 of 84).

This is the THIRD chapter of the book finished end to end.

THE DIVISION THAT DECIDES EVERY SALMONELLA QUESTION
------------------------------------------------------
    NON-TYPHOIDAL SALMONELLA — gastroenteritis, from eggs, poultry, dairy
        Reservoir: ANIMALS.
        In a healthy host it USUALLY NEEDS NO ANTIBIOTIC. Treatment does not
        shorten the illness and PROLONGS THE CARRIER STATE, because it
        suppresses the competing normal flora.
        Treat only: infants and the elderly, the immunosuppressed, those with
        prostheses, valve disease or sickle-cell disease, and anyone with
        bacteraemia or severe or prolonged disease.

    TYPHOID (enteric fever) — Salmonella typhi
        Reservoir: MAN ALONE. There is no animal host, which is why the chain
        runs person to water to person, and why chronic human carriers (the
        gallbladder, classically) sustain it.
        ALWAYS treated.

THE TYPHOID PICTURE, ASKED FIVE TIMES IN THIS CHAPTER
--------------------------------------------------------
Learn it as a list, because each item appears in a different question:

    a week or more of fever, classically climbing in a STEPWISE fashion
    RELATIVE BRADYCARDIA (Faget's sign) — a pulse of 70 to 80 with a fever
        of 39 to 40. Most bacterial fevers raise the pulse by about 10 beats
        for each degree; typhoid does not.
    headache, abdominal pain, and CONSTIPATION more often than diarrhoea in
        adults — the diarrhoea, when it comes, is a SECOND-WEEK feature
    ROSE SPOTS — sparse, blanching, salmon-pink macules on the trunk
    hepatosplenomegaly and a coated tongue
    LEUCOPENIA — the finding that turns the diagnosis, because almost every
        other bacterial sepsis raises the white count

DIAGNOSIS AS A TIMELINE, WHICH TWO QUESTIONS TURN ON
-------------------------------------------------------
    week 1              BLOOD CULTURE, positive in 60 to 80 %
    weeks 2 to 3        blood culture yield falls; STOOL and URINE cultures rise
    ANY week, and
    DESPITE PRIOR
    ANTIBIOTICS         BONE MARROW CULTURE — the MOST SENSITIVE, over 90 %

That last property is the whole reason marrow is the answer in a partially
treated patient: the organism lives INSIDE macrophages of the
reticuloendothelial system, where antibiotic concentrations are lower and
where it persists after the blood has been sterilised.

And the WIDAL test is NOT the answer to any of these questions: poor
sensitivity, poor specificity, and many false positives in an endemic area
from previous exposure.

TREATMENT
    Empirically, and for severe disease: a THIRD-GENERATION CEPHALOSPORIN,
    ceftriaxone, given intravenously. Fluoroquinolone resistance is now
    widespread in South Asia and the Middle East, which is why ceftriaxone
    rather than ciprofloxacin heads today's empirical list. Azithromycin is
    the oral alternative for uncomplicated disease.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022) —
salmonellosis, including typhoid (enteric) fever.
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


HS = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — "
      "salmonellosis, including typhoid (enteric) fever")
H = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — "
     "acute infectious diarrhoeal diseases")
SREFS = [HS]
REFS = [H]

# ============================================ TWO REMAINING INFLAMMATORY ITEMS
DIV_FA = [
    "⚠️ **در سؤال‌های «کدام نمی‌تواند»، اول جعبه‌ی بیمار را تعیین کنید: التهابی یا غیرالتهابی؟**",
    "**و گلبول سفید مدفوع همان چیزی است که این تعیین را انجام می‌دهد.**",
    "**اسهال التهابی: گلبول سفید دارد، حجم کم، خون و بلغم، تب، و درگیری کولون.**",
    "**عامل‌ها: شیگلا، کمپیلوباکتر، سالمونلا، EHEC، یرسینیا، آمیب.**",
    "**اسهال غیرالتهابی: بدون گلبول سفید، حجم زیاد، آبکی، معمولاً بدون تب.**",
    "**و سازوکار آن سمّی است، نه تهاجمی.**",
    "⚠️ **و ویبریوکلرا همیشه استثنای سؤال‌های التهابی است.**",
    "**چون سم‌ساز خالص است: هرگز تهاجم نمی‌کند.**",
    "**پس نه گلبول سفید می‌دهد، نه خون، نه تب.**",
    "**و همین سه «نبود»، آن را از هر تابلوی دیسانتریک بیرون می‌گذارد.**",
    "**در برابر آن، سالمونلای غیرتیفی تهاجمی است و اسهال التهابی می‌دهد.**",
    "⚠️ **پس دو سالمونلا را قاطی نکنید: غیرتیفی روده را می‌زند، تیفی سیستمیک است.**",
]
DIV_EN = [
    "WARNING: IN 'WHICH CANNOT' QUESTIONS, FIRST DECIDE THE PATIENT'S BOX: inflammatory or not?",
    "And the stool white cell count is what makes that decision.",
    "INFLAMMATORY diarrhoea: white cells present, small volume, blood and mucus, fever, colonic involvement.",
    "The organisms: Shigella, Campylobacter, Salmonella, EHEC, Yersinia, Entamoeba.",
    "NON-INFLAMMATORY diarrhoea: no white cells, large volume, watery, usually no fever.",
    "And its mechanism is toxin-mediated rather than invasive.",
    "WARNING, AND VIBRIO CHOLERAE IS ALWAYS THE EXCEPTION in inflammatory questions.",
    "Because it is a pure toxin producer: it never invades.",
    "So it produces no white cells, no blood and no fever.",
    "And those three absences put it outside any dysenteric picture.",
    "By contrast, non-typhoidal Salmonella IS invasive and causes inflammatory diarrhoea.",
    "WARNING, SO DO NOT CONFUSE THE TWO SALMONELLAS: non-typhoidal hits the bowel, typhi is systemic.",
]

add("book:293", "vignette", "easy",
    "**اسهال چرکی با گلبول سفید فراوان: ویبریوکلرا نمی‌تواند باشد.**",
    "Purulent diarrhoea with abundant white cells: Vibrio cholerae cannot be the cause.",
    DIV_FA,
    DIV_EN,
    "این سؤال همان قاعده‌ی بنیادی فصل را می‌سنجد، و پاسخ آن همیشه یکی است.\n\n"
    "**بیمار: دانش‌آموز ۱۷ ساله پس از شرکت در یک اردوی آموزشی، با تب، استفراغ، درد شکم و "
    "اسهال مکرر چرکی با حجم کم. در آزمایش مدفوع WBC و RBC فراوان.**\n\n"
    "**جعبه‌ی بیمار را تعیین کنید:**\n\n"
    "**اسهال چرکی** ✔ · **حجم کم** ✔ · **دفعات زیاد** ✔ · **تب** ✔ · **گلبول سفید و قرمز "
    "فراوان** ✔\n\n"
    "⚠️ **این پنج ویژگی با هم یعنی: اسهال التهابی (دیسانتری)، با درگیری کولون.**\n\n"
    "**پس هر ارگانیسم مهاجمی می‌تواند عامل باشد:**\n\n"
    "**شیگلا دیسانتری** — نمونه‌ی اعلای اسهال التهابی. و **در اردو بسیار محتمل است**، چون "
    "**دوز عفونی آن ۱۰ تا ۱۰۰ ارگانیسم** است و از فرد به فرد منتقل می‌شود.\n\n"
    "**کمپیلوباکتر ژژونی** — تهاجمی، از **مرغ نیم‌پز و شیر غیرپاستوریزه**.\n\n"
    "⚠️ **سالمونلا انتریتیدیس** — **تهاجمی است** و اسهال التهابی می‌دهد. از **تخم‌مرغ و مرغ** "
    "می‌آید — و در اردوی آموزشی با غذای گروهی، کاملاً محتمل.\n\n"
    "**و استثنا: ویبریوکلرا.**\n\n"
    "**چرا؟ چون وبا یک بیماری کاملاً سم‌محور است.** ویبریوکلرا **هرگز مخاط را تهاجم نمی‌کند**؛ "
    "فقط در لومن روده‌ی باریک می‌ماند و سم ترشح می‌کند.\n\n"
    "**و نتیجه‌ی مستقیم آن، سه «نبود» است:**\n\n"
    "**بدون گلبول سفید در مدفوع** (چون التهابی نیست) · **بدون خون** (چون زخمی نیست) · "
    "**بدون تب** (چون پاسخ التهابی سیستمیک راه نمی‌افتد).\n\n"
    "⚠️ **و این بیمار هر سه را دارد: گلبول سفید فراوان، گلبول قرمز فراوان، و تب.** پس وبا "
    "**از هر سه جهت رد می‌شود**.\n\n"
    "**به‌علاوه، وبا حجم زیاد می‌دهد، نه «حجم کم» که در سؤال آمده.**\n\n"
    "**درس روش‌شناختی: در سؤال‌های «کدام نمی‌تواند»، به‌جای گشتن دنبال پاسخ، اول جعبه‌ی بیمار "
    "را تعیین کنید. سپس عاملی که در جعبه‌ی مخالف است، خودش را نشان می‌دهد.**",
    "This question tests the chapter's fundamental rule, and its answer is always the same.\n\n"
    "THE PATIENT: a 17-year-old student who, after attending an educational camp, has fever, vomiting, "
    "abdominal pain and frequent SMALL-VOLUME PURULENT diarrhoea. The stool shows ABUNDANT WBC AND RBC.\n\n"
    "DETERMINE THE PATIENT'S BOX:\n\n"
    "PURULENT DIARRHOEA, SMALL VOLUME, HIGH FREQUENCY, FEVER, ABUNDANT WHITE AND RED CELLS.\n\n"
    "WARNING, THOSE FIVE FEATURES TOGETHER MEAN: INFLAMMATORY DIARRHOEA (DYSENTERY) with colonic "
    "involvement.\n\n"
    "SO ANY INVASIVE ORGANISM COULD BE RESPONSIBLE:\n\n"
    "SHIGELLA DYSENTERIAE — the archetype of inflammatory diarrhoea. AND HIGHLY LIKELY AT A CAMP, "
    "because ITS INFECTIVE DOSE IS 10 TO 100 ORGANISMS and it spreads person to person.\n\n"
    "CAMPYLOBACTER JEJUNI — invasive, from UNDERCOOKED POULTRY AND UNPASTEURISED MILK.\n\n"
    "WARNING, SALMONELLA ENTERITIDIS — IT IS INVASIVE and causes inflammatory diarrhoea. It comes from "
    "EGGS AND POULTRY — entirely plausible at a camp with communal catering.\n\n"
    "AND THE EXCEPTION: VIBRIO CHOLERAE.\n\n"
    "WHY? BECAUSE CHOLERA IS A PURELY TOXIN-MEDIATED DISEASE. Vibrio cholerae NEVER INVADES THE MUCOSA; "
    "it stays in the small bowel lumen and secretes toxin.\n\n"
    "AND THE DIRECT CONSEQUENCE IS THREE ABSENCES:\n\n"
    "NO STOOL WHITE CELLS (it is not inflammatory), NO BLOOD (nothing is ulcerated), NO FEVER (no "
    "systemic inflammatory response is triggered).\n\n"
    "WARNING, AND THIS PATIENT HAS ALL THREE: abundant white cells, abundant red cells, and fever. So "
    "cholera IS EXCLUDED ON ALL THREE COUNTS.\n\n"
    "MOREOVER, CHOLERA GIVES LARGE VOLUMES, not the 'small volume' the question states.\n\n"
    "THE METHODOLOGICAL LESSON: in 'which cannot' questions, instead of hunting for the answer, FIRST "
    "DETERMINE THE PATIENT'S BOX. Then the organism from the opposite box declares itself.",
    ["پاسخ صحیح — وبا سم‌ساز خالص است: نه گلبول سفید، نه خون، نه تب، و حجم آن زیاد است.",
     "نمونه‌ی اعلای اسهال التهابی، و در اردو بسیار محتمل به‌دلیل دوز عفونی پایین.",
     "تهاجمی است و اسهال التهابی می‌دهد؛ از مرغ نیم‌پز و شیر غیرپاستوریزه.",
     "تهاجمی است و اسهال التهابی می‌دهد؛ از تخم‌مرغ و مرغ در غذای گروهی."],
    ["Correct — cholera is a pure toxin producer: no white cells, no blood, no fever, and large volumes.",
     "The archetype of inflammatory diarrhoea, and highly likely at a camp given its low infective dose.",
     "Invasive and causes inflammatory diarrhoea; from undercooked poultry and unpasteurised milk.",
     "Invasive and causes inflammatory diarrhoea; from eggs and poultry in communal catering."],
    "**اول جعبه‌ی بیمار را تعیین کنید؛ عاملِ جعبه‌ی مخالف، خودش را نشان می‌دهد.**",
    "First determine the patient's box; the organism from the opposite box declares itself.",
    REFS)

add("book:294", "recall", "easy",
    "**اسهال خونی با گلبول سفید ۲۰ تا ۲۵: باز هم ویبریوکلرا نمی‌تواند باشد.**",
    "Bloody diarrhoea with 20 to 25 white cells: again, Vibrio cholerae cannot be the cause.",
    DIV_FA + [
        "**این سؤال کوتاه‌ترین شکل همان قاعده است.**",
        "**اسهال خونی به‌علاوه‌ی گلبول سفید ۲۰ تا ۲۵ در مدفوع.**",
        "⚠️ **دو یافته، و هر دو تهاجم را قطعی می‌کنند.**",
        "**پس هر سه ارگانیسم مهاجم می‌توانند عامل باشند.**",
        "**EHEC خونی است و سم شیگا دارد.**",
        "**کمپیلوباکتر تهاجمی است و اسهال خونی می‌دهد.**",
        "**و آمیب هیستولیتیکا با تهاجم مستقیم، زخم فلاسک‌شکل می‌سازد.**",
        "**و فقط وبا بیرون می‌ماند، چون هرگز تهاجم نمی‌کند.**",
    ],
    DIV_EN + [
        "This question is the shortest form of the same rule.",
        "Bloody diarrhoea plus 20 to 25 white cells in the stool.",
        "WARNING, TWO FINDINGS, and both make invasion certain.",
        "So all three invasive organisms could be responsible.",
        "EHEC is bloody and carries Shiga toxin.",
        "Campylobacter is invasive and causes bloody diarrhoea.",
        "And Entamoeba histolytica invades directly, creating flask-shaped ulcers.",
        "And only cholera stands outside, because it never invades.",
    ],
    "این کوتاه‌ترین سؤال فصل است و **همان قاعده را بدون هیچ زینتی** می‌پرسد.\n\n"
    "**موقعیت: بیماری با اسهال خونی مراجعه کرده و در آزمایش مدفوع، گلبول سفید ۲۰ تا ۲۵ "
    "گزارش شده. کدام نمی‌تواند علت باشد؟**\n\n"
    "**دو یافته، و هر دو در یک جهت:**\n\n"
    "**اسهال خونی** = مخاط **زخم شده** است. **گلبول سفید ۲۰ تا ۲۵** = **التهاب** برقرار است.\n\n"
    "⚠️ **پس این قطعاً اسهال التهابی است، و عامل آن باید تهاجمی باشد.**\n\n"
    "**سه گزینه‌ای که می‌توانند:**\n\n"
    "**ای‌کلای انتروهموراژیک (EHEC)** — اسهال **خونی** می‌دهد و **سم شیگا** دارد. (نکته: EHEC "
    "معمولاً **تب کمی** می‌دهد یا بدون تب است، ولی **خون و گلبول سفید** دارد.)\n\n"
    "**کمپیلوباکتر ژژونی** — **تهاجمی** است، اسهال خونی می‌دهد، و **شایع‌ترین علت اسهال "
    "باکتریایی** در بسیاری از کشورهاست.\n\n"
    "⚠️ **آمیب هیستولیتیکا** — با **تهاجم مستقیم بافتی** مخاط را می‌خورد و **زخم‌های "
    "فلاسک‌شکل** می‌سازد. تروفوزوئیت **گلبول قرمز می‌بلعد**، و همین اریتروفاگوسیتوز امضای "
    "گونه‌ی مهاجم است.\n\n"
    "**و استثنا: ویبریوکلرا.**\n\n"
    "**چرا؟ چون وبا هرگز تهاجم نمی‌کند.** سم وبا فقط **ترشح آب و الکترولیت** را تحریک می‌کند؛ "
    "**هیچ سلولی کشته نمی‌شود و هیچ مخاطی زخم نمی‌شود**.\n\n"
    "**پس مدفوع وبا:** **هرگز خونی نیست** (چون زخمی وجود ندارد) و **هرگز گلبول سفید ندارد** "
    "(چون التهابی وجود ندارد).\n\n"
    "⚠️ **و این بیمار هر دو را دارد. پس وبا از پایه رد می‌شود.**\n\n"
    "**جمع‌بندی این دو سؤال متوالی: کتاب همین قاعده را دو بار پشت سر هم پرسیده. پیام روشن "
    "است — یک بار درست یاد بگیرید و هر دو نمره را ببرید. وبا هرگز التهابی نیست.**",
    "This is the shortest question in the chapter and asks THE SAME RULE WITHOUT ANY ORNAMENT.\n\n"
    "THE SITUATION: a patient presents with bloody diarrhoea and the stool shows 20 to 25 white cells. "
    "Which cannot be the cause?\n\n"
    "TWO FINDINGS, BOTH POINTING THE SAME WAY:\n\n"
    "BLOODY DIARRHOEA means THE MUCOSA IS ULCERATED. WHITE CELLS OF 20 TO 25 mean INFLAMMATION is "
    "present.\n\n"
    "WARNING, SO THIS IS DEFINITELY INFLAMMATORY DIARRHOEA, and its cause must be invasive.\n\n"
    "THE THREE THAT CAN:\n\n"
    "ENTEROHAEMORRHAGIC E. COLI (EHEC) — causes BLOODY diarrhoea and carries SHIGA TOXIN. (Note: EHEC "
    "usually causes LITTLE OR NO FEVER, but it does produce BLOOD AND WHITE CELLS.)\n\n"
    "CAMPYLOBACTER JEJUNI — INVASIVE, causes bloody diarrhoea, and is THE COMMONEST CAUSE OF BACTERIAL "
    "DIARRHOEA in many countries.\n\n"
    "WARNING, ENTAMOEBA HISTOLYTICA — it eats into the mucosa by DIRECT TISSUE INVASION and creates "
    "FLASK-SHAPED ULCERS. The trophozoite INGESTS RED CELLS, and that erythrophagocytosis is the "
    "signature of the invasive species.\n\n"
    "AND THE EXCEPTION: VIBRIO CHOLERAE.\n\n"
    "WHY? BECAUSE CHOLERA NEVER INVADES. Cholera toxin merely stimulates SECRETION OF WATER AND "
    "ELECTROLYTES; NO CELL IS KILLED AND NO MUCOSA IS ULCERATED.\n\n"
    "SO CHOLERA STOOL IS NEVER BLOODY (there is no ulcer) and NEVER CONTAINS WHITE CELLS (there is no "
    "inflammation).\n\n"
    "WARNING, AND THIS PATIENT HAS BOTH. So cholera IS EXCLUDED OUTRIGHT.\n\n"
    "SUMMING UP THESE TWO CONSECUTIVE QUESTIONS: the book has asked the same rule twice in a row. The "
    "message is clear — LEARN IT PROPERLY ONCE AND TAKE BOTH MARKS. CHOLERA IS NEVER INFLAMMATORY.",
    ["پاسخ صحیح — وبا هرگز تهاجم نمی‌کند، پس نه خون می‌دهد و نه گلبول سفید.",
     "اسهال خونی می‌دهد و سم شیگا دارد؛ کاملاً می‌تواند عامل باشد.",
     "تهاجمی است و شایع‌ترین علت اسهال باکتریایی در بسیاری کشورهاست.",
     "با تهاجم مستقیم بافتی زخم فلاسک‌شکل می‌سازد و اسهال خونی می‌دهد."],
    ["Correct — cholera never invades, so it produces neither blood nor white cells.",
     "Causes bloody diarrhoea and carries Shiga toxin; entirely possible.",
     "Invasive and the commonest cause of bacterial diarrhoea in many countries.",
     "Invades tissue directly, creating flask-shaped ulcers and bloody diarrhoea."],
    "**وبا هرگز التهابی نیست — نه خون، نه گلبول سفید، نه تب.**",
    "Cholera is never inflammatory — no blood, no white cells, no fever.",
    REFS)

# ==================================================== TYPHOID: SHARED
TY_FA = [
    "⚠️ **تب تیفوئید را با یک فهرست بشناسید، چون هر جزء آن در سؤالی جداگانه می‌آید.**",
    "**یک هفته یا بیشتر تب، که کلاسیک به‌صورت پلکانی بالا می‌رود.**",
    "**برادی‌کاردی نسبی، یا علامت فاژه: نبض ۷۰ تا ۸۰ با تب ۳۹ تا ۴۰.**",
    "**در بیشتر عفونت‌های باکتریایی، هر درجه تب نبض را حدود ده ضربه بالا می‌برد.**",
    "⚠️ **ولی در تیفوئید این اتفاق نمی‌افتد — و همین آن را تشخیصی می‌کند.**",
    "**سردرد، درد شکم، و در بزرگ‌سال یبوست شایع‌تر از اسهال است.**",
    "**اسهال، وقتی بیاید، یافته‌ی هفته‌ی دوم است.**",
    "**راش رزئولا: ماکول‌های کم‌تعداد، صورتی-سالمون، و محوشونده با فشار، روی تنه.**",
    "**هپاتواسپلنومگالی و زبان باردار یا شیاردار.**",
    "⚠️ **و لکوپنی، که تشخیص را برمی‌گرداند.**",
    "**چون تقریباً هر سپسیس باکتریایی دیگری گلبول سفید را بالا می‌برد.**",
    "**پس تب بالا با گلبول سفید پایین، یک ترکیب غیرمعمول و پرمعناست.**",
    "**و مخزن سالمونلا تیفی فقط انسان است — هیچ میزبان حیوانی ندارد.**",
    "**به همین دلیل زنجیره از انسان به آب به انسان می‌رود.**",
    "⚠️ **و ناقلان مزمن انسانی — کلاسیک از راه کیسه‌ی صفرا — بیماری را زنده نگه می‌دارند.**",
]
TY_EN = [
    "WARNING: RECOGNISE TYPHOID BY A LIST, because each item appears in a different question.",
    "A week or more of fever, classically climbing in a STEPWISE fashion.",
    "RELATIVE BRADYCARDIA, or Faget's sign: a pulse of 70 to 80 with a fever of 39 to 40.",
    "In most bacterial infections each degree of fever raises the pulse by about ten beats.",
    "WARNING, BUT IN TYPHOID THAT DOES NOT HAPPEN — and that is what makes it diagnostic.",
    "Headache, abdominal pain, and in adults CONSTIPATION is commoner than diarrhoea.",
    "Diarrhoea, when it comes, is a SECOND-WEEK feature.",
    "ROSE SPOTS: sparse, salmon-pink, blanching macules on the trunk.",
    "Hepatosplenomegaly and a coated or furred tongue.",
    "WARNING, AND LEUCOPENIA, which turns the diagnosis.",
    "Because almost every other bacterial sepsis raises the white count.",
    "So a high fever with a low white count is an unusual and meaningful combination.",
    "And the reservoir of Salmonella typhi is MAN ALONE — it has no animal host.",
    "Which is why the chain runs person to water to person.",
    "WARNING, AND CHRONIC HUMAN CARRIERS — classically via the gallbladder — keep the disease alive.",
]

add("book:423", "recall", "easy",
    "**مخزن سالمونلا تیفی فقط انسان است — هیچ میزبان حیوانی ندارد.**",
    "The reservoir of Salmonella typhi is MAN ALONE — it has no animal host.",
    TY_FA,
    TY_EN,
    "این سؤال کوتاه است ولی یک **تفاوت اپیدمیولوژیک بنیادی** را می‌سنجد که پیامدهای عملی "
    "زیادی دارد.\n\n"
    "⚠️ **مخزن سالمونلا تیفی فقط انسان است.**\n\n"
    "**و این آن را از همه‌ی سالمونلاهای دیگر جدا می‌کند:**\n\n"
    "**سالمونلاهای غیرتیفی** (انتریتیدیس، تیفی‌موریوم و صدها سروتیپ دیگر) **مخزن حیوانی** "
    "دارند: **مرغ، تخم‌مرغ، گاو، خزندگان**. انسان از **غذای آلوده‌ی حیوانی** آلوده می‌شود.\n\n"
    "**سالمونلا تیفی مخزن حیوانی ندارد.** فقط در **انسان** زندگی می‌کند.\n\n"
    "**و این چه پیامدهایی دارد؟ چهار پیامد عملی که ارزش دانستن دارند:**\n\n"
    "**یک — زنجیره‌ی انتقال:** انسان → **آب یا غذای آلوده به مدفوع انسان** → انسان. "
    "پس تیفوئید **بیماری بهداشت نامناسب** است، نه بیماری غذای حیوانی.\n\n"
    "⚠️ **دو — نقش ناقل مزمن.** چون هیچ مخزن حیوانی وجود ندارد، **بیماری فقط با ناقلان "
    "انسانی زنده می‌ماند**. حدود **۱ تا ۵ درصد** بیماران **ناقل مزمن** می‌شوند — باکتری در "
    "**کیسه‌ی صفرا** (اغلب همراه با سنگ صفراوی) لانه می‌کند و ماه‌ها یا سال‌ها دفع می‌شود. "
    "**مشهورترین نمونه، «مری تیفوئیدی» است** که به‌عنوان آشپز، ده‌ها نفر را آلوده کرد.\n\n"
    "**سه — امکان ریشه‌کنی.** بیماری‌ای که فقط مخزن انسانی دارد، **از نظر نظری قابل ریشه‌کنی "
    "است** — برخلاف سالمونلای غیرتیفی که تا وقتی مرغ و گاو هستند، خواهد بود.\n\n"
    "**چهار — کنترل.** کنترل تیفوئید یعنی **آب سالم، فاضلاب بهداشتی، و شناسایی ناقلان** — "
    "نه کنترل دامداری.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**پرندگان:** مخزن **سالمونلاهای غیرتیفی** هستند (به‌ویژه مرغ و تخم‌مرغ)، نه سالمونلا تیفی.\n\n"
    "**گاو:** مخزن سالمونلاهای غیرتیفی، و همچنین بروسلا، ای‌کلای O157:H7 و لیستریا.\n\n"
    "**گوسفند:** مخزن بروسلا، اکینوکوکوس (به‌عنوان میزبان واسط) و توکسوپلاسما — نه تیفوئید.",
    "This question is short but tests A FUNDAMENTAL EPIDEMIOLOGICAL DIFFERENCE with many practical "
    "consequences.\n\n"
    "WARNING, THE RESERVOIR OF SALMONELLA TYPHI IS MAN ALONE.\n\n"
    "AND THIS SEPARATES IT FROM ALL OTHER SALMONELLAE:\n\n"
    "NON-TYPHOIDAL SALMONELLAE (enteritidis, typhimurium and hundreds of other serotypes) have ANIMAL "
    "RESERVOIRS: POULTRY, EGGS, CATTLE, REPTILES. Humans are infected from CONTAMINATED ANIMAL FOOD.\n\n"
    "SALMONELLA TYPHI HAS NO ANIMAL RESERVOIR. It lives only in MAN.\n\n"
    "AND WHAT FOLLOWS FROM THAT? Four practical consequences worth knowing:\n\n"
    "ONE — THE TRANSMISSION CHAIN: person, then WATER OR FOOD CONTAMINATED WITH HUMAN FAECES, then "
    "person. So typhoid is A DISEASE OF POOR SANITATION, not of animal food.\n\n"
    "WARNING, TWO — THE ROLE OF THE CHRONIC CARRIER. Since there is no animal reservoir, THE DISEASE "
    "SURVIVES ONLY THROUGH HUMAN CARRIERS. About 1 TO 5 PER CENT of patients become CHRONIC CARRIERS — "
    "the organism lodges in the GALLBLADDER (often with gallstones) and is shed for months or years. "
    "THE MOST FAMOUS EXAMPLE IS 'TYPHOID MARY', who as a cook infected dozens of people.\n\n"
    "THREE — THE POSSIBILITY OF ERADICATION. A disease with only a human reservoir IS THEORETICALLY "
    "ERADICABLE — unlike non-typhoidal Salmonella, which will exist as long as poultry and cattle do.\n\n"
    "FOUR — CONTROL. Controlling typhoid means CLEAN WATER, SANITATION AND IDENTIFYING CARRIERS — not "
    "livestock control.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "BIRDS: reservoirs of NON-TYPHOIDAL Salmonellae (especially poultry and eggs), not S. typhi.\n\n"
    "CATTLE: reservoirs of non-typhoidal Salmonellae, and also of Brucella, E. coli O157:H7 and Listeria.\n\n"
    "SHEEP: reservoirs of Brucella, Echinococcus (as intermediate host) and Toxoplasma — not typhoid.",
    ["مخزن سالمونلاهای غیرتیفی هستند، به‌ویژه مرغ و تخم‌مرغ، نه سالمونلا تیفی.",
     "مخزن سالمونلاهای غیرتیفی و همچنین بروسلا و ای‌کلای O157؛ نه تیفوئید.",
     "مخزن بروسلا و اکینوکوکوس و توکسوپلاسما، نه سالمونلا تیفی.",
     "پاسخ صحیح — سالمونلا تیفی هیچ مخزن حیوانی ندارد و فقط در انسان زندگی می‌کند."],
    ["Reservoirs of non-typhoidal Salmonellae, especially poultry and eggs, not S. typhi.",
     "Reservoirs of non-typhoidal Salmonellae and of Brucella and E. coli O157; not typhoid.",
     "Reservoirs of Brucella, Echinococcus and Toxoplasma, not Salmonella typhi.",
     "Correct — Salmonella typhi has no animal reservoir and lives only in man."],
    "**تیفوئید فقط مخزن انسانی دارد — پس ناقل مزمن، بیماری را زنده نگه می‌دارد.**",
    "Typhoid has only a human reservoir — so the chronic carrier keeps the disease alive.",
    SREFS)

add("book:424", "vignette", "easy",
    "**تب ۴۰ با نبض ۸۰: برادی‌کاردی نسبی، امضای تیفوئید.**",
    "A fever of 40 with a pulse of 80: RELATIVE BRADYCARDIA, the signature of typhoid.",
    TY_FA,
    TY_EN,
    "این سؤال یک **نشانه‌ی حیاتی** را به یک تشخیص تبدیل می‌کند — و آن نشانه فقط با **حساب "
    "کردن** دیده می‌شود.\n\n"
    "**بیمار: مرد ۲۸ ساله با تب، درد شکم، سردرد و کاهش اشتها از یک هفته قبل. در معاینه طحال "
    "قابل لمس و زبان شیاردار، و بثورات ماکولوپاپولر در قفسه‌ی سینه و تنه که با فشار محو "
    "می‌گردد. دما ۴۰ درجه، نبض ۸۰.**\n\n"
    "⚠️ **کلید سؤال در دو عدد است: T=40 و PR=80.**\n\n"
    "**چرا این ترکیب غیرعادی است؟ یک قاعده‌ی فیزیولوژیک را بدانید:**\n\n"
    "**در بیشتر عفونت‌های باکتریایی، هر درجه‌ی سانتی‌گراد افزایش دما، نبض را حدود ۱۰ ضربه در "
    "دقیقه بالا می‌برد.** پس در بیمار با تب ۴۰ درجه (یعنی ۳ درجه بالاتر از طبیعی)، انتظار "
    "داریم نبض حدود **۱۰۰ تا ۱۱۰** باشد.\n\n"
    "**ولی نبض این بیمار ۸۰ است.**\n\n"
    "⚠️ **این «برادی‌کاردی نسبی» یا «علامت فاژه» است — و یکی از تشخیصی‌ترین یافته‌های "
    "تیفوئید.**\n\n"
    "**و بقیه‌ی تابلو آن را تأیید می‌کند:**\n\n"
    "**یک هفته تب** ✔ (تیفوئید بیماری تدریجی است، نه حاد) · **سردرد و درد شکم و بی‌اشتهایی** ✔ "
    "· **طحال قابل لمس** ✔ · **زبان شیاردار (باردار)** ✔ · و ⚠️ **بثورات ماکولوپاپولر روی "
    "تنه که با فشار محو می‌شود** = **راش رزئولا (rose spots)**، که ماکول‌های کم‌تعداد "
    "صورتی-سالمون روی تنه‌اند.\n\n"
    "**پس تشخیص: تیفوئید.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**بروسلوز:** تب مواج، **تعریق با بوی خاص**، درد مفاصل و کمر، و سابقه‌ی **لبنیات "
    "غیرپاستوریزه یا تماس دامی**. **راش رزئولا نمی‌دهد**، و برادی‌کاردی نسبی مشخصه‌ی آن نیست.\n\n"
    "⚠️ **مننگوکوکسمی:** تابلوی آن **کاملاً متفاوت و بسیار حادتر** است: شروع **ناگهانی**، "
    "**راش پتشیال یا پورپورا** (که **با فشار محو نمی‌شود** — دقیقاً برعکس این بیمار)، و "
    "**پیشرفت سریع به شوک**. یک هفته تب تدریجی با آن نمی‌خواند.\n\n"
    "**لپتوسپیروز:** **تزریق ملتحمه (چشم قرمز)**، **میالژی شدید به‌ویژه در ساق پا**، و "
    "سابقه‌ی **تماس با آب آلوده به ادرار جوندگان**. راش آن هم متفاوت است.\n\n"
    "**درس: هر بار که تب بالا و نبض نسبتاً پایین دیدید، حساب کنید. برادی‌کاردی نسبی یک "
    "سرنخ رایگان است که بسیاری از آن می‌گذرند.**",
    "This question turns A VITAL SIGN into a diagnosis — and that sign is visible only BY CALCULATING.\n\n"
    "THE PATIENT: a 28-year-old man with fever, abdominal pain, headache and anorexia for a week. "
    "Examination shows a palpable spleen and a FURRED TONGUE, and MACULOPAPULAR LESIONS on the chest "
    "and trunk THAT BLANCH ON PRESSURE. Temperature 40, pulse 80.\n\n"
    "WARNING, THE KEY IS IN TWO NUMBERS: T=40 and PR=80.\n\n"
    "WHY IS THAT COMBINATION UNUSUAL? Know one physiological rule:\n\n"
    "IN MOST BACTERIAL INFECTIONS, EACH DEGREE CELSIUS OF FEVER RAISES THE PULSE BY ABOUT 10 BEATS PER "
    "MINUTE. So in a patient with a fever of 40 (three degrees above normal) we would expect a pulse of "
    "about 100 TO 110.\n\n"
    "BUT THIS PATIENT'S PULSE IS 80.\n\n"
    "WARNING, THIS IS 'RELATIVE BRADYCARDIA' OR 'FAGET'S SIGN' — one of the most diagnostic findings in "
    "typhoid.\n\n"
    "AND THE REST OF THE PICTURE CONFIRMS IT:\n\n"
    "A WEEK OF FEVER (typhoid is gradual, not acute), HEADACHE, ABDOMINAL PAIN AND ANOREXIA, A PALPABLE "
    "SPLEEN, A FURRED TONGUE, and WARNING, MACULOPAPULAR LESIONS ON THE TRUNK THAT BLANCH ON PRESSURE = "
    "ROSE SPOTS, sparse salmon-pink macules on the trunk.\n\n"
    "SO THE DIAGNOSIS: TYPHOID.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "BRUCELLOSIS: undulant fever, DISTINCTIVELY MALODOROUS SWEAT, joint and back pain, and a history of "
    "UNPASTEURISED DAIRY OR ANIMAL CONTACT. IT DOES NOT CAUSE ROSE SPOTS, and relative bradycardia is "
    "not characteristic.\n\n"
    "WARNING, MENINGOCOCCAEMIA: its picture is ENTIRELY DIFFERENT AND FAR MORE ACUTE: SUDDEN onset, a "
    "PETECHIAL OR PURPURIC RASH (which DOES NOT BLANCH ON PRESSURE — the exact opposite of this "
    "patient), and RAPID PROGRESSION TO SHOCK. A week of gradual fever does not fit.\n\n"
    "LEPTOSPIROSIS: CONJUNCTIVAL SUFFUSION (red eyes), SEVERE MYALGIA especially in the calves, and a "
    "history of CONTACT WITH WATER CONTAMINATED BY RODENT URINE. Its rash also differs.\n\n"
    "THE LESSON: WHENEVER YOU SEE A HIGH FEVER WITH A RELATIVELY LOW PULSE, DO THE ARITHMETIC. RELATIVE "
    "BRADYCARDIA IS A FREE CLUE THAT MANY PEOPLE WALK PAST.",
    ["پاسخ صحیح — برادی‌کاردی نسبی، راش رزئولا، زبان باردار و اسپلنومگالی، همه تیفوئید.",
     "تب مواج و درد مفاصل می‌دهد ولی راش رزئولا و برادی‌کاردی نسبی مشخصه‌ی آن نیست.",
     "شروع ناگهانی با راش پتشیال که با فشار محو نمی‌شود — دقیقاً برعکس این بیمار.",
     "تزریق ملتحمه و میالژی شدید ساق پا دارد، با سابقه‌ی تماس با آب آلوده."],
    ["Correct — relative bradycardia, rose spots, a furred tongue and splenomegaly all mean typhoid.",
     "Causes undulant fever and joint pain but neither rose spots nor relative bradycardia.",
     "Sudden onset with a petechial rash that does NOT blanch — the exact opposite of this patient.",
     "Causes conjunctival suffusion and severe calf myalgia, with contaminated water exposure."],
    "**هر درجه تب، نبض را ۱۰ ضربه بالا می‌برد — مگر در تیفوئید.**",
    "Each degree of fever raises the pulse by ten beats — except in typhoid.",
    SREFS)

add("book:425", "vignette", "easy",
    "**آب چشمه، تب یک‌هفته‌ای، زبان باردار و راش تنه: تیفوئید.**",
    "Spring water, a week of fever, a furred tongue and a trunk rash: TYPHOID.",
    TY_FA + [
        "**سابقه‌ی مصرف آب چشمه در این سؤال یک سرنخ اپیدمیولوژیک است.**",
        "**چون تیفوئید از راه آب آلوده به مدفوع انسان منتقل می‌شود.**",
        "⚠️ **و آب چشمه یا آب غیرلوله‌کشی، منبع کلاسیک آن است.**",
        "**علائم تحریک مننژ ندارد، که مننژیت را کنار می‌گذارد.**",
        "**و هوشیار است، که بیماری شدید سیستمیک دیگری را کم‌محتمل می‌کند.**",
        "**زبان باردار و طحال قابل لمس، دو یافته‌ی معاینه‌ای تیفوئیدند.**",
        "**و راش ماکولوپاپولر بخش فوقانی شکم، همان رزئولاست.**",
    ],
    TY_EN + [
        "The history of drinking spring water is an epidemiological clue here.",
        "Because typhoid is transmitted through water contaminated with human faeces.",
        "WARNING, AND SPRING OR UNPIPED WATER is its classic source.",
        "She has no meningeal signs, which sets meningitis aside.",
        "And she is alert, which makes another severe systemic illness less likely.",
        "A furred tongue and a palpable spleen are two typhoid examination findings.",
        "And the maculopapular rash on the upper abdomen is the rose spot.",
    ],
    "این سؤال همان تابلوی تیفوئید را با یک **سرنخ اپیدمیولوژیک** ترکیب می‌کند.\n\n"
    "**بیمار: خانم ۲۵ ساله با سابقه‌ی مصرف آب چشمه، با تب، درد شکمی و سردرد از یک هفته قبل. "
    "در معاینه: تب ۳۹ درجه، زبان باردار، طحال قابل لمس، ولی علائم تحریک مننژ ندارد. بیمار "
    "هوشیار است و چند راش ماکولوپاپولر در بخش فوقانی شکم دیده می‌شود.**\n\n"
    "⚠️ **سرنخ اپیدمیولوژیک: آب چشمه.**\n\n"
    "**چرا این مهم است؟** چون **مخزن سالمونلا تیفی فقط انسان است** و انتقال آن از راه "
    "**آب یا غذای آلوده به مدفوع انسان** رخ می‌دهد. **آب چشمه یا هر آب غیرلوله‌کشی و "
    "تصفیه‌نشده، منبع کلاسیک تیفوئید است.**\n\n"
    "**و بقیه‌ی تابلو، تیفوئید کلاسیک است:**\n\n"
    "**یک هفته تب** ✔ (تدریجی، نه حاد) · **سردرد و درد شکم** ✔ · **زبان باردار** ✔ · "
    "**طحال قابل لمس** ✔ · **راش ماکولوپاپولر روی شکم** ✔ = **رزئولا**.\n\n"
    "**و دو «نبود» که تشخیص‌های دیگر را کنار می‌گذارند:**\n\n"
    "**علائم تحریک مننژ ندارد** → مننژیت کم‌محتمل. **هوشیار است** → بیماری شدید سیستمیک "
    "پیشرفته یا انسفالیت کم‌محتمل.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**بروسلوز:** ⚠️ **نزدیک‌ترین رقیب در ایران**، چون هر دو **تب طولانی با اسپلنومگالی** "
    "می‌دهند. ولی تفاوت‌ها مهم‌اند: بروسلوز از **لبنیات غیرپاستوریزه یا تماس دامی** می‌آید "
    "(نه آب چشمه)، تب آن **مواج** است، **درد مفاصل و کمر** بارز دارد، **تعریق با بوی خاص** "
    "می‌دهد، و **راش رزئولا نمی‌سازد**.\n\n"
    "**مننژیت:** سؤال صریحاً گفته **علائم تحریک مننژ ندارد** و **بیمار هوشیار است**. سردرد "
    "به‌تنهایی برای مننژیت کافی نیست.\n\n"
    "**کوله‌سیستیت:** درد **ربع فوقانی راست** با **علامت مورفی مثبت**، معمولاً پس از غذای "
    "چرب، و **بدون راش و بدون اسپلنومگالی**. تب یک‌هفته‌ای تدریجی هم با آن نمی‌خواند. "
    "(**نکته‌ی جالب: کیسه‌ی صفرا در تیفوئید نقش دارد — ولی به‌عنوان محل ناقلی مزمن، نه "
    "به‌عنوان تظاهر حاد.**)",
    "This question combines the typhoid picture with AN EPIDEMIOLOGICAL CLUE.\n\n"
    "THE PATIENT: a 25-year-old woman with a history of DRINKING SPRING WATER, with fever, abdominal "
    "pain and headache for a week. Examination: temperature 39, A FURRED TONGUE, a palpable spleen, but "
    "NO MENINGEAL SIGNS. She is alert and a few maculopapular lesions are seen on the upper abdomen.\n\n"
    "WARNING, THE EPIDEMIOLOGICAL CLUE: SPRING WATER.\n\n"
    "WHY DOES THAT MATTER? Because THE RESERVOIR OF SALMONELLA TYPHI IS MAN ALONE and transmission "
    "occurs through WATER OR FOOD CONTAMINATED WITH HUMAN FAECES. SPRING WATER, OR ANY UNPIPED AND "
    "UNTREATED WATER, IS A CLASSIC TYPHOID SOURCE.\n\n"
    "AND THE REST OF THE PICTURE IS CLASSIC TYPHOID:\n\n"
    "A WEEK OF FEVER (gradual, not acute), HEADACHE AND ABDOMINAL PAIN, A FURRED TONGUE, A PALPABLE "
    "SPLEEN, and A MACULOPAPULAR RASH ON THE ABDOMEN = ROSE SPOTS.\n\n"
    "AND TWO ABSENCES THAT SET OTHER DIAGNOSES ASIDE:\n\n"
    "NO MENINGEAL SIGNS, so meningitis is unlikely. SHE IS ALERT, so advanced systemic illness or "
    "encephalitis is unlikely.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "BRUCELLOSIS: WARNING, THE CLOSEST COMPETITOR IN IRAN, since both cause PROLONGED FEVER WITH "
    "SPLENOMEGALY. But the differences matter: brucellosis comes from UNPASTEURISED DAIRY OR ANIMAL "
    "CONTACT (not spring water), its fever is UNDULANT, it causes prominent JOINT AND BACK PAIN, gives "
    "DISTINCTIVELY MALODOROUS SWEAT, and DOES NOT PRODUCE ROSE SPOTS.\n\n"
    "MENINGITIS: the question states explicitly that there are NO MENINGEAL SIGNS and that SHE IS "
    "ALERT. Headache alone is not enough for meningitis.\n\n"
    "CHOLECYSTITIS: RIGHT UPPER QUADRANT pain with A POSITIVE MURPHY'S SIGN, usually after a fatty "
    "meal, and WITHOUT RASH OR SPLENOMEGALY. A gradual week-long fever does not fit either. (AN "
    "INTERESTING POINT: THE GALLBLADDER DOES FEATURE IN TYPHOID — but as the site of CHRONIC CARRIAGE, "
    "not as an acute presentation.)",
    ["نزدیک‌ترین رقیب، ولی از لبنیات غیرپاستوریزه می‌آید، تب مواج دارد و راش رزئولا نمی‌سازد.",
     "پاسخ صحیح — آب چشمه، تب یک‌هفته‌ای، زبان باردار، اسپلنومگالی و راش رزئولا.",
     "سؤال صریحاً گفته علائم تحریک مننژ ندارد و بیمار هوشیار است.",
     "درد ربع فوقانی راست با مورفی مثبت می‌دهد، بدون راش و بدون اسپلنومگالی."],
    ["The closest competitor, but from unpasteurised dairy, with undulant fever and no rose spots.",
     "Correct — spring water, a week of fever, a furred tongue, splenomegaly and rose spots.",
     "The question states explicitly that there are no meningeal signs and the patient is alert.",
     "Causes right upper quadrant pain with a positive Murphy's sign, without rash or splenomegaly."],
    "**آب چشمه + تب یک‌هفته‌ای + راش تنه = تیفوئید تا خلاف آن ثابت نشود.**",
    "Spring water plus a week of fever plus a trunk rash = typhoid until proved otherwise.",
    SREFS)

add("book:426", "vignette", "easy",
    "**تب، یبوست، راش تنه، نبض ۸۰ و لکوپنی: پنج‌گانه‌ی تیفوئید.**",
    "Fever, constipation, a trunk rash, a pulse of 80 and leucopenia: the typhoid pentad.",
    TY_FA + [
        "**این بیمار پنج یافته‌ی تیفوئید را یک‌جا دارد.**",
        "**تب هفت‌روزه، یبوست، راش تنه، نبض ۸۰ با تب ۳۹، و لکوپنی.**",
        "⚠️ **و یبوست، نکته‌ای است که بسیاری از دانشجویان انتظارش را ندارند.**",
        "**چون «تیفوئید» را با «بیماری روده‌ای» یکی می‌گیرند و اسهال انتظار دارند.**",
        "**ولی در بزرگ‌سال، یبوست شایع‌تر از اسهال است، به‌ویژه در هفته‌ی اول.**",
        "**اسهال، اگر بیاید، یافته‌ی هفته‌ی دوم است.**",
        "**و لکوپنی، تشخیص را برمی‌گرداند.**",
        "⚠️ **چون تقریباً هر سپسیس باکتریایی دیگری گلبول سفید را بالا می‌برد.**",
    ],
    TY_EN + [
        "This patient has five typhoid findings at once.",
        "Seven days of fever, constipation, a trunk rash, a pulse of 80 with a fever of 39, and leucopenia.",
        "WARNING, AND CONSTIPATION IS THE POINT many students do not expect.",
        "Because they equate 'typhoid' with 'bowel disease' and expect diarrhoea.",
        "But in adults, constipation is commoner than diarrhoea, especially in the first week.",
        "Diarrhoea, if it comes, is a second-week feature.",
        "And the leucopenia turns the diagnosis.",
        "WARNING, BECAUSE ALMOST EVERY OTHER BACTERIAL SEPSIS RAISES THE WHITE COUNT.",
    ],
    "این سؤال **پنج یافته‌ی تیفوئید** را یک‌جا آورده، و هر کدام به‌تنهایی ارزش دارد.\n\n"
    "**بیمار: پسر ۱۶ ساله بدون سابقه‌ی بیماری خاص، با تب، سردرد، درد شکم و یبوست از ۷ روز "
    "قبل. بثورات ماکولوپاپولر قرمزرنگ در ناحیه‌ی قفسه‌ی سینه. اگزودای لوزه ندارد. تب ۳۹ درجه "
    "و PR=80. در آزمایش‌ها لکوپنی وجود دارد.**\n\n"
    "**پنج یافته را بشماریم:**\n\n"
    "**یک — تب هفت‌روزه.** تیفوئید بیماری **تدریجی** است؛ تب آن کلاسیک به‌صورت **پلکانی** طی "
    "چند روز بالا می‌رود.\n\n"
    "⚠️ **دو — یبوست. و این نکته‌ای است که بسیاری انتظارش را ندارند.** دانشجو «تیفوئید» را "
    "با «بیماری روده‌ای» یکی می‌گیرد و **اسهال** انتظار دارد. **ولی در بزرگ‌سال، یبوست "
    "شایع‌تر از اسهال است**، به‌ویژه در **هفته‌ی اول**. **اسهال، اگر بیاید، یافته‌ی هفته‌ی "
    "دوم است.**\n\n"
    "**سه — بثورات ماکولوپاپولر قرمز روی قفسه‌ی سینه** = **راش رزئولا**.\n\n"
    "**چهار — تب ۳۹ با نبض ۸۰** = **برادی‌کاردی نسبی (علامت فاژه)**. با تب ۳۹، انتظار "
    "نبض حدود ۱۰۰ داریم.\n\n"
    "⚠️ **پنج — لکوپنی. و این یافته تشخیص را برمی‌گرداند.**\n\n"
    "**چرا لکوپنی این‌قدر مهم است؟** چون **تقریباً هر سپسیس باکتریایی دیگری گلبول سفید را "
    "بالا می‌برد**. **تب بالا با گلبول سفید پایین** یک ترکیب **غیرمعمول** است و فهرست "
    "تشخیص‌های افتراقی را به‌شدت محدود می‌کند: **تیفوئید، بروسلوز، عفونت‌های ویروسی، مالاریا، "
    "و ریکتزیوزها**.\n\n"
    "**و «اگزودای لوزه ندارد» هم عمداً آمده: فارنژیت استرپتوکوکی و مونونوکلئوز را کنار می‌گذارد.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**مالاریا:** ⚠️ **آن هم می‌تواند لکوپنی بدهد**، ولی تابلوی آن **حملات لرز-تب-تعریق** "
    "است، **سابقه‌ی سفر به منطقه‌ی مالاریاخیز** می‌خواهد، و **راش رزئولا نمی‌دهد**. و "
    "برادی‌کاردی نسبی مشخصه‌ی آن نیست.\n\n"
    "**اندوکاردیت عفونی:** **سوفل قلبی**، **پدیده‌های آمبولیک** (لکه‌های جین‌وی، گره‌های "
    "اوسلر)، و معمولاً **لکوسیتوز** نه لکوپنی. و **زمینه‌ی قلبی یا اعتیاد تزریقی** می‌خواهد "
    "که سؤال صریحاً نفی کرده («بدون سابقه‌ی بیماری خاص»).\n\n"
    "**مونونوکلئوز عفونی:** **فارنژیت اگزوداتیو** (که سؤال صریحاً نفی کرده)، **لنفادنوپاتی "
    "منتشر**، و **لنفوسیتوز با لنفوسیت آتیپیک** — نه لکوپنی.",
    "This question presents FIVE TYPHOID FINDINGS at once, and each is valuable on its own.\n\n"
    "THE PATIENT: a 16-year-old boy with no significant history, with fever, headache, abdominal pain "
    "and CONSTIPATION for 7 days. Red maculopapular lesions on the chest. NO TONSILLAR EXUDATE. "
    "Temperature 39 and PR 80. The tests show LEUCOPENIA.\n\n"
    "LET US COUNT THE FIVE FINDINGS:\n\n"
    "ONE — SEVEN DAYS OF FEVER. Typhoid is a GRADUAL disease; its fever classically climbs STEPWISE "
    "over several days.\n\n"
    "WARNING, TWO — CONSTIPATION. And this is the point many do not expect. A student equates "
    "'typhoid' with 'bowel disease' and expects DIARRHOEA. BUT IN ADULTS CONSTIPATION IS COMMONER THAN "
    "DIARRHOEA, especially in the FIRST WEEK. DIARRHOEA, IF IT COMES, IS A SECOND-WEEK FEATURE.\n\n"
    "THREE — RED MACULOPAPULAR LESIONS ON THE CHEST = ROSE SPOTS.\n\n"
    "FOUR — A FEVER OF 39 WITH A PULSE OF 80 = RELATIVE BRADYCARDIA (Faget's sign). With a fever of 39 "
    "we would expect a pulse near 100.\n\n"
    "WARNING, FIVE — LEUCOPENIA. And this finding turns the diagnosis.\n\n"
    "WHY IS LEUCOPENIA SO IMPORTANT? Because ALMOST EVERY OTHER BACTERIAL SEPSIS RAISES THE WHITE "
    "COUNT. A HIGH FEVER WITH A LOW WHITE COUNT is AN UNUSUAL combination and sharply narrows the "
    "differential: TYPHOID, BRUCELLOSIS, VIRAL INFECTIONS, MALARIA and the RICKETTSIOSES.\n\n"
    "AND 'NO TONSILLAR EXUDATE' IS ALSO DELIBERATE: it sets aside streptococcal pharyngitis and "
    "mononucleosis.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "MALARIA: WARNING, IT TOO CAN CAUSE LEUCOPENIA, but its picture is PAROXYSMS OF CHILL, FEVER AND "
    "SWEATING, it requires A HISTORY OF TRAVEL TO A MALARIOUS AREA, and IT DOES NOT CAUSE ROSE SPOTS. "
    "Nor is relative bradycardia characteristic.\n\n"
    "INFECTIVE ENDOCARDITIS: A MURMUR, EMBOLIC PHENOMENA (Janeway lesions, Osler nodes), and usually "
    "LEUCOCYTOSIS rather than leucopenia. And it requires A CARDIAC BACKGROUND OR INJECTING DRUG USE, "
    "which the question explicitly denies ('no significant history').\n\n"
    "INFECTIOUS MONONUCLEOSIS: EXUDATIVE PHARYNGITIS (explicitly denied), GENERALISED LYMPHADENOPATHY, "
    "and LYMPHOCYTOSIS WITH ATYPICAL LYMPHOCYTES — not leucopenia.",
    ["پاسخ صحیح — تب هفت‌روزه، یبوست، رزئولا، برادی‌کاردی نسبی و لکوپنی؛ پنج‌گانه‌ی تیفوئید.",
     "لکوپنی می‌دهد ولی حملات لرز-تب-تعریق دارد و سابقه‌ی سفر می‌خواهد؛ رزئولا نمی‌دهد.",
     "سوفل قلبی و پدیده‌های آمبولیک می‌خواهد و معمولاً لکوسیتوز دارد نه لکوپنی.",
     "فارنژیت اگزوداتیو و لنفوسیتوز آتیپیک دارد؛ سؤال هر دو را نفی کرده است."],
    ["Correct — a week of fever, constipation, rose spots, relative bradycardia and leucopenia.",
     "Causes leucopenia but with chill-fever-sweat paroxysms and travel history; no rose spots.",
     "Requires a murmur and embolic phenomena and usually causes leucocytosis, not leucopenia.",
     "Causes exudative pharyngitis and atypical lymphocytosis; the question denies both."],
    "**در تیفوئید بزرگ‌سال، یبوست شایع‌تر از اسهال است — و اسهال یافته‌ی هفته‌ی دوم.**",
    "In adult typhoid, constipation is commoner than diarrhoea — and diarrhoea is a second-week feature.",
    SREFS)

add("book:427", "vignette", "medium",
    "**تب ۴۰ با نبض ۷۰، رزئولا و لکوپنی ۲۸۰۰: تب روده‌ای.**",
    "A fever of 40 with a pulse of 70, rose spots and a white count of 2800: ENTERIC FEVER.",
    TY_FA + [
        "**در این بیمار اعداد، تشخیص را می‌سازند.**",
        "**تب ۴۰ با نبض ۷۰: برادی‌کاردی نسبی بسیار بارز.**",
        "⚠️ **گلبول سفید ۲۸۰۰ با ۳۰ درصد نوتروفیل: لکوپنی با نوتروپنی نسبی.**",
        "**و این ترکیب در سپسیس باکتریایی معمول بسیار غیرعادی است.**",
        "**آنزیم‌های کبدی و آلکالین فسفاتاز هم خفیف بالا رفته‌اند.**",
        "**درگیری خفیف کبد در تیفوئید شایع است و نباید گمراه کند.**",
        "**چون سالمونلا تیفی در سلول‌های رتیکولواندوتلیال کبد و طحال تکثیر می‌شود.**",
        "⚠️ **و همین جایگاه داخل‌سلولی، بعداً توضیح می‌دهد چرا مغز استخوان بهترین کشت است.**",
    ],
    TY_EN + [
        "In this patient the NUMBERS make the diagnosis.",
        "A fever of 40 with a pulse of 70: very marked relative bradycardia.",
        "WARNING, A WHITE COUNT OF 2800 WITH 30% NEUTROPHILS: leucopenia with relative neutropenia.",
        "And that combination is highly unusual in ordinary bacterial sepsis.",
        "The liver enzymes and alkaline phosphatase are also mildly raised.",
        "Mild hepatic involvement is common in typhoid and should not mislead.",
        "Because Salmonella typhi multiplies in the reticuloendothelial cells of liver and spleen.",
        "WARNING, AND THAT INTRACELLULAR LOCATION later explains why marrow is the best culture.",
    ],
    "این سؤال با **اعداد** حل می‌شود، و هر عدد یک قطعه از پازل است.\n\n"
    "**بیمار: آقای ۲۷ ساله با تب، درد شکم و سردرد از ۵ روز قبل. خواب‌آلود، تب‌دار و توکسیک. "
    "طحال زیر لبه‌ی دنده لمس می‌شود و چندین راش ماکولوپاپولر قرمز روی پوست شکم. علائم حیاتی: "
    "BP=110/75، RR=18، PR=70، BT=40. آزمایش‌ها: WBC=2800 با ۳۰٪ نوتروفیل، ALP=300، ALT=120.**\n\n"
    "**اعداد را یکی‌یکی بخوانیم:**\n\n"
    "⚠️ **PR=70 با BT=40.** این **برادی‌کاردی نسبی بسیار بارز** است. با تب ۴۰ درجه، انتظار "
    "نبض **۱۰۰ تا ۱۱۰** داریم — و نبض این بیمار **۷۰** است. **این تقریباً پاتوگنومونیک تیفوئید "
    "است.**\n\n"
    "⚠️ **WBC=2800 با ۳۰٪ نوتروفیل.** دو نکته: **لکوپنی** (زیر ۴۰۰۰)، و **نوتروفیل فقط ۳۰ "
    "درصد** (طبیعی ۵۰ تا ۷۰ درصد) — یعنی **نوتروپنی نسبی**. **در سپسیس باکتریایی معمول، "
    "انتظار لکوسیتوز با نوتروفیلی داریم — دقیقاً برعکس.**\n\n"
    "**راش ماکولوپاپولر قرمز روی شکم** = **رزئولا**.\n\n"
    "**طحال قابل لمس** ✔ · **خواب‌آلودگی و ظاهر توکسیک** ✔ (تیفوئید در هفته‌ی دوم می‌تواند "
    "**کاهش هوشیاری و حالت تیفوئیدی** بدهد — نام بیماری از همین «typhos» یونانی به معنی "
    "مه‌آلودگی می‌آید).\n\n"
    "**و آنزیم‌های کبدی؟** ALP=300 و ALT=120 — **افزایش خفیف تا متوسط**. ⚠️ **این در تیفوئید "
    "شایع است و نباید گمراه کند.** چرا؟ چون **سالمونلا تیفی در سلول‌های رتیکولواندوتلیال کبد "
    "و طحال تکثیر می‌شود** و **هپاتیت خفیف تیفوئیدی** ایجاد می‌کند.\n\n"
    "**پس تشخیص: تب روده‌ای (Enteric Fever).**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**هپاتیت ویروسی:** ⚠️ **دام سؤال، به‌دلیل آنزیم‌های کبدی بالا.** ولی در هپاتیت ویروسی "
    "حاد، **ALT معمولاً صدها تا هزاران** است (نه ۱۲۰)، **یرقان** بارز است، و **راش رزئولا و "
    "برادی‌کاردی نسبی** جزو تابلوی آن نیستند. اینجا آنزیم‌ها **خفیف** بالا رفته‌اند، که با "
    "درگیری ثانویه‌ی کبد در یک عفونت سیستمیک می‌خواند.\n\n"
    "**مننگوکوکسمی:** شروع **ناگهانی**، **راش پتشیال/پورپورا**، **پیشرفت سریع به شوک**، و "
    "**لکوسیتوز**. پنج روز تب تدریجی با فشار طبیعی، با آن نمی‌خواند.\n\n"
    "**مالاریا:** لکوپنی می‌دهد، ولی **حملات دوره‌ای لرز-تب-تعریق** دارد، **سابقه‌ی سفر** "
    "می‌خواهد، و **رزئولا نمی‌دهد**.",
    "This question is solved BY THE NUMBERS, and each number is a piece of the puzzle.\n\n"
    "THE PATIENT: a 27-year-old man with fever, abdominal pain and headache for 5 days. He is drowsy, "
    "febrile and toxic. The spleen is palpable below the costal margin and there are several red "
    "maculopapular lesions on the abdominal skin. Vital signs: BP 110/75, RR 18, PR 70, BT 40. Tests: "
    "WBC 2800 with 30% neutrophils, ALP 300, ALT 120.\n\n"
    "LET US READ THE NUMBERS ONE BY ONE:\n\n"
    "WARNING, PR 70 WITH BT 40. This is VERY MARKED RELATIVE BRADYCARDIA. With a fever of 40 we would "
    "expect a pulse of 100 TO 110 — and this patient's is 70. THIS IS ALMOST PATHOGNOMONIC OF TYPHOID.\n\n"
    "WARNING, WBC 2800 WITH 30% NEUTROPHILS. Two points: LEUCOPENIA (below 4000), and NEUTROPHILS AT "
    "ONLY 30% (normal 50 to 70) — RELATIVE NEUTROPENIA. IN ORDINARY BACTERIAL SEPSIS WE EXPECT "
    "LEUCOCYTOSIS WITH NEUTROPHILIA — exactly the opposite.\n\n"
    "RED MACULOPAPULAR LESIONS ON THE ABDOMEN = ROSE SPOTS.\n\n"
    "A PALPABLE SPLEEN, and DROWSINESS WITH A TOXIC APPEARANCE (typhoid in the second week can produce "
    "IMPAIRED CONSCIOUSNESS AND THE 'TYPHOID STATE' — the disease is named from the Greek 'typhos', "
    "meaning a mist or stupor).\n\n"
    "AND THE LIVER ENZYMES? ALP 300 and ALT 120 — A MILD TO MODERATE RISE. WARNING, THIS IS COMMON IN "
    "TYPHOID AND SHOULD NOT MISLEAD. Why? Because SALMONELLA TYPHI MULTIPLIES IN THE "
    "RETICULOENDOTHELIAL CELLS OF THE LIVER AND SPLEEN and produces A MILD TYPHOID HEPATITIS.\n\n"
    "SO THE DIAGNOSIS: ENTERIC FEVER.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "VIRAL HEPATITIS: WARNING, THE TRAP, because of the raised liver enzymes. But in acute viral "
    "hepatitis the ALT is usually IN THE HUNDREDS OR THOUSANDS (not 120), JAUNDICE is prominent, and "
    "ROSE SPOTS AND RELATIVE BRADYCARDIA are not part of the picture. Here the enzymes are only MILDLY "
    "raised, consistent with secondary hepatic involvement in a systemic infection.\n\n"
    "MENINGOCOCCAEMIA: SUDDEN onset, a PETECHIAL/PURPURIC rash, RAPID PROGRESSION TO SHOCK, and "
    "LEUCOCYTOSIS. Five days of gradual fever with a normal blood pressure does not fit.\n\n"
    "MALARIA: causes leucopenia, but with PERIODIC CHILL-FEVER-SWEAT PAROXYSMS, requiring A TRAVEL "
    "HISTORY, and it DOES NOT CAUSE ROSE SPOTS.",
    ["دام سؤال — ولی در هپاتیت حاد، ALT صدها تا هزاران است و رزئولا و برادی‌کاردی نسبی ندارد.",
     "شروع ناگهانی با راش پتشیال و پیشرفت سریع به شوک؛ با پنج روز تب تدریجی نمی‌خواند.",
     "پاسخ صحیح — برادی‌کاردی نسبی بارز، رزئولا، لکوپنی ۲۸۰۰ و اسپلنومگالی.",
     "لکوپنی می‌دهد ولی حملات دوره‌ای دارد، سابقه‌ی سفر می‌خواهد و رزئولا نمی‌دهد."],
    ["The trap — but in acute hepatitis the ALT is in the hundreds or thousands, with no rose spots.",
     "Sudden onset with a petechial rash and rapid progression to shock; five gradual days do not fit.",
     "Correct — marked relative bradycardia, rose spots, a white count of 2800 and splenomegaly.",
     "Causes leucopenia but with periodic paroxysms, a travel history, and no rose spots."],
    "**سالمونلا تیفی داخل ماکروفاژهای کبد و طحال زندگی می‌کند — پس آنزیم کبدی خفیف بالا می‌رود.**",
    "S. typhi lives inside hepatic and splenic macrophages — hence the mildly raised liver enzymes.",
    SREFS)

# ============================================== TYPHOID DIAGNOSIS
DX_FA = TY_FA + [
    "⚠️ **تشخیص تیفوئید را به‌صورت یک خط زمانی حفظ کنید.**",
    "**هفته‌ی اول: کشت خون، مثبت در ۶۰ تا ۸۰ درصد.**",
    "**هفته‌ی دوم و سوم: بازده کشت خون کم می‌شود و کشت مدفوع و ادرار بالا می‌رود.**",
    "**و در هر هفته: کشت مغز استخوان حساس‌ترین است، بیش از ۹۰ درصد.**",
    "⚠️ **و ویژگی منحصربه‌فرد مغز استخوان: با وجود آنتی‌بیوتیک قبلی هم مثبت می‌ماند.**",
    "**چرا؟ چون سالمونلا تیفی داخل ماکروفاژهای سیستم رتیکولواندوتلیال زندگی می‌کند.**",
    "**در آنجا غلظت آنتی‌بیوتیک کمتر است و باکتری پناه دارد.**",
    "**پس وقتی خون استریل شده، مغز استخوان هنوز باکتری دارد.**",
    "**و همین آن را در بیمار نیمه‌درمان‌شده به پاسخ تبدیل می‌کند.**",
    "**و تست ویدال پاسخ هیچ‌کدام از این سؤال‌ها نیست.**",
    "⚠️ **حساسیت و اختصاصیت پایین دارد و در منطقه‌ی اندمیک مثبت کاذب فراوان می‌دهد.**",
]
DX_EN = TY_EN + [
    "WARNING: MEMORISE THE DIAGNOSIS OF TYPHOID AS A TIMELINE.",
    "WEEK ONE: blood culture, positive in 60 to 80 per cent.",
    "WEEKS TWO AND THREE: the blood culture yield falls and stool and urine cultures rise.",
    "And in ANY week: BONE MARROW CULTURE is the most sensitive, over 90 per cent.",
    "WARNING, AND MARROW'S UNIQUE PROPERTY: IT STAYS POSITIVE DESPITE PRIOR ANTIBIOTICS.",
    "Why? Because Salmonella typhi lives INSIDE the macrophages of the reticuloendothelial system.",
    "There the antibiotic concentration is lower and the organism is sheltered.",
    "So when the blood has been sterilised, the marrow still holds the organism.",
    "And that is what makes it the answer in a partially treated patient.",
    "And the WIDAL test is the answer to none of these questions.",
    "WARNING, IT HAS POOR SENSITIVITY AND SPECIFICITY and many false positives in an endemic area.",
]

add("book:428", "vignette", "medium",
    "**در هفته‌ی اول تیفوئید، کشت خون بیشترین بازده را دارد.**",
    "In the first week of typhoid, BLOOD CULTURE has the highest yield.",
    DX_FA,
    DX_EN,
    "این سؤال یک **آزمون تشخیصی** را می‌خواهد، و پاسخ آن به **هفته‌ی بیماری** بستگی دارد.\n\n"
    "**بیمار: آقای ۴۹ ساله با تب و لرز و درد شکم از یک هفته قبل. تهوع، استفراغ و اسهال داشته "
    "و از سردرد و میالژی نیز شاکی است. در معاینه علاوه بر اسپلنومگالی، تعداد اندکی راش "
    "ماکولوپاپولر روی شکم که با فشار محو می‌شود. دمای ۳۹٫۵ اگزیلری و نبض ۷۸.**\n\n"
    "**اول تشخیص را قطعی کنیم:**\n\n"
    "⚠️ **دمای ۳۹٫۵ با نبض ۷۸** = **برادی‌کاردی نسبی**. **راش ماکولوپاپولر محوشونده با فشار** "
    "= **رزئولا**. **اسپلنومگالی** ✔ · **یک هفته تب تدریجی** ✔\n\n"
    "**پس: تیفوئید.**\n\n"
    "**حالا آزمون: بیمار در هفته‌ی اول بیماری است.**\n\n"
    "**خط زمانی تشخیص تیفوئید را به یاد بیاورید:**\n\n"
    "**هفته‌ی اول** → **کشت خون**، مثبت در **۶۰ تا ۸۰ درصد**. چرا؟ چون در هفته‌ی اول، "
    "**باکتریمی در اوج خود است** — باکتری از روده وارد غدد لنفاوی مزانتریک، سپس مجرای "
    "توراسیک، و از آنجا به **جریان خون** می‌رسد.\n\n"
    "**هفته‌ی دوم و سوم** → بازده کشت خون **کم می‌شود** و **کشت مدفوع و ادرار بالا می‌رود** "
    "(چون باکتری از کیسه‌ی صفرا به روده و از کلیه به ادرار دفع می‌شود).\n\n"
    "**هر هفته** → **کشت مغز استخوان** حساس‌ترین (بیش از ۹۰ درصد).\n\n"
    "**پس در این بیمار که در هفته‌ی اول است: کشت خون.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "⚠️ **تست رایت:** این آزمون **بروسلوز** است، نه تیفوئید. (و بروسلوز نزدیک‌ترین رقیب "
    "تشخیصی در ایران است — ولی **راش رزئولا** و **برادی‌کاردی نسبی** به سمت تیفوئید می‌برند.)\n\n"
    "**اکوکاردیوگرافی:** برای **اندوکاردیت**. ولی بیمار **سوفل قلبی، پدیده‌ی آمبولیک یا "
    "زمینه‌ی قلبی** ندارد. و **رزئولا** جزو تابلوی اندوکاردیت نیست.\n\n"
    "**آنالیز مایع نخاع:** برای **مننژیت**. بیمار سردرد دارد، ولی **علائم تحریک مننژ یا "
    "اختلال هوشیاری** ذکر نشده. LP یک اقدام تهاجمی است و باید اندیکاسیون داشته باشد.\n\n"
    "⚠️ **و نکته‌ای که سؤال نپرسیده ولی مهم است: تست ویدال پاسخ نیست.** ویدال **حساسیت و "
    "اختصاصیت پایینی** دارد، در **منطقه‌ی اندمیک مثبت کاذب فراوان** می‌دهد (به‌دلیل تماس "
    "قبلی)، و **در هفته‌ی اول اغلب منفی است**. **کشت خون استاندارد طلایی است.**",
    "This question asks for A DIAGNOSTIC TEST, and its answer depends on THE WEEK OF ILLNESS.\n\n"
    "THE PATIENT: a 49-year-old man with fever, chills and abdominal pain for a week. He has had "
    "nausea, vomiting and diarrhoea and also complains of headache and myalgia. Examination shows "
    "splenomegaly and a few maculopapular lesions on the abdomen THAT BLANCH ON PRESSURE. Temperature "
    "39.5 axillary and pulse 78.\n\n"
    "FIRST LET US SETTLE THE DIAGNOSIS:\n\n"
    "WARNING, A TEMPERATURE OF 39.5 WITH A PULSE OF 78 = RELATIVE BRADYCARDIA. A BLANCHING "
    "MACULOPAPULAR RASH = ROSE SPOTS. SPLENOMEGALY, and A WEEK OF GRADUAL FEVER.\n\n"
    "SO: TYPHOID.\n\n"
    "NOW THE TEST: the patient is in the FIRST WEEK of illness.\n\n"
    "RECALL THE TYPHOID DIAGNOSTIC TIMELINE:\n\n"
    "WEEK ONE means BLOOD CULTURE, positive in 60 TO 80 PER CENT. Why? Because in the first week "
    "BACTERAEMIA IS AT ITS PEAK — the organism passes from the bowel to the mesenteric lymph nodes, "
    "then the thoracic duct, and from there into THE BLOODSTREAM.\n\n"
    "WEEKS TWO AND THREE mean the blood culture yield FALLS and STOOL AND URINE CULTURES RISE (as the "
    "organism is shed from the gallbladder into the bowel and from the kidney into the urine).\n\n"
    "ANY WEEK means BONE MARROW CULTURE is the most sensitive (over 90%).\n\n"
    "SO IN THIS FIRST-WEEK PATIENT: BLOOD CULTURE.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "WARNING, THE WRIGHT TEST: this is a test for BRUCELLOSIS, not typhoid. (And brucellosis is the "
    "closest diagnostic competitor in Iran — but ROSE SPOTS and RELATIVE BRADYCARDIA point to typhoid.)\n\n"
    "ECHOCARDIOGRAPHY: for ENDOCARDITIS. But the patient has NO MURMUR, EMBOLIC PHENOMENA OR CARDIAC "
    "BACKGROUND. And ROSE SPOTS are not part of the endocarditis picture.\n\n"
    "CSF ANALYSIS: for MENINGITIS. The patient has headache, but NO MENINGEAL SIGNS OR ALTERED "
    "CONSCIOUSNESS are described. An LP is invasive and must be indicated.\n\n"
    "WARNING, AND A POINT THE QUESTION DID NOT ASK BUT WHICH MATTERS: THE WIDAL TEST IS NOT THE ANSWER. "
    "Widal has POOR SENSITIVITY AND SPECIFICITY, gives MANY FALSE POSITIVES IN AN ENDEMIC AREA (from "
    "previous exposure), and IS OFTEN NEGATIVE IN THE FIRST WEEK. BLOOD CULTURE IS THE GOLD STANDARD.",
    ["آزمون بروسلوز است، نه تیفوئید؛ و رزئولا و برادی‌کاردی نسبی به سمت تیفوئید می‌برند.",
     "پاسخ صحیح — در هفته‌ی اول تیفوئید، باکتریمی در اوج است و کشت خون ۶۰ تا ۸۰ درصد مثبت.",
     "برای اندوکاردیت است؛ بیمار سوفل، پدیده‌ی آمبولیک یا زمینه‌ی قلبی ندارد.",
     "برای مننژیت است؛ علائم تحریک مننژ یا اختلال هوشیاری ذکر نشده."],
    ["A test for brucellosis, not typhoid; and rose spots with relative bradycardia point to typhoid.",
     "Correct — in the first week bacteraemia is at its peak and blood culture is 60 to 80% positive.",
     "For endocarditis; the patient has no murmur, embolic phenomena or cardiac background.",
     "For meningitis; no meningeal signs or altered consciousness are described."],
    "**هفته‌ی اول: خون. هفته‌ی دوم و سوم: مدفوع و ادرار. هر هفته: مغز استخوان.**",
    "Week one: blood. Weeks two and three: stool and urine. Any week: bone marrow.",
    SREFS)

add("book:431", "vignette", "hard",
    "**تیفوئید نیمه‌درمان‌شده: کشت مغز استخوان — تنها کشتی که آنتی‌بیوتیک آن را منفی نمی‌کند.**",
    "Partially treated typhoid: BONE MARROW CULTURE — the one culture antibiotics do not turn negative.",
    DX_FA,
    DX_EN,
    "این **سخت‌ترین سؤال تشخیصی این فصل** است، و کلید آن در **یک جمله‌ی به‌ظاهر فرعی** پنهان "
    "شده.\n\n"
    "**بیمار: آقای ۲۵ ساله با تب از ۱۲ روز قبل و درد شکم و سردرد و یبوست. ⚠️ و این جمله‌ی "
    "کلیدی: «بیمار ذکر می‌کند که ۵ روز سفکسیم خوراکی دریافت نموده است ولی بهبودی مناسب "
    "نداشته است.» در معاینه، تنها یافته‌ی مثبت هپاتواسپلنومگالی خفیف است.**\n\n"
    "**تشخیص روشن است: تیفوئید.** (۱۲ روز تب + یبوست + سردرد + هپاتواسپلنومگالی.)\n\n"
    "**ولی سؤال یک وضعیت خاص ساخته: بیمار قبلاً آنتی‌بیوتیک گرفته است.**\n\n"
    "⚠️ **و این همه‌چیز را عوض می‌کند. چرا؟**\n\n"
    "**پنج روز سفکسیم — یک سفالوسپورین نسل سوم خوراکی — احتمالاً برای بهبود بالینی کافی "
    "نبوده، ولی برای «استریل کردن خون» کافی بوده است.** پس **کشت خون احتمالاً منفی می‌شود** — "
    "و **یک منفی کاذب، بدترین نتیجه‌ی ممکن است**، چون تشخیص را به تأخیر می‌اندازد.\n\n"
    "**و بیمار در روز ۱۲ است، یعنی هفته‌ی دوم — که بازده کشت خون از قبل هم پایین آمده.**\n\n"
    "**پس چه چیزی باقی می‌ماند؟ کشت آسپیراسیون مغز استخوان.**\n\n"
    "⚠️ **و حالا مهم‌ترین بخش: چرا مغز استخوان با وجود آنتی‌بیوتیک هم مثبت می‌ماند؟**\n\n"
    "**پاسخ در زیست‌شناسی خودِ باکتری است.** سالمونلا تیفی یک پاتوژن **داخل‌سلولی** است: "
    "**داخل ماکروفاژهای سیستم رتیکولواندوتلیال** — یعنی **مغز استخوان، کبد، طحال و غدد "
    "لنفاوی** — زندگی و تکثیر می‌کند.\n\n"
    "**و این دو پیامد دارد:**\n\n"
    "**یک — غلظت آنتی‌بیوتیک در داخل ماکروفاژ کمتر** از خون است. **دو — باکتری در آنجا پناه "
    "دارد** و پس از استریل شدن خون، **همچنان زنده می‌ماند**.\n\n"
    "**نتیجه: حساسیت کشت مغز استخوان بیش از ۹۰ درصد است، و — بر خلاف کشت خون — با آنتی‌بیوتیک "
    "قبلی افت چشمگیری نمی‌کند.**\n\n"
    "**پس در بیمار نیمه‌درمان‌شده، مغز استخوان استاندارد طلایی است.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**کشت خون:** ⚠️ **در بیمار درمان‌نشده بهترین گزینه بود** — ولی این بیمار **پنج روز "
    "سفکسیم گرفته** و در **هفته‌ی دوم** است. **احتمال منفی کاذب بالاست.**\n\n"
    "**کشت CSF:** بیمار **ردورگردنی ندارد** و علائم مننژیت ندارد. اندیکاسیون ندارد.\n\n"
    "**کشت مدفوع:** در **هفته‌ی دوم و سوم** بازده آن بالا می‌رود، پس **گزینه‌ی بدی نیست**. "
    "ولی **حساسیت آن (حدود ۳۰ تا ۴۰ درصد) به‌مراتب کمتر از مغز استخوان (بیش از ۹۰ درصد)** "
    "است، و **آن هم تحت تأثیر آنتی‌بیوتیک قرار می‌گیرد**. سؤال «بیشترین ارزش تشخیصی» را "
    "خواسته — و آن مغز استخوان است.",
    "This is THE HARDEST DIAGNOSTIC QUESTION IN THE CHAPTER, and its key is hidden IN AN APPARENTLY "
    "MINOR SENTENCE.\n\n"
    "THE PATIENT: a 25-year-old man with fever for 12 days plus abdominal pain, headache and "
    "constipation. WARNING, AND THIS IS THE KEY SENTENCE: 'the patient reports receiving 5 days of oral "
    "cefixime without adequate improvement.' Examination shows only mild hepatosplenomegaly.\n\n"
    "THE DIAGNOSIS IS CLEAR: TYPHOID. (12 days of fever, constipation, headache, hepatosplenomegaly.)\n\n"
    "BUT THE QUESTION HAS CREATED A SPECIAL SITUATION: THE PATIENT HAS ALREADY HAD AN ANTIBIOTIC.\n\n"
    "WARNING, AND THAT CHANGES EVERYTHING. WHY?\n\n"
    "FIVE DAYS OF CEFIXIME — an oral third-generation cephalosporin — was probably insufficient for "
    "clinical cure, BUT SUFFICIENT TO STERILISE THE BLOOD. So THE BLOOD CULTURE WILL PROBABLY BE "
    "NEGATIVE — and A FALSE NEGATIVE IS THE WORST POSSIBLE RESULT, because it delays the diagnosis.\n\n"
    "AND THE PATIENT IS ON DAY 12, that is, THE SECOND WEEK — when the blood culture yield has already "
    "fallen.\n\n"
    "SO WHAT REMAINS? BONE MARROW ASPIRATION CULTURE.\n\n"
    "WARNING, AND NOW THE MOST IMPORTANT PART: WHY DOES MARROW STAY POSITIVE DESPITE ANTIBIOTICS?\n\n"
    "THE ANSWER LIES IN THE BIOLOGY OF THE ORGANISM. Salmonella typhi is AN INTRACELLULAR pathogen: it "
    "lives and multiplies INSIDE THE MACROPHAGES OF THE RETICULOENDOTHELIAL SYSTEM — that is, the BONE "
    "MARROW, LIVER, SPLEEN AND LYMPH NODES.\n\n"
    "AND THAT HAS TWO CONSEQUENCES:\n\n"
    "ONE — THE ANTIBIOTIC CONCENTRATION INSIDE THE MACROPHAGE IS LOWER than in blood. TWO — THE "
    "ORGANISM IS SHELTERED THERE and SURVIVES after the blood has been sterilised.\n\n"
    "THE RESULT: MARROW CULTURE SENSITIVITY EXCEEDS 90%, AND — UNLIKE BLOOD CULTURE — IT DOES NOT FALL "
    "MARKEDLY WITH PRIOR ANTIBIOTICS.\n\n"
    "SO IN A PARTIALLY TREATED PATIENT, MARROW IS THE GOLD STANDARD.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "BLOOD CULTURE: WARNING, IT WOULD HAVE BEEN THE BEST CHOICE IN AN UNTREATED PATIENT — but this one "
    "HAS HAD FIVE DAYS OF CEFIXIME and is in THE SECOND WEEK. THE RISK OF A FALSE NEGATIVE IS HIGH.\n\n"
    "CSF CULTURE: the patient has NO NECK STIFFNESS and no meningitic features. Not indicated.\n\n"
    "STOOL CULTURE: its yield RISES in weeks two and three, so IT IS NOT A BAD OPTION. But ITS "
    "SENSITIVITY (about 30 to 40%) IS FAR BELOW MARROW'S (over 90%), and IT TOO IS AFFECTED BY PRIOR "
    "ANTIBIOTICS. The question asks for THE GREATEST DIAGNOSTIC VALUE — and that is marrow.",
    ["در بیمار درمان‌نشده بهترین بود، ولی پنج روز سفکسیم و هفته‌ی دوم، احتمال منفی کاذب را بالا برده.",
     "بیمار ردورگردنی ندارد و علائم مننژیت ندارد؛ اندیکاسیون ندارد.",
     "در هفته‌ی دوم بازده آن بالا می‌رود ولی حساسیتش حدود ۳۰ تا ۴۰ درصد است، به‌مراتب کمتر از مغز استخوان.",
     "پاسخ صحیح — باکتری داخل ماکروفاژ پناه دارد، پس مغز استخوان با آنتی‌بیوتیک قبلی هم مثبت می‌ماند."],
    ["The best choice in an untreated patient, but five days of cefixime in week two risks a false negative.",
     "The patient has no neck stiffness or meningitic features; not indicated.",
     "Its yield rises in week two but its sensitivity is 30 to 40%, far below marrow's.",
     "Correct — the organism shelters inside macrophages, so marrow stays positive despite prior antibiotics."],
    "**باکتری داخل ماکروفاژ پناه دارد — پس مغز استخوان پس از استریل شدن خون هم مثبت است.**",
    "The organism shelters inside macrophages — so marrow stays positive after the blood is sterilised.",
    SREFS)

# ============================================== SALMONELLA TREATMENT
TX_FA = TY_FA + [
    "⚠️ **دو سالمونلا، دو رویکرد درمانی کاملاً متضاد.**",
    "**سالمونلای غیرتیفی در فرد سالم معمولاً آنتی‌بیوتیک نمی‌خواهد.**",
    "**چون درمان مدت بیماری را کوتاه نمی‌کند.**",
    "**و بدتر: مدت ناقلی را طولانی می‌کند.**",
    "**چرا؟ چون آنتی‌بیوتیک فلور طبیعی رقیب را سرکوب می‌کند.**",
    "**و سالمونلا در نبود رقیب، راحت‌تر در روده می‌ماند.**",
    "⚠️ **پس درمان فقط برای گروه‌های پرخطر است، و آن‌ها را بشمارید.**",
    "**شیرخوار و سالمند، فرد دچار سرکوب ایمنی، دارنده‌ی پروتز یا بیماری دریچه‌ای.**",
    "**بیمار مبتلا به سیکل‌سل، و هر بیمار با باکتریمی یا بیماری شدید یا طول‌کشیده.**",
    "**و در برابر آن، تیفوئید همیشه درمان می‌شود.**",
    "**درمان تجربی و بیماری شدید: سفالوسپورین نسل سوم وریدی، یعنی سفتریاکسون.**",
    "⚠️ **چون مقاومت به فلوروکینولون در آسیای جنوبی و خاورمیانه گسترده شده است.**",
    "**و آزیترومایسین، جایگزین خوراکی بیماری بدون عارضه است.**",
]
TX_EN = TY_EN + [
    "WARNING: TWO SALMONELLAS, TWO OPPOSITE TREATMENT APPROACHES.",
    "Non-typhoidal Salmonella in a healthy host usually needs NO antibiotic.",
    "Because treatment does not shorten the illness.",
    "And worse: it PROLONGS THE CARRIER STATE.",
    "Why? Because the antibiotic suppresses the competing normal flora.",
    "And Salmonella, without competitors, persists more easily in the bowel.",
    "WARNING, SO TREATMENT IS ONLY FOR HIGH-RISK GROUPS, and they should be counted.",
    "Infants and the elderly, the immunosuppressed, those with a prosthesis or valve disease.",
    "Patients with sickle-cell disease, and anyone with bacteraemia or severe or prolonged illness.",
    "And by contrast, typhoid is ALWAYS treated.",
    "Empirical therapy and severe disease: an intravenous third-generation cephalosporin, ceftriaxone.",
    "WARNING, BECAUSE FLUOROQUINOLONE RESISTANCE has spread widely in South Asia and the Middle East.",
    "And azithromycin is the oral alternative for uncomplicated disease.",
]

add("book:432", "vignette", "medium",
    "**سالمونلای غیرتیفی در فرد سالم: فقط مایع‌درمانی — آنتی‌بیوتیک ناقلی را طولانی می‌کند.**",
    "Non-typhoidal Salmonella in a healthy host: REHYDRATION ONLY — antibiotics prolong carriage.",
    TX_FA,
    TX_EN,
    "این سؤال یکی از **غیرشهودی‌ترین قواعد** این فصل را می‌سنجد: **گاهی درمان نکردن، درمان "
    "درست است.**\n\n"
    "**بیمار: مرد جوان بدون سابقه‌ی بیماری قبلی با تب و اسهال. در کشت مدفوع، سالمونلای "
    "غیرتیفی گزارش شده. مناسب‌ترین درمان کدام است؟**\n\n"
    "⚠️ **پاسخ: مایع‌درمانی.**\n\n"
    "**وسوسه‌ی طبیعی: «باکتری پیدا شده، پس آنتی‌بیوتیک بدهیم.» و این اشتباه است.**\n\n"
    "**چرا در فرد سالم، سالمونلای غیرتیفی آنتی‌بیوتیک نمی‌خواهد؟ دو دلیل:**\n\n"
    "**دلیل یک — آنتی‌بیوتیک مدت بیماری را کوتاه نمی‌کند.** مطالعات متعدد نشان داده‌اند که "
    "در گاستروآنتریت سالمونلایی بدون عارضه، **آنتی‌بیوتیک تفاوت معناداری در مدت تب یا اسهال "
    "ایجاد نمی‌کند**. بیماری **خودمحدود** است و ظرف چند روز خوب می‌شود.\n\n"
    "⚠️ **دلیل دو — و این مهم‌تر است: آنتی‌بیوتیک مدت ناقلی را طولانی می‌کند.**\n\n"
    "**چرا؟ سازوکار زیبایی دارد:** فلور طبیعی روده یک **سد رقابتی** است — با اشغال فضا و "
    "منابع، مانع ماندگاری پاتوژن‌ها می‌شود. **آنتی‌بیوتیک این فلور رقیب را سرکوب می‌کند**، و "
    "**سالمونلا — که نسبت به بسیاری از آنتی‌بیوتیک‌ها مقاوم‌تر است — در نبود رقیب راحت‌تر "
    "می‌ماند**. نتیجه: **دفع باکتری هفته‌ها طولانی‌تر می‌شود** و بیمار **مدت بیشتری برای "
    "دیگران خطرناک است**.\n\n"
    "**پس چه کسانی درمان می‌شوند؟ گروه‌های پرخطر را بشمارید:**\n\n"
    "**شیرخواران (زیر ۳ ماه) و سالمندان (بالای ۵۰ سال)** · **افراد دچار سرکوب ایمنی** (از "
    "جمله HIV) · **دارندگان پروتز عروقی یا مفصلی** · **بیماران با بیماری دریچه‌ای قلب** · "
    "**بیماران مبتلا به سیکل‌سل** (خطر استئومیلیت سالمونلایی) · و **هر بیمار با باکتریمی، "
    "بیماری شدید، یا اسهال طول‌کشیده**.\n\n"
    "**بیمار ما «مرد جوان بدون سابقه‌ی بیماری قبلی» است — یعنی هیچ‌کدام از این‌ها نیست.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**سیپروفلوکساسین:** انتخاب مناسبی **اگر** درمان لازم بود — ولی در این بیمار **لازم "
    "نیست**، و **ناقلی را طولانی می‌کند**.\n\n"
    "**آموکسی‌سیلین:** هم اندیکاسیون ندارد و هم **مقاومت سالمونلا به آن گسترده** است.\n\n"
    "**سفتریاکسون:** داروی **تیفوئید و سالمونلای شدید یا باکتریمیک** است. در گاستروآنتریت "
    "ساده‌ی یک جوان سالم، **درمان به‌شدت بیش‌ازحد** است.\n\n"
    "⚠️ **و تفاوت کلیدی را به یاد بسپارید: سالمونلای غیرتیفی معمولاً درمان نمی‌شود؛ تیفوئید "
    "همیشه درمان می‌شود.**",
    "This question tests one of THE MOST COUNTER-INTUITIVE RULES in the chapter: SOMETIMES NOT TREATING "
    "IS THE CORRECT TREATMENT.\n\n"
    "THE PATIENT: a young man with no previous illness, with fever and diarrhoea. The stool culture "
    "reports NON-TYPHOIDAL SALMONELLA. What is the most appropriate treatment?\n\n"
    "WARNING, THE ANSWER: REHYDRATION.\n\n"
    "THE NATURAL TEMPTATION: 'a bacterium has been found, so give an antibiotic.' AND THAT IS WRONG.\n\n"
    "WHY DOES NON-TYPHOIDAL SALMONELLA NEED NO ANTIBIOTIC IN A HEALTHY HOST? Two reasons:\n\n"
    "REASON ONE — THE ANTIBIOTIC DOES NOT SHORTEN THE ILLNESS. Multiple studies have shown that in "
    "uncomplicated Salmonella gastroenteritis, ANTIBIOTICS MAKE NO SIGNIFICANT DIFFERENCE to the "
    "duration of fever or diarrhoea. The illness is SELF-LIMITED and settles within days.\n\n"
    "WARNING, REASON TWO — AND THIS MATTERS MORE: THE ANTIBIOTIC PROLONGS THE CARRIER STATE.\n\n"
    "WHY? The mechanism is elegant: the normal bowel flora is A COMPETITIVE BARRIER — by occupying "
    "space and resources it prevents pathogens from persisting. THE ANTIBIOTIC SUPPRESSES THAT "
    "COMPETING FLORA, and SALMONELLA — being more resistant to many antibiotics — PERSISTS MORE EASILY "
    "WITHOUT COMPETITORS. The result: SHEDDING LASTS WEEKS LONGER and the patient IS A HAZARD TO OTHERS "
    "FOR LONGER.\n\n"
    "SO WHO IS TREATED? COUNT THE HIGH-RISK GROUPS:\n\n"
    "INFANTS (under 3 months) AND THE ELDERLY (over 50), THE IMMUNOSUPPRESSED (including HIV), THOSE "
    "WITH A VASCULAR OR JOINT PROSTHESIS, PATIENTS WITH VALVULAR HEART DISEASE, PATIENTS WITH "
    "SICKLE-CELL DISEASE (risk of Salmonella osteomyelitis), and ANY PATIENT WITH BACTERAEMIA, SEVERE "
    "DISEASE OR PROLONGED DIARRHOEA.\n\n"
    "OUR PATIENT IS 'A YOUNG MAN WITH NO PREVIOUS ILLNESS' — that is, none of these.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "CIPROFLOXACIN: a suitable choice IF treatment were needed — but in this patient IT IS NOT NEEDED, "
    "and it PROLONGS CARRIAGE.\n\n"
    "AMOXICILLIN: neither indicated nor reliable, since SALMONELLA RESISTANCE TO IT IS WIDESPREAD.\n\n"
    "CEFTRIAXONE: a drug for TYPHOID AND SEVERE OR BACTERAEMIC SALMONELLA. In simple gastroenteritis in "
    "a healthy young man it is GROSS OVERTREATMENT.\n\n"
    "WARNING, AND REMEMBER THE KEY DISTINCTION: NON-TYPHOIDAL SALMONELLA IS USUALLY NOT TREATED; "
    "TYPHOID IS ALWAYS TREATED.",
    ["مناسب بود اگر درمان لازم بود، ولی در فرد سالم لازم نیست و ناقلی را طولانی می‌کند.",
     "اندیکاسیون ندارد و مقاومت سالمونلا به آموکسی‌سیلین هم گسترده است.",
     "پاسخ صحیح — بیماری خودمحدود است و آنتی‌بیوتیک مدت ناقلی را طولانی می‌کند.",
     "داروی تیفوئید و سالمونلای باکتریمیک است؛ در گاستروآنتریت ساده بیش‌ازحد است."],
    ["Suitable if treatment were needed, but it is not in a healthy host, and it prolongs carriage.",
     "Not indicated, and Salmonella resistance to amoxicillin is widespread.",
     "Correct — the illness is self-limited and antibiotics prolong the carrier state.",
     "A drug for typhoid and bacteraemic Salmonella; gross overtreatment in simple gastroenteritis."],
    "**آنتی‌بیوتیک فلور رقیب را می‌کشد — پس سالمونلا راحت‌تر می‌ماند و ناقلی طولانی می‌شود.**",
    "The antibiotic kills the competing flora — so Salmonella persists and carriage lengthens.",
    SREFS)

add("book:433", "vignette", "easy",
    "**گاستروآنتریت سالمونلایی با علائم حیاتی پایدار: نیازی به آنتی‌بیوتیک ندارد.**",
    "Salmonella gastroenteritis with stable vital signs: NO ANTIBIOTIC IS NEEDED.",
    TX_FA + [
        "**این سؤال همان قاعده است، ولی با اعدادی که پایداری بیمار را ثابت می‌کنند.**",
        "**فشار ۱۲۰/۷۰ و علائم حیاتی پایدار: هیچ نشانه‌ی بیماری شدید نیست.**",
        "⚠️ **و گلبول سفید مدفوع فقط ۱۰ عدد: التهاب خفیف.**",
        "**پس بیمار در هیچ گروه پرخطری قرار نمی‌گیرد.**",
        "**سابقه‌ی مصرف تخم‌مرغ هم منبع کلاسیک سالمونلای غیرتیفی است.**",
        "**و کشت مدفوع سالمونلا را تأیید کرده است.**",
        "**ولی کشت مثبت، به‌خودی‌خود اندیکاسیون درمان نیست.**",
        "⚠️ **درمان را وضعیت بیمار تعیین می‌کند، نه نتیجه‌ی کشت.**",
    ],
    TX_EN + [
        "This question is the same rule, but with numbers proving the patient is stable.",
        "BP 120/70 and stable vital signs: no marker of severe disease.",
        "WARNING, AND ONLY 10 STOOL WHITE CELLS: mild inflammation.",
        "So the patient falls into no high-risk group.",
        "The history of eating eggs is also the classic source of non-typhoidal Salmonella.",
        "And the stool culture has confirmed Salmonella.",
        "But a positive culture is not by itself an indication to treat.",
        "WARNING, THE PATIENT'S CONDITION DECIDES THE TREATMENT, not the culture result.",
    ],
    "کتاب همان قاعده را دوباره پرسیده، و این بار **اعدادی داده که پایداری بیمار را ثابت "
    "می‌کنند**.\n\n"
    "**بیمار: به دنبال مصرف تخم‌مرغ دچار تب، اسهال و استفراغ شده. علائم حیاتی پایدار و فشار "
    "خون ۱۲۰/۷۰. در آزمایش مدفوع ۱۰ عدد گلبول سفید. کشت مدفوع: سالمونلا.**\n\n"
    "⚠️ **پاسخ: نیازی به مصرف آنتی‌بیوتیک ندارد.**\n\n"
    "**بیایید ببینیم چرا این بیمار در هیچ گروه پرخطری نیست:**\n\n"
    "**علائم حیاتی پایدار و فشار ۱۲۰/۷۰** → **نه شوک، نه دهیدراتاسیون شدید، نه بیماری شدید**.\n\n"
    "**گلبول سفید مدفوع فقط ۱۰ عدد** → **التهاب خفیف**، نه کولیت شدید.\n\n"
    "**هیچ اشاره‌ای به سن بالا، نقص ایمنی، پروتز، بیماری دریچه‌ای یا سیکل‌سل نیست.**\n\n"
    "**سابقه‌ی مصرف تخم‌مرغ** → منبع کلاسیک **سالمونلای غیرتیفی**.\n\n"
    "**پس: گاستروآنتریت سالمونلایی بدون عارضه در فرد سالم — که آنتی‌بیوتیک نمی‌خواهد.**\n\n"
    "⚠️ **و نکته‌ی مفهومی مهم: کشت مثبت، به‌خودی‌خود اندیکاسیون درمان نیست.**\n\n"
    "**این یکی از مهم‌ترین درس‌های طب عفونی است.** یافتن یک ارگانیسم، **یک واقعیت** است؛ "
    "تصمیم به درمان، **یک قضاوت بالینی** است که بر پایه‌ی **وضعیت بیمار** گرفته می‌شود، نه "
    "بر پایه‌ی برگه‌ی آزمایشگاه.\n\n"
    "**و یادآوری دلیل: آنتی‌بیوتیک در این بیمار (۱) مدت بیماری را کوتاه نمی‌کند، و (۲) مدت "
    "ناقلی را طولانی می‌کند** — چون فلور رقیب را سرکوب می‌کند و سالمونلا راحت‌تر در روده "
    "می‌ماند.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**آزیترومایسین تک‌دوز ۱ گرم:** درمان بی‌مورد. (آزیترومایسین در **تیفوئید بدون عارضه** "
    "یا در **سالمونلای مقاوم** جایی دارد، نه اینجا.)\n\n"
    "**فورازولیدون ۵ روز:** داروی قدیمی و کم‌استفاده، و **به‌هرحال اندیکاسیون درمان وجود ندارد**.\n\n"
    "⚠️ **سیپروفلوکساسین ۳ تا ۵ روز:** این **وسوسه‌انگیزترین گزینه** است، چون سیپروفلوکساسین "
    "**واقعاً روی سالمونلا مؤثر است**. ولی **مؤثر بودن با لازم بودن یکی نیست.** در این بیمار، "
    "درمان **سود ندارد** ولی **زیان دارد**: عوارض دارویی، طولانی شدن ناقلی، و فشار انتخابی "
    "برای مقاومت.",
    "The book asks the same rule again, this time WITH NUMBERS PROVING THE PATIENT IS STABLE.\n\n"
    "THE PATIENT: after eating eggs he has developed fever, diarrhoea and vomiting. Vital signs stable "
    "with a blood pressure of 120/70. The stool shows 10 white cells. Stool culture: SALMONELLA.\n\n"
    "WARNING, THE ANSWER: NO ANTIBIOTIC IS REQUIRED.\n\n"
    "LET US SEE WHY THIS PATIENT IS IN NO HIGH-RISK GROUP:\n\n"
    "STABLE VITAL SIGNS AND BP 120/70 mean NO SHOCK, NO SEVERE DEHYDRATION, NO SEVERE DISEASE.\n\n"
    "ONLY 10 STOOL WHITE CELLS means MILD INFLAMMATION, not severe colitis.\n\n"
    "THERE IS NO MENTION of advanced age, immunodeficiency, a prosthesis, valve disease or sickle-cell "
    "disease.\n\n"
    "A HISTORY OF EATING EGGS points to the classic source of NON-TYPHOIDAL SALMONELLA.\n\n"
    "SO: UNCOMPLICATED SALMONELLA GASTROENTERITIS IN A HEALTHY HOST — which needs no antibiotic.\n\n"
    "WARNING, AND AN IMPORTANT CONCEPTUAL POINT: A POSITIVE CULTURE IS NOT BY ITSELF AN INDICATION TO "
    "TREAT.\n\n"
    "THIS IS ONE OF THE MOST IMPORTANT LESSONS IN INFECTIOUS DISEASES. Finding an organism is A FACT; "
    "deciding to treat is A CLINICAL JUDGEMENT made on THE PATIENT'S CONDITION, not on the laboratory "
    "form.\n\n"
    "AND A REMINDER OF WHY: in this patient the antibiotic (1) DOES NOT SHORTEN THE ILLNESS, and (2) "
    "PROLONGS THE CARRIER STATE — because it suppresses the competing flora and Salmonella persists "
    "more easily.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "AZITHROMYCIN 1 g SINGLE DOSE: unnecessary treatment. (Azithromycin has a place in UNCOMPLICATED "
    "TYPHOID or in RESISTANT SALMONELLA, not here.)\n\n"
    "FURAZOLIDONE FOR 5 DAYS: an old and little-used drug, and IN ANY CASE THERE IS NO INDICATION TO "
    "TREAT.\n\n"
    "WARNING, CIPROFLOXACIN FOR 3 TO 5 DAYS: THE MOST TEMPTING OPTION, because ciprofloxacin IS "
    "GENUINELY EFFECTIVE against Salmonella. But BEING EFFECTIVE IS NOT THE SAME AS BEING NECESSARY. In "
    "this patient treatment offers NO BENEFIT but DOES CAUSE HARM: drug toxicity, prolonged carriage, "
    "and selective pressure for resistance.",
    ["درمان بی‌مورد؛ آزیترومایسین در تیفوئید بدون عارضه جا دارد، نه در گاستروآنتریت ساده.",
     "داروی قدیمی و کم‌استفاده، و به‌هرحال اندیکاسیون درمان وجود ندارد.",
     "وسوسه‌انگیزترین گزینه — مؤثر است ولی لازم نیست، و ناقلی را طولانی می‌کند.",
     "پاسخ صحیح — بیمار پایدار و بدون عامل خطر است؛ کشت مثبت اندیکاسیون درمان نیست."],
    ["Unnecessary treatment; azithromycin has a place in uncomplicated typhoid, not simple gastroenteritis.",
     "An old and little-used drug, and in any case there is no indication to treat.",
     "The most tempting option — effective but not necessary, and it prolongs carriage.",
     "Correct — the patient is stable with no risk factor; a positive culture is not an indication to treat."],
    "**کشت مثبت یک واقعیت است؛ تصمیم به درمان یک قضاوت بالینی.**",
    "A positive culture is a fact; the decision to treat is a clinical judgement.",
    SREFS)

add("book:436", "vignette", "hard",
    "**سالمونلای غیرتیفی با باکتریمی: درمان لازم است و طولانی — دو هفته.**",
    "Non-typhoidal Salmonella WITH BACTERAEMIA: treatment is required and prolonged — two weeks.",
    TX_FA + [
        "**این بیمار برخلاف دو سؤال قبلی، حتماً درمان می‌خواهد.**",
        "**و دلیلش یک جمله است: کشت خون مثبت شده است.**",
        "⚠️ **باکتریمی سالمونلایی، قاعده‌ی «درمان نکنید» را کاملاً وارونه می‌کند.**",
        "**چون سالمونلا در خون می‌تواند در هر جایی کانون بگذارد.**",
        "**آندوواسکولار، استخوان، مفصل، مننژ، یا آنوریسم مایکوتیک.**",
        "**و همین خطر کانون‌گذاری است که درمان طولانی را لازم می‌کند.**",
        "**دو هفته برای باکتریمی بدون کانون، استاندارد است.**",
        "⚠️ **و اگر کانون آندوواسکولار پیدا شود، شش هفته یا بیشتر.**",
        "**۴۸ ساعت برای باکتریمی به‌کلی ناکافی است و عود می‌دهد.**",
    ],
    TX_EN + [
        "Unlike the previous two questions, this patient definitely needs treatment.",
        "And the reason is one sentence: THE BLOOD CULTURE IS POSITIVE.",
        "WARNING, SALMONELLA BACTERAEMIA COMPLETELY INVERTS the 'do not treat' rule.",
        "Because Salmonella in the blood can seed anywhere.",
        "Endovascular sites, bone, joint, meninges, or a mycotic aneurysm.",
        "And it is that risk of seeding that requires prolonged treatment.",
        "Two weeks is standard for bacteraemia without a focus.",
        "WARNING, AND IF AN ENDOVASCULAR FOCUS IS FOUND, six weeks or more.",
        "Forty-eight hours is grossly inadequate for bacteraemia and invites relapse.",
    ],
    "این سؤال قاعده‌ی دو سؤال قبلی را **وارونه** می‌کند، و دلیل آن **در یک جمله** است.\n\n"
    "**بیمار: خانم ۳۵ ساله به دلیل درد شکم همراه با تب و اسهال غیرخونی بستری شده. نتیجه‌ی "
    "آزمایش مدفوع به نفع اسهال التهابی است. ⚠️ و این جمله‌ی کلیدی: «در کشت مدفوع و یک نوبت "
    "از سه نوبت کشت خون بیمار، سالمونلا تیفی‌موریوم رشد می‌کند.»**\n\n"
    "⚠️ **«کشت خون مثبت» همه‌چیز را عوض می‌کند.**\n\n"
    "**در دو سؤال قبلی، بیمار فقط گاستروآنتریت داشت و آنتی‌بیوتیک لازم نبود. اینجا "
    "باکتریمی وجود دارد — یعنی باکتری از روده به جریان خون رسیده است.**\n\n"
    "**چرا باکتریمی سالمونلایی این‌قدر جدی است؟ به‌دلیل خطر کانون‌گذاری (seeding):**\n\n"
    "سالمونلا در خون می‌تواند در هر جایی مستقر شود و **عفونت کانونی** بسازد:\n\n"
    "⚠️ **آندوواسکولار** — چسبیدن به **پلاک آترواسکلروتیک یا آنوریسم**، که **آنوریسم مایکوتیک** "
    "می‌سازد. **این خطرناک‌ترین عارضه است** و مرگ‌ومیر بالایی دارد. خطر آن در **بالای ۵۰ سال** "
    "و در **بیماران با بیماری عروقی** بیشتر است.\n\n"
    "**استخوان و مفصل** — **استئومیلیت سالمونلایی**، به‌ویژه در **بیماران سیکل‌سل**.\n\n"
    "**مننژ** — به‌ویژه در **شیرخواران**.\n\n"
    "**و طحال، کبد، کلیه** — آبسه‌های عمقی.\n\n"
    "**پس درمان لازم است. ولی چه مدت؟**\n\n"
    "**دو هفته** — این مدت استاندارد **باکتریمی سالمونلایی بدون کانون شناخته‌شده** است. "
    "⚠️ **و اگر کانون آندوواسکولار پیدا شود، شش هفته یا بیشتر** (به‌علاوه‌ی احتمالاً جراحی).\n\n"
    "**پس پاسخ: سیپروفلوکساسین به مدت ۲ هفته.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "⚠️ **سفتریاکسون به مدت ۴۸ ساعت:** **داروی درستی است، ولی مدت به‌کلی ناکافی.** ۴۸ ساعت "
    "برای **باکتریمی** بسیار کوتاه است و **عود تقریباً حتمی** است. (این دام کلاسیک «داروی "
    "درست، مدت غلط» است.)\n\n"
    "**کوتریموکسازول ۵ روز:** هم **مدت کوتاه** است و هم **مقاومت سالمونلا به کوتریموکسازول "
    "گسترده** شده است.\n\n"
    "**آمپی‌سیلین ۴ هفته:** **مقاومت گسترده** به آمپی‌سیلین وجود دارد. و **چهار هفته برای "
    "باکتریمی بدون کانون، بیش‌ازحد** است — چهار تا شش هفته برای **عفونت کانونی** (استئومیلیت، "
    "آندوواسکولار) کنار گذاشته می‌شود.\n\n"
    "**درس: در سالمونلا، سه سؤال بپرسید — آیا درمان لازم است؟ کدام دارو؟ و چه مدت؟ و پاسخ "
    "هر سه از وضعیت بیمار می‌آید، نه از نام باکتری.**",
    "This question INVERTS the rule of the previous two, and the reason lies IN ONE SENTENCE.\n\n"
    "THE PATIENT: a 35-year-old woman admitted with abdominal pain, fever and non-bloody diarrhoea. The "
    "stool result favours inflammatory diarrhoea. WARNING, AND THIS IS THE KEY SENTENCE: 'Salmonella "
    "typhimurium grows in the stool culture AND IN ONE OF THREE BLOOD CULTURES.'\n\n"
    "WARNING, 'A POSITIVE BLOOD CULTURE' CHANGES EVERYTHING.\n\n"
    "IN THE PREVIOUS TWO QUESTIONS the patient had gastroenteritis only and no antibiotic was needed. "
    "HERE THERE IS BACTERAEMIA — the organism has passed from the bowel into the bloodstream.\n\n"
    "WHY IS SALMONELLA BACTERAEMIA SO SERIOUS? BECAUSE OF THE RISK OF SEEDING:\n\n"
    "Salmonella in the blood can lodge anywhere and create A FOCAL INFECTION:\n\n"
    "WARNING, ENDOVASCULAR — adhering to AN ATHEROSCLEROTIC PLAQUE OR ANEURYSM, producing A MYCOTIC "
    "ANEURYSM. THIS IS THE MOST DANGEROUS COMPLICATION with a high mortality. Its risk is greater OVER "
    "AGE 50 and in PATIENTS WITH VASCULAR DISEASE.\n\n"
    "BONE AND JOINT — SALMONELLA OSTEOMYELITIS, especially in SICKLE-CELL patients.\n\n"
    "MENINGES — especially in INFANTS.\n\n"
    "AND SPLEEN, LIVER, KIDNEY — deep abscesses.\n\n"
    "SO TREATMENT IS REQUIRED. BUT FOR HOW LONG?\n\n"
    "TWO WEEKS — the standard duration for SALMONELLA BACTERAEMIA WITHOUT A KNOWN FOCUS. WARNING, AND "
    "IF AN ENDOVASCULAR FOCUS IS FOUND, SIX WEEKS OR MORE (plus probable surgery).\n\n"
    "SO THE ANSWER: CIPROFLOXACIN FOR 2 WEEKS.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "WARNING, CEFTRIAXONE FOR 48 HOURS: THE RIGHT DRUG BUT A GROSSLY INADEQUATE DURATION. Forty-eight "
    "hours is far too short for BACTERAEMIA and RELAPSE IS ALL BUT CERTAIN. (This is the classic 'right "
    "drug, wrong duration' trap.)\n\n"
    "CO-TRIMOXAZOLE FOR 5 DAYS: both TOO SHORT and subject to WIDESPREAD SALMONELLA RESISTANCE.\n\n"
    "AMPICILLIN FOR 4 WEEKS: WIDESPREAD RESISTANCE to ampicillin. And FOUR WEEKS IS EXCESSIVE for "
    "bacteraemia without a focus — four to six weeks is reserved for FOCAL INFECTION (osteomyelitis, "
    "endovascular).\n\n"
    "THE LESSON: IN SALMONELLA, ASK THREE QUESTIONS — is treatment needed? Which drug? And for how "
    "long? And all three answers come from THE PATIENT'S CONDITION, not from the organism's name.",
    ["داروی درست ولی مدت به‌کلی ناکافی — ۴۸ ساعت برای باکتریمی، عود تقریباً حتمی است.",
     "هم مدت کوتاه است و هم مقاومت سالمونلا به کوتریموکسازول گسترده شده است.",
     "پاسخ صحیح — باکتریمی سالمونلایی بدون کانون، دو هفته درمان می‌خواهد.",
     "مقاومت گسترده دارد، و چهار هفته برای باکتریمی بدون کانون بیش‌ازحد است."],
    ["The right drug but a grossly inadequate duration — 48 hours for bacteraemia invites relapse.",
     "Both too short and subject to widespread Salmonella resistance to co-trimoxazole.",
     "Correct — Salmonella bacteraemia without a focus requires two weeks of treatment.",
     "Widespread resistance, and four weeks is excessive for bacteraemia without a focus."],
    "**باکتریمی سالمونلایی می‌تواند در عروق، استخوان و مننژ کانون بگذارد — پس دو هفته.**",
    "Salmonella bacteraemia can seed vessels, bone and meninges — hence two weeks.",
    SREFS)

add("book:437", "vignette", "medium",
    "**تیفوئید با تابلوی توکسیک: سفتریاکسون وریدی، پس از گرفتن کشت خون.**",
    "Typhoid with a toxic picture: INTRAVENOUS CEFTRIAXONE, after taking blood cultures.",
    TX_FA + [
        "**این بیمار همه‌ی اجزای تیفوئید را دارد و بدحال هم هست.**",
        "**تب ۳۹، نبض ۸۰، کنفیوز و آپاتیک، زبان خشک و کبابی.**",
        "⚠️ **راش رزئولا روی سینه و شکم، و طحال قابل لمس.**",
        "**و لکوپنی ۳۰۰۰ با ترومبوسیتوپنی ۱۰۰ هزار.**",
        "**پس بیماری شدید است و درمان وریدی می‌خواهد.**",
        "**سفالوسپورین نسل سوم وریدی، یعنی سفتریاکسون، انتخاب است.**",
        "**چون مقاومت به فلوروکینولون در آسیای جنوبی و خاورمیانه گسترده شده.**",
        "⚠️ **و کلرامفنیکل، داروی تاریخی تیفوئید، به‌دلیل آپلازی مغز استخوان کنار گذاشته شده.**",
    ],
    TX_EN + [
        "This patient has every component of typhoid and is also very unwell.",
        "Fever 39, pulse 80, confused and apathetic, a dry and furred tongue.",
        "WARNING, ROSE SPOTS on the chest and abdomen, and a palpable spleen.",
        "And leucopenia of 3000 with thrombocytopenia of 100,000.",
        "So this is severe disease requiring intravenous treatment.",
        "An intravenous third-generation cephalosporin, ceftriaxone, is the choice.",
        "Because fluoroquinolone resistance has spread widely in South Asia and the Middle East.",
        "WARNING, AND CHLORAMPHENICOL, the historic typhoid drug, was abandoned for marrow aplasia.",
    ],
    "این سؤال **درمان تیفوئید شدید** را می‌سنجد، و ترتیب اقدامات هم در آن مهم است.\n\n"
    "**بیمار: نوجوان ۲۰ ساله با تب شدید، سردرد، درد شکم و بی‌اشتهایی از یک هفته‌ی قبل. تب "
    "۳۹، نبض ۸۰، فشار خون طبیعی. کنفیوز و آپاتیک به نظر می‌رسد. زبان خشک و کبابی. شکم متسع، "
    "طحال قابل لمس، و چندین راش ماکولوپاپولر صورتی محوشونده در قفسه‌ی سینه و شکم. لکوپنی "
    "۳۰۰۰ و ترومبوسیتوپنی ۱۰۰ هزار.**\n\n"
    "**تشخیص قطعی است — همه‌ی اجزای تیفوئید حاضرند:**\n\n"
    "⚠️ **تب ۳۹ با نبض ۸۰** = برادی‌کاردی نسبی · **راش صورتی محوشونده** = رزئولا · **زبان "
    "خشک و کبابی** ✔ · **طحال قابل لمس** ✔ · **لکوپنی ۳۰۰۰** ✔ · **یک هفته تب تدریجی** ✔\n\n"
    "**و «کنفیوز و آپاتیک» یعنی حالت تیفوئیدی — نشانه‌ی بیماری شدید.**\n\n"
    "**سؤال هم صریحاً گفته: «بعد از گرفتن کشت خون» — یعنی ترتیب درست را فرض گرفته: "
    "کشت قبل از آنتی‌بیوتیک.**\n\n"
    "⚠️ **پاسخ: سفتریاکسون وریدی.**\n\n"
    "**چرا سفالوسپورین نسل سوم؟ دو دلیل:**\n\n"
    "**دلیل یک — مقاومت.** ⚠️ **مقاومت سالمونلا تیفی به فلوروکینولون‌ها در آسیای جنوبی، "
    "خاورمیانه و آفریقا به‌شدت گسترش یافته است.** به همین دلیل، **سفتریاکسون امروز در صدر "
    "فهرست درمان تجربی** است، نه سیپروفلوکساسین.\n\n"
    "**دلیل دو — شدت بیماری.** بیمار **کنفیوز و آپاتیک** است و **لکوپنی و ترومبوسیتوپنی** "
    "دارد. **بیماری شدید، درمان وریدی می‌خواهد** — نه خوراکی.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "⚠️ **کلرامفنیکل + جنتامایسین وریدی:** **کلرامفنیکل داروی تاریخی تیفوئید بود** — و "
    "بسیار مؤثر هم بود. **ولی کنار گذاشته شد**، به دو دلیل: **آپلازی مغز استخوان** (یک عارضه‌ی "
    "نادر ولی **کشنده و غیروابسته به دوز**)، و **گسترش مقاومت**. و **جنتامایسین در تیفوئید "
    "بی‌فایده است** — چون آمینوگلیکوزیدها **در داخل سلول** (جایی که سالمونلا تیفی زندگی می‌کند) "
    "**فعالیت ندارند**. این نکته‌ی ظریفی است: باکتری داخل ماکروفاژ است، و جنتامایسین به آنجا "
    "نمی‌رسد.\n\n"
    "**داکسی‌سیکلین وریدی:** داروی **بروسلوز، ریکتزیا و لپتوسپیروز** است. **در تیفوئید نقشی "
    "ندارد.**\n\n"
    "**وانکومایسین + مترونیدازول وریدی:** ⚠️ **از پایه غلط.** وانکومایسین برای **گرم مثبت‌ها** "
    "است و مترونیدازول برای **بی‌هوازی‌ها**. **سالمونلا تیفی یک باسیل گرم منفی هوازی اختیاری "
    "است** — هیچ‌کدام از این دو پوششی روی آن ندارند. (این رژیم برای **کولیت کلستریدیوم "
    "دیفیسیل فولمینانت** است، نه تیفوئید.)",
    "This question tests THE TREATMENT OF SEVERE TYPHOID, and the ORDER of steps matters too.\n\n"
    "THE PATIENT: a 20-year-old with high fever, headache, abdominal pain and anorexia for a week. "
    "Temperature 39, pulse 80, normal blood pressure. He appears CONFUSED AND APATHETIC. The tongue is "
    "dry and furred. The abdomen is distended, the spleen palpable, and there are several blanching "
    "pink maculopapular lesions on the chest and abdomen. Leucopenia of 3000 and thrombocytopenia of "
    "100,000.\n\n"
    "THE DIAGNOSIS IS CERTAIN — every component of typhoid is present:\n\n"
    "WARNING, A FEVER OF 39 WITH A PULSE OF 80 means relative bradycardia; BLANCHING PINK LESIONS are "
    "rose spots; A DRY FURRED TONGUE; A PALPABLE SPLEEN; LEUCOPENIA OF 3000; and A WEEK OF GRADUAL FEVER.\n\n"
    "AND 'CONFUSED AND APATHETIC' MEANS THE TYPHOID STATE — a marker of severe disease.\n\n"
    "THE QUESTION ALSO STATES 'AFTER TAKING BLOOD CULTURES' — presupposing the correct order: CULTURE "
    "BEFORE ANTIBIOTIC.\n\n"
    "WARNING, THE ANSWER: INTRAVENOUS CEFTRIAXONE.\n\n"
    "WHY A THIRD-GENERATION CEPHALOSPORIN? Two reasons:\n\n"
    "REASON ONE — RESISTANCE. WARNING, SALMONELLA TYPHI RESISTANCE TO FLUOROQUINOLONES HAS SPREAD "
    "MARKEDLY IN SOUTH ASIA, THE MIDDLE EAST AND AFRICA. That is why CEFTRIAXONE NOW HEADS THE "
    "EMPIRICAL LIST rather than ciprofloxacin.\n\n"
    "REASON TWO — DISEASE SEVERITY. The patient is CONFUSED AND APATHETIC with LEUCOPENIA AND "
    "THROMBOCYTOPENIA. SEVERE DISEASE REQUIRES INTRAVENOUS TREATMENT, not oral.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "WARNING, CHLORAMPHENICOL PLUS INTRAVENOUS GENTAMICIN: CHLORAMPHENICOL WAS THE HISTORIC TYPHOID "
    "DRUG — and a very effective one. BUT IT WAS ABANDONED for two reasons: MARROW APLASIA (a rare but "
    "FATAL AND DOSE-INDEPENDENT reaction), and SPREADING RESISTANCE. And GENTAMICIN IS USELESS IN "
    "TYPHOID — because aminoglycosides HAVE NO ACTIVITY INSIDE CELLS, which is where Salmonella typhi "
    "lives. This is a subtle point: the organism is inside the macrophage, and gentamicin does not "
    "reach it there.\n\n"
    "INTRAVENOUS DOXYCYCLINE: a drug for BRUCELLOSIS, RICKETTSIA AND LEPTOSPIROSIS. IT HAS NO ROLE IN "
    "TYPHOID.\n\n"
    "INTRAVENOUS VANCOMYCIN PLUS METRONIDAZOLE: WARNING, WRONG FROM THE START. Vancomycin is for GRAM "
    "POSITIVES and metronidazole for ANAEROBES. SALMONELLA TYPHI IS A FACULTATIVELY AEROBIC "
    "GRAM-NEGATIVE BACILLUS — neither covers it. (That regimen is for FULMINANT C. DIFFICILE COLITIS, "
    "not typhoid.)",
    ["کلرامفنیکل به‌دلیل آپلازی مغز استخوان کنار گذاشته شد، و جنتامایسین داخل سلول اثر ندارد.",
     "داروی بروسلوز و ریکتزیا و لپتوسپیروز است؛ در تیفوئید نقشی ندارد.",
     "پاسخ صحیح — سفالوسپورین نسل سوم وریدی، به‌دلیل مقاومت گسترده به فلوروکینولون و شدت بیماری.",
     "از پایه غلط — وانکومایسین برای گرم مثبت و مترونیدازول برای بی‌هوازی؛ هیچ‌کدام سالمونلا را پوشش نمی‌دهند."],
    ["Chloramphenicol was abandoned for marrow aplasia, and gentamicin has no intracellular activity.",
     "A drug for brucellosis, rickettsia and leptospirosis; it has no role in typhoid.",
     "Correct — an intravenous third-generation cephalosporin, given widespread fluoroquinolone resistance and severity.",
     "Wrong from the start — vancomycin is for gram positives and metronidazole for anaerobes."],
    "**جنتامایسین داخل سلول کار نمی‌کند — و سالمونلا تیفی داخل ماکروفاژ زندگی می‌کند.**",
    "Gentamicin does not work inside cells — and Salmonella typhi lives inside the macrophage.",
    SREFS)

add("book:438", "vignette", "easy",
    "**تیفوئید تجربی با برادی‌کاردی نسبی: سفتریاکسون وریدی.**",
    "Empirical typhoid with relative bradycardia: INTRAVENOUS CEFTRIAXONE.",
    TX_FA + [
        "**این آخرین سؤال فصل است و همان قاعده‌ی درمان تجربی را می‌سنجد.**",
        "**سؤال خودش تشخیص را داده: «شک به تب تیفوئید».**",
        "⚠️ **و سرنخ کلیدی را هم صریح گفته: برادی‌کاردی نسبی.**",
        "**پس فقط انتخاب دارو باقی می‌ماند.**",
        "**سفتریاکسون وریدی، انتخاب تجربی امروز است.**",
        "**چون مقاومت به فلوروکینولون گسترده شده و سفتریاکسون پوشش قابل اتکایی می‌دهد.**",
        "**و در بیمار بستری با تب طول‌کشیده، راه وریدی ارجح است.**",
        "⚠️ **کوتریموکسازول هم به‌دلیل مقاومت گسترده کنار گذاشته شده است.**",
    ],
    TX_EN + [
        "This is the chapter's last question and tests the same empirical treatment rule.",
        "The question itself gives the diagnosis: 'suspected typhoid fever'.",
        "WARNING, AND IT STATES THE KEY CLUE EXPLICITLY: relative bradycardia.",
        "So only the drug choice remains.",
        "Intravenous ceftriaxone is today's empirical choice.",
        "Because fluoroquinolone resistance has spread and ceftriaxone gives reliable cover.",
        "And in an inpatient with prolonged fever the intravenous route is preferred.",
        "WARNING, CO-TRIMOXAZOLE HAS ALSO BEEN ABANDONED for widespread resistance.",
    ],
    "این **آخرین سؤال فصل گوارشی** است، و با تکمیل آن این فصل ۱۰۰ درصد کامل می‌شود.\n\n"
    "**بیمار: آقای ۵۰ ساله با تب از چند روز قبل، درد شکم و یبوست. در معاینه علائم حاد شکمی "
    "ندارد ولی هپاتواسپلنومگالی دارد. ⚠️ و سؤال صریحاً می‌گوید: «با توجه به برادی‌کاردی نسبی "
    "و شک به تب تیفوئید».**\n\n"
    "**پس سؤال تشخیص را داده و فقط انتخاب دارو را می‌خواهد. ولی بیایید تابلو را هم تأیید "
    "کنیم:**\n\n"
    "**تب چند روزه** ✔ · **درد شکم** ✔ · ⚠️ **یبوست** ✔ (و به یاد بیاورید: در بزرگ‌سال، "
    "یبوست شایع‌تر از اسهال است) · **هپاتواسپلنومگالی** ✔ · **برادی‌کاردی نسبی** ✔\n\n"
    "**پاسخ: سفتریاکسون وریدی.**\n\n"
    "**چرا سفتریاکسون؟ سه دلیل:**\n\n"
    "**دلیل یک — مقاومت.** ⚠️ **مقاومت سالمونلا تیفی به فلوروکینولون‌ها در آسیای جنوبی، "
    "خاورمیانه و آفریقا گسترده شده است.** در بسیاری از مناطق، **بیش از نیمی از سویه‌ها** "
    "حساسیت کاهش‌یافته به سیپروفلوکساسین دارند. **پس درمان تجربی نمی‌تواند بر آن تکیه کند.**\n\n"
    "**دلیل دو — قابلیت اتکا.** سفالوسپورین‌های نسل سوم **پوشش قابل اتکایی** روی سالمونلا "
    "تیفی دارند، حتی در سویه‌های **مقاوم به چند دارو (MDR)**.\n\n"
    "**دلیل سه — راه تجویز.** بیمار **بستری** است و **تب طول‌کشیده** دارد. **راه وریدی** "
    "جذب مطمئن را تضمین می‌کند، به‌ویژه در بیماری که ممکن است تهوع و استفراغ داشته باشد.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**سیپروفلوکساسین خوراکی:** ⚠️ **دو ایراد.** یک: **مقاومت گسترده** به فلوروکینولون‌ها. "
    "دو: در بیمار بستری با تب طول‌کشیده، **راه خوراکی کمتر مطمئن** است. (سیپروفلوکساسین "
    "زمانی خط اول بود — این یکی از روشن‌ترین نمونه‌های **جابه‌جایی راهنما به‌دلیل مقاومت** است.)\n\n"
    "**کوتریموکسازول خوراکی:** **مقاومت گسترده** به آن هم وجود دارد. کوتریموکسازول یکی از "
    "سه داروی کلاسیک تیفوئید بود (کنار کلرامفنیکل و آمپی‌سیلین) — و **هر سه به‌دلیل مقاومت "
    "کنار گذاشته شدند**، که همان **سویه‌های MDR** را تعریف می‌کند.\n\n"
    "⚠️ **کلرامفنیکل وریدی:** **داروی تاریخی تیفوئید** — و در زمان خود انقلابی بود. ولی "
    "کنار گذاشته شد به دو دلیل: **آپلازی مغز استخوان** (عارضه‌ای نادر ولی **کشنده و "
    "غیروابسته به دوز**، یعنی حتی با دوز درست هم ممکن است رخ دهد) و **گسترش مقاومت**. امروز "
    "فقط در شرایط بسیار محدود استفاده می‌شود.\n\n"
    "**و با این سؤال، فصل عفونت‌های گوارشی و اسهال کامل می‌شود: ۸۴ از ۸۴.**",
    "This is THE LAST QUESTION OF THE GASTROINTESTINAL CHAPTER, and with it the chapter reaches 100%.\n\n"
    "THE PATIENT: a 50-year-old man with fever for several days, abdominal pain and CONSTIPATION. "
    "Examination shows no acute abdominal signs but there is HEPATOSPLENOMEGALY. WARNING, AND THE "
    "QUESTION STATES EXPLICITLY: 'given the relative bradycardia and suspected typhoid fever'.\n\n"
    "SO THE QUESTION HAS GIVEN THE DIAGNOSIS AND ASKS ONLY FOR THE DRUG. But let us confirm the picture:\n\n"
    "SEVERAL DAYS OF FEVER, ABDOMINAL PAIN, WARNING, CONSTIPATION (and recall: in adults constipation is "
    "commoner than diarrhoea), HEPATOSPLENOMEGALY, and RELATIVE BRADYCARDIA.\n\n"
    "THE ANSWER: INTRAVENOUS CEFTRIAXONE.\n\n"
    "WHY CEFTRIAXONE? Three reasons:\n\n"
    "REASON ONE — RESISTANCE. WARNING, SALMONELLA TYPHI RESISTANCE TO FLUOROQUINOLONES IS WIDESPREAD IN "
    "SOUTH ASIA, THE MIDDLE EAST AND AFRICA. In many regions MORE THAN HALF OF STRAINS have reduced "
    "ciprofloxacin susceptibility. SO EMPIRICAL TREATMENT CANNOT RELY ON IT.\n\n"
    "REASON TWO — RELIABILITY. Third-generation cephalosporins give RELIABLE COVER against Salmonella "
    "typhi, even in MULTIDRUG-RESISTANT (MDR) strains.\n\n"
    "REASON THREE — THE ROUTE. The patient is AN INPATIENT with PROLONGED FEVER. THE INTRAVENOUS ROUTE "
    "guarantees absorption, especially in someone who may have nausea and vomiting.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ORAL CIPROFLOXACIN: WARNING, TWO FAULTS. One: WIDESPREAD FLUOROQUINOLONE RESISTANCE. Two: in an "
    "inpatient with prolonged fever THE ORAL ROUTE IS LESS RELIABLE. (Ciprofloxacin was once first "
    "line — this is one of the clearest examples of A GUIDELINE MOVING BECAUSE OF RESISTANCE.)\n\n"
    "ORAL CO-TRIMOXAZOLE: WIDESPREAD RESISTANCE to it as well. Co-trimoxazole was one of the three "
    "classic typhoid drugs (with chloramphenicol and ampicillin) — and ALL THREE WERE ABANDONED FOR "
    "RESISTANCE, which is exactly what defines an MDR strain.\n\n"
    "WARNING, INTRAVENOUS CHLORAMPHENICOL: THE HISTORIC TYPHOID DRUG — revolutionary in its day. But it "
    "was abandoned for two reasons: MARROW APLASIA (a rare but FATAL AND DOSE-INDEPENDENT reaction, "
    "which can occur even at correct doses) and SPREADING RESISTANCE. Today it is used only in very "
    "limited circumstances.\n\n"
    "AND WITH THIS QUESTION, THE CHAPTER ON GASTROINTESTINAL INFECTIONS IS COMPLETE: 84 OF 84.",
    ["مقاومت گسترده به فلوروکینولون‌ها، و راه خوراکی در بیمار بستری کمتر مطمئن است.",
     "پاسخ صحیح — سفالوسپورین نسل سوم وریدی، انتخاب تجربی امروز در تیفوئید.",
     "مقاومت گسترده دارد؛ یکی از سه داروی کلاسیکی که سویه‌های MDR را تعریف می‌کنند.",
     "داروی تاریخی تیفوئید، ولی به‌دلیل آپلازی مغز استخوان و مقاومت کنار گذاشته شد."],
    ["Widespread fluoroquinolone resistance, and the oral route is less reliable in an inpatient.",
     "Correct — an intravenous third-generation cephalosporin, today's empirical choice in typhoid.",
     "Widespread resistance; one of the three classic drugs whose loss defines MDR strains.",
     "The historic typhoid drug, but abandoned for marrow aplasia and resistance."],
    "**سه داروی کلاسیک تیفوئید همه به‌دلیل مقاومت کنار رفتند — و MDR یعنی همان سه.**",
    "The three classic typhoid drugs were all lost to resistance — and MDR means exactly those three.",
    SREFS)

json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book50.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 50 lessons:', len(L))
