# -*- coding: utf-8 -*-
"""English stems and options for the taught book questions.

Why hand-written rather than machine-translated
-----------------------------------------------
These are clinical questions where a single mistranslated number, drug name or
negation changes the answer. Machine translation of hundreds of vignettes would
introduce exactly the class of silent error this project has spent its effort
eliminating. So the English is written by hand, and only for questions that
already have a hand-written bilingual lesson — that way stem, options and
teaching text all say the same thing.

Rule 16 was checked first: the ministry's own English booklets cover Esfand-1400
and Khordad-1402, while this book covers sittings 93-98. There is no official
translation to reuse for these items, so an original one is the only option.

Every number here was taken from the stem AFTER the age, mixed-digit and
vital-sign repairs, and apply_en.py re-checks each digit run before attaching
anything: a vignette whose Persian says "25-year-old" and whose English says
"35-year-old" is worse than no translation at all. That guard has repeatedly
earned its keep — it caught nine stems here where I had abbreviated away a
laboratory value that the Persian states.

Each entry keys off the flat index into the concatenated book payload.
"""

EN = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    assert all(o.strip() for o in options), idx
    EN[idx] = {"stem_en": stem, "options_en": options}


# ------------------------------------------------ sepsis / fever / FUO
add(0,
    "Which of the following plays NO part in the pathogenesis of hyperthermia?",
    ["Heat production within the body",
     "A shift in the hypothalamic temperature set point",
     "Increased environmental heat",
     "Use of certain neuroleptic drugs such as MAO inhibitors"])

add(2,
    "A patient develops headache, fever, body pain, myalgia, arthralgia and confusion 10 days "
    "after travelling to Zanjan. He also has a cough with streaks of blood. On examination his "
    "temperature is 40 degrees, and he has conjunctival suffusion and subicterus. The lungs are "
    "clear on auscultation and the heart is tachycardic. Which of the following is most likely?",
    ["Viral haemorrhagic fever",
     "Leptospirosis",
     "Tick-borne relapsing fever",
     "Louse-borne relapsing fever"])

add(5,
    "All of the following fit the definition of classic FUO, EXCEPT",
    ["A fever lasting more than one week",
     "Three outpatient visits",
     "One week of invasive investigation",
     "Three days of hospital stay"])

add(8,
    "A 45-year-old man with no known underlying disease presents with a fever of about one "
    "month's duration. He has night fevers and clear weight loss, and reports no symptom other "
    "than fever. Outpatient investigation has not identified a cause. Which investigation do you "
    "prefer next?",
    ["Chest CT scan",
     "ESR and CRP",
     "Blood culture",
     "Abdominal and pelvic ultrasound"])

# ------------------------------------------------ skin and soft tissue
add(26,
    "A 32-year-old man sustained an open fracture of the right leg bones in a motorcycle accident "
    "and is admitted to the trauma ward. During the first 24 hours of admission he requires high "
    "doses of intravenous opioid because of severe and increasing pain at the trauma site, yet he "
    "still complains of pain there. The splint is opened, revealing marked swelling, dark blisters "
    "and thin, foul-smelling discharge from the trauma site. His vital signs are: blood pressure "
    "85/60, pulse 125 per minute and temperature 37.9. Which action do you prioritise?",
    ["MRI of the affected limb",
     "Transfer the patient to theatre for debridement",
     "Angiography of the affected limb",
     "Colour Doppler venous ultrasound of the affected limb"])

add(30,
    "A 47-year-old abattoir worker presents with a skin lesion on his left forearm. It began as a "
    "small papule with mild itch and finally became a painless ulcer with marked oedema. A smear "
    "from the lesion shows bacilli. What is the most likely diagnosis?",
    ["Orf",
     "Erysipeloid",
     "Anthrax",
     "Cutaneous leishmaniasis"])

# ------------------------------------------------ respiratory
add(36,
    "A 9-year-old girl presents with fever, headache and sore throat for 2 days. On examination "
    "she has bilateral anterior cervical lymphadenopathy with swollen tonsils and exudate, and a "
    "diffuse maculopapular rash that is rough to the touch. Which of the following is the most "
    "likely cause?",
    ["Adenovirus",
     "Epstein-Barr virus",
     "Staphylococcus aureus",
     "Beta-haemolytic streptococcus"])

add(38,
    "A 10-year-old child presents with streptococcal pharyngitis. In the case of a non-immediate "
    "penicillin allergy, which of the following drugs is NOT recommended for treatment?",
    ["Erythromycin",
     "Azithromycin",
     "Cephalexin",
     "Cefixime"])

# ------------------------------------------------ bone and joint
add(68,
    "A 45-year-old haemodialysis patient presents with fever, thoracic back pain and lower limb "
    "weakness. He is febrile with tenderness on palpation of the thoracic vertebrae. Given the "
    "most likely diagnosis, which investigation do you prefer?",
    ["Whole body bone scan",
     "Vertebral CT scan",
     "MRI",
     "Thoracic X-ray"])

# ------------------------------------------------ vaccination
add(78,
    "Pneumococcal vaccine is recommended in all of the following, EXCEPT",
    ["A diabetic patient treated with glibenclamide",
     "A patient with a history of splenectomy",
     "A person with hepatic cirrhosis",
     "A patient with a complement deficiency (C5-C9)"])

# ------------------------------------------------ pneumonia
add(81,
    "A 52-year-old man presents to the emergency department with fever and productive cough for "
    "two days. The chest film shows opacity in the left lower lobe. He has no underlying disease "
    "and has taken no antibiotics in the past three months. All of the following treatments are "
    "appropriate for him EXCEPT",
    ["Clarithromycin",
     "Doxycycline",
     "Azithromycin",
     "Ciprofloxacin"])

add(91,
    "A 67-year-old man attends the emergency screening area with fever, rigors and productive "
    "cough. His vital signs are: T 39 C, BP 100/70 mmHg, PR 120/min, RR 25/min. He is fully alert. "
    "On examination there are reduced breath sounds at the right lung base with crackles. He has "
    "no previous illness and has taken no medication in the past year. Initial tests are: WBC 14.5 "
    "x 10^3 per mm3, Hb 13.4 mg/dL, HCT 45, platelets 180 x 10^3 per mm3, Na 140 mmol/L, K 4.3 "
    "mmol/L, urea 5 mmol/L, creatinine 1.5 mg/dL, and oxygen saturation 95 percent on room air. "
    "Which of the following do you recommend for his treatment?",
    ["Azithromycin as an outpatient",
     "Ceftriaxone and azithromycin on a general ward",
     "Levofloxacin on a general ward",
     "Ceftriaxone and levofloxacin in the ICU"])

# ------------------------------------------------ endocarditis
add(103,
    "An injecting drug user presents with a temperature of 38 degrees Celsius for one week and "
    "shortness of breath for two days. A single blood culture has isolated Staphylococcus "
    "epidermidis susceptible to vancomycin. What is the appropriate next step?",
    ["Repeat blood cultures and echocardiography",
     "Start intravenous vancomycin",
     "Start intravenous vancomycin and perform echocardiography",
     "CT pulmonary angiography and treatment for pulmonary embolism"])

add(106,
    "An injecting drug user presents with high fever, shortness of breath and haemorrhagic lesions "
    "on the palms and soles for several days. His WBC is 13500 and ESR is 75, and the chest "
    "radiograph shows multiple round lesions in both lungs. Given the most likely diagnosis, which "
    "investigation would confirm it?",
    ["Chest CT scan",
     "CT pulmonary angiography",
     "Blood cultures plus echocardiography",
     "Abdominal and pelvic ultrasound plus urine culture"])

add(111,
    "Which of the following is a MAJOR criterion for the diagnosis of endocarditis?",
    ["Glomerulonephritis",
     "A history of injecting drug use",
     "Isolation of Staphylococcus aureus from a single blood culture",
     "A mobile vegetation on the affected valve reported on echocardiography"])

add(112,
    "A 22-year-old injecting drug user is admitted to the emergency department with high fever and "
    "severe weakness. On examination there is marked tachycardia. Painless subcutaneous ecchymotic "
    "lesions are visible on the soles of his feet. He is hypoxic and the chest radiograph shows "
    "multiple lesions. How many Duke criteria does he meet?",
    ["Five minor criteria",
     "One major and three minor criteria",
     "Three minor criteria",
     "Two minor criteria"])

add(129,
    "A 10-year-old boy who underwent VSD surgery 2 months ago is to have a tooth extracted by the "
    "dentist. Given that he reports a history of immediate hypersensitivity to penicillin, which is "
    "the most appropriate choice for endocarditis prophylaxis?",
    ["Cephalexin",
     "Vancomycin",
     "Clindamycin",
     "No prophylaxis is required"])

# ------------------------------------------------ typhoid
add(134,
    "A 25-year-old man has had high fever, headache, abdominal pain, severe anorexia, constipation "
    # The pulse was repaired from glyph geometry after this translation was
    # first written: page 52 prints 84, not 48. The numeric inspector in
    # apply_en.py caught the stale English, which is exactly its purpose. The
    # value is not cosmetic — 84 with a fever of 40 is RELATIVE BRADYCARDIA
    # (Faget's sign), a classical clue to typhoid; 48 would be an absolute
    # bradycardia suggesting something else.
    "and dry cough for about 2 weeks. On examination he is febrile at 40 C with a pulse of 84 and a "
    "respiratory rate of 20 per minute and a normal blood pressure. There is no neck stiffness, the "
    "abdomen is soft and the lungs are clear. In the past week he had several faint pink lesions on "
    "the abdomen and chest. The chest film is normal. The CBC shows a white cell count of 3500 and "
    "platelets of 135000. Given the likely diagnosis, which complication is most likely in this man?",
    ["Meningitis",
     "Intestinal perforation",
     "Splenic rupture",
     "Empyema"])

# ------------------------------------------------ CNS infection
add(135,
    "You review a 25-year-old woman in the emergency department. She has been admitted with fever, "
    "severe headache, nausea and vomiting. Six months ago, following a road accident and an "
    "alteration in consciousness, she spent 3 days in a trauma hospital but had no surgery. Which "
    "organism is the most likely cause?",
    ["Staphylococcus aureus",
     "Streptococcus pneumoniae",
     "Pseudomonas aeruginosa",
     "Listeria monocytogenes"])

add(136,
    "An adolescent who underwent splenectomy after trauma develops fever, tachycardia, tachypnoea, "
    "hypotension and a skin rash. The rash was initially pink maculopapular on the trunk and limbs "
    "and blanched on pressure, but later became haemorrhagic. Which organism is most likely "
    "responsible?",
    ["Neisseria meningitidis",
     "Group A beta-haemolytic streptococcus",
     "Clostridium perfringens",
     "Staphylococcus epidermidis"])

add(141,
    "You review a young man with fever and a declining level of consciousness that has progressed "
    "since yesterday. On examination he has neck stiffness, and fundoscopy shows papilloedema. "
    "Which of the following is the correct ORDER of management?",
    ["Blood cultures, lumbar puncture, then start antibiotic and antiviral treatment",
     "Lumbar puncture, start antibiotic and antiviral treatment, then brain imaging",
     "Brain imaging, lumbar puncture, then start antibiotic and antiviral treatment",
     "Blood cultures, start antibiotic and antiviral treatment, then brain imaging"])

add(142,
    "A 19-year-old man with no underlying disease presents with severe headache, fever, nausea and "
    "vomiting worsening since yesterday. He has never experienced a headache of this severity. On "
    "physical examination his consciousness and orientation are intact, there are no focal "
    "neurological signs and fundoscopy is normal, but he has neck stiffness. What is the correct "
    "order of management?",
    ["Start antibiotics, CT scan, lumbar puncture",
     "CT scan, lumbar puncture, blood cultures, start antibiotics",
     "Blood cultures, start antibiotics, lumbar puncture",
     "Blood cultures, start antibiotics, CT scan, lumbar puncture"])

add(159,
    "A 35-year-old patient presents with fever, rigors, headache and vomiting, and neck stiffness "
    "is evident on examination. The cerebrospinal fluid shows: WBC 1200 (PMN 85 percent, "
    "lymphocytes 15 percent), glucose 25, protein 150, and a positive Limulus lysate test. Which is "
    "the most likely causative organism?",
    ["Streptococcus pneumoniae",
     "Mycobacterium tuberculosis",
     "Staphylococcus aureus",
     "Neisseria meningitidis"])

add(179,
    "A 60-year-old man is brought to the emergency department with severe headache, fever, neck "
    "stiffness and drowsiness. After lumbar puncture, CSF analysis shows 1000 white cells with a "
    "predominance of PMN at 80 percent, glucose 25 mg/dL and protein 200 mg/dL. Until the CSF "
    "culture result is ready, which treatment regimen do you recommend for him?",
    ["Ceftriaxone plus vancomycin",
     "Cefotaxime plus gentamicin",
     "Cefepime plus vancomycin",
     "Ceftriaxone plus vancomycin plus ampicillin"])

add(189,
    "A 1-year-old patient with no significant past history and no head trauma is brought to the "
    "emergency department in spring with fever, headache, nausea and vomiting for two days. The "
    "patient is alert, has no focal neurological signs and fundoscopy is normal. CSF examination "
    "shows 250 cells with a lymphocyte predominance, glucose 75 mg/dL (with a simultaneous blood "
    "glucose of 90 mg/dL) and protein 60 mg/dL. Which of the following treatments is correct?",
    ["Ceftriaxone plus vancomycin",
     "Ceftriaxone plus ampicillin",
     "Supportive treatment",
     "Aciclovir"])

# ------------------------------------------------ tuberculosis
add(234,
    "In a young patient with smear-positive pulmonary tuberculosis who is receiving four-drug "
    "therapy, which method do you choose to monitor the response to treatment?",
    ["Liver function tests and CBC at regular intervals",
     "Chest radiographs at regular intervals",
     "Sputum smear examination at the end of the second, fifth and sixth months of treatment",
     "Tuberculin skin test (PPD) at the end of the second, fifth and sixth months of treatment"])

add(241,
    "A 60-year-old woman with pulmonary tuberculosis is being treated with the standard four-drug "
    "regimen. Two weeks after starting the drugs her doctor reviews her. She is pleased with her "
    "improved appetite and reduced fever and weakness, and says she has taken the drugs regularly. "
    "Liver tests are requested and reported as: AST 90 (normal 0 to 40), ALT 95 (normal 0 to 40), "
    "ALP 250 (up to 350) and LDH 367 (normal 0 to 500). What is the appropriate action?",
    ["Stop all anti-tuberculous drugs and repeat the tests one week later",
     "Stop isoniazid, rifampicin and pyrazinamide and repeat the tests one week later",
     "Continue anti-tuberculous treatment with the standard regimen as before",
     "Request an ultrasound of the liver and biliary tract"])

add(243,
    "A 40-year-old woman from Zahedan, who has been receiving four-drug anti-tuberculous treatment "
    "(isoniazid, rifampicin, pyrazinamide, ethambutol) for about 20 days for pulmonary tuberculosis, "
    "presents with nausea, vomiting and abdominal pain. Investigations show a marked rise in liver "
    "enzymes. What is the appropriate action?",
    ["Continue anti-tuberculous treatment and recheck the liver enzymes next week",
     "Stop rifampicin and continue the remaining anti-tuberculous drugs in divided doses",
     "Stop all the patient's drugs and restart after the symptoms resolve and the enzymes are nearly normal",
     "Add symptomatic anti-emetic treatment and change the timing of the drugs"])

add(248,
    "The risk of visual impairment is associated with which of the following anti-tuberculous drugs?",
    ["Isoniazid",
     "Ethambutol",
     "Rifampicin",
     "Pyrazinamide"])

add(253,
    "A 17-year-old man presented with fever and productive cough for one month and, after "
    "investigation, was diagnosed with smear-positive pulmonary tuberculosis and started on the "
    "standard four-drug regimen. On the twelfth day of treatment he develops thrombocytopenia with "
    "a platelet count of 23000, raising the possibility of an adverse effect of the anti-tuberculous "
    "drugs. Which drug is most likely responsible?",
    ["Isoniazid",
     "Rifampicin",
     "Pyrazinamide",
     "Ethambutol"])

add(260,
    "What is the best method of preventing tuberculosis in the community?",
    ["BCG vaccination of the entire population",
     "Treating people with latent tuberculosis",
     "Diagnosing, treating and isolating cases of active tuberculosis",
     "Personal and public hygiene"])

# ------------------------------------------------ Clostridioides difficile
add(309,
    "Which of the following is correct regarding Clostridioides difficile infection?",
    ["The diagnosis is based on the combination of clinical features and laboratory tests",
     "The presence of toxin in the stool after treatment indicates probable relapse",
     "Testing for toxin after recovery is necessary to confirm cure",
     "Testing and treating asymptomatic people for the toxin is recommended"])

add(320,
    "A 65-year-old man was admitted with a lung abscess and has been treated with intravenous "
    "clindamycin for 7 days. Since yesterday he has developed severe diarrhoea with frequent "
    "large-volume watery stools and a leucocytosis of 25000. Because of severe dehydration he has "
    "required 5 to 6 litres of isotonic fluid over the past 24 hours. Given the most likely "
    "diagnosis, what is the appropriate management?",
    ["Replace clindamycin with ampicillin and start oral vancomycin",
     "Replace clindamycin with ceftriaxone and start intravenous metronidazole",
     "Continue clindamycin, send stool for examination and start intravenous ciprofloxacin",
     "Continue clindamycin and start oral azithromycin"])

# ------------------------------------------------ cholera
add(336,
    "In a patient with non-inflammatory diarrhoea in whom cholera is suspected, which clinical "
    "finding would NOT be expected?",
    ["Dehydration",
     "Muscle cramps",
     "Fever",
     "Vomiting"])

# ------------------------------------------------ tetanus in pregnancy
add(361,
    "A 20-year-old pregnant woman with no history of vaccination presents. What do you recommend to "
    "prevent neonatal tetanus?",
    ["Two doses of Td vaccine at a minimum interval of 4 weeks",
     "Two doses of DPT vaccine at a minimum interval of 2 weeks",
     "A single dose of Td vaccine",
     "A single dose of DPT vaccine"])

# ------------------------------------------------ rabies
add(402,
    "A 28-year-old woman attends the clinic after being bitten on the leg by a jackal. Which of the "
    "following is the EARLIEST neurological symptom suggestive of rabies?",
    ["Headache and vomiting",
     "Aerophobia and hydrophobia",
     "Delirium and drowsiness",
     "Paraesthesia and itching at the bite site"])

# ------------------------------------------------ typhoid diagnosis
add(429,
    "A 17-year-old boy presents with a stepwise fever for 3 weeks together with anorexia and "
    "abdominal pain. The pain is mostly in the right lower quadrant. On examination he is confused "
    "and obtunded. He has a history of drinking unsafe water in a rural area, and has already "
    "received antibiotics. Which investigation has the highest diagnostic yield?",
    ["Blood culture",
     "Serology",
     "Bone marrow culture",
     "Stool culture"])

# ------------------------------------------------ brucellosis
add(443,
    "Which of the following is NOT particularly helpful in distinguishing tuberculous spondylitis "
    "from brucellar spondylitis?",
    ["Anterolateral osteophytes",
     "Early destruction of the vertebral body",
     "The presence of a gibbus deformity",
     "The site of the involved vertebrae (lumbar plus thoracic)"])

add(456,
    "What is the most appropriate method of following up a patient after completing treatment for "
    "brucellosis?",
    ["Clinical follow-up of the patient for two years",
     "IgG serology follow-up for two years",
     "Clinical and IgG serological follow-up for one year",
     "Annual complement fixation titres for 10 years"])

add(458,
    "A 35-year-old woman presented with fever and joint pains for about 3 weeks. Brucellosis was "
    "confirmed by Wright and 2ME tests and she completed a full course of treatment. What is your "
    "advice for following her up?",
    ["Follow up with serological tests every 3 months for 2 years",
     "No follow-up is needed since the course of treatment is complete",
     "Follow up with Wright and 2ME tests every 3 months for 2 years",
     "Follow up for 2 years, with the patient's general condition and weight as the most important indicators"])

# ------------------------------------------------ leptospirosis
add(494,
    "In severe leptospirosis (Weil's disease), which of the following is NOT part of the triad of "
    "features?",
    ["Renal failure",
     "Jaundice",
     "Encephalitis",
     "Pulmonary haemorrhage"])

# ------------------------------------------------ urinary tract
add(505,
    "In which of the following should asymptomatic bacteriuria receive antibiotic treatment?",
    ["An elderly person",
     "A diabetic patient",
     "A patient with a kidney stone",
     "A pregnant woman"])

add(509,
    "A morning urine culture from a 52-year-old woman with no clinical symptoms has grown more than "
    "one hundred thousand colonies of Escherichia coli on two occasions. The presence of which of "
    "the following would be an indication to start antibiotic treatment?",
    ["Uncontrolled diabetes",
     "Undergoing a bladder biopsy",
     "Hepatic cirrhosis",
     "A kidney stone"])

# ------------------------------------------------ sexually transmitted infection
add(528,
    "Which of the following are causes of sexually transmitted microbial disease?",
    ["HIV types 1 and 2",
     "Giardia lamblia",
     "Sarcoptes scabiei",
     "All of the above"])

add(540,
    "A 27-year-old man presents with dysuria and urethral discharge. He does not wish to have any "
    "tests. What is the treatment of choice?",
    ["Ceftriaxone 250 mg IM plus azithromycin 1 g orally",
     "Ceftriaxone 2 g IM plus doxycycline 100 mg twice daily for one week",
     "Spectinomycin 2 g IM",
     "None of the above"])

add(541,
    "A 30-year-old man develops urethral burning and purulent discharge 2 to 3 days after sexual "
    "contact with an unknown partner. A slide prepared from the purulent discharge shows "
    "intracellular gram-negative diplococci. He is diagnosed with gonococcal infection and treated "
    "with a single intramuscular dose of ceftriaxone 250 mg. His symptoms improve, but after one "
    "week he again has mild burning and a mucoid discharge. What is the most likely explanation?",
    ["Gonococcal resistance to ceftriaxone",
     "A mucoid discharge usually persists for a while after treating gonorrhoea and resolves spontaneously",
     "Concurrent infection with Chlamydia trachomatis",
     "None of the above"])

# ------------------------------------------------ influenza vaccination
add(588,
    "In which of the following groups is influenza vaccination mandatory?",
    ["Children under 6 months of age",
     "Children from 6 months to 18 years of age",
     "Pregnant women whose first trimester falls in the influenza season",
     "Young people aged 15 to 45 years"])

# ------------------------------------------------ herpes zoster
add(618,
    "A 65-year-old woman presents with pain in the left ear. On examination several vesicles are "
    "seen in the external auditory canal. She has lost taste sensation over the anterior tongue and "
    "has a unilateral facial palsy. A smear from the vesicles reports multinucleated giant cells. "
    "What is the appropriate treatment?",
    ["Ribavirin",
     "Aciclovir",
     "Levofloxacin",
     "Co-amoxiclav"])

# ------------------------------------------------ HIV testing algorithm
add(674,
    "A young man with a history of high-risk behaviour presents with a positive ELISA test for HIV "
    "infection. What is the next step?",
    ["Repeat the ELISA test",
     "Confirm the diagnosis with a Western blot",
     "Confirm the diagnosis with an HIV RNA PCR",
     "Request a CD4 count"])

add(684,
    "An HIV antibody test by ELISA is reported positive on the first occasion and negative on the "
    "second. What is your next step?",
    ["Western blot",
     "Repeat the ELISA three to six months later",
     "P24 antigen",
     "Repeat the ELISA four to six weeks later"])

# ------------------------------------------------ candidiasis
add(710,
    "A 30-year-old woman presents complaining of vaginal discharge. On examination the discharge is "
    "white, thick, adherent, curd-like and clumped. Which of the following does NOT predispose to "
    "this clinical syndrome?",
    ["HIV infection",
     "Pregnancy",
     "Diabetes mellitus",
     "Alcohol consumption"])

# ------------------------------------------------ severe malaria
add(762,
    "All of the following are diagnostic criteria for severe falciparum malaria, EXCEPT",
    ["Anuria",
     "A haemoglobin of 9 grams per decilitre",
     "A blood glucose of 30 milligrams per decilitre",
     "Jaundice"])

add(767,
    "Which of the following is NOT a manifestation of severe falciparum malaria?",
    ["Hypoglycaemia",
     "Cardiogenic pulmonary oedema",
     "Lactic acidosis",
     "Disseminated intravascular coagulation (DIC)"])
