# -*- coding: utf-8 -*-
"""Infectious-diseases micro-lessons, batch 3 — Khordad-1402 (items 122-130).

English stems/options are NOT written here: they came verbatim from the
ministry's official English booklet and must not be overwritten.
Reference: Harrison's Principles of Internal Medicine, 21st ed.
"""
import json, io, os
L = {}

L["1402-03:122"] = {
 "style": "recall", "difficulty": "medium",
 "micro": {
  "lead_fa": "لپتوسپیروز: بیشتر موارد بدون علامت؛ ولی وقتی علامت‌دار شود، میالژی شدید ساق پا و سردرد پیشانی و تزریق ملتحمه دارد.",
  "lead_en": "Leptospirosis: most infections are subclinical, but when symptomatic it brings severe calf myalgia, frontal headache and conjunctival suffusion.",
  "points_fa": [
   "لپتوسپیروز یک زئونوز اسپیروکتی است که از ادرار حیوانات آلوده، به‌ویژه موش، به انسان می‌رسد.",
   "راه ورود، پوست خراشیده یا مخاط در تماس با آب یا خاک آلوده است؛ برنج‌کاران و شالی‌کاران گروه پرخطرند.",
   "در ایران بیشترین موارد از استان‌های شمالی، گیلان و مازندران، در فصل کشت برنج گزارش می‌شود.",
   "حدود نود درصد عفونت‌ها خفیف یا کاملاً بدون علامت‌اند؛ پس «اکثر بیماران علامت‌دار هستند» غلط است.",
   "بیماری دوفازی است: فاز اول سپتیسمیک با تب و میالژی، سپس فاز دوم ایمنی با مننژیت آسپتیک.",
   "میالژی در لپتوسپیروز از شدیدترین دردهای عضلانی طب عفونی است، نه خفیف.",
   "درد به‌طور مشخص در عضلات ساق پا و ناحیه‌ی کمر متمرکز می‌شود؛ لمس ساق دردناک است.",
   "سردرد کلاسیک، شدید و ضربان‌دار و در ناحیه‌ی پیشانی (فرونتال) است، نه تمپورال.",
   "تزریق ملتحمه یا conjunctival suffusion یعنی قرمزی چشم بدون ترشح چرکی و یافته‌ای بسیار کمک‌کننده است.",
   "شکل شدید بیماری، سندرم وایل است: زردی، نارسایی کلیه و خون‌ریزی، با مرگ‌ومیر بالا.",
   "درمان خفیف با داکسی‌سایکلین خوراکی و شدید با پنی‌سیلین یا سفتریاکسون وریدی است."
  ],
  "points_en": [
   "Leptospirosis is a spirochaetal zoonosis reaching humans from the urine of infected animals, especially rodents.",
   "Entry is through abraded skin or mucosa in contact with contaminated water or soil; rice farmers are a high-risk group.",
   "In Iran most cases are reported from the northern provinces, Gilan and Mazandaran, during the rice-planting season.",
   "About ninety per cent of infections are mild or entirely subclinical, so 'most patients are symptomatic' is false.",
   "The illness is biphasic: a septicaemic phase with fever and myalgia, then an immune phase with aseptic meningitis.",
   "Myalgia in leptospirosis is among the most severe muscle pain in infectious medicine, not mild.",
   "The pain is characteristically concentrated in the calf muscles and the lumbar region; the calves are tender to touch.",
   "The classic headache is severe and throbbing and frontal in location, not temporal.",
   "Conjunctival suffusion means red eyes without purulent discharge and is a very helpful clue.",
   "The severe form is Weil's syndrome: jaundice, renal failure and bleeding, with high mortality.",
   "Mild disease is treated with oral doxycycline and severe disease with intravenous penicillin or ceftriaxone."
  ]
 },
 "explanation_fa": "لپتوسپیروز چهار ادعای این سؤال را یکی‌یکی رد می‌کند تا فقط گزینه‌ی آخر بماند. اول: تخمین زده می‌شود حدود نود درصد عفونت‌ها خفیف یا کاملاً بدون علامت‌اند، پس «اکثر بیماران علامت‌دار» غلط است. دوم: میالژی در لپتوسپیروز نه‌تنها خفیف نیست، بلکه یکی از شدیدترین دردهای عضلانی در طب عفونی است — آن‌قدر که بیمار از لمس ساق پا هم می‌نالد. سوم: سردرد کلاسیک آن فرونتال و شدید و ضربان‌دار است، نه تمپورال. و چهارم که پاسخ است: درد به‌طور مشخص در عضلات ساق پا و کمر متمرکز می‌شود؛ ترکیب تب و میالژی شدید ساق و تزریق ملتحمه تابلوی امضایی لپتوسپیروز است. منطق پاتوفیزیولوژیک هم همین را می‌گوید: اسپیروکت باعث واسکولیت عضلانی می‌شود و گروه‌های عضلانی بزرگ و پرخون بیشترین آسیب را می‌بینند.",
 "explanation_en": "Leptospirosis knocks down three of these statements one by one and leaves only the last. First, roughly ninety per cent of infections are mild or wholly subclinical, so 'most patients are symptomatic' is wrong. Second, the myalgia is not mild at all; it is among the most severe muscle pain in infectious medicine, so severe that the patient winces when you touch the calf. Third, the classic headache is frontal, intense and throbbing, not temporal. And fourth, which is the answer, the pain concentrates in the calves and the lower back; fever plus severe calf myalgia plus conjunctival suffusion is the signature picture. The pathophysiology agrees: the spirochaete causes a muscular vasculitis, and the large, well-perfused muscle groups take the worst of it.",
 "why_fa": [
  "نادرست است. اکثریت بزرگی از عفونت‌های لپتوسپیرا خفیف یا بدون علامت باقی می‌مانند و هرگز تشخیص داده نمی‌شوند.",
  "برعکس است. میالژی در این بیماری شاخص و بسیار شدید است و یکی از دلایل اصلی مراجعه‌ی بیمار محسوب می‌شود.",
  "سردرد لپتوسپیروز شدید و در ناحیه‌ی پیشانی است. محل تمپورال بیشتر یادآور آرتریت تمپورال یا سردرد تنشی است.",
  "پاسخ صحیح — درد عضلانی به‌طور مشخص در ساق پا و کمر بیشتر است و لمس ساق دردناک می‌باشد."
 ],
 "why_en": [
  "False. The large majority of leptospiral infections stay mild or subclinical and are never diagnosed.",
  "The opposite is true. Myalgia here is prominent and very severe and is one of the main reasons the patient presents.",
  "The headache of leptospirosis is severe and frontal. A temporal location suggests temporal arteritis or tension headache instead.",
  "Correct — the myalgia is characteristically worst in the calves and lower back, and the calves are tender to palpation."
 ],
 "golden_fa": "لپتوسپیروز = تب + میالژی شدید ساق پا + تزریق ملتحمه + سردرد پیشانی. اکثر موارد بدون علامت.",
 "golden_en": "Leptospirosis equals fever plus severe calf myalgia plus conjunctival suffusion plus frontal headache. Most cases are subclinical.",
 "refs": [
  "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 184: Leptospirosis"
 ]
}

L["1402-03:123"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "در پنومونی، سؤال اصلی «کجا بستری کنم» است. RR ≥ ۳۰ و دمای ≥ ۴۰ دو معیار مینور ICU هستند.",
  "lead_en": "In pneumonia the real question is where to admit. A respiratory rate of 30 or more and a temperature of 40 or more are two minor ICU criteria.",
  "points_fa": [
   "پنومونی اکتسابی از جامعه سه تصمیم دارد: محل درمان، رژیم آنتی‌بیوتیک و طول درمان.",
   "محل درمان مهم‌ترین تصمیم است، چون بستری نابه‌جا در بخش به‌جای ICU مرگ‌ومیر را بالا می‌برد.",
   "ابزار غربالگری اولیه CURB-65 یا PSI است، اما تصمیم ICU با معیارهای IDSA/ATS گرفته می‌شود.",
   "دو معیار ماژور ICU: نیاز به تهویه‌ی مکانیکی، یا شوک سپتیک نیازمند وازوپرسور.",
   "با وجود یک معیار ماژور، بستری در ICU الزامی است.",
   "معیارهای مینور شامل تعداد تنفس مساوی یا بیشتر از سی در دقیقه است.",
   "معیارهای مینور دیگر: نسبت PaO2/FiO2 کمتر از ۲۵۰، انفیلتراسیون چندلوبی و گیجی.",
   "همچنین اوره‌ی بالا، لکوپنی، ترومبوسیتوپنی، هیپوترمی و هیپوتانسیون نیازمند مایع‌درمانی تهاجمی.",
   "با سه معیار مینور یا بیشتر، بستری در ICU توصیه می‌شود؛ برخی منابع دو معیار را هم کافی می‌دانند.",
   "رژیم دارویی در بخش و ICU مشابه است: بتالاکتام به‌علاوه‌ی ماکرولید، یا فلوروکینولون تنفسی.",
   "تاکی‌پنه حساس‌ترین علامت زودرس نارسایی تنفسی است و اغلب پیش از افت اشباع اکسیژن ظاهر می‌شود."
  ],
  "points_en": [
   "Community-acquired pneumonia needs three decisions: where to treat, which antibiotic and for how long.",
   "The site decision matters most, because admitting to the ward instead of the ICU raises mortality.",
   "CURB-65 or PSI is the initial screening tool, but the ICU decision uses the IDSA/ATS criteria.",
   "The two major ICU criteria are the need for mechanical ventilation, or septic shock requiring vasopressors.",
   "One major criterion alone mandates ICU admission.",
   "The minor criteria include a respiratory rate of thirty or more per minute.",
   "Other minor criteria are a PaO2/FiO2 ratio below 250, multilobar infiltrates and confusion.",
   "Also raised urea, leukopenia, thrombocytopenia, hypothermia and hypotension needing aggressive fluids.",
   "Three or more minor criteria warrant ICU care; some sources accept two.",
   "The drug regimen is the same on the ward and in the ICU: a beta-lactam plus a macrolide, or a respiratory fluoroquinolone.",
   "Tachypnoea is the most sensitive early sign of respiratory failure and usually precedes any fall in oxygen saturation."
  ]
 },
 "explanation_fa": "این سؤال در واقع سؤالِ «کجا بستری کنم؟» است، نه «چه آنتی‌بیوتیکی بدهم؟». دو رقم را ببینید: دمای چهل درجه و مهم‌تر از آن تعداد تنفس چهل در دقیقه. در معیارهای شدت پنومونی، تعداد تنفس مساوی یا بیشتر از سی به‌تنهایی یکی از معیارهای مینور پذیرش در ICU است و چهل خیلی بالاتر از آن است؛ دمای مساوی یا بیشتر از چهل هم معیار دیگری است. با دو معیار مینور یا بیشتر، بیمار باید در ICU بستری شود. رژیم دارویی در هر دو حالت بستری یکسان است، پس گزینه‌ی دو و سه فقط در محل بستری فرق دارند و همین محل، پاسخ را تعیین می‌کند. نکته‌ی بالینی: تاکی‌پنه‌ی شدید حساس‌ترین علامت زودرس نارسایی تنفسی است و اغلب پیش از افت اشباع اکسیژن ظاهر می‌شود؛ درمان سرپایی اینجا خطرناک است.",
 "explanation_en": "This is really a question about where to admit, not which antibiotic to choose. Look at two numbers: a temperature of forty degrees and, more importantly, a respiratory rate of forty per minute. In the pneumonia severity criteria a respiratory rate of thirty or more is by itself a minor ICU criterion, and forty is well past it; a temperature of forty or above is another. With two or more minor criteria the patient belongs in the ICU. The antibiotic regimen is identical in both inpatient settings, so options two and three differ only in location, and that location is the answer. Clinically, severe tachypnoea is the most sensitive early sign of respiratory failure and usually appears before oxygen saturation drops; outpatient treatment here would be dangerous.",
 "why_fa": [
  "درمان سرپایی برای بیمار پایدار و کم‌خطر است. با تنفس چهل در دقیقه و تب چهل درجه، این بیمار در خطر نارسایی تنفسی قریب‌الوقوع است.",
  "رژیم دارویی درست است اما محل اشتباه. بیمار با دو معیار مینور شدت، نیاز به پایش پیوسته در ICU دارد نه بخش عادی.",
  "پاسخ صحیح — همان رژیم بتالاکتام به‌علاوه‌ی ماکرولید، اما در ICU که پایش تنفسی و امکان تهویه‌ی فوری وجود دارد.",
  "لووفلوکساسین به همراه سفتریاکسون ترکیبی غیرمعمول و دارای پوشش مضاعف است؛ ضمن اینکه باز هم محل بستری اشتباه انتخاب شده."
 ],
 "why_en": [
  "Outpatient care suits a stable, low-risk patient. With a respiratory rate of forty and a temperature of forty this patient is heading for respiratory failure.",
  "The regimen is right but the place is wrong. With two minor severity criteria this patient needs continuous ICU monitoring, not a general ward.",
  "Correct — the same beta-lactam plus macrolide regimen, but in the ICU where respiratory monitoring and immediate ventilation are available.",
  "Levofloxacin combined with ceftriaxone is an unusual, doubly redundant regimen, and the site of care is still wrong."
 ],
 "golden_fa": "معیار مینور ICU: RR ≥ ۳۰، T ≥ ۴۰، گیجی، چندلوبی، PaO2/FiO2 < ۲۵۰. دو تا یا بیشتر یعنی ICU.",
 "golden_en": "Minor ICU criteria: RR 30 or more, T 40 or more, confusion, multilobar infiltrate, PaO2/FiO2 under 250. Two or more means ICU.",
 "refs": [
  "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 126: Pneumonia"
 ]
}

L["1402-03:124"] = {
 "style": "case", "difficulty": "hard",
 "micro": {
  "lead_fa": "ضایعه‌ی پوستی «متحرک» + سرفه + ائوزینوفیلی نوسان‌دار = استرونژیلوئیدس. تشخیص با اسمیر مدفوع.",
  "lead_en": "A migrating skin lesion plus cough plus fluctuating eosinophilia means Strongyloides. Diagnosis is by stool smear.",
  "points_fa": [
   "استرونژیلوئیدس استرکورالیس تنها کرم روده‌ای است که چرخه‌ی خودآلودگی (autoinfection) دارد.",
   "به همین دلیل عفونت می‌تواند ده‌ها سال در یک میزبان باقی بماند، حتی بدون تماس مجدد.",
   "لارو فیلاریفرم از پوست برهنه وارد می‌شود، به ریه می‌رود و پس از بلع به روده می‌رسد.",
   "عبور لارو از ریه سرفه و خس‌خس و انفیلتراسیون گذرا می‌سازد که سندرم لوفلر نام دارد.",
   "ضایعه‌ی پوستی مشخص آن larva currens است: راش خطی خارش‌داری که ساعتی چند سانتی‌متر جابه‌جا می‌شود.",
   "این سرعت، larva currens را از larva migrans جلدی کرم قلابدار سگ که بسیار کندتر است جدا می‌کند.",
   "ائوزینوفیلی نوسان‌دار، بازتاب چرخه‌های متناوب خودآلودگی است و سرنخ آزمایشگاهی مهمی است.",
   "تشخیص با یافتن لارو رابدیتی‌فرم در اسمیر مستقیم مدفوع انجام می‌شود، نه تخم.",
   "حساسیت یک نمونه‌ی مدفوع کم است، حدود سی درصد؛ پس باید سه تا هفت نمونه فرستاد.",
   "سرولوژی ELISA حساس‌تر است و در موارد مشکوک با مدفوع منفی کمک می‌کند.",
   "خطر مرگبار آن سندرم هایپراینفکشن است که با کورتیکواستروئید یا HTLV-1 تحریک می‌شود.",
   "درمان انتخابی آیورمکتین است؛ آلبندازول جایگزین درجه‌دو محسوب می‌شود."
  ],
  "points_en": [
   "Strongyloides stercoralis is the only intestinal helminth with an autoinfection cycle.",
   "That is why the infection can persist for decades in one host, even without any further exposure.",
   "The filariform larva penetrates bare skin, travels to the lung and reaches the gut after being swallowed.",
   "Pulmonary transit causes cough, wheeze and transient infiltrates, known as Loeffler syndrome.",
   "Its characteristic skin lesion is larva currens: an itchy linear rash that moves several centimetres per hour.",
   "That speed separates larva currens from the much slower cutaneous larva migrans of dog hookworm.",
   "Fluctuating eosinophilia mirrors the intermittent autoinfection cycles and is an important laboratory clue.",
   "Diagnosis rests on finding rhabditiform larvae on direct stool smear, not eggs.",
   "A single stool sample has low sensitivity, around thirty per cent, so three to seven samples should be sent.",
   "ELISA serology is more sensitive and helps in suspected cases with negative stool studies.",
   "Its lethal complication is hyperinfection syndrome, triggered by corticosteroids or HTLV-1 co-infection.",
   "Ivermectin is the drug of choice; albendazole is a second-line alternative."
  ]
 },
 "explanation_fa": "سه سرنخ را کنار هم بگذارید: ضایعه‌ی پوستی خارش‌دار که حرکت می‌کند، سرفه‌ای که چند روز بعد از آن پیدا می‌شود، و ائوزینوفیلی که بالا و پایین می‌رود. این دقیقاً چرخه‌ی استرونژیلوئیدس استرکورالیس است. ضایعه‌ی متحرک همان larva currens است — لارو زیر پوست با سرعت چند سانتی‌متر در ساعت جابه‌جا می‌شود، که آن را از larva migrans کندِ کرم قلابدار سگ متمایز می‌کند. سرفه هم از عبور لارو از ریه می‌آید. تشخیص یک انگل روده‌ای با یافتن خودِ لارو در مدفوع انجام می‌شود، یعنی اسمیر مستقیم مدفوع. کشت مدفوع برای باکتری است نه انگل؛ بیوپسی پوست ممکن است لارو را نشان دهد ولی تهاجمی و کم‌بازده است؛ و آسپیراسیون مغز استخوان جایی در تشخیص انگل روده‌ای ندارد. نکته‌ی حیاتی: حساسیت یک نمونه‌ی مدفوع پایین است، پس عملاً باید چند نمونه فرستاد.",
 "explanation_en": "Put three clues together: an itchy skin lesion that moves, a cough appearing a few days later, and an eosinophil count that rises and falls. That is exactly the Strongyloides stercoralis cycle. The moving lesion is larva currens; the larva travels under the skin at several centimetres an hour, which distinguishes it from the far slower cutaneous larva migrans of dog hookworm. The cough comes from larval transit through the lung. A gut helminth is diagnosed by finding the organism itself in stool, which means a direct stool smear. Stool culture targets bacteria, not parasites; skin biopsy may show the larva but is invasive and low-yield; and bone marrow aspiration has no role in diagnosing an intestinal worm. One caveat: a single stool sample has poor sensitivity, so several must be sent in practice.",
 "why_fa": [
  "آسپیراسیون مغز استخوان برای بدخیمی‌های خونی و سیتوپنی‌های نامشخص است، نه برای یافتن یک انگل روده‌ای.",
  "کشت مدفوع باکتری‌های بیماری‌زا مثل سالمونلا و شیگلا را جدا می‌کند. انگل‌ها با کشت روتین مدفوع رشد نمی‌کنند.",
  "بیوپسی پوست ممکن است در برخی موارد لارو را نشان دهد، اما تهاجمی، پرهزینه و بسیار کم‌بازده‌تر از مدفوع است.",
  "پاسخ صحیح — اسمیر مستقیم مدفوع لارو رابدیتی‌فرم را نشان می‌دهد و روش استاندارد اولیه است."
 ],
 "why_en": [
  "Bone marrow aspiration is for haematological malignancy and unexplained cytopenias, not for finding a gut parasite.",
  "Stool culture isolates bacterial pathogens such as Salmonella and Shigella. Parasites do not grow on routine stool culture.",
  "Skin biopsy may occasionally show the larva, but it is invasive, costly and far lower-yield than stool examination.",
  "Correct — direct stool smear reveals rhabditiform larvae and is the standard first-line test."
 ],
 "golden_fa": "larva currens (سریع) = استرونژیلوئیدس؛ larva migrans (کند) = کرم قلابدار سگ. تشخیص: اسمیر مدفوع، چند نمونه.",
 "golden_en": "Larva currens (fast) means Strongyloides; larva migrans (slow) means dog hookworm. Diagnose with stool smear, several samples.",
 "refs": [
  "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 223: Intestinal Nematodes"
 ]
}

L["1402-03:125"] = {
 "style": "recall", "difficulty": "medium",
 "micro": {
  "lead_fa": "شیگلا معمولاً در مخاط می‌ماند. در سوءتغذیه و HIV از مخاط عبور می‌کند و باکتریمی می‌دهد.",
  "lead_en": "Shigella normally stays in the mucosa. In malnutrition and HIV it breaches the mucosa and causes bacteraemia.",
  "points_fa": [
   "شیگلا با دوز عفونی بسیار پایین، حدود ده تا صد باکتری، منتقل می‌شود و انتقال انسان به انسان دارد.",
   "باکتری به سلول‌های اپیتلیال کولون حمله می‌کند و در همان لایه‌ی مخاطی تکثیر می‌یابد.",
   "به همین دلیل تابلوی بالینی، دیسانتری است: اسهال کم‌حجم و مکرر با خون و موکوس و تنسموس.",
   "چون عفونت مخاطی و سطحی است، ورود به جریان خون در میزبان سالم نادر است.",
   "در سوءتغذیه‌ی شدید و در HIV پیشرفته، سد مخاطی و ایمنی سلولی تضعیف می‌شود.",
   "در این دو گروه باکتری از مخاط عبور می‌کند و باکتریمی رخ می‌دهد، با مرگ‌ومیر بسیار بالاتر.",
   "مگاکولون توکسیک و پرفوریشن روده هم عوارض واقعی‌اند، به‌ویژه با شیگلا دیسانتری تیپ یک.",
   "هیپوگلیسمی و هیپوناترمی از عوارض متابولیک شایع در کودکان کم‌سن است.",
   "سندرم اورمیک همولیتیک با توکسین شیگا در شیگلا دیسانتری تیپ یک دیده می‌شود.",
   "در بیمار HIV مثبت با اسهال خونی، کشت خون هم باید فرستاده شود نه فقط کشت مدفوع.",
   "درمان با سیپروفلوکساسین یا سفتریاکسون است؛ داروهای ضداسهال ممنوع‌اند."
  ],
  "points_en": [
   "Shigella spreads person to person with a very low infectious dose, around ten to a hundred organisms.",
   "The bacterium invades colonic epithelial cells and multiplies within the mucosal layer itself.",
   "Hence the clinical picture is dysentery: small-volume frequent stools with blood, mucus and tenesmus.",
   "Because the infection is mucosal and superficial, entry into the bloodstream is rare in a healthy host.",
   "In severe malnutrition and advanced HIV both the mucosal barrier and cellular immunity are weakened.",
   "In those two groups the organism crosses the mucosa and bacteraemia occurs, with much higher mortality.",
   "Toxic megacolon and intestinal perforation are genuine complications too, especially with S. dysenteriae type 1.",
   "Hypoglycaemia and hyponatraemia are common metabolic complications in young children.",
   "Haemolytic uraemic syndrome from Shiga toxin is seen with S. dysenteriae type 1.",
   "In an HIV-positive patient with bloody diarrhoea, send blood cultures as well as stool cultures.",
   "Treatment is ciprofloxacin or ceftriaxone; antimotility agents are contraindicated."
  ]
 },
 "explanation_fa": "شیگلا معمولاً یک عفونت مخاطی است: باکتری در اپیتلیوم کولون می‌ماند و به‌ندرت وارد خون می‌شود، به همین دلیل باکتریمی در میزبان سالم نادر است. اما وقتی سیستم ایمنی سلولی یا سد مخاطی ضعیف شود — یعنی همان دو گروهی که سؤال نام برده: سوءتغذیه‌ی شدید و HIV پیشرفته — باکتری از مخاط عبور می‌کند و باکتریمی رخ می‌دهد؛ همراه با افزایش چشمگیر مرگ‌ومیر. بقیه‌ی گزینه‌ها هم عوارض واقعی شیگلوز هستند، ولی هیچ‌کدام آن اختصاصیتِ ارتباط با نقص ایمنی را ندارند که این سؤال دنبالش است. درس بالینی: در بیمار HIV مثبت با اسهال خونی، کشت خون هم بفرستید، نه فقط کشت مدفوع.",
 "explanation_en": "Shigella is normally a mucosal infection: the organism stays in the colonic epithelium and rarely enters the blood, which is why bacteraemia is uncommon in a healthy host. But when cellular immunity or the mucosal barrier is impaired, precisely the two groups the question names, severe malnutrition and advanced HIV, the organism crosses the mucosa and bacteraemia follows, with a striking rise in mortality. The other options are all real complications of shigellosis, but none carries the specific link to immunodeficiency that this question is testing. The clinical lesson: in an HIV-positive patient with bloody diarrhoea, send blood cultures, not just stool cultures.",
 "why_fa": [
  "مگاکولون توکسیک عارضه‌ی واقعی شیگلوز شدید است، اما ارتباط اختصاصی با سوءتغذیه یا HIV ندارد.",
  "پاسخ صحیح — نقص ایمنی سلولی و ضعف سد مخاطی باعث عبور باکتری از مخاط و باکتریمی می‌شود.",
  "پرفوریشن روده به‌ویژه با شیگلا دیسانتری تیپ یک رخ می‌دهد، ولی به وضعیت ایمنی میزبان گره نخورده است.",
  "اختلالات متابولیک مانند هیپوگلیسمی بیشتر در کودکان کم‌سن دیده می‌شود، نه به‌طور اختصاصی در HIV."
 ],
 "why_en": [
  "Toxic megacolon is a genuine complication of severe shigellosis, but it is not specifically linked to malnutrition or HIV.",
  "Correct — impaired cellular immunity and a weakened mucosal barrier let the organism cross into the bloodstream.",
  "Intestinal perforation occurs particularly with S. dysenteriae type 1, but it is not tied to the host's immune status.",
  "Metabolic disturbances such as hypoglycaemia are seen mainly in young children, not specifically in HIV."
 ],
 "golden_fa": "شیگلا = عفونت مخاطی. باکتریمی فقط وقتی ایمنی افت کند: سوءتغذیه یا HIV.",
 "golden_en": "Shigella is a mucosal infection. Bacteraemia happens only when immunity falls: malnutrition or HIV.",
 "refs": [
  "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 160/166: Shigellosis"
 ]
}

L["1402-03:126"] = {
 "style": "case", "difficulty": "hard",
 "micro": {
  "lead_fa": "طول درمان آبسه‌ی ریه را رادیولوژی تعیین می‌کند، نه علائم بالینی و نه تقویم.",
  "lead_en": "The duration of lung abscess therapy is set by radiology, not by symptoms and not by the calendar.",
  "points_fa": [
   "آبسه‌ی ریه اغلب پیامد آسپیراسیون است؛ سکته، تشنج، الکل و کاهش هوشیاری عوامل خطر اصلی‌اند.",
   "خلط بدبو یا putrid امضای بی‌هوازی‌هاست و تقریباً تشخیص را قطعی می‌کند.",
   "محل آبسه به وضعیت بیمار هنگام آسپیراسیون بستگی دارد؛ در حالت خوابیده سگمان خلفی لوب فوقانی راست.",
   "عوامل شایع، بی‌هوازی‌های دهانی مثل پپتواسترپتوکوک، پرووتلا و فوزوباکتریوم هستند.",
   "درمان انتخابی آمپی‌سیلین-سولباکتام یا کلیندامایسین است و با کوآموکسی‌کلاو خوراکی ادامه می‌یابد.",
   "علائم بالینی معمولاً ظرف یک تا دو هفته فروکش می‌کنند، اما این پایان درمان نیست.",
   "حفره‌ی آبسه هفته‌ها تا ماه‌ها طول می‌کشد تا جمع شود، چون بافت نکروزه باید بازجذب شود.",
   "قطع آنتی‌بیوتیک با بهبود علائم، شایع‌ترین علت عود آبسه‌ی ریه است.",
   "پس معیار قطع درمان، بهبود رادیولوژیک است: زخم باقی‌مانده‌ی کوچک و پایدار یا گرافی طبیعی.",
   "طول درمان معمول سه هفته تا چند ماه است و برای هر بیمار متفاوت.",
   "ESR و CRP نشانگرهای غیراختصاصی‌اند و هرگز معیار مستقل قطع درمان نیستند.",
   "اگر با درمان مناسب بهبود نیافت، به بدخیمی زمینه‌ای یا جسم خارجی یا سل فکر کنید."
  ],
  "points_en": [
   "Lung abscess usually follows aspiration; stroke, seizures, alcohol and reduced consciousness are the main risks.",
   "Putrid or foul-smelling sputum is the signature of anaerobes and nearly clinches the diagnosis.",
   "The location depends on the patient's posture during aspiration; when supine, the posterior segment of the right upper lobe.",
   "The usual organisms are oral anaerobes such as Peptostreptococcus, Prevotella and Fusobacterium.",
   "First-line therapy is ampicillin-sulbactam or clindamycin, continued with oral co-amoxiclav.",
   "Symptoms usually settle within one to two weeks, but that is not the end of treatment.",
   "The cavity takes weeks to months to close, because the necrotic tissue must be reabsorbed.",
   "Stopping antibiotics when symptoms improve is the commonest cause of relapse.",
   "So the stopping rule is radiological improvement: a small stable residual scar or a clear film.",
   "Typical total duration runs from three weeks to several months and differs for each patient.",
   "ESR and CRP are non-specific markers and are never an independent criterion for stopping.",
   "If it fails to improve on adequate therapy, think of underlying malignancy, a foreign body or tuberculosis."
  ]
 },
 "explanation_fa": "آبسه‌ی ریه — اینجا آسپیراسیون پس از سکته، با خلط بدبو که امضای بی‌هوازی‌هاست — یکی از معدود عفونت‌هایی است که طول درمانش را نه تقویم و نه علائم بالینی، بلکه تصویر تعیین می‌کند. علائم بالینی معمولاً ظرف یک تا دو هفته می‌خوابند، اما حفره‌ی آبسه ماه‌ها طول می‌کشد تا جمع شود؛ اگر آنتی‌بیوتیک را با بهبود علائم قطع کنید، عود شایع است. پس قاعده این است: درمان تا زمانی ادامه یابد که گرافی یا سی‌تی به یک زخم باقی‌مانده‌ی کوچک و پایدار یا نمای طبیعی برسد — که در عمل اغلب بین سه هفته تا چند ماه طول می‌کشد. به همین دلیل «تا چهار هفته»ی ثابت هم پاسخ نیست: برای بعضی بیماران کوتاه و برای بعضی بلند است. ESR و CRP هم نشانگرهای غیراختصاصی‌اند و معیار قطع درمان نیستند.",
 "explanation_en": "Lung abscess, here from aspiration after a stroke with the foul sputum that signals anaerobes, is one of the few infections whose duration is dictated by imaging rather than by the calendar or by symptoms. Symptoms usually settle within one to two weeks, but the cavity takes months to close, and stopping antibiotics when the patient feels better is a common cause of relapse. The rule is therefore to continue until the chest film or CT shows either a small stable residual scar or a normal appearance, which in practice runs from three weeks to several months. That is also why a fixed four weeks is not the answer: too short for some patients and too long for others. ESR and CRP are non-specific and are not a stopping criterion.",
 "why_fa": [
  "یک بازه‌ی ثابت چهارهفته‌ای برای بعضی بیماران کوتاه و برای بعضی طولانی است؛ آبسه‌ی ریه پاسخ فردی دارد.",
  "پاسخ صحیح — درمان تا بهبود یافته‌های رادیولوژیک ادامه می‌یابد، یعنی حفره جمع شود یا زخم باقی‌مانده پایدار گردد.",
  "ESR و CRP نشانگرهای التهابی غیراختصاصی‌اند و می‌توانند در بسیاری از شرایط دیگر هم بالا بمانند.",
  "بهبود علائم بالینی زودتر از بسته شدن حفره اتفاق می‌افتد و قطع درمان در این نقطه شایع‌ترین علت عود است."
 ],
 "why_en": [
  "A fixed four weeks is too short for some patients and too long for others; lung abscess responds individually.",
  "Correct — treat until the radiological findings resolve, meaning the cavity closes or the residual scar stabilises.",
  "ESR and CRP are non-specific inflammatory markers and can stay elevated in many other conditions.",
  "Symptoms improve well before the cavity closes, and stopping at that point is the commonest cause of relapse."
 ],
 "golden_fa": "آبسه‌ی ریه: درمان تا بهبود رادیولوژیک، نه تا بهبود علائم. خلط بدبو = بی‌هوازی.",
 "golden_en": "Lung abscess: treat to radiological resolution, not to symptom resolution. Foul sputum means anaerobes.",
 "refs": [
  "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 127: Lung Abscess"
 ]
}

L["1402-03:127"] = {
 "style": "case", "difficulty": "hard",
 "micro": {
  "lead_fa": "سل میلیاری: بار باسیل ریوی کم است، پس اسمیر خلط و PPD ناامیدکننده‌اند. بیوپسی مغز استخوان بازده بالا دارد.",
  "lead_en": "Miliary TB has a low pulmonary bacillary load, so sputum smear and PPD disappoint. Bone marrow biopsy has high yield.",
  "points_fa": [
   "سل میلیاری یعنی انتشار خونی باسیل سل و درگیری همزمان چند اندام.",
   "نام میلیاری از نمای گرافی می‌آید: ندول‌های ریز و منتشر به اندازه‌ی دانه‌ی ارزن در هر دو ریه.",
   "تابلوی بالینی مبهم است: تب طولانی، تعریق شبانه، کاهش وزن و ضعف پیشرونده.",
   "درگیری چنداُرگانی شامل هپاتواسپلنومگالی، لنفادنوپاتی و افزایش آنزیم‌های کبدی است.",
   "سیتوپنی‌ها به‌ویژه لنفوپنی و پان‌سیتوپنی شایع‌اند و نشانه‌ی درگیری مغز استخوان‌اند.",
   "چون بار باسیل در ریه کم است، اسمیر خلط در اکثر موارد منفی می‌شود.",
   "کشت خلط حساس‌تر است ولی شش تا هشت هفته طول می‌کشد که در بیماری منتشر خیلی دیر است.",
   "PPD در سل منتشر و در حضور لنفوپنی اغلب منفی کاذب می‌شود، پدیده‌ای به نام آنرژی.",
   "PPD در هیچ حالتی تشخیص قطعی نمی‌دهد؛ فقط تماس قبلی با باسیل را نشان می‌دهد.",
   "مغز استخوان در سل میلیاری تقریباً همیشه درگیر است و بیوپسی آن بازده بالایی دارد.",
   "بیوپسی گرانولوم کازئیفیه و باسیل اسیدفاست را نشان می‌دهد و پاسخ نسبتاً سریعی می‌گیریم.",
   "وجود سیتوپنی خودش اندیکاسیون مستقل بیوپسی مغز استخوان است.",
   "بیوپسی کبد هم گزینه‌ی جایگزین است، به‌ویژه وقتی آنزیم‌های کبدی بالا باشد."
  ],
  "points_en": [
   "Miliary TB means haematogenous dissemination of the bacillus with simultaneous multi-organ involvement.",
   "The name comes from the film: tiny diffuse millet-seed nodules throughout both lungs.",
   "The clinical picture is vague: prolonged fever, night sweats, weight loss and progressive weakness.",
   "Multi-organ involvement includes hepatosplenomegaly, lymphadenopathy and raised liver enzymes.",
   "Cytopenias, especially lymphopenia and pancytopenia, are common and indicate marrow involvement.",
   "Because the pulmonary bacillary load is low, sputum smear is negative in most cases.",
   "Sputum culture is more sensitive but takes six to eight weeks, far too slow for disseminated disease.",
   "PPD is often falsely negative in disseminated TB and with lymphopenia, a phenomenon called anergy.",
   "PPD never establishes a definitive diagnosis in any case; it only shows previous exposure.",
   "The bone marrow is almost always involved in miliary TB and biopsy has a high yield.",
   "Biopsy shows caseating granulomas and acid-fast bacilli, giving a relatively fast answer.",
   "The presence of cytopenias is itself an independent indication for marrow biopsy.",
   "Liver biopsy is an alternative, particularly when the liver enzymes are raised."
  ]
 },
 "explanation_fa": "تابلو، سل میلیاری است: تب و تعریق شبانه و کاهش وزن دو ماهه، به‌علاوه‌ی درگیری چنداُرگانی — کبد و طحال بزرگ، لنفادنوپاتی، آنزیم‌های کبدی بالا و نمای میلیاری در گرافی. کلید سؤال این است که در سل میلیاری بار باسیل در ریه کم است، پس تست‌های تنفسی ناامیدکننده‌اند: اسمیر خلط در اکثر موارد منفی است و کشت خلط هم شش تا هشت هفته طول می‌کشد که برای بیماری‌ای با این شدت خیلی دیر است. PPD هم در سل منتشر و در حضور لنفوپنی اغلب منفی کاذب می‌شود و در هر حال هرگز تشخیص قطعی نمی‌دهد. در مقابل، مغز استخوان در سل میلیاری تقریباً همیشه درگیر است و بیوپسی آن گرانولوم کازئیفیه و باسیل اسیدفاست را با بازده بالا و سریع نشان می‌دهد؛ مخصوصاً وقتی سیتوپنی هم وجود دارد که خودش اندیکاسیون مستقل بیوپسی است.",
 "explanation_en": "The picture is miliary tuberculosis: two months of fever, night sweats and weight loss plus multi-organ involvement, with hepatosplenomegaly, lymphadenopathy, raised liver enzymes and a miliary pattern on the chest film. The key point is that in miliary TB the pulmonary bacillary load is low, so respiratory tests disappoint: sputum smear is negative in most cases and sputum culture takes six to eight weeks, far too slow for a disease this severe. PPD is often falsely negative in disseminated disease and in the presence of lymphopenia, and it never gives a definitive diagnosis anyway. By contrast the bone marrow is almost always involved and biopsy shows caseating granulomas and acid-fast bacilli quickly and with high yield, especially when cytopenias are present, which is itself an independent indication for marrow biopsy.",
 "why_fa": [
  "پاسخ صحیح — مغز استخوان در سل میلیاری تقریباً همیشه درگیر است و بیوپسی، تشخیص بافتی سریع و پربازده می‌دهد.",
  "PPD در سل منتشر و با لنفوپنی اغلب منفی کاذب می‌شود و در هیچ شرایطی تشخیص قطعی نمی‌دهد.",
  "اسمیر خلط در سل میلیاری در اکثر موارد منفی است، چون بار باسیل در راه هوایی پایین است.",
  "کشت خلط حساس‌تر از اسمیر است اما شش تا هشت هفته طول می‌کشد که برای این بیمار بسیار دیر است."
 ],
 "why_en": [
  "Correct — the marrow is almost always involved in miliary TB and biopsy gives a fast, high-yield tissue diagnosis.",
  "PPD is often falsely negative in disseminated disease with lymphopenia and never gives a definitive diagnosis.",
  "Sputum smear is negative in most miliary TB cases because the airway bacillary load is low.",
  "Sputum culture is more sensitive than smear but takes six to eight weeks, far too slow for this patient."
 ],
 "golden_fa": "سل میلیاری = تب طولانی + هپاتواسپلنومگالی + سیتوپنی + نمای میلیاری. تشخیص: بیوپسی مغز استخوان.",
 "golden_en": "Miliary TB equals prolonged fever plus hepatosplenomegaly plus cytopenias plus a miliary film. Diagnose with marrow biopsy.",
 "refs": [
  "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 178: Tuberculosis, miliary disease",
  "الگوریتم‌های تشخیص سل ریوی — مصوبه ۱۴۰۳ کمیته کشوری سل، وزارت بهداشت"
 ]
}

L["1402-03:128"] = {
 "style": "recall", "difficulty": "medium",
 "micro": {
  "lead_fa": "مرز مننژیت و انسفالیت یک چیز است: درگیری پارانشیم مغز. تشنج، اختلال هوشیاری و علائم کانونی = انسفالیت.",
  "lead_en": "One thing separates meningitis from encephalitis: involvement of the brain parenchyma. Seizures, altered consciousness and focal signs mean encephalitis.",
  "points_fa": [
   "مننژیت یعنی التهاب پرده‌های مغز؛ انسفالیت یعنی التهاب خودِ بافت مغز.",
   "علائم تحریک مننژ شامل سردرد، سفتی گردن، فوتوفوبی و درد حین حرکت چشم است.",
   "این علائم هرچقدر هم شدید باشند، فقط درگیری مننژ را نشان می‌دهند و تشخیص را عوض نمی‌کنند.",
   "علائم درگیری پارانشیم متفاوت‌اند: تشنج، اختلال هوشیاری، تغییر شخصیت و رفتار.",
   "همچنین علائم نورولوژیک کانونی مثل همی‌پارزی، آفازی و اختلال حرکات چشمی.",
   "پیش‌آگهی این دو کاملاً متفاوت است و همین، تمایز را حیاتی می‌کند.",
   "مننژیت ویروسی معمولاً خودمحدودشونده است و با درمان حمایتی بهبود می‌یابد.",
   "انسفالیت ویروسی می‌تواند کشنده یا ناتوان‌کننده باشد و نیاز به درمان فوری دارد.",
   "شایع‌ترین علت قابل‌درمان انسفالیت اسپورادیک در بالغین، ویروس هرپس سیمپلکس تیپ یک است.",
   "HSV به‌طور مشخص لوب تمپورال را درگیر می‌کند؛ MRI و EEG همین را نشان می‌دهند.",
   "درمان آسیکلوویر وریدی است و باید فوراً و پیش از آماده شدن PCR شروع شود.",
   "انسفالیت HSV درمان‌نشده مرگ‌ومیر بالای هفتاد درصد دارد."
  ],
  "points_en": [
   "Meningitis means inflammation of the meninges; encephalitis means inflammation of the brain tissue itself.",
   "Meningeal irritation signs include headache, neck stiffness, photophobia and pain on eye movement.",
   "However severe these are, they show only meningeal involvement and do not change the diagnosis.",
   "Parenchymal signs are different: seizures, altered consciousness, and changes in personality and behaviour.",
   "Also focal neurological signs such as hemiparesis, aphasia and eye-movement disorders.",
   "The prognosis of the two differs completely, which is what makes the distinction vital.",
   "Viral meningitis is usually self-limiting and recovers with supportive care.",
   "Viral encephalitis can be fatal or disabling and demands immediate treatment.",
   "The commonest treatable cause of sporadic encephalitis in adults is herpes simplex virus type 1.",
   "HSV characteristically involves the temporal lobe, which MRI and EEG will show.",
   "Treatment is intravenous acyclovir, started immediately and before the PCR result is back.",
   "Untreated HSV encephalitis carries a mortality above seventy per cent."
  ]
 },
 "explanation_fa": "مرز مننژیت و انسفالیت یک چیز است و فقط یک چیز: آیا خودِ پارانشیم مغز درگیر شده یا نه. فوتوفوبی، درد حرکت چشم و سفتی گردن هر سه از تحریک مننژ می‌آیند — یعنی حتی اگر شدید باشند، باز هم فقط مننژیت را نشان می‌دهند و پیش‌آگهی را عوض نمی‌کنند. اما تشنج یعنی نورون‌های قشر مغز درگیر و تحریک شده‌اند؛ همین‌طور اختلال هوشیاری، تغییر شخصیت و نشانه‌های نورولوژیک کانونی. این تمایز آکادمیک نیست: بیمار مننژیت ویروسی معمولاً خودبه‌خود خوب می‌شود، ولی بیمار انسفالیت باید فوراً آسیکلوویر وریدی بگیرد تا HSV — که درمان‌نشده مرگ‌ومیر بالای هفتاد درصد دارد — پوشش داده شود.",
 "explanation_en": "One thing, and only one thing, separates meningitis from encephalitis: whether the brain parenchyma itself is involved. Photophobia, painful eye movement and neck stiffness all arise from meningeal irritation, so however severe they are they still indicate only meningitis and do not alter the prognosis. A seizure, by contrast, means cortical neurons are involved and irritable, as do altered consciousness, personality change and focal neurological signs. This distinction is not academic: a patient with viral meningitis usually recovers spontaneously, whereas a patient with encephalitis must receive intravenous acyclovir immediately to cover HSV, which untreated carries a mortality above seventy per cent.",
 "why_fa": [
  "فوتوفوبی از تحریک مننژ می‌آید و در مننژیت ویروسی ساده هم بسیار شایع است؛ درگیری پارانشیم را نشان نمی‌دهد.",
  "درد حین حرکت چشم‌ها هم یک علامت تحریک مننژ است و به‌تنهایی معنای انسفالیت ندارد.",
  "پاسخ صحیح — تشنج یعنی نورون‌های قشر مغز درگیر شده‌اند، پس پارانشیم مغز التهاب دارد.",
  "سفتی گردن شاخص‌ترین علامت تحریک مننژ است و دقیقاً همان چیزی است که در مننژیت انتظار داریم."
 ],
 "why_en": [
  "Photophobia arises from meningeal irritation and is very common in simple viral meningitis; it does not indicate parenchymal disease.",
  "Painful eye movement is likewise a meningeal irritation sign and does not by itself mean encephalitis.",
  "Correct — a seizure means cortical neurons are involved, so the brain parenchyma is inflamed.",
  "Neck stiffness is the hallmark of meningeal irritation and is exactly what we expect in meningitis."
 ],
 "golden_fa": "تشنج، افت هوشیاری یا علامت کانونی روی مننژیت = انسفالیت = آسیکلوویر وریدی فوری.",
 "golden_en": "Seizure, altered consciousness or a focal sign on top of meningitis means encephalitis and immediate IV acyclovir.",
 "refs": [
  "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 133: Acute Meningitis and Encephalitis"
 ]
}

L["1402-03:129"] = {
 "style": "recall", "difficulty": "medium",
 "micro": {
  "lead_fa": "گاز انسان در تمام موارد پروفیلاکسی می‌خواهد. فلور دهان انسان پرخطرترین است.",
  "lead_en": "A human bite always needs prophylaxis. The human oral flora is the most dangerous of all.",
  "points_fa": [
   "گازگرفتگی‌ها را نه بر اساس ترسناکی حیوان، بلکه بر اساس میزان عفونت زخم طبقه‌بندی می‌کنیم.",
   "گاز انسان بالاترین میزان عفونت را دارد و در تمام موارد پروفیلاکسی آنتی‌بیوتیکی می‌گیرد.",
   "دهان انسان فلور پرغلظت و مخلوط هوازی و بی‌هوازی دارد، بیش از صد گونه‌ی مختلف.",
   "پاتوژن شاخص گاز انسان، Eikenella corrodens است که به کلیندامایسین و آمینوگلیکوزید مقاوم است.",
   "خطرناک‌ترین شکل، زخم clenched-fist روی مفاصل متاکارپوفالانژیال است.",
   "این زخم مستقیم وارد فضای مفصلی و غلاف تاندون می‌شود و می‌تواند به سپتیک آرتریت بینجامد.",
   "گاز گربه هم پرخطر است چون دندان نازک و تیز، سوراخ عمیق و بسته می‌سازد.",
   "پاتوژن شاخص گاز گربه، Pasteurella multocida است که سلولیت سریع در چند ساعت می‌دهد.",
   "گاز سگ برعکس زخم پهن‌تر و بازتر می‌سازد و میزان عفونت آن پایین‌تر است.",
   "پس در گاز سگ پروفیلاکسی انتخابی و بر پایه‌ی محل زخم و وضعیت ایمنی بیمار است.",
   "گاز جوندگان کمترین خطر را دارد و حتی هاری هم منتقل نمی‌کند.",
   "آنتی‌بیوتیک انتخابی در همه‌ی گازگرفتگی‌ها کوآموکسی‌کلاو است.",
   "شست‌وشوی فراوان زخم، ارزیابی وضعیت کزاز و در موارد حیوانی، ارزیابی هاری فراموش نشود."
  ],
  "points_en": [
   "Bites are graded not by how frightening the animal is but by the observed wound infection rate.",
   "Human bites have the highest infection rate and receive antibiotic prophylaxis in every case.",
   "The human mouth carries a dense mixed aerobic and anaerobic flora, more than a hundred species.",
   "The characteristic pathogen of human bites is Eikenella corrodens, resistant to clindamycin and aminoglycosides.",
   "The most dangerous form is the clenched-fist injury over the metacarpophalangeal joints.",
   "That wound enters the joint space and tendon sheath directly and can lead to septic arthritis.",
   "Cat bites are also high-risk because the thin sharp teeth create a deep, sealed puncture.",
   "The characteristic pathogen of cat bites is Pasteurella multocida, causing rapid cellulitis within hours.",
   "Dog bites by contrast create a wider, more open wound and carry a lower infection rate.",
   "So for dog bites prophylaxis is selective, based on the wound site and the patient's immune status.",
   "Rodent bites carry the least risk and do not even transmit rabies.",
   "Co-amoxiclav is the antibiotic of choice for all bite wounds.",
   "Do not forget copious wound irrigation, tetanus status and, for animal bites, rabies assessment."
  ]
 },
 "explanation_fa": "این سؤال ظاهراً چهار حیوان را مقایسه می‌کند ولی در واقع یک اصل را می‌پرسد: کدام گازگرفتگی همیشه پروفیلاکسی می‌خواهد؟ پاسخ گازگرفتگی انسان است. دهان انسان فلور پرغلظت و مخلوط هوازی-بی‌هوازی دارد، از جمله Eikenella corrodens که به بسیاری از آنتی‌بیوتیک‌های رایج مقاوم است، و میزان عفونت زخم انسانی از همه بالاتر است؛ به‌ویژه زخم clenched-fist روی مفاصل MCP که مستقیم وارد فضای مفصلی می‌شود. برای همین در تمام موارد کوآموکسی‌کلاو تجویز می‌شود. گاز گربه هم پرخطر است و بسیاری از منابع آن را هم پرخطر می‌دانند، ولی قاعده‌ی «در همه‌ی موارد بدون استثنا» درباره‌ی انسان است. گاز سگ برعکس، زخم پهن‌تری می‌سازد و میزان عفونتش پایین‌تر است، پس پروفیلاکسی انتخابی است. جوندگان کمترین خطر را دارند.",
 "explanation_en": "The question appears to compare four animals but is really testing one principle: which bite always requires prophylaxis? The answer is the human bite. The human mouth carries a dense mixed aerobic-anaerobic flora, including Eikenella corrodens which resists many common antibiotics, and human bite wounds have the highest infection rate of all, especially the clenched-fist injury over the MCP joints that enters the joint space directly. That is why co-amoxiclav is given in every case. Cat bites are also high-risk and many sources treat them similarly, but the rule of universal, no-exception prophylaxis belongs to human bites. Dog bites, by contrast, create a wider wound with a lower infection rate, so prophylaxis there is selective. Rodents carry the least risk.",
 "why_fa": [
  "گاز سگ زخم پهن‌تر و بازتری می‌سازد و میزان عفونت آن پایین‌تر است؛ پروفیلاکسی انتخابی و بر پایه‌ی خطر است.",
  "پاسخ صحیح — گاز انسان بالاترین میزان عفونت را دارد و در تمام موارد پروفیلاکسی می‌گیرد.",
  "گاز گربه واقعاً پرخطر است، اما قاعده‌ی مطلق و بدون استثنا مربوط به گاز انسان است، نه گربه.",
  "گاز جوندگان کمترین خطر عفونت را دارد و حتی برای هاری هم پروفیلاکسی لازم نمی‌شود."
 ],
 "why_en": [
  "Dog bites create a wider, more open wound with a lower infection rate, so prophylaxis is selective and risk-based.",
  "Correct — human bites carry the highest infection rate and receive prophylaxis in every case.",
  "Cat bites really are high-risk, but the absolute no-exception rule belongs to human bites, not cats.",
  "Rodent bites carry the lowest infection risk and do not even require rabies prophylaxis."
 ],
 "golden_fa": "انسان > گربه > سگ > جونده از نظر خطر عفونت. انسان همیشه پروفیلاکسی؛ داروی همه: کوآموکسی‌کلاو.",
 "golden_en": "Infection risk: human over cat over dog over rodent. Human always gets prophylaxis; the drug for all is co-amoxiclav.",
 "refs": [
  "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 141: Infectious Complications of Bites"
 ]
}

L["1402-03:130"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "بارداری + سرولوژی VZV منفی + تماس در ۱۰ روز گذشته = VariZIG. واکسن زنده در بارداری ممنوع.",
  "lead_en": "Pregnancy plus negative VZV serology plus exposure within ten days equals VariZIG. Live vaccine is contraindicated in pregnancy.",
  "points_fa": [
   "پس از تماس با آبله‌مرغان، سه سؤال را به ترتیب بپرسید: آیا فرد ایمن است، آیا پرخطر است، چند روز گذشته.",
   "سابقه‌ی ابتلا یا واکسیناسیون کامل یعنی ایمن است و اقدامی لازم نیست.",
   "سرولوژی VZV منفی یعنی هیچ ایمنی وجود ندارد و بیمار واقعاً در معرض خطر است.",
   "گروه‌های پرخطر: زنان باردار، نوزادان، افراد با نقص ایمنی و بیماران تحت درمان سرکوبگر.",
   "در زن باردار غیرایمن، واریسلا می‌تواند پنومونی واریسلایی بدهد با مرگ‌ومیر بسیار بالا.",
   "ابتلا در بیست هفته‌ی اول بارداری خطر سندرم واریسلای مادرزادی جنین را ایجاد می‌کند.",
   "واکسن واریسلا ویروس زنده‌ی ضعیف‌شده است و در بارداری کاملاً ممنوع است.",
   "پس در این بیمار ایمن‌سازی غیرفعال یعنی تجویز ایمونوگلوبولین اختصاصی انتخاب می‌شود.",
   "VariZIG یا VZIG آنتی‌بادی آماده می‌دهد بدون آنکه ویروس زنده وارد بدن شود.",
   "پنجره‌ی زمانی مؤثر تا ده روز پس از تماس است؛ هرچه زودتر، بهتر.",
   "آسیکلوویر و والاسیکلوویر داروی درمان‌اند نه پیشگیری استاندارد پس از تماس.",
   "اگر ایمونوگلوبولین در دسترس نباشد، آسیکلوویر خوراکی از روز هفتم پس از تماس جایگزین درجه‌دو است.",
   "پس از پایان بارداری، واکسیناسیون این خانم برای بارداری‌های بعدی توصیه می‌شود."
  ],
  "points_en": [
   "After chickenpox exposure ask three questions in order: is the person immune, are they high-risk, how many days have passed.",
   "A history of disease or complete vaccination means immunity and no action is needed.",
   "Negative VZV serology means there is no immunity and the patient is genuinely at risk.",
   "High-risk groups are pregnant women, neonates, the immunodeficient and patients on immunosuppression.",
   "In a non-immune pregnant woman, varicella can cause varicella pneumonia with very high mortality.",
   "Infection in the first twenty weeks of pregnancy risks congenital varicella syndrome in the fetus.",
   "The varicella vaccine is a live attenuated virus and is absolutely contraindicated in pregnancy.",
   "So for this patient passive immunisation with specific immunoglobulin is the choice.",
   "VariZIG or VZIG supplies ready-made antibody without introducing live virus.",
   "The effective window extends to ten days after exposure; the sooner the better.",
   "Acyclovir and valacyclovir are treatment drugs, not standard post-exposure prophylaxis.",
   "If immunoglobulin is unavailable, oral acyclovir from day seven after exposure is a second-line alternative.",
   "After delivery, vaccinating this woman is recommended to protect future pregnancies."
  ]
 },
 "explanation_fa": "سه قید در صورت سؤال هست و هر سه لازم‌اند: بارداری، سرولوژی منفی یعنی بدون ایمنی، و فاصله‌ی پنج روز از تماس. بارداری یعنی واکسن واریسلا ممنوع است، چون واکسن ویروس زنده‌ی ضعیف‌شده است. سرولوژی منفی یعنی بیمار واقعاً در معرض خطر است و باید کاری کرد. و پنج روز یعنی هنوز داخل پنجره‌ی مؤثر ایمونوگلوبولین هستیم — VariZIG تا ده روز پس از تماس توصیه می‌شود. پس ایمن‌سازی غیرفعال با VZV IG پاسخ است: آنتی‌بادی آماده می‌دهد بدون آنکه ویروس زنده وارد کند، و هم مادر را از پنومونی واریسلایی که در بارداری مرگ‌ومیر بالایی دارد و هم جنین را محافظت می‌کند. آسیکلوویر و والاسیکلوویر داروی درمان‌اند نه پیشگیری استاندارد پس از تماس؛ اگر IG در دسترس نباشد به‌عنوان جایگزین درجه‌دو مطرح می‌شوند.",
 "explanation_en": "The stem contains three conditions and all three matter: pregnancy, negative serology meaning no immunity, and five days since exposure. Pregnancy rules out the varicella vaccine, because it is a live attenuated virus. Negative serology means the patient really is at risk and something must be done. And five days means we are still inside the effective immunoglobulin window, since VariZIG is recommended up to ten days after exposure. So passive immunisation with VZV IG is the answer: it supplies ready-made antibody without introducing live virus, and protects both the mother from varicella pneumonia, which carries high mortality in pregnancy, and the fetus. Acyclovir and valacyclovir are treatment agents rather than standard post-exposure prophylaxis; they are second-line if immunoglobulin is unavailable.",
 "why_fa": [
  "واکسن واریسلا ویروس زنده‌ی ضعیف‌شده است و تجویز آن در بارداری کاملاً ممنوع می‌باشد.",
  "پاسخ صحیح — ایمن‌سازی غیرفعال با ایمونوگلوبولین اختصاصی VZV، مؤثر تا ده روز پس از تماس و ایمن در بارداری.",
  "آسیکلوویر وریدی برای درمان واریسلای شدید یا پنومونی واریسلایی است، نه پیشگیری در فرد هنوز سالم.",
  "والاسیکلوویر خوراکی فقط در نبود ایمونوگلوبولین و از روز هفتم پس از تماس جایگزین درجه‌دو محسوب می‌شود."
 ],
 "why_en": [
  "The varicella vaccine is a live attenuated virus and is absolutely contraindicated in pregnancy.",
  "Correct — passive immunisation with VZV-specific immunoglobulin, effective up to ten days post-exposure and safe in pregnancy.",
  "Intravenous acyclovir treats severe varicella or varicella pneumonia; it is not prophylaxis in a still-well person.",
  "Oral valacyclovir is only a second-line option when immunoglobulin is unavailable, starting on day seven after exposure."
 ],
 "golden_fa": "بارداری = واکسن زنده ممنوع. تماس واریسلا + غیرایمن + ≤۱۰ روز = VariZIG.",
 "golden_en": "Pregnancy forbids live vaccines. Varicella exposure plus non-immune plus ten days or less equals VariZIG.",
 "refs": [
  "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 192: Varicella-Zoster Virus Infections"
 ]
}

json.dump(L, io.open('/home/user/work/infectious/lessons/L3.json', 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('infectious L3:', len(L))
