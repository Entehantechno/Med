# -*- coding: utf-8 -*-
"""English stems and options for the tuberculosis chapter (batches 51-57).

Rule 16 checked first, as always: these 62 items come from sittings 93 to 98,
for which the ministry published no English booklet, so these are hand-written
translations rather than official ones.

TRANSLATION DECISIONS WORTH RECORDING
--------------------------------------
DRUG NAMES use the international non-proprietary spellings — isoniazid,
rifampicin, pyrazinamide, ethambutol, streptomycin — and the source's Persian
transliterations are mapped onto them consistently. Where the source writes an
older or local spelling of a second-line agent (ofloxacin, prothionamide,
cycloserine) the standard English form is used.

THE ABBREVIATIONS ARE KEPT AS A CLINICIAN WOULD WRITE THEM: PPD, TST, IGRA,
BCG, AFB, BK (the source's term for acid-fast bacilli, expanded on first use),
CXR, ESRD, HRZE. Expanding every one would make the stems unreadable; leaving
them opaque would make them unusable. The compromise is to expand on first
appearance within a stem where the Persian does the same.

THE REPAIRED NUMBERS are carried in their corrected form, as always: q9214's
pleural panel (LDH 2000 against a serum 500, glucose 60) and q9249's
haemoglobin (12, not 21). Both were confirmed against the printed glyph runs
of pages 84 and 97 before being written here; see fix_tb_numbers2.py for the
evidence.

q9249's haemoglobin deserves a note of its own. At 21 the panel would show
polycythaemia and the student would hunt for another cause of the purpura. At
12, WITH A NORMAL WHITE COUNT, the platelet count of 40,000 stands alone as an
ISOLATED THROMBOCYTOPENIA — which is precisely the finding that names
rifampicin as the culprit. The mirrored digit had destroyed the question.

TWO PHRASES THAT ARE LOAD-BEARING AND ARE TRANSLATED LITERALLY EVERY TIME:
"regardless of the tuberculin result", because six questions in this chapter
turn on it; and "after excluding active disease", because giving preventive
monotherapy to a patient with active tuberculosis is the single most damaging
error in the chapter.
"""

EN22 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    assert all(o.strip() for o in options), idx
    EN22[idx] = {"stem_en": stem, "options_en": options}


# =========================================================== BATCH 51
add(205,
    "Given that one third of the world's population has latent tuberculosis and a positive tuberculin "
    "test, which of the following groups has the highest chance of progressing to active tuberculosis?",
    ["HIV infection",
     "Injecting drug users",
     "Chronic hepatitis B",
     "Patients with diabetes mellitus"])

add(206,
    "A 35-year-old man presents with a cough of one month's duration and one episode of blood-streaked "
    "sputum yesterday. He reports weight loss and anorexia. He states that he has become low in mood "
    "and has lost his concentration. On examination he has flank tenderness and scattered crackles on "
    "auscultation. How many of the features required for tuberculosis assessment in the national "
    "guideline does he have?",
    ["3", "4", "5", "7"])

add(207,
    "A 13-year-old adolescent girl with no underlying disease presents with chest pain, fever, weight "
    "loss, cough and scant sputum for about one month. On examination she is febrile and a lesion "
    "resembling erythema nodosum is seen on her shin. The chest radiograph shows infiltration in the "
    "mid and peripheral zone of the lung together with pleural reaction and hilar adenopathy. Which is "
    "most likely?",
    ["Primary tuberculosis",
     "Post-primary tuberculosis",
     "Lung cancer",
     "Candida infection"])

add(208,
    "Which of the following is a feature of primary pulmonary tuberculosis?",
    ["Hilar adenopathy",
     "Pleurisy",
     "Phlyctenular conjunctivitis",
     "All of the above"])

add(210,
    "In tuberculous adenitis, what percentage of lymph node biopsy specimens yield a positive culture "
    "for tuberculosis?",
    ["20 to 30 %",
     "70 to 80 %",
     "50 to 60 %",
     "90 to 100 %"])

add(211,
    "A 30-year-old man presents with a seizure and right-sided weakness. He is afebrile, has no other "
    "systemic symptoms, is HIV negative and has no underlying disease. His chest radiograph shows "
    "fibrotic lesions at the right apex. His tuberculin test measures 20 mm. Brain MRI shows several "
    "3 to 4 cm space-occupying lesions with ring enhancement. Which diagnosis is most likely?",
    ["Brain tumour",
     "Tuberculoma",
     "Cerebral toxoplasmosis",
     "Cerebral lymphoma"])

add(212,
    "A married woman presents with chronic pelvic pain, primary infertility and menstrual disturbance. "
    "Laboratory investigation reports sterile pyuria. Genitourinary tuberculosis is suspected. Which "
    "diagnostic approach is preferred?",
    ["Acid-fast staining of urine on three occasions",
     "A single urine PCR",
     "Culture of early-morning urine on three occasions",
     "Acid-fast staining of a tissue specimen"])

add(213,
    "A patient is being investigated for a unilateral pleural effusion. Aspiration of the pleural fluid "
    "shows an exudate with a low glucose and a white cell count of 1550 with lymphocyte predominance. "
    "Which of the following do you consider best for reaching the diagnosis?",
    ["Examination of the pleural fluid for acid-fast bacilli",
     "Pleural biopsy",
     "Measurement of adenosine deaminase (ADA) in the pleural fluid",
     "Tuberculin skin test (PPD)"])

add(214,
    "A man presents with a one-month history of cough, fever, breathlessness, sweating and weight loss. "
    "CT of the chest shows a right pleural effusion without parenchymal involvement. Analysis of the "
    "pleural fluid shows LDH = 2000 mg/dL (simultaneous serum = 500), glucose = 60, protein 4 g/dL "
    "(simultaneous serum = 2.5) and a white cell count of 2000/microlitre with 90 % lymphocytes. He "
    "reports close contact with a patient with tuberculosis. What is the most appropriate step towards "
    "the diagnosis?",
    ["Pleural biopsy and a tuberculin skin test (PPD)",
     "Pleural fluid smear for acid-fast bacilli and serum interferon gamma release assay (IGRA)",
     "Pleural fluid smear and culture for acid-fast bacilli together with pleural biopsy",
     "Sputum smear and culture for acid-fast bacilli"])

# =========================================================== BATCH 52
add(215,
    "A 45-year-old man with a history of imprisonment presents with productive cough for the past two "
    "months. He also complains of weight loss and night sweats. Three sputum smears have been negative "
    "for acid-fast bacilli and two weeks of antibiotic treatment have produced no change in his "
    "clinical condition. What is the appropriate next step?",
    ["Repeat three sputum smears for acid-fast bacilli",
     "PCR of the sputum for Mycobacterium tuberculosis",
     "Bronchoscopy with bronchoalveolar lavage",
     "Start antituberculous treatment for smear-negative pulmonary tuberculosis"])

add(216,
    "A 30-year-old patient presents with a cough of one month's duration. Because his general condition "
    "was good he was treated for allergy and also received a course of azithromycin and co-amoxiclav, "
    "with no improvement. Which step takes priority?",
    ["Chest CT",
     "Sputum examination for tuberculosis on three occasions",
     "Starting oral prednisolone",
     "Requesting CBC, ESR and CRP"])

add(218,
    "A 27-year-old man presents with a prolonged cough for the past two months. He has attended as an "
    "outpatient several times and reports slight improvement after a dextromethorphan syrup. He uses "
    "psychoactive drugs and has lost a considerable amount of weight during this period. His chest "
    "radiograph is reported as showing a lesion suggestive of bronchopneumonia. What is the first "
    "step?",
    ["Bronchoscopy",
     "Chest CT",
     "Antibiotic treatment with amoxicillin/clavulanic acid",
     "Requesting sputum smear and acid-fast staining on three occasions"])

add(219,
    "A 30-year-old pregnant woman at 25 weeks' gestation presents with weakness, malaise, loss of "
    "appetite and a cough that began one month ago. On examination her temperature is 37.8 C and her "
    "chest is clear on auscultation. What is the most appropriate diagnostic step?",
    ["Tuberculin skin test",
     "Sputum smear",
     "Sputum culture",
     "Bronchoscopy"])

add(220,
    "An HIV-positive man who has spent the past year in prison presents with cough, sputum and weight "
    "loss. Investigation shows unilateral opacity at the lung apex. Which of the following tests on "
    "his sputum offers the greatest speed and sensitivity?",
    ["Auramine-rhodamine staining",
     "Interferon gamma release assay",
     "Ziehl-Neelsen staining",
     "Xpert MTB/RIF"])

add(221,
    "The QuantiFERON test is specific for which of the following?",
    ["Leprosy",
     "Nocardia infection",
     "Infection with Mycobacterium tuberculosis",
     "Infection with non-tuberculous mycobacteria"])

add(222,
    "Regarding co-infection with tuberculosis and HIV, which statement is correct?",
    ["In these patients the blood culture may become positive for mycobacteria.",
     "The rate of sputum smear positivity increases as HIV disease advances.",
     "Upper-zone involvement and cavity formation increase as HIV disease advances.",
     "The risk of latent infection progressing to tuberculosis in these patients is 3 to 13 % over a lifetime."])

add(223,
    "A patient with chronic cough attends the tuberculosis control centre. Three sputum smears have "
    "been negative for acid-fast bacilli and the centre has referred him to you. What do you do at the "
    "first stage?",
    ["Start a course of antibiotic treatment",
     "Repeat the direct sputum examination",
     "Chest CT for further evaluation",
     "Wait for the sputum culture result"])

# =========================================================== BATCH 53
add(225,
    "A 55-year-old man presents with cough, haemoptysis and about 10 kg of weight loss, and is "
    "diagnosed with smear-positive pulmonary tuberculosis. Which of the following is NOT considered a "
    "first-line drug?",
    ["Rifampicin",
     "Isoniazid",
     "Pyrazinamide",
     "Levofloxacin"])

add(226,
    "A 35-year-old man has developed sputum-positive pulmonary tuberculosis. Five years ago he received "
    "six months of treatment for tuberculous lymphadenitis. How many months should the antituberculous "
    "regimen be on this occasion?",
    ["6", "8", "10", "12"])

add(228,
    "A patient with pulmonary tuberculosis presents with a 3+ sputum smear and a cavity in the lung. He "
    "completed a full course of tuberculosis treatment eight years ago. How should the intensive phase "
    "be started in him?",
    ["We do not treat until the culture result is available.",
     "We treat for 3 months with the four first-line drugs isoniazid, rifampicin, ethambutol and pyrazinamide.",
     "Treatment is the same as for a patient diagnosed for the first time.",
     "Treatment is started with isoniazid, rifampicin, ethambutol, pyrazinamide and streptomycin."])

add(229,
    "A young woman presents with several painless enlarged lymph nodes in the right side of the neck. "
    "She is afebrile and reports no weight loss. Clinical examination and laboratory investigations are "
    "normal. Fine-needle aspiration of the nodes reports caseating granuloma. She has no immune defect. "
    "What is the appropriate treatment?",
    ["Isoniazid plus rifampicin for 6 months",
     "Isoniazid plus rifampicin for 4 months",
     "The classical four-drug regimen for 2 months followed by two drugs for 4 months",
     "The classical four-drug regimen for 2 months followed by two drugs for 7 months"])

add(230,
    "A 32-year-old woman from Bojnurd presents with a painless mass in the left side of the neck. She "
    "has fever and mild weight loss. Other clinical examinations and tests are normal. Biopsy of the "
    "mass reports caseating granuloma. Given the most likely diagnosis, what is the appropriate step?",
    ["Start isoniazid for 9 months",
     "Clinical follow-up in 6 months",
     "Isoniazid plus rifampicin for 4 months",
     "The standard four-drug antituberculous regimen for 6 months"])

add(232,
    "A 25-year-old Afghan woman was started six months ago on empirical four-drug antituberculous "
    "therapy for presumed tuberculous pleurisy and stopped the drugs about two weeks later. She now "
    "returns with fever and productive cough. The chest radiograph shows a cavity at the right apex "
    "with an ipsilateral pleural effusion. Which of the following is correct in approaching her?",
    ["Restart the standard four-drug regimen",
     "Category II treatment as treatment after default",
     "Category I treatment if the sputum smear is again positive",
     "Decide after repeating the smear and performing a pleural biopsy"])

add(233,
    "A 52-year-old man diagnosed with pulmonary tuberculosis stopped his drugs on his own initiative "
    "two months after starting them because his symptoms had improved. Three months later he returns "
    "complaining of recurrent symptoms with drenching sweats and productive cough, and his sputum smear "
    "is positive for acid-fast bacilli. Which of the following do you consider correct?",
    ["Restart the standard regimen without counting the previous duration of treatment",
     "Start the Category II regimen and continue treatment according to the susceptibility results",
     "Perform a sputum culture and re-treat according to the susceptibility results",
     "Restart treatment with isoniazid plus four new second-line drugs"])

add(259,
    "In a patient with extensively drug-resistant pulmonary tuberculosis (XDR-TB), which of the "
    "following regimens is recommended?",
    ["Adding a fluoroquinolone such as high-dose moxifloxacin or levofloxacin to the regimen",
     "Using second-line antituberculous drugs not previously used (cycloserine, para-aminosalicylic acid, ethionamide, prothionamide)",
     "Both of the above",
     "Neither of the above"])

# =========================================================== BATCH 54
add(236,
    "A patient develops joint pain after starting antituberculous treatment. Which drug causes this "
    "adverse effect?",
    ["Isoniazid",
     "Rifampicin",
     "Pyrazinamide",
     "Ethambutol"])

add(246,
    "Which of the following antituberculous drugs is NOT hepatotoxic?",
    ["Isoniazid",
     "Rifampicin",
     "Ethambutol",
     "Pyrazinamide"])

add(257,
    "A pregnant woman currently on antituberculous treatment presents complaining of tingling and "
    "numbness of her hands and feet in a glove-and-stocking distribution. This adverse effect has "
    "followed the use of which of the following drugs?",
    ["Ethambutol",
     "Rifampicin",
     "Isoniazid",
     "Pyrazinamide"])

add(247,
    "A 68-year-old woman is receiving four-drug antituberculous therapy for smear-positive pulmonary "
    "tuberculosis. In the second month of treatment she develops optic neuritis. Which is appropriate?",
    ["Permanent removal of pyrazinamide from the regimen",
     "Temporary removal of ethambutol until the neuritis resolves",
     "Permanent removal of ethambutol from the regimen",
     "Temporary removal of pyrazinamide until the neuritis resolves"])

add(237,
    "A 27-year-old woman with end-stage renal disease on haemodialysis three times weekly is admitted "
    "complaining of productive cough, weight loss and anorexia. Her chest radiograph shows pulmonary "
    "infiltration at the right apex and one sputum smear is positive for acid-fast bacilli. Given the "
    "above, which drug is best left out of the treatment regimen?",
    ["Rifampicin",
     "Pyrazinamide",
     "Ethambutol",
     "Isoniazid"])

add(239,
    "A 45-year-old man who has been on the standard four-drug regimen for pulmonary tuberculosis for "
    "about three weeks attends for follow-up. His liver enzymes are about three times the upper limit "
    "of normal. He has no particular symptoms. At this stage, what do you suggest regarding "
    "continuation of treatment?",
    ["Stop all antituberculous drugs and refer to a specialist centre",
     "Continue the antituberculous drugs and repeat the test",
     "Stop pyrazinamide and ethambutol",
     "Stop the three drugs isoniazid, rifampicin and pyrazinamide"])

add(245,
    "A 57-year-old man with smear-positive pulmonary tuberculosis has been started on the standard "
    "regimen of isoniazid, rifampicin, pyrazinamide and ethambutol. After three weeks he presents with "
    "abdominal pain, nausea and vomiting, and his liver enzymes are more than three times normal. What "
    "is the appropriate step for this patient?",
    ["Continue the standard treatment and monitor the patient",
     "Stop the drugs temporarily until the liver enzymes normalise",
     "Continue pyrazinamide and ethambutol and stop isoniazid and rifampicin",
     "Stop pyrazinamide and continue the other drugs together with levofloxacin"])

add(242,
    "A 40-year-old man has been on treatment for smear-negative pulmonary tuberculosis for one month "
    "with rifampicin, isoniazid, ethambutol and pyrazinamide. For the past three days he has had "
    "anorexia and nausea and has vomited once. On examination his general condition is good, his vital "
    "signs are normal and the rest of the examination shows no important findings. Which step is "
    "correct for him?",
    ["Stop rifampicin and isoniazid while continuing the other antituberculous drugs, and request AST, ALT and bilirubin",
     "Continue the antituberculous treatment and give metoclopramide",
     "Stop all the antituberculous drugs and request AST, ALT and bilirubin",
     "Stop rifampicin, isoniazid and pyrazinamide and continue with ethambutol and ciprofloxacin"])

add(249,
    "A patient with smear-positive pulmonary tuberculosis in the intensive phase of treatment presents "
    "with an itchy skin rash together with petechiae and purpura. Laboratory investigation of the "
    "peripheral blood count shows WBC = 6000, Hb: 12 mg/dl and platelets = 40000. The antituberculous "
    "drugs are stopped and after one week his symptoms improve. When antituberculous treatment is "
    "restarted, which of the following drugs must NOT be used?",
    ["Ethambutol",
     "Rifampicin",
     "Isoniazid",
     "Pyrazinamide"])

add(254,
    "A 45-year-old patient with smear-positive pulmonary tuberculosis has been on the standard four-drug "
    "regimen since last month. Since yesterday he has suddenly developed shock, thrombocytopenia and "
    "acute renal failure of the interstitial nephritis type. Which of the following drugs is "
    "responsible for this complication?",
    ["Isoniazid",
     "Rifampicin",
     "Ethambutol",
     "Pyrazinamide"])

add(258,
    "In a patient with pulmonary tuberculosis on four-drug antituberculous therapy, the appearance of "
    "which of the following complications does NOT require permanent discontinuation of the drug?",
    ["Optic neuritis with ethambutol",
     "Thrombocytopenia with rifampicin",
     "Gouty arthritis with pyrazinamide",
     "Hepatitis with isoniazid"])

add(238,
    "A newborn who received the birth vaccination programme presents one week later with generalised "
    "lymphadenopathy, fever and poor feeding. Investigations report a positive NBT test. He is "
    "therefore treated for disseminated vaccine-derived mycobacterial disease. In your view, which of "
    "the following drugs has intrinsic resistance against this mycobacterium?",
    ["Pyrazinamide",
     "Ethambutol",
     "Rifampicin",
     "Isoniazid"])

# =========================================================== BATCH 55
add(250,
    "A patient with pulmonary tuberculosis develops a fall in platelet count to 5,000/microlitre two "
    "weeks after receiving four-drug treatment with isoniazid, rifampicin, pyrazinamide and ethambutol "
    "(HRZE). What is the appropriate recommendation for continuing the treatment regimen?",
    ["Ofloxacin plus amikacin plus cycloserine plus prothionamide plus pyrazinamide plus ethambutol",
     "Isoniazid, pyrazinamide and ethambutol (HZE) for twelve to eighteen months",
     "Pyrazinamide, ethambutol, streptomycin and a quinolone (ZESQ) for twelve to eighteen months",
     "No change of drugs is needed."])

add(251,
    "A 30-year-old woman develops cutaneous petechiae two weeks after starting four-drug treatment "
    "(HRZE) for pulmonary tuberculosis. Her blood count shows thrombocytopenia at around 40 thousand (40,000). How "
    "must her treatment regimen be changed in order to continue?",
    ["Isoniazid plus pyrazinamide plus ethambutol",
     "Rifampicin plus ethambutol plus rifampicin plus pyrazinamide plus a steroid",
     "Ofloxacin plus amikacin plus cycloserine plus prothionamide plus pyrazinamide plus ethambutol",
     "Isoniazid plus rifampicin"])

add(255,
    "The use of which of the following antituberculous drugs requires a change in the dose of hormonal "
    "contraceptives or the use of non-hormonal methods?",
    ["Rifampicin",
     "Isoniazid",
     "Ethambutol",
     "Pyrazinamide"])

add(256,
    "A 25-year-old woman who regularly takes LD contraceptive pills to prevent pregnancy develops, over "
    "the course of one month, productive cough, weight loss, fever and sweating. Her chest radiograph "
    "shows involvement of the left lung apex and three sputum smears are reported positive for AFB. She "
    "is started on six months of four-drug antituberculous treatment. By the end of the second month "
    "all her symptoms have resolved, but because of a missed period she has a beta-HCG test which "
    "confirms pregnancy. In your view, which of the antituberculous drugs has caused this unintended "
    "pregnancy?",
    ["Rifampicin",
     "Isoniazid",
     "Ethambutol",
     "Pyrazinamide"])

add(262,
    "In a patient whose tuberculin skin test is recorded as 8 mm of induration, the presence of which "
    "of the following prompts a recommendation for chemoprophylaxis after active tuberculosis has been "
    "excluded?",
    ["Injecting drug use",
     "Organ transplantation",
     "Age under 5 years",
     "Gastrointestinal surgery"])

add(263,
    "A nurse works on an infectious diseases ward. Her pre-employment tests and examinations were all "
    "normal, and on routine annual review her tuberculin test measures 15 mm (two years after "
    "appointment). What is the appropriate step for her?",
    ["She does not need chemoprophylaxis.",
     "Give isoniazid for six months",
     "Give isoniazid for twelve months",
     "Repeat the skin test 6 to 8 weeks later"])

add(267,
    "A nurse with systemic lupus erythematosus has been on prolonged corticosteroid treatment. On "
    "routine testing her Mantoux (PPD) measures 12 mm and her examination reveals no positive findings. "
    "What is the most appropriate step for her?",
    ["No specific action is needed",
     "Standard drug treatment",
     "Repeat the tuberculin skin test",
     "Preventive drug treatment"])

# =========================================================== BATCH 56
add(268,
    "A 25-year-old man with HIV infection has shared a house for one month with a patient who has "
    "smear-positive pulmonary tuberculosis. His medical history and clinical examination show no "
    "evidence of active tuberculosis and his tuberculin test is negative. Regarding the use of "
    "isoniazid prophylaxis in this patient, which option is correct?",
    ["Isoniazid prophylaxis for one month, then repeat the tuberculin test and, if positive, continue isoniazid for a further eight months",
     "Isoniazid prophylaxis for 3 months, then repeat the tuberculin test and, if positive, continue isoniazid for a further 6 months",
     "Isoniazid prophylaxis for 9 months is required",
     "No isoniazid prophylaxis is needed"])

add(269,
    "A patient with HIV infection who has been a household contact of a patient with smear-positive "
    "pulmonary tuberculosis attends your clinic. Provided that clinical examination and laboratory "
    "findings show no evidence of active tuberculosis, on the basis of the tuberculin skin test result "
    "which step is correct for isoniazid prevention in this patient?",
    ["If the reaction exceeds 10 mm",
     "If the reaction exceeds 5 mm",
     "With any reaction of one millimetre or more",
     "Regardless of the skin test result"])

add(270,
    "A 25-year-old HIV-positive man with no respiratory symptoms is brought from prison for advice. His "
    "history reveals that a patient with smear-positive pulmonary tuberculosis shared his cell. His "
    "chest radiograph is normal and his tuberculin test is also reported negative. Which of the "
    "following do you recommend for this patient?",
    ["No specific action is needed and we advise follow-up of the patient.",
     "Start isoniazid and repeat the tuberculin test three months later.",
     "Start isoniazid and continue it for a full 9 months.",
     "Start rifampicin and continue it for a full 6 months."])

add(271,
    "A young HIV-positive man who has recently had close contact with a patient with smear-positive "
    "pulmonary tuberculosis has a tuberculin test measuring 5 mm, a negative sputum examination and a "
    "normal chest radiograph. What therapeutic or preventive action is recommended for him?",
    ["Four-drug antituberculous treatment for 6 months",
     "Treatment with isoniazid for 9 months",
     "Treatment with rifampicin for 2 months",
     "No specific action is needed."])

add(264,
    "A patient with human immunodeficiency virus (HIV) infection has a positive tuberculin skin test "
    "with 7 mm of induration. He denies cough, fever, night sweats and weight loss. What do you "
    "recommend?",
    ["Isoniazid for nine months",
     "Rifampicin and pyrazinamide for two months",
     "Rifampicin for three months",
     "No specific action is needed."])

add(265,
    "A patient with HIV attends with a tuberculin test of 5 mm. He denies fever, night sweats and "
    "weight loss. If his chest radiograph is normal, what is your next step?",
    ["Isoniazid prophylaxis for 6 to 9 months",
     "Start four-drug treatment against tuberculosis",
     "No action is required for this patient.",
     "Repeating the tuberculin skin test after three months is recommended."])

add(281,
    "A 55-year-old diabetic patient has recently shared a prison cell with a person who has "
    "smear-positive pulmonary tuberculosis. The diabetic patient has no respiratory symptoms, his chest "
    "radiograph is normal and his tuberculin skin test is recorded as 3 millimetres. What do you decide "
    "in order to prevent active tuberculosis in this patient?",
    ["Because of his underlying disease we treat him with isoniazid for 6 months.",
     "We repeat the skin test three months later and start isoniazid if it exceeds 5 mm.",
     "If more than 12 weeks have passed since this person's last contact with the tuberculosis patient, isoniazid treatment is not needed.",
     "He does not need isoniazid treatment and we simply follow him up every 6 months for two years."])

add(282,
    "A 55-year-old man has developed smear-positive pulmonary tuberculosis. For his wife, who is "
    "healthy in every respect and currently has no complaints, which of the following is the most "
    "correct action?",
    ["Perform a tuberculin skin test",
     "Perform a plain chest radiograph",
     "Perform a sputum examination for acid-fast bacilli",
     "Simply advise her to see a doctor if symptoms appear"])

# =========================================================== BATCH 57
add(272,
    "In a patient with smear-positive pulmonary tuberculosis who has a 6-month-old child, which of the "
    "following do you recommend?",
    ["If the infant's tuberculin test is positive, start four-drug treatment",
     "If the infant's tuberculin test is positive, start drug prophylaxis",
     "If the infant's tuberculin test is negative, start drug prophylaxis",
     "Perform a tuberculin test and start prophylaxis regardless of its result"])

add(274,
    "A 32-year-old woman diagnosed with smear-positive pulmonary tuberculosis is on treatment. A "
    "tuberculin test has been performed on her 3-year-old child and the result is negative. What is the "
    "appropriate action for this child?",
    ["Preventive treatment with isoniazid for 9 months",
     "No specific action is needed, but re-examine and reassess three months later.",
     "Start preventive treatment with isoniazid and repeat the tuberculin test after 3 months",
     "Repeat the tuberculin test after 3 months and, if positive, start preventive treatment"])

add(276,
    "A 4-year-old child has been in contact with his grandmother, who had sputum-positive pulmonary "
    "tuberculosis. The child has no symptoms of tuberculosis, but a tuberculin skin test (TST/PPD) "
    "performed on him showed 2 millimetres of induration. According to the national protocol, what "
    "action is required for the prevention of tuberculosis in this child?",
    ["Perform a chest radiograph and, if abnormal, give the child preventive treatment with isoniazid",
     "Give three months of preventive treatment with isoniazid, then perform a tuberculin test and then decide about continuing preventive treatment",
     "Give three months of preventive treatment with isoniazid, then obtain a chest radiograph and then decide about continuing preventive treatment",
     "Perform a chest radiograph and, if normal, give a full 6-month course of preventive treatment with isoniazid"])

add(278,
    "A housewife who has recently been diagnosed with smear-positive pulmonary tuberculosis attends "
    "your clinic. Regarding her 2-year-old child, whose clinical assessment for tuberculosis was "
    "negative and whose tuberculin test is negative, what action is required?",
    ["Start preventive treatment with isoniazid",
     "Perform a tuberculin test one month later",
     "Start tuberculosis treatment with a four-drug regimen",
     "No specific action is needed"])

add(275,
    "A 27-year-old woman with smear-positive pulmonary tuberculosis is receiving four-drug "
    "antituberculous treatment. What do you advise for this mother's 9-month-old infant?",
    ["If the chest radiograph is abnormal, we start drug prophylaxis.",
     "If there is no active tuberculosis, we start drug prophylaxis and review the infant clinically every two months.",
     "Only if the infant's tuberculin skin test exceeds 5 millimetres do we start drug prophylaxis.",
     "We review clinically every three months and start drug prophylaxis if the tuberculin skin test becomes positive and the radiograph is abnormal."])

add(279,
    "The tuberculin test of a three-year-old boy whose mother has active smear-positive pulmonary "
    "tuberculosis is reported as ten millimetres. What is the appropriate action?",
    ["Treatment with isoniazid and rifampicin for 12 months",
     "Start isoniazid prophylaxis after excluding active disease",
     "Start isoniazid prophylaxis and repeat the tuberculin test after three months",
     "Start four-drug treatment"])

add(280,
    "The mother of a three-year-old child attends your clinic for advice. Her husband was diagnosed two "
    "weeks ago with sputum-positive pulmonary tuberculosis and has started treatment. What approach is "
    "appropriate as the first step for this child?",
    ["Start isoniazid prophylaxis",
     "Start rifampicin prophylaxis",
     "Prove or exclude the diagnosis of pulmonary tuberculosis",
     "Clinical follow-up for 6 months"])

add(277,
    "Two months after delivery, a woman is diagnosed with smear-positive pulmonary tuberculosis and is "
    "on treatment. Her infant received BCG vaccine at birth and is currently asymptomatic. Which action "
    "is appropriate for the infant?",
    ["Formula feeding",
     "Prescribe isoniazid for 6 months",
     "Prescribe isoniazid only if the tuberculin test is positive",
     "Prescribe rifampicin for 3 months and then decide on the basis of the tuberculin test"])

add(284,
    "A 24-year-old woman at 38 weeks' gestation has developed sputum-positive pulmonary tuberculosis and "
    "has been started on rifampicin, isoniazid, pyrazinamide and ethambutol. Eight days after starting "
    "treatment she delivers. For the prevention of tuberculosis in her newborn, which of the following "
    "is correct?",
    ["BCG vaccine should be given on the first day of life.",
     "The newborn should have a tuberculin skin test and, if positive, receive isoniazid prophylaxis for 6 months.",
     "She should temporarily withhold breast milk and the infant should be separated from the mother for 2 weeks after the start of treatment.",
     "Isoniazid prophylaxis should be started for the newborn and completed over 6 months."])

add(283,
    "A 28-year-old woman was diagnosed with smear-positive pulmonary tuberculosis in the seventh month "
    "of pregnancy and started on the standard four-drug first-line antituberculous regimen, and by the "
    "ninth month of pregnancy her sputum smear had become negative. What do you now recommend for her "
    "newborn?",
    ["Avoid breast milk",
     "Start isoniazid",
     "Give the BCG vaccine",
     "Separate the newborn from the mother"])
