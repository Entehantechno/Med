# -*- coding: utf-8 -*-
"""Micro-lessons, batch 52 — tuberculosis part two: making the diagnosis.
Sputum smear, culture, Xpert MTB/RIF, IGRA, the smear-negative algorithm, and
the special case of tuberculosis with HIV.

THE DIAGNOSTIC LADDER, WHICH DECIDES EVERY QUESTION IN THIS BLOCK
-------------------------------------------------------------------
    SPUTUM SMEAR (Ziehl-Neelsen or auramine-rhodamine)
        cheap, fast, available everywhere — and the basis of infectiousness
        NEEDS ABOUT 10,000 BACILLI PER MILLILITRE to turn positive
        sensitivity in pulmonary TB: only about 50-60 %
        THREE specimens, because shedding is intermittent

    XPERT MTB/RIF (automated nucleic-acid amplification)
        result in under two hours
        far more sensitive than smear, especially in smear-negative and in HIV
        AND IT REPORTS RIFAMPICIN RESISTANCE AT THE SAME TIME
        WHO now recommends it as the INITIAL test, not a back-up

    CULTURE
        THE GOLD STANDARD — most sensitive, and the only route to full
        susceptibility testing
        but 2 to 6 weeks on solid medium (1 to 3 in liquid), so it never
        answers "what do I do now?"

    IGRA / tuberculin skin test
        THESE DETECT INFECTION, NOT DISEASE
        useless for diagnosing active tuberculosis in an endemic country

THE SMEAR-NEGATIVE ALGORITHM, ASKED THREE TIMES
-------------------------------------------------
A patient with chronic cough whose three smears are negative is NOT thereby
free of tuberculosis: smear misses roughly 40-50 % of cases. The national
programme's sequence is:

    1. a trial of a BROAD-SPECTRUM ANTIBIOTIC (not a fluoroquinolone) for
       10 to 14 days, to clear an ordinary bacterial pneumonia
    2. if the patient does not improve, REPEAT THREE SMEARS
    3. chest radiograph, culture, and Xpert
    4. only then, a clinical diagnosis of smear-negative tuberculosis

WHY NOT A FLUOROQUINOLONE FOR THAT TRIAL? Because levofloxacin and
moxifloxacin are ACTIVE AGAINST M. TUBERCULOSIS. They produce a partial,
temporary improvement that masks the diagnosis, delay it by weeks, and breed
fluoroquinolone resistance in a drug class that is the backbone of MDR-TB
treatment. This single point is worth more marks than any other in the block.

TUBERCULOSIS IN HIV — FOUR THINGS THAT INVERT
-----------------------------------------------
    the TUBERCULIN TEST tends to be NEGATIVE (anergy)
    the SMEAR is LESS often positive as the CD4 count falls, because
        cavitation — which pours bacilli into the airway — requires immunity
    the RADIOGRAPH loses its upper-lobe cavitary pattern and becomes
        lower-zone, diffuse, miliary, or entirely normal
    MYCOBACTERAEMIA becomes possible: the BLOOD CULTURE may grow the organism
    and the lifetime risk of 10 % becomes ABOUT 10 % PER YEAR

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022) —
tuberculosis; WHO consolidated guidelines on tuberculosis, Module 3:
Diagnosis — rapid diagnostics for tuberculosis detection (2021).
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — tuberculosis")
WHO3 = ("WHO consolidated guidelines on tuberculosis, Module 3: Diagnosis — "
        "rapid diagnostics for tuberculosis detection, 2021 update")
REFS = [H]
REFSW = [H, WHO3]

# ============================================== SMEAR-NEGATIVE ALGORITHM
ALGO_FA = [
    "⚠️ **اسمیر خلط منفی، سل را رد نمی‌کند.**",
    "**چون اسمیر برای مثبت شدن به حدود ۱۰٬۰۰۰ باسیل در میلی‌لیتر نیاز دارد.**",
    "**حساسیتش در سل ریوی فقط حدود ۵۰ تا ۶۰٪ است.**",
    "**پس تقریباً نیمی از بیماران سل، اسمیر منفی‌اند.**",
    "**الگوریتم کشوری در اسمیر منفی، ترتیب مشخصی دارد.**",
    "**گام یک: یک دوره آنتی‌بیوتیک وسیع‌الطیف ۱۰ تا ۱۴ روزه.**",
    "**گام دو: اگر بهبود نیافت، سه نوبت اسمیر را تکرار کنید.**",
    "**گام سه: گرافی، کشت و Xpert.**",
    "**گام چهار: و تنها آنگاه، تشخیص بالینی سل اسمیر منفی.**",
    "⚠️ **و یک ممنوعیت مطلق: در این دوره‌ی آزمایشی، فلوروکینولون ندهید.**",
    "**چون لووفلوکساسین و موکسی‌فلوکساسین علیه باسیل سل فعال‌اند.**",
    "**بهبود موقتی می‌سازند، تشخیص را هفته‌ها عقب می‌اندازند، و مقاومت می‌سازند.**",
]
ALGO_EN = [
    "WARNING: A NEGATIVE SPUTUM SMEAR DOES NOT EXCLUDE TUBERCULOSIS.",
    "Because a smear needs about 10,000 bacilli per millilitre to turn positive.",
    "Its sensitivity in pulmonary tuberculosis is only about 50 to 60 %.",
    "So nearly half of all tuberculosis patients are smear-negative.",
    "The national algorithm for a negative smear follows a set order.",
    "STEP ONE: a 10- to 14-day trial of a BROAD-SPECTRUM ANTIBIOTIC.",
    "STEP TWO: if there is no improvement, REPEAT THREE SMEARS.",
    "STEP THREE: chest radiograph, culture and Xpert.",
    "STEP FOUR: and only then, a clinical diagnosis of smear-negative tuberculosis.",
    "WARNING, AND ONE ABSOLUTE PROHIBITION: DO NOT USE A FLUOROQUINOLONE FOR THAT TRIAL.",
    "Because levofloxacin and moxifloxacin are ACTIVE AGAINST the tubercle bacillus.",
    "They give temporary improvement, delay the diagnosis by weeks, and breed resistance.",
]

add("book:215", "vignette", "medium",
    "**سه اسمیر منفی و آنتی‌بیوتیک بی‌اثر: سه اسمیر را دوباره تکرار کنید.**",
    "Three negative smears and an ineffective antibiotic: repeat the three smears.",
    ALGO_FA, ALGO_EN,
    "این سؤال یکی از پرتکرارترین الگوهای امتحان پره‌انترنی است، و پاسخش کاملاً "
    "الگوریتمی است.\n\n"
    "**بیمار: مرد ۴۵ ساله با سابقه‌ی اقامت در زندان، سرفه‌ی خلط‌دار از ۲ ماه قبل، "
    "کاهش وزن و تعریق شبانه. سه نوبت اسمیر خلط منفی. دو هفته آنتی‌بیوتیک تغییری "
    "نداده است.**\n\n"
    "**احتمال سل در این بیمار بسیار بالاست:** زندان (محیط پرازدحام و پرخطر) + سرفه‌ی "
    "دوماهه + کاهش وزن + تعریق شبانه. **هر چهار مورد از فهرست غربالگری‌اند.**\n\n"
    "⚠️ **پس چرا اسمیرها منفی است؟ چون اسمیر آزمون حساسی نیست.** برای مثبت شدن به "
    "حدود **۱۰٬۰۰۰ باسیل در هر میلی‌لیتر خلط** نیاز دارد. حساسیت کلی‌اش در سل ریوی "
    "**۵۰ تا ۶۰٪** است. یعنی **تقریباً نیمی از بیماران سل، اسمیر منفی‌اند** — به‌ویژه "
    "کسانی که کاویته ندارند.\n\n"
    "**حالا بیمار در کدام مرحله‌ی الگوریتم است؟**\n\n"
    "**گام اول (سه اسمیر) انجام شده. گام آنتی‌بیوتیک هم انجام شده و بی‌نتیجه بوده.**\n\n"
    "**دقیقاً همین «بی‌نتیجه بودن» است که ارزش دارد:** اگر پنومونی باکتریایی معمولی "
    "بود، دو هفته آنتی‌بیوتیک آن را بهبود می‌داد. **نبود پاسخ، احتمال سل را بالاتر "
    "می‌برد، نه پایین‌تر.**\n\n"
    "**پس گام بعدی: تکرار سه نوبت اسمیر خلط.**\n\n"
    "**چرا تکرار اسمیر منطقی است و صرفاً تکرار بی‌فایده‌ی کار قبلی نیست؟**\n\n"
    "**۱. دفع باسیل متناوب است** — همان بیمار ممکن است هفته‌ی بعد مثبت شود.\n\n"
    "**۲. بیماری پیشرفت کرده** — دو هفته گذشته و بار باسیلی افزایش یافته.\n\n"
    "**۳. کیفیت نمونه** — بسیاری از «اسمیر منفی»ها در واقع نمونه‌ی بزاق بوده‌اند، نه "
    "خلط. تکرار با آموزش درست، نمونه‌ی بهتری می‌دهد.\n\n"
    "**۴. و مهم‌تر از همه: این گام ارزان، سریع و غیرتهاجمی است.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**PCR روی خلط** — گزینه‌ی خوبی است و در راهنمای امروزی جایگاه بالایی دارد "
    "(به‌ویژه Xpert MTB/RIF). ولی در **الگوریتم مرحله‌ای کشوری**، پس از تکرار اسمیر "
    "می‌آید، نه پیش از آن؛ و در بسیاری از مراکز محیطی در دسترس نیست.\n\n"
    "**برونکوسکوپی و لاواژ** — **تهاجمی است** و برای وقتی نگه داشته می‌شود که "
    "روش‌های غیرتهاجمی شکست خورده باشند. پرش از اسمیر مکرر به برونکوسکوپی، "
    "پله‌ای را جا انداختن است.\n\n"
    "⚠️ **شروع درمان ضدسل با تشخیص سل اسمیر منفی** — این آخرین گام الگوریتم است، نه "
    "گام بعدی. **شروع شش ماه درمان چهاردارویی بدون تلاش بیشتر برای اثبات، هم بیمار "
    "را در معرض سمّیت قرار می‌دهد و هم تشخیص‌های دیگر (کانسر، برونشکتازی، "
    "آسپرژیلوز) را پنهان می‌کند.**",
    "This is one of the most frequently repeated patterns in the pre-internship examination, and its answer is purely algorithmic.\n\n"
    "THE PATIENT: a 45-year-old man with a history of imprisonment, productive cough for two months, weight loss and night sweats. Three sputum smears negative. Two weeks of antibiotics have made no difference.\n\n"
    "THE PROBABILITY OF TUBERCULOSIS HERE IS VERY HIGH: prison (a crowded, high-risk setting) plus a two-month cough plus weight loss plus night sweats. ALL FOUR ARE ON THE SCREENING LIST.\n\n"
    "WARNING: SO WHY ARE THE SMEARS NEGATIVE? BECAUSE THE SMEAR IS NOT A SENSITIVE TEST. It needs about 10,000 BACILLI PER MILLILITRE of sputum to turn positive. Its overall sensitivity in pulmonary tuberculosis is 50 TO 60 %. That means NEARLY HALF OF ALL TUBERCULOSIS PATIENTS ARE SMEAR-NEGATIVE, especially those without a cavity.\n\n"
    "SO WHERE IN THE ALGORITHM IS THIS PATIENT?\n\n"
    "STEP ONE (three smears) is done. The antibiotic trial is also done, and it failed.\n\n"
    "AND IT IS PRECISELY THAT FAILURE THAT CARRIES INFORMATION: if this were an ordinary bacterial pneumonia, two weeks of antibiotics would have improved it. THE ABSENCE OF RESPONSE RAISES THE PROBABILITY OF TUBERCULOSIS, IT DOES NOT LOWER IT.\n\n"
    "SO THE NEXT STEP IS: REPEAT THREE SPUTUM SMEARS.\n\n"
    "WHY IS REPEATING THE SMEAR SENSIBLE RATHER THAN a pointless repetition?\n\n"
    "1. SHEDDING IS INTERMITTENT — the same patient may be positive next week.\n\n"
    "2. THE DISEASE HAS PROGRESSED — two weeks have passed and the bacillary load has risen.\n\n"
    "3. SPECIMEN QUALITY — many 'negative smears' were in fact saliva rather than sputum. A repeat with proper coaching yields a better specimen.\n\n"
    "4. AND ABOVE ALL: this step is cheap, fast and non-invasive.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "SPUTUM PCR — a good option, and one that ranks high in today's guidance (especially Xpert MTB/RIF). But in the STEPWISE NATIONAL ALGORITHM it comes after repeat smears, not before them, and in many peripheral centres it is not available.\n\n"
    "BRONCHOSCOPY AND LAVAGE — INVASIVE, and reserved for when non-invasive methods have failed. Jumping from smear straight to bronchoscopy skips a rung.\n\n"
    "WARNING: STARTING ANTITUBERCULOUS TREATMENT AS SMEAR-NEGATIVE TUBERCULOSIS — this is the LAST step of the algorithm, not the next one. STARTING SIX MONTHS OF FOUR-DRUG THERAPY WITHOUT FURTHER ATTEMPTS AT PROOF BOTH EXPOSES THE PATIENT TO TOXICITY AND CONCEALS OTHER DIAGNOSES (cancer, bronchiectasis, aspergillosis).",
    ["پاسخ صحیح — دفع باسیل متناوب است، بیماری پیشرفت کرده، و این گام ارزان و غیرتهاجمی است.",
     "آزمون خوبی است ولی در الگوریتم کشوری پس از تکرار اسمیر می‌آید و همه‌جا در دسترس نیست.",
     "تهاجمی است و برای شکست روش‌های غیرتهاجمی نگه داشته می‌شود.",
     "آخرین گام الگوریتم است، نه گام بعدی؛ زودهنگام شروع کردن تشخیص‌های دیگر را پنهان می‌کند."],
    ["Correct — shedding is intermittent, the disease has progressed, and this step is cheap and non-invasive.",
     "A good test, but in the national algorithm it comes after repeat smears and is not universally available.",
     "Invasive, and reserved for failure of non-invasive methods.",
     "The last step of the algorithm, not the next one; starting early conceals other diagnoses."],
    "**اسمیر منفی سل را رد نمی‌کند؛ تکرار اسمیر ارزان‌ترین گام بعدی است.**",
    "A negative smear does not exclude tuberculosis; repeating the smear is the cheapest next step.",
    REFSW)

add("book:216", "vignette", "medium",
    "**سرفه‌ی یک‌ماهه که به دو آنتی‌بیوتیک پاسخ نداده: خلط را سه نوبت برای سل بفرست.**",
    "A one-month cough unresponsive to two antibiotics: send three sputum specimens for tuberculosis.",
    ALGO_FA, ALGO_EN,
    "این سؤال ساده به‌نظر می‌رسد ولی یک تله‌ی مهم دارد که بسیاری در آن می‌افتند.\n\n"
    "**بیمار: ۳۰ ساله با سرفه‌ی یک‌ماهه. حال عمومی خوب. تحت درمان آلرژی قرار گرفته و "
    "یک دوره آزیترومایسین و کوآموکسی‌کلاو گرفته، بدون بهبودی.**\n\n"
    "**دو نکته را کنار هم بگذارید:**\n\n"
    "**۱. سرفه‌ی بیش از دو هفته** — این به‌تنهایی بیمار را وارد تعریف «مشکوک به سل» "
    "در برنامه‌ی کشوری می‌کند. **یک ماه یعنی دو برابر آستانه.**\n\n"
    "**۲. عدم پاسخ به دو آنتی‌بیوتیک مناسب** — آزیترومایسین (پوشش آتیپیک) و "
    "کوآموکسی‌کلاو (پوشش پنوموکوک و هموفیلوس) دو دوره‌ی معقول‌اند. **شکست هر دو، "
    "علت باکتریایی معمول را کنار می‌گذارد.**\n\n"
    "⚠️ **و «حال عمومی خوب» نباید شما را گمراه کند.** سل ریوی می‌تواند ماه‌ها با "
    "حال عمومی نسبتاً خوب پیش برود. **دقیقاً همین است که آن را خطرناک می‌کند:** بیمار "
    "کار می‌کند، در اتوبوس می‌نشیند، و باسیل را پخش می‌کند.\n\n"
    "**پس اولویت روشن است: بررسی خلط از نظر TB در سه نوبت.**\n\n"
    "**چرا «سه نوبت» و نه یک نوبت؟** چون **دفع باسیل متناوب است**. یک نمونه حساسیت "
    "را حدود ۵۰ تا ۶۰٪ می‌دهد؛ سه نمونه‌ی متوالی (ترجیحاً شامل نمونه‌ی صبحگاهی) آن را "
    "به‌طور معناداری بالا می‌برد. **این ارزان‌ترین افزایش حساسیت در تمام پزشکی "
    "تنفسی است.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**CT اسکن ریه** — گران است، اشعه می‌دهد، و **پیش از آزمون میکروبیولوژیک ساده** "
    "منطقی نیست. به‌علاوه CT هرگز تشخیص قطعی سل نمی‌دهد؛ فقط شک را بیشتر یا کمتر "
    "می‌کند.\n\n"
    "⚠️ **شروع پردنیزولون خوراکی** — **خطرناک‌ترین گزینه‌ی این سؤال.** فرض ضمنی‌اش این "
    "است که علت، آسم یا التهاب آلرژیک است. ولی **اگر بیمار سل داشته باشد، "
    "کورتیکواستروئید سیستمیک ایمنی سلولی را سرکوب می‌کند و بیماری را منتشر می‌کند.** "
    "این دقیقاً همان اشتباهی است که در عمل بالینی به سل میلیاری ختم می‌شود.\n\n"
    "**ESR، CRP، CBC** — همه غیراختصاصی‌اند. ESR بالا در صدها بیماری دیده می‌شود و "
    "ESR طبیعی هم سل را رد نمی‌کند. **آزمونی که نه تأیید می‌کند و نه رد، اولویت "
    "نیست.**\n\n"
    "**درس روش‌شناختی: وقتی یک تشخیص خطرناک و قابل‌درمان در فهرست است، آزمون "
    "اختصاصی همان تشخیص را اول انجام دهید — نه آزمون‌های عمومی را.**",
    "This question looks simple but hides an important trap that many fall into.\n\n"
    "THE PATIENT: 30 years old with a one-month cough. GOOD GENERAL CONDITION. Treated for allergy and given a course of azithromycin and co-amoxiclav, with no improvement.\n\n"
    "PUT TWO FACTS TOGETHER:\n\n"
    "1. A COUGH LASTING MORE THAN TWO WEEKS — this alone brings the patient inside the national programme's definition of a presumptive tuberculosis case. ONE MONTH IS DOUBLE THE THRESHOLD.\n\n"
    "2. FAILURE OF TWO APPROPRIATE ANTIBIOTICS — azithromycin (atypical cover) and co-amoxiclav (pneumococcal and Haemophilus cover) are two reasonable courses. THE FAILURE OF BOTH SETS ASIDE THE ORDINARY BACTERIAL CAUSES.\n\n"
    "WARNING: AND 'GOOD GENERAL CONDITION' MUST NOT MISLEAD YOU. Pulmonary tuberculosis can run for months with a relatively well-looking patient. THAT IS EXACTLY WHAT MAKES IT DANGEROUS: the patient works, rides the bus, and spreads the bacillus.\n\n"
    "SO THE PRIORITY IS CLEAR: EXAMINE THE SPUTUM FOR TUBERCULOSIS ON THREE OCCASIONS.\n\n"
    "WHY 'THREE' AND NOT ONE? Because SHEDDING IS INTERMITTENT. One specimen gives a sensitivity of about 50 to 60 %; three consecutive specimens (preferably including an early-morning one) raise it substantially. THIS IS THE CHEAPEST GAIN IN SENSITIVITY IN ALL OF RESPIRATORY MEDICINE.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "CHEST CT — expensive, irradiating, and illogical BEFORE a simple microbiological test. Besides, CT never makes the diagnosis; it only raises or lowers suspicion.\n\n"
    "WARNING: STARTING ORAL PREDNISOLONE — THE MOST DANGEROUS OPTION HERE. Its implicit assumption is that the cause is asthma or allergic inflammation. But IF THE PATIENT HAS TUBERCULOSIS, A SYSTEMIC CORTICOSTEROID SUPPRESSES CELL-MEDIATED IMMUNITY AND DISSEMINATES THE DISEASE. This is precisely the mistake that ends in miliary tuberculosis in real practice.\n\n"
    "ESR, CRP, CBC — all non-specific. A raised ESR occurs in hundreds of diseases and a normal ESR does not exclude tuberculosis. A TEST THAT NEITHER CONFIRMS NOR EXCLUDES IS NOT A PRIORITY.\n\n"
    "THE METHODOLOGICAL LESSON: when a dangerous and treatable diagnosis is on the list, do the test SPECIFIC TO THAT DIAGNOSIS first — not the general ones.",
    ["گران و پرتوزا است و پیش از آزمون میکروبیولوژیک ساده منطقی نیست؛ تشخیص قطعی هم نمی‌دهد.",
     "پاسخ صحیح — سرفه‌ی یک‌ماهه و شکست دو آنتی‌بیوتیک، بیمار را مشکوک به سل می‌کند.",
     "خطرناک‌ترین گزینه؛ کورتون سیستمیک در سل تشخیص‌داده‌نشده بیماری را منتشر می‌کند.",
     "همه غیراختصاصی‌اند؛ نه سل را تأیید می‌کنند و نه رد."],
    ["Expensive and irradiating, illogical before a simple microbiological test, and never diagnostic.",
     "Correct — a one-month cough plus failure of two antibiotics makes this a presumptive tuberculosis case.",
     "The most dangerous option; a systemic corticosteroid in undiagnosed tuberculosis disseminates the disease.",
     "All non-specific; they neither confirm nor exclude tuberculosis."],
    "**سرفه‌ی بیش از دو هفته که به آنتی‌بیوتیک پاسخ نمی‌دهد، تا خلاف آن ثابت نشود سل است.**",
    "A cough over two weeks that does not respond to antibiotics is tuberculosis until proved otherwise.",
    REFSW)

add("book:218", "vignette", "medium",
    "**سرفه‌ی دوماهه با کاهش وزن در معتاد: نخستین اقدام، سه اسمیر خلط است.**",
    "A two-month cough with weight loss in a drug user: the first step is three sputum smears.",
    ALGO_FA, ALGO_EN,
    "این سؤال همان الگوریتم است، ولی با یک گمراه‌کننده‌ی رادیولوژیک.\n\n"
    "**بیمار: آقای ۲۷ ساله با سرفه‌ی طول‌کشیده از دو ماه قبل، چند نوبت مراجعه‌ی "
    "سرپایی با بهبود مختصر پس از شربت دکسترومتورفان، معتاد به مواد روان‌گردان، "
    "کاهش وزن قابل توجه. در رادیوگرافی، ضایعه‌ای به نفع برونکوپنومونی.**\n\n"
    "**سه عامل خطر و دو نشانه، همه در یک جهت:**\n\n"
    "**سرفه‌ی دوماهه** ✔ (چهار برابر آستانه‌ی دو هفته) · **کاهش وزن قابل توجه** ✔ · "
    "**اعتیاد** ✔ (عامل خطر مستقل با افزایش ۱۰ تا ۳۰ برابری، به‌علاوه احتمال HIV "
    "همراه) · **بهبود موقت با ضدسرفه** — که یعنی هیچ درمان مؤثری دریافت نکرده است.\n\n"
    "⚠️ **حالا تله: «ضایعه به نفع برونکوپنومونی».** بسیاری این را می‌بینند و به سراغ "
    "درمان آنتی‌بیوتیکی می‌روند. ولی **رادیوگرافی سل ریوی می‌تواند دقیقاً شبیه "
    "برونکوپنومونی باشد** — و در معتادان و در بیماران HIV مثبت، تابلوی کلاسیک "
    "کاویته‌ی قله اغلب **وجود ندارد**.\n\n"
    "**قاعده‌ی طلایی: در بیمار با سرفه‌ی مزمن و کاهش وزن، رادیوگرافی هرگز نمی‌تواند سل "
    "را رد کند. فقط میکروبیولوژی می‌تواند.**\n\n"
    "**پس نخستین اقدام: درخواست اسمیر خلط و رنگ‌آمیزی اسیدفست در سه نوبت.**\n\n"
    "**و یک دلیل اضافه که فقط در این بیمار وجود دارد: کنترل عفونت.** اگر این بیمار "
    "اسمیر مثبت باشد، **مسری است** و باید فوراً جدا شود. هر روز تأخیر یعنی مواجهه‌ی "
    "بیشتر برای خانواده و کادر درمان. **اسمیر تنها آزمونی است که هم تشخیص می‌دهد و "
    "هم درجه‌ی سرایت را تعیین می‌کند.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**برونکوسکوپی** — تهاجمی است و به‌عنوان **نخستین** اقدام هرگز جایی ندارد. "
    "به‌علاوه در بیمار اسمیر مثبتِ تشخیص‌داده‌نشده، برونکوسکوپی یک **پروسیجر "
    "آئروسل‌ساز** است و کادر اتاق را در معرض خطر جدی قرار می‌دهد.\n\n"
    "**سی‌تی‌اسکن توراکس** — گران، پرتوزا، و بازهم غیرتشخیصی. ضایعه را دقیق‌تر نشان "
    "می‌دهد ولی نمی‌گوید داخلش چیست.\n\n"
    "**آموکسی‌سیلین/کلاولانیک اسید** — در الگوریتم جایگاه دارد، ولی **پس از** "
    "فرستادن اسمیر، نه به‌جای آن. در بیمار با این‌همه عامل خطر، فرستادن اسمیر یک "
    "کار موازی و ارزان است که هیچ دلیلی برای تأخیرش وجود ندارد.",
    "This is the same algorithm, but with a radiological decoy.\n\n"
    "THE PATIENT: a 27-year-old man with a prolonged cough for two months, several outpatient visits with slight improvement after a dextromethorphan syrup, addicted to psychoactive drugs, with substantial weight loss. The radiograph shows a lesion reported as bronchopneumonia.\n\n"
    "THREE RISK FACTORS AND TWO SYMPTOMS, ALL POINTING ONE WAY:\n\n"
    "TWO-MONTH COUGH (four times the two-week threshold), SUBSTANTIAL WEIGHT LOSS, DRUG ADDICTION (an independent 10- to 30-fold risk factor, plus the possibility of co-existing HIV), and temporary relief with a cough suppressant — which means he has received no effective treatment at all.\n\n"
    "WARNING, NOW THE TRAP: 'A LESION SUGGESTING BRONCHOPNEUMONIA'. Many see this and reach for antibiotics. But THE RADIOGRAPH OF PULMONARY TUBERCULOSIS CAN LOOK EXACTLY LIKE BRONCHOPNEUMONIA — and in drug users and HIV-positive patients the classic apical cavity is often ABSENT.\n\n"
    "THE GOLDEN RULE: IN A PATIENT WITH CHRONIC COUGH AND WEIGHT LOSS, A RADIOGRAPH CAN NEVER EXCLUDE TUBERCULOSIS. ONLY MICROBIOLOGY CAN.\n\n"
    "SO THE FIRST STEP IS: REQUEST SPUTUM SMEAR AND ACID-FAST STAINING ON THREE OCCASIONS.\n\n"
    "AND ONE EXTRA REASON THAT APPLIES ONLY TO THIS PATIENT: INFECTION CONTROL. If he is smear-positive he IS INFECTIOUS and must be isolated at once. Every day of delay means more exposure for his family and for the staff. THE SMEAR IS THE ONLY TEST THAT BOTH MAKES THE DIAGNOSIS AND GRADES THE INFECTIOUSNESS.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "BRONCHOSCOPY — invasive and never a FIRST step. Moreover, in an undiagnosed smear-positive patient, bronchoscopy is an AEROSOL-GENERATING PROCEDURE that puts the whole room at serious risk.\n\n"
    "CHEST CT — expensive, irradiating, and again non-diagnostic. It shows the lesion more precisely but does not say what is inside it.\n\n"
    "AMOXICILLIN/CLAVULANIC ACID — it has a place in the algorithm, but AFTER sending the smear, not instead of it. In a patient with this many risk factors, sending a smear is a cheap parallel action with no reason to delay it.",
    ["تهاجمی و آئروسل‌ساز است؛ به‌عنوان نخستین اقدام جایی ندارد.",
     "گران و پرتوزا و بازهم غیرتشخیصی؛ نمی‌گوید داخل ضایعه چیست.",
     "در الگوریتم جایگاه دارد ولی پس از فرستادن اسمیر، نه به‌جای آن.",
     "پاسخ صحیح — سرفه‌ی دوماهه با کاهش وزن در معتاد؛ اسمیر هم تشخیص می‌دهد هم سرایت را."],
    ["Invasive and aerosol-generating; it has no place as a first step.",
     "Expensive, irradiating and still non-diagnostic; it does not say what is inside the lesion.",
     "It has a place in the algorithm, but after sending the smear, not instead of it.",
     "Correct — a two-month cough with weight loss in a drug user; the smear gives both diagnosis and infectiousness."],
    "**رادیوگرافی هرگز سل را رد نمی‌کند؛ فقط میکروبیولوژی می‌تواند.**",
    "A radiograph never excludes tuberculosis; only microbiology can.",
    REFSW)

add("book:223", "recall", "medium",
    "**سه اسمیر منفی: نخست یک دوره آنتی‌بیوتیک — ولی هرگز فلوروکینولون نه.**",
    "Three negative smears: first a course of antibiotics — but never a fluoroquinolone.",
    ALGO_FA, ALGO_EN,
    "این سؤال دقیقاً همان الگوریتم را از **نقطه‌ی شروع** می‌پرسد، و یک نکته‌ی حیاتی "
    "دارد که در گزینه‌ها پنهان است.\n\n"
    "**بیمار: مراجعه به مرکز مبارزه با سل به علت سرفه‌ی مزمن. سه نوبت اسمیر خلط "
    "منفی. مرکز، بیمار را به شما ارجاع داده است. در اولین مرحله چه می‌کنید؟**\n\n"
    "**پاسخ: شروع یک دوره درمان آنتی‌بیوتیک.**\n\n"
    "**چرا این گام اول است؟ منطقش دو بخش دارد:**\n\n"
    "**۱. بخش تشخیصی.** شایع‌ترین علت سرفه‌ی مزمن با اسمیر منفی، **عفونت باکتریایی "
    "معمولی** است. یک دوره‌ی ۱۰ تا ۱۴ روزه‌ی آنتی‌بیوتیک وسیع‌الطیف، این گروه بزرگ را "
    "**حذف** می‌کند. **کسانی که بهبود می‌یابند، بررسی بیشتر نمی‌خواهند؛ کسانی که بهبود "
    "نمی‌یابند، احتمال سلشان به‌شدت بالا می‌رود.** این یک آزمون درمانی است، نه یک "
    "درمان کورکورانه.\n\n"
    "**۲. بخش عملی.** در دو هفته‌ای که آنتی‌بیوتیک می‌خورد، **کشت خلط در حال رشد "
    "است** و اگر Xpert فرستاده شده باشد، جوابش می‌رسد. یعنی زمان تلف نمی‌شود.\n\n"
    "⚠️ **و حالا مهم‌ترین نکته‌ی این درسنامه، که سؤال آن را نمی‌پرسد ولی بالین "
    "می‌پرسد:**\n\n"
    "**در این دوره‌ی آزمایشی هرگز فلوروکینولون ندهید.**\n\n"
    "**چرا؟** چون **لووفلوکساسین و موکسی‌فلوکساسین داروهای ضدسل مؤثری هستند** — "
    "آن‌قدر مؤثر که در رژیم‌های MDR-TB ستون فقرات درمان‌اند. اگر به بیمار مسلولِ "
    "تشخیص‌داده‌نشده لووفلوکساسین بدهید، **سه اتفاق بد با هم می‌افتد:**\n\n"
    "**الف) بهبود موقتی و فریبنده** — شما فکر می‌کنید پنومونی بوده و پرونده را "
    "می‌بندید.\n\n"
    "**ب) اسمیر و کشت بعدی منفی می‌شوند** — تشخیص هفته‌ها یا ماه‌ها عقب می‌افتد.\n\n"
    "**ج) مقاومت به فلوروکینولون ساخته می‌شود** — و همان دارویی که ممکن بود بعداً "
    "جان بیمار را در MDR-TB نجات دهد، از دست می‌رود.\n\n"
    "**پس آنتی‌بیوتیک انتخابی: آموکسی‌سیلین/کلاولانات، یا کوتریموکسازول، یا "
    "داکسی‌سیکلین — نه کینولون.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**تکرار آزمایش مستقیم خلط** — گام درستی است ولی **گام دوم**، پس از شکست "
    "آنتی‌بیوتیک. تکرار فوری بدون فاصله‌ی زمانی، احتمال کمی برای تغییر نتیجه دارد.\n\n"
    "**CT اسکن ریه** — گران، و در این مرحله تغییری در تصمیم نمی‌دهد.\n\n"
    "**انتظار برای جواب کشت** — **انتظار منفعل، بدترین گزینه است.** کشت روی محیط جامد "
    "۲ تا ۶ هفته طول می‌کشد. در این مدت بیمار درمان‌نشده می‌ماند و اگر عفونت "
    "باکتریایی داشته باشد، بی‌جهت رنج می‌برد.",
    "This question asks about the same algorithm from ITS STARTING POINT, and it carries a vital point hidden in the options.\n\n"
    "THE PATIENT: referred to the tuberculosis centre for chronic cough. Three sputum smears negative. The centre has referred him to you. What do you do first?\n\n"
    "THE ANSWER: START A COURSE OF ANTIBIOTICS.\n\n"
    "WHY IS THIS THE FIRST STEP? THE LOGIC HAS TWO PARTS:\n\n"
    "1. THE DIAGNOSTIC PART. The commonest cause of chronic cough with a negative smear is AN ORDINARY BACTERIAL INFECTION. A 10- to 14-day course of a broad-spectrum antibiotic REMOVES that large group. THOSE WHO IMPROVE NEED NO FURTHER WORK-UP; THOSE WHO DO NOT IMPROVE HAVE A SHARPLY HIGHER PROBABILITY OF TUBERCULOSIS. This is a therapeutic test, not blind treatment.\n\n"
    "2. THE PRACTICAL PART. During the two weeks on antibiotics, THE SPUTUM CULTURE IS GROWING, and if an Xpert was sent its result arrives. No time is wasted.\n\n"
    "WARNING, AND NOW THE MOST IMPORTANT POINT IN THIS LESSON, which the question does not ask but the bedside does:\n\n"
    "NEVER USE A FLUOROQUINOLONE FOR THAT TRIAL.\n\n"
    "WHY? Because LEVOFLOXACIN AND MOXIFLOXACIN ARE EFFECTIVE ANTITUBERCULOUS DRUGS — so effective that they form the backbone of MDR-TB regimens. Give levofloxacin to an undiagnosed tuberculosis patient and THREE BAD THINGS HAPPEN AT ONCE:\n\n"
    "(a) TEMPORARY, DECEPTIVE IMPROVEMENT — you conclude it was pneumonia and close the case.\n\n"
    "(b) SUBSEQUENT SMEARS AND CULTURES TURN NEGATIVE — the diagnosis is delayed by weeks or months.\n\n"
    "(c) FLUOROQUINOLONE RESISTANCE IS BRED — and the very drug that might later have saved the patient in MDR-TB is lost.\n\n"
    "SO THE ANTIBIOTIC OF CHOICE IS: amoxicillin/clavulanate, or co-trimoxazole, or doxycycline — NOT a quinolone.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "REPEATING THE DIRECT SPUTUM EXAMINATION — a correct step, but the SECOND one, after the antibiotic has failed. An immediate repeat with no interval is unlikely to change the result.\n\n"
    "CHEST CT — expensive, and at this stage it changes no decision.\n\n"
    "WAITING FOR THE CULTURE RESULT — PASSIVE WAITING IS THE WORST OPTION. Culture on solid medium takes 2 to 6 weeks. Meanwhile the patient goes untreated and, if he has a bacterial infection, suffers needlessly.",
    ["پاسخ صحیح — یک دوره آنتی‌بیوتیک وسیع‌الطیف (نه فلوروکینولون) گروه باکتریایی معمول را حذف می‌کند.",
     "گام درستی است ولی گام دوم، پس از شکست آنتی‌بیوتیک.",
     "گران است و در این مرحله تصمیم را تغییر نمی‌دهد.",
     "انتظار منفعل بدترین گزینه است؛ کشت جامد ۲ تا ۶ هفته طول می‌کشد."],
    ["Correct — a broad-spectrum antibiotic course (never a fluoroquinolone) removes the ordinary bacterial group.",
     "A correct step, but the second one, after the antibiotic has failed.",
     "Expensive, and at this stage it changes no decision.",
     "Passive waiting is the worst option; solid culture takes 2 to 6 weeks."],
    "**در آزمون درمانی سرفه‌ی مزمن، هرگز فلوروکینولون ندهید — تشخیص را می‌پوشاند و مقاومت می‌سازد.**",
    "In the therapeutic trial for chronic cough, never use a fluoroquinolone — it masks the diagnosis and breeds resistance.",
    REFSW)

# ============================================== PREGNANCY DIAGNOSIS
PREG_DX_FA = [
    "⚠️ **در بارداری، اصل تشخیصی عوض نمی‌شود: اسمیر خلط همچنان گام اول است.**",
    "**چون اسمیر هیچ خطری برای جنین ندارد.**",
    "**نه اشعه دارد، نه دارو، نه تزریق.**",
    "**و سل درمان‌نشده در بارداری بسیار خطرناک‌تر از هر آزمون تشخیصی است.**",
    "**خطرها: زایمان زودرس، وزن کم هنگام تولد، و مرگ‌ومیر مادری بیشتر.**",
    "**پس تأخیر در تشخیص، خودش بزرگ‌ترین خطر است.**",
    "⚠️ **و رادیوگرافی هم در بارداری ممنوع نیست — با محافظ شکمی مجاز است.**",
    "**دوز جنینی گرافی قفسه‌ی سینه با محافظ، ناچیز است.**",
    "**ولی باز هم اسمیر مقدم است، چون تشخیص قطعی می‌دهد و گرافی نمی‌دهد.**",
    "**تست PPD در بارداری بی‌خطر است ولی بیماری فعال را تشخیص نمی‌دهد.**",
    "**کشت لازم است ولی هفته‌ها طول می‌کشد؛ گام اول نیست.**",
    "**و درمان: ایزونیازید، ریفامپین و اتامبوتول در بارداری بی‌خطرند.**",
]
PREG_DX_EN = [
    "WARNING: IN PREGNANCY THE DIAGNOSTIC PRINCIPLE DOES NOT CHANGE — sputum smear is still the first step.",
    "Because a smear carries no risk whatever to the fetus.",
    "No radiation, no drug, no injection.",
    "And untreated tuberculosis in pregnancy is far more dangerous than any diagnostic test.",
    "The risks: preterm delivery, low birth weight, and higher maternal mortality.",
    "So delay in diagnosis is itself the greatest danger.",
    "WARNING, AND RADIOGRAPHY IS NOT FORBIDDEN IN PREGNANCY EITHER — it is permitted with abdominal shielding.",
    "The fetal dose from a shielded chest film is negligible.",
    "But the smear still comes first, because it is diagnostic and the film is not.",
    "The tuberculin test is safe in pregnancy but does not diagnose active disease.",
    "Culture is necessary but takes weeks; it is not the first step.",
    "And for treatment: isoniazid, rifampicin and ethambutol are all safe in pregnancy.",
]

add("book:219", "vignette", "medium",
    "**زن باردار با سرفه‌ی یک‌ماهه: اسمیر خلط، همان گام اول همیشگی.**",
    "A pregnant woman with a one-month cough: sputum smear, the same first step as always.",
    PREG_DX_FA, PREG_DX_EN,
    "این سؤال می‌سنجد که آیا بارداری، الگوریتم شما را بی‌جهت تغییر می‌دهد یا نه.\n\n"
    "**بیمار: خانم ۳۰ ساله‌ی باردار در هفته‌ی بیست‌وپنجم، با ضعف، بی‌حالی، کاهش اشتها "
    "و سرفه از یک ماه قبل. در معاینه T=37/8 و سمع ریه طبیعی.**\n\n"
    "**اول تشخیص را بسازید:** سرفه‌ی بیش از دو هفته + کاهش اشتها + تب خفیف. **این "
    "بیمار طبق تعریف برنامه‌ی کشوری، مشکوک به سل است.**\n\n"
    "⚠️ **و «سمع ریه طبیعی» نباید شما را آرام کند.** در سل ریوی، سمع اغلب طبیعی است "
    "حتی وقتی گرافی کاویته نشان می‌دهد. **این تضاد بین معاینه‌ی فقیر و بیماری وسیع، "
    "خودش یکی از ویژگی‌های شناخته‌شده‌ی سل است.**\n\n"
    "**حالا سؤال واقعی: آیا بارداری چیزی را عوض می‌کند؟**\n\n"
    "**پاسخ: نه در گام اول. اسمیر خلط همچنان مناسب‌ترین اقدام تشخیصی است.**\n\n"
    "**دلیلش سه بخش دارد:**\n\n"
    "**۱. اسمیر مطلقاً بی‌خطر است.** بیمار در یک ظرف سرفه می‌کند. **نه اشعه، نه دارو، "
    "نه تزریق، نه هیچ مواجهه‌ای برای جنین.** هیچ دلیلی برای تردید وجود ندارد.\n\n"
    "**۲. خطر واقعی، تأخیر است — نه آزمون.** سل درمان‌نشده در بارداری با **زایمان "
    "زودرس، وزن کم هنگام تولد، محدودیت رشد داخل‌رحمی و افزایش مرگ‌ومیر مادری** همراه "
    "است. **هر هفته تأخیر در تشخیص، این خطرها را بیشتر می‌کند.**\n\n"
    "**۳. اسمیر تنها آزمونی است که هم تشخیص می‌دهد و هم می‌گوید بیمار مسری هست یا "
    "نه** — که برای برنامه‌ریزی زایمان و مراقبت از نوزاد حیاتی است.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**تست PPD** — در بارداری بی‌خطر است، ولی **عفونت را نشان می‌دهد نه بیماری فعال "
    "را**. در کشور اندمیک، بخش بزرگی از بزرگسالان PPD مثبت دارند. **و مهم‌تر: PPD "
    "منفی هم سل فعال را رد نمی‌کند** (در سل شدید و در بیماری‌های همراه، آنرژی رخ "
    "می‌دهد).\n\n"
    "**کشت خلط** — **ضروری است، ولی گام اول نیست.** ۲ تا ۶ هفته طول می‌کشد. در عمل، "
    "کشت را **هم‌زمان با اسمیر** می‌فرستید؛ ولی اگر مجبور به انتخاب یکی باشید، "
    "اسمیر جواب امروز را می‌دهد.\n\n"
    "**برونکوسکوپی** — تهاجمی، نیازمند آرام‌بخش، و در بارداری با احتیاط بیشتر. "
    "**به‌عنوان گام اول کاملاً نامناسب است.**\n\n"
    "**نکته‌ی تکمیلی برای بالین: اگر گرافی لازم شد، بارداری مانع نیست. با محافظ "
    "شکمی، دوز جنینی ناچیز است. ترس بی‌مورد از گرافی در بارداری، سالانه تشخیص‌های "
    "زیادی را به تأخیر می‌اندازد.**",
    "This question tests whether pregnancy needlessly changes your algorithm.\n\n"
    "THE PATIENT: a 30-year-old woman at 25 weeks' gestation with weakness, malaise, loss of appetite and a cough for one month. On examination her temperature is 37.8 and the chest is CLEAR ON AUSCULTATION.\n\n"
    "FIRST BUILD THE DIAGNOSIS: a cough over two weeks plus anorexia plus low-grade fever. BY THE NATIONAL PROGRAMME'S DEFINITION THIS IS A PRESUMPTIVE TUBERCULOSIS CASE.\n\n"
    "WARNING: AND A CLEAR CHEST MUST NOT REASSURE YOU. In pulmonary tuberculosis auscultation is often normal even when the film shows a cavity. THAT CONTRAST BETWEEN A POOR EXAMINATION AND EXTENSIVE DISEASE IS ITSELF A RECOGNISED FEATURE.\n\n"
    "NOW THE REAL QUESTION: DOES PREGNANCY CHANGE ANYTHING?\n\n"
    "THE ANSWER: NOT AT THE FIRST STEP. SPUTUM SMEAR REMAINS THE MOST APPROPRIATE DIAGNOSTIC ACTION.\n\n"
    "THE REASON HAS THREE PARTS:\n\n"
    "1. A SMEAR IS ABSOLUTELY HARMLESS. The patient coughs into a pot. NO RADIATION, NO DRUG, NO INJECTION, NO FETAL EXPOSURE OF ANY KIND. There is nothing to hesitate about.\n\n"
    "2. THE REAL DANGER IS DELAY, NOT THE TEST. Untreated tuberculosis in pregnancy carries PRETERM DELIVERY, LOW BIRTH WEIGHT, INTRAUTERINE GROWTH RESTRICTION AND INCREASED MATERNAL MORTALITY. EVERY WEEK OF DIAGNOSTIC DELAY INCREASES THOSE RISKS.\n\n"
    "3. THE SMEAR IS THE ONLY TEST THAT BOTH DIAGNOSES AND TELLS YOU WHETHER SHE IS INFECTIOUS — which is vital for planning the delivery and the care of the newborn.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "TUBERCULIN TEST — safe in pregnancy, but IT SHOWS INFECTION, NOT ACTIVE DISEASE. In an endemic country a large fraction of adults are PPD-positive. AND MORE IMPORTANTLY, A NEGATIVE PPD DOES NOT EXCLUDE ACTIVE TUBERCULOSIS EITHER (anergy occurs in severe disease and with comorbidity).\n\n"
    "SPUTUM CULTURE — ESSENTIAL, BUT NOT THE FIRST STEP. It takes 2 to 6 weeks. In practice you send culture ALONGSIDE the smear; but if forced to choose one, the smear answers today.\n\n"
    "BRONCHOSCOPY — invasive, requiring sedation, and needing extra caution in pregnancy. WHOLLY INAPPROPRIATE AS A FIRST STEP.\n\n"
    "A SUPPLEMENTARY POINT FOR THE BEDSIDE: if a radiograph is needed, pregnancy is not a barrier. With abdominal shielding the fetal dose is negligible. Unfounded fear of chest films in pregnancy delays many diagnoses every year.",
    ["در بارداری بی‌خطر است ولی عفونت را نشان می‌دهد نه بیماری فعال را؛ منفی بودنش هم رد نمی‌کند.",
     "پاسخ صحیح — بی‌خطر برای جنین، تشخیصی، و تعیین‌کننده‌ی سرایت؛ و تأخیر خودش خطر است.",
     "ضروری است ولی ۲ تا ۶ هفته طول می‌کشد؛ گام اول نیست.",
     "تهاجمی و نیازمند آرام‌بخش؛ به‌عنوان گام اول کاملاً نامناسب است."],
    ["Safe in pregnancy but shows infection rather than active disease; a negative result excludes nothing.",
     "Correct — harmless to the fetus, diagnostic, and it grades infectiousness; and delay is itself the danger.",
     "Essential but takes 2 to 6 weeks; not a first step.",
     "Invasive and requiring sedation; wholly inappropriate as a first step."],
    "**بارداری الگوریتم را عوض نمی‌کند؛ خطر واقعی تأخیر است، نه آزمون.**",
    "Pregnancy does not change the algorithm; the real danger is delay, not the test.",
    REFSW)

# ============================================== XPERT AND MOLECULAR TESTS
XPERT_FA = [
    "⚠️ **Xpert MTB/RIF سه کار را هم‌زمان انجام می‌دهد.**",
    "**یک: DNA مایکوباکتریوم توبرکلوزیس را شناسایی می‌کند.**",
    "**دو: مقاومت به ریفامپین را در همان آزمون گزارش می‌کند.**",
    "**سه: جواب را در کمتر از دو ساعت می‌دهد.**",
    "**حساسیتش بسیار بالاتر از اسمیر است، به‌ویژه در اسمیر منفی و در HIV.**",
    "**چون به بار باسیلی ۱۰٬۰۰۰ در میلی‌لیتر نیاز ندارد.**",
    "⚠️ **و به همین دلیل، سازمان جهانی آن را آزمون اولیه معرفی کرده، نه آزمون پشتیبان.**",
    "**در برابر آن، اورامین-رودامین فقط یک رنگ فلورسنت است.**",
    "**سریع‌تر از ذیل نلسون خوانده می‌شود ولی همچنان یک اسمیر است.**",
    "**و ذیل نلسون رنگ‌آمیزی کلاسیک اسیدفست است — ارزان، ولی کم‌حساس.**",
    "⚠️ **و IGRA (اینترفرون گاما) عفونت را نشان می‌دهد، نه بیماری فعال را.**",
    "**پس در تشخیص سل فعال در کشور اندمیک، جایی ندارد.**",
]
XPERT_EN = [
    "WARNING: XPERT MTB/RIF DOES THREE THINGS AT ONCE.",
    "One: it detects the DNA of Mycobacterium tuberculosis.",
    "Two: it reports RIFAMPICIN RESISTANCE in the same run.",
    "Three: it gives the result in under two hours.",
    "Its sensitivity is far above that of smear, especially in smear-negative disease and in HIV.",
    "Because it does not need a load of 10,000 bacilli per millilitre.",
    "WARNING, AND FOR THAT REASON WHO NOW NAMES IT THE INITIAL TEST, not a back-up.",
    "By contrast, auramine-rhodamine is only a fluorescent stain.",
    "It is read faster than Ziehl-Neelsen but it is still a smear.",
    "And Ziehl-Neelsen is the classical acid-fast stain — cheap, but insensitive.",
    "WARNING, AND IGRA (interferon gamma) SHOWS INFECTION, NOT ACTIVE DISEASE.",
    "So it has no place in diagnosing active tuberculosis in an endemic country.",
]

add("book:220", "vignette", "medium",
    "**بیمار HIV مثبت با سابقه‌ی زندان: Xpert MTB/RIF سریع‌ترین و حساس‌ترین است.**",
    "An HIV-positive patient with a prison history: Xpert MTB/RIF is the fastest and most sensitive.",
    XPERT_FA, XPERT_EN,
    "این سؤال دقیقاً می‌پرسد «کدام آزمون هم سریع‌تر است و هم حساس‌تر» — و فقط یک "
    "گزینه هر دو صفت را دارد.\n\n"
    "**بیمار: مرد HIV مثبت که یک سال گذشته را در زندان بوده، با سرفه، خلط و کاهش "
    "وزن. در بررسی، کدورت یک‌طرفه‌ی قله‌ی ریه.**\n\n"
    "**دو عامل خطر بزرگ با هم:** HIV (خطر بازفعالی حدود ۱۰٪ در سال) + زندان (محیط "
    "پرازدحام با شیوع بالای سل).\n\n"
    "**پاسخ: Xpert MTB/RIF.**\n\n"
    "**چرا؟ سه دلیل، و در این بیمار هر سه اهمیت مضاعف دارند:**\n\n"
    "**۱. سرعت.** جواب در **کمتر از دو ساعت**. اسمیر چند ساعت، ولی کشت ۲ تا ۶ هفته. "
    "در بیمار HIV مثبت که ممکن است به‌سرعت بدحال شود، این تفاوت حیاتی است.\n\n"
    "⚠️ **۲. حساسیت، به‌ویژه در HIV.** این مهم‌ترین بخش است. **در بیمار HIV مثبت، اسمیر "
    "بسیار بیشتر از حالت عادی منفی می‌شود.** دلیلش زیباست: **مثبت شدن اسمیر به کاویته "
    "نیاز دارد، و ساختن کاویته کارِ سیستم ایمنی است.** وقتی CD4 پایین می‌آید، بدن "
    "دیگر نمی‌تواند آن پاسخ نکروزان را بسازد؛ پس کاویته کمتر، باسیل کمتر در راه "
    "هوایی، و اسمیر منفی — در حالی که بیماری شدیدتر است. **Xpert به بار باسیلی بالا "
    "نیاز ندارد و همین شکاف را پر می‌کند.**\n\n"
    "**۳. مقاومت به ریفامپین در همان آزمون.** Xpert جهش‌های ژن rpoB را می‌خواند و "
    "**مقاومت به ریفامپین را در همان دو ساعت گزارش می‌کند**. چون مقاومت به ریفامپین "
    "شاخص جانشین (surrogate) MDR-TB است، این یعنی شما همان روز می‌دانید آیا رژیم "
    "استاندارد کار می‌کند یا نه. **در بیمار زندانی که در معرض سویه‌های مقاوم بوده، "
    "این اطلاعات طلاست.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**رنگ‌آمیزی اورامین-رودامین** — یک رنگ فلورسنت است که خواندن اسمیر را سریع‌تر "
    "می‌کند (میکروسکوپ با بزرگ‌نمایی کمتر، سطح بیشتر در هر ثانیه). **کمی حساس‌تر از "
    "ذیل نلسون است، ولی همچنان یک اسمیر است** و همان محدودیت ۱۰٬۰۰۰ باسیل را دارد.\n\n"
    "**Interferon Gamma (IGRA)** — ⚠️ **خطای مفهومی رایج.** IGRA **عفونت** را نشان "
    "می‌دهد، نه **بیماری فعال** را. در ایران که بخش بزرگی از بزرگسالان عفونت نهفته "
    "دارند، IGRA مثبت تقریباً هیچ چیز نمی‌گوید. **و بدتر: در HIV با CD4 پایین، IGRA "
    "می‌تواند نامعین یا منفی کاذب شود.**\n\n"
    "**رنگ‌آمیزی ذیل نلسون** — رنگ‌آمیزی کلاسیک اسیدفست. ارزان و در دسترس، ولی "
    "**کم‌حساس‌ترین گزینه‌ی این فهرست**، و دقیقاً در بیمار HIV مثبت بیشترین احتمال "
    "منفی کاذب را دارد.",
    "This question asks precisely which test is BOTH faster AND more sensitive — and only one option has both properties.\n\n"
    "THE PATIENT: an HIV-positive man who has spent the past year in prison, with cough, sputum and weight loss. Investigation shows unilateral apical opacity.\n\n"
    "TWO MAJOR RISK FACTORS TOGETHER: HIV (about a 10 % per year reactivation risk) and prison (a crowded setting with high tuberculosis prevalence).\n\n"
    "THE ANSWER: XPERT MTB/RIF.\n\n"
    "WHY? THREE REASONS, ALL OF WHICH MATTER DOUBLY IN THIS PATIENT:\n\n"
    "1. SPEED. A result IN UNDER TWO HOURS. A smear takes hours, a culture 2 to 6 weeks. In an HIV-positive patient who may deteriorate quickly, that difference is vital.\n\n"
    "WARNING, 2. SENSITIVITY, ESPECIALLY IN HIV. This is the crucial part. IN AN HIV-POSITIVE PATIENT THE SMEAR IS FAR MORE OFTEN NEGATIVE THAN USUAL. The reason is elegant: A POSITIVE SMEAR REQUIRES A CAVITY, AND BUILDING A CAVITY IS THE IMMUNE SYSTEM'S WORK. As the CD4 count falls the body can no longer mount that necrotising response; so fewer cavities, fewer bacilli in the airway, and a negative smear — while the disease is in fact more severe. XPERT DOES NOT NEED A HIGH BACILLARY LOAD AND FILLS EXACTLY THAT GAP.\n\n"
    "3. RIFAMPICIN RESISTANCE IN THE SAME RUN. Xpert reads rpoB gene mutations and REPORTS RIFAMPICIN RESISTANCE WITHIN THOSE SAME TWO HOURS. Because rifampicin resistance is the surrogate marker for MDR-TB, this means you know the same day whether the standard regimen will work. IN A PRISONER EXPOSED TO RESISTANT STRAINS, THAT INFORMATION IS GOLD.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "AURAMINE-RHODAMINE STAIN — a fluorescent stain that makes smear reading faster (lower magnification, more field per second). SLIGHTLY MORE SENSITIVE THAN ZIEHL-NEELSEN BUT STILL A SMEAR, with the same 10,000-bacilli limitation.\n\n"
    "INTERFERON GAMMA (IGRA) — WARNING, A COMMON CONCEPTUAL ERROR. IGRA shows INFECTION, not ACTIVE DISEASE. In Iran, where a large share of adults carry latent infection, a positive IGRA says almost nothing. AND WORSE: in HIV with a low CD4 count, IGRA can be indeterminate or falsely negative.\n\n"
    "ZIEHL-NEELSEN STAIN — the classical acid-fast stain. Cheap and available, but THE LEAST SENSITIVE OPTION ON THIS LIST, and precisely in an HIV-positive patient the one most likely to be falsely negative.",
    ["رنگ فلورسنت است و خواندن را سریع‌تر می‌کند ولی همچنان یک اسمیر با همان محدودیت است.",
     "عفونت نهفته را نشان می‌دهد نه بیماری فعال؛ در HIV نامعین یا منفی کاذب هم می‌شود.",
     "رنگ‌آمیزی کلاسیک و ارزان، ولی کم‌حساس‌ترین گزینه و پرخطاترین در HIV.",
     "پاسخ صحیح — جواب زیر دو ساعت، حساسیت بالا در HIV، و گزارش مقاومت به ریفامپین."],
    ["A fluorescent stain that speeds up reading, but still a smear with the same limitation.",
     "Shows latent infection rather than active disease; in HIV it can be indeterminate or falsely negative.",
     "The classical cheap stain, but the least sensitive option and the most error-prone in HIV.",
     "Correct — a result in under two hours, high sensitivity in HIV, and rifampicin resistance reported."],
    "**Xpert در دو ساعت هم تشخیص می‌دهد هم مقاومت به ریفامپین را — و در HIV جای اسمیر را پر می‌کند.**",
    "Xpert gives both the diagnosis and rifampicin resistance in two hours — and in HIV it fills the gap the smear leaves.",
    REFSW)

add("book:221", "recall", "medium",
    "**QuantiFERON آزمونی اختصاصی برای عفونت با مایکوباکتریوم توبرکلوزیس است.**",
    "QuantiFERON is a test specific for infection with Mycobacterium tuberculosis.",
    XPERT_FA + [
        "⚠️ **مزیت بزرگ IGRA بر PPD: با واکسن ب‌ث‌ژ مثبت کاذب نمی‌شود.**",
        "**چون آنتی‌ژن‌های ESAT-6 و CFP-10 در سویه‌ی واکسن وجود ندارند.**",
    ],
    XPERT_EN + [
        "WARNING: THE GREAT ADVANTAGE OF IGRA OVER PPD is that BCG does not make it falsely positive.",
        "Because the ESAT-6 and CFP-10 antigens are absent from the vaccine strain.",
    ],
    "این سؤال کوتاه، یک نکته‌ی مولکولی مهم را می‌سنجد.\n\n"
    "**QuantiFERON یک آزمون IGRA است** — یعنی **Interferon-Gamma Release Assay**. "
    "روش کارش این است: خون بیمار را با **آنتی‌ژن‌های اختصاصی مایکوباکتریوم "
    "توبرکلوزیس** مجاور می‌کنند و می‌سنجند لنفوسیت‌های T چقدر **اینترفرون گاما** آزاد "
    "می‌کنند. اگر بدن قبلاً با باسیل سل روبه‌رو شده باشد، لنفوسیت‌های حافظه پاسخ "
    "می‌دهند.\n\n"
    "**پس پاسخ: عفونت با مایکوباکتریوم توبرکلوز.**\n\n"
    "⚠️ **حالا نکته‌ای که این آزمون را ارزشمند می‌کند: کدام آنتی‌ژن‌ها؟**\n\n"
    "**ESAT-6 و CFP-10** (و در نسخه‌های جدیدتر TB7.7). **این دو پروتئین در ناحیه‌ای "
    "از ژنوم به‌نام RD1 کد می‌شوند — و آن ناحیه در سویه‌ی واکسن ب‌ث‌ژ حذف شده است.**\n\n"
    "**نتیجه‌ی عملی و بسیار مهم:**\n\n"
    "**PPD در فرد واکسینه‌شده با ب‌ث‌ژ می‌تواند مثبت کاذب شود** — مشکل بزرگی در ایران "
    "که واکسیناسیون همگانی دارد.\n\n"
    "⚠️ **ولی IGRA با ب‌ث‌ژ مثبت نمی‌شود.** این تنها و بزرگ‌ترین مزیتش است.\n\n"
    "**همچنین IGRA با اکثر مایکوباکتریوم‌های غیرتوبرکلوز (NTM) مثبت نمی‌شود** — با سه "
    "استثنای شناخته‌شده که آن‌ها هم RD1 دارند: **M. kansasii، M. marinum و M. "
    "szulgai**.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**جذام** — عامل آن **مایکوباکتریوم لپره** است. IGRA برای آن طراحی نشده و "
    "آنتی‌ژن‌هایش را نمی‌سنجد.\n\n"
    "**نوکاردیا** — اصلاً مایکوباکتریوم نیست؛ یک **اکتینومیست** است. (نکته‌ی "
    "میکروب‌شناسی: نوکاردیا **نیمه‌اسیدفست** است، یعنی با رنگ‌آمیزی اسیدفست تعدیل‌شده "
    "رنگ می‌گیرد — و همین گاهی با سل اشتباه می‌شود.)\n\n"
    "⚠️ **مایکوباکتریوم غیرتوبرکلوز** — گزینه‌ی فریبنده و مهم. **دقیقاً نقطه‌ی مقابل "
    "پاسخ است:** IGRA طراحی شده تا **NTM را ندیده بگیرد** و فقط توبرکلوزیس را "
    "بگیرد.\n\n"
    "**و یک محدودیت بنیادی که همیشه باید کنار IGRA بیاید: مثل PPD، این آزمون "
    "نمی‌تواند عفونت نهفته را از بیماری فعال جدا کند. مثبت بودنش فقط می‌گوید "
    "«روبه‌رو شده‌اید»، نه «الان بیمارید».**",
    "This short question tests an important molecular point.\n\n"
    "QUANTIFERON IS AN IGRA — an INTERFERON-GAMMA RELEASE ASSAY. It works like this: the patient's blood is exposed to ANTIGENS SPECIFIC TO MYCOBACTERIUM TUBERCULOSIS and the amount of INTERFERON GAMMA released by the T lymphocytes is measured. If the body has met the tubercle bacillus before, memory lymphocytes respond.\n\n"
    "SO THE ANSWER IS: INFECTION WITH MYCOBACTERIUM TUBERCULOSIS.\n\n"
    "WARNING, NOW THE POINT THAT MAKES THIS TEST VALUABLE: WHICH ANTIGENS?\n\n"
    "ESAT-6 AND CFP-10 (and TB7.7 in newer versions). THESE TWO PROTEINS ARE ENCODED IN A GENOMIC REGION CALLED RD1 — AND THAT REGION IS DELETED FROM THE BCG VACCINE STRAIN.\n\n"
    "THE PRACTICAL AND VERY IMPORTANT CONSEQUENCE:\n\n"
    "THE PPD CAN BE FALSELY POSITIVE IN A BCG-VACCINATED PERSON — a large problem in Iran, where vaccination is universal.\n\n"
    "WARNING: BUT IGRA IS NOT MADE POSITIVE BY BCG. That is its single greatest advantage.\n\n"
    "IGRA IS ALSO NOT MADE POSITIVE BY MOST NON-TUBERCULOUS MYCOBACTERIA — with three known exceptions that also carry RD1: M. KANSASII, M. MARINUM AND M. SZULGAI.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "LEPROSY — caused by MYCOBACTERIUM LEPRAE. IGRA is not designed for it and does not measure its antigens.\n\n"
    "NOCARDIA — not a mycobacterium at all; it is an ACTINOMYCETE. (A microbiology point: Nocardia is PARTIALLY ACID-FAST, staining with a modified acid-fast method — which is why it is sometimes mistaken for tuberculosis.)\n\n"
    "WARNING: NON-TUBERCULOUS MYCOBACTERIA — the seductive and important option. IT IS EXACTLY THE OPPOSITE OF THE ANSWER: IGRA was designed specifically TO IGNORE NTM and detect only M. tuberculosis.\n\n"
    "AND ONE FUNDAMENTAL LIMITATION THAT MUST ALWAYS ACCOMPANY IGRA: like the PPD, it cannot separate latent infection from active disease. A positive result says only 'you have met it', not 'you are ill now'.",
    ["عامل آن مایکوباکتریوم لپره است و IGRA آنتی‌ژن‌های آن را نمی‌سنجد.",
     "نوکاردیا اصلاً مایکوباکتریوم نیست؛ اکتینومیست نیمه‌اسیدفست است.",
     "پاسخ صحیح — IGRA با آنتی‌ژن‌های ESAT-6 و CFP-10 اختصاصی توبرکلوزیس کار می‌کند.",
     "دقیقاً نقطه‌ی مقابل؛ IGRA طراحی شده تا مایکوباکتریوم‌های غیرتوبرکلوز را ندیده بگیرد."],
    ["Caused by Mycobacterium leprae; IGRA does not measure its antigens.",
     "Nocardia is not a mycobacterium at all; it is a partially acid-fast actinomycete.",
     "Correct — IGRA works on the ESAT-6 and CFP-10 antigens specific to M. tuberculosis.",
     "Exactly the opposite; IGRA was designed to ignore non-tuberculous mycobacteria."],
    "**IGRA با آنتی‌ژن‌های RD1 کار می‌کند، و RD1 در سویه‌ی ب‌ث‌ژ حذف شده است.**",
    "IGRA works on the RD1 antigens, and RD1 is deleted from the BCG strain.",
    REFSW)

# ============================================== TB IN HIV
HIVTB_FA = [
    "⚠️ **در همراهی TB و HIV، چهار چیز برعکس حالت عادی می‌شود.**",
    "**یک: تست توبرکولین اغلب منفی می‌شود — آنرژی.**",
    "**دو: اسمیر خلط با پیشرفت HIV کمتر مثبت می‌شود، نه بیشتر.**",
    "**چون مثبت شدن اسمیر به کاویته نیاز دارد، و کاویته کار ایمنی است.**",
    "**سه: رادیوگرافی تابلوی کلاسیک قله را از دست می‌دهد.**",
    "**در CD4 پایین: درگیری تحتانی، منتشر، میلیاری، یا حتی گرافی طبیعی.**",
    "⚠️ **چهار: کشت خون می‌تواند مایکوباکتریوم بدهد — مایکوباکتریمی.**",
    "**چون در نبود گرانولوم مؤثر، باسیل وارد جریان خون می‌شود.**",
    "**و خطر تبدیل نهفته به فعال، حدود ۱۰٪ در هر سال است.**",
    "**نه ۳ تا ۱۳٪ در طول عمر — این عدد مال فرد با ایمنی سالم است.**",
    "**پس در هر بیمار HIV مثبت با تب یا سرفه، سل را جدی بگیرید.**",
    "**و هم‌زمان، غربالگری HIV در هر بیمار مسلول الزامی است.**",
]
HIVTB_EN = [
    "WARNING: IN TB-HIV CO-INFECTION, FOUR THINGS INVERT.",
    "ONE: the tuberculin test tends to become NEGATIVE — anergy.",
    "TWO: the sputum smear becomes LESS often positive as HIV advances, not more.",
    "Because a positive smear requires a cavity, and cavitation is an act of immunity.",
    "THREE: the radiograph loses the classic apical pattern.",
    "At a low CD4 count: lower-zone, diffuse, miliary, or even a normal film.",
    "WARNING: FOUR — THE BLOOD CULTURE MAY GROW MYCOBACTERIUM. Mycobacteraemia.",
    "Because without an effective granuloma the bacillus enters the bloodstream.",
    "And the risk of latent becoming active is about 10 % PER YEAR.",
    "Not 3 to 13 % over a lifetime — that figure belongs to the immunocompetent.",
    "So in every HIV-positive patient with fever or cough, take tuberculosis seriously.",
    "And conversely, HIV screening is mandatory in every tuberculosis patient.",
]

add("book:222", "recall", "hard",
    "**در همراهی TB و HIV، کشت خون می‌تواند مایکوباکتریوم بدهد.**",
    "In TB-HIV co-infection, the blood culture may grow Mycobacterium.",
    HIVTB_FA, HIVTB_EN,
    "این سؤال چهار جمله را کنار هم گذاشته و می‌خواهد بدانید کدام درست است. **و "
    "جالب اینکه سه جمله‌ی غلط، همگی از یک سوءبرداشت واحد زاده‌اند.**\n\n"
    "⚠️ **سوءبرداشت مشترک: «HIV بیماری را بدتر می‌کند، پس همه‌ی نشانه‌های بیماری هم "
    "شدیدتر می‌شوند.» این دقیقاً برعکس واقعیت است.**\n\n"
    "**اصل حاکم: بسیاری از یافته‌های کلاسیک سل، محصول پاسخ ایمنی‌اند، نه محصول خود "
    "باکتری. وقتی ایمنی از بین می‌رود، آن یافته‌ها هم از بین می‌روند — در حالی که "
    "بیماری شدیدتر است.**\n\n"
    "**حالا گزینه‌ها را با این اصل بسنجیم.**\n\n"
    "**گزینه‌ی درست: امکان مثبت شدن کشت خون با مایکوباکتریوم وجود دارد.** ✔\n\n"
    "**چرا؟** در فرد با ایمنی سالم، **گرانولوم** باسیل را در ریه محبوس می‌کند و "
    "**مایکوباکتریمی عملاً رخ نمی‌دهد**. ولی وقتی CD4 پایین است، گرانولوم درست ساخته "
    "نمی‌شود، سد شکسته می‌شود، و **باسیل وارد جریان خون می‌شود**. این همان چیزی است که "
    "**سل منتشر (میلیاری)** را در HIV شایع می‌کند. **در CD4 خیلی پایین، کشت خون "
    "مایکوباکتریایی یک آزمون منطقی و گاه تشخیصی است.**\n\n"
    "**چرا سه گزینه‌ی دیگر غلط‌اند؟**\n\n"
    "⚠️ **«میزان مثبت شدن اسمیر خلط با پیشرفت HIV افزایش می‌یابد»** — **دقیقاً برعکس.** "
    "**اسمیر مثبت نیازمند کاویته است**، و کاویته یک **ضایعه‌ی نکروزان ایمنی‌محور** است: "
    "ماکروفاژهای فعال و لنفوسیت‌های T بافت را تخریب می‌کنند و حفره می‌سازند، و همان "
    "حفره میلیون‌ها باسیل را به راه هوایی می‌ریزد. **بدون ایمنی، کاویته نیست؛ بدون "
    "کاویته، اسمیر منفی است.**\n\n"
    "⚠️ **«درگیری قسمت‌های فوقانی و تشکیل کاویته با پیشرفت HIV بیشتر می‌شود»** — **باز "
    "هم برعکس، و به همان دلیل.** الگوی قله‌ای-کاویتری، تابلوی **بازفعالی در فرد با "
    "ایمنی حفظ‌شده** است. **در CD4 پایین، تابلو به سمت درگیری تحتانی، منتشر، میلیاری، "
    "آدنوپاتی مدیاستینال، یا حتی گرافی طبیعی می‌رود.** این یکی از خطرناک‌ترین دام‌های "
    "بالینی است: **گرافی «تقریباً طبیعی» در بیمار HIV مثبت، سل را رد نمی‌کند.**\n\n"
    "⚠️ **«خطر تبدیل عفونت نهفته به بیماری در این بیماران ۳ تا ۱۳٪ در طول عمر است»** — "
    "**این عدد مال فرد با ایمنی سالم است** (حدود ۱۰٪ در تمام عمر). **در HIV "
    "درمان‌نشده، همان خطر حدود ۱۰٪ در هر سال است** — یعنی جابه‌جایی «طول عمر» به "
    "«سال»، که تفاوت را ده‌ها برابر می‌کند.\n\n"
    "**نتیجه‌ی عملی: در هر بیمار HIV مثبت با تب یا سرفه، سل را در صدر فهرست بگذارید، "
    "حتی با اسمیر منفی و گرافی نامشخص. و متقابلاً، در هر بیمار مسلول، آزمایش HIV "
    "الزامی است.**",
    "This question sets four statements side by side and asks which is true. AND STRIKINGLY, THE THREE FALSE ONES ALL SPRING FROM A SINGLE MISCONCEPTION.\n\n"
    "WARNING, THE SHARED MISCONCEPTION: 'HIV makes the disease worse, so all the signs of disease must be more severe too.' THAT IS EXACTLY BACKWARDS.\n\n"
    "THE GOVERNING PRINCIPLE: MANY OF THE CLASSIC FINDINGS OF TUBERCULOSIS ARE PRODUCTS OF THE IMMUNE RESPONSE, NOT OF THE BACTERIUM. When immunity is lost, those findings are lost too — while the disease itself is more severe.\n\n"
    "NOW TEST THE OPTIONS AGAINST THAT PRINCIPLE.\n\n"
    "THE CORRECT OPTION: THE BLOOD CULTURE MAY GROW MYCOBACTERIUM.\n\n"
    "WHY? In an immunocompetent host the GRANULOMA imprisons the bacillus in the lung and MYCOBACTERAEMIA essentially does not occur. But when the CD4 count is low the granuloma is not properly built, the barrier fails, and THE BACILLUS ENTERS THE BLOODSTREAM. This is precisely what makes DISSEMINATED (MILIARY) TUBERCULOSIS common in HIV. AT A VERY LOW CD4 COUNT, A MYCOBACTERIAL BLOOD CULTURE IS A REASONABLE AND SOMETIMES DIAGNOSTIC TEST.\n\n"
    "WHY ARE THE OTHER THREE FALSE?\n\n"
    "WARNING: 'SMEAR POSITIVITY RISES AS HIV ADVANCES' — EXACTLY BACKWARDS. A POSITIVE SMEAR REQUIRES A CAVITY, and a cavity is an IMMUNE-DRIVEN NECROTISING LESION: activated macrophages and T cells destroy tissue and hollow it out, and that hollow pours millions of bacilli into the airway. WITHOUT IMMUNITY THERE IS NO CAVITY; WITHOUT A CAVITY THE SMEAR IS NEGATIVE.\n\n"
    "WARNING: 'UPPER-ZONE INVOLVEMENT AND CAVITATION INCREASE AS HIV ADVANCES' — AGAIN BACKWARDS, FOR THE SAME REASON. The apical-cavitary pattern is the picture of REACTIVATION IN A PRESERVED IMMUNE SYSTEM. AT A LOW CD4 COUNT THE PICTURE MOVES TOWARDS LOWER-ZONE, DIFFUSE OR MILIARY DISEASE, MEDIASTINAL ADENOPATHY, OR EVEN A NORMAL FILM. This is one of the most dangerous clinical traps: AN ALMOST-NORMAL FILM IN AN HIV-POSITIVE PATIENT DOES NOT EXCLUDE TUBERCULOSIS.\n\n"
    "WARNING: 'THE LIFETIME RISK OF PROGRESSION IN THESE PATIENTS IS 3 TO 13 %' — THAT FIGURE BELONGS TO THE IMMUNOCOMPETENT (about 10 % over a lifetime). IN UNTREATED HIV THE SAME RISK IS ABOUT 10 % PER YEAR — the shift from 'lifetime' to 'year' multiplies it many times over.\n\n"
    "THE PRACTICAL CONSEQUENCE: in every HIV-positive patient with fever or cough, put tuberculosis at the top of the list even with a negative smear and an equivocal film. And conversely, HIV testing is mandatory in every tuberculosis patient.",
    ["پاسخ صحیح — بدون گرانولوم مؤثر، باسیل وارد خون می‌شود و مایکوباکتریمی رخ می‌دهد.",
     "برعکس است؛ اسمیر مثبت به کاویته نیاز دارد و کاویته کار ایمنی است.",
     "برعکس است؛ الگوی قله‌ای-کاویتری تابلوی ایمنی حفظ‌شده است، نه CD4 پایین.",
     "این عدد مال فرد با ایمنی سالم در طول عمر است؛ در HIV حدود ۱۰٪ در هر سال است."],
    ["Correct — without an effective granuloma the bacillus enters the blood and mycobacteraemia occurs.",
     "The opposite; a positive smear requires a cavity and cavitation is an act of immunity.",
     "The opposite; the apical-cavitary pattern belongs to preserved immunity, not to a low CD4 count.",
     "That figure is the lifetime risk in the immunocompetent; in HIV it is about 10 % per year."],
    "**یافته‌های کلاسیک سل محصول ایمنی‌اند؛ در HIV آن‌ها محو می‌شوند و بیماری شدیدتر است.**",
    "The classic findings of tuberculosis are products of immunity; in HIV they fade while the disease worsens.",
    REFSW)

json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book52.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 52 lessons:', len(L))
