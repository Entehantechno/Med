# -*- coding: utf-8 -*-
"""Re-examine the four quarantined keys against primary sources.

Why this exists
---------------
In an earlier session I audited the book's printed answer keys against clinical
rules and quarantined four as medically wrong. Re-checking those four against
primary sources shows that **two of my own flags were mistaken**. Recording the
correction here, rather than quietly editing, because a review process that is
never itself reviewed is worth very little.

  idx 674 — "positive ELISA, next step?"  book says REPEAT THE ELISA
      My flag: wrong, should be Western blot.
      Re-check: the flag was MISTAKEN. The classical two-tier algorithm
      explicitly retests an initially reactive specimen IN DUPLICATE, and only
      a *repeatedly reactive* specimen proceeds to a supplemental test. CDC/
      NHANES laboratory method: "Initially reactive specimens should be
      retested in duplicate to validate the initial test results... Repeatedly
      reactive specimens according to the algorithm will undergo further
      testing: HIV-1 Western blot."  -> the book is RIGHT. Un-quarantine.

  idx 684 — "ELISA positive then negative, next step?"  book says REPEAT IN 3-6 MONTHS
      My flag: wrong, should be Western blot.
      Re-check: the flag was MISTAKEN. With the repeat negative the specimen is
      not repeatedly reactive, so by the same algorithm it is reported negative
      and Western blot is NOT indicated. Serial retesting to cover the window
      period is the defensible next step.  -> the book is RIGHT. Un-quarantine.

  idx 134 — typhoid, "most likely complication?"  book says MENINGITIS
      My flag: wrong, should be intestinal perforation.
      Re-check: the flag STANDS. Merck: "An acute abdomen and leukocytosis
      during the third week may suggest intestinal perforation"; CDC Yellow
      Book: serious complications "include life-threatening gastrointestinal
      hemorrhage, intestinal perforation, and encephalopathy". Meningitis is a
      rare focal complication.  -> the book is WRONG. Correct the key.

  idx 540 — presumptive urethritis, "treatment of choice?"  book says NONE OF THE ABOVE
      My flag: wrong, should be ceftriaxone + azithromycin.
      Re-check: the flag STANDS. Option (a) reads "Ceftriaxone 250 mg amp +
      Azithromycin 1 g PO", which is verbatim the CDC dual-therapy regimen of
      that era. Answering "none of the above" when a listed option is the
      guideline regimen is indefensible.  -> the book is WRONG. Correct the key.

Net effect: two questions return to normal use with the book's own key, and two
have their key corrected with the change recorded on the question itself.
"""
import json, io, os

BANK = '/home/user/project/tools/infectious-bank'

# idx -> what to do
UNQUARANTINE = {
    674: 'classical algorithm repeats a reactive screen in duplicate before a '
         'supplemental test; the printed key is correct',
    684: 'a repeat-negative screen is not repeatedly reactive, so Western blot '
         'is not indicated; the printed key is correct',
}

CORRECT = {
    134: {
        'new_index': 1,
        'was': 'مننژیت',
        'now': 'پرفوراسیون روده',
        'reason_fa': 'عارضه‌ی کلاسیک و شایع تب روده‌ای در هفته‌ی سوم، پرفوراسیون '
                     'ایلئوم و خونریزی گوارشی است؛ مننژیت عارضه‌ی کانونی نادری است.',
        'reason_en': 'The classic severe complication of enteric fever in week three '
                     'is ileal perforation and GI haemorrhage; meningitis is a rare '
                     'focal complication.',
        'source': 'Merck Manual Professional, Typhoid Fever; CDC Yellow Book, '
                  'Typhoid and Paratyphoid Fever',
    },
    540: {
        'new_index': 0,
        'was': 'هیچ‌کدام از موارد فوق',
        'now': 'Ceftriaxone 250 mg + Azithromycin 1 g PO',
        'reason_fa': 'گزینه‌ی الف دقیقاً همان رژیم دوگانه‌ی توصیه‌شده برای یورتریت '
                     'فرضی است؛ وقتی یک گزینه رژیم راهنماست، «هیچ‌کدام» نمی‌تواند پاسخ باشد.',
        'reason_en': 'Option (a) is verbatim the recommended dual regimen for '
                     'presumptive urethritis; "none of the above" cannot be correct '
                     'when a listed option is the guideline regimen.',
        'source': 'CDC STD Treatment Guidelines (dual therapy: ceftriaxone plus '
                  'azithromycin)',
    },
}


def main():
    idx = 0
    freed, fixed = [], []
    for i in range(1, 6):
        p = os.path.join(BANK, f'import-payload.book.part{i:02d}.json')
        if not os.path.exists(p):
            continue
        body = json.load(io.open(p, encoding='utf-8'))
        for q in body['questions']:
            n = idx
            idx += 1

            if n in UNQUARANTINE:
                q.pop('key_disputed', None)
                q.pop('key_dispute_reason', None)
                q.pop('key_expected', None)
                q.pop('needs_review', None)
                q.pop('premium', None)
                q['key_recheck'] = UNQUARANTINE[n]
                freed.append(n)

            if n in CORRECT:
                c = CORRECT[n]
                q['original_correct_index'] = q['correct_index']
                q['correct_index'] = c['new_index']
                q['key_corrected'] = True
                q['key_correction_fa'] = c['reason_fa']
                q['key_correction_en'] = c['reason_en']
                q['key_correction_source'] = c['source']
                # it is no longer "disputed" — it is resolved and corrected
                q.pop('key_disputed', None)
                q.pop('key_dispute_reason', None)
                q.pop('key_expected', None)
                q.pop('needs_review', None)
                q.pop('premium', None)
                fixed.append((n, c['was'], c['now']))

        json.dump(body, io.open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

    print(f'scanned {idx} questions')
    print(f'un-quarantined (my flag was wrong, book was right): {freed}')
    for n, was, now in fixed:
        print(f'corrected idx={n}: "{was}" -> "{now}"')


if __name__ == '__main__':
    main()
