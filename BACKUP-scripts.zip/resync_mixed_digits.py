# -*- coding: utf-8 -*-
"""Re-sync the handful of stems that mixed Arabic-Indic and ASCII digits.

The problem
-----------
This book prints some numbers with Arabic-Indic (U+0660..) or Persian
(U+06F0..) digits, and sometimes mixes them into the SAME number as ASCII ones:
a 52-year-old is typeset "5٢". `NUM_RUN` in extract_rtl matches only [0-9], so
that run was read as two independent one-digit numbers. A one-digit number is
its own mirror, so the line flip left the pair in visual order and the value
came out reversed AND split — "٢5" rendered as "25 " with a stray digit adrift.

`fold()` now maps every digit to ASCII before the flip, so the run is a single
token and the ordinary rules get it right. That fixes the extractor, but the
payload for these few questions still holds the older broken text, and the
targeted age substitution in fix_book_ages.py can only move the age — it cannot
remove the orphaned digit left elsewhere in the sentence.

The fix
-------
For exactly these questions, take the whole stem and options from the clean
re-extraction rather than patching them. Matching is on Persian LETTERS only,
because letters are precisely what neither bug disturbed, while digits and
spacing are what we intend to replace.

Guards: the option count must match, the answer index is never touched, and a
question is rewritten only on a unique letter-key hit.
"""
import json, io, os, re, sys, collections

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import repair_text

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, 'out', 'book_raw.json')
NON_ASCII_DIGIT = re.compile(r'[\u0660-\u0669\u06F0-\u06F9]')
AGE_ANY = re.compile(r'(?<![\d])(\d{1,3})(?:\s*(?:ساله|سال\s*ه|ساله\s*ای|سال))')


def letters(s):
    """Persian letters only — stable across both digit bugs.

    U+0600..U+06FF also contains the Arabic-Indic and Persian DIGIT blocks, so
    a naive class keeps exactly the characters we are trying to ignore.
    """
    s = NON_ASCII_DIGIT.sub('', s or '')
    return re.sub(r'[^\u0600-\u06FF]', '', s)


def main():
    raw = json.load(io.open(RAW, encoding='utf-8'))

    tokens = collections.Counter()
    for q in raw:
        for f in [q['stem_fa']] + list(q['options_fa']):
            for w in repair_text.WORD.findall(f or ''):
                tokens[w] += 1
    vocab = repair_text.clean_vocab()
    rep = repair_text.build_fixes(tokens, vocab)
    for k, v in repair_text.build_che_fixes(tokens, vocab).items():
        rep.setdefault(k, v)

    index = collections.defaultdict(list)
    for q in raw:
        stem = repair_text.apply_fixes(q['stem_fa'], rep)
        opts = [repair_text.apply_fixes(o, rep) for o in q['options_fa']]
        index[letters(stem)].append((stem, opts))

    fixed = skipped = 0
    notes = []

    for i in range(1, 6):
        p = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        if not os.path.exists(p):
            continue
        body = json.load(io.open(p, encoding='utf-8'))
        dirty = False
        for q in body['questions']:
            blob = q['question_fa'] + ' '.join(q['options_fa'])
            if not NON_ASCII_DIGIT.search(blob):
                continue
            cands = index.get(letters(q['question_fa']))
            if not cands or len({c[0] for c in cands}) != 1:
                skipped += 1
                notes.append(f"q{q['question_no']}: no unique clean twin")
                continue
            stem, opts = cands[0]
            if len(opts) != len(q['options_fa']):
                skipped += 1
                notes.append(f"q{q['question_no']}: option count differs")
                continue
            if NON_ASCII_DIGIT.search(stem + ' '.join(opts)):
                skipped += 1
                notes.append(f"q{q['question_no']}: clean twin still has mixed digits")
                continue

            before = q['question_fa']
            q['question_fa'] = stem
            q['options_fa'] = opts
            q['text_resynced'] = 'mixed_digit_reextract'

            # Any age_corrected record predates this rewrite and may name a
            # value that is no longer in the stem. Restate it against the text
            # that is actually stored now, or drop it.
            old_ages = AGE_ANY.findall(before)
            new_ages = AGE_ANY.findall(stem)
            if old_ages != new_ages and len(old_ages) == len(new_ages):
                q['age_corrected'] = {'from': old_ages, 'to': new_ages}
                q['age_correction_note_fa'] = (
                    'ارقام این سؤال در PDF با اعداد عربی و لاتین درهم نوشته شده بود و '
                    'هنگام استخراج شکسته می‌شد؛ متن از روی کتاب دوباره استخراج و اصلاح شد.')
                q['age_correction_note_en'] = (
                    'This question mixed Arabic-Indic and ASCII digits in one number, which '
                    'broke the original extraction; the text was re-extracted from the book.')
            else:
                q.pop('age_corrected', None)
                q.pop('age_correction_note_fa', None)
                q.pop('age_correction_note_en', None)

            txt = re.sub(r'[۰-۹0-9]', '#', stem)
            txt = re.sub(r'[^\w\s#]', ' ', txt)
            q['fingerprint'] = (
                'بیماری‌های عفونی Infectious Diseases '
                + re.sub(r'\s+', ' ', txt).strip())[:400]
            fixed += 1
            dirty = True
            notes.append(f"q{q['question_no']}: {before[:44]} -> {stem[:44]}")
        if dirty:
            json.dump(body, io.open(p, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)

    print(f're-synced: {fixed}   left alone: {skipped}')
    for n in notes:
        print('  ', n)


if __name__ == '__main__':
    main()
