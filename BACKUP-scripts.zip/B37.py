# -*- coding: utf-8 -*-
"""Micro-lessons, batch 37 — the last 46 questions of the viral and STI chapter.

This batch closes the largest chapter in the book. Five clusters remain, and
each reduces to one discriminating idea rather than a list:

  * GENITAL ULCER AND URETHRITIS — decided by PAIN and by what the Gram stain
    can and cannot see.
  * MONONUCLEOSIS, ONE MORE TIME — the exam's favourite trap, penicillin.
  * VARICELLA ZOSTER, THE WHOLE LIFE CYCLE — chickenpox, zoster, Ramsay Hunt,
    and the four post-exposure scenarios that students routinely confuse.
  * MEASLES, RUBELLA AND MUMPS — recognised from the mucosa, not the rash.
  * HEPATITIS C AND THE NON-RESPONDER — the window period again, in a new
    disease.

TWO SOURCE DEFECTS ANNOTATED IN THIS BATCH
-------------------------------------------
q9599 prints a platelet count of 1,350,000 — not a human value; the intended
figure is almost certainly 135,000, the mild thrombocytopenia of
mononucleosis. q9856 prints an antibody titre of "about 6" with NO UNIT at
all. Glyph geometry confirms the page prints what we stored in both cases, so
both are errors of the BOOK and are annotated rather than rewritten. See
flag_source_errors_viral.py. Both lessons tell the student openly.

A NOTE ON THE VARICELLA POST-EXPOSURE CLUSTER
----------------------------------------------
Four questions (q9626, q9629, q9630, q9634) ask what to give after a varicella
exposure, and their keys are ORAL ACICLOVIR rather than VZIG. A student who
learned "VZIG for the immunocompromised" from an older source will think the
keys are wrong. They are not, and the reason is worth teaching: a randomised
comparison showed aciclovir started IMMEDIATELY after exposure failed (10 of
13, 77%, still developed varicella) while aciclovir started at DAY 7 worked
(3 of 14, 21%). Timing, not the drug, is the variable. UKHSA and the RCOG have
since made oral antivirals from day 7 to 14 the FIRST CHOICE for susceptible
pregnant women at any gestation, with VZIG reserved for those who cannot take
oral drugs. So the keys agree with current guidance, and the lessons say so.

Reference: UKHSA — Guidelines on post-exposure prophylaxis (PEP) for varicella
or shingles (2023, reviewed 2025); RCOG Green-top Guideline No. 13, Chickenpox
in Pregnancy (updated 2024); CDC — Chapter 15: Mumps, Pink Book; CDC — Manual
for the Surveillance of Vaccine-Preventable Diseases, Ch. 9 (Mumps);
Workowski KA et al., CDC STI Treatment Guidelines 2021 (MMWR 70(4));
Harrison's Principles of Internal Medicine, 21st ed (2022).
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — the viral and sexually "
     "transmitted infection chapters")
CDC2021 = ("Workowski KA et al. — Sexually Transmitted Infections Treatment Guidelines, 2021. "
           "MMWR Recomm Rep 2021;70(4):1-187 (Centers for Disease Control and Prevention)")
UKHSA = ("UK Health Security Agency — Guidelines on post-exposure prophylaxis (PEP) for "
         "varicella or shingles (2023, reviewed 2025)")
RCOG = ("Royal College of Obstetricians and Gynaecologists — Green-top Guideline No. 13: "
        "Chickenpox in Pregnancy (updated 2024)")
CDCMUMPS = ("CDC — Epidemiology and Prevention of Vaccine-Preventable Diseases (Pink Book), "
            "Ch. 15: Mumps; and Manual for the Surveillance of Vaccine-Preventable Diseases, "
            "Ch. 9: Mumps")
CDCMEASLES = ("CDC — Epidemiology and Prevention of Vaccine-Preventable Diseases (Pink Book), "
              "Ch. 13: Measles")
REDBOOK = ("American Academy of Pediatrics — Red Book: Report of the Committee on Infectious "
           "Diseases (varicella-zoster and Epstein-Barr virus)")

# ===================================================== GENITAL ULCER NETWORK
ULCER_FA = [
    "⚠️ **زخم تناسلی را با دو سؤال حل کنید: دردناک است یا نه؟ نرم است یا سفت؟**",
    "**این شبکه‌ی دوبعدی تقریباً همه‌ی سؤال‌های زخم تناسلی این فصل را جواب می‌دهد.**",
    "**سیفلیس (شانکر): بدون درد، سفت، با حاشیه‌ی صاف و برجسته، معمولاً تک.**",
    "⚠️ **و غدد لنفاوی سیفلیس هم بدون درد و دوطرفه‌اند — همه‌چیزش بی‌درد است.**",
    "**شانکروئید (هموفیلوس دوکره‌ای): دردناک، نرم، با حاشیه‌ی نامنظم و کنده‌شده، چرکی.**",
    "**و غدد لنفاوی‌اش یک‌طرفه، دردناک و مستعد چرکی شدن و تخلیه است (بوبو).**",
    "**هرپس: وزیکول‌های گروهی که به زخم‌های کم‌عمق و بسیار دردناک تبدیل می‌شوند.**",
    "⚠️ **و غدد لنفاوی هرپس اولیه دوطرفه و دردناک است — همین آن را از شانکروئید جدا می‌کند.**",
    "**لنفوگرانولوم ونروم: زخم اولیه‌ی کوچک و گذرا که بیمار اغلب اصلاً ندیده است.**",
    "**تابلوی غالبش لنفادنوپاتی دردناک است، نه خودِ زخم — و علامت شیار کلاسیک آن است.**",
    "⚠️ **قاعده‌ی حافظه: سیفلیس بی‌درد و سفت؛ شانکروئید دردناک و نرم؛ هرپس دردناک و وزیکولر.**",
    "**و «نرم» بودن شانکروئید آن‌قدر مشخصه است که نام دیگرش «شانکر نرم» است.**",
    "**در عمل، هم‌زمانی چند عامل شایع است، پس تست هم‌زمان برای سیفلیس و HIV الزامی است.**",
]
ULCER_EN = [
    "WARNING: SOLVE A GENITAL ULCER WITH TWO QUESTIONS — is it PAINFUL, and is it SOFT or HARD?",
    "That two-dimensional grid answers nearly every genital-ulcer question in this chapter.",
    "SYPHILIS (chancre): PAINLESS, INDURATED, with a clean raised edge, usually solitary.",
    "WARNING, AND ITS NODES ARE PAINLESS AND BILATERAL TOO — everything about it is painless.",
    "CHANCROID (Haemophilus ducreyi): PAINFUL, SOFT, with a ragged undermined edge, purulent.",
    "And its nodes are UNILATERAL, TENDER and liable to suppurate and drain (a bubo).",
    "HERPES: grouped vesicles breaking down into shallow, exquisitely painful ulcers.",
    "WARNING, AND THE NODES OF PRIMARY HERPES ARE BILATERAL AND TENDER — that separates it from chancroid.",
    "LYMPHOGRANULOMA VENEREUM: a small transient primary ulcer the patient often never noticed.",
    "Its dominant picture is PAINFUL LYMPHADENOPATHY rather than the ulcer, with the classic groove sign.",
    "WARNING, THE MEMORY RULE: syphilis painless and hard; chancroid painful and soft; herpes painful and vesicular.",
    "And chancroid's softness is so characteristic that its other name is SOFT CHANCRE.",
    "In practice coinfection is common, so simultaneous testing for syphilis and HIV is mandatory.",
]

# ===================================================== URETHRITIS
URETH_FA = [
    "⚠️ **اورتریت را به دو دسته تقسیم کنید: گونوکوکی و غیرگونوکوکی. و هر دو را با هم درمان کنید.**",
    "**گونوکوک: دوره‌ی کمون کوتاه (۲ تا ۷ روز)، ترشح فراوان و آشکارا چرکی.**",
    "**غیرگونوکوکی (عمدتاً کلامیدیا): کمون طولانی‌تر (۷ تا ۲۱ روز)، ترشح کم و مخاطی.**",
    "⚠️ **و مهم‌ترین نکته‌ی آزمایشگاهی: رنگ‌آمیزی گرم فقط گونوکوک را می‌بیند.**",
    "**دیپلوکوک گرم منفی داخل سلولی یعنی گونوکوک — و این یافته تشخیصی است.**",
    "**ولی کلامیدیا دیواره‌ی سلولی معمولی ندارد و داخل سلول زندگی می‌کند، پس در گرم دیده نمی‌شود.**",
    "⚠️ **نتیجه‌ی عملی: گرم منفی، کلامیدیا را رد نمی‌کند — فقط می‌گوید گونوکوک نیست.**",
    "**و چون هم‌زمانی این دو تا یک‌سوم موارد است، درمان همیشه هر دو را پوشش می‌دهد.**",
    "**رژیم آن دوره: سفتریاکسون برای گونوکوک به‌علاوه‌ی آزیترومایسین یا داکسی‌سیکلین برای کلامیدیا.**",
    "⚠️ **و به‌روزرسانی CDC 2021: سفتریاکسون ۵۰۰ میلی‌گرم تک‌دوز، و داکسی‌سیکلین به‌جای آزیترومایسین.**",
    "**دلیل حذف آزیترومایسین: نگرانی از مقاومت فزاینده، و برتری داکسی‌سیکلین در کلامیدیای رکتال.**",
    "**علامت پایدار پس از درمان کامل، معمولاً اورتریت پایدار یا راجعه است، نه شکست درمان.**",
    "**و شایع‌ترین علت آن، تریکوموناس یا مایکوپلاسما ژنیتالیوم یا عدم درمان شریک جنسی است.**",
]
URETH_EN = [
    "WARNING: SPLIT URETHRITIS INTO GONOCOCCAL AND NON-GONOCOCCAL — and treat for both.",
    "GONOCOCCAL: short incubation (2 to 7 days), profuse and frankly purulent discharge.",
    "NON-GONOCOCCAL (mostly chlamydia): longer incubation (7 to 21 days), scant mucoid discharge.",
    "WARNING, AND THE KEY LABORATORY POINT: THE GRAM STAIN SEES ONLY THE GONOCOCCUS.",
    "Intracellular Gram-negative diplococci mean gonorrhoea, and that finding is diagnostic.",
    "But chlamydia has no ordinary cell wall and lives inside cells, so it is invisible on Gram stain.",
    "WARNING, THE PRACTICAL CONSEQUENCE: a negative Gram does NOT exclude chlamydia; it only excludes gonorrhoea.",
    "And because the two coincide in up to a third of cases, treatment always covers both.",
    "The regimen of that era: ceftriaxone for gonorrhoea plus azithromycin or doxycycline for chlamydia.",
    "WARNING, THE CDC 2021 UPDATE: ceftriaxone 500 mg as a single dose, and doxycycline in place of azithromycin.",
    "Why azithromycin was dropped: rising resistance, and doxycycline's superiority in rectal chlamydia.",
    "Symptoms persisting after complete treatment usually mean persistent or recurrent urethritis, not treatment failure.",
    "And its commonest causes are trichomonas, Mycoplasma genitalium, or an untreated partner.",
]

# ===================================================== MONONUCLEOSIS
MONO_FA = [
    "⚠️ **مونونوکلئوز را از استرپتوکوک با سه یافته جدا کنید، و هر سه در این فصل پرسیده شده‌اند.**",
    "**یک — محل غدد: در مونونوکلئوز، گردنی خلفی یا ژنرالیزه؛ در استرپتوکوک، گردنی قدامی.**",
    "⚠️ **دو — اسپلنومگالی: استرپتوکوک طحال را بزرگ نمی‌کند. مونونوکلئوز در نیمی از موارد می‌کند.**",
    "**سه — لام خون: لنفوسیتوز با بیش از ۱۰ درصد لنفوسیت آتیپیک.**",
    "**این لنفوسیت‌های آتیپیک سلول‌های آلوده نیستند — سلول‌های T واکنشی علیه سلول B آلوده‌اند.**",
    "**پس تابلوی مونونوکلئوز بیشتر یک واکنش ایمنی است تا تهاجم مستقیم ویروس.**",
    "⚠️ **درمان مونونوکلئوز بدون عارضه: هیچ. استراحت، مایعات، مسکن و تب‌بر.**",
    "**آسیکلوویر بار ویروسی حلق را کم می‌کند ولی سیر بالینی را کوتاه نمی‌کند، پس توصیه نمی‌شود.**",
    "⚠️ **و دامی که این فصل چند بار می‌آزماید: آمپی‌سیلین یا آموکسی‌سیلین ندهید.**",
    "**در اکثریت قاطع بیماران مونونوکلئوزی این داروها راش ماکولوپاپولر وسیعی می‌سازند.**",
    "**این راش آلرژی به پنی‌سیلین نیست و نباید در پرونده به‌عنوان آلرژی ثبت شود.**",
    "**چون برچسب اشتباه آلرژی، تا آخر عمر انتخاب‌های درمانی بیمار را محدود می‌کند.**",
    "⚠️ **و توصیه‌ی عملی کلیدی: پرهیز از ورزش‌های برخوردی تا ۳ تا ۴ هفته.**",
    "**چون پارگی طحال، هرچند نادر، کشنده‌ترین عارضه‌ی مونونوکلئوز است.**",
]
MONO_EN = [
    "WARNING: SEPARATE MONONUCLEOSIS FROM STREPTOCOCCUS BY THREE FINDINGS, all examined in this chapter.",
    "ONE — the site of the nodes: posterior cervical or generalised in mononucleosis; anterior cervical in streptococcus.",
    "WARNING, TWO — SPLENOMEGALY: streptococcus does not enlarge the spleen. Mononucleosis does in half of cases.",
    "THREE — the blood film: lymphocytosis with more than 10 per cent ATYPICAL LYMPHOCYTES.",
    "Those atypical lymphocytes are not infected cells — they are reactive T cells attacking infected B cells.",
    "So the picture of mononucleosis is more an immune reaction than a direct viral invasion.",
    "WARNING, THE TREATMENT OF UNCOMPLICATED MONONUCLEOSIS IS NOTHING: rest, fluids, analgesia, antipyretics.",
    "Aciclovir reduces pharyngeal shedding but does not shorten the illness, so it is not recommended.",
    "WARNING, AND THE TRAP THIS CHAPTER TESTS REPEATEDLY: DO NOT GIVE AMPICILLIN OR AMOXICILLIN.",
    "In the great majority of patients with mononucleosis these drugs produce a florid maculopapular rash.",
    "That rash is NOT a penicillin allergy and must not be recorded as one.",
    "Because a mistaken allergy label narrows the patient's treatment options for life.",
    "WARNING, AND THE KEY PRACTICAL ADVICE: avoid contact sports for 3 to 4 weeks.",
    "Because SPLENIC RUPTURE, though rare, is the most lethal complication of mononucleosis.",
]

# ===================================================== VARICELLA ZOSTER
VZV_FA = [
    "⚠️ **آبله‌مرغان را از سه‌گانه‌اش بشناسید، و هر سه جزء لازم است.**",
    "**یک — ضایعات در مراحل مختلف تکامل: ماکول و پاپول و وزیکول و پوستول و کراست، هم‌زمان.**",
    "⚠️ **این «چندمرحله‌ای بودن» مهم‌ترین نکته است و آبله‌مرغان را از آبله جدا می‌کند.**",
    "**در آبله (اسمال‌پاکس) همه‌ی ضایعات هم‌مرحله بودند؛ در آبله‌مرغان هرگز.**",
    "**دو — انتشار مرکزگرا: تنه بیشتر از اندام‌ها درگیر است، برخلاف آبله.**",
    "**سه — درگیری مخاط دهان، که در سؤال‌های این فصل بارها ذکر شده است.**",
    "**وزیکول کلاسیک آبله‌مرغان را «قطره‌ی شبنم روی گلبرگ گل رز» توصیف می‌کنند.**",
    "⚠️ **دوره‌ی سرایت: از ۲۴ تا ۴۸ ساعت پیش از راش تا خشک شدن کامل همه‌ی ضایعات.**",
    "**پس معیار پایان ایزولاسیون، کراست شدن ضایعات است، نه گذشت تعداد معینی روز.**",
    "**زونا همان ویروس است که از گانگلیون حسی دوباره فعال شده و یک درماتوم را می‌گیرد.**",
    "**درد سوزشی معمولاً چند روز پیش از ظهور وزیکول‌ها شروع می‌شود و گمراه‌کننده است.**",
    "⚠️ **و سندرم رامسی‌هانت: زونای گانگلیون زانویی — وزیکول در کانال گوش به‌علاوه‌ی فلج عصب هفتم.**",
    "**افتراقش از فلج بل همین وزیکول‌ها و درد شدید گوش است، و درمانش فوری‌تر.**",
    "**عوارض آبله‌مرغان در بالغ: پنومونی واریسلایی، آتاکسی مخچه‌ای، عفونت ثانویه‌ی پوستی.**",
    "**و آتاکسی مخچه‌ای پس از آبله‌مرغان، خودمحدودشونده است و درمان حمایتی می‌خواهد.**",
]
VZV_EN = [
    "WARNING: RECOGNISE CHICKENPOX BY ITS TRIAD, and all three parts are needed.",
    "ONE — lesions in DIFFERENT STAGES of evolution: macules, papules, vesicles, pustules and crusts together.",
    "WARNING, THIS SIMULTANEOUS MULTI-STAGE APPEARANCE is the key point and separates it from smallpox.",
    "In smallpox all lesions were at the SAME stage; in chickenpox never.",
    "TWO — a CENTRIPETAL distribution: the trunk more than the limbs, again unlike smallpox.",
    "THREE — involvement of the ORAL MUCOSA, mentioned repeatedly in this chapter's stems.",
    "The classic chickenpox vesicle is described as a DEWDROP ON A ROSE PETAL.",
    "WARNING, THE INFECTIOUS PERIOD: from 24 to 48 hours BEFORE the rash until every lesion has crusted.",
    "So the criterion for ending isolation is CRUSTING, not the passage of a fixed number of days.",
    "Zoster is the same virus reactivating from a sensory ganglion and occupying one dermatome.",
    "A burning pain usually begins days before the vesicles appear and is a classic source of misdiagnosis.",
    "WARNING, AND RAMSAY HUNT SYNDROME: zoster of the geniculate ganglion — ear-canal vesicles plus a seventh nerve palsy.",
    "What separates it from Bell's palsy is exactly those vesicles and the severe ear pain, and it is more urgent.",
    "Complications of chickenpox in adults: varicella pneumonia, cerebellar ataxia, secondary skin infection.",
    "And post-varicella cerebellar ataxia is self-limiting and needs only supportive care.",
]

# ===================================================== VZV POST-EXPOSURE
VZVPEP_FA = [
    "⚠️ **چهار سؤال این فصل درباره‌ی پروفیلاکسی پس از تماس با آبله‌مرغان است و کلید همه آسیکلوویر خوراکی است.**",
    "**دانشجویی که «VZIG برای فرد نقص‌ایمنی» را از منبع قدیمی حفظ کرده، این کلیدها را غلط می‌پندارد.**",
    "**ولی کلیدها با راهنمای امروز سازگارند، و دلیلش ارزش دانستن دارد.**",
    "⚠️ **یک کارآزمایی نشان داد زمان شروع آسیکلوویر تعیین‌کننده است، نه خودِ دارو.**",
    "**شروع فوری پس از تماس شکست خورد: ۱۰ نفر از ۱۳ نفر (۷۷٪) باز هم آبله‌مرغان گرفتند.**",
    "**ولی شروع از روز هفتم مؤثر بود: فقط ۳ نفر از ۱۴ نفر (۲۱٪) بیمار شدند.**",
    "⚠️ **چرا؟ چون آسیکلوویر باید در زمان اوج تکثیر ویروس حاضر باشد، نه پیش از آن.**",
    "**در روزهای اول ویروس هنوز در حال تکثیر نیست و دارو چیزی برای مهار کردن ندارد.**",
    "**پس رژیم استاندارد: آسیکلوویر خوراکی از روز ۷ تا روز ۱۴ پس از تماس.**",
    "**و UKHSA و RCOG آن را انتخاب اول برای زن باردار مستعد در هر سن بارداری کرده‌اند.**",
    "⚠️ **VZIG امروز فقط وقتی است که بیمار نتواند داروی خوراکی بخورد، یا در نوزاد پرخطر.**",
    "**و اگر VZIG داده شود، باید ظرف ۹۶ ساعت باشد و حداکثر تا ۱۰ روز پس از تماس.**",
    "**پنجره‌ی خطرناک نوزادی: تولد از ۵ روز پیش تا ۲ روز پس از شروع آبله‌مرغان مادر.**",
    "⚠️ **و زونای مادر برای نوزاد خطر آبله‌مرغان منتشر ندارد، چون مادر آنتی‌بادی دارد و آن را منتقل کرده است.**",
]
VZVPEP_EN = [
    "WARNING: FOUR QUESTIONS IN THIS CHAPTER ASK ABOUT VARICELLA POST-EXPOSURE PROPHYLAXIS, and all key ORAL ACICLOVIR.",
    "A student who memorised 'VZIG for the immunocompromised' from an older source will think these keys are wrong.",
    "But the keys agree with current guidance, and the reason is worth knowing.",
    "WARNING, A TRIAL SHOWED THAT THE TIMING OF ACICLOVIR IS DECISIVE, not the drug itself.",
    "Starting immediately after exposure FAILED: 10 of 13 (77 per cent) still developed varicella.",
    "But starting on DAY 7 WORKED: only 3 of 14 (21 per cent) became ill.",
    "WARNING, WHY? Because aciclovir must be present at the PEAK of viral replication, not before it.",
    "In the first days the virus is not yet replicating and the drug has nothing to inhibit.",
    "So the standard regimen is ORAL ACICLOVIR FROM DAY 7 TO DAY 14 after exposure.",
    "And UKHSA and the RCOG have made it the FIRST CHOICE for a susceptible pregnant woman at any gestation.",
    "WARNING, VZIG TODAY IS ONLY FOR THOSE WHO CANNOT TAKE ORAL DRUGS, or for a high-risk neonate.",
    "And if VZIG is given it should be within 96 hours, and at the latest within 10 days of exposure.",
    "The dangerous neonatal window: birth from 5 days before to 2 days after the onset of maternal chickenpox.",
    "WARNING, AND MATERNAL ZOSTER CARRIES NO RISK OF DISSEMINATED NEONATAL VARICELLA, because the mother has antibody and has passed it on.",
]

# ===================================================== MEASLES / RUBELLA / MUMPS
MMR_FA = [
    "⚠️ **سرخک را از مخاط بشناسید، نه از راش. لکه‌های کوپلیک تشخیصی‌اند و راش نیست.**",
    "**لکه‌های کوپلیک: نقاط سفید مایل به آبی روی مخاط گونه، در محاذات دندان آسیای دوم.**",
    "**آن‌ها ۱ تا ۲ روز پیش از راش ظاهر می‌شوند و ظرف ۲ روز محو می‌شوند — پنجره‌ی کوتاهی دارند.**",
    "⚠️ **و سه C پیش‌درآمد سرخک: سرفه، کوریزا، کونژنکتیویت — به‌علاوه‌ی تب بالا.**",
    "**راش سرخک ماکولوپاپولر و به‌هم‌پیوسته است و از پیشانی و پشت گوش شروع می‌شود.**",
    "**سپس به پایین گسترش می‌یابد و به همان ترتیب هم محو می‌شود، با پوسته‌ریزی قهوه‌ای.**",
    "**این «انتشار از سر به پایین» با سرخجه مشترک است ولی شدت و سه C آن را جدا می‌کند.**",
    "⚠️ **شایع‌ترین عارضه‌ی سرخک اوتیت مدیای حاد است — شایع‌تر از پنومونی و بسیار شایع‌تر از انسفالیت.**",
    "**ولی شایع‌ترین علت مرگ، پنومونی است. «شایع‌ترین عارضه» با «کشنده‌ترین» فرق دارد.**",
    "**سرخجه: راش خفیف‌تر، تب کمتر، و لنفادنوپاتی پس‌گوشی و پس‌سری که مشخصه‌ی آن است.**",
    "⚠️ **خطر واقعی سرخجه برای جنین است، نه برای خود بیمار — سندرم سرخجه‌ی مادرزادی.**",
    "**و در بارداری، IgG مثبت با IgM منفی یعنی ایمنی قدیمی — یعنی خبر خوب و نیاز به هیچ اقدام.**",
    "**اوریون: تورم دردناک پاروتید، اغلب یک‌طرفه در شروع و سپس دوطرفه.**",
    "⚠️ **و دوره‌ی سرایت اوریون را با ایزولاسیون اشتباه نگیرید: ویروس از ۷ روز پیش تا ۹ روز پس از پاروتیت جدا شده.**",
    "**ولی توصیه‌ی عملی ایزولاسیون امروز ۵ روز پس از شروع پاروتیت است، چون بیشترین سرایت همان‌جاست.**",
]
MMR_EN = [
    "WARNING: RECOGNISE MEASLES FROM THE MUCOSA, NOT THE RASH. Koplik spots are diagnostic and the rash is not.",
    "KOPLIK SPOTS: bluish-white dots on the buccal mucosa, opposite the second molars.",
    "They appear 1 to 2 days BEFORE the rash and fade within 2 days — a short window.",
    "WARNING, AND THE THREE Cs OF THE MEASLES PRODROME: cough, coryza, conjunctivitis — plus high fever.",
    "The measles rash is maculopapular and CONFLUENT, beginning on the forehead and behind the ears.",
    "It then spreads downwards and fades in the same order, with brownish desquamation.",
    "That head-to-toe spread is shared with rubella, but the severity and the three Cs separate them.",
    "WARNING, THE COMMONEST COMPLICATION OF MEASLES IS ACUTE OTITIS MEDIA — commoner than pneumonia and far commoner than encephalitis.",
    "But the commonest CAUSE OF DEATH is pneumonia. 'Commonest complication' is not 'most lethal'.",
    "RUBELLA: a milder rash, less fever, and the characteristic POSTAURICULAR AND SUBOCCIPITAL lymphadenopathy.",
    "WARNING, RUBELLA'S REAL DANGER IS TO THE FETUS, not to the patient — congenital rubella syndrome.",
    "And in pregnancy, IgG positive with IgM negative means OLD IMMUNITY — good news, and no action needed.",
    "MUMPS: painful parotid swelling, often unilateral at onset and then bilateral.",
    "WARNING, DO NOT CONFUSE MUMPS INFECTIVITY WITH ISOLATION: virus has been isolated from 7 days before to 9 days after parotitis.",
    "But today's practical isolation advice is 5 days after parotitis onset, because that is when transmission concentrates.",
]

# ===================================================== HEPATITIS C
HCV_FA = [
    "⚠️ **هپاتیت C دو نشانگر دارد و باید بدانید هرکدام چه سؤالی را جواب می‌دهند.**",
    "**آنتی‌بادی ضد HCV: آیا تماس رخ داده است؟ ولی ۸ تا ۱۲ هفته طول می‌کشد تا مثبت شود.**",
    "**HCV RNA: آیا ویروس همین حالا در خون هست؟ و از ۱ تا ۲ هفته پس از تماس مثبت است.**",
    "⚠️ **پس در عفونت حاد و زودهنگام، آنتی‌بادی منفی است و فقط RNA جواب می‌دهد.**",
    "**همان منطق پنجره‌ای که در HIV یاد گرفتید، این‌بار در بیماری دیگری.**",
    "**و آنتی‌بادی مثبت به‌تنهایی عفونت فعال را ثابت نمی‌کند: در بهبودیافته هم مثبت می‌ماند.**",
    "**حدود ۱۵ تا ۲۵ درصد افراد ویروس را خودبه‌خود پاک می‌کنند ولی آنتی‌بادی‌شان مثبت می‌ماند.**",
    "⚠️ **پس هر آنتی‌بادی مثبت باید با RNA پیگیری شود تا عفونت فعال از عفونت گذشته جدا شود.**",
    "**RIBA یک تست تأییدی قدیمی برای آنتی‌بادی بود و امروز کاملاً کنار گذاشته شده است.**",
    "**چون RNA هم زودتر مثبت می‌شود و هم به سؤال مهم‌تری پاسخ می‌دهد: آیا ویروس فعال است؟**",
    "**و آنتی‌بادی ضد LKM در تابلوی هپاتیت، دو تفسیر دارد و باید هر دو را در نظر گرفت.**",
    "⚠️ **هپاتیت خودایمن تیپ ۲ آن را می‌سازد، ولی در هپاتیت C هم به‌طور غیراختصاصی مثبت می‌شود.**",
    "**پس پیش از تشخیص خودایمنی و شروع سرکوب ایمنی، باید عفونت ویروسی رد شود.**",
    "**و این ترتیب حیاتی است: کورتیکواستروئید در هپاتیت C فعال، تکثیر ویروس را تشدید می‌کند.**",
]
HCV_EN = [
    "WARNING: HEPATITIS C HAS TWO MARKERS, and you must know which question each answers.",
    "ANTI-HCV ANTIBODY: has exposure occurred? But it takes 8 to 12 weeks to turn positive.",
    "HCV RNA: is the virus in the blood right now? And it is positive from 1 to 2 weeks after exposure.",
    "WARNING, SO IN EARLY ACUTE INFECTION THE ANTIBODY IS NEGATIVE and only RNA answers.",
    "The same window logic you learned in HIV, now in a different disease.",
    "And a positive antibody alone does not prove active infection: it stays positive after recovery too.",
    "About 15 to 25 per cent of people clear the virus spontaneously yet remain antibody positive.",
    "WARNING, SO EVERY POSITIVE ANTIBODY MUST BE FOLLOWED BY RNA to separate active from past infection.",
    "RIBA was an old confirmatory antibody test and has been abandoned entirely.",
    "Because RNA turns positive earlier AND answers the more important question: is the virus active?",
    "And an anti-LKM antibody in a hepatitis picture has two readings, both of which must be considered.",
    "WARNING, TYPE 2 AUTOIMMUNE HEPATITIS PRODUCES IT, but it also turns non-specifically positive in hepatitis C.",
    "So before diagnosing autoimmunity and starting immunosuppression, viral infection must be excluded.",
    "And that order is vital: corticosteroids in active hepatitis C accelerate viral replication.",
]


# ================================================== GENITAL ULCER QUESTIONS
add("book:531", "case", "easy",
 "زخم **دردناک و نرم** با لنفادنوپاتی **یک‌طرفه‌ی حساس** ← **شانکروئید**.",
 "A PAINFUL, SOFT ulcer with TENDER UNILATERAL nodes is CHANCROID.",
 ULCER_FA + [
  "**این سؤال هر چهار مشخصه‌ی شانکروئید را در یک جمله جمع کرده است.**",
  "**زخم چرکی · دردناک · نرم · با حاشیه‌ی نامشخص.**",
  "⚠️ **و لنفادنوپاتی اینگوینال یک‌طرفه با تندرنس واضح، امضای شانکروئید است.**",
  "**عاملش هموفیلوس دوکره‌ای است، یک کوکوباسیل گرم منفی که کشتش دشوار است.**",
 ],
 ULCER_EN + [
  "This stem gathers all four features of chancroid into one sentence.",
  "A purulent, painful, soft ulcer with an ill-defined edge.",
  "WARNING, AND UNILATERAL INGUINAL LYMPHADENOPATHY WITH MARKED TENDERNESS is chancroid's signature.",
  "Its cause is Haemophilus ducreyi, a Gram-negative coccobacillus that is difficult to culture.",
 ],
 "این سؤال هر چهار مشخصه‌ی شانکروئید را یک‌جا آورده، و اگر شبکه‌ی درد/قوام را بلد "
 "باشید، در چند ثانیه حل می‌شود.\n\n"
 "**زخم: چرکی · دردناک · نرم · حاشیه‌ی نامشخص.** ⚠️ **لنفادنوپاتی: یک‌طرفه، با "
 "تندرنس واضح.**\n\n"
 "**شبکه‌ی دوبعدی را اجرا کنید:**\n\n"
 "**دردناک است؟ بله** → سیفلیس حذف می‌شود (شانکر سیفلیس **بدون درد** است).\n\n"
 "**نرم است؟ بله** → این تأیید مضاعف است. شانکر سیفلیس **سفت و اندوره** است، تا "
 "جایی که نام دیگر شانکروئید **«شانکر نرم»** است.\n\n"
 "**وزیکولر است؟ خیر** → هرپس حذف می‌شود. هرپس با **وزیکول‌های گروهی** شروع می‌شود.\n\n"
 "**لنفادنوپاتی یک‌طرفه؟ بله** → این آخرین میخ است. ⚠️ **غدد هرپس اولیه دوطرفه‌اند؛ "
 "غدد شانکروئید یک‌طرفه.**\n\n"
 "**پس تشخیص: شانکروئید، ناشی از هموفیلوس دوکره‌ای.**\n\n"
 "**و چرا لنفوگرانولوم ونروم نه؟** ⚠️ این ظریف‌ترین گزینه است، چون LGV هم "
 "**لنفادنوپاتی دردناک** می‌دهد. ولی تفاوت در **خودِ زخم** است: در LGV زخم اولیه "
 "**کوچک، گذرا و بدون درد** است و بیمار اغلب **اصلاً ندیده است** — تابلوی غالب "
 "**غدد** است، نه زخم. اینجا زخم **برجسته، چرکی و دردناک** است.",
 "This stem gathers all four features of chancroid at once, and if you know the pain/consistency "
 "grid it takes seconds.\n\n"
 "THE ULCER: purulent, painful, soft, ill-defined edge. WARNING, THE NODES: unilateral, markedly "
 "tender.\n\n"
 "RUN THE TWO-DIMENSIONAL GRID:\n\n"
 "PAINFUL? YES — syphilis is excluded (its chancre is PAINLESS).\n\n"
 "SOFT? YES — a double confirmation. A syphilitic chancre is HARD AND INDURATED, so much so that "
 "chancroid's other name is SOFT CHANCRE.\n\n"
 "VESICULAR? NO — herpes is excluded; herpes begins with GROUPED VESICLES.\n\n"
 "UNILATERAL NODES? YES — the final nail. WARNING, THE NODES OF PRIMARY HERPES ARE BILATERAL; "
 "THOSE OF CHANCROID ARE UNILATERAL.\n\n"
 "SO THE DIAGNOSIS IS CHANCROID, caused by Haemophilus ducreyi.\n\n"
 "AND WHY NOT LYMPHOGRANULOMA VENEREUM? WARNING, the subtlest option, because LGV also produces "
 "PAINFUL LYMPHADENOPATHY. But the difference lies in THE ULCER ITSELF: in LGV the primary ulcer is "
 "SMALL, TRANSIENT AND PAINLESS and the patient OFTEN NEVER NOTICED IT — the dominant picture is "
 "THE NODES, not the ulcer. Here the ulcer is prominent, purulent and painful.",
 ["هرپس با وزیکول‌های گروهی شروع می‌شود و غدد لنفاوی‌اش دوطرفه و دردناک است، نه یک‌طرفه.",
  "در لنفوگرانولوم ونروم زخم اولیه کوچک و بدون درد است و بیمار اغلب آن را ندیده است.",
  "شانکر سیفلیس بدون درد و سفت است — دقیقاً برعکس این زخم.",
  "پاسخ صحیح — زخم دردناک و نرم با لنفادنوپاتی یک‌طرفه‌ی حساس، تابلوی کلاسیک شانکروئید است."],
 ["Herpes begins with grouped vesicles and its nodes are bilateral and tender, not unilateral.",
  "In lymphogranuloma venereum the primary ulcer is small and painless and often unnoticed.",
  "A syphilitic chancre is painless and indurated — exactly the opposite of this ulcer.",
  "Correct — a painful, soft ulcer with tender unilateral nodes is the classic picture of chancroid."],
 "**سیفلیس بی‌درد و سفت؛ شانکروئید دردناک و نرم؛ هرپس دردناک و وزیکولر.**",
 "Syphilis is painless and hard; chancroid painful and soft; herpes painful and vesicular.",
 [CDC2021, H])

add("book:532", "case", "easy",
 "زخم‌های **عمیق، چرکی و دردناک** که از پوستول شروع شده‌اند + غدد دردناک ← **شانکروئید**.",
 "DEEP, PURULENT, PAINFUL ulcers that began as pustules, with tender nodes: CHANCROID.",
 ULCER_FA + [
  "**این سؤال تکرار همان مفهوم است، ولی با یک سرنخ اضافه: سیر تکاملی ضایعه.**",
  "⚠️ **شانکروئید از پاپول شروع می‌شود، به پوستول تبدیل می‌شود و سپس زخم می‌شود.**",
  "**این سیر پاپول ← پوستول ← زخم، در متن سؤال صریحاً آمده است.**",
  "**و کمون کوتاه آن (۳ تا ۷ روز) با «۱۰ روز پیش» در متن کاملاً هم‌خوان است.**",
  "**در مقابل، کمون سیفلیس حدود ۳ هفته است — یعنی برای این متن خیلی طولانی.**",
 ],
 ULCER_EN + [
  "This item repeats the same concept with one extra clue: the lesion's evolution.",
  "WARNING: CHANCROID BEGINS AS A PAPULE, becomes a PUSTULE, and then ulcerates.",
  "That papule-to-pustule-to-ulcer sequence is stated explicitly in the stem.",
  "And its short incubation (3 to 7 days) fits the stem's '10 days ago' exactly.",
  "By contrast syphilis incubates about 3 weeks — too long for this history.",
 ],
 "**آقای ۲۸ ساله**، تماس محافظت‌نشده **۱۰ روز پیش**، زخم‌های کشاله‌ی ران که "
 "**ابتدا از ۳ روز پیش به‌صورت پوستول‌های متعدد شروع شده‌اند**. زخم‌ها **عمیق، چرکی و "
 "دردناک**، با **لنفادنوپاتی دردناک** همان سمت.\n\n"
 "⚠️ **پاسخ: شانکروئید. و این سؤال یک سرنخ اضافه دارد که سؤال قبلی نداشت — سیر "
 "تکاملی ضایعه.**\n\n"
 "**شانکروئید این مسیر را طی می‌کند: پاپول ← پوستول ← زخم.** متن سؤال دقیقاً همین "
 "را گفته: «ابتدائاً به‌صورت پوستول‌های متعدد شروع شده‌اند».\n\n"
 "**و حالا زمان‌بندی را بررسی کنید، چون سؤال دو تاریخ داده است:**\n\n"
 "**تماس ۱۰ روز پیش، ضایعه از ۳ روز پیش** → یعنی **کمون حدود ۷ روز**.\n\n"
 "⚠️ **این با کمون شانکروئید (۳ تا ۷ روز) کاملاً هم‌خوان است.**\n\n"
 "**و همین زمان‌بندی سیفلیس را رد می‌کند:** کمون شانکر سیفلیس حدود **سه هفته** "
 "(۹ تا ۹۰ روز) است. اگر تماس ۱۰ روز پیش بوده، **برای سیفلیس خیلی زود است**.\n\n"
 "**و چرا تبخال تناسلی نه؟** هرپس **وزیکول** می‌سازد نه **پوستول عمیق**، و "
 "زخم‌هایش **کم‌عمق** است نه عمیق. ضمناً غددش **دوطرفه** است.\n\n"
 "**و لنفوگرانولوم ونروم؟** زخم اولیه‌اش **گذرا و بدون درد** است؛ اینجا زخم‌ها "
 "**برجسته و دردناک**اند.",
 "A 28-YEAR-OLD MAN, unprotected contact 10 DAYS AGO, with right groin ulcers that BEGAN 3 DAYS "
 "AGO AS MULTIPLE PUSTULES. The ulcers are DEEP, PURULENT AND PAINFUL, with TENDER "
 "LYMPHADENOPATHY on the same side.\n\n"
 "WARNING, THE ANSWER: CHANCROID. And this stem carries one extra clue the previous did not — the "
 "LESION'S EVOLUTION.\n\n"
 "CHANCROID FOLLOWS THIS PATH: PAPULE, then PUSTULE, then ULCER. The stem says exactly that: 'they "
 "began as multiple pustules'.\n\n"
 "NOW CHECK THE TIMING, because the stem gives two dates:\n\n"
 "CONTACT 10 DAYS AGO, LESION FOR 3 DAYS — an incubation of about 7 DAYS.\n\n"
 "WARNING, THAT MATCHES CHANCROID'S INCUBATION (3 TO 7 DAYS) EXACTLY.\n\n"
 "AND THE SAME TIMING EXCLUDES SYPHILIS: a syphilitic chancre incubates about THREE WEEKS (9 to 90 "
 "days). With contact 10 days ago it is TOO EARLY FOR SYPHILIS.\n\n"
 "AND WHY NOT GENITAL HERPES? Herpes makes VESICLES, not DEEP PUSTULES, and its ulcers are SHALLOW "
 "rather than deep. Its nodes are also BILATERAL.\n\n"
 "AND LYMPHOGRANULOMA VENEREUM? Its primary ulcer is TRANSIENT AND PAINLESS; here the ulcers are "
 "prominent and painful.",
 ["هرپس وزیکول می‌سازد نه پوستول عمیق، زخم‌هایش کم‌عمق است و غددش دوطرفه.",
  "پاسخ صحیح — سیر پاپول به پوستول به زخم، با کمون حدود ۷ روز، تابلوی شانکروئید است.",
  "کمون سیفلیس حدود سه هفته است؛ با تماس ۱۰ روز پیش خیلی زود است، و شانکرش بدون درد.",
  "در لنفوگرانولوم ونروم زخم اولیه گذرا و بدون درد است، نه عمیق و چرکی."],
 ["Herpes makes vesicles rather than deep pustules, its ulcers are shallow, and its nodes are bilateral.",
  "Correct — a papule-to-pustule-to-ulcer course with about 7 days' incubation is chancroid.",
  "Syphilis incubates about three weeks; 10 days is too early, and its chancre is painless.",
  "In lymphogranuloma venereum the primary ulcer is transient and painless, not deep and purulent."],
 "**کمون ۷ روزه + پوستولی که زخم شد + غدد یک‌طرفه = شانکروئید.**",
 "A 7-day incubation, a pustule that ulcerated, and unilateral nodes: chancroid.",
 [CDC2021, H])

add("book:606", "case", "easy",
 "**چند** زخم دردناک + لنفادنوپاتی **دوطرفه‌ی** دردناک ← **هرپس**، نه شانکروئید.",
 "MULTIPLE painful ulcers with BILATERAL tender nodes means HERPES, not chancroid.",
 ULCER_FA + [
  "**این سؤال قرینه‌ی دو سؤال قبلی است و تفاوتش در یک کلمه است: دوطرفه.**",
  "⚠️ **لنفادنوپاتی دوطرفه‌ی دردناک، هرپس اولیه را از شانکروئید جدا می‌کند.**",
  "**و تعدد زخم‌ها هم به نفع هرپس است: شانکر سیفلیس معمولاً تک است.**",
  "**در حمله‌ی اولیه‌ی هرپس، زخم‌ها از وزیکول‌های گروهی به وجود می‌آیند.**",
  "**پس اگر متن «وزیکول» بگوید تشخیص قطعی است، ولی حتی بدون آن هم الگو کافی است.**",
 ],
 ULCER_EN + [
  "This item mirrors the previous two, and the difference is one word: BILATERAL.",
  "WARNING: BILATERAL TENDER LYMPHADENOPATHY separates primary herpes from chancroid.",
  "And the multiplicity of ulcers also favours herpes: a syphilitic chancre is usually solitary.",
  "In a primary herpes attack the ulcers arise from grouped vesicles.",
  "So if the stem says 'vesicles' the diagnosis is certain, but even without it the pattern suffices.",
 ],
 "**آقای جوان** با **چند زخم دردناک** روی آلت تناسلی و **لنفادنوپاتی اینگوینال "
 "دوطرفه‌ی دردناک**.\n\n"
 "⚠️ **این سؤال قرینه‌ی دو سؤال شانکروئید است، و تفاوتش در یک کلمه است: دوطرفه.**\n\n"
 "**شبکه را اجرا کنید:**\n\n"
 "**دردناک؟ بله** → سیفلیس حذف می‌شود.\n\n"
 "**چند زخم؟ بله** → این هم به ضرر سیفلیس است؛ **شانکر سیفلیس معمولاً تک است**.\n\n"
 "⚠️ **لنفادنوپاتی دوطرفه؟ بله — و این تعیین‌کننده است.**\n\n"
 "**غدد شانکروئید یک‌طرفه‌اند؛ غدد هرپس اولیه دوطرفه.** همین یک کلمه، پاسخ را از "
 "شانکروئید به هرپس می‌برد.\n\n"
 "**و چرا عفونت کلامیدیایی نه؟** کلامیدیا در شکل معمولش **اورتریت** می‌دهد، نه زخم "
 "تناسلی. (سروتیپ‌های L۱ تا L۳ آن **لنفوگرانولوم ونروم** می‌دهند، ولی آنجا هم "
 "**غدد** غالب‌اند و زخم اولیه **بدون درد و گذرا** است.)\n\n"
 "**نکته‌ی بالینی که ورای سؤال است:** در حمله‌ی **اولیه‌ی** هرپس، بیمار معمولاً "
 "**علائم سیستمیک** هم دارد — تب، سردرد، میالژی — چون بدن هنوز آنتی‌بادی ندارد. در "
 "**عودها** این علائم تقریباً وجود ندارند و ضایعات محدودتر و کم‌دردترند.",
 "A YOUNG MAN with SEVERAL PAINFUL ULCERS on the penis and BILATERAL TENDER INGUINAL "
 "LYMPHADENOPATHY.\n\n"
 "WARNING, THIS MIRRORS THE TWO CHANCROID QUESTIONS, and the difference is one word: BILATERAL.\n\n"
 "RUN THE GRID:\n\n"
 "PAINFUL? YES — syphilis is excluded.\n\n"
 "SEVERAL ULCERS? YES — also against syphilis; A SYPHILITIC CHANCRE IS USUALLY SOLITARY.\n\n"
 "WARNING, BILATERAL NODES? YES — AND THAT IS DECISIVE.\n\n"
 "CHANCROID'S NODES ARE UNILATERAL; THE NODES OF PRIMARY HERPES ARE BILATERAL. That single word "
 "moves the answer from chancroid to herpes.\n\n"
 "AND WHY NOT CHLAMYDIAL INFECTION? Chlamydia in its usual form causes URETHRITIS, not a genital "
 "ulcer. (Its L1 to L3 serovars cause LYMPHOGRANULOMA VENEREUM, but there too THE NODES DOMINATE "
 "and the primary ulcer is PAINLESS AND TRANSIENT.)\n\n"
 "A CLINICAL POINT BEYOND THE QUESTION: in a PRIMARY herpes attack the patient usually also has "
 "SYSTEMIC SYMPTOMS — fever, headache, myalgia — because there is no antibody yet. In RECURRENCES "
 "those are virtually absent and the lesions are fewer and less painful.",
 ["شانکر سیفلیس بدون درد، سفت و معمولاً تک است — هر سه ویژگی اینجا نقض شده‌اند.",
  "غدد شانکروئید یک‌طرفه‌اند؛ اینجا لنفادنوپاتی دوطرفه است و این تعیین‌کننده است.",
  "کلامیدیا در شکل معمولش اورتریت می‌دهد نه زخم تناسلی دردناک.",
  "پاسخ صحیح — چند زخم دردناک با لنفادنوپاتی دوطرفه‌ی دردناک، تابلوی هرپس تناسلی است."],
 ["A syphilitic chancre is painless, indurated and usually solitary — all three violated here.",
  "Chancroid's nodes are unilateral; here they are bilateral, and that is decisive.",
  "Chlamydia in its usual form causes urethritis, not a painful genital ulcer.",
  "Correct — multiple painful ulcers with bilateral tender nodes is the picture of genital herpes."],
 "**یک کلمه پاسخ را عوض می‌کند: یک‌طرفه شانکروئید، دوطرفه هرپس.**",
 "One word changes the answer: unilateral means chancroid, bilateral means herpes.",
 [CDC2021, H])

add("book:608", "case", "easy",
 "**وزیکول‌های دردناک** تناسلی + غدد دوطرفه، یک هفته پس از تماس ← **هرپس سیمپلکس**.",
 "PAINFUL GENITAL VESICLES with bilateral nodes a week after exposure: HERPES SIMPLEX.",
 ULCER_FA + [
  "**اینجا متن صریحاً کلمه‌ی «وزیکول» را آورده، و همان کار را تمام می‌کند.**",
  "⚠️ **وزیکول روی زمینه‌ی اریتماتو، امضای هرپس است — هرجای بدن که باشد.**",
  "**هیچ‌کدام از سه گزینه‌ی دیگر ضایعه‌ی وزیکولر نمی‌سازند.**",
  "**تریپونما پالیدوم زخم بدون درد و سفت می‌دهد، نه وزیکول.**",
  "**پاپیلوما ویروس زگیل می‌دهد که برجسته و بدون درد است.**",
  "**و هموفیلوس دوکره‌ای زخم چرکی نرم می‌دهد که از پوستول شروع می‌شود، نه وزیکول.**",
  "**و کمون یک‌هفته‌ای با هرپس (۲ تا ۱۲ روز) کاملاً هم‌خوان است.**",
 ],
 ULCER_EN + [
  "Here the stem uses the word VESICLE outright, and that settles it.",
  "WARNING: A VESICLE ON AN ERYTHEMATOUS BASE IS THE SIGNATURE OF HERPES, wherever on the body it appears.",
  "None of the other three options produces a vesicular lesion.",
  "Treponema pallidum gives a painless indurated ulcer, not a vesicle.",
  "Papillomavirus gives warts, which are raised and painless.",
  "And Haemophilus ducreyi gives a soft purulent ulcer arising from a pustule, not a vesicle.",
  "And a one-week incubation fits herpes (2 to 12 days) exactly.",
 ],
 "**آقای ۳۰ ساله**، یک هفته پس از تماس مشکوک، با **تب**، **سوزش ادرار**، و در معاینه "
 "**ضایعات وزیکولر دردناک** تناسلی به‌همراه **لنفادنوپاتی دوطرفه‌ی دردناک**.\n\n"
 "⚠️ **اینجا متن کلمه‌ی «وزیکول» را صریحاً آورده، و همین کار را تمام می‌کند.**\n\n"
 "**قاعده‌ی طلایی: وزیکول روی زمینه‌ی اریتماتو، امضای هرپس است — هرجای بدن که "
 "ظاهر شود.** و **هیچ‌کدام** از سه گزینه‌ی دیگر ضایعه‌ی وزیکولر نمی‌سازد:\n\n"
 "**تریپونما پالیدوم (سیفلیس)** — زخم **بدون درد و سفت**. نه وزیکول، نه درد.\n\n"
 "**پاپیلوما ویروس (HPV)** — **زگیل تناسلی**: ضایعه‌ی **برجسته، گوشتی و بدون درد**. "
 "و **تب نمی‌دهد**.\n\n"
 "**هموفیلوس دوکره‌ای (شانکروئید)** — زخم **چرکی و نرم** که از **پوستول** شروع "
 "می‌شود، نه وزیکول. و غددش **یک‌طرفه** است، نه دوطرفه.\n\n"
 "**و دو سرنخ تأییدی دیگر در متن:**\n\n"
 "**۱) کمون یک هفته** — با هرپس (۲ تا ۱۲ روز) هم‌خوان است.\n\n"
 "⚠️ **۲) تب** — این نشان می‌دهد **حمله‌ی اولیه** است، نه عود. در حمله‌ی اول بدن "
 "هنوز آنتی‌بادی ندارد، پس **علائم سیستمیک** (تب، سردرد، میالژی) ظاهر می‌شود. در "
 "عودها این علائم تقریباً وجود ندارند.\n\n"
 "**و سوزش ادرار؟** در هرپس تناسلی شایع است و دو علت دارد: **تماس ادرار با زخم‌های "
 "باز**، و گاهی **اورتریت هرپسی** واقعی. این را با اورتریت گونوکوکی اشتباه نگیرید — "
 "آنجا **ترشح چرکی** غالب است و **وزیکولی در کار نیست**.",
 "A 30-YEAR-OLD MAN, one week after a suspicious contact, with FEVER, DYSURIA, and on examination "
 "PAINFUL GENITAL VESICULAR LESIONS with BILATERAL TENDER INGUINAL LYMPHADENOPATHY.\n\n"
 "WARNING, HERE THE STEM USES THE WORD 'VESICLE' OUTRIGHT, and that settles it.\n\n"
 "THE GOLDEN RULE: A VESICLE ON AN ERYTHEMATOUS BASE IS THE SIGNATURE OF HERPES, wherever it "
 "appears. And NONE of the other three options makes a vesicular lesion:\n\n"
 "TREPONEMA PALLIDUM (syphilis) — a PAINLESS, INDURATED ulcer. No vesicle, no pain.\n\n"
 "PAPILLOMAVIRUS (HPV) — GENITAL WARTS: RAISED, FLESHY, PAINLESS lesions. And NO FEVER.\n\n"
 "HAEMOPHILUS DUCREYI (chancroid) — a SOFT PURULENT ulcer arising from a PUSTULE, not a vesicle. "
 "And its nodes are UNILATERAL, not bilateral.\n\n"
 "AND TWO CONFIRMATORY CLUES IN THE STEM:\n\n"
 "1) A ONE-WEEK INCUBATION — consistent with herpes (2 to 12 days).\n\n"
 "WARNING, 2) FEVER — this shows it is a PRIMARY ATTACK rather than a recurrence. In a first attack "
 "there is no antibody yet, so SYSTEMIC SYMPTOMS (fever, headache, myalgia) appear. In recurrences "
 "they are virtually absent.\n\n"
 "AND THE DYSURIA? Common in genital herpes, with two causes: URINE CONTACTING OPEN ULCERS, and "
 "sometimes true HERPETIC URETHRITIS. Do not confuse it with gonococcal urethritis — there a "
 "PURULENT DISCHARGE dominates and THERE ARE NO VESICLES.",
 ["تریپونما پالیدوم زخم بدون درد و سفت می‌دهد، نه وزیکول دردناک.",
  "پاسخ صحیح — وزیکول دردناک با غدد دوطرفه و تب، تابلوی حمله‌ی اولیه‌ی هرپس است.",
  "پاپیلوما ویروس زگیل برجسته و بدون درد می‌دهد و تب هم نمی‌سازد.",
  "هموفیلوس دوکره‌ای زخم چرکی نرم از پوستول می‌سازد و غددش یک‌طرفه است."],
 ["Treponema pallidum gives a painless indurated ulcer, not a painful vesicle.",
  "Correct — painful vesicles with bilateral nodes and fever is a primary herpes attack.",
  "Papillomavirus gives raised painless warts and causes no fever.",
  "Haemophilus ducreyi gives a soft purulent ulcer from a pustule, and its nodes are unilateral."],
 "**وزیکول روی زمینه‌ی اریتماتو = هرپس، هرجای بدن که باشد.**",
 "A vesicle on an erythematous base means herpes, wherever on the body it appears.",
 [CDC2021, H])

add("book:609", "case", "medium",
 "در هرپس تناسلی، **سرولوژی نوع‌اختصاصی** لازم است — تا حمله‌ی **اول** از **عود** جدا شود.",
 "In genital herpes, TYPE-SPECIFIC SEROLOGY is needed — to separate a FIRST ATTACK from a RECURRENCE.",
 ULCER_FA + [
  "**تشخیص در این سؤال از قبل قطعی شده و PCR هم درخواست شده — پس سؤال چیز دیگری می‌خواهد.**",
  "⚠️ **PCR می‌گوید ویروس هست و کدام تیپ است، ولی نمی‌گوید این حمله‌ی اول است یا عود.**",
  "**و سرولوژی دقیقاً همان را می‌گوید، چون آنتی‌بادی زمان می‌برد تا ساخته شود.**",
  "**در حمله‌ی اولِ واقعی، سرولوژی هنوز منفی است؛ در عود، از قبل مثبت است.**",
  "**چرا این تمایز مهم است؟ چون پیش‌آگهی و مشاوره‌ی این دو کاملاً متفاوت است.**",
  "⚠️ **حمله‌ی اول شدیدتر و طولانی‌تر است و در بارداری خطر انتقال به نوزاد را به‌شدت بالا می‌برد.**",
  "**و از نظر روابط، تعیین می‌کند که آیا عفونت تازه است یا سال‌ها نهفته بوده.**",
  "**تیپ ویروس هم مهم است: HSV-2 بسیار بیشتر از HSV-1 عود می‌کند.**",
  "**پس مشاوره درباره‌ی درمان سرکوبگر به همین تیپ‌بندی وابسته است.**",
 ],
 ULCER_EN + [
  "The diagnosis here is already settled and PCR has been requested, so the stem wants something else.",
  "WARNING: PCR SAYS THE VIRUS IS THERE AND WHICH TYPE, but not whether this is a first attack or a recurrence.",
  "And serology says exactly that, because antibody takes time to develop.",
  "In a TRUE first attack the serology is still negative; in a recurrence it is already positive.",
  "Why does the distinction matter? Because the prognosis and the counselling differ completely.",
  "WARNING, A FIRST ATTACK IS MORE SEVERE AND LONGER, and in pregnancy it sharply raises the risk to the neonate.",
  "And in relationship terms it determines whether the infection is new or has been latent for years.",
  "The viral type matters too: HSV-2 recurs far more often than HSV-1.",
  "So counselling about suppressive therapy depends on that typing.",
 ],
 "**خانم ۲۵ ساله** با تب، میالژی و **زخم‌های بسیار دردناک ژنیتال**، و در معاینه "
 "**اولسرهای مخاطی و وزیکول‌های گروهی**. تشخیص **هرپس ژنیتال** گذاشته شده، **PCR** "
 "درخواست شده و **آسیکلوویر** شروع شده است.\n\n"
 "⚠️ **دقت کنید: سؤال تشخیص را نمی‌پرسد — آن از قبل قطعی است. سؤال می‌پرسد چه "
 "بررسی دیگری ضروری است.**\n\n"
 "**پاسخ: تست سرولوژی HSV.**\n\n"
 "**و برای فهمیدن چرایی، باید بدانید هر تست چه سؤالی را جواب می‌دهد:**\n\n"
 "**PCR از محتویات وزیکول** می‌پرسد: **«آیا ویروس اینجاست و کدام تیپ است؟»** — این "
 "حساس‌ترین و سریع‌ترین راه **اثبات** تشخیص است، و از قبل درخواست شده.\n\n"
 "⚠️ **سرولوژی نوع‌اختصاصی** می‌پرسد: **«آیا بدن این بیمار قبلاً این ویروس را "
 "دیده است؟»** — و این سؤال کاملاً متفاوتی است.\n\n"
 "**چرا این تمایز حیاتی است؟ سه دلیل:**\n\n"
 "**۱) پیش‌آگهی.** حمله‌ی **اولِ واقعی** شدیدتر، طولانی‌تر و پرعارضه‌تر است. عودها "
 "خفیف‌تر و کوتاه‌ترند.\n\n"
 "⚠️ **۲) بارداری — و این مهم‌ترین است.** اگر این خانم باردار شود، خطر **هرپس "
 "نوزادی** در **عفونت اولیه‌ی نزدیک زایمان** بسیار بالا (۳۰ تا ۵۰ درصد) و در **عود** "
 "بسیار پایین (کمتر از ۳ درصد) است. **بدون دانستن اینکه این حمله‌ی اول بوده یا نه، "
 "نمی‌توان این خطر را تخمین زد.**\n\n"
 "**۳) مشاوره‌ی رابطه.** سرولوژی منفی یعنی عفونت **تازه** است؛ سرولوژی مثبت یعنی "
 "**سال‌ها نهفته** بوده و حالا فعال شده. این تفاوت برای بیمار و شریک جنسی‌اش معنای "
 "بزرگی دارد.\n\n"
 "**و تیپ‌بندی هم مهم است:** ⚠️ **HSV-2 بسیار بیشتر از HSV-1 عود می‌کند** (به‌طور "
 "متوسط چهار برابر). پس تصمیم درباره‌ی **درمان سرکوبگر طولانی‌مدت** به همین بستگی "
 "دارد.\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟** **ایمونوگلوبولین‌های سرم** بررسی نقص ایمنی هومورال "
 "است و ربطی به هرپس ندارد. **سونوگرافی رحم و ضمائم** و **هیستروسالپنگوگرافی** هر دو "
 "بررسی **ساختاری** دستگاه تناسلی‌اند — برای ناباروری یا توده، نه برای یک عفونت "
 "ویروسی سطحی.",
 "A 25-YEAR-OLD WOMAN with fever, myalgia and VERY PAINFUL GENITAL ULCERS, with MUCOSAL ULCERS AND "
 "GROUPED VESICLES on examination. GENITAL HERPES has been diagnosed, PCR requested and ACICLOVIR "
 "started.\n\n"
 "WARNING, NOTE CAREFULLY: the stem does not ask the diagnosis — that is already settled. It asks "
 "WHAT FURTHER INVESTIGATION IS NECESSARY.\n\n"
 "THE ANSWER: HSV SEROLOGY.\n\n"
 "AND TO SEE WHY, ASK WHAT QUESTION EACH TEST ANSWERS:\n\n"
 "PCR FROM THE VESICLE FLUID asks: 'IS THE VIRUS HERE, AND WHICH TYPE?' — the most sensitive and "
 "fastest way to PROVE the diagnosis, and it has already been requested.\n\n"
 "WARNING, TYPE-SPECIFIC SEROLOGY asks: 'HAS THIS PATIENT'S BODY SEEN THIS VIRUS BEFORE?' — an "
 "entirely different question.\n\n"
 "WHY IS THAT DISTINCTION VITAL? Three reasons:\n\n"
 "1) PROGNOSIS. A TRUE first attack is more severe, longer and more complicated. Recurrences are "
 "milder and shorter.\n\n"
 "WARNING, 2) PREGNANCY — the most important. If she becomes pregnant, the risk of NEONATAL HERPES "
 "is very high with a PRIMARY infection near delivery (30 to 50 per cent) and very low with a "
 "RECURRENCE (under 3 per cent). WITHOUT KNOWING WHETHER THIS WAS A FIRST ATTACK, THAT RISK CANNOT "
 "BE ESTIMATED.\n\n"
 "3) RELATIONSHIP COUNSELLING. Negative serology means the infection is NEW; positive serology "
 "means it has been LATENT FOR YEARS and has now reactivated. That difference means a great deal to "
 "the patient and her partner.\n\n"
 "AND TYPING MATTERS TOO: WARNING, HSV-2 RECURS FAR MORE OFTEN THAN HSV-1 (about fourfold on "
 "average). So the decision about LONG-TERM SUPPRESSIVE THERAPY depends on it.\n\n"
 "AND WHY NOT THE OTHER THREE? SERUM IMMUNOGLOBULINS assess humoral immunodeficiency and are "
 "irrelevant here. PELVIC ULTRASOUND and HYSTEROSALPINGOGRAPHY are both STRUCTURAL studies of the "
 "genital tract — for infertility or a mass, not for a superficial viral infection.",
 ["ایمونوگلوبولین‌های سرم نقص ایمنی هومورال را می‌سنجند و ربطی به هرپس تناسلی ندارند.",
  "سونوگرافی رحم و ضمائم بررسی ساختاری است، نه بررسی یک عفونت ویروسی سطحی.",
  "پاسخ صحیح — سرولوژی نوع‌اختصاصی حمله‌ی اول را از عود جدا می‌کند، که برای بارداری حیاتی است.",
  "هیستروسالپنگوگرافی برای بررسی ناباروری و مجاری است، نه برای هرپس تناسلی."],
 ["Serum immunoglobulins assess humoral immunodeficiency and are irrelevant to genital herpes.",
  "Pelvic ultrasound is a structural study, not an investigation for a superficial viral infection.",
  "Correct — type-specific serology separates a first attack from a recurrence, which is vital for pregnancy.",
  "Hysterosalpingography investigates infertility and tubal patency, not genital herpes."],
 "**PCR می‌گوید ویروس هست؛ سرولوژی می‌گوید این بار اول است یا نه.**",
 "PCR says the virus is there; serology says whether this is the first time.",
 [CDC2021, H])

add("book:610", "case", "medium",
 "ضایعه‌ی **وزیکولوپوستولر انگشت** در کادر درمان، **راجعه** و بی‌پاسخ به آنتی‌بیوتیک ← **ویتلوی هرپسی**.",
 "A VESICULOPUSTULAR FINGER lesion in a health worker, RECURRENT and unresponsive to antibiotics: HERPETIC WHITLOW.",
 ULCER_FA + [
  "**ویتلوی هرپسی، هرپس روی انگشت است — و در کادر درمان و دندان‌پزشک شایع‌تر است.**",
  "⚠️ **سه سرنخ این سؤال را قطعی می‌کنند و هر سه عمداً آمده‌اند.**",
  "**یک — شغل: پرستار بخش مراقبت ویژه، یعنی تماس مکرر با ترشحات دهانی بیماران.**",
  "**دو — بی‌پاسخی به سفالکسین: یعنی عامل باکتریایی نیست.**",
  "⚠️ **سه — و قاطع‌ترین: ضایعه‌ی مشابه در سال گذشته. یعنی عود.**",
  "**عود، ویژگی ذاتی ویروس‌های هرپسی است که در گانگلیون نهفته می‌مانند.**",
  "**باکتری‌ها و قارچ‌ها چنین الگوی عودکننده‌ای در همان محل نمی‌سازند.**",
  "**و لنفادنوپاتی اپی‌تروکلئار، تخلیه‌ی لنفاوی طبیعی انگشتان دوم و سوم است.**",
  "⚠️ **و مهم‌ترین نکته‌ی درمانی: ویتلوی هرپسی را هرگز جراحی و درناژ نکنید.**",
  "**چون عفونت ویروسی است نه آبسه، و برش فقط باعث انتشار و عفونت ثانویه می‌شود.**",
 ],
 ULCER_EN + [
  "Herpetic whitlow is herpes on the finger, commoner in health workers and dentists.",
  "WARNING, THREE CLUES SETTLE THIS QUESTION, and all three are there deliberately.",
  "ONE — the occupation: an intensive-care nurse, meaning repeated contact with patients' oral secretions.",
  "TWO — failure of cephalexin: so the cause is not bacterial.",
  "WARNING, THREE — AND THE MOST DECISIVE: a similar lesion last year. That means RECURRENCE.",
  "Recurrence is intrinsic to herpesviruses, which lie latent in ganglia.",
  "Bacteria and fungi do not produce that recurring pattern at the same site.",
  "And epitrochlear lymphadenopathy is the normal lymphatic drainage of the second and third fingers.",
  "WARNING, AND THE KEY TREATMENT POINT: NEVER INCISE AND DRAIN A HERPETIC WHITLOW.",
  "Because it is a viral infection and not an abscess; incision only spreads it and invites secondary infection.",
 ],
 "**پرستار بخش مراقبت ویژه** با **تب**، **لنفادنوپاتی اپی‌تروکلئار** و **ضایعات "
 "وزیکولوپوستولی انگشت دوم دست راست**، که **به سفالکسین پاسخ نداده** و **سال گذشته "
 "نیز ضایعه‌ی مشابه داشته است**.\n\n"
 "⚠️ **پاسخ: ویروس هرپس سیمپلکس — ویتلوی هرپسی. و سه سرنخ این را قطعی می‌کنند.**\n\n"
 "**سرنخ یک — شغل.** پرستار **بخش مراقبت ویژه**. ⚠️ این شغل تماس مکرر با **ترشحات "
 "دهانی و تنفسی** بیماران دارد — ساکشن کردن، مراقبت از لوله‌ی تراشه، بهداشت دهان. "
 "**ویتلوی هرپسی کلاسیک‌ترین بیماری شغلی همین گروه است**، در کنار دندان‌پزشکان.\n\n"
 "**سرنخ دو — بی‌پاسخی به سفالکسین.** سفالکسین یک سفالوسپورین نسل اول است و "
 "**استافیلوکوک و استرپتوکوک را خوب پوشش می‌دهد** — یعنی عوامل معمول عفونت انگشت "
 "(پاروناشیا، فلگمون). **بی‌پاسخی یعنی عامل باکتریایی نیست.**\n\n"
 "⚠️ **سرنخ سه — و قاطع‌ترین: ضایعه‌ی مشابه در سال گذشته.**\n\n"
 "**عود در همان محل، ویژگی ذاتی ویروس‌های هرپسی است.** پس از عفونت اولیه، ویروس در "
 "**گانگلیون حسی** همان ناحیه نهفته می‌ماند و با استرس، تب یا سرکوب ایمنی دوباره "
 "فعال می‌شود. **باکتری‌ها و قارچ‌ها چنین الگویی نمی‌سازند.**\n\n"
 "**و لنفادنوپاتی اپی‌تروکلئار؟** این غده در **آرنج داخلی** است و **تخلیه‌ی لنفاوی "
 "طبیعی انگشتان دوم و سوم** را بر عهده دارد. پس با محل ضایعه کاملاً هم‌خوان است.\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**پسودوموناس آئروژینوزا** — عفونت‌های ناخن می‌دهد (به‌ویژه در تماس طولانی با آب) "
 "ولی **الگوی عودکننده‌ی سالانه** نمی‌سازد و معمولاً رنگ سبز مشخصی دارد.\n\n"
 "**ویروس واریسلا زوستر** — زونا **یک درماتوم** را می‌گیرد، نه یک انگشت را. و "
 "**معمولاً یک بار** رخ می‌دهد، نه سالانه.\n\n"
 "**آسپرژیلوس فومیگاتوس** — قارچ فرصت‌طلب است و در فرد **ایمن‌سالم** عفونت پوستی "
 "انگشت نمی‌دهد.\n\n"
 "⚠️ **و مهم‌ترین نکته‌ی درمانی که سؤال نپرسیده ولی حیاتی است: ویتلوی هرپسی را "
 "هرگز درناژ نکنید.** برش زدن یک عفونت ویروسی، **ویروس را منتشر می‌کند**، راه ورود "
 "**عفونت ثانویه‌ی باکتریایی** باز می‌کند، و بهبود را **کندتر** می‌کند. درمان "
 "**آسیکلوویر خوراکی** و **پانسمان پوشاننده** برای جلوگیری از انتقال است.",
 "AN INTENSIVE-CARE NURSE with FEVER, EPITROCHLEAR LYMPHADENOPATHY and VESICULOPUSTULAR LESIONS OF "
 "THE RIGHT INDEX FINGER, which HAVE NOT RESPONDED TO CEPHALEXIN and where SHE HAD A SIMILAR LESION "
 "LAST YEAR.\n\n"
 "WARNING, THE ANSWER: HERPES SIMPLEX VIRUS — herpetic whitlow. Three clues settle it.\n\n"
 "CLUE ONE — THE OCCUPATION. An INTENSIVE-CARE nurse. WARNING, that work involves repeated contact "
 "with patients' ORAL AND RESPIRATORY SECRETIONS — suctioning, tracheal tube care, mouth care. "
 "HERPETIC WHITLOW IS THE CLASSIC OCCUPATIONAL DISEASE OF THAT GROUP, alongside dentists.\n\n"
 "CLUE TWO — FAILURE OF CEPHALEXIN. A first-generation cephalosporin covers STAPHYLOCOCCUS AND "
 "STREPTOCOCCUS well — the usual causes of finger infection (paronychia, cellulitis). FAILURE MEANS "
 "THE CAUSE IS NOT BACTERIAL.\n\n"
 "WARNING, CLUE THREE — AND THE MOST DECISIVE: A SIMILAR LESION LAST YEAR.\n\n"
 "RECURRENCE AT THE SAME SITE IS INTRINSIC TO HERPESVIRUSES. After the primary infection the virus "
 "lies latent in the SENSORY GANGLION of that area and reactivates with stress, fever or "
 "immunosuppression. BACTERIA AND FUNGI DO NOT PRODUCE THAT PATTERN.\n\n"
 "AND THE EPITROCHLEAR NODE? It sits at the MEDIAL ELBOW and drains the SECOND AND THIRD FINGERS, "
 "so it matches the lesion's site exactly.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "PSEUDOMONAS AERUGINOSA — causes nail infections (especially with prolonged water exposure) but "
 "does not RECUR ANNUALLY and usually shows a characteristic green discolouration.\n\n"
 "VARICELLA ZOSTER VIRUS — zoster occupies A DERMATOME, not a single finger, and USUALLY OCCURS "
 "ONCE rather than yearly.\n\n"
 "ASPERGILLUS FUMIGATUS — an opportunistic mould that does not cause finger skin infection in an "
 "IMMUNOCOMPETENT person.\n\n"
 "WARNING, AND THE KEY TREATMENT POINT THE QUESTION DOES NOT ASK BUT WHICH IS VITAL: NEVER DRAIN A "
 "HERPETIC WHITLOW. Incising a viral infection SPREADS THE VIRUS, opens a route for SECONDARY "
 "BACTERIAL INFECTION, and SLOWS healing. Treatment is ORAL ACICLOVIR and an OCCLUSIVE DRESSING to "
 "prevent transmission.",
 ["پسودوموناس عفونت ناخن می‌دهد ولی الگوی عودکننده‌ی سالانه در همان محل نمی‌سازد.",
  "زونا یک درماتوم را می‌گیرد، نه یک انگشت را، و معمولاً یک بار رخ می‌دهد نه سالانه.",
  "آسپرژیلوس قارچ فرصت‌طلب است و در فرد ایمن‌سالم عفونت پوستی انگشت نمی‌دهد.",
  "پاسخ صحیح — شغل پرخطر، بی‌پاسخی به آنتی‌بیوتیک و عود سالانه، هر سه به ویتلوی هرپسی اشاره می‌کنند."],
 ["Pseudomonas causes nail infection but does not recur annually at the same site.",
  "Zoster occupies a dermatome rather than one finger, and usually occurs once rather than yearly.",
  "Aspergillus is an opportunistic mould and does not cause finger skin infection in an immunocompetent person.",
  "Correct — the at-risk occupation, antibiotic failure and annual recurrence all point to herpetic whitlow."],
 "**عود در همان محل = ویروس هرپسی. و ویتلو را هرگز درناژ نکنید.**",
 "Recurrence at the same site means a herpesvirus. And never drain a whitlow.",
 [CDC2021, H])


# =========================================================== URETHRITIS QUESTIONS
add("book:534", "case", "medium",
 "ترشح چرکی + **آرتریت و راش** چند روز بعد ← **عفونت گنوکوکی منتشر**، نه سیفلیس ثانویه.",
 "Purulent discharge followed days later by ARTHRITIS AND RASH is DISSEMINATED GONOCOCCAL INFECTION, not secondary syphilis.",
 URETH_FA + [
  "**این سؤال یک عارضه‌ی سیستمیک گونوکوک را می‌آزماید که بسیاری آن را نمی‌شناسند.**",
  "⚠️ **عفونت گنوکوکی منتشر: تب، آرتریت مهاجر، تنوسینوویت و ضایعات پوستی پوستولر.**",
  "**در حدود ۰٫۵ تا ۳ درصد عفونت‌های گونوکوکی رخ می‌دهد و در زنان شایع‌تر است.**",
  "**سه‌گانه‌ی کلاسیکش: تنوسینوویت، درماتیت پوستولر، و پلی‌آرترالژی مهاجر.**",
  "⚠️ **و ترتیب زمانی در این سؤال قاطع است: ترشح ادراری دو روز پیش از علائم سیستمیک.**",
  "**یعنی عفونت از مجرا شروع شده و سپس منتشر شده — همان مسیر عفونت گنوکوکی منتشر.**",
  "**در سیفلیس ثانویه، فاصله‌ی میان شانکر و راش شش هفته تا شش ماه است، نه دو روز.**",
  "**و راش سیفلیس ثانویه کف دست و پا را می‌گیرد و بدون درد و بدون تب بالاست.**",
 ],
 URETH_EN + [
  "This question tests a systemic complication of gonorrhoea that many students do not know.",
  "WARNING: DISSEMINATED GONOCOCCAL INFECTION — fever, migratory arthritis, tenosynovitis and pustular skin lesions.",
  "It occurs in about 0.5 to 3 per cent of gonococcal infections and is commoner in women.",
  "Its classic triad: tenosynovitis, pustular dermatitis and migratory polyarthralgia.",
  "WARNING, AND THE TIME SEQUENCE HERE IS DECISIVE: urethral discharge two days BEFORE the systemic features.",
  "So the infection began in the urethra and then disseminated — exactly the DGI route.",
  "In secondary syphilis the interval between chancre and rash is six weeks to six months, not two days.",
  "And the secondary syphilis rash involves the palms and soles and is painless and without high fever.",
 ],
 "**آقای ۳۰ ساله**، **یک هفته** پس از تماس مشکوک، با **تب**، **درد ژنرالیزه‌ی بدن**، "
 "**راش‌های پوستی منتشر**، و **تورم و محدودیت حرکت در چند مفصل**. و نکته‌ی کلیدی: "
 "**۲ روز پیش از این علائم، ترشح چرکی از مجرای ادرار داشته است**.\n\n"
 "⚠️ **پاسخ: عفونت با گونوکوک — و به‌طور مشخص، عفونت گنوکوکی منتشر (DGI).**\n\n"
 "**بسیاری از دانشجویان گونوکوک را فقط به‌عنوان عامل اورتریت می‌شناسند و نمی‌دانند "
 "می‌تواند منتشر شود. این سؤال دقیقاً همان را می‌آزماید.**\n\n"
 "**سه‌گانه‌ی کلاسیک عفونت گنوکوکی منتشر:**\n\n"
 "**۱) تنوسینوویت** — التهاب غلاف تاندون، به‌ویژه در مچ دست و پا و انگشتان.\n\n"
 "**۲) درماتیت پوستولر** — ضایعات پوستی معدود (معمولاً کمتر از ۳۰ عدد)، پوستولر یا "
 "وزیکولوپوستولر، اغلب روی اندام‌ها.\n\n"
 "**۳) پلی‌آرترالژی مهاجر** — درد مفصلی که از مفصلی به مفصل دیگر جابه‌جا می‌شود.\n\n"
 "⚠️ **و ترتیب زمانی در این سؤال قاطع است: ترشح ادراری دو روز پیش از علائم سیستمیک "
 "شروع شده.** یعنی عفونت **از مجرا شروع شده و سپس به خون راه یافته** — دقیقاً مسیر "
 "DGI.\n\n"
 "**و چرا سیفلیس ثانویه نه؟** ⚠️ این وسوسه‌انگیزترین گزینه است، چون سیفلیس ثانویه هم "
 "**راش منتشر** و **آرترالژی** می‌دهد. ولی **زمان‌بندی آن را کاملاً رد می‌کند**:\n\n"
 "**در سیفلیس، فاصله‌ی میان شانکر اولیه و راش ثانویه شش هفته تا شش ماه است.** اینجا "
 "فاصله **دو روز** است. ضمناً راش سیفلیس ثانویه **کف دست و پا** را می‌گیرد، "
 "**بدون درد** است و با **تب بالا** همراه نیست.\n\n"
 "**و دو گزینه‌ی دیگر؟** **مایکوپلاسما ژنیتالیوم** و **کلامیدیا تراکوماتیس** هر دو "
 "اورتریت **غیرگونوکوکی** می‌دهند: ترشح **کم و مخاطی** به‌جای فراوان و چرکی. و "
 "**هیچ‌کدام این تابلوی سیستمیک منتشر را نمی‌سازند**. (کلامیدیا می‌تواند **آرتریت "
 "واکنشی** بدهد، ولی آن **هفته‌ها بعد** می‌آید و با **کونژنکتیویت و اورتریت** همراه "
 "است و **کشت خون منفی** دارد.)",
 "A 30-YEAR-OLD MAN, ONE WEEK after a suspicious contact, with FEVER, GENERALISED BODY PAIN, a "
 "WIDESPREAD SKIN RASH and SWELLING AND RESTRICTED MOVEMENT IN SEVERAL JOINTS. And the key point: "
 "TWO DAYS BEFORE these symptoms he had a PURULENT URETHRAL DISCHARGE.\n\n"
 "WARNING, THE ANSWER: gonococcal infection — specifically DISSEMINATED GONOCOCCAL INFECTION (DGI).\n\n"
 "Many students know the gonococcus only as a cause of urethritis and do not know it can "
 "disseminate. This question tests exactly that.\n\n"
 "THE CLASSIC TRIAD OF DGI:\n\n"
 "1) TENOSYNOVITIS — inflammation of tendon sheaths, especially at the wrists, ankles and fingers.\n\n"
 "2) PUSTULAR DERMATITIS — few skin lesions (usually fewer than 30), pustular or vesiculopustular, "
 "mostly on the limbs.\n\n"
 "3) MIGRATORY POLYARTHRALGIA — joint pain moving from one joint to another.\n\n"
 "WARNING, AND THE TIME SEQUENCE HERE IS DECISIVE: the urethral discharge began TWO DAYS BEFORE the "
 "systemic features. So the infection STARTED IN THE URETHRA AND THEN ENTERED THE BLOOD — exactly "
 "the DGI route.\n\n"
 "AND WHY NOT SECONDARY SYPHILIS? WARNING, the most tempting option, because secondary syphilis "
 "also causes a WIDESPREAD RASH and ARTHRALGIA. But THE TIMING RULES IT OUT COMPLETELY:\n\n"
 "IN SYPHILIS THE INTERVAL BETWEEN THE PRIMARY CHANCRE AND THE SECONDARY RASH IS SIX WEEKS TO SIX "
 "MONTHS. Here it is TWO DAYS. The secondary syphilis rash also involves the PALMS AND SOLES, is "
 "PAINLESS and is not accompanied by HIGH FEVER.\n\n"
 "AND THE OTHER TWO? MYCOPLASMA GENITALIUM and CHLAMYDIA TRACHOMATIS both cause NON-GONOCOCCAL "
 "urethritis: SCANT MUCOID discharge rather than profuse and purulent. And NEITHER PRODUCES THIS "
 "DISSEMINATED SYSTEMIC PICTURE. (Chlamydia can cause REACTIVE ARTHRITIS, but that comes WEEKS "
 "later, is accompanied by CONJUNCTIVITIS AND URETHRITIS, and has NEGATIVE BLOOD CULTURES.)",
 ["زمان‌بندی آن را رد می‌کند — فاصله‌ی شانکر تا راش ثانویه شش هفته تا شش ماه است، نه دو روز.",
  "پاسخ صحیح — ترشح چرکی و سپس آرتریت و راش پوستولر، تابلوی عفونت گنوکوکی منتشر است.",
  "مایکوپلاسما ژنیتالیوم اورتریت غیرگونوکوکی با ترشح مخاطی می‌دهد و منتشر نمی‌شود.",
  "کلامیدیا آرتریت واکنشی می‌دهد ولی هفته‌ها بعد، با کونژنکتیویت، و کشت خون منفی."],
 ["The timing rules it out — chancre to secondary rash is six weeks to six months, not two days.",
  "Correct — purulent discharge followed by arthritis and a pustular rash is disseminated gonococcal infection.",
  "Mycoplasma genitalium causes non-gonococcal urethritis with mucoid discharge and does not disseminate.",
  "Chlamydia causes reactive arthritis, but weeks later, with conjunctivitis, and with negative blood cultures."],
 "**گونوکوک فقط اورتریت نیست — می‌تواند منتشر شود و آرتریت و راش پوستولر بدهد.**",
 "The gonococcus is not only urethritis: it can disseminate and cause arthritis and a pustular rash.",
 [CDC2021, H])

add("book:537", "case", "hard",
 "عفونت گنوکوکی منتشر **سه بار در یک سال** ← نقص **کمپلمان انتهایی (C5 تا C9)**.",
 "Disseminated gonococcal infection THREE TIMES IN A YEAR means a TERMINAL COMPLEMENT (C5 to C9) deficiency.",
 URETH_FA + [
  "**این سؤال از عفونت گنوکوکی منتشر شروع می‌شود ولی به ایمنی‌شناسی می‌رسد.**",
  "⚠️ **کلمه‌ی کلیدی: «برای سومین بار طی یک سال». عود، سؤال را عوض می‌کند.**",
  "**یک بار عفونت گنوکوکی منتشر می‌تواند اتفاق باشد؛ سه بار یعنی نقص میزبان.**",
  "**نایسریاها یک آسیب‌پذیری منحصربه‌فرد دارند که هیچ باکتری دیگری ندارد.**",
  "⚠️ **کشتن نایسریا نیازمند کمپلکس حمله به غشا است: اجزای C5 تا C9.**",
  "**چون نایسریا یک دیپلوکوک گرم منفی است و فاگوسیتوز به‌تنهایی برای کشتنش کافی نیست.**",
  "**پس فرد با نقص کمپلمان انتهایی، عفونت‌های نایسریایی مکرر می‌گیرد.**",
  "**و این تقریباً تنها تظاهر بالینی آن نقص است — در بقیه‌ی موارد فرد سالم است.**",
  "⚠️ **در مقابل، نقص C1 تا C4 (مسیر کلاسیک زودرس) تابلوی کاملاً متفاوتی دارد.**",
  "**آن‌ها لوپوس‌مانند و عفونت با باکتری‌های کپسول‌دار می‌دهند، نه نایسریای مکرر.**",
  "**تست غربالگری مناسب CH50 است، که کل مسیر کلاسیک را می‌سنجد.**",
  "**و این افراد باید واکسن مننگوکوک بگیرند، چون در خطر مننژیت مکررند.**",
 ],
 URETH_EN + [
  "This question starts from disseminated gonococcal infection but ends in immunology.",
  "WARNING, THE KEY PHRASE: 'for the third time this year'. Recurrence changes the question.",
  "One episode of DGI can be chance; three means a HOST DEFECT.",
  "The Neisseriae have a unique vulnerability that no other bacterium shares.",
  "WARNING: KILLING NEISSERIA REQUIRES THE MEMBRANE ATTACK COMPLEX — components C5 to C9.",
  "Because Neisseria is a Gram-negative diplococcus and phagocytosis alone does not kill it.",
  "So someone with a terminal complement deficiency gets RECURRENT NEISSERIAL INFECTIONS.",
  "And that is almost the only clinical manifestation of the defect — otherwise they are well.",
  "WARNING, BY CONTRAST, A C1 TO C4 DEFECT (the early classical pathway) gives a completely different picture.",
  "Those cause lupus-like disease and infection with encapsulated bacteria, not recurrent Neisseria.",
  "The appropriate screening test is CH50, which measures the whole classical pathway.",
  "And such people must receive meningococcal vaccine, because they are at risk of recurrent meningitis.",
 ],
 "**خانم ۲۰ ساله** که **برای سومین بار طی یک سال گذشته** دچار **تب، پلی‌آرتریت مفاصل "
 "کوچک، و ضایعات پوستولر** شده، و **کشت خونش دیپلوکوک گرم منفی** رشد داده است.\n\n"
 "**اول تشخیص: این عفونت گنوکوکی منتشر است** — دیپلوکوک گرم منفی در کشت خون، به‌همراه "
 "سه‌گانه‌ی آرتریت و ضایعات پوستولر.\n\n"
 "⚠️ **ولی سؤال تشخیص را نمی‌پرسد. سؤال می‌پرسد چه بررسی دیگری لازم است — و کلمه‌ی "
 "کلیدی «برای سومین بار طی یک سال» است.**\n\n"
 "**یک بار عفونت گنوکوکی منتشر می‌تواند بدشانسی باشد. سه بار در یک سال یعنی چیزی در "
 "خودِ میزبان اشکال دارد.**\n\n"
 "**و اینجا یکی از زیباترین مفاهیم ایمنی‌شناسی بالینی مطرح می‌شود:**\n\n"
 "⚠️ **نایسریاها یک آسیب‌پذیری منحصربه‌فرد دارند که هیچ باکتری دیگری ندارد: کشتن "
 "آن‌ها نیازمند کمپلکس حمله به غشا (MAC) است.**\n\n"
 "**چرا؟** چون نایسریا یک **دیپلوکوک گرم منفی** است و **فاگوسیتوز به‌تنهایی برای "
 "کشتنش کافی نیست**. بدن باید غشایش را **سوراخ کند** — و این کار **اجزای C5 تا C9** "
 "کمپلمان است که با هم MAC را می‌سازند.\n\n"
 "**پس فرد با نقص کمپلمان انتهایی (C5-C9):**\n\n"
 "**در برابر همه‌چیز سالم است، بجز نایسریا.** عفونت‌های **گنوکوکی منتشر مکرر** و "
 "**مننگوکوکسمی مکرر** می‌گیرد. ⚠️ **و این تقریباً تنها تظاهر بالینی آن نقص است.**\n\n"
 "**و چرا سنجش C1 تا C3 نه؟** این‌ها **مسیر کلاسیک زودرس**اند و نقصشان تابلوی "
 "**کاملاً متفاوتی** دارد:\n\n"
 "**نقص C1، C2، C4** → بیماری **لوپوس‌مانند** (چون پاکسازی کمپلکس‌های ایمنی مختل "
 "می‌شود) و عفونت با **باکتری‌های کپسول‌دار** (پنوموکوک، هموفیلوس).\n\n"
 "**نقص C3** → عفونت‌های **چرکی شدید و مکرر** با باکتری‌های کپسول‌دار، از کودکی.\n\n"
 "**هیچ‌کدام الگوی «نایسریای مکرر» نمی‌سازند.**\n\n"
 "**و دو گزینه‌ی دیگر؟** **ایمونوگلوبولین‌های سرم** نقص هومورال را می‌سنجند، که "
 "**عفونت با کپسول‌دارها** می‌دهد نه نایسریای مکرر. **HIV** یک بررسی معقول در هر STI "
 "است، ولی **HIV الگوی عفونت گنوکوکی منتشر مکرر نمی‌سازد** — الگوی آن **عفونت‌های "
 "فرصت‌طلب** است.\n\n"
 "**و نتیجه‌ی عملی:** تست غربالگری مناسب **CH50** است، و این بیمار باید **واکسن "
 "مننگوکوک** بگیرد، چون در خطر **مننژیت مننگوکوکی مکرر** است.",
 "A 20-YEAR-OLD WOMAN who FOR THE THIRD TIME THIS YEAR has developed FEVER, SMALL-JOINT "
 "POLYARTHRITIS and PUSTULAR SKIN LESIONS, and whose BLOOD CULTURE grew a GRAM-NEGATIVE DIPLOCOCCUS.\n\n"
 "FIRST THE DIAGNOSIS: this is DISSEMINATED GONOCOCCAL INFECTION — a Gram-negative diplococcus in "
 "blood culture with the triad of arthritis and pustular lesions.\n\n"
 "WARNING, BUT THE STEM DOES NOT ASK THE DIAGNOSIS. It asks what FURTHER INVESTIGATION is needed — "
 "and the key phrase is 'FOR THE THIRD TIME THIS YEAR'.\n\n"
 "ONE EPISODE OF DGI CAN BE BAD LUCK. THREE IN A YEAR MEANS SOMETHING IS WRONG WITH THE HOST.\n\n"
 "And here one of the most elegant concepts in clinical immunology appears:\n\n"
 "WARNING: THE NEISSERIAE HAVE A UNIQUE VULNERABILITY NO OTHER BACTERIUM SHARES — KILLING THEM "
 "REQUIRES THE MEMBRANE ATTACK COMPLEX (MAC).\n\n"
 "WHY? Because Neisseria is a GRAM-NEGATIVE DIPLOCOCCUS and PHAGOCYTOSIS ALONE DOES NOT KILL IT. "
 "The body must PUNCH THROUGH ITS MEMBRANE — and that is the job of COMPLEMENT COMPONENTS C5 TO C9, "
 "which together form the MAC.\n\n"
 "SO SOMEONE WITH A TERMINAL COMPLEMENT DEFICIENCY (C5-C9):\n\n"
 "IS HEALTHY AGAINST EVERYTHING EXCEPT NEISSERIA. They get RECURRENT DISSEMINATED GONOCOCCAL "
 "INFECTION and RECURRENT MENINGOCOCCAEMIA. WARNING, AND THAT IS ALMOST THE ONLY CLINICAL "
 "MANIFESTATION OF THE DEFECT.\n\n"
 "AND WHY NOT MEASURING C1 TO C3? Those are the EARLY CLASSICAL PATHWAY and their deficiencies give "
 "a COMPLETELY DIFFERENT picture:\n\n"
 "C1, C2, C4 DEFICIENCY — a LUPUS-LIKE disease (because immune-complex clearance fails) and "
 "infection with ENCAPSULATED bacteria (pneumococcus, Haemophilus).\n\n"
 "C3 DEFICIENCY — SEVERE RECURRENT PYOGENIC infections with encapsulated bacteria, from childhood.\n\n"
 "NEITHER PRODUCES THE 'RECURRENT NEISSERIA' PATTERN.\n\n"
 "AND THE OTHER TWO? SERUM IMMUNOGLOBULINS assess humoral deficiency, which causes ENCAPSULATED "
 "bacterial infection, not recurrent Neisseria. HIV testing is reasonable in any STI, but HIV DOES "
 "NOT PRODUCE RECURRENT DGI — its pattern is OPPORTUNISTIC INFECTION.\n\n"
 "AND THE PRACTICAL CONSEQUENCE: the appropriate screening test is CH50, and this patient must "
 "receive MENINGOCOCCAL VACCINE, because she is at risk of RECURRENT MENINGOCOCCAL MENINGITIS.",
 ["ایمونوگلوبولین‌های سرم نقص هومورال را می‌سنجند، که عفونت با کپسول‌دارها می‌دهد نه نایسریای مکرر.",
  "بررسی HIV در هر STI معقول است، ولی HIV الگوی عفونت گنوکوکی منتشر مکرر نمی‌سازد.",
  "نقص C1 تا C3 بیماری لوپوس‌مانند و عفونت با کپسول‌دارها می‌دهد، نه نایسریای مکرر.",
  "پاسخ صحیح — کشتن نایسریا به کمپلکس حمله به غشا (C5 تا C9) نیاز دارد، پس نقص آن عفونت مکرر می‌دهد."],
 ["Serum immunoglobulins assess humoral deficiency, which causes encapsulated infection, not recurrent Neisseria.",
  "HIV testing is reasonable in any STI, but HIV does not produce recurrent disseminated gonococcal infection.",
  "A C1 to C3 defect gives lupus-like disease and encapsulated infection, not recurrent Neisseria.",
  "Correct — killing Neisseria requires the membrane attack complex (C5 to C9), so its deficiency causes recurrence."],
 "**نایسریای مکرر = نقص کمپلمان انتهایی. هیچ باکتری دیگری این الگو را نمی‌سازد.**",
 "Recurrent Neisseria means a terminal complement deficiency; no other bacterium makes that pattern.",
 [CDC2021, H])

add("book:551", "case", "medium",
 "کوکوباسیل گرم منفی **غیرمتحرک** در سواب حلق پس از تماس جنسی ← **فارنژیت گنوکوکی** ← سفتریاکسون.",
 "A NON-MOTILE Gram-negative coccobacillus from a throat swab after sexual contact: GONOCOCCAL PHARYNGITIS, treated with ceftriaxone.",
 URETH_FA + [
  "**فارنژیت گنوکوکی وجود دارد و اغلب فراموش می‌شود، چون معمولاً بی‌علامت است.**",
  "⚠️ **پس از تماس دهانی-تناسلی رخ می‌دهد و در غربالگری‌های معمول دیده نمی‌شود.**",
  "**و درمانش از فارنژیت استرپتوکوکی کاملاً متفاوت است — پنی‌سیلین کار نمی‌کند.**",
  "**سفتریاکسون داروی انتخابی است، و فارنژیت گنوکوکی سخت‌تر از اورتریت ریشه‌کن می‌شود.**",
  "⚠️ **به همین دلیل CDC برای فارنژیت گنوکوکی تست درمان (test of cure) توصیه می‌کند.**",
  "**در حالی که برای اورتریت و سرویسیت گنوکوکی چنین توصیه‌ای وجود ندارد.**",
  "**علتش نفوذ کمتر آنتی‌بیوتیک به بافت حلق و فلور رقیب فراوان آنجاست.**",
  "**و همیشه باید کلامیدیا هم پوشش داده شود، چون هم‌زمانی شایع است.**",
 ],
 URETH_EN + [
  "Gonococcal pharyngitis exists and is often forgotten, because it is usually asymptomatic.",
  "WARNING: it follows oro-genital contact and is missed by routine screening.",
  "And its treatment differs entirely from streptococcal pharyngitis — penicillin does not work.",
  "Ceftriaxone is the drug of choice, and pharyngeal gonorrhoea is harder to eradicate than urethral.",
  "WARNING, THAT IS WHY THE CDC RECOMMENDS A TEST OF CURE for gonococcal pharyngitis.",
  "Whereas no such recommendation exists for gonococcal urethritis or cervicitis.",
  "The reason is poorer antibiotic penetration into pharyngeal tissue and the abundant competing flora.",
  "And chlamydia must always be covered too, because coinfection is common.",
 ],
 "**خانم جوان** با **فارنژیت اگزوداتیو** و **لنفادنوپاتی گردنی حساس**، با سابقه‌ی "
 "**تماس جنسی محافظت‌نشده طی هفته‌ی اخیر**. در سواب نازوفارنکس: **کوکوباسیل‌های گرم "
 "منفی غیرمتحرک، تک‌تک یا جفتی**.\n\n"
 "⚠️ **پاسخ: سفتریاکسون — چون این فارنژیت گنوکوکی است.**\n\n"
 "**و اول باید بپذیریم که این تشخیص اصلاً به ذهن بیشتر دانشجویان نمی‌رسد. فارنژیت "
 "اگزوداتیو در ذهن همه یعنی استرپتوکوک. ولی سه سرنخ این را عوض می‌کنند:**\n\n"
 "**۱) سابقه‌ی تماس جنسی محافظت‌نشده در هفته‌ی اخیر** — بدون این جمله، تشخیص عوض "
 "می‌شد. طراح آن را عمداً گذاشته است.\n\n"
 "**۲) توصیف میکروبیولوژیک: «کوکوباسیل گرم منفی، جفتی».** ⚠️ **استرپتوکوک گرم "
 "مثبت و زنجیره‌ای است** — پس با یک نگاه رد می‌شود. توصیف **گرم منفی و جفتی** به "
 "**نایسریا گنوره** اشاره دارد.\n\n"
 "**۳) کمون کوتاه** — تماس در هفته‌ی اخیر، با کمون گونوکوک (۲ تا ۷ روز) هم‌خوان است.\n\n"
 "**فارنژیت گنوکوکی چیست و چرا مهم است؟**\n\n"
 "پس از **تماس دهانی-تناسلی** رخ می‌دهد. ⚠️ **و نکته‌ی مهم بهداشت عمومی این است که "
 "معمولاً بی‌علامت است** — یعنی افراد زیادی آن را دارند و نمی‌دانند، و به‌عنوان "
 "**مخزن انتقال** عمل می‌کنند.\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**داکسی‌سیکلین** — کلامیدیا را پوشش می‌دهد ولی **برای گونوکوک ناکافی** است "
 "(مقاومت گسترده).\n\n"
 "**جنتامایسین** — یک آمینوگلیکوزید که در برخی راهنماها به‌عنوان **جایگزین** در "
 "آلرژی شدید به سفالوسپورین آمده، ولی **انتخاب اول نیست** و در فارنژیت اثربخشی "
 "کمتری دارد.\n\n"
 "**اسپکتینومایسین** — زمانی جایگزین بود، ولی ⚠️ **در فارنژیت گنوکوکی اثربخشی ضعیفی "
 "دارد** (حدود ۵۲ درصد) و امروز در بسیاری از کشورها در دسترس نیست.\n\n"
 "⚠️ **و یک نکته‌ی عملی مهم: فارنژیت گنوکوکی سخت‌تر از اورتریت ریشه‌کن می‌شود**، چون "
 "نفوذ آنتی‌بیوتیک به بافت حلق کمتر است و فلور رقیب فراوان است. **به همین دلیل CDC "
 "برای آن «تست درمان» توصیه می‌کند** — کاری که برای اورتریت گنوکوکی توصیه نمی‌شود.",
 "A YOUNG WOMAN with EXUDATIVE PHARYNGITIS and TENDER CERVICAL LYMPHADENOPATHY, with a history of "
 "UNPROTECTED SEXUAL CONTACT IN THE PAST WEEK. Her nasopharyngeal swab grows NON-MOTILE "
 "GRAM-NEGATIVE COCCOBACILLI, singly or in pairs.\n\n"
 "WARNING, THE ANSWER: CEFTRIAXONE — because this is GONOCOCCAL PHARYNGITIS.\n\n"
 "First we must admit this diagnosis does not occur to most students. Exudative pharyngitis means "
 "streptococcus to everyone. But three clues change that:\n\n"
 "1) A HISTORY OF UNPROTECTED SEXUAL CONTACT IN THE PAST WEEK — without that sentence the diagnosis "
 "would be different. The examiner placed it deliberately.\n\n"
 "2) THE MICROBIOLOGY: 'Gram-negative coccobacilli, in pairs'. WARNING, STREPTOCOCCUS IS "
 "GRAM-POSITIVE AND FORMS CHAINS — so it is excluded at a glance. GRAM-NEGATIVE AND PAIRED points "
 "to NEISSERIA GONORRHOEAE.\n\n"
 "3) A SHORT INCUBATION — contact in the past week fits gonorrhoea (2 to 7 days).\n\n"
 "WHAT IS GONOCOCCAL PHARYNGITIS AND WHY DOES IT MATTER?\n\n"
 "It follows ORO-GENITAL CONTACT. WARNING, AND THE PUBLIC HEALTH POINT IS THAT IT IS USUALLY "
 "ASYMPTOMATIC — so many people carry it unknowingly and act as a RESERVOIR FOR TRANSMISSION.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "DOXYCYCLINE — covers chlamydia but is INADEQUATE FOR GONORRHOEA (widespread resistance).\n\n"
 "GENTAMICIN — an aminoglycoside listed in some guidelines as an ALTERNATIVE in severe "
 "cephalosporin allergy, but NOT FIRST CHOICE and less effective in pharyngeal disease.\n\n"
 "SPECTINOMYCIN — once an alternative, but WARNING, IT PERFORMS POORLY IN GONOCOCCAL PHARYNGITIS "
 "(about 52 per cent) and is unavailable in many countries today.\n\n"
 "WARNING, AND AN IMPORTANT PRACTICAL POINT: PHARYNGEAL GONORRHOEA IS HARDER TO ERADICATE THAN "
 "URETHRAL, because antibiotic penetration into pharyngeal tissue is poorer and competing flora are "
 "abundant. THAT IS WHY THE CDC RECOMMENDS A TEST OF CURE FOR IT — which it does not for gonococcal "
 "urethritis.",
 ["داکسی‌سیکلین کلامیدیا را پوشش می‌دهد ولی برای گونوکوک به‌دلیل مقاومت گسترده ناکافی است.",
  "پاسخ صحیح — کوکوباسیل گرم منفی جفتی پس از تماس جنسی یعنی فارنژیت گنوکوکی، و درمانش سفتریاکسون است.",
  "جنتامایسین فقط جایگزین در آلرژی شدید است و در فارنژیت اثربخشی کمتری دارد.",
  "اسپکتینومایسین در فارنژیت گنوکوکی اثربخشی ضعیفی دارد و امروز کم‌دسترس است."],
 ["Doxycycline covers chlamydia but is inadequate for gonorrhoea because of widespread resistance.",
  "Correct — paired Gram-negative coccobacilli after sexual contact means gonococcal pharyngitis, treated with ceftriaxone.",
  "Gentamicin is only an alternative in severe allergy and is less effective in pharyngeal disease.",
  "Spectinomycin performs poorly in gonococcal pharyngitis and is little available today."],
 "**فارنژیت اگزوداتیو + سابقه‌ی جنسی + گرم منفی جفتی = گونوکوک، نه استرپتوکوک.**",
 "Exudative pharyngitis plus a sexual history plus paired Gram-negatives means gonococcus, not streptococcus.",
 [CDC2021, H])

add("book:554", "case", "medium",
 "**اپیدیدیمیت** در مرد جوان فعال جنسی ← **سفتریاکسون + داکسی‌سیکلین**، هر دو با هم.",
 "EPIDIDYMITIS in a sexually active young man: CEFTRIAXONE PLUS DOXYCYCLINE, both together.",
 URETH_FA + [
  "**درد و تورم یک‌طرفه‌ی بیضه با سابقه‌ی ترشح مجرا، یعنی اپیدیدیمیت با منشأ جنسی.**",
  "⚠️ **و علت آن در مرد زیر ۳۵ سال، تقریباً همیشه گونوکوک یا کلامیدیا یا هر دو است.**",
  "**پس درمان باید هر دو را بپوشاند، دقیقاً مثل اورتریت.**",
  "**سفتریاکسون گونوکوک را می‌گیرد و داکسی‌سیکلین کلامیدیا را.**",
  "⚠️ **و در اپیدیدیمیت، داکسی‌سیکلین ۱۰ روز داده می‌شود، نه ۷ روز اورتریت.**",
  "**چون بافت بیضه عمیق‌تر است و نفوذ دارو زمان بیشتری می‌طلبد.**",
  "**در مرد بالای ۳۵ سال یا با رفتار جنسی مقعدی، انتروباکتریاسه هم باید پوشش داده شود.**",
  "**و مهم‌ترین تشخیص افتراقی که هرگز نباید فراموش شود، تورشن بیضه است.**",
  "⚠️ **تورشن یک اورژانس جراحی است و پنجره‌ی نجات بیضه فقط چند ساعت است.**",
  "**سیر یک‌هفته‌ای در این بیمار به نفع عفونت است، چون تورشن سیر ساعتی دارد.**",
 ],
 URETH_EN + [
  "Unilateral testicular pain and swelling with a history of urethral discharge means sexually acquired epididymitis.",
  "WARNING, AND IN A MAN UNDER 35 THE CAUSE IS ALMOST ALWAYS GONORRHOEA OR CHLAMYDIA OR BOTH.",
  "So treatment must cover both, exactly as in urethritis.",
  "Ceftriaxone covers the gonococcus and doxycycline covers chlamydia.",
  "WARNING, AND IN EPIDIDYMITIS DOXYCYCLINE IS GIVEN FOR 10 DAYS, not the 7 of urethritis.",
  "Because testicular tissue is deeper and drug penetration takes longer.",
  "In a man over 35, or with insertive anal intercourse, Enterobacteriaceae must also be covered.",
  "And the differential that must never be forgotten is TESTICULAR TORSION.",
  "WARNING, TORSION IS A SURGICAL EMERGENCY and the window to save the testis is only hours.",
  "The one-week course here favours infection, because torsion evolves over hours.",
 ],
 "**بیمار جوان ۲۴ ساله** با **درد و تورم یک‌طرفه‌ی بیضه‌ی راست از یک هفته پیش**، و در "
 "شرح حال **سابقه‌ی ترشح از نوک مه‌آ (مجرا)**.\n\n"
 "⚠️ **پاسخ: سفتریاکسون + داکسی‌سیکلین.**\n\n"
 "**تشخیص: اپیدیدیمیت با منشأ جنسی.** و **سابقه‌ی ترشح مجرا** همان چیزی است که "
 "منشأ آن را روشن می‌کند.\n\n"
 "**اصل حاکم را از اورتریت به یاد بیاورید:** ⚠️ **در مرد زیر ۳۵ سال، اپیدیدیمیت "
 "تقریباً همیشه گونوکوک یا کلامیدیا یا هر دو است.** پس درمان باید **هر دو را "
 "بپوشاند** — همان منطق درمان دوگانه‌ی اورتریت.\n\n"
 "**سفتریاکسون** → گونوکوک. **داکسی‌سیکلین** → کلامیدیا. ✅\n\n"
 "⚠️ **و یک تفاوت مهم با اورتریت: مدت درمان.** در اورتریت داکسی‌سیکلین **۷ روز** "
 "داده می‌شود؛ در اپیدیدیمیت **۱۰ روز**. **چرا؟** چون بافت بیضه و اپیدیدیم **عمیق‌تر** "
 "است و نفوذ دارو زمان بیشتری می‌طلبد.\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟** ⚠️ **هر سه یک اشکال مشترک دارند: فلوروکینولون یا "
 "سفکسیم، که هیچ‌کدام برای گونوکوک قابل اتکا نیستند.**\n\n"
 "**افلوکساسین + آزیترومایسین** — افلوکساسین یک فلوروکینولون است، و **CDC از سال "
 "۲۰۰۷ فلوروکینولون‌ها را برای گونوکوک کنار گذاشت** به‌دلیل مقاومت گسترده.\n\n"
 "**سفکسیم + آزیترومایسین** — سفکسیم خوراکی است و **کارایی کمتری از سفتریاکسون** "
 "دارد، به‌ویژه در بافت عمقی. در اپیدیدیمیت **کافی نیست**.\n\n"
 "**جمی‌فلوکساسین + داکسی‌سیکلین** — باز هم فلوروکینولون، با همان مشکل مقاومت.\n\n"
 "⚠️ **و مهم‌ترین نکته‌ی بالینی که سؤال نپرسیده ولی می‌تواند بیضه‌ی یک جوان را نجات "
 "دهد: تورشن بیضه.**\n\n"
 "**در هر مرد جوان با درد حاد بیضه، تورشن باید تا خلاف آن ثابت نشود در نظر باشد**، "
 "چون **اورژانس جراحی** است و پنجره‌ی نجات بیضه فقط **۶ تا ۸ ساعت** است.\n\n"
 "**چه چیزی اینجا به نفع عفونت است؟** **سیر یک‌هفته‌ای.** ⚠️ **تورشن سیر ساعتی دارد، "
 "نه هفتگی** — درد ناگهانی، شدید، با تهوع و استفراغ. و در تورشن **رفلکس کرماستریک "
 "غایب** است، در حالی که در اپیدیدیمیت حفظ شده.",
 "A 24-YEAR-OLD MAN with PAIN AND UNILATERAL SWELLING OF THE RIGHT TESTIS FOR A WEEK, and a history "
 "of URETHRAL DISCHARGE.\n\n"
 "WARNING, THE ANSWER: CEFTRIAXONE PLUS DOXYCYCLINE.\n\n"
 "THE DIAGNOSIS: SEXUALLY ACQUIRED EPIDIDYMITIS. And the history of URETHRAL DISCHARGE is what "
 "establishes its origin.\n\n"
 "RECALL THE GOVERNING PRINCIPLE FROM URETHRITIS: WARNING, IN A MAN UNDER 35, EPIDIDYMITIS IS "
 "ALMOST ALWAYS GONORRHOEA OR CHLAMYDIA OR BOTH. So treatment must COVER BOTH — the same dual-cover "
 "logic as urethritis.\n\n"
 "CEFTRIAXONE for the gonococcus. DOXYCYCLINE for chlamydia.\n\n"
 "WARNING, AND ONE IMPORTANT DIFFERENCE FROM URETHRITIS: THE DURATION. In urethritis doxycycline is "
 "given for 7 DAYS; in epididymitis for 10 DAYS. WHY? Because testicular and epididymal tissue is "
 "DEEPER and drug penetration takes longer.\n\n"
 "AND WHY NOT THE OTHER THREE? WARNING, ALL THREE SHARE ONE FLAW: a fluoroquinolone or cefixime, "
 "neither of which is reliable against the gonococcus.\n\n"
 "OFLOXACIN PLUS AZITHROMYCIN — ofloxacin is a fluoroquinolone, and THE CDC ABANDONED "
 "FLUOROQUINOLONES FOR GONORRHOEA IN 2007 because of widespread resistance.\n\n"
 "CEFIXIME PLUS AZITHROMYCIN — cefixime is oral and LESS EFFECTIVE THAN CEFTRIAXONE, especially in "
 "deep tissue. It is INADEQUATE in epididymitis.\n\n"
 "GEMIFLOXACIN PLUS DOXYCYCLINE — again a fluoroquinolone, with the same resistance problem.\n\n"
 "WARNING, AND THE MOST IMPORTANT CLINICAL POINT THE QUESTION DOES NOT ASK BUT WHICH CAN SAVE A "
 "YOUNG MAN'S TESTIS: TESTICULAR TORSION.\n\n"
 "IN ANY YOUNG MAN WITH ACUTE TESTICULAR PAIN, TORSION MUST BE CONSIDERED UNTIL EXCLUDED, because "
 "it is a SURGICAL EMERGENCY and the window to save the testis is only 6 TO 8 HOURS.\n\n"
 "WHAT FAVOURS INFECTION HERE? THE ONE-WEEK COURSE. WARNING, TORSION EVOLVES OVER HOURS, NOT WEEKS "
 "— sudden severe pain with nausea and vomiting. And in torsion the CREMASTERIC REFLEX IS ABSENT, "
 "whereas in epididymitis it is preserved.",
 ["افلوکساسین یک فلوروکینولون است، و CDC از ۲۰۰۷ آن‌ها را برای گونوکوک کنار گذاشت.",
  "پاسخ صحیح — اپیدیدیمیت جنسی نیازمند پوشش هم‌زمان گونوکوک و کلامیدیاست.",
  "سفکسیم خوراکی کارایی کمتری از سفتریاکسون دارد و در بافت عمقی کافی نیست.",
  "جمی‌فلوکساسین هم فلوروکینولون است و همان مشکل مقاومت گونوکوک را دارد."],
 ["Ofloxacin is a fluoroquinolone, and the CDC abandoned these for gonorrhoea in 2007.",
  "Correct — sexually acquired epididymitis needs simultaneous cover of gonorrhoea and chlamydia.",
  "Oral cefixime is less effective than ceftriaxone and inadequate in deep tissue.",
  "Gemifloxacin is also a fluoroquinolone and shares the same gonococcal resistance problem."],
 "**اپیدیدیمیت جنسی = درمان دوگانه. و تورشن را همیشه رد کنید.**",
 "Sexually acquired epididymitis needs dual therapy — and always exclude torsion.",
 [CDC2021, H])

add("book:555", "case", "hard",
 "علائم پس از درمان **کامل و صحیح** ← **هیچ‌کدام**؛ این اورتریت پایدار است، نه شکست درمان.",
 "Symptoms after COMPLETE, CORRECT treatment: NONE OF THE ABOVE — this is persistent urethritis, not treatment failure.",
 URETH_FA + [
  "**این سخت‌ترین سؤال بلوک اورتریت است، چون پاسخ «هیچ‌کدام» است.**",
  "⚠️ **دو نکته‌ی متن، هر سه گزینه‌ی فعال را رد می‌کنند.**",
  "**نکته‌ی یک: بیمار پس از سفتریاکسون بهبود یافت — پس درمان گونوکوک موفق بود.**",
  "**نکته‌ی دو: علائم بدون تماس جنسی جدید برگشتند — پس عفونت مجدد نیست.**",
  "**و ترشح این‌بار مخاطی است، نه چرکی — الگوی اورتریت غیرگونوکوکی.**",
  "⚠️ **این تابلوی اورتریت پایدار یا راجعه است، که تعریف و رویکرد خودش را دارد.**",
  "**شایع‌ترین علتش مایکوپلاسما ژنیتالیوم است، که به آزیترومایسین تک‌دوز مقاوم است.**",
  "**سپس تریکوموناس واژینالیس، که هیچ‌کدام از رژیم‌های معمول پوششش نمی‌دهند.**",
  "**پس اقدام درست، ارزیابی مجدد و آزمایش هدفمند است، نه تکرار کورکورانه‌ی درمان.**",
 ],
 URETH_EN + [
  "This is the hardest question in the urethritis block, because the answer is 'none of the above'.",
  "WARNING, TWO POINTS IN THE STEM RULE OUT ALL THREE ACTIVE OPTIONS.",
  "POINT ONE: the patient improved after ceftriaxone — so gonococcal treatment succeeded.",
  "POINT TWO: symptoms returned WITHOUT new sexual contact — so this is not reinfection.",
  "And the discharge is now MUCOID rather than purulent — the pattern of non-gonococcal urethritis.",
  "WARNING, THIS IS PERSISTENT OR RECURRENT URETHRITIS, which has its own definition and approach.",
  "Its commonest cause is Mycoplasma genitalium, which resists single-dose azithromycin.",
  "Then Trichomonas vaginalis, which none of the usual regimens covers.",
  "So the right action is reassessment and targeted testing, not blindly repeating treatment.",
 ],
 "**جوان ۳۰ ساله** با یورتریت و **دیپلوکوک گرم منفی داخل سلولی** در اسمیر. **درمان "
 "گونوکوک با سفتریاکسون شروع شد و بیمار بهبود یافت.** ولی **پس از یک هفته، بدون "
 "تماس جنسی جدید، دچار ترشح مخاطی شد.**\n\n"
 "⚠️ **پاسخ: هیچ‌کدام از موارد فوق. و این سخت‌ترین سؤال بلوک است، چون باید سه گزینه "
 "را فعالانه رد کنید.**\n\n"
 "**دو نکته‌ی متن، کل ماجرا را تعیین می‌کنند:**\n\n"
 "**نکته‌ی یک: بیمار پس از سفتریاکسون بهبود یافت.** ⚠️ **پس درمان گونوکوک موفق بوده "
 "است.** اگر مقاومت دارویی وجود داشت، بیمار **اصلاً بهبود نمی‌یافت**.\n\n"
 "**نکته‌ی دو: بدون تماس جنسی جدید.** ⚠️ **پس عفونت مجدد نیست.**\n\n"
 "**و سرنخ سوم در نوع ترشح است:** بار اول **چرکی** بود (گونوکوک)، این‌بار **مخاطی** "
 "است — الگوی **اورتریت غیرگونوکوکی**.\n\n"
 "**پس این چیست؟ اورتریت پایدار یا راجعه** — یک موجودیت بالینی تعریف‌شده با رویکرد "
 "خودش.\n\n"
 "**علل شایعش را بدانید:**\n\n"
 "⚠️ **۱) مایکوپلاسما ژنیتالیوم** — شایع‌ترین علت. **به آزیترومایسین تک‌دوز مقاوم "
 "است** و درمانش رژیم متفاوتی می‌طلبد (موکسی‌فلوکساسین یا داکسی‌سیکلین سپس "
 "آزیترومایسین طولانی).\n\n"
 "**۲) تریکوموناس واژینالیس** — **هیچ‌کدام از رژیم‌های معمول اورتریت پوششش نمی‌دهند**؛ "
 "مترونیدازول لازم است.\n\n"
 "**۳) عدم درمان شریک جنسی** — که باعث چرخه‌ی «پینگ‌پنگ» می‌شود.\n\n"
 "**حالا سه گزینه را رد کنیم:**\n\n"
 "**«درمان با آنتی‌بیوتیک دیگر به‌احتمال مقاومت»** ❌ — بیمار **بهبود یافته بود**، پس "
 "مقاومتی در کار نیست.\n\n"
 "**«سفتریاکسون + آزیترومایسین برای کلامیدیا»** ❌ — تکرار پوشش گونوکوک **بی‌مورد** "
 "است، و اگر کلامیدیا بود، آزیترومایسین اولیه (اگر داده شده بود) پوششش می‌داد. ضمناً "
 "این گزینه **علت واقعی را هدف نمی‌گیرد**.\n\n"
 "**«آزیترومایسین برای کلامیدیا»** ❌ — ⚠️ نزدیک‌ترین گزینه به درست، ولی همچنان ناقص: "
 "**علت شایع‌تر مایکوپلاسما ژنیتالیوم است که به آزیترومایسین تک‌دوز مقاوم است.**\n\n"
 "**پس اقدام درست: ارزیابی مجدد، آزمایش هدفمند برای تریکوموناس و مایکوپلاسما "
 "ژنیتالیوم، و بررسی وضعیت درمان شریک جنسی — نه تکرار کورکورانه‌ی آنتی‌بیوتیک.**",
 "A 30-YEAR-OLD MAN with urethritis and INTRACELLULAR GRAM-NEGATIVE DIPLOCOCCI on smear. GONOCOCCAL "
 "TREATMENT WITH CEFTRIAXONE WAS STARTED AND HE IMPROVED. But AFTER A WEEK, WITHOUT NEW SEXUAL "
 "CONTACT, he developed a MUCOID discharge.\n\n"
 "WARNING, THE ANSWER: NONE OF THE ABOVE. And this is the hardest question in the block, because "
 "you must actively reject three options.\n\n"
 "TWO POINTS IN THE STEM DECIDE EVERYTHING:\n\n"
 "POINT ONE: HE IMPROVED AFTER CEFTRIAXONE. WARNING, SO GONOCOCCAL TREATMENT SUCCEEDED. Had there "
 "been resistance, he would NOT HAVE IMPROVED AT ALL.\n\n"
 "POINT TWO: WITHOUT NEW SEXUAL CONTACT. WARNING, SO THIS IS NOT REINFECTION.\n\n"
 "AND A THIRD CLUE IN THE DISCHARGE ITSELF: the first was PURULENT (gonococcus), this one is MUCOID "
 "— the pattern of NON-GONOCOCCAL urethritis.\n\n"
 "SO WHAT IS THIS? PERSISTENT OR RECURRENT URETHRITIS — a defined clinical entity with its own "
 "approach.\n\n"
 "KNOW ITS COMMON CAUSES:\n\n"
 "WARNING, 1) MYCOPLASMA GENITALIUM — the commonest. IT RESISTS SINGLE-DOSE AZITHROMYCIN and needs "
 "a different regimen (moxifloxacin, or doxycycline followed by extended azithromycin).\n\n"
 "2) TRICHOMONAS VAGINALIS — NONE of the usual urethritis regimens covers it; metronidazole is "
 "needed.\n\n"
 "3) AN UNTREATED PARTNER — producing a ping-pong cycle.\n\n"
 "NOW REJECT THE THREE OPTIONS:\n\n"
 "'TREAT WITH ANOTHER ANTIBIOTIC ASSUMING RESISTANCE' — he HAD IMPROVED, so there is no resistance.\n\n"
 "'CEFTRIAXONE PLUS AZITHROMYCIN FOR CHLAMYDIA' — repeating gonococcal cover is UNNECESSARY, and "
 "this option DOES NOT TARGET THE REAL CAUSE.\n\n"
 "'AZITHROMYCIN FOR CHLAMYDIA' — WARNING, the closest to right but still incomplete: THE COMMONER "
 "CAUSE IS MYCOPLASMA GENITALIUM, WHICH RESISTS SINGLE-DOSE AZITHROMYCIN.\n\n"
 "SO THE RIGHT ACTION IS REASSESSMENT, TARGETED TESTING for trichomonas and M. genitalium, and "
 "CHECKING THE PARTNER'S TREATMENT — not blindly repeating an antibiotic.",
 ["بیمار پس از سفتریاکسون بهبود یافته بود، پس مقاومت دارویی در کار نیست.",
  "تکرار پوشش گونوکوک بی‌مورد است و این گزینه علت واقعی علائم را هدف نمی‌گیرد.",
  "نزدیک‌ترین گزینه ولی ناقص — علت شایع‌تر مایکوپلاسما ژنیتالیوم است که به آزیترومایسین تک‌دوز مقاوم است.",
  "پاسخ صحیح — این اورتریت پایدار است و نیازمند ارزیابی مجدد و آزمایش هدفمند، نه تکرار درمان."],
 ["He improved after ceftriaxone, so there is no drug resistance.",
  "Repeating gonococcal cover is unnecessary and this option does not target the real cause.",
  "The closest option but incomplete — the commoner cause is M. genitalium, which resists single-dose azithromycin.",
  "Correct — this is persistent urethritis needing reassessment and targeted testing, not repeated treatment."],
 "**بهبود یافت سپس برگشت، بدون تماس جدید = اورتریت پایدار، نه شکست درمان.**",
 "Improved then relapsed with no new contact means persistent urethritis, not treatment failure.",
 [CDC2021, H])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book37.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 37 lessons:', len(L))
