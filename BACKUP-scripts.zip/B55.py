# -*- coding: utf-8 -*-
"""Micro-lessons, batch 55 — tuberculosis part five: rebuilding the regimen
after a rifampicin immune reaction, the rifampicin drug interactions, and the
tuberculin thresholds that decide who gets preventive therapy.

REBUILDING A REGIMEN WITHOUT RIFAMPICIN
-----------------------------------------
When rifampicin must be abandoned permanently — after thrombocytopenia,
haemolysis, interstitial nephritis or shock — the loss is severe, because
rifampicin is the sterilising drug that made six-month treatment possible.
The replacement regimen must therefore be:

    LONGER (12 to 18 months rather than 6)
    built from SEVERAL drugs the strain has not seen
    and it must not simply drop rifampicin and continue with what is left,
    because that would leave too few effective drugs standing

The book's answer to both questions in this block is the same five- to
six-drug combination — ofloxacin, amikacin, cycloserine, prothionamide,
pyrazinamide and ethambutol — which is the classical MDR-style regimen of its
era. TODAY the same clinical situation would be managed with an all-oral
regimen built on Group A drugs (levofloxacin or moxifloxacin, bedaquiline,
linezolid), because WHO's 2019-2022 revisions removed the injectable agents
from routine use. The PRINCIPLE the question tests — several new effective
drugs, for longer, rather than a bare subtraction — is unchanged, and that is
what these lessons teach.

RIFAMPICIN AS THE INTERACTION DRUG
------------------------------------
Rifampicin is the most potent inducer of cytochrome P450 in clinical use
(especially CYP3A4) and also induces P-glycoprotein. Within about a week it
can halve or worse the levels of:

    ORAL CONTRACEPTIVES        the classic exam item — contraceptive failure
    warfarin                   loss of anticoagulation
    methadone                  withdrawal
    azole antifungals          treatment failure
    HIV protease inhibitors    rifabutin is substituted for this reason
    ciclosporin, tacrolimus    graft rejection
    corticosteroids            adrenal crisis in a steroid-dependent patient
    oral hypoglycaemics        loss of glycaemic control

A woman on the combined oral contraceptive who starts rifampicin must be
moved to a NON-HORMONAL method (or a depot progestogen), and must be counselled
that the interaction persists for some weeks after rifampicin is stopped.

THE TUBERCULIN THRESHOLDS, WHICH DECIDE SIX QUESTIONS
--------------------------------------------------------
    >= 5 mm is positive in
        HIV infection
        RECENT CLOSE CONTACT of an infectious case
        fibrotic changes on the chest film consistent with old tuberculosis
        ORGAN TRANSPLANT recipients
        other immunosuppression, including prednisolone >= 15 mg/day for
            a month or more, and TNF-alpha blockers

    >= 10 mm is positive in
        recent immigrants from high-prevalence countries
        injecting drug users
        residents and staff of congregate settings — PRISONS, shelters,
            nursing homes, and HEALTH CARE WORKERS
        mycobacteriology laboratory personnel
        chronic illness raising risk: DIABETES, chronic renal failure,
            leukaemia and lymphoma, silicosis, gastrectomy, low body weight
        CHILDREN UNDER 5, and children exposed to high-risk adults

    >= 15 mm is positive in everyone else, with no risk factor at all

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022) —
tuberculosis; CDC/NTCA Guidelines for the Treatment of Latent Tuberculosis
Infection, MMWR Recomm Rep 2020;69(1).
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — tuberculosis")
CDC = ("Sterling TR et al. Guidelines for the Treatment of Latent Tuberculosis "
       "Infection: Recommendations from the NTCA and CDC, 2020. "
       "MMWR Recomm Rep 2020;69(1):1-11")
WHO4 = ("WHO consolidated guidelines on tuberculosis, Module 4: Treatment — "
        "drug-resistant tuberculosis treatment (2022 update)")
REFS = [H]
REFSC = [H, CDC]
REFSW = [H, WHO4]

# ============================================ REGIMEN WITHOUT RIFAMPICIN
NORIF_FA = [
    "⚠️ **از دست دادن ریفامپین، سنگین‌ترین ضربه به رژیم ضدسل است.**",
    "**چون ریفامپین داروی استریل‌کننده است و شش‌ماهه شدن درمان را ممکن کرد.**",
    "**پس رژیم بدون ریفامپین باید بسیار طولانی‌تر باشد: ۱۲ تا ۱۸ ماه.**",
    "⚠️ **و نباید فقط ریفامپین را کم کرد و بقیه را ادامه داد.**",
    "**چون آنچه می‌ماند، داروهای کافی و مؤثر ندارد.**",
    "**قاعده: چند داروی مؤثرِ تازه را هم‌زمان اضافه کنید.**",
    "**در رژیم کلاسیک آن دوره: فلوروکینولون، آمینوگلیکوزید، سیکلوسرین، پروتیونامید.**",
    "**به‌همراه پیرازینامید و اتامبوتول که هنوز مؤثرند.**",
    "⚠️ **و در راهنمای امروزی، تزریقی‌ها از رده خارج شده‌اند.**",
    "**رژیم امروز تماماً خوراکی است و بر داروهای گروه A بنا می‌شود.**",
    "**گروه A: لوو یا موکسی‌فلوکساسین، بداکیلین، لاینزولید.**",
    "**ولی اصل سؤال — چند داروی تازه با هم، برای مدت طولانی‌تر — تغییر نکرده است.**",
]
NORIF_EN = [
    "WARNING: LOSING RIFAMPICIN IS THE HEAVIEST BLOW A TUBERCULOSIS REGIMEN CAN TAKE.",
    "Because rifampicin is the sterilising drug that made six-month treatment possible.",
    "So a rifampicin-free regimen must run far longer: 12 to 18 months.",
    "WARNING, AND ONE MUST NOT SIMPLY SUBTRACT RIFAMPICIN AND CARRY ON.",
    "Because what remains does not contain enough effective drugs.",
    "The rule: add SEVERAL new effective drugs at the same time.",
    "In the classical regimen of that era: a fluoroquinolone, an aminoglycoside, cycloserine, prothionamide.",
    "Together with pyrazinamide and ethambutol, which remain effective.",
    "WARNING, AND IN CURRENT GUIDANCE THE INJECTABLE AGENTS HAVE BEEN RETIRED.",
    "Today's regimen is entirely oral and is built on the Group A drugs.",
    "Group A: levofloxacin or moxifloxacin, bedaquiline, linezolid.",
    "But the principle the question tests — several new drugs together, for longer — is unchanged.",
]

add("book:250", "recall", "hard",
    "**افت شدید پلاکت با ریفامپین: رژیم چنددارویی جایگزین، نه صرفاً حذف یک دارو.**",
    "A severe platelet fall on rifampicin: a multi-drug replacement regimen, not a bare subtraction.",
    NORIF_FA, NORIF_EN,
    "این سؤال ادامه‌ی منطقی مبحث ترومبوسیتوپنی ریفامپین است: **حالا که ریفامپین "
    "برای همیشه رفت، چه رژیمی بسازیم؟**\n\n"
    "**بیمار: مبتلا به سل ریوی، دو هفته پس از شروع HRZE، دچار افت پلاکت تا ۵٬۰۰۰ در "
    "میکرولیتر شده است.**\n\n"
    "⚠️ **پلاکت ۵٬۰۰۰ یک اورژانس است، نه یک یافته‌ی آزمایشگاهی.** زیر ۱۰٬۰۰۰، خطر "
    "**خونریزی خودبه‌خودی از جمله خونریزی داخل مغزی** جدی است.\n\n"
    "**تشخیص روشن است: ترومبوسیتوپنی ایمنی ناشی از ریفامپین** — آنتی‌بادی وابسته به "
    "دارو علیه کمپلکس ریفامپین-پلاکت. **و همان‌طور که می‌دانیم، این یعنی ریفامپین "
    "برای همیشه ممنوع است.**\n\n"
    "**پاسخ: افلوکساسین + آمیکاسین + سیکلوسرین + پروتیونامید + پیرازینامید + "
    "اتامبوتول.**\n\n"
    "**چرا این رژیم بزرگ، و نه چیز ساده‌تری؟**\n\n"
    "⚠️ **دلیل اول: ریفامپین جایگزین ساده ندارد.** ریفامپین **داروی استریل‌کننده** "
    "است — تنها دارویی که باسیل‌های نیمه‌خفته را می‌کشد. **بدون آن، درمان ۶ ماهه "
    "غیرممکن است و باید به ۱۲ تا ۱۸ ماه برود.**\n\n"
    "**دلیل دوم: نمی‌توان فقط تفریق کرد.** اگر ریفامپین را برداریم و **HZE** ادامه "
    "دهیم، رژیمی می‌ماند با ایزونیازید به‌عنوان تنها داروی قوی. **این خیلی نزدیک به "
    "تک‌درمانی مؤثر است** و راه ساختن مقاومت به ایزونیازید را باز می‌کند.\n\n"
    "**دلیل سوم: در چنین وضعیتی، اصل «چند داروی مؤثر هم‌زمان» حاکم است.** رژیم "
    "پیشنهادی شش دارو دارد که هر کدام سازوکار متفاوتی دارند:\n\n"
    "**افلوکساسین** (فلوروکینولون — امروز لوو یا موکسی‌فلوکساسین ترجیح دارد) · "
    "**آمیکاسین** (آمینوگلیکوزید تزریقی) · **سیکلوسرین** (مهار سنتز دیواره) · "
    "**پروتیونامید** (شبیه اتیونامید) · **پیرازینامید و اتامبوتول** (که هنوز مؤثرند "
    "و بی‌دلیل کنار گذاشته نمی‌شوند).\n\n"
    "⚠️ **و آنچه امروز تغییر کرده و باید بدانید:** از بازنگری‌های **۲۰۱۹ تا ۲۰۲۲** "
    "سازمان جهانی بهداشت، **داروهای تزریقی (آمیکاسین، کاپرئومایسین) از رژیم‌های "
    "روتین حذف شده‌اند**، چون **ناشنوایی برگشت‌ناپذیر** می‌سازند و نتایجشان از "
    "خوراکی‌های جدید بدتر است. **رژیم امروز تماماً خوراکی است** و بر **گروه A** بنا "
    "می‌شود: **لوو/موکسی‌فلوکساسین، بداکیلین، لاینزولید**.\n\n"
    "**ولی اصل سؤال دقیقاً همان است و امروز هم درست است: وقتی داروی محوری از دست "
    "می‌رود، رژیم را با چند داروی تازه بازسازی کنید، نه با تفریق.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**HZE به‌مدت ۱۲ تا ۱۸ ماه** — همان **تفریق ساده**. طول درمان درست است ولی "
    "**تعداد داروهای مؤثر کافی نیست**.\n\n"
    "**ZESQ (پیرازینامید، اتامبوتول، استرپتومایسین، کینولون) ۱۲ تا ۱۸ ماه** — "
    "⚠️ **گزینه‌ی نزدیک ولی ناقص.** ترکیب معقولی است، ولی **استرپتومایسین در بیمار با "
    "واکنش ایمنی و شمارش خونی مختل، انتخاب خوبی نیست**، و رژیم نسبت به گزینه‌ی صحیح "
    "**کم‌دارو‌تر** است.\n\n"
    "⚠️ **«نیاز به تعویض داروها نیست»** — **خطرناک‌ترین گزینه.** ادامه‌ی ریفامپین در "
    "بیمار با پلاکت ۵٬۰۰۰ **می‌تواند به خونریزی کشنده منجر شود.**",
    "This question is the logical continuation of the rifampicin thrombocytopenia topic: NOW THAT RIFAMPICIN IS GONE FOR GOOD, WHAT REGIMEN DO WE BUILD?\n\n"
    "THE PATIENT: pulmonary tuberculosis, two weeks after starting HRZE, with a platelet fall to 5,000 per microlitre.\n\n"
    "WARNING: A PLATELET COUNT OF 5,000 IS AN EMERGENCY, NOT A LABORATORY CURIOSITY. Below 10,000 the risk of SPONTANEOUS HAEMORRHAGE, INCLUDING INTRACRANIAL BLEEDING, is serious.\n\n"
    "THE DIAGNOSIS IS CLEAR: RIFAMPICIN-INDUCED IMMUNE THROMBOCYTOPENIA — drug-dependent antibody against the rifampicin-platelet complex. AND AS WE KNOW, THAT MEANS RIFAMPICIN IS FORBIDDEN FOR LIFE.\n\n"
    "THE ANSWER: OFLOXACIN PLUS AMIKACIN PLUS CYCLOSERINE PLUS PROTHIONAMIDE PLUS PYRAZINAMIDE PLUS ETHAMBUTOL.\n\n"
    "WHY SUCH A LARGE REGIMEN RATHER THAN SOMETHING SIMPLER?\n\n"
    "WARNING, REASON ONE: RIFAMPICIN HAS NO SIMPLE SUBSTITUTE. It is THE STERILISING DRUG — the only one that kills semi-dormant bacilli. WITHOUT IT SIX-MONTH TREATMENT IS IMPOSSIBLE AND THE COURSE MUST STRETCH TO 12 TO 18 MONTHS.\n\n"
    "REASON TWO: YOU CANNOT SIMPLY SUBTRACT. Remove rifampicin and continue HZE and you are left with isoniazid as the only strong drug. THAT IS PERILOUSLY CLOSE TO EFFECTIVE MONOTHERAPY and opens the road to isoniazid resistance.\n\n"
    "REASON THREE: IN THIS SITUATION THE RULE 'SEVERAL EFFECTIVE DRUGS AT ONCE' GOVERNS. The proposed regimen has six drugs with different mechanisms:\n\n"
    "OFLOXACIN (a fluoroquinolone — today levofloxacin or moxifloxacin is preferred), AMIKACIN (an injectable aminoglycoside), CYCLOSERINE (cell wall synthesis inhibition), PROTHIONAMIDE (an ethionamide analogue), and PYRAZINAMIDE AND ETHAMBUTOL, which remain effective and are not discarded without reason.\n\n"
    "WARNING, AND WHAT HAS CHANGED TODAY: since WHO's 2019 to 2022 revisions, THE INJECTABLE AGENTS (amikacin, capreomycin) HAVE BEEN REMOVED FROM ROUTINE REGIMENS, because they cause IRREVERSIBLE DEAFNESS and give worse outcomes than the newer oral drugs. TODAY'S REGIMEN IS ENTIRELY ORAL and built on GROUP A: LEVOFLOXACIN/MOXIFLOXACIN, BEDAQUILINE, LINEZOLID.\n\n"
    "BUT THE PRINCIPLE THE QUESTION TESTS IS EXACTLY THE SAME AND STILL CORRECT: WHEN A PIVOTAL DRUG IS LOST, REBUILD THE REGIMEN WITH SEVERAL NEW DRUGS RATHER THAN BY SUBTRACTION.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "HZE FOR 12 TO 18 MONTHS — a BARE SUBTRACTION. The duration is right but THERE ARE NOT ENOUGH EFFECTIVE DRUGS.\n\n"
    "ZESQ (pyrazinamide, ethambutol, streptomycin, a quinolone) FOR 12 TO 18 MONTHS — WARNING, CLOSE BUT INCOMPLETE. A reasonable combination, but STREPTOMYCIN IS A POOR CHOICE IN A PATIENT WHO HAS JUST HAD AN IMMUNE REACTION AND A DISORDERED BLOOD COUNT, and the regimen carries fewer drugs than the correct option.\n\n"
    "WARNING: 'NO CHANGE OF DRUGS IS NEEDED' — THE MOST DANGEROUS OPTION. Continuing rifampicin in a patient with a platelet count of 5,000 CAN LEAD TO FATAL HAEMORRHAGE.",
    ["پاسخ صحیح — رژیم چنددارویی جایگزین با داروهای تازه، به‌جای تفریق ساده‌ی ریفامپین.",
     "تفریق ساده است؛ طول درمان درست ولی تعداد داروهای مؤثر کافی نیست.",
     "ترکیب معقول ولی کم‌دارو‌تر، و استرپتومایسین در بیمار با واکنش ایمنی انتخاب خوبی نیست.",
     "خطرناک‌ترین گزینه؛ ادامه‌ی ریفامپین با پلاکت ۵٬۰۰۰ می‌تواند به خونریزی کشنده برسد."],
    ["Correct — a multi-drug replacement built from new agents rather than a bare subtraction.",
     "A bare subtraction; the duration is right but there are not enough effective drugs.",
     "A reasonable combination but with fewer drugs, and streptomycin is poor after an immune reaction.",
     "The most dangerous option; continuing rifampicin at a platelet count of 5,000 risks fatal haemorrhage."],
    "**وقتی داروی محوری از دست می‌رود، رژیم را بازسازی کن — تفریق نکن.**",
    "When a pivotal drug is lost, rebuild the regimen — do not subtract.",
    REFSW)

add("book:251", "vignette", "hard",
    "**پتشی جلدی با پلاکت ۴۰ هزار: رژیم جایگزین چنددارویی و ریفامپین برای همیشه کنار.**",
    "Cutaneous petechiae with a platelet count of 40,000: a multi-drug replacement, and rifampicin gone for good.",
    NORIF_FA, NORIF_EN,
    "این سؤال، همان وضعیت سؤال قبل است با شدت کمتر، و **گزینه‌های نادرستش سه خطای "
    "متفاوت و آموزنده را نشان می‌دهند**.\n\n"
    "**بیمار: خانم ۳۰ ساله، دو هفته پس از شروع HRZE برای سل ریوی، دچار پتشی جلدی "
    "شده و پلاکت به ۴۰ هزار رسیده است.**\n\n"
    "**تشخیص: ترومبوسیتوپنی ایمنی ریفامپین** — همان مکانیسم هاپتنی که پیش‌تر دیدیم. "
    "**زمان‌بندی دو هفته‌ای کاملاً معمول است.**\n\n"
    "**پاسخ: افلوکساسین + آمیکاسین + سیکلوسرین + پروتیونامید + پیرازینامید + "
    "اتامبوتول.**\n\n"
    "**اقدام فوری در بالین (که سؤال نمی‌پرسد ولی باید بدانید):**\n\n"
    "**۱. قطع فوری ریفامپین** — و ثبت آن به‌عنوان **آلرژی دائمی** در پرونده.\n\n"
    "**۲. پایش پلاکت** — معمولاً ظرف چند روز تا یک هفته بهبود می‌یابد.\n\n"
    "**۳. اجتناب از NSAID و آسپرین** تا نرمال شدن پلاکت.\n\n"
    "**۴. و سپس ساختن رژیم جایگزین.**\n\n"
    "**چرا رژیم جایگزین باید بزرگ باشد؟ همان سه دلیل سؤال قبل:** ریفامپین "
    "استریل‌کننده است و جایگزین تک‌نفره ندارد · تفریق ساده رژیم را به مرز تک‌درمانی "
    "می‌برد · و اصل «چند داروی مؤثر هم‌زمان» در سل مقاوم یا محدود‌شده حاکم است.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟ هر کدام یک درس دارند:**\n\n"
    "**ایزونیازید + پیرازینامید + اتامبوتول** — **تفریق ساده.** فقط ریفامپین حذف "
    "شده. **این رژیم برای درمان طولانی سل بدون ریفامپین کافی نیست** و ایزونیازید را "
    "در معرض ساخته شدن مقاومت می‌گذارد.\n\n"
    "⚠️ **ریفامپیین + اتامبوتول + ریفامپیسین + پیرازینامید + استروئید** — **بدترین "
    "گزینه، و دو خطای جدی دارد.**\n\n"
    "**خطای اول و مرگبار: ریفامپین در رژیم مانده است** (و حتی دو بار با دو املا "
    "نوشته شده). **در بیماری که ترومبوسیتوپنی ایمنی به ریفامپین داده، ادامه‌ی آن "
    "می‌تواند به افت شدیدتر پلاکت و خونریزی کشنده منجر شود.**\n\n"
    "**خطای دوم: افزودن استروئید.** استروئید در ITP ایدیوپاتیک جایگاه دارد، ولی "
    "**در ترومبوسیتوپنی دارویی، درمان اصلی قطع داروست، نه سرکوب ایمنی**. به‌علاوه "
    "استروئید در بیمار مسلول، اگر رژیم مؤثری در کار نباشد، **خطرناک** است.\n\n"
    "**ایزونیازید + ریفامپین** — **دو خطا:** ریفامپین همچنان حاضر است، و رژیم "
    "دودارویی برای سل فعال **بسیار ناکافی** است.",
    "This question presents the same situation as the previous one in a milder form, and ITS WRONG OPTIONS ILLUSTRATE THREE DIFFERENT AND INSTRUCTIVE ERRORS.\n\n"
    "THE PATIENT: a 30-year-old woman who, two weeks after starting HRZE for pulmonary tuberculosis, develops CUTANEOUS PETECHIAE with a platelet count of 40,000.\n\n"
    "THE DIAGNOSIS: RIFAMPICIN IMMUNE THROMBOCYTOPENIA — the same hapten mechanism we met earlier. THE TWO-WEEK TIMING IS ENTIRELY TYPICAL.\n\n"
    "THE ANSWER: OFLOXACIN PLUS AMIKACIN PLUS CYCLOSERINE PLUS PROTHIONAMIDE PLUS PYRAZINAMIDE PLUS ETHAMBUTOL.\n\n"
    "IMMEDIATE BEDSIDE ACTIONS (which the question does not ask but you must know):\n\n"
    "1. STOP RIFAMPICIN AT ONCE — and record it as a PERMANENT ALLERGY in the notes.\n\n"
    "2. MONITOR THE PLATELET COUNT — it usually recovers within days to a week.\n\n"
    "3. AVOID NSAIDs AND ASPIRIN until the count normalises.\n\n"
    "4. AND THEN BUILD THE REPLACEMENT REGIMEN.\n\n"
    "WHY MUST THE REPLACEMENT BE LARGE? The same three reasons as before: rifampicin is the sterilising drug with no single substitute; a bare subtraction pushes the regimen to the edge of monotherapy; and the rule of 'several effective drugs at once' governs constrained or resistant disease.\n\n"
    "WHY ARE THE OTHER THREE REJECTED? EACH CARRIES A LESSON:\n\n"
    "ISONIAZID PLUS PYRAZINAMIDE PLUS ETHAMBUTOL — A BARE SUBTRACTION. Only rifampicin has been removed. THIS IS NOT ENOUGH FOR PROLONGED RIFAMPICIN-FREE TREATMENT and it exposes isoniazid to resistance.\n\n"
    "WARNING: RIFAMPICIN PLUS ETHAMBUTOL PLUS RIFAMPICIN PLUS PYRAZINAMIDE PLUS STEROID — THE WORST OPTION, WITH TWO SERIOUS ERRORS.\n\n"
    "THE FIRST AND LETHAL ERROR: RIFAMPICIN IS STILL IN THE REGIMEN (indeed written twice under two spellings). IN A PATIENT WHO HAS JUST HAD RIFAMPICIN IMMUNE THROMBOCYTOPENIA, CONTINUING IT CAN CAUSE A DEEPER PLATELET FALL AND FATAL HAEMORRHAGE.\n\n"
    "THE SECOND ERROR: ADDING A STEROID. Steroids have a role in idiopathic ITP, but IN DRUG-INDUCED THROMBOCYTOPENIA THE TREATMENT IS WITHDRAWAL OF THE DRUG, NOT IMMUNOSUPPRESSION. Moreover a steroid in a tuberculosis patient without an effective regimen is DANGEROUS.\n\n"
    "ISONIAZID PLUS RIFAMPICIN — TWO ERRORS: rifampicin is still present, and a two-drug regimen is grossly inadequate for active tuberculosis.",
    ["تفریق ساده است؛ برای درمان طولانی بدون ریفامپین کافی نیست و ایزونیازید را در خطر می‌گذارد.",
     "بدترین گزینه؛ ریفامپین را نگه داشته و استروئید هم درمان ترومبوسیتوپنی دارویی نیست.",
     "پاسخ صحیح — رژیم چنددارویی جایگزین بدون ریفامپین، برای مدت طولانی‌تر.",
     "دو خطا: ریفامپین همچنان حاضر است و رژیم دودارویی برای سل فعال ناکافی است."],
    ["A bare subtraction; inadequate for prolonged rifampicin-free treatment and it endangers isoniazid.",
     "The worst option; it retains rifampicin, and a steroid is not the treatment for drug-induced thrombocytopenia.",
     "Correct — a multi-drug rifampicin-free replacement regimen, given for longer.",
     "Two errors: rifampicin is still present and a two-drug regimen is inadequate for active disease."],
    "**داروی مسبب واکنش ایمنی باید از رژیم بیرون برود — نه اینکه با استروئید پوشانده شود.**",
    "The drug that caused the immune reaction must leave the regimen — not be papered over with a steroid.",
    REFSW)

# ============================================ RIFAMPICIN INTERACTIONS
INT_FA = [
    "⚠️ **ریفامپین قوی‌ترین القاکننده‌ی سیتوکروم P450 در طب بالینی است.**",
    "**به‌ویژه CYP3A4، و همچنین گلیکوپروتئین P.**",
    "**ظرف حدود یک هفته، سطح خونی ده‌ها دارو را به نصف یا کمتر می‌رساند.**",
    "⚠️ **کلاسیک‌ترین مورد امتحانی: قرص‌های ضدبارداری خوراکی.**",
    "**نتیجه: شکست پیشگیری از بارداری و حاملگی ناخواسته.**",
    "**راه‌حل: روش غیرهورمونی، یا پروژسترون تزریقی طولانی‌اثر.**",
    "**فهرست بقیه را هم بدانید: وارفارین — از دست رفتن ضدانعقاد.**",
    "**متادون — سندرم ترک. آزول‌ها — شکست درمان قارچی.**",
    "**مهارکننده‌های پروتئاز HIV — به همین دلیل ریفابوتین جایگزین می‌شود.**",
    "**سیکلوسپورین و تاکرولیموس — رد پیوند.**",
    "⚠️ **و کورتیکواستروئیدها — بحران آدرنال در بیمار وابسته به استروئید.**",
    "**و اثر القا تا هفته‌ها پس از قطع ریفامپین باقی می‌ماند.**",
]
INT_EN = [
    "WARNING: RIFAMPICIN IS THE MOST POTENT INDUCER OF CYTOCHROME P450 IN CLINICAL MEDICINE.",
    "Especially CYP3A4, and also P-glycoprotein.",
    "Within about a week it can halve or worse the blood levels of dozens of drugs.",
    "WARNING: THE CLASSIC EXAMINATION ITEM IS THE ORAL CONTRACEPTIVE PILL.",
    "The result: contraceptive failure and unintended pregnancy.",
    "The solution: a non-hormonal method, or a long-acting injectable progestogen.",
    "Know the rest of the list too: WARFARIN — loss of anticoagulation.",
    "METHADONE — a withdrawal syndrome. AZOLES — antifungal treatment failure.",
    "HIV PROTEASE INHIBITORS — which is why rifabutin is substituted.",
    "CICLOSPORIN AND TACROLIMUS — graft rejection.",
    "WARNING, AND CORTICOSTEROIDS — adrenal crisis in a steroid-dependent patient.",
    "And the induction persists for weeks after rifampicin is stopped.",
]

add("book:255", "recall", "medium",
    "**ریفامپین متابولیسم داروهای ضدبارداری هورمونی را تسریع می‌کند.**",
    "Rifampicin accelerates the metabolism of hormonal contraceptives.",
    INT_FA, INT_EN,
    "این سؤال یکی از پرتکرارترین تداخل‌های دارویی در کل طب داخلی را می‌سنجد.\n\n"
    "**سؤال: در مصرف کدام داروی ضدسل، نیاز به تغییر دوز داروهای ضدبارداری هورمونی "
    "یا استفاده از روش‌های غیرهورمونی است؟ پاسخ: ریفامپین.**\n\n"
    "**مکانیسم را بفهمید تا بتوانید کل فهرست تداخل‌ها را بازسازی کنید:**\n\n"
    "⚠️ **ریفامپین قوی‌ترین القاکننده‌ی آنزیم‌های کبدی سیتوکروم P450 است که در طب "
    "بالینی به‌کار می‌رود** — به‌ویژه **CYP3A4** — و علاوه بر آن **گلیکوپروتئین P** "
    "(پمپ خروجی روده) را هم القا می‌کند.\n\n"
    "**«القا» یعنی چه؟** ریفامپین به گیرنده‌ی هسته‌ای **PXR** متصل می‌شود و **رونویسی "
    "ژن آنزیم را افزایش می‌دهد**. یعنی کبد **تعداد بیشتری آنزیم می‌سازد**. نتیجه: هر "
    "دارویی که با آن آنزیم متابولیزه می‌شود، **سریع‌تر تجزیه می‌شود و سطح خونی‌اش "
    "افت می‌کند**.\n\n"
    "**زمان‌بندی مهم است:** القا در حدود **یک هفته** به اوج می‌رسد (چون ساختن آنزیم "
    "زمان می‌برد)، و **تا دو تا چهار هفته پس از قطع ریفامپین ادامه می‌یابد**. **این "
    "نکته‌ی دوم را بیماران هرگز نمی‌دانند و باید صریحاً به آن‌ها گفته شود.**\n\n"
    "**درباره‌ی ضدبارداری خوراکی:**\n\n"
    "**اتینیل‌استرادیول و پروژستین‌ها هر دو با CYP3A4 متابولیزه می‌شوند.** ریفامپین "
    "سطح آن‌ها را به‌شدت پایین می‌آورد و **تخمک‌گذاری دوباره رخ می‌دهد**.\n\n"
    "**راه‌حل عملی:**\n\n"
    "**روش غیرهورمونی: کاندوم، IUD مسی** (بهترین گزینه — تحت تأثیر متابولیسم کبدی "
    "نیست) · **یا پروژسترون تزریقی طولانی‌اثر با فاصله‌ی کوتاه‌تر** · **افزایش دوز قرص "
    "توصیه‌ی مطمئنی نیست** و راهنماهای امروزی روش غیرهورمونی را ترجیح می‌دهند.\n\n"
    "**فهرست کامل تداخل‌های مهم ریفامپین را یک‌بار مرور کنید — هر کدام یک فاجعه‌ی "
    "بالینی بالقوه است:**\n\n"
    "**وارفارین** ⇐ INR سقوط می‌کند ⇐ ترومبوز · **متادون** ⇐ سندرم ترک · **آزول‌ها** ⇐ "
    "شکست درمان قارچی · **مهارکننده‌های پروتئاز HIV** ⇐ شکست ART (به همین دلیل "
    "**ریفابوتین** جایگزین می‌شود) · **سیکلوسپورین و تاکرولیموس** ⇐ **رد پیوند** · "
    "**کورتیکواستروئیدها** ⇐ **بحران آدرنال** · **داروهای خوراکی دیابت** ⇐ افت کنترل "
    "قند · **دیگوکسین، فنی‌توئین، ورapamil، استاتین‌ها**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**ایزونیازید** — ⚠️ **نکته‌ی ظریف: ایزونیازید برعکس ریفامپین، مهارکننده‌ی P450 "
    "است**، نه القاکننده. سطح فنی‌توئین و کاربامازپین را **بالا** می‌برد. ولی روی "
    "ضدبارداری اثر معنادار بالینی ندارد.\n\n"
    "**اتامبوتول** — تداخل دارویی مهمی ندارد.\n\n"
    "**پیرازینامید** — تداخل دارویی مهمی ندارد.",
    "This question tests one of the most frequently examined drug interactions in all of internal medicine.\n\n"
    "THE QUESTION: with which antituberculous drug must hormonal contraception be changed in dose or replaced by a non-hormonal method? THE ANSWER: RIFAMPICIN.\n\n"
    "UNDERSTAND THE MECHANISM AND YOU CAN RECONSTRUCT THE WHOLE INTERACTION LIST:\n\n"
    "WARNING: RIFAMPICIN IS THE MOST POTENT INDUCER OF HEPATIC CYTOCHROME P450 ENZYMES IN CLINICAL USE — especially CYP3A4 — and it also induces P-GLYCOPROTEIN, the intestinal efflux pump.\n\n"
    "WHAT DOES 'INDUCTION' MEAN? Rifampicin binds the nuclear receptor PXR AND INCREASES TRANSCRIPTION OF THE ENZYME GENE. The liver therefore MAKES MORE ENZYME. The consequence: any drug metabolised by that enzyme IS BROKEN DOWN FASTER AND ITS BLOOD LEVEL FALLS.\n\n"
    "THE TIMING MATTERS: induction peaks at about ONE WEEK (because making enzyme takes time), and IT PERSISTS FOR TWO TO FOUR WEEKS AFTER RIFAMPICIN IS STOPPED. PATIENTS NEVER KNOW THIS SECOND FACT AND MUST BE TOLD EXPLICITLY.\n\n"
    "ABOUT ORAL CONTRACEPTIVES:\n\n"
    "ETHINYLOESTRADIOL AND THE PROGESTOGENS ARE BOTH METABOLISED BY CYP3A4. Rifampicin drives their levels sharply down and OVULATION RESUMES.\n\n"
    "THE PRACTICAL SOLUTION:\n\n"
    "A NON-HORMONAL METHOD: condoms, or a COPPER IUD (the best option — untouched by hepatic metabolism); or a long-acting injectable progestogen at shortened intervals. SIMPLY INCREASING THE PILL DOSE IS NOT RELIABLE, and current guidance prefers a non-hormonal method.\n\n"
    "REVIEW THE FULL LIST OF IMPORTANT RIFAMPICIN INTERACTIONS ONCE — EACH IS A POTENTIAL CLINICAL DISASTER:\n\n"
    "WARFARIN, the INR collapses, thrombosis. METHADONE, withdrawal. AZOLES, antifungal failure. HIV PROTEASE INHIBITORS, failure of antiretroviral therapy (which is why RIFABUTIN is substituted). CICLOSPORIN AND TACROLIMUS, GRAFT REJECTION. CORTICOSTEROIDS, ADRENAL CRISIS. ORAL HYPOGLYCAEMICS, loss of glycaemic control. Also digoxin, phenytoin, verapamil and the statins.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ISONIAZID — WARNING, A SUBTLE POINT: UNLIKE RIFAMPICIN, ISONIAZID IS AN INHIBITOR of P450, not an inducer. It RAISES phenytoin and carbamazepine levels. But it has no clinically meaningful effect on contraception.\n\n"
    "ETHAMBUTOL — no important drug interactions.\n\n"
    "PYRAZINAMIDE — no important drug interactions.",
    ["پاسخ صحیح — ریفامپین با القای CYP3A4 سطح هورمون‌های ضدبارداری را به‌شدت پایین می‌آورد.",
     "برعکس ریفامپین، مهارکننده‌ی P450 است و روی ضدبارداری اثر معنادار ندارد.",
     "تداخل دارویی مهمی ندارد.",
     "تداخل دارویی مهمی ندارد."],
    ["Correct — rifampicin induces CYP3A4 and drives contraceptive hormone levels sharply down.",
     "Unlike rifampicin it is a P450 inhibitor and has no meaningful effect on contraception.",
     "Has no important drug interactions.",
     "Has no important drug interactions."],
    "**ریفامپین آنزیم می‌سازد، پس داروهای دیگر را می‌سوزاند — و اثرش تا هفته‌ها می‌ماند.**",
    "Rifampicin builds enzyme, so it burns other drugs away — and the effect outlasts the course by weeks.",
    REFS)

add("book:256", "vignette", "medium",
    "**حاملگی ناخواسته حین درمان سل: ریفامپین قرص LD را بی‌اثر کرده است.**",
    "Unintended pregnancy during tuberculosis treatment: rifampicin has disarmed the contraceptive pill.",
    INT_FA, INT_EN,
    "این سؤال، همان تداخل را در قالب یک داستان بالینی واقعی می‌آورد — و همین شکل، "
    "آن را فراموش‌نشدنی می‌کند.\n\n"
    "**بیمار: خانم ۲۵ ساله که مرتب قرص LD مصرف می‌کند. طی یک ماه دچار سرفه‌ی "
    "خلط‌دار، کاهش وزن، تب و تعریق می‌شود. گرافی درگیری قله‌ی ریه، و اسمیر خلط سه "
    "نوبت AFB مثبت. تحت درمان شش‌ماهه‌ی چهاردارویی قرار می‌گیرد. در انتهای ماه دوم "
    "علائم بهبود یافته، ولی به‌علت تأخیر قاعدگی، بتا-HCG داده و حاملگی تأیید شده "
    "است.**\n\n"
    "**پاسخ: ریفامپین.**\n\n"
    "**زنجیره‌ی علّی را دنبال کنید:**\n\n"
    "**۱. بیمار قرص LD می‌خورد** — قرص ترکیبی حاوی **اتینیل‌استرادیول و "
    "لوونورژسترل**.\n\n"
    "**۲. ریفامپین شروع می‌شود** و **CYP3A4 کبدی را به‌شدت القا می‌کند**.\n\n"
    "**۳. ظرف حدود یک هفته، متابولیسم هر دو هورمون چند برابر می‌شود** و سطح خونی‌شان "
    "به زیر آستانه‌ی مهار تخمک‌گذاری می‌افتد.\n\n"
    "**۴. تخمک‌گذاری از سر گرفته می‌شود** — در حالی که بیمار **مرتب قرصش را می‌خورد** و "
    "فکر می‌کند محافظت‌شده است.\n\n"
    "**۵. حاملگی رخ می‌دهد.**\n\n"
    "⚠️ **و «تأخیر رگل در انتهای ماه دوم» با این زنجیره کاملاً می‌خواند.**\n\n"
    "**درس بالینی که باید از این سؤال ببرید:**\n\n"
    "**هر زن در سن باروری که ریفامپین شروع می‌کند، باید پیش از نخستین دوز درباره‌ی "
    "این تداخل مشاوره بگیرد.** این یک گفت‌وگوی دو دقیقه‌ای است که یک حاملگی ناخواسته "
    "را — در بدترین زمان ممکن، یعنی وسط درمان سل — پیشگیری می‌کند.\n\n"
    "**پیام مشاوره سه بخش دارد:**\n\n"
    "**الف) قرص خوراکی دیگر قابل اعتماد نیست.** روش غیرهورمونی لازم است — **IUD مسی** "
    "بهترین گزینه است، چون **اصلاً از راه کبد متابولیزه نمی‌شود**.\n\n"
    "**ب) این وضعیت تا پایان درمان ادامه دارد** — یعنی شش ماه.\n\n"
    "**ج) و تا دو تا چهار هفته پس از آخرین دوز ریفامپین هم ادامه دارد**، چون آنزیم‌های "
    "القاشده به‌تدریج کاهش می‌یابند.\n\n"
    "**نکته‌ی آرام‌بخش درباره‌ی خود حاملگی: داروهای خط اول ضدسل — ایزونیازید، "
    "ریفامپین، اتامبوتول — در بارداری بی‌خطر تلقی می‌شوند و درمان ادامه می‌یابد.** "
    "(پیرازینامید در بسیاری از راهنماها به‌ویژه سازمان جهانی بهداشت مجاز است.) "
    "**فقط پیریدوکسین را حتماً اضافه کنید.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**ایزونیازید** — مهارکننده‌ی P450 است نه القاکننده؛ سطح ضدبارداری را **پایین "
    "نمی‌آورد**.\n\n"
    "**اتامبوتول** — بدون تداخل معنادار.\n\n"
    "**پیرازینامید** — بدون تداخل معنادار.",
    "This question wraps the same interaction in a real clinical story — and that form makes it unforgettable.\n\n"
    "THE PATIENT: a 25-year-old woman who takes the LD contraceptive pill regularly. Over one month she develops productive cough, weight loss, fever and sweats. The film shows apical involvement and three sputum smears are AFB-positive. She starts six-month four-drug therapy. By the end of the second month her symptoms have resolved, but because of a missed period she has a beta-HCG test and PREGNANCY IS CONFIRMED.\n\n"
    "THE ANSWER: RIFAMPICIN.\n\n"
    "FOLLOW THE CAUSAL CHAIN:\n\n"
    "1. THE PATIENT TAKES THE LD PILL — a combined preparation of ETHINYLOESTRADIOL AND LEVONORGESTREL.\n\n"
    "2. RIFAMPICIN IS STARTED and POWERFULLY INDUCES HEPATIC CYP3A4.\n\n"
    "3. WITHIN ABOUT A WEEK the metabolism of both hormones multiplies and their blood levels fall below the threshold for suppressing ovulation.\n\n"
    "4. OVULATION RESUMES — while the patient IS TAKING HER PILL FAITHFULLY and believes she is protected.\n\n"
    "5. PREGNANCY OCCURS.\n\n"
    "WARNING: AND 'A MISSED PERIOD AT THE END OF THE SECOND MONTH' FITS THAT CHAIN EXACTLY.\n\n"
    "THE CLINICAL LESSON TO TAKE FROM THIS QUESTION:\n\n"
    "EVERY WOMAN OF REPRODUCTIVE AGE STARTING RIFAMPICIN MUST BE COUNSELLED ABOUT THIS INTERACTION BEFORE THE FIRST DOSE. It is a two-minute conversation that prevents an unintended pregnancy at the worst possible time — in the middle of tuberculosis treatment.\n\n"
    "THE COUNSELLING HAS THREE PARTS:\n\n"
    "(a) THE ORAL PILL IS NO LONGER RELIABLE. A non-hormonal method is required — A COPPER IUD is the best choice because IT IS NOT METABOLISED BY THE LIVER AT ALL.\n\n"
    "(b) THIS SITUATION LASTS THROUGHOUT TREATMENT — six months.\n\n"
    "(c) AND IT CONTINUES FOR TWO TO FOUR WEEKS AFTER THE LAST DOSE, as the induced enzymes gradually decline.\n\n"
    "A REASSURING POINT ABOUT THE PREGNANCY ITSELF: THE FIRST-LINE DRUGS — ISONIAZID, RIFAMPICIN, ETHAMBUTOL — ARE CONSIDERED SAFE IN PREGNANCY AND TREATMENT CONTINUES. (Pyrazinamide is permitted in many guidelines, notably WHO's.) JUST BE SURE TO ADD PYRIDOXINE.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ISONIAZID — a P450 inhibitor rather than an inducer; it does NOT lower contraceptive levels.\n\n"
    "ETHAMBUTOL — no meaningful interaction.\n\n"
    "PYRAZINAMIDE — no meaningful interaction.",
    ["پاسخ صحیح — القای CYP3A4 سطح هورمون‌های قرص LD را به زیر آستانه‌ی مهار تخمک‌گذاری برد.",
     "مهارکننده‌ی P450 است نه القاکننده؛ سطح ضدبارداری را پایین نمی‌آورد.",
     "تداخل معناداری با ضدبارداری هورمونی ندارد.",
     "تداخل معناداری با ضدبارداری هورمونی ندارد."],
    ["Correct — CYP3A4 induction drove the pill's hormone levels below the ovulation-suppressing threshold.",
     "A P450 inhibitor rather than an inducer; it does not lower contraceptive levels.",
     "No meaningful interaction with hormonal contraception.",
     "No meaningful interaction with hormonal contraception."],
    "**هر زن در سن باروری که ریفامپین می‌گیرد، باید پیش از نخستین دوز مشاوره‌ی ضدبارداری بگیرد.**",
    "Every woman of reproductive age starting rifampicin needs contraceptive counselling before the first dose.",
    REFS)

# ============================================ TUBERCULIN THRESHOLDS
PPD_FA = [
    "⚠️ **تست توبرکولین یک عدد ثابت ندارد — آستانه‌اش به خطر بیمار بستگی دارد.**",
    "**سه آستانه وجود دارد: پنج، ده، و پانزده میلی‌متر.**",
    "**پنج میلی‌متر در پرخطرترین‌ها مثبت است.**",
    "**عفونت HIV · تماس نزدیک و اخیر با بیمار مسری.**",
    "**تغییرات فیبروتیک گرافی به نفع سل قدیمی · گیرنده‌ی پیوند عضو.**",
    "**و سایر سرکوب‌های ایمنی، مثل پردنیزولون ۱۵ میلی‌گرم یا بیشتر برای یک ماه.**",
    "⚠️ **ده میلی‌متر در گروه‌های با خطر متوسط.**",
    "**مهاجران از کشورهای پرشیوع · معتادان تزریقی · کارکنان بهداشتی.**",
    "**ساکنان و کارکنان محیط‌های جمعی مانند زندان و آسایشگاه.**",
    "**بیماری‌های مزمن: دیابت، نارسایی کلیه، لوسمی، سیلیکوز · کودکان زیر پنج سال.**",
    "⚠️ **پانزده میلی‌متر در کسانی که هیچ عامل خطری ندارند.**",
    "**درس: پیش از خواندن عدد، بپرسید بیمار در کدام گروه است.**",
]
PPD_EN = [
    "WARNING: THE TUBERCULIN TEST HAS NO SINGLE CUT-OFF — its threshold depends on the patient's risk.",
    "There are three thresholds: five, ten and fifteen millimetres.",
    "FIVE MILLIMETRES is positive in the highest-risk groups.",
    "HIV infection; RECENT CLOSE CONTACT with an infectious case.",
    "Fibrotic changes on the film consistent with old tuberculosis; ORGAN TRANSPLANT recipients.",
    "And other immunosuppression, such as prednisolone 15 mg or more daily for a month.",
    "WARNING: TEN MILLIMETRES in intermediate-risk groups.",
    "Immigrants from high-prevalence countries; injecting drug users; HEALTH CARE WORKERS.",
    "Residents and staff of congregate settings such as prisons and nursing homes.",
    "Chronic illnesses: diabetes, renal failure, leukaemia, silicosis; and CHILDREN UNDER FIVE.",
    "WARNING: FIFTEEN MILLIMETRES in those with no risk factor at all.",
    "The lesson: before reading the number, ask which group the patient belongs to.",
]

add("book:262", "recall", "medium",
    "**اندوراسیون ۸ میلی‌متر در گیرنده‌ی پیوند عضو: مثبت است و پروفیلاکسی می‌خواهد.**",
    "An 8 mm induration in an organ transplant recipient: positive, and preventive therapy is needed.",
    PPD_FA, PPD_EN,
    "این سؤال، مهارت اصلی کار با تست توبرکولین را می‌سنجد: **عدد را در بستر خطر "
    "بخوانید، نه به‌تنهایی.**\n\n"
    "**سؤال: بیمار با ایندوریشن ۸ میلی‌متر. در حضور کدام‌یک از موارد زیر، پس از رد "
    "سل فعال، کموپروفیلاکسی توصیه می‌شود؟**\n\n"
    "**پاسخ: پیوند ارگان.**\n\n"
    "⚠️ **کلید: عدد ۸ بین دو آستانه است — بیشتر از ۵ ولی کمتر از ۱۰.** پس فقط برای "
    "گروهی مثبت است که **آستانه‌شان ۵ میلی‌متر** باشد.\n\n"
    "**سه آستانه را مرور کنیم و ببینیم هر گزینه کجاست:**\n\n"
    "**آستانه‌ی ۵ میلی‌متر — پرخطرترین‌ها:**\n\n"
    "**عفونت HIV** · **تماس نزدیک و اخیر با مورد مسری** · **تغییرات فیبروتیک در گرافی "
    "به نفع سل قدیمی** · ⚠️ **گیرنده‌ی پیوند عضو** · **سایر سرکوب‌های ایمنی: "
    "پردنیزولون ۱۵ میلی‌گرم یا بیشتر روزانه برای یک ماه یا بیشتر، و مهارکننده‌های "
    "TNF-α**\n\n"
    "**آستانه‌ی ۱۰ میلی‌متر — خطر متوسط:**\n\n"
    "**مهاجران اخیر از کشورهای پرشیوع** · ⚠️ **معتادان تزریقی** · **کارکنان بهداشتی** · "
    "**ساکنان و کارکنان محیط‌های جمعی (زندان، آسایشگاه، خوابگاه بی‌خانمان‌ها)** · "
    "**کارکنان آزمایشگاه مایکوباکتری** · **بیماری‌های مزمن: دیابت، نارسایی مزمن کلیه، "
    "لوسمی و لنفوم، سیلیکوز، گاسترکتومی، کاهش وزن شدید** · ⚠️ **کودکان زیر ۵ سال**\n\n"
    "**آستانه‌ی ۱۵ میلی‌متر — بدون هیچ عامل خطر.**\n\n"
    "**حالا گزینه‌ها:**\n\n"
    "⚠️ **پیوند ارگان** ✔ — **آستانه‌ی ۵ میلی‌متر.** پس **۸ میلی‌متر مثبت است.**\n\n"
    "**چرا این گروه در بالاترین رده است؟ دو دلیل جدی:**\n\n"
    "**۱. سرکوب ایمنی عمیق و دائمی.** گیرنده‌ی پیوند مادام‌العمر **مهارکننده‌ی "
    "کلسینورین (سیکلوسپورین یا تاکرولیموس) و کورتیکواستروئید** می‌گیرد — که دقیقاً "
    "**ایمنی سلولی نگهدارنده‌ی گرانولوم** را فلج می‌کند.\n\n"
    "**۲. عواقب سل فعال در پیوندی، فاجعه‌بار است:** مرگ‌ومیر بالا، و **تداخل شدید "
    "ریفامپین با داروهای سرکوب ایمنی** که می‌تواند به **رد پیوند** منجر شود. **پس "
    "پیشگیری به‌مراتب آسان‌تر از درمان است.**\n\n"
    "**اعتیاد تزریقی** ✘ — آستانه‌اش **۱۰** است. ۸ میلی‌متر **منفی** محسوب می‌شود.\n\n"
    "**سن زیر ۵ سال** ✘ — آستانه‌اش **۱۰** است. ۸ میلی‌متر **منفی** است. (البته اگر "
    "همان کودک **تماس نزدیک** با مورد مسری داشته باشد، به آستانه‌ی ۵ منتقل می‌شود — "
    "ولی سؤال چنین چیزی نگفته.)\n\n"
    "**جراحی گوارشی** ✘ — **گاسترکتومی** جزو عوامل خطر آستانه‌ی ۱۰ است، ولی «جراحی "
    "گوارشی» به‌طور کلی عامل خطر نیست، و در هر حال ۸ به آستانه‌ی ۱۰ نمی‌رسد.\n\n"
    "**درس روش‌شناختی: در هر سؤال PPD، اول گروه خطر را تعیین کنید، بعد عدد را "
    "بخوانید. عدد بدون بستر، بی‌معناست.**",
    "This question tests the essential skill of the tuberculin test: READ THE NUMBER IN ITS RISK CONTEXT, NOT ALONE.\n\n"
    "THE QUESTION: a patient with an 8 mm induration. In the presence of which of the following, after excluding active disease, is chemoprophylaxis recommended?\n\n"
    "THE ANSWER: ORGAN TRANSPLANT.\n\n"
    "WARNING: THE KEY IS THAT 8 SITS BETWEEN TWO THRESHOLDS — above 5 but below 10. So it is positive only for a group whose THRESHOLD IS 5 MM.\n\n"
    "REVIEW THE THREE THRESHOLDS AND SEE WHERE EACH OPTION FALLS:\n\n"
    "THE 5 MM THRESHOLD — THE HIGHEST-RISK GROUPS:\n\n"
    "HIV INFECTION; RECENT CLOSE CONTACT with an infectious case; FIBROTIC CHANGES on the film consistent with old tuberculosis; ORGAN TRANSPLANT RECIPIENTS; other immunosuppression, including prednisolone 15 mg or more daily for a month or more, and TNF-alpha blockers.\n\n"
    "THE 10 MM THRESHOLD — INTERMEDIATE RISK:\n\n"
    "recent immigrants from high-prevalence countries; INJECTING DRUG USERS; HEALTH CARE WORKERS; residents and staff of congregate settings (prisons, nursing homes, shelters); mycobacteriology laboratory staff; chronic illnesses such as diabetes, chronic renal failure, leukaemia and lymphoma, silicosis, gastrectomy and marked weight loss; and CHILDREN UNDER FIVE.\n\n"
    "THE 15 MM THRESHOLD — no risk factor at all.\n\n"
    "NOW THE OPTIONS:\n\n"
    "WARNING: ORGAN TRANSPLANT — THRESHOLD 5 MM. SO 8 MM IS POSITIVE.\n\n"
    "WHY IS THIS GROUP IN THE HIGHEST TIER? TWO SERIOUS REASONS:\n\n"
    "1. DEEP AND PERMANENT IMMUNOSUPPRESSION. A transplant recipient takes A CALCINEURIN INHIBITOR (ciclosporin or tacrolimus) AND A CORTICOSTEROID for life — precisely the agents that cripple THE CELL-MEDIATED IMMUNITY THAT MAINTAINS THE GRANULOMA.\n\n"
    "2. THE CONSEQUENCES OF ACTIVE TUBERCULOSIS IN A TRANSPLANT PATIENT ARE CATASTROPHIC: high mortality, and A SEVERE RIFAMPICIN INTERACTION WITH THE IMMUNOSUPPRESSANTS that can precipitate GRAFT REJECTION. SO PREVENTION IS FAR EASIER THAN TREATMENT.\n\n"
    "INJECTING DRUG USE — its threshold is 10. Eight millimetres counts as NEGATIVE.\n\n"
    "AGE UNDER 5 — its threshold is 10. Eight millimetres is NEGATIVE. (Of course, if that same child were a CLOSE CONTACT of an infectious case, he would move to the 5 mm threshold — but the question says no such thing.)\n\n"
    "GASTROINTESTINAL SURGERY — GASTRECTOMY is among the 10 mm risk factors, but 'gastrointestinal surgery' in general is not a risk factor, and in any case 8 does not reach 10.\n\n"
    "THE METHODOLOGICAL LESSON: in any PPD question, FIRST ESTABLISH THE RISK GROUP, THEN READ THE NUMBER. A number without context is meaningless.",
    ["آستانه‌اش ۱۰ میلی‌متر است؛ ۸ میلی‌متر در معتاد تزریقی منفی محسوب می‌شود.",
     "پاسخ صحیح — آستانه‌ی گیرنده‌ی پیوند ۵ میلی‌متر است، پس ۸ میلی‌متر مثبت است.",
     "آستانه‌ی کودک زیر ۵ سال هم ۱۰ میلی‌متر است؛ ۸ میلی‌متر به آن نمی‌رسد.",
     "جراحی گوارشی به‌طور کلی عامل خطر نیست، و ۸ به آستانه‌ی ۱۰ نمی‌رسد."],
    ["Its threshold is 10 mm; 8 mm counts as negative in an injecting drug user.",
     "Correct — a transplant recipient's threshold is 5 mm, so 8 mm is positive.",
     "A child under five also has a 10 mm threshold; 8 mm does not reach it.",
     "Gastrointestinal surgery in general is not a risk factor, and 8 does not reach the 10 mm threshold."],
    "**اول گروه خطر را تعیین کن، بعد عدد را بخوان — عدد بدون بستر بی‌معناست.**",
    "Establish the risk group first, then read the number — a number without context is meaningless.",
    REFSC)

add("book:263", "vignette", "medium",
    "**تبدیل تست در پرستار: ایزونیازید به‌مدت شش ماه.**",
    "Tuberculin conversion in a nurse: isoniazid for six months.",
    PPD_FA + [
        "⚠️ **«تبدیل تست» یعنی منفی بودن قبلی و مثبت شدن اکنون.**",
        "**و تبدیل، خطرناک‌تر از مثبت بودن ثابت است — چون عفونت تازه است.**",
    ],
    PPD_EN + [
        "WARNING: 'CONVERSION' MEANS A PREVIOUSLY NEGATIVE TEST THAT IS NOW POSITIVE.",
        "And conversion is more dangerous than a stable positive — because the infection is recent.",
    ],
    "این سؤال دو مفهوم را با هم می‌سنجد: **آستانه‌ی کارکنان بهداشتی**، و **معنای "
    "تبدیل تست**.\n\n"
    "**بیمار: پرستاری در بخش عفونی. آزمایش‌ها و معاینات بدو استخدام همگی نرمال "
    "بوده‌اند. دو سال پس از استخدام، در بررسی روتین سالیانه، PPD=15 میلی‌متر است.**\n\n"
    "**پاسخ: دادن ایزونیازید به‌مدت شش ماه.**\n\n"
    "**دو گام تحلیل:**\n\n"
    "**گام یک — آیا این تست مثبت است؟**\n\n"
    "**پرستار = کارکن بهداشتی = آستانه‌ی ۱۰ میلی‌متر.** عدد ۱۵ **کاملاً بالاتر** از "
    "آستانه است. **پس مثبت است.**\n\n"
    "⚠️ **گام دو، و مهم‌تر — این فقط «مثبت» نیست، این «تبدیل» است.**\n\n"
    "**در بدو استخدام همه‌چیز نرمال بوده و حالا مثبت شده.** این یعنی **عفونت طی این "
    "دو سال رخ داده**.\n\n"
    "**چرا تبدیل تست این‌قدر مهم‌تر از مثبت بودن ثابت است؟**\n\n"
    "**چون بزرگ‌ترین خطر پیشرفت به بیماری فعال، در دو سال نخست پس از عفونت است.** "
    "از آن ۱۰٪ خطر مادام‌العمر، **حدود نیمی در همان دو سال اول متمرکز است**. "
    "**پس این پرستار دقیقاً در پنجره‌ی پرخطر قرار دارد.**\n\n"
    "**و از منظر بهداشت شغلی، تبدیل تست یعنی یک چیز دیگر هم: انتقال در محیط کار رخ "
    "داده و باید بررسی شود.**\n\n"
    "**پس درمان عفونت نهفته (LTBI) لازم است، پس از رد کردن سل فعال با گرافی و شرح "
    "حال.**\n\n"
    "**رژیم‌های درمان عفونت نهفته:**\n\n"
    "**کلید کتاب: ایزونیازید ۶ ماه.** رژیم کلاسیک، مؤثر، ارزان.\n\n"
    "⚠️ **و آنچه امروز باید بدانید:** راهنمای **CDC/NTCA سال ۲۰۲۰** رژیم‌های "
    "**کوتاه‌مدت مبتنی بر ریفامایسین** را **ترجیح می‌دهد**:\n\n"
    "**3HP** — ایزونیازید + ریفاپنتین، هفتگی، ۳ ماه (۱۲ دوز) · **4R** — ریفامپین "
    "روزانه، ۴ ماه · **3HR** — ایزونیازید + ریفامپین روزانه، ۳ ماه\n\n"
    "**و ۶ یا ۹ ماه ایزونیازید، امروز «جایگزین» محسوب می‌شود، نه «ترجیحی».**\n\n"
    "**چرا این تغییر؟** چون رژیم‌های کوتاه **نرخ تکمیل بسیار بالاتری** دارند (بیمار "
    "۳ ماه را تمام می‌کند ولی ۹ ماه را نه) و **سمّیت کبدی کمتری** دارند. **این یک "
    "جابه‌جایی راهنماست، نه خطای کتاب — پس کلید تصحیح نمی‌شود.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**نیاز به کموپروفیلاکسی ندارد** — نادرست. ۱۵ میلی‌متر در کارکن بهداشتی با "
    "تبدیل تست، **قطعاً درمان می‌خواهد**.\n\n"
    "**INH به‌مدت دوازده ماه** — **بیش از حد.** ۱۲ ماه ایزونیازید در هیچ راهنمایی "
    "توصیه نمی‌شود؛ سود اضافی ندارد و سمّیت کبدی و ترک درمان را بیشتر می‌کند.\n\n"
    "⚠️ **تکرار تست پوستی ۶ تا ۸ هفته بعد** — این کار برای **پدیده‌ی بوستر** انجام "
    "می‌شود (وقتی تست اول، پاسخ خفته را بیدار می‌کند). **ولی اینجا بی‌معناست**، چون "
    "بیمار **تست پایه‌ی منفی مستند** دارد. **وقتی پایه معلوم است، تبدیل قطعی است و "
    "تکرار فقط تأخیر می‌سازد.**",
    "This question tests two concepts at once: THE HEALTH-CARE-WORKER THRESHOLD, and THE MEANING OF CONVERSION.\n\n"
    "THE PATIENT: a nurse working on an infectious diseases ward. Her pre-employment examinations and tests were all normal. Two years after appointment, on annual routine screening, her PPD is 15 MM.\n\n"
    "THE ANSWER: ISONIAZID FOR SIX MONTHS.\n\n"
    "TWO STEPS OF ANALYSIS:\n\n"
    "STEP ONE — IS THIS TEST POSITIVE?\n\n"
    "A NURSE IS A HEALTH CARE WORKER, SO THE THRESHOLD IS 10 MM. Fifteen is well above it. SO YES, POSITIVE.\n\n"
    "WARNING, STEP TWO, AND MORE IMPORTANT — THIS IS NOT MERELY 'POSITIVE', IT IS A CONVERSION.\n\n"
    "EVERYTHING WAS NORMAL AT APPOINTMENT AND IS NOW POSITIVE. That means THE INFECTION OCCURRED WITHIN THESE TWO YEARS.\n\n"
    "WHY IS CONVERSION SO MUCH MORE IMPORTANT THAN A STABLE POSITIVE?\n\n"
    "BECAUSE THE GREATEST RISK OF PROGRESSION TO ACTIVE DISEASE LIES IN THE FIRST TWO YEARS AFTER INFECTION. Of that 10 % lifetime risk, ABOUT HALF IS CONCENTRATED IN THOSE FIRST TWO YEARS. SO THIS NURSE SITS EXACTLY IN THE HIGH-RISK WINDOW.\n\n"
    "AND FROM AN OCCUPATIONAL HEALTH VIEW, A CONVERSION MEANS SOMETHING ELSE TOO: TRANSMISSION HAS OCCURRED IN THE WORKPLACE and must be investigated.\n\n"
    "SO TREATMENT OF LATENT INFECTION IS REQUIRED, after excluding active disease by history and chest film.\n\n"
    "THE LATENT-INFECTION REGIMENS:\n\n"
    "THE BOOK'S KEY: ISONIAZID FOR 6 MONTHS. The classical regimen — effective and cheap.\n\n"
    "WARNING, AND WHAT YOU MUST KNOW TODAY: the 2020 CDC/NTCA guideline PREFERS SHORT-COURSE RIFAMYCIN-BASED REGIMENS:\n\n"
    "3HP — isoniazid plus rifapentine, weekly, 3 months (12 doses); 4R — daily rifampicin, 4 months; 3HR — daily isoniazid plus rifampicin, 3 months.\n\n"
    "AND 6 OR 9 MONTHS OF ISONIAZID IS NOW CLASSED AS 'ALTERNATIVE' RATHER THAN 'PREFERRED'.\n\n"
    "WHY THE CHANGE? Because the short regimens have MUCH HIGHER COMPLETION RATES (a patient finishes three months but not nine) and LESS HEPATOTOXICITY. THIS IS A GUIDELINE SHIFT, NOT AN ERROR IN THE BOOK — so the key is not corrected.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "'NO CHEMOPROPHYLAXIS NEEDED' — wrong. Fifteen millimetres in a health care worker with conversion DEFINITELY REQUIRES TREATMENT.\n\n"
    "ISONIAZID FOR TWELVE MONTHS — TOO LONG. Twelve months of isoniazid is recommended by no guideline; it adds no benefit and increases both hepatotoxicity and default.\n\n"
    "WARNING: REPEATING THE SKIN TEST IN 6 TO 8 WEEKS — that is done for THE BOOSTER PHENOMENON (when the first test awakens a waned response). BUT IT IS MEANINGLESS HERE, because the patient HAS A DOCUMENTED NEGATIVE BASELINE. WHEN THE BASELINE IS KNOWN, THE CONVERSION IS CERTAIN AND REPEATING ONLY CREATES DELAY.",
    ["نادرست است؛ ۱۵ میلی‌متر در کارکن بهداشتی با تبدیل تست، قطعاً درمان می‌خواهد.",
     "پاسخ صحیح (کلید کتاب) — درمان عفونت نهفته با ایزونیازید شش ماهه.",
     "بیش از حد؛ ۱۲ ماه ایزونیازید در هیچ راهنمایی توصیه نمی‌شود.",
     "برای پدیده‌ی بوستر است، ولی این بیمار تست پایه‌ی منفی مستند دارد و تبدیل قطعی است."],
    ["Wrong; 15 mm in a health care worker with conversion definitely requires treatment.",
     "Correct (the book's key) — treatment of latent infection with six months of isoniazid.",
     "Too long; twelve months of isoniazid is recommended by no guideline.",
     "That is for the booster phenomenon, but this nurse has a documented negative baseline and the conversion is certain."],
    "**تبدیل تست از مثبت ثابت خطرناک‌تر است — نیمی از خطر عمر، در دو سال اول است.**",
    "A conversion is more dangerous than a stable positive — half the lifetime risk falls in the first two years.",
    REFSC)

add("book:267", "vignette", "medium",
    "**PPD دوازده میلی‌متر در بیمار تحت کورتون طولانی: درمان پیشگیرانه.**",
    "A 12 mm PPD in a patient on prolonged corticosteroids: preventive treatment.",
    PPD_FA + [
        "⚠️ **کورتیکواستروئید طولانی، بیمار را به آستانه‌ی ۵ میلی‌متر می‌برد.**",
        "**معیار رایج: پردنیزولون ۱۵ میلی‌گرم یا بیشتر در روز، برای یک ماه یا بیشتر.**",
    ],
    PPD_EN + [
        "WARNING: PROLONGED CORTICOSTEROID THERAPY MOVES THE PATIENT TO THE 5 MM THRESHOLD.",
        "The usual criterion: prednisolone 15 mg or more daily for a month or longer.",
    ],
    "این سؤال، ترکیب دو خطر را می‌سنجد: **سرکوب ایمنی دارویی** و **شغل پرمواجهه**.\n\n"
    "**بیمار: خانم پرستار مبتلا به لوپوس اریتماتوز سیستمیک، تحت درمان طولانی‌مدت با "
    "استروئید. در آزمایش‌های روتین، تست مانتو ۱۲ میلی‌متر. معاینات بدون نکته‌ی مثبت.**\n\n"
    "**پاسخ: درمان دارویی پیشگیرانه.**\n\n"
    "**این بیمار در دو گروه خطر هم‌زمان قرار دارد — و هر دو تنها به یک نتیجه "
    "می‌رسند:**\n\n"
    "⚠️ **گروه اول: سرکوب ایمنی با کورتیکواستروئید ⇐ آستانه‌ی ۵ میلی‌متر.**\n\n"
    "**معیار پذیرفته‌شده: پردنیزولون ۱۵ میلی‌گرم یا بیشتر در روز، برای یک ماه یا "
    "بیشتر.** بیمار «درمان طولانی‌مدت» می‌گیرد، پس در این گروه است.\n\n"
    "**چرا کورتون این‌قدر خطرناک است؟** چون **دقیقاً همان ایمنی سلولی را می‌زند که "
    "گرانولوم را نگه می‌دارد**: تولید IL-2 و اینترفرون گاما را کاهش می‌دهد، عملکرد "
    "ماکروفاژ را مختل می‌کند، و **گرانولوم موجود را از هم می‌پاشد**.\n\n"
    "**و لوپوس خودش هم یک بیماری خودایمنی با اختلال ایمنی است، که خطر را بیشتر "
    "می‌کند.**\n\n"
    "**گروه دوم: کارکن بهداشتی ⇐ آستانه‌ی ۱۰ میلی‌متر.**\n\n"
    "**۱۲ میلی‌متر از هر دو آستانه (۵ و ۱۰) بالاتر است. پس با هر معیاری، مثبت است.**\n\n"
    "**و «معاینات بدون نکته‌ی مثبت» یعنی سل فعال ندارد — پس تشخیص، عفونت نهفته است "
    "و درمان پیشگیرانه لازم است.**\n\n"
    "⚠️ **یک نکته‌ی حیاتی که سؤال نمی‌پرسد ولی بالین می‌پرسد: پیش از شروع درمان "
    "پیشگیرانه، حتماً سل فعال را رد کنید.** حداقل با **گرافی قفسه‌ی سینه** و شرح "
    "حال دقیق. **چرا؟** چون **ایزونیازید تنها، در سل فعال یعنی تک‌درمانی** — و "
    "تک‌درمانی سل فعال، مطمئن‌ترین راه ساختن مقاومت به ایزونیازید است.\n\n"
    "**نکته‌ی دوم برای بالین: در بیمار لوپوسی، ایزونیازید انتخاب حساسی است، چون "
    "ایزونیازید می‌تواند سندرم شبه‌لوپوس بدهد.** در عمل معمولاً مشکل‌ساز نیست، ولی "
    "پایش لازم است — و **رژیم مبتنی بر ریفامپین (4R) گزینه‌ی جایگزین خوبی است**، "
    "به شرط توجه به **تداخل ریفامپین با کورتیکواستروئید** (که سطح استروئید را "
    "پایین می‌آورد و می‌تواند لوپوس را شعله‌ور کند).\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**اقدام خاصی لازم نیست** — نادرست و خطرناک. **این بیمار در یکی از پرخطرترین "
    "گروه‌ها برای فعال شدن سل است.**\n\n"
    "**درمان دارویی استاندارد** — یعنی رژیم چهاردارویی سل **فعال**. ولی این بیمار "
    "**بیماری فعال ندارد**. **درمان بیش از حد، بیمار را در معرض سمّیت چهار دارو "
    "قرار می‌دهد بدون هیچ سودی.**\n\n"
    "**تکرار تست پوستی** — **بی‌فایده.** تست قبلاً به‌روشنی مثبت است. **تکرار فقط "
    "شروع درمان را به تأخیر می‌اندازد، در بیماری که هر هفته تأخیر برایش خطر "
    "دارد.**",
    "This question tests a combination of two risks: DRUG-INDUCED IMMUNOSUPPRESSION and A HIGH-EXPOSURE OCCUPATION.\n\n"
    "THE PATIENT: a nurse with systemic lupus erythematosus on long-term corticosteroid therapy. Routine testing gives a Mantoux of 12 MM. Examination reveals nothing.\n\n"
    "THE ANSWER: PREVENTIVE DRUG TREATMENT.\n\n"
    "THIS PATIENT BELONGS TO TWO RISK GROUPS AT ONCE — AND BOTH LEAD TO THE SAME CONCLUSION:\n\n"
    "WARNING, GROUP ONE: CORTICOSTEROID IMMUNOSUPPRESSION MEANS THE 5 MM THRESHOLD.\n\n"
    "THE ACCEPTED CRITERION: prednisolone 15 mg or more daily for a month or longer. She is on 'long-term treatment', so she qualifies.\n\n"
    "WHY ARE STEROIDS SO DANGEROUS HERE? Because they strike EXACTLY THE CELL-MEDIATED IMMUNITY THAT HOLDS THE GRANULOMA TOGETHER: they reduce IL-2 and interferon-gamma production, impair macrophage function, and CAN DISASSEMBLE AN EXISTING GRANULOMA.\n\n"
    "AND LUPUS ITSELF IS AN AUTOIMMUNE DISEASE WITH IMMUNE DYSREGULATION, which adds further risk.\n\n"
    "GROUP TWO: HEALTH CARE WORKER, THRESHOLD 10 MM.\n\n"
    "TWELVE MILLIMETRES EXCEEDS BOTH THRESHOLDS (5 AND 10). SO BY ANY CRITERION IT IS POSITIVE.\n\n"
    "AND 'examination reveals nothing' means there is no active disease — so the diagnosis is latent infection and preventive treatment is indicated.\n\n"
    "WARNING, A VITAL POINT THE QUESTION DOES NOT ASK BUT THE BEDSIDE DOES: BEFORE STARTING PREVENTIVE THERAPY, ALWAYS EXCLUDE ACTIVE DISEASE — at minimum with a CHEST RADIOGRAPH and a careful history. WHY? Because ISONIAZID ALONE IN ACTIVE DISEASE IS MONOTHERAPY — and monotherapy of active tuberculosis is the surest way to create isoniazid resistance.\n\n"
    "A SECOND BEDSIDE POINT: in a lupus patient, isoniazid is a delicate choice, because ISONIAZID CAN ITSELF CAUSE A LUPUS-LIKE SYNDROME. In practice this is usually not a problem, but monitoring is needed — and A RIFAMPICIN-BASED REGIMEN (4R) IS A GOOD ALTERNATIVE, provided one remembers THE RIFAMPICIN-CORTICOSTEROID INTERACTION (which lowers steroid levels and can flare the lupus).\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "'NOTHING NEEDS TO BE DONE' — wrong and dangerous. THIS PATIENT IS IN ONE OF THE HIGHEST-RISK GROUPS FOR REACTIVATION.\n\n"
    "'STANDARD DRUG TREATMENT' — that means the four-drug regimen for ACTIVE disease. But this patient HAS NO ACTIVE DISEASE. OVER-TREATMENT EXPOSES HER TO FOUR DRUGS' TOXICITY FOR NO BENEFIT.\n\n"
    "'REPEAT THE SKIN TEST' — POINTLESS. The test is already clearly positive. REPEATING ONLY DELAYS TREATMENT IN A PATIENT FOR WHOM EVERY WEEK OF DELAY CARRIES RISK.",
    ["نادرست و خطرناک؛ کورتون طولانی، بیمار را در پرخطرترین گروه فعال شدن سل می‌گذارد.",
     "رژیم سل فعال است ولی این بیمار بیماری فعال ندارد؛ درمان بیش از حد و پرعارضه.",
     "بی‌فایده؛ تست قبلاً به‌روشنی مثبت است و تکرار فقط تأخیر می‌سازد.",
     "پاسخ صحیح — کورتون طولانی آستانه را به ۵ می‌برد و ۱۲ میلی‌متر قطعاً مثبت است."],
    ["Wrong and dangerous; prolonged steroids place her in the highest-risk group for reactivation.",
     "That is the active-disease regimen, but she has no active disease; over-treatment with no benefit.",
     "Pointless; the test is already clearly positive and repeating only delays treatment.",
     "Correct — prolonged steroids move the threshold to 5 mm and 12 mm is definitely positive."],
    "**پیش از هر درمان پیشگیرانه، سل فعال را رد کن — ایزونیازید تنها در سل فعال یعنی مقاومت.**",
    "Before any preventive therapy, exclude active disease — isoniazid alone in active tuberculosis means resistance.",
    REFSC)

json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book55.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 55 lessons:', len(L))
