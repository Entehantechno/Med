# -*- coding: utf-8 -*-
"""Micro-lessons, batch 53 — tuberculosis part three: the regimens.
First-line therapy, retreatment after relapse or default, extrapulmonary
regimens, and drug-resistant disease.

THE STANDARD REGIMEN, WHICH EVERY QUESTION IN THIS BLOCK ORBITS
-----------------------------------------------------------------
    2 HRZE  /  4 HR

    INTENSIVE PHASE, two months: isoniazid (H), rifampicin (R),
        pyrazinamide (Z), ethambutol (E) — four drugs, daily
    CONTINUATION PHASE, four months: isoniazid and rifampicin

WHY FOUR DRUGS AND NOT ONE? Because a cavity contains about 10^8 to 10^9
bacilli, and spontaneous resistance mutations occur at roughly 1 in 10^6 for
isoniazid and 1 in 10^8 for rifampicin. So a cavity ALREADY CONTAINS resistant
mutants before any drug is given. Monotherapy simply selects them. But a
mutant resistant to two drugs at once would require a frequency of 1 in 10^14,
which is far more bacilli than a human body can hold. THAT ARITHMETIC IS THE
ENTIRE JUSTIFICATION FOR COMBINATION THERAPY.

WHY EACH DRUG IS THERE
    ISONIAZID     the most powerful early bactericidal drug — it kills the
                  rapidly dividing extracellular population, which is what
                  makes the patient non-infectious within weeks
    RIFAMPICIN    the STERILISING drug — it kills semi-dormant bacilli in
                  spurts of metabolism. It is rifampicin that shortened
                  treatment from 18 months to 6, and losing it is the single
                  most consequential loss in the whole chapter
    PYRAZINAMIDE  active ONLY in an acid environment, so it kills the
                  intracellular and inflamed-focus population; it is what
                  allowed the continuation phase to shrink to 4 months
    ETHAMBUTOL    the weakest — it is present as a GUARD, to protect the
                  other three against unsuspected isoniazid resistance

LONGER THAN SIX MONTHS
    CNS tuberculosis (meningitis, tuberculoma)   9 to 12 months, plus steroid
    bone and joint tuberculosis                  9 to 12 months
    everything else, including lymph node,
    pleura, kidney and disseminated disease      the same 6 months

RETREATMENT: WHAT CHANGED, AND WHY IT MATTERS FOR THIS BOOK
--------------------------------------------------------------
The book teaches the old CATEGORY II regimen (2HRZES / 1HRZE / 5HRE) for a
patient returning after relapse or default. In 2017 the WHO Guideline
Development Group issued a good practice statement that THE CATEGORY II
REGIMEN SHOULD NO LONGER BE PRESCRIBED, and that DRUG SUSCEPTIBILITY TESTING
should instead determine the regimen: if no resistance is found, the standard
first-line regimen is simply repeated. The reasoning is that adding a single
drug (streptomycin) to a regimen that has already failed amplifies resistance
rather than curing it.

These lessons therefore teach BOTH: the book's key, so the student answers the
examination correctly, AND the current standard, so the student is not
misinformed at the bedside. No key is changed, because the change is a
guideline shift and not a factual error in the book.

DRUG-RESISTANT DISEASE — THE DEFINITIONS AS THEY STAND NOW
-------------------------------------------------------------
    MDR-TB      resistant to at least isoniazid AND rifampicin
    pre-XDR     MDR/RR-TB plus resistance to any fluoroquinolone
    XDR-TB      (2021 definition) MDR/RR-TB plus fluoroquinolone resistance
                plus resistance to at least one other Group A drug
                (bedaquiline or linezolid)
    and the WHO's 2022 preferred regimen is BPaLM — bedaquiline, pretomanid,
    linezolid and moxifloxacin — six months, all oral

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022) —
tuberculosis; WHO consolidated guidelines on tuberculosis, Module 4:
Treatment (2022 update).
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — tuberculosis")
WHO4 = ("WHO consolidated guidelines on tuberculosis, Module 4: Treatment — "
        "drug-susceptible and drug-resistant tuberculosis (2022 update)")
NTP = "راهنمای کشوری مبارزه با سل — National Tuberculosis Programme guideline"
REFS = [H]
REFSW = [H, WHO4]
REFSN = [H, WHO4, NTP]

# ==================================================== FIRST-LINE DRUGS
FIRST_FA = [
    "**رژیم استاندارد سل حساس: دو ماه HRZE، سپس چهار ماه HR.**",
    "**یعنی ایزونیازید، ریفامپین، پیرازینامید و اتامبوتول در فاز حمله‌ای.**",
    "**و ایزونیازید و ریفامپین در فاز نگهدارنده.**",
    "⚠️ **چرا چهار دارو؟ چون کاویته پیش از هر دارویی، جهش‌یافته‌ی مقاوم دارد.**",
    "**جهش مقاومت به ایزونیازید حدود یک در ۱۰ به توان ۶ است.**",
    "**و کاویته حدود ۱۰ به توان ۸ تا ۹ باسیل دارد — پس مقاوم‌ها آنجا هستند.**",
    "**تک‌دارو فقط آن‌ها را انتخاب می‌کند؛ ترکیب، همه را می‌کشد.**",
    "**ایزونیازید: قوی‌ترین کشنده‌ی زودرس، جمعیت خارج‌سلولی فعال را می‌زند.**",
    "⚠️ **ریفامپین: داروی استریل‌کننده — نیمه‌خفته‌ها را می‌کشد.**",
    "**ریفامپین بود که درمان را از ۱۸ ماه به ۶ ماه رساند.**",
    "**پیرازینامید: فقط در محیط اسیدی کار می‌کند، پس داخل سلول و کانون ملتهب.**",
    "⚠️ **اتامبوتول: ضعیف‌ترین — نگهبان است، نه سرباز خط مقدم.**",
]
FIRST_EN = [
    "The standard regimen for susceptible tuberculosis: two months of HRZE, then four months of HR.",
    "That is isoniazid, rifampicin, pyrazinamide and ethambutol in the intensive phase.",
    "And isoniazid with rifampicin in the continuation phase.",
    "WARNING: WHY FOUR DRUGS? Because a cavity contains resistant mutants BEFORE any drug is given.",
    "The mutation rate to isoniazid resistance is about one in ten to the sixth.",
    "And a cavity holds about ten to the eighth or ninth bacilli — so the mutants are already there.",
    "Monotherapy merely selects them; combination therapy kills them all.",
    "ISONIAZID: the most powerful early bactericidal drug, killing the active extracellular population.",
    "WARNING: RIFAMPICIN IS THE STERILISING DRUG — it kills the semi-dormant organisms.",
    "It was rifampicin that shortened treatment from 18 months to 6.",
    "PYRAZINAMIDE: active only in an ACID environment, so intracellular and in inflamed foci.",
    "WARNING: ETHAMBUTOL IS THE WEAKEST — it is a GUARD, not a front-line soldier.",
]

add("book:225", "recall", "medium",
    "**لووفلوکساسین جزو خط اول درمان سل نیست.**",
    "Levofloxacin is not a first-line antituberculous drug.",
    FIRST_FA, FIRST_EN,
    "این سؤال ساده است ولی یک اصل بسیار مهم را می‌سنجد که در جای دیگر همین فصل هم "
    "به‌کار می‌آید.\n\n"
    "**بیمار: آقای ۵۵ ساله با سرفه، خلط خونی و کاهش وزن حدود ۱۰ کیلوگرم، با تشخیص "
    "سل ریوی اسمیر مثبت. کدام‌یک خط اول نیست؟**\n\n"
    "**پاسخ: لووفلوکساسین.**\n\n"
    "**چهار داروی خط اول سل، یک مجموعه‌ی بسته و ثابت‌اند:**\n\n"
    "**ایزونیازید (H) · ریفامپین (R) · پیرازینامید (Z) · اتامبوتول (E)**\n\n"
    "(استرپتومایسین زمانی جزو خط اول شمرده می‌شد، ولی امروز به‌دلیل تزریقی بودن و "
    "سمّیت گوشی و کلیوی، از رژیم‌های استاندارد کنار رفته است.)\n\n"
    "**نقش هر کدام را یک‌بار بفهمید و دیگر فراموش نمی‌کنید:**\n\n"
    "**ایزونیازید** — **قوی‌ترین کشنده‌ی زودرس**. جمعیت **خارج‌سلولی و سریع‌تقسیم‌شونده** "
    "را در چند روز نابود می‌کند. **همین است که بیمار را ظرف دو هفته غیرمسری می‌کند.**\n\n"
    "⚠️ **ریفامپین** — **داروی استریل‌کننده**. باسیل‌های **نیمه‌خفته** را که هر از گاهی "
    "متابولیسم کوتاهی دارند، می‌کشد. **این‌ها همان‌هایی هستند که اگر بمانند، عود "
    "می‌سازند.** ریفامپین بود که مدت درمان را از **۱۸ ماه به ۶ ماه** رساند — و به "
    "همین دلیل، **از دست دادن ریفامپین بزرگ‌ترین فاجعه‌ی این فصل است.**\n\n"
    "**پیرازینامید** — فقط در **محیط اسیدی** فعال است، پس دقیقاً باسیل‌های **درون "
    "ماکروفاژ و درون کانون ملتهب** را می‌زند. حضورش در دو ماه اول، فاز نگهدارنده را "
    "از ۷ ماه به ۴ ماه کوتاه کرد.\n\n"
    "**اتامبوتول** — **ضعیف‌ترین.** عملاً باکتریواستاتیک است. **نقشش نگهبانی است:** اگر "
    "سویه بدون اطلاع ما به ایزونیازید مقاوم باشد، اتامبوتول جلوی تک‌دارو شدن "
    "ریفامپین را می‌گیرد.\n\n"
    "**و حالا لووفلوکساسین کجاست؟**\n\n"
    "⚠️ **لووفلوکساسین یک فلوروکینولون است و ضدسل مؤثری هم هست — ولی جایگاهش خط دوم "
    "است، در گروه A رژیم‌های MDR-TB.** در واقع در درمان سل مقاوم، فلوروکینولون‌ها "
    "**ستون فقرات** رژیم‌اند.\n\n"
    "**و همین است که استفاده‌ی بی‌جای آن‌ها را خطرناک می‌کند:** هر بار که برای یک سرفه‌ی "
    "مبهم لووفلوکساسین تجویز می‌شود، **احتمال ساخته شدن مقاومت فلوروکینولونی در "
    "سویه‌ای که هنوز تشخیص داده نشده، بالا می‌رود** — و آن سویه بعداً pre-XDR می‌شود.\n\n"
    "**سه گزینه‌ی دیگر (ریفامپین، ایزونیازید، پیرازینامید) همگی هسته‌ی خط اول‌اند و "
    "بدون آن‌ها رژیم شش‌ماهه ممکن نیست.**",
    "This question is simple but tests a very important principle that reappears elsewhere in this chapter.\n\n"
    "THE PATIENT: a 55-year-old man with cough, haemoptysis and about 10 kg of weight loss, diagnosed with smear-positive pulmonary tuberculosis. Which is NOT first-line?\n\n"
    "THE ANSWER: LEVOFLOXACIN.\n\n"
    "THE FOUR FIRST-LINE ANTITUBERCULOUS DRUGS ARE A CLOSED, FIXED SET:\n\n"
    "ISONIAZID (H), RIFAMPICIN (R), PYRAZINAMIDE (Z), ETHAMBUTOL (E).\n\n"
    "(Streptomycin was once counted as first-line, but being injectable and both oto- and nephrotoxic it has left the standard regimens.)\n\n"
    "UNDERSTAND EACH ROLE ONCE AND YOU WILL NOT FORGET IT:\n\n"
    "ISONIAZID — THE MOST POWERFUL EARLY BACTERICIDAL DRUG. It destroys the EXTRACELLULAR, RAPIDLY DIVIDING population within days. THAT IS WHAT RENDERS THE PATIENT NON-INFECTIOUS WITHIN ABOUT TWO WEEKS.\n\n"
    "WARNING: RIFAMPICIN — THE STERILISING DRUG. It kills the SEMI-DORMANT bacilli that metabolise only in brief spurts. THOSE ARE THE ORGANISMS THAT CAUSE RELAPSE IF THEY SURVIVE. It was rifampicin that cut treatment from 18 MONTHS TO 6 — which is why LOSING RIFAMPICIN IS THE GREATEST DISASTER IN THIS CHAPTER.\n\n"
    "PYRAZINAMIDE — active only in an ACID environment, so it strikes exactly the bacilli INSIDE MACROPHAGES AND INSIDE INFLAMED FOCI. Its presence in the first two months shortened the continuation phase from 7 months to 4.\n\n"
    "ETHAMBUTOL — THE WEAKEST. Essentially bacteriostatic. ITS ROLE IS TO STAND GUARD: if the strain is unknowingly isoniazid-resistant, ethambutol prevents rifampicin from becoming effective monotherapy.\n\n"
    "AND WHERE DOES LEVOFLOXACIN SIT?\n\n"
    "WARNING: LEVOFLOXACIN IS A FLUOROQUINOLONE AND IS GENUINELY ACTIVE AGAINST TUBERCULOSIS — but its place is SECOND LINE, in Group A of MDR-TB regimens. In drug-resistant disease the fluoroquinolones are in fact THE BACKBONE of the regimen.\n\n"
    "AND THAT IS WHAT MAKES CASUAL USE DANGEROUS: every time levofloxacin is prescribed for an undifferentiated cough, THE CHANCE OF BREEDING FLUOROQUINOLONE RESISTANCE IN AN AS-YET-UNDIAGNOSED STRAIN RISES — and that strain later becomes pre-XDR.\n\n"
    "The other three (rifampicin, isoniazid, pyrazinamide) are all core first-line drugs, and without them the six-month regimen is impossible.",
    ["داروی استریل‌کننده و ستون رژیم شش‌ماهه؛ کاملاً خط اول است.",
     "قوی‌ترین کشنده‌ی زودرس و بخش جدایی‌ناپذیر خط اول.",
     "در محیط اسیدی داخل سلول کار می‌کند و فاز نگهدارنده را کوتاه کرد؛ خط اول است.",
     "پاسخ صحیح — فلوروکینولون خط دوم و ستون رژیم‌های MDR است، نه خط اول."],
    ["The sterilising drug and the pillar of the six-month regimen; firmly first-line.",
     "The most powerful early bactericidal drug and an inseparable part of first-line therapy.",
     "Works in the acid intracellular environment and shortened the continuation phase; first-line.",
     "Correct — a second-line fluoroquinolone and the backbone of MDR regimens, not first-line."],
    "**چهار داروی خط اول یک مجموعه‌ی بسته است: HRZE. فلوروکینولون خط دوم است.**",
    "The four first-line drugs are a closed set, HRZE. The fluoroquinolone is second line.",
    REFSW)

# ==================================================== RETREATMENT
RETREAT_FA = [
    "⚠️ **بیمار «درمان‌گرفته‌ی قبلی» با بیمار جدید یکسان نیست.**",
    "**چون احتمال مقاومت دارویی در او به‌مراتب بیشتر است.**",
    "**کتاب، رژیم دسته‌ی دوم را آموزش می‌دهد: دو ماه HRZES، یک ماه HRZE، پنج ماه HRE.**",
    "**که جمعاً هشت ماه می‌شود، با افزودن استرپتومایسین در دو ماه اول.**",
    "⚠️ **ولی راهنمای امروزی این رژیم را کنار گذاشته است.**",
    "**سازمان جهانی بهداشت در سال ۲۰۱۷ اعلام کرد رژیم دسته‌ی دوم دیگر تجویز نشود.**",
    "**دلیل: افزودن یک دارو به رژیمی که شکست خورده، مقاومت را تکثیر می‌کند.**",
    "**جایگزین امروزی: آزمون حساسیت دارویی سریع، و سپس رژیم بر پایه‌ی نتیجه.**",
    "**اگر مقاومتی نبود، همان رژیم استاندارد شش‌ماهه تکرار می‌شود.**",
    "**اگر مقاومت به ریفامپین بود، رژیم MDR شروع می‌شود.**",
    "⚠️ **پس در امتحان، کلید کتاب را بدهید؛ در بالین، Xpert را بفرستید.**",
    "**و در هر دو حالت، کشت و آنتی‌بیوگرام الزامی است.**",
]
RETREAT_EN = [
    "WARNING: A PREVIOUSLY TREATED PATIENT IS NOT THE SAME AS A NEW PATIENT.",
    "Because the probability of drug resistance in him is far higher.",
    "The book teaches the Category II regimen: two months HRZES, one month HRZE, five months HRE.",
    "Eight months in total, with streptomycin added for the first two months.",
    "WARNING, BUT CURRENT GUIDANCE HAS ABANDONED THAT REGIMEN.",
    "In 2017 WHO stated that the Category II regimen should no longer be prescribed.",
    "The reason: adding one drug to a regimen that has already failed amplifies resistance.",
    "Today's replacement: rapid drug-susceptibility testing, then a regimen based on the result.",
    "If no resistance is found, the standard six-month regimen is simply repeated.",
    "If rifampicin resistance is found, an MDR regimen is begun.",
    "WARNING: SO IN THE EXAMINATION GIVE THE BOOK'S KEY; AT THE BEDSIDE SEND AN XPERT.",
    "And in either case, culture and susceptibility testing are mandatory.",
]

add("book:226", "recall", "medium",
    "**بیمار با سابقه‌ی درمان قبلی سل: رژیم هشت‌ماهه‌ی درمان مجدد (کلید کتاب).**",
    "A patient with previous tuberculosis treatment: the eight-month retreatment regimen (the book's key).",
    RETREAT_FA, RETREAT_EN,
    "این سؤال یکی از مواردی است که در آن **کلید کتاب و راهنمای امروزی از هم فاصله "
    "گرفته‌اند**، و درسنامه هر دو را به شما می‌گوید.\n\n"
    "**بیمار: مرد ۳۵ ساله با سل ریوی خلط مثبت. ۵ سال پیش به‌علت لنفادنیت سلی ۶ ماه "
    "درمان گرفته است. رژیم این نوبت چند ماهه باید باشد؟**\n\n"
    "**کلید کتاب: هشت ماه.**\n\n"
    "**منطق کتاب (که منطق راهنمای قدیمی سازمان جهانی است):**\n\n"
    "**این بیمار «درمان‌گرفته‌ی قبلی» محسوب می‌شود**، چون یک دوره‌ی کامل درمان ضدسل را "
    "پیش‌تر گرفته است. در چنین بیماری، **احتمال مقاومت دارویی به‌مراتب بیشتر از بیمار "
    "جدید است** — چون هر دوره‌ی درمان، فرصتی برای انتخاب سویه‌های مقاوم بوده.\n\n"
    "**رژیم دسته‌ی دوم (Category II) که کتاب آموزش می‌دهد:**\n\n"
    "**۲ ماه HRZES** (پنج دارو، با استرپتومایسین) **+ ۱ ماه HRZE** (چهار دارو) **+ "
    "۵ ماه HRE** (سه دارو) **= جمعاً ۸ ماه.**\n\n"
    "**منطقش: فاز حمله‌ای طولانی‌تر (۳ ماه به‌جای ۲)، داروی پنجم در ابتدا، و فاز "
    "نگهدارنده‌ی سه‌دارویی به‌جای دودارویی — همه برای پوشاندن احتمال مقاومت.**\n\n"
    "⚠️ **حالا آنچه امروز تغییر کرده، و باید بدانید:**\n\n"
    "**در سال ۲۰۱۷، گروه تدوین راهنمای سازمان جهانی بهداشت یک بیانیه‌ی «شیوه‌ی خوب "
    "عملکرد» صادر کرد: رژیم دسته‌ی دوم دیگر نباید تجویز شود، و به‌جای آن باید آزمون "
    "حساسیت دارویی انجام شود تا رژیم را تعیین کند.**\n\n"
    "**استدلال ساده و قانع‌کننده است:** اگر بیمار به‌خاطر مقاومت شکست خورده باشد، "
    "**افزودن یک داروی تنها (استرپتومایسین) به رژیمی که کار نکرده، عملاً یعنی "
    "تک‌درمانی با آن دارو** — و نتیجه، تکثیر مقاومت است، نه درمان.\n\n"
    "**راه امروزی:**\n\n"
    "**Xpert MTB/RIF بفرستید** (جواب در دو ساعت). اگر **مقاومت به ریفامپین نبود**، "
    "**همان رژیم استاندارد شش‌ماهه (2HRZE/4HR) تکرار می‌شود**. اگر **مقاومت به "
    "ریفامپین بود**، رژیم MDR شروع می‌شود.\n\n"
    "**پس چرا کلید تصحیح نمی‌شود؟** چون **این یک خطای واقعی کتاب نیست، بلکه یک "
    "جابه‌جایی راهنماست**. در چارچوب راهنمایی که کتاب بر آن نوشته شده، «۸ ماه» درست "
    "است. **در امتحان همان را بدهید؛ در بالین Xpert بفرستید.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**۶ ماه** — رژیم بیمار **جدید** است، نه درمان‌گرفته‌ی قبلی (در چارچوب کتاب).\n\n"
    "**۱۰ ماه** — چنین طول درمانی در هیچ رژیم استانداردی وجود ندارد.\n\n"
    "**۱۲ ماه** — طول درمان سل **سیستم عصبی مرکزی** یا **استخوان و مفصل** است، نه "
    "درمان مجدد سل ریوی.",
    "This is one of the questions where THE BOOK'S KEY AND CURRENT GUIDANCE HAVE PARTED COMPANY, and this lesson gives you both.\n\n"
    "THE PATIENT: a 35-year-old man with smear-positive pulmonary tuberculosis. Five years ago he received six months of treatment for tuberculous lymphadenitis. How many months should this course be?\n\n"
    "THE BOOK'S KEY: EIGHT MONTHS.\n\n"
    "THE BOOK'S LOGIC (which is the logic of the older WHO guideline):\n\n"
    "THIS PATIENT COUNTS AS 'PREVIOUSLY TREATED', because he has already had a full antituberculous course. In such a patient THE PROBABILITY OF DRUG RESISTANCE IS FAR HIGHER THAN IN A NEW PATIENT — because every course of treatment has been an opportunity to select resistant strains.\n\n"
    "THE CATEGORY II REGIMEN THE BOOK TEACHES:\n\n"
    "2 MONTHS HRZES (five drugs, with streptomycin) + 1 MONTH HRZE (four drugs) + 5 MONTHS HRE (three drugs) = EIGHT MONTHS IN TOTAL.\n\n"
    "Its logic: a longer intensive phase (3 months rather than 2), a fifth drug at the start, and a three-drug rather than two-drug continuation phase — all to cover the possibility of resistance.\n\n"
    "WARNING, NOW WHAT HAS CHANGED, AND WHAT YOU MUST KNOW:\n\n"
    "IN 2017 THE WHO GUIDELINE DEVELOPMENT GROUP ISSUED A GOOD PRACTICE STATEMENT: THE CATEGORY II REGIMEN SHOULD NO LONGER BE PRESCRIBED, AND DRUG-SUSCEPTIBILITY TESTING SHOULD INSTEAD DETERMINE THE REGIMEN.\n\n"
    "The argument is simple and compelling: if the patient failed because of resistance, then ADDING A SINGLE DRUG (STREPTOMYCIN) TO A REGIMEN THAT DID NOT WORK IS EFFECTIVELY MONOTHERAPY WITH THAT DRUG — and the result is amplified resistance, not cure.\n\n"
    "TODAY'S PATHWAY:\n\n"
    "SEND AN XPERT MTB/RIF (result in two hours). If there is NO RIFAMPICIN RESISTANCE, THE STANDARD SIX-MONTH REGIMEN (2HRZE/4HR) IS SIMPLY REPEATED. If rifampicin resistance IS present, an MDR regimen is started.\n\n"
    "SO WHY IS THE KEY NOT CORRECTED? Because THIS IS NOT A FACTUAL ERROR IN THE BOOK BUT A GUIDELINE SHIFT. Within the framework the book was written on, 'eight months' is right. GIVE THAT IN THE EXAMINATION; SEND AN XPERT AT THE BEDSIDE.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "SIX MONTHS — the regimen for a NEW patient, not a previously treated one (within the book's framework).\n\n"
    "TEN MONTHS — no standard regimen has this duration.\n\n"
    "TWELVE MONTHS — that is the duration for CNS or BONE AND JOINT tuberculosis, not for pulmonary retreatment.",
    ["رژیم بیمار جدید است؛ این بیمار سابقه‌ی درمان کامل قبلی دارد.",
     "پاسخ صحیح (کلید کتاب) — رژیم درمان مجدد: دو ماه HRZES، یک ماه HRZE، پنج ماه HRE.",
     "چنین طول درمانی در هیچ رژیم استاندارد ضدسل وجود ندارد.",
     "طول درمان سل سیستم عصبی مرکزی یا استخوان و مفصل است، نه درمان مجدد ریوی."],
    ["The regimen for a new patient; this man has had a full previous course.",
     "Correct (the book's key) — the retreatment regimen: 2 months HRZES, 1 month HRZE, 5 months HRE.",
     "No standard antituberculous regimen has this duration.",
     "The duration for CNS or bone and joint tuberculosis, not for pulmonary retreatment."],
    "**در امتحان کلید کتاب را بدهید؛ در بالین Xpert بفرستید و رژیم را با آنتی‌بیوگرام بسازید.**",
    "Give the book's key in the examination; at the bedside send an Xpert and build the regimen on susceptibility.",
    REFSN)

add("book:228", "recall", "medium",
    "**عود پس از درمان کامل: فاز حمله‌ای سه‌ماهه با چهار داروی خط اول (کلید کتاب).**",
    "Relapse after a completed course: a three-month intensive phase with the four first-line drugs (the book's key).",
    RETREAT_FA, RETREAT_EN,
    "این سؤال همان مفهوم درمان مجدد را می‌سنجد، ولی این‌بار فقط **فاز حمله‌ای** را "
    "می‌پرسد.\n\n"
    "**بیمار: سل ریه با اسمیر خلط ۳+ و کاویته. ۸ سال پیش یک دوره درمان سل را کامل "
    "دریافت کرده است. شروع درمان مرحله‌ی حمله‌ای چگونه است؟**\n\n"
    "**کلید کتاب: سه ماه با چهار داروی خط اول — ایزونیازید، ریفامپین، اتامبوتول، "
    "پیرازینامید.**\n\n"
    "**نکته‌ی اول: این بیمار «عود» است، نه بیمار جدید.** درمان قبلی را **کامل** کرده "
    "و حالا دوباره بیمار شده. در طبقه‌بندی برنامه‌ی کشوری، این **relapse** است و در "
    "گروه «درمان‌گرفته‌ی قبلی» قرار می‌گیرد.\n\n"
    "**نکته‌ی دوم: چرا فاز حمله‌ای سه ماه است و نه دو ماه؟**\n\n"
    "**چون بار باسیلی بالاست و احتمال مقاومت بیشتر.** اسمیر ۳+ یعنی **بار باسیلی "
    "بسیار سنگین**، و کاویته یعنی **محیطی با ۱۰ به توان ۸ تا ۹ باسیل** — دقیقاً "
    "جایی که جهش‌یافته‌های مقاوم فراوان‌اند. **فاز حمله‌ای طولانی‌تر، زمان بیشتری برای "
    "کاهش این بار می‌دهد پیش از آنکه به رژیم کم‌دارو‌تر برویم.**\n\n"
    "⚠️ **و اینجا باید راهنمای امروزی را هم بدانید:** همان‌طور که گفته شد، از **۲۰۱۷** "
    "سازمان جهانی بهداشت **رژیم دسته‌ی دوم را کنار گذاشته** و به‌جایش **آزمون حساسیت "
    "دارویی** را در صدر قرار داده. در بیمار عودکرده با اسمیر ۳+، **Xpert فوری** "
    "می‌فرستید و اگر ریفامپین حساس بود، **همان رژیم استاندارد شش‌ماهه** را تکرار "
    "می‌کنید.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "⚠️ **«تا حاضر شدن جواب کشت درمان نمی‌کنیم»** — **خطرناک‌ترین گزینه.** بیمار اسمیر "
    "۳+ دارد، یعنی **بسیار مسری است**. کشت ۲ تا ۶ هفته طول می‌کشد. **در این مدت او "
    "ده‌ها نفر را آلوده می‌کند و بیماری خودش پیشرفت می‌کند.** قاعده: **در سل اسمیر "
    "مثبت، درمان بلافاصله شروع می‌شود و کشت به‌موازات آن می‌رود.**\n\n"
    "**«درمان مثل موارد بار اول»** — نادیده گرفتن سابقه‌ی درمان قبلی، و در چارچوب "
    "کتاب نادرست است. (هرچند جالب است بدانید **راهنمای ۲۰۱۷ به بعد دقیقاً همین را "
    "می‌گوید، به شرطی که آنتی‌بیوگرام حساسیت را ثابت کند** — یعنی این گزینه‌ی "
    "«غلط» امروز با یک شرط، درست شده است.)\n\n"
    "**«افزودن استرپتومایسین به چهار دارو»** — این پنج‌دارویی، فاز حمله‌ای رژیم "
    "دسته‌ی دوم را توصیف می‌کند، ولی سؤال **مدت** و **ترکیب فاز حمله‌ای** را با هم "
    "می‌خواهد و گزینه‌ی صحیح، سه ماه چهاردارویی را مشخص کرده است.",
    "This question tests the same retreatment concept but asks only about THE INTENSIVE PHASE.\n\n"
    "THE PATIENT: pulmonary tuberculosis with a 3+ sputum smear and a cavity. Eight years ago he completed a full course of treatment. How should the intensive phase begin?\n\n"
    "THE BOOK'S KEY: THREE MONTHS WITH THE FOUR FIRST-LINE DRUGS — isoniazid, rifampicin, ethambutol, pyrazinamide.\n\n"
    "POINT ONE: THIS PATIENT IS A RELAPSE, NOT A NEW CASE. He COMPLETED his previous treatment and has fallen ill again. In the national classification this is a RELAPSE and belongs to the 'previously treated' group.\n\n"
    "POINT TWO: WHY IS THE INTENSIVE PHASE THREE MONTHS RATHER THAN TWO?\n\n"
    "BECAUSE THE BACILLARY LOAD IS HIGH AND RESISTANCE MORE LIKELY. A 3+ smear means A VERY HEAVY LOAD, and a cavity means AN ENVIRONMENT HOLDING TEN TO THE EIGHTH OR NINTH BACILLI — precisely where resistant mutants abound. A LONGER INTENSIVE PHASE GIVES MORE TIME TO REDUCE THAT LOAD BEFORE MOVING TO A REGIMEN WITH FEWER DRUGS.\n\n"
    "WARNING, AND HERE TOO YOU MUST KNOW CURRENT GUIDANCE: as noted, since 2017 WHO HAS ABANDONED THE CATEGORY II REGIMEN and placed DRUG-SUSCEPTIBILITY TESTING first. In a relapsed patient with a 3+ smear you send an IMMEDIATE XPERT and, if rifampicin is susceptible, simply REPEAT THE STANDARD SIX-MONTH REGIMEN.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "WARNING: 'WE DO NOT TREAT UNTIL THE CULTURE RESULT ARRIVES' — THE MOST DANGEROUS OPTION. The patient has a 3+ smear, meaning HE IS HIGHLY INFECTIOUS. Culture takes 2 to 6 weeks. IN THAT TIME HE WILL INFECT DOZENS OF PEOPLE AND HIS OWN DISEASE WILL ADVANCE. THE RULE: IN SMEAR-POSITIVE TUBERCULOSIS, TREATMENT STARTS IMMEDIATELY AND CULTURE RUNS ALONGSIDE.\n\n"
    "'TREAT AS IF FIRST DIAGNOSED' — this ignores the previous course and is wrong within the book's framework. (Though it is interesting that GUIDANCE SINCE 2017 SAYS PRECISELY THIS, PROVIDED SUSCEPTIBILITY IS PROVEN — so this 'wrong' option has, with one condition, become right.)\n\n"
    "'ADDING STREPTOMYCIN TO THE FOUR DRUGS' — this five-drug combination describes the intensive phase of the Category II regimen, but the question asks for both the DURATION and the COMBINATION together, and the correct option specifies three months of four drugs.",
    ["خطرناک‌ترین گزینه؛ بیمار اسمیر ۳+ بسیار مسری است و کشت هفته‌ها طول می‌کشد.",
     "پاسخ صحیح (کلید کتاب) — فاز حمله‌ای سه‌ماهه با چهار داروی خط اول در بیمار عودکرده.",
     "سابقه‌ی درمان قبلی را نادیده می‌گیرد؛ در چارچوب کتاب نادرست است.",
     "ترکیب پنج‌دارویی فاز حمله‌ای دسته‌ی دوم است ولی مدت و ترکیب خواسته‌شده را نمی‌دهد."],
    ["The most dangerous option; a 3+ smear patient is highly infectious and culture takes weeks.",
     "Correct (the book's key) — a three-month intensive phase with the four first-line drugs in a relapsed patient.",
     "Ignores the previous course; wrong within the book's framework.",
     "The five-drug Category II intensive phase, but not the duration and combination the question asks for."],
    "**در سل اسمیر مثبت، درمان فوراً شروع می‌شود و کشت به‌موازات آن می‌رود.**",
    "In smear-positive tuberculosis, treatment starts at once and culture runs alongside it.",
    REFSN)

add("book:232", "vignette", "medium",
    "**بیماری که دو هفته پس از شروع، دارو را قطع کرده: درمان استاندارد را از نو شروع کنید.**",
    "A patient who stopped treatment two weeks in: restart the standard four-drug regimen.",
    RETREAT_FA + [
        "⚠️ **قطع درمان در دو هفته‌ی اول با قطع درمان در ماه چهارم یکی نیست.**",
        "**در دو هفته، فشار انتخابی کافی برای ساختن مقاومت ایجاد نشده است.**",
    ],
    RETREAT_EN + [
        "WARNING: STOPPING IN THE FIRST TWO WEEKS IS NOT THE SAME AS STOPPING IN THE FOURTH MONTH.",
        "In two weeks there has not been enough selective pressure to breed resistance.",
    ],
    "این سؤال یک تمایز ظریف و بسیار کاربردی را می‌سنجد: **مدت مواجهه‌ی قبلی با دارو "
    "چقدر بوده؟**\n\n"
    "**بیمار: خانم ۲۵ ساله‌ی افغان که ۶ ماه پیش با احتمال پلورزی سلی تحت درمان "
    "تجربی چهاردارویی قرار گرفته و حدود ۲ هفته پس از آن داروها را قطع کرده است. "
    "حالا با تب و سرفه‌ی پروداکتیو برگشته، با کاویته در قله‌ی ریه‌ی راست و افیوژن "
    "پلور همان سمت.**\n\n"
    "**پاسخ: شروع مجدد درمان استاندارد چهاردارویی.**\n\n"
    "⚠️ **کلید ماجرا در همان «۲ هفته» است.**\n\n"
    "**مقاومت دارویی چگونه ساخته می‌شود؟** با **فشار انتخابی طولانی و ناکافی**: وقتی "
    "بیمار ماه‌ها دارو را نامنظم می‌خورد، جمعیت حساس کشته می‌شود ولی جمعیت مقاوم "
    "زنده می‌ماند و تکثیر می‌شود.\n\n"
    "**دو هفته برای این فرآیند بسیار کوتاه است.** در دو هفته، رژیم چهاردارویی هنوز "
    "در فاز کشتار سریع است و **جمعیت مقاوم فرصت غالب شدن پیدا نکرده**. پس این بیمار "
    "را می‌توان عملاً **مثل یک بیمار جدید** درمان کرد.\n\n"
    "**نکته‌ی دوم: درمان قبلی «تجربی» بود، نه اثبات‌شده.** یعنی حتی معلوم نیست همان "
    "موقع سل داشته یا نه. **حالا تشخیص روشن‌تر است:** کاویته‌ی قله + افیوژن + تب + "
    "سرفه‌ی پروداکتیو.\n\n"
    "**پس مسیر درست: شروع رژیم استاندارد ۲HRZE/4HR، و هم‌زمان فرستادن اسمیر، کشت و "
    "Xpert.** (Xpert اینجا مهم است: افغانستان و ایران هر دو شیوع قابل توجه MDR "
    "دارند، و اطمینان از حساسیت به ریفامپین ارزش دو ساعت انتظار را دارد.)\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**درمان دسته‌ی دوم به‌عنوان «درمان بعد از غیبت»** — تعریف «غیبت» (default) در "
    "برنامه‌ی کشوری، **قطع درمان به‌مدت دو ماه یا بیشتر پس از دریافت حداقل یک ماه "
    "درمان** است. **این بیمار فقط دو هفته دارو خورده**، پس اصلاً وارد این طبقه‌بندی "
    "نمی‌شود. **و همان‌طور که گفته شد، رژیم دسته‌ی دوم امروز کنار گذاشته شده است.**\n\n"
    "**درمان دسته‌ی اول فقط در صورت تکرار اسمیر مثبت** — **تأخیر غیرقابل توجیه.** "
    "بیمار **کاویته** دارد، یعنی تابلوی بالینی و رادیولوژیک کاملاً گویاست. **منتظر "
    "ماندن برای اسمیر مثبت، در حالی که ۴۰ تا ۵۰٪ بیماران سل اسمیر منفی‌اند، یعنی "
    "احتمال از دست دادن بیمار.**\n\n"
    "**تصمیم‌گیری پس از تکرار اسمیر و بیوپسی پلور** — **بیوپسی پلور در این بیمار "
    "غیرضروری و تهاجمی است.** وقتی **کاویته‌ی ریوی** وجود دارد، تشخیص از راه خلط "
    "بسیار ساده‌تر و کم‌خطرتر به‌دست می‌آید. **بیوپسی پلور برای وقتی است که تنها "
    "یافته، افیوژن باشد.**",
    "This question tests a subtle and very practical distinction: HOW LONG WAS THE PREVIOUS DRUG EXPOSURE?\n\n"
    "THE PATIENT: a 25-year-old Afghan woman who six months ago was started on empirical four-drug therapy for presumed tuberculous pleurisy and STOPPED THE DRUGS ABOUT TWO WEEKS LATER. She now returns with fever and productive cough, a cavity at the right apex and an ipsilateral pleural effusion.\n\n"
    "THE ANSWER: RESTART THE STANDARD FOUR-DRUG REGIMEN.\n\n"
    "WARNING: THE WHOLE POINT LIES IN THOSE 'TWO WEEKS'.\n\n"
    "HOW IS DRUG RESISTANCE BRED? By PROLONGED, INADEQUATE SELECTIVE PRESSURE: when a patient takes drugs irregularly for months, the susceptible population is killed while the resistant population survives and multiplies.\n\n"
    "TWO WEEKS IS FAR TOO SHORT FOR THAT PROCESS. At two weeks the four-drug regimen is still in its rapid-killing phase and THE RESISTANT POPULATION HAS HAD NO CHANCE TO BECOME DOMINANT. So this patient can effectively be treated AS A NEW CASE.\n\n"
    "POINT TWO: THE PREVIOUS TREATMENT WAS EMPIRICAL, NOT PROVEN. It is not even certain she had tuberculosis then. NOW THE DIAGNOSIS IS CLEARER: an apical cavity plus effusion plus fever plus productive cough.\n\n"
    "SO THE RIGHT PATH: START THE STANDARD 2HRZE/4HR REGIMEN and send smear, culture and Xpert at the same time. (Xpert matters here: both Afghanistan and Iran have appreciable MDR prevalence, and confirming rifampicin susceptibility is worth two hours.)\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "CATEGORY II AS 'TREATMENT AFTER DEFAULT' — the programme's definition of DEFAULT is INTERRUPTION FOR TWO MONTHS OR MORE AFTER AT LEAST ONE MONTH OF TREATMENT. THIS PATIENT TOOK DRUGS FOR ONLY TWO WEEKS, so she does not enter that category at all. AND, AS NOTED, THE CATEGORY II REGIMEN HAS BEEN ABANDONED.\n\n"
    "CATEGORY I ONLY IF THE SMEAR IS AGAIN POSITIVE — AN UNJUSTIFIABLE DELAY. The patient HAS A CAVITY, so the clinical and radiological picture is fully eloquent. WAITING FOR A POSITIVE SMEAR, WHEN 40 TO 50 % OF TUBERCULOSIS PATIENTS ARE SMEAR-NEGATIVE, RISKS LOSING THE PATIENT ALTOGETHER.\n\n"
    "DECIDING AFTER REPEAT SMEAR AND PLEURAL BIOPSY — PLEURAL BIOPSY IS UNNECESSARY AND INVASIVE HERE. When a PULMONARY CAVITY is present, the diagnosis comes far more easily and safely from sputum. PLEURAL BIOPSY IS FOR WHEN THE EFFUSION IS THE ONLY FINDING.",
    ["پاسخ صحیح — دو هفته مصرف، فشار انتخابی کافی برای مقاومت نساخته؛ رژیم استاندارد از نو.",
     "تعریف غیبت، قطع دوماهه پس از حداقل یک ماه درمان است؛ این بیمار وارد آن طبقه نمی‌شود.",
     "تأخیر غیرقابل توجیه؛ کاویته وجود دارد و ۴۰ تا ۵۰٪ بیماران سل اسمیر منفی‌اند.",
     "بیوپسی پلور تهاجمی و غیرضروری است وقتی کاویته‌ی ریوی و راه خلط در دسترس است."],
    ["Correct — two weeks of drugs created no selective pressure for resistance; restart the standard regimen.",
     "Default means a two-month interruption after at least one month of treatment; she does not qualify.",
     "An unjustifiable delay; a cavity is present and 40 to 50 % of tuberculosis patients are smear-negative.",
     "Pleural biopsy is invasive and unnecessary when a pulmonary cavity and the sputum route are available."],
    "**دو هفته دارو مقاومت نمی‌سازد؛ مقاومت محصول ماه‌ها مصرف نامنظم است.**",
    "Two weeks of drugs does not breed resistance; resistance is the product of months of irregular therapy.",
    REFSN)

add("book:233", "vignette", "medium",
    "**قطع خودسرانه در ماه دوم و عود پس از سه ماه: رژیم درمان مجدد و ادامه بر پایه‌ی آنتی‌بیوگرام.**",
    "Self-discontinuation at two months with relapse three months later: the retreatment regimen, continued on the basis of susceptibility.",
    RETREAT_FA + [
        "⚠️ **دو ماه مصرف و سپس سه ماه قطع، یعنی «غیبت» واقعی.**",
        "**و در غیبت، احتمال مقاومت جدی است — پس آنتی‌بیوگرام تعیین‌کننده می‌شود.**",
    ],
    RETREAT_EN + [
        "WARNING: TWO MONTHS OF TREATMENT FOLLOWED BY THREE MONTHS OFF IS A GENUINE DEFAULT.",
        "And in default the risk of resistance is real — so susceptibility testing becomes decisive.",
    ],
    "این سؤال دقیقاً **نقطه‌ی مقابل** سؤال قبلی است، و مقایسه‌ی این دو، بهترین راه "
    "یادگیری این مبحث است.\n\n"
    "**بیمار: آقای ۵۲ ساله با تشخیص سل ریوی، ۲ ماه پس از شروع داروها به‌دلیل بهبود "
    "علائم، درمان را خودسرانه قطع کرده است. ۳ ماه بعد با تعریق شدید و سرفه‌ی "
    "پروداکتیو برگشته و اسمیر خلط مثبت است.**\n\n"
    "**پاسخ (کلید کتاب): شروع رژیم دسته‌ی دوم و ادامه‌ی درمان براساس نتایج "
    "آنتی‌بیوگرام.**\n\n"
    "⚠️ **حالا مقایسه کنید با بیمار قبلی:**\n\n"
    "**بیمار قبلی: ۲ هفته دارو خورد.** فشار انتخابی ناچیز → **مثل بیمار جدید درمان "
    "می‌شود**.\n\n"
    "**این بیمار: ۲ ماه دارو خورد، سپس ۳ ماه قطع کرد.** این **غیبت (default)** واقعی "
    "است طبق تعریف برنامه (قطع دو ماه یا بیشتر، پس از حداقل یک ماه درمان).\n\n"
    "**چرا دو ماه فرق می‌کند؟** چون در دو ماه، **جمعیت حساس تقریباً کاملاً کشته شده** "
    "و آنچه باقی مانده، **غنی‌شده از جهش‌یافته‌های مقاوم** است. سپس سه ماه بدون دارو، "
    "**همان جمعیت مقاوم آزادانه تکثیر شده**. **این دقیقاً دستور پخت مقاومت اکتسابی "
    "است.**\n\n"
    "**نکته‌ی دوم — «بهبود علائم» به‌عنوان علت قطع، خطرناک‌ترین الگوی رفتاری در سل "
    "است.** بیمار در ماه دوم واقعاً بهتر می‌شود، چون ایزونیازید جمعیت فعال را کشته. "
    "**ولی جمعیت نیمه‌خفته هنوز زنده است — و ریشه‌کنی همان‌ها کار چهار ماه بعدی "
    "ریفامپین است.** آموزش این نکته به بیمار، به‌اندازه‌ی خودِ نسخه اهمیت دارد. **و "
    "همین است که DOTS (درمان تحت نظارت مستقیم) را ضروری کرده.**\n\n"
    "**نکته‌ی سوم و مهم‌ترین: «ادامه‌ی درمان براساس آنتی‌بیوگرام».** این عبارت، بخش "
    "دائمی و درست پاسخ است — و **دقیقاً همان چیزی است که راهنمای ۲۰۱۷ به بعد آن را "
    "به مرکز صحنه آورد.** حتی اگر رژیم دسته‌ی دوم دیگر توصیه نشود، **اصل «رژیم را با "
    "آنتی‌بیوگرام بساز» امروز قوی‌تر از همیشه است.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**شروع مجدد رژیم استاندارد بدون احتساب طول درمان قبلی** — نادیده گرفتن غیبت "
    "دوماهه و احتمال مقاومت.\n\n"
    "**فقط کشت و انتظار برای آنتی‌بیوگرام** — ⚠️ **بیمار اسمیر مثبت است، یعنی مسری.** "
    "**تعویق درمان تا آماده شدن آنتی‌بیوگرام (۲ تا ۶ هفته) پذیرفتنی نیست.** درمان "
    "شروع می‌شود و **بر پایه‌ی نتیجه اصلاح** می‌شود.\n\n"
    "**شروع درمان با ایزونیازید به‌همراه چهار داروی جدید خط دوم** — پرش بی‌دلیل به خط "
    "دوم. **داروهای خط دوم سمّی‌تر، گران‌تر و طولانی‌ترند**، و تا وقتی مقاومت اثبات "
    "نشده، شروع آن‌ها هم به بیمار آسیب می‌زند و هم منابع محدود را هدر می‌دهد.",
    "This question is the EXACT MIRROR of the previous one, and comparing the two is the best way to learn this topic.\n\n"
    "THE PATIENT: a 52-year-old man diagnosed with pulmonary tuberculosis who, two months after starting, STOPPED THE DRUGS HIMSELF because his symptoms improved. Three months later he returns with drenching sweats and productive cough, and the sputum smear is positive.\n\n"
    "THE ANSWER (the book's key): START THE CATEGORY II REGIMEN AND CONTINUE ON THE BASIS OF SUSCEPTIBILITY RESULTS.\n\n"
    "WARNING, NOW COMPARE WITH THE PREVIOUS PATIENT:\n\n"
    "THE PREVIOUS PATIENT TOOK DRUGS FOR TWO WEEKS. Negligible selective pressure, so SHE IS TREATED AS A NEW CASE.\n\n"
    "THIS PATIENT TOOK DRUGS FOR TWO MONTHS, THEN STOPPED FOR THREE. That is a genuine DEFAULT by the programme's definition (interruption of two months or more after at least one month of treatment).\n\n"
    "WHY DOES TWO MONTHS DIFFER? Because in two months THE SUSCEPTIBLE POPULATION HAS BEEN ALMOST ENTIRELY KILLED and what remains is ENRICHED FOR RESISTANT MUTANTS. Then three months without drugs let THAT RESISTANT POPULATION MULTIPLY FREELY. THAT IS PRECISELY THE RECIPE FOR ACQUIRED RESISTANCE.\n\n"
    "POINT TWO — 'SYMPTOMS IMPROVED' AS A REASON FOR STOPPING IS THE MOST DANGEROUS BEHAVIOURAL PATTERN IN TUBERCULOSIS. The patient genuinely does feel better by the second month, because isoniazid has killed the active population. BUT THE SEMI-DORMANT POPULATION IS STILL ALIVE — AND ERADICATING IT IS THE WORK OF THE NEXT FOUR MONTHS OF RIFAMPICIN. Teaching the patient this matters as much as the prescription itself. AND IT IS WHY DIRECTLY OBSERVED THERAPY (DOTS) EXISTS.\n\n"
    "POINT THREE, AND THE MOST IMPORTANT: 'CONTINUE ON THE BASIS OF SUSCEPTIBILITY'. That clause is the permanent and correct part of the answer — AND PRECISELY WHAT GUIDANCE SINCE 2017 MOVED TO CENTRE STAGE. Even if the Category II regimen is no longer recommended, THE PRINCIPLE OF BUILDING THE REGIMEN ON SUSCEPTIBILITY IS STRONGER TODAY THAN EVER.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "RESTARTING THE STANDARD REGIMEN WITHOUT COUNTING PREVIOUS TREATMENT — this ignores a two-month default and the resistance risk.\n\n"
    "CULTURE ONLY, AND WAIT FOR SUSCEPTIBILITY — WARNING: THE PATIENT IS SMEAR-POSITIVE AND THEREFORE INFECTIOUS. DELAYING TREATMENT FOR 2 TO 6 WEEKS IS UNACCEPTABLE. Treatment starts and is then ADJUSTED on the result.\n\n"
    "ISONIAZID PLUS FOUR NEW SECOND-LINE DRUGS — an unwarranted leap to second line. SECOND-LINE DRUGS ARE MORE TOXIC, MORE EXPENSIVE AND LONGER, and until resistance is proven, starting them harms the patient and wastes scarce resources.",
    ["غیبت دوماهه و احتمال جدی مقاومت را نادیده می‌گیرد.",
     "پاسخ صحیح (کلید کتاب) — رژیم درمان مجدد، با اصلاح بر پایه‌ی آنتی‌بیوگرام.",
     "بیمار اسمیر مثبت و مسری است؛ تعویق درمان تا آماده شدن آنتی‌بیوگرام پذیرفتنی نیست.",
     "پرش بی‌دلیل به خط دوم؛ داروهای خط دوم سمّی‌تر و طولانی‌ترند و مقاومت اثبات نشده."],
    ["Ignores a two-month default and a real risk of resistance.",
     "Correct (the book's key) — the retreatment regimen, adjusted on the susceptibility result.",
     "The patient is smear-positive and infectious; delaying treatment for the susceptibility result is unacceptable.",
     "An unwarranted leap to second line; those drugs are more toxic and longer, and no resistance is proven."],
    "**دو ماه مصرف و سپس قطع، مقاومت می‌سازد؛ درمان را شروع کن و با آنتی‌بیوگرام اصلاح کن.**",
    "Two months on and then off breeds resistance; start treatment and correct it with the susceptibility result.",
    REFSN)

# ==================================================== EXTRAPULMONARY REGIMEN
EXTRA_FA = [
    "⚠️ **قاعده‌ی طلایی: سل خارج‌ریوی همان رژیم شش‌ماهه‌ی استاندارد را می‌گیرد.**",
    "**یعنی دو ماه HRZE و سپس چهار ماه HR — دقیقاً مثل سل ریوی.**",
    "**و این شامل غده‌ی لنفاوی، پلور، کلیه، پریکارد و سل منتشر می‌شود.**",
    "⚠️ **دو استثنای واقعی وجود دارد و فقط دو تا.**",
    "**سل سیستم عصبی مرکزی: ۹ تا ۱۲ ماه، به‌همراه کورتیکواستروئید.**",
    "**سل استخوان و مفصل: ۹ تا ۱۲ ماه.**",
    "**دلیل هر دو یکی است: نفوذ دارو به آن بافت‌ها محدودتر است.**",
    "**و عواقب شکست درمان در مغز و ستون فقرات، فاجعه‌بار است.**",
    "**پس در آدنیت سلی، رژیم چهاردارویی استاندارد شش‌ماهه بدهید.**",
    "**نه دو دارو، و نه کوتاه‌تر از شش ماه.**",
    "⚠️ **و بزرگ شدن پارادوکسیکال غده حین درمان، شکست نیست.**",
    "**پاسخ ایمنی به آنتی‌ژن‌های آزادشده است و رژیم را تغییر نمی‌دهد.**",
]
EXTRA_EN = [
    "WARNING: THE GOLDEN RULE — EXTRAPULMONARY TUBERCULOSIS TAKES THE SAME STANDARD SIX-MONTH REGIMEN.",
    "That is two months of HRZE then four months of HR, exactly as for pulmonary disease.",
    "And that covers lymph node, pleura, kidney, pericardium and disseminated disease.",
    "WARNING: THERE ARE TWO GENUINE EXCEPTIONS, AND ONLY TWO.",
    "CNS tuberculosis: 9 to 12 months, together with a corticosteroid.",
    "Bone and joint tuberculosis: 9 to 12 months.",
    "The reason for both is the same: drug penetration into those tissues is more limited.",
    "And the consequences of treatment failure in brain and spine are catastrophic.",
    "So in tuberculous adenitis give the standard four-drug six-month regimen.",
    "Not two drugs, and not shorter than six months.",
    "WARNING, AND PARADOXICAL ENLARGEMENT OF THE NODE DURING TREATMENT IS NOT FAILURE.",
    "It is an immune response to released antigen and it does not change the regimen.",
]

add("book:229", "vignette", "medium",
    "**آدنیت سلی: چهار دارو به‌مدت دو ماه، سپس دو دارو به‌مدت چهار ماه.**",
    "Tuberculous adenitis: four drugs for two months, then two drugs for four months.",
    EXTRA_FA, EXTRA_EN,
    "این سؤال آزمون می‌کند که آیا شما وسوسه می‌شوید سل خارج‌ریوی را «سبک‌تر» درمان "
    "کنید یا نه.\n\n"
    "**بیمار: زن جوان با تورم چند غده‌ی لنفاوی بدون درد در گردن راست. بدون تب، بدون "
    "کاهش وزن. معاینه و آزمایش‌ها نرمال. در FNA: گرانولوم کازئوز. بدون نقص ایمنی.**\n\n"
    "**تشخیص روشن است: لنفادنیت سلی (اسکروفولا)** — شایع‌ترین شکل سل خارج‌ریوی.\n\n"
    "⚠️ **تابلوی «آرام» این بیماری، فریبنده است:** بیمار تب ندارد، کاهش وزن ندارد، و "
    "حالش خوب است. **این باعث می‌شود بسیاری فکر کنند درمان کمتری لازم است. کاملاً "
    "اشتباه.**\n\n"
    "**قاعده‌ی طلایی: سل خارج‌ریوی همان رژیم شش‌ماهه‌ی استاندارد سل ریوی را می‌گیرد.**\n\n"
    "**پس: ۲ ماه چهاردارویی (HRZE) + ۴ ماه دودارویی (HR) = ۶ ماه.**\n\n"
    "**چرا رژیم کوتاه‌تر یا سبک‌تر نه؟**\n\n"
    "**۱. بار باسیلی در غده‌ی درگیر کم نیست** — کشت بیوپسی در ۷۰ تا ۸۰٪ موارد مثبت "
    "می‌شود، که یعنی باسیل زنده فراوان است.\n\n"
    "**۲. اصل چهاردارویی، مستقل از محل بیماری است.** حتی در آدنیت، جمعیت باسیلی "
    "به‌قدری است که مقاومت جهشی از پیش موجود باشد. **حذف پیرازینامید یا اتامبوتول "
    "یعنی ریسک تک‌درمانی مؤثر.**\n\n"
    "**۳. عود در سل خارج‌ریوی درمان‌ناکافی، شایع است.**\n\n"
    "**دو استثنای واقعی که باید بدانید:** **سل CNS** (۹ تا ۱۲ ماه + کورتیکواستروئید) "
    "و **سل استخوان و مفصل** (۹ تا ۱۲ ماه). **غده‌ی لنفاوی جزو این دو نیست.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**ایزونیازید + ریفامپین به‌مدت ۶ ماه** — فقط **دو دارو**. **فاز حمله‌ای چهاردارویی "
    "را حذف کرده**، که یعنی اگر سویه به ایزونیازید مقاوم باشد، عملاً ریفامپین "
    "تک‌درمانی می‌شود. **این همان مسیری است که MDR-TB می‌سازد.**\n\n"
    "**ایزونیازید + ریفامپین به‌مدت ۴ ماه** — هم دارو کم، هم مدت کم. **دو خطا در یک "
    "گزینه.**\n\n"
    "**چهار دارو ۲ ماه سپس دو دارو ۷ ماه (جمعاً ۹ ماه)** — ⚠️ **گزینه‌ی فریبنده، چون "
    "«محتاطانه‌تر» به‌نظر می‌رسد.** ولی ۹ ماه، طول درمان **سل CNS و استخوان** است. "
    "**درمان بیش از حد هم اشتباه است:** سه ماه اضافه یعنی سه ماه بیشتر در معرض "
    "سمّیت کبدی، هزینه‌ی بیشتر، و احتمال بیشتر ترک درمان.\n\n"
    "⚠️ **نکته‌ی بالینی که همیشه باید کنار این سؤال بیاید: در ماه دوم یا سوم درمان، "
    "غده ممکن است بزرگ‌تر شود یا غده‌ی جدیدی ظاهر شود. این «واکنش پارادوکسیکال» "
    "است — پاسخ ایمنی به آنتی‌ژن‌های آزادشده از باسیل‌های کشته‌شده. شکست درمان نیست و "
    "رژیم را عوض نمی‌کند.**",
    "This question tests whether you are tempted to treat extrapulmonary tuberculosis 'more lightly'.\n\n"
    "THE PATIENT: a young woman with several painless swollen lymph nodes in the right neck. No fever, no weight loss. Examination and laboratory tests normal. FNA: CASEATING GRANULOMA. No immune defect.\n\n"
    "THE DIAGNOSIS IS CLEAR: TUBERCULOUS LYMPHADENITIS (SCROFULA) — the commonest form of extrapulmonary tuberculosis.\n\n"
    "WARNING: THE QUIET PICTURE OF THIS DISEASE IS DECEPTIVE. No fever, no weight loss, the patient feels well. THIS LEADS MANY TO THINK LESS TREATMENT IS NEEDED. THAT IS ENTIRELY WRONG.\n\n"
    "THE GOLDEN RULE: EXTRAPULMONARY TUBERCULOSIS RECEIVES THE SAME STANDARD SIX-MONTH REGIMEN AS PULMONARY DISEASE.\n\n"
    "SO: 2 MONTHS OF FOUR DRUGS (HRZE) + 4 MONTHS OF TWO DRUGS (HR) = 6 MONTHS.\n\n"
    "WHY NOT SHORTER OR LIGHTER?\n\n"
    "1. THE BACILLARY LOAD IN THE INVOLVED NODE IS NOT SMALL — biopsy culture is positive in 70 to 80 %, meaning abundant living organisms.\n\n"
    "2. THE FOUR-DRUG PRINCIPLE IS INDEPENDENT OF THE SITE. Even in adenitis the bacillary population is large enough for pre-existing resistant mutants. DROPPING PYRAZINAMIDE OR ETHAMBUTOL RISKS EFFECTIVE MONOTHERAPY.\n\n"
    "3. RELAPSE AFTER INADEQUATE TREATMENT OF EXTRAPULMONARY DISEASE IS COMMON.\n\n"
    "THE TWO GENUINE EXCEPTIONS YOU MUST KNOW: CNS TUBERCULOSIS (9 to 12 months plus a corticosteroid) and BONE AND JOINT TUBERCULOSIS (9 to 12 months). LYMPH NODE IS NOT ONE OF THEM.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ISONIAZID PLUS RIFAMPICIN FOR SIX MONTHS — only TWO drugs. IT REMOVES THE FOUR-DRUG INTENSIVE PHASE, so if the strain is isoniazid-resistant, rifampicin becomes effective monotherapy. THAT IS EXACTLY THE ROAD THAT MAKES MDR-TB.\n\n"
    "ISONIAZID PLUS RIFAMPICIN FOR FOUR MONTHS — too few drugs and too short. TWO ERRORS IN ONE OPTION.\n\n"
    "FOUR DRUGS FOR 2 MONTHS THEN TWO DRUGS FOR 7 MONTHS (9 months total) — WARNING, A SEDUCTIVE OPTION BECAUSE IT LOOKS 'MORE CAUTIOUS'. But nine months is the duration for CNS AND BONE disease. OVER-TREATMENT IS ALSO AN ERROR: three extra months means three more months of hepatotoxic exposure, more cost, and a higher chance of default.\n\n"
    "WARNING, A CLINICAL POINT THAT MUST ALWAYS ACCOMPANY THIS QUESTION: in the second or third month the node may enlarge or a new node may appear. THIS IS A PARADOXICAL REACTION — an immune response to antigen released from killed bacilli. It is not treatment failure and it does not change the regimen.",
    ["فقط دو دارو؛ فاز حمله‌ای چهاردارویی را حذف می‌کند و مسیر ساختن MDR است.",
     "هم دارو کم است و هم مدت کوتاه — دو خطا در یک گزینه.",
     "پاسخ صحیح — رژیم استاندارد شش‌ماهه، همان که برای سل ریوی به‌کار می‌رود.",
     "نه ماه طول درمان سل CNS و استخوان است؛ درمان بیش از حد هم خطا و پرعارضه است."],
    ["Only two drugs; it removes the four-drug intensive phase and is the road to MDR.",
     "Too few drugs and too short a course — two errors in one option.",
     "Correct — the standard six-month regimen, the same one used for pulmonary disease.",
     "Nine months is for CNS and bone disease; over-treatment is also an error and adds toxicity."],
    "**سل خارج‌ریوی همان شش ماه استاندارد را می‌گیرد؛ فقط مغز و استخوان طولانی‌ترند.**",
    "Extrapulmonary tuberculosis takes the same standard six months; only brain and bone run longer.",
    REFSW)

add("book:230", "vignette", "medium",
    "**توده‌ی گردنی با گرانولوم کازئیفیه: رژیم چهاردارویی استاندارد شش‌ماهه.**",
    "A neck mass with caseating granuloma: the standard four-drug six-month regimen.",
    EXTRA_FA, EXTRA_EN,
    "این سؤال همان مفهوم را از زاویه‌ی دیگری می‌پرسد، و گزینه‌های نادرستش، سه "
    "سوءبرداشت متفاوت را نمایندگی می‌کنند.\n\n"
    "**بیمار: خانم ۳۲ ساله اهل بجنورد با توده‌ی بدون درد در گردن. تب و کاهش وزن "
    "خفیف دارد. سایر معاینات و آزمایش‌ها نرمال. در نمونه‌برداری: گرانولوم کازئیفیه.**\n\n"
    "⚠️ **«گرانولوم کازئیفیه» تقریباً یک تشخیص است، نه یک یافته.** فهرست علل آن کوتاه "
    "است: **سل** در صدر، سپس مایکوباکتریوم‌های غیرتوبرکلوز، بروسلوز، قارچ‌های اندمیک "
    "و برخی موارد نادر. **در ایران و به‌ویژه در خراسان شمالی، سل به‌طور قاطع اول "
    "است.**\n\n"
    "**تفاوت با سؤال قبلی: این بیمار تب و کاهش وزن خفیف هم دارد** — یعنی علائم "
    "سیستمیک، که تشخیص را باز هم قوی‌تر می‌کند.\n\n"
    "**پاسخ: رژیم چهاردارویی استاندارد ضدسل به‌مدت ۶ ماه.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟ هر کدام یک سوءبرداشت متفاوت را نشان می‌دهند:**\n\n"
    "⚠️ **سوءبرداشت اول — «ایزونیازید به‌مدت ۹ ماه».** این **رژیم درمان عفونت نهفته** "
    "است، نه بیماری فعال. **تفاوتش حیاتی است:**\n\n"
    "**در سل نهفته**، تعداد باسیل‌ها بسیار کم است (شاید چند هزار)، پس **احتمال وجود "
    "جهش‌یافته‌ی مقاوم ناچیز است** و تک‌دارو کافی است.\n\n"
    "**در سل فعال**، جمعیت باسیلی میلیون‌ها یا میلیاردهاست، پس **جهش‌یافته‌ی مقاوم "
    "قطعاً وجود دارد** و تک‌دارو فقط آن را انتخاب می‌کند. **دادن ایزونیازید تنها به "
    "بیمار سل فعال، مطمئن‌ترین راه ساختن سل مقاوم به ایزونیازید است.**\n\n"
    "**سوءبرداشت دوم — «فالوآپ بالینی ۶ ماه بعد».** یعنی درمان نکردن. **گرانولوم "
    "کازئیفیه با تب و کاهش وزن، بیماری فعال است و درمان می‌خواهد، نه انتظار.** سل "
    "لنفاوی درمان‌نشده می‌تواند به پوست فیستول بزند (اسکروفولودرما) و منتشر شود.\n\n"
    "**سوءبرداشت سوم — «ایزونیازید + ریفامپین به‌مدت ۴ ماه».** دو دارو به‌جای چهار، و "
    "چهار ماه به‌جای شش. **این رژیم به رژیم درمان عفونت نهفته شبیه‌تر است تا درمان "
    "بیماری فعال.**\n\n"
    "**قاعده‌ی جمع‌بندی که هر سه را با هم رد می‌کند: بیماری فعال ⇐ چهار دارو، شش ماه. "
    "عفونت نهفته ⇐ یک یا دو دارو، سه تا نه ماه. این دو را هرگز با هم مخلوط "
    "نکنید.**",
    "This question asks the same concept from another angle, and its wrong options represent three different misconceptions.\n\n"
    "THE PATIENT: a 32-year-old woman from Bojnurd with a painless neck mass. She has fever and mild weight loss. Other examinations and tests are normal. Biopsy: CASEATING GRANULOMA.\n\n"
    "WARNING: 'CASEATING GRANULOMA' IS ALMOST A DIAGNOSIS RATHER THAN A FINDING. Its causes are a short list: TUBERCULOSIS first, then non-tuberculous mycobacteria, brucellosis, endemic fungi and a few rarities. IN IRAN, AND ESPECIALLY IN NORTH KHORASAN, TUBERCULOSIS IS DECISIVELY FIRST.\n\n"
    "THE DIFFERENCE FROM THE PREVIOUS QUESTION: this patient also has fever and mild weight loss — systemic features that strengthen the diagnosis further.\n\n"
    "THE ANSWER: THE STANDARD FOUR-DRUG ANTITUBERCULOUS REGIMEN FOR SIX MONTHS.\n\n"
    "WHY ARE THE OTHER THREE REJECTED? EACH REPRESENTS A DIFFERENT MISCONCEPTION:\n\n"
    "WARNING, MISCONCEPTION ONE — 'ISONIAZID FOR NINE MONTHS'. That is the regimen for LATENT INFECTION, not active disease. THE DIFFERENCE IS VITAL:\n\n"
    "IN LATENT TUBERCULOSIS the bacillary number is very small (perhaps a few thousand), so THE CHANCE OF A RESISTANT MUTANT IS NEGLIGIBLE and one drug suffices.\n\n"
    "IN ACTIVE DISEASE the population is millions or billions, so A RESISTANT MUTANT CERTAINLY EXISTS and monotherapy merely selects it. GIVING ISONIAZID ALONE TO A PATIENT WITH ACTIVE TUBERCULOSIS IS THE SUREST WAY TO CREATE ISONIAZID-RESISTANT DISEASE.\n\n"
    "MISCONCEPTION TWO — 'CLINICAL FOLLOW-UP IN SIX MONTHS'. That is not treating at all. A CASEATING GRANULOMA WITH FEVER AND WEIGHT LOSS IS ACTIVE DISEASE AND NEEDS TREATMENT, NOT WATCHING. Untreated nodal tuberculosis can fistulate to the skin (scrofuloderma) and disseminate.\n\n"
    "MISCONCEPTION THREE — 'ISONIAZID PLUS RIFAMPICIN FOR FOUR MONTHS'. Two drugs instead of four and four months instead of six. THIS REGIMEN RESEMBLES LATENT-INFECTION TREATMENT MORE THAN TREATMENT OF ACTIVE DISEASE.\n\n"
    "THE SUMMARISING RULE THAT REJECTS ALL THREE AT ONCE: ACTIVE DISEASE MEANS FOUR DRUGS FOR SIX MONTHS. LATENT INFECTION MEANS ONE OR TWO DRUGS FOR THREE TO NINE MONTHS. NEVER MIX THE TWO.",
    ["رژیم درمان عفونت نهفته است؛ تک‌دارو در بیماری فعال، سل مقاوم به ایزونیازید می‌سازد.",
     "یعنی درمان نکردن؛ گرانولوم کازئیفیه با تب و کاهش وزن، بیماری فعال است.",
     "دو دارو به‌جای چهار و چهار ماه به‌جای شش؛ به رژیم نهفته شبیه‌تر است تا فعال.",
     "پاسخ صحیح — رژیم چهاردارویی استاندارد شش‌ماهه، همان درمان بیماری فعال."],
    ["The latent-infection regimen; monotherapy in active disease creates isoniazid-resistant tuberculosis.",
     "That is not treating at all; a caseating granuloma with fever and weight loss is active disease.",
     "Two drugs instead of four and four months instead of six; closer to latent than to active treatment.",
     "Correct — the standard four-drug six-month regimen, the treatment of active disease."],
    "**بیماری فعال: چهار دارو، شش ماه. عفونت نهفته: یک یا دو دارو. هرگز مخلوط نکنید.**",
    "Active disease: four drugs, six months. Latent infection: one or two drugs. Never mix the two.",
    REFSW)

# ==================================================== XDR-TB
XDR_FA = [
    "⚠️ **تعریف‌ها را دقیق بدانید، چون هر کدام رژیم متفاوتی می‌خواهند.**",
    "**MDR-TB: مقاوم دست‌کم به ایزونیازید و ریفامپین با هم.**",
    "**pre-XDR: همان MDR، به‌علاوه مقاومت به هر فلوروکینولونی.**",
    "**XDR در تعریف ۲۰۲۱: MDR + مقاومت به فلوروکینولون + مقاومت به یک داروی گروه A دیگر.**",
    "**داروهای گروه A: لوو/موکسی‌فلوکساسین، بداکیلین، لاینزولید.**",
    "⚠️ **اصل درمان سل مقاوم: هرگز یک دارو به رژیم شکست‌خورده اضافه نکنید.**",
    "**چون آن یک دارو عملاً تک‌درمانی می‌شود و مقاومت بعدی را می‌سازد.**",
    "**رژیم باید از چند داروی مؤثرِ اثبات‌شده ساخته شود، هم‌زمان.**",
    "**و پایه‌ی انتخاب، آنتی‌بیوگرام است، نه حدس.**",
    "**رژیم ترجیحی امروز سازمان جهانی: BPaLM.**",
    "**یعنی بداکیلین، پرتومانید، لاینزولید و موکسی‌فلوکساسین — شش ماه، تماماً خوراکی.**",
    "⚠️ **و داروهای قدیمی خط دوم (سیکلوسرین، اتیونامید، PAS) امروز پشت صف‌اند.**",
]
XDR_EN = [
    "WARNING: KNOW THE DEFINITIONS PRECISELY, because each demands a different regimen.",
    "MDR-TB: resistant to at least isoniazid AND rifampicin together.",
    "PRE-XDR: MDR plus resistance to any fluoroquinolone.",
    "XDR in the 2021 definition: MDR plus fluoroquinolone resistance plus resistance to another Group A drug.",
    "The Group A drugs: levofloxacin/moxifloxacin, bedaquiline, linezolid.",
    "WARNING: THE CARDINAL RULE OF RESISTANT DISEASE — NEVER ADD A SINGLE DRUG TO A FAILING REGIMEN.",
    "Because that one drug becomes effective monotherapy and breeds the next resistance.",
    "The regimen must be built from several proven effective drugs, all at once.",
    "And the basis of that choice is the susceptibility result, not a guess.",
    "WHO's preferred regimen today: BPaLM.",
    "That is bedaquiline, pretomanid, linezolid and moxifloxacin — six months, entirely oral.",
    "WARNING, AND THE OLD SECOND-LINE DRUGS (cycloserine, ethionamide, PAS) NOW STAND AT THE BACK OF THE QUEUE.",
]

add("book:259", "recall", "hard",
    "**در سل با مقاومت گسترده، هر دو راهبرد لازم است: هم فلوروکینولون و هم داروهای خط دوم.**",
    "In extensively resistant tuberculosis both strategies are needed: the fluoroquinolone and the second-line drugs.",
    XDR_FA, XDR_EN,
    "این سؤال یک اصل بنیادی درمان سل مقاوم را می‌سنجد، و پاسخش «هر دو» است — به "
    "دلیلی که ارزش دارد یک‌بار برای همیشه فهمیده شود.\n\n"
    "**سؤال: در بیمار با سل ریوی مقاوم گسترده (XDR-TB)، کدام رژیم توصیه می‌شود؟ "
    "افزودن فلوروکینولون با دوز بالا، یا استفاده از داروهای خط دوم استفاده‌نشده؟**\n\n"
    "**پاسخ: هر دو.**\n\n"
    "⚠️ **چرا هرگز «فقط یکی»؟ به‌خاطر بنیادی‌ترین قاعده‌ی درمان سل مقاوم:**\n\n"
    "**هرگز یک داروی تنها را به رژیمی که شکست خورده اضافه نکنید.**\n\n"
    "**چرا؟** چون اگر رژیم فعلی شکست خورده، یعنی باسیل‌های زنده در برابر همه‌ی "
    "داروهای آن مقاوم‌اند. **افزودن یک داروی جدید به چنین رژیمی، از دید آن باسیل‌ها "
    "دقیقاً یعنی «تک‌درمانی با داروی جدید».** و تک‌درمانی همیشه به یک نتیجه می‌رسد: "
    "**جهش‌یافته‌ی مقاوم به داروی جدید انتخاب می‌شود، و شما آن دارو را هم از دست "
    "می‌دهید.**\n\n"
    "**این پدیده نامی هم دارد: «تکثیر مقاومت» (amplification). و همین است که "
    "بیمار MDR را به XDR تبدیل می‌کند.**\n\n"
    "**پس رژیم سل مقاوم باید:**\n\n"
    "**چند داروی مؤثر را هم‌زمان داشته باشد** (کلاسیک: دست‌کم چهار تا پنج داروی "
    "مؤثر) · **بر پایه‌ی آنتی‌بیوگرام ساخته شود، نه حدس** · **مدت طولانی‌تری ادامه یابد** "
    "· **تحت نظارت مستقیم اجرا شود**.\n\n"
    "**و به همین دلیل «هر دو» درست است:** فلوروکینولون با دوز بالا **و** داروهای خط "
    "دوم استفاده‌نشده، **با هم**، رژیمی می‌سازند که چند دارو دارد.\n\n"
    "⚠️ **حالا آنچه از زمان نگارش کتاب تغییر کرده، و باید بدانید:**\n\n"
    "**تعریف XDR در سال ۲۰۲۱ بازنویسی شد.** تعریف قدیمی بر پایه‌ی مقاومت به "
    "فلوروکینولون و **داروهای تزریقی خط دوم** بود. **تعریف جدید:** MDR/RR-TB به‌علاوه "
    "مقاومت به هر فلوروکینولون **به‌علاوه** مقاومت به دست‌کم یکی از داروهای دیگر "
    "**گروه A** (یعنی **بداکیلین** یا **لاینزولید**). و **pre-XDR** یعنی MDR به‌علاوه "
    "مقاومت فلوروکینولونی به‌تنهایی.\n\n"
    "**و رژیم هم عوض شده:** از دسامبر ۲۰۲۲، سازمان جهانی بهداشت رژیم **BPaLM** را "
    "توصیه می‌کند — **بداکیلین، پرتومانید، لاینزولید، موکسی‌فلوکساسین** — **شش ماه، "
    "تماماً خوراکی**. این جایگزین رژیم‌های ۱۸ تا ۲۰ ماهه‌ی تزریقی قدیمی شده و نتایج "
    "به‌مراتب بهتری دارد.\n\n"
    "**پس داروهایی که در گزینه‌ی «ب» آمده‌اند (سیکلوسرین، PAS، اتیونامید) امروز در "
    "گروه C قرار دارند — یعنی فقط وقتی به‌کار می‌روند که رژیم با داروهای گروه A و B "
    "کامل نشود. ولی اصل سؤال — «چند دارو با هم، نه یکی» — امروز هم دقیقاً برقرار "
    "است.**\n\n"
    "**چرا «هیچ‌کدام» رد می‌شود؟** چون XDR-TB **قابل درمان است**، هرچند سخت. رها کردن "
    "بیمار پذیرفتنی نیست.",
    "This question tests a cardinal principle of resistant tuberculosis treatment, and the answer is 'both' — for a reason worth understanding once and for all.\n\n"
    "THE QUESTION: in a patient with extensively drug-resistant pulmonary tuberculosis (XDR-TB), which regimen is recommended? Adding a high-dose fluoroquinolone, or using previously unused second-line drugs?\n\n"
    "THE ANSWER: BOTH.\n\n"
    "WARNING: WHY NEVER 'JUST ONE'? BECAUSE OF THE MOST FUNDAMENTAL RULE IN RESISTANT TUBERCULOSIS:\n\n"
    "NEVER ADD A SINGLE DRUG TO A FAILING REGIMEN.\n\n"
    "WHY? Because if the current regimen has failed, the surviving bacilli are resistant to everything in it. ADDING ONE NEW DRUG TO SUCH A REGIMEN IS, FROM THOSE BACILLI'S POINT OF VIEW, EXACTLY MONOTHERAPY WITH THE NEW DRUG. And monotherapy always ends the same way: A MUTANT RESISTANT TO THE NEW DRUG IS SELECTED AND YOU LOSE THAT DRUG TOO.\n\n"
    "THIS PHENOMENON HAS A NAME: AMPLIFICATION OF RESISTANCE. And it is exactly what turns an MDR patient into an XDR patient.\n\n"
    "SO A RESISTANT-TB REGIMEN MUST:\n\n"
    "contain SEVERAL EFFECTIVE DRUGS SIMULTANEOUSLY (classically at least four to five), be BUILT ON SUSCEPTIBILITY DATA RATHER THAN GUESSWORK, run for LONGER, and be given UNDER DIRECT OBSERVATION.\n\n"
    "AND THAT IS WHY 'BOTH' IS RIGHT: a high-dose fluoroquinolone AND previously unused second-line drugs, TOGETHER, make a regimen with several drugs.\n\n"
    "WARNING, NOW WHAT HAS CHANGED SINCE THE BOOK WAS WRITTEN, AND WHAT YOU MUST KNOW:\n\n"
    "THE DEFINITION OF XDR WAS REWRITTEN IN 2021. The old definition rested on resistance to a fluoroquinolone plus a SECOND-LINE INJECTABLE. THE NEW DEFINITION: MDR/RR-TB plus resistance to any fluoroquinolone PLUS resistance to at least one other GROUP A drug (that is, BEDAQUILINE or LINEZOLID). And PRE-XDR means MDR plus fluoroquinolone resistance alone.\n\n"
    "AND THE REGIMEN HAS CHANGED TOO: since December 2022 WHO recommends BPaLM — BEDAQUILINE, PRETOMANID, LINEZOLID, MOXIFLOXACIN — SIX MONTHS, ENTIRELY ORAL. It has replaced the old 18- to 20-month injectable regimens and gives far better outcomes.\n\n"
    "SO THE DRUGS NAMED IN OPTION B (cycloserine, PAS, ethionamide) now sit in Group C — used only when the regimen cannot be completed with Group A and B drugs. BUT THE PRINCIPLE THE QUESTION TESTS — SEVERAL DRUGS TOGETHER, NOT ONE — HOLDS EXACTLY AS FIRMLY TODAY.\n\n"
    "WHY IS 'NEITHER' REJECTED? Because XDR-TB IS TREATABLE, though difficult. Abandoning the patient is not acceptable.",
    ["به‌تنهایی نادرست است؛ افزودن یک داروی تنها به رژیم شکست‌خورده، تک‌درمانی و تکثیر مقاومت است.",
     "به‌تنهایی نادرست است؛ رژیم باید چند داروی مؤثر را هم‌زمان داشته باشد.",
     "پاسخ صحیح — رژیم سل مقاوم از چند داروی مؤثر هم‌زمان ساخته می‌شود، نه یکی.",
     "نادرست است؛ سل با مقاومت گسترده سخت ولی قابل درمان است و رها کردن بیمار پذیرفتنی نیست."],
    ["Wrong alone; adding a single drug to a failing regimen is monotherapy and amplifies resistance.",
     "Wrong alone; the regimen must contain several effective drugs at the same time.",
     "Correct — a resistant-TB regimen is built from several effective drugs together, not one.",
     "Wrong; extensively resistant tuberculosis is difficult but treatable, and abandoning the patient is unacceptable."],
    "**هرگز یک دارو به رژیم شکست‌خورده اضافه نکن — آن یک دارو تک‌درمانی است.**",
    "Never add a single drug to a failing regimen — that one drug is monotherapy.",
    REFSW)

json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book53.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 53 lessons:', len(L))
