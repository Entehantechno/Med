# -*- coding: utf-8 -*-
"""English stems and options for the batch-26 and batch-27 questions (CNS).

Rule 16 checked first, as always: these are sittings 93 to 98, for which the
ministry published no English booklet, so these are hand-written translations.

Translation decisions worth recording
-------------------------------------
The CSF panels here were the most heavily repaired of any chapter — eighteen
numbers across twelve questions — and every English stem quotes the REPAIRED
values, because in meningitis the panel IS the diagnosis:

  q9156 (idx 156): glucose stored as 2 and protein as 21; page 61 prints 20
        and 120. 'Glucose 2 with protein 21' is a combination that occurs in
        no meningitis, and it destroyed the pattern the question teaches.
  q9161 (idx 161): pleocytosis stored as '043'; page 63 prints 340.
  q9163 (idx 163): protein '09' and RBC '001'; page 64 prints 90 and 100. The
        red cell count matters: red cells in the CSF without a traumatic tap
        are the signature of the haemorrhagic necrosis of herpes encephalitis.
  q9166 (idx 166): the panel is quoted as printed (160 cells, 80% lymphocytes,
        glucose 20, protein 310) — a very high protein is the hallmark of
        tuberculous meningitis and must survive into the English.
  q9186 (idx 186): WBC 1000 with 25% neutrophils. The English keeps both
        figures because the reader is expected to compute the absolute
        neutrophil count of 250 and recognise severe neutropenia.

q9167 (idx 167): the first draft dropped the CD4 count and the normal brain CT.
apply_en.py rejected it — 'numbers lost in translation: 100' — and was right to.
A CD4 BELOW 100 is not background detail: it is the threshold at which
cryptococcal disease disseminates, and it is half the reason the answer is
Cryptococcus rather than tuberculosis. The normal CT matters too, since it
excludes the mass lesion that would change the management.

q9152 (idx 152): the stem lists four candidate indications and asks which is
NOT one. The English preserves all four exactly, including 'old age', because
the whole question turns on age being a surrogate rather than a criterion.
"""

EN12 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    assert all(o.strip() for o in options), idx
    EN12[idx] = {"stem_en": stem, "options_en": options}


# ================================== order of actions and CSF panel (batch 26)
add(143,
    "A young man presents with fever, severe headache, nausea and vomiting for the past two "
    "days. He is fully alert and has no focal neurological deficit and no papilloedema. Which "
    "diagnostic and therapeutic course of action is appropriate for him?",
    ["Brain CT scan, lumbar puncture, blood culture and starting antibiotics",
     "Blood culture, starting antibiotics, brain CT scan and lumbar puncture",
     "Starting antibiotics, blood culture, brain CT scan and lumbar puncture",
     "Blood culture, starting antibiotics, lumbar puncture"])

add(145,
    "A 58-year-old man presents with fever, headache, vomiting and drowsiness. He gives a "
    "history of seizures. On examination he has neck stiffness and papilloedema. Name, in order, "
    "the actions required for this patient.",
    ["Lumbar puncture, blood culture, starting antibiotics",
     "Blood culture, lumbar puncture, starting antibiotics",
     "Blood culture, starting antibiotics, brain CT scan",
     "Brain CT scan, starting antibiotics, lumbar puncture"])

add(152,
    "A 55-year-old patient is referred to the emergency department with headache, fever and "
    "reduced consciousness. Last month he was treated with antibiotics for sinusitis. On "
    "examination his temperature is 38 and papilloedema is present. Which of the following is "
    "NOT an indication for performing a brain CT before the lumbar puncture?",
    ["Reduced consciousness", "The history of sinusitis", "Old age", "Papilloedema"])

add(156,
    "An 18-year-old presents to the emergency department with fever and headache since this "
    "morning. On examination, besides the fever, neck stiffness was found. He has no underlying "
    "disease and no history of head injury, and he answers questions correctly. The CSF analysis "
    "is as follows: WBC 800, PMN 87%, glucose 20 mg/dl, protein 120 mg/dl. Which organism is the "
    "most likely cause of his illness?",
    ["Herpes simplex virus", "Streptococcus pneumoniae", "Cryptococcus neoformans",
     "Plasmodium falciparum"])

add(161,
    "A 16-year-old girl with no underlying disease presents with severe headache, neck pain, "
    "nausea and vomiting worsening over the past 3 days. On examination she has neck stiffness "
    "on passive flexion. With a probable diagnosis of meningitis a lumbar puncture is performed, "
    "and the CSF analysis shows a pleocytosis of 340 per cubic millimetre with lymphocyte "
    "predominance, a protein of 90 mg/dl and a glucose of 70 mg/dl. Given the whole picture, "
    "which pathogen do you consider more likely as the cause?",
    ["Streptococcus pneumoniae", "Enterovirus", "Listeria monocytogenes", "Cytomegalovirus"])

add(166,
    "A 65-year-old patient with a headache of 20 days and several episodes of vomiting, together "
    "with a temperature of 38 degrees Celsius, undergoes a lumbar puncture. The CSF analysis is "
    "reported as WBC 160 (80% lymphocytes), a CSF glucose of about 20 mg/dl and a protein of 310 "
    "mg/dl. Which diagnosis is most likely?",
    ["Acute bacterial meningitis", "Viral meningitis", "Carcinomatous meningitis",
     "Tuberculous meningitis"])

add(163,
    "A young man presents to the emergency department with fever, headache, seizures and altered "
    "consciousness since yesterday. Examination of the CSF shows a white cell count of 100, a "
    "protein of 90 and a red cell count of 100. MRI shows involvement of the temporal lobe. "
    "Which is the most likely causative agent?",
    ["Herpes simplex virus", "Pneumococcus", "Meningococcus", "Haemophilus influenzae"])


# ============= empirical therapy, brain abscess and prophylaxis (batch 27)
add(171,
    "A 20-year-old developed fever and headache abruptly yesterday. This morning his level of "
    "consciousness fell and his companions brought him to the emergency department. No "
    "diagnostic investigations are possible. Which is the most appropriate empirical treatment?",
    ["Aciclovir plus vancomycin plus ampicillin",
     "Ceftriaxone plus vancomycin plus ampicillin",
     "Meropenem plus vancomycin",
     "Aciclovir plus ceftriaxone plus vancomycin"])

add(180,
    "A 60-year-old diabetic man presents with fever and headache. On examination he has signs of "
    "meningeal irritation. Before the CSF analysis is available, which of the following "
    "empirical treatments would you choose?",
    ["Vancomycin plus ceftazidime", "Ampicillin plus gentamicin",
     "Vancomycin plus ceftriaxone plus ampicillin",
     "Vancomycin plus ceftriaxone plus gentamicin"])

add(186,
    "A 59-year-old man presents to the emergency department with fever and headache. He has a "
    "history of chemotherapy for gastric cancer. On examination he has neck stiffness and is "
    "febrile. Investigations show a WBC of 1000 with 25% neutrophils. Which initial empirical "
    "treatment is appropriate for him?",
    ["Ampicillin plus cefotaxime", "Meropenem plus metronidazole plus ampicillin",
     "Cefepime plus vancomycin", "Ampicillin plus ceftazidime plus vancomycin"])

add(184,
    "A 25-year-old patient with a history of chronic otitis media presents with fever and "
    "rigors, headache and aphasia. On examination his temperature is 39 degrees and power in the "
    "right upper and lower limbs is reduced. Given the most likely diagnosis, which treatment do "
    "you recommend for this patient?",
    ["Ceftriaxone plus meropenem", "Ceftriaxone plus metronidazole",
     "Aciclovir plus metronidazole", "Aciclovir plus meropenem"])

add(199,
    "A man has developed meningococcal meningitis. What do you recommend as prophylaxis for his "
    "pregnant wife?",
    ["Rifampicin", "Ciprofloxacin", "Ceftriaxone", "Co-trimoxazole"])

add(192,
    "A soldier living in barracks accommodation is admitted to hospital with a diagnosis of "
    "bacterial meningitis. In which of the following meningitides is it necessary for the other "
    "soldiers in that accommodation to receive antibiotic prophylaxis?",
    ["Brucellar meningitis", "Pneumococcal meningitis", "Tuberculous meningitis",
     "Meningococcal meningitis"])

add(167,
    "An HIV-positive patient presents with fever, headache, nausea, vomiting and altered "
    "consciousness for the past 3 weeks. On examination he has neck stiffness. Lumbar puncture "
    "shows a slightly raised white cell count and protein with a reduced glucose in the CSF. "
    "India ink staining of the CSF is positive. The brain CT is normal. His CD4 count is below "
    "100. Which of the following is the likely diagnosis?",
    ["Infection with Candida", "Infection with Mycobacterium tuberculosis",
     "Infection with Cryptococcus", "Infection with Coccidioides immitis"])
