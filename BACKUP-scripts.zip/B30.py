# -*- coding: utf-8 -*-
"""Micro-lessons, batch 30 — genital ulcers and urethritis.

The first half of the viral and STI chapter, and the densest cluster of
near-identical questions in the whole book. Thirty-odd stems describe a young
adult some days after unprotected intercourse and ask either "which ulcer is
this?" or "what do you give?". They all reduce to two small tables, and a
student who owns those two tables answers the lot.

TABLE ONE — THE ULCER IS IDENTIFIED BY PAIN AND TEXTURE
Two questions settle almost every genital ulcer in this chapter:
  is it PAINFUL or PAINLESS?   is it SOFT or HARD?
  painful + soft + purulent + suppurating nodes  -> chancroid
  painless + hard + clean base + rubbery nodes   -> syphilis
  painful + grouped vesicles first               -> herpes
  small transient ulcer, then huge nodes         -> LGV
The examiners never deviate from that grid, and three separate questions in
this chapter (q9530, q9531, q9532) are the same chancroid vignette reworded.

TABLE TWO — URETHRITIS IS TWO ORGANISMS, NOT ONE
Almost every treatment question here turns on remembering that gonorrhoea and
chlamydia travel together, that the gram stain only sees the gonococcus, and
that treating what you can see leaves the other one behind. Post-gonococcal
urethritis — symptoms returning a week later with no new exposure — is the
exam's favourite way of asking it.

A NOTE ON WHICH GUIDELINE IS TAUGHT, WHICH MATTERS MORE HERE THAN ANYWHERE
--------------------------------------------------------------------------
These sittings were written against the CDC 2015 guideline: ceftriaxone 250 mg
plus azithromycin 1 g, given together as routine dual therapy. The CDC 2021
guideline changed BOTH halves of that sentence:

  * gonorrhoea is now ceftriaxone 500 mg MONOTHERAPY (1 g if over 150 kg);
    routine azithromycin co-treatment was dropped for stewardship reasons and
    because of rising macrolide resistance
  * chlamydia is now DOXYCYCLINE 100 mg twice daily for 7 days, with
    azithromycin demoted to an alternative (still preferred in pregnancy)
  * doxycycline is added to ceftriaxone only when chlamydia has NOT been
    excluded — which, in every stem here, it has not

So the exam answer and current practice differ in the DOSE and in the SECOND
DRUG, while agreeing completely on the principle the questions are actually
testing: cover both organisms. Every lesson below states the keyed answer and
then the 2021 position explicitly. Teaching only the old regimen would be
teaching a superseded dose; silently teaching only the new one would make the
student answer the exam wrongly. Both, labelled, is the only honest option —
the same decision taken for clindamycin in the endocarditis chapter.

Numbers repaired before writing: q9541's ceftriaxone dose; see
fix_viral_sti_numbers.py.

Reference: Workowski KA et al., "Sexually Transmitted Infections Treatment
Guidelines, 2021", MMWR Recomm Rep 2021;70(4):1-187 (CDC); Harrison's
Principles of Internal Medicine, 21st ed (2022), Ch. 35 (Sexually Transmitted
Infections) and Ch. 182 (Syphilis).
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


CDC2021 = ("Workowski KA et al. — Sexually Transmitted Infections Treatment Guidelines, 2021. "
           "MMWR Recomm Rep 2021;70(4):1-187 (Centers for Disease Control and Prevention)")
H35 = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 35: "
       "Sexually Transmitted Infections: Overview and Clinical Approach")
H182 = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 182: Syphilis")

# ------------------------------------------------------------- the ulcer grid
ULCER_FA = [
    "⚠️ **زخم تناسلی را با دو سؤال تشخیص دهید: دردناک است یا بی‌درد؟ نرم است یا سفت؟**",
    "**این دو سؤال، چهار بیماری اصلی را از هم جدا می‌کنند و در امتحان هرگز از این شبکه خارج نمی‌شوند.**",
    "⚠️ **شانکروئید — دردناک، نرم، چرکی، با لبه‌ی نامنظم و کنده‌شده.**",
    "**عاملش هموفیلوس دوکره‌ای (Haemophilus ducreyi)، یک کوکوباسیل گرم‌منفی.**",
    "**غدد لنفاوی‌اش دردناک، یک‌طرفه و چرکی‌اند و می‌توانند سوراخ شوند (بوبو).**",
    "**دوره‌ی کمون کوتاه: ۳ تا ۷ روز.** پس «چند روز پس از تماس» به نفع شانکروئید است.",
    "⚠️ **سیفلیس اولیه (شانکر) — بدون درد، سفت، با بستر تمیز و لبه‌ی منظم و برجسته.**",
    "**عاملش ترپونما پالیدوم؛ دوره‌ی کمون بلندتر: حدود ۳ هفته (۱۰ تا ۹۰ روز).**",
    "**غدد لنفاوی‌اش دوطرفه، لاستیکی و بدون درد است — دقیقاً برعکس شانکروئید.**",
    "**و شانکر حتی بدون درمان هم خودبه‌خود در ۳ تا ۶ هفته خوب می‌شود** — که دام بزرگی است.",
    "⚠️ **هرپس تناسلی — دردناک، ولی با وزیکول‌های گروهی که بعد زخم می‌شوند.**",
    "**در حمله‌ی اول علائم سیستمیک هم دارد: تب، بدن‌درد، سردرد.**",
    "**زخم‌هایش سطحی و متعددند، نه یک زخم عمیق منفرد.**",
    "**لنفوگرانولوم ونروم (LGV) — زخم اولیه‌ی کوچک و گذرا که اغلب دیده نمی‌شود،**",
    "**و بعد لنفادنوپاتی بزرگ و دردناک اینگوینال. عاملش سروتیپ‌های L کلامیدیاست.**",
    "⚠️ **علامت شیار (groove sign): درگیری غدد بالا و پایین رباط اینگوینال، مشخصه‌ی LGV.**",
    "**و یک قاعده‌ی عملی که همیشه صادق است: زخم تناسلی می‌تواند بیش از یک علت داشته باشد.**",
    "**در هر زخم تناسلی، سرولوژی سیفلیس و آزمایش HIV را هم بفرستید.**",
    "**چون زخم تناسلی خودش دروازه‌ی ورود HIV است و خطر انتقال را چند برابر می‌کند.**",
]
ULCER_EN = [
    "WARNING: IDENTIFY A GENITAL ULCER WITH TWO QUESTIONS: IS IT PAINFUL OR PAINLESS? SOFT OR HARD?",
    "Those two questions separate the four main diseases, and the exam never leaves that grid.",
    "WARNING, CHANCROID — PAINFUL, SOFT, PURULENT, with a ragged undermined edge.",
    "Its agent is Haemophilus ducreyi, a gram-negative coccobacillus.",
    "Its nodes are PAINFUL, UNILATERAL AND SUPPURATIVE, and may rupture (a bubo).",
    "Short incubation: 3 to 7 days. So 'a few days after exposure' favours chancroid.",
    "WARNING, PRIMARY SYPHILIS (CHANCRE) — PAINLESS, HARD, with a CLEAN BASE and a regular raised edge.",
    "Its agent is Treponema pallidum; the incubation is longer, about 3 weeks (10 to 90 days).",
    "Its nodes are BILATERAL, RUBBERY AND PAINLESS — the exact opposite of chancroid.",
    "And a chancre HEALS BY ITSELF in 3 to 6 weeks even untreated, which is a major trap.",
    "WARNING, GENITAL HERPES — PAINFUL, but beginning as GROUPED VESICLES that then ulcerate.",
    "A first attack also brings systemic features: fever, myalgia, headache.",
    "Its ulcers are SHALLOW AND MULTIPLE, not one deep solitary sore.",
    "LYMPHOGRANULOMA VENEREUM (LGV) — a small transient primary ulcer that is often never seen,",
    "followed by large painful inguinal lymphadenopathy. Its agent is chlamydia serovars L.",
    "WARNING, THE GROOVE SIGN: nodes above and below the inguinal ligament, characteristic of LGV.",
    "And a practical rule that always holds: a genital ulcer may have MORE THAN ONE cause.",
    "In every genital ulcer, also send syphilis serology and an HIV test.",
    "Because a genital ulcer is itself a portal of entry for HIV and multiplies the transmission risk.",
]

# ------------------------------------------------------- the urethritis table
URE_FA = [
    "⚠️ **قاعده‌ی محوری کل این بخش: اورتریت یک ارگانیسم نیست، دو تاست.**",
    "**گونوکوک و کلامیدیا با هم سفر می‌کنند، و در ۲۰ تا ۴۰ درصد موارد هم‌زمان‌اند.**",
    "**و مشکل اینجاست: رنگ‌آمیزی گرم فقط گونوکوک را می‌بیند.**",
    "⚠️ **دیپلوکوک گرم‌منفی داخل سلولی = گونوکوک. ولی نبودنش، کلامیدیا را رد نمی‌کند —**",
    "**چون کلامیدیا یک باکتری داخل‌سلولی اجباری است و در رنگ‌آمیزی گرم اصلاً دیده نمی‌شود.**",
    "**پس «چیزی دیده نشد» یعنی اورتریت غیرگونوکوکی، نه «اورتریتی در کار نیست».**",
    "**تفاوت بالینی‌شان هم هست، ولی برای تصمیم‌گیری کافی نیست:**",
    "**گونوکوک: کمون ۲ تا ۵ روز، ترشح چرکی و فراوان، شروع ناگهانی.**",
    "**کلامیدیا: کمون ۱ تا ۳ هفته، ترشح مخاطی یا سروزی و کم، شروع تدریجی.**",
    "⚠️ **ولی هم‌پوشانی زیاد است، پس درمان بر پایه‌ی ظاهر ترشح بنا نمی‌شود.**",
    "**پاسخ کلید این آزمون‌ها (راهنمای ۲۰۱۵): سفتریاکسون ۲۵۰ میلی‌گرم عضلانی + آزیترومایسین ۱ گرم خوراکی.**",
    "⚠️ **و به‌روزرسانی مهم — راهنمای CDC سال ۲۰۲۱ هر دو نیمه‌ی این جمله را عوض کرد:**",
    "**گونوکوک: سفتریاکسون ۵۰۰ میلی‌گرم عضلانی، تک‌دارو** (۱ گرم برای بالای ۱۵۰ کیلوگرم).",
    "**کلامیدیا: داکسی‌سیکلین ۱۰۰ میلی‌گرم دو بار در روز، ۷ روز** — آزیترومایسین به جایگزین تنزل یافت.",
    "**پس امروز: سفتریاکسون + داکسی‌سیکلین، و داکسی‌سیکلین فقط وقتی که کلامیدیا رد نشده باشد.**",
    "**در بارداری، آزیترومایسین همچنان انتخاب اول کلامیدیاست** (داکسی‌سیکلین ممنوع است).",
    "⚠️ **و اصلی که در هر دو راهنما یکسان است و امتحان همان را می‌خواهد: هر دو ارگانیسم را بپوشانید.**",
    "**درمان شریک جنسی جزء لاینفک درمان است، نه یک توصیه‌ی اضافی.**",
    "**بدون آن، بیمار ظرف چند هفته دوباره آلوده می‌شود — پدیده‌ی «پینگ‌پنگ».**",
    "**و پرهیز از تماس جنسی تا ۷ روز پس از درمان تک‌دوز، برای بیمار و شریکش.**",
]
URE_EN = [
    "WARNING, THE CENTRAL RULE OF THIS WHOLE BLOCK: URETHRITIS IS NOT ONE ORGANISM, IT IS TWO.",
    "Gonorrhoea and chlamydia travel together and coexist in 20 to 40 per cent of cases.",
    "And here is the problem: THE GRAM STAIN ONLY SEES THE GONOCOCCUS.",
    "WARNING: INTRACELLULAR GRAM-NEGATIVE DIPLOCOCCI MEAN GONORRHOEA. But their absence does NOT exclude chlamydia,",
    "because chlamydia is an obligate intracellular organism and is not visible on a gram stain at all.",
    "So 'nothing was seen' means NON-GONOCOCCAL urethritis, not 'there is no urethritis'.",
    "There are clinical differences too, but they are not enough to decide treatment:",
    "GONORRHOEA: incubation 2 to 5 days, copious purulent discharge, abrupt onset.",
    "CHLAMYDIA: incubation 1 to 3 weeks, scant mucoid or serous discharge, gradual onset.",
    "WARNING, BUT THE OVERLAP IS LARGE, so treatment is not built on the look of the discharge.",
    "The keyed answer in these exams (the 2015 guideline): CEFTRIAXONE 250 MG IM PLUS AZITHROMYCIN 1 G ORALLY.",
    "WARNING, AN IMPORTANT UPDATE — THE CDC 2021 GUIDELINE CHANGED BOTH HALVES OF THAT SENTENCE:",
    "GONORRHOEA: CEFTRIAXONE 500 MG IM AS MONOTHERAPY (1 g if over 150 kg).",
    "CHLAMYDIA: DOXYCYCLINE 100 MG TWICE DAILY FOR 7 DAYS — azithromycin was demoted to an alternative.",
    "So today: ceftriaxone plus doxycycline, and the doxycycline only when chlamydia has not been excluded.",
    "IN PREGNANCY, AZITHROMYCIN REMAINS FIRST CHOICE for chlamydia (doxycycline is contraindicated).",
    "WARNING, AND THE PRINCIPLE IDENTICAL IN BOTH GUIDELINES, WHICH IS WHAT THE EXAM WANTS: COVER BOTH ORGANISMS.",
    "TREATING THE SEXUAL PARTNER IS PART OF THE TREATMENT, not an optional extra.",
    "Without it the patient is reinfected within weeks — the 'ping-pong' phenomenon.",
    "And abstinence for 7 days after single-dose therapy, for the patient and the partner alike.",
]


# =========================================================== book:530
add("book:530", "case", "easy",
 "پوستول‌های **دردناک و نرم** با قاعده‌ی چرکی و غدد **دردناک و چرکی** ← **شانکروئید**.",
 "PAINFUL, SOFT pustules with a purulent base and PAINFUL SUPPURATIVE nodes: CHANCROID.",
 ULCER_FA + [
  "**در این سؤال چهار کلمه تشخیص را قطعی می‌کنند و هر چهار عمداً آمده‌اند:**",
  "**«نرم»، «بسیار دردناک»، «قاعده‌ی چرکی»، و «غدد لنفاوی دردناک و چرکی».**",
  "⚠️ **هر چهار، دقیقاً نقطه‌ی مقابل شانکر سیفلیس‌اند.**",
  "**و یک سرنخ پنجم: «۵ روز بعد از تماس» — کمون کوتاه، که به شانکروئید می‌خورد نه سیفلیس.**",
  "**خونریزی آسان ضایعه هم مشخصه‌ی بافت گرانولاسیون شکننده‌ی شانکروئید است.**",
  "**درمان شانکروئید چهار گزینه دارد و همه مؤثرند:**",
  "**آزیترومایسین ۱ گرم تک‌دوز خوراکی · سفتریاکسون ۲۵۰ میلی‌گرم تک‌دوز عضلانی**",
  "**سیپروفلوکساسین ۵۰۰ میلی‌گرم دو بار در روز ۳ روز · اریترومایسین ۵۰۰ سه بار در روز ۷ روز**",
  "⚠️ **و بوبوی بزرگ و پرتنش را باید آسپیره یا درناژ کرد، چون خودبه‌خود می‌ترکد.**",
 ],
 ULCER_EN + [
  "FOUR WORDS IN THIS STEM SETTLE THE DIAGNOSIS, AND ALL FOUR ARE THERE DELIBERATELY:",
  "'soft', 'very painful', 'purulent base', and 'painful suppurative nodes'.",
  "WARNING: ALL FOUR ARE THE EXACT OPPOSITE OF A SYPHILITIC CHANCRE.",
  "And a fifth clue: 'five days after exposure' — a short incubation, fitting chancroid, not syphilis.",
  "The lesion bleeding easily also reflects the friable granulation tissue of chancroid.",
  "Chancroid has four treatment options and all are effective:",
  "AZITHROMYCIN 1 G orally single dose; CEFTRIAXONE 250 MG IM single dose;",
  "CIPROFLOXACIN 500 MG twice daily for 3 days; ERYTHROMYCIN 500 MG three times daily for 7 days.",
  "WARNING, AND A LARGE TENSE BUBO SHOULD BE ASPIRATED OR DRAINED, because it will rupture on its own.",
 ],
 "این سؤال ساده‌ترین شکل شبکه‌ی تشخیصی زخم تناسلی است و باید مثل یک رفلکس پاسخ داده شود.\n\n"
 "**آقای جوان، ۵ روز پس از تماس جنسی**، با **پوستول‌های متعدد نامنظم، نرم و بسیار دردناک** "
 "با **قاعده‌ی چرکی**، که **به‌راحتی خونریزی می‌کنند**، و **غدد لنفاوی دردناک و چرکی**.\n\n"
 "⚠️ **پنج سرنخ، همه به یک سمت:**\n\n"
 "**۱) دردناک** — سیفلیس بی‌درد است. ✗سیفلیس\n\n"
 "**۲) نرم** — شانکر سیفلیس **سفت** است (اصلاً به آن hard chancre می‌گویند). ✗سیفلیس\n\n"
 "**۳) قاعده‌ی چرکی** — شانکر سیفلیس بستر **تمیز** دارد. ✗سیفلیس\n\n"
 "**۴) غدد چرکی و دردناک** — در سیفلیس غدد **لاستیکی و بی‌درد** و در LGV بزرگ ولی بدون "
 "زخم چرکی همراه‌اند. ✗سیفلیس ✗LGV\n\n"
 "**۵) کمون ۵ روزه** — سیفلیس حدود ۳ هفته کمون دارد. ✗سیفلیس\n\n"
 "**و چرا هرپس نه؟** چون هرپس با **وزیکول‌های گروهی** شروع می‌شود و زخم‌هایش **سطحی و "
 "متعدد**اند، نه پوستول‌های عمیق چرکی با خونریزی آسان. ضمناً در هرپس اولیه معمولاً **علائم "
 "سیستمیک** (تب و بدن‌درد) هم هست که اینجا ذکر نشده.\n\n"
 "**پس: شانکروئید، ناشی از هموفیلوس دوکره‌ای.**\n\n"
 "⚠️ **نکته‌ی عملی مهم:** تشخیص شانکروئید عمدتاً **بالینی** است، چون کشت هموفیلوس دوکره‌ای "
 "محیط اختصاصی می‌خواهد و حساسیتش زیر ۸۰ درصد است. ولی **همیشه سرولوژی سیفلیس و تست HIV** "
 "را هم بفرستید — هم به‌خاطر امکان هم‌زمانی، و هم چون زخم تناسلی خودش خطر انتقال HIV را "
 "چند برابر می‌کند.",
 "This is the genital-ulcer grid in its simplest form and should be answered as a reflex.\n\n"
 "A YOUNG MAN, FIVE DAYS AFTER INTERCOURSE, with MULTIPLE IRREGULAR, SOFT, VERY PAINFUL "
 "PUSTULES on a PURULENT BASE that BLEED EASILY, and PAINFUL SUPPURATIVE NODES.\n\n"
 "WARNING, FIVE CLUES, ALL POINTING THE SAME WAY:\n\n"
 "1) PAINFUL — syphilis is painless. NOT syphilis\n\n"
 "2) SOFT — a syphilitic chancre is HARD (it is literally called a hard chancre). NOT syphilis\n\n"
 "3) PURULENT BASE — a syphilitic chancre has a CLEAN base. NOT syphilis\n\n"
 "4) SUPPURATIVE PAINFUL NODES — in syphilis the nodes are RUBBERY AND PAINLESS, and in LGV they "
 "are large but without an accompanying purulent ulcer. NOT syphilis, NOT LGV\n\n"
 "5) FIVE-DAY INCUBATION — syphilis incubates for about three weeks. NOT syphilis\n\n"
 "AND WHY NOT HERPES? Because herpes begins as GROUPED VESICLES and its ulcers are SHALLOW AND "
 "MULTIPLE, not deep purulent pustules that bleed easily. A first herpes attack also usually "
 "brings SYSTEMIC symptoms (fever, myalgia), which are not mentioned here.\n\n"
 "SO: CHANCROID, caused by Haemophilus ducreyi.\n\n"
 "WARNING, A PRACTICAL POINT: chancroid is diagnosed largely CLINICALLY, because culturing "
 "H. ducreyi needs special media and is less than 80 per cent sensitive. But ALWAYS send syphilis "
 "serology and an HIV test as well — both because coinfection is possible and because a genital "
 "ulcer itself multiplies the risk of HIV transmission.",
 ["پاسخ صحیح — نرم، دردناک، چرکی، با غدد چرکی و کمون کوتاه: چهار مشخصه‌ی شانکروئید.",
  "شانکر سیفلیس بی‌درد، سفت و با بستر تمیز است و غددش لاستیکی و بدون درد.",
  "در LGV زخم اولیه کوچک و گذراست و تابلو با لنفادنوپاتی بزرگ غالب می‌شود، نه پوستول چرکی.",
  "هرپس با وزیکول‌های گروهی و زخم‌های سطحی و علائم سیستمیک شروع می‌شود، نه پوستول عمیق چرکی."],
 ["Correct — soft, painful, purulent, with suppurative nodes and a short incubation: the four marks of chancroid.",
  "A syphilitic chancre is painless, hard and clean-based, and its nodes are rubbery and painless.",
  "In LGV the primary ulcer is small and transient and the picture is dominated by large nodes, not purulent pustules.",
  "Herpes begins with grouped vesicles, shallow ulcers and systemic symptoms, not deep purulent pustules."],
 "**دردناک + نرم + چرکی = شانکروئید. بی‌درد + سفت + تمیز = سیفلیس.**",
 "Painful, soft and purulent means chancroid; painless, hard and clean means syphilis.",
 [CDC2021, H35])


# =========================================================== book:557
add("book:557", "case", "easy",
 "پاپول **بدون درد، سفت، با حدود مشخص و بستر تمیز** یک ماه پس از تماس ← **سیفلیس اولیه**.",
 "A PAINLESS, FIRM, well-demarcated papule with a CLEAN base a month after exposure: PRIMARY SYPHILIS.",
 ULCER_FA + [
  "**این سؤال قرینه‌ی دقیق سؤال شانکروئید است — همان شبکه، از سمت مقابل.**",
  "**پنج کلمه‌ی کلیدی: «بدون درد»، «سفت»، «حدود مشخص»، «غیرچرکی و تمیز»، «یک ماه بعد».**",
  "⚠️ **«بدون درد» به‌تنهایی شانکروئید و هرپس را حذف می‌کند.**",
  "**«سفت» همان hard chancre است — سفتی غضروفی زیر انگشت حس می‌شود.**",
  "**«یک ماه بعد» با کمون ۳ هفته‌ای سیفلیس می‌خواند، نه با کمون چندروزه‌ی شانکروئید.**",
  "**و لنفادنوپاتی دوطرفه هم به سیفلیس می‌خورد؛ شانکروئید یک‌طرفه است.**",
  "⚠️ **مهم‌ترین دام سیفلیس اولیه: شانکر بدون درمان هم خودبه‌خود خوب می‌شود.**",
  "**بیمار خیال می‌کند بهبود یافته، ولی بیماری وارد مرحله‌ی ثانویه و سپس نهفته می‌شود.**",
  "**تشخیص: میکروسکوپ زمینه‌تاریک یا PCR از خودِ ضایعه، به‌علاوه‌ی سرولوژی.**",
  "**و در همان هفته‌های اول، سرولوژی غیرترپونمایی ممکن است هنوز منفی باشد.**",
 ],
 ULCER_EN + [
  "This question is the exact mirror of the chancroid one — the same grid, from the other side.",
  "Five key words: 'painless', 'firm', 'well-demarcated', 'non-purulent and clean', 'one month later'.",
  "WARNING: 'PAINLESS' ALONE ELIMINATES CHANCROID AND HERPES.",
  "'Firm' is the hard chancre — a cartilaginous induration felt under the finger.",
  "'One month later' fits the three-week incubation of syphilis, not the few days of chancroid.",
  "And bilateral lymphadenopathy fits syphilis too; chancroid is unilateral.",
  "WARNING, THE GREAT TRAP OF PRIMARY SYPHILIS: THE CHANCRE HEALS BY ITSELF WITHOUT TREATMENT.",
  "The patient believes he has recovered, while the disease moves to the secondary and then latent stage.",
  "Diagnosis: dark-field microscopy or PCR from the lesion itself, plus serology.",
  "And in those first weeks the non-treponemal serology may still be negative.",
 ],
 "این سؤال، قرینه‌ی دقیق سؤال شانکروئید است. اگر آن یکی را فهمیده باشید، این یکی خودبه‌خود "
 "حل می‌شود.\n\n"
 "**آقای جوان، یک ماه پس از تماس محافظت‌نشده**، با **یک پاپول ۱ سانتی‌متری بدون درد، سفت، "
 "برجسته و گرد با حدود مشخص**، ضایعه‌ی **غیرچرکی و تمیز**، و **تورم دوطرفه‌ی غدد اینگوینال**.\n\n"
 "⚠️ **جدول مقایسه را در ذهن اجرا کنید:**\n\n"
 "ویژگی: این بیمار — شانکروئید — سیفلیس\n"
 "درد: **ندارد** — دارد — ندارد ✔\n"
 "قوام: **سفت** — نرم — سفت ✔\n"
 "بستر: **تمیز** — چرکی — تمیز ✔\n"
 "غدد: **دوطرفه** — یک‌طرفه چرکی — دوطرفه لاستیکی ✔\n"
 "کمون: **یک ماه** — ۳ تا ۷ روز — حدود ۳ هفته ✔\n\n"
 "**هر پنج ویژگی به سیفلیس اولیه می‌خورد.**\n\n"
 "**و چرا دونووانوزیس (گرانولوم اینگوینال) نه؟** آن هم بدون درد است، ولی ضایعه‌اش یک "
 "**زخم گوشتی، قرمز روشن و بسیار خون‌ریز (beefy red)** است که **بزرگ و گسترده** می‌شود و "
 "**لنفادنوپاتی واقعی ندارد** (تورمش از خودِ ضایعه‌ی زیرجلدی است). ضمناً در ایران بسیار "
 "نادر است.\n\n"
 "⚠️ **مهم‌ترین نکته‌ی بالینی این سؤال، چیزی است که در صورت سؤال نیست: شانکر خودبه‌خود خوب "
 "می‌شود.**\n\n"
 "شانکر سیفلیس **حتی بدون هیچ درمانی**، ظرف **۳ تا ۶ هفته** بهبود می‌یابد. بیمار خیال "
 "می‌کند خوب شده و مراجعه نمی‌کند — و بیماری وارد **مرحله‌ی ثانویه** (راش کف دست و پا، "
 "کوندیلوما لاتا) و سپس **نهفته** می‌شود. **به همین دلیل است که هر زخم تناسلی باید سرولوژی "
 "سیفلیس بگیرد، حتی اگر در حال بهبود باشد.**",
 "This is the exact mirror of the chancroid question. If you understood that one, this solves itself.\n\n"
 "A YOUNG MAN, ONE MONTH AFTER UNPROTECTED INTERCOURSE, with a 1 CM PAINLESS, FIRM, RAISED, ROUND "
 "PAPULE with well-defined margins, a NON-PURULENT CLEAN lesion, and BILATERAL inguinal node "
 "swelling.\n\n"
 "WARNING, RUN THE COMPARISON TABLE IN YOUR HEAD:\n\n"
 "Feature: This patient — Chancroid — Syphilis\n"
 "Pain: NONE — present — absent YES\n"
 "Consistency: FIRM — soft — firm YES\n"
 "Base: CLEAN — purulent — clean YES\n"
 "Nodes: BILATERAL — unilateral, suppurative — bilateral, rubbery YES\n"
 "Incubation: ONE MONTH — 3 to 7 days — about 3 weeks YES\n\n"
 "ALL FIVE FEATURES FIT PRIMARY SYPHILIS.\n\n"
 "AND WHY NOT DONOVANOSIS (granuloma inguinale)? That is also painless, but its lesion is a "
 "BEEFY-RED, HIGHLY VASCULAR ULCER that enlarges and spreads and has NO TRUE LYMPHADENOPATHY (its "
 "swelling comes from the subcutaneous lesion itself). It is also very rare in Iran.\n\n"
 "WARNING, THE MOST IMPORTANT CLINICAL POINT IS WHAT THE STEM DOES NOT SAY: THE CHANCRE HEALS BY "
 "ITSELF.\n\n"
 "A syphilitic chancre resolves in 3 TO 6 WEEKS WITH NO TREATMENT AT ALL. The patient believes he "
 "is cured and does not return — and the disease moves into the SECONDARY stage (palmoplantar "
 "rash, condylomata lata) and then LATENCY. THAT IS WHY EVERY GENITAL ULCER NEEDS SYPHILIS "
 "SEROLOGY, even one that is healing.",
 ["شانکروئید دردناک، نرم و چرکی است و غددش یک‌طرفه و چرکی — همه برعکس این بیمار.",
  "پاسخ صحیح — بدون درد، سفت، بستر تمیز، غدد دوطرفه و کمون یک‌ماهه: شانکر سیفلیس.",
  "در LGV زخم اولیه گذراست و تابلو را لنفادنوپاتی بزرگ و دردناک می‌سازد، نه پاپول سفت پایدار.",
  "دونووانوزیس زخم گوشتی و بسیار خون‌ریز می‌سازد و لنفادنوپاتی واقعی ندارد."],
 ["Chancroid is painful, soft and purulent with unilateral suppurative nodes — all the opposite of this patient.",
  "Correct — painless, firm, clean-based, bilateral nodes and a one-month incubation: a syphilitic chancre.",
  "In LGV the primary ulcer is transient and the picture is large painful nodes, not a persistent firm papule.",
  "Donovanosis produces a beefy-red, highly vascular ulcer and has no true lymphadenopathy."],
 "**شانکر: بی‌درد، سفت، تمیز — و خودبه‌خود خوب می‌شود.** همین آخری خطرناک‌ترین بخش است.",
 "A chancre is painless, firm and clean, and it heals by itself; that last point is the dangerous one.",
 [H182, CDC2021])


# =========================================================== book:558
add("book:558", "case", "medium",
 "زخم **بدون تندرنس با بستر تمیز** و غدد **بدون درد** ← سیفلیس ← **پنی‌سیلین بنزاتین**.",
 "A NON-TENDER ulcer with a CLEAN base and PAINLESS nodes is syphilis: BENZATHINE PENICILLIN.",
 ULCER_FA + [
  "**پس از تشخیص سیفلیس، درمانش یک جمله است و استثنا ندارد.**",
  "⚠️ **پنی‌سیلین بنزاتین G، ۲/۴ میلیون واحد، عضلانی، تک‌دوز** — برای سیفلیس اولیه، ثانویه و نهفته‌ی زودرس.",
  "**برای سیفلیس نهفته‌ی دیررس یا با طول نامعلوم: همان دوز، ولی هفته‌ای یک‌بار، سه هفته.**",
  "**برای نوروسیفلیس: پنی‌سیلین کریستالین وریدی، ۱۸ تا ۲۴ میلیون واحد در روز، ۱۰ تا ۱۴ روز.**",
  "⚠️ **و نکته‌ای که سیفلیس را در میان باکتری‌ها استثنایی می‌کند: مقاومت به پنی‌سیلین هرگز گزارش نشده است.**",
  "**پس از هفتاد سال، ترپونما پالیدوم همچنان کاملاً به پنی‌سیلین حساس است.**",
  "**در آلرژی به پنی‌سیلین: داکسی‌سیکلین ۱۰۰ میلی‌گرم دو بار در روز، ۱۴ روز.**",
  "⚠️ **ولی در بارداری، هیچ جایگزینی پذیرفته نیست: باید حساسیت‌زدایی کرد و پنی‌سیلین داد.**",
  "**چون فقط پنی‌سیلین از جفت عبور می‌کند و جنین را درمان می‌کند.**",
  "**و واکنش یاریش-هرکسهایمر را به بیمار هشدار دهید: تب و لرز چند ساعت پس از اولین دوز،**",
  "**که از لیز انبوه ترپونما می‌آید، نه از آلرژی — و خودبه‌خود در ۲۴ ساعت می‌گذرد.**",
 ],
 ULCER_EN + [
  "Once syphilis is diagnosed, its treatment is one sentence with no exceptions.",
  "WARNING: BENZATHINE PENICILLIN G, 2.4 MILLION UNITS, INTRAMUSCULARLY, SINGLE DOSE — for primary, secondary and early latent syphilis.",
  "For late latent or unknown-duration syphilis: the same dose weekly for three weeks.",
  "For neurosyphilis: intravenous crystalline penicillin, 18 to 24 million units daily for 10 to 14 days.",
  "WARNING, AND THE FACT THAT MAKES SYPHILIS UNIQUE AMONG BACTERIA: PENICILLIN RESISTANCE HAS NEVER BEEN REPORTED.",
  "After seventy years, Treponema pallidum remains fully penicillin sensitive.",
  "In penicillin allergy: doxycycline 100 mg twice daily for 14 days.",
  "WARNING, BUT IN PREGNANCY NO ALTERNATIVE IS ACCEPTED: the patient must be desensitised and given penicillin.",
  "Because only penicillin crosses the placenta and treats the fetus.",
  "And warn the patient about the Jarisch-Herxheimer reaction: fever and rigors hours after the first dose,",
  "caused by mass treponemal lysis rather than by allergy, and settling by itself within 24 hours.",
 ],
 "این سؤال دو گام دارد: اول تشخیص، بعد درمان. و گام دوم فقط وقتی درست می‌شود که گام اول "
 "درست باشد.\n\n"
 "**گام یک — تشخیص.** خانم ۲۸ ساله، **۲ هفته پس از تماس مشکوک**، با زخمی که ابتدا پاپول "
 "بوده: **بیضی، نسبتاً عمیق، ۱ سانتی‌متر، بدون تندرنس، با لبه‌های منظم و بستر تمیز**، "
 "همراه با **لنفادنوپاتی دوطرفه بدون تندرنس**.\n\n"
 "⚠️ **«بدون تندرنس» دو بار در صورت سؤال تکرار شده — یک‌بار برای زخم و یک‌بار برای غدد. "
 "این تکرار عمدی است.**\n\n"
 "بدون درد + لبه‌ی منظم + بستر تمیز + غدد دوطرفه بدون درد = **شانکر سیفلیس**.\n\n"
 "**گام دو — درمان.** و اینجا پاسخ بدون استثناست: **پنی‌سیلین بنزاتین G، ۲/۴ میلیون واحد، "
 "عضلانی، تک‌دوز.**\n\n"
 "**چرا سه گزینه‌ی دیگر غلط‌اند؟** هر سه داروی درمان **شانکروئید** هستند — سفتریاکسون، "
 "سیپروفلوکساسین و آزیترومایسین. **طراح سؤال عمداً کل جدول درمان شانکروئید را به‌عنوان "
 "طعمه گذاشته است**، تا کسی که تشخیص را اشتباه گرفته باشد، در گام دوم هم اشتباه کند.\n\n"
 "⚠️ **و یک واقعیت قابل توجه که ارزش دانستن دارد:** ترپونما پالیدوم پس از بیش از هفتاد سال "
 "مصرف گسترده، **هرگز مقاومت به پنی‌سیلین نشان نداده است**. این در میان باکتری‌ها تقریباً "
 "بی‌نظیر است، و به همین دلیل پنی‌سیلین همچنان انتخاب اول و بدون رقیب است.\n\n"
 "**نکته‌ی بارداری که باید حفظ شود:** در بیمار باردار با آلرژی به پنی‌سیلین، **داکسی‌سیکلین "
 "مجاز نیست** (اثر روی جنین) و ماکرولیدها **از جفت به‌خوبی عبور نمی‌کنند و جنین را درمان "
 "نمی‌کنند**. تنها راه درست، **حساسیت‌زدایی و تجویز پنی‌سیلین** است.",
 "This question has two steps: first the diagnosis, then the treatment. The second is only right "
 "if the first is.\n\n"
 "STEP ONE — THE DIAGNOSIS. A 28-year-old woman, TWO WEEKS after a suspicious exposure, with a "
 "lesion that began as a papule: OVAL, fairly deep, 1 CM, NON-TENDER, with REGULAR EDGES and a "
 "CLEAN BASE, together with BILATERAL NON-TENDER lymphadenopathy.\n\n"
 "WARNING: 'NON-TENDER' APPEARS TWICE IN THE STEM — once for the ulcer and once for the nodes. "
 "That repetition is deliberate.\n\n"
 "Painless + regular edge + clean base + painless bilateral nodes = A SYPHILITIC CHANCRE.\n\n"
 "STEP TWO — THE TREATMENT. And here the answer has no exceptions: BENZATHINE PENICILLIN G, "
 "2.4 MILLION UNITS, INTRAMUSCULARLY, AS A SINGLE DOSE.\n\n"
 "WHY ARE THE OTHER THREE WRONG? All three are CHANCROID drugs — ceftriaxone, ciprofloxacin and "
 "azithromycin. THE EXAMINER HAS DELIBERATELY PUT THE ENTIRE CHANCROID TREATMENT TABLE UP AS "
 "BAIT, so that anyone who got the diagnosis wrong will also get the treatment wrong.\n\n"
 "WARNING, AND A REMARKABLE FACT WORTH KNOWING: after more than seventy years of widespread use, "
 "Treponema pallidum HAS NEVER DEVELOPED PENICILLIN RESISTANCE. That is close to unique among "
 "bacteria, and it is why penicillin remains the unchallenged first choice.\n\n"
 "THE PREGNANCY POINT TO MEMORISE: in a pregnant patient with penicillin allergy, DOXYCYCLINE IS "
 "NOT ALLOWED (fetal effects) and macrolides DO NOT CROSS THE PLACENTA WELL AND DO NOT TREAT THE "
 "FETUS. The only correct course is DESENSITISATION AND PENICILLIN.",
 ["سفتریاکسون داروی شانکروئید است؛ اینجا تشخیص سیفلیس است نه شانکروئید.",
  "سیپروفلوکساسین هم از جدول درمان شانکروئید است و روی ترپونما پالیدوم جایی ندارد.",
  "آزیترومایسین نیز درمان شانکروئید است؛ در سیفلیس فقط در شرایط خاص و به‌عنوان جایگزین ضعیف مطرح می‌شود.",
  "پاسخ صحیح — سیفلیس اولیه: پنی‌سیلین بنزاتین ۲/۴ میلیون واحد عضلانی تک‌دوز."],
 ["Ceftriaxone is a chancroid drug; the diagnosis here is syphilis, not chancroid.",
  "Ciprofloxacin is also from the chancroid table and has no role against Treponema pallidum.",
  "Azithromycin is likewise a chancroid treatment; in syphilis it is only a weak alternative in special situations.",
  "Correct — primary syphilis: benzathine penicillin 2.4 million units intramuscularly as a single dose."],
 "**سیفلیس = پنی‌سیلین بنزاتین، بدون استثنا.** مقاومت به پنی‌سیلین هرگز گزارش نشده است.",
 "Syphilis means benzathine penicillin, without exception; penicillin resistance has never been reported.",
 [H182, CDC2021])


# =========================================================== book:561
add("book:561", "case", "medium",
 "**VDRL مثبت در فرد بدون علامت** ← اول **تست ترپونمایی تأییدی (FTA-ABS)**، نه درمان.",
 "A POSITIVE VDRL in an asymptomatic person needs a CONFIRMATORY TREPONEMAL TEST (FTA-ABS) first, not treatment.",
 ULCER_FA + [
  "⚠️ **سرولوژی سیفلیس دو خانواده‌ی کاملاً متفاوت دارد و خلط کردنشان منشأ بیشتر خطاهاست.**",
  "**خانواده‌ی یک — تست‌های غیرترپونمایی: VDRL و RPR.**",
  "**این‌ها آنتی‌بادی ضد کاردیولیپین را می‌سنجند، نه ضد خودِ ترپونما.**",
  "**حساس‌اند و ارزان، پس برای غربالگری خوب‌اند — ولی اختصاصی نیستند.**",
  "⚠️ **و چون تیترشان با فعالیت بیماری بالا و پایین می‌شود، برای پایش درمان به کار می‌روند.**",
  "**خانواده‌ی دو — تست‌های ترپونمایی: FTA-ABS، TPHA، TPPA.**",
  "**این‌ها آنتی‌بادی ضد خودِ ترپونما را می‌سنجند: بسیار اختصاصی، ولی مادام‌العمر مثبت می‌مانند.**",
  "**پس برای پایش درمان بی‌فایده‌اند — یک‌بار مثبت، همیشه مثبت.**",
  "⚠️ **حالا علت‌های مثبت کاذب VDRL را حفظ کنید، چون سؤال دقیقاً همین را می‌سنجد:**",
  "**بارداری، لوپوس و سندرم آنتی‌فسفولیپید، عفونت‌های ویروسی حاد، اعتیاد تزریقی، سن بالا، واکسیناسیون اخیر.**",
  "**نکته‌ی مشترکشان: همه وضعیت‌هایی‌اند که آنتی‌بادی ضد فسفولیپید تولید می‌کنند.**",
  "**پس منطق: تست حساس غربال می‌کند، تست اختصاصی تأیید می‌کند. هرگز بر پایه‌ی غربالگری تنها درمان نکنید.**",
 ],
 ULCER_EN + [
  "WARNING: SYPHILIS SEROLOGY HAS TWO ENTIRELY DIFFERENT FAMILIES, and confusing them causes most errors.",
  "FAMILY ONE — NON-TREPONEMAL TESTS: VDRL and RPR.",
  "They measure antibody against CARDIOLIPIN, not against the treponeme itself.",
  "They are sensitive and cheap, so they are good for screening — but they are not specific.",
  "WARNING, AND BECAUSE THEIR TITRE RISES AND FALLS WITH DISEASE ACTIVITY, THEY ARE USED TO MONITOR TREATMENT.",
  "FAMILY TWO — TREPONEMAL TESTS: FTA-ABS, TPHA, TPPA.",
  "They measure antibody against the treponeme itself: highly specific, but they stay positive for life.",
  "So they are useless for monitoring treatment — once positive, always positive.",
  "WARNING, NOW MEMORISE THE CAUSES OF A FALSE-POSITIVE VDRL, because that is exactly what this question tests:",
  "pregnancy, lupus and antiphospholipid syndrome, acute viral infections, injecting drug use, old age, recent vaccination.",
  "What they share: all are states that generate antiphospholipid antibodies.",
  "So the logic is: the sensitive test screens, the specific test confirms. NEVER TREAT ON A SCREENING TEST ALONE.",
 ],
 "این سؤال یک اصل کلی آزمایشگاهی را در لباس سیفلیس می‌پرسد: **تست غربالگری، تشخیص نیست.**\n\n"
 "**خانم ۲۵ ساله‌ی سالم** که برای **اهدای خون** آمده، و **VDRL مثبت** گزارش شده. "
 "**نه علامتی دارد، نه شرح حال تماس مشکوکی ذکر شده.**\n\n"
 "⚠️ **چرا نباید فوراً پنی‌سیلین داد؟**\n\n"
 "چون **VDRL یک تست غیرترپونمایی** است: آنتی‌بادی ضد **کاردیولیپین** را می‌سنجد، نه "
 "آنتی‌بادی ضد خودِ ترپونما را. این تست **حساس ولی غیراختصاصی** است، و در فهرست بلندی از "
 "وضعیت‌های کاملاً بی‌ربط مثبت کاذب می‌دهد:\n\n"
 "**بارداری · لوپوس و سندرم آنتی‌فسفولیپید · عفونت‌های ویروسی حاد · اعتیاد تزریقی · "
 "سن بالا · واکسیناسیون اخیر · بیماری‌های خودایمن**\n\n"
 "در یک **جمعیت غربالگری با شیوع پایین** — مثل اهداکنندگان خون که همین بیمار است"
 "**ارزش اخباری مثبت پایین است** و احتمال مثبت کاذب واقعاً قابل توجه.\n\n"
 "**پس اقدام درست: تأیید با یک تست ترپونمایی، یعنی FTA-ABS** (یا TPHA / TPPA). این تست‌ها "
 "آنتی‌بادی ضد **خودِ ترپونما پالیدوم** را می‌سنجند و **بسیار اختصاصی**اند.\n\n"
 "⚠️ **و تقسیم کار این دو خانواده را حفظ کنید، چون در سؤال دیگری از همین فصل هم پرسیده شده:**\n\n"
 "غیرترپونمایی (VDRL, RPR): ترپونمایی (FTA-ABS, TPHA)\n"
 "می‌سنجد: آنتی‌بادی ضد کاردیولیپین — آنتی‌بادی ضد ترپونما\n"
 "نقش: **غربالگری** — **تأیید**\n"
 "پس از درمان: تیتر **افت می‌کند** — **مادام‌العمر مثبت**\n"
 "پایش درمان: **بله** — **خیر**\n\n"
 "**و چرا Anti-dsDNA نه؟** درست است که لوپوس یکی از علل مثبت کاذب VDRL است، ولی **گام اول "
 "منطقی، تأیید یا رد خودِ سیفلیس است**، نه جست‌وجوی یکی از ده‌ها علت احتمالی مثبت کاذب. "
 "اگر FTA-ABS منفی شد، آنگاه دنبال علت مثبت کاذب می‌گردیم — و آنجاست که لوپوس مطرح می‌شود.",
 "This question asks a general laboratory principle dressed as syphilis: A SCREENING TEST IS NOT "
 "A DIAGNOSIS.\n\n"
 "A HEALTHY 25-YEAR-OLD WOMAN attending to DONATE BLOOD, with a POSITIVE VDRL. She has NO "
 "SYMPTOMS and no history of suspicious exposure is given.\n\n"
 "WARNING, WHY NOT SIMPLY GIVE PENICILLIN?\n\n"
 "Because the VDRL IS A NON-TREPONEMAL TEST: it measures antibody against CARDIOLIPIN, not "
 "against the treponeme. It is SENSITIVE BUT NON-SPECIFIC, and gives false positives in a long "
 "list of entirely unrelated states:\n\n"
 "PREGNANCY · LUPUS AND ANTIPHOSPHOLIPID SYNDROME · ACUTE VIRAL INFECTIONS · INJECTING DRUG USE · "
 "OLD AGE · RECENT VACCINATION · AUTOIMMUNE DISEASE\n\n"
 "In a LOW-PREVALENCE SCREENING POPULATION — such as blood donors, which is exactly this patient "
 "— THE POSITIVE PREDICTIVE VALUE IS LOW and a false positive is genuinely likely.\n\n"
 "SO THE CORRECT STEP IS CONFIRMATION WITH A TREPONEMAL TEST, THE FTA-ABS (or TPHA/TPPA). These "
 "measure antibody against TREPONEMA PALLIDUM ITSELF and are HIGHLY SPECIFIC.\n\n"
 "WARNING, AND MEMORISE THE DIVISION OF LABOUR, because another question in this chapter asks it:\n\n"
 "Non-treponemal (VDRL, RPR): Treponemal (FTA-ABS, TPHA)\n"
 "Measures: anti-cardiolipin antibody — anti-treponemal antibody\n"
 "Role: SCREENING — CONFIRMATION\n"
 "After treatment: titre FALLS — POSITIVE FOR LIFE\n"
 "Monitoring: YES — NO\n\n"
 "AND WHY NOT ANTI-dsDNA? True, lupus is one cause of a false-positive VDRL, but THE LOGICAL "
 "FIRST STEP IS TO CONFIRM OR EXCLUDE SYPHILIS ITSELF, not to hunt one of dozens of possible "
 "false-positive causes. If the FTA-ABS is negative, THEN we look for the cause — and that is "
 "when lupus comes up.",
 ["درمان بر پایه‌ی یک تست غربالگری غیراختصاصی، پیش از تأیید، نادرست است.",
  "پاسخ صحیح — FTA-ABS یک تست ترپونمایی اختصاصی است و VDRL مثبت را تأیید یا رد می‌کند.",
  "Anti-dsDNA فقط پس از منفی شدن تست ترپونمایی و در جست‌وجوی علت مثبت کاذب مطرح می‌شود.",
  "پیگیری علائم، یک VDRL مثبت را نه تأیید می‌کند نه رد؛ سیفلیس نهفته اصلاً علامت ندارد."],
 ["Treating on a non-specific screening test before confirmation is wrong.",
  "Correct — FTA-ABS is a specific treponemal test and either confirms or refutes the positive VDRL.",
  "Anti-dsDNA only arises after a negative treponemal test, when hunting the cause of a false positive.",
  "Watching for symptoms neither confirms nor excludes a positive VDRL; latent syphilis has no symptoms at all."],
 "**VDRL غربال می‌کند، FTA-ABS تأیید.** و VDRL برای پایش درمان است، نه تشخیص قطعی.",
 "The VDRL screens and the FTA-ABS confirms; the VDRL is for monitoring treatment, not for making the diagnosis.",
 [H182, CDC2021])


# =========================================================== book:544
add("book:544", "recall", "medium",
 "درمان شانکروئید: آزیترومایسین، سفتریاکسون، سیپروفلوکساسین، اریترومایسین — **جنتامایسین نه**.",
 "Chancroid treatment is azithromycin, ceftriaxone, ciprofloxacin or erythromycin — NOT GENTAMICIN.",
 ULCER_FA + [
  "**چهار رژیم مورد تأیید برای شانکروئید را حفظ کنید — سؤال دقیقاً همین فهرست را می‌سنجد:**",
  "**یک — آزیترومایسین ۱ گرم خوراکی، تک‌دوز.**",
  "**دو — سفتریاکسون ۲۵۰ میلی‌گرم عضلانی، تک‌دوز.**",
  "**سه — سیپروفلوکساسین ۵۰۰ میلی‌گرم دو بار در روز، ۳ روز.**",
  "**چهار — اریترومایسین ۵۰۰ میلی‌گرم سه بار در روز، ۷ روز.**",
  "⚠️ **جنتامایسین در این فهرست نیست، و دلیلش مفهومی است نه حفظی.**",
  "**آمینوگلیکوزیدها برای ورود به سلول باکتری به یک سامانه‌ی انتقال وابسته به اکسیژن نیاز دارند،**",
  "**و نفوذشان به بافت‌های سطحی و ترشحات چرکی ضعیف است.**",
  "**ضمناً جنتامایسین خوراکی جذب نمی‌شود و باید تزریقی و چندروزه داده شود، با سمیت کلیه و گوش.**",
  "⚠️ **و یک نکته‌ی عملی: در بیمار HIV مثبت، شانکروئید کندتر پاسخ می‌دهد و ممکن است شکست درمان ببینید.**",
  "**پس در این گروه، رژیم چندروزه بر تک‌دوز ترجیح دارد و پیگیری در ۳ تا ۷ روز لازم است.**",
 ],
 ULCER_EN + [
  "Memorise the four approved chancroid regimens — this question tests exactly that list:",
  "ONE — azithromycin 1 g orally, single dose.",
  "TWO — ceftriaxone 250 mg intramuscularly, single dose.",
  "THREE — ciprofloxacin 500 mg twice daily for 3 days.",
  "FOUR — erythromycin 500 mg three times daily for 7 days.",
  "WARNING: GENTAMICIN IS NOT ON THAT LIST, and the reason is conceptual rather than rote.",
  "Aminoglycosides need an oxygen-dependent transport system to enter the bacterial cell,",
  "and they penetrate superficial tissues and purulent secretions poorly.",
  "Gentamicin is also not absorbed orally and must be given parenterally for days, with renal and cochlear toxicity.",
  "WARNING, AND A PRACTICAL POINT: in an HIV-positive patient chancroid responds more slowly and may fail treatment.",
  "So in that group a multi-day regimen is preferred over a single dose, and review at 3 to 7 days is needed.",
 ],
 "یک سؤال **منفی** است: می‌پرسد کدام درمان **توصیه نمی‌شود**. پس باید فهرست درمان‌های "
 "معتبر را بدانید و عضو غریبه را پیدا کنید.\n\n"
 "**چهار رژیم مورد تأیید برای شانکروئید:**\n\n"
 "دارو: دوز — مدت\n"
 "**آزیترومایسین**: ۱ گرم خوراکی — تک‌دوز\n"
 "**سفتریاکسون**: ۲۵۰ میلی‌گرم عضلانی — تک‌دوز\n"
 "**سیپروفلوکساسین**: ۵۰۰ میلی‌گرم دو بار در روز — ۳ روز\n"
 "**اریترومایسین**: ۵۰۰ میلی‌گرم سه بار در روز — ۷ روز\n\n"
 "سه گزینه‌ی سؤال (آزیترومایسین، سیپروفلوکساسین، سفتریاکسون) **مستقیماً در همین جدول‌اند**. "
 "**جنتامایسین نیست.**\n\n"
 "⚠️ **و چرا نیست؟ این را مفهومی یاد بگیرید تا حفظ نکنید:**\n\n"
 "**۱) مکانیسم ورود.** آمینوگلیکوزیدها برای عبور از غشای باکتری به یک **سامانه‌ی انتقال "
 "وابسته به اکسیژن** نیاز دارند. در محیط **چرکی و کم‌اکسیژن** — که دقیقاً محیط زخم "
 "شانکروئید است — این سامانه ضعیف کار می‌کند.\n\n"
 "**۲) نفوذ بافتی.** نفوذ جنتامایسین به **بافت‌های سطحی و ترشحات** ضعیف است، و شانکروئید "
 "یک عفونت سطحی پوستی-مخاطی است.\n\n"
 "**۳) عملی بودن.** جنتامایسین **خوراکی جذب نمی‌شود**، پس باید تزریقی و چندروزه داده شود، "
 "با پایش سطح خونی و خطر **سمیت کلیوی و گوشی** — در حالی که یک قرص آزیترومایسین همان کار "
 "را می‌کند.\n\n"
 "**نکته‌ی بالینی مهم برای پیگیری:** زخم شانکروئید باید ظرف **۳ تا ۷ روز** شروع به بهبود "
 "کند. اگر نکرد، سه احتمال را بررسی کنید: **تشخیص اشتباه، هم‌زمانی با HIV، یا عدم مصرف "
 "دارو**. ⚠️ **در بیماران HIV مثبت، پاسخ کندتر است و شکست تک‌دوز شایع‌تر** — در این گروه "
 "رژیم ۷ روزه‌ی اریترومایسین ترجیح دارد.",
 "This is a NEGATIVE question: it asks which treatment is NOT recommended. So you must know the "
 "list of valid regimens and spot the stranger.\n\n"
 "THE FOUR APPROVED CHANCROID REGIMENS:\n\n"
 "Drug: Dose — Duration\n"
 "AZITHROMYCIN: 1 g orally — single dose\n"
 "CEFTRIAXONE: 250 mg IM — single dose\n"
 "CIPROFLOXACIN: 500 mg twice daily — 3 days\n"
 "ERYTHROMYCIN: 500 mg three times daily — 7 days\n\n"
 "Three of the options (azithromycin, ciprofloxacin, ceftriaxone) are DIRECTLY ON THAT TABLE. "
 "GENTAMICIN IS NOT.\n\n"
 "WARNING, AND WHY NOT? Learn this conceptually so you need not memorise it:\n\n"
 "1) MECHANISM OF ENTRY. Aminoglycosides need an OXYGEN-DEPENDENT TRANSPORT SYSTEM to cross the "
 "bacterial membrane. In a PURULENT, LOW-OXYGEN environment — precisely the environment of a "
 "chancroid ulcer — that system works poorly.\n\n"
 "2) TISSUE PENETRATION. Gentamicin penetrates SUPERFICIAL TISSUES AND SECRETIONS poorly, and "
 "chancroid is a superficial mucocutaneous infection.\n\n"
 "3) PRACTICALITY. Gentamicin IS NOT ABSORBED ORALLY, so it must be given parenterally for days, "
 "with level monitoring and the risk of NEPHROTOXICITY AND OTOTOXICITY — when a single "
 "azithromycin tablet does the same job.\n\n"
 "AN IMPORTANT FOLLOW-UP POINT: a chancroid ulcer should begin improving within 3 TO 7 DAYS. If "
 "it does not, consider three possibilities: THE WRONG DIAGNOSIS, COEXISTING HIV, OR "
 "NON-ADHERENCE. WARNING: IN HIV-POSITIVE PATIENTS THE RESPONSE IS SLOWER AND SINGLE-DOSE FAILURE "
 "IS COMMONER — in that group the 7-day erythromycin regimen is preferred.",
 ["آزیترومایسین ۱ گرم تک‌دوز یکی از چهار رژیم استاندارد شانکروئید است.",
  "پاسخ صحیح — جنتامایسین در درمان شانکروئید جایی ندارد: نفوذ ضعیف، نیاز به تزریق و سمیت.",
  "سیپروفلوکساسین ۵۰۰ میلی‌گرم دو بار در روز به مدت ۳ روز یک رژیم مورد تأیید است.",
  "سفتریاکسون ۲۵۰ میلی‌گرم عضلانی تک‌دوز نیز از رژیم‌های استاندارد شانکروئید است."],
 ["Azithromycin 1 g single dose is one of the four standard chancroid regimens.",
  "Correct — gentamicin has no place in chancroid: poor penetration, parenteral only, and toxic.",
  "Ciprofloxacin 500 mg twice daily for 3 days is an approved regimen.",
  "Ceftriaxone 250 mg IM single dose is also a standard chancroid regimen."],
 "**شانکروئید: آزیترومایسین، سفتریاکسون، سیپرو، اریترومایسین.** آمینوگلیکوزید در چرک کار نمی‌کند.",
 "Chancroid means azithromycin, ceftriaxone, ciprofloxacin or erythromycin; aminoglycosides do not work in pus.",
 [CDC2021, H35])


# =========================================================== book:546
add("book:546", "case", "medium",
 "اورتریت ← **هر دو ارگانیسم** را بپوشان **و شریک جنسی را هم درمان کن** — هر سه با هم.",
 "Urethritis: cover BOTH organisms AND treat the partner — all three parts together.",
 URE_FA + [
  "**این سؤال چهار گزینه دارد که هر کدام یک تکه از پاسخ کامل‌اند، و فقط یکی هر سه تکه را دارد.**",
  "**تکه‌ی یک — پوشش گونوکوک: سفتریاکسون.**",
  "**تکه‌ی دو — پوشش کلامیدیا: آزیترومایسین (در راهنمای امروز: داکسی‌سیکلین).**",
  "**تکه‌ی سه — درمان شریک جنسی.**",
  "⚠️ **گزینه‌ای که فقط یک آنتی‌بیوتیک دارد، نیمی از عفونت را درمان‌نشده می‌گذارد.**",
  "**گزینه‌ای که شریک را درمان نمی‌کند، بیمار را ظرف چند هفته دوباره آلوده می‌کند.**",
  "**درمان شریک جنسی یک توصیه‌ی اخلاقی نیست؛ بخشی از درمان خودِ بیمار است.**",
  "⚠️ **و توجه کنید که ترشح «سروزی و سوزش خفیف» در این بیمار، تصویر کلامیدیایی است،**",
  "**ولی باز هم گونوکوک را می‌پوشانیم — چون ظاهر ترشح برای رد کردن کافی نیست.**",
  "**همه‌ی شرکای جنسی ۶۰ روز گذشته باید بررسی و درمان شوند.**",
  "**و بیمار و شریکش تا ۷ روز پس از درمان تک‌دوز باید از تماس جنسی پرهیز کنند.**",
 ],
 URE_EN + [
  "This question offers four options, each holding a piece of the full answer, and only one holds all three.",
  "PIECE ONE — cover gonorrhoea: ceftriaxone.",
  "PIECE TWO — cover chlamydia: azithromycin (in today's guideline, doxycycline).",
  "PIECE THREE — treat the sexual partner.",
  "WARNING: AN OPTION WITH ONLY ONE ANTIBIOTIC LEAVES HALF THE INFECTION UNTREATED.",
  "An option that omits the partner leaves the patient to be reinfected within weeks.",
  "TREATING THE PARTNER IS NOT AN ETHICAL EXTRA; IT IS PART OF TREATING THIS PATIENT.",
  "WARNING, AND NOTE THAT 'MILD BURNING WITH SEROUS DISCHARGE' IS A CHLAMYDIAL PICTURE,",
  "yet we still cover gonorrhoea — because the look of the discharge is not enough to exclude it.",
  "All sexual partners from the past 60 days should be evaluated and treated.",
  "And patient and partner must abstain for 7 days after single-dose therapy.",
 ],
 "این سؤال، کل فلسفه‌ی درمان اورتریت را در یک انتخاب چهارگزینه‌ای جمع کرده است.\n\n"
 "**مرد جوان، یک هفته پس از تماس محافظت‌نشده**، با **سوزش خفیف پیشابراهی و ترشحات سروزی**.\n\n"
 "⚠️ **پاسخ کامل سه جزء دارد، و هر گزینه فقط بخشی از آن است:**\n\n"
 "گزینه: گونوکوک — کلامیدیا — شریک\n"
 "سفتریاکسون + درمان شریک: ✔ — ✗ — ✔\n"
 "آزیترومایسین + درمان شریک: ✗ — ✔ — ✔\n"
 "سفتریاکسون + آزیترومایسین: ✔ — ✔ — ✗\n"
 "**هر سه**: ✔ — ✔ — ✔\n\n"
 "**فقط گزینه‌ی آخر کامل است.**\n\n"
 "⚠️ **نکته‌ی ظریف: چرا با اینکه تابلو کلامیدیایی است، باز گونوکوک را می‌پوشانیم؟**\n\n"
 "**سوزش خفیف با ترشح سروزی و کمون یک‌هفته‌ای** واقعاً تصویر کلاسیک **کلامیدیا**ست "
 "(گونوکوک ترشح چرکی فراوان با کمون ۲ تا ۵ روز می‌دهد). ولی **هم‌پوشانی بالینی زیاد است** "
 "و **۲۰ تا ۴۰ درصد بیماران هر دو را دارند**. درمان تجربی بر پایه‌ی ظاهر ترشح بنا "
 "نمی‌شود.\n\n"
 "⚠️ **و مهم‌ترین درس این سؤال: درمان شریک جنسی.**\n\n"
 "این یک توصیه‌ی جانبی نیست. اگر شریک درمان نشود، بیمار **ظرف چند هفته دوباره آلوده "
 "می‌شود** — پدیده‌ای که به آن **«پینگ‌پنگ»** می‌گویند. **همه‌ی شرکای ۶۰ روز گذشته** باید "
 "بررسی و درمان شوند، حتی اگر بدون علامت باشند (که در زنان با کلامیدیا **بسیار شایع** است "
 "و می‌تواند به **بیماری التهابی لگن و ناباروری** ختم شود).\n\n"
 "**به‌روزرسانی راهنمای CDC ۲۰۲۱:** امروز رژیم **سفتریاکسون ۵۰۰ میلی‌گرم تک‌دوز + "
 "داکسی‌سیکلین ۱۰۰ میلی‌گرم دو بار در روز به مدت ۷ روز** است. اصلِ «هر دو را بپوشان و شریک "
 "را درمان کن» **دقیقاً همان است**؛ فقط دوز و داروی دوم عوض شده‌اند.",
 "This question packs the whole philosophy of urethritis treatment into one multiple choice.\n\n"
 "A YOUNG MAN, ONE WEEK AFTER UNPROTECTED INTERCOURSE, with MILD URETHRAL BURNING AND SEROUS "
 "DISCHARGE.\n\n"
 "WARNING, THE COMPLETE ANSWER HAS THREE PARTS, and each option holds only some of them:\n\n"
 "Option: Gonorrhoea — Chlamydia — Partner\n"
 "Ceftriaxone + partner: YES — NO — YES\n"
 "Azithromycin + partner: NO — YES — YES\n"
 "Ceftriaxone + azithromycin: YES — YES — NO\n"
 "ALL THREE: YES — YES — YES\n\n"
 "ONLY THE LAST OPTION IS COMPLETE.\n\n"
 "WARNING, A SUBTLE POINT: why cover gonorrhoea when the picture is chlamydial?\n\n"
 "MILD BURNING WITH SEROUS DISCHARGE AND A ONE-WEEK INCUBATION really is the classic CHLAMYDIAL "
 "picture (gonorrhoea gives copious purulent discharge at 2 to 5 days). But THE CLINICAL OVERLAP "
 "IS LARGE and 20 TO 40 PER CENT OF PATIENTS HAVE BOTH. Empirical treatment is not built on the "
 "appearance of the discharge.\n\n"
 "WARNING, AND THE MOST IMPORTANT LESSON HERE: TREATING THE PARTNER.\n\n"
 "This is not a side recommendation. If the partner is untreated the patient IS REINFECTED WITHIN "
 "WEEKS — the 'PING-PONG' phenomenon. ALL PARTNERS FROM THE PAST 60 DAYS should be evaluated and "
 "treated, even when asymptomatic — which in women with chlamydia is VERY COMMON and can end in "
 "PELVIC INFLAMMATORY DISEASE AND INFERTILITY.\n\n"
 "CDC 2021 UPDATE: today the regimen is CEFTRIAXONE 500 MG SINGLE DOSE PLUS DOXYCYCLINE 100 MG "
 "TWICE DAILY FOR 7 DAYS. The principle 'cover both and treat the partner' is EXACTLY THE SAME; "
 "only the dose and the second drug have changed.",
 ["سفتریاکسون به‌تنهایی کلامیدیا را پوشش نمی‌دهد و نیمی از عفونت درمان‌نشده می‌ماند.",
  "آزیترومایسین به‌تنهایی گونوکوک را به‌طور قابل اتکا پوشش نمی‌دهد؛ مقاومت ماکرولیدی بالاست.",
  "پوشش هر دو ارگانیسم درست است ولی بدون درمان شریک، بیمار ظرف چند هفته دوباره آلوده می‌شود.",
  "پاسخ صحیح — پوشش گونوکوک، پوشش کلامیدیا، و درمان شریک جنسی: هر سه جزء لازم‌اند."],
 ["Ceftriaxone alone does not cover chlamydia and leaves half the infection untreated.",
  "Azithromycin alone does not reliably cover gonorrhoea; macrolide resistance is high.",
  "Covering both organisms is right, but without treating the partner the patient is reinfected within weeks.",
  "Correct — cover gonorrhoea, cover chlamydia, and treat the partner: all three are required."],
 "**هر دو ارگانیسم + شریک جنسی.** درمان شریک، بخشی از درمان بیمار است، نه یک توصیه‌ی اضافی.",
 "Both organisms plus the partner; treating the partner is part of treating the patient, not an optional extra.",
 [CDC2021, H35])


# =========================================================== book:549
add("book:549", "case", "medium",
 "اورتریت با **ارگانیسم دیده‌نشده** ← این کلامیدیا را رد نمی‌کند ← باز هم **درمان دوگانه**.",
 "Urethritis with NO ORGANISM SEEN does not exclude chlamydia: still give DUAL THERAPY.",
 URE_FA + [
  "⚠️ **کلید این سؤال یک سوءتفاهم رایج است: «ارگانیسمی دیده نشد» یعنی چه؟**",
  "**یعنی گونوکوک دیده نشد. درباره‌ی کلامیدیا هیچ چیزی نمی‌گوید.**",
  "**چون کلامیدیا یک باکتری داخل‌سلولی اجباری است و در رنگ‌آمیزی گرم اصلاً دیده نمی‌شود.**",
  "**تشخیصش فقط با NAAT (آزمون تکثیر اسید نوکلئیک) ممکن است، نه با میکروسکوپ.**",
  "⚠️ **پس اسمیر منفی، تشخیص را به «اورتریت غیرگونوکوکی» می‌برد، نه به «اورتریتی نیست».**",
  "**و شایع‌ترین علت اورتریت غیرگونوکوکی، دقیقاً کلامیدیا تراکوماتیس است.**",
  "**سایر علل: مایکوپلاسما ژنیتالیوم، اوره‌آپلاسما، تریکوموناس، و گاهی آدنوویروس و HSV.**",
  "**ولی آیا می‌توان گونوکوک را کنار گذاشت چون دیده نشد؟ در درمان تجربی، خیر.**",
  "⚠️ **حساسیت رنگ‌آمیزی گرم در مردان علامت‌دار حدود ۹۵ درصد است — بالا، ولی نه کامل.**",
  "**و هزینه‌ی از دست دادن یک گونوکوک درمان‌نشده بسیار بیشتر از هزینه‌ی یک آمپول اضافه است.**",
  "**پس پاسخ همان درمان دوگانه است، دقیقاً مثل حالتی که دیپلوکوک دیده شده بود.**",
 ],
 URE_EN + [
  "WARNING: THE KEY HERE IS A COMMON MISUNDERSTANDING — what does 'no organism was seen' mean?",
  "It means NO GONOCOCCUS was seen. It says nothing whatever about chlamydia.",
  "Because chlamydia is an obligate intracellular organism and is INVISIBLE on a gram stain.",
  "It can only be diagnosed by NAAT (nucleic acid amplification), not by microscopy.",
  "WARNING: SO A NEGATIVE SMEAR MOVES THE DIAGNOSIS TO 'NON-GONOCOCCAL URETHRITIS', NOT TO 'NO URETHRITIS'.",
  "And the commonest cause of non-gonococcal urethritis is precisely Chlamydia trachomatis.",
  "Other causes: Mycoplasma genitalium, Ureaplasma, Trichomonas, and occasionally adenovirus and HSV.",
  "But can gonorrhoea be dropped because it was not seen? In empirical therapy, no.",
  "WARNING: THE GRAM STAIN IS ABOUT 95 PER CENT SENSITIVE IN SYMPTOMATIC MEN — high, but not complete.",
  "And the cost of missing an untreated gonococcus far exceeds the cost of one extra injection.",
  "So the answer is the same dual therapy as if diplococci had been seen.",
 ],
 "این سؤال یک سوءتفاهم بسیار شایع را هدف گرفته است، و دانشجویانی که آن را نگرفته باشند، "
 "با اطمینان گزینه‌ی غلط را انتخاب می‌کنند.\n\n"
 "**مرد جوان، یک هفته پس از تماس محافظت‌نشده، با علائم اورتریت.** در بررسی ترشحات، "
 "**ارگانیسمی دیده نمی‌شود**.\n\n"
 "⚠️ **سؤال کلیدی: «ارگانیسمی دیده نشد» دقیقاً چه چیزی را رد می‌کند؟**\n\n"
 "**فقط و فقط گونوکوک را.** و حتی آن را هم به‌طور کامل رد نمی‌کند.\n\n"
 "**چرا؟** چون در رنگ‌آمیزی گرم، آنچه می‌بینیم **دیپلوکوک‌های گرم‌منفی داخل سلولی** است"
 "یعنی **نایسریا گونوره‌آ**. اما **کلامیدیا تراکوماتیس یک باکتری داخل‌سلولی اجباری است "
 "که دیواره‌ی سلولی معمولی ندارد و در رنگ‌آمیزی گرم اصلاً دیده نمی‌شود.** تشخیصش فقط با "
 "**NAAT** ممکن است.\n\n"
 "**پس اسمیر منفی، تشخیص را به «اورتریت غیرگونوکوکی» (NGU) می‌برد** — و **شایع‌ترین علت "
 "NGU دقیقاً کلامیدیاست**. یعنی اسمیر منفی، احتمال کلامیدیا را **بالاتر** می‌برد، نه "
 "پایین‌تر!\n\n"
 "⚠️ **و آیا می‌توان گونوکوک را کنار گذاشت؟ در درمان تجربی، خیر.**\n\n"
 "حساسیت رنگ‌آمیزی گرم در **مردان علامت‌دار** حدود **۹۵ درصد** است — بالا، ولی نه صد "
 "درصد. **هزینه‌ی از قلم انداختن یک گونوکوک درمان‌نشده** (اپیدیدیمیت، اورتریت مقاوم، "
 "انتقال به شریک، و در زنان PID و ناباروری) **بسیار بیشتر از هزینه‌ی یک آمپول اضافه "
 "است.**\n\n"
 "**پس پاسخ: تک‌دوز سفتریاکسون + تک‌دوز آزیترومایسین یک گرم** — یعنی **دقیقاً همان درمان "
 "دوگانه‌ای که اگر دیپلوکوک دیده بودیم می‌دادیم.**\n\n"
 "**به‌روزرسانی امروز:** با راهنمای CDC ۲۰۲۱، اورتریت غیرگونوکوکیِ ثابت‌شده با "
 "**داکسی‌سیکلین ۷ روزه** درمان می‌شود؛ ولی وقتی گونوکوک رد نشده، همچنان "
 "**سفتریاکسون + داکسی‌سیکلین** داده می‌شود.",
 "This question targets a very common misunderstanding, and students who have not grasped it pick "
 "the wrong option with confidence.\n\n"
 "A YOUNG MAN, ONE WEEK AFTER UNPROTECTED INTERCOURSE, with urethritis. On examination of the "
 "discharge, NO ORGANISM IS SEEN.\n\n"
 "WARNING, THE KEY QUESTION: what exactly does 'no organism was seen' exclude?\n\n"
 "ONLY THE GONOCOCCUS. And not even that completely.\n\n"
 "WHY? Because what a gram stain shows is INTRACELLULAR GRAM-NEGATIVE DIPLOCOCCI — that is, "
 "Neisseria gonorrhoeae. But CHLAMYDIA TRACHOMATIS IS AN OBLIGATE INTRACELLULAR ORGANISM WITHOUT "
 "A CONVENTIONAL CELL WALL AND IS SIMPLY NOT VISIBLE ON A GRAM STAIN. It can only be diagnosed by "
 "NAAT.\n\n"
 "SO A NEGATIVE SMEAR MOVES THE DIAGNOSIS TO NON-GONOCOCCAL URETHRITIS (NGU) — and THE COMMONEST "
 "CAUSE OF NGU IS PRECISELY CHLAMYDIA. In other words, a negative smear makes chlamydia MORE "
 "likely, not less.\n\n"
 "WARNING, AND CAN GONORRHOEA BE DROPPED? In empirical therapy, no.\n\n"
 "The gram stain is about 95 PER CENT sensitive in SYMPTOMATIC MEN — high, but not total. THE "
 "COST OF MISSING AN UNTREATED GONOCOCCUS (epididymitis, persistent urethritis, transmission to "
 "the partner, and in women PID and infertility) FAR EXCEEDS THE COST OF ONE EXTRA INJECTION.\n\n"
 "SO THE ANSWER IS: SINGLE-DOSE CEFTRIAXONE PLUS SINGLE-DOSE AZITHROMYCIN 1 G — exactly the same "
 "dual therapy we would have given had diplococci been seen.\n\n"
 "TODAY'S UPDATE: under CDC 2021, PROVEN non-gonococcal urethritis is treated with 7 DAYS OF "
 "DOXYCYCLINE; but when gonorrhoea has not been excluded, CEFTRIAXONE PLUS DOXYCYCLINE is still "
 "given.",
 ["سفتریاکسون تنها، کلامیدیا را پوشش نمی‌دهد — و اسمیر منفی احتمال کلامیدیا را بیشتر می‌کند نه کمتر.",
  "آزیترومایسین تنها، گونوکوک را به‌طور قابل اتکا پوشش نمی‌دهد و حساسیت اسمیر ۱۰۰ درصد نیست.",
  "پاسخ صحیح — اسمیر منفی کلامیدیا را رد نمی‌کند، پس درمان دوگانه‌ی تجربی همچنان لازم است.",
  "سفیکسیم ۷ روزه رژیم استانداردی نیست؛ درمان گونوکوک تک‌دوز است، نه یک هفته."],
 ["Ceftriaxone alone does not cover chlamydia — and a negative smear makes chlamydia more likely, not less.",
  "Azithromycin alone does not reliably cover gonorrhoea, and the smear is not 100 per cent sensitive.",
  "Correct — a negative smear does not exclude chlamydia, so empirical dual therapy is still required.",
  "Seven days of cefixime is not a standard regimen; gonorrhoea treatment is single-dose, not a week."],
 "**«ارگانیسمی دیده نشد» یعنی گونوکوک دیده نشد.** کلامیدیا در رنگ‌آمیزی گرم اصلاً دیده نمی‌شود.",
 "'No organism seen' means no gonococcus seen; chlamydia is invisible on a gram stain.",
 [CDC2021, H35])


# =========================================================== book:553
add("book:553", "case", "easy",
 "**دیپلوکوک گرم‌منفی داخل سلولی** = گونوکوک ← سفتریاکسون، **به‌علاوه‌ی** پوشش کلامیدیا.",
 "INTRACELLULAR GRAM-NEGATIVE DIPLOCOCCI mean gonorrhoea: ceftriaxone PLUS chlamydial cover.",
 URE_FA + [
  "**اینجا برخلاف سؤال قبل، ارگانیسم دیده شده — و باز هم پاسخ درمان دوگانه است.**",
  "⚠️ **همین تقارن، درس اصلی این بلوک است: دیدن یا ندیدن گونوکوک، درمان تجربی را عوض نمی‌کند.**",
  "**اگر دیده شد: گونوکوک قطعی است، ولی کلامیدیا هنوز رد نشده.**",
  "**اگر دیده نشد: کلامیدیا محتمل‌تر است، ولی گونوکوک هنوز کاملاً رد نشده.**",
  "**در هر دو حالت، هر دو را می‌پوشانیم — مگر آنکه NAAT کلامیدیا منفی شده باشد.**",
  "**دیپلوکوک گرم‌منفی داخل سلولی در مرد علامت‌دار، حساسیت حدود ۹۵ و ویژگی بالای ۹۹ درصد دارد.**",
  "⚠️ **کلمه‌ی «داخل سلولی» مهم است: باید داخل نوتروفیل باشد، نه کنار آن.**",
  "**دیپلوکوک‌های خارج سلولی می‌توانند نایسریاهای غیربیماری‌زای فلور باشند.**",
  "**در زنان، همین اسمیر حساسیت بسیار پایین‌تری دارد (حدود ۵۰ درصد) و قابل اتکا نیست.**",
  "**پس در زنان همیشه NAAT لازم است، حتی با اسمیر منفی.**",
  "**و اریترومایسین تک‌دوز خوراکی هیچ جایگاهی در این درمان ندارد — نه برای گونوکوک، نه برای کلامیدیا.**",
 ],
 URE_EN + [
  "Here, unlike the previous question, the organism WAS seen — and the answer is still dual therapy.",
  "WARNING: THAT SYMMETRY IS THE MAIN LESSON OF THIS BLOCK — seeing or not seeing the gonococcus does not change empirical treatment.",
  "If seen: gonorrhoea is certain, but chlamydia is still not excluded.",
  "If not seen: chlamydia is likelier, but gonorrhoea is still not fully excluded.",
  "Either way we cover both — unless a chlamydial NAAT has come back negative.",
  "Intracellular gram-negative diplococci in a symptomatic man are about 95 per cent sensitive and over 99 per cent specific.",
  "WARNING, THE WORD 'INTRACELLULAR' MATTERS: they must be inside a neutrophil, not beside it.",
  "Extracellular diplococci may be non-pathogenic commensal Neisseria species.",
  "In women the same smear is far less sensitive (about 50 per cent) and is not reliable.",
  "So in women a NAAT is always needed, even with a negative smear.",
  "And a single oral dose of erythromycin has no place here — neither for gonorrhoea nor for chlamydia.",
 ],
 "این سؤال را باید **کنار** سؤال «ارگانیسمی دیده نشد» خواند. تقارن این دو، کل درس را "
 "می‌سازد.\n\n"
 "**مرد جوان، یک هفته پس از تماس، با ترشح چرکی.** رنگ‌آمیزی گرم: **دیپلوکوک گرم‌منفی داخل "
 "سلولی**.\n\n"
 "⚠️ **گام یک — این یافته چقدر قطعی است؟**\n\n"
 "**دیپلوکوک گرم‌منفی داخل سلولی در مرد علامت‌دار، عملاً تشخیصی است:** حساسیت حدود "
 "**۹۵ درصد** و ویژگی **بالای ۹۹ درصد**. پس **گونوکوک قطعی است**.\n\n"
 "**نکته‌ی ظریف:** کلمه‌ی **«داخل سلولی»** حیاتی است. دیپلوکوک باید **داخل سیتوپلاسم "
 "نوتروفیل** دیده شود. دیپلوکوک‌های **خارج سلولی** می‌توانند نایسریاهای غیربیماری‌زای فلور "
 "طبیعی باشند.\n\n"
 "⚠️ **گام دو — پس چرا سفتریاکسون به‌تنهایی کافی نیست؟**\n\n"
 "چون **دیدن گونوکوک، کلامیدیا را رد نمی‌کند.** رنگ‌آمیزی گرم اصلاً کلامیدیا را نشان "
 "نمی‌دهد (داخل‌سلولی اجباری، بدون دیواره‌ی معمولی). و **۲۰ تا ۴۰ درصد مردان مبتلا به "
 "گونوکوک، هم‌زمان کلامیدیا هم دارند.**\n\n"
 "**اگر فقط سفتریاکسون بدهیم، دقیقاً همان سناریوی «اورتریت پس از گونوکوک» ساخته می‌شود:** "
 "علائم بهبود می‌یابد، و **یک هفته بعد ترشح مخاطی برمی‌گردد بدون هیچ تماس جدیدی** — چون "
 "کلامیدیای درمان‌نشده حالا خودش را نشان می‌دهد. **دو سؤال دیگر در همین فصل دقیقاً همین "
 "سناریو را می‌پرسند.**\n\n"
 "**پس: سفتریاکسون تک‌دوز عضلانی + داکسی‌سیکلین.** ✅\n\n"
 "⚠️ **و اینجا نکته‌ی جالبی هست: گزینه‌ی درست این سؤال قدیمی، دقیقاً همان چیزی است که "
 "راهنمای CDC ۲۰۲۱ امروز توصیه می‌کند** — سفتریاکسون به‌علاوه‌ی **داکسی‌سیکلین**، نه "
 "آزیترومایسین. (تنها تفاوت، دوز سفتریاکسون است: امروز ۵۰۰ میلی‌گرم به‌جای ۲۵۰.)\n\n"
 "**چرا سیپروفلوکساسین نه؟** مقاومت گونوکوک به فلوروکینولون‌ها چنان گسترده شد که "
 "**CDC از سال ۲۰۰۷ آن‌ها را کاملاً از درمان گونوکوک کنار گذاشت.**",
 "Read this question BESIDE the 'no organism seen' one. The symmetry between them is the whole "
 "lesson.\n\n"
 "A YOUNG MAN, ONE WEEK AFTER INTERCOURSE, with purulent discharge. Gram stain: INTRACELLULAR "
 "GRAM-NEGATIVE DIPLOCOCCI.\n\n"
 "WARNING, STEP ONE — how certain is that finding?\n\n"
 "INTRACELLULAR GRAM-NEGATIVE DIPLOCOCCI IN A SYMPTOMATIC MAN ARE EFFECTIVELY DIAGNOSTIC: about "
 "95 PER CENT sensitive and OVER 99 PER CENT specific. So GONORRHOEA IS CERTAIN.\n\n"
 "A SUBTLE POINT: the word INTRACELLULAR is critical. The diplococci must be seen INSIDE "
 "NEUTROPHIL CYTOPLASM. EXTRACELLULAR diplococci may be non-pathogenic commensal Neisseria.\n\n"
 "WARNING, STEP TWO — so why is ceftriaxone alone not enough?\n\n"
 "Because SEEING THE GONOCOCCUS DOES NOT EXCLUDE CHLAMYDIA. The gram stain cannot show chlamydia "
 "at all (obligate intracellular, no conventional wall). And 20 TO 40 PER CENT OF MEN WITH "
 "GONORRHOEA HAVE CHLAMYDIA TOO.\n\n"
 "GIVE CEFTRIAXONE ALONE AND YOU CREATE EXACTLY THE 'POST-GONOCOCCAL URETHRITIS' SCENARIO: the "
 "symptoms settle, and A WEEK LATER MUCOID DISCHARGE RETURNS WITH NO NEW EXPOSURE — because the "
 "untreated chlamydia is now declaring itself. TWO OTHER QUESTIONS IN THIS CHAPTER ASK PRECISELY "
 "THAT SCENARIO.\n\n"
 "SO: SINGLE-DOSE INTRAMUSCULAR CEFTRIAXONE PLUS DOXYCYCLINE.\n\n"
 "WARNING, AND HERE IS SOMETHING INTERESTING: the correct option in this old question is EXACTLY "
 "WHAT THE CDC 2021 GUIDELINE RECOMMENDS TODAY — ceftriaxone plus DOXYCYCLINE, not azithromycin. "
 "(The only difference is the ceftriaxone dose: 500 mg today instead of 250.)\n\n"
 "WHY NOT CIPROFLOXACIN? Gonococcal fluoroquinolone resistance became so widespread that THE CDC "
 "REMOVED THEM FROM GONORRHOEA TREATMENT ENTIRELY IN 2007.",
 ["پاسخ صحیح — سفتریاکسون گونوکوک را و داکسی‌سیکلین کلامیدیای هم‌زمان را پوشش می‌دهد.",
  "سفتریاکسون تنها، کلامیدیای هم‌زمان را درمان‌نشده می‌گذارد و اورتریت پس از گونوکوک می‌سازد.",
  "مقاومت گونوکوک به فلوروکینولون‌ها چنان بالاست که از سال ۲۰۰۷ از درمان کنار گذاشته شده‌اند.",
  "اریترومایسین تک‌دوز خوراکی نه گونوکوک را درمان می‌کند و نه رژیم استاندارد کلامیدیاست."],
 ["Correct — ceftriaxone covers the gonococcus and doxycycline covers coexisting chlamydia.",
  "Ceftriaxone alone leaves coexisting chlamydia untreated and produces post-gonococcal urethritis.",
  "Gonococcal fluoroquinolone resistance is so high that they were withdrawn from treatment in 2007.",
  "A single oral dose of erythromycin neither treats gonorrhoea nor is a standard chlamydia regimen."],
 "**دیدن گونوکوک، کلامیدیا را رد نمی‌کند.** رنگ‌آمیزی گرم فقط نیمی از عفونت را می‌بیند.",
 "Seeing the gonococcus does not exclude chlamydia; the gram stain sees only half the infection.",
 [CDC2021, H35])


# =========================================================== book:545
add("book:545", "case", "hard",
 "بازگشت علائم **یک هفته بعد بدون تماس جدید** پس از سفتریاکسون ← **کلامیدیای درمان‌نشده** ← آزیترومایسین.",
 "Symptoms returning a week after ceftriaxone WITH NO NEW EXPOSURE means UNTREATED CHLAMYDIA: azithromycin.",
 URE_FA + [
  "⚠️ **این سناریو نام دارد و باید با نامش بشناسیدش: اورتریت پس از گونوکوک.**",
  "**سه جزء تعریفش را حفظ کنید، چون هر سه در صورت سؤال آمده‌اند:**",
  "**یک — درمان گونوکوک انجام شده و علائم اولیه بهبود یافته.**",
  "**دو — علائم پس از حدود یک هفته برمی‌گردند، ولی خفیف‌تر و مخاطی، نه چرکی.**",
  "**سه — و مهم‌ترین جزء: هیچ تماس جنسی جدیدی در این فاصله نبوده است.**",
  "⚠️ **جزء سوم است که «عفونت مجدد» را حذف می‌کند و پاسخ را قطعی می‌سازد.**",
  "**علتش ساده است: سفتریاکسون گونوکوک را کشت، ولی کلامیدیا را دست‌نخورده گذاشت.**",
  "**و چون کمون کلامیدیا بلندتر است (۱ تا ۳ هفته)، درست همان موقع خودش را نشان می‌دهد.**",
  "**پس اقدام درست: پوشش دادن همان چیزی که جا افتاده بود — کلامیدیا.**",
  "⚠️ **تکرار سفتریاکسون بی‌فایده است: گونوکوک دیگر آنجا نیست.**",
  "**و اگر پس از پوشش کلامیدیا هم علائم ماند، به مایکوپلاسما ژنیتالیوم فکر کنید.**",
  "**درمان آن: داکسی‌سیکلین ۷ روز و سپس موکسی‌فلوکساسین ۴۰۰ میلی‌گرم روزانه ۷ روز.**",
 ],
 URE_EN + [
  "WARNING: THIS SCENARIO HAS A NAME AND YOU SHOULD KNOW IT BY NAME — POST-GONOCOCCAL URETHRITIS.",
  "Memorise its three defining parts, because all three appear in the stem:",
  "ONE — gonorrhoea was treated and the initial symptoms resolved.",
  "TWO — symptoms return after about a week, but milder and MUCOID rather than purulent.",
  "THREE — and the crucial part: THERE HAS BEEN NO NEW SEXUAL CONTACT IN BETWEEN.",
  "WARNING: IT IS THE THIRD PART THAT ELIMINATES REINFECTION AND MAKES THE ANSWER CERTAIN.",
  "The reason is simple: ceftriaxone killed the gonococcus and left the chlamydia untouched.",
  "And because chlamydia incubates longer (1 to 3 weeks), it declares itself at exactly that moment.",
  "So the correct step is to cover what was missed — the chlamydia.",
  "WARNING: REPEATING THE CEFTRIAXONE IS POINTLESS — the gonococcus is no longer there.",
  "And if symptoms persist even after chlamydial cover, think of Mycoplasma genitalium.",
  "Its treatment: doxycycline for 7 days, then moxifloxacin 400 mg daily for 7 days.",
 ],
 "این سناریو در فصل حاضر **سه بار** با عبارت‌های مختلف پرسیده شده. اگر یک‌بار آن را عمیق "
 "بفهمید، هر سه را می‌زنید.\n\n"
 "**آقای ۲۵ ساله** با سوزش و ترشح مجرا پس از تماس جنسی. **یک آمپول سفتریاکسون** می‌گیرد و "
 "**بهبود می‌یابد**. ولی **یک هفته بعد دوباره علائم اورتریت** پیدا می‌کند — و "
 "**در این مدت هیچ تماس جنسی جدیدی نداشته است**.\n\n"
 "⚠️ **آن جمله‌ی آخر، کلید کل سؤال است.**\n\n"
 "بدون آن، **عفونت مجدد** یک احتمال جدی بود. با آن، عفونت مجدد **حذف می‌شود** و فقط یک "
 "توضیح می‌ماند: **چیزی از همان ابتدا درمان نشده بود.**\n\n"
 "**و آن چیز، کلامیدیاست.**\n\n"
 "**منطق زمانی را ببینید — این زیباترین بخش سؤال است:**\n\n"
 "گونوکوک: کلامیدیا\n"
 "کمون: ۲ تا ۵ روز — **۱ تا ۳ هفته**\n"
 "ترشح: چرکی و فراوان — **مخاطی و کم**\n"
 "پاسخ به سفتریاکسون: **بله** — **خیر**\n\n"
 "سفتریاکسون گونوکوک را کشت و علائم چرکی خوابید. ولی **کلامیدیا دست‌نخورده ماند**، و چون "
 "**کمون بلندتری دارد**، درست حدود یک هفته بعد **علائم خفیف‌تر و مخاطی** خودش را نشان "
 "می‌دهد.\n\n"
 "**این پدیده نام دارد: اورتریت پس از گونوکوک (post-gonococcal urethritis).**\n\n"
 "**پس اقدام درست: پوشش دادن کلامیدیا — آزیترومایسین ۱ گرم خوراکی.** ✅\n\n"
 "⚠️ **چرا تکرار سفتریاکسون غلط است؟** چون **گونوکوک دیگر آنجا نیست**. دوز اول کارش را "
 "کرد. مشکل، ارگانیسمی است که سفتریاکسون هرگز روی آن اثر نداشت.\n\n"
 "**و چرا گزینه‌ی «سفتریاکسون + آزیترومایسین» غلط است؟** چون نیمه‌ی سفتریاکسونش "
 "**اضافی و بی‌مورد** است. سؤال یک انتخاب هدفمند می‌خواهد، نه پاشیدن آنتی‌بیوتیک.\n\n"
 "**نکته‌ی تکمیلی مهم:** اگر پس از پوشش کلامیدیا هم علائم ادامه یافت، به "
 "**مایکوپلاسما ژنیتالیوم** فکر کنید — علت مهم اورتریت مقاوم و راجعه، که با "
 "**داکسی‌سیکلین سپس موکسی‌فلوکساسین** درمان می‌شود.",
 "This scenario is asked THREE TIMES in this chapter in different wordings. Understand it deeply "
 "once and you answer all three.\n\n"
 "A 25-YEAR-OLD MAN with urethral burning and discharge after intercourse. He receives ONE "
 "CEFTRIAXONE INJECTION and IMPROVES. But A WEEK LATER THE URETHRITIS RETURNS — and HE HAS HAD NO "
 "NEW SEXUAL CONTACT IN THE MEANTIME.\n\n"
 "WARNING: THAT LAST SENTENCE IS THE KEY TO THE WHOLE QUESTION.\n\n"
 "Without it, REINFECTION would be a serious possibility. With it, reinfection IS ELIMINATED and "
 "only one explanation remains: SOMETHING WAS NEVER TREATED IN THE FIRST PLACE.\n\n"
 "AND THAT SOMETHING IS CHLAMYDIA.\n\n"
 "LOOK AT THE TIMING LOGIC — this is the elegant part of the question:\n\n"
 "Gonorrhoea: Chlamydia\n"
 "Incubation: 2 to 5 days — 1 TO 3 WEEKS\n"
 "Discharge: copious, purulent — SCANT, MUCOID\n"
 "Responds to ceftriaxone: YES — NO\n\n"
 "Ceftriaxone killed the gonococcus and the purulent symptoms settled. But THE CHLAMYDIA WAS "
 "UNTOUCHED, and because it INCUBATES LONGER it declares itself about a week later with MILDER, "
 "MUCOID symptoms.\n\n"
 "THIS PHENOMENON HAS A NAME: POST-GONOCOCCAL URETHRITIS.\n\n"
 "SO THE CORRECT STEP IS TO COVER THE CHLAMYDIA — AZITHROMYCIN 1 G ORALLY.\n\n"
 "WARNING, WHY IS REPEATING CEFTRIAXONE WRONG? Because THE GONOCOCCUS IS NO LONGER THERE. The "
 "first dose did its job. The problem is an organism ceftriaxone never touched.\n\n"
 "AND WHY IS 'CEFTRIAXONE PLUS AZITHROMYCIN' WRONG? Because its ceftriaxone half is REDUNDANT. "
 "The question wants a targeted choice, not a scattering of antibiotics.\n\n"
 "AN IMPORTANT ADDITION: if symptoms persist even after chlamydial cover, think of MYCOPLASMA "
 "GENITALIUM — a major cause of persistent and recurrent urethritis, treated with DOXYCYCLINE "
 "FOLLOWED BY MOXIFLOXACIN.",
 ["تکرار سفتریاکسون بی‌فایده است: گونوکوک با دوز اول درمان شده و علائم چرکی خوابیده بود.",
  "پاسخ صحیح — علائم بازگشته از کلامیدیای درمان‌نشده است و آزیترومایسین دقیقاً همان را پوشش می‌دهد.",
  "نیمه‌ی سفتریاکسون این گزینه اضافی است؛ گونوکوک دیگر وجود ندارد و نیازی به تکرارش نیست.",
  "«هیچ‌کدام» نادرست است: توضیح روشنی وجود دارد و درمان مؤثر و مشخصی هم در دسترس است."],
 ["Repeating ceftriaxone is pointless: the first dose cured the gonorrhoea and the purulent symptoms settled.",
  "Correct — the returning symptoms are untreated chlamydia, and azithromycin covers exactly that.",
  "The ceftriaxone half of this option is redundant; the gonococcus is gone and need not be re-treated.",
  "'None of the above' is wrong: there is a clear explanation and a specific effective treatment."],
 "**بازگشت علائم بدون تماس جدید = چیزی از اول درمان نشده بود.** آن چیز کلامیدیاست.",
 "Symptoms returning with no new exposure mean something was never treated; that something is chlamydia.",
 [CDC2021, H35])


# =========================================================== book:552
add("book:552", "case", "medium",
 "اپیدیدیمیت در جوان فعال جنسی ← **سفتریاکسون تک‌دوز + داکسی‌سیکلین ۱۰ روز**.",
 "Epididymitis in a sexually active young man: CEFTRIAXONE SINGLE DOSE PLUS DOXYCYCLINE FOR 10 DAYS.",
 URE_FA + [
  "⚠️ **اپیدیدیمیت را با سن بیمار به دو دسته‌ی کاملاً متفاوت تقسیم کنید.**",
  "**زیر ۳۵ سال و فعال جنسی: عامل، ارگانیسم‌های مقاربتی‌اند — کلامیدیا و گونوکوک.**",
  "**بالای ۳۵ سال یا با انسداد ادراری: عامل، گرم‌منفی‌های روده‌ای‌اند — به‌ویژه ای‌کولای.**",
  "**این تقسیم‌بندی، درمان را کاملاً عوض می‌کند و اولین چیزی است که باید تصمیم بگیرید.**",
  "**در گروه مقاربتی: سفتریاکسون ۵۰۰ میلی‌گرم عضلانی تک‌دوز + داکسی‌سیکلین ۱۰۰ میلی‌گرم دو بار در روز، ۱۰ روز.**",
  "⚠️ **دقت کنید: اینجا داکسی‌سیکلین ۱۰ روز است، نه ۷ روزِ اورتریت ساده.**",
  "**چون عفونت از مجرا به بافت عمقی اپیدیدیم رسیده و نفوذ بیشتری لازم است.**",
  "**در مردانی که رابطه‌ی مقعدی فاعلی دارند، گرم‌منفی روده‌ای هم محتمل است:**",
  "**آنگاه سفتریاکسون + لووفلوکساسین ۵۰۰ میلی‌گرم روزانه، ۱۰ روز.**",
  "⚠️ **و مهم‌ترین تشخیص افتراقی که هرگز نباید از قلم بیفتد: تورشن بیضه.**",
  "**تورشن درد ناگهانی و شدید است، رفلکس کرماستریک ندارد، و یک فوریت جراحی است.**",
  "**در تردید، سونوگرافی داپلر فوری لازم است: در اپیدیدیمیت جریان خون زیاد، در تورشن کم.**",
 ],
 URE_EN + [
  "WARNING: SPLIT EPIDIDYMITIS BY THE PATIENT'S AGE INTO TWO ENTIRELY DIFFERENT DISEASES.",
  "UNDER 35 AND SEXUALLY ACTIVE: the agents are sexually transmitted — chlamydia and gonorrhoea.",
  "OVER 35, OR WITH URINARY OBSTRUCTION: the agents are enteric gram-negatives, above all E. coli.",
  "That split completely changes the treatment and is the first decision to make.",
  "In the sexually transmitted group: CEFTRIAXONE 500 MG IM SINGLE DOSE PLUS DOXYCYCLINE 100 MG TWICE DAILY FOR 10 DAYS.",
  "WARNING, NOTE: HERE THE DOXYCYCLINE RUNS 10 DAYS, not the 7 of simple urethritis.",
  "Because the infection has travelled from the urethra into deep epididymal tissue and needs more penetration.",
  "In men who practise insertive anal intercourse, enteric gram-negatives are also likely:",
  "then ceftriaxone plus levofloxacin 500 mg daily for 10 days.",
  "WARNING, AND THE DIFFERENTIAL THAT MUST NEVER BE MISSED: TESTICULAR TORSION.",
  "Torsion is sudden severe pain with an absent cremasteric reflex, and it is a surgical emergency.",
  "If in doubt, get an urgent Doppler ultrasound: flow is INCREASED in epididymitis and REDUCED in torsion.",
 ],
 "این سؤال، اورتریت را یک قدم جلوتر می‌برد: وقتی عفونت از مجرا بالا می‌رود.\n\n"
 "**آقای ۲۲ ساله** با **اپیدیدیمواورکیت یک‌طرفه**، که **۳ هفته پیش** پس از تماس "
 "محافظت‌نشده دچار **ترشح چرکی مجرا** شده و **درمان نگرفته است**.\n\n"
 "⚠️ **گام یک — کدام دسته از اپیدیدیمیت؟**\n\n"
 "این تقسیم‌بندی، اولین و مهم‌ترین تصمیم است:\n\n"
 "زیر ۳۵ سال، فعال جنسی: بالای ۳۵ سال یا انسداد ادراری\n"
 "عامل: **کلامیدیا و گونوکوک** — **ای‌کولای و گرم‌منفی‌های روده‌ای**\n"
 "درمان: **سفتریاکسون + داکسی‌سیکلین** — **فلوروکینولون**\n\n"
 "بیمار ما **۲۲ ساله**، با **سابقه‌ی روشن تماس جنسی و ترشح چرکی درمان‌نشده** است. "
 "**دسته‌ی اول، بدون تردید.**\n\n"
 "⚠️ **گام دو — چرا این عفونت اتفاق افتاد؟**\n\n"
 "این نکته‌ی آموزشی طلایی سؤال است: **بیمار سه هفته پیش اورتریت داشته و درمان نگرفته**. "
 "عفونت درمان‌نشده از مجرا **به‌صورت صعودی از طریق مجرای دفران** به اپیدیدیم رسیده. "
 "**اپیدیدیمیت، عارضه‌ی اورتریت درمان‌نشده است** — دقیقاً همان چیزی که درمان دوگانه‌ی به‌موقع "
 "از آن پیشگیری می‌کند.\n\n"
 "**گام سه — درمان: سفتریاکسون تک‌دوز + داکسی‌سیکلین ۱۰ روز.** ✅\n\n"
 "⚠️ **چرا داکسی‌سیکلین ۱۰ روز و نه ۷ روز؟** چون عفونت دیگر سطحی و مخاطی نیست؛ به "
 "**بافت عمقی اپیدیدیم** رسیده و **نفوذ بافتی طولانی‌تری** لازم دارد. (در اورتریت ساده، "
 "۷ روز کافی است.)\n\n"
 "**چرا گزینه‌ی «سفتریاکسون + آزیترومایسین» غلط است؟** آزیترومایسین **تک‌دوز** برای "
 "اورتریت ساده طراحی شده و **غلظت بافتی پایدار لازم برای اپیدیدیمیت** را نمی‌سازد. "
 "در اپیدیدیمیت، **دوره‌ی ۱۰ روزه‌ی داکسی‌سیکلین** استاندارد است.\n\n"
 "⚠️ **و هشدار حیاتی: تورشن بیضه را رد کنید.** در جوان با درد بیضه، تورشن یک "
 "**فوریت جراحی** است و پنجره‌ی نجات بیضه فقط **۶ ساعت** است. تورشن **ناگهانی و بسیار "
 "دردناک** است، **رفلکس کرماستریک ندارد**، و **ترشح مجرا ندارد**. در تردید، "
 "**سونوگرافی داپلر فوری**: در اپیدیدیمیت جریان خون **زیاد**، در تورشن **کم**.",
 "This question takes urethritis one step further: what happens when the infection ascends.\n\n"
 "A 22-YEAR-OLD MAN with UNILATERAL EPIDIDYMO-ORCHITIS, who THREE WEEKS AGO developed PURULENT "
 "URETHRAL DISCHARGE after unprotected intercourse and RECEIVED NO TREATMENT.\n\n"
 "WARNING, STEP ONE — WHICH KIND OF EPIDIDYMITIS?\n\n"
 "This split is the first and most important decision:\n\n"
 "Under 35, sexually active: Over 35, or urinary obstruction\n"
 "Agent: CHLAMYDIA AND GONORRHOEA — E. COLI AND ENTERIC GRAM-NEGATIVES\n"
 "Treatment: CEFTRIAXONE PLUS DOXYCYCLINE — A FLUOROQUINOLONE\n\n"
 "Our patient is 22, with a CLEAR HISTORY OF INTERCOURSE AND UNTREATED PURULENT DISCHARGE. THE "
 "FIRST GROUP, without doubt.\n\n"
 "WARNING, STEP TWO — WHY DID THIS HAPPEN?\n\n"
 "This is the golden teaching point: THE PATIENT HAD URETHRITIS THREE WEEKS AGO AND WAS NOT "
 "TREATED. The untreated infection ASCENDED ALONG THE VAS DEFERENS to the epididymis. "
 "EPIDIDYMITIS IS A COMPLICATION OF UNTREATED URETHRITIS — exactly what timely dual therapy "
 "prevents.\n\n"
 "STEP THREE — TREATMENT: CEFTRIAXONE SINGLE DOSE PLUS DOXYCYCLINE FOR 10 DAYS.\n\n"
 "WARNING, WHY 10 DAYS RATHER THAN 7? Because the infection is no longer superficial and mucosal; "
 "it has reached DEEP EPIDIDYMAL TISSUE and needs LONGER TISSUE PENETRATION. (In simple "
 "urethritis, 7 days suffices.)\n\n"
 "WHY IS 'CEFTRIAXONE PLUS AZITHROMYCIN' WRONG? Single-dose azithromycin is designed for simple "
 "urethritis and does not produce the SUSTAINED TISSUE CONCENTRATION epididymitis requires. In "
 "epididymitis the 10-DAY DOXYCYCLINE COURSE is standard.\n\n"
 "WARNING, AND A CRITICAL CAUTION: EXCLUDE TESTICULAR TORSION. In a young man with testicular "
 "pain, torsion is a SURGICAL EMERGENCY with only a SIX-HOUR window to save the testis. Torsion "
 "is SUDDEN and SEVERE, has NO CREMASTERIC REFLEX, and has NO URETHRAL DISCHARGE. If in doubt, "
 "URGENT DOPPLER ULTRASOUND: flow is INCREASED in epididymitis and REDUCED in torsion.",
 ["اوفلوکساسین به‌تنهایی گونوکوک را پوشش نمی‌دهد؛ مقاومت کینولونی گونوکوک بسیار بالاست.",
  "سفوروکسیم نه پوشش کافی گونوکوک دارد و نه اصلاً روی کلامیدیا اثر می‌کند.",
  "پاسخ صحیح — سفتریاکسون گونوکوک را و داکسی‌سیکلین ۱۰ روزه کلامیدیا را در بافت عمقی پوشش می‌دهد.",
  "آزیترومایسین تک‌دوز غلظت بافتی پایدار لازم برای اپیدیدیمیت را نمی‌سازد؛ اینجا دوره‌ی ۱۰ روزه لازم است."],
 ["Ofloxacin alone does not cover gonorrhoea; gonococcal quinolone resistance is very high.",
  "Cefuroxime neither covers gonorrhoea adequately nor works against chlamydia at all.",
  "Correct — ceftriaxone covers the gonococcus and 10 days of doxycycline covers chlamydia in deep tissue.",
  "Single-dose azithromycin does not give the sustained tissue level epididymitis needs; a 10-day course is required."],
 "**زیر ۳۵ سال = مقاربتی. بالای ۳۵ = ای‌کولای.** و همیشه تورشن بیضه را رد کنید.",
 "Under 35 means sexually transmitted, over 35 means E. coli; and always exclude testicular torsion.",
 [CDC2021, H35])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book30.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 30 lessons:', len(L))
