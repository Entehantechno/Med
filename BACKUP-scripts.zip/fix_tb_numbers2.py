# -*- coding: utf-8 -*-
"""Four numeric repairs in the tuberculosis chapter, found by the generalised
second-pass auditor.

METHOD, UNCHANGED FROM THE FOURTEEN EARLIER CHAPTER PASSES
-----------------------------------------------------------
pdfplumber gives the x coordinate of every glyph. A number is always DRAWN
left to right even inside right-to-left Persian text, so sorting a line's
characters by x0 recovers the digits in the order the typesetter placed them.
Nothing here is repaired on the auditor's word alone: every replacement value
must appear as a printed digit run on its own page or the script refuses it.

HOW THESE FOUR WERE FOUND
--------------------------
`python3 audit_chapter_numbers.py 'سل'` reported:

    agree=53   disagree=3   unlocated=4

The four "unlocated" items were then checked BY HAND against pages 104 to 107
and every one of them proved sound — they are prophylaxis questions whose
wording repeats across four neighbouring pages, which is exactly the ambiguity
the three-page window is designed to refuse rather than guess at. So nothing
is written for them.

The three "disagree" items are real, and inspecting the glyph runs of their
pages turned up a FOURTH defect the auditor could not see, described below.

THE FOURTH DEFECT: A TRUNCATION, NOT A MIRRORING
--------------------------------------------------
Every earlier chapter's defects were mirrorings — the digits of one value in
reverse order. q9214 carries a different and more dangerous kind. The page
prints

    LDH=2000mg/dL (همزمان سرم = 500)، قند = 60

and the stored stem had kept only the leading "2" of the pleural LDH. The
auditor cannot flag that, because "2" is a legitimate digit run and it does
occur on the page. It surfaced only when the page's runs were listed in
printed order and the missing 000 became obvious.

WHY THIS MATTERS MEDICALLY, QUESTION BY QUESTION
--------------------------------------------------
  q9214  This is a Light's-criteria question wearing a tuberculosis costume.
         The student is meant to see A LYMPHOCYTE-PREDOMINANT EXUDATE:
         pleural LDH 2000 against a serum LDH of 500 is a ratio of 4, far
         above the 0.6 that defines an exudate, and pleural protein 4 g/dL
         against serum 2.5 (wait: serum here is the protein pair) is likewise
         exudative. With "LDH = 2" and "serum = 005" NONE of those ratios can
         be computed, and the vignette collapses into a guess. A glucose of
         60 — low — is the other half of the tuberculous pleural picture.

  q9249  The page prints Hb: 12 mg/dl. Stored "21" is not merely wrong, it
         inverts the clinical meaning: 21 g/dL would be polycythaemia and
         would send the student hunting for a completely different cause of
         the purpura. At Hb 12 the ONLY cytopenia in the panel is the
         platelet count of 40,000 — an ISOLATED THROMBOCYTOPENIA, which is
         precisely the finding that identifies rifampicin as the culprit and
         makes rifampicin permanently contraindicated on rechallenge.

So of the four repairs, three change what the student is able to conclude and
one (the glucose) restores a supporting finding.
"""
import collections
import io
import json
import os

import pdfplumber

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = '/home/user/uploads/بیماری عفونی.pdf'

# question_no -> [(page, old, new, expected_printed_run, kind, why_fa, why_en)]
FIXES = {
    9214: [
        (84, '2 mg/dL=LDH', 'LDH=2000 mg/dL', '2000', 'truncation',
         'LDH مایع پلور: صفحه ۸۴ عبارت **LDH=2000mg/dL** را چاپ کرده است. '
         'گلیف‌ها به‌ترتیب x: «۲» در ۱۸۷٫۱ · «۰» در ۱۹۷٫۱ · «۰» در ۲۰۷٫۱ · '
         '«۰» در ۲۱۷٫۱ — یعنی صفحه از چپ به راست **۲۰۰۰** را نشان می‌دهد.\n\n'
         '⚠️ **این خرابی از نوع تازه‌ای است: بریدگی، نه وارونگی.** در متن ذخیره‌شده '
         'فقط رقم نخست («۲») مانده و سه صفر افتاده بود.\n\n'
         '**چرا این عدد کل سؤال را می‌سازد؟** این در واقع یک سؤال «معیارهای لایت» '
         'است. **نسبت LDH مایع به سرم = ۲۰۰۰ ÷ ۵۰۰ = ۴** — بسیار بالاتر از آستانه‌ی '
         '۰٫۶ که اگزودا را تعریف می‌کند. با «LDH = ۲» و «سرم = ۰۰۵» هیچ نسبتی '
         'قابل محاسبه نیست و ویگنت به حدس تبدیل می‌شود.',
         'Pleural fluid LDH: page 84 prints LDH=2000mg/dL. The glyphs in ascending x: 2 at 187.1, 0 at 197.1, 0 at 207.1, 0 at 217.1, so the page reads 2000 left to right. WARNING, THIS IS A NEW KIND OF DEFECT: A TRUNCATION, NOT A MIRRORING. The stored stem had kept only the leading digit and lost three zeros. WHY THIS NUMBER BUILDS THE WHOLE QUESTION: this is a Light\'s-criteria question. THE PLEURAL-TO-SERUM LDH RATIO IS 2000 / 500 = 4, far above the 0.6 that defines an exudate. With "LDH = 2" and "serum = 005" no ratio can be computed at all and the vignette collapses into a guess.'),
        (84, '=،)005', '= 500)،', '500', 'reorder',
         'LDH سرم هم‌زمان: صفحه ۸۴ عدد **۵۰۰** را چاپ کرده است، ولی متن ذخیره‌شده '
         '«۰۰۵» داشت — ارقام دقیقاً برعکس.\n\n'
         '**چرا مهم است؟** بدون مخرج درست، نسبت LDH مایع به سرم قابل محاسبه نیست '
         'و **اثبات اگزودا بودن مایع** — که پایه‌ی رفتن به سمت پلورزی سلی است — '
         'ممکن نمی‌شود.',
         'Simultaneous serum LDH: page 84 prints 500, while the stored stem read 005 — the digits exactly reversed. WHY IT MATTERS: without the correct denominator the pleural-to-serum LDH ratio cannot be computed, and PROVING THE FLUID IS AN EXUDATE — the basis for moving towards tuberculous pleurisy — becomes impossible.'),
        (84, 'قند = 06', 'قند = 60', '60', 'reorder',
         'قند مایع پلور: صفحه ۸۴ عدد **۶۰** را چاپ کرده است (متن ذخیره‌شده «۰۶»).\n\n'
         '**چرا مهم است؟** **قند پایین مایع پلور** یکی از ستون‌های تابلوی پلورزی '
         'سلی است و در کنار غلبه‌ی لنفوسیت‌ها (۹۰٪) تشخیص را به سمت سل می‌برد. '
         '«۰۶» عددی نیست که دانشجو بتواند تفسیر کند.',
         'Pleural fluid glucose: page 84 prints 60 (the stored stem read 06). WHY IT MATTERS: A LOW PLEURAL GLUCOSE is one of the pillars of the tuberculous pleurisy picture and, alongside the 90 % lymphocyte predominance, steers the diagnosis towards tuberculosis. "06" is not a figure a student can interpret.'),
    ],
    9249: [
        (97, ',21 mg/dl:Hb', 'Hb: 12 mg/dl', '12', 'reorder',
         'هموگلوبین: صفحه ۹۷ عبارت **Hb: 12mg/dl** را چاپ کرده است. گلیف‌ها: '
         '«۱» در x=۲۲۹٫۶ و «۲» در x=۲۳۹٫۶ — یعنی صفحه **۱۲** را نشان می‌دهد.\n\n'
         '⚠️ **این وارونگی معنای بالینی را برعکس می‌کند، نه فقط عدد را.** '
         'هموگلوبین ۲۱ یعنی **پلی‌سیتمی**، و دانشجو را به دنبال علتی کاملاً '
         'متفاوت برای پورپورا می‌فرستد.\n\n'
         '**با هموگلوبین ۱۲ و گلبول سفید ۶۰۰۰، تنها اختلال پانل، پلاکت ۴۰٬۰۰۰ است '
         '— یعنی ترومبوسیتوپنی منفرد.** و ترومبوسیتوپنی منفردِ ایمنی در بیمار تحت '
         'درمان ضدسل، امضای **ریفامپین** است؛ همان چیزی که سؤال می‌خواهد و همان '
         'چیزی که مصرف مجدد آن را برای همیشه ممنوع می‌کند.',
         'Haemoglobin: page 97 prints Hb: 12mg/dl. The glyphs: 1 at x=229.6 and 2 at x=239.6, so the page reads 12. WARNING, THIS MIRRORING INVERTS THE CLINICAL MEANING, NOT MERELY THE NUMBER. A haemoglobin of 21 means POLYCYTHAEMIA and sends the student hunting for a completely different cause of the purpura. WITH Hb 12 AND A WHITE COUNT OF 6000, THE ONLY ABNORMALITY IN THE PANEL IS THE PLATELET COUNT OF 40,000 — AN ISOLATED THROMBOCYTOPENIA. And an isolated immune thrombocytopenia in a patient on antituberculous therapy is the signature of RIFAMPICIN, which is what the question wants and what makes rechallenge with that drug permanently forbidden.'),
    ],
}

FOLD = {}
for _i in range(10):
    FOLD[chr(0x0660 + _i)] = str(_i)   # Arabic-Indic
    FOLD[chr(0x06F0 + _i)] = str(_i)   # Persian


def page_digit_runs(pdf, pno):
    """Digit runs of a page in PRINTED (x-ascending) order."""
    page = pdf.pages[pno - 1]
    rows = collections.defaultdict(list)
    for c in page.chars:
        rows[round(c['top'])].append(c)
    runs = []
    for top in sorted(rows):
        cs = sorted(rows[top], key=lambda c: c['x0'])
        cur = ''
        for c in cs:
            t = FOLD.get(c['text'], c['text'])
            # a space must NOT close an open run: kerning sometimes splits a
            # number, and closing on the space invents two numbers out of one
            if t.isspace() and cur:
                continue
            if t.isdigit():
                cur += t
            else:
                if cur:
                    runs.append(cur)
                cur = ''
        if cur:
            runs.append(cur)
    return runs


def main():
    pages = {p for specs in FIXES.values() for (p, *_r) in specs}
    with pdfplumber.open(SRC) as pdf:
        printed = {p: page_digit_runs(pdf, p) for p in pages}

    applied, missing, unproven = [], [], []
    for i in range(1, 6):
        path = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        if not os.path.exists(path):
            continue
        body = json.load(io.open(path, encoding='utf-8'))
        dirty = False
        for q in body['questions']:
            specs = FIXES.get(q['question_no'])
            if not specs:
                continue
            for (pno, old, new, expect, kind, why_fa, why_en) in specs:
                # GUARD ONE: the repaired value must actually be printed.
                if expect not in printed[pno]:
                    unproven.append(f'q{q["question_no"]}: {expect} not printed on p{pno}')
                    continue
                # GUARD TWO: the text being replaced must be present, so a
                # silent no-op cannot be reported as a success.
                if old not in q['question_fa']:
                    missing.append(f'q{q["question_no"]}: {old!r} not in stem')
                    continue
                # THE BANK'S CONTRACT FOR A REPAIRED STEM, enforced by the
                # suite: keep the untouched original and explain the repair in
                # BOTH languages.
                q.setdefault('stem_original_fa', q['question_fa'])
                q['question_fa'] = q['question_fa'].replace(old, new)
                fixes = q.setdefault('stem_number_corrections', {})
                fixes[old] = new
                prev_fa = q.get('stem_repair_note_fa') or ''
                q['stem_repair_note_fa'] = (prev_fa + '\n\n' + why_fa).strip()
                prev_en = q.get('stem_repair_note_en') or ''
                q['stem_repair_note_en'] = (prev_en + '\n\n' + why_en).strip()
                q['stem_repaired'] = True
                applied.append(f'q{q["question_no"]}: {old!r} -> {new!r} (p{pno}, {kind})')
                dirty = True
        if dirty:
            json.dump(body, io.open(path, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)

    for a in applied:
        print('fixed  ', a)
    for m in missing:
        print('SKIP   ', m)
    for u in unproven:
        print('UNPROVEN', u)
    print(f'\napplied={len(applied)}  skipped={len(missing)}  unproven={len(unproven)}')
    # An empty run means the script silently did nothing, which is the failure
    # mode this bank has been bitten by before.
    assert applied, 'nothing applied — the script did nothing at all'


if __name__ == '__main__':
    main()
