# -*- coding: utf-8 -*-
"""Correct one more defective printed key: idx 541.

The stem: gonococcal urethritis confirmed on Gram stain, treated with a single
dose of ceftriaxone, symptoms resolve, then a week later mucoid discharge
returns WITHOUT any new sexual contact. The book's printed key is "none of the
above"; option (c) is "concurrent Chlamydia trachomatis infection".

Verified against the PDF line by line — the extraction is faithful, so this is
the book's own key, not a parsing error.

It is nonetheless wrong, and for a reason the bank has already settled: an
identical scenario appears at idx 555 ("treated for gonococcus with
ceftriaxone... recurs after a week without re-exposure"), where the book's own
printed key IS "ceftriaxone + azithromycin for chlamydia". The book therefore
contradicts itself between two printings of the same question, and only one of
those answers is defensible.

Why option (c) is right: ceftriaxone treats the gonococcus but has no activity
against Chlamydia trachomatis. Up to 40-50% of men with gonococcal urethritis
are co-infected. When the purulent gonococcal discharge clears and a mucoid
post-gonococcal urethritis appears about a week later with no new exposure, the
residual organism is chlamydia. That is the textbook definition of
post-gonococcal urethritis.

Recorded the same way as the earlier corrections: original key preserved,
bilingual justification, cited source, and the lesson discloses the change.
"""
import json, io, os

BANK = '/home/user/project/tools/infectious-bank'

TARGET = 541
NEW_INDEX = 2

CORRECTION = {
    'was': 'هیچ‌کدام',
    'now': 'عفونت همزمان با کلامیدیا تراکوماتیس',
    'reason_fa': 'سفتریاکسون گونوکوک را درمان می‌کند ولی روی کلامیدیا اثری ندارد. '
                 'بازگشت ترشح موکوسی حدود یک هفته بعد و بدون تماس جنسی جدید، '
                 'تعریف کلاسیک یورتریت پس از گونوکوک است که عامل آن کلامیدیای '
                 'همزمان درمان‌نشده است. ضمناً همین سناریو در سؤال دیگری از همین '
                 'منبع (شهریور ۹۸) کلید «سفتریاکسون + آزیترومایسین برای کلامیدیا» '
                 'دارد، یعنی منبع با خودش ناسازگار است.',
    'reason_en': 'Ceftriaxone treats the gonococcus but has no activity against '
                 'Chlamydia. Mucoid discharge returning about a week later with no '
                 'new sexual contact is the classic definition of post-gonococcal '
                 'urethritis, caused by untreated concurrent chlamydia. The same '
                 'source answers an identical scenario elsewhere (Shahrivar 98) '
                 'with "ceftriaxone + azithromycin for chlamydia", so the book '
                 'contradicts itself.',
    'source': 'CDC STD Treatment Guidelines (post-gonococcal urethritis; dual '
              'therapy); internal cross-check against the same book, idx 555',
}


def main():
    idx = 0
    done = False
    for i in range(1, 6):
        p = os.path.join(BANK, f'import-payload.book.part{i:02d}.json')
        if not os.path.exists(p):
            continue
        body = json.load(io.open(p, encoding='utf-8'))
        changed = False
        for q in body['questions']:
            n = idx
            idx += 1
            if n != TARGET:
                continue
            if q.get('key_corrected'):
                print('already corrected; nothing to do')
                return
            q['original_correct_index'] = q['correct_index']
            q['correct_index'] = NEW_INDEX
            q['key_corrected'] = True
            q['key_correction_fa'] = CORRECTION['reason_fa']
            q['key_correction_en'] = CORRECTION['reason_en']
            q['key_correction_source'] = CORRECTION['source']
            changed = done = True
        if changed:
            json.dump(body, io.open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

    print(f'scanned {idx} questions')
    if done:
        print(f'corrected idx={TARGET}: "{CORRECTION["was"]}" -> "{CORRECTION["now"]}"')
    else:
        print('target not found')


if __name__ == '__main__':
    main()
