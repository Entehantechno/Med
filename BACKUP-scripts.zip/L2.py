# -*- coding: utf-8 -*-
"""Infectious-diseases micro-lessons, batch 2 — Esfand-1403 (items 103-108)."""
import json, io
L = {}

L["1403-12:103"] = {
 "style": "case", "difficulty": "hard",
 "stem_en": "A 27-year-old woman presents to the emergency department with nausea, vomiting and fever. On examination she has high fever, neck stiffness and left lower limb weakness. CSF analysis: WBC 1000/µL, PMN 90%, glucose 20 mg/dL, protein 105 mg/dL. What is the appropriate treatment?",
 "options_en": ["Ceftriaxone + vancomycin + ampicillin", "Ceftriaxone + vancomycin + metronidazole",
                "Ceftriaxone + vancomycin + acyclovir", "Ceftriaxone + vancomycin + levofloxacin"],
 "micro": {
  "lead_fa": "قند پایین + نوتروفیل غالب = مننژیت باکتریال. علامت کانونی در جوان = افزودن آمپی‌سیلین برای لیستریا.",
  "lead_en": "Low glucose with neutrophil predominance means bacterial meningitis; a focal sign means adding ampicillin for Listeria.",
  "points_fa": [
   "آنالیز مایع نخاعی سه عدد کلیدی دارد: شمارش و نوع سلول، قند و پروتئین.",
   "مننژیت باکتریال: سلول بالا با غلبه‌ی نوتروفیل، قند پایین، پروتئین بالا.",
   "مننژیت ویروسی: سلول متوسط با غلبه‌ی لنفوسیت، قند طبیعی، پروتئین کمی بالا.",
   "قند مایع نخاعی زیر ۴۰ یا نسبت قند CSF به سرم زیر ۰٫۴ به‌شدت به نفع باکتریال است.",
   "درمان تجربی پایه در بزرگسال: سفتریاکسون به‌علاوه‌ی وانکومایسین.",
   "وانکومایسین برای پوشش پنوموکوک مقاوم به سفالوسپورین اضافه می‌شود.",
   "آمپی‌سیلین وقتی اضافه می‌شود که خطر لیستریا مونوسیتوژنز مطرح باشد.",
   "گروه‌های پرخطر لیستریا: بالای ۵۰ سال، بارداری، نقص ایمنی و الکلیسم.",
   "لیستریا می‌تواند رومبانسفالیت بسازد و علامت عصبی کانونی بدهد."
  ],
  "points_en": [
   "CSF analysis has three key numbers: cell count and type, glucose and protein.",
   "Bacterial meningitis: high cells with neutrophil predominance, low glucose, high protein.",
   "Viral meningitis: moderate cells with lymphocyte predominance, normal glucose, mildly raised protein.",
   "A CSF glucose under 40, or a CSF-to-serum ratio under 0.4, strongly favours bacterial disease.",
   "Baseline empirical treatment in adults: ceftriaxone plus vancomycin.",
   "Vancomycin is added to cover cephalosporin-resistant pneumococcus.",
   "Ampicillin is added when Listeria monocytogenes is a concern.",
   "High-risk groups for Listeria: over 50, pregnancy, immunosuppression and alcoholism.",
   "Listeria can cause rhombencephalitis and produce focal neurological signs."
  ]
 },
 "explanation_fa": "این سؤال دو مرحله دارد و مرحله‌ی دوم ظریف‌تر است. مرحله‌ی اول خواندن مایع نخاعی است: هزار سلول با نود درصد نوتروفیل، قند بیست و پروتئین صد و پنج. این ترکیب مننژیت باکتریال حاد را قطعی می‌کند و آسیکلوویر را کنار می‌گذارد، چون انسفالیت هرپسی قند مایع نخاعی را این‌قدر پایین نمی‌آورد و لنفوسیتی است. مرحله‌ی دوم انتخاب رژیم است. پایه در همه‌ی بزرگسالان سفتریاکسون به‌علاوه‌ی وانکومایسین است، پس سؤال در واقع می‌پرسد داروی سوم چه باشد. آمپی‌سیلین وقتی اضافه می‌شود که لیستریا مطرح باشد، و اینجا دو نشانه به آن اشاره دارد: ضعف اندام تحتانی چپ که یک علامت کانونی است و به رومبانسفالیت لیستریایی می‌خورد، و سن باروری بیمار که احتمال بارداری را مطرح می‌کند؛ بارداری از عوامل خطر شناخته‌شده‌ی لیستریاست.",
 "explanation_en": "This item has two steps and the second is subtler. The first is reading the CSF: a thousand cells with ninety percent neutrophils, glucose of twenty and protein of one hundred and five. That combination settles acute bacterial meningitis and rules out acyclovir, because herpes encephalitis does not drive CSF glucose that low and is lymphocytic. The second step is choosing the regimen. The base in every adult is ceftriaxone plus vancomycin, so the question really asks what the third drug should be. Ampicillin is added when Listeria is a concern, and two features point there: left lower limb weakness, a focal sign fitting listerial rhombencephalitis, and the patient's childbearing age raising the possibility of pregnancy, a recognised Listeria risk factor.",
 "why_fa": [
  "پاسخ صحیح — سفتریاکسون و وانکومایسین پایه‌ی درمان است و آمپی‌سیلین برای پوشش لیستریا اضافه می‌شود که با علامت کانونی این بیمار می‌خواند.",
  "مترونیدازول برای بی‌هوازی‌هاست و در مننژیت باکتریال اکتسابی از جامعه اندیکاسیون ندارد؛ جای آن در آبسه‌ی مغزی است.",
  "آسیکلوویر برای انسفالیت هرپسی است که مایع نخاعی لنفوسیتی با قند طبیعی دارد، نه نوتروفیلی با قند بیست.",
  "لووفلوکساسین در رژیم استاندارد مننژیت باکتریال جایی ندارد و پوشش قابل اتکایی برای لیستریا فراهم نمی‌کند."
 ],
 "why_en": [
  "Correct — ceftriaxone plus vancomycin is the base, and ampicillin is added for Listeria cover, which fits this patient's focal sign.",
  "Metronidazole targets anaerobes and has no indication in community-acquired bacterial meningitis; its place is brain abscess.",
  "Acyclovir is for herpes encephalitis, which gives lymphocytic CSF with normal glucose, not neutrophilic CSF with glucose of twenty.",
  "Levofloxacin has no place in the standard bacterial meningitis regimen and gives no reliable Listeria cover."
 ],
 "golden_fa": "قند پایین + نوتروفیل = باکتریال. پایه: سفتریاکسون + وانکومایسین. لیستریا مطرح؟ آمپی‌سیلین اضافه کن.",
 "golden_en": "Low glucose plus neutrophils means bacterial. Base: ceftriaxone plus vancomycin. Listeria a concern? Add ampicillin.",
 "refs": [
  "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 138: Acute Meningitis",
  "IDSA practice guidelines for the management of bacterial meningitis"
 ]
}

L["1403-12:104"] = {
 "style": "case", "difficulty": "medium",
 "stem_en": "A 23-year-old woman presents 6 hours after eating a salad with watery diarrhoea, nausea and vomiting. The abdominal pain is colicky. Which organism is the main cause?",
 "options_en": ["Staphylococcus aureus", "Escherichia coli", "Shigella", "Listeria"],
 "micro": {
  "lead_fa": "دوره‌ی نهفتگی زیر ۶ ساعت یعنی توکسین از پیش ساخته‌شده، نه تکثیر باکتری.",
  "lead_en": "An incubation under 6 hours means preformed toxin, not bacterial multiplication.",
  "points_fa": [
   "در مسمومیت غذایی، مهم‌ترین سرنخ تشخیصی فاصله‌ی بین غذا و شروع علائم است.",
   "زیر ۶ ساعت: توکسین از پیش ساخته‌شده در غذا؛ استاف اورئوس و باسیلوس سرئوس.",
   "۸ تا ۱۶ ساعت: کلستریدیوم پرفرنژنس با تولید توکسین در روده.",
   "بیش از ۱۶ ساعت تا چند روز: عفونت واقعی؛ سالمونلا، شیگلا، کامپیلوباکتر و E. coli.",
   "استاف اورئوس انتروتوکسین مقاوم به حرارت می‌سازد که با پختن مجدد از بین نمی‌رود.",
   "غذاهای پرخطر: سالاد، سس، شیرینی خامه‌ای و غذاهایی که با دست کار شده‌اند.",
   "در مسمومیت استافی، استفراغ معمولاً بارزتر از اسهال است.",
   "بیماری خودمحدودشونده است و طی ۲۴ ساعت فروکش می‌کند.",
   "درمان فقط حمایتی و جبران مایعات است؛ آنتی‌بیوتیک جایی ندارد."
  ],
  "points_en": [
   "In food poisoning, the single best clue is the interval between the meal and the symptoms.",
   "Under 6 hours: preformed toxin in the food; Staphylococcus aureus and Bacillus cereus.",
   "8 to 16 hours: Clostridium perfringens, producing toxin in the gut.",
   "Over 16 hours to days: true infection; Salmonella, Shigella, Campylobacter and E. coli.",
   "Staph aureus makes a heat-stable enterotoxin that reheating does not destroy.",
   "High-risk foods: salads, sauces, cream pastries and anything handled by hand.",
   "In staphylococcal poisoning, vomiting is usually more prominent than diarrhoea.",
   "The illness is self-limiting and settles within 24 hours.",
   "Treatment is supportive rehydration only; antibiotics have no role."
  ]
 },
 "explanation_fa": "برای حل این سؤال به هیچ آزمایشی نیاز نیست، فقط به ساعت. شش ساعت فاصله بین غذا و علائم، بازه‌ای است که هیچ باکتری‌ای فرصت ندارد در روده تکثیر شود و بیماری ایجاد کند. پس بیماری باید از چیزی بیاید که از قبل در غذا آماده بوده، یعنی توکسین. دو عامل کلاسیک این بازه‌ی کوتاه استاف اورئوس و باسیلوس سرئوس هستند. حالا نوع غذا انتخاب را نهایی می‌کند: سالاد غذایی است که با دست آماده می‌شود و اگر دست فرد آماده‌کننده زخم یا کلونیزاسیون استافی داشته باشد، باکتری وارد غذا می‌شود و در دمای اتاق انتروتوکسین می‌سازد. این توکسین مقاوم به حرارت است، پس حتی گرم کردن دوباره هم آن را از بین نمی‌برد. سه گزینه‌ی دیگر همگی باید در روده تکثیر شوند و دوره‌ی نهفتگی‌شان یک تا چند روز است، نه چند ساعت.",
 "explanation_en": "No laboratory test is needed here, only the clock. Six hours between the meal and the symptoms is a window in which no bacterium has time to multiply in the gut and cause disease. So the illness must come from something already present in the food: a toxin. The two classic organisms for this short window are Staph aureus and Bacillus cereus. The food then settles the choice: salad is prepared by hand, and if the preparer has a staphylococcal skin lesion or carriage, the organism enters the food and produces enterotoxin at room temperature. That toxin is heat-stable, so even reheating does not destroy it. The other three all need to multiply in the gut and have incubation periods of one to several days, not hours.",
 "why_fa": [
  "پاسخ صحیح — دوره‌ی نهفتگی شش ساعته با انتروتوکسین از پیش ساخته‌شده‌ی استاف اورئوس می‌خواند، به‌ویژه در غذایی مثل سالاد که با دست آماده می‌شود.",
  "اشریشیاکلی برای ایجاد بیماری باید در روده تکثیر شود و دوره‌ی نهفتگی آن معمولاً یک تا سه روز است.",
  "شیگلا اسهال خونی با تب و تنسموس می‌سازد و دوره‌ی نهفتگی آن یک تا سه روز است، نه شش ساعت.",
  "لیستریا دوره‌ی نهفتگی طولانی دارد و بیشتر در بارداری، سالمندان و نقص ایمنی بیماری جدی می‌سازد."
 ],
 "why_en": [
  "Correct — a six-hour incubation fits Staph aureus preformed enterotoxin, especially in a hand-prepared food such as salad.",
  "Escherichia coli must multiply in the gut to cause illness and its incubation is usually one to three days.",
  "Shigella causes bloody diarrhoea with fever and tenesmus after an incubation of one to three days, not six hours.",
  "Listeria has a long incubation and mainly causes serious disease in pregnancy, the elderly and the immunocompromised."
 ],
 "golden_fa": "زیر ۶ ساعت = توکسین آماده = استاف/باسیلوس سرئوس. روزها = عفونت واقعی.",
 "golden_en": "Under 6 hours means preformed toxin (Staph or B. cereus); days mean true infection.",
 "refs": [
  "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 133: Acute Infectious Diarrheal Diseases and Bacterial Food Poisoning",
  "Harrison's 21st ed — Ch. 147: Staphylococcal Infections"
 ]
}

L["1403-12:105"] = {
 "style": "case", "difficulty": "hard",
 "stem_en": "A 45-year-old man presents to the emergency department with diplopia, ptosis, dysphagia and symmetric descending paralysis. He ate a can of tinned fish about 24 hours earlier. Which of the following must be done immediately?",
 "options_en": ["High-dose intravenous corticosteroid",
                "Specific antitoxin and preparation for intubation",
                "Admission to the infectious diseases ward, antibiotics and close monitoring",
                "ICU admission and intubation with ventilator support if required"],
 "micro": {
  "lead_fa": "آنتی‌توکسین تنها اقدامی است که پیشرفت فلج را متوقف می‌کند؛ هر ساعت تأخیر آسیب بیشتری را ماندگار می‌کند.",
  "lead_en": "Antitoxin is the only measure that halts progression; every hour of delay makes more paralysis permanent.",
  "points_fa": [
   "بوتولیسم غذایی با فلج قرینه و پایین‌رونده از اعصاب کرانیال شروع می‌شود.",
   "چهار نشانه‌ی کرانیال کلاسیک: دوبینی، پتوز، دیسفاژی و دیزآرتری.",
   "بیمار تب ندارد، حس سالم است و هوشیاری کاملاً حفظ می‌شود.",
   "توکسین به‌طور برگشت‌ناپذیر به پایانه‌ی عصبی پیش‌سیناپسی می‌چسبد.",
   "آنتی‌توکسین فقط توکسین آزاد در گردش خون را خنثی می‌کند.",
   "پس هر توکسینی که قبلاً متصل شده، با آنتی‌توکسین برنمی‌گردد.",
   "نتیجه‌ی عملی: هر ساعت تأخیر یعنی فلج بیشتری که باید با ترمیم عصب برگردد.",
   "خطر اصلی مرگ، فلج عضلات تنفسی است، پس پایش ظرفیت حیاتی الزامی است.",
   "آنتی‌بیوتیک در فرم غذایی نقشی ندارد و آمینوگلیکوزید فلج را تشدید می‌کند."
  ],
  "points_en": [
   "Foodborne botulism begins with symmetric descending paralysis starting in the cranial nerves.",
   "The four classic cranial features: diplopia, ptosis, dysphagia and dysarthria.",
   "The patient is afebrile, sensation is intact and consciousness is fully preserved.",
   "The toxin binds irreversibly to the presynaptic nerve terminal.",
   "Antitoxin neutralises only the toxin still free in the circulation.",
   "So any toxin already bound will not be reversed by antitoxin.",
   "The practical consequence: every hour of delay means more paralysis that must await nerve regrowth.",
   "The main cause of death is respiratory muscle paralysis, so vital capacity monitoring is mandatory.",
   "Antibiotics have no role in the foodborne form, and aminoglycosides worsen the paralysis."
  ]
 },
 "explanation_fa": "تشخیص در این سؤال آسان است و چالش جای دیگری است: انتخاب میان دو گزینه‌ای که هر دو درست به نظر می‌رسند. گزینه‌ی چهارم پذیرش در ICU و آمادگی برای انتوباسیون را پیشنهاد می‌دهد؛ این کار قطعاً لازم است چون علت مرگ در بوتولیسم فلج تنفسی است. اما این اقدام فقط منتظر می‌ماند و سیر بیماری را تغییر نمی‌دهد. تفاوت در اینجاست: توکسین بوتولینوم به‌طور برگشت‌ناپذیر به پایانه‌ی عصبی می‌چسبد و آنتی‌توکسین فقط می‌تواند توکسینی را که هنوز در خون آزاد است خنثی کند. یعنی هر ساعتی که می‌گذرد، بخش بیشتری از توکسین متصل می‌شود و دیگر قابل خنثی‌سازی نیست و آن فلج باید ماه‌ها منتظر ترمیم عصب بماند. پس آنتی‌توکسین یک اورژانس واقعی زمان‌محور است و پاسخ کامل، تجویز فوری آن همراه با آمادگی تنفسی است.",
 "explanation_en": "The diagnosis here is easy; the challenge lies elsewhere, in choosing between two options that both look right. The fourth proposes ICU admission and readiness to intubate; that is certainly necessary, since respiratory paralysis is what kills in botulism. But it only waits and does not change the course. Here is the difference: botulinum toxin binds irreversibly to the nerve terminal, and antitoxin can neutralise only toxin still free in the blood. Every passing hour lets more toxin bind beyond reach, and that paralysis must then wait months for nerve regrowth. Antitoxin is therefore a genuinely time-critical emergency, and the complete answer is to give it at once alongside respiratory preparation.",
 "why_fa": [
  "کورتیکواستروئید در بوتولیسم هیچ جایگاهی ندارد؛ مکانیسم بیماری ایمنی‌زاد نیست بلکه مسدود شدن مکانیکی انتقال عصبی است.",
  "پاسخ صحیح — آنتی‌توکسین توکسین آزاد را خنثی می‌کند و پیشرفت فلج را متوقف می‌سازد؛ هرچه زودتر داده شود آسیب کمتری ماندگار می‌ماند.",
  "آنتی‌بیوتیک در بوتولیسم غذایی بی‌فایده است، چون بیماری از توکسین آماده می‌آید نه از عفونت فعال.",
  "پذیرش در ICU و حمایت تنفسی لازم است اما به‌تنهایی کافی نیست؛ این اقدام سیر بیماری را تغییر نمی‌دهد."
 ],
 "why_en": [
  "Corticosteroids have no place in botulism; the mechanism is not immune-mediated but a mechanical block of neurotransmission.",
  "Correct — antitoxin neutralises free toxin and halts progression; the sooner it is given, the less damage becomes permanent.",
  "Antibiotics are useless in foodborne botulism, because the illness comes from preformed toxin rather than active infection.",
  "ICU admission and respiratory support are necessary but not sufficient alone; they do not alter the disease course."
 ],
 "golden_fa": "بوتولیسم: آنتی‌توکسین فوری (زمان‌محور) + پایش تنفسی. آنتی‌بیوتیک و استروئید نه.",
 "golden_en": "Botulism: immediate antitoxin (time-critical) plus respiratory monitoring. No antibiotics, no steroids.",
 "refs": [
  "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 153: Botulism",
  "CDC: botulinum antitoxin — early administration limits progression"
 ]
}

L["1403-12:106"] = {
 "style": "case", "difficulty": "medium",
 "stem_en": "A 30-year-old woman cuts her hand with a dirty knife while working in a kitchen and comes to the clinic. Her childhood vaccination is complete. Her last tetanus vaccine was 6 years ago. Which of the following is needed to prevent tetanus?",
 "options_en": ["Immunoglobulin and vaccine", "Immunoglobulin", "Toxoid and vaccine", "Wound cleaning and follow-up"],
 "micro": {
  "lead_fa": "پیشگیری کزاز یک جدول دو‌متغیره است: تعداد دوزهای قبلی و تمیز یا آلوده بودن زخم.",
  "lead_en": "Tetanus prophylaxis is a two-variable table: number of prior doses, and whether the wound is clean or dirty.",
  "points_fa": [
   "تصمیم‌گیری پیشگیری کزاز فقط به دو چیز بستگی دارد و باید هر دو را بسنجید.",
   "متغیر اول: آیا بیمار سه دوز یا بیشتر واکسن گرفته است؟",
   "متغیر دوم: زخم تمیز و سطحی است یا آلوده و عمیق؟",
   "اگر کمتر از سه دوز یا نامعلوم و زخم آلوده باشد: هم واکسن و هم ایمونوگلوبولین.",
   "اگر کمتر از سه دوز و زخم تمیز باشد: فقط واکسن.",
   "اگر سه دوز یا بیشتر و زخم تمیز: یادآور فقط اگر بیش از ۱۰ سال گذشته باشد.",
   "اگر سه دوز یا بیشتر و زخم آلوده: یادآور اگر بیش از ۵ سال گذشته باشد.",
   "ایمونوگلوبولین فقط برای کسانی است که ایمنی پایه ندارند.",
   "شستشو و دبریدمان زخم در همه‌ی موارد بخش جدایی‌ناپذیر پیشگیری است."
  ],
  "points_en": [
   "Tetanus prophylaxis depends on only two things and both must be assessed.",
   "First variable: has the patient had three or more vaccine doses?",
   "Second variable: is the wound clean and superficial, or dirty and deep?",
   "Fewer than three doses (or unknown) with a dirty wound: give both vaccine and immunoglobulin.",
   "Fewer than three doses with a clean wound: vaccine only.",
   "Three or more doses with a clean wound: booster only if over 10 years have passed.",
   "Three or more doses with a dirty wound: booster if over 5 years have passed.",
   "Immunoglobulin is only for those without baseline immunity.",
   "Wound cleaning and debridement are an inseparable part of prophylaxis in every case."
  ]
 },
 "explanation_fa": "این سؤال یک جدول ساده را می‌آزماید و اگر جدول را بدانید در چند ثانیه حل می‌شود. دو متغیر را از صورت سؤال بیرون بکشید. متغیر اول وضعیت ایمنی است: واکسیناسیون کودکی کامل بوده، یعنی بیمار سه دوز یا بیشتر گرفته و ایمنی پایه دارد. همین یک جمله ایمونوگلوبولین را کاملاً حذف می‌کند، چون ایمونوگلوبولین فقط برای کسی است که ایمنی پایه ندارد. متغیر دوم نوع زخم است: بریدگی با چاقوی آشپزخانه، هرچند «کثیف» توصیف شده، یک زخم تمیز و سطحی محسوب می‌شود؛ زخم آلوده در این طبقه‌بندی یعنی آغشته به خاک، مدفوع یا بزاق، له‌شدگی، سوختگی یا زخم عمیق نافذ. حالا با جدول تطبیق دهید: سه دوز یا بیشتر به‌علاوه‌ی زخم تمیز یعنی یادآور فقط پس از ۱۰ سال لازم است، و از آخرین دوز این بیمار فقط ۶ سال گذشته. پس هیچ مداخله‌ی ایمنی لازم نیست.",
 "explanation_en": "This item tests a simple table, and knowing the table solves it in seconds. Extract the two variables from the stem. The first is immune status: childhood vaccination was complete, so the patient has had three or more doses and has baseline immunity. That single fact eliminates immunoglobulin entirely, since immunoglobulin is only for those without baseline immunity. The second is the wound: a kitchen-knife cut, though described as dirty, counts as a clean superficial wound; a dirty wound in this classification means contaminated with soil, faeces or saliva, or a crush, burn or deep puncture. Now match the table: three or more doses plus a clean wound means a booster is needed only after 10 years, and only 6 years have passed. So no immune intervention is required.",
 "why_fa": [
  "ایمونوگلوبولین به‌همراه واکسن برای بیماری است که ایمنی پایه ندارد و زخم آلوده دارد؛ این بیمار واکسیناسیون کامل دارد.",
  "ایمونوگلوبولین به‌تنهایی هرگز در بیمار با ایمنی پایه‌ی کامل تجویز نمی‌شود.",
  "توکسوئید و واکسن در واقع یک چیزند و تکرار آن‌ها در بازه‌ی معتبر ۱۰ ساله لازم نیست.",
  "پاسخ صحیح — با واکسیناسیون کامل، زخم تمیز و فاصله‌ی ۶ سال (کمتر از ۱۰ سال)، فقط شستشوی زخم و پیگیری کافی است."
 ],
 "why_en": [
  "Immunoglobulin with vaccine is for a patient lacking baseline immunity who has a dirty wound; this patient is fully vaccinated.",
  "Immunoglobulin alone is never given to a patient with complete baseline immunity.",
  "Toxoid and vaccine are effectively the same thing, and repeating them inside the valid 10-year window is unnecessary.",
  "Correct — with complete vaccination, a clean wound and a 6-year interval (under 10 years), wound cleaning and follow-up suffice."
 ],
 "golden_fa": "زخم تمیز: یادآور بعد از ۱۰ سال. زخم آلوده: بعد از ۵ سال. ایمونوگلوبولین فقط بدون ایمنی پایه.",
 "golden_en": "Clean wound: booster after 10 years. Dirty wound: after 5. Immunoglobulin only without baseline immunity.",
 "refs": [
  "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 152: Tetanus",
  "CDC tetanus prophylaxis in routine wound management"
 ]
}

L["1403-12:107"] = {
 "style": "case", "difficulty": "medium",
 "stem_en": "A 60-year-old diabetic man presents with persistent fever, severe back pain, radiculopathy, weakness, numbness of the lower limbs and urinary incontinence. Lumbar MRI reports T1 enhancement in the intervertebral space and a microabscess in the epidural region. Blood culture grows a methicillin-resistant gram-positive bacterium. Which antibiotic is preferred?",
 "options_en": ["Cefepime", "Vancomycin", "Clindamycin", "Ciprofloxacin"],
 "micro": {
  "lead_fa": "«گرم‌مثبت مقاوم به متی‌سیلین» یعنی MRSA، و همه‌ی بتالاکتام‌ها یک‌جا حذف می‌شوند.",
  "lead_en": "\"Methicillin-resistant gram-positive\" means MRSA, which eliminates every beta-lactam at once.",
  "points_fa": [
   "آبسه‌ی اپی‌دورال نخاعی یک اورژانس عصبی-عفونی است و تأخیر آن فلج دائمی می‌سازد.",
   "سه‌گانه‌ی کلاسیک: تب، درد موضعی ستون فقرات، و نقص عصبی پیش‌رونده.",
   "عوامل خطر: دیابت، اعتیاد تزریقی، جراحی یا تزریق اپی‌دورال و باکتریمی.",
   "شایع‌ترین عامل استافیلوکوک اورئوس است و بخش زیادی از آن MRSA است.",
   "اغلب همراه با استئومیلیت مهره‌ای و دیسکیت دیده می‌شود، مثل همین بیمار.",
   "MRI با گادولینیوم روش تصویربرداری انتخابی است.",
   "مقاومت به متی‌سیلین یعنی ژن mecA و ناکارآمدی همه‌ی پنی‌سیلین‌ها و سفالوسپورین‌ها.",
   "وانکومایسین درمان انتخابی MRSA در عفونت‌های عمقی و سیستم عصبی است.",
   "درمان طولانی است، معمولاً شش تا هشت هفته، و گاهی تخلیه‌ی جراحی لازم می‌شود."
  ],
  "points_en": [
   "Spinal epidural abscess is a neuro-infectious emergency; delay causes permanent paralysis.",
   "The classic triad: fever, focal spinal pain and progressive neurological deficit.",
   "Risk factors: diabetes, injecting drug use, spinal surgery or epidural injection, and bacteraemia.",
   "The commonest organism is Staphylococcus aureus, a large share of it MRSA.",
   "It often accompanies vertebral osteomyelitis and discitis, as in this patient.",
   "Gadolinium-enhanced MRI is the imaging of choice.",
   "Methicillin resistance means the mecA gene and failure of all penicillins and cephalosporins.",
   "Vancomycin is the treatment of choice for MRSA in deep and central nervous system infections.",
   "Treatment is prolonged, usually six to eight weeks, and surgical drainage is sometimes needed."
  ]
 },
 "explanation_fa": "این سؤال طولانی به نظر می‌رسد ولی در واقع یک قدم دارد. همه‌ی جزئیات بالینی و تصویربرداری فقط برای ساختن تشخیص آبسه‌ی اپی‌دورال با استئومیلیت مهره‌ای است، اما تصمیم درمانی از یک عبارت واحد می‌آید: «باکتری گرم‌مثبت مقاوم به متی‌سیلین». این یعنی MRSA. مقاومت به متی‌سیلین از ژن mecA می‌آید که پروتئین متصل‌شونده به پنی‌سیلین را تغییر می‌دهد، و نتیجه‌اش این است که تمام خانواده‌ی بتالاکتام از پنی‌سیلین‌ها تا سفالوسپورین‌های نسل چهارم مثل سفپیم بی‌اثر می‌شوند. پس گزینه‌ی سفپیم بلافاصله حذف است. میان سه گزینه‌ی باقی‌مانده، وانکومایسین درمان استاندارد MRSA است و مزیت مهمش نفوذ قابل قبول به سیستم عصبی مرکزی و بافت عمقی است. کلیندامایسین برای عفونت عمقی استخوان و آبسه به‌تنهایی قابل اتکا نیست و سیپروفلوکساسین پوشش مطمئنی روی MRSA ندارد.",
 "explanation_en": "The item looks long but has only one step. All the clinical and imaging detail exists to build the diagnosis of epidural abscess with vertebral osteomyelitis, but the treatment decision comes from a single phrase: methicillin-resistant gram-positive bacterium. That means MRSA. Methicillin resistance arises from the mecA gene, which alters the penicillin-binding protein, and the result is that the entire beta-lactam family, from penicillins to fourth-generation cephalosporins such as cefepime, becomes ineffective. So cefepime is eliminated immediately. Among the remaining three, vancomycin is the standard MRSA treatment, and its key advantage is acceptable penetration into the central nervous system and deep tissue. Clindamycin is not reliable alone for deep bone infection and abscess, and ciprofloxacin gives no dependable MRSA cover.",
 "why_fa": [
  "سفپیم یک سفالوسپورین نسل چهارم است و مثل همه‌ی بتالاکتام‌ها در برابر MRSA بی‌اثر است.",
  "پاسخ صحیح — وانکومایسین درمان انتخابی MRSA در آبسه‌ی اپی‌دورال و استئومیلیت است و نفوذ کافی به بافت عمقی و CNS دارد.",
  "کلیندامایسین گاهی روی MRSA اکتسابی از جامعه اثر دارد اما برای آبسه‌ی اپی‌دورال و عفونت استخوان به‌تنهایی قابل اتکا نیست.",
  "سیپروفلوکساسین پوشش قابل اطمینانی روی استافیلوکوک اورئوس مقاوم ندارد و مقاومت به آن سریع ایجاد می‌شود."
 ],
 "why_en": [
  "Cefepime is a fourth-generation cephalosporin and, like every beta-lactam, is ineffective against MRSA.",
  "Correct — vancomycin is the treatment of choice for MRSA epidural abscess and osteomyelitis, with adequate deep-tissue and CNS penetration.",
  "Clindamycin sometimes works against community-acquired MRSA but is not reliable alone for epidural abscess and bone infection.",
  "Ciprofloxacin gives no dependable cover against resistant Staphylococcus aureus and resistance emerges quickly."
 ],
 "golden_fa": "مقاوم به متی‌سیلین = MRSA = هیچ بتالاکتامی. آبسه‌ی اپی‌دورال = وانکومایسین طولانی‌مدت.",
 "golden_en": "Methicillin-resistant means MRSA and no beta-lactam; epidural abscess means prolonged vancomycin.",
 "refs": [
  "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 147: Staphylococcal Infections",
  "Harrison's 21st ed — Ch. 130: Infectious Arthritis and osteomyelitis; spinal epidural abscess"
 ]
}

L["1403-12:108"] = {
 "style": "case", "difficulty": "medium",
 "stem_en": "A 58-year-old man with a history of long-term alcohol use and very poor oral hygiene presents with fever, productive cough and foul-smelling sputum. Chest X-ray shows a cavity with an air-fluid level plus consolidation in the right lower lobe. Which mechanism caused this condition?",
 "options_en": ["Haematogenous spread of bacteria to the lung",
                "Aspiration of oropharyngeal secretions",
                "Abscess from bronchial obstruction by a tumour",
                "Reactivation of latent TB due to immune weakness"],
 "micro": {
  "lead_fa": "خلط بدبو + بهداشت بد دهان + الکل + لوب تحتانی راست = آبسه‌ی ریه از آسپیراسیون.",
  "lead_en": "Foul sputum plus poor oral hygiene plus alcohol plus right lower lobe means aspiration lung abscess.",
  "points_fa": [
   "آبسه‌ی ریه در تصویربرداری با کاویته و سطح مایع-هوا مشخص می‌شود.",
   "شایع‌ترین مکانیسم، آسپیراسیون ترشحات اوروفارنکس است.",
   "بوی بسیار بد خلط تقریباً اختصاصی باکتری‌های بی‌هوازی دهانی است.",
   "بهداشت بد دهان و دندان، بار باکتریایی اوروفارنکس را چند برابر می‌کند.",
   "الکلیسم با کاهش هوشیاری و مهار رفلکس سرفه، آسپیراسیون را ممکن می‌سازد.",
   "عوامل خطر دیگر: تشنج، سکته، بیهوشی، اختلال بلع و لوله‌گذاری.",
   "محل ضایعه به وضعیت بدن هنگام آسپیراسیون بستگی دارد.",
   "در وضعیت خوابیده، سگمان خلفی لوب فوقانی و سگمان فوقانی لوب تحتانی درگیر می‌شود.",
   "سمت راست شایع‌تر است چون برونش اصلی راست عمودی‌تر، کوتاه‌تر و پهن‌تر است."
  ],
  "points_en": [
   "A lung abscess appears on imaging as a cavity with an air-fluid level.",
   "The commonest mechanism is aspiration of oropharyngeal secretions.",
   "Very foul-smelling sputum is nearly specific for oral anaerobes.",
   "Poor dental hygiene multiplies the oropharyngeal bacterial load.",
   "Alcoholism enables aspiration by reducing consciousness and suppressing the cough reflex.",
   "Other risk factors: seizures, stroke, anaesthesia, swallowing disorders and intubation.",
   "The site depends on body position at the time of aspiration.",
   "When supine, the posterior segment of the upper lobe and superior segment of the lower lobe are affected.",
   "The right side is commoner because the right main bronchus is more vertical, shorter and wider."
  ]
 },
 "explanation_fa": "سؤال مکانیسم را می‌پرسد نه تشخیص را، پس باید از یافته‌ها به مسیر بیماری‌زایی برسید. تشخیص از تصویربرداری روشن است: کاویته با سطح مایع-هوا یعنی آبسه‌ی ریه. حالا سه سرنخ مکانیسم را قطعی می‌کنند. اول، خلط «بسیار بدبو» که تقریباً امضای باکتری‌های بی‌هوازی دهانی است و هیچ مکانیسم دیگری آن را توضیح نمی‌دهد. دوم، بهداشت بسیار ضعیف دهان و دندان که همان مخزن این باکتری‌هاست؛ بدون آن، آسپیراسیون هم معمولاً آبسه نمی‌سازد. سوم، الکلیسم مزمن که با کاهش دوره‌ای سطح هوشیاری و مهار رفلکس سرفه، راه ورود ترشحات به ریه را باز می‌کند. محل ضایعه هم مهر تأیید می‌زند: لوب تحتانی راست، چون برونش اصلی راست عمودی‌تر و پهن‌تر است و ترشحات آسپیره‌شده ترجیحاً به آن سمت می‌روند. سه گزینه‌ی دیگر هر کدام الگوی رادیولوژیک متفاوتی می‌سازند.",
 "explanation_en": "The question asks for the mechanism, not the diagnosis, so you must reason from the findings to the pathogenesis. The diagnosis is clear from imaging: a cavity with an air-fluid level means lung abscess. Three clues then settle the mechanism. First, the very foul-smelling sputum, nearly a signature of oral anaerobes, which no other mechanism explains. Second, the very poor dental hygiene, which is the reservoir of those organisms; without it, aspiration usually does not produce an abscess. Third, chronic alcohol use, which opens the route by periodically reducing consciousness and suppressing the cough reflex. The site confirms it: the right lower lobe, because the right main bronchus is more vertical and wider so aspirated secretions preferentially travel there. Each of the other three options would produce a different radiological pattern.",
 "why_fa": [
  "گسترش خونی باکتری‌ها معمولاً ضایعات متعدد، محیطی و دوطرفه می‌سازد، نه یک کاویته‌ی منفرد در لوب تحتانی راست.",
  "پاسخ صحیح — خلط بدبو، بهداشت بد دهان، الکلیسم و محل لوب تحتانی راست، همگی به آسپیراسیون ترشحات اوروفارنکس اشاره دارند.",
  "آبسه‌ی ناشی از انسداد تومورال معمولاً در فرد سیگاری با کاهش وزن و بدون بوی بد خلط دیده می‌شود و نیازمند بررسی برونکوسکوپی است.",
  "سل فعال‌شده بیشتر سگمان‌های آپیکال و خلفی لوب فوقانی را درگیر می‌کند و خلط بدبو از ویژگی‌های آن نیست."
 ],
 "why_en": [
  "Haematogenous spread usually produces multiple peripheral bilateral lesions, not a single right-lower-lobe cavity.",
  "Correct — foul sputum, poor oral hygiene, alcoholism and a right-lower-lobe location all point to aspiration of oropharyngeal secretions.",
  "An abscess from tumour obstruction is typically seen in a smoker with weight loss and without foul sputum, and needs bronchoscopy.",
  "Reactivated TB mainly involves the apical and posterior segments of the upper lobe, and foul sputum is not a feature."
 ],
 "golden_fa": "خلط بدبو = بی‌هوازی دهانی = آسپیراسیون. راست شایع‌تر چون برونش راست عمودی‌تر است.",
 "golden_en": "Foul sputum means oral anaerobes and aspiration; the right side is commoner because the right bronchus is more vertical.",
 "refs": [
  "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 127: Lung Abscess",
  "Harrison's 21st ed — Ch. 126: Pneumonia, aspiration and anaerobic infection"
 ]
}

json.dump(L, io.open('/home/user/work/infectious/lessons/L2.json','w',encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('infectious L2:', len(L))
