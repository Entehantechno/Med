# -*- coding: utf-8 -*-
"""Micro-lessons, batch 26 — meningitis: the order of actions and the CSF panel.

The first half of the central nervous system chapter, and the most
algorithmically uniform block in the whole book. Fourteen questions ask "what
do you do first?" and eleven show a CSF panel and ask "which organism?". Both
reduce to a single decision tree each, and a student who learns the two trees
answers twenty-five questions with two pieces of knowledge.

TREE ONE — THE ORDER OF ACTIONS
The examiners test one rule above all others: ANTIBIOTICS MUST NEVER WAIT FOR
IMAGING. The sequence depends on whether a CT is needed at all:

  NO indication for CT  ->  blood culture -> LUMBAR PUNCTURE -> antibiotics
  CT indicated          ->  blood culture -> ANTIBIOTICS -> CT -> LP

And the six indications for CT before LP are a fixed list worth memorising,
because every one of them appears in a stem somewhere in this chapter.

TREE TWO — READING THE CSF
Three patterns, separated by the cell type and the glucose. The glucose is the
discriminator students most often skip, and it is the one that separates
bacterial from viral and tuberculous from viral.

A note on why this chapter's numbers were repaired first
--------------------------------------------------------
In meningitis the CSF panel IS the diagnosis, so a mirrored glucose moves the
patient between bacterial and viral and inverts the answer. Eighteen numbers in
this chapter were repaired from glyph geometry before these lessons were
written; see fix_cns_numbers.py.

Reference: Tunkel AR et al., "Practice Guidelines for the Management of
Bacterial Meningitis", Clin Infect Dis 2004;39:1267-1284; van de Beek D et al.,
"Dexamethasone in Adults with Bacterial Meningitis", N Engl J Med
2002;347:1549-1556; Harrison's Principles of Internal Medicine, 21st ed (2022),
Ch. 133 (Meningitis, Encephalitis, Brain Abscess and Empyema).
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


TUNKEL = ("Tunkel AR et al. — Practice Guidelines for the Management of Bacterial Meningitis. "
          "Clin Infect Dis 2004;39(9):1267-1284 (Infectious Diseases Society of America)")
BEEK = ("van de Beek D et al. — Dexamethasone in Adults with Bacterial Meningitis. "
        "N Engl J Med 2002;347(20):1549-1556")
H133 = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 133: Meningitis, "
        "Encephalitis, Brain Abscess and Empyema")

ORDER_FA = [
    "⚠️ **مهم‌ترین قاعده‌ی کل این فصل: آنتی‌بیوتیک هرگز منتظر تصویربرداری نمی‌ماند.**",
    "**در مننژیت باکتریال، هر ساعت تأخیر در آنتی‌بیوتیک، مرگ‌ومیر را بالا می‌برد.**",
    "**اول تصمیم بگیرید: آیا این بیمار پیش از LP نیاز به سی‌تی‌اسکن دارد؟**",
    "⚠️ **شش اندیکاسیون سی‌تی پیش از LP را حفظ کنید — همه‌شان در همین فصل پرسیده شده‌اند:**",
    "**یک — کاهش سطح هوشیاری** (اختلال هوشیاری متوسط تا شدید).",
    "**دو — نقص نورولوژیک فوکال** (همی‌پارزی، فلج نگاه، آفازی).",
    "**سه — ادم پاپی** در فوندوسکوپی.",
    "**چهار — تشنج تازه** (در یک هفته‌ی اخیر).",
    "**پنج — نقص ایمنی شدید** (HIV، شیمی‌درمانی، پیوند، داروی سرکوبگر).",
    "**شش — سابقه‌ی بیماری سیستم عصبی مرکزی** (توده، سکته، عفونت کانونی).",
    "⚠️ **حالا دو مسیر، و تفاوتشان فقط در جای LP است:**",
    "**اگر هیچ‌یک از شش مورد نبود:** **کشت خون ← LP ← آنتی‌بیوتیک + دگزامتازون**.",
    "**اگر یکی از شش مورد بود:** **کشت خون ← آنتی‌بیوتیک + دگزامتازون ← سی‌تی ← LP**.",
    "**در هر دو مسیر، کشت خون اول است** و **بیش از نیمی از موارد مثبت می‌شود**.",
    "⚠️ **و نکته‌ای که نگرانی را برطرف می‌کند: آنتی‌بیوتیک، CSF را بی‌فایده نمی‌کند.**",
    "**شمارش سلولی، قند و پروتئین تا ساعت‌ها تغییر معناداری نمی‌کنند**؛",
    "فقط **کشت** ممکن است منفی شود — و آن هم در پنوموکوک تا حدود ۴ ساعت مثبت می‌ماند.",
    "**دگزامتازون: ۱۰ میلی‌گرم هر ۶ ساعت، ۴ روز.**",
    "⚠️ **زمان‌بندی‌اش حیاتی است: پیش از اولین دوز آنتی‌بیوتیک یا هم‌زمان با آن.**",
    "**چرا؟** چون لیز باکتری، التهاب را شعله‌ور می‌کند و استروئید باید **از قبل** آنجا باشد.",
    "**پس از شروع آنتی‌بیوتیک، دگزامتازون دیگر سودی ندارد.**",
    "**بیشترین فایده‌اش در مننژیت پنوموکوکی است: کاهش ناشنوایی و مرگ‌ومیر.**",
]
ORDER_EN = [
    "WARNING, THE MOST IMPORTANT RULE OF THIS CHAPTER: ANTIBIOTICS NEVER WAIT FOR IMAGING.",
    "In bacterial meningitis every hour of antibiotic delay raises mortality.",
    "FIRST DECIDE: DOES THIS PATIENT NEED A CT BEFORE THE LUMBAR PUNCTURE?",
    "WARNING, MEMORISE THE SIX INDICATIONS FOR CT BEFORE LP — every one appears in a stem in this chapter:",
    "ONE — A REDUCED LEVEL OF CONSCIOUSNESS (moderate to severe impairment).",
    "TWO — A FOCAL NEUROLOGICAL DEFICIT (hemiparesis, gaze palsy, aphasia).",
    "THREE — PAPILLOEDEMA on fundoscopy.",
    "FOUR — A NEW SEIZURE (within the past week).",
    "FIVE — SEVERE IMMUNOCOMPROMISE (HIV, chemotherapy, transplant, immunosuppressants).",
    "SIX — A HISTORY OF CNS DISEASE (mass, stroke, focal infection).",
    "WARNING, NOW TWO PATHWAYS, differing only in where the LP sits:",
    "IF NONE OF THE SIX APPLY: BLOOD CULTURE, then LP, then ANTIBIOTICS PLUS DEXAMETHASONE.",
    "IF ANY OF THE SIX APPLY: BLOOD CULTURE, then ANTIBIOTICS PLUS DEXAMETHASONE, then CT, then LP.",
    "IN BOTH PATHWAYS THE BLOOD CULTURE COMES FIRST, and it is positive in MORE THAN HALF of cases.",
    "WARNING, AND THE POINT THAT ANSWERS THE USUAL WORRY: ANTIBIOTICS DO NOT MAKE THE CSF USELESS.",
    "THE CELL COUNT, GLUCOSE AND PROTEIN DO NOT CHANGE MEANINGFULLY FOR HOURS;",
    "only the CULTURE may turn negative — and even that stays positive for about 4 hours in pneumococcus.",
    "DEXAMETHASONE: 10 MG EVERY 6 HOURS FOR 4 DAYS.",
    "WARNING, ITS TIMING IS CRITICAL: BEFORE THE FIRST ANTIBIOTIC DOSE OR WITH IT.",
    "Why? Because bacterial lysis ignites inflammation, and the steroid must ALREADY be there.",
    "GIVEN AFTER THE ANTIBIOTIC, DEXAMETHASONE NO LONGER HELPS.",
    "Its greatest benefit is in PNEUMOCOCCAL meningitis: reduced deafness and reduced mortality.",
]

CSF_FA = [
    "⚠️ **در مننژیت، پنل مایع نخاع خودِ تشخیص است. سه الگو را حفظ کنید:**",
    "**باکتریال:** سلول **صدها تا هزاران**، غلبه‌ی **نوتروفیل**،",
    "⚠️ **قند پایین** (نسبت CSF به سرم زیر ۰٫۴)، **پروتئین بالا**.",
    "**ویروسی:** سلول **ده‌ها تا صدها**، غلبه‌ی **لنفوسیت**،",
    "⚠️ **قند طبیعی** (این مهم‌ترین ممیز است)، پروتئین **مختصر بالا**.",
    "**سلی یا قارچی:** سلول **ده‌ها تا صدها**، غلبه‌ی **لنفوسیت**،",
    "⚠️ **قند پایین** و **پروتئین بسیار بالا** (اغلب بالای ۱۵۰ و گاهی چند صد).",
    "**پس منطق تشخیص دو گام دارد:**",
    "**گام یک — نوع سلول:** نوتروفیل ← باکتریال. لنفوسیت ← ویروسی یا سلی/قارچی.",
    "**گام دو — قند:** اگر لنفوسیتی است، **قند طبیعی یعنی ویروسی، قند پایین یعنی سلی/قارچی**.",
    "⚠️ **همیشه قند خون هم‌زمان را بخواهید** — قند CSF به‌تنهایی معنا ندارد.",
    "**نسبت طبیعی CSF به سرم حدود ۰٫۶ است؛ زیر ۰٫۴ قویاً به نفع باکتریال یا سلی است.**",
    "**فشار باز شدن طبیعی: ۸ تا ۲۰ سانتی‌متر آب** (۸۰ تا ۲۰۰ میلی‌متر).",
    "**دو استثنای مهم که باید بشناسید:**",
    "⚠️ **یک — در ساعات اولیه‌ی مننژیت ویروسی، ممکن است نوتروفیل غالب باشد**",
    "و ظرف ۲۴ تا ۴۸ ساعت به لنفوسیت تغییر کند. پس زمان بیماری را در نظر بگیرید.",
    "**دو — در مننژیت باکتریالِ نیمه‌درمان‌شده، تصویر می‌تواند لنفوسیتی شود.**",
    "**و یک یافته‌ی افتراقی طلایی: گلبول قرمز در CSF بدون تروما.**",
    "⚠️ **در انسفالیت هرپسی، نکروز خونریزی‌دهنده‌ی لوب تمپورال گلبول قرمز وارد CSF می‌کند.**",
]
CSF_EN = [
    "WARNING: IN MENINGITIS THE CSF PANEL IS THE DIAGNOSIS. MEMORISE THREE PATTERNS:",
    "BACTERIAL: HUNDREDS TO THOUSANDS of cells, NEUTROPHIL predominant,",
    "WARNING, LOW GLUCOSE (CSF-to-serum ratio below 0.4), HIGH PROTEIN.",
    "VIRAL: TENS TO HUNDREDS of cells, LYMPHOCYTE predominant,",
    "WARNING, NORMAL GLUCOSE (this is the key discriminator), MILDLY raised protein.",
    "TUBERCULOUS OR FUNGAL: TENS TO HUNDREDS of cells, LYMPHOCYTE predominant,",
    "WARNING, LOW GLUCOSE and VERY HIGH PROTEIN (often above 150, sometimes several hundred).",
    "SO THE DIAGNOSTIC LOGIC HAS TWO STEPS:",
    "STEP ONE — THE CELL TYPE: neutrophils mean bacterial; lymphocytes mean viral or TB/fungal.",
    "STEP TWO — THE GLUCOSE: if lymphocytic, NORMAL GLUCOSE MEANS VIRAL, LOW GLUCOSE MEANS TB OR FUNGAL.",
    "WARNING, ALWAYS ASK FOR A SIMULTANEOUS BLOOD GLUCOSE — a CSF glucose alone means nothing.",
    "THE NORMAL CSF-TO-SERUM RATIO IS ABOUT 0.6; BELOW 0.4 STRONGLY FAVOURS BACTERIAL OR TUBERCULOUS.",
    "NORMAL OPENING PRESSURE: 8 TO 20 CM OF WATER (80 to 200 mm).",
    "TWO IMPORTANT EXCEPTIONS TO KNOW:",
    "WARNING, ONE — IN THE FIRST HOURS OF VIRAL MENINGITIS NEUTROPHILS MAY PREDOMINATE,",
    "shifting to lymphocytes within 24 to 48 hours. So consider how long the illness has lasted.",
    "TWO — IN PARTIALLY TREATED BACTERIAL MENINGITIS THE PICTURE CAN BECOME LYMPHOCYTIC.",
    "AND A GOLDEN DISCRIMINATING FINDING: RED CELLS IN THE CSF WITHOUT A TRAUMATIC TAP.",
    "WARNING: IN HERPES ENCEPHALITIS, HAEMORRHAGIC NECROSIS OF THE TEMPORAL LOBE PUTS RED CELLS INTO THE CSF.",
]


# =========================================================== book:143
add("book:143", "case", "medium",
 "بیمار **هوشیار، بدون نقص فوکال و بدون ادم پاپی** ← سی‌تی لازم نیست ← **کشت خون، آنتی‌بیوتیک، LP**.",
 "An ALERT patient with NO FOCAL DEFICIT AND NO PAPILLOEDEMA needs no CT: BLOOD CULTURE, ANTIBIOTICS, LP.",
 ORDER_FA + [
  "این سؤال ساده‌ترین شکل الگوریتم است، و باید مثل یک رفلکس پاسخ داده شود.",
  "**سه جمله‌ی کلیدی در صورت سؤال:** «کاملاً هوشیار»، «فاقد اختلال نورولوژیک موضعی»، «فاقد ادم پاپی».",
  "⚠️ **هر سه، نفیِ اندیکاسیون‌های سی‌تی هستند** — یعنی صورت سؤال عمداً می‌گوید سی‌تی لازم نیست.",
  "**پس مسیر ساده است: کشت خون ← آنتی‌بیوتیک ← LP.**",
  "**و توجه کنید که هیچ گزینه‌ای سی‌تی‌اسکن ندارد در گزینه‌ی درست** — که کاملاً منطقی است.",
  "**سه گزینه‌ی دیگر همگی سی‌تی‌اسکن را وارد مسیر می‌کنند، و هر سه غلط‌اند:**",
  "⚠️ **سی‌تی در بیماری که هیچ اندیکاسیونی ندارد، فقط وقت می‌سوزاند** —",
  "و در مننژیت باکتریال، وقت همان چیزی است که بیمار ندارد.",
  "**مطالعات نشان داده‌اند سی‌تی پیش از LP، زمان تا آنتی‌بیوتیک را ۲ تا ۳ ساعت طولانی می‌کند.**",
  "⚠️ **و یک نکته‌ی ظریف: چرا در این مسیر هم آنتی‌بیوتیک پیش از LP آمده؟**",
  "چون در عمل، **حتی LP هم می‌تواند دقایقی طول بکشد** و راهنما اجازه می‌دهد",
  "آنتی‌بیوتیک بلافاصله پس از کشت خون شروع شود اگر LP فوراً ممکن نباشد.",
  "**در بیمار کاملاً پایدار، LP پیش از آنتی‌بیوتیک هم پذیرفته است** — نکته این است که **تأخیر نیفتد**.",
  "**و دگزامتازون را فراموش نکنید: هم‌زمان یا پیش از اولین دوز آنتی‌بیوتیک.**",
 ],
 ORDER_EN + [
  "This is the algorithm in its simplest form and should be answered as a reflex.",
  "THREE KEY PHRASES IN THE STEM: 'fully alert', 'no focal neurological deficit', 'no papilloedema'.",
  "WARNING: ALL THREE ARE NEGATIONS OF THE CT INDICATIONS — the stem is deliberately saying no CT is needed.",
  "SO THE PATH IS SIMPLE: BLOOD CULTURE, then ANTIBIOTICS, then LP.",
  "And note that the correct option contains NO CT at all, which is entirely logical.",
  "THE OTHER THREE OPTIONS ALL INSERT A CT INTO THE PATH, AND ALL THREE ARE WRONG:",
  "WARNING: A CT IN A PATIENT WITH NO INDICATION MERELY BURNS TIME —",
  "and in bacterial meningitis, time is exactly what the patient does not have.",
  "STUDIES SHOW THAT CT BEFORE LP LENGTHENS TIME TO ANTIBIOTICS BY 2 TO 3 HOURS.",
  "WARNING, AND A SUBTLE POINT: why do antibiotics precede the LP even here?",
  "Because in practice EVEN AN LP CAN TAKE SOME MINUTES, and the guideline permits",
  "antibiotics immediately after blood cultures if the LP cannot be done at once.",
  "IN A FULLY STABLE PATIENT, LP BEFORE ANTIBIOTICS IS ALSO ACCEPTED — the point is THAT THERE IS NO DELAY.",
  "AND DO NOT FORGET DEXAMETHASONE: with, or just before, the first antibiotic dose.",
 ],
 "این سؤال ساده‌ترین شکل الگوریتم است و باید مثل یک **رفلکس** پاسخ داده شود.\n\n"
 "**سه جمله‌ی کلیدی در صورت سؤال را ببینید:** «بیمار **کاملاً هوشیار** بوده»، «**فاقد اختلال نورولوژیک موضعی**»، «**فاقد ادم پاپی**».\n\n"
 "⚠️ **هر سه، دقیقاً نفیِ اندیکاسیون‌های سی‌تی‌اسکن هستند.** یعنی صورت سؤال عمداً به شما می‌گوید که این بیمار **نیازی به تصویربرداری پیش از LP ندارد**.\n\n"
 "**شش اندیکاسیون سی‌تی پیش از LP را به یاد بیاورید:**\n\n"
 "کاهش سطح هوشیاری · نقص نورولوژیک فوکال · **ادم پاپی** · تشنج تازه · نقص ایمنی شدید · سابقه‌ی بیماری CNS\n\n"
 "**هیچ‌کدام اینجا نیست. پس مسیر: کشت خون ← شروع آنتی‌بیوتیک ← LP.**\n\n"
 "**چرا سه گزینه‌ی دیگر رد می‌شوند؟** هر سه **سی‌تی‌اسکن را وارد مسیر می‌کنند**، و در بیماری که هیچ اندیکاسیونی ندارد این فقط **وقت می‌سوزاند**. ⚠️ مطالعات نشان داده‌اند که سی‌تی پیش از LP، **زمان تا اولین دوز آنتی‌بیوتیک را ۲ تا ۳ ساعت طولانی می‌کند** — و در مننژیت باکتریال، هر ساعت تأخیر مرگ‌ومیر را بالا می‌برد.\n\n"
 "⚠️ **و نگرانی رایجی که باید برطرف شود:** «اگر آنتی‌بیوتیک پیش از LP بدهیم، جواب CSF خراب نمی‌شود؟» **خیر.** **شمارش سلولی، قند و پروتئین تا ساعت‌ها تغییر معناداری نمی‌کنند.** فقط **کشت** ممکن است منفی شود، و آن هم در پنوموکوک تا حدود **۴ ساعت** مثبت می‌ماند. **هرگز آنتی‌بیوتیک را برای حفظ کشت به تأخیر نیندازید.**\n\n"
 "**و دگزامتازون را فراموش نکنید:** ۱۰ میلی‌گرم هر ۶ ساعت به مدت ۴ روز، **هم‌زمان یا اندکی پیش از اولین دوز آنتی‌بیوتیک** — چون پس از شروع آنتی‌بیوتیک دیگر سودی ندارد.",
 "This is the algorithm in its simplest form and should be answered as a REFLEX.\n\n"
 "LOOK AT THE THREE KEY PHRASES IN THE STEM: the patient is 'FULLY ALERT', has 'NO FOCAL NEUROLOGICAL DEFICIT', and has 'NO PAPILLOEDEMA'.\n\n"
 "WARNING: ALL THREE ARE PRECISELY NEGATIONS OF THE CT INDICATIONS. The stem is deliberately telling you this patient NEEDS NO IMAGING BEFORE LP.\n\n"
 "RECALL THE SIX INDICATIONS FOR CT BEFORE LP:\n\n"
 "Reduced consciousness · Focal neurological deficit · PAPILLOEDEMA · New seizure · Severe immunocompromise · History of CNS disease\n\n"
 "NONE IS PRESENT. So the path is: BLOOD CULTURE, then ANTIBIOTICS, then LP.\n\n"
 "WHY DO THE OTHER THREE FAIL? All three INSERT A CT into the path, and in a patient with no indication that merely BURNS TIME. WARNING, studies show CT before LP LENGTHENS TIME TO THE FIRST ANTIBIOTIC DOSE BY 2 TO 3 HOURS — and in bacterial meningitis every hour of delay raises mortality.\n\n"
 "WARNING, AND A COMMON WORRY TO SETTLE: 'if we give antibiotics before the LP, will the CSF result be ruined?' NO. THE CELL COUNT, GLUCOSE AND PROTEIN DO NOT CHANGE MEANINGFULLY FOR HOURS. Only the CULTURE may turn negative, and even that stays positive for about FOUR HOURS in pneumococcus. NEVER DELAY ANTIBIOTICS TO PRESERVE A CULTURE.\n\n"
 "AND DO NOT FORGET DEXAMETHASONE: 10 mg every 6 hours for 4 days, WITH OR JUST BEFORE the first antibiotic dose — because after the antibiotic it no longer helps.",
 ["سی‌تی‌اسکن در بیمار بدون اندیکاسیون فقط وقت می‌سوزاند و آنتی‌بیوتیک را به تأخیر می‌اندازد.",
  "کشت خون درست است ولی سی‌تی‌اسکن پیش از LP در این بیمار اندیکاسیون ندارد.",
  "شروع آنتی‌بیوتیک پیش از کشت خون، شانس شناسایی ارگانیسم را بی‌جهت کم می‌کند.",
  "پاسخ صحیح — بیمار هوشیار بدون نقص فوکال و ادم پاپی: کشت خون، آنتی‌بیوتیک، سپس LP."],
 ["A CT in a patient with no indication merely burns time and delays antibiotics.",
  "Blood culture is right, but CT before LP is not indicated in this patient.",
  "Starting antibiotics before blood cultures needlessly reduces the chance of identifying the organism.",
  "Correct — an alert patient without focal deficit or papilloedema: blood culture, antibiotics, then LP."],
 "بدون اندیکاسیون سی‌تی ← **کشت خون ← LP/آنتی‌بیوتیک**. سی‌تی بی‌مورد = **۲ تا ۳ ساعت تأخیر**.",
 "With no CT indication: blood culture, then LP and antibiotics. An unnecessary CT costs 2 to 3 hours.",
 [TUNKEL, H133])


# =========================================================== book:145
add("book:145", "case", "hard",
 "**ادم پاپی + تشنج** ← سی‌تی لازم است ← **کشت خون، آنتی‌بیوتیک، سی‌تی** (و LP بعد از آن).",
 "PAPILLOEDEMA plus SEIZURES means a CT is needed: BLOOD CULTURE, ANTIBIOTICS, CT (and LP after).",
 ORDER_FA + [
  "این سؤال آینه‌ی سؤال قبلی است، و **دو اندیکاسیون سی‌تی** را هم‌زمان دارد:",
  "**یک — سابقه‌ی تشنج.** **دو — ادم پاپی در فوندوسکوپی.**",
  "به‌علاوه‌ی **خواب‌آلودگی**، که خودش سومین اندیکاسیون است.",
  "⚠️ **پس این بیمار حتماً پیش از LP نیاز به سی‌تی دارد — و همین‌جا خطر شکل می‌گیرد.**",
  "**چرا ادم پاپی مانع LP است؟** چون نشانه‌ی **افزایش فشار داخل جمجمه** است،",
  "و برداشتن مایع از فضای لومبار می‌تواند **گرادیان فشاری** ایجاد کند",
  "که مغز را به سمت پایین می‌راند: **فتق مغزی (herniation)**.",
  "**اما اینجاست که تله‌ی سؤال است: اگر منتظر سی‌تی بمانیم، آنتی‌بیوتیک عقب می‌افتد.**",
  "⚠️ **راه‌حل راهنما: آنتی‌بیوتیک را پیش از فرستادن بیمار به سی‌تی شروع کنید.**",
  "**پس ترتیب درست: کشت خون ← آنتی‌بیوتیک (+ دگزامتازون) ← سی‌تی‌اسکن ← و در صورت اجازه، LP.**",
  "**دو گزینه‌ای که LP را اول گذاشته‌اند، در بیمار با ادم پاپی خطرناک‌اند.**",
  "**و گزینه‌ای که سی‌تی را پیش از آنتی‌بیوتیک گذاشته، تأخیر درمانی می‌سازد.**",
  "⚠️ **نکته‌ی مهم: سی‌تی طبیعی، فتق را کاملاً رد نمی‌کند.**",
  "پس اگر شک بالینی به فشار بالا زیاد باشد، ممکن است LP اصلاً انجام نشود",
  "و درمان بر پایه‌ی **کشت خون** پیش برود — که در بیش از نیمی از موارد مثبت است.",
 ],
 ORDER_EN + [
  "This question mirrors the previous one and has TWO CT INDICATIONS at once:",
  "ONE — A HISTORY OF SEIZURES. TWO — PAPILLOEDEMA on fundoscopy.",
  "Plus DROWSINESS, which is itself a third indication.",
  "WARNING: SO THIS PATIENT DEFINITELY NEEDS A CT BEFORE LP — and that is where the danger arises.",
  "WHY DOES PAPILLOEDEMA PRECLUDE LP? Because it signals RAISED INTRACRANIAL PRESSURE,",
  "and removing fluid from the lumbar space can create A PRESSURE GRADIENT",
  "that drives the brain downwards: HERNIATION.",
  "BUT HERE IS THE TRAP: IF WE WAIT FOR THE CT, THE ANTIBIOTIC IS DELAYED.",
  "WARNING, THE GUIDELINE'S SOLUTION: START ANTIBIOTICS BEFORE SENDING THE PATIENT FOR THE CT.",
  "SO THE CORRECT ORDER IS: BLOOD CULTURE, ANTIBIOTICS (plus dexamethasone), CT, then LP if permitted.",
  "THE TWO OPTIONS PUTTING LP FIRST ARE DANGEROUS IN A PATIENT WITH PAPILLOEDEMA.",
  "AND THE OPTION PUTTING CT BEFORE ANTIBIOTICS CREATES A TREATMENT DELAY.",
  "WARNING, AN IMPORTANT POINT: A NORMAL CT DOES NOT COMPLETELY EXCLUDE HERNIATION.",
  "So if clinical suspicion of raised pressure is high, the LP may not be done at all",
  "and treatment proceeds on the BLOOD CULTURE — positive in more than half of cases.",
 ],
 "این سؤال **آینه‌ی سؤال قبلی** است، و مقایسه‌ی این دو بهترین راه یادگیری کل الگوریتم است.\n\n"
 "**این بیمار دو (در واقع سه) اندیکاسیون سی‌تی دارد:**\n\n"
 "**۱. سابقه‌ی تشنج** · **۲. ادم پاپی در فوندوسکوپی** · **۳. خواب‌آلودگی**\n\n"
 "⚠️ **پس حتماً پیش از LP نیاز به سی‌تی‌اسکن دارد.**\n\n"
 "**چرا ادم پاپی مانع LP است؟** چون نشانه‌ی **افزایش فشار داخل جمجمه** است. برداشتن مایع از فضای لومبار می‌تواند یک **گرادیان فشاری** بسازد که مغز را به سمت سوراخ مگنوم می‌راند — یعنی **فتق مغزی**، که کشنده است.\n\n"
 "**اما اینجاست که تله‌ی سؤال شکل می‌گیرد:** اگر منتظر سی‌تی بمانیم، **آنتی‌بیوتیک ساعت‌ها عقب می‌افتد**.\n\n"
 "⚠️ **و راه‌حل راهنما دقیقاً همین است: آنتی‌بیوتیک را پیش از فرستادن بیمار به سی‌تی شروع کنید.**\n\n"
 "**پس ترتیب درست:**\n\n"
 "**کشت خون ← آنتی‌بیوتیک + دگزامتازون ← سی‌تی‌اسکن ← (و در صورت اجازه) LP**\n\n"
 "**چرا گزینه‌های دیگر رد می‌شوند؟**\n\n"
 "دو گزینه **LP را اول گذاشته‌اند** — در بیمار با ادم پاپی این کار **خطرناک** است.\n\n"
 "یک گزینه **سی‌تی را پیش از آنتی‌بیوتیک** گذاشته — که همان تأخیر درمانی کشنده است.\n\n"
 "⚠️ **و یک نکته‌ی مهم که کمتر گفته می‌شود: سی‌تی طبیعی، خطر فتق را کاملاً رد نمی‌کند.** اگر شک بالینی به فشار بالا زیاد باشد، ممکن است LP اصلاً انجام نشود و درمان بر پایه‌ی **کشت خون** ادامه یابد — که خوشبختانه در **بیش از نیمی از موارد** مثبت می‌شود.",
 "This question MIRRORS the previous one, and comparing the two is the best way to learn the whole algorithm.\n\n"
 "THIS PATIENT HAS TWO (in fact three) CT INDICATIONS:\n\n"
 "1. A HISTORY OF SEIZURES · 2. PAPILLOEDEMA on fundoscopy · 3. DROWSINESS\n\n"
 "WARNING: SO HE DEFINITELY NEEDS A CT BEFORE LP.\n\n"
 "WHY DOES PAPILLOEDEMA PRECLUDE LP? Because it signals RAISED INTRACRANIAL PRESSURE. Removing fluid from the lumbar space can create a PRESSURE GRADIENT that drives the brain towards the foramen magnum — HERNIATION, which is fatal.\n\n"
 "BUT HERE IS WHERE THE TRAP FORMS: if we wait for the CT, THE ANTIBIOTIC IS DELAYED BY HOURS.\n\n"
 "WARNING, AND THE GUIDELINE'S SOLUTION IS EXACTLY THIS: START ANTIBIOTICS BEFORE SENDING THE PATIENT FOR THE CT.\n\n"
 "SO THE CORRECT ORDER IS:\n\n"
 "BLOOD CULTURE, then ANTIBIOTICS PLUS DEXAMETHASONE, then CT, then LP if permitted\n\n"
 "WHY DO THE OTHER OPTIONS FAIL?\n\n"
 "Two options PUT THE LP FIRST — dangerous in a patient with papilloedema.\n\n"
 "One option puts THE CT BEFORE THE ANTIBIOTIC — the lethal treatment delay.\n\n"
 "WARNING, AND A POINT THAT IS RARELY MADE: A NORMAL CT DOES NOT FULLY EXCLUDE THE RISK OF HERNIATION. If clinical suspicion of raised pressure is high, the LP may not be done at all, and treatment continues on the BLOOD CULTURE — which is fortunately positive in MORE THAN HALF of cases.",
 ["پونکسیون لومبار در بیمار با ادم پاپی و افزایش فشار داخل جمجمه، خطر فتق مغزی دارد.",
  "کشت خون درست است ولی LP پیش از تصویربرداری در بیمار با ادم پاپی خطرناک است.",
  "پاسخ صحیح — کشت خون، سپس آنتی‌بیوتیک، سپس سی‌تی؛ آنتی‌بیوتیک منتظر تصویربرداری نمی‌ماند.",
  "سی‌تی پیش از آنتی‌بیوتیک یعنی ساعت‌ها تأخیر درمانی در بیماری که هر ساعتش مرگ‌ومیر می‌آورد."],
 ["Lumbar puncture in a patient with papilloedema and raised intracranial pressure risks herniation.",
  "Blood culture is right, but LP before imaging is dangerous in a patient with papilloedema.",
  "Correct — blood culture, then antibiotics, then CT; antibiotics never wait for imaging.",
  "CT before antibiotics means hours of delay in a disease where every hour raises mortality."],
 "اندیکاسیون سی‌تی هست ← **کشت خون ← آنتی‌بیوتیک ← سی‌تی ← LP**. **هرگز آنتی‌بیوتیک را عقب نینداز.**",
 "If a CT is indicated: blood culture, antibiotics, CT, then LP. Never delay the antibiotic.",
 [TUNKEL, BEEK, H133])


# =========================================================== book:152
add("book:152", "recall", "medium",
 "**سن بالا** به‌تنهایی اندیکاسیون سی‌تی پیش از LP **نیست**.",
 "OLD AGE ALONE is NOT an indication for CT before LP.",
 ORDER_FA + [
  "این سؤال منفی است: **کدام مورد اندیکاسیون سی‌تی پیش از LP نیست؟**",
  "پس سه اندیکاسیون **واقعی** را در گزینه‌ها بیابید تا چهارمی خودش را نشان دهد.",
  "**کاهش هوشیاری؟** ⚠️ **بله، اندیکاسیون است** — و در مطالعات، شایع‌ترین اندیکاسیون هم هست.",
  "**ادم پاپی؟** ⚠️ **بله**، و قوی‌ترین پیش‌بینی‌کننده‌ی یافته‌ی غیرطبیعی در سی‌تی است",
  "(نسبت درست‌نمایی حدود ۱۱).",
  "**سابقه‌ی سینوزیت؟** این یکی ظریف‌تر است. سینوزیت به‌تنهایی در فهرست نیست،",
  "⚠️ **ولی سینوزیت پیشانی یا اتموئید می‌تواند به آبسه‌ی مغزی یا امپیم ساب‌دورال بینجامد**،",
  "که یک **ضایعه‌ی فضاگیر** است و در دسته‌ی «عفونت کانونی CNS» جا می‌گیرد.",
  "پس در بیمار با سینوزیت و علائم مننژیت، تصویربرداری منطقی است.",
  "⚠️ **می‌ماند «سن بالا» — و پاسخ همین است.**",
  "**چرا سن به‌تنهایی کافی نیست؟** در برخی مطالعات، سن بالای ۶۰ سال با یافته‌ی غیرطبیعی",
  "در سی‌تی **همراهی آماری** نشان داده، ولی این همراهی **غیرمستقیم** است:",
  "**افراد مسن‌تر بیشتر سابقه‌ی بیماری CNS (سکته، توده) دارند** — و آن سابقه اندیکاسیون است، نه خودِ سن.",
  "**پس سن یک نشانگر جانشین است، نه یک معیار مستقل.**",
  "⚠️ **و پیامد عملی: یک فرد ۷۰ ساله‌ی کاملاً هوشیار، بدون نقص فوکال و بدون سابقه‌ی CNS،**",
  "**می‌تواند بدون سی‌تی مستقیماً LP شود** — و این کار وقت گران‌بهایی نجات می‌دهد.",
 ],
 ORDER_EN + [
  "This is a negative question: WHICH IS NOT AN INDICATION FOR CT BEFORE LP?",
  "So find the three REAL indications among the options and the fourth reveals itself.",
  "REDUCED CONSCIOUSNESS? WARNING, YES, IT IS AN INDICATION — and in studies the commonest one.",
  "PAPILLOEDEMA? WARNING, YES, and the strongest predictor of an abnormal CT",
  "(a likelihood ratio of about 11).",
  "A HISTORY OF SINUSITIS? This one is subtler. Sinusitis alone is not on the list,",
  "WARNING, BUT FRONTAL OR ETHMOID SINUSITIS CAN LEAD TO A BRAIN ABSCESS OR SUBDURAL EMPYEMA,",
  "which is A SPACE-OCCUPYING LESION and falls under 'focal CNS infection'.",
  "So in a patient with sinusitis and meningitic signs, imaging is reasonable.",
  "WARNING, THAT LEAVES 'OLD AGE' — AND THAT IS THE ANSWER.",
  "WHY IS AGE ALONE NOT ENOUGH? Some studies show a STATISTICAL ASSOCIATION between age over 60",
  "and abnormal CT findings, but that association is INDIRECT:",
  "OLDER PEOPLE MORE OFTEN HAVE A HISTORY OF CNS DISEASE (stroke, mass) — and it is the HISTORY that is the indication, not the age.",
  "SO AGE IS A SURROGATE MARKER, NOT AN INDEPENDENT CRITERION.",
  "WARNING, AND THE PRACTICAL CONSEQUENCE: A FULLY ALERT 70-YEAR-OLD with no focal deficit and no CNS history",
  "CAN GO STRAIGHT TO LP WITHOUT A CT — and doing so saves precious time.",
 ],
 "این سؤال منفی است، پس راهش این است که سه اندیکاسیون **واقعی** را در گزینه‌ها بیابیم.\n\n"
 "**کاهش هوشیاری؟** ⚠️ **بله، اندیکاسیون است** — و در مطالعات، **شایع‌ترین** اندیکاسیون سی‌تی پیش از LP همین است.\n\n"
 "**ادم پاپی؟** ⚠️ **بله**، و در واقع **قوی‌ترین پیش‌بینی‌کننده** یافته‌ی غیرطبیعی در سی‌تی است (نسبت درست‌نمایی حدود **۱۱**).\n\n"
 "**سابقه‌ی سینوزیت؟** این ظریف‌تر است. سینوزیت به‌تنهایی در فهرست شش‌گانه نیست، ⚠️ **ولی سینوزیت پیشانی یا اتموئید می‌تواند به آبسه‌ی مغزی یا امپیم ساب‌دورال بینجامد** — و آن یک **ضایعه‌ی فضاگیر** است که در دسته‌ی «عفونت کانونی CNS» می‌گنجد. پس در چنین بیماری تصویربرداری منطقی است.\n\n"
 "⚠️ **می‌ماند «سن بالا» — و پاسخ همین است.**\n\n"
 "**چرا سن به‌تنهایی کافی نیست؟ این نکته‌ی مفهومی مهمی است:**\n\n"
 "در برخی مطالعات، سن بالای ۶۰ سال با یافته‌ی غیرطبیعی در سی‌تی **همراهی آماری** نشان داده است. اما این همراهی **غیرمستقیم** است: **افراد مسن‌تر بیشتر سابقه‌ی بیماری CNS دارند** — سکته، توده، جراحی قبلی. و آنچه اندیکاسیون است، **همان سابقه** است، نه خودِ سن.\n\n"
 "**پس سن یک نشانگر جانشین (surrogate) است، نه یک معیار مستقل.**\n\n"
 "⚠️ **و پیامد عملی این تمایز مهم است:** یک فرد **۷۰ ساله‌ی کاملاً هوشیار، بدون نقص فوکال و بدون سابقه‌ی بیماری CNS** می‌تواند **بدون سی‌تی مستقیماً LP شود**. اگر سن را به‌اشتباه یک اندیکاسیون مستقل بدانیم، در هر بیمار مسنی وقت گران‌بهایی را از دست می‌دهیم — و در مننژیت باکتریال، آن وقت به قیمت جان تمام می‌شود.",
 "This is a negative question, so the way in is to find the three REAL indications among the options.\n\n"
 "REDUCED CONSCIOUSNESS? WARNING, YES, IT IS AN INDICATION — and in studies it is the COMMONEST indication for CT before LP.\n\n"
 "PAPILLOEDEMA? WARNING, YES, and in fact the STRONGEST PREDICTOR of an abnormal CT (likelihood ratio about 11).\n\n"
 "A HISTORY OF SINUSITIS? This is subtler. Sinusitis alone is not on the list of six, WARNING, BUT FRONTAL OR ETHMOID SINUSITIS CAN LEAD TO A BRAIN ABSCESS OR SUBDURAL EMPYEMA — a SPACE-OCCUPYING LESION falling under 'focal CNS infection'. So imaging is reasonable in such a patient.\n\n"
 "WARNING, THAT LEAVES 'OLD AGE' — AND THAT IS THE ANSWER.\n\n"
 "WHY IS AGE ALONE NOT ENOUGH? This is an important conceptual point:\n\n"
 "Some studies show a STATISTICAL ASSOCIATION between age over 60 and abnormal CT findings. But that association is INDIRECT: OLDER PEOPLE MORE OFTEN HAVE A HISTORY OF CNS DISEASE — stroke, mass, previous surgery. And what constitutes the indication is THAT HISTORY, not the age itself.\n\n"
 "SO AGE IS A SURROGATE MARKER, NOT AN INDEPENDENT CRITERION.\n\n"
 "WARNING, AND THE PRACTICAL CONSEQUENCE MATTERS: a FULLY ALERT 70-YEAR-OLD with no focal deficit and no CNS history CAN GO STRAIGHT TO LP WITHOUT A CT. If we wrongly treat age as an independent indication, we lose precious time in every older patient — and in bacterial meningitis that time costs lives.",
 ["کاهش هوشیاری یکی از اندیکاسیون‌های اصلی سی‌تی پیش از LP و شایع‌ترین آن‌هاست.",
  "سینوزیت پیشانی یا اتموئید می‌تواند به آبسه‌ی مغزی بینجامد و تصویربرداری را موجه کند.",
  "پاسخ صحیح — سن بالا به‌تنهایی اندیکاسیون نیست؛ نشانگر جانشین سابقه‌ی بیماری CNS است.",
  "ادم پاپی قوی‌ترین پیش‌بینی‌کننده‌ی یافته‌ی غیرطبیعی در سی‌تی و یک اندیکاسیون قطعی است."],
 ["Reduced consciousness is a principal and the commonest indication for CT before LP.",
  "Frontal or ethmoid sinusitis can lead to a brain abscess and justifies imaging.",
  "Correct — age alone is not an indication; it is a surrogate for a history of CNS disease.",
  "Papilloedema is the strongest predictor of an abnormal CT and a definite indication."],
 "اندیکاسیون سی‌تی: **هوشیاری، فوکال، ادم پاپی، تشنج، نقص ایمنی، سابقه‌ی CNS.** **سن به‌تنهایی نه.**",
 "CT indications: consciousness, focal deficit, papilloedema, seizure, immunocompromise, CNS history. Age alone is not one.",
 [TUNKEL])


# =========================================================== book:156
add("book:156", "case", "medium",
 "CSF با **۸۷٪ نوتروفیل، قند ۲۰، پروتئین ۱۲۰** ← مننژیت باکتریال ← **پنوموکوک**.",
 "A CSF with 87% NEUTROPHILS, GLUCOSE 20 and PROTEIN 120 is bacterial meningitis: PNEUMOCOCCUS.",
 CSF_FA + [
  "⚠️ **توجه: پنل CSF این سؤال تصحیح شده است.** متن استخراج‌شده «قند ۲» و «پروتئین ۲۱» داشت؛",
  "صفحه‌ی ۶۱ در واقع **قند ۲۰** و **پروتئین ۱۲۰** چاپ کرده و رقم‌ها در استخراج افتاده بودند.",
  "**چرا این تصحیح لازم بود؟ چون «قند ۲ با پروتئین ۲۱» ترکیبی است که در هیچ مننژیتی وجود ندارد.**",
  "قند به‌شدت پایین همیشه با **پروتئین بالا** همراه است، نه با پروتئین طبیعی.",
  "**حالا پنل تصحیح‌شده را بخوانید و الگو را تشخیص دهید:**",
  "**WBC = ۸۰۰** ← در محدوده‌ی صدها، سازگار با باکتریال.",
  "⚠️ **PMN = ۸۷٪** ← غلبه‌ی روشن نوتروفیل ← **گام اول: باکتریال**.",
  "⚠️ **قند = ۲۰** ← پایین ← تأیید باکتریال (یا سلی، ولی سلی لنفوسیتی است).",
  "**پروتئین = ۱۲۰** ← بالا ← باز هم سازگار.",
  "**پس مننژیت باکتریال است. حالا کدام باکتری؟**",
  "**بیمار ۱۸ ساله، بدون بیماری زمینه‌ای، بدون سابقه‌ی ضربه به سر، و هوشیار است.**",
  "⚠️ **در بزرگسال جوان و سالم، دو عامل اصلی: استرپتوکوک پنومونیه و نایسریا مننژیتیدیس.**",
  "**پنوموکوک در همه‌ی گروه‌های سنی بزرگسال شایع‌ترین است** — و پاسخ همین است.",
  "**مننگوکوک هم محتمل است، ولی معمولاً با راش پتشی می‌آید که اینجا ذکر نشده.**",
  "چرا کریپتوکوک نه؟ آن **لنفوسیتی** است و در **نقص ایمنی** رخ می‌دهد.",
  "چرا هرپس نه؟ انسفالیت هرپسی **لنفوسیتی با قند طبیعی** است و **اختلال رفتار** می‌دهد.",
  "چرا پلاسمودیوم نه؟ مالاریای مغزی **پلئوسیتوز چشمگیر نمی‌سازد** و سابقه‌ی سفر می‌خواهد.",
 ],
 CSF_EN + [
  "WARNING, NOTE: THE CSF PANEL OF THIS QUESTION HAS BEEN CORRECTED. The extracted text read 'glucose 2' and 'protein 21';",
  "page 61 actually prints GLUCOSE 20 and PROTEIN 120, and digits had been dropped in extraction.",
  "WHY WAS THE CORRECTION NECESSARY? BECAUSE 'GLUCOSE 2 WITH PROTEIN 21' IS A COMBINATION THAT OCCURS IN NO MENINGITIS.",
  "A profoundly low glucose always accompanies a HIGH protein, never a normal one.",
  "NOW READ THE CORRECTED PANEL AND RECOGNISE THE PATTERN:",
  "WBC = 800 — in the hundreds, consistent with bacterial.",
  "WARNING, PMN = 87% — clear neutrophil predominance — STEP ONE: BACTERIAL.",
  "WARNING, GLUCOSE = 20 — low — confirming bacterial (or tuberculous, but TB is lymphocytic).",
  "PROTEIN = 120 — high — again consistent.",
  "SO IT IS BACTERIAL MENINGITIS. NOW WHICH BACTERIUM?",
  "THE PATIENT IS 18, WITH NO UNDERLYING DISEASE, NO HEAD TRAUMA, AND IS ALERT.",
  "WARNING: IN A HEALTHY YOUNG ADULT THE TWO MAIN AGENTS ARE STREPTOCOCCUS PNEUMONIAE AND NEISSERIA MENINGITIDIS.",
  "PNEUMOCOCCUS IS THE COMMONEST IN EVERY ADULT AGE GROUP — and that is the answer.",
  "Meningococcus is also possible, but usually comes with a petechial rash, which is not mentioned here.",
  "Why not Cryptococcus? That is LYMPHOCYTIC and occurs in IMMUNOCOMPROMISE.",
  "Why not herpes? Herpes encephalitis is LYMPHOCYTIC WITH NORMAL GLUCOSE and causes BEHAVIOURAL CHANGE.",
  "Why not Plasmodium? Cerebral malaria DOES NOT PRODUCE MARKED PLEOCYTOSIS and needs a travel history.",
 ],
 "⚠️ **پیش از هر چیز: پنل CSF این سؤال تصحیح شده است.** متن استخراج‌شده «قند ۲» و «پروتئین ۲۱» داشت، ولی صفحه‌ی ۶۱ کتاب **قند ۲۰** و **پروتئین ۱۲۰** چاپ کرده است.\n\n"
 "**چرا این تصحیح ضروری بود؟** چون **«قند ۲ با پروتئین ۲۱» ترکیبی است که در هیچ مننژیتی وجود ندارد** — قند به‌شدت پایین همیشه با **پروتئین بالا** همراه است. با عدد غلط، الگویی که سؤال می‌خواهد بیاموزد از بین می‌رفت.\n\n"
 "**حالا پنل تصحیح‌شده را با الگوریتم دو‌مرحله‌ای بخوانید:**\n\n"
 "**WBC = ۸۰۰** ← در محدوده‌ی صدها\n"
 "⚠️ **PMN = ۸۷٪** ← **گام یک: غلبه‌ی نوتروفیل ← باکتریال**\n"
 "⚠️ **قند = ۲۰** ← **گام دو: قند پایین ← تأیید باکتریال**\n"
 "**پروتئین = ۱۲۰** ← بالا، سازگار\n\n"
 "**پس مننژیت باکتریال است. حالا کدام باکتری؟**\n\n"
 "بیمار **۱۸ ساله، بدون بیماری زمینه‌ای، بدون سابقه‌ی ضربه به سر** است. در بزرگسال جوان و سالم، دو عامل اصلی **استرپتوکوک پنومونیه** و **نایسریا مننژیتیدیس**‌اند. ⚠️ **و پنوموکوک در همه‌ی گروه‌های سنی بزرگسال شایع‌ترین است.**\n\n"
 "(مننگوکوک هم محتمل بود، ولی معمولاً با **راش پتشی** می‌آید که در این سؤال ذکر نشده.)\n\n"
 "**چرا گزینه‌های دیگر رد می‌شوند؟**\n\n"
 "**کریپتوکوکوس** ← تابلوی **لنفوسیتی** می‌سازد و در **نقص ایمنی** (به‌ویژه HIV) رخ می‌دهد؛ این بیمار سالم است.\n\n"
 "**هرپس سیمپلکس** ← انسفالیت هرپسی **لنفوسیتی با قند طبیعی** است و با **اختلال رفتار و تشنج** می‌آید، نه با ۸۷٪ نوتروفیل.\n\n"
 "**پلاسمودیوم فالسیپاروم** ← مالاریای مغزی **پلئوسیتوز چشمگیری نمی‌سازد** و سابقه‌ی سفر به منطقه‌ی اندمیک می‌خواهد.",
 "WARNING, FIRST: THE CSF PANEL OF THIS QUESTION HAS BEEN CORRECTED. The extracted text read 'glucose 2' and 'protein 21', but page 61 prints GLUCOSE 20 and PROTEIN 120.\n\n"
 "WHY WAS THE CORRECTION NECESSARY? Because 'GLUCOSE 2 WITH PROTEIN 21' IS A COMBINATION THAT OCCURS IN NO MENINGITIS — a profoundly low glucose always accompanies a HIGH protein. With the wrong figures, the very pattern the question teaches was destroyed.\n\n"
 "NOW READ THE CORRECTED PANEL WITH THE TWO-STEP ALGORITHM:\n\n"
 "WBC = 800 — in the hundreds\n"
 "WARNING, PMN = 87% — STEP ONE: NEUTROPHIL PREDOMINANCE MEANS BACTERIAL\n"
 "WARNING, GLUCOSE = 20 — STEP TWO: LOW GLUCOSE CONFIRMS BACTERIAL\n"
 "PROTEIN = 120 — high, consistent\n\n"
 "SO IT IS BACTERIAL MENINGITIS. NOW WHICH BACTERIUM?\n\n"
 "The patient is 18, WITH NO UNDERLYING DISEASE AND NO HEAD TRAUMA. In a healthy young adult the two main agents are STREPTOCOCCUS PNEUMONIAE and NEISSERIA MENINGITIDIS. WARNING, AND PNEUMOCOCCUS IS THE COMMONEST IN EVERY ADULT AGE GROUP.\n\n"
 "(Meningococcus was also possible, but it usually comes with a PETECHIAL RASH, which this stem does not mention.)\n\n"
 "WHY DO THE OTHER OPTIONS FAIL?\n\n"
 "CRYPTOCOCCUS produces a LYMPHOCYTIC picture and occurs in IMMUNOCOMPROMISE (especially HIV); this patient is healthy.\n\n"
 "HERPES SIMPLEX — herpes encephalitis is LYMPHOCYTIC WITH NORMAL GLUCOSE and presents with BEHAVIOURAL CHANGE AND SEIZURES, not 87% neutrophils.\n\n"
 "PLASMODIUM FALCIPARUM — cerebral malaria DOES NOT PRODUCE MARKED PLEOCYTOSIS and requires travel to an endemic area.",
 ["انسفالیت هرپسی تابلوی لنفوسیتی با قند طبیعی دارد، نه ۸۷ درصد نوتروفیل با قند پایین.",
  "پاسخ صحیح — نوتروفیلی با قند پایین یعنی باکتریال، و پنوموکوک شایع‌ترین عامل در بزرگسال است.",
  "کریپتوکوکوس تابلوی لنفوسیتی می‌سازد و در بیمار دچار نقص ایمنی رخ می‌دهد، نه در جوان سالم.",
  "مالاریای مغزی پلئوسیتوز چشمگیر ایجاد نمی‌کند و نیازمند سابقه‌ی سفر به منطقه‌ی اندمیک است."],
 ["Herpes encephalitis gives a lymphocytic picture with normal glucose, not 87% neutrophils with low glucose.",
  "Correct — neutrophilia with low glucose means bacterial, and pneumococcus is the commonest adult cause.",
  "Cryptococcus produces a lymphocytic picture in an immunocompromised host, not in a healthy young adult.",
  "Cerebral malaria does not cause marked pleocytosis and requires travel to an endemic area."],
 "**نوتروفیل + قند پایین = باکتریال.** در بزرگسال سالم، **پنوموکوک** شایع‌ترین است.",
 "Neutrophils plus low glucose means bacterial. In a healthy adult the commonest organism is the pneumococcus.",
 [H133])


# =========================================================== book:161
add("book:161", "case", "medium",
 "CSF **لنفوسیتی با قند طبیعی** در نوجوان سالم ← **انترو‌ویروس**.",
 "A LYMPHOCYTIC CSF WITH NORMAL GLUCOSE in a healthy adolescent means ENTEROVIRUS.",
 CSF_FA + [
  "⚠️ **توجه: شمارش سلولی این سؤال تصحیح شده است** — صفحه‌ی ۶۳ عدد **۳۴۰** چاپ کرده",
  "و متن استخراج‌شده «۰۴۳» داشت که اصلاً یک عدد نیست.",
  "**پنل را با الگوریتم دو‌مرحله‌ای بخوانید:**",
  "**پلئوسیتوز ۳۴۰** ← در محدوده‌ی صدها، که هم با ویروسی و هم با باکتریال می‌خواند.",
  "⚠️ **برتری لنفوسیت** ← **گام یک: ویروسی یا سلی/قارچی، نه باکتریال.**",
  "⚠️ **قند ۷۰** ← **گام دو: قند طبیعی ← ویروسی، نه سلی.**",
  "**پروتئین ۹۰** ← مختصر بالا، که با ویروسی سازگار است (در سلی معمولاً بسیار بالاتر).",
  "**پس مننژیت ویروسی (آسپتیک) است. حالا کدام ویروس؟**",
  "⚠️ **انترو‌ویروس‌ها عامل بیش از ۸۰ تا ۹۰ درصد مننژیت‌های ویروسی هستند.**",
  "**اکو‌ویروس و کوکساکی‌ویروس مهم‌ترین اعضای این خانواده‌اند.**",
  "**اوجشان تابستان و اوایل پاییز است و انتقالشان مدفوعی-دهانی.**",
  "**سیر بیماری خوش‌خیم است: بهبود خودبه‌خودی در ۷ تا ۱۰ روز، درمان حمایتی.**",
  "چرا پنوموکوک نه؟ آن **نوتروفیلی با قند پایین** می‌سازد — دقیقاً برعکس این پنل.",
  "چرا لیستریا نه؟ لیستریا هم باکتریال است و در **نوزاد، مسن، باردار و نقص ایمنی** رخ می‌دهد؛",
  "این بیمار نوجوان سالم است و پنل هم لنفوسیتی با قند طبیعی است.",
  "⚠️ **چرا سیتومگالوویروس نه؟** CMV در CNS عمدتاً در **نقص ایمنی شدید** (ایدز پیشرفته) دیده می‌شود",
  "و در فرد سالم عامل مننژیت آسپتیک محسوب نمی‌شود.",
 ],
 CSF_EN + [
  "WARNING, NOTE: THE CELL COUNT OF THIS QUESTION HAS BEEN CORRECTED — page 63 prints 340",
  "and the extracted text read '043', which is not a number at all.",
  "READ THE PANEL WITH THE TWO-STEP ALGORITHM:",
  "PLEOCYTOSIS 340 — in the hundreds, compatible with either viral or bacterial.",
  "WARNING, LYMPHOCYTE PREDOMINANCE — STEP ONE: VIRAL OR TB/FUNGAL, NOT BACTERIAL.",
  "WARNING, GLUCOSE 70 — STEP TWO: NORMAL GLUCOSE MEANS VIRAL, NOT TUBERCULOUS.",
  "PROTEIN 90 — mildly raised, consistent with viral (in TB it is usually far higher).",
  "SO IT IS VIRAL (ASEPTIC) MENINGITIS. NOW WHICH VIRUS?",
  "WARNING: ENTEROVIRUSES CAUSE MORE THAN 80 TO 90 PER CENT OF VIRAL MENINGITIS.",
  "ECHOVIRUS AND COXSACKIEVIRUS are the most important members of the family.",
  "They peak in SUMMER AND EARLY AUTUMN and spread by the FAECAL-ORAL route.",
  "The course is benign: SPONTANEOUS RECOVERY IN 7 TO 10 DAYS, supportive treatment.",
  "Why not pneumococcus? It produces NEUTROPHILIA WITH LOW GLUCOSE — the exact opposite of this panel.",
  "Why not Listeria? Listeria is also bacterial and occurs in NEONATES, THE ELDERLY, PREGNANCY AND IMMUNOCOMPROMISE;",
  "this patient is a healthy adolescent and the panel is lymphocytic with normal glucose.",
  "WARNING, WHY NOT CYTOMEGALOVIRUS? CMV in the CNS is seen mainly in SEVERE IMMUNOCOMPROMISE (advanced AIDS)",
  "and is not considered a cause of aseptic meningitis in a healthy person.",
 ],
 "⚠️ **توجه: شمارش سلولی این سؤال تصحیح شده است.** صفحه‌ی ۶۳ عدد **۳۴۰** چاپ کرده و متن استخراج‌شده «۰۴۳» داشت که اصلاً یک عدد نیست.\n\n"
 "**حالا پنل را با الگوریتم دو‌مرحله‌ای بخوانید — این همان مهارتی است که کل بلوک را حل می‌کند:**\n\n"
 "**پلئوسیتوز ۳۴۰** ← در محدوده‌ی صدها؛ این عدد به‌تنهایی تصمیم‌گیر نیست\n"
 "⚠️ **برتری لنفوسیت** ← **گام یک: ویروسی یا سلی/قارچی است، نه باکتریال**\n"
 "⚠️ **قند ۷۰ (طبیعی)** ← **گام دو: پس ویروسی است، نه سلی**\n"
 "**پروتئین ۹۰** ← مختصر بالا؛ در مننژیت سلی معمولاً **بسیار بالاتر** (اغلب بالای ۱۵۰) است\n\n"
 "**پس مننژیت ویروسی (آسپتیک) است.**\n\n"
 "**حالا کدام ویروس؟** ⚠️ **انترو‌ویروس‌ها عامل بیش از ۸۰ تا ۹۰ درصد مننژیت‌های ویروسی هستند** — یعنی اگر تابلو ویروسی بود و سرنخ دیگری نبود، پاسخ تقریباً همیشه انترو‌ویروس است.\n\n"
 "**اکو‌ویروس و کوکساکی‌ویروس** مهم‌ترین اعضای این خانواده‌اند، اوجشان **تابستان و اوایل پاییز** است، و انتقالشان **مدفوعی-دهانی**. سیر بیماری **خوش‌خیم** است: بهبود خودبه‌خودی در **۷ تا ۱۰ روز** با **درمان حمایتی**.\n\n"
 "**چرا گزینه‌های دیگر رد می‌شوند؟**\n\n"
 "**استرپتوکوک پنومونیه** ← **نوتروفیلی با قند پایین** می‌سازد، دقیقاً برعکس این پنل.\n\n"
 "**لیستریا مونوسیتوژن** ← باکتریال است و در گروه‌های خاص رخ می‌دهد: **نوزاد، بالای ۵۰ سال، باردار، نقص ایمنی**. این بیمار **نوجوان سالم** است.\n\n"
 "⚠️ **سیتومگالوویروس** ← درگیری CNS با CMV عمدتاً در **نقص ایمنی شدید** (ایدز پیشرفته) دیده می‌شود و در فرد سالم عامل مننژیت آسپتیک محسوب نمی‌شود.",
 "WARNING, NOTE: THE CELL COUNT OF THIS QUESTION HAS BEEN CORRECTED. Page 63 prints 340 and the extracted text read '043', which is not a number at all.\n\n"
 "NOW READ THE PANEL WITH THE TWO-STEP ALGORITHM — the one skill that solves this whole block:\n\n"
 "PLEOCYTOSIS 340 — in the hundreds; this figure alone does not decide\n"
 "WARNING, LYMPHOCYTE PREDOMINANCE — STEP ONE: VIRAL OR TB/FUNGAL, NOT BACTERIAL\n"
 "WARNING, GLUCOSE 70 (NORMAL) — STEP TWO: THEREFORE VIRAL, NOT TUBERCULOUS\n"
 "PROTEIN 90 — mildly raised; in tuberculous meningitis it is usually FAR HIGHER (often above 150)\n\n"
 "SO IT IS VIRAL (ASEPTIC) MENINGITIS.\n\n"
 "NOW WHICH VIRUS? WARNING: ENTEROVIRUSES CAUSE MORE THAN 80 TO 90 PER CENT OF VIRAL MENINGITIS — so if the picture is viral and there is no other clue, the answer is almost always enterovirus.\n\n"
 "ECHOVIRUS AND COXSACKIEVIRUS are the most important members, they peak in SUMMER AND EARLY AUTUMN, and they spread by the FAECAL-ORAL route. The course is BENIGN: spontaneous recovery in 7 TO 10 DAYS with SUPPORTIVE care.\n\n"
 "WHY DO THE OTHER OPTIONS FAIL?\n\n"
 "STREPTOCOCCUS PNEUMONIAE produces NEUTROPHILIA WITH LOW GLUCOSE, the exact opposite of this panel.\n\n"
 "LISTERIA MONOCYTOGENES is bacterial and occurs in specific groups: NEONATES, THE OVER-50s, PREGNANCY, IMMUNOCOMPROMISE. This patient is a HEALTHY ADOLESCENT.\n\n"
 "WARNING, CYTOMEGALOVIRUS — CNS involvement with CMV is seen mainly in SEVERE IMMUNOCOMPROMISE (advanced AIDS) and is not considered a cause of aseptic meningitis in a healthy person.",
 ["پنوموکوک نوتروفیلی با قند پایین می‌سازد؛ این پنل لنفوسیتی با قند طبیعی است.",
  "پاسخ صحیح — لنفوسیتی با قند طبیعی یعنی ویروسی، و انترو‌ویروس عامل بیش از ۸۰ درصد موارد است.",
  "لیستریا باکتریال است و در نوزاد، مسن، باردار و نقص ایمنی رخ می‌دهد، نه در نوجوان سالم.",
  "سیتومگالوویروس در CNS عمدتاً در نقص ایمنی شدید دیده می‌شود، نه در فرد سالم."],
 ["Pneumococcus produces neutrophilia with low glucose; this panel is lymphocytic with normal glucose.",
  "Correct — lymphocytic with normal glucose means viral, and enterovirus causes over 80% of cases.",
  "Listeria is bacterial and occurs in neonates, the elderly, pregnancy and immunocompromise, not a healthy adolescent.",
  "Cytomegalovirus in the CNS is seen mainly in severe immunocompromise, not in a healthy person."],
 "**لنفوسیت + قند طبیعی = ویروسی ← انترو‌ویروس.** **لنفوسیت + قند پایین = سلی/قارچی.**",
 "Lymphocytes plus normal glucose means viral, and that means enterovirus. Lymphocytes plus low glucose means TB or fungal.",
 [H133])


# =========================================================== book:166
add("book:166", "case", "hard",
 "CSF **لنفوسیتی با قند پایین و پروتئین بسیار بالا** در سیر سه‌هفته‌ای ← **مننژیت سلی**.",
 "A LYMPHOCYTIC CSF with LOW GLUCOSE and VERY HIGH PROTEIN over three weeks means TUBERCULOUS MENINGITIS.",
 CSF_FA + [
  "بیمار **۶۵ ساله** با **سردرد ۲۰ روزه**، استفراغ مکرر و تب ۳۸ درجه.",
  "⚠️ **اولین سرنخ، خودِ زمان است: سیر تحت‌حاد (هفته‌ها) نه حاد (ساعت‌ها).**",
  "**مننژیت باکتریال حاد در عرض ساعت تا یکی دو روز بیمار را زمین می‌زند.**",
  "**سیر بیست‌روزه به سه چیز فکر می‌کند: سل، قارچ، و بدخیمی.**",
  "**حالا پنل را بخوانید:**",
  "**WBC = ۱۶۰ با ۸۰٪ لنفوسیت** ← گام یک: لنفوسیتی ← ویروسی یا سلی/قارچی.",
  "⚠️ **قند = ۲۰** ← گام دو: **قند پایین ← ویروسی حذف می‌شود.**",
  "⚠️ **پروتئین = ۳۱۰** ← **بسیار بالا** — و این امضای مننژیت سلی است.",
  "**چرا پروتئین در سل این‌قدر بالا می‌رود؟** چون التهاب **اگزوداتیو غلیظ** در قاعده‌ی مغز",
  "جریان CSF را مسدود می‌کند و **بلوک نسبی فضای ساب‌آراکنوئید** می‌سازد.",
  "**پروتئین بالای ۱۰۰۰ هم دیده می‌شود و گاهی مایع لخته می‌بندد (تار عنکبوتی).**",
  "**سه ویژگی دیگر مننژیت سلی را بدانید:**",
  "**درگیری قاعده‌ی مغز** ← **فلج اعصاب کرانیال** (به‌ویژه سوم، ششم و هفتم).",
  "**هیدروسفالی** به‌علت انسداد جریان CSF.",
  "**انفارکت** به‌علت واسکولیت شریان‌های قاعده‌ای.",
  "⚠️ **و نکته‌ی درمانی حیاتی: درمان بر پایه‌ی شک بالینی شروع می‌شود، نه منتظر کشت.**",
  "کشت سل **هفته‌ها** طول می‌کشد و **حساسیت اسمیر بسیار پایین است**.",
  "**درمان: چهار داروی ضدسل + دگزامتازون** (استروئید در مننژیت سلی مرگ‌ومیر را کم می‌کند).",
  "چرا کارسینوماتوز نه؟ ممکن است، ولی **تب** به نفع عفونت است و سیتولوژی لازم دارد.",
 ],
 CSF_EN + [
  "A 65-YEAR-OLD with A 20-DAY HEADACHE, repeated vomiting and a temperature of 38.",
  "WARNING, THE FIRST CLUE IS THE TIME ITSELF: A SUBACUTE COURSE (weeks), NOT ACUTE (hours).",
  "Acute bacterial meningitis fells a patient within hours to a day or two.",
  "A TWENTY-DAY COURSE POINTS TO THREE THINGS: TUBERCULOSIS, FUNGUS, AND MALIGNANCY.",
  "NOW READ THE PANEL:",
  "WBC = 160 with 80% LYMPHOCYTES — step one: lymphocytic, so viral or TB/fungal.",
  "WARNING, GLUCOSE = 20 — step two: LOW GLUCOSE ELIMINATES VIRAL.",
  "WARNING, PROTEIN = 310 — VERY HIGH — and that is the signature of tuberculous meningitis.",
  "WHY DOES THE PROTEIN RISE SO HIGH IN TB? Because THICK EXUDATIVE INFLAMMATION at the base of the brain",
  "obstructs CSF flow and creates A PARTIAL SUBARACHNOID BLOCK.",
  "Proteins above 1000 are seen, and the fluid can even clot (a cobweb clot).",
  "KNOW THREE OTHER FEATURES OF TUBERCULOUS MENINGITIS:",
  "BASAL INVOLVEMENT — CRANIAL NERVE PALSIES (especially third, sixth and seventh).",
  "HYDROCEPHALUS from obstruction of CSF flow.",
  "INFARCTION from vasculitis of the basal arteries.",
  "WARNING, AND A CRUCIAL THERAPEUTIC POINT: TREATMENT STARTS ON CLINICAL SUSPICION, NOT ON CULTURE.",
  "TB culture takes WEEKS and SMEAR SENSITIVITY IS VERY LOW.",
  "TREATMENT: FOUR ANTI-TUBERCULOUS DRUGS PLUS DEXAMETHASONE (steroid reduces mortality in TB meningitis).",
  "Why not carcinomatous? Possible, but FEVER favours infection, and it requires cytology.",
 ],
 "بیمار **۶۵ ساله** با **سردرد ۲۰ روزه**، استفراغ مکرر و تب ۳۸ درجه است.\n\n"
 "⚠️ **اولین سرنخ، خودِ زمان است:** سیر **تحت‌حاد** (هفته‌ها) نه **حاد** (ساعت‌ها). مننژیت باکتریال حاد بیمار را در عرض **ساعت تا یکی دو روز** زمین می‌زند. یک سیر بیست‌روزه شما را به سه چیز می‌برد: **سل، قارچ، و بدخیمی**.\n\n"
 "**حالا پنل را بخوانید:**\n\n"
 "**WBC = ۱۶۰ با ۸۰٪ لنفوسیت** ← گام یک: لنفوسیتی\n"
 "⚠️ **قند = ۲۰** ← گام دو: **قند پایین است، پس ویروسی حذف می‌شود**\n"
 "⚠️ **پروتئین = ۳۱۰** ← **بسیار بالا — و این امضای مننژیت سلی است**\n\n"
 "**چرا پروتئین در سل این‌قدر بالا می‌رود؟** این نکته را بفهمید تا حفظ نکنید: مننژیت سلی یک **التهاب اگزوداتیو غلیظ در قاعده‌ی مغز** می‌سازد که **جریان CSF را مسدود می‌کند**. این **بلوک نسبی فضای ساب‌آراکنوئید**، پروتئین را در مایع پایین‌دست انباشته می‌کند. پروتئین بالای **۱۰۰۰** هم دیده می‌شود و گاهی مایع در لوله **لخته‌ی تار‌عنکبوتی** می‌بندد.\n\n"
 "**و همان اگزودای قاعده‌ای، سه عارضه‌ی کلاسیک دیگر را هم توضیح می‌دهد:**\n\n"
 "**فلج اعصاب کرانیال** (به‌ویژه سوم، ششم، هفتم) ← چون اعصاب از قاعده عبور می‌کنند\n"
 "**هیدروسفالی** ← انسداد جریان CSF\n"
 "**انفارکت مغزی** ← واسکولیت شریان‌های قاعده‌ای\n\n"
 "⚠️ **و نکته‌ی درمانی حیاتی: درمان بر پایه‌ی شک بالینی شروع می‌شود، نه با انتظار برای کشت.** کشت سل **هفته‌ها** طول می‌کشد و حساسیت اسمیر AFB در CSF بسیار پایین است. **درمان: چهار داروی ضدسل + دگزامتازون** — و استروئید در مننژیت سلی **مرگ‌ومیر را کاهش می‌دهد**.\n\n"
 "**چرا مننژیت کارسینوماتوز نه؟** الگوی CSF می‌تواند مشابه باشد، ولی **تب** به نفع عفونت است و تشخیصش **سیتولوژی مکرر** می‌خواهد.",
 "A 65-YEAR-OLD with A 20-DAY HEADACHE, repeated vomiting and a temperature of 38.\n\n"
 "WARNING, THE FIRST CLUE IS THE TIME ITSELF: a SUBACUTE course (weeks), not ACUTE (hours). Acute bacterial meningitis fells a patient within HOURS TO A DAY OR TWO. A twenty-day course points to three things: TUBERCULOSIS, FUNGUS, AND MALIGNANCY.\n\n"
 "NOW READ THE PANEL:\n\n"
 "WBC = 160 with 80% LYMPHOCYTES — step one: lymphocytic\n"
 "WARNING, GLUCOSE = 20 — step two: THE GLUCOSE IS LOW, SO VIRAL IS ELIMINATED\n"
 "WARNING, PROTEIN = 310 — VERY HIGH, AND THAT IS THE SIGNATURE OF TUBERCULOUS MENINGITIS\n\n"
 "WHY DOES THE PROTEIN RISE SO HIGH IN TB? Understand this rather than memorising it: tuberculous meningitis creates a THICK EXUDATIVE INFLAMMATION AT THE BASE OF THE BRAIN that OBSTRUCTS CSF FLOW. That PARTIAL SUBARACHNOID BLOCK concentrates protein in the fluid downstream. Proteins above 1000 are seen, and the fluid can form a COBWEB CLOT in the tube.\n\n"
 "AND THAT SAME BASAL EXUDATE EXPLAINS THREE OTHER CLASSICAL COMPLICATIONS:\n\n"
 "CRANIAL NERVE PALSIES (especially third, sixth, seventh) — because the nerves run across the base\n"
 "HYDROCEPHALUS — obstruction of CSF flow\n"
 "CEREBRAL INFARCTION — vasculitis of the basal arteries\n\n"
 "WARNING, AND A CRUCIAL THERAPEUTIC POINT: TREATMENT BEGINS ON CLINICAL SUSPICION, NOT WHILE WAITING FOR CULTURE. TB culture takes WEEKS and the sensitivity of AFB smear in CSF is very low. TREATMENT: FOUR ANTI-TUBERCULOUS DRUGS PLUS DEXAMETHASONE — and the steroid REDUCES MORTALITY in tuberculous meningitis.\n\n"
 "WHY NOT CARCINOMATOUS MENINGITIS? The CSF pattern can be similar, but FEVER favours infection, and the diagnosis requires REPEATED CYTOLOGY.",
 ["مننژیت حاد باکتریال سیر ساعتی تا یکی دو روزه دارد و نوتروفیلی است، نه بیست روز با لنفوسیت.",
  "مننژیت ویروسی قند طبیعی دارد؛ اینجا قند ۲۰ است که ویروسی را رد می‌کند.",
  "مننژیت کارسینوماتوز ممکن است ولی تب به نفع عفونت است و تشخیصش سیتولوژی مکرر می‌خواهد.",
  "پاسخ صحیح — لنفوسیتی با قند پایین و پروتئین بسیار بالا در سیر تحت‌حاد: مننژیت سلی."],
 ["Acute bacterial meningitis runs over hours to a day or two and is neutrophilic, not twenty days with lymphocytes.",
  "Viral meningitis has a normal glucose; here it is 20, which excludes viral.",
  "Carcinomatous meningitis is possible but fever favours infection, and diagnosis needs repeated cytology.",
  "Correct — lymphocytic with low glucose and very high protein over a subacute course: tuberculous meningitis."],
 "سل: **لنفوسیت + قند پایین + پروتئین خیلی بالا + سیر هفته‌ها.** اگزودای قاعده‌ای ← **فلج اعصاب کرانیال**.",
 "TB: lymphocytes, low glucose, very high protein, a course of weeks. Basal exudate causes cranial nerve palsies.",
 [H133])


# =========================================================== book:163
add("book:163", "case", "hard",
 "**گلبول قرمز در CSF + درگیری لوب تمپورال در MRI** ← **انسفالیت هرپسی**.",
 "RED CELLS IN THE CSF plus TEMPORAL LOBE involvement on MRI means HERPES ENCEPHALITIS.",
 CSF_FA + [
  "⚠️ **توجه: دو عدد این سؤال تصحیح شده است** — صفحه‌ی ۶۴ **پروتئین ۹۰** و **RBC=100** چاپ کرده،",
  "و متن استخراج‌شده «۰۹» و «۰۰۱» داشت.",
  "**بیمار: مرد جوان با تب، سردرد، تشنج و اختلال سطح هوشیاری از دیروز.**",
  "⚠️ **اول یک تمایز مفهومی: مننژیت یا انسفالیت؟**",
  "**مننژیت = التهاب پرده‌ها** ← سردرد، تب، سفتی گردن، ولی **هوشیاری و عملکرد مغز حفظ است**.",
  "**انسفالیت = التهاب خودِ پارانشیم مغز** ← **تغییر رفتار، تشنج، نقص فوکال، اختلال هوشیاری**.",
  "**این بیمار تشنج و اختلال هوشیاری دارد — پس انسفالیت است، نه صرفاً مننژیت.**",
  "**حالا پنل و تصویربرداری را کنار هم بگذارید:**",
  "**WBC = ۱۰۰** ← پلئوسیتوز خفیف، سازگار با ویروسی.",
  "**پروتئین = ۹۰** ← مختصر بالا.",
  "⚠️ **RBC = ۱۰۰ بدون سابقه‌ی تروما یا تپ خونی** — و این یافته‌ی طلایی است.",
  "**چرا گلبول قرمز؟ چون انسفالیت هرپسی یک نکروز خونریزی‌دهنده است.**",
  "⚠️ **و کجا؟ لوب تمپورال — که MRI بیمار دقیقاً همان را نشان می‌دهد.**",
  "**چرا لوب تمپورال؟** چون ویروس از **عصب بویایی یا عصب تری‌ژمینال** بالا می‌آید",
  "و ابتدا به **لوب تمپورال داخلی و اربیتوفرونتال** می‌رسد.",
  "**همین محل، اختلال رفتار و حافظه و تشنج‌های تمپورال را توضیح می‌دهد.**",
  "⚠️ **درمان: آسیکلوویر وریدی، فوراً و بدون انتظار برای PCR.**",
  "**مرگ‌ومیر بدون درمان بیش از ۷۰ درصد است و با درمان زودهنگام به کمتر از ۲۰ درصد می‌رسد.**",
  "**تشخیص قطعی: PCR مایع نخاع برای HSV** (حساسیت و ویژگی بالای ۹۵ درصد).",
 ],
 CSF_EN + [
  "WARNING, NOTE: TWO NUMBERS IN THIS QUESTION HAVE BEEN CORRECTED — page 64 prints PROTEIN 90 and RBC 100,",
  "and the extracted text read '09' and '001'.",
  "THE PATIENT: a young man with fever, headache, SEIZURES and impaired consciousness since yesterday.",
  "WARNING, FIRST A CONCEPTUAL DISTINCTION: MENINGITIS OR ENCEPHALITIS?",
  "MENINGITIS IS INFLAMMATION OF THE MEMBRANES — headache, fever, neck stiffness, but BRAIN FUNCTION IS PRESERVED.",
  "ENCEPHALITIS IS INFLAMMATION OF THE BRAIN PARENCHYMA ITSELF — BEHAVIOURAL CHANGE, SEIZURES, FOCAL DEFICITS, ALTERED CONSCIOUSNESS.",
  "THIS PATIENT HAS SEIZURES AND ALTERED CONSCIOUSNESS — so this is ENCEPHALITIS, not merely meningitis.",
  "NOW PUT THE PANEL AND THE IMAGING TOGETHER:",
  "WBC = 100 — mild pleocytosis, consistent with viral.",
  "PROTEIN = 90 — mildly raised.",
  "WARNING, RBC = 100 WITHOUT TRAUMA OR A BLOODY TAP — and that is the golden finding.",
  "WHY RED CELLS? BECAUSE HERPES ENCEPHALITIS IS A HAEMORRHAGIC NECROSIS.",
  "WARNING, AND WHERE? THE TEMPORAL LOBE — exactly what this patient's MRI shows.",
  "WHY THE TEMPORAL LOBE? Because the virus ascends along the OLFACTORY OR TRIGEMINAL NERVE",
  "and reaches the MEDIAL TEMPORAL AND ORBITOFRONTAL regions first.",
  "That location explains the behavioural and memory disturbance and the temporal seizures.",
  "WARNING, TREATMENT: INTRAVENOUS ACICLOVIR, IMMEDIATELY, WITHOUT WAITING FOR PCR.",
  "Untreated mortality exceeds 70 PER CENT; with early treatment it falls below 20 PER CENT.",
  "DEFINITIVE DIAGNOSIS: CSF PCR FOR HSV (sensitivity and specificity above 95%).",
 ],
 "⚠️ **توجه: دو عدد این سؤال تصحیح شده است.** صفحه‌ی ۶۴ **پروتئین ۹۰** و **RBC = ۱۰۰** چاپ کرده، و متن استخراج‌شده «۰۹» و «۰۰۱» داشت که هیچ‌کدام عدد نیستند.\n\n"
 "**بیمار: مرد جوان با تب، سردرد، تشنج و اختلال سطح هوشیاری از دیروز.**\n\n"
 "⚠️ **اول یک تمایز مفهومی که کل این سؤال روی آن سوار است: مننژیت یا انسفالیت؟**\n\n"
 "**مننژیت = التهاب پرده‌های مغز** ← سردرد، تب، سفتی گردن؛ ولی **هوشیاری و عملکرد مغز حفظ است**\n"
 "**انسفالیت = التهاب خودِ بافت مغز** ← **تغییر رفتار، تشنج، نقص فوکال، اختلال هوشیاری**\n\n"
 "**این بیمار تشنج و اختلال هوشیاری دارد — پس انسفالیت است.**\n\n"
 "**حالا پنل و تصویربرداری را کنار هم بگذارید:**\n\n"
 "**WBC = ۱۰۰** ← پلئوسیتوز خفیف، سازگار با ویروسی\n"
 "**پروتئین = ۹۰** ← مختصر بالا\n"
 "⚠️ **RBC = ۱۰۰ بدون سابقه‌ی تروما یا تپ خونی** ← **یافته‌ی طلایی**\n\n"
 "**چرا گلبول قرمز در CSF؟** چون **انسفالیت هرپسی یک نکروز خونریزی‌دهنده است**. و ⚠️ **کجا؟ لوب تمپورال** — که MRI بیمار دقیقاً همان را نشان می‌دهد.\n\n"
 "**چرا لوب تمپورال؟** چون ویروس از **عصب بویایی یا شاخه‌های تری‌ژمینال** بالا می‌آید و ابتدا به **لوب تمپورال داخلی و ناحیه‌ی اربیتوفرونتال** می‌رسد. همین محل، **اختلال رفتار، اختلال حافظه، و تشنج‌های تمپورال** را توضیح می‌دهد — یعنی آناتومی، تابلوی بالینی را می‌سازد.\n\n"
 "⚠️ **و مهم‌ترین نکته‌ی عملی: آسیکلوویر وریدی را فوراً شروع کنید، بدون انتظار برای PCR.**\n\n"
 "مرگ‌ومیر انسفالیت هرپسی **بدون درمان بیش از ۷۰ درصد** است و **با درمان زودهنگام به کمتر از ۲۰ درصد** می‌رسد. تأخیر حتی چند ساعته، پیامد را بدتر می‌کند. **تشخیص قطعی با PCR مایع نخاع** انجام می‌شود (حساسیت و ویژگی بالای ۹۵ درصد)، ولی درمان منتظر آن نمی‌ماند.",
 "WARNING, NOTE: TWO NUMBERS IN THIS QUESTION HAVE BEEN CORRECTED. Page 64 prints PROTEIN 90 and RBC 100, and the extracted text read '09' and '001', neither of which is a number.\n\n"
 "THE PATIENT: a young man with fever, headache, SEIZURES and impaired consciousness since yesterday.\n\n"
 "WARNING, FIRST A CONCEPTUAL DISTINCTION ON WHICH THE WHOLE QUESTION RESTS: MENINGITIS OR ENCEPHALITIS?\n\n"
 "MENINGITIS IS INFLAMMATION OF THE MENINGES — headache, fever, neck stiffness; but BRAIN FUNCTION IS PRESERVED\n"
 "ENCEPHALITIS IS INFLAMMATION OF THE BRAIN TISSUE ITSELF — BEHAVIOURAL CHANGE, SEIZURES, FOCAL DEFICITS, ALTERED CONSCIOUSNESS\n\n"
 "THIS PATIENT HAS SEIZURES AND ALTERED CONSCIOUSNESS — so this is ENCEPHALITIS.\n\n"
 "NOW PUT THE PANEL AND THE IMAGING TOGETHER:\n\n"
 "WBC = 100 — mild pleocytosis, consistent with viral\n"
 "PROTEIN = 90 — mildly raised\n"
 "WARNING, RBC = 100 WITHOUT TRAUMA OR A BLOODY TAP — THE GOLDEN FINDING\n\n"
 "WHY RED CELLS IN THE CSF? Because HERPES ENCEPHALITIS IS A HAEMORRHAGIC NECROSIS. And WARNING, WHERE? THE TEMPORAL LOBE — exactly what this patient's MRI shows.\n\n"
 "WHY THE TEMPORAL LOBE? Because the virus ascends along the OLFACTORY NERVE OR TRIGEMINAL BRANCHES and reaches the MEDIAL TEMPORAL LOBE AND ORBITOFRONTAL REGION first. That location explains the BEHAVIOURAL DISTURBANCE, MEMORY IMPAIRMENT AND TEMPORAL SEIZURES — the anatomy creates the clinical picture.\n\n"
 "WARNING, AND THE KEY PRACTICAL POINT: START INTRAVENOUS ACICLOVIR IMMEDIATELY, WITHOUT WAITING FOR PCR.\n\n"
 "Mortality in herpes encephalitis EXCEEDS 70 PER CENT UNTREATED and falls BELOW 20 PER CENT WITH EARLY TREATMENT. Even a few hours' delay worsens the outcome. DEFINITIVE DIAGNOSIS IS BY CSF PCR (sensitivity and specificity above 95%), but treatment does not wait for it.",
 ["پاسخ صحیح — گلبول قرمز در CSF بدون تروما به‌همراه درگیری لوب تمپورال: انسفالیت هرپسی.",
  "پنوموکوک تابلوی نوتروفیلی با قند پایین می‌سازد و درگیری انتخابی لوب تمپورال ندارد.",
  "مننگوکوک هم باکتریال است و با راش پتشی و پنل نوتروفیلی مطرح می‌شود، نه با نکروز تمپورال.",
  "هموفیلوس آنفولانزا عامل باکتریال است و این تابلوی انسفالیتی با گلبول قرمز را نمی‌سازد."],
 ["Correct — red cells in the CSF without trauma, with temporal lobe involvement: herpes encephalitis.",
  "Pneumococcus produces a neutrophilic picture with low glucose and no selective temporal involvement.",
  "Meningococcus is also bacterial and presents with a petechial rash and neutrophilic panel, not temporal necrosis.",
  "Haemophilus influenzae is a bacterial agent and does not produce this encephalitic picture with red cells."],
 "**RBC در CSF + لوب تمپورال = هرپس.** آسیکلوویر **فوراً**، بدون انتظار برای PCR.",
 "Red cells in the CSF plus temporal lobe involvement means herpes. Give aciclovir at once, without waiting for PCR.",
 [H133])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book26.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 26 lessons:', len(L))
