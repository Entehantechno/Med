# -*- coding: utf-8 -*-
"""Repair the mirrored drug doses of the viral / STI chapter.

Same method as the parasitology pass: pdfplumber reports each glyph's
x-coordinate, and a number is drawn left to right even inside right-to-left
script, so sorting a line's digits by x0 recovers the printed value. The
extracted text stores the LOGICAL order, and that is where a run gets reversed.

All four repairs are in ONE question, q9548, and all four are in the OPTIONS —
which is the whole reason they matter. Every option of that question is a drug
regimen, and the mirrored form makes each of them pharmacological nonsense:

    "سیپروفلوکساسین mg005"   ciprofloxacin 5 mg      -> 500 mg
    "سفیکسیم mg004"           cefixime 4 mg           -> 400 mg
    "داکسی‌سیکلین mg001"      doxycycline 1 mg        -> 100 mg   (twice)

A student comparing "cefixime 4 mg" with "ciprofloxacin 5 mg" is not being
asked a medical question at all. Page 205 prints, in x-order:

    5@343.6 0@353.7 0@363.7   -> 500
    4@401.7 0@411.7 0@421.7   -> 400
    1@121.0 0@131.1 0@141.1   -> 100
    1@379.1 0@389.2 0@399.2   -> 100

Note what is NOT changed. The audit flagged 29 disagreements in this chapter,
but 25 of them were the matcher failing on a stem that spans two printed lines,
not a mirrored value; each was re-checked against the page by hand and the
stored number was right. Two deserve recording because they LOOK wrong and are
not:

  q9701  "CD4 = 95"  — page 259 prints 9@541.5 5@551.5, so 95 is correct;
         the mirror 59 was tempting but the geometry says otherwise.
  q9696  "CD4 کمتر از ml200" — page 257 prints 2@505.5 0@515.5 0@525.5, so the
         value 200 is right and only the unit label reads oddly.

Recording the near-misses matters as much as recording the repairs: the point
of the geometry check is that it can say NO.
"""
import json, io, os, collections

import pdfplumber

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = '/home/user/uploads/بیماری عفونی.pdf'

# question -> list of (page, old, new, expected-printed-run, why)
FIXES = {
    9548: [
        (205, 'mg005', 'mg500', '500',
         'دوز سیپروفلوکساسین: صفحه ۲۰۵ رقم‌ها را ۵۰۰ چاپ کرده است.'),
        (205, 'mg004', 'mg400', '400',
         'دوز سفیکسیم: صفحه ۲۰۵ رقم‌ها را ۴۰۰ چاپ کرده است.'),
        (205, 'mg001', 'mg100', '100',
         'دوز داکسی‌سیکلین: صفحه ۲۰۵ رقم‌ها را ۱۰۰ چاپ کرده است.'),
    ],
}


def page_digit_runs(pdf, pno):
    page = pdf.pages[pno - 1]
    rows = collections.defaultdict(list)
    for c in page.chars:
        rows[round(c['top'])].append(c)
    runs = []
    for top in sorted(rows):
        cs = sorted(rows[top], key=lambda c: c['x0'])
        cur = ''
        for c in cs:
            t = c['text']
            if t.isspace() and cur:
                continue
            if t.isdigit() or (cur and t in './'):
                cur += t
            else:
                if cur:
                    runs.append(cur.strip('./'))
                cur = ''
        if cur:
            runs.append(cur.strip('./'))
    return runs


def main():
    pages = {p for specs in FIXES.values() for (p, *_rest) in specs}
    with pdfplumber.open(SRC) as pdf:
        printed = {p: page_digit_runs(pdf, p) for p in pages}

    applied, missing = [], []
    for i in range(1, 6):
        path = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        body = json.load(io.open(path, encoding='utf-8'))
        dirty = False
        for q in body['questions']:
            specs = FIXES.get(q['question_no'])
            if not specs:
                continue
            for pno, old, new, expect, why in specs:
                assert expect in printed[pno], \
                    f'q{q["question_no"]}: page {pno} does not print {expect}'
                hit = False
                # a dose may legitimately appear in more than one option
                for oi, opt in enumerate(q['options_fa']):
                    if old in opt:
                        q.setdefault('options_original_fa', list(q['options_fa']))
                        q['options_fa'][oi] = opt.replace(old, new)
                        q.setdefault('stem_number_corrections', []).append({
                            'from': old, 'to': new, 'page': pno,
                            'where': f'option {oi + 1}',
                            'method': 'glyph geometry (pdfplumber x-order)',
                            'why_fa': why})
                        applied.append(f'q{q["question_no"]}: {old} -> {new} (option {oi + 1})')
                        hit = True
                        dirty = True
                if old in q['question_fa']:
                    q.setdefault('stem_original_fa', q['question_fa'])
                    q['question_fa'] = q['question_fa'].replace(old, new)
                    q.setdefault('stem_number_corrections', []).append({
                        'from': old, 'to': new, 'page': pno, 'where': 'stem',
                        'method': 'glyph geometry (pdfplumber x-order)',
                        'why_fa': why})
                    applied.append(f'q{q["question_no"]}: {old} -> {new} (stem)')
                    hit = True
                    dirty = True
                if not hit:
                    missing.append(f'q{q["question_no"]}: {old!r} not found')
        if dirty:
            json.dump(body, io.open(path, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)

    for a in applied:
        print('fixed  ', a)
    for m in missing:
        print('MISSING', m)
    print(f'\n{len(applied)} corrections written, {len(missing)} not found')


if __name__ == '__main__':
    main()
