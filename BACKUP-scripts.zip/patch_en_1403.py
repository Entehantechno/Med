# -*- coding: utf-8 -*-
"""Add English text to the Esfand-1403 infectious items.

The ministry printed no English booklet for this sitting, so unlike every other
sitting in this bank these strings are OUR translation rather than the official
one. They are marked `en_source: 'translated'` so a reader can always tell the
difference, and they are written in plain clinical English aimed at a student,
not word-for-word from the Persian.
"""
import json, io, os

HERE = os.path.dirname(os.path.abspath(__file__))
PATH = os.path.join(HERE, 'out', 'inf_1403_12.json')

EN = {
 103: (
  "A 27-year-old woman has come to the emergency department with nausea, vomiting and fever. "
  "On examination she has a high fever, neck stiffness and weakness of the left lower limb. "
  "CSF analysis shows WBC 1000/µL with 90% PMNs, glucose 20 mg/dL and protein 105 mg/dL. "
  "What is the appropriate treatment?",
  ["Ceftriaxone + vancomycin + ampicillin",
   "Ceftriaxone + vancomycin + metronidazole",
   "Ceftriaxone + vancomycin + acyclovir",
   "Ceftriaxone + vancomycin + levofloxacin"]),
 104: (
  "A 23-year-old woman presents 6 hours after eating a salad with watery diarrhoea, nausea and "
  "vomiting. The abdominal pain is colicky in nature. Which organism is the main cause of her illness?",
  ["Staphylococcus aureus", "Escherichia coli", "Shigella", "Listeria"]),
 105: (
  "A 45-year-old man comes to the emergency department with diplopia, ptosis, dysphagia and a "
  "symmetrical descending paralysis. He ate a tin of canned fish about 24 hours earlier. "
  "Which of the following must be done immediately?",
  ["Give high-dose intravenous corticosteroids",
   "Give the specific antitoxin and prepare for intubation",
   "Admit to the infectious diseases ward, start antibiotics and monitor closely",
   "Admit to the ICU and intubate and ventilate if required"]),
 106: (
  "A 30-year-old woman cuts her hand on a dirty knife while working in the kitchen and comes to "
  "the clinic. Her childhood vaccination was complete and her last tetanus vaccine was 6 years ago. "
  "Which of the following is required to prevent tetanus?",
  ["Immunoglobulin and vaccine", "Immunoglobulin", "Toxoid and vaccine", "Wound cleaning and follow-up"]),
 107: (
  "A 60-year-old diabetic man presents with persistent fever, severe low back pain, radiculopathy, "
  "weakness and numbness of the lower limbs and loss of urinary control. Lumbar MRI reports T1 "
  "enhancement in the intervertebral space and a microabscess in the epidural region. Blood culture "
  "grows a methicillin-resistant Gram-positive organism. Which antibiotic is preferred?",
  ["Cefepime", "Vancomycin", "Clindamycin", "Ciprofloxacin"]),
 108: (
  "A 58-year-old man with a long history of alcohol use and very poor oral hygiene presents with "
  "fever and a productive, extremely foul-smelling cough. Chest radiography shows a cavity with an "
  "air-fluid level together with consolidation in the right lower lobe. Which mechanism is responsible "
  "for this condition?",
  ["Haematogenous spread of bacteria to the lung",
   "Aspiration of oropharyngeal secretions",
   "Abscess caused by bronchial obstruction from a tumour",
   "Reactivation of latent tuberculosis due to a weakened immune system"]),
}


def run():
    rows = json.load(io.open(PATH, encoding='utf-8'))
    for r in rows:
        stem, opts = EN[r['question_no']]
        assert len(opts) == 4
        r['stem_en'] = stem
        r['options_en'] = opts
        r['en_source'] = 'translated'
    json.dump(rows, io.open(PATH, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(f'added English to {len(rows)} Esfand-1403 items')


if __name__ == '__main__':
    run()
