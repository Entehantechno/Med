# -*- coding: utf-8 -*-
"""Bring batches 1 and 2 up to the >=10 micro-point standard used by L3-L11.

These twelve lessons were written first, to a nine-point template, before the
standard settled at ten. Rather than rewrite them (and risk disturbing text the
user has already reviewed) we append the two points each was missing. Idempotent:
re-running adds nothing, because we check for the point before appending.
"""
import json, io, os

HERE = os.path.dirname(os.path.abspath(__file__))

EXTRA = {
 "1404-09:103": [
  ("آرتسونات وریدی حداقل سه دوز در ساعت صفر، دوازده و بیست و چهار داده می‌شود.",
   "Intravenous artesunate is given as at least three doses at hours zero, twelve and twenty-four."),
  ("پس از تحمل خوراکی، درمان با یک رژیم کامل ACT ادامه می‌یابد تا از عود جلوگیری شود.",
   "Once oral intake is tolerated, a full ACT course follows to prevent recrudescence."),
 ],
 "1404-09:104": [
  ("افتراق مهم با گیلن‌باره: بوتولیسم فلج نزولی می‌دهد و گیلن‌باره صعودی.",
   "A key distinction from Guillain-Barre: botulism paralyses downward, Guillain-Barre upward."),
  ("پایش ظرفیت حیاتی ضروری است، چون نارسایی تنفسی علت اصلی مرگ در بوتولیسم است.",
   "Vital capacity monitoring is essential, since respiratory failure is the leading cause of death."),
 ],
 "1404-09:105": [
  ("مترونیدازول تروفوزوئیت بافتی را می‌کشد ولی غلظت لومنی کافی ایجاد نمی‌کند.",
   "Metronidazole kills tissue trophozoites but does not reach adequate luminal concentrations."),
  ("داروی لومنی مثل پارومومایسین یا یدوکینول پس از اتمام مترونیدازول شروع می‌شود، نه همزمان.",
   "The luminal agent, paromomycin or iodoquinol, starts after metronidazole finishes, not alongside it."),
 ],
 "1404-09:106": [
  ("پروفیلاکسی کزاز و ارزیابی خطر هاری در هر گازگرفتگی حیوانی جداگانه بررسی می‌شود.",
   "Tetanus prophylaxis and rabies risk assessment are considered separately in every animal bite."),
  ("زخم گازگرفتگی دست معمولاً بسته نمی‌شود، چون خطر عفونت بسته‌شدن اولیه بالاست.",
   "Bite wounds of the hand are usually left open, because primary closure carries a high infection risk."),
 ],
 "1404-09:107": [
  ("پنومونیت آسپیراسیون در چند ساعت اول تصویر برق‌آسا می‌دهد ولی اغلب خودبه‌خود فروکش می‌کند.",
   "Aspiration pneumonitis produces a dramatic picture within hours but usually settles spontaneously."),
  ("در مقابل، پنومونی آسپیراسیون طی روزها پیشرفت می‌کند و پوشش بی‌هوازی لازم دارد.",
   "Aspiration pneumonia, by contrast, evolves over days and does require anaerobic cover."),
 ],
 "1404-09:108": [
  ("پیش از شروع anti-TNF، غربالگری سل نهفته با TST یا IGRA الزامی است.",
   "Before starting anti-TNF therapy, latent TB screening with TST or IGRA is mandatory."),
  ("anti-TNF گرانولوم را ناپایدار می‌کند و باسیل خفته را آزاد می‌سازد، پس خطر فعال‌شدن بالاست.",
   "Anti-TNF destabilises granulomas and releases dormant bacilli, so the reactivation risk is high."),
 ],
 "1403-12:103": [
  ("لیستریا به سفالوسپورین‌ها ذاتاً مقاوم است، پس افزودن آمپی‌سیلین ضروری است.",
   "Listeria is intrinsically resistant to cephalosporins, so adding ampicillin is essential."),
  ("در آلرژی به پنی‌سیلین، کوتریموکسازول جایگزین پوشش لیستریا محسوب می‌شود.",
   "With penicillin allergy, co-trimoxazole substitutes for Listeria cover."),
 ],
 "1403-12:104": [
  ("استاف اورئوس با کمون یک تا شش ساعت و استفراغ غالب مطرح می‌شود.",
   "Staphylococcus aureus is suggested by a one-to-six-hour incubation with prominent vomiting."),
  ("باسیلوس سرئوس فرم استفراغی (برنج سرخ‌شده) و فرم اسهالی با کمون طولانی‌تر دارد.",
   "Bacillus cereus has an emetic form (fried rice) and a diarrhoeal form with a longer incubation."),
 ],
 "1403-12:105": [
  ("آنتی‌توکسین فقط توکسین آزاد در گردش را خنثی می‌کند و توکسین متصل برگشت‌ناپذیر است.",
   "Antitoxin neutralises only free circulating toxin; bound toxin is irreversible."),
  ("گزارش فوری به نظام مراقبت بهداشتی الزامی است، چون منبع غذایی مشترک ممکن است دیگران را هم درگیر کند.",
   "Immediate public-health notification is mandatory, since a shared food source may affect others."),
 ],
 "1403-12:106": [
  ("ایمونوگلوبولین کزاز فقط برای زخم آلوده در فرد با کمتر از سه دوز قبلی لازم است.",
   "Tetanus immunoglobulin is needed only for a dirty wound in someone with fewer than three prior doses."),
  ("واکسن و ایمونوگلوبولین باید با سرنگ جدا و در دو اندام مختلف تزریق شوند.",
   "Vaccine and immunoglobulin must be given with separate syringes in two different limbs."),
 ],
 "1403-12:107": [
  ("سه‌گانه‌ی کلاسیک آبسه‌ی اپی‌دورال: کمردرد، تب و نقص عصبی پیشرونده.",
   "The classic triad of epidural abscess: back pain, fever and progressive neurological deficit."),
  ("MRI با گادولینیوم روش تصویربرداری انتخابی است و تأخیر در آن به فلج دائمی می‌انجامد.",
   "Gadolinium-enhanced MRI is the imaging of choice, and delay risks permanent paralysis."),
 ],
 "1403-12:108": [
  ("پوشش بی‌هوازی با آمپی‌سیلین-سولباکتام یا کلیندامایسین انجام می‌شود.",
   "Anaerobic cover is provided by ampicillin-sulbactam or clindamycin."),
  ("درمان تا برطرف شدن کاویته در تصویربرداری ادامه می‌یابد و اغلب چند هفته طول می‌کشد.",
   "Treatment continues until the cavity resolves radiologically, often taking several weeks."),
 ],
}


def main():
    changed = 0
    for name in ('L1', 'L2'):
        p = os.path.join(HERE, 'lessons', f'{name}.json')
        d = json.load(io.open(p, encoding='utf-8'))
        for key, pairs in EXTRA.items():
            if key not in d:
                continue
            m = d[key]['micro']
            for fa, en in pairs:
                if fa not in m['points_fa']:
                    m['points_fa'].append(fa)
                    m['points_en'].append(en)
                    changed += 1
            assert len(m['points_fa']) == len(m['points_en']) >= 10, key
        json.dump(d, io.open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(f'patch_micro: added {changed} micro-point(s)')


if __name__ == '__main__':
    main()
