# -*- coding: utf-8 -*-
"""Quarantine book questions whose printed answer key is medically unsafe.

Background
----------
The book prints an answer under every question and our extraction of those
letters was verified line-by-line against the PDF — so these are the book's own
keys, not parsing errors. Auditing them against Harrison 21e found four where
the printed key is simply wrong:

  * typhoid vignette answered "meningitis"; the classic severe complications
    of enteric fever are intestinal perforation and GI haemorrhage in week 3
  * two HIV items answered "repeat the ELISA"; a reactive screening assay is
    confirmed with a supplemental test, not repeated
  * presumptive urethritis answered "none of the above" when ceftriaxone plus
    azithromycin is exactly the recommended regimen

A wrong key is worse than a missing question: it teaches the wrong medicine
with the authority of a printed answer. These are therefore marked
`key_disputed` and `premium` so they are excluded from the learner-facing bank
until a human resolves them, while staying in the file for review.
"""
import json, io, os

BANK = '/home/user/project/tools/infectious-bank'
AUDIT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'out', 'key_audit.json')


def main():
    flagged = json.load(io.open(AUDIT, encoding='utf-8'))
    # the audit records a flat index across the concatenated parts
    bad = {f['idx']: f for f in flagged}

    n = 0
    seen = 0
    for i in range(1, 6):
        p = os.path.join(BANK, f'import-payload.book.part{i:02d}.json')
        if not os.path.exists(p):
            continue
        body = json.load(io.open(p, encoding='utf-8'))
        for q in body['questions']:
            f = bad.get(seen)
            seen += 1
            if not f:
                continue
            q['key_disputed'] = True
            q['key_dispute_reason'] = f['rule']
            q['key_expected'] = f['expected']
            # keep it out of the learner-facing bank entirely
            q['premium'] = True
            q['needs_review'] = True
            n += 1
        json.dump(body, io.open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

    print(f'scanned {seen} questions, quarantined {n} with a disputed key')
    for f in flagged:
        print(f"   idx={f['idx']}  {f['rule']}  ({f['year']}-{f['month']})")


if __name__ == '__main__':
    main()
