# -*- coding: utf-8 -*-
"""One printed key in the viral / STI chapter that is wrong: q9542.

The conservative rule again: the printed key is presumed right and is overruled
only when a primary source says plainly that it is wrong AND the argument
survives being written out for a student. This one does not survive; the key
does.

------------------------------------------------------------------ q9542
"A young man treated for urethritis with ceftriaxone returns TWO WEEKS later
with MUCOID discharge, burning and itching. What is the appropriate action?"
Printed key: (C) repeat the ceftriaxone, 1 g.

That cannot be right, and the strongest argument is not from a foreign guideline
but from THE BOOK ITSELF. The same chapter asks this identical clinical scenario
four more times, and every other time the book answers it correctly:

  q9541  gonococcus treated with ceftriaxone, mucoid discharge returns a week
         later -> key: CONCURRENT CHLAMYDIA TRACHOMATIS INFECTION
  q9545  urethritis treated with one ceftriaxone injection, urethritis returns a
         week later with no new contact -> key: GIVE 1 g AZITHROMYCIN
  q9555  gonococcus treated with ceftriaxone, mucoid discharge returns a week
         later -> key: none of the above (the book's way of rejecting "resistance"
         and rejecting re-treating the gonococcus)
  q9539  urethritis treated with ceftriaxone AND doxycycline, symptoms return
         -> key: metronidazole + azithromycin (i.e. now think trichomonas and
         M. genitalium, still not more ceftriaxone)

So the book teaches the right rule four times and contradicts itself once. The
medicine behind that rule:

  * Ceftriaxone treats the GONOCOCCUS and has no useful activity against
    Chlamydia trachomatis. When gonorrhoea is treated with ceftriaxone alone, an
    untreated chlamydial co-infection — present in a large minority of cases —
    declares itself a week or two later as POST-GONOCOCCAL URETHRITIS. The
    discharge changes character, from frankly purulent to scanty and MUCOID,
    which is exactly what this stem describes.
  * The 2021 CDC STI Treatment Guidelines make the same point from the other
    direction: "If chlamydial infection has not been excluded, providers should
    treat for chlamydia." And on recurrence they warn that "reinfections are
    more likely than actual treatment failures", so the answer to a relapse is
    not automatically more of the same drug.
  * True ceftriaxone failure is rare and is defined by symptoms persisting
    3-5 days after treatment, not by new symptoms appearing after a two-week
    symptom-free interval. This patient got better and then relapsed — the
    timeline of an untreated second organism, not of a resistant first one.
  * Of the four options offered, only AZITHROMYCIN 1 g covers Chlamydia.
    Ciprofloxacin and spectinomycin are anti-gonococcal, and repeating the
    ceftriaxone treats an organism that has already been cured.

  Correction: C -> D (azithromycin 1 g single dose).

The lesson teaches the mechanism, names the book's own four consistent answers,
and tells the student plainly that this one printed key is the outlier — which
is more useful than either silently "fixing" it or silently teaching it.
"""
import json, io, os

HERE = os.path.dirname(os.path.abspath(__file__))

FIXES = {
    9542: {
        'to': 3,
        'expect_from': 2,
        'fa': 'کلید چاپی «تکرار آمپول سفتریاکسون» را انتخاب کرده است، ولی قوی‌ترین دلیل '
              'رد آن، **خودِ همین کتاب** است: این سناریو در همین فصل چهار بار دیگر پرسیده '
              'شده و هر چهار بار پاسخ درست داده شده — q9541 «کلامیدیای همزمان»، q9545 '
              '«یک گرم آزیترومایسین»، q9555 «هیچ‌کدام» (یعنی رد مقاومت و رد تکرار '
              'سفتریاکسون)، و q9539 «مترونیدازول + آزیترومایسین». پس کتاب قاعده را چهار '
              'بار درست آموزش می‌دهد و یک بار با خودش متناقض می‌شود.\n\n'
              'پزشکیِ پشت این قاعده: **سفتریاکسون گونوکوک را درمان می‌کند و روی کلامیدیا '
              'اثر مفیدی ندارد.** وقتی سوزاک تنها با سفتریاکسون درمان شود، کلامیدیای '
              'همزمانِ درمان‌نشده یک تا دو هفته بعد خود را به شکل **اورتریت پس از '
              'گونوکوک** نشان می‌دهد و ترشح از چرکی به **موکوئیدی** تغییر می‌کند — دقیقاً '
              'همان چیزی که در صورت سؤال آمده. ضمناً شکست واقعی سفتریاکسون با **باقی '
              'ماندن** علائم در ۳ تا ۵ روز اول تعریف می‌شود، نه با عود پس از دو هفته '
              'بهبودی. از میان چهار گزینه، تنها **آزیترومایسین** کلامیدیا را پوشش می‌دهد.',
        'en': 'The printed key chooses "repeat the ceftriaxone", but the strongest argument '
              'against it is THE BOOK ITSELF: this same scenario is asked four more times in '
              'this chapter and answered correctly every time — q9541 "concurrent chlamydia", '
              'q9545 "azithromycin 1 g", q9555 "none of the above" (rejecting both resistance '
              'and re-treating the gonococcus), and q9539 "metronidazole + azithromycin". The '
              'book teaches the rule correctly four times and contradicts itself once.\n\n'
              'The medicine behind the rule: CEFTRIAXONE TREATS THE GONOCOCCUS AND HAS NO '
              'USEFUL ACTIVITY AGAINST CHLAMYDIA. When gonorrhoea is treated with ceftriaxone '
              'alone, an untreated chlamydial co-infection declares itself one to two weeks '
              'later as POST-GONOCOCCAL URETHRITIS, with the discharge turning from purulent '
              'to MUCOID — exactly what this stem describes. True ceftriaxone failure is '
              'defined by symptoms PERSISTING at 3-5 days, not by relapse after two symptom-'
              'free weeks. Of the four options, only AZITHROMYCIN covers Chlamydia.',
        'refs': ['CDC Sexually Transmitted Infections Treatment Guidelines, 2021 — '
                 'Urethritis and Cervicitis; Gonococcal Infections',
                 "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 155 "
                 '(Neisseria gonorrhoeae) and Ch. 178 (Chlamydia trachomatis)',
                 'Internal consistency of the source: q9541, q9545, q9555 and q9539 of the '
                 'same chapter all answer this scenario the other way'],
    },
}


def main():
    done = []
    for i in range(1, 6):
        p = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        body = json.load(io.open(p, encoding='utf-8'))
        dirty = False
        for q in body['questions']:
            spec = FIXES.get(q['question_no'])
            if not spec:
                continue
            if q['correct_index'] == spec['to'] and q.get('key_corrected'):
                continue
            assert q['correct_index'] == spec['expect_from'], (
                f"q{q['question_no']}: expected printed key {spec['expect_from']}, "
                f"found {q['correct_index']}")
            q['original_correct_index'] = q['correct_index']
            q['correct_index'] = spec['to']
            q['key_corrected'] = True
            q['key_correction_fa'] = spec['fa']
            q['key_correction_en'] = spec['en']
            q['key_correction_source'] = '; '.join(spec['refs'])
            done.append(f"q{q['question_no']}: {spec['expect_from'] + 1} -> {spec['to'] + 1}  "
                        f"({q['options_fa'][spec['to']][:46]})")
            dirty = True
        if dirty:
            json.dump(body, io.open(p, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)
    for d in done:
        print('key fixed', d)
    print(f'\n{len(done)} keys corrected')


if __name__ == '__main__':
    main()
