# -*- coding: utf-8 -*-
"""Micro-lessons, batch 23 — influenza and the acute respiratory viruses.

The second half of the respiratory chapter. Thirty-three of its fifty-seven
questions are influenza, and they are unusually repetitive: the examiners ask
the SAME four decisions over and over, with the patient changed each time.

The four decisions, and the single rule behind each
---------------------------------------------------
1. IS THIS INFLUENZA OR A COMMON COLD? Influenza begins ABRUPTLY, with
   SYSTEMIC symptoms out of proportion to the respiratory ones: high fever,
   shaking rigors, severe myalgia, headache. A cold begins gradually and stays
   local: sneezing, rhinorrhoea, mild sore throat, no fever. And the exam's
   favourite discriminator: EXUDATE ON THE PHARYNX IS NOT INFLUENZA.

2. WHO IS HIGH RISK? This one list answers at least eight questions. It is
   also where the numeric defects of this chapter lived, because a mirrored
   age silently moves a patient across a boundary.

3. TREAT WITH AN ANTIVIRAL, OR NOT AT ALL? Oseltamivir for the high-risk, the
   hospitalised and the progressive. Symptomatic care for the healthy young
   adult. And NEVER an antibiotic for uncomplicated influenza.

4. WHICH COMPLICATION IS THIS? Three post-influenza pneumonias, separated by
   their TIMING, not by their severity. This is the most conceptually
   demanding block in the chapter and four questions turn on it.

The two absolute prohibitions
-----------------------------
ASPIRIN IN A CHILD WITH INFLUENZA — Reye's syndrome.
AMANTADINE AND RIMANTADINE — abandoned since 2009 for near-universal
resistance. Any option containing them is wrong, in every question, always.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022), Ch. 195
(Influenza); CDC/ACIP Prevention and Control of Seasonal Influenza with
Vaccines; CDC Influenza Antiviral Medications: Summary for Clinicians;
Uyeki TM et al., IDSA Clinical Practice Guideline on Influenza, Clin Infect
Dis 2019;68:e1.
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H195 = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 195: Influenza"
ACIP = "CDC / ACIP — Prevention and Control of Seasonal Influenza with Vaccines: Recommendations of the Advisory Committee on Immunization Practices"
CDCAV = "CDC — Influenza Antiviral Medications: Summary for Clinicians"
IDSAF = ("Uyeki TM et al. — Clinical Practice Guidelines by the Infectious Diseases Society of "
         "America: 2018 Update on Diagnosis, Treatment, Chemoprophylaxis, and Institutional "
         "Outbreak Management of Seasonal Influenza. Clin Infect Dis 2019;68(6):e1-e47")

FLU_FA = [
    "⚠️ **آنفلوانزا با سرماخوردگی فرق دارد، و تفاوت در «شروع» و «نسبت علائم» است.**",
    "**آنفلوانزا: شروع ناگهانی** — بیمار ساعت شروع را به یاد می‌آورد.",
    "**علائم سیستمیک غالب‌اند:** تب بالا، **لرز تکان‌دهنده**، **میالژی شدید**، سردرد، ضعف مفرط.",
    "علائم تنفسی (سرفه‌ی خشک، گلودرد) **در مقایسه با علائم سیستمیک خفیف‌ترند**.",
    "**سرماخوردگی: شروع تدریجی** و علائم **موضعی**: عطسه، آبریزش بینی، گلودرد خفیف، **بدون تب**.",
    "⚠️ **افتراق طلایی امتحان: اگزودای فارنکس با آنفلوانزا نمی‌خواند.**",
    "در آنفلوانزا حلق **اریتماتو ولی بدون اگزودا** است؛ اگزودا یعنی **استرپتوکوک گروه A** یا **EBV**.",
    "**سردرد آنفلوانزا معمولاً فرونتال یا رتروبولبار است و درد با حرکت چشم مشخصه‌ی آن است.**",
    "**میالژی آنفلوانزا در عضلات بزرگ (ساق و کمر) است، نه موضعی.**",
    "⚠️ **راش پوستی جزو تظاهرات آنفلوانزا نیست** — اگر راش دیدید، به تشخیص دیگری فکر کنید.",
    "**دوره‌ی کمون ۱ تا ۴ روز؛ دفع ویروس از یک روز پیش از علائم تا حدود ۵ تا ۷ روز بعد.**",
    "**سه تیپ ویروس را بشناسید، چون مستقیم پرسیده می‌شود:**",
    "**تیپ A** ← تنها تیپی که **پاندمی** می‌سازد؛ شدیدترین بیماری؛ مخزن حیوانی دارد.",
    "**تیپ B** ← اپیدمی فصلی، به‌ویژه در کودکان؛ شدت متوسط.",
    "⚠️ **تیپ C** ← بیماری **خفیف و شبه‌سرماخوردگی**؛ **اپیدمی و مرگ‌ومیر نمی‌سازد**.",
    "**دو مکانیسم تغییر آنتی‌ژنی را از هم جدا کنید:**",
    "**Antigenic drift**: جهش‌های نقطه‌ای تدریجی ← **اپیدمی سالانه** ← دلیل واکسن سالانه.",
    "⚠️ **Antigenic shift**: **بازآرایی قطعات ژنومی** بین سویه‌های انسانی و حیوانی ← **پاندمی**.",
    "شیفت فقط در **تیپ A** رخ می‌دهد، و به همین دلیل فقط A پاندمی می‌سازد.",
]
FLU_EN = [
    "WARNING: INFLUENZA DIFFERS FROM A COMMON COLD, AND THE DIFFERENCE IS ONSET AND PROPORTION.",
    "INFLUENZA: ABRUPT ONSET — the patient can name the hour it began.",
    "SYSTEMIC SYMPTOMS DOMINATE: high fever, SHAKING RIGORS, SEVERE MYALGIA, headache, prostration.",
    "The respiratory symptoms (dry cough, sore throat) are MILD COMPARED WITH THE SYSTEMIC ONES.",
    "A COLD: GRADUAL ONSET and LOCAL symptoms — sneezing, rhinorrhoea, mild sore throat, NO FEVER.",
    "WARNING, THE EXAM'S GOLDEN DISCRIMINATOR: PHARYNGEAL EXUDATE DOES NOT FIT INFLUENZA.",
    "In influenza the throat is ERYTHEMATOUS BUT WITHOUT EXUDATE; exudate means GROUP A STREPTOCOCCUS or EBV.",
    "THE HEADACHE OF INFLUENZA IS TYPICALLY FRONTAL OR RETRO-ORBITAL, with pain on eye movement.",
    "THE MYALGIA OF INFLUENZA IS IN THE LARGE MUSCLES (calves and back), not localised.",
    "WARNING: A SKIN RASH IS NOT A FEATURE OF INFLUENZA — if you see a rash, think of another diagnosis.",
    "INCUBATION 1 TO 4 DAYS; viral shedding from a day before symptoms until about 5 to 7 days after.",
    "KNOW THE THREE TYPES, because they are asked directly:",
    "TYPE A — the only type that causes PANDEMICS; the most severe disease; it has an animal reservoir.",
    "TYPE B — seasonal epidemics, especially in children; moderate severity.",
    "WARNING, TYPE C — a MILD, COLD-LIKE illness; IT CAUSES NEITHER EPIDEMICS NOR DEATHS.",
    "SEPARATE THE TWO MECHANISMS OF ANTIGENIC CHANGE:",
    "ANTIGENIC DRIFT: gradual point mutations, giving ANNUAL EPIDEMICS — the reason for a yearly vaccine.",
    "WARNING, ANTIGENIC SHIFT: REASSORTMENT OF GENOME SEGMENTS between human and animal strains, giving PANDEMICS.",
    "Shift occurs only in TYPE A, which is why only A causes pandemics.",
]

RISK_FA = [
    "⚠️ **فهرست گروه‌های پرخطر آنفلوانزا را حفظ کنید — دست‌کم هشت سؤال این فصل با همین یک فهرست حل می‌شود:**",
    "**سن ۶۵ سال یا بیشتر.**",
    "**کودکان زیر ۵ سال، و بالاترین خطر در کودکان زیر ۲ سال.**",
    "⚠️ **بارداری در هر سه‌ماهه، و تا ۲ هفته پس از زایمان.**",
    "**بیماری مزمن ریوی** (آسم، COPD)، **قلبی** (به‌جز فشار خون تنها)، **کلیوی**، **کبدی**.",
    "**دیابت و سایر اختلالات متابولیک.**",
    "**هموگلوبینوپاتی‌ها** (از جمله آنمی داسی‌شکل).",
    "**نقص ایمنی** — بیماری یا دارو، شامل HIV و شیمی‌درمانی.",
    "**بیماری‌های عصبی-عضلانی** که سرفه و بلع را مختل می‌کنند.",
    "⚠️ **چاقی مرضی: BMI برابر ۴۰ یا بیشتر** (نه اضافه‌وزن ساده).",
    "**افراد زیر ۱۹ سال که آسپیرین طولانی‌مدت می‌گیرند** (به‌خاطر خطر سندرم ری).",
    "**ساکنان خانه‌های سالمندان و مراکز مراقبت طولانی‌مدت.**",
    "⚠️ **و دو نکته‌ی مرزی که سؤالات روی آن‌ها بنا می‌شوند:**",
    "**فشار خون بالا به‌تنهایی گروه پرخطر نیست** — این استثنا صریحاً در راهنما آمده.",
    "**کودک سالم بالای ۵ سال گروه پرخطر نیست**، هرچند واکسن برایش توصیه می‌شود.",
]
RISK_EN = [
    "WARNING: MEMORISE THE HIGH-RISK LIST — at least eight questions in this chapter are solved by it alone:",
    "AGE 65 YEARS OR OVER.",
    "CHILDREN UNDER 5, with the highest risk in those UNDER 2.",
    "WARNING: PREGNANCY IN ANY TRIMESTER, and up to 2 weeks post partum.",
    "CHRONIC LUNG DISEASE (asthma, COPD), HEART DISEASE (except hypertension alone), KIDNEY, LIVER disease.",
    "DIABETES and other metabolic disorders.",
    "HAEMOGLOBINOPATHIES, including sickle cell disease.",
    "IMMUNOSUPPRESSION — from disease or drugs, including HIV and chemotherapy.",
    "NEUROMUSCULAR DISEASE that impairs coughing and swallowing.",
    "WARNING: MORBID OBESITY, BMI 40 OR ABOVE (not mere overweight).",
    "PEOPLE UNDER 19 ON LONG-TERM ASPIRIN (because of the risk of Reye's syndrome).",
    "RESIDENTS OF NURSING HOMES AND LONG-TERM CARE FACILITIES.",
    "WARNING, AND TWO BORDERLINE POINTS ON WHICH QUESTIONS ARE BUILT:",
    "HYPERTENSION ALONE IS NOT A HIGH-RISK GROUP — the guideline states this exception explicitly.",
    "A HEALTHY CHILD OVER 5 IS NOT A HIGH-RISK GROUP, although vaccination is still recommended.",
]

RX_FA = [
    "⚠️ **درمان ضدویروسی آنفلوانزا: اوسلتامیویر، و برای چه کسی؟**",
    "**همه‌ی بیماران بستری**، **بیماری شدید یا پیشرونده**، و **همه‌ی گروه‌های پرخطر**.",
    "**در فرد جوان سالم با بیماری بدون عارضه، درمان علامتی کافی است.**",
    "**بهترین زمان شروع: ظرف ۴۸ ساعت از شروع علائم** (هرچه زودتر، بهتر).",
    "⚠️ ولی در **بیمار بستری یا با بیماری پیشرونده، حتی پس از ۴۸ ساعت هم شروع می‌شود**.",
    "**شایع‌ترین عارضه‌ی اوسلتامیویر: تهوع و استفراغ** (با غذا خوردن کمتر می‌شود).",
    "**زانامیویر استنشاقی است و در آسم و COPD منع نسبی دارد** چون **برونکواسپاسم** می‌سازد.",
    "⚠️ **پس در بیمار آسمی، اوسلتامیویر خوراکی انتخاب می‌شود نه زانامیویر استنشاقی.**",
    "⚠️ **آمانتادین و ریمانتادین از سال ۲۰۰۹ کنار گذاشته شده‌اند.**",
    "دلیل: **مقاومت تقریباً صددرصدی** سویه‌های در گردش. ضمناً روی **تیپ B اصلاً اثر ندارند**.",
    "**هر گزینه‌ای که آمانتادین یا ریمانتادین داشته باشد، در هر سؤالی، غلط است.**",
    "⚠️ **آنتی‌بیوتیک در آنفلوانزای بدون عارضه هیچ جایی ندارد** — بیماری ویروسی است.",
    "آنتی‌بیوتیک فقط وقتی اضافه می‌شود که **پنومونی باکتریال ثانویه** مطرح باشد.",
    "⚠️ **و ممنوعیت مطلق: آسپیرین در کودک مبتلا به آنفلوانزا یا آبله‌مرغان.**",
    "علت: **سندرم ری** — انسفالوپاتی حاد به‌همراه **دژنراسیون چرب کبد**، با مرگ‌ومیر بالا.",
    "**در کودک، تب را با استامینوفن یا ایبوپروفن پایین بیاورید، هرگز با آسپیرین.**",
]
RX_EN = [
    "WARNING: ANTIVIRAL TREATMENT OF INFLUENZA IS OSELTAMIVIR — but for whom?",
    "ALL HOSPITALISED PATIENTS, SEVERE OR PROGRESSIVE DISEASE, and ALL HIGH-RISK GROUPS.",
    "IN A HEALTHY YOUNG ADULT WITH UNCOMPLICATED DISEASE, SYMPTOMATIC CARE IS ENOUGH.",
    "BEST TIME TO START: WITHIN 48 HOURS of symptom onset (the earlier the better).",
    "WARNING, but in the HOSPITALISED OR PROGRESSIVE patient it is started EVEN AFTER 48 HOURS.",
    "THE COMMONEST ADVERSE EFFECT OF OSELTAMIVIR IS NAUSEA AND VOMITING (less if taken with food).",
    "ZANAMIVIR IS INHALED and is relatively contraindicated in asthma and COPD because it causes BRONCHOSPASM.",
    "WARNING, SO IN AN ASTHMATIC PATIENT CHOOSE ORAL OSELTAMIVIR, NOT INHALED ZANAMIVIR.",
    "WARNING: AMANTADINE AND RIMANTADINE HAVE BEEN ABANDONED SINCE 2009.",
    "The reason: NEAR-UNIVERSAL RESISTANCE among circulating strains. They also HAVE NO ACTIVITY AGAINST TYPE B.",
    "ANY OPTION CONTAINING AMANTADINE OR RIMANTADINE IS WRONG, IN EVERY QUESTION.",
    "WARNING: ANTIBIOTICS HAVE NO PLACE IN UNCOMPLICATED INFLUENZA — it is a viral illness.",
    "An antibiotic is added only when SECONDARY BACTERIAL PNEUMONIA is suspected.",
    "WARNING, AND AN ABSOLUTE PROHIBITION: ASPIRIN IN A CHILD WITH INFLUENZA OR CHICKENPOX.",
    "The reason: REYE'S SYNDROME — acute encephalopathy with FATTY DEGENERATION OF THE LIVER, with high mortality.",
    "IN A CHILD, BRING THE FEVER DOWN WITH PARACETAMOL OR IBUPROFEN, NEVER WITH ASPIRIN.",
]

PNEU_FA = [
    "⚠️ **سه پنومونی پس از آنفلوانزا را با «زمان» از هم جدا کنید، نه با شدت.**",
    "**یک — پنومونی ویروسی اولیه (primary viral):**",
    "**بدون فاصله‌ی بهبودی**؛ علائم آنفلوانزا **مستقیماً و پیوسته** به دیسترس تنفسی می‌رسد.",
    "**در گرافی: انفیلتراسیون منتشر بینابینی یا رتیکولوندولر دو طرفه** — نه کنسولیداسیون لوبار.",
    "**هیپوکسمی شدید و نامتناسب با معاینه** (سمع ممکن است تقریباً طبیعی باشد).",
    "⚠️ **این شکل کشنده‌ترین است** و درمانش **اوسلتامیویر + حمایت تنفسی** است، نه آنتی‌بیوتیک.",
    "**دو — پنومونی باکتریال ثانویه (secondary bacterial):**",
    "⚠️ **الگوی دوفازی: بیمار بهبود می‌یابد، و ۴ تا ۱۴ روز بعد دوباره بدتر می‌شود.**",
    "**بازگشت تب همراه با خلط چرکی و کنسولیداسیون لوبار** در گرافی.",
    "**ارگانیسم‌ها به ترتیب: پنوموکوک، استافیلوکوک اورئوس، هموفیلوس آنفولانزا.**",
    "⚠️ **استافیلوکوک اورئوس پس از آنفلوانزا نسبت به حالت عادی بسیار شایع‌تر است**",
    "و نشانه‌ی رادیولوژیک آن **کاویته‌های جدارنازک متعدد (پنوماتوسل)** است.",
    "**سه — پنومونی مختلط ویروسی-باکتریایی:** تصویر بینابینی، شایع‌ترین شکل در عمل.",
    "⚠️ **پس قاعده‌ی تشخیصی ساده است: «فاصله‌ی بهبودی» را در شرح حال بگردید.**",
    "**بدون فاصله ← ویروسی اولیه. با فاصله و بازگشت ← باکتریال ثانویه.**",
    "**و اگر کاویته‌ی جدارنازک دیدید، پوشش ضداستافیلوکوکی (وانکومایسین) الزامی است.**",
]
PNEU_EN = [
    "WARNING: SEPARATE THE THREE POST-INFLUENZA PNEUMONIAS BY TIMING, NOT BY SEVERITY.",
    "ONE — PRIMARY VIRAL PNEUMONIA:",
    "NO INTERVAL OF IMPROVEMENT; the influenza runs STRAIGHT ON into respiratory distress.",
    "ON THE FILM: DIFFUSE BILATERAL INTERSTITIAL OR RETICULONODULAR INFILTRATES — not lobar consolidation.",
    "SEVERE HYPOXAEMIA OUT OF PROPORTION TO THE EXAMINATION (auscultation may be almost normal).",
    "WARNING, THIS IS THE DEADLIEST FORM, and its treatment is OSELTAMIVIR PLUS RESPIRATORY SUPPORT, not antibiotics.",
    "TWO — SECONDARY BACTERIAL PNEUMONIA:",
    "WARNING, A BIPHASIC PATTERN: the patient improves, then deteriorates again 4 TO 14 DAYS later.",
    "FEVER RETURNS with PURULENT SPUTUM and LOBAR CONSOLIDATION on the film.",
    "THE ORGANISMS IN ORDER: PNEUMOCOCCUS, STAPHYLOCOCCUS AUREUS, HAEMOPHILUS INFLUENZAE.",
    "WARNING: STAPHYLOCOCCUS AUREUS IS FAR COMMONER AFTER INFLUENZA THAN OTHERWISE,",
    "and its radiological signature is MULTIPLE THIN-WALLED CAVITIES (pneumatocoeles).",
    "THREE — MIXED VIRAL-BACTERIAL PNEUMONIA: an intermediate picture, the commonest in practice.",
    "WARNING, SO THE DIAGNOSTIC RULE IS SIMPLE: LOOK IN THE HISTORY FOR AN INTERVAL OF IMPROVEMENT.",
    "NO INTERVAL means PRIMARY VIRAL. AN INTERVAL THEN RELAPSE means SECONDARY BACTERIAL.",
    "AND IF YOU SEE THIN-WALLED CAVITIES, ANTI-STAPHYLOCOCCAL COVER (VANCOMYCIN) IS MANDATORY.",
]


# =========================================================== book:564
add("book:564", "case", "medium",
 "جوان سالم با آنفلوانزای بدون عارضه ← **استامینوفن، استراحت و جداسازی** — نه آنتی‌بیوتیک.",
 "A healthy young adult with uncomplicated influenza needs PARACETAMOL, REST AND ISOLATION — not an antibiotic.",
 FLU_FA + RX_FA + [
  "مرد **۲۵ ساله**، انتهای زمستان، شروع **ناگهانی** از دیروز، تب ۳۹، گلودرد، **سرفه‌ی خشک**،",
  "**درد چشم هنگام حرکت** و **تماس با برادر مبتلا** یک هفته پیش.",
  "**هر جزء این تابلو آنفلوانزاست:** فصل، شروع ناگهانی، علائم سیستمیک، درد رتروبولبار، و تماس خانوادگی.",
  "**در معاینه: حلق «مختصر اریتماتو» و بقیه‌ی معاینه نرمال** — یعنی **بدون اگزودا**.",
  "⚠️ **این بیمار در هیچ گروه پرخطری نیست:** ۲۵ ساله، بدون بیماری زمینه‌ای، غیرباردار، BMI طبیعی.",
  "**پس اوسلتامیویر الزامی نیست و درمان علامتی کافی است.**",
  "**استامینوفن + مایعات + استراحت** — و یک توصیه‌ی مهم که گزینه‌ی درست به آن اشاره دارد:",
  "⚠️ **عدم حضور در اماکن عمومی**، چون بیمار **از یک روز پیش از علائم تا ۵ تا ۷ روز بعد ویروس دفع می‌کند**.",
  "**چرا پنی‌سیلین بنزاتین نه؟** آن برای **فارنژیت استرپتوکوکی** است.",
  "و فارنژیت استرپتوکوکی **اگزودا، لنفادنوپاتی گردنی دردناک و نبودِ سرفه** دارد —",
  "دقیقاً برعکس این بیمار که **سرفه دارد و اگزودا ندارد**.",
  "**چرا سفتریاکسون و بستری نه؟** بیمار پایدار است: BP نرمال، RR=18، معاینه‌ی ریه طبیعی.",
  "**چرا آزیترومایسین نه؟** آنتی‌بیوتیک در آنفلوانزای بدون عارضه **هیچ سودی ندارد**",
  "و فقط **مقاومت، عوارض دارویی و هزینه** اضافه می‌کند.",
 ],
 FLU_EN + RX_EN + [
  "A 25-YEAR-OLD man, late winter, ABRUPT onset yesterday, fever 39, sore throat, DRY COUGH,",
  "PAIN ON EYE MOVEMENT, and CONTACT WITH AN AFFECTED BROTHER a week ago.",
  "EVERY ELEMENT IS INFLUENZA: the season, the abrupt onset, systemic symptoms, retro-orbital pain, household contact.",
  "ON EXAMINATION: the throat is 'mildly erythematous' and the rest is normal — that is, NO EXUDATE.",
  "WARNING: THIS PATIENT IS IN NO HIGH-RISK GROUP — 25 years old, no comorbidity, not pregnant, normal BMI.",
  "SO OSELTAMIVIR IS NOT MANDATORY and symptomatic care suffices.",
  "PARACETAMOL PLUS FLUIDS PLUS REST — and one important piece of advice the correct option includes:",
  "WARNING, STAYING AWAY FROM PUBLIC PLACES, because the patient SHEDS VIRUS from a day before symptoms until 5 to 7 days after.",
  "WHY NOT BENZATHINE PENICILLIN? That is for STREPTOCOCCAL PHARYNGITIS.",
  "And streptococcal pharyngitis has EXUDATE, TENDER CERVICAL NODES AND NO COUGH —",
  "the exact opposite of this patient, who HAS A COUGH AND NO EXUDATE.",
  "WHY NOT CEFTRIAXONE AND ADMISSION? The patient is stable: normal BP, RR 18, normal chest examination.",
  "WHY NOT AZITHROMYCIN? An antibiotic gives NO BENEFIT in uncomplicated influenza",
  "and only adds RESISTANCE, DRUG ADVERSE EFFECTS AND COST.",
 ],
 "مرد **۲۵ ساله**، انتهای زمستان، شروع **ناگهانی** از دیروز، تب ۳۹ درجه، گلودرد، **سرفه‌ی خشک**، **درد چشم هنگام حرکت**، و **تماس با برادر مبتلا** یک هفته پیش.\n\n"
 "**هر جزء این تابلو آنفلوانزاست:** فصل، شروع ناگهانی، غلبه‌ی علائم سیستمیک، درد رتروبولبار، و تماس خانوادگی.\n\n"
 "⚠️ **و در معاینه، حلق «مختصر اریتماتو» است — یعنی بدون اگزودا. این نکته‌ی افتراقی طلایی است.**\n\n"
 "**حالا دو سؤال بپرسید:**\n\n"
 "**۱. آیا بیمار در گروه پرخطر است؟** ۲۵ ساله، بدون بیماری زمینه‌ای، غیرباردار، بدون چاقی مرضی ← **خیر**.\n\n"
 "**۲. آیا بیماری شدید یا پیشرونده است؟** BP نرمال، RR=18، معاینه‌ی ریه طبیعی ← **خیر**.\n\n"
 "**پس اوسلتامیویر الزامی نیست و درمان علامتی کافی است:** استامینوفن، مایعات، استراحت — و ⚠️ **عدم حضور در اماکن عمومی**، چون بیمار **از یک روز پیش از علائم تا ۵ تا ۷ روز بعد ویروس دفع می‌کند**. این توصیه‌ی بهداشت عمومی، بخشی از درمان است.\n\n"
 "**چرا گزینه‌های دیگر رد می‌شوند؟**\n\n"
 "**پنی‌سیلین بنزاتین** ← داروی **فارنژیت استرپتوکوکی** است، و فارنژیت استرپی **اگزودا، لنفادنوپاتی گردنی دردناک و نبودِ سرفه** دارد. بیمار ما **سرفه دارد و اگزودا ندارد** — یعنی دقیقاً برعکس.\n\n"
 "**سفتریاکسون و بستری** ← بیمار کاملاً پایدار است؛ بستری بی‌مورد.\n\n"
 "⚠️ **آزیترومایسین** ← آنتی‌بیوتیک در آنفلوانزای بدون عارضه **هیچ سودی ندارد**؛ فقط **مقاومت میکروبی، عوارض دارویی و هزینه** اضافه می‌کند.",
 "A 25-YEAR-OLD man, late winter, ABRUPT onset yesterday, fever of 39, sore throat, DRY COUGH, PAIN ON EYE MOVEMENT, and CONTACT WITH AN AFFECTED BROTHER a week ago.\n\n"
 "EVERY ELEMENT IS INFLUENZA: the season, the abrupt onset, the dominance of systemic symptoms, retro-orbital pain, household contact.\n\n"
 "WARNING, AND ON EXAMINATION THE THROAT IS 'MILDLY ERYTHEMATOUS' — that is, WITHOUT EXUDATE. This is the golden discriminator.\n\n"
 "NOW ASK TWO QUESTIONS:\n\n"
 "1. IS THE PATIENT IN A HIGH-RISK GROUP? 25 years old, no comorbidity, not pregnant, no morbid obesity — NO.\n\n"
 "2. IS THE DISEASE SEVERE OR PROGRESSIVE? Normal BP, RR 18, normal chest examination — NO.\n\n"
 "SO OSELTAMIVIR IS NOT MANDATORY and symptomatic care suffices: paracetamol, fluids, rest — and WARNING, STAYING AWAY FROM PUBLIC PLACES, because the patient SHEDS VIRUS from a day before symptoms until 5 to 7 days after. That public health advice is part of the treatment.\n\n"
 "WHY THE OTHER OPTIONS FAIL:\n\n"
 "BENZATHINE PENICILLIN — the drug for STREPTOCOCCAL PHARYNGITIS, which has EXUDATE, TENDER CERVICAL NODES AND NO COUGH. Our patient HAS A COUGH AND NO EXUDATE — the exact opposite.\n\n"
 "CEFTRIAXONE AND ADMISSION — the patient is entirely stable; admission is unwarranted.\n\n"
 "WARNING, AZITHROMYCIN — an antibiotic gives NO BENEFIT in uncomplicated influenza; it adds only ANTIMICROBIAL RESISTANCE, DRUG ADVERSE EFFECTS AND COST.",
 ["پاسخ صحیح — آنفلوانزای بدون عارضه در جوان سالم با درمان علامتی و جداسازی اداره می‌شود.",
  "پنی‌سیلین بنزاتین برای فارنژیت استرپتوکوکی است؛ آن بیماری اگزودا دارد و سرفه ندارد.",
  "بیمار پایدار است و هیچ معیاری برای بستری و سفتریاکسون وریدی ندارد.",
  "آزیترومایسین در آنفلوانزای بدون عارضه سودی ندارد و فقط مقاومت و عارضه اضافه می‌کند."],
 ["Correct — uncomplicated influenza in a healthy young adult is managed with symptomatic care and isolation.",
  "Benzathine penicillin is for streptococcal pharyngitis, which has exudate and no cough.",
  "The patient is stable and meets no criterion for admission or intravenous ceftriaxone.",
  "Azithromycin gives no benefit in uncomplicated influenza and adds only resistance and adverse effects."],
 "آنفلوانزای بدون عارضه در فرد **کم‌خطر** ← **علامتی**. **آنتی‌بیوتیک هیچ نقشی ندارد.**",
 "Uncomplicated influenza in a low-risk person means symptomatic care. Antibiotics have no role at all.",
 [H195, IDSAF])


# =========================================================== book:571
add("book:571", "recall", "medium",
 "**اگزودای فارنکس** تنها یافته‌ای است که با آنفلوانزا نمی‌خواند.",
 "PHARYNGEAL EXUDATE is the one finding that does not fit influenza.",
 FLU_FA + [
  "این سؤال منفی است: **کدام علامت با آنفلوانزا منطبق نیست؟**",
  "پس سه یافته‌ی **سازگار** را بشناسید تا چهارمی خودش را نشان دهد.",
  "**تب ۳۹ درجه؟ کاملاً سازگار.** آنفلوانزا معمولاً تب **۳۸ تا ۴۰** می‌دهد و شروعش ناگهانی است.",
  "**سردرد فرونتال؟ سازگار.** سردرد آنفلوانزا معمولاً **فرونتال یا رتروبولبار** است،",
  "و **درد با حرکت چشم** یکی از توصیف‌های کلاسیک آن است.",
  "**میالژی در عضلات ساق؟ سازگار.** میالژی آنفلوانزا در **عضلات بزرگ** است:",
  "ساق پا، ران و کمر. در کودکان، میالژی ساق گاهی آن‌قدر شدید است که راه رفتن مختل می‌شود.",
  "⚠️ **می‌ماند اگزودای سفیدرنگ فارنکس — و این با آنفلوانزا نمی‌خواند.**",
  "**در آنفلوانزا حلق قرمز و ملتهب است ولی اگزودا ندارد.**",
  "**پس اگزودا شما را به سمت سه تشخیص دیگر می‌برد:**",
  "**فارنژیت استرپتوکوکی گروه A** ← اگزودا + لنفادنوپاتی دردناک + **نبودِ سرفه** + تب.",
  "**مونونوکلئوز عفونی (EBV)** ← اگزودا + **لنفادنوپاتی خلفی گردن** + **اسپلنومگالی** + لنفوسیت آتیپیک.",
  "**دیفتری** ← **غشای کاذب خاکستری چسبنده** که با کندن **خونریزی** می‌کند.",
  "⚠️ **معیار سنتور (Centor) را به یاد داشته باشید:** تب، **نبودِ سرفه**، اگزودای لوزه،",
  "و آدنوپاتی قدامی گردن. **وجود سرفه، احتمال استرپ را کم می‌کند** و به سمت ویروس می‌برد.",
 ],
 FLU_EN + [
  "This is a negative question: WHICH FINDING DOES NOT FIT INFLUENZA?",
  "So recognise the three findings that DO fit, and the fourth reveals itself.",
  "A FEVER OF 39? ENTIRELY CONSISTENT. Influenza usually gives a fever of 38 to 40 with abrupt onset.",
  "A FRONTAL HEADACHE? CONSISTENT. The headache of influenza is typically FRONTAL OR RETRO-ORBITAL,",
  "and PAIN ON EYE MOVEMENT is one of its classical descriptions.",
  "MYALGIA IN THE CALVES? CONSISTENT. Influenza myalgia affects the LARGE MUSCLES:",
  "calves, thighs and back. In children, calf myalgia is sometimes severe enough to impair walking.",
  "WARNING, THAT LEAVES WHITE PHARYNGEAL EXUDATE — AND THAT DOES NOT FIT INFLUENZA.",
  "IN INFLUENZA THE THROAT IS RED AND INFLAMED BUT HAS NO EXUDATE.",
  "SO EXUDATE POINTS YOU TOWARDS THREE OTHER DIAGNOSES:",
  "GROUP A STREPTOCOCCAL PHARYNGITIS — exudate plus tender nodes plus NO COUGH plus fever.",
  "INFECTIOUS MONONUCLEOSIS (EBV) — exudate plus POSTERIOR CERVICAL NODES plus SPLENOMEGALY plus atypical lymphocytes.",
  "DIPHTHERIA — an ADHERENT GREY PSEUDOMEMBRANE that BLEEDS when peeled off.",
  "WARNING, REMEMBER THE CENTOR CRITERIA: fever, ABSENCE OF COUGH, tonsillar exudate,",
  "and tender anterior cervical adenopathy. THE PRESENCE OF A COUGH ARGUES AGAINST STREP and towards a virus.",
 ],
 "این سؤال منفی است، پس راهش این است که سه یافته‌ی **سازگار با آنفلوانزا** را بشناسیم:\n\n"
 "**تب ۳۹ درجه؟** ✅ کاملاً سازگار — آنفلوانزا معمولاً تب **۳۸ تا ۴۰** با شروع ناگهانی می‌دهد.\n\n"
 "**سردرد فرونتال؟** ✅ سازگار — سردرد آنفلوانزا معمولاً **فرونتال یا رتروبولبار** است و **درد با حرکت چشم** از توصیف‌های کلاسیک آن.\n\n"
 "**میالژی در عضلات ساق؟** ✅ سازگار — میالژی آنفلوانزا در **عضلات بزرگ** (ساق، ران، کمر) است. در کودکان گاهی آن‌قدر شدید است که راه رفتن مختل می‌شود.\n\n"
 "⚠️ **می‌ماند اگزودای سفیدرنگ فارنکس — و این با آنفلوانزا نمی‌خواند.**\n\n"
 "**در آنفلوانزا حلق قرمز و ملتهب است، ولی اگزودا ندارد.** این افتراق آن‌قدر پرکاربرد است که باید مثل یک رفلکس عمل کند.\n\n"
 "**اگزودا شما را به سه تشخیص دیگر می‌برد:**\n\n"
 "**فارنژیت استرپتوکوکی گروه A** ← اگزودا + لنفادنوپاتی قدامی دردناک + **نبودِ سرفه** + تب\n\n"
 "**مونونوکلئوز عفونی (EBV)** ← اگزودا + **لنفادنوپاتی خلفی گردن** + **اسپلنومگالی** + لنفوسیت آتیپیک\n\n"
 "**دیفتری** ← **غشای کاذب خاکستری و چسبنده** که با کندن **خونریزی می‌کند**\n\n"
 "⚠️ **و ابزار عملی: معیارهای سنتور (Centor):** تب، **نبودِ سرفه**، اگزودای لوزه، و آدنوپاتی قدامی گردن. نکته‌ی ظریفش این است که **وجود سرفه احتمال استرپ را کم می‌کند** — یعنی سرفه، برخلاف انتظار، به نفع ویروس است.",
 "This is a negative question, so the way in is to recognise the three findings that DO fit influenza:\n\n"
 "A FEVER OF 39? Consistent — influenza usually gives a fever of 38 to 40 with abrupt onset.\n\n"
 "A FRONTAL HEADACHE? Consistent — the headache of influenza is typically FRONTAL OR RETRO-ORBITAL, and PAIN ON EYE MOVEMENT is one of its classical descriptions.\n\n"
 "MYALGIA IN THE CALVES? Consistent — influenza myalgia affects the LARGE MUSCLES (calves, thighs, back). In children it is sometimes severe enough to impair walking.\n\n"
 "WARNING, THAT LEAVES WHITE PHARYNGEAL EXUDATE — AND THAT DOES NOT FIT INFLUENZA.\n\n"
 "IN INFLUENZA THE THROAT IS RED AND INFLAMED BUT HAS NO EXUDATE. This discriminator is so useful that it should become a reflex.\n\n"
 "EXUDATE POINTS TO THREE OTHER DIAGNOSES:\n\n"
 "GROUP A STREPTOCOCCAL PHARYNGITIS — exudate plus tender anterior nodes plus NO COUGH plus fever\n\n"
 "INFECTIOUS MONONUCLEOSIS (EBV) — exudate plus POSTERIOR CERVICAL NODES plus SPLENOMEGALY plus atypical lymphocytes\n\n"
 "DIPHTHERIA — an ADHERENT GREY PSEUDOMEMBRANE that BLEEDS when peeled\n\n"
 "WARNING, AND A PRACTICAL TOOL — THE CENTOR CRITERIA: fever, ABSENCE OF COUGH, tonsillar exudate, and tender anterior cervical adenopathy. The subtlety is that THE PRESENCE OF A COUGH ARGUES AGAINST STREP — cough, counter-intuitively, favours a virus.",
 ["تب ۳۹ درجه کاملاً با آنفلوانزا سازگار است؛ تب معمول آن ۳۸ تا ۴۰ درجه است.",
  "سردرد فرونتال و رتروبولبار از ویژگی‌های شناخته‌شده‌ی آنفلوانزاست.",
  "پاسخ صحیح — در آنفلوانزا حلق اریتماتو است ولی اگزودا ندارد؛ اگزودا به استرپ، EBV یا دیفتری اشاره می‌کند.",
  "میالژی در عضلات بزرگ مانند ساق پا از تظاهرات کلاسیک آنفلوانزاست."],
 ["A fever of 39 is entirely consistent with influenza, whose usual fever is 38 to 40.",
  "Frontal and retro-orbital headache is a recognised feature of influenza.",
  "Correct — in influenza the throat is erythematous but without exudate; exudate suggests strep, EBV or diphtheria.",
  "Myalgia in large muscles such as the calves is a classical manifestation of influenza."],
 "**اگزودای حلق = نه آنفلوانزا.** به **استرپ گروه A، EBV یا دیفتری** فکر کنید. **سرفه به نفع ویروس است.**",
 "Pharyngeal exudate is not influenza. Think group A strep, EBV or diphtheria. A cough argues for a virus.",
 [H195])


# =========================================================== book:575
add("book:575", "recall", "medium",
 "**آنفلوانزای تیپ C** بیماری خفیف می‌سازد و گروه پرخطر نیست.",
 "INFLUENZA TYPE C causes mild illness and is not a high-risk category.",
 FLU_FA + RISK_FA + [
  "⚠️ **توجه: یکی از گزینه‌های این سؤال تصحیح شده است، و بدون آن تصحیح سؤال دو پاسخ داشت.**",
  "متن استخراج‌شده «BMI بالای ۲۴» داشت؛ صفحه‌ی ۲۱۵ در واقع **BMI بالای ۴۰** چاپ کرده است.",
  "**چرا این تفاوت حیاتی است؟** چون **BMI بالای ۲۴ فقط اضافه‌وزن است و گروه پرخطر نیست**،",
  "در حالی که **BMI برابر ۴۰ یا بیشتر یعنی چاقی مرضی، که یک گروه پرخطر شناخته‌شده است**.",
  "با عدد غلط، آن گزینه هم «کم‌خطر» می‌شد و سؤال **دو پاسخ درست** پیدا می‌کرد.",
  "**حالا سؤال را بخوانید: کدام گروه در ریسک کمتری برای عوارض و مرگ است؟**",
  "**بالای ۶۰ سال؟** پرخطر — سن یکی از قوی‌ترین عوامل خطر است.",
  "**فشار خون بالای ریوی؟** پرخطر — بیماری مزمن قلبی-ریوی.",
  "**چاقی مرضی با BMI بالای ۴۰؟** پرخطر — این گروه پس از پاندمی ۲۰۰۹ به فهرست افزوده شد.",
  "⚠️ **می‌ماند «بیماران مبتلا به آنفلوانزای C» — و پاسخ همین است.**",
  "**سه تیپ ویروس آنفلوانزا را از هم جدا کنید:**",
  "**تیپ A** ← شدیدترین؛ تنها تیپی که **پاندمی** می‌سازد؛ مخزن حیوانی (پرندگان، خوک) دارد.",
  "**تیپ B** ← اپیدمی فصلی، به‌ویژه در کودکان؛ فقط مخزن انسانی.",
  "⚠️ **تیپ C** ← بیماری **خفیف و شبه‌سرماخوردگی**، معمولاً در کودکان؛",
  "**نه اپیدمی می‌سازد، نه با مرگ‌ومیر قابل توجه همراه است، و در واکسن فصلی هم گنجانده نمی‌شود.**",
  "**چرا فقط A پاندمی می‌سازد؟** چون **antigenic shift** — بازآرایی قطعات ژنومی بین سویه‌های",
  "انسانی و حیوانی — تنها در تیپ A رخ می‌دهد و ویروسی می‌سازد که جمعیت هیچ ایمنی‌ای به آن ندارد.",
 ],
 FLU_EN + RISK_EN + [
  "WARNING, NOTE: ONE OPTION IN THIS QUESTION HAS BEEN CORRECTED, and without that correction it had two answers.",
  "The extracted text read 'BMI above 24'; page 215 actually prints BMI ABOVE 40.",
  "WHY IS THAT DIFFERENCE VITAL? Because A BMI ABOVE 24 IS MERE OVERWEIGHT AND NOT A RISK GROUP,",
  "whereas A BMI OF 40 OR MORE IS MORBID OBESITY, WHICH IS A RECOGNISED RISK GROUP.",
  "With the wrong figure that option too became 'lower risk', and the question had TWO correct answers.",
  "NOW READ THE QUESTION: WHICH GROUP IS AT LOWER RISK OF COMPLICATIONS AND DEATH?",
  "OVER 60 YEARS? HIGH RISK — age is one of the strongest risk factors.",
  "PULMONARY HYPERTENSION? HIGH RISK — chronic cardiopulmonary disease.",
  "MORBID OBESITY WITH BMI ABOVE 40? HIGH RISK — added to the list after the 2009 pandemic.",
  "WARNING, THAT LEAVES 'PATIENTS WITH INFLUENZA C' — and that is the answer.",
  "SEPARATE THE THREE TYPES OF INFLUENZA VIRUS:",
  "TYPE A — the most severe; the only type that causes PANDEMICS; it has an animal reservoir (birds, pigs).",
  "TYPE B — seasonal epidemics, especially in children; a human reservoir only.",
  "WARNING, TYPE C — a MILD, COLD-LIKE illness, usually in children;",
  "IT CAUSES NEITHER EPIDEMICS NOR SIGNIFICANT MORTALITY, and it is not included in the seasonal vaccine.",
  "WHY DOES ONLY A CAUSE PANDEMICS? Because ANTIGENIC SHIFT — reassortment of genome segments between",
  "human and animal strains — occurs only in type A, producing a virus to which the population has no immunity.",
 ],
 "⚠️ **پیش از هر چیز: گزینه‌ی چهارم این سؤال تصحیح شده است، و بدون آن تصحیح، سؤال دو پاسخ داشت.**\n\n"
 "متن استخراج‌شده «BMI بالای ۲۴» داشت، ولی صفحه‌ی ۲۱۵ در واقع **«BMI بالای ۴۰»** چاپ کرده است. **چرا این تفاوت حیاتی است؟** چون **BMI بالای ۲۴ فقط «اضافه‌وزن» است و اصلاً گروه پرخطر محسوب نمی‌شود**، در حالی که **BMI برابر ۴۰ یا بیشتر یعنی چاقی مرضی**، که یک گروه پرخطر شناخته‌شده است. با عدد غلط، آن گزینه هم «کم‌خطر» می‌شد و سؤال **دو پاسخ درست** پیدا می‌کرد.\n\n"
 "**حالا سؤال را حل کنیم: کدام گروه ریسک کمتری دارد؟**\n\n"
 "**بالای ۶۰ سال** ← پرخطر (سن یکی از قوی‌ترین عوامل خطر)\n"
 "**فشار خون بالای ریوی** ← پرخطر (بیماری مزمن قلبی-ریوی)\n"
 "**چاقی مرضی با BMI>40** ← پرخطر (پس از پاندمی ۲۰۰۹ به فهرست افزوده شد)\n\n"
 "⚠️ **می‌ماند «آنفلوانزای تیپ C» — و پاسخ همین است.**\n\n"
 "**سه تیپ ویروس آنفلوانزا را دقیق از هم جدا کنید:**\n\n"
 "**تیپ A** ← شدیدترین بیماری؛ **تنها تیپی که پاندمی می‌سازد**؛ مخزن حیوانی دارد (پرندگان، خوک)\n\n"
 "**تیپ B** ← اپیدمی فصلی، به‌ویژه در کودکان؛ فقط مخزن انسانی؛ شدت متوسط\n\n"
 "⚠️ **تیپ C** ← بیماری **خفیف و شبه‌سرماخوردگی**، معمولاً در کودکان؛ **نه اپیدمی می‌سازد، نه مرگ‌ومیر قابل توجهی دارد**، و حتی در واکسن فصلی هم گنجانده نمی‌شود.\n\n"
 "**و چرا فقط تیپ A پاندمی می‌سازد؟** چون **antigenic shift** — یعنی **بازآرایی قطعات ژنومی** بین سویه‌های انسانی و حیوانی — **تنها در تیپ A** رخ می‌دهد و ویروسی می‌سازد که جمعیت انسانی هیچ ایمنی قبلی به آن ندارد. در مقابل، **antigenic drift** (جهش‌های نقطه‌ای تدریجی) در A و B هر دو رخ می‌دهد و علت **اپیدمی سالانه و نیاز به واکسن هرساله** است.",
 "WARNING, FIRST: THE FOURTH OPTION OF THIS QUESTION HAS BEEN CORRECTED, and without that correction the question had two answers.\n\n"
 "The extracted text read 'BMI above 24', but page 215 actually prints 'BMI ABOVE 40'. WHY IS THAT VITAL? Because A BMI ABOVE 24 IS MERELY OVERWEIGHT and not a risk group at all, whereas A BMI OF 40 OR MORE IS MORBID OBESITY, a recognised risk group. With the wrong figure that option too became 'lower risk', giving the question TWO correct answers.\n\n"
 "NOW SOLVE IT: WHICH GROUP IS AT LOWER RISK?\n\n"
 "OVER 60 — HIGH RISK (age is among the strongest risk factors)\n"
 "PULMONARY HYPERTENSION — HIGH RISK (chronic cardiopulmonary disease)\n"
 "MORBID OBESITY WITH BMI OVER 40 — HIGH RISK (added to the list after the 2009 pandemic)\n\n"
 "WARNING, THAT LEAVES 'INFLUENZA TYPE C' — and that is the answer.\n\n"
 "SEPARATE THE THREE TYPES PRECISELY:\n\n"
 "TYPE A — the most severe; THE ONLY TYPE THAT CAUSES PANDEMICS; it has an animal reservoir (birds, pigs)\n\n"
 "TYPE B — seasonal epidemics, especially in children; a human reservoir only; moderate severity\n\n"
 "WARNING, TYPE C — a MILD, COLD-LIKE illness, usually in children; IT CAUSES NEITHER EPIDEMICS NOR SIGNIFICANT MORTALITY, and it is not even included in the seasonal vaccine.\n\n"
 "AND WHY DOES ONLY TYPE A CAUSE PANDEMICS? Because ANTIGENIC SHIFT — REASSORTMENT OF GENOME SEGMENTS between human and animal strains — OCCURS ONLY IN TYPE A, producing a virus to which the human population has no prior immunity. By contrast ANTIGENIC DRIFT (gradual point mutation) occurs in both A and B and is the reason for ANNUAL EPIDEMICS AND A YEARLY VACCINE.",
 ["پاسخ صحیح — آنفلوانزای تیپ C بیماری خفیف و شبه‌سرماخوردگی می‌دهد و اپیدمی و مرگ‌ومیر نمی‌سازد.",
  "سن بالای ۶۰ سال یکی از قوی‌ترین عوامل خطر عوارض و مرگ ناشی از آنفلوانزاست.",
  "فشار خون بالای ریوی یک بیماری مزمن قلبی-ریوی و گروه پرخطر شناخته‌شده است.",
  "چاقی مرضی با BMI برابر ۴۰ یا بیشتر پس از پاندمی ۲۰۰۹ به فهرست گروه‌های پرخطر افزوده شد."],
 ["Correct — influenza type C causes a mild, cold-like illness and produces neither epidemics nor deaths.",
  "Age over 60 is one of the strongest risk factors for influenza complications and death.",
  "Pulmonary hypertension is a chronic cardiopulmonary disease and a recognised high-risk group.",
  "Morbid obesity with a BMI of 40 or more was added to the high-risk list after the 2009 pandemic."],
 "**A پاندمی می‌سازد، B اپیدمی فصلی، C خفیف.** **شیفت فقط در A** ← پاندمی؛ **دریفت** ← اپیدمی سالانه.",
 "A causes pandemics, B seasonal epidemics, C mild illness. Shift occurs only in A and causes pandemics; drift causes annual epidemics.",
 [H195, ACIP])


# =========================================================== book:579
add("book:579", "case", "hard",
 "**بدون فاصله‌ی بهبودی** + هیپوکسمی شدید + انفیلتراسیون منتشر ← **پنومونی ویروسی اولیه**.",
 "NO INTERVAL OF IMPROVEMENT plus severe hypoxaemia plus diffuse infiltrates means PRIMARY VIRAL PNEUMONIA.",
 FLU_FA + PNEU_FA + [
  "بیمار **۲۵ ساله**: از **شب گذشته** به‌طور ناگهانی تب، سردرد و میالژی، و **همین حالا** دیسپنه.",
  "⚠️ **کلمه‌ی کلیدی همان چیزی است که در صورت سؤال نیست: هیچ فاصله‌ی بهبودی وجود ندارد.**",
  "بیماری از آنفلوانزا **مستقیماً و بدون وقفه** به نارسایی تنفسی رسیده است.",
  "**علائم حیاتی و یافته‌ها:** RR=35، T=39، و **اشباع اکسیژن ۷۵ درصد**.",
  "⚠️ **و مهم‌ترین یافته‌ی معاینه: «سمع ریه‌ها طبیعی است».**",
  "**هیپوکسمی شدید با سمع تقریباً طبیعی — همین ناهماهنگی، امضای درگیری بینابینی است.**",
  "چرا؟ چون فرآیند در **اینترستیسیوم** است نه در فضای آلوئولی پر از ترشح؛",
  "پس **تبادل گاز مختل می‌شود بدون آنکه صدای کراکل بلندی تولید شود**.",
  "**و گرافی: انفیلتراسیون منتشر رتیکولوندولر** — نه کنسولیداسیون لوبار.",
  "**همه‌ی این‌ها یعنی پنومونی ویروسی اولیه‌ی آنفلوانزا.**",
  "⚠️ **چرا پنومونی باکتریال ثانویه نیست؟** چون آن **الگوی دوفازی** دارد:",
  "بیمار بهبود می‌یابد، **۴ تا ۱۴ روز** بعد دوباره تب می‌کند، **خلط چرکی** پیدا می‌کند",
  "و در گرافی **کنسولیداسیون لوبار** دارد. هیچ‌کدام اینجا نیست.",
  "**چرا مختلط نیست؟** آن هم نیازمند شواهد باکتریال (خلط چرکی، کنسولیداسیون) است.",
  "**چرا تراکئوبرونشیت نیست؟** آن **هیپوکسمی ۷۵ درصدی و انفیلتراسیون منتشر** نمی‌سازد.",
  "⚠️ **درمان: اوسلتامیویر فوری + حمایت تنفسی.** این شکل **کشنده‌ترین** عارضه‌ی آنفلوانزاست.",
 ],
 FLU_EN + PNEU_EN + [
  "A 25-YEAR-OLD patient: SINCE LAST NIGHT, abrupt fever, headache and myalgia, and dyspnoea NOW.",
  "WARNING, THE KEY WORD IS THE ONE THAT IS ABSENT FROM THE STEM: THERE IS NO INTERVAL OF IMPROVEMENT.",
  "The illness has run STRAIGHT ON from influenza into respiratory failure.",
  "VITAL SIGNS AND FINDINGS: RR 35, T 39, and OXYGEN SATURATION 75 PER CENT.",
  "WARNING, AND THE MOST IMPORTANT EXAMINATION FINDING: 'THE LUNGS SOUND NORMAL'.",
  "SEVERE HYPOXAEMIA WITH ALMOST NORMAL AUSCULTATION — that mismatch is the signature of interstitial disease.",
  "Why? Because the process is in the INTERSTITIUM, not in alveoli filled with secretions;",
  "so GAS EXCHANGE FAILS WITHOUT GENERATING LOUD CRACKLES.",
  "AND THE FILM: DIFFUSE RETICULONODULAR INFILTRATES — not lobar consolidation.",
  "ALL OF THIS MEANS PRIMARY INFLUENZA VIRAL PNEUMONIA.",
  "WARNING, WHY NOT SECONDARY BACTERIAL PNEUMONIA? Because that has a BIPHASIC PATTERN:",
  "the patient improves, then 4 TO 14 DAYS later becomes febrile again with PURULENT SPUTUM",
  "and LOBAR CONSOLIDATION on the film. None of that is here.",
  "WHY NOT MIXED? That too requires bacterial evidence (purulent sputum, consolidation).",
  "WHY NOT TRACHEOBRONCHITIS? That does not produce a saturation of 75% and diffuse infiltrates.",
  "WARNING, TREATMENT: IMMEDIATE OSELTAMIVIR PLUS RESPIRATORY SUPPORT. This is the DEADLIEST complication of influenza.",
 ],
 "بیمار **۲۵ ساله**: از **شب گذشته** به‌طور ناگهانی تب، سردرد و میالژی، و **همین حالا** دیسپنه و سرفه‌ی خشک.\n\n"
 "⚠️ **کلید این سؤال چیزی است که در صورت سؤال نیست: هیچ فاصله‌ی بهبودی وجود ندارد.** بیماری از آنفلوانزا **مستقیماً و بدون وقفه** به نارسایی تنفسی رسیده است.\n\n"
 "**حالا یافته‌ها را کنار هم بگذارید:**\n\n"
 "RR=35، T=39 درجه، و **اشباع اکسیژن ۷۵ درصد**\n"
 "⚠️ **و مهم‌ترین یافته‌ی معاینه: «سمع ریه‌ها طبیعی است»**\n"
 "گرافی: **انفیلتراسیون منتشر رتیکولوندولر**\n\n"
 "**همین ناهماهنگیِ «هیپوکسمی شدید با سمع تقریباً طبیعی» امضای درگیری بینابینی است.** دلیلش را بفهمید: فرآیند در **اینترستیسیوم** است، نه در فضای آلوئولی پر از ترشح چرکی. پس **تبادل گاز به‌شدت مختل می‌شود بدون آنکه کراکل بلندی تولید شود**.\n\n"
 "**پس تشخیص: پنومونی ویروسی اولیه‌ی آنفلوانزا.**\n\n"
 "⚠️ **حالا سه عارضه‌ی ریوی آنفلوانزا را با «زمان» از هم جدا کنید — این جدول کل بلوک را حل می‌کند:**\n\n"
 "**۱. ویروسی اولیه** ← **بدون فاصله‌ی بهبودی**؛ انفیلتراسیون **منتشر بینابینی**؛ هیپوکسمی شدید نامتناسب با سمع؛ **کشنده‌ترین**؛ درمان: **اوسلتامیویر + حمایت تنفسی**\n\n"
 "**۲. باکتریال ثانویه** ← **الگوی دوفازی**: بهبود، سپس بدتر شدن **۴ تا ۱۴ روز** بعد؛ **خلط چرکی**؛ **کنسولیداسیون لوبار**؛ درمان: **آنتی‌بیوتیک**\n\n"
 "**۳. مختلط** ← تصویر بینابینی بین این دو؛ شایع‌ترین در عمل\n\n"
 "**چرا گزینه‌های دیگر رد می‌شوند؟** هیچ‌کدام از نشانه‌های باکتریال (فاصله‌ی بهبودی، خلط چرکی، کنسولیداسیون) اینجا نیست، و **تراکئوبرونشیت ویروسی** هرگز اشباع ۷۵ درصد و انفیلتراسیون منتشر نمی‌سازد.",
 "A 25-YEAR-OLD patient: SINCE LAST NIGHT, abrupt fever, headache and myalgia, and NOW dyspnoea and a dry cough.\n\n"
 "WARNING, THE KEY TO THIS QUESTION IS WHAT IS ABSENT FROM THE STEM: THERE IS NO INTERVAL OF IMPROVEMENT. The illness has run STRAIGHT ON from influenza into respiratory failure.\n\n"
 "NOW PUT THE FINDINGS TOGETHER:\n\n"
 "RR 35, T 39, and OXYGEN SATURATION 75 PER CENT\n"
 "WARNING, AND THE MOST IMPORTANT EXAMINATION FINDING: 'THE LUNGS SOUND NORMAL'\n"
 "Film: DIFFUSE RETICULONODULAR INFILTRATES\n\n"
 "THAT MISMATCH — SEVERE HYPOXAEMIA WITH ALMOST NORMAL AUSCULTATION — IS THE SIGNATURE OF INTERSTITIAL DISEASE. Understand why: the process is in the INTERSTITIUM, not in alveoli filled with purulent secretion. So GAS EXCHANGE FAILS SEVERELY WITHOUT PRODUCING LOUD CRACKLES.\n\n"
 "SO THE DIAGNOSIS IS PRIMARY INFLUENZA VIRAL PNEUMONIA.\n\n"
 "WARNING, NOW SEPARATE THE THREE PULMONARY COMPLICATIONS OF INFLUENZA BY TIMING — this table solves the whole block:\n\n"
 "1. PRIMARY VIRAL — NO INTERVAL OF IMPROVEMENT; DIFFUSE INTERSTITIAL infiltrates; severe hypoxaemia out of proportion to auscultation; THE DEADLIEST; treatment: OSELTAMIVIR PLUS RESPIRATORY SUPPORT\n\n"
 "2. SECONDARY BACTERIAL — A BIPHASIC PATTERN: improvement, then deterioration 4 TO 14 DAYS later; PURULENT SPUTUM; LOBAR CONSOLIDATION; treatment: ANTIBIOTICS\n\n"
 "3. MIXED — a picture intermediate between the two; the commonest in practice\n\n"
 "WHY THE OTHER OPTIONS FAIL? None of the bacterial markers (an interval of improvement, purulent sputum, consolidation) is present, and VIRAL TRACHEOBRONCHITIS never produces a saturation of 75% with diffuse infiltrates.",
 ["پاسخ صحیح — بدون فاصله‌ی بهبودی، با انفیلتراسیون منتشر و هیپوکسمی شدید نامتناسب با سمع: پنومونی ویروسی اولیه.",
  "پنومونی باکتریال ثانویه الگوی دوفازی، خلط چرکی و کنسولیداسیون لوبار دارد که هیچ‌کدام اینجا نیست.",
  "پنومونی مختلط هم نیازمند شواهد باکتریال است؛ اینجا تصویر کاملاً بینابینی و ویروسی است.",
  "تراکئوبرونشیت ویروسی اشباع اکسیژن ۷۵ درصد و انفیلتراسیون منتشر ایجاد نمی‌کند."],
 ["Correct — no interval of improvement, diffuse infiltrates and hypoxaemia out of proportion to auscultation: primary viral pneumonia.",
  "Secondary bacterial pneumonia has a biphasic pattern, purulent sputum and lobar consolidation, none of which is present.",
  "Mixed pneumonia also requires bacterial evidence; here the picture is purely interstitial and viral.",
  "Viral tracheobronchitis does not produce an oxygen saturation of 75% with diffuse infiltrates."],
 "**بدون فاصله ← ویروسی اولیه (منتشر، هیپوکسمی شدید).** **با فاصله و بازگشت ← باکتریال ثانویه (لوبار، خلط چرکی).**",
 "No interval means primary viral (diffuse, severe hypoxaemia). An interval then relapse means secondary bacterial (lobar, purulent sputum).",
 [H195, IDSAF])


# =========================================================== book:581
add("book:581", "case", "hard",
 "**کاویته‌ی جدارنازک** پس از آنفلوانزا ← **استافیلوکوک اورئوس** ← **وانکومایسین + سفتریاکسون**.",
 "A THIN-WALLED CAVITY after influenza means STAPHYLOCOCCUS AUREUS: give VANCOMYCIN PLUS CEFTRIAXONE.",
 FLU_FA + PNEU_FA + [
  "بیمار **۳۰ ساله** با تب ۳۹، **PCR آنفلوانزای مثبت**، و در گرافی **کاویته با دیواره‌ی نازک در محیط ریه**.",
  "⚠️ **کاویته‌ی جدارنازک پس از آنفلوانزا یک نشانه‌ی تقریباً اختصاصی است: استافیلوکوک اورئوس.**",
  "**چرا آنفلوانزا زمینه‌ساز عفونت استافیلوکوکی می‌شود؟ سه مکانیسم:**",
  "**یک — تخریب اپیتلیوم مژه‌دار تنفسی**، که سد اصلی پاکسازی مکانیکی است.",
  "**دو — برهنه شدن گیرنده‌های چسبندگی** روی سلول‌های آسیب‌دیده، که باکتری به آن‌ها می‌چسبد.",
  "**سه — اختلال عملکرد نوتروفیل و ماکروفاژ آلوئولی** در جریان عفونت ویروسی.",
  "**چرا کاویته می‌سازد؟** چون استافیلوکوک اورئوس **توکسین‌های نکروزکننده** تولید می‌کند",
  "(از جمله **لکوسیدین پنتون-والنتاین**) که بافت ریه را ذوب می‌کنند و **پنوماتوسل** می‌سازند.",
  "⚠️ **پس درمان باید حتماً پوشش ضداستافیلوکوکی داشته باشد، و در ایران فرض بر MRSA است.**",
  "**وانکومایسین** (یا لینزولید) پوشش MRSA را می‌دهد،",
  "و **سفتریاکسون** پنوموکوک و سایر عوامل شایع پنومونی پس از آنفلوانزا را.",
  "**پس ترکیب وانکومایسین + سفتریاکسون هر دو نیاز را پوشش می‌دهد.**",
  "⚠️ **چرا گزینه‌های دیگر ناکافی‌اند؟ همه‌شان یک مشکل مشترک دارند: پوشش MRSA ندارند.**",
  "**مروپنم** کارباپنم وسیعی است ولی **روی MRSA بی‌اثر است**.",
  "**کلیندامایسین** روی برخی سویه‌های MRSA اکتسابی از جامعه مؤثر است ولی **قابل اتکا نیست**.",
  "**و در کاویته‌ی نکروزان، هیچ‌کس روی «شاید مؤثر باشد» شرط نمی‌بندد.**",
 ],
 FLU_EN + PNEU_EN + [
  "A 30-YEAR-OLD with fever of 39, a POSITIVE INFLUENZA PCR, and A THIN-WALLED PERIPHERAL CAVITY on the film.",
  "WARNING: A THIN-WALLED CAVITY AFTER INFLUENZA IS ALMOST SPECIFIC: STAPHYLOCOCCUS AUREUS.",
  "WHY DOES INFLUENZA PREDISPOSE TO STAPHYLOCOCCAL INFECTION? Three mechanisms:",
  "ONE — DESTRUCTION OF THE CILIATED RESPIRATORY EPITHELIUM, the main barrier of mechanical clearance.",
  "TWO — EXPOSURE OF ADHESION RECEPTORS on damaged cells, to which the bacterium binds.",
  "THREE — IMPAIRED NEUTROPHIL AND ALVEOLAR MACROPHAGE FUNCTION during the viral infection.",
  "WHY DOES IT CAVITATE? Because Staphylococcus aureus produces NECROTISING TOXINS",
  "(including PANTON-VALENTINE LEUKOCIDIN) that melt lung tissue and create PNEUMATOCOELES.",
  "WARNING, SO TREATMENT MUST INCLUDE ANTI-STAPHYLOCOCCAL COVER, and in Iran MRSA is assumed.",
  "VANCOMYCIN (or linezolid) provides the MRSA cover,",
  "and CEFTRIAXONE covers the pneumococcus and the other common post-influenza pathogens.",
  "SO VANCOMYCIN PLUS CEFTRIAXONE meets both needs.",
  "WARNING, WHY ARE THE OTHERS INADEQUATE? They share one flaw: NO MRSA COVER.",
  "MEROPENEM is a broad carbapenem but IS INACTIVE AGAINST MRSA.",
  "CLINDAMYCIN works against some community-acquired MRSA strains but IS NOT RELIABLE.",
  "AND IN A NECROTISING CAVITY NOBODY BETS ON 'MIGHT WORK'.",
 ],
 "بیمار **۳۰ ساله** با تب ۳۹ درجه، شروع حاد با **میالژی شدید عضلات کمر و ساق**، **PCR آنفلوانزای مثبت**، و در گرافی **کاویته با دیواره‌ی نازک در محیط ریه**.\n\n"
 "⚠️ **«کاویته‌ی جدارنازک پس از آنفلوانزا» یک نشانه‌ی تقریباً اختصاصی است: استافیلوکوک اورئوس.**\n\n"
 "**چرا آنفلوانزا زمینه‌ساز عفونت استافیلوکوکی می‌شود؟ سه مکانیسم را بدانید:**\n\n"
 "**۱. تخریب اپیتلیوم مژه‌دار تنفسی** — سد اصلی پاکسازی مکانیکی از بین می‌رود.\n"
 "**۲. برهنه شدن گیرنده‌های چسبندگی** روی سلول‌های آسیب‌دیده که باکتری به آن‌ها می‌چسبد.\n"
 "**۳. اختلال عملکرد نوتروفیل و ماکروفاژ آلوئولی** در جریان عفونت ویروسی.\n\n"
 "**و چرا کاویته می‌سازد؟** چون استافیلوکوک اورئوس **توکسین‌های نکروزکننده** تولید می‌کند — از جمله **لکوسیدین پنتون-والنتاین** — که بافت ریه را ذوب می‌کنند و **پنوماتوسل (کاویته‌ی جدارنازک)** می‌سازند.\n\n"
 "⚠️ **پس درمان باید حتماً پوشش ضداستافیلوکوکی داشته باشد، و در پنومونی نکروزان فرض بر MRSA است.**\n\n"
 "**رژیم درست: وانکومایسین + سفتریاکسون**\n\n"
 "**وانکومایسین** (یا لینزولید) ← پوشش **MRSA**\n"
 "**سفتریاکسون** ← پوشش **پنوموکوک** و سایر عوامل شایع پنومونی پس از آنفلوانزا\n\n"
 "⚠️ **و حالا نکته‌ی مشترک همه‌ی گزینه‌های غلط: هیچ‌کدام پوشش MRSA ندارند.**\n\n"
 "**مروپنم** ← کارباپنم بسیار وسیعی است، ولی **روی MRSA کاملاً بی‌اثر** است. وسعت طیف با پوشش MRSA یکی نیست — این یکی از شایع‌ترین سوءتفاهم‌های دانشجویی است.\n\n"
 "**کلیندامایسین** ← روی برخی سویه‌های MRSA اکتسابی از جامعه مؤثر است، ولی **قابل اتکا نیست** و در پنومونی نکروزان نمی‌توان روی «شاید» شرط بست.",
 "A 30-YEAR-OLD with a fever of 39, acute onset with SEVERE MYALGIA OF THE BACK AND CALVES, a POSITIVE INFLUENZA PCR, and A THIN-WALLED PERIPHERAL CAVITY on the film.\n\n"
 "WARNING: 'A THIN-WALLED CAVITY AFTER INFLUENZA' IS ALMOST SPECIFIC: STAPHYLOCOCCUS AUREUS.\n\n"
 "WHY DOES INFLUENZA PREDISPOSE TO STAPHYLOCOCCAL INFECTION? Know the three mechanisms:\n\n"
 "1. DESTRUCTION OF THE CILIATED RESPIRATORY EPITHELIUM — the main barrier of mechanical clearance is lost.\n"
 "2. EXPOSURE OF ADHESION RECEPTORS on damaged cells, to which the bacterium binds.\n"
 "3. IMPAIRED NEUTROPHIL AND ALVEOLAR MACROPHAGE FUNCTION during the viral infection.\n\n"
 "AND WHY DOES IT CAVITATE? Because Staphylococcus aureus produces NECROTISING TOXINS — including PANTON-VALENTINE LEUKOCIDIN — that melt lung tissue and create PNEUMATOCOELES (thin-walled cavities).\n\n"
 "WARNING, SO TREATMENT MUST INCLUDE ANTI-STAPHYLOCOCCAL COVER, and in necrotising pneumonia MRSA is assumed.\n\n"
 "THE CORRECT REGIMEN: VANCOMYCIN PLUS CEFTRIAXONE\n\n"
 "VANCOMYCIN (or linezolid) — MRSA cover\n"
 "CEFTRIAXONE — cover for the pneumococcus and other common post-influenza pathogens\n\n"
 "WARNING, AND NOW THE FLAW SHARED BY EVERY WRONG OPTION: NONE OF THEM COVERS MRSA.\n\n"
 "MEROPENEM — a very broad carbapenem, but COMPLETELY INACTIVE AGAINST MRSA. Breadth of spectrum is not the same as MRSA cover — one of the commonest student misconceptions.\n\n"
 "CLINDAMYCIN — active against some community-acquired MRSA strains, but NOT RELIABLE, and in necrotising pneumonia one cannot bet on 'maybe'.",
 ["مروپنم و کوتریموکسازول پوشش قابل اتکای MRSA در پنومونی نکروزان فراهم نمی‌کنند.",
  "کلیندامایسین روی برخی سویه‌های MRSA جامعه مؤثر است ولی قابل اتکا نیست و پوشش پنوموکوک کافی هم ندارد.",
  "مروپنم با وجود طیف بسیار وسیع، روی MRSA کاملاً بی‌اثر است؛ وسعت طیف با پوشش MRSA یکی نیست.",
  "پاسخ صحیح — کاویته‌ی جدارنازک پس از آنفلوانزا یعنی استاف اورئوس؛ وانکومایسین پوشش MRSA و سفتریاکسون پوشش پنوموکوک می‌دهد."],
 ["Meropenem plus co-trimoxazole does not provide reliable MRSA cover in necrotising pneumonia.",
  "Clindamycin works against some community MRSA strains but is unreliable and gives inadequate pneumococcal cover.",
  "Meropenem, despite its very broad spectrum, is completely inactive against MRSA; breadth is not MRSA cover.",
  "Correct — a thin-walled cavity after influenza means Staph aureus; vancomycin covers MRSA and ceftriaxone the pneumococcus."],
 "**کاویته‌ی جدارنازک پس از آنفلوانزا = استاف اورئوس** ← **پوشش MRSA الزامی**. مروپنم MRSA را **نمی‌گیرد**.",
 "A thin-walled cavity after influenza means Staph aureus, so MRSA cover is mandatory. Meropenem does not cover MRSA.",
 [H195, IDSAF])


# =========================================================== book:585
add("book:585", "case", "medium",
 "خانم باردار در تماس با فرزند مبتلا ← **واکسن غیرفعال + اوسلتامیویر**.",
 "A pregnant woman exposed to her infected child needs THE INACTIVATED VACCINE PLUS OSELTAMIVIR.",
 FLU_FA + RISK_FA + RX_FA + [
  "این سؤال دو تصمیم را هم‌زمان می‌سنجد: **کدام واکسن** و **کدام دارو**.",
  "⚠️ **بارداری در هر سه‌ماهه یک گروه پرخطر است** — و از پرخطرترین‌ها.",
  "**چرا؟** در بارداری **حجم جاری تنفسی محدود می‌شود** (بالا آمدن دیافراگم)،",
  "**بار قلبی افزایش می‌یابد**، و **ایمنی سلولی به‌طور فیزیولوژیک تعدیل می‌شود**.",
  "**نتیجه: خطر بستری، ICU و مرگ در زن باردار مبتلا به آنفلوانزا چند برابر است.**",
  "**تصمیم اول — کدام واکسن؟ حتماً واکسن غیرفعال (تزریقی).**",
  "⚠️ **واکسن اینترانازال (LAIV) ویروس زنده‌ی ضعیف‌شده است و در بارداری ممنوع است.**",
  "همچنین در **نقص ایمنی**، **کودکان زیر ۲ سال** و **افراد بالای ۵۰ سال** استفاده نمی‌شود.",
  "**تصمیم دوم — کدام دارو؟ اوسلتامیویر، برای پروفیلاکسی پس از تماس.**",
  "⚠️ **آمانتادین از ۲۰۰۹ کنار گذاشته شده** (مقاومت تقریباً کامل و بی‌اثری روی تیپ B).",
  "**پس هر گزینه‌ای که آمانتادین داشته باشد، بدون نیاز به فکر بیشتر، غلط است.**",
  "**نکته‌ی مهم: واکسن و دارو مکمل‌اند، نه جایگزین یکدیگر.**",
  "واکسن **۲ هفته** طول می‌کشد تا ایمنی بسازد؛ اوسلتامیویر **همین حالا** محافظت می‌دهد.",
  "⚠️ **و یک سود مضاعف واکسن در بارداری: آنتی‌بادی از جفت عبور می‌کند**",
  "و **نوزاد را در ۶ ماه اول زندگی محافظت می‌کند** — دقیقاً وقتی که خودش نمی‌تواند واکسینه شود.",
 ],
 FLU_EN + RISK_EN + RX_EN + [
  "This question tests two decisions at once: WHICH VACCINE and WHICH DRUG.",
  "WARNING: PREGNANCY IN ANY TRIMESTER IS A HIGH-RISK GROUP — and among the highest.",
  "WHY? In pregnancy TIDAL VOLUME IS RESTRICTED (the diaphragm rides high),",
  "CARDIAC LOAD RISES, and CELLULAR IMMUNITY IS PHYSIOLOGICALLY MODULATED.",
  "THE RESULT: the risk of admission, ICU care and death is several times higher in a pregnant woman.",
  "DECISION ONE — WHICH VACCINE? THE INACTIVATED (INJECTED) VACCINE, without question.",
  "WARNING: THE INTRANASAL VACCINE (LAIV) IS A LIVE ATTENUATED VIRUS AND IS CONTRAINDICATED IN PREGNANCY.",
  "It is likewise avoided in IMMUNODEFICIENCY, CHILDREN UNDER 2 and ADULTS OVER 50.",
  "DECISION TWO — WHICH DRUG? OSELTAMIVIR, as post-exposure prophylaxis.",
  "WARNING: AMANTADINE WAS ABANDONED IN 2009 (near-complete resistance, and no activity against type B).",
  "SO ANY OPTION CONTAINING AMANTADINE IS WRONG WITHOUT FURTHER THOUGHT.",
  "AN IMPORTANT POINT: THE VACCINE AND THE DRUG ARE COMPLEMENTARY, NOT ALTERNATIVES.",
  "The vaccine takes TWO WEEKS to build immunity; oseltamivir protects RIGHT NOW.",
  "WARNING, AND A DOUBLE BENEFIT OF VACCINATION IN PREGNANCY: ANTIBODY CROSSES THE PLACENTA",
  "and PROTECTS THE INFANT IN ITS FIRST SIX MONTHS — exactly when it cannot be vaccinated itself.",
 ],
 "این سؤال **دو تصمیم را هم‌زمان** می‌سنجد: کدام **واکسن** و کدام **دارو**.\n\n"
 "⚠️ **اول بدانید چرا این زن پرخطر است: بارداری در هر سه‌ماهه یک گروه پرخطر است — و از پرخطرترین‌ها.**\n\n"
 "**دلیل فیزیولوژیک:** در بارداری **حجم جاری تنفسی محدود می‌شود** (بالا آمدن دیافراگم)، **بار قلبی افزایش می‌یابد**، و **ایمنی سلولی به‌طور فیزیولوژیک تعدیل می‌شود** تا جنین رد نشود. نتیجه: **خطر بستری، ICU و مرگ در زن باردار مبتلا به آنفلوانزا چند برابر جمعیت عمومی است**.\n\n"
 "**تصمیم اول — کدام واکسن؟**\n\n"
 "**واکسن غیرفعال (تزریقی).** ⚠️ **واکسن اینترانازال (LAIV) ویروس زنده‌ی ضعیف‌شده است و در بارداری ممنوع است.** همچنین در **نقص ایمنی**، **کودکان زیر ۲ سال** و **افراد بالای ۵۰ سال** به کار نمی‌رود.\n\n"
 "**تصمیم دوم — کدام دارو؟**\n\n"
 "**اوسلتامیویر**، به‌عنوان پروفیلاکسی پس از تماس. ⚠️ **آمانتادین از سال ۲۰۰۹ کنار گذاشته شده** — هم به‌خاطر **مقاومت تقریباً کامل** سویه‌های در گردش و هم چون **روی تیپ B اصلاً اثر ندارد**. پس هر گزینه‌ای که آمانتادین داشته باشد، بدون نیاز به فکر بیشتر غلط است.\n\n"
 "⚠️ **و نکته‌ای که چرایی ترکیب را روشن می‌کند: واکسن و دارو مکمل‌اند، نه جایگزین.**\n\n"
 "**واکسن حدود ۲ هفته** طول می‌کشد تا ایمنی بسازد — یعنی برای تماسی که **همین حالا** رخ داده دیر است. **اوسلتامیویر همین حالا محافظت می‌دهد.** پس یکی خطر فعلی را می‌پوشاند و دیگری بقیه‌ی فصل را.\n\n"
 "**و یک سود مضاعف واکسیناسیون در بارداری:** آنتی‌بادی مادر **از جفت عبور می‌کند** و **نوزاد را در ۶ ماه اول زندگی محافظت می‌کند** — دقیقاً همان دوره‌ای که خودِ نوزاد نمی‌تواند واکسینه شود.",
 "This question tests TWO DECISIONS AT ONCE: which VACCINE and which DRUG.\n\n"
 "WARNING, FIRST KNOW WHY SHE IS HIGH RISK: PREGNANCY IN ANY TRIMESTER IS A HIGH-RISK GROUP — and among the highest.\n\n"
 "THE PHYSIOLOGICAL REASON: in pregnancy TIDAL VOLUME IS RESTRICTED (the diaphragm rides high), CARDIAC LOAD RISES, and CELLULAR IMMUNITY IS PHYSIOLOGICALLY MODULATED so the fetus is not rejected. The result: THE RISK OF ADMISSION, ICU CARE AND DEATH IS SEVERAL TIMES THAT OF THE GENERAL POPULATION.\n\n"
 "DECISION ONE — WHICH VACCINE?\n\n"
 "THE INACTIVATED (INJECTED) VACCINE. WARNING: THE INTRANASAL VACCINE (LAIV) IS A LIVE ATTENUATED VIRUS AND IS CONTRAINDICATED IN PREGNANCY. It is likewise avoided in IMMUNODEFICIENCY, CHILDREN UNDER 2 and ADULTS OVER 50.\n\n"
 "DECISION TWO — WHICH DRUG?\n\n"
 "OSELTAMIVIR, as post-exposure prophylaxis. WARNING: AMANTADINE WAS ABANDONED IN 2009 — both for NEAR-COMPLETE RESISTANCE among circulating strains and because IT HAS NO ACTIVITY AGAINST TYPE B. So any option containing amantadine is wrong without further thought.\n\n"
 "WARNING, AND THE POINT THAT EXPLAINS WHY BOTH ARE GIVEN: THE VACCINE AND THE DRUG ARE COMPLEMENTARY, NOT ALTERNATIVES.\n\n"
 "THE VACCINE TAKES ABOUT TWO WEEKS to build immunity — too late for an exposure that has ALREADY happened. OSELTAMIVIR PROTECTS NOW. One covers the present risk, the other the rest of the season.\n\n"
 "AND A DOUBLE BENEFIT OF VACCINATION IN PREGNANCY: maternal antibody CROSSES THE PLACENTA and PROTECTS THE INFANT THROUGH ITS FIRST SIX MONTHS — exactly the period when the baby cannot be vaccinated itself.",
 ["آمانتادین از سال ۲۰۰۹ کنار گذاشته شده است؛ مقاومت تقریباً کامل دارد و روی تیپ B بی‌اثر است.",
  "واکسن اینترانازال ویروس زنده‌ی ضعیف‌شده است و در بارداری ممنوع می‌باشد.",
  "پاسخ صحیح — واکسن غیرفعال برای بارداری بی‌خطر است و اوسلتامیویر پروفیلاکسی پس از تماس را فراهم می‌کند.",
  "هم واکسن اینترانازال در بارداری ممنوع است و هم آمانتادین دیگر توصیه نمی‌شود."],
 ["Amantadine was abandoned in 2009; resistance is near-complete and it has no activity against type B.",
  "The intranasal vaccine is a live attenuated virus and is contraindicated in pregnancy.",
  "Correct — the inactivated vaccine is safe in pregnancy and oseltamivir provides post-exposure prophylaxis.",
  "Both wrong: the intranasal vaccine is contraindicated in pregnancy and amantadine is no longer recommended."],
 "بارداری: **واکسن غیرفعال بله، اینترانازال (زنده) هرگز.** **آمانتادین از ۲۰۰۹ کنار گذاشته شده.**",
 "In pregnancy: the inactivated vaccine yes, the intranasal live vaccine never. Amantadine was abandoned in 2009.",
 [ACIP, CDCAV])


# =========================================================== book:591
add("book:591", "case", "easy",
 "**آسپیرین در کودک مبتلا به آنفلوانزا ممنوع است** — خطر **سندرم ری**.",
 "ASPIRIN IS FORBIDDEN IN A CHILD WITH INFLUENZA — the risk of REYE'S SYNDROME.",
 FLU_FA + RX_FA + [
  "این سؤال یکی از معدود **ممنوعیت‌های مطلق** طب کودکان را می‌سنجد.",
  "⚠️ **آسپیرین در کودک مبتلا به آنفلوانزا یا آبله‌مرغان هرگز داده نمی‌شود.**",
  "**علت: سندرم ری (Reye's syndrome).**",
  "**سندرم ری چیست؟** یک **انسفالوپاتی حاد** به‌همراه **دژنراسیون چرب کبد**،",
  "که چند روز پس از یک عفونت ویروسی (به‌ویژه آنفلوانزای B و آبله‌مرغان) شروع می‌شود.",
  "**مکانیسم: آسیب میتوکندریایی و مهار بتا-اکسیداسیون اسیدهای چرب.**",
  "**سیر بالینی‌اش را بدانید، چون جداگانه هم پرسیده می‌شود:**",
  "**استفراغ مقاوم** ← **تغییر رفتار و تحریک‌پذیری** ← **گیجی** ← **تشنج** ← **کما**.",
  "**آزمایش‌ها: آنزیم‌های کبدی و آمونیاک بالا، ولی بیلی‌روبین معمولاً طبیعی است.**",
  "⚠️ همین «آمونیاک بالا با بیلی‌روبین طبیعی» یافته‌ی افتراقی مهمی است.",
  "**پس در کودک، تب را با استامینوفن یا ایبوپروفن پایین بیاورید، هرگز با آسپیرین.**",
  "**سه گزینه‌ی دیگر همگی بی‌خطر و مناسب‌اند:**",
  "**ایبوپروفن** و **استامینوفن** ← ضدتب‌های استاندارد کودکان.",
  "**اوسلتامیویر** ← در کودک با **آنفلوانزای شدید** دقیقاً اندیکاسیون دارد.",
  "⚠️ **و یک نکته‌ی مکمل: کودکان زیر ۱۹ سال که به هر دلیل آسپیرین طولانی‌مدت می‌گیرند**",
  "(مثلاً بیماری کاوازاکی یا بیماری روماتیسمی) **خودشان یک گروه پرخطر آنفلوانزا هستند** —",
  "دقیقاً به همین دلیل که در صورت ابتلا، در معرض سندرم ری قرار می‌گیرند.",
 ],
 FLU_EN + RX_EN + [
  "This question tests one of the few ABSOLUTE PROHIBITIONS in paediatrics.",
  "WARNING: ASPIRIN IS NEVER GIVEN TO A CHILD WITH INFLUENZA OR CHICKENPOX.",
  "THE REASON: REYE'S SYNDROME.",
  "WHAT IS REYE'S SYNDROME? An ACUTE ENCEPHALOPATHY with FATTY DEGENERATION OF THE LIVER,",
  "beginning a few days after a viral infection (especially influenza B and chickenpox).",
  "THE MECHANISM: MITOCHONDRIAL INJURY AND INHIBITION OF FATTY ACID BETA-OXIDATION.",
  "KNOW ITS CLINICAL COURSE, because it is asked in its own right:",
  "INTRACTABLE VOMITING, then BEHAVIOURAL CHANGE AND IRRITABILITY, then CONFUSION, SEIZURES and COMA.",
  "LABORATORY: RAISED LIVER ENZYMES AND AMMONIA, but the BILIRUBIN IS USUALLY NORMAL.",
  "WARNING, that combination — high ammonia with a normal bilirubin — is an important discriminator.",
  "SO IN A CHILD, BRING THE FEVER DOWN WITH PARACETAMOL OR IBUPROFEN, NEVER WITH ASPIRIN.",
  "THE OTHER THREE OPTIONS ARE ALL SAFE AND APPROPRIATE:",
  "IBUPROFEN and PARACETAMOL — the standard paediatric antipyretics.",
  "OSELTAMIVIR — precisely indicated in a child with SEVERE INFLUENZA.",
  "WARNING, AND A COMPLEMENTARY POINT: CHILDREN UNDER 19 ON LONG-TERM ASPIRIN for any reason",
  "(Kawasaki disease, rheumatic disease) ARE THEMSELVES A HIGH-RISK INFLUENZA GROUP —",
  "for exactly this reason, that catching influenza puts them at risk of Reye's syndrome.",
 ],
 "این سؤال یکی از معدود **ممنوعیت‌های مطلق** طب کودکان را می‌سنجد، و پاسخش باید یک **رفلکس** باشد.\n\n"
 "⚠️ **آسپیرین در کودک مبتلا به آنفلوانزا یا آبله‌مرغان هرگز داده نمی‌شود. علت: سندرم ری.**\n\n"
 "**سندرم ری چیست؟**\n\n"
 "یک **انسفالوپاتی حاد** به‌همراه **دژنراسیون چرب کبد**، که چند روز پس از یک عفونت ویروسی — به‌ویژه **آنفلوانزای تیپ B** و **آبله‌مرغان** — شروع می‌شود. مکانیسمش **آسیب میتوکندریایی و مهار بتا-اکسیداسیون اسیدهای چرب** است.\n\n"
 "**سیر بالینی‌اش را حفظ کنید، چون جداگانه هم پرسیده می‌شود:**\n\n"
 "**استفراغ مقاوم** ← **تغییر رفتار و تحریک‌پذیری** ← **گیجی** ← **تشنج** ← **کما**\n\n"
 "⚠️ **و یافته‌ی آزمایشگاهی افتراقی مهم:** **آنزیم‌های کبدی و آمونیاک بالا می‌روند، ولی بیلی‌روبین معمولاً طبیعی می‌ماند**. این «آمونیاک بالا با بیلی‌روبین طبیعی» آن را از هپاتیت جدا می‌کند.\n\n"
 "**پس در کودک تب‌دار، ضدتب انتخابی استامینوفن یا ایبوپروفن است — هرگز آسپیرین.**\n\n"
 "**سه گزینه‌ی دیگر همگی بی‌خطر و مناسب‌اند:** **ایبوپروفن** و **استامینوفن** ضدتب‌های استاندارد کودکان‌اند، و **اوسلتامیویر** در کودک با **آنفلوانزای شدید** دقیقاً اندیکاسیون دارد.\n\n"
 "⚠️ **و یک نکته‌ی مکمل که حلقه را کامل می‌کند:** **کودکان زیر ۱۹ سال که به هر دلیلی آسپیرین طولانی‌مدت می‌گیرند** (مثلاً پس از بیماری کاوازاکی یا در بیماری روماتیسمی) **خودشان یک گروه پرخطر آنفلوانزا محسوب می‌شوند** — دقیقاً به همین دلیل که ابتلا به آنفلوانزا آن‌ها را در معرض سندرم ری قرار می‌دهد. پس اولویت واکسیناسیون دارند.",
 "This question tests one of the few ABSOLUTE PROHIBITIONS in paediatrics, and the answer should be a REFLEX.\n\n"
 "WARNING: ASPIRIN IS NEVER GIVEN TO A CHILD WITH INFLUENZA OR CHICKENPOX. THE REASON IS REYE'S SYNDROME.\n\n"
 "WHAT IS REYE'S SYNDROME?\n\n"
 "An ACUTE ENCEPHALOPATHY with FATTY DEGENERATION OF THE LIVER, beginning a few days after a viral infection — especially INFLUENZA TYPE B and CHICKENPOX. The mechanism is MITOCHONDRIAL INJURY AND INHIBITION OF FATTY ACID BETA-OXIDATION.\n\n"
 "MEMORISE ITS CLINICAL COURSE, because it is asked in its own right:\n\n"
 "INTRACTABLE VOMITING, then BEHAVIOURAL CHANGE AND IRRITABILITY, then CONFUSION, SEIZURES, COMA\n\n"
 "WARNING, AND AN IMPORTANT DISCRIMINATING LABORATORY FINDING: LIVER ENZYMES AND AMMONIA RISE, BUT THE BILIRUBIN USUALLY STAYS NORMAL. That combination separates it from hepatitis.\n\n"
 "SO IN A FEBRILE CHILD THE ANTIPYRETIC OF CHOICE IS PARACETAMOL OR IBUPROFEN — NEVER ASPIRIN.\n\n"
 "THE OTHER THREE OPTIONS ARE ALL SAFE AND APPROPRIATE: IBUPROFEN and PARACETAMOL are the standard paediatric antipyretics, and OSELTAMIVIR is precisely indicated in a child with SEVERE INFLUENZA.\n\n"
 "WARNING, AND A COMPLEMENTARY POINT THAT CLOSES THE LOOP: CHILDREN UNDER 19 WHO TAKE LONG-TERM ASPIRIN for any reason (after Kawasaki disease, or in rheumatic disease) ARE THEMSELVES A HIGH-RISK INFLUENZA GROUP — for exactly this reason, that catching influenza exposes them to Reye's syndrome. They are therefore a vaccination priority.",
 ["ایبوپروفن ضدتب مناسبی برای کودک است و ارتباطی با سندرم ری ندارد.",
  "پاسخ صحیح — آسپیرین در کودک مبتلا به آنفلوانزا یا آبله‌مرغان ممنوع است، به‌علت خطر سندرم ری.",
  "استامینوفن ضدتب استاندارد و انتخاب اول در کودک تب‌دار است.",
  "اوسلتامیویر در کودک مبتلا به آنفلوانزای شدید دقیقاً اندیکاسیون دارد و باید تجویز شود."],
 ["Ibuprofen is a suitable antipyretic in children and has no association with Reye's syndrome.",
  "Correct — aspirin is forbidden in a child with influenza or chickenpox because of the risk of Reye's syndrome.",
  "Paracetamol is the standard antipyretic and first choice in a febrile child.",
  "Oseltamivir is precisely indicated in a child with severe influenza and should be given."],
 "**آسپیرین + کودک + آنفلوانزا/آبله‌مرغان = سندرم ری.** آمونیاک بالا با **بیلی‌روبین طبیعی**.",
 "Aspirin plus a child plus influenza or chickenpox means Reye's syndrome: high ammonia with a normal bilirubin.",
 [H195])


# =========================================================== book:593
add("book:593", "case", "medium",
 "بیمار **آسمی** ← **اوسلتامیویر خوراکی**، نه زانامیویر استنشاقی (برونکواسپاسم).",
 "In an ASTHMATIC patient choose ORAL OSELTAMIVIR, not inhaled zanamivir (bronchospasm).",
 FLU_FA + RX_FA + RISK_FA + [
  "بیمار **آسمی** با علائم حاد آنفلوانزا و **تشدید تنگی نفس** مراجعه کرده است.",
  "⚠️ **دو نکته را هم‌زمان باید ببینید: بیمار پرخطر است، و یکی از داروها برایش خطرناک است.**",
  "**اول: آسم یک بیماری مزمن ریوی و یک گروه پرخطر آنفلوانزاست.**",
  "پس **درمان ضدویروسی قطعاً اندیکاسیون دارد** — سؤال فقط این است که کدام دارو.",
  "**آمانتادین و ریمانتادین** ← از **۲۰۰۹** کنار گذاشته شده‌اند: مقاومت تقریباً کامل،",
  "و **بی‌اثری کامل روی تیپ B**. پس هر دو گزینه بدون بحث حذف می‌شوند.",
  "**می‌ماند دو مهارکننده‌ی نورامینیداز: اوسلتامیویر خوراکی و زانامیویر استنشاقی.**",
  "⚠️ **و اینجاست که آسم تصمیم را می‌گیرد: زانامیویر استنشاقی برونکواسپاسم می‌سازد.**",
  "**در بیمار آسمی یا COPD، زانامیویر می‌تواند تنگی نفس را بدتر کند** —",
  "و این بیمار همین حالا هم **تشدید تنگی نفس** دارد.",
  "**پس اوسلتامیویر خوراکی انتخاب درست است.**",
  "**دو نکته‌ی عملی درباره‌ی اوسلتامیویر:**",
  "**دوز بزرگسال: ۷۵ میلی‌گرم دو بار در روز به مدت ۵ روز** (در پروفیلاکسی: روزی یک بار).",
  "⚠️ **شایع‌ترین عارضه: تهوع و استفراغ** — با **مصرف همراه غذا** کمتر می‌شود.",
  "**و در بیمار آسمی، درمان آنفلوانزا فقط ضدویروس نیست:**",
  "**تشدید آسم هم باید هم‌زمان با برونکودیلاتور و در صورت لزوم کورتیکواستروئید درمان شود.**",
 ],
 FLU_EN + RX_EN + RISK_EN + [
  "An ASTHMATIC patient presents with acute influenza and WORSENING BREATHLESSNESS.",
  "WARNING: SEE TWO THINGS AT ONCE — the patient is high risk, and one of the drugs is dangerous for him.",
  "FIRST: ASTHMA IS A CHRONIC LUNG DISEASE AND A HIGH-RISK INFLUENZA GROUP.",
  "So ANTIVIRAL TREATMENT IS DEFINITELY INDICATED — the only question is which drug.",
  "AMANTADINE AND RIMANTADINE — abandoned since 2009: near-complete resistance,",
  "and NO ACTIVITY AT ALL AGAINST TYPE B. Both options are eliminated without discussion.",
  "THAT LEAVES THE TWO NEURAMINIDASE INHIBITORS: ORAL OSELTAMIVIR AND INHALED ZANAMIVIR.",
  "WARNING, AND HERE THE ASTHMA DECIDES: INHALED ZANAMIVIR CAUSES BRONCHOSPASM.",
  "IN AN ASTHMATIC OR COPD PATIENT ZANAMIVIR CAN WORSEN THE BREATHLESSNESS —",
  "and this patient already HAS WORSENING BREATHLESSNESS.",
  "SO ORAL OSELTAMIVIR IS THE RIGHT CHOICE.",
  "TWO PRACTICAL POINTS ABOUT OSELTAMIVIR:",
  "ADULT DOSE: 75 MG TWICE DAILY FOR 5 DAYS (once daily for prophylaxis).",
  "WARNING, THE COMMONEST ADVERSE EFFECT IS NAUSEA AND VOMITING — reduced by TAKING IT WITH FOOD.",
  "AND IN AN ASTHMATIC, TREATING INFLUENZA IS NOT ONLY ANTIVIRAL:",
  "THE ASTHMA EXACERBATION MUST BE TREATED IN PARALLEL with bronchodilators and, if needed, corticosteroids.",
 ],
 "بیمار **آسمی** با علائم حاد آنفلوانزا و **تشدید تنگی نفس** مراجعه کرده است. باید **دو نکته را هم‌زمان** ببینید: بیمار **پرخطر** است، و یکی از داروها **برای او خطرناک** است.\n\n"
 "**نکته‌ی اول: آسم یک بیماری مزمن ریوی و یک گروه پرخطر آنفلوانزاست.** پس **درمان ضدویروسی قطعاً اندیکاسیون دارد**؛ سؤال فقط این است که کدام دارو.\n\n"
 "**حالا چهار گزینه را غربال کنید:**\n\n"
 "⚠️ **آمانتادین و ریمانتادین** ← از سال **۲۰۰۹** کنار گذاشته شده‌اند: **مقاومت تقریباً کامل** سویه‌های در گردش، و **بی‌اثری کامل روی تیپ B**. هر دو بدون بحث حذف می‌شوند.\n\n"
 "**می‌مانند دو مهارکننده‌ی نورامینیداز:** اوسلتامیویر **خوراکی** و زانامیویر **استنشاقی**.\n\n"
 "⚠️ **و اینجاست که آسم تصمیم را می‌گیرد: زانامیویر استنشاقی برونکواسپاسم می‌سازد.**\n\n"
 "در بیمار آسمی یا COPD، زانامیویر می‌تواند **تنگی نفس را بدتر کند** — و این بیمار همین حالا هم با **تشدید تنگی نفس** آمده است. دادن دارویی که خودش برونکواسپاسم می‌سازد به چنین بیماری، خطای بالینی روشنی است.\n\n"
 "**پس پاسخ: اوسلتامیویر خوراکی.**\n\n"
 "**دو نکته‌ی عملی که جداگانه هم پرسیده می‌شوند:**\n\n"
 "**دوز بزرگسال: ۷۵ میلی‌گرم دو بار در روز، ۵ روز** (در پروفیلاکسی روزی یک بار)\n"
 "⚠️ **شایع‌ترین عارضه: تهوع و استفراغ** — که با **مصرف همراه غذا** کمتر می‌شود\n\n"
 "**و فراموش نکنید:** در بیمار آسمی، درمان فقط ضدویروسی نیست؛ **تشدید آسم هم باید هم‌زمان با برونکودیلاتور و در صورت لزوم کورتیکواستروئید سیستمیک درمان شود**.",
 "An ASTHMATIC patient presents with acute influenza and WORSENING BREATHLESSNESS. You must see TWO THINGS AT ONCE: the patient is HIGH RISK, and one of the drugs is DANGEROUS FOR HIM.\n\n"
 "FIRST POINT: ASTHMA IS A CHRONIC LUNG DISEASE AND A HIGH-RISK INFLUENZA GROUP. So ANTIVIRAL TREATMENT IS DEFINITELY INDICATED; the only question is which drug.\n\n"
 "NOW SIFT THE FOUR OPTIONS:\n\n"
 "WARNING, AMANTADINE AND RIMANTADINE — abandoned since 2009: NEAR-COMPLETE RESISTANCE among circulating strains, and NO ACTIVITY AT ALL AGAINST TYPE B. Both are eliminated without discussion.\n\n"
 "THAT LEAVES THE TWO NEURAMINIDASE INHIBITORS: ORAL oseltamivir and INHALED zanamivir.\n\n"
 "WARNING, AND HERE THE ASTHMA DECIDES: INHALED ZANAMIVIR CAUSES BRONCHOSPASM.\n\n"
 "In an asthmatic or COPD patient zanamivir can WORSEN THE BREATHLESSNESS — and this patient has arrived with WORSENING BREATHLESSNESS already. Giving a drug that itself provokes bronchospasm to such a patient is a plain clinical error.\n\n"
 "SO THE ANSWER IS ORAL OSELTAMIVIR.\n\n"
 "TWO PRACTICAL POINTS THAT ARE ALSO ASKED SEPARATELY:\n\n"
 "ADULT DOSE: 75 MG TWICE DAILY FOR 5 DAYS (once daily for prophylaxis)\n"
 "WARNING, COMMONEST ADVERSE EFFECT: NAUSEA AND VOMITING — reduced by TAKING IT WITH FOOD\n\n"
 "AND DO NOT FORGET: in an asthmatic, treatment is not only antiviral; THE ASTHMA EXACERBATION MUST BE TREATED IN PARALLEL with bronchodilators and, if needed, systemic corticosteroids.",
 ["آمانتادین از سال ۲۰۰۹ کنار گذاشته شده است: مقاومت تقریباً کامل و بی‌اثری روی تیپ B.",
  "ریمانتادین هم مانند آمانتادین در گروه آدامانتان‌هاست و دیگر توصیه نمی‌شود.",
  "پاسخ صحیح — اوسلتامیویر خوراکی در بیمار آسمی انتخاب درست است و خطر برونکواسپاسم ندارد.",
  "زانامیویر استنشاقی در آسم و COPD برونکواسپاسم می‌سازد و در این بیمار مناسب نیست."],
 ["Amantadine was abandoned in 2009: near-complete resistance and no activity against type B.",
  "Rimantadine, like amantadine, is an adamantane and is no longer recommended.",
  "Correct — oral oseltamivir is the right choice in an asthmatic and carries no bronchospasm risk.",
  "Inhaled zanamivir causes bronchospasm in asthma and COPD and is unsuitable for this patient."],
 "**آسم/COPD ← زانامیویر استنشاقی نه، اوسلتامیویر خوراکی بله.** **آدامانتان‌ها از ۲۰۰۹ کنار گذاشته شده‌اند.**",
 "In asthma or COPD, not inhaled zanamivir but oral oseltamivir. The adamantanes were abandoned in 2009.",
 [CDCAV, IDSAF])


# =========================================================== book:595
add("book:595", "recall", "medium",
 "**فشار خون بالا به‌تنهایی** گروه پرخطر آنفلوانزا نیست — استثنای صریح راهنما.",
 "HYPERTENSION ALONE is not a high-risk influenza group — an explicit exception in the guideline.",
 FLU_FA + RISK_FA + RX_FA + [
  "⚠️ **توجه: سن گزینه‌ی چهارم این سؤال تصحیح شده است** (۵۴ ← ۴۵، طبق صفحه‌ی ۲۲۲).",
  "این تصحیح پاسخ را عوض نمی‌کند، چون دیابت — نه سن — آن گزینه را پرخطر می‌کند.",
  "**سؤال منفی است: کدام بیمار به اوسلتامیویر نیاز ندارد؟**",
  "پس سه بیمار **پرخطر** را بشناسید تا چهارمی خودش را نشان دهد.",
  "**مرد ۳۰ ساله تحت درمان با آسپیرین؟** ⚠️ **پرخطر.**",
  "**افراد زیر ۱۹ سال با آسپیرین طولانی‌مدت** گروه پرخطر کلاسیک‌اند (به‌خاطر سندرم ری)،",
  "و مصرف مزمن آسپیرین در بزرگسال هم معمولاً نشانه‌ی **بیماری قلبی-عروقی زمینه‌ای** است.",
  "**خانم ۲۵ ساله با حاملگی هشت هفته؟** **پرخطر** — بارداری در **هر سه‌ماهه**.",
  "**آقای ۴۵ ساله دیابتی؟** **پرخطر** — دیابت یک اختلال متابولیک و از فهرست اصلی است.",
  "⚠️ **می‌ماند «آقای ۴۰ ساله مبتلا به پرفشاری خون» — و پاسخ همین است.**",
  "**چرا؟ چون راهنمای CDC صریحاً «فشار خون بالا به‌تنهایی» را از فهرست مستثنا می‌کند.**",
  "عبارت دقیق راهنما: بیماری قلبی-عروقی **«به‌جز فشار خون تنها»**.",
  "**منطقش:** فشار خون کنترل‌شده و بدون آسیب عضو هدف، **ذخیره‌ی قلبی-ریوی را کم نمی‌کند**",
  "و مطالعات، افزایش خطر مستقلی برای عوارض آنفلوانزا در آن نشان نداده‌اند.",
  "⚠️ **ولی دقت کنید: اگر همان بیمار نارسایی قلبی، بیماری ایسکمیک یا نارسایی کلیه پیدا کند،**",
  "**بلافاصله وارد گروه پرخطر می‌شود.** مرز، **آسیب عضو هدف** است نه خودِ عدد فشار خون.",
  "**و یادآوری: «نیاز ندارد» یعنی الزام ندارد؛ اگر ظرف ۴۸ ساعت مراجعه کند، تجویز مجاز است.**",
 ],
 FLU_EN + RISK_EN + RX_EN + [
  "WARNING, NOTE: THE AGE IN THE FOURTH OPTION HAS BEEN CORRECTED (54 to 45, per page 222).",
  "The correction does not change the answer, because it is the DIABETES, not the age, that makes that option high risk.",
  "THE QUESTION IS NEGATIVE: WHICH PATIENT DOES NOT NEED OSELTAMIVIR?",
  "So identify the three HIGH-RISK patients and the fourth reveals itself.",
  "A 30-YEAR-OLD MAN ON ASPIRIN? WARNING, HIGH RISK.",
  "PEOPLE UNDER 19 ON LONG-TERM ASPIRIN are a classical high-risk group (because of Reye's syndrome),",
  "and chronic aspirin in an adult usually signals UNDERLYING CARDIOVASCULAR DISEASE.",
  "A 25-YEAR-OLD WOMAN AT EIGHT WEEKS' GESTATION? HIGH RISK — pregnancy in ANY trimester.",
  "A 45-YEAR-OLD DIABETIC? HIGH RISK — diabetes is a metabolic disorder and on the core list.",
  "WARNING, THAT LEAVES 'A 40-YEAR-OLD MAN WITH HYPERTENSION' — and that is the answer.",
  "WHY? BECAUSE THE CDC GUIDELINE EXPLICITLY EXCLUDES 'HYPERTENSION ALONE' FROM THE LIST.",
  "The guideline's exact phrase: cardiovascular disease 'EXCEPT HYPERTENSION ALONE'.",
  "THE LOGIC: controlled hypertension without end-organ damage DOES NOT REDUCE CARDIOPULMONARY RESERVE,",
  "and studies have not shown an independent increase in the risk of influenza complications.",
  "WARNING, BUT NOTE: IF THAT SAME PATIENT DEVELOPS HEART FAILURE, ISCHAEMIC DISEASE OR RENAL FAILURE,",
  "HE ENTERS THE HIGH-RISK GROUP AT ONCE. The boundary is END-ORGAN DAMAGE, not the blood pressure number.",
  "AND A REMINDER: 'does not need' means not mandatory; if he presents within 48 hours, treatment is permitted.",
 ],
 "⚠️ **توجه: سن گزینه‌ی چهارم این سؤال تصحیح شده است** (۵۴ ← ۴۵، مطابق صفحه‌ی ۲۲۲). این تصحیح پاسخ را عوض نمی‌کند، چون آنچه آن گزینه را پرخطر می‌کند **دیابت** است نه سن.\n\n"
 "**سؤال منفی است: کدام بیمار به اوسلتامیویر نیاز ندارد؟** پس سه بیمار **پرخطر** را بشناسیم:\n\n"
 "**مرد ۳۰ ساله تحت درمان با آسپیرین** ← ⚠️ **پرخطر**. افراد زیر ۱۹ سال با آسپیرین طولانی‌مدت گروه پرخطر کلاسیک‌اند (به‌خاطر **سندرم ری**)، و مصرف مزمن آسپیرین در بزرگسال هم معمولاً نشانه‌ی **بیماری قلبی-عروقی زمینه‌ای** است.\n\n"
 "**خانم ۲۵ ساله با حاملگی هشت هفته** ← **پرخطر**؛ بارداری در **هر سه‌ماهه**.\n\n"
 "**آقای ۴۵ ساله دیابتی** ← **پرخطر**؛ دیابت یک اختلال متابولیک و از فهرست اصلی است.\n\n"
 "⚠️ **می‌ماند «آقای ۴۰ ساله مبتلا به پرفشاری خون» — و پاسخ همین است.**\n\n"
 "**چرا؟** چون راهنمای CDC **صریحاً** فشار خون بالا را از فهرست مستثنا می‌کند. عبارت دقیقش این است: بیماری قلبی-عروقی **«به‌جز فشار خون تنها»** (except hypertension alone).\n\n"
 "**منطق پشت این استثنا:** فشار خون کنترل‌شده و **بدون آسیب عضو هدف**، **ذخیره‌ی قلبی-ریوی را کاهش نمی‌دهد**، و مطالعات افزایش خطر مستقلی برای عوارض آنفلوانزا در آن نشان نداده‌اند. برخلاف دیابت که ایمنی ذاتی را مختل می‌کند یا COPD که ذخیره‌ی تنفسی را می‌بلعد، فشار خون تنها چنین اثری ندارد.\n\n"
 "⚠️ **ولی مرز را دقیق بشناسید:** اگر همان بیمار **نارسایی قلبی، بیماری ایسکمیک قلب یا نارسایی کلیه** پیدا کند، **بلافاصله وارد گروه پرخطر می‌شود**. یعنی مرز، **آسیب عضو هدف** است نه خودِ عدد فشار خون.\n\n"
 "**و یک یادآوری:** «نیاز ندارد» یعنی **الزام ندارد**، نه اینکه ممنوع باشد. اگر همین بیمار ظرف ۴۸ ساعت از شروع علائم مراجعه کند، تجویز اوسلتامیویر بر پایه‌ی قضاوت بالینی مجاز است.",
 "WARNING, NOTE: THE AGE IN THE FOURTH OPTION HAS BEEN CORRECTED (54 to 45, per page 222). This does not change the answer, because what makes that option high risk is the DIABETES, not the age.\n\n"
 "THE QUESTION IS NEGATIVE: WHICH PATIENT DOES NOT NEED OSELTAMIVIR? So identify the three HIGH-RISK patients:\n\n"
 "A 30-YEAR-OLD MAN ON ASPIRIN — WARNING, HIGH RISK. People under 19 on long-term aspirin are a classical high-risk group (because of REYE'S SYNDROME), and chronic aspirin in an adult usually signals UNDERLYING CARDIOVASCULAR DISEASE.\n\n"
 "A 25-YEAR-OLD WOMAN AT EIGHT WEEKS' GESTATION — HIGH RISK; pregnancy in ANY trimester.\n\n"
 "A 45-YEAR-OLD DIABETIC — HIGH RISK; diabetes is a metabolic disorder on the core list.\n\n"
 "WARNING, THAT LEAVES 'A 40-YEAR-OLD MAN WITH HYPERTENSION' — and that is the answer.\n\n"
 "WHY? Because the CDC guideline EXPLICITLY excludes hypertension from the list. Its exact phrase is: cardiovascular disease 'EXCEPT HYPERTENSION ALONE'.\n\n"
 "THE LOGIC BEHIND THE EXCEPTION: controlled hypertension WITHOUT END-ORGAN DAMAGE DOES NOT REDUCE CARDIOPULMONARY RESERVE, and studies have shown no independent increase in the risk of influenza complications. Unlike diabetes, which impairs innate immunity, or COPD, which consumes respiratory reserve, hypertension alone does not.\n\n"
 "WARNING, BUT KNOW THE BOUNDARY PRECISELY: if that same patient develops HEART FAILURE, ISCHAEMIC HEART DISEASE OR RENAL FAILURE, HE ENTERS THE HIGH-RISK GROUP IMMEDIATELY. The boundary is END-ORGAN DAMAGE, not the blood pressure reading.\n\n"
 "AND A REMINDER: 'does not need' means NOT MANDATORY, not forbidden. If this patient presents within 48 hours of onset, oseltamivir may be given on clinical judgement.",
 ["مصرف مزمن آسپیرین گروه پرخطر است، هم به‌علت خطر سندرم ری و هم معمولاً به‌دلیل بیماری قلبی زمینه‌ای.",
  "بارداری در هر سه‌ماهه یک گروه پرخطر شناخته‌شده برای عوارض آنفلوانزاست.",
  "پاسخ صحیح — راهنما صریحاً «فشار خون بالا به‌تنهایی» را از فهرست گروه‌های پرخطر مستثنا می‌کند.",
  "دیابت یک اختلال متابولیک و از اعضای اصلی فهرست گروه‌های پرخطر آنفلوانزاست."],
 ["Chronic aspirin use is a high-risk category, both for the Reye's risk and because it usually signals cardiac disease.",
  "Pregnancy in any trimester is a recognised high-risk group for influenza complications.",
  "Correct — the guideline explicitly excludes 'hypertension alone' from the list of high-risk groups.",
  "Diabetes is a metabolic disorder and a core member of the high-risk list."],
 "**فشار خون تنها = پرخطر نیست** (استثنای صریح). با **آسیب عضو هدف**، فوراً پرخطر می‌شود.",
 "Hypertension alone is not high risk (an explicit exception). With end-organ damage it immediately becomes so.",
 [ACIP, CDCAV])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book23.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 23 lessons:', len(L))
