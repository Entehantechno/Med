# -*- coding: utf-8 -*-
"""Two more SOURCE defects, this time in the remaining viral/STI questions.

The distinction this bank has kept from the beginning, and keeps here:

  * an EXTRACTION defect means the page prints one thing and our text says
    another. Glyph geometry settles it, and the text is REPAIRED.
  * a SOURCE defect means the page itself prints something wrong or
    incomplete. There is no physical fact to appeal to, so the text is LEFT
    ALONE and ANNOTATED.

Rewriting a source defect would show the student something different from the
real booklet they will sit the exam with.

---------------------------------------------------------------- q9599
"...leucocytosis 15000 with 70% polymorphs and 30% lymphocytes, PLATELETS
1350000, and a mild rise in the liver transaminases."

A PLATELET COUNT OF 1,350,000 IS NOT A HUMAN VALUE. The normal range is
150,000 to 450,000 per microlitre. 1,350,000 would be extreme thrombocytosis,
a myeloproliferative-disease number — and it appears in a vignette whose whole
point is a benign, self-limiting illness treated with rest and analgesia.

GLYPH GEOMETRY PROVES THIS IS THE BOOK'S OWN TEXT, NOT OUR EXTRACTION. On
page 223 the digits are drawn, in ascending x:

    '1' at 136.6, '3' at 146.6, '5' at 156.6, '0' at 166.6,
    '0' at 176.6, '0' at 186.6, '0' at 196.6

so the page really does print 1350000, left to right, in one unbroken run. Our
text is faithful; the book is wrong.

The intended value is almost certainly 135,000 — a MILD THROMBOCYTOPENIA,
which is exactly what infectious mononucleosis produces and which fits the
rest of the panel (lymphocytosis, mildly raised transaminases). One extra zero
turned a classic mononucleosis panel into an impossible one.

DOES IT CHANGE THE ANSWER? No, and the lesson says so. The question is decided
by the CLINICAL TRIAD plus the FAILURE OF PENICILLIN, and the answer is
supportive care. But the defect is annotated so that nobody, human or script,
later "repairs" the digits and makes the impossible value look deliberate.

---------------------------------------------------------------- q9856
"...he has had two courses of HBV vaccine and his antibody titre was finally
reported as ABOUT 6."

THE UNIT IS MISSING ENTIRELY. Page 315 prints the bare number 6 with no unit
after it. Anti-HBs is reported in mIU/mL, and the protective threshold is
10 mIU/mL, so the intended reading is 6 mIU/mL — below protection, i.e. a
NON-RESPONDER after two full series.

This is the same shape as q9852 in the previous batch, where the book printed
IU/mL where mIU/mL belonged. Here it prints nothing at all. Both are source
defects and both are annotated rather than rewritten.

The missing unit does not change the answer either: a titre of 6 on any
reading of the number is below 10, so this surgeon is a non-responder. What
the lesson must add — and does — is that a TRUE non-responder after TWO full
series is not given a third series, because a third has a low chance of
working; such a person receives TWO DOSES OF HBIG a month apart, which is
exactly the printed key.
"""
import io
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))

FLAGS = {
    9599: [{
        'where': 'stem',
        'contains': '1350000',
        'kind': 'physiologically impossible platelet count (extra zero)',
        'fa': '⚠️ **خطای چاپی در خودِ کتاب:** پلاکت این بیمار **۱٬۳۵۰٬۰۰۰** چاپ شده '
              'است، در حالی که **محدوده‌ی طبیعی پلاکت ۱۵۰٬۰۰۰ تا ۴۵۰٬۰۰۰** در هر '
              'میکرولیتر است. عدد ۱٬۳۵۰٬۰۰۰ یک **ترومبوسیتوز شدید** است که در '
              'بیماری‌های میلوپرولیفراتیو دیده می‌شود — نه در یک بیماری خوش‌خیم و '
              'خودمحدودشونده.\n\n'
              '**هندسه‌ی گلیف ثابت می‌کند این متنِ خودِ کتاب است، نه خطای استخراج ما:** '
              'در صفحه ۲۲۳ ارقام به‌ترتیب صعودی x چاپ شده‌اند — «۱» در ۱۳۶٫۶، «۳» در '
              '۱۴۶٫۶، «۵» در ۱۵۶٫۶ و چهار صفر در ۱۶۶٫۶ تا ۱۹۶٫۶. یعنی صفحه واقعاً '
              '۱۳۵۰۰۰۰ را در یک رشته‌ی پیوسته چاپ کرده و **متن ما وفادار است**.\n\n'
              '**عدد موردنظر تقریباً به‌قطع ۱۳۵٬۰۰۰ بوده است** — یعنی یک '
              '**ترومبوسیتوپنی خفیف**، که دقیقاً همان چیزی است که مونونوکلئوز عفونی '
              'می‌سازد و با بقیه‌ی پنل (لنفوسیتوز و افزایش خفیف آنزیم‌های کبدی) '
              'کاملاً هم‌خوان است. **یک صفر اضافه، یک پنل کلاسیک مونونوکلئوز را به '
              'یک پنل ناممکن تبدیل کرده است.**\n\n'
              '**آیا پاسخ را عوض می‌کند؟ نه.** این سؤال با **سه‌گانه‌ی بالینی** و '
              '**شکست پنی‌سیلین** حل می‌شود و پاسخ **درمان حمایتی** است. متن عمداً '
              'دست‌نخورده مانده تا با دفترچه‌ی چاپی یکی باشد، و خطا فقط علامت‌گذاری '
              'شده است.',
        'en': 'WARNING, A MISPRINT IN THE SOURCE BOOK ITSELF: this patient\'s platelet count is '
              'printed as 1,350,000, whereas the NORMAL RANGE IS 150,000 TO 450,000 per '
              'microlitre. A value of 1,350,000 is EXTREME THROMBOCYTOSIS, a number seen in '
              'myeloproliferative disease — not in a benign, self-limiting illness.\n\n'
              'GLYPH GEOMETRY PROVES THIS IS THE BOOK\'S OWN TEXT AND NOT OUR EXTRACTION: on '
              'page 223 the digits are drawn in ascending x — "1" at 136.6, "3" at 146.6, "5" '
              'at 156.6 and four zeros from 166.6 to 196.6. So the page really does print '
              '1350000 in one unbroken run, and OUR TEXT IS FAITHFUL.\n\n'
              'THE INTENDED VALUE WAS ALMOST CERTAINLY 135,000 — a MILD THROMBOCYTOPENIA, which '
              'is exactly what infectious mononucleosis produces and which fits the rest of the '
              'panel (lymphocytosis, mildly raised transaminases). ONE EXTRA ZERO TURNED A '
              'CLASSIC MONONUCLEOSIS PANEL INTO AN IMPOSSIBLE ONE.\n\n'
              'DOES IT CHANGE THE ANSWER? NO. The question is decided by the CLINICAL TRIAD and '
              'the FAILURE OF PENICILLIN, and the answer is SUPPORTIVE CARE. The text is '
              'deliberately left unchanged so that it matches the printed booklet, and the '
              'error is only annotated.',
    }],
    9856: [{
        'where': 'stem',
        'contains': 'حدود 6',
        'kind': 'missing unit on an antibody titre',
        'fa': '⚠️ **نقص چاپی در خودِ کتاب: واحد این عدد اصلاً چاپ نشده است.** متن '
              'می‌گوید «تیتر آنتی‌بادی در نهایت حدود **۶**» و صفحه ۳۱۵ هم واقعاً همان '
              'عدد برهنه را بدون هیچ واحدی چاپ کرده است.\n\n'
              '**واحد درست mIU/mL است** (میلی‌واحد بین‌المللی در میلی‌لیتر)، و '
              '**آستانه‌ی محافظت ۱۰ mIU/mL** است. پس خوانش موردنظر **۶ mIU/mL** است — '
              '**زیر آستانه**، یعنی این جراح پس از **دو سری کامل واکسن** یک '
              '**نان‌رسپاندر** است.\n\n'
              'این دقیقاً همان شکل خطایی است که در q9852 دیدیم، با این تفاوت که آنجا '
              'واحد **غلط** چاپ شده بود و اینجا **هیچ** واحدی چاپ نشده است. هر دو '
              'خطای منبع‌اند و هر دو **پرچم‌گذاری می‌شوند، نه بازنویسی**.\n\n'
              '**آیا پاسخ را عوض می‌کند؟ نه** — عدد ۶ با هر خوانشی زیر ۱۰ است، پس '
              'بیمار نان‌رسپاندر است و کلید چاپی درست است.',
        'en': 'WARNING, A PRINTING DEFECT IN THE SOURCE BOOK: THE UNIT IS MISSING ENTIRELY. The '
              'text says the antibody titre was "finally about 6", and page 315 does indeed '
              'print that bare number with no unit after it.\n\n'
              'THE CORRECT UNIT IS mIU/mL, and the PROTECTIVE THRESHOLD IS 10 mIU/mL. So the '
              'intended reading is 6 mIU/mL — BELOW THE THRESHOLD, meaning this surgeon is a '
              'NON-RESPONDER after TWO FULL VACCINE SERIES.\n\n'
              'This is the same shape of defect as q9852, except that there the unit was printed '
              'WRONGLY and here it is not printed AT ALL. Both are source defects and both are '
              'ANNOTATED RATHER THAN REWRITTEN.\n\n'
              'DOES IT CHANGE THE ANSWER? NO — 6 on any reading is below 10, so the patient is a '
              'non-responder and the printed key stands.',
    }],
}


def main():
    done, missing = [], []
    for i in range(1, 6):
        p = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        if not os.path.exists(p):
            continue
        body = json.load(io.open(p, encoding='utf-8'))
        dirty = False
        for q in body['questions']:
            specs = FLAGS.get(q['question_no'])
            if not specs:
                continue
            for spec in specs:
                if spec['contains'] not in q['question_fa']:
                    missing.append(
                        f"q{q['question_no']}: the stem no longer contains "
                        f"{spec['contains']!r} — has it already been edited?")
                    continue
                notes = q.setdefault('source_defects', [])
                # already annotated is NOT a failure: these scripts must be
                # idempotent, a rule learned when a rerun reported five
                # ALREADY-CORRECT questions as failures
                if any(n.get('kind') == spec['kind'] for n in notes):
                    done.append(f"q{q['question_no']}: already annotated ({spec['kind']})")
                    continue
                notes.append({
                    'where': spec['where'],
                    'kind': spec['kind'],
                    'note_fa': spec['fa'],
                    'note_en': spec['en'],
                    'action': 'annotated, text left unchanged (this is a source error, '
                              'not an extraction defect)',
                })
                done.append(f"q{q['question_no']}: flagged — {spec['kind']}")
                dirty = True
        if dirty:
            json.dump(body, io.open(p, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)

    for d in done:
        print('  ', d)
    assert not missing, missing
    assert done, 'no question matched; the script did nothing'
    print(f'\nsource defects annotated: {len(done)}')


if __name__ == '__main__':
    main()
