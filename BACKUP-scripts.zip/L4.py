# -*- coding: utf-8 -*-
"""Infectious-diseases micro-lessons, batch 4 — Esfand-1400 (items 122-130).

English stems/options came verbatim from the ministry's official English
booklet and are not written here. Reference: Harrison's 21st ed.
"""
import json, io
L = {}

L["1400-12:122"] = {
 "style": "recall", "difficulty": "medium",
 "micro": {
  "lead_fa": "آستانه‌ی مثبت PPD ثابت نیست: ۵ برای پرخطر، ۱۰ برای خطر متوسط، ۱۵ برای فرد سالم.",
  "lead_en": "The PPD positivity threshold is not fixed: 5 mm for high risk, 10 mm for moderate risk, 15 mm for healthy people.",
  "points_fa": [
   "تست پوستی توبرکولین پاسخ ازدیاد حساسیت تأخیری به آنتی‌ژن‌های مایکوباکتریوم را می‌سنجد.",
   "قطر اندوراسیون خوانده می‌شود، نه قطر قرمزی، و پس از چهل‌وهشت تا هفتاد و دو ساعت.",
   "آستانه‌ی مثبت بودن ثابت نیست و به احتمال قبلی ابتلا در آن فرد بستگی دارد.",
   "آستانه‌ی پنج میلی‌متر برای پرخطرترین گروه است: HIV مثبت و تماس نزدیک اخیر با مورد فعال.",
   "همچنین گیرندگان پیوند عضو، مصرف‌کنندگان طولانی‌مدت کورتیکواستروئید و کاندیدهای anti-TNF.",
   "و افرادی که تغییرات فیبروتیک سازگار با سل قدیمی در گرافی قفسه سینه دارند.",
   "آستانه‌ی ده میلی‌متر برای خطر متوسط است: کارکنان بهداشتی، مهاجران از مناطق پرشیوع، زندانیان.",
   "همچنین دیابتی‌ها، معتادان تزریقی، بیماران نارسایی کلیه و کودکان زیر چهار سال.",
   "آستانه‌ی پانزده میلی‌متر برای افراد بدون هیچ عامل خطر شناخته‌شده است.",
   "درمان سل نهفته با ایزونیازید تنها به مدت شش تا نه ماه انجام می‌شود.",
   "پیش از شروع، حتماً باید سل فعال با شرح حال و گرافی رد شود، وگرنه مقاومت دارویی ایجاد می‌شود.",
   "در نقص ایمنی شدید احتمال منفی کاذب یا آنرژی بالاست و IGRA جایگزین بهتری است."
  ],
  "points_en": [
   "The tuberculin skin test measures a delayed hypersensitivity response to mycobacterial antigens.",
   "You read the diameter of induration, not of erythema, at forty-eight to seventy-two hours.",
   "The positivity threshold is not fixed; it depends on the pre-test probability in that person.",
   "The five-millimetre threshold applies to the highest-risk group: HIV-positive patients and recent close contacts.",
   "It also covers organ transplant recipients, long-term corticosteroid users and anti-TNF candidates.",
   "And people with fibrotic changes on chest radiography consistent with old tuberculosis.",
   "The ten-millimetre threshold covers moderate risk: healthcare workers, migrants from high-burden areas, prisoners.",
   "Also diabetics, injecting drug users, patients with renal failure and children under four.",
   "The fifteen-millimetre threshold applies to people with no known risk factor at all.",
   "Latent TB is treated with isoniazid alone for six to nine months.",
   "Active disease must first be excluded by history and chest film, otherwise drug resistance develops.",
   "In severe immunodeficiency false negatives or anergy are common and IGRA is a better alternative."
  ]
 },
 "explanation_fa": "کل این سؤال روی یک جدول می‌چرخد: آستانه‌ی مثبت شدن PPD ثابت نیست و به میزان خطر فرد بستگی دارد. سه آستانه وجود دارد. آستانه‌ی پنج میلی‌متر برای پرخطرترین‌هاست: HIV مثبت، تماس نزدیک اخیر با مورد فعال، گیرنده‌ی پیوند عضو و هر کس که کورتیکواستروئید طولانی‌مدت می‌گیرد. آستانه‌ی ده میلی‌متر برای خطر متوسط است: کارکنان بهداشتی، مهاجران از مناطق آندمیک، زندانیان، دیابتی‌ها. و آستانه‌ی پانزده میلی‌متر برای افراد بدون هیچ عامل خطر. حالا گزینه‌ها را بسنجید: پرستار با هفده میلی‌متر از آستانه‌ی ده خودش عبور کرده. HIV مثبت با هفت میلی‌متر از آستانه‌ی پنج عبور کرده. تماس اخیر با اسمیر مثبت با پنج میلی‌متر دقیقاً روی آستانه‌ی پنج است. اما بیمار پیوند کبد با سه میلی‌متر — هرچند در گروه پنج میلی‌متری است — به آستانه‌اش نرسیده، پس PPD او منفی است و کاندید درمان سل نهفته نیست.",
 "explanation_en": "This whole question turns on one table: the PPD positivity threshold is not fixed but depends on the person's risk. There are three cut-offs. Five millimetres applies to the highest-risk people: HIV-positive patients, recent close contacts of an active case, transplant recipients and anyone on long-term corticosteroids. Ten millimetres covers moderate risk: healthcare workers, migrants from endemic areas, prisoners and diabetics. Fifteen millimetres is for people with no risk factor at all. Now test the options: the nurse at seventeen millimetres clears her own ten-millimetre threshold. The HIV-positive man at seven clears his five. The recent contact of a smear-positive case at five is exactly at her threshold. But the liver transplant patient at three millimetres, although he belongs to the five-millimetre group, has not reached his cut-off, so his PPD is negative and he is not a candidate for latent TB treatment.",
 "why_fa": [
  "پرستار در گروه خطر متوسط با آستانه‌ی ده میلی‌متر است و هفده میلی‌متر به‌روشنی مثبت محسوب می‌شود.",
  "بیمار HIV مثبت در گروه پرخطر با آستانه‌ی پنج میلی‌متر است و هفت میلی‌متر مثبت است.",
  "تماس نزدیک اخیر با سل اسمیر مثبت هم آستانه‌ی پنج میلی‌متر دارد و این بیمار دقیقاً روی آستانه است.",
  "پاسخ صحیح — گیرنده‌ی پیوند کبد آستانه‌ی پنج میلی‌متر دارد ولی اندوراسیون او فقط سه میلی‌متر است، پس منفی است."
 ],
 "why_en": [
  "The nurse is in the moderate-risk group with a ten-millimetre threshold, and seventeen is clearly positive.",
  "The HIV-positive patient is high-risk with a five-millimetre threshold, and seven is positive.",
  "A recent close contact of smear-positive TB also has a five-millimetre threshold, and this patient sits exactly on it.",
  "Correct — the liver transplant recipient has a five-millimetre threshold but only three millimetres of induration, so he is negative."
 ],
 "golden_fa": "PPD: ۵ (HIV/تماس/پیوند/استروئید) • ۱۰ (کادر درمان/مهاجر/دیابت) • ۱۵ (سالم).",
 "golden_en": "PPD: 5 mm (HIV, contact, transplant, steroid) • 10 mm (health worker, migrant, diabetic) • 15 mm (healthy).",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 178: Tuberculosis",
          "مدیریت سل نهفته — مصوبه ۱۴۰۳ کمیته کشوری سل، وزارت بهداشت"]
}

L["1400-12:123"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "مدفوع وبایی سرشار از بی‌کربنات و پتاسیم است. پس مایع باید هم حجم بدهد، هم باز، هم پتاسیم: رینگر لاکتات.",
  "lead_en": "Cholera stool is rich in bicarbonate and potassium, so the fluid must replace volume, base and potassium: Ringer's lactate.",
  "points_fa": [
   "ویبریو کلرا با توکسین خود آدنیلات سیکلاز را فعال می‌کند و ترشح کلر و آب به لومن روده را زیاد می‌کند.",
   "مخاط روده سالم می‌ماند، پس اسهال آبکی و بدون خون و بدون تب است.",
   "مدفوع کلاسیک، آب برنجی یا rice-water نامیده می‌شود و می‌تواند لیتری در ساعت باشد.",
   "مدفوع وبایی فقط آب نیست؛ سرشار از بی‌کربنات، پتاسیم و سدیم است.",
   "پس بیمار همزمان دچار دهیدراتاسیون شدید، اسیدوز متابولیک و هیپوکالمی می‌شود.",
   "دهیدراتاسیون بیش از ده درصد یعنی شوک هیپوولمیک و اورژانس واقعی است.",
   "مایع انتخابی باید سه کار کند: احیای حجم، جایگزینی باز و تأمین پتاسیم.",
   "رینگر لاکتات دقیقاً همین است؛ لاکتات آن در کبد به بی‌کربنات تبدیل می‌شود.",
   "سازمان جهانی بهداشت رینگر لاکتات را برای وبای شدید توصیه‌ی رسمی کرده است.",
   "نرمال سالین حجم می‌دهد ولی هیچ بازی ندارد و بار کلر بالای آن اسیدوز هایپرکلرمیک اضافه می‌کند.",
   "حجم مورد نیاز عظیم است: گاهی سی درصد کسری در نیم‌ساعت اول و بقیه در چند ساعت.",
   "آنتی‌بیوتیک مثل داکسی‌سایکلین کمکی است و مدت اسهال را کوتاه می‌کند، نه جایگزین مایع‌درمانی."
  ],
  "points_en": [
   "Vibrio cholerae toxin activates adenylate cyclase and drives chloride and water secretion into the gut lumen.",
   "The mucosa remains intact, so the diarrhoea is watery, without blood and without fever.",
   "The classic stool is called rice-water and can reach litres per hour.",
   "Cholera stool is not just water; it is rich in bicarbonate, potassium and sodium.",
   "So the patient develops severe dehydration, metabolic acidosis and hypokalaemia simultaneously.",
   "Dehydration beyond ten per cent means hypovolaemic shock and a true emergency.",
   "The chosen fluid must do three things: restore volume, replace base and supply potassium.",
   "Ringer's lactate does exactly that; its lactate is converted to bicarbonate in the liver.",
   "The World Health Organization formally recommends Ringer's lactate for severe cholera.",
   "Normal saline restores volume but provides no base, and its chloride load adds hyperchloraemic acidosis.",
   "The volumes needed are enormous: sometimes thirty per cent of the deficit in the first half hour.",
   "Antibiotics such as doxycycline are adjunctive and shorten the diarrhoea; they do not replace fluids."
  ]
 },
 "explanation_fa": "در وبا بیمار فقط آب از دست نمی‌دهد؛ مدفوع وبایی سرشار از بی‌کربنات و پتاسیم است. به همین دلیل تابلوی کلاسیک، هم دهیدراتاسیون شدید است و هم اسیدوز متابولیک و هیپوکالمی. پس مایع انتخابی باید سه کار همزمان بکند: حجم را برگرداند، باز جایگزین کند و پتاسیم بدهد. رینگر لاکتات دقیقاً همین است — لاکتات آن در کبد به بی‌کربنات تبدیل می‌شود و اسیدوز را اصلاح می‌کند، و مقداری پتاسیم هم دارد. سازمان جهانی بهداشت هم رسماً همین را برای وبای شدید توصیه می‌کند. نرمال سالین حجم را برمی‌گرداند ولی هیچ بازی ندارد و با بار کلر بالا حتی می‌تواند اسیدوز هایپرکلرمیک اضافه کند. نیم‌سالین برای شوک هیپوولمیک بیش از حد هیپوتونیک است. دکستروز سالین هم کالری می‌دهد نه احیای حجم.",
 "explanation_en": "In cholera the patient does not simply lose water; the stool is rich in bicarbonate and potassium. That is why the classic picture combines severe dehydration with metabolic acidosis and hypokalaemia. The chosen fluid must therefore do three things at once: restore volume, replace base and supply potassium. Ringer's lactate does exactly that; its lactate is converted to bicarbonate in the liver, correcting the acidosis, and it contains some potassium. The World Health Organization officially recommends it for severe cholera. Normal saline restores volume but provides no base, and its high chloride load can even add a hyperchloraemic acidosis. Half-saline is far too hypotonic for hypovolaemic shock, and dextrose saline provides calories rather than volume resuscitation.",
 "why_fa": [
  "نیم‌نرمال سالین هیپوتونیک است و برای احیای حجم در شوک هیپوولمیک شدید مناسب نیست.",
  "نرمال سالین حجم را برمی‌گرداند اما هیچ بازی ندارد و بار کلر بالای آن می‌تواند اسیدوز را بدتر کند.",
  "دکستروز سالین برای تأمین کالری و آب آزاد است، نه برای احیای سریع حجم داخل عروقی.",
  "پاسخ صحیح — رینگر لاکتات همزمان حجم، باز و پتاسیم می‌دهد و توصیه‌ی رسمی WHO برای وبای شدید است."
 ],
 "why_en": [
  "Half-normal saline is hypotonic and unsuitable for volume resuscitation in severe hypovolaemic shock.",
  "Normal saline restores volume but supplies no base, and its chloride load can worsen the acidosis.",
  "Dextrose saline provides calories and free water rather than rapid intravascular volume replacement.",
  "Correct — Ringer's lactate supplies volume, base and potassium together and is the WHO recommendation for severe cholera."
 ],
 "golden_fa": "وبا = آب + بی‌کربنات + پتاسیم می‌رود. مایع انتخابی: رینگر لاکتات، حجم زیاد و سریع.",
 "golden_en": "Cholera loses water plus bicarbonate plus potassium. Fluid of choice: Ringer's lactate, large volume, fast.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 168: Cholera and Other Vibrioses"]
}

L["1400-12:124"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "از ۲۰۰۷ پرولاپس میترال از فهرست پروفیلاکسی اندوکاردیت حذف شد. فقط چهار گروه پرخطر باقی مانده‌اند.",
  "lead_en": "Since 2007 mitral valve prolapse is off the endocarditis prophylaxis list. Only four high-risk groups remain.",
  "points_fa": [
   "تا سال ۲۰۰۷ برای طیف وسیعی از بیماری‌های دریچه‌ای پروفیلاکسی اندوکاردیت داده می‌شد.",
   "انجمن قلب آمریکا آن سال اندیکاسیون‌ها را به‌شدت محدود کرد و پرولاپس میترال حذف شد.",
   "منطق تغییر ساده بود: باکتریمی گذرا هر روز با مسواک زدن و جویدن هم اتفاق می‌افتد.",
   "پس سهم یک پروسیجر دندانی از کل بار باکتریمی سالانه ناچیز است.",
   "در مقابل، آنتی‌بیوتیک بی‌دلیل هم عارضه‌ی دارویی دارد و هم به مقاومت میکروبی دامن می‌زند.",
   "امروز فقط چهار گروه پرخطر پروفیلاکسی می‌گیرند. گروه اول: دریچه‌ی مصنوعی یا مواد پروتزی در ترمیم دریچه.",
   "گروه دوم: سابقه‌ی اندوکاردیت عفونی قبلی.",
   "گروه سوم: بیماری مادرزادی قلبی سیانوتیک ترمیم‌نشده یا ناقص‌ترمیم‌شده.",
   "گروه چهارم: گیرنده‌ی پیوند قلب که والوپاتی پیدا کرده است.",
   "پروسیجرهای مشمول: دستکاری لثه یا ناحیه‌ی پری‌اپیکال دندان و سوراخ کردن مخاط دهان.",
   "رژیم استاندارد در صورت اندیکاسیون: آموکسی‌سیلین دو گرم تک‌دوز، سی تا شصت دقیقه قبل.",
   "در آلرژی به پنی‌سیلین: کلیندامایسین ششصد میلی‌گرم یا آزیترومایسین پانصد میلی‌گرم تک‌دوز.",
   "پروفیلاکسی چندروزه هیچ‌گاه توصیه نمی‌شود؛ همیشه تک‌دوز پیش از پروسیجر است."
  ],
  "points_en": [
   "Until 2007 endocarditis prophylaxis was given for a wide range of valvular conditions.",
   "That year the American Heart Association sharply narrowed the indications and mitral valve prolapse was dropped.",
   "The reasoning was simple: transient bacteraemia occurs daily with tooth-brushing and chewing.",
   "So a single dental procedure contributes negligibly to the annual bacteraemia burden.",
   "Meanwhile needless antibiotics carry adverse effects and drive antimicrobial resistance.",
   "Today only four high-risk groups receive prophylaxis. First: a prosthetic valve or prosthetic material used in valve repair.",
   "Second: a history of previous infective endocarditis.",
   "Third: unrepaired or incompletely repaired cyanotic congenital heart disease.",
   "Fourth: heart transplant recipients who have developed valvulopathy.",
   "Covered procedures involve manipulating the gingiva or periapical region of teeth, or perforating the oral mucosa.",
   "When indicated the standard regimen is amoxicillin two grams as a single dose, thirty to sixty minutes before.",
   "For penicillin allergy: clindamycin six hundred milligrams or azithromycin five hundred milligrams as a single dose.",
   "Multi-day prophylaxis is never recommended; it is always a single dose before the procedure."
  ]
 },
 "explanation_fa": "دام این سؤال، دام تاریخی است: تا سال ۲۰۰۷ برای پرولاپس دریچه‌ی میترال پروفیلاکسی می‌دادند، ولی انجمن قلب آمریکا آن سال اندیکاسیون‌ها را به‌شدت محدود کرد و پرولاپس میترال از فهرست حذف شد. منطقش هم روشن است: باکتریمی گذرا هر روز با مسواک زدن و جویدن اتفاق می‌افتد، پس سهم یک پروسیجر دندانی در کل بار باکتریمی ناچیز است؛ در مقابل، آنتی‌بیوتیک بی‌دلیل هم عارضه دارد و هم مقاومت می‌سازد. امروز پروفیلاکسی فقط برای چهار گروه پرخطر است: دریچه‌ی مصنوعی، سابقه‌ی اندوکاردیت قبلی، بیماری مادرزادی قلبی سیانوتیک ترمیم‌نشده، و گیرنده‌ی پیوند قلب با والوپاتی. این خانم در هیچ‌کدام نمی‌گنجد. برای یادآوری: اگر اندیکاسیون داشت، رژیم صحیح آموکسی‌سیلین دو گرم تک‌دوز بود، پس گزینه‌ی سه حتی از نظر دوز و طول دوره هم غلط است.",
 "explanation_en": "The trap here is historical: until 2007 mitral valve prolapse did receive endocarditis prophylaxis, but that year the American Heart Association sharply narrowed the indications and dropped it. The logic is clear: transient bacteraemia happens every day with tooth-brushing and chewing, so one dental procedure contributes very little to the total burden, while unnecessary antibiotics carry both adverse effects and resistance. Today prophylaxis is limited to four high-risk groups: a prosthetic valve, previous endocarditis, unrepaired cyanotic congenital heart disease, and a heart transplant recipient with valvulopathy. This woman fits none of them. As a reminder, had she been eligible the correct regimen would have been a single two-gram dose of amoxicillin, so option three is also wrong in both dose and duration.",
 "why_fa": [
  "آزیترومایسین فقط جایگزین در آلرژی به پنی‌سیلین است و در هر حال این بیمار اصلاً اندیکاسیون پروفیلاکسی ندارد.",
  "کلیندامایسین هم جایگزین در آلرژی است؛ ضمن اینکه امروزه به‌دلیل خطر کولیت کلستریدیوم دیفیسیل کمتر ترجیح داده می‌شود.",
  "این گزینه دو خطا دارد: دوز صحیح دو گرم است نه پانصد میلی‌گرم، و پروفیلاکسی همیشه تک‌دوز است نه پنج‌روزه.",
  "پاسخ صحیح — پرولاپس دریچه میترال از سال ۲۰۰۷ از فهرست اندیکاسیون‌های پروفیلاکسی حذف شده است."
 ],
 "why_en": [
  "Azithromycin is only an alternative for penicillin allergy, and in any case this patient has no indication at all.",
  "Clindamycin is likewise an allergy alternative, and is now less favoured because of Clostridioides difficile colitis risk.",
  "This option is doubly wrong: the correct dose is two grams, not five hundred milligrams, and prophylaxis is always a single dose, not five days.",
  "Correct — mitral valve prolapse was removed from the prophylaxis indications in 2007."
 ],
 "golden_fa": "پروفیلاکسی اندوکاردیت فقط ۴ گروه: دریچه مصنوعی، اندوکاردیت قبلی، CHD سیانوتیک، پیوند قلب با والوپاتی. دوز: آموکسی‌سیلین ۲g تک‌دوز.",
 "golden_en": "Endocarditis prophylaxis for four groups only: prosthetic valve, prior endocarditis, cyanotic CHD, transplant valvulopathy. Dose: amoxicillin 2 g single.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 128: Infective Endocarditis"]
}

L["1400-12:125"] = {
 "style": "recall", "difficulty": "easy",
 "micro": {
  "lead_fa": "سه عامل مننژیت نوزادی: استرپتوکوک گروه B (= اگالاکتیه)، اشریشیا کلی و لیستریا. پنوموکوک در نوزاد نادر است.",
  "lead_en": "Three neonatal meningitis pathogens: group B streptococcus (= agalactiae), E. coli and Listeria. Pneumococcus is rare in neonates.",
  "points_fa": [
   "عامل مننژیت باکتریال به‌شدت به سن بیمار وابسته است و همین پایه‌ی درمان تجربی است.",
   "در نوزاد زیر یک ماه، سه عامل کلاسیک وجود دارد که همه از مادر منتقل می‌شوند.",
   "عامل اول استرپتوکوک گروه B است که نام علمی‌اش استرپتوکوکوس اگالاکتیه می‌باشد.",
   "این دو نام یک باکتری هستند و در گزینه‌های سؤال به‌عمد جداگانه آورده شده‌اند.",
   "عامل دوم اشریشیا کلی به‌ویژه سویه‌ی K1 و عامل سوم لیستریا مونوسیتوژنز است.",
   "این باکتری‌ها حین عبور از کانال زایمان یا از فلور روده‌ای مادر منتقل می‌شوند.",
   "علائم در نوزاد غیراختصاصی است: اختلال تغذیه، بی‌قراری یا خواب‌آلودگی، بی‌ثباتی دما.",
   "سفتی گردن در نوزاد معمولاً وجود ندارد، پس فقدان آن هرگز مننژیت را رد نمی‌کند.",
   "برجستگی فونتانل قدامی یافته‌ای دیرهنگام اما مهم است.",
   "درمان تجربی نوزاد آمپی‌سیلین به‌علاوه‌ی سفوتاکسیم یا جنتامایسین است.",
   "آمپی‌سیلین دقیقاً برای پوشش لیستریا اضافه می‌شود که به سفالوسپورین‌ها ذاتاً مقاوم است.",
   "استرپتوکوک پنومونیه شایع‌ترین علت مننژیت در کودکان بزرگ‌تر و بالغین است، نه نوزاد.",
   "دلیلش این است که نوزاد هنوز کلونیزاسیون نازوفارنکس با پنوموکوک را پیدا نکرده است."
  ],
  "points_en": [
   "The organism causing bacterial meningitis depends heavily on age, and that underpins empirical therapy.",
   "In neonates under one month there are three classic pathogens, all acquired from the mother.",
   "The first is group B streptococcus, whose scientific name is Streptococcus agalactiae.",
   "These two names denote one organism and appear deliberately as separate options in this question.",
   "The second is Escherichia coli, especially the K1 strain, and the third is Listeria monocytogenes.",
   "These organisms are transmitted during passage through the birth canal or from the maternal gut flora.",
   "Neonatal signs are non-specific: poor feeding, irritability or drowsiness, temperature instability.",
   "Neck stiffness is usually absent in a neonate, so its absence never excludes meningitis.",
   "A bulging anterior fontanelle is a late but important finding.",
   "Empirical neonatal therapy is ampicillin plus cefotaxime or gentamicin.",
   "Ampicillin is added precisely to cover Listeria, which is intrinsically resistant to cephalosporins.",
   "Streptococcus pneumoniae is the commonest cause in older children and adults, not in neonates.",
   "The reason is that neonates have not yet acquired nasopharyngeal colonisation with pneumococcus."
  ]
 },
 "explanation_fa": "سه عامل کلاسیک مننژیت نوزادی را حفظ کنید: استرپتوکوک گروه B، اشریشیا کلی و لیستریا مونوسیتوژنز. هر سه از مادر در حین زایمان یا از فلور روده‌ای منتقل می‌شوند. حالا به گزینه‌ها نگاه کنید و یک تله ببینید: «استرپتوکوک گروه B» و «استرپتوکوکوس اگالاکتیه» دو نامِ یک باکتری‌اند! پس گزینه‌های یک و سه عملاً یکی هستند و هیچ‌کدام نمی‌توانند پاسخ باشند، چون اگر یکی پاسخ بود، دیگری هم بود. همین تشخیصِ ساده سؤال را تمام می‌کند. لیستریا هم که عامل شناخته‌شده‌ی نوزادی است. می‌ماند استرپتوکوک پنومونیه، که پاسخ است: پنوموکوک شایع‌ترین علت مننژیت باکتریال در کودکان بزرگ‌تر و بالغین است، اما در نوزاد کمتر از یک ماه به‌ندرت دیده می‌شود چون نوزاد هنوز کلونیزاسیون نازوفارنکس با پنوموکوک را پیدا نکرده است.",
 "explanation_en": "Memorise the three classic neonatal meningitis pathogens: group B streptococcus, Escherichia coli and Listeria monocytogenes, all acquired from the mother during delivery or from her gut flora. Now look at the options and spot a trap: group B streptococcus and Streptococcus agalactiae are two names for the same organism. Options one and three are therefore identical, and neither can be the answer, because if one were correct so would the other be. That single observation settles the question. Listeria is also a recognised neonatal pathogen. That leaves Streptococcus pneumoniae, which is the answer: pneumococcus is the commonest cause of bacterial meningitis in older children and adults, but it is rare under one month of age because the neonate has not yet acquired nasopharyngeal pneumococcal colonisation.",
 "why_fa": [
  "استرپتوکوک گروه B شایع‌ترین عامل مننژیت نوزادی است و کاملاً مورد انتظار محسوب می‌شود.",
  "پاسخ صحیح — پنوموکوک عامل شایع مننژیت در کودکان بزرگ‌تر و بالغین است، ولی در نوزاد زیر یک ماه نادر می‌باشد.",
  "استرپتوکوکوس اگالاکتیه دقیقاً همان استرپتوکوک گروه B است؛ دو نام برای یک باکتری و کاملاً مورد انتظار.",
  "لیستریا مونوسیتوژنز یکی از سه عامل کلاسیک نوزادی است و به همین دلیل آمپی‌سیلین در درمان تجربی گنجانده می‌شود."
 ],
 "why_en": [
  "Group B streptococcus is the commonest cause of neonatal meningitis and is entirely expected.",
  "Correct — pneumococcus is a common cause in older children and adults but is rare under one month of age.",
  "Streptococcus agalactiae is exactly group B streptococcus; two names for one organism, and fully expected.",
  "Listeria monocytogenes is one of the three classic neonatal pathogens, which is why ampicillin is included empirically."
 ],
 "golden_fa": "نوزاد: GBS (= اگالاکتیه) + E. coli + لیستریا. درمان: آمپی‌سیلین + سفوتاکسیم. پنوموکوک = بزرگ‌تر.",
 "golden_en": "Neonate: GBS (= agalactiae) plus E. coli plus Listeria. Treat with ampicillin plus cefotaxime. Pneumococcus is for older ages.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 133: Acute Bacterial Meningitis"]
}

L["1400-12:126"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "سفر گرمسیری + خارش پای برهنه + آنمی فقر آهن + ائوزینوفیلی = کرم قلابدار. درمان: مبندازول.",
  "lead_en": "Tropical travel plus itchy bare feet plus iron-deficiency anaemia plus eosinophilia equals hookworm. Treat with mebendazole.",
  "points_fa": [
   "کرم قلابدار شامل دو گونه است: آنکیلوستوما دئودناله و نکاتور آمریکانوس.",
   "لارو فیلاریفرم در خاک مرطوب گرمسیری زندگی می‌کند و از پوست برهنه‌ی پا وارد می‌شود.",
   "محل ورود خارش و راش موضعی می‌دهد که به آن ground itch گفته می‌شود.",
   "لارو سپس از راه خون به ریه می‌رود، بالا می‌آید، بلعیده می‌شود و به روده‌ی باریک می‌رسد.",
   "کرم بالغ با دندان یا صفحه‌ی برنده به مخاط می‌چسبد و روزانه خون می‌مکد.",
   "هر کرم آنکیلوستوما روزانه حدود صد و پنجاه میکرولیتر خون می‌برد.",
   "بار انگلی سنگین و مزمن، آنمی میکروسیتیک هیپوکروم یعنی فقر آهن ایجاد می‌کند.",
   "همراه با خون، پروتئین هم از دست می‌رود و هیپوآلبومینمی و گاهی ادم ایجاد می‌شود.",
   "ائوزینوفیلی پاسخ استاندارد ایمنی به انگل بافتی است و در فاز مهاجرت بیشتر می‌شود.",
   "تشخیص با یافتن تخم مشخص کرم قلابدار در اسمیر مدفوع انجام می‌شود.",
   "درمان با بنزیمیدازول‌ها است: مبندازول یا آلبندازول که پلیمریزاسیون توبولین انگل را مختل می‌کنند.",
   "جایگزینی آهن خوراکی همزمان ضروری است، چون ذخایر آهن معمولاً کاملاً تخلیه شده‌اند.",
   "کرم قلابدار شایع‌ترین علت انگلی آنمی فقر آهن در جهان است."
  ],
  "points_en": [
   "Hookworm comprises two species: Ancylostoma duodenale and Necator americanus.",
   "The filariform larva lives in warm moist soil and penetrates the bare skin of the foot.",
   "The entry site itches and develops a local rash known as ground itch.",
   "The larva then travels by blood to the lung, ascends, is swallowed and reaches the small intestine.",
   "The adult worm attaches to the mucosa with teeth or cutting plates and sucks blood daily.",
   "Each Ancylostoma worm removes roughly one hundred and fifty microlitres of blood a day.",
   "A heavy chronic worm burden produces microcytic hypochromic, that is iron-deficiency, anaemia.",
   "Protein is lost along with the blood, producing hypoalbuminaemia and sometimes oedema.",
   "Eosinophilia is the standard immune response to a tissue helminth and peaks in the migratory phase.",
   "Diagnosis is by finding the characteristic hookworm eggs on stool smear.",
   "Treatment is with benzimidazoles: mebendazole or albendazole, which disrupt parasite tubulin polymerisation.",
   "Concurrent oral iron replacement is essential because iron stores are usually completely depleted.",
   "Hookworm is the commonest parasitic cause of iron-deficiency anaemia worldwide."
  ]
 },
 "explanation_fa": "چهار سرنخ را دنبال کنید و تشخیص خودش را نشان می‌دهد: سفر به منطقه‌ی گرمسیری، خارش پوست ساق پا که محل ورود لارو از طریق پوست برهنه است، کم‌خونی فقر آهن یعنی میکروسیتیک-هیپوکروم، و ائوزینوفیلی. این تابلوی کرم قلابدار است. کرم بالغ به مخاط روده‌ی باریک می‌چسبد و روزانه خون می‌مکد؛ خون‌ریزی مزمن مخفی هم آهن می‌برد و هم پروتئین، و همین هیپوآلبومینمی را توضیح می‌دهد. ائوزینوفیلی هم پاسخ استاندارد بدن به انگل بافتی است. درمان، یک بنزیمیدازول است: مبندازول یا آلبندازول که پلیمریزاسیون توبولین انگل را مختل می‌کند، به‌علاوه‌ی جایگزینی آهن که فراموش نشود. مترونیدازول برای تک‌یاخته‌ها و بی‌هوازی‌هاست نه کرم؛ کلوتریمازول ضدقارچ موضعی است؛ و فلوتیکازون یک کورتیکواستروئید است که اینجا فقط ضرر می‌رساند.",
 "explanation_en": "Follow four clues and the diagnosis presents itself: travel to a tropical region, itching of the lower leg where the larva penetrated bare skin, iron-deficiency (microcytic hypochromic) anaemia, and eosinophilia. This is the hookworm picture. The adult worm attaches to the small-bowel mucosa and sucks blood daily; the chronic occult bleeding removes both iron and protein, which explains the hypoalbuminaemia, while eosinophilia is the standard response to a tissue helminth. Treatment is a benzimidazole, mebendazole or albendazole, which disrupts parasite tubulin polymerisation, plus iron replacement that must not be forgotten. Metronidazole targets protozoa and anaerobes, not worms; clotrimazole is a topical antifungal; and fluticasone is a corticosteroid that would only do harm here.",
 "why_fa": [
  "پاسخ صحیح — مبندازول یک بنزیمیدازول ضدکرم است و درمان استاندارد عفونت کرم قلابدار محسوب می‌شود.",
  "مترونیدازول برای تک‌یاخته‌ها مانند ژیاردیا و آمیب و برای باکتری‌های بی‌هوازی است، نه برای کرم‌ها.",
  "کلوتریمازول یک ضدقارچ موضعی است و هیچ اثری بر انگل‌های روده‌ای ندارد.",
  "فلوتیکازون کورتیکواستروئید استنشاقی است؛ در عفونت انگلی نه‌تنها بی‌فایده بلکه بالقوه خطرناک است."
 ],
 "why_en": [
  "Correct — mebendazole is an anthelminthic benzimidazole and the standard treatment for hookworm infection.",
  "Metronidazole targets protozoa such as Giardia and Entamoeba and anaerobic bacteria, not helminths.",
  "Clotrimazole is a topical antifungal with no effect on intestinal parasites.",
  "Fluticasone is an inhaled corticosteroid; in a parasitic infection it is not merely useless but potentially harmful."
 ],
 "golden_fa": "کرم قلابدار = شایع‌ترین علت انگلی آنمی فقر آهن. درمان: مبندازول/آلبندازول + آهن.",
 "golden_en": "Hookworm is the commonest parasitic cause of iron-deficiency anaemia. Treat with mebendazole or albendazole plus iron.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 223: Intestinal Nematodes"]
}

L["1400-12:127"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "آکواریوم + ندول بنفش تک روی دست + بیمار پایدار = مایکوباکتریوم مارینوم.",
  "lead_en": "Aquarium plus a single purple nodule on the hand plus a stable patient means Mycobacterium marinum.",
  "points_fa": [
   "مایکوباکتریوم مارینوم یک مایکوباکتریوم غیرتوبرکلوزی است که در آب شیرین و شور زندگی می‌کند.",
   "زمینه‌ی امضایی آن آکواریوم است؛ بیماری‌اش را گرانولوم آکواریوم یا گرانولوم شناگران می‌نامند.",
   "باکتری از یک خراش یا زخم کوچک روی دست وارد می‌شود.",
   "نکته‌ی زیستی کلیدی: این باکتری در دمای حدود سی درجه بهتر از دمای مرکزی بدن رشد می‌کند.",
   "به همین دلیل عفونت در اندام‌های سرد یعنی دست و ساعد باقی می‌ماند و منتشر نمی‌شود.",
   "ضایعه یک ندول اریتماتو یا بنفش، بی‌درد و کندرشد است و بیمار سیستمیک بیمار نیست.",
   "دوره‌ی کمون دو تا چهار هفته است و سیر بیماری آرام و مزمن می‌باشد.",
   "ائروموناس هیدروفیلا با آب شیرین و زالو مرتبط است و عفونت سریع و مهاجم می‌سازد.",
   "ویبریو ولنیفیکوس آب شور گرم و بیمار سیروتیک می‌خواهد و سلولیت برق‌آسا با بولای هموراژیک می‌دهد.",
   "ویبریو ولنیفیکوس می‌تواند ظرف چند ساعت به سپسیس و مرگ بینجامد؛ بیمار ما پایدار است.",
   "اسپوروتریکس شنکئی زمینه‌اش خاک و گل‌کاری و خار گل رز است.",
   "اسپوروتریکوز ضایعات را زنجیره‌وار در مسیر عروق لنفاوی بالا می‌برد، که در این بیمار نیست.",
   "تشخیص با کشت در دمای سی درجه و درمان با کلاریترومایسین یا داکسی‌سایکلین یا ریفامپین-اتامبوتول است."
  ],
  "points_en": [
   "Mycobacterium marinum is a non-tuberculous mycobacterium living in fresh and salt water.",
   "Its signature setting is the aquarium; the disease is called aquarium or swimming-pool granuloma.",
   "The organism enters through a small scratch or cut on the hand.",
   "A key biological point: it grows better at around thirty degrees than at core body temperature.",
   "That is why the infection stays in the cool extremities, the hand and forearm, and does not disseminate.",
   "The lesion is an erythematous or violaceous nodule, painless and slow-growing, in a systemically well patient.",
   "The incubation period is two to four weeks and the course is indolent and chronic.",
   "Aeromonas hydrophila is linked to fresh water and leeches and causes rapid invasive infection.",
   "Vibrio vulnificus needs warm salt water and a cirrhotic host and causes fulminant cellulitis with haemorrhagic bullae.",
   "Vibrio vulnificus can progress to sepsis and death within hours; our patient is stable.",
   "Sporothrix schenckii is associated with soil, gardening and rose thorns.",
   "Sporotrichosis characteristically ascends in a chain along the lymphatics, which is absent here.",
   "Diagnosis is by culture at thirty degrees; treatment is clarithromycin, doxycycline, or rifampin plus ethambutol."
  ]
 },
 "explanation_fa": "آکواریوم در صورت سؤال یک کلیدواژه‌ی امضایی است. مایکوباکتریوم مارینوم آن‌قدر با این زمینه گره خورده که بیماری‌اش را گرانولوم آکواریوم یا گرانولوم شناگران می‌نامند. باکتری از یک خراش کوچک روی دست وارد می‌شود و چون در دمای پایین‌تر از مرکز بدن بهتر رشد می‌کند، در اندام‌های سرد یعنی دست و ساعد می‌ماند و یک ندول بنفش-اریتماتوی بی‌درد و کندرشد می‌سازد. سه گزینه‌ی دیگر را با سرعت و شدت کنار بگذارید: ائروموناس و به‌ویژه ویبریو ولنیفیکوس عفونت‌های برق‌آسا و بسیار مهاجم می‌سازند با تب، سلولیت پیشرونده و بولای هموراژیک — نه یک ندول آرام سه‌روزه در بیمار پایدار، و ویبریو ولنیفیکوس هم آب شور و بیمار سیروتیک می‌خواهد نه آکواریوم خانگی. اسپوروتریکس هم زمینه‌اش خاک و خار گل رز است و مشخصاً ضایعات را زنجیره‌ای در مسیر لنفاوی بالا می‌برد، در حالی که سؤال صراحتاً می‌گوید ضایعه‌ی دیگری در بدن نیست.",
 "explanation_en": "The word aquarium in the stem is a signature keyword. Mycobacterium marinum is so tied to this setting that its disease is called aquarium or swimming-pool granuloma. The organism enters through a small scratch on the hand, and because it grows better below core temperature it stays in the cool extremities, producing a painless, slow-growing violaceous nodule. Rule out the other three by speed and severity: Aeromonas and especially Vibrio vulnificus cause fulminant, highly invasive infection with fever, spreading cellulitis and haemorrhagic bullae, not a quiet three-day nodule in a stable patient, and Vibrio vulnificus also requires salt water and a cirrhotic host rather than a home aquarium. Sporothrix is associated with soil and rose thorns and characteristically ascends the lymphatics in a chain, whereas the stem explicitly states there are no other lesions.",
 "why_fa": [
  "پاسخ صحیح — مایکوباکتریوم مارینوم عامل گرانولوم آکواریوم است و ندول بنفش تنها روی دست ایجاد می‌کند.",
  "ائروموناس هیدروفیلا عفونت سریع و مهاجم آب شیرین می‌دهد، نه یک ندول آرام و کندرشد در بیمار پایدار.",
  "ویبریو ولنیفیکوس نیازمند آب شور گرم و میزبان سیروتیک است و سلولیت برق‌آسا با بولای هموراژیک می‌سازد.",
  "اسپوروتریکس شنکئی زمینه‌ی خاک و گل‌کاری دارد و ضایعات را زنجیره‌وار در مسیر لنفاوی بالا می‌برد."
 ],
 "why_en": [
  "Correct — Mycobacterium marinum causes aquarium granuloma and produces a solitary violaceous nodule on the hand.",
  "Aeromonas hydrophila causes rapid invasive fresh-water infection, not a quiet slow nodule in a stable patient.",
  "Vibrio vulnificus requires warm salt water and a cirrhotic host and causes fulminant cellulitis with haemorrhagic bullae.",
  "Sporothrix schenckii is linked to soil and gardening and characteristically ascends the lymphatics in a chain."
 ],
 "golden_fa": "آکواریوم = M. marinum (ندول تک، آرام). خار گل رز = اسپوروتریکس (زنجیره لنفاوی). سیروز + آب شور = V. vulnificus (برق‌آسا).",
 "golden_en": "Aquarium means M. marinum (solitary, indolent). Rose thorn means Sporothrix (lymphatic chain). Cirrhosis plus salt water means V. vulnificus (fulminant).",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 122/181: Skin and Soft Tissue Infections; Nontuberculous Mycobacteria"]
}

L["1400-12:128"] = {
 "style": "recall", "difficulty": "easy",
 "micro": {
  "lead_fa": "اتامبوتول = نوریت اپتیک. هر داروی ضدسل یک عارضه‌ی امضایی دارد.",
  "lead_en": "Ethambutol equals optic neuritis. Each anti-TB drug has one signature toxicity.",
  "points_fa": [
   "رژیم استاندارد سل چهار دارو دارد و هر کدام یک عارضه‌ی شاخص و قابل‌شناسایی دارند.",
   "اتامبوتول عارضه‌ی امضایی نوریت اپتیک دارد که وابسته به دوز است.",
   "علائم آن کاهش حدت بینایی و از دست رفتن تمایز رنگ‌ها، به‌ویژه سبز و قرمز، است.",
   "اگر دارو زود قطع شود معمولاً برگشت‌پذیر است، اما تأخیر می‌تواند آسیب دائمی بگذارد.",
   "پس پیش از شروع درمان و سپس ماهانه باید حدت بینایی و دید رنگی سنجیده شود.",
   "در نارسایی کلیه باید دوز اتامبوتول تنظیم شود، چون تجمع دارو خطر را زیاد می‌کند.",
   "ایزونیازید نوروپاتی محیطی می‌دهد که از تداخل با متابولیسم پیریدوکسین ناشی می‌شود.",
   "این عارضه با تجویز همزمان ویتامین B6 قابل پیشگیری است.",
   "ایزونیازید همچنین هپاتیت دارویی می‌دهد که با افزایش سن شایع‌تر می‌شود.",
   "پیرازینامید هایپراوریسمی و درد مفاصل و هپاتوتوکسیسیته ایجاد می‌کند.",
   "ریفامپین رنگ نارنجی ادرار، اشک و عرق می‌دهد که بی‌خطر است ولی بیمار را می‌ترساند.",
   "ریفامپین القاکننده‌ی قوی سیتوکروم P450 است و اثر بسیاری از داروها را کم می‌کند.",
   "همین تداخل باعث شکست قرص ضدبارداری و کاهش سطح داروهای ضدرتروویروسی می‌شود."
  ],
  "points_en": [
   "The standard TB regimen has four drugs, each with one distinctive, recognisable toxicity.",
   "Ethambutol's signature adverse effect is optic neuritis, and it is dose-dependent.",
   "Its features are reduced visual acuity and loss of colour discrimination, especially green and red.",
   "It is usually reversible if the drug is stopped early, but delay can leave permanent damage.",
   "So visual acuity and colour vision must be tested before starting and monthly thereafter.",
   "In renal failure the ethambutol dose must be adjusted, because accumulation increases the risk.",
   "Isoniazid causes peripheral neuropathy through interference with pyridoxine metabolism.",
   "This is preventable by giving vitamin B6 alongside.",
   "Isoniazid also causes drug-induced hepatitis, which becomes more frequent with age.",
   "Pyrazinamide causes hyperuricaemia, joint pain and hepatotoxicity.",
   "Rifampin turns urine, tears and sweat orange, which is harmless but alarms patients.",
   "Rifampin is a potent cytochrome P450 inducer and reduces the effect of many drugs.",
   "That interaction causes oral contraceptive failure and lowers antiretroviral drug levels."
  ]
 },
 "explanation_fa": "هر یک از چهار داروی خط اول سل یک عارضه‌ی امضایی دارد و همین، سؤال را به یک بازی تطبیق ساده تبدیل می‌کند. اتامبوتول مساوی است با نوریت اپتیک؛ دقیقاً همان چیزی که این بیمار دارد: کاهش حدت بینایی و از دست رفتن تمایز رنگ‌ها، به‌ویژه سبز و قرمز. عارضه وابسته به دوز است و اگر زود دارو قطع شود معمولاً برگشت‌پذیر است، ولی اگر دیر بجنبید دائمی می‌شود — به همین دلیل قبل از شروع درمان و سپس ماهانه باید حدت بینایی و دید رنگی سنجیده شود. سه داروی دیگر: ایزونیازید نوروپاتی محیطی می‌دهد، به‌خاطر تداخل با پیریدوکسین که با ویتامین B6 پیشگیری می‌شود، و هپاتیت؛ پیرازینامید هایپراوریسمی و درد مفاصل و هپاتوتوکسیسیته؛ ریفامپین رنگ نارنجی ادرار و اشک و القای شدید سیتوکروم P450.",
 "explanation_en": "Each of the four first-line TB drugs has one signature toxicity, which turns this into a simple matching exercise. Ethambutol equals optic neuritis, exactly what this patient has: reduced visual acuity and loss of colour discrimination, especially green and red. The effect is dose-dependent and usually reversible if the drug is stopped early, but permanent if you act late, which is why visual acuity and colour vision must be checked before treatment and monthly thereafter. The other three: isoniazid causes peripheral neuropathy through pyridoxine interference, preventable with vitamin B6, and hepatitis; pyrazinamide causes hyperuricaemia, arthralgia and hepatotoxicity; rifampin turns secretions orange and strongly induces cytochrome P450.",
 "why_fa": [
  "پاسخ صحیح — اتامبوتول عامل نوریت اپتیک است و دقیقاً کاهش حدت بینایی و اختلال دید رنگی می‌دهد.",
  "ایزونیازید نوروپاتی محیطی و هپاتیت می‌دهد، نه اختلال بینایی؛ نوروپاتی آن با ویتامین B6 پیشگیری می‌شود.",
  "پیرازینامید هایپراوریسمی، درد مفاصل و هپاتوتوکسیسیته ایجاد می‌کند و عارضه‌ی چشمی ندارد.",
  "ریفامپین رنگ نارنجی ترشحات و القای سیتوکروم P450 می‌دهد؛ اثری بر عصب بینایی ندارد."
 ],
 "why_en": [
  "Correct — ethambutol causes optic neuritis, producing exactly this loss of visual acuity and colour vision.",
  "Isoniazid causes peripheral neuropathy and hepatitis, not visual loss; its neuropathy is prevented with vitamin B6.",
  "Pyrazinamide causes hyperuricaemia, arthralgia and hepatotoxicity and has no ocular toxicity.",
  "Rifampin turns secretions orange and induces cytochrome P450; it does not affect the optic nerve."
 ],
 "golden_fa": "E = چشم (اتامبوتول/نوریت اپتیک) • H = عصب و کبد • Z = اسیداوریک و کبد • R = نارنجی و P450.",
 "golden_en": "E is for eye (ethambutol, optic neuritis) • H nerve and liver • Z uric acid and liver • R orange and P450.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 178: Tuberculosis, drug toxicity"]
}

L["1400-12:129"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "CSF لنفوسیتی با قند طبیعی = ویروسی. تشنج = درگیری پارانشیم = انسفالیت. آسیکلوویر فوری.",
  "lead_en": "Lymphocytic CSF with normal glucose means viral. A seizure means parenchymal involvement, so encephalitis. Give acyclovir immediately.",
  "points_fa": [
   "تفسیر CSF را با سه عدد شروع کنید: نوع سلول غالب، قند و پروتئین.",
   "در مننژیت باکتریال نوتروفیل غالب است، قند پایین و پروتئین بسیار بالا می‌باشد.",
   "قند پایین یعنی مصرف قند توسط باکتری و نوتروفیل‌ها؛ نسبت قند CSF به سرم زیر چهل درصد.",
   "در مننژیت ویروسی لنفوسیت غالب است، قند طبیعی و پروتئین فقط کمی بالا می‌رود.",
   "در مننژیت سلی و قارچی لنفوسیت غالب است اما قند پایین و پروتئین بسیار بالاست.",
   "در این بیمار لنفوسیت هشتاد درصد، قند پنجاه و پروتئین هشتاد است، پس الگو ویروسی است.",
   "قدم دوم، تفکیک مننژیت از انسفالیت است و فقط یک چیز آن را تعیین می‌کند: درگیری پارانشیم.",
   "تب و سردرد و استفراغ در هر دو دیده می‌شود و کمکی به تفکیک نمی‌کند.",
   "تشنج، افت هوشیاری، تغییر رفتار و علائم کانونی یعنی پارانشیم مغز درگیر است، یعنی انسفالیت.",
   "شایع‌ترین علت قابل‌درمان انسفالیت اسپورادیک در بالغ، هرپس سیمپلکس تیپ یک است.",
   "HSV به‌طور مشخص لوب تمپورال را درگیر می‌کند؛ MRI و EEG همین ناحیه را نشان می‌دهند.",
   "PCR مایع مغزی نخاعی برای HSV حساسیت و ویژگی بسیار بالایی دارد.",
   "اما درمان با آسیکلوویر وریدی باید فوراً و پیش از آماده شدن PCR شروع شود.",
   "انسفالیت HSV درمان‌نشده مرگ‌ومیر بالای هفتاد درصد دارد و درمان زودهنگام آن را به‌شدت کم می‌کند."
  ],
  "points_en": [
   "Start CSF interpretation with three numbers: the predominant cell, the glucose and the protein.",
   "In bacterial meningitis neutrophils predominate, glucose is low and protein is markedly raised.",
   "Low glucose reflects consumption by bacteria and neutrophils; the CSF-to-serum ratio falls below forty per cent.",
   "In viral meningitis lymphocytes predominate, glucose is normal and protein is only mildly raised.",
   "In tuberculous and fungal meningitis lymphocytes predominate but glucose is low and protein very high.",
   "Here lymphocytes are eighty per cent, glucose fifty and protein eighty, so the pattern is viral.",
   "The second step is separating meningitis from encephalitis, decided by one thing only: parenchymal involvement.",
   "Fever, headache and vomiting occur in both and do not help the distinction.",
   "Seizures, reduced consciousness, behavioural change and focal signs mean the brain parenchyma is involved.",
   "The commonest treatable cause of sporadic encephalitis in adults is herpes simplex virus type 1.",
   "HSV characteristically involves the temporal lobe, and MRI and EEG localise to that region.",
   "CSF PCR for HSV has very high sensitivity and specificity.",
   "But intravenous acyclovir must be started immediately, before the PCR result arrives.",
   "Untreated HSV encephalitis has a mortality above seventy per cent, which early treatment greatly reduces."
  ]
 },
 "explanation_fa": "دو قدم بردارید. قدم اول، الگوی CSF: غالب بودن لنفوسیت با هشتاد درصد، قند طبیعی با پنجاه و پروتئین فقط کمی بالا با هشتاد — این پروفایل ویروسی است. مننژیت باکتریال قند پایین و نوتروفیل غالب می‌دهد و مننژیت قارچی مثل کریپتوکوک هم قند پایین و معمولاً زمینه‌ی نقص ایمنی می‌خواهد که این بیمار ندارد. پس گزینه‌های دو و سه حذف می‌شوند. قدم دوم، تفکیک مننژیت از انسفالیت — و اینجا فقط یک کلمه تعیین‌کننده است: تشنج. تب و سردرد و استفراغ در هر دو دیده می‌شود، اما تشنج یعنی پارانشیم مغز درگیر است، یعنی انسفالیت. پس تشخیص انسفالیت ویروسی است و در بالغ بدون زمینه، شایع‌ترین علت قابل‌درمانش HSV-1 است. اقدام فوری: آسیکلوویر وریدی را بدون معطلی شروع کنید و منتظر PCR نمانید؛ تأخیر در درمان HSV مستقیماً به مرگ یا آسیب دائمی مغز ترجمه می‌شود.",
 "explanation_en": "Take two steps. First, the CSF pattern: eighty per cent lymphocytes, a normal glucose of fifty and a protein of only eighty. That profile is viral. Bacterial meningitis gives a low glucose with neutrophil predominance, and fungal meningitis such as cryptococcal also lowers glucose and usually requires an immunocompromised host, which this patient is not. Options two and three are therefore out. Second, separate meningitis from encephalitis, and here a single word decides it: seizure. Fever, headache and vomiting occur in both, but a seizure means the brain parenchyma is involved, which is encephalitis. So the diagnosis is viral encephalitis, and in a previously well adult the commonest treatable cause is HSV-1. Act immediately: start intravenous acyclovir without waiting for PCR, because delay in HSV translates directly into death or permanent brain injury.",
 "why_fa": [
  "الگوی CSF واقعاً ویروسی است، اما تشنج نشان می‌دهد پارانشیم مغز هم درگیر شده و صرف مننژیت کافی نیست.",
  "مننژیت قارچی معمولاً قند CSF پایین دارد و زمینه‌ی نقص ایمنی می‌خواهد؛ این بیمار سابقه‌ی بیماری ندارد.",
  "مننژیت باکتریال با نوتروفیل غالب، قند پایین و پروتئین بسیار بالا مشخص می‌شود که هیچ‌کدام اینجا نیست.",
  "پاسخ صحیح — الگوی ویروسی CSF به‌علاوه‌ی تشنج یعنی انسفالیت ویروسی؛ آسیکلوویر وریدی فوری."
 ],
 "why_en": [
  "The CSF pattern is indeed viral, but the seizure shows the parenchyma is involved, so meningitis alone is insufficient.",
  "Fungal meningitis usually shows low CSF glucose and requires an immunocompromised host; this patient has no such history.",
  "Bacterial meningitis is defined by neutrophil predominance, low glucose and very high protein, none of which is present.",
  "Correct — a viral CSF pattern plus a seizure means viral encephalitis; start intravenous acyclovir at once."
 ],
 "golden_fa": "لنفوسیت + قند نرمال = ویروسی. تشنج = انسفالیت. HSV تا خلاف ثابت شود ← آسیکلوویر IV فوری.",
 "golden_en": "Lymphocytes plus normal glucose means viral. A seizure means encephalitis. Assume HSV and give IV acyclovir at once.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 133: Acute Meningitis and Encephalitis"]
}

L["1400-12:130"] = {
 "style": "case", "difficulty": "hard",
 "micro": {
  "lead_fa": "آرتریت راکتیو فقط با باکتری‌های گرم‌منفی مهاجم روده راه می‌افتد. آنتامبا تک‌یاخته است، نه محرک.",
  "lead_en": "Reactive arthritis is triggered only by invasive Gram-negative enteric bacteria. Entamoeba is a protozoan and is not a trigger.",
  "points_fa": [
   "آرتریت راکتیو یک آرتریت استریل است؛ خودِ میکروب در مفصل حضور ندارد.",
   "مکانیسم ایمونولوژیک است و در افراد با HLA-B27 مثبت به‌مراتب شایع‌تر رخ می‌دهد.",
   "فاصله‌ی زمانی تیپیک، دو تا چهار هفته پس از عفونت اولیه است.",
   "الگوی درگیری، الیگوآرتریت نامتقارن مفاصل بزرگ اندام تحتانی است، به‌ویژه زانو و مچ پا.",
   "درگیری ساکروایلیاک و کمردرد التهابی هم شایع است، مثل همین بیمار.",
   "سه‌گانه‌ی کلاسیک: آرتریت، اورتریت و کنژنکتیویت که سندرم رایتر نامیده می‌شد.",
   "یافته‌های دیگر: انتزیت به‌ویژه در تاندون آشیل، داکتیلیت و کراتودرما بلنوراژیکا.",
   "محرک‌های گوارشی همه باکتری گرم‌منفی مهاجم‌اند: شیگلا، سالمونلا، کمپیلوباکتر و یرسینیا.",
   "محرک ادراری-تناسلی اصلی، کلامیدیا تراکوماتیس است.",
   "این پنج عامل با هم فهرست کلاسیک محرک‌های آرتریت راکتیو را می‌سازند.",
   "آنتامبا هیستولیتیکا یک تک‌یاخته است، نه باکتری، و لیپوپلی‌ساکارید ندارد.",
   "آنتی‌ژن‌های آن با HLA-B27 تقلید مولکولی نمی‌کنند، پس محرک آرتریت راکتیو نیست.",
   "درمان با NSAID شروع می‌شود؛ در موارد مقاوم سولفاسالازین یا متوترکسات اضافه می‌شود.",
   "آنتی‌بیوتیک در فاز آرتریت کمکی نیست، چون عفونت فعالی در مفصل وجود ندارد."
  ],
  "points_en": [
   "Reactive arthritis is a sterile arthritis; the organism itself is not present in the joint.",
   "The mechanism is immunological and it occurs far more often in HLA-B27-positive individuals.",
   "The typical interval is two to four weeks after the initial infection.",
   "The pattern is an asymmetrical oligoarthritis of the large lower-limb joints, especially knee and ankle.",
   "Sacroiliac involvement with inflammatory back pain is also common, as in this patient.",
   "The classic triad is arthritis, urethritis and conjunctivitis, formerly called Reiter syndrome.",
   "Other features include enthesitis, especially of the Achilles tendon, dactylitis and keratoderma blennorrhagicum.",
   "The enteric triggers are all invasive Gram-negative bacteria: Shigella, Salmonella, Campylobacter and Yersinia.",
   "The main genitourinary trigger is Chlamydia trachomatis.",
   "Together these five make up the classic list of reactive arthritis triggers.",
   "Entamoeba histolytica is a protozoan, not a bacterium, and has no lipopolysaccharide.",
   "Its antigens do not molecularly mimic HLA-B27, so it is not a reactive arthritis trigger.",
   "Treatment starts with NSAIDs; sulfasalazine or methotrexate is added in resistant cases.",
   "Antibiotics do not help in the arthritis phase because there is no active joint infection."
  ]
 },
 "explanation_fa": "تشخیص، آرتریت راکتیو است: التهاب مفاصل بزرگ اندام تحتانی به‌علاوه‌ی درگیری ساکروایلیاک یعنی کمردرد و درد لگنی، که دو تا چهار هفته پس از یک عفونت روده‌ای یا ادراری-تناسلی ظاهر می‌شود. نکته این است که خودِ باکتری در مفصل نیست؛ ماجرا ایمونولوژیک است و در افراد HLA-B27 مثبت رخ می‌دهد. و اینجاست که کلید سؤال پیدا می‌شود: فقط باکتری‌های گرم‌منفی مهاجم دستگاه گوارش این واکنش را راه می‌اندازند — شیگلا، سالمونلا، کمپیلوباکتر و یرسینیا، که با کلامیدیا تراکوماتیس مجموعاً پنج عامل کلاسیک را می‌سازند. آنتامبا هیستولیتیکا یک تک‌یاخته است، نه باکتری؛ لیپوپلی‌ساکارید و آنتی‌ژن‌های تقلیدکننده‌ی HLA-B27 را ندارد و در فهرست محرک‌های آرتریت راکتیو نیست. پس همان گزینه‌ای است که نمی‌تواند عامل باشد.",
 "explanation_en": "The diagnosis is reactive arthritis: inflammation of the large lower-limb joints plus sacroiliac involvement with back and pelvic pain, appearing two to four weeks after an enteric or genitourinary infection. The point is that the organism itself is not in the joint; the process is immunological and occurs in HLA-B27-positive people. And that is where the key lies: only invasive Gram-negative enteric bacteria trigger this reaction, namely Shigella, Salmonella, Campylobacter and Yersinia, which together with Chlamydia trachomatis make the classic five. Entamoeba histolytica is a protozoan, not a bacterium; it lacks lipopolysaccharide and antigens that mimic HLA-B27, and it is not on the list of reactive arthritis triggers. So it is precisely the one that could not be responsible.",
 "why_fa": [
  "کمپیلوباکتر ژژونی یکی از چهار محرک گوارشی کلاسیک آرتریت راکتیو است و کاملاً می‌تواند عامل باشد.",
  "پاسخ صحیح — آنتامبا هیستولیتیکا یک تک‌یاخته است و در فهرست محرک‌های آرتریت راکتیو جایی ندارد.",
  "شیگلا دیسانتری تیپ یک از شناخته‌شده‌ترین محرک‌های آرتریت راکتیو پس از دیسانتری است.",
  "سالمونلا هم یکی از چهار باکتری گرم‌منفی مهاجم گوارشی است که آرتریت راکتیو راه می‌اندازد."
 ],
 "why_en": [
  "Campylobacter jejuni is one of the four classic enteric triggers of reactive arthritis and could certainly be responsible.",
  "Correct — Entamoeba histolytica is a protozoan and has no place on the list of reactive arthritis triggers.",
  "Shigella dysenteriae type 1 is among the best-known triggers of reactive arthritis after dysentery.",
  "Salmonella is another of the four invasive Gram-negative enteric bacteria that trigger reactive arthritis."
 ],
 "golden_fa": "محرک‌های آرتریت راکتیو: شیگلا، سالمونلا، کمپیلوباکتر، یرسینیا، کلامیدیا. همه باکتری — نه انگل.",
 "golden_en": "Reactive arthritis triggers: Shigella, Salmonella, Campylobacter, Yersinia, Chlamydia. All bacteria, never parasites.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 355: Reactive Arthritis"]
}

json.dump(L, io.open('/home/user/work/infectious/lessons/L4.json', 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('infectious L4:', len(L))
