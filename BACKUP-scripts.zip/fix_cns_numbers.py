# -*- coding: utf-8 -*-
"""Repair the damaged numbers of the central nervous system chapter.

Method — unchanged from the seven previous chapters
---------------------------------------------------
pdfplumber gives the x-coordinate of every glyph, and a number is drawn left to
right even inside right-to-left script. Sorting a line's glyphs by x0 and
reading the digit runs recovers exactly the values the typesetter placed on the
page; the extracted text keeps the LOGICAL order, and that is where a value
gets mirrored.

  kind='reorder'  the digits the page printed, put back in printed order
  kind='restore'  a digit the extraction DROPPED, put back; a stronger claim,
                  so main() holds it to a stronger assertion

Why the numbers of THIS chapter matter more than any other
----------------------------------------------------------
In meningitis, THE CSF PANEL IS THE DIAGNOSIS. Every question in the middle of
this chapter shows a white cell count, a differential, a glucose and a protein,
and asks which organism it is. The rule the student is being taught is:

    BACTERIAL   hundreds to thousands of cells, NEUTROPHIL predominant,
                LOW glucose (CSF:serum ratio below 0.4), HIGH protein
    VIRAL       tens to hundreds, LYMPHOCYTE predominant,
                NORMAL glucose, mildly raised protein
    TUBERCULOUS/FUNGAL  tens to hundreds, LYMPHOCYTE predominant,
                LOW glucose, VERY HIGH protein

So a mirrored glucose does not merely look odd — IT MOVES THE PATIENT BETWEEN
BACTERIAL AND VIRAL AND INVERTS THE ANSWER. Three of the repairs below are
exactly that:

  q9156  glucose stored as "2 mg/dl" where page 61 prints 20, and protein
         stored as "21" where the page prints 120. A CSF glucose of 2 with a
         protein of 21 is an impossible combination — profoundly low sugar with
         a normal protein — and it destroys the pattern the question teaches.
  q9173  the same defect in the same shape: glucose "2" for 20, protein "9"
         for 90 (page 68). Both are restores, not reorderings.
  q9172  the temperature "C38" is fine, but page 67 prints the glucose as 83
         and the extraction had it right; what was mirrored is the fever in
         the stem of a NEIGHBOURING question. Checked and left alone — see the
         note at the foot of this docstring.

A note on q9134, which belongs to another disease
-------------------------------------------------
q9134 is the typhoid question whose printed key was corrected long ago
(perforation, not meningitis). Its vital signs were still mirrored: page 52
prints a temperature of 40 and a pulse of 84, and the extraction had "04" and
"48". The pulse matters here for a specific reason worth teaching: 84 with a
fever of 40 is RELATIVE BRADYCARDIA — Faget's sign — which is one of the
classical clues of typhoid. Mirrored to 48 it becomes an absolute bradycardia
that suggests something else entirely.

A defect the first scan missed, and why
---------------------------------------
The automated scan compares each stored number against the digit RUNS of the
matched page, and accepts a number if that run appears anywhere on the page.
q9172's glucose was stored as 83 and the page does contain the run "83" — so
the scan passed it. But the 83 it found belongs to a DIFFERENT question's
serum value; in q9172's own panel the page prints 38. The error surfaced only
because the page-number assertion above forced a manual look at page 68.

This matters clinically, which is why it is recorded rather than quietly
fixed: a CSF glucose of 83 is NORMAL and points to viral meningitis, while 38
alongside 62% neutrophils is BACTERIAL. The stored value had inverted the
answer to a treatment question.

The lesson for the method: PAGE-LEVEL DIGIT MATCHING IS NECESSARY BUT NOT
SUFFICIENT. A run present somewhere on the page is weak evidence when the page
holds three questions and a dozen laboratory values.

Numbers checked and found ALREADY CORRECT (recorded rather than silently
dropped): q9172's protein 88 (page 68 prints it); q9154's panel; q9157's
panel; q9159's panel.
"""
import json, io, os, re, collections

import pdfplumber

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = '/home/user/uploads/بیماری عفونی.pdf'

# question_no -> [(page, old, new, expected_printed_run, kind, why_fa), ...]
FIXES = {
    9134: [
        (52, 'c̊ 04 نبض 48', '40 °C نبض 84', '84', 'reorder',
         'تب و نبض: صفحه ۵۲ رقم‌ها را تب ۴۰ و نبض ۸۴ چاپ کرده است. این تصحیح '
         'آموزشی است: نبض ۸۴ با تب ۴۰ درجه یعنی **برادی‌کاردی نسبی (علامت فاژه)**، '
         'که یکی از سرنخ‌های کلاسیک تیفوئید است. با «نبض ۴۸» این یک برادی‌کاردی '
         'مطلق می‌شد که تشخیص دیگری را مطرح می‌کند.'),
    ],
    9156: [
        (61, '2 mg/dl:Glu', 'Glu: 20 mg/dl', '20', 'restore',
         'قند مایع نخاع: صفحه ۶۱ رقم‌ها را ۲۰ چاپ کرده و **رقم صفر در استخراج '
         'افتاده بود**. این عدد تعیین‌کننده است، چون **قند پایین CSF همان چیزی است '
         'که مننژیت باکتریال را از ویروسی جدا می‌کند**.'),
        (61, '21 mg/dl:PRO', 'PRO: 120 mg/dl', '120', 'restore',
         'پروتئین مایع نخاع: صفحه ۶۱ رقم‌ها را ۱۲۰ چاپ کرده و **رقم یک در استخراج '
         'افتاده بود**. «قند ۲ با پروتئین ۲۱» ترکیبی است که در هیچ مننژیتی دیده '
         'نمی‌شود.'),
    ],
    9158: [
        (62, '23 mg/dl=Glu', 'Glu=32 mg/dl', '32', 'reorder',
         'قند مایع نخاع: صفحه ۶۲ رقم‌ها را ۳۲ چاپ کرده است.'),
        (62, '51 mg/dl=protein', 'protein=150 mg/dl', '150', 'restore',
         'پروتئین مایع نخاع: صفحه ۶۲ رقم‌ها را ۱۵۰ چاپ کرده و رقم یک افتاده بود.'),
    ],
    9161: [
        (63, 'پلئوسیتوز mm043', 'پلئوسیتوز 340 در میلی‌متر مکعب', '340', 'reorder',
         'شمارش سلولی: صفحه ۶۳ رقم‌ها را ۳۴۰ چاپ کرده است.'),
    ],
    9163: [
        (64, 'pro=09', 'pro=90', '90', 'reorder',
         'پروتئین مایع نخاع: صفحه ۶۴ رقم‌ها را ۹۰ چاپ کرده است.'),
        (64, 'RBC=001', 'RBC=100', '100', 'reorder',
         'شمارش گلبول قرمز مایع نخاع: صفحه ۶۴ رقم‌ها را ۱۰۰ چاپ کرده است. این '
         'عدد در انسفالیت هرپسی مهم است، چون **وجود گلبول قرمز در CSF بدون '
         'تروما، به نفع نکروز خونریزی‌دهنده‌ی لوب تمپورال است**.'),
    ],
    9168: [
        (66, 'قند، mg04', 'قند 40 mg/dl', '40', 'reorder',
         'قند مایع نخاع: صفحه ۶۶ رقم‌ها را ۴۰ چاپ کرده است.'),
        (66, 'پروتئین mg06', 'پروتئین 60 mg/dl', '60', 'reorder',
         'پروتئین مایع نخاع: صفحه ۶۶ رقم‌ها را ۶۰ چاپ کرده است.'),
    ],
    9172: [
        # Page 68, not 67: the question starts at the foot of page 67 and its
        # laboratory panel spills onto the next page. The assertion caught the
        # wrong page number before anything was written.
        (68, 'C38=T', 'T=38 °C', '38', 'reorder',
         'درجه حرارت: صفحه ۶۸ رقم‌ها را ۳۸ چاپ کرده است؛ در استخراج واحد به عدد '
         'چسبیده و «C38» ساخته بود.'),
        # Found only while checking the page number above. The first scan had
        # accepted "83" because the page really does print the digit run 83 —
        # but it prints it as the SERUM value of another question. In THIS
        # question's panel the page prints 38, and the extraction mirrored it.
        (68, '83 mg/Dl = Glucose', 'Glucose = 38 mg/Dl', '38', 'reorder',
         'قند مایع نخاع: صفحه ۶۸ رقم‌ها را ۳۸ چاپ کرده است. این تصحیح تعیین‌کننده '
         'است: با قند ۸۳ (که طبیعی است) تابلو به مننژیت ویروسی می‌خورد، ولی با '
         'قند ۳۸ در کنار ۶۲ درصد نوتروفیل، تشخیص **مننژیت باکتریال** و پاسخ '
         '«سفتریاکسون + وانکومایسین» منطقی می‌شود.'),
    ],
    9173: [
        (68, '9 mg/dl:Pro', 'Pro: 90 mg/dl', '90', 'restore',
         'پروتئین مایع نخاع: صفحه ۶۸ رقم‌ها را ۹۰ چاپ کرده و **رقم صفر در استخراج '
         'افتاده بود**.'),
        (68, '2 mg/dl:Glu', 'Glu: 20 mg/dl', '20', 'restore',
         'قند مایع نخاع: صفحه ۶۸ رقم‌ها را ۲۰ چاپ کرده و **رقم صفر در استخراج '
         'افتاده بود**. مثل q9156، «قند ۲ با پروتئین ۹» الگویی است که در هیچ '
         'مننژیتی وجود ندارد و تشخیص را ناممکن می‌کند.'),
    ],
    9174: [
        (69, 'پروتئین 51 mg/dl', 'پروتئین 150 mg/dl', '150', 'restore',
         'پروتئین مایع نخاع: صفحه ۶۹ رقم‌ها را ۱۵۰ چاپ کرده و رقم یک افتاده بود.'),
    ],
    9179: [
        (71, 'PMN %08', 'PMN 80%', '80', 'reorder',
         'درصد نوتروفیل: صفحه ۷۱ رقم‌ها را ۸۰ چاپ کرده است.'),
    ],
    9181: [
        (71, '%82:PMN 0031', 'PMN: 82%، WBC: 1300', '1300', 'reorder',
         'شمارش سلولی: صفحه ۷۱ رقم‌ها را ۱۳۰۰ چاپ کرده است؛ در استخراج، عدد به '
         'درصد نوتروفیل چسبیده و «۰۰۳۱» ساخته بود.'),
    ],
    9182: [
        (72, 'PMN %57', 'PMN 75%', '75', 'reorder',
         'درصد نوتروفیل: صفحه ۷۲ رقم‌ها را ۷۵ چاپ کرده است.'),
    ],
}

FOLD = {}
for _i in range(10):
    FOLD[chr(0x0660 + _i)] = str(_i)   # Arabic-Indic
    FOLD[chr(0x06F0 + _i)] = str(_i)   # Persian


def page_digit_runs(pdf, pno):
    """Digit runs of a page in PRINTED (x-ascending) order."""
    page = pdf.pages[pno - 1]
    rows = collections.defaultdict(list)
    for c in page.chars:
        rows[round(c['top'])].append(c)
    runs = []
    for top in sorted(rows):
        cs = sorted(rows[top], key=lambda c: c['x0'])
        cur = ''
        for c in cs:
            t = FOLD.get(c['text'], c['text'])
            # a space must NOT close an open run: kerning sometimes splits a
            # number, and closing on the space invents two numbers out of one
            if t.isspace() and cur:
                continue
            if t.isdigit():
                cur += t
            else:
                if cur:
                    runs.append(cur)
                cur = ''
        if cur:
            runs.append(cur)
    return runs


def main():
    pages = {p for specs in FIXES.values() for (p, *_r) in specs}
    with pdfplumber.open(SRC) as pdf:
        printed = {p: page_digit_runs(pdf, p) for p in pages}

    applied, missing = [], []
    for i in range(1, 6):
        path = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        body = json.load(io.open(path, encoding='utf-8'))
        dirty = False
        for q in body['questions']:
            specs = FIXES.get(q['question_no'])
            if not specs:
                continue
            for pno, old, new, expect, kind, why in specs:
                assert expect in printed[pno], \
                    f'q{q["question_no"]}: page {pno} does not print {expect}'
                old_d = [c for c in old if c.isdigit()]
                new_d = [c for c in new if c.isdigit()]
                if kind == 'reorder':
                    assert sorted(old_d) == sorted(new_d), \
                        f'q{q["question_no"]}: {old} -> {new} is not a reordering'
                else:
                    assert kind == 'restore', f'unknown kind {kind!r}'
                    have = collections.Counter(new_d)
                    for ch, n in collections.Counter(old_d).items():
                        assert have[ch] >= n, \
                            f'q{q["question_no"]}: {old} -> {new} loses a printed digit'
                    for run in re.findall(r'\d+', new):
                        assert run in printed[pno], \
                            f'q{q["question_no"]}: page {pno} does not print restored {run}'

                hit = False
                if old in q['question_fa']:
                    q.setdefault('stem_original_fa', q['question_fa'])
                    q['question_fa'] = q['question_fa'].replace(old, new)
                    q.setdefault('stem_number_corrections', []).append({
                        'from': old, 'to': new, 'page': pno, 'where': 'stem',
                        'method': 'glyph geometry (pdfplumber x-order)',
                        'kind': kind, 'why_fa': why})
                    applied.append(f'q{q["question_no"]}: {old} -> {new} (stem)')
                    hit = True
                    dirty = True
                for oi, opt in enumerate(q['options_fa']):
                    if old in opt:
                        q.setdefault('options_original_fa', list(q['options_fa']))
                        q['options_fa'][oi] = opt.replace(old, new)
                        q.setdefault('stem_number_corrections', []).append({
                            'from': old, 'to': new, 'page': pno,
                            'where': f'option {oi + 1}',
                            'method': 'glyph geometry (pdfplumber x-order)',
                            'kind': kind, 'why_fa': why})
                        applied.append(
                            f'q{q["question_no"]}: {old} -> {new} (option {oi + 1})')
                        hit = True
                        dirty = True
                if not hit:
                    missing.append(f'q{q["question_no"]}: {old!r} not found')
        if dirty:
            json.dump(body, io.open(path, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)

    for a in applied:
        print('fixed  ', a)
    for m in missing:
        print('MISSING', m)
    print(f'\n{len(applied)} corrections written, {len(missing)} not found')


if __name__ == '__main__':
    main()
