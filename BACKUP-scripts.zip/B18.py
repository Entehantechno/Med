# -*- coding: utf-8 -*-
"""Micro-lessons, batch 18 — latent TB, contact prophylaxis and regimens.

The second half of the tuberculosis chapter. Where batch 17 taught diagnosis
and drug toxicity, this batch covers the two blocks the exam returns to most
often — and they are the two where a student is most likely to reason wrongly
from a half-remembered rule.

1. LATENT TB AND THE THREE PPD THRESHOLDS. Twelve questions turn on which
   threshold applies to which patient, and the answer is never "the test is
   positive, so treat". Two safety rules sit on top of the numbers: active
   disease must be excluded FIRST, and a positive test does not by itself
   compel treatment in someone with no risk factor.

2. CONTACT PROPHYLAXIS, ESPECIALLY IN CHILDREN AND HIV. Eight questions ask
   what to do for the household contact of a smear-positive case. The rule
   that unlocks all of them is counter-intuitive: in a CHILD UNDER 5 and in an
   HIV-POSITIVE contact, prophylaxis is started REGARDLESS OF THE PPD RESULT,
   because a negative test in these groups may simply mean the immune system
   cannot yet mount a response.

3. THE RETREATMENT REGIMEN. Four questions ask about a previously treated
   patient. The book follows classical WHO category II; modern WHO has
   abandoned it for susceptibility-guided therapy. The lessons teach both and
   say plainly which the exam expects.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022),
Chapter 178; WHO Treatment of Tuberculosis Guidelines and the 2017 update
withdrawing the category II regimen; Iranian National TB Programme.
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 178"
WHO = "WHO — Treatment of Tuberculosis: Guidelines for National Programmes"
WHO17 = "WHO 2017 — the category II retreatment regimen should no longer be prescribed"
NTP = "دستورالعمل کشوری مبارزه با سل (Iranian National TB Programme)"

PPD_FA = [
    "تست توبرکولین **سه آستانه** دارد، و آستانه به **گروه خطر بیمار** بستگی دارد نه به خود تست.",
    "⚠️ **۵ میلی‌متر یا بیشتر = مثبت** در پرخطرترین گروه‌ها:",
    "**HIV مثبت**، **تماس نزدیک اخیر** با مورد اسمیر مثبت، **پیوند عضو**،",
    "**کورتیکواستروئید طولانی‌مدت** یا **مهارکننده‌ی TNF**، و **تغییرات فیبروتیک** در گرافی ریه.",
    "⚠️ **۱۰ میلی‌متر یا بیشتر = مثبت** در گروه‌های با خطر متوسط:",
    "**دیابت**، **همودیالیز**، **سیلیکوز**، **بدخیمی**، **گاسترکتومی**،",
    "**زندانیان**، **کارکنان بهداشتی**، **معتادان تزریقی**، **مهاجران اخیر**، **کودکان زیر ۴ سال**.",
    "⚠️ **۱۵ میلی‌متر یا بیشتر = مثبت** در فردی که **هیچ عامل خطری ندارد**.",
    "منطق: هرچه **احتمال پیش‌آزمون و خطر پیشرفت** بیشتر، آستانه پایین‌تر.",
    "⚠️ قاعده‌ی ایمنی شماره یک: **پیش از هر پروفیلاکسی، سل فعال باید رد شود**.",
    "چرا؟ چون **ایزونیازید تنها** در بیمار مبتلا به سل فعال، **مقاومت دارویی** می‌سازد.",
    "پس همیشه: شرح حال، معاینه، **گرافی قفسه‌ی سینه**، و در صورت لزوم اسمیر خلط — بعد پروفیلاکسی.",
    "درمان استاندارد سل نهفته: **ایزونیازید ۶ تا ۹ ماه** (در HIV، **۹ ماه**).",
]
PPD_EN = [
    "The tuberculin test has THREE THRESHOLDS, and the threshold depends on THE PATIENT'S RISK GROUP, not the test.",
    "WARNING, 5 MM OR MORE IS POSITIVE in the highest-risk groups:",
    "HIV POSITIVE, RECENT CLOSE CONTACT with a smear-positive case, ORGAN TRANSPLANT,",
    "long-term CORTICOSTEROIDS or TNF INHIBITORS, and FIBROTIC CHANGES on the chest film.",
    "WARNING, 10 MM OR MORE IS POSITIVE in intermediate-risk groups:",
    "DIABETES, DIALYSIS, SILICOSIS, MALIGNANCY, GASTRECTOMY,",
    "PRISONERS, HEALTHCARE WORKERS, INJECTING DRUG USERS, RECENT IMMIGRANTS, CHILDREN UNDER 4.",
    "WARNING, 15 MM OR MORE IS POSITIVE in a person with NO RISK FACTOR AT ALL.",
    "The logic: the higher the pre-test probability and risk of progression, the lower the threshold.",
    "WARNING, safety rule number one: ACTIVE DISEASE MUST BE EXCLUDED BEFORE ANY PROPHYLAXIS.",
    "Why? Because ISONIAZID ALONE in someone with active tuberculosis BREEDS DRUG RESISTANCE.",
    "So always: history, examination, CHEST RADIOGRAPH, and sputum smear if needed — then prophylaxis.",
    "Standard treatment of latent TB: ISONIAZID FOR 6 TO 9 MONTHS (9 months in HIV).",
]


# ---------------------------------------------------------------- idx 261
add("book:261", "recall", "medium",
 "دیابتی با PPD **۷ میلی‌متر** ← زیر آستانه‌ی ۱۰ ← **پروفیلاکسی لازم نیست**.",
 "A diabetic with a 7 mm PPD is BELOW the 10 mm threshold: NO prophylaxis needed.",
 PPD_FA + [
  "این سؤال چهار بیمار را کنار هم می‌گذارد و از شما می‌خواهد **آستانه‌ی هرکدام** را بدانید.",
  "بیمار یک: **مهارکننده‌ی TNF** با PPD **۱۰** ← آستانه‌اش **۵** است ← مثبت ✓ پروفیلاکسی لازم.",
  "مهارکننده‌های TNF (اینفلیکسیماب و همتایانش) خطر بسیار بالایی برای فعال شدن سل دارند.",
  "چرا؟ چون **TNF-α همان سیتوکینی است که گرانولوم را نگه می‌دارد**.",
  "با مهار آن، گرانولوم فرو می‌پاشد و باسیل‌های خفته آزاد می‌شوند.",
  "بیمار دو: **HIV** با PPD **۵** ← آستانه‌اش **۵** است ← مثبت ✓ پروفیلاکسی لازم.",
  "بیمار سه: **همودیالیزی** با PPD **۱۲** ← آستانه‌اش **۱۰** است ← مثبت ✓ پروفیلاکسی لازم.",
  "⚠️ بیمار چهار: **دیابتی** با PPD **۷** ← آستانه‌اش **۱۰** است ← **منفی** ✗ پروفیلاکسی لازم **نیست**.",
  "پس پاسخ همین گزینه است.",
  "چرا دیابت در گروه **۱۰** است و نه ۵؟ چون خطرش **متوسط** است نه بسیار بالا.",
  "دیابت خطر پیشرفت به سل فعال را حدود **دو تا سه برابر** می‌کند.",
  "در مقابل، HIV آن را **بیش از بیست برابر** می‌کند — و به همین دلیل در گروه ۵ است.",
  "⚠️ نکته‌ی مهم: ۷ میلی‌متر در دیابتی یعنی تست **منفی** است، نه اینکه «کمی مثبت» باشد.",
  "آستانه یک خط قاطع است؛ زیر آن، تست منفی تلقی می‌شود و پیگیری روتین کافی است.",
 ],
 PPD_EN + [
  "This question sets four patients side by side and asks you to know EACH ONE'S THRESHOLD.",
  "Patient one: on a TNF INHIBITOR with a PPD of 10 -> threshold 5 -> positive (yes), prophylaxis needed.",
  "TNF inhibitors (infliximab and its relatives) carry a very high risk of TB reactivation.",
  "Why? Because TNF-ALPHA IS THE CYTOKINE THAT HOLDS THE GRANULOMA TOGETHER.",
  "Block it and the granuloma disintegrates, releasing the dormant bacilli.",
  "Patient two: HIV with a PPD of 5 -> threshold 5 -> positive (yes), prophylaxis needed.",
  "Patient three: on DIALYSIS with a PPD of 12 -> threshold 10 -> positive (yes), prophylaxis needed.",
  "WARNING, patient four: DIABETIC with a PPD of 7 -> threshold 10 -> NEGATIVE (no), prophylaxis NOT needed.",
  "So that is the answer.",
  "Why is diabetes in the 10 group rather than the 5? Because its risk is INTERMEDIATE, not very high.",
  "Diabetes raises the risk of progression to active disease about TWO TO THREE times.",
  "HIV, by contrast, raises it MORE THAN TWENTYFOLD — which is why it sits in the 5 group.",
  "WARNING, an important point: 7 mm in a diabetic means the test is NEGATIVE, not 'slightly positive'.",
  "A threshold is a hard line; below it the test is read as negative and routine follow-up suffices.",
 ],
 "این سؤال چهار بیمار را کنار هم می‌گذارد و می‌خواهد بدانید **آستانه‌ی PPD هرکدام چند است** — و همین نشان می‌دهد چرا حفظ کردن سه گروه ضروری است.\n\n• **مهارکننده‌ی TNF**، PPD ۱۰، آستانه‌ی **۵** ← مثبت، پروفیلاکسی لازم\n• **HIV مثبت**، PPD ۵، آستانه‌ی **۵** ← مثبت، پروفیلاکسی لازم\n• **همودیالیزی**، PPD ۱۲، آستانه‌ی **۱۰** ← مثبت، پروفیلاکسی لازم\n• ⚠️ **دیابتی**، PPD **۷**، آستانه‌ی **۱۰** ← **منفی، پروفیلاکسی لازم نیست**\n\nپس پاسخ **بیمار دیابتی با PPD هفت میلی‌متر** است.\n\n**چرا دیابت در گروه ۱۰ است و نه ۵؟** چون خطرش **متوسط** است: دیابت احتمال پیشرفت به سل فعال را حدود **دو تا سه برابر** می‌کند. در مقابل HIV آن را **بیش از بیست برابر** می‌کند، و به همین دلیل در پرخطرترین گروه (آستانه‌ی ۵) قرار دارد.\n\n⚠️ **و یک نکته‌ی مفهومی مهم:** ۷ میلی‌متر در یک دیابتی یعنی تست **منفی** است — نه اینکه «کمی مثبت» باشد. آستانه یک **خط قاطع** است؛ زیر آن، تست منفی تلقی می‌شود و پیگیری روتین کافی است.\n\n⚠️ **و یک نکته‌ی پاتوفیزیولوژیک زیبا درباره‌ی مهارکننده‌های TNF:** چرا این داروها این‌قدر خطرناک‌اند؟ چون **TNF-آلفا دقیقاً همان سیتوکینی است که ساختار گرانولوم را حفظ می‌کند**. با مهار آن، گرانولومی که سال‌ها باسیل‌های خفته را محبوس کرده بود فرو می‌پاشد و بیماری فعال می‌شود. به همین دلیل **پیش از شروع این داروها، غربالگری سل نهفته الزامی است**.",
 "This question sets four patients side by side and asks you to know EACH ONE'S PPD THRESHOLD — showing why the three groups must be memorised.\n\n- On a TNF INHIBITOR, PPD 10, threshold 5 -> positive, prophylaxis\n- HIV POSITIVE, PPD 5, threshold 5 -> positive, prophylaxis\n- ON DIALYSIS, PPD 12, threshold 10 -> positive, prophylaxis\n- WARNING, DIABETIC, PPD 7, threshold 10 -> NEGATIVE, no prophylaxis\n\nSo the answer is the DIABETIC WITH A 7 MM PPD.\n\nWHY IS DIABETES IN THE 10 GROUP RATHER THAN THE 5? Because its risk is INTERMEDIATE: diabetes raises the risk of progression to active disease about TWO TO THREE times. HIV raises it MORE THAN TWENTYFOLD, which is why it sits in the highest-risk group with a threshold of 5.\n\nWARNING, AN IMPORTANT CONCEPTUAL POINT: 7 mm in a diabetic means the test is NEGATIVE — not 'slightly positive'. A threshold is a HARD LINE; below it the test reads negative and routine follow-up suffices.\n\nWARNING, AND AN ELEGANT PATHOPHYSIOLOGICAL POINT ABOUT TNF INHIBITORS: why are these drugs so dangerous? Because TNF-ALPHA IS PRECISELY THE CYTOKINE THAT MAINTAINS THE GRANULOMA. Block it and the granuloma that had imprisoned dormant bacilli for years disintegrates, and disease reactivates. This is why SCREENING FOR LATENT TB IS MANDATORY BEFORE STARTING THESE DRUGS.",
 ["مهارکننده‌ی TNF در گروه آستانه‌ی ۵ است، پس PPD ده میلی‌متر مثبت و پروفیلاکسی لازم است.",
  "پاسخ صحیح — دیابت آستانه‌ی ۱۰ دارد و PPD هفت میلی‌متر زیر آن است، پس منفی و بدون نیاز به پروفیلاکسی.",
  "HIV آستانه‌ی ۵ دارد، پس PPD پنج میلی‌متر مثبت است و پروفیلاکسی لازم دارد.",
  "همودیالیز آستانه‌ی ۱۰ دارد، پس PPD دوازده میلی‌متر مثبت است و پروفیلاکسی لازم دارد."],
 ["A TNF inhibitor puts the patient in the 5 mm group, so a 10 mm PPD is positive and prophylaxis is needed.",
  "Correct — diabetes has a 10 mm threshold and a 7 mm PPD falls below it, so the test is negative.",
  "HIV has a 5 mm threshold, so a 5 mm PPD is positive and prophylaxis is required.",
  "Dialysis has a 10 mm threshold, so a 12 mm PPD is positive and prophylaxis is required."],
 "**۵ = HIV/تماس/پیوند/TNF/فیبروز؛ ۱۰ = دیابت/دیالیز/زندان/کادر درمان؛ ۱۵ = بدون عامل خطر.**",
 "5 = HIV/contact/transplant/TNF/fibrosis; 10 = diabetes/dialysis/prison/health worker; 15 = no risk factor.",
 [H, NTP])


# ---------------------------------------------------------------- idx 273
add("book:273", "case", "hard",
 "کودک زیر ۵ سال در تماس با سل اسمیر مثبت ← پروفیلاکسی **بدون توجه به نتیجه‌ی PPD**.",
 "A child under 5 exposed to a smear-positive case gets prophylaxis REGARDLESS OF THE PPD RESULT.",
 PPD_FA + [
  "این قاعده هشت بار در همین فصل پرسیده شده و **ضدشهودی** است، پس منطقش را بفهمید.",
  "⚠️ در **کودک زیر ۵ سال** که با مورد اسمیر مثبت تماس داشته، پروفیلاکسی **بدون توجه به PPD** شروع می‌شود.",
  "یعنی حتی اگر PPD **صفر** باشد، باز هم ایزونیازید داده می‌شود. چرا؟ سه دلیل.",
  "**دلیل یک — پنجره‌ی ایمونولوژیک.** PPD پس از عفونت **۲ تا ۱۲ هفته** طول می‌کشد تا مثبت شود.",
  "پس کودکی که هفته‌ی گذشته آلوده شده، امروز PPD منفی دارد در حالی که **واقعاً آلوده است**.",
  "به این پروفیلاکسی، **درمان پیشگیرانه‌ی پنجره (window prophylaxis)** می‌گویند.",
  "**دلیل دو — نابالغی سیستم ایمنی.** کودک خردسال ممکن است اصلاً نتواند پاسخ پوستی بدهد.",
  "PPD یک پاسخ **ازدیاد حساسیت تأخیری** است و به لنفوسیت T بالغ نیاز دارد.",
  "⚠️ **دلیل سه، و مهم‌ترین — خطر بیماری منتشر.** کودک زیر ۵ سال خطر بسیار بالایی دارد.",
  "خطر پیشرفت به بیماری فعال در شیرخوار تا **۴۰ درصد** است، در برابر ۵ تا ۱۰ درصد در بزرگسال.",
  "و بدتر: کودک خردسال به‌جای سل ریوی موضعی، **سل ارزنی و مننژیت سلی** می‌گیرد.",
  "این دو شکل **کشنده و ناتوان‌کننده‌اند** — پس خطرِ ندادن دارو بسیار بیشتر از خطرِ دادن آن است.",
  "⚠️ الگوریتم عملی: اول **سل فعال رد شود**، سپس **ایزونیازید شروع شود**، و PPD **بعد از ۳ ماه تکرار شود**.",
  "اگر PPD در تکرار مثبت شد ← دوره‌ی کامل (۶ تا ۹ ماه) ادامه می‌یابد.",
  "اگر منفی ماند و منبع دیگر مسری نیست ← می‌توان قطع کرد.",
  "⚠️ همین منطق دقیقاً برای **فرد HIV مثبت** هم صادق است: پروفیلاکسی بدون توجه به PPD.",
 ],
 PPD_EN + [
  "This rule is asked eight times in this chapter and it is COUNTER-INTUITIVE, so understand its logic.",
  "WARNING: in a CHILD UNDER 5 exposed to a smear-positive case, prophylaxis starts REGARDLESS OF THE PPD.",
  "That is, even a PPD of ZERO gets isoniazid. Why? Three reasons.",
  "REASON ONE, THE IMMUNOLOGICAL WINDOW. The PPD takes 2-12 WEEKS after infection to turn positive.",
  "So a child infected last week has a negative PPD today while being GENUINELY INFECTED.",
  "This is called WINDOW PROPHYLAXIS.",
  "REASON TWO, IMMUNE IMMATURITY. A small child may be unable to mount a skin response at all.",
  "The PPD is a DELAYED HYPERSENSITIVITY response and requires mature T lymphocytes.",
  "WARNING, REASON THREE AND THE MOST IMPORTANT — THE RISK OF DISSEMINATED DISEASE.",
  "The risk of progression to active disease in an infant reaches 40%, against 5-10% in an adult.",
  "And worse: instead of localised pulmonary disease, a small child develops MILIARY TB AND TB MENINGITIS.",
  "Both are LETHAL OR DISABLING — so the risk of withholding the drug far exceeds the risk of giving it.",
  "WARNING, the practical algorithm: EXCLUDE ACTIVE DISEASE first, START ISONIAZID, and REPEAT THE PPD AT 3 MONTHS.",
  "If the repeat PPD is positive -> complete the full course (6-9 months).",
  "If it stays negative and the source is no longer infectious -> it may be stopped.",
  "WARNING: exactly the same logic applies to an HIV-POSITIVE contact — prophylaxis regardless of the PPD.",
 ],
 "این قاعده **هشت بار** در همین فصل پرسیده شده و کاملاً **ضدشهودی** است، پس ارزش دارد منطقش را بفهمید نه حفظ کنید.\n\n⚠️ **قاعده: در کودک زیر ۵ سال که با مورد سل اسمیر مثبت تماس داشته، پروفیلاکسی با ایزونیازید بدون توجه به نتیجه‌ی PPD شروع می‌شود** — حتی اگر PPD صفر باشد.\n\n**سه دلیل، که هر سه را باید دانست:**\n\n**۱. پنجره‌ی ایمونولوژیک.** تست PPD پس از عفونت **۲ تا ۱۲ هفته** طول می‌کشد تا مثبت شود. پس کودکی که هفته‌ی گذشته آلوده شده، امروز PPD منفی دارد در حالی که **واقعاً آلوده است**. به این کار **درمان پیشگیرانه‌ی پنجره** می‌گویند.\n\n**۲. نابالغی سیستم ایمنی.** PPD یک پاسخ **ازدیاد حساسیت تأخیری** است و به لنفوسیت T بالغ نیاز دارد. کودک خردسال ممکن است اصلاً نتواند چنین پاسخی بدهد — یعنی منفی بودن تست، **نبود عفونت را ثابت نمی‌کند**.\n\n⚠️ **۳. و مهم‌ترین دلیل: خطر بیماری منتشر.** خطر پیشرفت به بیماری فعال در شیرخوار تا **۴۰ درصد** است، در برابر ۵ تا ۱۰ درصد در بزرگسال. و بدتر از آن، کودک خردسال به‌جای سل ریوی موضعی، **سل ارزنی و مننژیت سلی** می‌گیرد — دو شکل کشنده و ناتوان‌کننده.\n\nپس **موازنه‌ی خطر** روشن است: خطر ندادن دارو بسیار بیشتر از خطر دادن آن است.\n\n**الگوریتم عملی:**\n۱. ⚠️ اول **سل فعال رد شود** (معاینه و گرافی)\n۲. **ایزونیازید شروع شود**\n۳. **PPD بعد از ۳ ماه تکرار شود**\n۴. اگر مثبت شد ← دوره‌ی کامل ۶ تا ۹ ماه؛ اگر منفی ماند و منبع دیگر مسری نیست ← می‌توان قطع کرد\n\n⚠️ و دقیقاً همین منطق برای **فرد HIV مثبت در تماس** هم صادق است.",
 "This rule is asked EIGHT times in this chapter and is thoroughly COUNTER-INTUITIVE, so it is worth understanding rather than memorising.\n\nWARNING, THE RULE: in a CHILD UNDER 5 exposed to a smear-positive case, isoniazid prophylaxis is started REGARDLESS OF THE PPD RESULT — even if the PPD is zero.\n\nTHREE REASONS, all worth knowing:\n\n1. THE IMMUNOLOGICAL WINDOW. The PPD takes 2-12 WEEKS after infection to become positive. A child infected last week has a negative PPD today while being GENUINELY INFECTED. This is called WINDOW PROPHYLAXIS.\n\n2. IMMUNE IMMATURITY. The PPD is a DELAYED HYPERSENSITIVITY response requiring mature T lymphocytes. A small child may be unable to mount one at all — so a negative test DOES NOT PROVE THE ABSENCE OF INFECTION.\n\nWARNING, 3. AND THE MOST IMPORTANT REASON: THE RISK OF DISSEMINATED DISEASE. The risk of progression to active disease in an infant reaches 40%, against 5-10% in an adult. And worse, instead of localised pulmonary disease the small child develops MILIARY TUBERCULOSIS AND TUBERCULOUS MENINGITIS — both lethal or disabling.\n\nThe BALANCE OF RISK is therefore clear: withholding the drug is far more dangerous than giving it.\n\nTHE PRACTICAL ALGORITHM:\n1. WARNING, EXCLUDE ACTIVE DISEASE first (examination and radiograph)\n2. START ISONIAZID\n3. REPEAT THE PPD AT 3 MONTHS\n4. If positive -> complete 6-9 months; if still negative and the source is no longer infectious -> it may be stopped\n\nWARNING: exactly the same logic applies to an HIV-POSITIVE contact.",
 ["«نیاز به اقدام خاصی ندارد» خطرناک است: کودک زیر ۵ سال بیشترین خطر سل ارزنی و مننژیت سلی را دارد.",
  "انجام PPD و توقف در صورت منفی بودن، پنجره‌ی ایمونولوژیک و نابالغی ایمنی کودک را نادیده می‌گیرد.",
  "شروع پروفیلاکسی فقط در صورت مثبت شدن PPD، دقیقاً همان خطایی است که این قاعده برای جلوگیری از آن ساخته شده.",
  "پاسخ صحیح — در کودک زیر ۵ سال در تماس، پروفیلاکسی بدون توجه به نتیجه‌ی PPD و پس از رد سل فعال شروع می‌شود."],
 ["'No action needed' is dangerous: a child under 5 has the highest risk of miliary TB and TB meningitis.",
  "Doing a PPD and stopping if negative ignores both the immunological window and the child's immune immaturity.",
  "Starting prophylaxis only if the PPD turns positive is exactly the error this rule exists to prevent.",
  "Correct — in an exposed child under 5, prophylaxis begins regardless of the PPD, after excluding active disease."],
 "کودک <۵ سال یا HIV در تماس ← **ایزونیازید بدون توجه به PPD**. اول سل فعال را رد کن؛ PPD را ۳ ماه بعد تکرار کن.",
 "An exposed child under 5, or an HIV contact -> ISONIAZID REGARDLESS OF THE PPD. Exclude active disease first; repeat the PPD at 3 months.",
 [H, NTP, WHO])


# ---------------------------------------------------------------- idx 266
add("book:266", "case", "hard",
 "PPD **۱۷ میلی‌متر** در فرد **بدون عامل خطر**: تست **مثبت** است، ولی درمان الزامی **نیست**.",
 "A 17 mm PPD in a person with NO RISK FACTOR is a POSITIVE TEST, but does not by itself compel treatment.",
 PPD_FA + [
  "⚠️ نخست یک نکته‌ی داده‌ای: عدد این سؤال در متن استخراج‌شده **۷۱ میلی‌متر** ثبت شده بود.",
  "اندوراسیون ۷۱ میلی‌متر از نظر فیزیکی ممکن نیست؛ صفحه‌ی ۱۰۳ کتاب رقم‌ها را **۱۷** چاپ کرده است.",
  "عدد از روی هندسه‌ی گلیف تصحیح شد، وگرنه سؤال اصلاً قابل پاسخ نبود.",
  "حالا بیمار: **مرد ۲۴ ساله**، معاینه‌ی استخدامی بانک، **بدون هیچ عامل خطری**.",
  "پس آستانه‌ی او **۱۵ میلی‌متر** است، و ۱۷ از آن بیشتر است ← **تست مثبت است**.",
  "⚠️ و حالا نکته‌ی محوری که این سؤال را سخت می‌کند:",
  "**مثبت بودن تست، با الزامی بودن درمان یکی نیست.**",
  "آستانه‌ها می‌گویند تست را چگونه **تفسیر** کنیم؛ نمی‌گویند حتماً **درمان** کنیم.",
  "تصمیم درمان به **موازنه‌ی سود و زیان در همان فرد** بستگی دارد.",
  "سودِ درمان = کاهش خطر پیشرفت به سل فعال، که در فرد بدون عامل خطر **کم** است.",
  "زیانِ درمان = **هپاتیت ایزونیازید**، که با **افزایش سن** بیشتر می‌شود.",
  "⚠️ در فرد جوانِ بدون عامل خطر با یک تست مثبتِ منفرد، رویکرد **پیگیری** است نه درمان فوری.",
  "و یک نکته‌ی مهم دیگر: نمی‌دانیم این تست **تازه مثبت شده** یا سال‌ها مثبت بوده.",
  "⚠️ **تبدیل تازه (conversion)** — افزایش بیش از ۱۰ میلی‌متر در دو سال — خطر بسیار بالاتری دارد.",
  "به همین دلیل در کارکنان بهداشتی که **تست پایه** دارند، تبدیل تازه حتماً درمان می‌شود.",
  "اینجا تست پایه‌ای وجود ندارد، پس نمی‌توان تبدیل تازه را اثبات کرد.",
 ],
 PPD_EN + [
  "WARNING, first a data note: this question's value was stored as 71 MM in the extracted text.",
  "A 71 mm induration is physically impossible; page 103 of the book prints the digits as 17.",
  "The number was corrected from glyph geometry, without which the question could not be answered at all.",
  "Now the patient: a 24-YEAR-OLD MAN at a pre-employment bank screen, WITH NO RISK FACTOR.",
  "His threshold is therefore 15 MM, and 17 exceeds it -> THE TEST IS POSITIVE.",
  "WARNING, and now the central point that makes this question hard:",
  "A POSITIVE TEST IS NOT THE SAME AS AN OBLIGATION TO TREAT.",
  "The thresholds tell you how to INTERPRET the test; they do not tell you to TREAT.",
  "The treatment decision depends on THE BALANCE OF BENEFIT AND HARM IN THAT PERSON.",
  "Benefit = reduced risk of progression to active disease, which is LOW in someone with no risk factor.",
  "Harm = ISONIAZID HEPATITIS, whose risk RISES WITH AGE.",
  "WARNING: in a young person with no risk factor and a single positive reading, the approach is FOLLOW-UP.",
  "And another important point: we do not know whether this test has JUST turned positive or has been so for years.",
  "WARNING: a RECENT CONVERSION — a rise of more than 10 mm within two years — carries a far higher risk.",
  "That is why, in health workers who have a BASELINE test, a recent conversion is always treated.",
  "Here there is no baseline, so a recent conversion cannot be established.",
 ],
 "⚠️ **نخست یک نکته‌ی داده‌ای که باید ثبت شود:** عدد PPD این سؤال در متن استخراج‌شده **۷۱ میلی‌متر** بود. اندوراسیون ۷۱ میلی‌متری از نظر فیزیکی ممکن نیست؛ صفحه‌ی ۱۰۳ کتاب رقم‌ها را به ترتیب **۱ و ۷** چاپ کرده، یعنی **۱۷**. عدد از روی هندسه‌ی گلیف تصحیح شد — وگرنه سؤال اصلاً قابل پاسخ نبود.\n\n**حالا بیمار:** مرد **۲۴ ساله**، معاینه‌ی استخدامی بانک، **بدون هیچ عامل خطری**، ESR و CRP نرمال، و شواهدی از سل فعال ندارد.\n\nآستانه‌ی او **۱۵ میلی‌متر** است (گروه بدون عامل خطر)، و ۱۷ از آن بیشتر است. پس **تست مثبت است**.\n\n⚠️ **و اینجا نکته‌ی محوری که این سؤال را سخت می‌کند:**\n\n**مثبت بودن تست با الزامی بودن درمان یکی نیست.**\n\nآستانه‌ها به ما می‌گویند تست را چگونه **تفسیر** کنیم؛ نمی‌گویند حتماً **درمان** کنیم. تصمیم درمان به **موازنه‌ی سود و زیان در همان فرد مشخص** بستگی دارد:\n\n• **سودِ درمان** = کاهش خطر پیشرفت به سل فعال — که در فرد **بدون عامل خطر کم** است\n• **زیانِ درمان** = **هپاتیت ایزونیازید** — که با **افزایش سن** بیشتر می‌شود و می‌تواند جدی باشد\n\nدر یک جوان ۲۴ ساله‌ی بدون عامل خطر، با یک تست مثبتِ منفرد و بدون شواهد بیماری فعال، رویکرد استاندارد **پیگیری** است، نه شروع فوری دارو.\n\n⚠️ **و یک نکته‌ی تکمیلی مهم:** ما نمی‌دانیم این تست **تازه مثبت شده** یا سال‌هاست مثبت بوده. **تبدیل تازه** — افزایش بیش از ۱۰ میلی‌متر ظرف دو سال — خطر بسیار بالاتری دارد و **حتماً درمان می‌شود**. به همین دلیل در کارکنان بهداشتی که **تست پایه** دارند، تبدیل تازه اندیکاسیون قطعی پروفیلاکسی است. اینجا تست پایه‌ای وجود ندارد، پس تبدیل تازه قابل اثبات نیست.",
 "WARNING, FIRST A DATA NOTE WORTH RECORDING: this question's PPD was stored as 71 MM in the extracted text. A 71 mm induration is physically impossible; page 103 of the book prints the digits in the order 1 then 7, that is 17. The number was corrected from glyph geometry — without which the question could not be answered at all.\n\nNOW THE PATIENT: a 24-YEAR-OLD MAN at a pre-employment bank screen, WITH NO RISK FACTOR, normal ESR and CRP, and no evidence of active disease.\n\nHis threshold is 15 MM (the no-risk-factor group) and 17 exceeds it. So THE TEST IS POSITIVE.\n\nWARNING, AND HERE IS THE CENTRAL POINT THAT MAKES THIS QUESTION HARD:\n\nA POSITIVE TEST IS NOT THE SAME AS AN OBLIGATION TO TREAT.\n\nThe thresholds tell us how to INTERPRET the test; they do not tell us to TREAT. The treatment decision depends on THE BALANCE OF BENEFIT AND HARM IN THAT PARTICULAR PERSON:\n\n- BENEFIT = reduced risk of progression to active disease — which is LOW in someone with no risk factor\n- HARM = ISONIAZID HEPATITIS — whose risk RISES WITH AGE and can be serious\n\nIn a 24-year-old with no risk factor, a single positive reading and no evidence of active disease, the standard approach is FOLLOW-UP, not immediate drug treatment.\n\nWARNING, A FURTHER IMPORTANT POINT: we do not know whether this test has JUST turned positive or has been positive for years. A RECENT CONVERSION — a rise of more than 10 mm within two years — carries a far higher risk and IS ALWAYS TREATED. That is why, in health workers who have a BASELINE test, a recent conversion is a definite indication. Here there is no baseline, so conversion cannot be established.",
 ["پاسخ صحیح — تست مثبت است ولی در فرد جوان بدون عامل خطر، رویکرد پیگیری است نه درمان فوری.",
  "«چون تست مثبت است پس پروفیلاکسی» همان خطای منطقی است: تفسیر تست با الزام درمان یکی نیست.",
  "درمان چهاردارویی ضدسل برای بیماری فعال است؛ این بیمار هیچ شاهدی از بیماری فعال ندارد.",
  "دادن سه‌ماهه‌ی ایزونیازید و تکرار تست، نه رژیم استانداردی است و نه منطقی: PPD پس از مثبت شدن، منفی نمی‌شود."],
 ["Correct — the test is positive, but in a young person with no risk factor the approach is follow-up, not immediate treatment.",
  "'The test is positive therefore treat' is the logical error: interpreting a test is not the same as being obliged to treat.",
  "Four-drug therapy is for active disease; this patient has no evidence of active tuberculosis.",
  "Three months of isoniazid then repeating the test is neither a standard regimen nor logical: a PPD does not revert once positive."],
 "**تست مثبت ≠ درمان الزامی.** در فرد بدون عامل خطر، سود کم و خطر هپاتیت هست ← پیگیری. **تبدیل تازه** حتماً درمان می‌شود.",
 "A POSITIVE TEST IS NOT AN OBLIGATION TO TREAT. With no risk factor the benefit is low and hepatitis a real risk -> follow up. A RECENT CONVERSION is always treated.",
 [H, NTP])


# ---------------------------------------------------------------- idx 227
add("book:227", "case", "hard",
 "بیمار **درمان‌شده‌ی قبلی** با اسمیر مثبت ← رژیم بازدرمانی: **۳ ماه HRZE + ۵ ماه HRE**.",
 "A PREVIOUSLY TREATED smear-positive patient gets the retreatment regimen: 3 months HRZE then 5 months HRE.",
 [
  "برای پاسخ باید **دو دسته‌ی بیمار** را از هم جدا کرد؛ کل بلوک رژیم‌ها بر این تفکیک بنا شده.",
  "**دسته‌ی یک — بیمار جدید (new case)**: هرگز درمان سل نگرفته، یا کمتر از **یک ماه** گرفته.",
  "رژیم بیمار جدید: **۲ ماه HRZE** سپس **۴ ماه HR** — همان ۲HRZE/4HR معروف.",
  "**دسته‌ی دو — بیمار درمان‌شده‌ی قبلی**: بیش از یک ماه درمان سل گرفته است.",
  "زیرگروه‌های آن: **عود (relapse)**، **شکست درمان (failure)**، و **بازگشت پس از غیبت (default)**.",
  "⚠️ چرا این دسته رژیم متفاوتی می‌خواهد؟ چون **خطر مقاومت دارویی در آن بالاتر است**.",
  "بیماری که یک دوره درمان گرفته و باز برگشته، احتمال بیشتری دارد باسیل مقاوم داشته باشد.",
  "**رژیم کلاسیک بازدرمانی (category II)**: ۲ ماه HRZES + ۱ ماه HRZE + ۵ ماه HRE.",
  "یعنی **۸ ماه** در مجموع، در برابر ۶ ماه بیمار جدید.",
  "و افزودن **استرپتومایسین** در دو ماه اول، داروی پنجمی است که پوشش را وسیع‌تر می‌کند.",
  "این بیمار **سابقه‌ی درمان سل پلور در سه سال پیش** دارد ← پس **درمان‌شده‌ی قبلی** است.",
  "پس گزینه‌ی **۳ ماه HRZE و ۵ ماه HRE** — که مجموعاً ۸ ماه است — با این چارچوب می‌خواند.",
  "⚠️ **و حالا به‌روزرسانی مهمی که دانشجو باید بداند:**",
  "**سازمان جهانی بهداشت در ۲۰۱۷ رژیم category II را کنار گذاشت.**",
  "دلیل: در جایی که مقاومت به ریفامپین شایع شده، این رژیم **ناکارآمد** است و مقاومت را تشدید می‌کند.",
  "توصیه‌ی امروزی: **آزمون حساسیت دارویی سریع** (مثل Xpert MTB/RIF) و رژیم **بر پایه‌ی نتیجه**.",
  "اگر مقاومت نبود، همان رژیم استاندارد ۲HRZE/4HR تکرار می‌شود.",
  "⚠️ ولی این آزمون‌ها **چارچوب کلاسیک** را می‌پرسند و کلیدهایشان بر آن بناست — هر دو را بدانید.",
 ],
 [
  "To answer, separate TWO CATEGORIES OF PATIENT; the whole regimen block rests on that division.",
  "CATEGORY ONE, A NEW CASE: never treated for tuberculosis, or treated for LESS THAN ONE MONTH.",
  "The new-case regimen: 2 MONTHS HRZE then 4 MONTHS HR — the familiar 2HRZE/4HR.",
  "CATEGORY TWO, A PREVIOUSLY TREATED PATIENT: has had more than a month of TB treatment.",
  "Its subgroups: RELAPSE, TREATMENT FAILURE, and RETURN AFTER DEFAULT.",
  "WARNING, why does this category need a different regimen? Because ITS RISK OF DRUG RESISTANCE IS HIGHER.",
  "A patient who has had a course and returned is more likely to harbour resistant bacilli.",
  "THE CLASSICAL RETREATMENT REGIMEN (category II): 2 months HRZES + 1 month HRZE + 5 months HRE.",
  "That is EIGHT MONTHS in total, against six for a new case.",
  "And adding STREPTOMYCIN in the first two months provides a fifth drug, broadening the cover.",
  "This patient was TREATED FOR TUBERCULOUS PLEURISY THREE YEARS AGO -> he is PREVIOUSLY TREATED.",
  "So the option of 3 MONTHS HRZE AND 5 MONTHS HRE — eight months in total — fits that framework.",
  "WARNING, AND NOW AN IMPORTANT UPDATE THE STUDENT SHOULD KNOW:",
  "THE WORLD HEALTH ORGANIZATION WITHDREW THE CATEGORY II REGIMEN IN 2017.",
  "The reason: where rifampicin resistance has become common, the regimen is INEFFECTIVE and amplifies resistance.",
  "Today's advice: RAPID DRUG SUSCEPTIBILITY TESTING (such as Xpert MTB/RIF) and a regimen GUIDED BY THE RESULT.",
  "If no resistance is found, the standard 2HRZE/4HR is simply repeated.",
  "WARNING: but these exams ask the CLASSICAL framework and their keys rest on it — know both.",
 ],
 "برای پاسخ باید **دو دسته‌ی بیمار** را از هم جدا کرد — و کل بلوک رژیم‌های این فصل بر همین تفکیک بنا شده است.\n\n**دسته‌ی یک — بیمار جدید:** هرگز درمان سل نگرفته، یا کمتر از **یک ماه** گرفته.\nرژیم: **۲ ماه HRZE + ۴ ماه HR** (همان ۲HRZE/4HR)، مجموعاً **۶ ماه**.\n\n**دسته‌ی دو — بیمار درمان‌شده‌ی قبلی:** بیش از یک ماه درمان گرفته است. زیرگروه‌ها: **عود**، **شکست درمان**، **بازگشت پس از غیبت**.\n\n⚠️ **چرا این دسته رژیم متفاوتی می‌خواهد؟** چون **خطر مقاومت دارویی در آن بالاتر است**. بیماری که یک دوره درمان گرفته و باز برگشته، احتمال بیشتری دارد باسیل مقاوم داشته باشد.\n\n**رژیم کلاسیک بازدرمانی (category II):**\n**۲ ماه HRZES + ۱ ماه HRZE + ۵ ماه HRE** = مجموعاً **۸ ماه**\n\nافزودن **استرپتومایسین** در دو ماه اول، داروی پنجمی است که پوشش را وسیع‌تر می‌کند.\n\nاین بیمار **سابقه‌ی درمان سل پلور در سه سال پیش** دارد، پس **درمان‌شده‌ی قبلی** است — و گزینه‌ی **۳ ماه HRZE و ۵ ماه HRE** (مجموعاً ۸ ماه) با این چارچوب می‌خواند.\n\n⚠️ **و حالا یک به‌روزرسانی مهم که هر دانشجویی باید بداند:**\n\n**سازمان جهانی بهداشت در سال ۲۰۱۷ رژیم category II را کنار گذاشت.** دلیلش این بود که در جوامعی که مقاومت به ریفامپین شایع شده، این رژیم نه‌تنها **ناکارآمد** است بلکه با افزودن یک داروی تنها (استرپتومایسین) به رژیمی که ممکن است شکست خورده باشد، **مقاومت را تشدید** می‌کند.\n\n**توصیه‌ی امروزی:** انجام **آزمون حساسیت دارویی سریع** (مثل Xpert MTB/RIF) و انتخاب رژیم **بر پایه‌ی نتیجه**. اگر مقاومتی نبود، همان رژیم استاندارد ۲HRZE/4HR تکرار می‌شود.\n\n⚠️ اما این آزمون‌ها **چارچوب کلاسیک** را می‌پرسند و کلیدهایشان بر همان بنا شده — پس **هر دو را بدانید**.",
 "To answer, separate TWO CATEGORIES OF PATIENT — the whole regimen block of this chapter rests on that division.\n\nCATEGORY ONE, A NEW CASE: never treated, or treated for LESS THAN ONE MONTH.\nRegimen: 2 MONTHS HRZE + 4 MONTHS HR (2HRZE/4HR), SIX MONTHS in total.\n\nCATEGORY TWO, A PREVIOUSLY TREATED PATIENT: has had more than a month of treatment. Subgroups: RELAPSE, TREATMENT FAILURE, RETURN AFTER DEFAULT.\n\nWARNING, WHY DOES THIS CATEGORY NEED A DIFFERENT REGIMEN? Because ITS RISK OF DRUG RESISTANCE IS HIGHER. A patient who has had a course and returned is more likely to harbour resistant bacilli.\n\nTHE CLASSICAL RETREATMENT REGIMEN (category II):\n2 months HRZES + 1 month HRZE + 5 months HRE = EIGHT MONTHS in total\n\nAdding STREPTOMYCIN in the first two months provides a fifth drug, broadening the cover.\n\nThis patient was TREATED FOR TUBERCULOUS PLEURISY THREE YEARS AGO, so he is PREVIOUSLY TREATED — and the option of 3 MONTHS HRZE AND 5 MONTHS HRE (eight months in total) fits that framework.\n\nWARNING, AND NOW AN IMPORTANT UPDATE EVERY STUDENT SHOULD KNOW:\n\nTHE WORLD HEALTH ORGANIZATION WITHDREW THE CATEGORY II REGIMEN IN 2017. The reason: where rifampicin resistance has become common, the regimen is not merely INEFFECTIVE but AMPLIFIES RESISTANCE, since it adds a single drug (streptomycin) to a regimen that may already have failed.\n\nTODAY'S ADVICE: perform RAPID DRUG SUSCEPTIBILITY TESTING (such as Xpert MTB/RIF) and choose the regimen BY THE RESULT. If no resistance is found, the standard 2HRZE/4HR is simply repeated.\n\nWARNING: but these exams ask the CLASSICAL framework and their keys rest on it — so KNOW BOTH.",
 ["دو ماه HRZE و چهار ماه HR رژیم **بیمار جدید** است؛ این بیمار سابقه‌ی درمان قبلی دارد.",
  "پاسخ صحیح — بیمار درمان‌شده‌ی قبلی، رژیم هشت‌ماهه‌ی بازدرمانی می‌گیرد، نه رژیم شش‌ماهه‌ی استاندارد.",
  "دو ماه HRZE و هفت ماه HR رژیم شناخته‌شده‌ای در چارچوب کشوری نیست.",
  "سه ماه HRZES و شش ماه HRE مجموعاً نُه ماه است و با رژیم استاندارد بازدرمانی نمی‌خواند."],
 ["Two months HRZE and four months HR is the NEW-CASE regimen; this patient has been treated before.",
  "Correct — a previously treated patient receives the eight-month retreatment regimen, not the standard six-month one.",
  "Two months HRZE and seven months HR is not a recognised regimen in this framework.",
  "Three months HRZES and six months HRE totals nine months and does not match the standard retreatment regimen."],
 "**جدید = ۲HRZE/4HR (۶ ماه).** **درمان‌شده‌ی قبلی = رژیم ۸ ماهه.** ⚠️ WHO از ۲۰۱۷ category II را کنار گذاشت.",
 "NEW = 2HRZE/4HR (6 months). PREVIOUSLY TREATED = an 8-month regimen. WARNING: WHO withdrew category II in 2017.",
 [H, WHO, WHO17])


# ---------------------------------------------------------------- idx 231
# NOTE: this lesson was drafted for idx 234, but apply_lessons.py's duplicate
# guard caught that batch 1 already teaches that question. Rather than ship two
# lessons on one stem — the user's rule is that no question may be duplicated —
# it was moved to idx 231 and rewritten around a different and sharper point:
# THE ONE-MONTH RULE that decides whether a patient counts as "new" at all.
# That rule is what makes the monitoring schedule meaningful, so the monitoring
# timetable is kept in the teaching points as supporting material.
add("book:231", "case", "hard",
 "درمانی که **کمتر از یک ماه** طول کشیده، اصلاً حساب نمی‌شود ← بیمار **مورد جدید** است.",
 "Treatment lasting LESS THAN ONE MONTH does not count at all: the patient is a NEW CASE.",
 [
  "⚠️ **قاعده‌ی یک ماه**: بیماری که **کمتر از یک ماه** درمان سل گرفته، **مورد جدید** حساب می‌شود.",
  "این قاعده در نگاه اول عجیب است — بیمار بالاخره دارو گرفته، چرا نادیده گرفته می‌شود؟",
  "دلیلش **میکروبیولوژیک** است، نه اداری.",
  "برای آنکه فشار انتخابی دارو، جمعیت مقاومی را غالب کند، به **زمان** نیاز است.",
  "مواجهه‌ی کوتاه‌تر از یک ماه، آن‌قدر نبوده که الگوی مقاومت را به‌طور معنادار عوض کند.",
  "پس خطر مقاومت این بیمار **مثل یک بیمار درمان‌نگرفته** است، و رژیم استاندارد کافی است.",
  "این بیمار **دو هفته** درمان گرفته و خودسرانه قطع کرده ← زیر یک ماه ← **مورد جدید**.",
  "پس رژیم او: **۲ ماه HRZE سپس ۴ ماه HR** — همان رژیم استاندارد شش‌ماهه.",
  "⚠️ در مقابل، اگر بیش از یک ماه درمان گرفته بود، **بازگشت پس از غیبت** محسوب می‌شد.",
  "و آن دسته، رژیم بازدرمانی و بررسی حساسیت دارویی می‌خواهد.",
  "**و حالا پیگیری همین بیمار، که بخش دوم دانش لازم است:**",
  "⚠️ ابزار پیگیری، **اسمیر خلط** است — نه رادیوگرافی و نه تست پوستی.",
  "زمان‌بندی: پایان **ماه دوم**، پایان **ماه پنجم**، و پایان **ماه ششم** (پایان درمان).",
  "**چرا پایان ماه دوم؟** چون پایان **مرحله‌ی حمله‌ای** است و تصمیم بعدی را می‌سازد.",
  "اگر اسمیر ماه دوم منفی شد ← وارد **مرحله‌ی نگهدارنده** می‌شویم.",
  "اگر مثبت ماند ← مرحله‌ی حمله‌ای **یک ماه تمدید** می‌شود و اسمیر ماه سوم تکرار.",
  "**چرا پایان ماه پنجم؟** چون این آزمون **شکست درمان** را تعریف می‌کند.",
  "⚠️ **تعریف شکست درمان: اسمیر مثبت در پایان ماه پنجم یا بعد از آن.**",
  "این تعریف اهمیت زیادی دارد، چون بیمار را وارد مسیر **بررسی مقاومت دارویی** می‌کند.",
  "**چرا پایان ماه ششم؟** برای تأیید **بهبودی (cure)** پیش از قطع دارو.",
  "⚠️ حالا چرا **رادیوگرافی** ابزار پیگیری خوبی نیست؟ دو دلیل محکم.",
  "دلیل یک: تغییرات رادیولوژیک **بسیار کندتر از پاسخ میکروبیولوژیک** برطرف می‌شوند.",
  "دلیل دو: **فیبروز و اسکار باقی‌مانده** ممکن است تا سال‌ها بماند و شبیه بیماری فعال به نظر برسد.",
  "پس عکس نرمال نشدن، به‌هیچ‌وجه به معنای شکست درمان نیست.",
  "⚠️ و چرا **PPD** اصلاً ابزار پیگیری نیست؟ چون پس از عفونت **مادام‌العمر مثبت می‌ماند**.",
  "PPD نه با درمان منفی می‌شود و نه شدت بیماری را نشان می‌دهد — کاملاً بی‌فایده برای پیگیری.",
  "آزمایش کبدی و CBC هم پیگیری **عوارض دارو** هستند، نه پیگیری **پاسخ به درمان**.",
 ],
 [
  "WARNING, THE ONE-MONTH RULE: a patient treated for LESS THAN ONE MONTH counts as a NEW CASE.",
  "At first sight this is strange — the patient did take drugs, so why is that ignored?",
  "The reason is MICROBIOLOGICAL, not administrative.",
  "For drug selection pressure to let a resistant population dominate, TIME is required.",
  "An exposure shorter than a month has not been long enough to shift the resistance pattern meaningfully.",
  "So this patient's resistance risk is that of an UNTREATED patient, and the standard regimen suffices.",
  "This patient had TWO WEEKS and stopped on his own -> under a month -> A NEW CASE.",
  "His regimen is therefore 2 MONTHS HRZE then 4 MONTHS HR — the standard six-month course.",
  "WARNING, by contrast, had he taken more than a month he would count as RETURN AFTER DEFAULT.",
  "And that category needs a retreatment regimen and drug susceptibility testing.",
  "AND NOW HIS MONITORING, which is the second half of the knowledge required:",
  "WARNING, the monitoring tool is the SPUTUM SMEAR — not radiography, not the skin test.",
  "The timing: end of MONTH TWO, end of MONTH FIVE, and end of MONTH SIX (end of treatment).",
  "WHY THE END OF MONTH TWO? Because it ends the INTENSIVE PHASE and drives the next decision.",
  "If the month-2 smear is negative -> move to the CONTINUATION PHASE.",
  "If it remains positive -> the intensive phase is EXTENDED BY A MONTH and the smear repeated at month 3.",
  "WHY THE END OF MONTH FIVE? Because that test defines TREATMENT FAILURE.",
  "WARNING, THE DEFINITION OF TREATMENT FAILURE: a positive smear at or after the end of month five.",
  "That definition matters greatly, because it puts the patient onto the DRUG-RESISTANCE pathway.",
  "WHY THE END OF MONTH SIX? To confirm CURE before stopping the drugs.",
  "WARNING, now why is RADIOGRAPHY a poor monitoring tool? Two solid reasons.",
  "Reason one: radiological change resolves FAR MORE SLOWLY than the microbiological response.",
  "Reason two: RESIDUAL FIBROSIS AND SCARRING may persist for years and mimic active disease.",
  "So a film that fails to normalise is in no way evidence of treatment failure.",
  "WARNING, and why is the PPD not a monitoring tool at all? Because it STAYS POSITIVE FOR LIFE after infection.",
  "The PPD neither reverts with treatment nor reflects disease severity — entirely useless for follow-up.",
  "Liver tests and a full blood count monitor DRUG TOXICITY, not the RESPONSE TO TREATMENT.",
 ],
 "این سؤال یک قاعده‌ی ظریف اما تعیین‌کننده را می‌آزماید: ⚠️ **بیماری که کمتر از یک ماه درمان سل گرفته، «مورد جدید» حساب می‌شود.**\n\nاین بیمار حدود **دو هفته** درمان گرفته و خودسرانه قطع کرده است — یعنی **زیر یک ماه**. پس با وجود سابقه‌ی دارو، **مورد جدید** است و رژیم استاندارد **۲ ماه HRZE سپس ۴ ماه HR** می‌گیرد.\n\n**چرا این قاعده منطقی است؟** دلیلش میکروبیولوژیک است، نه اداری: برای آنکه **فشار انتخابی دارو** جمعیت مقاومی را غالب کند، به **زمان** نیاز است. مواجهه‌ی کوتاه‌تر از یک ماه آن‌قدر نبوده که الگوی مقاومت را به‌طور معنادار تغییر دهد، پس خطر مقاومت این بیمار مثل یک بیمار درمان‌نگرفته است.\n\n⚠️ **در مقابل**، اگر بیش از یک ماه درمان گرفته بود، **بازگشت پس از غیبت** محسوب می‌شد و رژیم بازدرمانی به‌علاوه‌ی بررسی حساسیت دارویی لازم می‌بود.\n\n---\n\n**و حالا بخش دوم دانش لازم: این بیمار را چگونه پیگیری کنیم؟**\n\nابزار پیگیری **اسمیر خلط** است — نه رادیوگرافی، نه تست پوستی.\n\n**زمان‌بندی و منطق هر نوبت:**\n\n**پایان ماه دوم** — پایان **مرحله‌ی حمله‌ای**. این آزمون تصمیم بعدی را می‌سازد:\n• منفی شد ← وارد **مرحله‌ی نگهدارنده** می‌شویم\n• مثبت ماند ← مرحله‌ی حمله‌ای **یک ماه تمدید** و اسمیر ماه سوم تکرار می‌شود\n\n⚠️ **پایان ماه پنجم** — این مهم‌ترین نوبت است، چون **تعریف شکست درمان** را می‌سازد:\n**شکست درمان = اسمیر مثبت در پایان ماه پنجم یا پس از آن.**\nاین تعریف بیمار را وارد مسیر **بررسی مقاومت دارویی** می‌کند.\n\n**پایان ماه ششم** — تأیید **بهبودی** پیش از قطع دارو.\n\n⚠️ **و حالا چرا رادیوگرافی ابزار پیگیری خوبی نیست؟** دو دلیل محکم:\n\n۱. تغییرات رادیولوژیک **بسیار کندتر از پاسخ میکروبیولوژیک** برطرف می‌شوند؛ بیمار می‌تواند کاملاً درمان شده باشد ولی عکسش هنوز غیرطبیعی باشد\n۲. **فیبروز و اسکار باقی‌مانده** ممکن است تا سال‌ها بماند و به‌اشتباه شبیه بیماری فعال دیده شود\n\n⚠️ **و چرا PPD اصلاً ابزار پیگیری نیست؟** چون پس از عفونت **مادام‌العمر مثبت می‌ماند**. نه با درمان منفی می‌شود و نه شدت بیماری را نشان می‌دهد — برای پیگیری کاملاً بی‌فایده است.\n\n**و آزمایش کبدی و CBC؟** آن‌ها پیگیری **عوارض دارو** هستند، نه پیگیری **پاسخ به درمان** — که دو کار متفاوت است و سؤال دنبال دومی است.",
 "This question tests a subtle but decisive rule: WARNING, A PATIENT TREATED FOR LESS THAN ONE MONTH COUNTS AS A NEW CASE.\n\nThis patient had about TWO WEEKS and stopped on his own — UNDER A MONTH. So despite the drug history he is a NEW CASE and receives the standard regimen: 2 MONTHS HRZE then 4 MONTHS HR.\n\nWHY IS THAT RULE LOGICAL? The reason is microbiological rather than administrative: for DRUG SELECTION PRESSURE to let a resistant population dominate, TIME is needed. An exposure shorter than a month has not been long enough to shift the resistance pattern meaningfully, so this patient's resistance risk is that of an untreated patient.\n\nWARNING, BY CONTRAST, had he taken more than a month he would count as RETURN AFTER DEFAULT, requiring a retreatment regimen plus drug susceptibility testing.\n\nAND NOW THE SECOND HALF OF THE KNOWLEDGE REQUIRED: HOW IS HE MONITORED?\n\nThe monitoring tool is the SPUTUM SMEAR — not radiography, not the skin test.\n\nTHE TIMING AND THE LOGIC OF EACH POINT:\n\nEND OF MONTH TWO — the end of the INTENSIVE PHASE. This test drives the next decision:\n- Negative -> move to the CONTINUATION PHASE\n- Still positive -> EXTEND the intensive phase by a month and repeat at month 3\n\nWARNING, END OF MONTH FIVE — the most important point, because it defines TREATMENT FAILURE:\nTREATMENT FAILURE = a positive smear at or after the end of month five.\nThat definition puts the patient onto the DRUG-RESISTANCE pathway.\n\nEND OF MONTH SIX — confirming CURE before stopping the drugs.\n\nWARNING, NOW WHY IS RADIOGRAPHY A POOR MONITORING TOOL? Two solid reasons:\n\n1. Radiological change resolves FAR MORE SLOWLY than the microbiological response; a patient may be fully cured while the film is still abnormal\n2. RESIDUAL FIBROSIS AND SCARRING may persist for years and be mistaken for active disease\n\nWARNING, AND WHY IS THE PPD NOT A MONITORING TOOL AT ALL? Because it STAYS POSITIVE FOR LIFE after infection. It neither reverts with treatment nor reflects severity — entirely useless for follow-up.\n\nAND LIVER TESTS AND A BLOOD COUNT? They monitor DRUG TOXICITY, not the RESPONSE TO TREATMENT — two different jobs, and the question asks about the second.",
 ["«احتساب درمان قبلی» نادرست است: درمان زیر یک ماه اصلاً به حساب نمی‌آید و دوره از نو شمرده می‌شود.",
  "پاسخ صحیح — درمان کمتر از یک ماه، بیمار را «مورد جدید» می‌کند و رژیم استاندارد شش‌ماهه کافی است.",
  "«بازگشت پس از غیبت» برای کسی است که **بیش از یک ماه** درمان گرفته و سپس غیبت کرده باشد.",
  "رژیم پنج‌دارویی هشت‌ماهه برای مورد درمان‌شده‌ی قبلی است، نه برای بیماری که فقط دو هفته دارو گرفته."],
 ["'Counting the previous treatment' is wrong: under a month does not count and the course restarts from zero.",
  "Correct — less than a month of treatment makes the patient a NEW CASE, and the standard six-month regimen suffices.",
  "'Return after default' applies to someone who took MORE than a month and then defaulted.",
  "A five-drug eight-month regimen is for a previously treated case, not for someone who took two weeks of drugs."],
 "**زیر یک ماه درمان = مورد جدید** (۲HRZE/4HR). پیگیری = اسمیر ماه ۲، ۵، ۶؛ شکست = اسمیر مثبت ماه ۵ یا بعد.",
 "UNDER ONE MONTH OF TREATMENT = A NEW CASE (2HRZE/4HR). Monitor by smear at months 2, 5, 6; failure = positive smear at or after month 5.",
 [H, WHO, NTP])


# ---------------------------------------------------------------- idx 209
add("book:209", "recall", "easy",
 "شایع‌ترین سل **خارج‌ریوی** = **لنفادنیت** (اسکروفولا)، به‌ویژه غدد گردنی.",
 "The commonest EXTRAPULMONARY tuberculosis is LYMPHADENITIS (scrofula), especially cervical nodes.",
 [
  "سل خارج‌ریوی حدود **۱۵ تا ۲۰ درصد** موارد سل در فرد ایمنی‌سالم را می‌سازد.",
  "⚠️ در **HIV مثبت** این نسبت بسیار بالاتر می‌رود — تا بیش از **۵۰ درصد**.",
  "چرا؟ چون مهار ایمنی سلولی، محدود نگه داشتن باسیل در ریه را ناممکن می‌کند.",
  "**ترتیب شیوع سل خارج‌ریوی را حفظ کنید:**",
  "⚠️ **یک — لنفادنیت** (شایع‌ترین)، به‌ویژه **غدد گردنی**؛ نام سنتی‌اش **اسکروفولا**.",
  "**دو — پلورال** (پلورزی سلی).",
  "**سه — ادراری-تناسلی**.",
  "**چهار — استخوان و مفصل**، که شایع‌ترین شکلش **اسپوندیلیت سلی (بیماری پات)** است.",
  "**پنج — مننژیت**، که **کشنده‌ترین** شکل است هرچند شایع‌ترین نیست.",
  "**شش — پریتونیت، پریکاردیت، و سل ارزنی**.",
  "**تابلوی لنفادنیت سلی:** توده‌ی **بدون درد**، آهسته‌رشد، اغلب **یک‌طرفه** در گردن.",
  "غدد ابتدا سفت و مجزا هستند، بعد به هم می‌چسبند (matted) و می‌توانند **فیستوله** شوند.",
  "⚠️ نکته‌ی مهم: بیمار اغلب **علائم سیستمیک ندارد** — نه تب، نه کاهش وزن.",
  "همین «سلامت ظاهری» باعث می‌شود تشخیص به تأخیر بیفتد.",
  "**تشخیص**: نمونه‌برداری (FNA یا بیوپسی اکسیزیونال) با نمای **گرانولوم کازئیفیه**.",
  "⚠️ و نکته‌ی عملی: **کشت نمونه‌ی بیوپسی حساسیت بالاتری از اسمیر دارد** — حدود ۷۰ تا ۸۰ درصد.",
  "**درمان**: همان رژیم استاندارد **۶ ماهه‌ی چهاردارویی** — یعنی مثل سل ریوی.",
  "⚠️ استثنا: **مننژیت سلی و سل استخوان** درمان طولانی‌تر (۹ تا ۱۲ ماه) می‌خواهند.",
 ],
 [
  "Extrapulmonary tuberculosis accounts for about 15-20% of cases in an immunocompetent person.",
  "WARNING: in HIV POSITIVE patients the proportion rises far higher — to more than 50%.",
  "Why? Because suppressed cellular immunity makes it impossible to confine the bacillus to the lung.",
  "MEMORISE THE ORDER OF FREQUENCY OF EXTRAPULMONARY DISEASE:",
  "WARNING, ONE — LYMPHADENITIS (the commonest), especially CERVICAL nodes; traditionally called SCROFULA.",
  "TWO — PLEURAL disease (tuberculous pleurisy).",
  "THREE — GENITOURINARY.",
  "FOUR — BONE AND JOINT, of which the commonest form is TUBERCULOUS SPONDYLITIS (Pott's disease).",
  "FIVE — MENINGITIS, which is the DEADLIEST form although not the commonest.",
  "SIX — PERITONITIS, PERICARDITIS and MILIARY disease.",
  "THE PICTURE OF TUBERCULOUS LYMPHADENITIS: a PAINLESS, slowly growing, usually UNILATERAL neck mass.",
  "The nodes are firm and discrete at first, then become MATTED and may FISTULATE.",
  "WARNING, an important point: the patient often has NO SYSTEMIC SYMPTOMS — no fever, no weight loss.",
  "That apparent wellness is exactly what delays the diagnosis.",
  "DIAGNOSIS: sampling (FNA or excisional biopsy) showing CASEATING GRANULOMA.",
  "WARNING, a practical point: CULTURE OF THE BIOPSY IS MORE SENSITIVE THAN SMEAR — about 70-80%.",
  "TREATMENT: the same standard SIX-MONTH FOUR-DRUG regimen — that is, as for pulmonary disease.",
  "WARNING, the exceptions: TUBERCULOUS MENINGITIS AND BONE DISEASE need longer treatment (9-12 months).",
 ],
 "سل خارج‌ریوی حدود **۱۵ تا ۲۰ درصد** موارد سل در فرد ایمنی‌سالم را می‌سازد. ⚠️ اما در **HIV مثبت** این نسبت تا بیش از **۵۰ درصد** بالا می‌رود — چون مهار ایمنی سلولی، محدود نگه داشتن باسیل در ریه را ناممکن می‌کند.\n\n**ترتیب شیوع را حفظ کنید:**\n\n⚠️ **۱. لنفادنیت** ← **شایع‌ترین**، به‌ویژه غدد گردنی (نام سنتی: **اسکروفولا**)\n**۲. پلورال** (پلورزی سلی)\n**۳. ادراری-تناسلی**\n**۴. استخوان و مفصل** ← شایع‌ترین شکلش **اسپوندیلیت سلی (بیماری پات)**\n**۵. مننژیت** ← **کشنده‌ترین**، هرچند شایع‌ترین نیست\n**۶. پریتونیت، پریکاردیت، سل ارزنی**\n\n**تابلوی بالینی لنفادنیت سلی:**\nتوده‌ی **بدون درد**، آهسته‌رشد، اغلب **یک‌طرفه** در گردن. غدد ابتدا سفت و مجزا هستند، بعد به هم می‌چسبند و می‌توانند به پوست **فیستوله** شوند.\n\n⚠️ **و نکته‌ای که باعث تأخیر تشخیص می‌شود:** بیمار اغلب **هیچ علامت سیستمیکی ندارد** — نه تب، نه کاهش وزن، نه تعریق شبانه. همین «سلامت ظاهری» است که پزشک را به سمت تشخیص‌های خوش‌خیم‌تر می‌برد.\n\n**تشخیص:** نمونه‌برداری (FNA یا بیوپسی اکسیزیونال) با نمای **گرانولوم کازئیفیه**. ⚠️ و یک نکته‌ی عملی: **کشت نمونه‌ی بافتی حساسیت بالاتری از اسمیر دارد** — حدود **۷۰ تا ۸۰ درصد**.\n\n**درمان:** همان رژیم استاندارد **۶ ماهه‌ی چهاردارویی**، دقیقاً مثل سل ریوی. ⚠️ **استثناها:** **مننژیت سلی** و **سل استخوان** درمان طولانی‌تری (۹ تا ۱۲ ماه) می‌خواهند، چون نفوذ دارو به آن بافت‌ها محدودتر است.",
 "Extrapulmonary tuberculosis accounts for about 15-20% of cases in an immunocompetent person. WARNING: in HIV-POSITIVE patients that rises to more than 50%, because suppressed cellular immunity makes it impossible to confine the bacillus to the lung.\n\nMEMORISE THE ORDER OF FREQUENCY:\n\nWARNING, 1. LYMPHADENITIS -> THE COMMONEST, especially cervical nodes (traditionally SCROFULA)\n2. PLEURAL (tuberculous pleurisy)\n3. GENITOURINARY\n4. BONE AND JOINT -> commonest form TUBERCULOUS SPONDYLITIS (Pott's disease)\n5. MENINGITIS -> the DEADLIEST, though not the commonest\n6. PERITONITIS, PERICARDITIS, MILIARY disease\n\nTHE CLINICAL PICTURE OF TUBERCULOUS LYMPHADENITIS:\nA PAINLESS, slowly growing, usually UNILATERAL neck mass. The nodes are firm and discrete at first, then become matted and may FISTULATE to the skin.\n\nWARNING, AND THE FEATURE THAT DELAYS DIAGNOSIS: the patient often has NO SYSTEMIC SYMPTOMS at all — no fever, no weight loss, no night sweats. That apparent wellness steers the clinician towards more benign diagnoses.\n\nDIAGNOSIS: sampling (FNA or excisional biopsy) showing CASEATING GRANULOMA. WARNING, a practical point: CULTURE OF THE TISSUE IS MORE SENSITIVE THAN SMEAR — about 70-80%.\n\nTREATMENT: the same standard SIX-MONTH FOUR-DRUG regimen, exactly as for pulmonary disease. WARNING, THE EXCEPTIONS: TUBERCULOUS MENINGITIS and BONE DISEASE require longer treatment (9-12 months), because drug penetration into those tissues is more limited.",
 ["اسپوندیلیت سلی (بیماری پات) شایع‌ترین شکل سل استخوانی است، ولی از لنفادنیت کمتر شایع است.",
  "پریتونیت سلی یکی از اشکال سل شکمی است و در فهرست شیوع پایین‌تر از لنفادنیت قرار دارد.",
  "پاسخ صحیح — لنفادنیت، به‌ویژه غدد گردنی، شایع‌ترین تظاهر سل خارج‌ریوی است.",
  "مننژیت سلی کشنده‌ترین شکل سل خارج‌ریوی است، ولی شایع‌ترین نیست."],
 ["Tuberculous spondylitis (Pott's disease) is the commonest form of skeletal TB but is less common than lymphadenitis.",
  "Tuberculous peritonitis is a form of abdominal TB and ranks below lymphadenitis in frequency.",
  "Correct — lymphadenitis, especially of the cervical nodes, is the commonest extrapulmonary manifestation.",
  "Tuberculous meningitis is the deadliest form of extrapulmonary TB, but not the commonest."],
 "خارج‌ریوی: **لنفادنیت شایع‌ترین**، **مننژیت کشنده‌ترین**. درمان ۶ ماه؛ استثنا: مننژیت و استخوان (۹–۱۲ ماه).",
 "Extrapulmonary: LYMPHADENITIS is commonest, MENINGITIS is deadliest. Six months of treatment; exceptions: meningitis and bone (9-12 months).",
 [H])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book18.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 18 lessons:', len(L))
