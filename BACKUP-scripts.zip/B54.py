# -*- coding: utf-8 -*-
"""Micro-lessons, batch 54 — tuberculosis part four: the adverse effects of the
antituberculous drugs. The largest single cluster in this chapter.

THE TOXICITY TABLE, LEARNED ONCE AND ANSWERING THIRTEEN QUESTIONS
-------------------------------------------------------------------
    ISONIAZID      HEPATITIS (dose-independent, age-dependent)
                   PERIPHERAL NEUROPATHY — pyridoxine (B6) depletion,
                       glove-and-stocking, PREVENTED BY PYRIDOXINE 25-50 mg
                   a lupus-like syndrome, and seizures in overdose

    RIFAMPICIN     ORANGE-RED discoloration of urine, tears, sweat (harmless
                       but must be explained, or the patient stops the drug)
                   POTENT INDUCTION OF CYTOCHROME P450 — this is the drug
                       INTERACTION drug: oral contraceptives, warfarin,
                       methadone, azoles, antiretrovirals, ciclosporin
                   IMMUNE-MEDIATED reactions, seen mainly with intermittent
                       dosing: THROMBOCYTOPENIA, haemolysis, ACUTE INTERSTITIAL
                       NEPHRITIS, shock, a flu-like syndrome
                   hepatitis, usually cholestatic

    PYRAZINAMIDE   HYPERURICAEMIA and ARTHRALGIA — it blocks renal urate
                       excretion; arthralgia is common, true gout is rare
                   HEPATITIS — the most hepatotoxic of the four
                   nausea and rash

    ETHAMBUTOL     OPTIC NEURITIS — loss of visual acuity and, characteristically,
                       LOSS OF RED-GREEN COLOUR DISCRIMINATION
                   dose-related, and NOT hepatotoxic
                   requires dose reduction in renal failure

TWO ORGANISING PRINCIPLES THAT DECIDE THE HARD QUESTIONS
----------------------------------------------------------
PRINCIPLE ONE — REVERSIBLE VERSUS PERMANENT STOP.
A drug-induced hepatitis resolves and THE SAME DRUG CAN USUALLY BE
REINTRODUCED, one at a time, under monitoring. But an IMMUNE-MEDIATED reaction
(rifampicin thrombocytopenia, haemolysis, shock, acute interstitial nephritis)
means the immune system has learned the drug: re-exposure can be FATAL, and
that drug is stopped FOREVER. Optic neuritis from ethambutol is likewise a
permanent stop, because rechallenge can blind.

PRINCIPLE TWO — WHEN TO STOP EVERYTHING IN HEPATOTOXICITY.
Stop all hepatotoxic drugs when:
    ALT/AST above 3x normal WITH SYMPTOMS (nausea, vomiting, abdominal pain,
        jaundice), or
    ALT/AST above 5x normal WITHOUT symptoms, or
    bilirubin rises
An ASYMPTOMATIC rise up to about 3x normal is common, usually transient, and
is managed by CONTINUING and repeating the test — because stopping needlessly
prolongs treatment and risks resistance.

That single distinction — symptomatic or not — separates two questions in this
chapter whose stems look almost identical.

RENAL FAILURE: WHICH DRUGS NEED ADJUSTMENT
--------------------------------------------
    isoniazid and rifampicin   hepatic clearance — NO adjustment needed
    pyrazinamide and ethambutol  RENALLY cleared — DOSE REDUCTION or
                                 three-times-weekly dosing after dialysis
Ethambutol is the one whose accumulation in renal failure directly causes
optic neuritis, so it is the drug that most often has to be left out.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022) —
tuberculosis; ATS/CDC/IDSA hepatotoxicity of antituberculosis therapy
(Am J Respir Crit Care Med 2006;174:935).
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — tuberculosis")
ATS = ("Saukkonen JJ et al. An official ATS statement: hepatotoxicity of "
       "antituberculosis therapy. Am J Respir Crit Care Med 2006;174:935")
REFS = [H]
REFSA = [H, ATS]

# ==================================================== THE TOXICITY TABLE
TOX_FA = [
    "⚠️ **جدول عوارض چهار داروی خط اول را یک‌بار بسازید، سیزده سؤال حل می‌شود.**",
    "**ایزونیازید: هپاتیت، و نوروپاتی محیطی از کمبود ویتامین B6.**",
    "**نوروپاتی به‌شکل دستکش و جوراب، و با پیریدوکسین ۲۵ تا ۵۰ میلی‌گرم پیشگیری می‌شود.**",
    "⚠️ **ریفامپین: رنگ نارنجی ادرار و اشک — بی‌ضرر، ولی باید به بیمار گفته شود.**",
    "**ریفامپین قوی‌ترین القاکننده‌ی سیتوکروم P450 است — داروی تداخل‌ها.**",
    "**و واکنش‌های ایمنی: ترومبوسیتوپنی، همولیز، نفریت بینابینی حاد، شوک.**",
    "**پیرازینامید: هیپراوریسمی و درد مفاصل — دفع کلیوی اورات را مهار می‌کند.**",
    "**و پیرازینامید کبدی‌ترین داروی این چهارتاست.**",
    "⚠️ **اتامبوتول: نوریت اپتیک — کاهش دید و از دست رفتن تمایز رنگ قرمز-سبز.**",
    "**و اتامبوتول تنها داروی این چهارتاست که کبدی نیست.**",
    "⚠️ **قاعده‌ی طلایی: هپاتیت برگشت‌پذیر است، ولی واکنش ایمنی همیشگی است.**",
    "**داروی مسبب واکنش ایمنی، هرگز دوباره شروع نمی‌شود.**",
]
TOX_EN = [
    "WARNING: BUILD THE TOXICITY TABLE OF THE FOUR FIRST-LINE DRUGS ONCE AND THIRTEEN QUESTIONS DISSOLVE.",
    "ISONIAZID: hepatitis, and peripheral neuropathy from vitamin B6 depletion.",
    "The neuropathy is glove-and-stocking, and it is prevented by pyridoxine 25 to 50 mg.",
    "WARNING: RIFAMPICIN — ORANGE DISCOLORATION of urine and tears; harmless, but the patient must be told.",
    "Rifampicin is the most potent inducer of cytochrome P450 — it is THE interaction drug.",
    "And its immune reactions: thrombocytopenia, haemolysis, acute interstitial nephritis, shock.",
    "PYRAZINAMIDE: hyperuricaemia and arthralgia — it blocks renal urate excretion.",
    "And pyrazinamide is the most hepatotoxic of the four.",
    "WARNING: ETHAMBUTOL — OPTIC NEURITIS, with loss of acuity and of RED-GREEN colour discrimination.",
    "And ethambutol is the only one of the four that is NOT hepatotoxic.",
    "WARNING, THE GOLDEN RULE: HEPATITIS IS REVERSIBLE, BUT AN IMMUNE REACTION IS PERMANENT.",
    "The drug that caused an immune reaction is never restarted.",
]

add("book:236", "recall", "medium",
    "**درد مفاصل حین درمان سل: پیرازینامید.**",
    "Joint pain during antituberculous treatment: pyrazinamide.",
    TOX_FA, TOX_EN,
    "این سؤال کوتاه، یک ارتباط ساده ولی پرتکرار را می‌سنجد.\n\n"
    "**بیمار پس از شروع درمان سل، دچار درد مفاصل می‌شود. کدام دارو؟ پیرازینامید.**\n\n"
    "**مکانیسم را بفهمید، تا هرگز فراموش نکنید:**\n\n"
    "**پیرازینامید در بدن به پیرازینوئیک اسید تبدیل می‌شود.** این متابولیت، "
    "**بازجذب اورات را در توبول کلیه افزایش و دفع آن را مهار می‌کند**. نتیجه: "
    "**اسید اوریک خون بالا می‌رود (هیپراوریسمی).**\n\n"
    "**و این هیپراوریسمی، دو تظاهر متفاوت دارد که نباید قاطی شوند:**\n\n"
    "⚠️ **۱. آرترالژی (درد مفاصل) — بسیار شایع.** تا حدود ۴۰٪ بیماران. معمولاً شانه‌ها "
    "و زانوها. **این درد لزوماً با کریستال نقرس همراه نیست** و بیشتر یک اثر مستقیم "
    "است. **درمان: NSAID، و ادامه‌ی دارو.**\n\n"
    "**۲. حمله‌ی واقعی نقرس — نادر.** فقط در بیمارانی که زمینه‌ی نقرس دارند.\n\n"
    "**نکته‌ی بالینی مهم: آرترالژی پیرازینامید به‌ندرت نیازمند قطع دارو است.** با "
    "ضددرد کنترل می‌شود و **رژیم دست‌نخورده می‌ماند** — چون پیرازینامید همان دارویی "
    "است که فاز نگهدارنده را از ۷ ماه به ۴ ماه کوتاه کرده.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**ایزونیازید** — عارضه‌های شاخصش **هپاتیت** و **نوروپاتی محیطی** (از کمبود "
    "پیریدوکسین) است، نه درد مفصل. (هرچند سندرم شبه‌لوپوس نادر ایزونیازید می‌تواند "
    "آرترالژی بدهد، ولی این پاسخ کلاسیک سؤال نیست.)\n\n"
    "**ریفامپین** — رنگ نارنجی ترشحات، تداخل‌های دارویی گسترده، و واکنش‌های ایمنی "
    "(ترومبوسیتوپنی، نفریت بینابینی). **درد مفصل، عارضه‌ی شاخصش نیست.**\n\n"
    "**اتامبوتول** — تنها عارضه‌ی مهمش **نوریت اپتیک** است. **اتامبوتول نه کبد را "
    "می‌زند، نه مفصل را.**\n\n"
    "⚠️ **قاعده‌ی حافظه: «Z» را به «جوینت» (joint) گره بزنید — پیرازینامید و درد "
    "مفصل. و «E» را به «چشم» (eye) — اتامبوتول و نوریت اپتیک.**",
    "This short question tests a simple but frequently repeated association.\n\n"
    "A PATIENT DEVELOPS JOINT PAIN AFTER STARTING ANTITUBERCULOUS TREATMENT. WHICH DRUG? PYRAZINAMIDE.\n\n"
    "UNDERSTAND THE MECHANISM AND YOU WILL NEVER FORGET IT:\n\n"
    "PYRAZINAMIDE IS CONVERTED TO PYRAZINOIC ACID. That metabolite INCREASES URATE REABSORPTION AND BLOCKS ITS EXCRETION IN THE RENAL TUBULE. The result: THE SERUM URIC ACID RISES (HYPERURICAEMIA).\n\n"
    "AND THAT HYPERURICAEMIA HAS TWO DIFFERENT MANIFESTATIONS THAT MUST NOT BE CONFUSED:\n\n"
    "WARNING, 1. ARTHRALGIA (joint pain) — VERY COMMON, in up to about 40 % of patients, typically shoulders and knees. THIS PAIN IS NOT NECESSARILY ACCOMPANIED BY GOUT CRYSTALS and is largely a direct effect. TREATMENT: an NSAID, and CONTINUE THE DRUG.\n\n"
    "2. A TRUE GOUT ATTACK — RARE, and generally only in patients with pre-existing gout.\n\n"
    "AN IMPORTANT CLINICAL POINT: PYRAZINAMIDE ARTHRALGIA RARELY REQUIRES STOPPING THE DRUG. It is controlled with an analgesic and THE REGIMEN STAYS INTACT — because pyrazinamide is the very drug that shortened the continuation phase from 7 months to 4.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ISONIAZID — its characteristic effects are HEPATITIS and PERIPHERAL NEUROPATHY (from pyridoxine depletion), not joint pain. (Its rare lupus-like syndrome can cause arthralgia, but that is not the classic answer here.)\n\n"
    "RIFAMPICIN — orange secretions, extensive drug interactions, and immune reactions (thrombocytopenia, interstitial nephritis). JOINT PAIN IS NOT ITS CHARACTERISTIC EFFECT.\n\n"
    "ETHAMBUTOL — its only important adverse effect is OPTIC NEURITIS. ETHAMBUTOL STRIKES NEITHER LIVER NOR JOINT.\n\n"
    "WARNING, A MEMORY RULE: tie 'Z' to JOINT — pyrazinamide and joint pain. And tie 'E' to EYE — ethambutol and optic neuritis.",
    ["عارضه‌های شاخصش هپاتیت و نوروپاتی محیطی است، نه درد مفصل.",
     "رنگ نارنجی، تداخل دارویی و واکنش‌های ایمنی؛ درد مفصل شاخص آن نیست.",
     "پاسخ صحیح — پیرازینوئیک اسید دفع کلیوی اورات را مهار می‌کند و آرترالژی می‌دهد.",
     "تنها عارضه‌ی مهمش نوریت اپتیک است؛ نه کبد را می‌زند نه مفصل را."],
    ["Its characteristic effects are hepatitis and peripheral neuropathy, not joint pain.",
     "Orange secretions, drug interactions and immune reactions; joint pain is not characteristic.",
     "Correct — pyrazinoic acid blocks renal urate excretion and causes arthralgia.",
     "Its only important adverse effect is optic neuritis; it strikes neither liver nor joint."],
    "**Z را به جوینت گره بزنید و E را به چشم — پیرازینامید مفصل، اتامبوتول چشم.**",
    "Tie Z to JOINT and E to EYE — pyrazinamide the joint, ethambutol the eye.",
    REFS)

add("book:246", "recall", "medium",
    "**اتامبوتول تنها داروی خط اول است که هپاتوتوکسیک نیست.**",
    "Ethambutol is the only first-line drug that is not hepatotoxic.",
    TOX_FA, TOX_EN,
    "این سؤال یک واقعیت بسیار کاربردی را می‌سنجد که پایه‌ی چند تصمیم بالینی است.\n\n"
    "**سؤال: کدام‌یک از داروهای ضدسل هپاتوتوکسیسیتی ندارد؟ پاسخ: اتامبوتول.**\n\n"
    "**سه داروی دیگر همگی کبد را می‌زنند، ولی به شیوه‌های متفاوت:**\n\n"
    "**ایزونیازید** — هپاتیت **سلولی (هپاتوسلولار)**. خطرش **با سن به‌شدت بالا "
    "می‌رود**: زیر ۲۰ سال تقریباً صفر، بالای ۵۰ سال چند درصد. متابولیت‌های سمّی "
    "(استیل‌هیدرازین) عامل‌اند.\n\n"
    "**ریفامپین** — بیشتر **کلستاتیک**، و همچنین **هیپربیلی‌روبینمی گذرا** در روزهای "
    "اول از راه رقابت با بیلی‌روبین بر سر جذب کبدی (که خودش هپاتیت نیست).\n\n"
    "⚠️ **پیرازینامید** — **کبدی‌ترین داروی این چهارتا**، و **وابسته به دوز**. به همین "
    "دلیل وقتی رژیم باید در بیمار کبدی سبک شود، **پیرازینامید اولین داروی حذف‌شونده "
    "است**.\n\n"
    "**و اتامبوتول: هیچ‌کدام.** عارضه‌ی مهمش فقط **نوریت اپتیک** است.\n\n"
    "**چرا این واقعیت این‌قدر مهم است؟ سه کاربرد بالینی مستقیم دارد:**\n\n"
    "**۱. در بیمار با بیماری کبدی زمینه‌ای** (سیروز، هپاتیت مزمن فعال)، رژیم‌های "
    "**کم‌هپاتوتوکسیک** ساخته می‌شوند و **اتامبوتول همیشه در آن‌ها هست**. مثلاً "
    "**HRE بدون Z**، یا در نارسایی شدید کبدی رژیم‌های بدون H و Z مانند "
    "**اتامبوتول + استرپتومایسین + فلوروکینولون**.\n\n"
    "**۲. هنگام بازگرداندن داروها پس از هپاتیت دارویی**، اتامبوتول را می‌توان بدون "
    "نگرانی ادامه داد در حالی که سه داروی دیگر یکی‌یکی و با پایش برمی‌گردند.\n\n"
    "**۳. در پایش آزمایشگاهی**، وقتی آنزیم کبدی بالا می‌رود، اتامبوتول هرگز مظنون "
    "نیست.\n\n"
    "⚠️ **ولی یک هشدار متقابل: اتامبوتول بی‌خطر نیست، فقط خطرش جای دیگری است.** "
    "**در نارسایی کلیه تجمع می‌کند** (چون دفع کلیوی دارد) و **نوریت اپتیک می‌دهد**. "
    "پس در بیمار دیالیزی، همان اتامبوتولِ «بی‌خطر برای کبد» تبدیل به خطرناک‌ترین "
    "داروی رژیم می‌شود.\n\n"
    "**درس: «بی‌خطر» همیشه نسبی است — بپرسید «برای کدام عضو؟»**",
    "This question tests a highly practical fact that underlies several clinical decisions.\n\n"
    "THE QUESTION: which antituberculous drug is NOT hepatotoxic? THE ANSWER: ETHAMBUTOL.\n\n"
    "THE OTHER THREE ALL STRIKE THE LIVER, BUT IN DIFFERENT WAYS:\n\n"
    "ISONIAZID — HEPATOCELLULAR hepatitis. Its risk RISES STEEPLY WITH AGE: nearly zero under 20, several per cent over 50. Toxic metabolites (acetylhydrazine) are responsible.\n\n"
    "RIFAMPICIN — more CHOLESTATIC, and it also causes a TRANSIENT HYPERBILIRUBINAEMIA in the first days by competing with bilirubin for hepatic uptake (which is not hepatitis at all).\n\n"
    "WARNING: PYRAZINAMIDE — THE MOST HEPATOTOXIC OF THE FOUR, and DOSE-DEPENDENT. That is why, when a regimen must be lightened in a patient with liver disease, PYRAZINAMIDE IS THE FIRST DRUG TO GO.\n\n"
    "AND ETHAMBUTOL: none of these. Its only important effect is OPTIC NEURITIS.\n\n"
    "WHY DOES THIS FACT MATTER SO MUCH? IT HAS THREE DIRECT CLINICAL USES:\n\n"
    "1. IN A PATIENT WITH UNDERLYING LIVER DISEASE (cirrhosis, chronic active hepatitis), LOW-HEPATOTOXICITY regimens are built and ETHAMBUTOL IS ALWAYS IN THEM — for example HRE WITHOUT Z, or, in severe hepatic failure, regimens without H and Z such as ETHAMBUTOL PLUS STREPTOMYCIN PLUS A FLUOROQUINOLONE.\n\n"
    "2. WHEN REINTRODUCING DRUGS AFTER DRUG-INDUCED HEPATITIS, ethambutol can be continued without concern while the other three are returned one at a time under monitoring.\n\n"
    "3. IN LABORATORY MONITORING, when transaminases rise, ethambutol is never the suspect.\n\n"
    "WARNING, BUT A COUNTERBALANCING CAUTION: ETHAMBUTOL IS NOT HARMLESS, ITS HARM IS SIMPLY ELSEWHERE. IT ACCUMULATES IN RENAL FAILURE (being renally cleared) AND CAUSES OPTIC NEURITIS. So in a dialysis patient the very drug that is 'safe for the liver' becomes the most dangerous drug in the regimen.\n\n"
    "THE LESSON: 'SAFE' IS ALWAYS RELATIVE — ASK 'SAFE FOR WHICH ORGAN?'",
    ["هپاتیت هپاتوسلولار می‌دهد و خطرش با سن به‌شدت بالا می‌رود.",
     "هپاتیت کلستاتیک و هیپربیلی‌روبینمی گذرا می‌دهد.",
     "پاسخ صحیح — تنها داروی خط اول بدون سمّیت کبدی؛ عارضه‌اش نوریت اپتیک است.",
     "کبدی‌ترین داروی خط اول و وابسته به دوز؛ اولین داروی حذف‌شونده در بیمار کبدی."],
    ["Causes hepatocellular hepatitis, with risk rising steeply with age.",
     "Causes cholestatic hepatitis and a transient hyperbilirubinaemia.",
     "Correct — the only first-line drug without hepatotoxicity; its adverse effect is optic neuritis.",
     "The most hepatotoxic first-line drug and dose-dependent; the first to be dropped in liver disease."],
    "**«بی‌خطر» نسبی است — اتامبوتول برای کبد بی‌خطر است ولی در نارسایی کلیه چشم را می‌زند.**",
    "'Safe' is relative — ethambutol is safe for the liver but blinds in renal failure.",
    REFSA)

add("book:257", "vignette", "medium",
    "**گزگز دستکش و جورابی حین درمان سل: ایزونیازید و کمبود ویتامین B6.**",
    "Glove-and-stocking paraesthesia during antituberculous treatment: isoniazid and vitamin B6 depletion.",
    TOX_FA + [
        "⚠️ **در بارداری، پیریدوکسین برای همه‌ی بیماران تحت ایزونیازید الزامی است.**",
        "**چون نیاز به B6 در بارداری بیشتر است و خطر نوروپاتی بالاتر.**",
    ],
    TOX_EN + [
        "WARNING: IN PREGNANCY, PYRIDOXINE IS MANDATORY FOR EVERY PATIENT ON ISONIAZID.",
        "Because the requirement for B6 is higher in pregnancy and the neuropathy risk greater.",
    ],
    "این سؤال یک عارضه‌ی کاملاً قابل‌پیشگیری را می‌سنجد — و همین «قابل‌پیشگیری بودن» "
    "درس اصلی است.\n\n"
    "**بیمار: خانم حامله تحت درمان ضدسل، با گزگز و بی‌حسی دست‌ها و پاها به‌صورت "
    "دستکش و جوراب. کدام دارو؟**\n\n"
    "**پاسخ: ایزونیازید.**\n\n"
    "**مکانیسم، زیبا و کاملاً منطقی است:**\n\n"
    "**ایزونیازید از نظر ساختاری شبیه پیریدوکسین (ویتامین B6) است.** این شباهت باعث "
    "می‌شود ایزونیازید:\n\n"
    "**۱. با پیریدوکسال فسفات (فرم فعال B6) کمپلکس بسازد و دفع کلیوی آن را افزایش "
    "دهد.**\n\n"
    "**۲. آنزیم پیریدوکسین کیناز را مهار کند** — یعنی تبدیل B6 به فرم فعالش را "
    "مختل کند.\n\n"
    "**نتیجه: کمبود عملکردی ویتامین B6.**\n\n"
    "**و B6 برای متابولیسم عصبی، به‌ویژه سنتز میلین و نوروترانسمیترها، ضروری است. "
    "کمبودش، نوروپاتی محیطی حسی می‌دهد — دقیقاً به‌شکل دستکش و جوراب، چون "
    "بلندترین آکسون‌ها زودتر آسیب می‌بینند.**\n\n"
    "⚠️ **مهم‌ترین نکته: این عارضه کاملاً قابل‌پیشگیری است.**\n\n"
    "**پیریدوکسین ۲۵ تا ۵۰ میلی‌گرم روزانه**، هم‌زمان با ایزونیازید. **این یک قرص "
    "ارزان است که یک عارضه‌ی ناتوان‌کننده را حذف می‌کند.**\n\n"
    "**در چه کسانی پیریدوکسین الزامی است؟**\n\n"
    "**زنان باردار و شیرده** ✔ (بیمار همین سؤال) · **بیماران دیابتی** · **الکلی‌ها** · "
    "**بیماران HIV مثبت** · **نارسایی کلیه** · **سوءتغذیه** · **سالمندان** · "
    "**بیماران با نوروپاتی زمینه‌ای**\n\n"
    "**در عمل، بسیاری از مراکز آن را برای همه‌ی بیماران تجویز می‌کنند، چون ارزان و "
    "بی‌خطر است.**\n\n"
    "**نکته‌ی مکمل درباره‌ی بارداری: ایزونیازید در بارداری بی‌خطر است و نباید قطع شود. "
    "سل درمان‌نشده برای مادر و جنین بسیار خطرناک‌تر است. فقط پیریدوکسین را فراموش "
    "نکنید.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**اتامبوتول** — عصب می‌زند، ولی **عصب بینایی (زوج دوم)**، نه اعصاب محیطی. "
    "**نوریت اپتیک، نه نوروپاتی محیطی.**\n\n"
    "**ریفامپین** — رنگ نارنجی، تداخل‌ها، واکنش‌های ایمنی. **نوروپاتی محیطی نمی‌دهد.**\n\n"
    "**پیرازینامید** — هیپراوریسمی، آرترالژی، هپاتیت. **نوروپاتی محیطی نمی‌دهد.**",
    "This question tests a wholly preventable adverse effect — and that preventability is the main lesson.\n\n"
    "THE PATIENT: a pregnant woman on antituberculous treatment with tingling and numbness of hands and feet in a GLOVE-AND-STOCKING distribution. Which drug?\n\n"
    "THE ANSWER: ISONIAZID.\n\n"
    "THE MECHANISM IS ELEGANT AND ENTIRELY LOGICAL:\n\n"
    "ISONIAZID IS STRUCTURALLY SIMILAR TO PYRIDOXINE (VITAMIN B6). That similarity means isoniazid:\n\n"
    "1. FORMS A COMPLEX WITH PYRIDOXAL PHOSPHATE (the active form of B6) AND INCREASES ITS RENAL EXCRETION.\n\n"
    "2. INHIBITS PYRIDOXINE KINASE — impairing the conversion of B6 into its active form.\n\n"
    "THE RESULT: A FUNCTIONAL VITAMIN B6 DEFICIENCY.\n\n"
    "AND B6 IS ESSENTIAL FOR NEURAL METABOLISM, especially myelin and neurotransmitter synthesis. Its deficiency produces a SENSORY PERIPHERAL NEUROPATHY — precisely in a glove-and-stocking pattern, because the longest axons fail first.\n\n"
    "WARNING, THE MOST IMPORTANT POINT: THIS COMPLICATION IS ENTIRELY PREVENTABLE.\n\n"
    "PYRIDOXINE 25 TO 50 MG DAILY, given alongside the isoniazid. IT IS A CHEAP TABLET THAT ABOLISHES A DISABLING COMPLICATION.\n\n"
    "IN WHOM IS PYRIDOXINE MANDATORY?\n\n"
    "PREGNANT AND BREASTFEEDING WOMEN (this patient), DIABETICS, PEOPLE WITH ALCOHOL DEPENDENCE, HIV-POSITIVE PATIENTS, RENAL FAILURE, MALNUTRITION, THE ELDERLY, AND ANYONE WITH A PRE-EXISTING NEUROPATHY.\n\n"
    "In practice many centres give it to every patient, because it is cheap and safe.\n\n"
    "A SUPPLEMENTARY POINT ON PREGNANCY: ISONIAZID IS SAFE IN PREGNANCY AND MUST NOT BE STOPPED. Untreated tuberculosis is far more dangerous for both mother and fetus. Just do not forget the pyridoxine.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ETHAMBUTOL — it does strike a nerve, but THE OPTIC NERVE (the second cranial nerve), not peripheral nerves. OPTIC NEURITIS, NOT PERIPHERAL NEUROPATHY.\n\n"
    "RIFAMPICIN — orange secretions, interactions, immune reactions. IT DOES NOT CAUSE PERIPHERAL NEUROPATHY.\n\n"
    "PYRAZINAMIDE — hyperuricaemia, arthralgia, hepatitis. IT DOES NOT CAUSE PERIPHERAL NEUROPATHY.",
    ["عصب بینایی را می‌زند، نه اعصاب محیطی؛ نوریت اپتیک نه نوروپاتی دستکش و جورابی.",
     "رنگ نارنجی، تداخل‌ها و واکنش‌های ایمنی؛ نوروپاتی محیطی نمی‌دهد.",
     "پاسخ صحیح — ایزونیازید ویتامین B6 را تخلیه می‌کند؛ با پیریدوکسین پیشگیری می‌شود.",
     "هیپراوریسمی، آرترالژی و هپاتیت؛ نوروپاتی محیطی نمی‌دهد."],
    ["Strikes the optic nerve, not peripheral nerves; optic neuritis rather than a glove-and-stocking neuropathy.",
     "Orange secretions, interactions and immune reactions; it does not cause peripheral neuropathy.",
     "Correct — isoniazid depletes vitamin B6; it is prevented by pyridoxine.",
     "Hyperuricaemia, arthralgia and hepatitis; it does not cause peripheral neuropathy."],
    "**نوروپاتی ایزونیازید کاملاً قابل‌پیشگیری است — پیریدوکسین ۲۵ تا ۵۰ میلی‌گرم را فراموش نکنید.**",
    "Isoniazid neuropathy is wholly preventable — never forget pyridoxine 25 to 50 mg.",
    REFS)

# ==================================================== OPTIC NEURITIS
EYE_FA = [
    "⚠️ **نوریت اپتیک اتامبوتول، یک توقف دائمی است — نه موقت.**",
    "**تظاهر: کاهش حدت بینایی، اسکوتوم مرکزی، و از دست رفتن تمایز قرمز-سبز.**",
    "**از دست رفتن رنگ قرمز-سبز اغلب نخستین نشانه است.**",
    "**وابسته به دوز و به مدت مصرف است.**",
    "⚠️ **و در نارسایی کلیه بسیار خطرناک‌تر، چون اتامبوتول دفع کلیوی دارد.**",
    "**پس در بیمار دیالیزی، دوز باید کاهش یابد یا دارو حذف شود.**",
    "**پایش: حدت بینایی و دید رنگی پیش از شروع، و سپس ماهانه.**",
    "⚠️ **قاعده‌ی طلایی: به‌محض شک به نوریت، اتامبوتول برای همیشه قطع می‌شود.**",
    "**چون ادامه یا شروع مجدد، می‌تواند به کوری دائمی برسد.**",
    "**بهبود پس از قطع، معمولاً کند است — هفته‌ها تا ماه‌ها.**",
    "**و در موارد پیشرفته، ممکن است کامل نشود.**",
    "**رژیم بدون اتامبوتول ادامه می‌یابد؛ سه داروی دیگر کافی‌اند.**",
]
EYE_EN = [
    "WARNING: ETHAMBUTOL OPTIC NEURITIS IS A PERMANENT STOP, NOT A TEMPORARY ONE.",
    "Presentation: reduced visual acuity, a central scotoma, and loss of red-green discrimination.",
    "Loss of red-green colour vision is often the FIRST sign.",
    "It depends on both dose and duration.",
    "WARNING, AND IT IS FAR MORE DANGEROUS IN RENAL FAILURE, because ethambutol is renally cleared.",
    "So in a dialysis patient the dose must be reduced or the drug omitted.",
    "Monitoring: visual acuity and colour vision before starting, then monthly.",
    "WARNING, THE GOLDEN RULE: AT THE FIRST SUSPICION OF NEURITIS, ETHAMBUTOL IS STOPPED FOREVER.",
    "Because continuing it, or restarting it, can end in permanent blindness.",
    "Recovery after stopping is usually slow — weeks to months.",
    "And in advanced cases it may never be complete.",
    "The regimen continues without ethambutol; the other three drugs suffice.",
]

add("book:247", "vignette", "medium",
    "**نوریت اپتیک در ماه دوم درمان: اتامبوتول را برای همیشه حذف کنید.**",
    "Optic neuritis in the second month of treatment: remove ethambutol permanently.",
    EYE_FA, EYE_EN,
    "این سؤال دو چیز را با هم می‌سنجد: **کدام دارو؟** و **حذف موقت یا دائم؟** — و "
    "بخش دوم سخت‌تر و مهم‌تر است.\n\n"
    "**بیمار: خانم ۶۸ ساله تحت درمان چهاردارویی ضدسل، که در ماه دوم دچار نوریت "
    "اپتیک شده است.**\n\n"
    "**بخش اول آسان است: نوریت اپتیک = اتامبوتول.** این ارتباط، اختصاصی‌ترین "
    "ارتباط دارو-عارضه در کل فصل است.\n\n"
    "**تظاهرات: کاهش حدت بینایی، اسکوتوم مرکزی، و — به‌طور مشخص — از دست رفتن تمایز "
    "رنگ قرمز و سبز.** آن آخری اغلب **نخستین علامت** است و به همین دلیل در پایش، "
    "**دید رنگی** را جدا از حدت بینایی می‌سنجند.\n\n"
    "⚠️ **حالا بخش دشوار و حیاتی: چرا حذف کامل و نه موقت؟**\n\n"
    "**سه دلیل:**\n\n"
    "**۱. آسیب می‌تواند برگشت‌ناپذیر باشد.** نوریت اپتیک اتامبوتول اگر زود قطع شود، "
    "معمولاً طی هفته‌ها تا ماه‌ها بهبود می‌یابد. **ولی اگر ادامه یابد یا دوباره شروع "
    "شود، آسیب می‌تواند دائمی شود و به کوری برسد.**\n\n"
    "**۲. شروع مجدد، خطر را برمی‌گرداند.** برخلاف هپاتیت دارویی که پس از نرمال شدن "
    "آنزیم‌ها می‌توان دارو را با احتیاط برگرداند، **در نوریت اپتیک شروع مجدد ممنوع "
    "است**. سود احتمالی، به‌هیچ‌وجه ارزش خطر کوری را ندارد.\n\n"
    "**۳. و مهم‌ترین دلیل عملی: اتامبوتول ضعیف‌ترین داروی رژیم است.** نقشش صرفاً "
    "**نگهبانی در برابر مقاومت احتمالی به ایزونیازید** است. **رژیم بدون اتامبوتول با "
    "سه داروی دیگر (HRZ) کاملاً کارآمد است.** یعنی هزینه‌ی حذفش ناچیز و سود آن "
    "(حفظ بینایی) عظیم است.\n\n"
    "**سن بیمار هم مهم است: ۶۸ سال.** در سالمندان، **کاهش عملکرد کلیه شایع است** و "
    "چون اتامبوتول **دفع کلیوی** دارد، در همین بیمار احتمالاً **تجمع دارو** رخ داده "
    "و همان علت نوریت بوده.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**حذف کامل پیرازینامید** — داروی اشتباه. **پیرازینامید نوریت اپتیک نمی‌دهد**؛ "
    "عارضه‌های آن آرترالژی و هپاتیت است.\n\n"
    "⚠️ **حذف موقت اتامبوتول تا رفع علائم** — **داروی درست، تصمیم غلط، و خطرناک.** "
    "«موقت» یعنی قصد شروع مجدد دارید — و شروع مجدد اتامبوتول پس از نوریت اپتیک، "
    "**می‌تواند بینایی بیمار را برای همیشه بگیرد.**\n\n"
    "**حذف موقت پیرازینامید** — هم داروی اشتباه، هم تصمیم اشتباه.",
    "This question tests two things at once: WHICH DRUG? and TEMPORARY OR PERMANENT REMOVAL? — and the second part is harder and more important.\n\n"
    "THE PATIENT: a 68-year-old woman on four-drug antituberculous therapy who develops optic neuritis in the second month.\n\n"
    "THE FIRST PART IS EASY: OPTIC NEURITIS EQUALS ETHAMBUTOL. This is the most specific drug-to-effect link in the whole chapter.\n\n"
    "THE FEATURES: reduced visual acuity, a central scotoma, and — characteristically — LOSS OF RED-GREEN COLOUR DISCRIMINATION. That last is often the FIRST sign, which is why monitoring tests COLOUR VISION separately from acuity.\n\n"
    "WARNING, NOW THE DIFFICULT AND VITAL PART: WHY PERMANENT AND NOT TEMPORARY REMOVAL?\n\n"
    "THREE REASONS:\n\n"
    "1. THE DAMAGE CAN BE IRREVERSIBLE. Ethambutol optic neuritis, if stopped early, usually recovers over weeks to months. BUT IF THE DRUG IS CONTINUED OR RESTARTED, THE DAMAGE CAN BECOME PERMANENT AND END IN BLINDNESS.\n\n"
    "2. RECHALLENGE BRINGS THE RISK BACK. Unlike drug-induced hepatitis, where the drug can be cautiously reintroduced once transaminases normalise, IN OPTIC NEURITIS RECHALLENGE IS FORBIDDEN. The possible benefit in no way justifies the risk of blindness.\n\n"
    "3. AND THE MOST IMPORTANT PRACTICAL REASON: ETHAMBUTOL IS THE WEAKEST DRUG IN THE REGIMEN. Its role is merely TO GUARD AGAINST POSSIBLE ISONIAZID RESISTANCE. A REGIMEN WITHOUT ETHAMBUTOL, USING THE OTHER THREE (HRZ), IS FULLY EFFECTIVE. So the cost of removing it is trivial and the benefit — preserved sight — is enormous.\n\n"
    "THE PATIENT'S AGE MATTERS TOO: 68. In the elderly REDUCED RENAL FUNCTION IS COMMON, and since ethambutol is RENALLY CLEARED, this patient has probably ACCUMULATED the drug — which is likely why the neuritis occurred.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "PERMANENTLY REMOVING PYRAZINAMIDE — the wrong drug. PYRAZINAMIDE DOES NOT CAUSE OPTIC NEURITIS; its effects are arthralgia and hepatitis.\n\n"
    "WARNING: TEMPORARILY REMOVING ETHAMBUTOL UNTIL SYMPTOMS RESOLVE — THE RIGHT DRUG, THE WRONG AND DANGEROUS DECISION. 'Temporary' implies intent to restart — and restarting ethambutol after optic neuritis CAN TAKE THE PATIENT'S SIGHT FOR GOOD.\n\n"
    "TEMPORARILY REMOVING PYRAZINAMIDE — both the wrong drug and the wrong decision.",
    ["داروی اشتباه؛ پیرازینامید نوریت اپتیک نمی‌دهد بلکه آرترالژی و هپاتیت می‌دهد.",
     "داروی درست ولی تصمیم خطرناک؛ شروع مجدد اتامبوتول پس از نوریت می‌تواند کور کند.",
     "پاسخ صحیح — حذف دائمی اتامبوتول؛ ضعیف‌ترین داروی رژیم و پرخطرترین برای چشم.",
     "هم داروی اشتباه و هم تصمیم اشتباه."],
    ["The wrong drug; pyrazinamide causes arthralgia and hepatitis, not optic neuritis.",
     "The right drug but a dangerous decision; restarting ethambutol after neuritis can blind.",
     "Correct — permanent removal of ethambutol, the weakest drug in the regimen and the one that threatens the eye.",
     "Both the wrong drug and the wrong decision."],
    "**نوریت اپتیک یعنی اتامبوتول برای همیشه می‌رود — ضعیف‌ترین دارو، بزرگ‌ترین خطر.**",
    "Optic neuritis means ethambutol goes for good — the weakest drug carrying the gravest risk.",
    REFS)

add("book:237", "vignette", "medium",
    "**بیمار همودیالیزی: اتامبوتول بهتر است در رژیم نباشد.**",
    "A haemodialysis patient: ethambutol is best left out of the regimen.",
    EYE_FA, EYE_EN,
    "این سؤال، همان نوریت اپتیک را از زاویه‌ی **پیشگیری** می‌پرسد، نه درمان.\n\n"
    "**بیمار: خانم ۲۷ ساله مورد ESRD تحت همودیالیز ۳ بار در هفته، با سرفه‌ی "
    "پروداکتیو، کاهش وزن و بی‌اشتهایی. در گرافی، انفیلتراسیون قله‌ی ریه‌ی راست و "
    "اسمیر خلط BK مثبت. کدام دارو بهتر است در رژیم نباشد؟**\n\n"
    "**پاسخ: اتامبوتول.**\n\n"
    "**کلید، مسیر دفع داروهاست. این را یک‌بار مرتب کنید:**\n\n"
    "**ایزونیازید — متابولیسم کبدی (استیلاسیون).** در نارسایی کلیه **تعدیل دوز "
    "نمی‌خواهد**.\n\n"
    "**ریفامپین — متابولیسم و دفع کبدی-صفراوی.** در نارسایی کلیه **تعدیل دوز "
    "نمی‌خواهد**.\n\n"
    "⚠️ **پیرازینامید — دفع کلیوی متابولیت‌ها.** **نیازمند تعدیل** (معمولاً سه بار در "
    "هفته، پس از دیالیز).\n\n"
    "⚠️ **اتامبوتول — دفع عمدتاً کلیوی و بدون تغییر.** **در نارسایی کلیه تجمع می‌کند.**\n\n"
    "**و حالا چرا اتامبوتول از پیرازینامید هم مشکل‌سازتر است؟**\n\n"
    "**چون عارضه‌اش برگشت‌ناپذیر است.** اگر پیرازینامید تجمع کند، آرترالژی یا بالا "
    "رفتن آنزیم کبدی می‌دهد — هر دو **قابل پایش و برگشت‌پذیر**. **ولی اگر اتامبوتول "
    "تجمع کند، نوریت اپتیک می‌دهد — که می‌تواند به کاهش دائمی بینایی برسد.**\n\n"
    "⚠️ **و مشکل دوم: پایش سخت است.** برای تشخیص زودهنگام نوریت باید **حدت بینایی و "
    "دید رنگی** را ماهانه سنجید. در بیمار دیالیزی که با ده‌ها مشکل دیگر درگیر است، "
    "این پایش اغلب انجام نمی‌شود — و وقتی بیمار خودش از تاری دید شکایت می‌کند، "
    "آسیب پیشرفته است.\n\n"
    "**پس تصمیم منطقی: اتامبوتول را از رژیم بردارید.**\n\n"
    "**آیا این رژیم را ضعیف می‌کند؟ نه به‌طور معنادار.** اتامبوتول **ضعیف‌ترین** "
    "داروی خط اول است و نقشش صرفاً محافظت در برابر مقاومت به ایزونیازید. **HRZ "
    "بدون E در بیمار با سویه‌ی حساس کاملاً مؤثر است.** (و اگر Xpert مقاومت به "
    "ریفامپین را رد کرده باشد، خیال آسوده‌تر است.)\n\n"
    "**نکته‌ی عملی مهم برای بالین: در بیمار دیالیزی، همه‌ی داروهای ضدسل باید "
    "پس از دیالیز داده شوند**، چون دیالیز آن‌ها را از خون خارج می‌کند.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**ریفامپین** — دفع کبدی-صفراوی؛ در دیالیز **بی‌مشکل** و ضمناً **حیاتی‌ترین داروی "
    "رژیم** است.\n\n"
    "**پیرازینامید** — تعدیل دوز می‌خواهد ولی **حذف نمی‌شود**؛ عارضه‌اش قابل پایش و "
    "برگشت‌پذیر است.\n\n"
    "**ایزونیازید** — متابولیسم کبدی؛ در دیالیز بی‌مشکل. **فقط پیریدوکسین را حتماً "
    "اضافه کنید، چون بیماران دیالیزی خطر نوروپاتی بیشتری دارند.**",
    "This question asks about the same optic neuritis, but from the angle of PREVENTION rather than treatment.\n\n"
    "THE PATIENT: a 27-year-old woman with end-stage renal disease on haemodialysis three times weekly, with productive cough, weight loss and anorexia. The film shows right apical infiltration and the sputum smear is positive. Which drug is best left out?\n\n"
    "THE ANSWER: ETHAMBUTOL.\n\n"
    "THE KEY IS THE ROUTE OF ELIMINATION. SORT THIS ONCE:\n\n"
    "ISONIAZID — hepatic metabolism (acetylation). NO DOSE ADJUSTMENT in renal failure.\n\n"
    "RIFAMPICIN — hepatic metabolism and biliary excretion. NO DOSE ADJUSTMENT in renal failure.\n\n"
    "WARNING: PYRAZINAMIDE — its metabolites are renally cleared. ADJUSTMENT NEEDED (usually three times weekly, after dialysis).\n\n"
    "WARNING: ETHAMBUTOL — largely renally cleared unchanged. IT ACCUMULATES IN RENAL FAILURE.\n\n"
    "AND WHY IS ETHAMBUTOL MORE PROBLEMATIC THAN PYRAZINAMIDE?\n\n"
    "BECAUSE ITS ADVERSE EFFECT IS IRREVERSIBLE. If pyrazinamide accumulates it causes arthralgia or a transaminase rise — both MONITORABLE AND REVERSIBLE. BUT IF ETHAMBUTOL ACCUMULATES IT CAUSES OPTIC NEURITIS, WHICH CAN END IN PERMANENT VISUAL LOSS.\n\n"
    "WARNING, AND A SECOND PROBLEM: MONITORING IS HARD. Detecting neuritis early requires MONTHLY VISUAL ACUITY AND COLOUR VISION testing. In a dialysis patient burdened with a dozen other problems this is often not done — and by the time the patient complains of blurred vision the damage is advanced.\n\n"
    "SO THE LOGICAL DECISION IS: LEAVE ETHAMBUTOL OUT OF THE REGIMEN.\n\n"
    "DOES THAT WEAKEN THE REGIMEN? NOT MEANINGFULLY. Ethambutol is THE WEAKEST first-line drug and its role is merely protection against isoniazid resistance. HRZ WITHOUT E IS FULLY EFFECTIVE AGAINST A SUSCEPTIBLE STRAIN. (And if Xpert has excluded rifampicin resistance, one can be more comfortable still.)\n\n"
    "AN IMPORTANT PRACTICAL POINT: IN A DIALYSIS PATIENT ALL ANTITUBERCULOUS DRUGS SHOULD BE GIVEN AFTER DIALYSIS, because dialysis removes them from the blood.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "RIFAMPICIN — hepatobiliary clearance; UNPROBLEMATIC in dialysis and moreover THE MOST VITAL DRUG IN THE REGIMEN.\n\n"
    "PYRAZINAMIDE — needs dose adjustment but IS NOT REMOVED; its toxicity is monitorable and reversible.\n\n"
    "ISONIAZID — hepatic metabolism; unproblematic in dialysis. JUST BE SURE TO ADD PYRIDOXINE, since dialysis patients carry a higher neuropathy risk.",
    ["دفع کبدی-صفراوی دارد و در دیالیز بی‌مشکل است؛ ضمناً حیاتی‌ترین داروی رژیم.",
     "تعدیل دوز می‌خواهد ولی حذف نمی‌شود؛ عارضه‌اش قابل پایش و برگشت‌پذیر است.",
     "پاسخ صحیح — دفع کلیوی دارد، تجمع می‌کند، و نوریت اپتیک آن برگشت‌ناپذیر است.",
     "متابولیسم کبدی دارد و در دیالیز بی‌مشکل است؛ فقط پیریدوکسین اضافه کنید."],
    ["Hepatobiliary clearance and unproblematic in dialysis; and it is the most vital drug in the regimen.",
     "Needs dose adjustment but is not removed; its toxicity is monitorable and reversible.",
     "Correct — renally cleared, it accumulates, and its optic neuritis is irreversible.",
     "Hepatic metabolism and unproblematic in dialysis; just add pyridoxine."],
    "**در نارسایی کلیه، اتامبوتول تجمع می‌کند و عارضه‌اش برگشت‌ناپذیر است — پس حذفش کنید.**",
    "In renal failure ethambutol accumulates and its toxicity is irreversible — so leave it out.",
    REFS)

# ==================================================== HEPATOTOXICITY
HEP_FA = [
    "⚠️ **در بالا رفتن آنزیم کبدی، یک سؤال همه چیز را تعیین می‌کند: علامت دارد یا نه؟**",
    "**آنزیم تا حدود سه برابر، بدون علامت: ادامه بدهید و آزمایش را تکرار کنید.**",
    "**چون بالا رفتن گذرا و بی‌علامت در ۲۰٪ بیماران رخ می‌دهد و خودبه‌خود می‌خوابد.**",
    "⚠️ **ولی بیش از سه برابر همراه با علامت: همه‌ی داروهای کبدی را قطع کنید.**",
    "**علامت یعنی تهوع، استفراغ، درد شکم، بی‌اشتهایی یا زردی.**",
    "**یا بیش از پنج برابر حتی بدون علامت — باز هم قطع.**",
    "**یا هر بالا رفتن بیلی‌روبین — قطع.**",
    "⚠️ **و «قطع» یعنی همه با هم، نه یکی‌یکی.**",
    "**چون سه داروی H و R و Z هر سه کبدی‌اند و نمی‌دانید کدام مقصر است.**",
    "**پس از نرمال شدن، داروها یکی‌یکی و با فاصله برمی‌گردند.**",
    "**ترتیب معمول بازگشت: ریفامپین، سپس ایزونیازید، و در آخر پیرازینامید.**",
    "**و اگر بیمار بدحال است، در فاصله، رژیم غیرکبدی موقت داده می‌شود.**",
]
HEP_EN = [
    "WARNING: WITH A RISING TRANSAMINASE, ONE QUESTION DECIDES EVERYTHING — IS THE PATIENT SYMPTOMATIC?",
    "Up to about three times normal WITHOUT symptoms: continue and repeat the test.",
    "Because a transient asymptomatic rise occurs in about 20 % of patients and settles by itself.",
    "WARNING: BUT ABOVE THREE TIMES NORMAL WITH SYMPTOMS — STOP ALL HEPATOTOXIC DRUGS.",
    "Symptoms means nausea, vomiting, abdominal pain, anorexia or jaundice.",
    "Or above five times normal even without symptoms — again, stop.",
    "Or any rise in bilirubin — stop.",
    "WARNING, AND 'STOP' MEANS ALL OF THEM TOGETHER, NOT ONE AT A TIME.",
    "Because H, R and Z are all hepatotoxic and you do not know which is guilty.",
    "Once values normalise the drugs are reintroduced one at a time, spaced apart.",
    "The usual order of reintroduction: rifampicin, then isoniazid, and pyrazinamide last.",
    "And if the patient is unwell, a temporary non-hepatotoxic regimen covers the gap.",
]

add("book:239", "vignette", "hard",
    "**آنزیم سه برابر و بیمار بی‌علامت: دارو را ادامه دهید و آزمایش را تکرار کنید.**",
    "Transaminases three times normal in an asymptomatic patient: continue the drugs and repeat the test.",
    HEP_FA, HEP_EN,
    "این سؤال و سؤال بعدی، **دوقلوهای فریبنده‌ی این فصل‌اند**: ویگنت‌هایشان تقریباً "
    "یکسان است ولی پاسخشان معکوس. **تفاوت در یک کلمه است.**\n\n"
    "**بیمار: آقای ۴۵ ساله، حدود سه هفته تحت درمان استاندارد چهاردارویی. آنزیم‌های "
    "کبدی حدود سه برابر حد طبیعی. و — این عبارت را زیرش خط بکشید — بیمار علامت "
    "خاصی ندارد.**\n\n"
    "**پاسخ: ادامه‌ی داروهای ضدسل و تکرار آزمایش.**\n\n"
    "**چرا؟ چون بالا رفتن خفیف و بی‌علامت آنزیم، در درمان سل یک پدیده‌ی معمول است، "
    "نه یک هشدار.**\n\n"
    "**تا حدود ۲۰٪ بیماران در هفته‌های نخست، بالا رفتن گذرای ترانس‌آمینازها را نشان "
    "می‌دهند. این پدیده نامی هم دارد: «سازگاری کبدی» (hepatic adaptation).** کبد "
    "با متابولیزه کردن بار دارویی جدید سازگار می‌شود و **در اکثر موارد، آنزیم‌ها "
    "خودبه‌خود به حالت عادی برمی‌گردند، حتی با ادامه‌ی دارو.**\n\n"
    "⚠️ **معیارهای رسمی قطع درمان را حفظ کنید — این‌ها تصمیم را می‌سازند:**\n\n"
    "**ALT/AST بیش از ۳ برابر همراه با علامت** (تهوع، استفراغ، درد شکم، بی‌اشتهایی، "
    "زردی) ⇐ **قطع**\n\n"
    "**ALT/AST بیش از ۵ برابر، حتی بدون علامت** ⇐ **قطع**\n\n"
    "**هر بالا رفتن بیلی‌روبین** ⇐ **قطع**\n\n"
    "**بیمار ما: ۳ برابر، بدون علامت، بیلی‌روبین ذکر نشده.** **هیچ‌یک از سه معیار "
    "برآورده نشده. پس ادامه می‌دهیم.**\n\n"
    "**و «تکرار آزمایش» بخش ضروری پاسخ است، نه تزئین.** یعنی: ادامه بده، ولی "
    "**رها نکن**. آزمایش را ظرف چند روز تا یک هفته تکرار کن. اگر بالا رفت یا "
    "علامت پیدا شد، تصمیم عوض می‌شود.\n\n"
    "**چرا قطع بی‌مورد، خودش خطرناک است؟ سه دلیل:**\n\n"
    "**۱. وقفه در درمان = فرصت مقاومت.** هر قطع، فشار انتخابی ناقص می‌سازد.\n\n"
    "**۲. طولانی شدن دوره‌ی سرایت.** بیمار بیشتر مسری می‌ماند.\n\n"
    "**۳. سردرگمی بعدی.** وقتی داروها را بی‌دلیل قطع کنید، بازگرداندنشان یکی‌یکی "
    "هفته‌ها طول می‌کشد.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**قطع کلیه‌ی داروها و ارجاع** — واکنش بیش از حد به یافته‌ای که معیار قطع را "
    "برآورده نمی‌کند.\n\n"
    "⚠️ **قطع پیرازینامید و اتامبوتول** — **دو خطا در یک گزینه.** اول: **اتامبوتول "
    "اصلاً هپاتوتوکسیک نیست**، پس قطعش هیچ سودی ندارد. دوم: قطع انتخابی وقتی "
    "معیار قطع برآورده نشده، **رژیم را ضعیف می‌کند بدون هیچ فایده‌ای**.\n\n"
    "**قطع سه داروی H، R و Z** — اگر معیار قطع برآورده شده بود، **این پاسخ درست "
    "بود** (هر سه کبدی‌اند). ولی اینجا معیار برآورده نشده.",
    "This question and the next are THE DECEPTIVE TWINS OF THIS CHAPTER: their vignettes are nearly identical but their answers are opposite. THE DIFFERENCE IS ONE WORD.\n\n"
    "THE PATIENT: a 45-year-old man, about three weeks into standard four-drug therapy. Liver enzymes are about three times the upper limit. And — underline this phrase — THE PATIENT HAS NO SYMPTOMS.\n\n"
    "THE ANSWER: CONTINUE THE ANTITUBERCULOUS DRUGS AND REPEAT THE TEST.\n\n"
    "WHY? BECAUSE A MILD ASYMPTOMATIC TRANSAMINASE RISE DURING TUBERCULOSIS TREATMENT IS AN ORDINARY PHENOMENON, NOT AN ALARM.\n\n"
    "UP TO 20 % OF PATIENTS SHOW A TRANSIENT RISE IN THE EARLY WEEKS. The phenomenon has a name: HEPATIC ADAPTATION. The liver adjusts to metabolising the new drug load, and IN MOST CASES THE ENZYMES RETURN TO NORMAL BY THEMSELVES, EVEN WITH THE DRUGS CONTINUED.\n\n"
    "WARNING, MEMORISE THE FORMAL STOPPING CRITERIA — THEY MAKE THE DECISION:\n\n"
    "ALT/AST ABOVE 3x NORMAL WITH SYMPTOMS (nausea, vomiting, abdominal pain, anorexia, jaundice) — STOP.\n\n"
    "ALT/AST ABOVE 5x NORMAL, EVEN WITHOUT SYMPTOMS — STOP.\n\n"
    "ANY RISE IN BILIRUBIN — STOP.\n\n"
    "OUR PATIENT: 3x, no symptoms, no bilirubin mentioned. NOT ONE OF THE THREE CRITERIA IS MET. SO WE CONTINUE.\n\n"
    "AND 'REPEAT THE TEST' IS AN ESSENTIAL PART OF THE ANSWER, NOT DECORATION. It means: continue, but DO NOT ABANDON. Repeat within a few days to a week. If it rises further or symptoms appear, the decision changes.\n\n"
    "WHY IS NEEDLESS STOPPING ITSELF DANGEROUS? THREE REASONS:\n\n"
    "1. AN INTERRUPTION IS AN OPPORTUNITY FOR RESISTANCE. Every stop creates incomplete selective pressure.\n\n"
    "2. PROLONGED INFECTIOUSNESS. The patient stays infectious longer.\n\n"
    "3. SUBSEQUENT CONFUSION. Once you stop the drugs needlessly, reintroducing them one by one takes weeks.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "STOPPING EVERYTHING AND REFERRING — an overreaction to a finding that does not meet the stopping criteria.\n\n"
    "WARNING: STOPPING PYRAZINAMIDE AND ETHAMBUTOL — TWO ERRORS IN ONE OPTION. First, ETHAMBUTOL IS NOT HEPATOTOXIC AT ALL, so stopping it achieves nothing. Second, selective stopping when no criterion is met WEAKENS THE REGIMEN FOR NO BENEFIT.\n\n"
    "STOPPING H, R AND Z — if the criteria HAD been met, THIS WOULD BE THE RIGHT ANSWER (all three are hepatotoxic). But here they are not met.",
    ["واکنش بیش از حد؛ هیچ‌یک از معیارهای رسمی قطع در این بیمار برآورده نشده.",
     "پاسخ صحیح — سه برابر بدون علامت، معیار قطع نیست؛ ادامه بدهید و تکرار کنید.",
     "دو خطا: اتامبوتول اصلاً کبدی نیست، و قطع انتخابی رژیم را بی‌فایده ضعیف می‌کند.",
     "اگر معیار قطع برآورده شده بود درست بود، ولی اینجا برآورده نشده است."],
    ["An overreaction; none of the formal stopping criteria is met in this patient.",
     "Correct — 3x without symptoms is not a stopping criterion; continue and repeat.",
     "Two errors: ethambutol is not hepatotoxic at all, and selective stopping weakens the regimen pointlessly.",
     "Would be right if the criteria were met, but here they are not."],
    "**سه برابر بدون علامت یعنی ادامه بده و تکرار کن؛ قطع بی‌مورد خودش خطرناک است.**",
    "Three times normal without symptoms means continue and repeat; needless stopping is itself dangerous.",
    REFSA)

add("book:245", "vignette", "hard",
    "**آنزیم سه برابر همراه با تهوع و استفراغ: همه‌ی داروها موقتاً قطع می‌شوند.**",
    "Transaminases three times normal WITH nausea and vomiting: all drugs are stopped temporarily.",
    HEP_FA, HEP_EN,
    "این سؤال، **دوقلوی سؤال قبلی** است — و **مقایسه‌ی این دو، مؤثرترین راه یادگیری "
    "این مبحث است.**\n\n"
    "**بیمار: آقای ۵۷ ساله با سل ریوی اسمیر مثبت، تحت رژیم استاندارد. پس از سه "
    "هفته، به‌دنبال درد شکم، تهوع و استفراغ مراجعه کرده و آنزیم‌های کبدی بیش از سه "
    "برابر نرمال است.**\n\n"
    "**پاسخ: قطع موقت داروها تا نرمال شدن آنزیم‌های کبدی.**\n\n"
    "⚠️ **حالا دو بیمار را کنار هم بگذارید:**\n\n"
    "**بیمار قبلی (سؤال ۲۳۹): سه هفته درمان · آنزیم ۳ برابر · بدون علامت ⇐ ادامه بده.**\n\n"
    "**این بیمار: سه هفته درمان · آنزیم بیش از ۳ برابر · با درد شکم، تهوع و استفراغ "
    "⇐ قطع کن.**\n\n"
    "**تنها تفاوت: وجود علامت. و همان یک تفاوت، تصمیم را وارونه می‌کند.**\n\n"
    "**چرا علامت این‌قدر تعیین‌کننده است؟**\n\n"
    "**چون بالا رفتن بی‌علامت آنزیم، اغلب «سازگاری کبدی» است — پدیده‌ای گذرا.** ولی "
    "**وقتی علامت اضافه می‌شود، یعنی سلول کبدی واقعاً آسیب دیده و بیمار آن را حس "
    "می‌کند.** تهوع، استفراغ و درد شکم در بیمار تحت درمان سل، تا خلاف آن ثابت نشود، "
    "**علائم هپاتیت دارویی‌اند** — و **پیش‌درآمد نارسایی کبدی** می‌توانند باشند.\n\n"
    "**در سری‌های منتشرشده، مرگ ناشی از هپاتیت ضدسل تقریباً همیشه در بیمارانی رخ "
    "داده که با وجود علائم، دارو را ادامه داده بودند.**\n\n"
    "⚠️ **و حالا نکته‌ی دوم: چرا «همه‌ی داروها» و نه فقط یکی؟**\n\n"
    "**چون سه داروی H، R و Z هر سه هپاتوتوکسیک‌اند و در لحظه‌ی تصمیم، شما نمی‌دانید "
    "کدام مقصر است.** حدس زدن و قطع کردن یکی، هم بیمار را در معرض دو داروی "
    "باقی‌مانده نگه می‌دارد و هم اطلاعاتی نمی‌دهد.\n\n"
    "**پروتکل درست:**\n\n"
    "**۱. همه‌ی داروهای هپاتوتوکسیک قطع می‌شوند.**\n\n"
    "**۲. اگر بیمار بدحال یا شدیداً مسری است، در فاصله یک رژیم غیرکبدی موقت داده "
    "می‌شود** — مثلاً **اتامبوتول + فلوروکینولون (± آمینوگلیکوزید)**. (اینجا "
    "فلوروکینولون مجاز است، چون تشخیص سل قطعی شده و دیگر خطر پوشاندن تشخیص وجود "
    "ندارد.)\n\n"
    "**۳. پس از نرمال شدن آنزیم‌ها (معمولاً ۱ تا ۴ هفته)، داروها یکی‌یکی و با فاصله "
    "برمی‌گردند.** ترتیب معمول: **ریفامپین اول** (کم‌ترین احتمال، و مهم‌ترین دارو)، "
    "**سپس ایزونیازید**، و **پیرازینامید آخر** — و در بسیاری موارد پیرازینامید اصلاً "
    "برنمی‌گردد و طول درمان تمدید می‌شود.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**ادامه‌ی درمان و پایش** — **پاسخ درست برای بیمار قبلی، پاسخ خطرناک برای این "
    "بیمار.** علامت‌دار بودن، معیار قطع را برآورده کرده.\n\n"
    "⚠️ **ادامه‌ی پیرازینامید و اتامبوتول و قطع H و R** — **بدترین گزینه.** "
    "**پیرازینامید کبدی‌ترین داروی رژیم است**، و نگه داشتن آن در بیمار با هپاتیت "
    "دارویی، یعنی نگه داشتن اصلی‌ترین مظنون.\n\n"
    "**قطع پیرازینامید و ادامه‌ی بقیه با لووفلوکساسین** — پیرازینامید را درست حدس "
    "زده، ولی **H و R را که هر دو هپاتوتوکسیک‌اند ادامه داده**. در بیمار علامت‌دار، "
    "این کافی نیست.",
    "This question is THE TWIN of the previous one — and COMPARING THE TWO IS THE MOST EFFECTIVE WAY TO LEARN THIS TOPIC.\n\n"
    "THE PATIENT: a 57-year-old man with smear-positive pulmonary tuberculosis on the standard regimen. After three weeks he presents with ABDOMINAL PAIN, NAUSEA AND VOMITING, and his liver enzymes are more than three times normal.\n\n"
    "THE ANSWER: STOP THE DRUGS TEMPORARILY UNTIL THE ENZYMES NORMALISE.\n\n"
    "WARNING, NOW PUT THE TWO PATIENTS SIDE BY SIDE:\n\n"
    "THE PREVIOUS PATIENT: three weeks of treatment, enzymes 3x, NO SYMPTOMS — CONTINUE.\n\n"
    "THIS PATIENT: three weeks of treatment, enzymes above 3x, WITH abdominal pain, nausea and vomiting — STOP.\n\n"
    "THE ONLY DIFFERENCE IS THE PRESENCE OF SYMPTOMS. AND THAT ONE DIFFERENCE INVERTS THE DECISION.\n\n"
    "WHY ARE SYMPTOMS SO DECISIVE?\n\n"
    "BECAUSE AN ASYMPTOMATIC ENZYME RISE IS USUALLY 'HEPATIC ADAPTATION' — a transient phenomenon. BUT ONCE SYMPTOMS APPEAR, THE HEPATOCYTE IS GENUINELY INJURED AND THE PATIENT FEELS IT. Nausea, vomiting and abdominal pain in a patient on antituberculous therapy are, until proved otherwise, THE SYMPTOMS OF DRUG-INDUCED HEPATITIS — and can be THE PRELUDE TO LIVER FAILURE.\n\n"
    "IN PUBLISHED SERIES, DEATHS FROM ANTITUBERCULOUS HEPATITIS HAVE ALMOST ALWAYS OCCURRED IN PATIENTS WHO CONTINUED THE DRUGS DESPITE SYMPTOMS.\n\n"
    "WARNING, AND NOW THE SECOND POINT: WHY 'ALL THE DRUGS' AND NOT JUST ONE?\n\n"
    "BECAUSE H, R AND Z ARE ALL HEPATOTOXIC AND AT THE MOMENT OF DECISION YOU DO NOT KNOW WHICH IS GUILTY. Guessing and stopping one leaves the patient exposed to the other two and yields no information.\n\n"
    "THE CORRECT PROTOCOL:\n\n"
    "1. ALL HEPATOTOXIC DRUGS ARE STOPPED.\n\n"
    "2. IF THE PATIENT IS UNWELL OR HIGHLY INFECTIOUS, A TEMPORARY NON-HEPATOTOXIC REGIMEN COVERS THE GAP — for example ETHAMBUTOL PLUS A FLUOROQUINOLONE (with or without an aminoglycoside). (A fluoroquinolone is permissible here, because the diagnosis is already confirmed and there is no longer any risk of masking it.)\n\n"
    "3. ONCE THE ENZYMES NORMALISE (usually 1 to 4 weeks), THE DRUGS ARE REINTRODUCED ONE AT A TIME, SPACED APART. The usual order: RIFAMPICIN FIRST (least likely culprit and the most important drug), THEN ISONIAZID, AND PYRAZINAMIDE LAST — and in many cases pyrazinamide is never restored and the total duration is extended instead.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "CONTINUE AND MONITOR — THE RIGHT ANSWER FOR THE PREVIOUS PATIENT, A DANGEROUS ONE FOR THIS. Symptoms have met the stopping criterion.\n\n"
    "WARNING: CONTINUE PYRAZINAMIDE AND ETHAMBUTOL, STOP H AND R — THE WORST OPTION. PYRAZINAMIDE IS THE MOST HEPATOTOXIC DRUG IN THE REGIMEN, and keeping it in a patient with drug-induced hepatitis means keeping the prime suspect.\n\n"
    "STOP PYRAZINAMIDE AND CONTINUE THE REST WITH LEVOFLOXACIN — it guesses pyrazinamide correctly, BUT CONTINUES H AND R, BOTH HEPATOTOXIC. In a symptomatic patient that is not enough.",
    ["پاسخ درست برای بیمار بی‌علامت، ولی خطرناک برای این بیمار؛ علامت معیار قطع را برآورده کرده.",
     "پاسخ صحیح — با علامت و آنزیم بیش از سه برابر، همه‌ی داروهای کبدی موقتاً قطع می‌شوند.",
     "بدترین گزینه؛ پیرازینامید کبدی‌ترین داروی رژیم است و نباید نگه داشته شود.",
     "پیرازینامید را درست حدس زده ولی H و R را که هر دو کبدی‌اند ادامه داده."],
    ["The right answer for the asymptomatic patient but dangerous here; symptoms have met the stopping criterion.",
     "Correct — with symptoms and enzymes above three times normal, all hepatotoxic drugs are stopped temporarily.",
     "The worst option; pyrazinamide is the most hepatotoxic drug and must not be retained.",
     "Guesses pyrazinamide correctly but continues H and R, both of which are hepatotoxic."],
    "**بی‌علامت یعنی ادامه؛ علامت‌دار یعنی قطع همه با هم. یک کلمه، دو تصمیم متضاد.**",
    "Asymptomatic means continue; symptomatic means stop them all. One word, two opposite decisions.",
    REFSA)

add("book:242", "vignette", "hard",
    "**تهوع و استفراغ در ماه اول درمان: همه‌ی داروها قطع و آنزیم کبدی درخواست شود.**",
    "Nausea and vomiting in the first month: stop all the drugs and request liver enzymes.",
    HEP_FA, HEP_EN,
    "این سؤال، همان مفهوم را در **لحظه‌ای زودتر** می‌سنجد: **هنوز آزمایشی در دست "
    "نیست.**\n\n"
    "**بیمار: مرد ۴۰ ساله تحت درمان سل ریوی خلط منفی از یک ماه قبل با رژیم "
    "چهاردارویی. از سه روز قبل دچار بی‌اشتهایی و تهوع شده و یک بار استفراغ کرده. "
    "در معاینه حال عمومی خوب است، علائم حیاتی نرمال، و بقیه‌ی معاینه بدون یافته.**\n\n"
    "**پاسخ: قطع همه‌ی داروهای سل و درخواست AST، ALT و بیلی‌روبین.**\n\n"
    "**دو تصمیم در این پاسخ هست و هر دو باید توجیه شوند:**\n\n"
    "⚠️ **تصمیم اول: چرا آزمایش می‌خواهیم؟**\n\n"
    "**چون بی‌اشتهایی، تهوع و استفراغ در بیمار تحت درمان ضدسل، تا خلاف آن ثابت "
    "نشود، علائم هپاتیت دارویی‌اند.** این‌ها همان علائم پرودرومال کلاسیک‌اند و **پیش "
    "از زردی و پیش از بالا رفتن چشمگیر آنزیم‌ها ظاهر می‌شوند**.\n\n"
    "**«حال عمومی خوب» و «معاینه‌ی طبیعی» شما را نباید آرام کند** — در هپاتیت دارویی "
    "زودرس، معاینه معمولاً طبیعی است و **تنها آزمایش می‌تواند وضعیت را بگوید**.\n\n"
    "⚠️ **تصمیم دوم و دشوارتر: چرا داروها را قطع می‌کنیم پیش از دیدن جواب؟**\n\n"
    "**چون هزینه‌ی دو گزینه‌ی اشتباه، برابر نیست:**\n\n"
    "**اگر قطع کنیم و بعد معلوم شود آنزیم‌ها طبیعی‌اند** ⇐ چند روز درمان از دست "
    "رفته، که در سل قابل جبران است.\n\n"
    "**اگر ادامه دهیم و بعد معلوم شود هپاتیت شدید بوده** ⇐ **می‌تواند به نارسایی حاد "
    "کبدی و مرگ برسد.**\n\n"
    "**در پزشکی وقتی دو خطا نامتقارن‌اند، جانب خطای کم‌هزینه‌تر را می‌گیریم. این اصل، "
    "پاسخ را می‌سازد.**\n\n"
    "**و «همه‌ی داروها» چون سه دارو از چهار دارو هپاتوتوکسیک‌اند و نمی‌دانید کدام "
    "مقصر است.**\n\n"
    "**نکته‌ی آرام‌بخش: بیمار «اسمیر منفی» است، یعنی سرایت‌دهندگی‌اش پایین است. پس "
    "چند روز وقفه، خطر بهداشت عمومی نمی‌سازد.** (در بیمار اسمیر مثبتِ بدحال، ممکن "
    "بود رژیم غیرکبدی موقت لازم شود.)\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**قطع ریفامپین و ایزونیازید و ادامه‌ی بقیه** — ⚠️ **پیرازینامید را نگه داشته، که "
    "کبدی‌ترین داروی رژیم است.** حدس انتخابی، بدون داده، و با نگه داشتن اصلی‌ترین "
    "مظنون.\n\n"
    "⚠️ **ادامه‌ی درمان و تجویز متوکلوپرامید** — **خطرناک‌ترین گزینه.** این یعنی **علامت "
    "را بپوشانیم و علت را نبینیم**. متوکلوپرامید تهوع را می‌خواباند، بیمار احساس "
    "بهتری می‌کند، **و هپاتیت در سکوت پیشرفت می‌کند تا روزی که با زردی و "
    "انسفالوپاتی برگردد.** این دقیقاً همان الگویی است که در گزارش‌های مرگ ناشی از "
    "هپاتیت ضدسل دیده می‌شود.\n\n"
    "**قطع سه دارو و ادامه با اتامبوتول و سیپروفلوکساسین** — تصمیم درباره‌ی رژیم "
    "جایگزین، **پیش از آنکه بدانیم اصلاً هپاتیتی در کار هست یا نه.** اول آزمایش، "
    "بعد رژیم جایگزین.",
    "This question tests the same concept at AN EARLIER MOMENT: NO TEST RESULT IS YET AVAILABLE.\n\n"
    "THE PATIENT: a 40-year-old man on four-drug therapy for smear-negative pulmonary tuberculosis for one month. For the past three days he has had anorexia and nausea and vomited once. On examination he looks well, vital signs are normal, and the rest of the examination is unremarkable.\n\n"
    "THE ANSWER: STOP ALL THE ANTITUBERCULOUS DRUGS AND REQUEST AST, ALT AND BILIRUBIN.\n\n"
    "THERE ARE TWO DECISIONS IN THAT ANSWER AND BOTH MUST BE JUSTIFIED:\n\n"
    "WARNING, DECISION ONE: WHY REQUEST THE TESTS?\n\n"
    "BECAUSE ANOREXIA, NAUSEA AND VOMITING IN A PATIENT ON ANTITUBERCULOUS THERAPY ARE, UNTIL PROVED OTHERWISE, THE SYMPTOMS OF DRUG-INDUCED HEPATITIS. These are the classic prodromal features and THEY APPEAR BEFORE JAUNDICE AND BEFORE ANY STRIKING ENZYME RISE.\n\n"
    "'LOOKING WELL' AND A 'NORMAL EXAMINATION' MUST NOT REASSURE YOU — in early drug hepatitis the examination is usually normal and ONLY THE BLOOD TEST CAN TELL YOU WHERE YOU STAND.\n\n"
    "WARNING, DECISION TWO, AND THE HARDER ONE: WHY STOP THE DRUGS BEFORE SEEING THE RESULT?\n\n"
    "BECAUSE THE COSTS OF THE TWO POSSIBLE ERRORS ARE NOT EQUAL:\n\n"
    "IF WE STOP AND THE ENZYMES TURN OUT NORMAL — a few days of treatment are lost, which in tuberculosis is recoverable.\n\n"
    "IF WE CONTINUE AND IT TURNS OUT TO BE SEVERE HEPATITIS — IT CAN END IN ACUTE LIVER FAILURE AND DEATH.\n\n"
    "IN MEDICINE, WHEN TWO ERRORS ARE ASYMMETRIC, WE ERR ON THE SIDE OF THE CHEAPER ONE. That principle produces the answer.\n\n"
    "AND 'ALL THE DRUGS' BECAUSE THREE OF THE FOUR ARE HEPATOTOXIC AND YOU DO NOT KNOW WHICH IS GUILTY.\n\n"
    "A REASSURING POINT: THE PATIENT IS SMEAR-NEGATIVE, so his infectiousness is low. A few days' interruption creates no public health hazard. (In an unwell smear-positive patient a temporary non-hepatotoxic regimen might be needed.)\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "STOPPING RIFAMPICIN AND ISONIAZID AND CONTINUING THE REST — WARNING, IT KEEPS PYRAZINAMIDE, THE MOST HEPATOTOXIC DRUG IN THE REGIMEN. A selective guess, made without data, that retains the prime suspect.\n\n"
    "WARNING: CONTINUE TREATMENT AND GIVE METOCLOPRAMIDE — THE MOST DANGEROUS OPTION. It means MASKING THE SYMPTOM AND NOT SEEING THE CAUSE. Metoclopramide settles the nausea, the patient feels better, AND THE HEPATITIS ADVANCES IN SILENCE UNTIL THE DAY HE RETURNS WITH JAUNDICE AND ENCEPHALOPATHY. This is exactly the pattern seen in reported deaths from antituberculous hepatitis.\n\n"
    "STOPPING THREE DRUGS AND CONTINUING WITH ETHAMBUTOL AND CIPROFLOXACIN — deciding on a substitute regimen BEFORE KNOWING WHETHER THERE IS ANY HEPATITIS AT ALL. Test first, substitute later.",
    ["پیرازینامید را نگه می‌دارد که کبدی‌ترین داروی رژیم است؛ حدس انتخابی بدون داده.",
     "خطرناک‌ترین گزینه؛ متوکلوپرامید علامت را می‌پوشاند و هپاتیت در سکوت پیش می‌رود.",
     "پاسخ صحیح — علائم پرودرومال هپاتیت دارویی؛ قطع همه و درخواست آنزیم و بیلی‌روبین.",
     "تصمیم درباره‌ی رژیم جایگزین پیش از آنکه بدانیم اصلاً هپاتیتی در کار هست."],
    ["Retains pyrazinamide, the most hepatotoxic drug; a selective guess made without data.",
     "The most dangerous option; metoclopramide masks the symptom while the hepatitis advances in silence.",
     "Correct — prodromal symptoms of drug hepatitis; stop everything and request enzymes and bilirubin.",
     "Choosing a substitute regimen before knowing whether there is any hepatitis at all."],
    "**وقتی دو خطا نامتقارن‌اند، جانب خطای کم‌هزینه را بگیر — قطع کن و آزمایش بفرست.**",
    "When two errors are asymmetric, err on the cheaper side — stop the drugs and send the test.",
    REFSA)

# ==================================================== RIFAMPICIN IMMUNE
IMMUNE_FA = [
    "⚠️ **واکنش‌های ایمنی ریفامپین با عوارض سمّی فرق بنیادی دارند.**",
    "**عارضه‌ی سمّی وابسته به دوز است؛ واکنش ایمنی وابسته به مواجهه‌ی قبلی است.**",
    "**فهرست واکنش‌های ایمنی ریفامپین را حفظ کنید.**",
    "**ترومبوسیتوپنی — با پتشی و پورپورا.**",
    "**آنمی همولیتیک.**",
    "⚠️ **نارسایی حاد کلیه از نوع نفریت بینابینی حاد.**",
    "**شوک و افت فشار ناگهانی.**",
    "**سندرم شبه‌آنفلوانزا — تب و لرز و درد عضلانی چند ساعت پس از دوز.**",
    "**همه‌ی این‌ها با مصرف منقطع یا پس از وقفه و شروع مجدد شایع‌ترند.**",
    "⚠️ **و قاعده‌ی مطلق: پس از واکنش ایمنی، ریفامپین برای همیشه ممنوع می‌شود.**",
    "**چون مواجهه‌ی مجدد می‌تواند کشنده باشد.**",
    "**این با هپاتیت دارویی که پس از بهبود قابل بازگشت است، کاملاً فرق دارد.**",
]
IMMUNE_EN = [
    "WARNING: RIFAMPICIN'S IMMUNE REACTIONS DIFFER FUNDAMENTALLY FROM ITS TOXIC EFFECTS.",
    "A toxic effect depends on dose; an immune reaction depends on prior exposure.",
    "Memorise the list of rifampicin immune reactions.",
    "THROMBOCYTOPENIA — with petechiae and purpura.",
    "HAEMOLYTIC ANAEMIA.",
    "WARNING: ACUTE RENAL FAILURE of the acute interstitial nephritis type.",
    "SHOCK and sudden hypotension.",
    "A FLU-LIKE SYNDROME — fever, chills and myalgia a few hours after the dose.",
    "All of these are commoner with intermittent dosing or after an interruption and restart.",
    "WARNING, AND THE ABSOLUTE RULE: AFTER AN IMMUNE REACTION, RIFAMPICIN IS FORBIDDEN FOREVER.",
    "Because re-exposure can be fatal.",
    "This is entirely different from drug hepatitis, which can be reintroduced after recovery.",
]

add("book:249", "vignette", "hard",
    "**پورپورا با ترومبوسیتوپنی منفرد: ریفامپین هرگز نباید دوباره شروع شود.**",
    "Purpura with isolated thrombocytopenia: rifampicin must never be restarted.",
    IMMUNE_FA, IMMUNE_EN,
    "این سؤال یکی از مهم‌ترین سؤال‌های کل فصل است، چون **تصمیمش برگشت‌ناپذیر و "
    "بالقوه نجات‌بخش است**.\n\n"
    "⚠️ **نکته‌ی داده‌ای: در متن اصلی، هموگلوبین این بیمار «۲۱» ثبت شده بود. بازخوانی "
    "گلیف‌های صفحه‌ی ۹۷ نشان داد صفحه Hb: 12 چاپ کرده است.** این تصحیح حیاتی است: "
    "**هموگلوبین ۲۱ یعنی پلی‌سیتمی و شما را به دنبال علتی کاملاً متفاوت می‌فرستد.**\n\n"
    "**بیمار: سل ریوی اسمیر مثبت، تحت درمان مرحله‌ی حمله‌ای، با بثورات پوستی خارش‌دار "
    "به‌همراه پتشی و پورپورا. آزمایش: WBC=6000، Hb=12، پلاکت=40000. داروها قطع شده "
    "و پس از یک هفته علائم بهبود یافته. در شروع مجدد، کدام دارو نباید استفاده "
    "شود؟**\n\n"
    "**پاسخ: ریفامپین.**\n\n"
    "**اول، پانل خون را بخوانید:**\n\n"
    "**گلبول سفید ۶۰۰۰ = طبیعی** · **هموگلوبین ۱۲ = طبیعی** · **پلاکت ۴۰۰۰۰ = "
    "به‌شدت پایین**\n\n"
    "⚠️ **این یعنی ترومبوسیتوپنی منفرد (isolated) — و «منفرد» بودن، کلید تشخیص است.**\n\n"
    "**چرا؟** چون اگر مغز استخوان به‌طور کلی سرکوب شده بود، **هر سه رده افت "
    "می‌کردند** (پان‌سیتوپنی). ولی اینجا فقط **یک رده** افتاده — که یعنی مکانیسم، "
    "**تخریب محیطی انتخابی** است، نه نارسایی تولید. **و تخریب انتخابی پلاکت، امضای "
    "یک واکنش ایمنی است.**\n\n"
    "**مکانیسم دقیق: ریفامپین به‌عنوان هاپتن به سطح پلاکت می‌چسبد.** سیستم ایمنی "
    "علیه کمپلکس **دارو-پلاکت** آنتی‌بادی می‌سازد. **پلاکت‌های پوشیده از آنتی‌بادی، در "
    "طحال بلعیده می‌شوند.** نتیجه: افت سریع پلاکت، پتشی و پورپورا.\n\n"
    "**و شاهد قاطع در همین ویگنت: با قطع دارو، ظرف یک هفته همه‌چیز بهبود یافت.** "
    "این **رابطه‌ی زمانی**، تشخیص را قفل می‌کند.\n\n"
    "⚠️ **حالا مهم‌ترین بخش: چرا «هرگز دوباره نه»؟**\n\n"
    "**چون آنتی‌بادی ساخته شده و در بدن می‌ماند.** با نخستین دوز بعدی ریفامپین، "
    "**واکنش بلافاصله و شدیدتر برمی‌گردد**. گزارش‌های متعددی از **ترومبوسیتوپنی "
    "فاجعه‌بار، خونریزی داخل مغزی، همولیز حاد، نارسایی کلیه و شوک آنافیلاکتوئید** "
    "پس از شروع مجدد ریفامپین وجود دارد. **برخی از این موارد کشنده بوده‌اند.**\n\n"
    "**این تفاوت بنیادی با هپاتیت دارویی است:**\n\n"
    "**هپاتیت** = آسیب **سمّی** ⇐ پس از بهبود، دارو **با احتیاط برمی‌گردد**.\n\n"
    "**ترومبوسیتوپنی/همولیز/نفریت بینابینی/شوک** = واکنش **ایمنی** ⇐ دارو **برای "
    "همیشه ممنوع**.\n\n"
    "**پس رژیم بدون ریفامپین ساخته می‌شود** — که یعنی درمان **طولانی‌تر** (معمولاً "
    "۱۲ تا ۱۸ ماه) و اغلب با افزودن یک فلوروکینولون. **این هزینه‌ی سنگینی است، ولی "
    "بسیار کمتر از خطر مرگ.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**اتامبوتول** — عارضه‌اش نوریت اپتیک است، نه اختلال خونی.\n\n"
    "**ایزونیازید** — هپاتیت و نوروپاتی محیطی. **ترومبوسیتوپنی ایمنی، عارضه‌ی شاخص "
    "آن نیست.**\n\n"
    "**پیرازینامید** — هیپراوریسمی، آرترالژی، هپاتیت. **ترومبوسیتوپنی نمی‌دهد.**",
    "This is one of the most important questions in the whole chapter, because ITS DECISION IS IRREVERSIBLE AND POTENTIALLY LIFE-SAVING.\n\n"
    "WARNING, A DATA NOTE: in the source text this patient's haemoglobin was recorded as '21'. Re-reading the glyphs of page 97 showed the page prints Hb: 12. That correction is vital: A HAEMOGLOBIN OF 21 MEANS POLYCYTHAEMIA AND SENDS YOU HUNTING FOR AN ENTIRELY DIFFERENT CAUSE.\n\n"
    "THE PATIENT: smear-positive pulmonary tuberculosis in the intensive phase, presenting with an itchy rash together with PETECHIAE AND PURPURA. Laboratory: WBC 6000, Hb 12, PLATELETS 40,000. The drugs were stopped and within a week everything resolved. On restarting, which drug must not be used?\n\n"
    "THE ANSWER: RIFAMPICIN.\n\n"
    "FIRST, READ THE BLOOD PANEL:\n\n"
    "WHITE COUNT 6000 = NORMAL. HAEMOGLOBIN 12 = NORMAL. PLATELETS 40,000 = SEVERELY LOW.\n\n"
    "WARNING: THAT MEANS AN ISOLATED THROMBOCYTOPENIA — AND THE WORD 'ISOLATED' IS THE KEY TO THE DIAGNOSIS.\n\n"
    "WHY? Because if the marrow were generally suppressed, ALL THREE LINES WOULD FALL (pancytopenia). Here only ONE line has fallen, which means the mechanism is SELECTIVE PERIPHERAL DESTRUCTION rather than failure of production. AND SELECTIVE DESTRUCTION OF PLATELETS IS THE SIGNATURE OF AN IMMUNE REACTION.\n\n"
    "THE PRECISE MECHANISM: RIFAMPICIN BINDS AS A HAPTEN TO THE PLATELET SURFACE. The immune system makes antibody against the DRUG-PLATELET complex. ANTIBODY-COATED PLATELETS ARE CONSUMED IN THE SPLEEN. The result: a rapid platelet fall, petechiae and purpura.\n\n"
    "AND THE DECISIVE WITNESS IS IN THE VIGNETTE ITSELF: WITHIN A WEEK OF STOPPING, EVERYTHING RESOLVED. That temporal relationship locks the diagnosis.\n\n"
    "WARNING, NOW THE MOST IMPORTANT PART: WHY 'NEVER AGAIN'?\n\n"
    "BECAUSE THE ANTIBODY HAS BEEN MADE AND REMAINS IN THE BODY. With the very next dose of rifampicin THE REACTION RETURNS AT ONCE AND MORE SEVERELY. There are numerous reports of CATASTROPHIC THROMBOCYTOPENIA, INTRACRANIAL HAEMORRHAGE, ACUTE HAEMOLYSIS, RENAL FAILURE AND ANAPHYLACTOID SHOCK after rifampicin rechallenge. SOME OF THESE HAVE BEEN FATAL.\n\n"
    "THIS IS THE FUNDAMENTAL DIFFERENCE FROM DRUG HEPATITIS:\n\n"
    "HEPATITIS = TOXIC injury, so after recovery the drug CAN BE CAUTIOUSLY REINTRODUCED.\n\n"
    "THROMBOCYTOPENIA / HAEMOLYSIS / INTERSTITIAL NEPHRITIS / SHOCK = IMMUNE reaction, so the drug is FORBIDDEN FOR LIFE.\n\n"
    "SO A RIFAMPICIN-FREE REGIMEN IS BUILT — which means LONGER TREATMENT (usually 12 to 18 months), often with a fluoroquinolone added. THAT IS A HEAVY PRICE, BUT FAR CHEAPER THAN THE RISK OF DEATH.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ETHAMBUTOL — its adverse effect is optic neuritis, not a haematological disorder.\n\n"
    "ISONIAZID — hepatitis and peripheral neuropathy. IMMUNE THROMBOCYTOPENIA IS NOT CHARACTERISTIC OF IT.\n\n"
    "PYRAZINAMIDE — hyperuricaemia, arthralgia, hepatitis. IT DOES NOT CAUSE THROMBOCYTOPENIA.",
    ["عارضه‌ی شاخصش نوریت اپتیک است، نه اختلال خونی.",
     "پاسخ صحیح — ترومبوسیتوپنی ایمنی ریفامپین؛ آنتی‌بادی می‌ماند و مواجهه‌ی مجدد کشنده است.",
     "هپاتیت و نوروپاتی محیطی می‌دهد؛ ترومبوسیتوپنی ایمنی شاخص آن نیست.",
     "هیپراوریسمی، آرترالژی و هپاتیت؛ ترومبوسیتوپنی نمی‌دهد."],
    ["Its characteristic effect is optic neuritis, not a blood disorder.",
     "Correct — rifampicin immune thrombocytopenia; the antibody persists and re-exposure can be fatal.",
     "Causes hepatitis and peripheral neuropathy; immune thrombocytopenia is not characteristic.",
     "Hyperuricaemia, arthralgia and hepatitis; it does not cause thrombocytopenia."],
    "**هپاتیت برمی‌گردد، ولی واکنش ایمنی هرگز — آنتی‌بادی می‌ماند و بار دوم می‌کشد.**",
    "Hepatitis can be rechallenged, an immune reaction never — the antibody persists and the second exposure kills.",
    REFSA)

add("book:254", "vignette", "medium",
    "**شوک، ترومبوسیتوپنی و نفریت بینابینی حاد با هم: ریفامپین.**",
    "Shock, thrombocytopenia and acute interstitial nephritis together: rifampicin.",
    IMMUNE_FA, IMMUNE_EN,
    "این سؤال، همان مکانیسم ایمنی را نشان می‌دهد، ولی این‌بار با **سه تظاهر هم‌زمان** "
    "— و همین هم‌زمانی، تشخیص را قطعی می‌کند.\n\n"
    "**بیمار: ۴۵ ساله با سل ریوی اسمیر مثبت، تحت رژیم استاندارد از ماه گذشته. از "
    "روز گذشته به‌طور ناگهانی دچار شوک، ترومبوسیتوپنی و نارسایی حاد کلیوی از نوع "
    "نفریت اینترستیشیل شده است.**\n\n"
    "**پاسخ: ریفامپین.**\n\n"
    "⚠️ **سه یافته را جدا نبینید — آن‌ها یک بیماری‌اند، نه سه بیماری.**\n\n"
    "**هر سه تظاهر یک چیز واحدند: یک واکنش ازدیاد حساسیت سیستمیک به ریفامپین که "
    "با آنتی‌بادی وابسته به دارو انجام می‌شود.**\n\n"
    "**فهرست کامل واکنش‌های ایمنی ریفامپین را کنار هم بگذارید:**\n\n"
    "**ترومبوسیتوپنی** (آنتی‌بادی علیه کمپلکس دارو-پلاکت) · **آنمی همولیتیک** "
    "(همان مکانیسم روی گلبول قرمز) · **نفریت بینابینی حاد** (رسوب کمپلکس ایمنی در "
    "بینابینی کلیه) · **شوک و افت فشار** (آزادسازی گسترده‌ی واسطه‌ها) · **سندرم "
    "شبه‌آنفلوانزا** (تب، لرز، درد عضلانی چند ساعت پس از دوز)\n\n"
    "**در این بیمار، سه مورد از این پنج، هم‌زمان رخ داده — یعنی یک واکنش سیستمیک "
    "شدید.**\n\n"
    "⚠️ **نکته‌ی مهم درباره‌ی زمان‌بندی: چرا در ماه دوم و نه در روز اول؟**\n\n"
    "**چون این واکنش نیازمند حساس‌سازی قبلی است.** بدن باید ابتدا با دارو مواجه "
    "شود، آنتی‌بادی بسازد، و سپس در مواجهه‌ی بعدی واکنش نشان دهد. **به همین دلیل "
    "این عوارض معمولاً پس از هفته‌ها تا ماه‌ها ظاهر می‌شوند، نه در ابتدا.**\n\n"
    "**و به همین دلیل، مصرف منقطع (سه بار در هفته) یا وقفه و شروع مجدد، خطر را "
    "به‌شدت بالا می‌برد** — چون هر بار قطع و شروع، یک چرخه‌ی حساس‌سازی-مواجهه "
    "می‌سازد. **این یکی از دلایلی است که امروز رژیم‌های روزانه بر رژیم‌های منقطع "
    "ترجیح دارند.**\n\n"
    "**اقدام: قطع فوری ریفامپین، درمان حمایتی شوک، و ممنوعیت دائمی این دارو.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**ایزونیازید** — هپاتیت و نوروپاتی محیطی. **الگوی سه‌گانه‌ی شوک-ترومبوسیتوپنی-"
    "نفریت را نمی‌سازد.**\n\n"
    "**اتامبوتول** — نوریت اپتیک، و نیازمند تعدیل در نارسایی کلیه. **علت نارسایی "
    "کلیه نمی‌شود، بلکه قربانی آن است.**\n\n"
    "**پیرازینامید** — هیپراوریسمی و هپاتیت. **می‌تواند نفروپاتی اوراتی بدهد، ولی "
    "نه نفریت بینابینی حاد ایمنی، و قطعاً نه شوک با ترومبوسیتوپنی.**\n\n"
    "⚠️ **قاعده‌ی جمع‌بندی برای امتحان: هر جا در درمان سل، یک تظاهر ایمنی حاد دیدید "
    "— ترومبوسیتوپنی، همولیز، نفریت بینابینی، شوک — پاسخ ریفامپین است.**",
    "This question shows the same immune mechanism, but this time with THREE SIMULTANEOUS MANIFESTATIONS — and that simultaneity clinches the diagnosis.\n\n"
    "THE PATIENT: 45 years old, on the standard regimen for smear-positive pulmonary tuberculosis since last month. Since yesterday he has suddenly developed SHOCK, THROMBOCYTOPENIA and ACUTE RENAL FAILURE OF THE INTERSTITIAL NEPHRITIS TYPE.\n\n"
    "THE ANSWER: RIFAMPICIN.\n\n"
    "WARNING: DO NOT SEE THE THREE FINDINGS SEPARATELY — THEY ARE ONE DISEASE, NOT THREE.\n\n"
    "ALL THREE ARE THE SAME THING: A SYSTEMIC HYPERSENSITIVITY REACTION TO RIFAMPICIN MEDIATED BY DRUG-DEPENDENT ANTIBODY.\n\n"
    "PUT THE FULL LIST OF RIFAMPICIN'S IMMUNE REACTIONS TOGETHER:\n\n"
    "THROMBOCYTOPENIA (antibody against the drug-platelet complex), HAEMOLYTIC ANAEMIA (the same mechanism on the red cell), ACUTE INTERSTITIAL NEPHRITIS (immune complex deposition in the renal interstitium), SHOCK AND HYPOTENSION (massive mediator release), and a FLU-LIKE SYNDROME (fever, chills, myalgia hours after the dose).\n\n"
    "IN THIS PATIENT, THREE OF THOSE FIVE HAVE OCCURRED AT ONCE — a severe systemic reaction.\n\n"
    "WARNING, AN IMPORTANT POINT ABOUT TIMING: WHY IN THE SECOND MONTH AND NOT ON DAY ONE?\n\n"
    "BECAUSE THIS REACTION REQUIRES PRIOR SENSITISATION. The body must first meet the drug, make antibody, and then react on subsequent exposure. THAT IS WHY THESE EFFECTS TYPICALLY APPEAR AFTER WEEKS TO MONTHS RATHER THAN AT THE START.\n\n"
    "AND THAT IS ALSO WHY INTERMITTENT DOSING (three times weekly), OR AN INTERRUPTION FOLLOWED BY A RESTART, SHARPLY RAISES THE RISK — every stop-and-start creates another sensitisation-and-challenge cycle. THIS IS ONE OF THE REASONS DAILY REGIMENS ARE NOW PREFERRED OVER INTERMITTENT ONES.\n\n"
    "MANAGEMENT: stop rifampicin at once, support the circulation, and forbid the drug permanently.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ISONIAZID — hepatitis and peripheral neuropathy. IT DOES NOT PRODUCE THE SHOCK-THROMBOCYTOPENIA-NEPHRITIS TRIAD.\n\n"
    "ETHAMBUTOL — optic neuritis, and it needs adjustment in renal failure. IT IS NOT A CAUSE OF RENAL FAILURE BUT A VICTIM OF IT.\n\n"
    "PYRAZINAMIDE — hyperuricaemia and hepatitis. IT CAN CAUSE URATE NEPHROPATHY, BUT NOT IMMUNE ACUTE INTERSTITIAL NEPHRITIS, AND CERTAINLY NOT SHOCK WITH THROMBOCYTOPENIA.\n\n"
    "WARNING, THE SUMMARISING RULE FOR THE EXAMINATION: WHEREVER IN TUBERCULOSIS TREATMENT YOU SEE AN ACUTE IMMUNE MANIFESTATION — THROMBOCYTOPENIA, HAEMOLYSIS, INTERSTITIAL NEPHRITIS, SHOCK — THE ANSWER IS RIFAMPICIN.",
    ["هپاتیت و نوروپاتی محیطی می‌دهد؛ سه‌گانه‌ی شوک-ترومبوسیتوپنی-نفریت را نمی‌سازد.",
     "پاسخ صحیح — واکنش ازدیاد حساسیت سیستمیک ریفامپین با آنتی‌بادی وابسته به دارو.",
     "نوریت اپتیک می‌دهد و در نارسایی کلیه قربانی است، نه علت.",
     "می‌تواند نفروپاتی اوراتی بدهد ولی نه نفریت بینابینی ایمنی و نه شوک."],
    ["Causes hepatitis and peripheral neuropathy; it does not produce the shock-thrombocytopenia-nephritis triad.",
     "Correct — a systemic rifampicin hypersensitivity reaction mediated by drug-dependent antibody.",
     "Causes optic neuritis and in renal failure it is the victim, not the cause.",
     "Can cause urate nephropathy but not immune interstitial nephritis, and certainly not shock."],
    "**هر تظاهر ایمنی حاد در درمان سل — ترومبوسیتوپنی، همولیز، نفریت، شوک — یعنی ریفامپین.**",
    "Any acute immune manifestation during tuberculosis treatment — thrombocytopenia, haemolysis, nephritis, shock — means rifampicin.",
    REFSA)

add("book:258", "recall", "hard",
    "**تنها هپاتیت ایزونیازید است که نیاز به قطع دائمی ندارد.**",
    "Only isoniazid hepatitis does not require permanent discontinuation.",
    IMMUNE_FA + [
        "⚠️ **این سؤال، تمام فصل عوارض را در یک جدول جمع می‌کند.**",
        "**سمّی و برگشت‌پذیر ⇐ بازگشت‌پذیر. ایمنی یا برگشت‌ناپذیر ⇐ ممنوعیت دائمی.**",
    ],
    IMMUNE_EN + [
        "WARNING: THIS QUESTION GATHERS THE WHOLE TOXICITY CHAPTER INTO ONE TABLE.",
        "Toxic and reversible means rechallengeable. Immune or irreversible means permanent prohibition.",
    ],
    "این سؤال، **جمع‌بندی کل مبحث عوارض** است: چهار عارضه، و باید بگویید کدام‌یک "
    "**نیاز به قطع دائمی ندارد**.\n\n"
    "**پاسخ: هپاتیت با ایزونیازید.**\n\n"
    "⚠️ **اصل حاکم بر همه‌ی چهار گزینه، یک جمله است:**\n\n"
    "**عارضه‌ی سمّی و برگشت‌پذیر ⇐ دارو پس از بهبود می‌تواند برگردد.**\n\n"
    "**واکنش ایمنی یا آسیب برگشت‌ناپذیر ⇐ دارو برای همیشه ممنوع.**\n\n"
    "**حالا چهار گزینه را با این محک بسنجیم:**\n\n"
    "**۱. هپاتیت با ایزونیازید** ✔ **(پاسخ)** — این یک **آسیب سمّی** است، محصول "
    "متابولیت‌های واکنش‌پذیر. **کبد قدرت بازسازی فوق‌العاده‌ای دارد** و پس از قطع "
    "دارو، آنزیم‌ها ظرف ۱ تا ۴ هفته نرمال می‌شوند.\n\n"
    "**و در عمل بالینی، ایزونیازید در اکثر موارد با احتیاط برگردانده می‌شود:** پس از "
    "نرمال شدن آنزیم‌ها، **با دوز کم شروع و به‌تدریج افزایش، با پایش آزمایشگاهی "
    "نزدیک**. **چرا این‌قدر اصرار؟** چون ایزونیازید **قوی‌ترین داروی کشنده‌ی زودرس** "
    "است و رژیم بدون آن، به‌مراتب ضعیف‌تر و طولانی‌تر می‌شود.\n\n"
    "**(استثنا: اگر هپاتیت شدید بوده باشد — زردی، افزایش INR، انسفالوپاتی — "
    "بازگرداندن ایزونیازید توصیه نمی‌شود.)**\n\n"
    "**۲. نوریت اپتیک با اتامبوتول** ✘ — **قطع دائمی.** آسیب عصب بینایی می‌تواند "
    "**برگشت‌ناپذیر** باشد و شروع مجدد، خطر **کوری دائمی** دارد. **و چون اتامبوتول "
    "ضعیف‌ترین داروی رژیم است، حذفش هزینه‌ی کمی دارد.**\n\n"
    "**۳. ترومبوسیتوپنی با ریفامپین** ✘ — **قطع دائمی.** یک **واکنش ایمنی** با "
    "آنتی‌بادی وابسته به دارو. **آنتی‌بادی در بدن می‌ماند** و مواجهه‌ی مجدد می‌تواند "
    "**کشنده** باشد.\n\n"
    "**۴. آرتریت نقرسی با پیرازینامید** — ⚠️ **گزینه‌ی سخت این سؤال، و ارزش بحث "
    "دارد.** آرترالژی خفیف پیرازینامید **بسیار شایع است و اصلاً نیاز به قطع ندارد** "
    "— با NSAID کنترل می‌شود. **ولی سؤال از «آرتریت نقرسی» می‌گوید، یعنی حمله‌ی "
    "کامل نقرس با التهاب مفصلی.** در آن حالت، چون پیرازینامید **مستقیماً و به‌طور "
    "مداوم دفع اورات را مهار می‌کند**، ادامه‌اش حملات را تکرار می‌کند. **و از آنجا که "
    "پیرازینامید فقط در دو ماه اول لازم است، حذف کاملش هزینه‌ی قابل‌قبولی دارد** "
    "(با تمدید فاز نگهدارنده به ۷ ماه). **پس در کتاب، این هم قطع دائمی محسوب شده.**\n\n"
    "**جدول ذهنی نهایی که باید با خود ببرید:**\n\n"
    "**قابل بازگشت: هپاتیت (همه‌ی داروها، پس از بهبود، یکی‌یکی) و آرترالژی خفیف "
    "پیرازینامید.**\n\n"
    "**ممنوعیت دائمی: نوریت اپتیک اتامبوتول · همه‌ی واکنش‌های ایمنی ریفامپین "
    "(ترومبوسیتوپنی، همولیز، نفریت بینابینی، شوک) · و نقرس واقعی با پیرازینامید.**",
    "This question SUMS UP THE ENTIRE TOXICITY TOPIC: four adverse effects, and you must say which does NOT require permanent discontinuation.\n\n"
    "THE ANSWER: HEPATITIS WITH ISONIAZID.\n\n"
    "WARNING: ONE SENTENCE GOVERNS ALL FOUR OPTIONS:\n\n"
    "A TOXIC AND REVERSIBLE EFFECT MEANS THE DRUG CAN RETURN AFTER RECOVERY.\n\n"
    "AN IMMUNE REACTION OR IRREVERSIBLE INJURY MEANS THE DRUG IS FORBIDDEN FOR LIFE.\n\n"
    "NOW TEST THE FOUR AGAINST THAT RULE:\n\n"
    "1. HEPATITIS WITH ISONIAZID (THE ANSWER) — this is TOXIC injury, the product of reactive metabolites. THE LIVER HAS REMARKABLE REGENERATIVE CAPACITY and after stopping the drug the enzymes normalise within 1 to 4 weeks.\n\n"
    "AND IN PRACTICE ISONIAZID IS USUALLY REINTRODUCED CAUTIOUSLY: once enzymes are normal, STARTING AT A LOW DOSE AND INCREASING GRADUALLY WITH CLOSE MONITORING. WHY SUCH INSISTENCE? Because isoniazid is THE MOST POWERFUL EARLY BACTERICIDAL DRUG and a regimen without it is far weaker and far longer.\n\n"
    "(An exception: if the hepatitis was severe — jaundice, rising INR, encephalopathy — reintroduction is not advised.)\n\n"
    "2. OPTIC NEURITIS WITH ETHAMBUTOL — PERMANENT DISCONTINUATION. Optic nerve injury can be IRREVERSIBLE and rechallenge risks PERMANENT BLINDNESS. AND BECAUSE ETHAMBUTOL IS THE WEAKEST DRUG IN THE REGIMEN, LOSING IT COSTS LITTLE.\n\n"
    "3. THROMBOCYTOPENIA WITH RIFAMPICIN — PERMANENT DISCONTINUATION. An IMMUNE reaction with drug-dependent antibody. THE ANTIBODY PERSISTS and re-exposure can be FATAL.\n\n"
    "4. GOUTY ARTHRITIS WITH PYRAZINAMIDE — WARNING, THE HARD OPTION HERE, AND WORTH DISCUSSING. Mild pyrazinamide ARTHRALGIA IS VERY COMMON AND NEEDS NO DISCONTINUATION AT ALL — an NSAID controls it. BUT THE QUESTION SAYS 'GOUTY ARTHRITIS', meaning a full attack with joint inflammation. In that case, because pyrazinamide CONTINUOUSLY AND DIRECTLY BLOCKS URATE EXCRETION, continuing it will keep provoking attacks. AND SINCE PYRAZINAMIDE IS ONLY NEEDED FOR THE FIRST TWO MONTHS, REMOVING IT ENTIRELY IS AN ACCEPTABLE COST (extending the continuation phase to 7 months). SO IN THE BOOK THIS TOO COUNTS AS PERMANENT DISCONTINUATION.\n\n"
    "THE FINAL MENTAL TABLE TO CARRY AWAY:\n\n"
    "RECHALLENGEABLE: hepatitis (all drugs, after recovery, one at a time) and mild pyrazinamide arthralgia.\n\n"
    "PERMANENTLY FORBIDDEN: ethambutol optic neuritis; every rifampicin immune reaction (thrombocytopenia, haemolysis, interstitial nephritis, shock); and true gout with pyrazinamide.",
    ["آسیب می‌تواند برگشت‌ناپذیر باشد و شروع مجدد خطر کوری دارد؛ قطع دائمی.",
     "واکنش ایمنی با آنتی‌بادی ماندگار؛ مواجهه‌ی مجدد می‌تواند کشنده باشد؛ قطع دائمی.",
     "پیرازینامید دفع اورات را مداوم مهار می‌کند و حملات تکرار می‌شود؛ قطع دائمی.",
     "پاسخ صحیح — آسیب سمّی و برگشت‌پذیر؛ پس از نرمال شدن آنزیم‌ها با احتیاط برمی‌گردد."],
    ["The injury can be irreversible and rechallenge risks blindness; permanent discontinuation.",
     "An immune reaction with a persisting antibody; re-exposure can be fatal; permanent discontinuation.",
     "Pyrazinamide continuously blocks urate excretion and attacks recur; permanent discontinuation.",
     "Correct — toxic and reversible injury; once the enzymes normalise the drug is cautiously reintroduced."],
    "**سمّی و برگشت‌پذیر یعنی بازگشت‌پذیر؛ ایمنی یا برگشت‌ناپذیر یعنی ممنوعیت دائمی.**",
    "Toxic and reversible means rechallengeable; immune or irreversible means permanent prohibition.",
    REFSA)

# ==================================================== BCG-OSIS
BCG_FA = [
    "⚠️ **مایکوباکتریوم بوویس، سویه‌ی واکسن ب‌ث‌ژ، به پیرازینامید مقاومت ذاتی دارد.**",
    "**«ذاتی» یعنی همیشه، در همه‌ی سویه‌ها، و مستقل از مصرف قبلی دارو.**",
    "**مکانیسم: ژن pncA در بوویس جهش دارد.**",
    "**و آنزیم پیرازینامیداز که این ژن می‌سازد، برای فعال شدن دارو ضروری است.**",
    "**پیرازینامید یک پیش‌دارو است: باید به پیرازینوئیک اسید تبدیل شود.**",
    "**بدون پیرازینامیداز، این تبدیل رخ نمی‌دهد و دارو بی‌اثر است.**",
    "⚠️ **پس در هر عفونت با مایکوباکتریوم بوویس، پیرازینامید را حذف کنید.**",
    "**و این شامل ب‌ث‌ژایتیس منتشر پس از واکسن هم می‌شود.**",
    "**ب‌ث‌ژایتیس منتشر، نشانه‌ی نقص ایمنی زمینه‌ای است.**",
    "**بیماری گرانولوماتوز مزمن یا نقص محور اینترفرون گاما و IL-12.**",
    "**تست NBT مثبت، یعنی بیماری گرانولوماتوز مزمن.**",
    "**درمان: ایزونیازید، ریفامپین و اتامبوتول — بدون پیرازینامید.**",
]
BCG_EN = [
    "WARNING: MYCOBACTERIUM BOVIS, THE BCG VACCINE STRAIN, IS INTRINSICALLY RESISTANT TO PYRAZINAMIDE.",
    "'Intrinsic' means always, in every strain, and independently of prior drug exposure.",
    "The mechanism: the pncA gene is mutated in M. bovis.",
    "And the pyrazinamidase enzyme that gene encodes is required to activate the drug.",
    "Pyrazinamide is a PRODRUG: it must be converted to pyrazinoic acid.",
    "Without pyrazinamidase that conversion does not happen and the drug is inert.",
    "WARNING: SO IN ANY MYCOBACTERIUM BOVIS INFECTION, LEAVE PYRAZINAMIDE OUT.",
    "And that includes disseminated BCG disease after vaccination.",
    "Disseminated BCG-osis is a marker of an underlying immune defect.",
    "Chronic granulomatous disease, or a defect of the interferon-gamma / IL-12 axis.",
    "A positive NBT test means chronic granulomatous disease.",
    "Treatment: isoniazid, rifampicin and ethambutol — without pyrazinamide.",
]

add("book:238", "vignette", "hard",
    "**ب‌ث‌ژایتیس منتشر: پیرازینامید مقاومت ذاتی دارد و بی‌فایده است.**",
    "Disseminated BCG disease: pyrazinamide is intrinsically resistant and useless.",
    BCG_FA, BCG_EN,
    "این سخت‌ترین سؤال دارویی این فصل است، و پاسخش یک واقعیت میکروب‌شناسی است که "
    "کاربرد بالینی مستقیم دارد.\n\n"
    "**بیمار: نوزادی که در بدو تولد واکسینه شده، یک هفته بعد با تورم منتشر غدد "
    "لنفاوی، تب و کاهش میل به شیرخوردن مراجعه کرده. تست NBT مثبت است. با تشخیص "
    "مایکوباکتریوم منتشر ناشی از واکسن تحت درمان قرار می‌گیرد. کدام دارو مقاومت "
    "ذاتی به این مایکوباکتریوم دارد؟**\n\n"
    "**پاسخ: پیرازینامید.**\n\n"
    "**اول، تشخیص را بسازید:**\n\n"
    "**واکسن ب‌ث‌ژ از سویه‌ی ضعیف‌شده‌ی مایکوباکتریوم بوویس ساخته می‌شود.** در نوزاد "
    "سالم، این باسیل زنده‌ی ضعیف‌شده فقط یک واکنش موضعی می‌دهد. **ولی در نوزاد با "
    "نقص ایمنی، می‌تواند منتشر شود — پدیده‌ای که «ب‌ث‌ژایتیس منتشر» (BCG-osis) "
    "نامیده می‌شود.**\n\n"
    "⚠️ **و «تست NBT مثبت» تشخیص نقص ایمنی را قطعی می‌کند: بیماری گرانولوماتوز مزمن "
    "(CGD)** — نقص NADPH اکسیداز که در آن نوتروفیل بلع می‌کند ولی نمی‌تواند بکشد. "
    "(نقص محور اینترفرون گاما / IL-12 هم علت شناخته‌شده‌ی دیگر ب‌ث‌ژایتیس است.)\n\n"
    "**حالا سؤال دارویی: چرا پیرازینامید؟**\n\n"
    "⚠️ **مایکوباکتریوم بوویس مقاومت ذاتی و کامل به پیرازینامید دارد.** «ذاتی» "
    "(intrinsic) یعنی این مقاومت **ویژگی خود گونه است**، نه نتیجه‌ی مصرف قبلی دارو "
    "یا انتخاب سویه‌ی مقاوم.\n\n"
    "**مکانیسم، زیبا و کاملاً قابل درک است:**\n\n"
    "**پیرازینامید یک پیش‌دارو (prodrug) است.** به‌خودی‌خود هیچ اثری ندارد. **باید "
    "درون باکتری به پیرازینوئیک اسید تبدیل شود** تا فعال گردد.\n\n"
    "**آنزیمی که این تبدیل را انجام می‌دهد، پیرازینامیداز است، و ژنش pncA نام "
    "دارد.**\n\n"
    "**در مایکوباکتریوم بوویس، ژن pncA یک جهش نقطه‌ای دارد که آنزیم را غیرفعال "
    "می‌کند.** پس دارو وارد باکتری می‌شود، ولی **هرگز فعال نمی‌شود** و بی‌اثر خارج "
    "می‌شود.\n\n"
    "**(نکته‌ی جالب: همین جهش pncA، مکانیسم مقاومت اکتسابی به پیرازینامید در "
    "مایکوباکتریوم توبرکلوزیس هم هست. یعنی یک ژن، دو داستان.)**\n\n"
    "**پیامد بالینی مستقیم: در هر عفونت با مایکوباکتریوم بوویس — چه ب‌ث‌ژایتیس، چه "
    "سل ناشی از شیر غیرپاستوریزه — رژیم درمانی باید بدون پیرازینامید باشد.** یعنی "
    "**ایزونیازید + ریفامپین + اتامبوتول**، و معمولاً برای مدت طولانی‌تر.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**اتامبوتول** — علیه مایکوباکتریوم بوویس **فعال است** و در رژیم درمان "
    "ب‌ث‌ژایتیس **حضور دارد**.\n\n"
    "**ریفامپین** — **فعال است**، و در واقع **ستون درمان ب‌ث‌ژایتیس منتشر** محسوب "
    "می‌شود.\n\n"
    "**ایزونیازید** — **فعال است** و بخش اصلی رژیم.\n\n"
    "**درس ماندگار: «مقاومت ذاتی» را با «مقاومت اکتسابی» اشتباه نگیرید. اولی ویژگی "
    "گونه است و در کتاب میکروب‌شناسی نوشته شده؛ دومی حاصل درمان است و در "
    "آنتی‌بیوگرام ظاهر می‌شود.**",
    "This is the hardest pharmacological question in the chapter, and its answer is a microbiological fact with direct clinical use.\n\n"
    "THE PATIENT: a newborn vaccinated at birth who, a week later, presents with GENERALISED LYMPHADENOPATHY, fever and poor feeding. THE NBT TEST IS POSITIVE. He is treated for disseminated vaccine-derived mycobacterial disease. Which drug is INTRINSICALLY RESISTANT to this mycobacterium?\n\n"
    "THE ANSWER: PYRAZINAMIDE.\n\n"
    "FIRST, BUILD THE DIAGNOSIS:\n\n"
    "THE BCG VACCINE IS MADE FROM AN ATTENUATED STRAIN OF MYCOBACTERIUM BOVIS. In a healthy infant this live attenuated bacillus produces only a local reaction. BUT IN AN INFANT WITH AN IMMUNE DEFECT IT CAN DISSEMINATE — a phenomenon called DISSEMINATED BCG DISEASE (BCG-osis).\n\n"
    "WARNING: AND 'A POSITIVE NBT TEST' SETTLES THE IMMUNE DIAGNOSIS: CHRONIC GRANULOMATOUS DISEASE (CGD) — an NADPH oxidase defect in which the neutrophil can engulf but cannot kill. (A defect of the interferon-gamma / IL-12 axis is the other recognised cause of BCG-osis.)\n\n"
    "NOW THE PHARMACOLOGICAL QUESTION: WHY PYRAZINAMIDE?\n\n"
    "WARNING: MYCOBACTERIUM BOVIS IS INTRINSICALLY AND COMPLETELY RESISTANT TO PYRAZINAMIDE. 'Intrinsic' means the resistance IS A PROPERTY OF THE SPECIES ITSELF, not the result of previous drug exposure or selection.\n\n"
    "THE MECHANISM IS ELEGANT AND ENTIRELY COMPREHENSIBLE:\n\n"
    "PYRAZINAMIDE IS A PRODRUG. By itself it does nothing. IT MUST BE CONVERTED INSIDE THE BACTERIUM INTO PYRAZINOIC ACID to become active.\n\n"
    "THE ENZYME THAT PERFORMS THAT CONVERSION IS PYRAZINAMIDASE, ENCODED BY THE pncA GENE.\n\n"
    "IN MYCOBACTERIUM BOVIS THE pncA GENE CARRIES A POINT MUTATION THAT INACTIVATES THE ENZYME. So the drug enters the bacterium but IS NEVER ACTIVATED and leaves without effect.\n\n"
    "(An interesting note: that same pncA mutation is also the mechanism of ACQUIRED pyrazinamide resistance in M. tuberculosis. One gene, two stories.)\n\n"
    "THE DIRECT CLINICAL CONSEQUENCE: in any Mycobacterium bovis infection — BCG-osis, or tuberculosis from unpasteurised milk — THE REGIMEN MUST OMIT PYRAZINAMIDE. That is, ISONIAZID PLUS RIFAMPICIN PLUS ETHAMBUTOL, usually for longer.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ETHAMBUTOL — ACTIVE against M. bovis and PRESENT in the BCG-osis regimen.\n\n"
    "RIFAMPICIN — ACTIVE, and indeed THE BACKBONE of treatment for disseminated BCG disease.\n\n"
    "ISONIAZID — ACTIVE and a core part of the regimen.\n\n"
    "THE LASTING LESSON: do not confuse INTRINSIC with ACQUIRED resistance. The first is a species property written in the microbiology textbook; the second is a product of treatment and appears on the susceptibility report.",
    ["پاسخ صحیح — بوویس ژن pncA جهش‌یافته دارد و پیرازینامید پیش‌دارو فعال نمی‌شود.",
     "علیه مایکوباکتریوم بوویس فعال است و در رژیم درمان ب‌ث‌ژایتیس حضور دارد.",
     "فعال است و در واقع ستون درمان ب‌ث‌ژایتیس منتشر محسوب می‌شود.",
     "فعال است و بخش اصلی رژیم درمانی ب‌ث‌ژایتیس است."],
    ["Correct — M. bovis has a mutated pncA gene and the pyrazinamide prodrug is never activated.",
     "Active against M. bovis and present in the BCG-osis regimen.",
     "Active, and indeed the backbone of treatment for disseminated BCG disease.",
     "Active and a core part of the BCG-osis regimen."],
    "**پیرازینامید پیش‌دارو است؛ بوویس آنزیم فعال‌کننده ندارد، پس دارو هرگز روشن نمی‌شود.**",
    "Pyrazinamide is a prodrug; M. bovis lacks the activating enzyme, so the drug never switches on.",
    REFS)

json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book54.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 54 lessons:', len(L))
