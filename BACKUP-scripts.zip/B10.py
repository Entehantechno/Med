# -*- coding: utf-8 -*-
"""Micro-lessons, batch 10 — the sepsis staging and resuscitation block.

Why this chapter, and why it had to wait for the vitals repair
--------------------------------------------------------------
Forty-four questions with five taught. But this chapter could not be written
until the vital signs were fixed, because it is the one chapter whose answers
are COMPUTED from the numbers in the stem. A block of these questions asks the
student to classify a patient — SIRS, sepsis, severe sepsis or septic shock —
and that classification reads directly off the respiratory rate, the pulse and
the blood pressure.

Before the repair, several of these stems were unusable: an axillary
temperature of 83 degrees, a blood pressure of 5 over 7, a pulse of 401. A
student cannot stage a patient whose blood pressure is 5/7, and worse, a
mirrored pressure can flip the answer between "severe sepsis" and "septic
shock". fix_vitals_geometry.py corrected sixteen of these from glyph geometry
first; only then could the block be taught.

The staging ladder (the classical criteria these sittings examined)
-------------------------------------------------------------------
    SIRS          two or more of: T >38 or <36, HR >90, RR >20 (or PaCO2 <32),
                  WBC >12000 or <4000 or >10% bands
    Sepsis        SIRS plus a documented or suspected source of infection
    Severe sepsis sepsis plus ORGAN DYSFUNCTION or hypoperfusion
                  (oliguria, altered mental state, lactate, raised creatinine,
                  and hypotension that CORRECTS with fluid)
    Septic shock  hypotension that PERSISTS despite adequate fluid
                  resuscitation and needs a vasopressor
    Refractory    shock that persists despite fluid AND vasopressor

The single discriminator students get wrong is the last step, and it is not a
number at all: it is whether the blood pressure RESPONDS TO FLUID. Two patients
with identical vitals are staged differently depending on what happened after
a litre of saline. Every staging lesson in this batch turns on that hinge.

A note on Sepsis-3: the 2016 definitions replaced this ladder with qSOFA/SOFA
and abolished "severe sepsis" as a category. The Iranian pre-internship
sittings from 93 to 98 examined the classical criteria, and the printed keys
follow them, so the lessons teach the classical ladder AND tell the student
that the modern definition differs — otherwise a student reading Harrison 21e
would think the bank is wrong.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022),
Chapter 297; Surviving Sepsis Campaign.
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 297"
SSC = "Surviving Sepsis Campaign — International Guidelines"

LADDER_FA = [
    "**نردبان سپسیس** را همیشه از پایین به بالا بالا بروید؛ هر پله یک شرط اضافه دارد.",
    "**پله‌ی اول — SIRS**: دو مورد یا بیشتر از چهار معیار زیر.",
    "معیار یک: دما بالای ۳۸ یا زیر ۳۶ درجه.",
    "معیار دو: ضربان قلب بالای ۹۰ در دقیقه.",
    "معیار سه: تعداد تنفس بالای ۲۰ در دقیقه (یا PaCO₂ زیر ۳۲).",
    "معیار چهار: گلبول سفید بالای ۱۲۰۰۰، زیر ۴۰۰۰، یا بیش از ۱۰٪ باند.",
    "**پله‌ی دوم — سپسیس**: همان SIRS، به‌علاوه‌ی یک **منبع عفونت** مستند یا مشکوک.",
    "**پله‌ی سوم — سپسیس شدید**: سپسیس، به‌علاوه‌ی **اختلال عملکرد ارگان** یا هیپوپرفیوژن.",
    "نشانه‌های اختلال ارگان: الیگوری، کاهش هوشیاری، لاکتات بالا، کراتینین بالا.",
    "و مهم‌تر از همه: افت فشاری که **با مایع اصلاح می‌شود**.",
    "**پله‌ی چهارم — شوک سپتیک**: افت فشاری که **با وجود مایع کافی باقی می‌ماند** و وازوپرسور می‌خواهد.",
    "**پله‌ی پنجم — شوک مقاوم**: با وجود **هم مایع و هم وازوپرسور** همچنان هیپوتانسیو است.",
    "⚠️ لولای تصمیم، عدد نیست — **پاسخ فشار خون به مایع** است.",
    "دو بیمار با علائم حیاتی کاملاً یکسان، بسته به اینکه بعد از یک لیتر سالین چه شد، دو تشخیص می‌گیرند.",
    "پس همیشه در صورت سؤال دنبال جمله‌ی «بعد از تجویز سرم...» بگردید؛ آنجا جواب است.",
]
LADDER_EN = [
    "Always climb the SEPSIS LADDER from the bottom; each rung adds one condition.",
    "RUNG ONE, SIRS: two or more of the following four criteria.",
    "Criterion one: temperature above 38 or below 36 degrees.",
    "Criterion two: heart rate above 90 per minute.",
    "Criterion three: respiratory rate above 20 per minute (or PaCO2 below 32).",
    "Criterion four: white cells above 12000, below 4000, or more than 10% bands.",
    "RUNG TWO, SEPSIS: SIRS plus a documented or suspected SOURCE OF INFECTION.",
    "RUNG THREE, SEVERE SEPSIS: sepsis plus ORGAN DYSFUNCTION or hypoperfusion.",
    "Signs of organ dysfunction: oliguria, altered mental state, raised lactate, raised creatinine.",
    "And most importantly: hypotension that CORRECTS with fluid.",
    "RUNG FOUR, SEPTIC SHOCK: hypotension that PERSISTS despite adequate fluid and needs a vasopressor.",
    "RUNG FIVE, REFRACTORY SHOCK: still hypotensive despite BOTH fluid AND a vasopressor.",
    "WARNING: the hinge is not a number — it is HOW THE BLOOD PRESSURE RESPONDS TO FLUID.",
    "Two patients with identical vital signs get different diagnoses depending on what happened after a litre of saline.",
    "So always look for the sentence 'after giving fluid...' in the stem; that is where the answer is.",
]

SEPSIS3_FA = [
    "⚠️ نکته‌ی به‌روز: تعریف **Sepsis-3** (سال ۲۰۱۶) این نردبان را عوض کرده است.",
    "در تعریف جدید، «سپسیس شدید» به‌عنوان یک دسته‌ی جداگانه **حذف شده** است.",
    "سپسیس جدید یعنی: عفونت به‌علاوه‌ی افزایش دو نمره یا بیشتر در SOFA.",
    "و شوک سپتیک یعنی: نیاز به وازوپرسور برای MAP ≥۶۵ به‌همراه لاکتات بالای ۲.",
    "ابزار غربالگری کنار تخت هم qSOFA است: تنفس ≥۲۲، تغییر هوشیاری، فشار سیستولی ≤۱۰۰.",
    "ولی آزمون‌های پیش‌کارورزی ۹۳ تا ۹۸ بر پایه‌ی معیارهای **کلاسیک** طراحی شده‌اند.",
    "پس اینجا با نردبان کلاسیک پاسخ می‌دهیم، ولی بدانید که در بالین امروز SOFA حاکم است.",
]
SEPSIS3_EN = [
    "WARNING, an update: the Sepsis-3 definitions (2016) changed this ladder.",
    "In the new definition, 'severe sepsis' has been ABOLISHED as a separate category.",
    "Sepsis now means infection plus a rise of two or more points in the SOFA score.",
    "And septic shock means needing a vasopressor for a MAP of 65 or more, with lactate above 2.",
    "The bedside screening tool is qSOFA: respiratory rate 22 or more, altered mentation, systolic 100 or less.",
    "But the pre-internship sittings from 93 to 98 were written on the CLASSICAL criteria.",
    "So we answer with the classical ladder here, while knowing that SOFA governs current practice.",
]

FLUID_FA = [
  "در سپسیس، **اولین** اقدام همودینامیک همیشه **احیای با مایع کریستالوئید** است.",
  "دلیلش پاتوفیزیولوژی است: سپسیس یک شوک **توزیعی** با کمبود حجم نسبی است.",
  "واسطه‌های التهابی باعث اتساع عروق و **نشت مویرگی** می‌شوند.",
  "پس حجم داخل عروقی به فضای بینابینی می‌رود و بستر عروقی نسبت به حجم، بزرگ‌تر می‌شود.",
  "منطقی است که اول این ظرفِ خالی را پر کنیم، بعد سراغ تنگ کردن عروق برویم.",
  "کریستالوئید (نرمال سالین یا رینگر لاکتات) داروی انتخابی است، نه کلوئید.",
  "حجم اولیه‌ی توصیه‌شده حدود **۳۰ میلی‌لیتر بر کیلوگرم** در سه ساعت اول است.",
  "**وازوپرسور** فقط وقتی اضافه می‌شود که با وجود مایع کافی فشار پایین بماند.",
  "و وازوپرسور خط اول **نوراپی‌نفرین** است؛ دوپامین به دلیل آریتمی کنار گذاشته شده.",
  "هدف همودینامیک کلاسیک: **فشار متوسط شریانی (MAP) بالای ۶۵ میلی‌متر جیوه**.",
  "دادن وازوپرسور به بیمار هیپوولمیک، عروق را تنگ می‌کند بدون آنکه حجمی برای پمپ کردن باشد.",
  "نتیجه‌اش بدتر شدن پرفیوژن بافتی و ایسکمی اندام است — یعنی ضرر مستقیم.",
]
FLUID_EN = [
  "In sepsis the FIRST haemodynamic action is always CRYSTALLOID FLUID RESUSCITATION.",
  "The reason is pathophysiology: sepsis is a DISTRIBUTIVE shock with relative hypovolaemia.",
  "Inflammatory mediators cause vasodilatation and CAPILLARY LEAK.",
  "So intravascular volume moves into the interstitium and the vascular bed becomes too large for the volume.",
  "It makes sense to fill that enlarged container first, and only then to narrow it.",
  "Crystalloid (normal saline or Ringer's lactate) is the agent of choice, not colloid.",
  "The recommended initial volume is about 30 mL/kg within the first three hours.",
  "A VASOPRESSOR is added only when the pressure stays low despite adequate fluid.",
  "And the first-line vasopressor is NOREPINEPHRINE; dopamine has been set aside for arrhythmia risk.",
  "The classical haemodynamic target is a MEAN ARTERIAL PRESSURE above 65 mmHg.",
  "Giving a vasopressor to a hypovolaemic patient narrows the vessels with no volume to pump.",
  "The result is worse tissue perfusion and limb ischaemia — direct harm.",
]

# ---------------------------------------------------------------- idx 833
add("book:833", "case", "medium",
 "فشار با **یک لیتر سالین اصلاح شد** ← پس شوک نیست؛ **سپسیس شدید** است.",
 "The pressure CORRECTED with one litre of saline, so this is not shock — it is SEVERE SEPSIS.",
 LADDER_FA + [
  "این بیمار را پله‌به‌پله بالا ببرید. اول SIRS را بشمارید.",
  "تب ۳۹ درجه ← معیار اول ✓. نبض ۱۰۴ ← معیار دوم ✓. تنفس ۲۸ ← معیار سوم ✓.",
  "حالا منبع عفونت: علائم ادراری (بی‌اختیاری و تکرر) ← منبع مشخص است ← **سپسیس**.",
  "حالا اختلال ارگان: **خواب‌آلودگی** یعنی اختلال وضعیت ذهنی ← اختلال عملکرد ارگان ✓.",
  "و فشار خون ۸۰/۵۰ یعنی هیپوتانسیون ← هیپوپرفیوژن ✓.",
  "تا اینجا دست‌کم در پله‌ی **سپسیس شدید** هستیم. سؤال این است: آیا بالاتر می‌رویم؟",
  "⚠️ اینجاست که جمله‌ی کلیدی می‌آید: «بعد از تزریق ۱ لیتر نرمال سالین فشار به ۱۰۰/۷۰ رسید».",
  "یعنی هیپوتانسیون **به مایع پاسخ داد** و برطرف شد.",
  "طبق تعریف، شوک سپتیک افت فشاری است که با وجود مایع کافی **باقی می‌ماند**.",
  "چون اینجا باقی نماند، شوک سپتیک **نیست** و در پله‌ی سپسیس شدید متوقف می‌شویم.",
  "«حال عمومی به‌طور واضح بهتر شد» هم همین را تأیید می‌کند: پرفیوژن برگشته است.",
  "درس عملی: قبل از گفتن «شوک»، بپرسید بیمار مایع گرفته و چه شد.",
 ] + SEPSIS3_FA,
 LADDER_EN + [
  "Climb this patient rung by rung. First count SIRS.",
  "Fever 39 gives criterion one; pulse 104 gives criterion two; respiratory rate 28 gives criterion three.",
  "Now the source: urinary symptoms (incontinence and frequency) give a clear source, so SEPSIS.",
  "Now organ dysfunction: DROWSINESS is altered mental state, which counts as organ dysfunction.",
  "And a blood pressure of 80/50 is hypotension, so hypoperfusion as well.",
  "So far we are at least at SEVERE SEPSIS. The question is whether we climb higher.",
  "WARNING: here comes the key sentence — 'after one litre of normal saline the pressure reached 100/70'.",
  "That means the hypotension RESPONDED to fluid and resolved.",
  "By definition, septic shock is hypotension that PERSISTS despite adequate fluid.",
  "Since it did not persist, this is NOT septic shock, and we stop at severe sepsis.",
  "'His general condition clearly improved' confirms it: perfusion has been restored.",
  "Practical lesson: before saying 'shock', ask whether fluid was given and what happened.",
 ] + SEPSIS3_EN,
 "این سؤال دقیقاً همان چیزی را می‌سنجد که بیشترین خطا را می‌سازد: تفاوت **سپسیس شدید** و **شوک سپتیک**، که یک عدد نیست بلکه یک **پاسخ** است.\n\nبیمار را پله‌به‌پله بالا ببرید. SIRS: تب ۳۹ ✓، نبض ۱۰۴ ✓، تنفس ۲۸ ✓ — سه معیار از چهار. منبع عفونت: علائم ادراری ← **سپسیس**. اختلال ارگان: خواب‌آلودگی (اختلال وضعیت ذهنی) و هیپوتانسیون ۸۰/۵۰ ← **سپسیس شدید**.\n\nحالا جمله‌ی سرنوشت‌ساز: «بعد از تزریق ۱ لیتر نرمال سالین فشار به ۱۰۰/۷۰ رسید و حال عمومی واضحاً بهتر شد.» یعنی هیپوتانسیون **به مایع پاسخ داد**. طبق تعریف، شوک سپتیک افت فشاری است که با وجود مایع کافی **باقی می‌ماند** و به وازوپرسور نیاز پیدا می‌کند. چون اینجا فشار اصلاح شد، در پله‌ی **سپسیس شدید** می‌مانیم.\n\n⚠️ توجه کنید که در تعریف جدید Sepsis-3 (۲۰۱۶) دسته‌ی «سپسیس شدید» حذف شده است؛ ولی آزمون‌های ۹۳ تا ۹۸ بر پایه‌ی معیارهای کلاسیک طراحی شده‌اند و کلید هم همان را دنبال می‌کند.",
 "This question tests exactly what causes most errors: the difference between SEVERE SEPSIS and SEPTIC SHOCK, which is not a number but a RESPONSE.\n\nClimb rung by rung. SIRS: fever 39, pulse 104, respiratory rate 28 — three of four criteria. Source: urinary symptoms, so SEPSIS. Organ dysfunction: drowsiness (altered mental state) and hypotension at 80/50, so SEVERE SEPSIS.\n\nNow the decisive sentence: 'after one litre of normal saline the pressure reached 100/70 and his general condition clearly improved.' The hypotension RESPONDED to fluid. By definition, septic shock is hypotension that PERSISTS despite adequate fluid and requires a vasopressor. Because the pressure corrected here, we stay at SEVERE SEPSIS.\n\nNote that the Sepsis-3 definitions (2016) abolished the 'severe sepsis' category; but the 93-98 sittings were written on the classical criteria and the key follows them.",
 ["پاسخ صحیح — سپسیس با اختلال ارگان (خواب‌آلودگی) و افت فشاری که با مایع اصلاح شد.",
  "سپسیس تنها کافی نیست؛ این بیمار اختلال عملکرد ارگان و هیپوتانسیون هم دارد.",
  "شوک سپتیک نیست، چون فشار خون با یک لیتر سالین اصلاح شد و باقی نماند.",
  "SIRS تنها ناکافی است؛ منبع عفونت مشخص و اختلال ارگان هم وجود دارد."],
 ["Correct — sepsis with organ dysfunction (drowsiness) and hypotension that corrected with fluid.",
  "Sepsis alone is not enough; this patient also has organ dysfunction and hypotension.",
  "Not septic shock, because the pressure corrected with one litre of saline rather than persisting.",
  "SIRS alone is insufficient; there is a clear source of infection and organ dysfunction."],
 "فشار **با مایع اصلاح شد** ← سپسیس شدید. فشار **با وجود مایع باقی ماند** ← شوک سپتیک.",
 "Pressure CORRECTS with fluid means severe sepsis. Pressure PERSISTS despite fluid means septic shock.",
 [H, SSC])

# ---------------------------------------------------------------- idx 834
add("book:834", "case", "medium",
 "مایع جواب نداد و **نوراپی‌نفرین لازم شد** ← این **شوک سپتیک** است.",
 "Fluid did not work and NOREPINEPHRINE was needed, so this IS septic shock.",
 LADDER_FA + [
  "این سؤال جفتِ آینه‌ای سؤال قبلی است — تقریباً همان بیمار، ولی پایان متفاوت.",
  "SIRS را بشمارید: تب ✓، نبض ۱۰۴ ✓، تنفس ۲۸ ✓ — سه معیار.",
  "منبع عفونت: علائم ادراری و **کشت ادرار مثبت** ← سپسیس مستند.",
  "اختلال ارگان: کراتینین ۲ یعنی نارسایی کلیه ← اختلال عملکرد ارگان ✓.",
  "فشار ۸۵/۵۵ هم هیپوتانسیون است.",
  "تا اینجا عیناً مثل سؤال قبلی، در پله‌ی سپسیس شدید ایستاده‌ایم.",
  "⚠️ حالا جمله‌ی سرنوشت‌ساز، و این بار برعکس است.",
  "«یک لیتر نرمال سالین انفوزه شد ولی **جوابی حاصل نشد**.»",
  "«ولی بعد از انفوزیون **نوراپی‌نفرین** فشار افزایش یافت.»",
  "یعنی هیپوتانسیون به مایع پاسخ **نداد** و به **وازوپرسور** نیاز پیدا کرد.",
  "این دقیقاً تعریف **شوک سپتیک** است، پس یک پله بالاتر می‌رویم.",
  "و چون با وازوپرسور **پاسخ داد**، شوک مقاوم (refractory) هم نیست.",
  "این دو سؤال را کنار هم بخوانید: تفاوتشان فقط در یک جمله است، و همان جمله جواب را عوض می‌کند.",
 ] + SEPSIS3_FA,
 LADDER_EN + [
  "This is the mirror image of the previous question: almost the same patient, different ending.",
  "Count SIRS: fever, pulse 104, respiratory rate 28 — three criteria.",
  "Source: urinary symptoms and a POSITIVE URINE CULTURE, so documented sepsis.",
  "Organ dysfunction: a creatinine of 2 means renal impairment, so organ dysfunction.",
  "A pressure of 85/55 is hypotension.",
  "So far this is exactly the previous question: we are standing at severe sepsis.",
  "WARNING: now the decisive sentence, and this time it goes the other way.",
  "'One litre of normal saline was infused but there was NO response.'",
  "'But after infusing NOREPINEPHRINE the pressure rose.'",
  "So the hypotension did NOT respond to fluid and required a VASOPRESSOR.",
  "That is precisely the definition of SEPTIC SHOCK, so we climb one rung higher.",
  "And because it DID respond to the vasopressor, it is not refractory shock.",
  "Read these two questions side by side: they differ by one sentence, and that sentence changes the answer.",
 ] + SEPSIS3_EN,
 "این سؤال را باید **کنار سؤال قبلی** خواند؛ با هم، مرز سپسیس شدید و شوک سپتیک را می‌سازند. بیمار تقریباً یکسان است: مرد مسن، منبع ادراری، SIRS مثبت، اختلال ارگان (اینجا کراتینین ۲)، و هیپوتانسیون ۸۵/۵۵.\n\nتفاوت فقط در یک جمله است: «یک لیتر نرمال سالین انفوزه می‌شود ولی **جوابی حاصل نمی‌شود**، ولی بعد از انفوزیون **نوراپی‌نفرین** فشار خون افزایش می‌یابد.» هیپوتانسیون با وجود مایع کافی **باقی ماند** و به **وازوپرسور** نیاز پیدا کرد — و این دقیقاً تعریف **شوک سپتیک** است.\n\nدو نکته‌ی تکمیلی: چون با وازوپرسور پاسخ داد، شوک **مقاوم** نیست (آن یعنی با وجود هم مایع و هم وازوپرسور همچنان هیپوتانسیو بماند). و نوراپی‌نفرین درست همان وازوپرسور **خط اول** در شوک سپتیک است، نه دوپامین.",
 "Read this ALONGSIDE the previous question; together they define the boundary between severe sepsis and septic shock. The patient is almost identical: an older man, a urinary source, SIRS positive, organ dysfunction (here a creatinine of 2), and hypotension at 85/55.\n\nThe only difference is one sentence: 'a litre of normal saline is infused but there is NO response; after infusing NOREPINEPHRINE the pressure rises.' The hypotension PERSISTED despite adequate fluid and required a VASOPRESSOR — precisely the definition of SEPTIC SHOCK.\n\nTwo further points: because it responded to the vasopressor it is not REFRACTORY shock (which means staying hypotensive despite both fluid and vasopressor). And norepinephrine is exactly the FIRST-LINE vasopressor in septic shock, not dopamine.",
 ["SIRS تنها ناکافی است؛ این بیمار منبع عفونت مستند و اختلال ارگان هم دارد.",
  "سپسیس تنها کافی نیست؛ اختلال ارگان و هیپوتانسیون مقاوم به مایع هم وجود دارد.",
  "سپسیس شدید نیست، چون فشار با مایع اصلاح نشد و به وازوپرسور نیاز شد.",
  "پاسخ صحیح — هیپوتانسیون با وجود مایع کافی باقی ماند و وازوپرسور لازم شد."],
 ["SIRS alone is insufficient; this patient has a documented source and organ dysfunction.",
  "Sepsis alone is not enough; there is organ dysfunction and fluid-refractory hypotension.",
  "Not severe sepsis, because the pressure did not correct with fluid and needed a vasopressor.",
  "Correct — hypotension persisted despite adequate fluid and required a vasopressor."],
 "مایع جواب نداد + وازوپرسور لازم شد = **شوک سپتیک**. نوراپی‌نفرین وازوپرسور خط اول است.",
 "No response to fluid plus a vasopressor requirement equals SEPTIC SHOCK. Norepinephrine is first line.",
 [H, SSC])

# ---------------------------------------------------------------- idx 828
add("book:828", "case", "hard",
 "با وجود **۳ لیتر مایع و دوپامین** همچنان هیپوتانسیو است ← **شوک سپتیک مقاوم**.",
 "Still hypotensive despite THREE litres of fluid AND dopamine, so REFRACTORY septic shock.",
 LADDER_FA + [
  "این سؤال بالاترین پله‌ی نردبان را می‌سنجد، پس باید تا آخر بالا برویم.",
  "SIRS: تب ۳۹ ✓، تنفس ۴۰ ✓، گلبول سفید ۱۶۰۰۰ ✓ — سه معیار روشن.",
  "منبع عفونت: دو روز پس از کوله‌سیستکتومی با تب، لرز و درد شکم ← منبع داخل‌شکمی ← سپسیس.",
  "اختلال ارگان: **لتارژیک** (اختلال هوشیاری) و **الیگوریک** (نارسایی کلیه) ← هر دو ✓.",
  "فشار ۸۰/۵۰ هم هیپوتانسیون است. تا اینجا دست‌کم سپسیس شدید.",
  "⚠️ حالا دو جمله‌ی کلیدی پشت سر هم می‌آیند و ما را دو پله بالا می‌برند.",
  "جمله‌ی اول: «بعد از تجویز **۳ لیتر نرمال سالین**» ← مایع کافی داده شده است.",
  "جمله‌ی دوم: «و شروع **دوپامین**، بیمار **همچنان هیپوتانسیو** است.»",
  "پس هم مایع کافی گرفته و هم وازوپرسور، و باز هم فشارش پایین است.",
  "این تعریف **شوک سپتیک مقاوم (refractory)** است — بالاترین پله.",
  "تفاوتش با شوک سپتیک ساده این است که آنجا وازوپرسور **جواب می‌دهد**.",
  "نکته‌ی درمانی: در شوک سپتیک، وازوپرسور خط اول **نوراپی‌نفرین** است نه دوپامین.",
  "دوپامین آریتمی‌زایی بیشتری دارد و در راهنماهای امروزی کنار گذاشته شده است.",
  "در شوک مقاوم باید به فکر هیدروکورتیزون، کنترل منبع عفونت و ارزیابی مجدد تشخیص بود.",
  "و «کنترل منبع» اینجا کلیدی است: بیمار پس از جراحی است و ممکن است آبسه یا نشت داشته باشد.",
 ] + SEPSIS3_FA,
 LADDER_EN + [
  "This question tests the top rung of the ladder, so we must climb all the way.",
  "SIRS: fever 39, respiratory rate 40, white cells 16000 — three clear criteria.",
  "Source: two days after cholecystectomy with fever, rigors and abdominal pain — an intra-abdominal source, so sepsis.",
  "Organ dysfunction: LETHARGIC (altered consciousness) and OLIGURIC (renal impairment) — both present.",
  "A pressure of 80/50 is hypotension. So far, at least severe sepsis.",
  "WARNING: now two key sentences arrive together and take us up two rungs.",
  "First: 'after giving THREE LITRES of normal saline' — adequate fluid has been given.",
  "Second: 'and starting DOPAMINE, the patient REMAINS HYPOTENSIVE'.",
  "So he has had both adequate fluid and a vasopressor, and his pressure is still low.",
  "That is the definition of REFRACTORY septic shock — the highest rung.",
  "It differs from plain septic shock in that there the vasopressor WORKS.",
  "A treatment point: in septic shock the first-line vasopressor is NOREPINEPHRINE, not dopamine.",
  "Dopamine is more arrhythmogenic and has been set aside in current guidelines.",
  "In refractory shock, think of hydrocortisone, source control, and re-examining the diagnosis.",
  "Source control matters here: he is post-operative and may have an abscess or a leak.",
 ] + SEPSIS3_EN,
 "این سؤال بالاترین پله‌ی نردبان را می‌سنجد و برای رسیدن به آن باید هر پله را بشمارید.\n\nSIRS: تب ۳۹ ✓، تنفس ۴۰ ✓، WBC ۱۶۰۰۰ ✓. منبع: دو روز پس از کوله‌سیستکتومی با تب و درد شکم ← منبع داخل‌شکمی ← **سپسیس**. اختلال ارگان: **لتارژیک** (هوشیاری) و **الیگوریک** (کلیه) ← **سپسیس شدید**.\n\nحالا دو جمله‌ی پایانی: «بعد از تجویز **۳ لیتر** نرمال سالین و شروع **دوپامین**، بیمار **همچنان هیپوتانسیو** است.» یعنی هم مایع کافی و هم وازوپرسور داده شده و باز هم فشار پایین است — این **شوک سپتیک مقاوم** است، بالاترین پله. اگر وازوپرسور جواب داده بود، فقط «شوک سپتیک» می‌شد.\n\nدو نکته‌ی بالینی: اولاً وازوپرسور **خط اول** در شوک سپتیک **نوراپی‌نفرین** است نه دوپامین (دوپامین آریتمی‌زاتر است). ثانیاً در بیمار پس از جراحی که به درمان جواب نمی‌دهد، باید جدی به **کنترل منبع** فکر کرد: آبسه یا نشت صفراوی.",
 "This question tests the top rung, and to reach it you must count every step.\n\nSIRS: fever 39, respiratory rate 40, WBC 16000. Source: two days after cholecystectomy with fever and abdominal pain — an intra-abdominal source, so SEPSIS. Organ dysfunction: LETHARGIC (consciousness) and OLIGURIC (kidney), so SEVERE SEPSIS.\n\nNow the closing sentences: 'after giving THREE LITRES of normal saline and starting DOPAMINE, the patient REMAINS HYPOTENSIVE.' Both adequate fluid and a vasopressor have been given and the pressure is still low — this is REFRACTORY septic shock, the highest rung. Had the vasopressor worked, it would be plain 'septic shock'.\n\nTwo clinical points: first, the FIRST-LINE vasopressor in septic shock is NOREPINEPHRINE, not dopamine (which is more arrhythmogenic). Second, in a post-operative patient not responding to treatment, think hard about SOURCE CONTROL: an abscess or a bile leak.",
 ["SIRS تنها ناکافی است؛ منبع عفونت، اختلال ارگان و شوک مقاوم همگی وجود دارند.",
  "سپسیس شدید نیست، چون فشار با مایع اصلاح نشد و حتی به وازوپرسور هم پاسخ نداد.",
  "«سندرم سپسیس» اصطلاح دقیق این تابلو نیست؛ بیمار در بالاترین پله قرار دارد.",
  "پاسخ صحیح — با وجود ۳ لیتر مایع و دوپامین همچنان هیپوتانسیو است."],
 ["SIRS alone is insufficient; there is a source, organ dysfunction and refractory shock.",
  "Not severe sepsis, because the pressure neither corrected with fluid nor responded to a vasopressor.",
  "'Sepsis syndrome' is not the precise term here; the patient is at the highest rung.",
  "Correct — still hypotensive despite three litres of fluid and dopamine."],
 "مایع **و** وازوپرسور، و باز هیپوتانسیو ← **شوک مقاوم**. به کنترل منبع فکر کن.",
 "Fluid AND a vasopressor and still hypotensive means REFRACTORY shock. Think about source control.",
 [H, SSC])

# ---------------------------------------------------------------- idx 835
add("book:835", "case", "medium",
 "اختلال هوشیاری = اختلال عملکرد ارگان ← **سپسیس شدید**؛ هنوز مایعی داده نشده که شوک را ثابت کند.",
 "Altered consciousness is organ dysfunction, so SEVERE SEPSIS; no fluid has yet been given to prove shock.",
 LADDER_FA + [
  "SIRS را بشمارید: دمای ۳۸٫۵ ✓، نبض ۱۰۰ (مرزی)، تنفس ۲۸ ✓، WBC ۱۳۰۰۰ ✓.",
  "منبع عفونت: پیوری و باکتریوری در آنالیز ادرار ← منبع ادراری ← **سپسیس**.",
  "اختلال ارگان: «به مکان و زمان آگاهی ندارد» ← اختلال وضعیت ذهنی ← ✓.",
  "خواب‌آلودگی و دزاوریانتاسیون در سپسیس یک علامت هشدار جدی‌اند، نه یافته‌ی جانبی.",
  "به‌ویژه در سالمند و دیابتی، انسفالوپاتی سپتیک ممکن است اولین و بارزترین نشانه باشد.",
  "فشار ۸۰/۴۰ هم هیپوتانسیون است ← هیپوپرفیوژن ✓.",
  "پس بیمار دست‌کم در پله‌ی **سپسیس شدید** است.",
  "⚠️ حالا سؤال کلیدی: آیا شوک سپتیک است؟ برای پاسخ باید بدانیم مایع داده شده یا نه.",
  "در صورت سؤال **هیچ اشاره‌ای به تجویز مایع و پاسخ به آن نیست**.",
  "بدون آزمون مایع، نمی‌توان گفت هیپوتانسیون «مقاوم به مایع» است.",
  "و بدون مقاومت به مایع، برچسب شوک سپتیک قابل اثبات نیست.",
  "پس دقیق‌ترین پاسخ با اطلاعات موجود، **سپسیس شدید** است.",
  "این یک درس روش‌شناختی است: برچسبی نزنید که شواهدش در صورت سؤال نیامده.",
 ] + SEPSIS3_FA,
 LADDER_EN + [
  "Count SIRS: temperature 38.5, pulse 100 (borderline), respiratory rate 28, WBC 13000.",
  "Source: pyuria and bacteriuria on urinalysis give a urinary source, so SEPSIS.",
  "Organ dysfunction: 'not oriented to place and time' is altered mental state.",
  "Drowsiness and disorientation in sepsis are serious warning signs, not incidental findings.",
  "In the elderly and in diabetics especially, septic encephalopathy may be the first and most obvious sign.",
  "A pressure of 80/40 is hypotension, so hypoperfusion too.",
  "So the patient is at least at SEVERE SEPSIS.",
  "WARNING, the key question: is this septic shock? To answer we must know whether fluid was given.",
  "The stem makes NO mention of fluid administration or any response to it.",
  "Without a fluid challenge we cannot say the hypotension is fluid-refractory.",
  "And without fluid refractoriness, the label of septic shock cannot be established.",
  "So the most precise answer on the available information is SEVERE SEPSIS.",
  "This is a methodological lesson: do not apply a label whose evidence is absent from the stem.",
 ] + SEPSIS3_EN,
 "این بیمار همه‌ی اجزای سپسیس شدید را دارد: SIRS (دما ۳۸٫۵، تنفس ۲۸، WBC ۱۳۰۰۰)، منبع عفونت (پیوری و باکتریوری)، و **اختلال عملکرد ارگان** به شکل کاهش هوشیاری و عدم آگاهی به مکان و زمان. فشار ۸۰/۴۰ هم هیپوتانسیون است.\n\nپرسش اصلی این است که چرا **شوک سپتیک** نیست، با اینکه فشار پایین است. پاسخ ظریف و مهم است: شوک سپتیک به تعریف، هیپوتانسیونی است که **با وجود احیای کافی با مایع باقی می‌ماند**. در این صورت سؤال هیچ اشاره‌ای به تجویز مایع و پاسخ بیمار به آن نشده است. بدون آزمون مایع، نمی‌توان ثابت کرد که هیپوتانسیون مقاوم است، و بدون آن نمی‌توان برچسب شوک زد. پس دقیق‌ترین پاسخ با اطلاعات موجود **سپسیس شدید** است.\n\nنکته‌ی بالینی مهم: در سالمند و دیابتی، **انسفالوپاتی سپتیک** (خواب‌آلودگی، دزاوریانتاسیون) ممکن است اولین و بارزترین نشانه‌ی سپسیس باشد، حتی پیش از افت فشار.",
 "This patient has every component of severe sepsis: SIRS (temperature 38.5, respiratory rate 28, WBC 13000), a source (pyuria and bacteriuria), and ORGAN DYSFUNCTION in the form of reduced consciousness and disorientation to place and time. The pressure of 80/40 is hypotension.\n\nThe real question is why this is not SEPTIC SHOCK given the low pressure. The answer is subtle and important: septic shock is by definition hypotension that PERSISTS DESPITE adequate fluid resuscitation. This stem makes no mention of fluid or of any response to it. Without a fluid challenge we cannot show the hypotension is refractory, and without that we cannot apply the shock label. So the most precise answer on the available information is SEVERE SEPSIS.\n\nA clinical point: in elderly and diabetic patients, SEPTIC ENCEPHALOPATHY (drowsiness, disorientation) may be the first and most obvious sign of sepsis, even before the pressure falls.",
 ["پاسخ صحیح — سپسیس با اختلال عملکرد ارگان (کاهش هوشیاری) و هیپوتانسیون.",
  "سپسیس تنها ناکافی است؛ این بیمار اختلال هوشیاری و هیپوتانسیون هم دارد.",
  "شوک سپتیک اثبات نشده، چون در صورت سؤال هیچ آزمون مایعی گزارش نشده است.",
  "شوک مقاوم به‌مراتب اثبات‌نشده‌تر است؛ نه مایعی داده شده و نه وازوپرسوری."],
 ["Correct — sepsis with organ dysfunction (reduced consciousness) and hypotension.",
  "Sepsis alone is insufficient; this patient also has altered consciousness and hypotension.",
  "Septic shock is not established, because the stem reports no fluid challenge.",
  "Refractory shock is even less established; neither fluid nor a vasopressor has been given."],
 "بدون آزمون مایع نمی‌توان «شوک» گفت. اختلال هوشیاری = اختلال ارگان = سپسیس شدید.",
 "Without a fluid challenge you cannot say 'shock'. Altered consciousness is organ dysfunction, so severe sepsis.",
 [H, SSC])

# ---------------------------------------------------------------- idx 831
add("book:831", "case", "medium",
 "اولین اقدام در سپسیس همیشه **مایع** است — نه خون، نه وازوپرسور، نه استروئید.",
 "The first action in sepsis is always FLUID — not blood, not a vasopressor, not a steroid.",
 FLUID_FA + [
  "این بیمار یوروسپسیس دارد و فشارش ۷۰/۵۰ است — یعنی هیپوتانسیون واضح.",
  "سؤال صریح می‌پرسد «**اولین** اقدام درمانی»، پس ترتیب مهم است نه فقط درستی.",
  "کشت خون و آنتی‌بیوتیک قبلاً در صورت سؤال ذکر شده‌اند، پس بحث بر سر همودینامیک است.",
  "تله‌ی سؤال، هموگلوبین ۹ است که ذهن را به سمت تزریق خون می‌برد.",
  "ولی هموگلوبین ۹ در بیمار سپتیک **آستانه‌ی تزریق نیست**.",
  "آستانه‌ی محدودکننده‌ی تزریق خون در بیمار بدحال معمولاً هموگلوبین **زیر ۷** است.",
  "مطالعه‌ی TRISS نشان داد آستانه‌ی ۷ در شوک سپتیک به‌اندازه‌ی آستانه‌ی ۹ ایمن است.",
  "پس تزریق خون اینجا نه لازم است و نه بی‌خطر؛ فقط خطر و هزینه اضافه می‌کند.",
  "هیدروکورتیزون هم برای شوک **مقاوم** به مایع و وازوپرسور نگه داشته می‌شود، نه اقدام اول.",
  "دوپامین هم اصلاً خط اول نیست و پیش از مایع دادن، اشتباه است.",
 ],
 FLUID_EN + [
  "This patient has urosepsis with a pressure of 70/50 — clear hypotension.",
  "The stem asks for the FIRST treatment, so the order matters, not just correctness.",
  "Blood cultures and antibiotics are already mentioned in the stem, so the issue is haemodynamic.",
  "The trap is the haemoglobin of 9, which pulls the mind towards transfusion.",
  "But a haemoglobin of 9 is NOT a transfusion threshold in a septic patient.",
  "The restrictive transfusion threshold in critical illness is generally a haemoglobin below 7.",
  "The TRISS trial showed a threshold of 7 is as safe as 9 in septic shock.",
  "So transfusion here is neither necessary nor harmless; it adds only risk and cost.",
  "Hydrocortisone is reserved for shock REFRACTORY to fluid and vasopressor, not a first action.",
  "Dopamine is not first line at all, and giving it before fluid is simply wrong.",
 ],
 "سؤال صریح می‌پرسد «**اولین** اقدام»، پس این سؤال درباره‌ی **ترتیب** است نه فقط درستی. در سپسیس، اولین اقدام همودینامیک همیشه **احیای با مایع کریستالوئید** است، و دلیلش پاتوفیزیولوژی است: سپسیس یک شوک **توزیعی** است — واسطه‌های التهابی عروق را گشاد و مویرگ‌ها را نشت‌دار می‌کنند، پس بستر عروقی نسبت به حجم موجود بزرگ می‌شود. اول باید این ظرف را پر کرد، بعد سراغ تنگ کردنش رفت.\n\nتله‌ی سؤال **هموگلوبین ۹** است که ذهن را به تزریق خون می‌کشاند. اما در بیمار بدحال، آستانه‌ی محدودکننده‌ی تزریق معمولاً هموگلوبین **زیر ۷** است؛ مطالعه‌ی TRISS نشان داد در شوک سپتیک آستانه‌ی ۷ به‌اندازه‌ی ۹ ایمن است. پس تزریق خون فقط خطر اضافه می‌کند.\n\nهیدروکورتیزون برای شوک **مقاوم** نگه داشته می‌شود و دوپامین اصلاً خط اول نیست (نوراپی‌نفرین است) و به‌هرحال بعد از مایع می‌آید نه قبل از آن.",
 "The stem asks for the FIRST action, so this question is about ORDER, not merely correctness. In sepsis the first haemodynamic action is always CRYSTALLOID resuscitation, and the reason is pathophysiology: sepsis is a DISTRIBUTIVE shock — inflammatory mediators dilate vessels and make capillaries leak, so the vascular bed becomes too large for the circulating volume. Fill the container first; only then consider narrowing it.\n\nThe trap is the HAEMOGLOBIN OF 9, which pulls towards transfusion. But in critical illness the restrictive threshold is generally below 7; the TRISS trial showed that a threshold of 7 is as safe as 9 in septic shock. Transfusion here adds only risk.\n\nHydrocortisone is reserved for REFRACTORY shock, and dopamine is not first line at all (norepinephrine is) and in any case comes after fluid, not before it.",
 ["هیدروکورتیزون برای شوک مقاوم به مایع و وازوپرسور نگه داشته می‌شود، نه اقدام اول.",
  "هموگلوبین ۹ آستانه‌ی تزریق نیست؛ آستانه‌ی محدودکننده در بیمار بدحال زیر ۷ است.",
  "دوپامین وازوپرسور خط اول نیست و پیش از احیای با مایع جایی ندارد.",
  "پاسخ صحیح — احیای با کریستالوئید، اولین اقدام همودینامیک در سپسیس است."],
 ["Hydrocortisone is reserved for shock refractory to fluid and vasopressor, not a first action.",
  "A haemoglobin of 9 is not a transfusion threshold; the restrictive threshold in critical illness is below 7.",
  "Dopamine is not the first-line vasopressor and has no place before fluid resuscitation.",
  "Correct — crystalloid resuscitation is the first haemodynamic action in sepsis."],
 "سپسیس = شوک توزیعی. **اول مایع**، بعد وازوپرسور (نوراپی‌نفرین). Hb ۹ آستانه‌ی تزریق نیست.",
 "Sepsis is distributive shock. FLUID FIRST, then a vasopressor (norepinephrine). Hb 9 is not a transfusion threshold.",
 [H, SSC])

# ---------------------------------------------------------------- idx 832
add("book:832", "case", "easy",
 "فشار سیستولی ۷۰ در سپسیس ← **اولین اقدام: سرم نرمال سالین**.",
 "A systolic of 70 in sepsis means the FIRST action is NORMAL SALINE.",
 FLUID_FA + [
  "این نسخه‌ی ساده‌شده‌ی همان مفهوم است، بدون تله‌ی هموگلوبین.",
  "بیمار تب ۳۹، نبض ۱۲۰ و فشار سیستولی ۷۰ دارد با منبع ادراری روشن.",
  "پس سپسیس با هیپوتانسیون است و سؤال «اولین اقدام» را می‌خواهد.",
  "هر سه گزینه‌ی دیگر وازوپرسورند: نوراپی‌نفرین، اپی‌نفرین و دوپامین.",
  "هیچ‌کدام پیش از احیای با مایع، اقدام اول نیستند.",
  "نکته‌ی مقایسه‌ای: اگر همین بیمار **پس از مایع کافی** هنوز هیپوتانسیو بود، نوراپی‌نفرین درست می‌شد.",
  "یعنی گزینه‌ی «نوراپی‌نفرین» پاسخ **مرحله‌ی بعد** است، نه پاسخ غلط مطلق.",
  "این تفکیک مهم است: در سؤالات ترتیبی، گزینه‌ها اغلب همگی درست‌اند ولی در زمان‌های متفاوت.",
  "اپی‌نفرین در سپسیس داروی خط دوم یا سوم است و معمولاً کنار نوراپی‌نفرین می‌آید.",
 ],
 FLUID_EN + [
  "This is the simplified version of the same concept, without the haemoglobin trap.",
  "The patient has a fever of 39, a pulse of 120 and a systolic of 70, with a clear urinary source.",
  "So this is sepsis with hypotension, and the question asks for the first action.",
  "All three other options are vasopressors: norepinephrine, epinephrine and dopamine.",
  "None of them is the first action before fluid resuscitation.",
  "A comparative point: if this same patient were still hypotensive AFTER adequate fluid, norepinephrine would be right.",
  "So 'norepinephrine' is the answer to the NEXT step, not an absolutely wrong option.",
  "That distinction matters: in sequencing questions the options are often all correct, but at different times.",
  "Epinephrine is second or third line in sepsis and usually added alongside norepinephrine.",
 ],
 "این سؤال همان مفهوم سؤال قبلی را بدون تله می‌پرسد و برای همین ارزش دارد: پایه را محکم می‌کند. بیمار تب ۳۹، نبض ۱۲۰ و فشار سیستولی ۷۰ با منبع ادراری دارد — سپسیس با هیپوتانسیون. پرسش «**اولین** اقدام» است.\n\nهر سه گزینه‌ی دیگر وازوپرسورند و نکته‌ی آموزشی همین است: آن‌ها **غلط مطلق نیستند، بلکه زودهنگام‌اند**. اگر همین بیمار پس از احیای کافی با مایع همچنان هیپوتانسیو می‌ماند، نوراپی‌نفرین دقیقاً پاسخ درست می‌شد. در سؤالات ترتیبی، اغلب همه‌ی گزینه‌ها در جایی از مسیر درمان درست‌اند و آنچه سنجیده می‌شود **ترتیب** است.\n\nدلیل تقدم مایع باز هم پاتوفیزیولوژی است: سپسیس شوک توزیعی با نشت مویرگی است، پس اول ظرف را پر می‌کنیم و بعد در صورت نیاز تنگش می‌کنیم. تنگ کردن عروق در بیمار خالی، فقط پرفیوژن بافتی را بدتر می‌کند.",
 "This asks the same concept as the previous question without the trap, and that is its value: it consolidates the base. The patient has a fever of 39, a pulse of 120 and a systolic of 70 with a urinary source — sepsis with hypotension. The question is the FIRST action.\n\nAll three other options are vasopressors, and that is the teaching point: they are not absolutely wrong, they are PREMATURE. If this same patient remained hypotensive after adequate fluid, norepinephrine would be exactly right. In sequencing questions the options are often all correct somewhere along the pathway, and what is being tested is the ORDER.\n\nThe reason fluid comes first is again pathophysiology: sepsis is distributive shock with capillary leak, so fill the container first and narrow it afterwards if needed. Constricting the vessels of an empty patient only worsens tissue perfusion.",
 ["پاسخ صحیح — احیای با کریستالوئید همیشه اولین اقدام همودینامیک در سپسیس است.",
  "نوراپی‌نفرین پاسخ مرحله‌ی بعد است: اگر پس از مایع کافی هنوز هیپوتانسیو بماند.",
  "اپی‌نفرین در سپسیس خط دوم یا سوم است و اقدام اول نیست.",
  "دوپامین به دلیل خطر آریتمی کنار گذاشته شده و به‌هرحال پس از مایع می‌آید."],
 ["Correct — crystalloid resuscitation is always the first haemodynamic action in sepsis.",
  "Norepinephrine is the answer to the next step: if hypotension persists after adequate fluid.",
  "Epinephrine is second or third line in sepsis and is not the first action.",
  "Dopamine has been set aside for arrhythmia risk and in any case follows fluid."],
 "در سؤال «اولین اقدام»، گزینه‌ها اغلب همه درست‌اند ولی در زمان‌های مختلف. مایع اول.",
 "In a 'first action' question the options are often all right but at different times. Fluid comes first.",
 [H, SSC])

# ---------------------------------------------------------------- idx 830
add("book:830", "recall", "medium",
 "هدف همودینامیک در سپسیس: **MAP بالای ۶۵ میلی‌متر جیوه**.",
 "The haemodynamic goal in sepsis is a MEAN ARTERIAL PRESSURE above 65 mmHg.",
 FLUID_FA + [
  "این سؤال از درمان به **اهداف** درمان می‌رود، و اهداف عددی‌اند و قابل حفظ.",
  "چرا MAP و نه فشار سیستولی؟ چون MAP فشار محرکه‌ی پرفیوژن اندام‌هاست.",
  "زیر ۶۵، اتورگولاسیون کلیه و مغز از کار می‌افتد و ایسکمی شروع می‌شود.",
  "هدف دوم: **برون‌ده ادراری بیش از ۰٫۵ میلی‌لیتر بر کیلوگرم در ساعت**.",
  "⚠️ دقت کنید گزینه‌ی «بیشتر از ۰٫۲» عدد را کم گرفته است؛ عدد درست ۰٫۵ است.",
  "این یک تله‌ی عددی کلاسیک است: هدف درست، ولی مقدار غلط.",
  "هدف سوم در پروتکل کلاسیک EGDT: فشار ورید مرکزی (CVP) بین **۸ تا ۱۲** سانتی‌متر آب.",
  "پس گزینه‌ی «رسیدن CVP به ۱۵» هم بالاتر از محدوده‌ی توصیه‌شده است.",
  "و «کاهش ضربان قلب به زیر ۱۰۰» اصلاً هدف درمانی سپسیس **نیست**.",
  "تاکی‌کاردی در سپسیس یک **پاسخ جبرانی** است، نه چیزی که مستقیم درمانش کنیم.",
  "اگر پرفیوژن اصلاح شود، ضربان قلب خودبه‌خود پایین می‌آید؛ پایین آوردن اجباری‌اش مضر است.",
  "نکته‌ی به‌روز: راهنماهای جدید از هدف‌های ثابت CVP فاصله گرفته‌اند و بر لاکتات تکیه می‌کنند.",
 ],
 FLUID_EN + [
  "This question moves from treatment to its TARGETS, and targets are numerical and learnable.",
  "Why MAP rather than systolic? Because MAP is the driving pressure for organ perfusion.",
  "Below 65, renal and cerebral autoregulation fail and ischaemia begins.",
  "The second goal is a URINE OUTPUT above 0.5 mL/kg/hour.",
  "WARNING: the option offering 'more than 0.2' understates it; the correct figure is 0.5.",
  "That is a classic numerical trap: the right target with the wrong value.",
  "The third goal in the classical EGDT protocol is a central venous pressure of 8 to 12 cmH2O.",
  "So the option 'reaching a CVP of 15' is above the recommended range.",
  "And 'reducing the heart rate below 100' is not a treatment goal in sepsis at all.",
  "Tachycardia in sepsis is a COMPENSATORY response, not something to treat directly.",
  "If perfusion is restored the heart rate falls by itself; forcing it down is harmful.",
  "An update: modern guidelines have moved away from fixed CVP targets towards lactate.",
 ],
 "این سؤال از «چه بدهیم» به «به کجا برسیم» می‌رود. هدف اصلی و پذیرفته‌شده در احیای سپسیس، **فشار متوسط شریانی (MAP) بالای ۶۵ میلی‌متر جیوه** است. چرا MAP و نه سیستولیک؟ چون MAP فشار محرکه‌ی پرفیوژن اندام است؛ زیر ۶۵، اتورگولاسیون کلیه و مغز از کار می‌افتد.\n\nسه گزینه‌ی دیگر هرکدام یک نوع خطای متفاوت را نشان می‌دهند:\n\n- **برون‌ده ادراری**: هدف درستی است، ولی عدد غلط آمده — مقدار صحیح **۰٫۵** میلی‌لیتر بر کیلوگرم در ساعت است نه ۰٫۲. تله‌ی عددی کلاسیک.\n- **CVP ۱۵**: در پروتکل کلاسیک EGDT محدوده‌ی هدف **۸ تا ۱۲** بود، پس ۱۵ بالاتر از توصیه است. (راهنماهای امروزی اصلاً از هدف ثابت CVP فاصله گرفته‌اند.)\n- **کاهش ضربان قلب زیر ۱۰۰**: اصلاً هدف نیست. تاکی‌کاردی در سپسیس یک **پاسخ جبرانی** است؛ با اصلاح پرفیوژن خودبه‌خود فروکش می‌کند و پایین آوردن اجباری‌اش مضر است.",
 "This question moves from 'what to give' to 'what to aim for'. The main accepted goal in sepsis resuscitation is a MEAN ARTERIAL PRESSURE above 65 mmHg. Why MAP rather than systolic? Because MAP is the driving pressure for organ perfusion; below 65, renal and cerebral autoregulation fail.\n\nThe other three options each illustrate a different kind of error:\n\n- URINE OUTPUT is a real target, but the number is wrong — it is 0.5 mL/kg/hour, not 0.2. A classic numerical trap.\n- CVP 15: the classical EGDT target range was 8 to 12, so 15 is above recommendation. (Modern guidelines have abandoned fixed CVP targets altogether.)\n- REDUCING THE HEART RATE below 100 is not a goal at all. Tachycardia in sepsis is a COMPENSATORY response; it settles as perfusion is restored, and forcing it down is harmful.",
 ["کاهش ضربان قلب هدف درمانی سپسیس نیست؛ تاکی‌کاردی پاسخ جبرانی است.",
  "هدف برون‌ده ادراری درست است ولی عدد غلط آمده؛ مقدار صحیح ۰٫۵ میلی‌لیتر بر کیلوگرم در ساعت است.",
  "پاسخ صحیح — MAP بالای ۶۵ میلی‌متر جیوه، هدف پذیرفته‌شده‌ی احیای سپسیس است.",
  "در پروتکل کلاسیک، محدوده‌ی هدف CVP هشت تا دوازده بود، نه پانزده."],
 ["Reducing the heart rate is not a treatment goal in sepsis; tachycardia is a compensatory response.",
  "Urine output is a genuine target but the figure is wrong; the correct value is 0.5 mL/kg/hour.",
  "Correct — a MAP above 65 mmHg is the accepted target of sepsis resuscitation.",
  "In the classical protocol the CVP target range was eight to twelve, not fifteen."],
 "هدف: **MAP > ۶۵**، برون‌ده ادراری **> ۰٫۵ cc/kg/hr**. تاکی‌کاردی را مستقیم درمان نکن.",
 "Targets: MAP above 65 and urine output above 0.5 mL/kg/h. Do not treat the tachycardia directly.",
 [H, SSC])

# ---------------------------------------------------------------- idx 844
add("book:844", "case", "easy",
 "قرمزی صورت و گردن حین وانکومایسین = **سندرم مرد قرمز** ← درمان: **تزریق را آهسته کن**.",
 "Flushing of the face and neck during vancomycin is RED MAN SYNDROME: slow the infusion.",
 [
  "این عارضه شایع است و تشخیصش کاملاً بالینی است، پس باید فوراً شناخته شود.",
  "تابلو: قرمزی و گرگرفتگی صورت، گردن و تنه‌ی فوقانی، گاهی خارش و افت فشار خفیف.",
  "زمان‌بندی کلیدی است: در حین انفوزیون یا دقایقی پس از شروع آن رخ می‌دهد.",
  "⚠️ مهم‌ترین نکته: این یک **واکنش آلرژیک واقعی نیست**.",
  "واکنش آلرژیک نوع یک با IgE واسطه می‌شود؛ این یکی با IgE کاری ندارد.",
  "سازوکار، **آزادسازی مستقیم هیستامین از ماست‌سل‌ها** است، بدون دخالت آنتی‌بادی.",
  "به این پدیده واکنش **آنافیلاکتوئید** می‌گویند، نه آنافیلاکسی.",
  "و چون وابسته به آنتی‌بادی نیست، **وابسته به سرعت انفوزیون** است.",
  "هرچه سریع‌تر تزریق شود، هیستامین بیشتری یک‌جا آزاد می‌شود و واکنش شدیدتر است.",
  "نتیجه‌ی عملی: با **آهسته کردن تزریق** مشکل حل می‌شود.",
  "توصیه‌ی استاندارد: هر یک گرم وانکومایسین دست‌کم در **۶۰ دقیقه** انفوزه شود.",
  "پیش‌درمانی با **آنتی‌هیستامین** هم مؤثر است، چون مستقیماً هیستامین را هدف می‌گیرد.",
  "⚠️ نتیجه‌ی مهم: نیازی به **قطع دائمی** وانکومایسین نیست.",
  "این تفاوت حیاتی با آلرژی واقعی است: در آلرژی واقعی دارو باید کنار گذاشته شود.",
  "اگر بیمار را اشتباهاً «آلرژیک به وانکومایسین» برچسب بزنیم، درمان آینده‌اش را محدود کرده‌ایم.",
  "استروئید پیش از تزریق، درمان استاندارد این عارضه نیست و لازم نیست.",
 ],
 [
  "This reaction is common and its diagnosis is purely clinical, so it must be recognised immediately.",
  "The picture: flushing of the face, neck and upper trunk, sometimes with itching and mild hypotension.",
  "Timing is the key: it happens during the infusion or within minutes of starting it.",
  "WARNING, the crucial point: this is NOT a true allergic reaction.",
  "A type I allergic reaction is IgE-mediated; this one has nothing to do with IgE.",
  "The mechanism is DIRECT HISTAMINE RELEASE from mast cells, with no antibody involved.",
  "It is therefore called an ANAPHYLACTOID reaction, not anaphylaxis.",
  "And because it is not antibody-dependent, it IS infusion-rate dependent.",
  "The faster the drug goes in, the more histamine is released at once and the worse the reaction.",
  "The practical consequence: SLOWING THE INFUSION solves the problem.",
  "The standard advice is to infuse each gram of vancomycin over at least 60 minutes.",
  "Pre-treatment with an ANTIHISTAMINE also works, because it targets histamine directly.",
  "WARNING, an important consequence: vancomycin does NOT need to be stopped permanently.",
  "That is the vital difference from true allergy, where the drug must be abandoned.",
  "Mislabelling the patient 'vancomycin allergic' would restrict their future treatment.",
  "A steroid before the dose is not the standard management and is unnecessary.",
 ],
 "قرمزی صورت و گردن و گرگرفتگی **در حین تزریق وانکومایسین** تابلوی کلاسیک **سندرم مرد قرمز** است، و کل ارزش این سؤال در فهمیدن سازوکار آن است.\n\nاین واکنش **آلرژی واقعی نیست**. آلرژی نوع یک با IgE واسطه می‌شود؛ اینجا اما وانکومایسین **مستقیماً باعث آزادسازی هیستامین از ماست‌سل‌ها** می‌شود، بدون دخالت هیچ آنتی‌بادی — به این می‌گویند واکنش **آنافیلاکتوئید**.\n\nاز همین سازوکار، درمان بیرون می‌آید: چون واکنش وابسته به آنتی‌بادی نیست بلکه وابسته به **سرعت انفوزیون** است، با **آهسته کردن تزریق** (هر گرم دست‌کم در ۶۰ دقیقه) برطرف می‌شود. پیش‌درمانی با آنتی‌هیستامین هم منطقی و مؤثر است.\n\n⚠️ نکته‌ی بالینی مهم: **نیازی به قطع دائمی وانکومایسین نیست.** اگر بیمار را اشتباهاً «آلرژیک به وانکومایسین» برچسب بزنیم، گزینه‌های درمانی آینده‌اش را بی‌دلیل محدود کرده‌ایم — و در عفونت با استاف مقاوم، این محدودیت گران تمام می‌شود.",
 "Flushing of the face and neck DURING a vancomycin infusion is the classic picture of RED MAN SYNDROME, and the whole value of this question lies in understanding its mechanism.\n\nThis is NOT a true allergy. Type I allergy is IgE-mediated; here vancomycin causes DIRECT HISTAMINE RELEASE from mast cells with no antibody involved — an ANAPHYLACTOID reaction.\n\nThe treatment falls out of that mechanism: because the reaction depends not on antibody but on INFUSION RATE, SLOWING THE INFUSION (at least 60 minutes per gram) resolves it. Pre-treatment with an antihistamine is also logical and effective.\n\nWARNING, an important clinical point: vancomycin does NOT need to be stopped permanently. Mislabelling the patient as 'vancomycin allergic' needlessly restricts their future options — and in resistant staphylococcal infection that restriction is expensive.",
 ["تعویض به سفازولین لازم نیست؛ این واکنش آلرژی واقعی نیست و با کند کردن تزریق حل می‌شود.",
  "استروئید پیش از تزریق، درمان استاندارد سندرم مرد قرمز نیست؛ آنتی‌هیستامین منطقی‌تر است.",
  "پاسخ صحیح — واکنش وابسته به سرعت انفوزیون است، پس تزریق آهسته آن را برطرف می‌کند.",
  "تعویض به لینزولید بیش‌واکنشی است؛ نیازی به قطع دائمی وانکومایسین نیست."],
 ["Switching to cefazolin is unnecessary; this is not a true allergy and slowing the infusion fixes it.",
  "A steroid before the dose is not the standard management; an antihistamine is more logical.",
  "Correct — the reaction is infusion-rate dependent, so a slower infusion resolves it.",
  "Switching to linezolid is an over-reaction; vancomycin need not be stopped permanently."],
 "سندرم مرد قرمز = آزادسازی مستقیم هیستامین، **نه** آلرژی IgE. تزریق را آهسته کن، دارو را قطع نکن.",
 "Red man syndrome is direct histamine release, NOT IgE allergy. Slow the infusion; do not stop the drug.",
 [H])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book10.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 10 lessons:', len(L))
