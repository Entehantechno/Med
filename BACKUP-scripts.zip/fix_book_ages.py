# -*- coding: utf-8 -*-
"""Repair the patient ages in the already-built book payload, in place.

Why this exists instead of a rebuild
------------------------------------
`extract_rtl.unreverse` carried a bug that flipped a space-separated age a
SECOND time after `num()` had already put it right, so "خانم 25 ساله" was
stored as "خانم 52 ساله". It hit 220 of the 261 ages in the book. The fix is in
extract_rtl.py; the question is how to get it into the payload.

Re-running make_book_payload.py would work but would also throw away the
hand-written bilingual micro-lessons, the corrected answer keys and the
authored English stems, all of which are keyed to the current file order. So we
patch the stems in place instead: same file, same order, same question_no, only
the digits move.

How a payload question is matched to its freshly-extracted twin
---------------------------------------------------------------
On the stem with every digit blanked to '#'. The bug only ever permuted digits
within a run, so the blanked forms are identical while the digits differ, which
is exactly the discriminator we want. Matching on the blanked stem also means a
question whose text was touched by the later `repair_text` pass still lines up.

Safety rules — none of these is optional:

  * a stem is rewritten only when the blanked forms match exactly
  * only digit runs that carry an age (" ساله" / " سال") are touched
  * the corrected value must be a plausible age (1..105)
  * an authored English stem is moved in step, because it was translated from
    the corrupted Persian and inherited the same wrong age
"""
import json, io, os, re, sys, collections

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import repair_text

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, 'out', 'book_raw.json')

AGE = re.compile(r'(?<![\d])(\d{1,3})(\s*(?:ساله|سال\s*ه|ساله\s*ای|سال))')
EN_AGE = re.compile(r'(\d{1,3})\s*[-–]?\s*year\s*[-–]?\s*old', re.I)


def blank(s):
    s = re.sub(r'\d', '#', s or '')
    return re.sub(r'\s+', '', s)


def ages(s):
    return [m.group(1) for m in AGE.finditer(s or '')]


def main():
    if not os.path.exists(RAW):
        sys.exit('run extract_book.py first (out/book_raw.json missing)')
    raw = json.load(io.open(RAW, encoding='utf-8'))

    # The payload text passed through repair_text after extraction, so a freshly
    # extracted stem no longer matches it character for character. Run the same
    # repair over the raw side and the two become directly comparable again.
    tokens = collections.Counter()
    for q in raw:
        for f in [q['stem_fa']] + list(q['options_fa']):
            for w in repair_text.WORD.findall(f or ''):
                tokens[w] += 1
    vocab = repair_text.clean_vocab()
    rep = repair_text.build_fixes(tokens, vocab)
    for k, v in repair_text.build_che_fixes(tokens, vocab).items():
        rep.setdefault(k, v)

    fixed = collections.defaultdict(list)
    for q in raw:
        s = q['stem_fa']
        for variant in (s, repair_text.apply_fixes(s, rep)):
            fixed[blank(variant)].append(ages(variant))

    changed = files_changed = unmatched = ambiguous = en_synced = 0
    problems, examples = [], []

    for i in range(1, 6):
        p = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        if not os.path.exists(p):
            continue
        body = json.load(io.open(p, encoding='utf-8'))
        dirty = False

        for q in body['questions']:
            stem = q['question_fa']
            old = ages(stem)
            if not old:
                continue
            cands = fixed.get(blank(stem))
            if not cands:
                unmatched += 1
                continue
            uniq = {tuple(c) for c in cands}
            if len(uniq) != 1:
                ambiguous += 1
                continue
            new = list(uniq.pop())
            if len(new) != len(old) or new == old:
                continue
            if not all(1 <= int(v) <= 105 for v in new):
                problems.append(f"q{q['question_no']}: implausible age {new}")
                continue

            en = q.get('question_en') or ''
            m = EN_AGE.search(en)
            if m:
                if m.group(1) != new[0]:
                    q['question_en'] = en[:m.start(1)] + new[0] + en[m.end(1):]
                    q.setdefault('en_number_corrections', {})[m.group(1)] = new[0]
                en_synced += 1

            it = iter(new)
            q['question_fa'] = AGE.sub(lambda mm: next(it) + mm.group(2), stem)
            q['age_corrected'] = {'from': old, 'to': new}
            q['age_correction_note_fa'] = (
                'سن بیمار در استخراج اولیه‌ی PDF جابه‌جا خوانده شده بود '
                '(رقم‌های سن دو بار برعکس شده بودند) و اکنون از روی متن اصلی کتاب اصلاح شده است.')
            q['age_correction_note_en'] = (
                "The patient's age was mis-read by the initial PDF extraction "
                "(its digits were reversed twice) and has been corrected against the printed book.")
            changed += 1
            dirty = True
            if len(examples) < 10:
                examples.append((q['question_no'], old, new, stem[:52]))

        if dirty:
            json.dump(body, io.open(p, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)
            files_changed += 1

    print(f'ages corrected : {changed}')
    print(f'files rewritten: {files_changed}')
    print(f'English stems kept in step: {en_synced}')
    if unmatched:
        print(f'no extracted twin (left alone): {unmatched}')
    if ambiguous:
        print(f'twins disagreed (left alone)  : {ambiguous}')
    for no, o, n, s in examples:
        print(f'  q{no}: {o} -> {n}   {s}')
    for pr in problems:
        print('  !', pr)


if __name__ == '__main__':
    main()
