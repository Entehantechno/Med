# -*- coding: utf-8 -*-
"""Attach hand-written English stems and options to the taught book questions.

Guards applied before writing anything:

  * only questions that already have a hand-written bilingual LESSON get an
    English stem, so stem, options and teaching text always agree
  * option count must match the Persian exactly (4)
  * the English must actually be English (Latin letters, no Persian left over)
  * numbers in the Persian stem must survive into the English. A vignette whose
    Persian says "25-year-old" and whose English says "35-year-old" is worse
    than no translation at all, so every digit run in the Persian is checked
    against the English and any mismatch aborts the run.

That last guard has repeatedly earned its keep: it caught six English stems
still carrying pre-repair ages after the age fix, nine where a laboratory value
had been abbreviated away, and two where the PDF itself had lost a digit.
"""
import json, io, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
BANK = HERE
sys.path.insert(0, HERE)
from EN1 import EN
# Batch 8 (tetanus) English lives in its own file so each batch stays a
# reviewable unit; merged here. A key defined twice would mean two different
# translations of one question, so that is an error rather than an overwrite.
from EN2 import EN2
from EN3 import EN3
from EN4 import EN4
from EN5 import EN5
from EN6 import EN6
from EN7 import EN7
from EN8 import EN8
from EN9 import EN9
from EN10 import EN10
from EN11 import EN11
from EN12 import EN12
from EN13 import EN13
from EN14 import EN14
from EN15 import EN15
from EN16 import EN16
from EN17 import EN17
from EN18 import EN18
from EN19 import EN19
from EN20 import EN20
from EN21 import EN21
from EN22 import EN22
for _name, _batch in (('EN2', EN2), ('EN3', EN3), ('EN4', EN4), ('EN5', EN5), ('EN6', EN6), ('EN7', EN7), ('EN8', EN8), ('EN9', EN9), ('EN10', EN10), ('EN11', EN11), ('EN12', EN12), ('EN13', EN13), ('EN14', EN14), ('EN15', EN15), ('EN16', EN16), ('EN17', EN17), ('EN18', EN18), ('EN19', EN19), ('EN20', EN20), ('EN21', EN21), ('EN22', EN22)):
    _dup = set(EN) & set(_batch)
    assert not _dup, f'{_name} redefines entries already merged: {sorted(_dup)}'
    EN.update(_batch)

DIG = str.maketrans('۰۱۲۳۴۵۶۷۸۹', '0123456789')

# Numbers that legitimately differ or vanish between the two languages: unit
# conversions, list markers, and values the English phrases in words.
IGNORE_NUMS = {'0', '1', '2', '3', '4'}


def nums(s):
    """Multi-digit numbers, normalised so formatting differences do not count.

    Thousands separators are stripped (13,500 and 13500 are the same number),
    and leading zeros are dropped. Comparing on the numeric value rather than
    the literal string keeps the check meaningful without flagging cosmetics.
    """
    out = set()
    for m in re.findall(r'[\d,]{2,}', (s or '').translate(DIG)):
        d = m.replace(',', '')
        if not d.isdigit():
            continue
        out.add(str(int(d)))          # 13500 == 13,500 ; 04 == 4
    return out


def main():
    idx = 0
    attached = 0
    problems = []

    for i in range(1, 6):
        p = os.path.join(BANK, f'import-payload.book.part{i:02d}.json')
        if not os.path.exists(p):
            continue
        body = json.load(io.open(p, encoding='utf-8'))
        changed = False
        for q in body['questions']:
            n = idx
            idx += 1
            e = EN.get(n)
            if not e:
                continue

            tag = f"idx {n} ({q.get('year')}-{q.get('month')})"

            # only translate what is already taught
            if q.get('needs_lesson') is not False:
                problems.append(f'{tag}: has English but no lesson')
                continue

            if len(e['options_en']) != len(q['options_fa']):
                problems.append(f'{tag}: option count mismatch')
                continue

            if not re.search(r'[A-Za-z]', e['stem_en']):
                problems.append(f'{tag}: English stem is not English')
                continue

            blob = e['stem_en'] + ' '.join(e['options_en'])
            if re.search(r'[\u0600-\u06FF]', blob):
                problems.append(f'{tag}: Persian characters left in the English')
                continue

            # every multi-digit number in the Persian stem must appear in the English
            fa_n = nums(q['question_fa']) - IGNORE_NUMS
            en_n = nums(e['stem_en'])
            fix = q.get('en_number_corrections') or {}
            # a value corrected during the repair passes counts as present if
            # its corrected form is the one in the English
            fa_n = {v for v in fa_n
                    if not any(str(int(a)) == v and str(int(b)) in en_n
                               for a, b in fix.items())}
            lost = fa_n - en_n
            if lost:
                problems.append(f'{tag}: numbers lost in translation: {sorted(lost)}')
                continue

            q['question_en'] = e['stem_en']
            q['options_en'] = e['options_en']
            q['en_source'] = 'authored_translation'
            q.pop('en_partial', None)
            attached += 1
            changed = True

        if changed:
            json.dump(body, io.open(p, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)

    print(f'English entries available : {len(EN)}')
    print(f'attached                  : {attached}')
    if problems:
        print(f'{len(problems)} problem(s):')
        for pr in problems:
            print('  X', pr)
        sys.exit(1)
    print('all attached cleanly')


if __name__ == '__main__':
    main()
