# -*- coding: utf-8 -*-
"""Micro-lessons, batch 43 — malaria part one: diagnosis, species and severity.

Malaria is the single most heavily examined topic in this chapter. The book
asks it from three angles, and this batch covers the first two; treatment and
prophylaxis follow in batch 44.

THE THREE FACTS THAT DECIDE ALMOST EVERY MALARIA VIGNETTE
-----------------------------------------------------------
1) THE GEOGRAPHY IS THE FIRST CLUE, AND IN IRAN IT IS A SHORT LIST.
   Iran's malarious south-east: SISTAN AND BALUCHESTAN (Iranshahr, Saravan,
   Nikshahr, Zahedan, Chabahar), HORMOZGAN (Bandar Abbas) and southern KERMAN.
   A fever after a trip to any of these, or after arrival from Afghanistan or
   Pakistan, means malaria until proven otherwise.

   Careful: "ABHAR" appears in several stems. Abhar is a town in Zanjan
   province, in the cool north-west, and is NOT malarious. What the book means
   throughout is CHABAHAR (Persian "چابهار"), whose final syllables the PDF
   extraction has clipped to "ابهار". The vignettes are internally consistent
   with the south-east: they pair the place with falciparum, with severe
   disease, and with a pregnant traveller needing prophylaxis.

2) THE BANANA-SHAPED GAMETOCYTE IS FALCIPARUM AND NOTHING ELSE.
   Only P. falciparum makes a crescentic ("banana") gametocyte. Every other
   species makes a round one. Two questions in this batch are decided by that
   one morphological fact alone.

   The other falciparum clues on a film: HIGH parasitaemia, MULTIPLE rings in
   one red cell, DOUBLE-CHROMATIN ("headphone") rings, and red cells of NORMAL
   size — because falciparum invades erythrocytes of all ages.

   The vivax and ovale clues are the mirror image: ENLARGED red cells (they
   prefer reticulocytes), SCHUFFNER'S DOTS, and a low parasitaemia.

3) A NEGATIVE FILM DOES NOT EXCLUDE MALARIA.
   Parasitaemia fluctuates with the schizogony cycle. One negative thick film
   in a strongly suspicious patient means REPEAT IT every 12 to 24 hours for
   three days, not "malaria excluded".

THE SEVERE-FALCIPARUM CRITERIA, AS A COUNTABLE LIST
-----------------------------------------------------
WHO criteria, which the book asks twice in "which is NOT" form:

    cerebral malaria (impaired consciousness), repeated convulsions
    severe anaemia (Hb < 5 g/dL or haematocrit < 15 %)
    renal impairment, pulmonary oedema / ARDS
    HYPOglycaemia (< 40 mg/dL) — NEVER hyperglycaemia
    circulatory collapse, spontaneous bleeding / DIC
    metabolic acidosis (pH < 7.25, bicarbonate < 15 mmol/L)
    haemoglobinuria, jaundice, hyperparasitaemia (> 5 %)

Note what is NOT on the list, because that is what the exam exploits: a mild
leucopenia, a moderate thrombocytopenia, and a modestly raised transaminase are
all COMMON in malaria and none of them is a severity criterion by itself.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022) —
malaria; WHO Guidelines for the Treatment of Malaria / WHO Severe Malaria
criteria.
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — malaria")
WHO = ("World Health Organization — Guidelines for the Treatment of Malaria "
       "and the WHO criteria for severe falciparum malaria")
REFS = [H, WHO]

# ============================================== SHARED: DIAGNOSTIC APPROACH
DX_FA = [
    "⚠️ **در هر تب بازگشت از سفر، اولین سؤال این است: کجا بوده؟**",
    "**مناطق مالاریاخیز ایران: سیستان و بلوچستان، هرمزگان، و جنوب کرمان.**",
    "**ایرانشهر، سراوان، نیک‌شهر، زاهدان، چابهار و بندرعباس نام‌های تکرارشونده‌ی این کتاب‌اند.**",
    "**و مهاجر تازه‌وارد از افغانستان یا پاکستان هم همین ریسک را دارد.**",
    "⚠️ **تابلوی کلاسیک: حملات لرز، تب و تعریق — به همین ترتیب.**",
    "**به‌علاوه‌ی کم‌خونی (همولیز) و اسپلنومگالی (پاک‌سازی گلبول‌های آلوده توسط طحال).**",
    "**و در آزمایش: ترومبوسیتوپنی که بسیار شایع است، و گاهی لکوپنی.**",
    "**تست تشخیصی استاندارد طلایی: گسترش خون محیطی، ضخیم و نازک با هم.**",
    "**گسترش ضخیم برای غربالگری است: حجم خون بیشتری را می‌بیند، پس حساس‌تر است.**",
    "⚠️ **گسترش نازک برای تعیین گونه و شمارش درصد پارازیتمی است.**",
    "**پس این دو رقیب هم نیستند؛ مکمل‌اند و همیشه با هم درخواست می‌شوند.**",
    "**و نکته‌ی حیاتی: یک لام منفی، مالاریا را رد نمی‌کند.**",
    "**چون پارازیتمی با چرخه‌ی شیزوگونی نوسان می‌کند و ممکن است در لحظه‌ی نمونه‌گیری پایین باشد.**",
    "⚠️ **پس در شک بالینی قوی: تکرار لام هر ۱۲ تا ۲۴ ساعت، سه روز پیاپی.**",
]
DX_EN = [
    "WARNING: IN ANY FEVER AFTER TRAVEL, THE FIRST QUESTION IS: WHERE HAS THE PATIENT BEEN?",
    "Iran's malarious areas: Sistan and Baluchestan, Hormozgan, and southern Kerman.",
    "Iranshahr, Saravan, Nikshahr, Zahedan, Chabahar and Bandar Abbas are this book's recurring names.",
    "And a recent migrant from Afghanistan or Pakistan carries the same risk.",
    "WARNING, THE CLASSIC PICTURE: paroxysms of CHILL, then FEVER, then SWEATING — in that order.",
    "Plus anaemia (haemolysis) and splenomegaly (the spleen clearing infected cells).",
    "And in the laboratory: thrombocytopenia, which is very common, and sometimes leucopenia.",
    "The gold standard test: a peripheral blood film, THICK AND THIN TOGETHER.",
    "The THICK film is for screening: it examines a greater volume of blood, so it is more sensitive.",
    "WARNING, THE THIN FILM identifies the species and counts the percentage parasitaemia.",
    "So the two are not rivals; they are complementary and are always requested together.",
    "And the vital point: A SINGLE NEGATIVE FILM DOES NOT EXCLUDE MALARIA.",
    "Because parasitaemia fluctuates with the schizogony cycle and may be low at the moment of sampling.",
    "WARNING, SO WITH STRONG CLINICAL SUSPICION: repeat the film every 12 to 24 hours for three days.",
]

add("book:760", "vignette", "easy",
    "**تب و لرز دوره‌ای + کم‌خونی + اسپلنومگالی + سفر به جنوب = مالاریا.**",
    "Periodic fever and chills plus anaemia plus splenomegaly plus travel to the south = MALARIA.",
    DX_FA + [
        "**در این بیمار هر چهار جزء تابلو حاضرند و هیچ‌کدام جای دیگری نمی‌رود.**",
        "**سفر به بندرعباس، سه هفته پیش: در دوره‌ی نهفتگی مالاریا می‌گنجد.**",
        "⚠️ **ملتحمه‌ی رنگ‌پریده یعنی همولیز، و بزرگی طحال یعنی درگیری سیستم رتیکولواندوتلیال.**",
        "**و «حملات لرز، تب و تعریق» توصیف کتابی پاروکسیسم مالاریاست.**",
    ],
    DX_EN + [
        "In this patient all four components of the picture are present and none points elsewhere.",
        "Travel to Bandar Abbas three weeks ago fits within the incubation period of malaria.",
        "WARNING, PALE CONJUNCTIVAE mean haemolysis, and splenomegaly means reticuloendothelial involvement.",
        "And 'attacks of chill, fever and sweating' is the textbook description of a malarial paroxysm.",
    ],
    "این سؤال ساده‌ترین ورودی به بلوک مالاریاست و به همین دلیل ارزش دارد که **تابلو را از "
    "روی آن کامل حفظ کنید**.\n\n"
    "**چهار جزء تابلو:**\n\n"
    "**یک — سفر به منطقه‌ی مالاریاخیز.** بندرعباس در استان هرمزگان، از مناطق مالاریاخیز جنوب "
    "ایران. سه هفته پیش، که دقیقاً در بازه‌ی دوره‌ی نهفتگی مالاریا می‌گنجد.\n\n"
    "⚠️ **دو — حملات لرز، تب و تعریق.** این ترتیب سه‌مرحله‌ای، توصیف کتابی **پاروکسیسم "
    "مالاریا** است: ابتدا لرز شدید (وقتی شیزونت‌ها می‌ترکند)، سپس تب بالا، و در پایان تعریق "
    "شدید و افت دما.\n\n"
    "**سه — ملتحمه‌ی رنگ‌پریده.** یعنی **کم‌خونی**، که از **همولیز** گلبول‌های قرمز آلوده "
    "می‌آید.\n\n"
    "**چهار — بزرگی طحال.** طحال گلبول‌های آلوده و آسیب‌دیده را پاک می‌کند و در این فرآیند "
    "بزرگ می‌شود.\n\n"
    "**پس مالاریا محتمل‌ترین تشخیص است.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**کالاآزار (لیشمانیای احشایی):** اسپلنومگالی و کم‌خونی **دارد**، ولی **دوره‌ی نهفتگی "
    "آن ماه‌هاست، نه سه هفته**. به‌علاوه تب کالاآزار معمولاً **مداوم یا دوقله‌ای** است، نه "
    "حملات لرز-تب-تعریق. و اسپلنومگالی آن معمولاً **بسیار بزرگ** است.\n\n"
    "**تب راجعه:** تب دوره‌ای دارد، ولی الگوی آن **چند روز تب و چند روز بی‌تبی** است، نه "
    "حملات روزانه. و معمولاً سابقه‌ی گزش کنه یا شپش مطرح است.\n\n"
    "⚠️ **اندوکاردیت:** تب طولانی و اسپلنومگالی می‌دهد، ولی **سوفل قلبی، پدیده‌های آمبولیک "
    "و سابقه‌ی بیماری قلبی یا اعتیاد تزریقی** می‌خواهد. سؤال صریحاً گفته بیمار **زمینه‌ای ذکر "
    "نمی‌کند**، و مهم‌تر از آن، **سفر به منطقه‌ی مالاریاخیز** را نمی‌توان نادیده گرفت.",
    "This is the simplest entry point to the malaria block, and for that reason it is worth using it "
    "to MEMORISE THE WHOLE PICTURE.\n\n"
    "THE FOUR COMPONENTS:\n\n"
    "ONE — TRAVEL TO A MALARIOUS AREA. Bandar Abbas in Hormozgan province, one of the malarious areas "
    "of southern Iran. Three weeks ago, which falls exactly within the incubation period.\n\n"
    "WARNING, TWO — ATTACKS OF CHILL, FEVER AND SWEATING. That three-stage sequence is the textbook "
    "description of a MALARIAL PAROXYSM: first a hard rigor (as the schizonts rupture), then high "
    "fever, and finally profuse sweating with defervescence.\n\n"
    "THREE — PALE CONJUNCTIVAE. That means ANAEMIA, arising from HAEMOLYSIS of infected red cells.\n\n"
    "FOUR — SPLENOMEGALY. The spleen clears infected and damaged cells and enlarges in the process.\n\n"
    "SO MALARIA IS THE MOST LIKELY DIAGNOSIS.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "KALA-AZAR (visceral leishmaniasis): it DOES cause splenomegaly and anaemia, but ITS INCUBATION "
    "PERIOD IS MONTHS, NOT THREE WEEKS. Moreover its fever is usually CONTINUOUS OR DOUBLE-PEAKED, not "
    "chill-fever-sweat paroxysms. And its splenomegaly is usually MASSIVE.\n\n"
    "RELAPSING FEVER: it has periodic fever, but its pattern is SEVERAL DAYS OF FEVER ALTERNATING WITH "
    "AFEBRILE DAYS, not daily paroxysms. And a history of tick or louse exposure is usually present.\n\n"
    "WARNING, ENDOCARDITIS: it causes prolonged fever and splenomegaly, but requires A MURMUR, EMBOLIC "
    "PHENOMENA, and a history of heart disease or injecting drug use. The question states explicitly "
    "that the patient reports NO UNDERLYING CONDITION, and more importantly THE TRAVEL TO A MALARIOUS "
    "AREA cannot be ignored.",
    ["اسپلنومگالی و کم‌خونی دارد ولی دوره‌ی نهفتگی آن ماه‌هاست، نه سه هفته.",
     "پاسخ صحیح — سفر به منطقه‌ی مالاریاخیز، حملات لرز-تب-تعریق، کم‌خونی و اسپلنومگالی.",
     "الگوی تب آن چند روز تب و چند روز بی‌تبی است، نه حملات روزانه.",
     "سوفل قلبی و زمینه‌ی قلبی می‌خواهد؛ سؤال صریحاً گفته بیمار زمینه‌ای ندارد."],
    ["It causes splenomegaly and anaemia but its incubation is months, not three weeks.",
     "Correct — travel to a malarious area, chill-fever-sweat paroxysms, anaemia and splenomegaly.",
     "Its fever pattern alternates febrile and afebrile days, not daily paroxysms.",
     "It needs a murmur and cardiac background; the question states the patient has none."],
    "**لرز، تب، تعریق + طحال بزرگ + سفر به جنوب = تا خلاف آن ثابت نشده، مالاریا.**",
    "Chill, fever, sweat plus a big spleen plus travel to the south = malaria until proven otherwise.",
    REFS)

# ============================================== SPECIES BY MORPHOLOGY
MORPH_FA = [
    "⚠️ **گامتوسیت موزی‌شکل فقط و فقط فالسیپاروم است — این تک‌قاعده، دو سؤال را حل می‌کند.**",
    "**همه‌ی گونه‌های دیگر گامتوسیت گرد می‌سازند.**",
    "**پس دیدن شکل هلالی روی لام، تشخیص گونه را تمام می‌کند.**",
    "**سایر سرنخ‌های فالسیپاروم روی لام را هم بشناسید.**",
    "**پارازیتمی بالا: چون فالسیپاروم گلبول قرمز هر سنی را آلوده می‌کند.**",
    "**چند رینگ در یک گلبول قرمز: نشانه‌ی همان تهاجم انبوه.**",
    "⚠️ **رینگ دابل‌کروماتین (شکل هدفون): امضای دیگر فالسیپاروم.**",
    "**و گلبول‌های قرمز با اندازه‌ی طبیعی می‌مانند.**",
    "**در مقابل، ویواکس و اوال آینه‌ی این تصویرند.**",
    "**گلبول قرمز بزرگ‌شده، چون این دو رتیکولوسیت را ترجیح می‌دهند.**",
    "**نقاط شوفنر: دانه‌های زرد-قهوه‌ای داخل گلبول آلوده.**",
    "⚠️ **و پارازیتمی پایین، چون فقط گلبول‌های جوان را می‌گیرند.**",
    "**مالاریه هم پارازیتمی پایین دارد ولی گلبول را بزرگ نمی‌کند.**",
    "**و شکل «باند» یا نواری تروفوزوئیت، مشخصه‌ی مالاریه است.**",
]
MORPH_EN = [
    "WARNING: A BANANA-SHAPED GAMETOCYTE IS FALCIPARUM AND NOTHING ELSE — this one rule solves two questions.",
    "Every other species makes a ROUND gametocyte.",
    "So seeing the crescentic form on the film settles the species outright.",
    "Know the other falciparum clues on the film as well.",
    "HIGH parasitaemia: because falciparum invades red cells of any age.",
    "MULTIPLE RINGS IN ONE RED CELL: a sign of that same massive invasion.",
    "WARNING, A DOUBLE-CHROMATIN RING (the 'headphone' form): another falciparum signature.",
    "And the red cells remain NORMAL in size.",
    "By contrast, vivax and ovale are the mirror image of that picture.",
    "ENLARGED red cells, because these two prefer reticulocytes.",
    "SCHUFFNER'S DOTS: yellow-brown granules inside the infected cell.",
    "WARNING, AND A LOW PARASITAEMIA, because they take only young cells.",
    "P. malariae also has a low parasitaemia but does not enlarge the cell.",
    "And a BAND-shaped trophozoite is characteristic of P. malariae.",
]

add("book:764", "vignette", "easy",
    "**رینگ + گامتوسیت موزی‌شکل = فالسیپاروم، بدون هیچ ابهامی.**",
    "Rings plus a BANANA-SHAPED gametocyte = falciparum, with no ambiguity.",
    MORPH_FA,
    MORPH_EN,
    "این سؤال با **یک یافته‌ی مورفولوژیک** حل می‌شود، و همان یافته را کتاب چند بار تکرار "
    "کرده — پس ارزش امتحانی بالایی دارد.\n\n"
    "**بیمار: مهندس جوان، ۱۰ روز پس از بازگشت از چابهار (منطقه‌ی مالاریاخیز جنوب شرق)، با "
    "تب و لرز تکان‌دهنده، آنمی و اسپلنومگالی خفیف. در اسمیر خون محیطی: اشکال رینگ‌فرم و "
    "گامتوسیت موزی‌شکل.**\n\n"
    "⚠️ **گامتوسیت موزی‌شکل (هلالی) فقط و فقط پلاسمودیوم فالسیپاروم است.** همه‌ی گونه‌های "
    "دیگر — ویواکس، اوال، مالاریه — گامتوسیت **گرد** می‌سازند. پس این یک یافته، تشخیص گونه را "
    "به‌تنهایی تمام می‌کند.\n\n"
    "**سرنخ‌های تأییدکننده‌ی دیگر در تابلوی بیمار:**\n\n"
    "**سفر به جنوب شرق ایران** — منطقه‌ی اصلی فالسیپاروم و ویواکس در ایران.\n\n"
    "**لرز تکان‌دهنده** — پاروکسیسم مالاریایی.\n\n"
    "**آنمی و اسپلنومگالی** — همولیز و پاک‌سازی طحالی.\n\n"
    "**سایر سرنخ‌های فالسیپاروم روی لام را هم یاد بگیرید، چون سؤال‌های بعدی از آن‌ها استفاده "
    "می‌کنند:**\n\n"
    "⚠️ **پارازیتمی بالا** (فالسیپاروم گلبول قرمز **هر سنی** را آلوده می‌کند، پس بار انگلی "
    "می‌تواند بسیار بالا برود)؛ **چند رینگ در یک گلبول**؛ **رینگ دابل‌کروماتین** که به شکل "
    "هدفون دیده می‌شود؛ و **گلبول‌های قرمز با اندازه‌ی طبیعی**.\n\n"
    "**در مقابل، ویواکس و اوال:** **گلبول بزرگ‌شده** (چون رتیکولوسیت را ترجیح می‌دهند)، "
    "**نقاط شوفنر**، و **پارازیتمی پایین**.\n\n"
    "**و مالاریه:** پارازیتمی پایین، گلبول با اندازه‌ی طبیعی، و **تروفوزوئیت نواری (باند)**.\n\n"
    "**چرا تشخیص گونه این‌قدر مهم است؟** چون **فالسیپاروم تنها گونه‌ای است که مالاریای شدید "
    "و مرگ می‌دهد** و درمان آن با بقیه فرق دارد.",
    "This question is solved by ONE MORPHOLOGICAL FINDING, and the book repeats that finding several "
    "times — so it carries high exam value.\n\n"
    "THE PATIENT: a young engineer, 10 days after returning from Chabahar (the malarious south-east), "
    "with fever and shaking chills, anaemia and mild splenomegaly. On the film: ring forms and a "
    "BANANA-SHAPED GAMETOCYTE.\n\n"
    "WARNING, A BANANA-SHAPED (CRESCENTIC) GAMETOCYTE IS PLASMODIUM FALCIPARUM AND NOTHING ELSE. Every "
    "other species — vivax, ovale, malariae — makes a ROUND gametocyte. So this single finding settles "
    "the species by itself.\n\n"
    "OTHER CONFIRMING CLUES IN THE PICTURE:\n\n"
    "TRAVEL TO SOUTH-EASTERN IRAN — the main falciparum and vivax area of Iran.\n\n"
    "SHAKING CHILLS — a malarial paroxysm.\n\n"
    "ANAEMIA AND SPLENOMEGALY — haemolysis and splenic clearance.\n\n"
    "LEARN THE OTHER FALCIPARUM FILM CLUES TOO, BECAUSE LATER QUESTIONS USE THEM:\n\n"
    "WARNING, HIGH PARASITAEMIA (falciparum invades red cells OF ANY AGE, so the parasite load can rise "
    "very high); MULTIPLE RINGS IN ONE CELL; a DOUBLE-CHROMATIN RING that looks like a headphone; and "
    "RED CELLS OF NORMAL SIZE.\n\n"
    "BY CONTRAST, VIVAX AND OVALE: ENLARGED cells (because they prefer reticulocytes), SCHUFFNER'S "
    "DOTS, and a LOW parasitaemia.\n\n"
    "AND P. MALARIAE: low parasitaemia, normal-sized cells, and a BAND-FORM trophozoite.\n\n"
    "WHY DOES THE SPECIES MATTER SO MUCH? Because FALCIPARUM IS THE ONLY SPECIES THAT CAUSES SEVERE "
    "MALARIA AND DEATH, and its treatment differs from the rest.",
    ["پاسخ صحیح — گامتوسیت موزی‌شکل فقط در فالسیپاروم دیده می‌شود.",
     "گامتوسیت گرد می‌سازد و تروفوزوئیت نواری دارد؛ با این لام هم‌خوان نیست.",
     "گامتوسیت گرد، گلبول بزرگ‌شده و نقاط شوفنر دارد، نه شکل هلالی.",
     "مثل ویواکس گامتوسیت گرد و گلبول بزرگ‌شده دارد؛ شکل موزی نمی‌سازد."],
    ["Correct — a banana-shaped gametocyte is seen only in falciparum.",
     "Makes a round gametocyte and band-form trophozoites; inconsistent with this film.",
     "Has round gametocytes, enlarged cells and Schuffner's dots, not a crescent.",
     "Like vivax it has round gametocytes and enlarged cells; it makes no banana form."],
    "**گامتوسیت موزی‌شکل = فالسیپاروم. گرد = بقیه.**",
    "Banana-shaped gametocyte = falciparum. Round = everything else.",
    REFS)

add("book:766", "vignette", "easy",
    "**همان قاعده، بار دوم: گامتوسیت موزی‌شکل یعنی فالسیپاروم.**",
    "The same rule, a second time: a banana-shaped gametocyte means falciparum.",
    MORPH_FA + [
        "**اینجا آنمی و ترومبوسیتوپنی هم به تابلو اضافه شده است.**",
        "**ترومبوسیتوپنی در مالاریا بسیار شایع است و در همه‌ی گونه‌ها دیده می‌شود.**",
        "⚠️ **ولی ترومبوسیتوپنی به‌تنهایی معیار شدت نیست — این را جای دیگری لازم خواهید داشت.**",
        "**و مهاجر افغان، همان ریسک جغرافیایی جنوب شرق را دارد.**",
    ],
    MORPH_EN + [
        "Here anaemia and thrombocytopenia are added to the picture.",
        "Thrombocytopenia is very common in malaria and occurs with all species.",
        "WARNING, BUT THROMBOCYTOPENIA ALONE IS NOT A SEVERITY CRITERION — you will need that elsewhere.",
        "And an Afghan migrant carries the same geographical risk as the south-east.",
    ],
    "کتاب همان قاعده را دوباره پرسیده، و این تکرار پیام روشنی دارد: **گامتوسیت موزی‌شکل را "
    "یک بار درست یاد بگیرید و هر بار که دیدید، بی‌درنگ فالسیپاروم بگویید.**\n\n"
    "**بیمار: آقای ۳۰ ساله‌ی افغان با تب و لرز، آنمی و ترومبوسیتوپنی، و در لام خون محیطی "
    "گامتوسیت موزی‌شکل درون گلبول قرمز.**\n\n"
    "⚠️ **گامتوسیت موزی‌شکل = فالسیپاروم.** پاسخ همین است و به هیچ استدلال دیگری نیاز نیست.\n\n"
    "**دو نکته‌ی تکمیلی که این سؤال اضافه می‌کند:**\n\n"
    "**یک — جغرافیا از راه مهاجرت.** مهاجر تازه‌وارد از افغانستان یا پاکستان همان ریسک منطقه‌ی "
    "مالاریاخیز را دارد. در سؤال‌های ایرانی، **«مرد افغان تازه‌مهاجرت‌کرده»** یک سرنخ "
    "استاندارد برای مالاریاست.\n\n"
    "**دو — ترومبوسیتوپنی.** این یافته در مالاریا **بسیار شایع** است و در همه‌ی گونه‌ها دیده "
    "می‌شود. سازوکار آن چندعاملی است: پاک‌سازی طحالی پلاکت‌ها، مصرف در فرآیندهای التهابی، و "
    "گاهی سازوکار ایمنی.\n\n"
    "⚠️ **ولی این را برای سؤال‌های بعدی به خاطر بسپارید: ترومبوسیتوپنی به‌تنهایی معیار مالاریای "
    "شدید نیست.** کتاب دقیقاً از همین نکته سؤال ساخته است.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟** هر سه گامتوسیت **گرد** می‌سازند: **مالاریه** "
    "(با تروفوزوئیت نواری)، **ویواکس** و **اوال** (هر دو با گلبول بزرگ‌شده و نقاط شوفنر).",
    "The book asks the same rule again, and that repetition carries a clear message: LEARN THE "
    "BANANA-SHAPED GAMETOCYTE PROPERLY ONCE, AND WHENEVER YOU SEE IT, SAY FALCIPARUM AT ONCE.\n\n"
    "THE PATIENT: a 30-year-old Afghan man with fever and chills, anaemia and thrombocytopenia, and a "
    "banana-shaped gametocyte inside a red cell on the film.\n\n"
    "WARNING, BANANA-SHAPED GAMETOCYTE = FALCIPARUM. That is the answer and no further reasoning is "
    "needed.\n\n"
    "TWO ADDITIONAL POINTS THIS QUESTION ADDS:\n\n"
    "ONE — GEOGRAPHY THROUGH MIGRATION. A recent migrant from Afghanistan or Pakistan carries the same "
    "malarious-area risk. In Iranian exam questions, 'A RECENTLY MIGRATED AFGHAN MAN' is a standard "
    "clue for malaria.\n\n"
    "TWO — THROMBOCYTOPENIA. This finding is VERY COMMON in malaria and occurs with all species. Its "
    "mechanism is multifactorial: splenic clearance of platelets, consumption in inflammatory "
    "processes, and sometimes an immune mechanism.\n\n"
    "WARNING, BUT REMEMBER THIS FOR LATER QUESTIONS: THROMBOCYTOPENIA ALONE IS NOT A CRITERION FOR "
    "SEVERE MALARIA. The book has built a question on exactly that point.\n\n"
    "WHY ARE THE OTHER THREE REJECTED? All three make ROUND gametocytes: P. MALARIAE (with band-form "
    "trophozoites), VIVAX and OVALE (both with enlarged cells and Schuffner's dots).",
    ["گامتوسیت گرد و تروفوزوئیت نواری دارد؛ شکل موزی نمی‌سازد.",
     "گامتوسیت گرد با گلبول بزرگ‌شده و نقاط شوفنر دارد.",
     "پاسخ صحیح — گامتوسیت موزی‌شکل امضای اختصاصی فالسیپاروم است.",
     "مثل ویواکس گامتوسیت گرد دارد و گلبول را بزرگ می‌کند."],
    ["Has round gametocytes and band-form trophozoites; it makes no banana form.",
     "Has round gametocytes with enlarged cells and Schuffner's dots.",
     "Correct — the banana-shaped gametocyte is the specific signature of falciparum.",
     "Like vivax it has round gametocytes and enlarges the cell."],
    "**هلالی = فالسیپاروم. و ترومبوسیتوپنی شایع است ولی معیار شدت نیست.**",
    "Crescent = falciparum. And thrombocytopenia is common but is not a severity criterion.",
    REFS)

# ============================================== SEVERITY CRITERIA: THREE ITEMS
SEV_FA = [
    "⚠️ **معیارهای مالاریای شدید را به‌صورت فهرست شمردنی حفظ کنید، نه به‌صورت حس کلی.**",
    "**مالاریای مغزی: اختلال هوشیاری یا تشنج مکرر.**",
    "**کم‌خونی شدید: هموگلوبین زیر ۵ یا هماتوکریت زیر ۱۵.**",
    "**نارسایی کلیه، و ادم ریه یا ARDS.**",
    "⚠️ **هیپوگلیسمی زیر ۴۰ — همیشه هیپو، هرگز هیپر.**",
    "**کلاپس گردش خون، و خونریزی خودبه‌خودی یا DIC.**",
    "**اسیدوز متابولیک: pH زیر ۷٫۲۵ یا بیکربنات زیر ۱۵.**",
    "**هموگلوبینوری، زردی، و پارازیتمی بالای ۵ درصد.**",
    "⚠️ **حالا آنچه در فهرست نیست را هم بشناسید، چون امتحان از همان‌ها سؤال می‌سازد.**",
    "**لکوپنی خفیف: شایع است، ولی معیار شدت نیست.**",
    "**ترومبوسیتوپنی متوسط: بسیار شایع است، ولی معیار شدت نیست.**",
    "**افزایش خفیف تا متوسط آنزیم‌های کبدی: شایع است، ولی به‌تنهایی معیار شدت نیست.**",
    "**و pH طبیعی با بیکربنات مرزی هم معیار اسیدوز شدید را پر نمی‌کند.**",
    "⚠️ **چرا هیپوگلیسمی؟ سه سازوکار دارد و هر سه در سؤال‌ها می‌آیند.**",
    "**یک: انگل مصرف گلوکز بسیار بالایی دارد.**",
    "**دو: کینین و کینیدین ترشح انسولین را تحریک می‌کنند.**",
    "**سه: بیماری شدید، گلوکونئوژنز کبدی را مختل می‌کند.**",
]
SEV_EN = [
    "WARNING: MEMORISE THE SEVERE-MALARIA CRITERIA AS A COUNTABLE LIST, not as a general impression.",
    "CEREBRAL MALARIA: impaired consciousness or repeated convulsions.",
    "SEVERE ANAEMIA: haemoglobin below 5 or haematocrit below 15.",
    "RENAL FAILURE, and PULMONARY OEDEMA or ARDS.",
    "WARNING, HYPOGLYCAEMIA BELOW 40 — always HYPO, never HYPER.",
    "CIRCULATORY COLLAPSE, and spontaneous bleeding or DIC.",
    "METABOLIC ACIDOSIS: pH below 7.25 or bicarbonate below 15.",
    "HAEMOGLOBINURIA, JAUNDICE, and PARASITAEMIA ABOVE 5%.",
    "WARNING, NOW LEARN WHAT IS NOT ON THE LIST, because that is what the exam builds questions from.",
    "MILD LEUCOPENIA: common, but not a severity criterion.",
    "MODERATE THROMBOCYTOPENIA: very common, but not a severity criterion.",
    "A MILD TO MODERATE RISE IN LIVER ENZYMES: common, but not a severity criterion on its own.",
    "And a normal pH with a borderline bicarbonate does not meet the severe-acidosis criterion.",
    "WARNING, WHY HYPOGLYCAEMIA? It has three mechanisms and all three appear in questions.",
    "ONE: the parasite consumes glucose at a very high rate.",
    "TWO: quinine and quinidine stimulate insulin secretion.",
    "THREE: severe illness impairs hepatic gluconeogenesis.",
]

add("book:763", "recall", "medium",
    "**هیپرگلیسمی معیار مالاریای شدید نیست — معیار، هیپوگلیسمی است.**",
    "HYPERglycaemia is not a criterion of severe malaria — the criterion is HYPOglycaemia.",
    SEV_FA,
    SEV_EN,
    "این سؤال کوتاه است ولی یک **وارونگی** را می‌سنجد که بسیاری از دانشجویان در آن گیر "
    "می‌کنند.\n\n"
    "**سه گزینه‌ی دیگر همگی معیار قطعی مالاریای شدید فالسیپاروم‌اند:**\n\n"
    "**اختلال عملکرد کلیوی** — نارسایی حاد کلیه در مالاریای شدید شایع است و از **سکستراسیون "
    "گلبول‌های آلوده در مویرگ‌های کلیه**، هموگلوبینوری و هیپوولمی می‌آید.\n\n"
    "**ادم ریوی** — یکی از خطرناک‌ترین عوارض، که می‌تواند به ARDS برسد و مرگ‌ومیر بسیار بالایی "
    "دارد.\n\n"
    "**اسیدوز** — اسیدوز متابولیک (pH زیر ۷٫۲۵ یا بیکربنات زیر ۱۵) یکی از قوی‌ترین پیش‌بینی‌کننده‌های "
    "مرگ در مالاریای شدید است. علت آن **اسید لاکتیک** ناشی از انسداد میکروواسکولار و کاهش "
    "اکسیژن‌رسانی بافتی است.\n\n"
    "⚠️ **و گزینه‌ی چهارم، هیپرگلیسمی، دقیقاً برعکس است: معیار مالاریای شدید، هیپوگلیسمی "
    "(قند زیر ۴۰) است.**\n\n"
    "**چرا هیپوگلیسمی؟ سه سازوکار دارد و هر سه ارزش دانستن دارند:**\n\n"
    "**یک — مصرف بالای گلوکز توسط انگل.** پلاسمودیوم متابولیسم گلوکزی بسیار پرشتابی دارد و "
    "در پارازیتمی بالا، مصرف آن چشمگیر می‌شود.\n\n"
    "**دو — تحریک ترشح انسولین توسط کینین و کینیدین.** این نکته بالینی مهمی است: **درمان "
    "خودش می‌تواند هیپوگلیسمی بسازد**، پس در بیماری که کینین می‌گیرد باید قند خون پایش شود.\n\n"
    "**سه — اختلال گلوکونئوژنز کبدی** در بیماری شدید.\n\n"
    "⚠️ **و نکته‌ی بالینی خطرناک: هیپوگلیسمی در مالاریای مغزی می‌تواند با خود بیماری اشتباه "
    "شود** — هر دو کاهش هوشیاری می‌دهند. پس در هر بیمار مالاریایی با افت هوشیاری، **قند خون "
    "باید فوراً چک شود.**",
    "This question is short but tests AN INVERSION that many students stumble over.\n\n"
    "THE OTHER THREE OPTIONS ARE ALL DEFINITE CRITERIA OF SEVERE FALCIPARUM MALARIA:\n\n"
    "RENAL DYSFUNCTION — acute kidney injury is common in severe malaria and arises from SEQUESTRATION "
    "OF INFECTED CELLS IN RENAL CAPILLARIES, haemoglobinuria and hypovolaemia.\n\n"
    "PULMONARY OEDEMA — one of the most dangerous complications, which can progress to ARDS and "
    "carries a very high mortality.\n\n"
    "ACIDOSIS — metabolic acidosis (pH below 7.25 or bicarbonate below 15) is one of the strongest "
    "predictors of death in severe malaria. Its cause is LACTIC ACID from microvascular obstruction "
    "and reduced tissue oxygen delivery.\n\n"
    "WARNING, AND THE FOURTH OPTION, HYPERGLYCAEMIA, IS EXACTLY BACKWARDS: THE CRITERION IS "
    "HYPOGLYCAEMIA (glucose below 40).\n\n"
    "WHY HYPOGLYCAEMIA? It has three mechanisms, all worth knowing:\n\n"
    "ONE — HIGH GLUCOSE CONSUMPTION BY THE PARASITE. Plasmodium has a very rapid glucose metabolism, "
    "and at high parasitaemia its consumption becomes substantial.\n\n"
    "TWO — STIMULATION OF INSULIN SECRETION BY QUININE AND QUINIDINE. This is an important clinical "
    "point: THE TREATMENT ITSELF CAN CAUSE HYPOGLYCAEMIA, so blood glucose must be monitored in a "
    "patient receiving quinine.\n\n"
    "THREE — IMPAIRED HEPATIC GLUCONEOGENESIS in severe illness.\n\n"
    "WARNING, AND A DANGEROUS CLINICAL POINT: HYPOGLYCAEMIA IN CEREBRAL MALARIA CAN BE MISTAKEN FOR "
    "THE DISEASE ITSELF — both reduce consciousness. So in any malaria patient with a falling "
    "conscious level, THE BLOOD GLUCOSE MUST BE CHECKED IMMEDIATELY.",
    ["نارسایی حاد کلیه معیار قطعی مالاریای شدید است.",
     "ادم ریوی از خطرناک‌ترین عوارض و معیار قطعی شدت است.",
     "پاسخ صحیح — معیار، هیپوگلیسمی زیر ۴۰ است نه هیپرگلیسمی.",
     "اسیدوز متابولیک یکی از قوی‌ترین پیش‌بینی‌کننده‌های مرگ در مالاریای شدید است."],
    ["Acute renal failure is a definite criterion of severe malaria.",
     "Pulmonary oedema is among the most dangerous complications and a definite severity criterion.",
     "Correct — the criterion is hypoglycaemia below 40, not hyperglycaemia.",
     "Metabolic acidosis is one of the strongest predictors of death in severe malaria."],
    "**همیشه هیپوگلیسمی، هرگز هیپرگلیسمی — و کینین خودش آن را بدتر می‌کند.**",
    "Always hypoglycaemia, never hyperglycaemia — and quinine itself makes it worse.",
    REFS)

add("book:768", "recall", "medium",
    "**لکوپنی ۳۵۰۰ معیار پروگنوز بد نیست — سه گزینه‌ی دیگر معیارهای قطعی‌اند.**",
    "A white count of 3500 is not a poor-prognosis marker — the other three are definite criteria.",
    SEV_FA + [
        "**سه گزینه‌ی دیگر همگی مستقیماً از فهرست معیارهای WHO آمده‌اند.**",
        "**تشنج مکرر: تعریف مالاریای مغزی، با بالاترین مرگ‌ومیر.**",
        "**هماتوکریت زیر ۱۵: دقیقاً همان آستانه‌ی کم‌خونی شدید.**",
        "⚠️ **pH زیر یا مساوی ۷٫۱: اسیدوز متابولیک شدید، بدترین علامت پروگنوستیک.**",
        "**و لکوپنی ۳۵۰۰ یک یافته‌ی شایع و بی‌خطر در مالاریاست.**",
    ],
    SEV_EN + [
        "The other three come directly from the WHO criteria list.",
        "REPEATED CONVULSIONS: the definition of cerebral malaria, with the highest mortality.",
        "HAEMATOCRIT BELOW 15: exactly the severe-anaemia threshold.",
        "WARNING, pH AT OR BELOW 7.1: severe metabolic acidosis, the worst prognostic sign of all.",
        "And a white count of 3500 is a common, benign finding in malaria.",
    ],
    "این سؤال دقیقاً همان فهرست را می‌سنجد، ولی این بار با **اعداد**. پس باید آستانه‌ها را "
    "بلد باشید، نه فقط نام معیارها.\n\n"
    "**سه گزینه‌ای که واقعاً پروگنوز بد را نشان می‌دهند:**\n\n"
    "⚠️ **تشنج مکرر** — این تعریف **مالاریای مغزی** است، شدیدترین شکل بیماری با **بالاترین "
    "مرگ‌ومیر** (حتی با درمان مناسب، ۱۵ تا ۲۰ درصد). سازوکار آن **سکستراسیون گلبول‌های آلوده "
    "در مویرگ‌های مغز** است.\n\n"
    "**آنمی شدید با هماتوکریت زیر ۱۵** — این **دقیقاً آستانه‌ی معیار WHO** است (هموگلوبین "
    "زیر ۵ یا هماتوکریت زیر ۱۵). عدد سؤال روی خودِ آستانه نشسته است.\n\n"
    "**اسیدوز متابولیک شدید با pH کمتر یا مساوی ۷٫۱** — این **بدترین علامت پروگنوستیک** در "
    "مالاریای شدید است. آستانه‌ی معیار pH زیر ۷٫۲۵ است، و ۷٫۱ به‌مراتب پایین‌تر از آن.\n\n"
    "**و گزینه‌ی چهارم: لکوپنی ۳۵۰۰.**\n\n"
    "⚠️ **چرا این معیار نیست؟** چون **لکوپنی خفیف در مالاریا بسیار شایع است** و یک یافته‌ی "
    "معمولی محسوب می‌شود، نه علامت خطر. عدد ۳۵۰۰ فقط **کمی** زیر حد پایین طبیعی (۴۰۰۰) است — "
    "این حتی لکوپنی شدید هم نیست.\n\n"
    "**در فهرست معیارهای WHO، هیچ آستانه‌ای برای شمارش گلبول سفید وجود ندارد.**\n\n"
    "**درس روش‌شناختی این سؤال:** در سؤال‌های «کدام معیار نیست»، **فهرست را بشمارید**. اگر "
    "معیارهای WHO را به‌صورت فهرست شمردنی حفظ کرده باشید، گزینه‌ای که در فهرست نیست فوراً "
    "خودش را نشان می‌دهد. حفظ کردن «حس کلی» از شدت بیماری، برای این نوع سؤال کافی نیست.",
    "This question tests the same list, but this time WITH NUMBERS. So the thresholds must be known, "
    "not just the names of the criteria.\n\n"
    "THE THREE OPTIONS THAT GENUINELY INDICATE A POOR PROGNOSIS:\n\n"
    "WARNING, REPEATED CONVULSIONS — this is the definition of CEREBRAL MALARIA, the severest form "
    "with the HIGHEST MORTALITY (15 to 20% even with proper treatment). Its mechanism is SEQUESTRATION "
    "OF INFECTED CELLS IN CEREBRAL CAPILLARIES.\n\n"
    "SEVERE ANAEMIA WITH A HAEMATOCRIT BELOW 15 — this is EXACTLY THE WHO THRESHOLD (haemoglobin below "
    "5 or haematocrit below 15). The number in the question sits on the threshold itself.\n\n"
    "SEVERE METABOLIC ACIDOSIS WITH pH AT OR BELOW 7.1 — THE WORST PROGNOSTIC SIGN in severe malaria. "
    "The criterion threshold is a pH below 7.25, and 7.1 is far below that.\n\n"
    "AND THE FOURTH OPTION: LEUCOPENIA OF 3500.\n\n"
    "WARNING, WHY IS THIS NOT A CRITERION? Because MILD LEUCOPENIA IS VERY COMMON IN MALARIA and "
    "counts as an ordinary finding, not a danger sign. The figure 3500 is only SLIGHTLY below the "
    "lower limit of normal (4000) — this is not even severe leucopenia.\n\n"
    "THERE IS NO WHITE-CELL THRESHOLD ANYWHERE IN THE WHO CRITERIA LIST.\n\n"
    "THE METHODOLOGICAL LESSON: in 'which is NOT a criterion' questions, COUNT THE LIST. If you have "
    "memorised the WHO criteria as a countable list, the option that is not on it declares itself "
    "immediately. Memorising a 'general impression' of severity is not enough for this kind of question.",
    ["تعریف مالاریای مغزی است، با بالاترین مرگ‌ومیر در میان اشکال بیماری.",
     "هماتوکریت زیر ۱۵ دقیقاً همان آستانه‌ی کم‌خونی شدید در معیارهای WHO است.",
     "اسیدوز شدید بدترین علامت پروگنوستیک است؛ آستانه pH زیر ۷٫۲۵ است.",
     "پاسخ صحیح — لکوپنی خفیف در مالاریا شایع است و در فهرست معیارهای شدت نیست."],
    ["The definition of cerebral malaria, with the highest mortality of all forms.",
     "A haematocrit below 15 is exactly the WHO severe-anaemia threshold.",
     "Severe acidosis is the worst prognostic sign; the threshold is a pH below 7.25.",
     "Correct — mild leucopenia is common in malaria and is not on the severity list."],
    "**در سؤال «کدام معیار نیست»، فهرست را بشمارید — حس کلی کافی نیست.**",
    "In a 'which is NOT a criterion' question, count the list — a general impression is not enough.",
    REFS)

add("book:769", "recall", "hard",
    "**افزایش آنزیم‌های کبدی پنج برابر، تنها گزینه‌ای است که وارد محدوده‌ی نگران‌کننده می‌شود.**",
    "A fivefold rise in liver enzymes is the only option that enters worrying territory.",
    SEV_FA + [
        "**این سؤال برعکس قبلی است: باید معیار را پیدا کنید، نه استثنا را.**",
        "**و سه گزینه‌ی دیگر عمداً روی مرز طبیعی چیده شده‌اند.**",
        "**لکوپنی ۳۰۰۰: خفیف و شایع، در فهرست معیارها نیست.**",
        "**پلاکت ۶۶۰۰۰: ترومبوسیتوپنی متوسط، بسیار شایع و بدون ارزش پروگنوستیک مستقل.**",
        "⚠️ **pH برابر ۷٫۳۵ کاملاً طبیعی است و بیکربنات ۱۷ هم بالای آستانه‌ی ۱۵ است.**",
        "**پس گزینه‌ی اسیدوز، معیار اسیدوز شدید را پر نمی‌کند.**",
        "**می‌ماند آنزیم‌های کبدی پنج برابر نرمال، که زردی و اختلال کبدی را مطرح می‌کند.**",
        "**و زردی در فهرست معیارهای WHO هست.**",
    ],
    SEV_EN + [
        "This question is the reverse of the previous one: find the criterion, not the exception.",
        "And the other three options are deliberately placed on the edge of normal.",
        "LEUCOPENIA OF 3000: mild and common, not on the criteria list.",
        "PLATELETS 66,000: moderate thrombocytopenia, very common and without independent prognostic value.",
        "WARNING, A pH OF 7.35 IS ENTIRELY NORMAL, and a bicarbonate of 17 is above the threshold of 15.",
        "So the acidosis option does not meet the severe-acidosis criterion.",
        "That leaves liver enzymes at five times normal, which raises jaundice and hepatic dysfunction.",
        "And jaundice IS on the WHO criteria list.",
    ],
    "این سؤال **برعکس** سؤال قبلی است — این بار باید **معیار** را پیدا کنید، نه استثنا را. "
    "و کتاب سه گزینه را عمداً **روی مرز طبیعی** چیده تا آن‌ها را پس بزنید.\n\n"
    "**بیمار: توریست ۲۰ ساله، دو هفته پس از بازگشت از آفریقا، با تب و لرز، زردی و بدحالی. "
    "در لام خون محیطی پلاسمودیوم به میزان زیاد.**\n\n"
    "**نکته‌ی مهم پیش از بررسی گزینه‌ها: «پلاسمودیوم به میزان زیاد» یعنی پارازیتمی بالا، و "
    "پارازیتمی بالای ۵ درصد خودش معیار شدت است.** پس بیمار از قبل نگران‌کننده است.\n\n"
    "**حالا سه گزینه‌ای که رد می‌شوند:**\n\n"
    "**لکوپنی ۳۰۰۰** — لکوپنی خفیف، شایع در مالاریا، **در فهرست معیارهای WHO نیست**.\n\n"
    "**ترومبوسیتوپنی ۶۶۰۰۰** — ترومبوسیتوپنی **متوسط**. در مالاریا **بسیار شایع** است (تا "
    "بیش از ۶۰ درصد بیماران) و **ارزش پروگنوستیک مستقلی ندارد**. خطر خونریزی در این سطح "
    "پلاکت هم پایین است. معیار WHO **خونریزی خودبه‌خودی یا DIC** است، نه یک عدد پلاکت.\n\n"
    "⚠️ **pH خون ۷٫۳۵ و بیکربنات ۱۷** — این گزینه‌ی تله‌گذاری‌شده است. **pH برابر ۷٫۳۵ کاملاً "
    "طبیعی است** (محدوده‌ی طبیعی ۷٫۳۵ تا ۷٫۴۵). و **بیکربنات ۱۷ بالای آستانه‌ی ۱۵** است. پس "
    "**معیار اسیدوز شدید پر نمی‌شود.** اگر عدد ۷٫۱ و بیکربنات ۱۲ بود، پاسخ همین می‌شد.\n\n"
    "**و می‌ماند: آنزیم‌های کبدی AST و ALT بیش از پنج برابر نرمال.**\n\n"
    "**چرا این نگران‌کننده است؟** بیمار **زردی** دارد (در متن سؤال آمده)، و **زردی در فهرست "
    "معیارهای مالاریای شدید WHO هست**. افزایش پنج‌برابری آنزیم‌ها نشان می‌دهد که این زردی "
    "صرفاً همولیتیک نیست، بلکه **اختلال عملکرد کبدی** هم وجود دارد — یعنی درگیری ارگان.\n\n"
    "⚠️ **درس این سؤال: به اعداد نگاه کنید، نه به نام آزمایش.** «اسیدوز» در گزینه نوشته شده "
    "ولی اعدادش طبیعی است. «ترومبوسیتوپنی» نوشته شده ولی عددش متوسط است. **کتاب نام معیار را "
    "می‌نویسد و عدد غیرمعیار می‌دهد** — و این دقیقاً همان تله‌ای است که باید بشناسید.",
    "This question is THE REVERSE of the previous one — this time you must find the CRITERION, not the "
    "exception. And the book has deliberately placed three options ON THE EDGE OF NORMAL so that you "
    "reject them.\n\n"
    "THE PATIENT: a 20-year-old tourist, two weeks after returning from Africa, with fever and chills, "
    "jaundice and malaise. The film shows plasmodium IN LARGE NUMBERS.\n\n"
    "AN IMPORTANT POINT BEFORE THE OPTIONS: 'plasmodium in large numbers' means HIGH PARASITAEMIA, and "
    "a parasitaemia above 5% is itself a severity criterion. So the patient is already worrying.\n\n"
    "NOW THE THREE THAT ARE REJECTED:\n\n"
    "LEUCOPENIA OF 3000 — mild leucopenia, common in malaria, NOT ON THE WHO LIST.\n\n"
    "THROMBOCYTOPENIA OF 66,000 — MODERATE thrombocytopenia. It is VERY COMMON in malaria (over 60% "
    "of patients) and HAS NO INDEPENDENT PROGNOSTIC VALUE. The bleeding risk at this platelet level is "
    "also low. The WHO criterion is SPONTANEOUS BLEEDING OR DIC, not a platelet number.\n\n"
    "WARNING, A pH OF 7.35 WITH A BICARBONATE OF 17 — this is the booby-trapped option. A pH OF 7.35 IS "
    "ENTIRELY NORMAL (the normal range is 7.35 to 7.45). And A BICARBONATE OF 17 IS ABOVE THE "
    "THRESHOLD OF 15. So THE SEVERE-ACIDOSIS CRITERION IS NOT MET. Had the figures been 7.1 and 12, "
    "this would have been the answer.\n\n"
    "THAT LEAVES: LIVER ENZYMES, AST AND ALT, AT MORE THAN FIVE TIMES NORMAL.\n\n"
    "WHY IS THAT WORRYING? The patient HAS JAUNDICE (stated in the stem), and JAUNDICE IS ON THE WHO "
    "SEVERE-MALARIA LIST. A fivefold enzyme rise shows this jaundice is not purely haemolytic but that "
    "there is also HEPATIC DYSFUNCTION — that is, organ involvement.\n\n"
    "WARNING, THE LESSON: LOOK AT THE NUMBERS, NOT AT THE NAME OF THE TEST. The option says 'acidosis' "
    "but its numbers are normal. It says 'thrombocytopenia' but the figure is moderate. THE BOOK "
    "WRITES THE NAME OF A CRITERION AND SUPPLIES A NON-CRITERION VALUE — and that is exactly the trap "
    "to recognise.",
    ["لکوپنی خفیف است و در فهرست معیارهای شدت WHO جایی ندارد.",
     "ترومبوسیتوپنی متوسط در مالاریا بسیار شایع است و ارزش پروگنوستیک مستقلی ندارد.",
     "پاسخ صحیح — افزایش پنج‌برابری آنزیم‌ها با زردی بیمار، درگیری عملکرد کبدی را نشان می‌دهد.",
     "تله‌ی سؤال — pH برابر ۷٫۳۵ طبیعی و بیکربنات ۱۷ بالای آستانه‌ی ۱۵ است."],
    ["Mild leucopenia, which has no place on the WHO severity list.",
     "Moderate thrombocytopenia is very common in malaria and has no independent prognostic value.",
     "Correct — a fivefold enzyme rise with the patient's jaundice indicates hepatic dysfunction.",
     "The trap — a pH of 7.35 is normal and a bicarbonate of 17 is above the threshold of 15."],
    "**نام معیار در گزینه، عدد غیرمعیار در متن — همیشه عدد را بخوانید.**",
    "The name of a criterion in the option, a non-criterion value in the text — always read the number.",
    REFS)

# ============================================== DIAGNOSTIC ACTION: FOUR ITEMS
add("book:770", "vignette", "hard",
    "**باردار + تب + تشنج + سفر به جنوب: اسمیر ضخیم، و تشخیص مالاریای فالسیپاروم.**",
    "Pregnant plus fever plus seizure plus travel to the south: THICK film, and the diagnosis is falciparum malaria.",
    DX_FA + [
        "**در این بیمار سه عامل خطر با هم جمع شده‌اند.**",
        "**بارداری، سه‌ماهه‌ی سوم، و سفر به منطقه‌ی مالاریاخیز.**",
        "⚠️ **بارداری خودش مالاریا را شدیدتر می‌کند و این نکته‌ی حیاتی است.**",
        "**چون جفت جایگاه ترجیحی سکستراسیون گلبول‌های آلوده است.**",
        "**پس زن باردار هم پارازیتمی بالاتر می‌گیرد و هم عوارض شدیدتر.**",
        "**تشنج و کانفیوژن یعنی مالاریای مغزی: شدیدترین شکل بیماری.**",
        "**هموگلوبین ۶٫۴ یعنی کم‌خونی شدید نزدیک به آستانه‌ی معیار.**",
        "⚠️ **و پلاکت ۷۵ هزار، همان ترومبوسیتوپنی شایع مالاریاست.**",
        "**تنها گونه‌ای که مالاریای مغزی می‌دهد، فالسیپاروم است.**",
        "**و اسمیر ضخیم، حساس‌ترین و سریع‌ترین راه تأیید است.**",
    ],
    DX_EN + [
        "In this patient three risk factors come together.",
        "Pregnancy, the third trimester, and travel to a malarious area.",
        "WARNING, PREGNANCY ITSELF MAKES MALARIA MORE SEVERE, and this is a vital point.",
        "Because the placenta is a preferred site for sequestration of infected cells.",
        "So a pregnant woman gets both a higher parasitaemia and more severe complications.",
        "Seizure and confusion mean CEREBRAL MALARIA: the severest form of the disease.",
        "A haemoglobin of 6.4 is severe anaemia, close to the criterion threshold.",
        "WARNING, AND PLATELETS OF 75,000 are the thrombocytopenia typical of malaria.",
        "The only species that causes cerebral malaria is falciparum.",
        "And the thick film is the most sensitive and fastest way to confirm it.",
    ],
    "این سؤال یک اورژانس واقعی را توصیف می‌کند و **دو چیز را هم‌زمان می‌خواهد: اقدام تشخیصی "
    "و تشخیص**.\n\n"
    "**بیمار: خانم جوان در ماه هشتم حاملگی، سه هفته پس از سفر به چابهار، با تب، سردرد و "
    "تشنج. در معاینه کانفیوژن، لتارژی و تب ۴۱ درجه. هموگلوبین ۶٫۴ و پلاکت ۷۵ هزار.**\n\n"
    "**بیایید تابلو را قطعه‌قطعه بخوانیم:**\n\n"
    "**سفر به منطقه‌ی مالاریاخیز جنوب شرق** — پس مالاریا در صدر فهرست است.\n\n"
    "⚠️ **تشنج + کانفیوژن + لتارژی = مالاریای مغزی.** این شدیدترین شکل بیماری است و **تنها "
    "فالسیپاروم آن را می‌دهد** — چون تنها فالسیپاروم است که **سکستراسیون** در مویرگ‌های مغز "
    "ایجاد می‌کند.\n\n"
    "**هموگلوبین ۶٫۴** — کم‌خونی شدید، از همولیز گسترده.\n\n"
    "**پلاکت ۷۵ هزار** — ترومبوسیتوپنی، شایع در مالاریا.\n\n"
    "**تب ۴۱ درجه** — تب بسیار بالا.\n\n"
    "⚠️ **و عامل تشدیدکننده‌ی حیاتی: بارداری.** چرا بارداری مالاریا را بدتر می‌کند؟ چون "
    "**جفت جایگاه ترجیحی سکستراسیون گلبول‌های آلوده** است. گلبول‌های آلوده به گیرنده‌های "
    "جفتی می‌چسبند و در آنجا تجمع می‌کنند. نتیجه: **پارازیتمی بالاتر، کم‌خونی شدیدتر، "
    "هیپوگلیسمی شایع‌تر، و خطر مرگ مادر و جنین بسیار بیشتر.** مالاریا در بارداری همیشه یک "
    "**اورژانس** است.\n\n"
    "**اقدام تشخیصی: اسمیر ضخیم خون محیطی.** چرا ضخیم؟ چون **حجم خون بیشتری را می‌بیند و "
    "حساس‌تر است** — و در بیمار بدحال، سرعت و حساسیت مهم‌تر است. (در عمل اسمیر نازک هم "
    "هم‌زمان تهیه می‌شود تا گونه تعیین شود.)\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**آنالیز CSF — مننژیت باکتریال:** تب و تشنج و کانفیوژن دارد، ولی **علائم تحریک مننژ** "
    "ذکر نشده، و مهم‌تر: **کم‌خونی شدید و ترومبوسیتوپنی و سابقه‌ی سفر** مالاریا را بسیار "
    "محتمل‌تر می‌کند. به‌علاوه در بیمار با احتمال مالاریای مغزی، **LP پیش از رد کردن مالاریا** "
    "منطقی نیست.\n\n"
    "**اسمیر نازک — مالاریای ویواکس:** بخش اسمیر درست است ولی **ویواکس مالاریای مغزی نمی‌دهد**. "
    "این تشخیص با تابلو نمی‌خواند.\n\n"
    "**کشت خون — سپسیس مننگوکوکی:** کشت خون **روزها** طول می‌کشد و در این اورژانس بی‌فایده "
    "است. به‌علاوه سپسیس مننگوکوکی **راش پتشیال یا پورپورا** می‌دهد که ذکر نشده.",
    "This question describes a genuine emergency and asks TWO THINGS AT ONCE: the diagnostic step and "
    "the diagnosis.\n\n"
    "THE PATIENT: a young woman in the eighth month of pregnancy, three weeks after travelling to "
    "Chabahar, with fever, headache and a seizure. On examination she is confused and lethargic with a "
    "temperature of 41 degrees. Haemoglobin 6.4 and platelets 75,000.\n\n"
    "LET US READ THE PICTURE PIECE BY PIECE:\n\n"
    "TRAVEL TO THE MALARIOUS SOUTH-EAST — so malaria heads the list.\n\n"
    "WARNING, SEIZURE PLUS CONFUSION PLUS LETHARGY = CEREBRAL MALARIA. This is the severest form of "
    "the disease and ONLY FALCIPARUM CAUSES IT — because only falciparum produces SEQUESTRATION in "
    "cerebral capillaries.\n\n"
    "HAEMOGLOBIN 6.4 — severe anaemia from extensive haemolysis.\n\n"
    "PLATELETS 75,000 — thrombocytopenia, common in malaria.\n\n"
    "TEMPERATURE 41 — a very high fever.\n\n"
    "WARNING, AND THE VITAL AGGRAVATING FACTOR: PREGNANCY. Why does pregnancy make malaria worse? "
    "Because THE PLACENTA IS A PREFERRED SITE FOR SEQUESTRATION of infected cells. Infected cells bind "
    "placental receptors and accumulate there. The result: HIGHER PARASITAEMIA, MORE SEVERE ANAEMIA, "
    "MORE FREQUENT HYPOGLYCAEMIA, AND A MUCH HIGHER RISK OF MATERNAL AND FETAL DEATH. Malaria in "
    "pregnancy is always AN EMERGENCY.\n\n"
    "THE DIAGNOSTIC STEP: A THICK PERIPHERAL BLOOD FILM. Why thick? Because it EXAMINES A GREATER "
    "VOLUME OF BLOOD AND IS MORE SENSITIVE — and in a critically ill patient speed and sensitivity "
    "matter most. (In practice a thin film is made at the same time to identify the species.)\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "CSF ANALYSIS FOR BACTERIAL MENINGITIS: fever, seizure and confusion are present, but MENINGEAL "
    "IRRITATION is not mentioned, and more importantly SEVERE ANAEMIA, THROMBOCYTOPENIA AND THE TRAVEL "
    "HISTORY make malaria far more likely. Moreover, in a patient with possible cerebral malaria, "
    "performing an LP BEFORE EXCLUDING MALARIA is not sensible.\n\n"
    "THIN FILM FOR VIVAX MALARIA: the film part is right, but VIVAX DOES NOT CAUSE CEREBRAL MALARIA. "
    "That diagnosis does not fit the picture.\n\n"
    "BLOOD CULTURE FOR MENINGOCOCCAL SEPSIS: a blood culture takes DAYS and is useless in this "
    "emergency. And meningococcal sepsis produces a PETECHIAL OR PURPURIC RASH, which is not mentioned.",
    ["پاسخ صحیح — اسمیر ضخیم حساس‌ترین اقدام است، و مالاریای مغزی فقط با فالسیپاروم رخ می‌دهد.",
     "علائم تحریک مننژ ذکر نشده و کم‌خونی و ترومبوسیتوپنی مالاریا را محتمل‌تر می‌کند.",
     "اسمیر درست است ولی ویواکس مالاریای مغزی نمی‌دهد؛ تشخیص با تابلو نمی‌خواند.",
     "کشت خون روزها طول می‌کشد و سپسیس مننگوکوکی راش پتشیال می‌خواهد که ذکر نشده."],
    ["Correct — the thick film is the most sensitive step, and cerebral malaria occurs only with falciparum.",
     "Meningeal signs are not described, and the anaemia and thrombocytopenia favour malaria.",
     "The film is right but vivax does not cause cerebral malaria; the diagnosis does not fit.",
     "Blood culture takes days, and meningococcal sepsis needs a petechial rash, which is not mentioned."],
    "**بارداری مالاریا را بدتر می‌کند، چون جفت جایگاه ترجیحی سکستراسیون است.**",
    "Pregnancy worsens malaria, because the placenta is a preferred sequestration site.",
    REFS)

add("book:771", "vignette", "medium",
    "**مهاجر تازه‌وارد با اختلال چندارگانی: اسمیر ضخیم و نازک — نه مغز استخوان، نه کشت.**",
    "A recent migrant with multi-organ derangement: THICK AND THIN FILMS — not marrow, not culture.",
    DX_FA + [
        "**تابلوی این بیمار مالاریای شدید چندارگانی است.**",
        "**پلاکت پایین، اسیدوز متابولیک، کراتینین بالا و آنمی شدید.**",
        "⚠️ **اسیدوز و نارسایی کلیه هر دو در فهرست معیارهای WHO هستند.**",
        "**پس این بیمار وقت برای آزمون‌های کند ندارد.**",
        "**اسمیر خون در عرض چند دقیقه پاسخ می‌دهد.**",
        "**و در همان نمونه، هم تشخیص و هم گونه و هم درصد پارازیتمی به دست می‌آید.**",
        "**درصد پارازیتمی برای تصمیم درمانی حیاتی است: بالای ۵ درصد یعنی شدید.**",
        "⚠️ **آسپیراسیون مغز استخوان تهاجمی است و در بیمار با پلاکت پایین خطرناک.**",
        "**و پاسخ آن روزها طول می‌کشد.**",
    ],
    DX_EN + [
        "This patient's picture is severe, multi-organ malaria.",
        "Low platelets, metabolic acidosis, a raised creatinine and severe anaemia.",
        "WARNING, ACIDOSIS AND RENAL FAILURE ARE BOTH ON THE WHO CRITERIA LIST.",
        "So this patient has no time for slow tests.",
        "A blood film answers within minutes.",
        "And from the same sample come the diagnosis, the species and the percentage parasitaemia.",
        "The percentage parasitaemia is vital for the treatment decision: above 5% means severe.",
        "WARNING, BONE MARROW ASPIRATION IS INVASIVE and dangerous in a patient with low platelets.",
        "And its result takes days.",
    ],
    "این سؤال یک بیمار **بدحال چندارگانی** را توصیف می‌کند و می‌خواهد بدانیم **سریع‌ترین راه "
    "به تشخیص** کدام است.\n\n"
    "**بیمار: مرد ۴۲ ساله‌ی افغان که یک هفته پیش از کشورش به ایران مهاجرت کرده. تب بالا، درد "
    "بدن، سردرد و اسهال. در آزمایشات: پلاکت پایین، اسیدوز متابولیک، کراتینین بالا و آنمی شدید.**\n\n"
    "**اول جغرافیا:** **مهاجر تازه‌وارد از افغانستان** — ریسک مالاریا بالا.\n\n"
    "⚠️ **حالا شدت را ارزیابی کنید:** **اسیدوز متابولیک** و **کراتینین بالا (نارسایی کلیه)** "
    "**هر دو در فهرست معیارهای مالاریای شدید WHO** هستند. **آنمی شدید** هم همین‌طور. پس این "
    "بیمار **مالاریای شدید چندارگانی** دارد و **وقت ندارد**.\n\n"
    "**پس اقدام تشخیصی باید سه ویژگی داشته باشد: سریع، حساس، و کم‌خطر.**\n\n"
    "**اسمیر ضخیم و نازک خون محیطی هر سه را دارد:**\n\n"
    "**سریع** — پاسخ در چند دقیقه.\n\n"
    "**جامع** — از همان یک نمونه، هم **تشخیص** (ضخیم)، هم **گونه** (نازک)، و هم **درصد "
    "پارازیتمی** (نازک) به دست می‌آید. و درصد پارازیتمی برای تصمیم درمانی حیاتی است: **بالای "
    "۵ درصد یعنی مالاریای شدید و نیاز به آرتسونات وریدی**.\n\n"
    "**کم‌خطر** — فقط یک قطره خون.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "⚠️ **آسپیراسیون و بیوپسی مغز استخوان:** **تهاجمی** است، در بیمار با **پلاکت پایین "
    "خطرناک** است، **روزها** طول می‌کشد، و برای تشخیص مالاریا **اصلاً لازم نیست** — انگل در "
    "خون محیطی به‌راحتی دیده می‌شود.\n\n"
    "**کشت خون و کشت ادرار:** برای عفونت **باکتریایی** است. **مالاریا در کشت رشد نمی‌کند.** "
    "(البته در بیمار بدحال، کشت خون به‌عنوان اقدام موازی معقول است، ولی **راه رسیدن به تشخیص "
    "این بیمار** نیست.)\n\n"
    "**اسمیر و کشت مغز استخوان:** همان ایرادهای بالا، به‌علاوه‌ی بی‌فایدگی کشت.",
    "This question describes a CRITICALLY ILL, MULTI-ORGAN patient and asks for THE FASTEST ROUTE TO "
    "THE DIAGNOSIS.\n\n"
    "THE PATIENT: a 42-year-old Afghan man who migrated to Iran a week ago. High fever, body aches, "
    "headache and diarrhoea. Laboratory: low platelets, metabolic acidosis, raised creatinine and "
    "severe anaemia.\n\n"
    "FIRST THE GEOGRAPHY: A RECENT MIGRANT FROM AFGHANISTAN — high malaria risk.\n\n"
    "WARNING, NOW ASSESS THE SEVERITY: METABOLIC ACIDOSIS and A RAISED CREATININE (renal failure) ARE "
    "BOTH ON THE WHO SEVERE-MALARIA LIST. So is SEVERE ANAEMIA. This patient has SEVERE, MULTI-ORGAN "
    "MALARIA and HAS NO TIME.\n\n"
    "SO THE DIAGNOSTIC STEP MUST BE THREE THINGS: FAST, SENSITIVE AND LOW-RISK.\n\n"
    "THICK AND THIN PERIPHERAL FILMS ARE ALL THREE:\n\n"
    "FAST — an answer in minutes.\n\n"
    "COMPREHENSIVE — from that one sample come the DIAGNOSIS (thick), the SPECIES (thin) and the "
    "PERCENTAGE PARASITAEMIA (thin). And the percentage parasitaemia is vital for treatment: ABOVE 5% "
    "MEANS SEVERE MALARIA AND INTRAVENOUS ARTESUNATE.\n\n"
    "LOW-RISK — a single drop of blood.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "WARNING, BONE MARROW ASPIRATION AND BIOPSY: INVASIVE, DANGEROUS in a patient with LOW PLATELETS, "
    "takes DAYS, and IS SIMPLY NOT NEEDED for malaria — the parasite is readily seen in peripheral blood.\n\n"
    "BLOOD AND URINE CULTURE: these are for BACTERIAL infection. MALARIA DOES NOT GROW IN CULTURE. (In "
    "a critically ill patient a blood culture is reasonable as a parallel step, but it is not THE "
    "ROUTE TO THIS PATIENT'S DIAGNOSIS.)\n\n"
    "MARROW SMEAR AND CULTURE: the same objections, plus the futility of the culture.",
    ["پاسخ صحیح — سریع، حساس و کم‌خطر؛ و هم گونه و هم درصد پارازیتمی را می‌دهد.",
     "تهاجمی است، در پلاکت پایین خطرناک، و برای تشخیص مالاریا اصلاً لازم نیست.",
     "کشت برای عفونت باکتریایی است؛ مالاریا در کشت رشد نمی‌کند.",
     "همان ایرادهای مغز استخوان، به‌علاوه‌ی اینکه کشت برای انگل بی‌فایده است."],
    ["Correct — fast, sensitive and low-risk, and it gives both the species and the parasitaemia.",
     "Invasive, dangerous with low platelets, and simply not needed to diagnose malaria.",
     "Culture is for bacterial infection; malaria does not grow in culture.",
     "The same objections as marrow, plus the futility of culture for a parasite."],
    "**یک قطره خون: تشخیص، گونه، و درصد پارازیتمی — همه با هم.**",
    "One drop of blood: diagnosis, species and percentage parasitaemia — all at once.",
    REFS)

add("book:772", "vignette", "medium",
    "**تب پس از زاهدان با لکوپنی و ترومبوسیتوپنی: لام خون محیطی به‌علاوه‌ی کشت خون.**",
    "Fever after Zahedan with leucopenia and thrombocytopenia: a BLOOD FILM PLUS a BLOOD CULTURE.",
    DX_FA + [
        "**اینجا سؤال دو تشخیص هم‌زمان را در نظر دارد، و باید هر دو پوشش داده شوند.**",
        "**سفر به زاهدان یعنی مالاریا در صدر فهرست است.**",
        "**ولی تب، لکوپنی و ترومبوسیتوپنی با تیفوئید هم می‌خواند.**",
        "**و تیفوئید هم در همان مناطق شایع است.**",
        "⚠️ **لام خون محیطی مالاریا را می‌گیرد؛ کشت خون تیفوئید و سایر باکتری‌ها را.**",
        "**تست ویدال آزمون قدیمی و کم‌ارزشی برای تیفوئید است.**",
        "**حساسیت و اختصاصیت پایین دارد و مثبت کاذب فراوان می‌دهد.**",
        "**کشت خون استاندارد طلایی تشخیص تیفوئید است.**",
        "⚠️ **تست رایت برای بروسلوز است، که تابلوی این بیمار را توضیح نمی‌دهد.**",
    ],
    DX_EN + [
        "Here the question has TWO simultaneous diagnoses in mind, and both must be covered.",
        "Travel to Zahedan puts malaria at the head of the list.",
        "But fever with leucopenia and thrombocytopenia also fits typhoid.",
        "And typhoid is common in the same areas.",
        "WARNING, THE BLOOD FILM CATCHES MALARIA; THE BLOOD CULTURE catches typhoid and other bacteria.",
        "The Widal test is an old and low-value test for typhoid.",
        "It has poor sensitivity and specificity and yields many false positives.",
        "BLOOD CULTURE is the gold standard for diagnosing typhoid.",
        "WARNING, THE WRIGHT TEST IS FOR BRUCELLOSIS, which does not explain this patient's picture.",
    ],
    "این سؤال یک نکته‌ی مهم بالینی را می‌سنجد: **گاهی باید دو تشخیص را هم‌زمان دنبال کرد.**\n\n"
    "**بیمار: آقای ۴۰ ساله، راننده کامیون، یک هفته پس از بازگشت از زاهدان، با تب و لرز، "
    "سردرد، تهوع و استفراغ. در معاینه دمای ۴۰، نبض ۱۲۰ و طحال قابل لمس. در آزمایش: لکوپنی و "
    "ترومبوسیتوپنی.**\n\n"
    "**دو تشخیص جدی روی میز است:**\n\n"
    "**یک — مالاریا.** سفر به زاهدان (سیستان و بلوچستان)، تب و لرز، اسپلنومگالی، لکوپنی و "
    "ترومبوسیتوپنی. همه‌چیز می‌خواند.\n\n"
    "**دو — تب تیفوئید.** تب بالا، سردرد، تهوع و استفراغ، اسپلنومگالی، **لکوپنی** (که در "
    "تیفوئید مشخصه است) و ترومبوسیتوپنی. و تیفوئید در همان مناطق **بسیار شایع** است.\n\n"
    "⚠️ **پس اقدام درست باید هر دو را پوشش دهد:**\n\n"
    "**لام خون محیطی** → مالاریا را می‌گیرد.\n\n"
    "**کشت خون** → تیفوئید و سایر باکتریمی‌ها را می‌گیرد.\n\n"
    "**پس گزینه‌ی سوم — لام خونی محیطی و کشت خون — پاسخ است.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**کشت خون و تست رایت:** کشت خون درست است ولی **تست رایت برای بروسلوز** است. بروسلوز "
    "تب مواج و درد مفاصل می‌دهد و **مالاریا را پوشش نمی‌دهد** — در حالی که سفر به زاهدان "
    "مالاریا را در صدر گذاشته.\n\n"
    "⚠️ **لام خونی محیطی و تست ویدال:** لامش درست است ولی **تست ویدال آزمون ضعیفی است**. "
    "حساسیت و اختصاصیت پایین دارد، در مناطق اندمیک **مثبت کاذب فراوان** می‌دهد (به‌دلیل تماس "
    "قبلی)، و در هفته‌ی اول بیماری اغلب منفی است. **کشت خون استاندارد طلایی تیفوئید است**، نه ویدال.\n\n"
    "**کشت خون و تست ویدال:** **لام خون محیطی حذف شده** — یعنی مالاریا، که محتمل‌ترین تشخیص "
    "است، اصلاً بررسی نمی‌شود. و ویدال هم که ارزش کمی دارد.\n\n"
    "**درس این سؤال: وقتی دو تشخیص هم‌زمان محتمل‌اند، آزمونی را انتخاب کنید که هر دو را "
    "پوشش دهد — و همیشه استاندارد طلایی را بر آزمون قدیمی ترجیح دهید.**",
    "This question tests an important clinical point: SOMETIMES TWO DIAGNOSES MUST BE PURSUED AT ONCE.\n\n"
    "THE PATIENT: a 40-year-old lorry driver, one week after returning from Zahedan, with fever and "
    "chills, headache, nausea and vomiting. On examination temperature 40, pulse 120 and a palpable "
    "spleen. Laboratory: leucopenia and thrombocytopenia.\n\n"
    "TWO SERIOUS DIAGNOSES ARE ON THE TABLE:\n\n"
    "ONE — MALARIA. Travel to Zahedan (Sistan and Baluchestan), fever and chills, splenomegaly, "
    "leucopenia and thrombocytopenia. Everything fits.\n\n"
    "TWO — TYPHOID FEVER. High fever, headache, nausea and vomiting, splenomegaly, LEUCOPENIA (which "
    "is characteristic of typhoid) and thrombocytopenia. And typhoid is VERY COMMON in the same areas.\n\n"
    "WARNING, SO THE CORRECT STEP MUST COVER BOTH:\n\n"
    "PERIPHERAL BLOOD FILM -> catches malaria.\n\n"
    "BLOOD CULTURE -> catches typhoid and other bacteraemias.\n\n"
    "SO THE THIRD OPTION — blood film and blood culture — IS THE ANSWER.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "BLOOD CULTURE AND WRIGHT TEST: the culture is right, but THE WRIGHT TEST IS FOR BRUCELLOSIS. "
    "Brucellosis causes undulant fever and joint pain and DOES NOT COVER MALARIA — while the travel to "
    "Zahedan puts malaria at the head of the list.\n\n"
    "WARNING, BLOOD FILM AND WIDAL TEST: the film is right but THE WIDAL TEST IS A WEAK TEST. It has "
    "poor sensitivity and specificity, gives MANY FALSE POSITIVES in endemic areas (from previous "
    "exposure), and is often negative in the first week of illness. BLOOD CULTURE IS THE GOLD STANDARD "
    "FOR TYPHOID, not Widal.\n\n"
    "BLOOD CULTURE AND WIDAL TEST: THE BLOOD FILM IS OMITTED — so malaria, the most likely diagnosis, "
    "is never looked for at all. And Widal adds little.\n\n"
    "THE LESSON: when two diagnoses are simultaneously likely, choose the investigation that covers "
    "both — and always prefer the gold standard over an obsolete test.",
    ["کشت خون درست است ولی تست رایت برای بروسلوز است و مالاریا را پوشش نمی‌دهد.",
     "لام درست است ولی ویدال آزمون ضعیفی است؛ کشت خون استاندارد طلایی تیفوئید است.",
     "پاسخ صحیح — لام مالاریا را می‌گیرد و کشت خون تیفوئید و سایر باکتریمی‌ها را.",
     "لام خون محیطی حذف شده، پس مالاریا که محتمل‌ترین تشخیص است بررسی نمی‌شود."],
    ["The culture is right but the Wright test is for brucellosis and does not cover malaria.",
     "The film is right but Widal is a weak test; blood culture is the gold standard for typhoid.",
     "Correct — the film catches malaria and the blood culture catches typhoid and other bacteraemias.",
     "The blood film is omitted, so malaria, the most likely diagnosis, is never looked for."],
    "**دو تشخیص محتمل، یک انتخاب: آزمونی که هر دو را پوشش دهد.**",
    "Two likely diagnoses, one choice: the investigation that covers both.",
    REFS)

add("book:773", "vignette", "medium",
    "**اسمیر اولیه منفی، شک بالینی بالا: اسمیر را تکرار کنید — منفی بودن یک لام رد نمی‌کند.**",
    "Initial film negative, clinical suspicion high: REPEAT THE FILM — one negative does not exclude.",
    DX_FA + [
        "**این قاعده‌ی «یک لام منفی رد نمی‌کند» را کتاب دو بار پرسیده است.**",
        "**دلیل فیزیولوژیک آن را بدانید، نه فقط قاعده را.**",
        "**پارازیتمی با چرخه‌ی شیزوگونی نوسان می‌کند.**",
        "⚠️ **در فاز سکستراسیون، انگل‌ها در مویرگ‌های عمقی‌اند و در خون محیطی کم دیده می‌شوند.**",
        "**پس نمونه‌گیری در زمان نامناسب می‌تواند منفی بدهد.**",
        "**و در فالسیپاروم این نوسان چشمگیرتر است، چون سکستراسیون بیشتری دارد.**",
        "**تشنج در این بیمار یعنی احتمال مالاریای مغزی — پس فوریت بالاست.**",
        "**و نبود علائم تحریک مننژ، مننژیت را کم‌احتمال می‌کند.**",
    ],
    DX_EN + [
        "The book asks this 'one negative film does not exclude' rule twice.",
        "Know its physiological reason, not just the rule.",
        "Parasitaemia fluctuates with the schizogony cycle.",
        "WARNING, DURING SEQUESTRATION the parasites are in deep capillaries and are scarce peripherally.",
        "So sampling at the wrong moment can give a negative result.",
        "And in falciparum this fluctuation is more marked, because it sequesters more.",
        "The seizure in this patient raises cerebral malaria — so the urgency is high.",
        "And the absence of meningeal signs makes meningitis unlikely.",
    ],
    "این سؤال یکی از **پرارزش‌ترین قواعد** بلوک مالاریا را می‌سنجد.\n\n"
    "**بیمار: پس از بازگشت از ایرانشهر، تب ۴۰ درجه با لرز، میالژی، سردرد شدید و تشنج. آنمیک "
    "است و علائم تحریک مننژ ندارد. اسمیر اولیه‌ی خون محیطی منفی گزارش شده.**\n\n"
    "**وسوسه‌ی طبیعی: «لام منفی است، پس مالاریا نیست.» و این دقیقاً همان اشتباهی است که "
    "می‌تواند بیمار را بکشد.**\n\n"
    "⚠️ **قاعده: یک لام منفی، مالاریا را رد نمی‌کند.**\n\n"
    "**چرا؟ دلیل فیزیولوژیک را بدانید:**\n\n"
    "**پارازیتمی با چرخه‌ی شیزوگونی نوسان می‌کند.** انگل در بخشی از چرخه‌ی خود در **مویرگ‌های "
    "عمقی سکستره می‌شود** (به‌ویژه فالسیپاروم) و در آن فاز، تعداد انگل در **خون محیطی** بسیار "
    "کم می‌شود. اگر نمونه‌گیری دقیقاً در همان زمان انجام شود، لام می‌تواند **منفی کاذب** بدهد.\n\n"
    "**پس در شک بالینی قوی چه می‌کنیم؟ لام را تکرار می‌کنیم — هر ۱۲ تا ۲۴ ساعت، برای سه روز.**\n\n"
    "**و شک بالینی اینجا واقعاً قوی است:** سفر به **ایرانشهر** (سیستان و بلوچستان)، تب ۴۰ "
    "با لرز، میالژی، **آنمی**، و **تشنج** که مالاریای مغزی را مطرح می‌کند.\n\n"
    "**پس پاسخ: اسمیر مجدد خون.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**گرفتن مایع نخاع:** سؤال صریحاً گفته **علائم تحریک مننژ ندارد**. و در بیمار با احتمال "
    "مالاریای مغزی، LP پیش از رد کردن مالاریا منطقی نیست. LP اقدام تهاجمی است و باید "
    "اندیکاسیون داشته باشد.\n\n"
    "**سی‌تی‌اسکن مغز:** تشنج را بررسی می‌کند ولی **علت زمینه‌ای را پیدا نمی‌کند**. در مالاریای "
    "مغزی، سی‌تی معمولاً طبیعی یا فقط ادم منتشر نشان می‌دهد. **وقت را تلف می‌کند.**\n\n"
    "⚠️ **کشت خون:** **مالاریا در کشت رشد نمی‌کند.** کشت خون برای باکتریمی است، نه انگل.\n\n"
    "**نکته‌ی بالینی مهم که سؤال نپرسیده:** اگر شک بسیار قوی باشد و بیمار بدحال، **درمان "
    "حدسی هم‌زمان با تکرار لام** شروع می‌شود. در مالاریای شدید، تأخیر درمان مرگ‌آور است.",
    "This question tests one of the MOST VALUABLE RULES in the malaria block.\n\n"
    "THE PATIENT: after returning from Iranshahr, a fever of 40 with chills, myalgia, severe headache "
    "and a seizure. He is anaemic and has no meningeal signs. The initial blood film is reported negative.\n\n"
    "THE NATURAL TEMPTATION: 'the film is negative, so it is not malaria.' And that is precisely the "
    "mistake that can kill the patient.\n\n"
    "WARNING, THE RULE: ONE NEGATIVE FILM DOES NOT EXCLUDE MALARIA.\n\n"
    "WHY? KNOW THE PHYSIOLOGICAL REASON:\n\n"
    "PARASITAEMIA FLUCTUATES WITH THE SCHIZOGONY CYCLE. For part of its cycle the parasite is "
    "SEQUESTERED IN DEEP CAPILLARIES (especially falciparum), and in that phase the number of "
    "parasites in PERIPHERAL blood falls sharply. If the sample is taken at exactly that moment the "
    "film can be A FALSE NEGATIVE.\n\n"
    "SO WHAT DO WE DO WHEN SUSPICION IS STRONG? WE REPEAT THE FILM — every 12 to 24 hours for three days.\n\n"
    "AND THE SUSPICION HERE IS GENUINELY STRONG: travel to IRANSHAHR (Sistan and Baluchestan), a fever "
    "of 40 with chills, myalgia, ANAEMIA, and A SEIZURE raising cerebral malaria.\n\n"
    "SO THE ANSWER: REPEAT THE BLOOD FILM.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "LUMBAR PUNCTURE: the question states explicitly that there are NO MENINGEAL SIGNS. And in a "
    "patient with possible cerebral malaria, an LP before excluding malaria is not sensible. An LP is "
    "invasive and must be indicated.\n\n"
    "BRAIN CT: it investigates the seizure but DOES NOT FIND THE UNDERLYING CAUSE. In cerebral malaria "
    "the CT is usually normal or shows only diffuse oedema. IT WASTES TIME.\n\n"
    "WARNING, BLOOD CULTURE: MALARIA DOES NOT GROW IN CULTURE. Blood culture is for bacteraemia, not "
    "for a parasite.\n\n"
    "AN IMPORTANT CLINICAL POINT THE QUESTION DID NOT ASK: if suspicion is very strong and the patient "
    "is ill, EMPIRICAL TREATMENT IS STARTED ALONGSIDE THE REPEAT FILM. In severe malaria, delay is fatal.",
    ["سؤال صریحاً گفته علائم تحریک مننژ ندارد؛ LP بدون اندیکاسیون و پیش از رد مالاریا منطقی نیست.",
     "پاسخ صحیح — پارازیتمی نوسان دارد، پس یک لام منفی مالاریا را رد نمی‌کند.",
     "سی‌تی در مالاریای مغزی معمولاً طبیعی است و فقط وقت را تلف می‌کند.",
     "مالاریا در کشت رشد نمی‌کند؛ کشت خون برای باکتریمی است نه انگل."],
    ["The question states there are no meningeal signs; an LP unindicated and before excluding malaria is not sensible.",
     "Correct — parasitaemia fluctuates, so one negative film does not exclude malaria.",
     "CT is usually normal in cerebral malaria and merely wastes time.",
     "Malaria does not grow in culture; blood culture is for bacteraemia, not a parasite."],
    "**پارازیتمی نوسان می‌کند — پس لام منفی یعنی «دوباره بگیر»، نه «مالاریا نیست».**",
    "Parasitaemia fluctuates — so a negative film means 'take another', not 'not malaria'.",
    REFS)

add("book:774", "vignette", "medium",
    "**گستره‌ی ضخیم و نازک منفی با شک قوی: تکرار هر ۱۲ تا ۲۴ ساعت برای سه روز.**",
    "Thick and thin films negative with strong suspicion: repeat every 12 to 24 hours for three days.",
    DX_FA + [
        "**این سؤال همان قاعده است، ولی این بار عدد دقیق را می‌خواهد.**",
        "**فاصله‌ی تکرار: هر ۱۲ تا ۲۴ ساعت.**",
        "**مدت پیگیری: سه روز.**",
        "⚠️ **چرا ۱۲ تا ۲۴ ساعت و نه هر دو ساعت؟ چون چرخه‌ی شیزوگونی طولانی‌تر است.**",
        "**چرخه‌ی فالسیپاروم و ویواکس حدود ۴۸ ساعت است.**",
        "**پس نمونه‌گیری هر دو ساعت، همان فاز چرخه را دوباره می‌بیند و چیزی اضافه نمی‌کند.**",
        "**در حالی که فاصله‌ی ۱۲ تا ۲۴ ساعت، فازهای متفاوت چرخه را پوشش می‌دهد.**",
        "**و چرا سه روز؟ چون در این مدت چند چرخه‌ی کامل نمونه‌برداری می‌شود.**",
        "⚠️ **و اگر پس از سه روز همه منفی بود، آنگاه می‌توان مالاریا را کنار گذاشت.**",
    ],
    DX_EN + [
        "This question is the same rule, but this time it wants the exact number.",
        "REPEAT INTERVAL: every 12 to 24 hours.",
        "DURATION: three days.",
        "WARNING, WHY 12 TO 24 HOURS AND NOT EVERY TWO HOURS? Because the schizogony cycle is longer.",
        "The falciparum and vivax cycle is about 48 hours.",
        "So sampling every two hours sees the same phase of the cycle again and adds nothing.",
        "Whereas a 12 to 24 hour interval covers different phases of the cycle.",
        "And why three days? Because several complete cycles are sampled in that time.",
        "WARNING, AND IF ALL ARE NEGATIVE AFTER THREE DAYS, malaria can then be set aside.",
    ],
    "این سؤال همان قاعده‌ی قبلی است، ولی **این بار عدد دقیق را می‌خواهد** — و کتاب دو عدد "
    "اشتباه را هم به‌عنوان تله گذاشته.\n\n"
    "**بیمار: پسر جوان سرباز در ایرانشهر، تب و لرز تکان‌دهنده از سه روز پیش، با آنمی و افت "
    "پلاکت خفیف. گستره‌ی ضخیم و نازک درخواست شده و منفی گزارش شده. شک بالینی همچنان قوی است.**\n\n"
    "⚠️ **پاسخ: تکرار لام خون محیطی هر ۱۲ تا ۲۴ ساعت، برای سه روز.**\n\n"
    "**حالا چرا دقیقاً این اعداد؟ منطق را بدانید تا نیازی به حفظ کردن نداشته باشید:**\n\n"
    "**چرا تکرار؟** چون پارازیتمی با **چرخه‌ی شیزوگونی** نوسان می‌کند و در فاز سکستراسیون، "
    "انگل در خون محیطی کم دیده می‌شود.\n\n"
    "**چرا هر ۱۲ تا ۲۴ ساعت و نه هر ۲ ساعت؟** چون **چرخه‌ی شیزوگونی فالسیپاروم و ویواکس "
    "حدود ۴۸ ساعت** است. نمونه‌گیری هر دو ساعت عملاً **همان فاز چرخه** را دوباره می‌بیند و "
    "اطلاعات جدیدی نمی‌دهد — فقط بیمار را آزار می‌دهد و منابع آزمایشگاه را هدر می‌دهد. "
    "فاصله‌ی **۱۲ تا ۲۴ ساعت** تضمین می‌کند که **فازهای متفاوت چرخه** را ببینیم.\n\n"
    "**چرا سه روز؟** چون در سه روز، **چند چرخه‌ی کامل** نمونه‌برداری می‌شود. اگر پس از آن "
    "همه منفی بود، می‌توان با اطمینان معقول مالاریا را کنار گذاشت.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "⚠️ **«با توجه به منفی بودن لام، مالاریا بعید است»:** این **خطرناک‌ترین گزینه** است و "
    "دقیقاً همان اشتباهی که این سؤال برای شناساندنش طراحی شده. **یک لام منفی مالاریا را رد "
    "نمی‌کند.**\n\n"
    "**«درمان حدسی و پیگیری بالینی»:** در بیمار **بدحال یا با مالاریای شدید** این کار درست "
    "است. ولی این بیمار **پایدار** است (فقط آنمی و افت پلاکت خفیف). وقتی تشخیص در دسترس است، "
    "**اول تشخیص بگذارید، بعد درمان کنید** — درمان حدسی بی‌مورد یعنی مواجهه با عوارض دارویی "
    "و پنهان شدن تشخیص واقعی.\n\n"
    "**«تکرار لام هر ۲ ساعت تا ۱۲ ساعت»:** فاصله بیش‌ازحد کوتاه و مدت بیش‌ازحد کوتاه است. "
    "همان‌طور که گفتیم، هر دو ساعت همان فاز چرخه را می‌بیند، و ۱۲ ساعت حتی یک چرخه‌ی کامل "
    "هم نیست.",
    "This question is the same rule as before, but THIS TIME IT WANTS THE EXACT NUMBERS — and the book "
    "has planted two wrong numbers as traps.\n\n"
    "THE PATIENT: a young conscript in Iranshahr, three days of fever and shaking chills, with anaemia "
    "and a mild fall in platelets. Thick and thin films were requested and reported negative. Clinical "
    "suspicion remains strong.\n\n"
    "WARNING, THE ANSWER: REPEAT THE FILM EVERY 12 TO 24 HOURS FOR THREE DAYS.\n\n"
    "NOW WHY EXACTLY THOSE NUMBERS? Know the logic and you will not need to memorise them:\n\n"
    "WHY REPEAT? Because parasitaemia fluctuates with the SCHIZOGONY CYCLE, and during sequestration "
    "the parasite is scarce in peripheral blood.\n\n"
    "WHY EVERY 12 TO 24 HOURS AND NOT EVERY 2 HOURS? Because THE FALCIPARUM AND VIVAX SCHIZOGONY CYCLE "
    "IS ABOUT 48 HOURS. Sampling every two hours effectively sees THE SAME PHASE of the cycle again and "
    "adds nothing — it merely distresses the patient and wastes laboratory resources. A 12 TO 24 HOUR "
    "interval guarantees that DIFFERENT PHASES of the cycle are examined.\n\n"
    "WHY THREE DAYS? Because in three days SEVERAL COMPLETE CYCLES are sampled. If all are negative "
    "after that, malaria can be set aside with reasonable confidence.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "WARNING, 'GIVEN THE NEGATIVE FILM, MALARIA IS UNLIKELY': this is THE MOST DANGEROUS OPTION and "
    "precisely the mistake this question was designed to expose. ONE NEGATIVE FILM DOES NOT EXCLUDE "
    "MALARIA.\n\n"
    "'EMPIRICAL TREATMENT AND CLINICAL FOLLOW-UP': in a CRITICALLY ILL patient or one with SEVERE "
    "malaria this is correct. But this patient is STABLE (only anaemia and a mild platelet fall). When "
    "the diagnosis is obtainable, MAKE THE DIAGNOSIS FIRST AND THEN TREAT — unnecessary empirical "
    "treatment means drug toxicity and a masked true diagnosis.\n\n"
    "'REPEAT THE FILM EVERY 2 HOURS FOR 12 HOURS': the interval is far too short and the duration far "
    "too short. As explained, every two hours sees the same phase, and 12 hours is not even one "
    "complete cycle.",
    ["پاسخ صحیح — فاصله‌ی ۱۲ تا ۲۴ ساعت فازهای متفاوت چرخه را پوشش می‌دهد، و سه روز چند چرخه را.",
     "خطرناک‌ترین گزینه — یک لام منفی هرگز مالاریا را رد نمی‌کند.",
     "در بیمار پایدار، اول تشخیص بگذارید؛ درمان حدسی بی‌مورد تشخیص واقعی را پنهان می‌کند.",
     "هر دو ساعت همان فاز چرخه را می‌بیند، و ۱۲ ساعت حتی یک چرخه‌ی کامل هم نیست."],
    ["Correct — a 12 to 24 hour interval covers different phases of the cycle, and three days covers several.",
     "The most dangerous option — one negative film never excludes malaria.",
     "In a stable patient, make the diagnosis first; needless empirical treatment masks the true diagnosis.",
     "Every two hours sees the same phase, and 12 hours is not even one complete cycle."],
    "**هر ۱۲ تا ۲۴ ساعت، سه روز — چون چرخه‌ی شیزوگونی ۴۸ ساعت است.**",
    "Every 12 to 24 hours for three days — because the schizogony cycle is 48 hours.",
    REFS)

json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book43.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 43 lessons:', len(L))
