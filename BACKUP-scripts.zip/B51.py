# -*- coding: utf-8 -*-
"""Micro-lessons, batch 51 — tuberculosis part one: who progresses, primary
versus post-primary disease, and the extrapulmonary forms (pleura, lymph node,
genitourinary tract, brain).

THE ONE IDEA THAT ORGANISES THE WHOLE CHAPTER
----------------------------------------------
About a QUARTER of the world carries latent tuberculosis. Only about 10 % of
them will ever develop disease, and HALF of that 10 % does so in the first two
years after infection. So every question in this chapter is really asking one
of two things:

    who moves from LATENT to ACTIVE?      (immunity questions)
    and how do we prove it once they do?  (diagnosis questions)

THE RISK LADDER, WHICH DECIDES SEVERAL QUESTIONS AT ONCE
---------------------------------------------------------
Ranked by the size of the risk, not by how common the condition is:

    HIV, untreated          ~10 % PER YEAR — the single largest risk known
    recent infection (<2 yr)  ~5 % in the first 2 years
    silicosis                 ~30-fold
    transplant, TNF-alpha blockers, dialysis, prolonged steroids  high
    injecting drug use        ~10- to 30-fold (and higher again with HIV)
    diabetes                  ~2- to 4-fold
    chronic hepatitis B       NOT a recognised risk factor for progression

That last line is what one question turns on: hepatitis B damages the liver,
which MATTERS ENORMOUSLY for antituberculous DRUGS, but it does not weaken the
T-cell immunity that keeps a granuloma sealed.

WHY HIV IS DIFFERENT IN KIND, NOT ONLY IN DEGREE
--------------------------------------------------
Containment of Mycobacterium tuberculosis is the job of CD4 T cells and the
macrophages they activate. HIV destroys exactly that cell. This single fact
explains four separate exam findings:

    the risk of reactivation becomes ~10 % per year rather than per lifetime
    the tuberculin skin test tends to be NEGATIVE (anergy) even when infected
    the chest film loses its classic upper-lobe cavitary look and becomes
        lower-zone, diffuse, or normal, because cavitation is an immune act
    MYCOBACTERAEMIA becomes possible — the blood culture may grow the organism

PRIMARY VERSUS POST-PRIMARY, THE DIVISION BEHIND TWO QUESTIONS
----------------------------------------------------------------
    PRIMARY TB — first encounter, no prior immunity
        MIDDLE and LOWER zones (where ventilation is greatest, so that is
            where the inhaled droplet nucleus lands)
        HILAR and paratracheal LYMPHADENOPATHY — the hallmark
        pleural effusion and pleural reaction
        hypersensitivity phenomena: ERYTHEMA NODOSUM and PHLYCTENULAR
            CONJUNCTIVITIS
        usually self-limited in the immunocompetent

    POST-PRIMARY (reactivation) TB
        APICAL and POSTERIOR SEGMENTS of the upper lobes, and the superior
            segment of the lower lobe — the highest oxygen tension in the lung
        CAVITATION, fibrosis, volume loss
        adenopathy is uncommon
        chronic cough, haemoptysis, night sweats, weight loss

THE TUBERCULOUS PLEURAL EFFUSION, ASKED THREE TIMES
-----------------------------------------------------
The fluid is an EXUDATE with LYMPHOCYTE PREDOMINANCE, a LOW GLUCOSE, a high
protein and a high ADA. The trap is the yield:

    smear of pleural fluid     under 10 % — nearly useless alone
    culture of pleural fluid   about 25-40 %
    PLEURAL BIOPSY             about 70-80 %, and higher still when the
                               histology (caseating granuloma) is counted
                               with the culture of the biopsy specimen

The reason is mechanistic and worth learning once: a tuberculous effusion is a
HYPERSENSITIVITY REACTION to a few organisms in the pleural space, not a pus
collection. There are very few bacilli in the fluid and most of them are IN
THE PLEURA itself. That is why you must sample the membrane, not the liquid.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022) —
tuberculosis; WHO consolidated guidelines on tuberculosis.
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — tuberculosis")
WHO = ("WHO consolidated guidelines on tuberculosis, Module 2: Screening and "
       "Module 4: Treatment (2021-2022)")
REFS = [H]
REFSW = [H, WHO]

# ==================================================== RISK OF PROGRESSION
RISK_FA = [
    "**حدود یک‌چهارم جمعیت جهان سل نهفته دارد، ولی فقط حدود ۱۰٪ آن‌ها بیمار می‌شوند.**",
    "**و نیمی از همان ۱۰٪، در دو سال نخست پس از عفونت بیمار می‌شوند.**",
    "⚠️ **پس سؤال همیشه این است: چه چیزی گرانولوم بسته را باز می‌کند؟**",
    "**نگهبان گرانولوم، لنفوسیت CD4 و ماکروفاژی است که آن را فعال می‌کند.**",
    "**پس هر چیزی که ایمنی سلولی را بزند، بزرگ‌ترین خطر است.**",
    "⚠️ **HIV در صدر مطلق است: خطر فعال شدن حدود ۱۰٪ در هر سال، نه در تمام عمر.**",
    "**چون HIV دقیقاً همان سلول CD4 نگهبان را نابود می‌کند.**",
    "**بعد از آن: سیلیکوز، پیوند عضو، مهارکننده‌های TNF-α، دیالیز، کورتون طولانی.**",
    "**اعتیاد تزریقی هم خطر را ۱۰ تا ۳۰ برابر می‌کند، ولی نه در حد HIV.**",
    "**دیابت خطر را ۲ تا ۴ برابر می‌کند — واقعی، ولی کوچک در برابر HIV.**",
    "⚠️ **و هپاتیت B مزمن جزو عوامل خطر پیشرفت نیست.**",
    "**چون کبد را می‌زند، نه ایمنی سلولی را — اهمیتش در سمّیت داروهاست، نه در فعال‌شدن سل.**",
]
RISK_EN = [
    "About a QUARTER of the world has latent tuberculosis, but only about 10 % of them ever fall ill.",
    "And HALF of that 10 % falls ill within the first two years after infection.",
    "WARNING: SO THE QUESTION IS ALWAYS THE SAME — what opens a sealed granuloma?",
    "The guard of the granuloma is the CD4 lymphocyte and the macrophage it activates.",
    "So anything that strikes CELL-MEDIATED IMMUNITY is the greatest risk.",
    "WARNING: HIV IS ABSOLUTELY FIRST — the risk of reactivation is about 10 % PER YEAR, not per lifetime.",
    "Because HIV destroys precisely the CD4 cell that stands guard.",
    "After it: silicosis, organ transplant, TNF-alpha blockers, dialysis, prolonged corticosteroids.",
    "Injecting drug use raises the risk 10- to 30-fold, but not to the level of HIV.",
    "Diabetes raises it 2- to 4-fold — real, but small beside HIV.",
    "WARNING, AND CHRONIC HEPATITIS B IS NOT A RISK FACTOR FOR PROGRESSION AT ALL.",
    "Because it strikes the liver, not cell-mediated immunity — it matters for DRUG TOXICITY, not for reactivation.",
]

add("book:205", "recall", "medium",
    "**بزرگ‌ترین عامل خطر تبدیل سل نهفته به سل فعال، عفونت HIV است.**",
    "The single greatest risk factor for latent tuberculosis becoming active disease is HIV infection.",
    RISK_FA, RISK_EN,
    "سؤال چهار وضعیت را کنار هم گذاشته و می‌خواهد بدانید کدام‌یک بیشترین شانس فعال شدن سل نهفته را می‌سازد.\n\n"
    "**ابتدا مکانیسم را بفهمید، بعد گزینه‌ها خودشان مرتب می‌شوند.**\n\n"
    "**سل نهفته یعنی باسیل زنده ولی محبوس، درون گرانولوم.** دیوار این زندان را "
    "**لنفوسیت‌های CD4** می‌سازند: آن‌ها اینترفرون گاما ترشح می‌کنند، ماکروفاژ را فعال "
    "می‌کنند، و ماکروفاژ فعال باسیل را در بند نگه می‌دارد.\n\n"
    "⚠️ **پس هر بیماری‌ای که CD4 را بزند، مستقیماً دیوار زندان را خراب می‌کند.**\n\n"
    "**و HIV دقیقاً همین کار را می‌کند** — ویروسی که سلول هدفش همان CD4 است.\n\n"
    "**نتیجه در عدد:** در فرد سالمِ مبتلا به سل نهفته، خطر بیمار شدن حدود **۱۰٪ در "
    "تمام طول عمر** است. در فرد HIV مثبتِ درمان‌نشده، همان خطر **حدود ۱۰٪ در هر سال** "
    "می‌شود. یعنی تقریباً **ده برابر شدن سالانه**.\n\n"
    "**چرا سه گزینه‌ی دیگر پاسخ نیستند؟**\n\n"
    "**معتادان تزریقی** — خطرشان واقعاً بالاست (۱۰ تا ۳۰ برابر)، ولی بخش بزرگی از آن "
    "به **شرایط زندگی، ازدحام، زندان و همراهی با HIV** برمی‌گردد، نه به یک نقص ایمنی "
    "مستقیم و مشخص. در برابر ۱۰٪ سالانه‌ی HIV کوچک است.\n\n"
    "⚠️ **هپاتیت B مزمن** — گزینه‌ی فریبنده‌ی این سؤال. هپاتیت مزمن **کبد** را درگیر "
    "می‌کند، نه ایمنی سلولی را. **هیچ نقشی در تبدیل سل نهفته به فعال ندارد.** اهمیت "
    "بالینی‌اش جای دیگری است: در بیمار مبتلا به سل، هپاتیت زمینه‌ای **خطر سمیت کبدی "
    "ایزونیازید، ریفامپین و پیرازینامید** را بالا می‌برد. یعنی روی **درمان** اثر دارد، "
    "نه روی **فعال شدن**.\n\n"
    "**دیابت قندی** — عامل خطر واقعی است و در ایران بسیار شایع، ولی بزرگی‌اش **۲ تا ۴ "
    "برابر** است. یعنی اهمیت جمعیتی بالا (چون دیابت شایع است) ولی خطر فردی کوچک در "
    "برابر HIV.\n\n"
    "**درس روش‌شناختی: در سؤال «بیشترین خطر»، اندازه‌ی خطر را مقایسه کنید، نه شیوع "
    "بیماری زمینه‌ای را.**",
    "The question puts four conditions side by side and asks which gives the greatest chance that latent tuberculosis becomes active disease.\n\n"
    "UNDERSTAND THE MECHANISM FIRST AND THE OPTIONS SORT THEMSELVES.\n\n"
    "LATENT TUBERCULOSIS MEANS LIVING BUT IMPRISONED BACILLI inside a granuloma. The walls of that prison are built by CD4 LYMPHOCYTES: they secrete interferon gamma, they activate the macrophage, and the activated macrophage keeps the bacillus confined.\n\n"
    "WARNING: SO ANY DISEASE THAT STRIKES CD4 CELLS DEMOLISHES THE PRISON WALL DIRECTLY.\n\n"
    "AND HIV DOES EXACTLY THAT — a virus whose target cell is the CD4 lymphocyte itself.\n\n"
    "THE RESULT IN NUMBERS: in a healthy person with latent tuberculosis the lifetime risk of disease is about 10 %. In an untreated HIV-positive person the same risk becomes ABOUT 10 % PER YEAR — roughly a tenfold annual multiplication.\n\n"
    "WHY ARE THE OTHER THREE NOT THE ANSWER?\n\n"
    "INJECTING DRUG USE — genuinely high risk (10- to 30-fold), but much of that comes from LIVING CONDITIONS, CROWDING, IMPRISONMENT AND CO-EXISTING HIV rather than from a direct, defined immune defect. Beside 10 % per year it is small.\n\n"
    "WARNING, CHRONIC HEPATITIS B — the seductive option here. Chronic hepatitis involves THE LIVER, not cell-mediated immunity. IT PLAYS NO PART IN CONVERTING LATENT TO ACTIVE TUBERCULOSIS. Its clinical importance lies elsewhere: in a patient with tuberculosis, underlying hepatitis raises THE RISK OF HEPATOTOXICITY FROM ISONIAZID, RIFAMPICIN AND PYRAZINAMIDE. It affects TREATMENT, not REACTIVATION.\n\n"
    "DIABETES MELLITUS — a real risk factor and very common in Iran, but its magnitude is 2- TO 4-FOLD. High population importance because diabetes is common; small individual risk beside HIV.\n\n"
    "THE METHODOLOGICAL LESSON: in a 'greatest risk' question, compare THE SIZE OF THE RISK, not the prevalence of the underlying condition.",
    ["پاسخ صحیح — HIV همان سلول CD4 نگهبان گرانولوم را نابود می‌کند؛ خطر ۱۰٪ در هر سال.",
     "خطر ۱۰ تا ۳۰ برابر دارد ولی عمدتاً از راه شرایط زندگی و همراهی با HIV، نه نقص ایمنی مستقیم.",
     "کبد را درگیر می‌کند نه ایمنی سلولی؛ روی سمّیت داروها اثر دارد نه روی فعال شدن سل.",
     "عامل خطر واقعی ولی فقط ۲ تا ۴ برابر — بسیار کوچک‌تر از HIV."],
    ["Correct — HIV destroys the very CD4 cell that guards the granuloma; risk becomes 10 % per year.",
     "A 10- to 30-fold risk, but largely through living conditions and co-existing HIV, not a direct immune defect.",
     "It involves the liver, not cell-mediated immunity; it affects drug toxicity, not reactivation.",
     "A real risk factor but only 2- to 4-fold — far smaller than HIV."],
    "**نگهبان سل نهفته CD4 است؛ هر چه CD4 را بزند، بزرگ‌ترین خطر است.**",
    "The guard of latent tuberculosis is the CD4 cell; whatever strikes CD4 is the greatest risk.",
    REFS)

# ==================================================== NATIONAL SCREENING CRITERIA
SCREEN_FA = [
    "**راهنمای کشوری سل، «فرد مشکوک به سل» را با نشانه‌های مشخصی تعریف می‌کند.**",
    "⚠️ **نشانه‌ی کلیدی و الزامی: سرفه‌ی بیش از دو هفته.**",
    "**و کنار آن، نشانه‌های حمایتی شمرده می‌شوند.**",
    "**خلط خونی (هموپتیزی) — نشانه‌ی کلاسیک درگیری کاویتری.**",
    "**کاهش وزن بدون علت.**",
    "**بی‌اشتهایی.**",
    "**تب و تعریق شبانه.**",
    "**درد قفسه‌ی سینه و تنگی نفس.**",
    "**خستگی و ضعف عمومی.**",
    "⚠️ **اما یافته‌های غیراختصاصی جزو این فهرست نیستند.**",
    "**تندرنس فلانک، رال پراکنده، و اختلال تمرکز، نشانه‌ی سل نیستند.**",
    "**درس: در سؤال «چند تا از نشانه‌ها را دارد»، فقط اقلام فهرست را بشمارید.**",
]
SCREEN_EN = [
    "The national tuberculosis guideline defines a 'presumptive TB case' by a specific list of features.",
    "WARNING: THE KEY AND MANDATORY FEATURE IS A COUGH LASTING MORE THAN TWO WEEKS.",
    "And alongside it a set of supporting features is counted.",
    "HAEMOPTYSIS (blood-streaked sputum) — the classic marker of cavitary disease.",
    "Unexplained WEIGHT LOSS.",
    "ANOREXIA.",
    "FEVER and NIGHT SWEATS.",
    "CHEST PAIN and breathlessness.",
    "FATIGUE and general weakness.",
    "WARNING, BUT NON-SPECIFIC FINDINGS ARE NOT ON THAT LIST.",
    "Flank tenderness, scattered crackles and poor concentration are not features of tuberculosis.",
    "The lesson: in a 'how many of the features does he have' question, count ONLY the items on the list.",
]

add("book:206", "recall", "medium",
    "**چهار نشانه: سرفه‌ی طولانی، خلط خونی، کاهش وزن، و بی‌اشتهایی.**",
    "Four features: prolonged cough, haemoptysis, weight loss and anorexia.",
    SCREEN_FA, SCREEN_EN,
    "این سؤال یک تمرین شمارش دقیق است، و دقیقاً همان مهارتی را می‌سنجد که در برنامه‌ی "
    "کشوری سل لازم دارید.\n\n"
    "**بیمار: مرد ۳۵ ساله با سرفه از یک ماه قبل، یک نوبت خلط خونی، کاهش وزن، کاهش "
    "اشتها، بی‌حوصلگی و از دست دادن تمرکز. در معاینه تندرنس فلانک و رال پراکنده.**\n\n"
    "**حالا فهرست راهنمای کشوری را روی بیمار بگذارید:**\n\n"
    "**۱. سرفه‌ی بیش از دو هفته** ✔ — یک ماه است، پس واجد شرط.\n\n"
    "**۲. خلط خونی** ✔ — یک نوبت هم کافی است؛ هموپتیزی هر مقدار که باشد نشانه است.\n\n"
    "**۳. کاهش وزن** ✔ — صراحتاً ذکر شده.\n\n"
    "**۴. بی‌اشتهایی** ✔ — صراحتاً ذکر شده.\n\n"
    "**جمع: چهار نشانه.**\n\n"
    "⚠️ **حالا مهم‌ترین بخش: چه چیزهایی را نباید بشمارید؟**\n\n"
    "**بی‌حوصلگی و از دست دادن تمرکز** — این‌ها نشانه‌های عمومی بیماری مزمن‌اند و در "
    "افسردگی، کم‌خونی، کم‌کاری تیروئید و ده‌ها حالت دیگر هم دیده می‌شوند. **در فهرست "
    "غربالگری سل نیستند.**\n\n"
    "**تندرنس فلانک** — یافته‌ی معاینه‌ای است و به کلیه اشاره دارد، نه ریه. **جزو "
    "نشانه‌های غربالگری نیست.**\n\n"
    "**رال پراکنده** — یافته‌ی سمعی و کاملاً غیراختصاصی است. در سل ریوی سمع ریه اغلب "
    "**به‌طرز گمراه‌کننده‌ای طبیعی** است، حتی وقتی رادیوگرافی کاویته نشان می‌دهد. این "
    "تضاد بین سمع فقیر و گرافی پرمحتوا، خودش یکی از ویژگی‌های شناخته‌شده‌ی سل است.\n\n"
    "**درس روش‌شناختی: فهرست غربالگری از نشانه‌های ذهنی بیمار (symptom) ساخته شده، نه "
    "از یافته‌های معاینه (sign). این تفکیک، پاسخ را می‌سازد.**",
    "This question is an exercise in careful counting, and it tests exactly the skill the national tuberculosis programme requires.\n\n"
    "THE PATIENT: a 35-year-old man with cough for one month, one episode of blood-streaked sputum, weight loss, loss of appetite, low mood and poor concentration. On examination, flank tenderness and scattered crackles.\n\n"
    "NOW LAY THE NATIONAL GUIDELINE'S LIST OVER THE PATIENT:\n\n"
    "1. COUGH LASTING MORE THAN TWO WEEKS — one month, so it qualifies.\n\n"
    "2. HAEMOPTYSIS — a single episode is enough; any amount of blood counts.\n\n"
    "3. WEIGHT LOSS — explicitly stated.\n\n"
    "4. ANOREXIA — explicitly stated.\n\n"
    "TOTAL: FOUR FEATURES.\n\n"
    "WARNING, NOW THE IMPORTANT PART: WHAT MUST NOT BE COUNTED?\n\n"
    "LOW MOOD AND POOR CONCENTRATION — these are the general features of any chronic illness and occur in depression, anaemia, hypothyroidism and dozens of other states. THEY ARE NOT ON THE TUBERCULOSIS SCREENING LIST.\n\n"
    "FLANK TENDERNESS — an examination finding pointing at the kidney, not the lung. NOT A SCREENING FEATURE.\n\n"
    "SCATTERED CRACKLES — an auscultatory finding and entirely non-specific. In pulmonary tuberculosis the chest is often MISLEADINGLY NORMAL ON AUSCULTATION even when the radiograph shows a cavity. That contrast between a poor examination and a rich film is itself a recognised characteristic of the disease.\n\n"
    "THE METHODOLOGICAL LESSON: the screening list is built from the patient's SYMPTOMS, not from examination SIGNS. That distinction produces the answer.",
    ["کمتر از تعداد واقعی است؛ چهار نشانه‌ی فهرست‌شده در بیمار وجود دارد.",
     "پاسخ صحیح — سرفه‌ی بیش از دو هفته، خلط خونی، کاهش وزن و بی‌اشتهایی.",
     "بیش از تعداد واقعی؛ بی‌حوصلگی جزو فهرست غربالگری نیست.",
     "بسیار بیشتر از واقع؛ یافته‌های معاینه مانند رال و تندرنس فلانک شمرده نمی‌شوند."],
    ["Fewer than the true number; four listed features are present.",
     "Correct — cough over two weeks, haemoptysis, weight loss and anorexia.",
     "More than the true number; low mood is not on the screening list.",
     "Far more than the truth; examination findings such as crackles and flank tenderness do not count."],
    "**فهرست غربالگری از نشانه‌های بیمار ساخته شده، نه از یافته‌های معاینه.**",
    "The screening list is built from the patient's symptoms, not from examination findings.",
    REFSW)

# ==================================================== PRIMARY VS POST-PRIMARY
PRIM_FA = [
    "⚠️ **سل اولیه و سل ثانویه دو تابلوی رادیولوژیک کاملاً متفاوت‌اند.**",
    "**سل اولیه = نخستین برخورد، بدون ایمنی قبلی.**",
    "**محل: لوب میانی و تحتانی — جایی که تهویه بیشترین است و قطرک آنجا می‌نشیند.**",
    "⚠️ **مشخصه‌ی اصلی: آدنوپاتی ناف ریه و پاراتراکئال.**",
    "**به‌علاوه: پلورال افیوژن و واکنش پلور.**",
    "**و پدیده‌های ازدیاد حساسیت: اریتم ندوزوم و کونژنکتیویت فلیکتنولار.**",
    "**در فرد سالم معمولاً خودبه‌خود محدود می‌شود.**",
    "**سل ثانویه (بازفعالی) = بیماری کسی که قبلاً عفونی شده.**",
    "⚠️ **محل: قله‌ی ریه — سگمان آپیکال و پوستریور لوب فوقانی.**",
    "**چون فشار اکسیژن آنجا بیشترین است و باسیل هوازی اجباری است.**",
    "**مشخصه: کاویتاسیون، فیبروز، از دست رفتن حجم — و آدنوپاتی نادر است.**",
    "**درس: آدنوپاتی ناف ریه در نوجوان = سل اولیه؛ کاویته‌ی قله = سل ثانویه.**",
]
PRIM_EN = [
    "WARNING: PRIMARY AND POST-PRIMARY TUBERCULOSIS ARE TWO COMPLETELY DIFFERENT RADIOLOGICAL PICTURES.",
    "PRIMARY TB = the first encounter, with no prior immunity.",
    "Site: MIDDLE AND LOWER ZONES — where ventilation is greatest, so that is where the droplet lands.",
    "WARNING: THE DEFINING FEATURE IS HILAR AND PARATRACHEAL LYMPHADENOPATHY.",
    "In addition: pleural effusion and pleural reaction.",
    "And the hypersensitivity phenomena: ERYTHEMA NODOSUM and PHLYCTENULAR CONJUNCTIVITIS.",
    "In a healthy host it is usually self-limited.",
    "POST-PRIMARY (reactivation) TB = disease in someone already infected.",
    "WARNING: SITE — THE APEX, the apical and posterior segments of the upper lobe.",
    "Because oxygen tension is highest there and the bacillus is an obligate aerobe.",
    "Features: CAVITATION, fibrosis, volume loss — and adenopathy is uncommon.",
    "The lesson: hilar adenopathy in an adolescent = primary TB; an apical cavity = post-primary TB.",
]

add("book:207", "vignette", "medium",
    "**آدنوپاتی ناف ریه + اریتم ندوزوم + درگیری میانی و محیطی = سل اولیه.**",
    "Hilar adenopathy plus erythema nodosum plus mid- and peripheral-zone involvement equals primary tuberculosis.",
    PRIM_FA, PRIM_EN,
    "این سؤال یک تابلوی کلاسیک است که اگر دو تفاوت را بدانید، در ده ثانیه حل می‌شود.\n\n"
    "**بیمار: دختر نوجوان ۱۳ ساله، بدون بیماری زمینه‌ای، با درد سینه، تب، کاهش وزن، "
    "سرفه و خلط کم از یک ماه قبل. روی ساق پا ضایعه‌ای شبیه اریتم ندوزوم. در گرافی: "
    "انفیلتراسیون در قسمت میانی و محیطی ریه، همراه با پلورال ری‌اکشن و آدنوپاتی ناف "
    "ریه.**\n\n"
    "**سه سرنخ، و هر سه به یک سمت اشاره می‌کنند:**\n\n"
    "⚠️ **سرنخ اول — آدنوپاتی ناف ریه.** این **امضای سل اولیه** است. وقتی باسیل برای "
    "نخستین بار وارد می‌شود، از محل کانون اولیه (کانون گون) در امتداد لنفاوی‌ها به "
    "غدد ناف ریه می‌رود. مجموع کانون اولیه و آدنوپاتی، **کمپلکس رانکه/گون** نام دارد. "
    "**در سل ثانویه آدنوپاتی نادر است**، چون سیستم ایمنی از قبل باسیل را می‌شناسد و "
    "پاسخ لنفاوی گسترده نمی‌دهد.\n\n"
    "⚠️ **سرنخ دوم — محل درگیری: قسمت میانی و محیطی.** سل اولیه در **نواحی میانی و "
    "تحتانی** می‌نشیند، چون قطرک استنشاقی به جایی می‌رود که بیشترین تهویه را دارد. "
    "**سل ثانویه برعکس، قله‌ی ریه را می‌زند**، چون در بازفعالی، باسیلِ هوازیِ اجباری "
    "جایی رشد می‌کند که فشار اکسیژن بیشترین است.\n\n"
    "⚠️ **سرنخ سوم — اریتم ندوزوم.** یک پدیده‌ی **ازدیاد حساسیت** است که همراه با "
    "**تبدیل تست توبرکولین** در سل اولیه دیده می‌شود، نه در بازفعالی. هم‌خانواده‌ی آن، "
    "**کونژنکتیویت فلیکتنولار** است.\n\n"
    "**و سن هم می‌خواند:** نوجوان بدون بیماری زمینه‌ای در کشور با شیوع بالا، دقیقاً "
    "کسی است که برای نخستین بار عفونی می‌شود.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**سل ثانویه** — باید کاویته‌ی قله‌ی ریه می‌داشت، نه درگیری میانی با آدنوپاتی.\n\n"
    "**کانسر ریه** — در دختر ۱۳ ساله عملاً غیرممکن است، و اریتم ندوزوم را توضیح "
    "نمی‌دهد.\n\n"
    "**کاندیدا** — کاندیدا در ریه‌ی فرد با ایمنی سالم بیماری نمی‌سازد؛ عامل عفونت "
    "فرصت‌طلب است و اینجا هیچ نقص ایمنی‌ای وجود ندارد.",
    "This is a classic picture that resolves in ten seconds if you know two distinctions.\n\n"
    "THE PATIENT: a 13-year-old adolescent girl with no underlying disease, with chest pain, fever, weight loss, cough and scant sputum for about a month. On her shin, a lesion resembling ERYTHEMA NODOSUM. On the film: infiltration in the MID AND PERIPHERAL zone with pleural reaction and HILAR ADENOPATHY.\n\n"
    "THREE CLUES, ALL POINTING THE SAME WAY:\n\n"
    "WARNING, CLUE ONE — HILAR ADENOPATHY. This is THE SIGNATURE OF PRIMARY TUBERCULOSIS. When the bacillus arrives for the first time it travels from the initial focus (the Ghon focus) along the lymphatics to the hilar nodes. Focus plus adenopathy together make the GHON/RANKE COMPLEX. IN POST-PRIMARY DISEASE ADENOPATHY IS UNCOMMON, because the immune system already knows the organism and does not mount a widespread lymphatic response.\n\n"
    "WARNING, CLUE TWO — THE SITE: MID AND PERIPHERAL ZONE. Primary tuberculosis settles in the MIDDLE AND LOWER ZONES, because the inhaled droplet goes where ventilation is greatest. POST-PRIMARY DISEASE DOES THE OPPOSITE AND STRIKES THE APEX, because on reactivation this obligate aerobe grows where oxygen tension is highest.\n\n"
    "WARNING, CLUE THREE — ERYTHEMA NODOSUM. This is a HYPERSENSITIVITY phenomenon seen with TUBERCULIN CONVERSION in primary disease, not in reactivation. Its cousin is PHLYCTENULAR CONJUNCTIVITIS.\n\n"
    "AND THE AGE FITS TOO: an adolescent with no underlying disease in a high-prevalence country is exactly the person being infected for the first time.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "POST-PRIMARY TB — would require an apical cavity, not mid-zone involvement with adenopathy.\n\n"
    "LUNG CANCER — practically impossible in a 13-year-old girl, and it does not explain the erythema nodosum.\n\n"
    "CANDIDA — Candida does not cause lung disease in an immunocompetent host; it is an opportunist, and there is no immune defect here.",
    ["پاسخ صحیح — آدنوپاتی ناف ریه، درگیری میانی و محیطی، و اریتم ندوزوم، سه‌گانه‌ی سل اولیه است.",
     "باید کاویته‌ی قله‌ی ریه می‌داشت؛ در بازفعالی آدنوپاتی نادر است.",
     "در دختر ۱۳ ساله عملاً غیرممکن و توضیح‌دهنده‌ی اریتم ندوزوم نیست.",
     "عامل فرصت‌طلب است و در فرد با ایمنی سالم بیماری ریوی نمی‌سازد."],
    ["Correct — hilar adenopathy, mid- and peripheral-zone involvement and erythema nodosum are the triad of primary tuberculosis.",
     "Would require an apical cavity; adenopathy is uncommon in reactivation.",
     "Practically impossible in a 13-year-old and does not explain the erythema nodosum.",
     "An opportunist that does not cause lung disease in an immunocompetent host."],
    "**آدنوپاتی ناف ریه امضای سل اولیه است؛ کاویته‌ی قله امضای سل ثانویه.**",
    "Hilar adenopathy is the signature of primary tuberculosis; an apical cavity is the signature of post-primary disease.",
    REFS)

add("book:208", "recall", "medium",
    "**آدنوپاتی ناف ریه، پلورزی و کونژنکتیویت فلیکتنولار — هر سه از سل اولیه‌اند.**",
    "Hilar adenopathy, pleurisy and phlyctenular conjunctivitis are all features of primary tuberculosis.",
    PRIM_FA + [
        "⚠️ **کونژنکتیویت فلیکتنولار: ندول کوچک ملتحمه‌ای در پاسخ ازدیاد حساسیت.**",
        "**هم‌خانواده‌ی اریتم ندوزوم است — هر دو پاسخ ایمنی‌اند، نه عفونت مستقیم.**",
    ],
    PRIM_EN + [
        "WARNING: PHLYCTENULAR CONJUNCTIVITIS — a small conjunctival nodule arising as a hypersensitivity response.",
        "It is the cousin of erythema nodosum — both are immune responses, not direct infection.",
    ],
    "سؤال سه یافته را کنار هم گذاشته و می‌پرسد کدام‌یک از علائم سل اولیه‌ی ریوی است. "
    "**پاسخ «همه‌ی موارد» است، و دلیل هر سه یکی است.**\n\n"
    "**سل اولیه یعنی نخستین برخورد بدن با باسیل.** بدن هنوز ایمنی اختصاصی ندارد، پس "
    "دو دسته اتفاق می‌افتد: **گسترش لنفاوی** و **راه افتادن یک پاسخ ازدیاد حساسیت "
    "تازه‌ساز**. هر سه گزینه از یکی از این دو زاده می‌شوند.\n\n"
    "**۱. آدنوپاتی ناف ریه** ✔ — محصول مستقیم گسترش لنفاوی. باسیل از کانون اولیه "
    "(کانون گون) در امتداد لنفاوی‌ها به غدد ناف ریه می‌رود؛ مجموع این دو **کمپلکس گون "
    "(رانکه)** نام دارد. **این شایع‌ترین و مشخص‌ترین یافته‌ی سل اولیه است**، به‌ویژه در "
    "کودکان.\n\n"
    "**۲. پلورزی** ✔ — سل اولیه می‌تواند با پارگی یک کانون زیرپلورال به فضای پلور "
    "سرریز کند. نتیجه، **پلورال افیوژن سلی** است: اگزودای لنفوسیتی با قند پایین. "
    "توجه کنید که این هم عمدتاً یک **واکنش ازدیاد حساسیت** است، نه چرک — و همین است "
    "که بعداً توضیح می‌دهد چرا اسمیر مایع پلور تقریباً همیشه منفی است.\n\n"
    "**۳. کونژنکتیویت فلیکتنولار** ✔ — ندول کوچک و ملتحمه‌ای که در پاسخ به آنتی‌ژن "
    "مایکوباکتریوم ایجاد می‌شود. **دقیقاً هم‌خانواده‌ی اریتم ندوزوم است**: هیچ باسیلی "
    "در ضایعه نیست؛ آنچه می‌بینید، پاسخ ایمنی تازه‌بیدارشده‌ی بدن است.\n\n"
    "⚠️ **قاعده‌ی مفید برای امتحان: هر جا در سل، ضایعه‌ای دیدید که «باسیل ندارد ولی "
    "التهاب دارد» — اریتم ندوزوم، فلیکتنولار، پلورزی — به سل اولیه فکر کنید. این‌ها "
    "علائم بیدار شدن ایمنی‌اند، نه علائم تخریب بافت.**\n\n"
    "**و در برابر آن، علائم سل ثانویه علائم تخریب‌اند: کاویته، هموپتیزی، فیبروز.**",
    "The question puts three findings together and asks which is a feature of primary pulmonary tuberculosis. THE ANSWER IS ALL OF THEM, AND ALL THREE HAVE THE SAME EXPLANATION.\n\n"
    "PRIMARY TUBERCULOSIS IS THE BODY'S FIRST ENCOUNTER with the bacillus. There is no specific immunity yet, so two kinds of thing happen: LYMPHATIC SPREAD and THE SWITCHING-ON OF A BRAND-NEW HYPERSENSITIVITY RESPONSE. All three options are born from one of those two.\n\n"
    "1. HILAR ADENOPATHY — the direct product of lymphatic spread. The bacillus travels from the initial (Ghon) focus along the lymphatics to the hilar nodes; the two together form the GHON (RANKE) COMPLEX. THIS IS THE COMMONEST AND MOST CHARACTERISTIC FINDING OF PRIMARY DISEASE, especially in children.\n\n"
    "2. PLEURISY — primary tuberculosis can rupture a subpleural focus into the pleural space. The result is a TUBERCULOUS PLEURAL EFFUSION: a lymphocytic exudate with a low glucose. Note that this too is largely a HYPERSENSITIVITY REACTION rather than pus — which is what later explains why the fluid smear is almost always negative.\n\n"
    "3. PHLYCTENULAR CONJUNCTIVITIS — a small conjunctival nodule arising in response to mycobacterial antigen. IT IS THE EXACT COUSIN OF ERYTHEMA NODOSUM: there is no bacillus in the lesion; what you see is the newly awakened immune response.\n\n"
    "WARNING, A USEFUL EXAM RULE: wherever in tuberculosis you meet a lesion that HAS INFLAMMATION BUT NO BACILLI — erythema nodosum, phlyctenular conjunctivitis, pleurisy — think PRIMARY disease. These are the signs of immunity waking up, not of tissue destruction.\n\n"
    "AND BY CONTRAST, THE SIGNS OF POST-PRIMARY DISEASE ARE SIGNS OF DESTRUCTION: cavity, haemoptysis, fibrosis.",
    ["درست است ولی تنها یکی از سه؛ محصول گسترش لنفاوی از کانون گون.",
     "درست است ولی تنها یکی از سه؛ پارگی کانون زیرپلورال به فضای پلور.",
     "درست است ولی تنها یکی از سه؛ پاسخ ازدیاد حساسیت ملتحمه‌ای.",
     "پاسخ صحیح — هر سه یافته از سل اولیه‌اند: دو تا از گسترش لنفاوی و یکی از ازدیاد حساسیت."],
    ["True but only one of the three; the product of lymphatic spread from the Ghon focus.",
     "True but only one of the three; rupture of a subpleural focus into the pleural space.",
     "True but only one of the three; a conjunctival hypersensitivity response.",
     "Correct — all three are features of primary tuberculosis: two from lymphatic spread and one from hypersensitivity."],
    "**علائم سل اولیه علائم بیدار شدن ایمنی‌اند؛ علائم سل ثانویه علائم تخریب.**",
    "The signs of primary tuberculosis are signs of immunity awakening; those of post-primary disease are signs of destruction.",
    REFS)

# ==================================================== TB LYMPHADENITIS YIELD
LN_FA = [
    "**آدنیت سلی (اسکروفولا) شایع‌ترین شکل سل خارج‌ریوی است.**",
    "**تابلو: تورم بدون درد غدد گردنی، اغلب بدون تب و بدون کاهش وزن.**",
    "⚠️ **کلید تشخیص: نمونه‌برداری از خودِ غده، نه خون و نه خلط.**",
    "**و در نمونه، سه چیز را با هم می‌فرستید.**",
    "**بافت‌شناسی: گرانولوم کازئوزکننده — سریع‌ترین سرنخ.**",
    "**اسمیر اسیدفست روی نمونه: حساسیت پایین‌تر.**",
    "⚠️ **کشت نمونه‌ی بیوپسی: مثبت در حدود ۷۰ تا ۸۰٪ — بالاترین بازده.**",
    "**و کشت است که حساسیت دارویی می‌دهد؛ بافت‌شناسی نمی‌دهد.**",
    "**FNA در آدنیت گردنی بازده خوبی دارد ولی بیوپسی برتر است.**",
    "**درمان مثل سل ریوی است: رژیم استاندارد شش‌ماهه.**",
    "⚠️ **و بزرگ‌شدن پارادوکسیکال غده حین درمان، شکست درمان نیست.**",
    "**پاسخ ایمنی است و درمان را عوض نمی‌کند.**",
]
LN_EN = [
    "Tuberculous lymphadenitis (scrofula) is the commonest form of extrapulmonary tuberculosis.",
    "The picture: painless swelling of cervical nodes, often without fever and without weight loss.",
    "WARNING: THE KEY TO DIAGNOSIS IS SAMPLING THE NODE ITSELF, not blood and not sputum.",
    "And on that sample you send three things together.",
    "HISTOLOGY: caseating granuloma — the fastest clue.",
    "ACID-FAST SMEAR on the specimen: lower sensitivity.",
    "WARNING: CULTURE OF THE BIOPSY SPECIMEN — positive in about 70 to 80 %, the highest yield.",
    "And it is culture that gives drug susceptibility; histology does not.",
    "Fine-needle aspiration gives a good yield in cervical adenitis, but excision biopsy is superior.",
    "Treatment is as for pulmonary disease: the standard six-month regimen.",
    "WARNING, AND PARADOXICAL ENLARGEMENT OF THE NODE DURING TREATMENT IS NOT TREATMENT FAILURE.",
    "It is an immune response and it does not change the regimen.",
]

add("book:210", "recall", "medium",
    "**کشت نمونه‌ی بیوپسی غده‌ی لنفاوی در حدود ۷۰ تا ۸۰٪ موارد مثبت می‌شود.**",
    "Culture of a lymph node biopsy specimen is positive in about 70 to 80 % of cases.",
    LN_FA, LN_EN,
    "این یک سؤال عددی است، ولی عددش را می‌توان از روی منطق بازسازی کرد — و همین "
    "بازسازی، ارزش آموزشی سؤال است.\n\n"
    "**سؤال: در آدنیت توبرکلوزی، کشت نمونه‌ی بیوپسی از غده‌ی لنفاوی چند درصد مثبت "
    "می‌شود؟ پاسخ: ۷۰ تا ۸۰ درصد.**\n\n"
    "**چرا این عدد این‌قدر بالاست، در حالی که در مایع پلور بازده کشت زیر ۴۰٪ است؟**\n\n"
    "⚠️ **چون بار باسیلی در بافت است، نه در مایع.** غده‌ی لنفاوی درگیر، **خودِ کانون "
    "عفونت** است: گرانولوم، ماکروفاژهای آلوده و ماده‌ی کازئوزی همه در بافت غده‌اند. "
    "وقتی غده را برمی‌دارید و کشت می‌دهید، مستقیماً همان‌جایی را کشت داده‌اید که باسیل "
    "زندگی می‌کند.\n\n"
    "**در برابر آن، مایع پلور محصول یک واکنش ازدیاد حساسیت است**: باسیل‌ها در پرده‌ی "
    "پلور مانده‌اند و مایع تقریباً عاری از آن‌هاست. به همین دلیل در پلورزی سلی هم "
    "پاسخ درست، **بیوپسی پلور** است نه آسپیراسیون مایع. **یک قاعده‌ی واحد پشت هر دو "
    "سؤال است: بافت را نمونه بگیر، نه ترشح را.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**۲۰ تا ۳۰ درصد** — این عدد به بازده **اسمیر اسیدفست** نزدیک‌تر است، نه کشت. "
    "اسمیر برای مثبت شدن به حدود ۱۰٬۰۰۰ باسیل در هر میلی‌لیتر نیاز دارد، و آدنیت سلی "
    "معمولاً بار باسیلی کمتری دارد.\n\n"
    "**۵۰ تا ۶۰ درصد** — دست‌کم گرفتن بازده کشت بافت.\n\n"
    "**۹۰ تا ۱۰۰ درصد** — هیچ آزمون میکروبیولوژیکی در سل خارج‌ریوی این‌قدر حساس نیست. "
    "اگر کشت ۱۰۰٪ بود، بافت‌شناسی و PCR اصلاً لازم نمی‌شدند.\n\n"
    "**نکته‌ی بالینی که همیشه باید کنار این عدد بیاید: حتی وقتی بافت‌شناسی گرانولوم "
    "کازئوزکننده می‌دهد و تشخیص روشن است، باز هم کشت را بفرستید — چون فقط کشت "
    "«آنتی‌بیوگرام» می‌دهد، و در دنیای مقاومت دارویی امروز، آن اطلاعات ممکن است "
    "درمان را عوض کند.**",
    "This is a numerical question, but its number can be reconstructed from reasoning — and that reconstruction is the teaching value.\n\n"
    "THE QUESTION: in tuberculous adenitis, what percentage of lymph node biopsy cultures are positive? THE ANSWER: 70 TO 80 PER CENT.\n\n"
    "WHY IS THAT FIGURE SO HIGH, WHEN PLEURAL FLUID CULTURE YIELDS UNDER 40 %?\n\n"
    "WARNING: BECAUSE THE BACILLARY LOAD IS IN THE TISSUE, NOT IN A FLUID. The involved node IS THE FOCUS OF INFECTION: granuloma, infected macrophages and caseous material are all inside the node. When you excise the node and culture it, you have cultured precisely where the bacillus lives.\n\n"
    "BY CONTRAST, PLEURAL FLUID IS THE PRODUCT OF A HYPERSENSITIVITY REACTION: the bacilli stay in the pleural membrane and the fluid is nearly free of them. That is why in tuberculous pleurisy the right answer is also PLEURAL BIOPSY rather than fluid aspiration. ONE RULE SITS BEHIND BOTH QUESTIONS: SAMPLE THE TISSUE, NOT THE SECRETION.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "20 TO 30 PER CENT — that figure is closer to the yield of ACID-FAST SMEAR, not culture. A smear needs roughly 10,000 bacilli per millilitre to turn positive, and tuberculous adenitis usually carries a lower load.\n\n"
    "50 TO 60 PER CENT — an underestimate of tissue culture yield.\n\n"
    "90 TO 100 PER CENT — no microbiological test in extrapulmonary tuberculosis is that sensitive. If culture were 100 % there would be no need for histology or PCR at all.\n\n"
    "THE CLINICAL POINT THAT MUST ALWAYS ACCOMPANY THIS NUMBER: even when histology shows a caseating granuloma and the diagnosis is clear, STILL SEND THE CULTURE — because only culture gives drug susceptibility, and in today's world of resistance that information may change the treatment.",
    ["نزدیک به بازده اسمیر اسیدفست است، نه کشت بافت.",
     "پاسخ صحیح — کشت بافت غده در حدود ۷۰ تا ۸۰٪ مثبت می‌شود.",
     "دست‌کم گرفتن بازده کشت بافت؛ بافت غده بار باسیلی بالایی دارد.",
     "هیچ آزمون میکروبیولوژیکی در سل خارج‌ریوی این‌قدر حساس نیست."],
    ["Closer to the yield of acid-fast smear than of tissue culture.",
     "Correct — culture of node tissue is positive in about 70 to 80 %.",
     "An underestimate; node tissue carries a high bacillary load.",
     "No microbiological test in extrapulmonary tuberculosis is that sensitive."],
    "**بافت را کشت بده، نه ترشح را — و کشت است که آنتی‌بیوگرام می‌دهد.**",
    "Culture the tissue, not the secretion — and it is culture that gives the susceptibility result.",
    REFS)

# ==================================================== TUBERCULOMA
BRAIN_FA = [
    "⚠️ **در ضایعه‌ی حلقوی مغز، همیشه سه چیز را کنار هم بگذارید.**",
    "**وضعیت ایمنی بیمار · شواهد بیماری در جای دیگر بدن · شکل و تعداد ضایعه.**",
    "**توکسوپلاسموز مغزی: تقریباً همیشه در HIV با CD4 زیر ۱۰۰.**",
    "**پس در بیمار HIV منفی، توکسوپلاسموز از فهرست بیرون می‌رود.**",
    "**لنفوم مغزی اولیه: باز هم بیماری نقص ایمنی، و معمولاً تک‌ضایعه‌ی پری‌ونتریکولار.**",
    "⚠️ **توبرکلوما: ضایعه‌ی حلقوی، اغلب چندتایی، در بیمار با شواهد سل جای دیگر.**",
    "**و شواهد جای دیگر همان است که تشخیص را قطعی می‌کند.**",
    "**فیبروز قله‌ی ریه = سل قدیمی درمان‌نشده.**",
    "⚠️ **PPD بیست میلی‌متر = عفونت قطعی با مایکوباکتریوم توبرکلوزیس.**",
    "**تابلوی بالینی توبرکلوما: تشنج و نقص عصبی کانونی، اغلب بدون تب.**",
    "**چون توده است، نه مننژیت — و توده تب نمی‌سازد.**",
    "**درمان: رژیم ضدسل طولانی‌تر (۹ تا ۱۲ ماه) همراه با کورتیکواستروئید.**",
]
BRAIN_EN = [
    "WARNING: WITH A RING-ENHANCING BRAIN LESION, ALWAYS PUT THREE THINGS TOGETHER.",
    "The patient's immune status, evidence of disease elsewhere in the body, and the shape and number of the lesions.",
    "CEREBRAL TOXOPLASMOSIS: almost always in HIV with a CD4 count below 100.",
    "So in an HIV-negative patient toxoplasmosis leaves the list.",
    "PRIMARY CNS LYMPHOMA: again an immunodeficiency disease, and usually a single periventricular lesion.",
    "WARNING: TUBERCULOMA — a ring-enhancing lesion, often multiple, in a patient with evidence of tuberculosis elsewhere.",
    "And it is the evidence elsewhere that clinches the diagnosis.",
    "APICAL FIBROSIS means old untreated tuberculosis.",
    "WARNING: A PPD OF 20 MM MEANS DEFINITE INFECTION with Mycobacterium tuberculosis.",
    "The clinical picture of tuberculoma: seizures and focal neurological deficit, often without fever.",
    "Because it is a mass, not a meningitis — and a mass does not produce fever.",
    "Treatment: a longer antituberculous regimen (9 to 12 months) together with a corticosteroid.",
]

add("book:211", "vignette", "medium",
    "**ضایعه‌ی حلقوی مغز + فیبروز قله‌ی ریه + PPD بیست میلی‌متر + HIV منفی = توبرکلوما.**",
    "Ring-enhancing brain lesions plus apical fibrosis plus a PPD of 20 mm in an HIV-negative patient equals tuberculoma.",
    BRAIN_FA, BRAIN_EN,
    "این سؤال یک تمرین عالی در روش حذف است، چون هر سرنخ دقیقاً یک گزینه را از بازی "
    "بیرون می‌برد.\n\n"
    "**بیمار: مرد ۳۰ ساله با تشنج و پارزی سمت راست. بدون تب. HIV منفی. بدون بیماری "
    "زمینه‌ای. در گرافی ریه، ضایعات فیبروتیک قله‌ی ریه‌ی راست. PPD = ۲۰ میلی‌متر. در "
    "MRI، چند ضایعه‌ی فضاگیر ۳ تا ۴ سانتی‌متری با نمای Ring-enhanced.**\n\n"
    "**سرنخ اول — HIV منفی. این یکی، دو گزینه را با هم می‌کشد.**\n\n"
    "⚠️ **توکسوپلاسموز مغزی** تقریباً منحصراً بیماری فرد با **CD4 زیر ۱۰۰** است. در "
    "فرد با ایمنی سالم، عفونت توکسوپلاسما نهفته می‌ماند و آنسفالیت نمی‌سازد. **با HIV "
    "منفی، این گزینه می‌رود.**\n\n"
    "⚠️ **لنفوم مغزی اولیه** نیز عمدتاً بیماری نقص ایمنی است (به‌ویژه HIV با CD4 خیلی "
    "پایین، مرتبط با EBV). به‌علاوه معمولاً **تک‌ضایعه** و **پری‌ونتریکولار** است، نه "
    "چند ضایعه‌ی پراکنده. **می‌رود.**\n\n"
    "**سرنخ دوم — شواهد سل در جای دیگر بدن. این یکی، پاسخ را می‌سازد.**\n\n"
    "**فیبروز قله‌ی ریه‌ی راست** یعنی این بیمار **سل ریوی درمان‌نشده یا خودبه‌خود بهبود "
    "یافته** داشته است. **و PPD برابر ۲۰ میلی‌متر** — عددی بسیار بالاتر از هر آستانه‌ای "
    "— یعنی **عفونت قطعی با مایکوباکتریوم توبرکلوزیس**.\n\n"
    "**پس بدنی داریم که مایکوباکتریوم در آن حضور دارد، و مغزی که چند ضایعه‌ی حلقوی "
    "دارد. توبرکلوما همان گرانولوم سلی درون پارانشیم مغز است.**\n\n"
    "**سرنخ سوم — نبود تب.** توبرکلوما یک **توده** است، نه یک عفونت حاد منتشر. برخلاف "
    "مننژیت سلی که تب و سردرد و سفتی گردن می‌دهد، توبرکلوما با **تشنج و نقص کانونی** "
    "خودش را نشان می‌دهد، اغلب بدون تب.\n\n"
    "**چرا تومور مغزی رد می‌شود؟** تومور اولیه‌ی مغز معمولاً **تک‌ضایعه** است و مهم‌تر "
    "از آن، هیچ ربطی به فیبروز قله‌ی ریه و PPD بیست میلی‌متری ندارد. **در پزشکی، "
    "توضیحی که همه‌ی یافته‌ها را با یک بیماری جمع کند، بر توضیحی که دو بیماری بی‌ربط "
    "لازم دارد، ترجیح دارد.**\n\n"
    "**درمان: رژیم ضدسل، ولی طولانی‌تر از سل ریوی — معمولاً ۹ تا ۱۲ ماه — به‌همراه "
    "کورتیکواستروئید برای کنترل ادم اطراف ضایعه.**",
    "This question is an excellent exercise in elimination, because each clue removes exactly one option from play.\n\n"
    "THE PATIENT: a 30-year-old man with seizures and right-sided weakness. No fever. HIV NEGATIVE. No underlying disease. Chest film: FIBROTIC LESIONS AT THE RIGHT APEX. PPD = 20 MM. MRI: several 3-to-4 cm space-occupying lesions with RING ENHANCEMENT.\n\n"
    "CLUE ONE — HIV NEGATIVE. This single fact kills two options at once.\n\n"
    "WARNING: CEREBRAL TOXOPLASMOSIS is almost exclusively a disease of a CD4 COUNT BELOW 100. In an immunocompetent host toxoplasma infection stays latent and does not produce encephalitis. WITH HIV NEGATIVE, THIS OPTION GOES.\n\n"
    "WARNING: PRIMARY CNS LYMPHOMA is likewise mainly an immunodeficiency disease (especially HIV with a very low CD4 count, EBV-related). It is also usually a SINGLE PERIVENTRICULAR lesion rather than several scattered ones. IT GOES.\n\n"
    "CLUE TWO — EVIDENCE OF TUBERCULOSIS ELSEWHERE IN THE BODY. This one builds the answer.\n\n"
    "FIBROSIS AT THE RIGHT APEX means this patient has had UNTREATED OR SPONTANEOUSLY HEALED PULMONARY TUBERCULOSIS. AND A PPD OF 20 MM — far above any threshold — means DEFINITE INFECTION with Mycobacterium tuberculosis.\n\n"
    "SO WE HAVE A BODY IN WHICH MYCOBACTERIUM IS PRESENT AND A BRAIN WITH SEVERAL RING LESIONS. A tuberculoma is precisely a tuberculous granuloma within brain parenchyma.\n\n"
    "CLUE THREE — THE ABSENCE OF FEVER. A tuberculoma is A MASS, not an acute disseminated infection. Unlike tuberculous meningitis, which gives fever, headache and neck stiffness, a tuberculoma announces itself with SEIZURES AND FOCAL DEFICIT, often afebrile.\n\n"
    "WHY IS BRAIN TUMOUR REJECTED? A primary brain tumour is usually a SINGLE lesion and, more importantly, has nothing to do with apical fibrosis and a 20 mm PPD. IN MEDICINE, AN EXPLANATION THAT GATHERS ALL THE FINDINGS UNDER ONE DISEASE BEATS ONE THAT REQUIRES TWO UNRELATED DISEASES.\n\n"
    "TREATMENT: an antituberculous regimen, but longer than for pulmonary disease — usually 9 to 12 months — together with a corticosteroid to control the surrounding oedema.",
    ["معمولاً تک‌ضایعه است و فیبروز قله‌ی ریه و PPD بیست میلی‌متری را توضیح نمی‌دهد.",
     "پاسخ صحیح — چند ضایعه‌ی حلقوی در بیمار با شواهد سل ریوی قدیمی و PPD قویاً مثبت.",
     "تقریباً منحصراً در HIV با CD4 زیر ۱۰۰؛ این بیمار HIV منفی است.",
     "عمدتاً بیماری نقص ایمنی و معمولاً تک‌ضایعه‌ی پری‌ونتریکولار."],
    ["Usually a single lesion, and it does not explain the apical fibrosis or the 20 mm PPD.",
     "Correct — multiple ring lesions in a patient with evidence of old pulmonary tuberculosis and a strongly positive PPD.",
     "Almost exclusively in HIV with a CD4 count below 100; this patient is HIV negative.",
     "Mainly an immunodeficiency disease and usually a single periventricular lesion."],
    "**در ضایعه‌ی حلقوی مغز، وضعیت ایمنی و شواهد بیماری در جای دیگر بدن را با هم بخوانید.**",
    "With a ring-enhancing brain lesion, read the immune status together with the evidence of disease elsewhere.",
    REFS)

# ==================================================== GENITOURINARY TB
GU_FA = [
    "⚠️ **پیوری استریل تا خلاف آن ثابت نشود، یعنی سل ادراری‌تناسلی.**",
    "**یعنی گلبول سفید فراوان در ادرار، ولی کشت معمولی منفی.**",
    "**چون مایکوباکتریوم در محیط کشت معمولی رشد نمی‌کند.**",
    "**تابلو در زن: نازایی، درد لگن مزمن، اختلال قاعدگی.**",
    "**چون سل لوله‌های رحمی را می‌بندد — علت مهم نازایی در کشورهای اندمیک.**",
    "**تابلو در مرد: اپیدیدیمیت مزمن یا پروستاتیت بدون پاسخ به آنتی‌بیوتیک.**",
    "⚠️ **آزمون انتخابی: کشت ادرار صبحگاهی، سه نوبت متوالی.**",
    "**چرا صبحگاهی؟ چون تمام شب در مثانه تغلیظ شده و بار باسیلی بیشتر است.**",
    "**چرا سه نوبت؟ چون دفع باسیل متناوب است و یک نمونه ممکن است خالی باشد.**",
    "⚠️ **چرا کشت و نه اسمیر؟ چون مایکوباکتریوم‌های ساپروفیت اسمیر را مثبت کاذب می‌کنند.**",
    "**اسمیت‌گما و مایکوباکتریوم‌های محیطی در ناحیه‌ی تناسلی، اسیدفست‌اند.**",
    "**درمان: همان رژیم استاندارد شش‌ماهه.**",
]
GU_EN = [
    "WARNING: STERILE PYURIA MEANS GENITOURINARY TUBERCULOSIS UNTIL PROVED OTHERWISE.",
    "That is, abundant white cells in the urine with a negative routine culture.",
    "Because Mycobacterium does not grow on ordinary culture media.",
    "The picture in a woman: infertility, chronic pelvic pain, menstrual disturbance.",
    "Because tuberculosis occludes the fallopian tubes — an important cause of infertility in endemic countries.",
    "The picture in a man: chronic epididymitis or prostatitis unresponsive to antibiotics.",
    "WARNING: THE TEST OF CHOICE IS CULTURE OF EARLY-MORNING URINE ON THREE CONSECUTIVE OCCASIONS.",
    "Why early morning? Because it has concentrated in the bladder all night and the bacillary load is higher.",
    "Why three samples? Because shedding is INTERMITTENT and a single specimen may be empty.",
    "WARNING: WHY CULTURE AND NOT SMEAR? Because saprophytic mycobacteria give FALSE-POSITIVE smears.",
    "Mycobacterium smegmatis and environmental mycobacteria in the genital area are acid-fast.",
    "Treatment: the same standard six-month regimen.",
]

add("book:212", "recall", "medium",
    "**پیوری استریل با نازایی: کشت ادرار صبحگاهی در سه نوبت.**",
    "Sterile pyuria with infertility: culture early-morning urine on three occasions.",
    GU_FA, GU_EN,
    "این سؤال دو چیز را با هم می‌سنجد: شناختن تابلو، و انتخاب درست بین چهار آزمون که "
    "همه‌شان «معقول» به‌نظر می‌رسند.\n\n"
    "**بیمار: خانم متأهل با درد لگن مزمن، نازایی اولیه و اختلال عادت ماهیانه. در "
    "آزمایش، پیوری استریل.**\n\n"
    "⚠️ **پیوری استریل، عبارت کلیدی است: گلبول سفید فراوان در ادرار، ولی کشت معمولی "
    "منفی.** دلیلش ساده است — مایکوباکتریوم در محیط کشت معمولی آزمایشگاه **اصلاً رشد "
    "نمی‌کند**. پس آزمایشگاه «کشت منفی» گزارش می‌کند، در حالی که عفونت کاملاً فعال است.\n\n"
    "**و بقیه‌ی تابلو کاملاً می‌خواند:** سل ادراری‌تناسلی در زن، **لوله‌های رحمی** را "
    "درگیر و مسدود می‌کند. نتیجه: **نازایی اولیه، درد لگن مزمن و اختلال قاعدگی** — "
    "دقیقاً سه شکایت این بیمار. در کشورهای اندمیک، این یکی از علل مهم و "
    "قابل‌پیشگیری نازایی است.\n\n"
    "**حالا انتخاب آزمون. پاسخ: کشت ادرار صبحگاهی در سه نوبت.**\n\n"
    "**دو صفت این جمله، هر دو ضروری‌اند:**\n\n"
    "**«صبحگاهی»** — ادرار اول صبح تمام شب در مثانه جمع شده و **تغلیظ** شده است، پس "
    "بیشترین بار باسیلی را دارد. (توجه: نمونه‌ی ۲۴ ساعته توصیه نمی‌شود، چون ماندن "
    "طولانی در دمای اتاق کیفیت نمونه را خراب می‌کند.)\n\n"
    "**«سه نوبت»** — دفع باسیل در ادرار **متناوب** است. یک نمونه‌ی منفی هیچ چیز را رد "
    "نمی‌کند. سه نمونه‌ی متوالی، حساسیت را به‌طور معناداری بالا می‌برد.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "⚠️ **رنگ‌آمیزی اسیدفست ادراری در سه نوبت** — نزدیک‌ترین گزینه به پاسخ، و دقیقاً "
    "به همین دلیل خطرناک‌ترین. مشکل، **مثبت کاذب** است: **مایکوباکتریوم اسمگماتیس** و "
    "سایر مایکوباکتریوم‌های ساپروفیت که به‌طور طبیعی در ناحیه‌ی تناسلی زندگی می‌کنند، "
    "**اسیدفست‌اند**. اسمیر نمی‌تواند آن‌ها را از باسیل سل تشخیص دهد، ولی کشت می‌تواند.\n\n"
    "**PCR ادرار یک نوبت** — سریع است، ولی «یک نوبت» همان مشکل دفع متناوب را دارد، "
    "و مهم‌تر: **PCR آنتی‌بیوگرام نمی‌دهد**.\n\n"
    "**رنگ‌آمیزی اسیدفست در نمونه‌ی بافت** — تهاجمی است و به‌عنوان **اقدام اول** منطقی "
    "نیست. وقتی یک آزمون غیرتهاجمی با بازده خوب در دسترس است، از آن شروع می‌کنیم.",
    "This question tests two things at once: recognising the picture, and choosing correctly between four tests that all look reasonable.\n\n"
    "THE PATIENT: a married woman with chronic pelvic pain, primary infertility and menstrual disturbance. The laboratory reports STERILE PYURIA.\n\n"
    "WARNING: STERILE PYURIA IS THE KEY PHRASE — abundant white cells in the urine with a negative routine culture. The reason is simple: Mycobacterium DOES NOT GROW AT ALL on ordinary laboratory media. So the laboratory reports 'no growth' while the infection is fully active.\n\n"
    "AND THE REST OF THE PICTURE FITS EXACTLY: genitourinary tuberculosis in a woman involves and OCCLUDES THE FALLOPIAN TUBES. The result: PRIMARY INFERTILITY, CHRONIC PELVIC PAIN AND MENSTRUAL DISTURBANCE — precisely this patient's three complaints. In endemic countries this is an important and preventable cause of infertility.\n\n"
    "NOW THE CHOICE OF TEST. THE ANSWER: CULTURE OF EARLY-MORNING URINE ON THREE OCCASIONS.\n\n"
    "BOTH QUALIFIERS IN THAT SENTENCE ARE ESSENTIAL:\n\n"
    "'EARLY MORNING' — the first urine of the day has collected in the bladder all night and is CONCENTRATED, so it carries the highest bacillary load. (Note: a 24-hour collection is NOT recommended, because standing at room temperature degrades the specimen.)\n\n"
    "'THREE OCCASIONS' — urinary shedding of the bacillus is INTERMITTENT. One negative specimen excludes nothing. Three consecutive specimens raise the sensitivity substantially.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "WARNING: URINARY ACID-FAST STAIN ON THREE OCCASIONS — the closest option to the answer, and precisely for that reason the most dangerous. The problem is FALSE POSITIVES: MYCOBACTERIUM SMEGMATIS and other saprophytic mycobacteria that live naturally in the genital area ARE ACID-FAST. A smear cannot distinguish them from the tubercle bacillus; a culture can.\n\n"
    "A SINGLE URINE PCR — fast, but 'a single' runs into the same intermittent-shedding problem, and more importantly PCR DOES NOT GIVE SUSCEPTIBILITY DATA.\n\n"
    "ACID-FAST STAIN ON A TISSUE SPECIMEN — invasive and not a sensible FIRST step. When a non-invasive test with a good yield exists, start with that.",
    ["مایکوباکتریوم اسمگماتیس ساپروفیت هم اسیدفست است و مثبت کاذب می‌سازد.",
     "یک نوبت برای دفع متناوب کافی نیست و PCR آنتی‌بیوگرام نمی‌دهد.",
     "پاسخ صحیح — ادرار صبحگاهی تغلیظ‌شده است و سه نوبت بر دفع متناوب غلبه می‌کند.",
     "تهاجمی است و به‌عنوان اقدام اول، پیش از آزمون غیرتهاجمی، منطقی نیست."],
    ["Saprophytic Mycobacterium smegmatis is also acid-fast and produces false positives.",
     "A single specimen cannot overcome intermittent shedding, and PCR gives no susceptibility data.",
     "Correct — early-morning urine is concentrated and three specimens overcome intermittent shedding.",
     "Invasive, and not a sensible first step before a non-invasive test."],
    "**پیوری استریل یعنی سل ادراری؛ و پاسخ، کشت صبحگاهی سه‌نوبته است نه اسمیر.**",
    "Sterile pyuria means urinary tuberculosis; and the answer is three early-morning cultures, not a smear.",
    REFS)

# ==================================================== TUBERCULOUS PLEURISY
PLEUR_FA = [
    "⚠️ **پلورال افیوژن سلی یک واکنش ازدیاد حساسیت است، نه یک کیسه‌ی چرک.**",
    "**و این یک جمله، همه‌ی بازده‌های آزمایشگاهی را توضیح می‌دهد.**",
    "**مایع: اگزودا، غلبه‌ی لنفوسیت، قند پایین، پروتئین بالا، ADA بالا.**",
    "**معیار لایت: نسبت LDH مایع به سرم بیش از ۰٫۶ یعنی اگزودا.**",
    "⚠️ **اسمیر مایع پلور: کمتر از ۱۰٪ مثبت — تقریباً بی‌فایده به‌تنهایی.**",
    "**کشت مایع پلور: حدود ۲۵ تا ۴۰٪.**",
    "⚠️ **بیوپسی پلور: حدود ۷۰ تا ۸۰٪ — بالاترین بازده.**",
    "**چرا؟ چون باسیل‌ها در خودِ پرده‌ی پلور هستند، نه در مایع.**",
    "**پس بافت را نمونه بگیر، نه ترشح را — همان قاعده‌ی آدنیت سلی.**",
    "**ADA کمک‌کننده است ولی تشخیص قطعی نمی‌دهد و آنتی‌بیوگرام نمی‌دهد.**",
    "**PPD در پلورزی سلی می‌تواند تا یک‌سوم موارد منفی باشد.**",
    "⚠️ **پس PPD منفی هرگز پلورزی سلی را رد نمی‌کند.**",
]
PLEUR_EN = [
    "WARNING: A TUBERCULOUS PLEURAL EFFUSION IS A HYPERSENSITIVITY REACTION, NOT A BAG OF PUS.",
    "And that one sentence explains every laboratory yield that follows.",
    "The fluid: an exudate, lymphocyte-predominant, low glucose, high protein, high ADA.",
    "Light's criterion: a pleural-to-serum LDH ratio above 0.6 means an exudate.",
    "WARNING: SMEAR OF PLEURAL FLUID — POSITIVE IN UNDER 10 %, nearly useless alone.",
    "Culture of pleural fluid: about 25 to 40 %.",
    "WARNING: PLEURAL BIOPSY — about 70 to 80 %, the highest yield.",
    "Why? Because the bacilli are in the pleural MEMBRANE, not in the fluid.",
    "So sample the tissue, not the secretion — the same rule as in tuberculous adenitis.",
    "ADA is helpful but is not diagnostic on its own and gives no susceptibility data.",
    "The PPD can be NEGATIVE in up to a third of cases of tuberculous pleurisy.",
    "WARNING: SO A NEGATIVE PPD NEVER EXCLUDES TUBERCULOUS PLEURISY.",
]

add("book:213", "recall", "medium",
    "**اگزودای لنفوسیتی با قند پایین: پاسخ، بیوپسی پلور است.**",
    "A lymphocytic exudate with a low glucose: the answer is pleural biopsy.",
    PLEUR_FA, PLEUR_EN,
    "این سؤال کوتاه است ولی یک اصل بنیادی را می‌سنجد که در سه سؤال دیگر همین فصل هم "
    "تکرار می‌شود.\n\n"
    "**بیمار: پلورال افیوژن یک‌طرفه. در آسپیراسیون، مایع اگزوداتیو با قند پایین و "
    "WBC=1550 با غلبه‌ی لنفوسیت.**\n\n"
    "**این سه ویژگی با هم، تابلوی کلاسیک پلورزی سلی است:** اگزودا + قند پایین + "
    "غلبه‌ی لنفوسیت. (تشخیص‌های افتراقی دیگر همین تابلو: بدخیمی، آرتریت روماتوئید، "
    "لنفوم — ولی در کشور اندمیک، سل در صدر است.)\n\n"
    "**حالا سؤال واقعی: از اینجا به کجا برویم؟**\n\n"
    "⚠️ **کلید، یک واقعیت پاتوفیزیولوژیک است: پلورال افیوژن سلی از چرک ساخته نشده، "
    "از ازدیاد حساسیت ساخته شده.** یک کانون کوچک زیرپلورال به فضای پلور پاره می‌شود و "
    "**تعداد کمی باسیل** آزاد می‌کند. بدن به آنتی‌ژن آن‌ها پاسخ شدید تأخیری می‌دهد و "
    "**مایع، محصول همین پاسخ است**.\n\n"
    "**نتیجه‌ی مستقیم: مایع تقریباً عاری از باسیل است، ولی خودِ پرده‌ی پلور پر از "
    "گرانولوم است.**\n\n"
    "**و بازده‌ها دقیقاً همین را نشان می‌دهند:**\n\n"
    "**اسمیر مایع: زیر ۱۰٪** · **کشت مایع: ۲۵ تا ۴۰٪** · **بیوپسی پلور: ۷۰ تا ۸۰٪**\n\n"
    "**پس پاسخ، بیوپسی از پلور است.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**بررسی مایع پلور از نظر باسیل اسیدفست** — بازده زیر ۱۰٪. یعنی در ۹ نفر از هر "
    "۱۰ بیمار مبتلا، منفی می‌شود. **آزمونی که منفی‌اش هیچ چیز را رد نمی‌کند، آزمون "
    "«رسیدن به تشخیص» نیست.**\n\n"
    "⚠️ **ADA مایع پلور** — گزینه‌ی وسوسه‌انگیز، و در عمل بالینی واقعاً مفید. ADA بالا "
    "(معمولاً بالای ۴۰ واحد در لیتر) احتمال سل را بسیار بالا می‌برد. **ولی ADA یک "
    "آزمون حمایتی است، نه تشخیصی**: در لنفوم و آمپیم هم بالا می‌رود، و مهم‌تر — "
    "**آنتی‌بیوگرام نمی‌دهد**.\n\n"
    "**PPD** — بدترین گزینه، به دلیلی که دانشجویان کمتر می‌دانند: **در پلورزی سلی، "
    "PPD می‌تواند تا یک‌سوم موارد منفی باشد**، چون لنفوسیت‌های حساس‌شده در فضای پلور "
    "تجمع یافته‌اند. **PPD منفی هرگز پلورزی سلی را رد نمی‌کند.**",
    "This question is short but tests a fundamental principle that recurs in three other questions in this chapter.\n\n"
    "THE PATIENT: a unilateral pleural effusion. On aspiration, an EXUDATE with a LOW GLUCOSE and WBC 1550 with LYMPHOCYTE PREDOMINANCE.\n\n"
    "THOSE THREE FEATURES TOGETHER ARE THE CLASSIC PICTURE OF TUBERCULOUS PLEURISY: exudate plus low glucose plus lymphocytes. (Other differentials for the same picture: malignancy, rheumatoid arthritis, lymphoma — but in an endemic country tuberculosis heads the list.)\n\n"
    "NOW THE REAL QUESTION: WHERE DO WE GO FROM HERE?\n\n"
    "WARNING: THE KEY IS A PATHOPHYSIOLOGICAL FACT — A TUBERCULOUS EFFUSION IS NOT MADE OF PUS, IT IS MADE OF HYPERSENSITIVITY. A small subpleural focus ruptures into the pleural space and releases A SMALL NUMBER OF BACILLI. The body mounts a vigorous delayed response to their antigen, AND THE FLUID IS THE PRODUCT OF THAT RESPONSE.\n\n"
    "THE DIRECT CONSEQUENCE: the fluid is nearly free of organisms, while the pleural MEMBRANE is full of granulomas.\n\n"
    "AND THE YIELDS SHOW EXACTLY THAT:\n\n"
    "FLUID SMEAR: under 10 % · FLUID CULTURE: 25 to 40 % · PLEURAL BIOPSY: 70 to 80 %.\n\n"
    "SO THE ANSWER IS PLEURAL BIOPSY.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ACID-FAST EXAMINATION OF THE FLUID — a yield under 10 %. That means it is negative in nine of every ten patients who have the disease. A TEST WHOSE NEGATIVE EXCLUDES NOTHING IS NOT A TEST FOR 'REACHING THE DIAGNOSIS'.\n\n"
    "WARNING: PLEURAL FLUID ADA — the tempting option, and genuinely useful in practice. A high ADA (usually above 40 U/L) makes tuberculosis very likely. BUT ADA IS A SUPPORTIVE TEST, NOT A DIAGNOSTIC ONE: it also rises in lymphoma and empyema, and more importantly IT GIVES NO SUSCEPTIBILITY DATA.\n\n"
    "PPD — the worst option, for a reason students often miss: IN TUBERCULOUS PLEURISY THE PPD CAN BE NEGATIVE IN UP TO A THIRD OF CASES, because the sensitised lymphocytes have gathered in the pleural space. A NEGATIVE PPD NEVER EXCLUDES TUBERCULOUS PLEURISY.",
    ["بازده زیر ۱۰٪؛ منفی بودنش هیچ چیز را رد نمی‌کند.",
     "پاسخ صحیح — باسیل‌ها در پرده‌ی پلورند نه در مایع؛ بازده بیوپسی ۷۰ تا ۸۰٪.",
     "آزمون حمایتی مفید است ولی تشخیص قطعی و آنتی‌بیوگرام نمی‌دهد.",
     "در پلورزی سلی تا یک‌سوم موارد منفی است و بیماری را رد نمی‌کند."],
    ["A yield under 10 %; a negative result excludes nothing.",
     "Correct — the bacilli are in the pleural membrane, not the fluid; biopsy yields 70 to 80 %.",
     "A useful supportive test but not diagnostic, and it gives no susceptibility data.",
     "Negative in up to a third of cases of tuberculous pleurisy; it excludes nothing."],
    "**در سل، بافت را نمونه بگیر نه ترشح را — پلور و غده، هر دو.**",
    "In tuberculosis, sample the tissue and not the secretion — pleura and lymph node alike.",
    REFS)

add("book:214", "vignette", "medium",
    "**اسمیر و کشت مایع پلور به‌همراه بیوپسی پلور: هر دو با هم.**",
    "Smear and culture of the pleural fluid TOGETHER WITH pleural biopsy: both at once.",
    PLEUR_FA + [
        "⚠️ **در پلورزی سلی، بهترین راهبرد ترکیب است، نه انتخاب یکی.**",
        "**بیوپسی برای بازده بالا، و کشت برای آنتی‌بیوگرام.**",
    ],
    PLEUR_EN + [
        "WARNING: IN TUBERCULOUS PLEURISY THE BEST STRATEGY IS COMBINATION, NOT CHOOSING ONE.",
        "Biopsy for the high yield, and culture for the susceptibility result.",
    ],
    "این سؤال، نسخه‌ی پیشرفته‌تر سؤال قبل است، و یک درس اضافه دارد.\n\n"
    "⚠️ **نکته‌ی داده‌ای: در متن اصلی کتاب، چهار عدد این ویگنت آسیب دیده بود** "
    "(LDH مایع فقط «۲»، LDH سرم «۰۰۵»، و قند «۰۶»). با بازخوانی گلیف‌های صفحه‌ی ۸۴، "
    "مقادیر چاپ‌شده بازیابی شدند: **LDH مایع ۲۰۰۰، LDH سرم ۵۰۰، قند ۶۰**. "
    "**بدون این اعداد، ویگنت اصلاً قابل تحلیل نبود.**\n\n"
    "**بیمار: مرد با سرفه، تب، تنگی نفس، تعریق و کاهش وزن از یک ماه قبل. در CT، "
    "پلورال افیوژن راست بدون درگیری پارانشیم. آنالیز مایع: LDH=2000 (سرم ۵۰۰)، قند "
    "۶۰، پروتئین ۴ (سرم ۲٫۵)، WBC=2000 با ۹۰٪ لنفوسیت. سابقه‌ی تماس نزدیک با بیمار "
    "مسلول.**\n\n"
    "**اول، معیارهای لایت را اجرا کنید:**\n\n"
    "**نسبت LDH مایع به سرم = ۲۰۰۰ ÷ ۵۰۰ = ۴** — بسیار بالاتر از آستانه‌ی **۰٫۶**.\n\n"
    "**نسبت پروتئین مایع به سرم = ۴ ÷ ۲٫۵ = ۱٫۶** — بسیار بالاتر از آستانه‌ی **۰٫۵**.\n\n"
    "**پس مایع قطعاً اگزودا است.** و **۹۰٪ لنفوسیت** با **قند ۶۰ (پایین)** و **سابقه‌ی "
    "تماس با مسلول**، تشخیص را عملاً قفل می‌کند.\n\n"
    "**نکته‌ی رادیولوژیک مهم: «بدون درگیری پارانشیم».** این یعنی **خلط تشخیصی نخواهد "
    "بود** — چون هیچ ضایعه‌ی پارانشیمی وجود ندارد که باسیل را به راه هوایی برساند.\n\n"
    "**حالا چرا پاسخ، ترکیب «اسمیر و کشت مایع + بیوپسی» است و نه فقط بیوپسی؟**\n\n"
    "⚠️ **چون دو هدف متفاوت داریم و یک آزمون هر دو را نمی‌دهد:**\n\n"
    "**بیوپسی پلور** بالاترین **بازده تشخیصی** را دارد (۷۰ تا ۸۰٪) — گرانولوم کازئوزکننده "
    "را نشان می‌دهد و تشخیص را همان روز می‌سازد.\n\n"
    "**کشت** تنها راه گرفتن **آنتی‌بیوگرام** است. در دنیایی که MDR-TB واقعیت روزمره "
    "است، شروع درمان شش‌ماهه بدون دانستن حساسیت دارویی، ریسک بزرگی است.\n\n"
    "**پس هر دو را با هم می‌فرستید. و در عمل، نمونه‌ی بیوپسی را هم کشت می‌دهید — که "
    "بازده کشت را باز هم بالاتر می‌برد.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**بیوپسی + PPD** — بیوپسی درست است ولی **PPD چیزی اضافه نمی‌کند**: در پلورزی سلی "
    "تا یک‌سوم موارد منفی است، و مثبت بودنش هم در کشور اندمیک تشخیصی نیست.\n\n"
    "**اسمیر مایع + IGRA سرم** — هر دو ضعیف‌اند. اسمیر زیر ۱۰٪، و **IGRA فقط عفونت را "
    "نشان می‌دهد نه بیماری فعال را** — و در کشور با شیوع بالا، بخش بزرگی از جمعیت "
    "IGRA مثبت دارند.\n\n"
    "**اسمیر و کشت خلط** — در بیماری که صراحتاً **بدون درگیری پارانشیم** است، خلط "
    "چیزی برای عرضه ندارد.",
    "This is the advanced version of the previous question, and it carries one extra lesson.\n\n"
    "WARNING, A DATA NOTE: in the source text four numbers in this vignette were corrupted (pleural LDH reduced to '2', serum LDH shown as '005', glucose as '06'). Re-reading the glyphs of page 84 recovered the printed values: PLEURAL LDH 2000, SERUM LDH 500, GLUCOSE 60. WITHOUT THOSE NUMBERS THE VIGNETTE CANNOT BE ANALYSED AT ALL.\n\n"
    "THE PATIENT: a man with cough, fever, breathlessness, sweats and weight loss for a month. CT shows a right pleural effusion WITHOUT PARENCHYMAL INVOLVEMENT. Fluid analysis: LDH 2000 (serum 500), glucose 60, protein 4 (serum 2.5), WBC 2000 with 90 % LYMPHOCYTES. History of close contact with a tuberculosis patient.\n\n"
    "FIRST, APPLY LIGHT'S CRITERIA:\n\n"
    "PLEURAL-TO-SERUM LDH RATIO = 2000 / 500 = 4, far above the 0.6 threshold.\n\n"
    "PLEURAL-TO-SERUM PROTEIN RATIO = 4 / 2.5 = 1.6, far above the 0.5 threshold.\n\n"
    "SO THE FLUID IS DEFINITELY AN EXUDATE. And 90 % LYMPHOCYTES with a LOW GLUCOSE OF 60 and a HISTORY OF CONTACT effectively lock the diagnosis.\n\n"
    "AN IMPORTANT RADIOLOGICAL POINT: 'WITHOUT PARENCHYMAL INVOLVEMENT'. That means SPUTUM WILL NOT BE DIAGNOSTIC — there is no parenchymal lesion to deliver bacilli into the airway.\n\n"
    "NOW WHY IS THE ANSWER THE COMBINATION 'FLUID SMEAR AND CULTURE PLUS BIOPSY' RATHER THAN BIOPSY ALONE?\n\n"
    "WARNING: BECAUSE WE HAVE TWO DIFFERENT GOALS AND NO SINGLE TEST DELIVERS BOTH.\n\n"
    "PLEURAL BIOPSY has the highest DIAGNOSTIC YIELD (70 to 80 %) — it shows the caseating granuloma and makes the diagnosis the same day.\n\n"
    "CULTURE is the only route to a SUSCEPTIBILITY RESULT. In a world where MDR-TB is an everyday reality, starting six months of therapy without knowing susceptibility is a large risk.\n\n"
    "SO YOU SEND BOTH. And in practice you also culture the biopsy specimen, which raises the culture yield further still.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "BIOPSY PLUS PPD — the biopsy is right but THE PPD ADDS NOTHING: it is negative in up to a third of tuberculous pleurisy, and a positive result is not diagnostic in an endemic country.\n\n"
    "FLUID SMEAR PLUS SERUM IGRA — both are weak. The smear yields under 10 %, and IGRA SHOWS INFECTION, NOT ACTIVE DISEASE — in a high-prevalence country a large fraction of the population is IGRA-positive.\n\n"
    "SPUTUM SMEAR AND CULTURE — in a patient explicitly described as having NO PARENCHYMAL INVOLVEMENT, sputum has nothing to offer.",
    ["بیوپسی درست است ولی PPD چیزی اضافه نمی‌کند و تا یک‌سوم موارد منفی است.",
     "اسمیر مایع زیر ۱۰٪ بازده دارد و IGRA بیماری فعال را از عفونت نهفته جدا نمی‌کند.",
     "پاسخ صحیح — بیوپسی برای بازده بالا و کشت برای آنتی‌بیوگرام، هر دو با هم.",
     "بیمار صراحتاً بدون درگیری پارانشیم است؛ خلط چیزی برای عرضه ندارد."],
    ["The biopsy is right but the PPD adds nothing and is negative in up to a third of cases.",
     "Fluid smear yields under 10 %, and IGRA cannot separate active disease from latent infection.",
     "Correct — biopsy for the high yield and culture for susceptibility, both together.",
     "The patient explicitly has no parenchymal involvement; sputum has nothing to offer."],
    "**بیوپسی تشخیص را می‌دهد، کشت آنتی‌بیوگرام را — هر دو را با هم بفرست.**",
    "Biopsy gives the diagnosis, culture gives the susceptibility — send both together.",
    REFS)

json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book51.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 51 lessons:', len(L))
