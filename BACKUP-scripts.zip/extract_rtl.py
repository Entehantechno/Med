# -*- coding: utf-8 -*-
"""Extract booklet text with numbers that are actually correct.

The bug this fixes
------------------
Every earlier pass read these PDFs with pypdf, which returns the glyphs in
*visual* order. For Persian that means the letters of each line come out
right-to-left — readable enough that the text looked fine — but the DIGITS
inside the line come out reversed too, silently. So "خانم ۶۰ ساله" became
"خانم06 ساله", a lab value of 85000 became 00058, and "T:39" became "93:T".

Letters were being un-reversed by the reader's eye; numbers were not. In a
question bank that is dangerous: a 25-year-old and a 52-year-old are different
patients, and a creatinine of 1.5 is not 5.1.

The fix
-------
pdfplumber gives us the whole line still in visual order. Reversing the line
restores logical order for the Persian text AND puts each number's digits back
the wrong way round — so after reversing the line we reverse each digit run
once more. Both operations together leave every number correct:

    raw     "003- خانم06 ساله ... 00058=tlP"     (visual)
    reverse "Plt=85000 ... خانم60 ساله -300"     (logical, digits flipped)
    fix nums "Plt=85000 ... خانم60 ساله -300"    (digits restored)

Latin words come out reversed by the same mechanism ("desufnoc" for
"confused"), so runs of Latin letters get the same treatment.

Verified against the printed PDF: page 24 of Shahrivar-1403 shows a 60-year-old
woman and Plt=85000, which is exactly what this produces.
"""
import json, os, re, sys, glob, unicodedata
import pdfplumber

HERE = os.path.dirname(os.path.abspath(__file__))
PDF, OUT = os.path.join(HERE, 'pdf'), os.path.join(HERE, 'rtl')
os.makedirs(OUT, exist_ok=True)

FA = r'\u0600-\u06FF'
NUM_RUN = re.compile(r'[0-9]+(?:[./,][0-9]+)*')
LATIN_RUN = re.compile(r"[A-Za-z][A-Za-z'-]*")
FA_CHAR = re.compile(f'[{FA}]')


def unreverse(line):
    """Turn one visually-ordered line into logically-ordered text.

    Reversing the line fixes the Persian. Latin words then need reversing back,
    because they were stored left-to-right and the line flip mirrored them.

    Numbers are the subtle part. The PDF stores a digit run left-to-right, so
    the line flip mirrors it too — EXCEPT that the extractor already emits a run
    that sits inside Persian text in its correct order (Persian embeds numbers
    LTR inside RTL text, and the exporter honours that). The discriminator is
    therefore what the run touches:

        "خانم60 ساله"     touching Persian  -> already correct, leave it
        "Plt=85000"       touching Latin    -> mirrored, flip it back
        "T:39" / "110/70" touching Latin    -> flip

    Both readings were checked against the printed page: Shahrivar-1403 p.24 is
    a 60-year-old woman with Plt 85000, BP 110/70, T 39 — which is what this
    produces.
    """
    s = line[::-1]
    s = LATIN_RUN.sub(lambda m: m.group(0)[::-1], s)

    def num(m):
        a, b = m.start(), m.end()
        prev = s[a - 1] if a else ' '
        nxt = s[b] if b < len(s) else ' '
        # Directly glued to a Persian letter ("خانم60") the exporter already
        # wrote the run in logical order, so the line flip left it correct.
        if FA_CHAR.match(prev) or FA_CHAR.match(nxt):
            return m.group(0)
        return m.group(0)[::-1]

    s = NUM_RUN.sub(num, s)

    # NOTE (bug fixed): there used to be an extra rule here that reversed any
    # 2-3 digit run sitting between a Persian letter and " ساله". That was
    # wrong, and it silently corrupted 220 of the 261 ages in the book and 93
    # of the 114 in the ministry booklet.
    #
    # The reason is that NUM_RUN.sub() above had ALREADY flipped those runs. In
    # the flipped line "خانم 52 ساله" the run's neighbours are spaces, not
    # Persian letters, so num() takes the `return m.group(0)[::-1]` branch and
    # restores 25. The age rule then flipped it a second time, back to 52.
    #
    # Proof, from the ministry's own bilingual sitting (Esfand 1400) where the
    # English booklet prints the age in Latin digits and cannot be mirrored:
    #     q3 -> 56 (not 65), q4 -> 45 (not 54), q7 -> 50 (not 05),
    #     q8 -> 75 (not 57), q9 -> 18 (not 81), q12 -> 60 (not 06)
    # The cross-check over the whole paired sitting is 90/90 once it is gone.
    #
    # Residual ambiguity (a leading zero, or an age the introducing noun
    # contradicts) is settled downstream by fix_ages.py, which reasons about
    # meaning rather than layout and refuses to guess when both readings work.
    def year(m):
        v, r = m.group(1), m.group(1)[::-1]
        if 1390 <= int(v) <= 1410:
            return v
        return r if 1390 <= int(r) <= 1410 else v

    s = re.sub(r'(?<![0-9])(\d{4})(?![0-9])', year, s)
    return s


PROBES = ('است', 'بیمار', 'کدام', 'ساله', 'مراجعه', 'زیر', 'شده', 'برای')


def is_visual(page_text):
    """Decide whether this page needs un-reversing.

    Persian in logical order contains common words spelled forwards ("است");
    in visual order it contains their mirrors ("تسا"). Counting both tells us
    which way round we are without hard-coding anything about the exporter.

    Some exporters additionally emit Arabic *presentation forms* (U+FE70-FEFF),
    where each letter carries its joining shape. Those probe words then match
    neither spelling, so we normalise a copy first — the check has to work on
    the letters, not on the glyph variants.
    """
    t = unicodedata.normalize('NFKC', page_text).translate(
        str.maketrans({'ي': 'ی', 'ك': 'ک'}))
    fwd = sum(t.count(w) for w in PROBES)
    rev = sum(t.count(w[::-1]) for w in PROBES)
    return rev > fwd


_DIGIT_FOLD = {}
for _i in range(10):
    _DIGIT_FOLD[chr(0x0660 + _i)] = str(_i)      # Arabic-Indic  ٠١٢٣٤٥٦٧٨٩
    _DIGIT_FOLD[chr(0x06F0 + _i)] = str(_i)      # Extended (Persian) ۰۱۲۳۴۵۶۷۸۹

AR_FOLD = str.maketrans({'ي': 'ی', 'ك': 'ک', 'ة': 'ه',
                         '\u200e': '', '\u200f': '', '\ufeff': '',
                         **_DIGIT_FOLD})


def fold(s):
    """Presentation forms -> base letters, so the text is searchable.

    Must run BEFORE unreverse: the joining-shape codepoints are what make a
    mirrored word unrecognisable, and the number rules below match on ordinary
    Persian letters.

    Digits are folded to ASCII here for a second, less obvious reason. This book
    mixes Arabic-Indic (U+0660..) and Persian (U+06F0..) digits into the SAME
    number as ASCII ones — a 52-year-old prints as "5٢". NUM_RUN only matches
    [0-9], so such a run was seen as two separate one-digit numbers, each of
    which reverses to itself; the value therefore survived the line flip in
    mirrored order and came out split. Folding every digit to ASCII before the
    flip makes the run a single token the ordinary rules handle correctly.
    """
    return unicodedata.normalize('NFKC', s).translate(AR_FOLD)


def page_lines(page):
    t = page.extract_text() or ''
    if not t.strip():
        return [], False
    t = fold(t)
    vis = is_visual(t)
    lines = t.split('\n')
    return ([unreverse(l) for l in lines] if vis else lines), vis


def run(tags):
    for tag in tags:
        path = os.path.join(PDF, f'{tag}.pdf')
        if not os.path.exists(path):
            print(f'{tag:14} no pdf')
            continue
        out_pages, n_vis = [], 0
        with pdfplumber.open(path) as pdf:
            for i, page in enumerate(pdf.pages, 1):
                lines, vis = page_lines(page)
                n_vis += bool(vis)
                out_pages.append({'page': i, 'visual': bool(vis), 'lines': lines})
        chars = sum(len(l) for p in out_pages for l in p['lines'])
        json.dump({'tag': tag, 'pages': out_pages, 'visual_pages': n_vis},
                  open(os.path.join(OUT, f'{tag}.json'), 'w', encoding='utf-8'),
                  ensure_ascii=False)
        print(f'{tag:14} {len(out_pages):3} pages ({n_vis} visual) {chars:6} chars')


if __name__ == '__main__':
    tags = sys.argv[1:] or sorted(os.path.basename(p)[:-4] for p in glob.glob(os.path.join(PDF, '*.pdf')))
    run(tags)
