# -*- coding: utf-8 -*-
"""English stems and options for the batch-36 questions.

HIV part three (the testing chain, opportunistic infections and prophylaxis)
plus the hepatitis serology block.

Rule 16 checked first, as always: these items come from sittings 93 to 98, for
which the ministry published no English booklet, so these are hand-written
translations rather than official ones.

Translation decisions worth recording
-------------------------------------
THE COUNT OF POSITIVES IS LOAD-BEARING throughout the testing cluster, and is
translated with obsessive literalness. q9692 says "on two occasions" and q9693
says "the repeat EIA was also reported positive", and those phrases are the
ONLY thing separating the questions whose answer is REPEAT from those whose
answer is CONFIRM. Any smoothing of them would destroy the cluster.

q9683's discordant result is rendered as "one test was positive and a second
was negative", preserving the order, because the order is what makes it
discordant rather than simply negative.

q9852 CARRIES A SOURCE UNIT ERROR. The Persian prints "5 international units
per millilitre" where anti-HBs is reported in mIU/mL. The English preserves the
printed unit exactly as the book has it, because the stem must say what the
paper said; the lesson explains that the intended value is 5 mIU/mL, below the
protective threshold of 10, which is what makes the printed key correct. See
flag_source_errors_hiv.py.

q9854 CARRIES A SOURCE PANEL ERROR — the direct bilirubin exceeds the total.
The English reproduces the panel exactly as printed, for the same reason. The
serology, which actually decides the question, is transcribed marker by marker.

THE SEROLOGICAL MARKER NAMES keep their standard English forms — HBsAg, HBeAg,
anti-HBc, anti-HAV, anti-HCV, IgM — because that is how they appear on a
request form, and every one of these questions turns on telling them apart.

CD4 VALUES are preserved exactly (99, 180, 150, 95, 300, 550) because each one
places the patient on a specific rung of the CD4 ladder and is the whole
content of its question.
"""

EN18 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    assert all(o.strip() for o in options), idx
    EN18[idx] = {"stem_en": stem, "options_en": options}


# ============================================ the testing chain (batch 36)
add(676,
    "A 26-year-old man with a history of injecting drug use presents with prolonged fever, "
    "generalised lymphadenopathy and weight loss. On investigation his HIV ELISA is reported "
    "positive. For the further work-up required, which of the following tests do you consider "
    "appropriate?",
    ["Western blot",
     "A repeat ELISA",
     "p24 antigen",
     "PCR"])

add(677,
    "A patient with a history of injecting drug use comes to you with one positive HIV1/HIV2 enzyme "
    "immunoassay (EIA). What is your next requested test to diagnose HIV infection?",
    ["Repeat the HIV1/HIV2 EIA",
     "Request a Western blot",
     "Perform an HIV-RNA PCR",
     "Given the history of addiction, this single test is enough for the diagnosis"])

add(678,
    "A 45-year-old man is referred to you, the physician at the city health centre, with a letter "
    "from the blood bank stating that his HIV 1&2 ELISA was positive on screening at blood donation. "
    "The patient has no clinical signs or symptoms and gives no history of high-risk behaviour. "
    "Which action do you consider appropriate at the next stage?",
    ["Repeat the HIV 1&2 ELISA and exclude the diagnosis if it is negative",
     "Repeat the HIV 1&2 ELISA and, if negative, perform an HIV RNA PCR",
     "Repeat the HIV 1&2 ELISA and, if positive, perform an HIV-1 Western blot",
     "Perform an HIV-1 Western blot"])

add(679,
    "A young woman discovers during her antenatal tests that her HIV antibody EIA is positive and "
    "comes to you anxious about it. Which action is more appropriate for her?",
    ["Reassure her that the positive test is due to pregnancy and is false",
     "Repeat the EIA test a second time",
     "Request a Western blot to establish the diagnosis of HIV",
     "Request an HIV RNA PCR to confirm or exclude the diagnosis"])

add(680,
    "A 25-year-old with a history of high-risk behaviour over the past two years was investigated "
    "for possible HIV infection, and his HIV antibody ELISA was positive. What is the next step?",
    ["Repeat the HIV Ab ELISA",
     "HIV RNA PCR",
     "Western blot",
     "p24"])

add(681,
    "In a person with high-risk behaviour, the HIV-1 ELISA has come back positive. What is the next "
    "step?",
    ["Perform a Western blot",
     "A CD4 cell count",
     "Measure the viral load",
     "Repeat the ELISA"])

add(682,
    "A nurse who had a needlestick injury from an HIV-positive patient about 3 months ago, and who "
    "received no drug prophylaxis, attends for follow-up. Her HIV-1 ELISA is reported positive. What "
    "is the next step?",
    ["Request a Western blot",
     "Request an HIV viral load",
     "Repeat the ELISA",
     "Start antiretroviral treatment"])

add(683,
    "A 27-year-old man who injects drugs wishes to be investigated for HIV infection. He states that "
    "he had one positive test which was negative on a second occasion. What do you advise him?",
    ["Repeat the test in 3 to 6 months",
     "Perform an HIV-1 Western blot",
     "Perform an HIV-2 Western blot",
     "No follow-up is needed"])

add(690,
    "A 37-year-old single man returning from a trip to Thailand, with high-risk behaviour and "
    "unprotected contact, presents with a positive anti-HIV ELISA. His Western blot is reported "
    "indeterminate. To confirm or exclude the diagnosis of HIV in this patient, all of the following "
    "are appropriate, EXCEPT:",
    ["Repeat the anti-HIV ELISA in four to six weeks",
     "A p24 antigen test",
     "Repeat the Western blot in 4 to 6 weeks",
     "Qualitative HIV RNA RT-PCR"])

add(692,
    "In a person who has injected drugs, the HIV ELISA has been reported positive on two occasions. "
    "For further follow-up, which of the following diagnostic actions do you choose?",
    ["A Western blot test",
     "PCR for HIV",
     "A CD4+ cell count",
     "Measurement of the p24 antigen"])

add(693,
    "A young man is referred to you by the blood bank because of a positive HIV screening test. He "
    "has no history of high-risk sexual behaviour or injecting drug use. He currently has no clinical "
    "signs or symptoms. The repeat HIV 1,2 EIA has also been reported positive. Which action do you "
    "consider more appropriate at this stage?",
    ["Perform a rapid HIV test",
     "Repeat the HIV-1/HIV-2 EIA in four weeks",
     "Request an HIV-1 Western blot",
     "Request a p24 antigen test"])


# ================================ acute infection: the p24 window (batch 36)
add(686,
    "A young man develops fever, sore throat and muscle and joint pains. Given a history of "
    "unprotected sexual activity, which of the following tests is the investigation of choice for "
    "diagnosing HIV at this stage?",
    ["p24 Ag capture assay",
     "Anti-HIV Ab ELISA",
     "HIV cell culture",
     "Anti-HIV Ab Western blot"])

add(688,
    "A 27-year-old woman presents with fever, sore throat and lymphadenopathy for the past 8 days. "
    "She had high-risk sexual behaviour about 3 weeks ago. With a suspected retroviral syndrome, "
    "which test is more helpful to request?",
    ["Western blot",
     "p24 Ag",
     "HIV Ab",
     "Rapid test"])

add(689,
    "A 26-year-old with a history of suspicious sexual contact last month presents with fever, "
    "chills, sore throat, joint and muscle pains together with generalised lymphadenopathy. Which "
    "test do you request to diagnose HIV at this stage?",
    ["A CD4 count",
     "Lymph node biopsy",
     "HIV serology",
     "Serum p24 Ag"])


# =========================== opportunistic infection and prophylaxis (batch 36)
add(694,
    "Which of the following tests would you NOT request in the initial evaluation of an HIV-positive "
    "person?",
    ["VDRL",
     "FBS",
     "Bilirubin",
     "HLA-B27"])

add(696,
    "A 36-year-old HIV-positive patient has had fever and oral thrush for the past two months and has "
    "lost more than 10 per cent of his weight. Which of the following actions is preferable?",
    ["Start three-drug antiretroviral therapy immediately",
     "Count the CD4 and start antiviral treatment if the CD4 is below 200 per mL",
     "Measure the HIV viral load and start treatment if the viral load is above 10 to the power of 5 "
     "copies per millilitre",
     "All of the above are correct"])

add(697,
    "In young HIV-positive men whose CD4 lymphocytes are 300 per microlitre of blood, which of the "
    "following vaccines is recommended?",
    ["Haemophilus influenzae",
     "Pneumococcus",
     "Meningococcus",
     "Varicella"])

add(698,
    "An HIV-positive patient who has been on neither antiretroviral treatment nor prophylaxis "
    "presents with a dry cough, retrosternal chest pain and fever for the past month (CD4 = 180). "
    "The chest radiograph performed is normal. What is the most likely causative agent?",
    ["Mycobacterium tuberculosis",
     "Mycobacterium avium complex",
     "Pneumocystis jirovecii",
     "Aspergillus"])

add(699,
    "An HIV-positive patient with a CD4 of 150 presents with a dry cough and chest pain on "
    "inspiration. The patient is febrile and his tests show a high LDH. His chest radiograph is "
    "normal. Given the diagnosis, what is the initial treatment for this patient?",
    ["Ciprofloxacin",
     "Co-trimoxazole",
     "Rifampin",
     "Doxycycline"])

add(701,
    "On laboratory investigation of a patient with HIV, the CD4 count is reported as 95. "
    "Co-trimoxazole is started to prevent PCP. Against which of the following does this regimen also "
    "have a preventive effect?",
    ["Salmonella species",
     "Mycobacterium avium",
     "Toxoplasma",
     "Mycobacterium tuberculosis"])

add(703,
    "Which of the following is LESS likely as a CNS opportunistic infection in patients with HIV "
    "infection?",
    ["Toxoplasma",
     "Cryptococcus",
     "Histoplasmosis",
     "Amoebiasis"])

add(705,
    "In a patient with advanced AIDS, to prevent opportunistic infections when the CD4 is below 50, "
    "which of the following prophylactic approaches is better to prescribe?",
    ["Azithromycin",
     "Azithromycin + co-trimoxazole",
     "Azithromycin + co-trimoxazole + fluconazole",
     "Azithromycin + co-trimoxazole + fluconazole + ganciclovir"])

add(708,
    "In coinfection with HIV and tuberculosis, all of the following statements are correct, EXCEPT:",
    ["In patients with a CD4 above 200, the sputum smear is positive in most cases",
     "The tuberculin skin test is negative in most patients with a CD4 above 200",
     "In patients with a CD4 below 200, the pulmonary involvement usually resembles primary "
     "pulmonary tuberculosis",
     "In patients with a CD4 below 200, the pulmonary involvement is most often non-cavitary "
     "infiltration"])

add(709,
    "A 26-year-old HIV-positive man who has been under follow-up for the past 2 years presents with "
    "fever, cough and rusty sputum for the past 3 days. On examination he is severely unwell and his "
    "body temperature is 39.5 degrees centigrade. His chest radiograph shows lobar infiltration at "
    "the base of the right lung. His most recent CD4 report, from 10 days ago, is 550 cells per "
    "microlitre. Which of the following do you prefer for treating this patient?",
    ["Send sputum for smear and culture and start oral co-trimoxazole",
     "Start empirical treatment for community-acquired pneumonia and start ART (anti-HIV treatment) "
     "at the same time",
     "Send sputum for smear and culture and start ART (anti-HIV treatment)",
     "Treat the patient's pneumonia without regard to his HIV status"])

add(645,
    "A 15-month-old HIV-positive infant is referred to you from the health centre to assess the "
    "appropriate time to receive the MMR vaccine. The CD4 is 99. What is your recommendation for "
    "vaccination?",
    ["Give the MMR vaccine immediately",
     "Postpone the MMR vaccine until 24 months of age",
     "Decide after performing anti-rubella IgM and anti-measles IgM serology",
     "The MMR vaccine is contraindicated in this infant"])


# ==================================================== hepatitis (batch 36)
add(846,
    "A young woman in the second trimester of pregnancy is referred to you. Her screening tests "
    "report a positive HBsAg. She has no symptoms or complaints and gives no past history of "
    "jaundice. All of the following tests help establish her status, EXCEPT:",
    ["HBeAg",
     "Anti-HBc",
     "ALT",
     "INR"])

add(847,
    "A young woman in the third month of pregnancy presents with a positive HBsAg test. She recalls "
    "no history of jaundice in herself or those around her and is currently without any complaint or "
    "symptom. Which of the following tests is NOT helpful in assessing her current status and "
    "planning her follow-up?",
    ["INR and ALT",
     "HBV DNA",
     "Anti-HBc",
     "HBeAg"])

add(852,
    "An intern who has previously received three doses of hepatitis B vaccine, and whose blood "
    "antibody level one month after the last dose was 5 international units per millilitre of blood, "
    "sustains a needlestick injury with blood from a patient with hepatitis B while taking blood. To "
    "prevent hepatitis B infection, which of the following actions is preferable?",
    ["No action is needed",
     "Give three doses of hepatitis B vaccine",
     "Give hepatitis B hyperimmune globulin (HBIG)",
     "Give three doses of vaccine together with HBIG"])

add(854,
    "A patient presents with anorexia and abdominal pain for about the past 10 days and is "
    "investigated for possible hepatitis. The tests give the following results: ALT 1300, AST 1100, "
    "Bil Total 1.5 mg/dl, Bil Direct 3.5 mg/dl, anti-HBc IgM positive, anti-HAV IgM positive, HBsAg "
    "positive, anti-HCV negative. Which diagnosis applies to this patient?",
    ["He has acute hepatitis A",
     "He is an inactive hepatitis B carrier who has developed acute hepatitis A",
     "He has a past history of hepatitis A and has developed acute hepatitis B",
     "He has developed acute hepatitis A and B"])
