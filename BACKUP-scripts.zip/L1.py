# -*- coding: utf-8 -*-
"""Infectious-diseases micro-lessons, batch 1 — Azar-1404 (items 103-108).

English stems/options are NOT written here: they came verbatim from the
ministry's official English booklet and must not be overwritten.
Reference: Harrison's Principles of Internal Medicine, 21st ed (official 1405 syllabus).
"""
import json, io, os
L = {}

L["1404-09:103"] = {
 "style": "case", "difficulty": "hard",
 "micro": {
  "lead_fa": "گامتوسیت موزی‌شکل = فالسیپاروم. زردی، ادرار قهوه‌ای یا خواب‌آلودگی = مالاریای شدید = آرتسونات تزریقی.",
  "lead_en": "Banana-shaped gametocytes mean falciparum. Jaundice, dark urine or drowsiness mean severe malaria and parenteral artesunate.",
  "points_fa": [
   "مالاریا را با لام خون محیطی تشخیص می‌دهیم و شکل انگل، گونه را مشخص می‌کند.",
   "گامتوسیت هلالی یا موزی‌شکل فقط در پلاسمودیوم فالسیپاروم دیده می‌شود.",
   "فالسیپاروم تنها گونه‌ای است که مالاریای کشنده و مغزی می‌سازد.",
   "در ایران، مناطق آندمیک جنوب شرق یعنی سیستان و بلوچستان، هرمزگان و کرمان است.",
   "پس از تشخیص گونه، گام دوم تعیین شدید بودن یا نبودن بیماری است.",
   "معیارهای مالاریای شدید: اختلال هوشیاری، تشنج، زردی، نارسایی کلیه.",
   "معیارهای دیگر: هیپوگلیسمی، ادم ریه، شوک، خون‌ریزی و پارازیتمی بالای پنج درصد.",
   "ادرار قهوه‌ای نشانه‌ی همولیز شدید و هموگلوبینوری است (تب سیاه‌آب).",
   "در مالاریای شدید، آرتسونات وریدی مرگ‌ومیر را نسبت به کینین حدود یک‌سوم کم می‌کند."
  ],
  "points_en": [
   "Malaria is diagnosed on a peripheral blood smear, and the parasite's shape identifies the species.",
   "Crescent or banana-shaped gametocytes are seen only in Plasmodium falciparum.",
   "Falciparum is the only species that causes fatal and cerebral malaria.",
   "In Iran the endemic areas are the south-east: Sistan-Baluchistan, Hormozgan and Kerman.",
   "After identifying the species, the second step is deciding whether the disease is severe.",
   "Severe malaria criteria: impaired consciousness, seizures, jaundice, renal failure.",
   "Further criteria: hypoglycaemia, pulmonary oedema, shock, bleeding and parasitaemia over five percent.",
   "Dark urine indicates severe haemolysis and haemoglobinuria (blackwater fever).",
   "In severe malaria, intravenous artesunate cuts mortality by roughly a third compared with quinine."
  ]
 },
 "explanation_fa": "این سؤال دو تصمیم پشت سر هم می‌خواهد و اگر فقط یکی را بگیرید پاسخ را از دست می‌دهید. تصمیم اول تعیین گونه است: گامتوسیت موزی‌شکل در لام، امضای اختصاصی فالسیپاروم است و سفر به مرز بلوچستان هم منطقه‌ی آندمیک را تأیید می‌کند. تصمیم دوم و مهم‌تر، تعیین شدت بیماری است. صورت سؤال سه معیار مالاریای شدید را همزمان داده است: اسکلرای ایکتریک یعنی زردی، ادرار قهوه‌ای یعنی همولیز و هموگلوبینوری، و خواب‌آلودگی یعنی اختلال هوشیاری. وجود حتی یکی از این‌ها کافی است تا بیماری «شدید» طبقه‌بندی شود. قاعده‌ی درمانی روشن است: در مالاریای شدید، جذب گوارشی قابل اعتماد نیست و تأخیر کشنده است، پس هر درمان خوراکی رد می‌شود و آرتسونات تزریقی داروی انتخابی است.",
 "explanation_en": "This item asks for two decisions in sequence, and taking only one loses the answer. The first is the species: banana-shaped gametocytes on the smear are the specific signature of falciparum, and travel to the Baluchistan border confirms an endemic area. The second and more important decision is severity. The stem supplies three severe-malaria criteria at once: icteric sclera means jaundice, brown urine means haemolysis and haemoglobinuria, and drowsiness means impaired consciousness. Any single one of these is enough to classify the disease as severe. The treatment rule is then clear: in severe malaria gastrointestinal absorption is unreliable and delay is lethal, so every oral option is excluded and parenteral artesunate is the drug of choice.",
 "why_fa": [
  "داکسی‌سایکلین در مالاریا فقط داروی کمکی و همراه است، نه درمان اصلی، و به‌تنهایی اثر سریع کافی ندارد.",
  "پاسخ صحیح — در مالاریای شدید فالسیپاروم، آرتسونات تزریقی درمان انتخابی است و باید فوراً شروع و بیمار به مرکز مجهزتر منتقل شود.",
  "آرتمتر-لومفانترین خوراکی درمان مالاریای بدون عارضه است. در بیمار خواب‌آلود و زردشده، درمان خوراکی خطرناک و ناکافی است.",
  "هیدروکسی‌کلروکین برای فالسیپاروم مقاوم بی‌اثر است و در مالاریای شدید هیچ جایگاهی ندارد."
 ],
 "why_en": [
  "Doxycycline is only a companion drug in malaria, not the main treatment, and alone it acts too slowly.",
  "Correct — in severe falciparum malaria, parenteral artesunate is the treatment of choice and must be started at once while transferring the patient.",
  "Oral artemether-lumefantrine treats uncomplicated malaria. In a drowsy, jaundiced patient oral therapy is dangerous and insufficient.",
  "Hydroxychloroquine is ineffective against resistant falciparum and has no place in severe malaria."
 ],
 "golden_fa": "موزی‌شکل = فالسیپاروم. زردی/ادرار قهوه‌ای/خواب‌آلودگی = شدید = آرتسونات وریدی، نه خوراکی.",
 "golden_en": "Banana-shaped means falciparum; jaundice, dark urine or drowsiness mean severe, so IV artesunate, never oral.",
 "refs": [
  "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 224: Malaria",
  "WHO Guidelines for the treatment of malaria, severe malaria: parenteral artesunate"
 ]
}

L["1404-09:104"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "بوتولیسم بیماری توکسین است نه باکتری، پس تشخیص قطعی هم یافتن توکسین در سرم است.",
  "lead_en": "Botulism is a toxin disease, not a bacterial one, so confirmation means finding the toxin in serum.",
  "points_fa": [
   "بوتولیسم غذایی از خوردن توکسین از پیش ساخته‌شده در غذای کنسروشده می‌آید.",
   "کنسرو خانگی محیط بی‌هوازی ایده‌آل برای کلستریدیوم بوتولینوم است.",
   "توکسین آزادسازی استیل‌کولین را در پایانه‌ی پیش‌سیناپسی مسدود می‌کند.",
   "نتیجه فلج شل است، نه اسپاستیک، چون انتقال عصبی-عضلانی قطع می‌شود.",
   "فلج از اعصاب کرانیال شروع می‌شود: تاری دید، دوبینی، پتوز، دیسفاژی و دیزآرتری.",
   "سپس به‌صورت قرینه و پایین‌رونده به تنه و اندام‌ها می‌رسد.",
   "حس همیشه سالم می‌ماند و بیمار تب ندارد؛ این دو نکته‌ی افتراقی مهم‌اند.",
   "تشخیص قطعی با سنجش توکسین در سرم (و در صورت امکان مدفوع و خود غذا) است.",
   "درمان با آنتی‌توکسین است و نباید منتظر نتیجه‌ی آزمایش ماند."
  ],
  "points_en": [
   "Foodborne botulism comes from eating preformed toxin in canned food.",
   "Home canning creates the ideal anaerobic environment for Clostridium botulinum.",
   "The toxin blocks acetylcholine release at the presynaptic terminal.",
   "The result is flaccid, not spastic, paralysis because neuromuscular transmission fails.",
   "Paralysis starts with the cranial nerves: blurred vision, diplopia, ptosis, dysphagia and dysarthria.",
   "It then descends symmetrically to the trunk and limbs.",
   "Sensation always stays intact and the patient is afebrile; both are key discriminators.",
   "Confirmation is by toxin assay in serum (and where possible stool and the food itself).",
   "Treatment is antitoxin and must not wait for the laboratory result."
  ]
 },
 "explanation_fa": "برای رسیدن به پاسخ باید بدانید بیماری از کجا می‌آید. بوتولیسم غذایی برخلاف بیشتر عفونت‌های گوارشی، از تکثیر باکتری در بدن ناشی نمی‌شود؛ بیمار توکسینی را می‌خورد که از قبل در غذا ساخته شده است. همین یک جمله انتخاب آزمون تشخیصی را تعیین می‌کند: اگر عامل بیماری توکسین است، باید دنبال خود توکسین بگردیم، نه دنبال باکتری. سنجش توکسین در سرم استاندارد طلایی است. کشت مدفوع یا PCR ممکن است باکتری را نشان دهند اما در بوتولیسم غذایی بزرگسال حساسیت کمتری دارند و پاسخشان دیر می‌رسد. پونکسیون کمری هم بی‌ربط است؛ در بوتولیسم مایع نخاعی طبیعی است و همین آن را از گیلن باره جدا می‌کند که در آن پروتئین بالا می‌رود. نکته‌ی حیاتی بالینی: نمونه را بگیرید ولی درمان با آنتی‌توکسین را به تأخیر نیندازید.",
 "explanation_en": "To reach the answer you must know where the illness comes from. Unlike most gastrointestinal infections, foodborne botulism does not arise from bacteria multiplying in the body; the patient swallows toxin already formed in the food. That single fact determines the diagnostic test: if the toxin causes the disease, look for the toxin itself, not the organism. Serum toxin assay is the gold standard. Stool culture or PCR may show the organism but are less sensitive in adult foodborne botulism and return too late. Lumbar puncture is irrelevant; the CSF is normal in botulism, which is exactly what separates it from Guillain-Barre syndrome, where protein rises. The vital clinical point: take the sample, but never delay the antitoxin for it.",
 "why_fa": [
  "PCR مدفوع می‌تواند وجود باکتری را نشان دهد اما در بوتولیسم غذایی بزرگسال حساسیت پایینی دارد و علت بیماری توکسین است نه باکتری.",
  "کشت مدفوع کند است و در فرم غذایی بزرگسال اغلب منفی می‌شود، چون باکتری لزوماً در روده کلونیزه نشده است.",
  "مایع مغزی نخاعی در بوتولیسم طبیعی است. این آزمون برای افتراق از گیلن باره کمک‌کننده است اما تشخیص بوتولیسم را نمی‌گذارد.",
  "پاسخ صحیح — سنجش توکسین در سرم، استاندارد طلایی تشخیص بوتولیسم است، چون توکسین عامل مستقیم بیماری است."
 ],
 "why_en": [
  "Stool PCR can show the organism but has low sensitivity in adult foodborne botulism, and the cause is the toxin, not the bacterium.",
  "Stool culture is slow and often negative in the adult foodborne form, because the gut is not necessarily colonised.",
  "The CSF is normal in botulism. The test helps exclude Guillain-Barre syndrome but does not establish botulism.",
  "Correct — serum toxin assay is the gold standard for botulism, because the toxin is the direct cause of the illness."
 ],
 "golden_fa": "کنسرو + فلج قرینه‌ی پایین‌رونده از اعصاب کرانیال = بوتولیسم = توکسین سرم. درمان منتظر آزمایش نماند.",
 "golden_en": "Canned food plus descending symmetric cranial-onset paralysis means botulism: serum toxin assay, and never delay treatment for it.",
 "refs": [
  "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 153: Botulism",
  "CDC clinical guidance: botulism diagnosis and antitoxin administration"
 ]
}

L["1404-09:105"] = {
 "style": "case", "difficulty": "hard",
 "micro": {
  "lead_fa": "کولیت آمیبی دو مرحله دارد: کشتن تروفوزوئیت بافتی، سپس پاک کردن کیست لومنی.",
  "lead_en": "Amoebic colitis needs two stages: kill the invasive trophozoites, then clear the luminal cysts.",
  "points_fa": [
   "آنتامبا هیستولیتیکا با تهاجم به مخاط روده‌ی بزرگ، کولیت و اسهال خونی می‌سازد.",
   "تصویر بالینی: اسهال مکرر با حجم کم، تنسموس، درد شکم و تب خفیف.",
   "در مدفوع هم گلبول سفید دیده می‌شود هم گلبول قرمز فراوان.",
   "دیدن تروفوزوئیت با گلبول قرمز بلعیده‌شده تشخیص را قطعی می‌کند.",
   "انگل در دو شکل زندگی می‌کند: تروفوزوئیت مهاجم در بافت و کیست در لومن.",
   "مترونیدازول یا تینیدازول تروفوزوئیت‌های بافتی را می‌کشد.",
   "اما این داروها در لومن روده غلظت کافی پیدا نمی‌کنند و کیست‌ها زنده می‌مانند.",
   "پس داروی لومینال مثل یدوکینول یا پارومومایسین باید اضافه شود.",
   "بدون مرحله‌ی دوم، بیمار حامل می‌ماند و بیماری عود می‌کند."
  ],
  "points_en": [
   "Entamoeba histolytica invades the colonic mucosa and causes colitis with bloody diarrhoea.",
   "Clinical picture: frequent small-volume diarrhoea, tenesmus, abdominal pain and low fever.",
   "The stool shows both white cells and abundant red cells.",
   "Seeing trophozoites with ingested red cells settles the diagnosis.",
   "The parasite lives in two forms: invasive trophozoites in tissue and cysts in the lumen.",
   "Metronidazole or tinidazole kills the tissue trophozoites.",
   "But those drugs do not reach adequate luminal concentrations, so cysts survive.",
   "A luminal agent such as iodoquinol or paromomycin must therefore be added.",
   "Without the second stage the patient stays a carrier and the disease relapses."
  ]
 },
 "explanation_fa": "این سؤال یک اصل درمانی را می‌آزماید که اگر بدانید، پاسخ در چند ثانیه پیدا می‌شود. آنتامبا هیستولیتیکا در دو جای مختلف بدن و در دو شکل متفاوت زندگی می‌کند: تروفوزوئیت‌های مهاجم که در دیواره‌ی روده هستند و علائم را می‌سازند، و کیست‌ها که در لومن روده می‌مانند و از راه مدفوع منتقل می‌شوند. هیچ داروی واحدی هر دو را به‌خوبی پوشش نمی‌دهد. مترونیدازول در بافت غلظت عالی پیدا می‌کند و تروفوزوئیت‌ها را می‌کشد، ولی چون سریع جذب می‌شود در لومن اثر کافی ندارد. اگر فقط همین را بدهید، بیمار علامتش خوب می‌شود اما کیست‌ها می‌مانند و هم عود می‌کند و هم ناقل باقی می‌ماند. پس درمان کامل حتماً دو دارویی است: یک نیتروایمیدازول برای بافت و یک داروی لومینال مثل یدوکینول.",
 "explanation_en": "This item tests one treatment principle, and knowing it finds the answer in seconds. Entamoeba histolytica lives in two places and two forms: invasive trophozoites in the bowel wall, which cause the symptoms, and cysts in the lumen, which are shed and transmit the infection. No single drug covers both well. Metronidazole reaches excellent tissue concentrations and kills trophozoites, but because it is absorbed quickly it does not act adequately in the lumen. Give only that and the patient improves symptomatically while the cysts persist, so the disease relapses and the patient stays infectious. Complete treatment is therefore always two drugs: a nitroimidazole for tissue plus a luminal agent such as iodoquinol.",
 "why_fa": [
  "مترونیدازول به‌تنهایی تروفوزوئیت‌های بافتی را می‌کشد اما کیست‌های لومنی را پاک نمی‌کند، پس عود و حامل ماندن رخ می‌دهد.",
  "یدوکینول به‌تنهایی فقط داروی لومینال است و روی تروفوزوئیت‌های مهاجم در دیواره‌ی روده اثر ندارد.",
  "تینیدازول سه روز به‌همراه پارومومایسین از نظر منطق درمانی درست است، اما دوره‌ی سه‌روزه‌ی تینیدازول برای کولیت مهاجم کوتاه است و رژیم استاندارد این سؤال نیست.",
  "پاسخ صحیح — مترونیدازول برای مرحله‌ی بافتی و یدوکینول برای مرحله‌ی لومنی، درمان کامل دو‌مرحله‌ای کولیت آمیبی است."
 ],
 "why_en": [
  "Metronidazole alone kills the tissue trophozoites but does not clear luminal cysts, so relapse and carriage follow.",
  "Iodoquinol alone is only a luminal agent and has no effect on the invasive trophozoites in the bowel wall.",
  "Tinidazole for three days plus paromomycin follows the right logic, but a three-day tinidazole course is short for invasive colitis and is not the standard regimen intended here.",
  "Correct — metronidazole for the tissue stage plus iodoquinol for the luminal stage is the complete two-stage treatment of amoebic colitis."
 ],
 "golden_fa": "آمیبیازیس همیشه دو دارو: نیتروایمیدازول (بافت) + داروی لومینال (کیست).",
 "golden_en": "Amoebiasis always takes two drugs: a nitroimidazole for tissue plus a luminal agent for cysts.",
 "refs": [
  "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 223: Amebiasis and Infection with Free-Living Amebae",
  "Harrison's 21st ed — Ch. 133: Acute Infectious Diarrheal Diseases"
 ]
}

L["1404-09:106"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "گازگرفتگی سگ پوشش پلی‌میکروبی می‌خواهد؛ با آنافیلاکسی پنی‌سیلین، کلیندامایسین + سیپروفلوکساسین جایگزین است.",
  "lead_en": "A dog bite needs polymicrobial cover; with penicillin anaphylaxis, clindamycin plus ciprofloxacin is the substitute.",
  "points_fa": [
   "زخم گازگرفتگی حیوان همیشه پلی‌میکروبی است و فلور دهان حیوان را وارد بافت می‌کند.",
   "شایع‌ترین عوامل: پاستورلا مولتوسیدا، استافیلوکوک، استرپتوکوک و بی‌هوازی‌های دهانی.",
   "پاستورلا مولتوسیدا مشخصه‌ی گازگرفتگی است و عفونت زودرس (زیر ۲۴ ساعت) می‌سازد.",
   "انتخاب اول در حالت عادی آموکسی‌سیلین-کلاوولانات است که هر سه گروه را می‌پوشاند.",
   "در آلرژی شدید به پنی‌سیلین، همه‌ی بتالاکتام‌ها باید کنار گذاشته شوند.",
   "سفالوسپورین‌ها هم به دلیل خطر واکنش متقاطع در آنافیلاکسی توصیه نمی‌شوند.",
   "جایگزین استاندارد: کلیندامایسین به‌همراه یک فلوروکینولون یا کوتریموکسازول.",
   "کلیندامایسین بی‌هوازی‌ها و گرم‌مثبت‌ها را می‌پوشاند اما روی پاستورلا ضعیف است.",
   "سیپروفلوکساسین این شکاف را پر می‌کند و پاستورلا را پوشش می‌دهد."
  ],
  "points_en": [
   "Animal bite wounds are always polymicrobial, inoculating the animal's oral flora into tissue.",
   "The commonest organisms: Pasteurella multocida, staphylococci, streptococci and oral anaerobes.",
   "Pasteurella multocida is characteristic of bites and causes early infection, within 24 hours.",
   "The usual first choice is amoxicillin-clavulanate, which covers all three groups.",
   "With severe penicillin allergy, every beta-lactam must be set aside.",
   "Cephalosporins are also avoided in anaphylaxis because of cross-reactivity risk.",
   "The standard substitute: clindamycin plus a fluoroquinolone or co-trimoxazole.",
   "Clindamycin covers anaerobes and gram-positives but is weak against Pasteurella.",
   "Ciprofloxacin fills that gap and covers Pasteurella."
  ]
 },
 "explanation_fa": "این سؤال دو شرط را همزمان می‌گذارد و پاسخ باید هر دو را برآورده کند. شرط اول پوشش میکروبی است: زخم گازگرفتگی سگ سه گروه باکتری وارد بافت می‌کند و پوشش باید هر سه را بگیرد. شرط دوم محدودیت دارویی است: بیمار سابقه‌ی آنافیلاکسی به پنی‌سیلین دارد، پس هیچ بتالاکتامی مجاز نیست. حالا گزینه‌ها را غربال کنید. کوآموکسی‌کلاو و آمپی‌سیلین-سولباکتام هر دو پنی‌سیلین‌اند و مستقیماً حذف می‌شوند. سفالکسین سفالوسپورین است و در آنافیلاکسی به‌خاطر واکنش متقاطع پرهیز می‌شود؛ ضمناً پوشش آن روی پاستورلا و بی‌هوازی‌ها ضعیف است. می‌ماند کلیندامایسین به‌همراه سیپروفلوکساسین که ترکیب استاندارد جایگزین است: کلیندامایسین بی‌هوازی‌های دهانی و گرم‌مثبت‌ها را می‌گیرد و سیپروفلوکساسین پاستورلا را.",
 "explanation_en": "This item sets two conditions at once and the answer must satisfy both. The first is microbial cover: a dog bite inoculates three groups of bacteria and the regimen must cover all three. The second is a drug restriction: the patient has anaphylaxis to penicillin, so no beta-lactam is permitted. Now sift the options. Co-amoxiclav and ampicillin-sulbactam are both penicillins and are eliminated outright. Cephalexin is a cephalosporin, avoided in anaphylaxis because of cross-reactivity, and its cover of Pasteurella and anaerobes is poor anyway. That leaves clindamycin plus ciprofloxacin, the standard substitute: clindamycin takes the oral anaerobes and gram-positives, ciprofloxacin takes Pasteurella.",
 "why_fa": [
  "کوآموکسی‌کلاو انتخاب اول گازگرفتگی است اما پنی‌سیلین دارد و در آنافیلاکسی به‌طور مطلق ممنوع است.",
  "پاسخ صحیح — کلیندامایسین بی‌هوازی‌ها و گرم‌مثبت‌ها را می‌پوشاند و سیپروفلوکساسین پاستورلا را؛ این ترکیب جایگزین استاندارد در آلرژی به پنی‌سیلین است.",
  "آمپی‌سیلین-سولباکتام هم بتالاکتام است و به همان دلیل قبلی در این بیمار قابل استفاده نیست.",
  "سفالکسین علاوه بر خطر واکنش متقاطع، پوشش ضعیفی روی پاستورلا مولتوسیدا و بی‌هوازی‌های دهانی دارد."
 ],
 "why_en": [
  "Co-amoxiclav is the first choice for bites but contains a penicillin and is absolutely contraindicated in anaphylaxis.",
  "Correct — clindamycin covers anaerobes and gram-positives while ciprofloxacin covers Pasteurella; this is the standard penicillin-allergy substitute.",
  "Ampicillin-sulbactam is also a beta-lactam and is unusable in this patient for the same reason.",
  "Cephalexin carries cross-reactivity risk and additionally has poor cover of Pasteurella multocida and oral anaerobes."
 ],
 "golden_fa": "گازگرفتگی = کوآموکسی‌کلاو. آلرژی پنی‌سیلین = کلیندامایسین + سیپروفلوکساسین.",
 "golden_en": "Bite means co-amoxiclav; penicillin allergy means clindamycin plus ciprofloxacin.",
 "refs": [
  "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 141: Infectious Complications of Bites",
  "IDSA guideline: skin and soft tissue infections — animal bite management"
 ]
}

L["1404-09:107"] = {
 "style": "case", "difficulty": "hard",
 "micro": {
  "lead_fa": "آسپیراسیون در چند ساعت و بدون تب = پنومونیت شیمیایی (مندلسون)، نه پنومونی؛ آنتی‌بیوتیک لازم نیست.",
  "lead_en": "Aspiration within hours and without fever is chemical pneumonitis (Mendelson), not pneumonia; antibiotics are not needed.",
  "points_fa": [
   "آسپیراسیون دو پیامد کاملاً متفاوت دارد که نباید با هم اشتباه شوند.",
   "پنومونیت آسپیراسیون آسیب شیمیایی حاد ناشی از اسید معده است.",
   "پنومونی آسپیراسیون عفونت باکتریال ناشی از فلور اوروفارنکس است.",
   "پنومونیت طی چند ساعت شکل می‌گیرد؛ پنومونی طی چند روز.",
   "در پنومونیت بیمار معمولاً تب ندارد و لکوسیتوز پاسخ التهابی است نه عفونت.",
   "سندرم مندلسون همان پنومونیت شیمیایی پس از آسپیراسیون محتویات اسیدی است.",
   "درمان پنومونیت حمایتی است: اکسیژن، ساکشن و پایش تنفسی.",
   "آنتی‌بیوتیک تجربی در پنومونیت فقط فلور را مقاوم می‌کند و سودی ندارد.",
   "اگر پس از ۴۸ ساعت بهبود نیافت یا تب کرد، آن‌وقت به عفونت ثانویه فکر کنید."
  ],
  "points_en": [
   "Aspiration has two entirely different consequences that must not be confused.",
   "Aspiration pneumonitis is acute chemical injury from gastric acid.",
   "Aspiration pneumonia is bacterial infection from oropharyngeal flora.",
   "Pneumonitis develops within hours; pneumonia over days.",
   "In pneumonitis the patient is usually afebrile and the leukocytosis is inflammatory, not infective.",
   "Mendelson syndrome is that chemical pneumonitis after aspirating acidic contents.",
   "Treatment of pneumonitis is supportive: oxygen, suction and respiratory monitoring.",
   "Empirical antibiotics in pneumonitis only select resistance and offer no benefit.",
   "If there is no improvement after 48 hours, or fever develops, then consider secondary infection."
  ]
 },
 "explanation_fa": "این یکی از سؤالاتی است که پاسخ درست، «کاری نکردن» است و همین آن را سخت می‌کند. بیمار با کاهش هوشیاری محتویات معده را آسپیره کرده و حالا کدورت ریوی دارد. وسوسه‌ی طبیعی شروع آنتی‌بیوتیک وسیع‌الطیف است، اما سه سرنخ خلاف آن می‌گویند. اول زمان: علائم طی «چند ساعت» شروع شده‌اند، در حالی که پنومونی باکتریال آسپیراسیون روزها طول می‌کشد تا شکل بگیرد. دوم نبود تب: عفونت باکتریال ریه معمولاً تب می‌دهد. سوم ماهیت لکوسیتوز: آسیب شیمیایی حاد ریه خودش پاسخ التهابی سیستمیک و لکوسیتوز می‌سازد، پس لکوسیتوز بدون تب لزوماً عفونت نیست. این مجموعه یعنی پنومونیت شیمیایی یا سندرم مندلسون که درمانش حمایتی است. آنتی‌بیوتیک تجربی نه‌تنها کمکی نمی‌کند، بلکه فلور بیمار را مقاوم می‌کند.",
 "explanation_en": "This is one of those items where the right answer is to do nothing, which is what makes it hard. The patient aspirated gastric contents while unconscious and now has pulmonary opacity. The natural temptation is broad-spectrum antibiotics, but three clues argue against it. First, timing: symptoms began within hours, whereas bacterial aspiration pneumonia takes days to develop. Second, the absence of fever: bacterial lung infection usually causes fever. Third, the nature of the leukocytosis: acute chemical lung injury itself produces a systemic inflammatory response with leukocytosis, so a raised white count without fever is not necessarily infection. Together this is chemical pneumonitis, the Mendelson syndrome, and its treatment is supportive. Empirical antibiotics do not help and do select resistant flora.",
 "why_fa": [
  "لووفلوکساسین یک آنتی‌بیوتیک وسیع‌الطیف است و در پنومونیت شیمیایی اندیکاسیون ندارد؛ تجویز آن فقط خطر مقاومت را بالا می‌برد.",
  "پاسخ صحیح — سیر چندساعته، نبود تب و زمینه‌ی آسپیراسیون، سندرم مندلسون (پنومونیت شیمیایی) را مطرح می‌کند که درمانش حمایتی است.",
  "سفتریاکسون و کلیندامایسین رژیم پنومونی آسپیراسیون باکتریال است، که طی روزها و معمولاً با تب بروز می‌کند.",
  "سفتریاکسون و مترونیدازول هم پوشش بی‌هوازی برای عفونت باکتریال است و در فاز شیمیایی حاد جایگاهی ندارد."
 ],
 "why_en": [
  "Levofloxacin is a broad-spectrum antibiotic with no indication in chemical pneumonitis; giving it only raises resistance risk.",
  "Correct — a course of a few hours, absence of fever and an aspiration setting point to Mendelson syndrome (chemical pneumonitis), treated supportively.",
  "Ceftriaxone plus clindamycin is the regimen for bacterial aspiration pneumonia, which develops over days and usually with fever.",
  "Ceftriaxone plus metronidazole is likewise anaerobic cover for bacterial infection and has no role in the acute chemical phase."
 ],
 "golden_fa": "چند ساعت + بدون تب = پنومونیت شیمیایی = حمایتی. چند روز + تب = پنومونی = آنتی‌بیوتیک.",
 "golden_en": "Hours plus no fever means chemical pneumonitis and supportive care; days plus fever means pneumonia and antibiotics.",
 "refs": [
  "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 126: Pneumonia, aspiration syndromes",
  "Marik PE. Aspiration pneumonitis and aspiration pneumonia. N Engl J Med 2001;344:665-71"
 ]
}

L["1404-09:108"] = {
 "style": "case", "difficulty": "hard",
 "micro": {
  "lead_fa": "آستانه‌ی مثبت TST به گروه خطر بستگی دارد؛ برای کاندید anti-TNF فقط ۵ میلی‌متر کافی است.",
  "lead_en": "The TST positivity threshold depends on risk group; for an anti-TNF candidate just 5 mm is enough.",
  "points_fa": [
   "تست پوستی توبرکولین سه آستانه‌ی متفاوت دارد و انتخاب آستانه به بیمار بستگی دارد.",
   "آستانه‌ی ۱۵ میلی‌متر برای افراد سالم و بدون عامل خطر است.",
   "آستانه‌ی ۱۰ میلی‌متر برای مهاجران از مناطق پرشیوع، کارکنان درمان و زندانیان است.",
   "آستانه‌ی ۵ میلی‌متر برای پرخطرترین گروه‌هاست.",
   "این گروه شامل HIV مثبت، تماس نزدیک با بیمار سل و گیرندگان پیوند است.",
   "کاندیدهای درمان با مهارکننده‌ی TNF نیز در همین گروه ۵ میلی‌متری‌اند.",
   "دلیلش زیستی است: TNF-آلفا گرانولوم را منسجم نگه می‌دارد.",
   "مهار TNF گرانولوم را باز می‌کند و سل نهفته را به سل فعال و اغلب منتشر تبدیل می‌کند.",
   "سل نهفته با تک‌داروی ایزونیازید درمان می‌شود؛ رژیم چهاردارویی برای سل فعال است."
  ],
  "points_en": [
   "The tuberculin skin test has three different thresholds, and which applies depends on the patient.",
   "The 15 mm threshold is for healthy people with no risk factors.",
   "The 10 mm threshold is for migrants from high-prevalence areas, healthcare workers and prisoners.",
   "The 5 mm threshold is for the highest-risk groups.",
   "That group includes HIV-positive patients, close contacts of TB cases and transplant recipients.",
   "Candidates for TNF-inhibitor therapy also fall in this 5 mm group.",
   "The reason is biological: TNF-alpha holds the granuloma together.",
   "Blocking TNF opens the granuloma and can convert latent TB into active, often disseminated, disease.",
   "Latent TB is treated with single-agent isoniazid; the four-drug regimen is for active disease."
  ]
 },
 "explanation_fa": "دام این سؤال عدد است. شش میلی‌متر در نگاه اول کوچک به نظر می‌رسد و بسیاری آن را منفی می‌خوانند، اما آستانه‌ی مثبت شدن تست توبرکولین ثابت نیست و به گروه خطر بیمار بستگی دارد. برای فرد سالم آستانه ۱۵ میلی‌متر است، اما برای بیماری که قرار است داروی مهارکننده‌ی TNF شروع کند آستانه به ۵ میلی‌متر پایین می‌آید. پس ۶ میلی‌متر در این بیمار قطعاً مثبت است. دلیل این سخت‌گیری کاملاً زیستی است: TNF-آلفا همان سیتوکینی است که ساختار گرانولوم را حفظ می‌کند و باسیل سل را در آن محبوس نگه می‌دارد؛ مهار آن مثل باز کردن در زندان است و سل نهفته می‌تواند فعال و منتشر شود. گام بعدی افتراق نهفته از فعال است: علائم بالینی ندارد و CXR طبیعی است، پس سل نهفته مطرح است و درمان آن پروفیلاکسی با ایزونیازید است، نه رژیم چهاردارویی که برای بیماری فعال طراحی شده.",
 "explanation_en": "The trap in this item is the number. Six millimetres looks small at first glance and many read it as negative, but the tuberculin test's positivity threshold is not fixed; it depends on the patient's risk group. For a healthy person the threshold is 15 mm, but for someone about to start a TNF inhibitor it falls to 5 mm. So 6 mm in this patient is definitely positive. The reason for that strictness is purely biological: TNF-alpha is the cytokine that maintains granuloma structure and keeps the bacilli walled off; blocking it is like unlocking the prison, and latent TB can become active and disseminated. The next step is separating latent from active disease: there are no clinical features and the chest film is normal, so this is latent TB, treated with isoniazid prophylaxis rather than the four-drug regimen designed for active disease.",
 "why_fa": [
  "نادرست است. آستانه‌ی مثبت برای کاندید anti-TNF پنج میلی‌متر است، پس شش میلی‌متر مثبت محسوب می‌شود و نمی‌توان آن را نادیده گرفت.",
  "رژیم چهاردارویی برای سل فعال است. این بیمار علامت بالینی ندارد و CXR طبیعی است، پس درمان کامل، بیش‌درمانی و پرعارضه است.",
  "پاسخ صحیح — تشخیص سل نهفته است و درمان پیشگیرانه با ایزونیازید پیش از شروع anti-TNF ضروری است.",
  "برونکوسکوپی وقتی مطرح است که به سل ریوی فعال شک داشته باشیم. با CXR طبیعی و بدون علامت، اندیکاسیونی ندارد."
 ],
 "why_en": [
  "False. The positivity threshold for an anti-TNF candidate is 5 mm, so 6 mm counts as positive and cannot be ignored.",
  "The four-drug regimen is for active TB. This patient has no clinical features and a normal chest film, so full treatment is over-treatment with needless toxicity.",
  "Correct — this is latent TB, and isoniazid preventive therapy is required before starting anti-TNF.",
  "Bronchoscopy is considered when active pulmonary TB is suspected. With a normal film and no symptoms there is no indication."
 ],
 "golden_fa": "TST: ۱۵ سالم، ۱۰ پرخطر متوسط، ۵ پرخطر بالا (HIV، تماس، anti-TNF). نهفته = INH تنها.",
 "golden_en": "TST: 15 mm healthy, 10 mm moderate risk, 5 mm high risk (HIV, contacts, anti-TNF). Latent means isoniazid alone.",
 "refs": [
  "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 178: Tuberculosis, latent infection",
  "مدیریت عفونت سل نهفته — مصوبه ۱۴۰۳ کمیته کشوری سل، وزارت بهداشت"
 ]
}

json.dump(L, io.open('/home/user/work/infectious/lessons/L1.json','w',encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('infectious L1:', len(L))
