# -*- coding: utf-8 -*-
"""Glyph-geometry probe for the handful of parasitology numbers that matter.

The audit narrowed 101 questions down to a short list where a mirrored run
would change either the medicine or the key. This prints, for each of those
questions, every line of the book whose Persian letters overlap the stem,
together with the digits IN PRINTED ORDER — so the reading can be judged
against the page instead of against whichever value makes the key convenient.
"""
import json, io, os, re, collections, sys

import pdfplumber

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = '/home/user/uploads/بیماری عفونی.pdf'

WANT = {9736: 'mg005 paromomycin dose',
        9761: 'Hb 4/5 and urine 250 and Plt 90000',
        9768: 'pH 1.7 and Hct 15',
        9769: 'bicarbonate 71, pH 7.35',
        9770: 'gr6/4 haemoglobin',
        9754: '71-year-old',
        9805: 'egg 52 micron',
        9803: 'mebendazole 500',
        9822: 'WBC 7500 differential'}


def letters(s):
    s = re.sub(r'[\u0660-\u0669\u06F0-\u06F9]', '', s or '')
    return re.sub(r'[^\u0600-\u06FF]', '', s)


def main():
    qs = {}
    for i in range(1, 6):
        body = json.load(io.open(os.path.join(
            HERE, f'import-payload.book.part{i:02d}.json'), encoding='utf-8'))
        for q in body['questions']:
            if q['question_no'] in WANT:
                qs[q['question_no']] = q

    with pdfplumber.open(SRC) as pdf:
        lines = []
        for pno, page in enumerate(pdf.pages, 1):
            rows = collections.defaultdict(list)
            for c in page.chars:
                rows[round(c['top'])].append(c)
            for top in sorted(rows):
                cs = sorted(rows[top], key=lambda c: c['x0'])
                text = ''.join(c['text'] for c in cs)[::-1]
                digits = ''.join(c['text'] for c in cs if c['text'].isdigit())
                lines.append((pno, letters(text), digits, text))

    for no in sorted(WANT):
        q = qs.get(no)
        print('=' * 70)
        print(f'q{no}  ({WANT[no]})')
        if not q:
            print('  not found'); continue
        # anchor on a long, distinctive letter run from the stem
        anchors = [letters(p) for p in re.split(r'(?<=[.؟])\s+', q['question_fa'])]
        anchors += [letters(o) for o in q['options_fa']]
        anchors = [a for a in anchors if len(a) >= 14]
        seen = set()
        for pno, key, digits, text in lines:
            for a in anchors:
                probe = a[:20]
                if probe and probe in key and (pno, text) not in seen:
                    seen.add((pno, text))
                    print(f'  p{pno} digits={digits!r}')
                    print(f'      {text[:160]}')
                    break


if __name__ == '__main__':
    main()
