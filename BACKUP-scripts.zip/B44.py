# -*- coding: utf-8 -*-
"""Micro-lessons, batch 44 — malaria part two: treatment and prophylaxis.

Sixteen questions, and they are decided by three rules plus one exception.

RULE ONE — TREATMENT FOLLOWS THE SPECIES AND THE SEVERITY, IN THAT ORDER.

    SEVERE falciparum (any WHO criterion, or impaired consciousness)
        INTRAVENOUS ARTESUNATE, first line, without exception.
        Artesunate replaced quinine after the AQUAMAT and SEAQUAMAT trials
        showed a large mortality reduction. It is also far safer: quinine and
        quinidine cause hypoglycaemia, QT prolongation and arrhythmia.

    UNCOMPLICATED falciparum
        an ARTEMISININ-BASED COMBINATION (ACT), e.g. artesunate plus
        mefloquine. Chloroquine is NOT used: falciparum resistance to
        chloroquine is essentially universal, including in Iran's south-east.

    VIVAX or OVALE
        CHLOROQUINE for the blood stage, THEN PRIMAQUINE for 14 days to kill
        the hypnozoites. This second step is called RADICAL CURE.

RULE TWO — ONLY VIVAX AND OVALE HAVE HYPNOZOITES.
Falciparum and malariae have no dormant liver stage, so they never need
primaquine. This single fact answers one question outright.

RULE THREE — PROPHYLAXIS IS CHOSEN BY THE RESISTANCE OF THE DESTINATION.

    chloroquine-SENSITIVE area   chloroquine, weekly
    chloroquine-RESISTANT area   mefloquine weekly, OR doxycycline daily,
                                 OR atovaquone-proguanil daily
    PREGNANCY in a resistant area   MEFLOQUINE — the only option, because
                                 doxycycline is teratogenic and
                                 atovaquone-proguanil lacks safety data.

    And note the timings, which one question asks explicitly:
        atovaquone-proguanil  1 to 2 days before, until 7 DAYS after leaving
        mefloquine            1 to 2 weeks before, until 4 WEEKS after
        doxycycline           1 to 2 days before, until 4 WEEKS after
    The short tail of atovaquone-proguanil is because it also kills the liver
    stage; the other two only suppress blood stages, so they must outlast the
    liver phase.

THE EXCEPTION — BLOODBORNE VIVAX NEEDS NO PRIMAQUINE.
Two questions here turn on it, and it is the most elegant point in the whole
chapter. Malaria acquired by NEEDLESTICK, TRANSFUSION or TRANSPLACENTALLY
bypasses the mosquito's sporozoite inoculation, so the parasite never passes
through the liver. NO LIVER PHASE MEANS NO HYPNOZOITES, and no hypnozoites
means no relapse and no need for primaquine. Chloroquine alone is curative.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022) —
malaria; WHO Guidelines for the Treatment of Malaria; CDC Yellow Book,
malaria prophylaxis by destination.
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = "Harrison's Principles of Internal Medicine, 21st ed (2022) — malaria"
WHO = "World Health Organization — Guidelines for the Treatment of Malaria"
CDC = ("CDC Yellow Book / CDC Health Information for International Travel — "
       "malaria prophylaxis recommendations by destination")
REFS = [H, WHO]
PREFS = [H, CDC]

# ================================================== SHARED: TREATMENT LADDER
TX_FA = [
    "⚠️ **درمان مالاریا با دو سؤال تعیین می‌شود: کدام گونه، و شدید هست یا نه؟**",
    "**فالسیپاروم شدید: آرتسونات وریدی، خط اول و بدون استثنا.**",
    "**فالسیپاروم بدون عارضه: ترکیب مبتنی بر آرتمیزینین، مثل آرتسونات + مفلوکین.**",
    "**ویواکس یا اوال: کلروکین برای مرحله‌ی خونی، سپس پریماکین ۱۴ روز.**",
    "⚠️ **آن مرحله‌ی دوم را «درمان رادیکال» می‌نامند و هدفش کشتن هیپنوزوئیت است.**",
    "**چرا آرتسونات جای کینین را گرفت؟ دو مطالعه‌ی بزرگ آن را ثابت کردند.**",
    "**SEAQUAMAT در آسیا و AQUAMAT در آفریقا، کاهش چشمگیر مرگ‌ومیر نشان دادند.**",
    "**و آرتسونات ایمن‌تر هم هست، که در سؤال‌های قلبی اهمیت پیدا می‌کند.**",
    "⚠️ **کینین و کینیدین هیپوگلیسمی، طولانی شدن QT و آریتمی می‌دهند.**",
    "**پس در بیمار با سابقه‌ی آریتمی، کینیدین انتخاب خطرناکی است.**",
    "**و کلروکین در فالسیپاروم دیگر کار نمی‌کند: مقاومت تقریباً جهانی است.**",
    "**از جمله در جنوب شرق ایران، که مناطق تکرارشونده‌ی این کتاب‌اند.**",
    "**هالوفانترین به دلیل کاردیوتوکسیسیته عملاً کنار گذاشته شده است.**",
    "⚠️ **و آمودیاکین به‌تنهایی جایی در درمان استاندارد ندارد.**",
]
TX_EN = [
    "WARNING: MALARIA TREATMENT IS DECIDED BY TWO QUESTIONS: which species, and is it severe?",
    "SEVERE FALCIPARUM: intravenous ARTESUNATE, first line, without exception.",
    "UNCOMPLICATED FALCIPARUM: an artemisinin-based combination, such as artesunate plus mefloquine.",
    "VIVAX OR OVALE: chloroquine for the blood stage, then PRIMAQUINE for 14 days.",
    "WARNING, THAT SECOND STEP IS CALLED RADICAL CURE, and its purpose is killing the hypnozoites.",
    "Why did artesunate replace quinine? Two large trials proved it.",
    "SEAQUAMAT in Asia and AQUAMAT in Africa both showed a large reduction in mortality.",
    "And artesunate is also safer, which matters in the cardiac questions.",
    "WARNING, QUININE AND QUINIDINE CAUSE hypoglycaemia, QT prolongation and arrhythmia.",
    "So in a patient with a history of arrhythmia, quinidine is a dangerous choice.",
    "And chloroquine no longer works in falciparum: resistance is essentially universal.",
    "Including in south-eastern Iran, the areas this book keeps naming.",
    "Halofantrine has effectively been abandoned because of cardiotoxicity.",
    "WARNING, AND AMODIAQUINE ALONE has no place in standard treatment.",
]

add("book:783", "vignette", "medium",
    "**فالسیپاروم پس از سراوان: آرتسونات — کلروکین در فالسیپاروم دیگر کار نمی‌کند.**",
    "Falciparum after Saravan: ARTESUNATE — chloroquine no longer works in falciparum.",
    TX_FA,
    TX_EN,
    "این سؤال ساده‌ترین ورودی به بلوک درمان است و **یک اشتباه بسیار رایج** را هدف گرفته: "
    "دادن کلروکین به فالسیپاروم.\n\n"
    "**بیمار: ۱۸ ساله، یک هفته پس از بازگشت از سراوان (سیستان و بلوچستان)، با تب، لرز، تعریق "
    "و سردرد. در لام خون محیطی پلاسمودیوم فالسیپاروم گزارش شده.**\n\n"
    "⚠️ **قاعده: کلروکین در فالسیپاروم دیگر کار نمی‌کند.** مقاومت فالسیپاروم به کلروکین "
    "**تقریباً در سراسر جهان** گسترش یافته، از جمله در **جنوب شرق ایران**. دادن کلروکین به "
    "فالسیپاروم یعنی **درمان شکست‌خورده** و پیشرفت به سمت مالاریای شدید.\n\n"
    "**پس درمان فالسیپاروم چیست؟ مشتقات آرتمیزینین.** آرتسونات هم برای فالسیپاروم **شدید** "
    "(وریدی) و هم به‌عنوان پایه‌ی درمان **بدون عارضه** (در قالب ACT) استفاده می‌شود.\n\n"
    "**چرا آرتسونات؟** دو کارآزمایی بزرگ آن را تثبیت کردند: **SEAQUAMAT** در آسیا و "
    "**AQUAMAT** در آفریقا، هر دو **کاهش چشمگیر مرگ‌ومیر** نسبت به کینین نشان دادند. "
    "به‌علاوه آرتسونات **سریع‌ترین دارو در پاک کردن انگل از خون** است.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**کلروکین:** مقاومت فالسیپاروم تقریباً جهانی است. **این خطرناک‌ترین گزینه است**، چون به "
    "پزشک احساس کاذب درمان می‌دهد در حالی که بیمار در حال بدتر شدن است.\n\n"
    "**پروگوانیل + اتوواکون (مالارون):** این ترکیب **مؤثر است** ولی جایگاه اصلی آن "
    "**پروفیلاکسی** است و در درمان، خط دوم محسوب می‌شود. وقتی آرتسونات در دسترس است، انتخاب "
    "اول نیست.\n\n"
    "⚠️ **آمودیاکین:** به‌تنهایی جایی در درمان استاندارد ندارد. در برخی برنامه‌های آفریقایی "
    "**در ترکیب با آرتسونات** (به‌عنوان ASAQ) استفاده می‌شود، ولی **تک‌دارویی آن توصیه نمی‌شود** "
    "و مقاومت هم گزارش شده است.",
    "This is the simplest entry to the treatment block and it targets A VERY COMMON MISTAKE: giving "
    "chloroquine for falciparum.\n\n"
    "THE PATIENT: 18 years old, one week after returning from Saravan (Sistan and Baluchestan), with "
    "fever, chills, sweating and headache. The film reports Plasmodium falciparum.\n\n"
    "WARNING, THE RULE: CHLOROQUINE NO LONGER WORKS IN FALCIPARUM. Chloroquine resistance in "
    "falciparum has spread ALMOST WORLDWIDE, including in SOUTH-EASTERN IRAN. Giving chloroquine for "
    "falciparum means FAILED TREATMENT and progression to severe malaria.\n\n"
    "SO WHAT IS THE TREATMENT FOR FALCIPARUM? ARTEMISININ DERIVATIVES. Artesunate is used both for "
    "SEVERE falciparum (intravenously) and as the backbone of UNCOMPLICATED treatment (as an ACT).\n\n"
    "WHY ARTESUNATE? Two large trials established it: SEAQUAMAT in Asia and AQUAMAT in Africa, both "
    "showing A LARGE MORTALITY REDUCTION compared with quinine. Artesunate is also THE FASTEST DRUG AT "
    "CLEARING PARASITES from the blood.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "CHLOROQUINE: falciparum resistance is essentially universal. THIS IS THE MOST DANGEROUS OPTION, "
    "because it gives the doctor a false sense of having treated while the patient deteriorates.\n\n"
    "PROGUANIL PLUS ATOVAQUONE (Malarone): this combination IS EFFECTIVE, but its main place is "
    "PROPHYLAXIS, and in treatment it counts as second line. When artesunate is available it is not "
    "the first choice.\n\n"
    "WARNING, AMODIAQUINE: it has no place alone in standard treatment. In some African programmes it "
    "is used IN COMBINATION WITH ARTESUNATE (as ASAQ), but MONOTHERAPY IS NOT RECOMMENDED and "
    "resistance has been reported.",
    ["مقاومت فالسیپاروم به کلروکین تقریباً جهانی است؛ خطرناک‌ترین گزینه.",
     "مؤثر است ولی جایگاه اصلی آن پروفیلاکسی است و در درمان خط دوم محسوب می‌شود.",
     "به‌تنهایی جایی در درمان استاندارد ندارد و مقاومت هم گزارش شده است.",
     "پاسخ صحیح — مشتقات آرتمیزینین خط اول فالسیپاروم‌اند، با شواهد SEAQUAMAT و AQUAMAT."],
    ["Falciparum chloroquine resistance is essentially universal; the most dangerous option.",
     "Effective, but its main place is prophylaxis and in treatment it is second line.",
     "Has no place alone in standard treatment, and resistance has been reported.",
     "Correct — artemisinin derivatives are first line for falciparum, on SEAQUAMAT and AQUAMAT evidence."],
    "**فالسیپاروم = آرتمیزینین. کلروکین در فالسیپاروم مرده است.**",
    "Falciparum = artemisinin. Chloroquine is dead in falciparum.",
    REFS)

add("book:784", "vignette", "hard",
    "**رینگ دابل‌کروماتین یعنی فالسیپاروم، و سابقه‌ی آریتمی کینیدین را حذف می‌کند: آرتسونات.**",
    "A double-chromatin ring means falciparum, and a history of arrhythmia rules out quinidine: ARTESUNATE.",
    TX_FA + [
        "**در این بیمار دو سرنخ مستقل به یک پاسخ می‌رسند.**",
        "**سرنخ اول: رینگ دابل‌کروماتین امضای فالسیپاروم است.**",
        "**سرنخ دوم: کاهش هوشیاری یعنی مالاریای مغزی، یعنی بیماری شدید.**",
        "⚠️ **پس آرتسونات وریدی از همین‌جا خط اول است.**",
        "**و سابقه‌ی بیماری قلبی و آریتمی، انتخاب را قطعی‌تر می‌کند.**",
        "**کینیدین فاصله‌ی QT را طولانی می‌کند و می‌تواند تورساد دو پوان بدهد.**",
        "**هالوفانترین هم به همین دلیل عملاً کنار گذاشته شده است.**",
        "**و کلروکین در فالسیپاروم اصلاً مؤثر نیست.**",
    ],
    TX_EN + [
        "In this patient two independent clues converge on one answer.",
        "CLUE ONE: a double-chromatin ring is the signature of falciparum.",
        "CLUE TWO: reduced consciousness means cerebral malaria, which means severe disease.",
        "WARNING, SO INTRAVENOUS ARTESUNATE IS FIRST LINE from that point alone.",
        "And the history of cardiac disease and arrhythmia makes the choice even more definite.",
        "Quinidine prolongs the QT interval and can cause torsades de pointes.",
        "Halofantrine has effectively been abandoned for the same reason.",
        "And chloroquine is simply ineffective in falciparum.",
    ],
    "این سؤال هوشمندانه است، چون **دو مسیر مستقل** به یک پاسخ می‌رسند و هر کدام به‌تنهایی "
    "کافی است.\n\n"
    "**بیمار: تب و لرز و کاهش هوشیاری. سابقه‌ی بیماری قلبی و آریتمی. در لام خون محیطی، رینگ "
    "دابل‌کروماتین پلاسمودیوم.**\n\n"
    "**مسیر اول — تشخیص و شدت:**\n\n"
    "⚠️ **رینگ دابل‌کروماتین (شکل هدفون) امضای فالسیپاروم است.** و **کاهش هوشیاری = مالاریای "
    "مغزی = مالاریای شدید.**\n\n"
    "**پس بر اساس این مسیر: آرتسونات وریدی، خط اول مالاریای شدید فالسیپاروم.**\n\n"
    "**مسیر دوم — ایمنی دارویی:**\n\n"
    "**بیمار سابقه‌ی بیماری قلبی و آریتمی دارد.** حالا گزینه‌ها را از این زاویه ببینید:\n\n"
    "**کینیدین** — این ایزومر کینین است و **کاردیوتوکسیک** است: **فاصله‌ی QT را طولانی می‌کند** "
    "و می‌تواند **تورساد دو پوان** و آریتمی بطنی بدهد. در بیمار با سابقه‌ی آریتمی، این "
    "**خطرناک‌ترین انتخاب** است. تجویز آن مانیتورینگ قلبی مداوم می‌خواهد.\n\n"
    "⚠️ **هالوفانترین** — این دارو **به‌دلیل کاردیوتوکسیسیته عملاً از رده خارج شده است**. "
    "طولانی شدن شدید QT و موارد مرگ ناگهانی گزارش شده. در بیمار قلبی، **مطلقاً ممنوع**.\n\n"
    "**کلروکین** — علاوه بر بی‌اثر بودن در فالسیپاروم، خودش هم اثرات قلبی دارد.\n\n"
    "**و آرتسونات؟** **پروفایل قلبی امنی دارد**، QT را طولانی نمی‌کند، و سریع‌ترین پاک‌کننده‌ی "
    "انگل است.\n\n"
    "**پس هر دو مسیر — تشخیص و ایمنی — به آرتسونات می‌رسند.**\n\n"
    "**درس این سؤال: وقتی بیمار بیماری زمینه‌ای دارد، سابقه‌ی او بخشی از انتخاب دارو است، "
    "نه یک جزئیات اضافی در متن سؤال.**",
    "This is a clever question, because TWO INDEPENDENT ROUTES converge on one answer and either alone "
    "would suffice.\n\n"
    "THE PATIENT: fever, chills and reduced consciousness. A history of cardiac disease and "
    "arrhythmia. On the film, a double-chromatin plasmodium ring.\n\n"
    "ROUTE ONE — DIAGNOSIS AND SEVERITY:\n\n"
    "WARNING, A DOUBLE-CHROMATIN RING (the headphone form) IS THE SIGNATURE OF FALCIPARUM. And REDUCED "
    "CONSCIOUSNESS = CEREBRAL MALARIA = SEVERE MALARIA.\n\n"
    "SO BY THIS ROUTE: INTRAVENOUS ARTESUNATE, first line for severe falciparum malaria.\n\n"
    "ROUTE TWO — DRUG SAFETY:\n\n"
    "THE PATIENT HAS A HISTORY OF CARDIAC DISEASE AND ARRHYTHMIA. Now look at the options from that "
    "angle:\n\n"
    "QUINIDINE — this is the isomer of quinine and it is CARDIOTOXIC: it PROLONGS THE QT INTERVAL and "
    "can cause TORSADES DE POINTES and ventricular arrhythmia. In a patient with a history of "
    "arrhythmia this is THE MOST DANGEROUS CHOICE. Giving it requires continuous cardiac monitoring.\n\n"
    "WARNING, HALOFANTRINE — this drug HAS EFFECTIVELY BEEN WITHDRAWN BECAUSE OF CARDIOTOXICITY. "
    "Severe QT prolongation and sudden deaths have been reported. In a cardiac patient it is "
    "ABSOLUTELY CONTRAINDICATED.\n\n"
    "CHLOROQUINE — besides being ineffective in falciparum, it too has cardiac effects.\n\n"
    "AND ARTESUNATE? IT HAS A SAFE CARDIAC PROFILE, does not prolong the QT, and is the fastest "
    "parasite clearer.\n\n"
    "SO BOTH ROUTES — DIAGNOSIS AND SAFETY — LEAD TO ARTESUNATE.\n\n"
    "THE LESSON: when a patient has a comorbidity, that history is PART OF THE DRUG CHOICE, not an "
    "extra detail in the stem.",
    ["به‌دلیل کاردیوتوکسیسیته و طولانی شدن شدید QT عملاً از رده خارج شده؛ در بیمار قلبی ممنوع.",
     "پاسخ صحیح — خط اول مالاریای شدید، با پروفایل قلبی امن و سریع‌ترین پاک‌سازی انگل.",
     "کاردیوتوکسیک است، QT را طولانی می‌کند و در بیمار با سابقه‌ی آریتمی خطرناک‌ترین انتخاب است.",
     "در فالسیپاروم بی‌اثر است و خودش هم اثرات قلبی دارد."],
    ["Effectively withdrawn for cardiotoxicity and severe QT prolongation; contraindicated in a cardiac patient.",
     "Correct — first line for severe malaria, with a safe cardiac profile and the fastest parasite clearance.",
     "Cardiotoxic, prolongs the QT, and is the most dangerous choice in a patient with arrhythmia.",
     "Ineffective in falciparum, and it too has cardiac effects."],
    "**سابقه‌ی آریتمی بخشی از انتخاب دارو است — کینیدین و هالوفانترین QT را طولانی می‌کنند.**",
    "A history of arrhythmia is part of the drug choice — quinidine and halofantrine prolong the QT.",
    REFS)

add("book:788", "vignette", "medium",
    "**فالسیپاروم با افت هوشیاری و شوک: آرتسونات، اولین اقدام درمانی.**",
    "Falciparum with reduced consciousness and shock: ARTESUNATE, the first therapeutic step.",
    TX_FA + [
        "**این بیمار همه‌ی نشانه‌های مالاریای شدید را یک‌جا دارد.**",
        "**کاهش سطح هوشیاری: مالاریای مغزی.**",
        "**فشار خون ۸۰/۶۰ و نبض ۱۲۰: کلاپس گردش خون.**",
        "⚠️ **و تنفس ۳۵ در دقیقه: تاکی‌پنه‌ی جبرانی، که به اسیدوز متابولیک اشاره دارد.**",
        "**هر سه در فهرست معیارهای WHO هستند.**",
        "**پس این مالاریای شدید است و آرتسونات وریدی فوری لازم دارد.**",
        "**هر ساعت تأخیر در مالاریای شدید، مرگ‌ومیر را بالا می‌برد.**",
        "**و مفلوکین خوراکی در بیمار بی‌هوش اصلاً قابل تجویز نیست.**",
    ],
    TX_EN + [
        "This patient has every marker of severe malaria at once.",
        "Reduced conscious level: cerebral malaria.",
        "Blood pressure 80/60 and pulse 120: circulatory collapse.",
        "WARNING, AND A RESPIRATORY RATE OF 35: compensatory tachypnoea, pointing to metabolic acidosis.",
        "All three are on the WHO criteria list.",
        "So this is severe malaria and it needs immediate intravenous artesunate.",
        "Every hour of delay in severe malaria raises mortality.",
        "And oral mefloquine cannot be given at all to an unconscious patient.",
    ],
    "این سؤال یک **اورژانس واقعی** است و می‌پرسد **اولین اقدام درمانی** چیست.\n\n"
    "**بیمار: مرد جوان افغان که از مرز پاکستان وارد شده، با تب و لرز شدید و کاهش سطح هوشیاری. "
    "فشار ۸۰/۶۰، نبض ۱۲۰، تنفس ۳۵، دما ۳۸. در لام خون محیطی مالاریای فالسیپاروم.**\n\n"
    "**اول شدت را ارزیابی کنید — و اینجا سه معیار هم‌زمان برقرار است:**\n\n"
    "⚠️ **یک — کاهش سطح هوشیاری = مالاریای مغزی.** این تنها به‌تنهایی برای تشخیص مالاریای "
    "شدید کافی است.\n\n"
    "**دو — فشار ۸۰/۶۰ با نبض ۱۲۰ = کلاپس گردش خون.** فشار سیستولیک ۸۰ در بزرگسال یعنی شوک.\n\n"
    "**سه — تنفس ۳۵ در دقیقه.** این تاکی‌پنه‌ی چشمگیر، در بیمار مالاریایی معمولاً "
    "**جبران تنفسی اسیدوز متابولیک** است — و اسیدوز خودش یکی از قوی‌ترین پیش‌بینی‌کننده‌های "
    "مرگ است.\n\n"
    "**پس این مالاریای شدید فالسیپاروم است، و درمان آن: آرتسونات وریدی.**\n\n"
    "**چرا فوریت این‌قدر مهم است؟** چون در مالاریای شدید، **هر ساعت تأخیر مرگ‌ومیر را بالا "
    "می‌برد**. آرتسونات باید بی‌درنگ و وریدی شروع شود، پیش از هر اقدام دیگری.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**کینین:** پیش از سال ۲۰۱۰ خط اول بود، ولی **آرتسونات جای آن را گرفت** چون مطالعات "
    "SEAQUAMAT و AQUAMAT **کاهش چشمگیر مرگ‌ومیر** نشان دادند. به‌علاوه کینین **هیپوگلیسمی و "
    "آریتمی** می‌دهد. امروز فقط وقتی استفاده می‌شود که آرتسونات در دسترس نباشد.\n\n"
    "⚠️ **مفلوکین:** این داروی **خوراکی** است. **بیمار کاهش سطح هوشیاری دارد** و نمی‌تواند "
    "دارو ببلعد — خطر آسپیراسیون هم هست. به‌علاوه مفلوکین در مالاریای شدید اصلاً اندیکاسیون "
    "ندارد.\n\n"
    "**کلروکین:** مقاومت فالسیپاروم تقریباً جهانی است. در مالاریای شدید، دادن آن یعنی از "
    "دست دادن ساعت‌های حیاتی.",
    "This question is A GENUINE EMERGENCY and asks for THE FIRST THERAPEUTIC STEP.\n\n"
    "THE PATIENT: a young Afghan man who has crossed from the Pakistan border, with severe fever and "
    "chills and a reduced conscious level. BP 80/60, pulse 120, respiratory rate 35, temperature 38. "
    "The film shows falciparum malaria.\n\n"
    "FIRST ASSESS SEVERITY — AND HERE THREE CRITERIA ARE MET SIMULTANEOUSLY:\n\n"
    "WARNING, ONE — REDUCED CONSCIOUS LEVEL = CEREBRAL MALARIA. That alone is enough to diagnose "
    "severe malaria.\n\n"
    "TWO — BP 80/60 WITH A PULSE OF 120 = CIRCULATORY COLLAPSE. A systolic of 80 in an adult is shock.\n\n"
    "THREE — A RESPIRATORY RATE OF 35. This marked tachypnoea in a malaria patient is usually "
    "RESPIRATORY COMPENSATION FOR METABOLIC ACIDOSIS — and acidosis is itself one of the strongest "
    "predictors of death.\n\n"
    "SO THIS IS SEVERE FALCIPARUM MALARIA, AND ITS TREATMENT IS INTRAVENOUS ARTESUNATE.\n\n"
    "WHY DOES THE URGENCY MATTER SO MUCH? Because in severe malaria EVERY HOUR OF DELAY RAISES "
    "MORTALITY. Artesunate must be started intravenously at once, before anything else.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "QUININE: it was first line before about 2010, but ARTESUNATE REPLACED IT because SEAQUAMAT and "
    "AQUAMAT showed A LARGE MORTALITY REDUCTION. Quinine also causes HYPOGLYCAEMIA AND ARRHYTHMIA. "
    "Today it is used only when artesunate is unavailable.\n\n"
    "WARNING, MEFLOQUINE: this is an ORAL drug. THE PATIENT HAS A REDUCED CONSCIOUS LEVEL and cannot "
    "swallow — there is an aspiration risk too. And mefloquine has no indication in severe malaria at all.\n\n"
    "CHLOROQUINE: falciparum resistance is essentially universal. In severe malaria, giving it means "
    "losing vital hours.",
    ["خط اول سابق بود ولی آرتسونات جای آن را گرفت؛ هیپوگلیسمی و آریتمی هم می‌دهد.",
     "پاسخ صحیح — آرتسونات وریدی خط اول مالاریای شدید است و باید بی‌درنگ شروع شود.",
     "داروی خوراکی است و بیمار با کاهش هوشیاری نمی‌تواند آن را ببلعد؛ در مالاریای شدید اندیکاسیون ندارد.",
     "مقاومت فالسیپاروم تقریباً جهانی است؛ در مالاریای شدید یعنی از دست دادن ساعت‌های حیاتی."],
    ["It was first line, but artesunate replaced it; it also causes hypoglycaemia and arrhythmia.",
     "Correct — intravenous artesunate is first line for severe malaria and must start at once.",
     "An oral drug that a patient with reduced consciousness cannot swallow; not indicated in severe malaria.",
     "Falciparum resistance is essentially universal; in severe malaria this means losing vital hours."],
    "**مالاریای شدید = آرتسونات وریدی، بی‌درنگ. هر ساعت تأخیر مرگ‌ومیر را بالا می‌برد.**",
    "Severe malaria = intravenous artesunate, at once. Every hour of delay raises mortality.",
    REFS)

add("book:786", "vignette", "medium",
    "**فالسیپاروم بدون عارضه با علائم حیاتی پایدار: ترکیب مبتنی بر آرتمیزینین — آرتسونات + مفلوکین.**",
    "Uncomplicated falciparum with stable vital signs: an artemisinin-based COMBINATION — artesunate plus mefloquine.",
    TX_FA + [
        "**این سؤال برعکس قبلی است: بیمار پایدار است، نه بدحال.**",
        "**آزمایشات در سرحد طبیعی، علائم حیاتی پایدار، فقط ضعف و بدن‌درد.**",
        "**پس هیچ معیار مالاریای شدید برقرار نیست.**",
        "⚠️ **گامتوسیت موزی‌شکل باز هم فالسیپاروم را تأیید می‌کند.**",
        "**درمان فالسیپاروم بدون عارضه: درمان ترکیبی مبتنی بر آرتمیزینین.**",
        "**چرا ترکیبی و نه تک‌دارویی؟ این نکته‌ی کلیدی است.**",
        "**تک‌درمانی با آرتمیزینین، مقاومت را سریع ایجاد می‌کند.**",
        "**آرتمیزینین انگل را سریع کم می‌کند ولی نیمه‌عمر بسیار کوتاهی دارد.**",
        "⚠️ **پس داروی دوم با نیمه‌عمر طولانی، انگل‌های باقی‌مانده را پاک می‌کند.**",
        "**و همین از پیدایش مقاومت جلوگیری می‌کند — قاعده‌ی سیاست‌گذاری WHO.**",
    ],
    TX_EN + [
        "This question is the reverse of the previous one: the patient is stable, not critically ill.",
        "Laboratory tests within normal limits, stable vital signs, only weakness and body aches.",
        "So no severe-malaria criterion is met.",
        "WARNING, THE BANANA-SHAPED GAMETOCYTE again confirms falciparum.",
        "Treatment of uncomplicated falciparum: artemisinin-based COMBINATION therapy.",
        "Why a combination rather than monotherapy? This is the key point.",
        "Artemisinin monotherapy generates resistance rapidly.",
        "Artemisinin cuts the parasite load fast but has a very short half-life.",
        "WARNING, SO A SECOND DRUG WITH A LONG HALF-LIFE clears the remaining parasites.",
        "And that is what prevents resistance emerging — the WHO policy rule.",
    ],
    "این سؤال **جفت متضاد** سؤال قبلی است: همان گونه، ولی **شدت متفاوت** — و درمان هم "
    "متفاوت می‌شود.\n\n"
    "**بیمار: ۴۸ ساله اهل ایرانشهر، تب و لرز تکان‌دهنده، تعریق شدید و سردرد. آزمایشات عمومی "
    "و بیوشیمی در سرحد طبیعی. علائم حیاتی پایدار. فقط ضعف و بدن‌درد شدید. در لام: اشکال "
    "غیرطبیعی در گلبول قرمز و چند گامتوسیت موزی‌شکل.**\n\n"
    "**گام اول — گونه:** **گامتوسیت موزی‌شکل = فالسیپاروم.**\n\n"
    "⚠️ **گام دوم — شدت: هیچ معیاری برقرار نیست.** آزمایشات طبیعی (پس نه اسیدوز، نه نارسایی "
    "کلیه، نه کم‌خونی شدید)، علائم حیاتی پایدار (پس نه شوک)، هوشیاری کامل (پس نه مالاریای "
    "مغزی). **این فالسیپاروم بدون عارضه است.**\n\n"
    "**پس درمان: ترکیب مبتنی بر آرتمیزینین (ACT) — آرتسونات + مفلوکین.**\n\n"
    "**چرا ترکیبی و نه تک‌دارویی؟ این مهم‌ترین درس این سؤال است:**\n\n"
    "**آرتمیزینین بار انگلی را بسیار سریع پایین می‌آورد** — سریع‌تر از هر داروی دیگری. ولی "
    "**نیمه‌عمر آن بسیار کوتاه است** (حدود یک ساعت). پس اگر تنها داده شود، **انگل‌های "
    "باقی‌مانده** پس از پاک شدن دارو از خون، دوباره تکثیر می‌شوند و **عود** رخ می‌دهد. "
    "بدتر از آن: همین قرار گرفتن مکرر در معرض دوز کم، **مقاومت** می‌سازد.\n\n"
    "⚠️ **راه‌حل: افزودن داروی دوم با نیمه‌عمر طولانی** (مفلوکین، لومفانترین، پیپراکین) که "
    "**انگل‌های باقی‌مانده را پاک می‌کند**. به همین دلیل **WHO تک‌درمانی با آرتمیزینین را "
    "ممنوع کرده است.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**اتوواکون-پروگوانیل + کلیندامایسین:** ترکیب غیراستانداردی است. کلیندامایسین در مالاریا "
    "فقط به‌عنوان **همراه کینین** در موارد خاص (مثل بارداری) جایی دارد.\n\n"
    "**هالوفانترین + داکسی‌سیکلین:** **هالوفانترین به‌دلیل کاردیوتوکسیسیته کنار گذاشته شده است.**\n\n"
    "**کینین + آمودیاکین:** کینین خط دوم است و آمودیاکین به‌تنهایی توصیه نمی‌شود؛ این ترکیب "
    "استاندارد نیست.",
    "This question is THE MIRROR of the previous one: the same species, but A DIFFERENT SEVERITY — and "
    "so a different treatment.\n\n"
    "THE PATIENT: 48 years old from Iranshahr, fever with shaking chills, profuse sweating and "
    "headache. General and biochemical tests within normal limits. Stable vital signs. Only severe "
    "weakness and body aches. On the film: abnormal forms in the red cells and several banana-shaped "
    "gametocytes.\n\n"
    "STEP ONE — SPECIES: BANANA-SHAPED GAMETOCYTE = FALCIPARUM.\n\n"
    "WARNING, STEP TWO — SEVERITY: NO CRITERION IS MET. Normal tests (so no acidosis, no renal failure, "
    "no severe anaemia), stable vital signs (so no shock), full consciousness (so no cerebral "
    "malaria). THIS IS UNCOMPLICATED FALCIPARUM.\n\n"
    "SO THE TREATMENT: AN ARTEMISININ-BASED COMBINATION (ACT) — artesunate plus mefloquine.\n\n"
    "WHY A COMBINATION RATHER THAN MONOTHERAPY? This is the most important lesson here:\n\n"
    "ARTEMISININ REDUCES THE PARASITE LOAD VERY FAST — faster than any other drug. But ITS HALF-LIFE "
    "IS VERY SHORT (about one hour). So if given alone, THE SURVIVING PARASITES multiply again once "
    "the drug has cleared, and RECRUDESCENCE occurs. Worse: that repeated exposure to low drug levels "
    "GENERATES RESISTANCE.\n\n"
    "WARNING, THE SOLUTION: ADD A SECOND DRUG WITH A LONG HALF-LIFE (mefloquine, lumefantrine, "
    "piperaquine) THAT CLEARS THE REMAINING PARASITES. That is why WHO HAS BANNED ARTEMISININ "
    "MONOTHERAPY.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ATOVAQUONE-PROGUANIL PLUS CLINDAMYCIN: a non-standard combination. Clindamycin's place in malaria "
    "is only AS A PARTNER TO QUININE in special situations such as pregnancy.\n\n"
    "HALOFANTRINE PLUS DOXYCYCLINE: HALOFANTRINE HAS BEEN ABANDONED FOR CARDIOTOXICITY.\n\n"
    "QUININE PLUS AMODIAQUINE: quinine is second line and amodiaquine alone is not recommended; this "
    "combination is not standard.",
    ["ترکیب غیراستاندارد؛ کلیندامایسین در مالاریا فقط همراه کینین در موارد خاص جایی دارد.",
     "پاسخ صحیح — ترکیب مبتنی بر آرتمیزینین، خط اول فالسیپاروم بدون عارضه.",
     "هالوفانترین به‌دلیل کاردیوتوکسیسیته و طولانی شدن QT کنار گذاشته شده است.",
     "کینین خط دوم است و آمودیاکین به‌تنهایی توصیه نمی‌شود؛ ترکیب استاندارد نیست."],
    ["A non-standard combination; clindamycin's only place is as a quinine partner in special cases.",
     "Correct — an artemisinin-based combination is first line for uncomplicated falciparum.",
     "Halofantrine has been abandoned for cardiotoxicity and QT prolongation.",
     "Quinine is second line and amodiaquine alone is not recommended; not a standard combination."],
    "**آرتمیزینین تنها = مقاومت. همیشه با شریکِ نیمه‌عمر بلند.**",
    "Artemisinin alone = resistance. Always with a long half-life partner.",
    REFS)

add("book:785", "vignette", "medium",
    "**فالسیپاروم بدون عارضه: کینین + کلیندامایسین در میان این چهار، تنها رژیم قابل دفاع است.**",
    "Uncomplicated falciparum: among these four, quinine plus clindamycin is the only defensible regimen.",
    TX_FA + [
        "**گامتوسیت موزی‌شکل باز هم فالسیپاروم را قطعی می‌کند.**",
        "**و سؤال صریحاً گفته بیمار علائم مالاریای شدید ندارد.**",
        "**پس فالسیپاروم بدون عارضه است.**",
        "⚠️ **کینین + کلیندامایسین یک رژیم شناخته‌شده‌ی ترکیبی برای فالسیپاروم است.**",
        "**کلیندامایسین شریک کینین است و مدت درمان را کوتاه‌تر می‌کند.**",
        "**و این رژیم به‌ویژه در بارداری و کودکان کاربرد دارد.**",
        "**در مقابل، هر گزینه‌ای که کلروکین دارد در فالسیپاروم رد می‌شود.**",
        "**و فانسیدار (سولفادوکسین-پیریمتامین) مقاومت گسترده دارد.**",
        "⚠️ **پریماکین هم در فالسیپاروم برای درمان رادیکال جایی ندارد.**",
        "**چون فالسیپاروم اصلاً هیپنوزوئیت نمی‌سازد.**",
    ],
    TX_EN + [
        "The banana-shaped gametocyte again settles falciparum.",
        "And the question states explicitly that the patient has no features of severe malaria.",
        "So this is uncomplicated falciparum.",
        "WARNING, QUININE PLUS CLINDAMYCIN is a recognised combination regimen for falciparum.",
        "Clindamycin is quinine's partner and shortens the treatment course.",
        "And this regimen is particularly used in pregnancy and in children.",
        "By contrast, any option containing chloroquine is rejected in falciparum.",
        "And Fansidar (sulfadoxine-pyrimethamine) faces widespread resistance.",
        "WARNING, PRIMAQUINE ALSO HAS NO RADICAL-CURE ROLE IN FALCIPARUM.",
        "Because falciparum makes no hypnozoites at all.",
    ],
    "این سؤال با **حذف کردن** حل می‌شود: سه گزینه ایراد قطعی دارند، پس چهارمی می‌ماند.\n\n"
    "**بیمار: پس از سفر به جنوب ایران، تب و لرز. در گستره‌ی خون محیطی گامتوسیت موزی‌شکل. "
    "و سؤال صریحاً گفته: بیمار علائم مالاریای شدید ندارد.**\n\n"
    "**پس: فالسیپاروم بدون عارضه.**\n\n"
    "**حالا گزینه‌ها را حذف کنیم:**\n\n"
    "⚠️ **کلروکین + پریماکین:** **دو ایراد مستقل دارد.** یک: **کلروکین در فالسیپاروم بی‌اثر "
    "است** (مقاومت جهانی). دو: **پریماکین برای کشتن هیپنوزوئیت است، و فالسیپاروم هیپنوزوئیت "
    "ندارد** — پس درمان رادیکال در فالسیپاروم بی‌معناست. این رژیم مربوط به **ویواکس** است، نه "
    "فالسیپاروم.\n\n"
    "**پروگوانیل + پریماکین:** پروگوانیل به‌تنهایی داروی درمانی ضعیفی است (در پروفیلاکسی "
    "همراه اتوواکون استفاده می‌شود)، و پریماکین باز هم اشتباه است.\n\n"
    "**آرتسونات + فانسیدار:** آرتسونات درست است ولی **فانسیدار (سولفادوکسین-پیریمتامین) "
    "مقاومت گسترده‌ای دارد** و شریک مناسبی برای آرتسونات نیست. به‌علاوه خطر واکنش‌های پوستی "
    "شدید (استیونس-جانسون) دارد.\n\n"
    "**می‌ماند: کینین + کلیندامایسین.**\n\n"
    "**این رژیم چگونه کار می‌کند؟** کینین یک شیزونتوسید خونی مؤثر است که **هنوز در فالسیپاروم "
    "کار می‌کند**، و **کلیندامایسین شریک آن** است که هم کارایی را بالا می‌برد و هم اجازه "
    "می‌دهد دوره‌ی کینین کوتاه‌تر شود (کینین به‌تنهایی هفت روز، با کلیندامایسین سه روز کینین + "
    "هفت روز کلیندامایسین).\n\n"
    "⚠️ **و این ترکیب جایگاه ویژه‌ای دارد: در بارداری و کودکان**، جایی که برخی داروهای دیگر "
    "محدودیت دارند. امروز ACT خط اول است، ولی **کینین + کلیندامایسین رژیم جایگزین معتبری "
    "باقی مانده** و در میان این چهار گزینه، تنها گزینه‌ی قابل دفاع است.",
    "This question is solved BY ELIMINATION: three options have definite faults, so the fourth remains.\n\n"
    "THE PATIENT: after travel to southern Iran, fever and chills. A banana-shaped gametocyte on the "
    "film. And the question states explicitly: the patient has no features of severe malaria.\n\n"
    "SO: UNCOMPLICATED FALCIPARUM.\n\n"
    "NOW LET US ELIMINATE:\n\n"
    "WARNING, CHLOROQUINE PLUS PRIMAQUINE: TWO INDEPENDENT FAULTS. One: CHLOROQUINE IS INEFFECTIVE IN "
    "FALCIPARUM (universal resistance). Two: PRIMAQUINE EXISTS TO KILL HYPNOZOITES, AND FALCIPARUM HAS "
    "NONE — so radical cure is meaningless in falciparum. This regimen belongs to VIVAX, not falciparum.\n\n"
    "PROGUANIL PLUS PRIMAQUINE: proguanil alone is a weak therapeutic agent (it is used in prophylaxis "
    "with atovaquone), and the primaquine is wrong again.\n\n"
    "ARTESUNATE PLUS FANSIDAR: the artesunate is right but FANSIDAR (sulfadoxine-pyrimethamine) FACES "
    "WIDESPREAD RESISTANCE and is not a suitable artesunate partner. It also carries a risk of severe "
    "skin reactions (Stevens-Johnson).\n\n"
    "THAT LEAVES: QUININE PLUS CLINDAMYCIN.\n\n"
    "HOW DOES THIS REGIMEN WORK? Quinine is an effective blood schizonticide that STILL WORKS IN "
    "FALCIPARUM, and CLINDAMYCIN IS ITS PARTNER, raising efficacy and allowing the quinine course to "
    "be shortened (quinine alone for seven days; with clindamycin, three days of quinine plus seven of "
    "clindamycin).\n\n"
    "WARNING, AND THIS COMBINATION HAS A SPECIAL PLACE: IN PREGNANCY AND IN CHILDREN, where some other "
    "drugs are restricted. Today ACT is first line, but QUININE PLUS CLINDAMYCIN REMAINS A VALID "
    "ALTERNATIVE, and among these four options it is the only defensible one.",
    ["آرتسونات درست است ولی فانسیدار مقاومت گسترده دارد و شریک مناسبی نیست.",
     "پاسخ صحیح — رژیم ترکیبی معتبر برای فالسیپاروم، به‌ویژه در بارداری و کودکان.",
     "دو ایراد: کلروکین در فالسیپاروم بی‌اثر است، و فالسیپاروم هیپنوزوئیت ندارد.",
     "پروگوانیل تنها ضعیف است، و پریماکین در فالسیپاروم بی‌معناست."],
    ["The artesunate is right but Fansidar faces widespread resistance and is not a suitable partner.",
     "Correct — a valid combination regimen for falciparum, especially in pregnancy and children.",
     "Two faults: chloroquine is ineffective in falciparum, and falciparum has no hypnozoites.",
     "Proguanil alone is weak, and primaquine is meaningless in falciparum."],
    "**پریماکین در فالسیپاروم بی‌معناست — فالسیپاروم هیپنوزوئیت ندارد.**",
    "Primaquine is meaningless in falciparum — falciparum has no hypnozoites.",
    REFS)

# ================================================ HYPNOZOITES AND RADICAL CURE
HYP_FA = [
    "⚠️ **فقط ویواکس و اوال هیپنوزوئیت می‌سازند — این تک‌جمله چند سؤال را حل می‌کند.**",
    "**هیپنوزوئیت شکل خفته‌ی انگل در سلول کبدی است.**",
    "**می‌تواند هفته‌ها تا ماه‌ها و حتی سال‌ها خاموش بماند و سپس فعال شود.**",
    "**و فعال شدن آن، «عود» یا relapse نامیده می‌شود.**",
    "**فالسیپاروم و مالاریه هیچ مرحله‌ی کبدی خفته‌ای ندارند.**",
    "⚠️ **پس در آن‌ها عود واقعی رخ نمی‌دهد و پریماکین لازم نیست.**",
    "**آنچه در فالسیپاروم دیده می‌شود «recrudescence» است: بازگشت از انگل‌های خونی باقی‌مانده.**",
    "**پس دو واژه را قاطی نکنید: relapse از کبد، recrudescence از خون.**",
    "**درمان کامل ویواکس دو مرحله دارد و هر دو لازم است.**",
    "**مرحله‌ی یک: کلروکین، که انگل مرحله‌ی خونی را می‌کشد و علائم را قطع می‌کند.**",
    "⚠️ **مرحله‌ی دو: پریماکین ۱۴ روز، که هیپنوزوئیت‌های کبدی را می‌کشد.**",
    "**بدون مرحله‌ی دوم، بیمار خوب می‌شود ولی ماه‌ها بعد دوباره بیمار می‌شود.**",
    "**و پیش از پریماکین، G6PD باید بررسی شود.**",
    "**چون پریماکین در کمبود G6PD همولیز حاد شدید می‌دهد.**",
]
HYP_EN = [
    "WARNING: ONLY VIVAX AND OVALE MAKE HYPNOZOITES — this single sentence solves several questions.",
    "A hypnozoite is the dormant form of the parasite inside a liver cell.",
    "It can stay silent for weeks, months or even years and then reactivate.",
    "And that reactivation is called a RELAPSE.",
    "Falciparum and malariae have NO dormant liver stage at all.",
    "WARNING, SO TRUE RELAPSE DOES NOT OCCUR IN THEM and primaquine is not needed.",
    "What is seen in falciparum is RECRUDESCENCE: a return from surviving blood-stage parasites.",
    "So do not confuse the two words: relapse comes from the liver, recrudescence from the blood.",
    "Complete treatment of vivax has two stages and both are required.",
    "STAGE ONE: chloroquine, which kills the blood stage and stops the symptoms.",
    "WARNING, STAGE TWO: primaquine for 14 days, which kills the hepatic hypnozoites.",
    "Without the second stage the patient recovers and then falls ill again months later.",
    "And before primaquine, G6PD must be checked.",
    "Because primaquine causes severe acute haemolysis in G6PD deficiency.",
]

add("book:775", "recall", "easy",
    "**فقط اوال (و ویواکس) هیپنوزوئیت دارند — پس فقط آن‌ها درمان رادیکال می‌خواهند.**",
    "Only ovale (and vivax) have hypnozoites — so only they need radical cure.",
    HYP_FA,
    HYP_EN,
    "این سؤال کوتاه‌ترین سؤال بلوک است و **با یک جمله حل می‌شود** — ولی همان جمله چند سؤال "
    "دیگر را هم حل می‌کند.\n\n"
    "⚠️ **قاعده: فقط پلاسمودیوم ویواکس و پلاسمودیوم اوال هیپنوزوئیت می‌سازند.**\n\n"
    "**هیپنوزوئیت چیست؟** شکل **خفته‌ی** انگل در **سلول کبدی**. وقتی پشه انسان را نیش می‌زند، "
    "اسپوروزوئیت وارد کبد می‌شود. در فالسیپاروم و مالاریه، همه‌ی اسپوروزوئیت‌ها بلافاصله "
    "تکثیر می‌شوند و به خون می‌ریزند. **ولی در ویواکس و اوال، بخشی از آن‌ها خاموش می‌مانند** "
    "و می‌توانند **هفته‌ها، ماه‌ها یا حتی سال‌ها** بعد فعال شوند.\n\n"
    "**فعال شدن هیپنوزوئیت را «عود» (relapse) می‌نامند** — و برای جلوگیری از آن، **پریماکین "
    "به مدت ۱۴ روز** لازم است. این را **درمان رادیکال** می‌گویند.\n\n"
    "**در گزینه‌های این سؤال:**\n\n"
    "**پلاسمودیوم اوال** — **هیپنوزوئیت دارد.** پاسخ صحیح.\n\n"
    "**پلاسمودیوم نولزی (Knowlesi)** — گونه‌ای است که از میمون به انسان منتقل می‌شود، عمدتاً "
    "در جنوب شرق آسیا. **هیپنوزوئیت ندارد.** چرخه‌ی خونی آن بسیار کوتاه است (۲۴ ساعت) که "
    "می‌تواند به‌سرعت به بیماری شدید برسد.\n\n"
    "**پلاسمودیوم مالاریه** — **هیپنوزوئیت ندارد.** ولی نکته‌ی جالبی دارد: می‌تواند **سال‌ها** "
    "در خون با پارازیتمی بسیار پایین باقی بماند. این **عود از کبد نیست، بلکه ماندگاری در "
    "خون** است — پس پریماکین کمکی نمی‌کند.\n\n"
    "⚠️ **پلاسمودیوم فالسیپاروم** — **هیپنوزوئیت ندارد.** آنچه گاهی به‌عنوان «عود» دیده "
    "می‌شود، در واقع **recrudescence** است: بازگشت از **انگل‌های خونی باقی‌مانده** که درمان "
    "کاملاً پاکشان نکرده. این با relapse فرق دارد و درمانش تکرار درمان خونی است، نه پریماکین.\n\n"
    "**پس دو واژه را از هم جدا نگه دارید: relapse از کبد می‌آید، recrudescence از خون.**",
    "This is the shortest question in the block and IT IS SOLVED BY ONE SENTENCE — but that same "
    "sentence also solves several others.\n\n"
    "WARNING, THE RULE: ONLY PLASMODIUM VIVAX AND PLASMODIUM OVALE MAKE HYPNOZOITES.\n\n"
    "WHAT IS A HYPNOZOITE? The DORMANT form of the parasite inside a LIVER CELL. When a mosquito bites, "
    "sporozoites enter the liver. In falciparum and malariae they all multiply at once and spill into "
    "the blood. BUT IN VIVAX AND OVALE SOME REMAIN DORMANT and can reactivate WEEKS, MONTHS OR EVEN "
    "YEARS later.\n\n"
    "REACTIVATION OF A HYPNOZOITE IS CALLED A RELAPSE — and to prevent it, PRIMAQUINE FOR 14 DAYS is "
    "required. This is called RADICAL CURE.\n\n"
    "IN THIS QUESTION'S OPTIONS:\n\n"
    "PLASMODIUM OVALE — HAS HYPNOZOITES. The correct answer.\n\n"
    "PLASMODIUM KNOWLESI — a species transmitted from monkeys to humans, mainly in South-East Asia. "
    "NO HYPNOZOITES. Its blood cycle is very short (24 hours), which can bring severe disease rapidly.\n\n"
    "PLASMODIUM MALARIAE — NO HYPNOZOITES. But it has an interesting feature: it can persist FOR YEARS "
    "in the blood at a very low parasitaemia. That is PERSISTENCE IN THE BLOOD, NOT A RELAPSE FROM THE "
    "LIVER — so primaquine does not help.\n\n"
    "WARNING, PLASMODIUM FALCIPARUM — NO HYPNOZOITES. What is sometimes seen as a 'relapse' is in fact "
    "RECRUDESCENCE: a return from SURVIVING BLOOD-STAGE PARASITES that treatment did not fully clear. "
    "That differs from relapse, and its treatment is repeating blood-stage therapy, not primaquine.\n\n"
    "SO KEEP THE TWO WORDS APART: RELAPSE COMES FROM THE LIVER, RECRUDESCENCE FROM THE BLOOD.",
    ["پاسخ صحیح — اوال مثل ویواکس هیپنوزوئیت کبدی دارد و درمان رادیکال با پریماکین می‌خواهد.",
     "گونه‌ی منتقله از میمون در جنوب شرق آسیا؛ هیپنوزوئیت ندارد.",
     "هیپنوزوئیت ندارد؛ ماندگاری طولانی آن در خون است نه در کبد.",
     "هیپنوزوئیت ندارد؛ آنچه دیده می‌شود recrudescence از انگل خونی باقی‌مانده است."],
    ["Correct — like vivax, ovale has hepatic hypnozoites and needs radical cure with primaquine.",
     "A monkey-derived species of South-East Asia; it has no hypnozoites.",
     "No hypnozoites; its long persistence is in the blood, not the liver.",
     "No hypnozoites; what is seen is recrudescence from surviving blood-stage parasites."],
    "**relapse از کبد (ویواکس و اوال) · recrudescence از خون (فالسیپاروم).**",
    "Relapse comes from the liver (vivax and ovale); recrudescence from the blood (falciparum).",
    REFS)

# ============================== THE BLOODBORNE EXCEPTION: TWO ITEMS
BB_FA = HYP_FA + [
    "⚠️ **حالا استثنای زیبای این فصل: مالاریای منتقله از راه خون هیپنوزوئیت ندارد.**",
    "**چرا؟ چون چرخه‌ی کبدی اصلاً طی نمی‌شود.**",
    "**پشه اسپوروزوئیت تزریق می‌کند، و اسپوروزوئیت است که وارد کبد می‌شود.**",
    "**ولی در سوزن یا تزریق خون، آنچه منتقل می‌شود مروزوئیت خونی است.**",
    "**مروزوئیت مستقیماً گلبول قرمز را آلوده می‌کند و هرگز به کبد نمی‌رود.**",
    "⚠️ **نه چرخه‌ی کبدی، نه هیپنوزوئیت، نه عود — پس پریماکین لازم نیست.**",
    "**همین قاعده برای انتقال از جفت به جنین هم برقرار است.**",
    "**پس در این موارد، کلروکین به‌تنهایی درمان کامل است.**",
]
BB_EN = HYP_EN + [
    "WARNING, NOW THE ELEGANT EXCEPTION OF THIS CHAPTER: bloodborne malaria has no hypnozoites.",
    "Why? Because the hepatic cycle is never traversed at all.",
    "The mosquito injects SPOROZOITES, and it is the sporozoite that enters the liver.",
    "But with a needle or a transfusion, what is transmitted is the blood-stage MEROZOITE.",
    "A merozoite infects a red cell directly and never goes to the liver.",
    "WARNING, NO HEPATIC CYCLE, NO HYPNOZOITES, NO RELAPSE — so primaquine is not needed.",
    "The same rule applies to transplacental transmission to a fetus.",
    "So in these cases chloroquine alone is complete treatment.",
]

add("book:776", "vignette", "hard",
    "**ویواکس از راه نیدل‌استیک: کلروکین تنها — چرخه‌ی کبدی طی نشده، پس هیپنوزوئیتی نیست.**",
    "Vivax from a needlestick: CHLOROQUINE ALONE — the hepatic cycle was bypassed, so there are no hypnozoites.",
    BB_FA,
    BB_EN,
    "این **زیباترین سؤال کل فصل انگلی** است، چون یک استثنای منطقی را می‌سنجد که فقط با "
    "**فهمیدن چرخه‌ی زندگی انگل** حل می‌شود — نه با حفظ کردن.\n\n"
    "**موقعیت: تکنسین آزمایشگاهی به دنبال نیدل‌استیک مبتلا به مالاریای ویواکس شده است.**\n\n"
    "**وسوسه‌ی طبیعی:** «ویواکس است، پس کلروکین + پریماکین.» **و این اشتباه است.**\n\n"
    "⚠️ **چرا؟ چرخه‌ی زندگی انگل را دنبال کنید:**\n\n"
    "**در انتقال طبیعی (نیش پشه):** پشه‌ی آنوفل **اسپوروزوئیت** را وارد خون می‌کند. "
    "اسپوروزوئیت **مستقیماً به کبد می‌رود** و در سلول کبدی تکثیر می‌شود. در ویواکس، بخشی از "
    "آن‌ها به‌صورت **هیپنوزوئیت خفته** باقی می‌مانند. سپس مروزوئیت‌ها آزاد می‌شوند و گلبول‌های "
    "قرمز را آلوده می‌کنند.\n\n"
    "**در انتقال از راه خون (نیدل‌استیک، تزریق خون، جفت):** آنچه منتقل می‌شود **اسپوروزوئیت "
    "نیست** — چون اسپوروزوئیت فقط در غده‌ی بزاقی پشه است. آنچه در خون بیمار وجود دارد، "
    "**مروزوئیت و انگل‌های داخل گلبول قرمز** است. **مروزوئیت مستقیماً گلبول قرمز را آلوده "
    "می‌کند و هرگز وارد کبد نمی‌شود.**\n\n"
    "⚠️ **نتیجه: چرخه‌ی کبدی اصلاً طی نمی‌شود. پس هیپنوزوئیتی ساخته نمی‌شود. پس عود رخ "
    "نمی‌دهد. پس پریماکین لازم نیست.**\n\n"
    "**پس کلروکین به‌تنهایی، درمان کامل و قطعی است.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**کلروکین و به دنبال آن پریماکین:** این رژیم استاندارد ویواکسِ **منتقله از پشه** است. "
    "اینجا پریماکین **بی‌فایده** است — و بی‌فایده یعنی **مضر**، چون پریماکین در کمبود G6PD "
    "**همولیز حاد شدید** می‌دهد و ۱۴ روز مصرف اضافی است.\n\n"
    "**آمودیاکین و به دنبال آن پریماکین:** آمودیاکین انتخاب استاندارد ویواکس نیست، و "
    "پریماکین باز هم بی‌مورد است.\n\n"
    "**کلروکین + آرتسونات:** آرتسونات برای **فالسیپاروم** است. افزودن آن به ویواکس ساده، "
    "درمان بیش‌ازحد است.\n\n"
    "**این قاعده را حفظ کنید، چون کتاب دوباره می‌پرسد: مالاریای منتقله از خون (سوزن، تزریق "
    "خون، جفت) هرگز پریماکین نمی‌خواهد.**",
    "This is THE MOST ELEGANT QUESTION IN THE WHOLE PARASITOLOGY CHAPTER, because it tests a logical "
    "exception that can only be solved BY UNDERSTANDING THE PARASITE'S LIFE CYCLE — not by memorising.\n\n"
    "THE SITUATION: a laboratory technician has contracted vivax malaria from a needlestick.\n\n"
    "THE NATURAL TEMPTATION: 'it is vivax, so chloroquine plus primaquine.' AND THAT IS WRONG.\n\n"
    "WARNING, WHY? FOLLOW THE LIFE CYCLE:\n\n"
    "IN NATURAL TRANSMISSION (a mosquito bite): the Anopheles injects SPOROZOITES into the blood. The "
    "sporozoite GOES STRAIGHT TO THE LIVER and multiplies inside a hepatocyte. In vivax, some remain "
    "as DORMANT HYPNOZOITES. Then merozoites are released and infect red cells.\n\n"
    "IN BLOODBORNE TRANSMISSION (needlestick, transfusion, placenta): what is transmitted is NOT A "
    "SPOROZOITE — because sporozoites exist only in the mosquito's salivary gland. What is present in "
    "the patient's blood is MEROZOITES AND PARASITES INSIDE RED CELLS. A MEROZOITE INFECTS A RED CELL "
    "DIRECTLY AND NEVER ENTERS THE LIVER.\n\n"
    "WARNING, THE CONSEQUENCE: THE HEPATIC CYCLE IS NEVER TRAVERSED. SO NO HYPNOZOITES ARE FORMED. SO "
    "NO RELAPSE OCCURS. SO PRIMAQUINE IS NOT NEEDED.\n\n"
    "SO CHLOROQUINE ALONE IS COMPLETE AND DEFINITIVE TREATMENT.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "CHLOROQUINE FOLLOWED BY PRIMAQUINE: that is the standard regimen for MOSQUITO-TRANSMITTED vivax. "
    "Here the primaquine is USELESS — and useless means HARMFUL, because primaquine causes SEVERE "
    "ACUTE HAEMOLYSIS in G6PD deficiency and 14 days of it is superfluous.\n\n"
    "AMODIAQUINE FOLLOWED BY PRIMAQUINE: amodiaquine is not the standard choice for vivax, and the "
    "primaquine is again unnecessary.\n\n"
    "CHLOROQUINE PLUS ARTESUNATE: artesunate is for FALCIPARUM. Adding it to simple vivax is "
    "overtreatment.\n\n"
    "MEMORISE THIS RULE, BECAUSE THE BOOK ASKS IT AGAIN: BLOODBORNE MALARIA (needle, transfusion, "
    "placenta) NEVER NEEDS PRIMAQUINE.",
    ["رژیم استاندارد ویواکسِ منتقله از پشه است؛ اینجا پریماکین بی‌فایده و بالقوه مضر است.",
     "آمودیاکین انتخاب استاندارد ویواکس نیست، و پریماکین هم بی‌مورد است.",
     "پاسخ صحیح — چرخه‌ی کبدی طی نشده، پس هیپنوزوئیتی نیست و پریماکین لازم ندارد.",
     "آرتسونات برای فالسیپاروم است؛ افزودن آن به ویواکس ساده درمان بیش‌ازحد است."],
    ["The standard regimen for mosquito-transmitted vivax; here primaquine is useless and potentially harmful.",
     "Amodiaquine is not the standard choice for vivax, and the primaquine is unnecessary too.",
     "Correct — the hepatic cycle was bypassed, so there are no hypnozoites and no need for primaquine.",
     "Artesunate is for falciparum; adding it to simple vivax is overtreatment."],
    "**سوزن مروزوئیت منتقل می‌کند، نه اسپوروزوئیت — پس کبد دور زده می‌شود.**",
    "A needle transmits merozoites, not sporozoites — so the liver is bypassed.",
    REFS)

add("book:778", "vignette", "hard",
    "**ویواکس پس از تزریق خون: باز هم کلروکین به‌تنهایی — همان استثنا، بار دوم.**",
    "Vivax after a transfusion: again CHLOROQUINE ALONE — the same exception, a second time.",
    BB_FA + [
        "**اینجا سرنخ‌های مورفولوژیک هم به سؤال اضافه شده‌اند.**",
        "**گلبول قرمز بزرگ‌تر و تروفوزوئیت بزرگ: مشخصه‌ی ویواکس.**",
        "⚠️ **و نقاط شوفنر، امضای ویواکس و اوال است.**",
        "**پس گونه قطعی است، و راه انتقال هم در متن آمده: تزریق خون.**",
        "**دو با هم یعنی: ویواکس بدون هیپنوزوئیت.**",
        "**و سؤال گفته مقاومت به کلروکین در منطقه شایع نیست.**",
        "**پس کلروکین همچنان مؤثر است و به‌تنهایی کافی است.**",
    ],
    BB_EN + [
        "Here the morphological clues are added to the question as well.",
        "Enlarged red cells and large trophozoites: characteristic of vivax.",
        "WARNING, AND SCHUFFNER'S DOTS are the signature of vivax and ovale.",
        "So the species is certain, and the route of transmission is stated: a transfusion.",
        "The two together mean: vivax without hypnozoites.",
        "And the question says chloroquine resistance is not common in the area.",
        "So chloroquine still works and is sufficient by itself.",
    ],
    "کتاب همان استثنا را دوباره پرسیده، و این تکرار پیام روشنی دارد: **این قاعده را حفظ "
    "کنید، چون هر سال پرسیده می‌شود.**\n\n"
    "**بیمار: آقای ۴۵ ساله، به دنبال تزریق خون در منطقه‌ی مالاریاخیز، با تب و لرز چند روزه. "
    "در اسمیر: گلبول‌های قرمز بزرگ‌تر، تروفوزوئیت‌های بزرگ، و دانه‌های شوفنر.**\n\n"
    "**گام اول — گونه:**\n\n"
    "⚠️ **گلبول قرمز بزرگ‌شده + نقاط شوفنر = ویواکس (یا اوال).** ویواکس **رتیکولوسیت‌ها** را "
    "ترجیح می‌دهد، که گلبول‌های جوان و بزرگ‌ترند؛ و **نقاط شوفنر** دانه‌های زرد-قهوه‌ای داخل "
    "گلبول آلوده‌اند.\n\n"
    "**گام دوم — راه انتقال: تزریق خون.**\n\n"
    "**و اینجا همان استثنای طلایی وارد می‌شود:**\n\n"
    "⚠️ **خونِ اهداکننده حاوی مروزوئیت و انگل‌های داخل گلبول قرمز است، نه اسپوروزوئیت.** "
    "اسپوروزوئیت فقط در **غده‌ی بزاقی پشه** وجود دارد. **پس چرخه‌ی کبدی طی نمی‌شود، "
    "هیپنوزوئیتی ساخته نمی‌شود، و عود رخ نمی‌دهد.**\n\n"
    "**نتیجه: پریماکین لازم نیست.**\n\n"
    "**گام سوم — مقاومت:** سؤال صریحاً گفته **«اگر در این منطقه مالاریای مقاوم به درمان "
    "شایع نباشد»**. پس **کلروکین همچنان مؤثر است**.\n\n"
    "**پس پاسخ: کلروکین به تنهایی.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**کلروکین + پریماکین:** رژیم استاندارد ویواکسِ **منتقله از پشه**. اینجا پریماکین "
    "**اضافه** است، و اضافه یعنی **قرار دادن بیمار در معرض خطر همولیز G6PD بدون هیچ سود**.\n\n"
    "**مفلوکین + پریماکین:** مفلوکین وقتی لازم است که **مقاومت به کلروکین** وجود داشته باشد — "
    "و سؤال گفته که ندارد. پریماکین هم باز اضافه است.\n\n"
    "⚠️ **پریماکین به تنهایی:** این **خطرناک‌ترین گزینه** است. پریماکین عمدتاً روی "
    "**هیپنوزوئیت کبدی** کار می‌کند و **شیزونتوسید خونی ضعیفی** است. بیمار **مرحله‌ی خونی "
    "فعال** دارد (تب و لرز)، و پریماکین تنها **آن را درمان نمی‌کند** — بیمار همچنان بیمار "
    "می‌ماند.",
    "The book asks the same exception again, and that repetition carries a clear message: MEMORISE "
    "THIS RULE, BECAUSE IT IS ASKED EVERY YEAR.\n\n"
    "THE PATIENT: a 45-year-old man who, following a transfusion in a malarious area, has had fever "
    "and chills for several days. On the film: enlarged red cells, large trophozoites and Schuffner's "
    "dots.\n\n"
    "STEP ONE — SPECIES:\n\n"
    "WARNING, ENLARGED RED CELLS PLUS SCHUFFNER'S DOTS = VIVAX (or ovale). Vivax prefers "
    "RETICULOCYTES, which are young and larger cells; and SCHUFFNER'S DOTS are yellow-brown granules "
    "inside the infected cell.\n\n"
    "STEP TWO — ROUTE OF TRANSMISSION: A TRANSFUSION.\n\n"
    "AND HERE THE GOLDEN EXCEPTION ENTERS:\n\n"
    "WARNING, DONOR BLOOD CONTAINS MEROZOITES AND PARASITES INSIDE RED CELLS, NOT SPOROZOITES. "
    "Sporozoites exist only in the MOSQUITO'S SALIVARY GLAND. SO THE HEPATIC CYCLE IS NOT TRAVERSED, "
    "NO HYPNOZOITES FORM, AND NO RELAPSE OCCURS.\n\n"
    "THE CONSEQUENCE: PRIMAQUINE IS NOT NEEDED.\n\n"
    "STEP THREE — RESISTANCE: the question states explicitly 'IF RESISTANT MALARIA IS NOT COMMON IN "
    "THIS AREA'. So CHLOROQUINE STILL WORKS.\n\n"
    "SO THE ANSWER: CHLOROQUINE ALONE.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "CHLOROQUINE PLUS PRIMAQUINE: the standard regimen for MOSQUITO-TRANSMITTED vivax. Here the "
    "primaquine is SUPERFLUOUS, and superfluous means EXPOSING THE PATIENT TO THE RISK OF G6PD "
    "HAEMOLYSIS FOR NO BENEFIT.\n\n"
    "MEFLOQUINE PLUS PRIMAQUINE: mefloquine is needed when CHLOROQUINE RESISTANCE exists — and the "
    "question says it does not. The primaquine is again superfluous.\n\n"
    "WARNING, PRIMAQUINE ALONE: THIS IS THE MOST DANGEROUS OPTION. Primaquine works mainly on HEPATIC "
    "HYPNOZOITES and is a WEAK BLOOD SCHIZONTICIDE. The patient has ACTIVE BLOOD-STAGE DISEASE (fever "
    "and chills), and primaquine alone WILL NOT TREAT IT — he stays ill.",
    ["رژیم ویواکسِ منتقله از پشه است؛ اینجا پریماکین اضافه و بالقوه مضر است.",
     "پاسخ صحیح — انتقال از راه خون یعنی بدون هیپنوزوئیت، و منطقه هم مقاوم نیست.",
     "مفلوکین وقتی لازم است که مقاومت به کلروکین باشد؛ سؤال گفته نیست.",
     "خطرناک‌ترین گزینه — پریماکین شیزونتوسید خونی ضعیفی است و بیماری فعال را درمان نمی‌کند."],
    ["The mosquito-transmitted vivax regimen; here primaquine is superfluous and potentially harmful.",
     "Correct — bloodborne transmission means no hypnozoites, and the area is not resistant.",
     "Mefloquine is needed when chloroquine resistance exists; the question says it does not.",
     "The most dangerous option — primaquine is a weak blood schizonticide and will not treat active disease."],
    "**تزریق خون = بدون چرخه‌ی کبدی = بدون پریماکین.**",
    "Transfusion = no hepatic cycle = no primaquine.",
    REFS)

add("book:779", "vignette", "easy",
    "**نقاط شوفنر یعنی ویواکس، و در ویواکس کلروکین همچنان خط اول است.**",
    "Schuffner's dots mean vivax, and in vivax chloroquine is still first line.",
    HYP_FA + [
        "**در ویواکس، برخلاف فالسیپاروم، مقاومت به کلروکین هنوز محدود است.**",
        "**پس کلروکین همچنان شیزونتوسید خونی خط اول ویواکس است.**",
        "⚠️ **مناطق مهم مقاومت ویواکس به کلروکین: اندونزی، پاپوآ گینه‌نو و برخی نقاط دیگر.**",
        "**ولی در ایران، کلروکین همچنان برای ویواکس کار می‌کند.**",
        "**و پس از کلروکین، پریماکین ۱۴ روزه برای درمان رادیکال لازم است.**",
    ],
    HYP_EN + [
        "In vivax, unlike falciparum, chloroquine resistance is still limited.",
        "So chloroquine remains the first-line blood schizonticide for vivax.",
        "WARNING, THE MAIN VIVAX CHLOROQUINE-RESISTANT AREAS: Indonesia, Papua New Guinea and a few others.",
        "But in Iran, chloroquine still works for vivax.",
        "And after chloroquine, 14 days of primaquine is needed for radical cure.",
    ],
    "این سؤال ساده است ولی یک تمایز مهم را می‌سنجد: **مقاومت به کلروکین در فالسیپاروم و "
    "ویواکس یکسان نیست.**\n\n"
    "**بیمار: آقای جوان از نیک‌شهر بلوچستان، با تب و لرز و تعریق. در اسمیر: اریتروسیت‌های "
    "حاوی انگل و نقاط شوفنر زرد-قهوه‌ای.**\n\n"
    "⚠️ **نقاط شوفنر = ویواکس (یا اوال).** این دانه‌های زرد-قهوه‌ای در سیتوپلاسم گلبول آلوده "
    "دیده می‌شوند و مشخصه‌ی این دو گونه‌اند. فالسیپاروم آن‌ها را ندارد.\n\n"
    "**حالا نکته‌ی کلیدی: در ویواکس، کلروکین همچنان کار می‌کند.**\n\n"
    "**چرا این نکته مهم است؟** چون در فالسیپاروم گفتیم **کلروکین مرده است** — و دانشجو ممکن "
    "است این را به همه‌ی گونه‌ها تعمیم دهد. **ولی مقاومت ویواکس به کلروکین بسیار محدودتر "
    "است** و عمدتاً در **اندونزی، پاپوآ گینه‌نو** و چند منطقه‌ی دیگر گزارش شده. **در ایران، "
    "کلروکین برای ویواکس همچنان خط اول است.**\n\n"
    "**پس پاسخ: کلروکین.**\n\n"
    "**و نکته‌ی تکمیلی که سؤال نپرسیده ولی حتماً باید بدانید:** این بیمار **ویواکس منتقله از "
    "پشه** دارد (نه از سوزن یا تزریق خون). پس **هیپنوزوئیت دارد** و پس از کلروکین باید "
    "**پریماکین ۱۴ روزه** بگیرد تا عود نکند — با بررسی G6PD پیش از آن.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**مفلوکین:** برای **فالسیپاروم مقاوم به کلروکین** است. در ویواکسِ حساس، **درمان "
    "بیش‌ازحد** با عوارض عصبی-روانی بی‌مورد.\n\n"
    "**آرتسونات:** برای **فالسیپاروم** است، به‌ویژه شکل شدید آن. در ویواکس ساده اندیکاسیون "
    "خط اول ندارد (هرچند در مناطق مقاوم به کلروکین ACT استفاده می‌شود).\n\n"
    "⚠️ **کینین:** داروی خط دوم فالسیپاروم است، با عوارض قابل توجه (سینکونیسم: وزوز گوش، "
    "سردرد، تاری دید؛ و هیپوگلیسمی). در ویواکسِ حساس به کلروکین، هیچ دلیلی برای انتخاب آن "
    "وجود ندارد.",
    "This question is simple but tests an important distinction: CHLOROQUINE RESISTANCE IS NOT THE "
    "SAME IN FALCIPARUM AND IN VIVAX.\n\n"
    "THE PATIENT: a young man from Nikshahr in Baluchestan with fever, chills and sweating. On the "
    "film: parasitised erythrocytes and yellow-brown Schuffner's dots.\n\n"
    "WARNING, SCHUFFNER'S DOTS = VIVAX (or ovale). These yellow-brown granules are seen in the "
    "cytoplasm of the infected cell and are characteristic of these two species. Falciparum does not "
    "have them.\n\n"
    "NOW THE KEY POINT: IN VIVAX, CHLOROQUINE STILL WORKS.\n\n"
    "WHY DOES THIS MATTER? Because we said CHLOROQUINE IS DEAD in falciparum — and a student may "
    "generalise that to all species. BUT VIVAX CHLOROQUINE RESISTANCE IS FAR MORE LIMITED and is "
    "reported mainly in INDONESIA, PAPUA NEW GUINEA and a few other places. IN IRAN, CHLOROQUINE IS "
    "STILL FIRST LINE FOR VIVAX.\n\n"
    "SO THE ANSWER: CHLOROQUINE.\n\n"
    "AND AN ADDITION THE QUESTION DID NOT ASK BUT YOU MUST KNOW: this patient has MOSQUITO-TRANSMITTED "
    "vivax (not needlestick or transfusion). So HE DOES HAVE HYPNOZOITES and after chloroquine he must "
    "receive 14 DAYS OF PRIMAQUINE to prevent relapse — with a G6PD check beforehand.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "MEFLOQUINE: it is for CHLOROQUINE-RESISTANT FALCIPARUM. In sensitive vivax it is OVERTREATMENT "
    "with needless neuropsychiatric side effects.\n\n"
    "ARTESUNATE: it is for FALCIPARUM, especially the severe form. It is not first line in simple "
    "vivax (although ACT is used in chloroquine-resistant vivax areas).\n\n"
    "WARNING, QUININE: a second-line falciparum drug with considerable toxicity (cinchonism: tinnitus, "
    "headache, blurred vision; and hypoglycaemia). In chloroquine-sensitive vivax there is no reason "
    "to choose it.",
    ["برای فالسیپاروم مقاوم به کلروکین است؛ در ویواکس حساس درمان بیش‌ازحد است.",
     "برای فالسیپاروم است، به‌ویژه شکل شدید؛ در ویواکس ساده خط اول نیست.",
     "پاسخ صحیح — نقاط شوفنر یعنی ویواکس، و کلروکین در ویواکس همچنان خط اول است.",
     "خط دوم فالسیپاروم با عوارض سینکونیسم و هیپوگلیسمی؛ اینجا دلیلی برای انتخابش نیست."],
    ["It is for chloroquine-resistant falciparum; in sensitive vivax it is overtreatment.",
     "It is for falciparum, especially severe disease; not first line in simple vivax.",
     "Correct — Schuffner's dots mean vivax, and chloroquine is still first line in vivax.",
     "A second-line falciparum drug with cinchonism and hypoglycaemia; no reason to choose it here."],
    "**کلروکین در فالسیپاروم مرده است، ولی در ویواکس هنوز زنده.**",
    "Chloroquine is dead in falciparum, but still alive in vivax.",
    REFS)

add("book:782", "vignette", "medium",
    "**«تک‌کروماتین» و شیزونت روی لام، فالسیپاروم را رد می‌کند: ویواکس، پس کلروکین + پریماکین.**",
    "A single-chromatin parasite with schizonts on the film argues against falciparum: vivax, so chloroquine plus primaquine.",
    HYP_FA + [
        "**دو نشانه‌ی روی این لام با هم معنا پیدا می‌کنند.**",
        "**رینگ تک‌کروماتین در برابر دابل‌کروماتین: دابل مشخصه‌ی فالسیپاروم است.**",
        "⚠️ **و دیدن شیزونت در خون محیطی، خودش فالسیپاروم را کم‌احتمال می‌کند.**",
        "**چرا؟ چون شیزونت فالسیپاروم در مویرگ‌های عمقی سکستره می‌شود.**",
        "**پس در خون محیطی فالسیپاروم معمولاً فقط رینگ و گامتوسیت دیده می‌شود.**",
        "**دیدن همه‌ی مراحل، از جمله شیزونت، به نفع ویواکس است.**",
        "**و ویواکس منتقله از پشه، هیپنوزوئیت دارد.**",
        "⚠️ **پس درمان دومرحله‌ای است: کلروکین سپس پریماکین.**",
    ],
    HYP_EN + [
        "Two signs on this film take on meaning together.",
        "A SINGLE-chromatin ring versus a double one: the double is characteristic of falciparum.",
        "WARNING, AND SEEING SCHIZONTS IN PERIPHERAL BLOOD itself argues against falciparum.",
        "Why? Because falciparum schizonts sequester in deep capillaries.",
        "So in falciparum peripheral blood usually shows only rings and gametocytes.",
        "Seeing all stages, including schizonts, favours vivax.",
        "And mosquito-transmitted vivax does have hypnozoites.",
        "WARNING, SO THE TREATMENT IS TWO-STAGE: chloroquine, then primaquine.",
    ],
    "این سؤال یک نکته‌ی مورفولوژیک ظریف را می‌سنجد که ارزش بالینی واقعی دارد.\n\n"
    "**بیمار: پس از سفر به جنوب شرق ایران، تب و لرز و سردرد. در لام: پارازیت‌های "
    "تک‌کروماتین (Single-chromatin) و شیزونت.**\n\n"
    "**دو نشانه، و هر دو در یک جهت:**\n\n"
    "**نشانه‌ی اول — تک‌کروماتین در برابر دابل‌کروماتین.** رینگ **دابل‌کروماتین** (شکل هدفون) "
    "**مشخصه‌ی فالسیپاروم** است. اینجا تک‌کروماتین گزارش شده، پس **به نفع فالسیپاروم نیست**.\n\n"
    "⚠️ **نشانه‌ی دوم — دیدن شیزونت در خون محیطی، و این نکته‌ی زیبای سؤال است.** "
    "**شیزونت‌های فالسیپاروم در مویرگ‌های عمقی سکستره می‌شوند** — به دیواره‌ی عروق می‌چسبند و "
    "از گردش خون محیطی خارج می‌شوند. به همین دلیل، در لام فالسیپاروم معمولاً **فقط رینگ و "
    "گامتوسیت** دیده می‌شود. **دیدن شیزونت در خون محیطی، فالسیپاروم را کم‌احتمال و ویواکس را "
    "محتمل می‌کند** (چون ویواکس سکستره نمی‌شود و همه‌ی مراحلش در خون محیطی دیده می‌شود).\n\n"
    "**پس تشخیص: ویواکس.**\n\n"
    "**و درمان ویواکسِ منتقله از پشه دو مرحله دارد:**\n\n"
    "**مرحله‌ی یک — کلروکین فسفات:** انگل مرحله‌ی خونی را می‌کشد و علائم را قطع می‌کند.\n\n"
    "⚠️ **مرحله‌ی دو — پریماکین ۱۴ روز:** هیپنوزوئیت‌های کبدی را می‌کشد و از **عود** جلوگیری "
    "می‌کند. (با بررسی G6PD پیش از آن.)\n\n"
    "**پس پاسخ: کلروکین فسفات + پریماکین.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**کلروکین فسفات تنها:** مرحله‌ی خونی را درمان می‌کند ولی **هیپنوزوئیت‌ها باقی می‌مانند**. "
    "بیمار خوب می‌شود و **ماه‌ها بعد دوباره بیمار می‌شود**. این **درمان ناقص** است.\n\n"
    "**کلروکین فسفات + فانسیدار:** فانسیدار (سولفادوکسین-پیریمتامین) در ویواکس اندیکاسیون "
    "ندارد و مقاومت گسترده دارد. و **مرحله‌ی کبدی همچنان بدون درمان می‌ماند**.\n\n"
    "**مفلوکین:** برای فالسیپاروم مقاوم به کلروکین است. در ویواکس، درمان بیش‌ازحد، و باز هم "
    "**بدون پوشش هیپنوزوئیت**.",
    "This question tests a subtle morphological point with real clinical value.\n\n"
    "THE PATIENT: after travel to south-eastern Iran, fever, chills and headache. On the film: "
    "SINGLE-CHROMATIN parasites and SCHIZONTS.\n\n"
    "TWO SIGNS, BOTH POINTING THE SAME WAY:\n\n"
    "SIGN ONE — SINGLE versus DOUBLE chromatin. A DOUBLE-CHROMATIN ring (the headphone form) IS "
    "CHARACTERISTIC OF FALCIPARUM. Here single chromatin is reported, so IT DOES NOT FAVOUR FALCIPARUM.\n\n"
    "WARNING, SIGN TWO — SEEING SCHIZONTS IN PERIPHERAL BLOOD, and this is the elegant point of the "
    "question. FALCIPARUM SCHIZONTS SEQUESTER IN DEEP CAPILLARIES — they adhere to the vessel wall and "
    "leave the peripheral circulation. That is why a falciparum film usually shows ONLY RINGS AND "
    "GAMETOCYTES. SEEING SCHIZONTS PERIPHERALLY MAKES FALCIPARUM UNLIKELY AND VIVAX LIKELY (because "
    "vivax does not sequester and all its stages are visible peripherally).\n\n"
    "SO THE DIAGNOSIS: VIVAX.\n\n"
    "AND TREATMENT OF MOSQUITO-TRANSMITTED VIVAX HAS TWO STAGES:\n\n"
    "STAGE ONE — CHLOROQUINE PHOSPHATE: kills the blood stage and stops the symptoms.\n\n"
    "WARNING, STAGE TWO — PRIMAQUINE FOR 14 DAYS: kills the hepatic hypnozoites and prevents RELAPSE. "
    "(With a G6PD check beforehand.)\n\n"
    "SO THE ANSWER: CHLOROQUINE PHOSPHATE PLUS PRIMAQUINE.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "CHLOROQUINE PHOSPHATE ALONE: it treats the blood stage but THE HYPNOZOITES SURVIVE. The patient "
    "recovers and FALLS ILL AGAIN MONTHS LATER. This is INCOMPLETE TREATMENT.\n\n"
    "CHLOROQUINE PHOSPHATE PLUS FANSIDAR: Fansidar (sulfadoxine-pyrimethamine) is not indicated in "
    "vivax and faces widespread resistance. And THE HEPATIC STAGE IS STILL LEFT UNTREATED.\n\n"
    "MEFLOQUINE: it is for chloroquine-resistant falciparum. In vivax it is overtreatment, and again "
    "WITHOUT HYPNOZOITE COVER.",
    ["مرحله‌ی خونی درمان می‌شود ولی هیپنوزوئیت‌ها می‌مانند؛ عود ماه‌ها بعد رخ می‌دهد.",
     "پاسخ صحیح — کلروکین برای مرحله‌ی خونی و پریماکین برای هیپنوزوئیت کبدی.",
     "فانسیدار در ویواکس اندیکاسیون ندارد، و مرحله‌ی کبدی بدون درمان می‌ماند.",
     "برای فالسیپاروم مقاوم است؛ در ویواکس بیش‌ازحد و بدون پوشش هیپنوزوئیت."],
    ["The blood stage is treated but the hypnozoites remain; relapse follows months later.",
     "Correct — chloroquine for the blood stage and primaquine for the hepatic hypnozoites.",
     "Fansidar is not indicated in vivax, and the hepatic stage is left untreated.",
     "It is for resistant falciparum; in vivax it is excessive and gives no hypnozoite cover."],
    "**شیزونت در خون محیطی = فالسیپاروم نیست، چون فالسیپاروم شیزونت را سکستره می‌کند.**",
    "Schizonts in peripheral blood = not falciparum, because falciparum sequesters its schizonts.",
    REFS)

# ============================================== VIVAX IN PREGNANCY: TWO ITEMS
PREG_FA = HYP_FA + [
    "⚠️ **پریماکین در بارداری ممنوع است — و دلیلش را باید بدانید.**",
    "**وضعیت G6PD جنین قابل بررسی نیست.**",
    "**و پریماکین از جفت عبور می‌کند.**",
    "**پس اگر جنین کمبود G6PD داشته باشد، دچار همولیز داخل رحمی می‌شود.**",
    "**راه‌حل: مرحله‌ی خونی را درمان کنید، و مرحله‌ی کبدی را به تعویق بیندازید.**",
    "**یعنی کلروکین درمانی، سپس کلروکین هفتگی سرکوب‌گر تا زایمان.**",
    "⚠️ **چرا کلروکین هفتگی؟ چون هیپنوزوئیت‌ها هنوز زنده‌اند و می‌توانند عود بدهند.**",
    "**کلروکین هفتگی هر عود خونی را سرکوب می‌کند تا بارداری تمام شود.**",
    "**و پس از زایمان، پریماکین ۱۴ روزه داده می‌شود.**",
    "**البته با بررسی G6PD مادر و توجه به شیردهی.**",
]
PREG_EN = HYP_EN + [
    "WARNING: PRIMAQUINE IS CONTRAINDICATED IN PREGNANCY — and you must know why.",
    "The fetus's G6PD status cannot be determined.",
    "And primaquine crosses the placenta.",
    "So if the fetus is G6PD deficient, it suffers intrauterine haemolysis.",
    "The solution: treat the blood stage, and postpone the hepatic stage.",
    "That means therapeutic chloroquine, then weekly suppressive chloroquine until delivery.",
    "WARNING, WHY WEEKLY CHLOROQUINE? Because the hypnozoites are still alive and can relapse.",
    "Weekly chloroquine suppresses each blood relapse until the pregnancy ends.",
    "And after delivery, 14 days of primaquine is given.",
    "With a maternal G6PD check, and with breastfeeding taken into account.",
]

add("book:780", "vignette", "hard",
    "**ویواکس در بارداری: کلروکین درمانی سه روز، سپس کلروکین هفتگی تا زایمان — پریماکین بعداً.**",
    "Vivax in pregnancy: three days of therapeutic chloroquine, then weekly chloroquine until delivery — primaquine later.",
    PREG_FA,
    PREG_EN,
    "این سؤال یکی از دشوارترین تصمیم‌های درمانی مالاریاست، چون **باید یک مرحله‌ی درمان را "
    "عمداً به تعویق بیندازیم**.\n\n"
    "**بیمار: خانم حامله، پس از بازگشت از هند، با تب و لرزهای متناوب. تشخیص مالاریای ویواکس "
    "تأیید شده.**\n\n"
    "**درمان استاندارد ویواکس دو مرحله دارد: کلروکین (مرحله‌ی خونی) + پریماکین ۱۴ روز "
    "(مرحله‌ی کبدی، درمان رادیکال).**\n\n"
    "⚠️ **ولی این بیمار باردار است، و پریماکین در بارداری ممنوع است. چرا؟**\n\n"
    "**پریماکین در کمبود G6PD همولیز حاد می‌دهد. وضعیت G6PD جنین قابل بررسی نیست** — نمی‌توانیم "
    "پیش از تولد بدانیم جنین کمبود دارد یا نه. و **پریماکین از جفت عبور می‌کند**. پس اگر "
    "جنین کمبود G6PD داشته باشد، دچار **همولیز داخل رحمی** می‌شود، که می‌تواند به آنمی شدید "
    "جنین و مرگ داخل رحمی منجر شود.\n\n"
    "**پس چه کنیم؟ راهبرد «درمان کن و به تعویق بینداز»:**\n\n"
    "**گام یک — کلروکین درمانی سه روزه:** مرحله‌ی خونی را می‌کشد و علائم را قطع می‌کند.\n\n"
    "⚠️ **گام دو — کلروکین هفتگی تا آخر حاملگی:** این بخش کلیدی و ظریف سؤال است. "
    "**هیپنوزوئیت‌ها هنوز در کبد زنده‌اند** و می‌توانند هر زمان فعال شوند و **عود** بدهند. "
    "کلروکین هفتگی (دوز سرکوب‌گر) **هر عود خونی را قبل از علامت‌دار شدن سرکوب می‌کند** تا "
    "بارداری بی‌خطر به پایان برسد.\n\n"
    "**گام سه — پس از زایمان: پریماکین ۱۴ روزه** برای درمان رادیکال، با بررسی G6PD مادر.\n\n"
    "**پس پاسخ: کلروکین تا سه روز و ادامه‌ی آن هفتگی تا آخر حاملگی.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**آرتسونات سپس پریماکین هفتگی:** **پریماکین در بارداری ممنوع است** — این ایراد قطعی "
    "است. آرتسونات هم برای فالسیپاروم است.\n\n"
    "⚠️ **کلروکین سه روز سپس پریماکین ۱۴ روز:** این **رژیم استاندارد غیرباردار** است. در "
    "این بیمار **پریماکین جنین را به خطر می‌اندازد**.\n\n"
    "**اتوواکون-پروگوانیل:** داروی **پروفیلاکسی** است (و در بارداری هم داده‌های ایمنی کافی "
    "ندارد)، نه درمان ویواکس تأییدشده.",
    "This is one of the harder treatment decisions in malaria, because WE MUST DELIBERATELY POSTPONE "
    "ONE STAGE OF THE TREATMENT.\n\n"
    "THE PATIENT: a pregnant woman returning from India with intermittent fever and chills. Vivax "
    "malaria has been confirmed.\n\n"
    "STANDARD VIVAX TREATMENT HAS TWO STAGES: chloroquine (blood stage) plus 14 days of primaquine "
    "(hepatic stage, radical cure).\n\n"
    "WARNING, BUT THIS PATIENT IS PREGNANT, AND PRIMAQUINE IS CONTRAINDICATED IN PREGNANCY. WHY?\n\n"
    "PRIMAQUINE CAUSES ACUTE HAEMOLYSIS IN G6PD DEFICIENCY. THE FETUS'S G6PD STATUS CANNOT BE "
    "DETERMINED — we cannot know before birth whether the fetus is deficient. And PRIMAQUINE CROSSES "
    "THE PLACENTA. So if the fetus is G6PD deficient it suffers INTRAUTERINE HAEMOLYSIS, which can "
    "lead to severe fetal anaemia and intrauterine death.\n\n"
    "SO WHAT DO WE DO? THE 'TREAT AND POSTPONE' STRATEGY:\n\n"
    "STEP ONE — THREE DAYS OF THERAPEUTIC CHLOROQUINE: kills the blood stage and stops the symptoms.\n\n"
    "WARNING, STEP TWO — WEEKLY CHLOROQUINE UNTIL DELIVERY: this is the key, subtle part of the "
    "question. THE HYPNOZOITES ARE STILL ALIVE IN THE LIVER and can reactivate at any time and cause a "
    "RELAPSE. Weekly chloroquine (a suppressive dose) SUPPRESSES EACH BLOOD RELAPSE BEFORE IT BECOMES "
    "SYMPTOMATIC, so the pregnancy reaches term safely.\n\n"
    "STEP THREE — AFTER DELIVERY: 14 DAYS OF PRIMAQUINE for radical cure, with a maternal G6PD check.\n\n"
    "SO THE ANSWER: CHLOROQUINE FOR THREE DAYS, CONTINUED WEEKLY UNTIL DELIVERY.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ARTESUNATE THEN WEEKLY PRIMAQUINE: PRIMAQUINE IS CONTRAINDICATED IN PREGNANCY — a decisive fault. "
    "And artesunate is for falciparum.\n\n"
    "WARNING, CHLOROQUINE FOR THREE DAYS THEN PRIMAQUINE FOR 14 DAYS: this is THE STANDARD "
    "NON-PREGNANT REGIMEN. In this patient THE PRIMAQUINE ENDANGERS THE FETUS.\n\n"
    "ATOVAQUONE-PROGUANIL: a PROPHYLACTIC drug (and one without adequate pregnancy safety data), not "
    "an approved vivax treatment.",
    ["پاسخ صحیح — کلروکین درمانی، سپس کلروکین سرکوب‌گر هفتگی تا زایمان؛ پریماکین پس از زایمان.",
     "پریماکین در بارداری ممنوع است، و آرتسونات هم برای فالسیپاروم است.",
     "رژیم استاندارد غیرباردار است؛ پریماکین در بارداری جنین را به خطر می‌اندازد.",
     "داروی پروفیلاکسی است و در بارداری داده‌های ایمنی کافی ندارد؛ درمان تأییدشده‌ی ویواکس نیست."],
    ["Correct — therapeutic chloroquine, then weekly suppressive chloroquine until delivery; primaquine afterwards.",
     "Primaquine is contraindicated in pregnancy, and artesunate is for falciparum.",
     "The standard non-pregnant regimen; primaquine in pregnancy endangers the fetus.",
     "A prophylactic drug without adequate pregnancy safety data; not an approved vivax treatment."],
    "**در بارداری: مرحله‌ی خونی را درمان کن، مرحله‌ی کبدی را تا زایمان به تعویق بینداز.**",
    "In pregnancy: treat the blood stage, postpone the hepatic stage until after delivery.",
    REFS)

add("book:781", "vignette", "hard",
    "**پریماکین پس از وضع حمل — حتی وقتی G6PD خود مادر طبیعی است.**",
    "Primaquine AFTER delivery — even when the mother's own G6PD is normal.",
    PREG_FA + [
        "**این سؤال یک تله‌ی دقیق دارد: G6PD مادر نرمال گزارش شده است.**",
        "⚠️ **ولی مسئله هرگز G6PD مادر نبوده؛ مسئله G6PD جنین است.**",
        "**و G6PD جنین را پیش از تولد نمی‌توان دانست.**",
        "**پس نرمال بودن G6PD مادر، ممنوعیت پریماکین در بارداری را برنمی‌دارد.**",
        "**همچنین این مورد از راه سوزن منتقل شده است، پس اصلاً هیپنوزوئیت ندارد.**",
        "**که خود دلیل مستقل دیگری بر عجله نکردن است.**",
    ],
    PREG_EN + [
        "This question contains a precise trap: the mother's G6PD is reported normal.",
        "WARNING, BUT THE ISSUE WAS NEVER THE MOTHER'S G6PD; IT IS THE FETUS'S.",
        "And the fetus's G6PD cannot be known before birth.",
        "So a normal maternal G6PD does not lift the contraindication in pregnancy.",
        "This case was also acquired by needlestick, so it has no hypnozoites at all.",
        "Which is an independent further reason not to hurry.",
    ],
    "این سؤال یک **تله‌ی بسیار دقیق** دارد، و کسی که فقط قاعده را حفظ کرده باشد در آن "
    "می‌افتد.\n\n"
    "**موقعیت: یکی از پرسنل آزمایشگاه با نیدل‌استیک به مالاریای ویواکس مبتلا شده. درمان "
    "استاندارد با کلروکین شروع شده. حالا سؤال: اگر این پرسنل حامله باشد و فعالیت آنزیم G6PD "
    "او نرمال باشد، پریماکین را چگونه بدهیم؟**\n\n"
    "⚠️ **تله دقیقاً همین‌جاست: «G6PD نرمال» ذکر شده تا شما فکر کنید مانع برداشته شده است.**\n\n"
    "**ولی مسئله هرگز G6PD مادر نبوده. مسئله G6PD جنین است.**\n\n"
    "**پریماکین از جفت عبور می‌کند. اگر جنین کمبود G6PD داشته باشد — که ژنتیک آن مستقل از "
    "مادر است و پیش از تولد قابل بررسی نیست — دچار همولیز داخل رحمی می‌شود.** پس **نرمال بودن "
    "G6PD مادر، ممنوعیت پریماکین در بارداری را برنمی‌دارد**.\n\n"
    "**پس پاسخ: شروع پریماکین پس از وضع حمل.**\n\n"
    "⚠️ **و یک نکته‌ی اضافی که این سؤال را جالب‌تر می‌کند:** این عفونت از راه **نیدل‌استیک** "
    "منتقل شده است. یعنی **چرخه‌ی کبدی طی نشده و اصلاً هیپنوزوئیتی وجود ندارد**. پس **حتی "
    "دلیل پزشکی برای عجله در دادن پریماکین هم وجود ندارد** — از هر دو زاویه، به تعویق انداختن "
    "درست است.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**«درمان کلروکین به‌تنهایی کافی است»:** این گزینه **در این مورد خاص از نظر پزشکی نزدیک "
    "به درست است** (چون نیدل‌استیک هیپنوزوئیت نمی‌سازد)، ولی به‌عنوان **قاعده‌ی کلی برای "
    "ویواکس نادرست است** و سؤال درباره‌ی **نحوه‌ی صحیح استفاده از پریماکین** می‌پرسد، یعنی "
    "فرض کرده که پریماکین در برنامه هست. پاسخ باید **زمان‌بندی** آن را بگوید.\n\n"
    "**سه قرص در هفته به مدت ۸ هفته:** این رژیم **جایگزین در کمبود خفیف تا متوسط G6PD** است "
    "(دوز هفتگی به‌جای روزانه، برای کاهش همولیز). ولی مسئله‌ی این بیمار **G6PD مادر نیست، "
    "بارداری است** — و این رژیم هم در بارداری ممنوع است.\n\n"
    "**یک قرص روزانه به مدت دو هفته:** این **دوره‌ی استاندارد ۱۴ روزه** است، ولی **در بارداری "
    "نباید داده شود**.",
    "This question contains A VERY PRECISE TRAP, and anyone who has merely memorised the rule will "
    "fall into it.\n\n"
    "THE SITUATION: a laboratory worker has contracted vivax malaria from a needlestick. Standard "
    "chloroquine treatment has begun. Now the question: if this worker is pregnant and her G6PD enzyme "
    "activity is normal, how should primaquine be given?\n\n"
    "WARNING, THE TRAP IS EXACTLY HERE: 'NORMAL G6PD' IS STATED so that you think the obstacle has "
    "been removed.\n\n"
    "BUT THE ISSUE WAS NEVER THE MOTHER'S G6PD. IT IS THE FETUS'S.\n\n"
    "PRIMAQUINE CROSSES THE PLACENTA. If the fetus is G6PD deficient — and its genetics are "
    "independent of the mother's and cannot be tested before birth — it suffers INTRAUTERINE "
    "HAEMOLYSIS. So A NORMAL MATERNAL G6PD DOES NOT LIFT THE CONTRAINDICATION IN PREGNANCY.\n\n"
    "SO THE ANSWER: START PRIMAQUINE AFTER DELIVERY.\n\n"
    "WARNING, AND AN EXTRA POINT THAT MAKES THIS QUESTION MORE INTERESTING: this infection was "
    "acquired by NEEDLESTICK. That means THE HEPATIC CYCLE WAS BYPASSED AND THERE ARE NO HYPNOZOITES "
    "AT ALL. So THERE IS NOT EVEN A MEDICAL REASON TO HURRY with the primaquine — from both angles, "
    "postponing is correct.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "'CHLOROQUINE ALONE IS SUFFICIENT': in THIS PARTICULAR CASE this is medically close to correct "
    "(because a needlestick makes no hypnozoites), but AS A GENERAL RULE FOR VIVAX IT IS WRONG, and "
    "the question asks about THE CORRECT WAY TO USE PRIMAQUINE, that is, it presupposes primaquine is "
    "in the plan. The answer must state its TIMING.\n\n"
    "THREE TABLETS A WEEK FOR EIGHT WEEKS: that is the ALTERNATIVE REGIMEN FOR MILD TO MODERATE G6PD "
    "DEFICIENCY (a weekly instead of daily dose, to reduce haemolysis). But this patient's problem is "
    "NOT HER G6PD, IT IS THE PREGNANCY — and this regimen too is contraindicated in pregnancy.\n\n"
    "ONE TABLET DAILY FOR TWO WEEKS: that is the STANDARD 14-DAY COURSE, but IT MUST NOT BE GIVEN IN "
    "PREGNANCY.",
    ["پاسخ صحیح — پریماکین از جفت عبور می‌کند و G6PD جنین ناشناخته است، پس تا پس از زایمان صبر می‌کنیم.",
     "در این مورد خاص از نظر پزشکی نزدیک به درست است، ولی قاعده‌ی کلی ویواکس نیست و سؤال زمان‌بندی می‌خواهد.",
     "رژیم جایگزین برای کمبود G6PD خود بیمار است؛ مسئله‌ی اینجا بارداری است، نه G6PD مادر.",
     "دوره‌ی استاندارد ۱۴ روزه است ولی در بارداری نباید داده شود."],
    ["Correct — primaquine crosses the placenta and the fetal G6PD is unknown, so we wait until after delivery.",
     "Medically close to right in this particular case, but not the general vivax rule; the question asks about timing.",
     "The alternative regimen for the patient's own G6PD deficiency; the issue here is pregnancy, not maternal G6PD.",
     "The standard 14-day course, but it must not be given in pregnancy."],
    "**مسئله G6PD مادر نیست — G6PD جنین است، و آن را نمی‌توان دانست.**",
    "The issue is not the mother's G6PD — it is the fetus's, and that cannot be known.",
    REFS)

# ================================================== PROPHYLAXIS: FIVE ITEMS
PROP_FA = [
    "⚠️ **پروفیلاکسی مالاریا با یک سؤال انتخاب می‌شود: مقصد به کلروکین مقاوم است یا نه؟**",
    "**منطقه‌ی حساس به کلروکین: کلروکین هفتگی.**",
    "**منطقه‌ی مقاوم به کلروکین: مفلوکین هفتگی، یا داکسی‌سیکلین روزانه، یا اتوواکون-پروگوانیل روزانه.**",
    "**و بارداری در منطقه‌ی مقاوم: فقط مفلوکین.**",
    "⚠️ **چرا فقط مفلوکین در بارداری؟ چون دو گزینه‌ی دیگر حذف می‌شوند.**",
    "**داکسی‌سیکلین در بارداری ممنوع است: اثر بر دندان و استخوان جنین.**",
    "**و اتوواکون-پروگوانیل داده‌های ایمنی کافی در بارداری ندارد.**",
    "**پس مفلوکین تنها گزینه‌ی ایمن باقی‌مانده در منطقه‌ی مقاوم است.**",
    "**زمان‌بندی‌ها را هم بشمارید، چون کتاب از آن‌ها سؤال ساخته است.**",
    "**اتوواکون-پروگوانیل: ۱ تا ۲ روز قبل، تا ۷ روز پس از ترک منطقه.**",
    "⚠️ **مفلوکین: ۱ تا ۲ هفته قبل، تا ۴ هفته پس از ترک منطقه.**",
    "**داکسی‌سیکلین: ۱ تا ۲ روز قبل، تا ۴ هفته پس از ترک منطقه.**",
    "**چرا دنباله‌ی اتوواکون-پروگوانیل کوتاه است؟ چون مرحله‌ی کبدی را هم می‌کشد.**",
    "**دو داروی دیگر فقط مرحله‌ی خونی را سرکوب می‌کنند، پس باید از فاز کبدی طولانی‌تر بمانند.**",
    "⚠️ **و هیچ واکسن مالاریایی برای مسافر وجود ندارد.**",
    "**واکسن‌های RTS,S و R21 برای کودکان مناطق پرانتقال آفریقایی طراحی شده‌اند، نه برای مسافر.**",
    "**و در همه‌ی موارد، پیشگیری از گزش پشه لایه‌ی اول است: پشه‌بند، دافع حشرات، لباس پوشیده.**",
]
PROP_EN = [
    "WARNING: MALARIA PROPHYLAXIS IS CHOSEN BY ONE QUESTION: is the destination chloroquine resistant?",
    "CHLOROQUINE-SENSITIVE area: weekly chloroquine.",
    "CHLOROQUINE-RESISTANT area: weekly mefloquine, or daily doxycycline, or daily atovaquone-proguanil.",
    "And PREGNANCY in a resistant area: MEFLOQUINE ONLY.",
    "WARNING, WHY ONLY MEFLOQUINE IN PREGNANCY? Because the other two are eliminated.",
    "Doxycycline is contraindicated in pregnancy: effects on fetal teeth and bone.",
    "And atovaquone-proguanil lacks adequate pregnancy safety data.",
    "So mefloquine is the only safe option left in a resistant area.",
    "Count the timings too, because the book has built a question on them.",
    "ATOVAQUONE-PROGUANIL: 1 to 2 days before, until 7 DAYS after leaving.",
    "WARNING, MEFLOQUINE: 1 to 2 weeks before, until 4 WEEKS after leaving.",
    "DOXYCYCLINE: 1 to 2 days before, until 4 WEEKS after leaving.",
    "Why is the atovaquone-proguanil tail short? Because it also kills the liver stage.",
    "The other two only suppress the blood stage, so they must outlast the hepatic phase.",
    "WARNING, AND THERE IS NO MALARIA VACCINE FOR TRAVELLERS.",
    "The RTS,S and R21 vaccines are designed for children in high-transmission African settings, not travellers.",
    "And in every case, bite prevention is the first layer: nets, repellents, covering clothing.",
]

add("book:794", "recall", "easy",
    "**مفلوکین انتخاب استاندارد پروفیلاکسی برای مسافر به منطقه‌ی مالاریاخیز است.**",
    "Mefloquine is the standard prophylactic choice for a traveller to a malarious area.",
    PROP_FA,
    PROP_EN,
    "این ساده‌ترین سؤال بلوک پروفیلاکسی است و **چارچوب را برای بقیه می‌سازد**.\n\n"
    "**موقعیت: آقای ۲۸ ساله، پیش از سفر به منطقه‌ی مالاریاخیز، برای پروفیلاکسی مراجعه کرده.**\n\n"
    "⚠️ **قاعده‌ی انتخاب: مقصد به کلروکین مقاوم است یا نه؟** امروز **اکثر مناطق مالاریاخیز "
    "جهان مقاوم به کلروکین‌اند**، پس در نبود اطلاعات خاص، فرض بر مقاومت است.\n\n"
    "**در منطقه‌ی مقاوم، سه گزینه داریم:** **مفلوکین** هفتگی، **داکسی‌سیکلین** روزانه، و "
    "**اتوواکون-پروگوانیل** روزانه.\n\n"
    "**در میان چهار گزینه‌ی این سؤال، فقط مفلوکین یکی از این سه است.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**کلروکین:** فقط برای **مناطق حساس به کلروکین** است، که امروز بسیار محدودند. برای "
    "مسافر به یک منطقه‌ی مالاریاخیز نامشخص، **انتخاب امنی نیست** — چون اگر مقصد مقاوم باشد، "
    "**پروفیلاکسی شکست می‌خورد** و مسافر با احساس کاذب ایمنی سفر می‌کند.\n\n"
    "⚠️ **داپسون:** این دارو **در پروفیلاکسی مالاریا جایی ندارد**. داپسون برای **جذام** و "
    "**پروفیلاکسی پنوموسیستیس** استفاده می‌شود. (ترکیب قدیمی داپسون-پیریمتامین «مالوپریم» "
    "به‌دلیل عوارض خونی کنار گذاشته شد.)\n\n"
    "**پریماکین:** پریماکین **می‌تواند** به‌عنوان پروفیلاکسی اولیه در شرایط خاص استفاده شود "
    "(چون مرحله‌ی کبدی را می‌کشد)، ولی **انتخاب استاندارد نیست**: نیاز به **بررسی G6PD پیش "
    "از شروع** دارد، در بارداری ممنوع است، و به‌عنوان خط اول توصیه نمی‌شود.\n\n"
    "**نکته‌ی عملی که همیشه باید گفته شود:** **پروفیلاکسی دارویی هرگز صد درصد نیست.** "
    "**پیشگیری از گزش پشه — پشه‌بند آغشته به حشره‌کش، دافع حشرات حاوی DEET، لباس آستین‌بلند، "
    "و پرهیز از فضای باز در غروب و شب — لایه‌ی اول محافظت است** و باید همیشه همراه دارو "
    "توصیه شود.",
    "This is the simplest question in the prophylaxis block and IT SETS THE FRAMEWORK FOR THE REST.\n\n"
    "THE SITUATION: a 28-year-old man attending before travel to a malarious area for prophylaxis.\n\n"
    "WARNING, THE SELECTION RULE: IS THE DESTINATION CHLOROQUINE RESISTANT? Today MOST MALARIOUS AREAS "
    "OF THE WORLD ARE CHLOROQUINE RESISTANT, so in the absence of specific information resistance is "
    "assumed.\n\n"
    "IN A RESISTANT AREA WE HAVE THREE OPTIONS: weekly MEFLOQUINE, daily DOXYCYCLINE, and daily "
    "ATOVAQUONE-PROGUANIL.\n\n"
    "AMONG THIS QUESTION'S FOUR OPTIONS, ONLY MEFLOQUINE IS ONE OF THOSE THREE.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "CHLOROQUINE: it is only for CHLOROQUINE-SENSITIVE AREAS, which are now very limited. For a "
    "traveller to an unspecified malarious area IT IS NOT A SAFE CHOICE — because if the destination "
    "is resistant, THE PROPHYLAXIS FAILS and the traveller journeys with a false sense of protection.\n\n"
    "WARNING, DAPSONE: this drug HAS NO PLACE IN MALARIA PROPHYLAXIS. Dapsone is used for LEPROSY and "
    "for PNEUMOCYSTIS PROPHYLAXIS. (The old dapsone-pyrimethamine combination 'Maloprim' was abandoned "
    "for haematological toxicity.)\n\n"
    "PRIMAQUINE: primaquine CAN be used as primary prophylaxis in special circumstances (because it "
    "kills the liver stage), but IT IS NOT THE STANDARD CHOICE: it requires a G6PD CHECK BEFORE "
    "STARTING, is contraindicated in pregnancy, and is not recommended as first line.\n\n"
    "A PRACTICAL POINT THAT MUST ALWAYS BE MADE: DRUG PROPHYLAXIS IS NEVER 100% EFFECTIVE. BITE "
    "PREVENTION — an insecticide-treated net, a DEET-containing repellent, long sleeves, and avoiding "
    "the outdoors at dusk and at night — IS THE FIRST LAYER OF PROTECTION and must always be advised "
    "alongside the drug.",
    ["پاسخ صحیح — مفلوکین یکی از سه گزینه‌ی استاندارد در منطقه‌ی مقاوم به کلروکین است.",
     "فقط برای مناطق حساس به کلروکین است، که امروز بسیار محدودند؛ انتخاب امنی نیست.",
     "در پروفیلاکسی مالاریا جایی ندارد؛ داروی جذام و پروفیلاکسی پنوموسیستیس است.",
     "در شرایط خاص ممکن است، ولی نیاز به بررسی G6PD دارد و انتخاب استاندارد نیست."],
    ["Correct — mefloquine is one of the three standard options in a chloroquine-resistant area.",
     "Only for chloroquine-sensitive areas, now very limited; not a safe choice.",
     "Has no place in malaria prophylaxis; it is a drug for leprosy and Pneumocystis prophylaxis.",
     "Possible in special circumstances, but it needs a G6PD check and is not the standard choice."],
    "**پروفیلاکسی را مقاومتِ مقصد تعیین می‌کند، نه ترجیح پزشک.**",
    "Prophylaxis is decided by the destination's resistance, not the doctor's preference.",
    PREFS)

add("book:792", "vignette", "medium",
    "**زن باردار در منطقه‌ی مقاوم: مفلوکین — چون داکسی‌سیکلین و پریماکین هر دو حذف می‌شوند.**",
    "A pregnant woman in a resistant area: MEFLOQUINE — because doxycycline and primaquine are both eliminated.",
    PROP_FA,
    PROP_EN,
    "این سؤال چارچوب قبلی را با **یک قید** ترکیب می‌کند: **بارداری**.\n\n"
    "**موقعیت: خانواده‌ای برای سفر به جنوب کشور و چابهار مشورت می‌کنند. یکی از اعضا خانم "
    "حامله است.**\n\n"
    "**پس دو پرسش:** مقصد مقاوم است یا نه، و کدام دارو در بارداری بی‌خطر است.\n\n"
    "**جنوب شرق ایران، منطقه‌ی مقاوم به کلروکین است** (فالسیپاروم مقاوم در آنجا گزارش شده).\n\n"
    "⚠️ **حالا سه گزینه‌ی منطقه‌ی مقاوم را با فیلتر بارداری بگذرانیم:**\n\n"
    "**داکسی‌سیکلین** — **در بارداری ممنوع**. تتراسایکلین‌ها در جنین **رنگ‌آمیزی دائمی دندان** "
    "و **اختلال رشد استخوان** می‌دهند. (و در کودکان زیر ۸ سال هم ممنوع‌اند.)\n\n"
    "**اتوواکون-پروگوانیل** — **داده‌های ایمنی کافی در بارداری ندارد** و CDC استفاده از آن "
    "را در بارداری توصیه نمی‌کند.\n\n"
    "**مفلوکین** — **باقی می‌ماند، و ایمن است.** مفلوکین **تنها گزینه‌ی توصیه‌شده برای "
    "پروفیلاکسی در بارداری در مناطق مقاوم به کلروکین** است.\n\n"
    "**پس پاسخ: مفلوکین.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**کلروکین:** در بارداری **بی‌خطر است** (این نکته را بدانید)، ولی **در منطقه‌ی مقاوم "
    "مؤثر نیست**. پروفیلاکسی بی‌اثر، بدتر از نداشتن پروفیلاکسی است، چون احساس ایمنی کاذب "
    "می‌دهد و مسافر احتیاط‌های دیگر را رها می‌کند.\n\n"
    "⚠️ **داکسی‌سیکلین:** **در بارداری مطلقاً ممنوع** — رنگ‌آمیزی دندان و اختلال رشد استخوان جنین.\n\n"
    "**پریماکین:** **در بارداری ممنوع** — به‌دلیل خطر همولیز در جنینِ احتمالاً دچار کمبود "
    "G6PD، که وضعیت آن پیش از تولد قابل بررسی نیست.\n\n"
    "**و توصیه‌ی مهمی که همیشه باید داده شود:** **بهترین توصیه به زن باردار، به تعویق انداختن "
    "سفر به منطقه‌ی مالاریاخیز است.** مالاریا در بارداری **بسیار شدیدتر** است (جفت جایگاه "
    "ترجیحی سکستراسیون است) و خطر مرگ مادر و جنین بالاست. اگر سفر اجتناب‌ناپذیر باشد، مفلوکین "
    "به‌علاوه‌ی **حداکثر پیشگیری از گزش** توصیه می‌شود.",
    "This question combines the earlier framework with ONE CONSTRAINT: PREGNANCY.\n\n"
    "THE SITUATION: a family seeking advice before travelling to the south of the country and to "
    "Chabahar. One member is pregnant.\n\n"
    "SO TWO QUESTIONS: is the destination resistant, and which drug is safe in pregnancy?\n\n"
    "SOUTH-EASTERN IRAN IS A CHLOROQUINE-RESISTANT AREA (resistant falciparum has been reported there).\n\n"
    "WARNING, NOW PASS THE THREE RESISTANT-AREA OPTIONS THROUGH THE PREGNANCY FILTER:\n\n"
    "DOXYCYCLINE — CONTRAINDICATED IN PREGNANCY. Tetracyclines cause PERMANENT DENTAL STAINING and "
    "IMPAIRED BONE GROWTH in the fetus. (And they are contraindicated in children under 8 too.)\n\n"
    "ATOVAQUONE-PROGUANIL — LACKS ADEQUATE PREGNANCY SAFETY DATA, and the CDC does not recommend its "
    "use in pregnancy.\n\n"
    "MEFLOQUINE — REMAINS, AND IS SAFE. Mefloquine is THE ONLY RECOMMENDED PROPHYLACTIC OPTION IN "
    "PREGNANCY FOR CHLOROQUINE-RESISTANT AREAS.\n\n"
    "SO THE ANSWER: MEFLOQUINE.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "CHLOROQUINE: it IS SAFE IN PREGNANCY (know this point), but IT IS NOT EFFECTIVE IN A RESISTANT "
    "AREA. Ineffective prophylaxis is worse than none, because it gives false security and the "
    "traveller abandons other precautions.\n\n"
    "WARNING, DOXYCYCLINE: ABSOLUTELY CONTRAINDICATED IN PREGNANCY — dental staining and impaired "
    "fetal bone growth.\n\n"
    "PRIMAQUINE: CONTRAINDICATED IN PREGNANCY — because of the haemolysis risk in a possibly "
    "G6PD-deficient fetus whose status cannot be tested before birth.\n\n"
    "AND AN IMPORTANT PIECE OF ADVICE THAT MUST ALWAYS BE GIVEN: THE BEST ADVICE TO A PREGNANT WOMAN "
    "IS TO POSTPONE TRAVEL TO A MALARIOUS AREA. Malaria in pregnancy is FAR MORE SEVERE (the placenta "
    "is a preferred sequestration site) and the risk of maternal and fetal death is high. If travel is "
    "unavoidable, mefloquine plus MAXIMUM BITE PREVENTION is advised.",
    ["پاسخ صحیح — تنها گزینه‌ی توصیه‌شده برای پروفیلاکسی در بارداری در منطقه‌ی مقاوم.",
     "در بارداری بی‌خطر است ولی در منطقه‌ی مقاوم مؤثر نیست؛ ایمنی کاذب می‌دهد.",
     "در بارداری مطلقاً ممنوع — رنگ‌آمیزی دندان و اختلال رشد استخوان جنین.",
     "در بارداری ممنوع — خطر همولیز در جنینِ احتمالاً دچار کمبود G6PD."],
    ["Correct — the only recommended prophylactic option in pregnancy in a resistant area.",
     "Safe in pregnancy but ineffective in a resistant area; it gives false security.",
     "Absolutely contraindicated in pregnancy — dental staining and impaired fetal bone growth.",
     "Contraindicated in pregnancy — risk of haemolysis in a possibly G6PD-deficient fetus."],
    "**در بارداری و منطقه‌ی مقاوم، مفلوکین تنها گزینه است — بقیه حذف می‌شوند.**",
    "In pregnancy in a resistant area, mefloquine is the only option — the rest are eliminated.",
    PREFS)

add("book:793", "vignette", "easy",
    "**همان قاعده، صریح‌تر: منطقه‌ی مقاوم + بارداری = مفلوکین.**",
    "The same rule, stated more explicitly: resistant area plus pregnancy = MEFLOQUINE.",
    PROP_FA + [
        "**اینجا سؤال خودش گفته منطقه مقاومت بالا به کلروکین دارد.**",
        "**پس دیگر لازم نیست جغرافیا را حدس بزنیم.**",
        "⚠️ **مالارون همان اتوواکون-پروگوانیل است، و در بارداری توصیه نمی‌شود.**",
        "**پس شناختن نام تجاری دارو هم بخشی از پاسخ دادن است.**",
    ],
    PROP_EN + [
        "Here the question itself states that the area has high chloroquine resistance.",
        "So there is no need to guess the geography.",
        "WARNING, MALARONE IS ATOVAQUONE-PROGUANIL, and it is not recommended in pregnancy.",
        "So recognising the drug's brand name is part of answering.",
    ],
    "این سؤال همان قبلی است، ولی کتاب **صریح‌تر** پرسیده — و یک **نام تجاری** را هم امتحان "
    "کرده.\n\n"
    "**موقعیت: خانم حامله‌ی پنج ماهه قصد سفر به منطقه‌ی مالاریاخیز با مقاومت بالا به کلروکین "
    "دارد.**\n\n"
    "**سؤال دو قید را صریحاً داده است: بارداری، و مقاومت بالا به کلروکین.** پس نیازی به حدس "
    "زدن جغرافیا نیست.\n\n"
    "⚠️ **در منطقه‌ی مقاوم، سه گزینه داریم — و فیلتر بارداری دو تای آن‌ها را حذف می‌کند:**\n\n"
    "**داکسی‌سیکلین:** **در بارداری ممنوع** (دندان و استخوان جنین).\n\n"
    "**مالارون (اتوواکون-پروگوانیل):** **در بارداری توصیه نمی‌شود** (داده‌های ایمنی ناکافی).\n\n"
    "**مفلوکین:** **باقی می‌ماند و ایمن است.**\n\n"
    "**پس پاسخ: مفلوکین.**\n\n"
    "**نکته‌ای که این سؤال اضافه می‌کند: شناختن نام تجاری.** «مالارون» نام تجاری "
    "**اتوواکون-پروگوانیل** است. اگر این را ندانید، ممکن است فکر کنید داروی جدیدی است. "
    "**در امتحان‌ها، نام‌های تجاری رایج (مالارون، لاریام برای مفلوکین، کلوکین) گاهی به‌جای "
    "نام ژنریک می‌آیند.**\n\n"
    "**چرا کلروکین رد می‌شود؟** سؤال **صریحاً** گفته منطقه **مقاومت بالا به کلروکین** دارد. "
    "دادن کلروکین یعنی **پروفیلاکسی بی‌اثر** — و بدتر از آن، **احساس ایمنی کاذب** که باعث "
    "می‌شود مسافر پشه‌بند و دافع حشرات را جدی نگیرد.\n\n"
    "⚠️ **و باز هم بگوییم: بهترین توصیه به زن باردار، به تعویق انداختن سفر است.** مالاریا در "
    "بارداری **بسیار شدیدتر** است، چون **جفت جایگاه ترجیحی سکستراسیون گلبول‌های آلوده** است. "
    "اگر سفر حتمی است، **مفلوکین + حداکثر پیشگیری از گزش**.",
    "This question is the previous one, but the book asks it MORE EXPLICITLY — and also tests A BRAND "
    "NAME.\n\n"
    "THE SITUATION: a woman five months pregnant plans to travel to a malarious area with high "
    "chloroquine resistance.\n\n"
    "THE QUESTION STATES BOTH CONSTRAINTS EXPLICITLY: pregnancy, and high chloroquine resistance. So "
    "there is no geography to guess.\n\n"
    "WARNING, IN A RESISTANT AREA WE HAVE THREE OPTIONS — AND THE PREGNANCY FILTER REMOVES TWO:\n\n"
    "DOXYCYCLINE: CONTRAINDICATED IN PREGNANCY (fetal teeth and bone).\n\n"
    "MALARONE (atovaquone-proguanil): NOT RECOMMENDED IN PREGNANCY (inadequate safety data).\n\n"
    "MEFLOQUINE: REMAINS, AND IS SAFE.\n\n"
    "SO THE ANSWER: MEFLOQUINE.\n\n"
    "WHAT THIS QUESTION ADDS: RECOGNISING A BRAND NAME. 'Malarone' is the brand name of "
    "ATOVAQUONE-PROGUANIL. If you do not know that, you might think it is some new drug. IN EXAMS, "
    "COMMON BRAND NAMES (Malarone; Lariam for mefloquine) SOMETIMES APPEAR INSTEAD OF THE GENERIC NAME.\n\n"
    "WHY IS CHLOROQUINE REJECTED? The question states EXPLICITLY that the area has HIGH CHLOROQUINE "
    "RESISTANCE. Giving chloroquine means INEFFECTIVE PROPHYLAXIS — and worse, A FALSE SENSE OF "
    "SECURITY that leads the traveller to take nets and repellents less seriously.\n\n"
    "WARNING, AND TO REPEAT: THE BEST ADVICE TO A PREGNANT WOMAN IS TO POSTPONE THE TRIP. Malaria in "
    "pregnancy is FAR MORE SEVERE, because THE PLACENTA IS A PREFERRED SEQUESTRATION SITE for infected "
    "cells. If travel is unavoidable: MEFLOQUINE PLUS MAXIMUM BITE PREVENTION.",
    ["مالارون همان اتوواکون-پروگوانیل است و در بارداری داده‌های ایمنی کافی ندارد.",
     "پاسخ صحیح — تنها گزینه‌ی ایمن و مؤثر برای بارداری در منطقه‌ی مقاوم به کلروکین.",
     "سؤال صریحاً گفته منطقه مقاومت بالا دارد؛ کلروکین اینجا پروفیلاکسی بی‌اثر است.",
     "در بارداری مطلقاً ممنوع — اثر بر دندان و استخوان جنین."],
    ["Malarone is atovaquone-proguanil and lacks adequate pregnancy safety data.",
     "Correct — the only safe and effective option for pregnancy in a chloroquine-resistant area.",
     "The question states high resistance explicitly; chloroquine here is ineffective prophylaxis.",
     "Absolutely contraindicated in pregnancy — effects on fetal teeth and bone."],
    "**مالارون = اتوواکون-پروگوانیل. و در بارداری، مفلوکین تنها گزینه است.**",
    "Malarone = atovaquone-proguanil. And in pregnancy, mefloquine is the only option.",
    PREFS)

add("book:796", "vignette", "medium",
    "**آفریقای مقاوم + بارداری: باز هم مفلوکین — سومین بار همان قاعده.**",
    "Resistant Africa plus pregnancy: mefloquine again — the same rule for a third time.",
    PROP_FA + [
        "**کتاب این قاعده را سه بار پرسیده، و این تکرار تصادفی نیست.**",
        "**پس آن را به‌صورت یک جمله‌ی قطعی حفظ کنید.**",
        "⚠️ **بارداری + منطقه‌ی مقاوم به کلروکین = مفلوکین.**",
        "**کینین داروی درمانی است، نه پروفیلاکسی.**",
        "**و در بارداری، کینین خطر هیپوگلیسمی شدید دارد.**",
        "**پروگوانیل به‌تنهایی کارایی پروفیلاکسی کافی ندارد.**",
        "**پروگوانیل فقط در ترکیب با اتوواکون به‌کار می‌رود.**",
    ],
    PROP_EN + [
        "The book asks this rule three times, and that repetition is not accidental.",
        "So memorise it as one definite sentence.",
        "WARNING, PREGNANCY PLUS A CHLOROQUINE-RESISTANT AREA = MEFLOQUINE.",
        "Quinine is a treatment drug, not a prophylactic.",
        "And in pregnancy quinine carries a risk of severe hypoglycaemia.",
        "Proguanil alone does not have adequate prophylactic efficacy.",
        "Proguanil is used only in combination with atovaquone.",
    ],
    "کتاب همین قاعده را **سه بار** پرسیده است. این تکرار پیام روشنی دارد: **آن را به‌صورت "
    "یک جمله‌ی قطعی حفظ کنید و در امتحان بی‌درنگ به‌کار ببرید.**\n\n"
    "⚠️ **جمله: بارداری + منطقه‌ی مقاوم به کلروکین = مفلوکین.**\n\n"
    "**موقعیت: خانم باردار، محقق محیط زیست، قصد سفر به منطقه‌ای در آفریقا که مالاریای مقاوم "
    "شایع است.**\n\n"
    "**دو قید صریح: بارداری، و مقاومت.** پاسخ: **مفلوکین**.\n\n"
    "**ولی این سؤال دو گزینه‌ی جدید آورده که ارزش بررسی دارند:**\n\n"
    "**کینین:** این **داروی درمانی** است، نه پروفیلاکسی. کینین برای **درمان** مالاریا "
    "استفاده می‌شود (خط دوم فالسیپاروم) و **هرگز به‌عنوان پروفیلاکسی توصیه نمی‌شود** — عوارض "
    "آن (سینکونیسم: وزوز گوش، سردرد، تاری دید) برای مصرف طولانی پیشگیرانه غیرقابل تحمل است. "
    "⚠️ **و در بارداری، کینین خطر هیپوگلیسمی شدید دارد** که در زن باردار بارزتر است.\n\n"
    "**پروگوانیل:** این دارو **به‌تنهایی کارایی پروفیلاکسی کافی ندارد**. پروگوانیل فقط "
    "**در ترکیب با اتوواکون** (مالارون) استفاده می‌شود، و آن ترکیب هم در بارداری توصیه نمی‌شود. "
    "(در گذشته پروگوانیل + کلروکین در برخی مناطق استفاده می‌شد، ولی این رژیم منسوخ است.)\n\n"
    "**کلروکین:** سؤال گفته منطقه **مقاوم** است، پس بی‌اثر است.\n\n"
    "**و همان توصیه‌ی همیشگی:** **بهترین کار، به تعویق انداختن سفر است.** اگر سفر برای پروژه‌ی "
    "تحقیقاتی اجتناب‌ناپذیر است، **مفلوکین + پیشگیری شدید از گزش**: پشه‌بند آغشته به حشره‌کش، "
    "دافع حاوی DEET (که در بارداری هم بی‌خطر است)، لباس آستین‌بلند، و پرهیز از فضای باز از "
    "غروب تا سحر — چون **آنوفل عمدتاً شب‌گزنده** است.",
    "The book asks this same rule THREE TIMES. That repetition carries a clear message: MEMORISE IT AS "
    "ONE DEFINITE SENTENCE AND APPLY IT INSTANTLY IN THE EXAM.\n\n"
    "WARNING, THE SENTENCE: PREGNANCY PLUS A CHLOROQUINE-RESISTANT AREA = MEFLOQUINE.\n\n"
    "THE SITUATION: a pregnant environmental researcher planning travel to an area of Africa where "
    "resistant malaria is common.\n\n"
    "TWO EXPLICIT CONSTRAINTS: pregnancy, and resistance. The answer: MEFLOQUINE.\n\n"
    "BUT THIS QUESTION BRINGS TWO NEW OPTIONS WORTH EXAMINING:\n\n"
    "QUININE: this is a TREATMENT drug, not a prophylactic. Quinine is used to TREAT malaria "
    "(second-line falciparum) and IS NEVER RECOMMENDED AS PROPHYLAXIS — its side effects (cinchonism: "
    "tinnitus, headache, blurred vision) are intolerable for long preventive use. WARNING, AND IN "
    "PREGNANCY QUININE CARRIES A RISK OF SEVERE HYPOGLYCAEMIA, which is more pronounced in a pregnant "
    "woman.\n\n"
    "PROGUANIL: this drug DOES NOT HAVE ADEQUATE PROPHYLACTIC EFFICACY ALONE. Proguanil is used only "
    "IN COMBINATION WITH ATOVAQUONE (Malarone), and that combination is not recommended in pregnancy "
    "either. (Proguanil plus chloroquine was used in some areas in the past, but that regimen is "
    "obsolete.)\n\n"
    "CHLOROQUINE: the question says the area is RESISTANT, so it is ineffective.\n\n"
    "AND THE USUAL ADVICE: THE BEST COURSE IS TO POSTPONE THE TRIP. If travel for the research project "
    "is unavoidable: MEFLOQUINE PLUS RIGOROUS BITE PREVENTION — an insecticide-treated net, a "
    "DEET-containing repellent (safe in pregnancy), long sleeves, and avoiding the outdoors from dusk "
    "to dawn, because ANOPHELES BITES MAINLY AT NIGHT.",
    ["سؤال گفته منطقه مقاوم است، پس کلروکین اینجا پروفیلاکسی بی‌اثری است.",
     "داروی درمانی است نه پروفیلاکسی، و در بارداری خطر هیپوگلیسمی شدید دارد.",
     "به‌تنهایی کارایی پروفیلاکسی کافی ندارد؛ فقط در ترکیب با اتوواکون استفاده می‌شود.",
     "پاسخ صحیح — تنها گزینه‌ی ایمن و مؤثر برای بارداری در منطقه‌ی مقاوم."],
    ["The question says the area is resistant, so chloroquine is ineffective prophylaxis here.",
     "A treatment drug rather than a prophylactic, and in pregnancy it risks severe hypoglycaemia.",
     "Inadequate prophylactic efficacy alone; it is used only in combination with atovaquone.",
     "Correct — the only safe and effective option for pregnancy in a resistant area."],
    "**کینین درمان است، نه پیشگیری. و پروگوانیل تنها، کافی نیست.**",
    "Quinine is treatment, not prevention. And proguanil alone is not enough.",
    PREFS)

add("book:795", "recall", "hard",
    "**هر سه رژیم درست‌اند — و تفاوت دنباله‌ی آن‌ها منطق دارویی روشنی دارد.**",
    "All three regimens are correct — and the difference in their tails has a clear pharmacological logic.",
    PROP_FA + [
        "**این سؤال هر سه رژیم منطقه‌ی مقاوم را با زمان‌بندی دقیق آورده است.**",
        "**و همه‌ی سه گزینه درست‌اند، پس پاسخ «همه‌ی موارد» است.**",
        "⚠️ **ولی مهم‌تر از پاسخ، فهمیدن تفاوت دنباله‌هاست.**",
        "**اتوواکون-پروگوانیل فقط ۷ روز پس از ترک منطقه ادامه می‌یابد.**",
        "**مفلوکین و داکسی‌سیکلین ۴ هفته ادامه می‌یابند.**",
        "**دلیلش تفاوت در محل اثر داروهاست.**",
        "**اتوواکون-پروگوانیل مرحله‌ی کبدی (پیش‌اریتروسیتی) را هم می‌کشد.**",
        "⚠️ **پس وقتی مسافر منطقه را ترک کرد، انگل کبدی هم از بین رفته است.**",
        "**ولی مفلوکین و داکسی‌سیکلین فقط مرحله‌ی خونی را سرکوب می‌کنند.**",
        "**پس باید آن‌قدر ادامه یابند که هر انگلی که از کبد بیرون می‌آید را بگیرند.**",
        "**و همین چهار هفته را توضیح می‌دهد.**",
    ],
    PROP_EN + [
        "This question presents all three resistant-area regimens with their exact timings.",
        "And all three options are correct, so the answer is 'all of the above'.",
        "WARNING, BUT MORE IMPORTANT THAN THE ANSWER is understanding why the tails differ.",
        "Atovaquone-proguanil continues only 7 days after leaving the area.",
        "Mefloquine and doxycycline continue for 4 weeks.",
        "The reason is a difference in where the drugs act.",
        "Atovaquone-proguanil also kills the hepatic (pre-erythrocytic) stage.",
        "WARNING, SO BY THE TIME THE TRAVELLER LEAVES, the liver parasites are gone too.",
        "But mefloquine and doxycycline only suppress the blood stage.",
        "So they must continue long enough to catch any parasite emerging from the liver.",
        "And that is what explains the four weeks.",
    ],
    "این سخت‌ترین سؤال بلوک پروفیلاکسی است، چون **هر سه گزینه را باید جداگانه راستی‌آزمایی "
    "کنید** — و اگر حتی یکی را اشتباه بدانید، پاسخ را از دست می‌دهید.\n\n"
    "**بیایید هر سه را بررسی کنیم:**\n\n"
    "**گزینه‌ی یک — اتوواکون-پروگوانیل، ۱ تا ۲ روز قبل تا ۷ روز پس از ترک منطقه.** **درست است.**\n\n"
    "**گزینه‌ی دو — مفلوکین، ۱ تا ۲ روز قبل تا ۴ هفته پس از ترک منطقه.** **بازه‌ی پس از سفر "
    "درست است.** (توصیه‌ی شروع مفلوکین معمولاً **۱ تا ۲ هفته** پیش از سفر است تا سطح خونی "
    "کافی برسد و عوارض احتمالی پیش از سفر آشکار شود، ولی نکته‌ی محوری این گزینه — چهار هفته "
    "ادامه پس از ترک منطقه — کاملاً درست است.)\n\n"
    "**گزینه‌ی سه — داکسی‌سیکلین، ۱ تا ۲ روز قبل تا ۴ هفته پس از ترک منطقه.** **درست است.**\n\n"
    "**پس پاسخ: همه‌ی موارد فوق.**\n\n"
    "⚠️ **ولی مهم‌تر از پاسخ، این است که بفهمید چرا دنباله‌ها فرق دارند — و این یک منطق "
    "دارویی زیباست:**\n\n"
    "**اتوواکون-پروگوانیل: فقط ۷ روز پس از سفر.**\n\n"
    "**مفلوکین و داکسی‌سیکلین: ۴ هفته پس از سفر.**\n\n"
    "**چرا؟ به محل اثر داروها نگاه کنید:**\n\n"
    "**اتوواکون-پروگوانیل مرحله‌ی کبدی (پیش‌اریتروسیتی) را هم می‌کشد.** یعنی انگلی که در روزهای "
    "آخر سفر وارد بدن شده و در کبد است، **همان‌جا کشته می‌شود**. پس وقتی مسافر منطقه را ترک "
    "کرد و یک هفته دارو خورد، **دیگر انگلی در کبد نمانده** تا بعداً به خون بریزد.\n\n"
    "⚠️ **مفلوکین و داکسی‌سیکلین فقط مرحله‌ی خونی را سرکوب می‌کنند.** انگل در کبد **زنده "
    "می‌ماند** و ممکن است تا **چهار هفته** بعد از کبد بیرون بیاید و وارد خون شود. پس دارو "
    "باید آن‌قدر ادامه یابد که **هر انگلی که از کبد بیرون می‌آید را در خون بگیرد**.\n\n"
    "**این منطق را یک بار بفهمید و دیگر هیچ‌وقت این اعداد را فراموش نمی‌کنید.**",
    "This is the hardest question in the prophylaxis block, because ALL THREE OPTIONS MUST BE VERIFIED "
    "SEPARATELY — and if you judge even one wrong, you lose the mark.\n\n"
    "LET US CHECK ALL THREE:\n\n"
    "OPTION ONE — atovaquone-proguanil, 1 to 2 days before until 7 days after leaving. CORRECT.\n\n"
    "OPTION TWO — mefloquine, 1 to 2 days before until 4 weeks after leaving. THE POST-TRAVEL INTERVAL "
    "IS CORRECT. (The usual advice is to start mefloquine 1 to 2 WEEKS before travel so that adequate "
    "blood levels are reached and any side effects appear before departure; but the central point of "
    "this option — continuing four weeks after leaving — is entirely correct.)\n\n"
    "OPTION THREE — doxycycline, 1 to 2 days before until 4 weeks after leaving. CORRECT.\n\n"
    "SO THE ANSWER: ALL OF THE ABOVE.\n\n"
    "WARNING, BUT MORE IMPORTANT THAN THE ANSWER IS UNDERSTANDING WHY THE TAILS DIFFER — and it is a "
    "beautiful piece of pharmacological logic:\n\n"
    "ATOVAQUONE-PROGUANIL: only 7 days after travel.\n\n"
    "MEFLOQUINE AND DOXYCYCLINE: 4 weeks after travel.\n\n"
    "WHY? LOOK AT WHERE THE DRUGS ACT:\n\n"
    "ATOVAQUONE-PROGUANIL ALSO KILLS THE HEPATIC (PRE-ERYTHROCYTIC) STAGE. So a parasite acquired in "
    "the last days of the trip and sitting in the liver IS KILLED THERE. By the time the traveller has "
    "left and taken a week of the drug, NO PARASITE REMAINS IN THE LIVER to emerge later.\n\n"
    "WARNING, MEFLOQUINE AND DOXYCYCLINE ONLY SUPPRESS THE BLOOD STAGE. The parasite SURVIVES IN THE "
    "LIVER and may emerge into the blood up to FOUR WEEKS later. So the drug must continue long enough "
    "to CATCH IN THE BLOOD ANY PARASITE THAT EMERGES FROM THE LIVER.\n\n"
    "UNDERSTAND THAT LOGIC ONCE AND YOU WILL NEVER FORGET THESE NUMBERS.",
    ["درست است — دنباله‌ی هفت‌روزه چون این ترکیب مرحله‌ی کبدی را هم می‌کشد.",
     "بازه‌ی چهارهفته‌ای پس از سفر درست است؛ شروع مفلوکین معمولاً ۱ تا ۲ هفته قبل توصیه می‌شود.",
     "درست است — داکسی‌سیکلین فقط مرحله‌ی خونی را سرکوب می‌کند، پس چهار هفته ادامه می‌یابد.",
     "پاسخ صحیح — هر سه رژیم استاندارد منطقه‌ی مقاوم به کلروکین‌اند."],
    ["Correct — a seven-day tail because this combination also kills the hepatic stage.",
     "The four-week post-travel interval is correct; mefloquine is usually started 1 to 2 weeks before.",
     "Correct — doxycycline only suppresses the blood stage, so it continues for four weeks.",
     "Correct — all three are standard regimens for a chloroquine-resistant area."],
    "**دنباله‌ی کوتاه = کبد را هم می‌کشد. دنباله‌ی بلند = فقط خون را سرکوب می‌کند.**",
    "A short tail means it kills the liver stage too. A long tail means it only suppresses the blood.",
    PREFS)

add("book:797", "recall", "easy",
    "**واکسیناسیون برای پیشگیری از مالاریا در مسافر وجود ندارد.**",
    "There is no vaccination for malaria prevention in a traveller.",
    PROP_FA,
    PROP_EN,
    "این سؤال یک نکته‌ی ساده ولی مهم را می‌سنجد که دانشجویان گاهی در آن تردید می‌کنند.\n\n"
    "**سه گزینه‌ای که روش‌های معتبر پیشگیری‌اند:**\n\n"
    "**داکسی‌سیکلین در طول سفر به مناطق اندمیک** — یکی از سه رژیم استاندارد پروفیلاکسی در "
    "منطقه‌ی مقاوم به کلروکین. روزانه، از ۱ تا ۲ روز پیش از سفر تا ۴ هفته پس از ترک منطقه.\n\n"
    "**پماد دافع حشرات** — این **لایه‌ی اول محافظت** است و هرگز نباید دست‌کم گرفته شود. "
    "دافع حاوی **DEET** استاندارد است و در بارداری هم بی‌خطر. ⚠️ **پروفیلاکسی دارویی هرگز صد "
    "درصد نیست، پس پیشگیری از گزش همیشه لازم است.**\n\n"
    "**«ملوکین» (مفلوکین)** — همان رژیم هفتگی استاندارد در منطقه‌ی مقاوم است.\n\n"
    "**و گزینه‌ی چهارم: واکسیناسیون یک ماه قبل از سفر — که استفاده نمی‌شود.**\n\n"
    "⚠️ **چرا؟ هیچ واکسن مالاریایی برای مسافر وجود ندارد.**\n\n"
    "**ولی اینجا یک نکته‌ی به‌روز مهم است که باید بدانید:** دو واکسن مالاریا امروز وجود دارند "
    "و توسط WHO توصیه شده‌اند: **RTS,S/AS01 (موسکیریکس)** و **R21/Matrix-M**. **پس چرا پاسخ "
    "همچنان «واکسیناسیون استفاده نمی‌شود» است؟**\n\n"
    "**چون این واکسن‌ها برای موقعیت کاملاً متفاوتی طراحی شده‌اند:**\n\n"
    "**برای کودکان** ساکن مناطق **پرانتقال آفریقایی**، به‌عنوان بخشی از برنامه‌ی بهداشت عمومی، "
    "با هدف **کاهش مرگ‌ومیر کودکان**.\n\n"
    "**نه برای مسافر بالغ.** کارایی آن‌ها **جزئی** است (حدود ۳۰ تا ۷۵ درصد بسته به رژیم و "
    "شرایط)، **چند دوز در طول ماه‌ها** لازم دارند، و **جایگزین پروفیلاکسی دارویی نمی‌شوند**.\n\n"
    "**پس برای مسافر، پیشگیری همچنان دو لایه دارد: دارو + پیشگیری از گزش.** و «واکسیناسیون "
    "یک ماه قبل از سفر» هیچ جایگاهی ندارد.",
    "This question tests a simple but important point that students sometimes hesitate over.\n\n"
    "THE THREE OPTIONS THAT ARE GENUINE PREVENTIVE METHODS:\n\n"
    "DOXYCYCLINE DURING TRAVEL TO ENDEMIC AREAS — one of the three standard prophylactic regimens in a "
    "chloroquine-resistant area. Daily, from 1 to 2 days before travel until 4 weeks after leaving.\n\n"
    "INSECT REPELLENT — this is THE FIRST LAYER OF PROTECTION and must never be underrated. A "
    "DEET-containing repellent is standard and is safe in pregnancy too. WARNING, DRUG PROPHYLAXIS IS "
    "NEVER 100% EFFECTIVE, SO BITE PREVENTION IS ALWAYS NECESSARY.\n\n"
    "MEFLOQUINE — the standard weekly regimen in a resistant area.\n\n"
    "AND THE FOURTH OPTION: VACCINATION ONE MONTH BEFORE TRAVEL — which is not used.\n\n"
    "WARNING, WHY? THERE IS NO MALARIA VACCINE FOR TRAVELLERS.\n\n"
    "BUT THERE IS AN IMPORTANT UP-TO-DATE POINT TO KNOW HERE: two malaria vaccines now exist and are "
    "recommended by WHO: RTS,S/AS01 (Mosquirix) and R21/Matrix-M. SO WHY IS THE ANSWER STILL "
    "'VACCINATION IS NOT USED'?\n\n"
    "BECAUSE THOSE VACCINES ARE DESIGNED FOR AN ENTIRELY DIFFERENT SITUATION:\n\n"
    "FOR CHILDREN living in HIGH-TRANSMISSION AFRICAN settings, as part of a public health programme, "
    "aimed at REDUCING CHILDHOOD MORTALITY.\n\n"
    "NOT FOR THE ADULT TRAVELLER. Their efficacy is PARTIAL (roughly 30 to 75% depending on the "
    "schedule and setting), they require MULTIPLE DOSES OVER MONTHS, and they DO NOT REPLACE DRUG "
    "PROPHYLAXIS.\n\n"
    "SO FOR A TRAVELLER, PREVENTION STILL HAS TWO LAYERS: DRUGS PLUS BITE PREVENTION. And 'vaccination "
    "one month before travel' has no place at all.",
    ["یکی از سه رژیم استاندارد پروفیلاکسی در منطقه‌ی مقاوم به کلروکین است.",
     "لایه‌ی اول محافظت است؛ دافع حاوی DEET استاندارد و در بارداری هم بی‌خطر است.",
     "پاسخ صحیح — واکسن مالاریا برای مسافر وجود ندارد؛ واکسن‌های موجود برای کودکان آفریقایی‌اند.",
     "مفلوکین رژیم هفتگی استاندارد در منطقه‌ی مقاوم به کلروکین است."],
    ["One of the three standard prophylactic regimens in a chloroquine-resistant area.",
     "The first layer of protection; a DEET repellent is standard and safe in pregnancy.",
     "Correct — there is no malaria vaccine for travellers; the existing vaccines are for African children.",
     "Mefloquine is the standard weekly regimen in a chloroquine-resistant area."],
    "**واکسن‌های مالاریا وجود دارند — ولی برای کودک آفریقایی، نه برای مسافر.**",
    "Malaria vaccines do exist — but for African children, not for travellers.",
    PREFS)

json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book44.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 44 lessons:', len(L))
