# -*- coding: utf-8 -*-
"""Turn the extracted book questions into an import payload.

Design decisions
----------------
* The book's own 36 chapters are mapped onto the 13 teaching chapters the
  infectious bank already uses, so the new items land in the SAME lessons the
  student already has rather than creating a parallel structure.

* Every answer here is the OFFICIAL printed key, so key_source is 'official
  book key' — a meaningful upgrade over the 86 Harrison-derived answers in the
  existing bank.

* These questions ship WITHOUT a hand-written micro-lesson. Writing 865 of
  those to the standard of the existing bank is not something to fake, so the
  payload carries the stem, options, official answer and provenance, and the
  learner-facing explanation is left empty rather than auto-generated. The
  admin can author them over time; the import path already tolerates it.
  They are marked `needs_lesson: true` so they are easy to find later.

* Anything that overlaps an existing bank question is dropped, so the student
  never meets the same stem twice.
"""
import json, io, os, re, sys, collections

HERE = os.path.dirname(os.path.abspath(__file__))
BANK = '/home/user/work/infectious/import-payload.json'

SUBJECT_FA, SUBJECT_EN = 'بیماری‌های عفونی', 'Infectious Diseases'
SUBJECT_TRACK = 'minor'

CHAPTERS = {
    'cns-infection':   ('عفونت‌های سیستم عصبی مرکزی', 'CNS Infections'),
    'respiratory':     ('عفونت‌های دستگاه تنفسی', 'Respiratory Tract Infections'),
    'gi-infection':    ('عفونت‌های گوارشی و اسهال', 'Gastrointestinal Infections and Diarrhoea'),
    'skin-soft':       ('عفونت‌های پوست، بافت نرم و گازگرفتگی', 'Skin, Soft Tissue and Bite Infections'),
    'bone-joint':      ('عفونت‌های استخوان و مفصل', 'Bone and Joint Infections'),
    'tuberculosis':    ('سل', 'Tuberculosis'),
    'parasitic':       ('بیماری‌های انگلی و مالاریا', 'Parasitic Diseases and Malaria'),
    'toxin-mediated':  ('بیماری‌های توکسینی و کزاز', 'Toxin-Mediated Diseases and Tetanus'),
    'sepsis-febrile':  ('سپسیس و رویکرد به بیمار تب‌دار', 'Sepsis and the Febrile Patient'),
    'sti-viral':       ('عفونت‌های ویروسی و منتقله از راه جنسی', 'Viral and Sexually Transmitted Infections'),
    'endocarditis':    ('اندوکاردیت و عفونت‌های داخل عروقی', 'Endocarditis and Intravascular Infections'),
    'uti':             ('عفونت‌های ادراری', 'Urinary Tract Infections'),
    'zoonoses':        ('زئونوزها و بیماری‌های منتقله از حیوان', 'Zoonoses and Animal-Borne Diseases'),
}

# The book prints chapter titles with stray intra-word spaces, so match on the
# de-spaced form. Keys are de-spaced book headings.
BOOK_TO_SLUG = {
    'سل': 'tuberculosis',
    'مننژیتونسفلیت': 'cns-infection',
    'یدز': 'sti-viral',
    'بروسلوز': 'zoonoses',
    'ندوکردیت': 'endocarditis',
    'ملری': 'parasitic',
    'کزز،دیفتریوسیهسرفه': 'toxin-mediated',
    'عفونتهیمنتقلهیآمیزشیSTI': 'sti-viral',
    'عفونتمجریدرری': 'uti',
    'عفونتپوست،عضلهوبفتنرم': 'skin-soft',
    'آنفولنز': 'respiratory',
    'عفونتهیپنوموکوکیوپنومونی': 'respiratory',
    'ویروسوریسلزوستر': 'sti-viral',
    'سهلومسمومیت': 'gi-infection',
    'هری': 'zoonoses',
    'نمتودهیرودهی': 'parasitic',
    'وب': 'gi-infection',
    'عفونتهیسترپتوکوکی': 'skin-soft',
    'تکیخته': 'parasitic',
    'عفونتهیستفیلوکوکی': 'skin-soft',
    'سپسیس': 'sepsis-febrile',
    'عفونتهیقری': 'sepsis-febrile',
    'سلمونلوز': 'gi-infection',
    'کلستریدیومدیفیسیل': 'gi-infection',
    'لپتوسپیروز': 'zoonoses',
    'توکسوپلسموزیس': 'parasitic',
    'سرخکوسرخجه': 'sti-viral',
    'بوتولیسم': 'toxin-mediated',
    'هپتیت': 'sti-viral',
    'تبوتببدونمنشأFUO': 'sepsis-febrile',
    'شیگلوز': 'gi-infection',
    'ویروسپشتینبرEBV': 'sti-viral',
    'ویروسهرپس': 'sti-viral',
    'عفونتهیتنفسیویروسیشیع': 'respiratory',
    'سستودوترمتود': 'parasitic',
    'لیستری': 'cns-infection',
}

POLE_EN = {
    'تهران': 'Tehran', 'شیراز': 'Shiraz', 'مشهد': 'Mashhad', 'اصفهان': 'Isfahan',
    'تبریز': 'Tabriz', 'اهواز': 'Ahvaz', 'کرمان': 'Kerman', 'کرمانشاه': 'Kermanshah',
    'زنجان': 'Zanjan', 'شمال': 'North', 'آزاد': 'Azad', 'کشوری': 'National',
    'مشترک': 'Joint', 'یزد': 'Yazd', 'همدان': 'Hamadan', 'ساری': 'Sari',
    'گیلان': 'Gilan', 'اروميه': 'Urmia', 'ارومیه': 'Urmia', 'بندرعباس': 'Bandar Abbas',
}

MONTH_EN = {'فروردین': 'Farvardin', 'اردیبهشت': 'Ordibehesht', 'خرداد': 'Khordad',
            'تیر': 'Tir', 'مرداد': 'Mordad', 'شهریور': 'Shahrivar', 'مهر': 'Mehr',
            'آبان': 'Aban', 'آذر': 'Azar', 'دی': 'Dey', 'بهمن': 'Bahman', 'اسفند': 'Esfand'}
FA_DIG = str.maketrans('0123456789', '۰۱۲۳۴۵۶۷۸۹')
DIG = str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', '01234567890123456789')


def despace(s):
    """Normalise a book heading to a stable lookup key.

    Two exporter quirks have to be folded out first:
      * the lam-alef ligature is emitted as "ال", so مالاریا arrives as ماالریا
        and واریسلا as واریسال. Collapsing any "الا"/"ال" run that follows a
        letter is unsafe in general, so we simply strip ALL alef/lam ordering
        by removing the ligature's stray alef where it doubles.
      * parentheses come out mirrored, ")STI(" instead of "(STI)".
    Rather than model either quirk, we drop every non-letter and both of the
    ambiguous letters from the key. What remains is still unique across the
    book's 36 headings, which is all a lookup key needs to be.
    """
    s = re.sub(r'[^\u0600-\u06FFA-Za-z]', '', s or '')
    return s.replace('ا', '').replace('\u200c', '')


def norm(s):
    s = (s or '').translate(DIG).replace('\u200c', '').replace('ي', 'ی').replace('ك', 'ک')
    s = re.sub(r'[^\w\s]', ' ', s)
    return re.sub(r'\s+', ' ', s).strip()


def tri(s):
    return {s[i:i + 3] for i in range(len(s) - 2)}


def fingerprint(stem):
    txt = re.sub(r'[۰-۹0-9]', '#', stem)
    txt = re.sub(r'[^\w\s#]', ' ', txt)
    txt = re.sub(r'\s+', ' ', txt).strip()
    return f'{SUBJECT_FA} {SUBJECT_EN} {txt}'[:400]


def main():
    book = json.load(io.open(os.path.join(HERE, 'out', 'book_raw.json'), encoding='utf-8'))
    bank = json.load(io.open(BANK, encoding='utf-8'))['questions']

    # ---- drop anything already in the bank
    bank_tri = [tri(norm(q['question_fa'])) for q in bank]
    kept, dropped_dup = [], 0
    seen = []
    for q in book:
        t = tri(norm(q['stem_fa']))
        if not t:
            continue
        if any(b and len(t & b) / min(len(t), len(b)) >= 0.75 for b in bank_tri):
            dropped_dup += 1
            continue
        # also dedupe inside the book itself
        if any(len(t & s) / min(len(t), len(s)) >= 0.85 for s in seen):
            dropped_dup += 1
            continue
        seen.append(t)
        kept.append(q)

    unmapped = collections.Counter()
    payload = []
    per_chapter = collections.Counter()
    for q in kept:
        slug = BOOK_TO_SLUG.get(despace(q['book_chapter']))
        if not slug:
            unmapped[q['book_chapter']] += 1
            continue
        chap_fa, chap_en = CHAPTERS[slug]
        per_chapter[chap_fa] += 1
        # Match the neurology bank's convention so the year filter shows one
        # entry per sitting instead of splitting ۱۳۹۸ from ۹۸: pre-1400 years
        # are written with two digits, 1400+ in full.
        yr = q['year']
        month = q['month']
        year = str(yr if yr >= 1400 else yr - 1300).translate(FA_DIG)
        # Human-readable sitting label, matching the neurology bank exactly so
        # the two subjects share one "exam" filter instead of two shapes.
        # A question reused across sittings lists several poles run together
        # ("مشهدوشهریور"). Split on the connectors so each name can be
        # translated and the poles[] facet is meaningful.
        pole_raw = q.get('pole', '') or ''
        parts = [x for x in re.split(r'[،,]|\bو\b|و(?=[\u0600-\u06FF])', pole_raw) if x.strip()]
        parts = [x.strip() for x in parts if x.strip() in POLE_EN] or (
            [pole_raw] if pole_raw else [])
        pole = parts[0] if parts else ''
        scope = 'کشوری' if pole in ('', 'کشوری') else 'قطبی'
        men = MONTH_EN.get(month, month)
        if scope == 'کشوری':
            label_fa = f'پره‌انترنی {month} {year} — کشوری'
            label_en = f'Pre-internship {men} {q["year"]} — National'
        else:
            label_fa = f'پره‌انترنی {month} {year} — قطب ' + '، '.join(parts)
            pen = ', '.join(POLE_EN.get(x, x) for x in parts) or POLE_EN.get(pole, pole)
            label_en = f'Pre-internship {men} {q["year"]} — {pen}'
        payload.append({
            'question_no': 9000 + len(payload),   # book items get their own range
            'chapter_fa': chap_fa, 'chapter_en': chap_en,
            'question_fa': q['stem_fa'],
            'question_en': '',
            'options_fa': q['options_fa'],
            'options_en': [],
            'options_why_fa': [], 'options_why_en': [],
            'correct_index': q['correct_index'],
            'explanation_fa': '', 'explanation_en': '',
            'year': year, 'month': month, 'month_en': MONTH_EN.get(month, ''),
            'year_num': q['year'],
            'sitting': 'main' if month in ('شهریور', 'اسفند') else 'midterm',
            'pole': pole,
            'poles': [x for x in parts if x != 'کشوری'],
            'scope': scope, 'scope_en': 'National' if scope == 'کشوری' else 'Regional',
            'exam_type': 'پره‌انترنی',
            'label_fa': label_fa, 'label_en': label_en,
            'question_style': 'case' if 'ساله' in q['stem_fa'] else 'recall',
            'difficulty': 'medium',
            'concept': slug,
            'concept_fa': chap_fa, 'concept_en': chap_en,
            'key_source': 'official_book_key',
            'source': 'تست تمرینی بیماری‌های عفونی — امیرحسین بهرامیان، ویرایش دوم',
            'needs_lesson': True,
            'fingerprint': fingerprint(q['stem_fa']),
            'license': 'public_past_exam_review_required',
        })

    # lesson parts, 8 per lesson, within each chapter
    counts = collections.Counter()
    for it in payload:
        n = counts[it['chapter_fa']]
        counts[it['chapter_fa']] = n + 1
        it['lesson_part'] = (n // 8) + 1

    body = {
        'program': 'preint',
        'subject_fa': SUBJECT_FA, 'subject_en': SUBJECT_EN,
        'subject_track': SUBJECT_TRACK,
        'exam_type': 'پره‌انترنی',
        'maxPerLesson': 8,
        'source': 'تست تمرینی بیماری‌های عفونی (ویرایش دوم، خرداد ۹۹)',
        'questions': payload,
    }
    dest = os.path.join(HERE, 'import-payload.json')
    json.dump(body, io.open(dest, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    size = os.path.getsize(dest) / 1024 / 1024
    print(f'book: {len(book)}  dropped as duplicate: {dropped_dup}  payload: {len(payload)}')
    if unmapped:
        print('UNMAPPED chapters: ' + ', '.join(f'{k}={v}' for k, v in unmapped.most_common()))
    print('chapters: ' + ', '.join(f'{k}={v}' for k, v in per_chapter.most_common()))
    print(f'-> {dest} ({size:.2f} MB)')


if __name__ == '__main__':
    main()
