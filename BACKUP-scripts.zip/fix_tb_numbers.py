# -*- coding: utf-8 -*-
"""Repair the mirrored numbers of the tuberculosis chapter.

Same method as the three previous chapters: pdfplumber gives each glyph's
x-coordinate, and a number is drawn left to right even inside right-to-left
script, so sorting a line's digits by x0 recovers the printed value.

Why this chapter's numbers matter more than most
------------------------------------------------
Tuberculosis is the one chapter where a MILLIMETRE decides the management. The
whole latent-TB block turns on PPD thresholds:

    >= 5 mm   positive in HIV, recent contacts, transplant recipients,
              patients on TNF inhibitors, fibrotic changes on chest film
    >= 10 mm  positive in dialysis, diabetes, silicosis, prisoners, health
              workers, injecting drug users, recent immigrants, children <4
    >= 15 mm  positive in a person with NO risk factor

A mirrored PPD does not merely look odd — it moves the patient across a
threshold and inverts the answer. q9266 is exactly that case: stored as 71 mm
(a physically impossible induration) where the page prints 17. And 17 mm in a
healthy bank employee with no risk factor sits BELOW the 15 mm line... no,
ABOVE it — which is precisely why the printed key ("no treatment needed, just
follow up") deserved a second look. It survived: see the note below.

The repairs, each confirmed against the page glyphs:

  q9266  "توبرکولین mm71"  -> 17 mm   (p103 x-order: 1 7)
         The ESR on the same line already read 12 and is left alone.
  q9267  "مانتو (PPD) mm21" -> 12 mm   (p103 x-order: 1 2)
  q9225  "کاهش وزن Kg01"    -> 10 kg   (p88 x-order: 1 0)
  q9217  "درجه حرارت 37.8"  already correct (p85 prints 3 7 8); NOT changed
  q9253  "پلاکت 23000"      already correct (p98 prints 2 3 0 0 0); NOT changed
  q9263  "PPD mm15"         already correct (p102 prints 1 5); NOT changed

A note on q9266, which was nearly "corrected" wrongly
-----------------------------------------------------
With the PPD read as 17 mm the induration is positive by the 15 mm rule, and it
is tempting to conclude the printed key is wrong. It is not. The 15 mm rule
makes the TEST positive; it does not by itself make TREATMENT mandatory. The
Iranian national programme and the classical teaching both reserve
chemoprophylaxis in a person with NO risk factor for specific situations —
recent conversion above all — and a single positive reading at a pre-employment
screen in a 24-year-old with a normal examination and no risk factor is
followed, not treated. The key stands, and the lesson explains exactly this,
because a student who has just learned "15 mm is positive" will otherwise
conclude the book is wrong.
"""
import json, io, os, collections

import pdfplumber

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = '/home/user/uploads/بیماری عفونی.pdf'

FIXES = {
    9266: [
        (103, 'توبرکولین mm71', 'توبرکولین mm17', '17',
         'PPD: صفحه ۱۰۳ رقم‌ها را ۱۷ چاپ کرده است؛ اندوراسیون ۷۱ میلی‌متر از نظر فیزیکی '
         'ممکن نیست.'),
        # The ESR on the same line was CONSIDERED and found already correct:
        # the stored text reads "mm12=ESR" and page 103 prints 1 2 in that
        # order, so nothing is mirrored there. Recorded rather than silently
        # dropped, because a reader comparing this file to the page will see
        # two numbers on that line and should know both were checked.
    ],
    9267: [
        (103, 'mm21', 'mm12', '12',
         'PPD: صفحه ۱۰۳ رقم‌ها را ۱۲ چاپ کرده است.'),
    ],
    9225: [
        (88, 'Kg01', 'Kg10', '10',
         'کاهش وزن: صفحه ۸۸ رقم‌ها را ۱۰ چاپ کرده است.'),
    ],
}


def page_digit_runs(pdf, pno):
    page = pdf.pages[pno - 1]
    rows = collections.defaultdict(list)
    for c in page.chars:
        rows[round(c['top'])].append(c)
    runs = []
    for top in sorted(rows):
        cs = sorted(rows[top], key=lambda c: c['x0'])
        cur = ''
        for c in cs:
            t = c['text']
            if t.isspace() and cur:
                continue
            if t.isdigit() or (cur and t in './'):
                cur += t
            else:
                if cur:
                    runs.append(cur.strip('./'))
                cur = ''
        if cur:
            runs.append(cur.strip('./'))
    return runs


def main():
    pages = {p for specs in FIXES.values() for (p, *_r) in specs}
    with pdfplumber.open(SRC) as pdf:
        printed = {p: page_digit_runs(pdf, p) for p in pages}

    applied, missing = [], []
    for i in range(1, 6):
        path = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        body = json.load(io.open(path, encoding='utf-8'))
        dirty = False
        for q in body['questions']:
            specs = FIXES.get(q['question_no'])
            if not specs:
                continue
            for pno, old, new, expect, why in specs:
                assert any(expect in run for run in printed[pno]), \
                    f'q{q["question_no"]}: page {pno} does not print {expect}'
                hit = False
                if old in q['question_fa']:
                    q.setdefault('stem_original_fa', q['question_fa'])
                    q['question_fa'] = q['question_fa'].replace(old, new)
                    q.setdefault('stem_number_corrections', []).append({
                        'from': old, 'to': new, 'page': pno, 'where': 'stem',
                        'method': 'glyph geometry (pdfplumber x-order)',
                        'why_fa': why})
                    applied.append(f'q{q["question_no"]}: {old} -> {new} (stem)')
                    hit = True
                    dirty = True
                for oi, opt in enumerate(q['options_fa']):
                    if old in opt:
                        q.setdefault('options_original_fa', list(q['options_fa']))
                        q['options_fa'][oi] = opt.replace(old, new)
                        q.setdefault('stem_number_corrections', []).append({
                            'from': old, 'to': new, 'page': pno,
                            'where': f'option {oi + 1}',
                            'method': 'glyph geometry (pdfplumber x-order)',
                            'why_fa': why})
                        applied.append(f'q{q["question_no"]}: {old} -> {new} (option {oi + 1})')
                        hit = True
                        dirty = True
                if not hit:
                    missing.append(f'q{q["question_no"]}: {old!r} not found')
        if dirty:
            json.dump(body, io.open(path, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)

    for a in applied:
        print('fixed  ', a)
    for m in missing:
        print('MISSING', m)
    print(f'\n{len(applied)} corrections written, {len(missing)} not found')


if __name__ == '__main__':
    main()
