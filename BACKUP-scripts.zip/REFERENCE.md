# منبع رسمی درس بیماری‌های عفونی — آزمون پیش‌کارورزی ۱۴۰۵

منبع: دبیرخانه شورای آموزش پزشکی عمومی، «منابع آزمون‌های پیش‌کارورزی از ابتدای
اسفند ۱۴۰۴ تا پایان بهمن ۱۴۰۵» (استخراج‌شده از فایل رسمی).

## کتاب مرجع
**Loscalzo J. Harrison's Principles of Internal Medicine. 21st edition. McGraw Hill, 2022**

فقط فصول منتخب زیر (۳۵ فصل):

| # | فصل | # | فصل |
|---|---|---|---|
| 119 | Approach to the Patient with an Infectious Disease | 168 | Cholera and Other Vibrioses |
| 122 | Approach to the Acutely Ill Infected Febrile Patient | 169 | Brucellosis |
| 126 | Pneumonia | 178 | Tuberculosis |
| 127 | Lung Abscess | 184 | Leptospirosis |
| 128 | Infective Endocarditis | 192 | Herpes Simplex Virus Infection |
| 129 | Infections of the Skin, Muscles, and Soft Tissues | 193 | Varicella-Zoster Virus Infections |
| 130 | Infectious Arthritis | 194 | EBV Infections, Including Infectious Mononucleosis |
| 133 | Acute Infectious Diarrheal Disease and Bacterial Food Poisoning | 199 | Common Viral Respiratory Infections, Including COVID-19 |
| 134 | Clostridioides difficile Infection, Including Pseudomembranous Colitis | 200 | Influenza |
| 135 | Urinary Tract Infections, Pyelonephritis, and Prostatitis | 203 | Viral Gastroenteritis |
| 136 | Sexually Transmitted Infections: Overview and Clinical Approach | 205 | Measles (Rubeola) |
| 138 | Acute Meningitis | 216 | Candidiasis |
| 141 | Infectious Complications of Bites | 217 | Aspergillosis |
| 146 | Pneumococcal Infections | 218 | Mucormycosis |
| 147 | Staphylococcal Infections | 223 | Amebiasis and Infection with Free-Living Amebae |
| 148 | Streptococcal Infections | 224 | Malaria |
| 150 | Diphtheria and Other Corynebacterial Infections | 228 | Toxoplasma Infections |
| 152 | Tetanus | 232 | Intestinal Nematode Infections |
| 153 | Botulism | 235 | Cestode Infections |
| 155 | Meningococcal Infections | 304 | Sepsis and Septic Shock |
| 166 | Shigellosis | | |

## سه مصوبه‌ی ملی (منابع الزامی جداگانه)
1. **درمان سل** — مصوبه ۱۴۰۳ کمیته کشوری سل
2. **مدیریت عفونت سل نهفته** — مصوبه ۱۴۰۳ کمیته کشوری سل
3. **الگوریتم‌های تشخیص سل ریوی در یک نگاه** — مصوبه ۱۴۰۳ کمیته کشوری سل

قابل دانلود از: https://scume.behdasht.gov.ir/

## قاعده‌ی استناد در درسنامه‌ها
- استناد اصلی: `Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. N: <عنوان>`
- برای سل: افزودن مصوبه‌ی کمیته کشوری سل ۱۴۰۳ در کنار هریسون
- منابع تکمیلی (گایدلاین‌های IDSA/WHO) فقط به‌عنوان مرجع دوم
