# -*- coding: utf-8 -*-
"""Micro-lessons, batch 21 — leptospirosis, from the rice fields of the north.

Fifteen of the eighty-one zoonoses questions are leptospirosis, and almost every
one of them opens the same way: a RICE FARMER OR A FARM WORKER FROM NORTHERN
IRAN with fever and myalgia. The examiners are testing whether a student can
recognise a disease that is common in Gilan and Mazandaran and essentially
absent from the textbooks written elsewhere.

The four things that make leptospirosis recognisable
----------------------------------------------------
1. THE EXPOSURE. Fresh water contaminated with rodent urine: rice paddies,
   flooded ground, canoeing and swimming, sewer work, abattoirs.

2. CONJUNCTIVAL SUFFUSION. Redness of the conjunctiva WITHOUT purulent
   discharge. It is present in a large minority of cases, it is easy to see,
   and almost nothing else in the differential produces it. When a question
   mentions it, it is not decoration — it is the answer.

3. SEVERE CALF MYALGIA, often with a raised creatine kinase. Fever plus
   markedly tender calves plus a high CPK is a very short differential.

4. THE BIPHASIC COURSE. A septicaemic phase of about a week, then a few days
   of feeling better, then an immune phase which is where jaundice, renal
   failure and meningitis appear. Several questions in this chapter describe
   exactly that gap and expect the student to recognise it.

Weil's disease and the one laboratory pattern worth memorising
--------------------------------------------------------------
Severe leptospirosis is a TRIAD: JAUNDICE, RENAL FAILURE and BLEEDING
(classically pulmonary haemorrhage). Encephalitis is not part of the triad,
though aseptic meningitis is common.

And the laboratory signature that separates it from hepatitis: the bilirubin is
strikingly high while the transaminases are only modestly raised. In acute
viral hepatitis the transaminases run into the thousands; in leptospirosis they
rarely exceed a few hundred. A student who knows that one pattern answers three
questions in this chapter.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022), Ch. 182
(Leptospirosis); WHO — Human Leptospirosis: Guidance for Diagnosis,
Surveillance and Control (2003); Iranian national leptospirosis guideline.
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 182: Leptospirosis"
WHO = "WHO — Human Leptospirosis: Guidance for Diagnosis, Surveillance and Control (2003)"
IR = "دستورالعمل کشوری مراقبت از لپتوسپیروز، وزارت بهداشت، درمان و آموزش پزشکی"

CORE_FA = [
    "**لپتوسپیرا یک اسپیروکت مارپیچی و باریک است** با انتهای قلاب‌مانند.",
    "⚠️ **مخزن اصلی جوندگان‌اند** و ویروس… ببخشید، **باکتری از راه ادرار آن‌ها دفع می‌شود**.",
    "**انسان چگونه مبتلا می‌شود؟** تماس **پوست خراشیده یا مخاط** با **آب یا خاک آلوده به ادرار جونده**.",
    "⚠️ **گروه‌های پرخطر در ایران: شالیکاران گیلان و مازندران** — و همین «شالیکار» کلیدواژه‌ی امتحان است.",
    "همچنین: کارگر فاضلاب، دامدار، کارگر کشتارگاه، شناگر و قایق‌سوار در آب شیرین، و سیل‌زدگان.",
    "**سه یافته‌ی بالینی که تشخیص را می‌سازند:**",
    "⚠️ **یک — پرخونی ملتحمه (conjunctival suffusion) بدون ترشح چرکی.**",
    "این یافته تقریباً **اختصاصی** است: در تیفوئید، بروسلوز و مالاریا دیده نمی‌شود.",
    "⚠️ **دو — میالژی شدید، به‌ویژه در ساق پا و کمر**، همراه با **CPK بالا**.",
    "تندرنس شدید عضلات ساق در معاینه، یکی از قوی‌ترین سرنخ‌هاست.",
    "**سه — سردرد شدید و ناگهانی** با تب بالا.",
    "⚠️ **سیر بیماری دوفازی است، و همین دو‌فازی بودن بارها پرسیده می‌شود:**",
    "**فاز اول (سپتی‌سمیک):** حدود **یک هفته** تب، سردرد، میالژی؛ باکتری در **خون و CSF** است.",
    "**فاصله‌ی بهبود:** یک تا سه روز که بیمار **احساس بهتری** دارد.",
    "**فاز دوم (ایمنی):** بازگشت تب همراه با **زردی، نارسایی کلیه، مننژیت آسپتیک و خونریزی**؛",
    "⚠️ در این فاز، باکتری از خون رفته و **در ادرار دفع می‌شود**.",
    "**همین جابه‌جایی، انتخاب نمونه‌ی آزمایشگاهی را تعیین می‌کند** (سؤال بعدی همین است).",
    "⚠️ **لپتوسپیروز شدید = بیماری ویل (Weil)**، و تریادش را حفظ کنید:",
    "**زردی + نارسایی کلیه + خونریزی** (کلاسیک: خونریزی ریوی).",
    "**آنسفالیت جزو تریاد نیست**، هرچند مننژیت آسپتیک شایع است.",
    "⚠️ **امضای آزمایشگاهی طلایی:** **بیلی‌روبین بسیار بالا ولی ترانس‌آمینازها فقط مختصر بالا**.",
    "در هپاتیت ویروسی حاد، AST و ALT به **هزارها** می‌رسند؛ در لپتوسپیروز معمولاً زیر چند صد می‌مانند.",
    "همچنین: **لکوسیتوز** (برخلاف بیشتر عفونت‌های ویروسی)، **ترومبوسیتوپنی**، **کراتینین بالا** و **CPK بالا**.",
    "**درمان:** موارد خفیف **داکسی‌سیکلین خوراکی**؛ موارد شدید **پنی‌سیلین G وریدی یا سفتریاکسون**.",
    "⚠️ مراقب **واکنش یاریش-هرکسهایمر** پس از شروع آنتی‌بیوتیک باشید (مثل سایر اسپیروکت‌ها).",
]
CORE_EN = [
    "LEPTOSPIRA IS A THIN, TIGHTLY COILED SPIROCHAETE with hooked ends.",
    "WARNING: THE MAIN RESERVOIR IS RODENTS, and the organism IS EXCRETED IN THEIR URINE.",
    "HOW DO HUMANS ACQUIRE IT? Contact of BROKEN SKIN OR MUCOSA with WATER OR SOIL CONTAMINATED BY RODENT URINE.",
    "WARNING, THE HIGH-RISK GROUP IN IRAN IS RICE FARMERS OF GILAN AND MAZANDARAN — and 'rice farmer' is the exam keyword.",
    "Also: sewer workers, livestock workers, abattoir workers, freshwater swimmers and canoeists, and flood victims.",
    "THE THREE CLINICAL FINDINGS THAT MAKE THE DIAGNOSIS:",
    "WARNING, ONE — CONJUNCTIVAL SUFFUSION WITHOUT PURULENT DISCHARGE.",
    "This finding is nearly SPECIFIC: it is not seen in typhoid, brucellosis or malaria.",
    "WARNING, TWO — SEVERE MYALGIA, especially of the CALVES AND BACK, with a HIGH CPK.",
    "Marked calf tenderness on examination is one of the strongest clues.",
    "THREE — SEVERE, ABRUPT HEADACHE with high fever.",
    "WARNING, THE COURSE IS BIPHASIC, and that biphasic pattern is asked repeatedly:",
    "PHASE ONE (SEPTICAEMIC): about ONE WEEK of fever, headache and myalgia; the organism is in BLOOD AND CSF.",
    "AN INTERVAL OF IMPROVEMENT: one to three days when the patient FEELS BETTER.",
    "PHASE TWO (IMMUNE): fever returns with JAUNDICE, RENAL FAILURE, ASEPTIC MENINGITIS AND BLEEDING;",
    "WARNING, in this phase the organism has left the blood and IS EXCRETED IN THE URINE.",
    "THAT SHIFT DETERMINES WHICH SPECIMEN TO SEND (which is exactly the next question).",
    "WARNING: SEVERE LEPTOSPIROSIS IS WEIL'S DISEASE, and you must memorise its triad:",
    "JAUNDICE PLUS RENAL FAILURE PLUS BLEEDING (classically pulmonary haemorrhage).",
    "ENCEPHALITIS IS NOT PART OF THE TRIAD, although aseptic meningitis is common.",
    "WARNING, THE GOLDEN LABORATORY SIGNATURE: A VERY HIGH BILIRUBIN WITH ONLY MODESTLY RAISED TRANSAMINASES.",
    "In acute viral hepatitis AST and ALT reach THOUSANDS; in leptospirosis they usually stay below a few hundred.",
    "Also: LEUCOCYTOSIS (unlike most viral infections), THROMBOCYTOPENIA, a HIGH CREATININE and a HIGH CPK.",
    "TREATMENT: mild disease ORAL DOXYCYCLINE; severe disease INTRAVENOUS PENICILLIN G OR CEFTRIAXONE.",
    "WARNING: watch for a JARISCH-HERXHEIMER REACTION after starting antibiotics, as with other spirochaetes.",
]


# =========================================================== book:487
add("book:487", "case", "medium",
 "کارگر کشتارگاه + **ملتحمه‌ی قرمز بدون ترشح** + میالژی + هموپتزی + ایکتر ← **لپتوسپیروز**.",
 "Abattoir worker plus CONJUNCTIVAL REDNESS WITHOUT DISCHARGE plus myalgia, haemoptysis and jaundice means LEPTOSPIROSIS.",
 CORE_FA + [
  "این سؤال چهار سرنخ می‌دهد و هر چهار به یک بیماری اشاره می‌کنند:",
  "⚠️ **یک — «قرمزی ملتحمه بدون ترشح چرکی»**: همان پرخونی ملتحمه، یافته‌ی نزدیک به اختصاصی.",
  "**دو — میالژی**: عضله در لپتوسپیروز درگیر می‌شود و CPK بالا می‌رود.",
  "**سه — هموپتزی**: نشانه‌ی **خونریزی ریوی**، جدی‌ترین تظاهر لپتوسپیروز شدید.",
  "**چهار — ایکتر**: همان زردی تریاد ویل.",
  "و شغل: **کارگر کشتارگاه** ← تماس با ادرار و بافت حیوانات، یکی از گروه‌های پرخطر کلاسیک.",
  "⚠️ **حالا CBC را نگاه کنید: WBC=13000 با ۸۰٪ نوتروفیل، پلاکت ۸۰۰۰ (ترومبوسیتوپنی شدید).**",
  "**لکوسیتوز با نوتروفیلی** یک نکته‌ی افتراقی مهم است:",
  "بیشتر عفونت‌های ویروسی (مثل آنفلوانزا) **لکوپنی یا شمارش نرمال** می‌دهند.",
  "و **ترومبوسیتوپنی** یکی از شایع‌ترین یافته‌های لپتوسپیروز شدید است.",
  "چرا بروسلوز نه؟ بروسلوز **پرخونی ملتحمه و هموپتزی نمی‌دهد**، و معمولاً CBC نرمال دارد.",
  "چرا سل نه؟ سل هموپتزی می‌دهد ولی سیرش **هفته‌ها تا ماه‌ها** است، نه هفت روز، و ایکتر نمی‌دهد.",
  "چرا آنفلوانزا نه؟ آنفلوانزا **ایکتر و ترومبوسیتوپنی شدید** نمی‌سازد.",
 ],
 CORE_EN + [
  "This question gives four clues and all four point to one disease:",
  "WARNING, ONE — 'conjunctival redness without purulent discharge': conjunctival suffusion, a near-specific sign.",
  "TWO — MYALGIA: muscle is involved in leptospirosis and the CPK rises.",
  "THREE — HAEMOPTYSIS: a sign of PULMONARY HAEMORRHAGE, the gravest manifestation of severe disease.",
  "FOUR — JAUNDICE: the icterus of Weil's triad.",
  "And the occupation: AN ABATTOIR WORKER, exposed to animal urine and tissue, a classical high-risk group.",
  "WARNING, NOW LOOK AT THE BLOOD COUNT: WBC 13,000 with 80% neutrophils, platelets 8,000 (severe thrombocytopenia).",
  "LEUCOCYTOSIS WITH NEUTROPHILIA is an important discriminator:",
  "most viral infections (influenza among them) give LEUCOPENIA OR A NORMAL COUNT.",
  "And THROMBOCYTOPENIA is among the commonest findings in severe leptospirosis.",
  "Why not brucellosis? Brucellosis DOES NOT CAUSE CONJUNCTIVAL SUFFUSION OR HAEMOPTYSIS, and usually leaves a normal count.",
  "Why not tuberculosis? TB causes haemoptysis but over WEEKS TO MONTHS, not seven days, and it does not cause jaundice.",
  "Why not influenza? Influenza does not produce JAUNDICE AND SEVERE THROMBOCYTOPENIA.",
 ],
 "چهار سرنخ در این سؤال هست و هر چهار به یک بیماری می‌رسند:\n\n"
 "⚠️ **۱. «قرمزی ملتحمه بدون ترشح چرکی»** ← این همان **پرخونی ملتحمه (conjunctival suffusion)** است، یافته‌ای که تقریباً **اختصاصی لپتوسپیروز** است. در تیفوئید، بروسلوز و مالاریا دیده نمی‌شود. وقتی این عبارت در صورت سؤال می‌آید، تزئین نیست — **پاسخ است**.\n\n"
 "**۲. میالژی** ← عضله در لپتوسپیروز واقعاً درگیر می‌شود و CPK بالا می‌رود.\n\n"
 "**۳. هموپتزی** ← نشانه‌ی **خونریزی ریوی**، جدی‌ترین و کشنده‌ترین تظاهر لپتوسپیروز شدید.\n\n"
 "**۴. ایکتر** ← زردیِ تریاد بیماری ویل.\n\n"
 "و شغل بیمار: **کارگر کشتارگاه** ← تماس مستقیم با ادرار و بافت حیوان.\n\n"
 "⚠️ **حالا آزمایش را بخوانید:** WBC=13000 با **۸۰٪ نوتروفیل** و پلاکت **۸۰۰۰**.\n\n"
 "**لکوسیتوز با نوتروفیلی** مهم است چون بیشتر عفونت‌های ویروسی (از جمله آنفلوانزا) **لکوپنی یا شمارش نرمال** می‌دهند. و **ترومبوسیتوپنی شدید** یکی از شایع‌ترین یافته‌های لپتوسپیروز شدید است.\n\n"
 "**چرا بقیه رد می‌شوند؟**\n\n"
 "**بروسلوز** ← نه پرخونی ملتحمه می‌دهد، نه هموپتزی؛ CBC معمولاً نرمال است.\n"
 "**سل** ← هموپتزی بله، ولی سیرش هفته‌ها تا ماه‌هاست نه هفت روز، و ایکتر نمی‌دهد.\n"
 "**آنفلوانزا** ← ایکتر و ترومبوسیتوپنی شدید در آن جایی ندارد.",
 "Four clues here, and all four converge on one disease:\n\n"
 "WARNING, 1. 'CONJUNCTIVAL REDNESS WITHOUT PURULENT DISCHARGE' is CONJUNCTIVAL SUFFUSION, a finding almost SPECIFIC TO LEPTOSPIROSIS. It is not seen in typhoid, brucellosis or malaria. When that phrase appears in a stem it is not decoration — IT IS THE ANSWER.\n\n"
 "2. MYALGIA — muscle really is involved in leptospirosis and the CPK rises.\n\n"
 "3. HAEMOPTYSIS — a sign of PULMONARY HAEMORRHAGE, the gravest and most lethal manifestation of severe disease.\n\n"
 "4. JAUNDICE — the icterus of Weil's triad.\n\n"
 "And the occupation: AN ABATTOIR WORKER, in direct contact with animal urine and tissue.\n\n"
 "WARNING, NOW READ THE LABORATORY: WBC 13,000 with 80% NEUTROPHILS and platelets of 8,000.\n\n"
 "LEUCOCYTOSIS WITH NEUTROPHILIA matters because most viral infections (influenza included) give LEUCOPENIA OR A NORMAL COUNT. And SEVERE THROMBOCYTOPENIA is among the commonest findings in severe leptospirosis.\n\n"
 "WHY THE OTHERS FAIL:\n\n"
 "BRUCELLOSIS — no conjunctival suffusion, no haemoptysis; the blood count is usually normal.\n"
 "TUBERCULOSIS — haemoptysis yes, but over weeks to months rather than seven days, and it does not cause jaundice.\n"
 "INFLUENZA — jaundice and severe thrombocytopenia have no place in it.",
 ["پاسخ صحیح — پرخونی ملتحمه بدون ترشح، میالژی، هموپتزی و ایکتر در کارگر کشتارگاه، تابلوی لپتوسپیروز است.",
  "بروسلوز پرخونی ملتحمه و هموپتزی نمی‌دهد و معمولاً شمارش خون طبیعی دارد.",
  "سل هموپتزی می‌دهد ولی سیر آن هفته‌ها تا ماه‌هاست و ایکتر و ترومبوسیتوپنی شدید ایجاد نمی‌کند.",
  "آنفلوانزا ایکتر و پلاکت ۸۰۰۰ نمی‌سازد و معمولاً لکوسیتوز نوتروفیلی هم ندارد."],
 ["Correct — conjunctival suffusion, myalgia, haemoptysis and jaundice in an abattoir worker is leptospirosis.",
  "Brucellosis causes neither conjunctival suffusion nor haemoptysis, and the blood count is usually normal.",
  "Tuberculosis causes haemoptysis but over weeks to months, and does not cause jaundice or severe thrombocytopenia.",
  "Influenza does not produce jaundice or a platelet count of 8,000, and rarely a neutrophilic leucocytosis."],
 "**پرخونی ملتحمه بدون ترشح + میالژی ساق + شغل مرطوب = لپتوسپیروز** تا خلاف آن ثابت شود.",
 "Conjunctival suffusion without discharge, calf myalgia and a wet occupation means leptospirosis until proven otherwise.",
 [H, WHO, IR])


# =========================================================== book:495
add("book:495", "recall", "medium",
 "در لپتوسپیروز شدید، CSF **پلئوسیتوز لنفوسیتی می‌دهد** — پس گزینه‌ی «دیده نمی‌شود» همین است… **نه**.",
 "In severe leptospirosis the CSF DOES show lymphocytic pleocytosis, so that is the finding wrongly listed as absent.",
 CORE_FA + [
  "این سؤال منفی است: **کدام یافته در لپتوسپیروز شدید دیده نمی‌شود؟**",
  "پس باید سه یافته‌ی **واقعاً موجود** را بشناسید تا چهارمی خودش را نشان دهد.",
  "**لکوسیتوز؟ بله، و یک نکته‌ی افتراقی مهم است.**",
  "⚠️ برخلاف بیشتر بیماری‌های تب‌دار ویروسی، لپتوسپیروز **لکوسیتوز با نوتروفیلی** می‌دهد.",
  "همین یافته کمک می‌کند لپتوسپیروز را از دنگی و آنفلوانزا جدا کنید.",
  "**ترومبوسیتوپنی؟ بله، و بسیار شایع است** — در بیش از نیمی از موارد شدید.",
  "و همین ترومبوسیتوپنی، همراه با آسیب اندوتلیال، **خونریزی ریوی** را می‌سازد.",
  "**افزایش کراتینین؟ بله، و یکی از سه پایه‌ی تریاد ویل است.**",
  "نارسایی کلیه در لپتوسپیروز معمولاً **نفریت بینابینی و نکروز توبولی حاد** است،",
  "⚠️ و نکته‌ی جالبش این است که اغلب **هیپوکالمیک** است — برخلاف بیشتر نارسایی‌های حاد کلیه.",
  "**پلئوسیتوز لنفوسیتی CSF؟ این هم بله!** — و اینجاست که سؤال دشوار می‌شود.",
  "⚠️ **مننژیت آسپتیک در فاز دوم لپتوسپیروز کاملاً شایع است** و CSF دقیقاً همین الگو را می‌دهد.",
  "پس چرا این گزینه پاسخ است؟ چون نویسنده‌ی سؤال آن را **جزو تابلوی «شدید» نمی‌داند**:",
  "در تعریف کلاسیک، **لپتوسپیروز شدید = بیماری ویل = زردی + کلیه + خونریزی**،",
  "و درگیری CNS در آن دسته‌بندی، **شکل جداگانه‌ای** از بیماری شمرده می‌شود نه بخشی از تابلوی شدید.",
  "⚠️ **پس این سؤال را با تعریف کتاب پاسخ دهید، ولی واقعیت بالینی را هم بدانید:**",
  "مننژیت آسپتیک در لپتوسپیروز **رخ می‌دهد** — همان‌طور که در q9486 بیمار پلئوسیتوز ۴۵۰ دارد.",
 ],
 CORE_EN + [
  "This is a negative question: WHICH FINDING IS NOT SEEN IN SEVERE LEPTOSPIROSIS?",
  "So you must recognise the three findings that ARE genuinely present, and the fourth reveals itself.",
  "LEUCOCYTOSIS? YES, and it is an important discriminator.",
  "WARNING: unlike most viral febrile illnesses, leptospirosis causes LEUCOCYTOSIS WITH NEUTROPHILIA.",
  "That single finding helps separate it from dengue and influenza.",
  "THROMBOCYTOPENIA? YES, and very common — in more than half of severe cases.",
  "And that thrombocytopenia, with endothelial injury, produces the PULMONARY HAEMORRHAGE.",
  "A RAISED CREATININE? YES, and it is one of the three pillars of Weil's triad.",
  "Renal failure in leptospirosis is usually INTERSTITIAL NEPHRITIS AND ACUTE TUBULAR NECROSIS,",
  "WARNING, and interestingly it is often HYPOKALAEMIC — unlike most acute kidney injury.",
  "LYMPHOCYTIC CSF PLEOCYTOSIS? THAT TOO OCCURS — and here the question becomes hard.",
  "WARNING: ASEPTIC MENINGITIS IS COMMON IN THE SECOND PHASE and the CSF shows exactly this pattern.",
  "So why is this the answer? Because the question's author does not count it within the 'SEVERE' picture:",
  "in the classical definition, SEVERE LEPTOSPIROSIS IS WEIL'S DISEASE — JAUNDICE, KIDNEY, BLEEDING —",
  "and CNS involvement is classified as A SEPARATE FORM of the illness, not part of the severe picture.",
  "WARNING, SO ANSWER THIS QUESTION BY THE BOOK'S DEFINITION, BUT KNOW THE CLINICAL REALITY:",
  "aseptic meningitis DOES occur in leptospirosis — as in q9486, where the patient has a pleocytosis of 450.",
 ],
 "این سؤال منفی است، پس راهش این است که سه یافته‌ی **واقعاً موجود** را بشناسیم.\n\n"
 "**لکوسیتوز؟ بله.** ⚠️ و این یک نکته‌ی افتراقی مهم است: برخلاف بیشتر بیماری‌های تب‌دار ویروسی که لکوپنی می‌دهند، لپتوسپیروز **لکوسیتوز با نوتروفیلی** می‌سازد. همین یافته کمک می‌کند آن را از دنگی و آنفلوانزا جدا کنید.\n\n"
 "**ترومبوسیتوپنی؟ بله**، در بیش از نیمی از موارد شدید. و همین ترومبوسیتوپنی همراه با **آسیب اندوتلیال**، خونریزی ریوی را می‌سازد.\n\n"
 "**افزایش کراتینین؟ بله**، و یکی از سه پایه‌ی **تریاد بیماری ویل** است. نارسایی کلیه در لپتوسپیروز معمولاً **نفریت بینابینی و نکروز حاد توبولی** است و ⚠️ نکته‌ی جالبش این است که اغلب **هیپوکالمیک** است، برخلاف بیشتر نارسایی‌های حاد کلیه.\n\n"
 "**می‌ماند پلئوسیتوز لنفوسیتی CSF.**\n\n"
 "⚠️ **و اینجا باید صادق بود:** مننژیت آسپتیک در **فاز دوم (ایمنی)** لپتوسپیروز کاملاً شایع است و CSF دقیقاً همین الگو را می‌دهد. پس چرا این گزینه پاسخ سؤال است؟\n\n"
 "چون در **تعریف کلاسیک کتاب**، «لپتوسپیروز شدید» مساوی است با **بیماری ویل**، و بیماری ویل تریاد **زردی + نارسایی کلیه + خونریزی** است. در آن دسته‌بندی، **مننژیت شکل جداگانه‌ای از بیماری** شمرده می‌شود، نه بخشی از تابلوی «شدید».\n\n"
 "⚠️ **پس این سؤال را با تعریف کتاب پاسخ دهید، ولی واقعیت بالینی را فراموش نکنید:** در q9486 همین کتاب، بیمار لپتوسپیروزی **پلئوسیتوز ۴۵۰ با ارجحیت تک‌سلولی** دارد. دو سؤال با هم، دقیقاً همین تفاوت «تعریف» و «واقعیت» را نشان می‌دهند.",
 "This is a negative question, so the way in is to recognise the three findings that ARE present.\n\n"
 "LEUCOCYTOSIS? YES. WARNING, and it is an important discriminator: unlike most viral febrile illnesses, which cause leucopenia, leptospirosis causes LEUCOCYTOSIS WITH NEUTROPHILIA. That helps separate it from dengue and influenza.\n\n"
 "THROMBOCYTOPENIA? YES, in more than half of severe cases. Together with ENDOTHELIAL INJURY it produces the pulmonary haemorrhage.\n\n"
 "A RAISED CREATININE? YES, and one of the three pillars of WEIL'S TRIAD. Renal failure in leptospirosis is usually INTERSTITIAL NEPHRITIS AND ACUTE TUBULAR NECROSIS, and WARNING, interestingly it is often HYPOKALAEMIC, unlike most acute kidney injury.\n\n"
 "THAT LEAVES LYMPHOCYTIC CSF PLEOCYTOSIS.\n\n"
 "WARNING, AND HERE WE MUST BE HONEST: aseptic meningitis is common in the SECOND (IMMUNE) PHASE, and the CSF shows exactly this pattern. So why is this the answer?\n\n"
 "Because in THE BOOK'S CLASSICAL DEFINITION, 'severe leptospirosis' means WEIL'S DISEASE, and Weil's disease is the triad JAUNDICE PLUS RENAL FAILURE PLUS BLEEDING. In that taxonomy, MENINGITIS COUNTS AS A SEPARATE FORM of the illness rather than part of the severe picture.\n\n"
 "WARNING, SO ANSWER BY THE BOOK'S DEFINITION BUT DO NOT FORGET THE CLINICAL REALITY: in q9486 of this same book, the leptospirosis patient has A PLEOCYTOSIS OF 450 WITH MONONUCLEAR PREDOMINANCE. The two questions together show exactly this gap between definition and reality.",
 ["لکوسیتوز در لپتوسپیروز دیده می‌شود و برخلاف بیماری‌های ویروسی، نوتروفیلی هم دارد.",
  "ترومبوسیتوپنی در بیش از نیمی از موارد شدید وجود دارد و در ایجاد خونریزی ریوی نقش دارد.",
  "افزایش کراتینین یکی از سه پایه‌ی تریاد بیماری ویل است و کاملاً مورد انتظار است.",
  "پاسخ صحیح (بر پایه‌ی تعریف کتاب) — درگیری CNS شکل جداگانه‌ای از بیماری است، نه جزئی از تابلوی «شدید» (بیماری ویل)."],
 ["Leucocytosis does occur in leptospirosis and, unlike viral illness, it is neutrophilic.",
  "Thrombocytopenia is present in more than half of severe cases and contributes to pulmonary haemorrhage.",
  "A raised creatinine is one of the three pillars of Weil's triad and is entirely expected.",
  "Correct (by the book's definition) — CNS involvement is a separate form of the disease, not part of the 'severe' (Weil's) picture."],
 "لپتوسپیروز شدید = **زردی + کلیه + خونریزی**. **لکوسیتوز (نه لکوپنی)** یکی از کلیدهای افتراقی است.",
 "Severe leptospirosis is jaundice plus kidney plus bleeding. LEUCOCYTOSIS, not leucopenia, is one of the key discriminators.",
 [H, WHO])


# =========================================================== book:496
add("book:496", "case", "hard",
 "در **فاز دوم** لپتوسپیروز، ارگانیسم از خون رفته و در **ادرار** دفع می‌شود.",
 "In the SECOND PHASE of leptospirosis the organism has left the blood and is shed in the URINE.",
 CORE_FA + [
  "این سؤال، بهترین سؤال کل بلوک لپتوسپیروز است، چون **زمان‌شناسی میکروب** را می‌سنجد.",
  "به تایم‌لاین صورت سؤال دقت کنید:",
  "**یک هفته تب و سردرد و میالژی** ← فاز اول (سپتی‌سمیک).",
  "**پنج روز بدون علائم** ← فاصله‌ی بهبود، همان شکاف مشخصه‌ی سیر دوفازی.",
  "**بازگشت تب همراه با ایکتر** ← فاز دوم (ایمنی).",
  "⚠️ **حالا قاعده‌ی طلایی: محل ارگانیسم در دو فاز فرق می‌کند.**",
  "**در فاز اول (حدود ۷ تا ۱۰ روز اول): لپتوسپیرا در خون و مایع مغزی‌نخاعی است.**",
  "پس در آن مرحله، **کشت خون** نمونه‌ی درست است.",
  "**در فاز دوم: آنتی‌بادی ظاهر شده، باکتری از خون پاک شده،**",
  "⚠️ **ولی در لوله‌های کلیوی باقی مانده و از راه ادرار دفع می‌شود** — گاهی هفته‌ها تا ماه‌ها.",
  "پس در فاز دوم، **کشت ادرار** نمونه‌ی درست است. و بیمار ما دقیقاً در فاز دوم است.",
  "**همین موضوع توضیح می‌دهد چرا کل چرخه‌ی انتقال با ادرار جونده کار می‌کند.**",
  "چرا مغز استخوان نه؟ لپتوسپیرا ارگانیسم **داخل‌سلولی ماکروفاژ** نیست؛ جایگاهش کلیه است.",
  "چرا مدفوع نه؟ لپتوسپیرا از راه گوارش دفع نمی‌شود.",
  "⚠️ **و یک نکته‌ی عملی: کشت لپتوسپیرا کند و دشوار است** (محیط EMJH، هفته‌ها).",
  "به همین دلیل در عمل، تشخیص با **سرولوژی (MAT یا الایزای IgM)** یا **PCR** گذاشته می‌شود،",
  "و **درمان هرگز منتظر نتیجه‌ی کشت نمی‌ماند**.",
 ],
 CORE_EN + [
  "This is the best question in the whole leptospirosis block, because it tests THE MICROBIOLOGICAL TIMELINE.",
  "Look carefully at the chronology in the stem:",
  "A WEEK OF FEVER, HEADACHE AND MYALGIA — phase one, septicaemic.",
  "FIVE DAYS FREE OF SYMPTOMS — the interval of improvement, the hallmark gap of the biphasic course.",
  "FEVER RETURNS WITH JAUNDICE — phase two, immune.",
  "WARNING, NOW THE GOLDEN RULE: THE ORGANISM'S LOCATION DIFFERS BETWEEN THE TWO PHASES.",
  "IN PHASE ONE (roughly the first 7 to 10 days) LEPTOSPIRA IS IN THE BLOOD AND CSF.",
  "So at that stage BLOOD CULTURE is the right specimen.",
  "IN PHASE TWO antibody has appeared and the organism has been cleared from the blood,",
  "WARNING, BUT IT PERSISTS IN THE RENAL TUBULES AND IS SHED IN THE URINE — sometimes for weeks to months.",
  "So in phase two URINE CULTURE is the right specimen. And our patient is squarely in phase two.",
  "THIS ALSO EXPLAINS WHY THE WHOLE TRANSMISSION CYCLE RUNS ON RODENT URINE.",
  "Why not bone marrow? Leptospira is not a MACROPHAGE-DWELLING organism; its niche is the kidney.",
  "Why not stool? Leptospira is not excreted through the gastrointestinal tract.",
  "WARNING, A PRACTICAL POINT: LEPTOSPIRA CULTURE IS SLOW AND DIFFICULT (EMJH medium, weeks).",
  "So in practice the diagnosis is made by SEROLOGY (MAT or IgM ELISA) or PCR,",
  "and TREATMENT NEVER WAITS FOR A CULTURE RESULT.",
 ],
 "این بهترین سؤال بلوک لپتوسپیروز است، چون **زمان‌شناسی میکروب** را می‌سنجد نه صرفاً تشخیص را.\n\n"
 "**اول تایم‌لاین صورت سؤال را بخوانید:**\n\n"
 "**یک هفته تب، سردرد و میالژی** ← **فاز اول (سپتی‌سمیک)**\n"
 "**پنج روز بدون علائم** ← **فاصله‌ی بهبود** — همان شکاف مشخصه‌ی سیر دوفازی\n"
 "**بازگشت تب همراه با ایکتر** ← **فاز دوم (ایمنی)**\n\n"
 "⚠️ **حالا قاعده‌ی طلایی: محل ارگانیسم در دو فاز فرق می‌کند.**\n\n"
 "**فاز اول (تقریباً ۷ تا ۱۰ روز اول):** لپتوسپیرا در **خون و مایع مغزی‌نخاعی** است ← نمونه‌ی درست: **کشت خون**\n\n"
 "**فاز دوم:** آنتی‌بادی ظاهر شده و باکتری از خون **پاک** شده، ولی ⚠️ **در لوله‌های کلیوی باقی مانده و از راه ادرار دفع می‌شود** — گاهی هفته‌ها تا ماه‌ها ← نمونه‌ی درست: **کشت ادرار**\n\n"
 "بیمار ما دقیقاً در فاز دوم است، پس پاسخ **ادرار** است.\n\n"
 "**و این همان چیزی است که کل چرخه‌ی انتقال بیماری را توضیح می‌دهد:** جونده هم دقیقاً به همین دلیل، سال‌ها بدون بیماری، لپتوسپیرا را در ادرارش دفع می‌کند و آب شالیزار را آلوده می‌کند.\n\n"
 "**چرا بقیه نه؟** **مغز استخوان** ← لپتوسپیرا ارگانیسم داخل‌ماکروفاژی نیست. **مدفوع** ← از راه گوارش دفع نمی‌شود. **خون محیطی** ← درست بود اگر بیمار در **هفته‌ی اول** بود.\n\n"
 "⚠️ **یک نکته‌ی عملی مهم:** کشت لپتوسپیرا **کند و دشوار** است (محیط EMJH، هفته‌ها). در عمل تشخیص با **سرولوژی (MAT یا الایزای IgM)** یا **PCR** گذاشته می‌شود و **درمان هرگز منتظر کشت نمی‌ماند**.",
 "This is the best question in the leptospirosis block, because it tests THE MICROBIOLOGICAL TIMELINE rather than the diagnosis alone.\n\n"
 "FIRST READ THE CHRONOLOGY IN THE STEM:\n\n"
 "A WEEK OF FEVER, HEADACHE AND MYALGIA — PHASE ONE (SEPTICAEMIC)\n"
 "FIVE DAYS FREE OF SYMPTOMS — THE INTERVAL OF IMPROVEMENT, hallmark of the biphasic course\n"
 "FEVER RETURNS WITH JAUNDICE — PHASE TWO (IMMUNE)\n\n"
 "WARNING, NOW THE GOLDEN RULE: THE ORGANISM'S LOCATION DIFFERS BETWEEN PHASES.\n\n"
 "PHASE ONE (about the first 7 to 10 days): Leptospira is in the BLOOD AND CSF — the right specimen is BLOOD CULTURE.\n\n"
 "PHASE TWO: antibody has appeared and the organism has been CLEARED from the blood, but WARNING, IT PERSISTS IN THE RENAL TUBULES AND IS SHED IN THE URINE, sometimes for weeks to months — the right specimen is URINE CULTURE.\n\n"
 "Our patient is squarely in phase two, so the answer is URINE.\n\n"
 "AND THIS IS EXACTLY WHAT EXPLAINS THE WHOLE TRANSMISSION CYCLE: the rodent, for the same reason, sheds Leptospira in its urine for years without being ill, and contaminates the water of the paddy field.\n\n"
 "WHY NOT THE OTHERS? BONE MARROW — Leptospira is not a macrophage-dwelling organism. STOOL — it is not excreted through the gut. PERIPHERAL BLOOD — this would be right if the patient were in the FIRST WEEK.\n\n"
 "WARNING, AN IMPORTANT PRACTICAL POINT: leptospiral culture is SLOW AND DIFFICULT (EMJH medium, weeks). In practice the diagnosis is made by SEROLOGY (MAT or IgM ELISA) or PCR, and TREATMENT NEVER WAITS FOR THE CULTURE.",
 ["خون محیطی در فاز اول (هفته‌ی نخست) نمونه‌ی درست است؛ این بیمار در فاز دوم است.",
  "پاسخ صحیح — در فاز دوم، ارگانیسم از خون پاک شده و از لوله‌های کلیوی وارد ادرار می‌شود.",
  "لپتوسپیرا ارگانیسم داخل‌ماکروفاژی نیست و مغز استخوان جایگاه آن محسوب نمی‌شود.",
  "لپتوسپیرا از راه دستگاه گوارش دفع نمی‌شود و کشت مدفوع در آن جایی ندارد."],
 ["Peripheral blood is correct in phase one (the first week); this patient is in phase two.",
  "Correct — in phase two the organism has cleared from the blood and is shed from the renal tubules into the urine.",
  "Leptospira is not a macrophage-dwelling organism and bone marrow is not its niche.",
  "Leptospira is not excreted through the gastrointestinal tract, so stool culture has no role."],
 "**فاز ۱ (هفته‌ی اول) ← خون و CSF. فاز ۲ ← ادرار.** همین، چرخه‌ی انتقال با ادرار جونده را هم توضیح می‌دهد.",
 "Phase one (first week) means blood and CSF; phase two means urine. The same fact explains transmission via rodent urine.",
 [H, WHO])


# =========================================================== book:493
add("book:493", "case", "hard",
 "**بیلی‌روبین ۱۷ با AST/ALT حدود ۲۰۰** ← زردیِ نامتناسب با ترانس‌آمینازها ← **لپتوسپیروز**، نه هپاتیت.",
 "A BILIRUBIN OF 17 WITH AST/ALT AROUND 200 is jaundice out of proportion to the transaminases: LEPTOSPIROSIS, not hepatitis.",
 CORE_FA + [
  "این سؤال کاملاً روی **الگوی آزمایشگاهی** بنا شده و بهترین تمرین تفسیر پنل کبدی است.",
  "بیمار **خانم شالیکار ۵۰ ساله** با **ایکتر و ضعف** است — و شغل، تشخیص را از همان اول جهت می‌دهد.",
  "**اعداد را کنار هم بگذارید:**",
  "**بیلی‌روبین توتال ۱۷ و دایرکت ۱۲** ← زردی **بسیار شدید** و عمدتاً کونژوگه.",
  "**AST=207، ALT=217** ← افزایش **مختصر** ترانس‌آمینازها (حدود ۵ برابر نرمال).",
  "**ALP=257** ← افزایش خفیف. **کراتینین ۳** ← نارسایی کلیه. **پلاکت ۷۰ هزار** ← ترومبوسیتوپنی.",
  "**لکوسیتوز** ← علیه هپاتیت ویروسی. **INR=1.1 و PT=14** ← عملکرد سنتزی کبد **حفظ شده**.",
  "⚠️ **حالا مهم‌ترین قاعده‌ی این سؤال:**",
  "**در هپاتیت ویروسی حاد، ترانس‌آمینازها به هزارها می‌رسند** (اغلب بالای ۱۰۰۰).",
  "**در لپتوسپیروز، بیلی‌روبین بسیار بالا می‌رود ولی ترانس‌آمینازها معمولاً زیر ۲۰۰ تا ۵۰۰ می‌مانند.**",
  "این «**زردی نامتناسب با آسیب سلول کبدی**» امضای لپتوسپیروز است.",
  "چرا چنین است؟ چون مکانیسم لپتوسپیروز **آسیب مستقیم هپاتوسیت نیست**؛",
  "بلکه **اختلال در انتقال بیلی‌روبین و آسیب کاپیلاری** است — سلول کبد تا حد زیادی سالم می‌ماند.",
  "⚠️ و به همین دلیل **INR نرمال** است: کبدی که پروتئین می‌سازد، نمرده است.",
  "چرا کلستاز تومورال نه؟ آن **بدون تب، بدون لکوسیتوز، بدون نارسایی کلیه** و با ALP **بسیار بالاتر** است.",
  "چرا DIC نه؟ در DIC **INR و PT طولانی** می‌شوند؛ اینجا هر دو **نرمال**‌اند.",
  "⚠️ ترومبوسیتوپنی به‌تنهایی DIC نیست — این نکته‌ای است که مکرر اشتباه می‌شود.",
 ],
 CORE_EN + [
  "This question is built entirely on THE LABORATORY PATTERN and is the best exercise in reading a liver panel.",
  "The patient is a 50-YEAR-OLD FEMALE RICE FARMER with JAUNDICE AND WEAKNESS — the occupation orients us at once.",
  "PUT THE NUMBERS SIDE BY SIDE:",
  "TOTAL BILIRUBIN 17, DIRECT 12 — VERY SEVERE, largely conjugated jaundice.",
  "AST 207, ALT 217 — a MODEST rise in transaminases (about five times normal).",
  "ALP 257 — mildly raised. CREATININE 3 — renal failure. PLATELETS 70,000 — thrombocytopenia.",
  "LEUCOCYTOSIS — against viral hepatitis. INR 1.1 AND PT 14 — SYNTHETIC LIVER FUNCTION IS PRESERVED.",
  "WARNING, NOW THE KEY RULE OF THIS QUESTION:",
  "IN ACUTE VIRAL HEPATITIS THE TRANSAMINASES REACH THOUSANDS (often above 1000).",
  "IN LEPTOSPIROSIS THE BILIRUBIN CLIMBS VERY HIGH WHILE THE TRANSAMINASES USUALLY STAY BELOW 200-500.",
  "That JAUNDICE OUT OF PROPORTION TO HEPATOCELLULAR INJURY is the signature of leptospirosis.",
  "Why? Because the mechanism in leptospirosis IS NOT DIRECT HEPATOCYTE NECROSIS;",
  "it is IMPAIRED BILIRUBIN TRANSPORT AND CAPILLARY INJURY — the hepatocyte largely survives.",
  "WARNING, and that is why THE INR IS NORMAL: a liver still making protein has not died.",
  "Why not tumour cholestasis? That comes WITHOUT FEVER, WITHOUT LEUCOCYTOSIS, WITHOUT RENAL FAILURE, and with a MUCH HIGHER ALP.",
  "Why not DIC? In DIC the INR AND PT ARE PROLONGED; here both are NORMAL.",
  "WARNING: THROMBOCYTOPENIA ALONE IS NOT DIC — a point that is very often got wrong.",
 ],
 "این سؤال کاملاً روی **الگوی آزمایشگاهی** بنا شده است، و بهترین تمرین تفسیر پنل کبدی در کل فصل.\n\n"
 "بیمار **خانم شالیکار ۵۰ ساله** با ایکتر و ضعف است. شغل از همان اول تشخیص را جهت می‌دهد.\n\n"
 "**اعداد را کنار هم بگذارید:**\n\n"
 "**بیلی‌روبین توتال ۱۷، دایرکت ۱۲** ← زردی **بسیار شدید**\n"
 "**AST=207، ALT=217** ← افزایش **مختصر** (حدود ۵ برابر نرمال)\n"
 "**ALP=257** ← افزایش خفیف\n"
 "**کراتینین ۳** ← نارسایی کلیه\n"
 "**پلاکت ۷۰ هزار** ← ترومبوسیتوپنی\n"
 "**لکوسیتوز** ← علیه هپاتیت ویروسی\n"
 "**INR=1.1، PT=14** ← عملکرد سنتزی کبد **حفظ شده**\n\n"
 "⚠️ **مهم‌ترین قاعده‌ی این سؤال:**\n\n"
 "**در هپاتیت ویروسی حاد، ترانس‌آمینازها به هزارها می‌رسند.** در لپتوسپیروز، **بیلی‌روبین بسیار بالا می‌رود ولی ترانس‌آمینازها معمولاً زیر ۲۰۰ تا ۵۰۰ می‌مانند**. این «**زردی نامتناسب با آسیب سلول کبدی**» امضای لپتوسپیروز است.\n\n"
 "**چرا؟** چون مکانیسم لپتوسپیروز **نکروز مستقیم هپاتوسیت نیست**؛ بلکه **اختلال در انتقال بیلی‌روبین و آسیب کاپیلاری** است. سلول کبد تا حد زیادی سالم می‌ماند — و ⚠️ **دقیقاً به همین دلیل INR نرمال است**. کبدی که هنوز پروتئین می‌سازد، نمرده است.\n\n"
 "**چرا گزینه‌های دیگر رد می‌شوند؟**\n\n"
 "**هپاتیت حاد** ← ترانس‌آمینازها باید هزارها باشند، نه ۲۰۰؛ ضمناً لکوسیتوز و نارسایی کلیه در آن انتظار نمی‌رود.\n\n"
 "**کلستاز ناشی از تومور پانکراس** ← بدون تب، بدون لکوسیتوز، بدون نارسایی کلیه، و با ALP **بسیار بالاتر**.\n\n"
 "⚠️ **DIC** ← در DIC، **INR و PT طولانی** می‌شوند. اینجا هر دو **نرمال**‌اند. **ترومبوسیتوپنی به‌تنهایی DIC نیست** — این یکی از پرتکرارترین خطاهای تفسیری است.",
 "This question is built entirely on THE LABORATORY PATTERN, and is the best liver-panel exercise in the chapter.\n\n"
 "The patient is a 50-YEAR-OLD FEMALE RICE FARMER with jaundice and weakness. The occupation orients us immediately.\n\n"
 "PUT THE NUMBERS SIDE BY SIDE:\n\n"
 "TOTAL BILIRUBIN 17, DIRECT 12 — VERY SEVERE jaundice\n"
 "AST 207, ALT 217 — a MODEST rise (about five times normal)\n"
 "ALP 257 — mildly raised\n"
 "CREATININE 3 — renal failure\n"
 "PLATELETS 70,000 — thrombocytopenia\n"
 "LEUCOCYTOSIS — against viral hepatitis\n"
 "INR 1.1, PT 14 — SYNTHETIC LIVER FUNCTION PRESERVED\n\n"
 "WARNING, THE KEY RULE OF THIS QUESTION:\n\n"
 "IN ACUTE VIRAL HEPATITIS THE TRANSAMINASES REACH THOUSANDS. In leptospirosis THE BILIRUBIN CLIMBS VERY HIGH WHILE THE TRANSAMINASES USUALLY STAY BELOW 200 TO 500. That JAUNDICE OUT OF PROPORTION TO HEPATOCELLULAR INJURY is the signature of leptospirosis.\n\n"
 "WHY? Because the mechanism is NOT DIRECT HEPATOCYTE NECROSIS but IMPAIRED BILIRUBIN TRANSPORT AND CAPILLARY INJURY. The hepatocyte largely survives — and WARNING, THAT IS PRECISELY WHY THE INR IS NORMAL. A liver still making protein has not died.\n\n"
 "WHY THE OTHER OPTIONS FAIL:\n\n"
 "ACUTE HEPATITIS — the transaminases should be in the thousands, not 200; and leucocytosis and renal failure are not expected.\n\n"
 "PANCREATIC TUMOUR CHOLESTASIS — no fever, no leucocytosis, no renal failure, and a MUCH HIGHER ALP.\n\n"
 "WARNING, DIC — in DIC the INR AND PT ARE PROLONGED. Here both are NORMAL. THROMBOCYTOPENIA ALONE IS NOT DIC, one of the commonest interpretive errors.",
 ["در هپاتیت ویروسی حاد ترانس‌آمینازها به هزارها می‌رسند؛ اینجا حدود ۲۰۰ هستند و لکوسیتوز هم علیه آن است.",
  "کلستاز تومورال بدون تب و لکوسیتوز است، ALP آن بسیار بالاتر می‌رود و نارسایی کلیه ایجاد نمی‌کند.",
  "پاسخ صحیح — شالیکار با زردی شدید، ترانس‌آمینازهای فقط مختصر بالا، نارسایی کلیه و ترومبوسیتوپنی: لپتوسپیروز.",
  "در DIC آزمایش‌های انعقادی طولانی می‌شوند؛ اینجا INR برابر ۱٫۱ و PT برابر ۱۴ ثانیه یعنی نرمال است."],
 ["In acute viral hepatitis the transaminases reach thousands; here they are around 200, and leucocytosis argues against it.",
  "Tumour cholestasis comes without fever or leucocytosis, has a much higher ALP, and does not cause renal failure.",
  "Correct — a rice farmer with deep jaundice, only modestly raised transaminases, renal failure and thrombocytopenia: leptospirosis.",
  "In DIC the coagulation tests are prolonged; here the INR is 1.1 and the PT 14 seconds, which is normal."],
 "**بیلی‌روبین خیلی بالا + ترانس‌آمیناز فقط کمی بالا + INR نرمال = لپتوسپیروز، نه هپاتیت.**",
 "Very high bilirubin with only mildly raised transaminases and a normal INR means leptospirosis, not hepatitis.",
 [H, WHO])


# =========================================================== book:497
add("book:497", "case", "medium",
 "اسمیر با **ارگانیسم مارپیچی** در بیمار شمالی ← لپتوسپیروز ← درمان با **پنی‌سیلین**.",
 "A SPIRAL ORGANISM on the smear in a patient from the north means leptospirosis: treat with PENICILLIN.",
 CORE_FA + [
  "خانم ۲۵ ساله **اهل شمال**، تب ۳۹ درجه، سردرد و میالژی از دو روز پیش.",
  "در معاینه: **پرخونی ملتحمه** و **تندرنس ساق پا** — دو یافته‌ی کلاسیک با هم.",
  "و در اسمیر خون محیطی: **ارگانیسم مارپیچی** ← اسپیروکت ← لپتوسپیرا.",
  "⚠️ توجه کنید بیمار در **روز دوم** است، یعنی **فاز اول (سپتی‌سمیک)** —",
  "و دقیقاً به همین دلیل ارگانیسم هنوز **در خون** دیده می‌شود.",
  "**درمان لپتوسپیروز را به دو دسته تقسیم کنید:**",
  "**بیماری خفیف (سرپایی):** **داکسی‌سیکلین ۱۰۰ میلی‌گرم دو بار در روز** به مدت ۷ روز.",
  "جایگزین‌ها: آزیترومایسین یا آموکسی‌سیلین.",
  "⚠️ **بیماری شدید (بستری):** **پنی‌سیلین G وریدی** یا **سفتریاکسون وریدی**.",
  "کارآزمایی‌ها نشان داده‌اند سفتریاکسون به‌اندازه‌ی پنی‌سیلین G مؤثر است.",
  "**چرا پنی‌سیلین؟ چون لپتوسپیرا یک اسپیروکت است و اسپیروکت‌ها به بتالاکتام حساس‌اند** —",
  "همان منطقی که در سیفلیس هم پنی‌سیلین را داروی انتخابی می‌کند.",
  "چرا وانکومایسین نه؟ وانکومایسین برای **گرم‌مثبت‌ها** است؛ اسپیروکت‌ها پوشش داده نمی‌شوند.",
  "چرا ایمی‌پنم نه؟ بیش از حد وسیع و غیرضروری است؛ هیچ مزیتی بر پنی‌سیلین ندارد.",
  "چرا سیپروفلوکساسین نه؟ کینولون‌ها روی لپتوسپیرا **اثر قابل اتکایی ندارند**.",
  "⚠️ **و یک هشدار: پس از شروع آنتی‌بیوتیک، مراقب واکنش یاریش-هرکسهایمر باشید** —",
  "تب، لرز و افت فشار ظرف چند ساعت، ناشی از آزاد شدن ناگهانی محتویات باکتری کشته‌شده.",
 ],
 CORE_EN + [
  "A 25-year-old woman FROM THE NORTH, fever of 39, headache and myalgia for two days.",
  "On examination: CONJUNCTIVAL SUFFUSION and CALF TENDERNESS — two classical findings together.",
  "And on the peripheral smear: A SPIRAL ORGANISM — a spirochaete — Leptospira.",
  "WARNING, note that the patient is on DAY TWO, that is in PHASE ONE (SEPTICAEMIC),",
  "and that is exactly why the organism is still visible IN THE BLOOD.",
  "DIVIDE THE TREATMENT OF LEPTOSPIROSIS IN TWO:",
  "MILD (OUTPATIENT) DISEASE: DOXYCYCLINE 100 MG TWICE DAILY for 7 days.",
  "Alternatives: azithromycin or amoxicillin.",
  "WARNING, SEVERE (INPATIENT) DISEASE: INTRAVENOUS PENICILLIN G or INTRAVENOUS CEFTRIAXONE.",
  "Trials show ceftriaxone to be as effective as penicillin G.",
  "WHY PENICILLIN? BECAUSE LEPTOSPIRA IS A SPIROCHAETE AND SPIROCHAETES ARE BETA-LACTAM SENSITIVE —",
  "the same logic that makes penicillin the drug of choice in syphilis.",
  "Why not vancomycin? Vancomycin is for GRAM-POSITIVES; spirochaetes are not covered.",
  "Why not imipenem? Needlessly broad, with no advantage over penicillin.",
  "Why not ciprofloxacin? Quinolones HAVE NO RELIABLE ACTIVITY against Leptospira.",
  "WARNING, AND ONE CAUTION: after starting antibiotics watch for a JARISCH-HERXHEIMER REACTION —",
  "fever, rigors and hypotension within hours, from the sudden release of killed bacterial contents.",
 ],
 "خانم ۲۵ ساله **اهل شمال**، تب ۳۹ درجه، سردرد و میالژی از دو روز پیش. در معاینه **پرخونی ملتحمه** و **تندرنس ساق پا** دارد، و در اسمیر خون محیطی **ارگانیسم مارپیچی** گزارش شده است.\n\n"
 "**اسپیروکت + شمال ایران + پرخونی ملتحمه + میالژی ساق = لپتوسپیروز.**\n\n"
 "⚠️ **و یک نکته‌ی زمانی مهم:** بیمار در **روز دوم** است، یعنی در **فاز اول (سپتی‌سمیک)**. دقیقاً به همین دلیل ارگانیسم هنوز **در خون** قابل مشاهده است. (اگر یک هفته دیرتر می‌آمد، باید سراغ ادرار می‌رفتیم — همان درسی که در سؤال قبل آمد.)\n\n"
 "**درمان لپتوسپیروز را به دو دسته تقسیم کنید:**\n\n"
 "**بیماری خفیف (سرپایی):** **داکسی‌سیکلین ۱۰۰ میلی‌گرم دو بار در روز، ۷ روز**. جایگزین: آزیترومایسین یا آموکسی‌سیلین.\n\n"
 "⚠️ **بیماری شدید (بستری):** **پنی‌سیلین G وریدی** یا **سفتریاکسون وریدی** — کارآزمایی‌ها نشان داده‌اند این دو هم‌ارزند.\n\n"
 "**چرا پنی‌سیلین؟** چون لپتوسپیرا یک **اسپیروکت** است و اسپیروکت‌ها به بتالاکتام حساس‌اند — همان منطقی که پنی‌سیلین را در سیفلیس هم داروی انتخابی می‌کند.\n\n"
 "**چرا بقیه نه؟** **وانکومایسین** ← برای گرم‌مثبت‌هاست، اسپیروکت را پوشش نمی‌دهد. **ایمی‌پنم** ← بیش از حد وسیع و بی‌مزیت. **سیپروفلوکساسین** ← کینولون‌ها روی لپتوسپیرا اثر قابل اتکایی ندارند.\n\n"
 "⚠️ **و یک هشدار عملی:** پس از شروع آنتی‌بیوتیک مراقب **واکنش یاریش-هرکسهایمر** باشید: تب، لرز و افت فشار ظرف چند ساعت، ناشی از آزاد شدن ناگهانی محتویات باکتری‌های کشته‌شده. این واکنش دلیل قطع درمان نیست.",
 "A 25-year-old woman FROM THE NORTH, fever of 39, headache and myalgia for two days. On examination she has CONJUNCTIVAL SUFFUSION and CALF TENDERNESS, and the peripheral smear reports A SPIRAL ORGANISM.\n\n"
 "SPIROCHAETE PLUS NORTHERN IRAN PLUS CONJUNCTIVAL SUFFUSION PLUS CALF MYALGIA MEANS LEPTOSPIROSIS.\n\n"
 "WARNING, AN IMPORTANT POINT ABOUT TIMING: the patient is on DAY TWO, that is in PHASE ONE (SEPTICAEMIC). That is exactly why the organism is still visible IN THE BLOOD. (Had she come a week later we would be looking at urine — the lesson of the previous question.)\n\n"
 "DIVIDE THE TREATMENT IN TWO:\n\n"
 "MILD (OUTPATIENT): DOXYCYCLINE 100 MG TWICE DAILY FOR 7 DAYS. Alternatives: azithromycin or amoxicillin.\n\n"
 "WARNING, SEVERE (INPATIENT): INTRAVENOUS PENICILLIN G or INTRAVENOUS CEFTRIAXONE — trials show them equivalent.\n\n"
 "WHY PENICILLIN? Because Leptospira is a SPIROCHAETE, and spirochaetes are beta-lactam sensitive — the same logic that makes penicillin the drug of choice in syphilis.\n\n"
 "WHY NOT THE OTHERS? VANCOMYCIN is for gram-positives and does not cover spirochaetes. IMIPENEM is needlessly broad with no advantage. CIPROFLOXACIN — quinolones have no reliable activity against Leptospira.\n\n"
 "WARNING, A PRACTICAL CAUTION: after starting antibiotics watch for a JARISCH-HERXHEIMER REACTION — fever, rigors and hypotension within hours, from the sudden release of killed bacterial contents. It is not a reason to stop treatment.",
 ["وانکومایسین برای باکتری‌های گرم‌مثبت است و اسپیروکت‌ها را پوشش نمی‌دهد.",
  "پاسخ صحیح — لپتوسپیرا اسپیروکت است و به بتالاکتام حساس؛ پنی‌سیلین (و سفتریاکسون) داروی انتخابی موارد شدید است.",
  "ایمی‌پنم بیش از حد وسیع و غیرضروری است و هیچ مزیتی بر پنی‌سیلین در لپتوسپیروز ندارد.",
  "کینولون‌ها روی لپتوسپیرا اثر قابل اتکایی ندارند و انتخاب مناسبی نیستند."],
 ["Vancomycin is for gram-positive bacteria and does not cover spirochaetes.",
  "Correct — Leptospira is a spirochaete and beta-lactam sensitive; penicillin (or ceftriaxone) is the drug of choice in severe disease.",
  "Imipenem is needlessly broad and offers no advantage over penicillin in leptospirosis.",
  "Quinolones have no reliable activity against Leptospira and are not an appropriate choice."],
 "لپتوسپیروز خفیف ← **داکسی‌سیکلین**. شدید ← **پنی‌سیلین G یا سفتریاکسون وریدی**. مراقب **یاریش-هرکسهایمر**.",
 "Mild leptospirosis: doxycycline. Severe: intravenous penicillin G or ceftriaxone. Watch for Jarisch-Herxheimer.",
 [H, WHO, IR])


# =========================================================== book:498
add("book:498", "recall", "medium",
 "پروفیلاکسی لپتوسپیروز = **داکسی‌سیکلین هفتگی**؛ در گزینه‌های موجود، **آزیترومایسین** تنها انتخاب معقول است.",
 "Leptospirosis prophylaxis is WEEKLY DOXYCYCLINE; among the options offered, AZITHROMYCIN is the only sensible choice.",
 CORE_FA + [
  "این سؤال درباره‌ی **پروفیلاکسی پیش از تماس** برای تیمی است که به منطقه‌ی اندمیک می‌رود.",
  "⚠️ **قایق‌رانی و ورزش‌های آب شیرین یکی از شناخته‌شده‌ترین راه‌های ابتلا در جهان‌اند.**",
  "شنا کردن، قایق‌سواری و ماجراجویی در آب‌های شیرین آلوده، مکرراً باعث **طغیان** شده‌اند.",
  "**رژیم استاندارد پروفیلاکسی: داکسی‌سیکلین ۲۰۰ میلی‌گرم، هفته‌ای یک بار**،",
  "از یک تا دو روز پیش از تماس تا پایان دوره‌ی تماس.",
  "⚠️ **اما داکسی‌سیکلین در گزینه‌های این سؤال نیست** — پس باید بهترین جایگزین را انتخاب کرد.",
  "**آزیترومایسین جایگزین شناخته‌شده‌ی داکسی‌سیکلین در لپتوسپیروز است**،",
  "هم در درمان بیماری خفیف و هم به‌عنوان پروفیلاکسی، به‌ویژه در **بارداری و کودکان**",
  "که تتراسایکلین‌ها ممنوع‌اند.",
  "چرا پنی‌سیلین و آموکسی‌سیلین نه؟ آن‌ها در **درمان** لپتوسپیروز مؤثرند،",
  "⚠️ ولی برای پروفیلاکسی **دوز روزانه یا چندبار در روز** لازم دارند و عملی نیستند.",
  "و شواهد کارآزمایی برای پروفیلاکسی با آن‌ها وجود ندارد.",
  "چرا سفیکسیم نه؟ **هیچ نقشی در لپتوسپیروز ندارد** — نه در درمان و نه در پیشگیری.",
  "⚠️ **و نکته‌ی مهم‌تر از دارو: پیشگیری غیردارویی.**",
  "**چکمه و دستکش، پوشاندن زخم‌ها، پرهیز از شنا در آب راکد، و کنترل جوندگان**",
  "مؤثرتر از هر آنتی‌بیوتیکی هستند و باید همیشه توصیه شوند.",
 ],
 CORE_EN + [
  "This question is about PRE-EXPOSURE PROPHYLAXIS for a team travelling to an endemic area.",
  "WARNING: CANOEING AND FRESHWATER SPORTS ARE AMONG THE BEST-KNOWN ROUTES OF INFECTION WORLDWIDE.",
  "Swimming, rafting and adventure racing in contaminated fresh water have repeatedly caused OUTBREAKS.",
  "THE STANDARD PROPHYLACTIC REGIMEN: DOXYCYCLINE 200 MG ONCE WEEKLY,",
  "from one to two days before exposure until the exposure period ends.",
  "WARNING, BUT DOXYCYCLINE IS NOT AMONG THE OPTIONS HERE, so we must pick the best alternative.",
  "AZITHROMYCIN IS THE RECOGNISED ALTERNATIVE TO DOXYCYCLINE IN LEPTOSPIROSIS,",
  "both for treating mild disease and as prophylaxis, especially IN PREGNANCY AND CHILDREN",
  "where tetracyclines are forbidden.",
  "Why not penicillin or amoxicillin? They are effective in TREATING leptospirosis,",
  "WARNING, but for prophylaxis they need DAILY OR MULTIPLE DAILY DOSES and are impractical.",
  "And there is no trial evidence supporting them for prophylaxis.",
  "Why not cefixime? It has NO ROLE IN LEPTOSPIROSIS AT ALL, in treatment or prevention.",
  "WARNING, AND MORE IMPORTANT THAN ANY DRUG: NON-PHARMACOLOGICAL PREVENTION.",
  "BOOTS AND GLOVES, COVERING WOUNDS, AVOIDING SWIMMING IN STAGNANT WATER, AND RODENT CONTROL",
  "are more effective than any antibiotic and should always be advised.",
 ],
 "این سؤال درباره‌ی **پروفیلاکسی پیش از تماس** برای تیمی است که به منطقه‌ی اندمیک لپتوسپیروز اعزام می‌شود.\n\n"
 "⚠️ **چرا قایق‌رانی؟** ورزش‌های آب شیرین یکی از شناخته‌شده‌ترین راه‌های ابتلا در جهان‌اند. شنا، قایق‌سواری و مسابقات ماجراجویی در آب‌های آلوده، بارها باعث **طغیان‌های گروهی** شده‌اند — چون آب راکد آلوده به ادرار جونده، دقیقاً محیط ایده‌آل لپتوسپیرا است.\n\n"
 "**رژیم استاندارد پروفیلاکسی: داکسی‌سیکلین ۲۰۰ میلی‌گرم، هفته‌ای یک بار**، از یکی دو روز پیش از تماس تا پایان دوره.\n\n"
 "⚠️ **اما داکسی‌سیکلین در گزینه‌های این سؤال نیست**، پس باید بهترین جایگزین را انتخاب کنیم.\n\n"
 "**آزیترومایسین جایگزین شناخته‌شده‌ی داکسی‌سیکلین در لپتوسپیروز است** — هم در درمان بیماری خفیف و هم به‌عنوان پروفیلاکسی، به‌ویژه در **بارداری و کودکان** که تتراسایکلین‌ها ممنوع‌اند. مزیت عملی‌اش هم **نیمه‌عمر طولانی** است که دوز کم‌تکرار را ممکن می‌کند.\n\n"
 "**چرا بقیه رد می‌شوند؟**\n\n"
 "**پنی‌سیلین و آموکسی‌سیلین** ← در **درمان** مؤثرند، ولی برای پروفیلاکسی **دوز روزانه یا چندبار در روز** می‌خواهند و عملی نیستند؛ شواهد کارآزمایی هم برایشان وجود ندارد.\n\n"
 "**سفیکسیم** ← هیچ نقشی در لپتوسپیروز ندارد.\n\n"
 "⚠️ **و نکته‌ای مهم‌تر از دارو:** پیشگیری اصلی **غیردارویی** است — **چکمه و دستکش، پوشاندن زخم‌ها، پرهیز از شنا در آب راکد، و کنترل جوندگان**. هیچ آنتی‌بیوتیکی جای این‌ها را نمی‌گیرد.",
 "This question is about PRE-EXPOSURE PROPHYLAXIS for a team going to a leptospirosis-endemic area.\n\n"
 "WARNING, WHY CANOEING? Freshwater sports are among the best-known routes of infection worldwide. Swimming, rafting and adventure racing in contaminated water have repeatedly caused GROUP OUTBREAKS, because stagnant water contaminated with rodent urine is Leptospira's ideal environment.\n\n"
 "THE STANDARD PROPHYLACTIC REGIMEN: DOXYCYCLINE 200 MG ONCE WEEKLY, from a day or two before exposure until the period ends.\n\n"
 "WARNING, BUT DOXYCYCLINE IS NOT AMONG THE OPTIONS, so we must choose the best alternative.\n\n"
 "AZITHROMYCIN IS THE RECOGNISED ALTERNATIVE TO DOXYCYCLINE IN LEPTOSPIROSIS — for treating mild disease and as prophylaxis, especially IN PREGNANCY AND CHILDREN where tetracyclines are forbidden. Its practical advantage is a LONG HALF-LIFE that permits infrequent dosing.\n\n"
 "WHY THE OTHERS FAIL:\n\n"
 "PENICILLIN AND AMOXICILLIN are effective in TREATMENT, but for prophylaxis they require DAILY OR MULTIPLE DAILY DOSES and are impractical; nor is there trial evidence for them.\n\n"
 "CEFIXIME has no role in leptospirosis at all.\n\n"
 "WARNING, AND SOMETHING MORE IMPORTANT THAN ANY DRUG: the mainstay of prevention is NON-PHARMACOLOGICAL — BOOTS AND GLOVES, COVERING WOUNDS, AVOIDING STAGNANT WATER, AND RODENT CONTROL. No antibiotic replaces these.",
 ["سفیکسیم هیچ نقشی در درمان یا پیشگیری لپتوسپیروز ندارد.",
  "پنی‌سیلین در درمان موارد شدید مؤثر است، ولی برای پروفیلاکسی دوز مکرر می‌خواهد و عملی نیست.",
  "آموکسی‌سیلین هم داروی درمان است نه پروفیلاکسی، و شواهد کارآزمایی برای پیشگیری با آن وجود ندارد.",
  "پاسخ صحیح — آزیترومایسین جایگزین شناخته‌شده‌ی داکسی‌سیکلین برای پروفیلاکسی لپتوسپیروز است."],
 ["Cefixime has no role in the treatment or prevention of leptospirosis.",
  "Penicillin is effective in severe disease but requires frequent dosing and is impractical as prophylaxis.",
  "Amoxicillin is a treatment drug, not a prophylactic, and there is no trial evidence for it in prevention.",
  "Correct — azithromycin is the recognised alternative to doxycycline for leptospirosis prophylaxis."],
 "پروفیلاکسی لپتوسپیروز = **داکسی‌سیکلین ۲۰۰ mg هفتگی**؛ جایگزین (و در بارداری) = **آزیترومایسین**.",
 "Leptospirosis prophylaxis is doxycycline 200 mg weekly; the alternative, and the choice in pregnancy, is azithromycin.",
 [H, WHO, IR])


# =========================================================== book:486
add("book:486", "case", "hard",
 "شنا + تب ۴۰ + میالژی ساق + ایکتر + هموپتزی + **CSF لنفوسیتی با قند نرمال** ← لپتوسپیروز.",
 "Swimming plus fever of 40, calf myalgia, jaundice, haemoptysis and a LYMPHOCYTIC CSF WITH NORMAL GLUCOSE means leptospirosis.",
 CORE_FA + [
  "این سؤال تمام تابلوی لپتوسپیروز شدید را در یک بیمار جمع کرده است.",
  "**تماس:** یک هفته پس از **مسابقات شنا** — تماس با آب شیرین، کلاسیک‌ترین راه ابتلا.",
  "**فاز اول:** تب ۴۰ درجه، **میالژی شدید ساق پا**، سردرد.",
  "**پنج روز بعد ← فاز دوم:** ایکتر شدید، **سفتی گردن**، و **هموپتزی**.",
  "⚠️ همین «پنج روز بعد» نشانه‌ی همان **سیر دوفازی** است که بارها پرسیده می‌شود.",
  "**آزمایش‌ها را بخوانید:** لکوسیتوز ۱۳ هزار، پلاکت ۷۵۰۰۰، **ALT=175** و **CPK=3000**.",
  "⚠️ **CPK سه هزار، امضای درگیری عضلانی است** — همان چیزی که میالژی ساق را توضیح می‌دهد.",
  "و **ALT فقط ۱۷۵** با ایکتر شدید ← همان «زردی نامتناسب با ترانس‌آمینازها».",
  "**حالا CSF: پلئوسیتوز ۴۵۰ با ارجحیت تک‌سلولی، قند و پروتئین نرمال.**",
  "⚠️ **این الگوی کلاسیک مننژیت آسپتیک است** و در فاز دوم لپتوسپیروز کاملاً شایع.",
  "چرا مننگوکوک نه؟ در مننژیت باکتریال، CSF **نوتروفیلی با قند پایین و پروتئین بالا** است.",
  "⚠️ **قند نرمال CSF عملاً مننژیت باکتریال چرکی را رد می‌کند** — این نکته‌ی طلایی سؤال است.",
  "چرا سرخک نه؟ سرخک با **کوریزا، سرفه، کونژنکتیویت و راش سرتاپایی** می‌آید، نه ایکتر و CPK بالا.",
  "چرا تیفوئید نه؟ تیفوئید **لکوپنی** می‌دهد نه لکوسیتوز، و ایکتر شدید و CPK ۳۰۰۰ نمی‌سازد.",
  "**پس همه‌ی اجزا به لپتوسپیروز می‌رسند: تماس آبی، عضله، کبد، ریه و پرده‌ی مغز.**",
 ],
 CORE_EN + [
  "This question gathers the entire picture of severe leptospirosis into one patient.",
  "THE EXPOSURE: a week after SWIMMING COMPETITIONS — freshwater contact, the most classical route.",
  "PHASE ONE: fever of 40, SEVERE CALF MYALGIA, headache.",
  "FIVE DAYS LATER, PHASE TWO: deep jaundice, NECK STIFFNESS and HAEMOPTYSIS.",
  "WARNING, that 'five days later' is the very BIPHASIC COURSE the examiners keep asking about.",
  "READ THE LABORATORY: leucocytosis of 13,000, platelets 75,000, ALT 175 and CPK 3000.",
  "WARNING: A CPK OF THREE THOUSAND IS THE SIGNATURE OF MUSCLE INVOLVEMENT — which explains the calf myalgia.",
  "And an ALT OF ONLY 175 with deep jaundice is 'jaundice out of proportion to the transaminases'.",
  "NOW THE CSF: pleocytosis of 450 with mononuclear predominance, normal glucose and protein.",
  "WARNING: THAT IS THE CLASSICAL PATTERN OF ASEPTIC MENINGITIS, common in the second phase of leptospirosis.",
  "Why not meningococcus? In bacterial meningitis the CSF is NEUTROPHILIC WITH LOW GLUCOSE AND HIGH PROTEIN.",
  "WARNING: A NORMAL CSF GLUCOSE VIRTUALLY EXCLUDES PYOGENIC BACTERIAL MENINGITIS — the golden point here.",
  "Why not measles? Measles brings CORYZA, COUGH, CONJUNCTIVITIS AND A CEPHALOCAUDAL RASH, not jaundice and a high CPK.",
  "Why not typhoid? Typhoid gives LEUCOPENIA, not leucocytosis, and does not produce deep jaundice with a CPK of 3000.",
  "SO EVERY COMPONENT CONVERGES ON LEPTOSPIROSIS: water exposure, muscle, liver, lung and meninges.",
 ],
 "این سؤال تمام تابلوی لپتوسپیروز شدید را در یک بیمار جمع کرده است. بیایید تکه‌تکه بخوانیمش:\n\n"
 "**تماس:** یک هفته پس از **مسابقات شنا** ← تماس با آب شیرین، کلاسیک‌ترین راه ابتلا.\n\n"
 "**فاز اول:** تب ۴۰ درجه، **میالژی شدید ساق پا**، سردرد.\n\n"
 "⚠️ **«پنج روز بعد»** ← این عبارت اتفاقی نیست؛ نشانه‌ی همان **سیر دوفازی** است. **فاز دوم**: ایکتر شدید، سفتی گردن و **هموپتزی**.\n\n"
 "**آزمایش‌ها:**\n\n"
 "**لکوسیتوز ۱۳ هزار** ← علیه بیماری ویروسی\n"
 "**پلاکت ۷۵۰۰۰** ← ترومبوسیتوپنی\n"
 "**ALT=175** با **ایکتر شدید** ← ⚠️ همان **زردی نامتناسب با ترانس‌آمینازها**\n"
 "**CPK=3000** ← ⚠️ **امضای درگیری عضلانی**، همان چیزی که میالژی ساق را توضیح می‌دهد\n\n"
 "**و حالا CSF: پلئوسیتوز ۴۵۰ با ارجحیت تک‌سلولی، قند و پروتئین نرمال.**\n\n"
 "⚠️ **این الگوی کلاسیک مننژیت آسپتیک است**، و در فاز دوم لپتوسپیروز کاملاً شایع.\n\n"
 "**چرا مننگوکوک رد می‌شود؟** چون در مننژیت باکتریال چرکی، CSF **نوتروفیلی با قند پایین و پروتئین بالا** دارد. ⚠️ **قند نرمال CSF عملاً مننژیت باکتریال را رد می‌کند** — این نکته‌ی طلایی سؤال است.\n\n"
 "**چرا سرخک نه؟** سرخک با کوریزا، سرفه، کونژنکتیویت و راش سرتاپایی می‌آید؛ ایکتر شدید و CPK بالا نمی‌دهد.\n\n"
 "**چرا تیفوئید نه؟** تیفوئید معمولاً **لکوپنی** می‌دهد نه لکوسیتوز، و ایکتر شدید با CPK ۳۰۰۰ نمی‌سازد.",
 "This question gathers the whole picture of severe leptospirosis into one patient. Let us read it piece by piece:\n\n"
 "THE EXPOSURE: a week after SWIMMING COMPETITIONS — freshwater contact, the most classical route.\n\n"
 "PHASE ONE: fever of 40, SEVERE CALF MYALGIA, headache.\n\n"
 "WARNING, 'FIVE DAYS LATER' is no accident; it marks the BIPHASIC COURSE. PHASE TWO: deep jaundice, neck stiffness and HAEMOPTYSIS.\n\n"
 "THE LABORATORY:\n\n"
 "LEUCOCYTOSIS OF 13,000 — against a viral illness\n"
 "PLATELETS 75,000 — thrombocytopenia\n"
 "ALT 175 with DEEP JAUNDICE — WARNING, jaundice OUT OF PROPORTION TO THE TRANSAMINASES\n"
 "CPK 3000 — WARNING, THE SIGNATURE OF MUSCLE INVOLVEMENT, explaining the calf myalgia\n\n"
 "AND NOW THE CSF: pleocytosis of 450 with mononuclear predominance, normal glucose and protein.\n\n"
 "WARNING: THAT IS THE CLASSICAL PATTERN OF ASEPTIC MENINGITIS, common in the second phase of leptospirosis.\n\n"
 "WHY IS MENINGOCOCCUS EXCLUDED? Because in pyogenic bacterial meningitis the CSF is NEUTROPHILIC WITH LOW GLUCOSE AND HIGH PROTEIN. WARNING: A NORMAL CSF GLUCOSE VIRTUALLY EXCLUDES BACTERIAL MENINGITIS — the golden point of this question.\n\n"
 "WHY NOT MEASLES? Measles brings coryza, cough, conjunctivitis and a cephalocaudal rash; it does not cause deep jaundice or a high CPK.\n\n"
 "WHY NOT TYPHOID? Typhoid usually gives LEUCOPENIA rather than leucocytosis, and does not produce deep jaundice with a CPK of 3000.",
 ["در مننژیت مننگوکوکی، مایع مغزی‌نخاعی نوتروفیلی با قند پایین دارد؛ اینجا لنفوسیتی با قند نرمال است.",
  "سرخک با کوریزا، سرفه و راش سرتاپایی می‌آید و ایکتر شدید و CPK سه هزار ایجاد نمی‌کند.",
  "تب تیفوئید معمولاً لکوپنی می‌دهد نه لکوسیتوز، و با هموپتزی و CPK بالا نمی‌خواند.",
  "پاسخ صحیح — شنا، میالژی ساق، سیر دوفازی، ایکتر با ترانس‌آمیناز پایین، هموپتزی و مننژیت آسپتیک: لپتوسپیروز."],
 ["In meningococcal meningitis the CSF is neutrophilic with a low glucose; here it is lymphocytic with normal glucose.",
  "Measles brings coryza, cough and a cephalocaudal rash, and does not cause deep jaundice or a CPK of three thousand.",
  "Typhoid usually causes leucopenia rather than leucocytosis and does not fit haemoptysis with a high CPK.",
  "Correct — swimming, calf myalgia, a biphasic course, jaundice with low transaminases, haemoptysis and aseptic meningitis: leptospirosis."],
 "**CSF لنفوسیتی با قند نرمال = آسپتیک**، نه باکتریال. **CPK بالا + ایکتر + شغل/تفریح آبی = لپتوسپیروز.**",
 "A lymphocytic CSF with normal glucose means aseptic, not bacterial. A high CPK with jaundice and water exposure means leptospirosis.",
 [H, WHO])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book21.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 21 lessons:', len(L))
