# -*- coding: utf-8 -*-
"""English stems and options for the batch-9 (urinary tract infection) questions.

Same discipline as EN1 and EN2: hand written, never machine translated, and
only for questions that already carry a hand-written bilingual lesson.
apply_en.py verifies that every multi-digit number in the Persian survives into
the English before attaching anything.

Rule 16 checked again: the ministry's bilingual booklets cover Esfand 1400 and
Khordad 1402; these items are from sittings 93-98, so no official translation
exists to reuse.
"""

EN3 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    assert all(o.strip() for o in options), idx
    EN3[idx] = {"stem_en": stem, "options_en": options}


add(507,
    "In which of the following does asymptomatic bacteriuria NOT require treatment?",
    ["Kidney transplant",
     "Pregnancy",
     "Urinary catheter",
     "Urologic instrumentation"])

add(506,
    "In which of the following does asymptomatic bacteriuria require antibiotic treatment?",
    ["A 25-year-old woman with a kidney stone",
     "A 73-year-old woman who needs urethral repair",
     "A 50-year-old patient with diabetes",
     "A 60-year-old patient with a kidney transplant one year ago"])

# The colony count prints as a bare "10" in the book: the superscript exponent
# was lost by the exporter. The English keeps the same bare 10 rather than
# inventing an exponent, so the number guard can still compare the two sides.
add(503,
    "You review an 82-year-old man who has an indwelling urinary catheter because of a stroke and "
    "urinary incontinence. He has no fever and no systemic symptoms, but his urine culture has "
    "grown E. coli with a colony count of 10. Urinalysis reports 4-5 white cells per HPF and "
    "abundant bacteria. Ultrasound of the kidneys and urinary tract is normal. Which action do you "
    "consider correct?",
    ["He requires antibiotic treatment for 14 days in any case",
     "Treatment is indicated if E. coli is cultured from a suprapubic aspirate",
     "Treatment is indicated if a repeat urine culture grows E. coli again",
     "He needs neither a repeat urine culture nor antibiotic treatment"])

add(500,
    "A young diabetic woman who had a urinalysis done for a pre-employment check-up presents to "
    "you. The results are: urinalysis RBC 25-30, many WBC; urine culture E. coli greater than 10 "
    "to the fifth; nitrite positive. She has no symptoms. What is the most appropriate action?",
    ["Start antibiotic treatment",
     "Repeat the urine culture",
     "Perform an ultrasound",
     "No specific action is needed"])

add(508,
    "A pregnant woman with no complaints of any kind presents with the results of her antenatal "
    "screening tests. Urinalysis shows pyuria and bacteriuria, and the urine culture shows growth "
    "of more than 100,000 colonies of E. coli. What is the appropriate action?",
    ["Treat the infection",
     "No specific action is needed",
     "Repeat the urine culture",
     "Perform an ultrasound of the urinary system"])

add(513,
    "A 25-year-old woman with no significant past medical history presents with dysuria and "
    "frequency since yesterday. On examination she has no fever, no tachycardia and no CVA "
    "tenderness. A dipstick test was performed and was positive for nitrite. What is the "
    "appropriate next action?",
    ["Urine culture",
     "Urinalysis",
     "Start empirical treatment",
     "Ultrasound of the urinary system"])

add(517,
    "A 25-year-old woman in the second month of pregnancy presents with dysuria and frequency for "
    "24 hours. On examination she is afebrile and has clear suprapubic pain. Urinalysis shows "
    "numerous leucocytes. What is the most appropriate management?",
    ["Urine culture and co-trimoxazole",
     "Urine culture and nitrofurantoin",
     "Cephalexin",
     "Ampicillin"])

add(525,
    "A 45-year-old woman with myasthenia gravis presents with fever and CVA tenderness and is to "
    "be treated empirically for probable pyelonephritis. All of the following antibiotics may be "
    "used EXCEPT",
    ["Ciprofloxacin",
     "Cefixime",
     "Co-trimoxazole",
     "Ampicillin"])
