# -*- coding: utf-8 -*-
"""Micro-lessons, batch 27 — empirical therapy, brain abscess and meningococcal
prophylaxis.

The second half of the central nervous system chapter. Three blocks, each with
one organising idea.

BLOCK ONE — EMPIRICAL ANTIBIOTICS (fifteen questions)
Every one of these is the same question: given this host, which organisms must
be covered? The regimen is assembled, not memorised:

    EVERYONE            ceftriaxone (or cefotaxime) PLUS vancomycin
    plus AMPICILLIN     if Listeria is possible: age over 50, pregnancy,
                        immunocompromise, alcoholism, neonates
    plus ACICLOVIR      if encephalitis is possible: altered consciousness,
                        seizures, focal deficit
    ceftazidime/cefepime instead of ceftriaxone after NEUROSURGERY, a SHUNT,
                        or in the NEUTROPENIC — because Pseudomonas must be
                        covered and ceftriaxone does not cover it

BLOCK TWO — BRAIN ABSCESS (four questions)
A focal lesion with a source. The source names the organisms and therefore the
regimen; the commonest source in these questions is sinusitis, dental infection
or chronic otitis, and all three seed ORAL ANAEROBES AND STREPTOCOCCI.

BLOCK THREE — MENINGOCOCCAL PROPHYLAXIS (twelve questions)
One organism, one list of contacts, three drugs. And the single fact the
examiners test hardest: WHICH DRUG IN PREGNANCY.

Reference: Tunkel AR et al., Clin Infect Dis 2004;39:1267; CDC — Meningococcal
Disease: Prophylaxis for Close Contacts; Harrison's Principles of Internal
Medicine, 21st ed (2022), Ch. 133 and Ch. 148 (Meningococcal Infections).
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


TUNKEL = ("Tunkel AR et al. — Practice Guidelines for the Management of Bacterial Meningitis. "
          "Clin Infect Dis 2004;39(9):1267-1284 (Infectious Diseases Society of America)")
CDCM = "CDC — Meningococcal Disease: Recommendations for Antimicrobial Chemoprophylaxis of Close Contacts"
H133 = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 133: Meningitis, "
        "Encephalitis, Brain Abscess and Empyema")
H148 = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 148: Meningococcal Infections"

EMP_FA = [
    "⚠️ **رژیم تجربی مننژیت را حفظ نکنید — بسازید. سه سؤال بپرسید و هر پاسخ یک دارو اضافه می‌کند.**",
    "**پایه‌ی ثابت برای همه: سفتریاکسون (یا سفوتاکسیم) + وانکومایسین.**",
    "**سفتریاکسون** ← پنوموکوک، مننگوکوک، هموفیلوس، و گرم‌منفی‌های روده‌ای.",
    "⚠️ **وانکومایسین چرا؟** فقط و فقط به‌خاطر **پنوموکوک مقاوم به سفالوسپورین**.",
    "در مناطقی با مقاومت بالا، سفتریاکسون به‌تنهایی ممکن است شکست بخورد.",
    "**سؤال یک — آیا لیستریا محتمل است؟ اگر بله، آمپی‌سیلین اضافه کنید.**",
    "⚠️ **پنج گروه در معرض لیستریا: سن بالای ۵۰، بارداری، نقص ایمنی، الکلیسم، نوزاد.**",
    "**چرا آمپی‌سیلین؟ چون سفالوسپورین‌ها روی لیستریا هیچ اثری ندارند** — یک مقاومت ذاتی.",
    "**سؤال دو — آیا انسفالیت محتمل است؟ اگر بله، آسیکلوویر اضافه کنید.**",
    "⚠️ **نشانه‌های انسفالیت: اختلال هوشیاری، تشنج، نقص فوکال، تغییر رفتار.**",
    "**چون انسفالیت هرپسی درمان‌پذیر است و تأخیر در آسیکلوویر مرگ‌ومیر را چند برابر می‌کند.**",
    "**سؤال سه — آیا پسودوموناس محتمل است؟ اگر بله، سفتریاکسون را عوض کنید.**",
    "⚠️ **سه موقعیت: پس از جراحی اعصاب، شانت بطنی، و بیمار نوتروپنیک.**",
    "**در این موارد سفتازیدیم یا سفپیم یا مروپنم جای سفتریاکسون می‌نشیند**،",
    "چون **سفتریاکسون پسودوموناس را نمی‌پوشاند**.",
    "**و یک نکته‌ی مهم درباره‌ی شکستگی قاعده‌ی جمجمه و نشت CSF:**",
    "⚠️ **در نشت CSF، ارگانیسم غالب همچنان پنوموکوک است، نه پسودوموناس** —",
    "چون باکتری از **فلور نازوفارنکس** وارد می‌شود، نه از محیط بیمارستان.",
    "**پس در تروما و نشت CSF، رژیم استاندارد سفتریاکسون + وانکومایسین کافی است.**",
]
EMP_EN = [
    "WARNING: DO NOT MEMORISE THE EMPIRICAL MENINGITIS REGIMEN — BUILD IT. Ask three questions; each answer adds a drug.",
    "THE FIXED BASE FOR EVERYONE: CEFTRIAXONE (or cefotaxime) PLUS VANCOMYCIN.",
    "CEFTRIAXONE covers pneumococcus, meningococcus, Haemophilus and enteric gram-negatives.",
    "WARNING, WHY VANCOMYCIN? Solely because of CEPHALOSPORIN-RESISTANT PNEUMOCOCCUS.",
    "In regions of high resistance, ceftriaxone alone may fail.",
    "QUESTION ONE — IS LISTERIA POSSIBLE? IF SO, ADD AMPICILLIN.",
    "WARNING, FIVE GROUPS AT RISK OF LISTERIA: AGE OVER 50, PREGNANCY, IMMUNOCOMPROMISE, ALCOHOLISM, NEONATES.",
    "WHY AMPICILLIN? BECAUSE CEPHALOSPORINS HAVE NO ACTIVITY AGAINST LISTERIA AT ALL — an intrinsic resistance.",
    "QUESTION TWO — IS ENCEPHALITIS POSSIBLE? IF SO, ADD ACICLOVIR.",
    "WARNING, THE SIGNS OF ENCEPHALITIS: altered consciousness, seizures, focal deficit, behavioural change.",
    "Because herpes encephalitis is treatable and delay in aciclovir multiplies mortality.",
    "QUESTION THREE — IS PSEUDOMONAS POSSIBLE? IF SO, REPLACE THE CEFTRIAXONE.",
    "WARNING, THREE SITUATIONS: AFTER NEUROSURGERY, A VENTRICULAR SHUNT, and THE NEUTROPENIC PATIENT.",
    "In these, CEFTAZIDIME OR CEFEPIME OR MEROPENEM replaces ceftriaxone,",
    "because CEFTRIAXONE DOES NOT COVER PSEUDOMONAS.",
    "AND AN IMPORTANT POINT ABOUT BASAL SKULL FRACTURE AND CSF LEAK:",
    "WARNING: IN A CSF LEAK THE DOMINANT ORGANISM IS STILL PNEUMOCOCCUS, NOT PSEUDOMONAS —",
    "because the bacterium enters from the NASOPHARYNGEAL FLORA, not from the hospital environment.",
    "SO IN TRAUMA WITH A CSF LEAK, THE STANDARD CEFTRIAXONE PLUS VANCOMYCIN IS SUFFICIENT.",
]

PROPH_FA = [
    "⚠️ **پروفیلاکسی مننگوکوک: سه سؤال — چه کسی، چه دارویی، و چرا فوریت دارد.**",
    "**چه کسی پروفیلاکسی می‌گیرد؟ فقط تماس‌های نزدیک و طولانی در ۷ روز پیش از شروع بیماری:**",
    "**هم‌خانه**، **هم‌اتاقی خوابگاه یا پادگان**، **مهدکودک**، **بوسیدن**، **اشتراک ظرف غذا**.",
    "⚠️ **و کادر درمان، فقط اگر با ترشحات تنفسی بیمار تماس مستقیم داشته‌اند:**",
    "**لوله‌گذاری، ساکشن، یا احیای دهان‌به‌دهان بدون ماسک.**",
    "**چه کسی نمی‌گیرد؟ هم‌کلاسی معمولی، هم‌کار، و کادری که فقط بیمار را ویزیت کرده.**",
    "**سه داروی مورد تأیید، و هر سه حدود ۹۰ تا ۹۵ درصد مؤثرند:**",
    "**ریفامپین ۶۰۰ میلی‌گرم هر ۱۲ ساعت، ۲ روز** (کودکان ۱۰ میلی‌گرم بر کیلوگرم).",
    "**سیپروفلوکساسین ۵۰۰ میلی‌گرم، تک‌دوز خوراکی** (بزرگسال).",
    "**سفتریاکسون ۲۵۰ میلی‌گرم، تک‌دوز عضلانی** (کودکان زیر ۱۵ سال: ۱۲۵ میلی‌گرم).",
    "⚠️ **و مهم‌ترین نکته‌ی امتحانی این بلوک: در بارداری، سفتریاکسون انتخاب اول است.**",
    "**چرا؟** ریفامپین در بارداری **توصیه نمی‌شود** و سیپروفلوکساسین هم ترجیح داده نمی‌شود؛",
    "**سفتریاکسون بی‌خطرترین گزینه در بارداری است و تک‌دوز هم هست.**",
    "⚠️ **دو نکته‌ی عملی درباره‌ی ریفامپین:** **ترشحات را نارنجی می‌کند**",
    "و **اثر قرص ضدبارداری خوراکی را کم می‌کند**.",
    "**پروفیلاکسی باید ظرف ۲۴ ساعت شروع شود؛ پس از ۱۴ روز فایده‌ای ندارد.**",
    "⚠️ **و خودِ بیمار هم پیش از ترخیص پروفیلاکسی می‌گیرد**، مگر با سفتریاکسون درمان شده باشد",
    "— چون پنی‌سیلین حامل نازوفارنژیال را ریشه‌کن نمی‌کند.",
    "**ایزولاسیون بیمار: قطرات تنفسی، تا ۲۴ ساعت پس از شروع آنتی‌بیوتیک مؤثر.**",
    "⚠️ **و برای پنوموکوک، سل و بروسلا پروفیلاکسی تماس لازم نیست** — فقط مننگوکوک (و هموفیلوس).",
]
PROPH_EN = [
    "WARNING: MENINGOCOCCAL PROPHYLAXIS — three questions: who, which drug, and why the urgency.",
    "WHO GETS PROPHYLAXIS? Only CLOSE AND PROLONGED CONTACTS in the 7 days before onset:",
    "HOUSEHOLD MEMBERS, DORMITORY OR BARRACKS ROOMMATES, NURSERY CONTACTS, KISSING, SHARED UTENSILS.",
    "WARNING, AND HEALTHCARE STAFF ONLY IF DIRECTLY EXPOSED TO RESPIRATORY SECRETIONS:",
    "INTUBATION, SUCTIONING, or MOUTH-TO-MOUTH RESUSCITATION WITHOUT A MASK.",
    "WHO DOES NOT? An ordinary classmate, a workmate, or staff who merely examined the patient.",
    "THREE APPROVED DRUGS, all about 90 to 95 per cent effective:",
    "RIFAMPICIN 600 MG EVERY 12 HOURS FOR 2 DAYS (children 10 mg/kg).",
    "CIPROFLOXACIN 500 MG AS A SINGLE ORAL DOSE (adults).",
    "CEFTRIAXONE 250 MG AS A SINGLE INTRAMUSCULAR DOSE (children under 15: 125 mg).",
    "WARNING, AND THE MOST TESTED POINT OF THIS BLOCK: IN PREGNANCY, CEFTRIAXONE IS FIRST CHOICE.",
    "WHY? Rifampicin IS NOT RECOMMENDED in pregnancy and ciprofloxacin is not preferred;",
    "CEFTRIAXONE IS THE SAFEST OPTION IN PREGNANCY and is a single dose besides.",
    "WARNING, TWO PRACTICAL POINTS ABOUT RIFAMPICIN: IT TURNS SECRETIONS ORANGE",
    "and IT REDUCES THE EFFECTIVENESS OF THE ORAL CONTRACEPTIVE PILL.",
    "PROPHYLAXIS SHOULD START WITHIN 24 HOURS; after 14 days it is of no value.",
    "WARNING, AND THE PATIENT HIMSELF RECEIVES PROPHYLAXIS BEFORE DISCHARGE unless treated with ceftriaxone",
    "— because penicillin does not eradicate nasopharyngeal carriage.",
    "PATIENT ISOLATION: DROPLET PRECAUTIONS until 24 hours of effective antibiotics.",
    "WARNING, AND NO CONTACT PROPHYLAXIS IS NEEDED FOR PNEUMOCOCCUS, TUBERCULOSIS OR BRUCELLA — only meningococcus (and Haemophilus).",
]

ABSCESS_FA = [
    "⚠️ **آبسه‌ی مغزی: منبع عفونت، ارگانیسم را نام می‌برد — و ارگانیسم، رژیم را می‌سازد.**",
    "**سه راه ورود را بشناسید:**",
    "**یک — گسترش مستقیم از یک کانون مجاور** (شایع‌ترین): سینوزیت، عفونت دندان، اوتیت مزمن.",
    "**دو — انتشار خونی**: از ریه، اندوکاردیت، یا شانت راست‌به‌چپ قلبی.",
    "**سه — تلقیح مستقیم**: تروما یا جراحی اعصاب.",
    "⚠️ **و محل آبسه، منبع را لو می‌دهد:**",
    "**سینوزیت فرونتال یا اتموئید ← لوب فرونتال.**",
    "**عفونت دندان ← لوب فرونتال یا تمپورال.**",
    "**اوتیت مزمن یا ماستوئیدیت ← لوب تمپورال یا مخچه.**",
    "**انتشار خونی ← ضایعات متعدد، اغلب در مرز خاکستری-سفید.**",
    "**ارگانیسم‌ها بر پایه‌ی منبع:**",
    "⚠️ **سینوزیت، دندان و اوتیت ← استرپتوکوک‌ها (به‌ویژه گروه میلری) + بی‌هوازی‌های دهانی.**",
    "**تروما و جراحی ← استافیلوکوک اورئوس و گرم‌منفی‌ها.**",
    "**پس رژیم تجربی برای منبع دهانی-سینوسی: سفتریاکسون + مترونیدازول.**",
    "**سفتریاکسون** استرپتوکوک‌ها را می‌گیرد و **مترونیدازول** بی‌هوازی‌ها را.",
    "⚠️ **در تروما یا جراحی، وانکومایسین هم اضافه می‌شود** (به‌خاطر استاف).",
    "**و نکته‌ی درمانی: آبسه‌ی بزرگ‌تر از ۲/۵ سانتی‌متر معمولاً تخلیه‌ی جراحی می‌خواهد.**",
    "**مدت درمان دارویی: ۶ تا ۸ هفته.**",
]
ABSCESS_EN = [
    "WARNING: IN BRAIN ABSCESS THE SOURCE NAMES THE ORGANISM — and the organism builds the regimen.",
    "KNOW THE THREE ROUTES OF ENTRY:",
    "ONE — DIRECT SPREAD FROM AN ADJACENT FOCUS (commonest): sinusitis, dental infection, chronic otitis.",
    "TWO — HAEMATOGENOUS SPREAD: from lung, endocarditis, or a right-to-left cardiac shunt.",
    "THREE — DIRECT INOCULATION: trauma or neurosurgery.",
    "WARNING, AND THE SITE OF THE ABSCESS BETRAYS THE SOURCE:",
    "FRONTAL OR ETHMOID SINUSITIS gives A FRONTAL LOBE abscess.",
    "DENTAL INFECTION gives A FRONTAL OR TEMPORAL abscess.",
    "CHRONIC OTITIS OR MASTOIDITIS gives A TEMPORAL LOBE OR CEREBELLAR abscess.",
    "HAEMATOGENOUS SPREAD gives MULTIPLE LESIONS, often at the grey-white junction.",
    "THE ORGANISMS BY SOURCE:",
    "WARNING: SINUSITIS, DENTAL AND OTITIC SOURCES MEAN STREPTOCOCCI (especially the milleri group) PLUS ORAL ANAEROBES.",
    "TRAUMA AND SURGERY MEAN STAPHYLOCOCCUS AUREUS AND GRAM-NEGATIVES.",
    "SO THE EMPIRICAL REGIMEN FOR AN ORAL OR SINUS SOURCE IS: CEFTRIAXONE PLUS METRONIDAZOLE.",
    "CEFTRIAXONE takes the streptococci and METRONIDAZOLE takes the anaerobes.",
    "WARNING, AFTER TRAUMA OR SURGERY, ADD VANCOMYCIN as well (for staph).",
    "AND A THERAPEUTIC POINT: AN ABSCESS LARGER THAN 2.5 CM USUALLY REQUIRES SURGICAL DRAINAGE.",
    "DURATION OF MEDICAL THERAPY: 6 TO 8 WEEKS.",
]


# =========================================================== book:171
add("book:171", "case", "medium",
 "تب + **کاهش هوشیاری** و امکان بررسی نیست ← **آسیکلوویر + سفتریاکسون + وانکومایسین**.",
 "Fever with ALTERED CONSCIOUSNESS and no investigations possible: ACICLOVIR PLUS CEFTRIAXONE PLUS VANCOMYCIN.",
 EMP_FA + [
  "جوان **۲۰ ساله**، تب و سردرد ناگهانی از دیروز، و **کاهش سطح هوشیاری** از امروز صبح.",
  "**صورت سؤال می‌گوید «امکان انجام اقدامات تشخیصی وجود ندارد»** — یعنی باید کورکورانه پوشش داد.",
  "**رژیم را با سه سؤال بسازید:**",
  "**پایه:** سفتریاکسون + وانکومایسین ← پنوموکوک (حتی مقاوم)، مننگوکوک، هموفیلوس.",
  "**سؤال یک — لیستریا؟** بیمار **۲۰ ساله و سالم** است: نه بالای ۵۰، نه باردار،",
  "نه نقص ایمنی، نه الکلی. ⚠️ **پس آمپی‌سیلین لازم نیست.**",
  "⚠️ **سؤال دو — انسفالیت؟ بله — کاهش سطح هوشیاری دارد.**",
  "**پس آسیکلوویر باید اضافه شود.**",
  "**چرا این‌قدر مهم است؟** چون انسفالیت هرپسی **تنها انسفالیت ویروسی درمان‌پذیر** است",
  "و **مرگ‌ومیرش بدون درمان بیش از ۷۰ درصد** است.",
  "**هزینه‌ی افزودن آسیکلوویر ناچیز است؛ هزینه‌ی نیفزودنش می‌تواند جان بیمار باشد.**",
  "**سؤال سه — پسودوموناس؟** نه جراحی، نه شانت، نه نوتروپنی ← **سفتریاکسون می‌ماند.**",
  "**پس پاسخ: آسیکلوویر + سفتریاکسون + وانکومایسین.**",
  "چرا گزینه‌ی «سفتریاکسون + وانکومایسین + آمپی‌سیلین» نه؟ **آسیکلوویر ندارد** و",
  "**آمپی‌سیلین در جوان سالم لازم نیست** — یعنی هم کم دارد و هم زیادی دارد.",
  "چرا «مروپنم + وانکومایسین» نه؟ باز هم **آسیکلوویر ندارد**، و مروپنم در مننژیت اکتسابی از جامعه",
  "**بیش از حد وسیع** است و بی‌جهت به مقاومت دامن می‌زند.",
 ],
 EMP_EN + [
  "A 20-YEAR-OLD with abrupt fever and headache since yesterday, and REDUCED CONSCIOUSNESS since this morning.",
  "The stem says 'no investigations are possible' — so cover must be given blind.",
  "BUILD THE REGIMEN WITH THE THREE QUESTIONS:",
  "THE BASE: ceftriaxone plus vancomycin — pneumococcus (even resistant), meningococcus, Haemophilus.",
  "QUESTION ONE — LISTERIA? The patient is 20 AND HEALTHY: not over 50, not pregnant,",
  "not immunocompromised, not alcoholic. WARNING, SO AMPICILLIN IS NOT NEEDED.",
  "WARNING, QUESTION TWO — ENCEPHALITIS? YES — he has REDUCED CONSCIOUSNESS.",
  "SO ACICLOVIR MUST BE ADDED.",
  "WHY does this matter so much? Because herpes encephalitis is THE ONLY TREATABLE VIRAL ENCEPHALITIS",
  "and ITS UNTREATED MORTALITY EXCEEDS 70 PER CENT.",
  "The cost of adding aciclovir is trivial; the cost of omitting it can be the patient's life.",
  "QUESTION THREE — PSEUDOMONAS? No surgery, no shunt, no neutropenia — CEFTRIAXONE STAYS.",
  "SO THE ANSWER IS: ACICLOVIR PLUS CEFTRIAXONE PLUS VANCOMYCIN.",
  "Why not 'ceftriaxone plus vancomycin plus ampicillin'? IT LACKS ACICLOVIR, and",
  "AMPICILLIN IS UNNECESSARY IN A HEALTHY YOUNG ADULT — it has too little and too much at once.",
  "Why not 'meropenem plus vancomycin'? Again NO ACICLOVIR, and meropenem in community-acquired meningitis",
  "IS NEEDLESSLY BROAD and drives resistance for no benefit.",
 ],
 "جوان **۲۰ ساله**، تب و سردرد ناگهانی از دیروز، و **کاهش سطح هوشیاری** از امروز صبح. و صورت سؤال صریح می‌گوید **«امکان انجام اقدامات تشخیصی وجود ندارد»** — یعنی باید بر پایه‌ی احتمالات پوشش داد.\n\n"
 "⚠️ **رژیم تجربی را حفظ نکنید؛ با سه سؤال بسازید:**\n\n"
 "**پایه‌ی ثابت: سفتریاکسون + وانکومایسین**\n"
 "سفتریاکسون ← پنوموکوک، مننگوکوک، هموفیلوس · وانکومایسین ← **پنوموکوک مقاوم به سفالوسپورین**\n\n"
 "**سؤال ۱ — آیا لیستریا محتمل است؟**\n"
 "پنج گروه در معرض‌اند: **بالای ۵۰ سال، بارداری، نقص ایمنی، الکلیسم، نوزاد**. این بیمار **۲۰ ساله و سالم** است ← ⚠️ **آمپی‌سیلین لازم نیست**.\n\n"
 "⚠️ **سؤال ۲ — آیا انسفالیت محتمل است؟ بله — کاهش سطح هوشیاری دارد.**\n"
 "**پس آسیکلوویر اضافه می‌شود.**\n\n"
 "**چرا این تصمیم این‌قدر مهم است؟** انسفالیت هرپسی **تنها انسفالیت ویروسی درمان‌پذیر** است و **مرگ‌ومیرش بدون درمان بیش از ۷۰ درصد** است. هزینه‌ی افزودن آسیکلوویر ناچیز است؛ هزینه‌ی نیفزودنش می‌تواند جان بیمار باشد. **در هر بیمار تب‌دار با اختلال هوشیاری یا تشنج، آسیکلوویر را اضافه کنید.**\n\n"
 "**سؤال ۳ — آیا پسودوموناس محتمل است؟**\n"
 "نه جراحی اعصاب، نه شانت، نه نوتروپنی ← **سفتریاکسون سر جایش می‌ماند**.\n\n"
 "**پس پاسخ: آسیکلوویر + سفتریاکسون + وانکومایسین.**\n\n"
 "**چرا گزینه‌های دیگر رد می‌شوند؟**\n\n"
 "«**سفتریاکسون + وانکومایسین + آمپی‌سیلین**» ← **آسیکلوویر ندارد** و **آمپی‌سیلین بی‌مورد دارد**؛ هم‌زمان هم کم دارد و هم زیادی.\n\n"
 "«**مروپنم + وانکومایسین**» ← باز هم **بدون آسیکلوویر**، و مروپنم در مننژیت اکتسابی از جامعه **بیش از حد وسیع** است.\n\n"
 "«**آسیکلوویر + وانکومایسین + آمپی‌سیلین**» ← ⚠️ **بدون سفالوسپورین**، یعنی **پوشش مننگوکوک و گرم‌منفی‌ها را ندارد** — خطای جدی‌تری از آنچه به نظر می‌رسد.",
 "A 20-YEAR-OLD with abrupt fever and headache since yesterday, and REDUCED CONSCIOUSNESS since this morning. The stem states explicitly that 'no investigations are possible' — so cover must be based on probabilities.\n\n"
 "WARNING: DO NOT MEMORISE THE EMPIRICAL REGIMEN; BUILD IT WITH THREE QUESTIONS:\n\n"
 "THE FIXED BASE: CEFTRIAXONE PLUS VANCOMYCIN\n"
 "Ceftriaxone covers pneumococcus, meningococcus, Haemophilus; vancomycin covers CEPHALOSPORIN-RESISTANT PNEUMOCOCCUS\n\n"
 "QUESTION 1 — IS LISTERIA POSSIBLE?\n"
 "Five groups are at risk: OVER 50, PREGNANCY, IMMUNOCOMPROMISE, ALCOHOLISM, NEONATES. This patient is 20 AND HEALTHY — WARNING, AMPICILLIN IS NOT NEEDED.\n\n"
 "WARNING, QUESTION 2 — IS ENCEPHALITIS POSSIBLE? YES — he has reduced consciousness.\n"
 "SO ACICLOVIR IS ADDED.\n\n"
 "WHY DOES THIS DECISION MATTER SO MUCH? Herpes encephalitis is THE ONLY TREATABLE VIRAL ENCEPHALITIS and its UNTREATED MORTALITY EXCEEDS 70 PER CENT. The cost of adding aciclovir is trivial; the cost of omitting it can be the patient's life. IN ANY FEBRILE PATIENT WITH ALTERED CONSCIOUSNESS OR SEIZURES, ADD ACICLOVIR.\n\n"
 "QUESTION 3 — IS PSEUDOMONAS POSSIBLE?\n"
 "No neurosurgery, no shunt, no neutropenia — CEFTRIAXONE STAYS.\n\n"
 "SO THE ANSWER IS: ACICLOVIR PLUS CEFTRIAXONE PLUS VANCOMYCIN.\n\n"
 "WHY DO THE OTHERS FAIL?\n\n"
 "'CEFTRIAXONE PLUS VANCOMYCIN PLUS AMPICILLIN' — IT LACKS ACICLOVIR and CONTAINS UNNECESSARY AMPICILLIN; too little and too much at once.\n\n"
 "'MEROPENEM PLUS VANCOMYCIN' — again NO ACICLOVIR, and meropenem is NEEDLESSLY BROAD in community-acquired meningitis.\n\n"
 "'ACICLOVIR PLUS VANCOMYCIN PLUS AMPICILLIN' — WARNING, NO CEPHALOSPORIN AT ALL, so NO COVER FOR MENINGOCOCCUS OR GRAM-NEGATIVES — a graver error than it looks.",
 ["بدون سفالوسپورین، پوشش مننگوکوک و گرم‌منفی‌ها وجود ندارد؛ خطای جدی در رژیم تجربی است.",
  "آسیکلوویر ندارد، در حالی که بیمار کاهش هوشیاری دارد؛ آمپی‌سیلین هم در جوان سالم لازم نیست.",
  "مروپنم در مننژیت اکتسابی از جامعه بیش از حد وسیع است و این رژیم آسیکلوویر هم ندارد.",
  "پاسخ صحیح — پایه‌ی سفتریاکسون و وانکومایسین، به‌علاوه‌ی آسیکلوویر به‌خاطر اختلال هوشیاری."],
 ["Without a cephalosporin there is no cover for meningococcus or gram-negatives — a serious error.",
  "It lacks aciclovir despite the reduced consciousness, and ampicillin is unnecessary in a healthy young adult.",
  "Meropenem is needlessly broad in community-acquired meningitis, and this regimen also lacks aciclovir.",
  "Correct — the ceftriaxone and vancomycin base, plus aciclovir because of the altered consciousness."],
 "**پایه: سفتریاکسون + وانکومایسین.** اختلال هوشیاری/تشنج ← **+ آسیکلوویر**. بالای ۵۰/باردار ← **+ آمپی‌سیلین**.",
 "Base: ceftriaxone plus vancomycin. Altered consciousness or seizures add aciclovir. Over 50 or pregnant adds ampicillin.",
 [TUNKEL, H133])


# =========================================================== book:180
add("book:180", "case", "medium",
 "**دیابتی ۶۰ ساله** ← لیستریا محتمل است ← **وانکومایسین + سفتریاکسون + آمپی‌سیلین**.",
 "A 60-YEAR-OLD DIABETIC means Listeria is possible: VANCOMYCIN PLUS CEFTRIAXONE PLUS AMPICILLIN.",
 EMP_FA + [
  "بیمار **۶۰ ساله‌ی دیابتی** با تب، سردرد و علائم تحریک مننژ، پیش از آماده شدن جواب CSF.",
  "**رژیم را با سه سؤال بسازید:**",
  "**پایه:** سفتریاکسون + وانکومایسین.",
  "⚠️ **سؤال یک — لیستریا؟ بله، و دو دلیل مستقل دارد:**",
  "**یک — سن بالای ۵۰ سال.** **دو — دیابت، که یک حالت نقص ایمنی نسبی است.**",
  "**پس آمپی‌سیلین اضافه می‌شود.**",
  "⚠️ **چرا آمپی‌سیلین و نه چیز دیگر؟ چون لیستریا به سفالوسپورین‌ها ذاتاً مقاوم است.**",
  "**این یک مقاومت ذاتی است، نه اکتسابی** — هیچ سفالوسپورینی، از هیچ نسلی، روی لیستریا کار نمی‌کند.",
  "**دلیل مولکولی‌اش: پروتئین متصل‌شونده به پنی‌سیلین نوع ۳ (PBP3) در لیستریا**",
  "**میل ترکیبی بسیار پایینی با سفالوسپورین‌ها دارد.**",
  "**پس اگر لیستریا را در نظر نگیرید و فقط سفتریاکسون بدهید، بیمار درمان‌نشده می‌ماند.**",
  "**لیستریا مونوسیتوژنز را بشناسید: باسیل گرم‌مثبت کوتاه، داخل‌سلولی، با تحرک چرخشی.**",
  "**از راه غذا منتقل می‌شود: لبنیات غیرپاستوریزه، پنیر نرم، گوشت آماده، سبزیجات خام.**",
  "⚠️ **و ویژگی منحصربه‌فردش: در دمای یخچال هم رشد می‌کند** (سرمادوست).",
  "**سؤال دو — انسفالیت؟** صورت سؤال اختلال هوشیاری یا تشنج ذکر نکرده ← آسیکلوویر لازم نیست.",
  "**سؤال سه — پسودوموناس؟** نه جراحی، نه شانت، نه نوتروپنی ← سفتریاکسون می‌ماند.",
  "**در آلرژی به پنی‌سیلین، جایگزین لیستریا کوتریموکسازول است.**",
 ],
 EMP_EN + [
  "A 60-YEAR-OLD DIABETIC with fever, headache and meningeal signs, before the CSF result is available.",
  "BUILD THE REGIMEN WITH THE THREE QUESTIONS:",
  "THE BASE: ceftriaxone plus vancomycin.",
  "WARNING, QUESTION ONE — LISTERIA? YES, and for two independent reasons:",
  "ONE — AGE OVER 50. TWO — DIABETES, which is a state of relative immunocompromise.",
  "SO AMPICILLIN IS ADDED.",
  "WARNING, WHY AMPICILLIN AND NOTHING ELSE? BECAUSE LISTERIA IS INTRINSICALLY RESISTANT TO CEPHALOSPORINS.",
  "This is INTRINSIC, not acquired resistance — no cephalosporin of any generation works against Listeria.",
  "The molecular reason: LISTERIA'S PENICILLIN-BINDING PROTEIN 3 (PBP3)",
  "HAS VERY LOW AFFINITY FOR CEPHALOSPORINS.",
  "So if you do not consider Listeria and give only ceftriaxone, the patient goes untreated.",
  "KNOW LISTERIA MONOCYTOGENES: a short gram-positive bacillus, intracellular, with tumbling motility.",
  "It is FOODBORNE: unpasteurised dairy, soft cheese, deli meats, raw vegetables.",
  "WARNING, AND ITS UNIQUE PROPERTY: IT GROWS AT REFRIGERATOR TEMPERATURE (it is psychrophilic).",
  "QUESTION TWO — ENCEPHALITIS? The stem mentions no altered consciousness or seizure — no aciclovir needed.",
  "QUESTION THREE — PSEUDOMONAS? No surgery, no shunt, no neutropenia — ceftriaxone stays.",
  "IN PENICILLIN ALLERGY, THE ALTERNATIVE FOR LISTERIA IS CO-TRIMOXAZOLE.",
 ],
 "بیمار **۶۰ ساله‌ی دیابتی** با تب، سردرد و علائم تحریک مننژ است، و باید پیش از آماده شدن جواب CSF درمان تجربی شروع شود.\n\n"
 "**رژیم را با سه سؤال بسازید:**\n\n"
 "**پایه: سفتریاکسون + وانکومایسین**\n\n"
 "⚠️ **سؤال ۱ — آیا لیستریا محتمل است؟ بله، و این بیمار دو دلیل مستقل دارد:**\n\n"
 "**۱. سن بالای ۵۰ سال** · **۲. دیابت** (یک حالت نقص ایمنی نسبی)\n\n"
 "**پس آمپی‌سیلین اضافه می‌شود.**\n\n"
 "⚠️ **و حالا مهم‌ترین نکته: چرا حتماً آمپی‌سیلین؟ چون لیستریا به سفالوسپورین‌ها ذاتاً مقاوم است.**\n\n"
 "این یک **مقاومت ذاتی** است، نه اکتسابی — یعنی **هیچ سفالوسپورینی، از هیچ نسلی، روی لیستریا کار نمی‌کند**. دلیل مولکولی‌اش این است که **پروتئین متصل‌شونده به پنی‌سیلین نوع ۳ (PBP3)** در لیستریا **میل ترکیبی بسیار پایینی با سفالوسپورین‌ها** دارد.\n\n"
 "**پیامد عملی:** اگر لیستریا را در نظر نگیرید و فقط سفتریاکسون + وانکومایسین بدهید، **بیمار عملاً درمان‌نشده می‌ماند** — و مرگ‌ومیر مننژیت لیستریایی بالاست.\n\n"
 "**لیستریا مونوسیتوژنز را بشناسید:** باسیل **گرم‌مثبت کوتاه**، **داخل‌سلولی**، با **تحرک چرخشی** مشخصه. از راه **غذا** منتقل می‌شود: لبنیات غیرپاستوریزه، پنیر نرم، گوشت آماده، سبزیجات خام. ⚠️ **و ویژگی منحصربه‌فردش: در دمای یخچال هم رشد می‌کند** — به همین دلیل غذای مانده در یخچال هم می‌تواند منبع باشد.\n\n"
 "**سؤال ۲ — انسفالیت؟** صورت سؤال اختلال هوشیاری یا تشنج ذکر نکرده ← **آسیکلوویر لازم نیست**.\n\n"
 "**سؤال ۳ — پسودوموناس؟** نه جراحی، نه شانت، نه نوتروپنی ← **سفتریاکسون می‌ماند**.\n\n"
 "**پس پاسخ: وانکومایسین + سفتریاکسون + آمپی‌سیلین.** و به یاد داشته باشید که در **آلرژی به پنی‌سیلین**، جایگزین پوشش لیستریا **کوتریموکسازول** است.",
 "A 60-YEAR-OLD DIABETIC with fever, headache and meningeal signs, needing empirical therapy before the CSF result.\n\n"
 "BUILD THE REGIMEN WITH THE THREE QUESTIONS:\n\n"
 "THE BASE: CEFTRIAXONE PLUS VANCOMYCIN\n\n"
 "WARNING, QUESTION 1 — IS LISTERIA POSSIBLE? YES, and this patient has TWO INDEPENDENT REASONS:\n\n"
 "1. AGE OVER 50 · 2. DIABETES (a state of relative immunocompromise)\n\n"
 "SO AMPICILLIN IS ADDED.\n\n"
 "WARNING, AND NOW THE KEY POINT: WHY AMPICILLIN SPECIFICALLY? BECAUSE LISTERIA IS INTRINSICALLY RESISTANT TO CEPHALOSPORINS.\n\n"
 "This is INTRINSIC, not acquired, resistance — NO CEPHALOSPORIN OF ANY GENERATION WORKS AGAINST LISTERIA. The molecular reason is that LISTERIA'S PENICILLIN-BINDING PROTEIN 3 (PBP3) HAS VERY LOW AFFINITY FOR CEPHALOSPORINS.\n\n"
 "THE PRACTICAL CONSEQUENCE: if you do not consider Listeria and give only ceftriaxone plus vancomycin, THE PATIENT IS EFFECTIVELY UNTREATED — and the mortality of listerial meningitis is high.\n\n"
 "KNOW LISTERIA MONOCYTOGENES: a SHORT GRAM-POSITIVE BACILLUS, INTRACELLULAR, with characteristic TUMBLING MOTILITY. It is FOODBORNE: unpasteurised dairy, soft cheese, deli meats, raw vegetables. WARNING, AND ITS UNIQUE PROPERTY: IT GROWS AT REFRIGERATOR TEMPERATURE — which is why food kept in a fridge can still be a source.\n\n"
 "QUESTION 2 — ENCEPHALITIS? The stem mentions no altered consciousness or seizure — NO ACICLOVIR NEEDED.\n\n"
 "QUESTION 3 — PSEUDOMONAS? No surgery, no shunt, no neutropenia — CEFTRIAXONE STAYS.\n\n"
 "SO THE ANSWER IS: VANCOMYCIN PLUS CEFTRIAXONE PLUS AMPICILLIN. And remember that in PENICILLIN ALLERGY the alternative for Listeria cover is CO-TRIMOXAZOLE.",
 ["سفتازیدیم برای پوشش پسودوموناس است، که اینجا مطرح نیست؛ و پوشش لیستریا هم ندارد.",
  "آمپی‌سیلین و جنتامایسین پوشش پنوموکوک مقاوم و مننگوکوک را فراهم نمی‌کند.",
  "پاسخ صحیح — سن بالای ۵۰ و دیابت یعنی لیستریا محتمل است؛ آمپی‌سیلین به پایه اضافه می‌شود.",
  "جنتامایسین در مننژیت نفوذ خوبی به CSF ندارد و جایگزین آمپی‌سیلین برای لیستریا نیست."],
 ["Ceftazidime is for Pseudomonas cover, not relevant here, and it does not cover Listeria.",
  "Ampicillin plus gentamicin does not cover resistant pneumococcus or meningococcus.",
  "Correct — age over 50 and diabetes make Listeria possible, so ampicillin is added to the base.",
  "Gentamicin penetrates the CSF poorly and does not substitute for ampicillin against Listeria."],
 "**لیستریا: بالای ۵۰، باردار، نقص ایمنی، الکلی، نوزاد ← آمپی‌سیلین.** سفالوسپورین **هرگز** لیستریا را نمی‌گیرد.",
 "Listeria: over 50, pregnant, immunocompromised, alcoholic, neonate — add ampicillin. Cephalosporins never cover Listeria.",
 [TUNKEL, H133])


# =========================================================== book:186
add("book:186", "case", "hard",
 "بیمار **نوتروپنیک پس از شیمی‌درمانی** ← پسودوموناس محتمل ← **آمپی‌سیلین + سفتازیدیم + وانکومایسین**.",
 "A NEUTROPENIC patient after chemotherapy needs Pseudomonas cover: AMPICILLIN PLUS CEFTAZIDIME PLUS VANCOMYCIN.",
 EMP_FA + [
  "بیمار **۵۹ ساله** با سابقه‌ی **شیمی‌درمانی به‌دنبال کانسر معده**، با تب، سردرد و سفتی گردن.",
  "⚠️ **و یافته‌ی کلیدی در آزمایش: WBC = ۱۰۰۰ با ۲۵٪ نوتروفیل.**",
  "**شمارش مطلق نوتروفیل را حساب کنید: ۱۰۰۰ × ۰٫۲۵ = ۲۵۰.**",
  "**یعنی بیمار به‌شدت نوتروپنیک است (ANC زیر ۵۰۰).**",
  "**حالا رژیم را با سه سؤال بسازید — و این بیمار به هر سه پاسخ مثبت می‌دهد:**",
  "**سؤال یک — لیستریا؟ بله، دو دلیل: سن بالای ۵۰، و نقص ایمنی شدید.** ← آمپی‌سیلین.",
  "⚠️ **سؤال سه — پسودوموناس؟ بله — نوتروپنی یکی از سه موقعیت کلاسیک است.**",
  "**پس سفتریاکسون باید با سفتازیدیم (یا سفپیم یا مروپنم) جایگزین شود.**",
  "**چرا؟ چون سفتریاکسون پسودوموناس را اصلاً نمی‌پوشاند** —",
  "و در بیمار نوتروپنیک، **پسودوموناس آئروژینوزا می‌تواند ظرف ساعت‌ها کشنده باشد**.",
  "**و وانکومایسین به‌عنوان پایه می‌ماند** (پنوموکوک مقاوم و استاف).",
  "**پس: آمپی‌سیلین + سفتازیدیم + وانکومایسین.**",
  "⚠️ **این سؤال آموزنده است چون نشان می‌دهد رژیم یک فرمول ثابت نیست، بلکه یک ساختار است.**",
  "**همان سه سؤال، در بیمار جوان سالم دو دارو می‌سازد و در این بیمار سه داروی متفاوت.**",
  "چرا «سفپیم + وانکومایسین» نه؟ سفپیم پسودوموناس را می‌گیرد، ⚠️ **ولی پوشش لیستریا ندارد**،",
  "و این بیمار **دو دلیل مستقل** برای لیستریا دارد.",
  "چرا «آمپی‌سیلین + سفوتاکسیم» نه؟ **نه پسودوموناس را می‌گیرد و نه پنوموکوک مقاوم را.**",
 ],
 EMP_EN + [
  "A 59-YEAR-OLD with a history of CHEMOTHERAPY FOR GASTRIC CANCER, with fever, headache and neck stiffness.",
  "WARNING, AND THE KEY LABORATORY FINDING: WBC = 1000 WITH 25% NEUTROPHILS.",
  "CALCULATE THE ABSOLUTE NEUTROPHIL COUNT: 1000 times 0.25 equals 250.",
  "SO THE PATIENT IS SEVERELY NEUTROPENIC (ANC below 500).",
  "NOW BUILD THE REGIMEN WITH THE THREE QUESTIONS — and this patient answers YES to all three:",
  "QUESTION ONE — LISTERIA? YES, for two reasons: age over 50, and severe immunocompromise. Add AMPICILLIN.",
  "WARNING, QUESTION THREE — PSEUDOMONAS? YES — neutropenia is one of the three classical situations.",
  "SO CEFTRIAXONE MUST BE REPLACED BY CEFTAZIDIME (or cefepime or meropenem).",
  "Why? BECAUSE CEFTRIAXONE DOES NOT COVER PSEUDOMONAS AT ALL —",
  "and in a neutropenic patient PSEUDOMONAS AERUGINOSA CAN KILL WITHIN HOURS.",
  "AND VANCOMYCIN REMAINS as part of the base (resistant pneumococcus and staph).",
  "SO: AMPICILLIN PLUS CEFTAZIDIME PLUS VANCOMYCIN.",
  "WARNING, THIS QUESTION IS INSTRUCTIVE BECAUSE IT SHOWS THE REGIMEN IS NOT A FIXED FORMULA BUT A STRUCTURE.",
  "The same three questions give two drugs in a healthy young adult and three different ones here.",
  "Why not 'cefepime plus vancomycin'? Cefepime covers Pseudomonas, WARNING, BUT IT DOES NOT COVER LISTERIA,",
  "and this patient has TWO INDEPENDENT REASONS for Listeria.",
  "Why not 'ampicillin plus cefotaxime'? IT COVERS NEITHER PSEUDOMONAS NOR RESISTANT PNEUMOCOCCUS.",
 ],
 "بیمار **۵۹ ساله** با سابقه‌ی **شیمی‌درمانی به‌دنبال کانسر معده**، با تب، سردرد و سفتی گردن مراجعه کرده است.\n\n"
 "⚠️ **و یافته‌ی کلیدی در آزمایش: WBC = ۱۰۰۰ با ۲۵٪ نوتروفیل.**\n\n"
 "**شمارش مطلق نوتروفیل (ANC) را حساب کنید:** ۱۰۰۰ × ۰٫۲۵ = **۲۵۰**\n\n"
 "**یعنی بیمار به‌شدت نوتروپنیک است** (ANC زیر ۵۰۰) — و این همه‌چیز را عوض می‌کند.\n\n"
 "**حالا رژیم را با سه سؤال بسازید. نکته‌ی آموزشی این سؤال این است که این بیمار به هر سه پاسخ می‌دهد:**\n\n"
 "**سؤال ۱ — لیستریا؟** ✅ **بله، دو دلیل:** سن بالای ۵۰، و **نقص ایمنی شدید** ← **آمپی‌سیلین**\n\n"
 "**سؤال ۲ — انسفالیت؟** اختلال هوشیاری ذکر نشده ← آسیکلوویر لازم نیست\n\n"
 "⚠️ **سؤال ۳ — پسودوموناس؟** ✅ **بله — نوتروپنی یکی از سه موقعیت کلاسیک است** (کنار جراحی اعصاب و شانت) ← **سفتازیدیم جای سفتریاکسون**\n\n"
 "**چرا این جایگزینی حیاتی است؟** چون **سفتریاکسون پسودوموناس را اصلاً نمی‌پوشاند**، و در بیمار نوتروپنیک **پسودوموناس آئروژینوزا می‌تواند ظرف ساعت‌ها کشنده باشد**.\n\n"
 "**و وانکومایسین به‌عنوان بخشی از پایه می‌ماند.**\n\n"
 "**پس پاسخ: آمپی‌سیلین + سفتازیدیم + وانکومایسین.**\n\n"
 "⚠️ **و درس بزرگ‌تر این سؤال:** رژیم تجربی یک **فرمول حفظ‌کردنی** نیست، یک **ساختار** است. همان سه سؤال، در جوان سالم **دو دارو** می‌سازد و در این بیمار **سه داروی کاملاً متفاوت**.\n\n"
 "**چرا گزینه‌های دیگر رد می‌شوند؟**\n\n"
 "«**سفپیم + وانکومایسین**» ← سفپیم پسودوموناس را می‌گیرد، ⚠️ **ولی پوشش لیستریا ندارد** و این بیمار دو دلیل مستقل برای لیستریا دارد.\n\n"
 "«**آمپی‌سیلین + سفوتاکسیم**» ← **نه پسودوموناس را می‌گیرد و نه پنوموکوک مقاوم را**.",
 "A 59-YEAR-OLD with a history of CHEMOTHERAPY FOR GASTRIC CANCER presents with fever, headache and neck stiffness.\n\n"
 "WARNING, AND THE KEY LABORATORY FINDING: WBC = 1000 WITH 25% NEUTROPHILS.\n\n"
 "CALCULATE THE ABSOLUTE NEUTROPHIL COUNT (ANC): 1000 times 0.25 equals 250\n\n"
 "SO THE PATIENT IS SEVERELY NEUTROPENIC (ANC below 500) — and that changes everything.\n\n"
 "NOW BUILD THE REGIMEN WITH THE THREE QUESTIONS. The instructive point is that this patient answers YES to all three:\n\n"
 "QUESTION 1 — LISTERIA? YES, for two reasons: age over 50 and SEVERE IMMUNOCOMPROMISE — add AMPICILLIN\n\n"
 "QUESTION 2 — ENCEPHALITIS? No altered consciousness is mentioned — no aciclovir needed\n\n"
 "WARNING, QUESTION 3 — PSEUDOMONAS? YES — NEUTROPENIA IS ONE OF THE THREE CLASSICAL SITUATIONS (alongside neurosurgery and a shunt) — CEFTAZIDIME REPLACES CEFTRIAXONE\n\n"
 "WHY IS THAT SUBSTITUTION VITAL? Because CEFTRIAXONE DOES NOT COVER PSEUDOMONAS AT ALL, and in a neutropenic patient PSEUDOMONAS AERUGINOSA CAN KILL WITHIN HOURS.\n\n"
 "AND VANCOMYCIN REMAINS as part of the base.\n\n"
 "SO THE ANSWER IS: AMPICILLIN PLUS CEFTAZIDIME PLUS VANCOMYCIN.\n\n"
 "WARNING, AND THE LARGER LESSON: the empirical regimen is not a FORMULA TO MEMORISE but a STRUCTURE. The same three questions give TWO drugs in a healthy young adult and THREE COMPLETELY DIFFERENT ones here.\n\n"
 "WHY DO THE OTHER OPTIONS FAIL?\n\n"
 "'CEFEPIME PLUS VANCOMYCIN' — cefepime covers Pseudomonas, WARNING, BUT IT DOES NOT COVER LISTERIA, and this patient has two independent reasons for Listeria.\n\n"
 "'AMPICILLIN PLUS CEFOTAXIME' — IT COVERS NEITHER PSEUDOMONAS NOR RESISTANT PNEUMOCOCCUS.",
 ["آمپی‌سیلین و سفوتاکسیم نه پسودوموناس را می‌پوشاند و نه پنوموکوک مقاوم به سفالوسپورین را.",
  "مروپنم و مترونیدازول و آمپی‌سیلین پوشش وانکومایسین برای پنوموکوک مقاوم را ندارد.",
  "سفپیم پسودوموناس را می‌گیرد ولی پوشش لیستریا ندارد، و این بیمار دو دلیل برای لیستریا دارد.",
  "پاسخ صحیح — نوتروپنی یعنی پوشش پسودوموناس، و سن بالای ۵۰ با نقص ایمنی یعنی پوشش لیستریا."],
 ["Ampicillin plus cefotaxime covers neither Pseudomonas nor cephalosporin-resistant pneumococcus.",
  "Meropenem with metronidazole and ampicillin lacks vancomycin cover for resistant pneumococcus.",
  "Cefepime covers Pseudomonas but not Listeria, and this patient has two reasons for Listeria.",
  "Correct — neutropenia means Pseudomonas cover, and age over 50 with immunocompromise means Listeria cover."],
 "**نوتروپنی/جراحی اعصاب/شانت ← سفتازیدیم یا سفپیم جای سفتریاکسون** (پسودوموناس).",
 "Neutropenia, neurosurgery or a shunt means ceftazidime or cefepime instead of ceftriaxone, for Pseudomonas.",
 [TUNKEL, H133])


# =========================================================== book:184
add("book:184", "case", "medium",
 "**اوتیت مزمن + آفازی و همی‌پارزی** ← آبسه‌ی مغزی ← **سفتریاکسون + مترونیدازول**.",
 "CHRONIC OTITIS with APHASIA AND HEMIPARESIS means a brain abscess: CEFTRIAXONE PLUS METRONIDAZOLE.",
 ABSCESS_FA + [
  "بیمار **۲۵ ساله** با سابقه‌ی **اوتیت مدیای مزمن**، با تب ۳۹، سردرد، **آفازی**",
  "و **کاهش قدرت اندام‌های راست**.",
  "⚠️ **نشانه‌های فوکال (آفازی + همی‌پارزی) تشخیص را از مننژیت به سمت ضایعه‌ی کانونی می‌برند.**",
  "**مننژیت التهاب منتشر پرده‌هاست و معمولاً نقص فوکال نمی‌سازد.**",
  "**نقص فوکال یعنی چیزی در پارانشیم مغز هست: آبسه، امپیم، یا انسفالیت.**",
  "**و منبع را همان‌جا داریم: اوتیت مدیای مزمن.**",
  "⚠️ **آفازی و همی‌پارزی راست ← ضایعه در نیمکره‌ی چپ ← و اوتیت مزمن دقیقاً به لوب تمپورال می‌زند.**",
  "**پس: آبسه‌ی مغزی لوب تمپورال چپ، با منبع اوتیک.**",
  "**حالا ارگانیسم‌ها را از منبع بخوانید:**",
  "**اوتیت مزمن ← استرپتوکوک‌ها (به‌ویژه گروه میلری) + بی‌هوازی‌های دهانی و حلقی.**",
  "**گاهی هم انتروباکتریاسه و پسودوموناس در اوتیت مزمن دخیل‌اند.**",
  "**رژیم: سفتریاکسون (استرپ و گرم‌منفی) + مترونیدازول (بی‌هوازی).**",
  "⚠️ **چرا مترونیدازول جدانشدنی است؟ چون بی‌هوازی‌ها در آبسه‌ی مغزی تقریباً همیشه حضور دارند**",
  "و **مترونیدازول نفوذ عالی به بافت مغز و داخل آبسه دارد**.",
  "چرا آسیکلوویر نه؟ **این ضایعه‌ی حلقوی با منبع اوتیک است، نه انسفالیت هرپسی.**",
  "**انسفالیت هرپسی تشنج و اختلال رفتار می‌دهد و در MRI درگیری تمپورال دوطرفه‌ی نکروزان دارد.**",
  "⚠️ **و نکته‌ی درمانی: آبسه‌ی بزرگ‌تر از ۲/۵ سانتی‌متر تخلیه‌ی جراحی می‌خواهد**،",
  "و **کانون اولیه (اینجا گوش میانی) هم باید درمان شود** وگرنه آبسه برمی‌گردد.",
 ],
 ABSCESS_EN + [
  "A 25-YEAR-OLD with a history of CHRONIC OTITIS MEDIA, with a fever of 39, headache, APHASIA",
  "and REDUCED POWER IN THE RIGHT LIMBS.",
  "WARNING: FOCAL SIGNS (aphasia plus hemiparesis) MOVE THE DIAGNOSIS FROM MENINGITIS TO A FOCAL LESION.",
  "Meningitis is a diffuse inflammation of the membranes and usually causes no focal deficit.",
  "A FOCAL DEFICIT MEANS SOMETHING IS IN THE BRAIN PARENCHYMA: abscess, empyema, or encephalitis.",
  "AND WE HAVE THE SOURCE RIGHT THERE: CHRONIC OTITIS MEDIA.",
  "WARNING: APHASIA AND RIGHT HEMIPARESIS MEAN A LEFT HEMISPHERE LESION — and chronic otitis strikes exactly the temporal lobe.",
  "SO: A LEFT TEMPORAL BRAIN ABSCESS OF OTITIC ORIGIN.",
  "NOW READ THE ORGANISMS FROM THE SOURCE:",
  "CHRONIC OTITIS MEANS STREPTOCOCCI (especially the milleri group) PLUS ORAL AND PHARYNGEAL ANAEROBES.",
  "Enterobacteriaceae and Pseudomonas are sometimes involved in chronic otitis too.",
  "THE REGIMEN: CEFTRIAXONE (strep and gram-negatives) PLUS METRONIDAZOLE (anaerobes).",
  "WARNING, WHY IS METRONIDAZOLE INSEPARABLE? BECAUSE ANAEROBES ARE ALMOST ALWAYS PRESENT IN A BRAIN ABSCESS",
  "and METRONIDAZOLE PENETRATES BRAIN TISSUE AND ABSCESS CAVITIES EXCELLENTLY.",
  "Why not aciclovir? THIS IS A RING LESION WITH AN OTITIC SOURCE, NOT HERPES ENCEPHALITIS.",
  "Herpes encephalitis gives seizures and behavioural change, with necrotising bitemporal involvement on MRI.",
  "WARNING, AND A THERAPEUTIC POINT: AN ABSCESS LARGER THAN 2.5 CM NEEDS SURGICAL DRAINAGE,",
  "and THE PRIMARY FOCUS (here the middle ear) MUST ALSO BE TREATED or the abscess returns.",
 ],
 "بیمار **۲۵ ساله** با سابقه‌ی **اوتیت مدیای مزمن**، با تب ۳۹ درجه، سردرد، **آفازی** و **کاهش قدرت اندام‌های راست**.\n\n"
 "⚠️ **اولین قدم فکری: نشانه‌های فوکال، تشخیص را از مننژیت دور می‌کنند.**\n\n"
 "**مننژیت التهاب منتشر پرده‌هاست و معمولاً نقص نورولوژیک فوکال نمی‌سازد.** وقتی **آفازی و همی‌پارزی** می‌بینید، یعنی چیزی در **خودِ پارانشیم مغز** هست: **آبسه، امپیم ساب‌دورال، یا انسفالیت**.\n\n"
 "**و منبع را در همان جمله‌ی اول داریم: اوتیت مدیای مزمن.**\n\n"
 "⚠️ **حالا آناتومی را بخوانید:** آفازی و همی‌پارزی **راست** ← ضایعه در **نیمکره‌ی چپ**. و **اوتیت مزمن با گسترش مستقیم دقیقاً به لوب تمپورال (یا مخچه) می‌زند** — همان سمت.\n\n"
 "**پس تشخیص: آبسه‌ی مغزی لوب تمپورال چپ، با منبع اوتیک.**\n\n"
 "**حالا ارگانیسم را از منبع بخوانید — این قاعده‌ی طلایی آبسه‌ی مغزی است:**\n\n"
 "**اوتیت مزمن، سینوزیت و عفونت دندان** ← **استرپتوکوک‌ها (به‌ویژه گروه میلری) + بی‌هوازی‌های دهانی و حلقی**\n"
 "**تروما و جراحی اعصاب** ← **استاف اورئوس و گرم‌منفی‌ها**\n\n"
 "**پس رژیم: سفتریاکسون + مترونیدازول.** سفتریاکسون استرپتوکوک‌ها و گرم‌منفی‌ها را می‌گیرد، و **مترونیدازول بی‌هوازی‌ها را**.\n\n"
 "⚠️ **چرا مترونیدازول جدانشدنی است؟** چون **بی‌هوازی‌ها در آبسه‌ی مغزی تقریباً همیشه حضور دارند** و مترونیدازول **نفوذ عالی به بافت مغز و داخل حفره‌ی آبسه** دارد — ویژگی‌ای که بسیاری از آنتی‌بیوتیک‌ها ندارند.\n\n"
 "**چرا آسیکلوویر نه؟** انسفالیت هرپسی با **تشنج و اختلال رفتار** می‌آید و در MRI **درگیری نکروزان لوب تمپورال** دارد، نه ضایعه‌ی حلقوی با منبع اوتیک.\n\n"
 "⚠️ **و دو نکته‌ی درمانی:** آبسه‌ی **بزرگ‌تر از ۲/۵ سانتی‌متر** معمولاً **تخلیه‌ی جراحی** می‌خواهد، و **کانون اولیه (اینجا گوش میانی) هم باید درمان شود** — وگرنه آبسه برمی‌گردد. **مدت درمان دارویی: ۶ تا ۸ هفته.**",
 "A 25-YEAR-OLD with a history of CHRONIC OTITIS MEDIA, with a fever of 39, headache, APHASIA and REDUCED POWER IN THE RIGHT LIMBS.\n\n"
 "WARNING, THE FIRST STEP IN REASONING: FOCAL SIGNS MOVE THE DIAGNOSIS AWAY FROM MENINGITIS.\n\n"
 "Meningitis is a diffuse inflammation of the membranes and usually causes NO FOCAL NEUROLOGICAL DEFICIT. When you see APHASIA AND HEMIPARESIS, something is in THE BRAIN PARENCHYMA ITSELF: an ABSCESS, a SUBDURAL EMPYEMA, or ENCEPHALITIS.\n\n"
 "AND THE SOURCE IS IN THE VERY FIRST SENTENCE: CHRONIC OTITIS MEDIA.\n\n"
 "WARNING, NOW READ THE ANATOMY: aphasia and RIGHT hemiparesis mean a LEFT HEMISPHERE lesion. And CHRONIC OTITIS SPREADS DIRECTLY TO EXACTLY THE TEMPORAL LOBE (or cerebellum) — on that same side.\n\n"
 "SO THE DIAGNOSIS IS: A LEFT TEMPORAL BRAIN ABSCESS OF OTITIC ORIGIN.\n\n"
 "NOW READ THE ORGANISM FROM THE SOURCE — this is the golden rule of brain abscess:\n\n"
 "CHRONIC OTITIS, SINUSITIS AND DENTAL INFECTION mean STREPTOCOCCI (especially the milleri group) PLUS ORAL AND PHARYNGEAL ANAEROBES\n"
 "TRAUMA AND NEUROSURGERY mean STAPH AUREUS AND GRAM-NEGATIVES\n\n"
 "SO THE REGIMEN IS CEFTRIAXONE PLUS METRONIDAZOLE. Ceftriaxone takes the streptococci and gram-negatives, and METRONIDAZOLE TAKES THE ANAEROBES.\n\n"
 "WARNING, WHY IS METRONIDAZOLE INSEPARABLE? Because ANAEROBES ARE ALMOST ALWAYS PRESENT IN A BRAIN ABSCESS, and metronidazole has EXCELLENT PENETRATION INTO BRAIN TISSUE AND THE ABSCESS CAVITY — a property many antibiotics lack.\n\n"
 "WHY NOT ACICLOVIR? Herpes encephalitis presents with SEIZURES AND BEHAVIOURAL CHANGE and shows NECROTISING TEMPORAL LOBE INVOLVEMENT on MRI, not a ring lesion with an otitic source.\n\n"
 "WARNING, AND TWO THERAPEUTIC POINTS: an abscess LARGER THAN 2.5 CM usually needs SURGICAL DRAINAGE, and THE PRIMARY FOCUS (here the middle ear) MUST ALSO BE TREATED — otherwise the abscess returns. DURATION OF MEDICAL THERAPY: 6 TO 8 WEEKS.",
 ["سفتریاکسون و مروپنم هر دو بتالاکتام‌اند و ترکیبشان منطقی نیست؛ ضمناً مروپنم اینجا بی‌جهت وسیع است.",
  "پاسخ صحیح — منبع اوتیک یعنی استرپتوکوک و بی‌هوازی؛ سفتریاکسون به‌همراه مترونیدازول هر دو را می‌پوشاند.",
  "آسیکلوویر برای انسفالیت هرپسی است، نه آبسه‌ی مغزی با منبع اوتیک و ضایعه‌ی حلقوی.",
  "آسیکلوویر و مروپنم نه با تشخیص می‌خواند و نه ترکیب منطقی برای آبسه‌ی با منبع دهانی است."],
 ["Ceftriaxone and meropenem are both beta-lactams and combining them is illogical; meropenem is needlessly broad here.",
  "Correct — an otitic source means streptococci and anaerobes; ceftriaxone plus metronidazole covers both.",
  "Aciclovir is for herpes encephalitis, not a brain abscess of otitic origin with a ring lesion.",
  "Aciclovir plus meropenem neither fits the diagnosis nor is a logical combination for an oral-source abscess."],
 "آبسه‌ی مغزی: **منبع ← ارگانیسم ← رژیم.** دهان/سینوس/گوش ← **سفتریاکسون + مترونیدازول**.",
 "Brain abscess: the source names the organism which builds the regimen. Oral, sinus or ear means ceftriaxone plus metronidazole.",
 [H133])


# =========================================================== book:199
add("book:199", "recall", "medium",
 "پروفیلاکسی مننگوکوک در **همسر باردار** ← **سفتریاکسون**، نه ریفامپین.",
 "Meningococcal prophylaxis for a PREGNANT SPOUSE is CEFTRIAXONE, not rifampicin.",
 PROPH_FA + [
  "این سؤال ساده به نظر می‌رسد ولی مهم‌ترین نکته‌ی کل بلوک پروفیلاکسی را می‌سنجد.",
  "**اول: آیا همسر بیمار اصلاً پروفیلاکسی لازم دارد؟ بله.**",
  "**هم‌خانه بودن، تعریف کلاسیک «تماس نزدیک» است** و خطر ابتلا در هم‌خانه‌ها",
  "**۵۰۰ تا ۸۰۰ برابر جمعیت عمومی** است.",
  "**دوم: کدام دارو؟ و اینجا بارداری همه‌چیز را تعیین می‌کند.**",
  "⚠️ **ریفامپین در بارداری توصیه نمی‌شود.**",
  "⚠️ **سیپروفلوکساسین هم در بارداری ترجیح داده نمی‌شود** (اثر بر غضروف در حال رشد).",
  "**پس می‌ماند سفتریاکسون — و دقیقاً به همین دلیل انتخاب اول بارداری است.**",
  "**سفتریاکسون ۲۵۰ میلی‌گرم، تک‌دوز عضلانی.**",
  "**سه مزیت دیگر سفتریاکسون که آن را در بارداری ایده‌آل می‌کند:**",
  "**یک — بی‌خطری شناخته‌شده در بارداری** (دسته‌ی B).",
  "**دو — تک‌دوز بودن، که مسئله‌ی پایبندی را حل می‌کند.**",
  "**سه — اثربخشی ۹۰ تا ۹۵ درصد، برابر با دو داروی دیگر.**",
  "⚠️ **و کوتریموکسازول چرا نه؟** سولفونامیدها در **سه‌ماهه‌ی سوم** خطر **کرن‌ایکتروس** دارند،",
  "و ضمناً کوتریموکسازول اصلاً جزو داروهای تأییدشده‌ی پروفیلاکسی مننگوکوک نیست.",
  "**نکته‌ی زمانی: پروفیلاکسی باید ظرف ۲۴ ساعت شروع شود.**",
  "**پس از ۱۴ روز از تماس، دیگر فایده‌ای ندارد.**",
 ],
 PROPH_EN + [
  "This question looks simple but tests the single most important point of the whole prophylaxis block.",
  "FIRST: DOES THE PATIENT'S WIFE NEED PROPHYLAXIS AT ALL? YES.",
  "LIVING IN THE SAME HOUSEHOLD IS THE CLASSICAL DEFINITION OF A CLOSE CONTACT, and household risk is",
  "500 TO 800 TIMES THAT OF THE GENERAL POPULATION.",
  "SECOND: WHICH DRUG? And here the pregnancy decides everything.",
  "WARNING: RIFAMPICIN IS NOT RECOMMENDED IN PREGNANCY.",
  "WARNING: CIPROFLOXACIN IS ALSO NOT PREFERRED IN PREGNANCY (effects on growing cartilage).",
  "SO CEFTRIAXONE REMAINS — and that is precisely why it is the first choice in pregnancy.",
  "CEFTRIAXONE 250 MG AS A SINGLE INTRAMUSCULAR DOSE.",
  "THREE FURTHER ADVANTAGES MAKE CEFTRIAXONE IDEAL IN PREGNANCY:",
  "ONE — ESTABLISHED SAFETY IN PREGNANCY (category B).",
  "TWO — A SINGLE DOSE, which removes the adherence problem.",
  "THREE — 90 TO 95 PER CENT EFFECTIVENESS, equal to the other two drugs.",
  "WARNING, AND WHY NOT CO-TRIMOXAZOLE? Sulphonamides risk KERNICTERUS IN THE THIRD TRIMESTER,",
  "and co-trimoxazole is not among the approved drugs for meningococcal prophylaxis at all.",
  "A TIMING POINT: PROPHYLAXIS SHOULD START WITHIN 24 HOURS.",
  "AFTER 14 DAYS FROM THE EXPOSURE IT IS OF NO VALUE.",
 ],
 "این سؤال ساده به نظر می‌رسد، ولی **مهم‌ترین نکته‌ی کل بلوک پروفیلاکسی** را می‌سنجد — و همین نکته چهار بار در این فصل پرسیده شده است.\n\n"
 "**سؤال اول: آیا همسر بیمار اصلاً پروفیلاکسی لازم دارد؟ بله.**\n\n"
 "**هم‌خانه بودن، تعریف کلاسیک «تماس نزدیک» است.** خطر ابتلا در هم‌خانه‌های یک بیمار مننگوکوکی، **۵۰۰ تا ۸۰۰ برابر جمعیت عمومی** است — پس این یک اقدام حیاتی است، نه احتیاط اضافی.\n\n"
 "**سؤال دوم: کدام دارو؟ و اینجا بارداری همه‌چیز را تعیین می‌کند.**\n\n"
 "**سه داروی تأییدشده‌ی پروفیلاکسی مننگوکوک:**\n\n"
 "**ریفامپین** ۶۰۰ mg هر ۱۲ ساعت، ۲ روز · **سیپروفلوکساسین** ۵۰۰ mg تک‌دوز · **سفتریاکسون** ۲۵۰ mg تک‌دوز عضلانی\n\n"
 "**هر سه حدود ۹۰ تا ۹۵ درصد مؤثرند. اما در بارداری:**\n\n"
 "⚠️ **ریفامپین توصیه نمی‌شود**\n"
 "⚠️ **سیپروفلوکساسین ترجیح داده نمی‌شود** (اثر احتمالی بر غضروف در حال رشد)\n\n"
 "**پس می‌ماند سفتریاکسون — و دقیقاً به همین دلیل انتخاب اول بارداری است.**\n\n"
 "**سه مزیت دیگر سفتریاکسون در این موقعیت:** **بی‌خطری شناخته‌شده در بارداری**، **تک‌دوز بودن** (که مسئله‌ی پایبندی را حل می‌کند)، و **اثربخشی برابر** با دو داروی دیگر.\n\n"
 "**چرا کوتریموکسازول نه؟** ⚠️ سولفونامیدها در **سه‌ماهه‌ی سوم** خطر **کرن‌ایکتروس** نوزاد دارند، و ضمناً کوتریموکسازول اصلاً **جزو داروهای تأییدشده‌ی پروفیلاکسی مننگوکوک نیست**.\n\n"
 "⚠️ **و دو نکته‌ی زمانی که جداگانه هم پرسیده می‌شوند:** پروفیلاکسی باید **ظرف ۲۴ ساعت** شروع شود، و **پس از ۱۴ روز از تماس دیگر فایده‌ای ندارد**.",
 "This question looks simple but tests THE SINGLE MOST IMPORTANT POINT of the whole prophylaxis block — and that point is asked four times in this chapter.\n\n"
 "FIRST QUESTION: DOES THE PATIENT'S WIFE NEED PROPHYLAXIS AT ALL? YES.\n\n"
 "LIVING IN THE SAME HOUSEHOLD IS THE CLASSICAL DEFINITION OF A CLOSE CONTACT. The risk in household members of a meningococcal case is 500 TO 800 TIMES that of the general population — so this is a vital measure, not an extra precaution.\n\n"
 "SECOND QUESTION: WHICH DRUG? And here the pregnancy decides everything.\n\n"
 "THE THREE APPROVED DRUGS FOR MENINGOCOCCAL PROPHYLAXIS:\n\n"
 "RIFAMPICIN 600 mg every 12 hours for 2 days · CIPROFLOXACIN 500 mg single dose · CEFTRIAXONE 250 mg single intramuscular dose\n\n"
 "ALL THREE ARE ABOUT 90 TO 95 PER CENT EFFECTIVE. BUT IN PREGNANCY:\n\n"
 "WARNING, RIFAMPICIN IS NOT RECOMMENDED\n"
 "WARNING, CIPROFLOXACIN IS NOT PREFERRED (possible effects on growing cartilage)\n\n"
 "SO CEFTRIAXONE REMAINS — and that is precisely why it is first choice in pregnancy.\n\n"
 "THREE FURTHER ADVANTAGES IN THIS SITUATION: ESTABLISHED SAFETY IN PREGNANCY, A SINGLE DOSE (which removes the adherence problem), and EQUAL EFFECTIVENESS to the other two.\n\n"
 "WHY NOT CO-TRIMOXAZOLE? WARNING, sulphonamides risk NEONATAL KERNICTERUS in the THIRD TRIMESTER, and co-trimoxazole is not among the approved drugs for meningococcal prophylaxis at all.\n\n"
 "WARNING, AND TWO TIMING POINTS ALSO ASKED SEPARATELY: prophylaxis should begin WITHIN 24 HOURS, and AFTER 14 DAYS FROM THE EXPOSURE IT IS OF NO VALUE.",
 ["ریفامپین در بارداری توصیه نمی‌شود و انتخاب اول برای همسر باردار نیست.",
  "سیپروفلوکساسین در بارداری ترجیح داده نمی‌شود، هرچند در غیرباردار تک‌دوز مناسبی است.",
  "پاسخ صحیح — سفتریاکسون تک‌دوز عضلانی، بی‌خطرترین گزینه‌ی پروفیلاکسی در بارداری است.",
  "کوتریموکسازول جزو داروهای تأییدشده‌ی پروفیلاکسی مننگوکوک نیست و در بارداری هم مشکل دارد."],
 ["Rifampicin is not recommended in pregnancy and is not first choice for a pregnant spouse.",
  "Ciprofloxacin is not preferred in pregnancy, although it is a suitable single dose otherwise.",
  "Correct — a single intramuscular dose of ceftriaxone is the safest prophylaxis in pregnancy.",
  "Co-trimoxazole is not an approved drug for meningococcal prophylaxis and is problematic in pregnancy."],
 "پروفیلاکسی مننگوکوک در **بارداری ← سفتریاکسون تک‌دوز**. ریفامپین و سیپرو کنار گذاشته می‌شوند.",
 "Meningococcal prophylaxis in pregnancy means a single dose of ceftriaxone. Rifampicin and ciprofloxacin are set aside.",
 [CDCM, H148])


# =========================================================== book:192
add("book:192", "recall", "easy",
 "فقط **مننژیت مننگوکوکی** پروفیلاکسی تماس لازم دارد — نه پنوموکوک، نه سل، نه بروسلا.",
 "Only MENINGOCOCCAL meningitis requires contact prophylaxis — not pneumococcus, tuberculosis or brucella.",
 PROPH_FA + [
  "این سؤال یک تمایز پایه‌ای را می‌سنجد که در عمل بارها به کار می‌آید.",
  "**چرا فقط مننگوکوک؟ سه ویژگی آن را از بقیه جدا می‌کند:**",
  "⚠️ **یک — انتقال مستقیم از فرد به فرد از راه قطرات تنفسی.**",
  "**پنوموکوک هم در حلق کلونیزه می‌شود، ولی بیماری تهاجمی‌اش از فرد به فرد منتقل نمی‌شود.**",
  "**سل هم منتقل می‌شود، ولی مننژیت سلی از فعال شدن عفونت خودِ بیمار می‌آید، نه از تماس.**",
  "**بروسلا اصلاً از انسان به انسان منتقل نمی‌شود.**",
  "⚠️ **دو — خطر بسیار بالای تماس نزدیک: ۵۰۰ تا ۸۰۰ برابر جمعیت عمومی.**",
  "**و موارد ثانویه معمولاً در همان روزهای اول رخ می‌دهند** — یعنی پنجره‌ی مداخله تنگ است.",
  "**سه — پروفیلاکسی مؤثر و در دسترس است** (۹۰ تا ۹۵ درصد ریشه‌کنی حامل).",
  "**پس هر سه شرط لازم برای پروفیلاکسی تماس فقط در مننگوکوک جمع می‌شوند.**",
  "⚠️ **و یک استثنای مهم که باید بدانید: هموفیلوس آنفولانزا تیپ b هم پروفیلاکسی دارد**",
  "— در خانواده‌هایی که کودک واکسینه‌نشده‌ی زیر ۴ سال دارند.",
  "**در پادگان و خوابگاه، خطر ویژه است چون تراکم جمعیت و تماس نزدیک طولانی وجود دارد.**",
  "**پس در این سؤال، تمام هم‌آسایشگاهی‌های سرباز باید پروفیلاکسی بگیرند.**",
  "⚠️ **و یادآوری: بیمار خودش هم پیش از ترخیص پروفیلاکسی می‌گیرد**،",
  "مگر با سفتریاکسون درمان شده باشد — چون **پنی‌سیلین حامل نازوفارنژیال را ریشه‌کن نمی‌کند**.",
 ],
 PROPH_EN + [
  "This question tests a basic distinction that comes up repeatedly in practice.",
  "WHY ONLY MENINGOCOCCUS? Three properties separate it from the rest:",
  "WARNING, ONE — DIRECT PERSON-TO-PERSON TRANSMISSION BY RESPIRATORY DROPLETS.",
  "Pneumococcus also colonises the throat, but its invasive disease does not pass from person to person.",
  "Tuberculosis is transmitted, but tuberculous meningitis arises from reactivation in the patient, not from contact.",
  "Brucella is not transmitted from human to human at all.",
  "WARNING, TWO — A VERY HIGH RISK IN CLOSE CONTACTS: 500 TO 800 TIMES THE GENERAL POPULATION.",
  "And secondary cases usually occur within the first days — so the window for intervention is narrow.",
  "THREE — EFFECTIVE, AVAILABLE PROPHYLAXIS EXISTS (90 to 95 per cent eradication of carriage).",
  "SO ALL THREE CONDITIONS FOR CONTACT PROPHYLAXIS ARE MET ONLY BY MENINGOCOCCUS.",
  "WARNING, AND AN IMPORTANT EXCEPTION TO KNOW: HAEMOPHILUS INFLUENZAE TYPE B ALSO HAS PROPHYLAXIS",
  "— in households containing an unvaccinated child under 4.",
  "IN BARRACKS AND DORMITORIES THE RISK IS PARTICULAR, because of crowding and prolonged close contact.",
  "SO IN THIS QUESTION ALL THE SOLDIER'S DORMITORY-MATES SHOULD RECEIVE PROPHYLAXIS.",
  "WARNING, AND A REMINDER: THE PATIENT HIMSELF RECEIVES PROPHYLAXIS BEFORE DISCHARGE,",
  "unless treated with ceftriaxone — because PENICILLIN DOES NOT ERADICATE NASOPHARYNGEAL CARRIAGE.",
 ],
 "این سؤال یک **تمایز پایه‌ای** را می‌سنجد که در عمل بارها به کار می‌آید: **کدام مننژیت‌ها پروفیلاکسی تماس لازم دارند؟**\n\n"
 "**پاسخ: فقط مننگوکوک (و با شرایطی، هموفیلوس آنفولانزا تیپ b).**\n\n"
 "⚠️ **چرا؟ سه شرط لازم است، و فقط مننگوکوک هر سه را دارد:**\n\n"
 "**شرط ۱ — انتقال مستقیم از فرد به فرد**\n\n"
 "مننگوکوک از راه **قطرات تنفسی** منتقل می‌شود و در نازوفارنکس کلونیزه می‌گردد.\n\n"
 "در مقابل: **پنوموکوک** هم در حلق کلونیزه می‌شود، ولی **بیماری تهاجمی‌اش از فرد به فرد منتقل نمی‌شود**. **مننژیت سلی** از **فعال شدن عفونت خودِ بیمار** می‌آید، نه از تماس مستقیم. و **بروسلا اصلاً از انسان به انسان منتقل نمی‌شود** — منبعش دام و لبنیات است.\n\n"
 "⚠️ **شرط ۲ — خطر بالای تماس نزدیک:** در هم‌خانه‌ها و هم‌اتاقی‌ها، خطر **۵۰۰ تا ۸۰۰ برابر** جمعیت عمومی است، و **موارد ثانویه معمولاً در همان روزهای اول** رخ می‌دهند.\n\n"
 "**شرط ۳ — پروفیلاکسی مؤثر و در دسترس:** هر سه داروی تأییدشده **۹۰ تا ۹۵ درصد** حامل را ریشه‌کن می‌کنند.\n\n"
 "**پس در این سؤال، تمام هم‌آسایشگاهی‌های سرباز باید پروفیلاکسی بگیرند** — چون پادگان دقیقاً همان محیط تراکم بالا و تماس نزدیک طولانی است که خطر را چند برابر می‌کند.\n\n"
 "⚠️ **و دو یادآوری مهم:**\n\n"
 "**هموفیلوس آنفولانزا تیپ b** هم پروفیلاکسی دارد، در خانواده‌هایی که **کودک واکسینه‌نشده‌ی زیر ۴ سال** دارند.\n\n"
 "**خودِ بیمار هم پیش از ترخیص پروفیلاکسی می‌گیرد**، مگر با **سفتریاکسون** درمان شده باشد — چون **پنی‌سیلین حامل نازوفارنژیال را ریشه‌کن نمی‌کند** و بیمار می‌تواند پس از ترخیص همچنان ناقل بماند.",
 "This question tests a BASIC DISTINCTION that comes up repeatedly in practice: WHICH MENINGITIDES REQUIRE CONTACT PROPHYLAXIS?\n\n"
 "THE ANSWER: only meningococcus (and, conditionally, Haemophilus influenzae type b).\n\n"
 "WARNING, WHY? THREE CONDITIONS ARE REQUIRED, AND ONLY MENINGOCOCCUS MEETS ALL THREE:\n\n"
 "CONDITION 1 — DIRECT PERSON-TO-PERSON TRANSMISSION\n\n"
 "Meningococcus spreads by RESPIRATORY DROPLETS and colonises the nasopharynx.\n\n"
 "By contrast: PNEUMOCOCCUS also colonises the throat, but ITS INVASIVE DISEASE DOES NOT PASS FROM PERSON TO PERSON. TUBERCULOUS MENINGITIS arises from REACTIVATION IN THE PATIENT, not from direct contact. And BRUCELLA IS NOT TRANSMITTED BETWEEN HUMANS AT ALL — its source is livestock and dairy.\n\n"
 "WARNING, CONDITION 2 — HIGH RISK IN CLOSE CONTACTS: among household members and roommates the risk is 500 TO 800 TIMES that of the general population, and SECONDARY CASES USUALLY OCCUR WITHIN THE FIRST DAYS.\n\n"
 "CONDITION 3 — EFFECTIVE, AVAILABLE PROPHYLAXIS: all three approved drugs eradicate carriage in 90 TO 95 PER CENT.\n\n"
 "SO IN THIS QUESTION ALL THE SOLDIER'S DORMITORY-MATES SHOULD RECEIVE PROPHYLAXIS — because barracks are exactly the crowded, prolonged-close-contact environment that multiplies the risk.\n\n"
 "WARNING, AND TWO IMPORTANT REMINDERS:\n\n"
 "HAEMOPHILUS INFLUENZAE TYPE B also has prophylaxis, in households containing an UNVACCINATED CHILD UNDER 4.\n\n"
 "THE PATIENT HIMSELF ALSO RECEIVES PROPHYLAXIS BEFORE DISCHARGE, unless treated with CEFTRIAXONE — because PENICILLIN DOES NOT ERADICATE NASOPHARYNGEAL CARRIAGE and the patient can remain a carrier after discharge.",
 ["بروسلا از انسان به انسان منتقل نمی‌شود؛ منبعش دام و لبنیات است و پروفیلاکسی تماس ندارد.",
  "پنوموکوک در حلق کلونیزه می‌شود ولی بیماری تهاجمی‌اش از فرد به فرد منتقل نمی‌شود.",
  "مننژیت سلی از فعال شدن عفونت خودِ بیمار می‌آید و پروفیلاکسی تماس برای آن تعریف نشده است.",
  "پاسخ صحیح — مننگوکوک با قطرات تنفسی منتقل می‌شود و تماس نزدیک خطر بسیار بالایی دارد."],
 ["Brucella is not transmitted between humans; its source is livestock and dairy, and no contact prophylaxis exists.",
  "Pneumococcus colonises the throat but its invasive disease does not pass from person to person.",
  "Tuberculous meningitis arises from reactivation in the patient, and contact prophylaxis is not defined for it.",
  "Correct — meningococcus spreads by respiratory droplets and close contacts are at very high risk."],
 "پروفیلاکسی تماس فقط برای **مننگوکوک** (و هموفیلوس b). **پنوموکوک، سل و بروسلا نه.**",
 "Contact prophylaxis is only for meningococcus (and Haemophilus b). Not pneumococcus, tuberculosis or brucella.",
 [CDCM, H148])


# =========================================================== book:167
add("book:167", "case", "medium",
 "**HIV + رنگ‌آمیزی مرکب هند مثبت** ← **کریپتوکوکوس نئوفورمنس**.",
 "HIV plus a POSITIVE INDIA INK stain means CRYPTOCOCCUS NEOFORMANS.",
 PROPH_FA[:0] + [
  "بیمار **HIV مثبت** با تب، سردرد، تهوع، استفراغ و **اختلال هوشیاری از سه هفته قبل**.",
  "⚠️ **دو سرنخ قاطع در این سؤال هست، و هر دو را باید ببینید:**",
  "**یک — سیر سه‌هفته‌ای در بیمار دچار نقص ایمنی** ← مننژیت مزمن، نه حاد.",
  "⚠️ **دو — رنگ‌آمیزی مرکب هند (India ink) مثبت** ← این عملاً تشخیصی است.",
  "**مرکب هند چه چیزی را نشان می‌دهد؟ کپسول پلی‌ساکاریدی ضخیم کریپتوکوکوس را.**",
  "**مرکب سلول‌های زمینه را سیاه می‌کند ولی وارد کپسول نمی‌شود**،",
  "**پس دور مخمر یک هاله‌ی روشن دیده می‌شود** — همان نمای کلاسیک.",
  "**حساسیتش در بیماران HIV حدود ۸۰ درصد است** (چون بار قارچی بالاست).",
  "**کریپتوکوکوس نئوفورمنس را بشناسید:**",
  "**مخمر کپسول‌دار، از راه استنشاق وارد می‌شود، منبعش فضولات پرندگان (به‌ویژه کبوتر) است.**",
  "⚠️ **در فرد سالم معمولاً بی‌علامت می‌ماند؛ در نقص ایمنی سلولی (به‌ویژه CD4 زیر ۱۰۰) منتشر می‌شود.**",
  "**پنل CSF مشخصه‌اش: افزایش مختصر سلول (لنفوسیتی)، قند پایین، پروتئین بالا.**",
  "⚠️ **و یک ویژگی حیاتی: فشار باز شدن CSF اغلب بسیار بالاست.**",
  "**درمان فشار بالا با LP مکرر، بخش جدانشدنی درمان است و مرگ‌ومیر را کم می‌کند.**",
  "**تست دقیق‌تر: آنتی‌ژن کریپتوکوکی (CrAg) در CSF یا سرم — حساسیت بالای ۹۵ درصد.**",
  "**درمان: آمفوتریسین B + فلوسیتوزین (القا)، سپس فلوکونازول (تحکیم و نگهداری).**",
 ],
 PROPH_EN[:0] + [
  "An HIV-POSITIVE patient with fever, headache, nausea, vomiting and ALTERED CONSCIOUSNESS FOR THREE WEEKS.",
  "WARNING, THERE ARE TWO DECISIVE CLUES HERE AND YOU MUST SEE BOTH:",
  "ONE — A THREE-WEEK COURSE IN AN IMMUNOCOMPROMISED PATIENT — chronic, not acute, meningitis.",
  "WARNING, TWO — A POSITIVE INDIA INK STAIN — this is effectively diagnostic.",
  "WHAT DOES INDIA INK SHOW? THE THICK POLYSACCHARIDE CAPSULE OF CRYPTOCOCCUS.",
  "The ink blackens the background but CANNOT ENTER THE CAPSULE,",
  "SO A BRIGHT HALO APPEARS AROUND THE YEAST — the classical appearance.",
  "Its sensitivity in HIV patients is about 80 per cent (because the fungal burden is high).",
  "KNOW CRYPTOCOCCUS NEOFORMANS:",
  "AN ENCAPSULATED YEAST, ACQUIRED BY INHALATION, its source being BIRD DROPPINGS (especially pigeons).",
  "WARNING: IN A HEALTHY PERSON IT USUALLY STAYS SILENT; IN CELLULAR IMMUNODEFICIENCY (especially CD4 below 100) IT DISSEMINATES.",
  "ITS CHARACTERISTIC CSF PANEL: a mild lymphocytic pleocytosis, LOW GLUCOSE, HIGH PROTEIN.",
  "WARNING, AND A CRITICAL FEATURE: THE CSF OPENING PRESSURE IS OFTEN VERY HIGH.",
  "Managing that pressure with REPEATED LUMBAR PUNCTURES is an inseparable part of treatment and reduces mortality.",
  "A MORE ACCURATE TEST: THE CRYPTOCOCCAL ANTIGEN (CrAg) in CSF or serum — sensitivity above 95 per cent.",
  "TREATMENT: AMPHOTERICIN B PLUS FLUCYTOSINE (induction), then FLUCONAZOLE (consolidation and maintenance).",
 ],
 "بیمار **HIV مثبت** با تب، سردرد، تهوع، استفراغ و **اختلال هوشیاری از سه هفته قبل** مراجعه کرده است.\n\n"
 "⚠️ **دو سرنخ قاطع در این سؤال هست:**\n\n"
 "**۱. سیر سه‌هفته‌ای در بیمار دچار نقص ایمنی** ← این **مننژیت مزمن** است، نه حاد. و در بیمار HIV مثبت، مننژیت مزمن یعنی: **کریپتوکوکوس، سل، سیفلیس، یا لنفوم**.\n\n"
 "⚠️ **۲. رنگ‌آمیزی مرکب هند (India ink) مثبت** ← این عملاً تشخیصی است.\n\n"
 "**مرکب هند چه چیزی را نشان می‌دهد؟** **کپسول پلی‌ساکاریدی ضخیم کریپتوکوکوس** را. مرکب، زمینه را سیاه می‌کند ولی **نمی‌تواند وارد کپسول شود**، پس دور مخمر یک **هاله‌ی روشن** دیده می‌شود. در بیماران HIV حساسیتش حدود **۸۰ درصد** است، چون بار قارچی بالاست.\n\n"
 "**کریپتوکوکوس نئوفورمنس را بشناسید:** مخمر **کپسول‌دار**، از راه **استنشاق** وارد می‌شود، و منبعش **فضولات پرندگان (به‌ویژه کبوتر)** است. ⚠️ **در فرد سالم معمولاً بی‌علامت می‌ماند؛ در نقص ایمنی سلولی — به‌ویژه CD4 زیر ۱۰۰ — منتشر می‌شود** و به مننژ می‌رسد.\n\n"
 "**پنل CSF مشخصه:** افزایش **مختصر** سلول با غلبه‌ی لنفوسیت، **قند پایین**، **پروتئین بالا** — دقیقاً همان که صورت سؤال توصیف کرده.\n\n"
 "⚠️ **و یک ویژگی حیاتی که فراموش می‌شود: فشار باز شدن CSF اغلب بسیار بالاست.** مدیریت این فشار با **LP مکرر** بخش **جدانشدنی** درمان است و **مرگ‌ومیر را کاهش می‌دهد** — این نکته‌ای است که بسیاری از دانشجویان نمی‌دانند.\n\n"
 "**تست دقیق‌تر از مرکب هند: آنتی‌ژن کریپتوکوکی (CrAg)** در CSF یا سرم، با حساسیت بالای **۹۵ درصد**.\n\n"
 "**درمان:** **آمفوتریسین B + فلوسیتوزین** برای القا، سپس **فلوکونازول** برای تحکیم و نگهداری.",
 "An HIV-POSITIVE patient presents with fever, headache, nausea, vomiting and ALTERED CONSCIOUSNESS FOR THREE WEEKS.\n\n"
 "WARNING, THERE ARE TWO DECISIVE CLUES:\n\n"
 "1. A THREE-WEEK COURSE IN AN IMMUNOCOMPROMISED PATIENT — this is CHRONIC meningitis, not acute. And in an HIV-positive patient, chronic meningitis means CRYPTOCOCCUS, TUBERCULOSIS, SYPHILIS OR LYMPHOMA.\n\n"
 "WARNING, 2. A POSITIVE INDIA INK STAIN — this is effectively diagnostic.\n\n"
 "WHAT DOES INDIA INK SHOW? THE THICK POLYSACCHARIDE CAPSULE OF CRYPTOCOCCUS. The ink blackens the background but CANNOT ENTER THE CAPSULE, so A BRIGHT HALO appears around the yeast. In HIV patients its sensitivity is about 80 PER CENT, because the fungal burden is high.\n\n"
 "KNOW CRYPTOCOCCUS NEOFORMANS: an ENCAPSULATED YEAST, acquired by INHALATION, whose source is BIRD DROPPINGS (especially pigeons). WARNING: IN A HEALTHY PERSON IT USUALLY REMAINS SILENT; IN CELLULAR IMMUNODEFICIENCY — especially CD4 below 100 — IT DISSEMINATES and reaches the meninges.\n\n"
 "THE CHARACTERISTIC CSF PANEL: a MILD lymphocytic pleocytosis, LOW GLUCOSE, HIGH PROTEIN — exactly what the stem describes.\n\n"
 "WARNING, AND A CRITICAL FEATURE THAT IS OFTEN FORGOTTEN: THE CSF OPENING PRESSURE IS OFTEN VERY HIGH. Managing that pressure with REPEATED LUMBAR PUNCTURES is an INSEPARABLE part of treatment and REDUCES MORTALITY — a point many students do not know.\n\n"
 "A MORE ACCURATE TEST THAN INDIA INK: THE CRYPTOCOCCAL ANTIGEN (CrAg) in CSF or serum, with sensitivity above 95 PER CENT.\n\n"
 "TREATMENT: AMPHOTERICIN B PLUS FLUCYTOSINE for induction, then FLUCONAZOLE for consolidation and maintenance.",
 ["کاندیدا در رنگ‌آمیزی مرکب هند هاله‌ی کپسولی نشان نمی‌دهد و عامل شایع مننژیت مزمن HIV نیست.",
  "مننژیت سلی هم در HIV مطرح است ولی مرکب هند در آن منفی است؛ تشخیصش با کشت و PCR است.",
  "پاسخ صحیح — مرکب هند مثبت یعنی کپسول کریپتوکوکوس، شایع‌ترین مننژیت قارچی در HIV.",
  "کوکسیدیوئیدس ایمیتیس در ایران بومی نیست و در مرکب هند هاله‌ی کپسولی نشان نمی‌دهد."],
 ["Candida shows no capsular halo on India ink and is not a common cause of chronic meningitis in HIV.",
  "Tuberculous meningitis is also considered in HIV, but India ink is negative; diagnosis is by culture and PCR.",
  "Correct — a positive India ink means the cryptococcal capsule, the commonest fungal meningitis in HIV.",
  "Coccidioides immitis is not endemic in Iran and shows no capsular halo on India ink."],
 "**مرکب هند مثبت = کریپتوکوکوس.** **فشار بالای CSF را با LP مکرر مدیریت کنید** — بخشی از درمان است.",
 "A positive India ink means Cryptococcus. Manage the high CSF pressure with repeated lumbar punctures; it is part of the treatment.",
 [H133])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book27.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 27 lessons:', len(L))
