# -*- coding: utf-8 -*-
"""Correct the printed key of book question idx 382 (tetanus prophylaxis).

The question
------------
A 31-year-old man with a COMPLETE tetanus vaccination history, last dose at age
20, is admitted after a road accident with an extensive thigh laceration. What
do you recommend for tetanus prophylaxis?

The book answers "TIG and toxoid". That is wrong, and every authority agrees:

  * Harrison's 21e, Table 304-1 ("Guide to Tetanus Prophylaxis in Routine Wound
    Management") puts **No** in the TIG column for a history of >=3 doses, for
    BOTH "clean minor wounds" and "all other wounds".

  * CDC/ACIP, Clinical Guidance for Wound Management to Prevent Tetanus, lists
    the TIG indications exhaustively: unknown vaccination history, never
    vaccinated, incomplete primary series, HIV, severe immunodeficiency. A
    completed primary series appears on none of them.

The arithmetic still matters and is the other half of the question: last dose at
20, now 31, so eleven years have elapsed. For a dirty wound the booster
threshold is five years, so a toxoid dose IS due. The correct answer is
therefore **toxoid alone** — not the book's TIG-plus-toxoid.

Why the book is wrong is worth stating, because it is a reasoning error a
student can make too: a dramatic wound feels like it should demand the maximum
intervention. But passive immunity substitutes for immune memory, and this
patient has memory. After a booster he raises protective antitoxin within days
through an anamnestic response. TIG would add cost, an injection and a small
risk while duplicating what his own immune system does faster.

The change is never silent. The question keeps `original_correct_index`, a
bilingual justification, a cited source, and the lesson opens by telling the
student the printed key was corrected, so nobody is confused when their copy of
the book disagrees.
"""
import json, io, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
TARGET_NO = 9382

FA = ('کلید چاپی کتاب «تتابولین و توکسوئید» است، ولی جدول ۳۰۴-۱ هریسون و راهنمای CDC '
      'هر دو تصریح می‌کنند که با سابقه‌ی واکسیناسیون کامل (سه دوز یا بیشتر) تتابولین '
      '«در هیچ نوع زخمی» اندیکاسیون ندارد. TIG فقط برای سابقه‌ی نامعلوم، کمتر از سه دوز، '
      'HIV یا نقص ایمنی شدید است. از آخرین دوز این بیمار ۱۱ سال گذشته و در زخم کثیف آستانه '
      '۵ سال است، پس یک دوز توکسوئید یادآور لازم است — ولی فقط توکسوئید.')
EN = ("The book prints 'TIG and toxoid', but Harrison's Table 304-1 and CDC guidance both state "
      "that with a complete vaccination history (three or more doses) TIG is not indicated for "
      "ANY wound type. TIG is reserved for unknown history, fewer than three doses, HIV or severe "
      "immunodeficiency. Eleven years have passed since this patient's last dose and the "
      "dirty-wound threshold is five years, so a booster toxoid dose is required — but toxoid alone.")
SRC = ("Harrison's Principles of Internal Medicine, 21st ed (2022), Table 304-1; "
       "CDC — Clinical Guidance for Wound Management to Prevent Tetanus (ACIP)")


def main():
    for i in range(1, 6):
        p = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        if not os.path.exists(p):
            continue
        body = json.load(io.open(p, encoding='utf-8'))
        changed = False
        for q in body['questions']:
            if q.get('question_no') != TARGET_NO:
                continue

            # Locate the toxoid-only option by its TEXT rather than by a fixed
            # index, so a reordering of the payload can never silently point
            # this correction at the wrong answer.
            idx = None
            for j, o in enumerate(q['options_fa']):
                txt = re.sub(r'\s+', '', o)
                if 'توکسوئید' in txt and 'تتابولین' not in txt:
                    if idx is not None:
                        sys.exit('option match is ambiguous; aborting')
                    idx = j
            if idx is None:
                sys.exit('could not identify the toxoid-only option; aborting')

            if q.get('key_corrected') and q['correct_index'] == idx:
                print('already corrected')
                return

            q['original_correct_index'] = q['correct_index']
            q['correct_index'] = idx
            q['key_corrected'] = True
            q['key_correction_fa'] = FA
            q['key_correction_en'] = EN
            q['key_correction_source'] = SRC
            changed = True
            print(f'q{TARGET_NO}: key {q["original_correct_index"]} -> {idx} '
                  f'({q["options_fa"][idx].strip()})')
        if changed:
            json.dump(body, io.open(p, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)


if __name__ == '__main__':
    main()
