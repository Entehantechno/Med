# -*- coding: utf-8 -*-
"""Micro-lessons, batch 16 — cholera, shigella and C. difficile treatment.

The second half of the diarrhoea chapter. Where batch 15 taught the two-box
split and the food-poisoning clock, this batch teaches the three treatment
blocks the chapter returns to again and again.

1. CHOLERA IS DIAGNOSED CLINICALLY AND TREATED WITH FLUID. Eight questions
   describe the same patient — sudden, high-volume, rice-water stool, no fever,
   muscle cramps, collapse — and ask either the organism, the transport medium,
   the culture medium, or the drug. The one point that unites them: the
   antibiotic is an afterthought that shortens the illness by a day, while the
   FLUID is what saves the life.

2. AZITHROMYCIN IS THE PREGNANCY ANSWER. Six of this chapter's cholera
   questions specify a pregnant patient, and every one of them is answered by
   knowing which antibiotics are unsafe in pregnancy rather than by knowing
   anything about cholera.

3. C. DIFFICILE SEVERITY DRIVES THE DRUG. The book is internally consistent
   here: metronidazole for mild disease, vancomycin for severe. Modern guidance
   has moved on, and the lessons say so — but they teach the classical rule the
   printed keys follow, because a student who answers with the 2021 guideline
   would be marked wrong on this paper.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022),
Chapters 133 (C. difficile), 161 (Shigella), 163 (cholera); IDSA/SHEA 2021.
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H133 = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 133"
H161 = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 161"
H163 = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 163"
IDSA = "IDSA/SHEA Clinical Practice Guidelines for C. difficile (2021 focused update)"
WHO = "WHO — Cholera: Treatment and Management"

# The cholera picture, repeated verbatim in every cholera lesson.
CHOL_FA = [
    "**وبا (کلرا)** تابلوی چنان مشخصی دارد که تشخیصش **بالینی** است، نه آزمایشگاهی.",
    "**شروع ناگهانی** — بیمار می‌تواند ساعت دقیق شروع را بگوید.",
    "**حجم عظیم** — تا ۲۰ لیتر در روز؛ بیمار می‌تواند در چند ساعت به شوک برود.",
    "**مدفوع آب برنجی (rice water)**: آبکی، کدر، خاکستری، با پرزهای موکوسی شناور.",
    "**بوی ماهی گندیده** — نه بوی مدفوع معمولی.",
    "⚠️ **بدون تب** — چون کلرا **تهاجم نمی‌کند**، فقط توکسین ترشح می‌کند.",
    "⚠️ **بدون درد شکم و بدون تنسموس** — به همان دلیل.",
    "**کرامپ عضلانی** — از هیپوکالمی و از دست رفتن الکترولیت.",
    "**استفراغ** شایع است و در ساعات اول شروع می‌شود.",
    "آزمایش مدفوع: ⚠️ **بدون گلبول سفید و قرمز** — مهر تأیید غیرالتهابی بودن.",
    "سازوکار: **توکسین کلرا** زیرواحد A را وارد سلول می‌کند ← فعال شدن آدنیلات‌سیکلاز ← **cAMP بالا**.",
    "cAMP بالا کانال CFTR را باز نگه می‌دارد ← **ترشح انبوه کلر و به دنبالش آب**.",
    "⚠️ و نکته‌ی حیاتی: **جذب سدیم-گلوکز دست‌نخورده می‌ماند** — پایه‌ی کل درمان خوراکی ORS.",
    "درمان: **مایع** ستون اصلی است. آنتی‌بیوتیک فقط مدت بیماری را ~۱ روز کوتاه می‌کند.",
]
CHOL_EN = [
    "CHOLERA has so characteristic a picture that its diagnosis is CLINICAL, not laboratory.",
    "SUDDEN ONSET — the patient can often name the hour it began.",
    "ENORMOUS VOLUME — up to 20 litres a day; a patient can reach shock within hours.",
    "RICE-WATER STOOL: watery, cloudy, grey, with flecks of mucus floating in it.",
    "A SMELL OF STALE FISH — not of ordinary faeces.",
    "WARNING, NO FEVER — because cholera DOES NOT INVADE; it only secretes toxin.",
    "WARNING, NO ABDOMINAL PAIN AND NO TENESMUS — for the same reason.",
    "MUSCLE CRAMPS — from hypokalaemia and electrolyte loss.",
    "VOMITING is common and begins in the first hours.",
    "Stool examination: WARNING, NO WHITE OR RED CELLS — the seal on its non-inflammatory nature.",
    "Mechanism: CHOLERA TOXIN delivers its A subunit into the cell -> adenylate cyclase is activated -> cAMP RISES.",
    "High cAMP holds the CFTR channel open -> MASSIVE SECRETION OF CHLORIDE, and water follows.",
    "WARNING, the crucial point: SODIUM-GLUCOSE ABSORPTION REMAINS INTACT — the basis of all oral ORS therapy.",
    "Treatment: FLUID is the mainstay. Antibiotics shorten the illness by only about a day.",
]


# ---------------------------------------------------------------- idx 332
add("book:332", "case", "easy",
 "اسهال **آب برنجی، حجیم، بدون تب** با کرامپ عضلانی = **ویبریو کلرا**.",
 "RICE-WATER, high-volume, AFEBRILE diarrhoea with muscle cramps is VIBRIO CHOLERAE.",
 CHOL_FA + [
  "این بیمار هر جزء تابلو را دارد؛ آن را بند به بند تطبیق دهید.",
  "**اسهال حجیم و آبکی، ۱۵ بار در روز** ✓ — حجم، نه دفعات، مشخصه‌ی کلراست.",
  "**مدفوع کدر به رنگ آب برنج** ✓ — تقریباً تشخیصی.",
  "**بدون تب** ✓ — کلرا تب نمی‌دهد؛ این مهم‌ترین نکته‌ی افتراقی است.",
  "**بدون درد شکم** ✓ — چون تهاجمی نیست.",
  "**کرامپ عضلانی** ✓ — از هیپوکالمی.",
  "**افت فشار وضعیتی و تاکی‌کاردی** ✓ — شوک هیپوولمیک در حال شکل‌گیری.",
  "⚠️ **کاهش pH و بی‌کربنات** ✓ — **اسیدوز متابولیک** از دست رفتن بی‌کربنات در مدفوع.",
  "**افزایش کراتینین** ✓ — نارسایی پیش‌کلیوی از کم‌آبی.",
  "چرا ویبریو پاراهمولیتیکوس نه؟ آن با **غذای دریایی** و اغلب اسهال **التهابی خفیف** همراه است.",
  "چرا سالمونلا و شیگلا نه؟ هر دو **تهاجمی**‌اند: تب می‌دهند و در مدفوع گلبول سفید دارند.",
  "⚠️ ضمناً «فصل تابستان» هم سرنخ اپیدمیولوژیک است: کلرا در فصل گرم اوج می‌گیرد.",
 ],
 CHOL_EN + [
  "This patient has every element of the picture; match it line by line.",
  "HIGH-VOLUME WATERY DIARRHOEA, 15 TIMES A DAY (yes) — it is the volume, not the frequency, that marks cholera.",
  "CLOUDY, RICE-WATER STOOL (yes) — nearly diagnostic.",
  "NO FEVER (yes) — cholera does not cause fever; this is the key discriminator.",
  "NO ABDOMINAL PAIN (yes) — because it is not invasive.",
  "MUSCLE CRAMPS (yes) — from hypokalaemia.",
  "POSTURAL HYPOTENSION AND TACHYCARDIA (yes) — hypovolaemic shock developing.",
  "WARNING, A FALLEN pH AND BICARBONATE (yes) — METABOLIC ACIDOSIS from bicarbonate lost in the stool.",
  "A RISEN CREATININE (yes) — prerenal failure from dehydration.",
  "Why not Vibrio parahaemolyticus? That follows SEAFOOD and usually causes a mildly INFLAMMATORY diarrhoea.",
  "Why not salmonella or shigella? Both are INVASIVE: they cause fever and stool white cells.",
  "WARNING: 'in summer' is an epidemiological clue too — cholera peaks in the hot season.",
 ],
 "این بیمار تصویر کتاب‌درسی **وبا** است، و ارزش سؤال در این است که هر جزء تابلو یک نکته‌ی پاتوفیزیولوژیک را نشان می‌دهد:\n\n• **اسهال حجیم آبکی، ۱۵ بار در روز** ← در کلرا **حجم** مهم است نه دفعات؛ تا ۲۰ لیتر در روز\n• **مدفوع کدر به رنگ آب برنج** ← تقریباً تشخیصی؛ پرزهای موکوسی در مایع شفاف شناورند\n• ⚠️ **بدون تب** ← مهم‌ترین نکته‌ی افتراقی: کلرا **تهاجم نمی‌کند**\n• ⚠️ **بدون درد شکم** ← به همان دلیل\n• **کرامپ عضلانی** ← از هیپوکالمی و از دست رفتن الکترولیت\n• **افت فشار وضعیتی و تاکی‌کاردی** ← شوک هیپوولمیک در حال شکل‌گیری\n• **کاهش pH و بی‌کربنات** ← **اسیدوز متابولیک**، چون مدفوع کلرا سرشار از بی‌کربنات است\n\n**سازوکار مولکولی که همه‌ی این‌ها را توضیح می‌دهد:**\n\nتوکسین کلرا زیرواحد A خود را وارد سلول روده می‌کند → **آدنیلات‌سیکلاز فعال می‌شود** → **cAMP بالا می‌رود** → کانال CFTR باز می‌ماند → **ترشح انبوه کلر** و به دنبالش آب.\n\nتوجه کنید که سلول **آسیب نمی‌بیند** — فقط ترشح می‌کند. به همین دلیل نه تب هست، نه درد، نه گلبول سفید در مدفوع.\n\n⚠️ **و زیباترین نکته‌ی درمانی:** توکسین کلرا **کوترانسپورتر سدیم-گلوکز را دست‌نخورده می‌گذارد**. یعنی روده هنوز می‌تواند سدیم را همراه گلوکز جذب کند — و کشف همین اصل بود که **ORS** را ساخت و میلیون‌ها جان را نجات داد.\n\n**چرا گزینه‌های دیگر نه؟** ویبریو پاراهمولیتیکوس با **غذای دریایی** و اسهال خفیف التهابی همراه است؛ سالمونلا و شیگلا هر دو **تهاجمی**‌اند و تب و گلبول سفید در مدفوع می‌دهند.",
 "This patient is the textbook picture of CHOLERA, and the value of the question is that every element points to a piece of pathophysiology:\n\n- HIGH-VOLUME WATERY DIARRHOEA, 15 TIMES A DAY -> in cholera it is the VOLUME that matters, up to 20 litres a day\n- CLOUDY RICE-WATER STOOL -> nearly diagnostic; flecks of mucus float in clear fluid\n- WARNING, NO FEVER -> the key discriminator: cholera DOES NOT INVADE\n- WARNING, NO ABDOMINAL PAIN -> for the same reason\n- MUSCLE CRAMPS -> from hypokalaemia and electrolyte loss\n- POSTURAL HYPOTENSION AND TACHYCARDIA -> developing hypovolaemic shock\n- A FALLEN pH AND BICARBONATE -> METABOLIC ACIDOSIS, because cholera stool is rich in bicarbonate\n\nTHE MOLECULAR MECHANISM THAT EXPLAINS ALL OF IT:\n\nCholera toxin delivers its A subunit into the enterocyte -> ADENYLATE CYCLASE IS ACTIVATED -> cAMP RISES -> the CFTR channel stays open -> MASSIVE CHLORIDE SECRETION, with water following.\n\nNote that the cell IS NOT DAMAGED — it merely secretes. That is why there is no fever, no pain and no white cells in the stool.\n\nWARNING, AND THE MOST ELEGANT THERAPEUTIC POINT: cholera toxin LEAVES THE SODIUM-GLUCOSE CO-TRANSPORTER INTACT. The gut can still absorb sodium alongside glucose — and the discovery of that principle produced ORS and has saved millions of lives.\n\nWHY NOT THE OTHERS? Vibrio parahaemolyticus follows SEAFOOD and causes a mildly inflammatory diarrhoea; salmonella and shigella are both INVASIVE, causing fever and stool white cells.",
 ["پاسخ صحیح — اسهال آب برنجی حجیم بدون تب و بدون درد شکم با کرامپ عضلانی، تابلوی کلاسیک وباست.",
  "ویبریو پاراهمولیتیکوس با مصرف غذای دریایی همراه است و اسهال خفیف التهابی می‌دهد.",
  "سالمونلا یک ارگانیسم تهاجمی است: تب می‌دهد و در مدفوع گلبول سفید دیده می‌شود.",
  "شیگلا هم تهاجمی است و اسهال کم‌حجم خونی با تنسموس می‌دهد، نه اسهال آب برنجی حجیم."],
 ["Correct — high-volume rice-water diarrhoea without fever or abdominal pain, with muscle cramps, is classic cholera.",
  "Vibrio parahaemolyticus follows seafood consumption and causes a mildly inflammatory diarrhoea.",
  "Salmonella is an invasive organism: it causes fever and white cells appear in the stool.",
  "Shigella is also invasive and causes small-volume bloody diarrhoea with tenesmus, not high-volume rice-water stool."],
 "کلرا = **آب برنجی + حجیم + بدون تب + کرامپ**. مدفوع بدون WBC. cAMP بالا، جذب سدیم-گلوکز سالم ← ORS.",
 "Cholera = RICE-WATER + HIGH VOLUME + NO FEVER + CRAMPS. No stool WBC. High cAMP, intact sodium-glucose absorption -> ORS.",
 [H163, WHO])


# ---------------------------------------------------------------- idx 347
add("book:347", "case", "medium",
 "کلرا در **بارداری** ← **آزیترومایسین**؛ داکسی‌سیکلین و کینولون هر دو منع دارند.",
 "Cholera in PREGNANCY -> AZITHROMYCIN; both doxycycline and quinolones are contraindicated.",
 CHOL_FA + [
  "این سؤال شش بار در همین فصل تکرار شده و همیشه یک پاسخ دارد، پس یک‌بار خوب یاد بگیرید.",
  "⚠️ نکته: پاسخ از **دانستن داروهای ممنوع در بارداری** می‌آید، نه از دانستن کلرا.",
  "**داکسی‌سیکلین** — داروی انتخابی کلرا در **بزرگسال غیرباردار**، ولی در بارداری **ممنوع**.",
  "چرا؟ تتراسایکلین‌ها به **کلسیم استخوان و دندان جنین** می‌چسبند.",
  "نتیجه: **تغییر رنگ دائمی دندان‌ها** و اختلال در رشد استخوان.",
  "به همین دلیل در بارداری و در کودکان زیر ۸ سال منع دارند.",
  "**سیپروفلوکساسین** — فلوروکینولون‌ها هم در بارداری **توصیه نمی‌شوند**.",
  "چرا؟ نگرانی از آسیب به **غضروف در حال رشد** (آرتروپاتی در مطالعات حیوانی).",
  "⚠️ **آزیترومایسین** — یک ماکرولید، **ایمن در بارداری** (رده‌ی B).",
  "و خوشبختانه در کلرا هم **بسیار مؤثر** است: یک گرم تک دوز.",
  "پس آزیترومایسین هم گزینه‌ی بارداری است، هم گزینه‌ی **کودکان**، به همان دلایل.",
  "**آموکسی‌سیلین** در بارداری ایمن است ولی روی ویبریو کلرا اثر قابل‌اتکایی ندارد.",
  "⚠️ و نکته‌ای که نباید فراموش شود: در این بیمار **نبض لمس نمی‌شود** — یعنی شوک.",
  "پس اولویت مطلق **احیای وریدی با رینگر لاکتات** است؛ آنتی‌بیوتیک در رتبه‌ی دوم.",
  "آنتی‌بیوتیک فقط مدت اسهال و دفع ویبریو را کوتاه می‌کند — **جان را مایع نجات می‌دهد**.",
 ],
 CHOL_EN + [
  "This question is repeated six times in this chapter with the same answer, so learn it properly once.",
  "WARNING: the answer comes from KNOWING WHICH DRUGS ARE FORBIDDEN IN PREGNANCY, not from knowing cholera.",
  "DOXYCYCLINE — the drug of choice for cholera in a NON-PREGNANT adult, but CONTRAINDICATED in pregnancy.",
  "Why? Tetracyclines bind to CALCIUM IN FETAL BONE AND TEETH.",
  "The result: PERMANENT DISCOLOURATION OF THE TEETH and disturbed bone growth.",
  "That is why they are contraindicated in pregnancy and in children under 8.",
  "CIPROFLOXACIN — fluoroquinolones are likewise NOT RECOMMENDED in pregnancy.",
  "Why? Concern about damage to DEVELOPING CARTILAGE (arthropathy in animal studies).",
  "WARNING: AZITHROMYCIN — a macrolide, SAFE IN PREGNANCY (category B).",
  "And fortunately it is also HIGHLY EFFECTIVE in cholera: 1 gram as a single dose.",
  "So azithromycin is both the pregnancy choice and the CHILDREN'S choice, for the same reasons.",
  "AMOXICILLIN is safe in pregnancy but has no reliable activity against Vibrio cholerae.",
  "WARNING, a point not to be forgotten: this patient HAS NO PALPABLE PULSE — she is in shock.",
  "So the absolute priority is INTRAVENOUS RESUSCITATION WITH RINGER'S LACTATE; the antibiotic is secondary.",
  "The antibiotic only shortens the diarrhoea and the shedding — IT IS THE FLUID THAT SAVES THE LIFE.",
 ],
 "این سؤال شش بار در همین فصل تکرار شده و همیشه یک پاسخ دارد. ⚠️ و نکته‌ی مهم این است که **پاسخ از دانستن داروهای ممنوع در بارداری می‌آید، نه از دانستن کلرا**.\n\n**چرا داکسی‌سیکلین نه؟**\nداکسی‌سیکلین **داروی انتخابی کلرا در بزرگسال غیرباردار** است، ولی در بارداری **ممنوع**. دلیلش این است که تتراسایکلین‌ها به **کلسیم استخوان و دندان در حال ساخت جنین** می‌چسبند و باعث **تغییر رنگ دائمی دندان** و اختلال رشد استخوان می‌شوند. به همین دلیل در بارداری و در کودکان زیر ۸ سال منع دارند.\n\n**چرا سیپروفلوکساسین نه؟**\nفلوروکینولون‌ها در بارداری توصیه نمی‌شوند، به‌خاطر نگرانی از آسیب به **غضروف در حال رشد** (آرتروپاتی در مطالعات حیوانی).\n\n**چرا آموکسی‌سیلین نه؟**\nدر بارداری ایمن است، ولی روی **ویبریو کلرا اثر قابل‌اتکایی ندارد** — پس مسئله ایمنی نیست، اثربخشی است.\n\n⚠️ **پس چرا آزیترومایسین؟**\nیک **ماکرولید** است که هم **در بارداری ایمن** است (رده‌ی B) و هم **در کلرا بسیار مؤثر** — یک گرم تک دوز. به همین دو دلیل، آزیترومایسین هم انتخاب **بارداری** است و هم انتخاب **کودکان**.\n\n⚠️ **و مهم‌ترین نکته‌ای که نباید در این سؤال گم شود:** این بیمار **نبض قابل لمس ندارد** و خواب‌آلود است — یعنی در **شوک هیپوولمیک** است.\n\nپس اولویت مطلق **احیای وریدی فوری با رینگر لاکتات** است. آنتی‌بیوتیک فقط مدت اسهال و مدت دفع ویبریو را حدود یک روز کوتاه می‌کند. **آنچه جان بیمار را نجات می‌دهد مایع است، نه آنتی‌بیوتیک.**",
 "This question is repeated six times in this chapter with the same answer. WARNING, and the important point is that THE ANSWER COMES FROM KNOWING WHICH DRUGS ARE FORBIDDEN IN PREGNANCY, not from knowing cholera.\n\nWHY NOT DOXYCYCLINE?\nDoxycycline is THE DRUG OF CHOICE FOR CHOLERA IN A NON-PREGNANT ADULT, but is CONTRAINDICATED in pregnancy. Tetracyclines bind CALCIUM IN DEVELOPING FETAL BONE AND TEETH, causing PERMANENT TOOTH DISCOLOURATION and disturbed bone growth. Hence their contraindication in pregnancy and in children under 8.\n\nWHY NOT CIPROFLOXACIN?\nFluoroquinolones are not recommended in pregnancy, because of concern about damage to DEVELOPING CARTILAGE (arthropathy in animal studies).\n\nWHY NOT AMOXICILLIN?\nIt is safe in pregnancy but has NO RELIABLE ACTIVITY AGAINST VIBRIO CHOLERAE — here the problem is efficacy, not safety.\n\nWARNING, SO WHY AZITHROMYCIN?\nIt is a MACROLIDE that is both SAFE IN PREGNANCY (category B) and HIGHLY EFFECTIVE IN CHOLERA — 1 gram as a single dose. For those two reasons azithromycin is both the PREGNANCY choice and the CHILDREN'S choice.\n\nWARNING, AND THE MOST IMPORTANT POINT NOT TO LOSE IN THIS QUESTION: this patient HAS NO PALPABLE PULSE and is drowsy — she is in HYPOVOLAEMIC SHOCK.\n\nThe absolute priority is therefore IMMEDIATE INTRAVENOUS RESUSCITATION WITH RINGER'S LACTATE. The antibiotic shortens the diarrhoea and the shedding by about a day. IT IS THE FLUID THAT SAVES THE LIFE, NOT THE ANTIBIOTIC.",
 ["داکسی‌سیکلین داروی انتخابی کلرا در غیرباردار است، ولی در بارداری به‌علت رسوب در استخوان و دندان جنین ممنوع است.",
  "پاسخ صحیح — آزیترومایسین هم در بارداری ایمن است و هم در کلرا مؤثر؛ یک گرم تک دوز.",
  "سیپروفلوکساسین در بارداری توصیه نمی‌شود، به‌خاطر نگرانی از آسیب به غضروف در حال رشد.",
  "آموکسی‌سیلین در بارداری ایمن است ولی روی ویبریو کلرا اثر قابل‌اتکایی ندارد."],
 ["Doxycycline is the drug of choice in non-pregnant adults but is contraindicated in pregnancy, depositing in fetal bone and teeth.",
  "Correct — azithromycin is both safe in pregnancy and effective in cholera: 1 gram as a single dose.",
  "Ciprofloxacin is not recommended in pregnancy because of concern about developing cartilage.",
  "Amoxicillin is safe in pregnancy but has no reliable activity against Vibrio cholerae."],
 "کلرا در بارداری و کودکان = **آزیترومایسین**. داکسی (دندان/استخوان) و کینولون (غضروف) ممنوع. **اول مایع، بعد دارو.**",
 "Cholera in pregnancy and children = AZITHROMYCIN. Doxycycline (teeth/bone) and quinolones (cartilage) are out. FLUID FIRST, drug second.",
 [H163, WHO])


# ---------------------------------------------------------------- idx 340
add("book:340", "case", "medium",
 "کشت ویبریو کلرا نیاز به محیط **TCBS** دارد؛ برای انتقال از راه دور، **کری-بلر**.",
 "Culturing Vibrio cholerae needs TCBS medium; for transport over distance, CARY-BLAIR.",
 CHOL_FA + [
  "این سؤال یک نکته‌ی میکروب‌شناسی عملی را می‌آزماید که دو بار در این فصل تکرار شده.",
  "⚠️ **ویبریو کلرا روی محیط‌های معمولی مدفوع به‌خوبی رشد نمی‌کند.**",
  "محیط‌های استاندارد مثل **SS** یا مک‌کانکی برای انتروباکتریاسه (سالمونلا، شیگلا) طراحی شده‌اند.",
  "ویبریو دو ویژگی خاص دارد که محیط جدا می‌طلبد.",
  "ویژگی یک: **قلیادوست (alkaliphilic)** است — در pH بالای ۸ به‌خوبی رشد می‌کند.",
  "ویژگی دو: نسبت به **نمک صفراوی** مقاوم است، برخلاف بسیاری از باکتری‌های دیگر.",
  "⚠️ **محیط TCBS** دقیقاً این دو را به کار می‌گیرد: **تیوسولفات-سیترات-نمک صفراوی-ساکارز**.",
  "pH بالای آن رشد فلور طبیعی را مهار می‌کند ولی برای ویبریو ایده‌آل است.",
  "و ویبریو کلرا **ساکارز را تخمیر می‌کند**، پس کلنی‌های **زرد** می‌سازد.",
  "این نکته‌ی افتراقی است: ویبریو پاراهمولیتیکوس ساکارز را تخمیر نمی‌کند و **سبز** می‌ماند.",
  "⚠️ حالا تفاوت مهم دیگر: **محیط کشت** با **محیط انتقال** یکی نیست.",
  "اگر نمونه باید ساعت‌ها یا روزها تا آزمایشگاه سفر کند، از **کری-بلر (Cary-Blair)** استفاده می‌شود.",
  "کری-بلر یک محیط **نگهدارنده** است: باکتری را زنده نگه می‌دارد ولی اجازه‌ی تکثیر نمی‌دهد.",
  "پس در سؤالی که می‌گوید «فاصله‌ی طولانی تا مرکز بهداشت»، پاسخ **کری-بلر** است، نه TCBS.",
  "⚠️ و یادآوری بالینی: هیچ‌کدام از این‌ها **درمان را به تأخیر نمی‌اندازند**؛ تشخیص کلرا بالینی است.",
 ],
 CHOL_EN + [
  "This question tests a practical microbiology point that appears twice in this chapter.",
  "WARNING: VIBRIO CHOLERAE GROWS POORLY ON ORDINARY STOOL MEDIA.",
  "Standard media such as SS or MacConkey are designed for Enterobacteriaceae (salmonella, shigella).",
  "Vibrio has two peculiarities that demand a separate medium.",
  "One: it is ALKALIPHILIC — it grows well above pH 8.",
  "Two: it tolerates BILE SALTS, unlike many other organisms.",
  "WARNING: TCBS medium exploits exactly those two — THIOSULPHATE-CITRATE-BILE SALT-SUCROSE.",
  "Its high pH suppresses the normal flora while suiting vibrio perfectly.",
  "And Vibrio cholerae FERMENTS SUCROSE, so it forms YELLOW colonies.",
  "That is a useful discriminator: Vibrio parahaemolyticus does not ferment sucrose and stays GREEN.",
  "WARNING, now another important distinction: A CULTURE MEDIUM IS NOT A TRANSPORT MEDIUM.",
  "If the specimen must travel for hours or days to a laboratory, CARY-BLAIR is used.",
  "Cary-Blair is a PRESERVATION medium: it keeps the organism alive without letting it multiply.",
  "So when a question mentions 'a long distance to the health centre', the answer is CARY-BLAIR, not TCBS.",
  "WARNING, a clinical reminder: none of this DELAYS TREATMENT; the diagnosis of cholera is clinical.",
 ],
 "این سؤال یک نکته‌ی میکروب‌شناسی عملی را می‌آزماید که دو بار در این فصل به دو شکل پرسیده شده.\n\n⚠️ **مسئله‌ی اصلی: ویبریو کلرا روی محیط‌های معمولی مدفوع به‌خوبی رشد نمی‌کند.** محیط‌های استاندارد مثل **SS** یا مک‌کانکی برای انتروباکتریاسه (سالمونلا، شیگلا) طراحی شده‌اند.\n\nویبریو دو ویژگی خاص دارد که محیط جداگانه می‌طلبد:\n۱. **قلیادوست** است و در **pH بالای ۸** به‌خوبی رشد می‌کند\n۲. به **نمک صفراوی مقاوم** است\n\n⚠️ **محیط TCBS** دقیقاً از همین دو ویژگی استفاده می‌کند: **تیوسولفات-سیترات-نمک صفراوی-ساکارز**. pH بالای آن فلور طبیعی را مهار می‌کند ولی برای ویبریو ایده‌آل است.\n\nو یک نکته‌ی افتراقی ظریف: **ویبریو کلرا ساکارز را تخمیر می‌کند** و کلنی‌های **زرد** می‌سازد، در حالی که **ویبریو پاراهمولیتیکوس** ساکارز را تخمیر نمی‌کند و **سبز** می‌ماند.\n\n⚠️ **و حالا تفاوتی که در سؤال دیگری از همین فصل جداگانه پرسیده شده: محیط کشت با محیط انتقال یکی نیست.**\n\nاگر نمونه باید ساعت‌ها یا روزها تا آزمایشگاه سفر کند (مثلاً از یک مرکز روستایی)، از **کری-بلر (Cary-Blair)** استفاده می‌شود. کری-بلر یک **محیط نگهدارنده** است: باکتری را زنده نگه می‌دارد ولی اجازه‌ی تکثیر نمی‌دهد، پس نسبت گونه‌ها به هم نمی‌خورد.\n\nپس قاعده روشن است:\n• **کشت در آزمایشگاه** ← **TCBS**\n• **انتقال از راه دور** ← **کری-بلر**\n\n⚠️ و یادآوری بالینی مهم: هیچ‌یک از این‌ها نباید **درمان را به تأخیر بیندازد**. تشخیص کلرا **بالینی** است و مایع‌درمانی باید فوراً و پیش از هر کشتی شروع شود.",
 "This question tests a practical microbiology point that this chapter asks twice, in two forms.\n\nWARNING, THE CORE ISSUE: VIBRIO CHOLERAE GROWS POORLY ON ORDINARY STOOL MEDIA. Standard media such as SS or MacConkey are designed for Enterobacteriaceae (salmonella, shigella).\n\nVibrio has two peculiarities that demand a dedicated medium:\n1. It is ALKALIPHILIC and grows well above pH 8\n2. It TOLERATES BILE SALTS\n\nWARNING: TCBS medium exploits exactly those two properties — THIOSULPHATE-CITRATE-BILE SALT-SUCROSE. Its high pH suppresses normal flora while suiting vibrio perfectly.\n\nAnd a fine discriminating point: VIBRIO CHOLERAE FERMENTS SUCROSE and forms YELLOW colonies, whereas VIBRIO PARAHAEMOLYTICUS does not and remains GREEN.\n\nWARNING, AND NOW THE DISTINCTION THIS CHAPTER ASKS SEPARATELY: A CULTURE MEDIUM IS NOT A TRANSPORT MEDIUM.\n\nIf the specimen must travel for hours or days to a laboratory — from a rural centre, say — CARY-BLAIR is used. Cary-Blair is a PRESERVATION medium: it keeps the organism alive without allowing multiplication, so the proportions of species are not distorted.\n\nThe rule is therefore clear:\n- CULTURE IN THE LABORATORY -> TCBS\n- TRANSPORT OVER DISTANCE -> CARY-BLAIR\n\nWARNING, an important clinical reminder: none of this should DELAY TREATMENT. The diagnosis of cholera is CLINICAL, and fluid resuscitation must begin at once, before any culture.",
 ["دیدن تروفوزوئیت مربوط به انگل‌هایی مثل ژیاردیا و آمیب است، نه ویبریو کلرا.",
  "محیط SS برای سالمونلا و شیگلا طراحی شده و ویبریو روی آن به‌خوبی رشد نمی‌کند.",
  "بررسی توکسین در مدفوع روش تشخیص کلستریدیوم دیفیسیل است، نه کلرا.",
  "پاسخ صحیح — TCBS محیط اختصاصی ویبریو است؛ pH بالا و نمک صفراوی، و کلنی زرد از تخمیر ساکارز."],
 ["Seeing trophozoites applies to parasites such as giardia and amoeba, not to Vibrio cholerae.",
  "SS medium is designed for salmonella and shigella; vibrio grows poorly on it.",
  "Stool toxin testing is the method for Clostridioides difficile, not cholera.",
  "Correct — TCBS is the selective medium for vibrio: high pH and bile salt, with yellow colonies from sucrose fermentation."],
 "**کشت ویبریو ← TCBS** (کلنی زرد). **انتقال از راه دور ← کری-بلر.** تشخیص کلرا بالینی است؛ درمان را عقب نینداز.",
 "CULTURE vibrio -> TCBS (yellow colonies). TRANSPORT over distance -> CARY-BLAIR. Cholera is a clinical diagnosis; do not delay treatment.",
 [H163, WHO])


# ---------------------------------------------------------------- idx 321
add("book:321", "case", "hard",
 "کولیت دیفیسیل **شدید** (لکوسیتوز + غشاء کاذب + تب) ← **وانکومایسین خوراکی**.",
 "SEVERE C. difficile colitis (leucocytosis + pseudomembranes + fever) -> ORAL VANCOMYCIN.",
 [
  "درمان کلستریدیوم دیفیسیل بر پایه‌ی **شدت بیماری** انتخاب می‌شود، پس اول باید شدت را تعیین کرد.",
  "**معیارهای شدت (طبقه‌بندی کلاسیک که این آزمون‌ها می‌پرسند):**",
  "**گلبول سفید بالای ۱۵۰۰۰** ← نشانه‌ی شدت.",
  "**کراتینین بالای ۱/۵** (یا ۱/۵ برابر پایه) ← نشانه‌ی شدت.",
  "**آلبومین پایین**، تب بالا، درد شکم شدید ← نشانه‌های تکمیلی.",
  "**غشاء کاذب در کولونوسکوپی** ← نشانه‌ی بیماری پیشرفته.",
  "این بیمار **لکوسیتوز ۱۷۰۰۰**، **تب ۳۹**، **اسهال خونی** و **غشاء کاذب** دارد ← **شدید**.",
  "⚠️ **قاعده‌ی کلاسیک (که کلید این کتاب از آن پیروی می‌کند):**",
  "**خفیف تا متوسط** ← **مترونیدازول خوراکی** ۵۰۰ میلی‌گرم سه بار در روز، ۱۰ تا ۱۴ روز.",
  "**شدید** ← **وانکومایسین خوراکی** ۱۲۵ میلی‌گرم چهار بار در روز، ۱۰ روز.",
  "**فولمینانت** (شوک، ایلئوس، مگاکولون) ← وانکومایسین خوراکی **دوز بالا** + **مترونیدازول وریدی**.",
  "⚠️ چرا وانکومایسین **خوراکی** و نه وریدی؟ این مهم‌ترین دام دارویی این بلوک است.",
  "وانکومایسین خوراکی **از روده جذب نمی‌شود** — و همین دقیقاً چیزی است که می‌خواهیم.",
  "دارو در **مجرای روده** می‌ماند، همان‌جا که دیفیسیل است، و به غلظت بسیار بالا می‌رسد.",
  "⚠️ برعکس، وانکومایسین **وریدی** به لومن روده **نمی‌رسد** و در دیفیسیل **کاملاً بی‌اثر** است.",
  "و مترونیدازول برعکس است: **وریدی هم** به روده می‌رسد (از راه صفرا و مخاط ملتهب).",
  "به همین دلیل در بیمار با ایلئوس که نمی‌تواند بخورد، مترونیدازول وریدی جا دارد.",
  "⚠️ **به‌روزرسانی مدرن:** راهنمای IDSA/SHEA ۲۰۲۱ دیگر مترونیدازول را خط اول نمی‌داند.",
  "امروز **فیداکسومایسین** ارجح است و **وانکومایسین** جایگزین قابل‌قبول؛ مترونیدازول فقط وقتی آن دو نباشند.",
  "ولی این آزمون‌ها **طبقه‌بندی کلاسیک** را می‌پرسند و کلیدشان بر همان بناست.",
 ],
 [
  "Treatment of C. difficile is chosen by DISEASE SEVERITY, so severity must be established first.",
  "SEVERITY CRITERIA (the classical classification these exams ask about):",
  "WHITE CELL COUNT ABOVE 15,000 -> a marker of severity.",
  "CREATININE ABOVE 1.5 (or 1.5 times baseline) -> a marker of severity.",
  "LOW ALBUMIN, high fever, severe abdominal pain -> supporting markers.",
  "PSEUDOMEMBRANES AT COLONOSCOPY -> a sign of advanced disease.",
  "This patient has LEUCOCYTOSIS OF 17,000, FEVER OF 39, BLOODY DIARRHOEA and PSEUDOMEMBRANES -> SEVERE.",
  "WARNING, THE CLASSICAL RULE (which this book's keys follow):",
  "MILD TO MODERATE -> ORAL METRONIDAZOLE 500 mg three times daily for 10-14 days.",
  "SEVERE -> ORAL VANCOMYCIN 125 mg four times daily for 10 days.",
  "FULMINANT (shock, ileus, megacolon) -> HIGH-DOSE oral vancomycin PLUS INTRAVENOUS metronidazole.",
  "WARNING, why ORAL vancomycin and not intravenous? This is the block's most important pharmacological trap.",
  "Oral vancomycin IS NOT ABSORBED from the gut — and that is exactly what we want.",
  "The drug stays IN THE LUMEN, where C. difficile is, and reaches very high concentrations.",
  "WARNING, conversely, INTRAVENOUS vancomycin DOES NOT REACH the gut lumen and is COMPLETELY INEFFECTIVE here.",
  "Metronidazole is the opposite: even INTRAVENOUSLY it reaches the gut (via bile and inflamed mucosa).",
  "That is why intravenous metronidazole has a place in a patient with ileus who cannot swallow.",
  "WARNING, THE MODERN UPDATE: the 2021 IDSA/SHEA guideline no longer treats metronidazole as first line.",
  "Today FIDAXOMICIN is preferred and VANCOMYCIN an acceptable alternative; metronidazole only if neither is available.",
  "But these exams ask the CLASSICAL classification, and their keys rest on it.",
 ],
 "درمان کلستریدیوم دیفیسیل بر پایه‌ی **شدت بیماری** انتخاب می‌شود، پس اول باید شدت را تعیین کرد.\n\n**این بیمار شدید است:**\n• **لکوسیتوز ۱۷۰۰۰** (آستانه‌ی شدت: بالای ۱۵۰۰۰) ✓\n• **تب ۳۹ درجه** ✓\n• **اسهال خونی** ✓\n• **غشاء کاذب در کولونوسکوپی** ✓ ← نشانه‌ی بیماری پیشرفته\n\n⚠️ **قاعده‌ی کلاسیک که کلید این کتاب از آن پیروی می‌کند:**\n\n• **خفیف تا متوسط** ← **مترونیدازول خوراکی** ۵۰۰ میلی‌گرم سه بار در روز، ۱۰ تا ۱۴ روز\n• **شدید** ← **وانکومایسین خوراکی** ۱۲۵ میلی‌گرم چهار بار در روز، ۱۰ روز\n• **فولمینانت** ← وانکومایسین خوراکی دوز بالا به‌علاوه‌ی مترونیدازول **وریدی**\n\nپس پاسخ این بیمار **وانکومایسین خوراکی** است.\n\n⚠️ **و حالا مهم‌ترین دام دارویی این بلوک: چرا وانکومایسین خوراکی و نه وریدی؟**\n\nوانکومایسین خوراکی **از روده جذب نمی‌شود** — و این دقیقاً همان چیزی است که می‌خواهیم. دارو در **مجرای روده** باقی می‌ماند، یعنی همان‌جا که دیفیسیل زندگی می‌کند، و به غلظت بسیار بالایی می‌رسد.\n\nبرعکس، **وانکومایسین وریدی به لومن روده نمی‌رسد** و در درمان دیفیسیل **کاملاً بی‌اثر** است. این یکی از پرتکرارترین اشتباهات بالینی است.\n\nو **مترونیدازول دقیقاً برعکس** است: حتی به شکل **وریدی** هم از راه صفرا و مخاط ملتهب به روده می‌رسد. به همین دلیل در بیمار با **ایلئوس** که نمی‌تواند دارو بخورد، مترونیدازول وریدی جای خود را دارد.\n\n⚠️ **یک به‌روزرسانی مهم که دانشجو باید بداند:** راهنمای **IDSA/SHEA ۲۰۲۱** دیگر مترونیدازول را خط اول نمی‌داند. امروز **فیداکسومایسین** ارجح است و **وانکومایسین** جایگزین قابل‌قبول، و مترونیدازول فقط وقتی توصیه می‌شود که آن دو در دسترس نباشند. اما این آزمون‌ها **طبقه‌بندی کلاسیک** را می‌پرسند و کلیدهایشان بر همان مبنا ساخته شده — پس هر دو را بدانید.",
 "Treatment of C. difficile is chosen by DISEASE SEVERITY, so severity must be established first.\n\nTHIS PATIENT IS SEVERE:\n- LEUCOCYTOSIS OF 17,000 (severity threshold: above 15,000) (yes)\n- FEVER OF 39 (yes)\n- BLOODY DIARRHOEA (yes)\n- PSEUDOMEMBRANES AT COLONOSCOPY (yes) - a sign of advanced disease\n\nWARNING, THE CLASSICAL RULE THIS BOOK'S KEYS FOLLOW:\n\n- MILD TO MODERATE -> ORAL METRONIDAZOLE 500 mg three times daily, 10-14 days\n- SEVERE -> ORAL VANCOMYCIN 125 mg four times daily, 10 days\n- FULMINANT -> high-dose oral vancomycin PLUS INTRAVENOUS metronidazole\n\nSo the answer here is ORAL VANCOMYCIN.\n\nWARNING, AND NOW THE BLOCK'S MOST IMPORTANT PHARMACOLOGICAL TRAP: WHY ORAL AND NOT INTRAVENOUS VANCOMYCIN?\n\nOral vancomycin IS NOT ABSORBED from the gut — and that is exactly what we want. The drug stays IN THE LUMEN, where C. difficile lives, and reaches very high concentrations there.\n\nConversely, INTRAVENOUS VANCOMYCIN DOES NOT REACH THE GUT LUMEN and is COMPLETELY INEFFECTIVE against C. difficile. This is one of the commonest clinical errors.\n\nAnd METRONIDAZOLE IS EXACTLY THE OPPOSITE: even INTRAVENOUSLY it reaches the gut via bile and inflamed mucosa. That is why intravenous metronidazole has a place in a patient with ILEUS who cannot take oral drugs.\n\nWARNING, AN IMPORTANT UPDATE THE STUDENT SHOULD KNOW: the 2021 IDSA/SHEA guideline no longer regards metronidazole as first line. Today FIDAXOMICIN is preferred and VANCOMYCIN an acceptable alternative, with metronidazole recommended only when neither is available. But these exams ask the CLASSICAL classification and their keys rest on it — so know both.",
 ["مترونیدازول وریدی برای بیماری فولمینانت و در کنار وانکومایسین خوراکی جا دارد، نه به‌تنهایی در بیماری شدید.",
  "پاسخ صحیح — بیماری شدید (لکوسیتوز، تب، غشاء کاذب) با وانکومایسین خوراکی درمان می‌شود.",
  "وانکومایسین **وریدی** به لومن روده نمی‌رسد و در دیفیسیل کاملاً بی‌اثر است.",
  "افزودن مترونیدازول خوراکی به وانکومایسین خوراکی در بیماری شدیدِ غیرفولمینانت لازم نیست."],
 ["Intravenous metronidazole has a place in fulminant disease alongside oral vancomycin, not alone in severe disease.",
  "Correct — severe disease (leucocytosis, fever, pseudomembranes) is treated with oral vancomycin.",
  "INTRAVENOUS vancomycin does not reach the gut lumen and is completely ineffective in C. difficile.",
  "Adding oral metronidazole to oral vancomycin is unnecessary in severe, non-fulminant disease."],
 "دیفیسیل: **خفیف→مترونیدازول خوراکی؛ شدید→وانکومایسین خوراکی؛ فولمینانت→هر دو**. ⚠️ وانکو **وریدی بی‌اثر** است.",
 "C. difficile: mild -> oral metronidazole; severe -> ORAL vancomycin; fulminant -> both. WARNING: IV vancomycin is USELESS.",
 [H133, IDSA])


# ---------------------------------------------------------------- idx 324
add("book:324", "recall", "medium",
 "در اسهال حاد، **شیگلا** تنها موردی است که درمان آنتی‌بیوتیکی همیشه توصیه می‌شود.",
 "In acute diarrhoea, SHIGELLA is the one organism for which antibiotics are always recommended.",
 [
  "این سؤال قاعده‌ی درمانی چهار ارگانیسم را هم‌زمان می‌آزماید، پس فهرست را مرتب کنید.",
  "⚠️ **شیگلا** ← **همیشه درمان می‌شود**، و دو دلیل محکم دارد.",
  "دلیل یک: **دوز عفونی بسیار پایین** است — تنها **۱۰ تا ۱۰۰ باکتری** برای انتقال کافی است.",
  "این پایین‌ترین دوز عفونی در میان همه‌ی پاتوژن‌های روده‌ای است.",
  "پس درمان علاوه بر بیمار، **زنجیره‌ی انتقال** را هم قطع می‌کند — یک اقدام بهداشت عمومی.",
  "دلیل دو: آنتی‌بیوتیک **مدت بیماری و دفع باکتری را کوتاه می‌کند** (برخلاف سالمونلا).",
  "درمان: **سیپروفلوکساسین** یا **آزیترومایسین**، معمولاً ۳ تا ۵ روز.",
  "در میزبان با نقص ایمنی، دوره طولانی‌تر است: ۷ تا ۱۰ روز.",
  "⚠️ **سالمونلای غیرتیفوئیدی** ← **درمان نمی‌شود** در فرد سالم.",
  "چون آنتی‌بیوتیک **دفع باکتری را طولانی‌تر می‌کند** و مدت اسهال را کوتاه نمی‌کند.",
  "⚠️ **EHEC (ای‌کولای انتروهموراژیک)** ← **درمان ممنوع است**.",
  "چون آنتی‌بیوتیک با فعال کردن پاسخ SOS، تولید شیگاتوکسین و **خطر HUS** را زیاد می‌کند.",
  "**کمپیلوباکتر** ← معمولاً **خودمحدودشونده** است و در موارد خفیف درمان لازم نیست.",
  "درمان کمپیلوباکتر (آزیترومایسین) فقط در بیماری شدید، طول‌کشیده یا میزبان پرخطر.",
  "⚠️ پس ترتیب را حفظ کنید: **شیگلا همیشه، کمپیلوباکتر گاهی، سالمونلا معمولاً نه، EHEC هرگز**.",
 ],
 [
  "This question tests the treatment rule for four organisms at once, so organise the list.",
  "WARNING: SHIGELLA is ALWAYS TREATED, for two solid reasons.",
  "Reason one: its INFECTIOUS DOSE IS EXTREMELY LOW — only 10 to 100 organisms suffice.",
  "That is the lowest infectious dose of any enteric pathogen.",
  "So treatment breaks THE CHAIN OF TRANSMISSION as well as helping the patient — a public health measure.",
  "Reason two: antibiotics SHORTEN BOTH THE ILLNESS AND THE SHEDDING (unlike in salmonella).",
  "Treatment: CIPROFLOXACIN or AZITHROMYCIN, usually for 3-5 days.",
  "In an immunocompromised host the course is longer: 7-10 days.",
  "WARNING: NON-TYPHOIDAL SALMONELLA is NOT treated in a healthy person.",
  "Because antibiotics PROLONG SHEDDING and do not shorten the diarrhoea.",
  "WARNING: EHEC (enterohaemorrhagic E. coli) MUST NOT BE TREATED.",
  "Because antibiotics trigger the SOS response, increasing shiga-toxin production and THE RISK OF HUS.",
  "CAMPYLOBACTER is usually SELF-LIMITING and needs no treatment in mild cases.",
  "Treating campylobacter (azithromycin) is reserved for severe or prolonged illness, or a high-risk host.",
  "WARNING, memorise the order: SHIGELLA ALWAYS, CAMPYLOBACTER SOMETIMES, SALMONELLA USUALLY NOT, EHEC NEVER.",
 ],
 "این سؤال قاعده‌ی درمانی **چهار ارگانیسم** را هم‌زمان می‌آزماید، و ارزشش در این است که هر چهار پاسخ متفاوت است.\n\n⚠️ **شیگلا ← همیشه درمان می‌شود.** دو دلیل محکم دارد:\n\n**دلیل یک — دوز عفونی فوق‌العاده پایین.** برای انتقال شیگلا تنها **۱۰ تا ۱۰۰ باکتری** کافی است؛ این پایین‌ترین دوز عفونی در میان همه‌ی پاتوژن‌های روده‌ای است. (برای مقایسه: کلرا به میلیون‌ها باکتری نیاز دارد.) به همین دلیل شیگلا به‌راحتی از فرد به فرد منتقل می‌شود، و درمان علاوه بر کمک به بیمار، **زنجیره‌ی انتقال را قطع می‌کند** — یعنی یک اقدام **بهداشت عمومی** است.\n\n**دلیل دو — آنتی‌بیوتیک واقعاً کمک می‌کند.** برخلاف سالمونلا، در شیگلا آنتی‌بیوتیک هم **مدت بیماری** و هم **مدت دفع باکتری** را کوتاه می‌کند. درمان: سیپروفلوکساسین یا آزیترومایسین، ۳ تا ۵ روز.\n\n**و حالا سه ارگانیسم دیگر، که هرکدام قاعده‌ی متفاوتی دارند:**\n\n⚠️ **سالمونلای غیرتیفوئیدی ← در فرد سالم درمان نمی‌شود**، چون آنتی‌بیوتیک **دفع باکتری را طولانی‌تر می‌کند** و مدت اسهال را کوتاه نمی‌کند.\n\n⚠️ **EHEC ← درمان ممنوع است**، چون آنتی‌بیوتیک با فعال کردن **پاسخ SOS** باکتری، تولید شیگاتوکسین و در نتیجه **خطر HUS** را افزایش می‌دهد.\n\n**کمپیلوباکتر ← معمولاً خودمحدودشونده** است؛ درمان (آزیترومایسین) فقط در بیماری شدید، طول‌کشیده، یا میزبان پرخطر.\n\n⚠️ **یک جمله برای حفظ کردن کل قاعده:**\n**شیگلا همیشه، کمپیلوباکتر گاهی، سالمونلا معمولاً نه، EHEC هرگز.**",
 "This question tests the treatment rule for FOUR organisms at once, and its value is that all four answers differ.\n\nWARNING: SHIGELLA IS ALWAYS TREATED, for two solid reasons.\n\nREASON ONE — AN EXTRAORDINARILY LOW INFECTIOUS DOSE. Only 10 to 100 organisms are needed to transmit shigella; that is the lowest infectious dose of any enteric pathogen. (For comparison, cholera requires millions.) Shigella therefore spreads readily from person to person, and treatment BREAKS THE CHAIN OF TRANSMISSION as well as helping the patient — it is a PUBLIC HEALTH measure.\n\nREASON TWO — ANTIBIOTICS GENUINELY HELP. Unlike in salmonella, antibiotics in shigella shorten BOTH the illness AND the shedding. Treatment: ciprofloxacin or azithromycin for 3-5 days.\n\nAND NOW THE OTHER THREE, each with a different rule:\n\nWARNING: NON-TYPHOIDAL SALMONELLA is NOT treated in a healthy person, because antibiotics PROLONG SHEDDING without shortening the diarrhoea.\n\nWARNING: EHEC MUST NOT BE TREATED, because antibiotics trigger the bacterial SOS RESPONSE, increasing shiga-toxin production and therefore THE RISK OF HUS.\n\nCAMPYLOBACTER is usually SELF-LIMITING; treatment (azithromycin) is reserved for severe or prolonged illness or a high-risk host.\n\nWARNING, ONE LINE TO FIX THE WHOLE RULE:\nSHIGELLA ALWAYS, CAMPYLOBACTER SOMETIMES, SALMONELLA USUALLY NOT, EHEC NEVER.",
 ["در EHEC آنتی‌بیوتیک ممنوع است، چون تولید شیگاتوکسین و خطر HUS را افزایش می‌دهد.",
  "سالمونلای غیرتیفوئیدی در فرد سالم درمان نمی‌شود؛ آنتی‌بیوتیک دفع باکتری را طولانی‌تر می‌کند.",
  "کمپیلوباکتر معمولاً خودمحدودشونده است و در موارد خفیف درمان لازم ندارد.",
  "پاسخ صحیح — شیگلا به‌علت دوز عفونی بسیار پایین و پاسخ خوب به دارو، همیشه درمان می‌شود."],
 ["Antibiotics are contraindicated in EHEC, because they increase shiga-toxin production and the risk of HUS.",
  "Non-typhoidal salmonella is not treated in a healthy person; antibiotics prolong shedding.",
  "Campylobacter is usually self-limiting and needs no treatment in mild cases.",
  "Correct — shigella is always treated, because of its very low infectious dose and good response to therapy."],
 "**شیگلا همیشه، کمپیلوباکتر گاهی، سالمونلا معمولاً نه، EHEC هرگز.** شیگلا: دوز عفونی فقط ۱۰–۱۰۰ باکتری.",
 "SHIGELLA ALWAYS, CAMPYLOBACTER SOMETIMES, SALMONELLA USUALLY NOT, EHEC NEVER. Shigella's infectious dose is only 10-100 organisms.",
 [H161, IDSA])


# ---------------------------------------------------------------- idx 435
add("book:435", "case", "medium",
 "ناقل مزمن تیفوئید (کشت مثبت پس از یک سال) ← **آموکسی‌سیلین ۶ هفته**.",
 "A chronic typhoid carrier (still culture-positive at a year) -> SIX WEEKS OF AMOXICILLIN.",
 [
  "**ناقل مزمن تیفوئید** تعریف دقیقی دارد که باید حفظ شود.",
  "⚠️ تعریف: دفع سالمونلا تیفی در مدفوع یا ادرار **بیش از ۱۲ ماه** پس از بیماری حاد.",
  "حدود **۱ تا ۵ درصد** بیماران تیفوئید ناقل مزمن می‌شوند.",
  "⚠️ محل اختفای باکتری تقریباً همیشه یکی است: **کیسه‌ی صفرا**.",
  "چرا کیسه‌ی صفرا؟ چون سالمونلا تیفی روی **سنگ صفراوی** بیوفیلم می‌سازد.",
  "بیوفیلم یک سپر است: آنتی‌بیوتیک و سیستم ایمنی به‌سختی به داخلش نفوذ می‌کنند.",
  "به همین دلیل **زن مسن با سنگ صفراوی** پرخطرترین گروه برای ناقلی مزمن است.",
  "و به همین دلیل درمان ناقل **طولانی** است — دوره‌ی کوتاه بیوفیلم را پاک نمی‌کند.",
  "⚠️ درمان استاندارد: **آموکسی‌سیلین با دوز بالا به مدت ۶ هفته**.",
  "جایگزین‌ها: **سیپروفلوکساسین ۴ هفته** یا کوتریموکسازول ۶ هفته.",
  "⚠️ اگر درمان دارویی شکست بخورد و بیمار **سنگ صفراوی** داشته باشد، **کوله‌سیستکتومی** لازم است.",
  "چون تا وقتی سنگ و بیوفیلمش هست، هیچ آنتی‌بیوتیکی ریشه‌کن نمی‌کند.",
  "چرا این‌قدر مهم است؟ چون ناقل بی‌علامت **منبع طغیان** است.",
  "مشهورترین نمونه‌ی تاریخ: **مری مالون (تایفوئید مری)**، آشپزی که ده‌ها نفر را آلوده کرد.",
  "⚠️ به همین دلیل ناقلان **حق کار در تهیه‌ی غذا و مراقبت بهداشتی را ندارند** تا ریشه‌کن شوند.",
 ],
 [
  "A CHRONIC TYPHOID CARRIER has a precise definition that must be memorised.",
  "WARNING, the definition: excretion of S. typhi in stool or urine for MORE THAN 12 MONTHS after the acute illness.",
  "About 1-5% of typhoid patients become chronic carriers.",
  "WARNING, the organism's hiding place is almost always the same: THE GALLBLADDER.",
  "Why the gallbladder? Because S. typhi forms a BIOFILM ON GALLSTONES.",
  "A biofilm is a shield: antibiotics and the immune system penetrate it only with difficulty.",
  "That is why an ELDERLY WOMAN WITH GALLSTONES is the highest-risk group for chronic carriage.",
  "And that is why carrier treatment is LONG — a short course does not clear a biofilm.",
  "WARNING, the standard treatment: HIGH-DOSE AMOXICILLIN FOR SIX WEEKS.",
  "Alternatives: CIPROFLOXACIN for 4 weeks, or co-trimoxazole for 6 weeks.",
  "WARNING: if drug treatment fails and the patient has GALLSTONES, CHOLECYSTECTOMY is required.",
  "Because while the stone and its biofilm remain, no antibiotic will eradicate the organism.",
  "Why does this matter so much? Because an asymptomatic carrier is A SOURCE OF OUTBREAKS.",
  "The most famous example in history: MARY MALLON ('Typhoid Mary'), a cook who infected dozens.",
  "WARNING: this is why carriers MAY NOT WORK IN FOOD HANDLING OR HEALTHCARE until eradicated.",
 ],
 "**ناقل مزمن تیفوئید** تعریف دقیقی دارد: ⚠️ **دفع سالمونلا تیفی در مدفوع یا ادرار بیش از ۱۲ ماه پس از بیماری حاد**. این بیمار دقیقاً همین است — یک سال پس از درمان، کشت مدفوعش هنوز مثبت است. حدود **۱ تا ۵ درصد** بیماران تیفوئید به این حالت می‌رسند.\n\n⚠️ **محل اختفای باکتری تقریباً همیشه یکی است: کیسه‌ی صفرا.**\n\nو دلیلش نکته‌ی کلیدی این سؤال است: سالمونلا تیفی روی **سنگ صفراوی** یک **بیوفیلم** می‌سازد. بیوفیلم مثل یک سپر عمل می‌کند — هم آنتی‌بیوتیک و هم سیستم ایمنی به‌سختی به داخلش نفوذ می‌کنند.\n\nاز همین‌جا دو نتیجه‌ی عملی بیرون می‌آید:\n\n**۱. پرخطرترین گروه**: **زن مسن با سنگ صفراوی**\n**۲. درمان باید طولانی باشد** — یک دوره‌ی کوتاه هرگز بیوفیلم را پاک نمی‌کند\n\n⚠️ **درمان استاندارد: آموکسی‌سیلین با دوز بالا به مدت ۶ هفته.** جایگزین‌ها: سیپروفلوکساسین ۴ هفته یا کوتریموکسازول ۶ هفته.\n\n⚠️ **و اگر درمان دارویی شکست بخورد؟** اگر بیمار سنگ صفراوی داشته باشد، **کوله‌سیستکتومی** لازم است — چون تا وقتی سنگ و بیوفیلمش سر جایش است، هیچ آنتی‌بیوتیکی ریشه‌کن نمی‌کند.\n\n**چرا اصلاً ناقل بی‌علامت را درمان می‌کنیم؟** چون او **منبع طغیان** است. مشهورترین نمونه‌ی تاریخ **مری مالون** («تایفوئید مری») است، آشپزی در نیویورک که ده‌ها نفر را آلوده کرد و خودش هرگز علامت‌دار نشد. به همین دلیل ناقلان تا زمان ریشه‌کنی **حق کار در تهیه‌ی غذا و مراقبت بهداشتی را ندارند**.",
 "A CHRONIC TYPHOID CARRIER has a precise definition: WARNING, EXCRETION OF S. TYPHI IN STOOL OR URINE FOR MORE THAN 12 MONTHS after the acute illness. This patient is exactly that — a year after treatment, her stool culture is still positive. About 1-5% of typhoid patients reach this state.\n\nWARNING: THE ORGANISM'S HIDING PLACE IS ALMOST ALWAYS THE SAME — THE GALLBLADDER.\n\nAnd the reason is the key point of this question: S. typhi forms a BIOFILM ON GALLSTONES. The biofilm acts as a shield, penetrated only with difficulty by both antibiotics and the immune system.\n\nTwo practical consequences follow:\n\n1. THE HIGHEST-RISK GROUP is an ELDERLY WOMAN WITH GALLSTONES\n2. TREATMENT MUST BE LONG — a short course never clears a biofilm\n\nWARNING, THE STANDARD TREATMENT: HIGH-DOSE AMOXICILLIN FOR SIX WEEKS. Alternatives: ciprofloxacin for 4 weeks or co-trimoxazole for 6 weeks.\n\nWARNING, AND IF DRUG TREATMENT FAILS? If the patient has gallstones, CHOLECYSTECTOMY is required — because while the stone and its biofilm remain, no antibiotic will eradicate the organism.\n\nWHY TREAT AN ASYMPTOMATIC CARRIER AT ALL? Because a carrier is A SOURCE OF OUTBREAKS. The most famous case in history is MARY MALLON ('Typhoid Mary'), a New York cook who infected dozens and never became symptomatic herself. This is why carriers MAY NOT WORK IN FOOD PREPARATION OR HEALTHCARE until eradication is confirmed.",
 ["آزیترومایسین ۴ هفته رژیم استاندارد ریشه‌کنی ناقل مزمن نیست.",
  "سفالوسپورین ۶ هفته هم رژیم پذیرفته‌شده‌ی ناقل مزمن نیست.",
  "پاسخ صحیح — آموکسی‌سیلین با دوز بالا به مدت ۶ هفته، درمان استاندارد ناقل مزمن تیفوئید است.",
  "کلرامفنیکل درمان بیماری حاد بوده و برای ریشه‌کنی ناقل مزمن انتخاب نمی‌شود."],
 ["Four weeks of azithromycin is not the standard eradication regimen for a chronic carrier.",
  "Six weeks of a cephalosporin is not an accepted chronic-carrier regimen either.",
  "Correct — high-dose amoxicillin for six weeks is the standard treatment of the chronic typhoid carrier.",
  "Chloramphenicol treated the acute illness and is not chosen for eradicating chronic carriage."],
 "ناقل مزمن = کشت مثبت **>۱۲ ماه**، مخفیگاه **کیسه‌ی صفرا** (بیوفیلم روی سنگ). **آموکسی‌سیلین ۶ هفته**؛ شکست ← کوله‌سیستکتومی.",
 "Chronic carrier = culture-positive beyond 12 months, hiding in the GALLBLADDER (biofilm on stones). SIX WEEKS OF AMOXICILLIN; on failure, cholecystectomy.",
 [H160 := "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 160"])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book16.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 16 lessons:', len(L))
