# -*- coding: utf-8 -*-
"""Turn the extracted infectious-diseases questions into an import payload.

Deliberately standalone rather than bolted onto the neurology tooling: that
pipeline hard-codes "نورولوژی" in a dozen places, and a second subject is the
moment to stop copying strings around. The OUTPUT shape is identical, so the
same `/admin/official-question-import/commit` endpoint and the same
`import-bank.mjs` uploader work unchanged.

Chapters follow the official 1405 syllabus, which names Harrison 21st ed and
lists the 35 selected chapters (see REFERENCE.md); we group them into the
teaching chapters an Iranian pre-internship student would recognise.
"""
import json, io, os, glob, re, hashlib

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'out')

SUBJECT_FA, SUBJECT_EN = 'بیماری‌های عفونی', 'Infectious Diseases'
# Infectious disease is a MINOR subject of the pre-internship exam; the majors
# are internal medicine, surgery, paediatrics and obstetrics.
SUBJECT_TRACK = 'minor'

# concept slug -> (chapter_fa, chapter_en) — the teaching chapter the question
# belongs to, used to group questions into lessons on the learning path.
CHAPTERS = {
    'cns-infection':   ('عفونت‌های سیستم عصبی مرکزی', 'CNS Infections'),
    'respiratory':     ('عفونت‌های دستگاه تنفسی', 'Respiratory Tract Infections'),
    'gi-infection':    ('عفونت‌های گوارشی و اسهال', 'Gastrointestinal Infections and Diarrhoea'),
    'skin-soft':       ('عفونت‌های پوست، بافت نرم و گازگرفتگی', 'Skin, Soft Tissue and Bite Infections'),
    'bone-joint':      ('عفونت‌های استخوان و مفصل', 'Bone and Joint Infections'),
    'tuberculosis':    ('سل', 'Tuberculosis'),
    'parasitic':       ('بیماری‌های انگلی و مالاریا', 'Parasitic Diseases and Malaria'),
    'toxin-mediated':  ('بیماری‌های توکسینی و کزاز', 'Toxin-Mediated Diseases and Tetanus'),
    'sepsis-febrile':  ('سپسیس و رویکرد به بیمار تب‌دار', 'Sepsis and the Febrile Patient'),
    'sti-viral':       ('عفونت‌های ویروسی و منتقله از راه جنسی', 'Viral and Sexually Transmitted Infections'),
    'endocarditis':    ('اندوکاردیت و عفونت‌های داخل عروقی', 'Endocarditis and Intravascular Infections'),
    'uti':             ('عفونت‌های ادراری', 'Urinary Tract Infections'),
    'zoonoses':        ('زئونوزها و بیماری‌های منتقله از حیوان', 'Zoonoses and Animal-Borne Diseases'),
}

# question_no -> concept slug, per sitting. Assigning this by hand keeps the
# chapter mapping reviewable instead of guessing from keywords.
CONCEPT_OF = {
    ('1404-09', 103): ('parasitic', 'مالاریای شدید فالسیپاروم', 'Severe falciparum malaria'),
    ('1404-09', 104): ('toxin-mediated', 'تشخیص بوتولیسم', 'Diagnosis of botulism'),
    ('1404-09', 105): ('gi-infection', 'درمان کولیت آمیبی', 'Treatment of amoebic colitis'),
    ('1404-09', 106): ('skin-soft', 'پروفیلاکسی گازگرفتگی سگ', 'Dog-bite prophylaxis'),
    ('1404-09', 107): ('respiratory', 'پنومونیت آسپیراسیون', 'Aspiration pneumonitis'),
    ('1404-09', 108): ('tuberculosis', 'سل نهفته پیش از anti-TNF', 'Latent TB before anti-TNF'),
    ('1403-12', 103): ('cns-infection', 'مننژیت باکتریال و پوشش لیستریا', 'Bacterial meningitis and Listeria cover'),
    ('1403-12', 104): ('gi-infection', 'مسمومیت غذایی توکسینی', 'Toxin-mediated food poisoning'),
    ('1403-12', 105): ('toxin-mediated', 'درمان فوری بوتولیسم', 'Emergency treatment of botulism'),
    ('1403-12', 106): ('toxin-mediated', 'پیشگیری کزاز پس از زخم', 'Post-wound tetanus prophylaxis'),
    ('1403-12', 107): ('bone-joint', 'آبسه اپی‌دورال و MRSA', 'Epidural abscess and MRSA'),
    ('1403-12', 108): ('respiratory', 'آبسه ریه و آسپیراسیون', 'Lung abscess and aspiration'),
    # Khordad-1402 — official key (both ministry key scans agreed 9/9) and
    # official English booklet. Nine items; numbering follows the printing that
    # includes the floating questions.
    ('1402-03', 122): ('zoonoses', 'تظاهرات بالینی لپتوسپیروز', 'Clinical features of leptospirosis'),
    ('1402-03', 123): ('respiratory', 'تعیین محل بستری در پنومونی', 'Site-of-care decision in pneumonia'),
    ('1402-03', 124): ('parasitic', 'استرونژیلوئیدس و larva currens', 'Strongyloides and larva currens'),
    ('1402-03', 125): ('gi-infection', 'باکتریمی شیگلا در نقص ایمنی', 'Shigella bacteraemia in immunodeficiency'),
    ('1402-03', 126): ('respiratory', 'طول درمان آبسه ریه', 'Duration of lung abscess therapy'),
    ('1402-03', 127): ('tuberculosis', 'تشخیص سل میلیاری', 'Diagnosis of miliary tuberculosis'),
    ('1402-03', 128): ('cns-infection', 'افتراق مننژیت از انسفالیت', 'Distinguishing meningitis from encephalitis'),
    ('1402-03', 129): ('skin-soft', 'پروفیلاکسی گازگرفتگی انسان', 'Human-bite prophylaxis'),
    ('1402-03', 130): ('sti-viral', 'پیشگیری واریسلا در بارداری', 'Varicella prophylaxis in pregnancy'),
    # Esfand-1400 — official Persian AND English booklets; the ministry key for
    # this sitting is not public, so the answers are derived from Harrison.
    ('1400-12', 122): ('tuberculosis', 'آستانه‌های تفسیر PPD', 'PPD interpretation thresholds'),
    ('1400-12', 123): ('gi-infection', 'مایع‌درمانی در وبا', 'Fluid therapy in cholera'),
    ('1400-12', 124): ('endocarditis', 'اندیکاسیون پروفیلاکسی اندوکاردیت', 'Indications for endocarditis prophylaxis'),
    ('1400-12', 125): ('cns-infection', 'عوامل مننژیت نوزادی', 'Pathogens of neonatal meningitis'),
    ('1400-12', 126): ('parasitic', 'کرم قلابدار و آنمی فقر آهن', 'Hookworm and iron-deficiency anaemia'),
    ('1400-12', 127): ('skin-soft', 'گرانولوم آکواریوم', 'Aquarium granuloma'),
    ('1400-12', 128): ('tuberculosis', 'عوارض داروهای ضدسل', 'Toxicity of anti-tuberculosis drugs'),
    ('1400-12', 129): ('cns-infection', 'تفسیر CSF و انسفالیت HSV', 'CSF interpretation and HSV encephalitis'),
    ('1400-12', 130): ('bone-joint', 'محرک‌های آرتریت راکتیو', 'Triggers of reactive arthritis'),
    # Shahrivar-1400 — official booklet text via the all-subjects archive;
    # answers derived from Harrison and double-checked.
    ('1400-06', 122): ('toxin-mediated', 'پروفیلاکسی کزاز در ایمنی کامل', 'Tetanus prophylaxis with full immunity'),
    ('1400-06', 123): ('sepsis-febrile', 'ارزیابی اولیه تب با منشأ نامعلوم', 'Initial work-up of fever of unknown origin'),
    ('1400-06', 124): ('skin-soft', 'سلولیت آب شیرین و آئروموناس', 'Fresh-water cellulitis and Aeromonas'),
    ('1400-06', 125): ('zoonoses', 'درمان بروسلوز در بارداری', 'Treatment of brucellosis in pregnancy'),
    ('1400-06', 126): ('sti-viral', 'پروفیلاکسی فرصت‌طلب بر پایه CD4', 'CD4-based opportunistic prophylaxis'),
    ('1400-06', 127): ('sti-viral', 'سندرم رمزی هانت', 'Ramsay Hunt syndrome'),
    ('1400-06', 128): ('zoonoses', 'سندرم وایل و لپتوسپیروز شدید', 'Weil syndrome and severe leptospirosis'),
    ('1400-06', 129): ('gi-infection', 'اسهال خونی و EHEC', 'Bloody diarrhoea and EHEC'),
    ('1400-06', 130): ('tuberculosis', 'هپاتوتوکسیسیته داروهای ضدسل', 'Hepatotoxicity of anti-TB drugs'),
    # Esfand-1401
    ('1401-12', 122): ('endocarditis', 'باکتریمی استاف و اندیکاسیون اکو', 'Staph bacteraemia and echo indication'),
    ('1401-12', 123): ('tuberculosis', 'درمان سل در بارداری', 'Tuberculosis treatment in pregnancy'),
    ('1401-12', 124): ('gi-infection', 'درمان شیگلوز', 'Treatment of shigellosis'),
    ('1401-12', 125): ('sti-viral', 'تست هتروفیل در مونونوکلئوز', 'Heterophile test in mononucleosis'),
    ('1401-12', 126): ('zoonoses', 'تشخیص عود بروسلوز', 'Diagnosing relapsed brucellosis'),
    ('1401-12', 127): ('toxin-mediated', 'پروفیلاکسی کزاز پس از گازگرفتگی', 'Tetanus prophylaxis after a bite'),
    ('1401-12', 128): ('uti', 'اقدامات ضروری در پیلونفریت', 'Essential steps in pyelonephritis'),
    ('1401-12', 129): ('respiratory', 'پنومونی باکتریال پس از آنفلوانزا', 'Post-influenza bacterial pneumonia'),
    ('1401-12', 130): ('cns-infection', 'درمان تجربی مننژیت در بالغ سالم', 'Empirical meningitis therapy in a healthy adult'),
    # Khordad-1400
    ('1400-03', 122): ('sti-viral', 'درمان شریک جنسی در سرویسیت', 'Partner treatment in cervicitis'),
    ('1400-03', 123): ('endocarditis', 'پروفیلاکسی اندوکاردیت در آلرژی پنی‌سیلین', 'Endocarditis prophylaxis with penicillin allergy'),
    ('1400-03', 124): ('gi-infection', 'اسهال التهابی در برابر غیرالتهابی', 'Inflammatory versus non-inflammatory diarrhoea'),
    ('1400-03', 125): ('toxin-mediated', 'آستانه‌های یادآور کزاز', 'Tetanus booster thresholds'),
    ('1400-03', 126): ('cns-infection', 'پوشش لیستریا بالای ۵۰ سال', 'Listeria cover above age 50'),
    ('1400-03', 127): ('zoonoses', 'پروفیلاکسی پس از تماس با واکسن بروسلوز', 'Prophylaxis after brucellosis vaccine exposure'),
    ('1400-03', 128): ('respiratory', 'پنومونی ثانویه پس از آنفلوانزا', 'Secondary pneumonia after influenza'),
    ('1400-03', 129): ('bone-joint', 'افتراق اسپوندیلیت سلی از بروسلایی', 'Tuberculous versus brucellar spondylitis'),
    ('1400-03', 130): ('tuberculosis', 'ترومبوسیتوپنی ناشی از ریفامپین', 'Rifampin-induced thrombocytopenia'),
    # Shahrivar-1401
    ('1401-06', 122): ('zoonoses', 'محل تزریق واکسن هاری', 'Rabies vaccine injection site'),
    ('1401-06', 123): ('uti', 'پیشگیری از عفونت ادراری مرتبط با سوند', 'Preventing catheter-associated UTI'),
    ('1401-06', 124): ('gi-infection', 'مایع‌درمانی در اسهال ترشحی شدید', 'Fluid therapy in severe secretory diarrhoea'),
    ('1401-06', 125): ('gi-infection', 'درمان اسهال مسافران التهابی', 'Treating inflammatory traveller diarrhoea'),
    ('1401-06', 126): ('zoonoses', 'طول درمان بروسلوز', 'Duration of brucellosis therapy'),
    ('1401-06', 127): ('sepsis-febrile', 'اصول پروفیلاکسی جراحی', 'Principles of surgical prophylaxis'),
    ('1401-06', 128): ('sti-viral', 'واریسلای نوزادی و پنجره‌ی پرخطر', 'Neonatal varicella and the high-risk window'),
    ('1401-06', 129): ('sti-viral', 'پروفیلاکسی چندلایه در HIV', 'Layered prophylaxis in HIV'),
    ('1401-06', 130): ('tuberculosis', 'تعریف سل مقاوم به چند دارو', 'Definition of multidrug-resistant TB'),
    # Shahrivar-1403
    ('1403-06', 123): ('tuberculosis', 'پیوری استریل و سل ادراری', 'Sterile pyuria and urinary tuberculosis'),
    ('1403-06', 124): ('respiratory', 'معیارهای شدت پنومونی و بستری در ICU', 'Pneumonia severity criteria and ICU admission'),
    ('1403-06', 125): ('endocarditis', 'گروه‌های واجد پروفیلاکسی اندوکاردیت', 'Groups eligible for endocarditis prophylaxis'),
    ('1403-06', 126): ('uti', 'استثناهای درمان باکتریوری بدون علامت', 'Exceptions for treating asymptomatic bacteriuria'),
    ('1403-06', 127): ('cns-infection', 'پروفیلاکسی تماس با مننگوکوک', 'Meningococcal post-exposure prophylaxis'),
    ('1403-06', 128): ('bone-joint', 'افتراق اسپوندیلیت سلی از بروسلایی در MRI', 'Tuberculous versus brucellar spondylitis on MRI'),
    ('1403-06', 129): ('bone-joint', 'اقدام اول در آرتریت سپتیک', 'First step in septic arthritis'),
    ('1403-06', 130): ('sti-viral', 'کاهش انتقال عمودی هپاتیت B', 'Reducing vertical transmission of hepatitis B'),
    ('1403-06', 131): ('endocarditis', 'کمپلکس ایمنی و اندوکاردیت تحت‌حاد', 'Immune complexes and subacute endocarditis'),
    # Khordad-1403
    ('1403-03', 123): ('cns-infection', 'مننژیت در نقص ایمنی سلولی و لیستریا', 'Meningitis with cellular immunodeficiency and Listeria'),
    ('1403-03', 124): ('sepsis-febrile', 'تعریف Sepsis-3', 'The Sepsis-3 definition'),
    ('1403-03', 125): ('tuberculosis', 'غربالگری سل در محیط پرازدحام', 'Tuberculosis screening in a congregate setting'),
    ('1403-03', 126): ('tuberculosis', 'اندیکاسیون تست HIV در بیمار سلی', 'HIV testing indication in tuberculosis'),
    ('1403-03', 127): ('tuberculosis', 'آستانه PPD در ایدز', 'PPD threshold in AIDS'),
    ('1403-03', 128): ('toxin-mediated', 'کزاز در واکسیناسیون ناکافی', 'Tetanus with incomplete vaccination'),
    ('1403-03', 129): ('skin-soft', 'پروفیلاکسی گازگرفتگی گربه با آلرژی', 'Cat-bite prophylaxis with allergy'),
    ('1403-03', 130): ('uti', 'سیستیت بدون عارضه در زن جوان', 'Uncomplicated cystitis in a young woman'),
    ('1403-03', 131): ('respiratory', 'تفسیر گرافی قفسه سینه', 'Interpreting the chest radiograph'),
    # Esfand-1402
    ('1402-12', 122): ('respiratory', 'لژیونلا و پنومونی همراه با اسهال', 'Legionella and pneumonia with diarrhoea'),
    ('1402-12', 123): ('respiratory', 'ریشه‌کنی جمعی فارنژیت استرپتوکوکی', 'Mass eradication of streptococcal pharyngitis'),
    ('1402-12', 124): ('gi-infection', 'سالمونلا در بیماری سلول داسی‌شکل', 'Salmonella in sickle cell disease'),
    ('1402-12', 125): ('endocarditis', 'پروفیلاکسی اندوکاردیت با آلرژی پنی‌سیلین', 'Endocarditis prophylaxis with penicillin allergy'),
    ('1402-12', 126): ('respiratory', 'انتخاب ضدویروسی در آنفلوانزای شدید', 'Choosing an antiviral in severe influenza'),
    ('1402-12', 127): ('sti-viral', 'افتراق زخم‌های تناسلی', 'Differentiating genital ulcers'),
    ('1402-12', 128): ('uti', 'باکتریوری بدون علامت در دیابت', 'Asymptomatic bacteriuria in diabetes'),
    ('1402-12', 129): ('bone-joint', 'آرتریت سپتیک در معتاد تزریقی', 'Septic arthritis in injection drug use'),
    ('1402-12', 130): ('tuberculosis', 'سل نهفته در بارداری با تماس اخیر', 'Latent tuberculosis in pregnancy after recent contact'),
    # Shahrivar-1402
    ('1402-06', 126): ('sti-viral', 'پروفیلاکسی واریسلا در بارداری', 'Varicella prophylaxis in pregnancy'),
    ('1402-06', 127): ('zoonoses', 'درمان نوروبروسلوز', 'Treatment of neurobrucellosis'),
    ('1402-06', 128): ('bone-joint', 'محرک‌های آرتریت راکتیو', 'Triggers of reactive arthritis'),
    ('1402-06', 129): ('endocarditis', 'محدودیت تست‌ها در رد اندوکاردیت', 'Limits of tests in excluding endocarditis'),
    ('1402-06', 130): ('tuberculosis', 'داروهای خط اول و خط دوم سل', 'First-line versus second-line TB drugs'),
    ('1402-06', 131): ('respiratory', 'تفسیر تست سریع آنتی‌ژن استرپتوکوک', 'Interpreting the rapid streptococcal antigen test'),
    ('1402-06', 133): ('toxin-mediated', 'محورهای درمان کزاز', 'Pillars of tetanus treatment'),
    ('1402-06', 134): ('toxin-mediated', 'مکانیسم بوتولیسم غذایی', 'Mechanism of foodborne botulism'),
}

MONTH_EN = {'فروردین': 'Farvardin', 'اردیبهشت': 'Ordibehesht', 'خرداد': 'Khordad', 'تیر': 'Tir',
            'مرداد': 'Mordad', 'شهریور': 'Shahrivar', 'مهر': 'Mehr', 'آبان': 'Aban',
            'آذر': 'Azar', 'دی': 'Dey', 'بهمن': 'Bahman', 'اسفند': 'Esfand'}
SITTING_OF_MONTH = {'شهریور': 'main', 'اسفند': 'main'}


def fingerprint(q):
    """Stable dedupe key — same idea as the neurology bank so a question that
       somehow appears in both banks is still recognised as one item."""
    txt = re.sub(r'[۰-۹0-9]', '#', q['stem_fa'])
    txt = re.sub(r'[^\w\s#]', ' ', txt)
    txt = re.sub(r'\s+', ' ', txt).strip()
    return f"{SUBJECT_FA} {SUBJECT_EN} {txt}"[:400]


def year_num(y):
    n = int(re.sub(r'[^0-9]', '', y.translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹', '0123456789'))))
    return n if n > 1000 else 1300 + n


def _norm_stem(s):
    s = (s or '').translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', '01234567890123456789'))
    s = s.replace('\u200c', '').replace('ي', 'ی').replace('ك', 'ک')
    s = re.sub(r'[^\w\s]', ' ', s)
    return re.sub(r'\s+', ' ', s).strip()


def _similar(a, b):
    """Trigram overlap. The ministry re-uses a vignette across sittings with
       different distractors, so these are NOT duplicates — but a learner should
       not meet two near-identical stems back to back."""
    ta = {a[i:i + 3] for i in range(len(a) - 2)}
    tb = {b[i:i + 3] for i in range(len(b) - 2)}
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / min(len(ta), len(tb))


def space_out_repeats(items, threshold=0.75):
    """Reorder questions inside one chapter so near-identical stems are as far
       apart as possible. Greedy: repeatedly take the candidate least similar to
       the item just placed. Stable for unrelated items, so ordering by sitting
       is preserved everywhere the stems differ."""
    if len(items) < 3:
        return items
    norms = {id(it): _norm_stem(it['question_fa']) for it in items}
    out, pool = [items[0]], items[1:]
    while pool:
        prev = norms[id(out[-1])]
        best_i, best_s = 0, 2.0
        for i, cand in enumerate(pool):
            s = _similar(prev, norms[id(cand)])
            if s < best_s - 1e-9:
                best_i, best_s = i, s
            if best_s <= threshold and s <= threshold:
                # first candidate that is comfortably dissimilar wins, which
                # keeps the original sitting order for ordinary questions
                best_i, best_s = i, s
                break
        out.append(pool.pop(best_i))
    return out


def build():
    lessons = {}
    lp = os.path.join(HERE, 'lessons')
    for f in sorted(glob.glob(os.path.join(lp, '*.json'))):
        lessons.update(json.load(io.open(f, encoding='utf-8')))

    questions = []
    for f in sorted(glob.glob(os.path.join(OUT, 'inf_*.json'))):
        questions += json.load(io.open(f, encoding='utf-8'))
    questions.sort(key=lambda q: (year_num(q['exam'].split()[-1]), q['question_no']))

    payload, skipped = [], 0
    # count questions per chapter so lessons stay a sane size
    per_chapter = {}
    for q in questions:
        tag, no = q['exam_tag'], q['question_no']
        key = f'{tag}:{no}'
        les = lessons.get(key)
        if not les:
            skipped += 1
            continue
        slug, cfa, cen = CONCEPT_OF[(tag, no)]
        chap_fa, chap_en = CHAPTERS[slug]
        month = q['exam'].split()[0]
        year = q['exam'].split()[-1]
        per_chapter[chap_fa] = per_chapter.get(chap_fa, 0) + 1

        item = {
            'question_no': no,
            'chapter_fa': chap_fa, 'chapter_en': chap_en,
            'question_fa': q['stem_fa'],
            'question_en': q.get('stem_en') or '',
            'options_fa': q['options_fa'],
            'options_en': q.get('options_en') or [],
            'options_why_fa': les.get('why_fa', []),
            'options_why_en': les.get('why_en', []),
            'correct_index': q['correct_index'],
            'explanation_fa': les.get('explanation_fa', ''),
            'explanation_en': les.get('explanation_en', ''),
            'year': year, 'month': month,
            'sitting': SITTING_OF_MONTH.get(month, 'midterm'),
            'question_style': les.get('style', 'case'),
            'difficulty': les.get('difficulty', 'medium'),
            'lesson_part': 1,  # assigned below, after repeats are spaced out
            'micro': les.get('micro'),
            'concept': slug, 'concept_fa': cfa, 'concept_en': cen,
            'refs': les.get('refs', []),
            'golden_fa': les.get('golden_fa', ''), 'golden_en': les.get('golden_en', ''),
            'key_source': q.get('key_source', 'derived_harrison'),
            'key_rationale': q.get('key_rationale', ''),
            'en_source': q.get('en_source', ''),
            'fingerprint': fingerprint(q),
            'license': 'public_past_exam_review_required',
        }
        payload.append(item)

    # The ministry re-uses some vignettes across sittings with different
    # distractors. Those are legitimately different questions, but two of them
    # side by side in one lesson would read as a copy-paste error to a student.
    # Space them out within their chapter, then number the lesson parts.
    by_chapter = {}
    for it in payload:
        by_chapter.setdefault(it['chapter_fa'], []).append(it)
    ordered = []
    for chap in by_chapter:
        seq = space_out_repeats(by_chapter[chap])
        norms = [_norm_stem(it['question_fa']) for it in seq]
        parts = {}          # part number -> list of normalised stems already in it
        for i, it in enumerate(seq):
            want = (i // 8) + 1
            # walk forward until we find a part holding nothing near-identical,
            # so a re-used vignette and its variant always land in different
            # lessons even when the whole chapter would otherwise fit in one
            p = want
            while any(_similar(norms[i], s) >= 0.75 for s in parts.get(p, [])):
                p += 1
            parts.setdefault(p, []).append(norms[i])
            it['lesson_part'] = p
        ordered += seq
    # keep the file itself in exam order; lesson_part carries the pedagogy
    ordered.sort(key=lambda it: (year_num(it['year']), it['question_no']))
    payload = ordered

    body = {
        'program': 'preint',
        'subject_fa': SUBJECT_FA, 'subject_en': SUBJECT_EN,
        'subject_track': SUBJECT_TRACK,
        'exam_type': 'پره‌انترنی',
        'maxPerLesson': 8,
        'questions': payload,
    }
    dest = os.path.join(HERE, 'import-payload.json')
    json.dump(body, io.open(dest, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    size = os.path.getsize(dest) / 1024 / 1024
    print(f'questions: {len(payload)} | skipped (no lesson yet): {skipped}')
    print(f'chapters: {len(per_chapter)} -> ' + ', '.join(f'{k}={v}' for k, v in per_chapter.items()))
    print(f'payload: {dest} ({size:.2f} MB)')
    if size > 1.9:
        print('  ⚠️  over the 2 MB body limit — split before uploading')
    return body


if __name__ == '__main__':
    build()
