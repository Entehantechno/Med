# -*- coding: utf-8 -*-
"""Extract the 'تست تمرینی بیماری‌های عفونی' book (315 pages, ~1000 questions).

Why this needs its own extractor
--------------------------------
Unlike the ministry booklets, this book ships the OFFICIAL ANSWER with every
question, printed as a line "اینم جوابش" followed by the letter (الف/ب/ج/د).
That is enormously valuable: our existing infectious bank had to derive 86 of
its 101 answers from Harrison. Here the key is stated.

It also carries the provenance of each item in the stem tail, e.g.
"(پره‌انترنی اسفند 94- قطب آزاد)" — sitting, year and regional pole.

Structure per question:
    سوال N
    <stem lines, ending with (پره‌انترنی <month> <year>- قطب <pole>)>
    ( الف ) option A
    ( ب ) option B
    ( ج ) option C
    ( د ) option D
    اینم جوابش
    <answer letter>

Numbers
-------
Same visual-order trap as the booklets, handled by extract_rtl.unreverse. One
extra case appears here that the booklet rules miss: a slash-joined vital sign
glued directly to Persian ("فشار خون 06/58") is mirrored as a whole, so the
"touching Persian => leave alone" rule wrongly protects it. Blood pressure has
a self-check — systolic > diastolic, both in physiological range — so we can
repair it without guessing.
"""
import json, io, os, re, sys, unicodedata
import pdfplumber

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from extract_rtl import unreverse, fold, is_visual

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = '/home/user/uploads/بیماری عفونی.pdf'

Q_START = re.compile(r'^سوال\s+(\d+)\s*$')
OPT = re.compile(r'^\(\s*(الف|ب|ج|د)\s*\)\s*(.*)$')
ANS_MARK = re.compile(r'^اینم\s+جوابش\s*$')
ANS_LETTER = re.compile(r'^\s*(ال\s*ف|الف|ب|ج|د)\s*$')
NOISE = re.compile(r'^(لینک عضویت|https?:|-\s*\d+\s*-$|^\d+\s*$)')

LETTER_IX = {'الف': 0, 'ب': 1, 'ج': 2, 'د': 3}

# (پره‌انترنی اسفند 94- قطب آزاد)  /  (پره‌انترنی اردیبهشت 97- میان‌دوره‌ی کشوری)
#
# The PDF sprinkles stray spaces inside words ("ش هریور", "اسف ند", "قط ب"),
# so the month cannot be matched as one token. We therefore capture the whole
# parenthesised tail and de-space it before reading month/year/pole out of it.
# Some items cite two sittings ("شهریور 93- قطب تهران و اسفند 93- مشترک کشوری");
# the first is recorded and the raw tail kept for reference.
PROV = re.compile(r'\(\s*پر\s*ه?\s*ا\s*ن\s*ت\s*ر\s*ن\s*ی\s*([^)]*)\)')

MONTHS = ('فروردین اردیبهشت خرداد تیر مرداد شهریور مهر آبان آذر دی بهمن اسفند').split()


def despace(s):
    """Drop the stray intra-word spaces this exporter injects."""
    return re.sub(r'\s+', '', s)


def fix_bp(s):
    """Repair mirrored blood-pressure pairs glued to Persian text.

    "فشار خون 06/58" is really 85/60. The pair is self-checking: after flipping
    each side we require systolic 60..260, diastolic 30..160, systolic >
    diastolic. Only rewrite when the flipped reading passes and the original
    does not, so a correctly-printed value is never touched.
    """
    def rep(m):
        a, b = m.group(1), m.group(2)
        ra, rb = a[::-1], b[::-1]

        def ok(x, y):
            try:
                x, y = int(x), int(y)
            except ValueError:
                return False
            return 60 <= x <= 260 and 30 <= y <= 160 and x > y

        if ok(a, b):
            return m.group(0)
        if ok(ra, rb):
            return f'{ra}/{rb}'
        return m.group(0)

    return re.sub(r'(?<![0-9])(\d{2,3})/(\d{2,3})(?![0-9])', rep, s)


def clean(line):
    s = line.strip()
    s = re.sub(r'\s+', ' ', s)
    return s


def page_lines(pdf_page):
    t = pdf_page.extract_text() or ''
    if not t.strip():
        return []
    t = fold(t)
    vis = is_visual(t)
    out = []
    for raw in t.split('\n'):
        ln = unreverse(raw) if vis else raw
        ln = fix_bp(clean(ln))
        if not ln or NOISE.match(ln):
            continue
        out.append(ln)
    return out


def parse(lines):
    """Walk the flat line stream and cut it into questions.

    Chapter headings are identified structurally rather than by a hard-coded
    list: the book prints the chapter title on its own line and follows it with
    "خودآزمایی" (self-test). That two-line signature is unambiguous, so every
    question inherits the last heading seen.
    """
    qs, cur = [], None
    chapter = ''
    prev = ''
    mode = 'stem'          # stem -> options -> awaiting answer
    for ln in lines:
        if ln == 'خودآزمایی':
            # the line before it was the chapter title
            if prev and not Q_START.match(prev) and not OPT.match(prev):
                chapter = prev
            prev = ln
            continue
        _prev, prev = prev, ln
        m = Q_START.match(ln)
        if m:
            if cur:
                qs.append(cur)
            cur = {'no': int(m.group(1)), 'stem': [], 'opts': {}, 'ans': None,
                   'chapter': chapter}
            mode = 'stem'
            continue
        if cur is None:
            continue

        mo = OPT.match(ln)
        if mo:
            mode = 'options'
            cur['_last'] = LETTER_IX[mo.group(1)]
            cur['opts'][cur['_last']] = mo.group(2).strip()
            continue

        if ANS_MARK.match(ln):
            mode = 'answer'
            continue

        if mode == 'answer':
            ma = ANS_LETTER.match(ln)
            if ma and cur['ans'] is None:
                cur['ans'] = LETTER_IX[ma.group(1).replace(' ', '')]
            continue

        if mode == 'stem':
            cur['stem'].append(ln)
        elif mode == 'options' and '_last' in cur:
            # option text wrapped onto the next line
            cur['opts'][cur['_last']] += ' ' + ln
    if cur:
        qs.append(cur)
    return qs


def finish(q):
    stem = ' '.join(q['stem']).strip()
    prov = {}
    mp = PROV.search(stem)
    if mp:
        tail = mp.group(1)
        flat = despace(tail)
        my = re.search(r'(' + '|'.join(MONTHS) + r')(\d{2,4})', flat)
        if my:
            y = int(my.group(2))
            if y < 100:
                y += 1300
            if 1380 <= y <= 1410:
                pole = ''
                mpole = re.search(r'قطب([\u0600-\u06FF\u200c]+)', flat)
                if mpole:
                    pole = mpole.group(1)
                elif 'کشوری' in flat:
                    pole = 'کشوری'
                prov = {'month': my.group(1), 'year': y, 'pole': pole,
                        'source_note': re.sub(r'\s+', ' ', tail).strip()}
                stem = stem[:mp.start()].strip()
    stem = re.sub(r'\s+', ' ', stem).strip(' :.-')
    opts = [q['opts'].get(i, '').strip() for i in range(4)]
    return {
        'book_no': q['no'],
        'book_chapter': q.get('chapter', ''),
        'stem_fa': stem,
        'options_fa': opts,
        'correct_index': q['ans'],
        **prov,
    }


def main():
    lines = []
    with pdfplumber.open(SRC) as pdf:
        for p in pdf.pages:
            lines += page_lines(p)
    raw = parse(lines)
    qs = [finish(q) for q in raw]

    ok = [q for q in qs
          if q['stem_fa'] and q['correct_index'] is not None
          and all(q['options_fa']) and len(set(q['options_fa'])) == 4]
    bad = [q for q in qs if q not in ok]

    os.makedirs(os.path.join(HERE, 'out'), exist_ok=True)
    dest = os.path.join(HERE, 'out', 'book_raw.json')
    json.dump(ok, io.open(dest, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

    withprov = sum(1 for q in ok if q.get('year'))
    print(f'lines: {len(lines)}  parsed: {len(qs)}  usable: {len(ok)}  dropped: {len(bad)}')
    print(f'with provenance (sitting/year): {withprov}')
    import collections
    yc = collections.Counter(q.get('year') for q in ok if q.get('year'))
    print('years: ' + ', '.join(f'{k}={v}' for k, v in sorted(yc.items())))
    ac = collections.Counter(q['correct_index'] for q in ok)
    print('answer spread: ' + ', '.join(f'{k}={ac[k]}' for k in range(4)))
    print('->', dest)
    if bad[:3]:
        print('\nsample dropped:')
        for q in bad[:3]:
            print(' ', q['book_no'], (q['stem_fa'] or '')[:70], '| ans', q['correct_index'],
                  '| opts', sum(1 for o in q['options_fa'] if o))


if __name__ == '__main__':
    main()
