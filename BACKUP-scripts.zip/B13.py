# -*- coding: utf-8 -*-
"""Micro-lessons, batch 13 — genital ulcers, urethritis and syphilis.

160 questions with six taught: the largest remaining gap in the book. And the
gap is worth closing carefully, because this chapter is unusually repetitive in
a useful way. The same three or four discriminations are asked over and over in
slightly different words, so a student who genuinely learns them answers dozens
of questions rather than one.

Three teaching spines
---------------------
1. THE GENITAL ULCER TABLE. Almost every ulcer question in this chapter is
   settled by two questions asked in order: IS IT PAINFUL, and IS IT SOFT? A
   painless, hard, clean ulcer is syphilis; a painful, soft, ragged, purulent
   one is chancroid; painful grouped vesicles are herpes; and a small ulcer that
   HEALS BEFORE the enormous painful nodes appear is LGV. That single table
   answers idx 529-533, 544, 556-558, 606-608 — eleven questions.

2. CEFTRIAXONE DOES NOT TREAT CHLAMYDIA. This chapter asks the consequence of
   that one sentence at least six times, always as a relapse a week or two after
   apparently successful treatment of gonorrhoea. It is also where the chapter's
   one wrong printed key lives, and the wrongness is provable from the book's own
   other four answers.

3. SYPHILIS SEROLOGY HAS TWO KINDS OF TEST AND THEY DO DIFFERENT JOBS. The
   non-treponemal test (VDRL/RPR) has a TITRE, so it is the one that follows
   treatment; the treponemal test (FTA-ABS/TPHA) stays positive for life, so it
   can confirm but can never say whether therapy worked.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022),
Chapters 155 (gonococcus), 178 (chlamydia), 182 (syphilis), 187 (H. ducreyi);
CDC Sexually Transmitted Infections Treatment Guidelines, 2021.
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H155 = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 155"
H178 = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 178"
H182 = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 182"
CDC = "CDC Sexually Transmitted Infections Treatment Guidelines, 2021"

# The ulcer table, repeated verbatim in every ulcer lesson so the student meets
# identical wording each time and it becomes automatic.
ULCER_FA = [
    "برای هر **زخم تناسلی**، فقط دو سؤال بپرسید و تقریباً همیشه به جواب می‌رسید.",
    "**سؤال یک: دردناک است یا بدون درد؟**",
    "**سؤال دو: نرم است یا سفت؟**",
    "**سیفلیس (شانکر)**: **بدون درد**، **سفت** (قوام غضروفی)، لبه‌ی منظم، کف **تمیز**، منفرد.",
    "غدد لنفاوی سیفلیس هم **بدون درد** و اغلب **دوطرفه** و لاستیکی است.",
    "**شانکروئید**: **دردناک**، **نرم**، لبه‌ی **نامنظم**، کف **چرکی** که با سوآب خونریزی می‌کند.",
    "غدد شانکروئید **دردناک، یک‌طرفه** و مستعد **چرکی شدن** (بوبو) است.",
    "پس شانکروئید در همه‌چیز نقطه‌ی مقابل سیفلیس است — به آن «شانکر نرم» می‌گویند.",
    "**هرپس**: **وزیکول‌های گروهی** روی زمینه‌ی قرمز که می‌ترکند و زخم‌های **سطحی و بسیار دردناک** می‌سازند.",
    "هرپس اولیه علائم **سیستمیک** هم دارد: تب، سردرد، میالژی — و لنفادنوپاتی **دوطرفه‌ی دردناک**.",
    "⚠️ نکته‌ی افتراقی هرپس از شانکروئید: هرپس **وزیکول** دارد و زخم‌هایش **سطحی**‌اند؛ شانکروئید از اول **پوستولر و عمیق** است.",
    "**LGV (لنفوگرانولوم ونروم)**: زخم اولیه **کوچک، بدون درد** و **زودگذر** است.",
    "⚠️ و کل نکته‌ی LGV همین است: تا وقتی بیمار مراجعه می‌کند، **زخم خوب شده** و فقط غدد بزرگ و دردناک مانده‌اند.",
    "پس هر بیماری که می‌گوید «چند هفته پیش یک زخم کوچک داشتم که خودبه‌خود خوب شد» و حالا **بوبوی دردناک** دارد، LGV است.",
    "**دونووانوزیس**: زخم **بدون درد** ولی **گوشتی و پرخون** که به‌راحتی خونریزی می‌کند و **لنفادنوپاتی ندارد**.",
]
ULCER_EN = [
    "For any GENITAL ULCER, ask just two questions and you will almost always arrive at the answer.",
    "QUESTION ONE: is it PAINFUL or PAINLESS?",
    "QUESTION TWO: is it SOFT or HARD?",
    "SYPHILIS (chancre): PAINLESS, HARD (cartilaginous), regular edge, CLEAN base, single.",
    "The nodes in syphilis are also PAINLESS, often BILATERAL and rubbery.",
    "CHANCROID: PAINFUL, SOFT, RAGGED edge, PURULENT base that bleeds when swabbed.",
    "The nodes in chancroid are PAINFUL, UNILATERAL and liable to SUPPURATE (a bubo).",
    "So chancroid is the opposite of syphilis in every respect — hence its name, the soft chancre.",
    "HERPES: GROUPED VESICLES on an erythematous base that rupture into SHALLOW, intensely PAINFUL ulcers.",
    "Primary herpes also has SYSTEMIC features — fever, headache, myalgia — with PAINFUL BILATERAL nodes.",
    "WARNING, herpes versus chancroid: herpes has VESICLES and its ulcers are SHALLOW; chancroid is PUSTULAR AND DEEP from the start.",
    "LGV (lymphogranuloma venereum): the primary ulcer is SMALL, PAINLESS and TRANSIENT.",
    "WARNING, and that is the whole point of LGV: by the time the patient presents THE ULCER HAS HEALED, leaving only huge painful nodes.",
    "So any patient who says 'I had a small sore a few weeks ago that healed by itself' and now has a PAINFUL BUBO has LGV.",
    "DONOVANOSIS: a PAINLESS but BEEFY, highly vascular ulcer that bleeds easily, and WITHOUT lymphadenopathy.",
]


# ---------------------------------------------------------------- idx 529
add("book:529", "case", "easy",
 "زخم **دردناک + نرم + چرکی** با غده‌ی **دردناک یک‌طرفه** = **شانکروئید**.",
 "A PAINFUL, SOFT, PURULENT ulcer with PAINFUL UNILATERAL nodes is CHANCROID.",
 ULCER_FA + [
  "حالا این بیمار را با جدول بسنجید؛ هر جزء صورت سؤال یک ستون از جدول را پر می‌کند.",
  "**دردناک** ✓ — پس سیفلیس و LGV کنار می‌روند (هر دو زخم بدون درد دارند).",
  "**قوام نرم** ✓ — پس سیفلیس قطعاً رد است (شانکر سفت و غضروفی است).",
  "**لبه‌ی نامنظم و کف چرکی** ✓ — کاملاً مشخصه‌ی شانکروئید.",
  "**خونریزی با تماس سوآب** ✓ — کف زخم شانکروئید شکننده و پرعروق است.",
  "**لنفادنوپاتی دردناک یک‌طرفه** ✓ — بوبوی کلاسیک شانکروئید.",
  "عامل بیماری: **هموفیلوس دوکره‌ای** (Haemophilus ducreyi)، یک کوکوباسیل گرم‌منفی.",
  "چرا هرپس نیست؟ چون هرپس **وزیکول** می‌سازد و زخم‌هایش **سطحی**‌اند، نه عمیق و چرکی.",
  "درمان شانکروئید: **آزیترومایسین ۱ گرم تک دوز**، یا سفتریاکسون ۲۵۰ میلی‌گرم عضلانی تک دوز.",
  "گزینه‌های دیگر: سیپروفلوکساسین ۵۰۰ دو بار در روز ۳ روز، یا اریترومایسین ۷ روز.",
  "⚠️ هر بیمار با زخم تناسلی باید از نظر **سیفلیس و HIV** هم بررسی شود؛ همراهی شایع است.",
 ],
 ULCER_EN + [
  "Now test this patient against the table; every element of the stem fills one of its columns.",
  "PAINFUL (yes) — so syphilis and LGV are excluded, since both give painless ulcers.",
  "SOFT (yes) — so syphilis is definitely out, since the chancre is hard and cartilaginous.",
  "RAGGED EDGE AND PURULENT BASE (yes) — entirely characteristic of chancroid.",
  "BLEEDS ON SWAB CONTACT (yes) — the base of a chancroid ulcer is friable and vascular.",
  "PAINFUL UNILATERAL LYMPHADENOPATHY (yes) — the classic chancroid bubo.",
  "The organism is HAEMOPHILUS DUCREYI, a Gram-negative coccobacillus.",
  "Why not herpes? Herpes makes VESICLES and its ulcers are SHALLOW, not deep and purulent.",
  "Treatment of chancroid: AZITHROMYCIN 1 g single dose, or ceftriaxone 250 mg IM single dose.",
  "The alternatives are ciprofloxacin 500 mg twice daily for 3 days, or erythromycin for 7 days.",
  "WARNING: every patient with a genital ulcer must also be tested for SYPHILIS and HIV; co-infection is common.",
 ],
 "این بیمار را با جدول زخم تناسلی بسنجیم — هر جمله‌ی صورت سؤال یک ستون از جدول را پر می‌کند:\n\n• **دردناک** ← سیفلیس و LGV کنار می‌روند\n• **قوام نرم** ← سیفلیس قطعاً رد است (شانکر **سفت** است)\n• **لبه‌ی نامنظم، کف چرکی** ← مشخصه‌ی شانکروئید\n• **خونریزی با تماس سوآب** ← کف شکننده و پرعروق شانکروئید\n• **لنفادنوپاتی دردناک یک‌طرفه** ← بوبوی کلاسیک\n\nپس تشخیص **شانکروئید** است، ناشی از **هموفیلوس دوکره‌ای**.\n\nنام دیگر شانکروئید «**شانکر نرم**» است، و همین نام کل تشخیص افتراقی را در خود دارد: شانکروئید در **هر ویژگی** نقطه‌ی مقابل شانکر سیفلیس است — آن بدون درد و سفت و تمیز است، این دردناک و نرم و چرکی.\n\n⚠️ چرا هرپس نیست؟ چون هرپس با **وزیکول‌های گروهی** شروع می‌شود و زخم‌هایش **سطحی**‌اند؛ اینجا زخم از ابتدا **عمیق و چرکی** است.\n\nدرمان: **آزیترومایسین ۱ گرم تک دوز** یا سفتریاکسون ۲۵۰ میلی‌گرم عضلانی. و همیشه: هر زخم تناسلی را از نظر **سیفلیس و HIV** هم بررسی کنید.",
 "Test this patient against the genital-ulcer table — each sentence of the stem fills one of its columns:\n\n- PAINFUL -> syphilis and LGV are excluded\n- SOFT -> syphilis is definitely out (the chancre is HARD)\n- RAGGED EDGE, PURULENT BASE -> characteristic of chancroid\n- BLEEDS ON SWAB CONTACT -> the friable, vascular chancroid base\n- PAINFUL UNILATERAL NODES -> the classic bubo\n\nThe diagnosis is CHANCROID, caused by HAEMOPHILUS DUCREYI.\n\nChancroid's other name is the SOFT CHANCRE, and that name contains the whole differential: chancroid is the opposite of the syphilitic chancre in EVERY respect — that one is painless, hard and clean; this one is painful, soft and purulent.\n\nWARNING, why not herpes? Herpes begins with GROUPED VESICLES and its ulcers are SHALLOW; here the ulcer is DEEP AND PURULENT from the start.\n\nTreatment: AZITHROMYCIN 1 g single dose or ceftriaxone 250 mg IM. And always: test any genital ulcer for SYPHILIS and HIV as well.",
 ["تب‌خال تناسلی با وزیکول‌های گروهی و زخم‌های سطحی شروع می‌شود، نه زخم عمیق چرکی با قوام نرم.",
  "شانکر سیفلیس بدون درد و سفت با کف تمیز است — دقیقاً نقطه‌ی مقابل این بیمار.",
  "در LGV زخم اولیه کوچک و زودگذر است و تا زمان مراجعه خوب شده؛ اینجا زخم فعال و چرکی است.",
  "پاسخ صحیح — زخم دردناک، نرم، نامنظم و چرکی با بوبوی یک‌طرفه، تابلوی شانکروئید است."],
 ["Genital herpes begins with grouped vesicles and shallow ulcers, not a deep purulent ulcer of soft consistency.",
  "The syphilitic chancre is painless and hard with a clean base — the exact opposite of this patient.",
  "In LGV the primary ulcer is small and transient and has healed by presentation; here the ulcer is active and purulent.",
  "Correct — a painful, soft, ragged, purulent ulcer with a unilateral bubo is the picture of chancroid."],
 "زخم: **بدون درد + سفت = سیفلیس**؛ **دردناک + نرم + چرکی = شانکروئید**؛ وزیکول = هرپس.",
 "Ulcer: PAINLESS + HARD = syphilis; PAINFUL + SOFT + PURULENT = chancroid; vesicles = herpes.",
 [H182, CDC])


# ---------------------------------------------------------------- idx 533
add("book:533", "case", "medium",
 "زخم کوچکی که **خودش خوب شد**، و بعد **بوبوی دردناک** = **LGV**.",
 "A small ulcer that HEALED BY ITSELF, followed by a PAINFUL BUBO, is LGV.",
 ULCER_FA + [
  "این بیمار الگوی **دومرحله‌ای** LGV را به‌طور کامل نشان می‌دهد.",
  "**مرحله‌ی اول**: یک پاپول یا زخم کوچک و **بدون درد** در محل تلقیح.",
  "این زخم آن‌قدر بی‌آزار است که بیمار اغلب اصلاً متوجهش نمی‌شود، و **خودبه‌خود خوب می‌شود**.",
  "**مرحله‌ی دوم**، دو تا شش هفته بعد: **لنفادنیت** بزرگ و دردناک اینگوینال.",
  "⚠️ کل تله‌ی تشخیصی همین فاصله است: وقتی بیمار مراجعه می‌کند، **زخمی وجود ندارد**.",
  "پس اگر فقط دنبال زخم بگردید، LGV را از دست می‌دهید.",
  "غدد در LGV به هم می‌چسبند، ملتهب و اریتماتوند و می‌توانند **فیستوله** شوند.",
  "**علامت شیار (groove sign)**: غدد بالا و پایین رباط اینگوینال، شیاری بینشان می‌سازند.",
  "علائم سیستمیک هم دارد: تب، لرز، بی‌حالی — که این بیمار تب دارد.",
  "عامل: **کلامیدیا تراکوماتیس سروتیپ‌های L1، L2 و L3** — نه سروتیپ‌های اورتریت.",
  "همین تفاوت سروتیپ مهم است: سروتیپ‌های L **مهاجم**‌اند و به غدد لنفاوی می‌روند.",
  "درمان: **داکسی‌سیکلین ۱۰۰ میلی‌گرم دو بار در روز به مدت ۲۱ روز** — دوره‌ی طولانی.",
  "چرا ۲۱ روز؟ چون درگیری بافت لنفاوی عمیق است و دوره‌ی کوتاه کافی نیست.",
  "⚠️ آسپیراسیون بوبو برای جلوگیری از پارگی انجام می‌شود، ولی **برش و درناژ ممنوع** است (فیستول می‌سازد).",
 ],
 ULCER_EN + [
  "This patient shows the TWO-STAGE pattern of LGV in full.",
  "STAGE ONE: a small, PAINLESS papule or ulcer at the site of inoculation.",
  "It is so trivial that the patient often never notices it, and it HEALS SPONTANEOUSLY.",
  "STAGE TWO, two to six weeks later: large, painful inguinal LYMPHADENITIS.",
  "WARNING, the whole diagnostic trap lies in that interval: by presentation THERE IS NO ULCER.",
  "So if you look only for an ulcer, you will miss LGV.",
  "The nodes in LGV become matted, inflamed and erythematous, and can FISTULATE.",
  "The GROOVE SIGN: nodes above and below the inguinal ligament form a groove between them.",
  "There are systemic features too — fever, chills, malaise — and this patient has fever.",
  "The organism is CHLAMYDIA TRACHOMATIS SEROVARS L1, L2 and L3, not the urethritis serovars.",
  "That serovar difference matters: the L serovars are INVASIVE and travel to the lymph nodes.",
  "Treatment: DOXYCYCLINE 100 mg twice daily FOR 21 DAYS — a long course.",
  "Why 21 days? Because the lymphatic tissue involvement is deep and a short course is insufficient.",
  "WARNING: a bubo is ASPIRATED to prevent rupture, but INCISION AND DRAINAGE IS FORBIDDEN (it creates a fistula).",
 ],
 "این بیمار الگوی **دومرحله‌ای** لنفوگرانولوم ونروم را کامل نشان می‌دهد، و کل ارزش سؤال در فهمیدن **فاصله‌ی زمانی** بین دو مرحله است.\n\n**مرحله‌ی اول** یک پاپول یا زخم کوچک و **بدون درد** است — آن‌قدر بی‌آزار که بیمار اغلب اصلاً متوجهش نمی‌شود، و **خودبه‌خود خوب می‌شود**. صورت سؤال دقیقاً همین را می‌گوید: «سابقه‌ی یک زخم کوچک در ناحیه‌ی ژنیتال دو هفته پیش که خودبه‌خود بهبود یافته است.»\n\n**مرحله‌ی دوم**، دو تا شش هفته بعد، **لنفادنیت بزرگ و دردناک اینگوینال** است — همان چیزی که بیمار حالا با آن مراجعه کرده، همراه با تب.\n\n⚠️ و تله‌ی تشخیصی دقیقاً همین‌جاست: **وقتی بیمار می‌آید، زخمی وجود ندارد.** اگر فقط دنبال زخم بگردید LGV را از دست می‌دهید. پس هر بیمار با **بوبوی دردناک** و شرح حال یک زخم گذرا، تا خلاف آن ثابت نشود LGV است.\n\nعامل بیماری **کلامیدیا تراکوماتیس سروتیپ‌های L1، L2 و L3** است — نه سروتیپ‌های اورتریت. سروتیپ‌های L **مهاجم**‌اند و به بافت لنفاوی می‌روند، و همین تفاوت است که تابلوی بیماری را می‌سازد.\n\nدرمان **داکسی‌سیکلین ۱۰۰ میلی‌گرم دو بار در روز به مدت ۲۱ روز** است؛ دوره‌ی طولانی لازم است چون درگیری بافت لنفاوی عمیق است.\n\n⚠️ نکته‌ی جراحی: بوبو را برای جلوگیری از پارگی **آسپیره** می‌کنند، ولی **برش و درناژ ممنوع است** چون فیستول مزمن می‌سازد.",
 "This patient shows the TWO-STAGE pattern of lymphogranuloma venereum in full, and the whole value of the question lies in understanding the INTERVAL between the stages.\n\nSTAGE ONE is a small, PAINLESS papule or ulcer — so trivial that the patient often never notices it, and it HEALS SPONTANEOUSLY. The stem says exactly this: 'a history of a small genital sore two weeks ago that healed by itself'.\n\nSTAGE TWO, two to six weeks later, is large, painful INGUINAL LYMPHADENITIS — which is what has brought the patient in now, with fever.\n\nWARNING, and the diagnostic trap is precisely here: BY THE TIME THE PATIENT ARRIVES THERE IS NO ULCER. If you look only for an ulcer you will miss LGV. So any patient with a PAINFUL BUBO and a history of a transient sore has LGV until proven otherwise.\n\nThe organism is CHLAMYDIA TRACHOMATIS SEROVARS L1, L2 and L3 — not the urethritis serovars. The L serovars are INVASIVE and travel to lymphatic tissue, and that difference is what produces the clinical picture.\n\nTreatment is DOXYCYCLINE 100 mg twice daily FOR 21 DAYS; the long course is needed because the lymphatic involvement is deep.\n\nWARNING, a surgical point: a bubo is ASPIRATED to prevent rupture, but INCISION AND DRAINAGE IS FORBIDDEN, because it creates a chronic fistula.",
 ["در شانکروئید زخم فعال، دردناک و چرکی است و در زمان مراجعه وجود دارد، نه خوب‌شده.",
  "هرپس ژنیتال وزیکول‌های گروهی دردناک می‌دهد و با زخم منفرد بدون درد که خوب شده جور نیست.",
  "شانکر سیفلیس بدون درد است و خودبه‌خود خوب می‌شود، ولی غدد سیفلیس **بدون درد** و لاستیکی‌اند، نه بوبوی دردناک.",
  "پاسخ صحیح — زخم کوچک زودگذر و سپس لنفادنیت بزرگ و دردناک، الگوی دومرحله‌ای LGV است."],
 ["In chancroid the ulcer is active, painful and purulent and is present at presentation, not healed.",
  "Genital herpes gives painful grouped vesicles, inconsistent with a single painless sore that has healed.",
  "The syphilitic chancre is painless and self-healing, but the nodes of syphilis are PAINLESS and rubbery, not a painful bubo.",
  "Correct — a small transient ulcer followed by large painful lymphadenitis is the two-stage pattern of LGV."],
 "LGV = زخم **زودگذر بدون درد** → بعد **بوبوی دردناک**. داکسی‌سیکلین **۲۱ روز**. برش و درناژ ممنوع.",
 "LGV = a TRANSIENT PAINLESS ulcer, then a PAINFUL BUBO. Doxycycline for 21 DAYS. Never incise and drain.",
 [H178, CDC])


# ---------------------------------------------------------------- idx 556
add("book:556", "case", "easy",
 "زخم **بدون درد + سفت + کف تمیز** با غده‌ی **بدون درد** = **شانکر سیفلیس**.",
 "A PAINLESS, HARD ulcer with a CLEAN base and PAINLESS nodes is the SYPHILITIC CHANCRE.",
 ULCER_FA + [
  "این بیمار تصویر کتاب‌درسی **سیفلیس اولیه** است؛ هر جزء را با جدول تطبیق دهید.",
  "**بدون درد** ✓ — همین یک کلمه شانکروئید و هرپس را کنار می‌گذارد.",
  "**قوام سفت و برجسته** ✓ — شانکر «سخت» است، در برابر شانکروئید که «نرم» است.",
  "**بستر تمیز و غیرچرکی** ✓ — شانکر ترشح چرکی ندارد.",
  "**غده‌ی لنفاوی بدون درد** ✓ — لنفادنوپاتی سیفلیس بدون درد و لاستیکی است.",
  "زمان‌بندی هم کمک می‌کند: شانکر معمولاً **سه هفته** (۹ تا ۹۰ روز) پس از تماس ظاهر می‌شود.",
  "⚠️ خطرناک‌ترین ویژگی شانکر این است که **خودبه‌خود ظرف ۳ تا ۶ هفته خوب می‌شود**.",
  "بیمار خیال می‌کند بهبود یافته، ولی بیماری وارد **مرحله‌ی ثانویه** می‌شود.",
  "تشخیص: **میکروسکوپ زمینه‌تاریک** از ترشح زخم، یا تست‌های سرولوژی.",
  "⚠️ نکته: در **هفته‌های اول** سرولوژی ممکن است هنوز **منفی** باشد.",
  "پس منفی بودن VDRL در زخم تازه، سیفلیس را رد نمی‌کند.",
  "درمان سیفلیس اولیه: **پنی‌سیلین G بنزاتین ۲/۴ میلیون واحد عضلانی، تک دوز**.",
 ],
 ULCER_EN + [
  "This patient is the textbook picture of PRIMARY SYPHILIS; match each element to the table.",
  "PAINLESS (yes) — that single word already excludes chancroid and herpes.",
  "HARD, RAISED CONSISTENCY (yes) — the chancre is 'hard', against chancroid's 'soft'.",
  "CLEAN, NON-PURULENT BASE (yes) — the chancre has no purulent discharge.",
  "PAINLESS LYMPH NODE (yes) — syphilitic lymphadenopathy is painless and rubbery.",
  "The timing helps too: the chancre usually appears about THREE WEEKS (9-90 days) after exposure.",
  "WARNING, the chancre's most dangerous property is that IT HEALS SPONTANEOUSLY IN 3-6 WEEKS.",
  "The patient believes he has recovered, while the disease moves into its SECONDARY stage.",
  "Diagnosis: DARK-FIELD MICROSCOPY of the ulcer exudate, or serological tests.",
  "WARNING: in the FIRST WEEKS the serology may still be NEGATIVE.",
  "So a negative VDRL in a fresh ulcer does not exclude syphilis.",
  "Treatment of primary syphilis: BENZATHINE PENICILLIN G 2.4 million units IM, single dose.",
 ],
 "این بیمار تصویر کتاب‌درسی **سیفلیس اولیه** است، و با جدول زخم تناسلی در یک نگاه حل می‌شود:\n\n• **بدون درد** ← شانکروئید و هرپس هر دو کنار می‌روند\n• **سفت و برجسته** ← شانکر «سخت»؛ شانکروئید «نرم» است\n• **بستر تمیز** ← بدون ترشح چرکی\n• **لنف نود بدون درد** ← لنفادنوپاتی سیفلیس بدون درد و لاستیکی است\n\nپس تشخیص **سیفلیس** است.\n\n⚠️ و حالا خطرناک‌ترین ویژگی شانکر که باید حتماً یاد گرفته شود: **شانکر ظرف ۳ تا ۶ هفته خودبه‌خود خوب می‌شود.** بیمار خیال می‌کند بهبود یافته و مراجعه نمی‌کند، در حالی که بیماری خاموش وارد **مرحله‌ی ثانویه** شده است. به همین دلیل بسیاری از بیماران سیفلیس ثانویه اصلاً شانکری به یاد نمی‌آورند.\n\nتشخیص با **میکروسکوپ زمینه‌تاریک** از ترشح زخم یا با سرولوژی است. ⚠️ اما توجه کنید: در هفته‌های نخست ممکن است سرولوژی هنوز **منفی** باشد، پس VDRL منفی در یک زخم تازه، سیفلیس را رد نمی‌کند.\n\nدرمان **پنی‌سیلین G بنزاتین ۲/۴ میلیون واحد عضلانی تک دوز** است.",
 "This patient is the textbook picture of PRIMARY SYPHILIS, and the genital-ulcer table settles it at a glance:\n\n- PAINLESS -> chancroid and herpes both drop out\n- HARD AND RAISED -> the 'hard' chancre; chancroid is 'soft'\n- CLEAN BASE -> no purulent discharge\n- PAINLESS NODE -> syphilitic lymphadenopathy is painless and rubbery\n\nThe diagnosis is SYPHILIS.\n\nWARNING, and now the chancre's most dangerous property, which must be learned: THE CHANCRE HEALS SPONTANEOUSLY IN 3-6 WEEKS. The patient believes he has recovered and does not return, while the disease moves silently into its SECONDARY stage. That is why many patients with secondary syphilis remember no chancre at all.\n\nDiagnosis is by DARK-FIELD MICROSCOPY of the exudate or by serology. WARNING: in the first weeks the serology may still be NEGATIVE, so a negative VDRL in a fresh ulcer does not exclude syphilis.\n\nTreatment is BENZATHINE PENICILLIN G 2.4 million units IM as a single dose.",
 ["شانکروئید زخم دردناک، نرم و چرکی با بوبوی دردناک می‌دهد — نقطه‌ی مقابل این بیمار.",
  "پاسخ صحیح — زخم بدون درد، سفت، با بستر تمیز و غده‌ی بدون درد، شانکر سیفلیس است.",
  "هرپس وزیکول‌های گروهی و زخم‌های سطحی بسیار دردناک می‌سازد، نه زخم منفرد سفت بدون درد.",
  "در LGV زخم اولیه تا زمان مراجعه خوب شده و تابلو را بوبوی دردناک می‌سازد."],
 ["Chancroid gives a painful, soft, purulent ulcer with a painful bubo — the opposite of this patient.",
  "Correct — a painless, hard ulcer with a clean base and a painless node is the syphilitic chancre.",
  "Herpes produces grouped vesicles and shallow, intensely painful ulcers, not a single hard painless ulcer.",
  "In LGV the primary ulcer has healed by presentation and the picture is dominated by a painful bubo."],
 "شانکر سیفلیس: **بدون درد، سفت، تمیز، منفرد** + غده‌ی بدون درد. **خودبه‌خود خوب می‌شود** — و همین خطرناک است.",
 "The syphilitic chancre: PAINLESS, HARD, CLEAN, single, with painless nodes. IT HEALS BY ITSELF — which is the danger.",
 [H182, CDC])


# ---------------------------------------------------------------- idx 559
add("book:559", "case", "medium",
 "راش **کف دست و پا** + زخم بدون درد چند هفته قبل = **سیفلیس ثانویه** ← **پنی‌سیلین بنزاتین تک دوز**.",
 "A rash ON THE PALMS AND SOLES plus a painless ulcer weeks earlier is SECONDARY SYPHILIS: benzathine penicillin, single dose.",
 [
  "**سیفلیس ثانویه** را «مقلد بزرگ» می‌نامند، ولی یک نشانه آن را لو می‌دهد.",
  "⚠️ نشانه‌ی کلیدی: راش ماکولوپاپولر که **کف دست و کف پا را درگیر می‌کند**.",
  "بیماری‌های کمی راش کف دست و پا می‌دهند، و همین فهرست کوتاه، تشخیص را می‌سازد.",
  "راش سیفلیس ثانویه معمولاً **بدون خارش** است — نکته‌ی افتراقی مهم دیگر.",
  "زمان‌بندی: **۲ تا ۱۲ هفته** پس از شانکر، یعنی وقتی زخم اولیه خوب شده است.",
  "این بیمار می‌گوید چهار هفته پیش زخم **بدون درد** داشته — همان شانکر فراموش‌شده.",
  "علائم همراه: تب، گلودرد، بی‌اشتهایی، بی‌حالی — تابلوی شبه‌آنفلوانزا.",
  "**لنفادنوپاتی ژنرالیزه‌ی بدون تندرنس** هم بسیار مشخصه است، و این بیمار دارد.",
  "تظاهرات دیگر: **کندیلوما لاتا** (ضایعات مرطوب و بسیار مسری)، آلوپسی لکه‌ای، پلاک مخاطی.",
  "⚠️ سیفلیس ثانویه **بسیار مسری** است، چون ضایعات پر از ترپونماست.",
  "درمان سیفلیس **اولیه، ثانویه و نهفته‌ی زودرس**: **پنی‌سیلین G بنزاتین ۲/۴ میلیون واحد، تک دوز**.",
  "⚠️ سه دوز هفتگی برای **سیفلیس نهفته‌ی دیررس** یا با طول‌مدت نامعلوم است، نه ثانویه.",
  "چرا این تفاوت؟ چون در مراحل زودرس ترپونما سریع تقسیم می‌شود و به یک دوره‌ی کوتاه پاسخ می‌دهد.",
  "⚠️ پس از تزریق، مراقب **واکنش یاریش-هرکسهایمر** باشید: تب، لرز و بدتر شدن راش ظرف ۲۴ ساعت.",
  "این واکنش از **آزاد شدن انبوه آنتی‌ژن** از ترپونماهای کشته‌شده است، نه آلرژی به پنی‌سیلین.",
  "درمانش حمایتی است (استامینوفن) و **دلیلی برای قطع پنی‌سیلین نیست**.",
 ],
 [
  "SECONDARY SYPHILIS is called the great imitator, but one sign gives it away.",
  "WARNING, the key sign: a maculopapular rash that INVOLVES THE PALMS AND SOLES.",
  "Few diseases put a rash on palms and soles, and that short list makes the diagnosis.",
  "The rash of secondary syphilis is usually NON-ITCHY — another important discriminator.",
  "Timing: 2 to 12 WEEKS after the chancre, that is, once the primary ulcer has healed.",
  "This patient reports a PAINLESS sore four weeks ago — the forgotten chancre.",
  "Associated features: fever, sore throat, anorexia and malaise — a flu-like picture.",
  "NON-TENDER GENERALISED LYMPHADENOPATHY is highly characteristic, and this patient has it.",
  "Other manifestations: CONDYLOMATA LATA (moist, highly infectious lesions), patchy alopecia, mucous patches.",
  "WARNING: secondary syphilis is HIGHLY INFECTIOUS, because the lesions teem with treponemes.",
  "Treatment of PRIMARY, SECONDARY and EARLY LATENT syphilis: BENZATHINE PENICILLIN G 2.4 million units, SINGLE dose.",
  "WARNING: three weekly doses are for LATE LATENT syphilis or syphilis of unknown duration, not for secondary.",
  "Why the difference? In the early stages the treponeme divides rapidly and responds to a short course.",
  "WARNING: after the injection watch for the JARISCH-HERXHEIMER REACTION — fever, chills and a worsening rash within 24 hours.",
  "It comes from the MASSIVE RELEASE OF ANTIGEN from killed treponemes, not from penicillin allergy.",
  "Management is supportive (paracetamol) and it is NOT a reason to stop the penicillin.",
 ],
 "این بیمار تصویر کلاسیک **سیفلیس ثانویه** است، و یک نشانه آن را لو می‌دهد: **راش ماکولوپاپولر که کف دست و کف پا را درگیر می‌کند**. بیماری‌های کمی چنین راشی می‌دهند، و راش سیفلیس معمولاً **بدون خارش** هم هست.\n\nبقیه‌ی صورت سؤال کاملاً جفت‌وجور می‌شود:\n• **زخم بدون درد چهار هفته قبل** ← شانکر فراموش‌شده‌ی سیفلیس اولیه\n• **تب، گلودرد، بی‌اشتهایی** ← تابلوی شبه‌آنفلوانزای مرحله‌ی ثانویه\n• **لنفادنوپاتی متعدد بدون تندرنس** ← بسیار مشخصه‌ی سیفلیس ثانویه\n\n**و حالا نکته‌ی درمانی که کل سؤال روی آن است:** سیفلیس **اولیه، ثانویه و نهفته‌ی زودرس** همگی با **یک دوز** پنی‌سیلین G بنزاتین ۲/۴ میلیون واحد عضلانی درمان می‌شوند.\n\n⚠️ سه دوز هفتگی مربوط به **سیفلیس نهفته‌ی دیررس** یا سیفلیس با طول‌مدت نامعلوم است. دلیل این تفاوت هم منطقی است: در مراحل زودرس ترپونما سریع تقسیم می‌شود و به دوره‌ی کوتاه پاسخ می‌دهد؛ در مراحل دیررس تقسیم کند است و درمان طولانی‌تری می‌خواهد.\n\n⚠️ و یک هشدار عملی: پس از تزریق ممکن است **واکنش یاریش-هرکسهایمر** رخ دهد — تب، لرز و تشدید راش ظرف ۲۴ ساعت. این از **آزاد شدن انبوه آنتی‌ژن** از ترپونماهای کشته‌شده است، **نه آلرژی به پنی‌سیلین**، درمانش حمایتی است و دلیلی برای قطع دارو نیست.",
 "This patient is the classic picture of SECONDARY SYPHILIS, and one sign gives it away: a maculopapular rash INVOLVING THE PALMS AND SOLES. Few diseases produce such a rash, and the syphilitic rash is usually NON-ITCHY as well.\n\nThe rest of the stem fits exactly:\n- A PAINLESS SORE FOUR WEEKS AGO -> the forgotten chancre of primary syphilis\n- FEVER, SORE THROAT, ANOREXIA -> the flu-like picture of the secondary stage\n- MULTIPLE NON-TENDER NODES -> highly characteristic of secondary syphilis\n\nAND NOW THE THERAPEUTIC POINT THE WHOLE QUESTION RESTS ON: primary, secondary AND early latent syphilis are all treated with a SINGLE dose of benzathine penicillin G 2.4 million units IM.\n\nWARNING: three weekly doses are for LATE LATENT syphilis or syphilis of unknown duration. The reason for the difference is logical: in the early stages the treponeme divides rapidly and responds to a short course; in late stages division is slow and longer treatment is needed.\n\nWARNING, a practical caution: after the injection a JARISCH-HERXHEIMER REACTION may occur — fever, chills and a worsening rash within 24 hours. It comes from the MASSIVE ANTIGEN RELEASE of killed treponemes, NOT from penicillin allergy; management is supportive and it is no reason to stop the drug.",
 ["پاسخ صحیح — سیفلیس اولیه، ثانویه و نهفته‌ی زودرس همگی با یک دوز پنی‌سیلین بنزاتین درمان می‌شوند.",
  "سه دوز هفتگی برای سیفلیس نهفته‌ی دیررس یا با طول‌مدت نامعلوم است، نه سیفلیس ثانویه.",
  "سفتریاکسون تک دوز درمان استاندارد سیفلیس نیست؛ پنی‌سیلین داروی انتخابی است.",
  "سفتریاکسون ۱۴ روزه یک رژیم جایگزین در آلرژی به پنی‌سیلین است، نه انتخاب اول این بیمار."],
 ["Correct — primary, secondary and early latent syphilis are all treated with a single dose of benzathine penicillin.",
  "Three weekly doses are for late latent syphilis or syphilis of unknown duration, not secondary syphilis.",
  "A single dose of ceftriaxone is not standard treatment for syphilis; penicillin is the drug of choice.",
  "Fourteen days of ceftriaxone is an alternative in penicillin allergy, not the first choice for this patient."],
 "راش **کف دست و پا بدون خارش** = سیفلیس ثانویه. زودرس = **یک دوز**؛ دیررس = **سه دوز هفتگی**.",
 "A NON-ITCHY rash on PALMS AND SOLES = secondary syphilis. Early = ONE dose; late = THREE weekly doses.",
 [H182, CDC])


# ---------------------------------------------------------------- idx 560
add("book:560", "recall", "medium",
 "پاسخ به درمان سیفلیس را فقط با تست **غیرترپونمال تیتردار (VDRL/RPR)** می‌سنجند.",
 "Response to syphilis treatment is judged only by a QUANTITATIVE NON-TREPONEMAL test (VDRL/RPR).",
 [
  "سرولوژی سیفلیس **دو خانواده** تست دارد و هرکدام کار متفاوتی می‌کنند.",
  "**خانواده‌ی یک — غیرترپونمال**: VDRL و RPR.",
  "این تست‌ها آنتی‌بادی علیه **کاردیولیپین** را می‌سنجند، نه علیه خود ترپونما.",
  "⚠️ ویژگی حیاتی: نتیجه‌شان **کمّی** است و به‌صورت **تیتر** گزارش می‌شود (مثلاً ۱:۳۲).",
  "و تیتر با **فعالیت بیماری** بالا و پایین می‌رود — پس با درمان **کاهش** می‌یابد.",
  "پس معیار موفقیت درمان: **کاهش چهاربرابری تیتر** (مثلاً از ۱:۳۲ به ۱:۸).",
  "**خانواده‌ی دو — ترپونمال**: FTA-ABS و TPHA.",
  "این‌ها آنتی‌بادی علیه **خودِ ترپونما پالیدوم** را می‌سنجند و اختصاصی‌ترند.",
  "⚠️ ویژگی حیاتی: پس از عفونت، **تا آخر عمر مثبت می‌مانند** — حتی پس از درمان موفق.",
  "به همین دلیل تست ترپونمال **هرگز** برای سنجش پاسخ به درمان به کار نمی‌رود.",
  "پس تقسیم کار روشن است: **غیرترپونمال برای غربالگری و پیگیری، ترپونمال برای تأیید**.",
  "الگوریتم کلاسیک: اول VDRL/RPR (ارزان، حساس) ← اگر مثبت شد، تأیید با FTA-ABS.",
  "⚠️ چرا تأیید لازم است؟ چون VDRL **مثبت کاذب** می‌دهد.",
  "علل مثبت کاذب: **بارداری، لوپوس و سندرم آنتی‌فسفولیپید، اعتیاد تزریقی، عفونت‌های ویروسی حاد، سن بالا**.",
  "و یک تله‌ی معکوس: در سیفلیس **اولیه‌ی خیلی زودرس** VDRL ممکن است هنوز منفی باشد.",
  "تله‌ی دیگر: در تیتر بسیار بالا، **پدیده‌ی پروزون** می‌تواند VDRL را کاذباً منفی کند.",
 ],
 [
  "Syphilis serology has TWO FAMILIES of test, and they do different jobs.",
  "FAMILY ONE, NON-TREPONEMAL: VDRL and RPR.",
  "These measure antibody against CARDIOLIPIN, not against the treponeme itself.",
  "WARNING, the crucial property: the result is QUANTITATIVE, reported as a TITRE (for example 1:32).",
  "And the titre rises and falls with DISEASE ACTIVITY, so it FALLS with treatment.",
  "The criterion of cure is therefore a FOURFOLD FALL in titre (for example 1:32 to 1:8).",
  "FAMILY TWO, TREPONEMAL: FTA-ABS and TPHA.",
  "These measure antibody against TREPONEMA PALLIDUM itself and are more specific.",
  "WARNING, the crucial property: once infected they STAY POSITIVE FOR LIFE, even after successful treatment.",
  "For that reason a treponemal test is NEVER used to judge response to treatment.",
  "So the division of labour is clear: NON-TREPONEMAL for screening and follow-up, TREPONEMAL to confirm.",
  "The classic algorithm: VDRL/RPR first (cheap, sensitive); if positive, confirm with FTA-ABS.",
  "WARNING, why is confirmation needed? Because the VDRL gives FALSE POSITIVES.",
  "Causes of a false positive: PREGNANCY, LUPUS and antiphospholipid syndrome, injecting drug use, acute viral infection, old age.",
  "And the reverse trap: in VERY EARLY primary syphilis the VDRL may still be negative.",
  "Another trap: at very high titres the PROZONE PHENOMENON can make the VDRL falsely negative.",
 ],
 "سرولوژی سیفلیس **دو خانواده** تست دارد، و کل این سؤال روی فهمیدن تقسیم کار بین آن‌ها بنا شده است.\n\n**تست‌های غیرترپونمال (VDRL و RPR)** آنتی‌بادی علیه **کاردیولیپین** را می‌سنجند. ویژگی حیاتی‌شان این است که نتیجه **کمّی** و به‌صورت **تیتر** گزارش می‌شود، و تیتر با **فعالیت بیماری** بالا و پایین می‌رود. پس با درمان موفق، تیتر **کاهش** می‌یابد — معیار استاندارد، **کاهش چهاربرابری** است (مثلاً از ۱:۳۲ به ۱:۸).\n\n**تست‌های ترپونمال (FTA-ABS و TPHA)** آنتی‌بادی علیه **خودِ ترپونما** را می‌سنجند و اختصاصی‌ترند. اما ویژگی حیاتی‌شان این است که پس از عفونت **تا آخر عمر مثبت می‌مانند**، حتی پس از درمان کاملاً موفق.\n\n⚠️ نتیجه: تست ترپونمال **هرگز** نمی‌تواند بگوید درمان جواب داده یا نه، چون همیشه مثبت است. فقط تست **تیتردار** می‌تواند این را بگوید. پس پاسخ **VDRL** است.\n\nو الگوریتم عملی از همین‌جا بیرون می‌آید: اول **VDRL/RPR** (ارزان و حساس، برای غربالگری)، و اگر مثبت شد **تأیید با FTA-ABS**.\n\n⚠️ چرا تأیید لازم است؟ چون VDRL **مثبت کاذب** می‌دهد: در **بارداری، لوپوس و سندرم آنتی‌فسفولیپید، اعتیاد تزریقی، عفونت‌های ویروسی حاد و سن بالا**.\n\n⚠️ و دو تله‌ی معکوس: در سیفلیس **خیلی زودرس** ممکن است VDRL هنوز منفی باشد، و در تیترهای بسیار بالا **پدیده‌ی پروزون** می‌تواند آن را کاذباً منفی کند.",
 "Syphilis serology has TWO FAMILIES of test, and this whole question rests on understanding the division of labour between them.\n\nThe NON-TREPONEMAL tests (VDRL and RPR) measure antibody against CARDIOLIPIN. Their crucial property is that the result is QUANTITATIVE, reported as a TITRE, and the titre rises and falls with DISEASE ACTIVITY. So with successful treatment the titre FALLS — the standard criterion is a FOURFOLD fall (for example 1:32 to 1:8).\n\nThe TREPONEMAL tests (FTA-ABS and TPHA) measure antibody against THE TREPONEME ITSELF and are more specific. But their crucial property is that once infected they STAY POSITIVE FOR LIFE, even after entirely successful treatment.\n\nWARNING, the consequence: a treponemal test can NEVER tell you whether treatment worked, because it is always positive. Only a test with a TITRE can. So the answer is the VDRL.\n\nThe practical algorithm follows: VDRL/RPR first (cheap and sensitive, for screening), and if positive, CONFIRM WITH FTA-ABS.\n\nWARNING, why confirm? Because the VDRL gives FALSE POSITIVES: in PREGNANCY, LUPUS and antiphospholipid syndrome, injecting drug use, acute viral infection and old age.\n\nWARNING, two reverse traps: in VERY EARLY syphilis the VDRL may still be negative, and at very high titres the PROZONE PHENOMENON can make it falsely negative.",
 ["پاسخ صحیح — VDRL تیتردار است و تیترش با درمان کاهش می‌یابد، پس پاسخ به درمان را نشان می‌دهد.",
  "FTA-ABS تست ترپونمال است و پس از عفونت تا آخر عمر مثبت می‌ماند؛ برای پیگیری درمان بی‌فایده است.",
  "TPHA هم ترپونمال است و همان محدودیت را دارد: همیشه مثبت می‌ماند.",
  "«همه‌ی موارد» نادرست است، چون دو تست ترپونمال هرگز برای سنجش پاسخ به درمان به کار نمی‌روند."],
 ["Correct — the VDRL has a titre that falls with treatment, so it reflects response to therapy.",
  "FTA-ABS is a treponemal test and stays positive for life after infection; it is useless for follow-up.",
  "TPHA is also treponemal and has the same limitation: it remains permanently positive.",
  "'All of the above' is wrong, because the two treponemal tests are never used to judge treatment response."],
 "**غیرترپونمال (VDRL/RPR) = تیتردار → پیگیری درمان.** **ترپونمال (FTA/TPHA) = مادام‌العمر مثبت → فقط تأیید.**",
 "NON-TREPONEMAL (VDRL/RPR) = has a titre -> follow-up. TREPONEMAL (FTA/TPHA) = positive for life -> confirmation only.",
 [H182, CDC])


# ---------------------------------------------------------------- idx 542 (KEY CORRECTED)
add("book:542", "case", "hard",
 "⚠️ **کلید چاپی تصحیح شد.** ترشح **موکوئیدی** پس از سفتریاکسون = **کلامیدیای درمان‌نشده** ← آزیترومایسین.",
 "WARNING, THE PRINTED KEY WAS CORRECTED. MUCOID discharge after ceftriaxone means UNTREATED CHLAMYDIA: give azithromycin.",
 [
  "این سناریو در همین فصل **پنج بار** پرسیده شده، پس یک‌بار خوب یاد بگیرید.",
  "⚠️ جمله‌ی محوری: **سفتریاکسون گونوکوک را می‌کشد و روی کلامیدیا اثر مفیدی ندارد.**",
  "کلامیدیا یک باکتری **داخل‌سلولی اجباری** است و دیواره‌ی سلولی معمول ندارد.",
  "بتالاکتام‌ها (مثل سفتریاکسون) دیواره‌ی سلولی را هدف می‌گیرند — پس روی کلامیدیا کار نمی‌کنند.",
  "کلامیدیا به داروهای **داخل‌سلولی** پاسخ می‌دهد: **داکسی‌سیکلین، آزیترومایسین**.",
  "و همراهی گونوکوک با کلامیدیا **بسیار شایع** است — تا یک‌سوم موارد.",
  "پس اگر سوزاک را تنها با سفتریاکسون درمان کنید، کلامیدیا **درمان‌نشده باقی می‌ماند**.",
  "یک تا دو هفته بعد خودش را نشان می‌دهد: **اورتریت پس از گونوکوک**.",
  "⚠️ و **کیفیت ترشح تغییر می‌کند**: از چرکی غلیظ به **موکوئیدی و رقیق**.",
  "همین تغییر کیفیت، مهم‌ترین سرنخ صورت سؤال است.",
  "چرا «مقاومت سفتریاکسون» پاسخ نیست؟ چون **زمان‌بندی** با آن جور در نمی‌آید.",
  "شکست واقعی سفتریاکسون یعنی علائم در **۳ تا ۵ روز اول باقی بمانند**.",
  "اما این بیمار **خوب شد** و **دو هفته بعد** عود کرد — الگوی یک ارگانیسم دوم، نه مقاومت اولی.",
  "⚠️ و منابع صریح‌اند که در عود، **عفونت مجدد بسیار محتمل‌تر از شکست درمان** است.",
  "پس درمان: **آزیترومایسین ۱ گرم تک دوز** (یا داکسی‌سیکلین ۷ روزه).",
  "درس پیشگیرانه: از همان اول، درمان سوزاک را با پوشش کلامیدیا همراه کنید.",
 ],
 [
  "This scenario is asked FIVE times in this chapter, so learn it properly once.",
  "WARNING, the central sentence: CEFTRIAXONE KILLS THE GONOCOCCUS AND HAS NO USEFUL ACTIVITY AGAINST CHLAMYDIA.",
  "Chlamydia is an OBLIGATE INTRACELLULAR bacterium and has no conventional cell wall.",
  "Beta-lactams such as ceftriaxone target the cell wall — so they do not work against chlamydia.",
  "Chlamydia responds to drugs that act INTRACELLULARLY: DOXYCYCLINE and AZITHROMYCIN.",
  "And gonococcal-chlamydial co-infection is VERY COMMON — up to a third of cases.",
  "So if gonorrhoea is treated with ceftriaxone alone, the chlamydia is LEFT UNTREATED.",
  "One to two weeks later it declares itself: POST-GONOCOCCAL URETHRITIS.",
  "WARNING, and THE CHARACTER OF THE DISCHARGE CHANGES: from thick and purulent to thin and MUCOID.",
  "That change in character is the most important clue in the stem.",
  "Why is 'ceftriaxone resistance' not the answer? Because the TIMING does not fit.",
  "True ceftriaxone failure means symptoms PERSIST through the first 3-5 days.",
  "But this patient GOT BETTER and relapsed TWO WEEKS LATER — the pattern of a second organism, not of a resistant first one.",
  "WARNING: the sources state plainly that on relapse, REINFECTION IS FAR MORE LIKELY THAN TREATMENT FAILURE.",
  "So the treatment is AZITHROMYCIN 1 g as a single dose (or doxycycline for 7 days).",
  "The preventive lesson: cover chlamydia alongside gonorrhoea from the outset.",
 ],
 "⚠️ **کلید چاپی این سؤال نادرست بود و تصحیح شد** — و جالب اینکه قوی‌ترین دلیل رد آن، **خودِ همین کتاب** است.\n\nاین سناریو در همین فصل **پنج بار** پرسیده شده، و کتاب چهار بار پاسخ درست داده و فقط یک بار (همین سؤال) با خودش متناقض شده:\n\n• **q9541** ← «کلامیدیای همزمان دارد» ✓\n• **q9545** ← «یک گرم آزیترومایسین» ✓\n• **q9555** ← «هیچ‌کدام» (یعنی رد مقاومت و رد تکرار سفتریاکسون) ✓\n• **q9539** ← «مترونیدازول + آزیترومایسین» ✓\n• **و همین سؤال** ← «تکرار سفتریاکسون» ✗ ← تنها مورد ناسازگار\n\n**و حالا پزشکیِ پشت قاعده:** سفتریاکسون یک بتالاکتام است و **دیواره‌ی سلولی** را هدف می‌گیرد. اما کلامیدیا یک باکتری **داخل‌سلولی اجباری** است و دیواره‌ی سلولی معمول ندارد — پس سفتریاکسون روی آن **بی‌اثر** است. کلامیدیا فقط به داروهایی که داخل سلول کار می‌کنند پاسخ می‌دهد: **آزیترومایسین و داکسی‌سیکلین**.\n\nاز آنجا که همراهی سوزاک و کلامیدیا **تا یک‌سوم موارد** است، درمان سوزاک با سفتریاکسون تنها، کلامیدیا را دست‌نخورده رها می‌کند. یک تا دو هفته بعد، کلامیدیا خود را به شکل **اورتریت پس از گونوکوک** نشان می‌دهد — و ⚠️ **کیفیت ترشح از چرکی غلیظ به موکوئیدی رقیق تغییر می‌کند**، که دقیقاً همان سرنخ صورت سؤال است.\n\n**چرا «مقاومت به سفتریاکسون» پاسخ نیست؟** چون زمان‌بندی جور در نمی‌آید. شکست واقعی سفتریاکسون یعنی علائم در **۳ تا ۵ روز اول باقی بمانند**. اما این بیمار **بهبود یافت** و **دو هفته بعد** عود کرد — این الگوی یک **ارگانیسم دوم درمان‌نشده** است، نه مقاومت ارگانیسم اول.\n\nپس پاسخ درست **آزیترومایسین ۱ گرم تک دوز** است.",
 "WARNING: THE PRINTED KEY OF THIS QUESTION WAS WRONG AND HAS BEEN CORRECTED — and remarkably, the strongest argument against it comes from THE BOOK ITSELF.\n\nThis scenario is asked FIVE times in this chapter, and the book answers correctly four times, contradicting itself only here:\n\n- q9541 -> 'concurrent chlamydial infection' (correct)\n- q9545 -> 'azithromycin 1 g' (correct)\n- q9555 -> 'none of the above' (rejecting both resistance and repeat ceftriaxone) (correct)\n- q9539 -> 'metronidazole + azithromycin' (correct)\n- THIS question -> 'repeat the ceftriaxone' (WRONG) - the lone outlier\n\nAND NOW THE MEDICINE BEHIND THE RULE: ceftriaxone is a beta-lactam and targets the CELL WALL. But chlamydia is an OBLIGATE INTRACELLULAR bacterium with no conventional cell wall — so ceftriaxone is INACTIVE against it. Chlamydia responds only to drugs that work inside the cell: AZITHROMYCIN and DOXYCYCLINE.\n\nSince gonococcal-chlamydial co-infection occurs in up to a THIRD of cases, treating gonorrhoea with ceftriaxone alone leaves the chlamydia untouched. One to two weeks later it declares itself as POST-GONOCOCCAL URETHRITIS — and WARNING, THE DISCHARGE CHANGES from thick and purulent to thin and MUCOID, which is precisely the clue in the stem.\n\nWHY IS 'CEFTRIAXONE RESISTANCE' NOT THE ANSWER? The timing does not fit. True ceftriaxone failure means symptoms PERSIST through the first 3-5 days. This patient RECOVERED and relapsed TWO WEEKS LATER — the pattern of a SECOND UNTREATED ORGANISM, not of a resistant first one.\n\nThe correct answer is AZITHROMYCIN 1 g as a single dose.",
 ["سیپروفلوکساسین ضدگونوکوک است و پوشش قابل‌اتکایی برای کلامیدیا ندارد؛ ضمناً مقاومت گونوکوک به کینولون‌ها گسترده است. (توجه: واحد این گزینه در کتاب «گرم» چاپ شده که اشتباه است؛ دوز درست ۵۰۰ **میلی‌گرم** است.)",
  "اسپکتینومایسین هم ضدگونوکوک است و روی کلامیدیا بی‌اثر است.",
  "تکرار سفتریاکسون ارگانیسمی را درمان می‌کند که قبلاً کشته شده و کلامیدیا را دست‌نخورده می‌گذارد. (کلید چاپی کتاب همین بود و نادرست است.)",
  "پاسخ صحیح — آزیترومایسین کلامیدیای درمان‌نشده را پوشش می‌دهد، که علت واقعی اورتریت پس از گونوکوک است."],
 ["Ciprofloxacin is anti-gonococcal and does not reliably cover chlamydia; quinolone resistance in gonococci is also widespread. (Note: the source misprints the unit as 'grams'; the correct dose is 500 MILLIGRAMS.)",
  "Spectinomycin is likewise anti-gonococcal and inactive against chlamydia.",
  "Repeating the ceftriaxone treats an organism already killed and leaves the chlamydia untouched. (This was the printed key and it is wrong.)",
  "Correct — azithromycin covers the untreated chlamydia, the real cause of post-gonococcal urethritis."],
 "سفتریاکسون **کلامیدیا را درمان نمی‌کند**. ترشح **موکوئیدی** یک تا دو هفته بعد = کلامیدیای درمان‌نشده ← آزیترومایسین.",
 "Ceftriaxone DOES NOT TREAT CHLAMYDIA. MUCOID discharge a week or two later = untreated chlamydia -> azithromycin.",
 [H155, H178, CDC])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book13.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 13 lessons:', len(L))
