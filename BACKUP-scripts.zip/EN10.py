# -*- coding: utf-8 -*-
"""English stems and options for the batch-22 and batch-23 questions (respiratory).

Rule 16 checked first, as always: these are sittings 93 to 98, for which the
ministry published no English booklet, so these are hand-written translations.

Translation decisions worth recording
-------------------------------------
q9088 (idx 88): the laboratory panel was a scrambled two-column table. Page 34
prints WBC 4500, ALT 75, Na 128, Cr 1/6, Hb 14, AST 40, K 4/8, PLT 245000, and
fix_resp_numbers.py rebuilt it from the horizontal glyph clusters. The English
quotes the REBUILT panel. This matters more than usual: the sodium of 128 is
the clue that makes the answer, and the extraction had turned it into a
platelet count while reporting a sodium of 75.

q9575 (idx 575): the fourth option was stored as "BMI > 24" where page 215
prints BMI > 40. The English quotes 40. Without it the question has two correct
answers, since a BMI of 24 is not a risk group at all.

q9587, q9588, q9595: mirrored ages (57/75, 53/35, 81/18, 54/45) repaired from
glyph geometry; the English quotes the printed values throughout.

q9090 (idx 90): the vital signs are written in the source as "OT = 38.8", an
obvious rendering of the temperature. The English writes "temperature 38.8" and
keeps the digits so the numeric inspector can see them.
"""

EN10 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    assert all(o.strip() for o in options), idx
    EN10[idx] = {"stem_en": stem, "options_en": options}


# ========================================================= pneumonia (batch 22)
add(73,
    "A 26-year-old man with a history of epilepsy presents with fever and cough. On examination "
    "his temperature is 38.5 degrees Celsius and his respiratory rate is 30 per minute, and "
    "crackles are heard over the right lung. Given these circumstances, which is the likely "
    "causative pathogen?",
    ["Legionella", "Staphylococcus", "Enterococcus", "Oral anaerobes"])

add(75,
    "Two months after splenectomy a patient develops a fever of 39 degrees, an increased heart "
    "rate (110 beats per minute), an increased respiratory rate (30 per minute) and a fall in "
    "blood pressure. What is the commonest cause of these findings?",
    ["Streptococcus pneumoniae", "Haemophilus influenzae", "Staphylococcus aureus",
     "Pseudomonas aeruginosa"])

add(76,
    "A 40-year-old man who repairs air conditioners attends the clinic with respiratory distress "
    "accompanied by fever and leucocytosis, headache, myalgia, nausea and cough. On examination "
    "he is toxic, with respiratory distress and bilateral crackles with wheeze. Investigations "
    "show a potassium of 9.3, a sodium of 126 and a creatinine of 4.1. Blood cultures are not "
    "yet available. What is the most likely diagnosis?",
    ["Legionella", "Aspergillus", "Mycoplasma", "Hypersensitivity pneumonitis"])

add(77,
    "A 12-year-old girl with sickle cell anaemia presents with fever, a non-productive cough, "
    "nausea, vomiting and diarrhoea. Her cold agglutinin test is positive. During the course of "
    "the illness she develops necrosis of the toes. Which of the following is most likely to be "
    "the causative organism?",
    ["Chlamydia pneumoniae", "Legionella pneumophila", "Staphylococcus aureus",
     "Mycoplasma pneumoniae"])

add(82,
    "A 50-year-old man has had fever and a productive cough for two days. The chest radiograph "
    "shows an opacity in the left lower lobe. He has no underlying disease and has taken no "
    "antibiotics in the past three months. Which of the following antibiotics is NOT appropriate "
    "for his outpatient treatment?",
    ["Azithromycin", "Clarithromycin", "Ciprofloxacin", "Doxycycline"])

add(86,
    "A 50-year-old man with no particular underlying disease is admitted with fever and rigors, "
    "cough and sputum. The chest radiograph shows an opacity in the right middle lobe. He has "
    "taken antibiotics within the past month. What is the most appropriate antibiotic for him?",
    ["Erythromycin", "Doxycycline", "Co-amoxiclav", "Levofloxacin"])

add(88,
    "A 65-year-old man presents with high fever, cough, sputum, a reduced level of consciousness "
    "and diarrhoea. The chest radiograph showed unilateral involvement, and despite starting "
    "treatment the other side has also become involved. Investigations show WBC 4500, ALT 75, "
    "Na 128, Cr 1.6, Hb 14, AST 40, K 4.8 and PLT 245000, with urinalysis showing 8 to 10 red "
    "cells and 0 to 1 white cells. Given the most likely diagnosis, which treatment is "
    "preferred?",
    ["Azithromycin", "Ceftriaxone", "Colistin", "Vancomycin"])

add(90,
    "A 68-year-old man attends the clinic complaining of fever, rigors and a productive cough. "
    "On examination he is alert, with a blood pressure of 110/70, a pulse of 90 per minute, a "
    "respiratory rate of 34 per minute and a temperature of 38.8 degrees. If pneumonia is "
    "suspected, which course of action is more appropriate according to the CURB-65 criteria?",
    ["Outpatient treatment with azithromycin",
     "Admission to intensive care and treatment with levofloxacin",
     "Admission to intensive care and treatment with meropenem plus vancomycin",
     "Admission to a general ward and treatment with ceftriaxone plus azithromycin"])

add(95,
    "A 50-year-old man who has been treated for pneumonia develops fever and leucocytosis after "
    "5 days. The chest radiograph shows a pleural collection. On tapping the pleural fluid the "
    "pH is below 7, and the smear is reported as showing gram-positive diplococci. Which course "
    "of action is preferred?",
    ["Change the patient's antibiotic", "Insert a chest tube",
     "Repeated taps of the pleural fluid",
     "Continue antibiotic treatment and reassess the patient in 48 hours"])


# ========================================================= influenza (batch 23)
add(564,
    "A 25-year-old man attends the emergency department at the end of winter complaining of "
    "fever and body aches. His problems began abruptly yesterday and are accompanied by a sore "
    "throat, a dry cough and pain in the eyes on movement. He has no significant medical history "
    "and no recent travel. About a week ago his brother had a similar illness. On examination he "
    "is ill, with a blood pressure of 110/60, a temperature of 39 degrees Celsius, a respiratory "
    "rate of 18 per minute and a pulse of 90 per minute. The pharynx is mildly erythematous and "
    "the rest of the examination is normal. Which advice is correct for this patient?",
    ["Prescribe paracetamol and advise rest and avoidance of public places",
     "Give intramuscular benzathine penicillin and advise rest",
     "Admit the patient and start intravenous ceftriaxone",
     "Start azithromycin together with advice to rest"])

add(571,
    "A 24-year-old man attends with fever, headache, myalgia and sore throat since this morning. "
    "On history and examination his temperature is 39 degrees, the headache is localised to the "
    "frontal region, he has myalgia in the calf muscles, and white exudate is visible on "
    "examination of the pharynx. Which of the following findings is NOT consistent with "
    "influenza?",
    ["The degree of fever", "The localisation of the headache",
     "Exudate on the pharynx", "The localisation of the myalgia"])

add(575,
    "Which of the following groups of patients is at LOWER risk of complications and death if "
    "they contract influenza?",
    ["Patients with influenza C", "Patients over 60 years of age",
     "Patients with pulmonary hypertension",
     "Obese patients with a BMI above 40 kg/m2"])

add(579,
    "A 25-year-old man is brought to the emergency department with fever, dyspnoea and a dry "
    "cough. His companions report that he abruptly developed fever, headache and myalgia last "
    "night. On examination his respiratory rate is 35 per minute and his temperature is 39 "
    "degrees, and the lungs sound normal on auscultation. His oxygen saturation by pulse "
    "oximetry is 75 per cent. The chest radiograph shows diffuse reticulonodular infiltration. "
    "Which of the following diagnoses applies to this patient?",
    ["Primary viral pneumonia", "Secondary bacterial pneumonia",
     "Mixed viral and bacterial pneumonia", "Exacerbation of chronic bronchitis"])

add(581,
    "A 30-year-old man is admitted complaining of fever, cough and sputum. His temperature is 39 "
    "degrees, his blood pressure is 100/80, his respiratory rate is 30 and his heart rate is 120. "
    "The illness began acutely with severe myalgia of the lumbar and calf muscles, and the "
    "influenza PCR is positive. The chest radiograph shows a thin-walled cavity in the periphery "
    "of the lung. What is your treatment recommendation for this patient?",
    ["Meropenem plus co-trimoxazole", "Clindamycin plus azithromycin",
     "Azithromycin plus meropenem", "Vancomycin plus ceftriaxone"])

add(585,
    "To prevent influenza in a pregnant woman whose 7-year-old child has contracted the disease, "
    "which of the following is correct?",
    ["Inactivated vaccine plus amantadine", "Intranasal vaccine plus oseltamivir",
     "Inactivated vaccine plus oseltamivir", "Intranasal vaccine plus amantadine"])

add(591,
    "A 7-year-old boy has a high fever and shaking rigors from severe influenza. Which of the "
    "following drugs must NOT be given?",
    ["Ibuprofen", "Aspirin", "Paracetamol", "Oseltamivir"])

add(593,
    "During an influenza epidemic, a patient with a history of asthma presents with acute "
    "influenza symptoms and worsening breathlessness. Which of the following antiviral "
    "treatments do you consider appropriate?",
    ["Oral amantadine", "Oral rimantadine", "Oral oseltamivir", "Inhaled zanamivir"])

add(595,
    "In which of the following does a patient with influenza NOT require oseltamivir?",
    ["A 30-year-old man being treated with aspirin",
     "A 25-year-old woman at eight weeks' gestation",
     "A 40-year-old man with hypertension",
     "A 45-year-old man with diabetes mellitus"])
