# -*- coding: utf-8 -*-
"""Micro-lessons, batch 46 — inflammatory diarrhoea and the HUS cluster.

This opens the gastrointestinal chapter, the largest chapter still untaught
(66 of 84 questions had no lesson before this batch).

THE ONE DIVISION THAT DECIDES MOST OF THIS CHAPTER
----------------------------------------------------
Every diarrhoea question in this book is first sorted into one of two boxes,
and the stool white cell count is what sorts it:

    INFLAMMATORY (dysenteric)        NON-INFLAMMATORY (secretory / watery)
    stool WBC PRESENT                stool WBC ABSENT
    small volume, frequent           LARGE volume
    blood, mucus, TENESMUS           watery, no blood
    fever common                     fever usually absent
    invades the COLON                acts on the SMALL BOWEL
    Shigella, Campylobacter,         Vibrio cholerae, ETEC,
    EHEC, Salmonella, Yersinia,      Staph aureus, Bacillus cereus,
    Entamoeba, C. difficile          Clostridium perfringens, rotavirus,
                                     Giardia

Six questions in this chapter are of the form "all of these can cause this
picture EXCEPT", and every one is answered by taking the stool white cells,
deciding which box the vignette is in, and finding the organism from the other
box. Nothing else is needed.

THE TWO ORGANISMS THAT ARE ALWAYS THE ODD ONE OUT
---------------------------------------------------
  VIBRIO CHOLERAE  is the classic exception in an INFLAMMATORY vignette. It is
      a pure toxin producer: it never invades, so it never makes stool white
      cells, blood or fever.
  ETEC (enterotoxigenic E. coli) is the other. Note carefully that ETEC and
      EHEC are opposite in this respect and the book exploits the confusion:
      ETEC is watery traveller's diarrhoea; EHEC is bloody and causes HUS.

HAEMOLYTIC URAEMIC SYNDROME, ASKED FIVE TIMES
-----------------------------------------------
The triad, and only these three:
    MICROANGIOPATHIC HAEMOLYTIC ANAEMIA (schistocytes, negative Coombs)
    THROMBOCYTOPENIA
    ACUTE RENAL FAILURE

Leucocytosis is NOT part of the triad, though it is common and predicts a
worse course. Two organisms cause it by making SHIGA TOXIN: Shigella
dysenteriae type 1 and enterohaemorrhagic E. coli O157:H7. Campylobacter,
Salmonella and Entamoeba do NOT.

And the single most important management point, which the book does not ask
but which a doctor must know: ANTIBIOTICS IN SUSPECTED EHEC MAY PRECIPITATE
HUS, because killing the organism releases its toxin load.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022) —
acute infectious diarrhoeal diseases and bacterial food poisoning.
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — "
     "acute infectious diarrhoeal diseases and bacterial food poisoning")
REFS = [H]

# ============================================ THE CORE DIVISION, SHARED
DIV_FA = [
    "⚠️ **کل این فصل با یک تقسیم دوتایی شروع می‌شود: اسهال التهابی یا غیرالتهابی؟**",
    "**و چیزی که این تقسیم را انجام می‌دهد، گلبول سفید مدفوع است.**",
    "**اسهال التهابی: گلبول سفید مدفوع دارد.**",
    "**حجم کم، دفعات زیاد، خون و بلغم، و تنسموس (زور زدن مداوم).**",
    "**تب شایع است، و محل درگیری کولون است.**",
    "⚠️ **عامل‌ها: شیگلا، کمپیلوباکتر، EHEC، سالمونلا، یرسینیا، آمیب، کلستریدیوم دیفیسیل.**",
    "**اسهال غیرالتهابی: گلبول سفید مدفوع ندارد.**",
    "**حجم زیاد، آبکی، بدون خون، و معمولاً بدون تب.**",
    "**محل اثر روده‌ی باریک است، و سازوکار سمّی است نه تهاجمی.**",
    "**عامل‌ها: ویبریوکلرا، ETEC، استاف اورئوس، باسیلوس سرئوس، پرفرانژنس، روتاویروس، ژیاردیا.**",
    "⚠️ **و دو ارگانیسم همیشه «استثنا» در سؤال‌های التهابی‌اند.**",
    "**ویبریوکلرا: سم‌ساز خالص است، هرگز تهاجم نمی‌کند، پس نه گلبول سفید می‌دهد نه خون.**",
    "**و ETEC، که کتاب عمداً آن را با EHEC اشتباه‌انداز می‌کند.**",
    "**ETEC آبکی است (اسهال مسافران)؛ EHEC خونی است و HUS می‌دهد.**",
    "**پس دیدن حروف E و C کافی نیست — باید حرف وسط را خواند.**",
]
DIV_EN = [
    "WARNING: THE WHOLE CHAPTER STARTS WITH ONE BINARY SPLIT — inflammatory or non-inflammatory diarrhoea?",
    "And what performs that split is the STOOL WHITE CELL COUNT.",
    "INFLAMMATORY diarrhoea: stool white cells are PRESENT.",
    "Small volume, frequent, blood and mucus, and TENESMUS (constant straining).",
    "Fever is common, and the site of involvement is the COLON.",
    "WARNING, THE ORGANISMS: Shigella, Campylobacter, EHEC, Salmonella, Yersinia, Entamoeba, C. difficile.",
    "NON-INFLAMMATORY diarrhoea: stool white cells are ABSENT.",
    "Large volume, watery, no blood, and usually no fever.",
    "It acts on the SMALL BOWEL, and its mechanism is TOXIN rather than invasion.",
    "The organisms: Vibrio cholerae, ETEC, Staph aureus, Bacillus cereus, C. perfringens, rotavirus, Giardia.",
    "WARNING, AND TWO ORGANISMS ARE ALWAYS THE 'EXCEPTION' in inflammatory questions.",
    "VIBRIO CHOLERAE: a pure toxin producer that never invades, so no white cells and no blood.",
    "And ETEC, which the book deliberately confuses with EHEC.",
    "ETEC is watery (traveller's diarrhoea); EHEC is bloody and causes HUS.",
    "So seeing the letters E and C is not enough — the middle letter must be read.",
]

add("book:287", "vignette", "easy",
    "**اسهال التهابی با گلبول سفید مدفوع: ETEC استثناست، چون سم‌ساز خالص است.**",
    "Inflammatory diarrhoea with stool white cells: ETEC is the exception, because it is a pure toxin producer.",
    DIV_FA + [
        "**تابلوی این بیمار کاملاً التهابی است و هر جزئش همین را می‌گوید.**",
        "**حجم بسیار کم با دفعات زیاد: نشانه‌ی درگیری کولون، نه روده‌ی باریک.**",
        "⚠️ **و «رک» (تنسموس) در متن آمده، که امضای رکتیت است.**",
        "**به‌علاوه بلغم، و گلبول سفید و قرمز در آزمایش مدفوع.**",
        "**پس هر عاملی که تهاجم می‌کند می‌تواند این تابلو را بسازد.**",
    ],
    DIV_EN + [
        "This patient's picture is entirely inflammatory, and every part of it says so.",
        "Very small volume with high frequency: a sign of colonic involvement, not small bowel.",
        "WARNING, AND TENESMUS is stated in the stem, the signature of proctitis.",
        "Plus mucus, and both white and red cells in the stool.",
        "So any invasive organism can produce this picture.",
    ],
    "این سؤال ورودی فصل گوارشی است و **کل منطق فصل** را در خود دارد.\n\n"
    "**تابلوی بیمار: نوجوان ۱۵ ساله، تب، استفراغ، اسهال و درد شکم. هشت بار در روز، "
    "با حجم بسیار کم، همراه با تنسموس و بلغم و بدون خون. در آزمایش مدفوع، گلبول سفید و "
    "گلبول قرمز.**\n\n"
    "⚠️ **این یک اسهال التهابی کلاسیک است، و سه یافته آن را قطعی می‌کنند:**\n\n"
    "**یک — حجم بسیار کم با دفعات زیاد.** این الگوی **کولون** است. روده‌ی باریک حجم زیاد "
    "می‌دهد؛ کولون که ملتهب شود، دفعات زیاد با حجم کم می‌دهد.\n\n"
    "**دو — تنسموس.** یعنی احساس زور زدن مداوم، که **امضای رکتیت** است — یعنی التهاب به "
    "رکتوم رسیده.\n\n"
    "**سه — گلبول سفید در مدفوع.** این **معیار قطعی** التهاب است.\n\n"
    "**پس سه گزینه‌ی مهاجم می‌توانند این تابلو را بسازند:**\n\n"
    "**کمپیلوباکتر ژژونی** — شایع‌ترین علت اسهال باکتریایی در بسیاری از کشورها؛ تهاجمی و "
    "التهابی است.\n\n"
    "**ویبریو پاراهمولیتیکوس** — با غذای دریایی خام منتقل می‌شود و **برخلاف ویبریوکلرا "
    "تهاجمی است** و می‌تواند اسهال التهابی بدهد. (این تمایز مهم است: دو ویبریو، دو رفتار "
    "کاملاً متفاوت.)\n\n"
    "**شیگلا دیسانتری** — نمونه‌ی اعلای اسهال التهابی؛ تنسموس و دیسانتری امضای آن است.\n\n"
    "⚠️ **و استثنا: ETEC (اشرشیاکلی انتروتوکسیکوژنیک).**\n\n"
    "**چرا؟** چون ETEC **سم‌ساز خالص** است. دو سم می‌سازد (LT شبیه سم وبا، و ST)، هر دو "
    "**ترشح آب و الکترولیت از روده‌ی باریک** را تحریک می‌کنند. **هیچ تهاجمی به مخاط رخ "
    "نمی‌دهد.** پس ETEC می‌دهد: **اسهال آبکی با حجم زیاد، بدون خون، بدون گلبول سفید، معمولاً "
    "بدون تب** — یعنی دقیقاً **برعکس** تابلوی این بیمار. ETEC عامل اصلی **اسهال مسافران** است.\n\n"
    "**⚠️ دام اصلی سؤال: ETEC را با EHEC اشتباه نگیرید.** حروف شبیه‌اند ولی رفتار متضاد "
    "است: **ETEC آبکی؛ EHEC خونی و عامل HUS.**",
    "This question opens the gastrointestinal chapter and contains THE LOGIC OF THE WHOLE CHAPTER.\n\n"
    "THE PICTURE: a 15-year-old with fever, vomiting, diarrhoea and abdominal pain. Eight times a day, "
    "of VERY SMALL VOLUME, with TENESMUS and mucus and no blood. The stool shows white cells and red cells.\n\n"
    "WARNING, THIS IS CLASSIC INFLAMMATORY DIARRHOEA, and three findings settle it:\n\n"
    "ONE — VERY SMALL VOLUME WITH HIGH FREQUENCY. That is the COLONIC pattern. The small bowel produces "
    "large volumes; an inflamed colon produces frequent small ones.\n\n"
    "TWO — TENESMUS. A constant urge to strain, THE SIGNATURE OF PROCTITIS — the inflammation has "
    "reached the rectum.\n\n"
    "THREE — WHITE CELLS IN THE STOOL. This is the DEFINITIVE criterion of inflammation.\n\n"
    "SO THE THREE INVASIVE OPTIONS CAN ALL PRODUCE THIS PICTURE:\n\n"
    "CAMPYLOBACTER JEJUNI — the commonest cause of bacterial diarrhoea in many countries; invasive and "
    "inflammatory.\n\n"
    "VIBRIO PARAHAEMOLYTICUS — acquired from raw seafood and, UNLIKE VIBRIO CHOLERAE, IS INVASIVE and "
    "can cause inflammatory diarrhoea. (This distinction matters: two vibrios, two entirely different "
    "behaviours.)\n\n"
    "SHIGELLA DYSENTERIAE — the archetype of inflammatory diarrhoea; tenesmus and dysentery are its "
    "signature.\n\n"
    "WARNING, AND THE EXCEPTION: ETEC (enterotoxigenic E. coli).\n\n"
    "WHY? Because ETEC is a PURE TOXIN PRODUCER. It makes two toxins (LT, resembling cholera toxin, and "
    "ST), both of which stimulate SECRETION OF WATER AND ELECTROLYTES FROM THE SMALL BOWEL. THERE IS NO "
    "MUCOSAL INVASION AT ALL. So ETEC gives LARGE-VOLUME WATERY DIARRHOEA, NO BLOOD, NO WHITE CELLS, "
    "USUALLY NO FEVER — precisely THE OPPOSITE of this patient's picture. ETEC is the main cause of "
    "TRAVELLER'S DIARRHOEA.\n\n"
    "WARNING, THE MAIN TRAP: DO NOT CONFUSE ETEC WITH EHEC. The letters look alike but the behaviours "
    "are opposite: ETEC IS WATERY; EHEC IS BLOODY AND CAUSES HUS.",
    ["شایع‌ترین علت اسهال باکتریایی در بسیاری کشورها؛ تهاجمی و التهابی است.",
     "پاسخ صحیح — ETEC سم‌ساز خالص است و اسهال آبکی بدون گلبول سفید می‌دهد.",
     "برخلاف ویبریوکلرا تهاجمی است و می‌تواند اسهال التهابی بدهد.",
     "نمونه‌ی اعلای اسهال التهابی؛ تنسموس و دیسانتری امضای آن است."],
    ["The commonest cause of bacterial diarrhoea in many countries; invasive and inflammatory.",
     "Correct — ETEC is a pure toxin producer giving watery diarrhoea with no white cells.",
     "Unlike Vibrio cholerae it IS invasive and can cause inflammatory diarrhoea.",
     "The archetype of inflammatory diarrhoea; tenesmus and dysentery are its signature."],
    "**ETEC آبکی، EHEC خونی — حرف وسط همه‌چیز را عوض می‌کند.**",
    "ETEC is watery, EHEC is bloody — the middle letter changes everything.",
    REFS)

add("book:288", "vignette", "hard",
    "**آرتریت واکنشی فقط پس از اسهال مهاجم رخ می‌دهد — و ETEC مهاجم نیست.**",
    "Reactive arthritis follows only INVASIVE diarrhoea — and ETEC does not invade.",
    DIV_FA + [
        "**این سؤال یک لایه اضافه می‌کند: عارضه‌ی دیررس اسهال.**",
        "**آرتریت واکنشی، یک تا چهار هفته پس از عفونت روده‌ای یا ادراری-تناسلی می‌آید.**",
        "⚠️ **و فقط پس از ارگانیسم‌های مهاجم رخ می‌دهد، نه پس از سم‌سازها.**",
        "**چهار عامل روده‌ای کلاسیک آن: شیگلا، سالمونلا، یرسینیا، کمپیلوباکتر.**",
        "**این چهار را با هم حفظ کنید، چون فهرست ثابتی است.**",
        "**سازوکار: تقلید مولکولی و پاسخ ایمنی، نه عفونت فعال مفصل.**",
        "**پس کشت مایع مفصل استریل است — و همین آن را از آرتریت سپتیک جدا می‌کند.**",
        "⚠️ **و HLA-B27 خطر و شدت آن را بالا می‌برد.**",
        "**سه‌گانه‌ی رایتر: آرتریت، اورتریت، و کونژنکتیویت.**",
        "**درگیری ساکروایلیاک و کمردرد التهابی هم شایع است، مثل همین بیمار.**",
    ],
    DIV_EN + [
        "This question adds a layer: a LATE complication of diarrhoea.",
        "Reactive arthritis follows one to four weeks after an enteric or genitourinary infection.",
        "WARNING, AND IT FOLLOWS ONLY INVASIVE ORGANISMS, not toxin producers.",
        "Its four classic enteric triggers: Shigella, Salmonella, Yersinia, Campylobacter.",
        "Memorise those four together, because the list is fixed.",
        "The mechanism is molecular mimicry and an immune response, not active joint infection.",
        "So the joint fluid culture is STERILE — and that is what separates it from septic arthritis.",
        "WARNING, AND HLA-B27 raises both its risk and its severity.",
        "Reiter's triad: arthritis, urethritis and conjunctivitis.",
        "Sacroiliac involvement and inflammatory back pain are also common, as in this patient.",
    ],
    "این سؤال از قبلی سخت‌تر است، چون **از عارضه‌ی دیررس به عامل اولیه** برمی‌گردد.\n\n"
    "**بیمار: سرباز ۲۰ ساله با تب ۳۸، کمردرد، درد لگن و تورم هر دو زانو از یک هفته قبل. "
    "و در سابقه: اسهال خونی یک ماه قبل که پنج روز طول کشیده بود.**\n\n"
    "⚠️ **تشخیص: آرتریت واکنشی (رایتر).**\n\n"
    "**الگو را بشناسید:** عفونت روده‌ای یا ادراری-تناسلی → **فاصله‌ی یک تا چهار هفته** → "
    "آرتریت الیگوآرتیکولار نامتقارن اندام تحتانی، اغلب با **درگیری ساکروایلیاک و کمردرد "
    "التهابی**. سه‌گانه‌ی کلاسیک رایتر: **آرتریت + اورتریت + کونژنکتیویت**.\n\n"
    "**سازوکار مهم است:** این **عفونت فعال مفصل نیست**. **تقلید مولکولی** است — سیستم ایمنی "
    "به آنتی‌ژن باکتری پاسخ می‌دهد و آن پاسخ به بافت مفصل هم حمله می‌کند. **پس کشت مایع مفصل "
    "استریل است**، و همین آن را از آرتریت سپتیک جدا می‌کند. **HLA-B27** خطر و شدت را بالا می‌برد.\n\n"
    "**حالا سؤال: کدام عامل نمی‌توانسته باشد؟**\n\n"
    "**چهار عامل روده‌ای کلاسیک آرتریت واکنشی را حفظ کنید — فهرست ثابتی است:**\n\n"
    "**شیگلا · سالمونلا · یرسینیا · کمپیلوباکتر**\n\n"
    "و هر چهار **مهاجم** هستند. **این تصادفی نیست:** آرتریت واکنشی نیازمند **تهاجم مخاطی و "
    "پاسخ ایمنی سیستمیک** به آنتی‌ژن باکتری است. ارگانیسمی که فقط در لومن می‌ماند و سم "
    "ترشح می‌کند، چنین پاسخی برنمی‌انگیزد.\n\n"
    "⚠️ **پس ETEC نمی‌توانسته باشد — به دو دلیل مستقل:**\n\n"
    "**یک:** ETEC **اسهال خونی نمی‌دهد**. سؤال گفته «اسهال خونی یک ماه قبل»، و ETEC آبکی است.\n\n"
    "**دو:** ETEC **مهاجم نیست**، پس آرتریت واکنشی نمی‌سازد.\n\n"
    "**دو دلیل مستقل که هر کدام به‌تنهایی کافی است — و همین آن را پاسخ قطعی می‌کند.**",
    "This question is harder than the previous one, because it works BACK FROM A LATE COMPLICATION TO "
    "THE ORIGINAL ORGANISM.\n\n"
    "THE PATIENT: a 20-year-old soldier with a fever of 38, back pain, pelvic pain and swelling of both "
    "knees for a week. And in the history: BLOODY DIARRHOEA A MONTH AGO lasting five days.\n\n"
    "WARNING, THE DIAGNOSIS: REACTIVE ARTHRITIS (Reiter's).\n\n"
    "RECOGNISE THE PATTERN: an enteric or genitourinary infection, then AN INTERVAL OF ONE TO FOUR "
    "WEEKS, then an asymmetrical lower-limb oligoarthritis, often with SACROILIAC INVOLVEMENT AND "
    "INFLAMMATORY BACK PAIN. The classic Reiter triad: ARTHRITIS plus URETHRITIS plus CONJUNCTIVITIS.\n\n"
    "THE MECHANISM MATTERS: this is NOT ACTIVE JOINT INFECTION. It is MOLECULAR MIMICRY — the immune "
    "system responds to a bacterial antigen and that response also attacks joint tissue. SO THE JOINT "
    "FLUID CULTURE IS STERILE, and that is what separates it from septic arthritis. HLA-B27 raises both "
    "risk and severity.\n\n"
    "NOW THE QUESTION: which organism CANNOT have been responsible?\n\n"
    "MEMORISE THE FOUR CLASSIC ENTERIC TRIGGERS OF REACTIVE ARTHRITIS — the list is fixed:\n\n"
    "SHIGELLA, SALMONELLA, YERSINIA, CAMPYLOBACTER\n\n"
    "And all four are INVASIVE. THAT IS NOT A COINCIDENCE: reactive arthritis requires MUCOSAL INVASION "
    "AND A SYSTEMIC IMMUNE RESPONSE to bacterial antigen. An organism that stays in the lumen secreting "
    "toxin provokes no such response.\n\n"
    "WARNING, SO ETEC CANNOT HAVE BEEN THE CAUSE — for TWO INDEPENDENT REASONS:\n\n"
    "ONE: ETEC DOES NOT CAUSE BLOODY DIARRHOEA. The stem says 'bloody diarrhoea a month ago', and ETEC "
    "is watery.\n\n"
    "TWO: ETEC IS NOT INVASIVE, so it does not produce reactive arthritis.\n\n"
    "TWO INDEPENDENT REASONS, EITHER OF WHICH ALONE SUFFICES — and that makes it the definitive answer.",
    ["یکی از چهار عامل روده‌ای کلاسیک آرتریت واکنشی؛ مهاجم است و اسهال خونی می‌دهد.",
     "هم مهاجم است و هم از عوامل شناخته‌شده‌ی آرتریت واکنشی.",
     "از چهار عامل کلاسیک است و به‌ویژه با درگیری مفصلی و ایلئیت شناخته می‌شود.",
     "پاسخ صحیح — ETEC نه اسهال خونی می‌دهد و نه مهاجم است، پس آرتریت واکنشی نمی‌سازد."],
    ["One of the four classic enteric triggers of reactive arthritis; invasive and causes bloody diarrhoea.",
     "Both invasive and a recognised trigger of reactive arthritis.",
     "One of the four classic triggers, particularly known for joint involvement and ileitis.",
     "Correct — ETEC causes neither bloody diarrhoea nor invasion, so it does not trigger reactive arthritis."],
    "**آرتریت واکنشی: شیگلا · سالمونلا · یرسینیا · کمپیلوباکتر — همه مهاجم.**",
    "Reactive arthritis: Shigella, Salmonella, Yersinia, Campylobacter — all invasive.",
    REFS)

# ============================================== HUS: FIVE ITEMS
HUS_FA = [
    "⚠️ **سندرم همولیتیک اورمیک یک سه‌گانه است، و فقط همین سه.**",
    "**یک: آنمی همولیتیک میکروآنژیوپاتیک — با شیستوسیت و کومبس منفی.**",
    "**دو: ترومبوسیتوپنی.**",
    "**سه: نارسایی حاد کلیه.**",
    "**لکوسیتوز جزء سه‌گانه نیست، هرچند شایع است و پیش‌آگهی بدتر را نشان می‌دهد.**",
    "⚠️ **و کومبس منفی نکته‌ی کلیدی است: همولیز مکانیکی است، نه ایمنی.**",
    "**گلبول قرمز در عبور از عروق پر از فیبرین، فیزیکی تکه‌تکه می‌شود.**",
    "**و همان تکه‌ها شیستوسیت‌اند: امضای میکروآنژیوپاتی.**",
    "**سازوکار کل بیماری، سم شیگا است.**",
    "**سم شیگا به اندوتلیوم عروق کوچک — به‌ویژه گلومرول — می‌چسبد و آن را می‌کشد.**",
    "**آسیب اندوتلیال، ترومبوز موضعی و مصرف پلاکت را راه می‌اندازد.**",
    "⚠️ **دو ارگانیسم سم شیگا می‌سازند: شیگلا دیسانتریه تیپ ۱ و EHEC (اُ۱۵۷:اچ۷).**",
    "**کمپیلوباکتر، سالمونلا و آمیب سم شیگا نمی‌سازند و HUS نمی‌دهند.**",
    "**و مهم‌ترین نکته‌ی درمانی: آنتی‌بیوتیک در EHEC مشکوک می‌تواند HUS را تسریع کند.**",
    "**چون کشتن باکتری، بار سم را یک‌جا آزاد می‌کند.**",
]
HUS_EN = [
    "WARNING: HAEMOLYTIC URAEMIC SYNDROME IS A TRIAD, and only these three.",
    "ONE: microangiopathic haemolytic anaemia — with schistocytes and a NEGATIVE Coombs test.",
    "TWO: thrombocytopenia.",
    "THREE: acute renal failure.",
    "Leucocytosis is NOT part of the triad, though it is common and marks a worse prognosis.",
    "WARNING, AND THE NEGATIVE COOMBS IS THE KEY POINT: the haemolysis is MECHANICAL, not immune.",
    "The red cell is physically shredded as it passes through fibrin-filled vessels.",
    "And those fragments are the schistocytes: the signature of microangiopathy.",
    "The mechanism of the whole disease is SHIGA TOXIN.",
    "Shiga toxin binds the endothelium of small vessels — especially the glomerulus — and kills it.",
    "Endothelial injury sets off local thrombosis and platelet consumption.",
    "WARNING, TWO ORGANISMS MAKE SHIGA TOXIN: Shigella dysenteriae type 1 and EHEC (O157:H7).",
    "Campylobacter, Salmonella and Entamoeba make no Shiga toxin and do not cause HUS.",
    "And the key management point: ANTIBIOTICS IN SUSPECTED EHEC MAY PRECIPITATE HUS.",
    "Because killing the organism releases its whole toxin load at once.",
]

add("book:289", "recall", "easy",
    "**HUS از عوارض EHEC است — چون سم شیگا می‌سازد.**",
    "HUS is a complication of EHEC — because it makes Shiga toxin.",
    HUS_FA,
    HUS_EN,
    "این ساده‌ترین سؤال خوشه‌ی HUS است و **قاعده را مستقیم** می‌پرسد.\n\n"
    "⚠️ **سندرم همولیتیک اورمیک از عوارض اشرشیاکلی انتروهموراژیک (EHEC) است.**\n\n"
    "**چرا؟ چون EHEC — و به‌ویژه سروتیپ O157:H7 — سم شیگا (وروتوکسین) می‌سازد.**\n\n"
    "**زنجیره‌ی رویدادها را دنبال کنید:**\n\n"
    "خوردن گوشت نیم‌پز (به‌ویژه همبرگر) یا شیر غیرپاستوریزه → EHEC در کولون مستقر می‌شود → "
    "**سم شیگا تولید می‌کند** → سم وارد جریان خون می‌شود → **به گیرنده‌های Gb3 روی اندوتلیوم "
    "عروق کوچک می‌چسبد** (و گلومرول کلیه بیشترین چگالی این گیرنده را دارد) → **اندوتلیوم "
    "می‌میرد** → ترومبوز موضعی و رسوب فیبرین → و از اینجا هر سه جزء سه‌گانه زاده می‌شوند:\n\n"
    "**گلبول قرمز در عبور از شبکه‌ی فیبرین تکه‌تکه می‌شود** → **آنمی همولیتیک میکروآنژیوپاتیک "
    "با شیستوسیت**.\n\n"
    "**پلاکت‌ها در ترومبوزهای موضعی مصرف می‌شوند** → **ترومبوسیتوپنی**.\n\n"
    "**گلومرول‌ها مسدود می‌شوند** → **نارسایی حاد کلیه**.\n\n"
    "**پس هر سه جزء از یک مکانیسم واحد می‌آیند** — و به همین دلیل با هم می‌آیند.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**سالمونلاهای روده‌ای:** گاستروآنتریت التهابی و گاهی باکتریمی می‌دهند، ولی **سم شیگا "
    "نمی‌سازند** و HUS نمی‌دهند.\n\n"
    "**کلستریدیوم پرفرانژنس:** عامل **مسمومیت غذایی سم‌محور** است — اسهال آبکی و کرامپ، "
    "معمولاً ظرف ۸ تا ۱۶ ساعت پس از گوشت مانده. **نه تهاجمی است نه سم شیگا می‌سازد.**\n\n"
    "⚠️ **کمپیلوباکتر ژژونی:** این نزدیک‌ترین رقیب است، چون **اسهال خونی می‌دهد** و مهاجم "
    "است. ولی **سم شیگا نمی‌سازد**، پس **HUS نمی‌دهد**. عارضه‌ی دیررس مشخص کمپیلوباکتر چیز "
    "دیگری است: **سندرم گیلن-باره**. **این دو را با هم اشتباه نگیرید — EHEC کلیه را می‌زند، "
    "کمپیلوباکتر عصب را.**",
    "This is the simplest question in the HUS cluster and asks THE RULE DIRECTLY.\n\n"
    "WARNING, HAEMOLYTIC URAEMIC SYNDROME IS A COMPLICATION OF ENTEROHAEMORRHAGIC E. COLI (EHEC).\n\n"
    "WHY? Because EHEC — especially serotype O157:H7 — makes SHIGA TOXIN (verotoxin).\n\n"
    "FOLLOW THE CHAIN OF EVENTS:\n\n"
    "Eating undercooked meat (especially hamburger) or unpasteurised milk; EHEC colonises the colon; IT "
    "PRODUCES SHIGA TOXIN; the toxin enters the bloodstream; IT BINDS Gb3 RECEPTORS ON SMALL-VESSEL "
    "ENDOTHELIUM (and the renal glomerulus has the highest density of these receptors); THE ENDOTHELIUM "
    "DIES; local thrombosis and fibrin deposition follow; and from here all three components of the "
    "triad are born:\n\n"
    "RED CELLS ARE SHREDDED passing through the fibrin mesh, giving MICROANGIOPATHIC HAEMOLYTIC ANAEMIA "
    "WITH SCHISTOCYTES.\n\n"
    "PLATELETS ARE CONSUMED in the local thromboses, giving THROMBOCYTOPENIA.\n\n"
    "THE GLOMERULI ARE OCCLUDED, giving ACUTE RENAL FAILURE.\n\n"
    "SO ALL THREE COMPONENTS ARISE FROM ONE MECHANISM — which is why they arrive together.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ENTERIC SALMONELLAE: they cause inflammatory gastroenteritis and sometimes bacteraemia, but they "
    "MAKE NO SHIGA TOXIN and do not cause HUS.\n\n"
    "CLOSTRIDIUM PERFRINGENS: a TOXIN-MEDIATED FOOD POISONING — watery diarrhoea and cramps, usually 8 "
    "to 16 hours after reheated meat. It is NEITHER INVASIVE NOR A SHIGA TOXIN PRODUCER.\n\n"
    "WARNING, CAMPYLOBACTER JEJUNI: this is the closest competitor, because it DOES cause bloody "
    "diarrhoea and IS invasive. But it MAKES NO SHIGA TOXIN, so it DOES NOT CAUSE HUS. Campylobacter's "
    "characteristic late complication is something else entirely: GUILLAIN-BARRE SYNDROME. DO NOT "
    "CONFUSE THE TWO — EHEC HITS THE KIDNEY, CAMPYLOBACTER HITS THE NERVE.",
    ["گاستروآنتریت التهابی می‌دهند ولی سم شیگا نمی‌سازند، پس HUS نمی‌دهند.",
     "پاسخ صحیح — EHEC سم شیگا می‌سازد که اندوتلیوم گلومرول را می‌کشد.",
     "مسمومیت غذایی سم‌محور با اسهال آبکی است؛ نه مهاجم است نه سم شیگا می‌سازد.",
     "اسهال خونی می‌دهد ولی سم شیگا ندارد؛ عارضه‌ی دیررس آن گیلن-باره است، نه HUS."],
    ["They cause inflammatory gastroenteritis but make no Shiga toxin, so no HUS.",
     "Correct — EHEC makes Shiga toxin, which kills glomerular endothelium.",
     "A toxin-mediated food poisoning with watery diarrhoea; neither invasive nor Shiga-toxin producing.",
     "Causes bloody diarrhoea but has no Shiga toxin; its late complication is Guillain-Barre, not HUS."],
    "**EHEC کلیه را می‌زند (HUS)؛ کمپیلوباکتر عصب را (گیلن-باره).**",
    "EHEC hits the kidney (HUS); Campylobacter hits the nerve (Guillain-Barre).",
    REFS)

add("book:290", "vignette", "medium",
    "**آمیب سم شیگا نمی‌سازد — پس تنها گزینه‌ای است که HUS نمی‌دهد.**",
    "Entamoeba makes no Shiga toxin — so it is the only option that does not cause HUS.",
    HUS_FA + [
        "**تابلوی این بیمار HUS کامل است و هر سه جزء در متن آمده.**",
        "**هموگلوبین ۷ و شیستوسیت در لام: آنمی همولیتیک میکروآنژیوپاتیک.**",
        "**پلاکت ۲۰ هزار: ترومبوسیتوپنی.**",
        "⚠️ **کراتینین ۴: نارسایی حاد کلیه.**",
        "**و کومبس منفی، همولیز ایمنی را رد و همولیز مکانیکی را تأیید می‌کند.**",
        "**شیگلا و EHEC هر دو سم شیگا می‌سازند، پس هر دو محتمل‌اند.**",
        "**کمپیلوباکتر در برخی گزارش‌های نادر با HUS همراه شده است.**",
        "**ولی آمیب هیستولیتیکا هرگز — سازوکار آن تهاجم بافتی مستقیم است، نه سم شیگا.**",
    ],
    HUS_EN + [
        "This patient's picture is complete HUS, and all three components are in the stem.",
        "Haemoglobin 7 with schistocytes on the film: microangiopathic haemolytic anaemia.",
        "Platelets 20,000: thrombocytopenia.",
        "WARNING, CREATININE 4: acute renal failure.",
        "And the negative Coombs excludes immune haemolysis and confirms the mechanical kind.",
        "Shigella and EHEC both make Shiga toxin, so both are plausible.",
        "Campylobacter has been linked to HUS in rare reports.",
        "But Entamoeba histolytica never — its mechanism is direct tissue invasion, not Shiga toxin.",
    ],
    "این سؤال HUS را با **همه‌ی اعداد** توصیف می‌کند، و می‌خواهد عاملی را که نمی‌تواند باشد "
    "پیدا کنید.\n\n"
    "**اول تابلو را بخوانیم — هر سه جزء سه‌گانه حاضرند:**\n\n"
    "**هموگلوبین ۷ گرم + شیستوسیت در لام خون محیطی + کومبس منفی** = **آنمی همولیتیک "
    "میکروآنژیوپاتیک**. ⚠️ **کومبس منفی حیاتی است:** یعنی همولیز **ایمنی نیست**؛ گلبول قرمز "
    "به‌طور **مکانیکی** در عبور از عروق پر از فیبرین تکه‌تکه شده. و آن تکه‌ها همان **شیستوسیت**‌اند.\n\n"
    "**پلاکت ۲۰٬۰۰۰** = **ترومبوسیتوپنی** (از مصرف در ترومبوزهای موضعی).\n\n"
    "**کراتینین ۴** = **نارسایی حاد کلیه**.\n\n"
    "**و سرنخ زمینه‌ای: اسهال خونی چند روز قبل.**\n\n"
    "**پس تشخیص قطعی است: HUS پس از اسهال.**\n\n"
    "**حالا کدام عامل می‌تواند و کدام نمی‌تواند؟**\n\n"
    "**شیگلا** — **می‌تواند**. شیگلا دیسانتریه تیپ ۱ **سم شیگا** می‌سازد (نام سم از همین "
    "باکتری آمده).\n\n"
    "**EHEC** — **می‌تواند**. شایع‌ترین علت HUS در کودکان کشورهای توسعه‌یافته.\n\n"
    "**کمپیلوباکتر** — در **گزارش‌های نادری** با HUS همراه شده است. رابطه‌ی آن قوی و "
    "تثبیت‌شده نیست، ولی در فهرست تشخیص‌های افتراقی «مطرح می‌شود».\n\n"
    "⚠️ **آنتاموبا هیستولیتیکا — نمی‌تواند.**\n\n"
    "**چرا؟ سازوکار آسیب آمیب کاملاً متفاوت است.** آمیب با **تهاجم مستقیم بافتی** آسیب "
    "می‌زند: تروفوزوئیت به مخاط حمله می‌کند، زخم‌های فلاسک‌شکل می‌سازد، و می‌تواند به کبد "
    "برسد و آبسه بدهد. **هیچ سم شیگایی در کار نیست، و هیچ آسیب اندوتلیال سیستمیکی هم نیست.**\n\n"
    "**پس آمیب می‌تواند دیسانتری بدهد — ولی هرگز HUS نمی‌دهد.**\n\n"
    "**و یادآوری بالینی حیاتی که سؤال نپرسیده: در اسهال خونی مشکوک به EHEC، آنتی‌بیوتیک "
    "ندهید.** کشتن باکتری **بار سم را یک‌جا آزاد می‌کند** و می‌تواند HUS را تسریع کند.",
    "This question describes HUS WITH ALL ITS NUMBERS and asks you to find the organism that cannot be "
    "responsible.\n\n"
    "FIRST READ THE PICTURE — all three components of the triad are present:\n\n"
    "HAEMOGLOBIN 7 plus SCHISTOCYTES on the film plus a NEGATIVE COOMBS = MICROANGIOPATHIC HAEMOLYTIC "
    "ANAEMIA. WARNING, THE NEGATIVE COOMBS IS VITAL: it means the haemolysis IS NOT IMMUNE; the red "
    "cell has been shredded MECHANICALLY passing through fibrin-filled vessels. And those fragments are "
    "the SCHISTOCYTES.\n\n"
    "PLATELETS 20,000 = THROMBOCYTOPENIA (consumed in the local thromboses).\n\n"
    "CREATININE 4 = ACUTE RENAL FAILURE.\n\n"
    "AND THE BACKGROUND CLUE: bloody diarrhoea a few days earlier.\n\n"
    "SO THE DIAGNOSIS IS CERTAIN: POST-DIARRHOEAL HUS.\n\n"
    "NOW WHICH ORGANISM CAN, AND WHICH CANNOT?\n\n"
    "SHIGELLA — CAN. Shigella dysenteriae type 1 makes SHIGA TOXIN (the toxin is named after this "
    "bacterium).\n\n"
    "EHEC — CAN. The commonest cause of HUS in children in developed countries.\n\n"
    "CAMPYLOBACTER — has been linked to HUS in RARE REPORTS. The association is not strong or "
    "established, but it is 'considered' in the differential.\n\n"
    "WARNING, ENTAMOEBA HISTOLYTICA — CANNOT.\n\n"
    "WHY? Because the amoeba's mechanism of injury is entirely different. It damages by DIRECT TISSUE "
    "INVASION: the trophozoite attacks the mucosa, creates flask-shaped ulcers, and can reach the liver "
    "and form an abscess. THERE IS NO SHIGA TOXIN AND NO SYSTEMIC ENDOTHELIAL INJURY.\n\n"
    "SO THE AMOEBA CAN CAUSE DYSENTERY — BUT NEVER HUS.\n\n"
    "AND A VITAL CLINICAL REMINDER THE QUESTION DID NOT ASK: IN BLOODY DIARRHOEA WITH SUSPECTED EHEC, "
    "DO NOT GIVE ANTIBIOTICS. Killing the bacterium RELEASES ITS WHOLE TOXIN LOAD AT ONCE and can "
    "precipitate HUS.",
    ["می‌تواند — شیگلا دیسانتریه تیپ ۱ سم شیگا می‌سازد، و نام سم از همین باکتری است.",
     "می‌تواند — شایع‌ترین علت HUS در کودکان است.",
     "در گزارش‌های نادری با HUS همراه شده و در افتراق مطرح می‌شود.",
     "پاسخ صحیح — آمیب با تهاجم مستقیم بافتی آسیب می‌زند و هیچ سم شیگایی نمی‌سازد."],
    ["Can — Shigella dysenteriae type 1 makes Shiga toxin, which is named after it.",
     "Can — the commonest cause of HUS in children.",
     "Has been linked to HUS in rare reports and is considered in the differential.",
     "Correct — the amoeba damages by direct tissue invasion and makes no Shiga toxin."],
    "**کومبس منفی = همولیز مکانیکی، نه ایمنی — و شیستوسیت اثبات آن است.**",
    "A negative Coombs means mechanical, not immune, haemolysis — and the schistocyte proves it.",
    REFS)

add("book:291", "vignette", "medium",
    "**نارسایی کلیه پس از اسهال خونی: شیگلا دیسانتریه، تنها گزینه‌ی سم‌شیگاساز.**",
    "Renal failure after bloody diarrhoea: Shigella dysenteriae, the only Shiga-toxin producer here.",
    HUS_FA + [
        "**در این سؤال، سه گزینه‌ی دیگر هیچ‌کدام سم شیگا نمی‌سازند.**",
        "**پس تنها گزینه‌ی ممکن، شیگلا دیسانتریه است.**",
        "⚠️ **و آزمایش مدفوع تشخیص را تأیید می‌کند: گلبول قرمز فراوان و گلبول سفید ۱۰ تا ۱۵.**",
        "**یعنی اسهال التهابی، که ETEC را از پایه رد می‌کند.**",
        "**فاصله‌ی چهار روز هم با HUS هم‌خوان است: معمولاً ۵ تا ۱۰ روز پس از شروع اسهال.**",
    ],
    HUS_EN + [
        "In this question none of the other three options makes Shiga toxin.",
        "So the only possible answer is Shigella dysenteriae.",
        "WARNING, AND THE STOOL CONFIRMS the diagnosis: many red cells and 10 to 15 white cells.",
        "That is inflammatory diarrhoea, which rules ETEC out from the start.",
        "The four-day interval also fits HUS: typically 5 to 10 days after the diarrhoea begins.",
    ],
    "این سؤال با **حذف** حل می‌شود، و حذف بر پایه‌ی یک قاعده‌ی واحد انجام می‌گیرد: **کدام "
    "سم شیگا می‌سازد؟**\n\n"
    "**بیمار: خانم جوان، چهار روز پس از شروع اسهال خونی، دچار نارسایی حاد کلیه و آنمی شدید "
    "شده. در آزمایش مدفوع: گلبول قرمز فراوان و گلبول سفید ۱۰ تا ۱۵.**\n\n"
    "**دو چیز را از تابلو بگیرید:**\n\n"
    "**یک — این اسهال التهابی است.** گلبول سفید و قرمز در مدفوع، تهاجم را قطعی می‌کند.\n\n"
    "⚠️ **دو — این HUS است.** نارسایی حاد کلیه + آنمی شدید، چند روز پس از اسهال خونی. "
    "فاصله‌ی چهار روز کاملاً هم‌خوان است (HUS معمولاً **۵ تا ۱۰ روز** پس از شروع اسهال رخ "
    "می‌دهد).\n\n"
    "**حالا گزینه‌ها را با قاعده‌ی سم شیگا بسنجید:**\n\n"
    "**شیگلا دیسانتریه** — ✔ **سم شیگا می‌سازد.** تیپ ۱ آن قوی‌ترین تولیدکننده است. **پاسخ.**\n\n"
    "**انتروتوکسیکوژنیک ای‌کلای (ETEC)** — ✘ **دو ایراد.** یک: سم شیگا نمی‌سازد. دو: **اصلاً "
    "اسهال خونی نمی‌دهد** — آبکی و بدون گلبول سفید است، که با آزمایش مدفوع این بیمار در تضاد "
    "کامل است. (**اگر EHEC بود، پاسخ می‌شد** — و همین دقیقاً دام سؤال است.)\n\n"
    "**کمپیلوباکتر ژژونی** — ✘ اسهال خونی می‌دهد، ولی **سم شیگا نمی‌سازد**. عارضه‌ی دیررس آن "
    "**گیلن-باره** است، نه HUS.\n\n"
    "**یرسینیا انتروکولیتیکا** — ✘ اسهال التهابی و **ایلئیت ترمینال** می‌دهد که می‌تواند "
    "آپاندیسیت را تقلید کند (شبه‌آپاندیسیت). و از عوامل **آرتریت واکنشی** است. ولی **سم شیگا "
    "نمی‌سازد** و HUS نمی‌دهد.\n\n"
    "**پس فقط یک گزینه هر دو شرط را دارد: هم اسهال خونی می‌دهد و هم سم شیگا می‌سازد.**",
    "This question is solved BY ELIMINATION, and the elimination rests on a single rule: WHICH ONE "
    "MAKES SHIGA TOXIN?\n\n"
    "THE PATIENT: a young woman who, four days after the onset of bloody diarrhoea, has developed acute "
    "renal failure and severe anaemia. Stool: many red cells and 10 to 15 white cells.\n\n"
    "TAKE TWO THINGS FROM THE PICTURE:\n\n"
    "ONE — THIS IS INFLAMMATORY DIARRHOEA. White and red cells in the stool make invasion certain.\n\n"
    "WARNING, TWO — THIS IS HUS. Acute renal failure plus severe anaemia a few days after bloody "
    "diarrhoea. The four-day interval fits perfectly (HUS typically occurs 5 to 10 DAYS after the "
    "diarrhoea starts).\n\n"
    "NOW TEST THE OPTIONS AGAINST THE SHIGA TOXIN RULE:\n\n"
    "SHIGELLA DYSENTERIAE — YES, IT MAKES SHIGA TOXIN. Its type 1 is the most powerful producer. THE "
    "ANSWER.\n\n"
    "ENTEROTOXIGENIC E. COLI (ETEC) — NO, on TWO counts. One: it makes no Shiga toxin. Two: IT DOES NOT "
    "CAUSE BLOODY DIARRHOEA AT ALL — it is watery and free of white cells, in complete contradiction to "
    "this patient's stool. (IF IT HAD SAID EHEC IT WOULD BE THE ANSWER — and that is exactly the trap.)\n\n"
    "CAMPYLOBACTER JEJUNI — NO. It causes bloody diarrhoea but MAKES NO SHIGA TOXIN. Its late "
    "complication is GUILLAIN-BARRE, not HUS.\n\n"
    "YERSINIA ENTEROCOLITICA — NO. It causes inflammatory diarrhoea and TERMINAL ILEITIS which can mimic "
    "appendicitis (pseudoappendicitis), and it is a trigger of REACTIVE ARTHRITIS. But it MAKES NO "
    "SHIGA TOXIN and does not cause HUS.\n\n"
    "SO ONLY ONE OPTION MEETS BOTH CONDITIONS: it causes bloody diarrhoea AND it makes Shiga toxin.",
    ["پاسخ صحیح — تنها گزینه‌ای که هم اسهال خونی می‌دهد و هم سم شیگا می‌سازد.",
     "دو ایراد: سم شیگا نمی‌سازد، و اصلاً اسهال خونی نمی‌دهد؛ اگر EHEC بود پاسخ می‌شد.",
     "اسهال خونی می‌دهد ولی سم شیگا ندارد؛ عارضه‌ی آن گیلن-باره است.",
     "ایلئیت ترمینال و آرتریت واکنشی می‌دهد، ولی سم شیگا نمی‌سازد."],
    ["Correct — the only option that both causes bloody diarrhoea and makes Shiga toxin.",
     "Two faults: no Shiga toxin, and it does not cause bloody diarrhoea at all; EHEC would have been the answer.",
     "Causes bloody diarrhoea but has no Shiga toxin; its complication is Guillain-Barre.",
     "Causes terminal ileitis and reactive arthritis, but makes no Shiga toxin."],
    "**HUS ۵ تا ۱۰ روز پس از اسهال می‌آید — و فقط از سم شیگا.**",
    "HUS arrives 5 to 10 days after the diarrhoea — and only from Shiga toxin.",
    REFS)

add("book:292", "vignette", "medium",
    "**کودک با HUS پس از اسهال تب‌دار: شیگلا دیسانتری، و اعداد سه‌گانه را تأیید می‌کنند.**",
    "A child with HUS after febrile diarrhoea: Shigella dysenteriae, and the numbers confirm the triad.",
    HUS_FA + [
        "**اعداد این بیمار سه‌گانه را کامل می‌کنند و باید خوانده شوند.**",
        "**هموگلوبین ۷٫۵: آنمی.**",
        "**پلاکت ۵۰۰۰ در میکرولیتر: ترومبوسیتوپنی بسیار شدید.**",
        "⚠️ **و همین پلاکت پایین است که خونریزی از لثه‌ها را توضیح می‌دهد.**",
        "**اولیگوری و ادم اندام‌ها: نارسایی حاد کلیه.**",
        "**گلبول سفید ۵۰٬۰۰۰ هم لکوسیتوز شدید است.**",
        "**لکوسیتوز جزء سه‌گانه نیست، ولی در HUS پس از شیگلا شایع و نشانه‌ی شدت است.**",
        "**و اسهال همراه با تب، به نفع شیگلا در برابر EHEC است.**",
        "⚠️ **چون EHEC معمولاً تب نمی‌دهد یا تب خفیفی می‌دهد.**",
    ],
    HUS_EN + [
        "This patient's numbers complete the triad and must be read.",
        "Haemoglobin 7.5: anaemia.",
        "Platelets 5,000 per microlitre: very severe thrombocytopenia.",
        "WARNING, AND IT IS THAT LOW PLATELET COUNT that explains the gum bleeding.",
        "Oliguria and limb oedema: acute renal failure.",
        "A white count of 50,000 is also a marked leucocytosis.",
        "Leucocytosis is not part of the triad, but it is common in post-Shigella HUS and marks severity.",
        "And diarrhoea WITH FEVER favours Shigella over EHEC.",
        "WARNING, BECAUSE EHEC USUALLY CAUSES NO FEVER, or only a mild one.",
    ],
    "این سؤال HUS را در **کودک** توصیف می‌کند و **اعداد را برای تشخیص لازم می‌کند**.\n\n"
    "**بیمار: پسر ۷ ساله، از چند روز قبل اسهال همراه با تب، حالا با خونریزی از لثه‌ها و "
    "ادم اندام‌ها به اورژانس آمده. اولیگوریک و رنگ‌پریده است. آزمایش: هموگلوبین ۷٫۵، گلبول "
    "سفید ۵۰٬۰۰۰، پلاکت ۵۰۰۰ در میکرولیتر.**\n\n"
    "**بیایید هر عدد را به یک جزء سه‌گانه ترجمه کنیم:**\n\n"
    "**هموگلوبین ۷٫۵ + رنگ‌پریدگی** = **آنمی همولیتیک**.\n\n"
    "⚠️ **پلاکت ۵۰۰۰** = **ترومبوسیتوپنی بسیار شدید**. و همین **خونریزی از لثه‌ها** را "
    "توضیح می‌دهد — با پلاکت زیر ۱۰٬۰۰۰، خونریزی خودبه‌خودی مخاطی رخ می‌دهد.\n\n"
    "**اولیگوری + ادم اندام‌ها** = **نارسایی حاد کلیه** با احتباس مایع.\n\n"
    "**پس هر سه جزء حاضرند: HUS قطعی است.**\n\n"
    "**و گلبول سفید ۵۰٬۰۰۰؟** این **لکوسیتوز شدید** است. **جزء سه‌گانه نیست**، ولی در HUS "
    "پس از شیگلا **شایع** است و **نشانه‌ی شدت و پیش‌آگهی بدتر** به شمار می‌رود.\n\n"
    "**حالا کدام عامل؟**\n\n"
    "**شیگلا دیسانتری** — ✔ سم شیگا می‌سازد. **و یک سرنخ اضافه به نفع آن هست: تب.** ⚠️ "
    "**اسهال شیگلایی معمولاً با تب بالا همراه است، در حالی که EHEC معمولاً تب نمی‌دهد یا "
    "تب خفیفی می‌دهد.** لکوسیتوز شدید هم بیشتر با شیگلا می‌خواند.\n\n"
    "**آنتاموبا هیستولیتیکا** — ✘ سم شیگا نمی‌سازد؛ با تهاجم مستقیم بافتی آسیب می‌زند.\n\n"
    "**ویبریوکلرا** — ✘ **از پایه رد می‌شود**: اسهال آبکی و **بدون خون و بدون تب** می‌دهد. "
    "و هرگز HUS نمی‌دهد.\n\n"
    "**روتاویروس** — ✘ عامل شایع اسهال آبکی کودکان است، ولی **غیرالتهابی** است و **HUS "
    "نمی‌دهد**.",
    "This question describes HUS IN A CHILD and MAKES THE NUMBERS NECESSARY for the diagnosis.\n\n"
    "THE PATIENT: a 7-year-old boy with several days of diarrhoea AND FEVER, now brought to the "
    "emergency department with bleeding gums and limb oedema. He is oliguric and pale. Tests: "
    "haemoglobin 7.5, white cells 50,000, platelets 5,000 per microlitre.\n\n"
    "LET US TRANSLATE EACH NUMBER INTO A COMPONENT OF THE TRIAD:\n\n"
    "HAEMOGLOBIN 7.5 plus PALLOR = HAEMOLYTIC ANAEMIA.\n\n"
    "WARNING, PLATELETS 5,000 = VERY SEVERE THROMBOCYTOPENIA. And that explains THE BLEEDING GUMS — "
    "below 10,000, spontaneous mucosal bleeding occurs.\n\n"
    "OLIGURIA plus LIMB OEDEMA = ACUTE RENAL FAILURE with fluid retention.\n\n"
    "SO ALL THREE COMPONENTS ARE PRESENT: HUS IS CERTAIN.\n\n"
    "AND THE WHITE COUNT OF 50,000? That is MARKED LEUCOCYTOSIS. It is NOT PART OF THE TRIAD, but it is "
    "COMMON in post-Shigella HUS and marks SEVERITY AND A WORSE PROGNOSIS.\n\n"
    "NOW WHICH ORGANISM?\n\n"
    "SHIGELLA DYSENTERIAE — YES, it makes Shiga toxin. AND THERE IS AN EXTRA CLUE IN ITS FAVOUR: THE "
    "FEVER. WARNING, SHIGELLA DIARRHOEA IS USUALLY ACCOMPANIED BY HIGH FEVER, WHEREAS EHEC USUALLY "
    "CAUSES NO FEVER OR ONLY A MILD ONE. The marked leucocytosis also fits Shigella better.\n\n"
    "ENTAMOEBA HISTOLYTICA — NO; it makes no Shiga toxin and damages by direct tissue invasion.\n\n"
    "VIBRIO CHOLERAE — NO, REJECTED FROM THE START: it gives watery diarrhoea WITH NO BLOOD AND NO "
    "FEVER, and never causes HUS.\n\n"
    "ROTAVIRUS — NO. A common cause of watery diarrhoea in children, but NON-INFLAMMATORY and it does "
    "not cause HUS.",
    ["سم شیگا نمی‌سازد؛ با تهاجم مستقیم بافتی آسیب می‌زند و HUS نمی‌دهد.",
     "پاسخ صحیح — سم شیگا می‌سازد، و تب و لکوسیتوز شدید هم به نفع شیگلاست.",
     "اسهال آبکی بدون خون و بدون تب می‌دهد؛ هرگز HUS نمی‌سازد.",
     "عامل شایع اسهال آبکی کودکان است ولی غیرالتهابی است و HUS نمی‌دهد."],
    ["Makes no Shiga toxin; damages by direct tissue invasion and does not cause HUS.",
     "Correct — it makes Shiga toxin, and the fever and marked leucocytosis also favour Shigella.",
     "Gives watery diarrhoea with no blood and no fever; it never causes HUS.",
     "A common cause of watery childhood diarrhoea but non-inflammatory, and it does not cause HUS."],
    "**تب به نفع شیگلاست؛ EHEC معمولاً بی‌تب است.**",
    "Fever favours Shigella; EHEC is usually afebrile.",
    REFS)

add("book:327", "vignette", "easy",
    "**رنگ‌پریدگی + خونریزی + اوره و کراتینین بالا پس از اسهال خونی = سندرم همولیتیک اورمیک.**",
    "Pallor plus bleeding plus a raised urea and creatinine after bloody diarrhoea = HAEMOLYTIC URAEMIC SYNDROME.",
    HUS_FA + [
        "**اینجا سؤال نام سندرم را می‌خواهد، نه عامل آن.**",
        "**و الگوی زمانی کلاسیک است: اسهال خونی هفته‌ی پیش، حالا سندرم.**",
        "⚠️ **HUS معمولاً وقتی ظاهر می‌شود که اسهال در حال بهبود است.**",
        "**پس «اسهال درمان شد و بهبود یافت» تشخیص را رد نمی‌کند — تأیید می‌کند.**",
        "**هموگلوبین ۸ و پلاکت ۱۰٬۰۰۰ و اوره و کراتینین بالا: هر سه جزء.**",
        "**و ورم صورت، احتباس مایع ناشی از نارسایی کلیه است.**",
    ],
    HUS_EN + [
        "Here the question asks for the NAME of the syndrome, not its organism.",
        "And the temporal pattern is classic: bloody diarrhoea last week, the syndrome now.",
        "WARNING, HUS TYPICALLY APPEARS AS THE DIARRHOEA IS RESOLVING.",
        "So 'the diarrhoea was treated and recovered' does not exclude the diagnosis — it supports it.",
        "Haemoglobin 8, platelets 10,000, and raised urea and creatinine: all three components.",
        "And the facial swelling is fluid retention from the renal failure.",
    ],
    "این سؤال **نام سندرم** را می‌خواهد و یک نکته‌ی زمانی مهم در خود دارد.\n\n"
    "**بیمار: کودک ۶ ساله با رنگ‌پریدگی، ورم صورت، و خونریزی از بینی و لثه. مادرش می‌گوید "
    "کودک هفته‌ی پیش اسهال خونی داشته که درمان شده و بهبود یافته است. آزمایش: هموگلوبین ۸، "
    "گلبول سفید ۲۵٬۰۰۰، پلاکت ۱۰٬۰۰۰، و افزایش اوره و کراتینین.**\n\n"
    "**سه‌گانه را از روی اعداد بسازید:**\n\n"
    "**هموگلوبین ۸ + رنگ‌پریدگی** = **آنمی**. **پلاکت ۱۰٬۰۰۰** = **ترومبوسیتوپنی**، که "
    "**خونریزی از بینی و لثه** را توضیح می‌دهد. **اوره و کراتینین بالا + ورم صورت** = "
    "**نارسایی حاد کلیه** با احتباس مایع.\n\n"
    "**پس: سندرم همولیتیک اورمیک.**\n\n"
    "⚠️ **حالا نکته‌ی زمانی که ارزش بالینی واقعی دارد:** مادر می‌گوید اسهال **«درمان شده و "
    "بهبود یافته»** — و دانشجو ممکن است فکر کند این تشخیص را رد می‌کند. **برعکس است.**\n\n"
    "**HUS معمولاً ۵ تا ۱۰ روز پس از شروع اسهال ظاهر می‌شود، یعنی درست وقتی که اسهال در حال "
    "بهبود یا تمام‌شده است.** سم شیگا از قبل جذب شده و آسیب اندوتلیال را راه انداخته؛ عوارض "
    "آن با تأخیر خود را نشان می‌دهند. **پس بهبود اسهال، تشخیص را تأیید می‌کند، نه رد.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**سندرم ایکاری:** چنین موجودیت شناخته‌شده‌ای در این زمینه وجود ندارد.\n\n"
    "**سندرم روده‌ی تحریک‌پذیر:** یک اختلال **عملکردی مزمن** است — درد شکم و تغییر عادت "
    "اجابت مزاج، **بدون هیچ یافته‌ی آزمایشگاهی غیرطبیعی**. با آنمی، ترومبوسیتوپنی و نارسایی "
    "کلیه هیچ ربطی ندارد.\n\n"
    "⚠️ **سندرم رایتر (آرتریت واکنشی):** این هم **پس از اسهال مهاجم** می‌آید، پس رقیب "
    "معقولی به نظر می‌رسد. ولی تابلوی آن کاملاً متفاوت است: **آرتریت، اورتریت و کونژنکتیویت** "
    "— یعنی **مفصل و چشم و مجرا**، نه **خون و کلیه**. هیچ آنمی، ترومبوسیتوپنی یا نارسایی "
    "کلیه‌ای در رایتر وجود ندارد.",
    "This question asks for THE NAME OF THE SYNDROME and contains an important point about timing.\n\n"
    "THE PATIENT: a 6-year-old with pallor, facial swelling, and bleeding from the nose and gums. His "
    "mother says he had bloody diarrhoea LAST WEEK which was treated and RECOVERED. Tests: haemoglobin "
    "8, white cells 25,000, platelets 10,000, and raised urea and creatinine.\n\n"
    "BUILD THE TRIAD FROM THE NUMBERS:\n\n"
    "HAEMOGLOBIN 8 plus PALLOR = ANAEMIA. PLATELETS 10,000 = THROMBOCYTOPENIA, which explains the NOSE "
    "AND GUM BLEEDING. RAISED UREA AND CREATININE plus FACIAL SWELLING = ACUTE RENAL FAILURE with fluid "
    "retention.\n\n"
    "SO: HAEMOLYTIC URAEMIC SYNDROME.\n\n"
    "WARNING, NOW THE TIMING POINT WITH REAL CLINICAL VALUE: the mother says the diarrhoea WAS 'TREATED "
    "AND RECOVERED' — and a student may think this excludes the diagnosis. THE OPPOSITE IS TRUE.\n\n"
    "HUS TYPICALLY APPEARS 5 TO 10 DAYS AFTER THE DIARRHOEA BEGINS — that is, just as the diarrhoea is "
    "resolving or has ended. The Shiga toxin was absorbed earlier and set the endothelial injury in "
    "motion; its consequences declare themselves late. SO THE DIARRHOEA'S RECOVERY SUPPORTS THE "
    "DIAGNOSIS RATHER THAN EXCLUDING IT.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "'ICARY SYNDROME': no such recognised entity exists in this context.\n\n"
    "IRRITABLE BOWEL SYNDROME: a CHRONIC FUNCTIONAL disorder — abdominal pain and altered bowel habit "
    "WITH NO ABNORMAL LABORATORY FINDINGS AT ALL. It has nothing to do with anaemia, thrombocytopenia "
    "and renal failure.\n\n"
    "WARNING, REITER'S SYNDROME (reactive arthritis): this also follows INVASIVE DIARRHOEA, so it looks "
    "a reasonable competitor. But its picture is entirely different: ARTHRITIS, URETHRITIS AND "
    "CONJUNCTIVITIS — that is, JOINT, EYE AND URETHRA, not BLOOD AND KIDNEY. There is no anaemia, "
    "thrombocytopenia or renal failure in Reiter's.",
    ["چنین موجودیت شناخته‌شده‌ای در این زمینه وجود ندارد.",
     "پاسخ صحیح — آنمی، ترومبوسیتوپنی و نارسایی حاد کلیه پس از اسهال خونی.",
     "اختلال عملکردی مزمن بدون هیچ یافته‌ی آزمایشگاهی غیرطبیعی؛ بی‌ربط به این تابلو.",
     "پس از اسهال مهاجم می‌آید ولی مفصل و چشم و مجرا را می‌زند، نه خون و کلیه."],
    ["No such recognised entity exists in this context.",
     "Correct — anaemia, thrombocytopenia and acute renal failure after bloody diarrhoea.",
     "A chronic functional disorder with no abnormal laboratory findings; unrelated to this picture.",
     "It follows invasive diarrhoea but strikes joint, eye and urethra, not blood and kidney."],
    "**HUS وقتی می‌آید که اسهال دارد خوب می‌شود — پس بهبود اسهال آن را رد نمی‌کند.**",
    "HUS arrives as the diarrhoea is recovering — so recovery does not exclude it.",
    REFS)

add("book:328", "recall", "easy",
    "**لکوسیتوز جزء سه‌گانه‌ی HUS نیست — سه‌گانه فقط آنمی، ترومبوسیتوپنی و نارسایی کلیه است.**",
    "Leucocytosis is not part of the HUS triad — the triad is anaemia, thrombocytopenia and renal failure only.",
    HUS_FA,
    HUS_EN,
    "این کوتاه‌ترین سؤال خوشه است و **دقیقاً همان نکته‌ای را می‌سنجد که در سؤال‌های قبلی "
    "کنار گذاشتیم**.\n\n"
    "⚠️ **سه‌گانه‌ی تشخیصی HUS، و فقط همین سه:**\n\n"
    "**یک — آنمی همولیتیک میکروآنژیوپاتیک.** با **شیستوسیت** در لام خون محیطی و **کومبس "
    "منفی**. کومبس منفی حیاتی است: همولیز **مکانیکی** است، نه ایمنی — گلبول قرمز در عبور از "
    "عروق پر از فیبرین **فیزیکی تکه‌تکه می‌شود**.\n\n"
    "**دو — ترومبوسیتوپنی.** از **مصرف** پلاکت‌ها در ترومبوزهای میکروواسکولار.\n\n"
    "**سه — نارسایی حاد کلیه.** چون گلومرول بیشترین چگالی گیرنده‌ی Gb3 را دارد و بیشترین "
    "آسیب را از سم شیگا می‌بیند.\n\n"
    "**و لکوسیتوز؟**\n\n"
    "**در HUS شایع است** — به‌ویژه در نوع پس از شیگلا. و **نشانه‌ی پیش‌آگهی بدتر** هم هست: "
    "هرچه گلبول سفید بالاتر، خطر عوارض شدید بیشتر.\n\n"
    "⚠️ **ولی جزء سه‌گانه‌ی تشخیصی نیست.** یعنی برای تشخیص HUS **لازم نیست** لکوسیتوز داشته "
    "باشیم؛ و وجود آن به‌تنهایی هم تشخیص را نمی‌گذارد.\n\n"
    "**درس روش‌شناختی این سؤال، فراتر از خودش ارزش دارد:** فرق میان **«جزء تعریف»** و "
    "**«یافته‌ی همراه شایع»** را بشناسید. بسیاری از سؤال‌های «کدام جزء نیست» دقیقاً روی همین "
    "مرز ساخته می‌شوند. یافته‌ای که **شایع است** الزاماً **جزء تعریف** نیست.\n\n"
    "**و برای کامل شدن تصویر: چه چیز دیگری در HUS شایع است ولی جزء سه‌گانه نیست؟** "
    "**LDH بالا** (از همولیز)، **هاپتوگلوبین پایین** (مصرف‌شده)، **بیلی‌روبین غیرمستقیم بالا**، "
    "**هیپرتانسیون**، و در موارد شدید **درگیری عصبی** (تشنج و اختلال هوشیاری).",
    "This is the shortest question in the cluster and it tests EXACTLY THE POINT WE SET ASIDE in the "
    "earlier ones.\n\n"
    "WARNING, THE DIAGNOSTIC TRIAD OF HUS, AND ONLY THESE THREE:\n\n"
    "ONE — MICROANGIOPATHIC HAEMOLYTIC ANAEMIA. With SCHISTOCYTES on the blood film and a NEGATIVE "
    "COOMBS. The negative Coombs is vital: the haemolysis is MECHANICAL, not immune — the red cell is "
    "PHYSICALLY SHREDDED passing through fibrin-filled vessels.\n\n"
    "TWO — THROMBOCYTOPENIA. From CONSUMPTION of platelets in the microvascular thromboses.\n\n"
    "THREE — ACUTE RENAL FAILURE. Because the glomerulus has the highest density of Gb3 receptors and "
    "takes the greatest damage from Shiga toxin.\n\n"
    "AND LEUCOCYTOSIS?\n\n"
    "IT IS COMMON IN HUS — especially the post-Shigella form. And it also MARKS A WORSE PROGNOSIS: the "
    "higher the white count, the greater the risk of severe complications.\n\n"
    "WARNING, BUT IT IS NOT PART OF THE DIAGNOSTIC TRIAD. That is, HUS can be diagnosed WITHOUT "
    "leucocytosis; and its presence alone does not make the diagnosis.\n\n"
    "THE METHODOLOGICAL LESSON HERE IS WORTH MORE THAN THE QUESTION: learn the difference between A "
    "DEFINING COMPONENT and A COMMON ASSOCIATED FINDING. Many 'which is not a component' questions are "
    "built on exactly that boundary. A finding that is COMMON is not necessarily PART OF THE DEFINITION.\n\n"
    "AND TO COMPLETE THE PICTURE, WHAT ELSE IS COMMON IN HUS WITHOUT BEING PART OF THE TRIAD? A RAISED "
    "LDH (from haemolysis), A LOW HAPTOGLOBIN (consumed), A RAISED UNCONJUGATED BILIRUBIN, HYPERTENSION, "
    "and in severe cases NEUROLOGICAL INVOLVEMENT (seizures and impaired consciousness).",
    ["پاسخ صحیح — لکوسیتوز در HUS شایع و نشانه‌ی شدت است، ولی جزء سه‌گانه‌ی تشخیصی نیست.",
     "جزء دوم سه‌گانه است، از مصرف پلاکت در ترومبوزهای میکروواسکولار.",
     "جزء اول سه‌گانه است، با شیستوسیت و کومبس منفی.",
     "جزء سوم سه‌گانه است، چون گلومرول بیشترین آسیب را از سم شیگا می‌بیند."],
    ["Correct — leucocytosis is common in HUS and marks severity, but it is not part of the diagnostic triad.",
     "The second component of the triad, from platelet consumption in microvascular thromboses.",
     "The first component of the triad, with schistocytes and a negative Coombs test.",
     "The third component of the triad, because the glomerulus takes the greatest Shiga toxin damage."],
    "**«یافته‌ی شایع» با «جزء تعریف» یکی نیست — و امتحان روی همین مرز سؤال می‌سازد.**",
    "A common finding is not a defining component — and the exam builds questions on that boundary.",
    REFS)

add("book:326", "vignette", "hard",
    "**تب + ترومبوسیتوپنی + نارسایی کلیه + اختلال عصبی پس از دیسانتری = طیف HUS/TTP از شیگلا.**",
    "Fever plus thrombocytopenia plus renal failure plus neurological disturbance after dysentery = the HUS/TTP spectrum from Shigella.",
    HUS_FA + [
        "**این بیمار دو جزء اضافه بر سه‌گانه دارد: تب و اختلال عصبی.**",
        "**و همین دو، پنج‌گانه‌ی کلاسیک TTP را کامل می‌کنند.**",
        "**پنج‌گانه: آنمی همولیتیک، ترومبوسیتوپنی، نارسایی کلیه، تب، و علائم عصبی.**",
        "⚠️ **HUS و TTP دو سر یک طیف‌اند، نه دو بیماری کاملاً جدا.**",
        "**در HUS کلیه غالب است؛ در TTP علائم عصبی غالب‌اند.**",
        "**و شیگلا دیسانتریه می‌تواند هر دو سر طیف را بسازد.**",
        "**دیس‌ارینتاسیون و دلیریوم از میکروترومبوزهای مغزی می‌آیند.**",
        "**فاصله‌ی ده روز از دیسانتری کاملاً با این عارضه هم‌خوان است.**",
    ],
    HUS_EN + [
        "This patient has two features beyond the triad: fever and neurological disturbance.",
        "And those two complete the classic PENTAD of TTP.",
        "The pentad: haemolytic anaemia, thrombocytopenia, renal failure, fever, and neurological signs.",
        "WARNING, HUS AND TTP ARE TWO ENDS OF ONE SPECTRUM, not two entirely separate diseases.",
        "In HUS the kidney dominates; in TTP the neurological features dominate.",
        "And Shigella dysenteriae can produce either end of that spectrum.",
        "Disorientation and delirium arise from cerebral microthrombi.",
        "The ten-day interval from the dysentery fits this complication exactly.",
    ],
    "این سخت‌ترین سؤال خوشه است، چون تابلو **فراتر از سه‌گانه** می‌رود.\n\n"
    "**بیمار: مرد جوان با تب، ترومبوسیتوپنی، دیس‌ارینتاسیون و دلیریوم، و شواهد آزمایشگاهی "
    "نارسایی کلیه. در سابقه: دیسانتری و تب ده روز پیش، با گلبول سفید و قرمز فراوان در مدفوع.**\n\n"
    "**اجزا را بشماریم:**\n\n"
    "**ترومبوسیتوپنی** ✔ · **نارسایی کلیه** ✔ · **تب** ✔ · **اختلال عصبی (دیس‌ارینتاسیون و "
    "دلیریوم)** ✔\n\n"
    "⚠️ **این پنج‌گانه‌ی کلاسیک TTP است** (جزء پنجم، آنمی همولیتیک، در بیمار ضمنی است).\n\n"
    "**حالا نکته‌ی مفهومی مهم: HUS و TTP دو سر یک طیف‌اند، نه دو بیماری کاملاً جدا.**\n\n"
    "**در HUS:** درگیری **کلیه غالب** است و علائم عصبی کم یا خفیف.\n\n"
    "**در TTP:** **علائم عصبی غالب**اند و درگیری کلیه ممکن است خفیف‌تر باشد.\n\n"
    "**هر دو از یک مکانیسم می‌آیند: میکروترومبوز منتشر در عروق کوچک.** فقط **توزیع** آسیب "
    "فرق می‌کند. در HUS پس از اسهال، سم شیگا اندوتلیوم را می‌کشد؛ و اگر میکروترومبوزها به "
    "**مغز** هم برسند، **دیس‌ارینتاسیون و دلیریوم و حتی تشنج** رخ می‌دهد.\n\n"
    "**پس عامل؟ شیگلا دیسانتریه.** سم شیگا می‌سازد، و **سابقه‌ی دیسانتری با گلبول سفید و "
    "قرمز فراوان در مدفوع** آن را تأیید می‌کند. فاصله‌ی **ده روز** هم دقیقاً در بازه‌ی معمول "
    "این عارضه است.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**سالمونلا تیفی‌موریوم:** گاستروآنتریت التهابی و گاهی باکتریمی می‌دهد، ولی **سم شیگا "
    "نمی‌سازد** و این تابلو را نمی‌سازد.\n\n"
    "⚠️ **ای‌کلای انتروپاتوژنیک (EPEC):** این دام سؤال است. **EPEC با EHEC فرق دارد** — "
    "EPEC عامل **اسهال آبکی نوزادان و شیرخواران** است، با سازوکار **چسبیدن و محو کردن "
    "میکروویلی‌ها**، و **سم شیگا نمی‌سازد**. **فقط EHEC سم شیگا دارد.** (سه حرف وسط: "
    "**T**oxigenic آبکی · **H**aemorrhagic خونی و HUS · **P**athogenic آبکی نوزادان.)\n\n"
    "**کمپیلوباکتر ژژونی:** اسهال خونی می‌دهد، ولی سم شیگا ندارد؛ عارضه‌ی دیررس آن "
    "**گیلن-باره** است — که آن هم عصبی است، ولی تابلوی کاملاً متفاوتی دارد: **فلج شل صعودی "
    "و قرینه**، نه دلیریوم و نارسایی کلیه.",
    "This is the hardest question in the cluster, because the picture goes BEYOND THE TRIAD.\n\n"
    "THE PATIENT: a young man with fever, thrombocytopenia, disorientation and delirium, and laboratory "
    "evidence of renal failure. History: dysentery and fever ten days ago, with many white and red "
    "cells in the stool.\n\n"
    "LET US COUNT THE FEATURES:\n\n"
    "THROMBOCYTOPENIA, RENAL FAILURE, FEVER, NEUROLOGICAL DISTURBANCE (disorientation and delirium).\n\n"
    "WARNING, THIS IS THE CLASSIC PENTAD OF TTP (the fifth component, haemolytic anaemia, being implicit).\n\n"
    "NOW THE IMPORTANT CONCEPTUAL POINT: HUS AND TTP ARE TWO ENDS OF ONE SPECTRUM, not two entirely "
    "separate diseases.\n\n"
    "IN HUS: RENAL involvement dominates and neurological features are few or mild.\n\n"
    "IN TTP: NEUROLOGICAL features dominate and renal involvement may be milder.\n\n"
    "BOTH ARISE FROM ONE MECHANISM: DISSEMINATED MICROTHROMBOSIS IN SMALL VESSELS. Only the "
    "DISTRIBUTION of the damage differs. In post-diarrhoeal HUS the Shiga toxin kills endothelium; and "
    "if the microthrombi also reach THE BRAIN, DISORIENTATION, DELIRIUM AND EVEN SEIZURES follow.\n\n"
    "SO THE ORGANISM? SHIGELLA DYSENTERIAE. It makes Shiga toxin, and THE HISTORY OF DYSENTERY WITH "
    "MANY WHITE AND RED CELLS IN THE STOOL confirms it. The TEN-DAY interval also sits squarely in the "
    "usual window for this complication.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "SALMONELLA TYPHIMURIUM: causes inflammatory gastroenteritis and sometimes bacteraemia, but MAKES "
    "NO SHIGA TOXIN and does not produce this picture.\n\n"
    "WARNING, ENTEROPATHOGENIC E. COLI (EPEC): this is the trap. EPEC IS NOT EHEC — EPEC causes WATERY "
    "DIARRHOEA IN NEONATES AND INFANTS, by ATTACHING AND EFFACING THE MICROVILLI, and it MAKES NO SHIGA "
    "TOXIN. ONLY EHEC HAS SHIGA TOXIN. (Three middle letters: Toxigenic is watery; Haemorrhagic is "
    "bloody and causes HUS; Pathogenic is watery infantile diarrhoea.)\n\n"
    "CAMPYLOBACTER JEJUNI: causes bloody diarrhoea but has no Shiga toxin; its late complication is "
    "GUILLAIN-BARRE — which is also neurological, but with a completely different picture: A SYMMETRICAL "
    "ASCENDING FLACCID PARALYSIS, not delirium and renal failure.",
    ["گاستروآنتریت التهابی می‌دهد ولی سم شیگا نمی‌سازد و این تابلو را نمی‌سازد.",
     "دام سؤال — EPEC اسهال آبکی نوزادان می‌دهد و سم شیگا ندارد؛ فقط EHEC آن را دارد.",
     "پاسخ صحیح — سم شیگا می‌سازد و سابقه‌ی دیسانتری با مدفوع التهابی آن را تأیید می‌کند.",
     "اسهال خونی می‌دهد ولی سم شیگا ندارد؛ عارضه‌ی عصبی آن گیلن-باره است، نه دلیریوم."],
    ["Causes inflammatory gastroenteritis but makes no Shiga toxin and cannot produce this picture.",
     "The trap — EPEC causes watery infantile diarrhoea and has no Shiga toxin; only EHEC has it.",
     "Correct — it makes Shiga toxin, and the dysentery with inflammatory stool confirms it.",
     "Causes bloody diarrhoea but has no Shiga toxin; its neurological sequel is Guillain-Barre, not delirium."],
    "**ETEC آبکی · EHEC خونی و HUS · EPEC آبکی نوزادان — حرف وسط را بخوانید.**",
    "ETEC watery, EHEC bloody with HUS, EPEC watery infantile — read the middle letter.",
    REFS)

json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book46.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 46 lessons:', len(L))
