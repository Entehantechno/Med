# -*- coding: utf-8 -*-
"""Micro-lessons, batch 25 — streptococcal pharyngitis and invasive
staphylococcal disease.

The second half of the skin and soft tissue chapter. Two blocks, and each is
built on one idea that the examiners test from many angles.

BLOCK ONE — GROUP A STREPTOCOCCAL PHARYNGITIS (twelve questions)
The whole block rests on a single asymmetry that students consistently get
wrong:

    TREATING THE PHARYNGITIS PREVENTS RHEUMATIC FEVER.
    IT DOES NOT PREVENT POST-STREPTOCOCCAL GLOMERULONEPHRITIS.

Everything else follows. Why we bother treating a self-limiting sore throat at
all (rheumatic fever), why the ten-day course matters, why penicillin is still
the drug after eighty years, and what to do about the penicillin-allergic
child — where the answer depends entirely on WHETHER THE REACTION WAS
ANAPHYLACTIC.

BLOCK TWO — INVASIVE STAPHYLOCOCCUS AUREUS (nine questions)
One organism, many rooms of the hospital. The unifying idea is that
Staphylococcus aureus is the default answer whenever the infection involves
A DEVICE, A SURGICAL WOUND, A BONE, or A LUNG AFTER INFLUENZA — and that
haematogenous seeding explains most of it.

Reference: Shulman ST et al., "Clinical Practice Guideline for the Diagnosis
and Management of Group A Streptococcal Pharyngitis: 2012 Update by the
Infectious Diseases Society of America", Clin Infect Dis 2012;55:e86-e102;
Harrison's Principles of Internal Medicine, 21st ed (2022), Ch. 142
(Staphylococcal Infections) and Ch. 143 (Streptococcal Infections).
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


IDSAP = ("Shulman ST et al. — Clinical Practice Guideline for the Diagnosis and Management of "
         "Group A Streptococcal Pharyngitis: 2012 Update by the Infectious Diseases Society of "
         "America. Clin Infect Dis 2012;55(10):e86-e102")
H142 = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 142: Staphylococcal Infections"
H143 = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 143: Streptococcal Infections"
AHA = "American Heart Association — Prevention of Rheumatic Fever and Diagnosis and Treatment of Acute Streptococcal Pharyngitis"

PHAR_FA = [
    "⚠️ **فارنژیت استرپتوکوکی را از ویروسی جدا کنید — و سرفه مهم‌ترین علامت است.**",
    "**معیارهای سنتور (Centor)، هرکدام یک امتیاز:**",
    "**تب** · **اگزودای لوزه** · **آدنوپاتی قدامی گردن دردناک** · ⚠️ **نبودِ سرفه**",
    "(و در نسخه‌ی اصلاح‌شده، **سن ۳ تا ۱۴ سال** یک امتیاز مثبت و **بالای ۴۵ سال** یک امتیاز منفی.)",
    "⚠️ **نکته‌ی ضدشهودی که بارها پرسیده می‌شود: وجود سرفه احتمال استرپ را کم می‌کند.**",
    "**همین‌طور آبریزش بینی، عطسه، گرفتگی بینی، کونژنکتیویت و زخم دهانی — همه به نفع ویروس‌اند.**",
    "**سن هم سرنخ است: اوج فارنژیت استرپتوکوکی ۵ تا ۱۵ سال است.**",
    "**زیر ۳ سال نادر است**، و در آن سن تب روماتیسمی هم عملاً رخ نمی‌دهد.",
    "⚠️ **حالا مهم‌ترین قاعده‌ی این بلوک، و منبع بیشترین خطای دانشجویی:**",
    "**درمان با پنی‌سیلین از تب روماتیسمی پیشگیری می‌کند، ولی از گلومرولونفریت نه.**",
    "**چرا این تفاوت؟** چون **مکانیسم دو عارضه فرق دارد.**",
    "**تب روماتیسمی** ← پاسخ ایمنی متقاطع علیه **پروتئین M** که چند هفته طول می‌کشد تا شکل بگیرد؛",
    "پس با ریشه‌کنی باکتری **تا روز نهم**، هنوز می‌توان جلوی آن را گرفت.",
    "⚠️ **گلومرولونفریت** ← ناشی از **سویه‌های نفریتوژنیک خاص** و رسوب کمپلکس ایمنی است،",
    "**و این روند از همان ابتدا آغاز شده** — آنتی‌بیوتیک دیگر نمی‌تواند متوقفش کند.",
    "**پس تنها فایده‌ی آنتی‌بیوتیک در گلومرولونفریت، پیشگیری از انتشار به دیگران است.**",
    "**درمان: پنی‌سیلین یا آموکسی‌سیلین، ۱۰ روز کامل.**",
    "⚠️ **استرپتوکوک گروه A هنوز صددرصد به پنی‌سیلین حساس است — هیچ مقاومتی گزارش نشده.**",
    "**چرا ۱۰ روز و نه کمتر؟** چون دوره‌ی کوتاه‌تر **ریشه‌کنی کامل** نمی‌دهد و خطر عود می‌ماند.",
    "**بنزاتین پنی‌سیلین تک‌دوز عضلانی** جایگزین خوبی است وقتی پایبندی به درمان مشکوک باشد.",
]
PHAR_EN = [
    "WARNING: SEPARATE STREPTOCOCCAL FROM VIRAL PHARYNGITIS — AND COUGH IS THE MOST IMPORTANT SIGN.",
    "THE CENTOR CRITERIA, one point each:",
    "FEVER · TONSILLAR EXUDATE · TENDER ANTERIOR CERVICAL ADENOPATHY · WARNING, ABSENCE OF COUGH",
    "(and in the modified version, AGE 3 TO 14 adds a point and AGE OVER 45 subtracts one).",
    "WARNING, THE COUNTER-INTUITIVE POINT ASKED REPEATEDLY: THE PRESENCE OF A COUGH ARGUES AGAINST STREP.",
    "So do rhinorrhoea, sneezing, nasal congestion, conjunctivitis and oral ulcers — all favour a virus.",
    "AGE IS A CLUE TOO: streptococcal pharyngitis peaks between 5 AND 15 YEARS.",
    "IT IS RARE UNDER 3, and at that age rheumatic fever essentially does not occur either.",
    "WARNING, NOW THE MOST IMPORTANT RULE OF THIS BLOCK, and the source of most student error:",
    "TREATMENT WITH PENICILLIN PREVENTS RHEUMATIC FEVER, BUT IT DOES NOT PREVENT GLOMERULONEPHRITIS.",
    "WHY THE DIFFERENCE? Because THE MECHANISMS OF THE TWO COMPLICATIONS DIFFER.",
    "RHEUMATIC FEVER — a cross-reactive immune response against the M PROTEIN, which takes weeks to develop;",
    "so eradicating the organism UP TO DAY NINE can still prevent it.",
    "WARNING, GLOMERULONEPHRITIS — caused by SPECIFIC NEPHRITOGENIC STRAINS and immune complex deposition,",
    "AND THAT PROCESS HAS BEGUN FROM THE OUTSET — an antibiotic can no longer stop it.",
    "SO THE ONLY BENEFIT OF ANTIBIOTICS REGARDING GLOMERULONEPHRITIS IS PREVENTING SPREAD TO OTHERS.",
    "TREATMENT: PENICILLIN OR AMOXICILLIN FOR A FULL TEN DAYS.",
    "WARNING: GROUP A STREPTOCOCCUS REMAINS 100% PENICILLIN SUSCEPTIBLE — no resistance has ever been reported.",
    "WHY TEN DAYS AND NOT FEWER? Because a shorter course FAILS TO ERADICATE and leaves a relapse risk.",
    "A SINGLE INTRAMUSCULAR DOSE OF BENZATHINE PENICILLIN is a good alternative when adherence is doubtful.",
]

ALLERGY_FA = [
    "⚠️ **در آلرژی به پنی‌سیلین، همه‌چیز به یک سؤال بستگی دارد: واکنش آنافیلاکتیک بود یا نه؟**",
    "**این تفکیک، دو سؤال متفاوت این فصل را از هم جدا می‌کند و باید کاملاً روشن باشد.**",
    "**حساسیت غیرفوری (غیرآنافیلاکتیک)** — مثل راش ماکولوپاپولر تأخیری:",
    "⚠️ **سفالوسپورین نسل اول (سفالکسین) مجاز و انتخاب مناسبی است.**",
    "**چرا؟** چون **واکنش متقاطع بین پنی‌سیلین و سفالوسپورین‌های نسل اول حدود ۱ تا ۲ درصد** است،",
    "و در واکنش تأخیری این خطر قابل قبول تلقی می‌شود.",
    "⚠️ **حساسیت فوری (آنافیلاکسی، آنژیوادم، کهیر حاد)** — اینجا قاعده عوض می‌شود:",
    "**هیچ بتالاکتامی نباید داده شود** — نه پنی‌سیلین، نه سفالوسپورین، نه هیچ نسلی.",
    "**در این حالت انتخاب‌ها: ماکرولید (آزیترومایسین، کلاریترومایسین) یا کلیندامایسین.**",
    "**دوره‌ی درمان: آزیترومایسین ۵ روز، کلیندامایسین ۱۰ روز.**",
    "⚠️ **و داروهایی که هرگز برای فارنژیت استرپتوکوکی به کار نمی‌روند — این را حفظ کنید:**",
    "**تتراسایکلین‌ها (داکسی‌سیکلین)** ← نرخ شکست بالا و مقاومت شایع.",
    "**سولفونامیدها (کوتریموکسازول)** ← **ریشه‌کن نمی‌کنند** و از تب روماتیسمی پیشگیری نمی‌کنند.",
    "**فلوروکینولون‌ها** ← بیش از حد وسیع، گران، و با عوارض غیرضروری در کودک.",
    "**سفالوسپورین‌های نسل سوم خوراکی (سفیکسیم)** ← مؤثرند ولی **انتخاب اول نیستند**؛",
    "طیف بی‌جهت وسیعشان به مقاومت دامن می‌زند و مزیتی بر پنی‌سیلین ندارند.",
]
ALLERGY_EN = [
    "WARNING: IN PENICILLIN ALLERGY EVERYTHING DEPENDS ON ONE QUESTION — WAS THE REACTION ANAPHYLACTIC?",
    "This distinction separates two different questions in this chapter and must be perfectly clear.",
    "A NON-IMMEDIATE (NON-ANAPHYLACTIC) REACTION — such as a delayed maculopapular rash:",
    "WARNING, A FIRST-GENERATION CEPHALOSPORIN (CEPHALEXIN) IS PERMITTED AND A GOOD CHOICE.",
    "WHY? Because CROSS-REACTIVITY BETWEEN PENICILLIN AND FIRST-GENERATION CEPHALOSPORINS IS ABOUT 1 TO 2 PER CENT,",
    "and with a delayed reaction that risk is considered acceptable.",
    "WARNING, AN IMMEDIATE REACTION (anaphylaxis, angio-oedema, acute urticaria) — here the rule changes:",
    "NO BETA-LACTAM MAY BE GIVEN — not penicillin, not a cephalosporin, of any generation.",
    "IN THAT CASE THE CHOICES ARE: A MACROLIDE (azithromycin, clarithromycin) OR CLINDAMYCIN.",
    "DURATION: azithromycin 5 days, clindamycin 10 days.",
    "WARNING, AND THE DRUGS NEVER USED FOR STREPTOCOCCAL PHARYNGITIS — memorise these:",
    "TETRACYCLINES (doxycycline) — high failure rates and common resistance.",
    "SULPHONAMIDES (co-trimoxazole) — THEY DO NOT ERADICATE and do not prevent rheumatic fever.",
    "FLUOROQUINOLONES — needlessly broad, expensive, with unnecessary harms in children.",
    "ORAL THIRD-GENERATION CEPHALOSPORINS (cefixime) — effective but NOT FIRST CHOICE;",
    "their needlessly broad spectrum drives resistance and they offer no advantage over penicillin.",
]

STAPH_FA = [
    "⚠️ **استافیلوکوک اورئوس پاسخ پیش‌فرض است هرگاه عفونت با یکی از این چهار مرتبط باشد:**",
    "**وسیله‌ی داخل بدن**، **زخم جراحی**، **استخوان**، یا **ریه پس از آنفلوانزا**.",
    "**منطق مشترکشان: استاف به سطوح می‌چسبد و از راه خون کاشته می‌شود.**",
    "**چسبندگی به سطح:** پروتئین‌های MSCRAMM به فیبرونکتین و فیبرینوژن روی وسیله می‌چسبند،",
    "سپس **بیوفیلم** می‌سازند که هم آنتی‌بیوتیک و هم نوتروفیل را دور نگه می‌دارد.",
    "⚠️ **به همین دلیل عفونت وسیله معمولاً بدون برداشتن وسیله درمان نمی‌شود.**",
    "**شایع‌ترین علت عفونت زخم جراحی: استافیلوکوک اورئوس** (از فلور پوست خود بیمار).",
    "**پروفیلاکسی جراحی: سفازولین** — چون دقیقاً همین ارگانیسم را هدف می‌گیرد.",
    "⚠️ **چرا سفازولین و نه سفتریاکسون؟** چون هدف **گرم‌مثبت پوست** است، نه گرم‌منفی روده؛",
    "و سفازولین **نیمه‌عمر مناسب، نفوذ بافتی خوب و طیف باریک‌تر** دارد.",
    "**وانکومایسین فقط در آلرژی شدید به بتالاکتام یا کلونیزاسیون شناخته‌شده‌ی MRSA.**",
    "**استئومیلیت و اسپوندیلودیسکیت:** شایع‌ترین علت در همه‌ی گروه‌های سنی **استاف اورئوس** است.",
    "**عوامل خطر: معتاد تزریقی، همودیالیز، دیابت، وسیله‌ی داخل عروقی.**",
    "⚠️ **بهترین روش تصویربرداری برای اسپوندیلودیسکیت: MRI.**",
    "چرا؟ چون **حساسیت بالای ۹۰ درصد در روزهای اول** دارد و **آبسه‌ی اپیدورال** را نشان می‌دهد.",
    "**گرافی ساده تا ۲ تا ۴ هفته طبیعی می‌ماند** — یعنی در فاز حاد بی‌فایده است.",
    "**اسکن استخوان حساس ولی غیراختصاصی است** و آبسه‌ی اپیدورال را نشان نمی‌دهد.",
    "⚠️ **درمان MRSA:** عفونت خفیف پوستی ← **کوتریموکسازول، داکسی‌سیکلین یا کلیندامایسین خوراکی**.",
    "عفونت شدید یا باکتریمی ← **وانکومایسین یا دپتومایسین وریدی**.",
]
STAPH_EN = [
    "WARNING: STAPHYLOCOCCUS AUREUS IS THE DEFAULT ANSWER WHENEVER THE INFECTION INVOLVES ONE OF FOUR THINGS:",
    "AN INDWELLING DEVICE, A SURGICAL WOUND, BONE, or THE LUNG AFTER INFLUENZA.",
    "THEIR COMMON LOGIC: STAPH STICKS TO SURFACES AND IS SEEDED THROUGH THE BLOOD.",
    "SURFACE ADHESION: MSCRAMM proteins bind fibronectin and fibrinogen coating the device,",
    "then form a BIOFILM that keeps out both antibiotics and neutrophils.",
    "WARNING, THAT IS WHY DEVICE INFECTION USUALLY CANNOT BE CURED WITHOUT REMOVING THE DEVICE.",
    "THE COMMONEST CAUSE OF SURGICAL WOUND INFECTION IS STAPHYLOCOCCUS AUREUS (from the patient's own skin flora).",
    "SURGICAL PROPHYLAXIS IS CEFAZOLIN — because it targets precisely that organism.",
    "WARNING, WHY CEFAZOLIN AND NOT CEFTRIAXONE? Because the target is SKIN GRAM-POSITIVES, not gut gram-negatives;",
    "and cefazolin has A SUITABLE HALF-LIFE, GOOD TISSUE PENETRATION AND A NARROWER SPECTRUM.",
    "VANCOMYCIN ONLY for severe beta-lactam allergy or known MRSA colonisation.",
    "OSTEOMYELITIS AND SPONDYLODISCITIS: the commonest cause in every age group is STAPH AUREUS.",
    "RISK FACTORS: injecting drug use, haemodialysis, diabetes, an intravascular device.",
    "WARNING, THE BEST IMAGING FOR SPONDYLODISCITIS IS MRI.",
    "Why? Because its SENSITIVITY EXCEEDS 90% IN THE FIRST DAYS and it shows an EPIDURAL ABSCESS.",
    "A PLAIN FILM STAYS NORMAL FOR 2 TO 4 WEEKS — useless in the acute phase.",
    "A BONE SCAN IS SENSITIVE BUT NON-SPECIFIC and does not show an epidural abscess.",
    "WARNING, MRSA TREATMENT: mild skin infection — ORAL CO-TRIMOXAZOLE, DOXYCYCLINE OR CLINDAMYCIN.",
    "Severe infection or bacteraemia — INTRAVENOUS VANCOMYCIN OR DAPTOMYCIN.",
]


# =========================================================== book:45
add("book:45", "recall", "medium",
 "پنی‌سیلین از **تب روماتیسمی** پیشگیری می‌کند، ولی از **گلومرولونفریت** نه.",
 "Penicillin prevents RHEUMATIC FEVER but NOT GLOMERULONEPHRITIS.",
 PHAR_FA + [
  "این سؤال مهم‌ترین نکته‌ی کل بلوک فارنژیت را می‌پرسد، و پاسخش ضدشهودی است.",
  "**سه عارضه‌ی دیگر با درمان پیشگیری می‌شوند و منطقشان روشن است:**",
  "**تب روماتیسمی** ← درمان تا **روز نهم** بیماری هنوز مؤثر است و آن را متوقف می‌کند.",
  "**آبسه‌ی پری‌تونسیلر** ← یک عارضه‌ی **چرکی موضعی** است؛ کشتن باکتری مانعش می‌شود.",
  "**اوتیت میانی** ← همین‌طور، گسترش مستقیم باکتری است.",
  "⚠️ **می‌ماند گلومرولونفریت — و آنتی‌بیوتیک از آن پیشگیری نمی‌کند.**",
  "**چرا؟ تفاوت در مکانیسم و در زمان‌بندی است.**",
  "**در تب روماتیسمی:** بدن آنتی‌بادی علیه **پروتئین M** استرپتوکوک می‌سازد،",
  "که با **میوزین قلب، سارکولم و بافت مفصل** واکنش متقاطع می‌دهد (تقلید مولکولی).",
  "این پاسخ **چند هفته** طول می‌کشد تا شکل بگیرد، پس **پنجره‌ای برای مداخله باقی است**.",
  "⚠️ **در گلومرولونفریت:** بیماری از **سویه‌های نفریتوژنیک خاص** (مثل M12 و M49) می‌آید،",
  "و **کمپلکس‌های ایمنی از همان روزهای اول** در گلومرول رسوب می‌کنند.",
  "**تا وقتی بیمار به پزشک برسد، این روند شروع شده و آنتی‌بیوتیک نمی‌تواند برش گرداند.**",
  "**پس تنها فایده‌ی درمان در این مورد، جلوگیری از انتقال سویه‌ی نفریتوژنیک به دیگران است.**",
  "⚠️ **و یک نکته‌ی تکمیلی مهم: گلومرولونفریت هم پس از فارنژیت و هم پس از زرد زخم رخ می‌دهد،**",
  "**ولی تب روماتیسمی فقط پس از فارنژیت** — هرگز پس از عفونت پوستی.",
 ],
 PHAR_EN + [
  "This question asks the single most important point of the whole pharyngitis block, and the answer is counter-intuitive.",
  "THE OTHER THREE COMPLICATIONS ARE PREVENTED BY TREATMENT, and their logic is clear:",
  "RHEUMATIC FEVER — treatment UP TO DAY NINE of the illness is still effective and stops it.",
  "PERITONSILLAR ABSCESS — a LOCAL SUPPURATIVE complication; killing the organism prevents it.",
  "OTITIS MEDIA — likewise, direct bacterial spread.",
  "WARNING, THAT LEAVES GLOMERULONEPHRITIS — AND ANTIBIOTICS DO NOT PREVENT IT.",
  "WHY? The difference lies in mechanism and in timing.",
  "IN RHEUMATIC FEVER the body makes antibody against the streptococcal M PROTEIN,",
  "which CROSS-REACTS WITH CARDIAC MYOSIN, SARCOLEMMA AND JOINT TISSUE (molecular mimicry).",
  "That response takes WEEKS to develop, so A WINDOW FOR INTERVENTION REMAINS.",
  "WARNING, IN GLOMERULONEPHRITIS the disease comes from SPECIFIC NEPHRITOGENIC STRAINS (such as M12 and M49),",
  "and IMMUNE COMPLEXES DEPOSIT IN THE GLOMERULUS FROM THE EARLIEST DAYS.",
  "By the time the patient reaches a doctor that process has begun and no antibiotic can reverse it.",
  "SO THE ONLY BENEFIT OF TREATMENT HERE IS PREVENTING TRANSMISSION OF THE NEPHRITOGENIC STRAIN TO OTHERS.",
  "WARNING, AND AN IMPORTANT ADDITION: GLOMERULONEPHRITIS FOLLOWS BOTH PHARYNGITIS AND IMPETIGO,",
  "BUT RHEUMATIC FEVER FOLLOWS ONLY PHARYNGITIS — never a skin infection.",
 ],
 "این سؤال مهم‌ترین نکته‌ی کل بلوک فارنژیت را می‌پرسد، و پاسخش **ضدشهودی** است — به همین دلیل هم منبع بیشترین خطای دانشجویی است.\n\n"
 "**سه عارضه‌ی دیگر با درمان پیشگیری می‌شوند:**\n\n"
 "**تب روماتیسمی** ← درمان تا **روز نهم** بیماری هنوز مؤثر است\n"
 "**آبسه‌ی پری‌تونسیلر** ← عارضه‌ی چرکی موضعی؛ کشتن باکتری مانعش می‌شود\n"
 "**اوتیت میانی** ← گسترش مستقیم باکتری؛ همین‌طور\n\n"
 "⚠️ **می‌ماند گلومرولونفریت — و آنتی‌بیوتیک از آن پیشگیری نمی‌کند.**\n\n"
 "**چرا؟ تفاوت در مکانیسم و مهم‌تر از آن، در زمان‌بندی است:**\n\n"
 "**در تب روماتیسمی:** بدن آنتی‌بادی علیه **پروتئین M** استرپتوکوک می‌سازد که با **میوزین قلب، سارکولم و بافت مفصل** واکنش متقاطع می‌دهد — همان **تقلید مولکولی**. این پاسخ ایمنی **چند هفته** طول می‌کشد تا شکل بگیرد. پس اگر باکتری را زودتر ریشه‌کن کنیم، **پنجره‌ی مداخله هنوز باز است**.\n\n"
 "⚠️ **در گلومرولونفریت:** بیماری از **سویه‌های نفریتوژنیک خاص** (مانند M12 و M49) می‌آید، و **کمپلکس‌های ایمنی از همان روزهای اول** در گلومرول رسوب می‌کنند. تا وقتی بیمار به پزشک برسد، **این روند شروع شده** و آنتی‌بیوتیک نمی‌تواند آن را برگرداند.\n\n"
 "**پس تنها فایده‌ی درمان در این مورد، جلوگیری از انتقال سویه‌ی نفریتوژنیک به اطرافیان است، نه محافظت از خودِ بیمار.**\n\n"
 "⚠️ **و یک نکته‌ی تکمیلی که جداگانه هم پرسیده می‌شود:**\n\n"
 "**گلومرولونفریت هم پس از فارنژیت و هم پس از زرد زخم (عفونت پوستی) رخ می‌دهد.**\n"
 "**اما تب روماتیسمی فقط پس از فارنژیت رخ می‌دهد — هرگز پس از عفونت پوستی.**\n\n"
 "دلیلش هنوز کاملاً روشن نیست، ولی احتمالاً به تفاوت پاسخ ایمنی در مخاط حلق در برابر پوست برمی‌گردد.",
 "This question asks the single most important point of the entire pharyngitis block, and the answer is COUNTER-INTUITIVE — which is why it produces so much student error.\n\n"
 "THE OTHER THREE COMPLICATIONS ARE PREVENTED BY TREATMENT:\n\n"
 "RHEUMATIC FEVER — treatment up to DAY NINE of the illness is still effective\n"
 "PERITONSILLAR ABSCESS — a local suppurative complication; killing the organism prevents it\n"
 "OTITIS MEDIA — direct bacterial spread; likewise prevented\n\n"
 "WARNING, THAT LEAVES GLOMERULONEPHRITIS — AND ANTIBIOTICS DO NOT PREVENT IT.\n\n"
 "WHY? The difference lies in mechanism and, more importantly, in timing:\n\n"
 "IN RHEUMATIC FEVER the body makes antibody against the streptococcal M PROTEIN, which cross-reacts with CARDIAC MYOSIN, SARCOLEMMA AND JOINT TISSUE — MOLECULAR MIMICRY. That immune response takes WEEKS to develop. So if we eradicate the organism early enough, THE WINDOW FOR INTERVENTION IS STILL OPEN.\n\n"
 "WARNING, IN GLOMERULONEPHRITIS the disease arises from SPECIFIC NEPHRITOGENIC STRAINS (such as M12 and M49), and IMMUNE COMPLEXES DEPOSIT IN THE GLOMERULUS FROM THE EARLIEST DAYS. By the time the patient reaches a doctor THE PROCESS HAS ALREADY BEGUN, and no antibiotic can reverse it.\n\n"
 "SO THE ONLY BENEFIT OF TREATMENT HERE IS PREVENTING TRANSMISSION OF THE NEPHRITOGENIC STRAIN TO OTHERS, not protecting the patient.\n\n"
 "WARNING, AND A COMPLEMENTARY POINT THAT IS ALSO ASKED SEPARATELY:\n\n"
 "GLOMERULONEPHRITIS FOLLOWS BOTH PHARYNGITIS AND IMPETIGO (skin infection).\n"
 "BUT RHEUMATIC FEVER FOLLOWS ONLY PHARYNGITIS — never a skin infection.\n\n"
 "The reason is still not fully understood, but it probably reflects a difference between the immune response in pharyngeal mucosa and in skin.",
 ["پاسخ صحیح — کمپلکس‌های ایمنی از همان ابتدا رسوب کرده‌اند و آنتی‌بیوتیک نمی‌تواند روند را برگرداند.",
  "تب روماتیسمی دقیقاً همان عارضه‌ای است که درمان با پنی‌سیلین از آن پیشگیری می‌کند.",
  "آبسه‌ی پری‌تونسیلر یک عارضه‌ی چرکی موضعی است و با درمان آنتی‌بیوتیکی پیشگیری می‌شود.",
  "اوتیت میانی هم از گسترش مستقیم باکتری ناشی می‌شود و درمان از آن جلوگیری می‌کند."],
 ["Correct — immune complexes have deposited from the outset and antibiotics cannot reverse the process.",
  "Rheumatic fever is precisely the complication that penicillin treatment prevents.",
  "Peritonsillar abscess is a local suppurative complication and is prevented by antibiotic treatment.",
  "Otitis media also results from direct bacterial spread and is prevented by treatment."],
 "**پنی‌سیلین: تب روماتیسمی بله، گلومرولونفریت نه.** RF فقط پس از **حلق**؛ GN پس از **حلق یا پوست**.",
 "Penicillin prevents rheumatic fever, not glomerulonephritis. Rheumatic fever follows only pharyngitis; glomerulonephritis follows pharyngitis or skin infection.",
 [IDSAP, H143, AHA])


# =========================================================== book:39
add("book:39", "case", "medium",
 "**آنافیلاکسی** به پنی‌سیلین ← **هیچ بتالاکتامی** ← **آزیترومایسین**.",
 "ANAPHYLAXIS to penicillin means NO BETA-LACTAM AT ALL: give AZITHROMYCIN.",
 PHAR_FA + ALLERGY_FA + [
  "کودک **۱۰ ساله** با گلودرد استرپتوکوکی که **با پنی‌سیلین دچار آنافیلاکسی شده است**.",
  "⚠️ **کلمه‌ی «آنافیلاکسی» تمام تصمیم را تعیین می‌کند.**",
  "**آنافیلاکسی یک واکنش فوری با واسطه‌ی IgE (تیپ I) است**، و در آن:",
  "**هیچ بتالاکتامی نباید داده شود — نه پنی‌سیلین، نه سفالوسپورین، هیچ نسلی.**",
  "**چرا حتی سفالوسپورین نه؟** چون هرچند واکنش متقاطع با نسل اول فقط **۱ تا ۲ درصد** است،",
  "⚠️ **در بیماری که سابقه‌ی آنافیلاکسی دارد، حتی همان ۱ درصد هم غیرقابل قبول است** —",
  "چون پیامدش مرگ است، نه یک راش.",
  "**پس سفالکسین و سفیکسیم هر دو حذف می‌شوند.**",
  "**می‌ماند سیپروفلوکساسین و آزیترومایسین:**",
  "**سیپروفلوکساسین** ← فلوروکینولون؛ **در کودک به‌علت اثر بر غضروف در حال رشد پرهیز می‌شود**،",
  "و ضمناً برای فارنژیت استرپتوکوکی **بیش از حد وسیع و غیرضروری** است.",
  "⚠️ **پس پاسخ آزیترومایسین است** — یک ماکرولید، بدون هیچ ارتباط ساختاری با بتالاکتام‌ها.",
  "**دوره‌ی آزیترومایسین در فارنژیت: ۵ روز** (به‌خاطر نیمه‌عمر طولانی بافتی‌اش).",
  "**و یک نکته‌ی جهانی: مقاومت ماکرولیدی در استرپ گروه A در برخی مناطق بالاست**،",
  "پس در صورت شکست درمان باید به کلیندامایسین فکر کرد.",
  "⚠️ **مقایسه کنید با سؤال دیگر همین فصل:** آنجا حساسیت **غیرآنافیلاکتیک** بود و **سفالکسین** پاسخ.",
 ],
 PHAR_EN + ALLERGY_EN + [
  "A 10-YEAR-OLD with streptococcal sore throat who DEVELOPED ANAPHYLAXIS TO PENICILLIN.",
  "WARNING: THE WORD 'ANAPHYLAXIS' DETERMINES THE ENTIRE DECISION.",
  "ANAPHYLAXIS IS AN IMMEDIATE IgE-MEDIATED (TYPE I) REACTION, and in it:",
  "NO BETA-LACTAM MAY BE GIVEN — not penicillin, not a cephalosporin, of any generation.",
  "WHY NOT EVEN A CEPHALOSPORIN? Because although cross-reactivity with the first generation is only 1 TO 2 PER CENT,",
  "WARNING, IN A PATIENT WITH A HISTORY OF ANAPHYLAXIS EVEN 1 PER CENT IS UNACCEPTABLE —",
  "because the consequence is death, not a rash.",
  "SO CEPHALEXIN AND CEFIXIME ARE BOTH ELIMINATED.",
  "THAT LEAVES CIPROFLOXACIN AND AZITHROMYCIN:",
  "CIPROFLOXACIN — a fluoroquinolone, AVOIDED IN CHILDREN because of effects on growing cartilage,",
  "and in any case NEEDLESSLY BROAD for streptococcal pharyngitis.",
  "WARNING, SO THE ANSWER IS AZITHROMYCIN — a macrolide, structurally unrelated to beta-lactams.",
  "THE AZITHROMYCIN COURSE IN PHARYNGITIS IS 5 DAYS (because of its long tissue half-life).",
  "AND A GLOBAL POINT: MACROLIDE RESISTANCE IN GROUP A STREP IS HIGH IN SOME REGIONS,",
  "so clindamycin must be considered if treatment fails.",
  "WARNING, COMPARE WITH THE OTHER QUESTION IN THIS CHAPTER: there the allergy was NON-ANAPHYLACTIC and CEPHALEXIN was the answer.",
 ],
 "کودک **۱۰ ساله** با گلودرد استرپتوکوکی که **با دریافت پنی‌سیلین دچار آنافیلاکسی شده است**.\n\n"
 "⚠️ **کلمه‌ی «آنافیلاکسی» تمام تصمیم را تعیین می‌کند** — و همین کلمه، این سؤال را از سؤال دیگری در همین فصل جدا می‌کند که پاسخش سفالکسین بود.\n\n"
 "**آنافیلاکسی یک واکنش فوری با واسطه‌ی IgE (تیپ I) است.** و قاعده در آن قاطع است:\n\n"
 "**هیچ بتالاکتامی نباید داده شود — نه پنی‌سیلین، نه سفالوسپورین، هیچ نسلی.**\n\n"
 "**چرا حتی سفالوسپورین نه؟** واکنش متقاطع بین پنی‌سیلین و سفالوسپورین نسل اول حدود **۱ تا ۲ درصد** است. در حساسیت **تأخیری** این خطر قابل قبول است. ⚠️ **ولی در بیماری که سابقه‌ی آنافیلاکسی دارد، همان ۱ درصد هم غیرقابل قبول است** — چون پیامدش مرگ است، نه یک راش پوستی.\n\n"
 "**پس سفالکسین و سفیکسیم هر دو حذف می‌شوند.**\n\n"
 "**می‌ماند دو گزینه:**\n\n"
 "**سیپروفلوکساسین** ← فلوروکینولون است؛ **در کودک به‌علت اثر احتمالی بر غضروف در حال رشد پرهیز می‌شود**، و ضمناً برای فارنژیت استرپتوکوکی **بیش از حد وسیع و کاملاً غیرضروری** است.\n\n"
 "⚠️ **آزیترومایسین** ← یک **ماکرولید**، بدون هیچ ارتباط ساختاری با بتالاکتام‌ها، و بی‌خطر در این بیمار. **این پاسخ است.**\n\n"
 "**دوره‌ی درمان: آزیترومایسین ۵ روز** (به‌خاطر نیمه‌عمر طولانی بافتی‌اش، برخلاف ۱۰ روز استاندارد بقیه‌ی داروها).\n\n"
 "**و یک هشدار جهانی:** **مقاومت ماکرولیدی در استرپتوکوک گروه A در برخی مناطق بالاست** — پس اگر بیمار به آزیترومایسین پاسخ ندهد، باید به **کلیندامایسین** فکر کرد.",
 "A 10-YEAR-OLD with streptococcal sore throat WHO DEVELOPED ANAPHYLAXIS ON RECEIVING PENICILLIN.\n\n"
 "WARNING: THE WORD 'ANAPHYLAXIS' DETERMINES THE WHOLE DECISION — and it is what separates this question from another in this same chapter whose answer was cephalexin.\n\n"
 "ANAPHYLAXIS IS AN IMMEDIATE IgE-MEDIATED (TYPE I) REACTION. And the rule in it is absolute:\n\n"
 "NO BETA-LACTAM MAY BE GIVEN — not penicillin, not a cephalosporin, of any generation.\n\n"
 "WHY NOT EVEN A CEPHALOSPORIN? Cross-reactivity between penicillin and first-generation cephalosporins is about 1 TO 2 PER CENT. With a DELAYED allergy that risk is acceptable. WARNING, BUT IN A PATIENT WITH A HISTORY OF ANAPHYLAXIS EVEN 1 PER CENT IS UNACCEPTABLE — because the consequence is death, not a skin rash.\n\n"
 "SO CEPHALEXIN AND CEFIXIME ARE BOTH ELIMINATED.\n\n"
 "TWO OPTIONS REMAIN:\n\n"
 "CIPROFLOXACIN — a fluoroquinolone, AVOIDED IN CHILDREN because of possible effects on growing cartilage, and in any case NEEDLESSLY BROAD and entirely unnecessary for streptococcal pharyngitis.\n\n"
 "WARNING, AZITHROMYCIN — a MACROLIDE, structurally unrelated to beta-lactams and safe in this patient. THIS IS THE ANSWER.\n\n"
 "COURSE: AZITHROMYCIN FOR 5 DAYS (because of its long tissue half-life, unlike the standard 10 days for other agents).\n\n"
 "AND A GLOBAL CAUTION: MACROLIDE RESISTANCE IN GROUP A STREPTOCOCCUS IS HIGH IN SOME REGIONS — so if the patient fails azithromycin, CLINDAMYCIN must be considered.",
 ["سفالکسین یک بتالاکتام است و پس از آنافیلاکسی به پنی‌سیلین نباید تجویز شود.",
  "پاسخ صحیح — آزیترومایسین ماکرولید است و هیچ ارتباط ساختاری با بتالاکتام‌ها ندارد.",
  "سیپروفلوکساسین در کودک به‌علت اثر بر غضروف پرهیز می‌شود و برای فارنژیت بیش از حد وسیع است.",
  "سفیکسیم هم یک بتالاکتام است و در سابقه‌ی آنافیلاکسی به پنی‌سیلین ممنوع است."],
 ["Cephalexin is a beta-lactam and must not be given after anaphylaxis to penicillin.",
  "Correct — azithromycin is a macrolide, structurally unrelated to beta-lactams.",
  "Ciprofloxacin is avoided in children because of cartilage effects and is needlessly broad for pharyngitis.",
  "Cefixime is also a beta-lactam and is contraindicated after penicillin anaphylaxis."],
 "**آنافیلاکسی ← هیچ بتالاکتامی ← ماکرولید یا کلیندامایسین.** حساسیت **تأخیری** ← سفالکسین مجاز.",
 "Anaphylaxis means no beta-lactam at all: a macrolide or clindamycin. A delayed allergy permits cephalexin.",
 [IDSAP])


# =========================================================== book:47
add("book:47", "case", "easy",
 "راش سنباده‌ای + زبان توت‌فرنگی + پس از فارنژیت چرکی ← **مخملک (Scarlet fever)**.",
 "A SANDPAPER RASH with a STRAWBERRY TONGUE after purulent pharyngitis is SCARLET FEVER.",
 PHAR_FA + [
  "دختر **۶ ساله** پس از **گلودرد حاد چرکی** دچار راش شده است. جزئیات راش را بخوانید:",
  "**شروع از سینه و پشت، گسترش سریع به اندام‌ها، ولی کف دست و پا درگیر نمی‌شود.**",
  "⚠️ **در لمس زبر و شبیه کاغذ سنباده** — این توصیف تقریباً **اختصاصی مخملک** است.",
  "**در چین‌های بدن (زیربغل، آرنج، کشاله) پررنگ‌تر** ← این **خطوط پاستیا (Pastia's lines)** است.",
  "**و زبان شبیه توت‌فرنگی** ← ابتدا سفید با پاپیلاهای برجسته، سپس قرمز.",
  "**مخملک از توکسین است، نه از خود باکتری.**",
  "**عامل: اگزوتوکسین پیروژنیک استرپتوکوکی (توکسین اریتروژنیک)** از استرپ گروه A.",
  "⚠️ **پس مخملک همیشه همراه یا پس از یک عفونت استرپتوکوکی است** — معمولاً فارنژیت.",
  "**دو نشانه‌ی تکمیلی را بدانید:** **رنگ‌پریدگی دور دهانی (circumoral pallor)**،",
  "و **پوسته‌ریزی در هفته‌ی دوم**، به‌ویژه از نوک انگشتان.",
  "**چرا سرخک نه؟** سرخک با **کوریزا، سرفه، کونژنکتیویت** و **لکه‌های کوپلیک** می‌آید،",
  "راشش **ماکولوپاپولر و از خط مو به پایین** گسترش می‌یابد و **زبر نیست**.",
  "**چرا کاوازاکی نه؟** کاوازاکی **تب بیش از ۵ روز** می‌خواهد و **درگیری کف دست و پا** دارد",
  "(اریتم و ادم کف دست) — دقیقاً برعکس این بیمار که کف دست و پا سالم است.",
  "⚠️ **چرا تب روماتیسمی نه؟** راشش **اریتم مارژیناتوم** است: حلقوی، محو، گذرا و غیرزبر.",
  "**درمان مخملک: همان درمان فارنژیت استرپتوکوکی — پنی‌سیلین ۱۰ روز.**",
 ],
 PHAR_EN + [
  "A 6-YEAR-OLD GIRL develops a rash after ACUTE PURULENT PHARYNGITIS. Read the rash carefully:",
  "IT BEGINS ON CHEST AND BACK, spreads rapidly to the limbs, BUT SPARES PALMS AND SOLES.",
  "WARNING, IT FEELS ROUGH LIKE SANDPAPER — a description almost SPECIFIC to scarlet fever.",
  "IT IS DARKER IN THE SKIN FOLDS (axilla, antecubital fossa, groin) — these are PASTIA'S LINES.",
  "AND THE TONGUE LOOKS LIKE A STRAWBERRY — first white with prominent papillae, then red.",
  "SCARLET FEVER IS CAUSED BY A TOXIN, NOT BY THE ORGANISM ITSELF.",
  "THE AGENT: STREPTOCOCCAL PYROGENIC EXOTOXIN (erythrogenic toxin) from group A strep.",
  "WARNING, SO SCARLET FEVER ALWAYS ACCOMPANIES OR FOLLOWS A STREPTOCOCCAL INFECTION — usually pharyngitis.",
  "KNOW TWO MORE SIGNS: CIRCUMORAL PALLOR,",
  "and DESQUAMATION IN THE SECOND WEEK, especially from the fingertips.",
  "WHY NOT MEASLES? Measles comes with CORYZA, COUGH, CONJUNCTIVITIS and KOPLIK SPOTS;",
  "its rash is MACULOPAPULAR, spreads FROM THE HAIRLINE DOWNWARDS, and IS NOT ROUGH.",
  "WHY NOT KAWASAKI? Kawasaki requires FEVER FOR MORE THAN 5 DAYS and INVOLVES PALMS AND SOLES",
  "(erythema and oedema of the palms) — the exact opposite of this patient, whose palms are spared.",
  "WARNING, WHY NOT RHEUMATIC FEVER? Its rash is ERYTHEMA MARGINATUM: annular, faint, transient and not rough.",
  "TREATMENT OF SCARLET FEVER: the same as streptococcal pharyngitis — PENICILLIN FOR 10 DAYS.",
 ],
 "دختر **۶ ساله** پس از **گلودرد حاد چرکی** دچار راش شده است. جزئیات راش را با دقت بخوانید، چون هر کلمه‌اش تشخیصی است:\n\n"
 "**شروع از سینه و پشت، گسترش سریع به اندام‌ها، ولی کف دست و پا درگیر نمی‌شود**\n"
 "⚠️ **در لمس زبر و شبیه کاغذ سنباده** ← این توصیف تقریباً **اختصاصی مخملک** است\n"
 "**در چین‌های بدن (زیربغل، آرنج) پررنگ‌تر** ← **خطوط پاستیا (Pastia's lines)**\n"
 "**زبان شبیه توت‌فرنگی** ← ابتدا سفید با پاپیلاهای برجسته، سپس قرمز\n\n"
 "**پس تشخیص: مخملک (Scarlet fever).**\n\n"
 "⚠️ **و نکته‌ی مفهومی مهم: مخملک بیماری توکسین است، نه بیماری خودِ باکتری.** عاملش **اگزوتوکسین پیروژنیک استرپتوکوکی** (توکسین اریتروژنیک) از استرپتوکوک گروه A است. به همین دلیل، **مخملک همیشه همراه یا پس از یک عفونت استرپتوکوکی رخ می‌دهد** — که در نود درصد موارد فارنژیت است.\n\n"
 "**دو نشانه‌ی تکمیلی که باید بدانید:** **رنگ‌پریدگی دور دهانی** (circumoral pallor)، و **پوسته‌ریزی در هفته‌ی دوم** به‌ویژه از نوک انگشتان.\n\n"
 "**چرا گزینه‌های دیگر رد می‌شوند؟**\n\n"
 "**سرخک** ← با **کوریزا، سرفه، کونژنکتیویت** و **لکه‌های کوپلیک** می‌آید. راشش **ماکولوپاپولر** است، **از خط مو به پایین** گسترش می‌یابد، و **زبر نیست**.\n\n"
 "**بیماری کاوازاکی** ← **تب بیش از ۵ روز** لازم دارد، و مهم‌تر: **کف دست و پا را درگیر می‌کند** (اریتم و ادم کف دست). این دقیقاً **برعکس** بیمار ماست که کف دست و پایش سالم مانده.\n\n"
 "⚠️ **تب روماتیسمی** ← راشش **اریتم مارژیناتوم** است: حلقوی، محو، گذرا و **غیرزبر** — کاملاً متفاوت با راش سنباده‌ای.\n\n"
 "**درمان مخملک همان درمان فارنژیت استرپتوکوکی است: پنی‌سیلین ۱۰ روز.**",
 "A 6-YEAR-OLD GIRL develops a rash after ACUTE PURULENT PHARYNGITIS. Read the rash carefully, because every word of it is diagnostic:\n\n"
 "IT BEGINS ON CHEST AND BACK, spreads rapidly to the limbs, BUT SPARES PALMS AND SOLES\n"
 "WARNING, IT FEELS ROUGH LIKE SANDPAPER — a description almost SPECIFIC to scarlet fever\n"
 "IT IS DARKER IN THE SKIN FOLDS (axilla, antecubital fossa) — PASTIA'S LINES\n"
 "THE TONGUE LOOKS LIKE A STRAWBERRY — first white with prominent papillae, then red\n\n"
 "SO THE DIAGNOSIS IS SCARLET FEVER.\n\n"
 "WARNING, AND AN IMPORTANT CONCEPTUAL POINT: SCARLET FEVER IS A TOXIN DISEASE, NOT A DISEASE OF THE ORGANISM ITSELF. Its agent is STREPTOCOCCAL PYROGENIC EXOTOXIN (erythrogenic toxin) from group A strep. That is why SCARLET FEVER ALWAYS ACCOMPANIES OR FOLLOWS A STREPTOCOCCAL INFECTION — in ninety per cent of cases a pharyngitis.\n\n"
 "TWO MORE SIGNS TO KNOW: CIRCUMORAL PALLOR, and DESQUAMATION IN THE SECOND WEEK, especially from the fingertips.\n\n"
 "WHY DO THE OTHER OPTIONS FAIL?\n\n"
 "MEASLES comes with CORYZA, COUGH, CONJUNCTIVITIS and KOPLIK SPOTS. Its rash is MACULOPAPULAR, spreads FROM THE HAIRLINE DOWNWARDS, and IS NOT ROUGH.\n\n"
 "KAWASAKI DISEASE requires FEVER FOR MORE THAN 5 DAYS and, crucially, INVOLVES THE PALMS AND SOLES (erythema and oedema of the palms). That is the exact OPPOSITE of our patient, whose palms and soles are spared.\n\n"
 "WARNING, RHEUMATIC FEVER has ERYTHEMA MARGINATUM: annular, faint, transient and NOT ROUGH — entirely different from a sandpaper rash.\n\n"
 "TREATMENT OF SCARLET FEVER IS THE SAME AS STREPTOCOCCAL PHARYNGITIS: PENICILLIN FOR 10 DAYS.",
 ["پاسخ صحیح — راش سنباده‌ای با خطوط پاستیا و زبان توت‌فرنگی پس از فارنژیت چرکی: مخملک.",
  "سرخک با کوریزا، سرفه، کونژنکتیویت و لکه‌های کوپلیک می‌آید و راشش زبر نیست.",
  "کاوازاکی تب بیش از ۵ روز و درگیری کف دست و پا دارد، در حالی که اینجا کف دست و پا سالم است.",
  "راش تب روماتیسمی اریتم مارژیناتوم است: حلقوی، محو، گذرا و غیرزبر."],
 ["Correct — a sandpaper rash with Pastia's lines and a strawberry tongue after purulent pharyngitis is scarlet fever.",
  "Measles comes with coryza, cough, conjunctivitis and Koplik spots, and its rash is not rough.",
  "Kawasaki requires fever for over 5 days and involves palms and soles, which are spared here.",
  "The rash of rheumatic fever is erythema marginatum: annular, faint, transient and not rough."],
 "**سنباده‌ای + پاستیا + زبان توت‌فرنگی + کف دست سالم = مخملک** (توکسین اریتروژنیک).",
 "Sandpaper rash plus Pastia's lines plus a strawberry tongue with spared palms means scarlet fever (erythrogenic toxin).",
 [H143])


# =========================================================== book:44
add("book:44", "recall", "hard",
 "ریشه‌کنی ناقل حلقی استرپ ← **پنی‌سیلین خوراکی + ریفامپین**.",
 "Eradicating pharyngeal streptococcal carriage needs ORAL PENICILLIN PLUS RIFAMPICIN.",
 PHAR_FA + [
  "این سؤال درباره‌ی **ناقل بدون علامت** است، نه بیمار — و این تمایز کل پاسخ را می‌سازد.",
  "**اول بدانید ناقل کیست: کسی که کشت حلقش مثبت است ولی نه علامتی دارد و نه پاسخ ایمنی فعال.**",
  "**تا ۲۰ درصد کودکان مدرسه‌ای در فصل زمستان ناقل استرپ گروه A هستند.**",
  "⚠️ **و نکته‌ی مهم: ناقل معمولاً نیازی به درمان ندارد.**",
  "**چرا؟ چون سه ویژگی دارد که او را کم‌خطر می‌کند:**",
  "**یک — خطر ابتلای خودش به تب روماتیسمی بسیار پایین است** (چون تهاجم بافتی ندارد).",
  "**دو — سرایت‌دهندگی‌اش به دیگران کم است.**",
  "**سه — درمانش دشوار است و پنی‌سیلین تنها اغلب شکست می‌خورد.**",
  "**پس ریشه‌کنی فقط در موقعیت‌های خاص انجام می‌شود:**",
  "**طغیان در جامعه‌ی بسته** (مثل همین سؤال — همه‌گیری بیمارستانی)، **سابقه‌ی خانوادگی تب روماتیسمی**،",
  "**عود مکرر در خانواده**، **اضطراب شدید خانواده**، یا **در نظر گرفتن تونسیلکتومی**.",
  "⚠️ **حالا چرا پنی‌سیلین تنها برای ریشه‌کنی کافی نیست؟**",
  "**دو دلیل:** یک — باکتری **داخل سلول‌های اپیتلیال حلق** پناه می‌گیرد و پنی‌سیلین آنجا نمی‌رسد.",
  "**دو — فلور طبیعی حلق بتالاکتاماز تولید می‌کند** که پنی‌سیلین را تجزیه می‌کند.",
  "**ریفامپین هر دو مشکل را حل می‌کند: نفوذ عالی داخل‌سلولی، و بتالاکتاماز رویش اثری ندارد.**",
  "⚠️ **پس رژیم: پنی‌سیلین ۱۰ روز، با افزودن ریفامپین در ۴ روز آخر.**",
  "**جایگزین‌ها: کلیندامایسین ۱۰ روز، یا آموکسی‌سیلین-کلاوولانات ۱۰ روز.**",
  "**چرا وانکومایسین خوراکی نه؟** وانکومایسین خوراکی **جذب سیستمیک ندارد**؛",
  "در روده می‌ماند و جایش فقط **کولیت کلستریدیوم دیفیسیل** است. در حلق بی‌فایده است.",
 ],
 PHAR_EN + [
  "This question is about an ASYMPTOMATIC CARRIER, not a patient — and that distinction makes the whole answer.",
  "FIRST KNOW WHO A CARRIER IS: someone with a positive throat culture but no symptoms and no active immune response.",
  "UP TO 20 PER CENT OF SCHOOLCHILDREN CARRY GROUP A STREP IN WINTER.",
  "WARNING, AND THE IMPORTANT POINT: A CARRIER USUALLY NEEDS NO TREATMENT.",
  "WHY? Because three features make them low risk:",
  "ONE — THEIR OWN RISK OF RHEUMATIC FEVER IS VERY LOW (there is no tissue invasion).",
  "TWO — THEY TRANSMIT POORLY TO OTHERS.",
  "THREE — THEY ARE HARD TO CLEAR, and penicillin alone often fails.",
  "SO ERADICATION IS ATTEMPTED ONLY IN SPECIFIC SITUATIONS:",
  "AN OUTBREAK IN A CLOSED COMMUNITY (as in this question — a hospital outbreak), A FAMILY HISTORY OF RHEUMATIC FEVER,",
  "REPEATED FAMILY RECURRENCES, SEVERE FAMILY ANXIETY, or WHEN TONSILLECTOMY IS BEING CONSIDERED.",
  "WARNING, NOW WHY IS PENICILLIN ALONE INSUFFICIENT FOR ERADICATION?",
  "TWO REASONS: one — the organism shelters INSIDE PHARYNGEAL EPITHELIAL CELLS, where penicillin does not reach.",
  "TWO — THE NORMAL PHARYNGEAL FLORA PRODUCES BETA-LACTAMASE, which degrades penicillin.",
  "RIFAMPICIN SOLVES BOTH: excellent intracellular penetration, and beta-lactamase does not touch it.",
  "WARNING, SO THE REGIMEN IS: PENICILLIN FOR 10 DAYS WITH RIFAMPICIN ADDED FOR THE LAST 4 DAYS.",
  "ALTERNATIVES: clindamycin for 10 days, or amoxicillin-clavulanate for 10 days.",
  "Why not oral vancomycin? ORAL VANCOMYCIN IS NOT SYSTEMICALLY ABSORBED;",
  "it stays in the gut and its only place is CLOSTRIDIOIDES DIFFICILE COLITIS. In the pharynx it is useless.",
 ],
 "این سؤال درباره‌ی **ناقل بدون علامت** است، نه بیمار — و همین تمایز، کل پاسخ را می‌سازد.\n\n"
 "**ناقل کیست؟** کسی که **کشت حلقش مثبت است ولی نه علامتی دارد و نه پاسخ ایمنی فعال**. تا **۲۰ درصد کودکان مدرسه‌ای** در فصل زمستان ناقل استرپ گروه A هستند.\n\n"
 "⚠️ **و نکته‌ی اول: ناقل معمولاً نیازی به درمان ندارد.** چون سه ویژگی دارد: **خطر تب روماتیسمی خودش بسیار پایین است** (تهاجم بافتی ندارد)، **سرایت‌دهندگی‌اش کم است**، و **ریشه‌کنی‌اش دشوار است**.\n\n"
 "**پس ریشه‌کنی فقط در موقعیت‌های خاص انجام می‌شود:** **طغیان در جامعه‌ی بسته** (دقیقاً همین سؤال — همه‌گیری بیمارستانی)، سابقه‌ی خانوادگی تب روماتیسمی، عود مکرر در خانواده، یا در نظر گرفتن تونسیلکتومی.\n\n"
 "⚠️ **و حالا مهم‌ترین بخش: چرا پنی‌سیلین به‌تنهایی برای ریشه‌کنی کافی نیست؟**\n\n"
 "**دلیل اول:** باکتری **داخل سلول‌های اپیتلیال حلق** پناه می‌گیرد، و پنی‌سیلین که نفوذ داخل‌سلولی ضعیفی دارد به آنجا نمی‌رسد.\n\n"
 "**دلیل دوم:** **فلور طبیعی حلق (به‌ویژه بی‌هوازی‌ها و موراکسلا) بتالاکتاماز تولید می‌کند** که پنی‌سیلین را پیش از رسیدن به هدف تجزیه می‌کند.\n\n"
 "**و ریفامپین دقیقاً هر دو مشکل را حل می‌کند:** نفوذ **عالی داخل‌سلولی** دارد، و **بتالاکتاماز روی آن هیچ اثری ندارد**.\n\n"
 "⚠️ **پس رژیم درست: پنی‌سیلین خوراکی ۱۰ روز، با افزودن ریفامپین در ۴ روز آخر.** (ریفامپین هرگز تنها داده نمی‌شود، چون مقاومت سریع ایجاد می‌کند.)\n\n"
 "**جایگزین‌ها:** کلیندامایسین ۱۰ روز، یا آموکسی‌سیلین-کلاوولانات ۱۰ روز.\n\n"
 "**چرا وانکومایسین خوراکی نه؟** ⚠️ **وانکومایسین خوراکی اصلاً جذب سیستمیک ندارد** — در روده می‌ماند و تنها جایش **کولیت کلستریدیوم دیفیسیل** است. برای ریشه‌کنی حلق کاملاً بی‌فایده است.",
 "This question is about an ASYMPTOMATIC CARRIER, not a patient — and that distinction makes the whole answer.\n\n"
 "WHO IS A CARRIER? Someone with A POSITIVE THROAT CULTURE BUT NO SYMPTOMS AND NO ACTIVE IMMUNE RESPONSE. Up to 20 PER CENT of schoolchildren carry group A strep in winter.\n\n"
 "WARNING, AND THE FIRST POINT: A CARRIER USUALLY NEEDS NO TREATMENT, for three reasons: THEIR OWN RISK OF RHEUMATIC FEVER IS VERY LOW (no tissue invasion), THEY TRANSMIT POORLY, and THEY ARE HARD TO CLEAR.\n\n"
 "SO ERADICATION IS ATTEMPTED ONLY IN SPECIFIC SITUATIONS: AN OUTBREAK IN A CLOSED COMMUNITY (exactly this question — a hospital outbreak), a family history of rheumatic fever, repeated family recurrences, or when tonsillectomy is being considered.\n\n"
 "WARNING, AND NOW THE KEY PART: WHY IS PENICILLIN ALONE INSUFFICIENT FOR ERADICATION?\n\n"
 "FIRST REASON: the organism shelters INSIDE PHARYNGEAL EPITHELIAL CELLS, and penicillin, with poor intracellular penetration, does not reach it there.\n\n"
 "SECOND REASON: THE NORMAL PHARYNGEAL FLORA (especially anaerobes and Moraxella) PRODUCES BETA-LACTAMASE, which degrades penicillin before it reaches its target.\n\n"
 "AND RIFAMPICIN SOLVES EXACTLY BOTH PROBLEMS: it has EXCELLENT INTRACELLULAR PENETRATION, and BETA-LACTAMASE HAS NO EFFECT ON IT.\n\n"
 "WARNING, SO THE CORRECT REGIMEN IS: ORAL PENICILLIN FOR 10 DAYS WITH RIFAMPICIN ADDED FOR THE LAST 4 DAYS. (Rifampicin is never given alone, because resistance emerges rapidly.)\n\n"
 "ALTERNATIVES: clindamycin for 10 days, or amoxicillin-clavulanate for 10 days.\n\n"
 "WHY NOT ORAL VANCOMYCIN? WARNING: ORAL VANCOMYCIN IS NOT ABSORBED SYSTEMICALLY AT ALL — it stays in the gut and its only place is CLOSTRIDIOIDES DIFFICILE COLITIS. For pharyngeal eradication it is entirely useless.",
 ["وانکومایسین خوراکی جذب سیستمیک ندارد و در ریشه‌کنی حلقی هیچ نقشی ایفا نمی‌کند.",
  "وانکومایسین خوراکی در حلق بی‌اثر است؛ ریفامپین هم هرگز به‌تنهایی یا با آن داده نمی‌شود.",
  "پاسخ صحیح — پنی‌سیلین خوراکی به‌همراه ریفامپین، که نفوذ داخل‌سلولی دارد و بتالاکتاماز رویش اثری ندارد.",
  "در طغیان بیمارستانی، ریشه‌کنی ناقلین اندیکاسیون دارد و «اقدام لازم نیست» نادرست است."],
 ["Oral vancomycin is not absorbed systemically and has no role in pharyngeal eradication.",
  "Oral vancomycin is ineffective in the pharynx, and rifampicin is never given alone or with it.",
  "Correct — oral penicillin plus rifampicin, which penetrates cells and is unaffected by beta-lactamase.",
  "In a hospital outbreak, carrier eradication is indicated, so 'no action needed' is incorrect."],
 "ریشه‌کنی ناقل: **پنی‌سیلین + ریفامپین (۴ روز آخر).** ریفامپین **داخل سلول** می‌رود و بتالاکتاماز نمی‌شکندش.",
 "Carrier eradication: penicillin plus rifampicin for the last 4 days. Rifampicin enters cells and beta-lactamase cannot break it.",
 [IDSAP, H143])


# =========================================================== book:55
add("book:55", "case", "medium",
 "**کاربونکل** پشت گردن در دیابتی ← **استاف اورئوس** ← **سفازولین**.",
 "A CARBUNCLE on the nape of a diabetic means STAPH AUREUS: give CEFAZOLIN.",
 STAPH_FA + [
  "بیمار **دیابتی ۷۰ ساله** با درد پشت گردن، تب، و **تورم مواج با خروج چرک**.",
  "⚠️ **«تورم مواج با خروج چرک» یعنی یک تجمع چرکی — و چرک یعنی استافیلوکوک.**",
  "**این تابلوی کاربونکل است: مجموعه‌ای از فورونکل‌های به‌هم‌پیوسته.**",
  "**چرا پشت گردن؟** چون آنجا **پوست ضخیم و غیرقابل‌اتساع** است،",
  "پس عفونت فولیکولی نمی‌تواند به سطح باز شود و **به‌صورت افقی در بافت زیرجلدی گسترش می‌یابد**،",
  "چند فولیکول را به هم وصل می‌کند و **کاربونکل با چند دهانه‌ی چرکی** می‌سازد.",
  "**سایر محل‌های شایع: پشت، ران و باسن — همگی نواحی با پوست ضخیم.**",
  "⚠️ **چرا دیابت؟ سه مکانیسم:**",
  "**اختلال شیمی‌تاکسی و فاگوسیتوز نوتروفیل** در هیپرگلیسمی،",
  "**کاهش خون‌رسانی** به‌علت بیماری عروق کوچک، و **کلونیزاسیون بیشتر بینی با استاف**.",
  "**درمان کاربونکل دو بخش دارد و هر دو لازم است:**",
  "⚠️ **یک — تخلیه‌ی جراحی (incision and drainage). این مهم‌ترین بخش است.**",
  "**دو — آنتی‌بیوتیک ضداستافیلوکوکی: سفازولین (تزریقی) یا کلوگزاسیلین.**",
  "**در بیمار تب‌دار و دیابتی، درمان تزریقی و بستری منطقی است.**",
  "چرا پسودوموناس نه؟ آن پاتوژن **نوتروپنی، سوختگی و اوتیت خارجی بدخیم** است.",
  "⚠️ **و نکته‌ی مهم دیگر: اگر MRSA در منطقه شایع باشد یا بیمار عامل خطر داشته باشد،**",
  "**باید وانکومایسین جایگزین سفازولین شود** — پس همیشه کشت چرک بگیرید.",
 ],
 STAPH_EN + [
  "A 70-YEAR-OLD DIABETIC with pain in the nape of the neck, fever, and A FLUCTUANT SWELLING DISCHARGING PUS.",
  "WARNING: 'FLUCTUANT SWELLING WITH PUS' MEANS A PURULENT COLLECTION — AND PUS MEANS STAPHYLOCOCCUS.",
  "THIS IS A CARBUNCLE: a cluster of interconnected furuncles.",
  "WHY THE NAPE OF THE NECK? Because the skin there is THICK AND INEXTENSIBLE,",
  "so a follicular infection cannot open to the surface and SPREADS HORIZONTALLY IN THE SUBCUTIS,",
  "linking several follicles and producing A CARBUNCLE WITH MULTIPLE DRAINING POINTS.",
  "OTHER COMMON SITES: back, thigh and buttock — all areas of thick skin.",
  "WARNING, WHY DIABETES? Three mechanisms:",
  "IMPAIRED NEUTROPHIL CHEMOTAXIS AND PHAGOCYTOSIS in hyperglycaemia,",
  "REDUCED PERFUSION from small vessel disease, and GREATER NASAL STAPHYLOCOCCAL COLONISATION.",
  "TREATMENT OF A CARBUNCLE HAS TWO PARTS AND BOTH ARE REQUIRED:",
  "WARNING, ONE — SURGICAL INCISION AND DRAINAGE. This is the most important part.",
  "TWO — AN ANTISTAPHYLOCOCCAL ANTIBIOTIC: CEFAZOLIN (intravenous) or CLOXACILLIN.",
  "In a febrile diabetic, intravenous therapy and admission are reasonable.",
  "Why not Pseudomonas? That is the pathogen of NEUTROPENIA, BURNS AND MALIGNANT OTITIS EXTERNA.",
  "WARNING, AND ANOTHER IMPORTANT POINT: IF MRSA IS PREVALENT LOCALLY OR THE PATIENT HAS RISK FACTORS,",
  "VANCOMYCIN MUST REPLACE CEFAZOLIN — so always culture the pus.",
 ],
 "بیمار **دیابتی ۷۰ ساله** با درد پشت گردن، تب، و در معاینه **تورم مواج با خروج چرک** از بافت نرم.\n\n"
 "⚠️ **«تورم مواج با خروج چرک» یعنی یک تجمع چرکی — و قاعده‌ی طلایی می‌گوید: هر جا چرک هست، استافیلوکوک است.**\n\n"
 "**تشخیص: کاربونکل** — مجموعه‌ای از فورونکل‌های به‌هم‌پیوسته با چند دهانه‌ی چرکی.\n\n"
 "**چرا پشت گردن؟** این نکته‌ی آناتومیک را بدانید: پوست پشت گردن **ضخیم و غیرقابل‌اتساع** است. پس عفونتی که از یک فولیکول مو شروع شده نمی‌تواند به سطح باز شود و در عوض **به‌صورت افقی در بافت زیرجلدی گسترش می‌یابد**، چند فولیکول مجاور را به هم وصل می‌کند و کاربونکل می‌سازد. سایر محل‌های شایع (پشت، ران، باسن) هم دقیقاً همین ویژگی را دارند.\n\n"
 "⚠️ **چرا دیابت زمینه‌ساز است؟ سه مکانیسم:**\n\n"
 "**۱. اختلال شیمی‌تاکسی و فاگوسیتوز نوتروفیل** در هیپرگلیسمی\n"
 "**۲. کاهش خون‌رسانی** به‌علت بیماری عروق کوچک\n"
 "**۳. کلونیزاسیون بیشتر بینی با استافیلوکوک** در دیابتی‌ها\n\n"
 "**درمان دو بخش دارد و هر دو لازم است:**\n\n"
 "⚠️ **۱. تخلیه‌ی جراحی (incision and drainage)** — این مهم‌ترین بخش است. یک تجمع چرکی با آنتی‌بیوتیک تنها درمان نمی‌شود.\n\n"
 "**۲. آنتی‌بیوتیک ضداستافیلوکوکی: سفازولین** (تزریقی) یا **کلوگزاسیلین**. در بیمار تب‌دار و دیابتی، درمان تزریقی منطقی است.\n\n"
 "**چرا گزینه‌های دیگر رد می‌شوند؟** **پسودوموناس** ← پاتوژن نوتروپنی، سوختگی و اوتیت خارجی بدخیم است. **کاندیدا** ← عفونت چرکی بافت نرم به این شکل نمی‌سازد. **استرپتوکوک گروه A** ← عفونت **منتشر** می‌سازد نه تجمع چرکی موضعی.\n\n"
 "⚠️ **و یک هشدار عملی: اگر MRSA در منطقه شایع باشد، باید وانکومایسین جایگزین سفازولین شود.** پس همیشه از چرک **کشت** بگیرید.",
 "A 70-YEAR-OLD DIABETIC with pain in the nape of the neck, fever, and on examination A FLUCTUANT SWELLING DISCHARGING PUS from the soft tissue.\n\n"
 "WARNING: 'A FLUCTUANT SWELLING WITH PUS' MEANS A PURULENT COLLECTION — and the golden rule says WHEREVER THERE IS PUS, IT IS STAPHYLOCOCCUS.\n\n"
 "THE DIAGNOSIS IS A CARBUNCLE — a cluster of interconnected furuncles with multiple draining points.\n\n"
 "WHY THE NAPE OF THE NECK? Know this anatomical point: the skin there is THICK AND INEXTENSIBLE. So an infection beginning in a hair follicle cannot open to the surface and instead SPREADS HORIZONTALLY IN THE SUBCUTANEOUS TISSUE, linking neighbouring follicles into a carbuncle. The other common sites (back, thigh, buttock) share exactly that property.\n\n"
 "WARNING, WHY DOES DIABETES PREDISPOSE? Three mechanisms:\n\n"
 "1. IMPAIRED NEUTROPHIL CHEMOTAXIS AND PHAGOCYTOSIS in hyperglycaemia\n"
 "2. REDUCED PERFUSION from small vessel disease\n"
 "3. GREATER NASAL STAPHYLOCOCCAL COLONISATION in diabetics\n\n"
 "TREATMENT HAS TWO PARTS AND BOTH ARE REQUIRED:\n\n"
 "WARNING, 1. SURGICAL INCISION AND DRAINAGE — the most important part. A purulent collection is not cured by antibiotics alone.\n\n"
 "2. AN ANTISTAPHYLOCOCCAL ANTIBIOTIC: CEFAZOLIN (intravenous) or CLOXACILLIN. In a febrile diabetic, intravenous therapy is reasonable.\n\n"
 "WHY THE OTHER OPTIONS FAIL? PSEUDOMONAS is the pathogen of neutropenia, burns and malignant otitis externa. CANDIDA does not produce this kind of purulent soft tissue infection. GROUP A STREPTOCOCCUS causes DIFFUSE infection rather than a localised purulent collection.\n\n"
 "WARNING, AND A PRACTICAL CAUTION: IF MRSA IS PREVALENT LOCALLY, VANCOMYCIN MUST REPLACE CEFAZOLIN. So always CULTURE the pus.",
 ["پسودوموناس آئروژینوزا پاتوژن نوتروپنی، سوختگی و اوتیت خارجی بدخیم است، نه کاربونکل.",
  "پاسخ صحیح — تجمع چرکی یعنی استافیلوکوک طلایی، و سفازولین آنتی‌بیوتیک ضداستافیلوکوکی مناسبی است.",
  "کاندیدا آلبیکنس عفونت چرکی بافت نرم به این شکل ایجاد نمی‌کند و فلوکونازول اینجا جایی ندارد.",
  "استرپتوکوک گروه A عفونت منتشر (سلولیت، اریزیپل) می‌سازد، نه تجمع چرکی موضعی با تورم مواج."],
 ["Pseudomonas aeruginosa is the pathogen of neutropenia, burns and malignant otitis externa, not carbuncles.",
  "Correct — a purulent collection means Staphylococcus aureus, and cefazolin is a suitable antistaphylococcal agent.",
  "Candida albicans does not cause this kind of purulent soft tissue infection and fluconazole has no place here.",
  "Group A streptococcus causes diffuse infection (cellulitis, erysipelas), not a localised fluctuant purulent collection."],
 "**چرک = استاف.** کاربونکل ← **تخلیه + ضداستاف**. پوست ضخیم پشت گردن، عفونت را افقی می‌گستراند.",
 "Pus means staph. A carbuncle needs drainage plus an antistaphylococcal agent. The thick skin of the nape spreads infection horizontally.",
 [H142, IDSA_REF := "Stevens DL et al. — IDSA Skin and Soft Tissue Infections, 2014 update"])


# =========================================================== book:69
add("book:69", "case", "medium",
 "شک به اسپوندیلودیسکیت ← **MRI**، چون گرافی ساده هفته‌ها طبیعی می‌ماند.",
 "Suspected spondylodiscitis needs MRI, because the plain film stays normal for weeks.",
 STAPH_FA + [
  "بیمار **۴۵ ساله** با **تب، کمردرد با انتشار به پا**، ضعف و بی‌حالی از ده روز پیش.",
  "**در معاینه تندرنس روی مهره‌های سوم و چهارم کمری، و در آزمایش لکوسیتوز و ESR بالا.**",
  "⚠️ **ترکیب «تب + کمردرد موضعی + التهاب سیستمیک» یعنی اسپوندیلودیسکیت تا خلافش ثابت شود.**",
  "**و انتشار درد به پا یعنی احتمال درگیری ریشه‌ی عصبی یا آبسه‌ی اپیدورال.**",
  "**حالا سؤال این است: کدام تصویربرداری؟ و چهار گزینه را با هم مقایسه کنیم:**",
  "⚠️ **گرافی ساده** ← بزرگ‌ترین ضعفش **تأخیر زمانی** است.",
  "**تغییرات رادیوگرافیک تا ۲ تا ۴ هفته پس از شروع عفونت ظاهر نمی‌شوند**،",
  "چون گرافی فقط وقتی چیزی نشان می‌دهد که **۳۰ تا ۵۰ درصد ماده‌ی استخوانی از دست رفته باشد**.",
  "**بیمار ما ده روز است که علامت دارد — گرافی‌اش تقریباً حتماً طبیعی خواهد بود.**",
  "**اسکن استخوان** ← **حساس ولی بسیار غیراختصاصی**؛ در شکستگی، تومور و آرتروز هم مثبت می‌شود.",
  "و مهم‌تر: **آبسه‌ی اپیدورال و درگیری بافت نرم را نشان نمی‌دهد**.",
  "**سی‌تی‌اسکن** ← تخریب استخوانی را بهتر از گرافی نشان می‌دهد،",
  "ولی **حساسیتش برای مغز استخوان و دیسک در فاز اولیه پایین است**.",
  "⚠️ **MRI روش انتخابی است، و چهار مزیت دارد:**",
  "**یک — حساسیت بیش از ۹۰ درصد، و مثبت شدن در همان روزهای اول** (ادم مغز استخوان).",
  "**دو — نشان دادن دیسک، بافت نرم پاراورتبرال، و مهم‌تر از همه آبسه‌ی اپیدورال.**",
  "**سه — تعیین وسعت درگیری برای برنامه‌ریزی جراحی.** **چهار — بدون تشعشع یونیزان.**",
  "**و پس از تصویربرداری: کشت خون و در صورت لزوم بیوپسی سوزنی تحت هدایت تصویر.**",
 ],
 STAPH_EN + [
  "A 45-YEAR-OLD with FEVER, BACK PAIN RADIATING TO THE LEG, weakness and malaise for ten days.",
  "ON EXAMINATION there is tenderness over L3 and L4, and the laboratory shows leucocytosis and a raised ESR.",
  "WARNING: FEVER PLUS LOCALISED BACK PAIN PLUS SYSTEMIC INFLAMMATION MEANS SPONDYLODISCITIS UNTIL PROVEN OTHERWISE.",
  "AND RADIATION TO THE LEG RAISES THE POSSIBILITY OF NERVE ROOT INVOLVEMENT OR AN EPIDURAL ABSCESS.",
  "NOW THE QUESTION IS WHICH IMAGING, so let us compare the four options:",
  "WARNING, THE PLAIN FILM — its greatest weakness is a TIME LAG.",
  "RADIOGRAPHIC CHANGES DO NOT APPEAR FOR 2 TO 4 WEEKS after the infection begins,",
  "because a plain film shows something only once 30 TO 50 PER CENT OF BONE MINERAL HAS BEEN LOST.",
  "OUR PATIENT HAS HAD SYMPTOMS FOR TEN DAYS — his film will almost certainly be normal.",
  "THE BONE SCAN — SENSITIVE BUT VERY NON-SPECIFIC; it is positive in fracture, tumour and arthrosis too.",
  "And more importantly, IT DOES NOT SHOW AN EPIDURAL ABSCESS OR SOFT TISSUE INVOLVEMENT.",
  "CT — shows bony destruction better than a plain film,",
  "but ITS SENSITIVITY FOR MARROW AND DISC IN THE EARLY PHASE IS LOW.",
  "WARNING, MRI IS THE MODALITY OF CHOICE, with four advantages:",
  "ONE — SENSITIVITY ABOVE 90 PER CENT, POSITIVE IN THE FIRST DAYS (marrow oedema).",
  "TWO — IT SHOWS THE DISC, THE PARAVERTEBRAL SOFT TISSUE AND, ABOVE ALL, AN EPIDURAL ABSCESS.",
  "THREE — IT DEFINES THE EXTENT FOR SURGICAL PLANNING. FOUR — NO IONISING RADIATION.",
  "AND AFTER IMAGING: BLOOD CULTURES and, if needed, IMAGE-GUIDED NEEDLE BIOPSY.",
 ],
 "بیمار **۴۵ ساله** با **تب، کمردرد با انتشار به پای راست**، ضعف و بی‌حالی از ده روز پیش مراجعه کرده است. در معاینه **تندرنس روی مهره‌های سوم و چهارم کمری** دارد، و در آزمایش **لکوسیتوز و ESR افزایش‌یافته**.\n\n"
 "⚠️ **ترکیب «تب + کمردرد موضعی + التهاب سیستمیک» یعنی اسپوندیلودیسکیت، تا خلافش ثابت شود.** و **انتشار درد به پا** یعنی احتمال درگیری ریشه‌ی عصبی یا **آبسه‌ی اپیدورال** — که خودش یک فوریت است.\n\n"
 "**حالا چهار گزینه‌ی تصویربرداری را با هم مقایسه کنیم:**\n\n"
 "⚠️ **گرافی ساده** ← بزرگ‌ترین ضعفش **تأخیر زمانی** است. **تغییرات رادیوگرافیک تا ۲ تا ۴ هفته پس از شروع عفونت ظاهر نمی‌شوند**، چون گرافی ساده فقط وقتی چیزی نشان می‌دهد که **۳۰ تا ۵۰ درصد ماده‌ی استخوانی از دست رفته باشد**. بیمار ما **ده روز** است که علامت دارد — گرافی‌اش تقریباً حتماً طبیعی خواهد بود، و همین **تشخیص را به تأخیر می‌اندازد**.\n\n"
 "**اسکن استخوان** ← **حساس، ولی بسیار غیراختصاصی**. در شکستگی، تومور و حتی آرتروز هم مثبت می‌شود. و مهم‌تر اینکه **آبسه‌ی اپیدورال و درگیری بافت نرم را نشان نمی‌دهد**.\n\n"
 "**سی‌تی‌اسکن** ← تخریب استخوانی را بهتر از گرافی نشان می‌دهد، ولی **حساسیتش برای ادم مغز استخوان و درگیری دیسک در فاز اولیه پایین است**.\n\n"
 "⚠️ **پس MRI روش انتخابی است، و چهار مزیت دارد:**\n\n"
 "**۱. حساسیت بیش از ۹۰ درصد**، و **مثبت شدن در همان روزهای اول** (چون ادم مغز استخوان را می‌بیند)\n"
 "**۲. نشان دادن دیسک، بافت نرم پاراورتبرال، و مهم‌تر از همه آبسه‌ی اپیدورال**\n"
 "**۳. تعیین وسعت درگیری** برای برنامه‌ریزی جراحی\n"
 "**۴. بدون تشعشع یونیزان**\n\n"
 "**و پس از تصویربرداری:** **کشت خون** بگیرید (در نیمی از موارد مثبت است) و در صورت منفی بودن، **بیوپسی سوزنی تحت هدایت تصویر** انجام دهید — چون **درمان طولانی است و باید بدانیم با چه ارگانیسمی طرفیم**.",
 "A 45-YEAR-OLD presents with FEVER, BACK PAIN RADIATING TO THE RIGHT LEG, weakness and malaise for ten days. On examination there is TENDERNESS OVER L3 AND L4, and the laboratory shows LEUCOCYTOSIS AND A RAISED ESR.\n\n"
 "WARNING: FEVER PLUS LOCALISED BACK PAIN PLUS SYSTEMIC INFLAMMATION MEANS SPONDYLODISCITIS UNTIL PROVEN OTHERWISE. And RADIATION TO THE LEG raises the possibility of nerve root involvement or an EPIDURAL ABSCESS, which is itself an emergency.\n\n"
 "NOW LET US COMPARE THE FOUR IMAGING OPTIONS:\n\n"
 "WARNING, THE PLAIN FILM — its greatest weakness is a TIME LAG. RADIOGRAPHIC CHANGES DO NOT APPEAR FOR 2 TO 4 WEEKS after the infection begins, because a plain film shows something only once 30 TO 50 PER CENT OF BONE MINERAL HAS BEEN LOST. Our patient has had symptoms for TEN DAYS — his film will almost certainly be normal, and that DELAYS THE DIAGNOSIS.\n\n"
 "THE BONE SCAN — SENSITIVE BUT VERY NON-SPECIFIC. It is positive in fracture, tumour and even arthrosis. And crucially, IT DOES NOT SHOW AN EPIDURAL ABSCESS OR SOFT TISSUE INVOLVEMENT.\n\n"
 "CT — shows bony destruction better than a plain film, but ITS SENSITIVITY FOR MARROW OEDEMA AND EARLY DISC INVOLVEMENT IS LOW.\n\n"
 "WARNING, SO MRI IS THE MODALITY OF CHOICE, with four advantages:\n\n"
 "1. SENSITIVITY ABOVE 90 PER CENT, POSITIVE IN THE FIRST DAYS (because it sees marrow oedema)\n"
 "2. IT SHOWS THE DISC, THE PARAVERTEBRAL SOFT TISSUE AND, ABOVE ALL, AN EPIDURAL ABSCESS\n"
 "3. IT DEFINES THE EXTENT for surgical planning\n"
 "4. NO IONISING RADIATION\n\n"
 "AND AFTER IMAGING: take BLOOD CULTURES (positive in half of cases) and, if negative, perform an IMAGE-GUIDED NEEDLE BIOPSY — because TREATMENT IS LONG AND WE MUST KNOW THE ORGANISM.",
 ["گرافی ساده تا ۲ تا ۴ هفته طبیعی می‌ماند و در بیمار با ده روز علامت، تشخیص را به تأخیر می‌اندازد.",
  "پاسخ صحیح — MRI حساسیت بالای ۹۰ درصد دارد، از روزهای اول مثبت می‌شود و آبسه‌ی اپیدورال را نشان می‌دهد.",
  "اسکن استخوان حساس ولی غیراختصاصی است و آبسه‌ی اپیدورال و بافت نرم را نشان نمی‌دهد.",
  "سی‌تی‌اسکن تخریب استخوانی را نشان می‌دهد ولی برای ادم مغز استخوان در فاز اولیه حساسیت کافی ندارد."],
 ["A plain film stays normal for 2 to 4 weeks and, in a patient with ten days of symptoms, delays the diagnosis.",
  "Correct — MRI has over 90% sensitivity, is positive from the first days, and shows an epidural abscess.",
  "A bone scan is sensitive but non-specific and does not show epidural abscess or soft tissue involvement.",
  "CT shows bony destruction but lacks sensitivity for early marrow oedema."],
 "اسپوندیلودیسکیت ← **MRI**. گرافی **۲ تا ۴ هفته** طبیعی می‌ماند و **آبسه‌ی اپیدورال** را نمی‌بیند.",
 "Spondylodiscitis means MRI. A plain film stays normal for 2 to 4 weeks and cannot show an epidural abscess.",
 [H142])


# =========================================================== book:70
add("book:70", "recall", "easy",
 "پروفیلاکسی جراحی قلب باز ← **سفازولین**، چون هدف **استاف پوست** است.",
 "Prophylaxis for open heart surgery is CEFAZOLIN, because the target is SKIN STAPHYLOCOCCI.",
 STAPH_FA + [
  "این سؤال یک اصل کلی جراحی را می‌سنجد: **پروفیلاکسی باید محتمل‌ترین آلاینده را هدف بگیرد.**",
  "**در جراحی قلب باز، برش از راه پوست و استرنوم است.**",
  "⚠️ **پس محتمل‌ترین آلاینده، فلور پوست خودِ بیمار است: استافیلوکوک اورئوس و استاف اپیدرمیدیس.**",
  "**سفازولین دقیقاً همین دو را هدف می‌گیرد** و به همین دلیل انتخاب استاندارد است.",
  "**چهار ویژگی سفازولین که آن را برای پروفیلاکسی ایده‌آل می‌کند:**",
  "**یک — پوشش عالی گرم‌مثبت‌های پوست** (استاف حساس به متی‌سیلین و استرپتوکوک).",
  "**دو — نیمه‌عمر مناسب** که با یک دوز پیش از برش، کل جراحی را پوشش می‌دهد.",
  "**سه — نفوذ بافتی خوب**، از جمله به استخوان استرنوم.",
  "**چهار — طیف باریک، که فشار انتخابی و خطر C. difficile را کم می‌کند.**",
  "⚠️ **حالا چرا سفتریاکسون نه، با اینکه «قوی‌تر» به نظر می‌رسد؟**",
  "**چون هدف اشتباهی را می‌زند.** سفتریاکسون نسل سوم است: **گرم‌منفی بهتر، گرم‌مثبت ضعیف‌تر**.",
  "**در جراحی تمیزِ قلب، گرم‌منفی روده اصلاً مسئله نیست.**",
  "**پس طیف وسیع‌تر اینجا مزیت نیست، بلکه ضرر است:** مقاومت بیشتر و خطر C. difficile بالاتر.",
  "**چرا وانکومایسین نه؟** ⚠️ **وانکومایسین فقط در سه حالت جایگزین می‌شود:**",
  "**آلرژی شدید به بتالاکتام**، **کلونیزاسیون شناخته‌شده‌ی MRSA**، یا **شیوع بالای MRSA در آن مرکز**.",
  "**استفاده‌ی روتین از آن، مقاومت به وانکومایسین را ترویج می‌کند و کندتر هم عمل می‌کند.**",
  "**چرا کلیندامایسین نه؟** جایگزین در آلرژی است، ولی پوشش گرم‌منفی ندارد و انتخاب اول نیست.",
  "⚠️ **و دو نکته‌ی زمان‌بندی که جداگانه پرسیده می‌شوند:**",
  "**دوز باید ظرف ۶۰ دقیقه پیش از برش** داده شود، و **پروفیلاکسی معمولاً ظرف ۲۴ ساعت قطع می‌شود**.",
 ],
 STAPH_EN + [
  "This question tests a general surgical principle: PROPHYLAXIS MUST TARGET THE MOST LIKELY CONTAMINANT.",
  "IN OPEN HEART SURGERY THE INCISION PASSES THROUGH SKIN AND STERNUM.",
  "WARNING: SO THE MOST LIKELY CONTAMINANT IS THE PATIENT'S OWN SKIN FLORA — STAPH AUREUS AND STAPH EPIDERMIDIS.",
  "CEFAZOLIN TARGETS EXACTLY THOSE TWO, which is why it is the standard choice.",
  "FOUR PROPERTIES MAKE CEFAZOLIN IDEAL FOR PROPHYLAXIS:",
  "ONE — EXCELLENT COVER OF SKIN GRAM-POSITIVES (methicillin-sensitive staph and streptococci).",
  "TWO — A SUITABLE HALF-LIFE, so one dose before incision covers the whole operation.",
  "THREE — GOOD TISSUE PENETRATION, including into sternal bone.",
  "FOUR — A NARROW SPECTRUM, which limits selection pressure and the risk of C. difficile.",
  "WARNING, NOW WHY NOT CEFTRIAXONE, WHICH SOUNDS 'STRONGER'?",
  "BECAUSE IT HITS THE WRONG TARGET. Ceftriaxone is third generation: BETTER GRAM-NEGATIVE, WEAKER GRAM-POSITIVE.",
  "IN CLEAN CARDIAC SURGERY, GUT GRAM-NEGATIVES ARE NOT THE ISSUE AT ALL.",
  "So a broader spectrum is not an advantage here but a harm: more resistance and more C. difficile.",
  "WHY NOT VANCOMYCIN? WARNING, VANCOMYCIN SUBSTITUTES IN ONLY THREE SITUATIONS:",
  "SEVERE BETA-LACTAM ALLERGY, KNOWN MRSA COLONISATION, or A HIGH LOCAL MRSA PREVALENCE.",
  "Routine use promotes vancomycin resistance and it also acts more slowly.",
  "WHY NOT CLINDAMYCIN? An alternative in allergy, but with no gram-negative cover and not first choice.",
  "WARNING, AND TWO TIMING POINTS THAT ARE ASKED SEPARATELY:",
  "THE DOSE MUST BE GIVEN WITHIN 60 MINUTES BEFORE INCISION, and PROPHYLAXIS IS USUALLY STOPPED WITHIN 24 HOURS.",
 ],
 "این سؤال یک **اصل کلی جراحی** را می‌سنجد که در همه‌ی جراحی‌ها به کار می‌آید:\n\n"
 "⚠️ **پروفیلاکسی آنتی‌بیوتیکی باید محتمل‌ترین آلاینده را هدف بگیرد، نه «قوی‌ترین» دارو را.**\n\n"
 "**در جراحی قلب باز، برش از راه پوست و استرنوم است.** پس محتمل‌ترین آلاینده، **فلور پوست خودِ بیمار** است: **استافیلوکوک اورئوس و استافیلوکوک اپیدرمیدیس**.\n\n"
 "**و سفازولین دقیقاً همین دو را هدف می‌گیرد.**\n\n"
 "**چهار ویژگی که سفازولین را برای پروفیلاکسی ایده‌آل می‌کند:**\n\n"
 "**۱. پوشش عالی گرم‌مثبت‌های پوست** (استاف حساس به متی‌سیلین و استرپتوکوک)\n"
 "**۲. نیمه‌عمر مناسب** — یک دوز پیش از برش، کل جراحی را پوشش می‌دهد\n"
 "**۳. نفوذ بافتی خوب**، از جمله به استخوان استرنوم\n"
 "**۴. طیف باریک** — فشار انتخابی کمتر و خطر کمتر کولیت کلستریدیوم دیفیسیل\n\n"
 "⚠️ **و حالا مهم‌ترین بخش: چرا سفتریاکسون نه، با اینکه «قوی‌تر» به نظر می‌رسد؟**\n\n"
 "**چون هدف اشتباهی را می‌زند.** سفتریاکسون نسل سوم است، و نسل سوم یعنی **گرم‌منفی بهتر، گرم‌مثبت ضعیف‌تر**. اما در یک جراحی **تمیزِ قلب**، گرم‌منفی روده اصلاً مسئله نیست. پس طیف وسیع‌تر اینجا **مزیت نیست، ضرر است**: هم مقاومت را ترویج می‌کند و هم خطر C. difficile را بالا می‌برد.\n\n"
 "**این یکی از مهم‌ترین درس‌های مدیریت آنتی‌بیوتیک است: «وسیع‌تر» با «بهتر» یکی نیست.**\n\n"
 "**چرا وانکومایسین نه؟** ⚠️ وانکومایسین فقط در سه حالت جایگزین می‌شود: **آلرژی شدید به بتالاکتام**، **کلونیزاسیون شناخته‌شده‌ی MRSA**، یا **شیوع بالای MRSA در آن مرکز**. استفاده‌ی روتین، مقاومت به وانکومایسین را ترویج می‌کند و ضمناً وانکومایسین **کندتر** از سفازولین عمل می‌کند.\n\n"
 "⚠️ **و دو نکته‌ی زمان‌بندی:** دوز باید **ظرف ۶۰ دقیقه پیش از برش** داده شود، و پروفیلاکسی معمولاً **ظرف ۲۴ ساعت** قطع می‌شود.",
 "This question tests a GENERAL SURGICAL PRINCIPLE that applies to every operation:\n\n"
 "WARNING: ANTIBIOTIC PROPHYLAXIS MUST TARGET THE MOST LIKELY CONTAMINANT, NOT THE 'STRONGEST' DRUG.\n\n"
 "IN OPEN HEART SURGERY THE INCISION PASSES THROUGH SKIN AND STERNUM. So the most likely contaminant is THE PATIENT'S OWN SKIN FLORA: STAPHYLOCOCCUS AUREUS AND STAPHYLOCOCCUS EPIDERMIDIS.\n\n"
 "AND CEFAZOLIN TARGETS EXACTLY THOSE TWO.\n\n"
 "FOUR PROPERTIES MAKE CEFAZOLIN IDEAL FOR PROPHYLAXIS:\n\n"
 "1. EXCELLENT COVER OF SKIN GRAM-POSITIVES (methicillin-sensitive staph and streptococci)\n"
 "2. A SUITABLE HALF-LIFE — one dose before incision covers the whole operation\n"
 "3. GOOD TISSUE PENETRATION, including into sternal bone\n"
 "4. A NARROW SPECTRUM — less selection pressure and less risk of C. difficile colitis\n\n"
 "WARNING, AND NOW THE KEY PART: WHY NOT CEFTRIAXONE, WHICH SOUNDS 'STRONGER'?\n\n"
 "BECAUSE IT HITS THE WRONG TARGET. Ceftriaxone is third generation, and third generation means BETTER GRAM-NEGATIVE, WEAKER GRAM-POSITIVE. But in CLEAN CARDIAC SURGERY gut gram-negatives are not the issue at all. So a broader spectrum here is NOT AN ADVANTAGE BUT A HARM: it promotes resistance and raises the risk of C. difficile.\n\n"
 "THIS IS ONE OF THE MOST IMPORTANT LESSONS IN ANTIMICROBIAL STEWARDSHIP: 'BROADER' IS NOT 'BETTER'.\n\n"
 "WHY NOT VANCOMYCIN? WARNING, vancomycin substitutes in only three situations: SEVERE BETA-LACTAM ALLERGY, KNOWN MRSA COLONISATION, or HIGH LOCAL MRSA PREVALENCE. Routine use promotes vancomycin resistance, and vancomycin also acts MORE SLOWLY than cefazolin.\n\n"
 "WARNING, AND TWO TIMING POINTS: the dose must be given WITHIN 60 MINUTES BEFORE INCISION, and prophylaxis is usually STOPPED WITHIN 24 HOURS.",
 ["پاسخ صحیح — سفازولین فلور پوست (استاف اورئوس و اپیدرمیدیس) را هدف می‌گیرد و انتخاب استاندارد است.",
  "سفتریاکسون نسل سوم است: پوشش گرم‌مثبت ضعیف‌تر و طیف بی‌جهت وسیع‌تر برای یک جراحی تمیز.",
  "کلیندامایسین جایگزین در آلرژی به بتالاکتام است، نه انتخاب اول پروفیلاکسی جراحی قلب.",
  "وانکومایسین فقط در آلرژی شدید، کلونیزاسیون MRSA یا شیوع بالای MRSA جایگزین می‌شود."],
 ["Correct — cefazolin targets skin flora (Staph aureus and epidermidis) and is the standard choice.",
  "Ceftriaxone is third generation: weaker gram-positive cover and a needlessly broad spectrum for clean surgery.",
  "Clindamycin is an alternative in beta-lactam allergy, not the first choice for cardiac surgical prophylaxis.",
  "Vancomycin substitutes only for severe allergy, known MRSA colonisation, or high local MRSA prevalence."],
 "پروفیلاکسی جراحی = **هدف گرفتن آلاینده‌ی محتمل**، نه وسیع‌ترین دارو. پوست ← **سفازولین**.",
 "Surgical prophylaxis means targeting the likely contaminant, not choosing the broadest drug. Skin means cefazolin.",
 [H142])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book25.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 25 lessons:', len(L))
