# -*- coding: utf-8 -*-
"""Micro-lessons, batch 45 — the helminth block, completing the parasitology chapter.

Twenty-five questions and, with them, the chapter reaches 101 of 101. This is
the second chapter of the book to be finished.

THE ONE TABLE THAT DECIDES ALMOST EVERY QUESTION HERE
-------------------------------------------------------
Persian names appear constantly in this block, so learn both:

    کرم شالقی      whipworm         Trichuris trichiura
    کرم قلاب‌دار     hookworm         Ancylostoma / Necator
    کرمک           pinworm          Enterobius vermicularis
    آسکاریس        roundworm        Ascaris lumbricoides
    استرونژیلوئید   threadworm       Strongyloides stercoralis

    WORM              HALLMARK                           DRUG
    pinworm           NOCTURNAL PERIANAL ITCH            mebendazole or
                      tape test, treat the whole family  albendazole, single
                                                         dose, REPEAT IN 2 WEEKS
    whipworm          RECTAL PROLAPSE, lemon-shaped egg  mebendazole
    hookworm          IRON-DEFICIENCY ANAEMIA            albendazole
    ascaris           BOWEL OBSTRUCTION, biliary /       albendazole (but
                      pancreatic complications           PIPERAZINE if
                                                         obstructed)
    strongyloides     RHABDITIFORM larva in stool,       IVERMECTIN
                      HYPERINFECTION on steroids
    taenia saginata   beef, egg in stool                 praziquantel
    taenia solium     PORK, NEUROCYSTICERCOSIS           praziquantel /
                                                         albendazole
    echinococcus      HYDATID CYST, water-lily sign      albendazole ± PAIR
    fasciola          WATERCRESS, liver tunnels          TRICLABENDAZOLE
    schistosoma       S. haematobium -> URINARY          praziquantel

THREE POINTS THAT DECIDE MORE MARKS THAN THE REST
---------------------------------------------------
1) THE PINWORM QUARTET, asked SIX times in this chapter. Every single item is
   decided by the same four-part answer: TAPE TEST to diagnose, treat THE WHOLE
   FAMILY (not just the child), a SINGLE DOSE, and REPEAT AT TWO WEEKS. That
   repeat is not arbitrary: the drugs kill worms but not eggs, and the eggs in
   the environment take about two weeks to complete a new cycle.

2) ASCARIS OBSTRUCTION IS THE ONE PLACE PIPERAZINE STILL BELONGS. Albendazole
   and mebendazole KILL the worm; a bolus of dead worms in an already obstructed
   bowel can make matters worse. PIPERAZINE PARALYSES the worm flaccidly, so the
   relaxed worm is passed by peristalsis. This is the whole logic of two
   questions.

3) STRONGYLOIDES HYPERINFECTION IS A STEROID DISEASE. Strongyloides is the one
   nematode with an AUTOINFECTION cycle, so it can persist for decades. Give
   corticosteroids and that cycle accelerates catastrophically: larvae swarm
   through the bowel wall carrying gut bacteria with them, producing GRAM-NEGATIVE
   SEPSIS. Recurrent eosinophilia, buttock urticaria (larva currens) and
   epigastric pain in a steroid-treated patient with gram-negative sepsis is the
   examinable picture — and the stool may well be negative.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022) —
intestinal nematodes, cestodes, trematodes and schistosomiasis; WHO guidance on
the management of cystic echinococcosis.
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


HN = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — "
      "intestinal nematodes")
HC = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — "
      "cestodes and trematodes")
WHOE = ("World Health Organization Informal Working Group on Echinococcosis — "
        "expert consensus on the diagnosis and treatment of cystic and "
        "alveolar echinococcosis")
NREFS = [HN]
CREFS = [HC]

# ======================================================= PINWORM: SIX ITEMS
PIN_FA = [
    "⚠️ **خارش شبانه‌ی اطراف مقعد در کودک، تا خلاف آن ثابت نشده یعنی کرمک.**",
    "**کرمک همان انتروبیوس ورمیکولاریس است، و شایع‌ترین کرم روده‌ای در کشورهای معتدل.**",
    "**چرا خارش شب‌ها بدتر می‌شود؟ چون کرم ماده شب‌ها بیرون می‌آید.**",
    "**کرم ماده شبانه از مقعد خارج می‌شود و تخم‌هایش را در پوست اطراف مقعد می‌گذارد.**",
    "**همین حرکت و همین تخم‌ها، خارش شدید شبانه را می‌سازند.**",
    "⚠️ **و چون تخم‌ها روی پوست‌اند نه در مدفوع، آزمایش مدفوع معمولاً منفی است.**",
    "**آزمایش مدفوع فقط در حدود ۵ تا ۱۵ درصد موارد کرمک مثبت می‌شود.**",
    "**پس تست انتخابی، نوار چسب سلوفان (تست اسکاچ) در اطراف مقعد است.**",
    "**نوار باید صبح زود، پیش از اجابت مزاج و پیش از شست‌وشو گذاشته شود.**",
    "**و درمان چهار جزء دارد که همه‌ی سؤال‌های این خوشه را حل می‌کند.**",
    "**یک: مبندازول ۱۰۰ میلی‌گرم تک‌دوز، یا آلبندازول ۴۰۰ میلی‌گرم تک‌دوز.**",
    "⚠️ **دو: تکرار همان دوز دو هفته بعد — و این جزء حیاتی است.**",
    "**سه: درمان همه‌ی اعضای خانواده، حتی آن‌ها که علامت ندارند.**",
    "**چهار: بهداشت — شست‌وشوی ملحفه و لباس زیر، کوتاه نگه داشتن ناخن.**",
    "⚠️ **چرا تکرار دو هفته بعد؟ چون دارو کرم را می‌کشد ولی تخم را نه.**",
    "**تخم‌های موجود در محیط حدود دو هفته طول می‌کشد تا چرخه‌ی جدید را کامل کنند.**",
    "**پس دوز دوم، همان نسل تازه‌ی کرم‌ها را می‌گیرد.**",
    "**و چرا کل خانواده؟ چون تخم‌ها بسیار سبک‌اند و در هوا و ملحفه پخش می‌شوند.**",
    "**اعضای بی‌علامت خانواده مخزن عفونت مجددند و بدون درمان، کودک دوباره آلوده می‌شود.**",
]
PIN_EN = [
    "WARNING: NOCTURNAL PERIANAL ITCH IN A CHILD MEANS PINWORM until proved otherwise.",
    "Pinworm is Enterobius vermicularis, the commonest intestinal worm in temperate countries.",
    "Why is the itch worse at night? Because the female worm emerges at night.",
    "The female migrates out of the anus at night and lays her eggs on the perianal skin.",
    "That movement and those eggs together produce the intense nocturnal itch.",
    "WARNING, AND BECAUSE THE EGGS ARE ON THE SKIN RATHER THAN IN THE STOOL, stool tests are usually negative.",
    "Stool examination is positive in only about 5 to 15% of pinworm cases.",
    "So the test of choice is the CELLOPHANE TAPE (Scotch tape) test on the perianal skin.",
    "The tape must be applied early in the morning, before defaecation and before washing.",
    "And the treatment has four components, which solve every question in this cluster.",
    "ONE: mebendazole 100 mg single dose, or albendazole 400 mg single dose.",
    "WARNING, TWO: REPEAT THE SAME DOSE TWO WEEKS LATER — and this component is vital.",
    "THREE: treat EVERY MEMBER OF THE HOUSEHOLD, even those with no symptoms.",
    "FOUR: hygiene — wash bedding and underwear, keep fingernails short.",
    "WARNING, WHY REPEAT AT TWO WEEKS? Because the drug kills the worms but not the eggs.",
    "Eggs already in the environment take about two weeks to complete a new cycle.",
    "So the second dose catches that fresh generation of worms.",
    "And why the whole family? Because the eggs are very light and disperse into air and bedding.",
    "Asymptomatic family members are a reservoir for reinfection; untreated, the child is reinfected.",
]

add("book:798", "vignette", "easy",
    "**تشخیص کرمک با نوار سلوفان است، نه با آزمایش مدفوع — چون تخم‌ها روی پوست‌اند.**",
    "Pinworm is diagnosed with the cellophane tape test, not stool examination — because the eggs are on the skin.",
    PIN_FA,
    PIN_EN,
    "این سؤال ورودی خوشه‌ی کرمک است و **یک نکته‌ی فیزیولوژیک** را می‌سنجد.\n\n"
    "**بیمار: کودک خردسال با خارش اطراف مقعد که شب‌ها تشدید می‌شود.**\n\n"
    "**این تابلو، تا خلاف آن ثابت نشده، کرمک (انتروبیوس ورمیکولاریس) است.**\n\n"
    "⚠️ **چرا شب‌ها بدتر می‌شود؟ چون کرم ماده شب‌ها از مقعد بیرون می‌آید** و تخم‌هایش را در "
    "چین‌های پوستی اطراف مقعد می‌گذارد. حرکت خود کرم و واکنش به تخم‌ها، خارش شدید می‌سازد.\n\n"
    "**و همین حقیقت، تشخیص را تعیین می‌کند:**\n\n"
    "**تخم‌ها روی پوست‌اند، نه در مدفوع.** پس **آزمایش مدفوع در کرمک معمولاً منفی است** — "
    "حساسیت آن فقط حدود **۵ تا ۱۵ درصد** است. حتی تکرار سه‌باره‌ی آن هم این مشکل بنیادی را "
    "حل نمی‌کند، چون **جای اشتباهی را نگاه می‌کند**.\n\n"
    "**پس تست انتخابی: نوار چسب سلوفان (تست اسکاچ) در اطراف مقعد.** نوار چسب شفاف روی پوست "
    "اطراف مقعد گذاشته و برداشته می‌شود، سپس روی لام چسبانده و زیر میکروسکوپ **تخم‌های بیضی و "
    "یک‌طرف صاف** دیده می‌شوند.\n\n"
    "**نکته‌ی عملی مهم: نوار باید صبح زود، پیش از اجابت مزاج و پیش از شست‌وشو گذاشته شود** — "
    "چون شست‌وشو تخم‌ها را پاک می‌کند و حساسیت تست را از بین می‌برد.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**اسمیر مدفوع یک نوبت** و **اسمیر مدفوع سه نوبت:** هر دو **جای اشتباهی را نگاه می‌کنند**. "
    "سه بار نگاه کردن به جای اشتباه، بهتر از یک بار نیست.\n\n"
    "⚠️ **اسمیر و کشت مدفوع:** **کشت مدفوع برای باکتری است، نه برای انگل.** کرم‌ها در محیط "
    "کشت رشد نمی‌کنند. این گزینه دو اشتباه را با هم دارد.",
    "This question opens the pinworm cluster and tests ONE PHYSIOLOGICAL POINT.\n\n"
    "THE PATIENT: a young child with perianal itching that is worse at night.\n\n"
    "THIS PICTURE IS PINWORM (Enterobius vermicularis) until proved otherwise.\n\n"
    "WARNING, WHY IS IT WORSE AT NIGHT? BECAUSE THE FEMALE WORM EMERGES FROM THE ANUS AT NIGHT and "
    "lays her eggs in the perianal skin folds. The worm's movement and the reaction to the eggs "
    "produce intense itching.\n\n"
    "AND THAT SAME FACT DETERMINES THE DIAGNOSIS:\n\n"
    "THE EGGS ARE ON THE SKIN, NOT IN THE STOOL. So STOOL EXAMINATION IN PINWORM IS USUALLY NEGATIVE — "
    "its sensitivity is only about 5 to 15%. Even repeating it three times does not solve this "
    "fundamental problem, because IT IS LOOKING IN THE WRONG PLACE.\n\n"
    "SO THE TEST OF CHOICE: THE CELLOPHANE TAPE (Scotch tape) TEST on the perianal skin. Clear tape is "
    "applied to and lifted from the perianal skin, then stuck to a slide, and under the microscope the "
    "OVAL EGGS WITH ONE FLATTENED SIDE are seen.\n\n"
    "AN IMPORTANT PRACTICAL POINT: THE TAPE MUST BE APPLIED EARLY IN THE MORNING, BEFORE DEFAECATION "
    "AND BEFORE WASHING — because washing removes the eggs and destroys the test's sensitivity.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "A SINGLE STOOL SMEAR and THREE STOOL SMEARS: both LOOK IN THE WRONG PLACE. Looking three times in "
    "the wrong place is no better than looking once.\n\n"
    "WARNING, STOOL SMEAR AND CULTURE: STOOL CULTURE IS FOR BACTERIA, NOT PARASITES. Worms do not grow "
    "in culture media. This option contains two mistakes at once.",
    ["جای اشتباهی را نگاه می‌کند؛ تخم‌های کرمک روی پوست‌اند نه در مدفوع.",
     "سه بار نگاه کردن به جای اشتباه، بهتر از یک بار نیست؛ حساسیت همچنان بسیار پایین است.",
     "دو اشتباه با هم — جای اشتباه، و کشت که برای باکتری است نه انگل.",
     "پاسخ صحیح — نوار سلوفان تخم‌های چسبیده به پوست اطراف مقعد را برمی‌دارد."],
    ["Looks in the wrong place; pinworm eggs are on the skin, not in the stool.",
     "Looking three times in the wrong place is no better than once; sensitivity stays very low.",
     "Two mistakes at once — the wrong place, and a culture that is for bacteria not parasites.",
     "Correct — the cellophane tape lifts the eggs adhering to the perianal skin."],
    "**تخم‌های کرمک روی پوست‌اند، نه در مدفوع — پس نوار چسب، نه آزمایش مدفوع.**",
    "Pinworm eggs are on the skin, not in the stool — so tape, not stool examination.",
    NREFS)

add("book:800", "recall", "medium",
    "**آزمایش مستقیم مدفوع کمترین کمک را می‌کند — سه گزینه‌ی دیگر همگی اجزای درمان درست‌اند.**",
    "Direct stool examination helps least — the other three are all components of correct management.",
    PIN_FA,
    PIN_EN,
    "این سؤال از نوع «کدام کمتر کمک‌کننده است» و **همان قاعده‌ی قبلی را از زاویه‌ی دیگری "
    "می‌سنجد**.\n\n"
    "**بیمار: کودکی که شب‌ها دچار خارش مقعد می‌شود** — یعنی کرمک.\n\n"
    "**سه گزینه‌ای که واقعاً کمک می‌کنند:**\n\n"
    "**درمان سایر اعضای خانواده بدون علامت** — این **قطعاً کمک می‌کند** و بسیار مهم است. "
    "تخم‌های کرمک **بسیار سبک‌اند** و در هوا، ملحفه و لباس پخش می‌شوند. اعضای بی‌علامت خانواده "
    "**مخزن عفونت مجدد**اند. اگر فقط کودک درمان شود، **ظرف چند هفته دوباره آلوده می‌شود**.\n\n"
    "**درمان بیمار با مبندازول** — درمان استاندارد. مبندازول ۱۰۰ میلی‌گرم تک‌دوز.\n\n"
    "⚠️ **تکرار درمان قبلی دو هفته بعد** — این **جزء حیاتی** درمان است. **دارو کرم بالغ را "
    "می‌کشد ولی تخم را نه.** تخم‌های موجود در محیط حدود دو هفته طول می‌کشد تا به کرم بالغ "
    "تبدیل شوند. **دوز دوم دقیقاً همان نسل تازه را می‌گیرد.** بدون آن، عود بسیار شایع است.\n\n"
    "**و گزینه‌ی چهارم: آزمایش مستقیم مدفوع برای انگل.**\n\n"
    "⚠️ **چرا کمترین کمک را می‌کند؟** چون **تخم‌های کرمک در مدفوع نیستند، روی پوست اطراف "
    "مقعد**اند. حساسیت آزمایش مدفوع در کرمک فقط **۵ تا ۱۵ درصد** است. **یک نتیجه‌ی منفی، هیچ "
    "چیزی را رد نمی‌کند** — پس آزمونی که نه می‌تواند تأیید کند و نه رد، کمترین ارزش را دارد.\n\n"
    "**نکته‌ی روش‌شناختی: توجه کنید که سؤال «کمتر کمک‌کننده» را پرسیده، نه «غلط».** "
    "آزمایش مدفوع **غلط نیست** — ممکن است انگل دیگری را پیدا کند. ولی **برای این تشخیص "
    "خاص، کم‌ارزش‌ترین گزینه** است.",
    "This is a 'which helps least' question and it TESTS THE SAME RULE FROM ANOTHER ANGLE.\n\n"
    "THE PATIENT: a child with nocturnal perianal itching — that is, pinworm.\n\n"
    "THE THREE OPTIONS THAT GENUINELY HELP:\n\n"
    "TREATING ASYMPTOMATIC FAMILY MEMBERS — this DEFINITELY HELPS and is very important. Pinworm eggs "
    "are VERY LIGHT and disperse into the air, the bedding and the clothing. Asymptomatic household "
    "members are A RESERVOIR FOR REINFECTION. If only the child is treated, HE IS REINFECTED WITHIN "
    "WEEKS.\n\n"
    "TREATING THE PATIENT WITH MEBENDAZOLE — the standard treatment. Mebendazole 100 mg single dose.\n\n"
    "WARNING, REPEATING THE TREATMENT TWO WEEKS LATER — this is A VITAL COMPONENT. THE DRUG KILLS THE "
    "ADULT WORM BUT NOT THE EGGS. Eggs in the environment take about two weeks to become adult worms. "
    "THE SECOND DOSE CATCHES EXACTLY THAT NEW GENERATION. Without it relapse is very common.\n\n"
    "AND THE FOURTH OPTION: DIRECT STOOL EXAMINATION FOR PARASITES.\n\n"
    "WARNING, WHY DOES IT HELP LEAST? Because PINWORM EGGS ARE NOT IN THE STOOL, THEY ARE ON THE "
    "PERIANAL SKIN. Stool sensitivity in pinworm is only 5 to 15%. A NEGATIVE RESULT EXCLUDES NOTHING "
    "— so a test that can neither confirm nor exclude has the least value.\n\n"
    "A METHODOLOGICAL NOTE: notice that the question asks 'helps LESS', not 'is WRONG'. Stool "
    "examination IS NOT WRONG — it might find another parasite. But FOR THIS PARTICULAR DIAGNOSIS IT "
    "IS THE LEAST VALUABLE OPTION.",
    ["قطعاً کمک می‌کند — اعضای بی‌علامت خانواده مخزن عفونت مجددند.",
     "درمان استاندارد کرمک است؛ مبندازول تک‌دوز.",
     "جزء حیاتی درمان — دارو کرم را می‌کشد ولی تخم را نه، پس دوز دوم نسل تازه را می‌گیرد.",
     "پاسخ صحیح — تخم‌ها روی پوست‌اند نه در مدفوع، پس حساسیت آزمایش مدفوع فقط ۵ تا ۱۵ درصد است."],
    ["It definitely helps — asymptomatic family members are a reservoir for reinfection.",
     "The standard pinworm treatment; a single dose of mebendazole.",
     "A vital component — the drug kills worms but not eggs, so the second dose catches the new generation.",
     "Correct — the eggs are on the skin not in the stool, so stool sensitivity is only 5 to 15%."],
    "**آزمونی که نه تأیید می‌کند نه رد، کم‌ارزش‌ترین است.**",
    "A test that can neither confirm nor exclude is the least valuable.",
    NREFS)

add("book:801", "vignette", "medium",
    "**درمان کرمک چهار جزء دارد، و تنها گزینه‌ای که همه را دارد پاسخ است: خانواده + تک‌دوز + تکرار.**",
    "Pinworm management has four components, and the only option carrying them all is the answer: family, single dose, repeat.",
    PIN_FA,
    PIN_EN,
    "این سؤال **مهم‌ترین سؤال خوشه‌ی کرمک** است، چون **هر سه جزء درمانی را هم‌زمان** می‌سنجد.\n\n"
    "**بیمار: پسربچه‌ی شش ساله با خارش اطراف مقعد که شب‌ها تشدید می‌شود** — کرمک.\n\n"
    "**سه محور تصمیم:**\n\n"
    "**محور یک — چه کسی درمان شود؟** ⚠️ **کل خانواده، نه فقط کودک.** تخم‌های کرمک بسیار "
    "سبک‌اند و در ملحفه، لباس و هوا پخش می‌شوند. اعضای بی‌علامت **مخزن عفونت مجدد**اند. اگر "
    "فقط کودک درمان شود، ظرف چند هفته دوباره آلوده می‌شود.\n\n"
    "**محور دو — چه دوزی؟** **تک‌دوز.** مبندازول ۱۰۰ میلی‌گرم تک‌دوز کافی است. **دوره‌ی "
    "روزانه‌ی دو هفته‌ای اضافی و بی‌مورد است** — نه کارایی بیشتری دارد، نه عوارض کمتری.\n\n"
    "⚠️ **محور سه — تکرار؟ بله، دو هفته بعد.** این جزء حیاتی است. **دارو کرم بالغ را می‌کشد "
    "ولی تخم را نه.** تخم‌های موجود در محیط حدود دو هفته طول می‌کشد تا نسل جدیدی از کرم بالغ "
    "بسازند. دوز دوم دقیقاً همان نسل را می‌گیرد.\n\n"
    "**پس تنها گزینه‌ای که هر سه را دارد: «درمان بیمار و خانواده‌ی وی با مبندازول ۱۰۰ "
    "میلی‌گرم تک‌دوز و تکرار درمان دو هفته بعد.»**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟ هر کدام دقیقاً یک یا دو جزء را از دست داده‌اند:**\n\n"
    "**«مبندازول ۱۰۰ روزانه دو هفته، فقط بیمار»:** **دو ایراد** — خانواده درمان نمی‌شود، و "
    "رژیم دوهفته‌ای بی‌مورد است (به‌جای تک‌دوز + تکرار).\n\n"
    "**«مبندازول تک‌دوز و تکرار دو هفته بعد، فقط بیمار»:** دوز و تکرار درست‌اند، ولی "
    "**خانواده درمان نمی‌شود** — پس کودک از همان اعضای بی‌علامت دوباره آلوده می‌شود.\n\n"
    "**«بیمار و خانواده، ۱۰۰ روزانه دو هفته»:** خانواده درست، ولی **تکرار دو هفته بعد "
    "حذف شده** و رژیم روزانه‌ی دوهفته‌ای هم استاندارد نیست.\n\n"
    "**و جزء چهارم که سؤال نپرسیده ولی در عمل حیاتی است: بهداشت.** شست‌وشوی داغ ملحفه و "
    "لباس زیر، کوتاه نگه داشتن ناخن‌ها، و شست‌وشوی دست‌ها پس از اجابت مزاج و پیش از غذا.",
    "This is THE MOST IMPORTANT QUESTION IN THE PINWORM CLUSTER, because it tests ALL THREE MANAGEMENT "
    "COMPONENTS AT ONCE.\n\n"
    "THE PATIENT: a six-year-old boy with perianal itching worse at night — pinworm.\n\n"
    "THREE DECISION AXES:\n\n"
    "AXIS ONE — WHO IS TREATED? WARNING, THE WHOLE FAMILY, NOT JUST THE CHILD. Pinworm eggs are very "
    "light and disperse into bedding, clothing and air. Asymptomatic members are A REINFECTION "
    "RESERVOIR. If only the child is treated he is reinfected within weeks.\n\n"
    "AXIS TWO — WHAT DOSE? A SINGLE DOSE. Mebendazole 100 mg once is sufficient. A DAILY TWO-WEEK "
    "COURSE IS SUPERFLUOUS — no more effective and no less toxic.\n\n"
    "WARNING, AXIS THREE — REPEAT? YES, AT TWO WEEKS. This component is vital. THE DRUG KILLS THE ADULT "
    "WORM BUT NOT THE EGGS. Eggs in the environment take about two weeks to produce a new generation "
    "of adults. The second dose catches exactly that generation.\n\n"
    "SO THE ONLY OPTION WITH ALL THREE: 'treat the patient AND HIS FAMILY with mebendazole 100 mg as a "
    "SINGLE DOSE and REPEAT the treatment two weeks later.'\n\n"
    "WHY ARE THE OTHER THREE REJECTED? Each has lost exactly one or two components:\n\n"
    "'MEBENDAZOLE 100 mg DAILY FOR TWO WEEKS, PATIENT ONLY': TWO FAULTS — the family is untreated, and "
    "the two-week regimen is unnecessary (instead of single dose plus repeat).\n\n"
    "'MEBENDAZOLE SINGLE DOSE AND REPEAT AT TWO WEEKS, PATIENT ONLY': the dose and repeat are right, "
    "but THE FAMILY IS UNTREATED — so the child is reinfected from those same asymptomatic members.\n\n"
    "'PATIENT AND FAMILY, 100 mg DAILY FOR TWO WEEKS': the family part is right, but THE TWO-WEEK "
    "REPEAT IS OMITTED and the daily two-week regimen is not standard either.\n\n"
    "AND THE FOURTH COMPONENT THE QUESTION DID NOT ASK BUT WHICH IS VITAL IN PRACTICE: HYGIENE. Hot "
    "washing of bedding and underwear, keeping fingernails short, and handwashing after defaecation "
    "and before meals.",
    ["دو ایراد — خانواده درمان نمی‌شود، و رژیم روزانه‌ی دوهفته‌ای به‌جای تک‌دوز و تکرار بی‌مورد است.",
     "دوز و تکرار درست‌اند ولی خانواده درمان نمی‌شود، پس کودک دوباره آلوده می‌شود.",
     "خانواده درست است ولی تکرار دو هفته بعد حذف شده و رژیم روزانه استاندارد نیست.",
     "پاسخ صحیح — خانواده به‌علاوه‌ی تک‌دوز به‌علاوه‌ی تکرار دو هفته بعد؛ هر سه جزء."],
    ["Two faults — the family is untreated, and a daily two-week course replaces single dose plus repeat.",
     "The dose and repeat are right but the family is untreated, so the child is reinfected.",
     "The family part is right but the two-week repeat is omitted and the daily regimen is not standard.",
     "Correct — family plus single dose plus repeat at two weeks; all three components."],
    "**خانواده + تک‌دوز + تکرار دو هفته بعد — هر سه، وگرنه عود.**",
    "Family plus single dose plus repeat at two weeks — all three, or it relapses.",
    NREFS)

add("book:804", "vignette", "easy",
    "**آلبندازول برای کودک و همه‌ی خانواده، و تکرار دو هفته بعد — همان چهارگانه با داروی دیگر.**",
    "Albendazole for the child and the whole family, repeated at two weeks — the same quartet with a different drug.",
    PIN_FA + [
        "**آلبندازول و مبندازول در کرمک عملاً هم‌ارزند.**",
        "**آلبندازول ۴۰۰ میلی‌گرم تک‌دوز؛ مبندازول ۱۰۰ میلی‌گرم تک‌دوز.**",
        "⚠️ **پس انتخاب میان این دو، پاسخ سؤال را تعیین نمی‌کند.**",
        "**آنچه پاسخ را تعیین می‌کند، «همه‌ی خانواده» و «تکرار دو هفته بعد» است.**",
        "**پیرانتل پاموآت هم گزینه‌ی معتبری است، به‌ویژه در بارداری.**",
    ],
    PIN_EN + [
        "Albendazole and mebendazole are effectively equivalent in pinworm.",
        "Albendazole 400 mg single dose; mebendazole 100 mg single dose.",
        "WARNING, SO THE CHOICE BETWEEN THEM does not decide the answer.",
        "What decides the answer is 'the whole family' and 'repeat at two weeks'.",
        "Pyrantel pamoate is also a valid option, particularly in pregnancy.",
    ],
    "کتاب همان قاعده را با **داروی دیگری** پرسیده — و این نشان می‌دهد که **انتخاب دارو "
    "محور نیست، بلکه راهبرد درمان محور است**.\n\n"
    "**بیمار: کودک ۵ ساله با خارش شبانه‌ی مقعد** — کرمک.\n\n"
    "⚠️ **آلبندازول و مبندازول در کرمک عملاً هم‌ارزند:** آلبندازول ۴۰۰ میلی‌گرم تک‌دوز، "
    "مبندازول ۱۰۰ میلی‌گرم تک‌دوز. **پیرانتل پاموآت** هم گزینه‌ی معتبری است (و در **بارداری** "
    "ارجح است).\n\n"
    "**پس آنچه پاسخ را تعیین می‌کند، دارو نیست — بلکه دو چیز است:**\n\n"
    "**یک: درمان کودک و همه‌ی اعضای خانواده.**\n\n"
    "**دو: تکرار دارو دو هفته بعد.**\n\n"
    "**و گزینه‌ی دوم دقیقاً هر دو را دارد: «آلبندازول جهت کودک و اعضای خانواده و تکرار دارو "
    "دو هفته بعد.»**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "⚠️ **«مبندازول جهت کودک و درمان خانواده در صورت وجود علامت»:** داروی درستی است، ولی "
    "**شرط «در صورت وجود علامت» آن را خراب می‌کند**. **بیشتر اعضای آلوده‌ی خانواده بی‌علامت‌اند** "
    "و دقیقاً همان‌ها مخزن عفونت مجددند. اگر منتظر علامت بمانیم، هرگز درمانشان نمی‌کنیم و "
    "کودک دوباره آلوده می‌شود.\n\n"
    "**«آزمایش مدفوع و داروی ضدخارش»:** **دو اشتباه**. یک: آزمایش مدفوع در کرمک حساسیت "
    "بسیار پایینی دارد. دو: **داروی ضدخارش علامت را می‌پوشاند و عامل را درمان نمی‌کند** — "
    "کرم‌ها همچنان تخم می‌گذارند و بقیه را آلوده می‌کنند.\n\n"
    "**«اسمیر و کشت مدفوع و پیرانتل پاموآت»:** پیرانتل پاموآت داروی درستی است، ولی "
    "**کشت مدفوع برای باکتری است نه انگل**، و مهم‌تر: **درمان خانواده و تکرار دو هفته بعد "
    "هر دو حذف شده‌اند**.",
    "The book asks the same rule with A DIFFERENT DRUG — showing that THE DRUG CHOICE IS NOT THE "
    "POINT; THE MANAGEMENT STRATEGY IS.\n\n"
    "THE PATIENT: a 5-year-old child with nocturnal perianal itching — pinworm.\n\n"
    "WARNING, ALBENDAZOLE AND MEBENDAZOLE ARE EFFECTIVELY EQUIVALENT IN PINWORM: albendazole 400 mg "
    "single dose, mebendazole 100 mg single dose. PYRANTEL PAMOATE is also valid (and is preferred IN "
    "PREGNANCY).\n\n"
    "SO WHAT DECIDES THE ANSWER IS NOT THE DRUG BUT TWO THINGS:\n\n"
    "ONE: TREATING THE CHILD AND EVERY FAMILY MEMBER.\n\n"
    "TWO: REPEATING THE DRUG AT TWO WEEKS.\n\n"
    "AND THE SECOND OPTION HAS EXACTLY BOTH: 'albendazole for the child and the family members, with "
    "the drug repeated two weeks later.'\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "WARNING, 'MEBENDAZOLE FOR THE CHILD AND TREAT THE FAMILY IF SYMPTOMATIC': the drug is right, but "
    "THE CONDITION 'IF SYMPTOMATIC' RUINS IT. MOST INFECTED FAMILY MEMBERS ARE ASYMPTOMATIC and they "
    "are precisely the reinfection reservoir. If we wait for symptoms we never treat them and the "
    "child is reinfected.\n\n"
    "'STOOL EXAMINATION AND AN ANTIPRURITIC': TWO MISTAKES. One: stool examination has very low "
    "sensitivity in pinworm. Two: AN ANTIPRURITIC MASKS THE SYMPTOM WITHOUT TREATING THE CAUSE — the "
    "worms go on laying eggs and infecting others.\n\n"
    "'STOOL SMEAR AND CULTURE AND PYRANTEL PAMOATE': pyrantel pamoate is a correct drug, but STOOL "
    "CULTURE IS FOR BACTERIA NOT PARASITES, and more importantly BOTH FAMILY TREATMENT AND THE "
    "TWO-WEEK REPEAT ARE OMITTED.",
    ["داروی درستی است ولی شرط «در صورت علامت» آن را خراب می‌کند؛ بیشتر آلوده‌ها بی‌علامت‌اند.",
     "پاسخ صحیح — کودک و کل خانواده، و تکرار دارو دو هفته بعد.",
     "دو اشتباه — حساسیت پایین آزمایش مدفوع، و داروی ضدخارش که علامت را می‌پوشاند نه عامل را.",
     "پیرانتل درست است ولی کشت برای باکتری است، و درمان خانواده و تکرار هر دو حذف شده‌اند."],
    ["A correct drug, but 'if symptomatic' ruins it; most infected members are asymptomatic.",
     "Correct — the child and the whole family, with the drug repeated at two weeks.",
     "Two mistakes — low stool sensitivity, and an antipruritic that masks the symptom rather than the cause.",
     "Pyrantel is right but culture is for bacteria, and both family treatment and the repeat are omitted."],
    "**«در صورت وجود علامت» غلط است — بیشتر آلوده‌های خانواده بی‌علامت‌اند.**",
    "'If symptomatic' is wrong — most infected family members are asymptomatic.",
    NREFS)

add("book:805", "vignette", "medium",
    "**تخم بیضی نماتود در نوار سلوفان: آلبندازول تک‌دوز برای بیمار و خانواده، با تکرار دو هفته بعد.**",
    "An oval nematode egg on the tape test: single-dose albendazole for patient and family, repeated at two weeks.",
    PIN_FA + [
        "**اینجا تشخیص از قبل با نوار سلوفان قطعی شده است.**",
        "**تخم بیضی نماتود در ناحیه‌ی پرینه یعنی کرمک.**",
        "⚠️ **پس سؤال فقط درباره‌ی درمان است، نه تشخیص.**",
        "**و باز هم همان دو محور تعیین‌کننده: خانواده، و تکرار.**",
        "**نوجوان ۱۳ ساله هم همان درمان بزرگ‌سالان را می‌گیرد.**",
    ],
    PIN_EN + [
        "Here the diagnosis has already been settled by the tape test.",
        "An oval nematode egg in the perineal region means pinworm.",
        "WARNING, SO THE QUESTION IS ONLY ABOUT TREATMENT, not diagnosis.",
        "And again the same two decisive axes: the family, and the repeat.",
        "A 13-year-old receives the same treatment as an adult.",
    ],
    "این سؤال **تشخیص را از قبل داده** و فقط درمان را می‌خواهد — پس مستقیماً روی همان "
    "چهارگانه تمرکز کنید.\n\n"
    "**بیمار: نوجوان ۱۳ ساله با خارش شبانه‌ی مقعد. در تست نوار سلوفان ناحیه‌ی پرینه، تخم "
    "بیضی‌شکل نماتود با اندازه‌ی حدود ۲۵ میکرومتر دیده شده.**\n\n"
    "**تشخیص قطعی است: کرمک (انتروبیوس ورمیکولاریس).**\n\n"
    "**پس سؤال فقط درباره‌ی درمان است، و همان دو محور همیشگی تعیین‌کننده‌اند:**\n\n"
    "⚠️ **محور یک: درمان بیمار و خانواده.** محور دو: **تکرار دو هفته بعد.**\n\n"
    "**و گزینه‌ی سوم دقیقاً هر دو را دارد: «آلبندازول ۴۰۰ میلی‌گرم تک‌دوز برای بیمار و "
    "خانواده‌ی وی و تکرار درمان دو هفته بعد.»**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟ باز هم هر کدام یک یا دو جزء را از دست داده‌اند:**\n\n"
    "**«آلبندازول ۴۰۰ برای مدت یک هفته، بیمار و خانواده»:** خانواده درست است، ولی **رژیم "
    "یک‌هفته‌ای بی‌مورد است** (تک‌دوز کافی است) و **تکرار دو هفته بعد حذف شده**.\n\n"
    "**«مبندازول ۱۰۰ تک‌دوز برای بیمار»:** دوز و دارو درست‌اند، ولی **دو جزء حذف شده‌اند** — "
    "نه خانواده درمان می‌شود و نه تکرار انجام می‌گیرد. **این ناقص‌ترین گزینه است.**\n\n"
    "**«مبندازول ۱۰۰ به مدت ۳ روز برای بیمار و خانواده»:** خانواده درست است، ولی رژیم "
    "سه‌روزه استاندارد نیست و **باز هم تکرار دو هفته بعد حذف شده**.\n\n"
    "⚠️ **پیام تکرارشونده‌ی این خوشه: کتاب شش بار کرمک پرسیده، و هر بار پاسخ همان چهارگانه "
    "است — نوار سلوفان برای تشخیص، تک‌دوز، کل خانواده، و تکرار دو هفته بعد. یک بار درست یاد "
    "بگیرید و هر شش نمره را ببرید.**",
    "This question HAS ALREADY GIVEN THE DIAGNOSIS and asks only about treatment — so focus straight "
    "on the same quartet.\n\n"
    "THE PATIENT: a 13-year-old with nocturnal perianal itching. The perineal tape test shows an oval "
    "nematode egg about 25 micrometres across.\n\n"
    "THE DIAGNOSIS IS CERTAIN: PINWORM (Enterobius vermicularis).\n\n"
    "SO THE QUESTION IS ONLY ABOUT TREATMENT, AND THE SAME TWO AXES DECIDE IT:\n\n"
    "WARNING, AXIS ONE: TREAT THE PATIENT AND THE FAMILY. Axis two: REPEAT AT TWO WEEKS.\n\n"
    "AND THE THIRD OPTION HAS EXACTLY BOTH: 'albendazole 400 mg single dose for the patient and his "
    "family, with treatment repeated two weeks later.'\n\n"
    "WHY ARE THE OTHER THREE REJECTED? Again each has lost one or two components:\n\n"
    "'ALBENDAZOLE 400 mg FOR ONE WEEK, PATIENT AND FAMILY': the family part is right, but THE "
    "ONE-WEEK COURSE IS UNNECESSARY (a single dose suffices) and THE TWO-WEEK REPEAT IS OMITTED.\n\n"
    "'MEBENDAZOLE 100 mg SINGLE DOSE FOR THE PATIENT': the dose and drug are right, but TWO "
    "COMPONENTS ARE MISSING — neither the family is treated nor is the dose repeated. THIS IS THE MOST "
    "INCOMPLETE OPTION.\n\n"
    "'MEBENDAZOLE 100 mg FOR 3 DAYS FOR PATIENT AND FAMILY': the family part is right, but a "
    "three-day regimen is not standard and AGAIN THE TWO-WEEK REPEAT IS OMITTED.\n\n"
    "WARNING, THE RECURRING MESSAGE OF THIS CLUSTER: the book asks pinworm SIX TIMES, and every time "
    "the answer is the same quartet — tape test to diagnose, single dose, the whole family, and repeat "
    "at two weeks. Learn it properly once and take all six marks.",
    ["خانواده درست است ولی رژیم یک‌هفته‌ای بی‌مورد است و تکرار دو هفته بعد حذف شده.",
     "دارو و دوز درست‌اند ولی نه خانواده درمان می‌شود و نه تکرار انجام می‌گیرد؛ ناقص‌ترین گزینه.",
     "پاسخ صحیح — تک‌دوز برای بیمار و خانواده، با تکرار دو هفته بعد.",
     "خانواده درست است ولی رژیم سه‌روزه استاندارد نیست و تکرار دو هفته بعد حذف شده."],
    ["The family part is right but a one-week course is unnecessary and the two-week repeat is omitted.",
     "The drug and dose are right but neither the family is treated nor the dose repeated; the most incomplete option.",
     "Correct — a single dose for the patient and family, repeated at two weeks.",
     "The family part is right but a three-day course is not standard and the two-week repeat is omitted."],
    "**همان چهارگانه، ششمین بار: نوار · تک‌دوز · کل خانواده · تکرار دو هفته بعد.**",
    "The same quartet for the sixth time: tape, single dose, whole family, repeat at two weeks.",
    NREFS)

add("book:806", "recall", "medium",
    "**«بررسی همه‌ی افراد خانواده» نادرست نیست، ولی کافی هم نیست — همه باید درمان شوند، نه بررسی.**",
    "'Screening every family member' is not wrong, but it is not enough — everyone must be TREATED, not screened.",
    PIN_FA + [
        "**این سؤال از نوع «به‌جز» است و ظریف‌ترین سؤال خوشه‌ی کرمک.**",
        "**سه گزینه‌ی دیگر همگی اجزای قطعی درمان‌اند.**",
        "⚠️ **و گزینه‌ی «بررسی همه‌ی افراد خانواده» دقیقاً همان‌جا می‌لنگد.**",
        "**چون توصیه‌ی درست «درمان همه‌ی افراد خانواده» است، نه «بررسی» آن‌ها.**",
        "**و دلیلش همان حساسیت پایین آزمایش‌هاست.**",
        "**اگر عضوی از خانواده را بررسی کنیم و منفی شود، عفونت را رد نکرده‌ایم.**",
        "**پس بررسی، تصمیم درمان را بهتر نمی‌کند و فقط تأخیر می‌اندازد.**",
        "⚠️ **در کرمک، درمان تجربی همه‌ی خانواده استاندارد است.**",
    ],
    PIN_EN + [
        "This is an 'except' question and the subtlest in the pinworm cluster.",
        "The other three options are all definite components of management.",
        "WARNING, AND THE OPTION 'SCREEN EVERY FAMILY MEMBER' fails precisely there.",
        "Because the correct advice is TREAT every family member, not SCREEN them.",
        "And the reason is the same low sensitivity of the tests.",
        "If we screen a family member and the result is negative, we have not excluded infection.",
        "So screening does not improve the treatment decision; it only delays it.",
        "WARNING, IN PINWORM, EMPIRICAL TREATMENT OF THE WHOLE FAMILY IS STANDARD.",
    ],
    "این **ظریف‌ترین سؤال خوشه‌ی کرمک** است، چون گزینه‌ی نادرست **کاملاً غلط نیست** — فقط "
    "**دقیقاً درست نیست**.\n\n"
    "**بیمار: کودک ۷ ساله با خارش شبانه‌ی اطراف مقعد. آزمایش مدفوع نرمال بوده و تشخیص با "
    "نوار استات‌سلولز داده شده** — یعنی کرمک، و توجه کنید که **آزمایش مدفوع منفی بود** که "
    "خودش الگوی کلاسیک کرمک است.\n\n"
    "**سه گزینه‌ای که قطعاً درست‌اند:**\n\n"
    "**تجویز یک دوز مبندازول** — تک‌دوز، درمان استاندارد.\n\n"
    "**تکرار مبندازول دو هفته بعد** — جزء حیاتی، برای گرفتن نسل تازه‌ای که از تخم‌های محیطی "
    "می‌آید.\n\n"
    "**درمان سایر افراد خانواده** — قطعاً درست، چون بی‌علامت‌ها مخزن عفونت مجددند.\n\n"
    "⚠️ **و گزینه‌ی چهارم: «بررسی همه‌ی افراد خانواده از نظر بیماری».**\n\n"
    "**چرا این استثناست؟** چون **توصیه‌ی استاندارد «درمان» همه‌ی افراد خانواده است، نه "
    "«بررسی» آن‌ها.**\n\n"
    "**و دلیلش دو چیز است:**\n\n"
    "**یک — حساسیت پایین آزمون.** اگر عضوی از خانواده را با نوار سلوفان بررسی کنیم و منفی "
    "شود، **عفونت را رد نکرده‌ایم**. حتی نوار سلوفان هم در یک نوبت حساسیت کامل ندارد (نیاز "
    "به سه نوبت در روزهای متوالی دارد). پس **یک بررسی منفی، تصمیم ما را عوض نمی‌کند** — "
    "همچنان باید درمان کنیم.\n\n"
    "**دو — نسبت هزینه به فایده.** آزمونی که نتیجه‌اش تصمیم را عوض نمی‌کند، ارزش انجام دادن "
    "ندارد. **درمان تجربی همه‌ی اعضای خانواده ساده‌تر، ارزان‌تر و مؤثرتر است**، و داروها "
    "(مبندازول، آلبندازول، پیرانتل) عوارض بسیار کمی دارند.\n\n"
    "**پس در کرمک، قاعده این است: بررسی نکنید، درمان کنید.**\n\n"
    "**نکته‌ی روش‌شناختی: در سؤال‌های «به‌جز»، گاهی گزینه‌ی نادرست چیزی است که «کاملاً غلط "
    "نیست ولی توصیه‌ی استاندارد نیست». به عبارت‌های دقیق گزینه‌ها توجه کنید: «بررسی» با "
    "«درمان» فرق دارد.**",
    "This is THE SUBTLEST QUESTION IN THE PINWORM CLUSTER, because the wrong option IS NOT COMPLETELY "
    "WRONG — it is merely NOT EXACTLY RIGHT.\n\n"
    "THE PATIENT: a 7-year-old with nocturnal perianal itching. The stool examination was normal and "
    "the diagnosis was made with the cellulose acetate tape — pinworm, and note that THE STOOL WAS "
    "NEGATIVE, which is itself the classic pinworm pattern.\n\n"
    "THE THREE OPTIONS THAT ARE DEFINITELY CORRECT:\n\n"
    "GIVING ONE DOSE OF MEBENDAZOLE — a single dose, the standard treatment.\n\n"
    "REPEATING THE MEBENDAZOLE AT TWO WEEKS — the vital component, to catch the new generation coming "
    "from environmental eggs.\n\n"
    "TREATING THE OTHER FAMILY MEMBERS — definitely right, because asymptomatic members are a "
    "reinfection reservoir.\n\n"
    "WARNING, AND THE FOURTH OPTION: 'SCREENING EVERY FAMILY MEMBER FOR THE DISEASE.'\n\n"
    "WHY IS THIS THE EXCEPTION? Because THE STANDARD ADVICE IS TO TREAT every family member, NOT TO "
    "SCREEN them.\n\n"
    "AND THERE ARE TWO REASONS:\n\n"
    "ONE — LOW TEST SENSITIVITY. If we screen a family member with the tape test and it is negative, "
    "WE HAVE NOT EXCLUDED INFECTION. Even the tape test is not fully sensitive on a single occasion "
    "(it needs three consecutive mornings). So A NEGATIVE SCREEN DOES NOT CHANGE OUR DECISION — we "
    "must still treat.\n\n"
    "TWO — COST AND BENEFIT. A test whose result does not change the decision is not worth doing. "
    "EMPIRICAL TREATMENT OF THE WHOLE FAMILY IS SIMPLER, CHEAPER AND MORE EFFECTIVE, and the drugs "
    "(mebendazole, albendazole, pyrantel) have very few side effects.\n\n"
    "SO IN PINWORM THE RULE IS: DO NOT SCREEN, TREAT.\n\n"
    "A METHODOLOGICAL NOTE: in 'except' questions the wrong option is sometimes something that IS NOT "
    "COMPLETELY WRONG BUT IS NOT THE STANDARD ADVICE. Read the exact wording: 'SCREEN' is not 'TREAT'.",
    ["پاسخ صحیح — توصیه‌ی استاندارد درمان همه‌ی افراد خانواده است، نه بررسی آن‌ها.",
     "درست است — مبندازول تک‌دوز، درمان استاندارد کرمک.",
     "درست است — تکرار دو هفته بعد نسل تازه‌ی برخاسته از تخم‌های محیطی را می‌گیرد.",
     "درست است — اعضای بی‌علامت خانواده مخزن عفونت مجددند و باید درمان شوند."],
    ["Correct — the standard advice is to TREAT every family member, not to screen them.",
     "Correct — mebendazole single dose, the standard pinworm treatment.",
     "Correct — repeating at two weeks catches the new generation arising from environmental eggs.",
     "Correct — asymptomatic family members are a reinfection reservoir and must be treated."],
    "**در کرمک: بررسی نکنید، درمان کنید — چون بررسی منفی تصمیم را عوض نمی‌کند.**",
    "In pinworm: do not screen, treat — because a negative screen does not change the decision.",
    NREFS)

# ================================================ WHIPWORM AND HOOKWORM
WH_FA = [
    "⚠️ **پرولاپس رکتوم در کودک = کرم شالقی (تریکوریس تریکیورا).**",
    "**چرا؟ چون کرم شالقی در رکتوم و کولون دیستال می‌نشیند.**",
    "**آلودگی شدید باعث زور زدن مداوم (تنسموس) و التهاب مخاط می‌شود.**",
    "**و زور زدن مداوم در کودکِ دچار سوءتغذیه، رکتوم را بیرون می‌اندازد.**",
    "**سوءتغذیه‌ی پروتئین-کالری خطر را چند برابر می‌کند: عضلات لگنی ضعیف‌ترند.**",
    "⚠️ **تخم کرم شالقی شکل مشخصی دارد: بشکه‌ای یا لیمویی با دو قطب شفاف.**",
    "**و درمان آن مبندازول است.**",
    "**حالا کرم قلاب‌دار را در برابر آن بگذارید، چون سؤال‌ها آن‌ها را کنار هم می‌آورند.**",
    "**کرم قلاب‌دار (آنکیلوستوما و نکاتور) در روده‌ی باریک به مخاط می‌چسبد و خون می‌مکد.**",
    "**نتیجه: کم‌خونی فقر آهن — امضای اصلی این کرم.**",
    "⚠️ **آنمی میکروسیتیک هیپوکروم + ائوزینوفیلی = کرم قلاب‌دار، تا خلاف آن ثابت نشده.**",
    "**و هیپوآلبومینمی هم از دست دادن پروتئین از راه روده را نشان می‌دهد.**",
    "**راه ورود کرم قلاب‌دار: نفوذ لارو از پوست پای برهنه.**",
    "**درمان: آلبندازول، به‌علاوه‌ی جبران آهن.**",
]
WH_EN = [
    "WARNING: RECTAL PROLAPSE IN A CHILD = WHIPWORM (Trichuris trichiura).",
    "Why? Because the whipworm settles in the rectum and distal colon.",
    "Heavy infection causes continuous straining (tenesmus) and mucosal inflammation.",
    "And continuous straining in a malnourished child pushes the rectum out.",
    "Protein-calorie malnutrition multiplies the risk: the pelvic muscles are weaker.",
    "WARNING, THE WHIPWORM EGG HAS A DISTINCTIVE SHAPE: barrel or lemon shaped with two clear polar plugs.",
    "And its treatment is mebendazole.",
    "Now set the hookworm against it, because the questions place them side by side.",
    "The hookworm (Ancylostoma and Necator) attaches to the small bowel mucosa and sucks blood.",
    "The result: IRON-DEFICIENCY ANAEMIA — this worm's chief signature.",
    "WARNING, MICROCYTIC HYPOCHROMIC ANAEMIA PLUS EOSINOPHILIA = hookworm until proved otherwise.",
    "And hypoalbuminaemia reflects protein loss through the bowel.",
    "The hookworm's route of entry: larval penetration through the skin of a bare foot.",
    "Treatment: albendazole, plus iron replacement.",
]

add("book:799", "recall", "medium",
    "**کرم شالقی مهاجرت ریوی ندارد — چون تخمش مستقیماً در روده تفریخ می‌شود.**",
    "The whipworm has no pulmonary migration — because its egg hatches directly in the bowel.",
    WH_FA + [
        "**چرخه‌ی لوفلر (مهاجرت ریوی) را یک بار درست بفهمید.**",
        "**لارو از روده وارد خون می‌شود، به ریه می‌رود، از آلوئول بالا می‌آید.**",
        "**سپس بلعیده می‌شود و به روده برمی‌گردد تا بالغ شود.**",
        "⚠️ **این مسیر در آسکاریس، استرونژیلوئید و کرم قلاب‌دار وجود دارد.**",
        "**و به همین دلیل هر سه می‌توانند سندرم لوفلر بدهند: سرفه، ویز و ائوزینوفیلی گذرا.**",
        "**ولی کرم شالقی این مسیر را ندارد.**",
        "**تخم آن بلعیده می‌شود، در روده تفریخ می‌شود، و همان‌جا در کولون بالغ می‌شود.**",
        "**هیچ‌گاه وارد خون یا ریه نمی‌شود.**",
    ],
    WH_EN + [
        "Understand Loeffler's cycle (pulmonary migration) properly once.",
        "The larva enters the blood from the bowel, reaches the lung, ascends through the alveolus.",
        "Then it is swallowed and returns to the bowel to mature.",
        "WARNING, THIS ROUTE EXISTS IN ASCARIS, STRONGYLOIDES AND HOOKWORM.",
        "Which is why all three can cause Loeffler's syndrome: cough, wheeze and transient eosinophilia.",
        "But the whipworm does not take this route.",
        "Its egg is swallowed, hatches in the bowel, and matures right there in the colon.",
        "It never enters the blood or the lung.",
    ],
    "این سؤال یک تفاوت **چرخه‌ی زندگی** را می‌سنجد که چند سؤال دیگر هم به آن وابسته‌اند.\n\n"
    "⚠️ **اول چرخه‌ی مهاجرت ریوی (چرخه‌ی لوفلر) را دقیق بفهمید:**\n\n"
    "لارو از دیواره‌ی روده وارد **جریان خون** می‌شود → با خون به **ریه** می‌رسد → از مویرگ "
    "ریوی به داخل **آلوئول** نفوذ می‌کند → از درخت برونشیال **بالا می‌آید** تا حلق → **بلعیده "
    "می‌شود** → به روده برمی‌گردد و آنجا **بالغ** می‌شود.\n\n"
    "**چرا این مسیر بالینی مهم است؟** چون در زمان عبور لارو از ریه، بیمار **سندرم لوفلر** "
    "می‌گیرد: **سرفه‌ی خشک، ویز، ارتشاح گذرای ریوی و ائوزینوفیلی**. این می‌تواند با آسم "
    "اشتباه شود.\n\n"
    "**سه کرمی که این مهاجرت را دارند:**\n\n"
    "**آسکاریس لومبریکوئیدس** — تخم بلعیده می‌شود، لارو از روده بیرون می‌آید و مسیر کامل را "
    "می‌رود.\n\n"
    "**استرونژیلوئیدس استرکورالیس** — لارو از پوست وارد می‌شود و مسیر ریوی را طی می‌کند.\n\n"
    "**نکاتور آمریکانوس (کرم قلاب‌دار)** — لارو از پوست پای برهنه وارد می‌شود و همان مسیر را می‌رود.\n\n"
    "⚠️ **و کرم شالقی (تریکوریس تریکیورا) این مسیر را ندارد.**\n\n"
    "**چرخه‌ی کرم شالقی ساده است:** تخم بلعیده می‌شود → در **روده‌ی باریک تفریخ می‌شود** → "
    "لارو به **کولون** می‌رود → همان‌جا **بالغ می‌شود**. **هیچ‌گاه وارد خون یا ریه نمی‌شود.**\n\n"
    "**پس پاسخ: کرم شالقی.**\n\n"
    "**نکته‌ی جانبی که ارزش دانستن دارد: کرمک (انتروبیوس) هم مهاجرت ریوی ندارد** — چرخه‌ی "
    "آن هم کاملاً روده‌ای است. پس اگر کرمک در گزینه‌ها بود، آن هم پاسخ می‌شد.",
    "This question tests a LIFE-CYCLE difference on which several other questions also depend.\n\n"
    "WARNING, FIRST UNDERSTAND THE PULMONARY MIGRATION (Loeffler's cycle) PRECISELY:\n\n"
    "The larva enters the BLOODSTREAM from the bowel wall, travels to the LUNG, penetrates from the "
    "pulmonary capillary into the ALVEOLUS, ASCENDS the bronchial tree to the pharynx, IS SWALLOWED, "
    "and returns to the bowel where it MATURES.\n\n"
    "WHY DOES THIS ROUTE MATTER CLINICALLY? Because while the larvae pass through the lung the patient "
    "develops LOEFFLER'S SYNDROME: DRY COUGH, WHEEZE, TRANSIENT PULMONARY INFILTRATES AND "
    "EOSINOPHILIA. This can be mistaken for asthma.\n\n"
    "THE THREE WORMS WITH THIS MIGRATION:\n\n"
    "ASCARIS LUMBRICOIDES — the egg is swallowed, the larva leaves the bowel and completes the whole route.\n\n"
    "STRONGYLOIDES STERCORALIS — the larva enters through the skin and takes the pulmonary route.\n\n"
    "NECATOR AMERICANUS (hookworm) — the larva enters through the skin of a bare foot and takes the "
    "same route.\n\n"
    "WARNING, AND THE WHIPWORM (Trichuris trichiura) DOES NOT TAKE THIS ROUTE.\n\n"
    "THE WHIPWORM CYCLE IS SIMPLE: the egg is swallowed, HATCHES IN THE SMALL BOWEL, the larva moves "
    "to the COLON and MATURES THERE. IT NEVER ENTERS THE BLOOD OR THE LUNG.\n\n"
    "SO THE ANSWER: THE WHIPWORM.\n\n"
    "A SIDE POINT WORTH KNOWING: PINWORM (Enterobius) ALSO HAS NO PULMONARY MIGRATION — its cycle is "
    "entirely intestinal too. So had pinworm been among the options, it would also have been an answer.",
    ["مهاجرت ریوی دارد؛ لارو از روده به خون، به ریه و سپس با بلع به روده برمی‌گردد.",
     "لارو آن از پوست وارد می‌شود و مسیر ریوی را کامل طی می‌کند.",
     "لارو کرم قلاب‌دار از پوست پای برهنه وارد و از راه ریه به روده می‌رسد.",
     "پاسخ صحیح — تخم در روده تفریخ می‌شود و لارو مستقیماً در کولون بالغ می‌شود."],
    ["It has pulmonary migration; the larva goes bowel to blood to lung and back by swallowing.",
     "Its larva enters through the skin and completes the pulmonary route.",
     "The hookworm larva enters through bare skin and reaches the bowel via the lung.",
     "Correct — the egg hatches in the bowel and the larva matures directly in the colon."],
    "**آسکاریس · استرونژیلوئید · قلاب‌دار = مهاجرت ریوی. شالقی و کرمک = بدون آن.**",
    "Ascaris, strongyloides and hookworm migrate through the lung. Whipworm and pinworm do not.",
    NREFS)

add("book:803", "vignette", "medium",
    "**پرولاپس رکتوم + تخم لیمویی‌شکل = کرم شالقی، و درمان آن مبندازول است.**",
    "Rectal prolapse plus a lemon-shaped egg = whipworm, and its treatment is mebendazole.",
    WH_FA + [
        "**در این بیمار سه سرنخ به یک تشخیص می‌رسند.**",
        "**اسهال خونی شدید، رکتال پرولاپس، و تخم شبیه لیمو.**",
        "⚠️ **تخم بشکه‌ای یا لیمویی با دو قطب شفاف، امضای تریکوریس است.**",
        "**و سوءتغذیه‌ی مزمن پروتئین-کالری خطر پرولاپس را چند برابر می‌کند.**",
        "**درمان تریکوریس: مبندازول.**",
        "**آلبندازول تک‌دوز در تریکوریس کارایی کمتری دارد.**",
        "**در آلودگی سنگین، افزودن ایورمکتین به آلبندازول کارایی را بالا می‌برد.**",
    ],
    WH_EN + [
        "In this patient three clues converge on one diagnosis.",
        "Severe bloody diarrhoea, rectal prolapse, and a lemon-shaped egg.",
        "WARNING, A BARREL OR LEMON-SHAPED EGG WITH TWO CLEAR POLAR PLUGS is the Trichuris signature.",
        "And chronic protein-calorie malnutrition multiplies the prolapse risk.",
        "Treatment of Trichuris: mebendazole.",
        "Single-dose albendazole is less effective in Trichuris.",
        "In heavy infection, adding ivermectin to albendazole improves the cure rate.",
    ],
    "این سؤال یک تابلوی کلاسیک را با یک **یافته‌ی میکروسکوپی** ترکیب کرده.\n\n"
    "**بیمار: کودک ۴ ساله با سوءتغذیه‌ی پروتئین-کالری مزمن، اسهال خونی شدید، دل‌درد و "
    "رکتال پرولاپس. در آزمایش مدفوع، تخم انگل شبیه لیمو.**\n\n"
    "**سه سرنخ، همه به یک تشخیص:**\n\n"
    "⚠️ **سرنخ یک — رکتال پرولاپس.** این کلاسیک‌ترین نشانه‌ی **تریکوریازیس شدید در کودک** "
    "است. مکانیسم: کرم شالقی در **رکتوم و کولون دیستال** می‌نشیند، آلودگی شدید **تنسموس "
    "(زور زدن مداوم)** و التهاب مخاط می‌سازد، و زور زدن مداوم رکتوم را بیرون می‌اندازد.\n\n"
    "**سرنخ دو — سوءتغذیه‌ی پروتئین-کالری.** این **خطر را چند برابر می‌کند**، چون عضلات و "
    "بافت‌های نگهدارنده‌ی لگنی ضعیف‌ترند. سوءتغذیه و تریکوریازیس شدید هم‌زمان دیده می‌شوند و "
    "یکدیگر را بدتر می‌کنند.\n\n"
    "**سرنخ سه — تخم شبیه لیمو.** این توصیف کتابی تخم تریکوریس است: **بشکه‌ای یا لیمویی، با "
    "دو قطب شفاف (polar plugs)**.\n\n"
    "**پس تشخیص قطعی: تریکوریس تریکیورا (کرم شالقی).**\n\n"
    "**و درمان: مبندازول.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**آلبندازول ۴۰۰ تک‌دوز:** آلبندازول روی تریکوریس **کارایی دارد ولی تک‌دوز آن ضعیف "
    "است** (نرخ درمان پایین). در تریکوریس، مبندازول ارجح است؛ و در آلودگی سنگین، **افزودن "
    "ایورمکتین به آلبندازول** کارایی را بالا می‌برد.\n\n"
    "**ایورمکتین ۲۰۰ تک‌دوز:** ایورمکتین به‌تنهایی روی تریکوریس **کارایی محدودی** دارد. "
    "جایگاه اصلی آن **استرونژیلوئیدس** و **انکوسرکیازیس** است.\n\n"
    "⚠️ **نیتازوکسانید:** این داروی **تک‌یاخته‌ها**ست (ژیاردیا، کریپتوسپوریدیوم)، نه کرم‌ها. "
    "**هدف دارویی کاملاً متفاوتی دارد.**",
    "This question combines a classic picture with A MICROSCOPIC FINDING.\n\n"
    "THE PATIENT: a 4-year-old with chronic protein-calorie malnutrition, severe bloody diarrhoea, "
    "abdominal pain and rectal prolapse. The stool shows a LEMON-SHAPED parasite egg.\n\n"
    "THREE CLUES, ALL TO ONE DIAGNOSIS:\n\n"
    "WARNING, CLUE ONE — RECTAL PROLAPSE. This is the most classic sign of SEVERE TRICHURIASIS IN A "
    "CHILD. The mechanism: the whipworm settles in the RECTUM AND DISTAL COLON, heavy infection "
    "produces TENESMUS (continuous straining) and mucosal inflammation, and that straining pushes the "
    "rectum out.\n\n"
    "CLUE TWO — PROTEIN-CALORIE MALNUTRITION. It MULTIPLIES THE RISK, because the pelvic muscles and "
    "supporting tissues are weaker. Malnutrition and heavy trichuriasis occur together and worsen each "
    "other.\n\n"
    "CLUE THREE — A LEMON-SHAPED EGG. This is the textbook description of the Trichuris egg: BARREL OR "
    "LEMON SHAPED WITH TWO CLEAR POLAR PLUGS.\n\n"
    "SO THE DIAGNOSIS IS CERTAIN: TRICHURIS TRICHIURA (whipworm).\n\n"
    "AND THE TREATMENT: MEBENDAZOLE.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ALBENDAZOLE 400 mg SINGLE DOSE: albendazole HAS ACTIVITY against Trichuris BUT ITS SINGLE DOSE IS "
    "WEAK (low cure rates). In Trichuris, mebendazole is preferred; and in heavy infection ADDING "
    "IVERMECTIN TO ALBENDAZOLE raises the cure rate.\n\n"
    "IVERMECTIN 200 SINGLE DOSE: ivermectin alone has LIMITED activity against Trichuris. Its main "
    "place is STRONGYLOIDES and ONCHOCERCIASIS.\n\n"
    "WARNING, NITAZOXANIDE: this is a drug for PROTOZOA (giardia, cryptosporidium), not for worms. IT "
    "HAS AN ENTIRELY DIFFERENT DRUG TARGET.",
    ["پاسخ صحیح — تخم لیمویی و پرولاپس رکتوم یعنی تریکوریس، و درمان آن مبندازول است.",
     "آلبندازول روی تریکوریس فعالیت دارد ولی تک‌دوز آن نرخ درمان پایینی دارد.",
     "ایورمکتین به‌تنهایی روی تریکوریس کارایی محدودی دارد؛ جایگاهش استرونژیلوئیدس است.",
     "داروی تک‌یاخته‌هاست (ژیاردیا و کریپتوسپوریدیوم)، نه کرم‌ها."],
    ["Correct — a lemon-shaped egg with rectal prolapse means Trichuris, treated with mebendazole.",
     "Albendazole has activity against Trichuris but its single dose has a low cure rate.",
     "Ivermectin alone has limited activity against Trichuris; its place is strongyloides.",
     "A drug for protozoa (giardia and cryptosporidium), not for worms."],
    "**تخم بشکه‌ای با دو قطب شفاف + پرولاپس رکتوم = کرم شالقی.**",
    "A barrel-shaped egg with two polar plugs plus rectal prolapse = whipworm.",
    NREFS)

add("book:817", "recall", "easy",
    "**پرولاپس رکتوم در کودک، عارضه‌ی کرم شالقی است.**",
    "Rectal prolapse in a child is a complication of the whipworm.",
    WH_FA,
    WH_EN,
    "این سؤال همان قاعده را **بدون تابلوی بالینی** می‌پرسد — یعنی باید ارتباط را مستقیم "
    "بدانید.\n\n"
    "⚠️ **پرولاپس رکتوم در کودکان = تریکوریس تریکیورا (کرم شالقی).**\n\n"
    "**مکانیسم را یک بار بفهمید تا فراموش نکنید:**\n\n"
    "کرم شالقی محل زندگی خاصی دارد: **سکوم، کولون و در آلودگی سنگین، رکتوم**. قسمت باریک "
    "بدن کرم (شبیه شلاق، از همین‌جا نام «شالقی») **در مخاط فرو می‌رود** و آن را می‌خراشد.\n\n"
    "**در آلودگی سنگین:** ده‌ها تا صدها کرم در رکتوم → التهاب مزمن مخاط → **اسهال خونی و "
    "تنسموس (احساس زور زدن مداوم)** → کودک مدام زور می‌زند → **رکتوم بیرون می‌افتد**.\n\n"
    "**و عامل تشدیدکننده: سوءتغذیه.** کودک دچار سوءتغذیه‌ی پروتئین-کالری، **عضلات و بافت "
    "همبند نگهدارنده‌ی ضعیف‌تری** دارد، پس با همان مقدار زور زدن، پرولاپس راحت‌تر رخ می‌دهد.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**استرونژیلوئیدس استرکورالیس:** تابلوی آن **اسهال، درد اپی‌گاستر، ائوزینوفیلی، لاروا "
    "کورنس (کهیر خطی مهاجر)** و در فرد دچار سرکوب ایمنی، **هایپراینفکشن** است. پرولاپس رکتوم "
    "مشخصه‌ی آن نیست.\n\n"
    "⚠️ **آنکیلوستوما دئودناله (کرم قلاب‌دار):** امضای آن **کم‌خونی فقر آهن** است، چون به "
    "مخاط روده‌ی باریک می‌چسبد و **خون می‌مکد**. هر کرم روزانه مقدار مشخصی خون می‌گیرد، و در "
    "آلودگی سنگین این به کم‌خونی شدید می‌رسد. **پرولاپس نمی‌دهد** چون در روده‌ی باریک است، نه رکتوم.\n\n"
    "**تریکینلوزیس:** بیماری کاملاً متفاوتی است. از خوردن **گوشت خوک نیم‌پز** می‌آید و لارو "
    "در **عضلات** کیست می‌بندد. تابلو: **تب، میالژی شدید، ادم دور چشم (پری‌اربیتال) و "
    "ائوزینوفیلی بالا**. اصلاً بیماری روده‌ای مزمن نیست.",
    "This question asks the same rule WITHOUT A CLINICAL PICTURE — so the association must be known "
    "directly.\n\n"
    "WARNING, RECTAL PROLAPSE IN CHILDREN = TRICHURIS TRICHIURA (whipworm).\n\n"
    "UNDERSTAND THE MECHANISM ONCE AND YOU WILL NOT FORGET IT:\n\n"
    "The whipworm has a specific habitat: the CAECUM, COLON and, in heavy infection, the RECTUM. The "
    "thin, whip-like part of its body (hence the name) BURROWS INTO THE MUCOSA and abrades it.\n\n"
    "IN HEAVY INFECTION: dozens to hundreds of worms in the rectum, chronic mucosal inflammation, "
    "BLOODY DIARRHOEA AND TENESMUS (a constant urge to strain), the child strains continually, and THE "
    "RECTUM PROLAPSES.\n\n"
    "AND THE AGGRAVATING FACTOR: MALNUTRITION. A child with protein-calorie malnutrition has WEAKER "
    "SUPPORTING MUSCLE AND CONNECTIVE TISSUE, so the same straining produces prolapse more readily.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "STRONGYLOIDES STERCORALIS: its picture is DIARRHOEA, EPIGASTRIC PAIN, EOSINOPHILIA, LARVA CURRENS "
    "(a migrating linear urticaria) and, in an immunosuppressed host, HYPERINFECTION. Rectal prolapse "
    "is not characteristic.\n\n"
    "WARNING, ANCYLOSTOMA DUODENALE (hookworm): its signature is IRON-DEFICIENCY ANAEMIA, because it "
    "attaches to the small bowel mucosa and SUCKS BLOOD. Each worm takes a set amount of blood daily, "
    "and in heavy infection this reaches severe anaemia. IT DOES NOT CAUSE PROLAPSE, because it lives "
    "in the small bowel, not the rectum.\n\n"
    "TRICHINELLOSIS: an entirely different disease. It comes from eating UNDERCOOKED PORK and its "
    "larvae encyst IN MUSCLE. The picture: FEVER, SEVERE MYALGIA, PERIORBITAL OEDEMA AND MARKED "
    "EOSINOPHILIA. It is not a chronic intestinal disease at all.",
    ["پاسخ صحیح — کرم شالقی در رکتوم می‌نشیند و تنسموس مداوم پرولاپس می‌سازد.",
     "تابلوی آن اسهال، لاروا کورنس و هایپراینفکشن است؛ پرولاپس مشخصه‌ی آن نیست.",
     "امضای آن کم‌خونی فقر آهن است؛ در روده‌ی باریک زندگی می‌کند نه رکتوم.",
     "بیماری عضلانی از گوشت خوک نیم‌پز است: تب، میالژی و ادم دور چشم."],
    ["Correct — the whipworm settles in the rectum and constant tenesmus produces prolapse.",
     "Its picture is diarrhoea, larva currens and hyperinfection; prolapse is not characteristic.",
     "Its signature is iron-deficiency anaemia; it lives in the small bowel, not the rectum.",
     "A muscle disease from undercooked pork: fever, myalgia and periorbital oedema."],
    "**شالقی در رکتوم می‌نشیند، پس پرولاپس می‌دهد. قلاب‌دار خون می‌مکد، پس آنمی می‌دهد.**",
    "The whipworm sits in the rectum, so it prolapses. The hookworm sucks blood, so it anaemias.",
    NREFS)

add("book:818", "recall", "easy",
    "**کم‌خونی فقر آهن، امضای کرم قلاب‌دار است — چون خون می‌مکد.**",
    "Iron-deficiency anaemia is the hookworm's signature — because it sucks blood.",
    WH_FA,
    WH_EN,
    "این سؤال یک ارتباط ساده ولی حیاتی را می‌سنجد.\n\n"
    "⚠️ **کم‌خونی فقر آهن ناشی از آلودگی شدید روده‌ای = کرم قلاب‌دار.**\n\n"
    "**چرا؟ مکانیسم بسیار مستقیم است:**\n\n"
    "کرم قلاب‌دار (آنکیلوستوما دئودناله و نکاتور آمریکانوس) با **صفحات برنده یا دندان‌های "
    "خود** به مخاط روده‌ی باریک **می‌چسبد** و از آن **خون می‌مکد**. هر کرم روزانه مقدار "
    "مشخصی خون می‌گیرد، و در آلودگی سنگین با صدها کرم، **از دست دادن خون روزانه چشمگیر** "
    "می‌شود.\n\n"
    "**نتیجه: کم‌خونی مزمن فقر آهن.** و چون مزمن است، بدن سازگار می‌شود و بیمار ممکن است "
    "با هموگلوبین بسیار پایین هم نسبتاً خوب به نظر برسد.\n\n"
    "**راه ورود را هم بدانید:** **لارو از پوست پای برهنه نفوذ می‌کند** (در کشاورزان و "
    "کودکانی که پابرهنه راه می‌روند)، سپس **مسیر ریوی** را طی می‌کند و به روده می‌رسد.\n\n"
    "**درمان: آلبندازول** (یا مبندازول)، **به‌علاوه‌ی جبران آهن**. توجه کنید که فقط کشتن "
    "کرم کافی نیست — ذخایر آهن هم باید بازسازی شوند.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**آسکاریس:** بزرگ‌ترین نماتود روده‌ای است ولی **خون‌مکنده نیست**. عوارض آن **انسدادی و "
    "مکانیکی**اند: انسداد روده، کلانژیت، پانکراتیت، آپاندیسیت. در کودکان با آلودگی سنگین "
    "می‌تواند **سوءتغذیه** بدهد، ولی **کم‌خونی فقر آهن مشخصه‌ی آن نیست**.\n\n"
    "**کرم شالقی:** در آلودگی بسیار سنگین می‌تواند **خونریزی مزمن مخاطی** و در نتیجه کم‌خونی "
    "بدهد، ولی امضای اصلی آن **پرولاپس رکتوم و اسهال خونی** است، نه کم‌خونی فقر آهن.\n\n"
    "⚠️ **تنیا سولیوم:** این یک **کرم نواری (سستود)** است، نه نماتود. خون نمی‌مکد. عارضه‌ی "
    "مهم آن **نوروسیستی‌سرکوز** است. برخی سستودها کمبود ویتامین می‌دهند (**دیفیلوبوتریوم "
    "لاتوم → کمبود B12**)، ولی این **کم‌خونی مگالوبلاستیک** است، نه فقر آهن.",
    "This question tests a simple but vital association.\n\n"
    "WARNING, IRON-DEFICIENCY ANAEMIA FROM HEAVY INTESTINAL INFECTION = HOOKWORM.\n\n"
    "WHY? The mechanism is very direct:\n\n"
    "The hookworm (Ancylostoma duodenale and Necator americanus) ATTACHES to the small bowel mucosa "
    "with its CUTTING PLATES OR TEETH and SUCKS BLOOD from it. Each worm takes a set volume of blood "
    "daily, and in heavy infection with hundreds of worms the DAILY BLOOD LOSS BECOMES SUBSTANTIAL.\n\n"
    "THE RESULT: CHRONIC IRON-DEFICIENCY ANAEMIA. And because it is chronic the body adapts, so a "
    "patient may look relatively well even with a very low haemoglobin.\n\n"
    "KNOW THE ROUTE OF ENTRY TOO: THE LARVA PENETRATES THE SKIN OF A BARE FOOT (in farmers and "
    "barefoot children), then takes THE PULMONARY ROUTE to reach the bowel.\n\n"
    "TREATMENT: ALBENDAZOLE (or mebendazole), PLUS IRON REPLACEMENT. Note that killing the worm alone "
    "is not enough — the iron stores must also be rebuilt.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ASCARIS: the largest intestinal nematode, but IT DOES NOT SUCK BLOOD. Its complications are "
    "OBSTRUCTIVE AND MECHANICAL: bowel obstruction, cholangitis, pancreatitis, appendicitis. In "
    "children with heavy infection it can cause MALNUTRITION, but IRON-DEFICIENCY ANAEMIA IS NOT ITS "
    "SIGNATURE.\n\n"
    "WHIPWORM: in very heavy infection it can cause CHRONIC MUCOSAL BLEEDING and hence anaemia, but "
    "its chief signature is RECTAL PROLAPSE AND BLOODY DIARRHOEA, not iron deficiency.\n\n"
    "WARNING, TAENIA SOLIUM: this is a TAPEWORM (cestode), not a nematode. It does not suck blood. Its "
    "important complication is NEUROCYSTICERCOSIS. Some cestodes do cause vitamin deficiency "
    "(DIPHYLLOBOTHRIUM LATUM causes B12 DEFICIENCY), but that is MEGALOBLASTIC anaemia, not iron "
    "deficiency.",
    ["بزرگ‌ترین نماتود روده‌ای است ولی خون‌مکنده نیست؛ عوارض آن انسدادی و مکانیکی است.",
     "امضای آن پرولاپس رکتوم و اسهال خونی است، نه کم‌خونی فقر آهن.",
     "پاسخ صحیح — کرم قلاب‌دار به مخاط می‌چسبد و خون می‌مکد، پس فقر آهن می‌سازد.",
     "کرم نواری است و خون نمی‌مکد؛ عارضه‌ی مهم آن نوروسیستی‌سرکوز است."],
    ["The largest intestinal nematode, but it does not suck blood; its complications are obstructive.",
     "Its signature is rectal prolapse and bloody diarrhoea, not iron-deficiency anaemia.",
     "Correct — the hookworm attaches to the mucosa and sucks blood, producing iron deficiency.",
     "A tapeworm that does not suck blood; its important complication is neurocysticercosis."],
    "**قلاب‌دار خون می‌مکد → فقر آهن. دیفیلوبوتریوم → کمبود B12، که مگالوبلاستیک است.**",
    "Hookworm sucks blood, giving iron deficiency. Diphyllobothrium gives B12 deficiency, which is megaloblastic.",
    NREFS)

add("book:819", "recall", "medium",
    "**آنمی میکروسیتیک + هیپوآلبومینمی + ائوزینوفیلی = کرم قلاب‌دار.**",
    "Microcytic anaemia plus hypoalbuminaemia plus eosinophilia = HOOKWORM.",
    WH_FA + [
        "**این سؤال سه یافته را با هم داده، و هر سه یک داستان می‌گویند.**",
        "**آنمی میکروسیتیک هیپوکروم: از دست دادن مزمن خون، یعنی فقر آهن.**",
        "**هیپوآلبومینمی: از دست دادن پروتئین از راه مخاط آسیب‌دیده‌ی روده.**",
        "⚠️ **ائوزینوفیلی: پاسخ ایمنی معمول به هر کرم بافتی و مهاجر.**",
        "**و کرم قلاب‌دار تنها گزینه‌ای است که هر سه را با هم توضیح می‌دهد.**",
        "**در آلودگی سنگین، از دست دادن پروتئین می‌تواند به ادم هم برسد.**",
    ],
    WH_EN + [
        "This question gives three findings together, and all three tell one story.",
        "MICROCYTIC HYPOCHROMIC ANAEMIA: chronic blood loss, that is, iron deficiency.",
        "HYPOALBUMINAEMIA: protein loss through damaged intestinal mucosa.",
        "WARNING, EOSINOPHILIA: the usual immune response to any tissue-migrating worm.",
        "And the hookworm is the only option that explains all three together.",
        "In heavy infection, protein loss can even progress to oedema.",
    ],
    "این سؤال **سه یافته‌ی آزمایشگاهی** را با هم داده، و مهارت واقعی این است که ببینید "
    "**هر سه یک داستان واحد** می‌گویند.\n\n"
    "**یافته‌ی یک — آنمی میکروسیتیک هیپوکروم.** این الگوی **فقر آهن** است. گلبول‌های کوچک "
    "و کم‌رنگ، چون آهن کافی برای ساخت هموگلوبین نیست. علت شایع آن در بزرگ‌سال: **از دست دادن "
    "مزمن خون**.\n\n"
    "**یافته‌ی دو — هیپوآلبومینمی.** یعنی **از دست دادن پروتئین**. در بیماری روده‌ای، این از "
    "**مخاط آسیب‌دیده** می‌آید (انتروپاتی از دست‌دهنده‌ی پروتئین).\n\n"
    "⚠️ **یافته‌ی سه — ائوزینوفیلی.** این پاسخ ایمنی معمول به **کرم‌های بافتی و مهاجر** است. "
    "(نکته: ائوزینوفیلی در کرم‌هایی که فقط در لومن می‌مانند — مثل تنیای بالغ — کمتر بارز است.)\n\n"
    "**حالا کدام کرم هر سه را با هم توضیح می‌دهد؟ کرم قلاب‌دار:**\n\n"
    "**به مخاط روده‌ی باریک می‌چسبد و خون می‌مکد** → فقر آهن ✓\n\n"
    "**مخاط را آسیب می‌زند** → از دست دادن پروتئین → هیپوآلبومینمی ✓\n\n"
    "**لارو آن از پوست و ریه مهاجرت می‌کند** → ائوزینوفیلی ✓\n\n"
    "**در آلودگی بسیار سنگین، از دست دادن پروتئین می‌تواند حتی به ادم برسد.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**آسکاریس:** ائوزینوفیلی می‌دهد (به‌ویژه در فاز مهاجرت ریوی) ولی **خون‌مکنده نیست**، پس "
    "**فقر آهن نمی‌سازد**.\n\n"
    "**استرونژیلوئید:** ائوزینوفیلی بارزی می‌دهد و می‌تواند سوءجذب هم بدهد، ولی **فقر آهن "
    "مشخصه‌ی آن نیست**. تابلوی آن **درد اپی‌گاستر، اسهال، لاروا کورنس** است.\n\n"
    "**کرم شالقی:** در آلودگی سنگین خونریزی مخاطی می‌دهد، ولی **این سه‌گانه با هم، امضای "
    "قلاب‌دار است**، و امضای شالقی **پرولاپس رکتوم** است.",
    "This question gives THREE LABORATORY FINDINGS together, and the real skill is seeing that ALL "
    "THREE TELL ONE STORY.\n\n"
    "FINDING ONE — MICROCYTIC HYPOCHROMIC ANAEMIA. That is the IRON-DEFICIENCY pattern. Small pale "
    "cells, because there is not enough iron to build haemoglobin. Its common cause in an adult: "
    "CHRONIC BLOOD LOSS.\n\n"
    "FINDING TWO — HYPOALBUMINAEMIA. That means PROTEIN LOSS. In intestinal disease it arises from "
    "DAMAGED MUCOSA (a protein-losing enteropathy).\n\n"
    "WARNING, FINDING THREE — EOSINOPHILIA. This is the usual immune response to TISSUE-MIGRATING "
    "WORMS. (Note: eosinophilia is less marked with worms that stay purely in the lumen, such as the "
    "adult tapeworm.)\n\n"
    "NOW WHICH WORM EXPLAINS ALL THREE? THE HOOKWORM:\n\n"
    "IT ATTACHES TO THE SMALL BOWEL MUCOSA AND SUCKS BLOOD, giving iron deficiency.\n\n"
    "IT DAMAGES THE MUCOSA, causing protein loss and hypoalbuminaemia.\n\n"
    "ITS LARVA MIGRATES THROUGH SKIN AND LUNG, causing eosinophilia.\n\n"
    "IN VERY HEAVY INFECTION THE PROTEIN LOSS CAN EVEN PROGRESS TO OEDEMA.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ASCARIS: it causes eosinophilia (especially in the pulmonary migration phase) but IT DOES NOT "
    "SUCK BLOOD, so it DOES NOT CAUSE IRON DEFICIENCY.\n\n"
    "STRONGYLOIDES: it causes marked eosinophilia and can cause malabsorption, but IRON DEFICIENCY IS "
    "NOT CHARACTERISTIC. Its picture is EPIGASTRIC PAIN, DIARRHOEA and LARVA CURRENS.\n\n"
    "WHIPWORM: in heavy infection it causes mucosal bleeding, but THIS TRIAD TOGETHER IS THE HOOKWORM "
    "SIGNATURE, and the whipworm's signature is RECTAL PROLAPSE.",
    ["ائوزینوفیلی می‌دهد ولی خون‌مکنده نیست، پس فقر آهن نمی‌سازد.",
     "پاسخ صحیح — خون می‌مکد (فقر آهن)، مخاط را آسیب می‌زند (هیپوآلبومینمی)، و مهاجرت می‌کند (ائوزینوفیلی).",
     "ائوزینوفیلی بارز دارد ولی فقر آهن مشخصه‌ی آن نیست؛ تابلویش درد اپی‌گاستر و لاروا کورنس است.",
     "در آلودگی سنگین خونریزی مخاطی دارد، ولی امضای آن پرولاپس رکتوم است نه این سه‌گانه."],
    ["Causes eosinophilia but does not suck blood, so it does not produce iron deficiency.",
     "Correct — it sucks blood (iron deficiency), damages mucosa (hypoalbuminaemia) and migrates (eosinophilia).",
     "Causes marked eosinophilia but iron deficiency is not characteristic; its picture is epigastric pain and larva currens.",
     "Causes mucosal bleeding in heavy infection, but its signature is rectal prolapse, not this triad."],
    "**سه یافته، یک داستان: خون‌مکیدن + آسیب مخاط + مهاجرت لارو = قلاب‌دار.**",
    "Three findings, one story: blood-sucking plus mucosal damage plus larval migration = hookworm.",
    NREFS)

# ================================================== ASCARIS: SIX ITEMS
ASC_FA = [
    "⚠️ **آسکاریس لومبریکوئیدس بزرگ‌ترین نماتود روده‌ای انسان است: ۱۵ تا ۳۵ سانتی‌متر.**",
    "**و همین اندازه، همه‌ی عوارض آن را توضیح می‌دهد: عوارض آسکاریس مکانیکی‌اند.**",
    "**در آلودگی سنگین، توده‌ای از کرم‌ها می‌تواند لومن روده را ببندد.**",
    "**پس انسداد روده، شایع‌ترین عارضه‌ی جراحی آسکاریس در کودکان است.**",
    "⚠️ **و کرم بالغ می‌تواند به مجاری باریک مهاجرت کند و آن‌ها را ببندد.**",
    "**مجرای صفراوی → کلانژیت و یرقان انسدادی.**",
    "**مجرای پانکراس → پانکراتیت حاد.**",
    "**آپاندیس → آپاندیسیت. و در آلودگی سنگین، حتی پرفوراسیون روده.**",
    "**درمان معمول آسکاریس: آلبندازول ۴۰۰ میلی‌گرم تک‌دوز.**",
    "⚠️ **ولی در انسداد، دارو عوض می‌شود — و این نکته‌ی کلیدی دو سؤال است.**",
    "**آلبندازول و مبندازول کرم را می‌کشند.**",
    "**و توده‌ای از کرم‌های مرده در روده‌ی از قبل مسدود، می‌تواند اوضاع را بدتر کند.**",
    "**پیپرازین اما کرم را فلج شل می‌کند، نه اینکه بکشد.**",
    "**کرم شل‌شده با حرکات دودی روده به‌راحتی دفع می‌شود.**",
    "⚠️ **پس در انسداد آسکاریسی: پیپرازین با لوله‌ی معده، به‌علاوه‌ی مایعات وریدی.**",
    "**و در بارداری، داروی انتخابی پیرانتل پاموآت است.**",
    "**چون بنزیمیدازول‌ها (آلبندازول و مبندازول) در بارداری، به‌ویژه سه‌ماهه‌ی اول، پرهیز می‌شوند.**",
]
ASC_EN = [
    "WARNING: ASCARIS LUMBRICOIDES IS THE LARGEST HUMAN INTESTINAL NEMATODE: 15 to 35 cm.",
    "And that size explains all its complications: ASCARIS COMPLICATIONS ARE MECHANICAL.",
    "In heavy infection a bolus of worms can occlude the bowel lumen.",
    "So bowel obstruction is the commonest surgical complication of ascaris in children.",
    "WARNING, AND THE ADULT WORM CAN MIGRATE INTO NARROW DUCTS and block them.",
    "Bile duct, giving cholangitis and obstructive jaundice.",
    "Pancreatic duct, giving acute pancreatitis.",
    "Appendix, giving appendicitis. And in heavy infection, even bowel perforation.",
    "The usual treatment of ascaris: albendazole 400 mg single dose.",
    "WARNING, BUT IN OBSTRUCTION THE DRUG CHANGES — and this is the key point of two questions.",
    "Albendazole and mebendazole KILL the worm.",
    "And a mass of dead worms in an already obstructed bowel can make matters worse.",
    "Piperazine, by contrast, PARALYSES the worm flaccidly rather than killing it.",
    "A relaxed worm is passed easily by peristalsis.",
    "WARNING, SO IN ASCARIS OBSTRUCTION: piperazine by nasogastric tube plus intravenous fluids.",
    "And in pregnancy the drug of choice is pyrantel pamoate.",
    "Because the benzimidazoles (albendazole and mebendazole) are avoided in pregnancy, especially the first trimester.",
]

add("book:813", "recall", "easy",
    "**هر سه عارضه از آسکاریس‌اند — چون عوارض آن مکانیکی است و کرم بزرگ است.**",
    "All three complications belong to ascaris — because its complications are mechanical and the worm is large.",
    ASC_FA,
    ASC_EN,
    "این سؤال کوتاه است ولی **منطق کل بلوک آسکاریس** را در خود دارد.\n\n"
    "⚠️ **کلید فهم آسکاریس یک جمله است: عوارض آسکاریس مکانیکی‌اند، چون کرم بسیار بزرگ است.**\n\n"
    "**آسکاریس لومبریکوئیدس بزرگ‌ترین نماتود روده‌ای انسان است: ۱۵ تا ۳۵ سانتی‌متر طول.** "
    "این اندازه، برخلاف کرم‌های کوچک، اجازه می‌دهد که کرم **مجراها را فیزیکی ببندد**.\n\n"
    "**حالا هر سه گزینه را ببینید:**\n\n"
    "**پرفوراسیون روده** — در آلودگی سنگین، توده‌ای از کرم‌ها می‌تواند **فشار و ایسکمی موضعی** "
    "ایجاد کند و به پرفوراسیون برسد. عارضه‌ی نادر ولی شناخته‌شده.\n\n"
    "⚠️ **کلانژیت** — کرم بالغ **به مجرای صفراوی مهاجرت می‌کند** و آن را می‌بندد. نتیجه: "
    "**کلانژیت، یرقان انسدادی، و گاهی آبسه‌ی کبدی**. این یکی از شناخته‌شده‌ترین عوارض آسکاریس "
    "در مناطق اندمیک است.\n\n"
    "**پانکراتیت** — همان مکانیسم، ولی در **مجرای پانکراس**. کرم مجرا را می‌بندد و **پانکراتیت "
    "حاد** رخ می‌دهد. در برخی مناطق اندمیک، آسکاریس از علل شایع پانکراتیت است.\n\n"
    "**پس پاسخ: همه‌ی موارد.**\n\n"
    "**و عوارض دیگری که در فهرست نبود ولی باید بدانید:**\n\n"
    "**انسداد روده** — شایع‌ترین عارضه‌ی جراحی، به‌ویژه در کودکان با آلودگی سنگین (لومن روده‌ی "
    "کودک باریک‌تر است).\n\n"
    "**آپاندیسیت** — کرم وارد آپاندیس می‌شود و آن را می‌بندد.\n\n"
    "**سندرم لوفلر** — در فاز **مهاجرت ریوی** لارو: سرفه، ویز، ارتشاح گذرای ریوی و ائوزینوفیلی.\n\n"
    "**سوءتغذیه** — در کودکان با آلودگی سنگین و مزمن، رقابت کرم‌ها برای مواد غذایی.\n\n"
    "⚠️ **درس روش‌شناختی: در سؤال‌های «همه‌ی موارد»، اگر منطق واحدی پیدا کنید که همه‌ی گزینه‌ها "
    "را توضیح دهد — اینجا «کرم بزرگ است و مجراها را می‌بندد» — پاسخ فوراً روشن می‌شود.**",
    "This question is short but contains THE LOGIC OF THE ENTIRE ASCARIS BLOCK.\n\n"
    "WARNING, THE KEY TO UNDERSTANDING ASCARIS IS ONE SENTENCE: ITS COMPLICATIONS ARE MECHANICAL, "
    "BECAUSE THE WORM IS VERY LARGE.\n\n"
    "ASCARIS LUMBRICOIDES IS THE LARGEST HUMAN INTESTINAL NEMATODE: 15 to 35 cm long. That size, "
    "unlike small worms, allows the worm to PHYSICALLY OCCLUDE DUCTS.\n\n"
    "NOW LOOK AT ALL THREE OPTIONS:\n\n"
    "BOWEL PERFORATION — in heavy infection a bolus of worms can create LOCAL PRESSURE AND ISCHAEMIA "
    "and progress to perforation. A rare but recognised complication.\n\n"
    "WARNING, CHOLANGITIS — the adult worm MIGRATES INTO THE BILE DUCT and blocks it. The result: "
    "CHOLANGITIS, OBSTRUCTIVE JAUNDICE and sometimes LIVER ABSCESS. This is one of the best-recognised "
    "ascaris complications in endemic areas.\n\n"
    "PANCREATITIS — the same mechanism, but in the PANCREATIC DUCT. The worm blocks the duct and ACUTE "
    "PANCREATITIS follows. In some endemic areas ascaris is a common cause of pancreatitis.\n\n"
    "SO THE ANSWER: ALL OF THE ABOVE.\n\n"
    "AND OTHER COMPLICATIONS NOT LISTED BUT WORTH KNOWING:\n\n"
    "BOWEL OBSTRUCTION — the commonest surgical complication, especially in children with heavy "
    "infection (a child's bowel lumen is narrower).\n\n"
    "APPENDICITIS — the worm enters the appendix and occludes it.\n\n"
    "LOEFFLER'S SYNDROME — during the LARVAL PULMONARY MIGRATION: cough, wheeze, transient pulmonary "
    "infiltrates and eosinophilia.\n\n"
    "MALNUTRITION — in children with heavy chronic infection, from the worms competing for nutrients.\n\n"
    "WARNING, A METHODOLOGICAL LESSON: in 'all of the above' questions, if you can find a single logic "
    "that explains every option — here 'the worm is large and blocks ducts' — the answer becomes "
    "immediately clear.",
    ["درست است — در آلودگی سنگین، فشار و ایسکمی موضعی می‌تواند به پرفوراسیون برسد.",
     "درست است — کرم بالغ به مجرای صفراوی مهاجرت می‌کند و کلانژیت و یرقان انسدادی می‌دهد.",
     "درست است — کرم مجرای پانکراس را می‌بندد و پانکراتیت حاد رخ می‌دهد.",
     "پاسخ صحیح — هر سه عارضه‌ی مکانیکی آسکاریس‌اند، چون کرم بزرگ است و مجراها را می‌بندد."],
    ["Correct — in heavy infection, local pressure and ischaemia can progress to perforation.",
     "Correct — the adult worm migrates into the bile duct, causing cholangitis and obstructive jaundice.",
     "Correct — the worm blocks the pancreatic duct and acute pancreatitis follows.",
     "Correct — all three are mechanical ascaris complications, because the worm is large and blocks ducts."],
    "**کرم ۳۵ سانتی‌متری مجرا را می‌بندد — پس عوارض آسکاریس مکانیکی‌اند.**",
    "A 35 cm worm blocks ducts — so ascaris complications are mechanical.",
    NREFS)

add("book:802", "vignette", "medium",
    "**کرم گرد و صورتی ۴۰ سانتی‌متری = آسکاریس، و درمان آن مبندازول است.**",
    "A round pink 40 cm worm = ascaris, and its treatment is mebendazole.",
    ASC_FA + [
        "**توصیف کرم در این سؤال، تشخیص را قطعی می‌کند.**",
        "**باریک، گرد، صورتی، و حدود ۴۰ سانتی‌متر: این آسکاریس است.**",
        "⚠️ **هیچ کرم روده‌ای دیگری این اندازه و این شکل را ندارد.**",
        "**کرم نواری (تنیا) پهن و بندبند است، نه گرد.**",
        "**و کرمک فقط چند میلی‌متر طول دارد.**",
        "**بنزیمیدازول‌ها (مبندازول و آلبندازول) درمان استاندارد آسکاریس بدون عارضه‌اند.**",
    ],
    ASC_EN + [
        "The description of the worm settles the diagnosis outright.",
        "Thin, round, pink and about 40 cm: this is ascaris.",
        "WARNING, NO OTHER INTESTINAL WORM has this size and this shape.",
        "A tapeworm (taenia) is flat and segmented, not round.",
        "And a pinworm is only a few millimetres long.",
        "The benzimidazoles (mebendazole and albendazole) are the standard treatment of uncomplicated ascaris.",
    ],
    "این سؤال با **توصیف فیزیکی کرم** حل می‌شود، و همین آن را آموزنده می‌کند: **ظاهر کرم "
    "دفع‌شده، تشخیص را می‌دهد.**\n\n"
    "**بیمار: دفع یک کرم باریک، گرد و صورتی‌رنگ به طول تقریبی ۴۰ سانتی‌متر.**\n\n"
    "⚠️ **این توصیف قطعاً آسکاریس لومبریکوئیدس است. چرا؟**\n\n"
    "**«گرد»** → یک **نماتود** است (کرم گرد)، نه سستود (کرم نواری) و نه ترماتود.\n\n"
    "**«۴۰ سانتی‌متر»** → **بزرگ‌ترین نماتود روده‌ای انسان**. آسکاریس ماده تا ۳۵ سانتی‌متر و "
    "گاهی بیشتر می‌رسد. هیچ نماتود روده‌ای دیگری این اندازه نیست: **کرمک فقط ۸ تا ۱۳ "
    "میلی‌متر**، **قلاب‌دار حدود ۱ سانتی‌متر**، **شالقی حدود ۴ سانتی‌متر**.\n\n"
    "**«صورتی»** → رنگ مشخص آسکاریس زنده.\n\n"
    "**پس تشخیص قطعی است، و درمان: مبندازول.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**مترونیدازول:** داروی **تک‌یاخته‌ها و بی‌هوازی‌ها**ست (آمیب، ژیاردیا، تریکوموناس). "
    "**روی کرم‌ها هیچ اثری ندارد.**\n\n"
    "⚠️ **پرازی‌کوانتل:** داروی **کرم‌های پهن** است — **سستودها** (تنیا، اکینوکوکوس) و "
    "**ترماتودها** (شیستوزوما، فاسیولا). **روی نماتودها مؤثر نیست.** این مهم‌ترین تمایز "
    "دارویی این فصل است: **بنزیمیدازول برای کرم گرد، پرازی‌کوانتل برای کرم پهن.**\n\n"
    "**نیکلوزامید:** داروی قدیمی **کرم نواری** است (امروز کمتر استفاده می‌شود، چون "
    "پرازی‌کوانتل بهتر است). **روی نماتودها اثری ندارد.**\n\n"
    "**پس قاعده‌ی کلیدی: کرم گرد (نماتود) → بنزیمیدازول (مبندازول یا آلبندازول). کرم پهن "
    "(سستود یا ترماتود) → پرازی‌کوانتل.**",
    "This question is solved by THE PHYSICAL DESCRIPTION OF THE WORM, and that is what makes it "
    "instructive: THE APPEARANCE OF A PASSED WORM MAKES THE DIAGNOSIS.\n\n"
    "THE PATIENT: has passed a thin, round, pink worm about 40 cm long.\n\n"
    "WARNING, THIS DESCRIPTION IS DEFINITELY ASCARIS LUMBRICOIDES. WHY?\n\n"
    "'ROUND' means it is A NEMATODE (roundworm), not a cestode (tapeworm) or a trematode.\n\n"
    "'40 cm' means THE LARGEST HUMAN INTESTINAL NEMATODE. A female ascaris reaches 35 cm and sometimes "
    "more. No other intestinal nematode is this size: PINWORM IS ONLY 8 TO 13 mm, HOOKWORM ABOUT 1 cm, "
    "WHIPWORM ABOUT 4 cm.\n\n"
    "'PINK' is the characteristic colour of a live ascaris.\n\n"
    "SO THE DIAGNOSIS IS CERTAIN, AND THE TREATMENT IS MEBENDAZOLE.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "METRONIDAZOLE: a drug for PROTOZOA AND ANAEROBES (amoeba, giardia, trichomonas). IT HAS NO EFFECT "
    "ON WORMS AT ALL.\n\n"
    "WARNING, PRAZIQUANTEL: a drug for FLATWORMS — CESTODES (taenia, echinococcus) and TREMATODES "
    "(schistosoma, fasciola). IT IS NOT EFFECTIVE AGAINST NEMATODES. This is the most important drug "
    "distinction in this chapter: BENZIMIDAZOLES FOR ROUNDWORMS, PRAZIQUANTEL FOR FLATWORMS.\n\n"
    "NICLOSAMIDE: an old TAPEWORM drug (little used today, since praziquantel is better). NO EFFECT ON "
    "NEMATODES.\n\n"
    "SO THE KEY RULE: ROUNDWORM (nematode) means a BENZIMIDAZOLE (mebendazole or albendazole). "
    "FLATWORM (cestode or trematode) means PRAZIQUANTEL.",
    ["داروی تک‌یاخته‌ها و بی‌هوازی‌هاست؛ روی کرم‌ها هیچ اثری ندارد.",
     "داروی کرم‌های پهن است (سستود و ترماتود)؛ روی نماتودها مؤثر نیست.",
     "پاسخ صحیح — کرم گرد ۴۰ سانتی‌متری یعنی آسکاریس، و بنزیمیدازول درمان آن است.",
     "داروی قدیمی کرم نواری است و روی نماتودها اثری ندارد."],
    ["A drug for protozoa and anaerobes; it has no effect on worms.",
     "A drug for flatworms (cestodes and trematodes); not effective against nematodes.",
     "Correct — a round 40 cm worm means ascaris, and a benzimidazole is its treatment.",
     "An old tapeworm drug with no effect on nematodes."],
    "**کرم گرد → بنزیمیدازول. کرم پهن → پرازی‌کوانتل.**",
    "Roundworm means a benzimidazole. Flatworm means praziquantel.",
    NREFS)

add("book:808", "vignette", "medium",
    "**آسکاریس در بارداری: پیرانتل پاموآت — بنزیمیدازول‌ها در سه‌ماهه‌ی اول پرهیز می‌شوند.**",
    "Ascaris in pregnancy: PYRANTEL PAMOATE — the benzimidazoles are avoided in the first trimester.",
    ASC_FA + [
        "**در بارداری، انتخاب دارو عوض می‌شود و دلیلش تراتوژنیسیته است.**",
        "**آلبندازول و مبندازول در مطالعات حیوانی تراتوژن بوده‌اند.**",
        "⚠️ **پس در سه‌ماهه‌ی اول از آن‌ها پرهیز می‌شود.**",
        "**پیرانتل پاموآت جایگزین ایمن است.**",
        "**چرا ایمن؟ چون جذب سیستمیک بسیار ناچیزی دارد.**",
        "**دارویی که وارد خون نمی‌شود، به جنین هم نمی‌رسد.**",
        "**و مکانیسم آن: فلج اسپاستیک کرم، که با حرکات روده دفع می‌شود.**",
    ],
    ASC_EN + [
        "In pregnancy the drug choice changes, and the reason is teratogenicity.",
        "Albendazole and mebendazole have been teratogenic in animal studies.",
        "WARNING, SO THEY ARE AVOIDED IN THE FIRST TRIMESTER.",
        "Pyrantel pamoate is the safe alternative.",
        "Why safe? Because it has negligible systemic absorption.",
        "A drug that does not enter the blood does not reach the fetus.",
        "And its mechanism: spastic paralysis of the worm, which is then passed by peristalsis.",
    ],
    "این سؤال قاعده‌ی درمان آسکاریس را با **یک قید** ترکیب می‌کند: **بارداری**.\n\n"
    "**بیمار: خانم ۲۳ ساله در ماه سوم بارداری، با درد شکم، تهوع و بی‌اشتهایی. در آزمایش "
    "میکروسکوپی مدفوع، تخم آسکاریس.**\n\n"
    "**تشخیص روشن است. سؤال درباره‌ی انتخاب دارو در بارداری است.**\n\n"
    "⚠️ **قاعده: بنزیمیدازول‌ها (آلبندازول و مبندازول) در بارداری، به‌ویژه سه‌ماهه‌ی اول، "
    "پرهیز می‌شوند.**\n\n"
    "**چرا؟** این داروها در **مطالعات حیوانی تراتوژن و امبریوتوکسیک** بوده‌اند. اگرچه داده‌های "
    "انسانی نگران‌کننده‌ی قاطعی وجود ندارد و WHO در برنامه‌های کرم‌زدایی انبوه، آلبندازول را "
    "پس از سه‌ماهه‌ی اول مجاز می‌داند، **در سه‌ماهه‌ی اول احتیاط استاندارد است** — و این بیمار "
    "در **ماه سوم** یعنی همان سه‌ماهه‌ی اول است.\n\n"
    "**پس داروی انتخابی: پیرانتل پاموآت.**\n\n"
    "**چرا پیرانتل پاموآت در بارداری ایمن است؟** پاسخ، **فارماکوکینتیک** است: پیرانتل "
    "**جذب سیستمیک بسیار ناچیزی** دارد و تقریباً کامل در لومن روده باقی می‌ماند. **دارویی که "
    "وارد خون مادر نمی‌شود، به جنین هم نمی‌رسد.**\n\n"
    "**مکانیسم آن:** پیرانتل **فلج اسپاستیک** در کرم ایجاد می‌کند (گیرنده‌های نیکوتینی را "
    "تحریک می‌کند)، کرم به مخاط نمی‌چسبد و با حرکات دودی روده دفع می‌شود.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**آلبندازول ۴۰۰ تک‌دوز** و **آلبندازول ۴۰۰ سه روز:** هر دو **بنزیمیدازول** و در "
    "سه‌ماهه‌ی اول پرهیز می‌شوند. (و برای آسکاریس بدون عارضه، تک‌دوز کافی است؛ سه روز بی‌مورد.)\n\n"
    "⚠️ **ایورمکتین ۱۰ گرم تک‌دوز:** **دو ایراد جدی.** یک: ایورمکتین در بارداری "
    "**توصیه نمی‌شود** (داده‌های ایمنی کافی ندارد). دو: **دوز ۱۰ گرم به‌کلی غیرممکن است** — "
    "دوز ایورمکتین بر حسب **میکروگرم بر کیلوگرم** است (حدود ۲۰۰ میکروگرم/کیلوگرم)، یعنی "
    "برای فرد ۶۰ کیلویی حدود **۱۲ میلی‌گرم**. **۱۰ گرم حدود هزار برابر دوز درست است.**",
    "This question combines the ascaris treatment rule with ONE CONSTRAINT: PREGNANCY.\n\n"
    "THE PATIENT: a 23-year-old woman in the third month of pregnancy with abdominal pain, nausea and "
    "anorexia. Stool microscopy shows ascaris eggs.\n\n"
    "THE DIAGNOSIS IS CLEAR. The question is about drug choice in pregnancy.\n\n"
    "WARNING, THE RULE: THE BENZIMIDAZOLES (albendazole and mebendazole) ARE AVOIDED IN PREGNANCY, "
    "ESPECIALLY THE FIRST TRIMESTER.\n\n"
    "WHY? These drugs have been TERATOGENIC AND EMBRYOTOXIC IN ANIMAL STUDIES. Although there is no "
    "decisive human alarm and WHO permits albendazole after the first trimester in mass deworming "
    "programmes, CAUTION IN THE FIRST TRIMESTER IS STANDARD — and this patient is in her THIRD MONTH, "
    "that is, the first trimester.\n\n"
    "SO THE DRUG OF CHOICE: PYRANTEL PAMOATE.\n\n"
    "WHY IS PYRANTEL PAMOATE SAFE IN PREGNANCY? The answer is PHARMACOKINETIC: pyrantel has NEGLIGIBLE "
    "SYSTEMIC ABSORPTION and remains almost entirely in the bowel lumen. A DRUG THAT DOES NOT ENTER "
    "THE MOTHER'S BLOOD DOES NOT REACH THE FETUS.\n\n"
    "ITS MECHANISM: pyrantel produces SPASTIC PARALYSIS of the worm (by stimulating nicotinic "
    "receptors); the worm loses its grip on the mucosa and is passed by peristalsis.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ALBENDAZOLE 400 mg SINGLE DOSE and ALBENDAZOLE 400 mg FOR 3 DAYS: both are BENZIMIDAZOLES and are "
    "avoided in the first trimester. (And for uncomplicated ascaris a single dose suffices anyway; "
    "three days is unnecessary.)\n\n"
    "WARNING, IVERMECTIN 10 g SINGLE DOSE: TWO SERIOUS FAULTS. One: ivermectin IS NOT RECOMMENDED in "
    "pregnancy (inadequate safety data). Two: A 10 g DOSE IS ENTIRELY IMPOSSIBLE — ivermectin is dosed "
    "in MICROGRAMS PER KILOGRAM (about 200 micrograms/kg), which for a 60 kg person is about 12 mg. "
    "TEN GRAMS IS ROUGHLY A THOUSAND TIMES THE CORRECT DOSE.",
    ["بنزیمیدازول است و در سه‌ماهه‌ی اول بارداری پرهیز می‌شود.",
     "پاسخ صحیح — جذب سیستمیک ناچیز دارد، پس به جنین نمی‌رسد و در بارداری ایمن است.",
     "همان ایراد بنزیمیدازول، به‌علاوه‌ی اینکه سه روز برای آسکاریس بدون عارضه بی‌مورد است.",
     "دو ایراد — در بارداری توصیه نمی‌شود، و دوز ۱۰ گرم حدود هزار برابر دوز درست است."],
    ["A benzimidazole, avoided in the first trimester of pregnancy.",
     "Correct — negligible systemic absorption, so it does not reach the fetus and is safe in pregnancy.",
     "The same benzimidazole objection, plus three days being unnecessary for uncomplicated ascaris.",
     "Two faults — not recommended in pregnancy, and a 10 g dose is about a thousandfold too high."],
    "**پیرانتل جذب نمی‌شود، پس به جنین نمی‌رسد — همین آن را در بارداری ایمن می‌کند.**",
    "Pyrantel is not absorbed, so it does not reach the fetus — that is what makes it safe in pregnancy.",
    NREFS)

add("book:809", "vignette", "easy",
    "**آسکاریس در ماه ششم بارداری: باز هم پیرانتل پاموآت — و به تعویق انداختن درمان گزینه نیست.**",
    "Ascaris at six months' pregnancy: pyrantel pamoate again — and postponing treatment is not an option.",
    ASC_FA + [
        "**این بیمار علامت‌دار است: کهیر، سرفه و درد شکم.**",
        "**پس درمان لازم است و به تعویق انداختن آن قابل دفاع نیست.**",
        "⚠️ **کهیر و سرفه نشان می‌دهند که مهاجرت لاروی هم در جریان است.**",
        "**و آسکاریس درمان‌نشده در بارداری می‌تواند به انسداد یا کلانژیت برسد.**",
        "**پس با داروی ایمن درمان می‌کنیم، نه اینکه صبر کنیم.**",
        "**پیرانتل پاموآت همان داروی ایمن است.**",
    ],
    ASC_EN + [
        "This patient is symptomatic: urticaria, cough and abdominal pain.",
        "So treatment is needed and postponing it is not defensible.",
        "WARNING, THE URTICARIA AND COUGH suggest larval migration is also under way.",
        "And untreated ascaris in pregnancy can progress to obstruction or cholangitis.",
        "So we treat with a safe drug rather than wait.",
        "Pyrantel pamoate is that safe drug.",
    ],
    "کتاب همان قاعده را دوباره پرسیده، ولی این بار یک **گزینه‌ی وسوسه‌انگیز** اضافه کرده: "
    "**صبر کردن**.\n\n"
    "**بیمار: خانم باردار در ماه ششم، با ضایعات کهیری، سرفه و درد شکم. در آزمایش مدفوع، "
    "آسکاریس.**\n\n"
    "**دو تصمیم لازم است: درمان کنیم یا صبر؟ و اگر درمان، با چه دارویی؟**\n\n"
    "**تصمیم اول — درمان کنیم؟ بله، قطعاً.**\n\n"
    "⚠️ **چرا صبر کردن قابل دفاع نیست؟** چون بیمار **علامت‌دار** است: **درد شکم، سرفه و "
    "ضایعات کهیری**. کهیر و سرفه نشان می‌دهند که **واکنش آلرژیک به انگل و احتمالاً مهاجرت "
    "لاروی** در جریان است.\n\n"
    "**و مهم‌تر: آسکاریس درمان‌نشده در بارداری خطرناک است.** آلودگی می‌تواند به **انسداد "
    "روده، کلانژیت یا پانکراتیت** برسد — و هر کدام از این‌ها در بارداری **بسیار خطرناک‌تر** "
    "است، هم برای مادر و هم برای جنین. سه ماه صبر کردن یعنی سه ماه در معرض این خطرات.\n\n"
    "**تصمیم دوم — چه دارویی؟ پیرانتل پاموآت.** جذب سیستمیک ناچیزی دارد، پس به جنین نمی‌رسد.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**تجویز مبندازول:** بنزیمیدازول است. (نکته: بیمار در **ماه ششم** یعنی سه‌ماهه‌ی دوم "
    "است، و WHO در برنامه‌های کرم‌زدایی انبوه، آلبندازول را پس از سه‌ماهه‌ی اول مجاز می‌داند. "
    "ولی **وقتی گزینه‌ی کاملاً ایمن‌تری در دسترس است، انتخاب محتاطانه‌تر ارجح است** — و "
    "پیرانتل دقیقاً همان است.)\n\n"
    "**تجویز ایورمکتین:** در بارداری **توصیه نمی‌شود** (داده‌های ایمنی کافی ندارد)، و برای "
    "آسکاریس هم داروی خط اول نیست.\n\n"
    "⚠️ **به تأخیر انداختن درمان تا پایان بارداری:** **بدترین گزینه.** بیمار علامت‌دار است "
    "و خطر عوارض جدی وجود دارد. **وقتی داروی ایمنی در دسترس است، رها کردن بیمار علامت‌دار "
    "قابل دفاع نیست.**",
    "The book asks the same rule again, but this time it adds A TEMPTING OPTION: WAITING.\n\n"
    "THE PATIENT: a woman in her sixth month of pregnancy with urticarial lesions, cough and "
    "abdominal pain. The stool shows ascaris.\n\n"
    "TWO DECISIONS ARE NEEDED: treat or wait? And if treating, with what?\n\n"
    "FIRST DECISION — TREAT? YES, DEFINITELY.\n\n"
    "WARNING, WHY IS WAITING INDEFENSIBLE? Because the patient is SYMPTOMATIC: ABDOMINAL PAIN, COUGH "
    "AND URTICARIAL LESIONS. The urticaria and cough suggest AN ALLERGIC REACTION TO THE PARASITE AND "
    "PROBABLY LARVAL MIGRATION under way.\n\n"
    "AND MORE IMPORTANTLY: UNTREATED ASCARIS IN PREGNANCY IS DANGEROUS. The infection can progress to "
    "BOWEL OBSTRUCTION, CHOLANGITIS OR PANCREATITIS — and each of these is FAR MORE DANGEROUS IN "
    "PREGNANCY, for mother and fetus alike. Waiting three months means three months of that exposure.\n\n"
    "SECOND DECISION — WHICH DRUG? PYRANTEL PAMOATE. Its systemic absorption is negligible, so it does "
    "not reach the fetus.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "MEBENDAZOLE: a benzimidazole. (Note: the patient is in her SIXTH MONTH, the second trimester, and "
    "WHO permits albendazole after the first trimester in mass deworming programmes. But WHEN A FULLY "
    "SAFER OPTION IS AVAILABLE, THE MORE CAUTIOUS CHOICE IS PREFERRED — and pyrantel is exactly that.)\n\n"
    "IVERMECTIN: NOT RECOMMENDED in pregnancy (inadequate safety data), and not a first-line ascaris "
    "drug in any case.\n\n"
    "WARNING, POSTPONING TREATMENT UNTIL AFTER DELIVERY: THE WORST OPTION. The patient is symptomatic "
    "and at risk of serious complications. WHEN A SAFE DRUG IS AVAILABLE, ABANDONING A SYMPTOMATIC "
    "PATIENT IS INDEFENSIBLE.",
    ["بنزیمیدازول است؛ وقتی گزینه‌ی کاملاً ایمن‌تری در دسترس است، انتخاب محتاطانه‌تر ارجح است.",
     "در بارداری توصیه نمی‌شود و برای آسکاریس هم داروی خط اول نیست.",
     "بدترین گزینه — بیمار علامت‌دار است و خطر انسداد و کلانژیت وجود دارد.",
     "پاسخ صحیح — جذب سیستمیک ناچیز، پس در بارداری ایمن است و بیمار علامت‌دار را درمان می‌کند."],
    ["A benzimidazole; when a fully safer option exists, the more cautious choice is preferred.",
     "Not recommended in pregnancy, and not a first-line ascaris drug either.",
     "The worst option — the patient is symptomatic and at risk of obstruction and cholangitis.",
     "Correct — negligible systemic absorption, so it is safe in pregnancy and treats a symptomatic patient."],
    "**بیمار علامت‌دار + داروی ایمن در دسترس = صبر کردن قابل دفاع نیست.**",
    "A symptomatic patient plus an available safe drug = waiting is indefensible.",
    NREFS)

add("book:811", "vignette", "hard",
    "**انسداد آسکاریسی: پیپرازین — چون کرم را فلج شل می‌کند، نه اینکه بکشد.**",
    "Ascaris obstruction: PIPERAZINE — because it paralyses the worm flaccidly rather than killing it.",
    ASC_FA + [
        "**این سؤال یک انتخاب دارویی غیرشهودی را می‌سنجد و باید منطقش را بفهمید.**",
        "**بیمار انسداد کامل دارد: استفراغ و عدم دفع مدفوع از ۲۴ ساعت قبل.**",
        "**و تصویربرداری علت را نشان داده: کرم‌های لوله‌ای ۲۰ سانتی‌متری.**",
        "⚠️ **حالا مشکل: اگر کرم‌ها را بکشیم، توده‌ی مرده همان‌جا می‌ماند.**",
        "**کرم مرده سفت و بی‌حرکت می‌شود و می‌تواند انسداد را بدتر کند.**",
        "**پیپرازین کرم را نمی‌کشد؛ آن را فلج شل می‌کند.**",
        "**کرم شل، مثل یک طناب نرم، با حرکات دودی روده به جلو رانده می‌شود.**",
        "⚠️ **و شربت بودن آن هم عمدی است: از لوله‌ی معده در بیمار مسدود قابل تجویز است.**",
        "**همراه آن: مایعات وریدی، ساکشن معده، و پایش دقیق.**",
    ],
    ASC_EN + [
        "This question tests a counter-intuitive drug choice and its logic must be understood.",
        "The patient has complete obstruction: vomiting and no stool for 24 hours.",
        "And imaging has shown the cause: 20 cm tubular worms.",
        "WARNING, NOW THE PROBLEM: if we kill the worms, the dead mass stays where it is.",
        "A dead worm becomes rigid and immobile and can worsen the obstruction.",
        "Piperazine does not kill the worm; it paralyses it flaccidly.",
        "A limp worm, like a soft rope, is pushed forward by peristalsis.",
        "WARNING, AND ITS SYRUP FORM IS DELIBERATE: it can be given by nasogastric tube in an obstructed patient.",
        "Alongside it: intravenous fluids, gastric suction and close monitoring.",
    ],
    "این **هوشمندانه‌ترین سؤال بلوک کرم‌ها** است، چون یک انتخاب دارویی **غیرشهودی** را "
    "می‌سنجد که فقط با **فهمیدن مکانیسم** حل می‌شود.\n\n"
    "**بیمار: جوان ۲۵ ساله در منطقه‌ی حاره‌ی آفریقایی، با استفراغ، درد شکم و عدم دفع مدفوع "
    "از ۲۴ ساعت گذشته. در تصویربرداری، علت انسداد کرم‌های لوله‌ای ۲۰ سانتی‌متری است.**\n\n"
    "**تشخیص: انسداد روده ناشی از توده‌ی آسکاریس.**\n\n"
    "**حالا وسوسه‌ی طبیعی: «آسکاریس است، پس آلبندازول یا مبندازول بدهیم.»**\n\n"
    "⚠️ **و اینجا مشکل ظریفی وجود دارد: آلبندازول و مبندازول کرم را می‌کشند.**\n\n"
    "**چرا کشتن کرم در انسداد مشکل‌ساز است؟** کرم مرده **همان‌جا می‌ماند**. کرم زنده حرکت "
    "می‌کند و ممکن است خودش جابه‌جا شود؛ ولی **کرم مرده سفت و بی‌حرکت می‌شود** و توده‌ای از "
    "کرم‌های مرده در روده‌ی از قبل مسدود می‌تواند **انسداد را تثبیت یا بدتر کند**.\n\n"
    "**راه‌حل: پیپرازین.**\n\n"
    "**مکانیسم پیپرازین چیست؟** پیپرازین **آگونیست گیرنده‌ی GABA** در کرم است. نتیجه: "
    "**فلج شل (flaccid) کرم**. کرم **نمی‌میرد**، بلکه **کاملاً شل می‌شود** — مثل یک طناب "
    "نرم. و کرم شل با **حرکات دودی خود روده** به جلو رانده و **دفع می‌شود**.\n\n"
    "⚠️ **و چرا «شربت» پیپرازین؟ این هم عمدی است.** بیمار **انسداد کامل** دارد و نمی‌تواند "
    "قرص ببلعد. **شربت از لوله‌ی معده (NG) قابل تجویز است** — و همان لوله برای ساکشن و کاهش "
    "اتساع هم به‌کار می‌رود.\n\n"
    "**درمان کامل: پیپرازین از NG + مایعات وریدی + ساکشن معده + پایش دقیق.** اگر انسداد "
    "برطرف نشد یا نشانه‌های ایسکمی یا پرفوراسیون پیدا شد، **جراحی** لازم می‌شود.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**قرص آلبندازول ۴۰۰:** **دو ایراد** — کرم را می‌کشد (توده‌ی مرده)، و **قرص است** که "
    "بیمار مسدود نمی‌تواند ببلعد.\n\n"
    "**پنج قرص مبندازول یکجا:** **سه ایراد** — کرم را می‌کشد، قرص است، و **دوز پنج قرص یکجا "
    "هیچ مبنای علمی ندارد** و صرفاً خطرناک است.\n\n"
    "**شربت پیرانتل پاموآت:** شربت بودنش درست است، ولی پیرانتل **فلج اسپاستیک** می‌دهد "
    "(انقباض)، نه فلج شل. **کرم منقبض در انسداد کمکی نمی‌کند** — چیزی که لازم داریم شل شدن "
    "است تا کرم بتواند از تنگی عبور کند.",
    "This is THE CLEVEREST QUESTION IN THE HELMINTH BLOCK, because it tests a COUNTER-INTUITIVE drug "
    "choice that can only be solved BY UNDERSTANDING THE MECHANISM.\n\n"
    "THE PATIENT: a 25-year-old in tropical Africa with vomiting, abdominal pain and no stool for 24 "
    "hours. Imaging shows the cause of obstruction to be 20 cm tubular worms.\n\n"
    "THE DIAGNOSIS: bowel obstruction from a bolus of ascaris.\n\n"
    "NOW THE NATURAL TEMPTATION: 'it is ascaris, so give albendazole or mebendazole.'\n\n"
    "WARNING, AND HERE LIES A SUBTLE PROBLEM: ALBENDAZOLE AND MEBENDAZOLE KILL THE WORM.\n\n"
    "WHY IS KILLING THE WORM A PROBLEM IN OBSTRUCTION? A dead worm STAYS WHERE IT IS. A live worm "
    "moves and may shift on its own; but A DEAD WORM BECOMES RIGID AND IMMOBILE, and a mass of dead "
    "worms in an already obstructed bowel can FIX OR WORSEN THE OBSTRUCTION.\n\n"
    "THE SOLUTION: PIPERAZINE.\n\n"
    "WHAT IS PIPERAZINE'S MECHANISM? Piperazine is a GABA RECEPTOR AGONIST in the worm. The result: "
    "FLACCID PARALYSIS of the worm. The worm DOES NOT DIE; it BECOMES COMPLETELY LIMP — like a soft "
    "rope. And a limp worm is PUSHED FORWARD AND PASSED by the bowel's own peristalsis.\n\n"
    "WARNING, AND WHY PIPERAZINE 'SYRUP'? That is deliberate too. The patient has COMPLETE OBSTRUCTION "
    "and cannot swallow a tablet. A SYRUP CAN BE GIVEN BY NASOGASTRIC TUBE — and the same tube is used "
    "for suction to reduce distension.\n\n"
    "COMPLETE MANAGEMENT: piperazine by NG tube plus intravenous fluids plus gastric suction plus "
    "close monitoring. If the obstruction does not resolve or signs of ischaemia or perforation "
    "appear, SURGERY is required.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ALBENDAZOLE 400 mg TABLET: TWO FAULTS — it kills the worm (a dead mass), and IT IS A TABLET which "
    "an obstructed patient cannot swallow.\n\n"
    "FIVE MEBENDAZOLE TABLETS AT ONCE: THREE FAULTS — it kills the worm, it is a tablet, and A "
    "FIVE-TABLET BOLUS HAS NO SCIENTIFIC BASIS and is simply dangerous.\n\n"
    "PYRANTEL PAMOATE SYRUP: the syrup part is right, but pyrantel causes SPASTIC paralysis "
    "(contraction), not flaccid paralysis. A CONTRACTED WORM DOES NOT HELP IN OBSTRUCTION — what is "
    "needed is relaxation so the worm can pass through the narrowing.",
    ["دو ایراد — کرم را می‌کشد و توده‌ی مرده می‌سازد، و قرص است که بیمار مسدود نمی‌تواند ببلعد.",
     "سه ایراد — کرم را می‌کشد، قرص است، و دوز پنج قرص یکجا مبنای علمی ندارد.",
     "پاسخ صحیح — پیپرازین کرم را فلج شل می‌کند و شربت از لوله‌ی معده قابل تجویز است.",
     "شربت بودنش درست است ولی پیرانتل فلج اسپاستیک می‌دهد؛ کرم منقبض از تنگی عبور نمی‌کند."],
    ["Two faults — it kills the worm leaving a dead mass, and it is a tablet an obstructed patient cannot swallow.",
     "Three faults — it kills the worm, it is a tablet, and a five-tablet bolus has no scientific basis.",
     "Correct — piperazine paralyses the worm flaccidly, and the syrup can be given by nasogastric tube.",
     "The syrup is right but pyrantel causes spastic paralysis; a contracted worm will not pass the narrowing."],
    "**در انسداد، کرم را نکشید — شلش کنید تا روده خودش بیرونش بیندازد.**",
    "In obstruction, do not kill the worm — relax it so the bowel expels it itself.",
    NREFS)

add("book:812", "vignette", "medium",
    "**انسداد پارشیال آسکاریسی: پیپرازین از NG به‌علاوه‌ی مایعات وریدی — نه جراحی.**",
    "Partial ascaris obstruction: piperazine by NG tube plus intravenous fluids — not surgery.",
    ASC_FA + [
        "**اینجا انسداد پارشیال است، نه کامل — و همین درمان محافظه‌کارانه را ممکن می‌کند.**",
        "**در انسداد پارشیال، لومن هنوز تا حدی باز است.**",
        "⚠️ **پس با شل کردن کرم‌ها و حمایت مایعاتی، اغلب بدون جراحی حل می‌شود.**",
        "**جراحی برای شکست درمان محافظه‌کارانه یا نشانه‌های ایسکمی است.**",
        "**نشانه‌های خطر: پریتونیت، تب، لکوسیتوز بالا، اسیدوز و بی‌ثباتی همودینامیک.**",
        "**در نبود این‌ها، جراحی زودهنگام ریسک بدون سود است.**",
        "**و مایعات وریدی جزء لازم است، چون بیمار مسدود دهیدره و دچار اختلال الکترولیت است.**",
    ],
    ASC_EN + [
        "Here the obstruction is PARTIAL, not complete — and that is what makes conservative treatment possible.",
        "In partial obstruction the lumen is still somewhat open.",
        "WARNING, SO RELAXING THE WORMS AND GIVING FLUID SUPPORT usually resolves it without surgery.",
        "Surgery is for failed conservative treatment or signs of ischaemia.",
        "The danger signs: peritonitis, fever, a high white count, acidosis and haemodynamic instability.",
        "In their absence, early surgery is risk without benefit.",
        "And intravenous fluids are essential, because an obstructed patient is dehydrated with electrolyte derangement.",
    ],
    "این سؤال همان منطق سؤال قبلی است، ولی این بار **سؤال دوم را هم اضافه کرده: جراحی یا نه؟**\n\n"
    "**بیمار: به دنبال ابتلا به آسکاریس، دچار انسداد پارشیال روده شده است.**\n\n"
    "**دو تصمیم لازم است: کدام دارو، و آیا جراحی؟**\n\n"
    "⚠️ **تصمیم اول — دارو: پیپرازین.** همان منطق: **آلبندازول و مبندازول کرم را می‌کشند** و "
    "توده‌ی کرم‌های مرده می‌تواند انسداد را بدتر کند. **پیپرازین کرم را فلج شل می‌کند** و "
    "کرمِ شل با حرکات دودی روده دفع می‌شود.\n\n"
    "**تصمیم دوم — جراحی؟ نه.**\n\n"
    "**چرا؟ چون انسداد پارشیال است، نه کامل.** در انسداد پارشیال، **لومن هنوز تا حدی باز "
    "است** و محتویات می‌توانند عبور کنند. با **شل کردن کرم‌ها + حمایت مایعاتی + ساکشن**، "
    "**اغلب موارد بدون جراحی حل می‌شوند**.\n\n"
    "**جراحی کِی لازم است؟ نشانه‌های خطر را بشمارید:**\n\n"
    "**پریتونیت** (نشانه‌ی پرفوراسیون)، **تب و لکوسیتوز بالا**، **اسیدوز متابولیک** (نشانه‌ی "
    "ایسکمی روده)، **بی‌ثباتی همودینامیک**، یا **شکست درمان محافظه‌کارانه** پس از ۲۴ تا ۴۸ ساعت.\n\n"
    "**در نبود این‌ها، جراحی زودهنگام ریسک بدون سود است** — لاپاراتومی خودش عوارض دارد.\n\n"
    "⚠️ **و چرا مایعات وریدی جزء لازم درمان است؟** بیمار مسدود **استفراغ می‌کند و نمی‌تواند "
    "مایع بخورد** → **دهیدراتاسیون و اختلال الکترولیت** (به‌ویژه هیپوکالمی و آلکالوز از "
    "استفراغ). مایعات وریدی نه‌فقط حمایتی، بلکه **برای برگرداندن حرکات دودی مؤثر روده** هم "
    "لازم است — و حرکات دودی همان چیزی است که قرار است کرم‌های شل‌شده را بیرون براند.\n\n"
    "**پس گزینه‌ی درست: دادن پیپرازین با لوله‌ی NG همراه با مایعات وریدی.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**مبندازول با NG + جراحی:** دو ایراد — داروی کشنده‌ی کرم، و جراحی بی‌مورد.\n\n"
    "**مبندازول با NG + مایعات:** مایعات درست است، ولی **داروی اشتباه** (کشنده‌ی کرم).\n\n"
    "**آلبندازول با NG + جراحی:** هر دو جزء اشتباه — داروی کشنده، و جراحی بی‌مورد.",
    "This question uses the same logic as the previous one but ADDS A SECOND QUESTION: SURGERY OR NOT?\n\n"
    "THE PATIENT: has developed partial bowel obstruction following ascaris infection.\n\n"
    "TWO DECISIONS ARE NEEDED: which drug, and whether to operate?\n\n"
    "WARNING, FIRST DECISION — THE DRUG: PIPERAZINE. The same logic: ALBENDAZOLE AND MEBENDAZOLE KILL "
    "THE WORM, and a mass of dead worms can worsen the obstruction. PIPERAZINE PARALYSES THE WORM "
    "FLACCIDLY and the limp worm is passed by peristalsis.\n\n"
    "SECOND DECISION — SURGERY? NO.\n\n"
    "WHY? BECAUSE THE OBSTRUCTION IS PARTIAL, NOT COMPLETE. In partial obstruction THE LUMEN IS STILL "
    "SOMEWHAT OPEN and contents can pass. With RELAXATION OF THE WORMS PLUS FLUID SUPPORT PLUS "
    "SUCTION, MOST CASES RESOLVE WITHOUT SURGERY.\n\n"
    "WHEN IS SURGERY NEEDED? COUNT THE DANGER SIGNS:\n\n"
    "PERITONITIS (indicating perforation), FEVER AND A HIGH WHITE COUNT, METABOLIC ACIDOSIS "
    "(indicating bowel ischaemia), HAEMODYNAMIC INSTABILITY, or FAILURE OF CONSERVATIVE TREATMENT "
    "after 24 to 48 hours.\n\n"
    "IN THEIR ABSENCE, EARLY SURGERY IS RISK WITHOUT BENEFIT — a laparotomy has its own complications.\n\n"
    "WARNING, AND WHY ARE INTRAVENOUS FLUIDS AN ESSENTIAL COMPONENT? An obstructed patient IS VOMITING "
    "AND CANNOT DRINK, giving DEHYDRATION AND ELECTROLYTE DERANGEMENT (especially hypokalaemia and "
    "alkalosis from vomiting). Fluids are not merely supportive but are needed TO RESTORE EFFECTIVE "
    "PERISTALSIS — and peristalsis is precisely what is meant to expel the relaxed worms.\n\n"
    "SO THE CORRECT OPTION: PIPERAZINE BY NG TUBE WITH INTRAVENOUS FLUIDS.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "MEBENDAZOLE BY NG PLUS SURGERY: two faults — a worm-killing drug, and unnecessary surgery.\n\n"
    "MEBENDAZOLE BY NG PLUS FLUIDS: the fluids are right, but THE WRONG DRUG (worm-killing).\n\n"
    "ALBENDAZOLE BY NG PLUS SURGERY: both components wrong — a killing drug and unnecessary surgery.",
    ["دو ایراد — داروی کشنده‌ی کرم که توده‌ی مرده می‌سازد، و جراحی بی‌مورد در انسداد پارشیال.",
     "پاسخ صحیح — پیپرازین کرم را شل می‌کند و مایعات وریدی حرکات دودی را برمی‌گردانند.",
     "مایعات درست است ولی مبندازول کرم را می‌کشد و توده‌ی مرده می‌تواند انسداد را بدتر کند.",
     "هر دو جزء اشتباه — داروی کشنده‌ی کرم، و جراحی بی‌مورد در انسداد پارشیال."],
    ["Two faults — a worm-killing drug leaving a dead mass, and unnecessary surgery in partial obstruction.",
     "Correct — piperazine relaxes the worms and intravenous fluids restore peristalsis.",
     "The fluids are right but mebendazole kills the worm, and the dead mass can worsen the obstruction.",
     "Both components wrong — a worm-killing drug and unnecessary surgery in partial obstruction."],
    "**انسداد پارشیال: شل کن، مایع بده، صبر کن. جراحی فقط برای ایسکمی یا شکست درمان.**",
    "Partial obstruction: relax, hydrate, wait. Surgery only for ischaemia or failed treatment.",
    NREFS)

# ============================================== STRONGYLOIDES: THREE ITEMS
STR_FA = [
    "⚠️ **استرونژیلوئیدس تنها نماتودی است که چرخه‌ی خودآلودگی (autoinfection) دارد.**",
    "**یعنی لارو می‌تواند داخل خودِ بدن میزبان به شکل عفونی تبدیل شود.**",
    "**و دوباره از دیواره‌ی روده یا پوست پری‌آنال نفوذ کند.**",
    "**نتیجه: عفونت می‌تواند دهه‌ها بدون تماس مجدد ادامه یابد.**",
    "**مواردی گزارش شده که چهل سال پس از ترک منطقه‌ی اندمیک تشخیص داده شده‌اند.**",
    "⚠️ **و همین چرخه، خطر مرگبار آن را می‌سازد: هایپراینفکشن.**",
    "**در فرد دارای ایمنی سالم، ایمنی سلولی چرخه‌ی خودآلودگی را مهار می‌کند.**",
    "**کورتیکواستروئید دقیقاً همان مهار را برمی‌دارد.**",
    "**نتیجه: چرخه به‌طور انفجاری تسریع می‌شود و هزاران لارو مهاجرت می‌کنند.**",
    "**لاروها هنگام عبور از دیواره‌ی روده، باکتری‌های روده را با خود می‌برند.**",
    "⚠️ **پس سپسیس گرم منفی و مننژیت با باکتری روده‌ای، امضای هایپراینفکشن است.**",
    "**تابلوی تشخیصی: ائوزینوفیلی متناوب، کهیر باسن، و درد اپی‌گاستر.**",
    "**کهیر خطی و مهاجر باسن نام خاصی دارد: لاروا کورنس.**",
    "**و نکته‌ی حیاتی: آزمایش مدفوع اغلب منفی است، چون دفع لارو متناوب است.**",
    "⚠️ **پس مدفوع منفی هرگز استرونژیلوئیدس را رد نمی‌کند.**",
    "**درمان: ایورمکتین، که داروی انتخابی است.**",
    "**و قاعده‌ی طلایی: پیش از شروع کورتیکواستروئید در فرد از منطقه‌ی اندمیک، غربالگری کنید.**",
]
STR_EN = [
    "WARNING: STRONGYLOIDES IS THE ONLY NEMATODE WITH AN AUTOINFECTION CYCLE.",
    "That means the larva can become infective inside the host's own body.",
    "And penetrate again through the bowel wall or the perianal skin.",
    "The result: the infection can persist for DECADES without any further exposure.",
    "Cases have been reported diagnosed forty years after leaving the endemic area.",
    "WARNING, AND THAT SAME CYCLE CREATES ITS LETHAL DANGER: HYPERINFECTION.",
    "In an immunocompetent host, cell-mediated immunity restrains the autoinfection cycle.",
    "Corticosteroids remove precisely that restraint.",
    "The result: the cycle accelerates explosively and thousands of larvae migrate.",
    "As the larvae cross the bowel wall they carry gut bacteria with them.",
    "WARNING, SO GRAM-NEGATIVE SEPSIS and meningitis with an enteric organism is the hyperinfection signature.",
    "The diagnostic picture: intermittent eosinophilia, buttock urticaria and epigastric pain.",
    "The migrating linear urticaria of the buttock has a specific name: LARVA CURRENS.",
    "And the vital point: the stool is often negative, because larval excretion is intermittent.",
    "WARNING, SO A NEGATIVE STOOL NEVER EXCLUDES STRONGYLOIDES.",
    "Treatment: IVERMECTIN, the drug of choice.",
    "And the golden rule: SCREEN before starting corticosteroids in anyone from an endemic area.",
]

add("book:815", "vignette", "hard",
    "**پردنیزولون + سپسیس گرم منفی + ائوزینوفیلی + کهیر باسن = هایپراینفکشن استرونژیلوئیدس.**",
    "Prednisolone plus gram-negative sepsis plus eosinophilia plus buttock urticaria = STRONGYLOIDES HYPERINFECTION.",
    STR_FA,
    STR_EN,
    "این **مهم‌ترین سؤال بالینی فصل انگلی** است، چون یک وضعیت **کشنده و قابل پیشگیری** را "
    "توصیف می‌کند.\n\n"
    "**بیمار: پس از دریافت دوز بالای پردنیزولون برای پمفیگوس، دچار سپسیس شده و در کشت خون "
    "باسیل گرم منفی رشد کرده است. سابقه: ائوزینوفیلی متناوب، کهیر در ناحیه‌ی باسن، و درد "
    "اپی‌گاستر. و آزمایش مدفوع از نظر تخم و لارو انگل منفی است.**\n\n"
    "**بیایید هر جزء را بخوانیم، چون هر کدام یک قطعه از پازل است:**\n\n"
    "⚠️ **دوز بالای پردنیزولون** — این محرک اصلی است. **کورتیکواستروئید، ایمنی سلولی را "
    "سرکوب می‌کند**، و ایمنی سلولی دقیقاً همان چیزی است که **چرخه‌ی خودآلودگی استرونژیلوئیدس "
    "را مهار می‌کند**.\n\n"
    "**سپسیس با باسیل گرم منفی** — و این **امضای قطعی** است. چرا؟ چون **لاروهای مهاجر هنگام "
    "عبور از دیواره‌ی روده، باکتری‌های روده‌ای را با خود به جریان خون می‌برند**. پس سپسیس گرم "
    "منفی (و گاهی مننژیت با ارگانیسم روده‌ای) در بیمار تحت استروئید، باید فوراً به "
    "استرونژیلوئیدس فکر کنیم.\n\n"
    "**ائوزینوفیلی متناوب** — نشانه‌ی عفونت انگلی مزمن. (نکته: در **هایپراینفکشن فعال، "
    "ائوزینوفیلی ممکن است غایب باشد** — چون استروئید آن را سرکوب می‌کند. پس ائوزینوفیلی "
    "**سابقه‌دار** ارزش تشخیصی دارد.)\n\n"
    "**کهیر در ناحیه‌ی باسن** — این **لاروا کورنس** است: کهیر **خطی و مهاجر** که از مسیر "
    "حرکت لارو زیر پوست می‌آید، معمولاً در ناحیه‌ی پری‌آنال و باسن (جایی که لارو از پوست دوباره "
    "نفوذ می‌کند). **این تقریباً پاتوگنومونیک است.**\n\n"
    "**درد اپی‌گاستر** — از حضور کرم در دئودنوم و ژژنوم.\n\n"
    "⚠️ **و آزمایش مدفوع منفی — که این را نباید گمراهتان کند.** **دفع لارو در استرونژیلوئیدس "
    "متناوب است** و یک نمونه‌ی مدفوع حساسیت پایینی دارد (حدود ۳۰ درصد). **مدفوع منفی هرگز "
    "استرونژیلوئیدس را رد نمی‌کند.** برای تشخیص، **سرولوژی**، **نمونه‌های مکرر مدفوع**، یا "
    "**آسپیره‌ی دئودنال** لازم است.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**آسکاریس لومبریکوئیدس:** ائوزینوفیلی می‌دهد ولی **چرخه‌ی خودآلودگی ندارد** و "
    "**هایپراینفکشن نمی‌دهد**. عوارض آن مکانیکی‌اند.\n\n"
    "**انتروبیوس ورمیکولاریس (کرمک):** خارش پری‌آنال می‌دهد ولی **هرگز سپسیس نمی‌سازد** و "
    "چرخه‌اش کاملاً روده‌ای است.\n\n"
    "**تریکوریس تریکیورا (کرم شالقی):** پرولاپس رکتوم و اسهال خونی می‌دهد، **نه سپسیس گرم "
    "منفی**.\n\n"
    "⚠️ **و قاعده‌ی طلایی که جان می‌نجات می‌دهد: پیش از شروع کورتیکواستروئید در هر فردی که "
    "از منطقه‌ی اندمیک آمده یا ائوزینوفیلی بی‌دلیل دارد، برای استرونژیلوئیدس غربالگری کنید "
    "(سرولوژی) و در صورت مثبت بودن، پیش از استروئید با ایورمکتین درمان کنید.**",
    "This is THE MOST IMPORTANT CLINICAL QUESTION IN THE PARASITOLOGY CHAPTER, because it describes a "
    "LETHAL AND PREVENTABLE situation.\n\n"
    "THE PATIENT: after high-dose prednisolone for pemphigus he has developed sepsis, and blood "
    "culture has grown a GRAM-NEGATIVE BACILLUS. History: intermittent eosinophilia, urticaria over "
    "the buttocks, and epigastric pain. And the stool is negative for ova and larvae.\n\n"
    "LET US READ EACH PIECE, BECAUSE EACH IS A PART OF THE PUZZLE:\n\n"
    "WARNING, HIGH-DOSE PREDNISOLONE — this is the trigger. CORTICOSTEROIDS SUPPRESS CELL-MEDIATED "
    "IMMUNITY, and cell-mediated immunity is precisely what RESTRAINS THE STRONGYLOIDES AUTOINFECTION "
    "CYCLE.\n\n"
    "GRAM-NEGATIVE SEPSIS — and this is THE DECISIVE SIGNATURE. Why? Because AS THE MIGRATING LARVAE "
    "CROSS THE BOWEL WALL THEY CARRY GUT BACTERIA WITH THEM INTO THE BLOODSTREAM. So gram-negative "
    "sepsis (and sometimes meningitis with an enteric organism) in a steroid-treated patient must "
    "prompt immediate thought of strongyloides.\n\n"
    "INTERMITTENT EOSINOPHILIA — a sign of chronic parasitic infection. (Note: IN ACTIVE "
    "HYPERINFECTION EOSINOPHILIA MAY BE ABSENT, because the steroid suppresses it. So a HISTORY of "
    "eosinophilia carries the diagnostic value.)\n\n"
    "URTICARIA OVER THE BUTTOCKS — this is LARVA CURRENS: a LINEAR, MIGRATING urticaria tracing the "
    "larva's path under the skin, typically perianally and over the buttocks (where the larva "
    "re-penetrates the skin). THIS IS ALMOST PATHOGNOMONIC.\n\n"
    "EPIGASTRIC PAIN — from the worm in the duodenum and jejunum.\n\n"
    "WARNING, AND THE NEGATIVE STOOL — which must not mislead you. LARVAL EXCRETION IN STRONGYLOIDES "
    "IS INTERMITTENT and a single stool sample has low sensitivity (about 30%). A NEGATIVE STOOL NEVER "
    "EXCLUDES STRONGYLOIDES. Diagnosis requires SEROLOGY, REPEATED STOOL SAMPLES, or DUODENAL ASPIRATE.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ASCARIS LUMBRICOIDES: causes eosinophilia but HAS NO AUTOINFECTION CYCLE and DOES NOT CAUSE "
    "HYPERINFECTION. Its complications are mechanical.\n\n"
    "ENTEROBIUS VERMICULARIS (pinworm): causes perianal itch but NEVER CAUSES SEPSIS, and its cycle is "
    "entirely intestinal.\n\n"
    "TRICHURIS TRICHIURA (whipworm): causes rectal prolapse and bloody diarrhoea, NOT GRAM-NEGATIVE "
    "SEPSIS.\n\n"
    "WARNING, AND THE GOLDEN RULE THAT SAVES LIVES: BEFORE STARTING CORTICOSTEROIDS IN ANYONE FROM AN "
    "ENDEMIC AREA OR WITH UNEXPLAINED EOSINOPHILIA, SCREEN FOR STRONGYLOIDES (serology) AND, IF "
    "POSITIVE, TREAT WITH IVERMECTIN BEFORE THE STEROID.",
    ["ائوزینوفیلی می‌دهد ولی چرخه‌ی خودآلودگی ندارد و هایپراینفکشن نمی‌سازد.",
     "خارش پری‌آنال می‌دهد ولی هرگز سپسیس نمی‌سازد؛ چرخه‌اش کاملاً روده‌ای است.",
     "پرولاپس رکتوم و اسهال خونی می‌دهد، نه سپسیس گرم منفی در بیمار تحت استروئید.",
     "پاسخ صحیح — تنها نماتود با چرخه‌ی خودآلودگی، که استروئید آن را به هایپراینفکشن تبدیل می‌کند."],
    ["Causes eosinophilia but has no autoinfection cycle and does not cause hyperinfection.",
     "Causes perianal itch but never causes sepsis; its cycle is entirely intestinal.",
     "Causes rectal prolapse and bloody diarrhoea, not gram-negative sepsis in a steroid-treated patient.",
     "Correct — the only nematode with an autoinfection cycle, which steroids convert into hyperinfection."],
    "**لارو باکتری روده را با خود به خون می‌برد — پس سپسیس گرم منفی امضای آن است.**",
    "The larva carries gut bacteria into the blood — so gram-negative sepsis is its signature.",
    NREFS)

add("book:816", "recall", "easy",
    "**استرونژیلوئیدس تنها کرم روده‌ای است که در نقص ایمنی عفونت منتشر کشنده می‌دهد.**",
    "Strongyloides is the only intestinal worm that causes lethal disseminated infection in immunodeficiency.",
    STR_FA,
    STR_EN,
    "این سؤال همان قاعده را **مستقیم** می‌پرسد و به همین دلیل ارزش دارد که پاسخ را با "
    "**دلیلش** یاد بگیرید، نه فقط به‌عنوان یک واقعیت.\n\n"
    "⚠️ **استرونژیلوئیدس استرکورالیس تنها کرم روده‌ای است که در فرد دچار نقص ایمنی، عفونت "
    "منتشر سیستمیک و کشنده می‌دهد.**\n\n"
    "**چرا فقط این یکی؟ به دلیل ویژگی منحصربه‌فرد آن: چرخه‌ی خودآلودگی (autoinfection).**\n\n"
    "**در همه‌ی کرم‌های روده‌ای دیگر:** کرم در روده تخم می‌گذارد، تخم با مدفوع بیرون می‌رود، "
    "و برای عفونت جدید **باید دوباره از محیط بلعیده شود یا از پوست وارد شود**. یعنی "
    "**تعداد کرم‌ها بدون تماس مجدد افزایش نمی‌یابد**.\n\n"
    "**در استرونژیلوئیدس:** **لارو می‌تواند داخل خودِ بدن میزبان به شکل عفونی (فیلاریفرم) "
    "تبدیل شود** و **دوباره از دیواره‌ی روده یا پوست پری‌آنال نفوذ کند**. یعنی چرخه **بدون "
    "خروج از بدن** کامل می‌شود.\n\n"
    "**دو پیامد دارد:**\n\n"
    "**یک — ماندگاری دهه‌ها.** عفونت می‌تواند **چهل سال** پس از ترک منطقه‌ی اندمیک هم زنده "
    "بماند. موارد متعددی در کهنه‌سربازان جنگ جهانی دوم دهه‌ها بعد تشخیص داده شده‌اند.\n\n"
    "⚠️ **دو — هایپراینفکشن در سرکوب ایمنی.** ایمنی سلولی این چرخه را در حد پایینی نگه "
    "می‌دارد. **کورتیکواستروئید (یا HTLV-1، یا شیمی‌درمانی) این مهار را برمی‌دارد** و چرخه "
    "**انفجاری** می‌شود: هزاران لارو از روده به ریه، مغز، کبد و همه‌جا مهاجرت می‌کنند.\n\n"
    "**و کشنده بودن آن از دو راه است:** **آسیب مستقیم چندارگانی**، و مهم‌تر: **سپسیس گرم "
    "منفی** — چون لاروها هنگام عبور از دیواره‌ی روده **باکتری‌های روده را با خود می‌برند**. "
    "**مرگ‌ومیر هایپراینفکشن درمان‌نشده بیش از ۸۰ درصد است.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**آسکاریس:** بزرگ‌ترین نماتود روده‌ای، ولی **چرخه‌ی خودآلودگی ندارد**. عوارضش مکانیکی‌اند.\n\n"
    "**تریکواسترونژیلیازیس:** عفونت نسبتاً خفیفی است که معمولاً بی‌علامت یا با علائم گوارشی "
    "خفیف همراه است. **منتشر نمی‌شود.**\n\n"
    "**آنیزاکیازیس:** از خوردن **ماهی خام** می‌آید. لارو به دیواره‌ی معده یا روده نفوذ می‌کند "
    "و **درد حاد شکم** می‌دهد. **در انسان به بلوغ نمی‌رسد و منتشر نمی‌شود** — عفونت خودمحدود است.",
    "This question asks the same rule DIRECTLY, and for that reason it is worth learning the answer "
    "WITH ITS REASON rather than as a bare fact.\n\n"
    "WARNING, STRONGYLOIDES STERCORALIS IS THE ONLY INTESTINAL WORM THAT CAUSES DISSEMINATED, LETHAL "
    "SYSTEMIC INFECTION IN AN IMMUNODEFICIENT HOST.\n\n"
    "WHY ONLY THIS ONE? Because of its unique feature: THE AUTOINFECTION CYCLE.\n\n"
    "IN EVERY OTHER INTESTINAL WORM: the worm lays eggs in the bowel, the eggs leave in the stool, and "
    "for a new infection they MUST BE SWALLOWED FROM THE ENVIRONMENT AGAIN OR PENETRATE THE SKIN. That "
    "is, THE WORM BURDEN DOES NOT INCREASE WITHOUT RE-EXPOSURE.\n\n"
    "IN STRONGYLOIDES: THE LARVA CAN BECOME INFECTIVE (FILARIFORM) INSIDE THE HOST'S OWN BODY and "
    "PENETRATE AGAIN through the bowel wall or the perianal skin. The cycle completes WITHOUT EVER "
    "LEAVING THE BODY.\n\n"
    "THIS HAS TWO CONSEQUENCES:\n\n"
    "ONE — PERSISTENCE FOR DECADES. The infection can survive FORTY YEARS after leaving the endemic "
    "area. Many cases were diagnosed in Second World War veterans decades later.\n\n"
    "WARNING, TWO — HYPERINFECTION UNDER IMMUNOSUPPRESSION. Cell-mediated immunity keeps the cycle at "
    "a low level. CORTICOSTEROIDS (or HTLV-1, or chemotherapy) REMOVE THAT RESTRAINT and the cycle "
    "becomes EXPLOSIVE: thousands of larvae migrate from the bowel to lung, brain, liver and everywhere.\n\n"
    "AND ITS LETHALITY HAS TWO ROUTES: DIRECT MULTI-ORGAN DAMAGE, and more importantly GRAM-NEGATIVE "
    "SEPSIS — because as the larvae cross the bowel wall THEY CARRY GUT BACTERIA WITH THEM. MORTALITY "
    "OF UNTREATED HYPERINFECTION EXCEEDS 80%.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ASCARIS: the largest intestinal nematode, but it HAS NO AUTOINFECTION CYCLE. Its complications "
    "are mechanical.\n\n"
    "TRICHOSTRONGYLIASIS: a relatively mild infection, usually asymptomatic or with mild "
    "gastrointestinal symptoms. IT DOES NOT DISSEMINATE.\n\n"
    "ANISAKIASIS: acquired from eating RAW FISH. The larva penetrates the stomach or bowel wall and "
    "causes ACUTE ABDOMINAL PAIN. IT DOES NOT MATURE IN HUMANS AND DOES NOT DISSEMINATE — the "
    "infection is self-limited.",
    ["بزرگ‌ترین نماتود روده‌ای است ولی چرخه‌ی خودآلودگی ندارد؛ عوارضش مکانیکی‌اند.",
     "پاسخ صحیح — تنها کرمی با چرخه‌ی خودآلودگی، که در سرکوب ایمنی به هایپراینفکشن کشنده می‌رسد.",
     "عفونت نسبتاً خفیفی است که معمولاً بی‌علامت است و منتشر نمی‌شود.",
     "از ماهی خام می‌آید و درد حاد شکم می‌دهد؛ در انسان بالغ نمی‌شود و منتشر نمی‌شود."],
    ["The largest intestinal nematode, but it has no autoinfection cycle; its complications are mechanical.",
     "Correct — the only worm with an autoinfection cycle, which under immunosuppression becomes lethal hyperinfection.",
     "A relatively mild infection, usually asymptomatic, which does not disseminate.",
     "Acquired from raw fish, causing acute abdominal pain; it does not mature in humans or disseminate."],
    "**خودآلودگی = ماندگاری دهه‌ها + هایپراینفکشن زیر استروئید.**",
    "Autoinfection means persistence for decades plus hyperinfection under steroids.",
    NREFS)

add("book:810", "vignette", "medium",
    "**لارو رابدیتیفرم در مدفوع = استرونژیلوئیدس، و داروی انتخابی آن ایورمکتین است.**",
    "A rhabditiform larva in the stool = strongyloides, and its drug of choice is IVERMECTIN.",
    STR_FA + [
        "**یک نکته‌ی تشخیصی مهم: در مدفوع تازه، لارو دیده می‌شود، نه تخم.**",
        "**در بقیه‌ی نماتودهای روده‌ای، آنچه در مدفوع می‌بینیم تخم است.**",
        "⚠️ **ولی تخم استرونژیلوئیدس در خودِ مخاط روده تفریخ می‌شود.**",
        "**پس آنچه دفع می‌شود لارو رابدیتیفرم است، نه تخم.**",
        "**و همین یافته، تشخیص را به‌تنهایی می‌دهد.**",
        "**ایورمکتین داروی انتخابی است و از آلبندازول مؤثرتر.**",
    ],
    STR_EN + [
        "An important diagnostic point: in fresh stool it is LARVAE that are seen, not eggs.",
        "In the other intestinal nematodes, what we see in the stool is the egg.",
        "WARNING, BUT THE STRONGYLOIDES EGG HATCHES WITHIN THE BOWEL MUCOSA ITSELF.",
        "So what is passed is a RHABDITIFORM LARVA, not an egg.",
        "And that finding alone makes the diagnosis.",
        "Ivermectin is the drug of choice and is more effective than albendazole.",
    ],
    "این سؤال یک **یافته‌ی آزمایشگاهی اختصاصی** را می‌سنجد.\n\n"
    "**بیمار: درد شکمی که با خوردن غذا بدتر می‌شود. در آزمایش مدفوع، لارو رابدیتیفرم گزارش "
    "شده.**\n\n"
    "⚠️ **لارو رابدیتیفرم در مدفوع تازه = استرونژیلوئیدس استرکورالیس.**\n\n"
    "**چرا این یافته اختصاصی است؟ یک نکته‌ی چرخه‌ی زندگی آن را توضیح می‌دهد:**\n\n"
    "**در همه‌ی نماتودهای روده‌ای دیگر** (آسکاریس، کرم قلاب‌دار، شالقی، کرمک)، **آنچه در مدفوع "
    "می‌بینیم تخم است**. تخم پس از دفع، در محیط تفریخ می‌شود.\n\n"
    "**ولی در استرونژیلوئیدس، تخم در خودِ مخاط روده تفریخ می‌شود** و لارو آزاد می‌شود. پس "
    "**آنچه در مدفوع دفع می‌شود، لارو رابدیتیفرم است، نه تخم**.\n\n"
    "**نکته‌ی عملی: «در مدفوع تازه» مهم است.** اگر نمونه‌ی مدفوع مدتی بماند، تخم کرم قلاب‌دار "
    "هم می‌تواند تفریخ شود و لارو بدهد — که با لارو استرونژیلوئیدس اشتباه می‌شود. پس **نمونه "
    "باید تازه بررسی شود**.\n\n"
    "**و درد شکمی که با غذا بدتر می‌شود** با محل کرم هم‌خوان است: **دئودنوم و ژژنوم** — که "
    "می‌تواند با زخم پپتیک اشتباه شود.\n\n"
    "**درمان: ایورمکتین، داروی انتخابی.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**امپرازول:** مهارکننده‌ی پمپ پروتون است. **علامت را می‌پوشاند** (چون درد شبیه زخم پپتیک "
    "است) ولی **انگل را درمان نمی‌کند**. ⚠️ **و این خطرناک است**: بیمار درمان‌نشده می‌ماند و "
    "اگر روزی استروئید بگیرد، هایپراینفکشن کشنده رخ می‌دهد.\n\n"
    "**مبندازول:** روی استرونژیلوئیدس **کارایی ضعیفی** دارد. (آلبندازول بهتر از مبندازول است "
    "ولی همچنان از ایورمکتین ضعیف‌تر.)\n\n"
    "**پیرانتل پاموآت:** برای **آسکاریس، کرمک و کرم قلاب‌دار** است. **روی استرونژیلوئیدس "
    "مؤثر نیست.**\n\n"
    "**و یادآوری قاعده‌ی طلایی: هر بیمار مبتلا به استرونژیلوئیدس باید پیش از هرگونه "
    "کورتیکواستروئید یا شیمی‌درمانی، کاملاً درمان شود.**",
    "This question tests A SPECIFIC LABORATORY FINDING.\n\n"
    "THE PATIENT: abdominal pain that worsens with eating. The stool report shows a RHABDITIFORM LARVA.\n\n"
    "WARNING, A RHABDITIFORM LARVA IN FRESH STOOL = STRONGYLOIDES STERCORALIS.\n\n"
    "WHY IS THIS FINDING SPECIFIC? One life-cycle point explains it:\n\n"
    "IN EVERY OTHER INTESTINAL NEMATODE (ascaris, hookworm, whipworm, pinworm), WHAT WE SEE IN THE "
    "STOOL IS THE EGG. The egg hatches in the environment after being passed.\n\n"
    "BUT IN STRONGYLOIDES THE EGG HATCHES WITHIN THE BOWEL MUCOSA ITSELF and the larva is released. So "
    "WHAT IS PASSED IN THE STOOL IS A RHABDITIFORM LARVA, NOT AN EGG.\n\n"
    "A PRACTICAL POINT: 'IN FRESH STOOL' MATTERS. If a stool sample stands for a while, hookworm eggs "
    "can also hatch and release larvae, which are then confused with strongyloides larvae. So THE "
    "SAMPLE MUST BE EXAMINED FRESH.\n\n"
    "AND ABDOMINAL PAIN WORSENED BY EATING fits the worm's location: THE DUODENUM AND JEJUNUM — which "
    "can be mistaken for peptic ulcer.\n\n"
    "TREATMENT: IVERMECTIN, the drug of choice.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "OMEPRAZOLE: a proton pump inhibitor. It MASKS THE SYMPTOM (since the pain resembles peptic ulcer) "
    "but DOES NOT TREAT THE PARASITE. WARNING, AND THAT IS DANGEROUS: the patient remains untreated, "
    "and if he ever receives steroids, lethal hyperinfection follows.\n\n"
    "MEBENDAZOLE: has POOR ACTIVITY against strongyloides. (Albendazole is better than mebendazole but "
    "still weaker than ivermectin.)\n\n"
    "PYRANTEL PAMOATE: for ASCARIS, PINWORM AND HOOKWORM. NOT EFFECTIVE AGAINST STRONGYLOIDES.\n\n"
    "AND A REMINDER OF THE GOLDEN RULE: EVERY PATIENT WITH STRONGYLOIDES MUST BE FULLY TREATED BEFORE "
    "ANY CORTICOSTEROID OR CHEMOTHERAPY.",
    ["علامت را می‌پوشاند ولی انگل را درمان نمی‌کند؛ و بیمار درمان‌نشده در معرض هایپراینفکشن است.",
     "پاسخ صحیح — ایورمکتین داروی انتخابی استرونژیلوئیدس است.",
     "روی استرونژیلوئیدس کارایی ضعیفی دارد؛ ایورمکتین به‌مراتب مؤثرتر است.",
     "برای آسکاریس، کرمک و کرم قلاب‌دار است؛ روی استرونژیلوئیدس مؤثر نیست."],
    ["Masks the symptom without treating the parasite, and an untreated patient risks hyperinfection.",
     "Correct — ivermectin is the drug of choice for strongyloides.",
     "Has poor activity against strongyloides; ivermectin is far more effective.",
     "For ascaris, pinworm and hookworm; not effective against strongyloides."],
    "**در مدفوع، بقیه تخم می‌دهند — استرونژیلوئیدس لارو می‌دهد.**",
    "In stool the others give eggs — strongyloides gives larvae.",
    NREFS)

# ============================================== CESTODES: THREE ITEMS
CES_FA = [
    "⚠️ **دو تنیا را با میزبان واسط از هم جدا کنید: ساژیناتا گاو، سولیوم خوک.**",
    "**تنیا ساژیناتا از گوشت گاو نیم‌پز می‌آید و بی‌آزارتر است.**",
    "**تنیا سولیوم از گوشت خوک می‌آید و خطر واقعی آن جای دیگری است.**",
    "**خطر سولیوم، خودِ کرم بالغ نیست — سیستی‌سرکوز است.**",
    "⚠️ **اگر انسان تخم سولیوم را ببلعد، خودش میزبان واسط می‌شود.**",
    "**لارو از روده وارد خون می‌شود و در بافت‌ها کیست می‌بندد.**",
    "**و مهم‌ترین محل آن مغز است: نوروسیستی‌سرکوز.**",
    "**نوروسیستی‌سرکوز شایع‌ترین علت تشنج اکتسابی در بسیاری از کشورهای در حال توسعه است.**",
    "**تصویربرداری: کیست‌های متعدد، برخی کلسیفیه، گاهی با اسکولکس قابل رؤیت.**",
    "⚠️ **درمان کرم بالغ تنیا در روده: پرازی‌کوانتل تک‌دوز.**",
    "**و درمان نوروسیستی‌سرکوز پیچیده‌تر است: آلبندازول به‌علاوه‌ی کورتیکواستروئید.**",
    "**چرا استروئید؟ چون مرگ کیست‌ها واکنش التهابی شدیدی در مغز می‌سازد.**",
    "**و در صورت لزوم، ضدتشنج هم اضافه می‌شود.**",
    "**نکته‌ی افتراقی: ساژیناتا نوروسیستی‌سرکوز نمی‌دهد، چون تخم آن در انسان کیست نمی‌بندد.**",
]
CES_EN = [
    "WARNING: SEPARATE THE TWO TAENIAS BY THEIR INTERMEDIATE HOST: saginata is beef, solium is pork.",
    "Taenia saginata comes from undercooked beef and is the more harmless of the two.",
    "Taenia solium comes from pork, and its real danger lies elsewhere.",
    "The danger of solium is not the adult worm — it is CYSTICERCOSIS.",
    "WARNING, IF A HUMAN SWALLOWS SOLIUM EGGS, HE BECOMES THE INTERMEDIATE HOST HIMSELF.",
    "The larva enters the blood from the bowel and encysts in the tissues.",
    "And its most important site is the brain: NEUROCYSTICERCOSIS.",
    "Neurocysticercosis is the commonest cause of acquired seizures in many developing countries.",
    "Imaging: multiple cysts, some calcified, sometimes with a visible scolex.",
    "WARNING, TREATMENT OF THE ADULT INTESTINAL TAPEWORM: praziquantel, single dose.",
    "And treatment of neurocysticercosis is more complex: albendazole plus a corticosteroid.",
    "Why the steroid? Because dying cysts provoke an intense inflammatory reaction in the brain.",
    "And an anticonvulsant is added when needed.",
    "A differentiating point: saginata does not cause neurocysticercosis, because its eggs do not encyst in humans.",
]

add("book:822", "vignette", "medium",
    "**تخم تنیا ساژیناتا در مدفوع: پرازی‌کوانتل — کرم پهن، پس پرازی‌کوانتل.**",
    "Taenia saginata eggs in the stool: PRAZIQUANTEL — a flatworm, so praziquantel.",
    CES_FA + [
        "**در این بیمار، آزمایش مدفوع تخم تنیا ساژیناتا را مستقیماً نشان داده است.**",
        "**پس تشخیص قطعی است و فقط انتخاب دارو می‌ماند.**",
        "⚠️ **قاعده‌ی دارویی: کرم پهن (سستود و ترماتود) → پرازی‌کوانتل.**",
        "**و کرم گرد (نماتود) → بنزیمیدازول یا ایورمکتین.**",
        "**ائوزینوفیلی ۱۰ درصد هم با عفونت انگلی هم‌خوان است.**",
    ],
    CES_EN + [
        "In this patient the stool has shown Taenia saginata eggs directly.",
        "So the diagnosis is certain and only the drug choice remains.",
        "WARNING, THE DRUG RULE: FLATWORM (cestode and trematode) means PRAZIQUANTEL.",
        "And roundworm (nematode) means a benzimidazole or ivermectin.",
        "An eosinophilia of 10% is also consistent with parasitic infection.",
    ],
    "این سؤال با **یک قاعده‌ی دارویی** حل می‌شود، و آن قاعده کل بلوک کرم‌ها را سازمان می‌دهد.\n\n"
    "**بیمار: درد مزمن شکمی با ضعف و بی‌حالی. در آزمایشات: WBC=7500 با ۶۵٪ نوتروفیل، ۲۵٪ "
    "لنفوسیت و ۱۰٪ ائوزینوفیل. و در مدفوع: تخم تنیا ساژیناتا.**\n\n"
    "**تشخیص مستقیماً داده شده است. پس سؤال فقط درباره‌ی دارو است.**\n\n"
    "⚠️ **قاعده‌ی طلایی داروهای کرم‌ها را حفظ کنید:**\n\n"
    "**کرم پهن (سستود و ترماتود) → پرازی‌کوانتل.**\n\n"
    "**کرم گرد (نماتود) → بنزیمیدازول (آلبندازول، مبندازول) یا ایورمکتین.**\n\n"
    "**تنیا ساژیناتا یک سستود (کرم نواری) است، پس پرازی‌کوانتل.** دوز: تک‌دوز ۵ تا ۱۰ "
    "میلی‌گرم بر کیلوگرم — بسیار مؤثر و ساده.\n\n"
    "**درباره‌ی خود تنیا ساژیناتا بدانید:** از خوردن **گوشت گاو نیم‌پز** می‌آید. کرم بالغ "
    "می‌تواند **چند متر** طول داشته باشد. علائم آن اغلب **خفیف** است: ناراحتی شکمی مبهم، "
    "گاهی کاهش وزن، و **دفع پروگلوتیدها** که بیمار متوجه می‌شود.\n\n"
    "⚠️ **و مهم‌ترین نکته‌ی افتراقی: تنیا ساژیناتا سیستی‌سرکوز نمی‌دهد.** فقط **تنیا سولیوم** "
    "(از گوشت خوک) این خطر را دارد، چون فقط تخم سولیوم می‌تواند در بافت انسان کیست ببندد.\n\n"
    "**ائوزینوفیلی ۱۰ درصد** هم با عفونت انگلی هم‌خوان است (هرچند در تنیای بالغِ لومنی، "
    "ائوزینوفیلی معمولاً خفیف است).\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**آلبندازول:** داروی **نماتودها** و **کیست هیداتید** است. روی تنیای بالغ کارایی کمتری "
    "از پرازی‌کوانتل دارد.\n\n"
    "**تری‌کلابندازول:** داروی اختصاصی **فاسیولا هپاتیکا** (ترماتود کبدی) است. **روی تنیا "
    "مؤثر نیست.**\n\n"
    "**ایورمکتین:** داروی **نماتودها** (استرونژیلوئیدس، انکوسرکا، اسکابیز). **روی سستودها "
    "اثری ندارد.**",
    "This question is solved by ONE DRUG RULE, and that rule organises the whole helminth block.\n\n"
    "THE PATIENT: chronic abdominal pain with weakness and lethargy. Tests: WBC 7500 with 65% "
    "neutrophils, 25% lymphocytes and 10% eosinophils. And in the stool: Taenia saginata eggs.\n\n"
    "THE DIAGNOSIS IS GIVEN DIRECTLY. So the question is only about the drug.\n\n"
    "WARNING, MEMORISE THE GOLDEN RULE OF HELMINTH DRUGS:\n\n"
    "FLATWORM (cestode and trematode) means PRAZIQUANTEL.\n\n"
    "ROUNDWORM (nematode) means a BENZIMIDAZOLE (albendazole, mebendazole) or IVERMECTIN.\n\n"
    "TAENIA SAGINATA IS A CESTODE (tapeworm), SO PRAZIQUANTEL. Dose: a single 5 to 10 mg/kg — highly "
    "effective and simple.\n\n"
    "KNOW ABOUT TAENIA SAGINATA ITSELF: it comes from UNDERCOOKED BEEF. The adult worm can be SEVERAL "
    "METRES long. Its symptoms are usually MILD: vague abdominal discomfort, sometimes weight loss, "
    "and PASSAGE OF PROGLOTTIDS that the patient notices.\n\n"
    "WARNING, AND THE MOST IMPORTANT DIFFERENTIATING POINT: TAENIA SAGINATA DOES NOT CAUSE "
    "CYSTICERCOSIS. Only TAENIA SOLIUM (from pork) carries that danger, because only solium eggs can "
    "encyst in human tissue.\n\n"
    "AN EOSINOPHILIA OF 10% is also consistent with parasitic infection (although with a purely "
    "luminal adult tapeworm the eosinophilia is usually mild).\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ALBENDAZOLE: a drug for NEMATODES and for HYDATID CYST. It is less effective than praziquantel "
    "against the adult tapeworm.\n\n"
    "TRICLABENDAZOLE: the specific drug for FASCIOLA HEPATICA (a liver trematode). NOT EFFECTIVE "
    "against taenia.\n\n"
    "IVERMECTIN: a drug for NEMATODES (strongyloides, onchocerca, scabies). NO EFFECT ON CESTODES.",
    ["پاسخ صحیح — تنیا یک سستود (کرم پهن) است و پرازی‌کوانتل داروی کرم‌های پهن است.",
     "داروی نماتودها و کیست هیداتید است؛ روی تنیای بالغ کارایی کمتری دارد.",
     "داروی اختصاصی فاسیولا هپاتیکاست و روی تنیا مؤثر نیست.",
     "داروی نماتودهاست (استرونژیلوئیدس و انکوسرکا)؛ روی سستودها اثری ندارد."],
    ["Correct — taenia is a cestode (flatworm) and praziquantel is the flatworm drug.",
     "A drug for nematodes and hydatid cyst; less effective against the adult tapeworm.",
     "The specific drug for Fasciola hepatica; not effective against taenia.",
     "A nematode drug (strongyloides and onchocerca); no effect on cestodes."],
    "**کرم پهن → پرازی‌کوانتل. کرم گرد → بنزیمیدازول یا ایورمکتین.**",
    "Flatworm means praziquantel. Roundworm means a benzimidazole or ivermectin.",
    CREFS)

add("book:824", "recall", "easy",
    "**درگیری مغزی از آنِ تنیا سولیوم است — چون فقط تخم آن در انسان کیست می‌بندد.**",
    "Cerebral involvement belongs to Taenia solium — because only its eggs encyst in humans.",
    CES_FA,
    CES_EN,
    "این سؤال کوتاه است ولی به یکی از **مهم‌ترین بیماری‌های انگلی جهان** اشاره می‌کند.\n\n"
    "⚠️ **درگیری مغزی = تنیا سولیوم = نوروسیستی‌سرکوز.**\n\n"
    "**بیایید دقیق بفهمیم چه اتفاقی می‌افتد، چون این نکته ظریف است:**\n\n"
    "**دو راه متفاوت برای آلوده شدن به تنیا سولیوم وجود دارد، و نتیجه‌ی آن‌ها کاملاً فرق می‌کند:**\n\n"
    "**راه یک — خوردن گوشت خوک آلوده (حاوی سیستی‌سرک):** لارو در روده به **کرم بالغ** تبدیل "
    "می‌شود. نتیجه: **تنیازیس روده‌ای** — بیماری نسبتاً خفیف با علائم گوارشی مبهم.\n\n"
    "⚠️ **راه دو — بلعیدن تخم تنیا سولیوم (از راه مدفوع-دهان، آب یا سبزی آلوده، یا حتی "
    "خودآلودگی):** اینجا **انسان به‌جای خوک، میزبان واسط می‌شود**. تخم در روده تفریخ می‌شود، "
    "**لارو از دیواره‌ی روده وارد خون می‌شود**، و در **بافت‌ها کیست می‌بندد**: عضله، بافت زیر "
    "جلدی، چشم، و مهم‌تر از همه **مغز**.\n\n"
    "**نتیجه: نوروسیستی‌سرکوز.**\n\n"
    "**چرا این‌قدر مهم است؟** چون **نوروسیستی‌سرکوز شایع‌ترین علت تشنج اکتسابی در بسیاری از "
    "کشورهای در حال توسعه** است. تظاهرات: **تشنج** (شایع‌ترین)، سردرد، علائم فشار داخل "
    "جمجمه، و گاهی هیدروسفالی.\n\n"
    "**تصویربرداری:** کیست‌های متعدد در پارانشیم مغز، برخی **کلسیفیه**، و گاهی **اسکولکس "
    "قابل رؤیت** داخل کیست (یافته‌ی بسیار مشخص).\n\n"
    "**درمان نوروسیستی‌سرکوز پیچیده است:** **آلبندازول** (یا پرازی‌کوانتل) **به‌علاوه‌ی "
    "کورتیکواستروئید**. ⚠️ **چرا استروئید؟ چون مرگ کیست‌ها واکنش التهابی شدیدی در مغز "
    "می‌سازد** که می‌تواند ادم و تشدید تشنج بدهد. و **ضدتشنج** هم معمولاً لازم است.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**آسکاریس:** عوارضش **مکانیکی و شکمی**اند. لارو آن از **ریه** عبور می‌کند، نه مغز.\n\n"
    "**کرم شالقی:** عارضه‌ی مشخص آن **پرولاپس رکتوم** است؛ اصلاً از روده خارج نمی‌شود.\n\n"
    "**کرم قلاب‌دار:** امضای آن **کم‌خونی فقر آهن** است؛ لارو از ریه عبور می‌کند ولی به مغز نمی‌رود.\n\n"
    "**و مقایسه‌ی نهایی: تنیا ساژیناتا (گاو) نوروسیستی‌سرکوز نمی‌دهد** — چون تخم آن در بافت "
    "انسان کیست نمی‌بندد. **فقط سولیوم.**",
    "This question is short but points to one of THE MOST IMPORTANT PARASITIC DISEASES IN THE WORLD.\n\n"
    "WARNING, CEREBRAL INVOLVEMENT = TAENIA SOLIUM = NEUROCYSTICERCOSIS.\n\n"
    "LET US UNDERSTAND EXACTLY WHAT HAPPENS, because the point is subtle:\n\n"
    "THERE ARE TWO DIFFERENT WAYS TO ACQUIRE TAENIA SOLIUM, AND THEIR OUTCOMES ARE COMPLETELY DIFFERENT:\n\n"
    "ROUTE ONE — EATING INFECTED PORK (containing cysticerci): the larva becomes an ADULT WORM in the "
    "bowel. The result: INTESTINAL TAENIASIS — a relatively mild disease with vague gastrointestinal "
    "symptoms.\n\n"
    "WARNING, ROUTE TWO — SWALLOWING TAENIA SOLIUM EGGS (faecal-oral, contaminated water or "
    "vegetables, or even autoinfection): here THE HUMAN BECOMES THE INTERMEDIATE HOST IN PLACE OF THE "
    "PIG. The egg hatches in the bowel, THE LARVA ENTERS THE BLOODSTREAM through the bowel wall, and "
    "ENCYSTS IN THE TISSUES: muscle, subcutaneous tissue, eye and, above all, THE BRAIN.\n\n"
    "THE RESULT: NEUROCYSTICERCOSIS.\n\n"
    "WHY DOES THIS MATTER SO MUCH? Because NEUROCYSTICERCOSIS IS THE COMMONEST CAUSE OF ACQUIRED "
    "SEIZURES IN MANY DEVELOPING COUNTRIES. Manifestations: SEIZURES (commonest), headache, signs of "
    "raised intracranial pressure, and sometimes hydrocephalus.\n\n"
    "IMAGING: multiple cysts in the brain parenchyma, some CALCIFIED, and sometimes a VISIBLE SCOLEX "
    "within the cyst (a highly characteristic finding).\n\n"
    "TREATMENT OF NEUROCYSTICERCOSIS IS COMPLEX: ALBENDAZOLE (or praziquantel) PLUS A CORTICOSTEROID. "
    "WARNING, WHY THE STEROID? BECAUSE DYING CYSTS PROVOKE AN INTENSE INFLAMMATORY REACTION IN THE "
    "BRAIN that can cause oedema and worsen seizures. And an ANTICONVULSANT is usually needed too.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ASCARIS: its complications are MECHANICAL AND ABDOMINAL. Its larva passes through the LUNG, not "
    "the brain.\n\n"
    "WHIPWORM: its characteristic complication is RECTAL PROLAPSE; it never leaves the bowel at all.\n\n"
    "HOOKWORM: its signature is IRON-DEFICIENCY ANAEMIA; its larva passes through the lung but does "
    "not reach the brain.\n\n"
    "AND A FINAL COMPARISON: TAENIA SAGINATA (beef) DOES NOT CAUSE NEUROCYSTICERCOSIS — because its "
    "eggs do not encyst in human tissue. ONLY SOLIUM.",
    ["عوارضش مکانیکی و شکمی است؛ لارو آن از ریه عبور می‌کند نه مغز.",
     "پاسخ صحیح — بلعیدن تخم سولیوم انسان را میزبان واسط می‌کند و لارو در مغز کیست می‌بندد.",
     "عارضه‌ی مشخص آن پرولاپس رکتوم است؛ اصلاً از روده خارج نمی‌شود.",
     "امضای آن کم‌خونی فقر آهن است؛ لارو از ریه عبور می‌کند ولی به مغز نمی‌رود."],
    ["Its complications are mechanical and abdominal; its larva passes through the lung, not the brain.",
     "Correct — swallowing solium eggs makes the human the intermediate host and the larva encysts in the brain.",
     "Its characteristic complication is rectal prolapse; it never leaves the bowel.",
     "Its signature is iron-deficiency anaemia; the larva passes through the lung but not to the brain."],
    "**خوردن گوشت خوک = کرم روده‌ای. خوردن تخم = کیست در مغز.**",
    "Eating the pork gives an intestinal worm. Eating the eggs gives cysts in the brain.",
    CREFS)

# ============================================== HYDATID: TWO ITEMS
HYD_FA = [
    "⚠️ **کیست هیداتید از اکینوکوکوس گرانولوزوس است، و انسان میزبان تصادفی و بن‌بست است.**",
    "**چرخه‌ی طبیعی: سگ میزبان نهایی، گوسفند میزبان واسط.**",
    "**سگ کرم بالغ را در روده دارد و تخم را با مدفوع دفع می‌کند.**",
    "**گوسفند علف آلوده به تخم را می‌خورد و در ارگان‌هایش کیست می‌بندد.**",
    "**و اگر سگ امعاء و احشای آلوده‌ی گوسفند را بخورد، چرخه بسته می‌شود.**",
    "⚠️ **انسان با خوردن تخم آلوده می‌شود — یعنی از راه دهانی، نه از راه گوشت.**",
    "**پس منبع، سبزیجات و آب آلوده به مدفوع سگ است، نه گوشت آلوده.**",
    "**و این تمایز، پاسخ یکی از سؤال‌های این بلوک است.**",
    "**محل شایع کیست: کبد (حدود دوسوم موارد)، سپس ریه.**",
    "**کیست ریه در رادیوگرافی می‌تواند علامت نیلوفر آبی بدهد.**",
    "⚠️ **علامت نیلوفر آبی یعنی غشای داخلی جدا شده و روی سطح مایع شناور است.**",
    "**درمان: آلبندازول، به‌علاوه‌ی مداخله‌ی جراحی یا PAIR در موارد مناسب.**",
    "**PAIR یعنی سوراخ کردن، آسپیره کردن، تزریق اسکولیسید، و آسپیره‌ی مجدد.**",
    "**و سه وضعیت هست که PAIR در آن‌ها به کار نمی‌رود.**",
]
HYD_EN = [
    "WARNING: THE HYDATID CYST IS ECHINOCOCCUS GRANULOSUS, and man is an accidental, dead-end host.",
    "The natural cycle: the dog is the definitive host, the sheep the intermediate host.",
    "The dog carries the adult worm in its bowel and passes eggs in its faeces.",
    "The sheep eats grass contaminated with the eggs and forms cysts in its organs.",
    "And if a dog eats the infected sheep offal, the cycle closes.",
    "WARNING, MAN IS INFECTED BY SWALLOWING EGGS — that is, by mouth, not through meat.",
    "So the source is vegetables and water contaminated with dog faeces, not infected meat.",
    "And that distinction is the answer to one of this block's questions.",
    "The common cyst sites: the liver (about two thirds of cases), then the lung.",
    "A lung cyst can produce the WATER-LILY SIGN on the radiograph.",
    "WARNING, THE WATER-LILY SIGN means the inner membrane has detached and floats on the fluid surface.",
    "Treatment: albendazole, plus surgical intervention or PAIR in suitable cases.",
    "PAIR means Puncture, Aspiration, Injection of a scolicidal agent, and Reaspiration.",
    "And there are three situations in which PAIR is not used.",
]

add("book:821", "vignette", "medium",
    "**کیست هیداتید ریه با علامت نیلوفر آبی: راه ابتلا، خوردن سبزیجات آلوده به تخم است.**",
    "A lung hydatid cyst with the water-lily sign: the route of infection is eating vegetables contaminated with eggs.",
    HYD_FA,
    HYD_EN,
    "این سؤال یک **راه انتقال** را می‌پرسد، و پاسخ آن غیرشهودی است — بسیاری فکر می‌کنند "
    "هیداتید از گوشت می‌آید.\n\n"
    "**بیمار: روستایی کاندید جراحی کیسه صفرا. در رادیوگرافی ریه، ضایعه‌ی کیستیک بزرگ با سطح "
    "مایع-هوا و علامت نیلوفر آبی.**\n\n"
    "⚠️ **علامت نیلوفر آبی (water-lily sign) تقریباً پاتوگنومونیک کیست هیداتید است.** "
    "چه اتفاقی می‌افتد؟ کیست هیداتید دو لایه دارد: **پری‌سیست** بیرونی (از بافت میزبان) و "
    "**اندوسیست** داخلی (غشای زایا). وقتی کیست پاره می‌شود، **غشای داخلی جدا می‌شود و روی سطح "
    "مایع داخل حفره شناور می‌ماند** — و در رادیوگرافی شبیه **گل نیلوفر آبی روی آب** دیده می‌شود.\n\n"
    "**پس تشخیص: کیست هیداتید ریه (اکینوکوکوس گرانولوزوس).**\n\n"
    "**حالا سؤال: چگونه مبتلا شده است؟ چرخه‌ی زندگی را دنبال کنید:**\n\n"
    "**سگ (میزبان نهایی)** کرم بالغ را در روده دارد و **تخم را با مدفوع دفع می‌کند** → "
    "**گوسفند (میزبان واسط)** علف آلوده به تخم را می‌خورد و در ارگان‌هایش کیست می‌بندد → "
    "**سگ امعاء و احشای گوسفند را می‌خورد** و چرخه بسته می‌شود.\n\n"
    "⚠️ **انسان کجای این چرخه است؟ در جای گوسفند — یعنی میزبان واسط تصادفی.** انسان با "
    "**بلعیدن تخم** آلوده می‌شود، و تخم در **مدفوع سگ** است. پس منبع: **سبزیجات، آب یا "
    "دست‌های آلوده به مدفوع سگ**.\n\n"
    "**پس پاسخ: خوردن سبزیجات آلوده.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "⚠️ **خوردن گوشت آلوده:** **این شایع‌ترین تصور غلط است.** انسان **از خوردن گوشت آلوده "
    "به کیست، هیداتید نمی‌گیرد** — این راهی است که **سگ** آلوده می‌شود، نه انسان. اگر انسان "
    "کیست گوسفند را بخورد، اسکولکس‌ها در روده‌ی او به کرم بالغ تبدیل نمی‌شوند (انسان میزبان "
    "نهایی مناسبی نیست).\n\n"
    "**استنشاق گرد و غبار آلوده:** راه ورود هیداتید **گوارشی** است، نه تنفسی. (کیست **در ریه** "
    "می‌نشیند، ولی از راه **خون** به آنجا می‌رسد، نه از راه هوا.)\n\n"
    "**راه رفتن با پای برهنه روی خاک آلوده:** این راه ورود **کرم قلاب‌دار و استرونژیلوئیدس** "
    "است (نفوذ لارو از پوست). هیچ ربطی به اکینوکوکوس ندارد.",
    "This question asks about A ROUTE OF TRANSMISSION, and its answer is counter-intuitive — many "
    "believe hydatid comes from meat.\n\n"
    "THE PATIENT: a villager awaiting gallbladder surgery. His chest radiograph shows a large cystic "
    "lesion with an air-fluid level and the WATER-LILY SIGN.\n\n"
    "WARNING, THE WATER-LILY SIGN IS ALMOST PATHOGNOMONIC OF A HYDATID CYST. What happens? The hydatid "
    "cyst has two layers: the outer PERICYST (host tissue) and the inner ENDOCYST (germinal membrane). "
    "When the cyst ruptures, THE INNER MEMBRANE DETACHES AND FLOATS ON THE FLUID inside the cavity — "
    "looking on the radiograph like A WATER LILY ON WATER.\n\n"
    "SO THE DIAGNOSIS: PULMONARY HYDATID CYST (Echinococcus granulosus).\n\n"
    "NOW THE QUESTION: HOW WAS HE INFECTED? FOLLOW THE LIFE CYCLE:\n\n"
    "THE DOG (definitive host) carries the adult worm in its bowel and PASSES EGGS IN ITS FAECES. THE "
    "SHEEP (intermediate host) eats grass contaminated with the eggs and forms cysts in its organs. "
    "THE DOG EATS THE SHEEP'S OFFAL and the cycle closes.\n\n"
    "WARNING, WHERE IS MAN IN THIS CYCLE? IN THE SHEEP'S PLACE — an accidental intermediate host. Man "
    "is infected BY SWALLOWING EGGS, and the eggs are in DOG FAECES. So the source is VEGETABLES, "
    "WATER OR HANDS CONTAMINATED WITH DOG FAECES.\n\n"
    "SO THE ANSWER: EATING CONTAMINATED VEGETABLES.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "WARNING, EATING CONTAMINATED MEAT: THIS IS THE COMMONEST MISCONCEPTION. Man DOES NOT ACQUIRE "
    "HYDATID BY EATING CYST-CONTAINING MEAT — that is how THE DOG is infected, not the human. If a "
    "person eats a sheep cyst, the scolices do not become adult worms in his bowel (man is not a "
    "suitable definitive host).\n\n"
    "INHALING CONTAMINATED DUST: the hydatid route of entry is DIGESTIVE, not respiratory. (The cyst "
    "lodges IN THE LUNG, but it reaches there VIA THE BLOOD, not through the air.)\n\n"
    "WALKING BAREFOOT ON CONTAMINATED SOIL: that is the route for HOOKWORM AND STRONGYLOIDES (larval "
    "skin penetration). It has nothing to do with echinococcus.",
    ["شایع‌ترین تصور غلط — این راهی است که سگ آلوده می‌شود، نه انسان.",
     "راه ورود هیداتید گوارشی است نه تنفسی؛ کیست از راه خون به ریه می‌رسد.",
     "این راه ورود کرم قلاب‌دار و استرونژیلوئیدس است، نه اکینوکوکوس.",
     "پاسخ صحیح — انسان با بلعیدن تخم موجود در مدفوع سگ، از راه سبزی و آب آلوده مبتلا می‌شود."],
    ["The commonest misconception — that is how the dog is infected, not the human.",
     "The hydatid route of entry is digestive, not respiratory; the cyst reaches the lung via the blood.",
     "That is the route for hookworm and strongyloides, not for echinococcus.",
     "Correct — man is infected by swallowing eggs from dog faeces, on contaminated vegetables and water."],
    "**هیداتید از تخمِ مدفوع سگ می‌آید، نه از گوشت — انسان جای گوسفند است، نه جای سگ.**",
    "Hydatid comes from eggs in dog faeces, not from meat — man takes the sheep's place, not the dog's.",
    CREFS)

add("book:820", "recall", "hard",
    "**PAIR در هر سه وضعیت به کار نمی‌رود: کیست سطحی، کیست لانه‌زنبوری، و کیست مرتبط با مجاری صفراوی.**",
    "PAIR is used in none of the three: a superficial cyst, a honeycomb cyst, and a cyst communicating with the biliary tree.",
    HYD_FA + [
        "**هر سه وضعیت این سؤال، منع استفاده از PAIR‌اند — ولی هر کدام به دلیل متفاوتی.**",
        "**کیست سطحی: خطر پارگی و نشت به حفره‌ی صفاق یا پلور بالاست.**",
        "⚠️ **و نشت محتوای کیست می‌تواند شوک آنافیلاکتیک بدهد.**",
        "**همچنین اسکولکس‌های پخش‌شده، کیست‌های ثانویه می‌سازند: اکینوکوکوز ثانویه.**",
        "**کیست لانه‌زنبوری (چندحفره‌ای): آسپیراسیون همه‌ی حفره‌ها ممکن نیست.**",
        "**پس درمان ناقص می‌ماند و حفره‌های درمان‌نشده عود می‌کنند.**",
        "⚠️ **کیست مرتبط با مجاری صفراوی: این خطرناک‌ترین مورد است.**",
        "**عوامل اسکولیسید مثل سالین هیپرتونیک یا اتانول، به مجاری صفراوی راه پیدا می‌کنند.**",
        "**نتیجه: کلانژیت شیمیایی اسکلروزان، که عارضه‌ی ویرانگری است.**",
        "**پس پیش از PAIR باید ارتباط با مجاری صفراوی رد شود.**",
    ],
    HYD_EN + [
        "All three situations here contraindicate PAIR — but each for a different reason.",
        "SUPERFICIAL CYST: a high risk of rupture and leakage into the peritoneal or pleural cavity.",
        "WARNING, AND LEAKED CYST CONTENTS CAN CAUSE ANAPHYLACTIC SHOCK.",
        "Also, spilled scolices form secondary cysts: secondary echinococcosis.",
        "HONEYCOMB (multiloculated) CYST: aspirating every locule is impossible.",
        "So treatment remains incomplete and the untreated locules recur.",
        "WARNING, A CYST COMMUNICATING WITH THE BILIARY TREE: this is the most dangerous.",
        "Scolicidal agents such as hypertonic saline or ethanol reach the bile ducts.",
        "The result: chemical SCLEROSING CHOLANGITIS, a devastating complication.",
        "So biliary communication must be excluded before PAIR.",
    ],
    "این سخت‌ترین سؤال بلوک کرم‌هاست، چون **هر سه گزینه را باید جداگانه راستی‌آزمایی کنید** "
    "و هر کدام **دلیل متفاوتی** دارد.\n\n"
    "**اول بدانیم PAIR چیست:** **P**uncture (سوراخ کردن) · **A**spiration (آسپیره کردن "
    "محتوا) · **I**njection (تزریق ماده‌ی اسکولیسید مثل سالین هیپرتونیک یا اتانول) · "
    "**R**easpiration (آسپیره‌ی مجدد). این روش **جایگزین کم‌تهاجمی جراحی** برای کیست هیداتید "
    "است و با هدایت سونوگرافی یا س‌ی‌تی انجام می‌شود.\n\n"
    "**حالا هر سه وضعیت را بررسی کنیم:**\n\n"
    "⚠️ **یک — کیست‌های سطحی.** خطر: **پارگی و نشت به حفره‌ی صفاق یا پلور**. کیست سطحی "
    "دیواره‌ی نازکی دارد و سوزن راحت آن را پاره می‌کند. **و نشت محتوای کیست دو خطر دارد:** "
    "**شوک آنافیلاکتیک** (محتوای کیست به‌شدت آنتی‌ژنیک است)، و **اکینوکوکوز ثانویه** — "
    "اسکولکس‌های پخش‌شده در حفره، **کیست‌های جدید متعددی** می‌سازند که درمانشان بسیار دشوار است.\n\n"
    "**دو — کیست لانه‌زنبوری (چندحفره‌ای).** خطر: **درمان ناقص**. در کیست چندحفره‌ای، "
    "**نمی‌توان به همه‌ی حفره‌ها با یک سوزن دسترسی پیدا کرد**. حفره‌های آسپیره‌نشده باقی می‌مانند "
    "و **عود می‌کنند**. این نوع کیست معمولاً به **جراحی** نیاز دارد.\n\n"
    "⚠️ **سه — کیست‌هایی که به سیستم صفراوی راه دارند. این خطرناک‌ترین است.** خطر: "
    "**کلانژیت شیمیایی اسکلروزان**. ماده‌ی اسکولیسید (سالین هیپرتونیک یا اتانول) که برای "
    "کشتن اسکولکس‌ها تزریق می‌شود، **از راه ارتباط، وارد مجاری صفراوی می‌شود** و به اپیتلیوم "
    "آن‌ها آسیب شیمیایی شدید می‌زند. نتیجه: **کلانژیت اسکلروزان** — عارضه‌ای ویرانگر و اغلب "
    "غیرقابل بازگشت. **به همین دلیل، پیش از هر PAIR باید ارتباط با مجاری صفراوی رد شود** "
    "(با بررسی بیلی‌روبین و تصویربرداری).\n\n"
    "**پس هر سه وضعیت منع PAIR‌اند، و پاسخ: همه‌ی موارد.**\n\n"
    "**و برای کامل شدن تصویر، PAIR کِی مناسب است؟** کیست **تک‌حفره‌ای**، **عمقی** (نه سطحی)، "
    "**بدون ارتباط صفراوی**، و در بیمار **غیرقابل جراحی** یا با **کیست‌های متعدد**. و همیشه "
    "**همراه با آلبندازول** پیش و پس از عمل، برای کاهش خطر عود و اکینوکوکوز ثانویه.",
    "This is the hardest question in the helminth block, because ALL THREE OPTIONS MUST BE VERIFIED "
    "SEPARATELY and each has A DIFFERENT REASON.\n\n"
    "FIRST, WHAT IS PAIR? Puncture, Aspiration of the contents, Injection of a scolicidal agent "
    "(hypertonic saline or ethanol), and Reaspiration. It is a MINIMALLY INVASIVE ALTERNATIVE TO "
    "SURGERY for hydatid cyst, performed under ultrasound or CT guidance.\n\n"
    "NOW LET US EXAMINE ALL THREE SITUATIONS:\n\n"
    "WARNING, ONE — SUPERFICIAL CYSTS. The risk: RUPTURE AND LEAKAGE INTO THE PERITONEAL OR PLEURAL "
    "CAVITY. A superficial cyst has a thin wall that the needle easily tears. AND LEAKED CYST CONTENTS "
    "CARRY TWO DANGERS: ANAPHYLACTIC SHOCK (the contents are intensely antigenic), and SECONDARY "
    "ECHINOCOCCOSIS — spilled scolices form NUMEROUS NEW CYSTS that are very hard to treat.\n\n"
    "TWO — HONEYCOMB (MULTILOCULATED) CYSTS. The risk: INCOMPLETE TREATMENT. In a multiloculated cyst "
    "IT IS IMPOSSIBLE TO REACH EVERY LOCULE WITH ONE NEEDLE. The unaspirated locules remain and "
    "RECUR. This type usually requires SURGERY.\n\n"
    "WARNING, THREE — CYSTS COMMUNICATING WITH THE BILIARY SYSTEM. THIS IS THE MOST DANGEROUS. The "
    "risk: CHEMICAL SCLEROSING CHOLANGITIS. The scolicidal agent (hypertonic saline or ethanol) "
    "injected to kill the scolices PASSES THROUGH THE COMMUNICATION INTO THE BILE DUCTS and severely "
    "damages their epithelium chemically. The result: SCLEROSING CHOLANGITIS — a devastating and often "
    "irreversible complication. FOR THIS REASON, BILIARY COMMUNICATION MUST BE EXCLUDED BEFORE ANY "
    "PAIR (by checking bilirubin and imaging).\n\n"
    "SO ALL THREE CONTRAINDICATE PAIR, AND THE ANSWER IS: ALL OF THE ABOVE.\n\n"
    "AND TO COMPLETE THE PICTURE, WHEN IS PAIR SUITABLE? A UNILOCULAR cyst, DEEP (not superficial), "
    "WITHOUT BILIARY COMMUNICATION, in a patient UNFIT FOR SURGERY or with MULTIPLE CYSTS. And always "
    "WITH ALBENDAZOLE before and after the procedure, to reduce the risk of recurrence and secondary "
    "echinococcosis.",
    ["درست است — خطر پارگی و نشت، که شوک آنافیلاکتیک و اکینوکوکوز ثانویه می‌دهد.",
     "درست است — در کیست چندحفره‌ای نمی‌توان به همه‌ی حفره‌ها دسترسی یافت و عود رخ می‌دهد.",
     "درست است — ماده‌ی اسکولیسید وارد مجاری صفراوی می‌شود و کلانژیت شیمیایی می‌سازد.",
     "پاسخ صحیح — هر سه وضعیت منع استفاده از PAIR‌اند، هر کدام به دلیل متفاوتی."],
    ["Correct — a risk of rupture and leakage, causing anaphylactic shock and secondary echinococcosis.",
     "Correct — in a multiloculated cyst not every locule can be reached, and recurrence follows.",
     "Correct — the scolicidal agent enters the bile ducts and causes chemical cholangitis.",
     "Correct — all three contraindicate PAIR, each for a different reason."],
    "**PAIR: نه سطحی، نه چندحفره‌ای، نه با ارتباط صفراوی.**",
    "PAIR: not superficial, not multiloculated, not communicating with the biliary tree.",
    [HC, WHOE])

# ============================================== TREMATODES: THREE ITEMS
TRE_FA = [
    "⚠️ **فاسیولا هپاتیکا با خوردن گیاهان آبزی خام منتقل می‌شود، به‌ویژه شاهی آبی.**",
    "**در ایران، شمال کشور (گیلان و مازندران) کانون اصلی فاسیولیازیس است.**",
    "**متاسرکاریا روی گیاه آبزی می‌چسبد و بلعیده می‌شود.**",
    "**سپس از دیواره‌ی روده عبور می‌کند و از کپسول کبد وارد پارانشیم می‌شود.**",
    "**و در حین عبور، مسیرهایی از تخریب بافتی به جا می‌گذارد.**",
    "⚠️ **این مسیرها در س‌ی‌تی به شکل «شیارهای عبور لارو» یا ضایعات هیپودنس متعدد دیده می‌شوند.**",
    "**فاز حاد: تب، درد ربع فوقانی راست، هپاتومگالی و ائوزینوفیلی بسیار بالا.**",
    "**ائوزینوفیلی در فاسیولیازیس می‌تواند به ۴۰ تا ۸۰ درصد برسد — از شاخص‌ترین موارد.**",
    "**کهیر هم شایع است، از واکنش آلرژیک به انگل مهاجر.**",
    "**سپس فاز مزمن: انگل در مجاری صفراوی مستقر می‌شود.**",
    "⚠️ **و نکته‌ی دارویی حیاتی: فاسیولا تنها ترماتودی است که به پرازی‌کوانتل پاسخ نمی‌دهد.**",
    "**داروی انتخابی آن تری‌کلابندازول است.**",
    "**این استثنا ارزش امتحانی بالایی دارد و باید جدا حفظ شود.**",
    "**و شیستوزوما را با محل درگیری از هم جدا کنید.**",
    "**هماتوبیوم دستگاه ادراری؛ مانسونی و ژاپونیکوم روده و کبد.**",
]
TRE_EN = [
    "WARNING: FASCIOLA HEPATICA is transmitted by eating raw aquatic plants, especially watercress.",
    "In Iran, the northern provinces (Gilan and Mazandaran) are the main focus of fascioliasis.",
    "The metacercaria attaches to the aquatic plant and is swallowed.",
    "It then crosses the bowel wall and enters the liver parenchyma through the capsule.",
    "And while crossing it leaves behind tracks of tissue destruction.",
    "WARNING, THESE TRACKS APPEAR ON CT as 'larval migration tunnels' or multiple hypodense lesions.",
    "The acute phase: fever, right upper quadrant pain, hepatomegaly and very high eosinophilia.",
    "Eosinophilia in fascioliasis can reach 40 to 80% — among the most striking of any infection.",
    "Urticaria is also common, from the allergic reaction to the migrating parasite.",
    "Then the chronic phase: the parasite settles in the bile ducts.",
    "WARNING, AND THE VITAL DRUG POINT: FASCIOLA IS THE ONE TREMATODE THAT DOES NOT RESPOND TO PRAZIQUANTEL.",
    "Its drug of choice is TRICLABENDAZOLE.",
    "This exception carries high exam value and must be memorised separately.",
    "And separate the schistosomes by the organ they involve.",
    "S. haematobium affects the urinary tract; S. mansoni and S. japonicum the bowel and liver.",
]

add("book:825", "vignette", "medium",
    "**سبزی خام از شمال + ائوزینوفیلی + شیارهای عبور لارو در کبد = فاسیولا هپاتیکا.**",
    "Raw vegetables from the north plus eosinophilia plus larval tunnels in the liver = FASCIOLA HEPATICA.",
    TRE_FA,
    TRE_EN,
    "این سؤال یک تابلوی **بسیار مشخص** را توصیف می‌کند، و اگر سه سرنخ آن را بشناسید، در "
    "چند ثانیه حل می‌شود.\n\n"
    "**بیمار: چند هفته پس از بازگشت از شمال، تب و درد شکم. اظهار می‌دارد در طی مسافرت از "
    "سبزیجات خام به مقدار زیاد استفاده کرده. در معاینه بزرگی کبد، در آزمایشات ائوزینوفیلی "
    "قابل توجه، و در س‌ی‌تی شکم، شیارهای عبور لارو.**\n\n"
    "**سه سرنخ، همه به یک تشخیص:**\n\n"
    "⚠️ **سرنخ یک — سبزیجات خام در شمال ایران.** **شمال ایران (گیلان و مازندران) کانون "
    "اصلی فاسیولیازیس** در کشور است. متاسرکاریای فاسیولا روی **گیاهان آبزی** — به‌ویژه "
    "**شاهی آبی**، ولی هر سبزی خام آبیاری‌شده با آب آلوده — می‌چسبد و با خوردن آن‌ها بلعیده "
    "می‌شود.\n\n"
    "**سرنخ دو — ائوزینوفیلی قابل توجه.** **فاسیولیازیس یکی از شدیدترین ائوزینوفیلی‌های "
    "بیماری‌های عفونی را می‌دهد** — می‌تواند به ۴۰ تا ۸۰ درصد برسد.\n\n"
    "⚠️ **سرنخ سه — شیارهای عبور لارو در س‌ی‌تی. این تقریباً پاتوگنومونیک است.** چرا این "
    "شیارها ساخته می‌شوند؟ چون **لارو فاسیولا از دیواره‌ی روده عبور می‌کند، از حفره‌ی صفاق "
    "می‌گذرد، و از کپسول کبد وارد پارانشیم می‌شود**. در حین این عبور، **مسیرهایی از تخریب "
    "بافتی و نکروز** به جا می‌گذارد که در تصویربرداری به شکل **شیار یا کانال** دیده می‌شوند.\n\n"
    "**پس تشخیص: فاسیولا هپاتیکا.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**استرونژیلوئیدس استرکورالیس:** ائوزینوفیلی می‌دهد، ولی **شیار در کبد نمی‌سازد**. "
    "تابلوی آن **گوارشی و پوستی** است (درد اپی‌گاستر، لاروا کورنس)، و راه ورود آن **پوست** "
    "است، نه سبزی خام.\n\n"
    "**لپتوسپیرا:** یک **باکتری** است، نه انگل. **ائوزینوفیلی نمی‌دهد** (بلکه نوتروفیلی "
    "می‌دهد). تابلوی آن **تب، میالژی شدید، تزریق ملتحمه و یرقان** است. و راه ورود آن **تماس "
    "با آب آلوده به ادرار جوندگان** است.\n\n"
    "**توکسوکارا:** لارو مهاجر احشایی (VLM) می‌دهد و **ائوزینوفیلی بسیار بالا** دارد، ولی "
    "بیشتر در **کودکان خردسال** با سابقه‌ی **خاک‌خواری (pica)** و تماس با **توله‌سگ یا "
    "بچه‌گربه** دیده می‌شود. **شیارهای مشخص کبدی نمی‌سازد** و ارتباط با سبزی خام ندارد.\n\n"
    "⚠️ **و یادآوری دارویی که سؤال بعدی می‌پرسد: درمان فاسیولا تری‌کلابندازول است، نه "
    "پرازی‌کوانتل.**",
    "This question describes A VERY DISTINCTIVE PICTURE, and if you recognise its three clues it is "
    "solved in seconds.\n\n"
    "THE PATIENT: several weeks after returning from the north, fever and abdominal pain. He reports "
    "eating large amounts of raw vegetables during the trip. Examination shows hepatomegaly, the tests "
    "show marked eosinophilia, and abdominal CT shows larval migration tunnels.\n\n"
    "THREE CLUES, ALL TO ONE DIAGNOSIS:\n\n"
    "WARNING, CLUE ONE — RAW VEGETABLES IN NORTHERN IRAN. NORTHERN IRAN (Gilan and Mazandaran) IS THE "
    "COUNTRY'S MAIN FOCUS OF FASCIOLIASIS. Fasciola metacercariae attach to AQUATIC PLANTS — "
    "especially WATERCRESS, but also any raw vegetable irrigated with contaminated water — and are "
    "swallowed with them.\n\n"
    "CLUE TWO — MARKED EOSINOPHILIA. FASCIOLIASIS PRODUCES ONE OF THE HIGHEST EOSINOPHIL COUNTS OF ANY "
    "INFECTIOUS DISEASE — it can reach 40 to 80%.\n\n"
    "WARNING, CLUE THREE — LARVAL MIGRATION TUNNELS ON CT. THIS IS ALMOST PATHOGNOMONIC. Why do these "
    "tunnels form? Because THE FASCIOLA LARVA CROSSES THE BOWEL WALL, TRAVERSES THE PERITONEAL CAVITY, "
    "AND ENTERS THE LIVER PARENCHYMA THROUGH ITS CAPSULE. During that passage it leaves TRACKS OF "
    "TISSUE DESTRUCTION AND NECROSIS which appear on imaging as TUNNELS OR TRACKS.\n\n"
    "SO THE DIAGNOSIS: FASCIOLA HEPATICA.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "STRONGYLOIDES STERCORALIS: causes eosinophilia, but DOES NOT CREATE LIVER TUNNELS. Its picture is "
    "GASTROINTESTINAL AND CUTANEOUS (epigastric pain, larva currens), and its route of entry is THE "
    "SKIN, not raw vegetables.\n\n"
    "LEPTOSPIRA: a BACTERIUM, not a parasite. It DOES NOT CAUSE EOSINOPHILIA (it causes neutrophilia). "
    "Its picture is FEVER, SEVERE MYALGIA, CONJUNCTIVAL SUFFUSION AND JAUNDICE. And its route is "
    "CONTACT WITH WATER CONTAMINATED BY RODENT URINE.\n\n"
    "TOXOCARA: causes visceral larva migrans with VERY HIGH EOSINOPHILIA, but it is seen mainly in "
    "YOUNG CHILDREN with a history of PICA (soil eating) and contact with PUPPIES OR KITTENS. It DOES "
    "NOT CREATE DISTINCT LIVER TUNNELS and has no association with raw vegetables.\n\n"
    "WARNING, AND A DRUG REMINDER THAT THE NEXT QUESTION ASKS: FASCIOLA IS TREATED WITH "
    "TRICLABENDAZOLE, NOT PRAZIQUANTEL.",
    ["ائوزینوفیلی می‌دهد ولی شیار کبدی نمی‌سازد؛ راه ورود آن پوست است نه سبزی خام.",
     "باکتری است و ائوزینوفیلی نمی‌دهد؛ تابلوی آن تب، میالژی و تزریق ملتحمه است.",
     "پاسخ صحیح — سبزی خام شمال، ائوزینوفیلی بالا، و شیارهای عبور لارو در کبد.",
     "ائوزینوفیلی بالا دارد ولی در کودکان با خاک‌خواری دیده می‌شود و شیار کبدی نمی‌سازد."],
    ["Causes eosinophilia but no liver tunnels; its route is the skin, not raw vegetables.",
     "A bacterium that causes no eosinophilia; its picture is fever, myalgia and conjunctival suffusion.",
     "Correct — raw northern vegetables, high eosinophilia, and larval tunnels in the liver.",
     "Has high eosinophilia but is seen in children with pica and creates no liver tunnels."],
    "**شیار عبور لارو در کبد + ائوزینوفیلی شدید + سبزی خام شمال = فاسیولا.**",
    "Larval tunnels in the liver plus severe eosinophilia plus raw northern vegetables = fasciola.",
    CREFS)

add("book:827", "vignette", "hard",
    "**فاسیولیازیس: تری‌کلابندازول — تنها ترماتودی که به پرازی‌کوانتل پاسخ نمی‌دهد.**",
    "Fascioliasis: TRICLABENDAZOLE — the one trematode that does not respond to praziquantel.",
    TRE_FA,
    TRE_EN,
    "این سؤال یک **استثنای دارویی** را می‌سنجد که ارزش امتحانی بسیار بالایی دارد.\n\n"
    "**بیمار: خانم ۳۰ ساله اهل استان شمالی، از یک هفته قبل با تب، درد شکم، بی‌اشتهایی و "
    "کاهش وزن ۵ کیلوگرم. در معاینه ضایعات کهیری و سرفه‌های خشک. در آزمایشات لکوسیتوز ۳۰ "
    "هزار با ائوزینوفیلی ۴۵ درصد. در س‌ی‌تی شکم، ضایعات هیپودنس متعدد کبدی.**\n\n"
    "**تشخیص را ابتدا محکم کنیم:**\n\n"
    "⚠️ **ائوزینوفیلی ۴۵ درصد با لکوسیتوز ۳۰ هزار.** بیایید حساب کنیم: ۴۵٪ از ۳۰٬۰۰۰ "
    "می‌شود **۱۳٬۵۰۰ ائوزینوفیل مطلق** — این **ائوزینوفیلی بسیار شدید** است و فهرست "
    "تشخیص‌های افتراقی را به‌شدت محدود می‌کند. **فاسیولیازیس یکی از معدود عفونت‌هایی است که "
    "چنین سطحی می‌دهد.**\n\n"
    "**اهل استان شمالی** — کانون فاسیولیازیس ایران.\n\n"
    "**ضایعات هیپودنس متعدد کبدی** — همان مسیرهای عبور لارو در فاز حاد.\n\n"
    "**کهیر** — واکنش آلرژیک به انگل مهاجر. **سرفه‌ی خشک** — واکنش آلرژیک سیستمیک.\n\n"
    "**پس تشخیص: فاسیولا هپاتیکا در فاز حاد (هپاتیک).**\n\n"
    "⚠️ **حالا نکته‌ی دارویی حیاتی: فاسیولا تنها ترماتود مهمی است که به پرازی‌کوانتل پاسخ "
    "نمی‌دهد.**\n\n"
    "**این استثنا را جدا حفظ کنید، چون قاعده‌ی کلی «کرم پهن → پرازی‌کوانتل» اینجا نقض "
    "می‌شود.** شیستوزوما، کلونورکیس، اوپیستورکیس، پاراگونیموس — همه با پرازی‌کوانتل. **ولی "
    "فاسیولا نه.**\n\n"
    "**داروی انتخابی فاسیولا: تری‌کلابندازول.** دوز: ۱۰ میلی‌گرم بر کیلوگرم، یک یا دو دوز. "
    "این دارو **بر خلاف بقیه‌ی بنزیمیدازول‌ها، فعالیت اختصاصی روی فاسیولا دارد**.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**آلبندازول:** برای **نماتودها و کیست هیداتید** است. روی فاسیولا **کارایی قابل اتکایی "
    "ندارد**.\n\n"
    "**ایورمکتین:** برای **نماتودها** (استرونژیلوئیدس، انکوسرکا) و **اسکابیز**. **روی "
    "ترماتودها مؤثر نیست.**\n\n"
    "**پیرانتل پاموآت:** برای **آسکاریس، کرمک و کرم قلاب‌دار**. **روی ترماتودها اثری ندارد.**\n\n"
    "**پس جدول نهایی داروهای کرم‌ها را کامل کنید:**\n\n"
    "**نماتود → بنزیمیدازول یا ایورمکتین یا پیرانتل. سستود و اکثر ترماتودها → پرازی‌کوانتل. "
    "⚠️ فاسیولا → تری‌کلابندازول (استثنا).**",
    "This question tests A DRUG EXCEPTION that carries very high exam value.\n\n"
    "THE PATIENT: a 30-year-old woman from a northern province, with one week of fever, abdominal "
    "pain, anorexia and 5 kg weight loss. Examination shows urticarial lesions and she complains of a "
    "dry cough. Tests show a white count of 30,000 with 45% eosinophils. Abdominal CT shows multiple "
    "hypodense liver lesions.\n\n"
    "FIRST LET US FIX THE DIAGNOSIS:\n\n"
    "WARNING, 45% EOSINOPHILS WITH A WHITE COUNT OF 30,000. Let us calculate: 45% of 30,000 is 13,500 "
    "ABSOLUTE EOSINOPHILS — this is EXTREMELY SEVERE EOSINOPHILIA and it narrows the differential "
    "sharply. FASCIOLIASIS IS ONE OF THE FEW INFECTIONS THAT REACHES SUCH LEVELS.\n\n"
    "FROM A NORTHERN PROVINCE — Iran's focus of fascioliasis.\n\n"
    "MULTIPLE HYPODENSE LIVER LESIONS — the larval migration tracks of the acute phase.\n\n"
    "URTICARIA — an allergic reaction to the migrating parasite. DRY COUGH — a systemic allergic "
    "response.\n\n"
    "SO THE DIAGNOSIS: FASCIOLA HEPATICA in the acute (hepatic) phase.\n\n"
    "WARNING, NOW THE VITAL DRUG POINT: FASCIOLA IS THE ONLY IMPORTANT TREMATODE THAT DOES NOT RESPOND "
    "TO PRAZIQUANTEL.\n\n"
    "MEMORISE THIS EXCEPTION SEPARATELY, because the general rule 'flatworm means praziquantel' BREAKS "
    "HERE. Schistosoma, Clonorchis, Opisthorchis, Paragonimus — all praziquantel. BUT NOT FASCIOLA.\n\n"
    "THE DRUG OF CHOICE FOR FASCIOLA: TRICLABENDAZOLE. Dose: 10 mg/kg, one or two doses. This drug, "
    "UNLIKE THE OTHER BENZIMIDAZOLES, HAS SPECIFIC ACTIVITY AGAINST FASCIOLA.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ALBENDAZOLE: for NEMATODES AND HYDATID CYST. It has NO RELIABLE ACTIVITY against fasciola.\n\n"
    "IVERMECTIN: for NEMATODES (strongyloides, onchocerca) and SCABIES. NOT EFFECTIVE AGAINST "
    "TREMATODES.\n\n"
    "PYRANTEL PAMOATE: for ASCARIS, PINWORM AND HOOKWORM. NO EFFECT ON TREMATODES.\n\n"
    "SO COMPLETE THE FINAL HELMINTH DRUG TABLE:\n\n"
    "NEMATODE means a benzimidazole or ivermectin or pyrantel. CESTODE AND MOST TREMATODES mean "
    "praziquantel. WARNING, FASCIOLA means TRICLABENDAZOLE (the exception).",
    ["برای نماتودها و کیست هیداتید است؛ روی فاسیولا کارایی قابل اتکایی ندارد.",
     "برای نماتودها و اسکابیز است؛ روی ترماتودها مؤثر نیست.",
     "برای آسکاریس و کرمک و قلاب‌دار است؛ روی ترماتودها اثری ندارد.",
     "پاسخ صحیح — فاسیولا تنها ترماتودی است که پرازی‌کوانتل روی آن کار نمی‌کند."],
    ["For nematodes and hydatid cyst; it has no reliable activity against fasciola.",
     "For nematodes and scabies; not effective against trematodes.",
     "For ascaris, pinworm and hookworm; no effect on trematodes.",
     "Correct — fasciola is the one trematode on which praziquantel does not work."],
    "**همه‌ی ترماتودها پرازی‌کوانتل — به‌جز فاسیولا، که تری‌کلابندازول می‌خواهد.**",
    "All trematodes take praziquantel — except fasciola, which needs triclabendazole.",
    CREFS)

add("book:826", "recall", "easy",
    "**شیستوزوما هماتوبیوم دستگاه ادراری را درگیر می‌کند — نامش هم همین را می‌گوید.**",
    "Schistosoma haematobium involves the urinary tract — and its very name says so.",
    TRE_FA + [
        "**نام گونه در شیستوزوما، محل درگیری را می‌گوید و همین حفظ کردن را آسان می‌کند.**",
        "**هماتوبیوم از «هماچوری» می‌آید: خون در ادرار.**",
        "⚠️ **این گونه در شبکه‌ی وریدی مثانه تخم‌گذاری می‌کند.**",
        "**پس هماچوری بدون درد در انتهای ادرار، تظاهر کلاسیک آن است.**",
        "**و عارضه‌ی دیررس آن مهم است: کارسینوم سلول سنگفرشی مثانه.**",
        "**مانسونی و ژاپونیکوم در وریدهای مزانتریک تخم می‌گذارند.**",
        "**پس آن‌ها روده و کبد را درگیر می‌کنند: فیبروز پری‌پورتال و هیپرتانسیون پورت.**",
        "**درمان همه‌ی شیستوزوماها: پرازی‌کوانتل.**",
    ],
    TRE_EN + [
        "In schistosomes the species name tells you the organ, which makes memorising easy.",
        "'Haematobium' comes from HAEMATURIA: blood in the urine.",
        "WARNING, THIS SPECIES LAYS ITS EGGS IN THE VESICAL VENOUS PLEXUS.",
        "So painless TERMINAL haematuria is its classic presentation.",
        "And its late complication matters: SQUAMOUS CELL CARCINOMA OF THE BLADDER.",
        "S. mansoni and S. japonicum lay eggs in the mesenteric veins.",
        "So they involve the bowel and liver: periportal fibrosis and portal hypertension.",
        "Treatment of all schistosomes: praziquantel.",
    ],
    "این سؤال با **نام خودِ گونه** حل می‌شود — و این نکته‌ی خوبی است، چون حفظ کردن را آسان "
    "می‌کند.\n\n"
    "⚠️ **«هماتوبیوم» از «هماچوری» می‌آید: خون در ادرار.** پس **شیستوزوما هماتوبیوم = دستگاه "
    "ادراری**.\n\n"
    "**چرا این گونه ادراری است؟ به محل تخم‌گذاری‌اش نگاه کنید:**\n\n"
    "**شیستوزوما هماتوبیوم در شبکه‌ی وریدی مثانه (پلکسوس وزیکال) تخم‌گذاری می‌کند.** تخم‌ها "
    "برای خروج، **از دیواره‌ی مثانه عبور می‌کنند** و در این مسیر **خونریزی و التهاب** ایجاد "
    "می‌کنند.\n\n"
    "**تظاهر کلاسیک: هماچوری بدون درد، به‌ویژه در انتهای ادرار (terminal hematuria).** در "
    "مناطق اندمیک آفریقا، این آن‌قدر شایع است که گاهی در پسران به‌عنوان «قاعدگی مردانه» تلقی "
    "می‌شده.\n\n"
    "**عوارض دیررس:** **فیبروز و کلسیفیکاسیون دیواره‌ی مثانه**، **انسداد حالب و هیدرونفروز**، "
    "و مهم‌تر از همه ⚠️ **کارسینوم سلول سنگفرشی مثانه** — یکی از معدود مواردی که سرطان مثانه "
    "به‌جای سلول ترانزیشنال، **سنگفرشی** است.\n\n"
    "**حالا سه گونه‌ی دیگر:**\n\n"
    "**شیستوزوما مانسونی** — در **وریدهای مزانتریک تحتانی** تخم می‌گذارد. درگیری: **کولون و "
    "کبد**. عوارض: **فیبروز پری‌پورتال (فیبروز سیمفورد)، هیپرتانسیون پورت، اسپلنومگالی و "
    "واریس مری**. جغرافیا: آفریقا و آمریکای جنوبی.\n\n"
    "**شیستوزوما ژاپونیکوم** — در **وریدهای مزانتریک فوقانی**. همان درگیری روده و کبد ولی "
    "**شدیدتر** (تخم بیشتری تولید می‌کند). جغرافیا: چین، فیلیپین، اندونزی.\n\n"
    "**شیستوزوما مکونگی** — مشابه ژاپونیکوم، در حوضه‌ی رود مکونگ (کامبوج و لائوس). **روده‌ای**.\n\n"
    "**پس قاعده‌ی ساده: هماتوبیوم تنها گونه‌ی ادراری است؛ بقیه روده‌ای و کبدی‌اند.**\n\n"
    "**و درمان همه: پرازی‌کوانتل.** (به‌یاد بیاورید که **فاسیولا استثناست**، نه شیستوزوما.)",
    "This question is solved by THE SPECIES NAME ITSELF — which is helpful, because it makes "
    "memorising easy.\n\n"
    "WARNING, 'HAEMATOBIUM' COMES FROM HAEMATURIA: blood in the urine. So SCHISTOSOMA HAEMATOBIUM "
    "means THE URINARY TRACT.\n\n"
    "WHY IS THIS SPECIES URINARY? LOOK AT WHERE IT LAYS ITS EGGS:\n\n"
    "SCHISTOSOMA HAEMATOBIUM LAYS ITS EGGS IN THE VESICAL VENOUS PLEXUS. To escape, the eggs CROSS THE "
    "BLADDER WALL, and in doing so they cause BLEEDING AND INFLAMMATION.\n\n"
    "THE CLASSIC PRESENTATION: PAINLESS HAEMATURIA, especially TERMINAL haematuria. In endemic parts "
    "of Africa it has been so common that it was sometimes regarded in boys as a 'male menstruation'.\n\n"
    "LATE COMPLICATIONS: FIBROSIS AND CALCIFICATION OF THE BLADDER WALL, URETERIC OBSTRUCTION AND "
    "HYDRONEPHROSIS, and above all WARNING, SQUAMOUS CELL CARCINOMA OF THE BLADDER — one of the few "
    "settings in which bladder cancer is SQUAMOUS rather than transitional cell.\n\n"
    "NOW THE OTHER THREE SPECIES:\n\n"
    "SCHISTOSOMA MANSONI — lays eggs in the INFERIOR MESENTERIC VEINS. Involvement: COLON AND LIVER. "
    "Complications: PERIPORTAL (Symmers) FIBROSIS, PORTAL HYPERTENSION, SPLENOMEGALY AND OESOPHAGEAL "
    "VARICES. Geography: Africa and South America.\n\n"
    "SCHISTOSOMA JAPONICUM — in the SUPERIOR MESENTERIC VEINS. The same bowel and liver involvement "
    "but MORE SEVERE (it produces more eggs). Geography: China, the Philippines, Indonesia.\n\n"
    "SCHISTOSOMA MEKONGI — similar to japonicum, in the Mekong basin (Cambodia and Laos). INTESTINAL.\n\n"
    "SO THE SIMPLE RULE: HAEMATOBIUM IS THE ONLY URINARY SPECIES; THE REST ARE INTESTINAL AND HEPATIC.\n\n"
    "AND THE TREATMENT OF ALL: PRAZIQUANTEL. (Remember that FASCIOLA IS THE EXCEPTION, not schistosoma.)",
    ["پاسخ صحیح — در شبکه‌ی وریدی مثانه تخم می‌گذارد و هماچوری بدون درد می‌دهد.",
     "در وریدهای مزانتریک فوقانی تخم می‌گذارد؛ درگیری روده و کبد است، نه ادرار.",
     "در وریدهای مزانتریک تحتانی؛ فیبروز پری‌پورتال و هیپرتانسیون پورت می‌دهد.",
     "مشابه ژاپونیکوم و روده‌ای است؛ در حوضه‌ی رود مکونگ دیده می‌شود."],
    ["Correct — it lays eggs in the vesical venous plexus and causes painless haematuria.",
     "Lays eggs in the superior mesenteric veins; bowel and liver involvement, not urinary.",
     "In the inferior mesenteric veins; causes periportal fibrosis and portal hypertension.",
     "Similar to japonicum and intestinal; found in the Mekong basin."],
    "**هماتوبیوم = هماچوری = مثانه. بقیه‌ی شیستوزوماها روده و کبد.**",
    "Haematobium means haematuria means bladder. The other schistosomes take bowel and liver.",
    CREFS)

json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book45.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 45 lessons:', len(L))
