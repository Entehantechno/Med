# -*- coding: utf-8 -*-
"""English stems and options for the batch-34 questions.

Infectious mononucleosis and herpes simplex.

Rule 16 checked first, as always: these items come from sittings 93 to 98, for
which the ministry published no English booklet, so these are hand-written
translations rather than official ones.

Translation decisions worth recording
-------------------------------------
q9604 (idx 604) CARRIES A CORRECTED KEY, and the English options are translated
exactly as printed, INCLUDING the option the book keyed. The stem must say what
the paper said; it is the lesson that explains that anti-EBNA appears 6 to 12
weeks after onset and that its presence early in the illness excludes acute EBV
infection. Softening or "fixing" an option in translation would hide the very
error the correction exists to teach.

THE SEROLOGICAL MARKER NAMES keep their standard English forms — VCA, EBNA, EA,
heterophile — rather than being spelled out in words, because that is how they
appear on a request form and in every guideline, and because the whole question
turns on telling them apart.

THE ATYPICAL LYMPHOCYTE PERCENTAGES are preserved exactly (20% in q9596, 12% in
q9604, and the 25,000 white count with lymphocyte predominance in q9601). They
are not decoration: the conventional threshold for mononucleosis is 10 per cent,
so the specific figure is what makes each stem answerable.

q9601's "5 days ago ... one dose of benzathine penicillin" is preserved with
both numbers, because the question is decided by the FAILURE TO RESPOND within
a period in which streptococcal pharyngitis would have responded.

'PAINFUL' IS LOAD-BEARING throughout the herpes questions, exactly as it was in
the genital-ulcer block, and is translated literally every time.
"""

EN16 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    assert all(o.strip() for o in options), idx
    EN16[idx] = {"stem_en": stem, "options_en": options}


# ===================================== infectious mononucleosis (batch 34)
add(596,
    "A 20-year-old man presents with sore throat, malaise, abdominal pain, nausea and vomiting. On "
    "examination he has lymphadenopathy, splenomegaly and exudative pharyngitis. A papular rash is "
    "seen on the limbs and trunk. The peripheral blood film is reported as showing more than 20 per "
    "cent atypical lymphocytes. Which of the following agents is more likely?",
    ["Herpes virus",
     "Streptococcus",
     "Epstein-Barr virus",
     "Cytomegalovirus"])

add(601,
    "A 15-year-old adolescent is brought to the clinic with fever and a 10-day sore throat. He "
    "received one dose of benzathine penicillin 5 days ago. His respiratory status is normal, there "
    "is obvious exudate on the tonsils together with cervical and axillary adenopathy. The full "
    "blood count shows a white cell count of 25,000 with a lymphocyte predominance. Which action is "
    "appropriate?",
    ["Give a 10-day course of oral penicillin",
     "Give azithromycin for 5 days",
     "Symptomatic treatment is sufficient",
     "Give prednisolone for 5 days"])

add(602,
    "A 7-year-old girl presents with fever, sore throat, weakness and marked malaise. Her laboratory "
    "findings favour haemolytic anaemia. Specific tests show EBV IgM antibody positive and EBV IgG "
    "negative. Which of the following treatments do you recommend for this patient's haemolytic "
    "anaemia?",
    ["Corticosteroid",
     "Aciclovir",
     "Rituximab",
     "Immunoglobulin"])

add(604,
    "An 18-year-old woman presents with fever and sore throat. On examination she has obvious "
    "exudative pharyngitis, cervical lymphadenopathy and hepatosplenomegaly, and her tests report "
    "lymphocytosis with more than 12 per cent atypical lymphocytes. Which is the most useful "
    "diagnostic test to establish her diagnosis?",
    ["IgM antibody for EBNA (Epstein-Barr Nuclear Antigen)",
     "Heterophile test",
     "IgM antibody for VCA (Viral Capsid Antigen)",
     "IgM antibody for EA (early antigen)"])


# ============================================ herpes simplex (batch 34)
add(605,
    "A child with a previous history of atopic eczema is brought to you with multiple vesicular "
    "lesions on an erythematous base on the face. Which is the most likely causative microorganism "
    "of this clinical syndrome?",
    ["Staphylococcus aureus",
     "Pseudomonas aeruginosa",
     "Herpes simplex virus",
     "Varicella zoster virus"])

add(607,
    "A 20-year-old man has felt feverish with headache and body aches for the past four days, "
    "accompanied by painful ulcers on the penis. He has no significant past medical history. On "
    "examination multiple vesiculopustular ulcers are seen on the shaft of the penis and he has "
    "painful bilateral inguinal lymphadenopathy. Which diagnosis is most likely for this patient?",
    ["Primary syphilis",
     "Secondary syphilis",
     "Primary genital herpes",
     "Recurrent genital herpes"])

add(611,
    "An informally trained dentist presents with a painful lesion of the right index finger with a "
    "swollen vesiculopustular appearance. On examination there is a slight fever and local "
    "tenderness. Which treatment is recommended?",
    ["Fluconazole capsules",
     "Oral clindamycin",
     "Surgical drainage",
     "Aciclovir tablets"])

add(613,
    "The neonate of a mother with a history of genital herpes is admitted to the intensive care "
    "unit. The neonate is febrile and unwell. If neonatal herpes is suspected, which of the "
    "following treatments is most appropriate?",
    ["Intravenous aciclovir",
     "Intravenous ganciclovir",
     "Intravenous valaciclovir",
     "Intravenous famciclovir"])
