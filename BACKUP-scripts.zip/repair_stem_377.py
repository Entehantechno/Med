# -*- coding: utf-8 -*-
"""Rebuild the stem of book question idx 377, which the PDF prints corrupted.

The defect is in the SOURCE, not in our extraction. On page 142 the exporter
emits the second half of this vignette twice, interleaved, so the stored text
reads (translated) "... the abdomen is very rigid. A 3x2 cm wound ... created
10 days ago. BP, PR=21, C. mmHg 90/60 with regard to mmHg 90/60. BP, min
created. with scant purulent discharge you see-very rigid. a 3x2 cm wound in a
decorticate posture 37.5=T ...". Sentences restart mid-clause and the vital
signs appear twice, once mangled.

A student cannot read that, and no honest translation of it exists. But the
clinical facts are all recoverable, because glyph geometry gives every number
unambiguously. Reading the digit runs of page 142 in printed (left-to-right)
order:

    age        "07" visual  -> 70 years
    PR         "021" visual -> 120 beats/min
    BP                      -> 90/60 mmHg  (printed twice by the defect)
    wound age  "01" visual  -> 10 days
    temperature"5/73" visual-> 37.5 C
    wound size              -> 3x2 cm, between the 2nd and 3rd toes

So the stem is rewritten once, by hand, from those verified values and the
non-duplicated Persian clauses. Nothing is invented: every clinical statement
below appears in the source, and every number is the geometrically-read value.
The question, options and printed answer key are untouched.

Digits are written in ASCII, matching every other stem in this payload, because
a guard test enforces it — a stray non-ASCII digit is the fingerprint of the
mixed-digit extraction bug.

The rewrite is recorded on the question itself (`stem_repaired`,
`stem_repair_note_fa/en`) so the change is never silent, exactly as the age,
vitals and key corrections are recorded.
"""
import json, io, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
TARGET_NO = 9377

STEM_FA = (
    "آقای 70 ساله‌ی کشاورز، به دنبال ضعف و بی‌حالی و درد عضلانی از 2 روز قبل، "
    "دچار اسپاسم عضلات صورت و اختلال بلع شده بود. با پیشرفت علائم، با اسپاسم "
    "جنرالیزه در وضعیت دکورتیکه و در حالی که هوشیار است و به سختی نفس می‌کشد به "
    "شما ارجاع شده است. در معاینه، سمع ریه‌ها نرمال و صداهای قلبی طبیعی است و "
    "شکم به شدت سفت است. یک زخم 3×2 سانتی‌متری بین انگشتان 2 و 3 اندام تحتانی چپ "
    "همراه با ترشح چرکی مختصر دیده می‌شود که 10 روز قبل و حین کار ایجاد شده است. "
    "علائم حیاتی: دمای 37/5 درجه‌ی سانتی‌گراد، نبض 120 در دقیقه، فشار خون 90/60 "
    "میلی‌متر جیوه. با توجه به محتمل‌ترین تشخیص، ضمن اینتوباسیون و اصلاح وضعیت "
    "همودینامیک، کدام اقدام درمانی را در نظر می‌گیرید؟"
)

NOTE_FA = (
    "متن این سؤال در فایل PDF کتاب به‌صورت تکراری و درهم چاپ شده بود (نیمه‌ی دوم "
    "صورت سؤال دو بار و بریده‌بریده تکرار شده بود). متن از روی همان صفحه و با "
    "خواندن ترتیب افقی نویسه‌ها بازسازی شد؛ همه‌ی اعداد (سن ۷۰، نبض ۱۲۰، فشار "
    "۹۰/۶۰، دمای ۳۷/۵، زخم ۱۰ روزه) از روی مختصات گلیف‌ها راستی‌آزمایی شده‌اند. "
    "گزینه‌ها و کلید پاسخ دست‌نخورده‌اند."
)
NOTE_EN = (
    "This question's text was printed corrupted in the book's PDF: the second half of "
    "the vignette was duplicated and interleaved. The stem was rebuilt from the same "
    "page by reading the glyphs in printed left-to-right order; every number (age 70, "
    "PR 120, BP 90/60, T 37.5, 10-day-old wound) was verified against glyph geometry. "
    "The options and answer key are unchanged."
)

# Facts that must survive the rewrite, as a guard against a careless edit.
REQUIRED = ['70', '2', '37/5', '120', '90/60', '10', 'دکورتیکه', 'هوشیار',
            'اسپاسم', 'کشاورز']


def main():
    for i in range(1, 6):
        p = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        if not os.path.exists(p):
            continue
        body = json.load(io.open(p, encoding='utf-8'))
        changed = False
        for q in body['questions']:
            if q.get('question_no') != TARGET_NO:
                continue
            if q.get('stem_repaired'):
                print('already repaired')
                return

            missing = [t for t in REQUIRED if t not in STEM_FA]
            if missing:
                sys.exit(f'rewritten stem lost required facts: {missing}')

            # The pulse is the one value the corrupted text mangled beyond a
            # simple mirror: the page prints the digit run "021" (=120), but the
            # duplication defect truncated it to "21" in the extracted text. The
            # glyph reading is unambiguous, so the rebuild uses 120 and records
            # the discrepancy rather than letting it look like an invention.
            q['stem_number_recovered'] = {'PR': {'corrupted_text': '21',
                                                 'glyph_order': '021',
                                                 'value': '120'}}
            q['stem_original_fa'] = q['question_fa']
            q['question_fa'] = STEM_FA
            q['stem_repaired'] = 'duplicated_pdf_text'
            q['stem_repair_note_fa'] = NOTE_FA
            q['stem_repair_note_en'] = NOTE_EN
            # the fingerprint is derived from the stem and must follow it
            txt = re.sub(r'[۰-۹0-9]', '#', STEM_FA)
            txt = re.sub(r'[^\w\s#]', ' ', txt)
            q['fingerprint'] = ('بیماری‌های عفونی Infectious Diseases '
                                + re.sub(r'\s+', ' ', txt).strip())[:400]
            changed = True
            print(f'q{TARGET_NO}: stem rebuilt '
                  f'({len(q["stem_original_fa"])} -> {len(STEM_FA)} chars)')
        if changed:
            json.dump(body, io.open(p, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)


if __name__ == '__main__':
    main()
