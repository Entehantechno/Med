# -*- coding: utf-8 -*-
"""Cross-check EVERY number of the parasitology chapter against glyph geometry.

The principle, established with the ministry's bilingual booklet and reused for
the archive ages and the vital signs: a number is always drawn left to right,
even inside right-to-left script. So the digits of a PDF line, sorted by their
x-coordinate, are the digits as the typesetter placed them. The extracted text
is the *logical* order, which for an RTL line runs the other way round — that is
exactly where a two-digit value gets mirrored.

This script does not repair anything. For every question of the chapter it
finds the book line whose Persian LETTERS match a sentence or an option, and
reports whether the stored number can be read out of the page's printed digits.
A disagreement is printed with both readings so it can be judged one at a time.

Matching on letters only is deliberate: the digits are the thing under suspicion,
so they must not take part in identifying the line.
"""
import json, io, os, re, collections

import pdfplumber

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = '/home/user/uploads/بیماری عفونی.pdf'
CHAPTER = 'زئونوزها و بیماری‌های منتقله از حیوان'


def letters(s):
    s = re.sub(r'[\u0660-\u0669\u06F0-\u06F9]', '', s or '')
    return re.sub(r'[^\u0600-\u06FF]', '', s)


def load_lines():
    out = []
    with pdfplumber.open(SRC) as pdf:
        for pno, page in enumerate(pdf.pages, 1):
            rows = collections.defaultdict(list)
            for c in page.chars:
                rows[round(c['top'])].append(c)
            for top in sorted(rows):
                cs = sorted(rows[top], key=lambda c: c['x0'])
                text = ''.join(c['text'] for c in cs)[::-1]
                digits = ''.join(c['text'] for c in cs if c['text'].isdigit())
                out.append((pno, letters(text), digits, text))
    return out


def main():
    qs, flat = [], 0
    for i in range(1, 6):
        body = json.load(io.open(os.path.join(
            HERE, f'import-payload.book.part{i:02d}.json'), encoding='utf-8'))
        for q in body['questions']:
            if q['chapter_fa'] == CHAPTER:
                qs.append((flat, q))
            flat += 1

    lines = load_lines()
    index = collections.defaultdict(list)
    for pno, key, digits, text in lines:
        if len(key) >= 14:
            index[key].append((pno, digits, text))

    n_ok = n_bad = n_unmatched = 0
    for idx, q in qs:
        pieces = re.split(r'(?<=[.؟])\s+', q['question_fa']) + list(q['options_fa'])
        for piece in pieces:
            nums = re.findall(r'\d+', piece)
            if not nums:
                continue
            key = letters(piece)
            if len(key) < 14:
                continue
            # a line of the book is a physical line; a stored sentence may span
            # two of them, so probe with the longest prefix that lands on
            # exactly one line
            hit = None
            for cut in (60, 46, 34, 26, 20, 16):
                cands = [v for k, v in index.items() if key[:cut] in k]
                flatc = [c for group in cands for c in group]
                if len(flatc) == 1:
                    hit = flatc[0]
                    break
            if not hit:
                n_unmatched += 1
                continue
            pno, printed, text = hit
            # every stored number should be readable straight out of the
            # printed digit run; if only its mirror is, the value is mirrored
            for v in nums:
                if len(v) < 2:
                    continue
                fwd, rev = v in printed, v[::-1] in printed
                if fwd:
                    n_ok += 1
                elif rev:
                    n_bad += 1
                    print(f'idx={idx} q{q["question_no"]} p{pno}  MIRRORED  '
                          f'stored={v}  page reads {v[::-1]}')
                    print(f'    stored piece: {piece.strip()[:110]}')
                    print(f'    page line   : {text.strip()[:110]}')
                    print(f'    page digits : {printed}')
                else:
                    n_bad += 1
                    print(f'idx={idx} q{q["question_no"]} p{pno}  NOT ON PAGE '
                          f'stored={v}  page digits={printed}')
                    print(f'    stored piece: {piece.strip()[:110]}')
                    print(f'    page line   : {text.strip()[:110]}')
    print(f'\nagree={n_ok}  disagree={n_bad}  unmatched-pieces={n_unmatched}')


if __name__ == '__main__':
    main()
