# -*- coding: utf-8 -*-
"""Micro-lessons, batch 11 — amoebiasis, giardiasis and toxoplasmosis.

Why this chapter, and why the audit had to come first
-----------------------------------------------------
101 questions with two taught: the largest teaching gap in the book. But the
chapter was audited before a single lesson was written, and the audit paid for
itself immediately. Six numbers were mirrored, three printed keys were wrong,
and two of those keys sit on numbers the extractor had reversed — so a lesson
written first would have taught the wrong medicine with confidence.

The three teaching spines of this batch
---------------------------------------
1. AMOEBIASIS: the tissue/luminal split. Metronidazole kills the invading
   trophozoite and does almost nothing to the cysts left sitting in the lumen,
   so every symptomatic patient needs a SECOND, luminal drug or they relapse
   and keep infecting others. The asymptomatic cyst passer is the mirror image:
   there is no tissue invasion to treat, so a luminal drug ALONE is correct.
   The same two sentences answer eight questions of this chapter.

2. GIARDIASIS: watery, fatty, gassy — never bloody. The single most examined
   discriminator in the whole parasitology block is that giardia does NOT cause
   dysentery, because it does not invade. And refractory giardiasis is an
   IMMUNOLOGICAL question, not a pharmacological one: the gut's defence against
   Giardia is secretory IgA, so a patient who cannot clear it is a patient who
   may not be making antibody.

3. TOXOPLASMOSIS: the competent host needs no treatment, and the trimester
   paradox. Transmission rises through pregnancy while severity falls, which is
   why first-trimester infection is rare but devastating and third-trimester
   infection is common but usually silent at birth. Half of the toxoplasma
   questions in this chapter are one or other half of that sentence.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022),
Chapters 222 (amoebiasis), 223 (giardiasis) and 226 (toxoplasmosis).
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H222 = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 222"
H223 = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 223"
H226 = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 226"
MSD = "MSD Manual Professional — Amebiasis / Toxoplasmosis"

# The two-compartment rule, repeated word for word in every amoebiasis lesson
# so the student meets identical wording each time and it becomes automatic.
AMEBA_FA = [
    "آمیب هیستولیتیکا در بدن **دو جای متفاوت** زندگی می‌کند، و کل درمانش از همین دو جا بیرون می‌آید.",
    "**جای اول — بافت**: تروفوزوئیت مهاجم که دیواره‌ی روده یا کبد را درگیر می‌کند.",
    "**جای دوم — لومن روده**: کیست‌هایی که آرام در مجرا نشسته‌اند و از مدفوع دفع می‌شوند.",
    "**مترونیدازول** (و هم‌خانواده‌اش تینیدازول) داروی **بافتی** است.",
    "مترونیدازول تروفوزوئیت مهاجم را عالی می‌کشد، و علائم بیمار را سریع برطرف می‌کند.",
    "⚠️ اما مترونیدازول در **لومن** غلظت کافی پیدا نمی‌کند و کیست‌ها را ریشه‌کن نمی‌کند.",
    "پس اگر فقط مترونیدازول بدهیم، بیمار خوب می‌شود ولی **ناقل می‌ماند و عود می‌کند**.",
    "**داروی لومینال** لازم است: پارومومایسین، یدوکینول، یا دیلوکسانید فوروات.",
    "قاعده‌ی طلایی یک: بیمار **علامت‌دار** ← داروی بافتی **به‌علاوه‌ی** داروی لومینال.",
    "قاعده‌ی طلایی دو: ناقل **بدون علامت** ← فقط داروی **لومینال**، بدون مترونیدازول.",
    "منطق قاعده‌ی دو ساده است: تهاجم بافتی وجود ندارد، پس داروی بافتی چیزی برای کشتن ندارد.",
    "و دادن مترونیدازول به فرد بی‌علامت فقط عارضه و مقاومت اضافه می‌کند.",
]
AMEBA_EN = [
    "Entamoeba histolytica lives in TWO different places in the body, and its whole treatment follows from that.",
    "PLACE ONE, the TISSUE: the invading trophozoite in the bowel wall or the liver.",
    "PLACE TWO, the GUT LUMEN: cysts sitting quietly in the lumen and passed in the stool.",
    "METRONIDAZOLE (and its relative tinidazole) is the TISSUE drug.",
    "Metronidazole kills the invading trophozoite superbly and relieves the symptoms quickly.",
    "WARNING: metronidazole does not reach an adequate concentration in the LUMEN and does not eradicate the cysts.",
    "So if metronidazole is given alone the patient improves but STAYS A CARRIER AND RELAPSES.",
    "A LUMINAL drug is required: paromomycin, iodoquinol or diloxanide furoate.",
    "Golden rule one: a SYMPTOMATIC patient needs a tissue drug PLUS a luminal drug.",
    "Golden rule two: an ASYMPTOMATIC cyst passer needs the LUMINAL drug ONLY, with no metronidazole.",
    "The logic of rule two is simple: there is no tissue invasion, so a tissue drug has nothing to kill.",
    "And giving metronidazole to an asymptomatic person only adds side effects and resistance.",
]


# ---------------------------------------------------------------- idx 727
add("book:727", "case", "easy",
 "اسهال با **RBC فراوان و WBC اندک** = **آمیب**؛ باکتری مهاجم برعکس است.",
 "Diarrhoea with MANY red cells but FEW white cells means AMOEBA; invasive bacteria give the opposite.",
 [
  "این سؤال با یک نکته‌ی ساده‌ی آزمایشگاهی حل می‌شود که خیلی‌ها از آن رد می‌شوند.",
  "در آزمایش مدفوع، **نسبت گلبول قرمز به گلبول سفید** خودش یک ابزار تشخیصی است.",
  "**آمیب هیستولیتیکا**: گلبول قرمز **فراوان**، گلبول سفید **کم**.",
  "چرا؟ چون آمیب گلبول‌های سفید را **می‌بلعد و از بین می‌برد**.",
  "آمیب حتی گلبول قرمز را هم می‌بلعد؛ به تروفوزوئیت حاوی RBC می‌گویند **اریتروفاگوسیتوز**.",
  "دیدن اریتروفاگوسیتوز تقریباً **تشخیصی** برای آنتاموبا هیستولیتیکا است.",
  "**شیگلا و باکتری‌های مهاجم**: گلبول سفید **فراوان** (پاسخ نوتروفیلی شدید).",
  "پس فرمول: RBC زیاد + WBC کم ← آمیب. WBC زیاد ← شیگلا و باکتری مهاجم.",
  "تابلوی بالینی آمیب هم کمک می‌کند: درد **پایین شکم**، تنسموس، اسهال خونی تدریجی.",
  "«دل‌پیچه» و درد ربع تحتانی همان کولیت آمیبی است که سکوم و کولون صعودی را می‌گیرد.",
  "**ویبریو کلرا** اصلاً خونی نیست: اسهال آبکی حجیم و بدون گلبول (اسهال ترشحی).",
  "**ژیاردیا** هم هرگز خونی نیست، چون به دیواره تهاجم نمی‌کند.",
  "OB مثبت سه‌مثبت یعنی خون واقعی در مدفوع، که ژیاردیا و کلرا را کنار می‌گذارد.",
 ],
 [
  "This question turns on one simple laboratory point that many students walk straight past.",
  "In a stool examination, the RATIO of red cells to white cells is itself a diagnostic tool.",
  "ENTAMOEBA HISTOLYTICA: MANY red cells, FEW white cells.",
  "Why? Because the amoeba INGESTS AND DESTROYS the white cells.",
  "It ingests red cells too; a trophozoite containing RBCs is called ERYTHROPHAGOCYTOSIS.",
  "Seeing erythrophagocytosis is essentially DIAGNOSTIC of Entamoeba histolytica.",
  "SHIGELLA and the invasive bacteria: MANY white cells (an intense neutrophil response).",
  "So the formula is: many RBC + few WBC -> amoeba. Many WBC -> shigella and invasive bacteria.",
  "The clinical picture helps too: LOWER abdominal pain, tenesmus, and gradual bloody diarrhoea.",
  "Cramping lower-quadrant pain is amoebic colitis, which favours the caecum and ascending colon.",
  "VIBRIO CHOLERAE is never bloody: a huge watery, cell-free secretory diarrhoea.",
  "GIARDIA is never bloody either, because it does not invade the wall.",
  "A strongly positive occult blood means real blood in the stool, which excludes giardia and cholera.",
 ],
 "کلید این سؤال، **نسبت گلبول قرمز به گلبول سفید در مدفوع** است — نکته‌ای که در تشخیص افتراقی اسهال خونی بارها به کار می‌آید.\n\nآمیب هیستولیتیکا گلبول‌های سفید را **می‌بلعد و تخریب می‌کند**، بنابراین تابلوی آزمایشگاهی‌اش **گلبول قرمز فراوان با گلبول سفید اندک** است. اگر خوش‌شانس باشید تروفوزوئیتی می‌بینید که خودش گلبول قرمز بلعیده — **اریتروفاگوسیتوز** — که تقریباً تشخیصی است.\n\nدر مقابل، **شیگلا** و سایر باکتری‌های مهاجم پاسخ نوتروفیلی شدید ایجاد می‌کنند و مدفوع پر از **گلبول سفید** است. **ویبریو کلرا** اسهال آبکی و بدون سلول می‌دهد و اصلاً خونی نیست، و **ژیاردیا** چون تهاجم نمی‌کند هرگز اسهال خونی نمی‌سازد.\n\nتابلوی بالینی هم همین را می‌گوید: درد **ربع تحتانی شکم** و دل‌پیچه، تصویر کولیت آمیبی است که سکوم و کولون صعودی را درگیر می‌کند.",
 "The key to this question is the RATIO OF RED TO WHITE CELLS in the stool — a point that repays itself repeatedly in the differential diagnosis of bloody diarrhoea.\n\nEntamoeba histolytica INGESTS AND DESTROYS white cells, so its laboratory picture is MANY RED CELLS WITH FEW WHITE CELLS. If you are lucky you see a trophozoite that has itself swallowed red cells — ERYTHROPHAGOCYTOSIS — which is essentially diagnostic.\n\nBy contrast SHIGELLA and the other invasive bacteria provoke an intense neutrophil response and the stool is full of WHITE CELLS. VIBRIO CHOLERAE produces a watery, cell-free diarrhoea that is never bloody, and GIARDIA, which does not invade, never causes bloody diarrhoea at all.\n\nThe clinical picture says the same thing: cramping LOWER-QUADRANT pain is the picture of amoebic colitis, which involves the caecum and ascending colon.",
 ["کلرا اسهال آبکی حجیم و بدون سلول می‌دهد؛ با خون در مدفوع سازگار نیست.",
  "پاسخ صحیح — گلبول قرمز فراوان با گلبول سفید اندک، الگوی کلاسیک آمیب است.",
  "ژیاردیا تهاجم نمی‌کند، پس اسهال خونی و OB مثبت نمی‌دهد.",
  "شیگلا هم اسهال خونی می‌دهد، ولی با گلبول سفید **فراوان** نه اندک."],
 ["Cholera gives a huge, cell-free watery diarrhoea, incompatible with blood in the stool.",
  "Correct — many red cells with few white cells is the classic amoebic pattern.",
  "Giardia does not invade, so it does not cause bloody diarrhoea or a positive occult blood.",
  "Shigella also causes bloody diarrhoea, but with MANY white cells, not few."],
 "مدفوع: **RBC زیاد + WBC کم = آمیب**. WBC زیاد = شیگلا. بدون خون = کلرا یا ژیاردیا.",
 "Stool: many RBC + few WBC = amoeba. Many WBC = shigella. No blood = cholera or giardia.",
 [H222, MSD])


# ---------------------------------------------------------------- idx 730
add("book:730", "case", "easy",
 "آمیب علامت‌دار = **مترونیدازول (بافت) + یدوکینول (لومن)**؛ هیچ‌کدام به‌تنهایی کافی نیست.",
 "Symptomatic amoebiasis needs METRONIDAZOLE (tissue) PLUS IODOQUINOL (lumen); neither alone is enough.",
 AMEBA_FA + [
  "این بیمار **علامت‌دار** است: اسهال خونی به دنبال آب آلوده.",
  "و تروفوزوئیت در مدفوع دیده شده، یعنی تهاجم بافتی فعال دارد.",
  "پس قاعده‌ی یک اجرا می‌شود: **مترونیدازول + یک داروی لومینال**.",
  "مترونیدازول ۷۵۰ میلی‌گرم هر ۸ ساعت به مدت ۷ تا ۱۰ روز، سپس داروی لومینال.",
  "سیپروفلوکساسین اینجا جایی ندارد؛ آمیب یک **انگل** است نه باکتری.",
 ],
 AMEBA_EN + [
  "This patient IS symptomatic: bloody diarrhoea after drinking contaminated water.",
  "And trophozoites were seen in the stool, so tissue invasion is active.",
  "Rule one therefore applies: METRONIDAZOLE PLUS A LUMINAL DRUG.",
  "Metronidazole 750 mg every 8 hours for 7-10 days, followed by the luminal agent.",
  "Ciprofloxacin has no place here; the amoeba is a PARASITE, not a bacterium.",
 ],
 "این بیمار اسهال خونی دارد و در مدفوعش **تروفوزوئیت** آمیب دیده شده — یعنی آمیبیاز **علامت‌دار با تهاجم بافتی فعال**. اینجا قاعده‌ی دوبخشی درمان آمیب کاملاً اجرا می‌شود.\n\n**مترونیدازول** تروفوزوئیت مهاجم را در بافت می‌کشد و علائم را برطرف می‌کند، ولی در **لومن روده** به غلظت کافی نمی‌رسد و کیست‌ها را ریشه‌کن نمی‌کند. اگر همین‌جا متوقف شویم، بیمار بهتر می‌شود اما **ناقل باقی می‌ماند و عود می‌کند**.\n\nبنابراین پس از مترونیدازول باید یک **داروی لومینال** داد: **یدوکینول**، پارومومایسین یا دیلوکسانید فوروات. ترکیب مترونیدازول + یدوکینول هر دو محفظه را پاک می‌کند و همین گزینه‌ی درست است.\n\n⚠️ سیپروفلوکساسین یک آنتی‌بیوتیک ضدباکتری است و روی آنتاموبا اثری ندارد؛ حضورش در هر گزینه‌ای، آن گزینه را رد می‌کند.",
 "This patient has bloody diarrhoea and TROPHOZOITES in the stool — symptomatic amoebiasis with active tissue invasion. The two-compartment rule applies in full.\n\nMETRONIDAZOLE kills the invading trophozoite in the tissue and relieves the symptoms, but it does not reach an adequate concentration in the GUT LUMEN and does not eradicate the cysts. Stop there and the patient improves but REMAINS A CARRIER AND RELAPSES.\n\nSo metronidazole must be followed by a LUMINAL drug: IODOQUINOL, paromomycin or diloxanide furoate. Metronidazole plus iodoquinol clears both compartments, and that is the correct option.\n\nWARNING: ciprofloxacin is an antibacterial and has no activity against Entamoeba; its presence in an option rules that option out.",
 ["مترونیدازول تنها، تروفوزوئیت را می‌کشد ولی کیست‌های لومینال را ریشه‌کن نمی‌کند و بیمار عود می‌کند.",
  "سیپروفلوکساسین آنتی‌بیوتیک ضدباکتری است و روی آمیب اثری ندارد.",
  "پاسخ صحیح — داروی بافتی به‌علاوه‌ی داروی لومینال، هر دو محفظه را پاک می‌کند.",
  "سیپروفلوکساسین تنها، نه بافت را درمان می‌کند نه لومن را؛ کاملاً بی‌اثر است."],
 ["Metronidazole alone kills the trophozoite but does not eradicate the luminal cysts, so the patient relapses.",
  "Ciprofloxacin is an antibacterial with no activity against the amoeba.",
  "Correct — a tissue drug plus a luminal drug clears both compartments.",
  "Ciprofloxacin alone treats neither the tissue nor the lumen; it is entirely ineffective."],
 "آمیب **علامت‌دار** = بافتی (مترونیدازول) **+** لومینال (یدوکینول/پارومومایسین). یکی به‌تنهایی هرگز.",
 "SYMPTOMATIC amoebiasis = tissue drug (metronidazole) PLUS luminal drug (iodoquinol/paromomycin). Never one alone.",
 [H222, MSD])


# ---------------------------------------------------------------- idx 736
add("book:736", "recall", "medium",
 "ناقل **بی‌علامت** کیست آمیب = فقط داروی **لومینال** (پارومومایسین ۵۰۰ میلی‌گرم × ۳، ۷ روز).",
 "An ASYMPTOMATIC amoebic cyst passer needs a LUMINAL drug only: paromomycin 500 mg three times daily for 7 days.",
 AMEBA_FA + [
  "این سؤال دقیقاً **قاعده‌ی دو** را می‌پرسد: فرد بی‌علامت اما ناقل کیست.",
  "پاسخ: **پارومومایسین ۵۰۰ میلی‌گرم سه بار در روز به مدت ۷ روز**.",
  "چرا اصلاً درمان می‌کنیم اگر بیمار علامتی ندارد؟ دو دلیل محکم دارد.",
  "دلیل اول: جلوگیری از **بیماری مهاجم** در آینده — کولیت یا آبسه‌ی کبدی.",
  "دلیل دوم: قطع **انتقال به دیگران**؛ ناقل بی‌علامت کیست دفع می‌کند و منبع آلودگی است.",
  "⚠️ نکته‌ی مهم: باید مطمئن شویم انگل واقعاً **هیستولیتیکا** است نه **دیسپار**.",
  "آنتاموبا دیسپار از نظر شکل دقیقاً شبیه هیستولیتیکا است ولی **بیماری‌زا نیست** و درمان نمی‌خواهد.",
  "«صبر می‌کنیم تا علامت‌دار شود» غلط است: تا آن زمان ممکن است آبسه‌ی کبدی داده باشد.",
 ],
 AMEBA_EN + [
  "This question asks RULE TWO exactly: a person with no symptoms who is passing cysts.",
  "The answer is PAROMOMYCIN 500 mg three times daily for seven days.",
  "Why treat at all if the patient has no symptoms? There are two solid reasons.",
  "Reason one: to prevent future INVASIVE disease — colitis or a liver abscess.",
  "Reason two: to stop TRANSMISSION; an asymptomatic carrier passes cysts and is a source of infection.",
  "WARNING: one must be sure the parasite really is HISTOLYTICA and not DISPAR.",
  "Entamoeba dispar is morphologically identical but is NOT pathogenic and needs no treatment.",
  "'Wait until symptoms appear' is wrong: by then the patient may already have a liver abscess.",
 ],
 "این پرسش دقیقاً همان **قاعده‌ی دوم** درمان آمیبیاز است: فرد **بی‌علامت** اما ناقل کیست، فقط داروی **لومینال** می‌خواهد — **پارومومایسین ۵۰۰ میلی‌گرم سه بار در روز به مدت ۷ روز**.\n\nمنطق روشن است: تهاجم بافتی وجود ندارد، پس مترونیدازول (داروی بافتی) چیزی برای کشتن ندارد و فقط عارضه اضافه می‌کند. آنچه باید پاک شود، **کیست‌های داخل لومن** است، و پارومومایسین دقیقاً همان‌جا کار می‌کند چون از روده جذب نمی‌شود.\n\nولی چرا اصلاً درمان می‌کنیم؟ دو دلیل: اول جلوگیری از **بیماری مهاجم آینده** (کولیت آمیبی یا آبسه‌ی کبدی)، و دوم قطع **انتقال به دیگران** — به‌ویژه در کسی که با غذا سروکار دارد.\n\n⚠️ یک هشدار مهم: **آنتاموبا دیسپار** از نظر میکروسکوپی از هیستولیتیکا قابل تفکیک نیست ولی بیماری‌زا نیست و درمان نمی‌خواهد. تشخیص افتراقی نیازمند آزمون آنتی‌ژن یا PCR است.",
 "This asks RULE TWO of amoebiasis treatment exactly: an ASYMPTOMATIC cyst passer needs a LUMINAL drug only — PAROMOMYCIN 500 mg three times daily for seven days.\n\nThe logic is clear: there is no tissue invasion, so metronidazole (the tissue drug) has nothing to kill and only adds side effects. What must be cleared are the CYSTS IN THE LUMEN, and paromomycin works exactly there because it is not absorbed from the gut.\n\nBut why treat at all? Two reasons: to prevent FUTURE INVASIVE DISEASE (amoebic colitis or a liver abscess), and to stop TRANSMISSION to others — especially in someone who handles food.\n\nWARNING: ENTAMOEBA DISPAR is microscopically indistinguishable from histolytica but is not pathogenic and needs no treatment. Telling them apart requires an antigen test or PCR.",
 ["پاسخ صحیح — ناقل بی‌علامت فقط داروی لومینال می‌خواهد؛ پارومومایسین ۵۰۰ میلی‌گرم سه بار در روز، ۷ روز.",
  "به تأخیر انداختن درمان تا شش هفته بعد، فرصت بروز بیماری مهاجم را می‌دهد.",
  "منتظر ماندن تا بروز کولیت، دقیقاً همان چیزی است که می‌خواهیم از آن پیشگیری کنیم.",
  "«اقدام خاصی لازم نیست» غلط است: ناقل کیست دفع می‌کند و در معرض بیماری مهاجم است."],
 ["Correct — an asymptomatic carrier needs only a luminal drug: paromomycin 500 mg three times daily for 7 days.",
  "Delaying treatment for six weeks allows time for invasive disease to develop.",
  "Waiting for colitis to appear is precisely what we are trying to prevent.",
  "'No action needed' is wrong: the carrier passes cysts and is at risk of invasive disease."],
 "ناقل **بی‌علامت** = فقط لومینال (پارومومایسین/یدوکینول). **بدون** مترونیدازول.",
 "ASYMPTOMATIC carrier = luminal drug only (paromomycin/iodoquinol). NO metronidazole.",
 [H222, MSD])


# ---------------------------------------------------------------- idx 739
add("book:739", "recall", "easy",
 "داروی **لومینال** آمیبیاز = **پارومومایسین** (جذب نمی‌شود، پس در مجرا می‌ماند).",
 "The LUMINAL drug for amoebiasis is PAROMOMYCIN: it is not absorbed, so it stays in the lumen.",
 AMEBA_FA + [
  "این سؤال مستقیماً می‌پرسد: داروی ریشه‌کنی فرم **لومینال** کدام است؟",
  "پاسخ: **پارومومایسین** — یک آمینوگلیکوزید خوراکی که تقریباً **جذب نمی‌شود**.",
  "و همین جذب‌نشدن، دلیل کارآمدی‌اش است: تمام دارو در مجرای روده باقی می‌ماند.",
  "پارومومایسین در **بارداری و کودکان** هم ارجح است، چون جذب سیستمیک ندارد.",
  "⚠️ احتیاط: در کولیت شدید، جذب از دیواره‌ی آسیب‌دیده ممکن است و سمیت گوشی/کلیوی می‌دهد.",
  "**یدوکینول** هم داروی لومینال است، اما دوره‌ی آن ۲۰ روز است و طولانی‌تر.",
  "**دیلوکسانید فوروات** گزینه‌ی لومینال سوم است، ولی در بسیاری از کشورها موجود نیست.",
  "**مترونیدازول و تینیدازول** هر دو داروی **بافتی** هستند و پاسخ این سؤال نیستند.",
 ],
 AMEBA_EN + [
  "This question asks directly: which drug eradicates the LUMINAL form?",
  "The answer is PAROMOMYCIN — an oral aminoglycoside that is essentially NOT ABSORBED.",
  "And that lack of absorption is exactly why it works: all of the drug stays in the gut lumen.",
  "Paromomycin is also preferred in PREGNANCY and in CHILDREN, because there is no systemic exposure.",
  "WARNING: in severe colitis absorption through the damaged wall is possible, with oto- and nephrotoxicity.",
  "IODOQUINOL is also a luminal drug, but its course is 20 days and therefore longer.",
  "DILOXANIDE FUROATE is the third luminal option, but is unavailable in many countries.",
  "METRONIDAZOLE and TINIDAZOLE are both TISSUE drugs and are not the answer here.",
 ],
 "پرسش مستقیم است: داروی ریشه‌کنی **فرم لومینال** آمیبیاز کدام است؟ پاسخ **پارومومایسین** است.\n\nپارومومایسین یک **آمینوگلیکوزید خوراکی** است که ویژگی کلیدی‌اش این است که از روده **جذب نمی‌شود** — و دقیقاً همین خاصیت آن را به داروی لومینال ایده‌آل تبدیل می‌کند: تمام دارو در مجرا باقی می‌ماند، همان‌جا که کیست‌ها هستند. به همین دلیل در **بارداری و کودکان** هم ارجح است.\n\nدر مقابل، **مترونیدازول و تینیدازول** داروهای **بافتی** هستند؛ جذب خوبی دارند و تروفوزوئیت مهاجم را می‌کشند، ولی در لومن غلظت کافی پیدا نمی‌کنند. **یدوکینول** داروی لومینال است ولی دوره‌ی ۲۰ روزه‌اش آن را به انتخاب دوم تبدیل می‌کند.\n\n⚠️ نکته‌ی ایمنی: در کولیت شدید که دیواره‌ی روده آسیب دیده، بخشی از پارومومایسین می‌تواند جذب شود و سمیت گوشی و کلیوی بدهد.",
 "The question is direct: which drug eradicates the LUMINAL form of amoebiasis? The answer is PAROMOMYCIN.\n\nParomomycin is an ORAL AMINOGLYCOSIDE whose key property is that it is NOT ABSORBED from the gut — and that is precisely what makes it the ideal luminal agent: all of the drug remains in the lumen, where the cysts are. For the same reason it is preferred in PREGNANCY and in CHILDREN.\n\nBy contrast METRONIDAZOLE and TINIDAZOLE are TISSUE drugs: well absorbed, excellent against the invading trophozoite, but never reaching an adequate luminal concentration. IODOQUINOL is a luminal drug, but its 20-day course makes it the second choice.\n\nWARNING on safety: in severe colitis, where the bowel wall is damaged, some paromomycin can be absorbed, causing oto- and nephrotoxicity.",
 ["پاسخ صحیح — پارومومایسین جذب نمی‌شود و در لومن باقی می‌ماند، پس ایده‌آل‌ترین داروی لومینال است.",
  "مترونیدازول داروی بافتی است و در لومن غلظت کافی پیدا نمی‌کند.",
  "تینیدازول هم مثل مترونیدازول نیتروایمیدازول و داروی بافتی است.",
  "یدوکینول واقعاً داروی لومینال است، ولی انتخاب اول نیست چون دوره‌اش ۲۰ روز است."],
 ["Correct — paromomycin is not absorbed and stays in the lumen, making it the ideal luminal agent.",
  "Metronidazole is a tissue drug and never reaches an adequate luminal concentration.",
  "Tinidazole, like metronidazole, is a nitroimidazole and therefore a tissue drug.",
  "Iodoquinol genuinely is a luminal drug, but it is not first choice because the course runs 20 days."],
 "**پارومومایسین** = لومینال، جذب‌نشدنی، ارجح در بارداری. مترونیدازول = بافتی.",
 "PAROMOMYCIN = luminal, non-absorbed, preferred in pregnancy. Metronidazole = tissue.",
 [H222, MSD])


# ---------------------------------------------------------------- idx 740
add("book:740", "recall", "easy",
 "ژیاردیا **هرگز خونی نیست** — چون تهاجم نمی‌کند. اسهال آبکی، چرب و پرنفخ می‌دهد.",
 "Giardia is NEVER bloody, because it does not invade. It gives watery, fatty, gassy diarrhoea.",
 [
  "ژیاردیا لامبلیا در **دئودنوم و ژژونوم** می‌چسبد، و همان‌جا می‌ماند.",
  "⚠️ کلیدی‌ترین نکته: ژیاردیا به دیواره‌ی روده **تهاجم نمی‌کند**.",
  "چون تهاجم نمی‌کند، خونریزی و التهاب مخاطی ایجاد نمی‌کند.",
  "پس **اسهال خونی و دیسانتری با ژیاردیا سازگار نیست** — این کل نکته‌ی سؤال است.",
  "به‌جای تهاجم، ژیاردیا با چسبیدن به سطح، **پرزهای روده را کند و صاف** می‌کند.",
  "نتیجه‌ی صاف شدن پرزها: **سوءجذب** — و از اینجا کل تابلوی بیماری بیرون می‌آید.",
  "**اسهال آبکی و بدبو**: نتیجه‌ی مستقیم سوءجذب.",
  "**استئاتوره** (مدفوع چرب و شناور): چربی جذب نمی‌شود.",
  "**نفخ و آروغ گوگردی و گاز فراوان**: کربوهیدرات جذب‌نشده در کولون تخمیر می‌شود.",
  "**درد و کرامپ شکم، تهوع و استفراغ**: بخشی از همان اختلال عملکرد روده‌ی باریک.",
  "**کاهش وزن** در موارد مزمن، از همان سوءجذب می‌آید.",
  "تب معمولاً وجود ندارد یا خفیف است، چون التهاب مهاجم در کار نیست.",
  "پس فرمول ژیاردیا: آبکی + چرب + پرنفخ + بدون خون + بدون تب.",
  "اگر اسهال **خونی** دیدید، به آمیب، شیگلا، کامپیلوباکتر یا سالمونلا فکر کنید — نه ژیاردیا.",
 ],
 [
  "Giardia lamblia attaches in the DUODENUM AND JEJUNUM and stays there.",
  "WARNING, the crucial point: Giardia does NOT INVADE the bowel wall.",
  "Because it does not invade, it causes no bleeding and no mucosal ulceration.",
  "So BLOODY DIARRHOEA AND DYSENTERY ARE INCOMPATIBLE WITH GIARDIA — that is the whole point of the question.",
  "Instead of invading, Giardia coats the surface and BLUNTS AND FLATTENS THE VILLI.",
  "The consequence of blunted villi is MALABSORPTION — and the entire clinical picture follows from it.",
  "WATERY, FOUL-SMELLING DIARRHOEA: a direct result of malabsorption.",
  "STEATORRHOEA (greasy, floating stool): fat is not absorbed.",
  "BLOATING, SULPHUROUS BELCHING AND EXCESS GAS: unabsorbed carbohydrate ferments in the colon.",
  "ABDOMINAL PAIN AND CRAMPS, NAUSEA AND VOMITING: part of the same small-bowel dysfunction.",
  "WEIGHT LOSS in chronic cases comes from the same malabsorption.",
  "Fever is usually absent or mild, because there is no invasive inflammation.",
  "So the giardia formula is: watery + fatty + gassy + no blood + no fever.",
  "If you see BLOODY diarrhoea, think amoeba, shigella, campylobacter or salmonella — not giardia.",
 ],
 "همه‌ی علائمی که در صورت سؤال آمده — درد شکم، نفخ، آروغ، تهوع و استفراغ — با ژیاردیازیس کاملاً سازگارند. تنها استثنا **اسهال خونی** است، و دلیلش یک جمله است: **ژیاردیا تهاجم نمی‌کند**.\n\nژیاردیا در **دئودنوم و ژژونوم** به سطح مخاط می‌چسبد و همان‌جا می‌ماند. چون وارد دیواره نمی‌شود، نه زخم می‌سازد نه خونریزی. کاری که می‌کند این است که **پرزهای روده را کند و صاف** می‌کند و **سوءجذب** ایجاد می‌کند — و کل تابلوی بیماری از همین سوءجذب بیرون می‌آید:\n\n• **اسهال آبکی و بدبو** از سوءجذب عمومی\n• **استئاتوره** از جذب‌نشدن چربی\n• **نفخ، گاز و آروغ گوگردی** از تخمیر کربوهیدرات جذب‌نشده در کولون\n• **کاهش وزن** در موارد مزمن\n\n⚠️ قاعده‌ی عملی: اسهال خونی ← آمیب، شیگلا، کامپیلوباکتر، سالمونلا. اسهال آبکی چرب و پرنفخ بدون خون ← ژیاردیا.",
 "Every symptom in the stem — abdominal pain, bloating, belching, nausea and vomiting — fits giardiasis perfectly. The single exception is BLOODY DIARRHOEA, and the reason is one sentence: GIARDIA DOES NOT INVADE.\n\nGiardia attaches to the mucosal surface of the DUODENUM AND JEJUNUM and stays there. Because it never enters the wall, it makes no ulcers and causes no bleeding. What it does instead is BLUNT AND FLATTEN THE VILLI and produce MALABSORPTION — and the whole clinical picture follows from that:\n\n- WATERY, FOUL-SMELLING DIARRHOEA from general malabsorption\n- STEATORRHOEA from unabsorbed fat\n- BLOATING, GAS AND SULPHUROUS BELCHING from unabsorbed carbohydrate fermenting in the colon\n- WEIGHT LOSS in chronic cases\n\nWARNING, the practical rule: bloody diarrhoea -> amoeba, shigella, campylobacter, salmonella. Watery, fatty, gassy diarrhoea without blood -> giardia.",
 ["پاسخ صحیح — ژیاردیا تهاجم نمی‌کند، پس اسهال خونی نمی‌دهد؛ این تنها مورد ناسازگار است.",
  "درد شکم و کرامپ از تظاهرات شایع ژیاردیازیس است.",
  "تهوع و استفراغ بخشی از اختلال عملکرد روده‌ی باریک در ژیاردیا است.",
  "نفخ از تخمیر کربوهیدرات جذب‌نشده می‌آید و بسیار مشخصه‌ی ژیاردیا است."],
 ["Correct — Giardia does not invade, so it does not cause bloody diarrhoea; this is the one incompatible feature.",
  "Abdominal pain and cramping are common manifestations of giardiasis.",
  "Nausea and vomiting are part of the small-bowel dysfunction Giardia causes.",
  "Bloating comes from unabsorbed carbohydrate fermenting and is highly characteristic of giardia."],
 "ژیاردیا = **تهاجم نمی‌کند** ← آبکی، چرب، پرنفخ، **بدون خون**. خون دیدید؟ ژیاردیا نیست.",
 "Giardia does NOT invade -> watery, fatty, gassy, NO BLOOD. See blood? It is not giardia.",
 [H223, MSD])


# ---------------------------------------------------------------- idx 741
add("book:741", "case", "medium",
 "ژیاردیای **مکرر و مقاوم** ← دنبال **هیپوگاماگلوبولینمی** بگرد؛ دفاع روده IgA ترشحی است.",
 "RECURRENT, refractory giardiasis should prompt a search for HYPOGAMMAGLOBULINAEMIA: the gut's defence is secretory IgA.",
 [
  "ژیاردیای مزمن، مکرر و مقاوم به درمان یک **پرچم قرمز ایمونولوژیک** است.",
  "برای فهمیدنش باید بپرسیم: بدن اصلاً **چطور** ژیاردیا را پاک می‌کند؟",
  "ژیاردیا **داخل سلول نمی‌رود** و به بافت **تهاجم نمی‌کند**؛ روی سطح مخاط می‌نشیند.",
  "پس ایمنی سلولی (لنفوسیت T و ماکروفاژ) نقش اصلی را ندارد — چیزی داخل سلول نیست که کشته شود.",
  "⚠️ دفاع اصلی، **IgA ترشحی** است که در مخاط روده ریخته می‌شود.",
  "IgA ترشحی مانع چسبیدن تروفوزوئیت به مخاط می‌شود و آن را از بدن بیرون می‌راند.",
  "پس هر نقصی که **تولید آنتی‌بادی** را مختل کند، بیمار را در برابر ژیاردیا بی‌دفاع می‌گذارد.",
  "نتیجه: در ژیاردیای مکرر باید **هیپوگاماگلوبولینمی** را بررسی کرد.",
  "شایع‌ترین علت در بزرگسالان: **CVID** (نقص ایمنی متغیر شایع).",
  "در واقع ژیاردیازیس مقاوم گاهی **اولین تظاهر** CVID است و به تشخیص آن می‌انجامد.",
  "**کمبود انتخابی IgA** هم همین آسیب‌پذیری را ایجاد می‌کند.",
  "برای همین در این بیماران باید سطح **IgG، IgA و IgM** اندازه‌گیری شود.",
  "چرا HIV پاسخ نیست؟ چون HIV ایمنی **سلولی** را می‌زند، نه تولید آنتی‌بادی مخاطی را.",
  "در HIV انگل‌های داخل‌سلولی مثل **کریپتوسپوریدیوم، میکروسپوریدیا و ایزوسپورا** مشکل‌سازند.",
  "کمبود کمپلمان هم ربطی ندارد: کمپلمان بیشتر با **نایسریا** و باکتری‌های کپسول‌دار درگیر است.",
 ],
 [
  "Chronic, recurrent, treatment-refractory giardiasis is an IMMUNOLOGICAL RED FLAG.",
  "To understand it, ask: how does the body clear Giardia in the first place?",
  "Giardia does NOT enter cells and does NOT invade tissue; it sits on the mucosal surface.",
  "So cellular immunity (T cells and macrophages) is not the main player — there is nothing intracellular to kill.",
  "WARNING: the principal defence is SECRETORY IgA, poured onto the gut mucosa.",
  "Secretory IgA blocks the trophozoite from attaching to the mucosa and sweeps it out of the body.",
  "So any defect in ANTIBODY PRODUCTION leaves the patient defenceless against Giardia.",
  "The conclusion: recurrent giardiasis calls for a search for HYPOGAMMAGLOBULINAEMIA.",
  "The commonest cause in adults is CVID (common variable immunodeficiency).",
  "Indeed refractory giardiasis is sometimes the FIRST PRESENTATION of CVID and leads to its diagnosis.",
  "SELECTIVE IgA DEFICIENCY produces the same vulnerability.",
  "That is why these patients should have IgG, IgA and IgM levels measured.",
  "Why is HIV not the answer? Because HIV attacks CELLULAR immunity, not mucosal antibody production.",
  "In HIV the troublesome parasites are the intracellular ones: CRYPTOSPORIDIUM, MICROSPORIDIA and ISOSPORA.",
  "Complement deficiency is also irrelevant: complement mainly matters for NEISSERIA and encapsulated bacteria.",
 ],
 "ژیاردیای **مزمن، مکرر و مقاوم به درمان** یک پرچم قرمز ایمونولوژیک است، و برای فهمیدن پاسخ باید بپرسیم بدن اصلاً چطور ژیاردیا را پاک می‌کند.\n\nژیاردیا **داخل سلول نمی‌رود و به بافت تهاجم نمی‌کند** — روی سطح مخاط می‌نشیند. بنابراین ایمنی سلولی نقش اصلی را ندارد؛ **دفاع اصلی، IgA ترشحی** است که از چسبیدن تروفوزوئیت به مخاط جلوگیری می‌کند و آن را بیرون می‌راند.\n\nنتیجه مستقیم است: هر نقصی که **تولید آنتی‌بادی** را مختل کند، بیمار را در برابر ژیاردیا بی‌دفاع می‌گذارد. پس در ژیاردیای مکرر باید سراغ **هیپوگاماگلوبولینمی** رفت — و شایع‌ترین علت در بزرگسالان **CVID** است. ژیاردیازیس مقاوم گاهی نخستین تظاهر CVID است.\n\n⚠️ چرا HIV پاسخ نیست؟ چون HIV ایمنی **سلولی** را تخریب می‌کند. انگل‌های مشکل‌ساز در HIV، انگل‌های **داخل‌سلولی** مثل کریپتوسپوریدیوم و میکروسپوریدیا هستند، نه ژیاردیا.",
 "CHRONIC, RECURRENT, TREATMENT-REFRACTORY giardiasis is an immunological red flag, and to find the answer you must ask how the body clears Giardia at all.\n\nGiardia does NOT enter cells and does NOT invade tissue — it sits on the mucosal surface. Cellular immunity is therefore not the main player; the PRINCIPAL DEFENCE IS SECRETORY IgA, which stops the trophozoite attaching and sweeps it out.\n\nThe conclusion follows directly: any defect in ANTIBODY PRODUCTION leaves the patient defenceless against Giardia. So recurrent giardiasis calls for a search for HYPOGAMMAGLOBULINAEMIA — and the commonest cause in adults is CVID. Refractory giardiasis is sometimes the first presentation of CVID.\n\nWARNING: why is HIV not the answer? Because HIV destroys CELLULAR immunity. The problem parasites in HIV are the INTRACELLULAR ones — cryptosporidium and microsporidia — not Giardia.",
 ["پاسخ صحیح — دفاع روده در برابر ژیاردیا IgA ترشحی است، پس نقص تولید آنتی‌بادی را بررسی کنید.",
  "سونوگرافی کبد ربطی به ژیاردیا ندارد؛ ژیاردیا کبد را درگیر نمی‌کند.",
  "کمبود کمپلمان بیشتر با عفونت نایسریا و باکتری‌های کپسول‌دار همراه است، نه ژیاردیا.",
  "HIV ایمنی سلولی را می‌زند؛ انگل‌های مشکل‌ساز در آن کریپتوسپوریدیوم و میکروسپوریدیا هستند."],
 ["Correct — the gut's defence against Giardia is secretory IgA, so look for an antibody-production defect.",
  "Liver ultrasound is irrelevant; Giardia does not involve the liver.",
  "Complement deficiency is associated with Neisseria and encapsulated bacteria, not Giardia.",
  "HIV attacks cellular immunity; its problem parasites are cryptosporidium and microsporidia."],
 "ژیاردیای **مکرر** ← IgA ترشحی کم است ← **هیپوگاماگلوبولینمی / CVID** را بررسی کن.",
 "RECURRENT giardiasis -> deficient secretory IgA -> screen for HYPOGAMMAGLOBULINAEMIA / CVID.",
 [H223, MSD])


# ---------------------------------------------------------------- idx 750
add("book:750", "case", "medium",
 "توکسوپلاسموز حاد در فرد **غیرحامله و ایمنی‌سالم** = **درمان لازم ندارد**؛ خودمحدودشونده است.",
 "Acute toxoplasmosis in an IMMUNOCOMPETENT, NON-PREGNANT adult needs NO TREATMENT: it is self-limiting.",
 [
  "این قاعده در کل فصل توکسوپلاسموز بارها آزموده می‌شود، پس یک‌بار خوب یاد بگیرید.",
  "بیش از **۸۰ تا ۹۰ درصد** عفونت‌های حاد توکسوپلاسما در فرد سالم **کاملاً بی‌علامت‌اند**.",
  "وقتی هم علامت بدهند، شایع‌ترین تابلو **لنفادنوپاتی گردنی** است.",
  "غدد معمولاً **غیردردناک یا کم‌درد، مجزا، متحرک** و بدون چرک‌شدن‌اند.",
  "گاهی تب خفیف، خستگی، گلودرد و بدن‌درد هم دارد — شبیه یک بیماری ویروسی خفیف.",
  "⚠️ نکته‌ی محوری: در میزبان **ایمنی‌سالم** این بیماری **خودمحدودشونده** است.",
  "علائم ظرف چند هفته تا چند ماه خودبه‌خود فروکش می‌کنند؛ لنفادنوپاتی ممکن است ماه‌ها بماند.",
  "پس درمان ضدانگلی **لازم نیست** و فقط عوارض دارویی اضافه می‌کند.",
  "پریمتامین سرکوب مغز استخوان می‌دهد؛ سولفادیازین سنگ کلیه، بثورات و واکنش شدید پوستی.",
  "**سه استثنای درمان** را حفظ کنید — فقط در این سه حالت درمان می‌دهیم.",
  "استثنای یک: **نقص ایمنی** (مثل انسفالیت توکسوپلاسمایی در ایدز).",
  "استثنای دو: **درگیری چشمی** (کوریورتینیت)، چون بینایی در خطر است.",
  "استثنای سه: **بارداری و توکسوپلاسموز مادرزادی**، برای محافظت از جنین.",
  "استثنای فرعی چهارم: علائم شدید و طول‌کشیده یا درگیری ارگان حیاتی.",
  "چون این خانم **جوان، غیرحامله و ایمنی‌سالم** است، هیچ‌کدام از استثناها صدق نمی‌کند.",
 ],
 [
  "This rule is examined again and again in the toxoplasmosis block, so learn it properly once.",
  "More than 80-90% of acute Toxoplasma infections in a healthy person are COMPLETELY ASYMPTOMATIC.",
  "When it does cause symptoms, the commonest picture is CERVICAL LYMPHADENOPATHY.",
  "The nodes are typically NON-TENDER or only mildly tender, DISCRETE and MOBILE, and do not suppurate.",
  "There may be low-grade fever, fatigue, sore throat and myalgia — like a mild viral illness.",
  "WARNING, the central point: in an IMMUNOCOMPETENT host this illness is SELF-LIMITING.",
  "Symptoms settle spontaneously over weeks to months; the lymphadenopathy may persist for months.",
  "So antiparasitic treatment is NOT NEEDED and would only add drug toxicity.",
  "Pyrimethamine causes bone-marrow suppression; sulfadiazine causes renal stones, rash and severe skin reactions.",
  "Memorise the THREE EXCEPTIONS — treatment is given only in these three situations.",
  "Exception one: IMMUNODEFICIENCY (for example toxoplasmic encephalitis in AIDS).",
  "Exception two: OCULAR involvement (chorioretinitis), because sight is at risk.",
  "Exception three: PREGNANCY and CONGENITAL toxoplasmosis, to protect the fetus.",
  "A minor fourth: severe, prolonged symptoms or involvement of a vital organ.",
  "Because this woman is YOUNG, NOT PREGNANT and IMMUNOCOMPETENT, none of the exceptions applies.",
 ],
 "این سؤال یکی از پرتکرارترین قواعد فصل توکسوپلاسموز را می‌پرسد: **توکسوپلاسموز حاد در فرد ایمنی‌سالم و غیرحامله، درمان نمی‌خواهد**.\n\nبیش از ۸۰ تا ۹۰ درصد عفونت‌های حاد توکسوپلاسما در فرد سالم کاملاً **بی‌علامت‌اند**. وقتی علامت بدهند، تابلوی شایع **لنفادنوپاتی گردنی** با غدد غیردردناک، مجزا و متحرک است، گاهی همراه تب خفیف و خستگی. این تصویر در میزبان سالم **خودمحدودشونده** است و ظرف هفته‌ها تا ماه‌ها خودبه‌خود فروکش می‌کند.\n\nدرمان دادن در این حالت نه‌تنها سودی ندارد، بلکه **زیان‌بار** است: پریمتامین مغز استخوان را سرکوب می‌کند و سولفادیازین سنگ کلیه و واکنش‌های شدید پوستی می‌دهد.\n\n⚠️ **سه استثنا** که حتماً باید حفظ شوند — فقط در این‌ها درمان می‌دهیم:\n• **نقص ایمنی** (مثل انسفالیت توکسوپلاسمایی در ایدز)\n• **درگیری چشمی** (کوریورتینیت)\n• **بارداری و توکسوپلاسموز مادرزادی**\n\nاین بیمار در هیچ‌کدام از سه گروه نیست، پس پاسخ «نیازی به درمان دارویی ندارد» است.",
 "This question asks one of the most frequently repeated rules of the toxoplasmosis block: ACUTE TOXOPLASMOSIS IN AN IMMUNOCOMPETENT, NON-PREGNANT PERSON NEEDS NO TREATMENT.\n\nMore than 80-90% of acute Toxoplasma infections in a healthy person are completely ASYMPTOMATIC. When symptoms occur, the usual picture is CERVICAL LYMPHADENOPATHY with non-tender, discrete, mobile nodes, sometimes with low-grade fever and fatigue. In an immunocompetent host this is SELF-LIMITING and settles spontaneously over weeks to months.\n\nTreating it is not merely useless but HARMFUL: pyrimethamine suppresses the bone marrow, and sulfadiazine causes renal stones and severe skin reactions.\n\nWARNING, the THREE EXCEPTIONS that must be memorised — only these get treatment:\n- IMMUNODEFICIENCY (for example toxoplasmic encephalitis in AIDS)\n- OCULAR involvement (chorioretinitis)\n- PREGNANCY and congenital toxoplasmosis\n\nThis patient falls into none of the three, so the answer is that no drug treatment is required.",
 ["کوتریموکسازول برای توکسوپلاسموز پیشگیرانه در ایدز جایی دارد، نه در فرد سالم علامت‌دار.",
  "پریمتامین + سولفادیازین درمان بیماری شدید یا میزبان با نقص ایمنی است، نه فرد سالم.",
  "پنتامیدین اصلاً داروی توکسوپلاسما نیست؛ برای پنوموسیستیس و تریپانوزومیازیس به کار می‌رود.",
  "پاسخ صحیح — در فرد ایمنی‌سالم و غیرحامله بیماری خودمحدودشونده است و درمان لازم ندارد."],
 ["Co-trimoxazole has a place in toxoplasmosis prophylaxis in AIDS, not in a symptomatic healthy adult.",
  "Pyrimethamine plus sulfadiazine treats severe disease or an immunocompromised host, not a healthy one.",
  "Pentamidine is not a Toxoplasma drug at all; it is used for pneumocystis and trypanosomiasis.",
  "Correct — in an immunocompetent, non-pregnant person the illness is self-limiting and needs no treatment."],
 "توکسو در فرد **سالم و غیرحامله** = **بدون درمان**. درمان فقط در: نقص ایمنی، چشم، بارداری.",
 "Toxoplasmosis in a HEALTHY, NON-PREGNANT adult = NO treatment. Treat only for: immunodeficiency, eye, pregnancy.",
 [H226, MSD])


# ---------------------------------------------------------------- idx 746
add("book:746", "recall", "medium",
 "**پارادوکس تریمستر**: هرچه بارداری پیش‌تر برود، **انتقال بیشتر** ولی **شدت کمتر**.",
 "The TRIMESTER PARADOX: the later in pregnancy, the HIGHER the transmission but the MILDER the disease.",
 [
  "این یکی از زیباترین و پرآزمون‌ترین قواعد کل عفونی است، و منطق روشنی دارد.",
  "عفونت مادرزادی توکسوپلاسما فقط وقتی رخ می‌دهد که مادر **در حین بارداری** تازه مبتلا شود.",
  "اگر مادر **پیش از بارداری** مبتلا شده باشد، ایمن است و جنین در خطر نیست (مگر نقص ایمنی).",
  "⚠️ حالا قاعده‌ی محوری: **میزان انتقال** و **شدت بیماری** در جهت‌های **مخالف** حرکت می‌کنند.",
  "**سه‌ماهه‌ی اول**: احتمال انتقال حدود **۱۰ تا ۱۵ درصد** — کمترین.",
  "**سه‌ماهه‌ی دوم**: احتمال انتقال حدود **۲۵ تا ۳۰ درصد**.",
  "**سه‌ماهه‌ی سوم**: احتمال انتقال حدود **۶۰ تا ۷۰ درصد** — بیشترین. پاسخ همین است.",
  "چرا انتقال بالا می‌رود؟ چون **جفت هرچه بزرگ‌تر و پرخون‌تر** شود، عبور انگل آسان‌تر است.",
  "اما **شدت** دقیقاً برعکس است: عفونت سه‌ماهه‌ی اول **ویرانگرترین** است.",
  "عفونت زودرس می‌تواند سقط، مرگ داخل رحمی، هیدروسفالی، کلسیفیکاسیون مغزی و کوریورتینیت بدهد.",
  "چرا؟ چون در آن مرحله **اندام‌ها در حال ساخته شدن‌اند** و آسیب به بافت در حال تکوین می‌رسد.",
  "عفونت سه‌ماهه‌ی سوم معمولاً نوزادی **ظاهراً سالم** می‌سازد.",
  "⚠️ ولی «ظاهراً سالم» یعنی خطر پنهان: تا **۸۵ درصد** این نوزادان اگر درمان نشوند، سال‌ها بعد **کوریورتینیت** می‌گیرند.",
  "برای همین نوزاد آلوده حتی اگر بی‌علامت باشد، **یک سال درمان** می‌شود.",
  "جمع‌بندی: انتقال ↑ با پیشرفت بارداری، شدت ↓ با پیشرفت بارداری.",
 ],
 [
  "This is one of the most elegant and most examined rules in infectious disease, and its logic is clear.",
  "Congenital toxoplasmosis occurs only when the mother acquires the infection DURING the pregnancy.",
  "If she was infected BEFORE conception she is immune and the fetus is not at risk (unless she is immunosuppressed).",
  "WARNING, the central rule: TRANSMISSION RATE and DISEASE SEVERITY move in OPPOSITE directions.",
  "FIRST TRIMESTER: transmission around 10-15% — the lowest.",
  "SECOND TRIMESTER: transmission around 25-30%.",
  "THIRD TRIMESTER: transmission around 60-70% — the highest. That is the answer.",
  "Why does transmission rise? Because the LARGER AND MORE VASCULAR the placenta, the easier the parasite crosses.",
  "But SEVERITY is exactly the reverse: first-trimester infection is the most DEVASTATING.",
  "Early infection can cause miscarriage, intrauterine death, hydrocephalus, intracranial calcification and chorioretinitis.",
  "Why? Because at that stage the ORGANS ARE STILL FORMING, so the damage lands on developing tissue.",
  "Third-trimester infection usually produces a baby who APPEARS NORMAL at birth.",
  "WARNING: 'appears normal' hides a real risk — up to 85% of these babies, if untreated, develop CHORIORETINITIS years later.",
  "That is why an infected newborn is treated for A FULL YEAR even when asymptomatic.",
  "In summary: transmission rises as pregnancy advances, severity falls as pregnancy advances.",
 ],
 "این سؤال یکی از قواعد کلاسیک و پرتکرار عفونی را می‌پرسد و منطقش را باید فهمید، نه حفظ کرد.\n\n**انتقال توکسوپلاسما از مادر به جنین با پیشرفت بارداری بیشتر می‌شود** — و پاسخ **سه‌ماهه‌ی سوم** است:\n\n• سه‌ماهه‌ی اول: احتمال انتقال **۱۰ تا ۱۵ درصد**\n• سه‌ماهه‌ی دوم: احتمال انتقال **۲۵ تا ۳۰ درصد**\n• سه‌ماهه‌ی سوم: احتمال انتقال **۶۰ تا ۷۰ درصد** ← بیشترین\n\nدلیلش ساده است: هرچه **جفت بزرگ‌تر و پرخون‌تر** شود، عبور انگل از آن آسان‌تر است.\n\n⚠️ اما نکته‌ای که همین‌جا باید یاد گرفت، **پارادوکس تریمستر** است: **شدت بیماری دقیقاً برعکس حرکت می‌کند**. عفونت **سه‌ماهه‌ی اول** نادر است ولی **ویرانگر** — سقط، هیدروسفالی، کلسیفیکاسیون داخل مغزی، کوریورتینیت. عفونت **سه‌ماهه‌ی سوم** شایع است ولی معمولاً نوزادی **ظاهراً سالم** می‌سازد.\n\nو یک هشدار پایانی: «ظاهراً سالم» به معنای بی‌خطر نیست. تا **۸۵ درصد** این نوزادان اگر درمان نشوند، سال‌ها بعد دچار **کوریورتینیت** می‌شوند — به همین دلیل نوزاد آلوده حتی بدون علامت، یک سال کامل درمان می‌شود.",
 "This question asks a classic, much-repeated rule, and the logic is worth understanding rather than memorising.\n\nTRANSMISSION OF TOXOPLASMA FROM MOTHER TO FETUS RISES AS PREGNANCY ADVANCES — and the answer is the THIRD TRIMESTER:\n\n- First trimester: transmission 10-15%\n- Second trimester: transmission 25-30%\n- THIRD trimester: transmission 60-70% (the highest)\n\nThe reason is simple: the LARGER AND MORE VASCULAR the placenta becomes, the more easily the parasite crosses it.\n\nWARNING, and this is what must really be learned here — the TRIMESTER PARADOX: SEVERITY MOVES EXACTLY THE OTHER WAY. FIRST-trimester infection is rare but DEVASTATING — miscarriage, hydrocephalus, intracranial calcification, chorioretinitis. THIRD-trimester infection is common but usually produces a baby who APPEARS NORMAL.\n\nAnd a closing warning: 'appears normal' does not mean safe. Up to 85% of these babies, if untreated, develop CHORIORETINITIS years later — which is why an infected newborn is treated for a full year even when asymptomatic.",
 ["سه‌ماهه‌ی اول کمترین انتقال (۱۰–۱۵٪) را دارد، هرچند شدیدترین آسیب را می‌سازد.",
  "سه‌ماهه‌ی دوم حد وسط است (۲۵–۳۰٪)، نه بیشترین.",
  "پاسخ صحیح — سه‌ماهه‌ی سوم بیشترین انتقال (۶۰–۷۰٪) را دارد، چون جفت بزرگ‌تر و پرخون‌تر است.",
  "انتقال حین زایمان سازوکار اصلی توکسوپلاسما نیست؛ انتقال از راه جفت است."],
 ["The first trimester has the lowest transmission (10-15%), though it causes the most severe damage.",
  "The second trimester is intermediate (25-30%), not the highest.",
  "Correct — the third trimester has the highest transmission (60-70%), because the placenta is larger and more vascular.",
  "Intrapartum transmission is not the mechanism for Toxoplasma; spread is transplacental."],
 "انتقال: اول ۱۰–۱۵٪ → سوم ۶۰–۷۰٪. **شدت برعکس**: اول ویرانگر، سوم ظاهراً سالم.",
 "Transmission: 1st 10-15% -> 3rd 60-70%. SEVERITY IS THE REVERSE: 1st devastating, 3rd apparently normal.",
 [H226, MSD])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book11.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 11 lessons:', len(L))
