# -*- coding: utf-8 -*-
"""English stems and options for the batch-28 and batch-29 questions (endocarditis).

Rule 16 checked first, as always: these items come from sittings 93 to 98, for
which the ministry published no English booklet, so these are hand-written
translations rather than official ones.

Translation decisions worth recording
-------------------------------------
This chapter COUNTS, so every number that feeds a Duke tally must survive into
the English. Three questions were repaired numerically before these
translations were written (see fix_endocarditis_numbers.py) and the English
quotes the REPAIRED values:

  q9101 (idx 101): blood pressure stored as '80/021'; page 39 prints 120/80.
        The English says 120/80. It matters clinically as well as
        arithmetically: a NORMAL blood pressure alongside a pulse of 120 and a
        temperature of 39 is the subacute endocarditis picture, whereas a
        hypotensive patient would read as septic shock.

  q9113 (idx 113): the two temperatures. Patient B was stored as '8/83' and
        patient C as '93'; page 44 prints 38.8 and 39. This is a Duke-counting
        question and FEVER SCORES ONLY AT 38 °C OR ABOVE, so with the corrupt
        value patient B would be one minor criterion short and the question
        would have had no correct answer at all. The English carries 38.8 and
        39 exactly.

  q9128 (idx 128): the three doses, stored with the unit fused onto a mirrored
        number ('mg052', 'mg006', 'mg005'); page 50 prints 250, 600 and 500.
        The doses are the whole point of that question — the correct option is
        correct partly BECAUSE clarithromycin 500 mg one hour before is the
        real regimen — so all three are carried into the English.

Two further notes:

  q9109 (idx 109) and q9110 (idx 110) are counting questions whose OPTIONS are
  the tallies themselves. The English options preserve the exact counts,
  including the distinction between '3 minor' and '1 major and 3 minor', since
  choosing between them is the entire task.

  q9106 (idx 106) is not in this batch — it already has a lesson from an
  earlier batch, and this file adds English only for questions taught in
  batches 28 and 29.
"""

EN13 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    assert all(o.strip() for o in options), idx
    EN13[idx] = {"stem_en": stem, "options_en": options}


# ============================== recognition and Duke criteria (batch 28)
add(97,
    "A 26-year-old man who injects drugs presents with fevers to 39.5 °C, a cardiac murmur, "
    "splinter haemorrhages under the nails, and multiple microabscesses in the brain and "
    "meninges. Which pathogen is most likely?",
    ["Staphylococcus epidermidis",
     "Staphylococcus aureus",
     "Enterococcus faecalis",
     "Pseudomonas aeruginosa"])

add(98,
    "A 25-year-old is brought to the emergency department with weight loss and fever for the "
    "past two weeks. On examination the temperature is 38 °C, there is a grade III/VI systolic "
    "murmur at the mitral area, an enlarged spleen, and ecchymotic rashes on the legs. Three "
    "sets of blood cultures are taken. The patient has received no prior antibiotics. After 72 "
    "hours the blood cultures are reported negative. Which organism is most likely?",
    ["Staphylococcus aureus",
     "Streptococcus viridans",
     "Enterococcus",
     "Cardiobacterium hominis"])

add(99,
    "In 5% to 15% of cases of endocarditis the blood cultures are negative, and one cause may "
    "be the HACEK group of microorganisms. Which of the following is NOT part of the HACEK "
    "group?",
    ["Coxiella burnetii",
     "Haemophilus species",
     "Cardiobacterium species",
     "Kingella species"])

add(100,
    "A 60-year-old man presents after two weeks of fever, fatigue, weakness and malaise. "
    "Cardiac examination shows a grade III/IV systolic murmur at the mitral area. His "
    "observations are SBP 130/80, RR 22, HR 110 and an oral temperature of 38 °C. Blood "
    "cultures on two occasions have grown Streptococcus bovis (Streptococcus gallolyticus), "
    "and transoesophageal echocardiography shows a mobile 7 mm vegetation on the anterior "
    "leaflet of the mitral valve. Which investigation is necessary for this patient?",
    ["Intravenous pyelography (IVP)",
     "Non-contrast CT of the abdomen and pelvis",
     "Colonoscopy",
     "CT scan of the brain"])

add(109,
    "A young man who injects drugs presents with fever, weakness, anorexia and weight loss of "
    "about three months' duration. Heart sounds are normal, and echocardiography shows a mobile "
    "vegetation measuring 1 x 1.5 cm on the tricuspid valve. Pseudomonas aeruginosa has grown "
    "in four blood cultures. With suspected infective endocarditis, how many major and how many "
    "minor criteria are present, respectively?",
    ["Two major, 2 minor",
     "Two major, one minor",
     "One major, 3 minor",
     "Three major, 2 minor"])

add(110,
    "A 65-year-old man presents with a history of fever for 10 days. Ten years ago he underwent "
    "aortic valve replacement and has a prosthetic valve. On examination he is mildly "
    "tachycardic. He has conjunctival petechiae but no cutaneous petechiae. There are several "
    "lesions on the soles suspicious for Janeway lesions. How many Duke criteria does he have "
    "for possible infective endocarditis?",
    ["3 minor",
     "1 major and 3 minor",
     "4 minor",
     "1 major and 2 minor"])

add(113,
    "For which of the following patients is a diagnosis of infective endocarditis established "
    "according to the Duke criteria?",
    ["A 26-year-old man who injects drugs, with a temperature of 39 °C, blood cultures positive "
     "for Pseudomonas aeruginosa, and red cells in the urine",
     "A 34-year-old woman with rheumatic heart disease, a temperature of 38.8 °C, a vegetation "
     "on echocardiography, and bilateral involvement on the chest radiograph",
     "A 67-year-old man with a history of myocardial infarction and a temperature of 39 °C, a "
     "reduced level of consciousness, and intracerebral haemorrhage on CT",
     "A 56-year-old woman with a temperature of 38.5 °C, blood cultures positive for "
     "Streptococcus viridans, and a positive rheumatoid factor"])


# ==================== treatment, monitoring and prophylaxis (batch 29)
add(119,
    "Four days after admission of a patient with suspected endocarditis, the blood cultures are "
    "reported as growing Staphylococcus aureus. On examination the patient is well and there "
    "are no complications. What duration of drug treatment do you recommend?",
    ["6 to 8 weeks",
     "2 to 4 weeks",
     "4 to 6 weeks",
     "8 to 12 weeks"])

add(120,
    "A 56-year-old man who underwent mitral valve replacement 10 years ago presents with fever "
    "and rigors over the past week. On examination the blood pressure is 100/75 mmHg, the heart "
    "rate 102 beats per minute, the respiratory rate 22 per minute and the temperature 38.7 °C, "
    "and a cardiac murmur is heard at the mitral area. Echocardiography reports a vegetation on "
    "the prosthetic valve. Blood cultures grow methicillin-resistant Staphylococcus aureus. "
    "Which of the following treatments is most appropriate for this patient?",
    ["Oxacillin plus gentamicin plus rifampicin",
     "Vancomycin plus gentamicin",
     "Oxacillin",
     "Vancomycin plus gentamicin plus rifampicin"])

add(121,
    "A 30-year-old man who is an injecting drug user (IDU) presents with fever, tachycardia and "
    "breathlessness for the past 5 days. On examination T = 38.5 oral, HR = 110, RR = 25. CT of "
    "the chest shows evidence of bilateral emboli, and echocardiography reports tricuspid valve "
    "regurgitation. What is the most likely causative microorganism and your recommended "
    "treatment?",
    ["Staphylococcus aureus; vancomycin together with gentamicin",
     "Enterococcus faecalis; ampicillin",
     "Staphylococcus epidermidis; vancomycin",
     "Staphylococcus aureus; vancomycin"])

add(122,
    "A 24-year-old man presents with 10 days of fever and rigors together with weakness and "
    "malaise. He reports a previous valvular problem in his history. On examination the "
    "temperature is 39 °C, HR = 120/min and RR = 25/min. A grade 2/6 cardiac murmur is heard at "
    "the mitral area. He complains of painful lesions on the palms and soles. Echocardiography "
    "shows a 1 cm vegetation on the anterior mitral leaflet. Which of the following is your most "
    "appropriate recommended treatment?",
    ["Piperacillin/tazobactam plus linezolid",
     "Ceftriaxone plus vancomycin",
     "Ciprofloxacin plus teicoplanin",
     "Ampicillin plus gentamicin"])

add(123,
    "A 45-year-old woman is being investigated for fever. Transthoracic echocardiography shows a "
    "0.5 cm vegetation on the mitral valve, and her blood cultures on two occasions are reported "
    "as Staphylococcus aureus. An appropriate antibiotic is started according to sensitivities. "
    "Which option is most appropriate for monitoring the response to treatment?",
    ["Sending blood cultures daily until they become negative",
     "Sending blood cultures weekly until the end of treatment",
     "Performing transoesophageal echocardiography 72 hours later",
     "Performing transthoracic echocardiography 48 hours later"])

add(124,
    "A 20-year-old patient has a history of congenital heart disease which was completely "
    "repaired surgically in childhood. He is now a candidate for dental surgery. Regarding the "
    "prevention of endocarditis, which of the following is correct?",
    ["No prophylaxis is required",
     "Ampicillin 2 g by injection",
     "Amoxicillin 2 g orally",
     "Clindamycin 600 mg orally"])

add(126,
    "A 50-year-old woman has a history of cardiac surgery for coronary artery disease. She is a "
    "candidate for gum surgery. She has a history of an anaphylactoid shock reaction following "
    "an injection of penicillin. Which drug do you recommend for endocarditis prophylaxis?",
    ["Amoxicillin 2 g given 1 hour before surgery",
     "Clindamycin 600 mg given 1 hour before surgery",
     "Azithromycin 500 mg given 1 hour before surgery",
     "The patient does not require endocarditis prophylaxis"])

add(127,
    "A 42-year-old man who underwent mitral valve replacement 2 years ago is a candidate for a "
    "dental implant. You are asked about the need for antibiotic prophylaxis before the dental "
    "procedure. Which option do you consider appropriate?",
    ["Amoxicillin orally one hour before the procedure",
     "Cefazolin by injection 2 hours before the procedure",
     "Ciprofloxacin orally 0.5 hours before the procedure",
     "No prophylaxis is required"])

add(128,
    "A 35-year-old woman with a history of infective endocarditis 2 years ago, treated "
    "appropriately and having undergone valve replacement surgery, is referred for prophylaxis "
    "before gum surgery. Her drug history includes anaphylactic allergy to penicillin. Which is "
    "the best antibiotic regimen for prophylaxis against endocarditis?",
    ["Azithromycin 250 mg orally one hour before gum surgery",
     "Cephalexin 2 g orally 30 minutes before gum surgery",
     "Clindamycin 600 mg intravenously at the start of gum surgery",
     "Clarithromycin 500 mg orally one hour before gum surgery"])

add(132,
    "A 25-year-old man is a candidate for endoscopy and biopsy of an oesophageal mass. He has "
    "rheumatic valvular heart disease and for that reason underwent insertion of a prosthetic "
    "mitral valve 2 years ago. About 6 months ago he developed an itchy skin rash after taking "
    "amoxicillin. Which drug would you NOT recommend for infective endocarditis prophylaxis "
    "before the endoscopy?",
    ["Azithromycin 500 mg 1 hour before the procedure",
     "Clindamycin 600 mg 1 hour before the procedure",
     "Doxycycline 200 mg 1 hour before the procedure",
     "Ceftriaxone 1 g intramuscularly 30 minutes before the procedure"])
