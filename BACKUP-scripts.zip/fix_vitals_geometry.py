# -*- coding: utf-8 -*-
"""Repair mirrored vital signs in the book payload, using glyph geometry.

The problem
-----------
The age fix corrected patient ages, and the number guard in apply_en.py
protects anything that gets translated. But a third class of number was never
systematically checked: the VITAL SIGNS inside the vignette body. A sweep of
the whole book found values that are physiologically impossible:

    "درجه حرارت زیربغلی ̊C83"      an axillary temperature of 83 degrees
    "فشار خون mmHg 05/07"          a blood pressure of 5 over 7
    "نبض 401"                       a pulse of 401
    "تعداد تنفس min82"              a respiratory rate of 82
    "تب 340 درجه"                   a fever of 340

These matter more than most numbers in this bank, because a whole block of
sepsis questions asks the student to CLASSIFY the patient — SIRS, sepsis,
severe sepsis or septic shock — and that classification is computed directly
from the respiratory rate, the pulse and the blood pressure. A mirrored digit
does not merely look odd; it changes the correct answer.

Why the earlier repairs missed them
-----------------------------------
`extract_rtl.unreverse` decides how to treat a digit run from what it touches.
A vital sign is usually glued to Latin ("PB=05/08", "RP = 021/nim") or sits
inside a compound token, so the touch test either protected a mirrored value or
could not see the run as one number at all.

The fix
-------
Glyph geometry, the same independent method that settled the archive ages and
was calibrated against the ministry's own English booklet. pdfplumber reports
each glyph's x-coordinate, and a number is always drawn left to right even
inside right-to-left script. So sorting a line's digits by x0 recovers the
digits as the typesetter placed them.

Nothing is guessed: a replacement is written only when the line matches the
question on Persian LETTERS alone, the corrected value is physiological, and
the corrected digits are a permutation of the stored ones.

Observation versus inference
----------------------------
Most repairs are direct observation: the page printed 120/80 and the extractor
mangled it. A few are inference: the page ITSELF printed an impossible run (a
respiratory rate of 130, a fever of 340), so the mirror — or dropping a stray
glyph — is merely the only physiological reading. Those are flagged in
`vitals_uncertain` rather than presented with the same confidence.
"""
import json, io, os, re, sys, collections

import pdfplumber

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = '/home/user/uploads/بیماری عفونی.pdf'

PLAUSIBLE = {
    'temp': lambda v: 34 <= v <= 43,
    'RR':   lambda v: 8 <= v <= 60,
    'PR':   lambda v: 30 <= v <= 200,
}


def bp_ok(sys_, dia):
    return 60 <= sys_ <= 260 and 20 <= dia <= 160 and sys_ > dia


def letters(s):
    s = re.sub(r'[\u0660-\u0669\u06F0-\u06F9]', '', s or '')
    return re.sub(r'[^\u0600-\u06FF]', '', s)


def page_lines(pdf):
    """(letters-key, digits-in-printed-order, text) for every line of the book."""
    out = []
    for page in pdf.pages:
        rows = collections.defaultdict(list)
        for c in page.chars:
            rows[round(c['top'])].append(c)
        for top in sorted(rows):
            cs = sorted(rows[top], key=lambda c: c['x0'])
            text = ''.join(c['text'] for c in cs)[::-1]     # visual -> logical
            digits = [c['text'] for c in cs if c['text'].isdigit()]
            out.append((letters(text), ''.join(digits), text))
    return out


def find_bad(stem):
    """Every implausible vital sign in a stem, as (kind, matched-text, value)."""
    bad = []
    for m in re.finditer(r'(?:T\s*[:=]\s*|درجه حرارت[^0-9]{0,12})(\d{2,3})(?![\d/])', stem):
        if not PLAUSIBLE['temp'](int(m.group(1))):
            bad.append(('temp', m.group(0), m.group(1)))
    # A temperature is just as often written with the unit AFTER the number:
    # "تب 340 درجه". The pattern above anchors on the label coming first, so
    # these were never inspected.
    for m in re.finditer(r'(?:تب|دما)\s*(\d{2,3})\s*درج', stem):
        if not PLAUSIBLE['temp'](int(m.group(1))):
            # The label itself constrains the value: the word تب means FEVER,
            # so the reading must be febrile. That is what separates 40 from 34
            # in "تب 340 درجه" — 34 would be hypothermia, contradicting the
            # very word introducing it. The same style of semantic argument
            # fix_ages.py uses for the noun that introduces a patient.
            kind = 'fever' if 'تب' in m.group(0) else 'temp'
            bad.append((kind, m.group(0), m.group(1)))
    for m in re.finditer(r'(?:RR|تعداد تنفس)\s*[:=]?\s*(\d{2,3})', stem):
        if not PLAUSIBLE['RR'](int(m.group(1))):
            bad.append(('RR', m.group(0), m.group(1)))
    # The exporter also writes a rate as "min82" (the unit glued in front of a
    # mirrored value, from "28/min").
    for m in re.finditer(r'(?:تاک\s*یپنه|تاکیپنه|تاکی‌پنه|تعداد\s*تنفس|RR)\s*min\s*(\d{2,3})', stem):
        if not PLAUSIBLE['RR'](int(m.group(1))):
            bad.append(('RR', m.group(0), m.group(1)))
    for m in re.finditer(r'(?:PR|HR|نبض)\s*[:=]?\s*(\d{2,3})', stem):
        if not PLAUSIBLE['PR'](int(m.group(1))):
            bad.append(('PR', m.group(0), m.group(1)))
    for m in re.finditer(r'(?<![\d/])(\d{2,3})/(\d{2,3})(?![\d/])', stem):
        before = stem[max(0, m.start() - 18):m.start()]
        after = stem[m.end():m.end() + 8]
        # A lab count labels the number immediately ("Plt: 80/000",
        # "14/700=WBC") and uses the slash as a thousands separator. Those are
        # not vital signs, and "correcting" one would corrupt a good value.
        if re.search(r'(Plt|WBC|CPK|پلاکت|لکوسیت)\s*[:=]?\s*$', before) or \
           re.match(r'\s*[:=]?\s*(WBC|Plt|CPK)', after):
            continue
        if not re.search(r'(فشار\s*خون|BP|Bp|bp|PB|mmHg|gHmm)\s*[:=]?\s*$', before):
            continue
        if not bp_ok(int(m.group(1)), int(m.group(2))):
            bad.append(('BP', m.group(0), f'{m.group(1)}/{m.group(2)}'))
    return bad


def repair_value(kind, stored, printed_digits):
    """Best plausible reading of `stored`, given the digits the page printed.

    A trailing '!' marks a reading that is INFERENCE rather than observation:
    the page's own printed order was itself impossible.
    """
    if kind == 'BP':
        a, b = stored.split('/')
        cands = set()
        for src in {printed_digits, a + b, (a + b)[::-1], a[::-1] + b[::-1]}:
            d = ''.join(ch for ch in src if ch.isdigit())
            for cut in range(2, 4):
                if len(d) < cut + 2:
                    continue
                x, y = d[:cut], d[cut:cut + 3]
                for y2 in {y, y[:2]}:
                    if not (x.isdigit() and y2.isdigit()):
                        continue
                    if x.startswith('0') or y2.startswith('0'):
                        continue
                    if bp_ok(int(x), int(y2)):
                        cands.add(f'{int(x)}/{int(y2)}')
        if len(cands) == 1:
            return cands.pop()
        want = sorted((a + b).lstrip('0'))
        exact = {c for c in cands if sorted(c.replace('/', '')) == want}
        if len(exact) == 1:
            return exact.pop()
        return None

    if kind == 'fever':
        # a febrile reading, built only from contiguous digits the page printed
        subs = ({stored[:2], stored[1:], stored[::-1][:2]} if len(stored) == 3
                else {stored, stored[::-1]})
        ok = {t.lstrip('0') for t in subs
              if t.lstrip('0').isdigit() and 38 <= int(t.lstrip('0')) <= 43}
        if len(ok) == 1:
            return str(int(ok.pop())) + '!'
        return None

    if kind == 'temp' and len(stored) == 3:
        # "340" for 40: the exporter emitted a stray digit that no rotation can
        # absorb. Only accept a CONTIGUOUS substring of what the page printed,
        # so we drop a spurious glyph rather than invent a value, and only when
        # exactly one such reading is physiological.
        subs = {stored[:2], stored[1:]}
        ok = {t.lstrip('0') for t in subs
              if t.lstrip('0').isdigit() and PLAUSIBLE['temp'](int(t.lstrip('0')))}
        if len(ok) == 1:
            return str(int(ok.pop())) + '!'
        return None

    rev = stored[::-1].lstrip('0') or '0'
    fwd = stored.lstrip('0') or '0'
    printed = None
    if stored in printed_digits:
        printed = fwd
    elif stored[::-1] in printed_digits:
        printed = rev
    if printed and PLAUSIBLE[kind](int(printed)):
        return str(int(printed))

    # The value as STORED is what the extractor read off the page in printed
    # order, so if that reading is itself impossible the page carries a
    # mirrored run and any repair is inference, not observation.
    stored_impossible = fwd.isdigit() and not PLAUSIBLE[kind](int(fwd))

    ok = [v for v in (fwd, rev) if v.isdigit() and PLAUSIBLE[kind](int(v))]
    if len(set(ok)) == 1:
        flag = '!' if (stored_impossible and str(int(ok[0])) != fwd) else ''
        return str(int(ok[0])) + flag
    return None


def main():
    with pdfplumber.open(SRC) as pdf:
        lines = page_lines(pdf)

    index = collections.defaultdict(list)
    for key, digits, text in lines:
        if len(key) >= 12:
            index[key].append(digits)

    fixed = files = 0
    skipped, examples = [], []

    for i in range(1, 6):
        p = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        if not os.path.exists(p):
            continue
        body = json.load(io.open(p, encoding='utf-8'))
        dirty = False

        for q in body['questions']:
            bad = find_bad(q['question_fa'])
            if not bad:
                continue

            stem_keys = [letters(x) for x in re.split(r'(?<=[.؟])\s+', q['question_fa'])]
            printed = ''.join(
                d for k in stem_keys if len(k) >= 12
                for cands in [index.get(k, [])] if len(cands) == 1
                for d in cands)

            changes, uncertain = {}, []
            for kind, matched, stored in bad:
                new = repair_value(kind, stored, printed)
                inferred = bool(new) and new.endswith('!')
                if inferred:
                    new = new[:-1]
                    uncertain.append(f"{kind} {stored}->{new}")
                if not new or new == stored:
                    skipped.append(f"q{q['question_no']}: {kind} {stored} unresolved")
                    continue
                # a 3-digit temperature is repaired by DROPPING a stray glyph,
                # so its digits are a subset rather than a permutation
                if kind in ('temp', 'fever') and len(stored) == 3 and new in stored:
                    changes[matched] = matched.replace(stored, new)
                    continue
                a = sorted(ch for ch in new if ch.isdigit())
                b = sorted(ch for ch in stored if ch.isdigit())
                if a != b and a != [c for c in b if c != '0'] and \
                   sorted(a + ['0'] * (len(b) - len(a))) != b:
                    skipped.append(f"q{q['question_no']}: {kind} {stored}->{new} changes digits")
                    continue
                changes[matched] = matched.replace(stored, new)

            if not changes:
                continue
            stem = q['question_fa']
            for old, new in changes.items():
                stem = stem.replace(old, new)
            q['question_fa'] = stem
            q['vitals_corrected'] = dict(changes)
            if uncertain:
                q['vitals_uncertain'] = uncertain
            q['vitals_correction_note_fa'] = (
                'علائم حیاتی این سؤال در استخراج PDF با ارقام معکوس خوانده شده بود '
                '(مثلاً فشار خون یا دما وارونه). مقادیر از روی ترتیب افقی نویسه‌های همان '
                'صفحه‌ی کتاب بازخوانی و اصلاح شده‌اند.')
            q['vitals_correction_note_en'] = (
                "This question's vital signs were mis-read by the PDF extraction with reversed "
                "digits. The values were re-read from the horizontal glyph order on the same "
                "page of the book and corrected.")
            fixed += 1
            dirty = True
            if len(examples) < 25:
                examples.append((q['question_no'], changes))

        if dirty:
            json.dump(body, io.open(p, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)
            files += 1

    print(f'questions repaired: {fixed}   files rewritten: {files}')
    for no, ch in examples:
        for a, b in ch.items():
            print(f'  q{no}: {a.strip()}  ->  {b.strip()}')
    if skipped:
        print(f'\n{len(skipped)} left alone:')
        for s in skipped:
            print('  !', s)


if __name__ == '__main__':
    main()
