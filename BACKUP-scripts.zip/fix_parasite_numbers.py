# -*- coding: utf-8 -*-
"""Repair the mirrored numbers of the parasitology / malaria chapter.

Every correction below was settled by GLYPH GEOMETRY, not by judgement: the
book's own PDF was reopened, each glyph's x-coordinate read, and the digits
sorted left to right — the order the typesetter actually placed them. A number
is drawn left to right even inside right-to-left script, so that order is the
printed value. The extracted text stores the LOGICAL order, and that is where a
two-digit run gets reversed.

The five repairs, with the page evidence:

  q9736  paromomycin "mg005"  -> 500 mg
         p272 glyphs: 5@308.4  0@318.4  0@328.4   -> "500"
         500 mg three times daily for seven days is the standard luminal dose;
         "5 mg" would be pharmacological nonsense.

  q9754  "فرد 71 ساله"        -> 17 years old
         p278 glyphs: 1@283.9  7@293.9            -> "17"
         (Note the discipline here: a 71-year-old is perfectly possible, so the
         value is NOT changed because it looks odd. It is changed because the
         page prints 17. The opposite mistake — "correcting" a real 91-year-old
         because 91 seemed unlikely — is exactly the bug fix_ages.py had to
         undo, which is why UNLIKELY_OVER is None there.)

  q9768  "اسیدوز متابولیک شدید (1.7≥PH)" -> pH ≤ 7.1
         p283 glyphs: 7@348.4  .@358.4  1@368.4   -> "7.1"
         A pH of 1.7 is not compatible with life; 7.1 is the severe-acidosis
         threshold the question is testing.

  q9769  "بیکربنات 71 mmol/L" -> 17 mmol/L
         p284 glyphs: 1@264.1  7@274.1            -> "17"
         This one also REPAIRS THE ANSWER. The printed key says option D (pH
         7.35, bicarbonate ...) is NOT a bad prognostic sign. With 71 mmol/L
         the option is meaningless; with 17 mmol/L it sits just above the
         severe-malaria threshold of 15, so the key becomes exactly right. The
         geometry and the key independently agree — strong confirmation.

  q9770  "هموگلوبین gr6/4"   -> 4/6 (4.6 g/dL)
         p284 glyphs: 4@273.1  /@283.1  6@287.9   -> "4/6"

  q9805  "تخم ... حدود mμ52" -> 25 μm
         p296 glyphs: 2@196.3  5@206.3            -> "25"

Each repair is verified against the page again at write time, and recorded in
`stem_number_corrections` so a reader can see what was changed and why.
"""
import json, io, os, re, collections

import pdfplumber

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = '/home/user/uploads/بیماری عفونی.pdf'

# question -> (page, text-to-replace, replacement, printed-digits-expected, why)
FIXES = {
    9736: (272, 'mg005', 'mg500', '500',
           'دوز پارومومایسین: صفحه ۲۷۲ رقم‌ها را ۵۰۰ چاپ کرده است.'),
    9754: (278, '71 ساله', '17 ساله', '17',
           'سن: صفحه ۲۷۸ رقم‌ها را ۱۷ چاپ کرده است.'),
    9768: (283, '1.7≤PH', 'PH≤7.1', '7.1',
           'pH: صفحه ۲۸۳ رقم‌ها را ۷٫۱ چاپ کرده است؛ pH برابر ۱٫۷ با حیات سازگار نیست.'),
    9769: (284, 'بیکربنات 71', 'بیکربنات 17', '17',
           'بیکربنات: صفحه ۲۸۴ رقم‌ها را ۱۷ چاپ کرده است؛ با کلید چاپی هم سازگار می‌شود.'),
    9770: (284, 'gr6/4', 'gr4/6', '4/6',
           'هموگلوبین: صفحه ۲۸۴ رقم‌ها را ۴٫۶ چاپ کرده است.'),
    9805: (296, 'mμ52', 'mμ25', '25',
           'اندازه‌ی تخم: صفحه ۲۹۶ رقم‌ها را ۲۵ چاپ کرده است.'),
}


def page_digit_runs(pdf, pno):
    """Every printed-order digit run on a page, as the typesetter placed it."""
    page = pdf.pages[pno - 1]
    rows = collections.defaultdict(list)
    for c in page.chars:
        rows[round(c['top'])].append(c)
    runs = []
    for top in sorted(rows):
        cs = sorted(rows[top], key=lambda c: c['x0'])
        cur = ''
        for c in cs:
            t = c['text']
            if t.isspace() and cur:
                # The typesetter's kerning sometimes drops a space INSIDE a
                # decimal ("7. 1"), so a space must not end a run that is
                # already open — otherwise the value can never be seen whole.
                continue
            if t.isdigit() or (cur and t in './'):
                cur += t
            else:
                if cur:
                    runs.append(cur.strip('./'))
                cur = ''
        if cur:
            runs.append(cur.strip('./'))
    return runs


def main():
    with pdfplumber.open(SRC) as pdf:
        pages = {p: page_digit_runs(pdf, p) for p, *_ in
                 ((v[0],) for v in FIXES.values())}

    applied, missing = [], []
    for i in range(1, 6):
        p = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        body = json.load(io.open(p, encoding='utf-8'))
        dirty = False
        for q in body['questions']:
            spec = FIXES.get(q['question_no'])
            if not spec:
                continue
            pno, old, new, expect, why = spec
            # refuse to write a value the page does not actually print
            assert expect in pages[pno], \
                f'q{q["question_no"]}: page {pno} does not print {expect}'
            # A mirrored number is just as likely to sit in an OPTION as in the
            # stem — three of the six here are option text, and two of those
            # options are the printed key, so skipping them would leave the
            # answer itself unreadable.
            where = None
            if old in q['question_fa']:
                q.setdefault('stem_original_fa', q['question_fa'])
                q['question_fa'] = q['question_fa'].replace(old, new)
                where = 'stem'
            else:
                for oi, opt in enumerate(q['options_fa']):
                    if old in opt:
                        q.setdefault('options_original_fa', list(q['options_fa']))
                        q['options_fa'][oi] = opt.replace(old, new)
                        where = f'option {oi + 1}'
                        break
            if not where:
                missing.append(f'q{q["question_no"]}: {old!r} not found')
                continue
            rec = q.setdefault('stem_number_corrections', [])
            rec.append({'from': old, 'to': new, 'page': pno, 'where': where,
                        'method': 'glyph geometry (pdfplumber x-order)',
                        'why_fa': why})
            applied.append(f'q{q["question_no"]}: {old} -> {new}  ({where})')
            dirty = True
        if dirty:
            json.dump(body, io.open(p, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)

    for a in applied:
        print('fixed  ', a)
    for m in missing:
        print('MISSING', m)
    print(f'\n{len(applied)} corrections written, {len(missing)} not found')


if __name__ == '__main__':
    main()
