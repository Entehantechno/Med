# -*- coding: utf-8 -*-
"""Repair the damaged numbers of the skin and soft tissue chapter.

Method — unchanged from the six previous chapters
-------------------------------------------------
pdfplumber gives the x-coordinate of every glyph, and a number is drawn left to
right even inside right-to-left script. Sorting a line's glyphs by x0 and
reading the digit runs recovers exactly the values the typesetter placed on the
page; the extracted text keeps the LOGICAL order, and that is where a value
gets mirrored.

Three kinds of repair, all three of which this chapter needed
-------------------------------------------------------------
  kind='reorder'  the digits the page printed, put back in printed order
  kind='restore'  a digit the extraction DROPPED, put back; a stronger claim,
                  so main() holds it to a stronger assertion

Why these numbers change the answer
-----------------------------------
This is the chapter of NECROTISING FASCIITIS and TOXIC SHOCK SYNDROME, and in
both the diagnosis is made by recognising that the patient is far sicker than
the skin looks. The vital signs ARE the diagnosis. A mirrored pulse or blood
pressure does not merely look odd — it removes the very evidence of shock that
should send the patient to theatre.

  q9017  "تاکی‌کاردی min011 و تاکیپنه min26" — page 7 prints 110 and 26. The
         stored text had glued the unit to a mirrored number, producing
         "min011", which is not a rate at all. This is the asplenic boy with
         Capnocytophaga sepsis, and the tachycardia of 110 with a respiratory
         rate of 26 is the evidence that he is septic.

  q9025  "OT: 3/83" — page 10 prints 38.3. A temperature of 83 degrees is not
         compatible with life; more to the point, this is the diabetic woman
         with necrotising fasciitis of the thigh, and her fever is one leg of
         the septic picture that justifies immediate surgical exploration.

  q9028  TWO defects on one line. The page prints "فشار خون 70/p" and
         "تعداد تنفس 130"; the extraction mirrored BOTH, giving a blood
         pressure of "p/07" and a respiratory rate of 31. The blood pressure
         of 70 systolic with an unrecordable diastolic is the shock of
         clostridial sepsis after an unsafe abortion — the finding the whole
         question turns on.

  q9031  "01 نفر" — page 13 prints 10. Ten people with painless black-eschar
         lesions and NO ANIMAL CONTACT is the stem's way of saying deliberate
         release, which is why the answer is 60 days of ciprofloxacin rather
         than 10 days of amoxicillin. "One person" would remove the outbreak.

  q9035  "خانم 23 ساله" — page 14 prints 32.

  q9060  "لکوسیتوز 00091" — page 23 prints 19000. A leucocyte count of 91 is
         incompatible with life, and 19000 is the neutrophilia of toxic shock.

A note on q9031's key, examined and left standing
-------------------------------------------------
The printed key is ciprofloxacin for 60 days, and it is right for a reason
worth teaching. Cutaneous anthrax acquired from an animal is treated for 7 to
10 days. But these ten patients have NO animal contact, which raises the
possibility of an aerosol release; in that setting the concern is not the skin
lesion but INHALED SPORES, which can germinate late. Sixty days of therapy
covers that latency. So the duration in the option is not a detail — it is the
diagnosis of the exposure.
"""
import json, io, os, re, collections

import pdfplumber

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = '/home/user/uploads/بیماری عفونی.pdf'

# question_no -> [(page, old, new, expected_printed_run, kind, why_fa), ...]
FIXES = {
    9017: [
        (7, 'تاک یکاردی min011', 'تاک یکاردی 110/min', '110', 'reorder',
         'ضربان قلب: صفحه ۷ رقم‌ها را ۱۱۰ چاپ کرده است؛ «min011» اصلاً یک '
         'میزان نیست. این تاکی‌کاردی بخشی از شواهد سپسیس در پسر اسپلنکتومی‌شده '
         'است و حذفش، دلیل بدحالی بیمار را از سؤال می‌گیرد.'),
        (7, 'تاکیپنه min26', 'تاکیپنه 26/min', '26', 'reorder',
         'تعداد تنفس: صفحه ۷ رقم‌ها را ۲۶ چاپ کرده است.'),
    ],
    9025: [
        (10, ':OT 3/83', 'T=38.3', '38', 'reorder',
         'درجه حرارت: صفحه ۱۰ «۳۸٫۳» چاپ کرده است؛ «۸۳ درجه» با حیات سازگار '
         'نیست. این تب یکی از پایه‌های تابلوی سپتیک در فاشئیت نکروزان ران است '
         'و همان چیزی است که اکسپلور فوری جراحی را توجیه می‌کند.'),
    ],
    9028: [
        (12, 'فشار خون p/07', 'فشار خون 70/p', '70', 'reorder',
         'فشار خون: صفحه ۱۲ «۷۰/p» چاپ کرده است، یعنی سیستولیک ۷۰ با '
         'دیاستولیک غیرقابل ثبت. این همان شوکِ سپسیس کلستریدیایی پس از سقط '
         'ناایمن است و کل سؤال روی آن می‌چرخد.'),
        (12, 'تعداد تنفس 31', 'تعداد تنفس 130', '130', 'restore',
         'تعداد تنفس: صفحه ۱۲ رقم‌ها را ۱۳۰ چاپ کرده و رقم یک در استخراج '
         'افتاده بود. (عدد ۱۳۰ به‌عنوان تعداد تنفس در خودِ کتاب هم نامتعارف '
         'است؛ متن دقیقاً همان چیزی ثبت می‌شود که صفحه چاپ کرده و قضاوت درباره‌ی '
         'آن به درسنامه سپرده شده است.)'),
    ],
    9031: [
        (13, '01 نفر', '10 نفر', '10', 'reorder',
         'تعداد بیماران: صفحه ۱۳ رقم‌ها را ۱۰ چاپ کرده است. این عدد تزئینی '
         'نیست: «ده نفر با ضایعه‌ی بدون درد و بدون تماس با دام» یعنی طغیان '
         'مشکوک به انتشار عمدی، و دقیقاً همین است که درمان ۶۰ روزه را توجیه '
         'می‌کند. با «یک نفر»، طغیان از سؤال حذف می‌شد.'),
    ],
    9035: [
        # Page 15, not 14: the question begins at the foot of page 14 and its
        # fourth option spills onto the next page. The assertion caught this —
        # the first draft said page 14 and the script refused to write.
        (15, 'خانم 23 ساله', 'خانم 32 ساله', '32', 'reorder',
         'سن: صفحه ۱۵ رقم‌ها را ۳۲ چاپ کرده است. (سؤال در پایین صفحه‌ی ۱۴ '
         'شروع می‌شود و گزینه‌ی چهارمش به صفحه‌ی بعد سرریز کرده است.)'),
    ],
    9060: [
        (23, 'لکوسیتوز 00091', 'لکوسیتوز 19000', '19000', 'reorder',
         'شمارش لکوسیت: صفحه ۲۳ رقم‌ها را ۱۹۰۰۰ چاپ کرده است؛ «۰۰۰۹۱» عدد '
         'نیست و لکوسیت ۹۱ با حیات سازگار نیست. ۱۹۰۰۰ همان نوتروفیلی سندرم '
         'شوک توکسیک است.'),
    ],
}

FOLD = {}
for _i in range(10):
    FOLD[chr(0x0660 + _i)] = str(_i)   # Arabic-Indic
    FOLD[chr(0x06F0 + _i)] = str(_i)   # Persian


def page_digit_runs(pdf, pno):
    """Digit runs of a page in PRINTED (x-ascending) order."""
    page = pdf.pages[pno - 1]
    rows = collections.defaultdict(list)
    for c in page.chars:
        rows[round(c['top'])].append(c)
    runs = []
    for top in sorted(rows):
        cs = sorted(rows[top], key=lambda c: c['x0'])
        cur = ''
        for c in cs:
            t = FOLD.get(c['text'], c['text'])
            # a space must NOT close an open run: kerning sometimes splits a
            # number, and closing on the space invents two numbers out of one
            if t.isspace() and cur:
                continue
            if t.isdigit():
                cur += t
            else:
                if cur:
                    runs.append(cur)
                cur = ''
        if cur:
            runs.append(cur)
    return runs


def main():
    pages = {p for specs in FIXES.values() for (p, *_r) in specs}
    with pdfplumber.open(SRC) as pdf:
        printed = {p: page_digit_runs(pdf, p) for p in pages}

    applied, missing = [], []
    for i in range(1, 6):
        path = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        body = json.load(io.open(path, encoding='utf-8'))
        dirty = False
        for q in body['questions']:
            specs = FIXES.get(q['question_no'])
            if not specs:
                continue
            for pno, old, new, expect, kind, why in specs:
                assert expect in printed[pno], \
                    f'q{q["question_no"]}: page {pno} does not print {expect}'
                old_d = [c for c in old if c.isdigit()]
                new_d = [c for c in new if c.isdigit()]
                if kind == 'reorder':
                    assert sorted(old_d) == sorted(new_d), \
                        f'q{q["question_no"]}: {old} -> {new} is not a reordering'
                else:
                    assert kind == 'restore', f'unknown kind {kind!r}'
                    have = collections.Counter(new_d)
                    for ch, n in collections.Counter(old_d).items():
                        assert have[ch] >= n, \
                            f'q{q["question_no"]}: {old} -> {new} loses a printed digit'
                    for run in re.findall(r'\d+', new):
                        assert run in printed[pno], \
                            f'q{q["question_no"]}: page {pno} does not print restored {run}'

                hit = False
                if old in q['question_fa']:
                    q.setdefault('stem_original_fa', q['question_fa'])
                    q['question_fa'] = q['question_fa'].replace(old, new)
                    q.setdefault('stem_number_corrections', []).append({
                        'from': old, 'to': new, 'page': pno, 'where': 'stem',
                        'method': 'glyph geometry (pdfplumber x-order)',
                        'kind': kind, 'why_fa': why})
                    applied.append(f'q{q["question_no"]}: {old} -> {new} (stem)')
                    hit = True
                    dirty = True
                for oi, opt in enumerate(q['options_fa']):
                    if old in opt:
                        q.setdefault('options_original_fa', list(q['options_fa']))
                        q['options_fa'][oi] = opt.replace(old, new)
                        q.setdefault('stem_number_corrections', []).append({
                            'from': old, 'to': new, 'page': pno,
                            'where': f'option {oi + 1}',
                            'method': 'glyph geometry (pdfplumber x-order)',
                            'kind': kind, 'why_fa': why})
                        applied.append(
                            f'q{q["question_no"]}: {old} -> {new} (option {oi + 1})')
                        hit = True
                        dirty = True
                if not hit:
                    missing.append(f'q{q["question_no"]}: {old!r} not found')
        if dirty:
            json.dump(body, io.open(path, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)

    for a in applied:
        print('fixed  ', a)
    for m in missing:
        print('MISSING', m)
    print(f'\n{len(applied)} corrections written, {len(missing)} not found')


if __name__ == '__main__':
    main()
