# -*- coding: utf-8 -*-
"""Micro-lessons, batch 47 — food poisoning, the acute-diarrhoea algorithm,
and the Clostridioides difficile cluster.

TWENTY QUESTIONS, THREE IDEAS.

IDEA ONE — THE INCUBATION PERIOD NAMES THE ORGANISM.
In toxin-mediated food poisoning the interval between the meal and the illness
is not a detail; it is the diagnostic test, because it measures whether the
toxin was ALREADY IN THE FOOD or had to be MADE IN THE GUT.

    1 to 6 hours     PREFORMED toxin, swallowed ready-made
                     STAPH AUREUS   — vomiting dominates; creamy foods, salads,
                                      mayonnaise; the food was left at room
                                      temperature after cooking
                     BACILLUS CEREUS (emetic form) — reheated rice
    8 to 16 hours    toxin made by spores germinating in the gut
                     CLOSTRIDIUM PERFRINGENS — reheated meat, gravy; cramps and
                                      watery diarrhoea, vomiting uncommon
    over 16 hours    INVASION or in-gut toxin production
                     Salmonella, Shigella, Campylobacter, EHEC, Vibrio

So "four hours after a party, vomiting and diarrhoea" is Staph aureus and needs
no test at all; and "slow cooling and storage at room temperature" is the exact
mechanism by which Staph aureus food poisoning happens.

IDEA TWO — MOST ACUTE WATERY DIARRHOEA NEEDS FLUID, NOT ANTIBIOTICS OR TESTS.
The book asks this four separate times, so it is worth stating as a rule:

    stable patient, watery stool, no blood, no fever, short history
        -> REHYDRATE. No culture, no antibiotic, no antimotility hunt.
    dysentery (blood + fever + stool white cells)
        -> rehydrate AND treat: a fluoroquinolone empirically in an adult.
    ANTIMOTILITY AGENTS (loperamide, diphenoxylate) ARE CONTRAINDICATED IN
    INFLAMMATORY DIARRHOEA: slowing the bowel prolongs mucosal contact with the
    organism and its toxin, and can precipitate toxic megacolon.

IDEA THREE — C. DIFFICILE, AND ONE GUIDELINE THAT HAS MOVED.
Recognise it by the setting: recent or current antibiotics (clindamycin,
cephalosporins and fluoroquinolones are the classic three), a hospital stay,
and diarrhoea that is usually non-bloody with a low-grade fever.

  DIAGNOSIS. Stool culture is NOT the test — C. difficile grows readily in
     people who are merely colonised, so a positive culture proves nothing
     about disease. Toxin testing (EIA, or PCR for the toxin gene) is the test.
     PCR is the most SENSITIVE; colonoscopy for pseudomembranes is the LEAST
     sensitive, because pseudomembranes are absent in many genuine cases.

  INFECTION CONTROL. Two facts that questions are built on:
     ALCOHOL HAND RUB DOES NOT KILL SPORES — hands must be washed with soap and
        water. This is the one setting where alcohol gel is the wrong answer.
     Hypochlorite (bleach) is needed for surfaces, for the same reason.
     And asymptomatic carriers are NOT screened or treated.

  TREATMENT, AND THE GUIDELINE THAT MOVED. The book keys metronidazole, and for
     the era of these sittings that was correct. Since the 2017-2018 IDSA/SHEA
     revision and the 2021 ESCMID and IDSA/SHEA updates, METRONIDAZOLE IS NO
     LONGER FIRST LINE: oral vancomycin or fidaxomicin are, with metronidazole
     reserved for when neither is available. The lessons state BOTH, so a
     student is not caught out by either the exam or the ward.
     For FULMINANT disease the book's own answer and today's guidance agree:
     ORAL VANCOMYCIN (plus intravenous metronidazole).

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022) — acute
infectious diarrhoeal diseases and bacterial food poisoning, and Clostridioides
difficile infection; Johnson S et al., IDSA/SHEA 2021 focused update
(Clin Infect Dis 2021;73:e1029); van Prehn J et al., ESCMID 2021 treatment
guidance (Clin Microbiol Infect 2021;27 Suppl 2:S1).
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — "
     "acute infectious diarrhoeal diseases and bacterial food poisoning")
HCD = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — "
       "Clostridioides difficile infection, including pseudomembranous colitis")
IDSA21 = ("Johnson S et al. — Clinical Practice Guideline by IDSA and SHEA: "
          "2021 Focused Update Guidelines on Management of Clostridioides "
          "difficile Infection in Adults (Clin Infect Dis 2021;73:e1029)")
ESCMID21 = ("van Prehn J et al. — European Society of Clinical Microbiology and "
            "Infectious Diseases: 2021 update on the treatment guidance document "
            "for Clostridioides difficile infection in adults "
            "(Clin Microbiol Infect 2021;27 Suppl 2:S1)")
REFS = [H]
CDREFS = [HCD, IDSA21, ESCMID21]

# ==================================================== FOOD POISONING: SHARED
FP_FA = [
    "⚠️ **در مسمومیت غذایی، فاصله‌ی میان غذا و بیماری، خودِ آزمون تشخیصی است.**",
    "**چون این فاصله نشان می‌دهد سم از قبل در غذا بوده یا باید در روده ساخته می‌شده.**",
    "**یک تا شش ساعت: سم از پیش ساخته‌شده، که آماده بلعیده شده است.**",
    "**استاف اورئوس: استفراغ غالب است؛ از غذای خامه‌ای، سالاد و سس مایونز.**",
    "**و باسیلوس سرئوس شکل استفراغی: از برنج مانده و دوباره گرم‌شده.**",
    "⚠️ **هشت تا شانزده ساعت: سم را اسپورهایی می‌سازند که در روده جوانه می‌زنند.**",
    "**کلستریدیوم پرفرانژنس: از گوشت و آبگوشت دوباره گرم‌شده.**",
    "**کرامپ و اسهال آبکی غالب است، و استفراغ کم است.**",
    "**بیش از شانزده ساعت: تهاجم یا تولید سم در روده.**",
    "**سالمونلا، شیگلا، کمپیلوباکتر، EHEC، ویبریو.**",
    "⚠️ **پس «چهار ساعت پس از مهمانی» یعنی استاف اورئوس، بدون نیاز به هیچ آزمایشی.**",
    "**و سازوکار آن دقیقاً همان است که سؤال دیگری می‌پرسد.**",
    "**غذای پخته اگر آهسته خنک شود و در دمای اتاق بماند، استاف در آن رشد می‌کند.**",
    "**و سم آن مقاوم به حرارت است، پس گرم کردن دوباره آن را از بین نمی‌برد.**",
    "**درمان همه‌ی این‌ها یکی است: مایع‌درمانی. آنتی‌بیوتیک جایی ندارد.**",
]
FP_EN = [
    "WARNING: IN FOOD POISONING, THE INTERVAL BETWEEN MEAL AND ILLNESS IS ITSELF THE DIAGNOSTIC TEST.",
    "Because that interval shows whether the toxin was already in the food or had to be made in the gut.",
    "ONE TO SIX HOURS: PREFORMED toxin, swallowed ready-made.",
    "STAPH AUREUS: vomiting dominates; from creamy foods, salads and mayonnaise.",
    "And BACILLUS CEREUS in its emetic form: from reheated rice.",
    "WARNING, EIGHT TO SIXTEEN HOURS: the toxin is made by spores germinating in the gut.",
    "CLOSTRIDIUM PERFRINGENS: from reheated meat and gravy.",
    "Cramps and watery diarrhoea dominate, and vomiting is uncommon.",
    "OVER SIXTEEN HOURS: invasion, or toxin production in the gut.",
    "Salmonella, Shigella, Campylobacter, EHEC, Vibrio.",
    "WARNING, SO 'FOUR HOURS AFTER A PARTY' MEANS STAPH AUREUS, with no test required at all.",
    "And its mechanism is exactly what another question asks about.",
    "Cooked food that is cooled slowly and left at room temperature lets Staph grow in it.",
    "And its toxin is HEAT STABLE, so reheating does not destroy it.",
    "The treatment of all of these is the same: rehydration. Antibiotics have no place.",
]

add("book:295", "recall", "easy",
    "**ژیاردیا مسمومیت غذایی نیست — یک عفونت انگلی با دوره‌ی نهفتگی هفته‌هاست.**",
    "Giardia is not food poisoning — it is a parasitic infection with an incubation of weeks.",
    FP_FA,
    FP_EN,
    "این سؤال یک **تعریف** را می‌سنجد: مسمومیت غذایی چیست و چه چیزی نیست.\n\n"
    "⚠️ **«مسمومیت غذایی» در معنای دقیق یعنی بیماری سم‌محور با دوره‌ی نهفتگی کوتاه** — "
    "ساعت‌ها، نه روزها و نه هفته‌ها.\n\n"
    "**سه گزینه‌ی اول همگی مسمومیت غذایی کلاسیک‌اند:**\n\n"
    "**کلستریدیوم پرفرانژنس** — سم را **اسپورهایی می‌سازند که در روده جوانه می‌زنند**. "
    "نهفتگی **۸ تا ۱۶ ساعت**. منبع: **گوشت و آبگوشت دوباره گرم‌شده**. تابلو: کرامپ شکمی و "
    "اسهال آبکی، **استفراغ کم**.\n\n"
    "**باسیلوس سرئوس** — **دو شکل کاملاً متفاوت دارد** که ارزش دانستن دارد: شکل **استفراغی** "
    "با سم از پیش ساخته‌شده، نهفتگی **۱ تا ۶ ساعت**، از **برنج مانده و دوباره گرم‌شده**؛ و "
    "شکل **اسهالی** با نهفتگی **۸ تا ۱۶ ساعت**، شبیه پرفرانژنس.\n\n"
    "**کمپیلوباکتر ژژونی** — گرچه **تهاجمی** است و نهفتگی طولانی‌تری دارد (۲ تا ۵ روز)، "
    "در فهرست بیماری‌های **منتقله از غذا** (foodborne) قرار می‌گیرد و از **مرغ نیم‌پز و شیر "
    "غیرپاستوریزه** می‌آید.\n\n"
    "⚠️ **و استثنا: ژیاردیا لامبلیا.**\n\n"
    "**چرا؟ سه تفاوت بنیادی:**\n\n"
    "**یک — دوره‌ی نهفتگی.** ژیاردیا **یک تا دو هفته** طول می‌کشد تا علامت‌دار شود، نه چند "
    "ساعت. هیچ ارتباط زمانی روشنی با یک وعده‌ی غذایی خاص برقرار نمی‌شود.\n\n"
    "**دو — سازوکار.** هیچ سمی در کار نیست. ژیاردیا یک **تک‌یاخته** است که به مخاط روده‌ی "
    "باریک می‌چسبد و **جذب را مختل** می‌کند.\n\n"
    "**سه — تابلوی بالینی.** بیماری آن **مزمن و طول‌کشیده** است: **اسهال چرب و بدبو "
    "(استئاتوره)، نفخ، آروغ گوگردی و کاهش وزن** — نه یک حمله‌ی حاد چندساعته.\n\n"
    "**راه انتقال آن هم عمدتاً آب آلوده است، نه غذای مانده.**",
    "This question tests A DEFINITION: what food poisoning is and what it is not.\n\n"
    "WARNING, 'FOOD POISONING' IN ITS STRICT SENSE MEANS A TOXIN-MEDIATED ILLNESS WITH A SHORT "
    "INCUBATION — hours, not days and not weeks.\n\n"
    "THE FIRST THREE OPTIONS ARE ALL CLASSIC FOOD POISONING:\n\n"
    "CLOSTRIDIUM PERFRINGENS — its toxin is made by SPORES GERMINATING IN THE GUT. Incubation 8 TO 16 "
    "HOURS. Source: REHEATED MEAT AND GRAVY. Picture: abdominal cramps and watery diarrhoea, with "
    "LITTLE VOMITING.\n\n"
    "BACILLUS CEREUS — it has TWO ENTIRELY DIFFERENT FORMS worth knowing: an EMETIC form with "
    "preformed toxin, incubation 1 TO 6 HOURS, from REHEATED RICE; and a DIARRHOEAL form with an "
    "incubation of 8 TO 16 HOURS, resembling perfringens.\n\n"
    "CAMPYLOBACTER JEJUNI — although INVASIVE with a longer incubation (2 to 5 days), it belongs on the "
    "list of FOODBORNE illnesses and comes from UNDERCOOKED POULTRY AND UNPASTEURISED MILK.\n\n"
    "WARNING, AND THE EXCEPTION: GIARDIA LAMBLIA.\n\n"
    "WHY? THREE FUNDAMENTAL DIFFERENCES:\n\n"
    "ONE — THE INCUBATION PERIOD. Giardia takes ONE TO TWO WEEKS to become symptomatic, not hours. No "
    "clear temporal link to a particular meal can be established.\n\n"
    "TWO — THE MECHANISM. There is no toxin at all. Giardia is a PROTOZOAN that adheres to the small "
    "bowel mucosa and IMPAIRS ABSORPTION.\n\n"
    "THREE — THE CLINICAL PICTURE. Its illness is CHRONIC AND PROTRACTED: GREASY FOUL DIARRHOEA "
    "(steatorrhoea), BLOATING, SULPHUROUS BELCHING AND WEIGHT LOSS — not an acute attack over a few hours.\n\n"
    "Its route of transmission is also mainly CONTAMINATED WATER rather than spoiled food.",
    ["مسمومیت غذایی کلاسیک با نهفتگی ۸ تا ۱۶ ساعت، از گوشت دوباره گرم‌شده.",
     "دو شکل دارد: استفراغی از برنج مانده و اسهالی شبیه پرفرانژنس؛ هر دو مسمومیت غذایی‌اند.",
     "تهاجمی است ولی در فهرست بیماری‌های منتقله از غذا قرار می‌گیرد.",
     "پاسخ صحیح — نهفتگی یک تا دو هفته، بدون سم، با تابلوی مزمن سوءجذب."],
    ["Classic food poisoning with an 8 to 16 hour incubation, from reheated meat.",
     "Has two forms: emetic from reheated rice and diarrhoeal like perfringens; both are food poisoning.",
     "Invasive, but it belongs on the list of foodborne illnesses.",
     "Correct — a one to two week incubation, no toxin, and a chronic malabsorptive picture."],
    "**مسمومیت غذایی یعنی ساعت‌ها. ژیاردیا یعنی هفته‌ها.**",
    "Food poisoning means hours. Giardia means weeks.",
    REFS)

add("book:296", "vignette", "medium",
    "**ویبریوکلرا در مسمومیت غذایی مهمانی جایی ندارد — منبع آن آب آلوده و طغیان است، نه یک وعده.**",
    "Vibrio cholerae has no place in party food poisoning — its source is contaminated water and outbreaks, not one meal.",
    FP_FA + [
        "**این سؤال یک خانواده‌ی سه‌نفره را با علائم مشترک پس از یک مهمانی توصیف می‌کند.**",
        "**پس دنبال عاملی می‌گردیم که با یک وعده‌ی غذایی مشترک منتقل شود.**",
        "**استاف اورئوس، سالمونلا و شیگلا هر سه همین‌طورند.**",
        "⚠️ **ولی وبا الگوی اپیدمیولوژیک کاملاً متفاوتی دارد.**",
        "**وبا بیماری آب آلوده و بهداشت نامناسب و طغیان‌های منطقه‌ای است.**",
        "**و دوز عفونی آن بسیار بالاست: میلیون‌ها ارگانیسم لازم است.**",
        "**چون اسید معده بیشتر باکتری‌ها را از بین می‌برد.**",
        "**پس انتقال آن نیازمند آلودگی گسترده‌ی منبع آب است، نه یک ظرف سالاد.**",
    ],
    FP_EN + [
        "This question describes a family of three with shared symptoms after a party.",
        "So we look for an organism transmitted by one shared meal.",
        "Staph aureus, Salmonella and Shigella all fit that.",
        "WARNING, BUT CHOLERA HAS AN ENTIRELY DIFFERENT EPIDEMIOLOGICAL PATTERN.",
        "Cholera is a disease of contaminated water, poor sanitation and regional outbreaks.",
        "And its infective dose is very high: millions of organisms are needed.",
        "Because gastric acid destroys most of the bacteria.",
        "So its transmission requires wide contamination of a water supply, not one bowl of salad.",
    ],
    "این سؤال **اپیدمیولوژی** را می‌سنجد، نه صرفاً میکروبیولوژی.\n\n"
    "**موقعیت: خانواده‌ی سه‌نفره با اسهال و استفراغ، که ظهر روز گذشته در یک مهمانی شرکت "
    "کرده‌اند.**\n\n"
    "**پس دنبال عاملی می‌گردیم که با یک وعده‌ی غذایی مشترک منتقل شود و چند نفر را هم‌زمان "
    "بیمار کند.**\n\n"
    "**سه گزینه‌ای که می‌توانند:**\n\n"
    "**استاف اورئوس** — کلاسیک‌ترین. سم از پیش ساخته‌شده در غذای خامه‌ای یا سالاد که در دمای "
    "اتاق مانده. نهفتگی **۱ تا ۶ ساعت** — و «ظهر روز گذشته» با آن هم‌خوان است.\n\n"
    "**سالمونلا** — از تخم‌مرغ، مرغ و فرآورده‌های لبنی. نهفتگی **۱۲ تا ۷۲ ساعت**، که آن هم "
    "می‌خواند.\n\n"
    "**شیگلا** — **دوز عفونی بسیار پایینی دارد** (حدود ۱۰ تا ۱۰۰ ارگانیسم)، پس **به‌راحتی "
    "از فرد به فرد و از راه غذای دست‌کاری‌شده منتقل می‌شود**. طغیان‌های خانوادگی شیگلا شایع‌اند.\n\n"
    "⚠️ **و استثنا: ویبریوکلرا.**\n\n"
    "**چرا؟ دو دلیل مستقل:**\n\n"
    "**یک — دوز عفونی.** ⚠️ **وبا دوز عفونی بسیار بالایی دارد: میلیون‌ها ارگانیسم.** چرا؟ "
    "چون **اسید معده بیشتر ویبریوها را از بین می‌برد**. برای اینکه تعداد کافی زنده بماند و "
    "به روده‌ی باریک برسد، باید **مقدار بسیار زیادی** بلعیده شود. **یک ظرف سالاد در مهمانی "
    "چنین باری را حمل نمی‌کند.** (و به همین دلیل است که افراد با **هیپوکلریدری** یا مصرف "
    "مهارکننده‌ی پمپ پروتون، در خطر بیشترند.)\n\n"
    "**دو — الگوی اپیدمیولوژیک.** وبا بیماری **آب آلوده، بهداشت نامناسب و طغیان‌های منطقه‌ای** "
    "است. **مسمومیت غذایی خانوادگی پس از یک مهمانی، الگوی آن نیست.**\n\n"
    "**و اگر شک دارید، به تابلو نگاه کنید:** وبا **اسهال آبکی بسیار حجیم شبیه آب برنج** "
    "می‌دهد که به‌سرعت به دهیدراتاسیون شدید می‌رسد — نه یک اسهال و استفراغ ساده‌ی خانوادگی.",
    "This question tests EPIDEMIOLOGY rather than microbiology alone.\n\n"
    "THE SITUATION: a family of three with diarrhoea and vomiting who attended a party at midday "
    "yesterday.\n\n"
    "So we are looking for an organism transmitted by one shared meal, making several people ill at "
    "once.\n\n"
    "THE THREE THAT CAN:\n\n"
    "STAPH AUREUS — the most classic. Preformed toxin in a creamy food or salad left at room "
    "temperature. Incubation 1 TO 6 HOURS — and 'midday yesterday' fits.\n\n"
    "SALMONELLA — from eggs, poultry and dairy products. Incubation 12 TO 72 HOURS, which also fits.\n\n"
    "SHIGELLA — it has A VERY LOW INFECTIVE DOSE (about 10 to 100 organisms), so it TRANSMITS EASILY "
    "PERSON TO PERSON AND THROUGH HANDLED FOOD. Family outbreaks of Shigella are common.\n\n"
    "WARNING, AND THE EXCEPTION: VIBRIO CHOLERAE.\n\n"
    "WHY? TWO INDEPENDENT REASONS:\n\n"
    "ONE — THE INFECTIVE DOSE. WARNING, CHOLERA HAS A VERY HIGH INFECTIVE DOSE: MILLIONS OF ORGANISMS. "
    "Why? Because GASTRIC ACID DESTROYS MOST VIBRIOS. For enough to survive and reach the small bowel, "
    "A VERY LARGE QUANTITY must be swallowed. A BOWL OF SALAD AT A PARTY DOES NOT CARRY SUCH A LOAD. "
    "(And that is why people with HYPOCHLORHYDRIA or on proton pump inhibitors are at greater risk.)\n\n"
    "TWO — THE EPIDEMIOLOGICAL PATTERN. Cholera is a disease of CONTAMINATED WATER, POOR SANITATION AND "
    "REGIONAL OUTBREAKS. FAMILY FOOD POISONING AFTER A PARTY IS NOT ITS PATTERN.\n\n"
    "AND IF IN DOUBT, LOOK AT THE PICTURE: cholera gives VERY LARGE-VOLUME RICE-WATER DIARRHOEA that "
    "reaches severe dehydration rapidly — not a simple family episode of diarrhoea and vomiting.",
    ["پاسخ صحیح — دوز عفونی بسیار بالا و الگوی آب آلوده؛ مسمومیت غذایی مهمانی نیست.",
     "از تخم‌مرغ و مرغ و لبنیات منتقل می‌شود و طغیان غذایی کلاسیک می‌سازد.",
     "دوز عفونی بسیار پایینی دارد، پس به‌راحتی از راه غذای دست‌کاری‌شده منتقل می‌شود.",
     "کلاسیک‌ترین مسمومیت غذایی مهمانی: سم از پیش ساخته‌شده در غذای مانده."],
    ["Correct — a very high infective dose and a contaminated-water pattern; not party food poisoning.",
     "Transmitted by eggs, poultry and dairy, and a classic cause of foodborne outbreaks.",
     "Has a very low infective dose, so it transmits readily through handled food.",
     "The most classic party food poisoning: preformed toxin in food left standing."],
    "**وبا میلیون‌ها ارگانیسم می‌خواهد، چون اسید معده بیشترشان را می‌کشد.**",
    "Cholera needs millions of organisms, because gastric acid kills most of them.",
    REFS)

add("book:298", "recall", "easy",
    "**خنک کردن آهسته و ماندن در دمای اتاق: سازوکار دقیق مسمومیت با سم استاف.**",
    "Slow cooling and standing at room temperature: the exact mechanism of staphylococcal toxin poisoning.",
    FP_FA + [
        "**این سؤال سازوکار را می‌پرسد، نه تابلو را.**",
        "**غذای پخته، باکتری‌های زنده‌ی کمی دارد چون پخت آن‌ها را کشته است.**",
        "**ولی اگر آهسته خنک شود و در دمای اتاق بماند، دوباره آلوده می‌شود.**",
        "⚠️ **منبع آلودگی معمولاً دست‌های آشپز است: استاف روی پوست انسان زندگی می‌کند.**",
        "**استاف در دمای اتاق تکثیر می‌شود و در همان غذا سم می‌سازد.**",
        "**و اینجاست که نکته‌ی کلیدی می‌آید: سم استاف مقاوم به حرارت است.**",
        "**پس حتی اگر غذا را دوباره خوب گرم کنید، باکتری می‌میرد ولی سم می‌ماند.**",
        "⚠️ **به همین دلیل «دوباره گرم کردن» غذای مانده، ایمنی نمی‌آورد.**",
        "**و به همین دلیل نهفتگی کوتاه است: سم آماده بلعیده می‌شود.**",
    ],
    FP_EN + [
        "This question asks about the MECHANISM, not the clinical picture.",
        "Cooked food has few live bacteria, because cooking killed them.",
        "But if it cools slowly and stands at room temperature, it is recontaminated.",
        "WARNING, THE SOURCE OF CONTAMINATION IS USUALLY THE COOK'S HANDS: Staph lives on human skin.",
        "Staph multiplies at room temperature and makes its toxin in the food itself.",
        "And here comes the key point: STAPHYLOCOCCAL TOXIN IS HEAT STABLE.",
        "So even if the food is thoroughly reheated, the bacterium dies but the toxin survives.",
        "WARNING, THIS IS WHY REHEATING LEFTOVERS DOES NOT MAKE THEM SAFE.",
        "And it is why the incubation is short: the toxin is swallowed ready-made.",
    ],
    "این سؤال **سازوکار** را می‌پرسد، و پاسخ آن یکی از کاربردی‌ترین نکات این فصل است.\n\n"
    "**سؤال: خنک کردن آهسته‌ی غذاها و نگهداری آن‌ها در دمای اتاق باعث کدام نوع مسمومیت "
    "غذایی می‌شود؟**\n\n"
    "⚠️ **پاسخ: اسهال‌های انتروتوکسینی، نظیر استاف اورئوس.**\n\n"
    "**زنجیره را قدم به قدم دنبال کنید:**\n\n"
    "**قدم یک — غذا پخته می‌شود.** حرارت پخت **باکتری‌های زنده را می‌کشد**، پس غذای تازه‌پخته "
    "نسبتاً امن است.\n\n"
    "**قدم دو — غذا آلوده می‌شود.** پس از پخت، غذا با **دست‌های فردی که آن را جابه‌جا می‌کند** "
    "تماس پیدا می‌کند. ⚠️ **و استاف اورئوس روی پوست و در بینی انسان زندگی می‌کند** — حدود "
    "۳۰ درصد افراد سالم ناقل بینی آن هستند. پس منبع آلودگی، خودِ آشپز است.\n\n"
    "**قدم سه — غذا آهسته خنک می‌شود و در دمای اتاق می‌ماند.** این **بهترین شرایط رشد** "
    "برای استاف است. باکتری تکثیر می‌شود و **در همان غذا انتروتوکسین می‌سازد**.\n\n"
    "⚠️ **قدم چهار — و اینجا نکته‌ی حیاتی: انتروتوکسین استاف مقاوم به حرارت است.** حتی "
    "جوشاندن هم آن را از بین نمی‌برد. پس **دوباره گرم کردن غذا، باکتری را می‌کشد ولی سم را "
    "نه** — و همان سم است که بیماری را می‌سازد.\n\n"
    "**قدم پنج — سم آماده بلعیده می‌شود**، پس نیازی به رشد باکتری در بدن نیست. **نهفتگی کوتاه "
    "است: ۱ تا ۶ ساعت.** و چون سم مستقیماً مرکز استفراغ را در مغز تحریک می‌کند، **استفراغ "
    "علامت غالب** است.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**اسهال‌های التهابی نظیر سالمونلا:** سالمونلا **باکتری زنده‌ای است که باید بلعیده شود "
    "و در روده تهاجم کند**. حرارت پخت آن را می‌کشد. مسئله‌ی آن **پخت ناکافی** است، نه خنک "
    "کردن آهسته.\n\n"
    "**اسهال‌های خونی نظیر شیگلا:** انتقال آن عمدتاً **مدفوعی-دهانی و از فرد به فرد** است، "
    "نه از غذای مانده در دمای اتاق.\n\n"
    "**اسهال ناشی از اسپور مثل کلستریدیوم:** این **نزدیک‌ترین رقیب** است، چون پرفرانژنس هم "
    "با غذای مانده مرتبط است. ولی سازوکار آن متفاوت است: **اسپورها از پخت جان سالم به در "
    "می‌برند، در غذای در حال خنک شدن جوانه می‌زنند، و سم در روده ساخته می‌شود** — نه از پیش "
    "در غذا. به همین دلیل نهفتگی آن طولانی‌تر است (**۸ تا ۱۶ ساعت**) و **اسهال غالب است نه "
    "استفراغ**. سؤال صریحاً «انتروتوکسین» را در گزینه‌ی درست آورده که به سم **از پیش "
    "ساخته‌شده** اشاره دارد.",
    "This question asks about MECHANISM, and its answer is one of the most practically useful points "
    "in the chapter.\n\n"
    "THE QUESTION: slow cooling of food and keeping it at room temperature causes which type of food "
    "poisoning?\n\n"
    "WARNING, THE ANSWER: ENTEROTOXIN DIARRHOEAS, SUCH AS STAPH AUREUS.\n\n"
    "FOLLOW THE CHAIN STEP BY STEP:\n\n"
    "STEP ONE — THE FOOD IS COOKED. The heat of cooking KILLS LIVE BACTERIA, so freshly cooked food is "
    "relatively safe.\n\n"
    "STEP TWO — THE FOOD IS CONTAMINATED. After cooking it comes into contact with THE HANDS OF WHOEVER "
    "HANDLES IT. WARNING, AND STAPH AUREUS LIVES ON HUMAN SKIN AND IN THE NOSE — about 30% of healthy "
    "people are nasal carriers. So the source of contamination is the cook.\n\n"
    "STEP THREE — THE FOOD COOLS SLOWLY AND STANDS AT ROOM TEMPERATURE. These are IDEAL GROWTH "
    "CONDITIONS for Staph. The bacterium multiplies and MAKES ITS ENTEROTOXIN IN THE FOOD ITSELF.\n\n"
    "WARNING, STEP FOUR — AND HERE IS THE VITAL POINT: STAPHYLOCOCCAL ENTEROTOXIN IS HEAT STABLE. Even "
    "boiling does not destroy it. So REHEATING THE FOOD KILLS THE BACTERIUM BUT NOT THE TOXIN — and it "
    "is the toxin that causes the illness.\n\n"
    "STEP FIVE — THE TOXIN IS SWALLOWED READY-MADE, so no bacterial growth in the body is needed. THE "
    "INCUBATION IS SHORT: 1 TO 6 HOURS. And because the toxin stimulates the vomiting centre in the "
    "brain directly, VOMITING IS THE DOMINANT SYMPTOM.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "INFLAMMATORY DIARRHOEAS SUCH AS SALMONELLA: Salmonella is A LIVE BACTERIUM THAT MUST BE SWALLOWED "
    "AND INVADE THE BOWEL. Cooking heat kills it. Its problem is UNDERCOOKING, not slow cooling.\n\n"
    "BLOODY DIARRHOEAS SUCH AS SHIGELLA: its transmission is mainly FAECAL-ORAL AND PERSON TO PERSON, "
    "not from food standing at room temperature.\n\n"
    "SPORE-RELATED DIARRHOEA SUCH AS CLOSTRIDIUM: this is THE CLOSEST COMPETITOR, since perfringens is "
    "also associated with food left standing. But its mechanism differs: THE SPORES SURVIVE COOKING, "
    "GERMINATE IN THE COOLING FOOD, AND THE TOXIN IS MADE IN THE GUT — not preformed in the food. That "
    "is why its incubation is longer (8 TO 16 HOURS) and DIARRHOEA RATHER THAN VOMITING DOMINATES. The "
    "question explicitly says 'enterotoxin' in the correct option, which points to PREFORMED toxin.",
    ["پاسخ صحیح — استاف در غذای مانده رشد می‌کند و سم مقاوم به حرارت می‌سازد.",
     "سالمونلا باکتری زنده‌ای است که تهاجم می‌کند؛ مسئله‌ی آن پخت ناکافی است نه خنک کردن آهسته.",
     "انتقال شیگلا عمدتاً مدفوعی-دهانی و از فرد به فرد است، نه از غذای مانده.",
     "نزدیک‌ترین رقیب، ولی سم پرفرانژنس در روده ساخته می‌شود نه از پیش در غذا."],
    ["Correct — Staph grows in standing food and makes a heat-stable toxin.",
     "Salmonella is a live invading bacterium; its problem is undercooking, not slow cooling.",
     "Shigella transmits mainly faecal-orally and person to person, not from standing food.",
     "The closest competitor, but perfringens toxin is made in the gut, not preformed in the food."],
    "**سم استاف مقاوم به حرارت است — پس دوباره گرم کردن غذا آن را ایمن نمی‌کند.**",
    "Staph toxin is heat stable — so reheating the food does not make it safe.",
    REFS)

add("book:299", "vignette", "easy",
    "**چهار ساعت پس از جشن تولد، با علائم مشترک: استاف اورئوس.**",
    "Four hours after a birthday party, with shared symptoms: STAPH AUREUS.",
    FP_FA + [
        "**سه سرنخ در این سؤال به یک پاسخ می‌رسند.**",
        "**سرنخ یک: فاصله‌ی چهار ساعت — یعنی سم از پیش ساخته‌شده.**",
        "**سرنخ دو: علائم مشابه در سایر مهمانان — یعنی منبع غذایی مشترک.**",
        "⚠️ **سرنخ سه: تهوع و استفراغ در کنار اسهال — یعنی استفراغ برجسته است.**",
        "**و استفراغ برجسته، امضای سم استاف است.**",
        "**چرا؟ چون سم استاف مستقیماً مرکز استفراغ را در مغز تحریک می‌کند.**",
        "**یعنی اثر آن عصبی-مرکزی است، نه فقط موضعی در روده.**",
        "**جشن تولد هم منبع کلاسیک را می‌رساند: کیک خامه‌ای، سالاد، سس مایونز.**",
    ],
    FP_EN + [
        "Three clues in this question converge on one answer.",
        "CLUE ONE: the four-hour interval — meaning preformed toxin.",
        "CLUE TWO: similar symptoms in the other guests — meaning a shared food source.",
        "WARNING, CLUE THREE: nausea and vomiting alongside the diarrhoea — vomiting is prominent.",
        "And prominent vomiting is the signature of staphylococcal toxin.",
        "Why? Because Staph toxin stimulates the vomiting centre in the brain DIRECTLY.",
        "That is, its action is central and neural, not merely local in the bowel.",
        "A birthday party also suggests the classic source: cream cake, salad, mayonnaise.",
    ],
    "این سؤال با **حساب کردن ساعت** حل می‌شود.\n\n"
    "**بیمار: دختر ۷ ساله، حدود ۴ ساعت پس از بازگشت از جشن تولد، با اسهال، تهوع و استفراغ. "
    "علائم مشابه در سایر دوستان او در جشن هم دیده می‌شود.**\n\n"
    "**سه سرنخ، همه به یک پاسخ:**\n\n"
    "⚠️ **سرنخ یک — فاصله‌ی ۴ ساعت.** این در بازه‌ی **۱ تا ۶ ساعت** است، یعنی **سم از پیش "
    "ساخته‌شده**. هیچ باکتری‌ای فرصت نداشته در بدن رشد کند؛ **سم آماده بلعیده شده است**.\n\n"
    "**سرنخ دو — علائم مشابه در سایر مهمانان.** یعنی **منبع غذایی مشترک** — طغیان نقطه‌ای.\n\n"
    "**سرنخ سه — تهوع و استفراغ در کنار اسهال.** **استفراغ برجسته است**، و همین **استاف را "
    "از پرفرانژنس جدا می‌کند**.\n\n"
    "**چرا استفراغ در استاف این‌قدر برجسته است؟** چون **انتروتوکسین استاف یک سوپرآنتی‌ژن "
    "است که مستقیماً مرکز استفراغ را در ساقه‌ی مغز تحریک می‌کند** — اثر آن **عصبی-مرکزی** "
    "است، نه فقط موضعی در روده. به همین دلیل بیمار پیش از آنکه اسهال شدید بگیرد، شدیداً "
    "استفراغ می‌کند.\n\n"
    "**و «جشن تولد» منبع کلاسیک را می‌رساند: کیک خامه‌ای، سالاد الویه، سس مایونز** — غذاهایی "
    "که پس از تهیه مدتی در دمای اتاق می‌مانند.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**سالمونلا:** نهفتگی **۱۲ تا ۷۲ ساعت**. **چهار ساعت بسیار زود است** — سالمونلا باید "
    "بلعیده شود، در روده تکثیر کند و تهاجم کند، و این زمان می‌برد.\n\n"
    "**کامپیلوباکتر:** نهفتگی **۲ تا ۵ روز**. حتی از سالمونلا هم طولانی‌تر.\n\n"
    "⚠️ **کلستریدیوم پرفرانژنس:** نزدیک‌ترین رقیب، ولی **دو تفاوت**: نهفتگی آن **۸ تا ۱۶ "
    "ساعت** است (نه ۴ ساعت)، و **استفراغ در آن کم است** — تابلوی آن **کرامپ شکمی و اسهال "
    "آبکی** است. سؤال هم تهوع و استفراغ را برجسته کرده.",
    "This question is solved BY COUNTING THE HOURS.\n\n"
    "THE PATIENT: a 7-year-old girl brought in about 4 HOURS after returning from a birthday party with "
    "diarrhoea, nausea and vomiting. Similar symptoms are seen in her friends from the party.\n\n"
    "THREE CLUES, ALL TO ONE ANSWER:\n\n"
    "WARNING, CLUE ONE — THE 4-HOUR INTERVAL. That is within the 1 TO 6 HOUR window, meaning PREFORMED "
    "TOXIN. No bacterium has had time to grow in the body; THE TOXIN WAS SWALLOWED READY-MADE.\n\n"
    "CLUE TWO — SIMILAR SYMPTOMS IN THE OTHER GUESTS. That means A SHARED FOOD SOURCE — a point-source "
    "outbreak.\n\n"
    "CLUE THREE — NAUSEA AND VOMITING alongside the diarrhoea. VOMITING IS PROMINENT, and that "
    "SEPARATES STAPH FROM PERFRINGENS.\n\n"
    "WHY IS VOMITING SO PROMINENT WITH STAPH? Because STAPHYLOCOCCAL ENTEROTOXIN IS A SUPERANTIGEN THAT "
    "STIMULATES THE VOMITING CENTRE IN THE BRAINSTEM DIRECTLY — its action is CENTRAL AND NEURAL, not "
    "merely local in the bowel. That is why the patient vomits severely before the diarrhoea becomes "
    "prominent.\n\n"
    "AND 'A BIRTHDAY PARTY' POINTS TO THE CLASSIC SOURCE: cream cake, potato salad, mayonnaise — foods "
    "that stand at room temperature after preparation.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "SALMONELLA: incubation 12 TO 72 HOURS. FOUR HOURS IS FAR TOO EARLY — Salmonella must be swallowed, "
    "multiply in the bowel and invade, and that takes time.\n\n"
    "CAMPYLOBACTER: incubation 2 TO 5 DAYS. Longer even than Salmonella.\n\n"
    "WARNING, CLOSTRIDIUM PERFRINGENS: the closest competitor, but TWO DIFFERENCES: its incubation is 8 "
    "TO 16 HOURS (not 4), and VOMITING IS UNCOMMON WITH IT — its picture is ABDOMINAL CRAMPS AND WATERY "
    "DIARRHOEA. The question emphasises nausea and vomiting.",
    ["نهفتگی ۱۲ تا ۷۲ ساعت دارد؛ چهار ساعت برای تهاجم و تکثیر آن بسیار زود است.",
     "نهفتگی ۲ تا ۵ روز دارد، حتی از سالمونلا هم طولانی‌تر.",
     "پاسخ صحیح — نهفتگی ۱ تا ۶ ساعت با استفراغ برجسته، از سم از پیش ساخته‌شده.",
     "نهفتگی ۸ تا ۱۶ ساعت دارد و استفراغ در آن کم است؛ تابلویش کرامپ و اسهال آبکی است."],
    ["Incubation 12 to 72 hours; four hours is far too early for it to invade and multiply.",
     "Incubation 2 to 5 days, longer even than Salmonella.",
     "Correct — a 1 to 6 hour incubation with prominent vomiting, from preformed toxin.",
     "Incubation 8 to 16 hours and vomiting is uncommon; its picture is cramps and watery diarrhoea."],
    "**استفراغ برجسته + چهار ساعت = استاف. کرامپ + دوازده ساعت = پرفرانژنس.**",
    "Prominent vomiting at four hours means Staph. Cramps at twelve hours means perfringens.",
    REFS)

add("book:304", "vignette", "medium",
    "**چهار ساعت پس از سالاد و سس مایونز: فقط مایع‌درمانی — نه کشت، نه آنتی‌بیوتیک.**",
    "Four hours after salad and mayonnaise: REHYDRATION ONLY — no culture, no antibiotic.",
    FP_FA + [
        "**این سؤال دو تصمیم می‌خواهد: تشخیص، و اینکه چه کاری لازم نیست.**",
        "**تشخیص روشن است: سم استاف، از سس مایونز مانده.**",
        "⚠️ **حالا سؤال واقعی: آیا کشت مدفوع لازم است؟ نه.**",
        "**چون بیماری سم‌محور است، نه عفونت زنده.**",
        "**کشت مدفوع باکتری زنده را می‌جوید، و اینجا باکتری در بدن تکثیر نکرده است.**",
        "**پس کشت مثبت هم نمی‌شود، و اگر بشود هم درمان را عوض نمی‌کند.**",
        "⚠️ **و آنتی‌بیوتیک؟ سم را از بین نمی‌برد. بیماری تا تخلیه‌ی سم ادامه دارد.**",
        "**مسمومیت با سم استاف خودمحدود است و ظرف ۲۴ تا ۴۸ ساعت خوب می‌شود.**",
        "**پس درمان: فقط جبران آب و الکترولیت.**",
        "**استثنا فقط جنبه‌ی بهداشت عمومی است: در طغیان، بررسی منبع لازم است.**",
    ],
    FP_EN + [
        "This question wants two decisions: the diagnosis, and what is NOT needed.",
        "The diagnosis is clear: staphylococcal toxin, from standing mayonnaise.",
        "WARNING, NOW THE REAL QUESTION: is a stool culture needed? NO.",
        "Because this is a toxin-mediated illness, not a live infection.",
        "A stool culture looks for a live bacterium, and here none has multiplied in the body.",
        "So the culture will not be positive, and if it were it would not change treatment.",
        "WARNING, AND ANTIBIOTICS? They do not destroy the toxin. The illness lasts until the toxin clears.",
        "Staphylococcal toxin poisoning is self-limited and settles within 24 to 48 hours.",
        "So the treatment is: fluid and electrolyte replacement only.",
        "The only exception is a public health one: in an outbreak the source must be investigated.",
    ],
    "این سؤال از قبلی یک قدم جلوتر می‌رود: **تشخیص را می‌داند و می‌پرسد چه کاری لازم نیست.**\n\n"
    "**موقعیت: تعدادی از دانشجویان خوابگاه، ۴ ساعت پس از خوردن سالاد کاهو و تخم‌مرغ حاوی سس "
    "مایونز، دچار اسهال آبکی، تهوع و استفراغ بدون درد شکم شده‌اند.**\n\n"
    "**تشخیص فوری است:** **۴ ساعت** + **سس مایونز** + **استفراغ برجسته** + **طغیان گروهی** "
    "= **مسمومیت با انتروتوکسین استاف اورئوس**.\n\n"
    "⚠️ **حالا سؤال واقعی: آیا کشت مدفوع لازم است؟ پاسخ: نه — و دلیلش مفهومی است.**\n\n"
    "**کشت مدفوع، باکتری زنده را می‌جوید.** ولی این بیماری **سم‌محور** است: باکتری در **غذا** "
    "رشد کرده و سم ساخته، و آنچه بیمار بلعیده **سم آماده** بوده. **هیچ باکتری‌ای در روده‌ی "
    "بیمار تکثیر نکرده است.** پس کشت مدفوع:\n\n"
    "**احتمالاً منفی می‌شود** (چون باکتری زنده‌ای در مدفوع نیست)، **زمان می‌برد** (۴۸ تا ۷۲ "
    "ساعت، در حالی که بیماری تا آن زمان تمام شده)، و **حتی اگر مثبت شود، درمان را عوض "
    "نمی‌کند**.\n\n"
    "**قاعده‌ی کلی: آزمونی که نتیجه‌اش تصمیم را عوض نمی‌کند، ارزش انجام دادن ندارد.**\n\n"
    "⚠️ **و آنتی‌بیوتیک؟ کاملاً بی‌فایده.** آنتی‌بیوتیک **باکتری** را می‌کشد، ولی مشکل بیمار "
    "**سمی است که از قبل بلعیده شده**. آنتی‌بیوتیک سم را از بین نمی‌برد. بیماری تا زمانی که "
    "سم دفع شود ادامه دارد — و این **خودبه‌خود ظرف ۲۴ تا ۴۸ ساعت** رخ می‌دهد.\n\n"
    "**پس درمان: فقط مایع‌درمانی.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**کشت مدفوع و مایع‌درمانی:** مایع‌درمانی درست است، ولی کشت **اضافه و بی‌فایده** است.\n\n"
    "**آزمایش مستقیم و کشت مدفوع:** دو آزمون بی‌فایده، و **مایع‌درمانی که جزء اصلی درمان است "
    "اصلاً ذکر نشده**.\n\n"
    "**آزمایش مستقیم مدفوع و شروع سیپروفلوکساسین:** ⚠️ **بدترین گزینه.** آنتی‌بیوتیک در "
    "بیماری سم‌محور **هیچ سودی ندارد** و فقط عوارض دارویی، اختلال فلور روده و فشار انتخابی "
    "مقاومت اضافه می‌کند.\n\n"
    "**تنها استثنا، جنبه‌ی بهداشت عمومی است:** در یک **طغیان خوابگاهی**، بررسی منبع غذا و "
    "آموزش کارکنان آشپزخانه لازم است — ولی این اقدام **بهداشتی** است، نه بخشی از درمان "
    "این بیماران.",
    "This question goes one step beyond the previous one: IT KNOWS THE DIAGNOSIS AND ASKS WHAT IS NOT "
    "NEEDED.\n\n"
    "THE SITUATION: several students in a hall of residence develop watery diarrhoea, nausea and "
    "vomiting without abdominal pain 4 HOURS after eating lettuce and egg salad with mayonnaise.\n\n"
    "THE DIAGNOSIS IS IMMEDIATE: 4 HOURS plus MAYONNAISE plus PROMINENT VOMITING plus A GROUP OUTBREAK "
    "= STAPHYLOCOCCAL ENTEROTOXIN POISONING.\n\n"
    "WARNING, NOW THE REAL QUESTION: is a stool culture needed? THE ANSWER IS NO — and the reason is "
    "conceptual.\n\n"
    "A STOOL CULTURE LOOKS FOR A LIVE BACTERIUM. But this is a TOXIN-MEDIATED illness: the bacterium "
    "grew IN THE FOOD and made its toxin there, and what the patient swallowed was READY-MADE TOXIN. NO "
    "BACTERIUM HAS MULTIPLIED IN THE PATIENT'S BOWEL. So the stool culture:\n\n"
    "WILL PROBABLY BE NEGATIVE (there is no live bacterium in the stool), TAKES TIME (48 to 72 hours, "
    "by which point the illness is over), and EVEN IF POSITIVE WOULD NOT CHANGE TREATMENT.\n\n"
    "THE GENERAL RULE: A TEST WHOSE RESULT DOES NOT CHANGE THE DECISION IS NOT WORTH DOING.\n\n"
    "WARNING, AND ANTIBIOTICS? Completely useless. An antibiotic kills THE BACTERIUM, but the patient's "
    "problem is A TOXIN ALREADY SWALLOWED. Antibiotics do not destroy the toxin. The illness continues "
    "until the toxin is cleared — and that happens SPONTANEOUSLY WITHIN 24 TO 48 HOURS.\n\n"
    "SO THE TREATMENT: REHYDRATION ONLY.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "STOOL CULTURE AND REHYDRATION: the rehydration is right, but the culture is SUPERFLUOUS AND USELESS.\n\n"
    "DIRECT EXAMINATION AND STOOL CULTURE: two useless tests, and REHYDRATION, THE MAIN COMPONENT OF "
    "TREATMENT, IS NOT MENTIONED AT ALL.\n\n"
    "DIRECT STOOL EXAMINATION AND STARTING CIPROFLOXACIN: WARNING, THE WORST OPTION. An antibiotic in a "
    "toxin-mediated illness HAS NO BENEFIT WHATSOEVER and merely adds drug toxicity, disruption of the "
    "bowel flora and selective pressure for resistance.\n\n"
    "THE ONLY EXCEPTION IS A PUBLIC HEALTH ONE: in a HALL-OF-RESIDENCE OUTBREAK the food source must be "
    "investigated and the kitchen staff educated — but that is a PUBLIC HEALTH measure, not part of "
    "these patients' treatment.",
    ["مایع‌درمانی درست است ولی کشت مدفوع در بیماری سم‌محور اضافه و بی‌فایده است.",
     "پاسخ صحیح — بیماری سم‌محور و خودمحدود است؛ فقط جبران آب و الکترولیت لازم است.",
     "دو آزمون بی‌فایده، و مایع‌درمانی که جزء اصلی درمان است اصلاً ذکر نشده.",
     "بدترین گزینه — آنتی‌بیوتیک سم را از بین نمی‌برد و فقط عارضه اضافه می‌کند."],
    ["The rehydration is right but a stool culture in a toxin-mediated illness is superfluous.",
     "Correct — the illness is toxin-mediated and self-limited; only fluid replacement is needed.",
     "Two useless tests, and rehydration, the main component of treatment, is not mentioned.",
     "The worst option — antibiotics do not destroy the toxin and merely add harm."],
    "**آزمونی که تصمیم را عوض نمی‌کند، ارزش انجام دادن ندارد.**",
    "A test that does not change the decision is not worth doing.",
    REFS)

# ================================================ THE ACUTE DIARRHOEA ALGORITHM
ALG_FA = [
    "⚠️ **بیشتر اسهال‌های حاد آبکی فقط مایع می‌خواهند — نه آزمایش، نه آنتی‌بیوتیک.**",
    "**قاعده را به‌صورت دو شاخه حفظ کنید.**",
    "**شاخه‌ی یک: بیمار پایدار، مدفوع آبکی، بدون خون، بدون تب، سابقه‌ی کوتاه.**",
    "**اقدام: فقط هیدراتاسیون. نه کشت، نه آنتی‌بیوتیک.**",
    "**چون بیشتر این موارد ویروسی یا سم‌محور و خودمحدودند.**",
    "⚠️ **شاخه‌ی دو: دیسانتری — خون، تب، و گلبول سفید مدفوع.**",
    "**اقدام: هم مایع و هم درمان؛ در بزرگ‌سال فلوروکینولون به‌صورت تجربی.**",
    "**و در هر دو شاخه، جبران آب و الکترولیت مهم‌ترین اقدام است.**",
    "**چون علت مرگ در اسهال، دهیدراتاسیون است، نه خودِ عفونت.**",
    "⚠️ **و داروی ضدحرکت روده در اسهال التهابی ممنوع است.**",
    "**لوپرامید و دیفنوکسیلات حرکت روده را کند می‌کنند.**",
    "**نتیجه: تماس مخاط با ارگانیسم و سم آن طولانی‌تر می‌شود.**",
    "**و این می‌تواند به مگاکولون توکسیک برسد.**",
    "**پس در هر اسهالی که خون یا تب دارد، ضدحرکت ممنوع است.**",
]
ALG_EN = [
    "WARNING: MOST ACUTE WATERY DIARRHOEA NEEDS ONLY FLUID — no test, no antibiotic.",
    "Memorise the rule as two branches.",
    "BRANCH ONE: a stable patient, watery stool, no blood, no fever, a short history.",
    "Action: HYDRATION ONLY. No culture, no antibiotic.",
    "Because most such cases are viral or toxin-mediated and self-limited.",
    "WARNING, BRANCH TWO: DYSENTERY — blood, fever, and stool white cells.",
    "Action: fluid AND treatment; in an adult, an empirical fluoroquinolone.",
    "And in both branches, fluid and electrolyte replacement is the most important step.",
    "Because what kills in diarrhoea is DEHYDRATION, not the infection itself.",
    "WARNING, AND ANTIMOTILITY DRUGS ARE CONTRAINDICATED IN INFLAMMATORY DIARRHOEA.",
    "Loperamide and diphenoxylate slow the bowel.",
    "The result: mucosal contact with the organism and its toxin is prolonged.",
    "And that can progress to toxic megacolon.",
    "So in any diarrhoea with blood or fever, antimotility agents are forbidden.",
]

add("book:305", "recall", "easy",
    "**اسهال آبکی دو ساعته با علائم حیاتی پایدار: فقط هیدراته کنید.**",
    "Two hours of watery diarrhoea with stable vital signs: just hydrate.",
    ALG_FA,
    ALG_EN,
    "این سؤال **ساده‌ترین شکل الگوریتم** را می‌سنجد، و بیشترین خطای بالینی هم در همین‌جا "
    "رخ می‌دهد: **درمان بیش‌ازحد**.\n\n"
    "**بیمار: دو ساعت است که دچار اسهال آبکی شده و علائم حیاتی پایدار است.**\n\n"
    "**چهار چیز را از این جمله‌ی کوتاه بگیرید:**\n\n"
    "**آبکی** — یعنی **غیرالتهابی**، بدون خون. **دو ساعت** — یعنی **بسیار حاد و کوتاه**. "
    "**علائم حیاتی پایدار** — یعنی **نه شوک، نه دهیدراتاسیون شدید**. و **هیچ تبی ذکر نشده**.\n\n"
    "⚠️ **پس این شاخه‌ی اول الگوریتم است: فقط هیدراتاسیون.**\n\n"
    "**چرا آزمایش نمی‌کنیم؟** چون **بیشتر اسهال‌های حاد آبکی، ویروسی یا سم‌محور و خودمحدودند** "
    "و ظرف ۲۴ تا ۷۲ ساعت خودبه‌خود خوب می‌شوند. کشت مدفوع **۴۸ تا ۷۲ ساعت** طول می‌کشد — "
    "یعنی جواب وقتی می‌رسد که بیمار خوب شده است. **آزمونی که پس از پایان بیماری جواب می‌دهد، "
    "تصمیمی را عوض نمی‌کند.**\n\n"
    "**آزمایش کِی لازم است؟** وقتی **خون در مدفوع** باشد، **تب بالا**، **دهیدراتاسیون شدید**، "
    "**اسهال بیش از هفت روز**، **نقص ایمنی**، یا **سابقه‌ی مصرف آنتی‌بیوتیک اخیر**.\n\n"
    "**چرا آنتی‌بیوتیک نمی‌دهیم؟** چون عامل احتمالاً ویروسی یا سم‌محور است، و آنتی‌بیوتیک "
    "**سود ندارد** ولی **زیان دارد**: عوارض دارویی، اختلال فلور طبیعی روده (که خودش می‌تواند "
    "به کلستریدیوم دیفیسیل برسد)، و فشار انتخابی برای مقاومت.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**کشت مدفوع + هیدراته کردن تا آمدن جواب:** هیدراتاسیون درست است ولی **کشت بی‌مورد** است.\n\n"
    "**آنالیز مدفوع و آنتی‌بیوتیک بر اساس آن:** **دو اشتباه**. آنالیز لازم نیست، و آنتی‌بیوتیک "
    "هم نه.\n\n"
    "⚠️ **کینولون‌ها برای درمان:** **بدترین گزینه.** در بیمار پایدار با اسهال آبکی دوساعته، "
    "فلوروکینولون **سود صفر** و **زیان واقعی** دارد. (و یادآوری مهم: در اسهال خونی مشکوک به "
    "EHEC، آنتی‌بیوتیک می‌تواند **خطر HUS را افزایش دهد**.)\n\n"
    "**و نکته‌ی حیاتی که همیشه باید گفته شود: علت مرگ در اسهال، دهیدراتاسیون است نه خودِ "
    "عفونت.** پس هیدراتاسیون، **درمان اصلی** است، نه اقدام حمایتی درجه دو.",
    "This question tests THE SIMPLEST FORM OF THE ALGORITHM, and it is where the commonest clinical "
    "error occurs: OVERTREATMENT.\n\n"
    "THE PATIENT: has had watery diarrhoea for two hours and his vital signs are stable.\n\n"
    "TAKE FOUR THINGS FROM THAT SHORT SENTENCE:\n\n"
    "WATERY — meaning NON-INFLAMMATORY, no blood. TWO HOURS — meaning VERY ACUTE AND SHORT. STABLE "
    "VITAL SIGNS — meaning NO SHOCK AND NO SEVERE DEHYDRATION. And NO FEVER IS MENTIONED.\n\n"
    "WARNING, SO THIS IS BRANCH ONE OF THE ALGORITHM: HYDRATION ONLY.\n\n"
    "WHY NO TESTS? Because MOST ACUTE WATERY DIARRHOEA IS VIRAL OR TOXIN-MEDIATED AND SELF-LIMITED, "
    "settling on its own within 24 to 72 hours. A stool culture takes 48 TO 72 HOURS — so the result "
    "arrives after the patient has recovered. A TEST THAT REPORTS AFTER THE ILLNESS HAS ENDED CHANGES "
    "NO DECISION.\n\n"
    "WHEN IS TESTING NEEDED? When there is BLOOD IN THE STOOL, HIGH FEVER, SEVERE DEHYDRATION, "
    "DIARRHOEA LASTING MORE THAN SEVEN DAYS, IMMUNODEFICIENCY, or RECENT ANTIBIOTIC USE.\n\n"
    "WHY NO ANTIBIOTIC? Because the cause is probably viral or toxin-mediated, and an antibiotic HAS NO "
    "BENEFIT but DOES HAVE HARMS: drug toxicity, disruption of the normal bowel flora (which can itself "
    "lead to C. difficile), and selective pressure for resistance.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "STOOL CULTURE AND HYDRATION UNTIL THE RESULT: the hydration is right but the CULTURE IS "
    "UNNECESSARY.\n\n"
    "STOOL ANALYSIS AND AN ANTIBIOTIC BASED ON IT: TWO MISTAKES. The analysis is not needed, and "
    "neither is the antibiotic.\n\n"
    "WARNING, QUINOLONES FOR TREATMENT: THE WORST OPTION. In a stable patient with two hours of watery "
    "diarrhoea, a fluoroquinolone offers ZERO BENEFIT and REAL HARM. (And an important reminder: in "
    "bloody diarrhoea with suspected EHEC, antibiotics can INCREASE THE RISK OF HUS.)\n\n"
    "AND THE VITAL POINT THAT MUST ALWAYS BE MADE: WHAT KILLS IN DIARRHOEA IS DEHYDRATION, NOT THE "
    "INFECTION. So hydration is THE MAIN TREATMENT, not a second-order supportive measure.",
    ["هیدراتاسیون درست است ولی کشت مدفوع در این بیمار بی‌مورد است و جوابش دیر می‌رسد.",
     "دو اشتباه — نه آنالیز لازم است و نه آنتی‌بیوتیک.",
     "پاسخ صحیح — بیمار پایدار با اسهال آبکی کوتاه، فقط هیدراتاسیون می‌خواهد.",
     "بدترین گزینه — فلوروکینولون در این بیمار سود صفر و زیان واقعی دارد."],
    ["Hydration is right but a stool culture is unnecessary here and reports too late.",
     "Two mistakes — neither the analysis nor the antibiotic is needed.",
     "Correct — a stable patient with short watery diarrhoea needs hydration only.",
     "The worst option — a fluoroquinolone here has zero benefit and real harm."],
    "**در اسهال، دهیدراتاسیون می‌کشد نه عفونت — پس مایع، درمان اصلی است.**",
    "In diarrhoea it is dehydration that kills, not the infection — so fluid is the main treatment.",
    REFS)

add("book:303", "vignette", "medium",
    "**افت فشار وضعیتی یعنی کاهش حجم شدید: اصلاح آب و الکترولیت، مهم‌ترین اقدام.**",
    "Postural hypotension means severe volume depletion: fluid and electrolyte correction is the priority.",
    ALG_FA + [
        "**در این بیمار یک اندازه‌گیری، همه‌چیز را می‌گوید: فشار خوابیده در برابر نشسته.**",
        "**خوابیده ۱۳۰ روی ۷۰ با نبض ۱۱۰؛ نشسته ۱۰۰ روی ۴۰.**",
        "⚠️ **افت سیستولیک ۳۰ میلی‌متر با تغییر وضعیت یعنی هیپوتانسیون اورتواستاتیک.**",
        "**و هیپوتانسیون اورتواستاتیک، نشانه‌ی کاهش حجم داخل عروقی چشمگیر است.**",
        "**تاکی‌کاردی ۱۱۰ هم همان را از جهت دیگری تأیید می‌کند.**",
        "**پس بیمار دهیدراته است و این خطر فوری اوست، نه خودِ اسهال.**",
        "**و مدفوع آبکی با حجم زیاد و بدون تب، غیرالتهابی است.**",
        "**آزمایش مدفوع هم نکته‌ی خاصی ندارد، که همین را تأیید می‌کند.**",
        "⚠️ **پس نه آنتی‌بیوتیک جایی دارد، نه داروی ضدحرکت.**",
    ],
    ALG_EN + [
        "In this patient one measurement says everything: the lying versus sitting blood pressure.",
        "Lying 130/70 with a pulse of 110; sitting 100/40.",
        "WARNING, A 30 mmHg SYSTOLIC DROP ON POSTURAL CHANGE means orthostatic hypotension.",
        "And orthostatic hypotension indicates substantial intravascular volume loss.",
        "The tachycardia of 110 confirms the same thing from another direction.",
        "So the patient is dehydrated, and that is her immediate danger, not the diarrhoea itself.",
        "And a large-volume watery stool without fever is non-inflammatory.",
        "The stool examination shows nothing of note, which confirms it.",
        "WARNING, SO NEITHER AN ANTIBIOTIC NOR AN ANTIMOTILITY AGENT HAS A PLACE.",
    ],
    "این سؤال یک **مهارت بالینی** را می‌سنجد: خواندن علائم حیاتی وضعیتی.\n\n"
    "**بیمار: خانم ۶۰ ساله، دو روز است روزانه ۷ تا ۸ بار مدفوع آبکی با حجم زیاد دارد که به "
    "ضعف شدید منجر شده. تب نداشته و ندارد. هوشیار است. فشار خوابیده ۱۳۰/۷۰ با نبض ۱۱۰؛ فشار "
    "نشسته ۱۰۰/۴۰. آزمایش مدفوع نکته‌ی خاصی ندارد.**\n\n"
    "⚠️ **کلید سؤال در دو عدد است: فشار خوابیده در برابر نشسته.**\n\n"
    "**۱۳۰ خوابیده → ۱۰۰ نشسته.** یعنی **افت سیستولیک ۳۰ میلی‌متر جیوه با تغییر وضعیت** — "
    "و این تعریف **هیپوتانسیون اورتواستاتیک** است (افت ≥۲۰ سیستولیک یا ≥۱۰ دیاستولیک).\n\n"
    "**این یافته چه معنایی دارد؟** یعنی **حجم داخل عروقی به‌طور چشمگیری کم شده است**. وقتی "
    "بیمار می‌نشیند، خون به پایین می‌رود و بدن نمی‌تواند جبران کند — چون حجم کافی ندارد.\n\n"
    "**و تاکی‌کاردی ۱۱۰ همان را از جهت دیگری تأیید می‌کند:** قلب سعی می‌کند با تندتر زدن، "
    "کاهش حجم ضربه‌ای را جبران کند.\n\n"
    "**پس خطر فوری این بیمار، خودِ اسهال نیست — دهیدراتاسیون است.**\n\n"
    "**و ماهیت اسهال؟** **آبکی با حجم زیاد، بدون تب، و آزمایش مدفوع بدون یافته** = "
    "**غیرالتهابی**. پس جایی برای آنتی‌بیوتیک نیست.\n\n"
    "**پاسخ: اصلاح آب و الکترولیت.** و در این بیمار، با توجه به هیپوتانسیون وضعیتی و سن ۶۰ "
    "سال، **مایع‌درمانی وریدی** ارجح است.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "⚠️ **تجویز داروی ضدحرکت روده:** این **درمان علامتی خطرناک** است. حتی اگر اسهال "
    "غیرالتهابی باشد، **کند کردن روده مشکل اصلی — یعنی کمبود حجم — را حل نمی‌کند** و فقط "
    "علامت را می‌پوشاند. و اگر تشخیص اشتباه باشد و اسهال التهابی از آب دربیاید، **خطر "
    "مگاکولون توکسیک** جدی است.\n\n"
    "**تجویز آنتی‌بیوتیک:** اسهال غیرالتهابی و بدون تب است؛ آنتی‌بیوتیک اندیکاسیون ندارد.\n\n"
    "**ترانسفوزیون خون:** بیمار **کم‌خون نیست** — او **کم‌آب** است. مشکل او **حجم** است، نه "
    "**گلبول قرمز**. دادن خون به بیمار دهیدراته، درمان اشتباه با ریسک انتقال خون است.",
    "This question tests A CLINICAL SKILL: reading postural vital signs.\n\n"
    "THE PATIENT: a 60-year-old woman who for two days has passed 7 to 8 large-volume watery stools "
    "daily, leading to severe weakness. She has had no fever. She is alert. Lying BP 130/70 with a "
    "pulse of 110; sitting BP 100/40. The stool examination shows nothing of note.\n\n"
    "WARNING, THE KEY IS IN TWO NUMBERS: the lying versus the sitting blood pressure.\n\n"
    "130 LYING becomes 100 SITTING. That is A 30 mmHg SYSTOLIC DROP ON POSTURAL CHANGE — and that is "
    "the definition of ORTHOSTATIC HYPOTENSION (a fall of 20 systolic or 10 diastolic or more).\n\n"
    "WHAT DOES THAT FINDING MEAN? That THE INTRAVASCULAR VOLUME IS SUBSTANTIALLY DEPLETED. When she "
    "sits up, blood pools downwards and the body cannot compensate — because there is not enough volume.\n\n"
    "AND THE TACHYCARDIA OF 110 CONFIRMS THE SAME THING FROM ANOTHER DIRECTION: the heart is beating "
    "faster to compensate for a reduced stroke volume.\n\n"
    "SO THIS PATIENT'S IMMEDIATE DANGER IS NOT THE DIARRHOEA — IT IS THE DEHYDRATION.\n\n"
    "AND THE NATURE OF THE DIARRHOEA? LARGE-VOLUME WATERY, NO FEVER, AND AN UNREMARKABLE STOOL "
    "EXAMINATION = NON-INFLAMMATORY. So there is no place for an antibiotic.\n\n"
    "THE ANSWER: CORRECTION OF FLUID AND ELECTROLYTES. And in this patient, given the postural "
    "hypotension and her age of 60, INTRAVENOUS fluid is preferable.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "WARNING, GIVING AN ANTIMOTILITY DRUG: this is DANGEROUS SYMPTOMATIC TREATMENT. Even if the "
    "diarrhoea is non-inflammatory, SLOWING THE BOWEL DOES NOT SOLVE THE REAL PROBLEM — the volume "
    "deficit — and merely masks the symptom. And if the diagnosis is wrong and the diarrhoea proves "
    "inflammatory, THE RISK OF TOXIC MEGACOLON is serious.\n\n"
    "GIVING AN ANTIBIOTIC: the diarrhoea is non-inflammatory and afebrile; there is no indication.\n\n"
    "BLOOD TRANSFUSION: the patient is NOT ANAEMIC — she is DEHYDRATED. Her problem is VOLUME, not RED "
    "CELLS. Transfusing a dehydrated patient is the wrong treatment with all the risks of transfusion.",
    ["درمان علامتی خطرناک — مشکل اصلی کمبود حجم است و کند کردن روده آن را حل نمی‌کند.",
     "پاسخ صحیح — افت فشار وضعیتی یعنی کاهش حجم شدید، و جبران آن اولویت است.",
     "اسهال غیرالتهابی و بدون تب است؛ آنتی‌بیوتیک اندیکاسیون ندارد.",
     "بیمار کم‌خون نیست، کم‌آب است؛ مشکل او حجم است نه گلبول قرمز."],
    ["Dangerous symptomatic treatment — the real problem is volume depletion, which slowing the bowel does not solve.",
     "Correct — postural hypotension means severe volume loss, and replacing it is the priority.",
     "The diarrhoea is non-inflammatory and afebrile; there is no indication for an antibiotic.",
     "The patient is not anaemic, she is dehydrated; her problem is volume, not red cells."],
    "**افت ۲۰ سیستولیک با تغییر وضعیت = هیپوتانسیون اورتواستاتیک = کاهش حجم.**",
    "A 20 mmHg systolic drop on standing = orthostatic hypotension = volume depletion.",
    REFS)

add("book:307", "vignette", "medium",
    "**در اسهال التهابی، داروی ضدحرکت ممنوع است — بقیه‌ی موارد کاربرد دارند.**",
    "In inflammatory diarrhoea, antimotility agents are forbidden — the rest all have a place.",
    ALG_FA + [
        "**این بیمار اسهال التهابی دارد و آزمایش مدفوع آن را قطعی می‌کند.**",
        "**گلبول سفید ۴۰ تا ۵۰ و گلبول قرمز ۱۰ در مدفوع.**",
        "**به‌علاوه تب ۳۸ و مخاطات خشک و نبض ۱۰۰.**",
        "⚠️ **پس سه اقدام لازم است و یکی ممنوع.**",
        "**رینگر لاکتات: جبران حجم در بیمار دهیدراته.**",
        "**او.آر.اس: ادامه‌ی جبران خوراکی، که ستون درمان اسهال است.**",
        "**آنتی‌بیوتیک: در اسهال التهابی با تب، اندیکاسیون دارد.**",
        "**و ممنوع: داروی ضدحرکت روده.**",
        "⚠️ **چون کند کردن روده، تماس مخاط با ارگانیسم و سم را طولانی می‌کند.**",
        "**نتیجه می‌تواند مگاکولون توکسیک و پرفوراسیون باشد.**",
    ],
    ALG_EN + [
        "This patient has inflammatory diarrhoea and the stool examination settles it.",
        "White cells 40 to 50 and red cells 10 in the stool.",
        "Plus a temperature of 38, dry mucous membranes and a pulse of 100.",
        "WARNING, SO THREE MEASURES ARE NEEDED AND ONE IS FORBIDDEN.",
        "Ringer's lactate: volume replacement in a dehydrated patient.",
        "ORS: continued oral replacement, the mainstay of diarrhoea treatment.",
        "An antibiotic: indicated in inflammatory diarrhoea with fever.",
        "And forbidden: an antimotility agent.",
        "WARNING, BECAUSE SLOWING THE BOWEL prolongs mucosal contact with the organism and its toxin.",
        "The result can be toxic megacolon and perforation.",
    ],
    "این سؤال از نوع «همه به‌جز» است و یک **ممنوعیت مهم** را می‌سنجد.\n\n"
    "**بیمار: آقای ۳۰ ساله با اسهال شدید، ضعف و بی‌حالی. در معاینه: تنفس ۲۰، تب ۳۸، فشار "
    "۸۰ با نبض قابل لمس، نبض ۱۰۰، و مخاطات خشک. در آزمایش مدفوع: گلبول سفید ۴۰ تا ۵۰ و "
    "گلبول قرمز ۱۰.**\n\n"
    "**دو چیز را قطعی کنیم:**\n\n"
    "**یک — این اسهال التهابی است.** گلبول سفید ۴۰ تا ۵۰ در مدفوع، همراه با گلبول قرمز و "
    "تب. تهاجم قطعی است.\n\n"
    "**دو — بیمار دهیدراته است.** مخاطات خشک، تاکی‌کاردی ۱۰۰، فشار پایین.\n\n"
    "**پس سه اقدام لازم است:**\n\n"
    "**سرم رینگر لاکتات** — ✔ برای **جبران سریع حجم** در بیمار دهیدراته با فشار پایین. "
    "رینگر لاکتات ترکیب الکترولیتی نزدیک به مایع خارج سلولی دارد و برای این کار مناسب است.\n\n"
    "**او.آر.اس (سرم خوراکی)** — ✔ **ستون درمان اسهال**. پس از تثبیت اولیه، جبران خوراکی "
    "ادامه می‌یابد. او.آر.اس یکی از مؤثرترین مداخلات بهداشت عمومی تاریخ است.\n\n"
    "**آنتی‌بیوتیک** — ✔ در **اسهال التهابی با تب**، درمان تجربی (معمولاً فلوروکینولون در "
    "بزرگ‌سال) اندیکاسیون دارد.\n\n"
    "⚠️ **و ممنوع: آنتی‌موتیلیتی (داروی ضدحرکت روده).**\n\n"
    "**چرا؟ سازوکار زیان را دقیق بفهمید:**\n\n"
    "لوپرامید و دیفنوکسیلات **حرکات دودی روده را کند می‌کنند**. در اسهال غیرالتهابی این فقط "
    "علامت را کم می‌کند. ولی در **اسهال التهابی**، اسهال یک **مکانیسم دفاعی** است: بدن دارد "
    "**ارگانیسم مهاجم و سم آن را بیرون می‌ریزد**.\n\n"
    "**کند کردن روده یعنی:** تماس مخاط با باکتری و سم **طولانی‌تر** می‌شود → **جذب سم بیشتر** "
    "می‌شود → **مدت بیماری طولانی‌تر** می‌شود → و در بدترین حالت، **مگاکولون توکسیک** رخ "
    "می‌دهد: اتساع فلج‌شده‌ی کولون که می‌تواند به **پرفوراسیون و مرگ** برسد.\n\n"
    "**قاعده‌ی ساده و قابل حفظ: در هر اسهالی که خون یا تب دارد، داروی ضدحرکت ممنوع است.**",
    "This is an 'all except' question testing AN IMPORTANT CONTRAINDICATION.\n\n"
    "THE PATIENT: a 30-year-old man with severe diarrhoea, weakness and lethargy. On examination: "
    "respiratory rate 20, temperature 38, blood pressure 80 by palpation, pulse 100, and dry mucous "
    "membranes. Stool: white cells 40 to 50 and red cells 10.\n\n"
    "LET US SETTLE TWO THINGS:\n\n"
    "ONE — THIS IS INFLAMMATORY DIARRHOEA. Stool white cells of 40 to 50 with red cells and fever. "
    "Invasion is certain.\n\n"
    "TWO — THE PATIENT IS DEHYDRATED. Dry mucous membranes, tachycardia of 100, low blood pressure.\n\n"
    "SO THREE MEASURES ARE NEEDED:\n\n"
    "RINGER'S LACTATE — YES, for RAPID VOLUME REPLACEMENT in a dehydrated hypotensive patient. Its "
    "electrolyte composition approximates extracellular fluid and suits the purpose.\n\n"
    "ORS (oral rehydration solution) — YES, THE MAINSTAY OF DIARRHOEA TREATMENT. After initial "
    "stabilisation, oral replacement continues. ORS is one of the most effective public health "
    "interventions in history.\n\n"
    "AN ANTIBIOTIC — YES. In INFLAMMATORY DIARRHOEA WITH FEVER, empirical treatment (usually a "
    "fluoroquinolone in an adult) is indicated.\n\n"
    "WARNING, AND FORBIDDEN: AN ANTIMOTILITY AGENT.\n\n"
    "WHY? UNDERSTAND THE MECHANISM OF HARM PRECISELY:\n\n"
    "Loperamide and diphenoxylate SLOW INTESTINAL PERISTALSIS. In non-inflammatory diarrhoea that "
    "merely reduces the symptom. But in INFLAMMATORY diarrhoea, the diarrhoea is A DEFENCE MECHANISM: "
    "the body is FLUSHING OUT THE INVADING ORGANISM AND ITS TOXIN.\n\n"
    "SLOWING THE BOWEL MEANS: mucosal contact with bacterium and toxin is PROLONGED; MORE TOXIN IS "
    "ABSORBED; THE ILLNESS LASTS LONGER; and at worst TOXIC MEGACOLON develops — a paralysed dilated "
    "colon that can progress to PERFORATION AND DEATH.\n\n"
    "A SIMPLE MEMORABLE RULE: IN ANY DIARRHOEA WITH BLOOD OR FEVER, ANTIMOTILITY DRUGS ARE FORBIDDEN.",
    ["کاربرد دارد — جبران سریع حجم در بیمار دهیدراته با فشار پایین.",
     "کاربرد دارد — او.آر.اس ستون درمان اسهال و ادامه‌ی جبران خوراکی است.",
     "کاربرد دارد — در اسهال التهابی با تب، درمان تجربی اندیکاسیون دارد.",
     "پاسخ صحیح — ضدحرکت در اسهال التهابی ممنوع است؛ خطر مگاکولون توکسیک دارد."],
    ["Has a place — rapid volume replacement in a dehydrated hypotensive patient.",
     "Has a place — ORS is the mainstay of diarrhoea treatment and continues oral replacement.",
     "Has a place — in inflammatory diarrhoea with fever, empirical treatment is indicated.",
     "Correct — antimotility agents are forbidden in inflammatory diarrhoea; they risk toxic megacolon."],
    "**در اسهال، خون یا تب = ضدحرکت ممنوع.**",
    "In diarrhoea, blood or fever means antimotility drugs are forbidden.",
    REFS)

add("book:301", "vignette", "medium",
    "**دیسانتری با تنسموس و انتقال خانوادگی: شیگلا — و درمان آن سیپروفلوکساسین است.**",
    "Dysentery with tenesmus and household transmission: Shigella — and its treatment is ciprofloxacin.",
    ALG_FA + [
        "**سه سرنخ این بیمار به شیگلا می‌رسند.**",
        "**سرنخ یک: اسهال ابتدا آبکی و سپس ظرف ۲۴ ساعت خونی شده.**",
        "**این تکامل کلاسیک شیگلاست: ابتدا روده‌ی باریک، سپس تهاجم به کولون.**",
        "⚠️ **سرنخ دو: تنسموس و کرامپ شکمی — یعنی رکتیت.**",
        "**سرنخ سه: برادرش سه روز قبل همین علائم را داشته.**",
        "**و این انتقال فرد به فرد، امضای شیگلاست.**",
        "**چون دوز عفونی شیگلا بسیار پایین است: ده تا صد ارگانیسم.**",
        "**پس شیگلا برخلاف بیشتر پاتوژن‌های روده‌ای، مستقیم از فرد به فرد منتقل می‌شود.**",
        "⚠️ **درمان: فلوروکینولون، که هم بیماری را کوتاه می‌کند و هم دفع باکتری را.**",
        "**و کوتاه کردن دفع باکتری، انتقال به بقیه‌ی خانواده را متوقف می‌کند.**",
    ],
    ALG_EN + [
        "Three clues in this patient point to Shigella.",
        "CLUE ONE: the diarrhoea was watery first and became bloody within 24 hours.",
        "That is the classic Shigella evolution: small bowel first, then colonic invasion.",
        "WARNING, CLUE TWO: tenesmus and abdominal cramps — meaning proctitis.",
        "CLUE THREE: his brother had the same symptoms three days earlier.",
        "And that person-to-person transmission is the Shigella signature.",
        "Because Shigella's infective dose is very low: ten to a hundred organisms.",
        "So Shigella, unlike most enteric pathogens, transmits directly person to person.",
        "WARNING, TREATMENT: a fluoroquinolone, which shortens both the illness and the shedding.",
        "And shortening the shedding stops transmission to the rest of the household.",
    ],
    "این سؤال از شاخه‌ی **دوم** الگوریتم است: **دیسانتری، که درمان می‌خواهد.**\n\n"
    "**بیمار: آقای ۲۱ ساله با اسهال و تب. اسهال ابتدا آبکی بوده و سپس ظرف ۲۴ ساعت خونی شده، "
    "همراه با تنسموس و کرامپ شکمی. برادرش سه روز قبل همین علائم را داشته. در معاینه فقط "
    "دهیدراتاسیون خفیف.**\n\n"
    "**سه سرنخ، همه به شیگلا:**\n\n"
    "**سرنخ یک — تکامل اسهال: ابتدا آبکی، سپس خونی.** این **الگوی کلاسیک شیگلا**ست و سازوکار "
    "دارد: شیگلا ابتدا در **روده‌ی باریک** سم ترشح می‌کند (فاز آبکی)، سپس به **کولون** "
    "می‌رسد و **مخاط را تهاجم می‌کند** (فاز خونی و دیسانتریک).\n\n"
    "⚠️ **سرنخ دو — تنسموس و کرامپ.** تنسموس یعنی **رکتیت**؛ التهاب به رکتوم رسیده. این "
    "امضای دیسانتری است.\n\n"
    "**سرنخ سه — و مهم‌ترین: برادرش سه روز قبل همین را داشته.**\n\n"
    "**چرا این سرنخ قوی است؟** چون **دوز عفونی شیگلا فوق‌العاده پایین است: فقط ۱۰ تا ۱۰۰ "
    "ارگانیسم**. (برای مقایسه: وبا میلیون‌ها می‌خواهد.) این یعنی شیگلا **مستقیماً از فرد به "
    "فرد** منتقل می‌شود — از راه دست‌های آلوده، بدون نیاز به تکثیر در غذا. **به همین دلیل "
    "طغیان‌های خانوادگی و مهدکودکی شیگلا بسیار شایع است.**\n\n"
    "**پس درمان: سیپروفلوکساسین.**\n\n"
    "**دو سود دارد:** **کوتاه کردن مدت بیماری**، و — مهم‌تر از نظر بهداشت عمومی — "
    "**کوتاه کردن مدت دفع باکتری**، که **انتقال به بقیه‌ی خانواده را متوقف می‌کند**.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "⚠️ **لوپرامید:** **خطرناک‌ترین گزینه.** این بیمار **اسهال خونی با تب** دارد — یعنی "
    "دقیقاً همان وضعیتی که **ضدحرکت در آن ممنوع است**. خطر **مگاکولون توکسیک**.\n\n"
    "**آموکسی‌سیلین:** شیگلا **مقاومت گسترده‌ای به آمپی‌سیلین و آموکسی‌سیلین** دارد. انتخاب "
    "نامناسبی است.\n\n"
    "**مترونیدازول:** داروی **آمیب و بی‌هوازی‌ها**ست. اگر تشخیص **آمیبیازیس** بود درست می‌شد، "
    "ولی تابلوی این بیمار — **شروع حاد، تب، انتقال خانوادگی سریع، تکامل آبکی به خونی** — "
    "به‌مراتب بیشتر با شیگلا می‌خواند تا آمیب. (آمیبیازیس معمولاً **تدریجی‌تر** و **بدون تب "
    "بارز** است.)",
    "This question belongs to BRANCH TWO of the algorithm: DYSENTERY, WHICH NEEDS TREATMENT.\n\n"
    "THE PATIENT: a 21-year-old man with diarrhoea and fever. The diarrhoea was watery at first and "
    "became bloody within 24 hours, with tenesmus and abdominal cramps. His brother had the same "
    "symptoms three days earlier. Examination shows only mild dehydration.\n\n"
    "THREE CLUES, ALL TO SHIGELLA:\n\n"
    "CLUE ONE — THE EVOLUTION: watery first, then bloody. This is THE CLASSIC SHIGELLA PATTERN and it "
    "has a mechanism: Shigella first secretes toxin in the SMALL BOWEL (the watery phase), then reaches "
    "the COLON and INVADES THE MUCOSA (the bloody, dysenteric phase).\n\n"
    "WARNING, CLUE TWO — TENESMUS AND CRAMPS. Tenesmus means PROCTITIS; the inflammation has reached "
    "the rectum. That is the signature of dysentery.\n\n"
    "CLUE THREE — AND THE MOST IMPORTANT: his brother had the same illness three days earlier.\n\n"
    "WHY IS THAT CLUE SO STRONG? Because SHIGELLA'S INFECTIVE DOSE IS EXTRAORDINARILY LOW: ONLY 10 TO "
    "100 ORGANISMS. (For comparison, cholera needs millions.) That means Shigella transmits DIRECTLY "
    "PERSON TO PERSON on contaminated hands, without needing to multiply in food. THIS IS WHY FAMILY "
    "AND NURSERY OUTBREAKS OF SHIGELLA ARE SO COMMON.\n\n"
    "SO THE TREATMENT: CIPROFLOXACIN.\n\n"
    "IT HAS TWO BENEFITS: SHORTENING THE ILLNESS, and — more important for public health — SHORTENING "
    "THE PERIOD OF BACTERIAL SHEDDING, which STOPS TRANSMISSION TO THE REST OF THE HOUSEHOLD.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "WARNING, LOPERAMIDE: THE MOST DANGEROUS OPTION. This patient has BLOODY DIARRHOEA WITH FEVER — "
    "precisely the situation in which ANTIMOTILITY AGENTS ARE FORBIDDEN. Risk of TOXIC MEGACOLON.\n\n"
    "AMOXICILLIN: Shigella has WIDESPREAD RESISTANCE TO AMPICILLIN AND AMOXICILLIN. An unsuitable choice.\n\n"
    "METRONIDAZOLE: a drug for AMOEBA AND ANAEROBES. It would be right if the diagnosis were "
    "AMOEBIASIS, but this patient's picture — ACUTE ONSET, FEVER, RAPID HOUSEHOLD TRANSMISSION, "
    "WATERY-TO-BLOODY EVOLUTION — fits Shigella far better than amoeba. (Amoebiasis is usually MORE "
    "GRADUAL and WITHOUT MARKED FEVER.)",
    ["پاسخ صحیح — فلوروکینولون هم بیماری را کوتاه می‌کند و هم دفع باکتری و انتقال خانوادگی را.",
     "خطرناک‌ترین گزینه — در اسهال خونی با تب، ضدحرکت ممنوع است؛ خطر مگاکولون توکسیک.",
     "شیگلا مقاومت گسترده‌ای به آموکسی‌سیلین دارد؛ انتخاب نامناسبی است.",
     "داروی آمیب است، ولی شروع حاد و انتقال خانوادگی سریع بیشتر با شیگلا می‌خواند."],
    ["Correct — a fluoroquinolone shortens the illness, the shedding and household transmission.",
     "The most dangerous option — in bloody febrile diarrhoea, antimotility drugs are forbidden.",
     "Shigella has widespread resistance to amoxicillin; an unsuitable choice.",
     "An amoeba drug, but the acute onset and rapid household spread fit Shigella far better."],
    "**دوز عفونی شیگلا ۱۰ تا ۱۰۰ است — به همین دلیل خانوادگی منتقل می‌شود.**",
    "Shigella's infective dose is 10 to 100 — which is why it spreads through a household.",
    REFS)

add("book:302", "vignette", "easy",
    "**دیسانتری تجربی در بزرگ‌سال: سیپروفلوکساسین.**",
    "Empirical dysentery in an adult: CIPROFLOXACIN.",
    ALG_FA + [
        "**اینجا آزمایش مدفوع فقط گلبول سفید و قرمز فراوان نشان داده و هیچ‌چیز دیگر.**",
        "**«هیچ مورد دیگری» یعنی انگل و کیست دیده نشده است.**",
        "⚠️ **پس آمیب و ژیاردیا از تشخیص کنار می‌روند.**",
        "**می‌ماند دیسانتری باکتریایی: شیگلا، کمپیلوباکتر، سالمونلا، EHEC.**",
        "**و درمان تجربی آن در بزرگ‌سال، فلوروکینولون است.**",
        "**فلوروکینولون هر سه عامل شایع باکتریایی را پوشش می‌دهد.**",
        "**و در همین حال، انتظار برای کشت، درمان را به تأخیر نمی‌اندازد.**",
    ],
    ALG_EN + [
        "Here the stool shows only abundant white and red cells and nothing else.",
        "'Nothing else was seen' means no parasites and no cysts.",
        "WARNING, SO AMOEBA AND GIARDIA DROP OUT of the differential.",
        "That leaves bacterial dysentery: Shigella, Campylobacter, Salmonella, EHEC.",
        "And its empirical treatment in an adult is a fluoroquinolone.",
        "A fluoroquinolone covers all three common bacterial causes.",
        "And meanwhile, waiting for a culture does not delay treatment.",
    ],
    "این سؤال کوتاه است و **درمان تجربی دیسانتری** را می‌سنجد.\n\n"
    "**بیمار: مرد ۴۰ ساله با تب و اسهال خونی. در آزمایش مدفوع اورژانسی، بجز گلبول سفید و "
    "قرمز فراوان، مورد دیگری مشاهده نشده است.**\n\n"
    "**دو نکته را از این جمله بگیرید:**\n\n"
    "**یک — گلبول سفید و قرمز فراوان** = **اسهال التهابی (دیسانتری)**. با تب همراه است، پس "
    "**درمان اندیکاسیون دارد**.\n\n"
    "⚠️ **دو — «مورد دیگری مشاهده نشده» یعنی چه؟** یعنی **انگل، تروفوزوئیت و کیست دیده "
    "نشده است**. و این عبارت عمداً آمده: **آمیب و ژیاردیا را از فهرست خارج می‌کند.**\n\n"
    "**پس می‌ماند: دیسانتری باکتریایی** — شیگلا، کمپیلوباکتر، سالمونلای غیرتیفی، یا EHEC.\n\n"
    "**درمان تجربی در بزرگ‌سال: فلوروکینولون (سیپروفلوکساسین).**\n\n"
    "**چرا فلوروکینولون؟** چون **هر سه عامل شایع باکتریایی را پوشش می‌دهد** و می‌توان آن را "
    "**پیش از آماده شدن کشت** شروع کرد. در بیمار تب‌دار با دیسانتری، **انتظار ۴۸ تا ۷۲ ساعته "
    "برای کشت قابل قبول نیست**.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**بیسموت:** ترکیبات بیسموت **اثر علامتی خفیفی** در اسهال مسافران دارند، ولی **درمان "
    "دیسانتری باکتریایی نیستند**. بیمار تب‌دار با اسهال خونی، درمان ضدمیکروبی می‌خواهد.\n\n"
    "**یدوکینول:** داروی **لومینال ضدآمیب** است. ولی سؤال صریحاً گفته **انگلی دیده نشده**، "
    "و یدوکینول **در بیماری مهاجم هم به‌تنهایی کافی نیست** (باید پس از نیتروایمیدازول بیاید).\n\n"
    "⚠️ **مترونیدازول:** اگر **آمیب** مطرح بود درست می‌شد. ولی **هیچ انگلی در مدفوع دیده "
    "نشده**، و مترونیدازول **روی شیگلا و کمپیلوباکتر و سالمونلا اثری ندارد** — این‌ها هوازی "
    "یا میکروآئروفیل‌اند، و مترونیدازول داروی **بی‌هوازی‌ها و تک‌یاخته‌ها**ست.",
    "This question is short and tests THE EMPIRICAL TREATMENT OF DYSENTERY.\n\n"
    "THE PATIENT: a 40-year-old man with fever and bloody diarrhoea. The urgent stool examination shows "
    "abundant white and red cells and NOTHING ELSE.\n\n"
    "TAKE TWO POINTS FROM THAT SENTENCE:\n\n"
    "ONE — ABUNDANT WHITE AND RED CELLS = INFLAMMATORY DIARRHOEA (DYSENTERY). It is accompanied by "
    "fever, so TREATMENT IS INDICATED.\n\n"
    "WARNING, TWO — WHAT DOES 'NOTHING ELSE WAS SEEN' MEAN? It means NO PARASITES, TROPHOZOITES OR "
    "CYSTS WERE SEEN. And that phrase is there deliberately: IT REMOVES AMOEBA AND GIARDIA FROM THE LIST.\n\n"
    "SO WHAT REMAINS IS BACTERIAL DYSENTERY — Shigella, Campylobacter, non-typhoidal Salmonella, or EHEC.\n\n"
    "EMPIRICAL TREATMENT IN AN ADULT: A FLUOROQUINOLONE (ciprofloxacin).\n\n"
    "WHY A FLUOROQUINOLONE? Because it COVERS ALL THREE COMMON BACTERIAL CAUSES and can be started "
    "BEFORE THE CULTURE IS READY. In a febrile patient with dysentery, A 48 TO 72 HOUR WAIT FOR CULTURE "
    "IS NOT ACCEPTABLE.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "BISMUTH: bismuth compounds have A MILD SYMPTOMATIC EFFECT in traveller's diarrhoea but ARE NOT A "
    "TREATMENT FOR BACTERIAL DYSENTERY. A febrile patient with bloody diarrhoea needs antimicrobial "
    "treatment.\n\n"
    "IODOQUINOL: a LUMINAL ANTIAMOEBIC agent. But the question states explicitly that NO PARASITE WAS "
    "SEEN, and iodoquinol IS NOT SUFFICIENT ALONE even in invasive disease (it must follow a "
    "nitroimidazole).\n\n"
    "WARNING, METRONIDAZOLE: it would be right if AMOEBA were in question. But NO PARASITE WAS SEEN IN "
    "THE STOOL, and metronidazole HAS NO EFFECT ON SHIGELLA, CAMPYLOBACTER OR SALMONELLA — these are "
    "aerobes or microaerophiles, and metronidazole is a drug for ANAEROBES AND PROTOZOA.",
    ["اثر علامتی خفیفی در اسهال مسافران دارد ولی درمان دیسانتری باکتریایی نیست.",
     "داروی لومینال ضدآمیب است، ولی هیچ انگلی در مدفوع دیده نشده است.",
     "پاسخ صحیح — فلوروکینولون درمان تجربی دیسانتری باکتریایی در بزرگ‌سال است.",
     "داروی بی‌هوازی‌ها و تک‌یاخته‌هاست؛ روی شیگلا و کمپیلوباکتر و سالمونلا اثری ندارد."],
    ["Has a mild symptomatic effect in traveller's diarrhoea but is not a treatment for bacterial dysentery.",
     "A luminal antiamoebic agent, but no parasite was seen in the stool.",
     "Correct — a fluoroquinolone is the empirical treatment of bacterial dysentery in an adult.",
     "A drug for anaerobes and protozoa; it has no effect on Shigella, Campylobacter or Salmonella."],
    "**«مورد دیگری دیده نشد» یعنی انگل نیست — پس مترونیدازول جایی ندارد.**",
    "'Nothing else was seen' means no parasite — so metronidazole has no place.",
    REFS)

add("book:300", "vignette", "hard",
    "**کیست آنتاموبا کلای بی‌آزار است — دیسانتری این بیمار باکتریایی است، پس سیپروفلوکساسین.**",
    "Entamoeba COLI cysts are harmless — this patient's dysentery is bacterial, so ciprofloxacin.",
    ALG_FA + [
        "**این سؤال یک دام نام‌گذاری دارد که باید بشناسید.**",
        "**آنتاموبا کلای با آنتاموبا هیستولیتیکا فرق دارد.**",
        "⚠️ **آنتاموبا کلای یک آمیب کاملاً بی‌آزار و غیربیماری‌زاست.**",
        "**در روده‌ی بسیاری از افراد سالم به‌عنوان همزیست زندگی می‌کند.**",
        "**دیدن کیست آن در مدفوع، هیچ درمانی نمی‌طلبد.**",
        "**فقط نشان می‌دهد که فرد در معرض آلودگی مدفوعی-دهانی بوده است.**",
        "**پس در این بیمار، کیست آنتاموبا کلای یک یافته‌ی اتفاقی است.**",
        "⚠️ **و آنچه بیماری را توضیح می‌دهد، گلبول سفید و قرمز فراوان است.**",
        "**یعنی دیسانتری باکتریایی، که با فلوروکینولون درمان می‌شود.**",
        "**اگر هیستولیتیکا بود، مترونیدازول درست می‌شد — و این تمام تفاوت است.**",
    ],
    ALG_EN + [
        "This question contains a naming trap that must be recognised.",
        "ENTAMOEBA COLI is not Entamoeba HISTOLYTICA.",
        "WARNING, ENTAMOEBA COLI IS A COMPLETELY HARMLESS, NON-PATHOGENIC AMOEBA.",
        "It lives as a commensal in the bowel of many healthy people.",
        "Seeing its cysts in the stool calls for no treatment whatsoever.",
        "It merely shows that the person has been exposed to faecal-oral contamination.",
        "So in this patient the Entamoeba coli cyst is an incidental finding.",
        "WARNING, AND WHAT EXPLAINS THE ILLNESS is the abundant white and red cells.",
        "That is bacterial dysentery, treated with a fluoroquinolone.",
        "Had it been histolytica, metronidazole would be right — and that is the whole difference.",
    ],
    "این **بهترین سؤال دام‌دار** این بلوک است، و دام آن **در یک کلمه** پنهان است.\n\n"
    "**بیمار: پسر ۱۷ ساله با اسهال خونی از دو روز قبل. در آزمایش مدفوع: گلبول قرمز فراوان، "
    "گلبول سفید فراوان، و کیست آمیب کلای.**\n\n"
    "**وسوسه‌ی طبیعی: «آمیب دیده شده، پس مترونیدازول بدهیم.» و این اشتباه است.**\n\n"
    "⚠️ **کلمه‌ی کلیدی «کلای» است، نه «هیستولیتیکا».**\n\n"
    "**آنتاموبا کلای (Entamoeba coli) یک آمیب کاملاً بی‌آزار و غیربیماری‌زاست.** در روده‌ی "
    "بسیاری از افراد سالم به‌عنوان **همزیست (کومنسال)** زندگی می‌کند، **هیچ‌گاه تهاجم "
    "نمی‌کند**، و **هیچ بیماری‌ای نمی‌سازد**.\n\n"
    "**پس دیدن کیست آن چه معنایی دارد؟** فقط یک چیز: **فرد در معرض آلودگی مدفوعی-دهانی بوده "
    "است**. یعنی یک **نشانگر بهداشتی** است، نه یک **تشخیص**. **و هیچ درمانی نمی‌طلبد.**\n\n"
    "**نکته‌ی عملی مهم: آنتاموبا کلای و آنتاموبا هیستولیتیکا در آزمایشگاه از هم قابل تفکیک‌اند** "
    "(بر اساس تعداد هسته‌ی کیست، اندازه، و شکل کاریوزوم). وقتی آزمایشگاه صریحاً **«کلای»** "
    "می‌نویسد، یعنی این تفکیک را انجام داده است.\n\n"
    "**پس چه چیزی بیماری این پسر را توضیح می‌دهد؟** **گلبول سفید و قرمز فراوان** — یعنی "
    "**دیسانتری باکتریایی**. عامل احتمالی: شیگلا، کمپیلوباکتر، یا سالمونلا.\n\n"
    "**درمان: سیپروفلوکساسین.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "⚠️ **مترونیدازول:** این **همان دامی است که سؤال گذاشته**. مترونیدازول درمان **آنتاموبا "
    "هیستولیتیکا** است، نه کلای. دادن آن یعنی **درمان یک ارگانیسم بی‌آزار و رها کردن عامل "
    "واقعی بیماری**.\n\n"
    "**یدوکینول:** داروی **لومینال ضدآمیب**. باز هم برای هیستولیتیکا، و باز هم بی‌مورد — "
    "به‌علاوه، **آنتاموبا کلای حتی درمان لومینال هم نمی‌خواهد**.\n\n"
    "**فورازولیدون:** داروی قدیمی برای **ژیاردیا و برخی اسهال‌های باکتریایی**. امروز کمتر "
    "استفاده می‌شود و **درمان انتخابی دیسانتری باکتریایی نیست**.\n\n"
    "**درس کلی: نام گونه را کامل بخوانید. «آمیب» به‌تنهایی یک تشخیص نیست.**",
    "This is the BEST TRAP QUESTION in the block, and its trap is hidden IN ONE WORD.\n\n"
    "THE PATIENT: a 17-year-old boy with bloody diarrhoea for two days. Stool: abundant red cells, "
    "abundant white cells, and cysts of Entamoeba COLI.\n\n"
    "THE NATURAL TEMPTATION: 'an amoeba was seen, so give metronidazole.' AND THAT IS WRONG.\n\n"
    "WARNING, THE KEY WORD IS 'COLI', NOT 'HISTOLYTICA'.\n\n"
    "ENTAMOEBA COLI IS A COMPLETELY HARMLESS, NON-PATHOGENIC AMOEBA. It lives as a COMMENSAL in the "
    "bowel of many healthy people, NEVER INVADES, and CAUSES NO DISEASE AT ALL.\n\n"
    "SO WHAT DOES SEEING ITS CYSTS MEAN? Only one thing: THE PERSON HAS BEEN EXPOSED TO FAECAL-ORAL "
    "CONTAMINATION. It is A HYGIENE MARKER, not A DIAGNOSIS. AND IT REQUIRES NO TREATMENT.\n\n"
    "AN IMPORTANT PRACTICAL POINT: Entamoeba coli and Entamoeba histolytica ARE DISTINGUISHABLE IN THE "
    "LABORATORY (by the number of nuclei in the cyst, its size, and the shape of the karyosome). When "
    "the laboratory explicitly writes 'COLI', it has made that distinction.\n\n"
    "SO WHAT EXPLAINS THIS BOY'S ILLNESS? THE ABUNDANT WHITE AND RED CELLS — that is, BACTERIAL "
    "DYSENTERY. The likely organism: Shigella, Campylobacter or Salmonella.\n\n"
    "TREATMENT: CIPROFLOXACIN.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "WARNING, METRONIDAZOLE: THIS IS THE TRAP THE QUESTION LAID. Metronidazole treats ENTAMOEBA "
    "HISTOLYTICA, not coli. Giving it means TREATING A HARMLESS ORGANISM AND LEAVING THE REAL CAUSE "
    "UNTREATED.\n\n"
    "IODOQUINOL: a LUMINAL ANTIAMOEBIC. Again for histolytica, and again unnecessary — moreover "
    "ENTAMOEBA COLI DOES NOT EVEN NEED LUMINAL TREATMENT.\n\n"
    "FURAZOLIDONE: an old drug for GIARDIA and some bacterial diarrhoeas. Little used today and NOT THE "
    "TREATMENT OF CHOICE for bacterial dysentery.\n\n"
    "THE GENERAL LESSON: READ THE FULL SPECIES NAME. 'AMOEBA' ALONE IS NOT A DIAGNOSIS.",
    ["دام سؤال — مترونیدازول برای هیستولیتیکاست؛ آنتاموبا کلای بی‌آزار است و درمان نمی‌خواهد.",
     "پاسخ صحیح — گلبول سفید و قرمز فراوان یعنی دیسانتری باکتریایی، که فلوروکینولون می‌خواهد.",
     "داروی لومینال ضدآمیب است؛ آنتاموبا کلای حتی درمان لومینال هم نمی‌خواهد.",
     "داروی قدیمی ژیاردیاست و درمان انتخابی دیسانتری باکتریایی نیست."],
    ["The trap — metronidazole is for histolytica; Entamoeba coli is harmless and needs no treatment.",
     "Correct — abundant white and red cells mean bacterial dysentery, which needs a fluoroquinolone.",
     "A luminal antiamoebic; Entamoeba coli does not even need luminal treatment.",
     "An old giardia drug and not the treatment of choice for bacterial dysentery."],
    "**آنتاموبا کلای بی‌آزار است — نام گونه را کامل بخوانید.**",
    "Entamoeba coli is harmless — read the full species name.",
    REFS)

# ==================================================== C. DIFFICILE: SHARED
CD_FA = [
    "⚠️ **کلستریدیوم دیفیسیل را از زمینه بشناسید، نه از تابلوی اسهال.**",
    "**زمینه: آنتی‌بیوتیک اخیر یا فعلی، و بستری در بیمارستان.**",
    "**سه آنتی‌بیوتیک کلاسیک: کلیندامایسین، سفالوسپورین‌ها، و فلوروکینولون‌ها.**",
    "**ولی عملاً هر آنتی‌بیوتیکی می‌تواند آن را راه بیندازد.**",
    "**سازوکار: آنتی‌بیوتیک فلور طبیعی کولون را از بین می‌برد.**",
    "**و کلستریدیوم دیفیسیل، که مقاوم است، جای خالی را پر می‌کند و سم می‌سازد.**",
    "⚠️ **تابلو: اسهال معمولاً غیرخونی، با تب خفیف و درد شکم.**",
    "**در موارد شدید، لکوسیتوز بارز و کولیت پسودوممبران.**",
    "**و در موارد فولمینانت: هیپوتانسیون، ایلئوس، و مگاکولون توکسیک.**",
    "**تشخیص: کشت مدفوع آزمون آن نیست، و دلیلش مهم است.**",
    "**کلستریدیوم دیفیسیل در افراد صرفاً کلونیزه هم به‌راحتی رشد می‌کند.**",
    "⚠️ **پس کشت مثبت، بیماری را ثابت نمی‌کند — فقط حضور باکتری را.**",
    "**آزمون درست، بررسی سم است: EIA یا PCR برای ژن سم.**",
    "**PCR حساس‌ترین روش است.**",
    "**و کولونوسکوپی کم‌حساس‌ترین، چون غشای کاذب در بسیاری از موارد واقعی وجود ندارد.**",
]
CD_EN = [
    "WARNING: RECOGNISE C. DIFFICILE FROM ITS SETTING, not from the character of the diarrhoea.",
    "The setting: recent or current antibiotics, and a hospital stay.",
    "The three classic antibiotics: clindamycin, cephalosporins and fluoroquinolones.",
    "But in practice almost any antibiotic can trigger it.",
    "The mechanism: the antibiotic destroys the normal colonic flora.",
    "And C. difficile, which is resistant, fills the vacancy and produces toxin.",
    "WARNING, THE PICTURE: usually NON-BLOODY diarrhoea with low-grade fever and abdominal pain.",
    "In severe cases, marked leucocytosis and pseudomembranous colitis.",
    "And in fulminant disease: hypotension, ileus and toxic megacolon.",
    "DIAGNOSIS: stool culture is NOT the test, and the reason matters.",
    "C. difficile grows readily even in people who are merely colonised.",
    "WARNING, SO A POSITIVE CULTURE DOES NOT PROVE DISEASE — only the presence of the organism.",
    "The correct test is TOXIN detection: EIA, or PCR for the toxin gene.",
    "PCR is the most SENSITIVE method.",
    "And colonoscopy the LEAST sensitive, because pseudomembranes are absent in many genuine cases.",
]

add("book:310", "vignette", "easy",
    "**اسهال یک هفته پس از پیوند مغز استخوان: کلستریدیوم دیفیسیل.**",
    "Diarrhoea one week after a bone marrow transplant: CLOSTRIDIOIDES DIFFICILE.",
    CD_FA,
    CD_EN,
    "این ساده‌ترین سؤال خوشه‌ی کلستریدیوم دیفیسیل است، و **زمینه** همه‌چیز را می‌گوید.\n\n"
    "**بیمار: آقای ۳۰ ساله که برای لوسمی پیوند مغز استخوان شده است. یک هفته بعد از پیوند "
    "دچار اسهال می‌شود.**\n\n"
    "⚠️ **چرا این زمینه، کلستریدیوم دیفیسیل را در صدر می‌گذارد؟ چهار عامل خطر هم‌زمان:**\n\n"
    "**یک — بستری طولانی در بیمارستان.** بیمار پیوند مغز استخوان هفته‌ها بستری است، و "
    "**اسپورهای کلستریدیوم دیفیسیل در محیط بیمارستان فراوان‌اند** و ماه‌ها زنده می‌مانند.\n\n"
    "**دو — آنتی‌بیوتیک وسیع‌الطیف.** بیمار پیوندی تقریباً همیشه **پروفیلاکسی یا درمان "
    "آنتی‌بیوتیکی** می‌گیرد. و همین **فلور طبیعی کولون را از بین می‌برد** و جا را برای "
    "کلستریدیوم دیفیسیل باز می‌کند.\n\n"
    "**سه — سرکوب شدید ایمنی.** رژیم آماده‌سازی پیوند و داروهای ضدرد پیوند.\n\n"
    "**چهار — شیمی‌درمانی**، که خودش هم مخاط روده را آسیب می‌زند.\n\n"
    "**سازوکار بیماری را بفهمید:** فلور طبیعی کولون یک **سد محافظ** است — با اشغال فضا و "
    "منابع، مانع رشد پاتوژن‌ها می‌شود. آنتی‌بیوتیک این سد را برمی‌دارد. **کلستریدیوم دیفیسیل، "
    "که به بیشتر آنتی‌بیوتیک‌ها مقاوم است، تکثیر می‌شود و سم A و B می‌سازد** که مخاط کولون را "
    "تخریب می‌کنند.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**سالمونلا:** یک پاتوژن **اکتسابی از جامعه** است که از غذای آلوده می‌آید. در بیمار "
    "بستری که غذای بیمارستانی می‌خورد، **بسیار کم‌محتمل‌تر** از کلستریدیوم دیفیسیل است.\n\n"
    "**کاندیدا آلبیکنس:** در بیمار دچار سرکوب ایمنی **کاندیدیازیس مخاطی (برفک دهان و مری)** "
    "شایع است، ولی **کاندیدا علت شناخته‌شده‌ی اسهال حاد نیست**. رشد آن در کشت مدفوع معمولاً "
    "**کلونیزاسیون** است، نه بیماری.\n\n"
    "⚠️ **شیگلا:** مثل سالمونلا، پاتوژن **اکتسابی از جامعه** با انتقال مدفوعی-دهانی. در "
    "بخش پیوند، **زمینه‌ی اپیدمیولوژیک آن وجود ندارد**.\n\n"
    "**قاعده‌ی کلی که ارزش حفظ کردن دارد: اسهالی که در بیمارستان شروع می‌شود، تا خلاف آن "
    "ثابت نشود کلستریدیوم دیفیسیل است.**",
    "This is the simplest question in the C. difficile cluster, and THE SETTING says everything.\n\n"
    "THE PATIENT: a 30-year-old man who has had a bone marrow transplant for leukaemia. One week after "
    "the transplant he develops diarrhoea.\n\n"
    "WARNING, WHY DOES THIS SETTING PUT C. DIFFICILE AT THE TOP? FOUR RISK FACTORS AT ONCE:\n\n"
    "ONE — A LONG HOSPITAL STAY. A bone marrow transplant patient is admitted for weeks, and C. "
    "DIFFICILE SPORES ARE ABUNDANT IN THE HOSPITAL ENVIRONMENT and survive for months.\n\n"
    "TWO — BROAD-SPECTRUM ANTIBIOTICS. A transplant patient almost always receives PROPHYLACTIC OR "
    "THERAPEUTIC ANTIBIOTICS. And these DESTROY THE NORMAL COLONIC FLORA, making room for C. difficile.\n\n"
    "THREE — PROFOUND IMMUNOSUPPRESSION. The conditioning regimen and anti-rejection drugs.\n\n"
    "FOUR — CHEMOTHERAPY, which itself damages the bowel mucosa.\n\n"
    "UNDERSTAND THE MECHANISM: the normal colonic flora is A PROTECTIVE BARRIER — by occupying space "
    "and resources it prevents pathogens from growing. Antibiotics remove that barrier. C. DIFFICILE, "
    "WHICH IS RESISTANT TO MOST ANTIBIOTICS, MULTIPLIES AND MAKES TOXINS A AND B, which destroy the "
    "colonic mucosa.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "SALMONELLA: a COMMUNITY-ACQUIRED pathogen from contaminated food. In an inpatient eating hospital "
    "food it is FAR LESS LIKELY than C. difficile.\n\n"
    "CANDIDA ALBICANS: MUCOSAL CANDIDIASIS (oral and oesophageal thrush) is common in an "
    "immunosuppressed patient, but CANDIDA IS NOT A RECOGNISED CAUSE OF ACUTE DIARRHOEA. Its growth in "
    "a stool culture usually represents COLONISATION, not disease.\n\n"
    "WARNING, SHIGELLA: like Salmonella, a COMMUNITY-ACQUIRED pathogen with faecal-oral transmission. "
    "On a transplant ward THE EPIDEMIOLOGICAL SETTING FOR IT DOES NOT EXIST.\n\n"
    "A GENERAL RULE WORTH MEMORISING: DIARRHOEA THAT BEGINS IN HOSPITAL IS C. DIFFICILE UNTIL PROVED "
    "OTHERWISE.",
    ["پاسخ صحیح — بستری طولانی، آنتی‌بیوتیک وسیع‌الطیف و سرکوب ایمنی، همه به سمت دیفیسیل.",
     "پاتوژن اکتسابی از جامعه است؛ در بیمار بستری با غذای بیمارستانی کم‌محتمل است.",
     "کاندیدا علت شناخته‌شده‌ی اسهال حاد نیست؛ رشد آن معمولاً کلونیزاسیون است.",
     "پاتوژن اکتسابی از جامعه با انتقال مدفوعی-دهانی؛ زمینه‌ی آن در بخش پیوند وجود ندارد."],
    ["Correct — a long admission, broad-spectrum antibiotics and immunosuppression all point to C. difficile.",
     "A community-acquired pathogen; unlikely in an inpatient eating hospital food.",
     "Candida is not a recognised cause of acute diarrhoea; its growth usually means colonisation.",
     "A community-acquired faecal-oral pathogen; its setting does not exist on a transplant ward."],
    "**اسهالی که در بیمارستان شروع می‌شود، تا خلاف آن ثابت نشده دیفیسیل است.**",
    "Diarrhoea that begins in hospital is C. difficile until proved otherwise.",
    CDREFS)

add("book:311", "vignette", "easy",
    "**اسهال پس از یک هفته بستری برای پنومونی: کلستریدیوم دیفیسیل، حتی با مدفوع خونی.**",
    "Diarrhoea after a week in hospital for pneumonia: C. difficile, even with blood in the stool.",
    CD_FA + [
        "**در این بیمار دو عامل خطر اصلی هر دو حاضرند.**",
        "**یک هفته بستری، و درمان آنتی‌بیوتیکی پنومونی.**",
        "⚠️ **و یک نکته: مدفوع این بیمار گلبول قرمز هم دارد.**",
        "**اسهال دیفیسیل معمولاً غیرخونی است، ولی می‌تواند خونی هم باشد.**",
        "**در کولیت شدید، تخریب مخاط به خونریزی می‌رسد.**",
        "**پس «خونی بودن» تشخیص دیفیسیل را رد نمی‌کند.**",
        "**و در بیمار بستری، زمینه بر تابلو غلبه دارد.**",
    ],
    CD_EN + [
        "In this patient both major risk factors are present.",
        "A week in hospital, and antibiotic treatment for pneumonia.",
        "WARNING, AND ONE POINT: this patient's stool also contains red cells.",
        "C. difficile diarrhoea is usually non-bloody, but it CAN be bloody.",
        "In severe colitis, mucosal destruction progresses to bleeding.",
        "So the presence of blood does not exclude C. difficile.",
        "And in an inpatient, the setting outweighs the character of the stool.",
    ],
    "این سؤال همان قاعده‌ی قبلی است، ولی یک **ابهام ظاهری** اضافه می‌کند.\n\n"
    "**بیمار: آقای ۶۵ ساله که از هفته‌ی گذشته به علت پنومونی در بیمارستان بستری بوده، حالا "
    "دچار تب، درد شکم و اسهال شده. در آزمایش مدفوع، گلبول قرمز و گلبول سفید مشهود است.**\n\n"
    "⚠️ **زمینه، تشخیص را می‌دهد: یک هفته بستری + درمان آنتی‌بیوتیکی پنومونی.**\n\n"
    "**درمان پنومونی معمولاً شامل سفالوسپورین یا فلوروکینولون است** — و **هر دو از سه "
    "آنتی‌بیوتیک کلاسیک راه‌اندازنده‌ی کلستریدیوم دیفیسیل‌اند** (کنار کلیندامایسین).\n\n"
    "**حالا ابهام ظاهری: مدفوع این بیمار گلبول قرمز هم دارد.**\n\n"
    "**دانشجو ممکن است فکر کند «اسهال دیفیسیل غیرخونی است، پس این چیز دیگری است». و این "
    "استدلال نادرست است.**\n\n"
    "⚠️ **اسهال کلستریدیوم دیفیسیل معمولاً غیرخونی است — ولی می‌تواند خونی هم باشد.** در "
    "**کولیت شدید**، سم A و B مخاط کولون را چنان تخریب می‌کنند که **خونریزی رخ می‌دهد**. "
    "گلبول سفید فراوان در مدفوع هم کاملاً مورد انتظار است (کولیت التهابی).\n\n"
    "**پس «معمولاً غیرخونی» یعنی «اغلب»، نه «همیشه» — و یک استثنا تشخیص را رد نمی‌کند وقتی "
    "زمینه این‌قدر قوی است.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**شیگلا:** پاتوژن اکتسابی از جامعه. بیمار **یک هفته است در بیمارستان است** — کجا "
    "شیگلا گرفته؟ زمینه‌ی اپیدمیولوژیک وجود ندارد.\n\n"
    "**روتاویروس:** عمدتاً بیماری **کودکان** است و **اسهال آبکی غیرالتهابی** می‌دهد — با "
    "گلبول سفید و قرمز فراوان در مدفوع هم‌خوان نیست.\n\n"
    "**کمپیلوباکتر ژژونی:** اسهال خونی می‌دهد، ولی باز هم **اکتسابی از جامعه** است (مرغ "
    "نیم‌پز، شیر غیرپاستوریزه). در بیمار بستری با آنتی‌بیوتیک، **کلستریدیوم دیفیسیل به‌مراتب "
    "محتمل‌تر است**.\n\n"
    "**درس: در تشخیص افتراقی، زمینه‌ی بیمار گاهی از تابلوی بالینی قوی‌تر است.**",
    "This question repeats the previous rule but adds AN APPARENT AMBIGUITY.\n\n"
    "THE PATIENT: a 65-year-old man admitted since last week for pneumonia, who now has fever, "
    "abdominal pain and diarrhoea. The stool shows both red and white cells.\n\n"
    "WARNING, THE SETTING MAKES THE DIAGNOSIS: a week in hospital plus antibiotic treatment for "
    "pneumonia.\n\n"
    "PNEUMONIA TREATMENT USUALLY INCLUDES A CEPHALOSPORIN OR A FLUOROQUINOLONE — and BOTH ARE AMONG THE "
    "THREE CLASSIC C. DIFFICILE TRIGGERS (alongside clindamycin).\n\n"
    "NOW THE APPARENT AMBIGUITY: this patient's stool also contains red cells.\n\n"
    "A STUDENT MAY THINK 'C. difficile diarrhoea is non-bloody, so this must be something else.' AND "
    "THAT REASONING IS WRONG.\n\n"
    "WARNING, C. DIFFICILE DIARRHOEA IS USUALLY NON-BLOODY — BUT IT CAN BE BLOODY. In SEVERE COLITIS, "
    "toxins A and B destroy the colonic mucosa so extensively that BLEEDING OCCURS. Abundant stool "
    "white cells are also entirely expected (inflammatory colitis).\n\n"
    "SO 'USUALLY NON-BLOODY' MEANS 'OFTEN', NOT 'ALWAYS' — and one exception does not exclude the "
    "diagnosis when the setting is this strong.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "SHIGELLA: a community-acquired pathogen. The patient HAS BEEN IN HOSPITAL FOR A WEEK — where would "
    "he have acquired Shigella? The epidemiological setting does not exist.\n\n"
    "ROTAVIRUS: mainly a disease OF CHILDREN, and it causes NON-INFLAMMATORY WATERY DIARRHOEA — "
    "inconsistent with abundant stool white and red cells.\n\n"
    "CAMPYLOBACTER JEJUNI: it does cause bloody diarrhoea, but it too is COMMUNITY-ACQUIRED "
    "(undercooked poultry, unpasteurised milk). In an inpatient on antibiotics, C. DIFFICILE IS FAR "
    "MORE LIKELY.\n\n"
    "THE LESSON: IN A DIFFERENTIAL DIAGNOSIS, THE PATIENT'S SETTING SOMETIMES OUTWEIGHS THE CLINICAL "
    "PICTURE.",
    ["پاتوژن اکتسابی از جامعه است؛ بیمار یک هفته است در بیمارستان است.",
     "عمدتاً بیماری کودکان است و اسهال آبکی غیرالتهابی می‌دهد.",
     "پاسخ صحیح — یک هفته بستری با آنتی‌بیوتیک پنومونی؛ و خونی بودن دیفیسیل را رد نمی‌کند.",
     "اسهال خونی می‌دهد ولی اکتسابی از جامعه است؛ در بیمار بستری دیفیسیل محتمل‌تر است."],
    ["A community-acquired pathogen; the patient has been in hospital for a week.",
     "Mainly a childhood disease causing non-inflammatory watery diarrhoea.",
     "Correct — a week in hospital on pneumonia antibiotics; and blood does not exclude C. difficile.",
     "Causes bloody diarrhoea but is community-acquired; in an inpatient C. difficile is far likelier."],
    "**«معمولاً غیرخونی» یعنی اغلب، نه همیشه — زمینه از تابلو قوی‌تر است.**",
    "'Usually non-bloody' means often, not always — the setting outweighs the picture.",
    CDREFS)

add("book:312", "vignette", "hard",
    "**حساس‌ترین روش تشخیص کلستریدیوم دیفیسیل، PCR برای ژن سم است.**",
    "The most SENSITIVE test for C. difficile is PCR for the toxin gene.",
    CD_FA + [
        "**این سؤال دقیقاً کلمه‌ی «حساس‌ترین» را می‌پرسد، پس ترتیب حساسیت را لازم داریم.**",
        "**PCR برای ژن سم: حساس‌ترین روش.**",
        "**چون ژن سم را در نمونه تکثیر و شناسایی می‌کند، حتی با بار کم.**",
        "⚠️ **تست EIA برای سم: اختصاصی‌تر ولی به‌مراتب کم‌حساس‌تر.**",
        "**کشت مدفوع: باکتری را می‌یابد ولی نمی‌گوید بیماری‌زا هست یا نه.**",
        "**چون سویه‌های بدون سم هم وجود دارند و کلونیزاسیون هم شایع است.**",
        "**کولونوسکوپی: کم‌حساس‌ترین، چون غشای کاذب در بسیاری از موارد وجود ندارد.**",
        "**و در ضمن تهاجمی است و در کولیت شدید خطر پرفوراسیون دارد.**",
    ],
    CD_EN + [
        "This question asks precisely for the MOST SENSITIVE, so we need the sensitivity ranking.",
        "PCR for the toxin gene: the MOST SENSITIVE method.",
        "Because it amplifies and detects the toxin gene even at low organism load.",
        "WARNING, EIA FOR TOXIN: more specific but far LESS sensitive.",
        "Stool culture: finds the bacterium but does not say whether it is pathogenic.",
        "Because non-toxigenic strains exist and colonisation is common.",
        "Colonoscopy: the LEAST sensitive, because pseudomembranes are absent in many cases.",
        "And it is invasive, carrying a perforation risk in severe colitis.",
    ],
    "این سؤال یک **کلمه** را می‌سنجد: **«حساس‌ترین»**. و همین کلمه پاسخ را تعیین می‌کند.\n\n"
    "**بیمار: ۷۰ ساله، چند روز پس از بستری برای پنومونی و تحت درمان با سفتریاکسون + "
    "اریترومایسین، دچار اسهال شده — ۵ تا ۶ بار در روز، بدون تب و بدون درد شکم. آزمایش مدفوع "
    "۱۰ تا ۱۲ گلبول سفید نشان داده و شمارش گلبول سفید و اوره و کراتینین طبیعی است.**\n\n"
    "**تشخیص روشن است: کلستریدیوم دیفیسیل** (بستری + آنتی‌بیوتیک + اسهال غیرخونی).\n\n"
    "⚠️ **حالا ترتیب حساسیت روش‌های تشخیصی را بدانید:**\n\n"
    "**۱ — PCR برای ژن سم (NAAT): حساس‌ترین.** ژن سم A یا B را **تکثیر و شناسایی** می‌کند، "
    "حتی وقتی بار باکتریایی پایین است. حساسیت آن بیش از ۹۰ درصد است.\n\n"
    "**۲ — کشت مدفوع:** باکتری را **می‌یابد** و حساسیت بالایی هم دارد، **ولی مشکل اساسی "
    "دارد**: ⚠️ **کشت نمی‌گوید که باکتری سم می‌سازد یا نه.** سویه‌های **بدون سم** وجود دارند، "
    "و مهم‌تر: **کلونیزاسیون بدون بیماری بسیار شایع است** — تا ۲۰ تا ۳۰ درصد بیماران بستری "
    "بدون هیچ علامتی کلونیزه‌اند. پس **کشت مثبت، بیماری را ثابت نمی‌کند.**\n\n"
    "**۳ — تست EIA برای سم A یا B:** **اختصاصی‌تر** است (سم را مستقیماً می‌یابد، نه فقط "
    "باکتری را)، ولی **حساسیت آن به‌مراتب پایین‌تر** است — حدود ۶۰ تا ۸۰ درصد. یعنی از هر "
    "پنج بیمار واقعی، یکی را از دست می‌دهد.\n\n"
    "**۴ — کولونوسکوپی: کم‌حساس‌ترین.** غشای کاذب فقط در بخشی از موارد دیده می‌شود؛ **بسیاری "
    "از بیماران واقعی کولونوسکوپی طبیعی دارند**. به‌علاوه **تهاجمی است** و در کولیت شدید "
    "**خطر پرفوراسیون** دارد.\n\n"
    "**پس پاسخ: PCR برای ژن توکسین A.**\n\n"
    "⚠️ **و نکته‌ی عملی مهم که ارزش دانستن دارد: چون PCR کلونیزاسیون را هم مثبت می‌کند، "
    "نباید در بیماری که اسهال ندارد درخواست شود.** راهبرد امروزی، **آزمون دومرحله‌ای** است: "
    "ابتدا یک آزمون حساس (PCR یا GDH)، سپس تأیید با آزمون اختصاصی سم (EIA). و **همیشه در "
    "بیماری که واقعاً اسهال دارد**.",
    "This question tests ONE WORD: 'MOST SENSITIVE'. And that word determines the answer.\n\n"
    "THE PATIENT: 70 years old, a few days after admission for pneumonia and on ceftriaxone plus "
    "erythromycin, develops diarrhoea — 5 to 6 times a day, without fever or abdominal pain. The stool "
    "shows 10 to 12 white cells and the blood count, urea and creatinine are normal.\n\n"
    "THE DIAGNOSIS IS CLEAR: C. DIFFICILE (admission plus antibiotics plus non-bloody diarrhoea).\n\n"
    "WARNING, NOW LEARN THE SENSITIVITY RANKING OF THE TESTS:\n\n"
    "1 — PCR FOR THE TOXIN GENE (NAAT): THE MOST SENSITIVE. It AMPLIFIES AND DETECTS the toxin A or B "
    "gene even at low bacterial load. Its sensitivity exceeds 90%.\n\n"
    "2 — STOOL CULTURE: it FINDS the bacterium and is highly sensitive, BUT IT HAS A FUNDAMENTAL "
    "PROBLEM: WARNING, CULTURE DOES NOT SAY WHETHER THE ORGANISM PRODUCES TOXIN. NON-TOXIGENIC strains "
    "exist, and more importantly ASYMPTOMATIC COLONISATION IS VERY COMMON — up to 20 to 30% of "
    "inpatients are colonised without symptoms. So A POSITIVE CULTURE DOES NOT PROVE DISEASE.\n\n"
    "3 — EIA FOR TOXIN A OR B: MORE SPECIFIC (it detects the toxin itself, not merely the bacterium), "
    "but ITS SENSITIVITY IS MUCH LOWER — about 60 to 80%. That is, it misses one in five genuine cases.\n\n"
    "4 — COLONOSCOPY: THE LEAST SENSITIVE. Pseudomembranes are seen in only a proportion of cases; MANY "
    "GENUINE PATIENTS HAVE A NORMAL COLONOSCOPY. It is also INVASIVE and carries A PERFORATION RISK in "
    "severe colitis.\n\n"
    "SO THE ANSWER: PCR FOR THE TOXIN A GENE.\n\n"
    "WARNING, AND AN IMPORTANT PRACTICAL POINT WORTH KNOWING: because PCR is also positive in "
    "colonisation, IT MUST NOT BE REQUESTED IN A PATIENT WITHOUT DIARRHOEA. The modern strategy is "
    "TWO-STEP TESTING: first a sensitive test (PCR or GDH), then confirmation with a specific toxin "
    "assay (EIA). And ALWAYS IN A PATIENT WHO GENUINELY HAS DIARRHOEA.",
    ["کم‌حساس‌ترین روش — غشای کاذب در بسیاری از موارد واقعی وجود ندارد، و تهاجمی هم هست.",
     "باکتری را می‌یابد ولی نمی‌گوید سم می‌سازد یا نه؛ کلونیزاسیون بدون بیماری شایع است.",
     "اختصاصی‌تر است ولی حساسیت آن حدود ۶۰ تا ۸۰ درصد است و موارد واقعی را از دست می‌دهد.",
     "پاسخ صحیح — PCR ژن سم را تکثیر می‌کند و حساس‌ترین روش با حساسیت بیش از ۹۰ درصد است."],
    ["The least sensitive — pseudomembranes are absent in many genuine cases, and it is invasive.",
     "Finds the bacterium but does not say whether it makes toxin; asymptomatic colonisation is common.",
     "More specific but only 60 to 80% sensitive, missing genuine cases.",
     "Correct — PCR amplifies the toxin gene and is the most sensitive method, over 90%."],
    "**کشت مثبت یعنی باکتری هست، نه اینکه بیماری هست.**",
    "A positive culture means the organism is present, not that disease is present.",
    CDREFS)

add("book:314", "recall", "medium",
    "**کولونوسکوپی کم‌حساس‌ترین روش است — چون غشای کاذب در بسیاری از موارد واقعی وجود ندارد.**",
    "Colonoscopy is the LEAST sensitive method — because pseudomembranes are absent in many genuine cases.",
    CD_FA + [
        "**این سؤال برعکس قبلی است: کم‌حساس‌ترین را می‌خواهد، نه حساس‌ترین.**",
        "**کشت مدفوع حساسیت بالایی دارد، هرچند اختصاصیت آن پایین است.**",
        "**PCR حساس‌ترین است.**",
        "**EIA حساسیت متوسطی دارد، حدود ۶۰ تا ۸۰ درصد.**",
        "⚠️ **و کولونوسکوپی برای رؤیت غشای کاذب، کمترین حساسیت را دارد.**",
        "**چون غشای کاذب فقط در بخشی از بیماران تشکیل می‌شود.**",
        "**بیمار می‌تواند عفونت قطعی داشته باشد و کولونوسکوپی کاملاً طبیعی.**",
        "**به‌علاوه غشای کاذب ممکن است فقط در کولون راست باشد و در سیگموئیدوسکوپی دیده نشود.**",
        "⚠️ **و کولونوسکوپی در کولیت شدید خطر پرفوراسیون دارد.**",
    ],
    CD_EN + [
        "This question is the reverse of the previous one: it wants the LEAST sensitive, not the most.",
        "Stool culture has high sensitivity, although its specificity is low.",
        "PCR is the most sensitive.",
        "EIA has intermediate sensitivity, about 60 to 80%.",
        "WARNING, AND COLONOSCOPY FOR PSEUDOMEMBRANES has the lowest sensitivity of all.",
        "Because pseudomembranes form in only a proportion of patients.",
        "A patient can have definite infection and a completely normal colonoscopy.",
        "Moreover the pseudomembranes may be confined to the right colon and missed at sigmoidoscopy.",
        "WARNING, AND COLONOSCOPY CARRIES A PERFORATION RISK in severe colitis.",
    ],
    "این سؤال **جفت متضاد** سؤال قبلی است: آنجا حساس‌ترین را خواست، اینجا **کم‌حساس‌ترین**.\n\n"
    "⚠️ **پاسخ: کولونوسکوپی جهت رؤیت غشای کاذب.**\n\n"
    "**چرا؟ سه دلیل مستقل:**\n\n"
    "**دلیل یک — غشای کاذب فقط در بخشی از بیماران تشکیل می‌شود.** کولیت پسودوممبران "
    "**شدیدترین شکل** بیماری است، نه شکل معمول آن. **بیمار می‌تواند عفونت قطعی کلستریدیوم "
    "دیفیسیل با اسهال و سم مثبت داشته باشد، و کولونوسکوپی او کاملاً طبیعی باشد.** پس یک "
    "کولونوسکوپی طبیعی **هیچ چیزی را رد نمی‌کند**.\n\n"
    "**دلیل دو — توزیع ناهمگون.** حتی وقتی غشای کاذب وجود دارد، ممکن است **فقط در کولون "
    "راست** باشد. **سیگموئیدوسکوپی** — که ساده‌تر و رایج‌تر است — آن را **از دست می‌دهد**.\n\n"
    "⚠️ **دلیل سه — و مهم‌ترین از نظر بالینی: خطر.** کولونوسکوپی در بیمار با **کولیت شدید یا "
    "مگاکولون توکسیک**، **خطر پرفوراسیون** دارد. یعنی نه‌فقط کم‌حساس، بلکه در بدترین بیماران "
    "**خطرناک** هم هست.\n\n"
    "**پس ترتیب حساسیت را کامل کنید:**\n\n"
    "**PCR (بیش از ۹۰٪) > کشت مدفوع (بالا، ولی اختصاصیت پایین) > EIA سم (۶۰ تا ۸۰٪) > "
    "کولونوسکوپی (کمترین)**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**کشت مدفوع:** **حساسیت بالایی دارد** — باکتری را به‌خوبی می‌یابد. مشکل آن **اختصاصیت** "
    "است، نه حساسیت (چون کلونیزاسیون را هم مثبت می‌کند). سؤال درباره‌ی **حساسیت** پرسیده.\n\n"
    "**PCR مدفوع:** **حساس‌ترین** روش است — دقیقاً برعکس آنچه سؤال می‌خواهد.\n\n"
    "**تست EIA:** حساسیت **متوسط** دارد (۶۰ تا ۸۰٪) — کمتر از PCR و کشت، ولی **بیشتر از "
    "کولونوسکوپی**.\n\n"
    "**پس کولونوسکوپی، ته فهرست است.**\n\n"
    "**نکته‌ی تکمیلی: پس کولونوسکوپی کِی جا دارد؟** وقتی **تشخیص نامشخص** است و باید "
    "بیماری‌های دیگر (مثل بیماری التهابی روده یا کولیت ایسکمیک) رد شوند، یا وقتی بیمار "
    "**ایلئوس** دارد و نمونه‌ی مدفوع در دسترس نیست.",
    "This question is THE MIRROR of the previous one: that asked for the most sensitive, this asks for "
    "THE LEAST.\n\n"
    "WARNING, THE ANSWER: COLONOSCOPY TO VISUALISE PSEUDOMEMBRANES.\n\n"
    "WHY? THREE INDEPENDENT REASONS:\n\n"
    "REASON ONE — PSEUDOMEMBRANES FORM IN ONLY A PROPORTION OF PATIENTS. Pseudomembranous colitis is "
    "THE SEVEREST FORM of the disease, not its usual form. A PATIENT CAN HAVE DEFINITE C. DIFFICILE "
    "INFECTION WITH DIARRHOEA AND A POSITIVE TOXIN, AND A COMPLETELY NORMAL COLONOSCOPY. So a normal "
    "colonoscopy EXCLUDES NOTHING.\n\n"
    "REASON TWO — PATCHY DISTRIBUTION. Even when pseudomembranes are present they may be CONFINED TO "
    "THE RIGHT COLON. SIGMOIDOSCOPY — which is simpler and commoner — MISSES THEM.\n\n"
    "WARNING, REASON THREE — AND THE MOST IMPORTANT CLINICALLY: RISK. In a patient with SEVERE COLITIS "
    "OR TOXIC MEGACOLON, colonoscopy carries A RISK OF PERFORATION. So it is not merely insensitive but, "
    "in the sickest patients, DANGEROUS.\n\n"
    "SO COMPLETE THE SENSITIVITY RANKING:\n\n"
    "PCR (over 90%) > STOOL CULTURE (high, but poor specificity) > TOXIN EIA (60 to 80%) > COLONOSCOPY "
    "(the lowest)\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "STOOL CULTURE: IT HAS HIGH SENSITIVITY — it finds the organism well. Its problem is SPECIFICITY, "
    "not sensitivity (because it is also positive in colonisation). The question asks about SENSITIVITY.\n\n"
    "STOOL PCR: THE MOST SENSITIVE method — exactly the opposite of what the question wants.\n\n"
    "EIA: INTERMEDIATE sensitivity (60 to 80%) — lower than PCR and culture, but HIGHER THAN COLONOSCOPY.\n\n"
    "SO COLONOSCOPY IS BOTTOM OF THE LIST.\n\n"
    "A CLOSING POINT: SO WHEN DOES COLONOSCOPY HAVE A PLACE? When THE DIAGNOSIS IS UNCERTAIN and other "
    "diseases (such as inflammatory bowel disease or ischaemic colitis) must be excluded, or when the "
    "patient has ILEUS and no stool sample is obtainable.",
    ["حساسیت بالایی دارد؛ مشکل آن اختصاصیت است نه حساسیت، چون کلونیزاسیون را هم مثبت می‌کند.",
     "حساس‌ترین روش است، دقیقاً برعکس آنچه سؤال می‌خواهد.",
     "حساسیت متوسط دارد (۶۰ تا ۸۰ درصد)، کمتر از PCR ولی بیشتر از کولونوسکوپی.",
     "پاسخ صحیح — غشای کاذب در بسیاری از موارد واقعی وجود ندارد، و کولونوسکوپی تهاجمی هم هست."],
    ["Highly sensitive; its problem is specificity rather than sensitivity, since colonisation is also positive.",
     "The most sensitive method, exactly the opposite of what the question wants.",
     "Intermediate sensitivity (60 to 80%), lower than PCR but higher than colonoscopy.",
     "Correct — pseudomembranes are absent in many genuine cases, and colonoscopy is invasive too."],
    "**کولونوسکوپی طبیعی، کلستریدیوم دیفیسیل را رد نمی‌کند.**",
    "A normal colonoscopy does not exclude C. difficile.",
    CDREFS)

add("book:313", "vignette", "medium",
    "**در تشخیص کلستریدیوم دیفیسیل، هر سه روش کمک می‌کنند — هر کدام از زاویه‌ای.**",
    "In diagnosing C. difficile, all three methods help — each from a different angle.",
    CD_FA + [
        "**زمینه‌ی این بیمار بسیار قوی است: سه هفته سیپروفلوکساسین و کلیندامایسین.**",
        "**کلیندامایسین کلاسیک‌ترین راه‌اندازنده‌ی کلستریدیوم دیفیسیل است.**",
        "⚠️ **و فلوروکینولون هم یکی از سه راه‌اندازنده‌ی اصلی است.**",
        "**پس دو عامل خطر بزرگ هم‌زمان و سه هفته مصرف.**",
        "**حالا سؤال می‌پرسد کدام روش به تشخیص کمک می‌کند.**",
        "**و پاسخ «همه‌ی موارد» است، چون هر کدام چیز متفاوتی نشان می‌دهد.**",
        "**کشت مدفوع: عوامل باکتریایی دیگر را رد می‌کند و باکتری را می‌یابد.**",
        "**PCR سم: بیماری‌زا بودن را ثابت می‌کند.**",
        "**و کولونوسکوپی: در صورت دیدن غشای کاذب، تشخیص را قطعی می‌کند.**",
        "⚠️ **کم‌حساس بودن یک روش، به معنای بی‌فایده بودن آن نیست.**",
    ],
    CD_EN + [
        "This patient's setting is very strong: three weeks of ciprofloxacin and clindamycin.",
        "Clindamycin is the most classic trigger of C. difficile.",
        "WARNING, AND A FLUOROQUINOLONE is another of the three main triggers.",
        "So two major risk factors together, over three weeks of use.",
        "Now the question asks which method helps with the diagnosis.",
        "And the answer is 'all of them', because each shows something different.",
        "Stool culture: excludes other bacterial causes and finds the organism.",
        "Toxin PCR: proves that the organism is toxigenic.",
        "And colonoscopy: if pseudomembranes are seen, it makes the diagnosis definitive.",
        "WARNING, A METHOD BEING INSENSITIVE DOES NOT MAKE IT USELESS.",
    ],
    "این سؤال یک نکته‌ی ظریف دارد: **کم‌حساس بودن یک روش، با بی‌فایده بودن آن یکی نیست.**\n\n"
    "**بیمار: خانم ۵۰ ساله‌ی دیابتی با استئومیلیت مهره‌های گردنی، تحت درمان با سیپروفلوکساسین "
    "+ کلیندامایسین. پس از سه هفته درمان، دچار تب، درد شکم و اسهال خونی شده. در آزمایش مدفوع "
    "گلبول قرمز ۲۰ تا ۳۰ و گلبول سفید فراوان.**\n\n"
    "⚠️ **زمینه فوق‌العاده قوی است:**\n\n"
    "**کلیندامایسین** — **کلاسیک‌ترین راه‌اندازنده‌ی کلستریدیوم دیفیسیل** در کل تاریخ این "
    "بیماری. **سیپروفلوکساسین** — فلوروکینولون‌ها یکی از **سه راه‌اندازنده‌ی اصلی**اند. و "
    "**سه هفته** مصرف هر دو با هم.\n\n"
    "**پس تشخیص محتمل: کلستریدیوم دیفیسیل.** (و یادآوری: اسهال خونی، دیفیسیل را رد نمی‌کند.)\n\n"
    "**حالا سؤال: کدام روش کمک می‌کند؟ پاسخ: همه‌ی موارد. و دلیل هر کدام متفاوت است:**\n\n"
    "**کشت مدفوع** — دو کار می‌کند. **یک:** کلستریدیوم دیفیسیل را می‌یابد. **دو — و مهم‌تر "
    "در این بیمار:** **سایر عوامل باکتریایی را رد می‌کند**. بیمار اسهال **خونی** دارد، و "
    "کشت می‌تواند شیگلا، سالمونلا و کمپیلوباکتر را نفی یا اثبات کند.\n\n"
    "**اندازه‌گیری توکسین با PCR** — این **حساس‌ترین** روش است و **بیماری‌زا بودن** را ثابت "
    "می‌کند (نه فقط حضور باکتری را).\n\n"
    "**کولونوسکوپی** — ⚠️ **درست است که کم‌حساس‌ترین است، ولی وقتی مثبت باشد، بسیار "
    "ارزشمند است.** **دیدن غشای کاذب، تشخیص را قطعی می‌کند** — اختصاصیت آن بسیار بالاست. "
    "به‌علاوه در این بیمار با **اسهال خونی**، کولونوسکوپی می‌تواند **تشخیص‌های دیگر** (بیماری "
    "التهابی روده، کولیت ایسکمیک) را هم بررسی کند.\n\n"
    "**پس تفاوت این سؤال با سؤال قبلی را دقت کنید:**\n\n"
    "**سؤال قبلی پرسید «کدام کم‌حساس‌تر است؟»** → پاسخ: کولونوسکوپی.\n\n"
    "**این سؤال می‌پرسد «کدام کمک می‌کند؟»** → پاسخ: همه، از جمله کولونوسکوپی.\n\n"
    "⚠️ **و این تفاوت مفهومی مهم است: حساسیت پایین یعنی «منفی بودنش چیزی را رد نمی‌کند»، نه "
    "«انجامش بی‌فایده است». آزمونی با حساسیت پایین ولی اختصاصیت بالا، وقتی مثبت شود بسیار "
    "قدرتمند است.**",
    "This question contains a subtle point: BEING INSENSITIVE IS NOT THE SAME AS BEING USELESS.\n\n"
    "THE PATIENT: a 50-year-old diabetic woman with cervical vertebral osteomyelitis, treated with "
    "ciprofloxacin plus clindamycin. After three weeks of treatment she develops fever, abdominal pain "
    "and bloody diarrhoea. Stool: red cells 20 to 30 and abundant white cells.\n\n"
    "WARNING, THE SETTING IS EXTRAORDINARILY STRONG:\n\n"
    "CLINDAMYCIN — THE MOST CLASSIC TRIGGER OF C. DIFFICILE in the entire history of the disease. "
    "CIPROFLOXACIN — fluoroquinolones are one of the THREE MAIN TRIGGERS. And THREE WEEKS of both "
    "together.\n\n"
    "SO THE LIKELY DIAGNOSIS: C. DIFFICILE. (And a reminder: bloody diarrhoea does not exclude it.)\n\n"
    "NOW THE QUESTION: which method helps? THE ANSWER: ALL OF THEM. And each for a different reason:\n\n"
    "STOOL CULTURE — it does two things. ONE: it finds C. difficile. TWO, AND MORE IMPORTANT IN THIS "
    "PATIENT: IT EXCLUDES OTHER BACTERIAL CAUSES. She has BLOODY diarrhoea, and culture can confirm or "
    "refute Shigella, Salmonella and Campylobacter.\n\n"
    "TOXIN MEASUREMENT BY PCR — this is THE MOST SENSITIVE method and it PROVES TOXIGENICITY (not "
    "merely the presence of the organism).\n\n"
    "COLONOSCOPY — WARNING, IT IS TRUE THAT IT IS THE LEAST SENSITIVE, BUT WHEN POSITIVE IT IS "
    "EXTREMELY VALUABLE. SEEING PSEUDOMEMBRANES MAKES THE DIAGNOSIS DEFINITIVE — its specificity is very "
    "high. Moreover in this patient with BLOODY diarrhoea, colonoscopy can also assess OTHER DIAGNOSES "
    "(inflammatory bowel disease, ischaemic colitis).\n\n"
    "SO NOTE THE DIFFERENCE BETWEEN THIS QUESTION AND THE PREVIOUS ONE:\n\n"
    "THE PREVIOUS QUESTION ASKED 'WHICH IS LESS SENSITIVE?' -> colonoscopy.\n\n"
    "THIS QUESTION ASKS 'WHICH HELPS?' -> all of them, including colonoscopy.\n\n"
    "WARNING, AND THAT CONCEPTUAL DIFFERENCE MATTERS: LOW SENSITIVITY MEANS 'A NEGATIVE RESULT EXCLUDES "
    "NOTHING', NOT 'IT IS POINTLESS TO DO'. A test with low sensitivity but high specificity is very "
    "powerful WHEN IT IS POSITIVE.",
    ["کمک می‌کند — هم دیفیسیل را می‌یابد و هم سایر عوامل باکتریایی را رد می‌کند.",
     "کمک می‌کند — دیدن غشای کاذب تشخیص را قطعی می‌کند و اختصاصیت بسیار بالایی دارد.",
     "کمک می‌کند — حساس‌ترین روش است و بیماری‌زا بودن باکتری را ثابت می‌کند.",
     "پاسخ صحیح — هر سه کمک می‌کنند، هر کدام از زاویه‌ای متفاوت."],
    ["Helps — it both finds C. difficile and excludes other bacterial causes.",
     "Helps — seeing pseudomembranes makes the diagnosis definitive, with very high specificity.",
     "Helps — the most sensitive method, and it proves the organism is toxigenic.",
     "Correct — all three help, each from a different angle."],
    "**حساسیت پایین یعنی «منفی‌اش چیزی را رد نمی‌کند»، نه «انجامش بی‌فایده است».**",
    "Low sensitivity means 'a negative excludes nothing', not 'it is pointless to do'.",
    CDREFS)

json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book47.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 47 lessons:', len(L))
