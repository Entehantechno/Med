# -*- coding: utf-8 -*-
"""Micro-lessons, batch 29 — endocarditis: treatment, monitoring and prophylaxis.

The second half of the chapter. Where batch 28 taught how to RECOGNISE and
COUNT, this batch teaches what to DO: which empirical regimen, for how long,
how to know it is working, and — the largest single block of questions in the
chapter — who actually needs antibiotic prophylaxis before a procedure.

THE PROPHYLAXIS BLOCK IS WHERE MOST MARKS ARE LOST
---------------------------------------------------
Nine questions in this chapter are prophylaxis questions, and they are all the
same question wearing different clothes. The examiner gives a patient with some
cardiac history and some procedure and asks what to give. Students answer by
recalling drugs. That is the wrong order and it loses marks.

The right order is a gate with two conditions, BOTH of which must be true
before any drug is even considered:

    1. Is this patient in one of the FOUR highest-risk cardiac groups?
    2. Is this procedure a DENTAL procedure involving gingiva, the periapical
       region, or perforation of the oral mucosa?

If either answer is no, the answer is NO PROPHYLAXIS, and no drug name is
correct. Three questions in this chapter (q9124, q9125, q9126) have exactly
that answer, and each one offers three plausible drugs as bait.

A NOTE ON CLINDAMYCIN, WHICH IS WHERE THIS BANK MUST BE HONEST
---------------------------------------------------------------
Three questions here (q9129, q9130, q9131) are keyed to CLINDAMYCIN as the
penicillin-allergic alternative. That was the correct answer under the 2007 AHA
guideline the exams were written against, and every other option offered in
those questions is worse, so the printed keys are NOT corrected.

But the 2021 AHA scientific statement WITHDREW clindamycin from endocarditis
prophylaxis entirely, because a single dose can cause Clostridioides difficile
colitis and its adverse-event rate is far higher than the alternatives
(13 fatal and 149 non-fatal reactions per million prescriptions, against 0 and
23 for amoxicillin). The current alternatives are cephalexin, azithromycin,
clarithromycin or doxycycline.

Quietly teaching clindamycin as current practice would be teaching outdated
medicine; quietly "correcting" the key would make the student fail the exam.
So the lessons do both jobs explicitly: they say what the exam wants AND that
the guideline has since moved, with the reason. A student who reads these
lessons can answer the question and also not harm a patient.

Numbers repaired before writing: the three doses in q9128; see
fix_endocarditis_numbers.py.

Reference: Wilson WR et al., "Prevention of Viridans Group Streptococcal
Infective Endocarditis: A Scientific Statement From the American Heart
Association", Circulation 2021;143:e963-e978; Baddour LM et al., Circulation
2015;132:1435-1486; Harrison's Principles of Internal Medicine, 21st ed (2022),
Ch. 128 (Infective Endocarditis).
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


WILSON = ("Wilson WR et al. — Prevention of Viridans Group Streptococcal Infective "
          "Endocarditis: A Scientific Statement From the American Heart Association. "
          "Circulation 2021;143(20):e963-e978")
BADDOUR = ("Baddour LM et al. — Infective Endocarditis in Adults: Diagnosis, Antimicrobial "
           "Therapy, and Management of Complications. Circulation 2015;132(15):1435-1486 "
           "(American Heart Association)")
H128 = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 128: "
        "Infective Endocarditis")

# ------------------------------------------------------------------ treatment
RX_FA = [
    "⚠️ **درمان اندوکاردیت را از سه سؤال بسازید: کدام دریچه، کدام ارگانیسم، و چند هفته.**",
    "**اصل اول و غیرقابل مذاکره: کشت خون پیش از اولین دوز آنتی‌بیوتیک.**",
    "**سه ست کشت از سه محل جدا** — چون پس از شروع دارو، شناسایی ارگانیسم بسیار سخت می‌شود.",
    "⚠️ **و اندوکاردیت، برخلاف مننژیت، معمولاً یک فوریت چنددقیقه‌ای نیست.**",
    "**در بیمار پایدار می‌توان چند ساعت صبر کرد تا کشت‌ها گرفته شوند** — این تفاوت مهمی است.",
    "**استثنا: بیمار سپتیک و ناپایدار، که در آن درمان تجربی فوراً پس از کشت شروع می‌شود.**",
    "**رژیم تجربی دریچه‌ی طبیعی: وانکومایسین (± سفتریاکسون).**",
    "⚠️ **رژیم تجربی دریچه‌ی مصنوعی: وانکومایسین + جنتامایسین + ریفامپین — هر سه.**",
    "**چرا سه دارو در دریچه‌ی مصنوعی؟ به‌خاطر بیوفیلم روی جسم خارجی.**",
    "⚠️ **ریفامپین تنها دارویی است که به داخل بیوفیلم نفوذ می‌کند** و باکتری چسبیده به پروتز را می‌کشد.",
    "**ولی ریفامپین هرگز تنها داده نمی‌شود** — مقاومت به‌سرعت پیدا می‌شود.",
    "**جنتامایسین برای سینرژی در دو هفته‌ی اول اضافه می‌شود.**",
    "**و نکته‌ی ترتیب: ریفامپین را پس از منفی شدن کشت خون اضافه کنید.**",
    "⚠️ **اگر ارگانیسم حساس به متی‌سیلین بود (MSSA)، وانکومایسین جای خود را می‌دهد:**",
    "**در MSSA، نافسیلین یا اگزاسیلین یا سفازولین از وانکومایسین مؤثرترند.**",
    "**وانکومایسین فقط برای MRSA یا آلرژی شدید به بتالاکتام است.**",
    "**مدت درمان: دریچه‌ی طبیعی معمولاً ۴ تا ۶ هفته؛ دریچه‌ی مصنوعی حداقل ۶ هفته.**",
    "⚠️ **و همه‌ی درمان وریدی است، نه خوراکی** — چون باید غلظت بالا و پایدار در وژتاسیون داشته باشیم.",
    "**وژتاسیون فاقد عروق است؛ دارو فقط با انتشار وارد آن می‌شود و باید غلظت خونی بالا بماند.**",
    "**اندیکاسیون‌های جراحی را هم بشناسید: نارسایی قلبی، عفونت کنترل‌نشده، آبسه‌ی حلقه،**",
    "**آمبولی مکرر با وژتاسیون بزرگ‌تر از ۱۰ میلی‌متر، و اندوکاردیت قارچی.**",
]
RX_EN = [
    "WARNING: BUILD ENDOCARDITIS TREATMENT FROM THREE QUESTIONS: WHICH VALVE, WHICH ORGANISM, HOW MANY WEEKS.",
    "FIRST AND NON-NEGOTIABLE PRINCIPLE: BLOOD CULTURES BEFORE THE FIRST ANTIBIOTIC DOSE.",
    "THREE SETS FROM THREE SEPARATE SITES — because after treatment starts the organism becomes very hard to identify.",
    "WARNING, AND UNLIKE MENINGITIS, ENDOCARDITIS IS USUALLY NOT A MINUTES-LEVEL EMERGENCY.",
    "IN A STABLE PATIENT YOU MAY WAIT SOME HOURS FOR CULTURES — an important difference.",
    "The exception is the septic, unstable patient, in whom empirical therapy starts immediately after cultures.",
    "EMPIRICAL REGIMEN FOR A NATIVE VALVE: VANCOMYCIN (plus or minus ceftriaxone).",
    "WARNING, EMPIRICAL REGIMEN FOR A PROSTHETIC VALVE: VANCOMYCIN PLUS GENTAMICIN PLUS RIFAMPICIN — all three.",
    "Why three drugs on a prosthetic valve? BECAUSE OF THE BIOFILM ON THE FOREIGN BODY.",
    "WARNING: RIFAMPICIN IS THE ONLY AGENT THAT PENETRATES BIOFILM and kills bacteria adherent to the prosthesis.",
    "But RIFAMPICIN IS NEVER GIVEN ALONE — resistance emerges rapidly.",
    "Gentamicin is added for synergy during the first two weeks.",
    "AND A POINT OF SEQUENCE: add the rifampicin once the blood cultures have turned negative.",
    "WARNING, IF THE ORGANISM IS METHICILLIN SENSITIVE (MSSA), VANCOMYCIN GIVES WAY:",
    "in MSSA, NAFCILLIN or OXACILLIN or CEFAZOLIN is MORE effective than vancomycin.",
    "Vancomycin is only for MRSA or severe beta-lactam allergy.",
    "DURATION: a native valve usually 4 to 6 weeks; a prosthetic valve at least 6 weeks.",
    "WARNING, AND ALL TREATMENT IS INTRAVENOUS, NOT ORAL — high, sustained concentrations must reach the vegetation.",
    "A vegetation has NO BLOOD SUPPLY; drug enters only by diffusion, so the blood level must stay high.",
    "KNOW THE SURGICAL INDICATIONS TOO: heart failure, uncontrolled infection, ring abscess,",
    "recurrent emboli with a vegetation larger than 10 mm, and fungal endocarditis.",
]

# ---------------------------------------------------------------- prophylaxis
PROPH_FA = [
    "⚠️ **پروفیلاکسی اندوکاردیت یک دروازه‌ی دوشرطی است. هر دو شرط باید برقرار باشند، وگرنه دارو بی‌معناست.**",
    "**شرط اول — آیا بیمار در یکی از چهار گروه پرخطر است؟ فقط همین چهار گروه:**",
    "**یک — دریچه‌ی مصنوعی** (یا هر ماده‌ی مصنوعی به‌کاررفته در ترمیم دریچه، از جمله TAVI).",
    "**دو — سابقه‌ی اندوکاردیت عفونی قبلی.**",
    "**سه — بیماری مادرزادی قلبی، ولی فقط سه حالت:**",
    "**سیانوتیک ترمیم‌نشده؛ ترمیم‌شده با ماده‌ی مصنوعی تا شش ماه؛ ترمیم‌شده با نقص باقی‌مانده.**",
    "**چهار — گیرنده‌ی پیوند قلب با والوپاتی.**",
    "⚠️ **و حالا آنچه دیگر پرخطر نیست و در سؤال‌ها مدام به‌عنوان دام می‌آید:**",
    "**بیماری دریچه‌ای روماتیسمی، پرولاپس میترال، بای‌پس کرونر (CABG)، و نقص مادرزادیِ کاملاً ترمیم‌شده پس از شش ماه.**",
    "**هیچ‌کدام از این‌ها پروفیلاکسی نمی‌گیرند.**",
    "**شرط دوم — آیا پروسیجر، دندانیِ تهاجمی است؟**",
    "**یعنی دستکاری لثه، ناحیه‌ی پری‌اپیکال دندان، یا سوراخ شدن مخاط دهان.**",
    "⚠️ **و این‌ها پروفیلاکسی نمی‌خواهند: آندوسکوپی گوارشی، کولونوسکوپی، برونکوسکوپی،**",
    "**سیستوسکوپی، زایمان طبیعی، و رادیوگرافی یا تزریق بی‌حسی معمولی دندان.**",
    "**اگر هر یک از دو شرط برقرار نباشد، پاسخ «نیازی به پروفیلاکسی نیست» است.**",
    "**رژیم استاندارد: آموکسی‌سیلین ۲ گرم خوراکی، ۳۰ تا ۶۰ دقیقه پیش از پروسیجر، تک‌دوز.**",
    "**اگر خوراکی ممکن نیست: آمپی‌سیلین ۲ گرم عضلانی یا وریدی.**",
    "⚠️ **در آلرژی به پنی‌سیلین: سفالکسین ۲ گرم، یا آزیترومایسین یا کلاریترومایسین ۵۰۰ میلی‌گرم، یا داکسی‌سیکلین ۱۰۰ میلی‌گرم.**",
    "**ولی سفالوسپورین در آلرژی آنافیلاکتیک ممنوع است** (خطر واکنش متقاطع).",
    "⚠️ **و یک به‌روزرسانی مهم: بیانیه‌ی ۲۰۲۱ انجمن قلب آمریکا کلیندامایسین را کنار گذاشت.**",
    "**دلیلش کولیت کلستریدیوم دیفیسیل حتی با یک دوز، و میزان عوارض به‌مراتب بالاتر از جایگزین‌هاست.**",
    "**در سؤال‌های قدیمی‌تر کلیندامایسین هنوز پاسخ کلید است؛ ولی در بالین امروز جای آن را ماکرولید یا سفالکسین گرفته است.**",
]
PROPH_EN = [
    "WARNING: ENDOCARDITIS PROPHYLAXIS IS A TWO-CONDITION GATE. BOTH must hold, or no drug makes sense.",
    "CONDITION ONE — IS THE PATIENT IN ONE OF THE FOUR HIGHEST-RISK GROUPS? Only these four:",
    "ONE — A PROSTHETIC VALVE (or any prosthetic material used in valve repair, including TAVI).",
    "TWO — PREVIOUS INFECTIVE ENDOCARDITIS.",
    "THREE — CONGENITAL HEART DISEASE, but only in three situations:",
    "unrepaired cyanotic disease; repaired with prosthetic material within six months; repaired with a residual defect.",
    "FOUR — A CARDIAC TRANSPLANT RECIPIENT WITH VALVULOPATHY.",
    "WARNING, AND NOW WHAT IS NO LONGER HIGH RISK, WHICH THE QUESTIONS USE REPEATEDLY AS BAIT:",
    "RHEUMATIC VALVULAR DISEASE, MITRAL VALVE PROLAPSE, CORONARY BYPASS (CABG), and a fully repaired congenital defect after six months.",
    "NONE OF THESE RECEIVE PROPHYLAXIS.",
    "CONDITION TWO — IS THE PROCEDURE AN INVASIVE DENTAL ONE?",
    "That means manipulation of gingiva, of the periapical region of a tooth, or perforation of the oral mucosa.",
    "WARNING, AND THESE DO NOT REQUIRE PROPHYLAXIS: GI ENDOSCOPY, COLONOSCOPY, BRONCHOSCOPY,",
    "cystoscopy, normal vaginal delivery, and routine dental radiographs or anaesthetic injections.",
    "IF EITHER CONDITION FAILS, THE ANSWER IS 'NO PROPHYLAXIS NEEDED'.",
    "STANDARD REGIMEN: AMOXICILLIN 2 G ORALLY, 30 TO 60 MINUTES BEFORE THE PROCEDURE, SINGLE DOSE.",
    "If oral is not possible: ampicillin 2 g intramuscularly or intravenously.",
    "WARNING, IN PENICILLIN ALLERGY: cephalexin 2 g, or azithromycin or clarithromycin 500 mg, or doxycycline 100 mg.",
    "But A CEPHALOSPORIN IS FORBIDDEN IN ANAPHYLACTIC ALLERGY (cross-reaction risk).",
    "WARNING, AND AN IMPORTANT UPDATE: THE 2021 AHA SCIENTIFIC STATEMENT WITHDREW CLINDAMYCIN.",
    "The reason is Clostridioides difficile colitis even after a single dose, and an adverse-event rate far above the alternatives.",
    "In older exam questions clindamycin is still the keyed answer; but in today's practice a macrolide or cephalexin has replaced it.",
]


# =========================================================== book:103 — NOT WRITTEN
# book:103 already has a lesson, in lessons_book2.json, written when the sepsis
# batch covered blood-culture interpretation. A draft of this batch re-taught
# it, and apply_lessons.py's anti-duplication assertion rejected the file:
#
#   AssertionError: lessons_book29.json redefines lessons already written:
#   ['book:103']
#
# That guard earned its place here. The duplicate would not have crashed
# anything; it would have silently overwritten a good lesson with a second
# version of the same content, and the only visible symptom would have been
# that the bank's lesson count stopped matching the number of lessons written.
# The replacement below teaches q9121 instead, which was genuinely untaught.

# =========================================================== book:119
add("book:119", "recall", "medium",
 "استاف اورئوس روی **دریچه‌ی طبیعی** بدون عارضه ← **۴ تا ۶ هفته** درمان وریدی.",
 "S. aureus on a NATIVE valve without complications: FOUR TO SIX WEEKS of intravenous therapy.",
 RX_FA + [
  "⚠️ **مدت درمان را با سه متغیر تعیین کنید: نوع دریچه، ارگانیسم، و وجود عارضه.**",
  "**دریچه‌ی طبیعی + استاف اورئوس + بدون عارضه ← ۴ تا ۶ هفته.**",
  "**دریچه‌ی طبیعی + استرپتوکوک ویریدنس حساس ← ۴ هفته (و با جنتامایسین می‌توان ۲ هفته کرد).**",
  "**دریچه‌ی مصنوعی، هر ارگانیسمی ← حداقل ۶ هفته.**",
  "⚠️ **چرا این‌قدر طولانی؟ به‌خاطر ساختار خودِ وژتاسیون.**",
  "**وژتاسیون از فیبرین و پلاکت ساخته شده و هیچ رگ خونی ندارد.**",
  "**باکتری در عمق آن با تراکم بسیار بالا و متابولیسم بسیار کند زندگی می‌کند.**",
  "**آنتی‌بیوتیک فقط با انتشار وارد می‌شود، و باکتری کم‌متابولیسم به آن کم پاسخ می‌دهد.**",
  "⚠️ **پس اصل: درمان باید طولانی، وریدی، و با دوز بالا باشد — هر سه با هم.**",
  "**درمان خوراکی یا کوتاه‌مدت، عود می‌دهد و عود اندوکاردیت خطرناک‌تر از حمله‌ی اول است.**",
  "**و شمارش هفته‌ها از روزی شروع می‌شود که کشت خون منفی شد، نه از روز بستری.**",
 ],
 RX_EN + [
  "WARNING: SET THE DURATION FROM THREE VARIABLES — valve type, organism, and complications.",
  "NATIVE VALVE + S. AUREUS + NO COMPLICATIONS: FOUR TO SIX WEEKS.",
  "Native valve + sensitive viridans streptococci: 4 weeks (and 2 weeks is possible with gentamicin).",
  "PROSTHETIC VALVE, ANY ORGANISM: AT LEAST SIX WEEKS.",
  "WARNING, WHY SO LONG? BECAUSE OF THE STRUCTURE OF THE VEGETATION ITSELF.",
  "A vegetation is made of fibrin and platelets and HAS NO BLOOD VESSELS.",
  "Bacteria deep inside it live at very high density and very low metabolic rate.",
  "Antibiotic enters only by diffusion, and slow-metabolising bacteria respond poorly to it.",
  "WARNING, HENCE THE PRINCIPLE: therapy must be LONG, INTRAVENOUS AND HIGH-DOSE — all three together.",
  "Oral or short therapy relapses, and a relapse of endocarditis is more dangerous than the first attack.",
  "And the weeks are counted from the day the blood cultures turned negative, not from admission.",
 ],
 "یک سؤال مستقیم درباره‌ی مدت درمان، ولی منطق پشتش ارزش یاد گرفتن دارد.\n\n"
 "**داده‌ها:** کشت خون **استافیلوکوک اورئوس** · **حال عمومی خوب** · **هیچ عارضه‌ای ندارد** · "
 "و در صورت سؤال **هیچ اشاره‌ای به دریچه‌ی مصنوعی نیست** — یعنی دریچه‌ی طبیعی.\n\n"
 "**پاسخ: ۴ تا ۶ هفته درمان وریدی.**\n\n"
 "⚠️ **حالا منطق، که مهم‌تر از خودِ عدد است: چرا این‌قدر طولانی؟**\n\n"
 "**وژتاسیون یک محیط بی‌نظیر و بسیار نامساعد برای آنتی‌بیوتیک است:**\n\n"
 "• **رگ خونی ندارد.** از فیبرین و پلاکت ساخته شده و دارو فقط با **انتشار (diffusion)** "
 "می‌تواند به عمق آن نفوذ کند.\n\n"
 "• **تراکم باکتری در آن فوق‌العاده بالاست** (تا ۱۰ به توان ۹ در هر گرم).\n\n"
 "• **باکتری‌های عمقی متابولیسم بسیار کندی دارند**، و بیشتر آنتی‌بیوتیک‌ها روی باکتری "
 "در حال تقسیم بهتر کار می‌کنند.\n\n"
 "این سه با هم توضیح می‌دهند که چرا درمان باید **طولانی، وریدی و پرقدرت** باشد. "
 "**درمان خوراکی یا کوتاه، باکتری عمقی را زنده می‌گذارد و بیماری عود می‌کند.**\n\n"
 "**جدول مدت درمان که باید حفظ کنید:**\n\n"
 "• **دریچه‌ی طبیعی، ویریدنس حساس:** ۴ هفته (یا ۲ هفته با افزودن جنتامایسین)\n"
 "• **دریچه‌ی طبیعی، استاف اورئوس:** ۴ تا ۶ هفته\n"
 "• **دریچه‌ی مصنوعی، هر ارگانیسمی:** حداقل ۶ هفته\n\n"
 "⚠️ **و یک نکته‌ی عملی که زیاد فراموش می‌شود: شمارش هفته‌ها از روز منفی شدن کشت خون "
 "آغاز می‌شود، نه از روز بستری یا روز شروع دارو.**",
 "A direct question about duration, but the logic behind it is worth learning.\n\n"
 "THE DATA: blood cultures grow STAPHYLOCOCCUS AUREUS · the patient is WELL · there are NO "
 "COMPLICATIONS · and the stem mentions NO PROSTHETIC VALVE — so this is a native valve.\n\n"
 "THE ANSWER: FOUR TO SIX WEEKS of intravenous therapy.\n\n"
 "WARNING, NOW THE LOGIC, WHICH MATTERS MORE THAN THE NUMBER: WHY SO LONG?\n\n"
 "A VEGETATION IS A UNIQUELY HOSTILE ENVIRONMENT FOR AN ANTIBIOTIC:\n\n"
 "• IT HAS NO BLOOD SUPPLY. Built of fibrin and platelets, drug reaches its depths only by "
 "DIFFUSION.\n\n"
 "• BACTERIAL DENSITY INSIDE IS ENORMOUS (up to 10^9 per gram).\n\n"
 "• THE DEEP BACTERIA ARE METABOLICALLY VERY SLOW, and most antibiotics work best on dividing "
 "organisms.\n\n"
 "Together these explain why treatment must be LONG, INTRAVENOUS AND HIGH-DOSE. Oral or short "
 "courses leave the deep bacteria alive and the disease relapses.\n\n"
 "THE DURATION TABLE TO MEMORISE:\n\n"
 "• Native valve, sensitive viridans: 4 weeks (or 2 weeks with added gentamicin)\n"
 "• Native valve, S. aureus: 4 to 6 weeks\n"
 "• Prosthetic valve, any organism: at least 6 weeks\n\n"
 "WARNING, AND A PRACTICAL POINT OFTEN FORGOTTEN: THE WEEKS ARE COUNTED FROM THE DAY THE BLOOD "
 "CULTURES TURN NEGATIVE, not from admission or from the first dose.",
 ["۶ تا ۸ هفته برای دریچه‌ی مصنوعی یا موارد عارضه‌دار است، نه دریچه‌ی طبیعیِ بدون عارضه.",
  "۲ تا ۴ هفته برای استاف اورئوس کافی نیست و خطر عود بالایی دارد.",
  "پاسخ صحیح — استاف اورئوس روی دریچه‌ی طبیعی بدون عارضه: ۴ تا ۶ هفته وریدی.",
  "۸ تا ۱۲ هفته در هیچ پروتکل استانداردی برای این وضعیت توصیه نشده است."],
 ["Six to eight weeks is for prosthetic valves or complicated cases, not an uncomplicated native valve.",
  "Two to four weeks is inadequate for S. aureus and carries a high relapse risk.",
  "Correct — S. aureus on a native valve without complications: 4 to 6 weeks intravenously.",
  "Eight to twelve weeks is not recommended in any standard protocol for this situation."],
 "**وژتاسیون رگ ندارد؛ دارو فقط با انتشار می‌رسد.** پس درمان طولانی، وریدی و پرقدرت.",
 "A vegetation has no blood supply and drug arrives only by diffusion, so therapy is long, intravenous and high-dose.",
 [BADDOUR, H128])


# =========================================================== book:120
add("book:120", "case", "hard",
 "**دریچه‌ی مصنوعی + MRSA** ← **وانکومایسین + جنتامایسین + ریفامپین**؛ ریفامپین به‌خاطر بیوفیلم.",
 "A PROSTHETIC VALVE with MRSA: VANCOMYCIN PLUS GENTAMICIN PLUS RIFAMPICIN — the rifampicin is for the biofilm.",
 RX_FA + [
  "⚠️ **دو کلمه رژیم را می‌سازند: «دریچه‌ی مصنوعی» و «مقاوم به متی‌سیلین».**",
  "**«مقاوم به متی‌سیلین» یعنی هیچ بتالاکتامی کار نمی‌کند** — نه اگزاسیلین، نه نافسیلین، نه سفازولین.",
  "**پس پایه‌ی رژیم اجباراً وانکومایسین است.** این دو گزینه‌ی حاوی اگزاسیلین را حذف می‌کند.",
  "⚠️ **حالا سؤال باقی‌مانده: چرا وانکومایسین + جنتامایسین کافی نیست؟**",
  "**چون بیمار یک جسم خارجی در قلب دارد، و روی جسم خارجی بیوفیلم تشکیل می‌شود.**",
  "**بیوفیلم یک لایه‌ی پلی‌ساکاریدی است که باکتری زیر آن پناه می‌گیرد.**",
  "⚠️ **باکتری داخل بیوفیلم تا هزار برابر به آنتی‌بیوتیک مقاوم‌تر است** — نه با مقاومت ژنتیکی، بلکه با پناه فیزیکی.",
  "**وانکومایسین مولکول بزرگی است و نفوذ ضعیفی به بیوفیلم دارد.**",
  "**ریفامپین تنها داروی این رژیم است که واقعاً وارد بیوفیلم می‌شود و استاف چسبیده را می‌کشد.**",
  "**به همین دلیل در هر عفونت پروتز (دریچه، مفصل مصنوعی، شانت) ریفامپین جای ویژه‌ای دارد.**",
  "⚠️ **ولی ریفامپین هرگز تنها نمی‌رود:** مقاومت به آن **در عرض چند روز** پیدا می‌شود.",
  "**جنتامایسین برای سینرژی، معمولاً در دو هفته‌ی نخست، اضافه می‌شود.**",
  "**و ترتیب مهم است: ریفامپین را پس از منفی شدن کشت خون شروع کنید تا مقاومت پیدا نشود.**",
 ],
 RX_EN + [
  "WARNING: TWO PHRASES BUILD THE REGIMEN — 'prosthetic valve' and 'methicillin resistant'.",
  "'METHICILLIN RESISTANT' MEANS NO BETA-LACTAM WORKS — not oxacillin, not nafcillin, not cefazolin.",
  "So the backbone must be VANCOMYCIN. That eliminates the two options containing oxacillin.",
  "WARNING, THE REMAINING QUESTION: why is vancomycin plus gentamicin not enough?",
  "Because the patient has A FOREIGN BODY IN THE HEART, and foreign bodies grow BIOFILM.",
  "Biofilm is a polysaccharide layer under which bacteria shelter.",
  "WARNING: BACTERIA INSIDE BIOFILM ARE UP TO A THOUSAND TIMES MORE RESISTANT — not genetically, but by physical shelter.",
  "Vancomycin is a large molecule and penetrates biofilm poorly.",
  "RIFAMPICIN IS THE ONLY AGENT IN THIS REGIMEN THAT TRULY ENTERS BIOFILM and kills the adherent staphylococci.",
  "That is why rifampicin has a special place in every prosthesis infection — valve, joint or shunt.",
  "WARNING, BUT RIFAMPICIN NEVER GOES ALONE: resistance to it emerges WITHIN DAYS.",
  "Gentamicin is added for synergy, usually for the first two weeks.",
  "And the order matters: start the rifampicin after the blood cultures have turned negative, to avoid resistance.",
 ],
 "این سؤال یکی از مهم‌ترین مفاهیم عفونی را می‌سنجد: **بیوفیلم**.\n\n"
 "**آقای ۵۶ ساله** با **دریچه‌ی میترال مصنوعی از ده سال پیش**، تب و لرز یک‌هفته‌ای، "
 "**وژتاسیون روی دریچه‌ی مصنوعی** در اکو، و کشت خون: **استافیلوکوکوس اورئوس مقاوم به "
 "متی‌سیلین (MRSA)**.\n\n"
 "**گام یک — حذف بتالاکتام‌ها.** «مقاوم به متی‌سیلین» یعنی مکانیسم مقاومت، تغییر در "
 "**PBP2a** است و **هیچ بتالاکتامی** روی آن کار نمی‌کند. پس **اگزاسیلین در هر ترکیبی "
 "غلط است** و دو گزینه فوراً حذف می‌شوند. پایه‌ی رژیم **وانکومایسین** است.\n\n"
 "**گام دو — و اینجاست که سؤال واقعی مطرح می‌شود: چرا «وانکومایسین + جنتامایسین» کافی نیست؟**\n\n"
 "⚠️ **پاسخ در یک کلمه است: بیوفیلم.**\n\n"
 "بیمار یک **جسم خارجی** در قلبش دارد. استافیلوکوک‌ها روی سطح پروتز یک لایه‌ی "
 "**پلی‌ساکاریدی (بیوفیلم)** می‌سازند و زیر آن پناه می‌گیرند. باکتری داخل بیوفیلم:\n\n"
 "• **متابولیسم بسیار کندی دارد** (پس به داروهای وابسته به تقسیم سلولی کم پاسخ می‌دهد)\n"
 "• **از نظر فیزیکی از دارو محافظت می‌شود**\n"
 "• **تا هزار برابر مقاوم‌تر رفتار می‌کند** — بدون هیچ تغییر ژنتیکی\n\n"
 "**وانکومایسین مولکول بزرگی است و نفوذ ضعیفی به بیوفیلم دارد. ریفامپین برعکس، به‌خوبی "
 "نفوذ می‌کند و باکتری چسبیده به پروتز را می‌کشد.** بدون ریفامپین، درمان معمولاً شکست "
 "می‌خورد و دریچه باید تعویض شود.\n\n"
 "⚠️ **دو هشدار عملی درباره‌ی ریفامپین:**\n\n"
 "**یک — هرگز تنها داده نمی‌شود.** مقاومت به ریفامپین در تک‌درمانی ظرف چند روز پیدا می‌شود.\n\n"
 "**دو — ترتیب شروع مهم است.** توصیه می‌شود ریفامپین **پس از منفی شدن کشت خون** اضافه شود، "
 "چون افزودن آن در زمان باکتریمی شدید، خطر ظهور مقاومت را بالا می‌برد.\n\n"
 "**جنتامایسین هم برای سینرژی، معمولاً در دو هفته‌ی اول، در رژیم است.**",
 "This question tests one of the most important concepts in infectious disease: BIOFILM.\n\n"
 "A 56-YEAR-OLD MAN with a PROSTHETIC MITRAL VALVE placed ten years ago, a week of fever and "
 "rigors, A VEGETATION ON THE PROSTHETIC VALVE on echo, and blood cultures growing "
 "METHICILLIN-RESISTANT STAPHYLOCOCCUS AUREUS (MRSA).\n\n"
 "STEP ONE — ELIMINATE THE BETA-LACTAMS. 'Methicillin resistant' means the resistance mechanism "
 "is altered PBP2a, and NO BETA-LACTAM works against it. So OXACILLIN IN ANY COMBINATION IS "
 "WRONG and two options fall immediately. The backbone is VANCOMYCIN.\n\n"
 "STEP TWO — AND HERE IS THE REAL QUESTION: why is 'vancomycin plus gentamicin' not enough?\n\n"
 "WARNING, THE ANSWER IS ONE WORD: BIOFILM.\n\n"
 "The patient has A FOREIGN BODY in his heart. Staphylococci build a POLYSACCHARIDE LAYER "
 "(biofilm) on the prosthesis surface and shelter beneath it. Bacteria inside biofilm:\n\n"
 "• are METABOLICALLY VERY SLOW (so they respond poorly to division-dependent drugs)\n"
 "• are PHYSICALLY SHIELDED from the drug\n"
 "• behave as much as A THOUSAND TIMES MORE RESISTANT — with no genetic change at all\n\n"
 "VANCOMYCIN IS A LARGE MOLECULE AND PENETRATES BIOFILM POORLY. RIFAMPICIN, BY CONTRAST, "
 "PENETRATES IT WELL and kills the prosthesis-adherent organisms. Without rifampicin, treatment "
 "usually fails and the valve must be replaced.\n\n"
 "WARNING, TWO PRACTICAL CAUTIONS ABOUT RIFAMPICIN:\n\n"
 "ONE — IT IS NEVER GIVEN ALONE. Resistance emerges within days in monotherapy.\n\n"
 "TWO — THE ORDER MATTERS. Rifampicin is best added AFTER THE BLOOD CULTURES HAVE TURNED "
 "NEGATIVE, because adding it during heavy bacteraemia raises the risk of resistance emerging.\n\n"
 "Gentamicin is in the regimen for synergy, usually for the first two weeks.",
 ["اگزاسیلین روی MRSA بی‌اثر است؛ مقاومت به متی‌سیلین یعنی همه‌ی بتالاکتام‌ها حذف می‌شوند.",
  "بدون ریفامپین، باکتری داخل بیوفیلمِ دریچه‌ی مصنوعی زنده می‌ماند و درمان شکست می‌خورد.",
  "اگزاسیلین به‌تنهایی هم روی MRSA بی‌اثر است و هم پوشش بیوفیلم ندارد.",
  "پاسخ صحیح — دریچه‌ی مصنوعی و MRSA: وانکومایسین + جنتامایسین + ریفامپین."],
 ["Oxacillin is inactive against MRSA; methicillin resistance rules out every beta-lactam.",
  "Without rifampicin the bacteria inside the prosthetic-valve biofilm survive and treatment fails.",
  "Oxacillin alone is both inactive against MRSA and without any biofilm cover.",
  "Correct — prosthetic valve plus MRSA: vancomycin plus gentamicin plus rifampicin."],
 "**جسم خارجی = بیوفیلم = ریفامپین.** و ریفامپین هرگز تنها نمی‌رود.",
 "A foreign body means biofilm, and biofilm means rifampicin; rifampicin never goes alone.",
 [BADDOUR, H128])


# =========================================================== book:123
add("book:123", "case", "medium",
 "پایش پاسخ به درمان در اندوکاردیت: **کشت خون روزانه تا منفی شدن**، نه تکرار اکو.",
 "Monitoring the response in endocarditis: DAILY BLOOD CULTURES UNTIL THEY CLEAR, not a repeat echo.",
 RX_FA + [
  "⚠️ **این سؤال یک اشتباه رایج را هدف گرفته: تکرار اکو برای سنجیدن پاسخ به درمان.**",
  "**پاسخ میکروبیولوژیک را با کشت خون می‌سنجند، نه با تصویربرداری.**",
  "**هدف درمان، استریل کردن خون است، و تنها معیار مستقیمش کشت خون است.**",
  "**پس کشت خون را روزانه تکرار کنید تا منفی شود.**",
  "⚠️ **و منفی شدن کشت، نقطه‌ی شروع شمارش مدت درمان است** — نه روز بستری.",
  "**باکتریمی پایدار پس از ۳ تا ۵ روز درمان مناسب، یک علامت هشدار جدی است:**",
  "**یعنی یا آبسه‌ی حلقه‌ی دریچه، یا کانون متاستاتیک، یا شکست رژیم دارویی.**",
  "**و همین وضعیت، یکی از اندیکاسیون‌های جراحی است (عفونت کنترل‌نشده).**",
  "⚠️ **حالا چرا تکرار زودهنگام اکو غلط است؟ چون وژتاسیون سریع آب نمی‌شود.**",
  "**وژتاسیون ممکن است هفته‌ها تا ماه‌ها باقی بماند، حتی در درمان کاملاً موفق.**",
  "**و گاهی در ابتدا حتی بزرگ‌تر هم دیده می‌شود.** پس اندازه‌ی آن معیار موفقیت نیست.",
  "**اکوی مجدد اندیکاسیون خودش را دارد: تب پایدار، سوفل تازه، نارسایی قلبی، یا شک به آبسه.**",
 ],
 RX_EN + [
  "WARNING: THIS QUESTION TARGETS A COMMON ERROR — repeating the echo to judge the response.",
  "THE MICROBIOLOGICAL RESPONSE IS MEASURED BY BLOOD CULTURES, NOT BY IMAGING.",
  "The aim of treatment is to sterilise the blood, and the only direct measure of that is a blood culture.",
  "SO REPEAT BLOOD CULTURES DAILY UNTIL THEY BECOME NEGATIVE.",
  "WARNING, AND CULTURE CLEARANCE IS THE STARTING POINT FOR COUNTING THE DURATION — not the admission date.",
  "PERSISTENT BACTERAEMIA AFTER 3 TO 5 DAYS OF APPROPRIATE THERAPY IS A SERIOUS WARNING SIGN:",
  "it means either a valve-ring abscess, a metastatic focus, or failure of the regimen.",
  "And that situation is itself a surgical indication (uncontrolled infection).",
  "WARNING, NOW WHY IS AN EARLY REPEAT ECHO WRONG? BECAUSE A VEGETATION DOES NOT MELT AWAY QUICKLY.",
  "A vegetation may persist for weeks or months even when treatment is completely successful.",
  "It may even look LARGER at first. So its size is not a measure of success.",
  "A repeat echo has its own indications: persistent fever, a new murmur, heart failure, or suspected abscess.",
 ],
 "سؤالی درباره‌ی **پایش درمان**، که یک خطای مفهومی شایع را هدف گرفته است.\n\n"
 "**خانم ۴۵ ساله** با وژتاسیون ۰/۵ سانتی‌متری میترال و **کشت خون مثبت در دو نوبت برای "
 "استاف اورئوس**. درمان مناسب بر اساس آنتی‌بیوگرام شروع شده. **حالا چطور بفهمیم درمان "
 "کار می‌کند؟**\n\n"
 "⚠️ **پاسخ: کشت خون روزانه تا منفی شدن آن.**\n\n"
 "**چرا؟ چون هدف درمان، استریل کردن جریان خون است، و تنها سنجه‌ی مستقیمِ آن، خودِ کشت خون "
 "است.** هیچ تصویری این را نمی‌گوید.\n\n"
 "**و این پایش سه فایده‌ی مشخص دارد:**\n\n"
 "**یک — تعیین نقطه‌ی شروع شمارش.** مدت درمان (۴ تا ۶ هفته) از **روز منفی شدن کشت** شمرده "
 "می‌شود، نه از روز بستری. بدون کشت روزانه، این روز را نمی‌دانید.\n\n"
 "**دو — کشف شکست درمان.** اگر کشت پس از **۳ تا ۵ روز** درمان مناسب همچنان مثبت بماند، "
 "این یک **زنگ خطر جدی** است: احتمالاً **آبسه‌ی حلقه‌ی دریچه**، یک **کانون متاستاتیک** "
 "(مثل آبسه‌ی طحال یا اسپوندیلودیسیت)، یا شکست رژیم دارویی وجود دارد. "
 "**باکتریمی پایدار خودش یکی از اندیکاسیون‌های جراحی است.**\n\n"
 "**سه — تأیید کفایت رژیم انتخابی.**\n\n"
 "⚠️ **و حالا چرا تکرار اکو در ۴۸ یا ۷۲ ساعت غلط است؟**\n\n"
 "**چون وژتاسیون به‌سرعت ناپدید نمی‌شود.** وژتاسیون یک توده‌ی سازمان‌یافته از فیبرین و "
 "پلاکت است که **هفته‌ها تا ماه‌ها** باقی می‌ماند، حتی وقتی درمان کاملاً موفق بوده. "
 "گاهی در روزهای اول حتی **بزرگ‌تر** هم دیده می‌شود. پس **اندازه‌ی وژتاسیون معیار موفقیت "
 "درمان نیست.**\n\n"
 "**اکوی مجدد اندیکاسیون‌های خودش را دارد** — و آن‌ها بالینی‌اند نه زمانی: **تب پایدار، "
 "سوفل جدید، علائم نارسایی قلبی، یا شک به آبسه‌ی حلقه.**",
 "A question about MONITORING, aimed at a common conceptual error.\n\n"
 "A 45-YEAR-OLD WOMAN with a 0.5 cm mitral vegetation and BLOOD CULTURES POSITIVE ON TWO "
 "OCCASIONS for S. aureus. Appropriate therapy has started per sensitivities. HOW DO WE KNOW "
 "IT IS WORKING?\n\n"
 "WARNING, THE ANSWER: DAILY BLOOD CULTURES UNTIL THEY TURN NEGATIVE.\n\n"
 "WHY? BECAUSE THE GOAL OF TREATMENT IS TO STERILISE THE BLOODSTREAM, AND THE ONLY DIRECT "
 "MEASURE OF THAT IS THE BLOOD CULTURE ITSELF. No image tells you this.\n\n"
 "AND THIS MONITORING HAS THREE CONCRETE USES:\n\n"
 "ONE — IT SETS THE CLOCK. The duration (4 to 6 weeks) is counted from THE DAY THE CULTURES "
 "CLEAR, not from admission. Without daily cultures you do not know that day.\n\n"
 "TWO — IT DETECTS TREATMENT FAILURE. If cultures remain positive after 3 TO 5 DAYS of "
 "appropriate therapy, that is a SERIOUS ALARM: there is probably a VALVE-RING ABSCESS, a "
 "METASTATIC FOCUS (splenic abscess, spondylodiscitis), or a failing regimen. PERSISTENT "
 "BACTERAEMIA IS ITSELF A SURGICAL INDICATION.\n\n"
 "THREE — IT CONFIRMS THE CHOSEN REGIMEN IS ADEQUATE.\n\n"
 "WARNING, AND WHY IS A REPEAT ECHO AT 48 OR 72 HOURS WRONG?\n\n"
 "BECAUSE A VEGETATION DOES NOT DISAPPEAR QUICKLY. It is an organised mass of fibrin and "
 "platelets that persists for WEEKS TO MONTHS even when treatment succeeds completely. In the "
 "early days it may even appear LARGER. SO VEGETATION SIZE IS NOT A MEASURE OF SUCCESS.\n\n"
 "A REPEAT ECHO HAS ITS OWN INDICATIONS — and they are clinical, not scheduled: PERSISTENT "
 "FEVER, A NEW MURMUR, SIGNS OF HEART FAILURE, OR SUSPICION OF A RING ABSCESS.",
 ["پاسخ صحیح — کشت خون روزانه تا منفی شدن، هم پاسخ درمان را می‌سنجد و هم شمارش مدت درمان را آغاز می‌کند.",
  "کشت هفتگی برای کشف شکست درمان بسیار دیر است؛ باکتریمی پایدار باید در چند روز اول شناسایی شود.",
  "وژتاسیون هفته‌ها تا ماه‌ها باقی می‌ماند، پس اکوی ۷۲ ساعت بعد چیزی درباره‌ی موفقیت درمان نمی‌گوید.",
  "اکوی ترانس توراسیک ۴۸ ساعت بعد هم به همین دلیل بی‌فایده است و حساسیت کمتری هم دارد."],
 ["Correct — daily cultures until they clear both measure the response and start the treatment clock.",
  "Weekly cultures are far too slow to detect failure; persistent bacteraemia must be found within days.",
  "A vegetation persists for weeks to months, so an echo at 72 hours says nothing about success.",
  "A transthoracic echo at 48 hours fails for the same reason and is less sensitive as well."],
 "**پاسخ درمان را با کشت می‌سنجند، نه با اکو.** وژتاسیون ماه‌ها می‌ماند.",
 "The response is measured by cultures, not by echo; a vegetation persists for months.",
 [BADDOUR, H128])


# =========================================================== book:124
add("book:124", "case", "medium",
 "نقص مادرزادی **کاملاً ترمیم‌شده** و گذشت سال‌ها ← دیگر پرخطر نیست ← **پروفیلاکسی لازم نیست**.",
 "A congenital defect COMPLETELY REPAIRED years ago is no longer high risk: NO PROPHYLAXIS NEEDED.",
 PROPH_FA + [
  "⚠️ **این سؤال دقیقاً روی مرز شش‌ماهه ایستاده و همان را می‌سنجد.**",
  "**بیماری مادرزادی قلبی فقط در سه حالت پرخطر است — و این بیمار در هیچ‌کدام نیست:**",
  "**حالت یک — سیانوتیک ترمیم‌نشده یا با ترمیم ناقص و شانت باقی‌مانده.** این بیمار **کاملاً** ترمیم شده.",
  "**حالت دو — ترمیم با ماده‌ی مصنوعی، ولی فقط تا شش ماه پس از عمل.** عمل در **کودکی** بوده.",
  "**حالت سه — ترمیم‌شده ولی با نقص باقی‌مانده در کنار وصله.** نقص باقی‌مانده‌ای ذکر نشده.",
  "⚠️ **پس چرا مرز شش ماه؟ چون در شش ماه اول، ماده‌ی مصنوعی هنوز اندوتلیزه نشده است.**",
  "**سطح برهنه‌ی پروتز، محل چسبیدن باکتری است.**",
  "**پس از اندوتلیزه شدن، سطح مثل اندوکارد طبیعی می‌شود و خطر به حد جمعیت عادی برمی‌گردد.**",
  "**این یک منطق زیستی است، نه یک قرارداد دلبخواهی — و به همین دلیل به‌راحتی یادتان می‌ماند.**",
  "**پس پاسخ: نیاز به پروفیلاکسی ندارد. و در این حالت، هیچ نام دارویی نمی‌تواند درست باشد.**",
  "⚠️ **سه گزینه‌ی دیگر همگی داروی درستی برای بیمارِ درست‌اند — ولی این بیمارِ درست نیست.**",
 ],
 PROPH_EN + [
  "WARNING: THIS QUESTION STANDS EXACTLY ON THE SIX-MONTH BOUNDARY AND TESTS IT.",
  "Congenital heart disease is high risk in only three situations — and this patient is in none:",
  "SITUATION ONE — unrepaired cyanotic disease, or incomplete repair with a residual shunt. This patient is COMPLETELY repaired.",
  "SITUATION TWO — repair with prosthetic material, but only for six months after surgery. The operation was in CHILDHOOD.",
  "SITUATION THREE — repaired but with a residual defect adjacent to the patch. No residual defect is mentioned.",
  "WARNING, SO WHY THE SIX-MONTH LINE? BECAUSE IN THE FIRST SIX MONTHS THE PROSTHETIC MATERIAL IS NOT YET ENDOTHELIALISED.",
  "The bare prosthetic surface is where bacteria adhere.",
  "Once endothelialised, the surface behaves like normal endocardium and the risk returns to that of the general population.",
  "This is BIOLOGICAL LOGIC, not an arbitrary convention — which is why it is easy to remember.",
  "SO THE ANSWER IS: NO PROPHYLAXIS. And in that case no drug name can be correct.",
  "WARNING: THE OTHER THREE OPTIONS ARE ALL THE RIGHT DRUG FOR THE RIGHT PATIENT — but this is not the right patient.",
 ],
 "این سؤال ساده به نظر می‌رسد ولی دقیقاً روی یک مرز زمانی ایستاده است.\n\n"
 "**بیمار ۲۰ ساله** با سابقه‌ی **ناهنجاری مادرزادی قلب** که **در کودکی به‌طور کامل ترمیم "
 "شده** است. حالا کاندید **جراحی دندان** است.\n\n"
 "⚠️ **دروازه‌ی دوشرطی را اجرا کنیم:**\n\n"
 "**شرط دوم (پروسیجر) برقرار است:** جراحی دندان یک پروسیجر تهاجمی دندانی است.\n\n"
 "**اما شرط اول (بیمار) برقرار نیست.** بیماری مادرزادی قلبی فقط در **سه حالت** پرخطر "
 "محسوب می‌شود:\n\n"
 "**۱) سیانوتیک ترمیم‌نشده** (یا ترمیم ناقص با شانت باقی‌مانده) — این بیمار **کاملاً** "
 "ترمیم شده. ✗\n\n"
 "**۲) ترمیم‌شده با ماده‌ی مصنوعی، فقط تا شش ماه پس از عمل** — عمل در **کودکی** انجام "
 "شده و بیمار حالا ۲۰ ساله است. ✗\n\n"
 "**۳) ترمیم‌شده ولی با نقص باقی‌مانده در مجاورت وصله** — چیزی ذکر نشده. ✗\n\n"
 "**پس بیمار در هیچ گروه پرخطری نیست و پاسخ «نیاز به پروفیلاکسی ندارد» است.**\n\n"
 "⚠️ **حالا نکته‌ی مفهومی که این قاعده را از حفظ کردن نجات می‌دهد: چرا دقیقاً شش ماه؟**\n\n"
 "چون در **شش ماه اول پس از کارگذاری**، ماده‌ی مصنوعی هنوز **اندوتلیزه نشده** است. "
 "یک سطح مصنوعی برهنه، **محل ایده‌آل چسبیدن باکتری** در جریان یک باکتریمی گذراست. "
 "با گذشت شش ماه، سلول‌های اندوتلیال روی وصله رشد می‌کنند و سطح **مثل اندوکارد طبیعی** "
 "رفتار می‌کند — و خطر به حد جمعیت عمومی برمی‌گردد.\n\n"
 "**این یک منطق زیستی است، نه یک عدد قراردادی؛ و به همین دلیل فراموش نمی‌شود.**\n\n"
 "**نکته‌ی مهم برای پاسخ‌دهی:** سه گزینه‌ی دیگر همگی داروهای معتبری در جدول پروفیلاکسی‌اند. "
 "**دام سؤال همین است:** اگر دنبال «کدام دارو» بگردید، حتماً یکی را انتخاب می‌کنید. "
 "**همیشه اول بپرسید آیا اصلاً پروفیلاکسی لازم است.**",
 "This looks simple but stands precisely on a time boundary.\n\n"
 "A 20-YEAR-OLD with a CONGENITAL HEART DEFECT COMPLETELY REPAIRED IN CHILDHOOD, now due for "
 "DENTAL SURGERY.\n\n"
 "WARNING, RUN THE TWO-CONDITION GATE:\n\n"
 "CONDITION TWO (the procedure) IS MET: dental surgery is an invasive dental procedure.\n\n"
 "BUT CONDITION ONE (the patient) IS NOT. Congenital heart disease counts as high risk in only "
 "THREE situations:\n\n"
 "1) UNREPAIRED CYANOTIC DISEASE (or incomplete repair with a residual shunt) — this patient is "
 "COMPLETELY repaired. NO\n\n"
 "2) REPAIRED WITH PROSTHETIC MATERIAL, ONLY FOR SIX MONTHS AFTER SURGERY — the operation was in "
 "CHILDHOOD and the patient is now 20. NO\n\n"
 "3) REPAIRED BUT WITH A RESIDUAL DEFECT beside the patch — nothing of the sort is mentioned. NO\n\n"
 "SO THE PATIENT IS IN NO HIGH-RISK GROUP AND THE ANSWER IS 'NO PROPHYLAXIS NEEDED'.\n\n"
 "WARNING, NOW THE CONCEPT THAT SAVES THIS RULE FROM ROTE MEMORY: WHY EXACTLY SIX MONTHS?\n\n"
 "Because in the FIRST SIX MONTHS after implantation the prosthetic material is NOT YET "
 "ENDOTHELIALISED. A bare artificial surface is an IDEAL SITE FOR BACTERIAL ADHESION during a "
 "transient bacteraemia. After six months, endothelial cells have grown over the patch and the "
 "surface behaves LIKE NORMAL ENDOCARDIUM — and the risk returns to that of the general "
 "population.\n\n"
 "THIS IS BIOLOGICAL LOGIC, NOT AN ARBITRARY NUMBER, WHICH IS WHY IT STICKS.\n\n"
 "AN IMPORTANT EXAM POINT: the other three options are all legitimate drugs from the prophylaxis "
 "table. THAT IS THE TRAP: if you go looking for 'which drug', you will certainly pick one. "
 "ALWAYS ASK FIRST WHETHER PROPHYLAXIS IS NEEDED AT ALL.",
 ["پاسخ صحیح — نقص مادرزادی کاملاً ترمیم‌شده پس از شش ماه دیگر پرخطر نیست.",
  "آمپی‌سیلین تزریقی فقط وقتی مطرح است که بیمار پرخطر باشد و نتواند خوراکی بگیرد.",
  "آموکسی‌سیلین ۲ گرم رژیم استاندارد است، ولی برای بیماری که اصلاً اندیکاسیون ندارد بی‌مورد است.",
  "کلیندامایسین جایگزین قدیمیِ آلرژی به پنی‌سیلین بود؛ اینجا نه آلرژی مطرح است و نه اندیکاسیون."],
 ["Correct — a completely repaired congenital defect is no longer high risk after six months.",
  "Intramuscular ampicillin applies only to a high-risk patient who cannot take oral medication.",
  "Amoxicillin 2 g is the standard regimen, but pointless in a patient with no indication at all.",
  "Clindamycin was the old penicillin-allergy alternative; here there is neither an allergy nor an indication."],
 "**اول بپرسید آیا پروفیلاکسی لازم است، بعد دنبال دارو بگردید.** شش ماه = زمان اندوتلیزه شدن.",
 "Ask first whether prophylaxis is needed at all, then look for a drug; six months is the time to endothelialise.",
 [WILSON, H128])


# =========================================================== book:126
add("book:126", "case", "hard",
 "**بای‌پس کرونر پرخطر نیست** ← پروفیلاکسی لازم نیست، هرچند بیمار آلرژی هم داشته باشد.",
 "CORONARY BYPASS IS NOT A HIGH-RISK CONDITION: no prophylaxis, whatever the patient's allergy.",
 PROPH_FA + [
  "⚠️ **این سؤال دو دام هم‌زمان دارد و باید هر دو را ببینید.**",
  "**دام یک — «جراحی قلب».** ذهن فوراً به «قلب مریض ← پس پرخطر» می‌رود. **این استدلال غلط است.**",
  "**عمل بای‌پس عروق کرونر (CABG) هیچ ماده‌ی مصنوعی داخل قلب و روی دریچه نمی‌گذارد.**",
  "**پیوند رگ روی سطح خارجی قلب است، نه در مسیر جریان خون داخل حفرات.**",
  "⚠️ **و فهرست پرخطر فقط چهار عضو دارد: دریچه‌ی مصنوعی، اندوکاردیت قبلی،**",
  "**سه حالت خاص بیماری مادرزادی، و پیوند قلب با والوپاتی. CABG در هیچ‌کدام نیست.**",
  "**دام دو — آلرژی آنافیلاکتوئید به پنی‌سیلین.** این اطلاعات جذاب است و شما را وسوسه می‌کند",
  "**که به سراغ جایگزین‌ها بروید. ولی جایگزینِ هیچ، هیچ است.**",
  "⚠️ **قاعده: وقتی اندیکاسیون وجود ندارد، نوع آلرژی هیچ اهمیتی ندارد.**",
  "**سؤالی درباره‌ی انتخاب دارو فقط وقتی معنا دارد که دروازه‌ی اول باز شده باشد.**",
  "**و اگر روزی همین بیمار دریچه‌ی مصنوعی بگیرد، آنگاه با آنافیلاکسی:**",
  "**سفالوسپورین ممنوع است و باید سراغ آزیترومایسین یا کلاریترومایسین یا داکسی‌سیکلین رفت.**",
 ],
 PROPH_EN + [
  "WARNING: THIS QUESTION SETS TWO TRAPS AT ONCE AND BOTH MUST BE SEEN.",
  "TRAP ONE — 'CARDIAC SURGERY'. The mind jumps to 'a diseased heart, therefore high risk'. THAT REASONING IS WRONG.",
  "CORONARY ARTERY BYPASS (CABG) PLACES NO PROSTHETIC MATERIAL INSIDE THE HEART OR ON A VALVE.",
  "The graft sits on the outer surface of the heart, not in the intracavitary blood path.",
  "WARNING, AND THE HIGH-RISK LIST HAS ONLY FOUR MEMBERS: a prosthetic valve, previous endocarditis,",
  "three specific congenital situations, and a transplanted heart with valvulopathy. CABG IS IN NONE OF THEM.",
  "TRAP TWO — THE ANAPHYLACTOID PENICILLIN ALLERGY. That detail is attractive and tempts you",
  "to reach for the alternatives. BUT THE ALTERNATIVE TO NOTHING IS NOTHING.",
  "WARNING, THE RULE: WHEN THERE IS NO INDICATION, THE TYPE OF ALLERGY IS IRRELEVANT.",
  "A question about drug choice only makes sense once the first gate has opened.",
  "And if this same patient one day receives a prosthetic valve, then with anaphylaxis:",
  "a cephalosporin is forbidden and the choice becomes azithromycin, clarithromycin or doxycycline.",
 ],
 "این سؤال دو دام را هم‌زمان کار گذاشته، و دام دوم زیرکانه‌تر است.\n\n"
 "**خانم ۵۰ ساله** با سابقه‌ی **عمل جراحی قلب به دلیل درگیری عروق کرونر** (یعنی CABG)، "
 "کاندید **جراحی لثه**، با سابقه‌ی **شوک آنافیلاکتوئید به پنی‌سیلین**.\n\n"
 "⚠️ **دام اول: «عمل جراحی قلب».**\n\n"
 "این عبارت ذهن را به سمت «قلب مریض ← پس پرخطر ← پس پروفیلاکسی» می‌برد. **ولی این استدلال "
 "غلط است.**\n\n"
 "**بای‌پس عروق کرونر هیچ جسم خارجی‌ای در مسیر جریان خون داخل حفرات قلب یا روی دریچه‌ها "
 "قرار نمی‌دهد.** گرافت روی سطح خارجی قلب دوخته می‌شود. **پس سطح مستعد چسبیدن باکتری در "
 "جریان یک باکتریمی گذرا، ایجاد نشده است.**\n\n"
 "**و فهرست چهارگانه‌ی پرخطر را مرور کنید:** دریچه‌ی مصنوعی ✗ · اندوکاردیت قبلی ✗ · "
 "سه حالت خاص مادرزادی ✗ · پیوند قلب با والوپاتی ✗. **CABG در هیچ‌کدام نیست.**\n\n"
 "⚠️ **دام دوم، و زیرکانه‌تر: آلرژی آنافیلاکتوئید.**\n\n"
 "این جزئیات بسیار «مفید» به نظر می‌رسد و شما را وسوسه می‌کند که فکر کنید سؤال درباره‌ی "
 "**انتخاب جایگزین** است: «پنی‌سیلین ممنوع، پس کلیندامایسین یا آزیترومایسین؟»\n\n"
 "**ولی این کل مسیر فکری اشتباه است. جایگزینِ «هیچ»، «هیچ» است.**\n\n"
 "**قاعده‌ای که باید نهادینه شود: تا وقتی دروازه‌ی اول (آیا بیمار پرخطر است؟) باز نشده، "
 "بحث درباره‌ی انتخاب دارو بی‌معناست.**\n\n"
 "**پس پاسخ: بیمار نیاز به پروفیلاکسی اندوکاردیت ندارد.**\n\n"
 "**و برای تکمیل دانش:** اگر روزی همین بیمار دریچه‌ی مصنوعی دریافت کند و **واقعاً** "
 "اندیکاسیون پیدا کند، آنگاه به‌خاطر **آنافیلاکسی**، **سفالوسپورین‌ها ممنوع‌اند** (خطر "
 "واکنش متقاطع) و انتخاب بین **آزیترومایسین یا کلاریترومایسین ۵۰۰ میلی‌گرم یا "
 "داکسی‌سیکلین ۱۰۰ میلی‌گرم** خواهد بود.",
 "This question lays two traps at once, and the second is the cleverer.\n\n"
 "A 50-YEAR-OLD WOMAN who has had CARDIAC SURGERY FOR CORONARY ARTERY DISEASE (that is, a CABG), "
 "due for GUM SURGERY, with a history of ANAPHYLACTOID SHOCK to penicillin.\n\n"
 "WARNING, TRAP ONE: 'CARDIAC SURGERY'.\n\n"
 "The phrase pulls the mind towards 'a diseased heart, therefore high risk, therefore "
 "prophylaxis'. THAT REASONING IS WRONG.\n\n"
 "CORONARY BYPASS PLACES NO FOREIGN BODY IN THE INTRACAVITARY BLOOD PATH OR ON THE VALVES. "
 "The graft is sewn onto the outer surface of the heart. SO NO SURFACE PRONE TO BACTERIAL "
 "ADHESION DURING A TRANSIENT BACTERAEMIA HAS BEEN CREATED.\n\n"
 "AND REVIEW THE FOUR HIGH-RISK CATEGORIES: prosthetic valve NO · previous endocarditis NO · "
 "the three congenital situations NO · transplant with valvulopathy NO. CABG IS IN NONE.\n\n"
 "WARNING, TRAP TWO, AND THE CLEVERER ONE: THE ANAPHYLACTOID ALLERGY.\n\n"
 "That detail looks extremely 'useful' and tempts you to believe the question is about CHOOSING "
 "AN ALTERNATIVE: 'penicillin is out, so clindamycin or azithromycin?'\n\n"
 "BUT THAT WHOLE LINE OF THOUGHT IS WRONG. THE ALTERNATIVE TO NOTHING IS NOTHING.\n\n"
 "THE RULE TO INTERNALISE: UNTIL THE FIRST GATE (is the patient high risk?) HAS OPENED, ANY "
 "DISCUSSION OF DRUG CHOICE IS MEANINGLESS.\n\n"
 "SO THE ANSWER: THIS PATIENT NEEDS NO ENDOCARDITIS PROPHYLAXIS.\n\n"
 "AND TO COMPLETE THE KNOWLEDGE: if one day this same patient received a prosthetic valve and "
 "genuinely acquired an indication, then because of the ANAPHYLAXIS, CEPHALOSPORINS WOULD BE "
 "FORBIDDEN (cross-reaction risk) and the choice would be AZITHROMYCIN OR CLARITHROMYCIN 500 MG "
 "OR DOXYCYCLINE 100 MG.",
 ["آموکسی‌سیلین در بیمار با آنافیلاکسی به پنی‌سیلین ممنوع است و اصلاً اندیکاسیونی هم وجود ندارد.",
  "کلیندامایسین جایگزین قدیمی بود، ولی اینجا اصلاً اندیکاسیون پروفیلاکسی وجود ندارد.",
  "آزیترومایسین جایگزین معتبری در آلرژی است، ولی برای بیماری که پرخطر نیست بی‌مورد است.",
  "پاسخ صحیح — بای‌پس عروق کرونر جزو چهار گروه پرخطر نیست، پس پروفیلاکسی لازم نیست."],
 ["Amoxicillin is contraindicated with penicillin anaphylaxis, and there is no indication anyway.",
  "Clindamycin was the old alternative, but here there is no indication for prophylaxis at all.",
  "Azithromycin is a valid allergy alternative, but pointless in a patient who is not high risk.",
  "Correct — coronary bypass is not among the four high-risk groups, so no prophylaxis is needed."],
 "**CABG جسم خارجی داخل قلب نمی‌گذارد، پس پرخطر نیست.** جایگزینِ هیچ، هیچ است.",
 "A CABG places no foreign body inside the heart, so it is not high risk; the alternative to nothing is nothing.",
 [WILSON, H128])


# =========================================================== book:127
add("book:127", "case", "medium",
 "**دریچه‌ی مصنوعی + ایمپلنت دندان** ← هر دو شرط برقرار ← **آموکسی‌سیلین ۲ گرم، یک ساعت قبل**.",
 "A PROSTHETIC VALVE plus a DENTAL IMPLANT: both conditions met, so AMOXICILLIN 2 G ONE HOUR BEFORE.",
 PROPH_FA + [
  "⚠️ **این تنها حالتی است که هر دو شرط دروازه برقرارند — و باید بتوانید تشخیصش دهید.**",
  "**شرط اول:** دریچه‌ی میترال **مصنوعی**. عضو شماره‌ی یک فهرست پرخطر. ✔",
  "**شرط دوم:** ایمپلنت دندان، که مستلزم **دستکاری لثه و استخوان** است. ✔",
  "**پس پروفیلاکسی واقعاً اندیکاسیون دارد و حالا نوبت انتخاب دارو است.**",
  "**رژیم استاندارد: آموکسی‌سیلین ۲ گرم خوراکی، تک‌دوز، ۳۰ تا ۶۰ دقیقه پیش از پروسیجر.**",
  "⚠️ **چرا آموکسی‌سیلین؟ چون هدف، استرپتوکوک‌های گروه ویریدنس در فلور دهان است.**",
  "**آموکسی‌سیلین جذب خوراکی عالی دارد و غلظت خونی بالا و پایداری می‌سازد.**",
  "**چرا ۳۰ تا ۶۰ دقیقه قبل؟ تا در لحظه‌ی باکتریمی، غلظت خونی در اوج باشد.**",
  "⚠️ **و چرا فقط یک دوز؟ چون باکتریمی ناشی از پروسیجر گذراست و چند دقیقه بیشتر طول نمی‌کشد.**",
  "**دوز دوم پس از پروسیجر، در راهنمای فعلی توصیه نمی‌شود** (در راهنماهای قدیمی بود).",
  "**اگر بیمار نتواند خوراکی بگیرد: آمپی‌سیلین ۲ گرم عضلانی یا وریدی.**",
  "**دقت کنید: سفازولین تزریقی هم گزینه‌ای هست، ولی زمان‌بندی «۲ ساعت قبل» نادرست است.**",
 ],
 PROPH_EN + [
  "WARNING: THIS IS THE ONE CASE WHERE BOTH GATE CONDITIONS HOLD — and you must be able to see it.",
  "CONDITION ONE: a PROSTHETIC mitral valve. Member number one of the high-risk list. YES",
  "CONDITION TWO: a dental implant, which requires MANIPULATION OF GINGIVA AND BONE. YES",
  "SO PROPHYLAXIS IS GENUINELY INDICATED and only now does drug choice arise.",
  "STANDARD REGIMEN: AMOXICILLIN 2 G ORALLY, SINGLE DOSE, 30 TO 60 MINUTES BEFORE THE PROCEDURE.",
  "WARNING, WHY AMOXICILLIN? BECAUSE THE TARGET IS THE VIRIDANS GROUP STREPTOCOCCI OF MOUTH FLORA.",
  "Amoxicillin is very well absorbed orally and produces high, sustained blood levels.",
  "Why 30 to 60 minutes before? So that the blood level peaks at the moment of bacteraemia.",
  "WARNING, AND WHY ONLY ONE DOSE? Because procedure-related bacteraemia is transient, lasting minutes.",
  "A SECOND POST-PROCEDURE DOSE IS NO LONGER RECOMMENDED (it was in older guidelines).",
  "If the patient cannot take oral medication: ampicillin 2 g intramuscularly or intravenously.",
  "Note: intravenous cefazolin is also an option, but the timing 'two hours before' is wrong.",
 ],
 "پس از چند سؤالی که پاسخشان «پروفیلاکسی لازم نیست» بود، این سؤال حالت مقابل را نشان "
 "می‌دهد — و همین تضاد، ارزش آموزشی‌اش را بالا می‌برد.\n\n"
 "**آقای ۴۲ ساله** با **تعویض دریچه‌ی میترال دو سال پیش**، کاندید **ایمپلنت دندان**.\n\n"
 "⚠️ **دروازه‌ی دوشرطی را اجرا کنیم:**\n\n"
 "**شرط اول — آیا بیمار پرخطر است؟ بله.** **دریچه‌ی مصنوعی** اولین و روشن‌ترین عضو فهرست "
 "چهارگانه است. و توجه کنید که برخلاف نقص مادرزادی ترمیم‌شده، **مرز شش ماه اینجا کاربرد "
 "ندارد**: دریچه‌ی مصنوعی **مادام‌العمر** پرخطر می‌ماند.\n\n"
 "**شرط دوم — آیا پروسیجر تهاجمی دندانی است؟ بله.** ایمپلنت دندان مستلزم **دستکاری لثه و "
 "استخوان آلوئول** است و باکتریمی قابل توجهی ایجاد می‌کند.\n\n"
 "**هر دو شرط برقرار است، پس پروفیلاکسی اندیکاسیون دارد.**\n\n"
 "**رژیم: آموکسی‌سیلین ۲ گرم خوراکی، تک‌دوز، ۳۰ تا ۶۰ دقیقه پیش از پروسیجر.**\n\n"
 "⚠️ **حالا منطق هر جزء این نسخه:**\n\n"
 "**چرا آموکسی‌سیلین؟** چون هدف، **استرپتوکوک‌های ویریدنس فلور دهان** است — همان‌هایی که "
 "با دستکاری لثه وارد خون می‌شوند. آموکسی‌سیلین جذب خوراکی عالی دارد و غلظت خونی بالا و "
 "پایدار می‌سازد.\n\n"
 "**چرا ۳۰ تا ۶۰ دقیقه قبل؟** تا **در لحظه‌ی ورود باکتری به خون، غلظت دارو در اوج باشد**. "
 "زودتر دادن (مثلاً دو ساعت قبل، که گزینه‌ی سفازولین پیشنهاد می‌کند) یعنی غلظت در لحظه‌ی "
 "حساس افت کرده باشد.\n\n"
 "**چرا فقط یک دوز؟** چون باکتریمیِ ناشی از پروسیجر **گذراست و فقط چند دقیقه طول می‌کشد**. "
 "پوشاندن همان پنجره کافی است. **دوز دوم پس از پروسیجر در راهنمای فعلی حذف شده است.**\n\n"
 "**نکته‌ی مقایسه‌ای مهم:** به سؤال بیمار بای‌پس کرونر برگردید. آنجا هم جراحی دهان بود، "
 "ولی بیمار پرخطر نبود و پاسخ «هیچ» بود. **همین دو سؤال کنار هم، کل منطق پروفیلاکسی را "
 "می‌آموزند.**",
 "After several questions whose answer was 'no prophylaxis', this one shows the opposite case — "
 "and that contrast is what makes it valuable.\n\n"
 "A 42-YEAR-OLD MAN whose MITRAL VALVE WAS REPLACED TWO YEARS AGO, due for a DENTAL IMPLANT.\n\n"
 "WARNING, RUN THE TWO-CONDITION GATE:\n\n"
 "CONDITION ONE — IS THE PATIENT HIGH RISK? YES. A PROSTHETIC VALVE is the first and clearest "
 "member of the four-item list. And note that, unlike a repaired congenital defect, THE "
 "SIX-MONTH RULE DOES NOT APPLY HERE: a prosthetic valve remains high risk FOR LIFE.\n\n"
 "CONDITION TWO — IS THE PROCEDURE AN INVASIVE DENTAL ONE? YES. A dental implant requires "
 "MANIPULATION OF GINGIVA AND ALVEOLAR BONE and produces a substantial bacteraemia.\n\n"
 "BOTH CONDITIONS HOLD, SO PROPHYLAXIS IS INDICATED.\n\n"
 "THE REGIMEN: AMOXICILLIN 2 G ORALLY, SINGLE DOSE, 30 TO 60 MINUTES BEFORE THE PROCEDURE.\n\n"
 "WARNING, NOW THE LOGIC OF EACH PART OF THAT PRESCRIPTION:\n\n"
 "WHY AMOXICILLIN? Because the target is the VIRIDANS STREPTOCOCCI OF MOUTH FLORA — exactly the "
 "organisms that enter the blood when gingiva is manipulated. Amoxicillin is very well absorbed "
 "orally and gives high, sustained levels.\n\n"
 "WHY 30 TO 60 MINUTES BEFORE? So that THE DRUG LEVEL PEAKS AT THE MOMENT BACTERIA ENTER THE "
 "BLOOD. Giving it earlier (two hours before, as the cefazolin option proposes) means the level "
 "has already fallen by the critical moment.\n\n"
 "WHY ONLY ONE DOSE? Because procedure-related bacteraemia is TRANSIENT, lasting only minutes. "
 "Covering that window is enough. A SECOND POST-PROCEDURE DOSE HAS BEEN REMOVED FROM CURRENT "
 "GUIDANCE.\n\n"
 "AN IMPORTANT COMPARISON: go back to the coronary-bypass patient. That was also oral surgery, "
 "but the patient was not high risk and the answer was 'nothing'. THESE TWO QUESTIONS SIDE BY "
 "SIDE TEACH THE ENTIRE LOGIC OF PROPHYLAXIS.",
 ["پاسخ صحیح — دریچه‌ی مصنوعی و ایمپلنت دندان: هر دو شرط برقرار، پس آموکسی‌سیلین ۲ گرم یک ساعت قبل.",
  "سفازولین تزریقی گزینه‌ی جایگزین است ولی زمان‌بندی درست ۳۰ تا ۶۰ دقیقه قبل است، نه ۲ ساعت.",
  "سیپروفلوکساسین استرپتوکوک ویریدنس دهان را پوشش نمی‌دهد و در این جدول جایی ندارد.",
  "دریچه‌ی مصنوعی مادام‌العمر پرخطر می‌ماند؛ اینجا پروفیلاکسی قطعاً لازم است."],
 ["Correct — a prosthetic valve plus a dental implant: both conditions met, so amoxicillin 2 g one hour before.",
  "Intravenous cefazolin is an alternative, but the correct timing is 30 to 60 minutes before, not 2 hours.",
  "Ciprofloxacin does not cover oral viridans streptococci and has no place in this table.",
  "A prosthetic valve remains high risk for life; prophylaxis is definitely required here."],
 "**دریچه‌ی مصنوعی مادام‌العمر پرخطر است.** آموکسی‌سیلین ۲ گرم، تک‌دوز، ۳۰ تا ۶۰ دقیقه قبل.",
 "A prosthetic valve is high risk for life; amoxicillin 2 g, single dose, 30 to 60 minutes before.",
 [WILSON, H128])


# =========================================================== book:128
add("book:128", "case", "hard",
 "اندوکاردیت قبلی + دریچه‌ی مصنوعی + **آنافیلاکسی** ← سفالوسپورین ممنوع ← **کلاریترومایسین ۵۰۰**.",
 "Previous endocarditis, a prosthetic valve and ANAPHYLAXIS: no cephalosporin, so CLARITHROMYCIN 500 MG.",
 PROPH_FA + [
  "⚠️ **این سؤال سه فیلتر پشت سر هم دارد و باید هر سه را رد کنید.**",
  "**فیلتر یک — آیا اندیکاسیون هست؟ بله، و دوبار:** سابقه‌ی اندوکاردیت **و** دریچه‌ی مصنوعی.",
  "**جراحی لثه هم پروسیجر تهاجمی دندانی است. پس دروازه باز است.**",
  "**فیلتر دو — آلرژی چه نوعی است؟ آنافیلاکتیک.**",
  "⚠️ **و این یعنی سفالوسپورین‌ها هم ممنوع‌اند** (سفالکسین، سفازولین، سفتریاکسون).",
  "**در آلرژی خفیف (راش) سفالوسپورین مجاز است؛ در آنافیلاکسی هرگز.**",
  "**پس گزینه‌ی سفالکسین حذف می‌شود، هرچند دوز و زمانش هم اشتباه است.**",
  "**فیلتر سه — از میان جایگزین‌های باقی‌مانده، کدام دوز و راه و زمان درست را دارد؟**",
  "**کلاریترومایسین ۵۰۰ میلی‌گرم خوراکی یک ساعت قبل: دوز درست، راه درست، زمان درست.** ✔",
  "⚠️ **آزیترومایسین هم داروی درستی است، ولی دوز صحیحش ۵۰۰ است، نه ۲۵۰.**",
  "**این یک دام دوزی است: داروی درست با دوز نصف.**",
  "**و کلیندامایسین وریدی هم‌زمان با شروع جراحی، دو ایراد دارد: زمان‌بندی غلط،**",
  "**و اینکه بیانیه‌ی ۲۰۲۱ انجمن قلب آمریکا کلیندامایسین را از این جدول حذف کرده است.**",
 ],
 PROPH_EN + [
  "WARNING: THIS QUESTION HAS THREE FILTERS IN SERIES AND YOU MUST PASS ALL THREE.",
  "FILTER ONE — IS THERE AN INDICATION? YES, TWICE OVER: previous endocarditis AND a prosthetic valve.",
  "Gum surgery is an invasive dental procedure too. So the gate is open.",
  "FILTER TWO — WHAT KIND OF ALLERGY? ANAPHYLACTIC.",
  "WARNING, AND THAT MEANS CEPHALOSPORINS ARE ALSO FORBIDDEN (cephalexin, cefazolin, ceftriaxone).",
  "With a mild allergy (a rash) a cephalosporin is allowed; with anaphylaxis, never.",
  "So the cephalexin option falls, quite apart from its wrong dose and timing.",
  "FILTER THREE — among the remaining alternatives, which has the right dose, route and timing?",
  "CLARITHROMYCIN 500 MG ORALLY ONE HOUR BEFORE: right dose, right route, right timing. CORRECT.",
  "WARNING, AZITHROMYCIN IS ALSO A CORRECT DRUG, but its correct dose is 500 mg, not 250.",
  "That is a DOSE TRAP: the right drug at half the dose.",
  "And intravenous clindamycin at the start of surgery has two faults: the timing is wrong,",
  "and the 2021 AHA statement has removed clindamycin from this table altogether.",
 ],
 "این سخت‌ترین سؤال پروفیلاکسی فصل است، چون **سه فیلتر پشت سر هم** دارد.\n\n"
 "**خانم ۳۵ ساله** با **سابقه‌ی اندوکاردیت عفونی دو سال پیش** و **تعویض دریچه**، کاندید "
 "**جراحی لثه**، با **آلرژی آنافیلاکتیک به پنی‌سیلین**.\n\n"
 "⚠️ **فیلتر یک — آیا اصلاً اندیکاسیون هست؟**\n\n"
 "**بله، و از دو راه مستقل:** **سابقه‌ی اندوکاردیت عفونی** (عضو دوم فهرست پرخطر) و "
 "**دریچه‌ی مصنوعی** (عضو اول). پروسیجر هم جراحی لثه است. **دروازه کاملاً باز است.**\n\n"
 "⚠️ **فیلتر دو — نوع آلرژی چیست؟**\n\n"
 "**آنافیلاکتیک.** و این کلمه یک گروه کامل دارو را حذف می‌کند: **سفالوسپورین‌ها**. "
 "به‌خاطر **خطر واکنش متقاطع**، در آلرژی آنافیلاکتیک به پنی‌سیلین، **هیچ سفالوسپورینی "
 "مجاز نیست** — نه سفالکسین، نه سفازولین، نه سفتریاکسون.\n\n"
 "**تمایز مهمی که باید بدانید:** در آلرژی **خفیف** (مثل راش خارش‌دار ساده)، سفالوسپورین "
 "**مجاز** است. در **آنافیلاکسی**، هرگز.\n\n"
 "⚠️ **فیلتر سه — از میان جایگزین‌های مجاز، کدام‌یک دوز و راه و زمانِ درست را دارد؟**\n\n"
 "و اینجاست که سؤال از دانش دارویی به **دقت** تبدیل می‌شود:\n\n"
 "• **آزیترومایسین ۲۵۰ میلی‌گرم** — **داروی درست، دوز غلط.** دوز صحیح **۵۰۰ میلی‌گرم** است. "
 "این یک دام کلاسیک دوزی است.\n\n"
 "• **سفالکسین ۲ گرم، ۳۰ دقیقه قبل** — **دارو ممنوع** (سفالوسپورین در آنافیلاکسی).\n\n"
 "• **کلیندامایسین ۶۰۰ میلی‌گرم وریدی، هم‌زمان با شروع جراحی** — **زمان‌بندی غلط** "
 "(باید پیش از پروسیجر باشد تا غلظت در اوج باشد). ⚠️ **و نکته‌ی مهم‌تر: بیانیه‌ی ۲۰۲۱ "
 "انجمن قلب آمریکا کلیندامایسین را کاملاً از جدول پروفیلاکسی حذف کرد**، به‌دلیل خطر "
 "کولیت کلستریدیوم دیفیسیل حتی با یک دوز.\n\n"
 "• **کلاریترومایسین ۵۰۰ میلی‌گرم خوراکی، یک ساعت قبل** — **دوز درست، راه درست، "
 "زمان درست.** ✅\n\n"
 "**درس کلی: در سؤال‌های پروفیلاکسی، پس از انتخاب داروی درست، دوز و زمان را هم بررسی کنید. "
 "طراح سؤال معمولاً یک داروی درست را با دوز یا زمان غلط در گزینه‌ها می‌گذارد.**",
 "This is the hardest prophylaxis question in the chapter, because it has THREE FILTERS IN "
 "SERIES.\n\n"
 "A 35-YEAR-OLD WOMAN with PREVIOUS INFECTIVE ENDOCARDITIS two years ago and a VALVE "
 "REPLACEMENT, due for GUM SURGERY, with ANAPHYLACTIC PENICILLIN ALLERGY.\n\n"
 "WARNING, FILTER ONE — IS THERE AN INDICATION AT ALL?\n\n"
 "YES, BY TWO INDEPENDENT ROUTES: PREVIOUS INFECTIVE ENDOCARDITIS (second on the high-risk list) "
 "and a PROSTHETIC VALVE (first on it). The procedure is gum surgery. THE GATE IS FULLY OPEN.\n\n"
 "WARNING, FILTER TWO — WHAT KIND OF ALLERGY?\n\n"
 "ANAPHYLACTIC. That single word removes an entire drug class: THE CEPHALOSPORINS. Because of "
 "CROSS-REACTION RISK, no cephalosporin is permitted with anaphylactic penicillin allergy — not "
 "cephalexin, not cefazolin, not ceftriaxone.\n\n"
 "AN IMPORTANT DISTINCTION: with a MILD allergy (a simple itchy rash) a cephalosporin IS "
 "allowed. With ANAPHYLAXIS, never.\n\n"
 "WARNING, FILTER THREE — among the permitted alternatives, which has the right dose, route and "
 "timing?\n\n"
 "And here the question turns from pharmacology into PRECISION:\n\n"
 "• AZITHROMYCIN 250 MG — RIGHT DRUG, WRONG DOSE. The correct dose is 500 MG. A classic dose "
 "trap.\n\n"
 "• CEPHALEXIN 2 G, 30 MINUTES BEFORE — FORBIDDEN DRUG (a cephalosporin in anaphylaxis).\n\n"
 "• CLINDAMYCIN 600 MG INTRAVENOUSLY AT THE START OF SURGERY — WRONG TIMING (it must precede the "
 "procedure so the level peaks). WARNING, AND MORE IMPORTANT: THE 2021 AHA STATEMENT REMOVED "
 "CLINDAMYCIN FROM THE PROPHYLAXIS TABLE ENTIRELY, because of Clostridioides difficile colitis "
 "even after a single dose.\n\n"
 "• CLARITHROMYCIN 500 MG ORALLY ONE HOUR BEFORE — RIGHT DOSE, RIGHT ROUTE, RIGHT TIMING. "
 "CORRECT.\n\n"
 "THE GENERAL LESSON: in prophylaxis questions, after choosing the right drug, CHECK THE DOSE "
 "AND THE TIMING TOO. Examiners routinely place a correct drug at a wrong dose or a wrong time "
 "among the options.",
 ["داروی درستی است ولی دوز آزیترومایسین در پروفیلاکسی ۵۰۰ میلی‌گرم است، نه ۲۵۰.",
  "سفالکسین یک سفالوسپورین است و در آلرژی آنافیلاکتیک به پنی‌سیلین ممنوع است.",
  "زمان‌بندی غلط است (باید پیش از پروسیجر باشد)، و کلیندامایسین از راهنمای ۲۰۲۱ حذف شده است.",
  "پاسخ صحیح — کلاریترومایسین ۵۰۰ میلی‌گرم خوراکی یک ساعت قبل: دوز، راه و زمان هر سه درست."],
 ["The right drug, but the azithromycin prophylaxis dose is 500 mg, not 250.",
  "Cephalexin is a cephalosporin and is contraindicated in anaphylactic penicillin allergy.",
  "The timing is wrong (it must precede the procedure), and clindamycin was removed from the 2021 guidance.",
  "Correct — clarithromycin 500 mg orally one hour before: dose, route and timing all correct."],
 "**آنافیلاکسی سفالوسپورین را هم حذف می‌کند.** و دوز را چک کنید: آزیترومایسین ۵۰۰ است نه ۲۵۰.",
 "Anaphylaxis rules out cephalosporins too; and check the dose, azithromycin is 500 mg not 250.",
 [WILSON, H128])



# =========================================================== book:121
add("book:121", "case", "medium",
 "معتاد تزریقی + **آمبولی دوطرفه‌ی ریه** + نارسایی تریکوسپید ← **استاف اورئوس**، وانکومایسین + جنتامایسین.",
 "An injecting drug user with BILATERAL PULMONARY EMBOLI and tricuspid regurgitation: S. AUREUS, vancomycin plus gentamicin.",
 RX_FA + [
  "⚠️ **این سؤال هم ارگانیسم می‌خواهد و هم درمان — و باید هر دو را درست بگویید.**",
  "**سه یافته، تشخیص اندوکاردیت سمت راست را قطعی می‌کنند:**",
  "**یک — اعتیاد تزریقی.** **دو — نارسایی تریکوسپید در اکو.** **سه — آمبولی دوطرفه‌ی ریه.**",
  "⚠️ **چرا آمبولی ریوی دوطرفه است؟ چون وژتاسیون روی تریکوسپید است.**",
  "**تکه‌های وژتاسیون از دهلیز راست به بطن راست و از آنجا مستقیم به شریان ریوی می‌روند.**",
  "**پس در اندوکاردیت سمت راست، آمبولی به ریه می‌رود؛ در سمت چپ، به مغز و طحال و کلیه.**",
  "**این یک تمایز آناتومیک ساده است که یک‌بار برای همیشه یاد می‌گیرید.**",
  "**شایع‌ترین ارگانیسم در این تابلو: استافیلوکوکوس اورئوس** — در بیش از دوسوم موارد.",
  "⚠️ **و حالا نکته‌ی درمانی: چرا وانکومایسین به‌تنهایی کافی نیست؟**",
  "**چون در درمان تجربی، پیش از آنکه حساسیت مشخص شود، MRSA محتمل است**",
  "**و جنتامایسین برای سینرژی در روزهای نخست اضافه می‌شود تا پاکسازی باکتریمی سریع‌تر شود.**",
  "**پس از آماده شدن آنتی‌بیوگرام، اگر MSSA بود، به نافسیلین یا سفازولین سوئیچ می‌کنیم.**",
 ],
 RX_EN + [
  "WARNING: THIS QUESTION ASKS FOR BOTH THE ORGANISM AND THE TREATMENT, and both must be right.",
  "THREE FINDINGS MAKE RIGHT-SIDED ENDOCARDITIS CERTAIN:",
  "ONE — injecting drug use. TWO — tricuspid regurgitation on echo. THREE — bilateral pulmonary emboli.",
  "WARNING, WHY ARE THE EMBOLI BILATERAL AND PULMONARY? BECAUSE THE VEGETATION IS ON THE TRICUSPID VALVE.",
  "Fragments travel from right atrium to right ventricle and straight into the pulmonary arteries.",
  "So in RIGHT-sided disease emboli go to the LUNGS; in LEFT-sided disease to brain, spleen and kidney.",
  "That is a simple anatomical distinction you learn once and keep.",
  "The commonest organism in this picture: STAPHYLOCOCCUS AUREUS — in over two-thirds of cases.",
  "WARNING, AND THE TREATMENT POINT: why is vancomycin alone not enough?",
  "Because in EMPIRICAL therapy, before sensitivities are known, MRSA is a real possibility,",
  "and gentamicin is added for synergy in the first days to clear the bacteraemia faster.",
  "Once sensitivities return, if it is MSSA we switch to nafcillin or cefazolin.",
 ],
 "این سؤال دو بخشی است: **ارگانیسم** و **درمان**. هر دو باید درست باشند.\n\n"
 "**آقای ۳۰ ساله‌ی معتاد تزریقی** با تب، تاکی‌کاردی و تنگی نفس پنج‌روزه. "
 "**سی‌تی قفسه‌ی سینه: آمبولی دوطرفه.** **اکو: نارسایی دریچه‌ی تریکوسپید.**\n\n"
 "⚠️ **بخش اول — ارگانیسم.**\n\n"
 "این یک **اندوکاردیت سمت راست در معتاد تزریقی** است، و شایع‌ترین عامل آن با فاصله‌ی زیاد "
 "**استافیلوکوکوس اورئوس** است (بیش از دوسوم موارد). دلیلش ساده است: **پوست منبع آلودگی "
 "سوزن است و استاف اورئوس ساکن پوست.**\n\n"
 "**چرا آمبولی دوطرفه‌ی ریوی؟** یک نکته‌ی آناتومیک ساده و بسیار پرتکرار در امتحان: "
 "**وژتاسیون روی تریکوسپید، تکه‌هایش را به بطن راست و از آنجا مستقیم به شریان ریوی "
 "می‌فرستد.** پس:\n\n"
 "• **اندوکاردیت سمت راست ← آمبولی ریوی** (ندول‌های متعدد و دوطرفه)\n"
 "• **اندوکاردیت سمت چپ ← آمبولی سیستمیک** (مغز، طحال، کلیه)\n\n"
 "⚠️ **بخش دوم — درمان، و اینجاست که دو گزینه‌ی شبیه هم از هم جدا می‌شوند.**\n\n"
 "هر دو گزینه‌ی «وانکومایسین + جنتامایسین» و «وانکومایسین تنها» ارگانیسم را درست گفته‌اند. "
 "تفاوت در **جنتامایسین** است.\n\n"
 "**در درمان تجربی — یعنی پیش از آماده شدن آنتی‌بیوگرام — وانکومایسین پایه است** (چون MRSA "
 "محتمل است)، و **جنتامایسین برای سینرژی در روزهای نخست اضافه می‌شود** تا پاکسازی باکتریمی "
 "سریع‌تر انجام شود. این همان رژیم تجربی استاندارد است.\n\n"
 "**نکته‌ی تکمیلی مهم:** پس از آماده شدن آنتی‌بیوگرام، اگر ارگانیسم **MSSA** بود، "
 "**وانکومایسین باید کنار گذاشته شود** و جای خود را به **نافسیلین یا سفازولین** بدهد — "
 "چون در MSSA، بتالاکتام‌ها **مؤثرتر از وانکومایسین** هستند.",
 "This question has two parts: THE ORGANISM and THE TREATMENT. Both must be right.\n\n"
 "A 30-YEAR-OLD INJECTING DRUG USER with five days of fever, tachycardia and breathlessness. "
 "CHEST CT: BILATERAL EMBOLI. ECHO: TRICUSPID REGURGITATION.\n\n"
 "WARNING, PART ONE — THE ORGANISM.\n\n"
 "This is RIGHT-SIDED ENDOCARDITIS IN AN INJECTING DRUG USER, and its commonest cause by a wide "
 "margin is STAPHYLOCOCCUS AUREUS (over two-thirds of cases). The reason is simple: THE SKIN IS "
 "THE SOURCE OF NEEDLE CONTAMINATION AND S. AUREUS LIVES ON SKIN.\n\n"
 "WHY BILATERAL PULMONARY EMBOLI? A simple anatomical point that recurs constantly in exams: "
 "A VEGETATION ON THE TRICUSPID VALVE SHEDS FRAGMENTS INTO THE RIGHT VENTRICLE AND STRAIGHT ON "
 "INTO THE PULMONARY ARTERIES. So:\n\n"
 "• RIGHT-SIDED ENDOCARDITIS means PULMONARY emboli (multiple, bilateral nodules)\n"
 "• LEFT-SIDED ENDOCARDITIS means SYSTEMIC emboli (brain, spleen, kidney)\n\n"
 "WARNING, PART TWO — THE TREATMENT, and this is where two similar options separate.\n\n"
 "Both 'vancomycin plus gentamicin' and 'vancomycin alone' name the organism correctly. The "
 "difference is THE GENTAMICIN.\n\n"
 "IN EMPIRICAL THERAPY — before sensitivities are available — VANCOMYCIN IS THE BACKBONE "
 "(because MRSA is plausible), and GENTAMICIN IS ADDED FOR SYNERGY IN THE FIRST DAYS to clear "
 "the bacteraemia faster. That is the standard empirical regimen.\n\n"
 "AN IMPORTANT FOLLOW-UP: once sensitivities return, if the organism is MSSA, VANCOMYCIN MUST "
 "BE STOPPED and replaced by NAFCILLIN OR CEFAZOLIN — because in MSSA the beta-lactams are MORE "
 "EFFECTIVE than vancomycin.",
 ["پاسخ صحیح — استاف اورئوس شایع‌ترین عامل است و رژیم تجربی وانکومایسین همراه با جنتامایسین است.",
  "انتروکوک فکالیس در این زمینه بسیار نامحتمل است و آمپی‌سیلین تنها پوشش کافی نمی‌دهد.",
  "استاف اپیدرمیدیس عامل اندوکاردیت دریچه‌ی مصنوعی است، نه دریچه‌ی طبیعی در معتاد تزریقی.",
  "ارگانیسم درست است ولی وانکومایسین به‌تنهایی رژیم تجربی کامل نیست؛ جنتامایسین برای سینرژی لازم است."],
 ["Correct — S. aureus is the commonest agent and the empirical regimen is vancomycin with gentamicin.",
  "Enterococcus faecalis is very unlikely in this setting and ampicillin alone is inadequate cover.",
  "S. epidermidis causes prosthetic-valve endocarditis, not native-valve disease in a drug user.",
  "The organism is right but vancomycin alone is not the complete empirical regimen; gentamicin adds synergy."],
 "**سمت راست ← آمبولی ریه. سمت چپ ← آمبولی مغز و طحال.** و در معتاد تزریقی، اورئوس.",
 "Right-sided disease embolises to the lung, left-sided to brain and spleen; and in a drug user it is S. aureus.",
 [BADDOUR, H128])


# =========================================================== book:132
add("book:132", "case", "hard",
 "**آندوسکوپی گوارشی پروفیلاکسی نمی‌خواهد** — پس سؤال «کدام را توصیه نمی‌کنید» جواب دیگری دارد: دوز و طیف.",
 "GI ENDOSCOPY NEEDS NO PROPHYLAXIS AT ALL, so the 'which would you NOT recommend' turns on dose and spectrum.",
 PROPH_FA + [
  "⚠️ **این سؤال منفی است: می‌پرسد کدام دارو را توصیه نمی‌کنید. اول این را ببینید.**",
  "**در سؤال منفی، سه گزینه باید قابل دفاع باشند و یکی نباشد.**",
  "**نکته‌ی مفهومی مهم‌تر: خودِ این پروسیجر اصلاً پروفیلاکسی نمی‌خواهد.**",
  "⚠️ **آندوسکوپی و بیوپسی گوارشی از سال ۲۰۰۷ از فهرست اندیکاسیون‌های پروفیلاکسی حذف شده‌اند.**",
  "**چرا؟ چون شواهد نشان داد باکتریمی گذرای ناشی از آن‌ها اندوکاردیت معنادار نمی‌سازد،**",
  "**و ضرر آنتی‌بیوتیک بی‌مورد از فایده‌ی فرضی‌اش بیشتر است.**",
  "**پروفیلاکسی امروز فقط برای پروسیجرهای دندانیِ تهاجمی در چهار گروه پرخطر است.**",
  "⚠️ **حالا در چارچوب خودِ سؤال، کدام گزینه بدترین است؟**",
  "**داکسی‌سیکلین ۲۰۰ میلی‌گرم:** داکسی‌سیکلین در جدول‌های جدید به‌عنوان جایگزین آمده،",
  "**ولی دوز پروفیلاکسی‌اش ۱۰۰ میلی‌گرم است، نه ۲۰۰** — و پوشش استرپتوکوکی‌اش هم ضعیف‌ترین است.",
  "**سه گزینه‌ی دیگر (آزیترومایسین ۵۰۰، کلیندامایسین ۶۰۰، سفتریاکسون ۱ گرم) دوزهای شناخته‌شده‌اند.**",
  "**و توجه: راش خارش‌دار پس از آموکسی‌سیلین یک آلرژی خفیف است، نه آنافیلاکسی —**",
  "**پس سفتریاکسون در این بیمار مجاز است، و همین گزینه‌ی سوم را قابل دفاع می‌کند.**",
 ],
 PROPH_EN + [
  "WARNING: THIS IS A NEGATIVE QUESTION — it asks which drug you would NOT recommend. See that first.",
  "In a negative question, three options must be defensible and one must not.",
  "THE MORE IMPORTANT CONCEPT: THIS PROCEDURE NEEDS NO PROPHYLAXIS AT ALL.",
  "WARNING: GI ENDOSCOPY AND BIOPSY WERE REMOVED FROM THE PROPHYLAXIS INDICATIONS IN 2007.",
  "Why? Because the evidence showed the transient bacteraemia they cause does not produce meaningful endocarditis,",
  "and the harm of unnecessary antibiotics outweighs the hypothetical benefit.",
  "Today prophylaxis is only for INVASIVE DENTAL procedures in the four high-risk groups.",
  "WARNING, NOW WITHIN THE QUESTION'S OWN FRAME, WHICH OPTION IS WORST?",
  "DOXYCYCLINE 200 MG: doxycycline does appear as an alternative in the newer tables,",
  "but its prophylaxis dose is 100 MG, NOT 200 — and its streptococcal cover is the weakest of the four.",
  "The other three (azithromycin 500, clindamycin 600, ceftriaxone 1 g) are recognised doses.",
  "And note: an itchy rash after amoxicillin is a MILD allergy, not anaphylaxis —",
  "so ceftriaxone is permitted in this patient, which is what makes that third option defensible.",
 ],
 "این سؤال دو لایه دارد و لایه‌ی دومش مهم‌تر از پاسخ خودِ سؤال است.\n\n"
 "**مرد ۲۵ ساله** با **دریچه‌ی میترال مصنوعی از دو سال پیش**، کاندید **آندوسکوپی و بیوپسی "
 "از توده‌ی مری**، با سابقه‌ی **راش پوستی خارش‌دار** پس از آموکسی‌سیلین شش ماه پیش. "
 "**کدام دارو را توصیه نمی‌کنید؟**\n\n"
 "⚠️ **لایه‌ی اول — نکته‌ای که خودِ سؤال نمی‌پرسد ولی مهم‌ترین چیز است:**\n\n"
 "**این بیمار اصلاً به پروفیلاکسی نیاز ندارد.** بله، **بیمار پرخطر است** (دریچه‌ی مصنوعی)، "
 "ولی **شرط دوم برقرار نیست: آندوسکوپی گوارشی یک پروسیجر دندانی نیست.**\n\n"
 "**از سال ۲۰۰۷، آندوسکوپی، کولونوسکوپی، برونکوسکوپی و سیستوسکوپی همگی از فهرست "
 "اندیکاسیون‌های پروفیلاکسی حذف شده‌اند.** دلیلش: شواهد نشان داد باکتریمی گذرای ناشی از "
 "این پروسیجرها **اندوکاردیت معناداری نمی‌سازد**، و ضرر آنتی‌بیوتیک بی‌مورد (آلرژی، "
 "کلستریدیوم دیفیسیل، مقاومت) از فایده‌ی فرضی‌اش بیشتر است.\n\n"
 "⚠️ **لایه‌ی دوم — پاسخ به سؤالی که واقعاً پرسیده شده.**\n\n"
 "سؤال **منفی** است: «کدام را توصیه **نمی‌کنید**؟» پس باید بدترین گزینه را پیدا کنیم:\n\n"
 "• **آزیترومایسین ۵۰۰ میلی‌گرم** — دوز صحیح و شناخته‌شده. قابل دفاع.\n\n"
 "• **کلیندامایسین ۶۰۰ میلی‌گرم** — دوز صحیح در جدول‌های آن زمان. قابل دفاع "
 "(هرچند راهنمای ۲۰۲۱ آن را کنار گذاشته است).\n\n"
 "• **سفتریاکسون ۱ گرم عضلانی** — دوز صحیح. **و مهم: آلرژی این بیمار «راش خارش‌دار» است، "
 "یعنی آلرژی خفیف، نه آنافیلاکسی.** در آلرژی خفیف، **سفالوسپورین مجاز است.** قابل دفاع.\n\n"
 "• **داکسی‌سیکلین ۲۰۰ میلی‌گرم** — ⚠️ **دوز غلط است** (دوز پروفیلاکسی داکسی‌سیکلین "
 "**۱۰۰ میلی‌گرم** است)، و علاوه بر آن **پوشش استرپتوکوک ویریدنس در داکسی‌سیکلین "
 "ضعیف‌ترینِ این چهار داروست.** **این گزینه‌ای است که توصیه نمی‌کنیم.**\n\n"
 "**درس تمایز آلرژی که باید حفظ شود:** راش ساده = آلرژی خفیف = **سفالوسپورین مجاز**. "
 "آنافیلاکسی یا آنژیوادم یا کهیر = **سفالوسپورین ممنوع**.",
 "This question has two layers, and the second matters more than the answer itself.\n\n"
 "A 25-YEAR-OLD MAN with a PROSTHETIC MITRAL VALVE placed two years ago, due for ENDOSCOPY AND "
 "BIOPSY OF AN OESOPHAGEAL MASS, with a history of an ITCHY SKIN RASH after amoxicillin six "
 "months ago. WHICH DRUG WOULD YOU NOT RECOMMEND?\n\n"
 "WARNING, LAYER ONE — WHAT THE QUESTION DOES NOT ASK BUT MATTERS MOST:\n\n"
 "THIS PATIENT NEEDS NO PROPHYLAXIS AT ALL. Yes, HE IS HIGH RISK (a prosthetic valve), but THE "
 "SECOND CONDITION FAILS: GI ENDOSCOPY IS NOT A DENTAL PROCEDURE.\n\n"
 "SINCE 2007, ENDOSCOPY, COLONOSCOPY, BRONCHOSCOPY AND CYSTOSCOPY HAVE ALL BEEN REMOVED FROM "
 "THE PROPHYLAXIS INDICATIONS. The reason: evidence showed the transient bacteraemia from these "
 "procedures DOES NOT PRODUCE MEANINGFUL ENDOCARDITIS, and the harms of unnecessary antibiotics "
 "(allergy, C. difficile, resistance) outweigh the hypothetical benefit.\n\n"
 "WARNING, LAYER TWO — ANSWERING THE QUESTION ACTUALLY ASKED.\n\n"
 "It is a NEGATIVE question: 'which would you NOT recommend?' So we must find the worst option:\n\n"
 "• AZITHROMYCIN 500 MG — the correct, recognised dose. Defensible.\n\n"
 "• CLINDAMYCIN 600 MG — the correct dose in the tables of that era. Defensible (though the 2021 "
 "guidance has since dropped it).\n\n"
 "• CEFTRIAXONE 1 G INTRAMUSCULARLY — correct dose. AND IMPORTANTLY: this patient's allergy is "
 "an ITCHY RASH, that is a MILD allergy, NOT anaphylaxis. With a mild allergy A CEPHALOSPORIN IS "
 "PERMITTED. Defensible.\n\n"
 "• DOXYCYCLINE 200 MG — WARNING, THE DOSE IS WRONG (the prophylaxis dose of doxycycline is "
 "100 MG), and beyond that ITS VIRIDANS STREPTOCOCCAL COVER IS THE WEAKEST OF THE FOUR. THIS IS "
 "THE ONE WE WOULD NOT RECOMMEND.\n\n"
 "THE ALLERGY DISTINCTION TO MEMORISE: a simple rash = mild allergy = CEPHALOSPORIN ALLOWED. "
 "Anaphylaxis, angioedema or urticaria = CEPHALOSPORIN FORBIDDEN.",
 ["آزیترومایسین ۵۰۰ میلی‌گرم یک ساعت قبل، دوز و زمان استانداردی است و قابل دفاع است.",
  "کلیندامایسین ۶۰۰ میلی‌گرم دوز شناخته‌شده‌ی آن زمان بود؛ اشکالش دوز نیست.",
  "پاسخ صحیح — دوز پروفیلاکسی داکسی‌سیکلین ۱۰۰ میلی‌گرم است نه ۲۰۰، و پوشش استرپتوکوکی‌اش ضعیف‌ترین است.",
  "آلرژی بیمار راش خفیف است نه آنافیلاکسی، پس سفتریاکسون مجاز و دوزش هم درست است."],
 ["Azithromycin 500 mg one hour before is a standard dose and timing, and is defensible.",
  "Clindamycin 600 mg was the recognised dose of that era; its dose is not the problem.",
  "Correct — the doxycycline prophylaxis dose is 100 mg, not 200, and its streptococcal cover is the weakest.",
  "The patient's allergy is a mild rash, not anaphylaxis, so ceftriaxone is permitted and correctly dosed."],
 "**راش ساده = سفالوسپورین مجاز. آنافیلاکسی = ممنوع.** و آندوسکوپی اصلاً پروفیلاکسی نمی‌خواهد.",
 "A simple rash permits a cephalosporin, anaphylaxis forbids it; and endoscopy needs no prophylaxis at all.",
 [WILSON, H128])



# =========================================================== book:122
# Written because apply_en.py refused the batch without it: EN13 had a
# translation for this question but B29 had no lesson, and the guard reported
# "idx 122: has English but no lesson". English is only attached to questions
# that already teach, so that the stem, the options and the teaching text can
# never drift apart. The guard was right and the lesson was the missing half.
add("book:122", "case", "medium",
 "دریچه‌ی طبیعیِ آسیب‌دیده + وژتاسیون ← رژیم تجربی **سفتریاکسون + وانکومایسین**.",
 "A damaged NATIVE valve with a vegetation: the empirical regimen is CEFTRIAXONE PLUS VANCOMYCIN.",
 RX_FA + [
  "⚠️ **تفاوت این سؤال با سؤال دریچه‌ی مصنوعی را ببینید: اینجا دریچه طبیعی است.**",
  "**بیمار «مشکل دریچه‌ای» قبلی دارد، ولی دریچه‌ی مصنوعی ندارد** — پس جسم خارجی و بیوفیلمی در کار نیست.",
  "**و چون بیوفیلم نیست، ریفامپین هم لازم نیست.** این تمایز کلیدی است.",
  "**رژیم تجربی دریچه‌ی طبیعی باید دو گروه را بپوشاند:**",
  "**یک — استرپتوکوک‌های ویریدنس** (شایع‌ترین در دریچه‌ی آسیب‌دیده‌ی غیرمعتاد) ← **سفتریاکسون**.",
  "**دو — استافیلوکوک، از جمله MRSA** (چون هنوز کشت نداریم) ← **وانکومایسین**.",
  "⚠️ **پس سفتریاکسون + وانکومایسین دقیقاً همان دو پوشش لازم را می‌دهد.**",
  "**سیر ۱۰ روزه و سوفل ملایم ۲/۶ به تابلوی تحت‌حاد ویریدنس می‌خورد،**",
  "**ولی تا وقتی کشت نیامده، پوشش استاف را نمی‌توان کنار گذاشت.**",
  "**و ضایعات دردناک کف دست و پا؟ درد یعنی ندول اسلر، یعنی پدیده‌ی ایمونولوژیک.**",
  "⚠️ **یادآوری تمایز: اسلر دردناک و ایمونولوژیک؛ جین‌وی بدون درد و آمبولیک.**",
 ],
 RX_EN + [
  "WARNING: SEE HOW THIS DIFFERS FROM THE PROSTHETIC-VALVE QUESTION — here the valve is NATIVE.",
  "The patient has a previous 'valve problem' but NO prosthetic valve, so there is no foreign body and no biofilm.",
  "AND WITH NO BIOFILM, NO RIFAMPICIN IS NEEDED. That is the key distinction.",
  "An empirical native-valve regimen must cover two groups:",
  "ONE — VIRIDANS STREPTOCOCCI (commonest on a damaged valve in a non-user) -> CEFTRIAXONE.",
  "TWO — STAPHYLOCOCCI INCLUDING MRSA (since cultures are not back) -> VANCOMYCIN.",
  "WARNING: SO CEFTRIAXONE PLUS VANCOMYCIN GIVES EXACTLY THE TWO COVERS REQUIRED.",
  "The ten-day course and the soft 2/6 murmur fit a subacute viridans picture,",
  "but until cultures return, staphylococcal cover cannot be dropped.",
  "And the PAINFUL lesions on palms and soles? PAIN means OSLER NODES, an immunologic phenomenon.",
  "WARNING, RECALL THE DISTINCTION: Osler nodes are painful and immunologic; Janeway lesions are painless and embolic.",
 ],
 "این سؤال را باید در کنار سؤال دریچه‌ی مصنوعی خواند — تفاوتشان کل درس است.\n\n"
 "**آقای ۲۴ ساله** با تب و لرز ۱۰ روزه، **سابقه‌ی مشکل دریچه‌ای**، سوفل **۲/۶** میترال، "
 "**ضایعات دردناک کف دست و پا**، و **وژتاسیون ۱ سانتی‌متری روی لت قدامی میترال**.\n\n"
 "⚠️ **نکته‌ی اول و تعیین‌کننده: این یک دریچه‌ی طبیعیِ آسیب‌دیده است، نه دریچه‌ی مصنوعی.**\n\n"
 "بیمار «مشکل دریچه‌ای» دارد — یعنی زمینه‌ی مستعدکننده — ولی **هیچ جسم خارجی‌ای در قلبش "
 "نیست.** و این یعنی **بیوفیلمی وجود ندارد، پس ریفامپین لازم نیست.**\n\n"
 "**رژیم تجربی دریچه‌ی طبیعی باید دو گروه ارگانیسم را بپوشاند:**\n\n"
 "**۱) استرپتوکوک‌های ویریدنس** — شایع‌ترین عامل روی دریچه‌ی آسیب‌دیده در فرد غیرمعتاد. "
 "سیر تحت‌حاد ۱۰ روزه هم دقیقاً به همین می‌خورد. → **سفتریاکسون**\n\n"
 "**۲) استافیلوکوک، از جمله MRSA** — چون هنوز جواب کشت نداریم و استاف اورئوس همیشه "
 "محتمل است. → **وانکومایسین**\n\n"
 "**پس سفتریاکسون + وانکومایسین دقیقاً همان دو پوشش لازم را می‌دهد.**\n\n"
 "⚠️ **و یک نکته‌ی تشخیصی جانبی که ارزش توجه دارد: «ضایعات دردناک کف دست و پا».**\n\n"
 "**درد** کلمه‌ی کلیدی است. **ندول اسلر دردناک است و پدیده‌ی ایمونولوژیک** (رسوب کمپلکس "
 "ایمنی)، در حالی که **ضایعه‌ی جین‌وی بدون درد است و پدیده‌ی عروقی/آمبولیک**. "
 "پس این یافته یک **معیار مینور ایمونولوژیک** است.\n\n"
 "**چرا سایر گزینه‌ها نه؟** پیپراسیلین/تازوباکتام + لینزولید پوشش بسیار وسیع و نامناسبی "
 "برای اندوکاردیت است. سیپروفلوکساسین جایی در درمان اندوکاردیت ندارد. آمپی‌سیلین + "
 "جنتامایسین رژیم انتروکوک است و MRSA را نمی‌پوشاند.",
 "Read this question beside the prosthetic-valve one — the difference between them is the whole "
 "lesson.\n\n"
 "A 24-YEAR-OLD MAN with ten days of fever and rigors, A PREVIOUS VALVE PROBLEM, a 2/6 mitral "
 "murmur, PAINFUL LESIONS ON THE PALMS AND SOLES, and a 1 CM VEGETATION on the anterior mitral "
 "leaflet.\n\n"
 "WARNING, THE FIRST AND DECISIVE POINT: THIS IS A DAMAGED NATIVE VALVE, NOT A PROSTHETIC ONE.\n\n"
 "The patient has a 'valve problem' — a predisposition — but THERE IS NO FOREIGN BODY IN HIS "
 "HEART. And that means THERE IS NO BIOFILM, SO NO RIFAMPICIN IS NEEDED.\n\n"
 "AN EMPIRICAL NATIVE-VALVE REGIMEN MUST COVER TWO GROUPS:\n\n"
 "1) VIRIDANS STREPTOCOCCI — the commonest agent on a damaged valve in a non-user, and the "
 "subacute ten-day course fits exactly. -> CEFTRIAXONE\n\n"
 "2) STAPHYLOCOCCI INCLUDING MRSA — because cultures are not back and S. aureus is always "
 "possible. -> VANCOMYCIN\n\n"
 "SO CEFTRIAXONE PLUS VANCOMYCIN PROVIDES PRECISELY THE TWO COVERS REQUIRED.\n\n"
 "WARNING, AND A DIAGNOSTIC ASIDE WORTH NOTICING: 'PAINFUL LESIONS ON THE PALMS AND SOLES'.\n\n"
 "PAIN is the key word. OSLER NODES ARE PAINFUL AND IMMUNOLOGIC (deposited immune complexes), "
 "whereas JANEWAY LESIONS ARE PAINLESS AND VASCULAR/EMBOLIC. So this finding is an IMMUNOLOGIC "
 "MINOR CRITERION.\n\n"
 "WHY NOT THE OTHERS? Piperacillin/tazobactam plus linezolid is far too broad and inappropriate "
 "for endocarditis. Ciprofloxacin has no place in endocarditis therapy. Ampicillin plus "
 "gentamicin is an enterococcal regimen and does not cover MRSA.",
 ["پوشش بسیار وسیع و نامناسب برای اندوکاردیت دریچه‌ی طبیعی؛ گرم‌منفی‌های مقاوم اینجا هدف نیستند.",
  "پاسخ صحیح — سفتریاکسون ویریدنس را و وانکومایسین استاف از جمله MRSA را می‌پوشاند.",
  "سیپروفلوکساسین در درمان اندوکاردیت جایگاهی ندارد و پوشش استرپتوکوکی ضعیفی دارد.",
  "آمپی‌سیلین + جنتامایسین رژیم انتروکوک است و استاف مقاوم به متی‌سیلین را پوشش نمی‌دهد."],
 ["Far too broad and inappropriate for native-valve endocarditis; resistant gram-negatives are not the target.",
  "Correct — ceftriaxone covers viridans streptococci and vancomycin covers staphylococci including MRSA.",
  "Ciprofloxacin has no place in endocarditis therapy and covers streptococci poorly.",
  "Ampicillin plus gentamicin is an enterococcal regimen and does not cover methicillin-resistant staphylococci."],
 "**دریچه‌ی طبیعی = بدون بیوفیلم = بدون ریفامپین.** سفتریاکسون برای ویریدنس، وانکومایسین برای استاف.",
 "A native valve means no biofilm and no rifampicin; ceftriaxone for viridans, vancomycin for staphylococci.",
 [BADDOUR, H128])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book29.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 29 lessons:', len(L))
