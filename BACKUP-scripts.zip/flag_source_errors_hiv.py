# -*- coding: utf-8 -*-
"""Two SOURCE errors in the HIV/hepatitis block that glyph geometry cannot fix.

The distinction this bank has kept from the beginning, and keeps here:

  * an EXTRACTION defect means the page prints one thing and our text says
    another. Glyph geometry settles it, and the text is REPAIRED.
  * a SOURCE error means the page itself prints something wrong. There is no
    physical fact to appeal to, so the text is LEFT ALONE and ANNOTATED.

Rewriting a source error would show the student something different from the
real booklet they will sit the exam with. Annotating it teaches both the
medicine and the fact that printed material can be wrong — the same lesson the
corrected keys teach.

---------------------------------------------------------------- q9854
"Bil Total: 1.5 mg/dl    Bil Direct: 3.5 mg/dl"

THE DIRECT BILIRUBIN EXCEEDS THE TOTAL. That is arithmetically impossible: the
total is the sum of the direct (conjugated) and indirect (unconjugated)
fractions, so the direct can at most EQUAL the total, never exceed it.

Glyph geometry proves this is the book's own error and not ours. On page 314
the characters are drawn, in ascending x:

    Bil Direct:  '3' at x=284.6, '.' at 294.6, '5' at 304.6
    Bil Total:   '1' at x=478.4, '.' at 488.4, '5' at 498.4

so the page really does print Direct 3.5 beside Total 1.5. Our extraction is
faithful; the typesetter transposed the two values.

The intended panel is almost certainly Total 3.5 with Direct 1.5, which fits
the vignette (acute hepatitis with jaundice and a conjugated fraction that is
a plausible share of the total).

DOES IT CHANGE THE ANSWER? No, and that is worth telling the student. The
question is decided entirely by the SEROLOGY — anti-HAV IgM positive AND
anti-HBc IgM positive AND HBsAg positive means simultaneous acute A and acute
B — and by ALT 1300 / AST 1100 confirming a hepatocellular pattern. The
bilirubin fractions are supporting detail. But the error is annotated so that
nobody, human or script, later "repairs" the digits and makes the impossible
panel look plausible.

---------------------------------------------------------------- q9852
"سطح خونی آنتی‌بادی ... 5 واحد بین‌المللی در هر میلی‌لیتر"

The unit is misprinted. Anti-HBs is reported in mIU/mL (milli-international
units per millilitre), not IU/mL, and the protective threshold everyone
memorises is 10 mIU/mL. A titre of "5 IU/mL" would be 5000 mIU/mL — five
hundred times the protective level — which would make the patient a
well-protected responder and invert the whole question.

The page prints واحد بین‌المللی (international unit) with no milli- prefix, so
again this is the source and not the extraction.

The question only makes sense on the intended reading: 5 mIU/mL is BELOW the
protective threshold of 10, so this intern is a NON-RESPONDER despite three
doses, and after a needlestick from an HBsAg-positive source needs BOTH HBIG
AND a repeat vaccine series — which is exactly the printed key. So the key is
right and only the unit is wrong. Note that q9856 in the same chapter prints
the very same shape ("titre of about 6") for the same clinical point.
"""
import io
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))

# question_no -> list of annotations
FLAGS = {
    9854: [{
        'where': 'stem',
        'contains': 'Bil',
        'kind': 'impossible laboratory panel (transposed values)',
        'fa': '⚠️ **خطای چاپی در خودِ کتاب:** در پنل آزمایشگاهی این سؤال، '
              '**بیلی‌روبین مستقیم ۳٫۵ و بیلی‌روبین توتال ۱٫۵** چاپ شده است — یعنی '
              '**مستقیم از توتال بیشتر است**، که از نظر ریاضی ناممکن است. توتال '
              '**مجموع** کسر مستقیم (کونژوگه) و غیرمستقیم است، پس مستقیم حداکثر '
              'می‌تواند **برابر** توتال باشد، هرگز بیشتر.\n\n'
              'هندسه‌ی گلیف ثابت می‌کند این خطای کتاب است نه خطای ما: در صفحه ۳۱۴ '
              'نویسه‌های «۳٫۵» در x برابر ۲۸۴٫۶ تا ۳۰۴٫۶ کنار عبارت Direct، و «۱٫۵» در '
              'x برابر ۴۷۸٫۴ تا ۴۹۸٫۴ کنار عبارت Total چاپ شده‌اند. پس صفحه واقعاً همین '
              'را چاپ کرده و **متن ما وفادار است**؛ حروف‌چین دو مقدار را جابه‌جا کرده.\n\n'
              'پنل موردنظر تقریباً به‌قطع **توتال ۳٫۵ و مستقیم ۱٫۵** بوده است.\n\n'
              '**آیا پاسخ را عوض می‌کند؟ نه** — و همین را باید بدانید. این سؤال کاملاً با '
              '**سرولوژی** حل می‌شود: **anti-HAV IgM مثبت** به‌علاوه‌ی **anti-HBc IgM '
              'مثبت** به‌علاوه‌ی **HBsAg مثبت** یعنی هپاتیت **حاد A و حاد B هم‌زمان**. '
              'ارقام بیلی‌روبین جزئیات پشتیبان‌اند. متن عمداً دست‌نخورده مانده تا با '
              'دفترچه‌ی چاپی یکی باشد، و خطا فقط علامت‌گذاری شده است.',
        'en': 'WARNING, A MISPRINT IN THE SOURCE BOOK ITSELF: this stem\'s laboratory panel '
              'prints DIRECT BILIRUBIN 3.5 beside TOTAL BILIRUBIN 1.5 — that is, the DIRECT '
              'EXCEEDS THE TOTAL, which is arithmetically impossible. The total is the SUM of '
              'the direct (conjugated) and indirect fractions, so the direct can at most EQUAL '
              'the total, never exceed it.\n\n'
              'Glyph geometry proves this is the book\'s error and not ours: on page 314 the '
              'characters "3.5" are drawn at x = 284.6 to 304.6 beside the word Direct, and '
              '"1.5" at x = 478.4 to 498.4 beside the word Total. So the page really does print '
              'this, OUR EXTRACTION IS FAITHFUL, and the typesetter transposed the two values.\n\n'
              'The intended panel was almost certainly TOTAL 3.5 with DIRECT 1.5.\n\n'
              'DOES IT CHANGE THE ANSWER? NO — and you should know why. The question is decided '
              'entirely by the SEROLOGY: anti-HAV IgM positive PLUS anti-HBc IgM positive PLUS '
              'HBsAg positive means SIMULTANEOUS ACUTE A AND ACUTE B. The bilirubin fractions '
              'are supporting detail. The text is deliberately left unchanged so that it matches '
              'the printed booklet, and the error is only annotated.',
    }],
    9852: [{
        'where': 'stem',
        # NOT 'واحد بین‌المللی': the stored stem carries the stray internal
        # space this extractor produces, so it reads 'بی نالمللی'. The guard
        # caught this on the first run, which is exactly what the guard is for
        # — a silent no-match would have annotated nothing and reported success.
        'contains': '5 واحد',
        'kind': 'wrong unit (IU/mL printed where mIU/mL belongs)',
        'fa': '⚠️ **خطای واحد در خودِ کتاب:** تیتر آنتی‌بادی این کارورز «**۵ واحد '
              'بین‌المللی در هر میلی‌لیتر**» چاپ شده، ولی anti-HBs همیشه با واحد '
              '**mIU/mL** (میلی‌واحد بین‌المللی) گزارش می‌شود، نه IU/mL.\n\n'
              '**چرا این تفاوت حیاتی است:** آستانه‌ی محافظت که همه حفظ می‌کنند '
              '**۱۰ mIU/mL** است. اگر عدد را «۵ IU/mL» بخوانید، یعنی **۵۰۰۰ mIU/mL** — '
              '**پانصد برابر** سطح محافظ — و آنگاه این فرد یک **پاسخ‌دهنده‌ی کاملاً '
              'ایمن** است و کل سؤال وارونه می‌شود.\n\n'
              'صفحه عبارت «واحد بین‌المللی» را بدون پیشوند «میلی» چاپ کرده، پس این هم '
              '**خطای منبع** است نه خطای استخراج.\n\n'
              '**سؤال فقط با خوانش درست معنا می‌دهد:** ۵ mIU/mL **زیر** آستانه‌ی ۱۰ است، '
              'پس این کارورز با وجود سه دوز واکسن یک **نان‌رسپاندر** است، و پس از '
              'نیدل‌استیک از منبع HBsAg مثبت به **هر دو** یعنی **HBIG و تکرار سری کامل '
              'واکسن** نیاز دارد — که دقیقاً همان کلید چاپی است. **پس کلید درست است و '
              'فقط واحد غلط است.**',
        'en': 'WARNING, A UNIT ERROR IN THE SOURCE BOOK: this intern\'s antibody titre is printed '
              'as "5 INTERNATIONAL UNITS per millilitre", but anti-HBs is always reported in '
              'mIU/mL (MILLI-international units), not IU/mL.\n\n'
              'WHY THE DIFFERENCE IS CRITICAL: the protective threshold everyone memorises is '
              '10 mIU/mL. Read as "5 IU/mL" the value would be 5000 mIU/mL — FIVE HUNDRED TIMES '
              'the protective level — which would make this person a FULLY PROTECTED RESPONDER '
              'and invert the entire question.\n\n'
              'The page prints "international unit" with no milli- prefix, so this too is a '
              'SOURCE ERROR and not an extraction defect.\n\n'
              'THE QUESTION ONLY MAKES SENSE ON THE INTENDED READING: 5 mIU/mL is BELOW the '
              'threshold of 10, so despite three doses this intern is a NON-RESPONDER, and after '
              'a needlestick from an HBsAg-positive source needs BOTH HBIG AND a repeat vaccine '
              'series — which is exactly the printed key. SO THE KEY IS RIGHT AND ONLY THE UNIT '
              'IS WRONG.',
    }],
}


def main():
    done, missing = [], []
    for i in range(1, 6):
        p = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        if not os.path.exists(p):
            continue
        body = json.load(io.open(p, encoding='utf-8'))
        dirty = False
        for q in body['questions']:
            specs = FLAGS.get(q['question_no'])
            if not specs:
                continue
            for spec in specs:
                text = q['question_fa']
                if spec['contains'] not in text:
                    missing.append(
                        f"q{q['question_no']}: the stem no longer contains "
                        f"{spec['contains']!r} — has it already been edited?")
                    continue
                notes = q.setdefault('source_defects', [])
                # already annotated is NOT a failure: these scripts must be
                # idempotent, a rule learned when a rerun reported five
                # ALREADY-CORRECT questions as failures
                if any(n.get('kind') == spec['kind'] for n in notes):
                    done.append(f"q{q['question_no']}: already annotated ({spec['kind']})")
                    continue
                notes.append({
                    'where': spec['where'],
                    'kind': spec['kind'],
                    'note_fa': spec['fa'],
                    'note_en': spec['en'],
                    'action': 'annotated, text left unchanged (this is a source error, '
                              'not an extraction defect)',
                })
                done.append(f"q{q['question_no']}: flagged — {spec['kind']}")
                dirty = True
        if dirty:
            json.dump(body, io.open(p, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)

    for d in done:
        print('  ', d)
    assert not missing, missing
    assert done, 'no question matched; the script did nothing'
    print(f'\nsource defects annotated: {len(done)}')


if __name__ == '__main__':
    main()
