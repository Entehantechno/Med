# -*- coding: utf-8 -*-
"""English stems and options for the batch-30 and batch-31 questions.

Genital ulcers, urethritis, and HIV testing, staging and prophylaxis.

Rule 16 checked first, as always: these items come from sittings 93 to 98, for
which the ministry published no English booklet, so these are hand-written
translations rather than official ones.

Translation decisions worth recording
-------------------------------------
THE ULCER ADJECTIVES ARE THE ANSWER, so they are translated with unusual care.
This chapter's genital-ulcer questions are decided entirely by two properties —
painful or painless, soft or hard — and a loose translation would destroy the
question. So:

  * "نرم" is rendered SOFT and "سفت" FIRM, never "tender"/"indurated", because
    the contrast being tested is texture, not tenderness
  * "بدون تندرنس" is NON-TENDER and "بدون درد" is PAINLESS; the Persian
    distinguishes them and so does the English
  * "بستر تمیز" is a CLEAN BASE, the standard English phrase for a chancre
  * q9558's "تورم الستیکی" is RUBBERY SWELLING, the conventional description of
    syphilitic nodes

q9541 (idx 541): the ceftriaxone dose was repaired from "mg052" to 250 mg
before this file was written, and the English carries 250 mg. That number is
not decoration: the question turns on the gonorrhoea having been treated
CORRECTLY, so that returning symptoms must mean untreated chlamydia rather
than an inadequate dose. Note this question is not translated here — it already
had a lesson from an earlier batch — but the repair is recorded because it
belongs to the same chapter and the same reasoning.

q9548 (idx 548): NOT translated here for the same reason as q9541's neighbours
— it has no lesson in these batches.

THE HIV TESTING STEMS keep their exact test names in English, including
"Western blot", even though the CDC withdrew that test in 2014. The stem must
say what the paper said; it is the LESSON that explains the guideline has
moved. Changing the stem would misrepresent the exam.

q9702 (idx 702): the CD4 of 250 and the "same for the past 4 months" are both
preserved, because the question is decided by two conditions — above the
threshold AND stable beyond three months — and dropping either makes the
answer unreachable.

q9706 (idx 706): the CD4 of 45 is preserved for the same reason. It sits below
two separate thresholds (200 and 50), and each one adds a drug to the answer.
"""

EN14 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    assert all(o.strip() for o in options), idx
    EN14[idx] = {"stem_en": stem, "options_en": options}


# ==================================== genital ulcers and urethritis (batch 30)
add(530,
    "Five days after intercourse, a young man has developed multiple irregular, soft and very "
    "painful pustules with a purulent base on the shaft of the penis. On examination the lesions "
    "are of varying size and bleed easily, and the lymph nodes on the right are painful and "
    "suppurative. Which differential diagnosis is most likely?",
    ["Chancroid",
     "Syphilis",
     "Lymphogranuloma venereum",
     "Herpes"])

add(544,
    "A married woman presents with multiple painful genital ulcers with discharge, and a diagnosis "
    "of chancroid is made. Which treatment is NOT recommended for her?",
    ["Azithromycin",
     "Gentamicin",
     "Ciprofloxacin",
     "Ceftriaxone"])

add(545,
    "A 25-year-old man develops urethral burning with urethral discharge after intercourse. He is "
    "given one intramuscular ampoule of ceftriaxone and improves, but one week later the symptoms "
    "of urethritis return. He has had no further sexual contact in the interval. Which treatment "
    "do you choose?",
    ["Another intramuscular ampoule of ceftriaxone",
     "Azithromycin 1 g orally",
     "One intramuscular ampoule of ceftriaxone plus azithromycin 1 g orally",
     "None of the above"])

add(546,
    "One week after unprotected intercourse, a young man has mild urethral burning and serous "
    "discharge. Which treatment is correct?",
    ["Single-dose ceftriaxone plus treatment of the sexual partner",
     "Single-dose azithromycin 1 g plus treatment of the sexual partner",
     "Single-dose ceftriaxone plus single-dose azithromycin 1 g",
     "Single-dose ceftriaxone plus single-dose azithromycin 1 g plus treatment of the sexual partner"])

add(549,
    "A young single man presents one week after unprotected intercourse with symptoms of "
    "urethritis. No organism is seen on examination of the urethral discharge. What is the most "
    "appropriate empirical treatment for him?",
    ["Single-dose ceftriaxone",
     "A single 1 g dose of azithromycin",
     "Single-dose ceftriaxone together with a single 1 g dose of azithromycin",
     "Cefixime for 7 days together with doxycycline for 7 days"])

add(552,
    "A 22-year-old man presents with evidence of unilateral epididymo-orchitis. Following "
    "unprotected intercourse three weeks earlier he first developed a purulent urethral discharge, "
    "and he has received no treatment up to this presentation. Which antibiotic treatment do you "
    "recommend?",
    ["Ofloxacin for 14 days",
     "Cefuroxime for 14 days",
     "Single-dose ceftriaxone plus doxycycline capsules for 10 days",
     "Single-dose ceftriaxone plus azithromycin tablets"])

add(553,
    "One week after intercourse a young man develops a purulent urethral discharge. A gram stain "
    "of the urethral discharge is reported as showing intracellular gram-negative diplococci. The "
    "treatment regimen for this patient is:",
    ["Single-dose intramuscular ceftriaxone plus doxycycline",
     "Single-dose intramuscular ceftriaxone alone",
     "Single-dose ciprofloxacin plus doxycycline",
     "A single 1 g oral dose of erythromycin"])

add(557,
    "One month after unprotected intercourse, a young man has developed a painless, firm, raised, "
    "round 1 cm papule with well-defined margins on the penis. The lesion is non-purulent and "
    "clean, and there is simultaneous bilateral swelling of the inguinal lymph nodes. Given the "
    "clinical picture, what is the most likely diagnosis?",
    ["Chancroid",
     "Syphilis",
     "Lymphogranuloma venereum",
     "Donovanosis"])

add(558,
    "Two weeks after a suspicious sexual contact, a 28-year-old woman notices a papule on the "
    "vulva which gradually enlarges and then ulcerates. On examination there is an oval, fairly "
    "deep ulcer 1 cm across, non-tender, with rubbery swelling, regular edges and a clean base, "
    "together with bilateral non-tender lymphadenopathy. Given the most likely diagnosis, which "
    "treatment is appropriate?",
    ["Ceftriaxone",
     "Ciprofloxacin",
     "Azithromycin",
     "Benzathine penicillin"])

add(561,
    "In the tests of a 25-year-old woman attending to donate blood, the VDRL is reported positive. "
    "What is the first appropriate step?",
    ["Give penicillin",
     "Perform an FTA-ABS test",
     "Perform an anti-double-stranded DNA test",
     "Follow the patient's symptoms"])


# ============================ HIV testing, staging and prophylaxis (batch 31)
add(669,
    "An internal medicine intern sustains a needlestick injury while taking blood from a known "
    "HIV-positive patient; the needle, contaminated with the patient's blood, penetrates the "
    "intern's hand. For how long is antiretroviral prophylaxis recommended?",
    ["12 weeks",
     "2 weeks",
     "8 weeks",
     "4 weeks"])

add(675,
    "A 25-year-old man who injects drugs attended a physician about two weeks ago and had an HIV "
    "antibody test by ELISA, which was positive. At this stage, which of the following is correct "
    "in helping to reach a final diagnosis of HIV infection in this patient?",
    ["The diagnosis of HIV infection is certain",
     "Request a repeat HIV antibody test by ELISA",
     "Request an HIV antibody test by Western blot",
     "Request an HIV RNA test by PCR"])

add(691,
    "A woman who injects drugs presents with two positive ELISA tests for HIV infection. Which "
    "test do you request to confirm the diagnosis?",
    ["Western blot",
     "Enzyme immunoassay",
     "CD4-positive T lymphocyte count",
     "No further test is needed"])

add(695,
    "Three weeks after high-risk sexual contact with a woman who injects drugs, a young man "
    "develops fever, sore throat, myalgia, weight loss and lymphadenopathy. His rapid HIV test is "
    "positive. What is the next step?",
    ["Repeat the test two weeks later",
     "HIV antibody ELISA",
     "Western blot test",
     "HIV PCR"])

add(700,
    "A 35-year-old man who injects drugs presents with cough and breathlessness for the past two "
    "months. Investigations report a positive anti-HIV and a CD4 count below 200. On examination "
    "oral candidiasis is evident. Which of the following do you recommend?",
    ["Checking the cryptococcal antigen level",
     "Examining the sputum for PCP",
     "Blood culture for acid-fast bacilli",
     "Examining the sputum by fungal culture and staining"])

add(702,
    "A patient with HIV and positive IgG against toxoplasma has been on prophylactic "
    "trimethoprim/sulfamethoxazole for the past 7 months. A CD4 count is taken and reported as "
    "250 per microlitre. Given that the CD4 count was at the same level 4 months ago as well, what "
    "is the appropriate recommendation for him?",
    ["Stop the trimethoprim/sulfamethoxazole",
     "Continue the trimethoprim/sulfamethoxazole",
     "Change the drug to dapsone plus pyrimethamine",
     "Add clindamycin"])

add(706,
    "A 27-year-old man, a known case of HIV, is referred to you with a letter from the health "
    "centre. The history states that the patient's father began treatment for TB last week. In the "
    "accompanying tests the patient has a CD4 count of 45. Which of the following do you recommend?",
    ["Daily co-trimoxazole plus weekly azithromycin",
     "Daily co-trimoxazole plus weekly azithromycin plus daily isoniazid plus daily vitamin B6",
     "Daily co-trimoxazole plus daily isoniazid plus daily vitamin B6",
     "Weekly azithromycin plus daily isoniazid plus daily vitamin B6"])
