# -*- coding: utf-8 -*-
"""Attach authored micro-lessons to book questions and promote them to the path.

A book question ships with the official answer but no teaching content, so the
importer routes it to `bank_only` — searchable and usable in exam simulation,
but kept off the curated learning path where a student expects a lesson after
answering.

This script closes that loop: when a lesson exists for a question, it writes the
lesson in and clears `needs_lesson`, which is exactly the condition the importer
checks. The question then lands on the learning path on the next import, with no
change to the server needed.

Keys in lessons_book.json are `book:<flat index>` into the concatenated parts.
"""
import json, io, os

HERE = os.path.dirname(os.path.abspath(__file__))
BANK = '/home/user/project/tools/infectious-bank'
# Lessons are authored in numbered batches (B1, B2, ...) so a batch stays a
# reviewable unit; they are merged here.
LESSON_FILES = sorted(
    f for f in os.listdir(HERE)
    if f.startswith('lessons_book') and f.endswith('.json')
)


def main():
    lessons = {}
    for f in LESSON_FILES:
        part = json.load(io.open(os.path.join(HERE, f), encoding='utf-8'))
        dup = set(part) & set(lessons)
        assert not dup, f'{f} redefines lessons already written: {sorted(dup)[:5]}'
        lessons.update(part)
    attached, skipped_disputed = 0, 0
    idx = 0

    for i in range(1, 6):
        p = os.path.join(BANK, f'import-payload.book.part{i:02d}.json')
        if not os.path.exists(p):
            continue
        body = json.load(io.open(p, encoding='utf-8'))
        for q in body['questions']:
            les = lessons.get(f'book:{idx}')
            idx += 1
            if not les:
                continue
            # never promote a question whose printed key we do not trust
            if q.get('key_disputed'):
                skipped_disputed += 1
                continue

            q['explanation_fa'] = les['explanation_fa']
            q['explanation_en'] = les['explanation_en']
            q['options_why_fa'] = les['why_fa']
            q['options_why_en'] = les['why_en']
            q['micro'] = les['micro']
            q['golden_fa'] = les['golden_fa']
            q['golden_en'] = les['golden_en']
            q['refs'] = les['refs']
            q['question_style'] = les['style']
            q['difficulty'] = les['difficulty']
            # English stem/options are still missing for book items; the lesson
            # supplies English teaching text, which is what the learner reads
            # after answering. Mark the remaining gap honestly.
            q['en_partial'] = not q.get('question_en')
            q['needs_lesson'] = False
            q.pop('premium', None)
            attached += 1
        json.dump(body, io.open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

    print(f'lessons available : {len(lessons)}')
    print(f'attached          : {attached}')
    if skipped_disputed:
        print(f'skipped (disputed key): {skipped_disputed}')


if __name__ == '__main__':
    main()
