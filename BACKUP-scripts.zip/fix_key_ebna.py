# -*- coding: utf-8 -*-
"""One printed key in the mononucleosis block that is wrong: q9604.

The conservative rule as always: the printed key is presumed right, and is
overruled only when a primary source says plainly that it is wrong AND the
argument survives being written out for a student. This one does not survive —
in fact the printed key asserts the exact opposite of what the marker means.

------------------------------------------------------------------ q9604
"An 18-year-old woman with fever and sore throat. On examination there is
obvious exudative pharyngitis, cervical lymphadenopathy and hepatosplenomegaly,
and her tests show lymphocytosis with more than 12% atypical lymphocytes. Which
is the MOST USEFUL DIAGNOSTIC TEST to establish her diagnosis?"

Options:
   (A) IgM antibody for EBNA (Epstein-Barr Nuclear Antigen)
   (B) Heterophile test
   (C) IgM antibody for VCA (Viral Capsid Antigen)
   (D) IgM antibody for EA (early antigen)
Printed key: (A) anti-EBNA.

WHY THE KEY CANNOT STAND
-------------------------
EBNA is the antigen the virus expresses only once it BEGINS TO ESTABLISH
LATENCY, that is, once the acute illness is over. Antibody to EBNA therefore
appears 6 to 12 weeks AFTER the onset of symptoms and then persists for life.

The consequence is the exact inverse of what the printed key claims, and every
source states it in almost the same words:

  * American Academy of Pediatrics Red Book: "IgG antibodies to EBNA appear
    6-12 weeks after the onset of symptoms and persist throughout life; THEIR
    PRESENCE EARLY IN THE COURSE OF ILLNESS EFFECTIVELY EXCLUDES ACUTE EBV
    INFECTION."
  * The Red Book adds the positive form of the same rule: the diagnosis is
    almost certain "in the presence of IgM anti-VCA antibodies AND THE ABSENCE
    OF IgG EBNA antibodies."
  * UK laboratory practice uses EBNA as a screening test for exactly this
    reason: "a positive result indicates PAST infection and EXCLUDES primary
    infection within the preceding 6 weeks."

So in a patient who is acutely ill TODAY, an EBNA antibody is not merely a poor
test — a positive result would ARGUE AGAINST the diagnosis the question is
asking us to establish.

VCA IgM is the marker that does the job. It is present at the onset of illness
(EBV's long 4-to-8-week incubation means antibody is already up by the time
symptoms begin), and it wanes over about 3 months, so it is a reliable marker
of acute infection.

  Correction: A -> C (IgM anti-VCA).

WHY NOT THE HETEROPHILE TEST, WHICH IS ALSO A REASONABLE ANSWER
----------------------------------------------------------------
This deserves stating, because a thoughtful student will choose it.

The heterophile (Monospot) test is the usual FIRST test in an adolescent or
adult, and in that sense it is the practical answer. But the stem asks for the
MOST USEFUL test TO ESTABLISH THE DIAGNOSIS, and the heterophile test cannot
establish it:

  * it is an antibody to an unrelated animal red-cell antigen, not to EBV at
    all, so it is not specific for the virus
  * it is falsely negative in about 25% of adults in the first week
  * and it is negative in a large share of children under 4

VCA IgM is EBV-specific and positive at presentation. Between an unrelated
non-specific agglutination and a virus-specific IgM, the one that ESTABLISHES
the diagnosis is the IgM.

The lesson written for this question teaches both: that the heterophile test is
what you order first in practice, and that VCA IgM is what proves it. The
correction is therefore from a wrong answer to a right one, not from one
defensible answer to another.

Options are matched by TEXT rather than by a fixed index, so a reordering of
the payload can never silently point the correction at the wrong answer.
"""
import io
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))

CORRECTIONS = {
    9604: {
        # the option naming VCA — "Viral Capsid Antigen"
        'match': lambda t: 'VCA' in t or 'Capsid' in t,
        'expect_from': lambda t: 'EBNA' in t or 'Nuclear' in t,
        'fa': ('کلید چاپی «آنتی‌بادی ضد EBNA» را انتخاب کرده است، ولی این انتخاب دقیقاً '
               '**عکسِ** معنای این نشانگر است.\n\n'
               '**EBNA آنتی‌ژنی است که ویروس فقط هنگام ورود به فاز نهفتگی می‌سازد** — یعنی '
               'وقتی بیماری حاد تمام شده است. به همین دلیل، آنتی‌بادی ضد EBNA حدود '
               '**۶ تا ۱۲ هفته پس از شروع علائم** ظاهر می‌شود و سپس مادام‌العمر می‌ماند.\n\n'
               '⚠️ **پس نتیجه برعکس چیزی است که کلید ادعا می‌کند: کتاب مرجع Red Book '
               'می‌گوید «حضور آنتی‌بادی EBNA در مراحل اولیه‌ی بیماری، عفونت حاد EBV را '
               'عملاً رد می‌کند».** آزمایشگاه‌های بریتانیا هم دقیقاً به همین دلیل از EBNA '
               'به‌عنوان تست غربالگری استفاده می‌کنند: «نتیجه‌ی مثبت یعنی عفونت گذشته، و '
               'عفونت اولیه در ۶ هفته‌ی اخیر را رد می‌کند».\n\n'
               'یعنی در بیماری که **امروز** حاد بیمار است، EBNA نه‌تنها تست خوبی نیست، بلکه '
               'مثبت شدنش **علیه** تشخیصی است که سؤال از ما می‌خواهد اثباتش کنیم.\n\n'
               '**نشانگر درست، IgM ضد VCA است.** چون دوره‌ی کمون EBV طولانی است '
               '(۴ تا ۸ هفته)، **در زمان شروع علائم آنتی‌بادی از قبل بالا آمده** و در '
               'مراجعه مثبت است؛ و ظرف حدود ۳ ماه محو می‌شود، پس نشانگر قابل اتکای عفونت '
               'حاد است.\n\n'
               '**و چرا تست هتروفیل نه؟** تست هتروفیل (مونواسپات) در عمل **اولین تستی است '
               'که درخواست می‌شود** و انتخاب معقولی است — ولی سؤال «مفیدترین تست جهت '
               '**اثبات** تشخیص» را می‌خواهد، و هتروفیل نمی‌تواند اثبات کند: آنتی‌بادی '
               'ضد یک آنتی‌ژن گلبول قرمز حیوانیِ **بی‌ربط** است و اصلاً اختصاصی ویروس '
               'نیست، در حدود **۲۵ درصد بزرگسالان در هفته‌ی اول کاذباً منفی** است، و در '
               'کودکان زیر ۴ سال اغلب منفی است. میان یک آگلوتیناسیون غیراختصاصی و یک '
               'IgM اختصاصیِ ویروس، آنچه تشخیص را **اثبات** می‌کند IgM است.'),
        'en': ('The printed key chooses the anti-EBNA antibody, but that is precisely the '
               'INVERSE of what the marker means.\n\n'
               'EBNA is the antigen the virus expresses only as it BEGINS TO ESTABLISH '
               'LATENCY — that is, once the acute illness is over. Antibody to EBNA therefore '
               'appears 6 TO 12 WEEKS AFTER THE ONSET OF SYMPTOMS and then persists for life.\n\n'
               'WARNING: so the consequence is the opposite of what the key claims. The AAP '
               'Red Book states that IgG antibodies to EBNA "appear 6-12 weeks after the onset '
               'of symptoms and persist throughout life; THEIR PRESENCE EARLY IN THE COURSE OF '
               'ILLNESS EFFECTIVELY EXCLUDES ACUTE EBV INFECTION." UK laboratories use EBNA as '
               'a screening test for exactly that reason: a positive result indicates PAST '
               'infection and excludes primary infection within the preceding 6 weeks.\n\n'
               'In a patient who is acutely ill TODAY, an EBNA antibody is therefore not merely '
               'a poor test: a positive result would ARGUE AGAINST the very diagnosis the '
               'question asks us to establish.\n\n'
               'THE CORRECT MARKER IS IgM ANTI-VCA. Because EBV has a long incubation period '
               '(4 to 8 weeks), the antibody is ALREADY PRESENT when symptoms begin, so it is '
               'positive at presentation; and it wanes over about 3 months, making it a '
               'reliable marker of acute infection.\n\n'
               'AND WHY NOT THE HETEROPHILE TEST? In practice the heterophile (Monospot) test '
               'is the FIRST test ordered and is a reasonable choice — but the stem asks for '
               'the most useful test TO ESTABLISH the diagnosis, and the heterophile test '
               'cannot establish it: it is an antibody to an UNRELATED animal red-cell antigen '
               'and is not specific for the virus at all, it is falsely negative in about 25% '
               'of adults in the first week, and it is negative in a large share of children '
               'under 4. Between a non-specific agglutination and a virus-specific IgM, the one '
               'that PROVES the diagnosis is the IgM.'),
        'refs': ['American Academy of Pediatrics — Red Book: Report of the Committee on '
                 'Infectious Diseases, Epstein-Barr virus infections (infectious mononucleosis): '
                 'antibodies to EBNA appear 6-12 weeks after onset and their presence early in '
                 'the illness effectively excludes acute EBV infection',
                 'CDC — Epstein-Barr Virus and Infectious Mononucleosis: laboratory testing and '
                 'interpretation of the EBV antibody panel',
                 "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 194: "
                 'Epstein-Barr Virus Infections, Including Infectious Mononucleosis'],
    },
}


def main():
    done = []
    for i in range(1, 6):
        p = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        if not os.path.exists(p):
            continue
        body = json.load(io.open(p, encoding='utf-8'))
        dirty = False
        for q in body['questions']:
            spec = CORRECTIONS.get(q['question_no'])
            if not spec:
                continue

            target = [j for j, t in enumerate(q['options_fa']) if spec['match'](t)]
            assert len(target) == 1, (
                f"q{q['question_no']}: the VCA option must match exactly once, "
                f"matched {len(target)}")
            to = target[0]

            # already applied is not a failure
            if q['correct_index'] == to and q.get('key_corrected'):
                done.append(f"q{q['question_no']}: already corrected")
                continue

            # the printed key must be the option we believe is wrong, matched by
            # TEXT rather than by index, so a reordered payload cannot silently
            # redirect the correction at some other answer
            assert spec['expect_from'](q['options_fa'][q['correct_index']]), (
                f"q{q['question_no']}: expected the printed key to be the EBNA option, "
                f"found {q['options_fa'][q['correct_index']][:50]!r}")

            q['original_correct_index'] = q['correct_index']
            q['correct_index'] = to
            q['key_corrected'] = True
            q['key_correction_fa'] = spec['fa']
            q['key_correction_en'] = spec['en']
            q['key_correction_source'] = '; '.join(spec['refs'])
            done.append(f"q{q['question_no']}: {q['original_correct_index'] + 1} -> {to + 1}  "
                        f"({q['options_fa'][to][:46]})")
            dirty = True
        if dirty:
            json.dump(body, io.open(p, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)

    for d in done:
        print('  ', d)
    assert done, 'no question matched; the correction did nothing'
    print(f'corrections applied: {len(done)}')


if __name__ == '__main__':
    main()
