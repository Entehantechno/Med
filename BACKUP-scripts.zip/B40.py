# -*- coding: utf-8 -*-
"""Micro-lessons, batch 40 — the last ten questions of the viral and STI chapter.

Vaginitis, dysuria in a sexually active woman, trichomonas resistance, HPV
vaccination, and the two remaining urethritis items. With this batch the
largest chapter in the book is COMPLETE: 160 of 160 questions taught.

THE VAGINITIS TRIAD, WHICH IS WORTH LEARNING ONCE PROPERLY
-----------------------------------------------------------
Three organisms, separated by pH, smell and microscopy:

    BACTERIAL VAGINOSIS   pH ABOVE 4.5, fishy on KOH, CLUE CELLS, thin grey
    TRICHOMONAS           pH ABOVE 4.5, frothy green, MOTILE organisms,
                          strawberry cervix
    CANDIDA               pH NORMAL (4 to 4.5), no smell, HYPHAE, thick curd

The pH is what most students never learn, and it is the fastest discriminator
in the whole block: candida is the ONLY one of the three that leaves the pH
normal, because lactobacilli survive.

A GUIDELINE THAT MOVED, HANDLED THE USUAL HONEST WAY
-----------------------------------------------------
q9562 keys the three-dose HPV schedule. Since 2016 the CDC has recommended a
TWO-DOSE schedule for those starting before their 15th birthday, keeping three
doses for those starting at 15 or older and for the immunocompromised. This
patient is 20, so THREE DOSES IS CORRECT FOR HIM and the key stands on today's
guidance as well. The lesson states both schedules so a student is not caught
out by either.

Reference: Workowski KA et al., CDC STI Treatment Guidelines 2021 (MMWR
70(4)); CDC/ACIP — Human Papillomavirus Vaccination: Updated Recommendations
(MMWR 2016;65:1405 and subsequent); Harrison's Principles of Internal
Medicine, 21st ed (2022).
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = "Harrison's Principles of Internal Medicine, 21st ed (2022) — the sexually transmitted infection chapters"
CDC2021 = ("Workowski KA et al. — Sexually Transmitted Infections Treatment Guidelines, 2021. "
           "MMWR Recomm Rep 2021;70(4):1-187 (Centers for Disease Control and Prevention)")
ACIPHPV = ("CDC/ACIP — Human Papillomavirus Vaccination: Updated Recommendations of the Advisory "
           "Committee on Immunization Practices (MMWR 2016;65:1405 and subsequent updates)")

# ===================================================== VAGINITIS
VAG_FA = [
    "⚠️ **سه‌گانه‌ی واژینیت را یک بار درست یاد بگیرید: pH، بو، و میکروسکوپ.**",
    "**واژینوز باکتریال: ترشح خاکستری و رقیق، pH بالای ۴/۵، بوی ماهی با KOH، کلوسل.**",
    "**تریکوموناس: ترشح سبز و کف‌آلود، pH بالای ۴/۵، ارگانیسم متحرک، سرویکس توت‌فرنگی.**",
    "**کاندیدا: ترشح سفید و پنیری و غلیظ، pH طبیعی، بدون بو، هایفی در KOH.**",
    "⚠️ **و pH سریع‌ترین افتراق‌دهنده است، ولی بیشتر دانشجویان آن را یاد نمی‌گیرند.**",
    "**کاندیدا تنها موردی از این سه است که pH را طبیعی می‌گذارد.**",
    "**چرا؟ چون لاکتوباسیل‌ها زنده می‌مانند و اسیدیته‌ی طبیعی واژن را حفظ می‌کنند.**",
    "**ولی در واژینوز باکتریال، لاکتوباسیل‌ها جای خود را به باکتری‌های بی‌هوازی می‌دهند.**",
    "**و آن باکتری‌ها آمین‌های فرار می‌سازند که هم pH را بالا می‌برند و هم بوی ماهی می‌دهند.**",
    "⚠️ **تست ویف (Whiff) همین را نشان می‌دهد: KOH آمین‌ها را آزاد می‌کند و بو بلند می‌شود.**",
    "**کلوسل هم سلول اپیتلیال پوشیده از باکتری است، با حاشیه‌ی محو و دانه‌دانه.**",
    "**و معیار امسل برای واژینوز: سه مورد از چهار — ترشح، pH بالا، ویف مثبت، کلوسل.**",
]
VAG_EN = [
    "WARNING: LEARN THE VAGINITIS TRIAD PROPERLY ONCE — pH, smell and microscopy.",
    "BACTERIAL VAGINOSIS: thin grey discharge, pH ABOVE 4.5, fishy odour with KOH, CLUE CELLS.",
    "TRICHOMONAS: frothy green discharge, pH ABOVE 4.5, MOTILE organisms, strawberry cervix.",
    "CANDIDA: thick white curd-like discharge, NORMAL pH, no odour, HYPHAE on KOH.",
    "WARNING, AND THE pH IS THE FASTEST DISCRIMINATOR, yet most students never learn it.",
    "Candida is the ONLY one of the three that leaves the pH normal.",
    "Why? Because the lactobacilli survive and maintain the vagina's normal acidity.",
    "But in bacterial vaginosis the lactobacilli are replaced by anaerobes.",
    "And those anaerobes make volatile amines, which both raise the pH and give the fishy smell.",
    "WARNING, THE WHIFF TEST SHOWS EXACTLY THAT: KOH liberates the amines and the odour rises.",
    "A clue cell is an epithelial cell coated with bacteria, with a blurred granular border.",
    "And the Amsel criteria for vaginosis: three of four — discharge, high pH, positive whiff, clue cells.",
]

# ===================================================== URETHRITIS / DYSURIA
URETH_FA = [
    "⚠️ **اورتریت را به دو دسته تقسیم کنید: گونوکوکی و غیرگونوکوکی. و هر دو را با هم درمان کنید.**",
    "**گونوکوک: دوره‌ی کمون کوتاه (۲ تا ۷ روز)، ترشح فراوان و آشکارا چرکی.**",
    "**غیرگونوکوکی (عمدتاً کلامیدیا): کمون طولانی‌تر (۷ تا ۲۱ روز)، ترشح کم و مخاطی.**",
    "⚠️ **و مهم‌ترین نکته‌ی آزمایشگاهی: رنگ‌آمیزی گرم فقط گونوکوک را می‌بیند.**",
    "**دیپلوکوک گرم منفی داخل سلولی یعنی گونوکوک — و این یافته تشخیصی است.**",
    "**ولی کلامیدیا دیواره‌ی سلولی معمولی ندارد و داخل سلول زندگی می‌کند، پس در گرم دیده نمی‌شود.**",
    "⚠️ **نتیجه‌ی عملی: گرم منفی، کلامیدیا را رد نمی‌کند — فقط می‌گوید گونوکوک نیست.**",
    "**و چون هم‌زمانی این دو تا یک‌سوم موارد است، درمان همیشه هر دو را پوشش می‌دهد.**",
    "**رژیم آن دوره: سفتریاکسون یا سفکسیم برای گونوکوک، به‌علاوه‌ی آزیترومایسین یا داکسی‌سیکلین برای کلامیدیا.**",
    "⚠️ **و به‌روزرسانی CDC 2021: سفتریاکسون ۵۰۰ میلی‌گرم تک‌دوز، و داکسی‌سیکلین به‌جای آزیترومایسین.**",
    "**دلیل حذف آزیترومایسین: نگرانی از مقاومت فزاینده و برتری داکسی‌سیکلین در کلامیدیای رکتال.**",
    "**و در زن جوان فعال جنسی با سوزش ادرار و کشت منفی، همیشه به سندرم اورترال حاد فکر کنید.**",
    "⚠️ **پیوری با کشت منفی، یعنی عاملی که در محیط کشت معمولی رشد نمی‌کند — یعنی کلامیدیا.**",
]
URETH_EN = [
    "WARNING: SPLIT URETHRITIS INTO GONOCOCCAL AND NON-GONOCOCCAL — and treat for both.",
    "GONOCOCCAL: short incubation (2 to 7 days), profuse and frankly purulent discharge.",
    "NON-GONOCOCCAL (mostly chlamydia): longer incubation (7 to 21 days), scant mucoid discharge.",
    "WARNING, AND THE KEY LABORATORY POINT: THE GRAM STAIN SEES ONLY THE GONOCOCCUS.",
    "Intracellular Gram-negative diplococci mean gonorrhoea, and that finding is diagnostic.",
    "But chlamydia has no ordinary cell wall and lives inside cells, so it is invisible on Gram stain.",
    "WARNING, THE PRACTICAL CONSEQUENCE: a negative Gram does NOT exclude chlamydia; it only excludes gonorrhoea.",
    "And because the two coincide in up to a third of cases, treatment always covers both.",
    "The regimen of that era: ceftriaxone or cefixime for gonorrhoea plus azithromycin or doxycycline for chlamydia.",
    "WARNING, THE CDC 2021 UPDATE: ceftriaxone 500 mg as a single dose, and doxycycline in place of azithromycin.",
    "Why azithromycin was dropped: rising resistance and doxycycline's superiority in rectal chlamydia.",
    "And in a sexually active young woman with dysuria and a negative culture, always think of ACUTE URETHRAL SYNDROME.",
    "WARNING, PYURIA WITH A NEGATIVE CULTURE means an organism that does not grow on ordinary media — that is chlamydia.",
]


# =========================================================== book:535
add("book:535", "recall", "medium",
 "**pH طبیعی (زیر ۴/۵) به ضرر واژینوز باکتریال است** — تنها معیاری که آن را رد می‌کند.",
 "A NORMAL pH (4.5 or below) ARGUES AGAINST bacterial vaginosis — the only criterion here that excludes it.",
 VAG_FA + [
  "**این سؤال ساختار «به ضرر تشخیص» دارد، یعنی دنبال یافته‌ای می‌گردد که تشخیص را رد کند.**",
  "⚠️ **و سه گزینه‌ی دیگر همگی معیارهای امسل برای واژینوز باکتریال‌اند.**",
  "**ترشح سفید و رقیق: معیار اول امسل.**",
  "**کلوسل در ترشحات: معیار دوم و اختصاصی‌ترین آن‌ها.**",
  "**بوی ماهی با KOH یعنی تست ویف مثبت: معیار سوم.**",
  "⚠️ **و معیار چهارم pH بالای ۴/۵ است — پس pH طبیعی خلاف آن است.**",
  "**در واژینوز، لاکتوباسیل‌ها از بین می‌روند و اسیدیته‌ی محافظ واژن را از دست می‌دهیم.**",
  "**پس pH بالا می‌رود؛ اگر pH طبیعی مانده باشد، لاکتوباسیل‌ها هنوز آنجایند.**",
 ],
 VAG_EN + [
  "This stem uses an 'argues against' structure: it seeks the finding that EXCLUDES the diagnosis.",
  "WARNING, AND THE OTHER THREE OPTIONS ARE ALL AMSEL CRITERIA for bacterial vaginosis.",
  "A thin white discharge: the first Amsel criterion.",
  "Clue cells in the discharge: the second, and the most specific of them.",
  "A fishy odour with KOH is a positive whiff test: the third criterion.",
  "WARNING, AND THE FOURTH CRITERION IS A pH ABOVE 4.5 — so a normal pH is against it.",
  "In vaginosis the lactobacilli are lost and the vagina's protective acidity goes with them.",
  "So the pH rises; if the pH is still normal, the lactobacilli are still there.",
 ],
 "**خانم ۲۱ ساله** با سوزش، تکرر ادرار و **ترشحات واژینال سفید**. سؤال می‌پرسد کدام "
 "مورد **به ضرر تشخیص واژینوز باکتریال** است — یعنی کدام یافته آن را **رد** می‌کند.\n\n"
 "⚠️ **پاسخ: pH واژینال کمتر یا مساوی ۴/۵.**\n\n"
 "**برای حل این سؤال، معیارهای امسل را بدانید — چهار معیار که سه‌تا از آن‌ها تشخیص "
 "را می‌گذارد:**\n\n"
 "**۱) ترشح رقیق، همگن، خاکستری یا سفید** ✅ در متن هست.\n\n"
 "**۲) pH واژینال بالای ۴/۵** ⚠️ **و اینجاست که گزینه‌ی درست ساخته شده.**\n\n"
 "**۳) تست ویف مثبت** (بوی ماهی پس از افزودن KOH) ✅ در گزینه‌ها هست.\n\n"
 "**۴) کلوسل در میکروسکوپ** ✅ در گزینه‌ها هست.\n\n"
 "**پس سه گزینه‌ی دیگر همگی به نفع تشخیص‌اند، و فقط pH طبیعی خلاف آن است.**\n\n"
 "⚠️ **و حالا چرا pH این‌قدر تعیین‌کننده است؟ سازوکارش زیباست:**\n\n"
 "**واژن سالم پر از لاکتوباسیل است.** این باکتری‌ها **اسید لاکتیک** می‌سازند و pH را "
 "در محدوده‌ی **۳/۸ تا ۴/۵** نگه می‌دارند. **این اسیدیته خودش یک سد دفاعی است** و از "
 "رشد باکتری‌های بیماری‌زا جلوگیری می‌کند.\n\n"
 "**در واژینوز باکتریال چه اتفاقی می‌افتد؟** ⚠️ **لاکتوباسیل‌ها جای خود را به "
 "باکتری‌های بی‌هوازی می‌دهند** (گاردنرلا، موبیلونکوس، پرووتلا). **بدون لاکتوباسیل، "
 "اسید لاکتیک ساخته نمی‌شود و pH بالا می‌رود.**\n\n"
 "**و همان باکتری‌های بی‌هوازی، آمین‌های فرار می‌سازند** (پوترسین، کاداورین) — که "
 "**هم pH را بالاتر می‌برند و هم بوی ماهی می‌دهند**. ⚠️ **تست ویف دقیقاً همین را "
 "نشان می‌دهد: KOH قلیایی، آمین‌ها را آزاد می‌کند و بو بلند می‌شود.**\n\n"
 "**پس اگر pH طبیعی باشد، یعنی لاکتوباسیل‌ها هنوز سر جایشان هستند — و واژینوز "
 "باکتریال رخ نداده است.**\n\n"
 "⚠️ **و این یک نکته‌ی افتراقی طلایی است: کاندیدا تنها عامل واژینیت است که pH را "
 "طبیعی می‌گذارد.** پس اگر pH طبیعی بود و ترشح سفید و غلیظ، به **کاندیدا** فکر کنید، "
 "نه واژینوز.",
 "A 21-YEAR-OLD WOMAN with burning, frequency and a WHITE VAGINAL DISCHARGE. The stem asks which "
 "finding ARGUES AGAINST bacterial vaginosis — that is, which one EXCLUDES it.\n\n"
 "WARNING, THE ANSWER: a vaginal pH of 4.5 or below.\n\n"
 "To solve this, know the AMSEL CRITERIA — four criteria, three of which make the diagnosis:\n\n"
 "1) A THIN, HOMOGENEOUS, GREY OR WHITE DISCHARGE — present in the stem.\n\n"
 "2) A VAGINAL pH ABOVE 4.5 — WARNING, AND THIS IS WHERE THE RIGHT OPTION IS BUILT.\n\n"
 "3) A POSITIVE WHIFF TEST (fishy odour after adding KOH) — present among the options.\n\n"
 "4) CLUE CELLS ON MICROSCOPY — present among the options.\n\n"
 "SO THE OTHER THREE ALL SUPPORT THE DIAGNOSIS, and only a normal pH is against it.\n\n"
 "WARNING, AND WHY IS THE pH SO DECISIVE? The mechanism is elegant:\n\n"
 "A HEALTHY VAGINA IS FULL OF LACTOBACILLI. They make LACTIC ACID and hold the pH between 3.8 AND "
 "4.5. THAT ACIDITY IS ITSELF A DEFENSIVE BARRIER preventing the growth of pathogens.\n\n"
 "WHAT HAPPENS IN BACTERIAL VAGINOSIS? WARNING, THE LACTOBACILLI ARE REPLACED BY ANAEROBES "
 "(Gardnerella, Mobiluncus, Prevotella). WITHOUT LACTOBACILLI NO LACTIC ACID IS MADE AND THE pH "
 "RISES.\n\n"
 "AND THOSE SAME ANAEROBES MAKE VOLATILE AMINES (putrescine, cadaverine) — which BOTH RAISE THE pH "
 "FURTHER AND GIVE THE FISHY SMELL. WARNING, THE WHIFF TEST SHOWS EXACTLY THAT: alkaline KOH "
 "liberates the amines and the odour rises.\n\n"
 "SO IF THE pH IS NORMAL, THE LACTOBACILLI ARE STILL IN PLACE — AND BACTERIAL VAGINOSIS HAS NOT "
 "OCCURRED.\n\n"
 "WARNING, AND THIS IS A GOLDEN DISCRIMINATOR: CANDIDA IS THE ONLY CAUSE OF VAGINITIS THAT LEAVES "
 "THE pH NORMAL. So with a normal pH and a thick white discharge, think CANDIDA, not vaginosis.",
 ["ترشح سفید و رقیق یکی از معیارهای امسل است و به نفع تشخیص واژینوز باکتریال است.",
  "کلوسل اختصاصی‌ترین معیار امسل است و تشخیص را تأیید می‌کند، نه رد.",
  "بوی ماهی با KOH یعنی تست ویف مثبت، که سومین معیار امسل است.",
  "پاسخ صحیح — pH طبیعی یعنی لاکتوباسیل‌ها هنوز هستند، و این واژینوز باکتریال را رد می‌کند."],
 ["A thin white discharge is an Amsel criterion and supports bacterial vaginosis.",
  "Clue cells are the most specific Amsel criterion and confirm rather than exclude the diagnosis.",
  "A fishy odour with KOH is a positive whiff test, the third Amsel criterion.",
  "Correct — a normal pH means the lactobacilli are still present, which excludes bacterial vaginosis."],
 "**کاندیدا تنها واژینیتی است که pH را طبیعی می‌گذارد.**",
 "Candida is the only vaginitis that leaves the pH normal.",
 [CDC2021, H])


# =========================================================== book:536
add("book:536", "case", "medium",
 "سوزش ادرار + پیوری + **کشت منفی** در زن جوان فعال جنسی ← **کلامیدیا** (سندرم اورترال حاد).",
 "Dysuria with pyuria and a NEGATIVE CULTURE in a sexually active young woman: CHLAMYDIA (acute urethral syndrome).",
 URETH_FA + [
  "**این سؤال یک الگوی کلاسیک را می‌آزماید که نامش سندرم اورترال حاد است.**",
  "⚠️ **پیوری با کشت ادرار منفی، یعنی عاملی که در محیط کشت معمولی رشد نمی‌کند.**",
  "**و شایع‌ترین چنین عاملی در زن جوان فعال جنسی، کلامیدیا تراکوماتیس است.**",
  "**چون کلامیدیا یک باکتری داخل سلولی اجباری است و روی آگار معمولی رشد نمی‌کند.**",
  "**پس کشت ادرار روتین آن را نمی‌بیند و تشخیص با NAAT انجام می‌شود.**",
  "⚠️ **و شکست کوتریموکسازول یک سرنخ تأییدی است، نه یک جزئیات بی‌اهمیت.**",
  "**کوتریموکسازول ای‌کولای و بیشتر اورگانیسم‌های ادراری را پوشش می‌دهد ولی کلامیدیا را نه.**",
  "**نبود درد سوپراپوبیک هم به نفع اورتریت است تا سیستیت.**",
 ],
 URETH_EN + [
  "This question tests a classic pattern called ACUTE URETHRAL SYNDROME.",
  "WARNING: PYURIA WITH A NEGATIVE URINE CULTURE means an organism that does not grow on ordinary media.",
  "And the commonest such organism in a sexually active young woman is CHLAMYDIA TRACHOMATIS.",
  "Because chlamydia is an obligate intracellular bacterium and does not grow on ordinary agar.",
  "So routine urine culture misses it, and diagnosis is made by NAAT.",
  "WARNING, AND THE FAILURE OF CO-TRIMOXAZOLE IS A CONFIRMATORY CLUE, not an incidental detail.",
  "Co-trimoxazole covers E. coli and most urinary organisms but not chlamydia.",
  "The absence of suprapubic pain also favours urethritis over cystitis.",
 ],
 "**خانم ۲۰ ساله با رفتارهای جنسی پرخطر**، سوزش ادرار چند روزه، **بدون درد "
 "سوپراپوبیک**، که **با کوتریموکسازول بهتر نشده**. آزمایش ادرار: **لکوسیت ۱۰ تا ۱۲**. "
 "کشت ادرار: **کوکسی گرم مثبت کمتر از ۱۰ عدد** (یعنی عملاً منفی و آلودگی).\n\n"
 "⚠️ **پاسخ: کلامیدیا تراکوماتیس. و این الگو نام دارد: سندرم اورترال حاد.**\n\n"
 "**سه سرنخ این سؤال را می‌سازند، و هر سه عمداً آمده‌اند:**\n\n"
 "**سرنخ یک — پیوری با کشت منفی.** ⚠️ **این مهم‌ترین یافته است.**\n\n"
 "**لکوسیت در ادرار هست (یعنی التهاب واقعی وجود دارد)، ولی کشت چیزی رشد نداده.** "
 "این ترکیب معنای مشخصی دارد: **عاملی وجود دارد که در محیط کشت ادرار معمولی رشد "
 "نمی‌کند**.\n\n"
 "**و چرا کلامیدیا رشد نمی‌کند؟** چون **یک باکتری داخل سلولی اجباری است** — یعنی "
 "**فقط داخل سلول زنده می‌ماند و روی آگار بی‌جان رشد نمی‌کند**. **پس کشت ادرار روتین "
 "آن را هرگز نمی‌بیند.** تشخیص با **NAAT** (تست تکثیر اسید نوکلئیک) انجام می‌شود.\n\n"
 "**سرنخ دو — شکست کوتریموکسازول.** ⚠️ **این یک جزئیات بی‌اهمیت نیست؛ یک سرنخ "
 "تأییدی است.** کوتریموکسازول **ای‌کولای و بیشتر اورگانیسم‌های ادراری را پوشش "
 "می‌دهد** — پس اگر سیستیت باکتریال معمولی بود، باید بهتر می‌شد. **ولی کلامیدیا را "
 "پوشش نمی‌دهد.**\n\n"
 "**سرنخ سه — نبود درد سوپراپوبیک.** درد سوپراپوبیک نشانه‌ی **سیستیت** است. نبودش "
 "به نفع **اورتریت** است — یعنی التهاب در مجرا، نه در مثانه.\n\n"
 "**و رفتار جنسی پرخطر، احتمال پیش‌آزمون را کامل می‌کند.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**استافیلوکوک اپیدرمیدیس** — ⚠️ **این همان «کوکسی گرم مثبت کمتر از ۱۰ عدد» در کشت "
 "است.** ولی این تعداد **زیر آستانه‌ی معنادار** است و **آلودگی پوستی** محسوب می‌شود، "
 "نه عامل بیماری. **استاف اپیدرمیدیس فلور طبیعی پوست است.**\n\n"
 "**استافیلوکوک ساپروفیتیکوس** — ⚠️ **گزینه‌ی وسوسه‌انگیز**، چون **واقعاً عامل سیستیت "
 "در زن جوان فعال جنسی است** (دومین عامل شایع پس از ای‌کولای). ولی دو اشکال: "
 "**۱)** در **کشت ادرار رشد می‌کند** — اینجا کشت منفی است. **۲)** معمولاً به "
 "کوتریموکسازول **پاسخ می‌دهد**.\n\n"
 "**تریکوموناس واژینالیس** — می‌تواند سوزش ادرار بدهد، ولی تابلوی غالبش **ترشح "
 "واژینال کف‌آلود سبز** و **خارش** است، که در متن **ذکر نشده**.",
 "A 20-YEAR-OLD WOMAN WITH HIGH-RISK SEXUAL BEHAVIOUR, several days of dysuria, WITHOUT SUPRAPUBIC "
 "PAIN, who HAS NOT IMPROVED ON CO-TRIMOXAZOLE. Urinalysis: 10 to 12 WHITE CELLS. Urine culture: "
 "FEWER THAN 10 GRAM-POSITIVE COCCI (effectively negative, a contaminant).\n\n"
 "WARNING, THE ANSWER: CHLAMYDIA TRACHOMATIS. And this pattern has a name: ACUTE URETHRAL SYNDROME.\n\n"
 "THREE CLUES BUILD THIS QUESTION, and all three are deliberate:\n\n"
 "CLUE ONE — PYURIA WITH A NEGATIVE CULTURE. WARNING, THE MOST IMPORTANT FINDING.\n\n"
 "THERE ARE WHITE CELLS IN THE URINE (so real inflammation exists), BUT THE CULTURE GREW NOTHING. "
 "That combination has a specific meaning: AN ORGANISM IS PRESENT THAT DOES NOT GROW ON ORDINARY "
 "URINE CULTURE MEDIA.\n\n"
 "AND WHY DOES CHLAMYDIA NOT GROW? Because it is an OBLIGATE INTRACELLULAR BACTERIUM — it survives "
 "ONLY INSIDE CELLS and does not grow on lifeless agar. SO ROUTINE URINE CULTURE NEVER SEES IT. "
 "Diagnosis is by NAAT (nucleic acid amplification testing).\n\n"
 "CLUE TWO — FAILURE OF CO-TRIMOXAZOLE. WARNING, NOT AN INCIDENTAL DETAIL BUT A CONFIRMATORY CLUE. "
 "Co-trimoxazole COVERS E. COLI AND MOST URINARY ORGANISMS — so ordinary bacterial cystitis should "
 "have improved. BUT IT DOES NOT COVER CHLAMYDIA.\n\n"
 "CLUE THREE — NO SUPRAPUBIC PAIN. Suprapubic pain indicates CYSTITIS. Its absence favours "
 "URETHRITIS — inflammation in the urethra rather than the bladder.\n\n"
 "And the high-risk sexual behaviour completes the pre-test probability.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "STAPHYLOCOCCUS EPIDERMIDIS — WARNING, THIS IS THE 'FEWER THAN 10 GRAM-POSITIVE COCCI' IN THE "
 "CULTURE. But that count is BELOW THE SIGNIFICANT THRESHOLD and represents SKIN CONTAMINATION, not "
 "a pathogen. S. EPIDERMIDIS IS NORMAL SKIN FLORA.\n\n"
 "STAPHYLOCOCCUS SAPROPHYTICUS — WARNING, a tempting option, because it IS genuinely a cause of "
 "cystitis in sexually active young women (the second commonest after E. coli). But two flaws: 1) "
 "IT GROWS IN URINE CULTURE — and here the culture is negative. 2) It usually RESPONDS to "
 "co-trimoxazole.\n\n"
 "TRICHOMONAS VAGINALIS — can cause dysuria, but its dominant picture is a FROTHY GREEN VAGINAL "
 "DISCHARGE with ITCHING, NOT MENTIONED in the stem.",
 ["پاسخ صحیح — پیوری با کشت منفی و شکست کوتریموکسازول، تابلوی سندرم اورترال حاد ناشی از کلامیدیاست.",
  "کوکسی گرم مثبت کمتر از ۱۰ عدد زیر آستانه‌ی معنادار است و آلودگی پوستی محسوب می‌شود.",
  "گزینه‌ی وسوسه‌انگیز — ولی ساپروفیتیکوس در کشت رشد می‌کند و به کوتریموکسازول پاسخ می‌دهد.",
  "تریکوموناس می‌تواند سوزش بدهد ولی تابلوی غالبش ترشح کف‌آلود سبز است که در متن نیست."],
 ["Correct — pyuria with a negative culture and co-trimoxazole failure is acute urethral syndrome from chlamydia.",
  "Fewer than 10 Gram-positive cocci is below the significant threshold and represents skin contamination.",
  "A tempting option — but S. saprophyticus grows in culture and responds to co-trimoxazole.",
  "Trichomonas can cause dysuria but its dominant picture is a frothy green discharge, absent here."],
 "**پیوری با کشت منفی = عاملی که روی آگار رشد نمی‌کند = کلامیدیا.**",
 "Pyuria with a negative culture means an organism that will not grow on agar — chlamydia.",
 [CDC2021, H])


# =========================================================== book:538
add("book:538", "case", "easy",
 "سیستیت ساده در زن جوان ← **سونوگرافی لازم نیست**؛ تصویربرداری برای عفونت پیچیده است.",
 "Simple cystitis in a young woman needs NO ULTRASOUND; imaging is for complicated infection.",
 URETH_FA + [
  "**این سؤال می‌پرسد کدام اقدام در مرحله‌ی اول توصیه نمی‌شود.**",
  "⚠️ **و اصل حاکم: در سیستیت ساده‌ی بدون عارضه، تصویربرداری اندیکاسیون ندارد.**",
  "**تصویربرداری برای عفونت پیچیده است: تب، درد پهلو، سنگ، انسداد، یا شکست درمان.**",
  "**این بیمار تب ندارد، سابقه‌ی بیماری خاصی ندارد و علائمش فقط دو روزه است.**",
  "**پس سونوگرافی نه چیزی را عوض می‌کند و نه چیزی را پیدا می‌کند.**",
  "⚠️ **و سه گزینه‌ی دیگر همگی در ارزیابی اولیه جای دارند، به‌ویژه در این بیمار.**",
  "**آنالیز ادرار پیوری را نشان می‌دهد و التهاب را تأیید می‌کند.**",
  "**کشت ادرار عامل و حساسیت آنتی‌بیوتیکی را می‌دهد.**",
  "**و معاینه‌ی لگنی در فرد با رفتار جنسی پرخطر ضروری است، چون STI را رد می‌کند.**",
 ],
 URETH_EN + [
  "The stem asks which action is NOT recommended at the first stage.",
  "WARNING, THE GOVERNING PRINCIPLE: in simple uncomplicated cystitis, imaging is not indicated.",
  "Imaging is for COMPLICATED infection: fever, flank pain, stones, obstruction, or treatment failure.",
  "This patient has no fever, no significant history, and only two days of symptoms.",
  "So an ultrasound would change nothing and find nothing.",
  "WARNING, AND THE OTHER THREE ALL BELONG IN THE INITIAL ASSESSMENT, especially in this patient.",
  "Urinalysis shows the pyuria and confirms inflammation.",
  "Urine culture gives the organism and its antibiotic sensitivities.",
  "And a pelvic examination is essential in someone with high-risk sexual behaviour, because it excludes STI.",
 ],
 "**خانم ۳۰ ساله، sex worker**، با **سوزش، تکرر و فوریت ادرار از ۲ روز پیش**، "
 "**بدون تب** و **بدون سابقه‌ی بیماری خاص**. سؤال: کدام اقدام تشخیصی **در اولین مرحله "
 "توصیه نمی‌شود**؟\n\n"
 "⚠️ **پاسخ: سونوگرافی سیستم ادراری.**\n\n"
 "**اصل حاکم را بدانید:**\n\n"
 "> ⚠️ **در سیستیت ساده‌ی بدون عارضه، تصویربرداری اندیکاسیون ندارد.**\n\n"
 "**تصویربرداری کِی لازم است؟ فقط در عفونت «پیچیده»:**\n\n"
 "**تب و لرز** (یعنی درگیری کلیه) · **درد پهلو** · **شک به سنگ یا انسداد** · "
 "**عفونت مکرر** · **شکست درمان** · **مرد** (چون سیستیت ساده در مرد نادر است) · "
 "**بارداری**.\n\n"
 "**این بیمار هیچ‌کدام را ندارد:** **تب ندارد**، **سابقه‌ی بیماری خاص ندارد**، و "
 "علائمش **فقط دو روزه** است. **پس سونوگرافی نه چیزی را عوض می‌کند و نه چیزی پیدا "
 "می‌کند** — فقط هزینه و تأخیر اضافه می‌کند.\n\n"
 "**و چرا سه گزینه‌ی دیگر لازم‌اند؟**\n\n"
 "**آنالیز ادرار** ✅ — **پایه‌ای‌ترین اقدام**. پیوری، هماچوری و نیتریت را نشان "
 "می‌دهد و **التهاب واقعی را تأیید می‌کند**.\n\n"
 "**کشت ادرار** ✅ — **عامل و حساسیت آنتی‌بیوتیکی** را می‌دهد. (نکته: در سیستیت "
 "ساده‌ی معمولی، کشت همیشه لازم نیست؛ ولی در این بیمار با **رفتار پرخطر** و احتمال "
 "**عوامل غیرمعمول**، منطقی است.)\n\n"
 "⚠️ **معاینه‌ی لگنی** ✅ — **و این مهم‌ترین گزینه‌ای است که نباید حذف شود.**\n\n"
 "**چرا؟ چون این بیمار sex worker است.** در او، **سوزش ادرار می‌تواند تظاهر یک "
 "عفونت منتقله از راه جنسی باشد**، نه سیستیت. **معاینه‌ی لگنی:**\n\n"
 "**ترشح سرویکس** (سرویسیت گونوکوکی یا کلامیدیایی) را نشان می‌دهد.\n\n"
 "**زخم تناسلی** (هرپس، سیفلیس، شانکروئید) را پیدا می‌کند.\n\n"
 "**حساسیت حرکت سرویکس** (بیماری التهابی لگن) را می‌سنجد.\n\n"
 "⚠️ **و این نکته‌ی بالینی مهمی است: در زن با رفتار جنسی پرخطر، هرگز سوزش ادرار را "
 "بدون معاینه‌ی لگنی به‌عنوان سیستیت ساده درمان نکنید.** ممکن است یک **بیماری "
 "التهابی لگن** را از دست بدهید، که درمان‌نشده به **ناباروری و بارداری خارج رحمی** "
 "می‌انجامد.",
 "A 30-YEAR-OLD SEX WORKER with BURNING, FREQUENCY AND URGENCY FOR 2 DAYS, WITHOUT FEVER and with "
 "NO SIGNIFICANT MEDICAL HISTORY. Which diagnostic action is NOT recommended at the first stage?\n\n"
 "WARNING, THE ANSWER: URINARY TRACT ULTRASOUND.\n\n"
 "KNOW THE GOVERNING PRINCIPLE:\n\n"
 "> WARNING: IN SIMPLE UNCOMPLICATED CYSTITIS, IMAGING IS NOT INDICATED.\n\n"
 "WHEN IS IMAGING NEEDED? Only in COMPLICATED infection:\n\n"
 "FEVER AND RIGORS (renal involvement) · FLANK PAIN · SUSPECTED STONE OR OBSTRUCTION · RECURRENT "
 "INFECTION · TREATMENT FAILURE · A MALE PATIENT (simple cystitis is rare in men) · PREGNANCY.\n\n"
 "THIS PATIENT HAS NONE OF THEM: NO FEVER, NO SIGNIFICANT HISTORY, and only TWO DAYS of symptoms. "
 "SO AN ULTRASOUND WOULD CHANGE NOTHING AND FIND NOTHING — it adds only cost and delay.\n\n"
 "AND WHY ARE THE OTHER THREE NEEDED?\n\n"
 "URINALYSIS — THE MOST BASIC STEP. It shows pyuria, haematuria and nitrites and CONFIRMS REAL "
 "INFLAMMATION.\n\n"
 "URINE CULTURE — gives THE ORGANISM AND ITS SENSITIVITIES. (Note: in ordinary simple cystitis a "
 "culture is not always needed; but in this patient with HIGH-RISK BEHAVIOUR and the possibility of "
 "UNUSUAL ORGANISMS, it is reasonable.)\n\n"
 "WARNING, PELVIC EXAMINATION — AND THIS IS THE MOST IMPORTANT OPTION NOT TO OMIT.\n\n"
 "WHY? BECAUSE THIS PATIENT IS A SEX WORKER. In her, DYSURIA MAY BE THE PRESENTATION OF A SEXUALLY "
 "TRANSMITTED INFECTION rather than cystitis. A PELVIC EXAMINATION:\n\n"
 "Reveals CERVICAL DISCHARGE (gonococcal or chlamydial cervicitis).\n\n"
 "Finds GENITAL ULCERS (herpes, syphilis, chancroid).\n\n"
 "Assesses CERVICAL MOTION TENDERNESS (pelvic inflammatory disease).\n\n"
 "WARNING, AND THIS IS AN IMPORTANT CLINICAL POINT: IN A WOMAN WITH HIGH-RISK SEXUAL BEHAVIOUR, "
 "NEVER TREAT DYSURIA AS SIMPLE CYSTITIS WITHOUT A PELVIC EXAMINATION. You may miss PELVIC "
 "INFLAMMATORY DISEASE, which untreated leads to INFERTILITY AND ECTOPIC PREGNANCY.",
 ["معاینه‌ی لگنی در فرد با رفتار پرخطر ضروری است، چون سرویسیت و بیماری التهابی لگن را رد می‌کند.",
  "آنالیز ادرار پایه‌ای‌ترین اقدام است و التهاب واقعی را تأیید می‌کند.",
  "کشت ادرار عامل و حساسیت آنتی‌بیوتیکی را می‌دهد و در این بیمار منطقی است.",
  "پاسخ صحیح — در سیستیت ساده‌ی بدون تب و بدون عارضه، تصویربرداری اندیکاسیون ندارد."],
 ["A pelvic examination is essential with high-risk behaviour, because it excludes cervicitis and pelvic inflammatory disease.",
  "Urinalysis is the most basic step and confirms real inflammation.",
  "Urine culture gives the organism and sensitivities and is reasonable in this patient.",
  "Correct — in simple cystitis without fever or complication, imaging is not indicated."],
 "**در زن با رفتار پرخطر، سوزش ادرار را بدون معاینه‌ی لگنی درمان نکنید.**",
 "In a woman with high-risk behaviour, never treat dysuria without a pelvic examination.",
 [CDC2021, H])


# =========================================================== book:539
add("book:539", "case", "medium",
 "علائم پس از سفتریاکسون + داکسی‌سیکلین **کامل** ← عاملی که پوشش داده نشده: **تریکوموناس**.",
 "Symptoms persisting after COMPLETE ceftriaxone plus doxycycline point to what was not covered: TRICHOMONAS.",
 URETH_FA + [
  "**این سؤال منطق «چه چیزی پوشش داده نشد» را می‌آزماید، که مهارت ارزشمندی است.**",
  "**بیمار سفتریاکسون گرفته، پس گونوکوک پوشش داده شده است.**",
  "**و داکسی‌سیکلین ۷ روزه گرفته، پس کلامیدیا هم پوشش داده شده است.**",
  "⚠️ **پس علائم باقی‌مانده باید از عاملی باشد که هیچ‌کدام از این دو نمی‌گیرند.**",
  "**تریکوموناس واژینالیس یک انگل تک‌یاخته است، نه باکتری.**",
  "**پس نه به سفالوسپورین پاسخ می‌دهد و نه به تتراسایکلین — به مترونیدازول نیاز دارد.**",
  "**و مایکوپلاسما ژنیتالیوم هم علت شایع دیگر اورتریت پایدار است.**",
  "⚠️ **و همیشه باید پرسید آیا شریک جنسی درمان شده است، وگرنه چرخه‌ی پینگ‌پنگ ادامه می‌یابد.**",
 ],
 URETH_EN + [
  "This question tests the logic of 'what was not covered', a valuable skill.",
  "The patient received ceftriaxone, so gonorrhoea was covered.",
  "And he received 7 days of doxycycline, so chlamydia was covered too.",
  "WARNING, SO THE PERSISTING SYMPTOMS MUST COME FROM AN ORGANISM NEITHER OF THOSE COVERS.",
  "Trichomonas vaginalis is a protozoan parasite, not a bacterium.",
  "So it responds to neither a cephalosporin nor a tetracycline — it needs metronidazole.",
  "And Mycoplasma genitalium is the other common cause of persistent urethritis.",
  "WARNING, AND ONE MUST ALWAYS ASK WHETHER THE PARTNER WAS TREATED, or the ping-pong cycle continues.",
 ],
 "**آقای ۴۰ ساله** با اورتریت پس از تماس مشکوک، که **سفتریاکسون ۲۵۰ میلی‌گرم عضلانی "
 "تک‌دوز و داکسی‌سیکلین به مدت ۷ روز** گرفته. **دو هفته بعد مجدداً سوزش ادرار و ترشح "
 "دارد.** در معاینه **ضایعه‌ی ژنیتالیا ندارد** و در آزمایش ترشح مجرا **۸ تا ۱۰** "
 "لکوسیت.\n\n"
 "⚠️ **این سؤال منطق «چه چیزی پوشش داده نشد» را می‌آزماید — و این یکی از ارزشمندترین "
 "مهارت‌های بالینی است.**\n\n"
 "**اول ببینیم درمان قبلی چه چیزهایی را پوشش داده است:**\n\n"
 "**سفتریاکسون ۲۵۰ میلی‌گرم عضلانی** → ⚠️ **گونوکوک پوشش داده شد.** این دقیقاً رژیم "
 "استاندارد آن دوره بود.\n\n"
 "**داکسی‌سیکلین ۷ روز** → ⚠️ **کلامیدیا پوشش داده شد.** این هم رژیم کامل و صحیح "
 "است.\n\n"
 "**پس درمان قبلی هم درست بود و هم کامل. و بیمار باز هم علامت دارد.**\n\n"
 "**نتیجه‌ی منطقی: علائم باقی‌مانده باید از عاملی باشد که هیچ‌کدام از این دو دارو "
 "نمی‌گیرند.**\n\n"
 "**و آن عامل کدام است؟**\n\n"
 "⚠️ **تریکوموناس واژینالیس — و دلیلش زیباست: تریکوموناس یک باکتری نیست.**\n\n"
 "**تریکوموناس یک انگل تک‌یاخته‌ی تاژک‌دار است.** پس:\n\n"
 "**سفالوسپورین‌ها** (که دیواره‌ی سلولی باکتری را هدف می‌گیرند) → **بی‌اثر**، چون "
 "انگل دیواره‌ی سلولی باکتریایی ندارد.\n\n"
 "**تتراسایکلین‌ها** (که ریبوزوم باکتری را هدف می‌گیرند) → **بی‌اثر**، چون ریبوزوم "
 "یوکاریوتی متفاوت است.\n\n"
 "**پس تریکوموناس به مترونیدازول نیاز دارد** — دارویی که در محیط بی‌هوازی فعال "
 "می‌شود و DNA انگل را تخریب می‌کند.\n\n"
 "**و علت شایع دوم اورتریت پایدار: مایکوپلاسما ژنیتالیوم**، که به آزیترومایسین "
 "تک‌دوز مقاوم است و رژیم خاص خودش را می‌خواهد.\n\n"
 "⚠️ **و سومین احتمال که همیشه باید پرسیده شود: آیا شریک جنسی درمان شده است؟** اگر "
 "نه، بیمار **دوباره از همان منبع آلوده می‌شود** — چرخه‌ای که به آن **«پینگ‌پنگ»** "
 "می‌گویند. **درمان همزمان شریک جنسی، بخشی جدایی‌ناپذیر از درمان هر STI است.**\n\n"
 "**و نکته‌ی آخر: «ضایعه‌ی ژنیتالیا ندارد» عمداً ذکر شده تا هرپس و سیفلیس و "
 "شانکروئید را رد کند.**",
 "A 40-YEAR-OLD MAN with urethritis after a suspicious contact, treated with CEFTRIAXONE 250 MG "
 "INTRAMUSCULARLY AS A SINGLE DOSE AND DOXYCYCLINE FOR 7 DAYS. TWO WEEKS LATER he again has dysuria "
 "and discharge. Examination shows NO GENITAL LESION and the urethral discharge shows 8 TO 10 white "
 "cells.\n\n"
 "WARNING, THIS QUESTION TESTS THE LOGIC OF 'WHAT WAS NOT COVERED' — one of the most valuable "
 "clinical skills.\n\n"
 "FIRST SEE WHAT THE PREVIOUS TREATMENT COVERED:\n\n"
 "CEFTRIAXONE 250 MG IM — WARNING, GONORRHOEA WAS COVERED. That was exactly the standard regimen of "
 "the era.\n\n"
 "DOXYCYCLINE FOR 7 DAYS — WARNING, CHLAMYDIA WAS COVERED. Also a complete and correct regimen.\n\n"
 "SO THE PREVIOUS TREATMENT WAS BOTH CORRECT AND COMPLETE. And the patient is symptomatic again.\n\n"
 "THE LOGICAL CONCLUSION: THE PERSISTING SYMPTOMS MUST COME FROM AN ORGANISM NEITHER DRUG COVERS.\n\n"
 "AND WHICH ORGANISM IS THAT?\n\n"
 "WARNING, TRICHOMONAS VAGINALIS — and the reason is elegant: TRICHOMONAS IS NOT A BACTERIUM.\n\n"
 "TRICHOMONAS IS A FLAGELLATED PROTOZOAN PARASITE. So:\n\n"
 "CEPHALOSPORINS (which target the bacterial cell wall) — INEFFECTIVE, because the parasite has no "
 "bacterial cell wall.\n\n"
 "TETRACYCLINES (which target the bacterial ribosome) — INEFFECTIVE, because the eukaryotic "
 "ribosome differs.\n\n"
 "SO TRICHOMONAS NEEDS METRONIDAZOLE — a drug activated in anaerobic conditions that destroys the "
 "parasite's DNA.\n\n"
 "AND THE SECOND COMMON CAUSE OF PERSISTENT URETHRITIS: MYCOPLASMA GENITALIUM, which resists "
 "single-dose azithromycin and needs its own regimen.\n\n"
 "WARNING, AND A THIRD POSSIBILITY THAT MUST ALWAYS BE ASKED: HAS THE PARTNER BEEN TREATED? If not, "
 "the patient is REINFECTED FROM THE SAME SOURCE — a cycle called PING-PONG. SIMULTANEOUS PARTNER "
 "TREATMENT IS AN INSEPARABLE PART OF TREATING ANY STI.\n\n"
 "A FINAL POINT: 'no genital lesion' is stated deliberately, to exclude herpes, syphilis and "
 "chancroid.",
 ["گونوکوک با سفتریاکسون پوشش داده شده بود، پس علائم باقی‌مانده از آن نیست.",
  "کلامیدیا با داکسی‌سیکلین ۷ روزه پوشش داده شده بود و درمانش کامل بوده است.",
  "پاسخ صحیح — تریکوموناس یک انگل تک‌یاخته است و نه سفالوسپورین و نه تتراسایکلین آن را نمی‌گیرد.",
  "مقاومت گونوکوک محتمل نیست، چون بیمار به درمان اولیه پاسخ داده بود."],
 ["Gonorrhoea was covered by ceftriaxone, so the persisting symptoms are not from it.",
  "Chlamydia was covered by 7 days of doxycycline and that treatment was complete.",
  "Correct — trichomonas is a protozoan parasite that neither a cephalosporin nor a tetracycline touches.",
  "Gonococcal resistance is unlikely, since the patient responded to the initial treatment."],
 "**تریکوموناس باکتری نیست — پس هیچ آنتی‌بیوتیک ضدباکتریایی آن را نمی‌گیرد.**",
 "Trichomonas is not a bacterium, so no antibacterial antibiotic touches it.",
 [CDC2021, H])


# =========================================================== book:543
add("book:543", "recall", "medium",
 "در تریکوموناس مقاوم، **کلیندامایسین واژینال** درست نیست — تریکوموناس انگل است، نه باکتری.",
 "In resistant trichomonas, VAGINAL CLINDAMYCIN is not correct — trichomonas is a parasite, not a bacterium.",
 VAG_FA + [
  "**این سؤال همان مفهوم سؤال قبلی را از زاویه‌ی درمانی می‌آزماید.**",
  "⚠️ **تریکوموناس یک انگل تک‌یاخته‌ی تاژک‌دار است، نه باکتری.**",
  "**پس فقط به داروهای گروه نیتروایمیدازول پاسخ می‌دهد: مترونیدازول و تینیدازول.**",
  "**و کلیندامایسین یک آنتی‌بیوتیک ضدباکتریایی است که ریبوزوم باکتری را هدف می‌گیرد.**",
  "**جای درست کلیندامایسین واژینال، واژینوز باکتریال است، نه تریکوموناس.**",
  "⚠️ **و در مقاومت واقعی به مترونیدازول، سه راهکار درست وجود دارد.**",
  "**یک: افزایش دوز مترونیدازول، چون مقاومت اغلب نسبی است نه مطلق.**",
  "**دو: ترکیب خوراکی و واژینال، برای رساندن غلظت بالاتر به محل.**",
  "**سه: تعویض به تینیدازول، که نیمه‌عمر طولانی‌تر و نفوذ بافتی بهتری دارد.**",
  "**و تینیدازول در بسیاری از سویه‌های مقاوم به مترونیدازول هنوز مؤثر است.**",
 ],
 VAG_EN + [
  "This question tests the same concept as the previous one, from the therapeutic angle.",
  "WARNING: TRICHOMONAS IS A FLAGELLATED PROTOZOAN PARASITE, not a bacterium.",
  "So it responds only to the nitroimidazoles: metronidazole and tinidazole.",
  "And clindamycin is an antibacterial antibiotic that targets the bacterial ribosome.",
  "The right place for vaginal clindamycin is BACTERIAL VAGINOSIS, not trichomonas.",
  "WARNING, AND IN TRUE METRONIDAZOLE RESISTANCE THERE ARE THREE CORRECT STRATEGIES.",
  "One: increase the metronidazole dose, because resistance is usually relative rather than absolute.",
  "Two: combine oral and vaginal routes, to deliver a higher local concentration.",
  "Three: switch to tinidazole, which has a longer half-life and better tissue penetration.",
  "And tinidazole remains effective against many metronidazole-resistant strains.",
 ],
 "**خانم متأهلی با عفونت‌های راجعه‌ی تریکوموناس واژینالیس**، که بررسی نشان داده "
 "**گونه‌ی جداشده به مترونیدازول مقاوم است**. سؤال: کدام اقدام **درست نیست**؟\n\n"
 "⚠️ **پاسخ: درمان با کلیندامایسین واژینال.**\n\n"
 "**و دلیلش همان مفهومی است که در سؤال قبلی دیدید، این‌بار از زاویه‌ی درمانی:**\n\n"
 "> ⚠️ **تریکوموناس یک انگل تک‌یاخته‌ی تاژک‌دار است، نه باکتری.**\n\n"
 "**کلیندامایسین یک آنتی‌بیوتیک ضدباکتریایی است که به زیرواحد ۵۰S ریبوزوم باکتری "
 "می‌چسبد و سنتز پروتئین را متوقف می‌کند.** ⚠️ **ولی تریکوموناس یک یوکاریوت است و "
 "ریبوزومش متفاوت است — پس کلیندامایسین هیچ اثری روی آن ندارد.**\n\n"
 "**پس جای درست کلیندامایسین واژینال کجاست؟** ⚠️ **واژینوز باکتریال** — که آنجا "
 "واقعاً یکی از درمان‌های خط اول است (در کنار مترونیدازول). **و همین منشأ سردرگمی "
 "است: هر دو بیماری با ترشح واژینال می‌آیند، ولی درمانشان کاملاً متفاوت است.**\n\n"
 "**و حالا سه گزینه‌ی دیگر — همه راهکارهای درست در مقاومت به مترونیدازول‌اند:**\n\n"
 "**دوزهای بالاتر مترونیدازول** ✅ — ⚠️ **و دلیلش مهم است: مقاومت تریکوموناس به "
 "مترونیدازول معمولاً نسبی است، نه مطلق.** یعنی انگل در غلظت‌های معمول زنده می‌ماند "
 "ولی در غلظت‌های بالاتر کشته می‌شود. **پس افزایش دوز واقعاً جواب می‌دهد.**\n\n"
 "**درمان هم‌زمان خوراکی و واژینال** ✅ — منطق روشنی دارد: **خوراکی غلظت سیستمیک "
 "می‌دهد** و **واژینال غلظت موضعی بسیار بالا**. ترکیبشان **حداکثر غلظت را در محل "
 "عفونت** فراهم می‌کند.\n\n"
 "**تینیدازول** ✅ — ⚠️ **بهترین گزینه در مقاومت واقعی.** تینیدازول هم از خانواده‌ی "
 "**نیتروایمیدازول** است (مثل مترونیدازول)، ولی:\n\n"
 "**نیمه‌عمر طولانی‌تری دارد** (حدود ۱۲ تا ۱۴ ساعت در برابر ۸ ساعت).\n\n"
 "**نفوذ بافتی بهتری دارد.**\n\n"
 "**و در بسیاری از سویه‌های مقاوم به مترونیدازول، هنوز مؤثر است.**\n\n"
 "⚠️ **و نکته‌ی عملی که سؤال نپرسیده: در عفونت راجعه، همیشه باید شریک جنسی هم درمان "
 "شود.** تریکوموناس در مرد اغلب **بی‌علامت** است، و مرد درمان‌نشده **مخزن عفونت مجدد** "
 "می‌شود. **بسیاری از موارد «مقاومت»، در واقع عفونت مجدد از شریک درمان‌نشده است.**",
 "A MARRIED WOMAN with RECURRENT TRICHOMONAS VAGINALIS INFECTIONS, in whom the isolate is reported "
 "RESISTANT TO METRONIDAZOLE. Which action is NOT correct?\n\n"
 "WARNING, THE ANSWER: treatment with VAGINAL CLINDAMYCIN.\n\n"
 "And the reason is the same concept as the previous question, now from the therapeutic angle:\n\n"
 "> WARNING: TRICHOMONAS IS A FLAGELLATED PROTOZOAN PARASITE, NOT A BACTERIUM.\n\n"
 "CLINDAMYCIN IS AN ANTIBACTERIAL that binds the 50S subunit of the bacterial ribosome and halts "
 "protein synthesis. WARNING, BUT TRICHOMONAS IS A EUKARYOTE WITH A DIFFERENT RIBOSOME — so "
 "clindamycin has no effect on it whatever.\n\n"
 "SO WHERE DOES VAGINAL CLINDAMYCIN BELONG? WARNING, IN BACTERIAL VAGINOSIS — where it genuinely is "
 "a first-line treatment (alongside metronidazole). AND THAT IS THE SOURCE OF THE CONFUSION: both "
 "diseases present with vaginal discharge, but their treatments differ entirely.\n\n"
 "AND NOW THE OTHER THREE — all correct strategies in metronidazole resistance:\n\n"
 "HIGHER DOSES OF METRONIDAZOLE — WARNING, AND THE REASON MATTERS: TRICHOMONAS RESISTANCE TO "
 "METRONIDAZOLE IS USUALLY RELATIVE, NOT ABSOLUTE. The parasite survives ordinary concentrations but "
 "is killed at higher ones. SO RAISING THE DOSE GENUINELY WORKS.\n\n"
 "SIMULTANEOUS ORAL AND VAGINAL TREATMENT — the logic is clear: ORAL gives a systemic concentration "
 "and VAGINAL a very high local one. Together they deliver THE MAXIMUM CONCENTRATION AT THE SITE OF "
 "INFECTION.\n\n"
 "TINIDAZOLE — WARNING, THE BEST OPTION IN TRUE RESISTANCE. Tinidazole is also a NITROIMIDAZOLE "
 "(like metronidazole), but:\n\n"
 "It has a LONGER HALF-LIFE (about 12 to 14 hours versus 8).\n\n"
 "It has BETTER TISSUE PENETRATION.\n\n"
 "And it REMAINS EFFECTIVE against many metronidazole-resistant strains.\n\n"
 "WARNING, AND A PRACTICAL POINT THE QUESTION DOES NOT ASK: IN RECURRENT INFECTION THE PARTNER MUST "
 "ALWAYS BE TREATED TOO. Trichomonas is often ASYMPTOMATIC in men, and an untreated man becomes a "
 "RESERVOIR FOR REINFECTION. MANY CASES OF 'RESISTANCE' ARE IN FACT REINFECTION FROM AN UNTREATED "
 "PARTNER.",
 ["پاسخ صحیح — کلیندامایسین ضدباکتریایی است و روی انگل تک‌یاخته اثری ندارد؛ جایش واژینوز باکتریال است.",
  "درست است — مقاومت تریکوموناس معمولاً نسبی است، پس دوز بالاتر واقعاً جواب می‌دهد.",
  "درست است — ترکیب خوراکی و واژینال حداکثر غلظت را در محل عفونت فراهم می‌کند.",
  "درست است — تینیدازول نیمه‌عمر طولانی‌تر دارد و در بسیاری از سویه‌های مقاوم مؤثر است."],
 ["Correct — clindamycin is antibacterial and has no effect on a protozoan; its place is bacterial vaginosis.",
  "Correct action — trichomonas resistance is usually relative, so a higher dose genuinely works.",
  "Correct action — combining oral and vaginal routes gives the maximum concentration at the site.",
  "Correct action — tinidazole has a longer half-life and remains effective against many resistant strains."],
 "**کلیندامایسین برای واژینوز باکتریال است؛ تریکوموناس فقط نیتروایمیدازول می‌خواهد.**",
 "Clindamycin is for bacterial vaginosis; trichomonas needs a nitroimidazole and nothing else.",
 [CDC2021, H])


# =========================================================== book:547
add("book:547", "case", "hard",
 "علائم پس از آزیترومایسین **تک‌دوز** ← بازگشت به همان دارو با رژیم کامل‌تر، طبق کلید آن دوره.",
 "Symptoms after SINGLE-DOSE azithromycin: the era's key returns to the same drug in a fuller regimen.",
 URETH_FA + [
  "**این سؤال یکی از دشوارترین‌های فصل است و ارزش دقت دارد.**",
  "**بیمار آزیترومایسین یک گرم تک‌دوز گرفته، یعنی درمان کلامیدیا انجام شده.**",
  "**و «بهبود نسبی» داشته، یعنی درمان تا حدی اثر کرده ولی کامل نبوده.**",
  "⚠️ **کلید کتاب تکرار آزیترومایسین است، و منطقش در چارچوب آن دوره قابل دفاع است.**",
  "**آزیترومایسین تک‌دوز در کلامیدیا نرخ شکست دارد، به‌ویژه اگر بار میکروبی بالا باشد.**",
  "**پس تکرار یا تمدید همان دارو، در آن دوره رویکردی پذیرفته‌شده بود.**",
  "⚠️ **ولی راهنمای امروز CDC 2021 داکسی‌سیکلین را جایگزین آزیترومایسین کرده است.**",
  "**دلیلش برتری داکسی‌سیکلین در ریشه‌کنی کلامیدیا، به‌ویژه در محل رکتال است.**",
  "**و در اورتریت پایدار، مایکوپلاسما ژنیتالیوم باید جدی گرفته شود.**",
  "**چون آن هم به آزیترومایسین تک‌دوز مقاوم است و رژیم متفاوتی می‌خواهد.**",
 ],
 URETH_EN + [
  "This is one of the harder questions in the chapter and deserves care.",
  "The patient received azithromycin 1 g as a single dose, so chlamydia was treated.",
  "And he had 'partial improvement', meaning the treatment worked somewhat but incompletely.",
  "WARNING, THE BOOK'S KEY IS TO REPEAT THE AZITHROMYCIN, and its logic is defensible within that era.",
  "Single-dose azithromycin has a failure rate in chlamydia, especially with a high organism load.",
  "So repeating or extending the same drug was an accepted approach at the time.",
  "WARNING, BUT TODAY'S CDC 2021 GUIDANCE HAS REPLACED AZITHROMYCIN WITH DOXYCYCLINE.",
  "The reason is doxycycline's superiority in eradicating chlamydia, especially at rectal sites.",
  "And in persistent urethritis, Mycoplasma genitalium must be taken seriously.",
  "Because it too resists single-dose azithromycin and requires a different regimen.",
 ],
 "**آقای جوان** که ۲ هفته قبل به علت **سوزش ادرار و ترشح چرکی** با تشخیص یورتریت "
 "**آزیترومایسین یک گرم تک‌دوز** گرفته، و **به دنبال بهبود نسبی، مجدداً علائم مشابه** "
 "پیدا کرده است.\n\n"
 "⚠️ **کلید کتاب: تکرار آزیترومایسین تک‌دوز. و این کلید نیازمند توضیح دقیق است، چون "
 "در نگاه اول عجیب به‌نظر می‌رسد.**\n\n"
 "**اول وضعیت را دقیق بخوانیم:**\n\n"
 "**درمان قبلی: آزیترومایسین یک گرم تک‌دوز** → این رژیم **کلامیدیا** را هدف می‌گیرد. "
 "⚠️ **توجه: گونوکوک پوشش داده نشده بود** (که خودش یک نقص در درمان اولیه بوده).\n\n"
 "**نتیجه: «بهبود نسبی».** یعنی درمان **تا حدی اثر کرده** — پس عامل بیماری **به "
 "آزیترومایسین حساس بوده**، ولی **ریشه‌کن نشده**.\n\n"
 "**و حالا منطق کلید:**\n\n"
 "⚠️ **آزیترومایسین تک‌دوز در کلامیدیا نرخ شکست قابل توجهی دارد** — به‌ویژه وقتی "
 "**بار میکروبی بالا** باشد یا **جذب دارو ناکافی** باشد (مثلاً اگر بیمار پس از "
 "مصرف استفراغ کرده باشد). **پس تکرار یا تمدید همان دارو، در چارچوب آن دوره یک "
 "رویکرد پذیرفته‌شده بود**، به‌ویژه چون **بهبود نسبی** نشان می‌داد دارو **کار "
 "می‌کند** ولی **کافی نبوده**.\n\n"
 "**و چرا سه گزینه‌ی دیگر در آن چارچوب کنار گذاشته شدند؟**\n\n"
 "**داکسی‌سیکلین ۷ روز** — ⚠️ **جالب‌ترین گزینه، چون امروز پاسخ بهتری است.** "
 "**CDC در راهنمای ۲۰۲۱ داکسی‌سیکلین ۱۰۰ میلی‌گرم دو بار در روز به مدت ۷ روز را "
 "جایگزین آزیترومایسین کرد**، به‌دلیل **برتری در ریشه‌کنی کلامیدیا** (به‌ویژه در "
 "محل رکتال). **پس اگر این سؤال امروز طرح می‌شد، داکسی‌سیکلین پاسخ بهتری بود.**\n\n"
 "**سیپروفلوکساسین ۳ روز** — ⚠️ **بدترین گزینه.** فلوروکینولون‌ها **کلامیدیا را خوب "
 "پوشش نمی‌دهند** و **برای گونوکوک هم از ۲۰۰۷ کنار گذاشته شده‌اند**.\n\n"
 "**سفکسیم تک‌دوز** — **گونوکوک** را هدف می‌گیرد، نه کلامیدیا. و بیمار **پس از "
 "آزیترومایسین بهبود نسبی داشته** — که نشان می‌دهد عامل **به ماکرولید حساس** بوده، "
 "یعنی احتمالاً **کلامیدیا یا مایکوپلاسما**، نه گونوکوک.\n\n"
 "⚠️ **و مهم‌ترین نکته‌ی امروزی که درسنامه باید بگوید: در اورتریت پایدار، "
 "مایکوپلاسما ژنیتالیوم باید جدی گرفته شود.** آن هم به **آزیترومایسین تک‌دوز مقاوم** "
 "است، و درمانش **داکسی‌سیکلین سپس موکسی‌فلوکساسین** یا **آزیترومایسین با رژیم "
 "طولانی** است. **پس رویکرد کامل امروزی: آزمایش هدفمند برای تریکوموناس و مایکوپلاسما "
 "ژنیتالیوم، و بررسی درمان شریک جنسی.**",
 "A YOUNG MAN who two weeks ago received AZITHROMYCIN 1 G AS A SINGLE DOSE for urethritis with "
 "dysuria and purulent discharge, and who AFTER PARTIAL IMPROVEMENT HAS DEVELOPED THE SAME SYMPTOMS "
 "AGAIN.\n\n"
 "WARNING, THE BOOK'S KEY: repeat the single-dose azithromycin. This key needs careful explanation, "
 "because at first glance it looks odd.\n\n"
 "FIRST READ THE SITUATION PRECISELY:\n\n"
 "PREVIOUS TREATMENT: AZITHROMYCIN 1 G SINGLE DOSE — a regimen aimed at CHLAMYDIA. WARNING, NOTE "
 "THAT GONORRHOEA WAS NOT COVERED (itself a shortcoming of the initial treatment).\n\n"
 "THE RESULT: 'PARTIAL IMPROVEMENT'. So the treatment WORKED TO SOME EXTENT — the organism was "
 "SENSITIVE TO AZITHROMYCIN but NOT ERADICATED.\n\n"
 "AND NOW THE KEY'S LOGIC:\n\n"
 "WARNING, SINGLE-DOSE AZITHROMYCIN HAS AN APPRECIABLE FAILURE RATE IN CHLAMYDIA — especially with "
 "a HIGH ORGANISM LOAD or INADEQUATE ABSORPTION (for instance if the patient vomited afterwards). "
 "SO REPEATING OR EXTENDING THE SAME DRUG WAS AN ACCEPTED APPROACH IN THAT ERA, particularly since "
 "PARTIAL IMPROVEMENT showed the drug WAS WORKING but WAS NOT ENOUGH.\n\n"
 "AND WHY WERE THE OTHER THREE SET ASIDE IN THAT FRAMEWORK?\n\n"
 "DOXYCYCLINE FOR 7 DAYS — WARNING, THE MOST INTERESTING OPTION, BECAUSE TODAY IT IS THE BETTER "
 "ANSWER. THE CDC'S 2021 GUIDELINE REPLACED AZITHROMYCIN WITH DOXYCYCLINE 100 MG TWICE DAILY FOR 7 "
 "DAYS, because of its SUPERIORITY IN ERADICATING CHLAMYDIA (especially at rectal sites). SO IF "
 "THIS QUESTION WERE SET TODAY, DOXYCYCLINE WOULD BE THE BETTER ANSWER.\n\n"
 "CIPROFLOXACIN FOR 3 DAYS — WARNING, THE WORST OPTION. Fluoroquinolones COVER CHLAMYDIA POORLY and "
 "have been ABANDONED FOR GONORRHOEA SINCE 2007.\n\n"
 "SINGLE-DOSE CEFIXIME — targets GONORRHOEA, not chlamydia. And the patient IMPROVED PARTIALLY ON "
 "AZITHROMYCIN, showing the organism was MACROLIDE-SENSITIVE — so probably CHLAMYDIA OR MYCOPLASMA, "
 "not the gonococcus.\n\n"
 "WARNING, AND THE MOST IMPORTANT MODERN POINT THIS LESSON MUST STATE: IN PERSISTENT URETHRITIS, "
 "MYCOPLASMA GENITALIUM MUST BE TAKEN SERIOUSLY. It too RESISTS SINGLE-DOSE AZITHROMYCIN, and its "
 "treatment is DOXYCYCLINE FOLLOWED BY MOXIFLOXACIN or an EXTENDED AZITHROMYCIN regimen. SO THE "
 "COMPLETE MODERN APPROACH: targeted testing for trichomonas and M. genitalium, and checking the "
 "partner's treatment.",
 ["پاسخ کلید آن دوره — بهبود نسبی نشان می‌دهد دارو مؤثر بوده ولی ریشه‌کن نکرده، پس تکرار منطقی بود.",
  "امروز پاسخ بهتری است — CDC در ۲۰۲۱ داکسی‌سیکلین را جایگزین آزیترومایسین کرد.",
  "بدترین گزینه — فلوروکینولون‌ها کلامیدیا را خوب پوشش نمی‌دهند و برای گونوکوک هم منسوخ‌اند.",
  "سفکسیم گونوکوک را هدف می‌گیرد، ولی بهبود نسبی با ماکرولید نشان می‌دهد عامل کلامیدیا یا مایکوپلاسماست."],
 ["The era's keyed answer — partial improvement shows the drug worked but did not eradicate, so repeating was logical.",
  "Today the better answer — the CDC replaced azithromycin with doxycycline in 2021.",
  "The worst option — fluoroquinolones cover chlamydia poorly and are obsolete for gonorrhoea.",
  "Cefixime targets gonorrhoea, but partial improvement on a macrolide points to chlamydia or mycoplasma."],
 "**کلید آن دوره تکرار آزیترومایسین بود؛ پاسخ امروز داکسی‌سیکلین است. هر دو را بدانید.**",
 "The era's key was to repeat azithromycin; today's answer is doxycycline. Know both.",
 [CDC2021, H])


# =========================================================== book:548
add("book:548", "case", "medium",
 "اورتریت با کشت ادرار منفی ← درمان **دوگانه**: سفکسیم برای گونوکوک + آزیترومایسین برای کلامیدیا.",
 "Urethritis with a negative urine culture needs DUAL therapy: cefixime for gonorrhoea plus azithromycin for chlamydia.",
 URETH_FA + [
  "**این سؤال اصل درمان دوگانه‌ی اورتریت را مستقیم می‌آزماید.**",
  "⚠️ **پیوری با کشت ادرار منفی، دقیقاً همان الگوی اورتریت منتقله از راه جنسی است.**",
  "**چون نه گونوکوک و نه کلامیدیا در کشت ادرار معمولی رشد نمی‌کنند.**",
  "**و چون هم‌زمانی این دو تا یک‌سوم موارد است، درمان باید هر دو را بگیرد.**",
  "**پس گزینه‌ای درست است که هم پوشش گونوکوک دارد و هم پوشش کلامیدیا.**",
  "⚠️ **گزینه‌های تک‌دارویی، هر کدام نیمی از مسئله را حل می‌کنند و نیمی را رها.**",
  "**و رها کردن کلامیدیای درمان‌نشده در مرد، به اپیدیدیمیت و در زن به ناباروری می‌انجامد.**",
  "**نبود تکرر ادرار هم به نفع اورتریت است تا سیستیت.**",
 ],
 URETH_EN + [
  "This question tests the principle of dual therapy for urethritis directly.",
  "WARNING: PYURIA WITH A NEGATIVE URINE CULTURE is exactly the pattern of sexually transmitted urethritis.",
  "Because neither the gonococcus nor chlamydia grows on ordinary urine culture media.",
  "And because the two coincide in up to a third of cases, treatment must cover both.",
  "So the right option is the one that covers gonorrhoea AND chlamydia.",
  "WARNING, THE SINGLE-DRUG OPTIONS each solve half the problem and abandon the other half.",
  "And leaving chlamydia untreated leads to epididymitis in men and infertility in women.",
  "The absence of frequency also favours urethritis over cystitis.",
 ],
 "**آقای ۳۰ ساله** پس از تماس جنسی اخیر، با **سوزش مجرای ادراری بدون تکرر ادرار** و "
 "**ترشح مجرا**. آزمایش ادرار: **WBC=10-15**. **کشت ادرار منفی.**\n\n"
 "⚠️ **پاسخ: سفکسیم ۴۰۰ میلی‌گرم دوز منفرد خوراکی + آزیترومایسین یک گرم تک‌دوز.**\n\n"
 "**و این سؤال اصل بنیادی درمان اورتریت را مستقیم می‌آزماید:**\n\n"
 "> ⚠️ **همیشه هر دو را درمان کنید — گونوکوک و کلامیدیا.**\n\n"
 "**اول سرنخ‌ها را بخوانیم:**\n\n"
 "**سوزش مجرا بدون تکرر ادرار** → به نفع **اورتریت** است تا **سیستیت**. (در سیستیت، "
 "تکرر و فوریت غالب‌اند.)\n\n"
 "**ترشح مجرا** → تأیید اورتریت.\n\n"
 "⚠️ **پیوری با کشت ادرار منفی** → **دقیقاً الگوی اورتریت منتقله از راه جنسی.** چرا؟ "
 "چون **نه گونوکوک و نه کلامیدیا در کشت ادرار معمولی رشد نمی‌کنند**: کلامیدیا "
 "**داخل سلولی اجباری** است، و گونوکوک **محیط کشت اختصاصی** (تایر-مارتین) می‌خواهد.\n\n"
 "**و چرا درمان دوگانه؟**\n\n"
 "⚠️ **چون هم‌زمانی گونوکوک و کلامیدیا تا یک‌سوم موارد است.** بیماری که با اورتریت "
 "گونوکوکی می‌آید، **در یک‌سوم موارد کلامیدیا هم دارد** — و برعکس. **پس درمان تک‌دارویی "
 "نیمی از موارد را ناقص درمان می‌کند.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**سیپروفلوکساسین ۷ روز** ❌ — **دو اشکال:** فلوروکینولون‌ها **برای گونوکوک از ۲۰۰۷ "
 "منسوخ** شده‌اند (مقاومت گسترده)، و **کلامیدیا را هم خوب پوشش نمی‌دهند**.\n\n"
 "**سفتریاکسون یک گرم وریدی + داکسی‌سیکلین** — ⚠️ **گزینه‌ی جالبی است چون از نظر "
 "پوشش میکروبی درست است** (هر دو پوشش داده می‌شوند). ولی **دوز و راه تجویز نامناسب "
 "است**: برای اورتریت ساده، **یک گرم وریدی** بیش از حد است. رژیم استاندارد آن دوره "
 "**۲۵۰ میلی‌گرم عضلانی** بود.\n\n"
 "**داکسی‌سیکلین تنها ۷ روز** ❌ — ⚠️ **نیمی از مسئله را حل می‌کند:** کلامیدیا را "
 "می‌گیرد ولی **گونوکوک را رها می‌کند**. و **گونوکوک درمان‌نشده** می‌تواند به "
 "**اپیدیدیمیت، پروستاتیت و عفونت گنوکوکی منتشر** بینجامد.\n\n"
 "⚠️ **و به‌روزرسانی مهم: CDC در ۲۰۲۱ رژیم را عوض کرد.** امروز: **سفتریاکسون ۵۰۰ "
 "میلی‌گرم عضلانی تک‌دوز** (به‌جای ۲۵۰) به‌علاوه‌ی **داکسی‌سیکلین ۱۰۰ میلی‌گرم دو بار "
 "در روز به مدت ۷ روز** (به‌جای آزیترومایسین). **و سفکسیم خوراکی فقط وقتی است که "
 "سفتریاکسون در دسترس نباشد.**",
 "A 30-YEAR-OLD MAN after recent sexual contact, with URETHRAL BURNING WITHOUT FREQUENCY and "
 "URETHRAL DISCHARGE. Urinalysis: 10 to 15 WHITE CELLS. URINE CULTURE NEGATIVE.\n\n"
 "WARNING, THE ANSWER: CEFIXIME 400 MG ORALLY AS A SINGLE DOSE PLUS AZITHROMYCIN 1 G SINGLE DOSE.\n\n"
 "This question tests the fundamental principle of urethritis treatment directly:\n\n"
 "> WARNING: ALWAYS TREAT BOTH — GONORRHOEA AND CHLAMYDIA.\n\n"
 "FIRST READ THE CLUES:\n\n"
 "URETHRAL BURNING WITHOUT FREQUENCY — favours URETHRITIS over CYSTITIS. (In cystitis frequency and "
 "urgency dominate.)\n\n"
 "URETHRAL DISCHARGE — confirms urethritis.\n\n"
 "WARNING, PYURIA WITH A NEGATIVE URINE CULTURE — EXACTLY THE PATTERN OF SEXUALLY TRANSMITTED "
 "URETHRITIS. Why? Because NEITHER THE GONOCOCCUS NOR CHLAMYDIA GROWS ON ORDINARY URINE CULTURE: "
 "chlamydia is OBLIGATE INTRACELLULAR, and the gonococcus needs SPECIAL MEDIA (Thayer-Martin).\n\n"
 "AND WHY DUAL THERAPY?\n\n"
 "WARNING, BECAUSE GONORRHOEA AND CHLAMYDIA COINCIDE IN UP TO A THIRD OF CASES. A patient "
 "presenting with gonococcal urethritis ALSO HAS CHLAMYDIA IN A THIRD OF CASES — and vice versa. SO "
 "SINGLE-DRUG THERAPY UNDERTREATS HALF OF THEM.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "CIPROFLOXACIN FOR 7 DAYS — TWO FLAWS: fluoroquinolones are OBSOLETE FOR GONORRHOEA SINCE 2007 "
 "(widespread resistance), and they COVER CHLAMYDIA POORLY too.\n\n"
 "CEFTRIAXONE 1 G IV PLUS DOXYCYCLINE — WARNING, an interesting option because ITS MICROBIAL COVER "
 "IS CORRECT (both are covered). But THE DOSE AND ROUTE ARE INAPPROPRIATE: for simple urethritis, 1 "
 "G INTRAVENOUSLY is excessive. The era's standard was 250 MG INTRAMUSCULARLY.\n\n"
 "DOXYCYCLINE ALONE FOR 7 DAYS — WARNING, IT SOLVES HALF THE PROBLEM: it covers chlamydia but "
 "ABANDONS THE GONOCOCCUS. And UNTREATED GONORRHOEA can lead to EPIDIDYMITIS, PROSTATITIS AND "
 "DISSEMINATED GONOCOCCAL INFECTION.\n\n"
 "WARNING, AND AN IMPORTANT UPDATE: THE CDC CHANGED THE REGIMEN IN 2021. Today: CEFTRIAXONE 500 MG "
 "IM AS A SINGLE DOSE (instead of 250) PLUS DOXYCYCLINE 100 MG TWICE DAILY FOR 7 DAYS (instead of "
 "azithromycin). AND ORAL CEFIXIME IS ONLY FOR WHEN CEFTRIAXONE IS UNAVAILABLE.",
 ["فلوروکینولون‌ها برای گونوکوک منسوخ‌اند و کلامیدیا را هم خوب پوشش نمی‌دهند.",
  "پاسخ صحیح — درمان دوگانه لازم است، چون گونوکوک و کلامیدیا تا یک‌سوم موارد با هم می‌آیند.",
  "پوشش میکروبی‌اش درست است ولی یک گرم وریدی برای اورتریت ساده بیش از حد است.",
  "نیمی از مسئله را حل می‌کند — کلامیدیا را می‌گیرد ولی گونوکوک را رها می‌کند."],
 ["Fluoroquinolones are obsolete for gonorrhoea and cover chlamydia poorly as well.",
  "Correct — dual therapy is needed because gonorrhoea and chlamydia coincide in up to a third of cases.",
  "Its microbial cover is right, but 1 g intravenously is excessive for simple urethritis.",
  "It solves half the problem — covering chlamydia but abandoning the gonococcus."],
 "**همیشه هر دو را درمان کنید: تا یک‌سوم بیماران هر دو عفونت را با هم دارند.**",
 "Always treat both: up to a third of patients have both infections together.",
 [CDC2021, H])


# =========================================================== book:550
add("book:550", "case", "medium",
 "ترشح چرکی **بدون امکان آزمایش** ← درمان تجربی **دوگانه**: سفتریاکسون + آزیترومایسین.",
 "Purulent discharge WITH NO TESTING AVAILABLE: empirical DUAL therapy — ceftriaxone plus azithromycin.",
 URETH_FA + [
  "**این سؤال درمان تجربی را در شرایط محدودیت امکانات می‌آزماید.**",
  "⚠️ **و جمله‌ی «در صورتی که امکان انجام آزمایش مقدور نباشد» کل رویکرد را تعیین می‌کند.**",
  "**وقتی نمی‌توان عامل را شناسایی کرد، باید محتمل‌ترین عوامل را با هم پوشش داد.**",
  "**ترشح چرکی و کمون چهارروزه، هر دو به نفع گونوکوک‌اند.**",
  "**ولی کلامیدیای هم‌زمان تا یک‌سوم موارد وجود دارد و دیده نمی‌شود.**",
  "⚠️ **پس پوشش تک‌دارویی، بیمار را با نیمی از عفونت رها می‌کند.**",
  "**و کلامیدیای درمان‌نشده در مرد به اپیدیدیمیت و در شریک زن به ناباروری می‌انجامد.**",
  "**پس درمان تجربی در اورتریت همیشه دوگانه است، حتی وقتی یک عامل محتمل‌تر به‌نظر می‌رسد.**",
 ],
 URETH_EN + [
  "This question tests empirical treatment under resource constraints.",
  "WARNING, AND THE PHRASE 'IF TESTING IS NOT POSSIBLE' determines the whole approach.",
  "When the organism cannot be identified, the likeliest organisms must be covered together.",
  "Purulent discharge and a four-day incubation both favour gonorrhoea.",
  "But concurrent chlamydia is present in up to a third of cases and goes unseen.",
  "WARNING, SO SINGLE-DRUG COVER LEAVES THE PATIENT WITH HALF AN INFECTION.",
  "And untreated chlamydia causes epididymitis in the man and infertility in a female partner.",
  "So empirical treatment of urethritis is always dual, even when one organism seems likelier.",
 ],
 "**پسر جوان ۲۵ ساله** با **ترشح چرکی مجرای ادرار** و سابقه‌ی **تماس جنسی چهار روز "
 "قبل**. سؤال: کدام رژیم درمانی، **در صورتی که امکان انجام آزمایش مقدور نباشد**؟\n\n"
 "⚠️ **جمله‌ی کلیدی: «در صورتی که امکان انجام آزمایش مقدور نباشد». این جمله کل "
 "رویکرد را تعیین می‌کند.**\n\n"
 "**پاسخ: آزیترومایسین + سفتریاکسون.**\n\n"
 "**اول سرنخ‌های بالینی:**\n\n"
 "**ترشح چرکی** → به نفع **گونوکوک** (کلامیدیا ترشح **مخاطی و کم** می‌دهد).\n\n"
 "**کمون چهارروزه** → به نفع **گونوکوک** (کمون ۲ تا ۷ روز؛ کلامیدیا ۷ تا ۲۱ روز).\n\n"
 "**پس گونوکوک محتمل‌تر است. ولی این کافی نیست.**\n\n"
 "⚠️ **چرا؟ چون کلامیدیای هم‌زمان تا یک‌سوم موارد وجود دارد — و بدون آزمایش، هیچ "
 "راهی برای دیدنش نیست.**\n\n"
 "**و اینجا اصل درمان تجربی مطرح می‌شود:**\n\n"
 "> ⚠️ **وقتی نمی‌توان عامل را شناسایی کرد، محتمل‌ترین عوامل را با هم پوشش دهید.**\n\n"
 "**عواقب پوشش ناقص را بدانید، چون همین منطق را می‌سازد:**\n\n"
 "**اگر کلامیدیا درمان نشود:** در **مرد** → اپیدیدیمیت، پروستاتیت، آرتریت واکنشی. "
 "⚠️ **و در شریک جنسی زن** → **بیماری التهابی لگن، ناباروری، و بارداری خارج رحمی**. "
 "**این عوارض بازگشت‌ناپذیرند.**\n\n"
 "**اگر گونوکوک درمان نشود:** اپیدیدیمیت، استریکچر مجرا، و **عفونت گنوکوکی منتشر**.\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**هفت روز مترونیدازول** ❌ — **مترونیدازول تریکوموناس و بی‌هوازی‌ها را می‌گیرد**، "
 "ولی **نه گونوکوک و نه کلامیدیا**. **هر دو عامل اصلی را رها می‌کند.**\n\n"
 "**هفت روز آزیترومایسین خوراکی** ❌ — ⚠️ **کلامیدیا را می‌گیرد ولی گونوکوک را نه** "
 "(مقاومت ماکرولیدی گونوکوک گسترده است). **نیمی از مسئله.**\n\n"
 "**هفت روز داکسی‌سیکلین** ❌ — **همان اشکال**: کلامیدیا آری، گونوکوک نه.\n\n"
 "⚠️ **و به‌روزرسانی CDC 2021: امروز رژیم استاندارد سفتریاکسون ۵۰۰ میلی‌گرم عضلانی "
 "تک‌دوز به‌علاوه‌ی داکسی‌سیکلین ۱۰۰ میلی‌گرم دو بار در روز به مدت ۷ روز است.** "
 "آزیترومایسین به‌دلیل **مقاومت فزاینده** کنار گذاشته شد. **ولی اصل بنیادی همان "
 "است و تغییر نکرده: پوشش دوگانه.**",
 "A 25-YEAR-OLD MAN with PURULENT URETHRAL DISCHARGE and a history of SEXUAL CONTACT FOUR DAYS AGO. "
 "Which regimen, IF TESTING IS NOT POSSIBLE?\n\n"
 "WARNING, THE KEY PHRASE: 'IF TESTING IS NOT POSSIBLE'. That phrase determines the whole approach.\n\n"
 "THE ANSWER: AZITHROMYCIN PLUS CEFTRIAXONE.\n\n"
 "FIRST THE CLINICAL CLUES:\n\n"
 "PURULENT DISCHARGE — favours GONORRHOEA (chlamydia gives a SCANT MUCOID discharge).\n\n"
 "A FOUR-DAY INCUBATION — favours GONORRHOEA (2 to 7 days; chlamydia 7 to 21).\n\n"
 "SO GONORRHOEA IS LIKELIER. BUT THAT IS NOT ENOUGH.\n\n"
 "WARNING, WHY? BECAUSE CONCURRENT CHLAMYDIA IS PRESENT IN UP TO A THIRD OF CASES — and without "
 "testing there is no way to see it.\n\n"
 "And here the principle of empirical treatment arises:\n\n"
 "> WARNING: WHEN THE ORGANISM CANNOT BE IDENTIFIED, COVER THE LIKELIEST ORGANISMS TOGETHER.\n\n"
 "KNOW THE CONSEQUENCES OF INCOMPLETE COVER, because they are what create this logic:\n\n"
 "IF CHLAMYDIA IS UNTREATED: in the MAN — epididymitis, prostatitis, reactive arthritis. WARNING, "
 "AND IN A FEMALE PARTNER — PELVIC INFLAMMATORY DISEASE, INFERTILITY AND ECTOPIC PREGNANCY. THOSE "
 "COMPLICATIONS ARE IRREVERSIBLE.\n\n"
 "IF GONORRHOEA IS UNTREATED: epididymitis, urethral stricture, and DISSEMINATED GONOCOCCAL "
 "INFECTION.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "SEVEN DAYS OF METRONIDAZOLE — metronidazole covers TRICHOMONAS AND ANAEROBES but NEITHER "
 "GONORRHOEA NOR CHLAMYDIA. IT ABANDONS BOTH MAIN ORGANISMS.\n\n"
 "SEVEN DAYS OF ORAL AZITHROMYCIN — WARNING, it covers chlamydia BUT NOT GONORRHOEA (gonococcal "
 "macrolide resistance is widespread). HALF THE PROBLEM.\n\n"
 "SEVEN DAYS OF DOXYCYCLINE — THE SAME FLAW: chlamydia yes, gonorrhoea no.\n\n"
 "WARNING, AND THE CDC 2021 UPDATE: today's standard is CEFTRIAXONE 500 MG IM AS A SINGLE DOSE PLUS "
 "DOXYCYCLINE 100 MG TWICE DAILY FOR 7 DAYS. Azithromycin was dropped because of RISING RESISTANCE. "
 "BUT THE UNDERLYING PRINCIPLE IS UNCHANGED: DUAL COVER.",
 ["مترونیدازول تریکوموناس و بی‌هوازی‌ها را می‌گیرد ولی هر دو عامل اصلی اورتریت را رها می‌کند.",
  "پاسخ صحیح — بدون امکان آزمایش، باید هم گونوکوک و هم کلامیدیا را تجربی پوشش داد.",
  "آزیترومایسین تنها کلامیدیا را می‌گیرد؛ مقاومت ماکرولیدی گونوکوک گسترده است.",
  "داکسی‌سیکلین تنها همان اشکال را دارد — کلامیدیا آری، گونوکوک نه."],
 ["Metronidazole covers trichomonas and anaerobes but abandons both main urethritis organisms.",
  "Correct — with no testing available, both gonorrhoea and chlamydia must be covered empirically.",
  "Azithromycin alone covers chlamydia; gonococcal macrolide resistance is widespread.",
  "Doxycycline alone has the same flaw — chlamydia yes, gonorrhoea no."],
 "**بدون آزمایش، محتمل‌ترین عوامل را با هم پوشش دهید — پوشش ناقص عوارض بازگشت‌ناپذیر دارد.**",
 "Without testing, cover the likeliest organisms together — incomplete cover causes irreversible harm.",
 [CDC2021, H])


# =========================================================== book:562
add("book:562", "recall", "medium",
 "واکسن HPV در **مرد ۲۰ ساله**: **سه دوز** — چون شروع پس از ۱۵ سالگی است.",
 "HPV vaccine in a 20-YEAR-OLD MAN: THREE DOSES, because he is starting at 15 or older.",
 URETH_FA + [
  "**واکسن HPV دو برنامه‌ی دوزبندی دارد و مرز آن سن شروع است، نه سن فعلی.**",
  "⚠️ **اگر دوز اول پیش از تولد پانزده‌سالگی زده شود: دو دوز کافی است.**",
  "**و اگر در ۱۵ سالگی یا بالاتر شروع شود: سه دوز لازم است.**",
  "**دلیلش ایمنی‌شناختی است: پاسخ آنتی‌بادی در نوجوانان کم‌سن‌تر قوی‌تر است.**",
  "**پس بدن نوجوان با دو دوز همان تیتری را می‌سازد که بالغ با سه دوز.**",
  "⚠️ **و افراد با نقص ایمنی، در هر سنی سه دوز می‌گیرند.**",
  "**واکسن HPV در مردان اندیکاسیون کامل دارد و این یک باور غلط رایج است.**",
  "**در مرد از سرطان آنال، پنیس، دهان و حلق، و زگیل تناسلی پیشگیری می‌کند.**",
  "**و ایمنی گله‌ای می‌سازد که شریک جنسی زن را هم محافظت می‌کند.**",
  "⚠️ **و بهترین زمان واکسیناسیون، پیش از شروع فعالیت جنسی است — دقیقاً وضعیت این بیمار.**",
 ],
 URETH_EN + [
  "The HPV vaccine has two schedules, and the dividing line is the AGE AT INITIATION, not current age.",
  "WARNING: if the first dose is given before the fifteenth birthday, TWO DOSES suffice.",
  "And if the course begins at 15 or older, THREE DOSES are required.",
  "The reason is immunological: the antibody response is stronger in younger adolescents.",
  "So an adolescent's body achieves with two doses the titre an adult needs three for.",
  "WARNING, AND THE IMMUNOCOMPROMISED RECEIVE THREE DOSES AT ANY AGE.",
  "The HPV vaccine is fully indicated in males, and the contrary is a common misconception.",
  "In men it prevents anal, penile and oropharyngeal cancer, and genital warts.",
  "And it creates herd immunity that also protects female partners.",
  "WARNING, AND THE BEST TIME TO VACCINATE IS BEFORE SEXUAL DEBUT — exactly this patient's situation.",
 ],
 "**آقای ۲۰ ساله، بدون سابقه‌ی تماس جنسی**، برای مشاوره درباره‌ی **پروفیلاکسی HPV** "
 "مراجعه کرده است.\n\n"
 "⚠️ **پاسخ: تجویز واکسن HPV در ۳ دوز.**\n\n"
 "**و این سؤال دو باور غلط رایج را هم‌زمان می‌آزماید.**\n\n"
 "**باور غلط اول: «واکسن HPV در آقایان اندیکاسیون ندارد.»**\n\n"
 "⚠️ **کاملاً غلط. واکسن HPV در مردان اندیکاسیون کامل دارد، و دلایلش قوی است:**\n\n"
 "**۱) سرطان آنال** — HPV عامل اصلی آن است، و بروزش در مردان در حال افزایش.\n\n"
 "**۲) سرطان پنیس** — کمتر شایع ولی جدی.\n\n"
 "**۳) سرطان دهان و حلق** — ⚠️ **و این مهم‌ترین است: بروز سرطان اوروفارنکس مرتبط با "
 "HPV در مردان به‌سرعت افزایش یافته** و در برخی کشورها **از سرطان سرویکس هم پیشی "
 "گرفته است**.\n\n"
 "**۴) زگیل تناسلی** — که هرچند خوش‌خیم است، بار روانی و درمانی سنگینی دارد.\n\n"
 "**۵) ایمنی گله‌ای** — واکسیناسیون مردان، **شریک جنسی زن را هم محافظت می‌کند** و "
 "چرخه‌ی انتقال را می‌شکند.\n\n"
 "**باور غلط دوم: «در سن ۲۰ سالگی دیگر دیر است.»**\n\n"
 "⚠️ **هم غلط است و هم برعکس: این بیمار سابقه‌ی تماس جنسی ندارد، یعنی در بهترین "
 "وضعیت ممکن برای واکسیناسیون است.** بهترین زمان واکسن HPV **پیش از شروع فعالیت "
 "جنسی** است، چون واکسن **پیشگیری‌کننده** است نه **درمانی** — روی عفونت موجود اثری "
 "ندارد.\n\n"
 "**و حالا چرا سه دوز و نه یک دوز یا دو دوز؟**\n\n"
 "⚠️ **واکسن HPV دو برنامه‌ی دوزبندی دارد، و مرز آن سن شروع است:**\n\n"
 "**شروع پیش از تولد ۱۵ سالگی → دو دوز** (با فاصله‌ی ۶ تا ۱۲ ماه).\n\n"
 "**شروع در ۱۵ سالگی یا بالاتر → سه دوز** (در ماه‌های ۰، ۱ تا ۲، و ۶).\n\n"
 "**و دلیلش ایمنی‌شناختی است و زیبا:** ⚠️ **پاسخ آنتی‌بادی در نوجوانان کم‌سن‌تر "
 "قوی‌تر است.** بدن یک نوجوان ۱۲ ساله با **دو دوز** همان تیتری را می‌سازد که بدن یک "
 "بالغ با **سه دوز**. **پس برنامه‌ی دو دوزی صرفه‌جویی نیست — بر پایه‌ی پاسخ ایمنی "
 "واقعی است.**\n\n"
 "**این بیمار ۲۰ ساله است، پس سه دوز لازم دارد.** ✅\n\n"
 "⚠️ **و یک استثنای مهم: افراد با نقص ایمنی (از جمله HIV مثبت) در هر سنی سه دوز "
 "می‌گیرند، حتی اگر پیش از ۱۵ سالگی شروع کنند.**",
 "A 20-YEAR-OLD MAN WITH NO HISTORY OF SEXUAL CONTACT presents for counselling about HPV "
 "PROPHYLAXIS.\n\n"
 "WARNING, THE ANSWER: give the HPV vaccine in 3 DOSES.\n\n"
 "This question tests two common misconceptions at once.\n\n"
 "MISCONCEPTION ONE: 'THE HPV VACCINE IS NOT INDICATED IN MEN.'\n\n"
 "WARNING, COMPLETELY WRONG. The HPV vaccine is fully indicated in men, for strong reasons:\n\n"
 "1) ANAL CANCER — HPV is its main cause, and its incidence in men is rising.\n\n"
 "2) PENILE CANCER — less common but serious.\n\n"
 "3) OROPHARYNGEAL CANCER — WARNING, AND THIS IS THE MOST IMPORTANT: THE INCIDENCE OF "
 "HPV-RELATED OROPHARYNGEAL CANCER IN MEN HAS RISEN RAPIDLY and in some countries HAS OVERTAKEN "
 "CERVICAL CANCER.\n\n"
 "4) GENITAL WARTS — benign but a heavy psychological and treatment burden.\n\n"
 "5) HERD IMMUNITY — vaccinating men ALSO PROTECTS FEMALE PARTNERS and breaks the transmission "
 "cycle.\n\n"
 "MISCONCEPTION TWO: 'AT 20 IT IS TOO LATE.'\n\n"
 "WARNING, WRONG AND INDEED THE OPPOSITE: this patient HAS NO HISTORY OF SEXUAL CONTACT, so he is "
 "IN THE BEST POSSIBLE POSITION FOR VACCINATION. The best time for HPV vaccine is BEFORE SEXUAL "
 "DEBUT, because the vaccine is PREVENTIVE rather than THERAPEUTIC — it has no effect on existing "
 "infection.\n\n"
 "AND NOW WHY THREE DOSES RATHER THAN ONE OR TWO?\n\n"
 "WARNING, THE HPV VACCINE HAS TWO SCHEDULES, and the dividing line is THE AGE AT INITIATION:\n\n"
 "STARTING BEFORE THE FIFTEENTH BIRTHDAY — TWO DOSES (6 to 12 months apart).\n\n"
 "STARTING AT 15 OR OLDER — THREE DOSES (at 0, 1 to 2, and 6 months).\n\n"
 "AND THE REASON IS IMMUNOLOGICAL AND ELEGANT: WARNING, THE ANTIBODY RESPONSE IS STRONGER IN "
 "YOUNGER ADOLESCENTS. A 12-year-old's body achieves with TWO doses the titre an adult needs THREE "
 "for. SO THE TWO-DOSE SCHEDULE IS NOT A COST SAVING — IT IS BASED ON REAL IMMUNE RESPONSE.\n\n"
 "This patient is 20, so he needs three doses.\n\n"
 "WARNING, AND ONE IMPORTANT EXCEPTION: THE IMMUNOCOMPROMISED (including those with HIV) RECEIVE "
 "THREE DOSES AT ANY AGE, even if they begin before 15.",
 ["پاسخ صحیح — شروع در ۱۵ سالگی یا بالاتر سه دوز می‌خواهد، و این بیمار ۲۰ ساله است.",
  "یک دوز کافی نیست؛ برنامه‌ی دو دوزی هم فقط برای شروع پیش از ۱۵ سالگی است.",
  "غلط است — سن ۲۰ سالگی دیر نیست، و نداشتن سابقه‌ی تماس جنسی بهترین وضعیت برای واکسیناسیون است.",
  "باور غلط رایج — واکسن HPV در مردان اندیکاسیون کامل دارد و از سرطان آنال و اوروفارنکس پیشگیری می‌کند."],
 ["Correct — starting at 15 or older requires three doses, and this patient is 20.",
  "One dose is not enough; the two-dose schedule applies only to initiation before age 15.",
  "Wrong — 20 is not too late, and having no sexual history is the best position for vaccination.",
  "A common misconception — the HPV vaccine is fully indicated in men and prevents anal and oropharyngeal cancer."],
 "**مرز دوزبندی، سن شروع است نه سن فعلی: پیش از ۱۵ دو دوز، از ۱۵ به بالا سه دوز.**",
 "The schedule depends on age at initiation, not current age: two doses before 15, three from 15 up.",
 [ACIPHPV, CDC2021])


# =========================================================== book:707
add("book:707", "case", "medium",
 "بیمار تازه‌تشخیص با CD4=۶۰۰ و ویرال لود ۵۰۰ ← **شروع ART**؛ درمان در هر CD4 توصیه می‌شود.",
 "A newly diagnosed patient with CD4 600 and a viral load of 500: START ART — treatment is recommended at any CD4.",
 URETH_FA[:4] + [
  "⚠️ **این سؤال یک اصل درمانی را می‌آزماید که در بیست سال گذشته کاملاً عوض شده است.**",
  "**قدیم: منتظر می‌ماندند تا CD4 به آستانه‌ای برسد و بعد درمان را شروع می‌کردند.**",
  "**امروز: درمان در هر CD4 و هر بار ویروسی و برای همه توصیه می‌شود.**",
  "**دو مطالعه این را عوض کردند: START و TEMPRANO، هر دو در سال ۲۰۱۵.**",
  "**هر دو نشان دادند شروع زودهنگام، مرگ و بیماری جدی را به‌طور معنادار کم می‌کند.**",
  "⚠️ **و دلیل دومی که کمتر گفته می‌شود: فرد با بار ویروسی سرکوب‌شده ویروس را منتقل نمی‌کند.**",
  "**این همان اصل U=U است: غیرقابل‌شناسایی یعنی غیرقابل‌انتقال.**",
  "**پس درمان، هم‌زمان یک مداخله‌ی پیشگیرانه‌ی بهداشت عمومی هم هست.**",
  "**و عدد ویرال لود در این سؤال، در استخراج دو رقم صفر از دست داده بود و تصحیح شد.**",
 ],
 URETH_EN[:4] + [
  "WARNING: THIS QUESTION TESTS A THERAPEUTIC PRINCIPLE THAT HAS CHANGED COMPLETELY IN TWENTY YEARS.",
  "THE OLD WAY: wait until the CD4 fell to a threshold, then start treatment.",
  "TODAY: treatment is recommended for everyone, at any CD4 count and any viral load.",
  "Two trials changed this: START and TEMPRANO, both in 2015.",
  "Both showed that early initiation significantly reduces death and serious illness.",
  "WARNING, AND A SECOND REASON LESS OFTEN STATED: someone with a suppressed viral load does not transmit the virus.",
  "That is the U=U principle: undetectable equals untransmittable.",
  "So treatment is simultaneously a public health preventive intervention.",
  "And this stem's viral load had lost two zeros in extraction and was repaired.",
 ],
 "**بیمار تازه‌تشخیص‌داده‌شده‌ی HIV**، با **معاینات بالینی کاملاً نرمال**، "
 "**CD4=۶۰۰** و **ویرال لود ۵۰۰ کپی در میلی‌لیتر**.\n\n"
 "⚠️ **پیش از هر چیز، یک نکته درباره‌ی همین عدد: در استخراج اولیه‌ی متن، عدد ویرال "
 "لود «۵» ثبت شده بود.** بررسی هندسه‌ی گلیف نشان داد صفحه ۲۶۱ عدد **۵۰۰** را چاپ "
 "کرده و **دو رقم صفر در استخراج افتاده بود** — و عدد تصحیح شد. **این تصحیح مهم بود، "
 "چون با «۵ کپی» بیمار عملاً بار ویروسی غیرقابل‌شناسایی داشت و گزینه‌ی نادرست "
 "بی‌جهت موجه جلوه می‌کرد.**\n\n"
 "⚠️ **پاسخ: شروع درمان ART.**\n\n"
 "**و این سؤال یک اصل درمانی را می‌آزماید که در بیست سال گذشته کاملاً وارونه شده "
 "است:**\n\n"
 "**دوره‌ی قدیم:** درمان **گران، پرعارضه و پرقرص** بود. پس منتظر می‌ماندند تا CD4 به "
 "آستانه‌ای (اول ۲۰۰، بعد ۳۵۰، بعد ۵۰۰) برسد. منطقش: «ضرر دارو را تا وقتی لازم نشده "
 "تحمیل نکنیم».\n\n"
 "⚠️ **امروز: درمان برای همه، در هر CD4 و هر بار ویروسی.**\n\n"
 "**چه چیزی این را عوض کرد؟ دو مطالعه‌ی بزرگ در ۲۰۱۵:**\n\n"
 "**START** و **TEMPRANO** — هر دو نشان دادند شروع **زودهنگام** درمان، **مرگ و "
 "بیماری جدی را به‌طور معنادار کاهش می‌دهد**، **حتی در افرادی که CD4 بالایی داشتند** "
 "— دقیقاً مثل این بیمار با CD4=۶۰۰.\n\n"
 "**و دو دلیل دیگر که تصمیم را قطعی می‌کنند:**\n\n"
 "**۱) داروهای امروزی یک قرص در روز و کم‌عارضه‌اند** — پس موازنه‌ی قدیمی «ضرر دارو "
 "در برابر سود» دیگر برقرار نیست.\n\n"
 "⚠️ **۲) و مهم‌تر: اصل U=U.** فرد تحت درمان با **بار ویروسی سرکوب‌شده، ویروس را "
 "منتقل نمی‌کند** (Undetectable = Untransmittable). **یعنی درمان، هم‌زمان یک مداخله‌ی "
 "پیشگیرانه‌ی بهداشت عمومی هم هست** — نه فقط درمان یک فرد.\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**«فعلاً نیازی به شروع ART نیست»** ❌ — ⚠️ **این پاسخ الگوریتم منسوخ است.** با CD4 "
 "برابر ۶۰۰، در دوره‌ی قدیم منتظر می‌ماندند. **امروز این تأخیر، بیمار را در معرض "
 "آسیب التهابی مزمن و خطر انتقال قرار می‌دهد.**\n\n"
 "**انجام وسترن بلات** — بیمار **از قبل تشخیص‌داده‌شده** است («مورد تازه شناخته "
 "شده»). **تست تأییدی مرحله‌ی تشخیص است، نه مرحله‌ی درمان.**\n\n"
 "**شروع کموپروفیلاکسی با کوتریموکسازول** — ⚠️ **آستانه‌ی پروفیلاکسی PCP، CD4 زیر "
 "۲۰۰ است.** این بیمار CD4=۶۰۰ دارد — **بسیار بالاتر از آستانه**. تجویز کوتریموکسازول "
 "اینجا **عارضه بدون سود** است.",
 "A NEWLY DIAGNOSED HIV PATIENT with ENTIRELY NORMAL CLINICAL EXAMINATION, CD4 600 and a VIRAL LOAD "
 "OF 500 COPIES/ML.\n\n"
 "WARNING, FIRST A NOTE ABOUT THAT VERY NUMBER: in the original extraction the viral load was "
 "recorded as '5'. Glyph geometry showed page 261 prints 500 and that TWO ZEROS HAD BEEN LOST IN "
 "EXTRACTION — the figure was repaired. THAT REPAIR MATTERED, because at '5 copies' the patient "
 "would effectively have an undetectable viral load and the wrong option would look needlessly "
 "defensible.\n\n"
 "WARNING, THE ANSWER: START ART.\n\n"
 "This question tests a therapeutic principle that has been completely inverted over twenty years:\n\n"
 "THE OLD ERA: treatment was EXPENSIVE, TOXIC AND PILL-HEAVY, so clinicians waited until the CD4 "
 "fell to a threshold (first 200, then 350, then 500). The logic: 'do not impose the drug's harm "
 "until it is needed'.\n\n"
 "WARNING, TODAY: TREATMENT FOR EVERYONE, AT ANY CD4 AND ANY VIRAL LOAD.\n\n"
 "WHAT CHANGED IT? Two large trials in 2015:\n\n"
 "START and TEMPRANO — both showed that EARLY initiation SIGNIFICANTLY REDUCES DEATH AND SERIOUS "
 "ILLNESS, EVEN IN PEOPLE WITH HIGH CD4 COUNTS — exactly like this patient at 600.\n\n"
 "AND TWO FURTHER REASONS THAT SETTLE THE DECISION:\n\n"
 "1) TODAY'S DRUGS ARE ONE TABLET A DAY WITH FEW SIDE EFFECTS — so the old trade-off of harm "
 "against benefit no longer holds.\n\n"
 "WARNING, 2) AND MORE IMPORTANTLY: THE U=U PRINCIPLE. A treated person with a SUPPRESSED VIRAL "
 "LOAD DOES NOT TRANSMIT THE VIRUS (Undetectable equals Untransmittable). SO TREATMENT IS "
 "SIMULTANEOUSLY A PUBLIC HEALTH PREVENTIVE INTERVENTION, not merely the treatment of an individual.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "'NO NEED TO START ART FOR NOW' — WARNING, THIS IS THE OBSOLETE ALGORITHM'S ANSWER. At a CD4 of "
 "600 the old era would have waited. TODAY THAT DELAY EXPOSES THE PATIENT TO CHRONIC INFLAMMATORY "
 "DAMAGE AND THE RISK OF TRANSMISSION.\n\n"
 "PERFORM A WESTERN BLOT — the patient is ALREADY DIAGNOSED ('a newly identified case'). A "
 "CONFIRMATORY TEST BELONGS TO THE DIAGNOSTIC STAGE, NOT THE TREATMENT STAGE.\n\n"
 "START CO-TRIMOXAZOLE CHEMOPROPHYLAXIS — WARNING, THE THRESHOLD FOR PCP PROPHYLAXIS IS A CD4 BELOW "
 "200. This patient's CD4 is 600 — FAR ABOVE IT. Giving co-trimoxazole here is TOXICITY WITHOUT "
 "BENEFIT.",
 ["الگوریتم منسوخ — از مطالعات START و TEMPRANO به بعد، درمان در هر CD4 توصیه می‌شود.",
  "بیمار از قبل تشخیص‌داده‌شده است؛ تست تأییدی مرحله‌ی تشخیص است، نه مرحله‌ی درمان.",
  "پاسخ صحیح — درمان در هر CD4 و هر بار ویروسی توصیه می‌شود، و اصل U=U آن را تقویت می‌کند.",
  "آستانه‌ی پروفیلاکسی PCP، CD4 زیر ۲۰۰ است؛ با CD4=۶۰۰ این کار عارضه بدون سود است."],
 ["The obsolete algorithm — since START and TEMPRANO, treatment is recommended at any CD4.",
  "The patient is already diagnosed; a confirmatory test belongs to the diagnostic stage, not treatment.",
  "Correct — treatment is recommended at any CD4 and any viral load, reinforced by the U=U principle.",
  "The PCP prophylaxis threshold is a CD4 below 200; at 600 this is toxicity without benefit."],
 "**درمان در هر CD4 — و فرد سرکوب‌شده ویروس را منتقل نمی‌کند.**",
 "Treatment at any CD4 — and a virally suppressed person does not transmit.",
 [CDC2021, H])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book40.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 40 lessons:', len(L))
