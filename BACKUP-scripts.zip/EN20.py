# -*- coding: utf-8 -*-
"""English stems and options for the parasitology and malaria chapter (batches 41-45).

Rule 16 checked first, as always: these 81 items come from sittings 93 to 98,
for which the ministry published no English booklet, so these are hand-written
translations rather than official ones.

TRANSLATION DECISIONS WORTH RECORDING
--------------------------------------
DRUG NAMES are given in their standard international spellings (metronidazole,
iodoquinol, paromomycin, tinidazole, praziquantel, triclabendazole), because
the Persian source transliterates them and several are misspelled in the
printed booklet ("تی‌تیدازول" for tinidazole, "آمودیاکسن" for amodiaquine,
"پروووانیل" for proguanil). A transliteration error in the SOURCE's own Latin
text is a typographic slip rather than content, and reproducing it would only
confuse an English reader. The Persian side keeps the printed form.

IRANIAN PLACE NAMES are transliterated and, where the extraction has clipped
them, restored: the source's "ابهار" in these malaria vignettes is CHABAHAR
(چابهار) in the malarious south-east, not Abhar in Zanjan province. The English
writes Chabahar, and the lessons explain the reasoning. Iranshahr, Saravan,
Nikshahr, Zahedan and Bandar Abbas are transliterated directly.

THE MORPHOLOGICAL TERMS are load-bearing throughout the malaria block and are
translated literally every time: BANANA-SHAPED gametocyte, SCHUFFNER'S DOTS,
RING FORM, DOUBLE-CHROMATIN ring, SCHIZONT, RHABDITIFORM larva, LEMON-SHAPED
egg, WATER-LILY sign. Each of these single terms decides its question, and
softening any of them would destroy it.

THE SEVERITY NUMBERS are preserved exactly (haematocrit below 15, pH 7.1,
pH 7.35 with bicarbonate 17, leucopenia 3500 and 3000, platelets 66000 and
75000, haemoglobin 6.4, temperature 41) because every one of them sits
deliberately either on or just off a WHO threshold, and that placement is the
whole content of those questions.

PROPHYLAXIS TIMINGS keep their exact intervals (1 to 2 days before, 7 days
after, 4 weeks after) for the same reason.
"""

EN20 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    assert all(o.strip() for o in options), idx
    EN20[idx] = {"stem_en": stem, "options_en": options}


# ============================================================ AMOEBA
add(728,
    "Which of the following diagnostic methods is useful in distinguishing an amoebic liver abscess "
    "from a pyogenic liver abscess?",
    ["Stool smears",
     "Liver ultrasound",
     "Contrast MRI of the liver",
     "Amoebic serology"])

add(729,
    "In investigating the cause of bloody diarrhoea in a 35-year-old woman who has presented to you, "
    "trophozoites of Entamoeba histolytica are reported. Which of the following antibiotics is "
    "recommended in treatment?",
    ["Metronidazole",
     "Ciprofloxacin",
     "Cefixime",
     "Co-trimoxazole"])

add(731,
    "A 60-year-old man has developed fever and dysentery after eating contaminated food. Stool "
    "examination shows, in addition to numerous white and red cells, trophozoites of Entamoeba "
    "histolytica. What is the most appropriate treatment?",
    ["Metronidazole plus iodoquinol",
     "Ciprofloxacin plus paromomycin",
     "Tinidazole plus spectinomycin",
     "Symptomatic treatment and oral rehydration"])

add(732,
    "In the stool examination of a young mountaineer who has had bloody diarrhoea for 2 days, "
    "trophozoites containing ingested red blood cells are seen. Which treatment regimen is most "
    "appropriate for him?",
    ["Doxycycline 300 mg as a single dose",
     "Metronidazole plus ciprofloxacin",
     "Metronidazole plus iodoquinol",
     "Tinidazole plus doxycycline"])

add(733,
    "A 30-year-old man presents with right upper quadrant pain accompanied by fever and anorexia for "
    "3 days. On examination there is mild tenderness in that region, and the laboratory shows "
    "leucocytosis with a raised alkaline phosphatase. The requested abdominal ultrasound reports a "
    "solitary round lesion 3 cm in diameter in the right lobe of the liver. Suspecting an amoebic "
    "liver abscess, which treatment do you consider appropriate?",
    ["Metronidazole for 3 days plus praziquantel for 20 days",
     "Surgical drainage of the abscess plus metronidazole for 10 days",
     "Tinidazole for 10 days plus ultrasound-guided drainage of the abscess",
     "Tinidazole for 3 days plus paromomycin for 10 days"])

add(734,
    "A 35-year-old man presents with bloody diarrhoea. Stool examination shows cysts and trophozoites "
    "of amoeba. Which treatment would you recommend for him?",
    ["Metronidazole plus iodoquinol for 10 days",
     "Tinidazole for 3 days plus paromomycin for 10 days",
     "Metronidazole plus paromomycin for 5 days",
     "Tinidazole plus iodoquinol for 10 days"])

add(735,
    "A 42-year-old man is being treated with oral prednisolone for pemphigus. Stool examination "
    "reports cysts of Entamoeba histolytica. The patient has no gastrointestinal symptoms. Which of "
    "the following would you recommend?",
    ["Treatment with paromomycin 500 mg three times daily for seven days",
     "Repeat the stool examination in one month and, if positive, treat with iodoquinol for ten days",
     "Treat with metronidazole for ten days if diarrhoea develops",
     "Since the patient is asymptomatic, we simply observe him for now"])

add(737,
    "A young man who works in a kitchen, with no gastrointestinal symptoms, has presented because "
    "cysts of Entamoeba histolytica were identified in his stool. Apart from the amoebic cysts, the "
    "stool examination showed no other positive finding. What is the appropriate action for him?",
    ["No particular action is needed",
     "A stool culture should be performed",
     "Iodoquinol should be prescribed",
     "Metronidazole plus iodoquinol should be prescribed"])

add(738,
    "A kitchen worker with no symptoms undergoes the tests required for a health certificate. His "
    "stool examination reports cysts of Entamoeba histolytica. Which of the following drugs should be "
    "prescribed?",
    ["Paromomycin plus tinidazole",
     "Metronidazole",
     "Iodoquinol plus metronidazole",
     "Iodoquinol"])

# ============================================================ GIARDIA
add(742,
    "A 19-year-old man with a history of common variable immunodeficiency has been investigated for "
    "abdominal pain, steatorrhoea and bloating. Because numerous trophozoites were seen in his stool "
    "he has been treated on several occasions. Despite appropriate treatment, both his clinical "
    "features and his stool samples remain positive for giardia. Which is the recommended treatment "
    "for him?",
    ["Albendazole 400 mg daily for 14 days",
     "Tinidazole 500 mg every 12 hours for 10 days",
     "Metronidazole 750 mg every 8 hours for 21 days",
     "Ivermectin 200 micrograms/kg every 12 hours for 4 days"])

# ============================================================ LEISHMANIA
add(743,
    "Which of the following is NOT a cause of cutaneous leishmaniasis (oriental sore)?",
    ["Leishmania tropica",
     "Leishmania major",
     "Leishmania aethiopica",
     "Leishmania infantum"])

add(744,
    "In the diagnosis of visceral leishmaniasis, which of the following has the higher sensitivity?",
    ["Bone marrow biopsy smear",
     "Splenic biopsy smear",
     "Liver biopsy smear",
     "Lymph node biopsy smear"])

# ============================================================ TOXOPLASMOSIS
add(745,
    "An eight-year-old patient presents with blurred vision. Ophthalmoscopy shows white plaques with "
    "well-defined edges and black spots in the retina, and a diagnosis of chorioretinitis is made. "
    "The patient's mother states that during her pregnancy she had a month of fever and cervical "
    "lymph node swelling which resolved without treatment. What is the most likely causative agent?",
    ["Toxoplasma gondii",
     "Cytomegalovirus",
     "Epstein-Barr virus",
     "Varicella zoster virus"])

add(747,
    "A young woman presents with multiple painless enlarged lymph nodes in the posterior cervical "
    "triangle, which she noticed incidentally. She has no medical history and takes no medication, "
    "and she is not pregnant. Her investigations report positive anti-toxoplasma IgG and IgM. Which "
    "action do you consider appropriate?",
    ["Treat and investigate for an underlying immunodeficiency",
     "Serological follow-up for up to 6 months",
     "No particular action is needed",
     "Brain imaging and testing for HIV"])

add(748,
    "In a 24-year-old woman, pre-pregnancy toxoplasma serology is as follows: anti-Toxoplasma IgG "
    "positive and anti-Toxoplasma IgM negative. Which of the following is correct?",
    ["Repeat toxoplasma serology in every trimester is recommended",
     "Amniotic fluid PCR is recommended at 18 weeks of pregnancy",
     "Starting spiramycin treatment for the mother is recommended",
     "We reassure the mother that this disease poses no threat to the fetus"])

add(749,
    "A young woman presents at 12 weeks of pregnancy. Her tests show positive anti-toxoplasma IgG but "
    "negative IgM. Review of her medical record shows that in her previous pregnancy, 5 years ago, "
    "she also had positive IgG and negative IgM. What clinical approach do you recommend for her at "
    "present?",
    ["Start treatment with spiramycin",
     "Start treatment with pyrimethamine plus sulfadiazine plus folinic acid",
     "Repeat the blood test in 4 weeks",
     "No further action is required"])

add(751,
    "A 35-year-old man with no particular medical history presents with swelling of the "
    "post-auricular lymph nodes accompanied by mild pain. His investigations report a positive "
    "anti-toxoplasma IgM. What is the appropriate action?",
    ["Start pyrimethamine plus sulfadiazine immediately",
     "Start pyrimethamine plus clindamycin immediately",
     "Start pyrimethamine plus sulfadiazine plus prednisolone immediately",
     "Follow the patient only"])

add(752,
    "An adolescent presents with enlarged cervical lymph nodes. The nodes are discrete, non-tender "
    "and slightly firm. The serological results are consistent with acute toxoplasmosis. What is the "
    "most appropriate action?",
    ["A steroid plus lymph node biopsy",
     "Pyrimethamine plus sulfadiazine",
     "Pyrimethamine plus clindamycin plus a steroid",
     "Clinical follow-up without any need for treatment"])

add(753,
    "A woman two months pregnant presents with cervical lymphadenopathy. Serology shows positive "
    "toxoplasma IgG and IgM. Which statement about fetal toxoplasma infection is correct?",
    ["Treating the pregnant mother with spiramycin reduces transmission of toxoplasma across the placenta",
     "If the fetus is infected, anti-toxoplasma treatment of the newborn after birth is useless",
     "Fetal infection is more common in the first trimester",
     "Disease severity in the child is milder after first-trimester infection"])

add(754,
    "All of the following cases of toxoplasmosis require specific treatment EXCEPT",
    ["Toxoplasmic encephalitis in a person with AIDS",
     "Ocular toxoplasmosis",
     "Acute cervical lymphadenopathy in an immunocompetent 17-year-old",
     "Congenital toxoplasmosis in an infant born to a mother who had acute toxoplasmosis in the first trimester"])

add(755,
    "A pregnant woman develops cervical lymphadenopathy at 28 weeks of pregnancy. Investigations "
    "report a positive toxoplasma IgM antibody. On pre-pregnancy screening her toxoplasma test was "
    "negative. What is your recommendation for her?",
    ["Give spiramycin until the end of pregnancy",
     "Give sulfadiazine plus pyrimethamine",
     "Recommend termination of the pregnancy",
     "No treatment is required"])

add(756,
    "An HIV-positive patient has been treated for a diagnosis of toxoplasmosis. After completing "
    "treatment, sulfadiazine plus pyrimethamine is prescribed alongside antiretroviral therapy to "
    "prevent recurrence. What is the most appropriate duration for toxoplasmosis prophylaxis?",
    ["For more than 3 months after the CD4 count exceeds 200",
     "For more than 2 months after the CD4 count exceeds 100",
     "For up to 12 months after the CD4 count exceeds 200",
     "For life, regardless of the CD4 count"])

add(757,
    "A young woman presents to you for pre-conception counselling. Two months ago, during a work-up "
    "for cervical lymph node enlargement, she was given a diagnosis of toxoplasma lymphadenitis. The "
    "tests she has brought, which date from 2 months ago, report positive anti-toxoplasma IgG and "
    "IgM. What do you advise her?",
    ["Start treatment with pyrimethamine and sulfadiazine",
     "Repeat serial serological testing until the anti-toxoplasma IgM becomes negative",
     "No treatment is needed, and delay pregnancy for another 4 months",
     "Start treatment with spiramycin and repeat the anti-toxoplasma IgM"])

add(758,
    "A 30-year-old woman presents with cervical adenopathy of one week's duration. The patient has no "
    "clinical symptoms at all. Her anti-toxoplasma antibody tests report both IgM and IgG positive. "
    "What is your advice to the patient?",
    ["No treatment, and no pregnancy for six months",
     "No treatment, and no pregnancy for three months",
     "Treat the toxoplasmosis, and no pregnancy for six months",
     "Treat the toxoplasmosis, and no pregnancy for three months"])

add(759,
    "A woman at 14 weeks of pregnancy has been referred from a reference laboratory with positive "
    "toxoplasmosis IgM and IgG. Ultrasound shows evidence of fetal involvement. In your opinion, "
    "which of the following actions is correct?",
    ["We wait until 18 weeks of pregnancy and then, after amniocentesis, start treatment based on the PCR result",
     "Treatment with pyrimethamine and sulfadiazine together with folinic acid",
     "Treatment with spiramycin, with amniocentesis and PCR at 18 weeks of pregnancy, continuing treatment according to the result",
     "Treatment with spiramycin until the end of the pregnancy"])

# ============================================================ MALARIA: DIAGNOSIS
add(760,
    "A young man presents to you with fever and severe rigors. The patient states that for 4 days he "
    "has had attacks of rigor, fever and sweating. On examination, in addition to fever, pale "
    "conjunctivae and splenomegaly are also evident. The patient reports no underlying condition. He "
    "travelled to Bandar Abbas about 3 weeks ago. Which of the following is the most likely diagnosis "
    "for this patient?",
    ["Kala-azar",
     "Malaria",
     "Relapsing fever",
     "Endocarditis"])

add(763,
    "Which of the following is NOT a feature of severe falciparum malaria?",
    ["Renal dysfunction",
     "Pulmonary oedema",
     "Hyperglycaemia",
     "Acidosis"])

add(764,
    "A young engineer developed fever and shaking chills 10 days after returning from Chabahar. On "
    "examination he has anaemia and mild splenomegaly. The peripheral blood smear shows ring forms "
    "inside the red cells and banana-shaped gametocytes. Which plasmodium is the causative agent?",
    ["Plasmodium falciparum",
     "Plasmodium malariae",
     "Plasmodium vivax",
     "Plasmodium ovale"])

add(766,
    "A 30-year-old Afghan man presents with fever and chills. His investigations show anaemia and "
    "thrombocytopenia. The peripheral blood film shows a banana-shaped gametocyte within a red cell. "
    "Which type of malaria should be considered for him?",
    ["Plasmodium malariae",
     "Plasmodium vivax",
     "Plasmodium falciparum",
     "Plasmodium ovale"])

add(768,
    "A 25-year-old traveller developed severe falciparum malaria two weeks after returning from a "
    "trip to Africa. Which of the following does NOT indicate a poor prognosis in this patient?",
    ["Repeated seizures",
     "Severe anaemia (haematocrit below 15)",
     "Severe metabolic acidosis (pH 7.1 or below)",
     "Leucopenia of 3500"])

add(769,
    "A 20-year-old tourist became febrile with rigors, jaundice and malaise 2 weeks after returning "
    "from a trip to Africa; the peripheral blood film reported plasmodium in large numbers. In your "
    "opinion, which of the following indicates a poor prognosis in this patient?",
    ["Leucopenia of 3000",
     "Thrombocytopenia of 66,000",
     "Liver enzymes (AST and ALT) at five times normal or above",
     "A blood pH of 7.35 with a bicarbonate of 17 mmol/L"])

add(770,
    "A young woman in the eighth month of pregnancy develops fever, headache and a seizure three "
    "weeks after travelling to the city of Chabahar. On examination the patient is confused and "
    "lethargic with a temperature of 41 degrees Celsius; her tests show a haemoglobin of 6.4 g/dL and "
    "a platelet count of 75,000 per microlitre. What is the first and most important diagnostic step, "
    "and the most likely diagnosis?",
    ["Thick peripheral blood smear; falciparum malaria",
     "CSF analysis; acute bacterial meningitis",
     "Thin peripheral blood smear; vivax malaria",
     "Blood culture; meningococcal sepsis syndrome"])

add(771,
    "A 42-year-old Afghan man who migrated to Iran from his country one week ago has been admitted "
    "with high fever, body aches, headache and diarrhoea. His tests show a low platelet count, "
    "metabolic acidosis, a raised creatinine and severe anaemia. Which of the following would you "
    "choose to reach the diagnosis?",
    ["Thick and thin peripheral blood smears",
     "Bone marrow aspiration and biopsy",
     "Blood culture and urine culture",
     "Bone marrow smear and culture"])

add(772,
    "A 40-year-old lorry driver developed fever and chills, headache, nausea and vomiting one week "
    "after returning from Zahedan. On examination his temperature is 40 degrees Celsius, his pulse is "
    "120, and the spleen is palpable. Blood tests show leucopenia and thrombocytopenia. What is the "
    "most appropriate diagnostic step?",
    ["Blood culture and a Wright test",
     "Peripheral blood film and a Widal test",
     "Peripheral blood film and blood culture",
     "Blood culture and a Widal test"])

add(773,
    "A patient develops a fever of 40 degrees Celsius with rigors, myalgia, severe headache and a "
    "seizure after returning from Iranshahr. The patient is anaemic and has no signs of meningeal "
    "irritation. The initial peripheral blood smear is reported negative. Which diagnostic step is "
    "helpful?",
    ["Obtaining cerebrospinal fluid",
     "Repeating the blood smear",
     "Brain CT scan",
     "Blood culture"])

add(774,
    "A young man doing his military service in Iranshahr presents with fever and shaking chills. The "
    "symptoms began 3 days ago and are accompanied by anaemia and a mild fall in the platelet count. "
    "Suspecting malaria you requested thick and thin peripheral blood films, which were reported "
    "negative. If you remain strongly suspicious of malaria on clinical grounds, which action do you "
    "consider appropriate?",
    ["Repeat the peripheral blood film every 12 to 24 hours for 3 days",
     "Given the negative thick and thin films, malaria seems unlikely",
     "Empirical treatment for malaria with clinical follow-up",
     "Repeat the peripheral blood film every 2 hours for 12 hours"])

# ============================================================ MALARIA: TREATMENT
add(775,
    "In the treatment of which of the following plasmodia is treatment of the hypnozoite form also "
    "necessary?",
    ["Plasmodium ovale",
     "Plasmodium knowlesi",
     "Plasmodium malariae",
     "Plasmodium falciparum"])

add(776,
    "A laboratory technician has contracted vivax malaria following a needlestick injury. Which of "
    "the following treatments would you recommend?",
    ["Chloroquine followed by primaquine",
     "Amodiaquine followed by primaquine",
     "Chloroquine",
     "Chloroquine plus artesunate"])

add(778,
    "A 45-year-old man presents with several days of fever and chills following a blood transfusion "
    "in a malarious region. The peripheral blood smear shows enlarged red cells containing large "
    "trophozoites and Schuffner's dots. If drug-resistant malaria is not common in this region, what "
    "is your suggestion for appropriate treatment?",
    ["Chloroquine plus primaquine",
     "Chloroquine alone",
     "Mefloquine plus primaquine",
     "Primaquine alone"])

add(779,
    "A young man presents with fever, chills and sweating for one week after returning from Nikshahr "
    "in Baluchestan. On investigation, the peripheral blood smear shows parasitised erythrocytes and "
    "yellow-brown Schuffner's dots. Given the characteristics of the parasite, what is the most "
    "appropriate treatment choice?",
    ["Mefloquine",
     "Artesunate",
     "Chloroquine",
     "Quinine"])

add(780,
    "A pregnant woman has developed intermittent fever and chills after returning from India, and "
    "vivax malaria has been confirmed for her. What regimen do you suggest for the patient?",
    ["Chloroquine for three days, continued weekly until the end of the pregnancy",
     "Artesunate for three days, then primaquine weekly until the end of the pregnancy",
     "Chloroquine for three days, then primaquine for 14 days",
     "Atovaquone-proguanil for three days, then weekly until the end of the pregnancy"])

add(781,
    "A member of the laboratory staff sustains a needlestick injury while taking blood from a patient "
    "with vivax malaria, and after 3 days her clinical and laboratory findings become positive for "
    "malaria. Standard treatment with chloroquine is started. If this member of staff is pregnant and "
    "her G6PD enzyme activity is normal, what is the correct way to use primaquine for her?",
    ["Start primaquine after delivery",
     "Treatment with chloroquine alone is sufficient",
     "Three tablets a week for 8 weeks",
     "One tablet daily for two weeks"])

add(782,
    "A patient presents with fever, chills and headache following travel to south-eastern Iran. "
    "Examination of the peripheral blood film shows single-chromatin parasites and schizonts. What is "
    "the treatment of choice?",
    ["Chloroquine phosphate",
     "Chloroquine phosphate plus primaquine",
     "Chloroquine phosphate plus Fansidar",
     "Mefloquine"])

add(783,
    "An 18-year-old patient developed fever, chills, sweating and headache one week after returning "
    "from Saravan. The peripheral blood film reports Plasmodium falciparum. What is the most "
    "appropriate treatment?",
    ["Chloroquine",
     "Proguanil plus atovaquone",
     "Amodiaquine",
     "Artesunate"])

add(784,
    "A patient has been admitted with fever, chills and a reduced level of consciousness, and reports "
    "a history of cardiac disease and arrhythmia. The peripheral blood film shows double-chromatin "
    "plasmodium rings. Which of the following is the best recommended drug for treating this patient?",
    ["Halofantrine",
     "Artesunate",
     "Quinidine",
     "Chloroquine"])

add(785,
    "A person develops fever and chills following travel to southern Iran. Banana-shaped gametocytes "
    "are seen on the peripheral blood film, and the patient has no features of severe malaria. What "
    "is the first-line treatment for him?",
    ["Artesunate plus Fansidar",
     "Quinine plus clindamycin",
     "Chloroquine plus primaquine",
     "Proguanil plus primaquine"])

add(786,
    "A 48-year-old patient from Iranshahr is admitted complaining of fever, shaking chills, profuse "
    "sweating and headache. General and biochemical tests are within normal limits. The vital signs "
    "are stable. However, the patient reports severe weakness and body aches. The stained peripheral "
    "blood film shows abnormal forms within the red cells and several banana-shaped gametocytes. "
    "Which of the following treatment regimens do you consider the treatment of choice for this "
    "patient?",
    ["Atovaquone-proguanil plus clindamycin",
     "Artesunate plus mefloquine",
     "Halofantrine plus doxycycline",
     "Quinine plus amodiaquine"])

add(788,
    "A young Afghan man has developed severe fever and chills with a reduced level of consciousness "
    "following migration to Iran across the Pakistan border. On examination his blood pressure is "
    "80/60, pulse 120, respiratory rate 35 and temperature 38 degrees Celsius. The peripheral blood "
    "film reports falciparum malaria. What is the first therapeutic step?",
    ["Quinine",
     "Artesunate",
     "Mefloquine",
     "Chloroquine"])

# ============================================================ MALARIA: PROPHYLAXIS
add(792,
    "A family consults you about travelling to the south of the country and to Chabahar, for malaria "
    "prevention. For the pregnant woman in this family, which of the following drugs would you "
    "recommend?",
    ["Mefloquine",
     "Chloroquine",
     "Doxycycline",
     "Primaquine"])

add(793,
    "A woman five months pregnant intends to travel to a malarious region with high chloroquine "
    "resistance. Which of the following drugs is recommended for malaria prophylaxis?",
    ["Malarone (atovaquone-proguanil)",
     "Mefloquine",
     "Chloroquine",
     "Doxycycline"])

add(794,
    "A 28-year-old man presents to you before travelling to a malarious area. Which of the following "
    "drugs is better for prophylaxis?",
    ["Mefloquine",
     "Chloroquine",
     "Dapsone",
     "Primaquine"])

add(795,
    "Which of the following is correct regarding the prevention of malaria when travelling to "
    "malarious areas?",
    ["Atovaquone-proguanil for areas where chloroquine resistance exists, from 1 to 2 days before "
     "travel until 7 days after leaving the area",
     "Mefloquine for areas where chloroquine resistance exists, from 1 to 2 days before travel until "
     "4 weeks after leaving the area",
     "Doxycycline for areas where chloroquine resistance exists, from 1 to 2 days before travel until "
     "4 weeks after leaving the area",
     "All of the above"])

add(796,
    "A pregnant woman who is an environmental researcher intends to travel for a research project to "
    "a region of Africa where resistant malaria is common. What do you recommend regarding malaria "
    "prophylaxis?",
    ["Taking chloroquine tablets",
     "Taking quinine tablets",
     "Taking proguanil tablets",
     "Taking mefloquine tablets"])

add(797,
    "Which of the following methods is NOT used for the prevention of malaria?",
    ["Using doxycycline during travel to endemic areas",
     "Using an insect repellent ointment",
     "Vaccination one month before travel",
     "Using mefloquine"])

# ============================================================ PINWORM
add(798,
    "A young child has developed perianal itching that worsens at night. What is the best diagnostic "
    "step?",
    ["A single stool smear",
     "Stool smears on three occasions",
     "Stool smear and culture",
     "The cellophane tape test of the perianal region"])

add(800,
    "For a child who has perianal itching at night, which of the following is LEAST helpful?",
    ["Treating the other, asymptomatic members of the family",
     "Treating the patient with mebendazole",
     "Repeating the previous treatment 2 weeks later",
     "Direct stool examination for parasites"])

add(801,
    "A six-year-old boy has been referred to you complaining of perianal itching that worsens at "
    "night. Given the most likely diagnosis, what is the appropriate action?",
    ["Treat the patient with mebendazole 100 mg daily for two weeks",
     "Treat the patient with mebendazole 100 mg as a single dose and repeat the treatment two weeks later",
     "Treat the patient and his family with mebendazole 100 mg daily for two weeks",
     "Treat the patient and his family with mebendazole 100 mg as a single dose and repeat the "
     "treatment two weeks later"])

add(804,
    "A 5-year-old child has perianal itching at night. What is the most appropriate action?",
    ["Mebendazole for the child, and treatment of the family if symptomatic",
     "Albendazole for the child and the family members, with the drug repeated 2 weeks later",
     "Stool examination for parasites and ova, and an antipruritic for the child",
     "Stool smear and culture, and starting pyrantel pamoate for the child"])

add(805,
    "In the cellophane tape test of the perineal region of a 13-year-old adolescent complaining of "
    "nocturnal perianal itching, an oval nematode egg about 25 micrometres in size is seen. Which "
    "treatment recommendation is most appropriate?",
    ["Albendazole 400 mg for one week for the patient and his family",
     "Mebendazole 100 mg as a single dose for the patient",
     "Albendazole 400 mg as a single dose for the patient and his family, with the treatment repeated "
     "2 weeks later",
     "Mebendazole 100 mg for 3 days for the patient and his family"])

add(806,
    "A 7-year-old child has been brought to you because of perianal itching. According to his mother "
    "the itching is worse at night. Examination shows no particular finding. The stool examination "
    "was normal, and the causative agent was identified using cellulose acetate tape applied to the "
    "perianal region. All of the following statements about this disease are correct EXCEPT",
    ["Screening every member of the family for the disease",
     "Giving one dose of mebendazole",
     "Repeating the mebendazole 2 weeks later",
     "Treating the other members of the family"])

# ============================================================ WHIPWORM AND HOOKWORM
add(799,
    "Pulmonary migration is absent from the development of which worm?",
    ["Ascaris",
     "Strongyloides",
     "Necator americanus",
     "Whipworm (Trichuris)"])

add(803,
    "A 4-year-old child suffering from chronic protein-calorie malnutrition is admitted with severe "
    "bloody diarrhoea, abdominal pain and rectal prolapse. The stool examination reports a "
    "lemon-shaped parasite egg. Which of the following treatments would you recommend?",
    ["Mebendazole 500 mg as a single day's treatment",
     "Albendazole 400 mg as a single dose",
     "Ivermectin 200 micrograms/kg as a single dose",
     "Nitazoxanide 500 mg as a single dose"])

add(817,
    "Rectal prolapse in children is a complication of which of the following worms?",
    ["Trichuris trichiura",
     "Strongyloides stercoralis",
     "Ancylostoma duodenale",
     "Trichinellosis"])

add(818,
    "Iron-deficiency anaemia is a feature of heavy infection with which intestinal worm?",
    ["Ascaris",
     "Whipworm (Trichuris)",
     "Hookworm",
     "Taenia solium"])

add(819,
    "Microcytic hypochromic anaemia together with hypoalbuminaemia and eosinophilia is seen in "
    "infection with which intestinal worm?",
    ["Ascaris",
     "Hookworm",
     "Strongyloides",
     "Whipworm (Trichuris)"])

# ============================================================ ASCARIS
add(802,
    "A patient presents complaining of having passed a thin, round, pink worm approximately 40 cm "
    "long. Which treatment would you recommend for this patient's infection?",
    ["Metronidazole",
     "Praziquantel",
     "Mebendazole",
     "Niclosamide"])

add(808,
    "A 23-year-old woman in the third month of pregnancy presents with abdominal pain, nausea and "
    "anorexia. Microscopic examination of her stool shows ascaris eggs. Which treatment do you "
    "consider appropriate for her?",
    ["Albendazole 400 mg as a single dose",
     "Pyrantel pamoate 1 g as a single dose",
     "Albendazole 400 mg for 3 days",
     "Ivermectin 10 g as a single dose"])

add(809,
    "In the stool examination of a woman in the sixth month of pregnancy who presented with "
    "urticarial lesions, cough and abdominal pain, ascaris has been reported. Which action is "
    "appropriate given her circumstances?",
    ["Prescribing mebendazole",
     "Prescribing ivermectin",
     "Postponing treatment until the end of the pregnancy",
     "Prescribing pyrantel pamoate"])

add(810,
    "A patient presents with abdominal pain that worsens with eating; the stool examination reported "
    "rhabditiform larvae. What is the most appropriate treatment?",
    ["Omeprazole",
     "Ivermectin",
     "Mebendazole",
     "Pyrantel pamoate"])

add(811,
    "A 25-year-old man in a tropical African region has been brought to the emergency department with "
    "vomiting, abdominal pain and no passage of stool for the past 24 hours. Imaging identifies the "
    "cause of the obstruction as 20 cm tubular worms. Given the probable diagnosis, which of the "
    "following drugs would you give the patient through a nasogastric tube?",
    ["Albendazole 400 mg tablets",
     "Five mebendazole tablets given together",
     "Piperazine citrate syrup",
     "Pyrantel pamoate syrup"])

add(812,
    "A patient has developed partial bowel obstruction following ascaris infection. What is the "
    "appropriate therapeutic action?",
    ["Giving mebendazole through a nasogastric tube together with surgery",
     "Giving piperazine through a nasogastric tube together with intravenous fluids",
     "Giving mebendazole through a nasogastric tube together with intravenous fluids",
     "Giving albendazole through a nasogastric tube together with surgery"])

add(813,
    "Which of the following is a complication of infection with Ascaris?",
    ["Bowel perforation",
     "Cholangitis",
     "Pancreatitis",
     "All of the above"])

# ============================================================ STRONGYLOIDES
add(815,
    "A patient has developed sepsis after receiving a high dose of prednisolone for the treatment of "
    "pemphigus, and the blood culture has grown a gram-negative bacillus. Given a history of "
    "intermittent eosinophilia, urticaria over the buttocks and epigastric pain, and despite a stool "
    "examination negative for parasite ova and larvae, what is the most likely causative agent?",
    ["Ascaris lumbricoides",
     "Enterobius vermicularis",
     "Trichuris trichiura",
     "Strongyloides stercoralis"])

add(816,
    "Which of the following intestinal worms causes disseminated systemic infection in "
    "immunocompromised people and is fatal?",
    ["Ascaris",
     "Strongyloidiasis",
     "Trichostrongyliasis",
     "Anisakiasis"])

# ============================================================ CESTODES AND TREMATODES
add(820,
    "For the treatment of hepatic hydatid cyst, the PAIR method (Puncture, Aspiration, Infusion of "
    "scolicidal agents, Reaspiration) instead of surgery is NOT used in which of the following?",
    ["Superficial cysts",
     "Honeycomb cysts",
     "Cysts that communicate with the biliary system",
     "All of the above"])

add(821,
    "A patient from a rural area who is a candidate for gallbladder surgery has had a chest "
    "radiograph, which reports a large cystic lesion in the lung with an air-fluid level and a "
    "water-lily sign. In your opinion, by which route did this patient become infected?",
    ["Eating contaminated meat",
     "Inhaling contaminated dust",
     "Walking barefoot on contaminated soil",
     "Eating contaminated vegetables"])

add(822,
    "A patient presents complaining of chronic abdominal pain together with weakness and lethargy. "
    "The tests performed are as follows: WBC 7500 (PMN 65%, lymphocytes 25%, eosinophils 10%), stool "
    "examination WBC and RBC nil, Taenia saginata eggs positive. Which drug would you recommend for "
    "this patient?",
    ["Praziquantel",
     "Albendazole",
     "Triclabendazole",
     "Ivermectin"])

add(824,
    "Cerebral involvement is a manifestation of infection with which worm?",
    ["Ascaris",
     "Taenia solium",
     "Whipworm (Trichuris)",
     "Hookworm"])

add(825,
    "A patient develops fever and abdominal pain several weeks after returning from the north of the "
    "country, and states that during the trip he ate large amounts of raw vegetables. Examination "
    "shows hepatomegaly, and the tests show marked eosinophilia. Abdominal CT has shown tunnels made "
    "by migrating larvae. What is the best diagnosis?",
    ["Strongyloides stercoralis",
     "Leptospira",
     "Fasciola hepatica",
     "Toxocara"])

add(826,
    "Which of the following Schistosoma species causes urinary tract disease?",
    ["Schistosoma haematobium",
     "Schistosoma japonicum",
     "Schistosoma mansoni",
     "Schistosoma mekongi"])

add(827,
    "A 30-year-old woman from a northern province has been under investigation for one week for "
    "fever, abdominal pain, anorexia and a weight loss of about 5 kg. On examination she has "
    "urticarial lesions, and she also complains of a dry cough. Her tests show a leucocytosis of "
    "30,000 with 45% eosinophils. Abdominal CT shows multiple hypodense hepatic lesions. What is the "
    "most appropriate treatment for her?",
    ["Albendazole",
     "Ivermectin",
     "Pyrantel pamoate",
     "Triclabendazole"])
