# -*- coding: utf-8 -*-
"""One printed key in the HIV cluster that cannot stand: q9662.

The conservative rule, unchanged: the printed key is presumed right and is
overruled only when a PRIMARY source says plainly that it is wrong AND the
argument survives being written out for a student.

------------------------------------------------------------------ q9662
"All of the following match the clinical features of CATEGORY C of HIV
infection, EXCEPT:"

   (A) cerebral toxoplasmosis
   (B) Pneumocystis jirovecii pneumonia
   (C) pulmonary tuberculosis
   (D) persistent generalised lymphadenopathy
Printed key: (A) cerebral toxoplasmosis.

WHY THE KEY CANNOT STAND
-------------------------
This question has a single, published, verifiable answer, because clinical
categories A, B and C are not a matter of clinical judgement — they are an
explicit LIST in the CDC 1993 revised classification system (MMWR 1992;41
(RR-17)), reprinted verbatim in the 2008 revision (MMWR 2008;57(RR-10)).

  CATEGORY A is defined as, and only as: asymptomatic HIV infection,
  PERSISTENT GENERALIZED LYMPHADENOPATHY, and acute (primary) HIV infection.

  CATEGORY C is the AIDS surveillance case definition list, and it contains
  by name: "Toxoplasmosis of brain", "Pneumocystis carinii pneumonia", and
  "Mycobacterium tuberculosis, ANY SITE (pulmonary or extrapulmonary)".

So three of the four options — including the option the book keyed — are
category C, and the ONE that is not is (D), persistent generalised
lymphadenopathy, which is the textbook example of category A.

The likely origin of the error is the 1987 definition, in which pulmonary
tuberculosis was NOT AIDS-defining; it was added, together with recurrent
pneumonia and invasive cervical cancer, in the 1993 expansion. Someone
carrying the pre-1993 list in mind would look for the exception among the
respiratory entries and might mis-key. But even on the 1987 list, cerebral
toxoplasmosis was category C, so the printed key is wrong under either
edition, and PGL is the exception under both.

  Correction: A -> D (persistent generalised lymphadenopathy).

WHY THIS CORRECTION IS WORTH MAKING RATHER THAN FLAGGING
---------------------------------------------------------
Elsewhere in this bank a disputed key is FLAGGED rather than corrected — the
endocarditis clindamycin item, the gonorrhoea dose, the Western blot — because
in those the book followed the guidance of its own era and a later guideline
moved. This is not that. Nothing moved here: PGL has been category A since
1993 and cerebral toxoplasmosis has been category C since 1987. The key is
simply the wrong letter, and teaching it would leave a student with an
inverted rule.

Options are matched by TEXT rather than by index, so a reordering of the
payload can never silently redirect the correction at a different answer.
"""
import io
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))

CORRECTIONS = {
    9662: {
        # the option naming persistent generalised lymphadenopathy
        'match': lambda t: 'لنفادنوپاتی' in t and ('جنرالیزه' in t or 'ژنرالیزه' in t),
        'expect_from': lambda t: 'توکسوپلاسموز' in t,
        'fa': ('کلید چاپی گزینه‌ی «توکسوپلاسموز مغزی» را به‌عنوان استثنا انتخاب کرده '
               'است، ولی این گزینه **خودش کاملاً در گروه C** جای دارد و کلید **تصحیح** شد.\n\n'
               '**چرا این سؤال یک پاسخ قطعی و قابل استناد دارد؟** چون گروه‌های بالینی '
               'A و B و C موضوع سلیقه‌ی بالینی نیستند؛ یک **فهرست صریح** در '
               '**طبقه‌بندی بازنگری‌شده‌ی CDC در سال ۱۹۹۳** هستند '
               '(MMWR 1992;41(RR-17)) که در بازنگری ۲۰۰۸ هم عیناً تکرار شده است.\n\n'
               '⚠️ **گروه A دقیقاً و فقط سه چیز است:** عفونت HIV بدون علامت، '
               '**لنفادنوپاتی ژنرالیزه‌ی پایدار (PGL)**، و عفونت حاد (اولیه‌ی) HIV.\n\n'
               '**و گروه C همان فهرست تعریف‌کننده‌ی ایدز است** که در متن CDC این سه '
               'مورد را با همین نام‌ها دارد: «توکسوپلاسموز مغز»، «پنومونی پنوموسیستیس»، '
               'و «مایکوباکتریوم توبرکلوزیس، **هر محل** (ریوی یا خارج‌ریوی)».\n\n'
               'پس سه گزینه از چهار گزینه — از جمله گزینه‌ای که کتاب کلید کرده — در '
               'گروه C هستند، و تنها موردی که در گروه C **نیست** گزینه‌ی '
               '**لنفادنوپاتی ژنرالیزه‌ی دائمی** است.\n\n'
               '**ریشه‌ی احتمالی خطا:** در تعریف قدیمی‌تر سال ۱۹۸۷، **سل ریوی '
               'جزو موارد تعریف‌کننده‌ی ایدز نبود** و در بازنگری ۱۹۹۳ به‌همراه '
               '«پنومونی راجعه» و «کانسر مهاجم سرویکس» اضافه شد. کسی که فهرست پیش از '
               '۱۹۹۳ را در ذهن داشته باشد دنبال استثنا میان گزینه‌های ریوی می‌گردد. '
               'ولی حتی در فهرست ۱۹۸۷ هم توکسوپلاسموز مغزی گروه C بود — یعنی کلید '
               'چاپی با **هر دو نسخه** ناسازگار است، و PGL با **هر دو نسخه** استثناست.'),
        'en': ('The printed key chooses cerebral toxoplasmosis as the exception, but that '
               'option is itself squarely CATEGORY C, and the key was CORRECTED.\n\n'
               'WHY THIS QUESTION HAS ONE VERIFIABLE ANSWER: clinical categories A, B and C '
               'are not a matter of clinical judgement. They are an EXPLICIT LIST in the CDC '
               '1993 revised classification system (MMWR 1992;41(RR-17)), reprinted verbatim '
               'in the 2008 revision (MMWR 2008;57(RR-10)).\n\n'
               'WARNING: CATEGORY A IS DEFINED AS, AND ONLY AS, three things: asymptomatic '
               'HIV infection, PERSISTENT GENERALIZED LYMPHADENOPATHY, and acute (primary) '
               'HIV infection.\n\n'
               'And CATEGORY C is the AIDS surveillance case definition list, which names '
               '"Toxoplasmosis of brain", "Pneumocystis carinii pneumonia", and '
               '"Mycobacterium tuberculosis, ANY SITE (pulmonary or extrapulmonary)".\n\n'
               'So three of the four options — including the one the book keyed — are '
               'category C, and the only option that is NOT is persistent generalised '
               'lymphadenopathy.\n\n'
               'THE LIKELY ORIGIN OF THE ERROR: in the older 1987 definition PULMONARY '
               'TUBERCULOSIS WAS NOT AIDS-DEFINING; it was added in the 1993 expansion '
               'together with recurrent pneumonia and invasive cervical cancer. Someone '
               'carrying the pre-1993 list in mind would hunt for the exception among the '
               'respiratory options. But even on the 1987 list cerebral toxoplasmosis was '
               'category C, so the printed key is wrong under EITHER edition, and PGL is '
               'the exception under BOTH.'),
        'refs': ['CDC — 1993 Revised Classification System for HIV Infection and Expanded '
                 'Surveillance Case Definition for AIDS Among Adolescents and Adults. '
                 'MMWR 1992;41(RR-17): clinical category A comprises asymptomatic infection, '
                 'persistent generalized lymphadenopathy and acute primary HIV infection',
                 'CDC — Revised Surveillance Case Definitions for HIV Infection Among Adults, '
                 'Adolescents, and Children. MMWR 2008;57(RR-10): reprints the category C '
                 'AIDS-defining condition list including toxoplasmosis of brain, Pneumocystis '
                 'pneumonia and M. tuberculosis at any site',
                 "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 202: "
                 'Human Immunodeficiency Virus Disease: AIDS and Related Disorders'],
    },
}


def main():
    done = []
    for i in range(1, 6):
        p = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        if not os.path.exists(p):
            continue
        body = json.load(io.open(p, encoding='utf-8'))
        dirty = False
        for q in body['questions']:
            spec = CORRECTIONS.get(q['question_no'])
            if not spec:
                continue

            target = [j for j, t in enumerate(q['options_fa']) if spec['match'](t)]
            assert len(target) == 1, (
                f"q{q['question_no']}: the PGL option must match exactly once, "
                f"matched {len(target)}")
            to = target[0]

            if q['correct_index'] == to and q.get('key_corrected'):
                done.append(f"q{q['question_no']}: already corrected")
                continue

            assert spec['expect_from'](q['options_fa'][q['correct_index']]), (
                f"q{q['question_no']}: expected the printed key to be the toxoplasmosis "
                f"option, found {q['options_fa'][q['correct_index']][:50]!r}")

            q['original_correct_index'] = q['correct_index']
            q['correct_index'] = to
            q['key_corrected'] = True
            q['key_correction_fa'] = spec['fa']
            q['key_correction_en'] = spec['en']
            q['key_correction_source'] = '; '.join(spec['refs'])
            done.append(f"q{q['question_no']}: {q['original_correct_index'] + 1} -> {to + 1}  "
                        f"({q['options_fa'][to][:46]})")
            dirty = True
        if dirty:
            json.dump(body, io.open(p, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)

    for d in done:
        print('  ', d)
    assert done, 'no question matched; the correction did nothing'
    print(f'corrections applied: {len(done)}')


if __name__ == '__main__':
    main()
