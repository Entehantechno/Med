# -*- coding: utf-8 -*-
"""English stems and options for the batch-19, -20 and -21 questions (zoonoses).

Rule 16 checked first, as always: these are sittings 93 to 98, for which the
ministry published no English booklet, so these are hand-written translations.

Translation decisions worth recording
-------------------------------------
q9414 (idx 414): the two immune-globulin doses were stored as "2 IU/kg" and
"4 IU/kg", each having lost a zero in extraction. Page 157 prints 20 and 40, and
fix_zoonoses_numbers.py restored them. The English quotes the CORRECTED values,
which also happen to be the only doses that exist in practice: 20 IU/kg for
human RIG and 40 IU/kg for equine.

q9450 (idx 450): the Wright titre was stored as "046/1" — a mirrored 1/640. The
English quotes 1/640. This matters because the titre IS the diagnosis in the
question; a student comparing the two languages must not see two different
numbers.

q9484, q9486, q9488, q9493, q9496: whole laboratory panels were repaired from
glyph geometry. The English quotes the repaired values throughout, and the
numeric inspector in apply_en.py checks every one of them.

q9468 (idx 468): the temperature was stored as "oc5/93" and repaired to 39.5 C.
The English writes "39.5" so the inspector can see it.

q9490 (idx 490): the stem writes the bilirubin as "Bili (T) = 25, Bili (D) = 20"
with no unit. The unit is mg/dL by context (a bilirubin of 25 in an icteric
patient), but the source prints no unit and the English does not invent one.
"""

EN9 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    assert all(o.strip() for o in options), idx
    EN9[idx] = {"stem_en": stem, "options_en": options}


# ============================================================ rabies (batch 19)
add(403,
    "A 59-year-old forester has sustained a laceration of the right leg from a wolf attack. He "
    "was fully vaccinated against rabies last year. Which of the following measures do you "
    "recommend for rabies prophylaxis?",
    ["Two doses of vaccine plus immune globulin",
     "Two doses of vaccine",
     "Five doses of vaccine",
     "Five doses of vaccine plus immune globulin"])

add(409,
    "Which of the following statements about the prevention of rabies is correct?",
    ["If previous vaccination was complete, give 2 doses of vaccine plus immune globulin",
     "If there was no previous vaccination, give four doses of vaccine plus immune globulin",
     "If there was no previous vaccination, give five doses of vaccine",
     "If there was no previous vaccination, give three doses of vaccine plus immune globulin"])

add(410,
    "A 10-year-old child is brought to the emergency department after being bitten two hours ago "
    "by a stray dog. On examination there is a laceration of the skin over the front of the "
    "forearm. The dog has run away. Besides washing the wound, what is the most appropriate "
    "measure for rabies prophylaxis?",
    ["Give antirabies serum and start a full course of rabies vaccination",
     "Start and complete a course of rabies vaccination alone",
     "Repair the wound and start rabies vaccination",
     "Antirabies serum alone"])

add(411,
    "A pregnant woman has been bitten by a dog suspected of rabies. Which of the following "
    "statements about giving her rabies vaccine is correct?",
    ["The vaccine is contraindicated",
     "Give three doses of vaccine on days zero, three and seven",
     "Give five doses of vaccine on days zero, three, seven, fourteen and twenty-eight",
     "Give four doses of vaccine on days zero, three, seven and fourteen"])

add(412,
    "Following a bite by a stray dog in a patient who has not previously been vaccinated, which "
    "preventive measure is recommended?",
    ["Three doses of rabies vaccine on days zero, three and seven, with one dose of rabies "
     "immune globulin on the first day",
     "Five doses of rabies vaccine on days zero, three, seven, fourteen and twenty-eight, with "
     "one dose of rabies immune globulin on the first day",
     "Four doses of rabies vaccine on days zero, three, seven and fourteen, with one dose of "
     "rabies immune globulin on the first day",
     "Five doses of rabies vaccine on days zero, three, seven, fourteen and twenty-eight, with "
     "two doses of rabies immune globulin on days zero and three"])

add(414,
    "A 12-year-old child has been bitten by a rabid dog. He lives in a remote area where rabies "
    "immune globulin is not available. Nine days after receiving the first dose of vaccine at "
    "the rural health post he attends the nearest health centre. Which of the following will you "
    "do?",
    ["Give RIG at a dose of 20 IU/kg",
     "Give RIG at a dose of 40 IU/kg",
     "Give the day 14 and day 28 vaccine doses according to the schedule",
     "Give the patient 5 g of IVIG"])

add(415,
    "In a person bitten by a dog who received only rabies vaccine as initial prophylaxis, and "
    "given that the vaccine and the immune globulin were not administered together, what is the "
    "best time to give HRIG?",
    ["Since the vaccine and immune globulin were not given together, later administration of "
     "HRIG is not permitted",
     "Up to two weeks after the vaccine dose",
     "HRIG may be given whenever the patient presents",
     "Up to one week after the vaccine dose"])

add(416,
    "A 45-year-old man attended the district health centre 9 days ago after a dog bite and "
    "received 3 doses of rabies vaccine on days 0, 3 and 7, but did not receive rabies immune "
    "globulin (RIG) because none was available. He has obtained RIG himself and has come to the "
    "health centre for the injection. What do you advise regarding the RIG?",
    ["Inject half the dose beside the bite site and the remainder into the gluteal muscle",
     "RIG is not recommended",
     "Since the wound has healed, inject the whole dose into the gluteal muscle",
     "Since 9 days have passed, inject the whole dose at the bite site"])

add(419,
    "A person attends after being bitten on the hand by an animal. What is the most appropriate "
    "prophylactic drug regimen?",
    ["Erythromycin ethylsuccinate", "Clindamycin", "Ciprofloxacin",
     "Amoxicillin-clavulanate"])

add(421,
    "A 25-year-old man was bitten by a dog a few hours before attending the emergency "
    "department. Rabies vaccination and initial wound care have been carried out. Which of the "
    "following treatments would you prescribe to prevent infection?",
    ["Ciprofloxacin", "Levofloxacin", "Gemifloxacin", "Moxifloxacin"])


# ====================================================== brucellosis (batch 20)
add(440,
    "A 50-year-old farmer presents with fever, sweating, weight loss and back pain of 3 months' "
    "duration. Radiographs show involvement of the L1 and L2 vertebrae with a healthy "
    "intervertebral disc and an anterolateral osteophyte (parrot-beak appearance). MRI shows no "
    "cord compression and no psoas abscess. Which of the following organisms is most likely "
    "responsible for this patient's spondylitis?",
    ["Mycobacterium tuberculosis", "Brucella", "Pseudomonas aeruginosa",
     "Staphylococcus aureus"])

add(444,
    "In distinguishing brucellar from tuberculous spondylitis, which of the following findings "
    "favours brucellosis?",
    ["Anterolateral osteophyte", "Spinal canal compression", "Anterior wedging",
     "Body destruction"])

add(447,
    "A 40-year-old man who works in an abattoir presents with prolonged fever of one month's "
    "duration together with cough. He has attended a doctor several times during this period and "
    "the fever has been documented. His Wright titre is 1/320. Which of the following is the "
    "correct step to confirm brucellosis?",
    ["Blood culture", "Bone marrow biopsy", "2-Mercaptoethanol test",
     "Coombs Wright test"])

add(452,
    "A 45-year-old man who works in a microbiology laboratory presents with fever, night sweats "
    "and joint pains of one month's duration. On examination his temperature is 38 degrees and "
    "the rest of the examination is normal. His standard agglutination test is 1/80. Which of "
    "the following organisms is the most likely cause of his illness?",
    ["Brucella melitensis", "Salmonella enterica", "Mycobacterium tuberculosis",
     "Francisella tularensis"])

add(464,
    "A pregnant woman at 20 weeks' gestation presents with a temperature of 38 degrees Celsius, "
    "fatigue, anorexia, night sweats and a limp. Her standard agglutination test is positive at "
    "1/320. What is the most appropriate treatment?",
    ["Ceftriaxone plus rifampicin", "Co-trimoxazole plus gentamicin",
     "Ciprofloxacin plus rifampicin", "Co-trimoxazole plus rifampicin"])

add(471,
    "For the treatment of uncomplicated brucellosis in a 40-year-old man, which treatment "
    "regimen is preferred?",
    ["Streptomycin plus doxycycline", "Doxycycline plus rifampicin",
     "Streptomycin plus rifampicin",
     "Doxycycline plus rifampicin plus streptomycin"])

add(475,
    "A patient developed fever, sweating, and pain and swelling of the knee 2 months ago after "
    "eating local cheese. The Wright test is reported as 1/640 and the 2ME as 1/160. Which of "
    "the following is recommended for this patient?",
    ["Treatment for 6 weeks", "Three-drug treatment", "Clinical monitoring for 6 months",
     "Repeating the Wright test every 2 months for 6 months"])

add(479,
    "A microbiology laboratory technician has had heavy skin and mucous membrane contact with "
    "the contents of a Brucella culture. The patient attends you two days after the exposure. "
    "Which of the following preventive or therapeutic measures do you recommend?",
    ["Drug prophylaxis has no effect in this patient",
     "Brucella vaccine can be given to this patient",
     "Prescribe doxycycline for 3 weeks",
     "Prescribe doxycycline and rifampicin for 6 weeks"])

add(483,
    "A young butcher presents with fever, rigors, anorexia, weight loss, myalgia and back pain. "
    "Investigations show a normal full blood count, with a Wright of 1/640 and a 2ME of 1/320. "
    "On examination a grade 4/6 holosystolic murmur is heard at the cardiac apex, and "
    "echocardiography shows a vegetation on the mitral valve. Which antibiotic treatment is more "
    "appropriate?",
    ["Streptomycin for 14 to 21 days plus doxycycline for 6 weeks",
     "Doxycycline plus rifampicin for a total of 6 weeks",
     "Gentamicin plus (doxycycline and rifampicin) for a total of 6 months, with or without "
     "ceftriaxone or a quinolone",
     "Gentamicin plus (doxycycline and rifampicin) for a total of 3 to 6 months"])

add(459,
    "In a patient with brucellosis after treatment, which of the following is the most useful "
    "index for assessing the response to treatment?",
    ["The Wright test becoming negative after one month of treatment",
     "A fall of one or two titres in the Wright test after one month of treatment",
     "Brucella serology becoming negative",
     "The patient's general condition and weight"])

add(462,
    "A 48-year-old man received rifampicin plus doxycycline for 8 weeks for brucellosis. Two "
    "weeks after finishing the drugs he again developed fever, sweating, musculoskeletal pain "
    "and anorexia. Investigations show a Wright of 1/320 and a 2ME of 1/160. What is the most "
    "appropriate approach to this patient?",
    ["Doxycycline plus rifampicin plus gentamicin for 8 weeks",
     "Doxycycline plus rifampicin for 12 weeks",
     "Observe the patient and repeat the tests in 8 weeks",
     "Doxycycline plus streptomycin for 12 weeks"])


# ==================================================== leptospirosis (batch 21)
add(487,
    "A 41-year-old abattoir worker presents with a seven-day fever, redness of the conjunctiva "
    "without purulent discharge, myalgia, one recent episode of haemoptysis and jaundice. His "
    "peripheral blood count is reported as WBC 13000 per microlitre, platelets 8000 per "
    "microlitre, neutrophils 80% and lymphocytes 20%. What is the most likely diagnosis?",
    ["Leptospirosis", "Brucellosis", "Tuberculosis", "Influenza"])

add(495,
    "In severe leptospirosis, which of the following is NOT seen?",
    ["Leucocytosis", "Thrombocytopenia", "A raised serum creatinine",
     "Lymphocytic pleocytosis of the cerebrospinal fluid"])

add(496,
    "A rice farmer gives a history of fever, headache and myalgia lasting one week, followed by "
    "5 days free of these symptoms, and now presents again with fever and jaundice. "
    "Investigations show AST 1000 u/ml, ALT 80 u/ml, a platelet count of 80000 per microlitre, a "
    "creatinine of 2.4 mg/dl and a PT of 12 seconds. Which of the following is the appropriate "
    "specimen for recovering the organism?",
    ["Peripheral blood", "Urine", "Bone marrow", "Stool"])

add(493,
    "A 50-year-old female rice farmer presents with jaundice and weakness. Investigations show a "
    "creatinine of 3, a platelet count of 70 thousand and leucocytosis. Her coagulation tests "
    "show an INR of 1.1 and a PT of 14 seconds, with a total bilirubin of 17 and a direct "
    "bilirubin of 12, AST 207, ALT 217 and ALP 257. What do you consider the most likely "
    "diagnosis?",
    ["Acute hepatitis", "Cholestasis due to a pancreatic tumour", "Leptospirosis",
     "Disseminated intravascular coagulation (DIC)"])

add(497,
    "A 25-year-old woman from the north of the country presents with a temperature of 39 "
    "degrees, headache and myalgia of 2 days' duration. On examination she has conjunctival "
    "suffusion and calf tenderness. A spiral organism is reported on the peripheral blood smear. "
    "Which treatment is preferred?",
    ["Vancomycin", "Penicillin", "Imipenem", "Ciprofloxacin"])

add(498,
    "For a canoeing team being sent to an area endemic for leptospirosis, which of the following "
    "is the appropriate antibiotic prophylaxis?",
    ["Cefixime", "Penicillin", "Amoxicillin", "Azithromycin"])

add(486,
    "One week after swimming competitions a 16-year-old adolescent develops a fever of 40 "
    "degrees, severe myalgia of the calves and headache. Five days later he is admitted with "
    "neck pain and stiffness, deep jaundice and cough with haemoptysis. Investigations show a "
    "leucocytosis of 13 thousand, a platelet count of 75000, ALT 175 and CPK 3000. Analysis of "
    "the CSF shows a pleocytosis of 450 with mononuclear predominance and a normal glucose and "
    "protein. Given this history, what diagnosis do you consider for the patient?",
    ["Meningococcaemia", "Severe measles", "Typhoid fever", "Leptospirosis"])
