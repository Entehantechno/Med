# -*- coding: utf-8 -*-
"""Second-pass numeric audit of the parasitology / malaria chapter.

WHY A SECOND PASS, AND WHAT IS DIFFERENT ABOUT IT
--------------------------------------------------
The first pass (`audit_parasite.py`) looked for a fixed list of SUSPECT values —
the thresholds a severity question turns on. That catches the numbers we thought
of. It cannot catch the ones we did not.

This pass inverts the question. It takes EVERY multi-digit number stored in the
81 not-yet-taught questions of the chapter and asks the page it came from
whether that number was actually printed there. Nothing is whitelisted.

The locating rule is the one the viral chapter proved is necessary but not
sufficient on its own:

  1. a question is matched to ITS OWN page, not to the book as a whole, by
     scoring the Persian LETTERS of its stem and options against each page;
  2. every page tied for the best score is kept, so an ambiguous match reports
     as ambiguous instead of silently picking one;
  3. a minimum match density is required — `sc >= max(3, len(words) * 0.55)` —
     because a handful of common Persian words will match any page.

Digits take no part in locating the line: they are the thing under suspicion.

Output is a report only. Nothing is written back.
"""
import collections
import io
import json
import os
import re

import pdfplumber

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = '/home/user/uploads/بیماری عفونی.pdf'
CHAPTER = 'بیماری‌های انگلی و مالاریا'

FOLD = {}
for _i in range(10):
    FOLD[chr(0x0660 + _i)] = str(_i)
    FOLD[chr(0x06F0 + _i)] = str(_i)


def fold(s):
    return ''.join(FOLD.get(c, c) for c in s or '')


def words(s):
    """Persian word tokens of length >= 4, digits stripped out."""
    s = re.sub(r'[\u0660-\u0669\u06F0-\u06F9\d]', ' ', s or '')
    s = re.sub(r'[^\u0600-\u06FF\s]', ' ', s)
    return [w for w in s.split() if len(w) >= 4]


def page_letter_text(page):
    """Page text rebuilt from glyphs, per line, reversed back into logical order.

    `page.extract_text()` is useless for matching here: this PDF's Persian comes
    out in a different order from the stored payload, so every page scored zero.
    The stored text was itself produced by reversing the x-sorted glyph run of a
    line, so the audit has to rebuild the page the same way to compare like with
    like.
    """
    rows = collections.defaultdict(list)
    for c in page.chars:
        rows[round(c['top'])].append(c)
    out = []
    for top in sorted(rows):
        cs = sorted(rows[top], key=lambda c: c['x0'])
        out.append(''.join(c['text'] for c in cs)[::-1])
    return '\n'.join(out)


def page_digit_runs(page):
    """Digit runs of a page in PRINTED (x-ascending) order."""
    rows = collections.defaultdict(list)
    for c in page.chars:
        rows[round(c['top'])].append(c)
    runs = []
    for top in sorted(rows):
        cs = sorted(rows[top], key=lambda c: c['x0'])
        cur = ''
        for c in cs:
            t = FOLD.get(c['text'], c['text'])
            if t.isspace() and cur:
                continue          # kerning must not split one number into two
            if t.isdigit():
                cur += t
            else:
                if cur:
                    runs.append(cur)
                cur = ''
        if cur:
            runs.append(cur)
    return runs


def main():
    lessons = {}
    for f in sorted(os.listdir(HERE)):
        if f.startswith('lessons_book') and f.endswith('.json'):
            lessons.update(json.load(io.open(os.path.join(HERE, f), encoding='utf-8')))

    qs, flat = [], 0
    for i in range(1, 6):
        p = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        body = json.load(io.open(p, encoding='utf-8'))
        for q in body['questions']:
            if q['chapter_fa'] == CHAPTER and f'book:{flat}' not in lessons:
                qs.append((flat, q))
            flat += 1

    with pdfplumber.open(SRC) as pdf:
        pages = []
        for pno, page in enumerate(pdf.pages, 1):
            txt = page_letter_text(page)
            pages.append((pno, set(words(txt)), page_digit_runs(page), fold(txt)))

    n_ok = n_bad = n_amb = 0
    print(f'questions in scope: {len(qs)}\n')
    for idx, q in qs:
        blob = ' '.join([q['question_fa']] + list(q['options_fa']))
        ws = words(blob)
        if not ws:
            continue
        need = max(3, len(ws) * 0.55)
        # A question printed near a page break has its stem on one page and its
        # options on the next, so a single page can never score high enough.
        # Each candidate is therefore a page TOGETHER WITH the following page;
        # the digit runs of both are accepted. This widens what counts as
        # "printed" by exactly one page, which is the real physical unit a
        # question occupies — not by the whole book.
        spreads = []
        for i, (pno, pw, runs, _t) in enumerate(pages):
            nw, nruns = (pages[i + 1][1], pages[i + 1][2]) if i + 1 < len(pages) else (set(), [])
            spreads.append((pno, pw | nw, runs + nruns))
        scored = [(len(set(ws) & pw), pno, runs) for pno, pw, runs in spreads]
        best = max(s for s, _p, _r in scored)
        if best < need:
            n_amb += 1
            print(f'? idx={idx} q{q["question_no"]}  NO PAGE (best={best}/{len(ws)}, need {need:.0f})')
            continue
        tied = [(pno, runs) for s, pno, runs in scored if s == best]
        # Spreads overlap by one page, so a question sitting on a page boundary
        # ties two ADJACENT spreads. That is not real ambiguity: both name the
        # same physical neighbourhood. Ties are accepted only while they stay
        # inside a three-page window; a tie any wider than that means the letters
        # did not actually pin the question down, and is reported.
        span = max(p for p, _ in tied) - min(p for p, _ in tied)
        if span > 2:
            n_amb += 1
            print(f'? idx={idx} q{q["question_no"]}  AMBIGUOUS pages {[p for p, _ in tied]}')
            continue
        pno = min(p for p, _ in tied)
        runs = [r for _p, rs in tied for r in rs]
        joined = ' '.join(runs)
        nums = [n for n in re.findall(r'\d+', fold(blob)) if len(n) >= 2]
        for v in nums:
            if v in runs or v in joined:
                n_ok += 1
            elif v[::-1] in runs:
                n_bad += 1
                print(f'X idx={idx} q{q["question_no"]} p{pno}  MIRRORED stored={v} '
                      f'page prints {v[::-1]}')
            else:
                n_bad += 1
                print(f'X idx={idx} q{q["question_no"]} p{pno}  NOT PRINTED stored={v}')
                print(f'    page runs: {sorted(set(runs))}')
    print(f'\nagree={n_ok}  disagree={n_bad}  unlocated={n_amb}')


if __name__ == '__main__':
    main()
