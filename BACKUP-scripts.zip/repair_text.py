# -*- coding: utf-8 -*-
"""Repair the two systematic text corruptions in the infectious book PDF.

1. lam-alef ligature
   The exporter writes the ligature "لا" as "ال" (alef first). So مبتلا becomes
   مبتال, علائم becomes عالئم, مالاریا becomes ماالریا. A blind global swap is
   impossible: "ال" is also the ordinary definite-article-like sequence in many
   legitimate words (اسهال, احتمال, سالمونلوز, سال). The discriminator has to be
   the word, not the letter pair.

   So we use a vocabulary: for every distinct token in the corpus, if swapping
   an "ال" back to "لا" produces a word that is a known Persian/medical term,
   take the swap. The known-word list is built from three sources that are
   independent of this PDF — the existing infectious bank, the neurology bank
   and the all-subject archive — which together contain ~4000 clean Persian
   medical tokens. A correction is only applied when the repaired form appears
   in that clean corpus AND the corrupted form does not.

   This is self-checking: a word that legitimately contains "ال" (اسهال) is
   present in the clean corpus in exactly that shape, so it is never touched.

2. mirrored parentheses
   Latin parentheticals come out as ")CSF(" instead of "(CSF)". Unambiguous.
"""
import json, io, os, re, sys, glob, collections

HERE = os.path.dirname(os.path.abspath(__file__))
CLEAN_SOURCES = [
    '/home/user/work/infectious/import-payload.json',
    '/home/user/project/tools/neurology-bank/import-payload.part01.json',
    '/home/user/project/tools/neurology-bank/import-payload.part02.json',
    '/home/user/project/tools/neurology-bank/import-payload.part03.json',
    '/home/user/project/tools/neurology-bank/import-payload.part04.json',
    '/home/user/project/tools/neurology-bank/import-payload.part05.json',
    '/home/user/project/tools/neurology-bank/import-payload.part06.json',
    '/home/user/project/tools/neurology-bank/import-payload.part07.json',
]
WORD = re.compile(r'[\u0600-\u06FF\u200c]+')


def clean_vocab():
    """Persian tokens from banks that were extracted without this corruption."""
    vocab = collections.Counter()
    for p in CLEAN_SOURCES:
        if not os.path.exists(p):
            continue
        body = json.load(io.open(p, encoding='utf-8'))
        for q in body.get('questions', []):
            blob = ' '.join([
                q.get('question_fa') or '',
                ' '.join(q.get('options_fa') or []),
                q.get('explanation_fa') or '',
                ' '.join((q.get('micro') or {}).get('points_fa') or []),
            ])
            for w in WORD.findall(blob):
                vocab[w.replace('\u200c', '')] += 1
    return vocab


# Terms the clean corpora happen not to contain (or contain too rarely to pass
# the frequency test), verified by hand against the printed page. Kept tiny and
# explicit rather than loosening the statistical rule, which would risk
# corrupting legitimate words like اسهال.
SEED = {
    'ماالریا': 'مالاریا', 'ماالریای': 'مالاریای', 'ماالریایی': 'مالاریایی',
    'واریسال': 'واریسلا', 'آنفوالنزا': 'آنفولانزا', 'آنفوالنزای': 'آنفولانزای',
    'کالسیک': 'کلاسیک', 'پالسمودیوم': 'پلاسمودیوم', 'باالتر': 'بالاتر',
    'کالمیدیا': 'کلامیدیا', 'اطالعات': 'اطلاعات', 'اسالید': 'اسلاید',
    'گاالکتومانان': 'گالاکتومانان',
}

# Stems whose ANY inflected form is corrupt. Applied as a substring swap so
# ماالریه/ماالریاخی/توکسوپالسمایی are all repaired without enumerating them.
# Every entry is a medical term where the "ال" sequence cannot occur legitimately.
SEED_STEMS = [
    ('ماالر', 'مالار'), ('واریسال', 'واریسلا'), ('آنفوالنز', 'آنفولانز'),
    ('پالسمو', 'پلاسمو'), ('پالسما', 'پلاسما'), ('کالمید', 'کلامید'),
    ('کالسیک', 'کلاسیک'), ('باالرو', 'بالارو'), ('وسیعالطیف', 'وسیع‌الطیف'),
    ('عالطیف', 'ع‌الطیف'),
]


# The exporter drops the letter "چ" entirely (the corpus contains zero of them),
# so چند -> ند, همچنین -> همنین, چرکی -> رکی. Recovered with the same
# vocabulary evidence used for the ligature: insert چ at each position and keep
# the candidate that is a known clean word. Only applied when the corrupted
# form is itself rare/absent in clean text, so "ند" inside a real word is safe.
def build_che_fixes(tokens, vocab):
    fixes = {}
    for tok, n in tokens.items():
        bare = tok.replace('\u200c', '')
        if 'چ' in bare or len(bare) < 2:
            continue
        if vocab.get(bare, 0) >= 3:
            continue                     # legitimately spelled this way
        # Short tokens are far too ambiguous: "هی" is the ordinary ezafe
        # suffix, not a mangled "هیچ". Require real length before guessing.
        if len(bare) < 3 and n > 50:
            continue
        best, score = None, 0
        for i in range(len(bare) + 1):
            c = bare[:i] + 'چ' + bare[i:]
            v = vocab.get(c, 0)
            if v > score:
                best, score = c, v
        # demand strong evidence AND that the corrupt form is essentially
        # unseen in clean text, so common suffixes are never rewritten
        if best and score >= 5 and vocab.get(bare, 0) == 0:
            fixes[tok] = best
    return fixes


def build_fixes(tokens, vocab):
    """token -> repaired token, only where the evidence is unambiguous."""
    fixes = {}
    for tok in tokens:
        if tok in SEED:
            fixes[tok] = SEED[tok]
            continue
        if 'ال' not in tok:
            continue
        bare = tok.replace('\u200c', '')
        if vocab.get(bare, 0) >= 2:
            continue          # the word legitimately looks like this
        # try swapping each ال occurrence (and all of them together)
        cands = set()
        idxs = [m.start() for m in re.finditer('ال', bare)]
        for i in idxs:
            cands.add(bare[:i] + 'لا' + bare[i + 2:])
        if len(idxs) > 1:
            cands.add(bare.replace('ال', 'لا'))
        best, score = None, 0
        for c in cands:
            v = vocab.get(c, 0)
            if v > score:
                best, score = c, v
        if best and score >= 2:
            fixes[tok] = best
    return fixes


# Lab values print as "dl/mg23" — the unit pair survived the line flip in
# mirrored form and the number was glued to it, so the digit-run rule in
# extract_rtl could not see that it sits next to Latin. Rewrite to "23 mg/dl",
# flipping the digits back. Ranges like "051" become "150".
# No \b here: the neighbours are Persian letters, which \b does not treat as a
# boundary the way it does for ASCII. Anchor on "not a Latin letter" instead.
UNIT = re.compile(r'(?<![A-Za-z])([A-Za-z]{1,6})/([A-Za-z]{1,6})(\d{1,6})(?![A-Za-z0-9])')

# Persian words the ligature pass mangled in a different way: the exporter
# occasionally emits a trailing cluster out of order (باکتریال -> باکتلایر).
WORD_FIX = {
    'باکتلایر': 'باکتریال', 'مننزیت': 'مننژیت',
}


PRESSURE = re.compile(r'(?<![A-Za-z])O2mmH(\d{2,4})(?![0-9])')


def fix_units(s):
    def rep(m):
        a, b, num = m.group(1), m.group(2), m.group(3)
        val = num[::-1].lstrip('0') or '0'
        return f'{val} {b}/{a}'
    s = UNIT.sub(rep, s)
    # "O2mmH002" is a mirrored "200 mmH2O" (CSF opening pressure)
    s = PRESSURE.sub(lambda m: f"{m.group(1)[::-1].lstrip('0') or '0'} mmH2O", s)
    return s


# The exporter scatters spaces inside words ("ت ب" for تب, "نمون هی" for نمونه‌ی,
# "سال های" for ساله). Rejoining every such split is not safely decidable, but
# three shapes are, and they cover almost all of it:
#   * a lone "ه" starting a word, glued back to the previous word (نمون هی)
#   * a space between a number and "ساله"
#   * a space glued before punctuation
JOIN_HE = re.compile(r'([\u0600-\u06FF]{2,})\s+ه([\u0600-\u06FF]{0,3})(?=\s|$)')
SPACE_PUNCT = re.compile(r'\s+([،.؟:!])')


def fix_ages(s):
    """A leading zero in an age means the digits were mirrored: 04 -> 40.

    Only two-digit runs immediately before "ساله" are touched, and only when
    they start with 0, which is never a real age. Self-checking and narrow.
    """
    return re.sub(r'(?<![0-9])0(\d)\s*(?=ساله)', lambda m: m.group(1) + '0 ', s)


def tidy(s):
    s = fix_ages(s)
    s = JOIN_HE.sub(lambda m: m.group(1) + '\u0647' + m.group(2), s)
    s = re.sub(r'(\d)\s+(ساله|سال\u200cه|سالهای|سال های)', r'\1 ساله', s)
    s = SPACE_PUNCT.sub(r'\1', s)
    s = re.sub(r'([\u0600-\u06FF])(\d)', r'\1 \2', s)
    s = re.sub(r'(\d)([\u0600-\u06FF])', r'\1 \2', s)
    s = re.sub(r'([a-zA-Z])([\u0600-\u06FF])', r'\1 \2', s)
    s = re.sub(r'([\u0600-\u06FF])([a-zA-Z])', r'\1 \2', s)
    return re.sub(r'\s{2,}', ' ', s).strip()


def apply_fixes(s, fixes):
    if not s:
        return s
    s = WORD.sub(lambda m: fixes.get(m.group(0), WORD_FIX.get(m.group(0), m.group(0))), s)
    for a, b in SEED_STEMS:
        s = s.replace(a, b)
    s = fix_units(s)
    s = tidy(s)
    # mirrored Latin parentheticals
    s = re.sub(r'\)([A-Za-z0-9][A-Za-z0-9 ./-]{0,20})\(', r'(\1)', s)
    return s


def main():
    src = os.path.join(HERE, 'import-payload.json')
    body = json.load(io.open(src, encoding='utf-8'))
    qs = body['questions']

    tokens = collections.Counter()
    for q in qs:
        for f in [q['question_fa']] + list(q['options_fa']):
            for w in WORD.findall(f or ''):
                tokens[w] += 1

    vocab = clean_vocab()
    fixes = build_fixes(tokens, vocab)
    che = build_che_fixes(tokens, vocab)
    for k, v in che.items():
        fixes.setdefault(k, v)
    print(f'  of which restored a dropped چ: {len(che)}')
    print(f'clean vocabulary: {len(vocab)} tokens')
    print(f'repairs learned: {len(fixes)}')
    for k, v in sorted(fixes.items(), key=lambda x: -tokens[x[0]])[:20]:
        print(f'   {k} -> {v}   (x{tokens[k]})')

    n = 0
    for q in qs:
        before = q['question_fa'] + '|'.join(q['options_fa'])
        q['question_fa'] = apply_fixes(q['question_fa'], fixes)
        q['options_fa'] = [apply_fixes(o, fixes) for o in q['options_fa']]
        if before != q['question_fa'] + '|'.join(q['options_fa']):
            n += 1
    # fingerprints must follow the repaired text
    for q in qs:
        txt = re.sub(r'[۰-۹0-9]', '#', q['question_fa'])
        txt = re.sub(r'[^\w\s#]', ' ', txt)
        txt = re.sub(r'\s+', ' ', txt).strip()
        q['fingerprint'] = f"بیماری‌های عفونی Infectious Diseases {txt}"[:400]

    json.dump(body, io.open(src, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(f'questions touched: {n}/{len(qs)}')

    blob = ' '.join(q['question_fa'] + ' ' + ' '.join(q['options_fa']) for q in qs)
    for w in ('مبتال', 'عالئم', 'ماالریا', 'واریسال', 'آنفوالنزا', 'اختالل', 'باال'):
        print(f'  residual {w}: {blob.count(w)}')
    mirrored = re.findall('[)][A-Za-z0-9 ]{1,12}[(]', blob)
    print('  residual mirrored parens:', len(mirrored))


if __name__ == '__main__':
    main()
