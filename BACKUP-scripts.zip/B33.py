# -*- coding: utf-8 -*-
"""Micro-lessons, batch 33 — measles, rubella, mumps, and hepatitis serology.

Two blocks that look unrelated but share one examining habit: both are decided
by reading a PATTERN rather than recalling a fact.

BLOCK ONE — THE VACCINE-PREVENTABLE EXANTHEMS
The examiners describe a rash and expect the student to name it from the
prodrome rather than the rash itself, because the rashes look alike and the
prodromes do not:

    measles   three Cs first — Cough, Coryza, Conjunctivitis — for 3 to 4
              days, then KOPLIK SPOTS, then a rash spreading DOWNWARDS from
              the face and BECOMING CONFLUENT
    rubella   a trivial prodrome, a rash that does not become confluent, and
              TENDER POSTERIOR AURICULAR AND OCCIPITAL NODES
    mumps     no rash at all: parotid swelling, and the question is always
              about the infectious period

The single most examined fact in the measles block is not diagnostic at all:
VITAMIN A. It is the one treatment with a mortality benefit, and three of the
options offered against it are deliberately plausible-looking nonsense.

BLOCK TWO — HEPATITIS SEROLOGY IS A GRID, NOT A LIST
Six questions hand the student a panel of HBsAg, anti-HBc, anti-HBs and IgM
and ask what it means or what to add. They are all answerable from one small
grid plus one rule about which marker answers which question:

    HBsAg      is the infection present now?
    anti-HBc IgM   is it ACUTE?
    anti-HBc IgG   has there ever been infection? (never from vaccine)
    anti-HBs   is there immunity, from vaccine or from recovery?
    HBeAg / DNA    how infectious, how actively replicating?

AND THE RULE THAT DECIDES TWO OF THE QUESTIONS
Vaccination produces anti-HBs ALONE. Natural infection produces anti-HBc as
well. So anti-HBc is the marker that separates "vaccinated" from "has met the
virus" — and in a patient already known to be HBsAg positive it adds nothing,
which is exactly what two questions here are asking.

A NOTE ON SEVERITY, WHICH THE CHAPTER TESTS ONCE
In acute hepatitis the transaminases measure how much liver is being damaged,
not how much liver still WORKS. Severity is judged by SYNTHETIC FUNCTION —
the prothrombin time above all, then bilirubin and glucose. A falling ALT with
a rising INR is not improvement; it is liver failure.

Reference: WHO, "Vitamin A supplementation in infants and children" and the
measles treatment recommendations; CDC Pink Book chapters on measles, rubella
and mumps; AASLD Guidance on Chronic Hepatitis B (2018); Harrison's Principles
of Internal Medicine, 21st ed (2022), Ch. 199 (Measles), Ch. 200 (Rubella),
Ch. 339 (Acute Viral Hepatitis).
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


PINKBOOK = ("CDC — Epidemiology and Prevention of Vaccine-Preventable Diseases (the Pink Book), "
            "chapters on Measles, Rubella and Mumps")
WHOVITA = ("World Health Organization — Vitamin A supplementation and the treatment of measles; "
           "WHO Measles fact sheet and treatment guidance")
AASLD = ("Terrault NA et al. — AASLD Guidance on Prevention, Diagnosis, and Treatment of Chronic "
         "Hepatitis B. Hepatology 2018;67(4):1560-1599")
H199 = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 199 (Measles) and "
        "Ch. 200 (Rubella)")
H339 = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 339: Acute Viral Hepatitis")

# --------------------------------------------------------------- the exanthems
EX_FA = [
    "⚠️ **راش‌های ویروسی را از روی پرودروم بشناسید، نه از روی خودِ راش.**",
    "**راش‌ها به هم شبیه‌اند؛ آنچه پیش از راش می‌آید، آن‌ها را از هم جدا می‌کند.**",
    "⚠️ **سرخک — سه C را حفظ کنید: سرفه، کوریزا (آبریزش بینی)، کونژنکتیویت.**",
    "**این سه، سه تا چهار روز پیش از راش شروع می‌شوند و بیمار را بسیار بدحال می‌کنند.**",
    "**سپس لکه‌های کوپلیک: نقاط سفید مایل به آبی روی مخاط گونه، مقابل دندان‌های آسیا.**",
    "⚠️ **کوپلیک پاتوگنومونیک است و ۱ تا ۲ روز پیش از راش ظاهر و با آمدن راش محو می‌شود.**",
    "**و راش سرخک از پیشانی و پشت گوش شروع می‌شود، به پایین گسترش می‌یابد، و به‌هم می‌پیوندد.**",
    "**«به‌هم پیوستن» (confluent) ویژگی مهمی است که سرخک را از سرخجه جدا می‌کند.**",
    "**سرخجه — پرودروم ناچیز، راش که به‌هم نمی‌پیوندد، و لنفادنوپاتی پشت گوش و پس‌سری حساس.**",
    "⚠️ **در بزرگسال، آرترالژی و آرتریت گذرا هم شایع است، به‌ویژه در زنان.**",
    "**اوریون — راشی در کار نیست: تورم پاروتید، اغلب یک‌طرفه و بعد دوطرفه.**",
    "**دوره‌ی سرایت اوریون: از حدود یک هفته پیش تا یک هفته پس از شروع تورم پاروتید.**",
    "⚠️ **و عارضه‌های سرخک را بر حسب زمان تفکیک کنید:**",
    "**زودرس و شایع: اوتیت مدیای حاد — شایع‌ترین عارضه‌ی سرخک.**",
    "**زودرس و خطرناک: پنومونی — شایع‌ترین علت مرگ در سرخک، به‌ویژه در کودکان.**",
    "**دیررس و نادر: انسفالیت حاد (۱ در هزار) و پان‌انسفالیت اسکلروزان تحت‌حاد سال‌ها بعد.**",
    "**و در سوءتغذیه و کمبود ویتامین A، همه‌ی این عوارض چند برابر شدیدترند.**",
]
EX_EN = [
    "WARNING: IDENTIFY THE VIRAL EXANTHEMS BY THE PRODROME, NOT BY THE RASH ITSELF.",
    "The rashes resemble one another; what comes before the rash separates them.",
    "WARNING, MEASLES — MEMORISE THE THREE Cs: COUGH, CORYZA, CONJUNCTIVITIS.",
    "These begin three to four days before the rash and make the patient markedly unwell.",
    "Then KOPLIK SPOTS: bluish-white dots on the buccal mucosa opposite the molars.",
    "WARNING, KOPLIK SPOTS ARE PATHOGNOMONIC, appearing 1 to 2 days before the rash and fading as it arrives.",
    "And the measles rash begins on the forehead and behind the ears, spreads DOWNWARDS, and BECOMES CONFLUENT.",
    "Confluence is an important feature separating measles from rubella.",
    "RUBELLA — a trivial prodrome, a rash that does not become confluent, and TENDER POSTERIOR AURICULAR AND OCCIPITAL NODES.",
    "WARNING, IN ADULTS transient arthralgia and arthritis are also common, especially in women.",
    "MUMPS — no rash at all: parotid swelling, often unilateral then bilateral.",
    "The infectious period of mumps: from about a week before to a week after the parotid swelling begins.",
    "WARNING, AND SEPARATE THE COMPLICATIONS OF MEASLES BY TIMING:",
    "EARLY AND COMMON: acute otitis media — the commonest complication of measles.",
    "EARLY AND DANGEROUS: pneumonia — the commonest cause of death in measles, especially in children.",
    "LATE AND RARE: acute encephalitis (1 in 1000) and subacute sclerosing panencephalitis years later.",
    "And in malnutrition and vitamin A deficiency all of these are several times more severe.",
]

# ------------------------------------------------------- hepatitis serology grid
HEP_FA = [
    "⚠️ **سرولوژی هپاتیت B را به‌صورت یک شبکه بخوانید: هر نشانگر به یک سؤال پاسخ می‌دهد.**",
    "**HBsAg — آیا عفونت همین حالا حاضر است؟ مثبت یعنی ویروس در بدن هست.**",
    "**anti-HBc از نوع IgM — آیا عفونت حاد است؟ نشانگر عفونت تازه.**",
    "**anti-HBc از نوع IgG — آیا هرگز عفونت رخ داده است؟ برای همیشه مثبت می‌ماند.**",
    "⚠️ **و نکته‌ی کلیدی: anti-HBc هرگز از واکسن ساخته نمی‌شود، فقط از عفونت واقعی.**",
    "**anti-HBs — آیا ایمنی وجود دارد؟ چه از واکسن، چه از بهبود عفونت.**",
    "**HBeAg و HBV DNA — چقدر تکثیر فعال است و بیمار چقدر مسری است؟**",
    "**پس سه الگوی اصلی را با هم حفظ کنید:**",
    "**واکسینه: فقط anti-HBs مثبت. هیچ نشانگر دیگری نیست.**",
    "**عفونت گذشته و بهبودیافته: anti-HBs مثبت به‌علاوه‌ی anti-HBc از نوع IgG.**",
    "⚠️ **عفونت مزمن: HBsAg بیش از ۶ ماه مثبت، anti-HBc از نوع IgG مثبت، anti-HBs منفی.**",
    "**و حالا قاعده‌ای که چند سؤال را حل می‌کند:**",
    "**در بیماری که HBsAg او از قبل مثبت است، anti-HBc چیز تازه‌ای اضافه نمی‌کند.**",
    "**چون وقتی می‌دانیم عفونت هست، دانستن اینکه «عفونتی رخ داده» بی‌فایده است.**",
    "⚠️ **و شدت بیماری را با آنزیم‌های کبدی نسنجید — با عملکرد سنتزی کبد بسنجید.**",
    "**ALT و AST نشان می‌دهند چقدر سلول کبدی در حال آسیب دیدن است، نه چقدر کبد کار می‌کند.**",
    "**معیار واقعی شدت: زمان پروترومبین (PT/INR)، سپس بیلی‌روبین و قند خون.**",
    "⚠️ **افت ALT همراه با بالا رفتن INR بهبود نیست — نارسایی کبد است.**",
    "**چون سلول کبدی آن‌قدر مرده که دیگر آنزیمی برای آزاد کردن ندارد.**",
]
HEP_EN = [
    "WARNING: READ HEPATITIS B SEROLOGY AS A GRID — each marker answers one question.",
    "HBsAg — is the infection present NOW? Positive means the virus is in the body.",
    "anti-HBc IgM — is it ACUTE? A marker of recent infection.",
    "anti-HBc IgG — has infection EVER occurred? It stays positive for life.",
    "WARNING, AND THE KEY POINT: anti-HBc IS NEVER PRODUCED BY THE VACCINE, only by real infection.",
    "anti-HBs — is there IMMUNITY? Whether from vaccine or from recovery.",
    "HBeAg and HBV DNA — how active is replication and how infectious is the patient?",
    "So memorise the three main patterns together:",
    "VACCINATED: anti-HBs alone. No other marker.",
    "PAST, RESOLVED INFECTION: anti-HBs positive PLUS anti-HBc IgG.",
    "WARNING, CHRONIC INFECTION: HBsAg positive beyond 6 months, anti-HBc IgG positive, anti-HBs negative.",
    "And now the rule that solves several questions:",
    "IN A PATIENT ALREADY KNOWN TO BE HBsAg POSITIVE, anti-HBc ADDS NOTHING NEW.",
    "Because once we know infection is present, learning that 'infection has occurred' is useless.",
    "WARNING, AND DO NOT JUDGE SEVERITY BY THE LIVER ENZYMES — judge it by SYNTHETIC FUNCTION.",
    "ALT and AST show how many hepatocytes are being damaged, not how well the liver WORKS.",
    "The real measure of severity: the PROTHROMBIN TIME (PT/INR), then bilirubin and blood glucose.",
    "WARNING: A FALLING ALT WITH A RISING INR IS NOT IMPROVEMENT — IT IS LIVER FAILURE.",
    "Because so many hepatocytes have died that there is no enzyme left to release.",
]


# =========================================================== book:640
add("book:640", "case", "easy",
 "سه C پیش از راش + **لکه‌های کوپلیک** + راش از پیشانی به پایین ← **سرخک**.",
 "The three Cs before the rash, KOPLIK SPOTS, and a rash spreading down from the forehead: MEASLES.",
 EX_FA + [
  "**این سؤال هر سه سرنخ کلاسیک سرخک را در یک جا گذاشته است.**",
  "**سرنخ یک — پرودروم یک‌هفته‌ای: تب، آبریزش بینی، سرفه، قرمزی چشم‌ها.**",
  "**همان سه C، که در سرخجه یا مخملک این‌قدر برجسته نیستند.**",
  "⚠️ **سرنخ دو — ضایعات سفید در مخاط دهان: لکه‌های کوپلیک، پاتوگنومونیک سرخک.**",
  "**توصیفشان: نقاط سفید مایل به آبی با هاله‌ی قرمز، مقابل دندان‌های آسیا.**",
  "**و پنجره‌ی دیدنشان کوتاه است: ۱ تا ۲ روز پیش از راش، و با آمدن راش محو می‌شوند.**",
  "**سرنخ سه — راش از پیشانی شروع شده و گسترش یافته: الگوی سرخک، از بالا به پایین.**",
  "⚠️ **و در سرخجه، برخلاف سرخک، پرودروم ناچیز است و راش به‌هم نمی‌پیوندد.**",
  "**در مخملک، راش سنباده‌ای و زبان توت‌فرنگی است و منشأش استرپتوکوک است، نه ویروس.**",
  "**و در آبله‌مرغان، راش وزیکولر و در مراحل مختلف است، نه ماکولوپاپولر یکنواخت.**",
 ],
 EX_EN + [
  "This question places all three classic measles clues in one stem.",
  "CLUE ONE — a week-long prodrome: fever, coryza, cough, red eyes.",
  "Those are the three Cs, which are not nearly so prominent in rubella or scarlet fever.",
  "WARNING, CLUE TWO — white lesions on the buccal mucosa: KOPLIK SPOTS, pathognomonic of measles.",
  "Their description: bluish-white dots with a red halo, opposite the molars.",
  "And the window to see them is short: 1 to 2 days before the rash, fading as it appears.",
  "CLUE THREE — a rash beginning on the forehead and spreading: the measles pattern, top downwards.",
  "WARNING, AND IN RUBELLA, unlike measles, the prodrome is trivial and the rash does not become confluent.",
  "In scarlet fever the rash is sandpapery with a strawberry tongue, and its cause is streptococcal, not viral.",
  "And in chickenpox the rash is vesicular and in different stages, not a uniform maculopapular one.",
 ],
 "این ساده‌ترین سؤال بلوک سرخک است و باید مثل یک رفلکس پاسخ داده شود — چون **هر سه سرنخ "
 "کلاسیک** در یک صورت سؤال جمع شده‌اند.\n\n"
 "**خانم جوان** با **تب و بثورات ماکولوپاپولر که از پیشانی شروع شده و گسترش یافته**، که "
 "**از یک هفته قبل** دچار **تب، آبریزش بینی، سرفه و قرمزی چشم‌ها** بوده، و در معاینه "
 "**ضایعات سفید رنگ در مخاط دهان** دارد.\n\n"
 "⚠️ **سرنخ یک — پرودروم: سه C.**\n\n"
 "**Cough (سرفه) · Coryza (آبریزش بینی) · Conjunctivitis (قرمزی چشم)**\n\n"
 "این سه، **سه تا چهار روز پیش از راش** شروع می‌شوند و بیمار را **بسیار بدحال** می‌کنند. "
 "**در سرخجه، پرودروم چنان خفیف است که اغلب اصلاً به یاد نمی‌ماند.** پس همین یک ویژگی، "
 "سرخجه را به حاشیه می‌برد.\n\n"
 "⚠️ **سرنخ دو — لکه‌های کوپلیک: پاتوگنومونیک.**\n\n"
 "«ضایعات سفید رنگ در مخاط دهان» توصیف **لکه‌های کوپلیک** است: **نقاط سفید مایل به آبی با "
 "هاله‌ی قرمز، روی مخاط گونه مقابل دندان‌های آسیا**.\n\n"
 "**«پاتوگنومونیک» یعنی: اگر آن را دیدید، تشخیص قطعی است.** هیچ بیماری دیگری این ضایعه "
 "را نمی‌سازد.\n\n"
 "**ولی یک هشدار عملی:** پنجره‌ی دیدنشان **کوتاه** است — **۱ تا ۲ روز پیش از راش ظاهر "
 "می‌شوند و با آمدن راش محو می‌شوند**. پس اگر بیمار دیر مراجعه کند، دیگر دیده نمی‌شوند و "
 "نبودنشان سرخک را رد نمی‌کند.\n\n"
 "⚠️ **سرنخ سه — الگوی گسترش راش.**\n\n"
 "راش سرخک **از پیشانی و پشت گوش شروع می‌شود و به پایین گسترش می‌یابد** (سفالوکودال)، و "
 "با گذشت زمان **به‌هم می‌پیوندد (confluent)**.\n\n"
 "**تشخیص: سرخک.** ✅\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**سرخجه** — پرودروم ناچیز، راش که **به‌هم نمی‌پیوندد**، و مشخصه‌اش **لنفادنوپاتی پشت "
 "گوش و پس‌سریِ حساس** است که اینجا ذکر نشده. ضمناً **کوپلیک ندارد**.\n\n"
 "**تب مخملک** — راشش **سنباده‌ای** است (بافت زبر مثل کاغذ سنباده)، با **زبان توت‌فرنگی** "
 "و **رنگ‌پریدگی دور دهان**. منشأش **استرپتوکوک گروه A** است، نه ویروس.\n\n"
 "**آبله‌مرغان** — راشش **وزیکولر و در مراحل مختلف** است، نه ماکولوپاپولر یکنواخت.",
 "This is the simplest question in the measles block and should be answered as a reflex, because "
 "ALL THREE CLASSIC CLUES sit in one stem.\n\n"
 "A YOUNG WOMAN with FEVER AND A MACULOPAPULAR RASH BEGINNING ON THE FOREHEAD AND SPREADING, who "
 "for A WEEK has had FEVER, CORYZA, COUGH AND RED EYES, and on examination has WHITE LESIONS ON THE "
 "BUCCAL MUCOSA.\n\n"
 "WARNING, CLUE ONE — THE PRODROME: THE THREE Cs.\n\n"
 "COUGH · CORYZA · CONJUNCTIVITIS\n\n"
 "These begin THREE TO FOUR DAYS BEFORE THE RASH and make the patient MARKEDLY UNWELL. IN RUBELLA "
 "THE PRODROME IS SO MILD IT IS OFTEN NOT REMEMBERED AT ALL. So this single feature already pushes "
 "rubella aside.\n\n"
 "WARNING, CLUE TWO — KOPLIK SPOTS: PATHOGNOMONIC.\n\n"
 "'White lesions on the buccal mucosa' describes KOPLIK SPOTS: BLUISH-WHITE DOTS WITH A RED HALO on "
 "the buccal mucosa opposite the molars.\n\n"
 "'PATHOGNOMONIC' MEANS: if you see it, the diagnosis is certain. No other disease produces it.\n\n"
 "But a practical warning: THE WINDOW IS SHORT — they appear 1 TO 2 DAYS BEFORE THE RASH AND FADE "
 "AS IT ARRIVES. So in a late presentation they are gone, and their absence does not exclude "
 "measles.\n\n"
 "WARNING, CLUE THREE — THE PATTERN OF SPREAD.\n\n"
 "The measles rash BEGINS ON THE FOREHEAD AND BEHIND THE EARS AND SPREADS DOWNWARDS "
 "(cephalocaudal), and with time BECOMES CONFLUENT.\n\n"
 "DIAGNOSIS: MEASLES.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "RUBELLA — a trivial prodrome, a rash that DOES NOT BECOME CONFLUENT, and characteristically TENDER "
 "POSTERIOR AURICULAR AND OCCIPITAL NODES, not mentioned here. It also HAS NO KOPLIK SPOTS.\n\n"
 "SCARLET FEVER — its rash is SANDPAPERY, with a STRAWBERRY TONGUE and CIRCUMORAL PALLOR. Its cause "
 "is GROUP A STREPTOCOCCUS, not a virus.\n\n"
 "CHICKENPOX — its rash is VESICULAR AND IN DIFFERENT STAGES, not a uniform maculopapular one.",
 ["پاسخ صحیح — سه C، لکه‌های کوپلیک و راش از بالا به پایین: تابلوی کامل سرخک.",
  "در سرخجه پرودروم ناچیز است، راش به‌هم نمی‌پیوندد و لکه‌ی کوپلیک وجود ندارد.",
  "در مخملک راش سنباده‌ای با زبان توت‌فرنگی است و عامل آن استرپتوکوک گروه A است.",
  "در آبله‌مرغان راش وزیکولر و در مراحل مختلف است، نه ماکولوپاپولر یکنواخت."],
 ["Correct — the three Cs, Koplik spots and a top-down rash: the complete measles picture.",
  "In rubella the prodrome is trivial, the rash is not confluent, and there are no Koplik spots.",
  "In scarlet fever the rash is sandpapery with a strawberry tongue, caused by group A streptococcus.",
  "In chickenpox the rash is vesicular and in different stages, not a uniform maculopapular one."],
 "**سه C، بعد کوپلیک، بعد راش از بالا به پایین.** کوپلیک پاتوگنومونیک است ولی زودگذر.",
 "Three Cs, then Koplik spots, then a rash spreading top-down; Koplik spots are pathognomonic but fleeting.",
 [H199, PINKBOOK])


# =========================================================== book:646
add("book:646", "case", "hard",
 "سرخک ← تنها درمان با فایده‌ی اثبات‌شده بر مرگ‌ومیر: **ویتامین A، دو روز**.",
 "Measles: the only treatment with a proven mortality benefit is VITAMIN A FOR TWO DAYS.",
 EX_FA + [
  "**در سرخک هیچ داروی ضدویروسی اختصاصی وجود ندارد — و این نکته‌ی محوری است.**",
  "**پس درمان دو بخش دارد: حمایتی، و یک مداخله‌ی اثبات‌شده.**",
  "⚠️ **آن مداخله ویتامین A است، و تنها درمانی است که مرگ‌ومیر سرخک را کم می‌کند.**",
  "**دوز: ۲۰۰٬۰۰۰ واحد بین‌المللی روزانه، دو روز پشت سر هم (در بالای یک سال).**",
  "**در ۶ تا ۱۱ ماهگی: ۱۰۰٬۰۰۰ واحد. زیر ۶ ماه: ۵۰٬۰۰۰ واحد.**",
  "⚠️ **چرا ویتامین A؟ چون سرخک ذخیره‌ی ویتامین A کبد را به‌سرعت تخلیه می‌کند.**",
  "**و ویتامین A برای سلامت اپیتلیوم تنفسی و گوارشی و برای عملکرد ایمنی لازم است.**",
  "**پس کمبود آن، پنومونی و اسهال و کوری قرنیه‌ای پس از سرخک را چند برابر می‌کند.**",
  "**سازمان جهانی بهداشت آن را برای همه‌ی کودکان مبتلا به سرخک توصیه می‌کند،**",
  "**حتی در کشورهایی که کمبود ویتامین A در آن‌ها شایع نیست.**",
  "⚠️ **و مطالعات کاهش معنادار مرگ‌ومیر را نشان داده‌اند، به‌ویژه در کودکان زیر دو سال.**",
  "**ایمونوگلوبولین جای دیگری دارد: پروفیلاکسی پس از تماس، نه درمان بیماری مستقر.**",
 ],
 EX_EN + [
  "There is NO specific antiviral for measles — and that is the central point.",
  "So treatment has two parts: supportive care, and one proven intervention.",
  "WARNING: THAT INTERVENTION IS VITAMIN A, the only treatment that reduces measles mortality.",
  "DOSE: 200,000 international units daily for two consecutive days (over one year of age).",
  "At 6 to 11 months: 100,000 units. Under 6 months: 50,000 units.",
  "WARNING, WHY VITAMIN A? Because measles rapidly depletes the liver's vitamin A stores.",
  "And vitamin A is required for respiratory and gut epithelial integrity and for immune function.",
  "So its deficiency multiplies post-measles pneumonia, diarrhoea and corneal blindness.",
  "The World Health Organization recommends it for EVERY child with measles,",
  "even in countries where vitamin A deficiency is not common.",
  "WARNING, AND TRIALS SHOW A SIGNIFICANT MORTALITY REDUCTION, especially under two years of age.",
  "Immunoglobulin has a different place: POST-EXPOSURE PROPHYLAXIS, not treatment of established disease.",
 ],
 "این سؤال یک نکته‌ی درمانی را می‌سنجد که **بسیار پرتکرار است و اغلب فراموش می‌شود**.\n\n"
 "**پسر ۲۰ ساله** با پرودروم چهارروزه‌ی **تب، آبریزش بینی، سردرد و سرفه‌ی خشک**، و از "
 "امروز **راش در صورت، تنه و اندام**. در معاینه **T=39**، **ملتحمه محتقن**، و "
 "**ضایعات سفید مایل به آبی در مخاط دهان**.\n\n"
 "**تشخیص روشن است: سرخک** (سه C + کوپلیک + راش).\n\n"
 "⚠️ **حالا سؤال واقعی: چه درمانی مجاز است؟**\n\n"
 "**و نکته‌ی محوری این است: در سرخک هیچ داروی ضدویروسی اختصاصی وجود ندارد.**\n\n"
 "پس درمان دو بخش دارد: **حمایتی** (مایعات، تب‌بر، تغذیه) و **یک مداخله‌ی اثبات‌شده**.\n\n"
 "**آن مداخله: ویتامین A.**\n\n"
 "**دوز: ۲۰۰٬۰۰۰ واحد بین‌المللی روزانه، دو روز پشت سر هم** (برای بالای یک سال). "
 "در ۶ تا ۱۱ ماهگی ۱۰۰٬۰۰۰ واحد، و زیر ۶ ماه ۵۰٬۰۰۰ واحد.\n\n"
 "⚠️ **و حالا چرا؟ این بخش را بفهمید تا هرگز فراموش نکنید:**\n\n"
 "**۱) سرخک ذخیره‌ی ویتامین A کبد را به‌سرعت تخلیه می‌کند.** حتی کودکی که پیش از بیماری "
 "ذخیره‌ی طبیعی داشته، در جریان سرخک دچار کمبود حاد می‌شود.\n\n"
 "**۲) ویتامین A برای سلامت اپیتلیوم لازم است** — اپیتلیوم تنفسی، گوارشی و **قرنیه**.\n\n"
 "**۳) و برای عملکرد ایمنی هم ضروری است.**\n\n"
 "**پس کمبودش مستقیماً سه عارضه‌ی کشنده‌ی سرخک را تشدید می‌کند:** **پنومونی**، **اسهال "
 "شدید**، و **کوری قرنیه‌ای (کراتومالاسی)**.\n\n"
 "⚠️ **و نتیجه‌ی بالینی: مطالعات کاهش معنادار مرگ‌ومیر را نشان داده‌اند، به‌ویژه در کودکان "
 "زیر دو سال. به همین دلیل سازمان جهانی بهداشت آن را برای همه‌ی بیماران مبتلا به سرخک "
 "توصیه می‌کند — حتی در کشورهایی که کمبود ویتامین A شایع نیست.**\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**ویتامین B12** — هیچ نقشی در سرخک ندارد. (⚠️ توجه: دوز این گزینه در متن استخراج‌شده "
 "«mg0001» بود که تصحیح شد و «۱۰۰۰ mg» است. تصحیح شد تا دانشجو بتواند گزینه را بخواند و "
 "**به دلیل درست** ردش کند — نه به‌خاطر ناخوانا بودن.)\n\n"
 "**سرم ایمونوگلوبولین** — جای درستی دارد، ولی **جای دیگری**: **پروفیلاکسی پس از تماس** "
 "در فرد مستعد پرخطر، **نه درمان بیماری مستقر**. وقتی راش ظاهر شده، ویرمی گذشته و "
 "ایمونوگلوبولین دیگر کاری نمی‌کند.\n\n"
 "**IVIG** — همان اشکال، با هزینه‌ی بسیار بیشتر.",
 "This question tests a therapeutic point that IS FREQUENTLY EXAMINED AND OFTEN FORGOTTEN.\n\n"
 "A 20-YEAR-OLD MAN with a four-day prodrome of FEVER, CORYZA, HEADACHE AND DRY COUGH, and from "
 "today A RASH on the face, trunk and limbs. On examination T = 39, CONGESTED CONJUNCTIVAE, and "
 "BLUISH-WHITE LESIONS ON THE BUCCAL MUCOSA.\n\n"
 "THE DIAGNOSIS IS CLEAR: MEASLES (three Cs plus Koplik spots plus the rash).\n\n"
 "WARNING, NOW THE REAL QUESTION: WHAT TREATMENT IS PERMITTED?\n\n"
 "AND THE CENTRAL POINT IS THIS: THERE IS NO SPECIFIC ANTIVIRAL FOR MEASLES.\n\n"
 "So treatment has two parts: SUPPORTIVE (fluids, antipyretics, nutrition) and ONE PROVEN "
 "INTERVENTION.\n\n"
 "THAT INTERVENTION: VITAMIN A.\n\n"
 "DOSE: 200,000 INTERNATIONAL UNITS DAILY FOR TWO CONSECUTIVE DAYS (over one year). At 6 to 11 "
 "months, 100,000 units; under 6 months, 50,000.\n\n"
 "WARNING, AND NOW WHY? Understand this part and you will never forget it:\n\n"
 "1) MEASLES RAPIDLY DEPLETES THE LIVER'S VITAMIN A STORES. Even a child with normal stores before "
 "the illness becomes acutely deficient during it.\n\n"
 "2) VITAMIN A IS REQUIRED FOR EPITHELIAL INTEGRITY — respiratory, gastrointestinal and CORNEAL.\n\n"
 "3) AND IT IS ESSENTIAL FOR IMMUNE FUNCTION.\n\n"
 "SO ITS DEFICIENCY DIRECTLY WORSENS THE THREE LETHAL COMPLICATIONS OF MEASLES: PNEUMONIA, SEVERE "
 "DIARRHOEA, and CORNEAL BLINDNESS (keratomalacia).\n\n"
 "WARNING, AND THE CLINICAL RESULT: trials show A SIGNIFICANT MORTALITY REDUCTION, especially under "
 "two years. That is why the WHO recommends it for EVERY measles patient — even in countries where "
 "vitamin A deficiency is not common.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "VITAMIN B12 — has no role whatever in measles. (WARNING, note: this option's dose read 'mg0001' "
 "in the extracted text and was repaired to 1000 mg. It was repaired so the student can READ the "
 "option and reject it FOR THE RIGHT REASON — not because it was illegible.)\n\n"
 "IMMUNOGLOBULIN SERUM — has a proper place, but A DIFFERENT ONE: POST-EXPOSURE PROPHYLAXIS in a "
 "susceptible high-risk contact, NOT treatment of established disease. Once the rash has appeared "
 "the viraemia is over and immunoglobulin achieves nothing.\n\n"
 "IVIG — the same objection, at far greater cost.",
 ["پاسخ صحیح — ویتامین A دویست‌هزار واحد روزانه برای ۲ روز، تنها درمان با فایده‌ی اثبات‌شده بر مرگ‌ومیر.",
  "ویتامین ب۱۲ هیچ نقشی در درمان سرخک ندارد و در هیچ راهنمایی توصیه نشده است.",
  "ایمونوگلوبولین جای پروفیلاکسی پس از تماس است، نه درمان بیماری مستقر با راش ظاهرشده.",
  "IVIG همان اشکال ایمونوگلوبولین را دارد، با هزینه و عوارض بیشتر."],
 ["Correct — vitamin A 200,000 units daily for 2 days, the only treatment with a proven mortality benefit.",
  "Vitamin B12 has no role in measles treatment and is recommended by no guideline.",
  "Immunoglobulin belongs to post-exposure prophylaxis, not to established disease with a rash already out.",
  "IVIG shares immunoglobulin's objection, at greater cost and with more adverse effects."],
 "**سرخک داروی ضدویروسی ندارد؛ ویتامین A تنها چیزی است که مرگ‌ومیر را کم می‌کند.**",
 "Measles has no antiviral; vitamin A is the only thing that lowers its mortality.",
 [WHOVITA, H199])


# =========================================================== book:644
add("book:644", "case", "hard",
 "تماس با سرخک در **نقص ایمنی** ← واکسن زنده ممنوع ← **ایمونوگلوبولین سرخک**.",
 "Measles exposure in an IMMUNOCOMPROMISED patient: the live vaccine is forbidden, so MEASLES IMMUNOGLOBULIN.",
 EX_FA + [
  "**در این سؤال، دو داده با هم تصمیم را می‌سازند و باید هر دو دیده شوند.**",
  "**داده‌ی یک — تماس دیروز با یک مورد سرخک، یعنی هنوز در پنجره‌ی پروفیلاکسی هستیم.**",
  "**داده‌ی دو — لوکمی تحت شیمی‌درمانی، یعنی نقص ایمنی سلولی شدید.**",
  "⚠️ **و داده‌ی دوم واکسن را حذف می‌کند: واکسن سرخک (MMR) زنده‌ی ضعیف‌شده است.**",
  "**در نقص ایمنی سلولی، ویروس واکسن می‌تواند تکثیر یابد و بیماری واقعی بسازد.**",
  "**پس در این بیمار، واکسن نه‌تنها بی‌فایده، که خطرناک است.**",
  "**می‌ماند ایمونوگلوبولین سرخک — ایمنی غیرفعال و فوری، بدون هیچ ویروس زنده‌ای.**",
  "⚠️ **پنجره‌ی زمانی‌اش: تا ۶ روز پس از تماس.**",
  "**و پنجره‌ی واکسن، در فرد واجد شرایط، کوتاه‌تر است: تا ۷۲ ساعت.**",
  "**سه گروهی که پس از تماس با سرخک ایمونوگلوبولین می‌گیرند را حفظ کنید:**",
  "**نقص ایمنی، زن باردار غیرایمن، و شیرخوار زیر ۱۲ ماه.**",
  "⚠️ **و نکته‌ی مهم: سابقه‌ی واکسیناسیون کامل در کودکی، این بیمار را محافظت نمی‌کند.**",
  "**چون شیمی‌درمانی، ایمنی حاصل از واکسن را هم تضعیف می‌کند.**",
 ],
 EX_EN + [
  "Two pieces of data build the decision here, and both must be seen.",
  "DATUM ONE — contact yesterday with a measles case, so we are still inside the prophylaxis window.",
  "DATUM TWO — leukaemia on chemotherapy, that is severe cellular immunodeficiency.",
  "WARNING, AND THE SECOND DATUM ELIMINATES THE VACCINE: the measles vaccine (MMR) is LIVE ATTENUATED.",
  "In cellular immunodeficiency the vaccine virus can replicate and cause real disease.",
  "So in this patient the vaccine is not merely useless but dangerous.",
  "That leaves MEASLES IMMUNOGLOBULIN — immediate passive immunity with no live virus at all.",
  "WARNING, ITS WINDOW: up to 6 days after exposure.",
  "And the vaccine's window, in an eligible person, is shorter: within 72 hours.",
  "Memorise the three groups who receive immunoglobulin after measles exposure:",
  "the immunocompromised, the non-immune pregnant woman, and the infant under 12 months.",
  "WARNING, AND AN IMPORTANT POINT: a complete childhood vaccination history does NOT protect this patient.",
  "Because chemotherapy also erodes vaccine-derived immunity.",
 ],
 "این سؤال همان ساختار «سه فیلتر» بلوک آبله‌مرغان را دارد، ولی برای سرخک — و همین تقارن، "
 "یادگیری‌اش را آسان می‌کند.\n\n"
 "**آقای جوان مبتلا به لوکمی تحت شیمی‌درمانی**، که **دیروز با بیمار مبتلا به سرخک تماس "
 "داشته**، و **سابقه‌ی واکسیناسیون کامل در کودکی** را ذکر می‌کند.\n\n"
 "⚠️ **دام اول: «سابقه‌ی واکسیناسیون کامل».**\n\n"
 "دانشجو ممکن است فکر کند «واکسینه است، پس ایمن است، پس نیازی نیست». **این غلط است.**\n\n"
 "**شیمی‌درمانی نه‌تنها ایمنی سلولی را از بین می‌برد، بلکه ایمنی حاصل از واکسن را هم "
 "تضعیف می‌کند.** یک بیمار لوکمیک تحت شیمی‌درمانی، **صرف‌نظر از سابقه‌ی واکسنش**، در برابر "
 "سرخک آسیب‌پذیر تلقی می‌شود.\n\n"
 "**و سرخک در بیمار دچار نقص ایمنی بسیار خطرناک است:** پنومونی سلول ژانت، انسفالیت "
 "پیش‌رونده، و مرگ‌ومیر بالا. ضمناً در این بیماران **راش ممکن است اصلاً ظاهر نشود**، که "
 "تشخیص را دشوارتر می‌کند.\n\n"
 "⚠️ **دام دوم، و مهم‌تر: واکسن سرخک.**\n\n"
 "**واکسن سرخک (MMR) یک واکسن زنده‌ی ضعیف‌شده است.** در بیمار با **نقص ایمنی سلولی**، "
 "**خودِ ویروس واکسن می‌تواند تکثیر یابد و بیماری واقعی بسازد**. پس واکسن اینجا "
 "**نه‌تنها بی‌فایده، که خطرناک** است.\n\n"
 "**پس چه می‌ماند؟ ایمونوگلوبولین سرخک.** ✅\n\n"
 "**چرا کار می‌کند؟** ایمونوگلوبولین **آنتی‌بادی آماده** می‌دهد — **ایمنی غیرفعال و فوری**، "
 "**بدون هیچ ویروس زنده‌ای**. پس در نقص ایمنی کاملاً بی‌خطر است.\n\n"
 "⚠️ **دو پنجره‌ی زمانی را با هم حفظ کنید:**\n\n"
 "• **واکسن** (در فرد واجد شرایط، بدون نقص ایمنی): **تا ۷۲ ساعت** پس از تماس\n"
 "• **ایمونوگلوبولین**: **تا ۶ روز** پس از تماس\n\n"
 "**بیمار ما دیروز تماس داشته — یعنی در هر دو پنجره هست. ولی واکسن ممنوع است، پس "
 "ایمونوگلوبولین.**\n\n"
 "**سه گروهی که پس از تماس با سرخک ایمونوگلوبولین می‌گیرند:**\n\n"
 "**۱) افراد با نقص ایمنی** (مثل این بیمار)\n\n"
 "**۲) زن باردار غیرایمن**\n\n"
 "**۳) شیرخوار زیر ۱۲ ماه** (که هنوز واکسن نگرفته)\n\n"
 "**و چرا آسیکلوویر نه؟** آسیکلوویر روی **ویروس‌های خانواده‌ی هرپس** (واریسلا، HSV) کار "
 "می‌کند. **سرخک یک پارامیکسوویروس است** و هیچ ارتباطی با آن خانواده ندارد.",
 "This question has the same 'three filters' structure as the chickenpox block, but for measles — "
 "and that symmetry makes it easy to learn.\n\n"
 "A YOUNG MAN WITH LEUKAEMIA ON CHEMOTHERAPY who HAD CONTACT YESTERDAY with a measles case, and who "
 "reports A COMPLETE CHILDHOOD VACCINATION HISTORY.\n\n"
 "WARNING, THE FIRST TRAP: 'COMPLETE VACCINATION HISTORY'.\n\n"
 "A student may think 'he is vaccinated, therefore immune, therefore nothing is needed'. THAT IS "
 "WRONG.\n\n"
 "CHEMOTHERAPY DESTROYS NOT ONLY CELLULAR IMMUNITY BUT ALSO VACCINE-DERIVED IMMUNITY. A leukaemic "
 "patient on chemotherapy is regarded as SUSCEPTIBLE to measles REGARDLESS OF VACCINATION HISTORY.\n\n"
 "AND MEASLES IN AN IMMUNOCOMPROMISED PATIENT IS VERY DANGEROUS: giant-cell pneumonia, progressive "
 "encephalitis, and high mortality. In such patients THE RASH MAY NEVER APPEAR, making the diagnosis "
 "even harder.\n\n"
 "WARNING, THE SECOND AND MORE IMPORTANT TRAP: THE MEASLES VACCINE.\n\n"
 "THE MEASLES VACCINE (MMR) IS LIVE ATTENUATED. In a patient with CELLULAR IMMUNODEFICIENCY, THE "
 "VACCINE VIRUS ITSELF CAN REPLICATE AND CAUSE REAL DISEASE. So the vaccine here is NOT MERELY "
 "USELESS BUT DANGEROUS.\n\n"
 "SO WHAT REMAINS? MEASLES IMMUNOGLOBULIN.\n\n"
 "WHY DOES IT WORK? Immunoglobulin supplies READY-MADE ANTIBODY — IMMEDIATE PASSIVE IMMUNITY, WITH "
 "NO LIVE VIRUS. So it is entirely safe in immunodeficiency.\n\n"
 "WARNING, MEMORISE THE TWO TIME WINDOWS TOGETHER:\n\n"
 "• VACCINE (in an eligible, non-immunocompromised person): WITHIN 72 HOURS of exposure\n"
 "• IMMUNOGLOBULIN: UP TO 6 DAYS after exposure\n\n"
 "Our patient was exposed yesterday — inside both windows. But the vaccine is forbidden, so "
 "immunoglobulin it is.\n\n"
 "THE THREE GROUPS WHO RECEIVE IMMUNOGLOBULIN AFTER MEASLES EXPOSURE:\n\n"
 "1) THE IMMUNOCOMPROMISED (like this patient)\n\n"
 "2) THE NON-IMMUNE PREGNANT WOMAN\n\n"
 "3) THE INFANT UNDER 12 MONTHS (not yet vaccinated)\n\n"
 "AND WHY NOT ACICLOVIR? Aciclovir works on the HERPES FAMILY (varicella, HSV). MEASLES IS A "
 "PARAMYXOVIRUS and has nothing to do with that family.",
 ["آسیکلوویر روی ویروس‌های خانواده‌ی هرپس اثر دارد؛ سرخک پارامیکسوویروس است و پاسخ نمی‌دهد.",
  "واکسن سرخک زنده‌ی ضعیف‌شده است و در نقص ایمنی سلولی ممنوع و خطرناک است.",
  "پاسخ صحیح — ایمونوگلوبولین سرخک ایمنی غیرفعال فوری می‌دهد و ویروس زنده ندارد.",
  "سابقه‌ی واکسن کودکی این بیمار را محافظت نمی‌کند، چون شیمی‌درمانی ایمنی واکسن را هم تضعیف می‌کند."],
 ["Aciclovir acts on the herpes family; measles is a paramyxovirus and does not respond.",
  "The measles vaccine is live attenuated and is forbidden and dangerous in cellular immunodeficiency.",
  "Correct — measles immunoglobulin gives immediate passive immunity and contains no live virus.",
  "A childhood vaccination history does not protect this patient, because chemotherapy erodes vaccine immunity too."],
 "**واکسن زنده در نقص ایمنی ممنوع؛ ایمونوگلوبولین تا ۶ روز، واکسن تا ۷۲ ساعت.**",
 "A live vaccine is forbidden in immunodeficiency; immunoglobulin works to 6 days, the vaccine to 72 hours.",
 [PINKBOOK, H199])


# =========================================================== book:649
add("book:649", "case", "hard",
 "**IgM سرخجه مثبت** در هفته‌ی ششم بارداری ← عفونت حاد ← **بررسی اندیکاسیون ختم حاملگی**.",
 "A POSITIVE RUBELLA IgM at six weeks' gestation means acute infection: ASSESS FOR TERMINATION.",
 EX_FA + [
  "⚠️ **در سرولوژی، IgM و IgG دو سؤال کاملاً متفاوت را پاسخ می‌دهند.**",
  "**IgM مثبت یعنی عفونت حاد و تازه — آنتی‌بادی اول که ظرف هفته‌ها محو می‌شود.**",
  "**IgG مثبت یعنی ایمنی، از عفونت گذشته یا واکسن — و مادام‌العمر می‌ماند.**",
  "**پس IgM مثبت با IgG منفی یا کم = عفونت همین حالا در حال رخ دادن.**",
  "⚠️ **و سرخجه‌ی حاد در سه‌ماهه‌ی اول، خطرناک‌ترین عفونت ویروسی بارداری است.**",
  "**خطر سندرم سرخجه‌ی مادرزادی را بر حسب هفته حفظ کنید — این عدد تصمیم می‌سازد:**",
  "**در ۱۱ هفته‌ی نخست: تا حدود ۹۰ درصد. یعنی تقریباً قطعی.**",
  "**هفته‌ی ۱۱ تا ۱۶: حدود ۱۰ تا ۲۰ درصد.**",
  "**پس از هفته‌ی ۲۰: خطر ناهنجاری عملاً ناچیز است.**",
  "⚠️ **سه‌گانه‌ی کلاسیک سندرم سرخجه‌ی مادرزادی: کاتاراکت، ناشنوایی، بیماری قلبی مادرزادی.**",
  "**و شایع‌ترین تک‌یافته، ناشنوایی حسی-عصبی است.**",
  "**هیچ درمانی وجود ندارد: نه ضدویروسی، نه ایمونوگلوبولین که از عفونت جنین جلوگیری کند.**",
  "⚠️ **پس در هفته‌ی ششم با IgM مثبت، تنها گفت‌وگوی صادقانه درباره‌ی ختم حاملگی است.**",
  "**و پیشگیری تنها راه واقعی است: واکسن پیش از بارداری، نه در حین آن.**",
 ],
 EX_EN + [
  "WARNING: IN SEROLOGY, IgM AND IgG ANSWER TWO ENTIRELY DIFFERENT QUESTIONS.",
  "A positive IgM means ACUTE, RECENT infection — the first antibody, which fades within weeks.",
  "A positive IgG means IMMUNITY, from past infection or vaccine — and it lasts for life.",
  "So a positive IgM with a negative or low IgG means infection is happening NOW.",
  "WARNING, AND ACUTE RUBELLA IN THE FIRST TRIMESTER IS THE MOST DANGEROUS VIRAL INFECTION OF PREGNANCY.",
  "Memorise the risk of congenital rubella syndrome by week — that number drives the decision:",
  "IN THE FIRST 11 WEEKS: up to about 90 per cent. Almost certain.",
  "WEEKS 11 TO 16: about 10 to 20 per cent.",
  "AFTER WEEK 20: the risk of malformation is effectively negligible.",
  "WARNING, THE CLASSIC TRIAD OF CONGENITAL RUBELLA SYNDROME: cataract, deafness, congenital heart disease.",
  "And the commonest single finding is SENSORINEURAL DEAFNESS.",
  "There is NO treatment: no antiviral, and no immunoglobulin that prevents fetal infection.",
  "WARNING, SO AT SIX WEEKS WITH A POSITIVE IgM, THE ONLY HONEST CONVERSATION IS ABOUT TERMINATION.",
  "And prevention is the only real answer: vaccinate BEFORE pregnancy, never during it.",
 ],
 "این سنگین‌ترین سؤال بلوک سرخجه است، و پاسخش یک تصمیم دشوار ولی روشن است.\n\n"
 "**خانم ۲۱ ساله در هفته‌ی ششم بارداری**، پس از **تب و آرترالژی اخیر**، با "
 "**Rubella IgM Ab مثبت**.\n\n"
 "⚠️ **گام یک — IgM مثبت یعنی چه؟**\n\n"
 "در سرولوژی، **IgM و IgG دو سؤال کاملاً متفاوت** را پاسخ می‌دهند:\n\n"
 "• **IgM** — اولین آنتی‌بادی که ساخته می‌شود، ظرف چند هفته محو می‌شود. **مثبت بودنش یعنی "
 "عفونت حاد و همین حالا.**\n\n"
 "• **IgG** — دیرتر می‌آید و **مادام‌العمر** می‌ماند. **مثبت بودنش یعنی ایمنی** (از عفونت "
 "گذشته یا واکسن).\n\n"
 "**پس IgM مثبت در این بیمار = سرخجه‌ی حاد، در هفته‌ی ششم بارداری.** و **تب و آرترالژی** "
 "هم دقیقاً تابلوی بالینی سرخجه در بزرگسال است.\n\n"
 "⚠️ **گام دو — و این چرا فاجعه است؟**\n\n"
 "**خطر سندرم سرخجه‌ی مادرزادی به‌شدت وابسته به هفته‌ی بارداری است:**\n\n"
 "• **در ۱۱ هفته‌ی نخست: تا حدود ۹۰ درصد** ← تقریباً قطعی\n"
 "• **هفته‌ی ۱۱ تا ۱۶: حدود ۱۰ تا ۲۰ درصد**\n"
 "• **پس از هفته‌ی ۲۰: عملاً ناچیز**\n\n"
 "**این بیمار در هفته‌ی ششم است — یعنی در بدترین بازه‌ی ممکن، با خطر نزدیک به ۹۰ درصد.**\n\n"
 "**سه‌گانه‌ی کلاسیک سندرم سرخجه‌ی مادرزادی:** **کاتاراکت · ناشنوایی · بیماری قلبی "
 "مادرزادی** (به‌ویژه PDA و تنگی شریان ریوی). و **شایع‌ترین تک‌یافته، ناشنوایی حسی-عصبی** "
 "است.\n\n"
 "⚠️ **گام سه — و حالا سخت‌ترین بخش: هیچ درمانی وجود ندارد.**\n\n"
 "**نه داروی ضدویروسی مؤثری هست، و نه ایمونوگلوبولینی که از عفونت جنین جلوگیری کند.** "
 "وقتی ویرمی مادر رخ داده و در هفته‌ی ششم است، **جنین با احتمال بسیار بالا آلوده شده "
 "است**.\n\n"
 "**پس تنها اقدام صادقانه: بررسی اندیکاسیون ختم حاملگی** — یعنی یک گفت‌وگوی کامل و شفاف با "
 "بیمار درباره‌ی خطر، پیامدها و گزینه‌ها. ✅\n\n"
 "**و چرا سه گزینه‌ی دیگر غلط‌اند؟**\n\n"
 "**ریباویرین** — روی سرخجه اثری ندارد، و ضمناً **در بارداری تراتوژن است** (یعنی خودش "
 "آسیب اضافه می‌کند).\n\n"
 "**واکسیناسیون** — واکسن سرخجه **زنده‌ی ضعیف‌شده** و **در بارداری ممنوع** است. ضمناً وقتی "
 "عفونت رخ داده، واکسن بی‌معناست.\n\n"
 "**ایمونوگلوبولین وریدی** — **از عفونت جنین جلوگیری نمی‌کند**. ممکن است علائم مادر را "
 "تخفیف دهد، ولی مسئله اینجا مادر نیست.\n\n"
 "⚠️ **و درس اصلی: تنها راه واقعی، پیشگیری است — واکسن پیش از بارداری. هر زن در سن "
 "باروری باید وضعیت ایمنی سرخجه‌اش مشخص باشد و در صورت نیاز، پیش از بارداری واکسینه "
 "شود.**",
 "This is the weightiest question in the rubella block, and its answer is a hard but clear "
 "decision.\n\n"
 "A 21-YEAR-OLD WOMAN AT SIX WEEKS' GESTATION, after RECENT FEVER AND ARTHRALGIA, with a POSITIVE "
 "RUBELLA IgM.\n\n"
 "WARNING, STEP ONE — WHAT DOES A POSITIVE IgM MEAN?\n\n"
 "In serology, IgM AND IgG ANSWER TWO ENTIRELY DIFFERENT QUESTIONS:\n\n"
 "• IgM — the first antibody made, fading within weeks. POSITIVE MEANS ACUTE INFECTION, HAPPENING "
 "NOW.\n\n"
 "• IgG — arrives later and PERSISTS FOR LIFE. POSITIVE MEANS IMMUNITY (past infection or vaccine).\n\n"
 "SO A POSITIVE IgM HERE MEANS ACUTE RUBELLA AT SIX WEEKS' GESTATION. And FEVER WITH ARTHRALGIA is "
 "exactly the adult clinical picture of rubella.\n\n"
 "WARNING, STEP TWO — WHY IS THAT A CATASTROPHE?\n\n"
 "THE RISK OF CONGENITAL RUBELLA SYNDROME DEPENDS SHARPLY ON GESTATIONAL WEEK:\n\n"
 "• IN THE FIRST 11 WEEKS: up to about 90 PER CENT -> almost certain\n"
 "• WEEKS 11 TO 16: about 10 to 20 per cent\n"
 "• AFTER WEEK 20: effectively negligible\n\n"
 "THIS PATIENT IS AT SIX WEEKS — the worst possible interval, with a risk near 90 per cent.\n\n"
 "THE CLASSIC TRIAD OF CONGENITAL RUBELLA SYNDROME: CATARACT · DEAFNESS · CONGENITAL HEART DISEASE "
 "(especially PDA and pulmonary artery stenosis). And THE COMMONEST SINGLE FINDING IS SENSORINEURAL "
 "DEAFNESS.\n\n"
 "WARNING, STEP THREE — AND NOW THE HARDEST PART: THERE IS NO TREATMENT.\n\n"
 "THERE IS NO EFFECTIVE ANTIVIRAL, AND NO IMMUNOGLOBULIN THAT PREVENTS FETAL INFECTION. Once "
 "maternal viraemia has occurred at six weeks, THE FETUS IS VERY PROBABLY ALREADY INFECTED.\n\n"
 "SO THE ONLY HONEST ACTION IS TO ASSESS FOR TERMINATION — that is, a full and transparent "
 "discussion with the patient about the risk, the consequences and the options.\n\n"
 "AND WHY ARE THE OTHER THREE WRONG?\n\n"
 "RIBAVIRIN — has no effect on rubella, and is moreover TERATOGENIC IN PREGNANCY (it would add harm "
 "of its own).\n\n"
 "VACCINATION — the rubella vaccine is LIVE ATTENUATED and FORBIDDEN IN PREGNANCY. And once "
 "infection has occurred, a vaccine is meaningless.\n\n"
 "INTRAVENOUS IMMUNOGLOBULIN — DOES NOT PREVENT FETAL INFECTION. It may attenuate maternal symptoms, "
 "but the mother is not the problem here.\n\n"
 "WARNING, AND THE CENTRAL LESSON: THE ONLY REAL ANSWER IS PREVENTION — vaccination BEFORE "
 "pregnancy. Every woman of childbearing age should have her rubella immunity established and, if "
 "needed, be vaccinated before conceiving.",
 ["ریباویرین روی سرخجه اثری ندارد و در بارداری تراتوژن است، پس آسیب اضافه می‌کند.",
  "واکسن سرخجه زنده‌ی ضعیف‌شده و در بارداری ممنوع است؛ ضمناً پس از وقوع عفونت بی‌معناست.",
  "ایمونوگلوبولین وریدی از عفونت جنین جلوگیری نمی‌کند و مشکل را حل نمی‌کند.",
  "پاسخ صحیح — سرخجه‌ی حاد در هفته‌ی ششم با خطر نزدیک ۹۰ درصد، بررسی ختم حاملگی را ایجاب می‌کند."],
 ["Ribavirin has no effect on rubella and is teratogenic in pregnancy, so it would only add harm.",
  "The rubella vaccine is live attenuated and forbidden in pregnancy; and after infection it is meaningless.",
  "Intravenous immunoglobulin does not prevent fetal infection and does not solve the problem.",
  "Correct — acute rubella at six weeks, with a risk near 90 per cent, requires assessment for termination."],
 "**IgM = حاد، IgG = ایمنی.** و خطر سندرم مادرزادی در ۱۱ هفته‌ی اول تا ۹۰ درصد است.",
 "IgM means acute and IgG means immunity; and the congenital risk in the first 11 weeks reaches 90 per cent.",
 [H199, PINKBOOK])


# =========================================================== book:648
add("book:648", "case", "medium",
 "**IgG مثبت با IgM منفی** ← مادر از قبل ایمن بوده ← **فقط اطمینان دادن**.",
 "IgG POSITIVE WITH IgM NEGATIVE means the mother was already immune: JUST REASSURE HER.",
 EX_FA + [
  "**این سؤال دقیقاً قرینه‌ی سؤال IgM مثبت است، و باید کنار هم خوانده شوند.**",
  "**IgG مثبت و IgM منفی، یک الگوی کاملاً روشن دارد:**",
  "⚠️ **IgG مثبت یعنی ایمنی از پیش موجود — از عفونت گذشته یا واکسن.**",
  "**IgM منفی یعنی هیچ عفونت حادی در جریان نیست.**",
  "**و نکته‌ی زمانی مهم: آزمایش تنها ۲ روز پس از مواجهه انجام شده.**",
  "**در این فاصله، هیچ آنتی‌بادی تازه‌ای فرصت ساخته شدن نداشته است.**",
  "⚠️ **پس آن IgG مثبت نمی‌تواند از این مواجهه باشد — حتماً از قبل وجود داشته.**",
  "**و ایمنی از پیش موجود در برابر سرخجه، مادر و جنین را کاملاً محافظت می‌کند.**",
  "**عفونت مجدد سرخجه در فرد ایمن بسیار نادر است و اگر رخ دهد، ویرمی معناداری ندارد.**",
  "**پس هیچ اقدام تشخیصی یا درمانی لازم نیست: فقط اطمینان دادن.**",
  "⚠️ **و دام سؤال: توصیه به ختم بارداری در یک زن ایمن، یک خطای فاجعه‌بار است.**",
  "**همین‌طور تجویز ایمونوگلوبولین به کسی که خودش آنتی‌بادی کافی دارد، بی‌فایده است.**",
 ],
 EX_EN + [
  "This question is the exact mirror of the positive-IgM one, and they should be read together.",
  "IgG positive with IgM negative has one entirely clear meaning:",
  "WARNING: IgG POSITIVE MEANS PRE-EXISTING IMMUNITY — from past infection or vaccine.",
  "IgM NEGATIVE means no acute infection is under way.",
  "And an important timing point: the test was done only 2 DAYS after the exposure.",
  "In that interval no new antibody could possibly have been produced.",
  "WARNING: SO THAT POSITIVE IgG CANNOT COME FROM THIS EXPOSURE — it must have existed already.",
  "And pre-existing rubella immunity protects mother and fetus completely.",
  "Rubella reinfection in an immune person is very rare and, if it occurs, produces no meaningful viraemia.",
  "So no diagnostic or therapeutic step is needed: simply reassure.",
  "WARNING, AND THE TRAP: recommending termination to an immune woman would be a catastrophic error.",
  "Likewise, giving immunoglobulin to someone who already has adequate antibody is pointless.",
 ],
 "این سؤال **قرینه‌ی دقیق** سؤال «IgM مثبت» است. اگر آن یکی را فهمیده باشید، این یکی "
 "خودبه‌خود حل می‌شود — ولی **دام‌های خطرناک‌تری** دارد.\n\n"
 "**خانمی در هفته‌ی یازدهم بارداری** که **با بیمار مبتلا به سرخجه مواجهه داشته**. سرولوژی "
 "که **۲ روز پس از مواجهه** انجام شده: **IgM منفی، IgG مثبت**.\n\n"
 "⚠️ **گام یک — این الگو یعنی چه؟**\n\n"
 "• **IgG مثبت** = **ایمنی از پیش موجود** (از عفونت گذشته یا واکسن)\n"
 "• **IgM منفی** = **هیچ عفونت حادی در جریان نیست**\n\n"
 "⚠️ **گام دو — و حالا نکته‌ی زمانی که سؤال روی آن حساب کرده:**\n\n"
 "**آزمایش تنها ۲ روز پس از مواجهه انجام شده.**\n\n"
 "این عدد عمداً در صورت سؤال آمده. **در ۲ روز، هیچ آنتی‌بادی تازه‌ای فرصت ساخته شدن "
 "ندارد** (ساخت IgG هفته‌ها طول می‌کشد). **پس آن IgG مثبت قطعاً از این مواجهه نیست — "
 "حتماً از قبل وجود داشته است.**\n\n"
 "**نتیجه: این خانم پیش از مواجهه هم ایمن بوده. مواجهه هیچ خطری برایش نداشته.** ✅\n\n"
 "**پس پاسخ: اطمینان دادن به بیمار.**\n\n"
 "⚠️ **و حالا چرا سه گزینه‌ی دیگر نه‌تنها غلط، که برخی‌شان خطرناک‌اند:**\n\n"
 "**«توصیه به ختم بارداری»** — این **فاجعه‌بارترین پاسخ ممکن** است. ختم یک بارداری سالم "
 "در زنی که **کاملاً ایمن** است، آسیبی جبران‌ناپذیر و کاملاً بی‌مورد است.\n\n"
 "**«تجویز ایمونوگلوبولین اختصاصی»** — بی‌فایده است. **ایمونوگلوبولین آنتی‌بادی می‌دهد به "
 "کسی که خودش آنتی‌بادی دارد.** هزینه و تزریق، بدون هیچ سودی.\n\n"
 "**«تکرار سرولوژی ۲ هفته بعد»** — این گزینه **وسوسه‌انگیزترین** است، چون محتاطانه به نظر "
 "می‌رسد. ولی **بی‌مورد است**: وقتی IgG از پیش مثبت است، تکرار آزمایش هیچ اطلاعات جدیدی "
 "نمی‌دهد. (تکرار سرولوژی وقتی معنا دارد که **IgG منفی** باشد و بخواهیم ببینیم آیا "
 "سروکانورژن رخ می‌دهد.)\n\n"
 "⚠️ **درس این دو سؤال کنار هم:**\n\n"
 "> **IgG مثبت + IgM منفی ← ایمن، اطمینان بده**\n"
 "> **IgM مثبت ← عفونت حاد، و در سه‌ماهه‌ی اول یعنی فاجعه**\n\n"
 "**و اگر هر دو منفی بودند؟** آنگاه زن **مستعد** است و باید **۲ تا ۳ هفته بعد سرولوژی "
 "تکرار شود** تا سروکانورژن بررسی گردد — همان جایی که گزینه‌ی «تکرار سرولوژی» درست "
 "می‌شد.",
 "This question is the EXACT MIRROR of the positive-IgM one. If you understood that, this solves "
 "itself — but it carries MORE DANGEROUS traps.\n\n"
 "A WOMAN AT ELEVEN WEEKS' GESTATION who was EXPOSED TO A RUBELLA CASE. Serology taken TWO DAYS "
 "AFTER THE EXPOSURE: IgM NEGATIVE, IgG POSITIVE.\n\n"
 "WARNING, STEP ONE — WHAT DOES THIS PATTERN MEAN?\n\n"
 "• IgG POSITIVE = PRE-EXISTING IMMUNITY (past infection or vaccine)\n"
 "• IgM NEGATIVE = NO ACUTE INFECTION under way\n\n"
 "WARNING, STEP TWO — AND NOW THE TIMING POINT THE QUESTION IS BUILT ON:\n\n"
 "THE TEST WAS DONE ONLY TWO DAYS AFTER THE EXPOSURE.\n\n"
 "That number is in the stem deliberately. IN TWO DAYS NO NEW ANTIBODY CAN HAVE BEEN MADE (IgG "
 "production takes weeks). SO THAT POSITIVE IgG CANNOT COME FROM THIS EXPOSURE — it must have "
 "existed beforehand.\n\n"
 "CONCLUSION: this woman was already immune before the exposure. The exposure posed her no risk.\n\n"
 "SO THE ANSWER IS: REASSURE THE PATIENT.\n\n"
 "WARNING, AND NOW WHY THE OTHER THREE ARE NOT MERELY WRONG BUT SOME OF THEM DANGEROUS:\n\n"
 "'RECOMMEND TERMINATION' — THE MOST CATASTROPHIC POSSIBLE ANSWER. Ending a healthy pregnancy in a "
 "woman who is FULLY IMMUNE is irreversible and entirely unwarranted harm.\n\n"
 "'GIVE SPECIFIC IMMUNOGLOBULIN' — pointless. IMMUNOGLOBULIN GIVES ANTIBODY TO SOMEONE WHO ALREADY "
 "HAS IT. Cost and an injection, with no benefit.\n\n"
 "'REPEAT SEROLOGY IN 2 WEEKS' — the MOST TEMPTING option, because it looks cautious. But it is "
 "UNWARRANTED: when the IgG is already positive, repeating adds no information. (Repeat serology "
 "makes sense when the IgG is NEGATIVE and we want to see whether seroconversion occurs.)\n\n"
 "WARNING, THE LESSON OF THESE TWO QUESTIONS TOGETHER:\n\n"
 "> IgG POSITIVE PLUS IgM NEGATIVE -> immune, reassure\n"
 "> IgM POSITIVE -> acute infection, and in the first trimester a catastrophe\n\n"
 "AND IF BOTH WERE NEGATIVE? Then the woman is SUSCEPTIBLE and serology should be REPEATED IN 2 TO "
 "3 WEEKS to look for seroconversion — which is exactly where the 'repeat serology' option would "
 "have been right.",
 ["ایمونوگلوبولین به کسی که خودش IgG محافظ دارد، هیچ فایده‌ای اضافه نمی‌کند.",
  "توصیه به ختم بارداری در زنی که کاملاً ایمن است، خطایی فاجعه‌بار و جبران‌ناپذیر است.",
  "پاسخ صحیح — IgG مثبت با IgM منفی، ۲ روز پس از مواجهه، یعنی ایمنی از پیش موجود.",
  "تکرار سرولوژی وقتی معنا دارد که IgG منفی باشد؛ با IgG مثبت اطلاعات تازه‌ای نمی‌دهد."],
 ["Immunoglobulin adds nothing to someone who already has protective IgG.",
  "Recommending termination in a fully immune woman would be a catastrophic and irreversible error.",
  "Correct — IgG positive with IgM negative, two days after exposure, means pre-existing immunity.",
  "Repeating serology makes sense when the IgG is negative; with a positive IgG it adds nothing."],
 "**۲ روز برای ساخت آنتی‌بادی کافی نیست — پس IgG مثبت از قبل بوده.** ایمن است، اطمینان بده.",
 "Two days is not enough to make antibody, so a positive IgG predates the exposure; she is immune, reassure her.",
 [H199, PINKBOOK])


# =========================================================== book:851
add("book:851", "case", "hard",
 "هپاتیت حاد ← برای تعیین عامل، **IgM ضد HAV و IgM ضد HBc** را با هم بخواهید.",
 "In acute hepatitis, order IgM ANTI-HAV AND IgM ANTI-HBc TOGETHER to identify the agent.",
 HEP_FA + [
  "**در هپاتیت حاد، اولین سؤال «کدام ویروس؟» است — و پاسخ در نشانگرهای IgM است.**",
  "⚠️ **قاعده: برای عفونت حاد، همیشه سراغ IgM بروید، نه IgG و نه آنتی‌ژن به‌تنهایی.**",
  "**IgM ضد HAV: تنها نشانگر هپاتیت A حاد. مثبت یعنی همین حالا.**",
  "**IgM ضد HBc: نشانگر هپاتیت B حاد — و از HBsAg هم قابل اتکاتر است.**",
  "⚠️ **چرا از HBsAg هم بهتر؟ به‌خاطر «پنجره‌ی سرولوژیک».**",
  "**در فاصله‌ای از بهبود هپاتیت B، HBsAg منفی شده ولی anti-HBs هنوز نیامده.**",
  "**در آن پنجره، تنها نشانگر مثبت IgM ضد HBc است — و تنها راه تشخیص.**",
  "**پس درخواست هم‌زمان این دو، دو شایع‌ترین علت هپاتیت حاد را پوشش می‌دهد.**",
  "**و ALT در هزارها (اینجا ۱۷۰۰) به نفع هپاتیت ویروسی حاد است، نه انسدادی.**",
  "⚠️ **در انسداد صفراوی، ALP بیشتر بالا می‌رود و ALT معمولاً زیر چند صد می‌ماند.**",
  "**اینجا ALP=۴۸۰ در برابر ALT=۱۷۰۰: الگوی هپاتوسلولار، نه کلستاتیک.**",
  "**و PT طبیعی (۱۳/۱) یعنی عملکرد سنتزی کبد هنوز حفظ شده — نشانه‌ی خوب.**",
 ],
 HEP_EN + [
  "In acute hepatitis the first question is 'which virus?' — and the answer lies in the IgM markers.",
  "WARNING, THE RULE: for ACUTE infection always reach for IgM, not IgG and not an antigen alone.",
  "IgM anti-HAV: the only marker of acute hepatitis A. Positive means now.",
  "IgM anti-HBc: the marker of acute hepatitis B — and more reliable even than HBsAg.",
  "WARNING, WHY BETTER THAN HBsAg? Because of the SEROLOGICAL WINDOW.",
  "During part of the recovery from hepatitis B, HBsAg has cleared but anti-HBs has not yet appeared.",
  "In that window the ONLY positive marker is IgM anti-HBc — and the only route to a diagnosis.",
  "So requesting both together covers the two commonest causes of acute hepatitis.",
  "And an ALT in the thousands (1700 here) favours acute VIRAL hepatitis rather than obstruction.",
  "WARNING, IN BILIARY OBSTRUCTION the ALP rises more and the ALT usually stays below a few hundred.",
  "Here ALP 480 against ALT 1700: a HEPATOCELLULAR pattern, not a cholestatic one.",
  "And a normal PT (13.1) means synthetic function is still preserved — a good sign.",
 ],
 "این سؤال یک اصل ساده ولی بسیار پرکاربرد را می‌سنجد: **برای تشخیص عفونت حاد، سراغ IgM "
 "بروید.**\n\n"
 "**دختر ۱۶ ساله** با ۲ تا ۳ روز **تب، سردرد، تهوع و بی‌اشتهایی**، سپس **پررنگ شدن ادرار "
 "و زردی**. آزمایش‌ها: **AST=۱۳۰۰، ALT=۱۷۰۰، ALP=۴۸۰، LDH=۴۵۰، PT=۱۳/۱**.\n\n"
 "⚠️ **گام یک — الگوی آزمایش‌ها را بخوانید.**\n\n"
 "**ALT در هزارها (۱۷۰۰)** یک **الگوی هپاتوسلولار شدید** است. این عدد به نفع **هپاتیت "
 "ویروسی حاد** است.\n\n"
 "**و مقایسه‌ی ALT با ALP تعیین‌کننده است:**\n\n"
 "• **ALT=۱۷۰۰ در برابر ALP=۴۸۰** → **الگوی هپاتوسلولار**\n"
 "• اگر انسداد صفراوی بود، **ALP خیلی بیشتر بالا می‌رفت** و **ALT معمولاً زیر چند صد** "
 "می‌ماند\n\n"
 "**پس این هپاتیت ویروسی حاد است، نه انسداد.** و همین **گزینه‌ی سونوگرافی را حذف می‌کند**.\n\n"
 "**و یک نکته‌ی مثبت: PT=۱۳/۱ تقریباً طبیعی است** — یعنی **عملکرد سنتزی کبد هنوز حفظ "
 "شده**. این نشانه‌ی خوبی است و نارسایی حاد کبد را رد می‌کند.\n\n"
 "⚠️ **گام دو — حالا کدام ویروس؟ و اینجا اصل کلیدی وارد می‌شود:**\n\n"
 "> **برای عفونت حاد، همیشه سراغ IgM بروید.**\n\n"
 "**IgM ضد HAV** — تنها نشانگر **هپاتیت A حاد**. در نوجوان با شروع ناگهانی و پرودروم "
 "گوارشی، هپاتیت A بسیار محتمل است.\n\n"
 "**IgM ضد HBc** — نشانگر **هپاتیت B حاد**.\n\n"
 "⚠️ **و حالا نکته‌ای که ارزش این گزینه را دوچندان می‌کند: چرا IgM ضد HBc و نه HBsAg؟**\n\n"
 "به‌خاطر **«پنجره‌ی سرولوژیک»**. در سیر هپاتیت B، فاصله‌ای وجود دارد که:\n\n"
 "• **HBsAg دیگر منفی شده** (بدن آن را پاک کرده)\n"
 "• **ولی anti-HBs هنوز ظاهر نشده**\n\n"
 "**در آن پنجره، تنها نشانگر مثبت IgM ضد HBc است.** اگر فقط HBsAg بخواهید، **بیمارِ در "
 "پنجره را از دست می‌دهید**.\n\n"
 "**پس درخواست هم‌زمان IgM ضد HAV و IgM ضد HBc، دو شایع‌ترین علت هپاتیت حاد را با دو تست "
 "پوشش می‌دهد.** ✅\n\n"
 "**و چرا سه گزینه‌ی دیگر نه؟**\n\n"
 "**«HBV DNA PCR و Anti-HBs»** — HBV DNA برای **سنجش بار ویروسی در بیماری مزمن** است، نه "
 "تشخیص اولیه‌ی حاد. و anti-HBs نشانگر **ایمنی** است، نه عفونت حاد.\n\n"
 "**«سونوگرافی کبد و مجاری صفراوی»** — الگوی آزمایش **هپاتوسلولار** است نه کلستاتیک، پس "
 "انسداد مطرح نیست.\n\n"
 "**«HBeAg و Anti-HBe»** — این‌ها **پس از** اثبات عفونت B، برای سنجش **تکثیر و سرایت** به "
 "کار می‌روند. **گام دوم‌اند، نه گام اول.**",
 "This question tests a simple but very widely applicable principle: TO DIAGNOSE ACUTE INFECTION, "
 "REACH FOR IgM.\n\n"
 "A 16-YEAR-OLD GIRL with 2 to 3 days of FEVER, HEADACHE, NAUSEA AND ANOREXIA, then DARK URINE AND "
 "JAUNDICE. Tests: AST 1300, ALT 1700, ALP 480, LDH 450, PT 13.1.\n\n"
 "WARNING, STEP ONE — READ THE PATTERN OF THE TESTS.\n\n"
 "AN ALT IN THE THOUSANDS (1700) is a SEVERE HEPATOCELLULAR pattern. That figure favours ACUTE VIRAL "
 "HEPATITIS.\n\n"
 "AND COMPARING ALT WITH ALP IS DECISIVE:\n\n"
 "• ALT 1700 against ALP 480 -> A HEPATOCELLULAR PATTERN\n"
 "• Had this been biliary obstruction, THE ALP WOULD RISE MUCH MORE and the ALT would usually stay "
 "below a few hundred\n\n"
 "SO THIS IS ACUTE VIRAL HEPATITIS, NOT OBSTRUCTION. And that ELIMINATES THE ULTRASOUND OPTION.\n\n"
 "AND A REASSURING POINT: PT 13.1 IS NEARLY NORMAL — SYNTHETIC FUNCTION IS STILL PRESERVED. That is "
 "a good sign and excludes acute liver failure.\n\n"
 "WARNING, STEP TWO — NOW WHICH VIRUS? And here the key principle enters:\n\n"
 "> FOR ACUTE INFECTION, ALWAYS REACH FOR IgM.\n\n"
 "IgM ANTI-HAV — the only marker of ACUTE HEPATITIS A. In an adolescent with abrupt onset and a "
 "gastrointestinal prodrome, hepatitis A is very likely.\n\n"
 "IgM ANTI-HBc — the marker of ACUTE HEPATITIS B.\n\n"
 "WARNING, AND NOW THE POINT THAT DOUBLES THE VALUE OF THIS OPTION: why IgM anti-HBc rather than "
 "HBsAg?\n\n"
 "Because of THE SEROLOGICAL WINDOW. In the course of hepatitis B there is an interval in which:\n\n"
 "• HBsAg HAS ALREADY CLEARED (the body has removed it)\n"
 "• BUT anti-HBs HAS NOT YET APPEARED\n\n"
 "IN THAT WINDOW THE ONLY POSITIVE MARKER IS IgM ANTI-HBc. If you order HBsAg alone, YOU MISS THE "
 "PATIENT IN THE WINDOW.\n\n"
 "SO ORDERING IgM ANTI-HAV AND IgM ANTI-HBc TOGETHER COVERS THE TWO COMMONEST CAUSES OF ACUTE "
 "HEPATITIS WITH TWO TESTS.\n\n"
 "AND WHY NOT THE OTHER THREE?\n\n"
 "'HBV DNA PCR AND ANTI-HBs' — HBV DNA is for MEASURING VIRAL LOAD IN CHRONIC DISEASE, not for "
 "initial acute diagnosis. And anti-HBs marks IMMUNITY, not acute infection.\n\n"
 "'ULTRASOUND OF LIVER AND BILIARY TREE' — the pattern is HEPATOCELLULAR, not cholestatic, so "
 "obstruction is not in question.\n\n"
 "'HBeAg AND ANTI-HBe' — these are used AFTER hepatitis B is established, to assess REPLICATION AND "
 "INFECTIVITY. THEY ARE STEP TWO, NOT STEP ONE.",
 ["HBV DNA برای سنجش بار ویروسی در بیماری مزمن است و anti-HBs نشانگر ایمنی، نه عفونت حاد.",
  "الگوی آزمایش‌ها هپاتوسلولار است نه کلستاتیک، پس انسداد صفراوی مطرح نیست.",
  "HBeAg و Anti-HBe پس از اثبات عفونت B و برای سنجش تکثیر به کار می‌روند، نه در گام اول.",
  "پاسخ صحیح — برای عفونت حاد سراغ IgM بروید؛ این دو تست، دو علت شایع هپاتیت حاد را پوشش می‌دهند."],
 ["HBV DNA measures viral load in chronic disease, and anti-HBs marks immunity, not acute infection.",
  "The pattern is hepatocellular rather than cholestatic, so biliary obstruction is not in question.",
  "HBeAg and anti-HBe are used after hepatitis B is established, to assess replication, not as a first step.",
  "Correct — for acute infection reach for IgM; these two tests cover the two commonest causes of acute hepatitis."],
 "**برای حاد، IgM.** و IgM ضد HBc تنها نشانگری است که در پنجره‌ی سرولوژیک مثبت می‌ماند.",
 "For acute disease, IgM; and IgM anti-HBc is the only marker that stays positive through the serological window.",
 [H339, AASLD])


# =========================================================== book:855
add("book:855", "recall", "medium",
 "شدت هپاتیت را با **عملکرد سنتزی** بسنجید، نه با آنزیم‌ها — **AST/ALT معیار شدت نیست**.",
 "Judge hepatitis severity by SYNTHETIC FUNCTION, not by the enzymes: AST/ALT IS NOT A SEVERITY MARKER.",
 HEP_FA + [
  "⚠️ **این سؤال یکی از رایج‌ترین سوءتفاهم‌های بالینی را هدف گرفته است.**",
  "**دانشجو می‌بیند ALT هزار است و نتیجه می‌گیرد «کبد خیلی خراب است».**",
  "**ولی ALT و AST فقط می‌گویند چند سلول کبدی در حال پاره شدن‌اند.**",
  "**آن‌ها نمی‌گویند کبدِ باقی‌مانده چقدر کار می‌کند — و همین دومی است که اهمیت دارد.**",
  "⚠️ **معیار واقعی شدت، عملکرد سنتزی کبد است، و سه نشانگر دارد:**",
  "**یک — زمان پروترومبین (PT/INR): مهم‌ترین و زودترین نشانگر.**",
  "**چون فاکتورهای انعقادی در کبد ساخته می‌شوند و نیمه‌عمر کوتاهی دارند.**",
  "**فاکتور VII نیمه‌عمری حدود ۶ ساعت دارد، پس PT ظرف ساعت‌ها تغییر را نشان می‌دهد.**",
  "**دو — بیلی‌روبین: توانایی کبد در کنژوگه و دفع کردن.**",
  "**سه — قند خون: کبد منبع اصلی گلوکونئوژنز است، و هیپوگلیسمی نشانه‌ی نارسایی شدید.**",
  "⚠️ **و خطرناک‌ترین سوءتفاهم: افت ALT همیشه خبر خوب نیست.**",
  "**اگر ALT پایین بیاید ولی INR بالا برود، یعنی سلول کبدی آن‌قدر مرده که آنزیمی نمانده.**",
  "**این نارسایی حاد کبد است، نه بهبودی — و اندیکاسیون ارجاع فوری برای پیوند.**",
 ],
 HEP_EN + [
  "WARNING: THIS QUESTION TARGETS ONE OF THE COMMONEST CLINICAL MISUNDERSTANDINGS.",
  "A student sees an ALT of a thousand and concludes 'the liver is badly damaged'.",
  "But ALT and AST only report HOW MANY HEPATOCYTES ARE BURSTING.",
  "They do not report HOW WELL THE REMAINING LIVER WORKS — and it is the second that matters.",
  "WARNING, THE REAL MEASURE OF SEVERITY IS SYNTHETIC FUNCTION, and it has three markers:",
  "ONE — THE PROTHROMBIN TIME (PT/INR): the most important and the earliest.",
  "Because clotting factors are made in the liver and have short half-lives.",
  "Factor VII has a half-life of about 6 hours, so the PT reflects change within hours.",
  "TWO — BILIRUBIN: the liver's ability to conjugate and excrete.",
  "THREE — BLOOD GLUCOSE: the liver is the main site of gluconeogenesis, and hypoglycaemia marks severe failure.",
  "WARNING, AND THE MOST DANGEROUS MISREADING: A FALLING ALT IS NOT ALWAYS GOOD NEWS.",
  "If the ALT falls while the INR rises, so many hepatocytes have died that no enzyme is left.",
  "That is ACUTE LIVER FAILURE, not recovery — and an indication for urgent transplant referral.",
 ],
 "این سؤال **منفی** است و یکی از **رایج‌ترین سوءتفاهم‌های بالینی** را هدف گرفته است.\n\n"
 "**بیمار پس از یک هفته تب و ضعف و تهوع، ایکتریک شده. برای سنجش شدت (Severity)، کدام "
 "آزمایش را درخواست نمی‌کنید؟**\n\n"
 "⚠️ **پاسخ: SGOT/SGPT (همان AST/ALT).**\n\n"
 "**و دلیلش، مهم‌ترین درس این سؤال است:**\n\n"
 "> **آنزیم‌های کبدی نشان می‌دهند چقدر سلول کبدی در حال آسیب دیدن است — نه اینکه کبد چقدر "
 "کار می‌کند.**\n\n"
 "**ALT و AST آنزیم‌های داخل سلول کبدی‌اند.** وقتی سلول پاره می‌شود، آن‌ها به خون می‌ریزند. "
 "پس عددشان **شاخص میزان تخریب جاری** است، **نه شاخص عملکرد باقی‌مانده**.\n\n"
 "**و این دو چیز کاملاً متفاوت‌اند.** یک بیمار می‌تواند ALT=۳۰۰۰ داشته باشد و کاملاً خوب "
 "شود؛ و بیمار دیگری با ALT=۴۰۰ در نارسایی کبدی بمیرد.\n\n"
 "⚠️ **پس معیار واقعی شدت چیست؟ عملکرد سنتزی کبد، با سه نشانگر:**\n\n"
 "**۱) زمان پروترومبین (PT/INR) — مهم‌ترین و زودترین.**\n\n"
 "**چرا این‌قدر خوب کار می‌کند؟** چون **فاکتورهای انعقادی در کبد ساخته می‌شوند** و "
 "**نیمه‌عمر کوتاهی دارند**. **فاکتور VII نیمه‌عمری حدود ۶ ساعت دارد** — پس اگر کبد از کار "
 "بیفتد، **PT ظرف ساعت‌ها بالا می‌رود**. این سریع‌ترین آینه‌ی عملکرد کبد است.\n\n"
 "**۲) بیلی‌روبین** — توانایی کبد در **کنژوگه کردن و دفع**.\n\n"
 "**۳) قند خون** — کبد **منبع اصلی گلوکونئوژنز** است. **هیپوگلیسمی در هپاتیت حاد، نشانه‌ی "
 "نارسایی شدید و بدشگون** است.\n\n"
 "**پس هر سه گزینه‌ی دیگر (PT، بیلی‌روبین، قند خون) معیار شدت‌اند — و فقط آنزیم‌ها "
 "نیستند.** ✅\n\n"
 "⚠️ **و حالا خطرناک‌ترین سوءتفاهم بالینی که از همین اصل می‌آید:**\n\n"
 "> **افت ALT همیشه خبر خوب نیست.**\n\n"
 "اگر در بیمار مبتلا به هپاتیت فولمینانت **ALT پایین بیاید ولی INR بالا برود**، این "
 "**بهبودی نیست**. یعنی **آن‌قدر سلول کبدی مرده که دیگر آنزیمی برای آزاد کردن باقی "
 "نمانده**.\n\n"
 "**این نارسایی حاد کبد است و اندیکاسیون ارجاع فوری به مرکز پیوند.**\n\n"
 "**معیارهای هشدار در هپاتیت حاد که باید بشناسید:** **INR بالای ۱/۵**، "
 "**انسفالوپاتی کبدی**، **هیپوگلیسمی**، و **کاهش سریع اندازه‌ی کبد**.",
 "This is a NEGATIVE question, and it targets ONE OF THE COMMONEST CLINICAL MISUNDERSTANDINGS.\n\n"
 "A patient becomes jaundiced after a week of fever, weakness and nausea. TO ASSESS SEVERITY, WHICH "
 "TEST WOULD YOU NOT REQUEST?\n\n"
 "WARNING, THE ANSWER: SGOT/SGPT (that is, AST/ALT).\n\n"
 "AND THE REASON IS THE MAIN LESSON OF THIS QUESTION:\n\n"
 "> THE LIVER ENZYMES SHOW HOW MANY HEPATOCYTES ARE BEING DAMAGED — NOT HOW WELL THE LIVER WORKS.\n\n"
 "ALT AND AST ARE INTRACELLULAR HEPATOCYTE ENZYMES. When a cell bursts they spill into the blood. So "
 "their level marks THE RATE OF ONGOING DESTRUCTION, NOT THE REMAINING FUNCTION.\n\n"
 "AND THOSE TWO THINGS ARE ENTIRELY DIFFERENT. One patient may have an ALT of 3000 and recover "
 "completely; another may die in liver failure with an ALT of 400.\n\n"
 "WARNING, SO WHAT IS THE REAL MEASURE OF SEVERITY? SYNTHETIC FUNCTION, with three markers:\n\n"
 "1) THE PROTHROMBIN TIME (PT/INR) — the most important and the earliest.\n\n"
 "WHY DOES IT WORK SO WELL? Because CLOTTING FACTORS ARE MADE IN THE LIVER and have SHORT "
 "HALF-LIVES. FACTOR VII HAS A HALF-LIFE OF ABOUT 6 HOURS — so if the liver fails, THE PT RISES "
 "WITHIN HOURS. It is the fastest mirror of hepatic function.\n\n"
 "2) BILIRUBIN — the liver's ability to CONJUGATE AND EXCRETE.\n\n"
 "3) BLOOD GLUCOSE — the liver is THE MAIN SITE OF GLUCONEOGENESIS. HYPOGLYCAEMIA IN ACUTE HEPATITIS "
 "IS A SIGN OF SEVERE AND OMINOUS FAILURE.\n\n"
 "SO ALL THREE OTHER OPTIONS (PT, bilirubin, glucose) ARE SEVERITY MARKERS — and only the enzymes "
 "are not.\n\n"
 "WARNING, AND NOW THE MOST DANGEROUS CLINICAL MISREADING THAT FOLLOWS FROM THIS PRINCIPLE:\n\n"
 "> A FALLING ALT IS NOT ALWAYS GOOD NEWS.\n\n"
 "If in fulminant hepatitis THE ALT FALLS WHILE THE INR RISES, that is NOT RECOVERY. It means SO "
 "MANY HEPATOCYTES HAVE DIED THAT NO ENZYME REMAINS TO BE RELEASED.\n\n"
 "THAT IS ACUTE LIVER FAILURE and an indication for urgent referral to a transplant centre.\n\n"
 "THE WARNING CRITERIA IN ACUTE HEPATITIS TO RECOGNISE: AN INR ABOVE 1.5, HEPATIC ENCEPHALOPATHY, "
 "HYPOGLYCAEMIA, and A RAPIDLY SHRINKING LIVER.",
 ["پاسخ صحیح — آنزیم‌های کبدی میزان تخریب را نشان می‌دهند، نه عملکرد باقی‌مانده‌ی کبد.",
  "PT مهم‌ترین معیار شدت است، چون فاکتورهای انعقادی در کبد ساخته می‌شوند و نیمه‌عمر کوتاهی دارند.",
  "بیلی‌روبین توانایی کبد در کنژوگه و دفع را می‌سنجد و یک معیار شدت است.",
  "قند خون معیار شدت است: کبد منبع اصلی گلوکونئوژنز است و هیپوگلیسمی نشانه‌ی نارسایی شدید."],
 ["Correct — the liver enzymes show the extent of destruction, not the remaining function.",
  "The PT is the most important severity marker, because clotting factors are hepatic and short-lived.",
  "Bilirubin measures the liver's ability to conjugate and excrete and is a severity marker.",
  "Blood glucose is a severity marker: the liver is the main site of gluconeogenesis and hypoglycaemia marks severe failure."],
 "**آنزیم = میزان تخریب. PT و بیلی‌روبین و قند = عملکرد.** افت ALT با INR بالا یعنی نارسایی.",
 "Enzymes measure destruction; PT, bilirubin and glucose measure function. A falling ALT with a rising INR means failure.",
 [H339, AASLD])


# =========================================================== book:848
add("book:848", "case", "medium",
 "نیدل‌استیک در فرد **واکسینه با تیتر محافظ اثبات‌شده** ← **هیچ اقدامی لازم نیست**.",
 "A needlestick in someone VACCINATED WITH A DOCUMENTED PROTECTIVE TITRE: NO ACTION IS NEEDED.",
 HEP_FA + [
  "**در مواجهه‌ی شغلی با هپاتیت B، تصمیم فقط به یک چیز بستگی دارد: وضعیت ایمنی فرد.**",
  "**و آن وضعیت را با یک عدد می‌سنجند: تیتر anti-HBs.**",
  "⚠️ **آستانه‌ی محافظت: anti-HBs برابر یا بیشتر از ۱۰ واحد بین‌المللی در میلی‌لیتر.**",
  "**اگر فرد پس از واکسیناسیون کامل، تیتر محافظ اثبات‌شده داشته باشد: پاسخ‌دهنده است.**",
  "**و پاسخ‌دهنده‌ی اثبات‌شده، پس از مواجهه هیچ اقدامی لازم ندارد — نه HBIG، نه یادآور.**",
  "⚠️ **چرا؟ چون حافظه‌ی ایمنی مادام‌العمر است، حتی وقتی تیتر با گذشت سال‌ها افت کند.**",
  "**سلول‌های B خاطره‌ای پس از مواجهه با ویروس، ظرف چند روز پاسخ آنافیلاکتیک می‌سازند.**",
  "**به همین دلیل، دوز یادآور روتین برای افراد سالم توصیه نمی‌شود.**",
  "**و اندازه‌گیری فوری تیتر هم لازم نیست، چون یک‌بار پاسخ‌دهندگی اثبات شده است.**",
  "⚠️ **حالا سه وضعیت دیگر را کنار این بگذارید تا کل جدول را داشته باشید:**",
  "**واکسینه ولی غیرپاسخ‌دهنده (تیتر زیر ۱۰): HBIG به‌علاوه‌ی شروع دوباره‌ی واکسیناسیون.**",
  "**واکسیناسیون ناقص یا وضعیت نامعلوم: HBIG به‌علاوه‌ی تکمیل واکسیناسیون.**",
  "**و در همه‌ی موارد، HBIG باید هرچه زودتر و ترجیحاً ظرف ۲۴ ساعت داده شود.**",
 ],
 HEP_EN + [
  "In occupational hepatitis B exposure the decision depends on one thing only: the person's immune status.",
  "And that status is measured by one number: the anti-HBs titre.",
  "WARNING, THE PROTECTIVE THRESHOLD: anti-HBs at or above 10 international units per millilitre.",
  "If, after full vaccination, the person had a documented protective titre, they are A RESPONDER.",
  "And a documented responder needs NOTHING after exposure — no HBIG, no booster.",
  "WARNING, WHY? Because immune memory is lifelong, even when the titre falls over the years.",
  "Memory B cells mount an anamnestic response within days of meeting the virus.",
  "That is why routine boosters are not recommended for healthy people.",
  "And measuring the titre urgently is unnecessary, since responder status was proven once.",
  "WARNING, NOW SET THREE OTHER SITUATIONS BESIDE THIS TO HOLD THE WHOLE TABLE:",
  "VACCINATED BUT A NON-RESPONDER (titre below 10): HBIG plus restarting the vaccine series.",
  "INCOMPLETE VACCINATION OR UNKNOWN STATUS: HBIG plus completing the series.",
  "And in every case HBIG should be given as soon as possible, preferably within 24 hours.",
 ],
 "این سؤال ساده به نظر می‌رسد ولی یک اصل ایمنی‌شناسی مهم را می‌سنجد: **تفاوت تیتر "
 "آنتی‌بادی با حافظه‌ی ایمنی.**\n\n"
 "**پرستاری** حین نمونه‌گیری از **بیمار مبتلا به هپاتیت B مزمن** دچار **نیدل‌استیک** شده. "
 "او **سه سال پیش واکسیناسیون هپاتیت B را کامل کرده** و **تیتر محافظت‌کننده‌ی بالا داشته "
 "است**.\n\n"
 "⚠️ **پاسخ: هیچ اقدامی لازم نیست.**\n\n"
 "**چرا؟ عبارت کلیدی صورت سؤال: «تیتر محافظت‌کننده‌ی بالا داشته است».**\n\n"
 "**آستانه‌ی محافظت: anti-HBs برابر یا بیشتر از ۱۰ واحد بین‌المللی در میلی‌لیتر.** کسی که "
 "پس از واکسیناسیون کامل به این آستانه رسیده، **«پاسخ‌دهنده» (responder)** نامیده می‌شود — "
 "و **این وضعیت دائمی است**.\n\n"
 "⚠️ **و حالا مهم‌ترین مفهوم این سؤال: تفاوت تیتر با حافظه.**\n\n"
 "دانشجو ممکن است بپرسد: «سه سال گذشته، شاید تیترش افت کرده باشد؟»\n\n"
 "**بله، ممکن است تیتر افت کرده باشد. ولی این اهمیتی ندارد.**\n\n"
 "**چون آنچه محافظت می‌کند، تیتر لحظه‌ای نیست — حافظه‌ی ایمنی است.** پس از یک پاسخ "
 "ایمنی موفق، **سلول‌های B خاطره‌ای** در بدن باقی می‌مانند. وقتی ویروس وارد شود، این "
 "سلول‌ها **ظرف چند روز یک پاسخ آنامنستیک (خاطره‌ای) سریع و قوی** می‌سازند — بسیار پیش از "
 "آنکه ویروس بتواند عفونت مستقر کند.\n\n"
 "**و دوره‌ی کمون هپاتیت B طولانی است (۶ هفته تا ۶ ماه)، پس زمان کافی برای این پاسخ "
 "هست.**\n\n"
 "**به همین دلیل است که دوز یادآور روتین برای افراد سالمِ پاسخ‌دهنده توصیه نمی‌شود.**\n\n"
 "**پس چرا سه گزینه‌ی دیگر غلط‌اند؟**\n\n"
 "**«یک واکسن یادآور»** — بی‌مورد. حافظه‌ی ایمنی حاضر است و یادآوری لازم ندارد.\n\n"
 "**«چک فوری تیتر آنتی‌بادی»** — بی‌فایده. **یک‌بار پاسخ‌دهندگی اثبات شده است.** حتی اگر "
 "تیتر امروز زیر ۱۰ باشد، فرد همچنان محافظت‌شده تلقی می‌شود.\n\n"
 "**«HBIG و یک نوبت واکسن»** — این پاسخِ **فرد غیرایمن** است، نه پاسخ‌دهنده‌ی اثبات‌شده.\n\n"
 "⚠️ **و حالا کل جدول را کنار هم بگذارید، چون سؤال‌های دیگر همین فصل روی خانه‌های دیگرش "
 "می‌ایستند:**\n\n"
 "**۱) پاسخ‌دهنده‌ی اثبات‌شده** ← **هیچ اقدامی** ✅\n\n"
 "**۲) واکسینه ولی غیرپاسخ‌دهنده (تیتر زیر ۱۰)** ← **HBIG + شروع دوباره‌ی سری واکسن**\n\n"
 "**۳) واکسیناسیون ناقص یا وضعیت نامعلوم** ← **HBIG + تکمیل واکسیناسیون**\n\n"
 "**۴) غیرپاسخ‌دهنده پس از دو سری کامل** ← **دو دوز HBIG به فاصله‌ی یک ماه**\n\n"
 "**و در همه‌ی موارد، HBIG باید هرچه زودتر و ترجیحاً ظرف ۲۴ ساعت داده شود.**",
 "This looks simple but tests an important immunological principle: THE DIFFERENCE BETWEEN AN "
 "ANTIBODY TITRE AND IMMUNE MEMORY.\n\n"
 "A NURSE sustains a NEEDLESTICK while taking blood from a patient with CHRONIC HEPATITIS B. She "
 "COMPLETED HEPATITIS B VACCINATION THREE YEARS AGO and HAD A HIGH PROTECTIVE TITRE.\n\n"
 "WARNING, THE ANSWER: NO ACTION IS NEEDED.\n\n"
 "WHY? The key phrase in the stem: 'had a high protective titre'.\n\n"
 "THE PROTECTIVE THRESHOLD: anti-HBs at or above 10 IU/mL. Someone who reached that after full "
 "vaccination is called A RESPONDER — AND THAT STATUS IS PERMANENT.\n\n"
 "WARNING, AND NOW THE CENTRAL CONCEPT: THE DIFFERENCE BETWEEN TITRE AND MEMORY.\n\n"
 "A student may ask: 'three years have passed, perhaps the titre has fallen?'\n\n"
 "YES, IT MAY HAVE FALLEN. AND IT DOES NOT MATTER.\n\n"
 "Because WHAT PROTECTS IS NOT THE MOMENTARY TITRE BUT IMMUNE MEMORY. After a successful immune "
 "response, MEMORY B CELLS remain. When the virus enters, those cells mount A RAPID, POWERFUL "
 "ANAMNESTIC RESPONSE WITHIN DAYS — long before the virus can establish infection.\n\n"
 "AND THE INCUBATION OF HEPATITIS B IS LONG (6 WEEKS TO 6 MONTHS), so there is ample time for that "
 "response.\n\n"
 "THAT IS WHY ROUTINE BOOSTERS ARE NOT RECOMMENDED FOR HEALTHY RESPONDERS.\n\n"
 "SO WHY ARE THE OTHER THREE WRONG?\n\n"
 "'A BOOSTER DOSE' — unnecessary. Immune memory is present and needs no reminding.\n\n"
 "'URGENTLY CHECK THE TITRE' — pointless. RESPONDER STATUS WAS PROVEN ONCE. Even if the titre is "
 "below 10 today, the person is still considered protected.\n\n"
 "'HBIG PLUS A VACCINE DOSE' — that is the answer for A NON-IMMUNE PERSON, not a documented "
 "responder.\n\n"
 "WARNING, AND NOW SET OUT THE WHOLE TABLE, because other questions in this chapter stand on its "
 "other cells:\n\n"
 "1) DOCUMENTED RESPONDER -> NOTHING\n\n"
 "2) VACCINATED BUT NON-RESPONDER (titre below 10) -> HBIG PLUS RESTART THE SERIES\n\n"
 "3) INCOMPLETE VACCINATION OR UNKNOWN STATUS -> HBIG PLUS COMPLETE THE SERIES\n\n"
 "4) NON-RESPONDER AFTER TWO FULL SERIES -> TWO DOSES OF HBIG ONE MONTH APART\n\n"
 "AND IN EVERY CASE HBIG SHOULD BE GIVEN AS SOON AS POSSIBLE, PREFERABLY WITHIN 24 HOURS.",
 ["دوز یادآور برای فرد پاسخ‌دهنده‌ی سالم توصیه نمی‌شود؛ حافظه‌ی ایمنی حاضر است.",
  "پاسخ صحیح — پاسخ‌دهنده‌ی اثبات‌شده پس از مواجهه به هیچ اقدامی نیاز ندارد.",
  "چک فوری تیتر بی‌فایده است: یک‌بار پاسخ‌دهندگی اثبات شده و افت تیتر محافظت را از بین نمی‌برد.",
  "HBIG و واکسن پاسخِ فرد غیرایمن یا با وضعیت نامعلوم است، نه پاسخ‌دهنده‌ی اثبات‌شده."],
 ["A booster is not recommended for a healthy responder; immune memory is already present.",
  "Correct — a documented responder needs nothing after exposure.",
  "Urgently checking the titre is pointless: responder status was proven once and a falling titre does not remove protection.",
  "HBIG plus vaccine is the answer for a non-immune person or unknown status, not a documented responder."],
 "**آنچه محافظت می‌کند حافظه‌ی ایمنی است، نه تیتر امروز.** پاسخ‌دهنده‌ی اثبات‌شده = هیچ اقدامی.",
 "What protects is immune memory, not today's titre; a documented responder needs nothing.",
 [AASLD, H339])


# =========================================================== book:853
add("book:853", "case", "hard",
 "همسر بیمار HBsAg مثبت که خودش **HBsAg منفی** است ← **واکسیناسیون سه‌نوبتی**.",
 "The HBsAg-NEGATIVE spouse of an HBsAg-positive patient needs THE THREE-DOSE VACCINE SERIES.",
 HEP_FA + [
  "**این سؤال دو کار می‌خواهد: خواندن پنل خودِ بیمار، و سپس تصمیم برای همسرش.**",
  "**پنل بیمار: HBsAg مثبت و anti-HBc از نوع IgG مثبت، با IgM منفی.**",
  "⚠️ **این ترکیب یعنی عفونت مزمن، نه حاد — چون IgM منفی است ولی IgG مثبت.**",
  "**پس بیمار یک ناقل مزمن است و شریک جنسی‌اش در معرض تماس مداوم است.**",
  "**حالا همسر: HBsAg منفی است، یعنی خودش آلوده نیست.**",
  "**و مواجهه‌ی او مواجهه‌ی حاد یک‌باره نیست — یک تماس مزمن و ادامه‌دار است.**",
  "⚠️ **و همین نکته انتخاب را تعیین می‌کند: در مواجهه‌ی مداوم، ایمنی فعال لازم است.**",
  "**HBIG ایمنی غیرفعال و موقت می‌دهد که ظرف چند هفته از بین می‌رود.**",
  "**پس برای کسی که هر روز در معرض است، HBIG راه‌حل نیست — واکسن است.**",
  "**واکسیناسیون سه‌نوبتی در ماه‌های صفر، یک و شش، ایمنی فعال و پایدار می‌سازد.**",
  "⚠️ **و HBIG جای خودش را دارد: مواجهه‌ی حاد و مشخص، مثل نیدل‌استیک یا تماس جنسی تک‌باره.**",
  "**پس از تکمیل واکسیناسیون، تیتر anti-HBs همسر باید بررسی شود تا پاسخ‌دهی تأیید گردد.**",
 ],
 HEP_EN + [
  "This question asks two things: read the patient's own panel, then decide for the spouse.",
  "THE PATIENT'S PANEL: HBsAg positive and anti-HBc IgG positive, with IgM negative.",
  "WARNING, THAT COMBINATION MEANS CHRONIC infection, not acute — IgM negative but IgG positive.",
  "So the patient is a chronic carrier and the sexual partner is under continuing exposure.",
  "Now the spouse: HBsAg negative, so she is not infected herself.",
  "And her exposure is not a single acute event — it is chronic and ongoing.",
  "WARNING, AND THAT POINT DECIDES THE CHOICE: continuing exposure requires ACTIVE immunity.",
  "HBIG gives passive, temporary immunity that disappears within weeks.",
  "So for someone exposed every day, HBIG is not the answer — the vaccine is.",
  "The three-dose series at months 0, 1 and 6 builds active, durable immunity.",
  "WARNING, AND HBIG HAS ITS OWN PLACE: a single, defined acute exposure such as a needlestick or one sexual contact.",
  "After completing the series, the spouse's anti-HBs titre should be checked to confirm response.",
 ],
 "این سؤال دو کار می‌خواهد: **اول پنل خودِ بیمار را بخوانید، بعد برای همسرش تصمیم "
 "بگیرید.**\n\n"
 "**معتاد تزریقی با تشخیص اندوکاردیت.** آزمایش‌ها: **HIV منفی**، **anti-HBc از نوع IgM "
 "منفی**، **HBsAg مثبت**، و **anti-HBc از نوع IgG مثبت**. **همسرش HBsAg منفی است.**\n\n"
 "⚠️ **گام یک — پنل بیمار یعنی چه؟**\n\n"
 "• **HBsAg مثبت** = عفونت **همین حالا** حاضر است\n"
 "• **anti-HBc از نوع IgG مثبت** = عفونت **در گذشته رخ داده**\n"
 "• **anti-HBc از نوع IgM منفی** = عفونت **حاد نیست**\n\n"
 "**ترکیب این سه: عفونت مزمن هپاتیت B.** بیمار یک **ناقل مزمن** است.\n\n"
 "⚠️ **گام دو — و حالا نکته‌ی تعیین‌کننده: نوع مواجهه‌ی همسر.**\n\n"
 "**همسر HBsAg منفی است** — یعنی **خودش آلوده نیست**. ولی چون شریک جنسی یک **ناقل مزمن** "
 "است، **مواجهه‌ی او یک‌باره نیست؛ مداوم و ادامه‌دار است**.\n\n"
 "**و همین جمله، انتخاب را تعیین می‌کند:**\n\n"
 "> **در مواجهه‌ی مداوم، ایمنی فعال لازم است — یعنی واکسن.**\n\n"
 "**چرا HBIG راه‌حل نیست؟** چون **HBIG ایمنی غیرفعال و موقت** می‌دهد: آنتی‌بادی آماده که "
 "**ظرف چند هفته تجزیه می‌شود و از بین می‌رود**. برای کسی که **هر روز در معرض است**، این "
 "مثل چتری است که فردا ناپدید می‌شود.\n\n"
 "**واکسیناسیون سه‌نوبتی (ماه صفر، یک و شش) ایمنی فعال و پایدار** می‌سازد — که دقیقاً "
 "چیزی است که یک شریک جنسی دائم به آن نیاز دارد. ✅\n\n"
 "⚠️ **پس HBIG کِی جایگاه دارد؟**\n\n"
 "> **در مواجهه‌ی حاد، مشخص و یک‌باره.**\n\n"
 "مثل **نیدل‌استیک**، **یک تماس جنسی تک‌باره با فرد آلوده**، یا **نوزاد مادر HBsAg مثبت**. "
 "در این موارد، **یک پنجره‌ی زمانی کوتاه** وجود دارد که باید فوراً پوشانده شود — و HBIG "
 "دقیقاً همان کار را می‌کند (معمولاً **به‌همراه** شروع واکسن).\n\n"
 "**و در مورد این همسر:** اگر **تماس جنسی محافظت‌نشده‌ی اخیر و مشخصی** ذکر شده بود، "
 "**HBIG + واکسن** منطقی می‌شد. ولی صورت سؤال چنین چیزی نگفته — پس تصمیم برای یک **مواجهه‌ی "
 "مزمن** است، و پاسخ **واکسن** است.\n\n"
 "**و یک نکته‌ی تکمیلی مهم:** پس از تکمیل سه نوبت واکسن، **تیتر anti-HBs همسر باید بررسی "
 "شود** تا مطمئن شویم پاسخ‌دهنده است (تیتر بالای ۱۰). چون در شریک یک ناقل مزمن، "
 "**اطمینان از ایمنی حیاتی است**.",
 "This question asks two things: FIRST READ THE PATIENT'S PANEL, THEN DECIDE FOR THE SPOUSE.\n\n"
 "AN INJECTING DRUG USER admitted with endocarditis. Tests: HIV NEGATIVE, anti-HBc IgM NEGATIVE, "
 "HBsAg POSITIVE, anti-HBc IgG POSITIVE. HIS WIFE IS HBsAg NEGATIVE.\n\n"
 "WARNING, STEP ONE — WHAT DOES THE PATIENT'S PANEL MEAN?\n\n"
 "• HBsAg POSITIVE = infection is present NOW\n"
 "• anti-HBc IgG POSITIVE = infection HAS OCCURRED in the past\n"
 "• anti-HBc IgM NEGATIVE = the infection IS NOT ACUTE\n\n"
 "TOGETHER: CHRONIC HEPATITIS B INFECTION. The patient is A CHRONIC CARRIER.\n\n"
 "WARNING, STEP TWO — AND NOW THE DECIDING POINT: THE NATURE OF THE SPOUSE'S EXPOSURE.\n\n"
 "THE WIFE IS HBsAg NEGATIVE — so SHE IS NOT INFECTED. But because her sexual partner is a CHRONIC "
 "CARRIER, HER EXPOSURE IS NOT A SINGLE EVENT; IT IS CONTINUING.\n\n"
 "AND THAT SENTENCE DECIDES THE CHOICE:\n\n"
 "> CONTINUING EXPOSURE REQUIRES ACTIVE IMMUNITY — THAT IS, THE VACCINE.\n\n"
 "WHY IS HBIG NOT THE ANSWER? Because HBIG GIVES PASSIVE, TEMPORARY IMMUNITY: ready-made antibody "
 "that IS CATABOLISED AND GONE WITHIN WEEKS. For someone exposed EVERY DAY, that is an umbrella "
 "that vanishes tomorrow.\n\n"
 "THE THREE-DOSE SERIES (months 0, 1 and 6) BUILDS ACTIVE, DURABLE IMMUNITY — exactly what a "
 "permanent sexual partner needs.\n\n"
 "WARNING, SO WHEN DOES HBIG HAVE A PLACE?\n\n"
 "> IN AN ACUTE, DEFINED, SINGLE EXPOSURE.\n\n"
 "Such as A NEEDLESTICK, A SINGLE SEXUAL CONTACT with an infected person, or THE NEONATE OF AN "
 "HBsAg-POSITIVE MOTHER. In those there is A SHORT TIME WINDOW to cover immediately — and HBIG does "
 "exactly that (usually TOGETHER WITH starting the vaccine).\n\n"
 "AND FOR THIS SPOUSE: had a RECENT, DEFINED UNPROTECTED CONTACT been described, HBIG PLUS VACCINE "
 "would be reasonable. The stem says no such thing — so the decision concerns A CHRONIC EXPOSURE, "
 "and the answer is THE VACCINE.\n\n"
 "AND AN IMPORTANT ADDITION: after completing the three doses, THE SPOUSE'S ANTI-HBs TITRE SHOULD BE "
 "CHECKED to confirm she is a responder (titre above 10). In the partner of a chronic carrier, "
 "CONFIRMING IMMUNITY IS ESSENTIAL.",
 ["پاسخ صحیح — مواجهه‌ی مداوم با یک ناقل مزمن، ایمنی فعال و پایدار می‌خواهد: واکسن سه‌نوبتی.",
  "HBIG به‌همراه واکسن پاسخِ مواجهه‌ی حاد و مشخص است، نه تماس مزمن و ادامه‌دار.",
  "HBIG به‌تنهایی ایمنی موقتی می‌دهد که ظرف چند هفته از بین می‌رود؛ برای تماس دائم بی‌فایده است.",
  "دو نوبت HBIG رژیم غیرپاسخ‌دهنده‌ی اثبات‌شده است، نه فرد سالمِ در معرض تماس مزمن."],
 ["Correct — continuing exposure to a chronic carrier requires active, durable immunity: the three-dose vaccine.",
  "HBIG with vaccine is the answer for an acute, defined exposure, not for chronic ongoing contact.",
  "HBIG alone gives temporary immunity that fades within weeks; useless against permanent exposure.",
  "Two doses of HBIG is the regimen for a proven non-responder, not a healthy person under chronic exposure."],
 "**مواجهه‌ی مزمن ← ایمنی فعال (واکسن). مواجهه‌ی حاد و یک‌باره ← HBIG.**",
 "Chronic exposure needs active immunity (the vaccine); a single acute exposure needs HBIG.",
 [AASLD, H339])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book33.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 33 lessons:', len(L))
