# -*- coding: utf-8 -*-
"""Infectious micro-lessons, batch 8 — Shahrivar-1401 (items 122-130).
Reference: Harrison's Principles of Internal Medicine, 21st ed."""
import json, io
L = {}

L["1401-06:122"] = {
 "style": "case", "difficulty": "hard",
 "micro": {
  "lead_fa": "واکسن هاری هرگز در گلوتئال زده نمی‌شود — چربی باسن جذب را مختل و پاسخ آنتی‌بادی را کم می‌کند.",
  "lead_en": "Rabies vaccine is never given in the gluteal muscle: buttock fat impairs absorption and lowers antibody response.",
  "points_fa": [
   "پروفیلاکسی هاری پس از تماس چهار جزء دارد و هر چهار باید درست انجام شوند.",
   "جزء اول: شست‌وشوی فراوان زخم با آب و صابون به‌مدت حداقل پانزده دقیقه.",
   "این ساده‌ترین و مؤثرترین اقدام است و به‌تنهایی بار ویروسی را به‌شدت کم می‌کند.",
   "جزء دوم: ایمونوگلوبولین هاری، که باید حداکثر ممکن در اطراف و داخل زخم انفیلتره شود.",
   "باقی‌مانده‌ی ایمونوگلوبولین در محلی دور از محل واکسن عضلانی تزریق می‌گردد.",
   "جزء سوم: واکسن، با رژیم Essen در روزهای صفر، سه، هفت و بیست و هشت.",
   "جزء چهارم: ارزیابی وضعیت حیوان و در صورت امکان مشاهده‌ی ده‌روزه.",
   "روباه، گرگ، شغال و خفاش حیوانات پرخطر محسوب می‌شوند و مشاهده در آن‌ها ممکن نیست.",
   "محل تزریق واکسن هاری در بالغین فقط عضله‌ی دلتوئید است.",
   "در شیرخواران محل صحیح، قسمت قدامی‌جانبی ران می‌باشد.",
   "تزریق در عضله‌ی گلوتئال ممنوع است چون بافت چربی ضخیم باسن جذب را مختل می‌کند.",
   "واکسن به‌جای عضله در چربی می‌نشیند و پاسخ آنتی‌بادی به‌طور معناداری کاهش می‌یابد.",
   "موارد شکست پروفیلاکسی هاری پس از تزریق گلوتئال گزارش شده است.",
   "ایمونوگلوبولین و واکسن نباید در یک محل و با یک سرنگ تزریق شوند.",
   "دلیلش این است که آنتی‌بادی می‌تواند آنتی‌ژن واکسن را خنثی کند."
  ],
  "points_en": [
   "Rabies post-exposure prophylaxis has four components and all four must be done correctly.",
   "First: copious wound washing with soap and water for at least fifteen minutes.",
   "This is the simplest and most effective step and by itself greatly reduces viral load.",
   "Second: rabies immunoglobulin, infiltrated as fully as possible into and around the wound.",
   "Any remainder is injected intramuscularly at a site distant from the vaccine.",
   "Third: the vaccine, using the Essen schedule on days 0, 3, 7 and 28.",
   "Fourth: assessing the animal and observing it for ten days where possible.",
   "Foxes, wolves, jackals and bats are high-risk animals and cannot be observed.",
   "The rabies vaccine site in adults is the deltoid muscle only.",
   "In infants the correct site is the anterolateral thigh.",
   "Gluteal injection is prohibited because the thick buttock fat impairs absorption.",
   "The vaccine settles in fat rather than muscle and the antibody response falls significantly.",
   "Prophylaxis failures after gluteal injection have been reported.",
   "Immunoglobulin and vaccine must not be given at the same site or with the same syringe.",
   "The reason is that antibody can neutralise the vaccine antigen."
  ]
 },
 "explanation_fa": "این سؤال چهار جزء پروفیلاکسی هاری را کنار هم می‌گذارد و می‌خواهد بدانید کدام‌یک اشتباه انجام شده. سه مورد درست است. شست‌وشوی فراوان زخم با آب و صابون مؤثرترین و ارزان‌ترین اقدام است. برنامه‌ی روزهای صفر، سه، هفت و بیست و هشت توالی استاندارد واکسن در فرد واکسینه‌نشده است. ایمونوگلوبولین هم باید حداکثر ممکن در اطراف زخم انفیلتره شود و باقی‌مانده عضلانی تزریق گردد. اما محل تزریق واکسن خطای واضح است: واکسن هاری هرگز نباید در عضله‌ی گلوتئال زده شود. دلیلش کاملاً عملی است — بافت چربی ضخیم باسن باعث می‌شود واکسن به‌جای عضله در چربی بنشیند، جذب ناقص شود و پاسخ آنتی‌بادی به‌طور معناداری کاهش یابد. موارد شکست پروفیلاکسی پس از تزریق گلوتئال گزارش شده است. محل صحیح در بالغین عضله‌ی دلتوئید است.",
 "explanation_en": "The question lays out the four components of rabies prophylaxis and asks which was done wrongly. Three are correct. Copious washing with soap and water is the most effective and cheapest measure. The schedule of days 0, 3, 7 and 28 is the standard course in an unvaccinated person. Immunoglobulin should indeed be infiltrated as fully as possible around the wound with any remainder given intramuscularly. But the vaccine site is the clear error: rabies vaccine must never be injected into the gluteal muscle. The reason is entirely practical — the thick buttock fat means the vaccine settles in fat rather than muscle, absorption is incomplete and the antibody response falls significantly. Prophylaxis failures after gluteal injection have been reported. The correct adult site is the deltoid.",
 "why_fa": [
  "شست‌وشوی زخم با آب و صابون درست و در واقع مؤثرترین جزء پروفیلاکسی هاری است.",
  "پاسخ صحیح — واکسن هاری هرگز در گلوتئال زده نمی‌شود؛ محل صحیح در بالغین دلتوئید است.",
  "تجویز عضلانی ایمونوگلوبولین پس از انفیلتراسیون در اطراف زخم، روش استاندارد محسوب می‌شود.",
  "توالی روزهای صفر، سه، هفت و بیست و هشت همان رژیم استاندارد Essen است و درست می‌باشد."
 ],
 "why_en": [
  "Washing with soap and water is correct and is in fact the most effective component of prophylaxis.",
  "Correct — rabies vaccine is never given gluteally; the correct adult site is the deltoid.",
  "Giving the immunoglobulin remainder intramuscularly after wound infiltration is standard practice.",
  "The day 0, 3, 7 and 28 sequence is the standard Essen regimen and is correct."
 ],
 "golden_fa": "هاری: شست‌وشو + RIG در زخم + واکسن روزهای ۰،۳،۷،۲۸ در دلتوئید. گلوتئال هرگز.",
 "golden_en": "Rabies: wash, infiltrate RIG into the wound, vaccine on days 0, 3, 7, 28 in the deltoid. Never gluteal.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 205: Rabies"]
}

L["1401-06:123"] = {
 "style": "recall", "difficulty": "medium",
 "micro": {
  "lead_fa": "شست‌وشوی سوند با ضدعفونی‌کننده نه‌تنها بی‌فایده، بلکه مضر است: سیستم بسته را باز می‌کند.",
  "lead_en": "Irrigating a catheter with antiseptic is not merely useless but harmful: it breaks the closed system.",
  "points_fa": [
   "عفونت ادراری مرتبط با سوند شایع‌ترین عفونت بیمارستانی است.",
   "پیشگیری از آن بر دو اصل استوار است: کم کردن ورود باکتری و کوتاه کردن مدت مواجهه.",
   "تکنیک استریل هنگام سوندگذاری از ورود باکتری در همان لحظه جلوگیری می‌کند.",
   "سیستم درناژ بسته مسیر صعود باکتری از کیسه به مثانه را می‌بندد.",
   "هر بار که سیستم باز شود، یک فرصت تازه برای آلودگی ایجاد می‌شود.",
   "کیسه‌ی ادرار باید همیشه پایین‌تر از سطح مثانه نگه داشته شود تا برگشت رخ ندهد.",
   "مؤثرترین مداخله، خروج زودهنگام سوند است.",
   "خطر باکتریوری با هر روز ادامه‌ی سوند حدود سه تا هفت درصد افزایش می‌یابد.",
   "شست‌وشوی سوند با محلول ضدعفونی‌کننده نه‌تنها مؤثر نیست، بلکه مضر است.",
   "هر شست‌وشو یعنی باز کردن سیستم بسته و ایجاد یک راه ورود تازه.",
   "باکتری‌ها روی سطح سوند بیوفیلم می‌سازند و محلول ضدعفونی به داخل بیوفیلم نفوذ نمی‌کند.",
   "نتیجه فقط انتخاب سویه‌های مقاوم و تحریک مخاط مثانه است.",
   "تمام راهنماهای پیشگیری از عفونت بیمارستانی شست‌وشوی روتین سوند را منع می‌کنند.",
   "درمان باکتریوری بدون علامت در بیمار سونددار هم توصیه نمی‌شود.",
   "استثنا: بارداری و پیش از پروسیجر اورولوژیک که در آن‌ها درمان لازم است."
  ],
  "points_en": [
   "Catheter-associated urinary tract infection is the commonest hospital-acquired infection.",
   "Prevention rests on two principles: reducing bacterial entry and shortening exposure time.",
   "Sterile technique at insertion prevents bacteria entering at that moment.",
   "A closed drainage system blocks the ascent of bacteria from bag to bladder.",
   "Every time the system is opened, a fresh opportunity for contamination is created.",
   "The bag must always be kept below bladder level to prevent reflux.",
   "The single most effective intervention is early catheter removal.",
   "The risk of bacteriuria rises about three to seven per cent for every catheter day.",
   "Irrigating the catheter with antiseptic solutions is not merely ineffective but harmful.",
   "Each irrigation means opening the closed system and creating a new route of entry.",
   "Bacteria form a biofilm on the catheter surface which antiseptics cannot penetrate.",
   "The only results are selection of resistant strains and irritation of the bladder mucosa.",
   "Every infection-prevention guideline explicitly discourages routine catheter irrigation.",
   "Treating asymptomatic bacteriuria in a catheterised patient is also not recommended.",
   "Exceptions: pregnancy and before a urological procedure, where treatment is required."
  ]
 },
 "explanation_fa": "عفونت ادراری مرتبط با سوند شایع‌ترین عفونت بیمارستانی است و پیشگیری از آن چند اصل ساده و اثبات‌شده دارد. سه گزینه‌ی درست همگی روی یک منطق استوارند: کم کردن ورود باکتری و کوتاه کردن مدت مواجهه. تکنیک استریل هنگام گذاشتن سوند از ورود باکتری جلوگیری می‌کند. سیستم درناژ بسته و دستکاری حداقلی مسیر صعود باکتری را می‌بندد. و مهم‌تر از همه، خروج زودهنگام سوند مؤثرترین مداخله است، چون خطر باکتریوری با هر روز ادامه‌ی سوند افزایش می‌یابد. اما شست‌وشوی سوند با محلول‌های ضدعفونی‌کننده نه‌تنها مؤثر نیست، بلکه مضر است: هر شست‌وشو یعنی باز کردن سیستم بسته، و باکتری‌ها روی سطح سوند بیوفیلم می‌سازند که محلول ضدعفونی به داخلش نفوذ نمی‌کند.",
 "explanation_en": "Catheter-associated urinary infection is the commonest hospital-acquired infection, and its prevention rests on a few simple, proven principles. The three correct options all share one logic: reduce bacterial entry and shorten exposure. Sterile insertion technique prevents bacteria entering at that moment. A closed drainage system with minimal manipulation blocks bacterial ascent. And most importantly, early catheter removal is the single most effective intervention, since the risk of bacteriuria climbs with every catheter day. Irrigating the catheter with antiseptic, however, is not merely ineffective but harmful: each irrigation means opening the closed system, and bacteria form a biofilm on the catheter surface that antiseptic cannot penetrate.",
 "why_fa": [
  "تکنیک استریل هنگام سوندگذاری از ورود باکتری در لحظه‌ی گذاشتن جلوگیری می‌کند و اقدام درستی است.",
  "درناژ بسته و دستکاری حداقلی مسیر صعود باکتری را می‌بندد و از اصول پذیرفته‌شده است.",
  "پاسخ صحیح — شست‌وشوی سوند با ضدعفونی‌کننده سیستم بسته را باز می‌کند و به بیوفیلم نفوذ نمی‌کند.",
  "خروج زودهنگام سوند مؤثرترین مداخله در کاهش عفونت ادراری بیمارستانی محسوب می‌شود."
 ],
 "why_en": [
  "Sterile insertion technique prevents bacteria entering at the moment of placement and is correct.",
  "Closed drainage with minimal manipulation blocks bacterial ascent and is an accepted principle.",
  "Correct — antiseptic irrigation opens the closed system and cannot penetrate the biofilm.",
  "Early catheter removal is the single most effective intervention against hospital urinary infection."
 ],
 "golden_fa": "CAUTI: استریل بگذار، بسته نگه دار، زود بردار. شست‌وشو با ضدعفونی‌کننده ممنوع.",
 "golden_en": "CAUTI: insert sterile, keep closed, remove early. Antiseptic irrigation is forbidden.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 130: Urinary Tract Infections"]
}

L["1401-06:124"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "اسهال ترشحی + شوک = رینگر لاکتات. هم حجم، هم باز، هم پتاسیم می‌دهد.",
  "lead_en": "Secretory diarrhoea with shock means Ringer's lactate: it supplies volume, base and potassium.",
  "points_fa": [
   "اسهال آبکی پرحجم بدون تب و بدون درد شکم، الگوی ترشحی شبیه‌وبا است.",
   "فشار هشتاد روی پنجاه، نبض صد و بیست و خواب‌آلودگی یعنی شوک هیپوولمیک.",
   "خواب‌آلودگی نشانه‌ی کاهش پرفیوژن مغز است و یک علامت هشدار جدی محسوب می‌شود.",
   "در اسهال ترشحی بیمار فقط آب از دست نمی‌دهد.",
   "مدفوع ترشحی سرشار از بی‌کربنات، پتاسیم و سدیم است.",
   "پس بیمار همزمان سه مشکل پیدا می‌کند: کاهش حجم، اسیدوز متابولیک و هیپوکالمی.",
   "مایع انتخابی باید هر سه را هدف بگیرد، نه فقط حجم را.",
   "رینگر لاکتات حجم را برمی‌گرداند و لاکتات آن در کبد به بی‌کربنات تبدیل می‌شود.",
   "همین تبدیل، اسیدوز متابولیک را اصلاح می‌کند.",
   "رینگر لاکتات مقداری پتاسیم هم دارد که هیپوکالمی را جبران می‌کند.",
   "سازمان جهانی بهداشت آن را مایع ارجح احیای وبای شدید معرفی کرده است.",
   "نرمال سالین حجم می‌دهد ولی هیچ بازی ندارد.",
   "بار کلر بالای نرمال سالین می‌تواند اسیدوز هایپرکلرمیک اضافه کند.",
   "دکستروز سالین برای آب آزاد و کالری است، نه احیای سریع حجم داخل عروقی.",
   "آلبومین کلوئید گران‌قیمتی است که بر کریستالوئید در این وضعیت برتری ندارد."
  ],
  "points_en": [
   "High-volume watery diarrhoea without fever or abdominal pain is a cholera-like secretory pattern.",
   "A blood pressure of 80/50, pulse 120 and drowsiness mean hypovolaemic shock.",
   "Drowsiness reflects reduced cerebral perfusion and is a serious warning sign.",
   "In secretory diarrhoea the patient does not lose water alone.",
   "Secretory stool is rich in bicarbonate, potassium and sodium.",
   "So three problems arise together: volume depletion, metabolic acidosis and hypokalaemia.",
   "The chosen fluid must address all three, not volume alone.",
   "Ringer's lactate restores volume and its lactate is converted to bicarbonate in the liver.",
   "That conversion corrects the metabolic acidosis.",
   "Ringer's lactate also contains some potassium, offsetting the hypokalaemia.",
   "The World Health Organization names it the preferred fluid for severe cholera resuscitation.",
   "Normal saline restores volume but provides no base.",
   "Its high chloride load can add a hyperchloraemic acidosis.",
   "Dextrose saline supplies free water and calories, not rapid intravascular resuscitation.",
   "Albumin is an expensive colloid with no advantage over crystalloid in this setting."
  ]
 },
 "explanation_fa": "تابلو، اسهال آبکی پرحجم و بدون تب و بدون درد شکم است که ظرف یک روز به شوک هیپوولمیک رسیده. این الگو کاملاً به وبا یا اسهال ترشحی شبیه‌وبا می‌خورد. نکته‌ی کلیدی این است که در چنین اسهالی بیمار فقط آب از دست نمی‌دهد. مدفوع ترشحی سرشار از بی‌کربنات و پتاسیم است، پس بیمار همزمان دچار سه مشکل می‌شود: کاهش حجم شدید، اسیدوز متابولیک و هیپوکالمی. رینگر لاکتات دقیقاً همین سه را هدف می‌گیرد: حجم را برمی‌گرداند، لاکتات آن در کبد به بی‌کربنات تبدیل می‌شود و اسیدوز را اصلاح می‌کند، و مقداری پتاسیم هم دارد. نرمال سالین حجم را برمی‌گرداند ولی هیچ بازی ندارد و بار کلر بالای آن می‌تواند اسیدوز هایپرکلرمیک اضافه کند.",
 "explanation_en": "The picture is high-volume watery diarrhoea without fever or abdominal pain that has produced hypovolaemic shock within a day. This fits cholera or a cholera-like secretory diarrhoea. The key point is that in such diarrhoea the patient does not lose water alone. Secretory stool is rich in bicarbonate and potassium, so three problems arise together: severe volume depletion, metabolic acidosis and hypokalaemia. Ringer's lactate targets all three: it restores volume, its lactate is converted to bicarbonate in the liver correcting the acidosis, and it contains some potassium. Normal saline restores volume but provides no base, and its high chloride load can add a hyperchloraemic acidosis.",
 "why_fa": [
  "نرمال سالین حجم را برمی‌گرداند اما هیچ بازی ندارد و می‌تواند اسیدوز هایپرکلرمیک اضافه کند.",
  "پاسخ صحیح — رینگر لاکتات همزمان حجم، باز و پتاسیم می‌دهد و توصیه‌ی WHO برای وبای شدید است.",
  "دکستروز سالین برای تأمین آب آزاد و کالری است و برای احیای سریع حجم داخل عروقی مناسب نیست.",
  "آلبومین کلوئید گران‌قیمتی است که در شوک ناشی از دست دادن آب و الکترولیت برتری بر کریستالوئید ندارد."
 ],
 "why_en": [
  "Normal saline restores volume but supplies no base and can add a hyperchloraemic acidosis.",
  "Correct — Ringer's lactate supplies volume, base and potassium together and is the WHO choice for severe cholera.",
  "Dextrose saline provides free water and calories and is unsuitable for rapid intravascular resuscitation.",
  "Albumin is an expensive colloid with no advantage over crystalloid in water and electrolyte loss."
 ],
 "golden_fa": "اسهال ترشحی شدید = آب + بی‌کربنات + پتاسیم می‌رود. مایع: رینگر لاکتات، حجم زیاد و سریع.",
 "golden_en": "Severe secretory diarrhoea loses water, bicarbonate and potassium. Fluid: Ringer's lactate, large volume, fast.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 168: Cholera and Other Vibrioses"]
}

L["1401-06:125"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "اسهال مسافران با لکوسیت مثبت = فرم التهابی ← فلوروکینولون کوتاه‌مدت.",
  "lead_en": "Traveller's diarrhoea with faecal leukocytes is the inflammatory form: a short fluoroquinolone course.",
  "points_fa": [
   "اسهال مسافران شایع‌ترین بیماری مرتبط با سفر است.",
   "شایع‌ترین عامل آن ETEC است، سپس کمپیلوباکتر، شیگلا و سالمونلا.",
   "وجود لکوسیت در مدفوع یعنی مخاط روده ملتهب و آسیب‌دیده است.",
   "این یافته عامل بیماری را از توکسینی به مهاجم تغییر می‌دهد.",
   "در فرم خفیف و آبکی بدون تب، درمان حمایتی و مایع‌درمانی خوراکی کافی است.",
   "در فرم التهابی با تب و لکوسیت مثبت، آنتی‌بیوتیک اندیکاسیون پیدا می‌کند.",
   "آنتی‌بیوتیک طول بیماری را از حدود سه تا پنج روز به یک تا دو روز کاهش می‌دهد.",
   "درمان استاندارد فلوروکینولون خوراکی کوتاه‌مدت است.",
   "سیپروفلوکساسین معمولاً یک تا سه روز کافی است.",
   "کوتریموکسازول زمانی خط اول بود ولی امروز مقاومت گسترده دارد.",
   "دوره‌ی هفت‌روزه در اسهال مسافران بی‌مورد طولانی است.",
   "سفتریاکسون عضلانی برای بیمار سرپایی و پایدار بیش‌درمانی تزریقی محسوب می‌شود.",
   "در سفر به جنوب و شرق آسیا مقاومت کمپیلوباکتر به فلوروکینولون بالاست.",
   "در آن مناطق آزیترومایسین جایگزین ترجیحی است.",
   "مایع‌درمانی خوراکی همیشه پایه‌ی درمان است، حتی وقتی آنتی‌بیوتیک می‌دهیم.",
   "لوپرامید در فرم التهابی با تب توصیه نمی‌شود."
  ],
  "points_en": [
   "Traveller's diarrhoea is the commonest travel-related illness.",
   "ETEC is the commonest cause, followed by Campylobacter, Shigella and Salmonella.",
   "Faecal leukocytes indicate an inflamed, damaged intestinal mucosa.",
   "That finding shifts the mechanism from toxin-mediated to invasive.",
   "In the mild watery afebrile form, supportive care and oral rehydration suffice.",
   "In the inflammatory form with fever and leukocytes, antibiotics become indicated.",
   "Antibiotics shorten the illness from about three to five days down to one or two.",
   "Standard therapy is a short course of an oral fluoroquinolone.",
   "Ciprofloxacin for one to three days is usually sufficient.",
   "Co-trimoxazole was once first-line but resistance is now widespread.",
   "A seven-day course is needlessly long for traveller's diarrhoea.",
   "Intramuscular ceftriaxone is parenteral over-treatment for a stable outpatient.",
   "In South and Southeast Asia, Campylobacter resistance to fluoroquinolones is high.",
   "Azithromycin is the preferred alternative in those regions.",
   "Oral rehydration remains the foundation of treatment even when antibiotics are given.",
   "Loperamide is not recommended in the inflammatory form with fever."
  ]
 },
 "explanation_fa": "دو عنصر تشخیص را می‌سازند: سفر اخیر و لکوسیت در مدفوع. این اسهال مسافران است، ولی نوع التهابی آن. وجود لکوسیت در مدفوع یعنی مخاط روده ملتهب و آسیب‌دیده است، پس عامل بیماری مهاجم است نه صرفاً توکسینی. این نکته گزینه‌ی نیازی به آنتی‌بیوتیک ندارد را کنار می‌گذارد: در اسهال مسافران خفیف و آبکی درمان حمایتی کافی است، اما در فرم التهابی با تب و لکوسیت مثبت، آنتی‌بیوتیک هم طول بیماری را کوتاه می‌کند و هم از عوارض جلوگیری می‌کند. درمان استاندارد فلوروکینولون خوراکی کوتاه‌مدت است. کوتریموکسازول امروز مقاومت گسترده دارد و دوره‌ی هفت‌روزه‌اش بی‌مورد طولانی است. سفتریاکسون عضلانی برای بیمار سرپایی پایدار بیش‌درمانی است.",
 "explanation_en": "Two elements make the diagnosis: recent travel and faecal leukocytes. This is traveller's diarrhoea, but the inflammatory variety. Leukocytes in stool mean an inflamed, damaged mucosa, so the organism is invasive rather than merely toxin-producing. That rules out the no-antibiotic option: in mild watery traveller's diarrhoea supportive care suffices, but in the inflammatory form with fever and positive leukocytes antibiotics both shorten the illness and prevent complications. Standard therapy is a short oral fluoroquinolone course. Co-trimoxazole now faces widespread resistance and its seven-day course is needlessly long. Intramuscular ceftriaxone is over-treatment for a stable outpatient.",
 "why_fa": [
  "پاسخ صحیح — سیپروفلوکساسین کوتاه‌مدت درمان استاندارد اسهال مسافران التهابی است.",
  "کوتریموکسازول مقاومت گسترده دارد و دوره‌ی هفت‌روزه هم برای این بیماری بی‌مورد طولانی است.",
  "سفتریاکسون تزریقی برای بیمار سرپایی و پایدار که می‌تواند دارو بخورد، بیش‌درمانی محسوب می‌شود.",
  "لکوسیت مثبت در مدفوع یعنی فرم التهابی، و در این فرم آنتی‌بیوتیک واقعاً اندیکاسیون دارد."
 ],
 "why_en": [
  "Correct — a short course of ciprofloxacin is standard therapy for inflammatory traveller's diarrhoea.",
  "Co-trimoxazole faces widespread resistance and a seven-day course is needlessly long here.",
  "Parenteral ceftriaxone is over-treatment for a stable outpatient who can take oral medication.",
  "Positive faecal leukocytes indicate the inflammatory form, in which antibiotics are genuinely indicated."
 ],
 "golden_fa": "اسهال مسافران: آبکی بدون تب ← حمایتی. لکوسیت/تب ← سیپرو ۱–۳ روز. آسیا ← آزیترومایسین.",
 "golden_en": "Traveller's diarrhoea: watery and afebrile means supportive care. Leukocytes or fever means cipro for 1-3 days. Asia means azithromycin.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 128: Acute Infectious Diarrhoea"]
}

L["1401-06:126"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "بروسلوز بدون عارضه = حداقل ۶ هفته، همیشه دودارویی. عارضه‌دار = ۳ تا ۶ ماه.",
  "lead_en": "Uncomplicated brucellosis needs at least six weeks of dual therapy; complicated disease three to six months.",
  "points_fa": [
   "بروسلوز از شیر و لبنیات غیرپاستوریزه یا تماس شغلی با دام منتقل می‌شود.",
   "تابلو مبهم است: تب موجی، تعریق شبانه، ضعف، درد استخوان و مفاصل و کاهش اشتها.",
   "سیتوپنی خفیف شامل لکوپنی و ترومبوسیتوپنی شایع است.",
   "دلیل سیتوپنی این است که بروسلا در سلول‌های رتیکولواندوتلیال زندگی می‌کند.",
   "نکته‌ی مهم: ESR و CRP در بروسلوز اغلب فقط کمی بالا هستند و نباید تشخیص را رد کنند.",
   "تیتر رایت یک‌صد و شصت یا بالاتر در زمینه‌ی بالینی مناسب معنادار است.",
   "تست 2ME آنتی‌بادی IgG را می‌سنجد و به نفع عفونت فعال یا مزمن است.",
   "بروسلا باکتری داخل‌سلولی است و در سلول‌های میزبان از دسترس آنتی‌بیوتیک پنهان می‌شود.",
   "به همین دلیل دو اصل حاکم است: درمان همیشه دودارویی و همیشه طولانی.",
   "حداقل دوره‌ی استاندارد برای بروسلوز بدون عارضه، شش هفته است.",
   "رژیم رایج: داکسی‌سایکلین به‌علاوه‌ی ریفامپین به‌مدت شش هفته.",
   "رژیم جایگزین: داکسی‌سایکلین شش هفته با استرپتومایسین در دو تا سه هفته‌ی اول.",
   "چهار هفته کوتاه‌تر از حداقل لازم است و میزان عود را بالا می‌برد.",
   "عود شایع‌ترین پیامد درمان ناکافی در بروسلوز است و معمولاً در شش ماه اول رخ می‌دهد.",
   "دوره‌های سه تا شش ماهه به عوارض موضعی اختصاص دارند.",
   "این عوارض شامل اسپوندیلیت، اندوکاردیت و نوروبروسلوز است."
  ],
  "points_en": [
   "Brucellosis is acquired from unpasteurised dairy or occupational contact with livestock.",
   "The presentation is vague: undulant fever, night sweats, weakness, bone and joint pain, anorexia.",
   "Mild cytopenias including leukopenia and thrombocytopenia are common.",
   "The cytopenias arise because Brucella lives within reticuloendothelial cells.",
   "An important point: ESR and CRP are often only mildly raised and must not exclude the diagnosis.",
   "A Wright titre of 1/160 or higher is meaningful in the right clinical context.",
   "The 2ME test measures IgG and favours active or chronic infection.",
   "Brucella is intracellular and hides from antibiotics inside host cells.",
   "Two principles follow: therapy is always dual-agent and always prolonged.",
   "The minimum standard course for uncomplicated brucellosis is six weeks.",
   "Common regimen: doxycycline plus rifampin for six weeks.",
   "Alternative: doxycycline for six weeks with streptomycin during the first two to three weeks.",
   "Four weeks is below the minimum and increases the relapse rate.",
   "Relapse is the commonest consequence of inadequate therapy, usually within six months.",
   "Three to six month courses are reserved for focal complications.",
   "Those complications include spondylitis, endocarditis and neurobrucellosis."
  ]
 },
 "explanation_fa": "تشخیص بروسلوز است و شواهد کاملاً جور درمی‌آید: مصرف شیر غیرپاستوریزه، تب و تعریق و درد استخوانی دوماهه، سیتوپنی خفیف، و تیتر رایت یک‌صد و شصت به‌همراه 2ME مثبت. نکته‌ی جالب اینکه ESR و CRP فقط کمی بالا هستند که در بروسلوز شایع است و نباید تشخیص را رد کند. سؤال درباره‌ی طول درمان است و همین جایی است که بروسلوز با اکثر عفونت‌های باکتریال فرق دارد. بروسلا یک باکتری داخل‌سلولی است که در سلول‌های رتیکولواندوتلیال پنهان می‌شود. به همین دلیل درمان همیشه دودارویی و همیشه طولانی است. حداقل دوره برای بروسلوز بدون عارضه شش هفته است. چهار هفته کوتاه‌تر از حداقل لازم است و عود را بالا می‌برد؛ سه و شش ماه هم به عوارض موضعی اختصاص دارند.",
 "explanation_en": "The diagnosis is brucellosis and the evidence fits neatly: unpasteurised milk, two months of fever, sweats and bone pain, mild cytopenias, and a Wright titre of 1/160 with a positive 2ME. Notably ESR and CRP are only mildly raised, which is common in brucellosis and must not exclude it. The question concerns duration, and this is exactly where brucellosis differs from most bacterial infections. Brucella is intracellular, hiding within reticuloendothelial cells, so therapy is always dual-agent and always prolonged. The minimum for uncomplicated disease is six weeks. Four weeks falls below that minimum and raises relapse; three and six months are reserved for focal complications.",
 "why_fa": [
  "چهار هفته کوتاه‌تر از حداقل استاندارد است و میزان عود بروسلوز را به‌طور معناداری بالا می‌برد.",
  "سه ماه برای عوارض موضعی مثل اسپوندیلیت یا نوروبروسلوز است، نه بروسلوز بدون عارضه.",
  "شش ماه به عوارض شدید مانند اندوکاردیت بروسلایی اختصاص دارد و اینجا بیش از حد طولانی است.",
  "پاسخ صحیح — حداقل شش هفته درمان دودارویی، استاندارد بروسلوز بدون عارضه است."
 ],
 "why_en": [
  "Four weeks is below the standard minimum and significantly increases the relapse rate.",
  "Three months is for focal complications such as spondylitis or neurobrucellosis, not uncomplicated disease.",
  "Six months is reserved for severe complications like brucellar endocarditis and is excessive here.",
  "Correct — a minimum of six weeks of dual therapy is the standard for uncomplicated brucellosis."
 ],
 "golden_fa": "بروسلوز: همیشه ۲ دارو. بدون عارضه ۶ هفته • اسپوندیلیت/نوروبروسلوز ۳ ماه • اندوکاردیت ۶ ماه.",
 "golden_en": "Brucellosis: always two drugs. Uncomplicated six weeks, spondylitis or neurobrucellosis three months, endocarditis six.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 169: Brucellosis"]
}

L["1401-06:127"] = {
 "style": "case", "difficulty": "medium",
 "micro": {
  "lead_fa": "پروفیلاکسی جراحی = تک‌دوز پیش از برش. ادامه‌ی چندروزه فایده ندارد و مقاومت می‌سازد.",
  "lead_en": "Surgical prophylaxis is a single pre-incision dose. Continuing for days adds no benefit and breeds resistance.",
  "points_fa": [
   "پیشگیری از عفونت محل جراحی چند اصل روشن و اثبات‌شده دارد.",
   "تک‌دوز آنتی‌بیوتیک باید در فاصله‌ی شصت دقیقه پیش از برش داده شود.",
   "هدف این است که در لحظه‌ی برش، غلظت بافتی دارو در حداکثر باشد.",
   "برای وانکومایسین و فلوروکینولون، زمان تجویز به صد و بیست دقیقه پیش از برش می‌رسد.",
   "کلرهگزیدین-الکل امروز بر پویدون-آیوداین ترجیح دارد.",
   "دلیلش اثر باقی‌مانده‌ی طولانی‌تر و کاهش بیشتر بار میکروبی پوست است.",
   "ترخیص زودهنگام مطلوب است چون هر روز اضافه یعنی مواجهه با فلور مقاوم بیمارستانی.",
   "تفاوت بنیادی پروفیلاکسی با درمان: پروفیلاکسی فقط پنجره‌ی خودِ عمل را می‌پوشاند.",
   "شواهد نشان داده ادامه دادن آنتی‌بیوتیک پس از بسته شدن زخم فایده‌ای ندارد.",
   "ولی سه ضرر قطعی دارد: انتخاب باکتری مقاوم، کولیت کلستریدیوم دیفیسیل، و عوارض و هزینه.",
   "قاعده‌ی امروزی: پروفیلاکسی جراحی نباید بیش از بیست و چهار ساعت ادامه یابد.",
   "در اکثر اعمال تمیز، همان تک‌دوز پیش از عمل کافی است.",
   "تنها استثنا تکرار دوز حین عمل است، اگر جراحی طولانی یا خون‌ریزی زیاد باشد.",
   "تکرار دوز معمولاً پس از دو نیمه‌عمر دارو یا خون‌ریزی بیش از ۱۵۰۰ میلی‌لیتر انجام می‌شود.",
   "سایر اقدامات مؤثر: کنترل قند خون، نرموترمی حین عمل و اصلاح موی محل با کلیپر نه تیغ."
  ],
  "points_en": [
   "Surgical site infection prevention rests on a few clear, evidence-based principles.",
   "A single antibiotic dose should be given within sixty minutes before incision.",
   "The aim is peak tissue concentration at the moment of incision.",
   "For vancomycin and fluoroquinolones the window extends to 120 minutes before incision.",
   "Chlorhexidine-alcohol is now preferred over povidone-iodine.",
   "It has a longer residual effect and reduces skin flora more effectively.",
   "Early discharge is desirable because each extra day means exposure to resistant hospital flora.",
   "The fundamental difference from treatment: prophylaxis covers only the operative window.",
   "Evidence shows continuing antibiotics after wound closure adds no benefit.",
   "It carries three definite harms: resistance selection, C. difficile colitis, and toxicity and cost.",
   "The modern rule: surgical prophylaxis should not continue beyond twenty-four hours.",
   "For most clean operations the single pre-operative dose suffices.",
   "The only exception is intra-operative redosing for prolonged surgery or heavy blood loss.",
   "Redosing is usually after two drug half-lives or blood loss above 1500 mL.",
   "Other effective measures: glycaemic control, intra-operative normothermia, and clipping rather than shaving."
  ]
 },
 "explanation_fa": "پیشگیری از عفونت محل جراحی چند اصل روشن دارد و سؤال می‌خواهد بدانید کدام اقدام آن‌ها را نقض می‌کند. سه مورد درست‌اند. تک‌دوز آنتی‌بیوتیک در فاصله‌ی شصت دقیقه پیش از برش دقیقاً رژیم استاندارد است. کلرهگزیدین-الکل امروز بر پویدون-آیوداین ترجیح دارد چون اثر باقی‌مانده‌ی طولانی‌تری دارد. و ترخیص زودهنگام نه‌تنها اشکالی ندارد بلکه مطلوب است. اما دوره‌ی ده‌روزه‌ی آنتی‌بیوتیک پروفیلاکسی خطای واضح است. تفاوت بنیادی پروفیلاکسی با درمان همین است: پروفیلاکسی برای پوشاندن پنجره‌ی زمانی خودِ عمل طراحی شده، نه برای روزهای بعد. ادامه دادن آنتی‌بیوتیک هیچ کاهش اضافی در عفونت ایجاد نمی‌کند، ولی سه ضرر قطعی دارد: مقاومت، کولیت کلستریدیوم دیفیسیل، و عوارض و هزینه.",
 "explanation_en": "Surgical site infection prevention has a few clear principles, and the question asks which action violates them. Three are correct. A single dose within sixty minutes of incision is precisely the standard regimen. Chlorhexidine-alcohol is now preferred over povidone-iodine for its longer residual effect. And early discharge is not merely acceptable but desirable. The ten-day prophylactic course, however, is the clear error. That is the fundamental difference between prophylaxis and treatment: prophylaxis is designed to cover the operative window, not the days that follow. Continuing antibiotics produces no further reduction in infection but carries three definite harms: resistance, Clostridioides difficile colitis, and toxicity and cost.",
 "why_fa": [
  "تک‌دوز آنتی‌بیوتیک در شصت دقیقه پیش از برش، دقیقاً رژیم استاندارد پروفیلاکسی جراحی است.",
  "کلرهگزیدین امروز بر پویدون-آیوداین ترجیح دارد و انتخاب درستی محسوب می‌شود.",
  "پاسخ صحیح — پروفیلاکسی هرگز نباید بیش از بیست و چهار ساعت ادامه یابد؛ ده روز خطای واضح است.",
  "ترخیص زودهنگام مطلوب است چون اقامت طولانی مواجهه با فلور مقاوم بیمارستانی را زیاد می‌کند."
 ],
 "why_en": [
  "A single dose within sixty minutes of incision is precisely the standard surgical prophylaxis regimen.",
  "Chlorhexidine is now preferred over povidone-iodine and is the correct choice.",
  "Correct — prophylaxis should never exceed twenty-four hours; ten days is a clear error.",
  "Early discharge is desirable, since a long stay increases exposure to resistant hospital flora."
 ],
 "golden_fa": "پروفیلاکسی جراحی: تک‌دوز ≤۶۰ دقیقه پیش از برش، حداکثر ۲۴ ساعت. ادامه = مقاومت + C. difficile.",
 "golden_en": "Surgical prophylaxis: one dose within 60 minutes of incision, never beyond 24 hours. Continuing means resistance and C. difficile.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 138: Health Care-Associated Infections"]
}

L["1401-06:128"] = {
 "style": "case", "difficulty": "hard",
 "micro": {
  "lead_fa": "راش واریسلای مادر بین ۵ روز پیش تا ۲ روز پس از زایمان = نوزاد پرخطر ← VZIG فوری.",
  "lead_en": "Maternal varicella rash from five days before to two days after delivery puts the newborn at risk: give VZIG at once.",
  "points_fa": [
   "واریسلای نوزادی یکی از خطرناک‌ترین عفونت‌های دوره‌ی نوزادی است.",
   "پنجره‌ی پرخطر بسیار مشخص است و باید حفظ شود.",
   "اگر راش مادر از پنج روز پیش از زایمان تا دو روز پس از آن شروع شود، نوزاد در خطر است.",
   "دلیل این پنجره کاملاً ایمونولوژیک است.",
   "مادر ویروس را از راه جفت به جنین منتقل می‌کند.",
   "اما تولید و انتقال آنتی‌بادی محافظ مادری حدود پنج روز طول می‌کشد.",
   "در این پنجره نوزاد ویروس را می‌گیرد بدون آنکه آنتی‌بادی مادری همراهش باشد.",
   "چون سیستم ایمنی نوزاد هم نابالغ است، بیماری می‌تواند منتشر و کشنده شود.",
   "مرگ‌ومیر واریسلای نوزادی درمان‌نشده تا حدود سی درصد گزارش شده است.",
   "اقدام صحیح در این پنجره، تجویز فوری VZIG برای نوزاد است.",
   "هرچه زودتر بهتر؛ تأخیر اثربخشی را کم می‌کند.",
   "آسیکلوویر وریدی درمان است نه پیشگیری.",
   "اگر نوزاد علامت‌دار شود و ضایعات ظاهر گردد، آسیکلوویر شروع می‌شود.",
   "پیگیری تنها با توجه به مرگ‌ومیر بالای این عارضه پذیرفتنی نیست.",
   "مادر خودش هم باید ارزیابی و در صورت لزوم با آسیکلوویر درمان شود.",
   "واریسلا در بزرگسال و به‌ویژه در دوران نفاس خطر پنومونی واریسلایی دارد."
  ],
  "points_en": [
   "Neonatal varicella is among the most dangerous infections of the newborn period.",
   "The high-risk window is very specific and should be memorised.",
   "If the maternal rash begins from five days before delivery to two days after, the newborn is at risk.",
   "The reason for this window is purely immunological.",
   "The mother transmits the virus transplacentally to the fetus.",
   "But producing and transferring protective maternal antibody takes about five days.",
   "Within that window the newborn receives virus without accompanying maternal antibody.",
   "Because the neonatal immune system is also immature, disease can become disseminated and fatal.",
   "Mortality of untreated neonatal varicella has been reported at around thirty per cent.",
   "The correct action within this window is immediate VZIG for the newborn.",
   "The sooner the better; delay reduces effectiveness.",
   "Intravenous acyclovir is treatment, not prophylaxis.",
   "If the newborn becomes symptomatic and lesions appear, acyclovir is started.",
   "Follow-up alone is unacceptable given the high mortality of this complication.",
   "The mother herself should also be assessed and treated with acyclovir if indicated.",
   "Varicella in adults, especially postpartum, carries a risk of varicella pneumonia."
  ]
 },
 "explanation_fa": "این سؤال روی یک پنجره‌ی زمانی بسیار مشخص می‌چرخد که باید حفظ شود: اگر راش واریسلای مادر از پنج روز پیش از زایمان تا دو روز پس از آن شروع شود، نوزاد در خطر واریسلای نوزادی شدید است. دلیلش ایمونولوژیک است. مادر ویروس را از راه جفت به جنین منتقل می‌کند، اما تولید و انتقال آنتی‌بادی محافظ حدود پنج روز طول می‌کشد. در این پنجره، نوزاد ویروس را می‌گیرد بدون آنکه آنتی‌بادی مادری همراهش باشد، و چون سیستم ایمنی خودش هم نابالغ است، بیماری می‌تواند منتشر و کشنده شود. در این بیمار راش روز پنجم پس از زایمان شروع شده، یعنی داخل پنجره‌ی پرخطر است. اقدام صحیح تجویز فوری ایمونوگلوبولین اختصاصی واریسلا-زوستر برای نوزاد است. آسیکلوویر وریدی درمان است نه پیشگیری.",
 "explanation_en": "This question turns on a very specific time window that should be memorised: if the mother's varicella rash begins between five days before delivery and two days after, the newborn is at risk of severe neonatal varicella. The reason is immunological. The mother transmits virus across the placenta, but producing and transferring protective antibody takes about five days. Within that window the newborn acquires the virus without maternal antibody, and because its own immune system is immature the disease can become disseminated and fatal. Here the rash began on the fifth postpartum day, inside the high-risk window. The correct action is immediate varicella-zoster immunoglobulin for the newborn. Intravenous acyclovir is treatment, not prophylaxis.",
 "why_fa": [
  "پاسخ صحیح — VZIG پیشگیری استاندارد نوزاد در پنجره‌ی پرخطر است و باید فوراً تجویز شود.",
  "افزودن آسیکلوویر وریدی به VZIG در نوزاد بدون علامت اندیکاسیون ندارد؛ آسیکلوویر درمان است.",
  "آسیکلوویر به‌تنهایی درمان بیماری فعال است، نه پیشگیری در نوزادی که هنوز علامت ندارد.",
  "پیگیری تنها با مرگ‌ومیر تا سی درصد در واریسلای نوزادی درمان‌نشده پذیرفتنی نیست."
 ],
 "why_en": [
  "Correct — VZIG is the standard newborn prophylaxis within the high-risk window and must be given at once.",
  "Adding intravenous acyclovir to VZIG is not indicated in an asymptomatic newborn; acyclovir is treatment.",
  "Acyclovir alone treats active disease, not prophylaxis in a newborn who is not yet symptomatic.",
  "Follow-up alone is unacceptable when untreated neonatal varicella carries up to thirty per cent mortality."
 ],
 "golden_fa": "راش مادر: ۵ روز قبل تا ۲ روز بعد از زایمان = پنجره‌ی پرخطر ← VZIG فوری برای نوزاد.",
 "golden_en": "Maternal rash from five days before to two days after delivery is the high-risk window: immediate VZIG for the newborn.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 192: Varicella-Zoster Virus Infections"]
}

L["1401-06:129"] = {
 "style": "case", "difficulty": "hard",
 "micro": {
  "lead_fa": "CD4=۷۴ + PPD مثبت: INH + B6 (سل نهفته) + کوتریموکسازول (PCP/توکسو) + آزیترومایسین (MAC).",
  "lead_en": "CD4 74 with positive PPD: INH plus B6 for latent TB, co-trimoxazole for PCP and toxoplasma, azithromycin for MAC.",
  "points_fa": [
   "در بیمار HIV مثبت، پروفیلاکسی چند لایه دارد که همزمان باید بررسی شوند.",
   "لایه‌ی اول، سل نهفته: در HIV مثبت آستانه‌ی PPD مثبت فقط پنج میلی‌متر است.",
   "این آستانه‌ی پایین به‌خاطر خطر بسیار بالای پیشرفت به سل فعال در این بیماران است.",
   "پیش از شروع درمان سل نهفته باید سل فعال با شرح حال و گرافی رد شود.",
   "درمان سل نهفته ایزونیازید تنها به‌مدت شش تا نُه ماه است.",
   "لایه‌ی دوم، ویتامین B6: ایزونیازید با متابولیسم پیریدوکسین تداخل می‌کند.",
   "نتیجه‌ی این تداخل نوروپاتی محیطی است که با B6 قابل پیشگیری می‌باشد.",
   "در بیمار HIV مثبت که خودش زمینه‌ی نوروپاتی دارد، B6 الزامی است.",
   "لایه‌ی سوم بر پایه‌ی شمارش CD4 تعیین می‌شود.",
   "زیر دویست سلول: کوتریموکسازول برای پنوموسیستیس ژیرووسی.",
   "زیر صد سلول با سرولوژی توکسوپلاسما مثبت: همان کوتریموکسازول توکسوپلاسموز را هم می‌پوشاند.",
   "زیر پنجاه سلول: آزیترومایسین هفتگی برای مایکوباکتریوم اویوم.",
   "شمارش هفتاد و چهار زیر صد است، پس هر دو اندیکاسیون کوتریموکسازول برقرارند.",
   "سفوروکسیم هیچ جایگاهی در پروفیلاکسی HIV ندارد.",
   "با شروع درمان ضدرتروویروسی و بالا رفتن پایدار CD4، پروفیلاکسی‌ها معکوس قطع می‌شوند."
  ],
  "points_en": [
   "In an HIV-positive patient prophylaxis has several layers that must be considered together.",
   "First layer, latent tuberculosis: in HIV the PPD positivity threshold is only 5 mm.",
   "That low threshold reflects the very high risk of progression to active disease.",
   "Active tuberculosis must be excluded by history and chest film before starting latent treatment.",
   "Latent TB treatment is isoniazid alone for six to nine months.",
   "Second layer, vitamin B6: isoniazid interferes with pyridoxine metabolism.",
   "The result is peripheral neuropathy, preventable with B6.",
   "In an HIV-positive patient already prone to neuropathy, B6 is mandatory.",
   "The third layer is determined by the CD4 count.",
   "Below 200 cells: co-trimoxazole against Pneumocystis jirovecii.",
   "Below 100 with positive toxoplasma serology, the same drug also covers toxoplasmosis.",
   "Below 50 cells: weekly azithromycin against Mycobacterium avium.",
   "A count of 74 is below 100, so both co-trimoxazole indications apply.",
   "Cefuroxime has no place in HIV prophylaxis.",
   "As antiretroviral therapy raises CD4 durably, the prophylaxes are withdrawn in reverse order."
  ]
 },
 "explanation_fa": "این سؤال چند لایه‌ی پروفیلاکسی را همزمان می‌سنجد و باید همه را کنار هم چید. لایه‌ی اول، سل نهفته: در بیمار HIV مثبت آستانه‌ی PPD مثبت فقط پنج میلی‌متر است، پس این بیمار کاندید درمان سل نهفته با ایزونیازید است. لایه‌ی دوم، ویتامین B6: ایزونیازید با متابولیسم پیریدوکسین تداخل می‌کند و نوروپاتی محیطی می‌دهد، پس در بیمار HIV مثبت تجویز همزمان B6 الزامی است. لایه‌ی سوم، شمارش CD4 برابر هفتاد و چهار: این عدد زیر صد است، پس کوتریموکسازول هم برای پنوموسیستیس و هم برای توکسوپلاسموز مغزی لازم می‌شود. آزیترومایسین هم برای مایکوباکتریوم اویوم است. پس رژیم کامل چهار جزء دارد. سفوروکسیم هیچ جایگاهی در پروفیلاکسی HIV ندارد.",
 "explanation_en": "This question tests several layers of prophylaxis at once and they must all be assembled. First layer, latent tuberculosis: in an HIV-positive patient the PPD threshold is only 5 mm, so this man is a candidate for isoniazid. Second layer, vitamin B6: isoniazid interferes with pyridoxine metabolism and causes peripheral neuropathy, so concurrent B6 is mandatory in HIV. Third layer, the CD4 count of 74: that is below 100, so co-trimoxazole is needed for both Pneumocystis and cerebral toxoplasmosis. Azithromycin covers Mycobacterium avium. The complete regimen therefore has four components. Cefuroxime has no place in HIV prophylaxis.",
 "why_fa": [
  "این رژیم ویتامین B6 را جا انداخته، در حالی که پیشگیری از نوروپاتی ایزونیازید در HIV الزامی است.",
  "این رژیم کوتریموکسازول را ندارد، در حالی که CD4 برابر هفتاد و چهار هم PCP و هم توکسو را مطرح می‌کند.",
  "سفوروکسیم در پروفیلاکسی HIV هیچ جایگاهی ندارد و یک گزینه‌ی انحرافی است.",
  "پاسخ صحیح — ایزونیازید و B6 و آزیترومایسین و کوتریموکسازول، هر چهار لایه را پوشش می‌دهند."
 ],
 "why_en": [
  "This regimen omits vitamin B6, although preventing isoniazid neuropathy is mandatory in HIV.",
  "This regimen lacks co-trimoxazole, although a CD4 of 74 indicates both PCP and toxoplasma cover.",
  "Cefuroxime has no role in HIV prophylaxis and is a distractor.",
  "Correct — isoniazid, B6, azithromycin and co-trimoxazole together cover all four layers."
 ],
 "golden_fa": "HIV: PPD ≥۵ ← INH + B6. CD4 <۲۰۰ کوتریموکسازول • <۱۰۰ + توکسو • <۵۰ آزیترومایسین.",
 "golden_en": "HIV: PPD 5 mm or more means INH plus B6. CD4 under 200 co-trimoxazole, under 100 adds toxoplasma, under 50 azithromycin.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 202: HIV Disease"]
}

L["1401-06:130"] = {
 "style": "recall", "difficulty": "medium",
 "micro": {
  "lead_fa": "MDR-TB = مقاومت به ایزونیازید و ریفامپین، هر دو با هم. XDR یک پله بالاتر است.",
  "lead_en": "MDR-TB means resistance to isoniazid AND rifampin together. XDR is one step beyond.",
  "points_fa": [
   "تعریف MDR-TB دقیق و غیرقابل‌مسامحه است: مقاومت همزمان به ایزونیازید و ریفامپین.",
   "این تعریف صرف‌نظر از حساسیت یا مقاومت به سایر داروها برقرار است.",
   "چرا دقیقاً این دو دارو؟ چون ستون‌های اصلی رژیم کوتاه‌مدت شش‌ماهه هستند.",
   "ایزونیازید قوی‌ترین داروی باکتریسید اولیه است.",
   "ایزونیازید بار باکتریایی را در روزهای نخست به‌سرعت پایین می‌آورد و بیمار را غیرمسری می‌کند.",
   "ریفامپین قوی‌ترین داروی استریلیزان است و باسیل‌های نیمه‌خفته را از بین می‌برد.",
   "همین ویژگی ریفامپین بود که درمان را از هجده ماه به شش ماه کوتاه کرد.",
   "با از دست رفتن هر دو، رژیم کوتاه‌مدت عملاً فرو می‌ریزد.",
   "بیمار به درمان طولانی، گران و پرعارضه با داروهای خط دوم نیاز پیدا می‌کند.",
   "مقاومت به ایزونیازید و اتامبوتول MDR نیست، چون ریفامپین هنوز کار می‌کند.",
   "XDR-TB تعریف دیگری دارد: MDR به‌علاوه‌ی مقاومت به فلوروکینولون.",
   "و به‌علاوه‌ی مقاومت به حداقل یکی از داروهای تزریقی خط دوم مثل کاپرئومایسین یا آمیکاسین.",
   "XDR یک پله بالاتر و بسیار وخیم‌تر است و گزینه‌های درمانی را به‌شدت محدود می‌کند.",
   "امروز با تست‌های مولکولی مثل Xpert MTB/RIF مقاومت به ریفامپین ظرف چند ساعت تشخیص داده می‌شود.",
   "مقاومت به ریفامپین معمولاً اولین نشانه‌ی هشدار MDR است و باید تست کامل حساسیت انجام شود."
  ],
  "points_en": [
   "The definition of MDR-TB is precise and non-negotiable: resistance to isoniazid AND rifampin.",
   "This holds regardless of susceptibility or resistance to any other drug.",
   "Why these two drugs? Because they are the pillars of the six-month short-course regimen.",
   "Isoniazid is the most potent early bactericidal drug.",
   "It rapidly lowers the bacterial load in the first days and renders the patient non-infectious.",
   "Rifampin is the most potent sterilising drug, killing semi-dormant bacilli.",
   "That property is what shortened treatment from eighteen months to six.",
   "Losing both collapses the short-course regimen entirely.",
   "The patient then needs prolonged, expensive and toxic second-line therapy.",
   "Resistance to isoniazid and ethambutol is not MDR, because rifampin still works.",
   "XDR-TB has a different definition: MDR plus resistance to a fluoroquinolone.",
   "Plus resistance to at least one second-line injectable such as capreomycin or amikacin.",
   "XDR is a step beyond, far graver, and severely limits the remaining options.",
   "Molecular tests such as Xpert MTB/RIF now detect rifampin resistance within hours.",
   "Rifampin resistance is usually the first warning of MDR and should prompt full susceptibility testing."
  ]
 },
 "explanation_fa": "تعریف MDR-TB دقیق و غیرقابل‌مسامحه است: مقاومت همزمان به ایزونیازید و ریفامپین، صرف‌نظر از حساسیت یا مقاومت به سایر داروها. چرا دقیقاً همین دو دارو؟ چون این دو ستون‌های اصلی رژیم کوتاه‌مدت شش‌ماهه هستند. ایزونیازید قوی‌ترین داروی باکتریسید اولیه است و بار باکتریایی را در روزهای نخست به‌سرعت پایین می‌آورد؛ ریفامپین قوی‌ترین داروی استریلیزان است و همان چیزی است که درمان را از هجده ماه به شش ماه کوتاه کرده. با از دست رفتن هر دو، رژیم کوتاه‌مدت عملاً فرو می‌ریزد. مقاومت به ایزونیازید و اتامبوتول MDR نیست چون ریفامپین هنوز کار می‌کند. و گزینه‌ی خط اول به‌علاوه‌ی فلوروکینولون و کاپرئومایسین، تعریف XDR است که یک پله بالاتر و وخیم‌تر می‌باشد.",
 "explanation_en": "The definition of MDR-TB is precise and non-negotiable: simultaneous resistance to isoniazid and rifampin, regardless of susceptibility to anything else. Why exactly these two? Because they are the pillars of the six-month short-course regimen. Isoniazid is the most potent early bactericidal drug, rapidly lowering the bacterial load in the first days; rifampin is the most potent steriliser and is what shortened treatment from eighteen months to six. Losing both collapses the short course. Resistance to isoniazid and ethambutol is not MDR because rifampin still works. And the option listing first-line drugs plus a fluoroquinolone and capreomycin describes XDR, a step beyond and considerably graver.",
 "why_fa": [
  "مقاومت به ایزونیازید و اتامبوتول MDR نیست، چون ریفامپین هنوز کار می‌کند و رژیم قابل نجات است.",
  "پاسخ صحیح — MDR-TB دقیقاً یعنی مقاومت همزمان به ریفامپین و ایزونیازید.",
  "این تعریف XDR-TB است: MDR به‌علاوه‌ی مقاومت به فلوروکینولون و یک تزریقی خط دوم.",
  "مقاومت به کلیه داروهای خط اول وخیم است ولی تعریف رسمی MDR را بازگو نمی‌کند."
 ],
 "why_en": [
  "Resistance to isoniazid and ethambutol is not MDR, because rifampin still works and the regimen is salvageable.",
  "Correct — MDR-TB means precisely simultaneous resistance to rifampin and isoniazid.",
  "That describes XDR-TB: MDR plus fluoroquinolone and second-line injectable resistance.",
  "Resistance to all first-line drugs is grave but does not state the formal definition of MDR."
 ],
 "golden_fa": "MDR = INH + RIF مقاوم. XDR = MDR + فلوروکینولون + تزریقی خط دوم. Xpert ریفامپین را ساعتی می‌گوید.",
 "golden_en": "MDR means INH plus RIF resistance. XDR means MDR plus fluoroquinolone plus a second-line injectable. Xpert detects rifampin resistance in hours.",
 "refs": ["Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 178: Tuberculosis, drug resistance"]
}

json.dump(L, io.open('/home/user/work/infectious/lessons/L8.json', 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('infectious L8:', len(L))
