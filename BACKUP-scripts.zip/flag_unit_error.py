# -*- coding: utf-8 -*-
"""Flag a WRONG UNIT that glyph geometry cannot fix: q9542 option A.

The option reads "سیپروفلوکساسین 500 گرم هر 12 ساعت" — ciprofloxacin 500 GRAMS
every 12 hours. The digits are right; the UNIT is wrong. The Persian word گرم
(gram) is printed where میلی‌گرم (milligram) belongs.

Why this needs its own script, and its own treatment
-----------------------------------------------------
Every other numeric repair in this bank was settled by glyph geometry: the page
prints the digits in a definite order, and the extractor reversed them. That
method can say YES or NO because there is a physical fact to appeal to.

Here there is no such fact. The page really does print the word "گرم". This is
not an extraction defect at all — it is an error in the SOURCE BOOK. So the
honest thing is not to silently rewrite the option, which would misrepresent
what the book says, but to LEAVE THE TEXT AND ANNOTATE IT.

That distinction matters for a student. If the printed option is quietly
corrected, a student sitting the real exam with the real booklet sees something
different from what we showed them. If it is left alone with a note, they learn
both the medicine and the fact that printed material can be wrong — which is
the same lesson the corrected keys teach.

500 g of ciprofloxacin is roughly half a kilogram of antibiotic. The correct
dose in this context is 500 mg twice daily. The option is wrong medicine either
way — ciprofloxacin does not treat chlamydia, which is the real point of the
question — so the unit error does not change the answer. It is flagged so that
nobody, human or script, later "fixes" the digits and makes it look plausible.
"""
import json, io, os

HERE = os.path.dirname(os.path.abspath(__file__))

FLAGS = {
    9542: {
        'option_index': 0,
        'contains': 'گرم',
        'fa': 'واحد این گزینه در کتاب اشتباه چاپ شده است: «۵۰۰ گرم» نوشته شده در حالی که '
              'دوز درست سیپروفلوکساسین **۵۰۰ میلی‌گرم** هر ۱۲ ساعت است. متن عمداً '
              'دست‌نخورده باقی مانده تا با دفترچه‌ی چاپی یکی باشد، و خطا فقط علامت‌گذاری '
              'شده است. توجه کنید که این خطا پاسخ سؤال را عوض نمی‌کند: سیپروفلوکساسین در '
              'هر صورت کلامیدیا را پوشش نمی‌دهد و گزینه‌ی نادرستی است.',
        'en': 'The unit in this option is misprinted in the source book: it reads "500 grams" '
              'where the correct ciprofloxacin dose is 500 MILLIGRAMS every 12 hours. The text '
              'is deliberately left unchanged so that it matches the printed booklet, and the '
              'error is only annotated. Note that it does not change the answer: ciprofloxacin '
              'does not cover chlamydia and is the wrong option either way.',
    },
}


def main():
    done, missing = [], []
    for i in range(1, 6):
        p = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        body = json.load(io.open(p, encoding='utf-8'))
        dirty = False
        for q in body['questions']:
            spec = FLAGS.get(q['question_no'])
            if not spec:
                continue
            oi = spec['option_index']
            opt = q['options_fa'][oi]
            if spec['contains'] not in opt:
                missing.append(f"q{q['question_no']}: option {oi + 1} no longer contains "
                               f"{spec['contains']!r} — has it already been edited?")
                continue
            # record, do not rewrite
            notes = q.setdefault('source_unit_errors', [])
            if any(n.get('option_index') == oi for n in notes):
                continue
            notes.append({
                'option_index': oi,
                'printed': opt.strip(),
                'note_fa': spec['fa'],
                'note_en': spec['en'],
                'action': 'annotated, text left unchanged (this is a source error, '
                          'not an extraction defect)',
            })
            done.append(f"q{q['question_no']}: option {oi + 1} flagged (unit)")
            dirty = True
        if dirty:
            json.dump(body, io.open(p, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)
    for d in done:
        print('flagged', d)
    for m in missing:
        print('SKIP   ', m)
    print(f'\n{len(done)} unit error(s) annotated')


if __name__ == '__main__':
    main()
