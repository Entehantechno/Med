# -*- coding: utf-8 -*-
"""Micro-lessons, batch 28 — endocarditis: recognising it and counting Duke.

The endocarditis chapter is the most COUNTABLE block in the book. Nine of its
thirty-six questions put a patient in front of the student and ask, literally,
"how many major and how many minor Duke criteria does this person have?" Three
more ask which single finding is a major criterion. That is a third of the
chapter decided by one memorised table — and by the discipline to apply it
without inventing criteria that are not on it.

This batch teaches that table and the recognition that comes before it.

THE TRAP THAT DECIDES MOST OF THESE QUESTIONS
----------------------------------------------
Students lose these marks in one predictable way: they count things that FEEL
like evidence of endocarditis but are NOT Duke criteria. Injecting drug use is
a predisposition (minor), not a major. A single positive blood culture is not a
major criterion. Glomerulonephritis is an immunologic phenomenon (minor). And
crucially, PAINFUL versus PAINLESS distinguishes two different minor criteria:
Osler nodes are painful and immunologic, Janeway lesions are painless and
vascular. The book asks about that distinction repeatedly.

So the lessons below give the criteria as a closed list and then, in every
counting question, walk the tally item by item so the student sees which
findings earned a point and which earned nothing.

A NOTE ON WHICH DUKE VERSION IS TAUGHT
---------------------------------------
The exam questions are written against the MODIFIED DUKE criteria (Li, 2000),
which is what Harrison 21e presents and what the answer keys assume. The 2023
Duke-ISCVID revision exists and is referenced in the lessons where it changes
something a student might meet in practice, but the counting is taught the way
the exam counts it. Saying "the newer criteria would score this differently"
without saying which one the exam wants would be worse than useless.

Numbers repaired before writing: q9101's blood pressure and q9113's two
temperatures; see fix_endocarditis_numbers.py. The q9113 repair matters here
because that question is a Duke-counting question and a fever below 38 °C
scores nothing.

Reference: Baddour LM et al., "Infective Endocarditis in Adults: Diagnosis,
Antimicrobial Therapy, and Management of Complications", Circulation
2015;132:1435-1486 (AHA); Li JS et al., "Proposed Modifications to the Duke
Criteria", Clin Infect Dis 2000;30:633-638; Fowler VG et al., "The 2023
Duke-ISCVID Criteria for Infective Endocarditis", Clin Infect Dis
2023;77:518-526; Harrison's Principles of Internal Medicine, 21st ed (2022),
Ch. 128 (Infective Endocarditis).
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


BADDOUR = ("Baddour LM et al. — Infective Endocarditis in Adults: Diagnosis, Antimicrobial "
           "Therapy, and Management of Complications. Circulation 2015;132(15):1435-1486 "
           "(American Heart Association)")
LI2000 = ("Li JS et al. — Proposed Modifications to the Duke Criteria for the Diagnosis of "
          "Infective Endocarditis. Clin Infect Dis 2000;30(4):633-638")
ISCVID = ("Fowler VG et al. — The 2023 Duke-ISCVID Criteria for Infective Endocarditis: "
          "Updating the Modified Duke Criteria. Clin Infect Dis 2023;77(4):518-526")
H128 = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 128: "
        "Infective Endocarditis")

# ---------------------------------------------------------------- the table
DUKE_FA = [
    "⚠️ **معیارهای دوک را به‌صورت یک فهرست بسته حفظ کنید. هرچه در این فهرست نیست، امتیاز ندارد.**",
    "**دو معیار ماژور وجود دارد — فقط دو تا:**",
    "⚠️ **ماژور یک — کشت خون مثبت، ولی با شرط:**",
    "**یا دو کشت جدا** با ارگانیسم تیپیک اندوکاردیت (استرپتوکوک ویریدنس، استرپتوکوک بوویس، گروه HACEK، استاف اورئوس، انتروکوک اکتسابی از جامعه بدون کانون)،",
    "**یا کشت مثبت پایدار** (دو کشت با فاصله‌ی بیش از ۱۲ ساعت، یا سه کشت از سه کشت).",
    "⚠️ **ماژور دو — شواهد درگیری اندوکارد:**",
    "**وژتاسیون متحرک، آبسه‌ی حلقه‌ی دریچه، جدا شدن تازه‌ی دریچه‌ی مصنوعی،**",
    "**یا نارسایی دریچه‌ای جدید** (سوفل تازه، نه تشدید سوفل قدیمی).",
    "**و پنج معیار مینور — با حرف اول هرکدام بسازید: زمینه، تب، عروقی، ایمنی، میکروب.**",
    "**مینور یک — زمینه:** بیماری دریچه‌ای، دریچه‌ی مصنوعی، **اعتیاد تزریقی**، یا سابقه‌ی اندوکاردیت.",
    "⚠️ **مینور دو — تب ۳۸ درجه یا بالاتر.** زیر ۳۸ امتیاز ندارد؛ این یک آستانه است نه یک احساس.",
    "**مینور سه — پدیده‌های عروقی (آمبولیک):** آمبولی شریانی، **آمبولی سپتیک ریوی**،",
    "آنوریسم مایکوتیک، خونریزی داخل جمجمه، خونریزی ملتحمه، و **ضایعات جین‌وی**.",
    "**مینور چهار — پدیده‌های ایمونولوژیک:** گلومرولونفریت، **ندول اسلر**، لکه‌های راث، **فاکتور روماتوئید مثبت**.",
    "**مینور پنج — شواهد میکروبی که به ماژور نمی‌رسند:** مثلاً **یک نوبت کشت مثبت**.",
    "⚠️ **حالا مهم‌ترین تمایز امتحانی این فصل: اسلر در برابر جین‌وی.**",
    "**ندول اسلر: دردناک، روی نوک انگشتان، منشأ ایمونولوژیک** (اسلر = اوچ = درد).",
    "**ضایعه‌ی جین‌وی: بدون درد، کف دست و پا، منشأ آمبولیک/عروقی.**",
    "⚠️ **پس یک ضایعه‌ی «بدون تندرنس در کف دست و پا» یک معیار عروقی است، نه ایمونولوژیک.**",
    "**و جمع‌بندی نهایی — تشخیص قطعی با یکی از این سه:**",
    "**دو ماژور؛ یا یک ماژور و سه مینور؛ یا پنج مینور.**",
    "**تشخیص محتمل: یک ماژور و یک مینور؛ یا سه مینور.**",
    "⚠️ **دامی که بیشترین امتیاز را می‌گیرد: چیزهایی که معیار نیستند.**",
    "**اعتیاد تزریقی ماژور نیست** (مینورِ زمینه است). **یک کشت مثبت ماژور نیست** (مینورِ میکروبی است).",
    "**گلومرولونفریت ماژور نیست** (مینورِ ایمنی است). **لکوسیتوز اصلاً معیار نیست.**",
]
DUKE_EN = [
    "WARNING: MEMORISE THE DUKE CRITERIA AS A CLOSED LIST. ANYTHING NOT ON THE LIST SCORES NOTHING.",
    "THERE ARE TWO MAJOR CRITERIA — only two:",
    "WARNING, MAJOR ONE — A POSITIVE BLOOD CULTURE, BUT WITH CONDITIONS:",
    "EITHER TWO SEPARATE CULTURES growing a typical endocarditis organism (viridans streptococci, S. bovis, the HACEK group, S. aureus, or community-acquired enterococcus without a focus),",
    "OR PERSISTENTLY POSITIVE CULTURES (two drawn more than 12 hours apart, or three of three).",
    "WARNING, MAJOR TWO — EVIDENCE OF ENDOCARDIAL INVOLVEMENT:",
    "a MOBILE VEGETATION, a VALVE-RING ABSCESS, NEW DEHISCENCE OF A PROSTHETIC VALVE,",
    "OR NEW VALVULAR REGURGITATION (a new murmur, not the worsening of an old one).",
    "AND FIVE MINOR CRITERIA — build them from five words: predisposition, fever, vascular, immunologic, microbiologic.",
    "MINOR ONE — PREDISPOSITION: valvular disease, a prosthetic valve, INJECTING DRUG USE, or previous endocarditis.",
    "WARNING, MINOR TWO — FEVER OF 38 °C OR ABOVE. Below 38 scores nothing; this is a threshold, not an impression.",
    "MINOR THREE — VASCULAR (EMBOLIC) PHENOMENA: arterial emboli, SEPTIC PULMONARY EMBOLI,",
    "mycotic aneurysm, intracranial haemorrhage, conjunctival haemorrhage, and JANEWAY LESIONS.",
    "MINOR FOUR — IMMUNOLOGIC PHENOMENA: glomerulonephritis, OSLER NODES, Roth spots, POSITIVE RHEUMATOID FACTOR.",
    "MINOR FIVE — MICROBIOLOGIC EVIDENCE FALLING SHORT OF MAJOR: for example A SINGLE POSITIVE CULTURE.",
    "WARNING, NOW THE MOST EXAMINED DISTINCTION IN THIS CHAPTER: OSLER VERSUS JANEWAY.",
    "OSLER NODES: PAINFUL, on the FINGER PULPS, IMMUNOLOGIC in origin (Osler = Ouch).",
    "JANEWAY LESIONS: PAINLESS, on the PALMS AND SOLES, EMBOLIC/VASCULAR in origin.",
    "WARNING: SO A NON-TENDER LESION ON THE PALMS AND SOLES IS A VASCULAR CRITERION, NOT AN IMMUNOLOGIC ONE.",
    "AND THE FINAL TALLY — DEFINITE ENDOCARDITIS BY ANY ONE OF THESE THREE:",
    "TWO MAJOR; or ONE MAJOR AND THREE MINOR; or FIVE MINOR.",
    "POSSIBLE ENDOCARDITIS: one major and one minor; or three minor.",
    "WARNING, THE TRAP THAT COSTS THE MOST MARKS: THINGS THAT ARE NOT CRITERIA AT ALL.",
    "INJECTING DRUG USE IS NOT A MAJOR (it is the predisposition minor). A SINGLE POSITIVE CULTURE IS NOT A MAJOR (it is the microbiologic minor).",
    "GLOMERULONEPHRITIS IS NOT A MAJOR (it is the immunologic minor). LEUCOCYTOSIS IS NOT A CRITERION AT ALL.",
]

# ------------------------------------------------------- recognising the disease
RECOG_FA = [
    "⚠️ **اندوکاردیت را از یک ترکیب بشناسید: تب + سوفل + پدیده‌های محیطی.**",
    "**تب تقریباً همیشه هست؛ سوفل در بیش از ۸۵ درصد؛ و پدیده‌های محیطی همان چیزی‌اند که تشخیص را قطعی می‌کنند.**",
    "**پدیده‌های محیطی را در چهار جا بگردید — و در امتحان همیشه همین چهار جا را می‌گویند:**",
    "**یک — بستر ناخن:** **خونریزی خطی (splinter)**، مثل یک خط باریک قهوه‌ای زیر ناخن.",
    "**دو — نوک انگشتان:** **ندول اسلر، دردناک** — رسوب کمپلکس ایمنی.",
    "**سه — کف دست و پا:** **ضایعه‌ی جین‌وی، بدون درد** — آمبولی سپتیک کوچک.",
    "**چهار — ملتحمه و ته چشم:** **پتشی ملتحمه** و **لکه‌های راث** (خونریزی با مرکز روشن).",
    "⚠️ **در معتاد تزریقی، قاعده‌ها عوض می‌شوند و باید جداگانه یاد بگیرید:**",
    "**دریچه‌ی درگیر: تریکوسپید (سمت راست قلب).** چون تلقیح باکتری از ورید است.",
    "⚠️ **و چون سمت راست است، تابلو ریوی است نه سیستمیک:** سرفه، تنگی نفس، درد پلورتیک.",
    "**گرافی سینه: ندول‌های متعدد و پراکنده در هر دو ریه — همان آمبولی سپتیک ریوی.**",
    "**و سمع قلب می‌تواند طبیعی باشد** — نارسایی تریکوسپید سوفل ضعیفی می‌دهد و اغلب شنیده نمی‌شود.",
    "⚠️ **این مهم‌ترین دام فصل است: «سمع قلب نرمال» اندوکاردیت را رد نمی‌کند.**",
    "**شایع‌ترین ارگانیسم در معتاد تزریقی: استافیلوکوکوس اورئوس** — تهاجمی، سریع، و مخرب.",
    "**در دریچه‌ی طبیعی و غیرمعتاد: استرپتوکوک ویریدنس** (سیر تحت‌حاد، از فلور دهان).",
    "**در دریچه‌ی مصنوعی زودرس (زیر یک سال): استاف اپیدرمیدیس** (کوآگولاز منفی).",
    "⚠️ **و یک ارتباط طلایی: استرپتوکوک بوویس (گالولیتیکوس) ← کولونوسکوپی.**",
    "**چون این ارگانیسم با ضایعات کولون، به‌ویژه کارسینوم و پولیپ، همراهی محکمی دارد.**",
    "**اقدام تشخیصی پایه در همه‌ی موارد: کشت خون + اکوکاردیوگرافی — و کشت خون اول.**",
    "**سه ست کشت خون از سه محل جدا، پیش از شروع آنتی‌بیوتیک.**",
]
RECOG_EN = [
    "WARNING: RECOGNISE ENDOCARDITIS FROM A COMBINATION: FEVER PLUS A MURMUR PLUS PERIPHERAL PHENOMENA.",
    "Fever is almost always present; a murmur in over 85 per cent; and the peripheral phenomena are what clinch it.",
    "LOOK FOR THE PERIPHERAL SIGNS IN FOUR PLACES — and the exam always names these same four:",
    "ONE — THE NAIL BED: SPLINTER HAEMORRHAGES, like a thin brown line under the nail.",
    "TWO — THE FINGER PULPS: OSLER NODES, PAINFUL — deposited immune complexes.",
    "THREE — THE PALMS AND SOLES: JANEWAY LESIONS, PAINLESS — small septic emboli.",
    "FOUR — THE CONJUNCTIVA AND FUNDUS: CONJUNCTIVAL PETECHIAE and ROTH SPOTS (haemorrhages with a pale centre).",
    "WARNING: IN AN INJECTING DRUG USER THE RULES CHANGE AND MUST BE LEARNED SEPARATELY:",
    "THE VALVE INVOLVED IS THE TRICUSPID (the right side of the heart), because the inoculum arrives by vein.",
    "WARNING, AND BECAUSE IT IS RIGHT-SIDED, THE PICTURE IS PULMONARY, NOT SYSTEMIC: cough, breathlessness, pleuritic pain.",
    "CHEST FILM: MULTIPLE SCATTERED NODULES IN BOTH LUNGS — those are the septic pulmonary emboli.",
    "AND CARDIAC AUSCULTATION MAY BE NORMAL: tricuspid regurgitation gives a soft murmur that is often not heard.",
    "WARNING, THIS IS THE CHAPTER'S BIGGEST TRAP: 'NORMAL HEART SOUNDS' DOES NOT EXCLUDE ENDOCARDITIS.",
    "THE COMMONEST ORGANISM IN AN INJECTING DRUG USER IS STAPHYLOCOCCUS AUREUS — aggressive, rapid, destructive.",
    "On a native valve in a non-user: VIRIDANS STREPTOCOCCI (a subacute course, from mouth flora).",
    "On an EARLY prosthetic valve (within a year): STAPHYLOCOCCUS EPIDERMIDIS (coagulase negative).",
    "WARNING, AND ONE GOLDEN ASSOCIATION: STREPTOCOCCUS BOVIS (gallolyticus) MEANS COLONOSCOPY.",
    "Because that organism is strongly associated with colonic lesions, above all carcinoma and polyps.",
    "THE BASELINE DIAGNOSTIC STEP IN EVERY CASE: BLOOD CULTURES PLUS ECHOCARDIOGRAPHY — cultures first.",
    "Three sets of blood cultures from three separate sites, before antibiotics are started.",
]


# =========================================================== book:97
add("book:97", "case", "medium",
 "معتاد تزریقی + سوفل + خونریزی زیر ناخن + **میکروآبسه‌های مغزی** ← **استاف اورئوس**.",
 "An injecting drug user with a murmur, splinter haemorrhages and BRAIN MICROABSCESSES: STAPHYLOCOCCUS AUREUS.",
 RECOG_FA + [
  "**در این سؤال دو سرنخ، ارگانیسم را قطعی می‌کنند و باید هر دو را ببینید.**",
  "**سرنخ یک — اعتیاد تزریقی:** شایع‌ترین عامل در این گروه **استاف اورئوس** است.",
  "⚠️ **سرنخ دو — میکروآبسه‌های متعدد در مغز و مننژ.**",
  "**این یعنی ارگانیسم توانایی ساختن آبسه دارد — یک ویژگی تهاجمی.**",
  "**استاف اورئوس آبسه می‌سازد؛ استرپتوکوک ویریدنس عملاً نمی‌سازد.**",
  "**تب ۳۹/۵ درجه هم به همین سیر حاد و تهاجمی می‌خورد، نه به تابلوی تحت‌حاد ویریدنس.**",
  "⚠️ **قاعده‌ی کلی: هرچه سیر حادتر و تخریب بیشتر، احتمال استاف اورئوس بالاتر.**",
  "**اندوکاردیت استاف اورئوس در عرض روزها دریچه را تخریب می‌کند و آمبولی می‌فرستد.**",
  "**اندوکاردیت ویریدنس در عرض هفته‌ها تا ماه‌ها با تب مختصر و کاهش وزن پیش می‌رود.**",
 ],
 RECOG_EN + [
  "TWO CLUES IN THIS STEM SETTLE THE ORGANISM, AND BOTH MUST BE SEEN.",
  "CLUE ONE — INJECTING DRUG USE: the commonest agent in this group is STAPHYLOCOCCUS AUREUS.",
  "WARNING, CLUE TWO — MULTIPLE MICROABSCESSES IN THE BRAIN AND MENINGES.",
  "That means the organism can FORM ABSCESSES, which is an invasive property.",
  "S. aureus forms abscesses; viridans streptococci essentially do not.",
  "A temperature of 39.5 also fits this acute, invasive course rather than a subacute viridans picture.",
  "WARNING, THE GENERAL RULE: THE MORE ACUTE THE COURSE AND THE GREATER THE DESTRUCTION, THE MORE LIKELY S. AUREUS.",
  "S. aureus endocarditis destroys a valve within days and throws emboli.",
  "Viridans endocarditis evolves over weeks to months with low-grade fever and weight loss.",
 ],
 "این سؤال یک تمرین ساده‌ی «ارگانیسم را از تابلو بخوان» است.\n\n"
 "**بیمار ۲۶ ساله‌ی معتاد تزریقی** با **تب ۳۹/۵**، **سوفل قلبی**، **خونریزی زیر ناخن** و "
 "**میکروآبسه‌های متعدد در مغز و مننژ**.\n\n"
 "⚠️ **دو سرنخ به یک جواب می‌رسند.**\n\n"
 "**اول، زمینه:** در معتاد تزریقی، **استافیلوکوکوس اورئوس** شایع‌ترین عامل اندوکاردیت است — "
 "چون پوست منبع اصلی آلودگی سوزن است و استاف اورئوس ساکن پوست است.\n\n"
 "**دوم، و قاطع‌تر: میکروآبسه.** توانایی ساختن آبسه در محل آمبولی، مشخصه‌ی ارگانیسم‌های "
 "**تهاجمی و چرک‌ساز** است. **استاف اورئوس دقیقاً چنین ارگانیسمی است.** استرپتوکوک ویریدنس "
 "با آنکه شایع‌ترین علت اندوکاردیت دریچه‌ی طبیعی در غیرمعتادان است، تابلوی تحت‌حاد و کم‌تخریب "
 "می‌سازد و آبسه‌ی مغزی از آن انتظار نمی‌رود.\n\n"
 "**نکته‌ی بالینی مهم:** آمبولی سپتیک به مغز در اندوکاردیت سمت چپ رخ می‌دهد. پس این بیمار "
 "احتمالاً **درگیری سمت چپ یا دوطرفه** دارد، نه صرفاً تریکوسپید — و این یعنی خطر بالاتر و "
 "نیاز به بررسی فوری‌تر.",
 "This question is a straightforward exercise in reading the organism off the picture.\n\n"
 "A 26-YEAR-OLD INJECTING DRUG USER with a temperature of 39.5, a CARDIAC MURMUR, SPLINTER "
 "HAEMORRHAGES and MULTIPLE MICROABSCESSES IN THE BRAIN AND MENINGES.\n\n"
 "WARNING: TWO CLUES CONVERGE ON ONE ANSWER.\n\n"
 "FIRST, THE SETTING: in an injecting drug user, STAPHYLOCOCCUS AUREUS is the commonest cause "
 "of endocarditis, because the skin is the main source of needle contamination and S. aureus "
 "lives on skin.\n\n"
 "SECOND, AND MORE DECISIVE: THE MICROABSCESSES. The ability to form an abscess where an "
 "embolus lodges marks an INVASIVE, PUS-FORMING organism. S. AUREUS IS EXACTLY THAT ORGANISM. "
 "Viridans streptococci, although the commonest cause of native-valve endocarditis in "
 "non-users, produce a subacute, low-destruction picture in which brain abscess is not "
 "expected.\n\n"
 "AN IMPORTANT CLINICAL POINT: septic embolism to the brain occurs in LEFT-SIDED endocarditis. "
 "So this patient probably has left-sided or bilateral involvement rather than tricuspid "
 "disease alone — which means higher risk and a more urgent work-up.",
 ["استاف اپیدرمیدیس عامل اندوکاردیت دریچه‌ی مصنوعی زودرس است، نه این تابلوی تهاجمی در دریچه‌ی طبیعی.",
  "پاسخ صحیح — اعتیاد تزریقی به‌علاوه‌ی میکروآبسه‌ی مغزی، مشخصه‌ی استاف اورئوس است.",
  "انتروکوک فکالیس بیشتر پس از دستکاری ادراری-تناسلی و در سالمندان مطرح است و آبسه‌ساز نیست.",
  "سودوموناس در معتادان دیده می‌شود ولی بسیار نادرتر است و اینجا سرنخ اختصاصی ندارد."],
 ["S. epidermidis causes early prosthetic-valve endocarditis, not this invasive native-valve picture.",
  "Correct — injecting drug use plus brain microabscesses is characteristic of S. aureus.",
  "Enterococcus faecalis is more typical after genitourinary instrumentation and in older patients, and does not form abscesses.",
  "Pseudomonas is seen in drug users but is far rarer, and nothing here points specifically to it."],
 "**معتاد تزریقی + آبسه = استاف اورئوس.** آبسه‌سازی ویژگی ارگانیسم تهاجمی است.",
 "Injecting drug use plus abscess formation means Staphylococcus aureus; abscesses mark an invasive organism.",
 [H128, BADDOUR])


# =========================================================== book:98
add("book:98", "case", "hard",
 "کشت خون **منفی پس از ۷۲ ساعت** بدون آنتی‌بیوتیک قبلی ← ارگانیسم **سخت‌رشد**: گروه **HACEK**.",
 "BLOOD CULTURES STILL NEGATIVE AT 72 HOURS with no prior antibiotics means a FASTIDIOUS organism: the HACEK group.",
 RECOG_FA + [
  "⚠️ **کلید این سؤال یک جمله است: «بیمار از قبل آنتی‌بیوتیک دریافت نکرده است».**",
  "**این جمله عمداً آمده تا شایع‌ترین علت کشت منفی را حذف کند.**",
  "**شایع‌ترین علت اندوکاردیت با کشت منفی، مصرف قبلی آنتی‌بیوتیک است — و اینجا رد شده.**",
  "**پس علت بعدی مطرح است: ارگانیسمی که به‌سختی و به‌کندی رشد می‌کند.**",
  "⚠️ **گروه HACEK را با همین سرنام حفظ کنید:**",
  "**H** — هموفیلوس (و آگرگاتی‌باکتر آفروفیلوس). **A** — آگرگاتی‌باکتر اکتینومیستم‌کومیتانس.",
  "**C** — کاردیوباکتریوم هومینیس. **E** — ایکنلا کورودنس. **K** — کینگلا کینگه.",
  "**همگی باسیل‌های گرم‌منفی سخت‌رشدِ فلور دهان و حلق‌اند.**",
  "⚠️ **مشخصه‌ی بالینی‌شان: سیر تحت‌حاد و وژتاسیون‌های بزرگ با احتمال آمبولی بالا.**",
  "**سایر علل کشت منفی که باید بشناسید: کوکسیلا بورنتی (تب کیو)، بارتونلا، بروسلا، قارچ‌ها.**",
  "**این‌ها با کشت معمولی رشد نمی‌کنند و نیاز به سرولوژی یا PCR دارند.**",
 ],
 RECOG_EN + [
  "WARNING: THE KEY TO THIS QUESTION IS ONE SENTENCE — 'the patient has received no prior antibiotics'.",
  "That sentence is there deliberately, to remove the commonest cause of negative cultures.",
  "THE COMMONEST CAUSE OF CULTURE-NEGATIVE ENDOCARDITIS IS PRIOR ANTIBIOTIC USE — and it has been excluded.",
  "So the next explanation applies: an organism that grows slowly and with difficulty.",
  "WARNING, MEMORISE THE HACEK GROUP BY ITS ACRONYM:",
  "H — Haemophilus (and Aggregatibacter aphrophilus). A — Aggregatibacter actinomycetemcomitans.",
  "C — Cardiobacterium hominis. E — Eikenella corrodens. K — Kingella kingae.",
  "All are FASTIDIOUS GRAM-NEGATIVE BACILLI OF THE OROPHARYNGEAL FLORA.",
  "WARNING, THEIR CLINICAL SIGNATURE: a subacute course with LARGE VEGETATIONS and a high embolic risk.",
  "OTHER CAUSES OF CULTURE-NEGATIVE DISEASE WORTH KNOWING: Coxiella burnetii (Q fever), Bartonella, Brucella, fungi.",
  "These do not grow on routine culture and need serology or PCR.",
 ],
 "این سؤال یک تمرین حذف است، و جمله‌ی تعیین‌کننده‌اش به‌راحتی از چشم می‌افتد.\n\n"
 "**جوان ۲۵ ساله** با **کاهش وزن و تب دوهفته‌ای**، **سوفل سیستولیک میترال**، **بزرگی طحال** و "
 "**راش اکیموتیک**. سه نوبت کشت خون گرفته شده و **پس از ۷۲ ساعت منفی** است.\n\n"
 "⚠️ **حالا جمله‌ی کلیدی: «بیمار از قبل آنتی‌بیوتیک دریافت نکرده است.»**\n\n"
 "چرا این جمله مهم است؟ چون **شایع‌ترین علت کشت خون منفی در اندوکاردیت، مصرف قبلی "
 "آنتی‌بیوتیک است** — و طراح سؤال آن را عمداً حذف کرده تا شما مجبور شوید به علت دوم فکر کنید: "
 "**ارگانیسم سخت‌رشد (fastidious).**\n\n"
 "**گروه HACEK** دقیقاً همین است: باسیل‌های گرم‌منفی سخت‌رشد از فلور دهان که **در محیط کشت "
 "معمولی به کندی رشد می‌کنند** و ممکن است تا چند روز کشت را منفی نشان دهند. "
 "**کاردیوباکتریوم هومینیس** یکی از اعضای همین گروه است.\n\n"
 "**بقیه‌ی تابلو هم می‌خواند:** سیر تحت‌حاد دوهفته‌ای با کاهش وزن، بزرگی طحال و پدیده‌های "
 "محیطی — همان الگوی کلاسیک اندوکاردیت تحت‌حاد که HACEK می‌سازد.\n\n"
 "⚠️ **نکته‌ی عملی:** امروزه با سیستم‌های کشت خودکار، HACEK معمولاً ظرف ۵ روز رشد می‌کند و "
 "دیگر لازم نیست کشت را عمداً طولانی نگه داشت؛ ولی همچنان کندترین گروه شایع است.",
 "This is an exercise in elimination, and its decisive sentence is easy to miss.\n\n"
 "A 25-YEAR-OLD with two weeks of WEIGHT LOSS AND FEVER, a MITRAL SYSTOLIC MURMUR, "
 "SPLENOMEGALY and an ECCHYMOTIC RASH. Three sets of blood cultures are NEGATIVE AT 72 HOURS.\n\n"
 "WARNING, NOW THE KEY SENTENCE: 'the patient has received no prior antibiotics'.\n\n"
 "Why does that matter? Because THE COMMONEST CAUSE OF NEGATIVE BLOOD CULTURES IN "
 "ENDOCARDITIS IS PRIOR ANTIBIOTIC THERAPY — and the examiner has deliberately removed it so "
 "that you must reach for the second explanation: A FASTIDIOUS ORGANISM.\n\n"
 "THE HACEK GROUP is precisely that: fastidious gram-negative bacilli from mouth flora that "
 "GROW SLOWLY ON ROUTINE MEDIA and may leave cultures negative for several days. "
 "CARDIOBACTERIUM HOMINIS is a member of that group.\n\n"
 "THE REST OF THE PICTURE FITS: a subacute two-week course with weight loss, splenomegaly and "
 "peripheral phenomena — the classic subacute pattern HACEK produces.\n\n"
 "WARNING, A PRACTICAL NOTE: with modern automated culture systems HACEK usually grows within "
 "5 days and prolonged incubation is no longer routinely required, but it remains the slowest "
 "of the common groups.",
 ["استاف اورئوس سریع و در عرض ۲۴ تا ۴۸ ساعت رشد می‌کند؛ با کشت منفی ۷۲ ساعته نمی‌خواند.",
  "استرپتوکوک ویریدنس هم در کشت معمولی به‌راحتی و زودتر از ۷۲ ساعت رشد می‌کند.",
  "انتروکوک نیز ارگانیسم سخت‌رشدی نیست و در کشت استاندارد به‌سرعت مثبت می‌شود.",
  "پاسخ صحیح — کاردیوباکتریوم هومینیس عضو گروه HACEK و سخت‌رشد است."],
 ["S. aureus grows quickly, within 24 to 48 hours; it does not fit cultures negative at 72 hours.",
  "Viridans streptococci also grow readily on routine media, sooner than 72 hours.",
  "Enterococcus is not fastidious either and turns standard cultures positive quickly.",
  "Correct — Cardiobacterium hominis belongs to the fastidious HACEK group."],
 "**کشت منفی + بدون آنتی‌بیوتیک قبلی = ارگانیسم سخت‌رشد (HACEK).**",
 "Negative cultures with no prior antibiotics point to a fastidious organism, the HACEK group.",
 [H128, BADDOUR])


# =========================================================== book:99
add("book:99", "recall", "easy",
 "**کوکسیلا بورنتی جزو HACEK نیست** — عامل تب کیو است و کشت منفی از راه دیگری می‌سازد.",
 "COXIELLA BURNETII IS NOT IN HACEK: it causes Q fever and produces culture-negative disease by a different route.",
 RECOG_FA + [
  "⚠️ **این سؤال فقط یک چیز می‌خواهد: عضویت در سرنام HACEK.**",
  "**H — هموفیلوس** (و آگرگاتی‌باکتر آفروفیلوس، که قبلاً هموفیلوس آفروفیلوس نامیده می‌شد).",
  "**A — آگرگاتی‌باکتر اکتینومیستم‌کومیتانس.**",
  "**C — کاردیوباکتریوم هومینیس.**",
  "**E — ایکنلا کورودنس.**",
  "**K — کینگلا کینگه.**",
  "⚠️ **وجه اشتراکشان: همه باسیل گرم‌منفی، سخت‌رشد، و ساکن دهان و حلق‌اند.**",
  "**کوکسیلا بورنتی هیچ‌کدام از این‌ها نیست: یک کوکوباسیل داخل‌سلولی اجباری است.**",
  "**عامل تب کیو، و منبعش دام‌ها — به‌ویژه گوسفند، بز و گاو — و ترشحات زایمانی آن‌هاست.**",
  "⚠️ **و نکته‌ی مهم: کوکسیلا هم اندوکاردیت با کشت منفی می‌دهد، ولی به دلیل متفاوت.**",
  "**HACEK کند رشد می‌کند؛ کوکسیلا در کشت خون معمولی اصلاً رشد نمی‌کند** چون داخل‌سلولی است.",
  "**تشخیص کوکسیلا با سرولوژی (تیتر IgG فاز یک) یا PCR است، نه با کشت.**",
 ],
 RECOG_EN + [
  "WARNING: THIS QUESTION ASKS ONE THING ONLY — membership of the HACEK acronym.",
  "H — Haemophilus (and Aggregatibacter aphrophilus, formerly Haemophilus aphrophilus).",
  "A — Aggregatibacter actinomycetemcomitans.",
  "C — Cardiobacterium hominis.",
  "E — Eikenella corrodens.",
  "K — Kingella kingae.",
  "WARNING, WHAT THEY SHARE: all are fastidious gram-negative bacilli living in the mouth and throat.",
  "COXIELLA BURNETII IS NONE OF THESE: it is an OBLIGATE INTRACELLULAR coccobacillus.",
  "It causes Q FEVER, and its source is livestock — especially sheep, goats and cattle — and their birth products.",
  "WARNING, AN IMPORTANT POINT: Coxiella ALSO causes culture-negative endocarditis, but for a different reason.",
  "HACEK grows SLOWLY; Coxiella does not grow in routine blood culture AT ALL, because it is intracellular.",
  "Coxiella is diagnosed by SEROLOGY (phase I IgG titre) or PCR, not by culture.",
 ],
 "یک سؤال حفظی مستقیم، ولی با یک نکته‌ی مفهومی ارزشمند در پس‌زمینه.\n\n"
 "**سرنام HACEK** پنج جنس باکتری را نام می‌برد که همگی **باسیل گرم‌منفی سخت‌رشد از فلور "
 "دهان و حلق** هستند:\n\n"
 "**H** — هموفیلوس · **A** — آگرگاتی‌باکتر اکتینومیستم‌کومیتانس · **C** — کاردیوباکتریوم "
 "هومینیس · **E** — ایکنلا کورودنس · **K** — کینگلا کینگه\n\n"
 "سه گزینه‌ی دیگر (هموفیلوس، کاردیوباکتریوم، کینگلا) مستقیماً در این فهرست‌اند. "
 "**کوکسیلا بورنتی** نیست.\n\n"
 "⚠️ **اما چرا کوکسیلا در این سؤال آمده؟ چون یک شباهت گمراه‌کننده دارد:** آن هم عامل "
 "**اندوکاردیت با کشت خون منفی** است. طراح سؤال روی همین شباهت حساب کرده.\n\n"
 "**تفاوت، در مکانیسم است و همین را باید یاد بگیرید:**\n\n"
 "• **HACEK کشت را منفی نشان می‌دهد چون کند رشد می‌کند** — با صبر و انکوباسیون کافی، "
 "بالاخره رشد می‌کند.\n\n"
 "• **کوکسیلا کشت را منفی نشان می‌دهد چون یک باکتری داخل‌سلولی اجباری است** و در محیط "
 "کشت خون معمولی **هرگز** رشد نمی‌کند. تشخیصش فقط با **سرولوژی یا PCR** ممکن است.\n\n"
 "**نکته‌ی بالینی:** اندوکاردیت کوکسیلایی سیر بسیار مزمنی دارد، اغلب روی دریچه‌ی آسیب‌دیده یا "
 "مصنوعی می‌نشیند، و درمانش طولانی است (داکسی‌سیکلین + هیدروکسی‌کلروکین برای ماه‌ها تا سال‌ها).",
 "A direct recall question, but with a worthwhile concept behind it.\n\n"
 "THE HACEK ACRONYM names five genera, all FASTIDIOUS GRAM-NEGATIVE BACILLI OF THE "
 "OROPHARYNGEAL FLORA:\n\n"
 "H — Haemophilus · A — Aggregatibacter actinomycetemcomitans · C — Cardiobacterium hominis · "
 "E — Eikenella corrodens · K — Kingella kingae\n\n"
 "Three of the options (Haemophilus, Cardiobacterium, Kingella) are directly on that list. "
 "COXIELLA BURNETII IS NOT.\n\n"
 "WARNING, SO WHY IS COXIELLA IN THIS QUESTION? Because it shares a misleading feature: it too "
 "causes CULTURE-NEGATIVE ENDOCARDITIS. The examiner is counting on that resemblance.\n\n"
 "THE DIFFERENCE IS IN THE MECHANISM, AND THAT IS WHAT TO LEARN:\n\n"
 "• HACEK LEAVES CULTURES NEGATIVE BECAUSE IT GROWS SLOWLY — with patience and adequate "
 "incubation it does eventually grow.\n\n"
 "• COXIELLA LEAVES CULTURES NEGATIVE BECAUSE IT IS AN OBLIGATE INTRACELLULAR ORGANISM and "
 "NEVER grows in routine blood culture. It can only be diagnosed by SEROLOGY OR PCR.\n\n"
 "A CLINICAL NOTE: Q fever endocarditis runs a very chronic course, usually settles on a "
 "damaged or prosthetic valve, and needs prolonged treatment (doxycycline plus "
 "hydroxychloroquine for months to years).",
 ["پاسخ صحیح — کوکسیلا بورنتی عامل تب کیو و داخل‌سلولی اجباری است و جزو HACEK نیست.",
  "هموفیلوس حرف H در سرنام HACEK است.",
  "کاردیوباکتریوم حرف C در سرنام HACEK است.",
  "کینگلا حرف K در سرنام HACEK است."],
 ["Correct — Coxiella burnetii causes Q fever, is obligately intracellular, and is not part of HACEK.",
  "Haemophilus is the H of HACEK.",
  "Cardiobacterium is the C of HACEK.",
  "Kingella is the K of HACEK."],
 "**HACEK = هموفیلوس، آگرگاتی‌باکتر، کاردیوباکتریوم، ایکنلا، کینگلا.** کوکسیلا داخل‌سلولی است و بیرون از این فهرست.",
 "HACEK is Haemophilus, Aggregatibacter, Cardiobacterium, Eikenella, Kingella; Coxiella is intracellular and outside the list.",
 [H128, BADDOUR])


# =========================================================== book:100
add("book:100", "case", "medium",
 "**استرپتوکوک بوویس (گالولیتیکوس)** در کشت خون ← جست‌وجوی سرطان کولون ← **کولونوسکوپی**.",
 "STREPTOCOCCUS BOVIS (gallolyticus) in the blood means LOOK FOR COLON CANCER: COLONOSCOPY.",
 RECOG_FA + [
  "⚠️ **این سؤال یک ارتباط طلایی را می‌سنجد که باید بدون تردید بدانید:**",
  "**استرپتوکوک بوویس (نام جدید: استرپتوکوکوس گالولیتیکوس) ← ضایعه‌ی کولون.**",
  "**در بیش از نیمی از موارد باکتریمی با این ارگانیسم، یک ضایعه‌ی کولون پیدا می‌شود.**",
  "**شایع‌ترین ضایعات: کارسینوم کولون، پولیپ آدنوماتو، و گاهی بیماری التهابی روده.**",
  "⚠️ **پس هر بیمار با اندوکاردیت یا باکتریمی بوویس، باید کولونوسکوپی شود** — حتی اگر بدون علامت گوارشی باشد.",
  "**چرا؟** چون ضایعه‌ی کولون **سد مخاطی را می‌شکند** و اجازه می‌دهد این ارگانیسم روده‌ای وارد خون شود.",
  "**یعنی باکتریمی، علامت هشدار سرطان است، نه یک اتفاق تصادفی.**",
  "**و نکته‌ی مهم: کولونوسکوپی هم تشخیصی است و هم درمانی** (برداشتن پولیپ).",
  "⚠️ **ارتباط‌های مشابه که ارزش حفظ کردن دارند:**",
  "**انتروکوک ← دستکاری ادراری-تناسلی.** **استرپتوکوک ویریدنس ← دهان و دندان.**",
  "**کلستریدیوم سپتیکوم ← هم باز هم بدخیمی کولون** (این ارتباط حتی قوی‌تر است).",
 ],
 RECOG_EN + [
  "WARNING: THIS QUESTION TESTS ONE GOLDEN ASSOCIATION THAT MUST BE KNOWN WITHOUT HESITATION:",
  "STREPTOCOCCUS BOVIS (new name Streptococcus gallolyticus) MEANS A COLONIC LESION.",
  "In more than half of bacteraemias with this organism a colonic lesion is found.",
  "The commonest lesions: COLON CARCINOMA, ADENOMATOUS POLYPS, and sometimes inflammatory bowel disease.",
  "WARNING: SO EVERY PATIENT WITH BOVIS ENDOCARDITIS OR BACTERAEMIA NEEDS A COLONOSCOPY — even with no bowel symptoms.",
  "Why? Because the colonic lesion BREAKS THE MUCOSAL BARRIER and lets this gut organism into the blood.",
  "That is, the bacteraemia is a WARNING SIGN OF CANCER, not a coincidence.",
  "And note that colonoscopy is both DIAGNOSTIC AND THERAPEUTIC (polyp removal).",
  "WARNING, SIMILAR ASSOCIATIONS WORTH MEMORISING:",
  "ENTEROCOCCUS means genitourinary instrumentation. VIRIDANS STREPTOCOCCI mean mouth and teeth.",
  "CLOSTRIDIUM SEPTICUM means colonic malignancy again — that association is even stronger.",
 ],
 "این سؤال در ظاهر درباره‌ی اندوکاردیت است، ولی در واقع یک ارتباط انکولوژیک را می‌سنجد.\n\n"
 "**آقای ۶۰ ساله** با تب و ضعف دوهفته‌ای، **سوفل سیستولیک میترال**، و **وژتاسیون ۷ میلی‌متری** "
 "در اکوی مری. کشت خون در دو نوبت: **استرپتوکوک بوویس (گالولیتیکوس)**.\n\n"
 "تشخیص اندوکاردیت با دو ماژور (کشت خون تیپیک در دو نوبت + وژتاسیون) قطعی است. "
 "**پس سؤال درباره‌ی تشخیص نیست — درباره‌ی این است که حالا چه کار دیگری باید بکنیم.**\n\n"
 "⚠️ **و پاسخ در نام ارگانیسم است.**\n\n"
 "**استرپتوکوک بوویس یک ساکن طبیعی روده است.** برای اینکه وارد خون شود، باید **سد مخاطی "
 "کولون شکسته باشد**. شایع‌ترین چیزی که این سد را می‌شکند، **یک ضایعه‌ی نئوپلاستیک** است.\n\n"
 "مطالعات نشان داده‌اند در **بیش از ۵۰ درصد** بیماران با باکتریمی بوویس، کولونوسکوپی یک "
 "ضایعه پیدا می‌کند — اغلب **کارسینوم کولون یا پولیپ آدنوماتو**، و اغلب **بدون هیچ علامت "
 "گوارشی**.\n\n"
 "**پس کولونوسکوپی یک اقدام اختیاری یا تکمیلی نیست؛ بخشی از استاندارد مراقبت این بیمار است.**\n\n"
 "**چرا سایر گزینه‌ها نه؟** IVP و سی‌تی شکم بدون کنتراست، مخاط کولون را ارزیابی نمی‌کنند و "
 "پولیپ یا کارسینوم زودرس را از دست می‌دهند. سی‌تی مغز فقط در صورت وجود علائم نورولوژیک "
 "اندیکاسیون دارد که این بیمار ندارد.",
 "On the surface this is an endocarditis question; in reality it tests an oncological association.\n\n"
 "A 60-YEAR-OLD MAN with two weeks of fever and malaise, a MITRAL SYSTOLIC MURMUR and a 7 MM "
 "VEGETATION on transoesophageal echo. Blood cultures on two occasions: STREPTOCOCCUS BOVIS "
 "(gallolyticus).\n\n"
 "Endocarditis is already definite on two major criteria (a typical organism in two cultures "
 "plus a vegetation). SO THE QUESTION IS NOT ABOUT THE DIAGNOSIS — it is about what else must "
 "now be done.\n\n"
 "WARNING, AND THE ANSWER IS IN THE ORGANISM'S NAME.\n\n"
 "STREPTOCOCCUS BOVIS IS A NORMAL GUT INHABITANT. For it to enter the bloodstream, THE COLONIC "
 "MUCOSAL BARRIER MUST HAVE BEEN BREACHED. The commonest thing that breaches it is a NEOPLASTIC "
 "LESION.\n\n"
 "Studies show that in MORE THAN 50 PER CENT of patients with bovis bacteraemia, colonoscopy "
 "finds a lesion — most often COLONIC CARCINOMA OR AN ADENOMATOUS POLYP, and most often with "
 "NO BOWEL SYMPTOMS AT ALL.\n\n"
 "SO COLONOSCOPY IS NOT OPTIONAL OR SUPPLEMENTARY HERE; IT IS PART OF THE STANDARD OF CARE.\n\n"
 "WHY NOT THE OTHERS? An IVP and a non-contrast abdominal CT do not assess the colonic mucosa "
 "and will miss a polyp or an early carcinoma. A brain CT is indicated only with neurological "
 "signs, which this patient does not have.",
 ["IVP دستگاه ادراری را بررسی می‌کند و با استرپتوکوک بوویس ارتباطی ندارد.",
  "سی‌تی شکم بدون کنتراست، مخاط کولون را ارزیابی نمی‌کند و پولیپ یا کارسینوم زودرس را از دست می‌دهد.",
  "پاسخ صحیح — باکتریمی استرپتوکوک بوویس تا بیش از ۵۰ درصد با ضایعه‌ی کولون همراه است.",
  "سی‌تی مغز فقط با علائم نورولوژیک اندیکاسیون دارد و این بیمار چنین علائمی ندارد."],
 ["An IVP examines the urinary tract and has no association with S. bovis.",
  "A non-contrast abdominal CT does not assess colonic mucosa and misses polyps or early carcinoma.",
  "Correct — S. bovis bacteraemia is associated with a colonic lesion in more than half of cases.",
  "A brain CT is indicated only with neurological signs, which this patient does not have."],
 "**بوویس در خون = کولونوسکوپی.** باکتریمی، علامت هشدار ضایعه‌ی کولون است.",
 "Bovis in the blood means colonoscopy: the bacteraemia is a warning sign of a colonic lesion.",
 [H128, BADDOUR])


# =========================================================== book:109
add("book:109", "case", "hard",
 "کشت مثبت **۴ از ۴** (ماژور) + **وژتاسیون** (ماژور) + اعتیاد تزریقی و تب (۲ مینور) ← **۲ ماژور، ۲ مینور**.",
 "FOUR OF FOUR CULTURES POSITIVE (major) plus a VEGETATION (major), with drug use and fever (2 minors): TWO MAJOR, TWO MINOR.",
 DUKE_FA + [
  "⚠️ **این سؤال را باید مورد به مورد شمرد. عجله نکنید و هیچ چیزی را از قلم نیندازید.**",
  "**ماژور یک — کشت خون:** در **چهار کشت از چهار کشت** سودوموناس رشد کرده.",
  "**این «کشت مثبت پایدار» است و شرط ماژور را برآورده می‌کند.**",
  "⚠️ **دقت کنید: سودوموناس ارگانیسم «تیپیک» اندوکاردیت نیست،**",
  "**ولی مثبت شدن پایدار همه‌ی کشت‌ها، خودش راه دوم رسیدن به ماژور است.**",
  "**ماژور دو — اکوکاردیوگرافی:** وژتاسیون متحرک ۱×۱/۵ سانتی‌متر روی تریکوسپید.",
  "**مینور یک — زمینه:** اعتیاد تزریقی.",
  "**مینور دو — تب:** در صورت سؤال ذکر شده.",
  "⚠️ **حالا آنچه امتیاز ندارد و نباید شمرده شود:**",
  "**ضعف، بی‌اشتهایی و کاهش وزن معیار دوک نیستند** — علائم عمومی‌اند، نه معیار.",
  "**سمع قلب نرمال هم چیزی اضافه نمی‌کند** (و اندوکاردیت را هم رد نمی‌کند).",
  "**پس جمع: دو ماژور و دو مینور.** با دو ماژور، تشخیص **قطعی** است.",
 ],
 DUKE_EN + [
  "WARNING: THIS ONE MUST BE COUNTED ITEM BY ITEM. Do not rush, and do not skip anything.",
  "MAJOR ONE — BLOOD CULTURES: Pseudomonas grew in FOUR OF FOUR cultures.",
  "That is PERSISTENT POSITIVITY and satisfies the major criterion.",
  "WARNING, NOTE: Pseudomonas is not a 'typical' endocarditis organism,",
  "but persistent positivity of all cultures is the SECOND route to the same major criterion.",
  "MAJOR TWO — ECHOCARDIOGRAPHY: a mobile vegetation 1 x 1.5 cm on the tricuspid valve.",
  "MINOR ONE — PREDISPOSITION: injecting drug use.",
  "MINOR TWO — FEVER: stated in the stem.",
  "WARNING, NOW WHAT SCORES NOTHING AND MUST NOT BE COUNTED:",
  "WEAKNESS, ANOREXIA AND WEIGHT LOSS ARE NOT DUKE CRITERIA — they are general symptoms.",
  "Normal heart sounds add nothing either (and do not exclude endocarditis).",
  "TOTAL: TWO MAJOR AND TWO MINOR. With two majors the diagnosis is DEFINITE.",
 ],
 "یک سؤال شمارشی تمام‌عیار. راه درست، رفتن روی فهرست معیارها به ترتیب است — نه حدس زدن.\n\n"
 "**داده‌های بیمار:** جوان معتاد تزریقی · تب، ضعف، بی‌اشتهایی و کاهش وزن از سه ماه قبل · "
 "سمع قلب **نرمال** · اکو: **وژتاسیون متحرک ۱×۱/۵ سانتی‌متر روی تریکوسپید** · "
 "**چهار کشت خون، هر چهار مثبت برای سودوموناس آئروژینوزا**.\n\n"
 "⚠️ **بشماریم:**\n\n"
 "**۱) ماژور — کشت خون.** معیار ماژور میکروبی دو راه دارد: یا **ارگانیسم تیپیک در دو کشت "
 "جدا**، یا **کشت مثبت پایدار**. سودوموناس ارگانیسم تیپیک نیست، ولی **چهار از چهار کشت "
 "مثبت** به‌روشنی پایداری را ثابت می‌کند. **ماژور اول محرز است.**\n\n"
 "**۲) ماژور — تصویربرداری.** وژتاسیون متحرک روی دریچه = شواهد درگیری اندوکارد. "
 "**ماژور دوم محرز است.**\n\n"
 "**۳) مینور — زمینه.** اعتیاد تزریقی یک عامل مستعدکننده است. **مینور اول.**\n\n"
 "**۴) مینور — تب.** ذکر شده. **مینور دوم.**\n\n"
 "**پس: دو ماژور و دو مینور.**\n\n"
 "⚠️ **و حالا مهم‌ترین بخش: چه چیزهایی را نباید شمرد؟**\n\n"
 "**ضعف، بی‌اشتهایی و کاهش وزن** هرچقدر هم که به اندوکاردیت بخورند، **در فهرست معیارهای "
 "دوک نیستند**. دانشجویی که این‌ها را هم بشمارد، به «سه ماژور، دو ماینور» یا اعداد دیگری "
 "می‌رسد که هیچ‌کدام درست نیست.\n\n"
 "**نکته‌ی بالینی جانبی:** سمع قلب نرمال در اندوکاردیت تریکوسپید طبیعی است — نارسایی "
 "تریکوسپید سوفل ضعیفی می‌دهد که اغلب شنیده نمی‌شود. **این یافته اندوکاردیت را رد نمی‌کند.**",
 "A pure counting question. The right method is to walk the criteria list in order, not to guess.\n\n"
 "THE PATIENT'S DATA: a young injecting drug user · fever, weakness, anorexia and weight loss "
 "for three months · NORMAL heart sounds · echo: a MOBILE VEGETATION 1 x 1.5 CM ON THE "
 "TRICUSPID VALVE · FOUR BLOOD CULTURES, ALL FOUR POSITIVE for Pseudomonas aeruginosa.\n\n"
 "WARNING, LET US COUNT:\n\n"
 "1) MAJOR — BLOOD CULTURES. The microbiologic major has two routes: a TYPICAL ORGANISM IN TWO "
 "SEPARATE CULTURES, or PERSISTENTLY POSITIVE CULTURES. Pseudomonas is not typical, but FOUR OF "
 "FOUR POSITIVE clearly establishes persistence. THE FIRST MAJOR IS MET.\n\n"
 "2) MAJOR — IMAGING. A mobile vegetation on a valve is evidence of endocardial involvement. "
 "THE SECOND MAJOR IS MET.\n\n"
 "3) MINOR — PREDISPOSITION. Injecting drug use is a predisposing factor. FIRST MINOR.\n\n"
 "4) MINOR — FEVER. Stated. SECOND MINOR.\n\n"
 "SO: TWO MAJOR AND TWO MINOR.\n\n"
 "WARNING, AND NOW THE MOST IMPORTANT PART: WHAT MUST NOT BE COUNTED?\n\n"
 "WEAKNESS, ANOREXIA AND WEIGHT LOSS, however well they fit endocarditis, ARE NOT ON THE DUKE "
 "LIST. A student who counts them arrives at 'three major, two minor' or some other tally, none "
 "of which is right.\n\n"
 "A SIDE CLINICAL NOTE: normal heart sounds are usual in tricuspid endocarditis — tricuspid "
 "regurgitation gives a soft murmur that is often inaudible. THAT FINDING DOES NOT EXCLUDE THE "
 "DIAGNOSIS.",
 ["پاسخ صحیح — کشت پایدار و وژتاسیون دو ماژورند؛ اعتیاد تزریقی و تب دو مینور.",
  "تب یک معیار مینور مستقل است و نباید نادیده گرفته شود؛ مینورها دو تا هستند نه یکی.",
  "کشت مثبت در چهار نوبت یک معیار ماژور است، نه مینور؛ پس یک ماژور و سه مینور غلط است.",
  "سه ماژور وجود ندارد: فقط دو معیار ماژور در کل سیستم دوک تعریف شده است."],
 ["Correct — persistent cultures and a vegetation are two majors; drug use and fever are two minors.",
  "Fever is a separate minor and must not be dropped; there are two minors, not one.",
  "Four positive cultures are a MAJOR criterion, not a minor, so one major and three minors is wrong.",
  "There cannot be three majors: the Duke system defines only two major criteria in total."],
 "**۴ از ۴ کشت = ماژور. وژتاسیون = ماژور. اعتیاد و تب = دو مینور.** ضعف و کاهش وزن معیار نیستند.",
 "Four of four cultures is a major, the vegetation is a major, drug use and fever are two minors; weakness and weight loss are not criteria.",
 [LI2000, H128])


# =========================================================== book:110
add("book:110", "case", "hard",
 "دریچه‌ی مصنوعی + تب + **جین‌وی** ← سه مینور، **بدون هیچ ماژور** (نه کشت، نه اکو).",
 "A prosthetic valve, fever and JANEWAY LESIONS: THREE MINORS AND NO MAJOR AT ALL (no culture, no echo).",
 DUKE_FA + [
  "⚠️ **این سؤال با یک حذف شروع می‌شود: در صورت سؤال نه کشت خونی هست و نه اکویی.**",
  "**پس هر دو معیار ماژور از همان ابتدا منتفی‌اند** — چون هر دو ماژور به این دو وابسته‌اند.",
  "**این را اول تشخیص دهید تا وقت را روی گزینه‌های حاوی «ماژور» تلف نکنید.**",
  "**حالا مینورها را بشمارید:**",
  "**مینور یک — زمینه:** **دریچه‌ی آئورت مصنوعی**. یک عامل مستعدکننده‌ی قطعی.",
  "**مینور دو — تب:** تب ۱۰ روزه ذکر شده.",
  "**مینور سه — پدیده‌ی عروقی:** **ضایعات جین‌وی در کف پا**.",
  "⚠️ **و پتشی ملتحمه هم پدیده‌ی عروقی است — ولی همان معیار سوم را تکرار می‌کند.**",
  "**یک معیار، هرچند بار هم که مصداق داشته باشد، فقط یک امتیاز دارد.**",
  "**این نکته‌ی ظریفی است که دانشجویان زیاد اشتباه می‌کنند: معیارها را می‌شمارند، نه یافته‌ها را.**",
  "**پس جمع: سه مینور و هیچ ماژور.**",
  "⚠️ **و طبق دوک، سه مینور بدون ماژور یعنی «اندوکاردیت محتمل»، نه قطعی.**",
  "**نتیجه‌ی عملی: باید کشت خون و اکو بگیریم تا تشخیص قطعی یا رد شود.**",
 ],
 DUKE_EN + [
  "WARNING: THIS QUESTION BEGINS WITH AN ABSENCE — the stem gives neither blood cultures nor an echo.",
  "SO BOTH MAJOR CRITERIA ARE OFF THE TABLE FROM THE START, since both depend on exactly those two.",
  "Recognise that first, and do not waste time on options containing the word 'major'.",
  "NOW COUNT THE MINORS:",
  "MINOR ONE — PREDISPOSITION: a PROSTHETIC AORTIC VALVE. A definite predisposing factor.",
  "MINOR TWO — FEVER: ten days of fever, stated.",
  "MINOR THREE — A VASCULAR PHENOMENON: JANEWAY LESIONS on the soles.",
  "WARNING, AND CONJUNCTIVAL PETECHIAE ARE ALSO VASCULAR — but they repeat that same third criterion.",
  "A CRITERION SCORES ONCE, however many findings satisfy it.",
  "This is a subtle point students often get wrong: YOU COUNT CRITERIA, NOT FINDINGS.",
  "TOTAL: THREE MINORS AND NO MAJOR.",
  "WARNING, AND BY DUKE, THREE MINORS WITHOUT A MAJOR MEANS 'POSSIBLE' ENDOCARDITIS, NOT DEFINITE.",
  "THE PRACTICAL CONSEQUENCE: blood cultures and echocardiography must be obtained to confirm or reject.",
 ],
 "این سؤال بیش از آنکه حافظه را بسنجد، **انضباط در شمارش** را می‌سنجد.\n\n"
 "**آقای ۶۵ ساله**، تب ۱۰ روزه، **دریچه‌ی آئورت مصنوعی از ده سال پیش**، مختصری تاکی‌کارد، "
 "**پتشی ملتحمه**، **بدون پتشی جلدی**، و **چند ضایعه‌ی مشکوک به جین‌وی در کف پا**.\n\n"
 "⚠️ **گام اول، و مهم‌ترین گام: ببینید چه چیزی در صورت سؤال نیست.**\n\n"
 "**نه کشت خونی گزارش شده و نه اکوکاردیوگرافی‌ای.** هر دو معیار ماژور دوک دقیقاً به همین "
 "دو وابسته‌اند (ماژور میکروبی = کشت؛ ماژور تصویربرداری = اکو). "
 "**پس هیچ ماژوری نمی‌تواند وجود داشته باشد.** این یک حذف قاطع است که سه گزینه را کنار می‌زند.\n\n"
 "**گام دوم، شمارش مینورها:**\n\n"
 "**۱) زمینه** — دریچه‌ی مصنوعی. ✔\n\n"
 "**۲) تب** — ۱۰ روزه. ✔\n\n"
 "**۳) پدیده‌ی عروقی** — ضایعات جین‌وی. ✔\n\n"
 "⚠️ **و حالا دام اصلی سؤال: پتشی ملتحمه.**\n\n"
 "پتشی ملتحمه هم یک **پدیده‌ی عروقی** است. آیا این مینور چهارم است؟ **خیر.** "
 "**در سیستم دوک شما معیارها را می‌شمارید، نه یافته‌ها را.** جین‌وی و پتشی ملتحمه هر دو "
 "زیر یک معیارِ واحد («پدیده‌های عروقی») می‌نشینند و **رویِ هم یک امتیاز** دارند.\n\n"
 "**پس پاسخ: سه مینور.**\n\n"
 "**و معنای بالینی‌اش:** سه مینور بدون ماژور = **اندوکاردیت محتمل**. این بیمار نیاز فوری به "
 "**سه ست کشت خون و اکوکاردیوگرافی (ترجیحاً از راه مری، چون دریچه‌ی مصنوعی دارد)** دارد.",
 "This question tests DISCIPLINE IN COUNTING more than memory.\n\n"
 "A 65-YEAR-OLD MAN, ten days of fever, A PROSTHETIC AORTIC VALVE placed ten years ago, mild "
 "tachycardia, CONJUNCTIVAL PETECHIAE, NO SKIN PETECHIAE, and SEVERAL LESIONS SUSPICIOUS FOR "
 "JANEWAY on the soles.\n\n"
 "WARNING, STEP ONE AND THE MOST IMPORTANT: NOTICE WHAT THE STEM DOES NOT CONTAIN.\n\n"
 "NEITHER BLOOD CULTURES NOR AN ECHOCARDIOGRAM IS REPORTED. Both Duke majors depend on exactly "
 "those two (microbiologic major = culture; imaging major = echo). SO THERE CAN BE NO MAJOR AT "
 "ALL. That single observation eliminates three options.\n\n"
 "STEP TWO, COUNT THE MINORS:\n\n"
 "1) PREDISPOSITION — the prosthetic valve. YES\n\n"
 "2) FEVER — ten days. YES\n\n"
 "3) VASCULAR PHENOMENON — the Janeway lesions. YES\n\n"
 "WARNING, AND NOW THE TRAP: THE CONJUNCTIVAL PETECHIAE.\n\n"
 "Conjunctival petechiae are ALSO a vascular phenomenon. Is that a fourth minor? NO. "
 "IN THE DUKE SYSTEM YOU COUNT CRITERIA, NOT FINDINGS. Janeway lesions and conjunctival "
 "petechiae both sit under the SINGLE criterion 'vascular phenomena' and together score ONCE.\n\n"
 "SO THE ANSWER IS THREE MINORS.\n\n"
 "AND ITS CLINICAL MEANING: three minors with no major is POSSIBLE endocarditis. This patient "
 "urgently needs THREE SETS OF BLOOD CULTURES AND AN ECHOCARDIOGRAM — transoesophageal by "
 "preference, since he has a prosthetic valve.",
 ["پاسخ صحیح — زمینه (دریچه‌ی مصنوعی)، تب و پدیده‌ی عروقی: سه مینور و هیچ ماژور.",
  "هیچ ماژوری وجود ندارد، چون نه کشت خونی گزارش شده و نه اکوکاردیوگرافی‌ای.",
  "چهار مینور نمی‌شود: جین‌وی و پتشی ملتحمه هر دو زیر یک معیار عروقی می‌نشینند و یک امتیاز دارند.",
  "باز هم ماژوری در کار نیست؛ بدون کشت و اکو، معیار ماژور قابل احراز نیست."],
 ["Correct — predisposition (prosthetic valve), fever and a vascular phenomenon: three minors and no major.",
  "There is no major at all, because neither cultures nor an echocardiogram is reported.",
  "It is not four minors: Janeway lesions and conjunctival petechiae fall under one vascular criterion and score once.",
  "Again there is no major; without cultures or echo no major criterion can be established."],
 "**معیارها را بشمارید، نه یافته‌ها را.** بدون کشت و اکو، هیچ ماژوری ممکن نیست.",
 "Count criteria, not findings; with no culture and no echo, no major criterion is possible.",
 [LI2000, H128])


# =========================================================== book:113
add("book:113", "case", "hard",
 "تنها بیماری که **دو معیار** جمع می‌کند: **وژتاسیون در اکو** + زمینه‌ی روماتیسمی + تب ۳۸/۸ + آمبولی ریوی.",
 "The only patient who accumulates enough: A VEGETATION ON ECHO plus rheumatic predisposition, fever 38.8 and pulmonary emboli.",
 DUKE_FA + [
  "⚠️ **این سؤال چهار بیمار را کنار هم می‌گذارد و می‌پرسد کدام‌یک تشخیص می‌گیرد.**",
  "**راه درست: برای هر بیمار جداگانه بشمارید. حدس زدن اینجا جواب نمی‌دهد.**",
  "**بیمار الف — معتاد تزریقی، تب ۳۹، کشت مثبت سودوموناس (یک نوبت)، RBC در ادرار:**",
  "**زمینه (مینور) + تب (مینور) + کشت تک‌نوبتی غیرتیپیک (مینور میکروبی) = سه مینور.**",
  "**بدون ماژور، سه مینور فقط «محتمل» است، نه قطعی.**",
  "⚠️ **بیمار ب — روماتیسم قلبی، تب ۳۸/۸، وژتاسیون در اکو، درگیری دوطرفه‌ی ریه:**",
  "**وژتاسیون = ماژور تصویربرداری.** **روماتیسم قلبی = مینور زمینه.**",
  "**تب ۳۸/۸ = مینور تب** (چون از ۳۸ بالاتر است). **درگیری دوطرفه‌ی ریه = مینور عروقی** (آمبولی سپتیک).",
  "**جمع: یک ماژور و سه مینور ← تشخیص قطعی.** ✔",
  "**بیمار ج — انفارکتوس قبلی، تب ۳۹، کاهش هوشیاری، خونریزی مغزی:**",
  "**تب (مینور) + خونریزی داخل جمجمه (مینور عروقی) = دو مینور. سابقه‌ی انفارکتوس زمینه‌ی دوک نیست.**",
  "**بیمار د — تب ۳۸/۵، کشت مثبت ویریدنس، RF مثبت:**",
  "⚠️ **دقت کنید: تعداد کشت‌ها ذکر نشده.** بدون «دو کشت جدا»، ماژور احراز نمی‌شود.",
  "**تب (مینور) + RF مثبت (مینور ایمنی) + کشت (مینور میکروبی) = سه مینور. باز هم فقط «محتمل».**",
 ],
 DUKE_EN + [
  "WARNING: THIS QUESTION SETS FOUR PATIENTS SIDE BY SIDE AND ASKS WHICH ONE QUALIFIES.",
  "The right method is to COUNT EACH PATIENT SEPARATELY. Guessing does not work here.",
  "PATIENT A — drug user, fever 39, one positive Pseudomonas culture, red cells in urine:",
  "predisposition (minor) + fever (minor) + a single non-typical culture (microbiologic minor) = THREE MINORS.",
  "With no major, three minors is only POSSIBLE, not definite.",
  "WARNING, PATIENT B — rheumatic heart disease, fever 38.8, a vegetation on echo, bilateral lung involvement:",
  "THE VEGETATION IS THE IMAGING MAJOR. Rheumatic heart disease is the predisposition minor.",
  "Fever 38.8 is the fever minor (it clears 38). Bilateral lung involvement is a vascular minor (septic emboli).",
  "TOTAL: ONE MAJOR AND THREE MINORS, WHICH IS DEFINITE ENDOCARDITIS. CORRECT.",
  "PATIENT C — old myocardial infarction, fever 39, reduced consciousness, intracerebral haemorrhage:",
  "fever (minor) + intracranial haemorrhage (vascular minor) = two minors. A past infarct is not a Duke predisposition.",
  "PATIENT D — fever 38.5, positive viridans culture, positive rheumatoid factor:",
  "WARNING, NOTE: THE NUMBER OF CULTURES IS NOT STATED. Without 'two separate cultures' the major is not met.",
  "fever (minor) + positive RF (immunologic minor) + culture (microbiologic minor) = three minors. Again only POSSIBLE.",
 ],
 "این سخت‌ترین سؤال شمارشی فصل است، چون باید **چهار بار** بشمارید.\n\n"
 "⚠️ **پیش از هر چیز، یک تصحیح عددی که این سؤال را نجات داده است:**\n\n"
 "متن استخراج‌شده برای بیمار ب **«۸/۸۳ درجه»** داشت و برای بیمار ج **«۹۳ درجه»**. هیچ‌کدام "
 "دمای انسانی نیستند. صفحه‌ی ۴۴ کتاب در واقع **۳۸/۸** و **۳۹** چاپ کرده است. "
 "**این تصحیح تعیین‌کننده است، چون تب فقط در ۳۸ درجه و بالاتر یک معیار مینور است** — "
 "با «۸/۸۳» بیمار ب یک مینور کم می‌آورد و پاسخ سؤال از بین می‌رفت.\n\n"
 "**حالا بشماریم:**\n\n"
 "**بیمار الف** (معتاد، تب ۳۹، کشت سودوموناس در **یک** نوبت، RBC در ادرار):\n"
 "زمینه ✔ · تب ✔ · کشت تک‌نوبتی با ارگانیسم غیرتیپیک ✔ (مینور میکروبی) → **سه مینور، بدون ماژور** → محتمل، نه قطعی.\n\n"
 "**بیمار ب** (روماتیسم قلبی، تب **۳۸/۸**، **وژتاسیون در اکو**، درگیری دوطرفه‌ی ریه):\n"
 "**وژتاسیون = ماژور** ✔ · زمینه‌ی روماتیسمی ✔ · تب ✔ · آمبولی سپتیک ریوی ✔ → "
 "**یک ماژور + سه مینور = تشخیص قطعی.** ✅\n\n"
 "**بیمار ج** (سابقه‌ی انفارکتوس، تب **۳۹**، کاهش هوشیاری، خونریزی مغزی):\n"
 "تب ✔ · خونریزی داخل جمجمه ✔ (عروقی) → **دو مینور**. "
 "⚠️ **سابقه‌ی انفارکتوس میوکارد یک زمینه‌ی دوک نیست** — زمینه یعنی بیماری *دریچه‌ای*، دریچه‌ی مصنوعی، اعتیاد تزریقی یا اندوکاردیت قبلی.\n\n"
 "**بیمار د** (تب ۳۸/۵، کشت ویریدنس، RF مثبت):\n"
 "⚠️ **دام اینجاست:** ویریدنس یک ارگانیسم **تیپیک** است، پس وسوسه می‌شوید ماژور بدهید. "
 "**ولی ماژور میکروبی به «دو کشت جدا» نیاز دارد و صورت سؤال تعداد کشت را نگفته.** "
 "پس فقط مینور میکروبی می‌گیرد → تب ✔ · RF ✔ · کشت ✔ = **سه مینور** → محتمل.\n\n"
 "**تنها بیمار ب به تشخیص قطعی می‌رسد.**",
 "This is the hardest counting question in the chapter, because you must count FOUR TIMES.\n\n"
 "WARNING, FIRST, A NUMERIC REPAIR THAT SAVED THIS QUESTION:\n\n"
 "The extracted text read '8/83 degrees' for patient B and '93 degrees' for patient C. Neither "
 "is a human temperature. Page 44 of the book actually prints 38.8 and 39. THAT REPAIR IS "
 "DECISIVE, BECAUSE FEVER IS A MINOR CRITERION ONLY AT 38 °C OR ABOVE — with '8/83', patient B "
 "would fall one minor short and the question would have no correct answer.\n\n"
 "NOW LET US COUNT:\n\n"
 "PATIENT A (drug user, fever 39, Pseudomonas in ONE culture, red cells in urine):\n"
 "predisposition YES · fever YES · a single culture with a non-typical organism YES "
 "(microbiologic minor) -> THREE MINORS, NO MAJOR -> possible, not definite.\n\n"
 "PATIENT B (rheumatic heart disease, fever 38.8, A VEGETATION ON ECHO, bilateral lung involvement):\n"
 "THE VEGETATION IS A MAJOR YES · rheumatic predisposition YES · fever YES · septic pulmonary "
 "emboli YES -> ONE MAJOR PLUS THREE MINORS = DEFINITE. CORRECT.\n\n"
 "PATIENT C (past infarct, fever 39, reduced consciousness, cerebral haemorrhage):\n"
 "fever YES · intracranial haemorrhage YES (vascular) -> TWO MINORS. "
 "WARNING: A PAST MYOCARDIAL INFARCTION IS NOT A DUKE PREDISPOSITION — predisposition means "
 "VALVULAR disease, a prosthetic valve, injecting drug use or previous endocarditis.\n\n"
 "PATIENT D (fever 38.5, viridans culture, positive RF):\n"
 "WARNING, HERE IS THE TRAP: viridans IS a typical organism, so you are tempted to award a "
 "major. BUT THE MICROBIOLOGIC MAJOR REQUIRES TWO SEPARATE CULTURES AND THE STEM DOES NOT SAY "
 "HOW MANY WERE TAKEN. So it earns only the microbiologic minor -> fever YES · RF YES · culture "
 "YES = THREE MINORS -> possible.\n\n"
 "ONLY PATIENT B REACHES A DEFINITE DIAGNOSIS.",
 ["سه مینور بدون ماژور (زمینه، تب، کشت تک‌نوبتی) فقط «محتمل» است، نه قطعی.",
  "پاسخ صحیح — وژتاسیون یک ماژور است و با سه مینور (زمینه، تب ۳۸/۸، آمبولی ریوی) تشخیص قطعی می‌شود.",
  "فقط دو مینور دارد؛ سابقه‌ی انفارکتوس میوکارد جزو زمینه‌های دوک نیست.",
  "تعداد کشت‌ها ذکر نشده، پس ماژور میکروبی احراز نمی‌شود و سه مینور فقط «محتمل» است."],
 ["Three minors with no major (predisposition, fever, a single culture) is only possible, not definite.",
  "Correct — the vegetation is a major and with three minors (predisposition, fever 38.8, pulmonary emboli) the diagnosis is definite.",
  "Only two minors; a past myocardial infarction is not a Duke predisposition.",
  "The number of cultures is not stated, so no microbiologic major is established and three minors is only possible."],
 "**تب زیر ۳۸ امتیاز ندارد، و ماژور میکروبی به دو کشت جدا نیاز دارد.** یک ماژور + سه مینور = قطعی.",
 "Fever below 38 scores nothing and the microbiologic major needs two separate cultures; one major plus three minors is definite.",
 [LI2000, H128, ISCVID])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book28.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 28 lessons:', len(L))
