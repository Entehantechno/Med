# -*- coding: utf-8 -*-
"""Numeric repairs for the viral and sexually transmitted infection chapter.

Same glyph-geometry method as the nine earlier chapters: pdfplumber gives the x
coordinate of every character, and a number is always PRINTED left to right
even inside right-to-left Persian text, so sorting a line's digits by x0
recovers the order the page really shows.

WHY ONLY TWO REPAIRS IN A 160-QUESTION CHAPTER
-----------------------------------------------
This is by far the largest chapter in the book and it yielded the fewest
numeric defects of any chapter so far. That is not luck and it is worth
recording, because it says something about where mirrored numbers come from.

The chapters that needed heavy repair — CNS with eighteen, skin with eight,
endocarditis with six — are the chapters full of LABORATORY PANELS: a CSF
glucose beside a protein beside a cell count, or a blood pressure beside a
pulse beside a temperature, all crammed onto one line with their units. That
dense mixed-direction text is exactly what defeats a text extractor.

The viral and STI chapter asks a different kind of question. Most of its stems
are narrative ("a young man one week after unprotected intercourse..."), and
its numbers are mostly ages and CD4 counts standing alone in running text,
where there is no adjacent Latin unit to reverse the run. So the chapter is
large but numerically clean.

THE SCAN THAT FOUND THEM, AND THE FALSE ALARMS IT FIRST PRODUCED
-----------------------------------------------------------------
The first pass located each question's page by matching Persian words and
checked its numbers against that single best-scoring page. It reported SEVEN
suspects. Five were false alarms, and the reason matters:

The page-matching is fuzzy, and for a short stem it can land on a page that
merely shares vocabulary. q9697 has only three long Persian words in its whole
stem ("در مردان جوان HIV مثبت که لنفوسیت‌های CD4..."), so its top-scoring page
was a coincidence, and the "missing" 300 was in fact printed on the correct
page all along. The same happened to q9699, q9615, q9635 and q9548.

The fix was to keep EVERY page tied at the top score rather than an arbitrary
single winner, and to require a minimum match density before trusting the
location at all. That reduced seven suspects to two, and both survive manual
inspection of their pages.

THE TWO REPAIRS
---------------
q9541  page 202  "mg052" -> "250 mg"
       Ceftriaxone 250 mg intramuscularly, the single-dose gonorrhoea regimen
       of the era. The unit is fused onto the front of a mirrored number, the
       same corruption shape seen three times in the endocarditis chapter.
       Note this question ALSO has a corrected answer key from an earlier
       round (fix_keys_uti.py); the two repairs are independent and both
       stand.

q9646  page 241  "mg0001" -> "1000 mg"
       Vitamin B12 1000 mg daily, in a DISTRACTOR option of the measles
       question. The digits are a clean mirror of 1000, which page 241 prints.
       It is repaired even though it sits in a wrong option, because a student
       must be able to read every option to reject it for the right reason:
       the point of that option is that B12 is irrelevant to measles, not that
       its dose is unreadable.

WHAT IS DELIBERATELY NOT TOUCHED
---------------------------------
Ages, CD4 counts and incubation intervals throughout the chapter were checked
against their own pages and are printed as extracted. No repair is invented
where the page agrees with the extraction.
"""
import collections
import io
import json
import os
import re

import pdfplumber

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = '/home/user/uploads/بیماری عفونی.pdf'

# question_no -> [(page, old, new, expected_printed_run, kind, why_fa), ...]
FIXES = {
    9541: [
        (202, 'سفتریاکسون، mg052', 'سفتریاکسون 250 mg', '250', 'reorder',
         'دوز سفتریاکسون: صفحه ۲۰۲ عدد **۲۵۰** را چاپ کرده است؛ در استخراج، واحد به '
         'ابتدای عدد چسبیده و رقم‌ها معکوس شده و «mg052» ساخته بود. این عدد مهم است '
         'چون **سفتریاکسون ۲۵۰ میلی‌گرم عضلانی تک‌دوز** همان رژیم استاندارد درمان '
         'گنوکوک در زمان طرح سؤال است، و دانشجو باید ببیند که **درمان گنوکوک درست '
         'انجام شده** تا بفهمد علامت باقی‌مانده از **کلامیدیای هم‌زمان** است، نه از '
         'شکست درمان یا دوز ناکافی.'),
    ],
    9646: [
        (241, 'mg0001', '1000 mg', '1000', 'reorder',
         'دوز ویتامین ب۱۲: صفحه ۲۴۱ عدد **۱۰۰۰** را چاپ کرده و رقم‌ها در استخراج '
         'معکوس شده بودند. این عدد در **گزینه‌ی نادرست** است، ولی باز هم تصحیح '
         'می‌شود: دانشجو باید بتواند هر گزینه را بخواند تا آن را **به دلیل درست** رد '
         'کند. ایراد این گزینه آن است که **ویتامین ب۱۲ هیچ نقشی در سرخک ندارد** — '
         'نه اینکه دوزش ناخوانا باشد.'),
    ],
}

FOLD = {}
for _i in range(10):
    FOLD[chr(0x0660 + _i)] = str(_i)   # Arabic-Indic
    FOLD[chr(0x06F0 + _i)] = str(_i)   # Persian


def page_digit_runs(pdf, pno):
    """Digit runs of a page in PRINTED (x-ascending) order."""
    page = pdf.pages[pno - 1]
    rows = collections.defaultdict(list)
    for c in page.chars:
        rows[round(c['top'])].append(c)
    runs = []
    for top in sorted(rows):
        cs = sorted(rows[top], key=lambda c: c['x0'])
        cur = ''
        for c in cs:
            t = FOLD.get(c['text'], c['text'])
            # a space must NOT close an open run: kerning sometimes splits a
            # number, and closing on the space invents two numbers out of one
            if t.isspace() and cur:
                continue
            if t.isdigit():
                cur += t
            else:
                if cur:
                    runs.append(cur)
                cur = ''
        if cur:
            runs.append(cur)
    return runs


def main():
    pages = {p for specs in FIXES.values() for (p, *_r) in specs}
    with pdfplumber.open(SRC) as pdf:
        printed = {p: page_digit_runs(pdf, p) for p in pages}

    applied, missing = [], []
    for i in range(1, 6):
        path = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        if not os.path.exists(path):
            continue
        body = json.load(io.open(path, encoding='utf-8'))
        dirty = False
        for q in body['questions']:
            specs = FIXES.get(q['question_no'])
            if not specs:
                continue
            for pno, old, new, expect, kind, why in specs:
                assert expect in printed[pno], \
                    f'q{q["question_no"]}: page {pno} does not print {expect}'
                old_d = [c for c in old if c.isdigit()]
                new_d = [c for c in new if c.isdigit()]
                if kind == 'reorder':
                    assert sorted(old_d) == sorted(new_d), \
                        f'q{q["question_no"]}: {old} -> {new} is not a reordering'
                else:
                    assert kind == 'restore', f'unknown kind {kind!r}'
                    have = collections.Counter(new_d)
                    for ch, n in collections.Counter(old_d).items():
                        assert have[ch] >= n, \
                            f'q{q["question_no"]}: {old} -> {new} loses a printed digit'
                    for run in re.findall(r'\d+', new):
                        assert run in printed[pno], \
                            f'q{q["question_no"]}: page {pno} does not print restored {run}'
                    assert any(w in why for w in ('افتاده', 'باقی مانده', 'حذف')), \
                        f'q{q["question_no"]}: a restore must say a digit was dropped'

                hit = False
                if old in q['question_fa']:
                    q.setdefault('stem_original_fa', q['question_fa'])
                    q['question_fa'] = q['question_fa'].replace(old, new)
                    q.setdefault('stem_number_corrections', []).append({
                        'from': old, 'to': new, 'page': pno, 'where': 'stem',
                        'method': 'glyph geometry (pdfplumber x-order)',
                        'kind': kind, 'why_fa': why})
                    applied.append(f'q{q["question_no"]}: {old} -> {new} (stem)')
                    hit = True
                    dirty = True
                for oi, opt in enumerate(q['options_fa']):
                    if old in opt:
                        q.setdefault('options_original_fa', list(q['options_fa']))
                        q['options_fa'][oi] = opt.replace(old, new)
                        q.setdefault('stem_number_corrections', []).append({
                            'from': old, 'to': new, 'page': pno,
                            'where': f'option {oi + 1}',
                            'method': 'glyph geometry (pdfplumber x-order)',
                            'kind': kind, 'why_fa': why})
                        applied.append(
                            f'q{q["question_no"]}: {old} -> {new} (option {oi + 1})')
                        hit = True
                        dirty = True
                if not hit:
                    # Already applied on an earlier run is NOT a failure. Learned
                    # in the endocarditis chapter, where a mistyped `old` string
                    # let five fixes write and then aborted, after which a rerun
                    # reported the five ALREADY-CORRECT questions as failures.
                    done = (new in q['question_fa']
                            or any(new in o for o in q['options_fa']))
                    if done:
                        applied.append(
                            f'q{q["question_no"]}: {old} -> {new} (already applied)')
                    else:
                        missing.append(f'q{q["question_no"]}: {old!r} not found')
        if dirty:
            json.dump(body, io.open(path, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)

    for a in applied:
        print('  fixed  ', a)
    for m in missing:
        print('  MISSING', m)
    print(f'applied {len(applied)}, missing {len(missing)}')
    assert not missing, 'some fixes did not match the stored text'


if __name__ == '__main__':
    main()
