# -*- coding: utf-8 -*-
"""English stems and options for the batch-17 and batch-18 questions.

Rule 16 checked first, as always: these are sittings 93-98, for which the
ministry published no English booklet, so these are hand-written translations.

Two translation decisions worth recording:

  q9266 (idx 266): the tuberculin reading was stored as 71 mm and has been
  repaired to 17 mm from glyph geometry (page 103 prints the digits 1 then 7).
  The English quotes the CORRECTED value. This matters more here than in most
  chapters: a PPD is the number the whole question turns on, and 71 mm is not a
  measurement a human arm can produce.

  q9244 (idx 244): the source writes the laboratory panel with its normal
  ranges inline — "AST 280 (NL 8-40)". Those parenthetical ranges are part of
  the printed question and are kept in the English, because the student is
  expected to compute the multiple of normal from them. Dropping them would
  quietly make the question harder than the paper intended.
"""

EN8 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    assert all(o.strip() for o in options), idx
    EN8[idx] = {"stem_en": stem, "options_en": options}


# ------------------------------------------------------------- diagnosis
add(209,
    "Which of the following is the commonest clinical presentation of extrapulmonary "
    "tuberculosis?",
    ["Spondylitis", "Peritonitis", "Lymphadenitis", "Meningitis"])

add(217,
    "A 67-year-old homeless man presents to the emergency department with fever and productive "
    "cough. He reports taking azithromycin and co-amoxiclav without clinical improvement. On "
    "examination he is cachectic. He is alert and oriented, and his vital signs are blood "
    "pressure 120/80, pulse 80 per minute, respiratory rate 32 per minute and temperature 37.8. "
    "His arterial oxygen saturation on room air is 88%. The chest radiograph shows cavitary "
    "infiltration in the upper lobes. What is the first appropriate diagnostic step for this "
    "patient?",
    ["Chest CT scan", "Spirometry", "Bronchoscopy and lung biopsy",
     "Sputum smear for acid-fast bacilli"])

add(224,
    "A 40-year-old man presents with fever, cough, sputum production and weight loss for the past "
    "15 days. He spent 6 months in prison 3 years ago. The chest radiograph shows opacity in the "
    "middle and upper zones of the right lung. Three sputum smears for acid-fast bacilli have "
    "been reported negative. According to the national guidance, which course of action do you "
    "consider appropriate?",
    ["Treat as community-acquired pneumonia and repeat the radiograph",
     "Empirical treatment for tuberculosis and repeat the sputum smear",
     "A course of treatment as community-acquired pneumonia, then repeat the sputum smear",
     "Chest CT scan and a tuberculin test"])

# --------------------------------------------------------------- regimens
add(227,
    "A 50-year-old man attends the clinic with fever, cough, sputum and weight loss. Sputum smear "
    "for acid-fast bacilli has been reported positive on two occasions. He gives a history of a "
    "course of treatment for tuberculous pleurisy three years ago. Which of the following "
    "regimens is appropriate for him?",
    ["Two months HRZE, four months HR", "Three months HRZE and five months HRE",
     "Two months HRZE, seven months HR", "Three months HRZES, six months HRE"])

add(231,
    "A young injecting drug user with a positive tuberculosis smear is about to start "
    "anti-tuberculous treatment. His companion reports that TB treatment had been started for him "
    "on another occasion about two months ago, and that he stopped it on his own after about two "
    "weeks. Select the correct statement about how he should be treated.",
    ["Standard four-drug treatment should continue, counting the previous treatment",
     "The patient should be treated as a new case",
     "The patient should be treated as treatment after interruption",
     "The patient should receive five-drug anti-TB treatment for 8 months"])

# ---------------------------------------------------------- drug toxicity
add(235,
    "A patient with pulmonary tuberculosis has been started on the four-drug anti-tuberculous "
    "regimen. Three weeks after starting treatment he develops sudden pain, swelling and redness "
    "of the great toe of the left foot. His uric acid is reported above the normal range. Which "
    "drug most likely caused this adverse effect?",
    ["Isoniazid", "Pyrazinamide", "Ethambutol", "Rifampicin"])

add(252,
    "A 45-year-old injecting drug user presents with cough, haemoptysis, weight loss and night "
    "sweats. Investigations suggest pulmonary tuberculosis and he is started on standard "
    "anti-tuberculous treatment. After one week he develops a generalised petechial skin rash and "
    "investigations show thrombocytopenia. This adverse effect followed the use of which "
    "anti-tuberculous drug?",
    ["Rifampicin", "Ethambutol", "Isoniazid", "Pyrazinamide"])

add(240,
    "A 58-year-old man with pulmonary tuberculosis and normal baseline liver tests was started on "
    "the four first-line drugs. One month later his liver tests are as follows: SGOT 60, SGPT 62. "
    "He currently has no complaints and his physical examination is normal. Which course of "
    "action is most appropriate?",
    ["Stop the rifampicin", "Stop the rifampicin and isoniazid",
     "No specific action is needed", "Add a corticosteroid"])

add(244,
    "A 50-year-old man with pulmonary tuberculosis, on anti-tuberculous drugs for the past three "
    "weeks, presents with jaundice and nausea. His results are as follows: direct bilirubin 1, "
    "total bilirubin 3, AST 280 (NL 8-40), ALT 250 (NL 5-40), O2 saturation 92%, BP 125/80, "
    "PR 90/min, RR 20/min. What is the best course of action?",
    ["Stop isoniazid and rifampicin until the tests improve",
     "Stop isoniazid, rifampicin and pyrazinamide for two weeks",
     "Stop all anti-tuberculous drugs and restart them once the tests normalise",
     "Stop pyrazinamide until the tests normalise"])

# ------------------------------------------------------------- latent TB
add(261,
    "In which of the following is chemoprophylaxis with isoniazid NOT required?",
    ["A patient treated with TNF inhibitors with a PPD of 10 mm",
     "A diabetic patient with a PPD of 7 mm",
     "A person with HIV infection with a PPD of 5 mm",
     "A patient on haemodialysis with a PPD of 12 mm"])

add(266,
    "A 24-year-old man is assessed for employment at a bank. His tuberculin test is reported as "
    "17 mm, his ESR is 12 mm and his CRP is negative, and there is no evidence of active "
    "tuberculosis. What is the appropriate course of action for him?",
    ["No drug treatment is needed; we follow the patient up",
     "Because the test is positive, prophylaxis with INH for six months",
     "Because the test is positive, four-drug anti-tuberculous treatment",
     "Give INH for 3 months and then repeat the test"])

add(273,
    "A 40-year-old man diagnosed with smear-positive pulmonary tuberculosis is started on "
    "treatment. What is the appropriate course of action for his 5-year-old child?",
    ["No specific action is needed",
     "Perform a PPD and, if negative, take no action",
     "If the PPD becomes positive, isoniazid is given as prophylaxis",
     "Isoniazid prophylaxis is started from the outset, regardless of the PPD result"])
