# -*- coding: utf-8 -*-
"""Repair the damaged numbers of the respiratory chapter (pneumonia, influenza).

Method — unchanged from the five previous chapters
--------------------------------------------------
pdfplumber gives the x-coordinate of every glyph, and a number is drawn left to
right even inside right-to-left script. So sorting a line's glyphs by x0 and
reading off the digit runs recovers exactly the values the typesetter placed on
the page. The extracted text keeps the LOGICAL order, and that is where a
two-digit value gets mirrored.

Two kinds of repair, as established in the zoonoses chapter
-----------------------------------------------------------
  kind='reorder'  the digits the page printed, put back in printed order
  kind='restore'  a digit the extraction DROPPED, put back; a stronger claim,
                  so main() holds it to a stronger assertion

Four of the five repairs here are REORDER: mirrored ages. The fifth, q9575, is
a RESTORE and is instructive about how these defects actually arise. The page
prints "BMI>40 kg/m2"; the extractor kept the superscript 2 of the unit and the
leading 4 of the value, dropped the 0 between them, and handed back "24 kg/m".
So a squared-metre sign and half a number collided into a plausible-looking
threshold. That is why the restore assertion demands that EVERY number of the
repaired text be a run the page actually printed: here both 40 and 2 are.

Why these particular numbers change the answer
----------------------------------------------
This chapter is unusual: almost every damaged number is an AGE or a BMI, and in
the influenza-vaccination block an age IS the answer. The questions ask which
person does or does not need vaccination or oseltamivir, and the whole of that
decision rests on the risk-group boundaries:

    age >= 65            high risk
    age <  5 (esp <2)    high risk
    age <  6 months      TOO YOUNG for the vaccine — the vaccine is not given
    pregnancy, any trimester            high risk
    BMI >= 40 (morbid obesity)          high risk
    chronic heart, lung, kidney, liver, metabolic disease, immunosuppression

So a mirrored age silently moves a patient across a boundary and inverts the
key. Three of the five repairs below do exactly that:

  q9587  "آقای 57 ساله با COPD" — page 219 prints 75. Either age is over the
         COPD threshold so the key is unchanged, but the stem should say what
         the paper says.
  q9587  "آقای 53 ساله با BMI>40" — page 219 prints 35. Again the BMI, not the
         age, is what makes this option an indication.
  q9588  "کودکان 6 ماهه تا 81 ساله" — page 220 prints 18. An 81-year-old is not
         a child; the option is the standard "6 months to 18 years" band.
  q9595  "آقای 54 ساله دیابتی" — page 222 prints 45.
  q9575  "بیماران چاق با BMI>24" — page 215 prints 40. THIS ONE MATTERS MOST:
         a BMI over 24 is merely overweight and is NOT a risk group, whereas
         BMI >= 40 is morbid obesity and IS one. Left uncorrected, the option
         is medically false and the question becomes unanswerable, because two
         options would then both be "lower risk".

The one defect that glyph ORDER could not have found: q9088
------------------------------------------------------------
Every repair before this chapter was found by reading digits in x-order within
a line. q9088 needed a second geometric idea, because its defect is not a
mirrored number at all.

Page 34 prints the laboratory results as a TWO-COLUMN TABLE spread over four
physical lines. Read as running text, the extractor produced:

    Na = 75   ALT = 4500   WBC = 1/6   Cr = 128   PLT = 4/8   K = 40 ...

which is nonsense in a specific and dangerous way: it makes the sodium 75 and
the platelet count 128. Clustering the glyphs of each line by the HORIZONTAL
GAPS BETWEEN THEM (rather than only sorting them) recovers the real cells:

    WBC = 4500     ALT = 75      Na = 128
    Cr = 1/6
    Hb = 14        AST = 40      K = 4/8       PLT = 245000

So the sodium is 128, the platelet count is 245000 — and the platelet count had
vanished from the extraction entirely.

Why this is the most consequential repair in the chapter: a 65-year-old with
pneumonia, DIARRHOEA, CONFUSION, spreading infiltrates and a SODIUM OF 128 is
the textbook picture of LEGIONELLA, and hyponatraemia is its classical clue.
The printed key (azithromycin) is right precisely because of that sodium. With
the sodium mangled to 75 and the platelets to 128, the very finding that
justifies the answer had been destroyed, and the stem instead reported two
values incompatible with life.


A note on q9575's key, which was examined and left alone
--------------------------------------------------------
The printed key is (A) "influenza C". That is right, and worth teaching rather
than merely accepting: influenza A and B cause epidemic disease and the deaths;
INFLUENZA C causes a mild, cold-like illness in children and is not associated
with epidemics or with severe outcomes. Once the BMI is repaired to 40, the
other three options are all genuine high-risk groups and the question has
exactly one answer. Before the repair it had two — which is a good reminder
that a numeric defect can quietly turn a sound question into a broken one.
"""
import json, io, os, re, collections

import pdfplumber

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = '/home/user/uploads/بیماری عفونی.pdf'

# question_no -> [(page, old, new, expected_printed_run, kind, why_fa), ...]
FIXES = {
    9575: [
        (215, '24 kg/m ->BMI', 'BMI>40 kg/m2', '40', 'restore',
         'شاخص تودهی بدنی: صفحه ۲۱۵ رقم‌ها را ۴۰ چاپ کرده است و رقم صفر در '
         'استخراج افتاده بود (آنچه مانده بود، «۲» توانِ مترمربع و «۴» ابتدای ۴۰ '
         'بود که کنار هم «۲۴» ساخته بودند). این تصحیح از همه '
         'مهم‌تر است، چون BMI بالای ۲۴ فقط «اضافه‌وزن» است و اصلاً گروه پرخطر '
         'محسوب نمی‌شود، در حالی که BMI بالای ۴۰ یعنی چاقی مرضی و یک گروه پرخطر '
         'شناخته‌شده است. با عدد غلط، این گزینه هم «کم‌خطر» می‌شد و سؤال دو پاسخ '
         'پیدا می‌کرد.'),
    ],
    9587: [
        (219, 'آقای 57 ساله', 'آقای 75 ساله', '75', 'reorder',
         'سن: صفحه ۲۱۹ رقم‌ها را ۷۵ چاپ کرده است.'),
        (219, 'آقای 53 ساله', 'آقای 35 ساله', '35', 'reorder',
         'سن: صفحه ۲۱۹ رقم‌ها را ۳۵ چاپ کرده است؛ آنچه این گزینه را اندیکاسیون '
         'می‌کند BMI بالای ۴۰ است، نه سن.'),
    ],
    9588: [
        (220, 'کودکان 6 ماهه تا 81 ساله', 'کودکان 6 ماهه تا 18 ساله', '18', 'reorder',
         'محدوده‌ی سنی: صفحه ۲۲۰ رقم‌ها را ۱۸ چاپ کرده است؛ «کودک ۸۱ ساله» وجود '
         'ندارد و محدوده‌ی استاندارد واکسن آنفلوانزا «۶ ماه تا ۱۸ سال» است.'),
    ],
    # q9088 is not a mirrored number but a SCRAMBLED TABLE, and it needed the
    # cluster geometry (x-gaps within a line) rather than digit order alone.
    # See the long note in the module docstring.
    9088: [
        (34, '= Na 75 = ALT 4500 = WBC 1/6=Cr 128 = PLT 4/8=K 40 = AST 14 = Hb',
         'WBC=4500، ALT=75، Na=128، Cr=1.6، Hb=14، AST=40، K=4.8، PLT=245000',
         '245000', 'restore',
         'پنل آزمایشگاهی: صفحه ۳۴ این اعداد را در یک جدول دوستونی چاپ کرده و '
         'استخراج، برچسب‌ها را جابه‌جا کرده بود. با بررسی مختصات افقی نویسه‌ها '
         'روشن شد که صفحه در واقع «Na = 128» و «PLT = 245000» دارد؛ یعنی عدد ۱۲۸ '
         'سدیم بوده نه پلاکت، و شمارش پلاکت (۲۴۵۰۰۰) در استخراج کلاً افتاده بود. '
         'این تصحیح تعیین‌کننده است، چون **هیپوناترمی** سرنخ کلاسیک لژیونلا و '
         'همان دلیلِ درست بودن کلید (آزیترومایسین) است.'),
    ],
    9595: [
        (222, 'آقای 54 ساله', 'آقای 45 ساله', '45', 'reorder',
         'سن: صفحه ۲۲۲ رقم‌ها را ۴۵ چاپ کرده است.'),
    ],
}

FOLD = {}
for _i in range(10):
    FOLD[chr(0x0660 + _i)] = str(_i)   # Arabic-Indic
    FOLD[chr(0x06F0 + _i)] = str(_i)   # Persian


def page_digit_runs(pdf, pno):
    """Digit runs of a page in PRINTED (x-ascending) order."""
    page = pdf.pages[pno - 1]
    rows = collections.defaultdict(list)
    for c in page.chars:
        rows[round(c['top'])].append(c)
    runs = []
    for top in sorted(rows):
        cs = sorted(rows[top], key=lambda c: c['x0'])
        cur = ''
        for c in cs:
            t = FOLD.get(c['text'], c['text'])
            # a space must NOT close an open run: kerning sometimes splits a
            # number, and closing on the space invents two numbers out of one
            if t.isspace() and cur:
                continue
            if t.isdigit():
                cur += t
            else:
                if cur:
                    runs.append(cur)
                cur = ''
        if cur:
            runs.append(cur)
    return runs


def main():
    pages = {p for specs in FIXES.values() for (p, *_r) in specs}
    with pdfplumber.open(SRC) as pdf:
        printed = {p: page_digit_runs(pdf, p) for p in pages}

    applied, missing = [], []
    for i in range(1, 6):
        path = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        body = json.load(io.open(path, encoding='utf-8'))
        dirty = False
        for q in body['questions']:
            specs = FIXES.get(q['question_no'])
            if not specs:
                continue
            for pno, old, new, expect, kind, why in specs:
                assert expect in printed[pno], \
                    f'q{q["question_no"]}: page {pno} does not print {expect}'
                # A REORDER only rearranges the digits the page printed. A
                # RESTORE puts back a digit the extraction dropped, which is a
                # stronger claim, so it is held to a stronger test.
                old_d = [c for c in old if c.isdigit()]
                new_d = [c for c in new if c.isdigit()]
                if kind == 'reorder':
                    assert sorted(old_d) == sorted(new_d), \
                        f'q{q["question_no"]}: {old} -> {new} is not a reordering'
                else:
                    assert kind == 'restore', f'unknown kind {kind!r}'
                    have = collections.Counter(new_d)
                    for ch, n in collections.Counter(old_d).items():
                        assert have[ch] >= n, \
                            f'q{q["question_no"]}: {old} -> {new} loses a printed digit'
                    for run in re.findall(r'\d+', new):
                        assert run in printed[pno], \
                            f'q{q["question_no"]}: page {pno} does not print restored {run}'

                hit = False
                if old in q['question_fa']:
                    q.setdefault('stem_original_fa', q['question_fa'])
                    q['question_fa'] = q['question_fa'].replace(old, new)
                    q.setdefault('stem_number_corrections', []).append({
                        'from': old, 'to': new, 'page': pno, 'where': 'stem',
                        'method': 'glyph geometry (pdfplumber x-order)',
                        'kind': kind, 'why_fa': why})
                    applied.append(f'q{q["question_no"]}: {old} -> {new} (stem)')
                    hit = True
                    dirty = True
                for oi, opt in enumerate(q['options_fa']):
                    if old in opt:
                        q.setdefault('options_original_fa', list(q['options_fa']))
                        q['options_fa'][oi] = opt.replace(old, new)
                        q.setdefault('stem_number_corrections', []).append({
                            'from': old, 'to': new, 'page': pno,
                            'where': f'option {oi + 1}',
                            'method': 'glyph geometry (pdfplumber x-order)',
                            'kind': kind, 'why_fa': why})
                        applied.append(
                            f'q{q["question_no"]}: {old} -> {new} (option {oi + 1})')
                        hit = True
                        dirty = True
                if not hit:
                    missing.append(f'q{q["question_no"]}: {old!r} not found')
        if dirty:
            json.dump(body, io.open(path, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)

    for a in applied:
        print('fixed  ', a)
    for m in missing:
        print('MISSING', m)
    print(f'\n{len(applied)} corrections written, {len(missing)} not found')


if __name__ == '__main__':
    main()
