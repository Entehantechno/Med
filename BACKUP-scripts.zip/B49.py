# -*- coding: utf-8 -*-
"""Micro-lessons, batch 49 — cholera, salmonella and enteric fever.

THIRTY-ONE QUESTIONS, AND WITH THEM THE GASTROINTESTINAL CHAPTER IS COMPLETE
(84 of 84). This is the third chapter of the book to be finished.

PART ONE — CHOLERA. RECOGNISE IT, THEN REPLACE THE FLUID.
The picture is unmistakable once its four features are learned together:

    RICE-WATER STOOL          colourless-grey, flecked with mucus, no blood
    ENORMOUS VOLUME           litres per hour in severe cases
    NO FEVER, NO ABDOMINAL PAIN, and a stool with NO white or red cells
    MUSCLE CRAMPS             from potassium and calcium loss, not from the
                              infection

The stem's "fishy odour" and "grey colour" both describe the same rice-water
stool. And the absence of fever is diagnostic: cholera is a PURE TOXIN
DISEASE. Cholera toxin locks adenylate cyclase on, cyclic AMP rises, and the
crypt cells pour out chloride with water following. NOTHING IS INVADED — hence
no fever, no pain, no stool leucocytes.

  FLUID IS THE TREATMENT, AND RINGER'S LACTATE IS THE FLUID.
  Untreated severe cholera kills up to half of those affected; with adequate
  rehydration alone, mortality falls below 1 %. Ringer's lactate is chosen
  because it alone among the common fluids replaces what cholera stool
  actually loses: sodium, chloride, potassium and — through the lactate,
  metabolised to bicarbonate — the BASE lost in the stool. Normal saline gives
  no base and no potassium; dextrose water gives neither electrolyte nor base
  and merely dilutes; one-third/two-thirds is a maintenance fluid, not a
  resuscitation fluid.

  ANTIBIOTICS ARE ADJUNCTIVE, NOT PRIMARY. They shorten the illness by about a
  day, cut stool volume by roughly half, and shorten shedding. The WHO/GTFCC
  first choice today is DOXYCYCLINE 300 mg as a single dose for all patients
  INCLUDING PREGNANT WOMEN, with AZITHROMYCIN 1 g single dose and
  ciprofloxacin as alternatives. Note that this has moved: the older teaching,
  which this book follows, avoided doxycycline in pregnancy and keyed
  azithromycin or erythromycin. The lessons state both.

  DEHYDRATION GRADING, WHICH IS ASKED DIRECTLY:
    under 5 %      thirst only, mild
    5 to 10 %      thirst, postural hypotension, weakness, tachycardia,
                   reduced skin turgor, dry mucosae, absent tears — MODERATE
    over 10 %      the above plus shock, lethargy or coma — SEVERE

  AND THE TRANSPORT MEDIUM, asked once: CARY-BLAIR. TCBS is a SELECTIVE
  CULTURE medium, not a transport medium; the distinction is the whole
  question.

PART TWO — SALMONELLA, AND THE DIVISION THAT DECIDES TREATMENT.

    NON-TYPHOIDAL SALMONELLA (gastroenteritis, from eggs and poultry)
        USUALLY NEEDS NO ANTIBIOTIC in a healthy host. Treatment does not
        shorten the illness and PROLONGS THE CARRIER STATE. Treat only the
        extremes of age, the immunosuppressed, those with prostheses or
        sickle-cell disease, and anyone with bacteraemia or severe disease.

    TYPHOID (enteric fever, from Salmonella typhi)
        ALWAYS treated, and the reservoir is MAN ALONE.

  THE TYPHOID PICTURE, asked five times:
        a week or more of fever that climbs in a stepwise fashion
        RELATIVE BRADYCARDIA (Faget's sign) — a pulse of 80 with a fever of 40
        headache, abdominal pain, and CONSTIPATION more often than diarrhoea
        ROSE SPOTS — sparse blanching macules on the trunk
        hepatosplenomegaly, a coated tongue, and LEUCOPENIA

  Leucopenia with fever is the finding that turns the diagnosis, because most
  bacterial sepsis raises the white count.

  DIAGNOSIS BY WEEK, which is asked twice and is worth learning as a timeline:
        week 1        BLOOD CULTURE, positive in 60 to 80 %
        week 2-3      blood culture yield falls; STOOL and urine rise
        any week      BONE MARROW CULTURE is the MOST SENSITIVE, over 90 %,
                      and remains positive DESPITE PRIOR ANTIBIOTICS
  That last property is what makes marrow the answer in a partially treated
  patient.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022) —
cholera and other vibrioses, and salmonellosis; WHO Global Task Force on
Cholera Control (GTFCC), Technical Note on the use of antibiotics for the
treatment of cholera.
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


HC = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — "
      "cholera and other vibrioses")
HS = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — "
      "salmonellosis, including typhoid (enteric) fever")
GTFCC = ("World Health Organization Global Task Force on Cholera Control "
         "(GTFCC) — Technical Note on the use of antibiotics for the treatment "
         "of cholera")
CREFS = [HC, GTFCC]
SREFS = [HS]

# ==================================================== CHOLERA: SHARED
CH_FA = [
    "⚠️ **وبا را با چهار ویژگی که با هم می‌آیند بشناسید.**",
    "**یک: مدفوع آب برنجی — بی‌رنگ تا خاکستری، با پرز مخاط، و بدون خون.**",
    "**دو: حجم عظیم — در موارد شدید، لیترها در ساعت.**",
    "**سه: بدون تب، بدون درد شکم، و مدفوع بدون گلبول سفید و قرمز.**",
    "**چهار: کرامپ عضلانی، که از دست دادن پتاسیم و کلسیم است، نه از عفونت.**",
    "⚠️ **و نبود تب، خودش تشخیصی است — چون وبا یک بیماری کاملاً سم‌محور است.**",
    "**سم وبا آنزیم آدنیلات سیکلاز را در حالت روشن قفل می‌کند.**",
    "**سطح cAMP بالا می‌رود و سلول‌های کریپت کلراید را بیرون می‌ریزند.**",
    "**و آب به‌دنبال کلراید می‌رود، پس اسهال آبکی عظیم می‌شود.**",
    "**هیچ تهاجمی رخ نمی‌دهد — پس نه تب، نه درد، نه گلبول سفید در مدفوع.**",
    "⚠️ **و درمان: مایع، مایع، و باز هم مایع.**",
    "**وبای شدید درمان‌نشده تا نیمی از مبتلایان را می‌کشد.**",
    "**و با مایع‌درمانی کافی، مرگ‌ومیر به زیر یک درصد می‌رسد.**",
    "**پس آنتی‌بیوتیک کمکی است، نه اصلی.**",
    "**آنتی‌بیوتیک مدت بیماری را حدود یک روز و حجم مدفوع را حدود نصف کم می‌کند.**",
]
CH_EN = [
    "WARNING: RECOGNISE CHOLERA BY FOUR FEATURES THAT COME TOGETHER.",
    "ONE: RICE-WATER STOOL — colourless to grey, flecked with mucus, and without blood.",
    "TWO: ENORMOUS VOLUME — litres per hour in severe cases.",
    "THREE: NO FEVER, NO ABDOMINAL PAIN, and a stool with no white or red cells.",
    "FOUR: MUSCLE CRAMPS, from loss of potassium and calcium, not from the infection.",
    "WARNING, AND THE ABSENCE OF FEVER IS ITSELF DIAGNOSTIC — because cholera is a PURE TOXIN disease.",
    "Cholera toxin locks the enzyme adenylate cyclase in the ON position.",
    "Cyclic AMP rises and the crypt cells pour out chloride.",
    "And water follows the chloride, producing enormous watery diarrhoea.",
    "NOTHING IS INVADED — hence no fever, no pain, and no stool leucocytes.",
    "WARNING, AND THE TREATMENT: FLUID, FLUID AND MORE FLUID.",
    "Untreated severe cholera kills up to half of those affected.",
    "And with adequate rehydration, mortality falls below one per cent.",
    "So antibiotics are ADJUNCTIVE, not primary.",
    "An antibiotic shortens the illness by about a day and halves the stool volume.",
]

add("book:333", "vignette", "easy",
    "**اسهال آبکی حجیم بدون گلبول سفید در یک طغیان: ویبریوکلرا.**",
    "Large-volume watery diarrhoea with no stool leucocytes during an outbreak: VIBRIO CHOLERAE.",
    CH_FA,
    CH_EN,
    "این سؤال ورودی بلوک وباست و **سه سرنخ** دارد که با هم تشخیص را قطعی می‌کنند.\n\n"
    "**بیمار: مرد ۲۲ ساله با اسهال آبکی با حجم زیاد به دفعات مکرر از صبح امروز. دمای ۳۷٫۳، "
    "فشار ۸۰ با نبض قابل لمس، ضربان ۱۱۲. در نمونه‌ی مستقیم مدفوع گلبول سفید گزارش نشده. و "
    "در چند روز اخیر موارد مشابه به اورژانس مراجعه کرده‌اند.**\n\n"
    "**سرنخ یک — حجم زیاد و آبکی.** این **الگوی روده‌ی باریک** است. کولون حجم کم می‌دهد؛ "
    "**حجم عظیم یعنی روده‌ی باریک، یعنی سازوکار ترشحی**.\n\n"
    "⚠️ **سرنخ دو — گلبول سفید در مدفوع گزارش نشده.** این **معیار قطعی غیرالتهابی بودن** "
    "است. هیچ تهاجمی رخ نداده. و **دمای ۳۷٫۳ یعنی عملاً بدون تب**.\n\n"
    "**سرنخ سه — موارد مشابه در چند روز اخیر.** یعنی **طغیان**. و وبا کلاسیک‌ترین علت طغیان "
    "اسهال آبکی حجیم است.\n\n"
    "**و شدت: فشار ۸۰ با نبض قابل لمس و ضربان ۱۱۲** — یعنی **دهیدراتاسیون شدید و شوک "
    "هیپوولمیک**، که با وبا کاملاً هم‌خوان است (وبا می‌تواند **لیترها در ساعت** مایع از دست بدهد).\n\n"
    "**سازوکار را بفهمید، چون همه‌ی سؤال‌های بعدی به آن وابسته‌اند:**\n\n"
    "**سم وبا** به سلول‌های اپیتلیال روده‌ی باریک می‌چسبد و **آدنیلات سیکلاز را در حالت روشن "
    "قفل می‌کند**. **cAMP** بالا می‌رود، و سلول‌های **کریپت** شروع به **ترشح کلراید** می‌کنند. "
    "**آب به‌دنبال کلراید می‌رود** — و نتیجه، اسهال آبکی عظیم است.\n\n"
    "⚠️ **و چون هیچ تهاجمی رخ نمی‌دهد: نه تب، نه درد شکم، نه گلبول سفید در مدفوع.** این سه "
    "«نبود»، به‌اندازه‌ی حضور اسهال، تشخیصی‌اند.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**شیگلا دیسانتری:** اسهال **التهابی** با **حجم کم**، **خون**، **تب** و **گلبول سفید "
    "فراوان**. هر چهار ویژگی با این بیمار در تضاد است.\n\n"
    "**ژیاردیا اینتستینالیس:** اسهال **مزمن** با **استئاتوره و نفخ**، و **نهفتگی یک تا دو "
    "هفته**. با شروع حاد «از صبح امروز» و طغیان چندروزه هم‌خوان نیست.\n\n"
    "⚠️ **سالمونلای غیرتیفی:** اسهال **التهابی** با **تب** می‌دهد و **گلبول سفید در مدفوع** "
    "دارد. این بیمار نه تب دارد و نه گلبول سفید.",
    "This question opens the cholera block and has THREE CLUES that together settle the diagnosis.\n\n"
    "THE PATIENT: a 22-year-old man with frequent large-volume watery diarrhoea since this morning. "
    "Temperature 37.3, blood pressure 80 by palpation, heart rate 112. The direct stool sample reports "
    "NO WHITE CELLS. And similar cases have attended the emergency department in recent days.\n\n"
    "CLUE ONE — LARGE VOLUME AND WATERY. This is the SMALL BOWEL PATTERN. The colon gives small "
    "volumes; ENORMOUS VOLUME MEANS SMALL BOWEL, MEANS A SECRETORY MECHANISM.\n\n"
    "WARNING, CLUE TWO — NO WHITE CELLS REPORTED IN THE STOOL. This is the DEFINITIVE CRITERION OF "
    "NON-INFLAMMATORY disease. Nothing has been invaded. And A TEMPERATURE OF 37.3 IS EFFECTIVELY NO "
    "FEVER.\n\n"
    "CLUE THREE — SIMILAR CASES IN RECENT DAYS. That means AN OUTBREAK. And cholera is the most classic "
    "cause of an outbreak of large-volume watery diarrhoea.\n\n"
    "AND THE SEVERITY: a blood pressure of 80 by palpation with a rate of 112 means SEVERE DEHYDRATION "
    "AND HYPOVOLAEMIC SHOCK, entirely consistent with cholera (which can lose LITRES PER HOUR).\n\n"
    "UNDERSTAND THE MECHANISM, because every later question depends on it:\n\n"
    "CHOLERA TOXIN binds the epithelial cells of the small bowel and LOCKS ADENYLATE CYCLASE IN THE ON "
    "POSITION. CYCLIC AMP rises, and the CRYPT cells begin SECRETING CHLORIDE. WATER FOLLOWS THE "
    "CHLORIDE — and the result is enormous watery diarrhoea.\n\n"
    "WARNING, AND BECAUSE NOTHING IS INVADED: NO FEVER, NO ABDOMINAL PAIN, NO STOOL LEUCOCYTES. Those "
    "three absences are as diagnostic as the diarrhoea itself.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "SHIGELLA DYSENTERIAE: INFLAMMATORY diarrhoea with SMALL VOLUME, BLOOD, FEVER and ABUNDANT WHITE "
    "CELLS. All four features contradict this patient.\n\n"
    "GIARDIA INTESTINALIS: CHRONIC diarrhoea with STEATORRHOEA AND BLOATING, and an incubation of ONE "
    "TO TWO WEEKS. Inconsistent with an acute onset 'since this morning' and a several-day outbreak.\n\n"
    "WARNING, NON-TYPHOIDAL SALMONELLA: causes INFLAMMATORY diarrhoea WITH FEVER and STOOL WHITE CELLS. "
    "This patient has neither.",
    ["پاسخ صحیح — حجم زیاد، بدون گلبول سفید، بدون تب، و در بستر یک طغیان.",
     "اسهال التهابی با حجم کم، خون، تب و گلبول سفید فراوان؛ هر چهار در تضاد با این بیمار.",
     "اسهال مزمن با استئاتوره و نهفتگی یک تا دو هفته؛ با شروع حاد امروز هم‌خوان نیست.",
     "اسهال التهابی با تب و گلبول سفید مدفوع می‌دهد؛ این بیمار هیچ‌کدام را ندارد."],
    ["Correct — large volume, no white cells, no fever, and set in an outbreak.",
     "Inflammatory diarrhoea with small volume, blood, fever and abundant white cells; all contradict this.",
     "Chronic diarrhoea with steatorrhoea and a one to two week incubation; inconsistent with today's onset.",
     "Causes inflammatory diarrhoea with fever and stool white cells; this patient has neither."],
    "**سه «نبود» به‌اندازه‌ی حضور اسهال تشخیصی‌اند: نه تب، نه درد، نه گلبول سفید.**",
    "Three absences are as diagnostic as the diarrhoea: no fever, no pain, no leucocytes.",
    CREFS)

add("book:334", "vignette", "easy",
    "**اسهال لعاب برنجی با بوی ماهی پس از سفر به هند: ویبریوکلرا.**",
    "Rice-water stool with a fishy odour after travel to India: VIBRIO CHOLERAE.",
    CH_FA + [
        "**دو توصیف در این سؤال، هر دو یک چیز را می‌گویند: مدفوع آب برنجی.**",
        "**«لعاب برنجی» یعنی بی‌رنگ و کدر با پرزهای مخاط شناور.**",
        "⚠️ **و «بوی ماهی گندیده» توصیف کلاسیک همان مدفوع است.**",
        "**چرا شبیه آب برنج است؟ چون تقریباً فقط آب و الکترولیت و مخاط است.**",
        "**رنگدانه‌ی صفراوی در آن نیست، چون عبور آن‌قدر سریع است که صفرا فرصت نمی‌کند.**",
        "**و پرزهای سفید همان تکه‌های مخاط جداشده‌اند.**",
        "**سفر به هند هم منطقه‌ی اندمیک وبا را می‌رساند.**",
        "⚠️ **و مدفوع بدون گلبول سفید و قرمز، تشخیص را قفل می‌کند.**",
    ],
    CH_EN + [
        "Two descriptions in this question both say the same thing: rice-water stool.",
        "'Rice-water' means colourless and cloudy with floating flecks of mucus.",
        "WARNING, AND 'A FISHY ODOUR' is the classic description of that same stool.",
        "Why does it look like rice water? Because it is almost purely water, electrolytes and mucus.",
        "There is no bile pigment in it, because transit is too fast for bile to colour it.",
        "And the white flecks are shed pieces of mucus.",
        "Travel to India also indicates a cholera-endemic region.",
        "WARNING, AND A STOOL WITH NO WHITE OR RED CELLS locks the diagnosis.",
    ],
    "این سؤال با **توصیف مدفوع** حل می‌شود، و آن توصیف کاملاً اختصاصی است.\n\n"
    "**بیمار: آقای ۲۵ ساله، یک روز پس از مسافرت به هند، دچار اسهال شدید آبکی لعاب برنجی. "
    "فشار خون ۹۰/۶۰. در نمونه‌ی مدفوع، گلبول قرمز صفر و گلبول سفید صفر. مدفوع بوی ماهی "
    "گندیده می‌دهد.**\n\n"
    "⚠️ **«لعاب برنجی» و «بوی ماهی» هر دو یک چیز را توصیف می‌کنند: مدفوع آب برنجی وبا.**\n\n"
    "**چرا مدفوع وبا شبیه آب برنج است؟ سه ویژگی آن را می‌سازد:**\n\n"
    "**یک — بی‌رنگ است.** چون **تقریباً فقط آب و الکترولیت** است. **هیچ رنگدانه‌ی صفراوی "
    "ندارد**، چون عبور روده‌ای آن‌قدر سریع است که صفرا فرصت رنگ دادن پیدا نمی‌کند.\n\n"
    "**دو — پرزهای سفید شناور دارد.** این‌ها **تکه‌های مخاط جداشده** هستند، و همان‌اند که "
    "ظاهر «دانه‌های برنج در آب» را می‌سازند.\n\n"
    "**سه — بوی خاصی دارد** که کلاسیک به‌صورت «بوی ماهی» یا «بوی شیرین ناخوشایند» توصیف "
    "می‌شود، و از **بوی معمول مدفوع کاملاً متفاوت** است (چون تقریباً هیچ محتوای مدفوعی و "
    "باکتریایی معمول در آن نیست).\n\n"
    "**و بقیه‌ی تابلو تشخیص را قفل می‌کند:**\n\n"
    "**سفر به هند** — منطقه‌ی اندمیک وبا. **فشار ۹۰/۶۰** — دهیدراتاسیون قابل توجه. ⚠️ "
    "**گلبول سفید صفر و گلبول قرمز صفر** — **کاملاً غیرالتهابی**، که تهاجم را رد می‌کند.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**باسیلوس سرئوس:** مسمومیت غذایی با نهفتگی **۱ تا ۱۶ ساعت** (بسته به شکل). ولی "
    "**حجم اسهال آن این‌قدر عظیم نیست** و **مدفوع آب برنجی نمی‌دهد**. و معمولاً با **برنج "
    "مانده** مرتبط است، نه سفر.\n\n"
    "**کلستریدیوم پرفرانژنس:** کرامپ و اسهال آبکی می‌دهد، ولی **خودمحدود و نسبتاً خفیف** "
    "است و **به دهیدراتاسیون شدید نمی‌رسد**. مدفوع آب برنجی هم نمی‌دهد.\n\n"
    "⚠️ **ETEC (اشرشیاکلی انتروتوکسیکوژنیک):** **این نزدیک‌ترین رقیب است** و ارزش بررسی "
    "دقیق دارد. ETEC هم **سم شبیه سم وبا (LT)** می‌سازد، هم **اسهال آبکی بدون گلبول سفید** "
    "می‌دهد، و هم **عامل اصلی اسهال مسافران** است. **پس چه چیزی آن‌ها را جدا می‌کند؟ شدت.** "
    "ETEC معمولاً **اسهال خفیف تا متوسط و خودمحدود** می‌دهد که به **دهیدراتاسیون شدید نمی‌رسد**، "
    "و **مدفوع آب برنجی کلاسیک نمی‌سازد**. توصیف «لعاب برنجی» به‌علاوه‌ی «اسهال شدید» به‌علاوه‌ی "
    "«افت فشار»، تابلو را به سمت وبا می‌برد.",
    "This question is solved BY THE DESCRIPTION OF THE STOOL, and that description is entirely specific.\n\n"
    "THE PATIENT: a 25-year-old man who, one day after travelling to India, develops severe watery "
    "RICE-WATER diarrhoea. Blood pressure 90/60. The stool sample shows ZERO red cells and ZERO white "
    "cells. The stool has A FISHY ODOUR.\n\n"
    "WARNING, 'RICE-WATER' AND 'FISHY ODOUR' BOTH DESCRIBE THE SAME THING: the rice-water stool of "
    "cholera.\n\n"
    "WHY DOES CHOLERA STOOL LOOK LIKE RICE WATER? Three features make it:\n\n"
    "ONE — IT IS COLOURLESS. Because it is ALMOST PURELY WATER AND ELECTROLYTES. It contains NO BILE "
    "PIGMENT, because intestinal transit is too fast for bile to colour it.\n\n"
    "TWO — IT CONTAINS FLOATING WHITE FLECKS. These are SHED PIECES OF MUCUS, and they create the "
    "appearance of 'grains of rice in water'.\n\n"
    "THREE — IT HAS A CHARACTERISTIC ODOUR classically described as 'fishy' or 'sweetish and "
    "unpleasant', ENTIRELY UNLIKE ORDINARY FAECAL SMELL (because it contains almost none of the usual "
    "faecal and bacterial content).\n\n"
    "AND THE REST OF THE PICTURE LOCKS THE DIAGNOSIS:\n\n"
    "TRAVEL TO INDIA — a cholera-endemic region. BLOOD PRESSURE 90/60 — significant dehydration. "
    "WARNING, ZERO WHITE CELLS AND ZERO RED CELLS — entirely NON-INFLAMMATORY, which excludes invasion.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "BACILLUS CEREUS: food poisoning with a 1 TO 16 HOUR incubation (depending on the form). But ITS "
    "DIARRHOEAL VOLUME IS NOT THIS ENORMOUS and it DOES NOT PRODUCE RICE-WATER STOOL. And it is usually "
    "linked to REHEATED RICE rather than travel.\n\n"
    "CLOSTRIDIUM PERFRINGENS: causes cramps and watery diarrhoea, but it is SELF-LIMITED AND RELATIVELY "
    "MILD and DOES NOT REACH SEVERE DEHYDRATION. Nor does it give rice-water stool.\n\n"
    "WARNING, ETEC (enterotoxigenic E. coli): THIS IS THE CLOSEST COMPETITOR and deserves careful "
    "examination. ETEC also makes A CHOLERA-LIKE TOXIN (LT), also causes WATERY DIARRHOEA WITHOUT WHITE "
    "CELLS, and is THE MAIN CAUSE OF TRAVELLER'S DIARRHOEA. SO WHAT SEPARATES THEM? SEVERITY. ETEC "
    "usually causes MILD TO MODERATE SELF-LIMITED diarrhoea that DOES NOT REACH SEVERE DEHYDRATION, and "
    "it DOES NOT PRODUCE THE CLASSIC RICE-WATER STOOL. The description 'rice-water' plus 'severe "
    "diarrhoea' plus 'a fall in blood pressure' moves the picture to cholera.",
    ["مسمومیت غذایی است ولی حجم آن عظیم نیست و مدفوع آب برنجی نمی‌دهد.",
     "پاسخ صحیح — مدفوع آب برنجی با بوی ماهی، بدون گلبول سفید، و سفر به منطقه‌ی اندمیک.",
     "کرامپ و اسهال آبکی خودمحدود می‌دهد و به دهیدراتاسیون شدید نمی‌رسد.",
     "نزدیک‌ترین رقیب — سم شبیه وبا دارد ولی اسهالش خفیف‌تر است و آب برنجی نمی‌شود."],
    ["Food poisoning, but its volume is not enormous and it does not give rice-water stool.",
     "Correct — rice-water stool with a fishy odour, no white cells, and travel to an endemic area.",
     "Causes self-limited cramps and watery diarrhoea and does not reach severe dehydration.",
     "The closest competitor — it has a cholera-like toxin but milder diarrhoea, never rice-water."],
    "**مدفوع آب برنجی: بی‌رنگ چون صفرا فرصت رنگ دادن ندارد، پرزدار چون مخاط جدا شده.**",
    "Rice-water stool: colourless because bile has no time to colour it, flecked because mucus is shed.",
    CREFS)

add("book:335", "recall", "easy",
    "**تب با وبای کلاسیک منطبق نیست — چون وبا هیچ تهاجمی ندارد.**",
    "Fever is inconsistent with classic cholera — because cholera invades nothing.",
    CH_FA,
    CH_EN,
    "این سؤال یک **«نبود»** را می‌سنجد، و همان نبود، ستون تشخیص وباست.\n\n"
    "**بیمار: کودک ۸ ساله با اسهال حاد آبکی از ۲ ساعت قبل. هم‌زمان تب‌دار است، استفراغ "
    "می‌کند و کرامپ عضلانی هم دارد. کدام علامت با کلرای کلاسیک منطبق نیست؟**\n\n"
    "⚠️ **پاسخ: تب.**\n\n"
    "**چرا وبا تب نمی‌دهد؟ پاسخ در سازوکار بیماری است:**\n\n"
    "**وبا یک بیماری کاملاً سم‌محور است.** ویبریوکلرا **به مخاط نمی‌چسبد تا آن را تخریب کند**؛ "
    "فقط در لومن روده‌ی باریک می‌ماند و **سم ترشح می‌کند**. سم آدنیلات سیکلاز را روشن نگه "
    "می‌دارد، cAMP بالا می‌رود، و سلول‌های کریپت **کلراید و آب** بیرون می‌ریزند.\n\n"
    "**و چون هیچ سلولی تخریب نمی‌شود و هیچ بافتی تهاجم نمی‌بیند:**\n\n"
    "**پاسخ التهابی سیستمیک راه نمی‌افتد** → **تب نمی‌آید**. **گلبول سفید به مخاط فرا خوانده "
    "نمی‌شود** → **مدفوع گلبول سفید ندارد**. **مخاط زخم نمی‌شود** → **خون در مدفوع نیست**. "
    "**گیرنده‌های درد تحریک نمی‌شوند** → **درد شکم قابل توجه نیست**.\n\n"
    "**پس چهار «نبود» وبا، همه از یک ریشه می‌آیند: نبود تهاجم.**\n\n"
    "**چرا سه علامت دیگر با وبا منطبق‌اند؟**\n\n"
    "**استفراغ** — **کاملاً منطبق**. استفراغ در وبا **شایع** است، به‌ویژه در ابتدای بیماری. "
    "سازوکار آن ترکیبی است: اثر سم بر روده‌ی باریک فوقانی، و **اسیدوز متابولیک** ناشی از از "
    "دست دادن بی‌کربنات.\n\n"
    "**اسهال آبکی** — **علامت تعریف‌کننده‌ی** بیماری.\n\n"
    "⚠️ **کرامپ عضلانی** — **کاملاً منطبق، و سازوکار آن آموزنده است.** کرامپ **از عفونت "
    "نمی‌آید**؛ از **اختلال الکترولیت** می‌آید. مدفوع وبا مقدار زیادی **پتاسیم** و **بی‌کربنات** "
    "دارد. **هیپوکالمی** و **هیپوکلسمی** (ناشی از آلکالوز یا از دست دادن) عضله را تحریک‌پذیر "
    "می‌کنند و کرامپ می‌سازند. **پس کرامپ نشانه‌ی شدت از دست دادن مایع است، نه نشانه‌ی عفونت.**\n\n"
    "**و اگر بیماری با اسهال آبکی حجیم تب داشت؟** آنگاه باید به **عامل دیگری** فکر کرد "
    "(سالمونلا، شیگلا در فاز اولیه، یا یک عفونت هم‌زمان) — یا به **عارضه‌ای** مثل عفونت ثانویه.",
    "This question tests AN ABSENCE, and that absence is a pillar of the cholera diagnosis.\n\n"
    "THE PATIENT: an 8-year-old child with acute watery diarrhoea for 2 hours. He is simultaneously "
    "FEBRILE, is vomiting, and has muscle cramps. Which feature is inconsistent with classic cholera?\n\n"
    "WARNING, THE ANSWER: THE FEVER.\n\n"
    "WHY DOES CHOLERA CAUSE NO FEVER? The answer lies in the mechanism:\n\n"
    "CHOLERA IS A PURELY TOXIN-MEDIATED DISEASE. Vibrio cholerae DOES NOT ATTACH TO THE MUCOSA TO "
    "DESTROY IT; it remains in the lumen of the small bowel and SECRETES TOXIN. The toxin keeps "
    "adenylate cyclase switched on, cyclic AMP rises, and the crypt cells pour out CHLORIDE AND WATER.\n\n"
    "AND BECAUSE NO CELL IS DESTROYED AND NO TISSUE IS INVADED:\n\n"
    "NO SYSTEMIC INFLAMMATORY RESPONSE IS TRIGGERED, so NO FEVER. NO LEUCOCYTES ARE RECRUITED to the "
    "mucosa, so NO STOOL WHITE CELLS. THE MUCOSA IS NOT ULCERATED, so NO BLOOD IN THE STOOL. PAIN "
    "RECEPTORS ARE NOT STIMULATED, so NO SIGNIFICANT ABDOMINAL PAIN.\n\n"
    "SO CHOLERA'S FOUR ABSENCES ALL SHARE ONE ROOT: THE ABSENCE OF INVASION.\n\n"
    "WHY ARE THE OTHER THREE CONSISTENT WITH CHOLERA?\n\n"
    "VOMITING — ENTIRELY CONSISTENT. Vomiting is COMMON in cholera, especially early. Its mechanism is "
    "mixed: the toxin's effect on the upper small bowel, and the METABOLIC ACIDOSIS from bicarbonate "
    "loss.\n\n"
    "WATERY DIARRHOEA — THE DEFINING feature of the disease.\n\n"
    "WARNING, MUSCLE CRAMPS — ENTIRELY CONSISTENT, AND THEIR MECHANISM IS INSTRUCTIVE. The cramps DO "
    "NOT COME FROM THE INFECTION; they come from ELECTROLYTE DISTURBANCE. Cholera stool contains large "
    "amounts of POTASSIUM and BICARBONATE. HYPOKALAEMIA and HYPOCALCAEMIA (from alkalosis or loss) make "
    "muscle irritable and produce cramps. SO CRAMPS ARE A MARKER OF THE SEVERITY OF FLUID LOSS, NOT A "
    "SIGN OF INFECTION.\n\n"
    "AND IF A PATIENT WITH LARGE-VOLUME WATERY DIARRHOEA DID HAVE FEVER? Then ANOTHER ORGANISM should "
    "be considered (Salmonella, early Shigella, or a coinfection) — or a COMPLICATION such as secondary "
    "infection.",
    ["پاسخ صحیح — وبا هیچ تهاجمی ندارد، پس پاسخ التهابی سیستمیک و تب راه نمی‌افتد.",
     "کاملاً منطبق — استفراغ در وبا شایع است، از اثر سم و اسیدوز متابولیک.",
     "علامت تعریف‌کننده‌ی بیماری است.",
     "کاملاً منطبق — کرامپ از هیپوکالمی و هیپوکلسمی می‌آید، نه از عفونت."],
    ["Correct — cholera invades nothing, so no systemic inflammatory response and no fever.",
     "Entirely consistent — vomiting is common in cholera, from the toxin and metabolic acidosis.",
     "The defining feature of the disease.",
     "Entirely consistent — the cramps come from hypokalaemia and hypocalcaemia, not from infection."],
    "**چهار «نبود» وبا از یک ریشه‌اند: نبود تهاجم.**",
    "Cholera's four absences share one root: the absence of invasion.",
    CREFS)

add("book:337", "recall", "easy",
    "**باز هم تب: تنها ویژگی این بیمار که با وبا نمی‌خواند.**",
    "Fever again: the only feature in this patient that does not fit cholera.",
    CH_FA + [
        "**سه ویژگی دیگر این بیمار همگی کاملاً وبایی‌اند.**",
        "**خونی نبودن اسهال: چون هیچ زخم مخاطی وجود ندارد.**",
        "**کرامپ عضلانی: از هیپوکالمی، نه از عفونت.**",
        "⚠️ **و رنگ خاکستری اسهال با موکوس: همان مدفوع آب برنجی است.**",
        "**پس هر سه با وبا منطبق‌اند و تنها تب بیرون می‌ماند.**",
        "**و بوی بد هم با مدفوع وبا منافاتی ندارد.**",
        "**بوی «ماهی» یا «شیرین ناخوشایند» توصیف کلاسیک آن است.**",
    ],
    CH_EN + [
        "The patient's other three features are all entirely cholera-like.",
        "The absence of blood: because there is no mucosal ulceration.",
        "Muscle cramps: from hypokalaemia, not from infection.",
        "WARNING, AND THE GREY COLOUR WITH MUCUS: that is the rice-water stool.",
        "So all three fit cholera and only the fever stands outside.",
        "And a bad odour is not inconsistent with cholera stool either.",
        "A 'fishy' or 'sweetish unpleasant' smell is its classic description.",
    ],
    "کتاب همان قاعده را دوباره پرسیده، و این تکرار پیام روشنی دارد: **نبود تب را به‌عنوان "
    "بخشی از تعریف وبا حفظ کنید.**\n\n"
    "**بیمار: خانم ۳۰ ساله با اسهال آبکی بدون درد شکم که به‌سرعت حجیم شده، به‌علاوه‌ی تب و "
    "استفراغ و کرامپ عضلانی. اسهال او خاکستری و محتوی موکوس، بدون خون، و با بوی بد است.**\n\n"
    "⚠️ **پاسخ: تب.**\n\n"
    "**بیایید سه ویژگی دیگر را بررسی کنیم تا ببینیم چرا همه با وبا منطبق‌اند:**\n\n"
    "**خونی نبودن اسهال** — ✔ **کاملاً منطبق و در واقع لازم.** وبا **هیچ‌گاه خونی نمی‌شود**، "
    "چون **هیچ زخم مخاطی ایجاد نمی‌کند**. اگر مدفوع خونی بود، تشخیص **رد می‌شد**.\n\n"
    "**کرامپ عضلانی** — ✔ **کاملاً منطبق.** از **از دست دادن پتاسیم و کلسیم** می‌آید، نه از "
    "عفونت. در وبای شدید کرامپ‌ها می‌توانند بسیار دردناک باشند.\n\n"
    "⚠️ **رنگ خاکستری اسهال با موکوس** — ✔ **این دقیقاً توصیف مدفوع آب برنجی است.** "
    "**بی‌رنگ تا خاکستری** (چون رنگدانه‌ی صفراوی ندارد) و **حاوی پرزهای موکوس** (تکه‌های مخاط "
    "جداشده). این **به نفع وباست، نه بر خلاف آن**.\n\n"
    "**و «بوی بد»؟** این هم منافاتی ندارد. مدفوع وبا بوی خاصی دارد که کلاسیک به‌صورت **«بوی "
    "ماهی»** یا **«شیرین ناخوشایند»** توصیف می‌شود.\n\n"
    "**پس فقط تب بیرون می‌ماند.**\n\n"
    "**و یادآوری سازوکار:** وبا **سم‌محور خالص** است. بدون تهاجم → بدون پاسخ التهابی سیستمیک "
    "→ بدون تب.\n\n"
    "⚠️ **نکته‌ی بالینی مهم: اگر بیماری با تابلوی وبا تب داشت، دو احتمال را بررسی کنید.** "
    "یک: **تشخیص اشتباه است** و عامل دیگری در کار است. دو: **عفونت هم‌زمان یا ثانویه** وجود "
    "دارد. در هر دو حالت، تب یک **پرچم قرمز** است که باید توضیح داده شود، نه نادیده گرفته شود.",
    "The book asks the same rule again, and that repetition carries a clear message: MEMORISE THE "
    "ABSENCE OF FEVER AS PART OF THE DEFINITION OF CHOLERA.\n\n"
    "THE PATIENT: a 30-year-old woman with painless watery diarrhoea that rapidly became voluminous, "
    "plus FEVER, vomiting and muscle cramps. Her stool is GREY and CONTAINS MUCUS, WITHOUT BLOOD, and "
    "has A BAD ODOUR.\n\n"
    "WARNING, THE ANSWER: THE FEVER.\n\n"
    "LET US EXAMINE THE OTHER THREE FEATURES TO SEE WHY THEY ALL FIT CHOLERA:\n\n"
    "THE ABSENCE OF BLOOD — CONSISTENT, and in fact REQUIRED. Cholera IS NEVER BLOODY, because it "
    "CAUSES NO MUCOSAL ULCERATION. If the stool were bloody, the diagnosis would be EXCLUDED.\n\n"
    "MUSCLE CRAMPS — ENTIRELY CONSISTENT. They come from LOSS OF POTASSIUM AND CALCIUM, not from "
    "infection. In severe cholera the cramps can be intensely painful.\n\n"
    "WARNING, THE GREY COLOUR WITH MUCUS — THIS IS EXACTLY THE DESCRIPTION OF RICE-WATER STOOL. "
    "COLOURLESS TO GREY (because it lacks bile pigment) and CONTAINING FLECKS OF MUCUS (shed mucosal "
    "fragments). This FAVOURS cholera rather than arguing against it.\n\n"
    "AND THE 'BAD ODOUR'? Also not inconsistent. Cholera stool has a characteristic smell classically "
    "described as 'FISHY' or 'SWEETISH AND UNPLEASANT'.\n\n"
    "SO ONLY THE FEVER STANDS OUTSIDE.\n\n"
    "AND A REMINDER OF THE MECHANISM: cholera is PURELY TOXIN-MEDIATED. No invasion, so no systemic "
    "inflammatory response, so no fever.\n\n"
    "WARNING, AN IMPORTANT CLINICAL POINT: IF A PATIENT WITH A CHOLERA PICTURE HAS FEVER, CONSIDER TWO "
    "POSSIBILITIES. One: THE DIAGNOSIS IS WRONG and another organism is responsible. Two: THERE IS A "
    "COINFECTION OR SECONDARY INFECTION. Either way, fever is A RED FLAG that must be explained rather "
    "than ignored.",
    ["پاسخ صحیح — وبا سم‌محور خالص است و بدون تهاجم، پاسخ التهابی سیستمیک راه نمی‌افتد.",
     "کاملاً منطبق و در واقع لازم — وبا هیچ‌گاه خونی نمی‌شود چون زخم مخاطی نمی‌سازد.",
     "کاملاً منطبق — کرامپ از از دست دادن پتاسیم و کلسیم می‌آید، نه از عفونت.",
     "رنگ خاکستری با موکوس دقیقاً توصیف مدفوع آب برنجی است و به نفع وباست."],
    ["Correct — cholera is purely toxin-mediated, and without invasion no systemic inflammatory response occurs.",
     "Consistent and in fact required — cholera is never bloody because it causes no mucosal ulceration.",
     "Entirely consistent — the cramps come from potassium and calcium loss, not from infection.",
     "Grey with mucus is exactly the description of rice-water stool and favours cholera."],
    "**اگر تابلوی وبا تب داشت، یا تشخیص غلط است یا عفونت دومی هست.**",
    "If a cholera picture has fever, either the diagnosis is wrong or there is a second infection.",
    CREFS)

add("book:338", "recall", "medium",
    "**تشنگی، افت فشار وضعیتی، تاکی‌کاردی و مخاط خشک: دهیدراتاسیون متوسط، ۵ تا ۱۰ درصد.**",
    "Thirst, postural hypotension, tachycardia and dry mucosae: MODERATE dehydration, 5 to 10 per cent.",
    CH_FA + [
        "**درجه‌بندی دهیدراتاسیون را به‌صورت سه پله حفظ کنید، چون مستقیم پرسیده می‌شود.**",
        "**زیر پنج درصد: فقط تشنگی، و معاینه تقریباً طبیعی.**",
        "⚠️ **پنج تا ده درصد: تشنگی، افت فشار وضعیتی، ضعف، تاکی‌کاردی.**",
        "**به‌علاوه کاهش تورگور پوست، مخاط خشک، و نداشتن اشک.**",
        "**بیش از ده درصد: همه‌ی موارد بالا، به‌علاوه‌ی شوک و لتارژی یا کما.**",
        "**تفاوت کلیدی میان متوسط و شدید، وضعیت هوشیاری و فشار خون در حالت خوابیده است.**",
        "**در متوسط، بیمار هوشیار است و فشار خوابیده هنوز حفظ شده.**",
        "⚠️ **در شدید، بیمار لتارژیک یا بی‌هوش است و فشار خوابیده هم افتاده.**",
        "**و نداشتن اشک در کودک، یکی از حساس‌ترین نشانه‌های بالینی است.**",
    ],
    CH_EN + [
        "Memorise dehydration grading as three steps, because it is asked directly.",
        "UNDER 5%: thirst only, with a nearly normal examination.",
        "WARNING, 5 TO 10%: thirst, postural hypotension, weakness, tachycardia.",
        "Plus reduced skin turgor, dry mucous membranes, and absent tears.",
        "OVER 10%: all of the above PLUS shock and lethargy or coma.",
        "The key difference between moderate and severe is the conscious level and the LYING blood pressure.",
        "In moderate dehydration the patient is alert and the lying pressure is still maintained.",
        "WARNING, IN SEVERE DEHYDRATION the patient is lethargic or unconscious and even the lying pressure has fallen.",
        "And absent tears in a child is one of the most sensitive clinical signs.",
    ],
    "این سؤال یک **درجه‌بندی** را می‌سنجد که مستقیماً بر تصمیم درمانی اثر می‌گذارد.\n\n"
    "**سؤال: در وبا، وجود تشنگی، هیپوتانسیون اورتواستاتیک، ضعف، تاکی‌کاردی، کاهش تورگور "
    "پوست، مخاط خشک و نداشتن اشک، نشانه‌ی چند درصد دهیدراتاسیون است؟**\n\n"
    "⚠️ **پاسخ: بین ۵ تا ۱۰ درصد — دهیدراتاسیون متوسط.**\n\n"
    "**سه پله را حفظ کنید:**\n\n"
    "**پله‌ی یک — کمتر از ۵ درصد (خفیف):** فقط **تشنگی**. معاینه تقریباً طبیعی است؛ فشار "
    "خون، نبض و تورگور پوست همه سالم‌اند. بیمار فقط احساس تشنگی می‌کند.\n\n"
    "⚠️ **پله‌ی دو — ۵ تا ۱۰ درصد (متوسط):** اینجا **نشانه‌های عینی** ظاهر می‌شوند: "
    "**هیپوتانسیون اورتواستاتیک** (افت فشار با تغییر وضعیت)، **تاکی‌کاردی**، **کاهش تورگور "
    "پوست**، **مخاط خشک**، **نداشتن اشک**، و **ضعف**.\n\n"
    "**پله‌ی سه — بیش از ۱۰ درصد (شدید):** همه‌ی موارد بالا، **به‌علاوه‌ی شوک** (فشار پایین "
    "حتی در حالت خوابیده)، **لتارژی یا کما**، **نبض ضعیف یا غیرقابل لمس**، **آنوری**، و "
    "**تورگور پوست بسیار کاهش‌یافته** (پوست به حالت خمیری درمی‌آید).\n\n"
    "**تفاوت کلیدی میان متوسط و شدید را بشناسید — دو چیز:**\n\n"
    "**یک — وضعیت هوشیاری.** در **متوسط**، بیمار **هوشیار** است. در **شدید**، **لتارژیک یا "
    "بی‌هوش**.\n\n"
    "**دو — فشار خون در حالت خوابیده.** در **متوسط**، فشار خوابیده **هنوز حفظ شده** و فقط "
    "با **نشستن یا ایستادن** می‌افتد (همان هیپوتانسیون اورتواستاتیک). در **شدید**، فشار "
    "**حتی در حالت خوابیده هم پایین** است.\n\n"
    "**و در سؤال ما:** بیمار **تشنگی، افت فشار وضعیتی، تاکی‌کاردی و مخاط خشک** دارد — ولی "
    "**هیچ اشاره‌ای به شوک، لتارژی یا کما نیست**. پس **متوسط**.\n\n"
    "⚠️ **چرا این درجه‌بندی مهم است؟ چون درمان را تعیین می‌کند:**\n\n"
    "**خفیف و متوسط** → **مایع‌درمانی خوراکی (او.آر.اس)** معمولاً کافی است.\n\n"
    "**شدید** → **مایع وریدی فوری** (رینگر لاکتات) لازم است، چون بیمار نمی‌تواند به‌اندازه‌ی "
    "کافی بنوشد و جذب روده‌ای هم در شوک مختل است.\n\n"
    "**و نکته‌ی کودکان: «نداشتن اشک» یکی از حساس‌ترین نشانه‌های بالینی دهیدراتاسیون در کودک "
    "است** و در ارزیابی سریع بسیار ارزشمند.",
    "This question tests A GRADING SYSTEM that directly affects the treatment decision.\n\n"
    "THE QUESTION: in cholera, the presence of thirst, orthostatic hypotension, weakness, tachycardia, "
    "reduced skin turgor, dry mucosae and absent tears indicates what percentage of dehydration?\n\n"
    "WARNING, THE ANSWER: 5 TO 10 PER CENT — MODERATE dehydration.\n\n"
    "MEMORISE THE THREE STEPS:\n\n"
    "STEP ONE — UNDER 5% (MILD): THIRST only. The examination is nearly normal; blood pressure, pulse "
    "and skin turgor are all intact. The patient simply feels thirsty.\n\n"
    "WARNING, STEP TWO — 5 TO 10% (MODERATE): here OBJECTIVE SIGNS appear: ORTHOSTATIC HYPOTENSION (a "
    "fall in pressure on changing posture), TACHYCARDIA, REDUCED SKIN TURGOR, DRY MUCOSAE, ABSENT "
    "TEARS, and WEAKNESS.\n\n"
    "STEP THREE — OVER 10% (SEVERE): all of the above PLUS SHOCK (a low pressure even lying down), "
    "LETHARGY OR COMA, a WEAK OR IMPALPABLE PULSE, ANURIA, and MARKEDLY REDUCED SKIN TURGOR (the skin "
    "becomes doughy).\n\n"
    "LEARN THE KEY DIFFERENCE BETWEEN MODERATE AND SEVERE — two things:\n\n"
    "ONE — THE CONSCIOUS LEVEL. In MODERATE dehydration the patient is ALERT. In SEVERE he is LETHARGIC "
    "OR UNCONSCIOUS.\n\n"
    "TWO — THE LYING BLOOD PRESSURE. In MODERATE dehydration the lying pressure IS STILL MAINTAINED and "
    "falls only ON SITTING OR STANDING (that is the orthostatic hypotension). In SEVERE dehydration the "
    "pressure IS LOW EVEN LYING DOWN.\n\n"
    "AND IN OUR QUESTION: the patient has THIRST, POSTURAL HYPOTENSION, TACHYCARDIA AND DRY MUCOSAE — "
    "but THERE IS NO MENTION OF SHOCK, LETHARGY OR COMA. So MODERATE.\n\n"
    "WARNING, WHY DOES THIS GRADING MATTER? BECAUSE IT DETERMINES THE TREATMENT:\n\n"
    "MILD AND MODERATE means ORAL REHYDRATION (ORS) is usually sufficient.\n\n"
    "SEVERE means IMMEDIATE INTRAVENOUS FLUID (Ringer's lactate) is required, because the patient "
    "cannot drink enough and intestinal absorption is impaired in shock.\n\n"
    "AND A PAEDIATRIC POINT: 'ABSENT TEARS' IS ONE OF THE MOST SENSITIVE CLINICAL SIGNS OF DEHYDRATION "
    "IN A CHILD and is very valuable in rapid assessment.",
    ["در دهیدراتاسیون خفیف فقط تشنگی هست و معاینه تقریباً طبیعی است.",
     "پاسخ صحیح — نشانه‌های عینی ظاهر شده‌اند ولی شوک و اختلال هوشیاری نیست.",
     "در دهیدراتاسیون شدید، شوک و لتارژی یا کما هم اضافه می‌شود که اینجا ذکر نشده.",
     "یکی از سه گزینه قطعاً درست است؛ این مجموعه‌ی نشانه‌ها تعریف دهیدراتاسیون متوسط است."],
    ["In mild dehydration there is thirst only and the examination is nearly normal.",
     "Correct — objective signs have appeared but there is no shock or altered consciousness.",
     "Severe dehydration adds shock and lethargy or coma, which are not mentioned here.",
     "One of the three options is definitely correct; this set of signs defines moderate dehydration."],
    "**متوسط: هوشیار با افت وضعیتی. شدید: لتارژیک با افت در حالت خوابیده.**",
    "Moderate: alert with a postural fall. Severe: lethargic with a fall even lying down.",
    CREFS)

add("book:339", "recall", "hard",
    "**محیط انتقالی وبا کری-بلر است — و TCBS محیط کشت است، نه انتقالی.**",
    "The transport medium for cholera is CARY-BLAIR — and TCBS is a CULTURE medium, not a transport one.",
    CH_FA + [
        "**این سؤال یک تمایز فنی را می‌سنجد: محیط انتقالی در برابر محیط کشت.**",
        "**محیط انتقالی، ارگانیسم را در راه زنده نگه می‌دارد بدون اینکه بگذارد تکثیر شود.**",
        "**و محیط کشت، ارگانیسم را در آزمایشگاه رشد می‌دهد و جدا می‌کند.**",
        "⚠️ **کری-بلر محیط انتقالی است و برای همین کار ساخته شده.**",
        "**نیمه‌جامد است، مواد مغذی ندارد، و pH آن قلیایی است.**",
        "**نبود مواد مغذی یعنی باکتری زنده می‌ماند ولی زیاد نمی‌شود.**",
        "**و همین ترکیب نمونه را روزها پایدار نگه می‌دارد.**",
        "**در برابر آن، TCBS یک محیط کشت انتخابی برای ویبریوهاست.**",
        "⚠️ **در TCBS، ویبریوکلرا کلنی زرد می‌دهد چون ساکارز را تخمیر می‌کند.**",
        "**و ویبریو پاراهمولیتیکوس کلنی سبز، چون ساکارز را تخمیر نمی‌کند.**",
        "**پس TCBS برای جدا کردن در آزمایشگاه است، نه برای حمل نمونه.**",
    ],
    CH_EN + [
        "This question tests a technical distinction: a TRANSPORT medium versus a CULTURE medium.",
        "A transport medium keeps the organism alive in transit without letting it multiply.",
        "And a culture medium grows and isolates the organism in the laboratory.",
        "WARNING, CARY-BLAIR IS A TRANSPORT MEDIUM built precisely for that purpose.",
        "It is semi-solid, contains no nutrients, and has an alkaline pH.",
        "The absence of nutrients means the bacterium survives but does not multiply.",
        "And that combination keeps the specimen stable for days.",
        "Against it, TCBS is a SELECTIVE CULTURE medium for vibrios.",
        "WARNING, ON TCBS Vibrio cholerae forms YELLOW colonies because it ferments sucrose.",
        "And Vibrio parahaemolyticus forms GREEN colonies, because it does not.",
        "So TCBS is for isolation in the laboratory, not for transporting a specimen.",
    ],
    "این سخت‌ترین سؤال بلوک وباست، چون یک **تمایز فنی آزمایشگاهی** را می‌سنجد.\n\n"
    "**موقعیت: مرد ۳۸ ساله با اسهال آبکی شدید در یک مرکز درمانی روستایی. فشار ۷۰ با پالس و "
    "مخاطات کاملاً خشک. با توجه به فاصله‌ی طولانی تا مرکز بهداشت شهرستان، برای تأیید تشخیص "
    "از کدام محیط انتقالی استفاده می‌کنیم؟**\n\n"
    "⚠️ **کلمه‌ی کلیدی «انتقالی» است. و سؤال هم دقیقاً روی همین تمرکز کرده: «فاصله‌ی طولانی "
    "تا مرکز بهداشت».**\n\n"
    "**تفاوت بنیادی را بفهمید:**\n\n"
    "**محیط انتقالی (transport medium):** کارش این است که ارگانیسم را **در راه زنده نگه "
    "دارد** — بدون اینکه بگذارد **تکثیر شود** یا **بمیرد**. نمونه باید ساعت‌ها یا روزها در "
    "راه بماند و همچنان قابل کشت باشد.\n\n"
    "**محیط کشت (culture medium):** کارش این است که ارگانیسم را **در آزمایشگاه رشد دهد** و "
    "**جدا کند**.\n\n"
    "**پس پاسخ: کری-بلر (Cary-Blair).**\n\n"
    "**چرا کری-بلر برای این کار مناسب است؟ سه ویژگی:**\n\n"
    "**یک — نیمه‌جامد است**، پس نمونه در آن پخش نمی‌شود و پایدار می‌ماند.\n\n"
    "⚠️ **دو — مواد مغذی ندارد.** این عمدی است: **باکتری زنده می‌ماند ولی زیاد نمی‌شود**. اگر "
    "تکثیر می‌شد، **نسبت ارگانیسم‌ها به هم می‌خورد** و فلور همراه بر پاتوژن غلبه می‌کرد.\n\n"
    "**سه — pH قلیایی دارد** (حدود ۸٫۴)، که **دقیقاً همان چیزی است که ویبریوکلرا دوست دارد** "
    "— ویبریو یک باکتری **قلیادوست** است.\n\n"
    "**و کری-بلر عمومی است:** برای **شیگلا، سالمونلا، کمپیلوباکتر و ویبریو** همگی کار می‌کند.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "⚠️ **TCBS (تیوسولفات-سیترات-بایل‌سالت-ساکارز):** **این دام اصلی سؤال است.** TCBS "
    "**محیط کشت انتخابی** برای ویبریوهاست، **نه محیط انتقالی**. در آزمایشگاه از آن برای "
    "**جدا کردن** ویبریو استفاده می‌شود. **و نکته‌ی زیبای آن: ویبریوکلرا کلنی زرد می‌دهد** "
    "(چون **ساکارز را تخمیر می‌کند** و pH را اسیدی می‌کند و معرف را زرد می‌کند)، در حالی که "
    "**ویبریو پاراهمولیتیکوس کلنی سبز** می‌دهد (ساکارز را تخمیر نمی‌کند).\n\n"
    "**TTG (تائوروکولات-تلوریت-ژلاتین):** این هم یک محیط **کشت** (غنی‌کننده) برای ویبریو "
    "است، نه محیط انتقالی.\n\n"
    "**«از هر سه محیط می‌توان استفاده نمود»:** نادرست، چون **دو تای آن‌ها محیط کشت‌اند**، و "
    "استفاده از محیط کشت برای حمل نمونه در فاصله‌ی طولانی، **ترکیب میکروبی نمونه را به هم "
    "می‌ریزد**.",
    "This is the hardest question in the cholera block, because it tests A TECHNICAL LABORATORY "
    "DISTINCTION.\n\n"
    "THE SITUATION: a 38-year-old man with severe watery diarrhoea at a rural health centre. Blood "
    "pressure 70 by palpation and completely dry mucosae. GIVEN THE LONG DISTANCE to the district "
    "health centre, which TRANSPORT medium is used to confirm the diagnosis?\n\n"
    "WARNING, THE KEY WORD IS 'TRANSPORT'. And the question focuses on it precisely: 'the long distance "
    "to the health centre'.\n\n"
    "UNDERSTAND THE FUNDAMENTAL DIFFERENCE:\n\n"
    "A TRANSPORT MEDIUM: its job is to KEEP THE ORGANISM ALIVE IN TRANSIT — without letting it MULTIPLY "
    "or DIE. The specimen must survive hours or days on the road and still be culturable.\n\n"
    "A CULTURE MEDIUM: its job is to GROW AND ISOLATE the organism in the laboratory.\n\n"
    "SO THE ANSWER: CARY-BLAIR.\n\n"
    "WHY IS CARY-BLAIR SUITED TO THIS? THREE PROPERTIES:\n\n"
    "ONE — IT IS SEMI-SOLID, so the specimen does not disperse and stays stable.\n\n"
    "WARNING, TWO — IT CONTAINS NO NUTRIENTS. This is deliberate: THE BACTERIUM SURVIVES BUT DOES NOT "
    "MULTIPLY. If it multiplied, THE PROPORTIONS OF ORGANISMS WOULD BE DISTORTED and accompanying flora "
    "would overgrow the pathogen.\n\n"
    "THREE — IT HAS AN ALKALINE pH (about 8.4), which is EXACTLY WHAT VIBRIO CHOLERAE LIKES — vibrio is "
    "an ALKALIPHILIC organism.\n\n"
    "AND CARY-BLAIR IS GENERAL PURPOSE: it works for SHIGELLA, SALMONELLA, CAMPYLOBACTER AND VIBRIO alike.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "WARNING, TCBS (thiosulfate-citrate-bile salt-sucrose): THIS IS THE MAIN TRAP. TCBS is a SELECTIVE "
    "CULTURE MEDIUM for vibrios, NOT A TRANSPORT MEDIUM. It is used in the laboratory to ISOLATE "
    "vibrio. AND ITS ELEGANT FEATURE: VIBRIO CHOLERAE FORMS YELLOW COLONIES (because it FERMENTS "
    "SUCROSE, acidifying the medium and turning the indicator yellow), while VIBRIO PARAHAEMOLYTICUS "
    "FORMS GREEN COLONIES (it does not ferment sucrose).\n\n"
    "TTG (taurocholate-tellurite-gelatin): also a CULTURE (enrichment) medium for vibrio, not a "
    "transport medium.\n\n"
    "'ANY OF THE THREE MAY BE USED': incorrect, because TWO OF THEM ARE CULTURE MEDIA, and using a "
    "culture medium to carry a specimen a long distance DISTORTS THE MICROBIAL COMPOSITION of the "
    "sample.",
    ["محیط کشت غنی‌کننده برای ویبریو است، نه محیط انتقالی.",
     "دام اصلی — TCBS محیط کشت انتخابی است؛ در آن ویبریوکلرا کلنی زرد می‌دهد.",
     "پاسخ صحیح — نیمه‌جامد، بدون مواد مغذی و با pH قلیایی؛ نمونه را روزها پایدار نگه می‌دارد.",
     "نادرست — دو تای آن‌ها محیط کشت‌اند و برای حمل نمونه مناسب نیستند."],
    ["An enrichment culture medium for vibrio, not a transport medium.",
     "The main trap — TCBS is a selective culture medium; on it Vibrio cholerae forms yellow colonies.",
     "Correct — semi-solid, nutrient-free and alkaline; it keeps the specimen stable for days.",
     "Incorrect — two of them are culture media and are unsuitable for transporting a specimen."],
    "**محیط انتقالی زنده نگه می‌دارد؛ محیط کشت رشد می‌دهد. کری-بلر اولی است، TCBS دومی.**",
    "A transport medium keeps alive; a culture medium grows. Cary-Blair is the first, TCBS the second.",
    CREFS)

# ============================================== CHOLERA FLUIDS: THREE ITEMS
FL_FA = CH_FA + [
    "⚠️ **رینگر لاکتات مایع انتخابی وباست، و دلیلش ترکیب آن است.**",
    "**مدفوع وبا چهار چیز از دست می‌دهد: سدیم، کلراید، پتاسیم، و بی‌کربنات.**",
    "**رینگر لاکتات هر چهار را جبران می‌کند.**",
    "**سدیم و کلراید مستقیم دارد، پتاسیم کم دارد، و لاکتات دارد.**",
    "**و لاکتات در کبد به بی‌کربنات تبدیل می‌شود، پس باز را برمی‌گرداند.**",
    "**همین جبران باز، اسیدوز متابولیک وبا را اصلاح می‌کند.**",
    "⚠️ **نرمال سالین هیچ بازی و هیچ پتاسیمی ندارد.**",
    "**پس اسیدوز را اصلاح نمی‌کند و می‌تواند اسیدوز هیپرکلرمیک هم بسازد.**",
    "**دکستروز واتر نه الکترولیت دارد و نه باز؛ فقط رقیق می‌کند.**",
    "**و سرم یک‌سوم-دوسوم مایع نگهدارنده است، نه مایع احیا.**",
]
FL_EN = CH_EN + [
    "WARNING: RINGER'S LACTATE IS THE FLUID OF CHOICE IN CHOLERA, and the reason is its composition.",
    "Cholera stool loses four things: sodium, chloride, potassium and bicarbonate.",
    "Ringer's lactate replaces all four.",
    "It contains sodium and chloride directly, a little potassium, and lactate.",
    "And the lactate is converted to bicarbonate in the liver, restoring the base.",
    "That base replacement is what corrects the metabolic acidosis of cholera.",
    "WARNING, NORMAL SALINE CONTAINS NO BASE AND NO POTASSIUM.",
    "So it does not correct the acidosis and can itself cause a hyperchloraemic acidosis.",
    "Dextrose water has neither electrolyte nor base; it merely dilutes.",
    "And one-third/two-thirds is a MAINTENANCE fluid, not a RESUSCITATION fluid.",
]

add("book:341", "recall", "easy",
    "**رینگر لاکتات: تنها مایعی که سدیم، کلراید، پتاسیم و باز را با هم جبران می‌کند.**",
    "Ringer's lactate: the only fluid that replaces sodium, chloride, potassium and base together.",
    FL_FA,
    FL_EN,
    "این سؤال یک **انتخاب مایع** را می‌سنجد، و پاسخ آن از **ترکیب مدفوع وبا** می‌آید.\n\n"
    "⚠️ **اول بدانید مدفوع وبا چه چیزی از دست می‌دهد. این کلید همه‌چیز است:**\n\n"
    "مدفوع وبا **ایزوتونیک** است و در هر لیتر تقریباً دارد: **سدیم ۱۳۰**، **کلراید ۱۰۰**، "
    "**پتاسیم ۲۰**، و **بی‌کربنات ۴۴** میلی‌اکی‌والان.\n\n"
    "**دو چیز را از این اعداد بگیرید:**\n\n"
    "**یک — از دست دادن پتاسیم چشمگیر است** (۲۰ میلی‌اکی‌والان در لیتر، در حالی که بیمار "
    "ممکن است **لیترها** از دست بدهد). این **هیپوکالمی** می‌سازد که **کرامپ عضلانی و آریتمی** "
    "می‌دهد.\n\n"
    "⚠️ **دو — از دست دادن بی‌کربنات بسیار زیاد است** (۴۴ در لیتر). این **اسیدوز متابولیک** "
    "می‌سازد، که یکی از خطرناک‌ترین جنبه‌های وباست.\n\n"
    "**پس مایع ایده‌آل باید هر چهار را جبران کند: سدیم، کلراید، پتاسیم، و باز.**\n\n"
    "**و رینگر لاکتات دقیقاً همین است:**\n\n"
    "**سدیم ۱۳۰** ✔ (تقریباً برابر با مدفوع وبا) · **کلراید ۱۰۹** ✔ · **پتاسیم ۴** ✔ (کم "
    "ولی موجود) · **لاکتات ۲۸** ✔ — و **لاکتات در کبد به بی‌کربنات تبدیل می‌شود**، پس **باز "
    "از دست رفته را برمی‌گرداند** و **اسیدوز را اصلاح می‌کند**.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "⚠️ **نرمال سالین:** **دو ایراد جدی.** یک: **هیچ بازی ندارد**، پس **اسیدوز متابولیک را "
    "اصلاح نمی‌کند**. دو: **کلراید آن ۱۵۴ است** — بسیار بیشتر از پلاسما — پس حجم زیاد آن "
    "می‌تواند **اسیدوز متابولیک هیپرکلرمیک** بسازد، یعنی **اسیدوز را بدتر کند**. و **پتاسیم "
    "هم ندارد**. (در نبود رینگر لاکتات، نرمال سالین قابل استفاده است — ولی باید پتاسیم و "
    "باز جداگانه اضافه شود.)\n\n"
    "**سرم یک‌سوم-دوسوم:** این یک **مایع نگهدارنده** است، نه مایع **احیا**. سدیم آن کم است "
    "(حدود ۵۱) و بخش عمده‌ی آن **دکستروز** است. برای جبران سریع حجم در شوک **کاملاً نامناسب** "
    "است.\n\n"
    "**دکستروز واتر ۵ درصد:** **بدترین گزینه.** **هیچ الکترولیتی ندارد.** پس از متابولیزه "
    "شدن قند، عملاً **آب خالص** می‌ماند که **در همه‌ی فضاها پخش می‌شود** و **فقط حدود یک‌دوازدهم "
    "آن در فضای داخل عروقی می‌ماند**. برای شوک هیپوولمیک **بی‌فایده** است، و می‌تواند "
    "**هیپوناترمی** هم بسازد.\n\n"
    "**و نکته‌ی WHO: در نبود رینگر لاکتات، «محلول اسهالی WHO» یا نرمال سالین با افزودن "
    "پتاسیم و باز جایگزین‌های قابل قبول‌اند.**",
    "This question tests A FLUID CHOICE, and its answer comes from THE COMPOSITION OF CHOLERA STOOL.\n\n"
    "WARNING, FIRST KNOW WHAT CHOLERA STOOL LOSES. This is the key to everything:\n\n"
    "Cholera stool is ISOTONIC and contains roughly, per litre: SODIUM 130, CHLORIDE 100, POTASSIUM 20 "
    "and BICARBONATE 44 milliequivalents.\n\n"
    "TAKE TWO THINGS FROM THOSE NUMBERS:\n\n"
    "ONE — POTASSIUM LOSS IS SUBSTANTIAL (20 mEq per litre, and the patient may lose LITRES). This "
    "produces HYPOKALAEMIA, causing MUSCLE CRAMPS AND ARRHYTHMIA.\n\n"
    "WARNING, TWO — BICARBONATE LOSS IS VERY LARGE (44 per litre). This produces METABOLIC ACIDOSIS, "
    "one of the most dangerous aspects of cholera.\n\n"
    "SO THE IDEAL FLUID MUST REPLACE ALL FOUR: sodium, chloride, potassium and base.\n\n"
    "AND RINGER'S LACTATE IS EXACTLY THAT:\n\n"
    "SODIUM 130 (almost identical to cholera stool), CHLORIDE 109, POTASSIUM 4 (a little, but present), "
    "and LACTATE 28 — and THE LACTATE IS CONVERTED TO BICARBONATE IN THE LIVER, so it RESTORES THE LOST "
    "BASE and CORRECTS THE ACIDOSIS.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "WARNING, NORMAL SALINE: TWO SERIOUS FAULTS. One: IT CONTAINS NO BASE, so it DOES NOT CORRECT THE "
    "METABOLIC ACIDOSIS. Two: ITS CHLORIDE IS 154 — far above plasma — so large volumes can produce a "
    "HYPERCHLORAEMIC METABOLIC ACIDOSIS, that is, MAKE THE ACIDOSIS WORSE. And IT CONTAINS NO POTASSIUM "
    "EITHER. (In the absence of Ringer's lactate, normal saline can be used — but potassium and base "
    "must be added separately.)\n\n"
    "ONE-THIRD/TWO-THIRDS SOLUTION: a MAINTENANCE fluid, not a RESUSCITATION fluid. Its sodium is low "
    "(about 51) and most of it is DEXTROSE. It is ENTIRELY UNSUITABLE for rapid volume replacement in "
    "shock.\n\n"
    "5% DEXTROSE IN WATER: THE WORST OPTION. IT CONTAINS NO ELECTROLYTES AT ALL. Once the sugar is "
    "metabolised, effectively PURE WATER remains, which DISTRIBUTES THROUGH ALL COMPARTMENTS with only "
    "about ONE TWELFTH staying intravascular. It is USELESS in hypovolaemic shock and can cause "
    "HYPONATRAEMIA.\n\n"
    "AND A WHO POINT: in the absence of Ringer's lactate, 'WHO Diarrhoea Treatment Solution' or normal "
    "saline with added potassium and base are acceptable alternatives.",
    ["پاسخ صحیح — سدیم، کلراید، پتاسیم و لاکتات (که به بی‌کربنات تبدیل می‌شود) را با هم دارد.",
     "هیچ بازی و هیچ پتاسیمی ندارد، و کلراید بالای آن می‌تواند اسیدوز هیپرکلرمیک بسازد.",
     "مایع نگهدارنده است نه احیا؛ سدیم کم و دکستروز زیاد دارد.",
     "بدترین گزینه — هیچ الکترولیتی ندارد و فقط یک‌دوازدهم آن داخل عروق می‌ماند."],
    ["Correct — it contains sodium, chloride, potassium and lactate (converted to bicarbonate) together.",
     "Contains no base and no potassium, and its high chloride can cause hyperchloraemic acidosis.",
     "A maintenance fluid rather than a resuscitation fluid; low sodium and mostly dextrose.",
     "The worst option — no electrolytes at all, and only one twelfth stays intravascular."],
    "**لاکتات در کبد به بی‌کربنات تبدیل می‌شود — و همین اسیدوز وبا را اصلاح می‌کند.**",
    "Lactate is converted to bicarbonate in the liver — and that is what corrects cholera's acidosis.",
    CREFS)

add("book:342", "vignette", "easy",
    "**در وبای شدید، مهم‌ترین اقدام مایع است — نه آنتی‌بیوتیک و نه آزمایش.**",
    "In severe cholera the priority is FLUID — not an antibiotic and not more tests.",
    FL_FA + [
        "**این بیمار با دهیدراتاسیون شدید بستری شده، پس فوریت با مایع است.**",
        "**در وبای شدید، بیمار می‌تواند لیترها در ساعت از دست بدهد.**",
        "⚠️ **و علت مرگ، شوک هیپوولمیک است، نه خودِ باکتری.**",
        "**پس هر دقیقه تأخیر در مایع‌درمانی، خطر مرگ را بالا می‌برد.**",
        "**آنتی‌بیوتیک کمکی است: مدت بیماری و حجم مدفوع را کم می‌کند.**",
        "**ولی جان بیمار را مایع نجات می‌دهد، نه آنتی‌بیوتیک.**",
        "**و تکمیل آزمایشات، وقتی بیمار در شوک است، تأخیر خطرناک است.**",
        "⚠️ **لوپرامید هم در وبا جایی ندارد و می‌تواند مایع را در روده حبس کند.**",
    ],
    FL_EN + [
        "This patient is admitted with severe dehydration, so the priority is fluid.",
        "In severe cholera a patient can lose litres per hour.",
        "WARNING, AND WHAT KILLS IS HYPOVOLAEMIC SHOCK, not the bacterium itself.",
        "So every minute of delay in rehydration raises the risk of death.",
        "An antibiotic is adjunctive: it shortens the illness and reduces stool volume.",
        "But it is FLUID that saves the patient's life, not the antibiotic.",
        "And completing investigations while the patient is in shock is a dangerous delay.",
        "WARNING, LOPERAMIDE ALSO HAS NO PLACE and can sequester fluid inside the bowel.",
    ],
    "این سؤال یک **اولویت‌بندی** را می‌سنجد، و پاسخ آن ساده ولی حیاتی است.\n\n"
    "**بیمار: آقای ۴۵ ساله با اسهال آبکی آب برنجی، به علت دهیدراتاسیون شدید در اورژانس "
    "بستری شده. مهم‌ترین اقدام کدام است؟**\n\n"
    "⚠️ **پاسخ: مایع‌درمانی با سرم رینگر.**\n\n"
    "**چرا مایع، مهم‌ترین اقدام است؟ یک جمله همه‌چیز را می‌گوید:**\n\n"
    "**در وبا، علت مرگ شوک هیپوولمیک است، نه خودِ باکتری.**\n\n"
    "**اعداد این را روشن می‌کنند:** وبای شدید درمان‌نشده **تا ۵۰ درصد** مبتلایان را می‌کشد. "
    "**با مایع‌درمانی کافی و به‌موقع، مرگ‌ومیر به زیر ۱ درصد می‌رسد.** ⚠️ **این کاهش تقریباً "
    "کاملاً از مایع می‌آید، نه از آنتی‌بیوتیک.**\n\n"
    "**و فوریت واقعی است:** بیمار وبای شدید می‌تواند **لیترها در ساعت** مایع از دست بدهد. "
    "**هر دقیقه تأخیر**، خطر ایست قلبی از هیپوولمی و اختلال الکترولیت را بالا می‌برد.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**سفتریاکسون وریدی:** ⚠️ **دو نکته.** یک: **آنتی‌بیوتیک در وبا کمکی است، نه اصلی** — "
    "مدت بیماری را حدود یک روز و حجم مدفوع را حدود نصف کم می‌کند، ولی **جان بیمار را نجات "
    "نمی‌دهد**. دو: **سفتریاکسون داروی انتخابی وبا نیست** — داروهای درست، **داکسی‌سیکلین "
    "تک‌دوز**، **آزیترومایسین تک‌دوز** یا **سیپروفلوکساسین** هستند.\n\n"
    "**لوپرامید خوراکی:** ⚠️ **در وبا جایی ندارد و می‌تواند مضر باشد.** کند کردن روده در "
    "بیماری که **لیترها مایع در لومن روده دارد**، آن مایع را **در روده حبس می‌کند** — "
    "بیمار همچنان حجم از دست می‌دهد ولی **ما دیگر آن را نمی‌بینیم و نمی‌توانیم اندازه بگیریم**. "
    "این **از دست دادن پنهان مایع** خطرناک است.\n\n"
    "**تکمیل آزمایشات:** بیمار **در دهیدراتاسیون شدید** است. **تشخیص از نظر بالینی روشن است** "
    "(اسهال آب برنجی + دهیدراتاسیون شدید). **منتظر ماندن برای آزمایش، تأخیر کشنده است.** "
    "آزمایش‌ها **موازی** با احیا انجام می‌شوند، نه **پیش از** آن.\n\n"
    "**قاعده‌ی طلایی: در وبا، اول مایع بده، بعد فکر کن.**",
    "This question tests A PRIORITISATION, and its answer is simple but vital.\n\n"
    "THE PATIENT: a 45-year-old man with rice-water diarrhoea, admitted to the emergency department "
    "with severe dehydration. What is the most important step?\n\n"
    "WARNING, THE ANSWER: FLUID RESUSCITATION WITH RINGER'S.\n\n"
    "WHY IS FLUID THE MOST IMPORTANT STEP? One sentence says everything:\n\n"
    "IN CHOLERA, WHAT KILLS IS HYPOVOLAEMIC SHOCK, NOT THE BACTERIUM.\n\n"
    "THE NUMBERS MAKE IT CLEAR: untreated severe cholera kills UP TO 50% of those affected. WITH "
    "ADEQUATE AND TIMELY REHYDRATION, MORTALITY FALLS BELOW 1%. WARNING, THAT REDUCTION COMES ALMOST "
    "ENTIRELY FROM THE FLUID, NOT FROM THE ANTIBIOTIC.\n\n"
    "AND THE URGENCY IS REAL: a patient with severe cholera can lose LITRES PER HOUR. EVERY MINUTE OF "
    "DELAY raises the risk of cardiac arrest from hypovolaemia and electrolyte disturbance.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "INTRAVENOUS CEFTRIAXONE: WARNING, TWO POINTS. One: ANTIBIOTICS IN CHOLERA ARE ADJUNCTIVE, NOT "
    "PRIMARY — they shorten the illness by about a day and halve the stool volume, but they DO NOT SAVE "
    "THE PATIENT'S LIFE. Two: CEFTRIAXONE IS NOT THE DRUG OF CHOICE FOR CHOLERA — the correct drugs are "
    "SINGLE-DOSE DOXYCYCLINE, SINGLE-DOSE AZITHROMYCIN or CIPROFLOXACIN.\n\n"
    "ORAL LOPERAMIDE: WARNING, IT HAS NO PLACE IN CHOLERA AND CAN BE HARMFUL. Slowing the bowel in a "
    "patient with LITRES OF FLUID IN THE BOWEL LUMEN SEQUESTERS THAT FLUID INSIDE THE BOWEL — the "
    "patient still loses volume but WE CAN NO LONGER SEE OR MEASURE IT. That CONCEALED FLUID LOSS is "
    "dangerous.\n\n"
    "COMPLETING INVESTIGATIONS: the patient is IN SEVERE DEHYDRATION. THE DIAGNOSIS IS CLINICALLY CLEAR "
    "(rice-water diarrhoea plus severe dehydration). WAITING FOR TESTS IS A LETHAL DELAY. "
    "Investigations are done IN PARALLEL with resuscitation, not BEFORE it.\n\n"
    "THE GOLDEN RULE: IN CHOLERA, GIVE FLUID FIRST AND THINK AFTERWARDS.",
    ["آنتی‌بیوتیک در وبا کمکی است نه اصلی، و سفتریاکسون هم داروی انتخابی وبا نیست.",
     "در وبا جایی ندارد و مایع را در روده حبس می‌کند؛ از دست دادن پنهان مایع خطرناک است.",
     "تشخیص بالینی روشن است؛ منتظر ماندن برای آزمایش در شوک، تأخیر کشنده است.",
     "پاسخ صحیح — علت مرگ در وبا شوک هیپوولمیک است، و مایع مرگ‌ومیر را از ۵۰٪ به زیر ۱٪ می‌رساند."],
    ["Antibiotics in cholera are adjunctive, and ceftriaxone is not the drug of choice anyway.",
     "It has no place and sequesters fluid in the bowel; concealed fluid loss is dangerous.",
     "The diagnosis is clinically clear; waiting for tests during shock is a lethal delay.",
     "Correct — what kills in cholera is hypovolaemic shock, and fluid cuts mortality from 50% to under 1%."],
    "**مایع مرگ‌ومیر وبا را از ۵۰ درصد به زیر ۱ درصد می‌رساند — آنتی‌بیوتیک نه.**",
    "Fluid cuts cholera mortality from 50% to under 1% — the antibiotic does not.",
    CREFS)

add("book:343", "vignette", "easy",
    "**سرم رینگر لاکتات: مناسب‌ترین برای جبران حجم در وبا.**",
    "Ringer's LACTATE: the most appropriate fluid for volume replacement in cholera.",
    FL_FA + [
        "**این سؤال میان رینگر ساده و رینگر لاکتات تمایز می‌گذارد.**",
        "**و همین تمایز، نکته‌ی کلیدی آن است.**",
        "⚠️ **رینگر ساده لاکتات ندارد، پس باز از دست رفته را برنمی‌گرداند.**",
        "**در حالی که اسیدوز متابولیک یکی از خطرناک‌ترین جنبه‌های وباست.**",
        "**رینگر لاکتات همان رینگر است، به‌علاوه‌ی لاکتات.**",
        "**و لاکتات در کبد به بی‌کربنات تبدیل می‌شود.**",
        "**پس فقط رینگر لاکتات اسیدوز را اصلاح می‌کند.**",
        "**و آلبومین در جبران حجم اسهالی جایی ندارد.**",
    ],
    FL_EN + [
        "This question distinguishes between plain Ringer's and Ringer's LACTATE.",
        "And that distinction is its key point.",
        "WARNING, PLAIN RINGER'S CONTAINS NO LACTATE, so it does not restore the lost base.",
        "Whereas metabolic acidosis is one of the most dangerous aspects of cholera.",
        "Ringer's lactate is the same solution PLUS lactate.",
        "And lactate is converted to bicarbonate in the liver.",
        "So only Ringer's LACTATE corrects the acidosis.",
        "And albumin has no place in replacing diarrhoeal losses.",
    ],
    "این سؤال یک تمایز **ظریف ولی مهم** را می‌سنجد: **رینگر ساده در برابر رینگر لاکتات**.\n\n"
    "**بیمار: خانم جوان با تابلوی اسهال حاد آبکی. خواب‌آلوده است و دهیدراتاسیون شدید و افت "
    "فشار خون دارد. حجم اسهال زیاد و به رنگ سفید-خاکستری است.**\n\n"
    "**تشخیص روشن است: وبای شدید.** (اسهال آب برنجی + دهیدراتاسیون شدید + خواب‌آلودگی که "
    "نشانه‌ی دهیدراتاسیون **بیش از ۱۰ درصد** است.)\n\n"
    "⚠️ **حالا انتخاب مایع، و کلید در تفاوت دو گزینه‌ی مشابه است:**\n\n"
    "**سرم رینگر (ساده):** حاوی **سدیم، کلراید، پتاسیم و کلسیم** است. **ولی لاکتات ندارد.**\n\n"
    "**سرم رینگر لاکتات:** همان ترکیب، **به‌علاوه‌ی لاکتات**.\n\n"
    "**و همین لاکتات، تفاوت را می‌سازد.**\n\n"
    "**چرا؟** چون مدفوع وبا مقدار زیادی **بی‌کربنات** از دست می‌دهد (حدود **۴۴ میلی‌اکی‌والان "
    "در لیتر**) و بیمار دچار **اسیدوز متابولیک** می‌شود. **اسیدوز یکی از خطرناک‌ترین جنبه‌های "
    "وباست** و می‌تواند به آریتمی و ایست قلبی برسد.\n\n"
    "⚠️ **لاکتات در کبد متابولیزه می‌شود و به بی‌کربنات تبدیل می‌گردد.** پس رینگر لاکتات "
    "**بازِ از دست رفته را برمی‌گرداند** و **اسیدوز را اصلاح می‌کند**. رینگر ساده این کار را "
    "**نمی‌کند**.\n\n"
    "**پس پاسخ: سرم رینگر لاکتات.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**آلبومین:** یک **کلوئید** و فرآورده‌ی خونی گران‌قیمت است. جای آن در شرایط خاصی مثل "
    "**سیروز با پاراسنتز حجیم** یا **پریتونیت باکتریال خودبه‌خودی** است. در **جبران حجم "
    "اسهالی**، هیچ برتری بر کریستالوئید ندارد و **بسیار گران‌تر** است.\n\n"
    "**سرم نرمال سالین:** **بازی ندارد** پس اسیدوز را اصلاح نمی‌کند، **پتاسیم هم ندارد**، و "
    "کلراید بالای آن می‌تواند **اسیدوز هیپرکلرمیک** بسازد. (در نبود رینگر لاکتات قابل استفاده "
    "است، ولی **مناسب‌ترین** نیست.)\n\n"
    "⚠️ **سرم رینگر (ساده):** **این نزدیک‌ترین رقیب و دام اصلی سؤال است.** ترکیب "
    "الکترولیتی خوبی دارد، **ولی لاکتات ندارد** — پس **اسیدوز را اصلاح نمی‌کند**. و در وبای "
    "شدید، اصلاح اسیدوز **بخشی جدایی‌ناپذیر از درمان** است.\n\n"
    "**درس: نام کامل مایع را بخوانید. «رینگر» و «رینگر لاکتات» دو چیز متفاوت‌اند.**",
    "This question tests A SUBTLE BUT IMPORTANT DISTINCTION: plain Ringer's versus Ringer's LACTATE.\n\n"
    "THE PATIENT: a young woman with acute watery diarrhoea. She is DROWSY with severe dehydration and "
    "hypotension. The stool volume is large and WHITE-GREY in colour.\n\n"
    "THE DIAGNOSIS IS CLEAR: SEVERE CHOLERA. (Rice-water diarrhoea plus severe dehydration plus "
    "drowsiness, which indicates dehydration OVER 10%.)\n\n"
    "WARNING, NOW THE FLUID CHOICE, and the key lies in the difference between two similar options:\n\n"
    "PLAIN RINGER'S: contains SODIUM, CHLORIDE, POTASSIUM AND CALCIUM. BUT NO LACTATE.\n\n"
    "RINGER'S LACTATE: the same composition PLUS LACTATE.\n\n"
    "AND THAT LACTATE MAKES THE DIFFERENCE.\n\n"
    "WHY? Because cholera stool loses a large amount of BICARBONATE (about 44 mEq PER LITRE) and the "
    "patient develops METABOLIC ACIDOSIS. ACIDOSIS IS ONE OF THE MOST DANGEROUS ASPECTS OF CHOLERA and "
    "can progress to arrhythmia and cardiac arrest.\n\n"
    "WARNING, LACTATE IS METABOLISED IN THE LIVER AND CONVERTED TO BICARBONATE. So Ringer's lactate "
    "RESTORES THE LOST BASE and CORRECTS THE ACIDOSIS. Plain Ringer's DOES NOT.\n\n"
    "SO THE ANSWER: RINGER'S LACTATE.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "ALBUMIN: a COLLOID and an expensive blood product. Its place is in specific settings such as "
    "CIRRHOSIS WITH LARGE-VOLUME PARACENTESIS or SPONTANEOUS BACTERIAL PERITONITIS. In replacing "
    "DIARRHOEAL LOSSES it has no advantage over crystalloid and is FAR MORE EXPENSIVE.\n\n"
    "NORMAL SALINE: IT HAS NO BASE so it does not correct the acidosis, IT HAS NO POTASSIUM, and its "
    "high chloride can create a HYPERCHLORAEMIC ACIDOSIS. (Usable in the absence of Ringer's lactate, "
    "but not THE MOST APPROPRIATE.)\n\n"
    "WARNING, PLAIN RINGER'S: THIS IS THE CLOSEST COMPETITOR AND THE MAIN TRAP. It has a good "
    "electrolyte composition, BUT NO LACTATE — so IT DOES NOT CORRECT THE ACIDOSIS. And in severe "
    "cholera, correcting the acidosis is AN INSEPARABLE PART OF TREATMENT.\n\n"
    "THE LESSON: READ THE FULL NAME OF THE FLUID. 'RINGER'S' AND 'RINGER'S LACTATE' ARE TWO DIFFERENT "
    "THINGS.",
    ["کلوئید گران‌قیمتی است و در جبران حجم اسهالی هیچ برتری بر کریستالوئید ندارد.",
     "بازی ندارد پس اسیدوز را اصلاح نمی‌کند، و کلراید بالای آن اسیدوز هیپرکلرمیک می‌سازد.",
     "دام اصلی — رینگر ساده لاکتات ندارد، پس بازِ از دست رفته را برنمی‌گرداند.",
     "پاسخ صحیح — لاکتات در کبد به بی‌کربنات تبدیل می‌شود و اسیدوز وبا را اصلاح می‌کند."],
    ["An expensive colloid with no advantage over crystalloid in replacing diarrhoeal losses.",
     "No base so it does not correct the acidosis, and its high chloride causes hyperchloraemic acidosis.",
     "The main trap — plain Ringer's has no lactate, so it does not restore the lost base.",
     "Correct — lactate is converted to bicarbonate in the liver and corrects cholera's acidosis."],
    "**«رینگر» و «رینگر لاکتات» دو چیز متفاوت‌اند — لاکتات همان بازِ از دست رفته است.**",
    "'Ringer's' and 'Ringer's lactate' are different — the lactate is the lost base.",
    CREFS)

# ============================================== CHOLERA ANTIBIOTICS: SIX ITEMS
AB_FA = CH_FA + [
    "⚠️ **آنتی‌بیوتیک در وبا کمکی است، و انتخاب آن به بیمار بستگی دارد.**",
    "**در بزرگ‌سال غیرباردار، داکسی‌سیکلین تک‌دوز ۳۰۰ میلی‌گرم انتخاب اول است.**",
    "**و آزیترومایسین یک گرم تک‌دوز، جایگزین اصلی آن.**",
    "**سیپروفلوکساسین هم گزینه‌ی دیگری است.**",
    "**در بارداری و کودکان، آموزش سنتی از داکسی‌سیکلین پرهیز می‌کند.**",
    "**چون تتراسایکلین‌ها روی دندان و استخوان جنین اثر می‌گذارند.**",
    "**پس در بارداری، آزیترومایسین انتخاب استاندارد این کتاب است.**",
    "⚠️ **ولی راهنمای امروز WHO این را تعدیل کرده است.**",
    "**بازنگری سیستماتیک نشان داد پروفایل ایمنی داکسی‌سیکلین با تتراسایکلین یکی نیست.**",
    "**پس GTFCC امروز داکسی‌سیکلین تک‌دوز را برای همه، از جمله باردار، توصیه می‌کند.**",
    "**و آزیترومایسین و سیپروفلوکساسین را جایگزین در مقاومت می‌داند.**",
    "**هر دو را بدانید: در امتحان این دوره آزیترومایسین، و در راهنمای امروز داکسی‌سیکلین.**",
]
AB_EN = CH_EN + [
    "WARNING: THE ANTIBIOTIC IN CHOLERA IS ADJUNCTIVE, and its choice depends on the patient.",
    "In a non-pregnant adult, single-dose DOXYCYCLINE 300 mg is the first choice.",
    "And single-dose AZITHROMYCIN 1 g is its main alternative.",
    "Ciprofloxacin is another option.",
    "In pregnancy and childhood, traditional teaching avoids doxycycline.",
    "Because tetracyclines affect fetal teeth and bone.",
    "So in pregnancy, azithromycin is this book's standard choice.",
    "WARNING, BUT TODAY'S WHO GUIDANCE HAS MODIFIED THIS.",
    "A systematic review found that doxycycline's safety profile differs from tetracycline's.",
    "So the GTFCC today recommends single-dose doxycycline for ALL patients, INCLUDING pregnant women.",
    "With azithromycin and ciprofloxacin as alternatives where there is resistance.",
    "Know both: azithromycin for this era's exam, doxycycline in today's guidance.",
]

add("book:344", "vignette", "medium",
    "**وبا در بارداری: رینگر لاکتات به‌علاوه‌ی ماکرولید — و مایع همچنان مهم‌تر است.**",
    "Cholera in pregnancy: Ringer's lactate plus a macrolide — and the fluid still matters more.",
    AB_FA,
    AB_EN,
    "این سؤال **دو تصمیم** را هم‌زمان می‌خواهد: **کدام مایع، و کدام آنتی‌بیوتیک.**\n\n"
    "**بیمار: خانم حامله با اسهال شدید آبکی. با توجه به علائم بالینی و شواهد اپیدمیولوژیک "
    "احتمال وبا مطرح است. علاوه بر تجویز KCl، چه درمانی انتخاب می‌شود؟**\n\n"
    "**تصمیم اول — مایع: سرم رینگر لاکتات.**\n\n"
    "چون **هر چهار چیزی را که مدفوع وبا از دست می‌دهد جبران می‌کند**: سدیم، کلراید، پتاسیم، "
    "و — از راه لاکتات — **باز**. و **اصلاح اسیدوز** در وبا حیاتی است.\n\n"
    "**(و توجه کنید که سؤال خودش KCl را ذکر کرده — یعنی جبران پتاسیم اضافی، که در وبای شدید "
    "با از دست دادن زیاد پتاسیم منطقی است.)**\n\n"
    "**تصمیم دوم — آنتی‌بیوتیک در بارداری.**\n\n"
    "⚠️ **فیلتر بارداری را اعمال کنید:**\n\n"
    "**داکسی‌سیکلین** — انتخاب اول در بزرگ‌سال غیرباردار، ولی **آموزش سنتی در بارداری از آن "
    "پرهیز می‌کند** (اثر تتراسایکلین‌ها بر دندان و استخوان جنین).\n\n"
    "**سیپروفلوکساسین** — در بارداری پرهیز می‌شود (نگرانی از غضروف).\n\n"
    "**ماکرولیدها (اریترومایسین و آزیترومایسین)** — **در بارداری بی‌خطرند** و روی ویبریوکلرا "
    "**مؤثر**.\n\n"
    "**پس گزینه‌ی درست: سرم رینگرالکتات + اریترومایسین.**\n\n"
    "⚠️ **و یک نکته‌ی به‌روز که باید بدانید: راهنمای امروز WHO این را تعدیل کرده است.** "
    "**بازنگری سیستماتیک نشان داد که پروفایل ایمنی داکسی‌سیکلین با تتراسایکلین یکسان نیست**، "
    "و **GTFCC امروز داکسی‌سیکلین تک‌دوز ۳۰۰ میلی‌گرم را برای همه‌ی بیماران — از جمله زنان "
    "باردار — توصیه می‌کند**، با آزیترومایسین و سیپروفلوکساسین به‌عنوان جایگزین در مقاومت. "
    "**پس هر دو را بدانید: در امتحان این دوره ماکرولید، و در راهنمای امروز داکسی‌سیکلین.**\n\n"
    "**و مهم‌تر از انتخاب آنتی‌بیوتیک: در وبا مایع جان می‌نجات دهد، نه آنتی‌بیوتیک.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**سرم قندی نمکی + سفتریاکسون:** **سرم قندی نمکی برای احیای حجم در وبا نامناسب است** "
    "(سدیم کم، بخش عمده دکستروز). و **سفتریاکسون داروی انتخابی وبا نیست**.\n\n"
    "**سرم ۲/۳-۱/۳ + آمپی‌سیلین:** **مایع نگهدارنده** است نه احیا. و **آمپی‌سیلین در وبا "
    "توصیه نمی‌شود**.\n\n"
    "**سرم نرمال سالین + سیپروفلوکساسین:** نرمال سالین **باز و پتاسیم ندارد** (کمتر مناسب "
    "از رینگر لاکتات)، و **سیپروفلوکساسین در بارداری پرهیز می‌شود**.",
    "This question requires TWO DECISIONS at once: WHICH FLUID, and WHICH ANTIBIOTIC.\n\n"
    "THE PATIENT: a pregnant woman with severe watery diarrhoea. Given the clinical features and "
    "epidemiological evidence, cholera is suspected. Besides giving KCl, what treatment is chosen?\n\n"
    "FIRST DECISION — THE FLUID: RINGER'S LACTATE.\n\n"
    "Because it replaces ALL FOUR THINGS CHOLERA STOOL LOSES: sodium, chloride, potassium and — through "
    "the lactate — BASE. And CORRECTING THE ACIDOSIS is vital in cholera.\n\n"
    "(And note that the question itself mentions KCl — additional potassium replacement, which is "
    "sensible in severe cholera with heavy potassium loss.)\n\n"
    "SECOND DECISION — THE ANTIBIOTIC IN PREGNANCY.\n\n"
    "WARNING, APPLY THE PREGNANCY FILTER:\n\n"
    "DOXYCYCLINE — the first choice in a non-pregnant adult, but TRADITIONAL TEACHING AVOIDS IT IN "
    "PREGNANCY (tetracycline effects on fetal teeth and bone).\n\n"
    "CIPROFLOXACIN — avoided in pregnancy (cartilage concerns).\n\n"
    "MACROLIDES (erythromycin and azithromycin) — SAFE IN PREGNANCY and EFFECTIVE against Vibrio "
    "cholerae.\n\n"
    "SO THE CORRECT OPTION: RINGER'S LACTATE PLUS ERYTHROMYCIN.\n\n"
    "WARNING, AND AN UP-TO-DATE POINT YOU MUST KNOW: TODAY'S WHO GUIDANCE HAS MODIFIED THIS. A "
    "SYSTEMATIC REVIEW FOUND THAT DOXYCYCLINE'S SAFETY PROFILE IS NOT THE SAME AS TETRACYCLINE'S, and "
    "THE GTFCC TODAY RECOMMENDS SINGLE-DOSE DOXYCYCLINE 300 mg FOR ALL PATIENTS — INCLUDING PREGNANT "
    "WOMEN — with azithromycin and ciprofloxacin as alternatives where there is resistance. SO KNOW "
    "BOTH: a macrolide for this era's exam, and doxycycline in today's guidance.\n\n"
    "AND MORE IMPORTANT THAN THE ANTIBIOTIC CHOICE: IN CHOLERA IT IS FLUID THAT SAVES LIFE.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "DEXTROSE-SALINE PLUS CEFTRIAXONE: DEXTROSE-SALINE IS UNSUITABLE FOR VOLUME RESUSCITATION IN "
    "CHOLERA (low sodium, mostly dextrose). And CEFTRIAXONE IS NOT THE DRUG OF CHOICE.\n\n"
    "ONE-THIRD/TWO-THIRDS PLUS AMPICILLIN: a MAINTENANCE fluid, not a resuscitation fluid. And "
    "AMPICILLIN IS NOT RECOMMENDED in cholera.\n\n"
    "NORMAL SALINE PLUS CIPROFLOXACIN: normal saline has NO BASE AND NO POTASSIUM (less suitable than "
    "Ringer's lactate), and CIPROFLOXACIN IS AVOIDED IN PREGNANCY.",
    ["سرم قندی نمکی برای احیای حجم نامناسب است، و سفتریاکسون داروی انتخابی وبا نیست.",
     "مایع نگهدارنده است نه احیا، و آمپی‌سیلین در وبا توصیه نمی‌شود.",
     "نرمال سالین باز و پتاسیم ندارد، و سیپروفلوکساسین در بارداری پرهیز می‌شود.",
     "پاسخ صحیح — رینگر لاکتات هر چهار را جبران می‌کند، و ماکرولید در بارداری بی‌خطر است."],
    ["Dextrose-saline is unsuitable for resuscitation, and ceftriaxone is not the drug of choice.",
     "A maintenance fluid rather than a resuscitation fluid, and ampicillin is not recommended.",
     "Normal saline has no base or potassium, and ciprofloxacin is avoided in pregnancy.",
     "Correct — Ringer's lactate replaces all four losses, and a macrolide is safe in pregnancy."],
    "**در بارداری: رینگر لاکتات + ماکرولید. و مایع همیشه مهم‌تر از آنتی‌بیوتیک است.**",
    "In pregnancy: Ringer's lactate plus a macrolide. And fluid always matters more than the antibiotic.",
    CREFS)

add("book:345", "vignette", "easy",
    "**وبا در ماه آخر بارداری: آزیترومایسین — تک‌دوز، بی‌خطر و مؤثر.**",
    "Cholera in the last month of pregnancy: AZITHROMYCIN — single dose, safe and effective.",
    AB_FA,
    AB_EN,
    "این سؤال همان قاعده‌ی بارداری را می‌سنجد، ولی این بار **مستقیم روی آنتی‌بیوتیک تمرکز "
    "کرده**.\n\n"
    "**بیمار: خانمی در ماه آخر حاملگی، مبتلا به گاستروآنتریت ناشی از ویبریوکلرا. علاوه بر "
    "مایع‌درمانی، کدام آنتی‌بیوتیک تجویز می‌شود؟**\n\n"
    "⚠️ **پاسخ: آزیترومایسین.**\n\n"
    "**چرا؟ سه ویژگی آن را انتخاب اول در بارداری می‌کند:**\n\n"
    "**یک — در بارداری بی‌خطر است.** آزیترومایسین یک ماکرولید با پروفایل ایمنی خوب در همه‌ی "
    "سه‌ماهه‌هاست.\n\n"
    "**دو — روی ویبریوکلرا مؤثر است.** و **مقاومت به آن در بیشتر مناطق کمتر از یک درصد** "
    "است — آزیترومایسین را «آخرین خط آنتی‌بیوتیکی که تقریباً همه‌ی سویه‌های ویبریو به آن "
    "حساس‌اند» توصیف کرده‌اند.\n\n"
    "⚠️ **سه — تک‌دوز است: یک گرم خوراکی، یک بار.** و این در **طغیان** اهمیت عملی زیادی "
    "دارد: **رعایت درمان تضمین می‌شود** و می‌توان دارو را زیر نظر مستقیم داد.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**سیپروفلوکساسین:** روی ویبریوکلرا **مؤثر است**، ولی **در بارداری پرهیز می‌شود** "
    "به‌دلیل نگرانی از **آسیب غضروف** در مطالعات حیوانی.\n\n"
    "⚠️ **داکسی‌سیکلین:** **این نکته‌ی ظریف سؤال است.** داکسی‌سیکلین **انتخاب اول وبا در "
    "بزرگ‌سال غیرباردار** است (۳۰۰ میلی‌گرم تک‌دوز). ولی **آموزش سنتی در بارداری از آن پرهیز "
    "می‌کند**، چون تتراسایکلین‌ها **روی دندان و استخوان جنین** اثر می‌گذارند — و این بیمار "
    "در **ماه آخر** است، یعنی زمانی که کلسیفیکاسیون دندان‌های شیری در جریان است.\n\n"
    "**ولی این راهنما جابه‌جا شده است، و باید بدانید:** ⚠️ **بازنگری سیستماتیک نشان داد که "
    "داکسی‌سیکلین از نظر ایمنی با تتراسایکلین یکسان نیست**، و **WHO/GTFCC امروز داکسی‌سیکلین "
    "تک‌دوز را برای همه — از جمله زنان باردار — توصیه می‌کند.** پس در **بالین امروز** "
    "داکسی‌سیکلین قابل قبول است، ولی در **امتحان این دوره**، آزیترومایسین پاسخ است.\n\n"
    "**آموکسی‌سیلین:** روی ویبریوکلرا **فعالیت قابل اتکایی ندارد** و **در درمان وبا توصیه "
    "نمی‌شود**. (بی‌خطر بودن در بارداری کافی نیست اگر دارو مؤثر نباشد.)\n\n"
    "**و یادآوری همیشگی: آنتی‌بیوتیک در وبا کمکی است. مایع‌درمانی جان می‌نجات دهد.**",
    "This question tests the same pregnancy rule, but this time FOCUSED DIRECTLY ON THE ANTIBIOTIC.\n\n"
    "THE PATIENT: a woman in the last month of pregnancy with gastroenteritis due to Vibrio cholerae. "
    "Besides rehydration, which antibiotic is given?\n\n"
    "WARNING, THE ANSWER: AZITHROMYCIN.\n\n"
    "WHY? THREE PROPERTIES MAKE IT THE FIRST CHOICE IN PREGNANCY:\n\n"
    "ONE — IT IS SAFE IN PREGNANCY. Azithromycin is a macrolide with a good safety profile in all "
    "trimesters.\n\n"
    "TWO — IT IS EFFECTIVE AGAINST VIBRIO CHOLERAE. And RESISTANCE TO IT IS UNDER ONE PER CENT in most "
    "regions — azithromycin has been described as 'the last-line antibiotic to which nearly all vibrio "
    "strains remain sensitive'.\n\n"
    "WARNING, THREE — IT IS A SINGLE DOSE: one gram orally, once. And in an OUTBREAK this has great "
    "practical importance: ADHERENCE IS GUARANTEED and the dose can be given under direct observation.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "CIPROFLOXACIN: EFFECTIVE against Vibrio cholerae, but AVOIDED IN PREGNANCY because of concern "
    "about CARTILAGE DAMAGE in animal studies.\n\n"
    "WARNING, DOXYCYCLINE: THIS IS THE SUBTLE POINT OF THE QUESTION. Doxycycline is THE FIRST CHOICE "
    "FOR CHOLERA IN A NON-PREGNANT ADULT (300 mg single dose). But TRADITIONAL TEACHING AVOIDS IT IN "
    "PREGNANCY, because tetracyclines affect FETAL TEETH AND BONE — and this patient is in her LAST "
    "MONTH, when deciduous tooth calcification is under way.\n\n"
    "BUT THIS GUIDANCE HAS MOVED, AND YOU SHOULD KNOW IT: WARNING, A SYSTEMATIC REVIEW FOUND THAT "
    "DOXYCYCLINE IS NOT EQUIVALENT TO TETRACYCLINE IN SAFETY, and WHO/GTFCC TODAY RECOMMENDS "
    "SINGLE-DOSE DOXYCYCLINE FOR ALL PATIENTS — INCLUDING PREGNANT WOMEN. So on TODAY'S WARD "
    "doxycycline is acceptable, but in THIS ERA'S EXAM azithromycin is the answer.\n\n"
    "AMOXICILLIN: it has NO RELIABLE ACTIVITY against Vibrio cholerae and IS NOT RECOMMENDED for "
    "cholera. (Being safe in pregnancy is not enough if the drug does not work.)\n\n"
    "AND THE STANDING REMINDER: THE ANTIBIOTIC IN CHOLERA IS ADJUNCTIVE. IT IS THE FLUID THAT SAVES LIFE.",
    ["پاسخ صحیح — تک‌دوز، در بارداری بی‌خطر، و مقاومت به آن زیر یک درصد است.",
     "روی ویبریوکلرا مؤثر است ولی در بارداری به‌دلیل نگرانی از غضروف پرهیز می‌شود.",
     "انتخاب اول در غیرباردار است، ولی آموزش سنتی در بارداری از آن پرهیز می‌کند.",
     "روی ویبریوکلرا فعالیت قابل اتکایی ندارد؛ بی‌خطر بودن بدون اثربخشی کافی نیست."],
    ["Correct — single dose, safe in pregnancy, and resistance to it is under one per cent.",
     "Effective against Vibrio cholerae but avoided in pregnancy over cartilage concerns.",
     "The first choice in a non-pregnant patient, but traditional teaching avoids it in pregnancy.",
     "Has no reliable activity against Vibrio cholerae; safety without efficacy is not enough."],
    "**آزیترومایسین: تک‌دوز، بی‌خطر در بارداری، و مقاومت زیر یک درصد.**",
    "Azithromycin: single dose, safe in pregnancy, and under one per cent resistance.",
    CREFS)

add("book:346", "vignette", "medium",
    "**وبا در کودک ۷ ساله: آزیترومایسین — چون داکسی‌سیکلین و سیپروفلوکساسین محدودیت دارند.**",
    "Cholera in a 7-year-old: AZITHROMYCIN — because doxycycline and ciprofloxacin are restricted.",
    AB_FA + [
        "**در کودک زیر هشت سال، همان فیلترهای بارداری تقریباً تکرار می‌شوند.**",
        "**تتراسایکلین‌ها در کودک زیر هشت سال رنگ‌آمیزی دائمی دندان می‌دهند.**",
        "⚠️ **و فلوروکینولون‌ها در کودکان با احتیاط بیشتری استفاده می‌شوند.**",
        "**پس آزیترومایسین باز هم انتخاب امن و مؤثر باقی می‌ماند.**",
        "**و دوز کودکان: بیست میلی‌گرم بر کیلوگرم، حداکثر یک گرم، تک‌دوز.**",
        "**جنتامایسین هم روی ویبریوکلرا نقشی ندارد.**",
        "**چون آمینوگلیکوزیدها در لومن روده به غلظت مؤثر نمی‌رسند.**",
    ],
    AB_EN + [
        "In a child under eight, almost the same filters as in pregnancy apply.",
        "Tetracyclines cause permanent dental staining in children under eight.",
        "WARNING, AND FLUOROQUINOLONES are used with greater caution in children.",
        "So azithromycin again remains the safe and effective choice.",
        "And the paediatric dose: 20 mg/kg, maximum 1 g, as a single dose.",
        "Gentamicin has no role against Vibrio cholerae either.",
        "Because aminoglycosides do not reach effective concentrations in the bowel lumen.",
    ],
    "این سؤال قاعده‌ی آنتی‌بیوتیک وبا را در **کودک** می‌سنجد.\n\n"
    "**موقعیت: طغیان اسهال آبکی با حجم زیاد در منطقه‌ی روستایی با امکانات بهداشتی پایین. "
    "کارشناسان بهداشت ویبریوکلرا را جدا کرده‌اند. در بین بیماران چند کودک ۷ ساله‌ی بدحال "
    "وجود دارد.**\n\n"
    "⚠️ **پاسخ: آزیترومایسین.**\n\n"
    "**چرا؟ فیلترهای کودک را اعمال کنید — و آن‌ها تقریباً همان فیلترهای بارداری‌اند:**\n\n"
    "**داکسی‌سیکلین** — **در کودک زیر هشت سال محدودیت دارد**، چون تتراسایکلین‌ها **رنگ‌آمیزی "
    "دائمی دندان** و **هیپوپلازی مینا** می‌دهند. (این کودک ۷ ساله است، یعنی زیر آستانه.)\n\n"
    "**سیپروفلوکساسین** — فلوروکینولون‌ها **در کودکان با احتیاط بیشتری** استفاده می‌شوند، "
    "به‌دلیل نگرانی سنتی از **آسیب غضروف**.\n\n"
    "**آزیترومایسین** — **باقی می‌ماند و بهترین انتخاب است**: در کودکان **بی‌خطر**، روی "
    "ویبریو **مؤثر**، و **تک‌دوز** (۲۰ میلی‌گرم بر کیلوگرم، حداکثر یک گرم).\n\n"
    "⚠️ **و در بستر یک طغیان روستایی، تک‌دوز بودن ارزش عملی بسیار بالایی دارد:** می‌توان "
    "دارو را **زیر نظر مستقیم** داد و **رعایت درمان را تضمین کرد** — بدون نیاز به پیگیری "
    "چندروزه در منطقه‌ای با امکانات پایین.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**داکسی‌سیکلین:** محدودیت سنی، چنان‌که گفته شد. **(و باز هم یادآوری: راهنمای امروز "
    "WHO/GTFCC داکسی‌سیکلین را حتی برای کودکان زیر ۱۲ سال با دوز ۲ تا ۴ میلی‌گرم بر کیلوگرم "
    "تک‌دوز مجاز می‌داند، چون دوره‌ی تک‌دوز خطر رنگ‌آمیزی دندان را عملاً ایجاد نمی‌کند. ولی در "
    "چارچوب این کتاب، آزیترومایسین پاسخ است.)**\n\n"
    "**سیپروفلوکساسین:** احتیاط در کودکان.\n\n"
    "⚠️ **جنتامایسین:** **این گزینه از پایه غلط است، و دلیلش آموزنده است.** آمینوگلیکوزیدها "
    "**از دستگاه گوارش جذب نمی‌شوند** — که خوب است — ولی مشکل جای دیگری است: **آن‌ها در محیط "
    "لومن روده فعالیت مؤثری ندارند** و **علیه ویبریوکلرا کاربرد بالینی ندارند**. جنتامایسین "
    "وریدی هم به لومن روده نمی‌رسد. **پس از هر دو راه بی‌فایده است.**\n\n"
    "**و یادآوری اصلی: در این طغیان، مهم‌ترین اقدام تأمین آب و الکترولیت است** — که سؤال "
    "خودش آن را ذکر کرده. **آنتی‌بیوتیک لایه‌ی دوم است.**",
    "This question tests the cholera antibiotic rule IN A CHILD.\n\n"
    "THE SITUATION: an outbreak of large-volume watery diarrhoea in a rural area with poor sanitation. "
    "Public health workers have isolated Vibrio cholerae. Among the patients are several severely ill "
    "7-year-olds.\n\n"
    "WARNING, THE ANSWER: AZITHROMYCIN.\n\n"
    "WHY? Apply the paediatric filters — and they are almost the same as the pregnancy ones:\n\n"
    "DOXYCYCLINE — RESTRICTED IN CHILDREN UNDER EIGHT, because tetracyclines cause PERMANENT DENTAL "
    "STAINING and ENAMEL HYPOPLASIA. (This child is 7, below the threshold.)\n\n"
    "CIPROFLOXACIN — fluoroquinolones are used WITH GREATER CAUTION in children, from the traditional "
    "concern about CARTILAGE DAMAGE.\n\n"
    "AZITHROMYCIN — REMAINS AND IS THE BEST CHOICE: SAFE in children, EFFECTIVE against vibrio, and A "
    "SINGLE DOSE (20 mg/kg, maximum 1 g).\n\n"
    "WARNING, AND IN A RURAL OUTBREAK, BEING A SINGLE DOSE HAS GREAT PRACTICAL VALUE: the drug can be "
    "given UNDER DIRECT OBSERVATION and ADHERENCE GUARANTEED — with no need for multi-day follow-up in "
    "an area with poor facilities.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "DOXYCYCLINE: the age restriction, as described. (AND AGAIN A REMINDER: today's WHO/GTFCC guidance "
    "permits doxycycline even in children under 12 at 2 to 4 mg/kg as a single dose, because a "
    "single-dose course effectively does not cause dental staining. But within this book's framework, "
    "azithromycin is the answer.)\n\n"
    "CIPROFLOXACIN: caution in children.\n\n"
    "WARNING, GENTAMICIN: THIS OPTION IS WRONG FROM THE START, and the reason is instructive. "
    "Aminoglycosides ARE NOT ABSORBED FROM THE GASTROINTESTINAL TRACT — which is fine — but the problem "
    "lies elsewhere: THEY HAVE NO EFFECTIVE ACTIVITY IN THE BOWEL LUMEN ENVIRONMENT and HAVE NO "
    "CLINICAL ROLE AGAINST VIBRIO CHOLERAE. Intravenous gentamicin does not reach the lumen either. SO "
    "IT IS USELESS BY EITHER ROUTE.\n\n"
    "AND THE MAIN REMINDER: IN THIS OUTBREAK THE MOST IMPORTANT MEASURE IS PROVIDING WATER AND "
    "ELECTROLYTES — which the question itself mentions. THE ANTIBIOTIC IS THE SECOND LAYER.",
    ["در کودک زیر هشت سال محدودیت دارد؛ رنگ‌آمیزی دائمی دندان و هیپوپلازی مینا.",
     "فلوروکینولون‌ها در کودکان با احتیاط بیشتری استفاده می‌شوند.",
     "پاسخ صحیح — در کودکان بی‌خطر، روی ویبریو مؤثر، و تک‌دوز که در طغیان ارزشمند است.",
     "آمینوگلیکوزیدها در لومن روده فعالیت مؤثری ندارند و علیه ویبریو کاربرد ندارند."],
    ["Restricted in children under eight; permanent dental staining and enamel hypoplasia.",
     "Fluoroquinolones are used with greater caution in children.",
     "Correct — safe in children, effective against vibrio, and a single dose, valuable in an outbreak.",
     "Aminoglycosides have no effective activity in the bowel lumen and no role against vibrio."],
    "**آمینوگلیکوزید در لومن روده کار نمی‌کند — پس در وبا از هر دو راه بی‌فایده است.**",
    "An aminoglycoside does not work in the bowel lumen — so in cholera it is useless by either route.",
    CREFS)

add("book:348", "vignette", "medium",
    "**باسیل خمیده‌ی متحرک در دارک‌فیلد: ویبریوکلرا — و در کودک، آزیترومایسین.**",
    "A motile curved bacillus on dark-field: VIBRIO CHOLERAE — and in a child, azithromycin.",
    AB_FA + [
        "**این سؤال یک یافته‌ی میکروسکوپی کلاسیک را آورده است.**",
        "**میکروسکوپ دارک‌فیلد، باکتری زنده و متحرک را در نمونه‌ی تازه نشان می‌دهد.**",
        "⚠️ **و ویبریوکلرا حرکت بسیار مشخصی دارد: پرتابی و شهاب‌وار.**",
        "**این حرکت از یک تاژک قطبی منفرد می‌آید.**",
        "**و شکل باکتری خمیده و کاما‌مانند است، که نام «ویبریو» از همان می‌آید.**",
        "**پس دارک‌فیلد یک آزمون سریع کنار بالین در طغیان است.**",
        "**و کودک ۵ ساله با فشار سیستولیک ۸۰، دهیدراتاسیون شدید دارد.**",
        "⚠️ **پس مایع وریدی فوری، و آنتی‌بیوتیک به‌عنوان کمکی.**",
    ],
    AB_EN + [
        "This question presents a classic microscopic finding.",
        "Dark-field microscopy shows live, motile bacteria in a fresh sample.",
        "WARNING, AND VIBRIO CHOLERAE HAS A VERY DISTINCTIVE MOTILITY: darting, like a shooting star.",
        "That motion comes from a single polar flagellum.",
        "And the organism is curved and comma-shaped, which is where the name 'vibrio' comes from.",
        "So dark-field is a rapid bedside test in an outbreak.",
        "And a 5-year-old with a systolic pressure of 80 has severe dehydration.",
        "WARNING, SO IMMEDIATE INTRAVENOUS FLUID, with the antibiotic as an adjunct.",
    ],
    "این سؤال یک **یافته‌ی میکروسکوپی** را با انتخاب دارو ترکیب می‌کند.\n\n"
    "**بیمار: کودک ۵ ساله با اسهال حاد آبکی از روز گذشته. فشار خون سیستولیک ۸۰ میلی‌متر "
    "جیوه. در آزمایش مدفوع، میکروارگانیسم خمیده‌ی متحرک زیر میکروسکوپ دارک‌فیلد مشاهده شده.**\n\n"
    "⚠️ **«باسیل خمیده‌ی متحرک در دارک‌فیلد» توصیف کلاسیک ویبریوکلراست.**\n\n"
    "**چرا دارک‌فیلد؟** میکروسکوپ **زمینه‌سیاه** نور را از کنار می‌تاباند، پس **باکتری زنده "
    "روی زمینه‌ی تاریک می‌درخشد**. این اجازه می‌دهد **حرکت** باکتری را در **نمونه‌ی تازه** ببینیم.\n\n"
    "**و ویبریوکلرا حرکت بسیار مشخصی دارد:** **پرتابی و شهاب‌وار (darting / shooting star)**. "
    "این حرکت از **یک تاژک قطبی منفرد** می‌آید. و شکل باکتری **خمیده و کاما‌مانند** است — "
    "**نام «ویبریو» از همین حرکت لرزان می‌آید**.\n\n"
    "**پس دارک‌فیلد یک آزمون سریع کنار بالین است** که در **طغیان** می‌تواند ظرف دقایق تشخیص "
    "احتمالی بدهد، پیش از آنکه کشت آماده شود.\n\n"
    "**حالا شدت:** **فشار سیستولیک ۸۰ در کودک ۵ ساله** یعنی **دهیدراتاسیون شدید و شوک "
    "هیپوولمیک**. **مایع وریدی فوری (رینگر لاکتات) اولویت مطلق است.**\n\n"
    "**و آنتی‌بیوتیک؟ در کودک ۵ ساله:**\n\n"
    "⚠️ **آزیترومایسین** — **بی‌خطر در کودکان**، **مؤثر روی ویبریو**، و **تک‌دوز** (۲۰ "
    "میلی‌گرم بر کیلوگرم).\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**داکسی‌سیکلین:** **در کودک ۵ ساله محدودیت دارد** (زیر هشت سال — رنگ‌آمیزی دندان). "
    "(**هرچند راهنمای امروز WHO تک‌دوز آن را در کودکان هم مجاز می‌داند.**)\n\n"
    "**سفیکسیم:** **سفالوسپورین خوراکی است و در وبا جایی ندارد.** پوشش آن روی ویبریوکلرا "
    "قابل اتکا نیست و در هیچ راهنمایی توصیه نشده.\n\n"
    "**سیپروفلوکساسین:** روی ویبریو مؤثر است، ولی در کودکان **با احتیاط بیشتری** استفاده "
    "می‌شود. آزیترومایسین انتخاب امن‌تری است.\n\n"
    "**و یادآوری همیشگی: در این کودک با فشار ۸۰، آنچه جان او را نجات می‌دهد مایع وریدی است، "
    "نه آنتی‌بیوتیک.**",
    "This question combines A MICROSCOPIC FINDING with a drug choice.\n\n"
    "THE PATIENT: a 5-year-old child with acute watery diarrhoea since yesterday. Systolic blood "
    "pressure 80 mmHg. Stool examination shows A MOTILE CURVED MICROORGANISM under dark-field "
    "microscopy.\n\n"
    "WARNING, 'A MOTILE CURVED BACILLUS ON DARK-FIELD' IS THE CLASSIC DESCRIPTION OF VIBRIO CHOLERAE.\n\n"
    "WHY DARK-FIELD? A dark-field microscope illuminates from the side, so LIVE BACTERIA GLOW AGAINST A "
    "DARK BACKGROUND. This allows the organism's MOTION to be seen in A FRESH SAMPLE.\n\n"
    "AND VIBRIO CHOLERAE HAS A VERY DISTINCTIVE MOTILITY: DARTING, LIKE A SHOOTING STAR. That motion "
    "comes from A SINGLE POLAR FLAGELLUM. And the organism is CURVED AND COMMA-SHAPED — THE NAME "
    "'VIBRIO' COMES FROM THIS VIBRATING MOTION.\n\n"
    "SO DARK-FIELD IS A RAPID BEDSIDE TEST that in an OUTBREAK can give a presumptive diagnosis within "
    "minutes, before a culture is ready.\n\n"
    "NOW THE SEVERITY: A SYSTOLIC PRESSURE OF 80 IN A 5-YEAR-OLD means SEVERE DEHYDRATION AND "
    "HYPOVOLAEMIC SHOCK. IMMEDIATE INTRAVENOUS FLUID (Ringer's lactate) IS THE ABSOLUTE PRIORITY.\n\n"
    "AND THE ANTIBIOTIC? In a 5-year-old:\n\n"
    "WARNING, AZITHROMYCIN — SAFE IN CHILDREN, EFFECTIVE against vibrio, and A SINGLE DOSE (20 mg/kg).\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "DOXYCYCLINE: RESTRICTED IN A 5-YEAR-OLD (under eight — dental staining). (ALTHOUGH TODAY'S WHO "
    "GUIDANCE PERMITS A SINGLE DOSE IN CHILDREN TOO.)\n\n"
    "CEFIXIME: AN ORAL CEPHALOSPORIN WITH NO PLACE IN CHOLERA. Its coverage of Vibrio cholerae is "
    "unreliable and it is recommended in no guideline.\n\n"
    "CIPROFLOXACIN: effective against vibrio, but used WITH GREATER CAUTION in children. Azithromycin "
    "is the safer choice.\n\n"
    "AND THE STANDING REMINDER: IN THIS CHILD WITH A PRESSURE OF 80, WHAT SAVES HIS LIFE IS THE "
    "INTRAVENOUS FLUID, NOT THE ANTIBIOTIC.",
    ["پاسخ صحیح — در کودکان بی‌خطر، روی ویبریو مؤثر، و تک‌دوز ۲۰ میلی‌گرم بر کیلوگرم.",
     "در کودک زیر هشت سال محدودیت دارد به‌دلیل رنگ‌آمیزی دائمی دندان.",
     "سفالوسپورین خوراکی است و پوشش آن روی ویبریوکلرا قابل اتکا نیست.",
     "روی ویبریو مؤثر است ولی در کودکان با احتیاط بیشتری استفاده می‌شود."],
    ["Correct — safe in children, effective against vibrio, and a single 20 mg/kg dose.",
     "Restricted in a child under eight because of permanent dental staining.",
     "An oral cephalosporin whose coverage of Vibrio cholerae is unreliable.",
     "Effective against vibrio but used with greater caution in children."],
    "**حرکت شهاب‌وار در دارک‌فیلد + شکل کاما = ویبریوکلرا، در چند دقیقه.**",
    "Darting motility on dark-field plus a comma shape = Vibrio cholerae, within minutes.",
    CREFS)

add("book:349", "vignette", "easy",
    "**وبا در بارداری، بار سوم: آزیترومایسین.**",
    "Cholera in pregnancy, a third time: AZITHROMYCIN.",
    AB_FA + [
        "**کتاب این قاعده را سه بار پرسیده، و تکرار تصادفی نیست.**",
        "**پس آن را به‌صورت یک جمله‌ی قطعی حفظ کنید.**",
        "⚠️ **وبا + بارداری = آزیترومایسین (در چارچوب این کتاب).**",
        "**نالیدیکسیک اسید هم گزینه‌ی جدیدی است که ارزش بررسی دارد.**",
        "**نالیدیکسیک اسید یک کینولون نسل اول است.**",
        "**امروز عملاً منسوخ شده، چون مقاومت به آن گسترده است.**",
        "**و در بارداری هم توصیه نمی‌شود.**",
        "**پس از هر دو جهت رد می‌شود: هم اثربخشی و هم ایمنی.**",
    ],
    AB_EN + [
        "The book asks this rule three times, and the repetition is not accidental.",
        "So memorise it as one definite sentence.",
        "WARNING, CHOLERA PLUS PREGNANCY = AZITHROMYCIN (within this book's framework).",
        "Nalidixic acid is a new option here worth examining.",
        "Nalidixic acid is a first-generation quinolone.",
        "It is effectively obsolete today, because resistance to it is widespread.",
        "And it is not recommended in pregnancy either.",
        "So it is rejected on both counts: efficacy and safety.",
    ],
    "کتاب همین قاعده را **سه بار** پرسیده است. این تکرار پیام روشنی دارد: **آن را به‌صورت "
    "یک جمله‌ی قطعی حفظ کنید و در امتحان بی‌درنگ به‌کار ببرید.**\n\n"
    "⚠️ **جمله: وبا + بارداری = آزیترومایسین.**\n\n"
    "**بیمار: خانم حامله با اسهال آبکی. با توجه به نتیجه‌ی آزمایش مستقیم مدفوع، شیوع بیماری "
    "و دهیدراتاسیون شدید، مشکوک به وبا هستید. علاوه بر اصلاح دهیدراتاسیون، از کدام آنتی‌بیوتیک "
    "استفاده می‌کنید؟**\n\n"
    "**پاسخ: آزیترومایسین** — تک‌دوز، بی‌خطر در بارداری، و مؤثر روی ویبریوکلرا.\n\n"
    "**ولی این سؤال یک گزینه‌ی جدید آورده که ارزش بررسی دارد:**\n\n"
    "⚠️ **نالیدیکسیک اسید.** این یک **کینولون نسل اول** است — جدّ فلوروکینولون‌های امروزی. "
    "دو ایراد جدی دارد:\n\n"
    "**یک — مقاومت گسترده.** نالیدیکسیک اسید **عملاً منسوخ شده است**. مقاومت به آن در "
    "پاتوژن‌های روده‌ای بسیار گسترده است. **و نکته‌ی مهم‌تر: مقاومت به نالیدیکسیک اسید یک "
    "نشانگر مقاومت نسبی به فلوروکینولون‌های جدیدتر هم هست** — آزمایشگاه‌ها گاهی آن را به همین "
    "منظور آزمایش می‌کنند.\n\n"
    "**دو — در بارداری توصیه نمی‌شود**، مثل بقیه‌ی کینولون‌ها.\n\n"
    "**پس از هر دو جهت رد می‌شود: هم اثربخشی و هم ایمنی.**\n\n"
    "**چرا دو گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**داکسی‌سیکلین:** انتخاب اول در **غیرباردار**، ولی آموزش سنتی در بارداری از آن پرهیز "
    "می‌کند. **(و باز هم: راهنمای امروز WHO/GTFCC آن را برای همه از جمله باردار توصیه "
    "می‌کند — پس در بالین امروز قابل قبول است.)**\n\n"
    "**سیپروفلوکساسین:** مؤثر است ولی **در بارداری پرهیز می‌شود** (نگرانی از غضروف).\n\n"
    "**و برای بار سوم، یادآوری همان اصل: در وبا مایع جان می‌نجات دهد.** آنتی‌بیوتیک مدت "
    "بیماری را حدود یک روز کوتاه می‌کند و حجم مدفوع را حدود نصف — که مهم است، ولی **کمکی**. "
    "**مرگ‌ومیر را مایع از ۵۰ درصد به زیر ۱ درصد می‌رساند.**",
    "The book asks this same rule THREE TIMES. That repetition carries a clear message: MEMORISE IT AS "
    "ONE DEFINITE SENTENCE AND APPLY IT INSTANTLY.\n\n"
    "WARNING, THE SENTENCE: CHOLERA PLUS PREGNANCY = AZITHROMYCIN.\n\n"
    "THE PATIENT: a pregnant woman with watery diarrhoea. Given the direct stool result, the local "
    "outbreak and severe dehydration, you suspect cholera. Besides correcting the dehydration, which "
    "antibiotic do you use?\n\n"
    "THE ANSWER: AZITHROMYCIN — single dose, safe in pregnancy, effective against Vibrio cholerae.\n\n"
    "BUT THIS QUESTION INTRODUCES A NEW OPTION WORTH EXAMINING:\n\n"
    "WARNING, NALIDIXIC ACID. This is a FIRST-GENERATION QUINOLONE — the ancestor of today's "
    "fluoroquinolones. It has two serious faults:\n\n"
    "ONE — WIDESPREAD RESISTANCE. Nalidixic acid is EFFECTIVELY OBSOLETE. Resistance among enteric "
    "pathogens is very widespread. AND A MORE IMPORTANT POINT: NALIDIXIC ACID RESISTANCE IS ALSO A "
    "MARKER OF REDUCED SUSCEPTIBILITY TO NEWER FLUOROQUINOLONES — laboratories sometimes test it for "
    "exactly that purpose.\n\n"
    "TWO — IT IS NOT RECOMMENDED IN PREGNANCY, like the other quinolones.\n\n"
    "SO IT IS REJECTED ON BOTH COUNTS: EFFICACY AND SAFETY.\n\n"
    "WHY ARE THE OTHER TWO REJECTED?\n\n"
    "DOXYCYCLINE: the first choice in a NON-PREGNANT patient, but traditional teaching avoids it in "
    "pregnancy. (AND AGAIN: today's WHO/GTFCC guidance recommends it for all patients including "
    "pregnant women — so it is acceptable on today's ward.)\n\n"
    "CIPROFLOXACIN: effective but AVOIDED IN PREGNANCY (cartilage concerns).\n\n"
    "AND FOR THE THIRD TIME, A REMINDER OF THE SAME PRINCIPLE: IN CHOLERA IT IS FLUID THAT SAVES LIFE. "
    "The antibiotic shortens the illness by about a day and halves the stool volume — which matters, "
    "but is ADJUNCTIVE. IT IS FLUID THAT CUTS MORTALITY FROM 50% TO UNDER 1%.",
    ["انتخاب اول در غیرباردار است، ولی آموزش سنتی در بارداری از آن پرهیز می‌کند.",
     "مؤثر است ولی در بارداری به‌دلیل نگرانی از غضروف پرهیز می‌شود.",
     "پاسخ صحیح — تک‌دوز، بی‌خطر در بارداری، و مؤثر روی ویبریوکلرا.",
     "کینولون نسل اول و عملاً منسوخ؛ مقاومت گسترده دارد و در بارداری هم توصیه نمی‌شود."],
    ["The first choice in a non-pregnant patient, but traditional teaching avoids it in pregnancy.",
     "Effective but avoided in pregnancy over cartilage concerns.",
     "Correct — single dose, safe in pregnancy, and effective against Vibrio cholerae.",
     "A first-generation quinolone, effectively obsolete with widespread resistance, and avoided in pregnancy."],
    "**مقاومت به نالیدیکسیک اسید، نشانگر مقاومت نسبی به فلوروکینولون‌های جدید هم هست.**",
    "Nalidixic acid resistance is also a marker of reduced susceptibility to newer fluoroquinolones.",
    CREFS)

add("book:350", "vignette", "medium",
    "**رشد در TCBS با اکسیداز مثبت: ویبریوکلرا — و در بارداری، آزیترومایسین.**",
    "Growth on TCBS with a positive oxidase: VIBRIO CHOLERAE — and in pregnancy, azithromycin.",
    AB_FA + [
        "**این سؤال دو یافته‌ی آزمایشگاهی را با هم آورده که هر دو تشخیصی‌اند.**",
        "**یک: رشد در محیط TCBS، که محیط انتخابی ویبریوهاست.**",
        "⚠️ **دو: اکسیداز مثبت، که ویبریو را از انتروباکتریاسه جدا می‌کند.**",
        "**همه‌ی انتروباکتریاسه — از جمله ای‌کلای، شیگلا و سالمونلا — اکسیداز منفی‌اند.**",
        "**و ویبریو اکسیداز مثبت است.**",
        "**پس این یک آزمون ساده و قدرتمند برای تفکیک است.**",
        "**و مدفوع بدون گلبول سفید و قرمز، تابلوی غیرالتهابی را تأیید می‌کند.**",
        "⚠️ **بیمار باردار دو ماهه است، پس فیلتر بارداری اعمال می‌شود.**",
    ],
    AB_EN + [
        "This question presents two laboratory findings, both of them diagnostic.",
        "ONE: growth on TCBS, the selective medium for vibrios.",
        "WARNING, TWO: OXIDASE POSITIVE, which separates vibrio from the Enterobacteriaceae.",
        "All Enterobacteriaceae — including E. coli, Shigella and Salmonella — are oxidase NEGATIVE.",
        "And vibrio is oxidase POSITIVE.",
        "So this is a simple and powerful discriminating test.",
        "And a stool with no white or red cells confirms the non-inflammatory picture.",
        "WARNING, THE PATIENT IS TWO MONTHS PREGNANT, so the pregnancy filter applies.",
    ],
    "این سؤال **دو یافته‌ی آزمایشگاهی** را با هم آورده که هر دو ارزش تشخیصی دارند.\n\n"
    "**بیمار: خانم حامله‌ی دو ماهه با اسهال شدید آبکی. در آزمایش مدفوع گلبول سفید صفر و "
    "گلبول قرمز صفر. در محیط کشت TCBS، ارگانیسم اکسیداز مثبت رشد کرده است.**\n\n"
    "**سه سرنخ، همه به ویبریوکلرا:**\n\n"
    "**سرنخ یک — مدفوع بدون گلبول سفید و قرمز.** **غیرالتهابی**، پس تهاجم رد می‌شود.\n\n"
    "**سرنخ دو — رشد در TCBS.** **TCBS محیط کشت انتخابی ویبریوهاست** "
    "(تیوسولفات-سیترات-بایل‌سالت-ساکارز). **رشد در آن یعنی ویبریو.** و اگر کلنی‌ها **زرد** "
    "باشند، **ویبریوکلرا** است (چون ساکارز را تخمیر می‌کند)؛ اگر **سبز** باشند، **ویبریو "
    "پاراهمولیتیکوس**.\n\n"
    "⚠️ **سرنخ سه — اکسیداز مثبت. و این نکته‌ی زیبای سؤال است.**\n\n"
    "**آزمون اکسیداز چه کار می‌کند؟** وجود آنزیم **سیتوکروم c اکسیداز** را نشان می‌دهد. و "
    "این یک **تفکیک‌کننده‌ی قدرتمند** است:\n\n"
    "**همه‌ی خانواده‌ی انتروباکتریاسه اکسیداز منفی‌اند** — ای‌کلای، شیگلا، سالمونلا، کلبسیلا، "
    "پروتئوس، همه.\n\n"
    "**و ویبریو اکسیداز مثبت است.** (همین‌طور سودوموناس، آئروموناس، کمپیلوباکتر و نایسریا.)\n\n"
    "**پس یک آزمون ساده‌ی چندثانیه‌ای، ویبریو را از کل خانواده‌ی انتروباکتریاسه جدا می‌کند.**\n\n"
    "**حالا آنتی‌بیوتیک: بیمار باردار دو ماهه است.**\n\n"
    "**فیلتر بارداری:** داکسی‌سیکلین (سنتی: پرهیز)، سیپروفلوکساسین (پرهیز)، کوتریموکسازول "
    "(پرهیز، به‌ویژه در **سه‌ماهه‌ی اول** به‌دلیل **آنتاگونیسم فولات و خطر نقص لوله‌ی عصبی** — "
    "و این بیمار دقیقاً در سه‌ماهه‌ی اول است).\n\n"
    "⚠️ **پس آزیترومایسین باقی می‌ماند: بی‌خطر، مؤثر، تک‌دوز.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**داکسی‌سیکلین:** آموزش سنتی در بارداری از آن پرهیز می‌کند (اثر بر دندان و استخوان جنین).\n\n"
    "⚠️ **کوتریموکسازول:** **در سه‌ماهه‌ی اول به‌ویژه خطرناک است** — تری‌متوپریم **آنتاگونیست "
    "فولات** است و خطر **نقص لوله‌ی عصبی** دارد. و این بیمار **دو ماهه باردار** است.\n\n"
    "**سیپروفلوکساسین:** در بارداری پرهیز می‌شود.",
    "This question presents TWO LABORATORY FINDINGS, both diagnostically valuable.\n\n"
    "THE PATIENT: a woman two months pregnant with severe watery diarrhoea. The stool shows zero white "
    "cells and zero red cells. On TCBS medium, AN OXIDASE-POSITIVE organism has grown.\n\n"
    "THREE CLUES, ALL TO VIBRIO CHOLERAE:\n\n"
    "CLUE ONE — A STOOL WITH NO WHITE OR RED CELLS. NON-INFLAMMATORY, so invasion is excluded.\n\n"
    "CLUE TWO — GROWTH ON TCBS. TCBS IS THE SELECTIVE CULTURE MEDIUM FOR VIBRIOS "
    "(thiosulfate-citrate-bile salt-sucrose). GROWTH ON IT MEANS VIBRIO. And if the colonies are "
    "YELLOW it is VIBRIO CHOLERAE (which ferments sucrose); if GREEN, VIBRIO PARAHAEMOLYTICUS.\n\n"
    "WARNING, CLUE THREE — OXIDASE POSITIVE. AND THIS IS THE ELEGANT POINT OF THE QUESTION.\n\n"
    "WHAT DOES THE OXIDASE TEST DO? It detects the enzyme CYTOCHROME c OXIDASE. And it is A POWERFUL "
    "DISCRIMINATOR:\n\n"
    "THE ENTIRE ENTEROBACTERIACEAE FAMILY IS OXIDASE NEGATIVE — E. coli, Shigella, Salmonella, "
    "Klebsiella, Proteus, all of them.\n\n"
    "AND VIBRIO IS OXIDASE POSITIVE. (As are Pseudomonas, Aeromonas, Campylobacter and Neisseria.)\n\n"
    "SO A SIMPLE FEW-SECOND TEST SEPARATES VIBRIO FROM THE WHOLE ENTEROBACTERIACEAE FAMILY.\n\n"
    "NOW THE ANTIBIOTIC: the patient is two months pregnant.\n\n"
    "THE PREGNANCY FILTER: doxycycline (traditionally avoided), ciprofloxacin (avoided), co-trimoxazole "
    "(avoided, especially in the FIRST TRIMESTER because of FOLATE ANTAGONISM AND THE RISK OF NEURAL "
    "TUBE DEFECTS — and this patient is exactly in the first trimester).\n\n"
    "WARNING, SO AZITHROMYCIN REMAINS: safe, effective, single dose.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "DOXYCYCLINE: traditional teaching avoids it in pregnancy (fetal teeth and bone).\n\n"
    "WARNING, CO-TRIMOXAZOLE: PARTICULARLY DANGEROUS IN THE FIRST TRIMESTER — trimethoprim is a FOLATE "
    "ANTAGONIST risking NEURAL TUBE DEFECTS. And this patient is TWO MONTHS PREGNANT.\n\n"
    "CIPROFLOXACIN: avoided in pregnancy.",
    ["آموزش سنتی در بارداری از آن پرهیز می‌کند به‌دلیل اثر بر دندان و استخوان جنین.",
     "در سه‌ماهه‌ی اول به‌ویژه خطرناک است؛ تری‌متوپریم آنتاگونیست فولات است.",
     "پاسخ صحیح — تک‌دوز، بی‌خطر در بارداری، و مؤثر روی ویبریوکلرا.",
     "در بارداری به‌دلیل نگرانی از آسیب غضروف پرهیز می‌شود."],
    ["Traditional teaching avoids it in pregnancy because of effects on fetal teeth and bone.",
     "Particularly dangerous in the first trimester; trimethoprim is a folate antagonist.",
     "Correct — single dose, safe in pregnancy, and effective against Vibrio cholerae.",
     "Avoided in pregnancy over concerns about cartilage damage."],
    "**انتروباکتریاسه اکسیداز منفی؛ ویبریو اکسیداز مثبت — یک آزمون، یک تفکیک.**",
    "Enterobacteriaceae are oxidase negative; vibrio is oxidase positive — one test, one separation.",
    CREFS)

add("book:351", "vignette", "medium",
    "**وبا در هفته‌ی هشتم بارداری: اریترومایسین — ماکرولید، همان خانواده‌ی امن.**",
    "Cholera at eight weeks' gestation: ERYTHROMYCIN — a macrolide, the same safe family.",
    AB_FA + [
        "**این سؤال باز هم بارداری است، ولی گزینه‌ها کمی متفاوت‌اند.**",
        "**اینجا آزیترومایسین در گزینه‌ها نیست و اریترومایسین آمده است.**",
        "**هر دو ماکرولیدند و هر دو در بارداری بی‌خطر.**",
        "⚠️ **ولی یک تفاوت عملی دارند که ارزش دانستن دارد.**",
        "**آزیترومایسین تک‌دوز است؛ اریترومایسین چند بار در روز و سه روز.**",
        "**و اریترومایسین عوارض گوارشی قابل توجهی دارد که رعایت درمان را کم می‌کند.**",
        "**به همین دلیل WHO آزیترومایسین را بر اریترومایسین ترجیح می‌دهد.**",
        "**ولی وقتی آزیترومایسین در گزینه‌ها نباشد، اریترومایسین انتخاب درست است.**",
    ],
    AB_EN + [
        "This question is again about pregnancy, but the options differ slightly.",
        "Here azithromycin is not among the options and ERYTHROMYCIN appears instead.",
        "Both are macrolides and both are safe in pregnancy.",
        "WARNING, BUT THEY DIFFER IN ONE PRACTICAL RESPECT worth knowing.",
        "Azithromycin is a single dose; erythromycin is several times a day for three days.",
        "And erythromycin has significant gastrointestinal side effects that reduce adherence.",
        "Which is why WHO prefers azithromycin over erythromycin.",
        "But when azithromycin is not among the options, erythromycin is the correct choice.",
    ],
    "این سؤال باز هم **وبا در بارداری** است، ولی **گزینه‌ها متفاوت‌اند** — و همین آن را "
    "آموزنده می‌کند.\n\n"
    "**بیمار: خانم حامله در هفته‌ی هشتم بارداری با اسهال آبکی و کرامپ‌های عضلانی. تب ندارد "
    "و از شکم‌درد هم شاکی نیست. در آزمایش مدفوع گلبول سفید صفر و گلبول قرمز صفر. در محیط "
    "کشت TCBS یک باسیل گرم منفی رشد کرده است.**\n\n"
    "**تشخیص قطعی است: وبا.** (اسهال آبکی + بدون تب + بدون درد شکم + مدفوع بدون گلبول + "
    "رشد در TCBS + کرامپ عضلانی.)\n\n"
    "⚠️ **و توجه کنید: «بدون تب و بدون درد شکم» عمداً ذکر شده — چون این دو «نبود» بخشی از "
    "تعریف وباست.**\n\n"
    "**حالا آنتی‌بیوتیک: بیمار در هفته‌ی هشتم است، یعنی سه‌ماهه‌ی اول.**\n\n"
    "**فیلتر بارداری را اعمال کنید:**\n\n"
    "**سیپروفلوکساسین** — در بارداری پرهیز می‌شود.\n\n"
    "**داکسی‌سیکلین** — آموزش سنتی در بارداری از آن پرهیز می‌کند.\n\n"
    "**کوتریموکسازول** — در **سه‌ماهه‌ی اول** به‌ویژه خطرناک است (آنتاگونیسم فولات و خطر "
    "نقص لوله‌ی عصبی). و این بیمار **در هفته‌ی هشتم** است.\n\n"
    "⚠️ **پس اریترومایسین باقی می‌ماند — و درست است.**\n\n"
    "**اریترومایسین یک ماکرولید است**، از همان خانواده‌ی آزیترومایسین. **در بارداری بی‌خطر** "
    "و **روی ویبریوکلرا مؤثر** است.\n\n"
    "**ولی یک تفاوت عملی با آزیترومایسین دارد که ارزش دانستن دارد:**\n\n"
    "**آزیترومایسین: یک گرم، تک‌دوز.** **اریترومایسین: ۵۰۰ میلی‌گرم چهار بار در روز، سه روز.**\n\n"
    "**و اریترومایسین عوارض گوارشی قابل توجهی دارد** (تهوع، استفراغ، کرامپ) — که در بیمار "
    "مبتلا به اسهال و استفراغ **رعایت درمان را دشوار می‌کند**. **به همین دلیل WHO آزیترومایسین "
    "را ترجیح می‌دهد و تصریح می‌کند که اریترومایسین را نمی‌توان به‌صورت تک‌دوز داد.**\n\n"
    "⚠️ **ولی وقتی آزیترومایسین در گزینه‌ها نباشد، اریترومایسین انتخاب درست و بی‌خطر است.**\n\n"
    "**درس روش‌شناختی: پاسخ درست، بهترین گزینه‌ی موجود است — نه بهترین گزینه‌ی ممکن در جهان.**",
    "This question is again CHOLERA IN PREGNANCY, but THE OPTIONS DIFFER — and that makes it instructive.\n\n"
    "THE PATIENT: a woman at eight weeks' gestation with watery diarrhoea and muscle cramps. She has no "
    "fever and no abdominal pain. The stool shows zero white and zero red cells. A gram-negative "
    "bacillus has grown on TCBS.\n\n"
    "THE DIAGNOSIS IS CERTAIN: CHOLERA. (Watery diarrhoea, no fever, no abdominal pain, a stool without "
    "cells, growth on TCBS, and muscle cramps.)\n\n"
    "WARNING, AND NOTE: 'NO FEVER AND NO ABDOMINAL PAIN' IS STATED DELIBERATELY — because those two "
    "absences are part of the definition of cholera.\n\n"
    "NOW THE ANTIBIOTIC: the patient is at eight weeks, that is, in the first trimester.\n\n"
    "APPLY THE PREGNANCY FILTER:\n\n"
    "CIPROFLOXACIN — avoided in pregnancy.\n\n"
    "DOXYCYCLINE — traditional teaching avoids it in pregnancy.\n\n"
    "CO-TRIMOXAZOLE — PARTICULARLY DANGEROUS IN THE FIRST TRIMESTER (folate antagonism and the risk of "
    "neural tube defects). And this patient IS AT EIGHT WEEKS.\n\n"
    "WARNING, SO ERYTHROMYCIN REMAINS — and it is correct.\n\n"
    "ERYTHROMYCIN IS A MACROLIDE, of the same family as azithromycin. It is SAFE IN PREGNANCY and "
    "EFFECTIVE against Vibrio cholerae.\n\n"
    "BUT IT DIFFERS FROM AZITHROMYCIN IN ONE PRACTICAL RESPECT WORTH KNOWING:\n\n"
    "AZITHROMYCIN: one gram, SINGLE DOSE. ERYTHROMYCIN: 500 mg four times daily for three days.\n\n"
    "AND ERYTHROMYCIN HAS SIGNIFICANT GASTROINTESTINAL SIDE EFFECTS (nausea, vomiting, cramps) — which "
    "in a patient with diarrhoea and vomiting MAKES ADHERENCE DIFFICULT. THAT IS WHY WHO PREFERS "
    "AZITHROMYCIN AND STATES EXPLICITLY THAT ERYTHROMYCIN CANNOT BE GIVEN AS A SINGLE DOSE.\n\n"
    "WARNING, BUT WHEN AZITHROMYCIN IS NOT AMONG THE OPTIONS, ERYTHROMYCIN IS THE CORRECT AND SAFE "
    "CHOICE.\n\n"
    "THE METHODOLOGICAL LESSON: THE RIGHT ANSWER IS THE BEST AVAILABLE OPTION — not the best option "
    "conceivable in the world.",
    ["در بارداری به‌دلیل نگرانی از آسیب غضروف پرهیز می‌شود.",
     "آموزش سنتی در بارداری از آن پرهیز می‌کند به‌دلیل اثر بر دندان و استخوان جنین.",
     "پاسخ صحیح — ماکرولید، در بارداری بی‌خطر و روی ویبریوکلرا مؤثر.",
     "در سه‌ماهه‌ی اول به‌ویژه خطرناک است؛ تری‌متوپریم آنتاگونیست فولات است."],
    ["Avoided in pregnancy over concerns about cartilage damage.",
     "Traditional teaching avoids it in pregnancy because of effects on fetal teeth and bone.",
     "Correct — a macrolide, safe in pregnancy and effective against Vibrio cholerae.",
     "Particularly dangerous in the first trimester; trimethoprim is a folate antagonist."],
    "**پاسخ درست، بهترین گزینه‌ی موجود است — نه بهترین گزینه‌ی ممکن.**",
    "The right answer is the best AVAILABLE option — not the best conceivable one.",
    CREFS)

add("book:352", "vignette", "medium",
    "**مهاجر از یمن با اسهال حجیم و کانفیوژن: آزیترومایسین تک‌دوز — تنها گزینه‌ی تک‌دوز مناسب.**",
    "A migrant from Yemen with voluminous diarrhoea and confusion: single-dose AZITHROMYCIN.",
    AB_FA + [
        "**یمن یکی از بزرگ‌ترین طغیان‌های وبای تاریخ معاصر را داشته است.**",
        "**پس ذکر آن در سؤال، یک سرنخ اپیدمیولوژیک قوی است.**",
        "⚠️ **و تابلو کاملاً وبایی است: اسهال حجیم بدون خون، بدون تب، بدون تندرنس.**",
        "**کانفیوژن و مخاط شدیداً خشک یعنی دهیدراتاسیون بیش از ده درصد.**",
        "**پس ابتدا اصلاح همودینامیک، که سؤال آن را فرض گرفته است.**",
        "**و سپس آنتی‌بیوتیک، که در گزینه‌ها باید بهترین را یافت.**",
        "**آزیترومایسین یک گرم تک‌دوز: مؤثر، ساده، و با مقاومت بسیار کم.**",
        "⚠️ **لووفلوکساسین تک‌دوز هم هست، ولی برای وبا رژیم استاندارد نیست.**",
    ],
    AB_EN + [
        "Yemen has had one of the largest cholera outbreaks in modern history.",
        "So mentioning it in the stem is a strong epidemiological clue.",
        "WARNING, AND THE PICTURE IS ENTIRELY CHOLERA: voluminous diarrhoea without blood, fever or tenderness.",
        "Confusion and severely dry mucosae mean dehydration over ten per cent.",
        "So haemodynamic correction comes first, which the question presupposes.",
        "And then the antibiotic, for which the best of the options must be found.",
        "Azithromycin one gram single dose: effective, simple, with very little resistance.",
        "WARNING, SINGLE-DOSE LEVOFLOXACIN EXISTS TOO, but it is not a standard cholera regimen.",
    ],
    "این آخرین سؤال بلوک وباست و **همه‌ی نکات را با هم** می‌آزماید.\n\n"
    "**بیمار: آقای ۲۵ ساله‌ی مهاجر از یمن، با اسهال حجیم بدون خون و بدون تب، فشار ۸۰/۵۰. "
    "در معاینه کانفیوژن دارد، تندرنس شکمی ندارد، و مخاطات شدیداً خشک است.**\n\n"
    "⚠️ **سرنخ اپیدمیولوژیک: یمن.** یمن **یکی از بزرگ‌ترین طغیان‌های وبای تاریخ معاصر** را "
    "تجربه کرده است (از ۲۰۱۶ به بعد، با بیش از دو میلیون مورد مشکوک). ذکر آن در سؤال، یک "
    "**سرنخ قوی** است.\n\n"
    "**و تابلو کاملاً وبایی است:**\n\n"
    "**اسهال حجیم** ✔ · **بدون خون** ✔ · **بدون تب** ✔ · **بدون تندرنس شکمی** ✔ — هر چهار "
    "با وبا منطبق‌اند.\n\n"
    "**و شدت: فشار ۸۰/۵۰ + کانفیوژن + مخاطات شدیداً خشک** = **دهیدراتاسیون بیش از ۱۰ درصد "
    "(شدید)**. ⚠️ **کانفیوژن یکی از معیارهای دهیدراتاسیون شدید است.**\n\n"
    "**پس ابتدا: اصلاح همودینامیک با رینگر لاکتات وریدی.** (سؤال این را فرض گرفته: «بعد از "
    "اصلاح همودینامیک بیمار...».)\n\n"
    "**و سپس آنتی‌بیوتیک. بیایید گزینه‌ها را بسنجیم:**\n\n"
    "**آزیترومایسین یک گرم تک‌دوز** — ✔ **پاسخ.** **مؤثر** روی ویبریو، **مقاومت بسیار کم** "
    "(زیر یک درصد در بیشتر مناطق)، و **تک‌دوز** که در طغیان و در بیمار بدحال ارزش عملی بالایی "
    "دارد.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**کوتریموکسازول هر ۱۲ ساعت، ۲ عدد، ۳ روز:** **مقاومت گسترده‌ای** در ویبریوکلرا به آن "
    "وجود دارد و **در راهنماهای امروزی توصیه نمی‌شود**.\n\n"
    "⚠️ **داکسی‌سیکلین ۱۰۰ میلی‌گرم هر ۱۲ ساعت، ۳ روز:** **دقت کنید — دوز اشتباه است.** "
    "داکسی‌سیکلین در وبا **۳۰۰ میلی‌گرم تک‌دوز** داده می‌شود، نه ۱۰۰ میلی‌گرم دوبار در روز "
    "برای سه روز. **رژیم تک‌دوز، استاندارد است** چون رعایت درمان را تضمین می‌کند. (خودِ دارو "
    "درست است — **دوز و طول دوره غلط است**.)\n\n"
    "**لووفلوکساسین ۷۵۰ میلی‌گرم تک‌دوز:** فلوروکینولون‌ها **می‌توانند** در وبا استفاده شوند "
    "(سیپروفلوکساسین یک گرم تک‌دوز در راهنماها آمده)، ولی **لووفلوکساسین رژیم استاندارد وبا "
    "نیست** و در راهنماهای WHO/GTFCC ذکر نشده.\n\n"
    "**پس تنها گزینه‌ای که هم داروی درست و هم دوز درست دارد، آزیترومایسین یک گرم تک‌دوز است.**\n\n"
    "**درس نهایی این بلوک: در وبا، مایع جان می‌نجات دهد و آنتی‌بیوتیک کمک می‌کند — و در "
    "انتخاب آنتی‌بیوتیک، دوز به‌اندازه‌ی خودِ دارو اهمیت دارد.**",
    "This is the last question in the cholera block and it tests EVERYTHING AT ONCE.\n\n"
    "THE PATIENT: a 25-year-old migrant from Yemen with voluminous diarrhoea, without blood or fever, "
    "blood pressure 80/50. On examination he is CONFUSED, has no abdominal tenderness, and his mucous "
    "membranes are severely dry.\n\n"
    "WARNING, THE EPIDEMIOLOGICAL CLUE: YEMEN. Yemen has experienced ONE OF THE LARGEST CHOLERA "
    "OUTBREAKS IN MODERN HISTORY (from 2016 onwards, with over two million suspected cases). Mentioning "
    "it is A STRONG CLUE.\n\n"
    "AND THE PICTURE IS ENTIRELY CHOLERA:\n\n"
    "VOLUMINOUS DIARRHOEA, NO BLOOD, NO FEVER, NO ABDOMINAL TENDERNESS — all four fit cholera.\n\n"
    "AND THE SEVERITY: BP 80/50 plus CONFUSION plus SEVERELY DRY MUCOSAE = DEHYDRATION OVER 10% "
    "(SEVERE). WARNING, CONFUSION IS ONE OF THE CRITERIA OF SEVERE DEHYDRATION.\n\n"
    "SO FIRST: HAEMODYNAMIC CORRECTION WITH INTRAVENOUS RINGER'S LACTATE. (The question presupposes "
    "this: 'after correcting the patient's haemodynamics...'.)\n\n"
    "AND THEN THE ANTIBIOTIC. Let us test the options:\n\n"
    "AZITHROMYCIN ONE GRAM SINGLE DOSE — THE ANSWER. EFFECTIVE against vibrio, with VERY LITTLE "
    "RESISTANCE (under one per cent in most regions), and A SINGLE DOSE, of high practical value in an "
    "outbreak and in a very ill patient.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "CO-TRIMOXAZOLE TWICE DAILY FOR 3 DAYS: there is WIDESPREAD RESISTANCE in Vibrio cholerae and it IS "
    "NOT RECOMMENDED in current guidelines.\n\n"
    "WARNING, DOXYCYCLINE 100 mg TWELVE-HOURLY FOR 3 DAYS: NOTE — THE DOSE IS WRONG. Doxycycline in "
    "cholera is given as 300 mg AS A SINGLE DOSE, not 100 mg twice daily for three days. THE "
    "SINGLE-DOSE REGIMEN IS THE STANDARD because it guarantees adherence. (The drug itself is right — "
    "THE DOSE AND DURATION ARE WRONG.)\n\n"
    "LEVOFLOXACIN 750 mg SINGLE DOSE: fluoroquinolones CAN be used in cholera (ciprofloxacin 1 g single "
    "dose appears in guidelines), but LEVOFLOXACIN IS NOT A STANDARD CHOLERA REGIMEN and is not listed "
    "in WHO/GTFCC guidance.\n\n"
    "SO THE ONLY OPTION WITH BOTH THE RIGHT DRUG AND THE RIGHT DOSE IS AZITHROMYCIN 1 g SINGLE DOSE.\n\n"
    "THE FINAL LESSON OF THIS BLOCK: IN CHOLERA, FLUID SAVES LIFE AND THE ANTIBIOTIC HELPS — and in "
    "choosing the antibiotic, THE DOSE MATTERS AS MUCH AS THE DRUG.",
    ["مقاومت گسترده‌ای در ویبریوکلرا به آن وجود دارد و در راهنماهای امروزی توصیه نمی‌شود.",
     "داروی درست ولی دوز غلط — داکسی‌سیکلین در وبا ۳۰۰ میلی‌گرم تک‌دوز است.",
     "فلوروکینولون‌ها قابل استفاده‌اند ولی لووفلوکساسین رژیم استاندارد وبا نیست.",
     "پاسخ صحیح — مؤثر، تک‌دوز، و با مقاومت زیر یک درصد در بیشتر مناطق."],
    ["There is widespread resistance in Vibrio cholerae and it is not recommended in current guidance.",
     "The right drug but the wrong dose — doxycycline in cholera is 300 mg as a single dose.",
     "Fluoroquinolones can be used but levofloxacin is not a standard cholera regimen.",
     "Correct — effective, single dose, and with under one per cent resistance in most regions."],
    "**در انتخاب آنتی‌بیوتیک، دوز به‌اندازه‌ی خودِ دارو اهمیت دارد.**",
    "In choosing an antibiotic, the dose matters as much as the drug.",
    CREFS)

json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book49.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 49 lessons:', len(L))
