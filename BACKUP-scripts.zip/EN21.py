# -*- coding: utf-8 -*-
"""English stems and options for the gastrointestinal chapter (batches 46-50).

Rule 16 checked first, as always: these 66 items come from sittings 93 to 98,
for which the ministry published no English booklet, so these are hand-written
translations rather than official ones.

TRANSLATION DECISIONS WORTH RECORDING
--------------------------------------
THE STOOL DESCRIPTORS ARE LOAD-BEARING and are translated literally every time,
because the whole chapter is decided by them: SMALL VOLUME versus LARGE VOLUME,
BLOODY versus WATERY, WITH versus WITHOUT white cells, MUCUS, TENESMUS, and the
RICE-WATER stool of cholera. Softening any of these would destroy the question
it belongs to.

THE ORGANISM ABBREVIATIONS keep their standard forms — ETEC, EHEC, EPEC — and
are also spelled out on first use in each stem where the source spells them
out, because the entire distinction between them is the middle letter and an
English reader must not have to guess.

THE REPAIRED NUMBERS are carried in their corrected form, as always: q9294's
stool white count (WBC 20-25), q9307's stool panel (WBC 40-50, RBC 10),
q9322's two ranges (WBC 20-25, RBC 30-40), q9327's white count (25,000),
q9348's systolic pressure (80 mmHg) and q9437's pulse (80/min). Every one was
confirmed against the printed glyph run of its own page before being written
here; see fix_gi_numbers2.py for the evidence.

q9437's pulse deserves a note of its own: at 80/min with a fever of 39 it is
RELATIVE BRADYCARDIA, a positive diagnostic finding for typhoid. The mirrored
"08" made a diagnostic clue look like meaningless noise, which is exactly the
kind of damage these repairs exist to undo.

TRANSPORT AND CULTURE MEDIA keep their standard names (Cary-Blair, TCBS, TTG)
because that is how they appear on a laboratory request.
"""

EN21 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    assert all(o.strip() for o in options), idx
    EN21[idx] = {"stem_en": stem, "options_en": options}


# ==================================================== INFLAMMATORY AND HUS
add(287,
    "A 15-year-old adolescent has had fever, vomiting, diarrhoea and abdominal pain for two days. He "
    "reports opening his bowels 8 times a day, with a very small volume each time, accompanied by "
    "tenesmus and mucus and without blood. The stool examination reports white cells and red cells. "
    "All of the following can cause this picture EXCEPT",
    ["Campylobacter jejuni",
     "Enterotoxigenic Escherichia coli (ETEC)",
     "Vibrio parahaemolyticus",
     "Shigella dysenteriae"])

add(288,
    "A 20-year-old soldier presents with a fever of 38 degrees Celsius, back pain and pelvic pain "
    "together with swelling of both knees for the past week, and complains of mild knee pain. His "
    "history includes bloody diarrhoea one month ago which lasted 5 days. In your opinion, which of "
    "the following organisms COULD NOT have been the cause of this patient's diarrhoea?",
    ["Shigella dysenteriae",
     "Campylobacter jejuni",
     "Yersinia enterocolitica",
     "Enterotoxigenic Escherichia coli"])

add(289,
    "Haemolytic uraemic syndrome (HUS) is a complication of which of the following causes of "
    "gastroenteritis?",
    ["Enteric Salmonellae",
     "Enterohaemorrhagic E. coli",
     "Clostridium perfringens",
     "Campylobacter jejuni"])

add(290,
    "A patient presents with weakness, pallor, epistaxis and generalised oedema. Investigations show a "
    "haemoglobin of 7 g/dL, a platelet count of 20,000 per microlitre, a negative Coombs test and a "
    "creatinine of 4 mg/dL. Schistocytes are seen on the peripheral blood film. The patient gives a "
    "history of bloody diarrhoea a few days earlier. All of the following microorganisms are "
    "considered as causes of this condition EXCEPT",
    ["Shigella",
     "Enterohaemorrhagic E. coli",
     "Campylobacter",
     "Entamoeba histolytica"])

add(291,
    "A young woman has developed acute renal failure and severe anaemia 4 days after the onset of "
    "bloody diarrhoea. The stool examination reports RBC: many and WBC: 10-15. Which organism is more "
    "likely?",
    ["Shigella dysenteriae",
     "Enterotoxigenic E. coli",
     "Campylobacter jejuni",
     "Yersinia enterocolitica"])

add(292,
    "A 7-year-old boy who had developed diarrhoea with fever a few days earlier has been brought to "
    "the emergency department with bleeding from the gums and swelling of the limbs. He is oliguric "
    "and pale. His blood count shows Hb 7.5, WBC 50,000 and platelets 5,000/mL. What is the most "
    "likely causative organism?",
    ["Entamoeba histolytica",
     "Shigella dysenteriae",
     "Vibrio cholerae",
     "Rotavirus"])

add(326,
    "A young man has been admitted with fever, thrombocytopenia, disorientation and delirium, and "
    "laboratory evidence of renal failure. He reports an episode of dysentery and fever 10 days "
    "earlier for which he was admitted for 2 days. The stool examination at that time reported many "
    "WBC and RBC. Which organism could account for this whole set of problems?",
    ["Salmonella typhimurium",
     "Enteropathogenic E. coli",
     "Shigella dysenteriae",
     "Campylobacter jejuni"])

add(327,
    "A 6-year-old child has been brought to the emergency department with pallor, facial swelling and "
    "bleeding from the nose and gums. According to his mother the child had bloody diarrhoea last "
    "week which was treated and resolved. Investigations show a haemoglobin of 8 mg/dL, WBC 25,000, "
    "platelets 10/000 (that is, 10,000), and a rise in urea and creatinine. Which syndrome should be considered?",
    ["Icary syndrome",
     "Haemolytic uraemic syndrome",
     "Irritable bowel syndrome",
     "Reiter's syndrome"])

add(328,
    "Which of the following is NOT part of the diagnostic triad of haemolytic uraemic syndrome?",
    ["Leucocytosis",
     "Thrombocytopenia",
     "Microangiopathic haemolytic anaemia",
     "Acute renal failure"])

# ==================================================== FOOD POISONING
add(295,
    "Which of the following is NOT a cause of food poisoning?",
    ["Clostridium perfringens",
     "Bacillus cereus",
     "Campylobacter jejuni",
     "Giardia lamblia"])

add(296,
    "A family of three present to you with diarrhoea and vomiting, stating that they attended a party "
    "at midday yesterday. All of the following organisms could be responsible for their problem EXCEPT",
    ["Vibrio cholerae",
     "Salmonella",
     "Shigella",
     "Staphylococcus aureus"])

add(298,
    "Cooling food slowly and keeping it at room temperature causes which of the following types of "
    "food poisoning?",
    ["Enterotoxin diarrhoeas such as Staphylococcus aureus",
     "Inflammatory diarrhoeas such as the Salmonellae",
     "Bloody diarrhoeas such as Shigella",
     "Spore-related diarrhoea such as Clostridium"])

add(299,
    "A 7-year-old girl is brought to the emergency department about 4 hours after returning from a "
    "birthday party with diarrhoea, nausea and vomiting. Similar symptoms are seen in her friends from "
    "the party. What is the most likely causative organism?",
    ["Salmonella",
     "Campylobacter",
     "Staphylococcus aureus",
     "Clostridium perfringens"])

add(304,
    "A number of students in a hall of residence have developed watery diarrhoea, nausea and vomiting "
    "without abdominal pain 4 hours after eating a lettuce and egg salad containing mayonnaise. What "
    "is the most appropriate action?",
    ["Stool culture and rehydration",
     "Rehydration",
     "Direct stool examination and stool culture",
     "Direct stool examination and starting ciprofloxacin"])

# ==================================================== ACUTE DIARRHOEA ALGORITHM
add(305,
    "A patient has had watery diarrhoea for 2 hours and his vital signs are stable. Which of the "
    "following is the correct approach to this patient?",
    ["We send a stool culture and hydrate the patient until the result arrives",
     "We perform a stool analysis and prescribe an appropriate antibiotic on that basis",
     "We simply hydrate the patient",
     "We use a quinolone for treatment"])

add(303,
    "A 60-year-old woman has been brought to the emergency department because of severe watery "
    "diarrhoea and weakness. For 2 days she has passed 7 to 8 large-volume watery stools daily, "
    "leading to severe weakness. She has had no fever. She is alert. Lying blood pressure 130/70 with "
    "PR 110/min; sitting blood pressure 100/40 with rr 16/min. No other systemic abnormality was "
    "found. The stool examination shows nothing of note. Which of the following is the most important "
    "action?",
    ["Giving an antimotility drug",
     "Correcting fluid and electrolytes",
     "Giving an antibiotic",
     "Blood transfusion"])

add(307,
    "A 30-year-old man has been brought to the emergency department with severe diarrhoea, weakness "
    "and lethargy. On examination RR 20, T 38, BP 80 by palpation and PR 100, with dry mucous "
    "membranes. Investigations in the emergency department show E/S: WBC 40-50 and RBC 10. All of the "
    "following have a place in his treatment EXCEPT",
    ["Ringer's lactate solution",
     "Oral rehydration solution (ORS)",
     "An antibiotic",
     "An antimotility agent"])

add(301,
    "A 21-year-old man presents complaining of diarrhoea and fever. His diarrhoea was watery and then "
    "became bloody over 24 hours, accompanied by tenesmus and abdominal cramps. He mentions similar "
    "symptoms in his brother 3 days earlier. Examination shows nothing apart from mild dehydration. "
    "Given the most likely diagnosis, what is the treatment of choice?",
    ["Ciprofloxacin",
     "Loperamide",
     "Amoxicillin",
     "Metronidazole"])

add(302,
    "A 40-year-old man presents with fever and bloody diarrhoea. The urgently performed stool "
    "examination shows nothing apart from many WBC and RBC. Which of the following drugs is "
    "recommended for him?",
    ["Bismuth",
     "Iodoquinol",
     "Ciprofloxacin",
     "Metronidazole"])

add(300,
    "A 17-year-old boy presents with bloody diarrhoea that began two days ago. The stool examination "
    "reports many RBC, many WBC, and cysts of Entamoeba COLI. Which of the following drugs is the "
    "treatment of choice for him?",
    ["Metronidazole",
     "Ciprofloxacin",
     "Iodoquinol",
     "Furazolidone"])

# ==================================================== C. DIFFICILE
add(310,
    "A 30-year-old man undergoes bone marrow transplantation for leukaemia. One week after the "
    "transplant he develops diarrhoea. Which organism is most likely?",
    ["Clostridioides difficile",
     "Salmonella",
     "Candida albicans",
     "Shigella"])

add(311,
    "A 65-year-old man who has been in hospital since last week for pneumonia has developed fever, "
    "abdominal pain and diarrhoea. Red cells and white cells are evident in his stool examination. "
    "Which organism is most likely to be causing his symptoms?",
    ["Shigella",
     "Rotavirus",
     "Clostridioides difficile",
     "Campylobacter jejuni"])

add(312,
    "A 70-year-old patient, a few days after admission for pneumonia and while being treated with "
    "ceftriaxone plus erythromycin, develops diarrhoea 5 to 6 times a day without fever or abdominal "
    "pain. The stool examination shows 10 to 12 white cells and the white cell count, urea and "
    "creatinine are normal. What is the MOST SENSITIVE diagnostic method for the causative organism?",
    ["Colonoscopy",
     "Stool culture",
     "Assay for Clostridioides difficile toxin",
     "PCR for the toxin A gene"])

add(314,
    "In the diagnosis of Clostridioides difficile infection, which method has the LOWER sensitivity?",
    ["Stool culture for Clostridioides difficile",
     "Stool PCR for toxin A or B",
     "Stool EIA for toxin A or B",
     "Colonoscopy to visualise pseudomembranes"])

add(313,
    "A 50-year-old diabetic woman with cervical vertebral osteomyelitis is being treated with "
    "ciprofloxacin plus clindamycin. After 3 weeks of treatment she develops fever, abdominal pain and "
    "bloody diarrhoea. The stool examination shows RBC 20-30 and WBC many. In this patient, which of "
    "the following methods helps with the diagnosis?",
    ["Stool culture",
     "Colonoscopy",
     "Measurement of Clostridioides difficile toxin in the stool by PCR",
     "All of the above"])

add(315,
    "In the regional hospital where you work, many cases of Clostridioides difficile-associated "
    "diarrhoea have been reported. You are asked to advise on this problem. Which measure do you "
    "consider LESS effective in controlling the outbreak?",
    ["Restricting the use of clindamycin and the cephalosporins",
     "Emphasising surface disinfection with a hypochlorite (bleach) solution",
     "Emphasising hand disinfection with an alcohol solution instead of soap and water",
     "Emphasising the use of gloves by healthcare staff"])

add(317,
    "A patient has developed non-bloody diarrhoea after receiving broad-spectrum antibiotics in the "
    "intensive care unit. In addition to treating the patient, which of the following is recommended "
    "to prevent transmission of the infection?",
    ["Identifying carrier patients in neighbouring beds",
     "Disinfecting staff hands with alcohol",
     "Environmental disinfection and the wearing of gloves by staff",
     "Identifying and treating asymptomatic carrier staff"])

add(318,
    "A 35-year-old woman with a diagnosis of PID is being treated with ceftriaxone and clindamycin. On "
    "the third day of treatment she reports non-bloody diarrhoea 6 episodes a day with a mild fever, "
    "without vomiting or abdominal pain. Given the most likely diagnosis, what is the most appropriate "
    "action after stopping the antibiotics?",
    ["Oral vancomycin 500 mg twice daily",
     "Oral metronidazole 500 mg three times daily",
     "Oral ciprofloxacin 500 mg three times daily",
     "Co-trimoxazole two adult tablets twice daily"])

add(319,
    "A patient with a diabetic foot ulcer develops diarrhoea after treatment with ciprofloxacin and "
    "clindamycin. No specific organism was identified on stool examination and colonoscopy has "
    "reported pseudomembranes. In addition to stopping the antibiotics, which of the following is the "
    "appropriate treatment for the patient?",
    ["Diphenoxylate",
     "Intravenous vancomycin",
     "Intravenous ceftriaxone",
     "Oral metronidazole"])

add(322,
    "A patient is admitted for pelvic surgery. 10 days after admission he develops bloody diarrhoea. "
    "The stool examination shows WBC 20-25, RBC 30-40 and no parasites. His antibiotics are stopped "
    "and a stool culture performed 48 hours later is negative. Over the following 48 to 72 hours the "
    "diarrhoea continues more severely and the patient becomes sicker. Which of the following "
    "treatments is most appropriate?",
    ["Oral metronidazole",
     "Oral vancomycin",
     "Oral ciprofloxacin",
     "Oral metronidazole plus oral vancomycin"])

# ==================================================== SHIGELLA
add(323,
    "A child has had a seizure following fever and diarrhoea. He also complains of abdominal pain and "
    "tenesmus. In the course of the illness he develops rectal prolapse. Which of the following "
    "organisms is most likely to be responsible?",
    ["Salmonella typhi",
     "Shigella dysenteriae",
     "Enterohaemorrhagic E. coli",
     "Entamoeba histolytica"])

add(325,
    "A seven-year-old child developed fever and watery diarrhoea yesterday. Today the stool volume has "
    "decreased but has become bloody. Which of the following is more likely?",
    ["Campylobacter jejuni",
     "Shigella dysenteriae",
     "Entamoeba histolytica",
     "Vibrio cholerae"])

add(329,
    "A 52-year-old man who received a liver transplant one year ago presents with fever, abdominal "
    "pain and diarrhoea for three days, and reports seeing streaks of blood in his stool on the day of "
    "presentation. He is febrile on examination. Stool analysis and culture were performed and the "
    "stool culture is reported positive for Shigella. What do you suggest for his treatment?",
    ["Azithromycin tablets as a single dose",
     "Ciprofloxacin tablets for 7 days",
     "Metronidazole tablets for three days",
     "The patient does not need antibiotic treatment"])

add(330,
    "A 28-year-old woman at 32 weeks' gestation presents with fever, bloody diarrhoea, abdominal pain "
    "and anorexia since yesterday. The direct stool examination reports WBC: many, RBC: many. In "
    "addition to correcting fluid and electrolytes, which antibiotic is appropriate for her?",
    ["Amoxicillin",
     "Azithromycin",
     "Clindamycin",
     "Cefuroxime"])

add(331,
    "A 25-year-old man with ALL-L2 is receiving chemotherapy. He has had dysentery for three days. "
    "Shigella dysenteriae type 1 has been isolated from his stool culture. What is the appropriate "
    "duration of treatment for him?",
    ["3 days",
     "5 days",
     "7 to 10 days",
     "14 days"])

add(293,
    "A 17-year-old student has developed fever, vomiting, abdominal pain and frequent small-volume "
    "purulent diarrhoea after attending an educational camp. The stool examination performed reports "
    "many WBC and RBC. Which of the following CANNOT cause this illness?",
    ["Vibrio cholerae",
     "Shigella dysenteriae",
     "Campylobacter jejuni",
     "Salmonella enteritidis"])

add(294,
    "In the stool examination of a patient presenting with bloody diarrhoea, WBC 20-25 is reported. "
    "Which CANNOT be the cause of the illness?",
    ["Vibrio cholerae",
     "Enterohaemorrhagic E. coli",
     "Campylobacter jejuni",
     "Entamoeba histolytica"])

# ==================================================== CHOLERA
add(333,
    "A 22-year-old man presents with frequent large-volume watery diarrhoea since this morning; on "
    "initial assessment his temperature was 37.3, BP 80 by palpation and HR 112/min. On direct stool "
    "examination no white cells were reported. Similar cases have attended the emergency department in "
    "recent days. What is the most likely diagnosis?",
    ["Infection with Vibrio cholerae",
     "Infection with Shigella dysenteriae",
     "Infection with Giardia intestinalis",
     "Infection due to non-typhoidal Salmonellae"])

add(334,
    "A 25-year-old man develops severe watery rice-water diarrhoea one day after travelling to India. "
    "His blood pressure is 90/60 mmHg and the stool sample shows RBC 0 and WBC 0. His stool has a "
    "fishy odour. Which of the following organisms should be considered?",
    ["Bacillus cereus",
     "Vibrio cholerae",
     "Clostridium perfringens",
     "Enterotoxigenic E. coli (ETEC)"])

add(335,
    "An 8-year-old child presents with acute watery diarrhoea for 2 hours. Together with the diarrhoea "
    "the patient is febrile, is vomiting, and also has muscle cramps. Which of the patient's features "
    "is NOT consistent with classic cholera?",
    ["Fever",
     "Vomiting",
     "Watery diarrhoea",
     "Muscle cramps"])

add(337,
    "A 30-year-old woman presents to the emergency department with painless watery diarrhoea that "
    "rapidly became voluminous, together with fever, vomiting and muscle cramps. Her stool is grey and "
    "contains mucus, without blood, and has a bad odour. All of the following features are consistent "
    "with cholera EXCEPT",
    ["Fever",
     "The absence of blood in the stool",
     "Muscle cramps",
     "The colour of the stool"])

add(338,
    "In cholera, the presence of thirst, orthostatic hypotension, weakness, tachycardia, reduced skin "
    "turgor, dry mucous membranes and absent tears indicates what percentage of dehydration?",
    ["Less than 5% dehydration, or mild dehydration",
     "Between 5% and 10% dehydration, or moderate dehydration",
     "More than 10% dehydration, or severe dehydration",
     "None of the above"])

add(339,
    "A 38-year-old man presents to a rural health centre with severe watery diarrhoea. On physical "
    "examination his blood pressure is 70 mmHg by palpation and his mucous membranes are completely "
    "dry. Given the long distance to the district health centre, which TRANSPORT medium do you use to "
    "confirm the diagnosis?",
    ["TTG (taurocholate-tellurite-gelatin)",
     "TCBS (thiosulfate-citrate-bile salt-sucrose)",
     "Cary-Blair",
     "Any of the three media may be used"])

add(341,
    "In a patient with cholera who requires intravenous fluid therapy, which of the following fluids "
    "is more appropriate for treatment?",
    ["Ringer's lactate",
     "Normal saline",
     "One-third/two-thirds solution",
     "5% dextrose in water"])

add(342,
    "A 45-year-old man with rice-water watery diarrhoea has been admitted to the emergency department "
    "with severe dehydration. What is the most important action?",
    ["Intravenous ceftriaxone",
     "Oral loperamide",
     "Completing the investigations",
     "Fluid resuscitation with Ringer's solution"])

add(343,
    "You are seeing a young woman in the emergency department with a picture of acute watery "
    "diarrhoea; she is drowsy and has severe dehydration and hypotension. The stool volume is large "
    "and white-grey in colour. Which is the most appropriate fluid for replacing the volume the "
    "patient has lost?",
    ["Albumin",
     "Normal saline",
     "Ringer's solution",
     "Ringer's lactate solution"])

add(344,
    "A pregnant woman presents with severe watery diarrhoea. Given the clinical features and the "
    "epidemiological evidence, cholera is suspected. In addition to giving KCl, which treatment is "
    "chosen for her?",
    ["Dextrose-saline plus ceftriaxone",
     "One-third/two-thirds solution plus ampicillin",
     "Normal saline plus ciprofloxacin",
     "Ringer's lactate plus erythromycin"])

add(345,
    "For a woman in the last month of pregnancy who has developed gastroenteritis due to Vibrio "
    "cholerae, which of the following antibiotics is given in addition to rehydration?",
    ["Azithromycin",
     "Ciprofloxacin",
     "Doxycycline",
     "Amoxicillin"])

add(346,
    "Following reports of numerous cases of large-volume watery diarrhoeal illness in a rural area "
    "with poor sanitation, public health workers isolate Vibrio cholerae from the stool samples of "
    "several patients. Among the patients are several severely ill 7-year-old children. In addition to "
    "providing water and electrolytes, which of the following antibiotics would you use as the "
    "preferred drug?",
    ["Doxycycline",
     "Ciprofloxacin",
     "Azithromycin",
     "Gentamicin"])

add(348,
    "A 5-year-old child presents with acute watery diarrhoea since yesterday. The patient's systolic "
    "blood pressure is 80 mmHg. In the stool examination performed, a motile curved microorganism is "
    "seen under dark-field microscopy. Which antibiotic do you suggest for his treatment?",
    ["Azithromycin",
     "Doxycycline",
     "Cefixime",
     "Ciprofloxacin"])

add(349,
    "A pregnant woman presents with watery diarrhoea. Given the direct stool examination result, the "
    "prevalence of the disease and her severe dehydration, you suspect cholera. In addition to "
    "correcting the dehydration, which of the following do you use for antibiotic treatment?",
    ["Doxycycline",
     "Ciprofloxacin",
     "Azithromycin",
     "Nalidixic acid"])

add(350,
    "A woman two months pregnant presents with severe watery diarrhoea. Her stool examination shows "
    "WBC 0 and RBC 0, and an oxidase-positive organism has grown on TCBS medium. What is the most "
    "appropriate antibiotic for this patient?",
    ["Doxycycline",
     "Co-trimoxazole",
     "Azithromycin",
     "Ciprofloxacin"])

add(351,
    "A pregnant woman at eight weeks' gestation presents with watery diarrhoea and muscle cramps. She "
    "has no fever and does not complain of abdominal pain. The stool examination reports WBC 0 and RBC "
    "0. A gram-negative bacillus grows on TCBS medium. In addition to correcting fluid and "
    "electrolytes, which antibiotic do you choose?",
    ["Ciprofloxacin",
     "Doxycycline",
     "Erythromycin",
     "Co-trimoxazole"])

add(352,
    "A 25-year-old man, a migrant from Yemen, has been brought to the emergency department by "
    "relatives complaining of voluminous diarrhoea without blood or fever, with a blood pressure of "
    "80/50 mmHg. On examination the patient is confused, has no abdominal tenderness, and his mucous "
    "membranes are severely dry. After correcting the patient's haemodynamics, which antibiotic is "
    "preferable given the history?",
    ["Co-trimoxazole 2 tablets every 12 hours for 3 days",
     "Doxycycline 100 mg every 12 hours for 3 days",
     "Levofloxacin 750 mg as a single dose",
     "Azithromycin 1 gram as a single dose"])

# ==================================================== SALMONELLA AND TYPHOID
add(423,
    "Which living creature is the source of transmission of Salmonella typhi to humans?",
    ["Birds",
     "Cattle",
     "Sheep",
     "Man"])

add(424,
    "A 28-year-old man presents complaining of fever, abdominal pain, headache and reduced appetite "
    "which began a week ago. On examination the spleen is palpable and the tongue is furred, and there "
    "are maculopapular lesions on the chest and trunk which blanch on pressure (T 40 degrees Celsius, "
    "PR 80/min). What is the most likely diagnosis?",
    ["Typhoid",
     "Brucellosis",
     "Meningococcaemia",
     "Leptospirosis"])

add(425,
    "A 25-year-old woman with a history of drinking spring water presents with fever, abdominal pain "
    "and headache for the past week. On physical examination she has a fever of 39 degrees, a furred "
    "tongue and a palpable spleen, but no meningeal signs. The patient is alert and a few "
    "maculopapular lesions are seen on the upper abdomen. What is the most likely diagnosis?",
    ["Brucellosis",
     "Typhoid",
     "Meningitis",
     "Cholecystitis"])

add(426,
    "A 16-year-old boy with no significant medical history presents with fever, headache, abdominal "
    "pain and constipation for the past 7 days. Red maculopapular lesions are seen on the chest. On "
    "examination there is no tonsillar exudate. He has a fever of 39 degrees and PR 80. The "
    "investigations performed show leucopenia. What is the most likely diagnosis?",
    ["Typhoid",
     "Malaria",
     "Infective endocarditis",
     "Infectious mononucleosis"])

add(427,
    "A 27-year-old man presents with fever, abdominal pain and headache for the past 5 days. On "
    "examination the patient is drowsy, febrile and toxic. On abdominal examination the spleen is "
    "palpable below the costal margin and several red maculopapular lesions are seen on the abdominal "
    "skin. His clinical signs are BP 110/75, RR 18, PR 70, BT 40 degrees Celsius. The investigations "
    "performed show WBC 2800 (PMN 30%), ALP 300, ALT 120. What is the most likely diagnosis?",
    ["Viral hepatitis",
     "Meningococcaemia",
     "Enteric fever",
     "Malaria"])

add(428,
    "A 49-year-old man presents complaining of fever, chills and abdominal pain for the past week. He "
    "has had nausea, vomiting and diarrhoea and also complains of headache and myalgia. On examination, "
    "in addition to splenomegaly, he has a small number of maculopapular lesions on the abdomen which "
    "blanch on pressure. His temperature is 39.5 degrees axillary and his pulse rate is 78 per minute. "
    "Given the clinical findings presented, which diagnostic test has the greater yield?",
    ["The Wright test",
     "Blood culture",
     "Echocardiography",
     "CSF analysis"])

add(431,
    "A 25-year-old man presents to the emergency department with fever for the past 12 days together "
    "with abdominal pain, headache and constipation. The patient reports that he received 5 days of "
    "oral cefixime without adequate improvement. On clinical examination he has no neck stiffness. On "
    "abdominal examination the only positive finding is mild hepatosplenomegaly. Given the most likely "
    "diagnosis, which of the following methods has the greatest diagnostic value?",
    ["Blood culture",
     "CSF culture",
     "Stool culture",
     "Bone marrow aspirate culture"])

add(432,
    "A young man with no previous medical history presents with fever and diarrhoea. Non-typhoidal "
    "Salmonella is reported in his stool culture. What is the most appropriate treatment for the "
    "patient?",
    ["Ciprofloxacin",
     "Amoxicillin",
     "Rehydration",
     "Ceftriaxone"])

add(433,
    "A patient has developed fever, diarrhoea and vomiting after eating eggs. His vital signs are "
    "stable and his blood pressure is 120/70. His stool examination reports 10 WBC and the stool "
    "culture reports Salmonella. What is the appropriate therapeutic action?",
    ["Azithromycin 1 gram as a single dose",
     "Furazolidone for 5 days",
     "Ciprofloxacin for 3 to 5 days",
     "The patient does not need an antibiotic"])

add(436,
    "A 35-year-old woman is admitted because of abdominal pain with fever and non-bloody diarrhoea. "
    "The stool examination result favours inflammatory diarrhoea. Salmonella typhimurium grows in the "
    "stool culture and in one of three blood cultures. In addition to correcting fluid and "
    "electrolytes, which therapeutic action do you consider appropriate?",
    ["Ceftriaxone for 48 hours",
     "Co-trimoxazole for 5 days",
     "Ciprofloxacin for 2 weeks",
     "Ampicillin for 4 weeks"])

add(437,
    "A 20-year-old adolescent is admitted to the infectious diseases ward with high fever, headache, "
    "abdominal pain and anorexia which began a week ago. On examination he has a fever of 39 degrees "
    "Celsius, a pulse of 80/min and a normal blood pressure, and appears confused and apathetic. His "
    "tongue is dry and furred. The abdomen is distended, the spleen is palpable, and several blanching "
    "pink maculopapular lesions are seen on the chest and abdomen. The patient has leucopenia of 3000 "
    "and thrombocytopenia of 100 thousand (100,000). After taking blood cultures, what is the most appropriate "
    "therapeutic action?",
    ["Intravenous chloramphenicol plus gentamicin",
     "Intravenous doxycycline",
     "Intravenous ceftriaxone",
     "Intravenous vancomycin plus metronidazole"])

add(438,
    "A 50-year-old man presents with fever for the past few days, abdominal pain and constipation. On "
    "examination he has no acute abdominal signs but does have hepatosplenomegaly. Given the relative "
    "bradycardia and the suspicion of typhoid fever, which of the following treatments would you "
    "suggest empirically?",
    ["Oral ciprofloxacin",
     "Intravenous ceftriaxone",
     "Oral co-trimoxazole",
     "Intravenous chloramphenicol"])
