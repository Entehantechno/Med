# -*- coding: utf-8 -*-
"""Micro-lessons, batch 8 — the tetanus prophylaxis block.

Why this chapter, and why these questions
-----------------------------------------
Of the 46 toxin-mediated questions in the book only ONE was taught, the worst
coverage of any chapter. It is also the chapter with the tightest internal
structure: 23 of the 46 ask the same single decision — given a wound and a
vaccination history, what do you give? The ministry has asked it in at least
nine separate sittings, phrased nine different ways.

That makes it exceptional value. One properly built decision table answers all
23, so this batch teaches the TABLE rather than 23 isolated facts. Every lesson
walks the same three steps in the same order, so by the third question the
student is running the algorithm rather than recalling a vignette.

The decision, once and for all (CDC/ACIP; Harrison's 21e Table 304-1):

    STEP 1  Count prior tetanus-toxoid doses:  >=3  or  <3/unknown
    STEP 2  Classify the wound:  clean & minor  or  everything else
    STEP 3  Read the answer off the table

        >=3 doses, clean wound     -> toxoid only if >=10 years since last
        >=3 doses, dirty wound     -> toxoid only if >=5 years since last
        >=3 doses, ANY wound       -> TIG never
        <3/unknown, clean wound    -> toxoid, no TIG
        <3/unknown, dirty wound    -> toxoid AND TIG 250 IU IM
        HIV / severe immunodeficiency + dirty wound -> TIG regardless of history

Pregnancy is the second cluster (WHO maternal/neonatal tetanus): a pregnant
woman with no or unknown history gets TWO doses at least four weeks apart
before delivery, the second at least two weeks pre-partum, then continues to
five doses lifetime. Vaccine is not contraindicated in pregnancy — it is the
whole point of the programme.

Sources checked for this batch, beyond Harrison:
  * CDC, "Clinical Guidance for Wound Management to Prevent Tetanus"
  * ACIP/CDC tetanus prophylaxis table (the 5-year vs 10-year thresholds)
  * WHO SAGE, maternal and neonatal tetanus vaccination schedules

One printed key is contradicted by every one of those sources and is handled
explicitly below (idx 382) rather than taught as printed.
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = "Harrison's Principles of Internal Medicine, 21st ed (2022)"
CDC = "CDC — Clinical Guidance for Wound Management to Prevent Tetanus (ACIP)"
WHO = "WHO SAGE — Vaccination schedules for preventing maternal and neonatal tetanus"

# The three steps, repeated verbatim in several lessons so the student meets the
# same wording every time and it becomes automatic.
STEP_FA = [
    "گام یک: تعداد دوزهای قبلی واکسن کزاز را بشمار — سه دوز یا بیشتر، یا کمتر از سه/نامعلوم.",
    "گام دو: زخم را دسته‌بندی کن — «تمیز و سطحی» یا «هر زخم دیگر».",
    "گام سه: جواب را از جدول بخوان؛ حدس نزن.",
]
STEP_EN = [
    "Step 1: count prior tetanus toxoid doses — three or more, or fewer than three/unknown.",
    "Step 2: classify the wound — 'clean and minor', or 'every other wound'.",
    "Step 3: read the answer off the table; do not guess.",
]

TABLE_FA = [
    "سه دوز یا بیشتر + زخم تمیز: واکسن فقط اگر ۱۰ سال یا بیشتر از آخرین دوز گذشته باشد.",
    "سه دوز یا بیشتر + زخم کثیف: واکسن فقط اگر ۵ سال یا بیشتر از آخرین دوز گذشته باشد.",
    "سه دوز یا بیشتر: **تتابولین (TIG) هرگز لازم نیست** — نه در زخم تمیز، نه در زخم کثیف.",
    "کمتر از سه دوز یا نامعلوم + زخم تمیز: واکسن بله، TIG خیر.",
    "کمتر از سه دوز یا نامعلوم + زخم کثیف: **هم واکسن و هم TIG** (۲۵۰ واحد عضلانی).",
    "استثنا: HIV یا نقص ایمنی شدید با زخم کثیف ← TIG بدون توجه به سابقه‌ی واکسن.",
]
TABLE_EN = [
    "Three or more doses + clean wound: vaccine only if 10 or more years since the last dose.",
    "Three or more doses + dirty wound: vaccine only if 5 or more years since the last dose.",
    "Three or more doses: TIG is NEVER needed — not for clean wounds, not for dirty ones.",
    "Fewer than three doses or unknown + clean wound: vaccine yes, TIG no.",
    "Fewer than three doses or unknown + dirty wound: BOTH vaccine and TIG (250 IU IM).",
    "Exception: HIV or severe immunodeficiency with a dirty wound gets TIG regardless of history.",
]

WHY_FA = [
    "واکسن (توکسوئید) ایمنی **فعال** می‌سازد ولی چند روز طول می‌کشد؛ زخم امروز را پوشش نمی‌دهد.",
    "تتابولین (TIG) ایمنی **غیرفعال** و فوری می‌دهد؛ سم آزاد در گردش را خنثی می‌کند.",
    "TIG سمی را که قبلاً به پایانه‌ی عصبی چسبیده خنثی نمی‌کند — پس هرچه زودتر بهتر.",
    "به همین دلیل در فرد ناایمن با زخم کثیف هر دو را با هم می‌دهیم: یکی برای امروز، یکی برای آینده.",
    "TIG و واکسن باید با **سرنگ جدا و در دو محل آناتومیک متفاوت** تزریق شوند.",
]
WHY_EN = [
    "The toxoid builds ACTIVE immunity but takes days; it does not cover today's wound.",
    "TIG gives immediate PASSIVE immunity, neutralising toxin still circulating.",
    "TIG cannot neutralise toxin already bound to nerve endings, so give it early.",
    "That is why a non-immune patient with a dirty wound gets both: one for today, one for the future.",
    "TIG and the vaccine must go in SEPARATE syringes at SEPARATE anatomical sites.",
]

# ---------------------------------------------------------------- idx 368
# Farmer, NO vaccination history, deep foot laceration in a field.
# <3 doses + dirty wound  =>  vaccine AND TIG. Book key agrees.
add("book:368", "case", "medium",
 "سابقه‌ی واکسن **ندارد** و زخم عمیقِ مزرعه است ← این یعنی **هم واکسن و هم تتابولین**، با هم.",
 "He has NO vaccination history and a deep farmyard wound, so he needs BOTH the vaccine AND TIG.",
 STEP_FA + TABLE_FA + WHY_FA + [
  "در این بیمار گام یک: «بدون سابقه‌ی واکسیناسیون» ← یعنی صفر دوز، پس ستون «کمتر از سه دوز».",
  "گام دو: بریدگی عمیق کف پا هنگام کار در مزرعه ← خاک و کود ← قطعاً «زخم کثیف».",
  "دام سؤال اینجاست: می‌نویسد «زخم تمیز بوده و علائم التهابی ندارد».",
  "«تمیز به‌نظر رسیدن» با «زخم تمیزِ تعریفی» یکی نیست؛ ملاک مکانیسم و آلودگی است نه ظاهر.",
  "زخم عمیقِ نافذ در محیط کشاورزی، حتی اگر شسته و بی‌ترشح باشد، زخم مستعد کزاز است.",
  "پس گام سه: صفر دوز + زخم کثیف ← واکسن + TIG.",
  "دلیل واکسن: این فرد اصلاً ایمنی پایه ندارد و باید سری اولیه‌ی سه‌دوزی را شروع کند.",
  "دلیل TIG: تا واکسن اثر کند چند روز طول می‌کشد و او در این فاصله کاملاً بی‌دفاع است.",
  "یک دوز واکسن به‌تنهایی در فرد کاملاً واکسینه‌نشده تقریباً هیچ محافظتی نمی‌دهد.",
  "آنتی‌بیوتیک پیشگیرانه برای کزاز توصیه **نمی‌شود**؛ شست‌وشو و دبریدمان جای آن را می‌گیرد.",
  "بعد از این ویزیت باید دوز دوم را ۴ هفته و دوز سوم را ۶ تا ۱۲ ماه بعد کامل کند.",
 ],
 STEP_EN + TABLE_EN + WHY_EN + [
  "Step 1 here: 'no history of vaccination' means zero doses, so the 'fewer than three' column.",
  "Step 2: a deep sole laceration sustained working in a field means soil and manure — a dirty wound.",
  "The trap: the stem says the wound 'looks clean with no inflammatory signs'.",
  "Looking clean is not the same as the defined 'clean, minor wound'; mechanism and contamination decide.",
  "A deep penetrating wound in a farm setting is tetanus-prone even after washing.",
  "So step 3: zero doses + dirty wound gives vaccine plus TIG.",
  "The vaccine is needed because he has no baseline immunity and must start the three-dose primary series.",
  "TIG is needed because the vaccine takes days to work and he is defenceless in the meantime.",
  "A single vaccine dose in a completely unvaccinated person confers almost no protection.",
  "Prophylactic antibiotics are NOT recommended for tetanus; cleaning and debridement replace them.",
  "After this visit he must complete dose two at four weeks and dose three at six to twelve months.",
 ],
 "این سؤال، خانه‌ی سمت راستِ پایینِ جدول را می‌سنجد: **سابقه‌ی ناکافی + زخم مستعد کزاز ← هر دو**. نکته‌ی ظریف، عبارت «در معاینه زخم او تمیز بوده» است. این عبارت **ظاهر** زخم را توصیف می‌کند، نه دسته‌ی آن. «زخم تمیز و سطحی» یک اصطلاح تعریف‌شده است و بریدگی **عمیقِ** کف پا در مزرعه در آن نمی‌گنجد؛ زخم نافذ، آلودگی با خاک، و بافت کم‌اکسیژن دقیقاً شرایط جوانه‌زدن اسپور کلستریدیوم تتانی است. پس هم توکسوئید (برای ساختن ایمنی آینده و شروع سری اولیه) و هم تتابولین (برای محافظت **همین امروز**) لازم است.",
 "This question probes the bottom-right cell of the table: inadequate history plus a tetanus-prone wound means BOTH. The subtlety is the phrase 'the wound looks clean on examination'. That describes the wound's APPEARANCE, not its category. 'Clean, minor wound' is a defined term, and a DEEP sole laceration acquired in a field does not qualify: a penetrating wound, soil contamination and poorly oxygenated tissue are exactly the conditions in which Clostridium tetani spores germinate. So he needs both the toxoid (to build future immunity and start the primary series) and TIG (to protect him TODAY).",
 ["تتابولین به‌تنهایی ایمنی آینده نمی‌سازد؛ این فرد سری اولیه‌ی واکسن را هم لازم دارد.",
  "واکسن به‌تنهایی چند روز طول می‌کشد تا اثر کند و زخم امروز را پوشش نمی‌دهد.",
  "آنتی‌بیوتیک برای پیشگیری از کزاز توصیه نمی‌شود؛ و واکسنِ تنها هم کافی نیست.",
  "پاسخ صحیح — سابقه‌ی صفر + زخم عمیق مزرعه ← تتابولین برای امروز و واکسن برای آینده."],
 ["TIG alone builds no future immunity; this man also needs the primary vaccine series.",
  "The vaccine alone takes days to work and does not cover today's wound.",
  "Antibiotics are not recommended for tetanus prophylaxis, and vaccine alone is insufficient.",
  "Correct — zero history plus a deep farm wound means TIG for today and vaccine for the future."],
 "سابقه‌ی ناکافی + زخم کثیف ← واکسن **و** تتابولین. «تمیز به‌نظر رسیدن» زخم را از دسته‌ی مستعد خارج نمی‌کند.",
 "Inadequate history plus a dirty wound means vaccine AND TIG. Looking clean does not make a wound clean.",
 [f"{H} — Ch. 304: Tetanus", CDC])

# ---------------------------------------------------------------- idx 371
# Child, COMPLETE vaccination, rusty-nail hand wound => nothing needed.
add("book:371", "case", "medium",
 "واکسیناسیون **کامل** است ← میخ زنگ‌زده هم باشد، **هیچ اقدامی لازم نیست**.",
 "His vaccination is COMPLETE, so even with a rusty nail, NO tetanus measure is required.",
 STEP_FA + TABLE_FA + WHY_FA + [
  "گام یک: «سوابق واکسیناسیون کودک کامل است» ← سه دوز یا بیشتر، ستون چپ جدول.",
  "گام دو: جراحت با میخ زنگ‌زده ← زخم نافذ ← «زخم کثیف».",
  "گام سه: سه دوز یا بیشتر + زخم کثیف ← واکسن فقط اگر ۵ سال گذشته باشد.",
  "این کودک ۸ ساله است و برنامه‌ی واکسیناسیون کشوری آخرین دوز را در ۶ سالگی می‌دهد.",
  "پس حدود ۲ سال از آخرین دوز گذشته — کمتر از ۵ سال — و واکسن هم لازم نیست.",
  "و چون سه دوز یا بیشتر دارد، TIG در هیچ حالتی لازم نیست.",
  "افسانه‌ی رایج: «میخ زنگ‌زده یعنی حتماً آمپول کزاز». زنگ‌زدگی خودش عامل خطر نیست.",
  "خطر از **اسپور موجود در خاک** می‌آید که روی میخ نشسته، نه از اکسید آهن.",
  "تنها کار لازم در این کودک، شست‌وشوی کامل زخم و خارج کردن اجسام خارجی است.",
  "تجویز غیرضروری و مکرر توکسوئید، خطر واکنش حساسیتی نوع آرتوس را بالا می‌برد.",
  "درس عملی: قبل از تجویز، دو عدد را بپرس — چند دوز؟ چند سال؟",
 ],
 STEP_EN + TABLE_EN + WHY_EN + [
  "Step 1: 'the child's vaccination record is complete' means three or more doses — the left column.",
  "Step 2: a rusty-nail injury is a puncture wound, so 'dirty'.",
  "Step 3: three or more doses plus a dirty wound means vaccine only if five years have passed.",
  "This child is eight and the national schedule gives the last dose at age six.",
  "So roughly two years have passed — under five — and no vaccine is needed either.",
  "And because he has three or more doses, TIG is not indicated under any circumstances.",
  "A common myth: 'a rusty nail always means a tetanus shot'. Rust itself is not the risk factor.",
  "The risk comes from SOIL SPORES on the nail, not from iron oxide.",
  "The only action required here is thorough wound cleaning and removal of foreign material.",
  "Unnecessary repeat toxoid doses increase the risk of an Arthus-type hypersensitivity reaction.",
  "Practical lesson: before prescribing, ask two numbers — how many doses, and how many years?",
 ],
 "این سؤال عمداً یک محرک احساسی می‌گذارد — «میخ زنگ زده» — تا ببیند آیا دانشجو جدول را می‌خواند یا از روی ترس تجویز می‌کند. زنگ‌زدگی هیچ نقشی در پاتوژنز ندارد؛ خطر از اسپور *Clostridium tetani* در خاکِ چسبیده به میخ می‌آید. وقتی سری اولیه کامل باشد، آنتی‌توکسین محافظ دست‌کم ۱۰ سال باقی می‌ماند و در زخم مستعد هم تا ۵ سال نیازی به یادآور نیست. این کودک ۸ ساله آخرین دوز را حدود ۲ سال قبل گرفته، پس در هر دو حساب ایمن است. تتابولین هم که با داشتن سه دوز یا بیشتر **هرگز** جایی ندارد. تنها اقدام درست، مراقبت از خود زخم است.",
 "This question deliberately plants an emotive trigger — 'a rusty nail' — to see whether the student reads the table or prescribes out of fear. Rust plays no part in the pathogenesis; the risk comes from Clostridium tetani spores in the soil clinging to the nail. Once the primary series is complete, protective antitoxin persists for at least ten years, and even for a tetanus-prone wound no booster is needed within five years. This eight-year-old had his last dose about two years ago, so he is covered on both counts. TIG has NO place at all once three or more doses have been given. The only correct action is wound care itself.",
 ["تتابولین با سابقه‌ی کامل هرگز لازم نیست، و واکسن هم در این فاصله‌ی زمانی لازم نیست.",
  "پاسخ صحیح — سری کامل و کمتر از ۵ سال از آخرین دوز؛ فقط شست‌وشوی زخم.",
  "تتابولین فقط برای سابقه‌ی ناکافی یا نامعلوم با زخم کثیف است، نه این کودک.",
  "یادآور زودتر از موعد فایده‌ای ندارد و خطر واکنش آرتوس را بالا می‌برد."],
 ["TIG is never needed with a complete history, and no vaccine is due within this interval.",
  "Correct — complete series and under five years since the last dose; wound care only.",
  "TIG is only for an inadequate or unknown history with a dirty wound, not this child.",
  "An early booster adds nothing and raises the risk of an Arthus reaction."],
 "میخ زنگ‌زده ترسناک است ولی تصمیم‌ساز نیست. سری کامل + کمتر از ۵ سال ← هیچ اقدامی.",
 "A rusty nail is alarming but not decisive. Complete series plus under five years means no action.",
 [f"{H} — Ch. 304: Tetanus", CDC])

# ---------------------------------------------------------------- idx 373
# Rat bite, last tetanus dose 3 years ago => nothing needed.
add("book:373", "case", "medium",
 "آخرین دوز **۳ سال** قبل بوده ← حتی با گزش حیوان، **هیچ اقدامی لازم نیست**.",
 "His last dose was THREE years ago, so even with an animal bite NO action is needed.",
 STEP_FA + TABLE_FA + WHY_FA + [
  "گام یک: «آخرین دوز واکسن کزاز را سه سال قبل دریافت کرده» ← یعنی واکسینه است، ستون چپ.",
  "گام دو: گزش موش ← بزاق حیوان ← «زخم کثیف».",
  "گام سه: واکسینه + زخم کثیف ← واکسن فقط اگر **۵ سال یا بیشتر** گذشته باشد.",
  "۳ سال کمتر از ۵ سال است، پس حتی یادآور هم لازم نیست.",
  "و TIG با سابقه‌ی کامل در هیچ نوع زخمی جایی ندارد.",
  "شایع‌ترین خطای این سؤال، قاطی کردن آستانه‌ی ۵ سال با آستانه‌ی ۱۰ سال است.",
  "۱۰ سال مالِ زخم تمیز است؛ ۵ سال مالِ زخم کثیف. این دو را نباید جابه‌جا کرد.",
  "اینکه زخم «کثیف» است فقط آستانه را از ۱۰ به ۵ می‌آورد — خودش تجویز نمی‌سازد.",
  "هشدار مهم: در گزش، خطر اصلی معمولاً **کزاز نیست**؛ هاری و عفونت باکتریایی زخم است.",
  "در گزش جونده (موش، سنجاب) پروفیلاکسی هاری در اغلب راهنماها لازم نیست.",
  "ولی شست‌وشوی فراوان زخم و ارزیابی نیاز به آنتی‌بیوتیک همچنان ضروری است.",
 ],
 STEP_EN + TABLE_EN + WHY_EN + [
  "Step 1: 'last tetanus dose three years ago' means he is vaccinated — the left column.",
  "Step 2: a rat bite involves animal saliva, so 'dirty'.",
  "Step 3: vaccinated plus dirty wound means vaccine only if FIVE or more years have passed.",
  "Three years is under five, so not even a booster is required.",
  "And TIG has no role in any wound type once the history is complete.",
  "The commonest error on this question is confusing the five-year and ten-year thresholds.",
  "Ten years applies to clean wounds, five to dirty ones; they must not be swapped.",
  "The wound being dirty only lowers the threshold from ten to five — it does not by itself mandate a dose.",
  "Important caveat: after a bite the main risk is usually NOT tetanus but rabies and wound infection.",
  "For rodent bites (rat, squirrel) most guidelines do not require rabies prophylaxis.",
  "But copious wound irrigation and assessment for antibiotics remain essential.",
 ],
 "این سؤال دقیقاً همان تله‌ای را می‌گذارد که در عمل بالینی بیشترین خطا را می‌سازد: قاطی کردن دو آستانه. زخم گزش، «زخم کثیف» است و همین باعث می‌شود آستانه از ۱۰ سال به **۵ سال** بیاید — ولی این بیمار فقط **۳ سال** پیش واکسن گرفته، پس هنوز داخل پنجره‌ی محافظت است و نه یادآور لازم دارد و نه تتابولین. توجه کنید که «زخم کثیف» بودن به‌تنهایی دستور تجویز نیست؛ فقط عددِ مقایسه را عوض می‌کند. نکته‌ی بالینی مهم دیگر: در گزش حیوان، آنچه واقعاً باید نگرانش بود معمولاً هاری و عفونت زخم است، نه کزاز — هرچند در گزش جونده‌ها پروفیلاکسی هاری معمولاً اندیکاسیون ندارد.",
 "This question sets exactly the trap that causes most real-world errors: confusing the two thresholds. A bite is a dirty wound, which lowers the threshold from ten years to FIVE — but this patient was vaccinated only THREE years ago, so he is still inside the protected window and needs neither a booster nor TIG. Note that a wound being dirty is not by itself an instruction to inject; it only changes which number you compare against. Another clinically important point: after an animal bite the real concerns are usually rabies and wound infection rather than tetanus — though for rodent bites rabies prophylaxis is generally not indicated.",
 ["واکسن یادآور فقط پس از ۵ سال در زخم کثیف لازم می‌شود؛ اینجا ۳ سال گذشته است.",
  "تتابولین با سابقه‌ی کامل واکسیناسیون هرگز اندیکاسیون ندارد.",
  "هیچ‌کدام لازم نیست؛ ترکیب هر دو در فرد کاملاً واکسینه توجیهی ندارد.",
  "پاسخ صحیح — فرد واکسینه و تنها ۳ سال از آخرین دوز؛ فقط مراقبت از زخم."],
 ["A booster is due only after five years for a dirty wound; only three have passed here.",
  "TIG is never indicated once the vaccination history is complete.",
  "Neither is needed; combining both in a fully vaccinated person has no justification.",
  "Correct — vaccinated and only three years since the last dose; wound care only."],
 "زخم کثیف آستانه را از ۱۰ به ۵ سال می‌آورد، ولی ۳ سال هنوز داخل پنجره است ← هیچ اقدامی.",
 "A dirty wound lowers the threshold from ten years to five, but three years is still inside the window.",
 [f"{H} — Ch. 304: Tetanus", CDC])

# ---------------------------------------------------------------- idx 378
# Afghan woman, NO childhood vaccination, SUPERFICIAL fingertip cut with a scalpel.
# <3 doses + CLEAN minor wound => vaccine only, NO TIG. Mirror image of idx 368.
add("book:378", "case", "hard",
 "سابقه‌ی واکسن ندارد، ولی زخم **سطحی و تمیز** است ← فقط شروع واکسیناسیون، **بدون** تتابولین.",
 "She has no vaccination history, but the wound is SUPERFICIAL and clean, so start the vaccine WITHOUT TIG.",
 STEP_FA + TABLE_FA + WHY_FA + [
  "گام یک: «سابقه‌ی واکسیناسیون در کودکی ندارد» ← ستون «کمتر از سه دوز».",
  "گام دو: بریدگی **سطحی** با تیغ بیستوری تمیز در نوک انگشت ← «زخم تمیز و سطحی».",
  "گام سه: کمتر از سه دوز + زخم تمیز ← **واکسن بله، TIG خیر**.",
  "این سؤال جفتِ آینه‌ای سؤال کشاورز است؛ همان ستون، ولی سطر دیگر.",
  "در کشاورز زخم عمیق و آلوده بود ← TIG لازم شد. اینجا زخم سطحی و تمیز است ← نمی‌شود.",
  "قاعده‌ی مطلق: **TIG هرگز برای زخم تمیز و سطحی تجویز نمی‌شود** — در هیچ سابقه‌ای.",
  "تیغ بیستوری وسیله‌ای استریل است و بریدگی نوک انگشت نه نافذ عمیق است و نه آلوده به خاک.",
  "پس این زخم واقعاً در دسته‌ی «تمیز و سطحی» می‌نشیند، برخلاف سؤال کشاورز.",
  "ولی چون او هیچ ایمنی پایه‌ای ندارد، باید همین حالا سری واکسیناسیون بزرگسال شروع شود.",
  "سری کامل: دوز اول امروز، دوز دوم ۴ هفته بعد، دوز سوم ۶ تا ۱۲ ماه بعد.",
  "در بزرگسال، واکسن توأم بزرگسال (Td) یا Tdap استفاده می‌شود، نه واکسن کودکان.",
  "مهاجر بودن بیمار یک نکته‌ی بهداشت عمومی است: فرصت را برای کامل کردن واکسن‌ها از دست ندهید.",
 ],
 STEP_EN + TABLE_EN + WHY_EN + [
  "Step 1: 'no childhood vaccination' puts her in the 'fewer than three doses' column.",
  "Step 2: a SUPERFICIAL cut from a clean scalpel on a fingertip is a 'clean, minor wound'.",
  "Step 3: fewer than three doses plus a clean wound means vaccine YES, TIG NO.",
  "This is the mirror image of the farmer question: same column, different row.",
  "The farmer's wound was deep and contaminated, so TIG was needed; here it is superficial and clean.",
  "Absolute rule: TIG is NEVER given for a clean, minor wound, whatever the vaccination history.",
  "A scalpel is a sterile instrument and a fingertip cut is neither deeply penetrating nor soil-contaminated.",
  "So this wound genuinely sits in the 'clean and minor' category, unlike the farmer's.",
  "But because she has no baseline immunity, the adult vaccination series must start today.",
  "Full series: first dose now, second at four weeks, third at six to twelve months.",
  "In adults use the adult tetanus-diphtheria vaccine (Td) or Tdap, not the paediatric formulation.",
  "Her migrant status is a public-health cue: do not miss the chance to complete her vaccinations.",
 ],
 "این سؤال را باید کنار سؤال کشاورز خواند؛ با هم، ستون «سابقه‌ی ناکافی» را کامل می‌کنند. هر دو بیمار **صفر دوز** واکسن دارند، ولی جوابشان فرق می‌کند و تنها تفاوت، **نوع زخم** است. اینجا بریدگی **سطحی** با تیغ بیستوری تمیز در نوک انگشت است: نه نافذ، نه آلوده به خاک، نه با بافت نکروتیک. پس در دسته‌ی «تمیز و سطحی» می‌نشیند و قاعده‌ی مطلق CDC صادق است: **تتابولین هرگز برای زخم تمیز و سطحی داده نمی‌شود**، حتی اگر بیمار اصلاً واکسن نزده باشد. ولی نداشتن ایمنی پایه یک مشکل واقعی است، پس همین حالا سری واکسیناسیون توأم بزرگسال شروع می‌شود و با دوز دوم در ۴ هفته و سوم در ۶ تا ۱۲ ماه کامل می‌گردد.",
 "Read this alongside the farmer question; together they complete the 'inadequate history' column. Both patients have ZERO doses, yet the answers differ, and the only difference is the WOUND. Here it is a SUPERFICIAL scalpel cut on a fingertip: not penetrating, not soil-contaminated, no devitalised tissue. It therefore sits in the 'clean and minor' category, where the CDC's absolute rule applies: TIG is NEVER given for a clean minor wound, even in a completely unvaccinated patient. But the absent baseline immunity is a real problem, so the adult Td series starts today and is completed with a second dose at four weeks and a third at six to twelve months.",
 ["تتابولین برای زخم تمیز و سطحی هرگز اندیکاسیون ندارد، حتی در فرد واکسینه‌نشده.",
  "پاسخ صحیح — زخم تمیز و سطحی، پس فقط شروع سری واکسیناسیون بزرگسال بدون تتابولین.",
  "افزودن تتابولین به زخم تمیز، تجویز اضافی است و در راهنماها جایی ندارد.",
  "تتابولین به‌تنهایی هم ایمنی آینده نمی‌سازد و هم برای زخم تمیز اندیکاسیون ندارد."],
 ["TIG is never indicated for a clean, minor wound, even in an unvaccinated person.",
  "Correct — a clean superficial wound, so start the adult series alone, without TIG.",
  "Adding TIG to a clean wound is over-treatment with no place in the guidelines.",
  "TIG alone builds no future immunity and is not indicated for a clean wound anyway."],
 "TIG **هرگز** برای زخم تمیز و سطحی داده نمی‌شود — حتی با صفر دوز واکسن. فقط سری را شروع کن.",
 "TIG is NEVER given for a clean, minor wound — even with zero prior doses. Just start the series.",
 [f"{H} — Ch. 304: Tetanus", CDC])

# ---------------------------------------------------------------- idx 382  KEY CORRECTED
# 31-year-old, COMPLETE series, last dose at 20 => 11 years, major thigh laceration.
# Book prints "TIG + toxoid". CDC/Harrison: >=3 doses => TIG is NEVER indicated.
add("book:382", "case", "hard",
 "⚠️ **کلید این سؤال تصحیح شده است.** سری واکسن **کامل** است ← فقط **توکسوئید**؛ تتابولین لازم نیست.",
 "WARNING: the printed key has been CORRECTED. His series is complete, so toxoid ALONE; no TIG.",
 STEP_FA + TABLE_FA + WHY_FA + [
  "گام یک: «سابقه‌ی واکسیناسیون کامل کزاز» ← سه دوز یا بیشتر ← ستون چپ جدول.",
  "گام دو: پارگی وسیع ران در تصادف ← بافت له‌شده و آلودگی ← «زخم کثیف».",
  "گام سه: سه دوز یا بیشتر + زخم کثیف ← توکسوئید اگر ۵ سال گذشته باشد؛ **TIG هرگز**.",
  "حساب زمان: آخرین دوز در ۲۰ سالگی، اکنون ۳۱ ساله ← **۱۱ سال** گذشته.",
  "۱۱ سال بیشتر از ۵ سال است، پس یک دوز توکسوئید یادآور **لازم است**.",
  "ولی تتابولین لازم **نیست**، چون سری اولیه کامل است و حافظه‌ی ایمنی وجود دارد.",
  "⚠️ کلید چاپی کتاب «تتابولین و توکسوئید» است که با راهنمای CDC و هریسون نمی‌خواند.",
  "جدول ۳۰۴-۱ هریسون در ستون TIG برای «سه دوز یا بیشتر» در هر دو نوع زخم «خیر» می‌نویسد.",
  "CDC هم صریح است: TIG فقط برای سابقه‌ی نامعلوم، کمتر از سه دوز، HIV یا نقص ایمنی شدید.",
  "منطق ایمنی‌شناختی: فرد با سری کامل، سلول خاطره دارد و ظرف چند روز تیتر را بالا می‌برد.",
  "این پاسخ سریع آنامنستیک، همان چیزی است که TIG را غیرضروری می‌کند.",
  "تنها استثنا نقص ایمنی است؛ این بیمار جوان سالم چنین شرایطی ندارد.",
  "درس عملی: «زخم بزرگ» به‌تنهایی مجوز TIG نیست؛ **سابقه‌ی واکسن** تعیین‌کننده است.",
 ],
 STEP_EN + TABLE_EN + WHY_EN + [
  "Step 1: 'complete tetanus vaccination history' means three or more doses — the left column.",
  "Step 2: an extensive thigh laceration from a road accident means crushed tissue and contamination — dirty.",
  "Step 3: three or more doses plus a dirty wound means toxoid if five years have passed; TIG never.",
  "Do the arithmetic: last dose at age 20, now 31, so ELEVEN years have passed.",
  "Eleven exceeds five, so a booster dose of toxoid IS required.",
  "But TIG is NOT, because the primary series is complete and immune memory exists.",
  "WARNING: the book prints 'TIG and toxoid', which conflicts with both CDC and Harrison.",
  "Harrison's Table 304-1 puts 'No' in the TIG column for three or more doses, for BOTH wound types.",
  "CDC is explicit: TIG is only for unknown history, fewer than three doses, HIV or severe immunodeficiency.",
  "The immunological logic: someone with a complete series has memory cells and raises titre within days.",
  "That rapid anamnestic response is precisely what makes TIG unnecessary.",
  "The only exception is immunodeficiency, and this healthy young man has no such condition.",
  "Practical lesson: a big wound alone does not license TIG; the VACCINATION HISTORY decides.",
 ],
 "⚠️ **توجه: کلید چاپی کتاب در این سؤال تصحیح شده است.** کتاب گزینه‌ی «تتابولین و توکسوئید» را درست دانسته، ولی این پاسخ با راهنمای CDC و جدول ۳۰۴-۱ هریسون در تضاد است.\n\nحساب کنید: بیمار **۳۱** ساله است و آخرین دوز را در **۲۰** سالگی گرفته، پس **۱۱ سال** گذشته. سابقه‌ی او **کامل** است (سه دوز یا بیشتر) و زخم «کثیف» محسوب می‌شود. در این خانه از جدول، آستانه ۵ سال است و ۱۱ سال از آن گذشته، پس **یک دوز توکسوئید یادآور لازم است**. اما ستون TIG برای «سه دوز یا بیشتر» در هر دو نوع زخم **«خیر»** است.\n\nچرا؟ چون کسی که سری اولیه را کامل کرده، سلول خاطره‌ی ایمنی دارد و پس از تزریق یادآور ظرف چند روز تیتر آنتی‌توکسین را به سطح محافظ می‌رساند؛ این پاسخ آنامنستیک همان چیزی است که ایمنی غیرفعال را غیرضروری می‌کند. TIG را برای کسی نگه می‌داریم که این حافظه را **ندارد**: سابقه‌ی نامعلوم، کمتر از سه دوز، یا نقص ایمنی شدید و HIV. پس پاسخ درست **توکسوئید به‌تنهایی** است.",
 "WARNING: the book's printed key for this question has been CORRECTED. The book marks 'TIG and toxoid' as correct, but that conflicts with CDC guidance and Harrison's Table 304-1.\n\nDo the arithmetic: the patient is 31 and had his last dose at 20, so ELEVEN years have passed. His history is COMPLETE (three or more doses) and the wound counts as dirty. In that cell of the table the threshold is five years, and eleven exceeds it, so a booster dose of toxoid IS required. But the TIG column reads 'No' for three or more doses, for BOTH wound types.\n\nWhy? Because someone who completed the primary series has immune memory and, after a booster, raises antitoxin to protective levels within days; that anamnestic response is exactly what makes passive immunity unnecessary. TIG is reserved for people who LACK that memory: unknown history, fewer than three doses, or severe immunodeficiency and HIV. The correct answer is therefore toxoid ALONE.",
 ["تتابولین با سری کامل واکسیناسیون اندیکاسیون ندارد و به‌تنهایی هم ایمنی آینده نمی‌سازد.",
  "پاسخ صحیح (کلید تصحیح‌شده) — سری کامل و ۱۱ سال گذشته: فقط یک دوز توکسوئید یادآور.",
  "کلید چاپی کتاب؛ افزودن تتابولین در فرد با سری کامل با CDC و هریسون در تضاد است.",
  "اقدام لازم است: ۱۱ سال از آخرین دوز گذشته و در زخم کثیف آستانه ۵ سال است."],
 ["TIG is not indicated with a complete series and alone would build no future immunity.",
  "Correct (corrected key) — complete series and eleven years elapsed: a single booster toxoid.",
  "This is the book's printed key; adding TIG with a complete series contradicts CDC and Harrison.",
  "Action IS needed: eleven years have passed and the dirty-wound threshold is five years."],
 "سری کامل ← TIG هرگز. ۱۱ سال گذشته ← یک دوز توکسوئید. «زخم بزرگ» مجوز TIG نیست.",
 "Complete series means TIG never. Eleven years elapsed means one toxoid dose. A big wound does not license TIG.",
 [f"{H} — Ch. 304: Tetanus, Table 304-1", CDC])

# ---------------------------------------------------------------- idx 364
# Pregnant, NO tetanus history => two TT doses one month apart. Core WHO rule.
PREG_FA = [
  "کزاز نوزادی از آلوده شدن بند ناف با اسپور کلستریدیوم تتانی هنگام زایمان غیربهداشتی می‌آید.",
  "نوزاد خودش ایمنی ندارد؛ تنها سپر او **آنتی‌بادی مادر** است که از جفت عبور می‌کند.",
  "پس راهبرد پیشگیری، واکسیناسیون **مادر** در بارداری است، نه اقدام روی نوزاد.",
  "قاعده‌ی WHO: مادر باردار با سابقه‌ی نامعلوم یا صفر، دست‌کم **دو دوز** TTCV بگیرد.",
  "فاصله‌ی این دو دوز باید حداقل **۴ هفته** باشد تا پاسخ ایمنی تقویتی شکل بگیرد.",
  "دوز دوم باید دست‌کم **۲ هفته پیش از زایمان** تزریق شود تا آنتی‌بادی وقت عبور از جفت داشته باشد.",
  "یک دوز تنها کافی **نیست**: پاسخ اولیه ضعیف است و تیتر محافظ به نوزاد نمی‌رسد.",
  "سه دوز در همین بارداری هم لازم نیست؛ دوز سوم ۶ ماه تا ۱ سال بعد یا در بارداری بعدی داده می‌شود.",
  "برنامه‌ی کامل مادر در طول سنین باروری **پنج دوز** است تا محافظت بلندمدت ایجاد شود.",
  "واکسن کزاز در بارداری **کنترااندیکه نیست**؛ توکسوئید است، ویروس زنده نیست.",
  "ایمونوگلوبولین (تتابولین) در این سناریوی پیشگیری روتین جایی ندارد؛ زخمی در کار نیست.",
  "دادن TIG به نوزاد پس از تولد، جایگزین واکسیناسیون مادر نمی‌شود و راهبرد استاندارد نیست.",
]
PREG_EN = [
  "Neonatal tetanus arises when the umbilical stump is contaminated with C. tetani spores at an unclean delivery.",
  "The newborn has no immunity of its own; its only shield is MATERNAL antibody crossing the placenta.",
  "So the prevention strategy is to vaccinate the MOTHER during pregnancy, not to treat the baby.",
  "WHO rule: a pregnant woman with unknown or zero history should receive at least TWO doses of a tetanus vaccine.",
  "The interval between those doses must be at least FOUR weeks for a boosting response to develop.",
  "The second dose should be at least TWO weeks before delivery so antibody has time to cross the placenta.",
  "One dose is NOT enough: the primary response is weak and no protective titre reaches the baby.",
  "Three doses in this pregnancy are not required either; the third comes six to twelve months later or next pregnancy.",
  "The complete maternal programme across the reproductive years is FIVE doses for long-term protection.",
  "Tetanus vaccine is NOT contraindicated in pregnancy; it is a toxoid, not a live virus.",
  "Immunoglobulin has no place in this routine prophylaxis scenario — there is no wound.",
  "Giving the newborn TIG after birth does not substitute for maternal vaccination and is not the standard strategy.",
]

add("book:364", "recall", "medium",
 "باردار و بدون سابقه‌ی واکسن ← **دو دوز** توکسوئید کزاز به فاصله‌ی حداقل **۴ هفته** (یک ماه).",
 "Pregnant with no vaccination history: TWO doses of tetanus toxoid at least FOUR weeks apart.",
 PREG_FA + [
  "در بسیاری از کشورها یک دوز Tdap در هفته‌ی ۲۷ تا ۳۶ هم برای محافظت از سیاه‌سرفه اضافه می‌شود.",
 ],
 PREG_EN + [
  "Many countries add a Tdap dose at 27 to 36 weeks for pertussis protection as well.",
 ],
 "این سؤال، ستون فقرات برنامه‌ی حذف کزاز نوزادی است. نوزاد در بدو تولد هیچ ایمنی فعالی ندارد و تنها چیزی که از او محافظت می‌کند، **آنتی‌بادی مادری** است که از جفت می‌گذرد. بنابراین کل راهبرد روی **مادر** متمرکز است. قاعده‌ی WHO ساده و قابل شمردن است: مادر با سابقه‌ی صفر یا نامعلوم، **دو دوز** توکسوئید با فاصله‌ی حداقل **۴ هفته** می‌گیرد و دوز دوم باید دست‌کم دو هفته پیش از زایمان باشد. یک دوز کافی نیست چون پاسخ اولیه ضعیف است. سه دوز در همین بارداری هم لازم نیست — دوز سوم و بعدی‌ها بعداً یا در بارداری‌های بعدی کامل می‌شوند تا در مجموع به پنج دوز برسد. و تتابولین اینجا اصلاً موضوعیت ندارد: بیمار زخمی ندارد، بحث پیشگیری برنامه‌ای است نه مدیریت زخم.",
 "This question is the backbone of the neonatal tetanus elimination programme. A newborn has no active immunity, and the only thing protecting it is MATERNAL antibody crossing the placenta. The whole strategy therefore targets the MOTHER. The WHO rule is simple and countable: a mother with zero or unknown history receives TWO toxoid doses at least FOUR weeks apart, with the second at least two weeks before delivery. One dose is not enough because the primary response is weak. Three doses in this pregnancy are not required either — the third and later doses are completed afterwards or in subsequent pregnancies, reaching five in total. TIG is simply not relevant here: there is no wound; this is programmatic prophylaxis, not wound management.",
 ["پاسخ صحیح — دو دوز توکسوئید با فاصله‌ی یک ماه، قاعده‌ی استاندارد WHO در بارداری.",
  "سه دوز در همین بارداری لازم نیست؛ دوز سوم بعداً یا در بارداری بعدی داده می‌شود.",
  "یک دوز تنها پاسخ ایمنی کافی نمی‌سازد و تیتر محافظ به نوزاد نمی‌رساند.",
  "افزودن ایمونوگلوبولین در پیشگیری برنامه‌ای بارداری اندیکاسیون ندارد؛ زخمی در کار نیست."],
 ["Correct — two toxoid doses one month apart, the standard WHO rule in pregnancy.",
  "Three doses in this pregnancy are unnecessary; the third comes later or next pregnancy.",
  "A single dose does not mount an adequate response or deliver a protective titre to the baby.",
  "Adding immunoglobulin to routine antenatal prophylaxis is not indicated; there is no wound."],
 "باردار بدون سابقه ← **۲ دوز** توکسوئید، فاصله‌ی **۴ هفته**، دوز دوم ≥۲ هفته پیش از زایمان.",
 "Pregnant with no history means TWO toxoid doses, FOUR weeks apart, the second at least two weeks pre-delivery.",
 [f"{H} — Ch. 304: Tetanus", WHO])

# ---------------------------------------------------------------- idx 366
# Pregnant, childhood primary doses only, no boosters => two doses 4 weeks apart.
add("book:366", "case", "hard",
 "فقط واکسن‌های **دوران کودکی** را دارد و بوستر نگرفته ← **۲ دوز** به فاصله‌ی **۴ هفته**.",
 "She has only her CHILDHOOD doses and no boosters, so TWO doses FOUR weeks apart.",
 PREG_FA + [
  "این سؤال یک لایه سخت‌تر از حالت «هیچ سابقه‌ای ندارد» است و باید دقیق خوانده شود.",
  "بیمار سری اولیه‌ی کودکی را گرفته ولی **بوسترها را نگرفته** است.",
  "چرا باز هم دو دوز؟ چون آنتی‌بادی دوران کودکی پس از سال‌ها افت کرده است.",
  "اگر مادر **چهار دوز** در کودکی گرفته باشد، تنها **یک** دوز یادآور کافی است.",
  "پس عدد دوز به سابقه بستگی دارد؛ حفظ کردن یک عدد ثابت اشتباه است.",
  "دقت کنید بیمار در هفته‌ی هشتم بارداری است، یعنی وقت کافی برای هر دو دوز وجود دارد.",
  "سه دوز به فواصل ۰ و ۱ و ۶ ماه، برنامه‌ی سری کامل عمر است نه برنامه‌ی همین بارداری.",
 ],
 PREG_EN + [
  "This is a level harder than the 'no history at all' case and must be read carefully.",
  "She received her childhood primary series but has had NO boosters since.",
  "Why still two doses? Because childhood antibody has waned over the intervening years.",
  "If a mother had FOUR childhood doses, a single booster would suffice.",
  "So the number of doses depends on the history; memorising one fixed number is wrong.",
  "Note she is at eight weeks' gestation, so there is ample time for both doses.",
  "Three doses at 0, 1 and 6 months is the lifetime series schedule, not this pregnancy's plan.",
 ],
 "این نسخه‌ی سخت‌ترِ سؤال بارداری است و تفاوتش در یک عبارت پنهان شده: «فقط واکسن‌های اولیه‌ی دوران کودکی را دریافت نموده ولی بوسترها را نگرفته». یعنی مادر **صفر دوز نیست**، ولی ایمنی‌اش هم به‌روز نیست. قاعده‌ی WHO برای مادری که فقط سه دوز DTP شیرخوارگی دارد همان **دو دوز** با فاصله‌ی **حداقل ۴ هفته** است، چون آنتی‌بادی کودکی افت کرده و دو دوز لازم است تا پاسخ خاطره‌ای احیا و تیتر به سطح قابل انتقال به جنین برسد. توجه کنید که این عدد ثابت نیست: مادری که **چهار** دوز کودکی گرفته باشد تنها به **یک** یادآور نیاز دارد. گزینه‌ی «۳ دوز با فواصل ۰ و ۱ و ۶ ماه» برنامه‌ی سری کامل مادام‌العمر را توصیف می‌کند، نه آنچه در همین بارداری لازم است.",
 "This is the harder version of the pregnancy question, and the difference hides in one phrase: 'received only the primary childhood vaccines but none of the boosters'. So the mother is NOT at zero doses, but her immunity is not current either. The WHO rule for a mother with only three infant DTP doses is the same TWO doses at least FOUR weeks apart, because childhood antibody has waned and two doses are needed to revive the memory response and lift the titre to a level transferable to the fetus. Note the number is not fixed: a mother with FOUR childhood doses needs only ONE booster. The option '3 doses at 0, 1 and 6 months' describes the lifetime series, not what this pregnancy requires.",
 ["پاسخ صحیح — دو دوز به فاصله‌ی ۴ هفته؛ سری کودکی افت کرده و به دو دوز احیاکننده نیاز است.",
  "برنامه‌ی ۰ و ۱ و ۶ ماه توصیف سری کامل مادام‌العمر است، نه نیاز همین بارداری.",
  "یک دوز در مادری که سال‌ها بوستر نگرفته، تیتر کافی برای انتقال به جنین نمی‌سازد.",
  "سه دوز با فاصله‌ی ۴ هفته برنامه‌ی استانداردی نیست؛ دوز سوم باید ۶ ماه تا ۱ سال بعد باشد."],
 ["Correct — two doses four weeks apart; the childhood series has waned and needs two doses to revive it.",
  "The 0, 1 and 6 month schedule describes the lifetime series, not this pregnancy's requirement.",
  "One dose in a mother years past her boosters will not raise a titre transferable to the fetus.",
  "Three doses four weeks apart is not a standard schedule; the third belongs at six to twelve months."],
 "سری کودکی بدون بوستر، در بارداری = **۲ دوز** با فاصله‌ی ۴ هفته. (چهار دوز کودکی = فقط ۱ یادآور.)",
 "Childhood series without boosters, in pregnancy, means TWO doses four weeks apart. Four childhood doses would need only one.",
 [f"{H} — Ch. 304: Tetanus", WHO])

# ---------------------------------------------------------------- idx 367
# Pregnant, no history, asks whether vaccine is contraindicated => it is NOT.
add("book:367", "case", "medium",
 "واکسن کزاز در بارداری **کنترااندیکه نیست** — توکسوئید است، نه ویروس زنده. **۲ دوز، ۴ هفته فاصله**.",
 "Tetanus vaccine is NOT contraindicated in pregnancy — it is a toxoid, not a live virus. TWO doses, four weeks apart.",
 PREG_FA + [
  "این سؤال دو چیز را همزمان می‌سنجد: عدد دوزها، و یک باور غلط رایج.",
  "باور غلط: «چون باردار است، واکسن ممنوع است». این کاملاً نادرست است.",
  "واکسن‌های **زنده‌ی ضعیف‌شده** (سرخک، سرخجه، اوریون، آبله‌مرغان) در بارداری منع دارند.",
  "دلیلش خطر نظری تکثیر ویروس زنده و انتقال به جنین است.",
  "ولی توکسوئید کزاز اصلاً میکروارگانیسم زنده نیست؛ یک سم غیرفعال‌شده است.",
  "بیش از آن: واکسیناسیون کزاز در بارداری نه‌تنها مجاز، بلکه **هدف برنامه‌ی سلامت** است.",
  "بیمار در هفته‌ی سوم بارداری است، پس وقت فراوان برای کامل کردن هر دو دوز دارد.",
 ],
 PREG_EN + [
  "This question tests two things at once: the number of doses, and a common misconception.",
  "The misconception: 'she is pregnant, so vaccines are forbidden'. That is simply wrong.",
  "LIVE attenuated vaccines (measles, rubella, mumps, varicella) are contraindicated in pregnancy.",
  "The reason is the theoretical risk of live viral replication reaching the fetus.",
  "But tetanus toxoid contains no live organism at all; it is an inactivated toxin.",
  "More than that: tetanus vaccination in pregnancy is the very AIM of the health programme.",
  "She is at three weeks' gestation, so there is ample time to complete both doses.",
 ],
 "این سؤال یکی از خطرناک‌ترین باورهای غلط بالینی را هدف گرفته است: «باردار است، پس واکسن نزنیم». آنچه در بارداری منع دارد **واکسن‌های زنده‌ی ضعیف‌شده** است (سرخک، سرخجه، اوریون، آبله‌مرغان)، چون ویروس زنده از نظر تئوری می‌تواند تکثیر یابد و به جنین برسد. اما توکسوئید کزاز **هیچ موجود زنده‌ای ندارد**؛ یک سم غیرفعال‌شده است، پس خطر تکثیر وجود ندارد و در سراسر بارداری بی‌خطر است. در واقع واکسیناسیون کزاز در بارداری نه فقط مجاز بلکه **ستون اصلی برنامه‌ی حذف کزاز نوزادی** است، چون تنها سپر نوزاد آنتی‌بادی مادری عبورکرده از جفت است. برای این بیمار با سابقه‌ی صفر، پاسخ همان قاعده‌ی همیشگی است: **دو دوز با فاصله‌ی حداقل ۴ هفته**. تتابولین هم اینجا جایی ندارد چون زخمی در میان نیست.",
 "This question targets one of the most dangerous clinical misconceptions: 'she is pregnant, so no vaccines'. What is contraindicated in pregnancy is LIVE attenuated vaccines (measles, rubella, mumps, varicella), because live virus could theoretically replicate and reach the fetus. But tetanus toxoid contains NO living organism; it is an inactivated toxin, so there is no replication risk and it is safe throughout pregnancy. In fact tetanus vaccination in pregnancy is not merely permitted but is the CENTREPIECE of the neonatal tetanus elimination programme, because the newborn's only shield is maternal antibody crossing the placenta. For this zero-history patient the answer is the familiar rule: TWO doses at least FOUR weeks apart. TIG has no place here because there is no wound.",
 ["ترکیب واکسن و ایمونوگلوبولین در پیشگیری روتین بارداری اندیکاسیون ندارد؛ زخمی در کار نیست.",
  "پاسخ صحیح — دو دوز واکسن کزاز با فاصله‌ی حداقل ۴ هفته، طبق قاعده‌ی WHO.",
  "نادرست است: واکسن کزاز توکسوئید است نه ویروس زنده، و در بارداری منع مصرف ندارد.",
  "ایمونوگلوبولین به‌تنهایی ایمنی فعال نمی‌سازد و در این سناریو اندیکاسیون ندارد."],
 ["Combining vaccine and immunoglobulin is not indicated in routine antenatal prophylaxis; there is no wound.",
  "Correct — two doses of tetanus vaccine at least four weeks apart, per the WHO rule.",
  "False: tetanus vaccine is a toxoid, not a live virus, and is not contraindicated in pregnancy.",
  "Immunoglobulin alone builds no active immunity and is not indicated in this scenario."],
 "واکسن **زنده** در بارداری ممنوع است، نه توکسوئید. کزاز در بارداری = ۲ دوز، ۴ هفته فاصله.",
 "LIVE vaccines are contraindicated in pregnancy, not toxoids. Tetanus in pregnancy means two doses, four weeks apart.",
 [f"{H} — Ch. 304: Tetanus", WHO])

# ---------------------------------------------------------------- idx 358 / 385
# Tetanus is a CLINICAL diagnosis; no test confirms or excludes it.
DX_FA = [
  "کزاز یک تشخیص **کاملاً بالینی** است؛ هیچ آزمایش تأییدکننده‌ای وجود ندارد.",
  "علت این است که مقدار سمی که بیماری می‌سازد، بسیار کمتر از آستانه‌ی تشخیص آزمایشگاهی است.",
  "تابلوی کلاسیک: تریسموس (قفل شدن فک)، ریسوس سردونیکوس، دیسفاژی، سفتی گردن.",
  "سپس اسپاسم‌های عمومی دردناک و اپیستوتونوس، در حالی که بیمار **کاملاً هوشیار** است.",
  "حفظ هوشیاری یک نکته‌ی کلیدی افتراقی است؛ توکسین سطح هوشیاری را مختل نمی‌کند.",
  "کشت زخم فقط در حدود سی درصد موارد مثبت می‌شود، پس کشت منفی بیماری را رد نمی‌کند.",
  "و کشت مثبت هم تشخیص نمی‌گذارد: باکتری می‌تواند بدون تولید سم در زخم کلونیزه باشد.",
  "اندازه‌گیری آنتی‌توکسین سرم کمکی نیست؛ حتی تیتر محافظ، کزاز را رد نمی‌کند.",
  "PCR در دسترس روتین نیست و حساسیت کافی برای رد کردن بیماری ندارد.",
  "تشخیص‌های افتراقی مهم: آبسه‌ی دندانی، دیستونی دارویی، هیپوکلسمی، مسمومیت با استریکنین.",
  "دیستونی دارویی (مثلاً با متوکلوپرامید) با دیفن‌هیدرامین سریع برطرف می‌شود — تست افتراقی مفیدی است.",
  "درس عملی: منتظر آزمایش نمانید؛ درمان باید بر پایه‌ی شک بالینی فوراً شروع شود.",
]
DX_EN = [
  "Tetanus is a purely CLINICAL diagnosis; no confirmatory laboratory test exists.",
  "The reason is that the amount of toxin needed to cause disease is far below any assay's detection limit.",
  "The classic picture is trismus (lockjaw), risus sardonicus, dysphagia and neck stiffness.",
  "Then painful generalised spasms and opisthotonus, while the patient remains FULLY conscious.",
  "Preserved consciousness is a key discriminator; the toxin does not depress the level of consciousness.",
  "Wound culture is positive in only about thirty per cent of cases, so a negative culture excludes nothing.",
  "A positive culture does not make the diagnosis either: the organism can colonise a wound without making toxin.",
  "Serum antitoxin measurement does not help; even a protective titre does not rule tetanus out.",
  "PCR is not routinely available and lacks the sensitivity needed to exclude the disease.",
  "Important differentials: dental abscess, drug-induced dystonia, hypocalcaemia, strychnine poisoning.",
  "Drug-induced dystonia (for example from metoclopramide) resolves quickly with diphenhydramine — a useful bedside test.",
  "Practical lesson: do not wait for a test; treatment must start immediately on clinical suspicion.",
]

add("book:358", "recall", "easy",
 "کزاز **تشخیص بالینی** است — هیچ کشت، سرولوژی یا PCR آن را تأیید یا رد نمی‌کند.",
 "Tetanus is a CLINICAL diagnosis — no culture, serology or PCR confirms or excludes it.",
 DX_FA, DX_EN,
 "این یکی از معدود بیماری‌هایی است که در آن آزمایشگاه عملاً هیچ کمکی نمی‌کند و همین آن را سؤال‌خیز کرده است. دلیلش زیبا و ساده است: مقدار توکسین کزازی که برای ایجاد بیماری کافی است، آن‌قدر ناچیز است که از آستانه‌ی تشخیص هر روش آزمایشگاهی پایین‌تر می‌ماند. پس تشخیص فقط بر پایه‌ی **تابلوی بالینی** گذاشته می‌شود: تریسموس، ریسوس سردونیکوس، دیسفاژی، سفتی، اسپاسم‌های عمومی دردناک — و مهم‌تر از همه، **هوشیاری کاملاً حفظ‌شده**. کشت زخم فقط در حدود ۳۰٪ مثبت است و مثبت بودنش هم تشخیصی نیست، چون باکتری می‌تواند بدون تولید سم کلونیزه شود. تیتر آنتی‌توکسین هم بیماری را رد نمی‌کند. نتیجه‌ی عملی حیاتی: **منتظر آزمایش نمانید** — درمان با شک بالینی شروع می‌شود.",
 "This is one of the few diseases where the laboratory is essentially useless, which is exactly why examiners like it. The reason is elegant: the quantity of tetanus toxin sufficient to cause disease is far below the detection limit of any assay. So the diagnosis rests on the CLINICAL picture alone: trismus, risus sardonicus, dysphagia, rigidity, painful generalised spasms — and above all, FULLY preserved consciousness. Wound culture is positive in only about 30% of cases, and a positive result is not diagnostic anyway because the organism can colonise without producing toxin. Antitoxin titres do not exclude the disease either. The crucial practical consequence: do NOT wait for a test — treat on clinical suspicion.",
 ["پاسخ صحیح — تشخیص کزاز کاملاً بر پایه‌ی یافته‌های بالینی است، نه آزمایشگاه.",
  "کشت بی‌هوازی زخم فقط حدود ۳۰٪ مثبت می‌شود و مثبت بودنش هم تشخیصی نیست.",
  "تیتر IgG ضد توکسین بیماری را رد نمی‌کند؛ حتی تیتر محافظ کزاز را منتفی نمی‌سازد.",
  "PCR روتین در دسترس نیست و حساسیت لازم برای رد یا تأیید بیماری را ندارد."],
 ["Correct — tetanus is diagnosed entirely on clinical grounds, not in the laboratory.",
  "Anaerobic wound culture is positive in only about 30% and is not diagnostic when it is.",
  "Anti-toxin IgG titres do not exclude the disease; even a protective titre does not rule it out.",
  "PCR is not routinely available and lacks the sensitivity to confirm or exclude tetanus."],
 "کزاز = تشخیص بالینی. کشت منفی ردش نمی‌کند، کشت مثبت اثباتش نمی‌کند. با شک، درمان را شروع کن.",
 "Tetanus is a clinical diagnosis. A negative culture does not exclude it, a positive one does not prove it.",
 [f"{H} — Ch. 304: Tetanus, diagnosis"])

add("book:385", "recall", "medium",
 "پاسخ «هیچ‌کدام» است — چون **هیچ آزمایشی** کزاز را قطعی تشخیص نمی‌دهد.",
 "The answer is 'none of the above', because NO test definitively diagnoses tetanus.",
 DX_FA + [
  "این سؤال همان مفهوم سؤال قبلی است، ولی از زاویه‌ی معکوس پرسیده شده.",
  "وقتی گزینه‌ها همه آزمایشگاهی‌اند و صورت سؤال «به‌طور قطعی» می‌گوید، پاسخ «هیچ‌کدام» است.",
  "دقت کنید که «هیچ‌کدام» اینجا گزینه‌ی فرار نیست؛ واقعاً پاسخ درست پزشکی است.",
 ],
 DX_EN + [
  "This asks the same concept as the previous question, from the opposite direction.",
  "When every option is a laboratory test and the stem says 'definitively', the answer is 'none'.",
  "Note that 'none of the above' is not an escape option here; it is genuinely the right medical answer.",
 ],
 "این سؤال جفتِ معکوس سؤال قبلی است و همان دانش را می‌سنجد. صورت سؤال می‌پرسد کدام روش کزاز را **به‌طور قطعی** تشخیص می‌دهد، و هر سه گزینه‌ی آزمایشگاهی شکست می‌خورند: PCR خون روتین نیست و حساسیت کافی ندارد؛ کشت زخم فقط در حدود ۳۰٪ مثبت می‌شود و مثبت بودنش هم اثبات‌کننده نیست چون کلستریدیوم تتانی می‌تواند بدون تولید سم کلونیزه شود؛ و اندازه‌گیری آنتی‌توکسین سرم حتی در سطح محافظ هم بیماری را رد نمی‌کند. پس «هیچ‌کدام» پاسخ درست است — و این یک نکته‌ی امتحانی مهم است: در کزاز، «هیچ‌کدام» گزینه‌ی فرار نیست بلکه بازتاب یک واقعیت بالینی است.",
 "This is the mirror image of the previous question and tests the same knowledge. The stem asks which method DEFINITIVELY diagnoses tetanus, and all three laboratory options fail: blood PCR is not routine and lacks sensitivity; wound culture is positive in only about 30% and is not proof anyway because C. tetani can colonise without producing toxin; and serum antitoxin does not exclude disease even at protective levels. So 'none of the above' is correct — an important exam point, because here 'none' is not an escape option but a reflection of clinical reality.",
 ["PCR خون برای کلستریدیوم تتانی روتین نیست و حساسیت لازم برای تشخیص قطعی را ندارد.",
  "کشت زخم فقط حدود ۳۰٪ مثبت است و کلونیزاسیون بدون تولید سم هم ممکن است.",
  "آنتی‌توکسین سرم حتی در سطح محافظ، کزاز را رد یا اثبات نمی‌کند.",
  "پاسخ صحیح — هیچ آزمایشی کزاز را قطعی تشخیص نمی‌دهد؛ تشخیص بالینی است."],
 ["Blood PCR for C. tetani is not routine and lacks the sensitivity for a definitive diagnosis.",
  "Wound culture is positive in only about 30%, and colonisation without toxin production occurs.",
  "Serum antitoxin neither confirms nor excludes tetanus, even at protective levels.",
  "Correct — no test definitively diagnoses tetanus; the diagnosis is clinical."],
 "هیچ آزمایشی کزاز را قطعی نمی‌کند. اینجا «هیچ‌کدام» پاسخ واقعی است، نه گزینه‌ی فرار.",
 "No test definitively diagnoses tetanus. Here 'none of the above' is the real answer, not an escape.",
 [f"{H} — Ch. 304: Tetanus, diagnosis"])

# ---------------------------------------------------------------- idx 377
# Established tetanus: debridement + METRONIDAZOLE + TIG.
add("book:377", "case", "hard",
 "کزاز مستقر ← دبریدمان زخم + **مترونیدازول** + تتابولین. مترونیدازول بر پنی‌سیلین ارجح است.",
 "Established tetanus: wound debridement plus METRONIDAZOLE plus TIG. Metronidazole is preferred over penicillin.",
 [
  "تابلوی این بیمار کلاسیک است: اسپاسم عضلات صورت، اختلال بلع، اسپاسم عمومی، هوشیاری حفظ‌شده.",
  "درمان کزاز مستقر چهار ستون دارد و هر چهار را باید همزمان شروع کرد.",
  "ستون اول: **خنثی کردن سم آزاد** با ایمونوگلوبولین ضد کزاز (TIG).",
  "TIG فقط سم گردش‌کننده را می‌گیرد؛ سمی که به عصب چسبیده برگشت‌پذیر نیست.",
  "پس هرچه زودتر تزریق شود، بار سمی که هنوز به عصب نرسیده کمتر می‌شود.",
  "ستون دوم: **از بین بردن منبع تولید سم** با دبریدمان زخم و آنتی‌بیوتیک.",
  "دبریدمان بافت نکروتیک، محیط بی‌هوازی لازم برای رشد باکتری را از بین می‌برد.",
  "آنتی‌بیوتیک ارجح **مترونیدازول** است، نه پنی‌سیلین.",
  "دلیلش مهم است: پنی‌سیلین خودش یک آنتاگونیست گیرنده‌ی GABA است.",
  "توکسین کزاز هم دقیقاً همین کار را می‌کند — مهار نورون‌های مهاری.",
  "پس پنی‌سیلین می‌تواند اثر سم را **تشدید** کند و اسپاسم را بدتر نماید.",
  "مترونیدازول این اثر را ندارد و در مطالعات پیامد بهتری نشان داده است.",
  "ستون سوم: **کنترل اسپاسم** با بنزودیازپین و در صورت نیاز شل‌کننده و تهویه‌ی مکانیکی.",
  "ستون چهارم: **واکسیناسیون**، چون خودِ بیماری کزاز ایمنی ایجاد نمی‌کند.",
  "این نکته‌ی مهمی است: بیمار بهبودیافته باید سری کامل واکسن را بگیرد.",
  "استروئید در درمان کزاز جایگاه ثابت‌شده‌ای ندارد و توصیه نمی‌شود.",
 ],
 [
  "This patient's picture is classic: facial muscle spasm, dysphagia, generalised spasms, preserved consciousness.",
  "Treatment of established tetanus rests on four pillars, all started at once.",
  "Pillar one: NEUTRALISE FREE TOXIN with tetanus immune globulin (TIG).",
  "TIG captures only circulating toxin; toxin already bound to nerve is irreversible.",
  "So the earlier it is given, the smaller the toxin load that ever reaches the nerve.",
  "Pillar two: ELIMINATE THE SOURCE with wound debridement and an antibiotic.",
  "Debriding necrotic tissue destroys the anaerobic environment the organism needs.",
  "The preferred antibiotic is METRONIDAZOLE, not penicillin.",
  "The reason matters: penicillin is itself a GABA-receptor antagonist.",
  "Tetanus toxin does exactly the same thing — it blocks inhibitory neurons.",
  "So penicillin can COMPOUND the toxin's effect and worsen spasms.",
  "Metronidazole lacks that effect and has shown better outcomes in studies.",
  "Pillar three: CONTROL SPASMS with benzodiazepines, and if needed paralysis and ventilation.",
  "Pillar four: VACCINATE, because having tetanus confers no immunity.",
  "That is an important point: a recovered patient still needs the full primary series.",
  "Steroids have no established role in tetanus and are not recommended.",
 ],
 "درمان کزاز مستقر چهار ستون همزمان دارد و این سؤال دو تای آن را می‌سنجد. **خنثی کردن سم** با تتابولین باید فوری انجام شود، چون TIG فقط سمی را می‌گیرد که هنوز به پایانه‌ی عصبی نچسبیده؛ سم متصل‌شده دیگر برگشت‌پذیر نیست. **حذف منبع** با دبریدمان زخم و آنتی‌بیوتیک انجام می‌شود.\n\nنکته‌ی طلایی سؤال، انتخاب آنتی‌بیوتیک است: **مترونیدازول بر پنی‌سیلین ارجح است**. دلیلش ظریف و زیباست — پنی‌سیلین خودش آنتاگونیست گیرنده‌ی **GABA** است، و توکسین کزاز هم دقیقاً با مهار نورون‌های مهاری کار می‌کند. یعنی پنی‌سیلین می‌تواند همان مسیری را که سم خراب کرده بیشتر تخریب کند و اسپاسم‌ها را بدتر نماید. دو ستون دیگر: کنترل اسپاسم با بنزودیازپین (و در صورت لزوم تهویه‌ی مکانیکی) و شروع واکسیناسیون، چون ابتلا به کزاز ایمنی نمی‌سازد.",
 "Treatment of established tetanus has four simultaneous pillars, and this question tests two. NEUTRALISING TOXIN with TIG must be immediate, because TIG captures only toxin not yet bound to nerve endings; bound toxin is irreversible. ELIMINATING THE SOURCE is done by debridement plus an antibiotic.\n\nThe golden point is the antibiotic choice: METRONIDAZOLE is preferred over penicillin. The reason is elegant — penicillin is itself a GABA-receptor antagonist, and tetanus toxin works by blocking inhibitory neurons. Penicillin can therefore aggravate the very pathway the toxin has already damaged and worsen the spasms. The other two pillars: spasm control with benzodiazepines (and ventilation if required), and starting vaccination, because having tetanus confers no immunity.",
 ["پاسخ صحیح — دبریدمان، مترونیدازول (ارجح بر پنی‌سیلین) و تتابولین برای خنثی کردن سم.",
  "پنی‌سیلین آنتاگونیست GABA است و می‌تواند اثر توکسین را تشدید کند؛ مترونیدازول ارجح است.",
  "وانکومایسین و کلیندامایسین پوشش مناسبی در این زمینه نیستند و TIG هم حذف شده است.",
  "استروئید جایگاه ثابت‌شده‌ای در کزاز ندارد و سفتریاکسون آنتی‌بیوتیک انتخابی نیست."],
 ["Correct — debridement, metronidazole (preferred over penicillin) and TIG to neutralise toxin.",
  "Penicillin is a GABA antagonist and may aggravate the toxin's effect; metronidazole is preferred.",
  "Vancomycin plus clindamycin is not appropriate cover here, and TIG has been omitted.",
  "Steroids have no established role in tetanus and ceftriaxone is not the antibiotic of choice."],
 "کزاز مستقر: TIG زودهنگام + دبریدمان + **مترونیدازول** (نه پنی‌سیلین، چون آنتاگونیست GABA است) + بنزودیازپین + واکسن.",
 "Established tetanus: early TIG, debridement, METRONIDAZOLE (not penicillin, a GABA antagonist), benzodiazepines and vaccine.",
 [f"{H} — Ch. 304: Tetanus, management"])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book8.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 8 lessons:', len(L))
