# -*- coding: utf-8 -*-
"""Repair the damaged numbers of the zoonoses chapter (rabies, brucellosis,
leptospirosis).

Method — unchanged from the four previous chapters
--------------------------------------------------
pdfplumber reports the x-coordinate of every glyph. A number is always drawn
left to right, even inside right-to-left script, so sorting a line's glyphs by
x0 and reading the digit runs recovers exactly the values the typesetter put on
the page. The extracted text keeps the *logical* order, and that is where a
multi-digit value gets mirrored (207 -> 702) or where the digits of two
neighbouring numbers get shuffled into each other.

Two damage patterns appear in this chapter, and they need different arguments
-----------------------------------------------------------------------------
1. MIRRORED — the classic case. "046/1" where the page prints 1/640.
   Reordering is safe: the same digits, put back in printed order.

2. LOST — a digit vanished from the extraction. q9414 stores "2 Iu/kg" and
   "4 Iu/kg" where page 157 prints 20 IU/kg and 40 IU/kg; q9496 stores
   "8 u/ml=ALT" where page 186 prints 80. Here we are not reordering, we are
   restoring a digit, so the bar is higher: every one of these is asserted
   against the printed run before it is written, and each is also medically
   coherent in a way the damaged value is not (rabies immune globulin is dosed
   at 20 IU/kg — 2 IU/kg is not a dose that exists).

Why this chapter's numbers change the answer
--------------------------------------------
* Rabies: the whole post-exposure algorithm turns on the RIG dose (20 IU/kg)
  and the vaccine day schedule (0-3-7-14, plus 28 for the immunocompromised).
  A student reading "2 IU/kg" learns a dose that would be a tenth of the real
  one.
* Brucellosis: the tube-agglutination (Wright) titre IS the diagnosis. 1/640
  is diagnostic; "046/1" is not a titre at all. And 1/160 versus 1/1280 is the
  difference between a resolving and an active infection in the follow-up
  questions.
* Leptospirosis: the Weil triad is jaundice + renal failure + bleeding, and
  the questions that test it hang on the bilirubin, the creatinine and the
  platelet count. q9484 stored a platelet count of "000001"; the page prints
  100,000/µL. q9493 stored AST 702 (a value that would suggest hepatitis) when
  the page prints 207 — and 207 with an ALP of 257 and a bilirubin of 17 is
  precisely the "jaundice out of proportion to transaminases" pattern that
  separates leptospirosis from acute viral hepatitis. Mirrored, the number
  destroyed the teaching point of the question.

Numbers that were checked and found ALREADY CORRECT (recorded, not silently
dropped, so a reader comparing this file with the pages knows they were
examined): q9407 age 54 (p154 prints 54 in Arabic-Indic digits, which an
un-folded scan misreads), q9422 day schedules 0-3-5-14-28 and 0-7-21/28
(p159 prints the runs in reverse *sequence* because the line is RTL, but every
individual number is right), q9448 (35 y, 20 d, 10 d — p169), q9462 (48 y,
8 weeks, 1/320, 1/160, 12 weeks — p174), q9488 blood pressure 90/50 and
AST 100 / ALT 120 (p183).
"""
import json, io, os, re, collections

import pdfplumber

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = '/home/user/uploads/بیماری عفونی.pdf'

# question_no -> [(page, old, new, expected_printed_run, kind, why_fa), ...]
#   kind == 'reorder'  the digits the page printed, put back in printed order
#   kind == 'restore'  a digit the extraction DROPPED, put back; a stronger
#                      claim, so main() holds it to a stronger assertion
FIXES = {
    9414: [
        (157, '2 Iu/kg', '20 IU/kg', '20', 'restore',
         'دوز ایمونوگلوبولین ضدهاری: صفحه ۱۵۷ رقم‌ها را ۲۰ چاپ کرده است؛ '
         'رقم صفر در استخراج افتاده بود. دوز استاندارد RIG برابر ۲۰ واحد بر '
         'کیلوگرم است و «۲ واحد بر کیلوگرم» اصلاً دوزی نیست که وجود داشته باشد.'),
        (157, '4 Iu/kg', '40 IU/kg', '40', 'restore',
         'گزینه‌ی انحرافی (دوز ایمونوگلوبولین اسبی): صفحه ۱۵۷ رقم‌ها را ۴۰ چاپ کرده '
         'است؛ اینجا هم رقم صفر در استخراج افتاده بود.'),
    ],
    9450: [
        (170, '(wright)=046/1', '(Wright)=1/640', '640', 'reorder',
         'تیتر رایت: صفحه ۱۷۰ رقم‌ها را ۶۴۰ چاپ کرده است، یعنی تیتر ۱/۶۴۰. '
         '«۰۴۶/۱» اصلاً تیتر نیست.'),
    ],
    9468: [
        (176, 'oc5/93', '39.5 °C', '39', 'reorder',
         'درجه حرارت: صفحه ۱۷۶ رقم‌ها را ۳۹ و ۵ چاپ کرده است، یعنی ۳۹٫۵ درجه؛ '
         '«۹۳٫۵ درجه» با حیات سازگار نیست.'),
    ],
    9469: [
        (176, 'برابر 061/1', 'برابر 1/160', '160', 'reorder',
         '2ME: صفحه ۱۷۶ رقم‌ها را ۱۶۰ چاپ کرده است، یعنی ۱/۱۶۰.'),
    ],
    9484: [
        (181, '21 mg/dl', '12 mg/dl', '12', 'reorder',
         'بیلی‌روبین توتال: صفحه ۱۸۱ رقم‌ها را ۱۲ چاپ کرده است.'),
        (182, 'lμ000001', '100000/μL', '100000', 'reorder',
         'شمارش پلاکت: صفحه ۱۸۲ رقم‌ها را ۱۰۰۰۰۰ چاپ کرده است؛ «۰۰۰۰۰۱» عدد نیست.'),
    ],
    9486: [
        (182, 'تب، C04 میالژی', 'تب 40 درجه، میالژی', '40', 'reorder',
         'درجه حرارت: صفحه ۱۸۲ رقم‌ها را ۴۰ چاپ کرده است.'),
        (182, 'شمارش پلاکتی 175=ALT ، 00057 و 3000=CPK',
         'شمارش پلاکتی 75000، ALT=175 و CPK=3000', '75000', 'reorder',
         'پنل آزمایشگاهی: صفحه ۱۸۲ به ترتیب چاپ رقم‌ها پلاکت ۷۵۰۰۰، ALT برابر '
         '۱۷۵ و CPK برابر ۳۰۰۰ دارد؛ در استخراج، عددها در هم رفته بودند و '
         '«۰۰۰۵۷» ساخته شده بود.'),
    ],
    9488: [
        (183, '8 mg/dir=urea', 'urea=80 mg/dl', '80', 'restore',
         'اوره: صفحه ۱۸۳ رقم‌ها را ۸۰ چاپ کرده است؛ رقم صفر در استخراج افتاده بود.'),
        (183, '5 mg/gl.2=Cr', 'Cr=2.5 mg/dl', '2', 'reorder',
         'کراتینین: صفحه ۱۸۳ «۲٫۵» چاپ کرده است؛ در استخراج رقم‌ها جابه‌جا شده بودند.'),
        (183, 'توتال 4. 5 mg/dl', 'توتال 4.5 mg/dl', '5', 'reorder',
         'بیلی‌روبین توتال: ۴٫۵ است؛ فاصله‌ی اضافه‌ی استخراج عدد را دو تکه کرده بود.'),
    ],
    9490: [
        (184, '%58', '85%', '85', 'reorder',
         'اشباع اکسیژن: صفحه ۱۸۴ رقم‌ها را ۸۵ چاپ کرده است؛ «۵۸ درصد» با بقیه‌ی '
         'تابلوی بیمار نمی‌خواند.'),
    ],
    9493: [
        (185, 'دایرکت 217=ALT ، 702=AST ، 21 و 257=ALP',
         'دایرکت 12، AST=207، ALT=217 و ALP=257', '207', 'reorder',
         'پنل کبدی: صفحه ۱۸۵ به ترتیب چاپ رقم‌ها بیلی‌روبین دایرکت ۱۲، AST برابر '
         '۲۰۷، ALT برابر ۲۱۷ و ALP برابر ۲۵۷ دارد. AST=702 معکوسِ ۲۰۷ بود و '
         'دقیقاً همان چیزی را خراب می‌کرد که سؤال می‌خواهد بیاموزد: در '
         'لپتوسپیروز زردی به‌مراتب بیشتر از افزایش ترانس‌آمینازها است.'),
    ],
    9496: [
        (186, '8 u/ml=ALT ,1 u/ml = AST', 'AST=1000 u/ml, ALT=80 u/ml', '1000', 'restore',
         'ترانس‌آمینازها: صفحه ۱۸۶ رقم‌ها را ۱۰۰۰ برای AST و ۸۰ برای ALT چاپ '
         'کرده است؛ در استخراج فقط رقم اول هر عدد باقی مانده بود.'),
        (186, 'کراتینین 2 mg/dl/4', 'کراتینین 2.4 mg/dl', '4', 'reorder',
         'کراتینین: صفحه ۱۸۶ «۲/۴» چاپ کرده است، یعنی ۲٫۴.'),
    ],
}

FOLD = {}
for _i in range(10):
    FOLD[chr(0x0660 + _i)] = str(_i)   # Arabic-Indic
    FOLD[chr(0x06F0 + _i)] = str(_i)   # Persian


def page_digit_runs(pdf, pno):
    """Digit runs of a page in PRINTED (x-ascending) order."""
    page = pdf.pages[pno - 1]
    rows = collections.defaultdict(list)
    for c in page.chars:
        rows[round(c['top'])].append(c)
    runs = []
    for top in sorted(rows):
        cs = sorted(rows[top], key=lambda c: c['x0'])
        cur = ''
        for c in cs:
            t = FOLD.get(c['text'], c['text'])
            # a space must NOT close an open run: kerning sometimes splits a
            # number, and closing on the space invents two numbers out of one
            if t.isspace() and cur:
                continue
            if t.isdigit():
                cur += t
            else:
                if cur:
                    runs.append(cur)
                cur = ''
        if cur:
            runs.append(cur)
    return runs


def main():
    pages = {p for specs in FIXES.values() for (p, *_r) in specs}
    with pdfplumber.open(SRC) as pdf:
        printed = {p: page_digit_runs(pdf, p) for p in pages}

    applied, missing = [], []
    for i in range(1, 6):
        path = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        body = json.load(io.open(path, encoding='utf-8'))
        dirty = False
        for q in body['questions']:
            specs = FIXES.get(q['question_no'])
            if not specs:
                continue
            for pno, old, new, expect, kind, why in specs:
                assert expect in printed[pno], \
                    f'q{q["question_no"]}: page {pno} does not print {expect}'
                # A REORDER only rearranges the digits the page printed. A
                # RESTORE puts back a digit the extraction dropped, which is a
                # stronger claim, so it is held to a stronger test: the old
                # digits must survive IN ORDER inside the new value, and every
                # number of the new value must actually be printed on the page.
                old_d = [c for c in old if c.isdigit()]
                new_d = [c for c in new if c.isdigit()]
                if kind == 'reorder':
                    assert sorted(old_d) == sorted(new_d), \
                        f'q{q["question_no"]}: {old} -> {new} is not a reordering'
                else:
                    assert kind == 'restore', f'unknown kind {kind!r}'
                    # Every digit the extraction did keep must survive. Order is
                    # NOT required: when one line carries two laboratory values,
                    # RTL extraction can hand them back in the opposite sequence,
                    # so demanding a subsequence would fail on a correct repair.
                    # (q9496 is exactly that case: the page prints AST 1000 then
                    # ALT 80, and the extraction kept "8" before "1".)
                    have = collections.Counter(new_d)
                    for c in collections.Counter(old_d).items():
                        assert have[c[0]] >= c[1], \
                            f'q{q["question_no"]}: {old} -> {new} loses a printed digit'
                    # And the strong part: EVERY number of the repaired text must
                    # be a run the page actually printed. A restore may not
                    # conjure a value, only put back one the typesetter set.
                    for run in re.findall(r'\d+', new):
                        assert run in printed[pno], \
                            f'q{q["question_no"]}: page {pno} does not print restored {run}'
                hit = False
                if old in q['question_fa']:
                    q.setdefault('stem_original_fa', q['question_fa'])
                    q['question_fa'] = q['question_fa'].replace(old, new)
                    q.setdefault('stem_number_corrections', []).append({
                        'from': old, 'to': new, 'page': pno, 'where': 'stem',
                        'method': 'glyph geometry (pdfplumber x-order)',
                        'kind': kind, 'why_fa': why})
                    applied.append(f'q{q["question_no"]}: {old} -> {new} (stem)')
                    hit = True
                    dirty = True
                for oi, opt in enumerate(q['options_fa']):
                    if old in opt:
                        q.setdefault('options_original_fa', list(q['options_fa']))
                        q['options_fa'][oi] = opt.replace(old, new)
                        q.setdefault('stem_number_corrections', []).append({
                            'from': old, 'to': new, 'page': pno,
                            'where': f'option {oi + 1}',
                            'method': 'glyph geometry (pdfplumber x-order)',
                            'kind': kind, 'why_fa': why})
                        applied.append(
                            f'q{q["question_no"]}: {old} -> {new} (option {oi + 1})')
                        hit = True
                        dirty = True
                if not hit:
                    missing.append(f'q{q["question_no"]}: {old!r} not found')
        if dirty:
            json.dump(body, io.open(path, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)

    for a in applied:
        print('fixed  ', a)
    for m in missing:
        print('MISSING', m)
    print(f'\n{len(applied)} corrections written, {len(missing)} not found')


if __name__ == '__main__':
    main()
