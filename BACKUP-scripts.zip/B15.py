# -*- coding: utf-8 -*-
"""Micro-lessons, batch 15 — the diarrhoea chapter: inflammatory vs secretory.

84 questions with four taught. This chapter is the most mechanically organised
in the book: almost every question is answered by placing the patient into one
of two boxes, and the whole chapter can be taught as one decision.

The central split
-----------------
    INFLAMMATORY (invasive)          SECRETORY (non-inflammatory)
    small volume, frequent           large volume, "rice water"
    fever, tenesmus, cramps          NO fever, no tenesmus
    stool WBC and RBC PRESENT        stool WBC and RBC ABSENT
    Shigella, Campylobacter,         Cholera, ETEC, S. aureus toxin,
    Salmonella, EIEC, EHEC,          B. cereus, C. perfringens,
    Yersinia, E. histolytica         rotavirus, Giardia
    antibiotics sometimes            REHYDRATION, essentially never antibiotics

The single most repeated question in this chapter is a variant of "which of
these could NOT cause this picture?", and it is always answered by noticing
that ETEC or cholera has been slipped into a list of invasive organisms, or the
reverse. Six questions are that exact question.

Three further spines
--------------------
1. THE INCUBATION CLOCK OF FOOD POISONING. 1-6 hours means a PREFORMED TOXIN
   was eaten (S. aureus, B. cereus emetic); 8-16 hours means the toxin is made
   in the gut (C. perfringens, B. cereus diarrhoeal); over 16 hours means the
   organism must first multiply and invade.

2. WHEN ANTIBIOTICS ARE HARMFUL. Two situations, and they are the opposite of
   intuition: EHEC/STEC, where antibiotics raise the risk of HUS, and
   non-typhoidal Salmonella, where they prolong carriage. This chapter asks
   both repeatedly.

3. TYPHOID IS NOT A DIARRHOEAL ILLNESS. Fever with relative bradycardia, rose
   spots, leucopenia and CONSTIPATION. And when antibiotics have already been
   started, bone-marrow culture outperforms blood culture — the chapter asks
   that three times.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022),
Chapters 128 (acute infectious diarrhoea), 160 (Salmonella), 161 (Shigella),
162 (Campylobacter), 163 (cholera), 133 (C. difficile).
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H128 = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 128"
H133 = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 133"
H160 = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 160-163"
IDSA = "IDSA Clinical Practice Guidelines for Infectious Diarrhea (2017)"

# The two-box split, repeated verbatim in every diarrhoea lesson.
SPLIT_FA = [
    "هر اسهال عفونی را اول در یکی از **دو جعبه** بگذارید؛ تقریباً همه‌ی سؤالات این فصل از همین‌جا حل می‌شوند.",
    "**جعبه‌ی یک — اسهال التهابی (تهاجمی)**: باکتری به مخاط **حمله می‌کند**.",
    "نشانه‌ها: حجم **کم**، دفعات **زیاد**، **تب**، **تنسموس**، کرامپ شکمی، گاهی خون.",
    "⚠️ نشانه‌ی آزمایشگاهی قطعی: در مدفوع **گلبول سفید و قرمز دیده می‌شود**.",
    "عوامل: **شیگلا، کمپیلوباکتر، سالمونلا، EIEC، EHEC، یرسینیا، آمیب هیستولیتیکا**.",
    "**جعبه‌ی دو — اسهال ترشحی (غیرالتهابی)**: توکسین ترشح آب را زیاد می‌کند، بدون تهاجم.",
    "نشانه‌ها: حجم **بسیار زیاد**، آبکی، **بدون تب**، **بدون تنسموس**، بدون درد شکم مشخص.",
    "⚠️ نشانه‌ی آزمایشگاهی قطعی: مدفوع **بدون گلبول سفید و قرمز** است.",
    "عوامل: **ویبریو کلرا، ETEC، استاف اورئوس، باسیلوس سرئوس، کلستریدیوم پرفرنژنس، روتاویروس، ژیاردیا**.",
    "⚠️ و نکته‌ای که بیشترین سؤال این فصل روی آن ساخته شده:",
    "**ETEC و ویبریو کلرا هرگز اسهال التهابی نمی‌دهند** — چون اصلاً تهاجم نمی‌کنند.",
    "پس اگر در فهرست عوامل یک تابلوی **التهابی**، نام **ETEC یا کلرا** را دیدید، همان استثناست.",
    "و برعکس: اگر تابلو **آبکی و بدون تب** بود، شیگلا و کمپیلوباکتر گزینه‌های نادرست‌اند.",
    "درمان جعبه‌ی دو تقریباً همیشه یکی است: **جبران آب و الکترولیت**، نه آنتی‌بیوتیک.",
]
SPLIT_EN = [
    "Put every infectious diarrhoea into one of TWO BOXES first; almost every question in this chapter falls out of that.",
    "BOX ONE, INFLAMMATORY (invasive) diarrhoea: the organism INVADES the mucosa.",
    "Features: SMALL volume, FREQUENT stools, FEVER, TENESMUS, cramping, sometimes blood.",
    "WARNING, the decisive laboratory sign: WHITE AND RED CELLS ARE PRESENT in the stool.",
    "Organisms: SHIGELLA, CAMPYLOBACTER, SALMONELLA, EIEC, EHEC, YERSINIA, Entamoeba histolytica.",
    "BOX TWO, SECRETORY (non-inflammatory) diarrhoea: a toxin drives water secretion without invasion.",
    "Features: VERY LARGE volume, watery, NO FEVER, NO TENESMUS, no localised abdominal pain.",
    "WARNING, the decisive laboratory sign: the stool has NO white or red cells.",
    "Organisms: VIBRIO CHOLERAE, ETEC, S. AUREUS, B. CEREUS, C. PERFRINGENS, rotavirus, Giardia.",
    "WARNING, and here is the point most of this chapter's questions are built on:",
    "ETEC AND CHOLERA NEVER CAUSE INFLAMMATORY DIARRHOEA, because they do not invade at all.",
    "So if ETEC or cholera appears in a list of causes of an INFLAMMATORY picture, that is the exception.",
    "And conversely: if the picture is watery and afebrile, shigella and campylobacter are the wrong options.",
    "Treatment of box two is almost always the same: FLUID AND ELECTROLYTE REPLACEMENT, not antibiotics.",
]


# ---------------------------------------------------------------- idx 286
add("book:286", "case", "easy",
 "تابلوی **التهابی** (تب + تنسموس + WBC و RBC در مدفوع) ← **ETEC** استثناست، چون تهاجم نمی‌کند.",
 "An INFLAMMATORY picture (fever + tenesmus + stool WBC and RBC) excludes ETEC, which does not invade.",
 SPLIT_FA + [
  "این بیمار را با جدول بسنجید؛ هر جزء صورت سؤال جعبه‌ی یک را پر می‌کند.",
  "**تب** ✓، **درد کرامپی** ✓، **تنسموس** ✓ — سه نشانه‌ی بالینی اسهال التهابی.",
  "**WBC و RBC فراوان در مدفوع** ✓ — نشانه‌ی آزمایشگاهی قطعی تهاجم.",
  "پس عامل باید یک ارگانیسم **مهاجم** باشد.",
  "**شیگلا دیسانتریه** ✓ مهاجم است — کلاسیک‌ترین عامل دیسانتری باسیلی.",
  "**کمپیلوباکتر ژژونی** ✓ مهاجم است — و شایع‌ترین علت اسهال باکتریایی در بسیاری از کشورها.",
  "**یرسینیا انتروکولیتیکا** ✓ مهاجم است — و می‌تواند شبیه آپاندیسیت تظاهر کند.",
  "⚠️ **ETEC** ✗ **مهاجم نیست** — و این پاسخ سؤال است.",
  "ETEC دو توکسین می‌سازد: **LT** (شبیه توکسین کلرا) و **ST**.",
  "این توکسین‌ها ترشح آب و الکترولیت را زیاد می‌کنند، **بدون آنکه به سلول حمله کنند**.",
  "پس ETEC اسهال **آبکی و بدون تب** می‌دهد — همان «اسهال مسافران».",
  "و چون التهابی نیست، در مدفوعش **گلبول سفید دیده نمی‌شود**.",
 ],
 SPLIT_EN + [
  "Test this patient against the table; every element of the stem fills box one.",
  "FEVER (yes), CRAMPING PAIN (yes), TENESMUS (yes) — the three clinical signs of inflammatory diarrhoea.",
  "ABUNDANT WBC AND RBC IN THE STOOL (yes) — the decisive laboratory sign of invasion.",
  "So the organism must be an INVASIVE one.",
  "SHIGELLA DYSENTERIAE (yes) invades — the classic cause of bacillary dysentery.",
  "CAMPYLOBACTER JEJUNI (yes) invades — and is the commonest cause of bacterial diarrhoea in many countries.",
  "YERSINIA ENTEROCOLITICA (yes) invades — and can mimic appendicitis.",
  "WARNING: ETEC (no) DOES NOT INVADE — and that is the answer.",
  "ETEC makes two toxins: LT (similar to cholera toxin) and ST.",
  "These drive water and electrolyte secretion WITHOUT attacking the cell.",
  "So ETEC gives WATERY, AFEBRILE diarrhoea — classic traveller's diarrhoea.",
  "And because it is not inflammatory, NO WHITE CELLS APPEAR in the stool.",
 ],
 "این سؤال با یک نگاه به **جدول دوجعبه‌ای** حل می‌شود، و همان سؤالی است که در این فصل شش بار به شکل‌های مختلف پرسیده شده.\n\n**تابلوی بیمار کاملاً التهابی است:**\n• **تب** ✓\n• **درد کرامپی شکم** ✓\n• **تنسموس** ✓\n• **WBC و RBC فراوان در مدفوع** ✓ ← نشانه‌ی آزمایشگاهی قطعی تهاجم\n\nپس عامل باید یک ارگانیسم **مهاجم** باشد. سه گزینه‌ی شیگلا، کمپیلوباکتر و یرسینیا هر سه مهاجم‌اند و می‌توانند دقیقاً همین تابلو را بسازند.\n\n⚠️ **اما ETEC اصلاً تهاجم نمی‌کند** — و همین پاسخ سؤال است.\n\nسازوکار ETEC کاملاً متفاوت است: دو توکسین می‌سازد، **LT** (که شبیه توکسین کلرا عمل می‌کند و cAMP را بالا می‌برد) و **ST** (که cGMP را بالا می‌برد). هر دو باعث می‌شوند سلول روده **آب و الکترولیت ترشح کند**، بدون آنکه سلول آسیب ببیند یا التهابی رخ دهد.\n\nنتیجه‌ی بالینی: ETEC اسهال **آبکی، حجیم و بدون تب** می‌دهد — همان چیزی که به آن «**اسهال مسافران**» می‌گویند. و چون التهابی نیست، **در مدفوعش گلبول سفید دیده نمی‌شود**.\n\n⚠️ **قاعده‌ی عملی برای این فصل:** هر وقت در فهرست عوامل یک تابلوی التهابی، نام **ETEC یا ویبریو کلرا** را دیدید، تقریباً همیشه همان گزینه استثناست.",
 "This question is settled at a glance by the TWO-BOX TABLE, and it is the same question this chapter asks six times in different words.\n\nTHE PATIENT'S PICTURE IS ENTIRELY INFLAMMATORY:\n- FEVER (yes)\n- CRAMPING ABDOMINAL PAIN (yes)\n- TENESMUS (yes)\n- ABUNDANT WBC AND RBC IN STOOL (yes) - the decisive laboratory sign of invasion\n\nSo the organism must be INVASIVE. Shigella, campylobacter and yersinia all invade and can produce exactly this picture.\n\nWARNING: BUT ETEC DOES NOT INVADE AT ALL — and that is the answer.\n\nETEC's mechanism is entirely different: it makes two toxins, LT (which acts like cholera toxin, raising cAMP) and ST (which raises cGMP). Both make the enterocyte SECRETE WATER AND ELECTROLYTES without the cell being damaged and without inflammation.\n\nThe clinical consequence: ETEC causes WATERY, HIGH-VOLUME, AFEBRILE diarrhoea — what is called TRAVELLER'S DIARRHOEA. And because it is not inflammatory, NO WHITE CELLS APPEAR IN THE STOOL.\n\nWARNING, THE PRACTICAL RULE FOR THIS CHAPTER: whenever ETEC or Vibrio cholerae appears in a list of causes of an inflammatory picture, that option is almost always the exception.",
 ["ETEC توکسین ترشحی می‌سازد و تهاجم نمی‌کند؛ اسهالش آبکی و بدون گلبول سفید است. پس نمی‌تواند این تابلو را بسازد. (اما این گزینه‌ی درست سؤال است — دقت کنید سؤال دنبال استثناست.)",
  "پاسخ صحیح — شیگلا دیسانتریه یک ارگانیسم مهاجم کلاسیک است و دقیقاً همین تابلو را می‌سازد، پس استثنا نیست.",
  "کمپیلوباکتر ژژونی مهاجم است و اسهال التهابی با گلبول سفید در مدفوع می‌دهد.",
  "یرسینیا انتروکولیتیکا هم مهاجم است و می‌تواند اسهال التهابی ایجاد کند."],
 ["ETEC makes a secretory toxin and does not invade; its diarrhoea is watery and free of white cells, so it cannot cause this picture. (Note the question asks for the exception.)",
  "Correct — Shigella dysenteriae is a classic invasive organism and produces exactly this picture, so it is not the exception.",
  "Campylobacter jejuni invades and causes inflammatory diarrhoea with stool white cells.",
  "Yersinia enterocolitica also invades and can produce inflammatory diarrhoea."],
 "**WBC در مدفوع = تهاجمی.** ETEC و کلرا **هرگز** تهاجمی نیستند. تب + تنسموس = التهابی.",
 "STOOL WBC = INVASIVE. ETEC and cholera are NEVER invasive. Fever + tenesmus = inflammatory.",
 [H128, H160])


# ---------------------------------------------------------------- idx 297
add("book:297", "case", "easy",
 "اسهال **۱ تا ۶ ساعت** پس از غذا = **توکسین از پیش ساخته‌شده** ← استاف اورئوس.",
 "Diarrhoea 1-6 HOURS after a meal means a PREFORMED TOXIN was eaten: S. aureus.",
 SPLIT_FA + [
  "برای مسمومیت غذایی، **زمان بین غذا و علائم** خودش تشخیص را می‌سازد. آن را مثل یک ساعت بخوانید.",
  "⚠️ **۱ تا ۶ ساعت** — کوتاه‌ترین. یعنی **توکسین از قبل در غذا ساخته شده بود**.",
  "چون توکسین آماده خورده شده، لازم نیست باکتری تکثیر کند؛ اثر تقریباً فوری است.",
  "عوامل این بازه: **استافیلوکوک اورئوس** و **باسیلوس سرئوس (فرم استفراغی)**.",
  "تابلوی این بازه: **استفراغ غالب**، تهوع، اسهال آبکی، و ⚠️ **بدون تب**.",
  "**۸ تا ۱۶ ساعت** — متوسط. باکتری خورده شده و توکسین را **داخل روده** می‌سازد.",
  "عوامل: **کلستریدیوم پرفرنژنس** و **باسیلوس سرئوس (فرم اسهالی)**.",
  "**بیش از ۱۶ ساعت** — طولانی. باکتری باید تکثیر کند و **تهاجم** کند.",
  "عوامل: **سالمونلا، شیگلا، کمپیلوباکتر، ETEC، EHEC**.",
  "حالا این بیمار: **۵ ساعت** پس از سالاد سیب‌زمینی با سس مایونز.",
  "⚠️ سالاد با مایونز، تخم‌مرغ و شیرینی خامه‌ای، غذاهای کلاسیک **استاف اورئوس** هستند.",
  "چرا؟ چون این غذاها با **دست** آماده می‌شوند و استاف روی پوست و بینی انسان زندگی می‌کند.",
  "و غذا در دمای اتاق می‌ماند تا استاف تکثیر کند و **انتروتوکسین مقاوم به حرارت** بسازد.",
  "⚠️ نکته‌ی کلیدی: این توکسین **با پختن مجدد از بین نمی‌رود** — گرم کردن غذا بی‌فایده است.",
  "درمان: فقط **حمایتی و مایع‌درمانی**. بیماری ظرف ۸ تا ۲۴ ساعت خودبه‌خود خوب می‌شود.",
  "آنتی‌بیوتیک کاملاً بی‌فایده است، چون اصلاً عفونتی در کار نیست — فقط **توکسین** است.",
 ],
 SPLIT_EN + [
  "For food poisoning, THE INTERVAL BETWEEN THE MEAL AND THE SYMPTOMS makes the diagnosis. Read it as a clock.",
  "WARNING, 1 TO 6 HOURS — the shortest. It means a PREFORMED TOXIN WAS ALREADY IN THE FOOD.",
  "Because ready-made toxin was swallowed, no bacterial multiplication is needed; the effect is almost immediate.",
  "Organisms in this window: STAPHYLOCOCCUS AUREUS and BACILLUS CEREUS (emetic form).",
  "The picture: VOMITING PREDOMINATES, with nausea, watery diarrhoea and WARNING, NO FEVER.",
  "8 TO 16 HOURS — intermediate. The organism is swallowed and makes its toxin INSIDE THE GUT.",
  "Organisms: CLOSTRIDIUM PERFRINGENS and BACILLUS CEREUS (diarrhoeal form).",
  "MORE THAN 16 HOURS — long. The organism must multiply and INVADE.",
  "Organisms: SALMONELLA, SHIGELLA, CAMPYLOBACTER, ETEC, EHEC.",
  "Now this patient: FIVE HOURS after potato salad with mayonnaise.",
  "WARNING: mayonnaise salads, egg dishes and cream pastries are the classic S. AUREUS foods.",
  "Why? Because they are prepared BY HAND, and staphylococcus lives on human skin and in the nose.",
  "And the food then sits at room temperature while the organism multiplies and makes its HEAT-STABLE ENTEROTOXIN.",
  "WARNING, the key point: that toxin IS NOT DESTROYED BY REHEATING — warming the food does not help.",
  "Treatment: SUPPORTIVE AND FLUIDS only. The illness resolves spontaneously in 8-24 hours.",
  "Antibiotics are entirely useless, because there is no infection at all — only TOXIN.",
 ],
 "برای مسمومیت غذایی، **فاصله‌ی زمانی بین غذا و شروع علائم** خودش تشخیص را می‌سازد. آن را مثل یک ساعت بخوانید:\n\n• **۱ تا ۶ ساعت** ← **توکسین از قبل در غذا بود** ← استاف اورئوس، باسیلوس سرئوس (فرم استفراغی)\n• **۸ تا ۱۶ ساعت** ← باکتری توکسین را داخل روده می‌سازد ← کلستریدیوم پرفرنژنس، باسیلوس سرئوس (فرم اسهالی)\n• **بیش از ۱۶ ساعت** ← باکتری باید تکثیر و تهاجم کند ← سالمونلا، شیگلا، کمپیلوباکتر، ETEC\n\nاین بیمار **۵ ساعت** پس از غذا علامت‌دار شده — یعنی جعبه‌ی اول: **توکسین از پیش ساخته‌شده**.\n\n⚠️ و نوع غذا تشخیص را قطعی می‌کند: **سالاد سیب‌زمینی با سس مایونز**. سالادهای مایونزی، تخم‌مرغ و شیرینی خامه‌ای، غذاهای کلاسیک **استافیلوکوک اورئوس** هستند. دلیلش ساده است: این غذاها **با دست** آماده می‌شوند و استاف روی پوست و در بینی انسان زندگی می‌کند. سپس غذا در دمای اتاق می‌ماند و استاف تکثیر می‌شود و **انتروتوکسین** می‌سازد.\n\n⚠️ **نکته‌ی حیاتی که در سؤال دیگری از همین فصل هم پرسیده شده:** این انتروتوکسین **مقاوم به حرارت** است و **با گرم کردن مجدد غذا از بین نمی‌رود**. به همین دلیل «خنک کردن آهسته‌ی غذا و نگهداری در دمای اتاق» عامل اصلی این نوع مسمومیت است.\n\nتابلوی بالینی هم جفت‌وجور است: **استفراغ غالب، بدون تب، بدون درد شکم مشخص**.\n\nدرمان: فقط **مایع‌درمانی**. بیماری ظرف ۸ تا ۲۴ ساعت خودبه‌خود برطرف می‌شود و آنتی‌بیوتیک کاملاً بی‌فایده است — چون اصلاً عفونتی در کار نیست، فقط توکسین است.",
 "For food poisoning, THE INTERVAL BETWEEN THE MEAL AND THE ONSET makes the diagnosis. Read it as a clock:\n\n- 1 TO 6 HOURS -> the toxin was ALREADY IN THE FOOD -> S. aureus, B. cereus (emetic)\n- 8 TO 16 HOURS -> the organism makes its toxin in the gut -> C. perfringens, B. cereus (diarrhoeal)\n- MORE THAN 16 HOURS -> the organism must multiply and invade -> salmonella, shigella, campylobacter, ETEC\n\nThis patient became symptomatic FIVE HOURS after the meal — box one: A PREFORMED TOXIN.\n\nWARNING, and the food clinches it: POTATO SALAD WITH MAYONNAISE. Mayonnaise salads, egg dishes and cream pastries are the classic S. AUREUS foods. The reason is simple: they are prepared BY HAND, and staphylococcus lives on human skin and in the nose. The food then stands at room temperature while the organism multiplies and produces its ENTEROTOXIN.\n\nWARNING, A VITAL POINT also asked separately in this chapter: that enterotoxin is HEAT-STABLE and IS NOT DESTROYED BY REHEATING. This is why 'slow cooling and storage at room temperature' is the principal cause of this kind of poisoning.\n\nThe clinical picture fits too: VOMITING PREDOMINATES, NO FEVER, no localised abdominal pain.\n\nTreatment: FLUIDS only. The illness resolves spontaneously in 8-24 hours, and antibiotics are entirely useless — there is no infection at all, only toxin.",
 ["کلستریدیوم پرفرنژنس دوره‌ی کمون ۸ تا ۱۶ ساعت دارد و با گوشت و خورش‌های مانده همراه است، نه ۵ ساعت.",
  "باسیلوس سرئوس فرم استفراغی هم کمون کوتاه دارد، ولی غذای کلاسیکش **برنج سرخ‌شده‌ی مانده** است نه سالاد مایونزی.",
  "پاسخ صحیح — کمون ۵ ساعته با سالاد مایونزی، تابلوی کلاسیک انتروتوکسین استاف اورئوس است.",
  "ویبریو کلرا اسهال آبکی حجیم می‌دهد ولی کمونش ۱ تا ۳ روز است، نه چند ساعت."],
 ["Clostridium perfringens has an 8-16 hour incubation and is associated with reheated meat dishes, not 5 hours.",
  "Bacillus cereus (emetic) also has a short incubation, but its classic food is REHEATED FRIED RICE, not mayonnaise salad.",
  "Correct — a 5-hour incubation with mayonnaise salad is the classic picture of S. aureus enterotoxin.",
  "Vibrio cholerae causes high-volume watery diarrhoea, but its incubation is 1-3 days, not a few hours."],
 "ساعت مسمومیت غذایی: **۱–۶ ساعت = توکسین آماده** (استاف/سرئوس)؛ **۸–۱۶ = پرفرنژنس**؛ **>۱۶ = تهاجمی**.",
 "The food-poisoning clock: 1-6 h = PREFORMED TOXIN (staph/cereus); 8-16 h = perfringens; >16 h = invasive.",
 [H128, IDSA])


# ---------------------------------------------------------------- idx 285
add("book:285", "case", "hard",
 "اسهال خونی + نارسایی کلیه + ترومبوسیتوپنی = **HUS** ← **آنتی‌بیوتیک را قطع کن**، شروع نکن.",
 "Bloody diarrhoea + renal failure + thrombocytopenia = HUS: STOP the antibiotic, do not add one.",
 [
  "این یکی از معدود سؤالاتی است که پاسخ درستش **قطع کردن درمان** است — و منطقش حیاتی است.",
  "**سندرم همولیتیک اورمیک (HUS)** یک **تریاد** دارد که باید حفظ شود:",
  "**یک — آنمی همولیتیک میکروآنژیوپاتیک** (در لام: **شیستوسیت**، کومبس **منفی**).",
  "**دو — ترومبوسیتوپنی**.",
  "**سه — نارسایی حاد کلیه**.",
  "⚠️ توجه: **لکوسیتوز جزو تریاد نیست** — گرچه اغلب همراه است.",
  "عامل: **شیگاتوکسین**، که از **EHEC (به‌ویژه O157:H7)** یا **شیگلا دیسانتریه تیپ ۱** می‌آید.",
  "شیگاتوکسین به اندوتلیوم عروق ریز — به‌ویژه **کلیه** — می‌چسبد و ترومبوز میکروواسکولار می‌سازد.",
  "گلبول‌های قرمز از میان این شبکه‌ی فیبرینی رد می‌شوند و **تکه‌تکه** می‌شوند: همان شیستوسیت.",
  "پلاکت‌ها هم در همین ترومبوزها **مصرف** می‌شوند: ترومبوسیتوپنی.",
  "⚠️ و حالا مهم‌ترین نکته‌ی درمانی، که کاملاً **ضدشهودی** است:",
  "**آنتی‌بیوتیک در عفونت شیگاتوکسین‌ساز، خطر HUS را افزایش می‌دهد.**",
  "سازوکارش زیباست: آنتی‌بیوتیک به باکتری **آسیب DNA** می‌زند و **پاسخ SOS** را فعال می‌کند.",
  "پاسخ SOS، **پروفاژ** حامل ژن شیگاتوکسین را از حالت خفته بیدار می‌کند.",
  "نتیجه: تولید توکسین **بیشتر** می‌شود، و لیز باکتری آن را یک‌جا به خون می‌ریزد.",
  "متاآنالیز روی کودکان مبتلا به O157:H7 نشان داد آنتی‌بیوتیک در هفته‌ی اول، خطر HUS را **سه برابر** می‌کند.",
  "⚠️ ضدحرکتی‌ها (لوپرامید) هم ممنوع‌اند، چون زمان تماس توکسین با روده را زیاد می‌کنند.",
  "پس درمان HUS: **حمایتی** — مایع‌درمانی دقیق، اصلاح الکترولیت، و در صورت لزوم **دیالیز**.",
 ],
 [
  "This is one of the few questions whose correct answer is to STOP treatment — and the reasoning matters.",
  "HAEMOLYTIC URAEMIC SYNDROME (HUS) has a TRIAD that must be memorised:",
  "ONE, MICROANGIOPATHIC HAEMOLYTIC ANAEMIA (film: SCHISTOCYTES; Coombs NEGATIVE).",
  "TWO, THROMBOCYTOPENIA.",
  "THREE, ACUTE RENAL FAILURE.",
  "WARNING: LEUCOCYTOSIS IS NOT PART OF THE TRIAD, although it often accompanies it.",
  "The cause is SHIGA TOXIN, from EHEC (especially O157:H7) or SHIGELLA DYSENTERIAE type 1.",
  "Shiga toxin binds the endothelium of small vessels — above all in the KIDNEY — and causes microvascular thrombosis.",
  "Red cells forced through that fibrin mesh are SHREDDED: those are the schistocytes.",
  "Platelets are CONSUMED in the same thrombi: hence the thrombocytopenia.",
  "WARNING, and now the key therapeutic point, which is thoroughly COUNTER-INTUITIVE:",
  "ANTIBIOTICS IN SHIGA-TOXIN-PRODUCING INFECTION INCREASE THE RISK OF HUS.",
  "The mechanism is elegant: the antibiotic causes BACTERIAL DNA DAMAGE and triggers the SOS RESPONSE.",
  "The SOS response wakes the dormant PROPHAGE that carries the shiga-toxin gene.",
  "The result: MORE toxin is produced, and bacterial lysis dumps it into the blood at once.",
  "A meta-analysis in children with O157:H7 found antibiotics in the first week TRIPLED the risk of HUS.",
  "WARNING: antimotility drugs (loperamide) are forbidden too, as they prolong toxin contact time.",
  "So the treatment of HUS is SUPPORTIVE — careful fluids, electrolyte correction, and DIALYSIS if needed.",
 ],
 "این یکی از معدود سؤالاتی است که پاسخ درستش **قطع کردن درمان** است، و منطق پشتش یکی از زیباترین نکات این فصل است.\n\n**تشخیص: سندرم همولیتیک اورمیک (HUS).** تریاد آن را حفظ کنید:\n۱. **آنمی همولیتیک میکروآنژیوپاتیک** (شیستوسیت در لام، کومبس منفی)\n۲. **ترومبوسیتوپنی**\n۳. **نارسایی حاد کلیه**\n\nاین بیمار اسهال خونی داشته، E. coli در کشت رشد کرده، و حالا **کراتینین بالا رفته، پلاکت افتاده و آنمیک شده** — یعنی هر سه جزء تریاد.\n\n**پاتوفیزیولوژی:** **شیگاتوکسین** به اندوتلیوم عروق ریز — به‌ویژه کلیه — می‌چسبد و **ترومبوز میکروواسکولار** می‌سازد. گلبول‌های قرمز که از میان این شبکه‌ی فیبرینی رد می‌شوند **تکه‌تکه** می‌شوند (شیستوسیت)، و پلاکت‌ها در همان ترومبوزها **مصرف** می‌شوند.\n\n⚠️ **و حالا نکته‌ی درمانی که کاملاً ضدشهودی است:**\n\n**دادن آنتی‌بیوتیک در عفونت شیگاتوکسین‌ساز، خطر HUS را افزایش می‌دهد.** سازوکارش این است:\n\nآنتی‌بیوتیک → آسیب DNA باکتری → فعال شدن **پاسخ SOS** → بیدار شدن **پروفاژ** حامل ژن شیگاتوکسین → **تولید بیشتر توکسین** → و لیز باکتری آن را یک‌جا به خون می‌ریزد\n\nمتاآنالیزی روی کودکان مبتلا به O157:H7 نشان داد که آنتی‌بیوتیک در هفته‌ی اول بیماری، خطر HUS را حدود **سه برابر** می‌کند.\n\nپس پاسخ درست: **سفتریاکسون را قطع کن و هیچ آنتی‌بیوتیک دیگری شروع نکن.** درمان HUS **حمایتی** است — مایع‌درمانی دقیق، اصلاح الکترولیت، و در صورت لزوم دیالیز.\n\n⚠️ و یک ممنوعیت دیگر: **ضدحرکتی‌ها (لوپرامید)** هم نباید داده شوند، چون زمان تماس توکسین با مخاط را طولانی می‌کنند.",
 "This is one of the few questions whose correct answer is to STOP treatment, and the reasoning behind it is one of the most elegant points in this chapter.\n\nTHE DIAGNOSIS IS HAEMOLYTIC URAEMIC SYNDROME (HUS). Memorise its triad:\n1. MICROANGIOPATHIC HAEMOLYTIC ANAEMIA (schistocytes on the film, Coombs negative)\n2. THROMBOCYTOPENIA\n3. ACUTE RENAL FAILURE\n\nThis patient had bloody diarrhoea, E. coli grew in the culture, and now the CREATININE HAS RISEN, THE PLATELETS HAVE FALLEN AND SHE IS ANAEMIC — all three components.\n\nPATHOPHYSIOLOGY: SHIGA TOXIN binds the endothelium of small vessels, above all in the kidney, and produces MICROVASCULAR THROMBOSIS. Red cells forced through that fibrin mesh are SHREDDED (schistocytes), and platelets are CONSUMED in the same thrombi.\n\nWARNING, AND NOW THE THOROUGHLY COUNTER-INTUITIVE THERAPEUTIC POINT:\n\nGIVING ANTIBIOTICS IN SHIGA-TOXIN-PRODUCING INFECTION INCREASES THE RISK OF HUS. The mechanism:\n\nantibiotic -> bacterial DNA damage -> the SOS RESPONSE is triggered -> the PROPHAGE carrying the shiga-toxin gene awakens -> MORE TOXIN is produced -> and bacterial lysis dumps it into the blood at once\n\nA meta-analysis in children with O157:H7 found that antibiotics in the first week of illness roughly TRIPLED the risk of HUS.\n\nSo the correct answer is: STOP THE CEFTRIAXONE AND START NO OTHER ANTIBIOTIC. Treatment of HUS is SUPPORTIVE — careful fluids, electrolyte correction and dialysis if required.\n\nWARNING, one further prohibition: ANTIMOTILITY DRUGS (loperamide) must also be avoided, as they prolong the toxin's contact with the mucosa.",
 ["افزودن آزیترومایسین همان خطا را بزرگ‌تر می‌کند: هر آنتی‌بیوتیکی می‌تواند آزادسازی شیگاتوکسین را زیاد کند.",
  "سیپروفلوکساسین از بدترین انتخاب‌هاست، چون کینولون‌ها پاسخ SOS باکتری را به‌شدت فعال می‌کنند.",
  "قطع سفتریاکسون درست است ولی شروع آزیترومایسین به‌جایش، همان خطر را دوباره می‌آورد.",
  "پاسخ صحیح — در HUS شیگاتوکسینی، آنتی‌بیوتیک قطع می‌شود و درمان کاملاً حمایتی است."],
 ["Adding azithromycin compounds the error: any antibiotic can increase shiga-toxin release.",
  "Ciprofloxacin is among the worst choices, because quinolones strongly induce the bacterial SOS response.",
  "Stopping the ceftriaxone is right, but replacing it with azithromycin reintroduces the same risk.",
  "Correct — in shiga-toxin HUS the antibiotic is stopped and management is entirely supportive."],
 "HUS = شیستوسیت + پلاکت پایین + نارسایی کلیه. **آنتی‌بیوتیک خطر را ۳ برابر می‌کند** (پاسخ SOS → پروفاژ). درمان: حمایتی.",
 "HUS = schistocytes + low platelets + renal failure. ANTIBIOTICS TRIPLE THE RISK (SOS response -> prophage). Treat supportively.",
 [H128, H160,
  'Freedman SB et al. Shiga Toxin-Producing E. coli Infection, Antibiotics, and Risk of Developing HUS: A Meta-analysis. Clin Infect Dis 2016'])


# ---------------------------------------------------------------- idx 306
add("book:306", "case", "medium",
 "کلرای شدید ← **رینگر لاکتات**، چون هم الکترولیت دارد هم **لاکتات برای اصلاح اسیدوز**.",
 "Severe cholera -> RINGER'S LACTATE: it carries the electrolytes AND the LACTATE that corrects the acidosis.",
 SPLIT_FA + [
  "این بیمار **شوک هیپوولمیک** از اسهال ترشحی دارد: لتارژیک، نبض محیطی لمس‌نشدنی، تورگور کاهش‌یافته.",
  "و آزمایش‌ها تصویر را کامل می‌کنند: **کراتینین ۲** (نارسایی پیش‌کلیوی) و **پتاسیم ۳/۲** (هیپوکالمی).",
  "⚠️ حالا باید بفهمیم مدفوع کلرا **چه چیزی** را از بدن می‌برد؛ انتخاب سرم از همین‌جا می‌آید.",
  "مدفوع کلرا تقریباً **ایزوتونیک با پلاسما** است و سرشار از سه چیز:",
  "**سدیم**، **پتاسیم** (بیشتر از پلاسما)، و ⚠️ **بی‌کربنات** (بسیار بیشتر از پلاسما).",
  "از دست رفتن بی‌کربنات یعنی بیمار دچار **اسیدوز متابولیک** می‌شود.",
  "پس سرم ایده‌آل باید هر سه را جبران کند: حجم، پتاسیم، و **قدرت بافری**.",
  "⚠️ **رینگر لاکتات** دقیقاً همین است: سدیم، کلر، **پتاسیم**، کلسیم و **لاکتات**.",
  "و نکته‌ی کلیدی: **لاکتات در کبد به بی‌کربنات تبدیل می‌شود** و اسیدوز را اصلاح می‌کند.",
  "چرا نرمال سالین دوم است؟ چون **پتاسیم ندارد** و **بافر ندارد**.",
  "بدتر: سالین حاوی کلر زیاد است و می‌تواند **اسیدوز هیپرکلرمیک** را تشدید کند.",
  "چرا سرم قندی-نمکی و ۱/۳-۲/۳ نه؟ چون **هیپوتونیک**‌اند و برای احیای حجم در شوک مناسب نیستند.",
  "قاعده‌ی WHO: در دهیدراتاسیون شدید، **رینگر لاکتات وریدی** انتخاب اول است.",
  "اگر رینگر نبود، سالین + جبران جداگانه‌ی پتاسیم و بی‌کربنات.",
  "⚠️ و پس از احیای اولیه، **ORS خوراکی** ادامه می‌یابد — چون کوترانسپورتر سدیم-گلوکز سالم می‌ماند.",
 ],
 SPLIT_EN + [
  "This patient is in HYPOVOLAEMIC SHOCK from secretory diarrhoea: lethargic, impalpable peripheral pulses, reduced turgor.",
  "And the laboratory completes the picture: CREATININE 2 (prerenal failure) and POTASSIUM 3.2 (hypokalaemia).",
  "WARNING: now work out WHAT cholera stool removes from the body; the fluid choice follows from that.",
  "Cholera stool is nearly ISOTONIC WITH PLASMA and rich in three things:",
  "SODIUM, POTASSIUM (more than plasma), and WARNING, BICARBONATE (far more than plasma).",
  "Losing bicarbonate means the patient develops METABOLIC ACIDOSIS.",
  "So the ideal fluid must replace all three: volume, potassium, and BUFFERING CAPACITY.",
  "WARNING: RINGER'S LACTATE is exactly that — sodium, chloride, POTASSIUM, calcium and LACTATE.",
  "And the key point: LACTATE IS CONVERTED TO BICARBONATE IN THE LIVER, correcting the acidosis.",
  "Why is normal saline second best? It contains NO POTASSIUM and NO BUFFER.",
  "Worse, saline is chloride-rich and can aggravate a HYPERCHLORAEMIC ACIDOSIS.",
  "Why not dextrose-saline or third-normal fluids? They are HYPOTONIC and unsuited to volume resuscitation in shock.",
  "The WHO rule: in severe dehydration, INTRAVENOUS RINGER'S LACTATE is the first choice.",
  "If Ringer's is unavailable, saline plus separate potassium and bicarbonate replacement.",
  "WARNING: after initial resuscitation, ORAL ORS continues — because the sodium-glucose co-transporter remains intact.",
 ],
 "این بیمار در **شوک هیپوولمیک** ناشی از اسهال ترشحی است: لتارژیک، نبض محیطی لمس‌نشدنی، تورگور پوستی کاهش‌یافته، کراتینین ۲ و پتاسیم ۳/۲.\n\nبرای انتخاب سرم درست، باید بدانیم **مدفوع کلرا چه چیزی را از بدن می‌برد**:\n\nمدفوع کلرا تقریباً **ایزوتونیک با پلاسما** است و سرشار از **سدیم**، **پتاسیم** (بیشتر از پلاسما) و ⚠️ **بی‌کربنات** (بسیار بیشتر از پلاسما).\n\nاز دست رفتن انبوه بی‌کربنات یعنی بیمار دچار **اسیدوز متابولیک** می‌شود — و همین است که انتخاب سرم را تعیین می‌کند.\n\n⚠️ **رینگر لاکتات** دقیقاً برای این وضعیت ساخته شده:\n• **سدیم و کلر** ← جبران حجم\n• **پتاسیم** ← جبران هیپوکالمی\n• **لاکتات** ← که در کبد به **بی‌کربنات** تبدیل می‌شود و **اسیدوز را اصلاح می‌کند**\n\n**چرا نرمال سالین انتخاب دوم است؟** چون **پتاسیم ندارد** و **هیچ بافری ندارد**. بدتر از آن، کلر بالای سالین می‌تواند **اسیدوز هیپرکلرمیک** را تشدید کند. البته اگر رینگر در دسترس نباشد، سالین با جبران جداگانه‌ی پتاسیم و بی‌کربنات قابل قبول است.\n\n**چرا سرم‌های هیپوتونیک (قندی-نمکی، ۱/۳-۲/۳) نه؟** چون برای **احیای حجم در شوک** ساخته نشده‌اند؛ آب آزاد می‌دهند نه حجم داخل‌عروقی.\n\n⚠️ **و یک نکته‌ی تکمیلی زیبا:** پس از احیای اولیه‌ی وریدی، درمان با **ORS خوراکی** ادامه می‌یابد. دلیلش این است که توکسین کلرا **کوترانسپورتر سدیم-گلوکز** را دست‌نخورده می‌گذارد — پس روده هنوز می‌تواند سدیم را همراه گلوکز جذب کند. کشف همین اصل، ORS را ساخت و میلیون‌ها جان را نجات داد.",
 "This patient is in HYPOVOLAEMIC SHOCK from secretory diarrhoea: lethargic, impalpable peripheral pulses, reduced skin turgor, creatinine 2 and potassium 3.2.\n\nTo choose the right fluid, you must know WHAT CHOLERA STOOL TAKES OUT OF THE BODY:\n\nCholera stool is nearly ISOTONIC WITH PLASMA and rich in SODIUM, POTASSIUM (more than plasma) and WARNING, BICARBONATE (far more than plasma).\n\nMassive bicarbonate loss means the patient develops METABOLIC ACIDOSIS — and that is what determines the fluid choice.\n\nWARNING: RINGER'S LACTATE is made for exactly this situation:\n- SODIUM AND CHLORIDE -> volume replacement\n- POTASSIUM -> replaces the hypokalaemia\n- LACTATE -> converted to BICARBONATE in the liver, CORRECTING THE ACIDOSIS\n\nWHY IS NORMAL SALINE SECOND BEST? It has NO POTASSIUM and NO BUFFER. Worse, its high chloride can aggravate a HYPERCHLORAEMIC ACIDOSIS. If Ringer's is unavailable, saline with separate potassium and bicarbonate replacement is acceptable.\n\nWHY NOT HYPOTONIC FLUIDS (dextrose-saline, third-normal)? They are not designed for VOLUME RESUSCITATION IN SHOCK; they deliver free water rather than intravascular volume.\n\nWARNING, AND AN ELEGANT FURTHER POINT: after initial intravenous resuscitation, treatment continues with ORAL ORS. Cholera toxin leaves the SODIUM-GLUCOSE CO-TRANSPORTER intact, so the gut can still absorb sodium alongside glucose. The discovery of that principle produced ORS and has saved millions of lives.",
 ["سرم‌های ۱/۳-۲/۳ هیپوتونیک‌اند و برای احیای حجم در شوک هیپوولمیک مناسب نیستند.",
  "نرمال سالین انتخاب دوم است: پتاسیم و بافر ندارد و کلر بالایش می‌تواند اسیدوز را تشدید کند.",
  "پاسخ صحیح — رینگر لاکتات هم حجم و پتاسیم را جبران می‌کند و هم لاکتاتش به بی‌کربنات تبدیل شده اسیدوز را اصلاح می‌کند.",
  "دکستروز سالین هم برای احیای حجم در شوک ساخته نشده و بافر ندارد."],
 ["Third-normal fluids are hypotonic and unsuited to volume resuscitation in hypovolaemic shock.",
  "Normal saline is second best: no potassium, no buffer, and its high chloride can worsen the acidosis.",
  "Correct — Ringer's lactate replaces volume and potassium, and its lactate becomes bicarbonate, correcting the acidosis.",
  "Dextrose-saline is likewise not a resuscitation fluid and contains no buffer."],
 "کلرا مدفوعش پر از **بی‌کربنات و پتاسیم** است ← **رینگر لاکتات** (لاکتات → بی‌کربنات). بعد ORS خوراکی.",
 "Cholera stool is rich in BICARBONATE AND POTASSIUM -> RINGER'S LACTATE (lactate becomes bicarbonate). Then oral ORS.",
 [H160, 'WHO — Treatment of Cholera / Diarrhoea Management'])


# ---------------------------------------------------------------- idx 308
add("book:308", "case", "medium",
 "**کلیندامایسین** بدنام‌ترین عامل کولیت کلستریدیوم دیفیسیل است — ولی هر آنتی‌بیوتیکی می‌تواند.",
 "CLINDAMYCIN is the most notorious cause of C. difficile colitis — though any antibiotic can cause it.",
 [
  "کلستریدیوئیدس دیفیسیل بیماری‌اش را نه با تهاجم، بلکه با **حذف رقیب** شروع می‌کند.",
  "روده‌ی سالم پر از فلور طبیعی است که با اشغال فضا و مواد غذایی، مانع رشد دیفیسیل می‌شود.",
  "⚠️ آنتی‌بیوتیک این فلور را از بین می‌برد — و دیفیسیل که **اسپور** دارد زنده می‌ماند و فضا را می‌گیرد.",
  "سپس دو توکسین می‌سازد: **توکسین A** (انتروتوکسین) و **توکسین B** (سیتوتوکسین).",
  "این توکسین‌ها اسکلت سلولی را تخریب می‌کنند و **کولیت غشاء کاذب** می‌سازند.",
  "⚠️ **هر آنتی‌بیوتیکی** می‌تواند این کار را بکند — حتی خودِ مترونیدازول و وانکومایسین.",
  "ولی سه گروه بدنام‌ترند و باید حفظ شوند:",
  "**یک — کلیندامایسین**: کلاسیک‌ترین و بدنام‌ترین؛ نخستین موارد تاریخی با همین دارو توصیف شدند.",
  "**دو — سفالوسپورین‌ها**، به‌ویژه نسل سوم مثل سفتریاکسون.",
  "**سه — فلوروکینولون‌ها**، که با سویه‌ی پرخطر **NAP1/BI/027** ارتباط دارند.",
  "چرا کلیندامایسین این‌قدر بد است؟ چون **فلور بی‌هوازی روده** را بسیار قوی از بین می‌برد.",
  "و همان بی‌هوازی‌ها هستند که بیشترین رقابت را با دیفیسیل دارند.",
  "چرا فلوکونازول نه؟ ضدقارچ است و روی فلور باکتریایی روده اثر معناداری ندارد.",
  "چرا آسیکلوویر نه؟ ضدویروس است و اصلاً با باکتری‌ها کاری ندارد.",
  "پیپراسیلین-تازوباکتام می‌تواند عامل باشد، ولی خطرش از کلیندامایسین **کمتر** است.",
  "⚠️ عوامل خطر دیگر: **سن بالای ۶۵**، **بستری در بیمارستان**، و **مهارکننده‌های پمپ پروتون**.",
 ],
 [
  "Clostridioides difficile causes disease not by invading but by ELIMINATING ITS COMPETITION.",
  "A healthy gut is full of normal flora that block C. difficile by occupying space and nutrients.",
  "WARNING: an antibiotic destroys that flora — and C. difficile, which forms SPORES, survives and takes the space.",
  "It then makes two toxins: TOXIN A (an enterotoxin) and TOXIN B (a cytotoxin).",
  "These disrupt the cytoskeleton and produce PSEUDOMEMBRANOUS COLITIS.",
  "WARNING: ANY antibiotic can do this — even metronidazole and vancomycin themselves.",
  "But three groups are the most notorious and must be memorised:",
  "ONE, CLINDAMYCIN: the classic and most notorious; the first historical cases were described with it.",
  "TWO, CEPHALOSPORINS, especially third-generation agents such as ceftriaxone.",
  "THREE, FLUOROQUINOLONES, associated with the hypervirulent NAP1/BI/027 strain.",
  "Why is clindamycin so bad? Because it destroys the gut's ANAEROBIC FLORA extremely thoroughly.",
  "And it is precisely those anaerobes that compete most strongly with C. difficile.",
  "Why not fluconazole? It is an antifungal with no meaningful effect on gut bacterial flora.",
  "Why not aciclovir? It is an antiviral and has nothing to do with bacteria.",
  "Piperacillin-tazobactam can be a cause, but its risk is LOWER than clindamycin's.",
  "WARNING, other risk factors: AGE OVER 65, HOSPITALISATION, and PROTON PUMP INHIBITORS.",
 ],
 "کلستریدیوئیدس دیفیسیل بیماری‌اش را نه با تهاجم، بلکه با **حذف رقیب** ایجاد می‌کند — و فهمیدن این نکته کل بلوک سؤالات دیفیسیل را حل می‌کند.\n\nروده‌ی سالم پر از **فلور طبیعی** است که با اشغال فضا و مصرف مواد غذایی، مانع رشد دیفیسیل می‌شود. ⚠️ آنتی‌بیوتیک این فلور را از بین می‌برد، و دیفیسیل که **اسپور** می‌سازد زنده می‌ماند و فضای خالی را اشغال می‌کند. سپس **توکسین A** (انتروتوکسین) و **توکسین B** (سیتوتوکسین) می‌سازد که اسکلت سلولی را تخریب کرده و **کولیت غشاء کاذب** به وجود می‌آورند.\n\n⚠️ نکته‌ی مهم: **هر آنتی‌بیوتیکی** می‌تواند این کار را بکند — حتی مترونیدازول و وانکومایسین که خودشان درمان دیفیسیل‌اند. اما سه گروه بدنام‌ترند:\n\n۱. **کلیندامایسین** ← کلاسیک‌ترین و بدنام‌ترین\n۲. **سفالوسپورین‌ها**، به‌ویژه نسل سوم\n۳. **فلوروکینولون‌ها**، مرتبط با سویه‌ی پرخطر NAP1/BI/027\n\n**چرا کلیندامایسین سرآمد است؟** چون **فلور بی‌هوازی روده** را بسیار قوی و کامل از بین می‌برد — و دقیقاً همان بی‌هوازی‌ها بیشترین رقابت را با دیفیسیل دارند.\n\n**چرا گزینه‌های دیگر نه؟**\n• **فلوکونازول** ضدقارچ است و روی فلور باکتریایی اثر معناداری ندارد\n• **آسیکلوویر** ضدویروس است و اصلاً با باکتری‌ها کاری ندارد\n• **پیپراسیلین-تازوباکتام** می‌تواند عامل باشد، ولی خطرش از کلیندامایسین کمتر است\n\n⚠️ عوامل خطر دیگری که باید بدانید: **سن بالای ۶۵ سال، بستری طولانی در بیمارستان، و مصرف مهارکننده‌های پمپ پروتون**.",
 "Clostridioides difficile causes disease not by invading but by ELIMINATING ITS COMPETITION — and grasping that point unlocks the whole C. difficile block.\n\nA healthy gut is full of NORMAL FLORA that blocks C. difficile by occupying space and consuming nutrients. WARNING: an antibiotic destroys that flora, and C. difficile, which forms SPORES, survives and occupies the vacated space. It then produces TOXIN A (an enterotoxin) and TOXIN B (a cytotoxin), which disrupt the cytoskeleton and cause PSEUDOMEMBRANOUS COLITIS.\n\nWARNING, an important point: ANY antibiotic can do this — even metronidazole and vancomycin, which are themselves the treatment. But three groups are the most notorious:\n\n1. CLINDAMYCIN - the classic and most notorious\n2. CEPHALOSPORINS, especially third-generation\n3. FLUOROQUINOLONES, linked to the hypervirulent NAP1/BI/027 strain\n\nWHY DOES CLINDAMYCIN LEAD THE LIST? Because it destroys the gut's ANAEROBIC FLORA so thoroughly — and those anaerobes are precisely C. difficile's strongest competitors.\n\nWHY NOT THE OTHERS?\n- FLUCONAZOLE is an antifungal with no meaningful effect on bacterial flora\n- ACICLOVIR is an antiviral and has nothing to do with bacteria\n- PIPERACILLIN-TAZOBACTAM can be a cause, but its risk is lower than clindamycin's\n\nWARNING, other risk factors worth knowing: AGE OVER 65, PROLONGED HOSPITALISATION, and PROTON PUMP INHIBITORS.",
 ["فلوکونازول ضدقارچ است و روی فلور باکتریایی روده اثر معناداری ندارد.",
  "پیپراسیلین-تازوباکتام می‌تواند عامل باشد، ولی خطرش به‌مراتب کمتر از کلیندامایسین است.",
  "آسیکلوویر ضدویروس است و هیچ اثری بر فلور باکتریایی روده ندارد.",
  "پاسخ صحیح — کلیندامایسین با تخریب کامل فلور بی‌هوازی، بدنام‌ترین عامل کولیت دیفیسیل است."],
 ["Fluconazole is an antifungal with no meaningful effect on gut bacterial flora.",
  "Piperacillin-tazobactam can be a cause, but its risk is far lower than clindamycin's.",
  "Aciclovir is an antiviral and has no effect on gut bacterial flora.",
  "Correct — by destroying the anaerobic flora, clindamycin is the most notorious cause of C. difficile colitis."],
 "دیفیسیل = **حذف فلور** توسط آنتی‌بیوتیک. بدنام‌ترین‌ها: **کلیندامایسین، سفالوسپورین، کینولون**.",
 "C. difficile = antibiotic WIPES OUT THE FLORA. The worst offenders: CLINDAMYCIN, CEPHALOSPORINS, QUINOLONES.",
 [H133, IDSA])


# ---------------------------------------------------------------- idx 316
add("book:316", "case", "medium",
 "⚠️ اسپور دیفیسیل **به الکل مقاوم است** ← دست را با **آب و صابون** بشوی، نه ژل الکلی.",
 "WARNING: C. difficile spores RESIST ALCOHOL — wash hands with SOAP AND WATER, not alcohol gel.",
 [
  "این نکته در همین فصل **سه بار** پرسیده شده، و کاملاً برخلاف عادت روزمره‌ی بیمارستانی است.",
  "در تقریباً همه‌ی عفونت‌ها، **ژل الکلی** بهترین و سریع‌ترین روش بهداشت دست است.",
  "⚠️ اما کلستریدیوم دیفیسیل یک استثنای مهم است، و دلیلش **اسپور** است.",
  "الکل با **دناتوره کردن پروتئین** و حل کردن غشای لیپیدی، میکروب را می‌کشد.",
  "اما اسپور غشای لیپیدی فعال ندارد؛ یک **پوسته‌ی پروتئینی متراکم و بی‌آب** است.",
  "پس الکل به آن نفوذ نمی‌کند و **اسپور را نمی‌کشد** — فقط رویش می‌لغزد.",
  "⚠️ در مقابل، **آب و صابون** اسپور را نمی‌کشد ولی کار مهم‌تری می‌کند: **آن را می‌شوید و می‌برد**.",
  "این تفاوت بنیادی است: الکل **کشتن** است، صابون **حذف مکانیکی**.",
  "و برای چیزی که کشته نمی‌شود، حذف مکانیکی تنها راه است.",
  "پس در بیمار دیفیسیل، **آب و صابون بر ژل الکلی ارجحیت دارد**.",
  "همین منطق برای **سطوح** هم صادق است.",
  "پاک‌کننده‌های معمولی اسپور را از بین نمی‌برند؛ **هیپوکلریت (وایتکس)** لازم است.",
  "⚠️ هیپوکلریت یک اکسیدکننده‌ی قوی است و می‌تواند پوسته‌ی اسپور را تخریب کند.",
  "اقدامات کامل کنترل: **ایزولاسیون تماسی**، **دستکش و گان**، **آب و صابون**، **وایتکس**.",
  "و مهم‌تر از همه‌ی این‌ها: **محدود کردن مصرف بی‌مورد آنتی‌بیوتیک** (استوارد‌شیپ).",
  "⚠️ نکته‌ی پایانی: **غربالگری و درمان ناقلان بی‌علامت توصیه نمی‌شود** و مؤثر نیست.",
 ],
 [
  "This point is asked THREE times in this chapter, and it runs against everyday hospital habit.",
  "In almost every infection, ALCOHOL GEL is the best and fastest hand hygiene.",
  "WARNING: C. difficile is an important exception, and the reason is the SPORE.",
  "Alcohol kills by DENATURING PROTEIN and dissolving the lipid membrane.",
  "But a spore has no active lipid membrane; it is a dense, desiccated PROTEIN COAT.",
  "So alcohol does not penetrate it and DOES NOT KILL THE SPORE — it merely slides over it.",
  "WARNING: SOAP AND WATER, by contrast, do not kill the spore but do something better — THEY WASH IT AWAY.",
  "That distinction is fundamental: alcohol KILLS, soap REMOVES MECHANICALLY.",
  "And for something that cannot be killed, mechanical removal is the only option.",
  "So with a C. difficile patient, SOAP AND WATER IS PREFERRED OVER ALCOHOL GEL.",
  "The same logic applies to SURFACES.",
  "Ordinary cleaners do not destroy spores; HYPOCHLORITE (bleach) is required.",
  "WARNING: hypochlorite is a strong oxidising agent and can destroy the spore coat.",
  "The full control package: CONTACT ISOLATION, GLOVES AND GOWN, SOAP AND WATER, BLEACH.",
  "And more important than any of them: LIMITING UNNECESSARY ANTIBIOTIC USE (stewardship).",
  "WARNING, a final point: SCREENING AND TREATING ASYMPTOMATIC CARRIERS IS NOT RECOMMENDED and is ineffective.",
 ],
 "این نکته در همین فصل **سه بار** پرسیده شده، و ارزشش در این است که کاملاً برخلاف عادت روزمره‌ی بیمارستانی است.\n\nدر تقریباً همه‌ی عفونت‌ها، **ژل الکلی** بهترین و سریع‌ترین روش بهداشت دست است. ⚠️ اما کلستریدیوم دیفیسیل یک **استثنای مهم** است، و دلیلش در یک کلمه خلاصه می‌شود: **اسپور**.\n\n**چرا الکل کار نمی‌کند؟**\nالکل با **دناتوره کردن پروتئین** و حل کردن **غشای لیپیدی** میکروب را می‌کشد. اما اسپور غشای لیپیدی فعال ندارد — یک **پوسته‌ی پروتئینی متراکم و تقریباً بی‌آب** است. الکل به آن نفوذ نمی‌کند و فقط رویش می‌لغزد.\n\n**پس چرا آب و صابون بهتر است؟**\n⚠️ نکته‌ی ظریف اینجاست: **آب و صابون هم اسپور را نمی‌کشد** — ولی کار مهم‌تری می‌کند: **آن را از روی دست می‌شوید و می‌برد**.\n\nاین تفاوت بنیادی است:\n• الکل = **کشتن**\n• صابون = **حذف مکانیکی**\n\nو برای چیزی که کشته نمی‌شود، **حذف مکانیکی تنها راه است**.\n\n**همین منطق برای سطوح هم صادق است:** پاک‌کننده‌های معمولی اسپور را از بین نمی‌برند و **هیپوکلریت (وایتکس)** لازم است، چون یک اکسیدکننده‌ی قوی است که می‌تواند پوسته‌ی اسپور را تخریب کند.\n\n**بسته‌ی کامل کنترل عفونت دیفیسیل:**\n• ایزولاسیون تماسی\n• دستکش و گان\n• **آب و صابون** (نه ژل الکلی)\n• **وایتکس** برای سطوح\n• و مهم‌تر از همه: **محدود کردن مصرف بی‌مورد آنتی‌بیوتیک**\n\n⚠️ و یک نکته‌ی پایانی: **غربالگری و درمان ناقلان بی‌علامت توصیه نمی‌شود** و در کنترل طغیان مؤثر نیست.",
 "This point is asked THREE times in this chapter, and its value lies in running directly against everyday hospital habit.\n\nIn almost every infection, ALCOHOL GEL is the best and fastest hand hygiene. WARNING: C. difficile is an IMPORTANT EXCEPTION, and the reason reduces to one word: THE SPORE.\n\nWHY DOESN'T ALCOHOL WORK?\nAlcohol kills by DENATURING PROTEIN and dissolving the LIPID MEMBRANE. But a spore has no active lipid membrane — it is a dense, almost desiccated PROTEIN COAT. Alcohol cannot penetrate it and merely slides over it.\n\nSO WHY IS SOAP AND WATER BETTER?\nWARNING, here is the subtlety: SOAP AND WATER DOES NOT KILL THE SPORE EITHER — but it does something better: IT WASHES IT OFF THE HANDS.\n\nThat distinction is fundamental:\n- Alcohol = KILLING\n- Soap = MECHANICAL REMOVAL\n\nAnd for something that cannot be killed, MECHANICAL REMOVAL IS THE ONLY OPTION.\n\nTHE SAME LOGIC APPLIES TO SURFACES: ordinary cleaners do not destroy spores, and HYPOCHLORITE (bleach) is required, being a strong oxidising agent able to destroy the spore coat.\n\nTHE FULL C. DIFFICILE CONTROL PACKAGE:\n- Contact isolation\n- Gloves and gown\n- SOAP AND WATER (not alcohol gel)\n- BLEACH for surfaces\n- And most important of all: LIMITING UNNECESSARY ANTIBIOTIC USE\n\nWARNING, a final point: SCREENING AND TREATING ASYMPTOMATIC CARRIERS is not recommended and does not help control an outbreak.",
 ["پاسخ صحیح — الکل اسپور دیفیسیل را نمی‌کشد، پس کم‌اثرترین گزینه در پیشگیری از انتقال است.",
  "شست‌وشوی اتاق با محلول سفیدکننده مؤثر است، چون هیپوکلریت اکسیدکننده‌ای است که اسپور را تخریب می‌کند.",
  "شستن دست با آب و صابون اسپور را نمی‌کشد ولی آن را از روی دست می‌شوید و می‌برد — مؤثرترین روش بهداشت دست اینجاست.",
  "محدود کردن مصرف آنتی‌بیوتیک مؤثرترین اقدام بلندمدت در کاهش موارد دیفیسیل است."],
 ["Correct — alcohol does not kill C. difficile spores, so it is the least effective option for preventing transmission.",
  "Washing the room with bleach is effective, because hypochlorite is an oxidiser that destroys the spore coat.",
  "Soap and water does not kill the spore but washes it off the hands — the most effective hand hygiene here.",
  "Restricting antibiotic use is the most effective long-term measure for reducing C. difficile cases."],
 "اسپور دیفیسیل: **الکل نمی‌کشد** ← آب و صابون (حذف مکانیکی). سطوح ← **وایتکس**. و آنتی‌بیوتیک را محدود کن.",
 "C. difficile spores: ALCOHOL DOES NOT KILL THEM -> soap and water (mechanical removal). Surfaces -> BLEACH. And restrict antibiotics.",
 [H133, IDSA])


# ---------------------------------------------------------------- idx 434
add("book:434", "case", "medium",
 "سالمونلای **غیرتیفوئیدی** در فرد سالم = **درمان حمایتی**؛ آنتی‌بیوتیک **ناقلی را طولانی می‌کند**.",
 "NON-TYPHOIDAL salmonella in a healthy host = SUPPORTIVE care; antibiotics PROLONG CARRIAGE.",
 SPLIT_FA + [
  "این یکی از پرتکرارترین «تله‌های درمانی» فصل است: اسهال خونی داریم، ولی آنتی‌بیوتیک نمی‌دهیم.",
  "⚠️ قاعده: **سالمونلای غیرتیفوئیدی در میزبان سالم، درمان آنتی‌بیوتیکی نمی‌خواهد.**",
  "دو دلیل محکم دارد.",
  "**دلیل یک**: بیماری **خودمحدودشونده** است و ظرف ۵ تا ۷ روز خودبه‌خود خوب می‌شود.",
  "آنتی‌بیوتیک **مدت اسهال را کوتاه نمی‌کند** — کارآزمایی‌ها این را نشان داده‌اند.",
  "⚠️ **دلیل دو، و مهم‌تر**: آنتی‌بیوتیک **دفع باکتری از مدفوع را طولانی‌تر می‌کند**.",
  "چرا؟ چون فلور طبیعی روده را می‌زند، و همان فلور است که سالمونلا را بیرون می‌راند.",
  "پس بیمار **بیشتر ناقل می‌ماند** و بیشتر دیگران را آلوده می‌کند — دقیقاً برعکس هدف.",
  "و خطر سوم: افزایش احتمال **عود** پس از قطع دارو.",
  "⚠️ حالا استثناها، که باید جداگانه حفظ شوند — در این گروه‌ها **حتماً** درمان می‌کنیم:",
  "**سن**: شیرخوار زیر ۳ ماه، و سالمند بالای ۵۰ سال (به‌خاطر خطر آنوریسم).",
  "**نقص ایمنی**: HIV، پیوند، کورتیکواستروئید، بدخیمی.",
  "**بیماری زمینه‌ای عروقی**: پروتز عروقی، آنوریسم، دریچه‌ی مصنوعی قلب.",
  "**همولیز**: به‌ویژه **کم‌خونی داسی‌شکل** (خطر استئومیلیت سالمونلایی).",
  "**بیماری شدید**: تب بالا، باکتریمی مستند، بستری.",
  "این بیمار **جوان و بدون بیماری زمینه‌ای** است، پس هیچ‌کدام از استثناها صدق نمی‌کند.",
 ],
 SPLIT_EN + [
  "This is one of the chapter's commonest therapeutic traps: there is bloody diarrhoea, yet no antibiotic is given.",
  "WARNING, the rule: NON-TYPHOIDAL SALMONELLA IN A HEALTHY HOST NEEDS NO ANTIBIOTIC.",
  "There are two solid reasons.",
  "REASON ONE: the illness is SELF-LIMITING and resolves in 5-7 days.",
  "Antibiotics DO NOT SHORTEN THE DIARRHOEA — trials have shown this.",
  "WARNING, REASON TWO, and the more important: ANTIBIOTICS PROLONG FAECAL SHEDDING.",
  "Why? They damage the normal gut flora, and it is that flora which drives salmonella out.",
  "So the patient REMAINS A CARRIER LONGER and infects more people — the opposite of the intent.",
  "And a third hazard: a greater chance of RELAPSE after the drug is stopped.",
  "WARNING, now the exceptions, to be memorised separately — these groups ARE treated:",
  "AGE: infants under 3 months, and adults over 50 (because of aneurysm risk).",
  "IMMUNODEFICIENCY: HIV, transplantation, corticosteroids, malignancy.",
  "VASCULAR DISEASE: vascular grafts, aneurysms, prosthetic heart valves.",
  "HAEMOLYSIS: especially SICKLE CELL DISEASE (risk of salmonella osteomyelitis).",
  "SEVERE ILLNESS: high fever, documented bacteraemia, hospitalisation.",
  "This patient is YOUNG AND WITHOUT UNDERLYING DISEASE, so none of the exceptions applies.",
 ],
 "این یکی از پرتکرارترین «تله‌های درمانی» این فصل است: بیمار **اسهال خونی** دارد و کشت مدفوعش **سالمونلا** نشان می‌دهد — و پاسخ درست این است که **آنتی‌بیوتیک ندهیم**.\n\n⚠️ **قاعده: سالمونلای غیرتیفوئیدی در میزبان سالم، درمان آنتی‌بیوتیکی نمی‌خواهد.** دو دلیل محکم دارد:\n\n**دلیل یک — آنتی‌بیوتیک سودی ندارد.** بیماری **خودمحدودشونده** است و ظرف ۵ تا ۷ روز خودبه‌خود برطرف می‌شود. کارآزمایی‌ها نشان داده‌اند که آنتی‌بیوتیک **مدت اسهال را کوتاه نمی‌کند**.\n\n⚠️ **دلیل دو — و مهم‌تر: آنتی‌بیوتیک زیان دارد.** دادن آنتی‌بیوتیک **مدت دفع باکتری از مدفوع را طولانی‌تر می‌کند**.\n\nسازوکارش منطقی است: آنتی‌بیوتیک **فلور طبیعی روده** را می‌زند، و همان فلور است که با رقابت، سالمونلا را از روده بیرون می‌راند. با حذف رقیب، سالمونلا بیشتر می‌ماند. نتیجه: بیمار **مدت بیشتری ناقل** است و مدت بیشتری دیگران را آلوده می‌کند — دقیقاً برعکس هدف. خطر سوم هم افزایش احتمال **عود** پس از قطع دارو است.\n\n⚠️ **اما استثناها را باید جداگانه حفظ کرد.** در این گروه‌ها **حتماً** درمان می‌کنیم:\n\n• **سنین دو سر طیف**: شیرخوار زیر ۳ ماه، بزرگسال بالای ۵۰ سال\n• **نقص ایمنی**: HIV، پیوند، کورتیکواستروئید، بدخیمی\n• **بیماری عروقی**: پروتز عروقی، آنوریسم، دریچه‌ی مصنوعی قلب\n• **حالات همولیتیک**: به‌ویژه **کم‌خونی داسی‌شکل** (خطر استئومیلیت سالمونلایی)\n• **بیماری شدید**: تب بالا، باکتریمی مستند، نیاز به بستری\n\nاین بیمار **جوان ۲۰ ساله و بدون سابقه‌ی بیماری** است، پس هیچ‌یک از استثناها صدق نمی‌کند و پاسخ **درمان حمایتی بدون آنتی‌بیوتیک** است.",
 "This is one of the chapter's commonest therapeutic traps: the patient has BLOODY DIARRHOEA and the stool culture grows SALMONELLA — and the correct answer is TO WITHHOLD ANTIBIOTICS.\n\nWARNING, THE RULE: NON-TYPHOIDAL SALMONELLA IN A HEALTHY HOST NEEDS NO ANTIBIOTIC. There are two solid reasons:\n\nREASON ONE — ANTIBIOTICS DO NOT HELP. The illness is SELF-LIMITING and resolves in 5-7 days. Trials have shown that antibiotics DO NOT SHORTEN THE DIARRHOEA.\n\nWARNING, REASON TWO — AND MORE IMPORTANT: ANTIBIOTICS DO HARM. Giving one PROLONGS FAECAL SHEDDING of the organism.\n\nThe mechanism is logical: the antibiotic damages the NORMAL GUT FLORA, and it is that flora which competitively drives salmonella out. Remove the competition and salmonella persists. The result: the patient REMAINS A CARRIER LONGER and infects others for longer — the opposite of the intent. A third hazard is a greater chance of RELAPSE after the drug stops.\n\nWARNING, BUT THE EXCEPTIONS MUST BE MEMORISED SEPARATELY. These groups ARE treated:\n\n- BOTH EXTREMES OF AGE: infants under 3 months, adults over 50\n- IMMUNODEFICIENCY: HIV, transplantation, corticosteroids, malignancy\n- VASCULAR DISEASE: vascular grafts, aneurysms, prosthetic valves\n- HAEMOLYTIC STATES: especially SICKLE CELL DISEASE (risk of salmonella osteomyelitis)\n- SEVERE ILLNESS: high fever, documented bacteraemia, need for admission\n\nThis patient is a HEALTHY 20-YEAR-OLD, so none of the exceptions applies, and the answer is SUPPORTIVE CARE WITHOUT ANTIBIOTICS.",
 ["سفیکسیم سه‌روزه در فرد سالم لازم نیست و دفع باکتری را طولانی‌تر می‌کند.",
  "سیپروفلوکساسین یک‌هفته‌ای برای موارد پرخطر است، نه برای جوان سالم بدون بیماری زمینه‌ای.",
  "پاسخ صحیح — سالمونلای غیرتیفوئیدی در میزبان سالم خودمحدودشونده است و آنتی‌بیوتیک ناقلی را طولانی می‌کند.",
  "آزیترومایسین پنج‌روزه هم در این بیمار اندیکاسیون ندارد و همان زیان طولانی شدن ناقلی را دارد."],
 ["A three-day course of cefixime is unnecessary in a healthy host and prolongs shedding.",
  "A week of ciprofloxacin is for high-risk cases, not a healthy young adult without comorbidity.",
  "Correct — non-typhoidal salmonella is self-limiting in a healthy host, and antibiotics prolong carriage.",
  "Five days of azithromycin is likewise not indicated here and carries the same risk of prolonged carriage."],
 "سالمونلای غیرتیفوئیدی سالم = **بدون آنتی‌بیوتیک** (ناقلی را طولانی می‌کند). استثنا: سن دو سر طیف، نقص ایمنی، عروقی، داسی‌شکل.",
 "Non-typhoidal salmonella, healthy host = NO ANTIBIOTIC (it prolongs carriage). Exceptions: age extremes, immunodeficiency, vascular disease, sickle cell.",
 [H160, IDSA])


# ---------------------------------------------------------------- idx 430
add("book:430", "case", "hard",
 "تیفوئید با آنتی‌بیوتیکِ **از قبل شروع‌شده** ← **کشت مغز استخوان** حساس‌ترین است.",
 "In typhoid where ANTIBIOTICS HAVE ALREADY BEEN STARTED, BONE MARROW CULTURE is the most sensitive test.",
 [
  "**تب روده‌ای (تیفوئید)** یک تابلوی بسیار مشخص دارد که با اسهال حاد اشتباه می‌شود.",
  "⚠️ نکته‌ی اول و پرتکرارترین: تیفوئید معمولاً **یبوست** می‌دهد نه اسهال — به‌ویژه در بزرگسالان.",
  "**تب پلکانی (step-ladder)**: تب هر روز کمی بالاتر می‌رود، طی یک تا دو هفته.",
  "⚠️ **برادی‌کاردی نسبی (علامت فاژه)**: تب ۳۹ درجه ولی نبض فقط ۷۰ تا ۸۰.",
  "معمولاً به ازای هر درجه تب، نبض ~۱۰ می‌رود بالا؛ در تیفوئید این اتفاق نمی‌افتد.",
  "**رزئولا (rose spots)**: ماکول‌های صورتی کم‌رنگ روی تنه که با فشار **محو می‌شوند**.",
  "**اسپلنومگالی**، درد شکم (اغلب **ربع تحتانی راست**)، سردرد، و حالت **گیج و مات** (تیفوس‌مانند).",
  "⚠️ آزمایشگاه: **لکوپنی** — که در یک عفونت باکتریایی شدید غیرمنتظره است و سرنخ مهمی است.",
  "حالا سؤال تشخیصی، که در این فصل **سه بار** پرسیده شده.",
  "**کشت خون**: در هفته‌ی اول حساسیت خوبی دارد (~۸۰٪) و اولین انتخاب است.",
  "⚠️ **اما اگر آنتی‌بیوتیک شروع شده باشد، حساسیت کشت خون به‌شدت افت می‌کند.**",
  "دلیلش روشن است: آنتی‌بیوتیک باکتری را از **جریان خون** پاک می‌کند.",
  "**کشت مغز استخوان** اما حساسیتش **بالای ۹۰ درصد** می‌ماند — حتی پس از چند روز آنتی‌بیوتیک.",
  "چرا؟ چون سالمونلا تیفی یک باکتری **داخل‌سلولی** است که در **ماکروفاژهای سیستم رتیکولواندوتلیال** پناه می‌گیرد.",
  "مغز استخوان انباشته از همان ماکروفاژهاست، و غلظت آنتی‌بیوتیک آنجا کمتر به باکتری می‌رسد.",
  "پس مغز استخوان **آخرین سنگری** است که باکتری در آن باقی می‌ماند.",
  "⚠️ سرولوژی (تست ویدال) حساسیت و ویژگی ضعیفی دارد و **نباید** مبنای تشخیص باشد.",
  "کشت مدفوع هم در هفته‌های بعدی مثبت می‌شود، ولی برای تشخیص حاد قابل اتکا نیست.",
 ],
 [
  "ENTERIC FEVER (typhoid) has a very characteristic picture that is often confused with acute diarrhoea.",
  "WARNING, the first and most examined point: typhoid usually causes CONSTIPATION, not diarrhoea — especially in adults.",
  "STEP-LADDER FEVER: the temperature climbs a little higher each day over one to two weeks.",
  "WARNING, RELATIVE BRADYCARDIA (Faget's sign): a temperature of 39 with a pulse of only 70-80.",
  "Normally the pulse rises about 10 per degree of fever; in typhoid it does not.",
  "ROSE SPOTS: faint pink macules on the trunk that BLANCH on pressure.",
  "SPLENOMEGALY, abdominal pain (often RIGHT LOWER QUADRANT), headache, and an apathetic, dulled state.",
  "WARNING, the laboratory: LEUCOPENIA — unexpected in a severe bacterial infection and an important clue.",
  "Now the diagnostic question, asked THREE times in this chapter.",
  "BLOOD CULTURE has good sensitivity in the first week (about 80%) and is the first choice.",
  "WARNING: BUT ONCE ANTIBIOTICS HAVE BEEN STARTED, THE SENSITIVITY OF BLOOD CULTURE FALLS SHARPLY.",
  "The reason is clear: the antibiotic clears the organism from THE BLOODSTREAM.",
  "BONE MARROW CULTURE, however, retains a sensitivity ABOVE 90% — even after several days of antibiotics.",
  "Why? Because Salmonella typhi is an INTRACELLULAR organism that shelters in the MACROPHAGES of the reticuloendothelial system.",
  "The marrow is packed with those macrophages, and antibiotic reaches the organism there less effectively.",
  "So the marrow is the LAST REDOUBT in which the organism persists.",
  "WARNING: serology (the Widal test) has poor sensitivity and specificity and should NOT be the basis of diagnosis.",
  "Stool culture becomes positive in later weeks but is unreliable for acute diagnosis.",
 ],
 "این بیمار تابلوی کلاسیک **تب روده‌ای (تیفوئید)** دارد، و صورت سؤال تقریباً همه‌ی نشانه‌های کتاب‌درسی را جمع کرده:\n\n• **تب پلکانی سه‌هفته‌ای** ✓\n• ⚠️ **یبوست** ✓ ← نکته‌ای که تیفوئید را از اسهال حاد جدا می‌کند\n• **درد ربع تحتانی راست** ✓\n• **گیج و مات بودن** ✓ ← همان حالت آپاتیک تیفوئید\n• ⚠️ **برادی‌کاردی نسبی**: تب ۳۸ درجه با نبض فقط ۷۴ ✓\n• ⚠️ **لکوپنی ۳۳۰۰** ✓ ← در یک عفونت باکتریایی شدید، غیرمنتظره و بسیار گویا\n\n**و حالا سؤال اصلی: چرا کشت مغز استخوان؟**\n\nدر حالت عادی **کشت خون** انتخاب اول است و در هفته‌ی نخست حدود ۸۰ درصد حساسیت دارد.\n\n⚠️ **اما این بیمار از قبل ۶ روز سفتریاکسون گرفته است** — و همین همه‌چیز را عوض می‌کند. آنتی‌بیوتیک باکتری را از **جریان خون** پاک می‌کند، پس حساسیت کشت خون به‌شدت افت می‌کند.\n\n**کشت مغز استخوان** اما حساسیتش **بالای ۹۰ درصد** باقی می‌ماند، حتی پس از چند روز درمان. دلیلش زیباست:\n\nسالمونلا تیفی یک باکتری **داخل‌سلولی** است که در **ماکروفاژهای سیستم رتیکولواندوتلیال** پناه می‌گیرد. مغز استخوان انباشته از همین ماکروفاژهاست، و آنتی‌بیوتیک در آن پناهگاه کمتر به باکتری می‌رسد. پس مغز استخوان **آخرین سنگری** است که باکتری در آن زنده می‌ماند.\n\n**چرا گزینه‌های دیگر نه؟**\n• **کشت خون** ← پس از شروع آنتی‌بیوتیک حساسیتش افت کرده\n• **سرولوژی (ویدال)** ← حساسیت و ویژگی ضعیف؛ نباید مبنای تشخیص باشد\n• **کشت مدفوع** ← در هفته‌های بعدی مثبت می‌شود ولی برای تشخیص حاد قابل اتکا نیست",
 "This patient has the classic picture of ENTERIC FEVER (typhoid), and the stem assembles almost every textbook feature:\n\n- THREE WEEKS OF STEP-LADDER FEVER (yes)\n- WARNING, CONSTIPATION (yes) - the feature that separates typhoid from acute diarrhoea\n- RIGHT LOWER QUADRANT PAIN (yes)\n- A DULLED, APATHETIC STATE (yes)\n- WARNING, RELATIVE BRADYCARDIA: temperature 38 with a pulse of only 74 (yes)\n- WARNING, LEUCOPENIA OF 3300 (yes) - unexpected in severe bacterial infection and highly informative\n\nAND NOW THE REAL QUESTION: WHY BONE MARROW CULTURE?\n\nOrdinarily BLOOD CULTURE is the first choice, with about 80% sensitivity in the first week.\n\nWARNING: BUT THIS PATIENT HAS ALREADY HAD SIX DAYS OF CEFTRIAXONE — and that changes everything. The antibiotic clears the organism from THE BLOODSTREAM, so blood-culture sensitivity falls sharply.\n\nBONE MARROW CULTURE, by contrast, retains a sensitivity ABOVE 90% even after several days of treatment. The reason is elegant:\n\nSalmonella typhi is an INTRACELLULAR organism that shelters in the MACROPHAGES OF THE RETICULOENDOTHELIAL SYSTEM. The marrow is packed with those macrophages, and antibiotic penetrates that sanctuary less effectively. The marrow is therefore the LAST REDOUBT in which the organism survives.\n\nWHY NOT THE OTHERS?\n- BLOOD CULTURE -> sensitivity has fallen once antibiotics were started\n- SEROLOGY (Widal) -> poor sensitivity and specificity; not a basis for diagnosis\n- STOOL CULTURE -> becomes positive in later weeks but is unreliable acutely",
 ["پاسخ صحیح — کشت مغز استخوان پس از شروع آنتی‌بیوتیک حساسیتش بالای ۹۰٪ می‌ماند، چون باکتری در ماکروفاژهای مغز استخوان پناه گرفته.",
  "تست ویدال حساسیت و ویژگی ضعیفی دارد و نباید مبنای تشخیص تیفوئید باشد.",
  "کشت خون انتخاب اول است ولی پس از ۶ روز سفتریاکسون حساسیتش به‌شدت افت کرده است.",
  "کشت مدفوع در هفته‌های بعدی بیماری مثبت می‌شود و برای تشخیص حاد قابل اتکا نیست."],
 ["Correct — bone marrow culture retains over 90% sensitivity after antibiotics, because the organism shelters in marrow macrophages.",
  "The Widal test has poor sensitivity and specificity and should not form the basis of a typhoid diagnosis.",
  "Blood culture is the first choice, but its sensitivity has fallen sharply after six days of ceftriaxone.",
  "Stool culture turns positive in later weeks and is unreliable for acute diagnosis."],
 "تیفوئید: **یبوست + برادی‌کاردی نسبی + رزئولا + لکوپنی**. آنتی‌بیوتیک شروع شده؟ ← **کشت مغز استخوان**.",
 "Typhoid: CONSTIPATION + RELATIVE BRADYCARDIA + ROSE SPOTS + LEUCOPENIA. Antibiotics already started? -> BONE MARROW CULTURE.",
 [H160])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book15.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 15 lessons:', len(L))
