# -*- coding: utf-8 -*-
"""English stems and options for the batch-24 and batch-25 questions (skin and
soft tissue).

Rule 16 checked first, as always: these are sittings 93 to 98, for which the
ministry published no English booklet, so these are hand-written translations.

Translation decisions worth recording
-------------------------------------
q9017 (idx 17): the vital signs were stored as "min011" and "min26", the unit
glued to a mirrored number. Page 7 prints 110 and 26, and fix_skin_numbers.py
repaired them. The English quotes the corrected values, because the tachycardia
and tachypnoea ARE the evidence of sepsis in an asplenic boy.

q9025 (idx 25): the temperature was stored as "3/83"; page 10 prints 38.3. The
English writes 38.3, since 83 degrees is not a temperature.

q9028 (idx 28): two mirrored values on one line — the blood pressure and the
respiratory rate. Page 12 prints "70/p" and "130". The English quotes both as
printed. The systolic of 70 with an unrecordable diastolic is the shock that
makes the question answerable; the respiratory rate of 130 is what the page
prints and is quoted faithfully rather than silently "improved".

q9031 (idx 31): "01 نفر" was a mirrored 10. The English says "ten employees",
which matters: ten people with painless eschars and no animal contact is an
outbreak, and the outbreak is why the answer is 60 days of ciprofloxacin.

q9035 (idx 35): the age in the fourth option was a mirrored 23 for 32 (page 15).

q9060 (idx 60): "لکوسیتوز 00091" was a mirrored 19000 (page 23).

q9061 (idx 61): the first draft of this translation summarised the stem and dropped
the examination findings and the laboratory panel. apply_en.py's numeric inspector
rejected it — 'numbers lost in translation: 1000, 17000, 39' — and it was right to.
The dropped findings were not decoration: INVOLVEMENT OF THE PALMS AND SOLES and
ORAL MUCOSAL LESIONS are two of the diagnostic criteria of toxic shock syndrome, and
a CPK of 1000 is the muscular organ involvement that a third criterion requires. An
English reader given the abbreviated stem could not have reached the answer. The
translation now carries the whole panel.
"""

EN11 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    assert all(o.strip() for o in options), idx
    EN11[idx] = {"stem_en": stem, "options_en": options}


# =================================================== cellulitis etc (batch 24)
add(11,
    "A 26-year-old man attends the clinic complaining of pain and redness of the middle of the "
    "right forearm. His oral temperature is 37 degrees Celsius, and he has tenderness, erythema, "
    "swelling and warmth over the mid right forearm. Which of the following is NOT recommended "
    "for his treatment?",
    ["Oxacillin", "Cefixime", "Erythromycin", "Clindamycin"])

add(10,
    "A 25-year-old man attends with pain and swelling of the leg since yesterday. He is febrile, "
    "and examination shows swelling, warmth and redness of the leg measuring 3 cm. There is also "
    "a tender raised red streak beginning at the proximal edge of the lesion and extending to "
    "mid-thigh. Which of the following is the commonest causative organism?",
    ["Staphylococcus aureus", "Streptococcus pyogenes", "Pseudomonas aeruginosa",
     "Aeromonas hydrophila"])

add(17,
    "An adolescent boy who underwent splenectomy years ago after trauma develops, a few days "
    "after being attacked by a stray dog, high fever, a leucocytosis of 13 thousand, tachycardia "
    "of 110 per minute, tachypnoea of 26 per minute and thrombocytopenia of 60 thousand. Blood "
    "culture grows a gram-negative coccobacillus. He deteriorates rapidly, develops haemorrhagic "
    "bullae over the body and enters septic shock. Which of the following organisms is "
    "responsible for this illness?",
    ["Vibrio vulnificus", "Capnocytophaga canimorsus", "Staphylococcus aureus",
     "Pseudomonas aeruginosa"])

add(20,
    "A young fishmonger is admitted with extensive swelling and redness of the hand together "
    "with fever and rigors. He reports cutting his hand while cleaning fish. If infection with "
    "Erysipelothrix rhusiopathiae is suspected, which of the following drugs must NOT be used?",
    ["Vancomycin", "Clindamycin", "Cefazolin", "Penicillin"])

add(23,
    "A 55-year-old man with liver cirrhosis ate raw shellfish after a trip to Qeshm island. He "
    "presents with fever, rigors, a fall in blood pressure and widespread haemorrhagic bullous "
    "lesions over the body surface. Investigations show leucocytosis. Which organism is the "
    "likely cause of the bacteraemia in this patient?",
    ["Vibrio vulnificus", "Capnocytophaga canimorsus", "Staphylococcus aureus",
     "Pseudomonas aeruginosa"])

add(24,
    "A 28-year-old man presents after strenuous physical exertion with severe pain and swelling "
    "of the upper calf for the past 2 days. Examination shows warmth, swelling and erythema of "
    "the area. He has a low fever. His blood pressure is 95/60 and his pulse rate is 115. "
    "Investigations show a leucocytosis with a left shift (87%) and a creatinine of 2.1. What is "
    "the most appropriate course of action for this patient?",
    ["Colour Doppler ultrasound and starting heparin",
     "Surgical consultation for debridement and starting antibiotics",
     "Starting antibiotics and cardiology consultation for echocardiography",
     "Starting antibiotics and heparin"])

add(25,
    "A 50-year-old diabetic woman with a history of a pulled thigh muscle is brought to the "
    "emergency department with fever, weakness, malaise and severe pain in the front of the "
    "thigh. On examination her blood pressure is 80/50 mmHg, heart rate 110 beats per minute, "
    "respiratory rate 30 per minute and temperature 38.3. There is mild erythema over the "
    "anterior thigh with marked tenderness on palpation. Given the likely diagnosis, and in "
    "addition to fluid therapy, which is more appropriate?",
    ["Soft tissue ultrasound and vancomycin plus clindamycin plus gentamicin",
     "Starting meropenem plus vancomycin",
     "Vancomycin plus clindamycin plus ciprofloxacin with rapid surgical exploration",
     "Starting ceftriaxone plus clindamycin with rapid surgical exploration"])

add(28,
    "A 25-year-old woman is seen in the emergency department with drowsiness and shock. Five "
    "days ago she underwent an illegal abortion and subsequently had heavy bleeding. On "
    "examination her vital signs are: blood pressure 70/p, respiratory rate 130 and temperature "
    "37. She has widespread limb oedema, hypogastric tenderness and non-purulent serosanguineous "
    "vaginal discharge. Investigations show a white cell count of 27000 with a neutrophil "
    "predominance, a haematocrit of 45, platelets of 90000 and a creatinine of 3. Which pathogen "
    "do you consider more likely to have produced this clinical picture?",
    ["Clostridium", "Escherichia coli", "Staphylococcus aureus", "Group B streptococcus"])

add(61,
    "A 30-year-old woman is referred to the emergency department with fever, generalised "
    "erythroderma, restlessness, abdominal pain, diarrhoea and vomiting. Her companions report "
    "that her symptoms began about 7 days ago during her menstrual period and worsened "
    "gradually. On examination you find hypotension (systolic blood pressure 80 mmHg), a "
    "temperature of 39 degrees Celsius, generalised maculopapular rashes involving the palms and "
    "soles, and oral mucosal lesions. There is no history of drug use, travel or animal contact "
    "before the onset of symptoms. Her investigations are as follows: creatinine 3.1, CPK 1000, "
    "WBC 17000, platelets 80,000. In addition to supportive care and correction of fluid and "
    "electrolytes, what is the most appropriate treatment given the most likely diagnosis?",
    ["Give steroids", "Give vancomycin and immunoglobulin",
     "Give clindamycin and steroids",
     "Give clindamycin, linezolid and immunoglobulin"])


# ============================== streptococcal pharyngitis and staph (batch 25)
add(45,
    "Treatment of streptococcal pharyngitis with penicillin is INEFFECTIVE in preventing which "
    "of the following complications?",
    ["Glomerulonephritis", "Rheumatic fever", "Peritonsillar abscess", "Otitis media"])

add(39,
    "A 10-year-old child attends with a sore throat and your most likely diagnosis is "
    "streptococcal pharyngitis. The patient developed anaphylaxis on receiving penicillin. Which "
    "is the most appropriate antibiotic for treating his sore throat?",
    ["Cephalexin", "Azithromycin", "Ciprofloxacin", "Cefixime"])

add(47,
    "A six-year-old girl develops, after an acute purulent sore throat, a macular rash on the "
    "chest and back which rapidly spreads to the limbs but spares the palms and soles. The rash "
    "feels rough like sandpaper and is darker in the body folds such as the axilla and the "
    "elbow, and her tongue looks like a strawberry. What is the most likely diagnosis?",
    ["Scarlet fever", "Measles", "Kawasaki disease", "Rheumatic fever"])

add(44,
    "Following a hospital outbreak of group A streptococcus, which measure do you consider "
    "appropriate for eradicating asymptomatic pharyngeal carriage among hospital staff?",
    ["Oral penicillin together with oral vancomycin",
     "Oral vancomycin together with rifampicin",
     "Oral penicillin together with oral rifampicin",
     "No specific treatment is necessary"])

add(55,
    "A 70-year-old diabetic patient attends with pain at the back of the neck. On examination he "
    "is febrile and there is a fluctuant swelling of the soft tissue of this area discharging "
    "pus. What is the commonest causative organism and the appropriate treatment?",
    ["Pseudomonas aeruginosa — ceftazidime", "Staphylococcus aureus — cefazolin",
     "Candida albicans — fluconazole", "Group A streptococcus — penicillin"])

add(69,
    "A 45-year-old man attends with fever, back pain, weakness and malaise that began about ten "
    "days ago. The back pain radiates to his right leg. On examination there is tenderness over "
    "the third and fourth lumbar vertebrae. Initial investigations show leucocytosis and a "
    "raised ESR. Which of the following is the most appropriate diagnostic imaging?",
    ["Anteroposterior and lateral radiographs of the lumbar spine",
     "MRI of the lumbar spine", "Bone scan", "CT scan of the lumbar spine"])

add(70,
    "A patient is admitted for open heart surgery. Which of the following antibiotics is the "
    "appropriate drug of choice for preventing infection?",
    ["Cefazolin", "Ceftriaxone", "Clindamycin", "Vancomycin"])
