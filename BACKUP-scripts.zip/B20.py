# -*- coding: utf-8 -*-
"""Micro-lessons, batch 20 — brucellosis: diagnosis, regimens and follow-up.

Brucellosis is the single most Iranian topic in this book. It is endemic across
the country, it accounts for forty-five of the eighty-one questions in the
zoonoses chapter, and the examiners return to it every sitting. It is also the
topic where a student's intuition is most reliably wrong, in three specific
places:

1. THE FOLLOW-UP TRAP. Six questions ask how to follow a treated patient, and
   the answer is never serology. Brucella antibody titres fall over months to
   YEARS after cure, so a still-positive Wright in a well patient means nothing.
   Follow-up is CLINICAL — symptoms, general condition and WEIGHT. A student who
   answers "repeat the Wright every three months" gets all six wrong.

2. THE REGIMEN TRAP. Eleven questions ask which drugs. The rule is never one
   drug and never a short course: two drugs, at least six weeks, one of which
   must penetrate cells because Brucella is an INTRACELLULAR organism. And the
   choice changes in pregnancy and in children, where doxycycline is out.

3. THE FOCAL-DISEASE TRAP. Spondylitis, neurobrucellosis and endocarditis are
   not "brucellosis plus a complication"; they change the duration and the
   number of drugs. Endocarditis in particular is the one form that usually
   needs SURGERY as well.

A note on the third rail: the difference between brucellar and tuberculous
spondylitis is asked three times, and it is asked because the two are the
commonest causes of infectious spondylitis in Iran and are treated completely
differently. The discriminator is the shape of the destruction, which follows
from the pace of the two diseases.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022), Ch. 169
(Brucellosis); Iranian national brucellosis guideline; Ariza J et al.,
"Perspectives for the Treatment of Brucellosis in the 21st Century: the
Ioannina Recommendations", PLoS Med 2007.
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 169: Brucellosis"
IOAN = "Ariza J et al. — Perspectives for the Treatment of Brucellosis in the 21st Century: the Ioannina Recommendations. PLoS Med 2007;4(12):e317"
IR = "دستورالعمل کشوری مبارزه با تب مالت (بروسلوز)، وزارت بهداشت، درمان و آموزش پزشکی"

# ---------------------------------------------------------------------------
# The shared spine of the brucellosis block.
# ---------------------------------------------------------------------------
CORE_FA = [
    "**بروسلا یک کوکوباسیل گرم‌منفی و مهم‌تر از آن، یک ارگانیسم داخل‌سلولی است.**",
    "⚠️ همین «داخل‌سلولی بودن» توضیح‌دهنده‌ی تقریباً همه‌ی ویژگی‌های بالینی آن است:",
    "چرا درمان **طولانی** است، چرا **دو دارو** لازم است، و چرا **عود** شایع است.",
    "**راه‌های انتقال در ایران:** لبنیات غیرپاستوریزه (به‌ویژه **پنیر محلی** و شیر خام)،",
    "تماس شغلی (**دامدار، قصاب، کارگر کشتارگاه، دامپزشک**) و **آزمایشگاه میکروب‌شناسی**.",
    "⚠️ بروسلا یکی از شایع‌ترین عفونت‌های **اکتسابی از آزمایشگاه** در جهان است.",
    "**تابلوی بالینی کلاسیک:** تب مواج، **تعریق شبانه با بوی خاص**، ضعف، بی‌اشتهایی،",
    "کاهش وزن، **آرترالژی و کمردرد**، و در معاینه گاهی اسپلنومگالی و هپاتومگالی.",
    "⚠️ **شایع‌ترین عارضه‌ی موضعی، درگیری استخوان و مفصل است** (تا نیمی از بیماران).",
    "و در بزرگسالان شایع‌ترین شکل آن **اسپوندیلیت، به‌ویژه مهره‌های کمری** است.",
    "در کودکان و جوانان، درگیری **ساکروایلیاک و مفاصل بزرگ محیطی** شایع‌تر است.",
    "**تشخیص — سه ابزار و ترتیبشان:**",
    "**۱. تست آگلوتیناسیون استاندارد (رایت):** تیتر **۱/۱۶۰ یا بالاتر** در منطقه‌ی اندمیک معنادار است.",
    "**۲. تست 2ME:** آنتی‌بادی **IgM** را با مرکاپتواتانول از بین می‌برد و فقط **IgG** را می‌سنجد.",
    "⚠️ پس **2ME نشانه‌ی عفونت فعال یا مزمن است**، و تیتر **۱/۸۰ یا بالاتر** آن معنادار است.",
    "**۳. کشت خون:** قطعی‌ترین است ولی **کند و کم‌حساس** (۳۰ تا ۷۰ درصد) — پس تشخیص را معطل آن نمی‌کنیم.",
    "⚠️ **کومبس رایت** برای کشف **آنتی‌بادی بلوکه‌کننده** است؛ وقتی رایت منفی است ولی شک بالینی بالاست.",
    "**درمان — قاعده‌ی ثابت:** حداقل **دو دارو**، حداقل **شش هفته**.",
    "چرا دو دارو؟ چون ارگانیسم **داخل سلول** پنهان است و تک‌دارو **عود** می‌سازد.",
    "⚠️ **دو رژیم استاندارد بزرگسال:**",
    "**داکسی‌سیکلین + ریفامپین**، هر دو **۶ هفته** (خوراکی، سرپایی، رایج‌ترین).",
    "**داکسی‌سیکلین ۶ هفته + استرپتومایسین ۲ تا ۳ هفته** (کارآمدتر؛ عود کمتر).",
    "⚠️ رژیم دوم در متون کلاسیک **استاندارد طلایی** نامیده می‌شود، چون میزان عودش پایین‌تر است.",
]
CORE_EN = [
    "BRUCELLA IS A GRAM-NEGATIVE COCCOBACILLUS AND, MORE IMPORTANTLY, AN INTRACELLULAR ORGANISM.",
    "WARNING: that intracellular habit explains almost every clinical feature it has:",
    "why treatment is LONG, why TWO DRUGS are needed, and why RELAPSE is common.",
    "ROUTES OF TRANSMISSION IN IRAN: unpasteurised dairy (especially LOCAL CHEESE and raw milk),",
    "occupational contact (FARMERS, BUTCHERS, ABATTOIR WORKERS, VETERINARIANS) and the MICROBIOLOGY LABORATORY.",
    "WARNING: Brucella is one of the commonest LABORATORY-ACQUIRED infections in the world.",
    "THE CLASSICAL PICTURE: undulant fever, NIGHT SWEATS WITH A CHARACTERISTIC ODOUR, weakness, anorexia,",
    "weight loss, ARTHRALGIA AND BACK PAIN, and sometimes splenomegaly and hepatomegaly on examination.",
    "WARNING: THE COMMONEST FOCAL COMPLICATION IS OSTEOARTICULAR DISEASE (up to half of patients).",
    "In adults its commonest form is SPONDYLITIS, especially of the LUMBAR vertebrae.",
    "In children and young adults, SACROILIAC and large peripheral joints are more often involved.",
    "DIAGNOSIS — THREE TOOLS AND THE ORDER IN WHICH THEY ARE USED:",
    "1. STANDARD AGGLUTINATION (WRIGHT) TEST: a titre of 1/160 OR HIGHER is significant in an endemic area.",
    "2. THE 2ME TEST: mercaptoethanol destroys IgM antibody so that only IgG is measured.",
    "WARNING: so 2ME INDICATES ACTIVE OR CHRONIC INFECTION, and a titre of 1/80 OR HIGHER is significant.",
    "3. BLOOD CULTURE: the most definitive but SLOW AND INSENSITIVE (30-70%), so diagnosis does not wait for it.",
    "WARNING: THE COOMBS WRIGHT test detects BLOCKING ANTIBODY, for when the Wright is negative but suspicion is high.",
    "TREATMENT — THE FIXED RULE: at least TWO DRUGS for at least SIX WEEKS.",
    "Why two drugs? Because the organism hides INSIDE CELLS and single-drug therapy breeds RELAPSE.",
    "WARNING, THE TWO STANDARD ADULT REGIMENS:",
    "DOXYCYCLINE PLUS RIFAMPICIN, both for SIX WEEKS (oral, outpatient, the commonest).",
    "DOXYCYCLINE FOR SIX WEEKS PLUS STREPTOMYCIN FOR TWO TO THREE WEEKS (more effective, fewer relapses).",
    "WARNING: classical texts call the second regimen the GOLD STANDARD because its relapse rate is lower.",
]

SPINE_FA = [
    "⚠️ **افتراق اسپوندیلیت بروسلایی از سلی یکی از پرتکرارترین سؤالات این فصل است.**",
    "منطق افتراق را بفهمید تا حفظ نکنید: **سرعت تخریب** تفاوت را می‌سازد.",
    "**سل کند و ویرانگر است:** باسیل ماه‌ها فرصت دارد و **جسم مهره را نابود می‌کند**.",
    "نتیجه: **تخریب زودرس بادی مهره**، **کلاپس گوه‌ای قدامی (anterior wedge)**،",
    "و در نهایت **دفورمیتی گیبوس** — همان قوز مشخصه‌ی بیماری پات.",
    "همچنین سل **آبسه‌ی سرد پاراورتبرال و پسواس** می‌سازد و **کانال نخاعی را فشرده** می‌کند.",
    "**بروسلوز تند و ترمیم‌گر است:** بدن فرصت **استخوان‌سازی واکنشی** پیدا می‌کند.",
    "⚠️ نتیجه‌ی مشخصه: **استئوفیت انترولترال** با نمای معروف **«منقار طوطی» (parrot beak)**.",
    "و **اسکلروز** و ترمیم استخوانی، در کنار **حفظ نسبی ارتفاع مهره**.",
    "⚠️ **پس منقار طوطی و اسکلروز = بروسلوز؛ گیبوس و کلاپس گوه‌ای = سل.**",
    "**محل درگیری چه؟** بروسلوز **مهره‌های کمری، به‌ویژه L4 و L5** را ترجیح می‌دهد.",
    "سل هم **توراسیک تحتانی و لومبار فوقانی** را می‌گیرد — یعنی محل‌ها **همپوشانی دارند**.",
    "⚠️ و دقیقاً به همین دلیل، **محل مهره‌ی درگیر ابزار افتراق خوبی نیست**.",
    "**علامت پونز (Pons sign)** — اروزیون گوشه‌ی قدامی-فوقانی مهره — به نفع بروسلوز است.",
    "**آبسه‌ی پسواس** به نفع **سل** است، هرچند در بروسلوز هم ممکن است دیده شود.",
]
SPINE_EN = [
    "WARNING: DISTINGUISHING BRUCELLAR FROM TUBERCULOUS SPONDYLITIS IS ONE OF THE COMMONEST QUESTIONS IN THIS CHAPTER.",
    "Understand the logic rather than memorising it: THE SPEED OF DESTRUCTION makes the difference.",
    "TUBERCULOSIS IS SLOW AND DESTRUCTIVE: the bacillus has months, and it DESTROYS THE VERTEBRAL BODY.",
    "The result: EARLY DESTRUCTION OF THE VERTEBRAL BODY, ANTERIOR WEDGE COLLAPSE,",
    "and finally GIBBUS DEFORMITY — the characteristic hump of Pott's disease.",
    "Tuberculosis also forms COLD PARAVERTEBRAL AND PSOAS ABSCESSES and COMPRESSES THE SPINAL CANAL.",
    "BRUCELLOSIS IS FASTER AND REPARATIVE: the body has time for REACTIVE BONE FORMATION.",
    "WARNING, the characteristic result: an ANTEROLATERAL OSTEOPHYTE with the famous PARROT BEAK appearance.",
    "Plus SCLEROSIS and bony repair, with RELATIVE PRESERVATION OF VERTEBRAL HEIGHT.",
    "WARNING: SO PARROT BEAK AND SCLEROSIS MEAN BRUCELLOSIS; GIBBUS AND WEDGE COLLAPSE MEAN TUBERCULOSIS.",
    "WHAT ABOUT THE SITE? Brucellosis prefers the LUMBAR vertebrae, especially L4 and L5.",
    "Tuberculosis takes the LOWER THORACIC AND UPPER LUMBAR spine — so the sites OVERLAP.",
    "WARNING, and precisely for that reason THE VERTEBRAL LEVEL IS A POOR DISCRIMINATOR.",
    "THE PONS SIGN — erosion of the anterosuperior corner of the vertebra — favours brucellosis.",
    "A PSOAS ABSCESS favours TUBERCULOSIS, although it can occur in brucellosis too.",
]

FOLLOW_FA = [
    "⚠️ **مهم‌ترین قاعده‌ی پیگیری بروسلوز: پیگیری بالینی است، نه سرولوژیک.**",
    "این قاعده در این فصل شش بار پرسیده شده و بیشترین خطای دانشجویی را می‌سازد.",
    "**چرا سرولوژی برای پیگیری بی‌فایده است؟**",
    "آنتی‌بادی‌های ضدبروسلا پس از درمان موفق **ماه‌ها تا سال‌ها** در خون باقی می‌مانند.",
    "پس **رایت مثبت در بیمار بی‌علامتِ درمان‌شده، معنای عود ندارد** — فقط حافظه‌ی ایمنی است.",
    "و برعکس: بیمار می‌تواند با تیتر رو به کاهش، **عود بالینی** داشته باشد.",
    "⚠️ تصمیم‌گیری بر اساس تیتر یعنی درمان کردن یک عدد به‌جای یک بیمار.",
    "**پس چه چیزی را پیگیری کنیم؟**",
    "**علائم بالینی، حال عمومی و مهم‌تر از همه، وزن بیمار.**",
    "⚠️ **وزن مهم‌ترین شاخص عینی است**: بروسلوز فعال کاهش وزن می‌دهد و بهبود، وزن را برمی‌گرداند.",
    "**مدت پیگیری: دو سال**، چون بیشترین عودها در همین بازه رخ می‌دهند.",
    "**اکثر عودها در ۶ ماه اول پس از پایان درمان اتفاق می‌افتند.**",
    "⚠️ **عود با کشت یا تابلوی بالینی تشخیص داده می‌شود، نه با تیتر.**",
    "و نکته‌ی مهم: **عود معمولاً به‌معنای مقاومت دارویی نیست** — مقاومت در بروسلا نادر است.",
    "عود معمولاً یعنی **ارگانیسم داخل‌سلولی از دوره‌ی درمان جان به‌در برده است**.",
]
FOLLOW_EN = [
    "WARNING, THE MOST IMPORTANT RULE OF BRUCELLOSIS FOLLOW-UP: IT IS CLINICAL, NOT SEROLOGICAL.",
    "This rule is asked six times in this chapter and produces more student errors than any other.",
    "WHY IS SEROLOGY USELESS FOR FOLLOW-UP?",
    "Anti-Brucella antibodies persist in the blood for MONTHS TO YEARS after successful treatment.",
    "So A POSITIVE WRIGHT IN A WELL, TREATED PATIENT DOES NOT MEAN RELAPSE — it is only immunological memory.",
    "And conversely, a patient can RELAPSE CLINICALLY while the titre is falling.",
    "WARNING: deciding on the titre means treating a number instead of a patient.",
    "SO WHAT DO WE FOLLOW?",
    "CLINICAL SYMPTOMS, GENERAL CONDITION, AND ABOVE ALL THE PATIENT'S WEIGHT.",
    "WARNING: WEIGHT IS THE MOST USEFUL OBJECTIVE INDEX — active brucellosis causes weight loss, and recovery restores it.",
    "DURATION OF FOLLOW-UP: TWO YEARS, because that is when relapses occur.",
    "MOST RELAPSES HAPPEN WITHIN THE FIRST SIX MONTHS after treatment ends.",
    "WARNING: RELAPSE IS DIAGNOSED BY CULTURE OR CLINICAL PICTURE, NOT BY TITRE.",
    "And an important point: RELAPSE USUALLY DOES NOT MEAN DRUG RESISTANCE — resistance in Brucella is rare.",
    "Relapse usually means THE INTRACELLULAR ORGANISM SURVIVED THE COURSE OF TREATMENT.",
]


# =========================================================== book:440
add("book:440", "case", "medium",
 "کمردرد مزمن + **دیسک سالم** + **منقار طوطی** ← **بروسلا**، نه سل.",
 "Chronic back pain with a PRESERVED DISC and a PARROT-BEAK osteophyte means BRUCELLA, not tuberculosis.",
 CORE_FA + SPINE_FA + [
  "در این بیمار سه نشانه دست‌به‌دست هم می‌دهند و همه به یک سمت اشاره می‌کنند:",
  "یک — **کشاورز ۵۰ ساله** ← تماس شغلی، یعنی احتمال پیش‌آزمون بالا در ایران.",
  "دو — **دیسک بین‌مهره‌ای سالم** ← سل معمولاً دیسک را زودتر و شدیدتر درگیر می‌کند.",
  "⚠️ سه — **استئوفیت قدامی-طرفی با نمای منقار طوطی** ← امضای بروسلوز.",
  "و دو نشانه‌ی منفی که سل را تضعیف می‌کنند: **بدون آبسه‌ی پسواس** و **بدون کمپرسیون نخاع**.",
  "پس تشخیص **بروسلا** است و نه مایکوباکتریوم توبرکلوزیس.",
  "چرا استاف اورئوس نیست؟ استئومیلیت استافی معمولاً **حادتر و توکسیک‌تر** است،",
  "با تب بالا، لکوسیتوز و درد شدید — نه سه ماه علائم آهسته با کاهش وزن.",
  "پسودوموناس هم بیشتر در **معتاد تزریقی** و **پس از جراحی یا تروما** مطرح می‌شود.",
  "⚠️ درمان اسپوندیلیت بروسلایی با بروسلوز ساده فرق دارد: **حداقل سه ماه**،",
  "و اغلب رژیم **سه‌دارویی** (داکسی‌سیکلین + ریفامپین + آمینوگلیکوزید).",
 ],
 CORE_EN + SPINE_EN + [
  "In this patient three findings work together and all point one way:",
  "One — a 50-YEAR-OLD FARMER: occupational contact, so a high pre-test probability in Iran.",
  "Two — THE INTERVERTEBRAL DISC IS PRESERVED: tuberculosis usually involves the disc earlier and more severely.",
  "WARNING, three — an ANTEROLATERAL OSTEOPHYTE WITH A PARROT-BEAK APPEARANCE: the signature of brucellosis.",
  "And two negative findings that argue against tuberculosis: NO PSOAS ABSCESS and NO CORD COMPRESSION.",
  "So the diagnosis is BRUCELLA, not Mycobacterium tuberculosis.",
  "Why not Staphylococcus aureus? Staphylococcal osteomyelitis is usually MORE ACUTE AND MORE TOXIC,",
  "with high fever, leucocytosis and severe pain — not three months of indolent symptoms with weight loss.",
  "Pseudomonas is chiefly considered in INJECTING DRUG USERS and AFTER SURGERY OR TRAUMA.",
  "WARNING: brucellar spondylitis is treated differently from uncomplicated brucellosis — AT LEAST THREE MONTHS,",
  "and often a THREE-DRUG regimen (doxycycline plus rifampicin plus an aminoglycoside).",
 ],
 "این سؤال کلاسیک‌ترین افتراق فصل را می‌پرسد: **اسپوندیلیت بروسلایی یا سلی؟**\n\n"
 "**منطق افتراق را بفهمید تا هرگز فراموش نکنید — همه‌چیز به سرعت تخریب برمی‌گردد:**\n\n"
 "**سل کند و ویرانگر است.** باسیل ماه‌ها فرصت دارد و **جسم مهره را نابود می‌کند**؛ نتیجه‌اش **تخریب زودرس بادی مهره**، **کلاپس گوه‌ای قدامی**، **دفورمیتی گیبوس**، **آبسه‌ی سرد پسواس** و **کمپرسیون نخاع** است.\n\n"
 "⚠️ **بروسلوز تندتر و ترمیم‌گر است.** بدن فرصت **استخوان‌سازی واکنشی** پیدا می‌کند؛ نتیجه‌اش **استئوفیت انترولترال با نمای «منقار طوطی»**، **اسکلروز** و **حفظ نسبی ارتفاع مهره** است.\n\n"
 "**حالا این بیمار را بسنجید:**\n\n"
 "**کشاورز ۵۰ ساله** ← تماس شغلی؛ در ایران احتمال پیش‌آزمون بالا\n"
 "**دیسک بین‌مهره‌ای سالم** ← به نفع بروسلا\n"
 "⚠️ **استئوفیت قدامی-طرفی، نمای منقار طوطی** ← امضای بروسلا\n"
 "**بدون آبسه‌ی پسواس، بدون کمپرسیون نخاع** ← علیه سل\n\n"
 "**پس پاسخ بروسلا است.**\n\n"
 "چرا **استاف اورئوس** نه؟ چون استئومیلیت استافی تابلوی **حادتر و توکسیک‌تری** دارد. چرا **پسودوموناس** نه؟ چون بیشتر در **معتاد تزریقی** یا **پس از جراحی و تروما** مطرح است.\n\n"
 "⚠️ **و یک نکته‌ی درمانی که فراموش می‌شود:** اسپوندیلیت بروسلایی مثل بروسلوز ساده شش هفته درمان نمی‌شود؛ **حداقل سه ماه** و اغلب با رژیم **سه‌دارویی** درمان می‌شود.",
 "This asks the most classical distinction in the chapter: BRUCELLAR OR TUBERCULOUS SPONDYLITIS?\n\n"
 "UNDERSTAND THE LOGIC AND YOU WILL NEVER FORGET IT — IT ALL COMES DOWN TO THE SPEED OF DESTRUCTION:\n\n"
 "TUBERCULOSIS IS SLOW AND DESTRUCTIVE. The bacillus has months and DESTROYS THE VERTEBRAL BODY, giving EARLY BODY DESTRUCTION, ANTERIOR WEDGE COLLAPSE, GIBBUS DEFORMITY, COLD PSOAS ABSCESS and CORD COMPRESSION.\n\n"
 "WARNING: BRUCELLOSIS IS FASTER AND REPARATIVE. The body has time for REACTIVE BONE FORMATION, giving an ANTEROLATERAL OSTEOPHYTE WITH A PARROT-BEAK APPEARANCE, SCLEROSIS, and RELATIVE PRESERVATION OF VERTEBRAL HEIGHT.\n\n"
 "NOW WEIGH THIS PATIENT:\n\n"
 "A 50-YEAR-OLD FARMER — occupational contact, high pre-test probability in Iran\n"
 "PRESERVED INTERVERTEBRAL DISC — favours Brucella\n"
 "WARNING, ANTEROLATERAL OSTEOPHYTE, PARROT-BEAK APPEARANCE — the signature of Brucella\n"
 "NO PSOAS ABSCESS, NO CORD COMPRESSION — against tuberculosis\n\n"
 "SO THE ANSWER IS BRUCELLA.\n\n"
 "Why not STAPHYLOCOCCUS AUREUS? Because staphylococcal osteomyelitis presents MORE ACUTELY AND MORE TOXICALLY. Why not PSEUDOMONAS? Because it is chiefly seen in INJECTING DRUG USERS or AFTER SURGERY AND TRAUMA.\n\n"
 "WARNING, AND A TREATMENT POINT THAT IS OFTEN FORGOTTEN: brucellar spondylitis is not treated for six weeks like uncomplicated disease; it needs AT LEAST THREE MONTHS and often a THREE-DRUG regimen.",
 ["سل دیسک را زودتر درگیر و مهره را دچار کلاپس گوه‌ای می‌کند؛ اینجا دیسک سالم و استئوفیت ترمیمی داریم.",
  "پاسخ صحیح — دیسک سالم به‌همراه استئوفیت قدامی-طرفی (منقار طوطی) امضای اسپوندیلیت بروسلایی است.",
  "پسودوموناس بیشتر در معتاد تزریقی یا پس از جراحی و تروما مطرح است، نه در کشاورز با سه ماه علائم آهسته.",
  "استئومیلیت استافیلوکوکی تابلوی حادتر و توکسیک‌تری دارد و با این سیر سه‌ماهه‌ی خفیف نمی‌خواند."],
 ["Tuberculosis involves the disc earlier and wedges the vertebra; here the disc is intact and the osteophyte is reparative.",
  "Correct — a preserved disc with an anterolateral (parrot-beak) osteophyte is the signature of brucellar spondylitis.",
  "Pseudomonas is chiefly seen in injecting drug users or after surgery and trauma, not in a farmer with three indolent months.",
  "Staphylococcal osteomyelitis is more acute and toxic and does not fit this mild three-month course."],
 "**منقار طوطی + دیسک سالم + اسکلروز = بروسلا.** **گیبوس + کلاپس + آبسه‌ی پسواس = سل.**",
 "Parrot beak plus preserved disc plus sclerosis means Brucella. Gibbus plus collapse plus psoas abscess means tuberculosis.",
 [H, IR])


# =========================================================== book:444
add("book:444", "recall", "medium",
 "**استئوفیت انترولترال (منقار طوطی)** تنها یافته‌ای است که قاطعانه به نفع بروسلوز است.",
 "The ANTEROLATERAL OSTEOPHYTE (parrot beak) is the one finding that decisively favours brucellosis.",
 CORE_FA + SPINE_FA + [
  "این سؤال همان افتراق را به شکل مستقیم می‌پرسد: **کدام یافته به نفع بروسلوز است؟**",
  "سه گزینه‌ی دیگر همگی یافته‌های **تخریب پیشرفته** هستند و همه به سل اشاره می‌کنند:",
  "**کمپرسیون کانال نخاعی** ← نتیجه‌ی تخریب گسترده و آبسه‌ی پاراورتبرال ← سل.",
  "**کلاپس گوه‌ای قدامی (anterior wedge)** ← فروریختن جسم مهره ← سل.",
  "**تخریب جسم مهره (body destruction)** ← تعریفِ همان روند سلی است.",
  "⚠️ و تنها گزینه‌ای که **ترمیم** را نشان می‌دهد نه تخریب، **استئوفیت انترولترال** است.",
  "چرا بروسلوز ترمیم می‌سازد و سل نه؟ چون **سرعت بیماری فرصت پاسخ استخوانی می‌دهد**.",
  "در بروسلوز، استخوان همزمان با تخریب، **استخوان‌سازی واکنشی** هم می‌کند.",
  "این استخوان تازه از لبه‌ی قدامی-طرفی مهره بیرون می‌زند و منحنی می‌شود:",
  "همان چیزی که در گرافی شبیه **نوک منقار طوطی** دیده می‌شود.",
  "⚠️ نتیجه‌ی عملی: بیمار بروسلایی معمولاً **دفورمیتی و نقص نورولوژیک باقی‌مانده ندارد**،",
  "در حالی که بیماری پات می‌تواند به گیبوس دائمی و پاراپلژی منجر شود.",
 ],
 CORE_EN + SPINE_EN + [
  "This question asks the same distinction directly: WHICH FINDING FAVOURS BRUCELLOSIS?",
  "The other three options are all findings of ADVANCED DESTRUCTION and all point to tuberculosis:",
  "SPINAL CANAL COMPRESSION — the result of extensive destruction and paravertebral abscess: tuberculosis.",
  "ANTERIOR WEDGE COLLAPSE — collapse of the vertebral body: tuberculosis.",
  "VERTEBRAL BODY DESTRUCTION — that is the definition of the tuberculous process.",
  "WARNING, and the only option showing REPAIR rather than destruction is the ANTEROLATERAL OSTEOPHYTE.",
  "Why does brucellosis repair and tuberculosis not? Because THE PACE OF THE DISEASE ALLOWS A BONY RESPONSE.",
  "In brucellosis the bone lays down REACTIVE NEW BONE at the same time as it is being eroded.",
  "That new bone projects from the anterolateral rim of the vertebra and curves over:",
  "which on the radiograph looks exactly like A PARROT'S BEAK.",
  "WARNING, the practical consequence: a brucellar patient usually has NO RESIDUAL DEFORMITY OR NEUROLOGICAL DEFICIT,",
  "whereas Pott's disease can end in a permanent gibbus and paraplegia.",
 ],
 "این سؤال همان افتراق کلاسیک را مستقیم می‌پرسد، و راه‌حلش یک تقسیم‌بندی ساده است:\n\n"
 "⚠️ **یافته‌های «تخریبی» ← سل. یافته‌ی «ترمیمی» ← بروسلوز.**\n\n"
 "سه گزینه از چهار گزینه، یافته‌ی **تخریب** هستند:\n\n"
 "**کمپرسیون کانال نخاعی** ← تخریب گسترده + آبسه‌ی پاراورتبرال ← **سل**\n"
 "**کلاپس گوه‌ای قدامی** ← فروریختن جسم مهره ← **سل**\n"
 "**تخریب جسم مهره** ← تعریفِ خود روند سلی ← **سل**\n\n"
 "⚠️ و تنها گزینه‌ی **ترمیمی**، **استئوفیت انترولترال** است — همان نمای معروف **منقار طوطی**.\n\n"
 "**چرا بروسلوز ترمیم می‌سازد؟** چون سریع‌تر از سل پیش می‌رود و بدن فرصت **استخوان‌سازی واکنشی** پیدا می‌کند. استخوان تازه از لبه‌ی قدامی-طرفی مهره بیرون می‌زند و منحنی می‌شود؛ در گرافی دقیقاً شبیه نوک منقار طوطی دیده می‌شود.\n\n"
 "**سل برعکس، آن‌قدر کند و ویرانگر است که فرصت ترمیم نمی‌دهد** — فقط تخریب می‌ماند.\n\n"
 "⚠️ **نتیجه‌ی بالینی این تفاوت مهم است:** بیمار بروسلایی معمولاً بدون **دفورمیتی و نقص نورولوژیک باقی‌مانده** بهبود می‌یابد، در حالی که بیماری پات می‌تواند به **گیبوس دائمی و پاراپلژی** ختم شود. به همین دلیل هم اشتباه گرفتن این دو، فقط یک خطای تشخیصی نیست؛ خطای پیش‌آگهی هم هست.",
 "This asks the classical distinction directly, and the solution is a simple division:\n\n"
 "WARNING: DESTRUCTIVE FINDINGS MEAN TUBERCULOSIS. A REPARATIVE FINDING MEANS BRUCELLOSIS.\n\n"
 "Three of the four options are findings of DESTRUCTION:\n\n"
 "SPINAL CANAL COMPRESSION — extensive destruction plus paravertebral abscess: TUBERCULOSIS\n"
 "ANTERIOR WEDGE COLLAPSE — collapse of the vertebral body: TUBERCULOSIS\n"
 "VERTEBRAL BODY DESTRUCTION — the definition of the tuberculous process: TUBERCULOSIS\n\n"
 "WARNING, and the one REPARATIVE option is the ANTEROLATERAL OSTEOPHYTE — the famous PARROT BEAK.\n\n"
 "WHY DOES BRUCELLOSIS REPAIR? Because it moves faster than tuberculosis and the body has time for REACTIVE BONE FORMATION. New bone projects from the anterolateral rim of the vertebra and curves over, looking on film exactly like a parrot's beak.\n\n"
 "TUBERCULOSIS, BY CONTRAST, IS SO SLOW AND DESTRUCTIVE THAT NO REPAIR OCCURS — only destruction remains.\n\n"
 "WARNING, THE CLINICAL CONSEQUENCE MATTERS: a brucellar patient usually recovers WITHOUT RESIDUAL DEFORMITY OR NEUROLOGICAL DEFICIT, whereas Pott's disease can end in PERMANENT GIBBUS AND PARAPLEGIA. Confusing the two is therefore not only a diagnostic error but a prognostic one.",
 ["پاسخ صحیح — استئوفیت انترولترال (منقار طوطی) یافته‌ی ترمیمی و مشخصه‌ی اسپوندیلیت بروسلایی است.",
  "کمپرسیون کانال نخاعی ناشی از تخریب گسترده و آبسه‌ی پاراورتبرال است و به نفع سل می‌باشد.",
  "کلاپس گوه‌ای قدامی نشانه‌ی فروریختن جسم مهره و مشخصه‌ی بیماری پات (سل) است.",
  "تخریب جسم مهره تعریف روند سلی است و درست نقطه‌ی مقابل نمای ترمیمی بروسلوز."],
 ["Correct — the anterolateral osteophyte (parrot beak) is a reparative finding characteristic of brucellar spondylitis.",
  "Spinal canal compression results from extensive destruction and paravertebral abscess and favours tuberculosis.",
  "Anterior wedge collapse indicates collapse of the vertebral body and is characteristic of Pott's disease.",
  "Vertebral body destruction is the definition of the tuberculous process, the opposite of the reparative brucellar picture."],
 "**تخریب ← سل. ترمیم (استئوفیت، اسکلروز) ← بروسلوز.** محل مهره ابزار افتراق خوبی **نیست**.",
 "Destruction means tuberculosis; repair (osteophyte, sclerosis) means brucellosis. The vertebral level is a poor discriminator.",
 [H, IR])


# =========================================================== book:447
add("book:447", "case", "medium",
 "با رایت **۱/۳۲۰** و شک بالینی بالا، تست تأییدی **2ME** است — چون **IgG** یعنی عفونت فعال.",
 "With a Wright of 1/320 and high clinical suspicion, the confirmatory test is 2ME, because IgG means active infection.",
 CORE_FA + [
  "بیمار **کارگر کشتارگاه** با **تب یک‌ماهه‌ی اثبات‌شده** و **رایت ۱/۳۲۰** است.",
  "تشخیص عملاً روشن است؛ سؤال می‌پرسد **چه چیزی آن را تأیید می‌کند**.",
  "⚠️ برای فهمیدن پاسخ، باید بدانید **تست رایت چه چیزی را نمی‌گوید**.",
  "رایت **مجموع IgM و IgG** ضدبروسلا را می‌سنجد.",
  "IgM در عفونت **حاد** بالا می‌رود، ولی می‌تواند **ماه‌ها پس از بهبود** هم باقی بماند.",
  "پس یک رایت مثبت به‌تنهایی نمی‌گوید بیماری **فعال** است یا **گذشته**.",
  "⚠️ **تست 2ME دقیقاً همین شکاف را پر می‌کند.**",
  "مرکاپتواتانول پیوندهای دی‌سولفیدی **IgM** را می‌شکند و آن را از میدان خارج می‌کند.",
  "پس آنچه باقی می‌ماند فقط **IgG** است.",
  "⚠️ **و IgG بالا یعنی عفونت فعال یا مزمن، نه خاطره‌ی گذرا.**",
  "تیتر 2ME برابر **۱/۸۰ یا بالاتر** معنادار در نظر گرفته می‌شود.",
  "چرا **کشت خون** پاسخ نیست؟ چون **کند** است (تا چند هفته) و **حساسیتش پایین** (۳۰ تا ۷۰ درصد).",
  "کشت منفی بروسلوز را رد نمی‌کند، پس ابزار تأیید سریع نیست.",
  "**بیوپسی مغز استخوان** حساسیت بالاتری از کشت خون دارد ولی **تهاجمی** است؛",
  "جای آن در تب طول‌کشیده‌ی بدون تشخیص است، نه در بیماری که سرولوژی‌اش گویاست.",
  "⚠️ **کومبس رایت** برای وضعیت **معکوس** است: شک بالینی بالا ولی **رایت منفی**.",
  "در آن حالت، **آنتی‌بادی بلوکه‌کننده** مانع آگلوتیناسیون شده و کومبس آن را آشکار می‌کند.",
 ],
 CORE_EN + [
  "The patient is an ABATTOIR WORKER with a DOCUMENTED MONTH OF FEVER and a WRIGHT OF 1/320.",
  "The diagnosis is practically clear; the question asks WHAT CONFIRMS IT.",
  "WARNING: to see the answer you must know WHAT THE WRIGHT TEST DOES NOT TELL YOU.",
  "The Wright measures THE SUM OF IgM AND IgG against Brucella.",
  "IgM rises in ACUTE infection but can persist FOR MONTHS AFTER RECOVERY.",
  "So a positive Wright alone cannot say whether disease is ACTIVE or PAST.",
  "WARNING: THE 2ME TEST FILLS EXACTLY THAT GAP.",
  "Mercaptoethanol breaks the disulphide bonds of IgM and removes it from the reaction.",
  "What remains measurable is therefore IgG ALONE.",
  "WARNING: AND A HIGH IgG MEANS ACTIVE OR CHRONIC INFECTION, not a transient memory.",
  "A 2ME titre of 1/80 OR HIGHER is considered significant.",
  "Why is BLOOD CULTURE not the answer? Because it is SLOW (up to weeks) and INSENSITIVE (30-70%).",
  "A negative culture does not exclude brucellosis, so it is not a rapid confirmatory tool.",
  "BONE MARROW BIOPSY is more sensitive than blood culture but INVASIVE;",
  "its place is in undiagnosed prolonged fever, not in a patient whose serology already speaks.",
  "WARNING: THE COOMBS WRIGHT is for the OPPOSITE situation — high suspicion but a NEGATIVE Wright.",
  "There, BLOCKING ANTIBODY prevents agglutination, and the Coombs test reveals it.",
 ],
 "بیمار **کارگر کشتارگاه** است، **یک ماه تب اثبات‌شده** دارد و **تیتر رایت ۱/۳۲۰** است. تشخیص عملاً روشن است؛ سؤال می‌پرسد **چه چیزی آن را تأیید می‌کند**.\n\n"
 "⚠️ **برای پاسخ، باید بدانید تست رایت چه چیزی را نمی‌گوید.** رایت **مجموع IgM و IgG** را می‌سنجد. اما IgM می‌تواند **ماه‌ها پس از بهبود** هم در خون بماند. پس رایت مثبت به‌تنهایی نمی‌گوید بیماری **فعال** است یا **گذشته**.\n\n"
 "⚠️ **تست 2ME (مرکاپتواتانول) دقیقاً همین شکاف را پر می‌کند.** مرکاپتواتانول پیوندهای دی‌سولفیدی **IgM** را می‌شکند و آن را از واکنش خارج می‌کند؛ پس آنچه اندازه‌گیری می‌شود **فقط IgG** است. و **IgG بالا یعنی عفونت فعال یا مزمن**. تیتر **۱/۸۰ یا بالاتر** معنادار است.\n\n"
 "**چرا گزینه‌های دیگر پاسخ نیستند؟**\n\n"
 "**کشت خون** ← قطعی‌ترین است ولی **کند** (تا چند هفته) و **کم‌حساس** (۳۰ تا ۷۰ درصد). کشت منفی بروسلوز را **رد نمی‌کند**، پس ابزار تأیید سریع نیست.\n\n"
 "**بیوپسی مغز استخوان** ← حساسیت بالاتری دارد ولی **تهاجمی** است. جایش در تب طول‌کشیده‌ی بدون تشخیص است، نه در بیماری که سرولوژی‌اش گویا است.\n\n"
 "⚠️ **کومبس رایت** ← برای وضعیت **معکوس** طراحی شده: شک بالینی بالا ولی **رایت منفی**. در بروسلوز مزمن، **آنتی‌بادی بلوکه‌کننده** مانع آگلوتیناسیون می‌شود و رایت را کاذباً منفی می‌کند؛ آزمون کومبس همان آنتی‌بادی پنهان را آشکار می‌سازد. در بیمار ما رایت **مثبت** است، پس کومبس چیزی اضافه نمی‌کند.",
 "The patient is an ABATTOIR WORKER with A DOCUMENTED MONTH OF FEVER and a WRIGHT TITRE OF 1/320. The diagnosis is practically clear; the question asks WHAT CONFIRMS IT.\n\n"
 "WARNING: TO ANSWER, YOU MUST KNOW WHAT THE WRIGHT DOES NOT TELL YOU. The Wright measures THE SUM OF IgM AND IgG. But IgM can persist FOR MONTHS AFTER RECOVERY. So a positive Wright alone cannot distinguish ACTIVE from PAST disease.\n\n"
 "WARNING: THE 2ME (MERCAPTOETHANOL) TEST FILLS EXACTLY THAT GAP. Mercaptoethanol breaks the disulphide bonds of IgM and removes it from the reaction, so what is measured is IgG ALONE. And HIGH IgG MEANS ACTIVE OR CHRONIC INFECTION. A titre of 1/80 OR HIGHER is significant.\n\n"
 "WHY NOT THE OTHERS?\n\n"
 "BLOOD CULTURE — the most definitive but SLOW (up to weeks) and INSENSITIVE (30-70%). A negative culture DOES NOT EXCLUDE brucellosis, so it is no rapid confirmatory tool.\n\n"
 "BONE MARROW BIOPSY — more sensitive, but INVASIVE. Its place is in undiagnosed prolonged fever, not in a patient whose serology already speaks.\n\n"
 "WARNING, THE COOMBS WRIGHT — designed for the OPPOSITE situation: high clinical suspicion with a NEGATIVE Wright. In chronic brucellosis, BLOCKING ANTIBODY prevents agglutination and makes the Wright falsely negative; the Coombs test reveals that hidden antibody. In our patient the Wright is POSITIVE, so Coombs adds nothing.",
 ["کشت خون قطعی‌ترین است ولی کند و کم‌حساس؛ کشت منفی بروسلوز را رد نمی‌کند و ابزار تأیید سریع نیست.",
  "بیوپسی مغز استخوان تهاجمی است و جایش در تب طول‌کشیده‌ی بدون تشخیص است، نه در بیمار با سرولوژی گویا.",
  "پاسخ صحیح — 2ME با حذف IgM فقط IgG را می‌سنجد و بالا بودن آن نشانه‌ی عفونت فعال یا مزمن است.",
  "کومبس رایت برای وضعیت معکوس است: شک بالینی بالا با رایت منفی به‌علت آنتی‌بادی بلوکه‌کننده."],
 ["Blood culture is the most definitive but slow and insensitive; a negative culture does not exclude brucellosis.",
  "Bone marrow biopsy is invasive and belongs in undiagnosed prolonged fever, not in a patient with informative serology.",
  "Correct — 2ME removes IgM and measures IgG alone, and a high IgG indicates active or chronic infection.",
  "The Coombs Wright is for the opposite situation: high suspicion with a negative Wright due to blocking antibody."],
 "**رایت = IgM + IgG. 2ME = فقط IgG ← فعال بودن. کومبس رایت = وقتی رایت منفی است ولی شک بالاست.**",
 "Wright measures IgM plus IgG; 2ME measures IgG alone and shows activity; Coombs Wright is for a negative Wright with high suspicion.",
 [H, IR])


# =========================================================== book:452
add("book:452", "case", "easy",
 "کارمند آزمایشگاه میکروب‌شناسی + تب و تعریق شبانه + رایت ۱/۸۰ ← **بروسلا ملی‌تنسیس**.",
 "A microbiology laboratory worker with fever, night sweats and a Wright of 1/80 has BRUCELLA MELITENSIS.",
 CORE_FA + [
  "این سؤال دو نکته را هم‌زمان می‌سنجد: **شغل به‌عنوان سرنخ** و **گونه‌ی غالب بروسلا**.",
  "⚠️ **بروسلا یکی از شایع‌ترین عفونت‌های اکتسابی از آزمایشگاه در جهان است.**",
  "چرا؟ چون **دوز عفونی‌کننده‌اش بسیار پایین است** — گاهی ده تا صد ارگانیسم کافی است.",
  "و چون از راه **آئروسل** منتقل می‌شود: باز کردن یک پلیت کشت روی میز کافی است.",
  "به همین دلیل کار با کشت مشکوک به بروسلا باید زیر **هود ایمنی زیستی کلاس دو** انجام شود.",
  "⚠️ **کدام گونه؟ در ایران و کل خاورمیانه، بروسلا ملی‌تنسیس (منشأ بز و گوسفند).**",
  "ملی‌تنسیس **بیماری‌زاترین** گونه است و شدیدترین تابلوی بالینی را می‌سازد.",
  "گونه‌های دیگر را هم بشناسید: **آبورتوس** (گاو)، **سوئیس** (خوک)، **کانیس** (سگ).",
  "**تیتر ۱/۸۰ چه معنایی دارد؟** در فرد **عادی** ممکن است مرزی باشد،",
  "⚠️ ولی در فردی با **تماس شغلی و تابلوی بالینی سازگار**، کاملاً حمایت‌کننده است.",
  "چرا سالمونلا انتریکا نه؟ تیفوئید معمولاً **تب پلکانی با علائم گوارشی** می‌دهد،",
  "و **تعریق شبانه و آرترالژی یک‌ماهه** الگوی آن نیست.",
  "چرا سل نه؟ سل هم تعریق شبانه می‌دهد، ولی **رایت مثبت** توضیح‌دهنده‌اش نیست.",
  "چرا فرانسیسلا تولارنسیس نه؟ **تولارمی در ایران بسیار نادر** است،",
  "و تابلویش معمولاً **زخم و لنفادنوپاتی موضعی** است، نه تب مزمن با آرترالژی.",
 ],
 CORE_EN + [
  "This question tests two things at once: OCCUPATION AS A CLUE and THE PREDOMINANT BRUCELLA SPECIES.",
  "WARNING: BRUCELLA IS ONE OF THE COMMONEST LABORATORY-ACQUIRED INFECTIONS IN THE WORLD.",
  "Why? Because ITS INFECTIOUS DOSE IS EXTREMELY LOW — sometimes ten to a hundred organisms suffice.",
  "And because it spreads by AEROSOL: opening a culture plate on the bench is enough.",
  "That is why suspected Brucella cultures must be handled in a BIOSAFETY LEVEL 2 CABINET.",
  "WARNING, WHICH SPECIES? In Iran and across the Middle East, BRUCELLA MELITENSIS (from goats and sheep).",
  "Melitensis is THE MOST VIRULENT species and produces the most severe clinical picture.",
  "Know the others too: ABORTUS (cattle), SUIS (pigs), CANIS (dogs).",
  "WHAT DOES A TITRE OF 1/80 MEAN? In an ordinary person it may be borderline,",
  "WARNING, but in someone with OCCUPATIONAL EXPOSURE AND A COMPATIBLE CLINICAL PICTURE it is fully supportive.",
  "Why not Salmonella enterica? Typhoid usually gives STEPWISE FEVER WITH GASTROINTESTINAL SYMPTOMS,",
  "and a month of NIGHT SWEATS AND ARTHRALGIA is not its pattern.",
  "Why not tuberculosis? TB also causes night sweats, but A POSITIVE WRIGHT is not explained by it.",
  "Why not Francisella tularensis? TULARAEMIA IS VERY RARE IN IRAN,",
  "and it usually presents with an ULCER AND REGIONAL LYMPHADENOPATHY, not chronic fever with arthralgia.",
 ],
 "دو کلمه در این سؤال تشخیص را می‌سازند: **«کارکنان آزمایشگاه میکروب‌شناسی»**.\n\n"
 "⚠️ **بروسلا یکی از شایع‌ترین عفونت‌های اکتسابی از آزمایشگاه در جهان است.** دو دلیل دارد:\n\n"
 "**۱. دوز عفونی‌کننده‌ی بسیار پایین** — گاهی ده تا صد ارگانیسم کافی است.\n"
 "**۲. انتقال از راه آئروسل** — باز کردن یک پلیت کشت روی میز آزمایشگاه می‌تواند کافی باشد.\n\n"
 "به همین دلیل، کار با کشت مشکوک به بروسلا باید زیر **هود ایمنی زیستی کلاس ۲** انجام شود، و همین موضوع در سؤالات پروفیلاکسی این فصل بارها برمی‌گردد.\n\n"
 "**کدام گونه؟** ⚠️ در ایران و سراسر خاورمیانه، **بروسلا ملی‌تنسیس** (منشأ بز و گوسفند) گونه‌ی غالب و **بیماری‌زاترین** گونه است. بقیه را هم بشناسید: **آبورتوس** (گاو)، **سوئیس** (خوک)، **کانیس** (سگ).\n\n"
 "**تیتر ۱/۸۰ کافی است؟** در فرد بدون تماس، مرزی است. اما در فردی با **تماس شغلی مستقیم** و **یک ماه تب، تعریق شبانه و درد مفاصل**، کاملاً حمایت‌کننده است. سرولوژی هرگز جدا از احتمال پیش‌آزمون خوانده نمی‌شود.\n\n"
 "**چرا بقیه نه؟** **سالمونلا** ← تب پلکانی با علائم گوارشی، نه تعریق شبانه‌ی یک‌ماهه. **سل** ← تعریق شبانه بله، ولی رایت مثبت را توضیح نمی‌دهد. **فرانسیسلا تولارنسیس** ← در ایران بسیار نادر، و تابلویش زخم و لنفادنوپاتی موضعی است.",
 "Two words make the diagnosis here: 'MICROBIOLOGY LABORATORY WORKER'.\n\n"
 "WARNING: BRUCELLA IS ONE OF THE COMMONEST LABORATORY-ACQUIRED INFECTIONS IN THE WORLD, for two reasons:\n\n"
 "1. AN EXTREMELY LOW INFECTIOUS DOSE — sometimes ten to a hundred organisms.\n"
 "2. AEROSOL TRANSMISSION — opening a culture plate on the bench can be enough.\n\n"
 "That is why suspected Brucella cultures must be handled in a BIOSAFETY LEVEL 2 CABINET, and why this fact keeps returning in the prophylaxis questions of this chapter.\n\n"
 "WHICH SPECIES? WARNING: in Iran and across the Middle East, BRUCELLA MELITENSIS (from goats and sheep) is both the predominant and THE MOST VIRULENT species. Know the others: ABORTUS (cattle), SUIS (pigs), CANIS (dogs).\n\n"
 "IS A TITRE OF 1/80 ENOUGH? In someone without exposure it is borderline. In someone with DIRECT OCCUPATIONAL EXPOSURE and A MONTH OF FEVER, NIGHT SWEATS AND JOINT PAIN it is fully supportive. Serology is never read apart from pre-test probability.\n\n"
 "WHY NOT THE OTHERS? SALMONELLA — stepwise fever with gastrointestinal symptoms, not a month of night sweats. TUBERCULOSIS — night sweats yes, but it does not explain a positive Wright. FRANCISELLA TULARENSIS — very rare in Iran, and it presents with an ulcer and regional lymphadenopathy.",
 ["پاسخ صحیح — بروسلا ملی‌تنسیس گونه‌ی غالب در ایران و شایع‌ترین عفونت اکتسابی از آزمایشگاه است.",
  "تیفوئید تب پلکانی با علائم گوارشی می‌دهد و با یک ماه تعریق شبانه و آرترالژی و رایت مثبت نمی‌خواند.",
  "سل هم تعریق شبانه می‌دهد ولی تست آگلوتیناسیون مثبت بروسلا را توضیح نمی‌دهد.",
  "تولارمی در ایران بسیار نادر است و معمولاً با زخم و لنفادنوپاتی موضعی تظاهر می‌کند."],
 ["Correct — Brucella melitensis is the predominant species in Iran and the commonest laboratory-acquired infection.",
  "Typhoid gives stepwise fever with gastrointestinal symptoms and does not fit a month of night sweats with a positive Wright.",
  "Tuberculosis also causes night sweats but does not explain a positive Brucella agglutination test.",
  "Tularaemia is very rare in Iran and usually presents with an ulcer and regional lymphadenopathy."],
 "**آزمایشگاه میکروب‌شناسی = بروسلا** (دوز عفونی پایین، انتقال آئروسل). گونه‌ی غالب ایران: **ملی‌تنسیس**.",
 "Microbiology laboratory means Brucella (low infectious dose, aerosol spread). The predominant species in Iran is melitensis.",
 [H, IR])


# =========================================================== book:464
add("book:464", "case", "hard",
 "بروسلوز در بارداری ← **کوتریموکسازول + ریفامپین**؛ داکسی‌سیکلین و استرپتومایسین **ممنوع**.",
 "Brucellosis in pregnancy: CO-TRIMOXAZOLE PLUS RIFAMPICIN. Doxycycline and streptomycin are FORBIDDEN.",
 CORE_FA + [
  "⚠️ **بروسلوز در بارداری یک وضعیت خاص است و رژیم استاندارد در آن قابل استفاده نیست.**",
  "دلیلش دو دارویی است که ستون رژیم بزرگسال‌اند و هر دو در بارداری منع دارند:",
  "**داکسی‌سیکلین (تتراسایکلین) ممنوع است** ← رسوب در دندان و استخوان جنین،",
  "رنگ‌آمیزی دائمی دندان‌ها، و مهار رشد استخوانی.",
  "**استرپتومایسین (آمینوگلیکوزید) ممنوع است** ← **سمیت عصب هشتم جنین**،",
  "یعنی خطر **ناشنوایی مادرزادی** — یکی از معدود عوارض واقعاً غیرقابل‌برگشت.",
  "⚠️ **پس چه می‌ماند؟ ریفامپین، که ستون رژیم بارداری است.**",
  "ریفامپین در بارداری بی‌خطر تلقی می‌شود و **داخل سلول** نفوذ خوبی دارد.",
  "و به آن **کوتریموکسازول** اضافه می‌شود تا رژیم دو‌دارویی کامل شود.",
  "⚠️ **دو احتیاط درباره‌ی کوتریموکسازول در بارداری را بدانید:**",
  "در **سه‌ماهه‌ی اول**، تری‌متوپریم آنتاگونیست فولات است ← خطر نقص لوله‌ی عصبی؛",
  "پس **مکمل فولیک اسید** همراهش داده می‌شود.",
  "نزدیک **زایمان**، سولفامتوکسازول می‌تواند بیلی‌روبین را از آلبومین جدا کند ← **کرن‌ایکتروس**.",
  "**در برخی مراکز، ریفامپین به‌تنهایی برای موارد خفیف در تریمستر سوم به کار می‌رود.**",
  "⚠️ **و چرا اصلاً درمان می‌کنیم و منتظر زایمان نمی‌مانیم؟**",
  "چون بروسلوز درمان‌نشده در بارداری خطر **سقط، مرده‌زایی و زایمان زودرس** را بالا می‌برد.",
  "تأخیر در درمان، خودش خطرناک‌ترین انتخاب است.",
 ],
 CORE_EN + [
  "WARNING: BRUCELLOSIS IN PREGNANCY IS A SPECIAL CASE AND THE STANDARD REGIMEN CANNOT BE USED.",
  "Because the two drugs that form the backbone of adult therapy are both contraindicated:",
  "DOXYCYCLINE (A TETRACYCLINE) IS FORBIDDEN — it deposits in fetal teeth and bone,",
  "permanently staining the teeth and inhibiting bone growth.",
  "STREPTOMYCIN (AN AMINOGLYCOSIDE) IS FORBIDDEN — FETAL EIGHTH-NERVE TOXICITY,",
  "meaning a risk of CONGENITAL DEAFNESS, one of the few genuinely irreversible harms.",
  "WARNING, SO WHAT REMAINS? RIFAMPICIN, the backbone of the pregnancy regimen.",
  "Rifampicin is considered safe in pregnancy and penetrates INTRACELLULARLY well.",
  "CO-TRIMOXAZOLE is added to it to complete a two-drug regimen.",
  "WARNING, KNOW THE TWO CAVEATS ABOUT CO-TRIMOXAZOLE IN PREGNANCY:",
  "IN THE FIRST TRIMESTER trimethoprim is a folate antagonist, risking neural tube defects,",
  "so FOLIC ACID SUPPLEMENTATION is given alongside.",
  "NEAR TERM, sulfamethoxazole can displace bilirubin from albumin, risking KERNICTERUS.",
  "SOME CENTRES USE RIFAMPICIN ALONE for mild third-trimester disease.",
  "WARNING, AND WHY TREAT AT ALL RATHER THAN WAIT FOR DELIVERY?",
  "Because untreated brucellosis in pregnancy raises the risk of MISCARRIAGE, STILLBIRTH AND PRETERM LABOUR.",
  "Delaying treatment is itself the most dangerous choice.",
 ],
 "⚠️ **بروسلوز در بارداری یکی از پرتکرارترین سؤالات این فصل است، چون رژیم استاندارد در آن قابل استفاده نیست.**\n\n"
 "**دو داروی ستون رژیم بزرگسال، هر دو در بارداری ممنوع‌اند:**\n\n"
 "**داکسی‌سیکلین (تتراسایکلین)** ← در **دندان و استخوان جنین** رسوب می‌کند؛ رنگ‌آمیزی دائمی دندان و مهار رشد استخوانی.\n\n"
 "**استرپتومایسین (آمینوگلیکوزید)** ← **سمیت عصب هشتم جنین** و خطر **ناشنوایی مادرزادی** — عارضه‌ای غیرقابل‌برگشت.\n\n"
 "⚠️ **پس رژیم بارداری: کوتریموکسازول + ریفامپین.**\n\n"
 "**ریفامپین** ستون این رژیم است: در بارداری بی‌خطر تلقی می‌شود و نفوذ داخل‌سلولی خوبی دارد — که برای ارگانیسمی که داخل سلول زندگی می‌کند حیاتی است. **کوتریموکسازول** داروی دوم است تا قاعده‌ی «هرگز تک‌دارو» رعایت شود.\n\n"
 "⚠️ **دو احتیاط درباره‌ی کوتریموکسازول:**\n\n"
 "**سه‌ماهه‌ی اول** ← تری‌متوپریم آنتاگونیست فولات است و خطر **نقص لوله‌ی عصبی** دارد؛ پس **مکمل فولیک اسید** همراهش داده می‌شود.\n\n"
 "**نزدیک زایمان** ← سولفامتوکسازول بیلی‌روبین را از آلبومین جدا می‌کند و خطر **کرن‌ایکتروس** نوزاد را بالا می‌برد.\n\n"
 "⚠️ **و مهم‌ترین نکته: چرا اصلاً درمان می‌کنیم؟** چون بروسلوز درمان‌نشده در بارداری خطر **سقط، مرده‌زایی و زایمان زودرس** را به‌شدت بالا می‌برد. گزینه‌ی «تعویق درمان تا زایمان» بی‌خطرترین گزینه به نظر می‌رسد ولی در واقع **خطرناک‌ترین** است.",
 "WARNING: BRUCELLOSIS IN PREGNANCY IS ONE OF THE COMMONEST QUESTIONS IN THIS CHAPTER, because the standard regimen cannot be used.\n\n"
 "THE TWO BACKBONE DRUGS OF ADULT THERAPY ARE BOTH CONTRAINDICATED:\n\n"
 "DOXYCYCLINE (A TETRACYCLINE) deposits in FETAL TEETH AND BONE, causing permanent staining and inhibiting bone growth.\n\n"
 "STREPTOMYCIN (AN AMINOGLYCOSIDE) causes FETAL EIGHTH-NERVE TOXICITY and a risk of CONGENITAL DEAFNESS — an irreversible harm.\n\n"
 "WARNING, SO THE PREGNANCY REGIMEN IS: CO-TRIMOXAZOLE PLUS RIFAMPICIN.\n\n"
 "RIFAMPICIN is the backbone: considered safe in pregnancy and with good intracellular penetration, which is vital against an organism that lives inside cells. CO-TRIMOXAZOLE is the second drug, honouring the rule 'never monotherapy'.\n\n"
 "WARNING, TWO CAVEATS ABOUT CO-TRIMOXAZOLE:\n\n"
 "FIRST TRIMESTER — trimethoprim is a folate antagonist and risks NEURAL TUBE DEFECTS, so FOLIC ACID is given alongside.\n\n"
 "NEAR TERM — sulfamethoxazole displaces bilirubin from albumin and raises the risk of neonatal KERNICTERUS.\n\n"
 "WARNING, AND THE KEY POINT: WHY TREAT AT ALL? Because untreated brucellosis in pregnancy sharply increases the risk of MISCARRIAGE, STILLBIRTH AND PRETERM LABOUR. 'Delay treatment until delivery' looks like the safest option but is in fact THE MOST DANGEROUS.",
 ["سفتریاکسون رژیم شناخته‌شده‌ی بروسلوز نیست و نفوذ داخل‌سلولی کافی برای این ارگانیسم ندارد.",
  "جنتامایسین یک آمینوگلیکوزید است و مانند استرپتومایسین خطر سمیت عصب هشتم جنین دارد.",
  "سیپروفلوکساسین در بارداری ارجح نیست و در بروسلوز هم میزان عود بالاتری نسبت به رژیم‌های استاندارد دارد.",
  "پاسخ صحیح — کوتریموکسازول + ریفامپین رژیم استاندارد بروسلوز در بارداری است."],
 ["Ceftriaxone is not a recognised brucellosis regimen and lacks adequate intracellular penetration.",
  "Gentamicin is an aminoglycoside and, like streptomycin, risks fetal eighth-nerve toxicity.",
  "Ciprofloxacin is not preferred in pregnancy and has a higher relapse rate than standard brucellosis regimens.",
  "Correct — co-trimoxazole plus rifampicin is the standard regimen for brucellosis in pregnancy."],
 "بارداری: **داکسی‌سیکلین ممنوع** (دندان/استخوان)، **آمینوگلیکوزید ممنوع** (عصب ۸) ← **کوتریموکسازول + ریفامپین**.",
 "In pregnancy doxycycline is banned (teeth and bone) and aminoglycosides are banned (eighth nerve), so use co-trimoxazole plus rifampicin.",
 [H, IOAN, IR])


# =========================================================== book:471
add("book:471", "recall", "medium",
 "«رژیم ارجح» بروسلوز بدون عارضه = **استرپتومایسین + داکسی‌سیکلین** (عود کمتر).",
 "The PREFERRED regimen for uncomplicated brucellosis is STREPTOMYCIN PLUS DOXYCYCLINE (fewer relapses).",
 CORE_FA + [
  "این سؤال یک کلمه‌ی کلیدی دارد: **«ارجح»** — یعنی از میان رژیم‌های درست، **بهترین** کدام است.",
  "هر دو رژیم استاندارد در گزینه‌ها هستند و هر دو **قابل قبول**‌اند:",
  "**داکسی‌سیکلین + ریفامپین ۶ هفته** ← رایج‌ترین، تماماً خوراکی، سرپایی و راحت.",
  "**داکسی‌سیکلین ۶ هفته + استرپتومایسین ۲ تا ۳ هفته** ← تزریقی، ولی **مؤثرتر**.",
  "⚠️ **تفاوت واقعی در میزان عود است، و همین «ارجح» را تعیین می‌کند.**",
  "کارآزمایی‌ها و متاآنالیزها نشان داده‌اند رژیم حاوی **آمینوگلیکوزید عود کمتری** دارد.",
  "عدد تقریبی را به یاد بسپارید: عود با داکسی+ریفامپین حدود **۱۰ تا ۱۵ درصد**،",
  "و با داکسی+استرپتومایسین حدود **۵ درصد یا کمتر**.",
  "**چرا آمینوگلیکوزید بهتر عمل می‌کند؟** به‌خاطر **اثر باکتریسیدال سریع** آن،",
  "در حالی که ترکیب داکسی+ریفامپین عمدتاً **باکتریواستاتیک** است.",
  "⚠️ نکته‌ی مهم دیگر: **ریفامپین سطح سرمی داکسی‌سیکلین را پایین می‌آورد**،",
  "چون القاکننده‌ی قوی سیتوکروم P450 است — یک ضعف پنهان رژیم خوراکی.",
  "**پس چرا رژیم خوراکی این‌قدر رایج است؟** چون **تزریق روزانه‌ی سه هفته‌ای** دشوار است،",
  "و استرپتومایسین **نفروتوکسیک و اتوتوکسیک** است و پایش می‌خواهد.",
  "⚠️ **در امتحان: اگر واژه‌ی «ارجح» یا «گلد استاندارد» آمد ← رژیم آمینوگلیکوزیددار.**",
  "اگر گفت «رژیم مناسب» یا «سرپایی» یا بیمار **باردار/کودک** بود ← رژیم خوراکی یا رژیم خاص.",
 ],
 CORE_EN + [
  "This question hinges on one word: PREFERRED — that is, among correct regimens, which is BEST.",
  "Both standard regimens appear among the options and both are ACCEPTABLE:",
  "DOXYCYCLINE PLUS RIFAMPICIN FOR SIX WEEKS — the commonest, entirely oral, outpatient and convenient.",
  "DOXYCYCLINE SIX WEEKS PLUS STREPTOMYCIN TWO TO THREE WEEKS — injectable, but MORE EFFECTIVE.",
  "WARNING: THE REAL DIFFERENCE IS THE RELAPSE RATE, and that is what 'preferred' means here.",
  "Trials and meta-analyses show that the AMINOGLYCOSIDE-CONTAINING regimen RELAPSES LESS.",
  "Remember the approximate figures: relapse with doxycycline plus rifampicin about 10 TO 15 PER CENT,",
  "and with doxycycline plus streptomycin about 5 PER CENT OR LESS.",
  "WHY DOES THE AMINOGLYCOSIDE DO BETTER? Because of its RAPID BACTERICIDAL action,",
  "whereas doxycycline plus rifampicin is largely BACTERIOSTATIC.",
  "WARNING, another important point: RIFAMPICIN LOWERS SERUM DOXYCYCLINE LEVELS,",
  "because it is a potent cytochrome P450 inducer — a hidden weakness of the oral regimen.",
  "SO WHY IS THE ORAL REGIMEN SO WIDELY USED? Because THREE WEEKS OF DAILY INJECTIONS is hard,",
  "and streptomycin is NEPHROTOXIC AND OTOTOXIC and needs monitoring.",
  "WARNING, IN THE EXAM: if the word PREFERRED or GOLD STANDARD appears, choose the aminoglycoside regimen.",
  "If it says 'a suitable regimen' or 'outpatient', or the patient is PREGNANT OR A CHILD, choose the oral or special regimen.",
 ],
 "⚠️ **کلید این سؤال یک کلمه است: «ارجح».**\n\n"
 "هر دو رژیم استاندارد در گزینه‌ها هستند و **هر دو درست‌اند**؛ سؤال می‌پرسد کدام **بهتر** است.\n\n"
 "**رژیم یک — داکسی‌سیکلین + ریفامپین، هر دو ۶ هفته:** تماماً خوراکی، سرپایی، راحت، و به همین دلیل رایج‌ترین.\n\n"
 "**رژیم دو — داکسی‌سیکلین ۶ هفته + استرپتومایسین ۲ تا ۳ هفته:** نیازمند تزریق روزانه، ولی **مؤثرتر**.\n\n"
 "⚠️ **تفاوت واقعی در میزان عود است:** حدود **۱۰ تا ۱۵ درصد** با رژیم خوراکی، در برابر **۵ درصد یا کمتر** با رژیم آمینوگلیکوزیددار.\n\n"
 "**چرا؟** دو دلیل:\n\n"
 "**۱.** آمینوگلیکوزید **باکتریسیدال سریع** است، در حالی که ترکیب داکسی‌سیکلین + ریفامپین عمدتاً **باکتریواستاتیک** است.\n\n"
 "**۲.** ⚠️ **ریفامپین القاکننده‌ی قوی سیتوکروم P450 است و سطح سرمی داکسی‌سیکلین را پایین می‌آورد** — یک ضعف پنهان که کمتر به آن توجه می‌شود.\n\n"
 "**پس چرا رژیم خوراکی این‌قدر استفاده می‌شود؟** چون سه هفته تزریق روزانه برای بیمار دشوار است و استرپتومایسین **نفروتوکسیک و اتوتوکسیک** است و پایش می‌خواهد.\n\n"
 "⚠️ **قاعده‌ی امتحانی:** واژه‌ی **«ارجح»** یا **«گلد استاندارد»** ← رژیم **آمینوگلیکوزیددار**. واژه‌ی «رژیم مناسب/سرپایی» یا بیمار **باردار یا کودک زیر ۸ سال** ← رژیم خوراکی یا رژیم خاص همان گروه.",
 "WARNING: THE KEY TO THIS QUESTION IS ONE WORD — 'PREFERRED'.\n\n"
 "Both standard regimens are among the options and BOTH ARE CORRECT; the question asks which is BETTER.\n\n"
 "REGIMEN ONE — DOXYCYCLINE PLUS RIFAMPICIN, both for six weeks: entirely oral, outpatient, convenient, and therefore the commonest.\n\n"
 "REGIMEN TWO — DOXYCYCLINE SIX WEEKS PLUS STREPTOMYCIN TWO TO THREE WEEKS: requires daily injections, but MORE EFFECTIVE.\n\n"
 "WARNING, THE REAL DIFFERENCE IS THE RELAPSE RATE: about 10 TO 15 PER CENT with the oral regimen against 5 PER CENT OR LESS with the aminoglycoside regimen.\n\n"
 "WHY? Two reasons:\n\n"
 "1. The aminoglycoside is RAPIDLY BACTERICIDAL, whereas doxycycline plus rifampicin is largely BACTERIOSTATIC.\n\n"
 "2. WARNING: RIFAMPICIN IS A POTENT CYTOCHROME P450 INDUCER AND LOWERS SERUM DOXYCYCLINE LEVELS — a hidden weakness that receives too little attention.\n\n"
 "SO WHY IS THE ORAL REGIMEN SO WIDELY USED? Because three weeks of daily injections is hard for the patient, and streptomycin is NEPHROTOXIC AND OTOTOXIC and requires monitoring.\n\n"
 "WARNING, THE EXAM RULE: the words PREFERRED or GOLD STANDARD point to the AMINOGLYCOSIDE regimen. The words 'a suitable regimen' or 'outpatient', or a PREGNANT patient or A CHILD UNDER 8, point to the oral or group-specific regimen.",
 ["پاسخ صحیح — استرپتومایسین + داکسی‌سیکلین رژیم ارجح است، چون میزان عودش به‌طور معنادار پایین‌تر است.",
  "داکسی‌سیکلین + ریفامپین رژیم درست و رایجی است، ولی عود بیشتری دارد؛ پس «ارجح» نیست.",
  "استرپتومایسین + ریفامپین رژیم استانداردی نیست؛ ستون درمان بروسلوز داکسی‌سیکلین است.",
  "رژیم سه‌دارویی برای موارد عارضه‌دار مانند اسپوندیلیت، نوروبروسلوز و اندوکاردیت است، نه بروسلوز ساده."],
 ["Correct — streptomycin plus doxycycline is the preferred regimen because its relapse rate is significantly lower.",
  "Doxycycline plus rifampicin is a correct and common regimen, but it relapses more often, so it is not 'preferred'.",
  "Streptomycin plus rifampicin is not a standard regimen; doxycycline is the backbone of brucellosis therapy.",
  "A three-drug regimen is for complicated disease such as spondylitis, neurobrucellosis and endocarditis, not uncomplicated brucellosis."],
 "**«ارجح» ← داکسی + استرپتومایسین** (عود ۵٪). **رایج‌ترین ← داکسی + ریفامپین** (عود ۱۰–۱۵٪).",
 "'Preferred' means doxycycline plus streptomycin (relapse about 5%). The commonest is doxycycline plus rifampicin (relapse 10-15%).",
 [H, IOAN, IR])


# =========================================================== book:475
add("book:475", "case", "hard",
 "**آرتریت** = بروسلوز عارضه‌دار ← **رژیم سه‌دارویی**، نه شش هفته‌ی معمول.",
 "ARTHRITIS makes this COMPLICATED brucellosis: use a THREE-DRUG regimen, not the ordinary six weeks.",
 CORE_FA + [
  "بیمار پس از خوردن **پنیر محلی** دچار **تب، تعریق، و درد و تورم زانو از دو ماه قبل** شده.",
  "تیترها: **رایت ۱/۶۴۰** و **2ME برابر ۱/۱۶۰** — هر دو کاملاً تشخیصی.",
  "⚠️ **کلمه‌ی کلیدی «تورم زانو» است: این دیگر بروسلوز ساده نیست، بروسلوز کانونی است.**",
  "**بروسلوز را به دو دسته تقسیم کنید، چون درمانشان فرق دارد:**",
  "**بروسلوز بدون عارضه** ← تب و علائم سیستمیک بدون کانون ← **دو دارو، شش هفته**.",
  "**بروسلوز کانونی (focal)** ← اسپوندیلیت، آرتریت، نوروبروسلوز، اندوکاردیت، ارکیت ←",
  "⚠️ **درمان طولانی‌تر و اغلب سه‌دارویی**.",
  "**چرا سه دارو؟** چون در کانون‌های عمقی مثل مفصل و استخوان و CNS،",
  "**نفوذ دارو محدودتر و بار باکتریایی بیشتر** است؛ دو دارو عود می‌سازد.",
  "رژیم سه‌دارویی معمول: **داکسی‌سیکلین + ریفامپین + آمینوگلیکوزید (استرپتومایسین یا جنتامایسین)**.",
  "**مدت: حداقل سه ماه** برای اسپوندیلیت و آرتریت؛ برای اندوکاردیت **شش ماه یا بیشتر**.",
  "⚠️ گزینه‌ی «درمان شش هفته» درست‌نما ولی **ناکافی** است — برای بروسلوز ساده است، نه کانونی.",
  "و گزینه‌های «پایش بالینی» یا «تکرار رایت» بدتراند: بیمار **علامت‌دار و تیتربالا** است،",
  "پس مشاهده کردن یعنی رها کردن یک عفونت فعال با درگیری مفصلی.",
  "⚠️ **نکته‌ی پیگیری:** بروسلوز کانونی هم مثل بقیه، **بالینی** پیگیری می‌شود نه سرولوژیک.",
 ],
 CORE_EN + [
  "The patient developed FEVER, SWEATS AND A SWOLLEN PAINFUL KNEE two months ago after eating LOCAL CHEESE.",
  "The titres: WRIGHT 1/640 and 2ME 1/160 — both fully diagnostic.",
  "WARNING: THE KEY PHRASE IS 'SWOLLEN KNEE'. This is no longer uncomplicated brucellosis but FOCAL disease.",
  "DIVIDE BRUCELLOSIS IN TWO, BECAUSE THE TREATMENTS DIFFER:",
  "UNCOMPLICATED BRUCELLOSIS — fever and systemic symptoms with no focus: TWO DRUGS FOR SIX WEEKS.",
  "FOCAL BRUCELLOSIS — spondylitis, arthritis, neurobrucellosis, endocarditis, orchitis:",
  "WARNING: LONGER TREATMENT AND USUALLY THREE DRUGS.",
  "WHY THREE DRUGS? Because in deep foci such as joint, bone and CNS",
  "DRUG PENETRATION IS POORER AND THE BACTERIAL LOAD HIGHER; two drugs relapse.",
  "The usual three-drug regimen: DOXYCYCLINE PLUS RIFAMPICIN PLUS AN AMINOGLYCOSIDE (streptomycin or gentamicin).",
  "DURATION: AT LEAST THREE MONTHS for spondylitis and arthritis; SIX MONTHS OR MORE for endocarditis.",
  "WARNING: 'treat for six weeks' looks right but is INSUFFICIENT — that is the uncomplicated regimen.",
  "And 'clinical monitoring' or 'repeat the Wright' are worse: the patient is SYMPTOMATIC WITH A HIGH TITRE,",
  "so observing means abandoning an active infection with joint involvement.",
  "WARNING, A FOLLOW-UP POINT: focal brucellosis, like the rest, is followed CLINICALLY and not serologically.",
 ],
 "بیمار پس از خوردن **پنیر محلی** دچار **تب، تعریق، و درد و تورم زانو از دو ماه قبل** شده است. تیترها هم قاطع‌اند: **رایت ۱/۶۴۰** و **2ME برابر ۱/۱۶۰**.\n\n"
 "⚠️ **کلمه‌ی کلیدی «تورم زانو» است.** این دیگر بروسلوز ساده نیست؛ **بروسلوز کانونی (focal)** است.\n\n"
 "**بروسلوز را همیشه به دو دسته تقسیم کنید، چون درمانشان یکی نیست:**\n\n"
 "**۱. بروسلوز بدون عارضه** ← تب و علائم سیستمیک بدون کانون مشخص ← **دو دارو، شش هفته**\n\n"
 "**۲. بروسلوز کانونی** ← **اسپوندیلیت، آرتریت، نوروبروسلوز، اندوکاردیت، ارکیت** ← ⚠️ **رژیم سه‌دارویی و مدت طولانی‌تر**\n\n"
 "**چرا در کانون سه دارو لازم است؟** چون در بافت‌های عمقی مثل مفصل، استخوان و سیستم عصبی مرکزی، **نفوذ دارو محدودتر و بار باکتریایی بیشتر** است. رژیم دودارویی در این شرایط **عود** می‌سازد.\n\n"
 "**رژیم سه‌دارویی معمول:** داکسی‌سیکلین + ریفامپین + آمینوگلیکوزید (استرپتومایسین یا جنتامایسین)\n"
 "**مدت:** اسپوندیلیت و آرتریت **حداقل سه ماه**؛ اندوکاردیت **شش ماه یا بیشتر**\n\n"
 "**چرا گزینه‌های دیگر رد می‌شوند؟**\n\n"
 "**«درمان شش هفته»** ← درست‌نماست ولی **ناکافی**؛ این مدت برای بروسلوز بدون عارضه است.\n\n"
 "⚠️ **«پایش بالینی تا ۶ ماه» و «تکرار رایت هر دو ماه»** ← بدتر. بیمار **علامت‌دار با تیتر بالا و درگیری مفصلی** است. مشاهده کردن یعنی رها کردن یک عفونت فعال. ضمناً پیگیری بروسلوز اصلاً **سرولوژیک نیست** — بالینی است.",
 "After eating LOCAL CHEESE the patient developed FEVER, SWEATS AND A SWOLLEN PAINFUL KNEE two months ago. The titres are decisive: WRIGHT 1/640 and 2ME 1/160.\n\n"
 "WARNING: THE KEY PHRASE IS 'SWOLLEN KNEE'. This is no longer uncomplicated brucellosis; it is FOCAL disease.\n\n"
 "ALWAYS DIVIDE BRUCELLOSIS IN TWO, BECAUSE THE TREATMENTS DIFFER:\n\n"
 "1. UNCOMPLICATED — fever and systemic symptoms without a defined focus: TWO DRUGS, SIX WEEKS\n\n"
 "2. FOCAL — SPONDYLITIS, ARTHRITIS, NEUROBRUCELLOSIS, ENDOCARDITIS, ORCHITIS: WARNING, A THREE-DRUG REGIMEN AND A LONGER COURSE\n\n"
 "WHY THREE DRUGS IN FOCAL DISEASE? Because in deep tissues such as joint, bone and central nervous system, DRUG PENETRATION IS POORER AND THE BACTERIAL LOAD HIGHER. A two-drug regimen RELAPSES there.\n\n"
 "THE USUAL THREE-DRUG REGIMEN: doxycycline plus rifampicin plus an aminoglycoside (streptomycin or gentamicin)\n"
 "DURATION: spondylitis and arthritis AT LEAST THREE MONTHS; endocarditis SIX MONTHS OR MORE\n\n"
 "WHY THE OTHER OPTIONS FAIL:\n\n"
 "'TREAT FOR SIX WEEKS' looks right but is INSUFFICIENT; that is the uncomplicated course.\n\n"
 "WARNING, 'CLINICAL MONITORING FOR SIX MONTHS' and 'REPEAT THE WRIGHT EVERY TWO MONTHS' are worse. The patient is SYMPTOMATIC, with a high titre and joint involvement. Observing means abandoning an active infection. And in any case brucellosis follow-up is NOT SEROLOGICAL — it is clinical.",
 ["درمان شش هفته‌ای برای بروسلوز بدون عارضه است؛ در آرتریت بروسلایی ناکافی است و عود می‌سازد.",
  "پاسخ صحیح — درگیری مفصلی یعنی بروسلوز کانونی، که رژیم سه‌دارویی و مدت طولانی‌تر می‌خواهد.",
  "پایش بدون درمان در بیمار علامت‌دار با تیتر ۱/۶۴۰ و آرتریت، رها کردن یک عفونت فعال است.",
  "تکرار تست رایت هیچ تصمیمی را عوض نمی‌کند؛ پیگیری بروسلوز بالینی است نه سرولوژیک، و اینجا بیمار نیاز به درمان دارد."],
 ["Six weeks is the uncomplicated course; in brucellar arthritis it is insufficient and invites relapse.",
  "Correct — joint involvement means focal brucellosis, which requires three drugs and a longer course.",
  "Observation without treatment in a symptomatic patient with a titre of 1/640 and arthritis abandons an active infection.",
  "Repeating the Wright changes no decision; brucellosis follow-up is clinical, not serological, and this patient needs treatment."],
 "**کانون (مفصل/مهره/CNS/قلب) ← سه دارو و ≥ ۳ ماه.** بدون کانون ← دو دارو و ۶ هفته.",
 "A focus (joint, spine, CNS, heart) means three drugs for at least three months. No focus means two drugs for six weeks.",
 [H, IOAN, IR])


# =========================================================== book:479
add("book:479", "case", "medium",
 "تماس آزمایشگاهی پرخطر با بروسلا ← **داکسی‌سیکلین + ریفامپین به مدت ۶ هفته** (پروفیلاکسی).",
 "A high-risk laboratory exposure to Brucella needs DOXYCYCLINE PLUS RIFAMPICIN FOR SIX WEEKS as prophylaxis.",
 CORE_FA + [
  "این سؤال درباره‌ی **پروفیلاکسی پس از تماس** است، نه درمان بیماری مستقر.",
  "⚠️ **چرا بروسلا اصلاً پروفیلاکسی پس از تماس دارد، برخلاف بیشتر باکتری‌ها؟**",
  "چون سه ویژگی را با هم دارد: **دوز عفونی بسیار پایین**، **انتقال آئروسل**،",
  "و **دوره‌ی کمون طولانی (هفته‌ها تا ماه‌ها)** که پنجره‌ای برای مداخله باز می‌گذارد.",
  "**سه موقعیت پرخطر که پروفیلاکسی می‌گیرند:**",
  "**یک — کار با کشت بروسلا روی میز باز** (بدون هود ایمنی زیستی).",
  "**دو — فرورفتن سوزن حاوی واکسن دامی بروسلا** (واکسن‌های RB51 و S19 **زنده‌ی ضعیف‌شده**‌اند).",
  "**سه — پاشیدن نمونه به چشم یا مخاط**، یا تماس شدید جلدی-مخاطی.",
  "⚠️ **رژیم پروفیلاکسی همان رژیم درمانی است: داکسی‌سیکلین + ریفامپین به مدت سه تا شش هفته.**",
  "در تماس‌های پرخطر (مثل همین بیمار) **شش هفته** توصیه می‌شود.",
  "**چرا دو دارو حتی برای پروفیلاکسی؟** چون تک‌دارو در ارگانیسم داخل‌سلولی مقاومت و شکست می‌سازد.",
  "⚠️ **و چرا واکسن بروسلا برای انسان تجویز نمی‌شود؟**",
  "چون واکسن‌های موجود **دامی و زنده‌ی ضعیف‌شده** هستند و در انسان **خودشان بیماری‌زا**‌اند.",
  "**پایش سرولوژیک هم انجام می‌شود:** رایت پایه و تکرار آن در هفته‌های ۶، ۱۲ و ۲۴.",
  "و بیمار باید بداند هر تبی در **شش ماه آینده** را باید گزارش کند.",
 ],
 CORE_EN + [
  "This question is about POST-EXPOSURE PROPHYLAXIS, not treatment of established disease.",
  "WARNING: WHY DOES BRUCELLA HAVE POST-EXPOSURE PROPHYLAXIS AT ALL, UNLIKE MOST BACTERIA?",
  "Because it combines three features: A VERY LOW INFECTIOUS DOSE, AEROSOL TRANSMISSION,",
  "and A LONG INCUBATION PERIOD (weeks to months) that leaves a window for intervention.",
  "THE THREE HIGH-RISK SITUATIONS THAT RECEIVE PROPHYLAXIS:",
  "ONE — working with a Brucella culture ON THE OPEN BENCH (outside a biosafety cabinet).",
  "TWO — A NEEDLESTICK WITH VETERINARY BRUCELLA VACCINE (RB51 and S19 are LIVE ATTENUATED).",
  "THREE — A SPLASH TO THE EYE OR MUCOSA, or heavy skin and mucous membrane contact.",
  "WARNING: THE PROPHYLACTIC REGIMEN IS THE TREATMENT REGIMEN — DOXYCYCLINE PLUS RIFAMPICIN FOR THREE TO SIX WEEKS.",
  "For high-risk exposures such as this one, SIX WEEKS is recommended.",
  "WHY TWO DRUGS EVEN FOR PROPHYLAXIS? Because monotherapy against an intracellular organism breeds resistance and failure.",
  "WARNING, AND WHY IS NO BRUCELLA VACCINE GIVEN TO HUMANS?",
  "Because the available vaccines are VETERINARY AND LIVE ATTENUATED, and in humans they CAUSE DISEASE THEMSELVES.",
  "SEROLOGICAL MONITORING IS ALSO DONE: a baseline Wright, repeated at 6, 12 and 24 weeks.",
  "And the person must know to report ANY FEVER IN THE NEXT SIX MONTHS.",
 ],
 "این سؤال درباره‌ی **پروفیلاکسی پس از تماس** است، نه درمان.\n\n"
 "⚠️ **چرا بروسلا برخلاف بیشتر باکتری‌ها پروفیلاکسی پس از تماس دارد؟** چون سه ویژگی را با هم دارد:\n\n"
 "**۱. دوز عفونی‌کننده‌ی بسیار پایین** (گاهی ده تا صد ارگانیسم)\n"
 "**۲. انتقال از راه آئروسل** (باز کردن پلیت کشت روی میز کافی است)\n"
 "**۳. دوره‌ی کمون طولانی** (هفته‌ها تا ماه‌ها) که پنجره‌ای برای مداخله باز می‌گذارد\n\n"
 "**سه موقعیت پرخطر که پروفیلاکسی می‌گیرند:**\n\n"
 "کار با کشت بروسلا **روی میز باز**؛ **نیدل‌استیک با واکسن دامی بروسلا**؛ و **پاشیدن نمونه به چشم یا مخاط** یا تماس شدید جلدی-مخاطی — که مورد همین بیمار است.\n\n"
 "⚠️ **رژیم پروفیلاکسی همان رژیم درمانی است: داکسی‌سیکلین + ریفامپین.** در تماس پرخطر، **شش هفته**.\n\n"
 "**چرا حتی برای پروفیلاکسی دو دارو؟** چون بروسلا **داخل‌سلولی** است و تک‌دارو در آن هم شکست می‌خورد و هم مقاومت می‌سازد. سه هفته داکسی‌سیکلین تنها، هر دو قاعده را نقض می‌کند.\n\n"
 "⚠️ **و چرا واکسن بروسلا به انسان زده نمی‌شود؟** چون واکسن‌های موجود (**RB51** و **S19**) **دامی و زنده‌ی ضعیف‌شده** هستند و در انسان **خودشان بیماری ایجاد می‌کنند**. به همین دلیل، نیدل‌استیک با این واکسن‌ها خودش یک تماس پرخطر محسوب می‌شود.\n\n"
 "**در کنار دارو، پایش هم لازم است:** رایت پایه و تکرار در هفته‌های **۶، ۱۲ و ۲۴**، و آموزش به فرد که **هر تبی در شش ماه آینده** را گزارش کند.",
 "This question is about POST-EXPOSURE PROPHYLAXIS, not treatment.\n\n"
 "WARNING: WHY DOES BRUCELLA, UNLIKE MOST BACTERIA, HAVE POST-EXPOSURE PROPHYLAXIS? Because it combines three features:\n\n"
 "1. A VERY LOW INFECTIOUS DOSE (sometimes ten to a hundred organisms)\n"
 "2. AEROSOL TRANSMISSION (opening a plate on the bench can suffice)\n"
 "3. A LONG INCUBATION PERIOD (weeks to months), leaving a window for intervention\n\n"
 "THE THREE HIGH-RISK SITUATIONS THAT RECEIVE PROPHYLAXIS:\n\n"
 "Working with a Brucella culture ON THE OPEN BENCH; A NEEDLESTICK WITH VETERINARY BRUCELLA VACCINE; and A SPLASH TO THE EYE OR MUCOSA or heavy skin and mucosal contact — which is this patient's case.\n\n"
 "WARNING: THE PROPHYLACTIC REGIMEN IS THE TREATMENT REGIMEN — DOXYCYCLINE PLUS RIFAMPICIN. For a high-risk exposure, SIX WEEKS.\n\n"
 "WHY TWO DRUGS EVEN FOR PROPHYLAXIS? Because Brucella is INTRACELLULAR, and monotherapy against it both fails and breeds resistance. Three weeks of doxycycline alone violates both rules.\n\n"
 "WARNING, AND WHY IS NO BRUCELLA VACCINE GIVEN TO HUMANS? Because the available vaccines (RB51 and S19) are VETERINARY AND LIVE ATTENUATED and CAUSE DISEASE IN PEOPLE. That is exactly why a needlestick with them counts as a high-risk exposure in its own right.\n\n"
 "ALONGSIDE THE DRUGS, MONITORING IS REQUIRED: a baseline Wright repeated at 6, 12 and 24 weeks, and instructions to report ANY FEVER IN THE NEXT SIX MONTHS.",
 ["پروفیلاکسی دارویی در تماس پرخطر با بروسلا کاملاً مؤثر و توصیه‌شده است؛ این گزینه قاعده را انکار می‌کند.",
  "واکسن‌های موجود بروسلا دامی و زنده‌ی ضعیف‌شده‌اند و در انسان خودشان بیماری‌زا هستند.",
  "داکسی‌سیکلین تنها و آن هم سه هفته، هم تک‌دارویی است و هم کوتاه؛ در ارگانیسم داخل‌سلولی شکست می‌خورد.",
  "پاسخ صحیح — داکسی‌سیکلین + ریفامپین به مدت شش هفته، رژیم پروفیلاکسی تماس پرخطر آزمایشگاهی است."],
 ["Drug prophylaxis after high-risk Brucella exposure is effective and recommended; this option denies the rule.",
  "The available Brucella vaccines are veterinary and live attenuated, and cause disease in humans.",
  "Doxycycline alone for three weeks is both monotherapy and too short, and fails against an intracellular organism.",
  "Correct — doxycycline plus rifampicin for six weeks is the regimen for high-risk laboratory exposure."],
 "تماس پرخطر بروسلا ← **داکسی + ریفامپین ۶ هفته** + پایش رایت در هفته‌های ۶، ۱۲ و ۲۴. **واکسن انسانی وجود ندارد.**",
 "High-risk Brucella exposure: doxycycline plus rifampicin for six weeks, with Wright monitoring at 6, 12 and 24 weeks. There is no human vaccine.",
 [H, IR])


# =========================================================== book:483
add("book:483", "case", "hard",
 "اندوکاردیت بروسلایی ← **سه دارو + آمینوگلیکوزید، حداقل شش ماه** و اغلب **جراحی**.",
 "Brucella endocarditis needs THREE DRUGS INCLUDING AN AMINOGLYCOSIDE FOR AT LEAST SIX MONTHS, and usually SURGERY.",
 CORE_FA + [
  "بیمار **قصاب جوان** با تب، لرز، کاهش وزن، درد کمر، **رایت ۱/۶۴۰ و 2ME ۱/۳۲۰** است.",
  "و در معاینه: **سوفل هولوسیستولیک ۴/۶ در آپکس** با **وژتاسیون میترال در اکو**.",
  "⚠️ **این اندوکاردیت بروسلایی است — نادرترین ولی کشنده‌ترین عارضه‌ی بروسلوز.**",
  "**فراوانی و اهمیت را کنار هم بگذارید:** اندوکاردیت کمتر از **۲ درصد** موارد بروسلوز است،",
  "ولی مسئول **بیشتر مرگ‌های ناشی از بروسلوز** است.",
  "⚠️ **دریچه‌ی درگیر معمولاً آئورت است، نه میترال** — برخلاف اغلب اندوکاردیت‌ها.",
  "(در این بیمار میترال درگیر است، که ممکن ولی کمتر شایع است.)",
  "**اصول درمان اندوکاردیت بروسلایی، سه تفاوت با بروسلوز ساده دارد:**",
  "**یک — تعداد دارو:** حداقل **سه دارو**، و **آمینوگلیکوزید الزامی است**،",
  "چون اثر **باکتریسیدال سریع** برای پاک کردن وژتاسیون ضروری است.",
  "**دو — مدت:** **حداقل شش ماه**، نه شش هفته؛ گاهی تا **یک سال**.",
  "⚠️ **سه — جراحی: در اکثر موارد تعویض دریچه لازم است.**",
  "چرا؟ چون وژتاسیون یک **پناهگاه بدون عروق** است که آنتی‌بیوتیک به‌سختی به آن می‌رسد،",
  "و ارگانیسم داخل‌سلولی در آن باقی می‌ماند.",
  "**درمان دارویی تنها، میزان مرگ بسیار بالاتری دارد؛ ترکیب دارو + جراحی بقا را به‌شدت بهبود می‌دهد.**",
  "⚠️ گزینه‌ای که «سه تا شش ماه» می‌گوید، مدت را **کوتاه‌تر از استاندارد** می‌گیرد.",
  "گزینه‌ی «داکسی + ریفامپین شش هفته» رژیم بروسلوز ساده است و در اندوکاردیت **کشنده** است.",
 ],
 CORE_EN + [
  "The patient is a YOUNG BUTCHER with fever, rigors, weight loss, back pain, WRIGHT 1/640 AND 2ME 1/320.",
  "And on examination: A GRADE 4/6 HOLOSYSTOLIC MURMUR AT THE APEX with a MITRAL VEGETATION on echo.",
  "WARNING: THIS IS BRUCELLA ENDOCARDITIS — the rarest but deadliest complication of brucellosis.",
  "PUT FREQUENCY AND IMPORTANCE SIDE BY SIDE: endocarditis occurs in under 2 PER CENT of cases,",
  "yet it accounts for MOST OF THE DEATHS from brucellosis.",
  "WARNING: THE VALVE INVOLVED IS USUALLY THE AORTIC, NOT THE MITRAL — unlike most endocarditis.",
  "(In this patient it is the mitral, which is possible but less common.)",
  "THE PRINCIPLES OF TREATMENT DIFFER FROM UNCOMPLICATED BRUCELLOSIS IN THREE WAYS:",
  "ONE — NUMBER OF DRUGS: at least THREE, and AN AMINOGLYCOSIDE IS MANDATORY,",
  "because rapid BACTERICIDAL activity is essential to clear a vegetation.",
  "TWO — DURATION: AT LEAST SIX MONTHS, not six weeks; sometimes UP TO A YEAR.",
  "WARNING, THREE — SURGERY: VALVE REPLACEMENT IS NEEDED IN MOST CASES.",
  "Why? Because a vegetation is an AVASCULAR SANCTUARY that antibiotics barely reach,",
  "and an intracellular organism survives inside it.",
  "MEDICAL THERAPY ALONE CARRIES A FAR HIGHER MORTALITY; DRUGS PLUS SURGERY MARKEDLY IMPROVES SURVIVAL.",
  "WARNING: the option saying 'three to six months' sets the duration SHORTER THAN STANDARD.",
  "The option 'doxycycline plus rifampicin for six weeks' is the uncomplicated regimen and is LETHAL in endocarditis.",
 ],
 "بیمار **قصاب جوان** است، تیترهای **رایت ۱/۶۴۰ و 2ME ۱/۳۲۰** دارد، و در معاینه **سوفل هولوسیستولیک ۴/۶ در آپکس** با **وژتاسیون دریچه‌ی میترال در اکوکاردیوگرافی** دیده می‌شود.\n\n"
 "⚠️ **این اندوکاردیت بروسلایی است — نادرترین ولی کشنده‌ترین عارضه‌ی بروسلوز.** کمتر از **۲ درصد** موارد بروسلوز، ولی مسئول **بیشتر مرگ‌های** آن.\n\n"
 "**درمان اندوکاردیت بروسلایی سه تفاوت اساسی با بروسلوز ساده دارد:**\n\n"
 "**۱. تعداد دارو** ← حداقل **سه دارو**، و ⚠️ **آمینوگلیکوزید (جنتامایسین) الزامی است**، چون برای پاک کردن وژتاسیون به اثر **باکتریسیدال سریع** نیاز داریم؛ داکسی‌سیکلین و ریفامپین عمدتاً باکتریواستاتیک‌اند.\n\n"
 "**۲. مدت** ← **حداقل شش ماه**، نه شش هفته؛ گاهی تا یک سال. اغلب سفتریاکسون یا کینولون هم به رژیم افزوده می‌شود.\n\n"
 "⚠️ **۳. جراحی** ← **در اکثر موارد تعویض دریچه لازم است.** دلیلش را بفهمید: وژتاسیون یک **پناهگاه بدون عروق** است؛ آنتی‌بیوتیک به‌سختی به آن نفوذ می‌کند و ارگانیسم **داخل‌سلولی** در آن زنده می‌ماند. درمان دارویی تنها میزان مرگ بسیار بالاتری دارد.\n\n"
 "**چرا گزینه‌های دیگر رد می‌شوند؟**\n\n"
 "**«داکسی + ریفامپین شش هفته»** ← رژیم بروسلوز **ساده** است؛ در اندوکاردیت **کشنده**.\n"
 "**«استرپتومایسین ۱۴ تا ۲۱ روز + داکسی ۶ هفته»** ← رژیم استاندارد بروسلوز بدون عارضه؛ باز هم کوتاه.\n"
 "**«سه تا شش ماه»** ← جهت درست، ولی مدت **کوتاه‌تر از استاندارد** و بدون اشاره به گزینه‌های تقویتی.\n\n"
 "⚠️ و یک نکته‌ی آناتومیک که پرسیده می‌شود: در اندوکاردیت بروسلایی، دریچه‌ی درگیر معمولاً **آئورت** است، نه میترال.",
 "The patient is a YOUNG BUTCHER with a WRIGHT OF 1/640 AND 2ME OF 1/320, and on examination a GRADE 4/6 HOLOSYSTOLIC APICAL MURMUR with a MITRAL VEGETATION on echocardiography.\n\n"
 "WARNING: THIS IS BRUCELLA ENDOCARDITIS — the rarest but deadliest complication of brucellosis. Under 2 PER CENT of cases, yet responsible for MOST OF THE DEATHS.\n\n"
 "ITS TREATMENT DIFFERS FROM UNCOMPLICATED BRUCELLOSIS IN THREE FUNDAMENTAL WAYS:\n\n"
 "1. NUMBER OF DRUGS — at least THREE, and WARNING, AN AMINOGLYCOSIDE (GENTAMICIN) IS MANDATORY, because clearing a vegetation demands RAPID BACTERICIDAL activity; doxycycline and rifampicin are largely bacteriostatic.\n\n"
 "2. DURATION — AT LEAST SIX MONTHS, not six weeks, sometimes up to a year. Ceftriaxone or a quinolone is often added.\n\n"
 "WARNING, 3. SURGERY — VALVE REPLACEMENT IS REQUIRED IN MOST CASES. Understand why: a vegetation is an AVASCULAR SANCTUARY that antibiotics barely penetrate, and an INTRACELLULAR organism survives within it. Medical therapy alone carries a far higher mortality.\n\n"
 "WHY THE OTHER OPTIONS FAIL:\n\n"
 "'DOXYCYCLINE PLUS RIFAMPICIN FOR SIX WEEKS' is the UNCOMPLICATED regimen and is LETHAL here.\n"
 "'STREPTOMYCIN 14-21 DAYS PLUS DOXYCYCLINE 6 WEEKS' is the standard uncomplicated regimen; still far too short.\n"
 "'THREE TO SIX MONTHS' points the right way but sets the duration SHORTER THAN STANDARD and omits the adjunctive agents.\n\n"
 "WARNING, and an anatomical point that gets asked: in Brucella endocarditis the valve involved is usually the AORTIC, not the mitral.",
 ["این رژیم استاندارد بروسلوز بدون عارضه است و برای اندوکاردیت بسیار کوتاه و بدون پوشش کافی است.",
  "شش هفته داکسی‌سیکلین و ریفامپین در اندوکاردیت بروسلایی کشنده است؛ نه آمینوگلیکوزید دارد نه مدت کافی.",
  "پاسخ صحیح — سه دارو با آمینوگلیکوزید به مدت حداقل شش ماه، همراه با گزینه‌های تقویتی و اغلب جراحی دریچه.",
  "جهت درست است ولی مدت سه تا شش ماه کوتاه‌تر از استاندارد شش ماه به بالا برای اندوکاردیت بروسلایی است."],
 ["That is the standard uncomplicated regimen and is far too short and too narrow for endocarditis.",
  "Six weeks of doxycycline and rifampicin is lethal in Brucella endocarditis: no aminoglycoside and too short.",
  "Correct — three drugs including an aminoglycoside for at least six months, with adjuncts and usually valve surgery.",
  "The direction is right but three to six months is shorter than the standard of six months or more for Brucella endocarditis."],
 "اندوکاردیت بروسلایی: **<۲٪ موارد ولی بیشتر مرگ‌ها**. **سه دارو + آمینوگلیکوزید، ≥۶ ماه، و اغلب جراحی**.",
 "Brucella endocarditis: under 2% of cases but most of the deaths. Three drugs including an aminoglycoside, at least six months, and usually surgery.",
 [H, IOAN])


# =========================================================== book:459
add("book:459", "recall", "easy",
 "بهترین شاخص پاسخ به درمان بروسلوز = **حال عمومی و وزن بیمار**، نه تیتر سرولوژی.",
 "The best index of response in brucellosis is THE PATIENT'S GENERAL CONDITION AND WEIGHT, not a serological titre.",
 CORE_FA + FOLLOW_FA + [
  "این سؤال مستقیم‌ترین شکل قاعده‌ی پیگیری است و پاسخش را باید بی‌درنگ بدانید.",
  "سه گزینه‌ی نادرست، هر سه **سرولوژی** را ملاک گرفته‌اند، و هر سه به یک دلیل رد می‌شوند:",
  "⚠️ **آنتی‌بادی ضدبروسلا پس از درمان موفق ماه‌ها تا سال‌ها باقی می‌ماند.**",
  "«منفی شدن رایت پس از یک ماه» انتظاری است که **در بیمار بهبودیافته هم برآورده نمی‌شود**.",
  "«کاهش یک یا دو تیتر پس از یک ماه» هم زودتر از آن است که معنادار باشد.",
  "و «منفی شدن تست‌های سرولوژی» ممکن است **هرگز** اتفاق نیفتد، حتی در بیمار کاملاً درمان‌شده.",
  "⚠️ **پس چرا وزن؟** چون وزن یک شاخص **عینی، ارزان و حساس** برای فعالیت بیماری است.",
  "بروسلوز فعال با تب مزمن و بی‌اشتهایی، **کاهش وزن پیشرونده** می‌سازد.",
  "و برگشت اشتها و وزن، نشانه‌ی خاموش شدن همان روند التهابی است.",
  "به همین دلیل در دستورالعمل کشوری، **ثبت وزن در هر ویزیت** بخشی از پیگیری است.",
  "⚠️ کنار وزن، **علائم بالینی** را هم دنبال می‌کنیم: تب، تعریق، آرترالژی و ضعف.",
  "و اگر عود بالینی رخ داد، **کشت خون** ابزار اثبات است، نه تیتر.",
 ],
 CORE_EN + FOLLOW_EN + [
  "This is the rule of follow-up in its most direct form, and you should know the answer instantly.",
  "The three wrong options all take SEROLOGY as the criterion, and all fail for one reason:",
  "WARNING: ANTI-BRUCELLA ANTIBODY PERSISTS FOR MONTHS TO YEARS AFTER SUCCESSFUL TREATMENT.",
  "'The Wright becoming negative after a month' is an expectation NOT EVEN MET BY A CURED PATIENT.",
  "'A fall of one or two titres after a month' is likewise too early to mean anything.",
  "And 'the serology becoming negative' may NEVER happen, even in someone completely cured.",
  "WARNING, SO WHY WEIGHT? Because weight is an OBJECTIVE, CHEAP AND SENSITIVE index of disease activity.",
  "Active brucellosis, with its chronic fever and anorexia, causes PROGRESSIVE WEIGHT LOSS.",
  "And the return of appetite and weight signals that the inflammatory process has quietened.",
  "That is why the national guideline makes RECORDING THE WEIGHT AT EVERY VISIT part of follow-up.",
  "WARNING, alongside weight we follow the CLINICAL SYMPTOMS: fever, sweats, arthralgia and weakness.",
  "And if clinical relapse occurs, BLOOD CULTURE is the tool that proves it, not a titre.",
 ],
 "این سؤال مستقیم‌ترین شکل مهم‌ترین قاعده‌ی این فصل است:\n\n"
 "⚠️ **پیگیری بروسلوز بالینی است، نه سرولوژیک.**\n\n"
 "**چرا سرولوژی به درد پیگیری نمی‌خورد؟**\n\n"
 "آنتی‌بادی‌های ضدبروسلا پس از **درمان موفق** هم **ماه‌ها تا سال‌ها** در خون باقی می‌مانند. پس:\n\n"
 "**«منفی شدن رایت پس از یک ماه»** ← انتظاری که حتی در بیمار **کاملاً درمان‌شده** برآورده نمی‌شود.\n"
 "**«کاهش یک یا دو تیتر پس از یک ماه»** ← خیلی زودتر از آن است که معنادار باشد.\n"
 "**«منفی شدن تست‌های سرولوژی»** ← ممکن است **هرگز** رخ ندهد.\n\n"
 "⚠️ **و خطر واقعی این است:** پزشکی که بر اساس تیتر تصمیم می‌گیرد، یا بیمار سالم را **بی‌جهت دوباره درمان می‌کند**، یا بیمار عودکرده‌ای را که تیترش پایین آمده **از دست می‌دهد**.\n\n"
 "**پس چه چیزی را دنبال کنیم؟**\n\n"
 "**حال عمومی، علائم بالینی (تب، تعریق، آرترالژی، ضعف) و — مهم‌ترین شاخص عینی — وزن بیمار.**\n\n"
 "⚠️ **چرا وزن؟** چون بروسلوز فعال با تب مزمن و بی‌اشتهایی، **کاهش وزن پیشرونده** می‌سازد؛ و برگشت وزن یعنی خاموش شدن همان روند. وزن ارزان، عینی و قابل ثبت است — به همین دلیل در دستورالعمل کشوری، **ثبت وزن در هر ویزیت** بخشی از پیگیری است.\n\n"
 "**مدت پیگیری: دو سال.** و اگر عود بالینی رخ داد، ابزار اثباتش **کشت خون** است، نه تیتر.",
 "This is the most direct form of the most important rule in this chapter:\n\n"
 "WARNING: BRUCELLOSIS FOLLOW-UP IS CLINICAL, NOT SEROLOGICAL.\n\n"
 "WHY IS SEROLOGY USELESS FOR FOLLOW-UP?\n\n"
 "Anti-Brucella antibodies persist for MONTHS TO YEARS even after SUCCESSFUL treatment. Therefore:\n\n"
 "'THE WRIGHT BECOMING NEGATIVE AFTER A MONTH' is an expectation not met even by a fully cured patient.\n"
 "'A FALL OF ONE OR TWO TITRES AFTER A MONTH' is far too early to mean anything.\n"
 "'THE SEROLOGY BECOMING NEGATIVE' may NEVER happen.\n\n"
 "WARNING, AND HERE IS THE REAL DANGER: a clinician who decides on titres either RETREATS A WELL PATIENT NEEDLESSLY or MISSES A RELAPSE whose titre happens to have fallen.\n\n"
 "SO WHAT DO WE FOLLOW?\n\n"
 "GENERAL CONDITION, CLINICAL SYMPTOMS (fever, sweats, arthralgia, weakness) and — the most useful objective index — THE PATIENT'S WEIGHT.\n\n"
 "WARNING, WHY WEIGHT? Because active brucellosis, with chronic fever and anorexia, causes PROGRESSIVE WEIGHT LOSS, and its return signals that the process has quietened. Weight is cheap, objective and recordable — which is why the national guideline makes RECORDING THE WEIGHT AT EVERY VISIT part of follow-up.\n\n"
 "DURATION OF FOLLOW-UP: TWO YEARS. And if clinical relapse occurs, the tool that proves it is BLOOD CULTURE, not a titre.",
 ["رایت پس از یک ماه درمان منفی نمی‌شود، حتی در بیمار کاملاً بهبودیافته؛ این انتظار غیرواقعی است.",
  "کاهش یک یا دو تیتر پس از یک ماه بسیار زودهنگام است و معیار قابل اتکایی برای پاسخ به درمان نیست.",
  "سرولوژی بروسلا ممکن است ماه‌ها تا سال‌ها مثبت بماند و منفی شدن آن معیار بهبود نیست.",
  "پاسخ صحیح — حال عمومی و وزن بیمار مفیدترین و عینی‌ترین شاخص پاسخ به درمان بروسلوز است."],
 ["The Wright does not become negative after a month of treatment, even in a fully cured patient; the expectation is unrealistic.",
  "A fall of one or two titres after a month is far too early and is not a reliable index of response.",
  "Brucella serology may stay positive for months to years, and its becoming negative is not a criterion of cure.",
  "Correct — the patient's general condition and weight are the most useful and objective index of response."],
 "پیگیری بروسلوز = **بالینی + وزن، به مدت دو سال**. سرولوژی سال‌ها مثبت می‌ماند و **معیار بهبود نیست**.",
 "Brucellosis follow-up is clinical plus weight, for two years. Serology stays positive for years and is not a criterion of cure.",
 [H, IR])


# =========================================================== book:462
add("book:462", "case", "hard",
 "عود پس از درمان کامل ← **همان رژیم، دوره‌ی طولانی‌تر** (۱۲ هفته)، نه تغییر دارو.",
 "Relapse after a full course means THE SAME REGIMEN FOR LONGER (12 weeks), not a change of drugs.",
 CORE_FA + FOLLOW_FA + [
  "بیمار **۸ هفته** داکسی‌سیکلین + ریفامپین گرفته، خوب شده، و **دو هفته بعد** علائم برگشته‌اند.",
  "تیترها: **رایت ۱/۳۲۰ و 2ME ۱/۱۶۰** — یعنی **IgG فعال** هنوز بالاست.",
  "⚠️ **این تعریف کلاسیک عود (relapse) است: بهبود، سپس بازگشت علائم پس از پایان درمان.**",
  "و همان‌طور که گفتیم، **عود بالینی است که تشخیص را می‌گذارد، نه تیتر**؛",
  "اینجا تیتر فقط تصویر بالینی را **تأیید** می‌کند، نه اینکه به‌تنهایی تصمیم بسازد.",
  "⚠️ **مهم‌ترین نکته: عود در بروسلوز معمولاً به‌معنای مقاومت دارویی نیست.**",
  "مقاومت اکتسابی در بروسلا **نادر** است — این بیماری با آن معروف نمی‌شود.",
  "عود یعنی **ارگانیسم داخل‌سلولی از دوره‌ی درمان جان به‌در برده است**.",
  "**پس منطق درمان مجدد: همان داروها، ولی طولانی‌تر.**",
  "در این سؤال، **داکسی‌سیکلین + ریفامپین به مدت ۱۲ هفته** انتخاب می‌شود.",
  "⚠️ چرا «تحت نظر گرفتن و تکرار آزمایش پس از ۸ هفته» غلط است؟",
  "چون بیمار **علامت‌دار** است؛ رها کردن یک عفونت فعال داخل‌سلولی، خطر **کانونی شدن** را بالا می‌برد.",
  "و کانونی شدن یعنی اسپوندیلیت، نوروبروسلوز یا اندوکاردیت — عوارضی که همین‌جا قابل پیشگیری بودند.",
  "**در عمل، بسیاری از مراکز در عود، آمینوگلیکوزید هم اضافه می‌کنند** تا اثر باکتریسیدال داشته باشند.",
  "⚠️ **و بیشتر عودها در شش ماه اول پس از پایان درمان رخ می‌دهند** — درست مثل این بیمار.",
 ],
 CORE_EN + FOLLOW_EN + [
  "The patient took doxycycline plus rifampicin for EIGHT WEEKS, improved, and TWO WEEKS LATER the symptoms returned.",
  "The titres: WRIGHT 1/320 AND 2ME 1/160 — that is, ACTIVE IgG is still high.",
  "WARNING: THIS IS THE CLASSICAL DEFINITION OF RELAPSE — recovery, then return of symptoms after treatment ends.",
  "And as we said, IT IS THE CLINICAL PICTURE THAT MAKES THE DIAGNOSIS, NOT THE TITRE;",
  "here the titre merely CONFIRMS the clinical picture rather than deciding by itself.",
  "WARNING, THE KEY POINT: RELAPSE IN BRUCELLOSIS USUALLY DOES NOT MEAN DRUG RESISTANCE.",
  "Acquired resistance in Brucella is RARE — this is not a disease known for it.",
  "Relapse means THE INTRACELLULAR ORGANISM SURVIVED THE COURSE OF TREATMENT.",
  "SO THE LOGIC OF RETREATMENT IS: THE SAME DRUGS, BUT FOR LONGER.",
  "In this question that is DOXYCYCLINE PLUS RIFAMPICIN FOR 12 WEEKS.",
  "WARNING, why is 'observe and repeat the tests in eight weeks' wrong?",
  "Because the patient IS SYMPTOMATIC; leaving an active intracellular infection raises the risk of FOCAL DISEASE.",
  "And focal disease means spondylitis, neurobrucellosis or endocarditis — complications preventable right here.",
  "IN PRACTICE MANY CENTRES ALSO ADD AN AMINOGLYCOSIDE at relapse, for bactericidal activity.",
  "WARNING, AND MOST RELAPSES OCCUR WITHIN SIX MONTHS OF FINISHING TREATMENT — exactly like this patient.",
 ],
 "بیمار **هشت هفته** داکسی‌سیکلین + ریفامپین گرفته، خوب شده، و **دو هفته پس از پایان دارو** دوباره تب، تعریق، درد استخوانی و بی‌اشتهایی پیدا کرده است. تیترها هم بالا مانده‌اند: **رایت ۱/۳۲۰ و 2ME ۱/۱۶۰**.\n\n"
 "⚠️ **این تعریف کلاسیک عود است: بهبود، سپس بازگشت علائم پس از پایان درمان.**\n\n"
 "توجه کنید که تشخیص را **تابلوی بالینی** گذاشت، نه تیتر. تیتر فقط آن را تأیید کرد. (اگر همین تیترها را در بیماری **بی‌علامت** می‌دیدید، هیچ کاری لازم نبود — همان درسی که در سؤالات پیگیری آمد.)\n\n"
 "⚠️ **مهم‌ترین نکته‌ی این سؤال: عود در بروسلوز معمولاً به‌معنای مقاومت دارویی نیست.** مقاومت اکتسابی در بروسلا **نادر** است. عود یعنی **ارگانیسم داخل‌سلولی از دوره‌ی درمان جان به‌در برده** — یعنی مسئله **مدت** و **نفوذ** بوده، نه انتخاب دارو.\n\n"
 "**پس منطق درمان مجدد ساده است: همان داروها، دوره‌ی طولانی‌تر.** در این سؤال، **داکسی‌سیکلین + ریفامپین به مدت ۱۲ هفته**. در عمل بسیاری از مراکز یک **آمینوگلیکوزید** هم اضافه می‌کنند تا اثر باکتریسیدال داشته باشند.\n\n"
 "⚠️ **چرا «تحت نظر گرفتن و تکرار آزمایش پس از ۸ هفته» خطرناک است؟** چون بیمار **علامت‌دار** است. رها کردن یک عفونت فعال داخل‌سلولی خطر **کانونی شدن** را بالا می‌برد — اسپوندیلیت، نوروبروسلوز یا اندوکاردیت. اینها عوارضی هستند که همین امروز قابل پیشگیری‌اند.\n\n"
 "و یک نکته‌ی زمانی: **بیشتر عودها در شش ماه اول پس از پایان درمان رخ می‌دهند** — دقیقاً مثل این بیمار.",
 "The patient took doxycycline plus rifampicin for EIGHT WEEKS, improved, and TWO WEEKS AFTER STOPPING developed fever, sweats, bone pain and anorexia again. The titres remain high: WRIGHT 1/320 AND 2ME 1/160.\n\n"
 "WARNING: THIS IS THE CLASSICAL DEFINITION OF RELAPSE — recovery, then return of symptoms after treatment ends.\n\n"
 "Note that THE CLINICAL PICTURE made the diagnosis, not the titre. The titre merely confirmed it. (Had you seen those same titres in an ASYMPTOMATIC patient, nothing would be needed — the lesson from the follow-up questions.)\n\n"
 "WARNING, THE KEY POINT: RELAPSE IN BRUCELLOSIS USUALLY DOES NOT MEAN DRUG RESISTANCE. Acquired resistance in Brucella is RARE. Relapse means THE INTRACELLULAR ORGANISM SURVIVED THE COURSE — the problem was DURATION AND PENETRATION, not drug choice.\n\n"
 "SO THE LOGIC OF RETREATMENT IS SIMPLE: THE SAME DRUGS FOR LONGER. Here that is DOXYCYCLINE PLUS RIFAMPICIN FOR 12 WEEKS. In practice many centres also add an AMINOGLYCOSIDE for bactericidal effect.\n\n"
 "WARNING, WHY IS 'OBSERVE AND REPEAT THE TESTS IN EIGHT WEEKS' DANGEROUS? Because the patient IS SYMPTOMATIC. Leaving an active intracellular infection raises the risk of FOCAL DISEASE — spondylitis, neurobrucellosis or endocarditis, all preventable today.\n\n"
 "And a point about timing: MOST RELAPSES OCCUR WITHIN SIX MONTHS OF FINISHING TREATMENT — exactly like this patient.",
 ["افزودن جنتامایسین منطقی است، ولی مدت هشت هفته برای عود کافی نیست؛ عود دوره‌ی طولانی‌تر می‌خواهد.",
  "پاسخ صحیح — عود معمولاً از مقاومت ناشی نمی‌شود، پس همان رژیم با دوره‌ی طولانی‌تر (۱۲ هفته) تجویز می‌شود.",
  "بیمار علامت‌دار است؛ تحت نظر گرفتن یعنی رها کردن عفونت فعال و خطر بروز شکل کانونی بیماری.",
  "استرپتومایسین دوازده‌هفته‌ای عملی نیست و سمیت کلیوی و شنوایی تجمعی قابل توجهی دارد."],
 ["Adding gentamicin is reasonable, but eight weeks is not long enough for a relapse, which needs a longer course.",
  "Correct — relapse usually reflects survival rather than resistance, so the same regimen is given for longer (12 weeks).",
  "The patient is symptomatic; observation abandons an active infection and risks focal disease.",
  "Twelve weeks of streptomycin is impractical and carries substantial cumulative renal and auditory toxicity."],
 "عود بروسلوز = **بقای داخل‌سلولی، نه مقاومت** ← **همان رژیم، طولانی‌تر (۱۲ هفته)**. بیشتر عودها در **۶ ماه اول**.",
 "Brucellosis relapse means intracellular survival, not resistance, so give the same regimen for longer (12 weeks). Most relapses occur within six months.",
 [H, IOAN, IR])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book20.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 20 lessons:', len(L))
