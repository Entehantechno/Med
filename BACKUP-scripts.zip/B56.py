# -*- coding: utf-8 -*-
"""Micro-lessons, batch 56 — tuberculosis part six: preventive therapy in the
HIV-positive contact, and the twelve-week window in the immunocompetent adult
contact.

THE RULE THAT DECIDES SIX QUESTIONS IN A ROW
----------------------------------------------
    AN HIV-POSITIVE PERSON WHO HAS BEEN IN CLOSE CONTACT WITH AN INFECTIOUS
    TUBERCULOSIS CASE RECEIVES PREVENTIVE ISONIAZID REGARDLESS OF THE
    TUBERCULIN RESULT — POSITIVE, NEGATIVE, OR ANY SIZE AT ALL.

Three separate facts converge on that rule.

FACT ONE — THE TUBERCULIN TEST FAILS IN HIV.
The Mantoux is a delayed hypersensitivity reaction executed by CD4 cells. HIV
destroys the CD4 cell. So as the count falls the test loses sensitivity and
eventually becomes anergic: a NEGATIVE PPD IN AN HIV-POSITIVE PATIENT MEANS
NOTHING AT ALL. It cannot exclude infection.

FACT TWO — THE STAKES ARE ENORMOUS.
In an immunocompetent person the lifetime risk of latent infection becoming
disease is about 10 %. In untreated HIV it is ABOUT 10 % PER YEAR.

FACT THREE — THE TEST IS UNRELIABLE BUT THE EXPOSURE IS DOCUMENTED.
When one piece of evidence is unreliable and another is solid, decide on the
solid one. The exposure is solid; the skin test is not.

WHY 5 MM IS THE THRESHOLD WHEN A TEST IS AVAILABLE
----------------------------------------------------
For an HIV-positive person WITHOUT documented contact, the threshold is 5 mm —
the lowest in the table — for the same reason: to catch as many infected people
as possible in a group where a false negative is lethal. But WITH documented
contact the test is bypassed entirely.

THE TWELVE-WEEK WINDOW, WHICH DECIDES THE IMMUNOCOMPETENT ADULT CONTACT
--------------------------------------------------------------------------
A tuberculin test does not turn positive the day infection occurs. It takes
TWO TO TWELVE WEEKS for the delayed hypersensitivity response to develop. This
interval — the WINDOW PERIOD — creates two distinct clinical situations:

    LESS than 12 weeks since last exposure, and the test is negative
        the test cannot be trusted; it may simply be too early. Window
        prophylaxis is considered in the vulnerable, and THE TEST IS REPEATED
        AT 8 TO 12 WEEKS.

    MORE than 12 weeks since last exposure, and the test is negative
        enough time has passed for conversion to have happened. A negative
        test now genuinely means no infection, and NO PREVENTIVE TREATMENT
        IS NEEDED.

That distinction is exactly what one question in this block turns on, and it
is the reason a 3 mm result in a diabetic contact needs a date, not a drug.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022) —
tuberculosis; WHO consolidated guidelines on tuberculosis, Module 1:
Prevention — tuberculosis preventive treatment (2020); CDC/NTCA MMWR Recomm
Rep 2020;69(1).
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — tuberculosis")
WHO1 = ("WHO consolidated guidelines on tuberculosis, Module 1: Prevention — "
        "tuberculosis preventive treatment (2020)")
CDC = ("Sterling TR et al. Guidelines for the Treatment of Latent Tuberculosis "
       "Infection: Recommendations from the NTCA and CDC, 2020. "
       "MMWR Recomm Rep 2020;69(1):1-11")
REFS = [H, WHO1]
REFSC = [H, CDC]

# ============================================ HIV CONTACT: IGNORE THE PPD
HIVC_FA = [
    "⚠️ **در فرد HIV مثبت با تماس نزدیک، تست توبرکولین اصلاً تصمیم‌ساز نیست.**",
    "**پروفیلاکسی داده می‌شود، صرف‌نظر از اینکه تست مثبت باشد یا منفی.**",
    "**سه واقعیت به این قاعده می‌رسند.**",
    "**واقعیت یک: تست مانتو یک پاسخ ازدیاد حساسیت تأخیری است.**",
    "**و مجری آن، همان لنفوسیت CD4 است که HIV نابودش می‌کند.**",
    "⚠️ **پس PPD منفی در بیمار HIV مثبت هیچ چیز را رد نمی‌کند — آنرژی است.**",
    "**واقعیت دو: خطر بسیار بزرگ است.**",
    "**در فرد سالم ۱۰٪ در طول عمر؛ در HIV درمان‌نشده حدود ۱۰٪ در هر سال.**",
    "**واقعیت سه: شاهد نامطمئن را کنار بگذارید و بر شاهد محکم تکیه کنید.**",
    "**تماس مستند، محکم است؛ تست پوستی نیست.**",
    "⚠️ **و پیش از هر پروفیلاکسی، سل فعال باید رد شود.**",
    "**چون ایزونیازید تنها در سل فعال، یعنی ساختن مقاومت.**",
]
HIVC_EN = [
    "WARNING: IN AN HIV-POSITIVE CLOSE CONTACT, THE TUBERCULIN TEST IS NOT THE DECIDER AT ALL.",
    "Preventive therapy is given regardless of whether the test is positive or negative.",
    "Three facts converge on that rule.",
    "FACT ONE: the Mantoux is a DELAYED HYPERSENSITIVITY response.",
    "And it is executed by the very CD4 lymphocyte that HIV destroys.",
    "WARNING: SO A NEGATIVE PPD IN AN HIV-POSITIVE PATIENT EXCLUDES NOTHING — it is anergy.",
    "FACT TWO: the stakes are enormous.",
    "In a healthy person, 10 % over a lifetime; in untreated HIV, about 10 % PER YEAR.",
    "FACT THREE: set the unreliable evidence aside and decide on the solid evidence.",
    "The documented exposure is solid; the skin test is not.",
    "WARNING, AND BEFORE ANY PREVENTIVE THERAPY, ACTIVE DISEASE MUST BE EXCLUDED.",
    "Because isoniazid alone in active tuberculosis means creating resistance.",
]

add("book:268", "vignette", "medium",
    "**HIV مثبت با تماس یک‌ماهه و PPD منفی: نه ماه ایزونیازید لازم است.**",
    "HIV-positive with a month of contact and a negative PPD: nine months of isoniazid is required.",
    HIVC_FA, HIVC_EN,
    "این سؤال، سنگ‌بنای شش سؤال بعدی است. **اگر منطقش را یک‌بار بفهمید، همه‌ی آن‌ها "
    "را در چند ثانیه حل می‌کنید.**\n\n"
    "**بیمار: مرد ۲۵ ساله با عفونت HIV که یک ماه با بیمار مبتلا به سل ریوی اسمیر "
    "مثبت هم‌خانه بوده. شواهدی از سل فعال ندارد. تست PPD منفی است.**\n\n"
    "**پاسخ: پروفیلاکسی با ایزونیازید به‌مدت ۹ ماه لازم است.**\n\n"
    "⚠️ **گره‌ی سؤال در این است: PPD منفی است. آیا این یعنی عفونت نگرفته؟ خیر — و "
    "دلیلش بنیادی است.**\n\n"
    "**تست مانتو چگونه کار می‌کند؟** پروتئین PPD زیر پوست تزریق می‌شود. اگر بدن قبلاً "
    "با باسیل سل روبه‌رو شده باشد، **لنفوسیت‌های T حافظه** به محل هجوم می‌آورند، "
    "سیتوکین ترشح می‌کنند، و **اندوراسیون** می‌سازند.\n\n"
    "**یعنی نتیجه‌ی تست، نه بیانگر وجود باکتری، بلکه بیانگر توانایی سیستم ایمنی در "
    "پاسخ دادن است.**\n\n"
    "⚠️ **و HIV دقیقاً همان لنفوسیت CD4 را که این پاسخ را اجرا می‌کند، نابود "
    "می‌کند.**\n\n"
    "**نتیجه: با پایین آمدن CD4، تست حساسیتش را از دست می‌دهد و بالاخره آنرژیک "
    "می‌شود. در CD4 خیلی پایین، حتی بیمار مبتلا به سل فعالِ منتشر هم می‌تواند PPD "
    "منفی داشته باشد.**\n\n"
    "**پس PPD منفی در بیمار HIV مثبت، اطلاعات صفر دارد. نه عفونت را رد می‌کند، نه "
    "بیماری را.**\n\n"
    "**حالا دو شاهد را کنار هم بگذارید:**\n\n"
    "**شاهد محکم:** یک ماه هم‌خانگی با بیمار **اسمیر مثبت** — یعنی بالاترین درجه‌ی "
    "سرایت، در بسته‌ترین نوع تماس. **احتمال عفونت بسیار بالاست.**\n\n"
    "**شاهد بی‌ارزش:** PPD منفی در فردی که نمی‌تواند به PPD پاسخ دهد.\n\n"
    "**و خطر: در HIV درمان‌نشده، عفونت نهفته با سرعت حدود ۱۰٪ در سال به بیماری فعال "
    "تبدیل می‌شود.**\n\n"
    "**پس تصمیم روشن است: پروفیلاکسی بده، و تست را نادیده بگیر.**\n\n"
    "**مدت: ۹ ماه ایزونیازید** — استاندارد کلاسیک برای بیماران HIV مثبت (در برخی "
    "راهنماها ۶ ماه، ولی ۹ ماه در HIV ترجیح داشته است).\n\n"
    "⚠️ **و دو نکته‌ی الزامی برای بالین:**\n\n"
    "**۱. پیش از شروع، سل فعال را رد کنید** — گرافی، شرح حال، و در صورت وجود علامت، "
    "اسمیر خلط. **ایزونیازید تنها در سل فعال، یعنی تک‌درمانی و ساختن مقاومت.**\n\n"
    "**۲. پیریدوکسین اضافه کنید** — بیماران HIV مثبت خطر نوروپاتی بیشتری دارند.\n\n"
    "**(نکته‌ی امروزی: راهنماهای فعلی رژیم‌های کوتاه‌تر مانند 3HP را هم در HIV مجاز "
    "می‌دانند، به شرط نبود تداخل با داروهای ضدرتروویروسی.)**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**پروفیلاکسی تا یک ماه، سپس PPD مجدد** — ⚠️ **بر تستی تکیه می‌کند که در این بیمار "
    "بی‌اعتبار است.** و یک ماه برای تبدیل تست کافی نیست (۸ تا ۱۲ هفته لازم است).\n\n"
    "**پروفیلاکسی تا ۳ ماه، سپس PPD مجدد** — همان خطا، با زمان‌بندی بهتر. **باز هم "
    "تصمیم را به تستی سپرده که کار نمی‌کند.**\n\n"
    "⚠️ **نیازی به پروفیلاکسی ندارد** — **خطرناک‌ترین گزینه.** این یعنی PPD منفی را "
    "باور کردن در بیماری که نمی‌تواند به PPD پاسخ دهد. **نتیجه‌ی احتمالی: سل فعال "
    "در بیمار HIV مثبت، که مرگ‌ومیر بالایی دارد.**",
    "This question is the cornerstone of the six that follow. UNDERSTAND ITS LOGIC ONCE AND YOU WILL SOLVE THEM ALL IN SECONDS.\n\n"
    "THE PATIENT: a 25-year-old man with HIV who has lived for a month in the same house as a smear-positive tuberculosis patient. There is no evidence of active disease. HIS PPD IS NEGATIVE.\n\n"
    "THE ANSWER: NINE MONTHS OF PREVENTIVE ISONIAZID IS REQUIRED.\n\n"
    "WARNING: THE KNOT OF THE QUESTION IS THIS — THE PPD IS NEGATIVE. DOES THAT MEAN HE IS NOT INFECTED? NO, AND THE REASON IS FUNDAMENTAL.\n\n"
    "HOW DOES THE MANTOUX WORK? PPD protein is injected into the skin. If the body has met the tubercle bacillus before, MEMORY T LYMPHOCYTES converge on the site, secrete cytokines, and produce INDURATION.\n\n"
    "SO THE RESULT REFLECTS NOT THE PRESENCE OF BACTERIA BUT THE IMMUNE SYSTEM'S ABILITY TO RESPOND.\n\n"
    "WARNING: AND HIV DESTROYS PRECISELY THE CD4 LYMPHOCYTE THAT EXECUTES THAT RESPONSE.\n\n"
    "THE RESULT: as the CD4 count falls the test loses sensitivity and eventually becomes anergic. At a very low count even a patient with disseminated ACTIVE tuberculosis can have a negative PPD.\n\n"
    "SO A NEGATIVE PPD IN AN HIV-POSITIVE PATIENT CARRIES ZERO INFORMATION. It excludes neither infection nor disease.\n\n"
    "NOW SET THE TWO PIECES OF EVIDENCE SIDE BY SIDE:\n\n"
    "THE SOLID EVIDENCE: a month of household contact with a SMEAR-POSITIVE case — the highest degree of infectiousness, in the closest kind of contact. THE PROBABILITY OF INFECTION IS VERY HIGH.\n\n"
    "THE WORTHLESS EVIDENCE: a negative PPD in a person who cannot respond to PPD.\n\n"
    "AND THE STAKES: in untreated HIV, latent infection converts to active disease at about 10 % PER YEAR.\n\n"
    "SO THE DECISION IS CLEAR: GIVE PREVENTIVE THERAPY AND IGNORE THE TEST.\n\n"
    "THE DURATION: NINE MONTHS OF ISONIAZID — the classical standard in HIV-positive patients (some guidelines say six, but nine has been preferred in HIV).\n\n"
    "WARNING, AND TWO OBLIGATORY BEDSIDE POINTS:\n\n"
    "1. EXCLUDE ACTIVE DISEASE FIRST — chest film, history, and sputum smear if any symptom exists. ISONIAZID ALONE IN ACTIVE TUBERCULOSIS IS MONOTHERAPY AND BREEDS RESISTANCE.\n\n"
    "2. ADD PYRIDOXINE — HIV-positive patients carry a higher neuropathy risk.\n\n"
    "(A contemporary note: current guidance also permits shorter regimens such as 3HP in HIV, provided there is no interaction with the antiretroviral regimen.)\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "PROPHYLAXIS FOR A MONTH THEN REPEAT THE PPD — WARNING, IT LEANS ON A TEST THAT IS INVALID IN THIS PATIENT. And one month is too short for conversion anyway (8 to 12 weeks are needed).\n\n"
    "PROPHYLAXIS FOR 3 MONTHS THEN REPEAT THE PPD — the same error with better timing. IT STILL HANDS THE DECISION TO A TEST THAT DOES NOT WORK.\n\n"
    "WARNING: 'NO PROPHYLAXIS NEEDED' — THE MOST DANGEROUS OPTION. It means believing a negative PPD in a patient who cannot produce a positive one. THE LIKELY CONSEQUENCE: active tuberculosis in an HIV-positive patient, which carries high mortality.",
    ["بر تستی تکیه می‌کند که در بیمار HIV مثبت بی‌اعتبار است؛ یک ماه هم برای تبدیل کافی نیست.",
     "همان خطا با زمان‌بندی بهتر؛ باز هم تصمیم را به تست آنرژیک سپرده است.",
     "پاسخ صحیح — تماس مستند شاهد محکم است و PPD در HIV بی‌اعتبار؛ نه ماه ایزونیازید.",
     "خطرناک‌ترین گزینه؛ باور کردن PPD منفی در کسی که نمی‌تواند به PPD پاسخ دهد."],
    ["Leans on a test that is invalid in an HIV-positive patient; and one month is too short for conversion.",
     "The same error with better timing; it still hands the decision to an anergic test.",
     "Correct — the documented contact is solid evidence and the PPD is invalid in HIV; nine months of isoniazid.",
     "The most dangerous option; believing a negative PPD in someone who cannot produce a positive one."],
    "**در HIV، تماس مستند تصمیم می‌گیرد، نه تست پوستی — چون تست، ایمنی را می‌سنجد نه باکتری را.**",
    "In HIV the documented contact decides, not the skin test — because the test measures immunity, not bacteria.",
    REFS)

add("book:269", "recall", "medium",
    "**در تماس خانگی HIV مثبت: بدون توجه به نتیجه‌ی تست پوستی، پروفیلاکسی بدهید.**",
    "In an HIV-positive household contact: give prophylaxis regardless of the skin test result.",
    HIVC_FA, HIVC_EN,
    "این سؤال، همان قاعده را **مستقیم و بی‌پرده** می‌پرسد.\n\n"
    "**بیمار: مبتلا به HIV که مورد تماس خانگی با بیمار سل ریوی اسمیر مثبت بوده. "
    "معاینه و آزمایش‌ها شواهدی از سل فعال ندارند. براساس نتیجه‌ی تست پوستی "
    "توبرکولین، کدام اقدام صحیح است؟**\n\n"
    "**پاسخ: بدون توجه به نتیجه‌ی تست پوستی.**\n\n"
    "**سؤال خودش تله را ساخته:** سه گزینه، سه عدد پیشنهاد می‌کنند (۱۰، ۵، و ۱ "
    "میلی‌متر). **دانشجویی که جدول آستانه‌ها را حفظ کرده، وسوسه می‌شود عدد ۵ را "
    "انتخاب کند** — چون می‌داند آستانه‌ی HIV پنج میلی‌متر است.\n\n"
    "⚠️ **ولی این سؤال درباره‌ی آستانه نیست. درباره‌ی این است که آیا اصلاً به تست نگاه "
    "می‌کنیم یا نه.**\n\n"
    "**دو موقعیت را از هم جدا کنید — این تفکیک، کلید همه‌ی این خوشه است:**\n\n"
    "**موقعیت الف — بیمار HIV مثبت، بدون تماس مستند.** اینجا تست **به‌کار می‌آید**، و "
    "**آستانه‌اش ۵ میلی‌متر** است (پایین‌ترین آستانه‌ی جدول، تا حداکثر افراد عفونی شکار "
    "شوند).\n\n"
    "⚠️ **موقعیت ب — بیمار HIV مثبت، با تماس نزدیک مستند.** اینجا **تست کنار گذاشته "
    "می‌شود** و پروفیلاکسی **بدون قید و شرط** داده می‌شود.\n\n"
    "**چرا؟ سه دلیل که همگی در یک جهت‌اند:**\n\n"
    "**۱. تست در این بیمار غیرقابل اعتماد است** (آنرژی از تخریب CD4).\n\n"
    "**۲. احتمال پیش‌آزمون بسیار بالاست** — تماس خانگی با اسمیر مثبت، پرخطرترین نوع "
    "مواجهه است.\n\n"
    "**۳. هزینه‌ی دو خطا نامتقارن است:**\n\n"
    "**اگر بی‌جهت پروفیلاکسی بدهیم** ⇐ ۹ ماه ایزونیازید، با خطر کوچک هپاتیت (که "
    "قابل پایش است).\n\n"
    "**اگر به‌اشتباه ندهیم** ⇐ سل فعال در بیمار HIV مثبت، با **مرگ‌ومیر بالا** و **خطر "
    "انتقال به دیگران**.\n\n"
    "**در چنین عدم‌تقارنی، همیشه جانب درمان را می‌گیریم.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**اگر واکنش بیش از ۱۰ میلی‌متر باشد** — آستانه‌ی گروه با خطر متوسط. **در HIV، "
    "این آستانه بسیار بالاست** و بسیاری از افراد عفونی را از دست می‌دهد.\n\n"
    "⚠️ **اگر واکنش بیش از ۵ میلی‌متر باشد** — **گزینه‌ی فریبنده و نزدیک‌ترین به "
    "درست.** ۵ میلی‌متر **واقعاً** آستانه‌ی HIV است — **ولی فقط در نبود تماس مستند**. "
    "**وقتی تماس نزدیک ثابت شده، از آستانه هم عبور می‌کنیم.**\n\n"
    "**با هر واکنشی به میزان یک میلی‌متر یا بیشتر** — عملاً یعنی «هر تستی که صفر "
    "نباشد». این **معیار ساختگی است و در هیچ راهنمایی وجود ندارد**، و ضمناً "
    "**بیمار با تست صفر را — که دقیقاً همان بیمار آنرژیک پرخطر است — کنار "
    "می‌گذارد.**",
    "This question asks the same rule DIRECTLY AND BLUNTLY.\n\n"
    "THE PATIENT: an HIV-positive person who has been a household contact of a smear-positive tuberculosis case. Examination and tests show no evidence of active disease. Based on the tuberculin skin test result, what is correct?\n\n"
    "THE ANSWER: REGARDLESS OF THE SKIN TEST RESULT.\n\n"
    "THE QUESTION HAS BUILT ITS OWN TRAP: three options propose three numbers (10, 5 and 1 mm). A STUDENT WHO HAS MEMORISED THE THRESHOLD TABLE IS TEMPTED TO PICK 5 — because he knows the HIV threshold is five millimetres.\n\n"
    "WARNING: BUT THIS QUESTION IS NOT ABOUT THE THRESHOLD. IT IS ABOUT WHETHER WE LOOK AT THE TEST AT ALL.\n\n"
    "SEPARATE TWO SITUATIONS — THIS DISTINCTION IS THE KEY TO THE WHOLE CLUSTER:\n\n"
    "SITUATION A — AN HIV-POSITIVE PATIENT WITHOUT DOCUMENTED CONTACT. Here the test IS used, and ITS THRESHOLD IS 5 MM (the lowest in the table, to catch as many infected people as possible).\n\n"
    "WARNING: SITUATION B — AN HIV-POSITIVE PATIENT WITH DOCUMENTED CLOSE CONTACT. Here THE TEST IS SET ASIDE and prophylaxis is given UNCONDITIONALLY.\n\n"
    "WHY? THREE REASONS POINTING THE SAME WAY:\n\n"
    "1. THE TEST IS UNRELIABLE IN THIS PATIENT (anergy from CD4 destruction).\n\n"
    "2. THE PRE-TEST PROBABILITY IS VERY HIGH — household contact with a smear-positive case is the highest-risk exposure there is.\n\n"
    "3. THE COSTS OF THE TWO ERRORS ARE ASYMMETRIC:\n\n"
    "GIVING PROPHYLAXIS UNNECESSARILY — nine months of isoniazid with a small, monitorable risk of hepatitis.\n\n"
    "WITHHOLDING IT WRONGLY — active tuberculosis in an HIV-positive patient, with HIGH MORTALITY and ONWARD TRANSMISSION.\n\n"
    "WITH THAT ASYMMETRY, WE ALWAYS ERR TOWARDS TREATING.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "'IF THE REACTION EXCEEDS 10 MM' — the intermediate-risk threshold. IN HIV THAT BAR IS FAR TOO HIGH and would miss many infected people.\n\n"
    "WARNING: 'IF THE REACTION EXCEEDS 5 MM' — THE SEDUCTIVE OPTION AND THE CLOSEST TO RIGHT. Five millimetres IS genuinely the HIV threshold — BUT ONLY IN THE ABSENCE OF DOCUMENTED CONTACT. ONCE CLOSE CONTACT IS ESTABLISHED WE GO PAST THE THRESHOLD ALTOGETHER.\n\n"
    "'WITH ANY REACTION OF ONE MILLIMETRE OR MORE' — effectively 'any test that is not zero'. THIS IS AN INVENTED CRITERION FOUND IN NO GUIDELINE, and it also EXCLUDES THE PATIENT WITH A ZERO TEST — who is precisely the high-risk anergic patient.",
    ["آستانه‌ی گروه با خطر متوسط است؛ در HIV بسیار بالاست و بیماران عفونی را از دست می‌دهد.",
     "آستانه‌ی درست HIV است، ولی فقط در نبود تماس مستند؛ با تماس ثابت‌شده از آستانه عبور می‌کنیم.",
     "معیار ساختگی است و در هیچ راهنمایی وجود ندارد؛ ضمناً بیمار آنرژیک را کنار می‌گذارد.",
     "پاسخ صحیح — با تماس مستند در HIV، تست کنار گذاشته و پروفیلاکسی بدون قید داده می‌شود."],
    ["The intermediate-risk threshold; far too high in HIV and it would miss infected patients.",
     "The correct HIV threshold, but only without documented contact; proven contact takes us past the threshold.",
     "An invented criterion found in no guideline, and it excludes the anergic patient.",
     "Correct — with documented contact in HIV the test is set aside and prophylaxis is given unconditionally."],
    "**بدون تماس، آستانه پنج است؛ با تماس مستند، اصلاً به تست نگاه نمی‌کنیم.**",
    "Without contact the threshold is five; with documented contact we do not look at the test at all.",
    REFS)

add("book:270", "vignette", "medium",
    "**زندانی HIV مثبت با گرافی نرمال و PPD منفی: ایزونیازید نه ماه تمام.**",
    "An HIV-positive prisoner with a normal film and a negative PPD: a full nine months of isoniazid.",
    HIVC_FA + [
        "⚠️ **زندان خودش یک عامل خطر مستقل و بزرگ است.**",
        "**ازدحام، تهویه‌ی ضعیف، و شیوع سل چند برابر جامعه.**",
    ],
    HIVC_EN + [
        "WARNING: PRISON IS ITSELF A LARGE INDEPENDENT RISK FACTOR.",
        "Overcrowding, poor ventilation, and a tuberculosis prevalence many times that of the community.",
    ],
    "این سؤال، همان قاعده را با **دو عامل خطر روی هم** می‌آزماید.\n\n"
    "**بیمار: مرد ۲۵ ساله HIV مثبت، بدون علائم ریوی، از زندان جهت مشاوره آورده شده. "
    "در شرح حال، بیمار مبتلا به سل ریوی اسمیر خلط مثبت با وی هم‌بند بوده. گرافی "
    "قفسه‌ی صدری نرمال و تست PPD منفی گزارش شده است.**\n\n"
    "**پاسخ: شروع ایزونیازید و ادامه‌ی آن به‌مدت ۹ ماه تمام.**\n\n"
    "**دو عامل خطر بزرگ روی هم انباشته شده‌اند:**\n\n"
    "**عامل اول — HIV.** خطر تبدیل نهفته به فعال، حدود **۱۰٪ در هر سال**.\n\n"
    "⚠️ **عامل دوم — زندان.** یکی از پرخطرترین محیط‌های سل در جهان: **ازدحام شدید، "
    "تهویه‌ی ناکافی، سوءتغذیه، تأخیر در تشخیص، و شیوع سل ده‌ها برابر جامعه‌ی "
    "عمومی**. و **هم‌بند بودن** یعنی نزدیک‌ترین و طولانی‌ترین نوع تماس ممکن.\n\n"
    "**حالا دو یافته‌ی «آرام‌بخش» را بررسی کنیم — چون هر دو فریبنده‌اند:**\n\n"
    "**«گرافی قفسه‌ی صدری نرمال»** — این خوب است و **سل فعال را کم‌احتمال می‌کند**، پس "
    "شرط لازم برای دادن پروفیلاکسی برآورده شده. ⚠️ **ولی توجه: در بیمار HIV مثبت با "
    "CD4 پایین، گرافی طبیعی سل فعال را کاملاً رد نمی‌کند** — چون تابلوی رادیولوژیک "
    "در نقص ایمنی محو می‌شود. **در عمل، اگر هر علامتی باشد، اسمیر خلط هم لازم است.** "
    "(اینجا بیمار «بدون علائم ریوی» است، پس قابل قبول است.)\n\n"
    "**«تست PPD منفی»** — همان‌طور که می‌دانیم، **در HIV بی‌ارزش است**. آنرژی.\n\n"
    "**پس: تماس بسیار نزدیک ✔ · نقص ایمنی شدید ✔ · سل فعال رد شده ✔ · تست بی‌اعتبار "
    "✔ ⇐ پروفیلاکسی کامل ۹ ماهه.**\n\n"
    "⚠️ **و کلمه‌ی «تمام» در گزینه‌ی صحیح، عمدی و مهم است.** یعنی **دوره را کامل کنید "
    "و در میانه بر اساس تست دوباره تصمیم نگیرید**. این دقیقاً همان چیزی است که "
    "گزینه‌ی رقیب پیشنهاد می‌کند و اشتباه است.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "⚠️ **نیاز به اقدام خاصی نیست و توصیه به پیگیری** — **خطرناک‌ترین گزینه.** "
    "**«پیگیری» در بیماری با ۱۰٪ خطر سالانه یعنی منتظر ماندن تا بیمار شود.** "
    "و در زندان، بیمار شدنِ او یعنی **شیوع در کل بند**.\n\n"
    "**شروع ایزونیازید و تکرار PPD سه ماه بعد** — نیمه‌درست: شروع دارو خوب است، ولی "
    "**سپردن ادامه‌ی تصمیم به تستی که در این بیمار کار نمی‌کند، غلط است**. اگر تست "
    "سه ماه بعد باز هم منفی باشد (که در آنرژی محتمل است)، آیا دارو را قطع می‌کنید؟ "
    "**قطع کردن، بیمار را در معرض همان خطر اولیه می‌گذارد.**\n\n"
    "**شروع ریفامپین و ادامه به‌مدت ۶ ماه تمام** — ⚠️ **گزینه‌ی ظریف.** رژیم "
    "**ریفامپین ۴ ماهه (4R)** امروز یکی از رژیم‌های ترجیحی درمان عفونت نهفته است. "
    "**ولی دو مشکل:** اول، **۶ ماه ریفامپین** رژیم استانداردی نیست (۴ ماه است). "
    "دوم و مهم‌تر، **ریفامپین با داروهای ضدرتروویروسی تداخل شدید دارد** — سطح "
    "مهارکننده‌های پروتئاز را به‌شدت پایین می‌آورد و می‌تواند **درمان HIV را شکست "
    "دهد**. (به همین دلیل در بیماران HIV مثبت، **ریفابوتین** جایگزین می‌شود.)",
    "This question tests the same rule with TWO RISK FACTORS STACKED.\n\n"
    "THE PATIENT: a 25-year-old HIV-positive man with no respiratory symptoms, brought from prison for advice. His history reveals that a smear-positive tuberculosis patient SHARED HIS CELL. His chest radiograph is normal and his PPD is negative.\n\n"
    "THE ANSWER: START ISONIAZID AND CONTINUE IT FOR A FULL NINE MONTHS.\n\n"
    "TWO LARGE RISK FACTORS ARE STACKED HERE:\n\n"
    "FACTOR ONE — HIV. A reactivation risk of about 10 % PER YEAR.\n\n"
    "WARNING, FACTOR TWO — PRISON. One of the highest-risk tuberculosis environments in the world: SEVERE OVERCROWDING, POOR VENTILATION, MALNUTRITION, DELAYED DIAGNOSIS, and a prevalence many times that of the general community. And SHARING A CELL means the closest and most prolonged contact possible.\n\n"
    "NOW EXAMINE THE TWO 'REASSURING' FINDINGS — BECAUSE BOTH ARE DECEPTIVE:\n\n"
    "'A NORMAL CHEST RADIOGRAPH' — good, and it MAKES ACTIVE DISEASE UNLIKELY, so the precondition for giving prophylaxis is met. WARNING, BUT NOTE: IN AN HIV-POSITIVE PATIENT WITH A LOW CD4 COUNT, A NORMAL FILM DOES NOT WHOLLY EXCLUDE ACTIVE DISEASE, because the radiological picture fades with immunodeficiency. IN PRACTICE, IF ANY SYMPTOM EXISTS, A SPUTUM SMEAR IS ALSO REQUIRED. (Here he is explicitly asymptomatic, so this is acceptable.)\n\n"
    "'A NEGATIVE PPD' — as we know, WORTHLESS IN HIV. Anergy.\n\n"
    "SO: very close contact, severe immunodeficiency, active disease excluded, and an invalid test — A FULL NINE-MONTH COURSE OF PROPHYLAXIS.\n\n"
    "WARNING: AND THE WORD 'FULL' IN THE CORRECT OPTION IS DELIBERATE AND IMPORTANT. It means COMPLETE THE COURSE AND DO NOT REOPEN THE DECISION MID-WAY ON THE BASIS OF A REPEAT TEST. That is exactly what the rival option proposes, and it is wrong.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "WARNING: 'NOTHING SPECIFIC IS NEEDED, JUST FOLLOW HIM UP' — THE MOST DANGEROUS OPTION. 'FOLLOW-UP' IN A PATIENT WITH A 10 % ANNUAL RISK MEANS WAITING FOR HIM TO FALL ILL. And in prison his falling ill means AN OUTBREAK ON THE WHOLE WING.\n\n"
    "'START ISONIAZID AND REPEAT THE PPD IN THREE MONTHS' — half right: starting the drug is good, but HANDING THE REST OF THE DECISION TO A TEST THAT DOES NOT WORK IN THIS PATIENT IS WRONG. If the test is negative again in three months (likely with anergy), do you stop the drug? STOPPING RETURNS HIM TO HIS ORIGINAL RISK.\n\n"
    "'START RIFAMPICIN AND CONTINUE FOR A FULL SIX MONTHS' — WARNING, A SUBTLE OPTION. FOUR MONTHS OF RIFAMPICIN (4R) is today one of the preferred latent-infection regimens. BUT THERE ARE TWO PROBLEMS: first, SIX months of rifampicin is not a standard regimen (it is four). Second and more important, RIFAMPICIN INTERACTS SEVERELY WITH ANTIRETROVIRAL DRUGS — it drives protease inhibitor levels down and can CAUSE HIV TREATMENT FAILURE. (Which is why RIFABUTIN is substituted in HIV-positive patients.)",
    ["خطرناک‌ترین گزینه؛ «پیگیری» در بیمار با ۱۰٪ خطر سالانه یعنی منتظر ماندن تا بیمار شود.",
     "شروع دارو خوب است ولی سپردن ادامه‌ی تصمیم به تستی که در HIV کار نمی‌کند، غلط است.",
     "پاسخ صحیح — تماس بسیار نزدیک، نقص ایمنی شدید، تست بی‌اعتبار؛ نه ماه کامل ایزونیازید.",
     "شش ماه ریفامپین رژیم استاندارد نیست، و ریفامپین با داروهای ضدرتروویروسی تداخل شدید دارد."],
    ["The most dangerous option; 'follow-up' in a patient with a 10 % annual risk means waiting for disease.",
     "Starting the drug is right, but handing the rest of the decision to a test that fails in HIV is wrong.",
     "Correct — very close contact, severe immunodeficiency and an invalid test; a full nine months of isoniazid.",
     "Six months of rifampicin is not a standard regimen, and rifampicin interacts severely with antiretrovirals."],
    "**«تمام» یعنی دوره را کامل کن و تصمیم را با تستی که کار نمی‌کند بازنکن.**",
    "'Full' means finish the course and do not reopen the decision with a test that does not work.",
    REFS)

add("book:271", "vignette", "medium",
    "**HIV مثبت با PPD پنج میلی‌متر و تماس اخیر: ایزونیازید نه ماه.**",
    "HIV-positive with a 5 mm PPD and recent contact: nine months of isoniazid.",
    HIVC_FA, HIVC_EN,
    "این سؤال، نسخه‌ی **مثبت** همان قاعده است: قبلی‌ها PPD منفی داشتند، این یکی "
    "PPD مثبت دارد — **و پاسخ همان است.** و همین نکته‌ی آموزشی است.\n\n"
    "**بیمار: آقای جوان HIV مثبت که اخیراً با بیمار سل ریوی اسمیر مثبت تماس نزدیک "
    "داشته. PPD به اندازه‌ی ۵ میلی‌متر. آزمایش خلط منفی و رادیوگرافی قفسه‌ی سینه "
    "نرمال.**\n\n"
    "**پاسخ: درمان با ایزونیازید به‌مدت ۹ ماه.**\n\n"
    "**اول، تفسیر عدد ۵ میلی‌متر:**\n\n"
    "**در فرد عادی، ۵ میلی‌متر منفی است.** ولی **در HIV، آستانه ۵ میلی‌متر است** — پس "
    "این تست **مثبت** محسوب می‌شود.\n\n"
    "⚠️ **و در واقع، این بیمار دو دلیل مستقل برای آستانه‌ی ۵ دارد:** هم **HIV مثبت** "
    "است و هم **تماس نزدیک و اخیر** — و هر دو در گروه آستانه‌ی ۵ میلی‌متر قرار "
    "دارند. **پس با هر دو معیار، تست مثبت است.**\n\n"
    "**دوم، رد کردن سل فعال:**\n\n"
    "**آزمایش خلط منفی ✔ · رادیوگرافی نرمال ✔ · و سؤال هم علامتی ذکر نکرده.** پس "
    "**سل فعال رد شده** و شرط لازم برای پروفیلاکسی برآورده است.\n\n"
    "**سوم، درمان: ایزونیازید ۹ ماه.**\n\n"
    "**چرا ۹ ماه و نه ۶ ماه؟** در بیماران HIV مثبت، رژیم ۹ ماهه به‌طور سنتی ترجیح "
    "داشته، چون **کارآیی محافظتی بیشتری نشان داده** و در گروهی که خطرش ده برابر "
    "است، این تفاوت ارزش دارد.\n\n"
    "⚠️ **نکته‌ی آموزشی مهم این خوشه: چهار سؤال پشت‌سرهم، همه یک پاسخ دارند.**\n\n"
    "**هم‌خانه‌ی HIV مثبت با PPD منفی ⇐ ایزونیازید ۹ ماه**\n\n"
    "**تماس خانگی HIV مثبت با هر نتیجه‌ای ⇐ پروفیلاکسی**\n\n"
    "**زندانی HIV مثبت با PPD منفی ⇐ ایزونیازید ۹ ماه**\n\n"
    "**و این بیمار، با PPD مثبت (۵ میلی‌متر) ⇐ باز هم ایزونیازید ۹ ماه**\n\n"
    "**و این تکرار، خودش پیام دارد: در بیمار HIV مثبتِ در تماس، عدد تست تصمیم را "
    "عوض نمی‌کند. یاد بگیرید قاعده را، نه عددها را.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "⚠️ **درمان چهاردارویی ضدسل به‌مدت ۶ ماه** — **درمان بیماری فعال، نه پیشگیری.** این "
    "بیمار **بیماری فعال ندارد** (خلط منفی، گرافی نرمال). **درمان بیش از حد یعنی "
    "قرار دادن او در معرض سمّیت چهار دارو — به‌ویژه در بیماری که هم‌زمان داروهای "
    "ضدرتروویروسی می‌گیرد و بار دارویی کبدش بالاست.**\n\n"
    "**درمان با ریفامپین به‌مدت ۲ ماه** — ⚠️ **رژیم منسوخ و خطرناک.** رژیم "
    "**ریفامپین + پیرازینامید ۲ ماهه** زمانی برای LTBI استفاده می‌شد، ولی "
    "**به‌دلیل هپاتوتوکسیسیتی شدید و مرگ‌های گزارش‌شده، کنار گذاشته شد**. و "
    "ریفامپین تنها هم ۴ ماه لازم دارد، نه ۲.\n\n"
    "⚠️ **نیاز به اقدام خاص ندارد** — خطرناک. **PPD پنج میلی‌متر در بیمار HIV مثبت "
    "با تماس اخیر، قطعاً مثبت است.** رها کردن این بیمار یعنی پذیرفتن خطر ۱۰٪ "
    "سالانه‌ی سل فعال.",
    "This question is the POSITIVE version of the same rule: the previous patients had negative PPDs, this one has a positive PPD — AND THE ANSWER IS THE SAME. That is the teaching point.\n\n"
    "THE PATIENT: a young HIV-positive man who has recently had close contact with a smear-positive tuberculosis case. His PPD measures 5 MM. Sputum examination is negative and the chest radiograph is normal.\n\n"
    "THE ANSWER: ISONIAZID FOR NINE MONTHS.\n\n"
    "FIRST, INTERPRET THE 5 MM:\n\n"
    "IN AN ORDINARY PERSON 5 MM IS NEGATIVE. But IN HIV THE THRESHOLD IS 5 MM — so this test counts as POSITIVE.\n\n"
    "WARNING: AND IN FACT THIS PATIENT HAS TWO INDEPENDENT REASONS FOR THE 5 MM THRESHOLD: he is HIV-POSITIVE and he is a RECENT CLOSE CONTACT — both of which sit in the 5 mm group. SO BY EITHER CRITERION THE TEST IS POSITIVE.\n\n"
    "SECOND, EXCLUDE ACTIVE DISEASE:\n\n"
    "Sputum negative, radiograph normal, and no symptoms mentioned. SO ACTIVE DISEASE IS EXCLUDED and the precondition for prophylaxis is met.\n\n"
    "THIRD, THE TREATMENT: NINE MONTHS OF ISONIAZID.\n\n"
    "WHY NINE RATHER THAN SIX? In HIV-positive patients the nine-month regimen has traditionally been preferred because it showed GREATER PROTECTIVE EFFICACY, and in a group whose risk is tenfold that difference is worth having.\n\n"
    "WARNING, THE IMPORTANT TEACHING POINT OF THIS CLUSTER: FOUR CONSECUTIVE QUESTIONS ALL HAVE THE SAME ANSWER.\n\n"
    "The HIV-positive household contact with a NEGATIVE PPD: nine months of isoniazid. The HIV-positive household contact with ANY result: prophylaxis. The HIV-positive prisoner with a NEGATIVE PPD: nine months of isoniazid. And this patient, with a POSITIVE PPD of 5 mm: nine months of isoniazid again.\n\n"
    "AND THAT REPETITION CARRIES ITS OWN MESSAGE: IN AN HIV-POSITIVE CONTACT, THE NUMBER ON THE TEST DOES NOT CHANGE THE DECISION. LEARN THE RULE, NOT THE NUMBERS.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "WARNING: FOUR-DRUG ANTITUBERCULOUS TREATMENT FOR SIX MONTHS — THAT IS TREATMENT OF ACTIVE DISEASE, NOT PREVENTION. This patient HAS NO ACTIVE DISEASE (negative sputum, normal film). OVER-TREATMENT EXPOSES HIM TO FOUR DRUGS' TOXICITY — especially in a patient simultaneously taking antiretrovirals with an already heavy hepatic drug load.\n\n"
    "RIFAMPICIN FOR TWO MONTHS — WARNING, AN OBSOLETE AND DANGEROUS REGIMEN. The two-month RIFAMPICIN PLUS PYRAZINAMIDE regimen was once used for latent infection but WAS ABANDONED BECAUSE OF SEVERE HEPATOTOXICITY AND REPORTED DEATHS. And rifampicin alone requires four months, not two.\n\n"
    "WARNING: 'NO SPECIFIC ACTION NEEDED' — dangerous. A 5 MM PPD IN AN HIV-POSITIVE RECENT CONTACT IS DEFINITELY POSITIVE. Leaving this patient means accepting a 10 % annual risk of active tuberculosis.",
    ["درمان بیماری فعال است، نه پیشگیری؛ این بیمار خلط منفی و گرافی نرمال دارد.",
     "پاسخ صحیح — پنج میلی‌متر در HIV مثبت است، سل فعال رد شده، پس ایزونیازید نه ماه.",
     "رژیم منسوخ؛ ریفامپین-پیرازینامید دوماهه به‌دلیل هپاتوتوکسیسیتی کنار گذاشته شد.",
     "خطرناک؛ پنج میلی‌متر در HIV مثبت با تماس اخیر قطعاً مثبت است و درمان می‌خواهد."],
    ["That is treatment of active disease, not prevention; this patient has a negative sputum and a normal film.",
     "Correct — 5 mm is positive in HIV, active disease is excluded, so nine months of isoniazid.",
     "An obsolete regimen; two-month rifampicin-pyrazinamide was abandoned for hepatotoxicity.",
     "Dangerous; 5 mm in an HIV-positive recent contact is definitely positive and requires treatment."],
    "**قاعده را یاد بگیرید نه عدد را — در تماسِ HIV مثبت، پاسخ همیشه پروفیلاکسی است.**",
    "Learn the rule, not the number — in an HIV-positive contact the answer is always prophylaxis.",
    REFS)

add("book:264", "recall", "medium",
    "**HIV مثبت با PPD هفت میلی‌متر و بدون علامت: ایزونیازید نه ماه.**",
    "HIV-positive with a 7 mm PPD and no symptoms: nine months of isoniazid.",
    HIVC_FA + [
        "⚠️ **آستانه‌ی HIV پنج میلی‌متر است — پایین‌ترین آستانه‌ی جدول.**",
        "**پس هر عددی از پنج بالاتر، در HIV مثبت است.**",
    ],
    HIVC_EN + [
        "WARNING: THE HIV THRESHOLD IS FIVE MILLIMETRES — the lowest in the table.",
        "So any figure above five is positive in an HIV-positive patient.",
    ],
    "این سؤال، مورد **بدون تماس مستند** را می‌سنجد — یعنی جایی که **تست واقعاً "
    "تصمیم‌ساز است**.\n\n"
    "**بیمار: مبتلا به HIV با تست پوستی سل مثبت، اندوراسیون ۷ میلی‌متر. سرفه، تب، "
    "عرق شبانه و کاهش وزن را ذکر نمی‌کند.**\n\n"
    "**پاسخ: ایزونیازید برای مدت نه ماه.**\n\n"
    "**سه گام، و هر گام یک درس:**\n\n"
    "**گام یک — آیا ۷ میلی‌متر مثبت است؟**\n\n"
    "**در فرد بدون عامل خطر، ۷ میلی‌متر منفی است** (آستانه ۱۵). **در گروه با خطر "
    "متوسط هم منفی است** (آستانه ۱۰). ⚠️ **ولی در HIV، آستانه ۵ میلی‌متر است — پس "
    "۷ میلی‌متر مثبت است.**\n\n"
    "**چرا آستانه‌ی HIV این‌قدر پایین گذاشته شده؟** یک تصمیم عمدی و آگاهانه است: "
    "**در گروهی که پاسخ ایمنی‌اش ضعیف است، تست به‌طور طبیعی اندوراسیون کوچک‌تری "
    "می‌سازد.** اگر آستانه‌ی ۱۰ یا ۱۵ را به‌کار ببریم، **بسیاری از افراد واقعاً عفونی "
    "را از دست می‌دهیم** — و در گروهی که خطر مرگش بالاست، این خطای غیرقابل قبول "
    "است. **پس حساسیت را بر ویژگی ترجیح می‌دهیم.**\n\n"
    "**گام دو — آیا سل فعال دارد؟**\n\n"
    "**سؤال صراحتاً می‌گوید سرفه، تب، عرق شبانه و کاهش وزن را ذکر نمی‌کند.** این "
    "چهار مورد، **دقیقاً همان چهار سؤال غربالگری علامتی سازمان جهانی بهداشت برای "
    "سل در بیماران HIV مثبت است.**\n\n"
    "⚠️ **این ابزار (WHO four-symptom screen) بسیار مهم است: اگر هر چهار پاسخ منفی "
    "باشد، احتمال سل فعال بسیار پایین است و می‌توان با اطمینان معقول پروفیلاکسی "
    "شروع کرد.** سؤال به‌طور هوشمندانه هر چهار را رد کرده.\n\n"
    "**گام سه — درمان: ایزونیازید ۹ ماه.**\n\n"
    "**به‌همراه پیریدوکسین، چون بیماران HIV مثبت خطر نوروپاتی بیشتری دارند.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "⚠️ **ریفامپین و پیرازینامید برای دو ماه** — **رژیم منسوخ و خطرناک.** این رژیم "
    "زمانی برای درمان عفونت نهفته توصیه می‌شد، ولی **CDC آن را کنار گذاشت** پس از "
    "گزارش‌های **هپاتیت شدید و مرگ**. **امروز در هیچ راهنمایی توصیه نمی‌شود.**\n\n"
    "**ریفامپین برای سه ماه** — رژیم **ریفامپین تنها** وجود دارد، ولی **۴ ماه** است "
    "نه ۳. ⚠️ **و در بیمار HIV مثبت، تداخل ریفامپین با داروهای ضدرتروویروسی مشکل "
    "جدی است** (ریفابوتین جایگزین می‌شود).\n\n"
    "**اقدام خاصی نیاز ندارد** — نادرست. **۷ میلی‌متر در HIV مثبت است** و بیمار در "
    "پرخطرترین گروه پیشرفت قرار دارد.",
    "This question tests the case WITHOUT documented contact — that is, where THE TEST GENUINELY DECIDES.\n\n"
    "THE PATIENT: an HIV-positive person with a positive tuberculin test measuring 7 MM. He denies cough, fever, night sweats and weight loss.\n\n"
    "THE ANSWER: ISONIAZID FOR NINE MONTHS.\n\n"
    "THREE STEPS, EACH WITH A LESSON:\n\n"
    "STEP ONE — IS 7 MM POSITIVE?\n\n"
    "In a person with no risk factor, 7 mm is negative (threshold 15). In an intermediate-risk group it is also negative (threshold 10). WARNING: BUT IN HIV THE THRESHOLD IS 5 MM — SO 7 MM IS POSITIVE.\n\n"
    "WHY IS THE HIV THRESHOLD SET SO LOW? It is a deliberate, informed decision: IN A GROUP WHOSE IMMUNE RESPONSE IS WEAK, THE TEST NATURALLY PRODUCES A SMALLER INDURATION. Applying a 10 or 15 mm bar WOULD MISS MANY GENUINELY INFECTED PEOPLE — and in a group with high mortality that is an unacceptable error. SO WE PREFER SENSITIVITY OVER SPECIFICITY.\n\n"
    "STEP TWO — DOES HE HAVE ACTIVE DISEASE?\n\n"
    "The question explicitly states he denies cough, fever, night sweats and weight loss. THOSE FOUR ITEMS ARE EXACTLY THE WHO FOUR-SYMPTOM SCREEN FOR TUBERCULOSIS IN HIV-POSITIVE PATIENTS.\n\n"
    "WARNING: THAT TOOL MATTERS ENORMOUSLY — if all four are absent, the probability of active tuberculosis is very low and preventive therapy can be started with reasonable confidence. The question has cleverly excluded all four.\n\n"
    "STEP THREE — TREATMENT: NINE MONTHS OF ISONIAZID.\n\n"
    "With pyridoxine, since HIV-positive patients carry a higher neuropathy risk.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "WARNING: RIFAMPICIN AND PYRAZINAMIDE FOR TWO MONTHS — AN OBSOLETE AND DANGEROUS REGIMEN. It was once recommended for latent infection but CDC WITHDREW IT after reports of SEVERE HEPATITIS AND DEATHS. IT IS RECOMMENDED BY NO GUIDELINE TODAY.\n\n"
    "RIFAMPICIN FOR THREE MONTHS — a rifampicin-alone regimen does exist, but it is FOUR months, not three. WARNING, AND IN AN HIV-POSITIVE PATIENT THE RIFAMPICIN-ANTIRETROVIRAL INTERACTION IS A SERIOUS PROBLEM (rifabutin is substituted).\n\n"
    "'NO SPECIFIC ACTION NEEDED' — wrong. SEVEN MILLIMETRES IS POSITIVE IN HIV and the patient sits in the highest-risk group for progression.",
    ["پاسخ صحیح — آستانه‌ی HIV پنج میلی‌متر است، پس هفت میلی‌متر مثبت است؛ نه ماه ایزونیازید.",
     "رژیم منسوخ و خطرناک؛ به‌دلیل هپاتیت شدید و مرگ‌های گزارش‌شده کنار گذاشته شد.",
     "رژیم ریفامپین تنها چهار ماه است نه سه، و در HIV با ضدرتروویروسی‌ها تداخل شدید دارد.",
     "نادرست؛ هفت میلی‌متر در HIV مثبت است و بیمار در پرخطرترین گروه پیشرفت است."],
    ["Correct — the HIV threshold is 5 mm, so 7 mm is positive; nine months of isoniazid.",
     "An obsolete and dangerous regimen, withdrawn after reports of severe hepatitis and deaths.",
     "Rifampicin alone runs four months, not three, and in HIV it interacts severely with antiretrovirals.",
     "Wrong; 7 mm is positive in HIV and the patient is in the highest-risk group for progression."],
    "**در HIV، حساسیت را بر ویژگی ترجیح می‌دهیم — آستانه پنج، چون خطای منفی کاذب کشنده است.**",
    "In HIV we prefer sensitivity to specificity — a threshold of five, because a false negative kills.",
    REFS)

add("book:265", "recall", "medium",
    "**HIV مثبت با PPD پنج میلی‌متر و گرافی نرمال: پروفیلاکسی با ایزونیازید.**",
    "HIV-positive with a 5 mm PPD and a normal film: isoniazid prophylaxis.",
    HIVC_FA + [
        "⚠️ **پنج میلی‌متر در HIV دقیقاً روی آستانه است — یعنی مثبت.**",
        "**«مساوی یا بیشتر از پنج» مثبت است، نه «بیشتر از پنج».**",
    ],
    HIVC_EN + [
        "WARNING: FIVE MILLIMETRES IN HIV SITS EXACTLY ON THE THRESHOLD — meaning positive.",
        "The rule is 'five or more', not 'more than five'.",
    ],
    "این سؤال، همان مفهوم را با عددی می‌آزماید که **دقیقاً روی آستانه** است — و "
    "همین، تله‌ی ظریفش است.\n\n"
    "**بیمار: مبتلا به HIV با PPD = ۵ میلی‌متر. تب، تعریق شبانه و کاهش وزن را ذکر "
    "نمی‌کند. گرافی قفسه‌ی سینه نرمال است. اقدام بعدی؟**\n\n"
    "**پاسخ: پروفیلاکسی با ایزونیازید به‌مدت ۶ تا ۹ ماه.**\n\n"
    "⚠️ **نکته‌ی ظریف اول: قاعده «مساوی یا بیشتر از ۵ میلی‌متر» است، نه «بیشتر از ۵».** "
    "پس **۵ میلی‌متر دقیقاً مثبت است**، نه مرزی و نه منفی. **دانشجویانی که این را "
    "«درست روی خط، پس نامشخص» تفسیر می‌کنند، پاسخ را از دست می‌دهند.**\n\n"
    "**نکته‌ی دوم: دو شرط لازم برای پروفیلاکسی، هر دو برآورده شده‌اند:**\n\n"
    "**شرط الف — تست مثبت است** ✔ (۵ میلی‌متر با آستانه‌ی HIV).\n\n"
    "**شرط ب — سل فعال رد شده است** ✔ — و اینجا **دو سطح غربالگری** انجام شده:\n\n"
    "**غربالگری علامتی:** تب، تعریق شبانه و کاهش وزن منفی است (بخشی از "
    "چهارسؤالی WHO).\n\n"
    "**غربالگری تصویری:** گرافی قفسه‌ی سینه نرمال است.\n\n"
    "**این ترکیب — بی‌علامتی به‌علاوه‌ی گرافی نرمال — استاندارد پذیرفته‌شده برای رد "
    "سل فعال پیش از شروع پروفیلاکسی در بیماران HIV مثبت است.**\n\n"
    "**نکته‌ی سوم: مدت ۶ تا ۹ ماه.** هر دو در راهنماها آمده‌اند؛ **۹ ماه به‌طور سنتی "
    "در HIV ترجیح داشته** ولی **۶ ماه هم مؤثر و پذیرفته‌شده است** (و نرخ تکمیل "
    "بهتری دارد).\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "⚠️ **شروع درمان چهاردارویی برعلیه سل** — **درمان بیماری فعال در بیماری که "
    "بیماری فعال ندارد.** بی‌علامت است و گرافی نرمال دارد. **چهار دارو یعنی "
    "چهار برابر خطر سمّیت، بدون هیچ سود اضافی** — و در بیماری که هم‌زمان درمان "
    "ضدرتروویروسی می‌گیرد، بار دارویی و خطر تداخل بسیار بالا می‌رود.\n\n"
    "⚠️ **نیاز به اقدامی جهت بیمار نیست** — **خطرناک، و مبتنی بر یک سوءبرداشت رایج:** "
    "«۵ میلی‌متر که خیلی کم است». **این تفسیر با آستانه‌ی عمومی (۱۵) در ذهن انجام "
    "می‌شود و بیمار HIV مثبت را در معرض ۱۰٪ خطر سالانه رها می‌کند.**\n\n"
    "**تکرار تست پوستی پس از سه ماه** — **تأخیر بی‌فایده.** تست **همین حالا مثبت "
    "است**؛ تکرارش چه چیزی را قرار است روشن کند؟ **و در این سه ماه، بیمار بدون "
    "محافظت می‌ماند.** (تکرار تست برای بیمار **منفی** در پنجره‌ی زمانی معنا دارد، نه "
    "برای بیمار مثبت.)",
    "This question tests the same concept with a figure that sits EXACTLY ON THE THRESHOLD — and that is its subtle trap.\n\n"
    "THE PATIENT: HIV-positive with a PPD of 5 MM. He denies fever, night sweats and weight loss. The chest radiograph is normal. Next step?\n\n"
    "THE ANSWER: ISONIAZID PROPHYLAXIS FOR 6 TO 9 MONTHS.\n\n"
    "WARNING, SUBTLE POINT ONE: THE RULE IS 'FIVE MILLIMETRES OR MORE', NOT 'MORE THAN FIVE'. So 5 MM IS DEFINITELY POSITIVE, neither borderline nor negative. STUDENTS WHO READ IT AS 'RIGHT ON THE LINE, THEREFORE UNCLEAR' LOSE THE ANSWER.\n\n"
    "POINT TWO: THE TWO PRECONDITIONS FOR PROPHYLAXIS ARE BOTH MET:\n\n"
    "CONDITION A — THE TEST IS POSITIVE (5 mm against the HIV threshold).\n\n"
    "CONDITION B — ACTIVE DISEASE IS EXCLUDED, and here at TWO LEVELS OF SCREENING:\n\n"
    "SYMPTOM SCREENING: fever, night sweats and weight loss are all absent (part of the WHO four-symptom screen).\n\n"
    "IMAGING SCREENING: the chest radiograph is normal.\n\n"
    "THAT COMBINATION — ASYMPTOMATIC PLUS A NORMAL FILM — IS THE ACCEPTED STANDARD FOR EXCLUDING ACTIVE DISEASE BEFORE STARTING PROPHYLAXIS IN HIV-POSITIVE PATIENTS.\n\n"
    "POINT THREE: THE DURATION OF 6 TO 9 MONTHS. Both appear in the guidelines; NINE MONTHS HAS TRADITIONALLY BEEN PREFERRED IN HIV, but SIX IS ALSO EFFECTIVE AND ACCEPTED (with a better completion rate).\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "WARNING: STARTING FOUR-DRUG ANTITUBERCULOUS TREATMENT — TREATING ACTIVE DISEASE IN A PATIENT WHO DOES NOT HAVE IT. He is asymptomatic with a normal film. FOUR DRUGS MEANS FOUR TIMES THE TOXICITY RISK FOR NO ADDED BENEFIT — and in a patient simultaneously on antiretrovirals the drug burden and interaction risk rise sharply.\n\n"
    "WARNING: 'NOTHING NEEDS TO BE DONE' — DANGEROUS, AND BASED ON A COMMON MISCONCEPTION: 'five millimetres is so small'. THAT READING APPLIES THE GENERAL THRESHOLD (15) IN ONE'S HEAD AND ABANDONS AN HIV-POSITIVE PATIENT TO A 10 % ANNUAL RISK.\n\n"
    "REPEATING THE SKIN TEST AFTER THREE MONTHS — A POINTLESS DELAY. THE TEST IS ALREADY POSITIVE; what would repeating it clarify? AND FOR THOSE THREE MONTHS THE PATIENT REMAINS UNPROTECTED. (Repeat testing is meaningful for a NEGATIVE patient inside the window period, not for a positive one.)",
    ["پاسخ صحیح — پنج میلی‌متر با آستانه‌ی HIV مثبت است و سل فعال با علامت و گرافی رد شده.",
     "درمان بیماری فعال در بیماری که بی‌علامت و با گرافی نرمال است؛ سمّیت بدون سود.",
     "خطرناک؛ تفسیر پنج میلی‌متر با آستانه‌ی عمومی، بیمار را با ۱۰٪ خطر سالانه رها می‌کند.",
     "تأخیر بی‌فایده؛ تست همین حالا مثبت است و سه ماه بیمار بدون محافظت می‌ماند."],
    ["Correct — 5 mm is positive against the HIV threshold and active disease is excluded by symptoms and film.",
     "Treating active disease in an asymptomatic patient with a normal film; toxicity without benefit.",
     "Dangerous; reading 5 mm against the general threshold abandons the patient to a 10 % annual risk.",
     "A pointless delay; the test is already positive and three months leave the patient unprotected."],
    "**قاعده «مساوی یا بیشتر از پنج» است — پنج میلی‌متر در HIV دقیقاً مثبت است.**",
    "The rule is 'five or more' — five millimetres in HIV is definitely positive.",
    REFS)

# ============================================ THE 12-WEEK WINDOW
WINDOW_FA = [
    "⚠️ **تست توبرکولین روز اول عفونت مثبت نمی‌شود.**",
    "**ساخته شدن پاسخ ازدیاد حساسیت تأخیری، دو تا دوازده هفته طول می‌کشد.**",
    "**این فاصله را «دوره‌ی پنجره» می‌نامند و دو موقعیت متفاوت می‌سازد.**",
    "**موقعیت یک: کمتر از دوازده هفته از آخرین تماس گذشته و تست منفی است.**",
    "⚠️ **این تست قابل اعتماد نیست — شاید فقط زود است.**",
    "**پس در افراد آسیب‌پذیر، پروفیلاکسی پنجره‌ای شروع و تست در هفته‌ی ۸ تا ۱۲ تکرار می‌شود.**",
    "**موقعیت دو: بیش از دوازده هفته از آخرین تماس گذشته و تست منفی است.**",
    "**زمان کافی برای تبدیل گذشته و تبدیل رخ نداده.**",
    "⚠️ **پس تست منفی واقعاً یعنی عفونت رخ نداده — و درمان لازم نیست.**",
    "**درس: پیش از تفسیر تست منفی، تاریخ آخرین تماس را بپرسید.**",
    "**در بزرگسال با ایمنی سالم، این تاریخ تصمیم را می‌سازد.**",
    "**ولی در HIV و در کودک زیر پنج سال، این قاعده کنار گذاشته می‌شود.**",
]
WINDOW_EN = [
    "WARNING: THE TUBERCULIN TEST DOES NOT TURN POSITIVE ON THE DAY OF INFECTION.",
    "Building the delayed hypersensitivity response takes TWO TO TWELVE WEEKS.",
    "That interval is called the WINDOW PERIOD, and it creates two different situations.",
    "SITUATION ONE: fewer than twelve weeks since the last exposure, and the test is negative.",
    "WARNING: THAT TEST CANNOT BE TRUSTED — it may simply be too early.",
    "So in vulnerable people window prophylaxis is started and the test repeated at 8 to 12 weeks.",
    "SITUATION TWO: more than twelve weeks since the last exposure, and the test is negative.",
    "Enough time has passed for conversion, and conversion has not happened.",
    "WARNING: SO THE NEGATIVE TEST GENUINELY MEANS NO INFECTION — and no treatment is needed.",
    "The lesson: before interpreting a negative test, ask the date of the last exposure.",
    "In an immunocompetent adult that date makes the decision.",
    "But in HIV, and in a child under five, this rule is set aside.",
]

add("book:281", "vignette", "hard",
    "**دیابتی با PPD سه میلی‌متر: اگر بیش از ۱۲ هفته از تماس گذشته، درمان لازم نیست.**",
    "A diabetic with a 3 mm PPD: if more than 12 weeks have passed since exposure, no treatment is needed.",
    WINDOW_FA, WINDOW_EN,
    "این سخت‌ترین سؤال این خوشه است، چون **مفهومی را می‌سنجد که در جدول آستانه‌ها "
    "نیست: زمان.**\n\n"
    "**بیمار: مریض ۵۵ ساله دیابتی که اخیراً با یک فرد مبتلا به سل ریوی اسمیر خلط "
    "مثبت در زندان هم‌بند بوده. بیمار هیچ علامت ریوی ندارد. CXR طبیعی. PPD = ۳ "
    "میلی‌متر.**\n\n"
    "**پاسخ: اگر از آخرین تماس این فرد با بیمار مسلول بیش از ۱۲ هفته گذشته باشد، "
    "درمان با ایزونیازید نیاز نیست.**\n\n"
    "⚠️ **کلید سؤال، «دوره‌ی پنجره» است — مفهومی که همه‌ی گزینه‌های دیگر آن را نادیده "
    "می‌گیرند.**\n\n"
    "**تست توبرکولین روز اول عفونت مثبت نمی‌شود.** پس از ورود باسیل، بدن باید:\n\n"
    "**آنتی‌ژن را پردازش کند** ⇐ **لنفوسیت T اختصاصی بسازد** ⇐ **جمعیت حافظه ایجاد "
    "کند**\n\n"
    "**این فرآیند دو تا دوازده هفته طول می‌کشد.** در این فاصله، **فرد عفونی است ولی "
    "تستش منفی است** — همان «دوره‌ی پنجره».\n\n"
    "**پس یک تست منفی، دو معنای کاملاً متفاوت می‌تواند داشته باشد:**\n\n"
    "**الف) عفونتی رخ نداده** ✔\n\n"
    "**ب) عفونت رخ داده ولی هنوز زود است** ✘\n\n"
    "⚠️ **و تنها چیزی که این دو را از هم جدا می‌کند، تاریخ آخرین تماس است.**\n\n"
    "**اگر کمتر از ۱۲ هفته گذشته باشد:** تست بی‌اعتبار است. در افراد آسیب‌پذیر "
    "**پروفیلاکسی پنجره‌ای** شروع می‌شود و **تست در هفته‌ی ۸ تا ۱۲ تکرار می‌گردد**.\n\n"
    "**اگر بیش از ۱۲ هفته گذشته باشد:** زمان کافی برای تبدیل گذشته و **تبدیل رخ "
    "نداده**. **پس تست منفی واقعاً منفی است و درمان لازم نیست.**\n\n"
    "**و درباره‌ی دیابت:** عامل خطر واقعی است (۲ تا ۴ برابر) و **آستانه‌اش ۱۰ "
    "میلی‌متر** است. **۳ میلی‌متر با هر آستانه‌ای منفی است.** ⚠️ **ولی دیابت — برخلاف "
    "HIV — آنرژی نمی‌سازد.** ایمنی سلولی دیابتی به‌قدری حفظ شده که **تست قابل اعتماد "
    "است**. **این تفاوت بنیادی با خوشه‌ی HIV است و دقیقاً چیزی است که سؤال می‌سنجد.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**به‌علت بیماری زمینه‌ای، ۶ ماه ایزونیازید** — **درمان بدون شاهد عفونت.** دیابت "
    "به‌تنهایی اندیکاسیون درمان عفونت نهفته نیست؛ **باید تست مثبت باشد.**\n\n"
    "⚠️ **تکرار تست سه ماه بعد و شروع اگر بیش از ۵ میلی‌متر شد** — **گزینه‌ی بسیار "
    "نزدیک و آموزنده.** تکرار تست، **مفهوماً درست** است (و اگر تماس اخیر بود، دقیقاً "
    "همین کار انجام می‌شد). **ولی دو ایراد دارد:** اول، **آستانه‌ی ۵ برای دیابتی "
    "نادرست است** — آستانه‌ی او **۱۰** است. دوم، **سؤال شرط زمانی را مطرح کرده** و "
    "اگر بیش از ۱۲ هفته گذشته باشد، تکرار لازم نیست.\n\n"
    "**نیازی به درمان ندارد و فقط هر ۶ ماه یک بار تا دو سال پیگیری** — **پیگیری "
    "منفعل طولانی**، بدون در نظر گرفتن پنجره‌ی زمانی. **اگر تماس اخیر بوده باشد، این "
    "بیمار می‌تواند در همین دو سال بیمار شود** — و پیگیری شش‌ماهه او را نجات "
    "نمی‌دهد.",
    "This is the hardest question in the cluster, because it tests A CONCEPT ABSENT FROM THE THRESHOLD TABLE: TIME.\n\n"
    "THE PATIENT: a 55-year-old diabetic who recently shared a prison cell with a smear-positive tuberculosis case. He has no respiratory symptoms. His chest film is normal. His PPD is 3 MM.\n\n"
    "THE ANSWER: IF MORE THAN 12 WEEKS HAVE PASSED SINCE HIS LAST CONTACT, ISONIAZID IS NOT NEEDED.\n\n"
    "WARNING: THE KEY IS THE WINDOW PERIOD — a concept every other option ignores.\n\n"
    "THE TUBERCULIN TEST DOES NOT TURN POSITIVE ON THE DAY OF INFECTION. After the bacillus arrives, the body must PROCESS THE ANTIGEN, GENERATE SPECIFIC T LYMPHOCYTES, and BUILD A MEMORY POPULATION.\n\n"
    "THAT PROCESS TAKES TWO TO TWELVE WEEKS. During that interval THE PERSON IS INFECTED BUT THE TEST IS NEGATIVE — the window period.\n\n"
    "SO A NEGATIVE TEST CAN MEAN TWO COMPLETELY DIFFERENT THINGS:\n\n"
    "(a) no infection has occurred; or (b) infection has occurred but it is still too early.\n\n"
    "WARNING: AND THE ONLY THING THAT SEPARATES THE TWO IS THE DATE OF THE LAST EXPOSURE.\n\n"
    "IF FEWER THAN 12 WEEKS HAVE PASSED: the test is invalid. In vulnerable people WINDOW PROPHYLAXIS is started and THE TEST REPEATED AT 8 TO 12 WEEKS.\n\n"
    "IF MORE THAN 12 WEEKS HAVE PASSED: there has been enough time for conversion and CONVERSION HAS NOT OCCURRED. SO THE NEGATIVE TEST IS GENUINELY NEGATIVE AND NO TREATMENT IS NEEDED.\n\n"
    "AND ABOUT THE DIABETES: it is a real risk factor (2- to 4-fold) and ITS THRESHOLD IS 10 MM. Three millimetres is negative against any threshold. WARNING: BUT DIABETES — UNLIKE HIV — DOES NOT CAUSE ANERGY. Cell-mediated immunity in a diabetic is preserved enough that THE TEST IS RELIABLE. THAT IS THE FUNDAMENTAL DIFFERENCE FROM THE HIV CLUSTER AND EXACTLY WHAT THIS QUESTION TESTS.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "'BECAUSE OF THE UNDERLYING DISEASE, SIX MONTHS OF ISONIAZID' — TREATMENT WITHOUT EVIDENCE OF INFECTION. Diabetes alone is not an indication for latent-infection treatment; THE TEST MUST BE POSITIVE.\n\n"
    "WARNING: 'REPEAT THE TEST IN THREE MONTHS AND START IF IT EXCEEDS 5 MM' — A VERY CLOSE AND INSTRUCTIVE OPTION. Repeat testing is CONCEPTUALLY RIGHT (and if the contact were recent, that is exactly what one would do). BUT IT HAS TWO FAULTS: first, A 5 MM THRESHOLD IS WRONG FOR A DIABETIC — his threshold is 10. Second, THE QUESTION HAS POSED A TIME CONDITION, and if more than 12 weeks have passed no repeat is needed.\n\n"
    "'NO TREATMENT, JUST FOLLOW HIM UP EVERY SIX MONTHS FOR TWO YEARS' — PROLONGED PASSIVE FOLLOW-UP that ignores the window period. IF THE CONTACT WAS RECENT, THIS PATIENT COULD FALL ILL WITHIN THOSE VERY TWO YEARS — and six-monthly review will not save him.",
    ["درمان بدون شاهد عفونت؛ دیابت به‌تنهایی اندیکاسیون درمان عفونت نهفته نیست.",
     "تکرار تست مفهوماً درست است ولی آستانه‌ی دیابتی ۱۰ است نه ۵، و شرط زمانی نادیده گرفته شده.",
     "پاسخ صحیح — پس از ۱۲ هفته، تست منفی واقعاً منفی است و درمان لازم نیست.",
     "پیگیری منفعل طولانی بدون توجه به پنجره‌ی زمانی؛ اگر تماس اخیر بوده، بیمار را نجات نمی‌دهد."],
    ["Treatment without evidence of infection; diabetes alone is not an indication for latent treatment.",
     "Repeat testing is conceptually right, but a diabetic's threshold is 10 not 5, and the time condition is ignored.",
     "Correct — after 12 weeks a negative test is genuinely negative and no treatment is needed.",
     "Prolonged passive follow-up ignoring the window period; if the contact was recent it will not save him."],
    "**پیش از تفسیر تست منفی، تاریخ آخرین تماس را بپرسید — زمان، معنای تست را عوض می‌کند.**",
    "Before interpreting a negative test, ask the date of the last exposure — time changes what the test means.",
    REFSC)

add("book:282", "recall", "medium",
    "**همسر بی‌علامت بیمار مسلول: در کتاب، فقط توصیه به مراجعه در صورت بروز علائم.**",
    "The asymptomatic spouse of a tuberculosis patient: in the book, simply advise return if symptoms appear.",
    WINDOW_FA + [
        "⚠️ **در بزرگسال سالم و بی‌علامت، غربالگری تماس با شرح حال شروع می‌شود.**",
        "**و راهنماهای امروزی، غربالگری فعال تماس نزدیک را قوی‌تر توصیه می‌کنند.**",
    ],
    WINDOW_EN + [
        "WARNING: IN A HEALTHY ASYMPTOMATIC ADULT, CONTACT SCREENING BEGINS WITH THE HISTORY.",
        "And current guidance recommends active screening of close contacts more strongly.",
    ],
    "این سؤال، **محافظه‌کارانه‌ترین** پاسخ خوشه را دارد، و ارزشش در فهمیدن "
    "**چرایی** آن است — و در دانستن اینکه **راهنمای امروزی سخت‌گیرانه‌تر است**.\n\n"
    "**بیمار: آقای ۵۵ ساله مبتلا به سل ریوی اسمیر مثبت. جهت همسر ایشان که از هر "
    "جهت سالم است و اکنون نیز شکایتی ندارد، صحیح‌ترین اقدام کدام است؟**\n\n"
    "**کلید کتاب: صرفاً توصیه به مراجعه به پزشک در صورت بروز علائم.**\n\n"
    "**منطق کتاب:**\n\n"
    "**همسر یک بزرگسال با ایمنی سالم است** — نه HIV مثبت، نه دیابتی، نه تحت "
    "کورتون، نه کودک. **در چنین فردی، خطر پیشرفت به بیماری فعال حدود ۱۰٪ در تمام "
    "عمر است**، نه ۱۰٪ در سال.\n\n"
    "**و «از هر جهت سالم است و شکایتی ندارد»** یعنی **غربالگری علامتی منفی است**.\n\n"
    "**در چارچوب محدودیت منابع و اولویت‌بندی برنامه‌ی کشوری، این پاسخ توجیه دارد:** "
    "منابع محدود ابتدا به **پرخطرترین تماس‌ها** (کودکان زیر ۵ سال، HIV مثبت‌ها، "
    "افراد با نقص ایمنی) اختصاص می‌یابد.\n\n"
    "⚠️ **ولی آنچه امروز باید بدانید، و مهم است:**\n\n"
    "**راهنماهای فعلی سازمان جهانی بهداشت و CDC، غربالگری فعال تماس‌های خانگی را "
    "به‌مراتب قوی‌تر توصیه می‌کنند.** رویکرد امروزی برای همسر یک بیمار اسمیر مثبت:\n\n"
    "**۱. غربالگری علامتی** (سرفه، تب، تعریق شبانه، کاهش وزن).\n\n"
    "**۲. تست پوستی یا IGRA.**\n\n"
    "**۳. گرافی قفسه‌ی سینه در صورت مثبت بودن تست یا وجود علامت.**\n\n"
    "**۴. و در صورت اثبات عفونت نهفته و رد سل فعال، درمان پیشگیرانه.**\n\n"
    "**چرا این تغییر رخ داده؟** چون **تماس خانگی با اسمیر مثبت، یکی از پرخطرترین "
    "مواجهه‌هاست** — مطالعات نشان می‌دهند **۳۰ تا ۵۰٪ تماس‌های خانگی نزدیک عفونی "
    "می‌شوند** — و **درمان عفونت نهفته یکی از مقرون‌به‌صرفه‌ترین مداخلات بهداشت "
    "عمومی است**.\n\n"
    "**پس در امتحان کلید کتاب را بدهید؛ در بالین همسر را غربالگری کنید.**\n\n"
    "**چرا سه گزینه‌ی دیگر در چارچوب کتاب رد می‌شوند؟**\n\n"
    "**انجام تست پوستی سل** — در چارچوب کتاب، **برای بزرگسال سالم و بی‌علامت اولویت "
    "اول نیست**. (و یک مشکل عملی واقعی: در ایران با واکسیناسیون همگانی ب‌ث‌ژ و شیوع "
    "بالای عفونت نهفته، **تفسیر تست مثبت در بزرگسال دشوار است**.)\n\n"
    "**انجام گرافی ساده‌ی سینه** — **پرتو بدون اندیکاسیون**، در فرد کاملاً بی‌علامت.\n\n"
    "⚠️ **انجام آزمایش خلط از نظر اسیدفست** — **بی‌معناترین گزینه.** **این فرد اصلاً "
    "سرفه ندارد** — چه خلطی قرار است بدهد؟ آزمایش خلط برای فرد **علامت‌دار** است، نه "
    "برای غربالگری فرد بی‌علامت.",
    "This question carries the MOST CONSERVATIVE answer in the cluster, and its value lies in understanding WHY — and in knowing that CURRENT GUIDANCE IS STRICTER.\n\n"
    "THE PATIENT: a 55-year-old man with smear-positive pulmonary tuberculosis. What is the correct action for his wife, who is entirely healthy and has no complaints?\n\n"
    "THE BOOK'S KEY: SIMPLY ADVISE HER TO SEE A DOCTOR IF SYMPTOMS APPEAR.\n\n"
    "THE BOOK'S LOGIC:\n\n"
    "THE WIFE IS AN IMMUNOCOMPETENT ADULT — not HIV-positive, not diabetic, not on steroids, not a child. IN SUCH A PERSON THE RISK OF PROGRESSION IS ABOUT 10 % OVER A LIFETIME, not 10 % per year.\n\n"
    "AND 'entirely healthy with no complaints' means THE SYMPTOM SCREEN IS NEGATIVE.\n\n"
    "WITHIN THE RESOURCE CONSTRAINTS AND PRIORITIES OF A NATIONAL PROGRAMME, THIS ANSWER IS DEFENSIBLE: scarce resources go first to THE HIGHEST-RISK CONTACTS (children under five, HIV-positive people, the immunosuppressed).\n\n"
    "WARNING, BUT HERE IS WHAT YOU MUST KNOW TODAY, AND IT MATTERS:\n\n"
    "CURRENT WHO AND CDC GUIDANCE RECOMMENDS ACTIVE SCREENING OF HOUSEHOLD CONTACTS FAR MORE STRONGLY. The contemporary approach for the spouse of a smear-positive case:\n\n"
    "1. SYMPTOM SCREENING (cough, fever, night sweats, weight loss).\n\n"
    "2. A TUBERCULIN TEST OR IGRA.\n\n"
    "3. A CHEST RADIOGRAPH if the test is positive or symptoms are present.\n\n"
    "4. AND, IF LATENT INFECTION IS ESTABLISHED AND ACTIVE DISEASE EXCLUDED, PREVENTIVE TREATMENT.\n\n"
    "WHY THE CHANGE? Because HOUSEHOLD CONTACT WITH A SMEAR-POSITIVE CASE IS ONE OF THE HIGHEST-RISK EXPOSURES THERE IS — studies show 30 TO 50 % OF CLOSE HOUSEHOLD CONTACTS BECOME INFECTED — and TREATING LATENT INFECTION IS ONE OF THE MOST COST-EFFECTIVE PUBLIC HEALTH INTERVENTIONS AVAILABLE.\n\n"
    "SO GIVE THE BOOK'S KEY IN THE EXAMINATION; SCREEN THE SPOUSE AT THE BEDSIDE.\n\n"
    "WHY ARE THE OTHER THREE REJECTED WITHIN THE BOOK'S FRAMEWORK?\n\n"
    "PERFORMING A TUBERCULIN TEST — within the book's framework, NOT THE FIRST PRIORITY FOR A HEALTHY ASYMPTOMATIC ADULT. (And there is a genuine practical difficulty: in Iran, with universal BCG and a high prevalence of latent infection, INTERPRETING A POSITIVE TEST IN AN ADULT IS HARD.)\n\n"
    "A PLAIN CHEST RADIOGRAPH — RADIATION WITHOUT INDICATION in a wholly asymptomatic person.\n\n"
    "WARNING: SPUTUM EXAMINATION FOR ACID-FAST BACILLI — THE MOST MEANINGLESS OPTION. THIS WOMAN HAS NO COUGH AT ALL — what sputum is she meant to produce? Sputum examination is for the SYMPTOMATIC patient, not for screening the well.",
    ["در چارچوب کتاب برای بزرگسال سالم و بی‌علامت اولویت اول نیست؛ تفسیرش هم در ایران دشوار است.",
     "پرتو بدون اندیکاسیون در فرد کاملاً بی‌علامت.",
     "بی‌معناترین گزینه؛ این فرد سرفه ندارد و اصلاً خلطی برای فرستادن ندارد.",
     "پاسخ صحیح (کلید کتاب) — بزرگسال سالم بی‌علامت؛ توصیه به مراجعه در صورت بروز علائم."],
    ["Within the book's framework not the first priority for a healthy asymptomatic adult, and hard to interpret in Iran.",
     "Radiation without indication in a wholly asymptomatic person.",
     "The most meaningless option; she has no cough and no sputum to send.",
     "Correct (the book's key) — a healthy asymptomatic adult; advise return if symptoms appear."],
    "**در امتحان کلید کتاب را بدهید؛ در بالین تماس خانگی را فعالانه غربالگری کنید.**",
    "Give the book's key in the examination; actively screen the household contact at the bedside.",
    REFSC)

json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book56.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 56 lessons:', len(L))
