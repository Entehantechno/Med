# -*- coding: utf-8 -*-
"""One printed key in the zoonoses chapter that is wrong: q9421.

The conservative rule as always: the printed key is presumed right, and is
overruled only when a primary source says plainly that it is wrong AND the
argument survives being written out for a student. This one does not survive.

------------------------------------------------------------------ q9421
"A 25-year-old man bitten by a dog a few hours ago; rabies vaccine and first
aid have been given. Which of the following treatments do you prescribe to
prevent INFECTION?"
Options, all four of them fluoroquinolones:
   (A) ciprofloxacin   (B) levofloxacin   (C) gemifloxacin   (D) moxifloxacin
Printed key: (A) ciprofloxacin.

Why the key cannot stand
------------------------
The rule the book itself teaches, twice, in the two neighbouring questions:
prophylaxis of a bite wound must cover BOTH the aerobes (above all Pasteurella
multocida, plus streptococci and staphylococci) AND the animal's ORAL
ANAEROBES. That is precisely why amoxicillin-clavulanate is the drug of choice,
and the book answers exactly that in q9419 and q9420.

Apply the same rule to the four quinolones offered here:

  ciprofloxacin   Pasteurella yes, ANAEROBES NO
  levofloxacin    Pasteurella yes, ANAEROBES NO
  gemifloxacin    a respiratory quinolone; no place in bite flora
  moxifloxacin    Pasteurella yes, ANAEROBES YES

The IDSA 2014 skin and soft tissue guideline is explicit in both directions.
On the inadequate ones: "If SMX-TMP or levofloxacin is used, anaerobic coverage
with either clindamycin or metronidazole should be added." And in Table 5,
beside moxifloxacin, the comment reads: "Monotherapy; good for anaerobes also."
UCSF's adult bite guidance says the same thing operationally — for severe
beta-lactam allergy it prescribes "clindamycin PLUS either ciprofloxacin or
levofloxacin", i.e. a quinolone is never used alone unless it is moxifloxacin.

Nothing in the stem pairs any of these agents with metronidazole or
clindamycin, so the question is asking which single agent suffices. Only one
does.

  Correction: A -> D (moxifloxacin).

Note what is NOT claimed. We are not saying ciprofloxacin is useless in bites —
it is a perfectly good component of a regimen. We are saying that as the SOLE
agent, among these four, it leaves the anaerobic half of a polymicrobial wound
untreated while another option on the same list does not. And we are not
weakening the main teaching point: whenever amoxicillin-clavulanate is on the
list it remains first choice, which is what the lesson says in its last line.
"""
import json, io, os

HERE = os.path.dirname(os.path.abspath(__file__))

FIXES = {
    9421: {
        'to': 3,
        'expect_from': 0,
        'fa': 'کلید چاپی «سیپروفلوکساسین» را انتخاب کرده است، ولی این انتخاب با قاعده‌ای که '
              '**خودِ همین کتاب** دو سؤال قبل‌تر آموزش می‌دهد نمی‌خواند. در q9419 و q9420 '
              'پاسخ درست **آموکسی‌سیلین-کلاوولانات** است، دقیقاً به این دلیل که پروفیلاکسی '
              'گازگرفتگی باید **هم هوازی‌ها (به‌ویژه پاستورلا مولتوسیدا) و هم بی‌هوازی‌های '
              'دهانی حیوان** را بپوشاند.\n\n'
              'همان قاعده را روی چهار کینولون این سؤال اعمال کنید: **سیپروفلوکساسین** و '
              '**لووفلوکساسین** پاستورلا را می‌گیرند ولی **روی بی‌هوازی‌ها عملاً بی‌اثرند**؛ '
              '**جمی‌فلوکساسین** یک کینولون تنفسی است و در فلور گازگرفتگی جایگاهی ندارد؛ و '
              'تنها **موکسی‌فلوکساسین** هر دو گروه را می‌پوشاند.\n\n'
              'راهنمای IDSA سال ۲۰۱۴ همین را از هر دو سو می‌گوید: اگر لووفلوکساسین یا '
              'کوتریموکسازول به کار رود **باید کلیندامایسین یا مترونیدازول اضافه شود**، و در '
              'جدول ۵ کنار موکسی‌فلوکساسین نوشته است «**تک‌دارویی؛ برای بی‌هوازی‌ها هم '
              'خوب است**». چون در این سؤال هیچ‌یک از گزینه‌ها با مترونیدازول ترکیب نشده، '
              'پرسش این است که کدام دارو **به‌تنهایی** کافی است — و تنها یکی هست.',
        'en': 'The printed key chooses ciprofloxacin, but that contradicts the rule THE BOOK '
              'ITSELF teaches two questions earlier. In q9419 and q9420 the correct answer is '
              'AMOXICILLIN-CLAVULANATE, precisely because bite prophylaxis must cover BOTH the '
              'aerobes (above all Pasteurella multocida) AND the animal\'s ORAL ANAEROBES.\n\n'
              'Apply that same rule to the four quinolones offered here: CIPROFLOXACIN and '
              'LEVOFLOXACIN cover Pasteurella but are ESSENTIALLY INACTIVE AGAINST ANAEROBES; '
              'GEMIFLOXACIN is a respiratory quinolone with no place in bite flora; only '
              'MOXIFLOXACIN covers both groups.\n\n'
              'The IDSA 2014 guideline says this from both directions: if levofloxacin or '
              'co-trimoxazole is used, CLINDAMYCIN OR METRONIDAZOLE MUST BE ADDED, and Table 5 '
              'notes beside moxifloxacin, "Monotherapy; good for anaerobes also". Since no '
              'option here is paired with metronidazole, the question is which single agent '
              'suffices — and only one does.',
        'refs': ['IDSA — Practice Guidelines for the Diagnosis and Management of Skin and Soft '
                 'Tissue Infections, 2014 update, Table 5 and the animal-bite recommendations',
                 "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 46: "
                 'Infectious Complications of Bites',
                 'Internal consistency of the source: q9419 and q9420 of the same chapter both '
                 'answer amoxicillin-clavulanate, i.e. the book requires anaerobic cover'],
    },
}


def main():
    done = []
    for i in range(1, 6):
        p = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        body = json.load(io.open(p, encoding='utf-8'))
        dirty = False
        for q in body['questions']:
            spec = FIXES.get(q['question_no'])
            if not spec:
                continue
            if q['correct_index'] == spec['to'] and q.get('key_corrected'):
                continue
            assert q['correct_index'] == spec['expect_from'], (
                f"q{q['question_no']}: expected printed key {spec['expect_from']}, "
                f"found {q['correct_index']}")
            q['original_correct_index'] = q['correct_index']
            q['correct_index'] = spec['to']
            q['key_corrected'] = True
            q['key_correction_fa'] = spec['fa']
            q['key_correction_en'] = spec['en']
            q['key_correction_source'] = '; '.join(spec['refs'])
            done.append(f"q{q['question_no']}: {spec['expect_from'] + 1} -> {spec['to'] + 1}  "
                        f"({q['options_fa'][spec['to']][:46]})")
            dirty = True
        if dirty:
            json.dump(body, io.open(p, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)
    for d in done:
        print('key fixed', d)
    print(f'\n{len(done)} keys corrected')


if __name__ == '__main__':
    main()
