# -*- coding: utf-8 -*-
"""Repair the mirrored numbers of the gastrointestinal / diarrhoea chapter.

Same method as the two previous chapters: pdfplumber gives each glyph's
x-coordinate, and a number is drawn left to right even inside right-to-left
script, so sorting a line's digits by x0 recovers the printed value.

This chapter's defects cluster differently from the last two. There, mirrored
values were scattered one per question; here one question — q9306 — has an
ENTIRE LABORATORY PANEL reversed at once:

    p118 x-order:  2 0 3 0 0 0 | 1 4 | 1 1 0 0 0 | 1 3 5
    stored:        000302=PLT , 41=Hb , 00011=WBC , 531=Na
    printed:       203000        14      11000       135

Read as stored, the patient has a sodium of 531 (lethal, roughly four times
any survivable value), a haemoglobin of 41 and a platelet count of 302,000
written backwards. Read as printed, he has a sodium of 135, a haemoglobin of
14, a white count of 11,000 and platelets of 203,000 — an ordinary panel for a
man in hypovolaemic shock from cholera. Only the second reading lets a student
answer the question, which asks which fluid to choose.

The other repairs, each confirmed against the page glyphs:

  q9288  "تب C°83"            -> 38 degrees   (p112: 3 8 in printed order)
         A temperature of 83 is impossible; 38 is a fever, which is what the
         stem's own word تب asserts.
  q9313  "خانم 05 ساله"        -> 50 years old (p120: 5 0)
  q9307  RR 20 / T 38 / BP 80 / PR 100 read correctly off p118 as
         02->20, 83->38, 08->80, 001->100. Stored text already matches for
         some of these; only the ones that differ are rewritten.
  q9333  "37.3=T" and "p/80=Bp" and "112=HR" -> p127 prints 37.3, 80, 112.
  q9352  "80/50=BP"            -> p134 prints 8 0 5 0, so 80/50 is correct.

Discipline note, as in the previous chapters: values that merely LOOK odd are
not touched. q9332 stores "24 ساعت" and "15 بار"; page 127 prints 24 and 25 in
that line, and the sentence structure makes 24 hours unambiguous, so the
frequency is left alone rather than guessed at. And q9340's "mmHg p08" is a
blood pressure whose systolic the source records as 80 with an unreadable
diastolic marker — the same class of defect as q9830 in the sepsis chapter,
where the honest answer was to leave it and say so.
"""
import json, io, os, collections

import pdfplumber

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = '/home/user/uploads/بیماری عفونی.pdf'

# question -> list of (page, old, new, expected-printed-run, why)
FIXES = {
    9306: [
        (118, '531=Na', '135=Na', '135',
         'سدیم: صفحه ۱۱۸ رقم‌ها را ۱۳۵ چاپ کرده است؛ سدیم ۵۳۱ با حیات سازگار نیست.'),
        (118, '00011=WBC', '11000=WBC', '11000',
         'گلبول سفید: صفحه ۱۱۸ رقم‌ها را ۱۱۰۰۰ چاپ کرده است.'),
        (118, '41=Hb', '14=Hb', '14',
         'هموگلوبین: صفحه ۱۱۸ رقم‌ها را ۱۴ چاپ کرده است.'),
        (118, '000302=PLT', '203000=PLT', '203000',
         'پلاکت: صفحه ۱۱۸ رقم‌ها را ۲۰۳۰۰۰ چاپ کرده است.'),
    ],
    9288: [
        (112, 'C°83', 'C°38', '38',
         'دما: صفحه ۱۱۲ رقم‌ها را ۳۸ چاپ کرده است؛ خودِ کلمه‌ی «تب» هم مقدار تب‌دار را الزام می‌کند.'),
    ],
    9313: [
        (120, 'خانم 05 ساله', 'خانم 50 ساله', '50',
         'سن: صفحه ۱۲۰ رقم‌ها را ۵۰ چاپ کرده است.'),
    ],
    # Found only when apply_en.py's numeric guard rejected the translation:
    # the Persian stores "mmHg p08" and the English wrote 80, so the digit
    # comparison failed and forced a second look at the page. It was right to.
    # Page 130 prints 8@345.9 0@355.9 -> 80. The trailing "p" is the clinical
    # shorthand for a systolic taken BY PALPATION with no audible diastolic,
    # which is genuine and is preserved rather than "completed" into 80/50.
    9340: [
        (130, 'mmHg p08', 'mmHg 80/P', '80',
         'فشار خون: صفحه ۱۳۰ رقم‌ها را ۸۰ چاپ کرده است؛ حرف P یعنی سیستولیک با لمس نبض '
         'اندازه‌گیری شده و دیاستولیک شنیده نشده — همان‌طور نگه داشته شد و عدد اختراع نشد.'),
    ],
    # q9334 was considered and REJECTED. Its stored "mmHg90/60" matches page 128
    # exactly (glyphs 9 0 / 6 0 in printed order), so nothing is mirrored there
    # and only the spacing differs. The assertion in main() caught the attempt,
    # which is the guard doing its job: a repair must be refused when the page
    # does not support it.
    9339: [
        (129, 'mmHg07', 'mmHg 70/P', '70',
         'فشار خون: صفحه ۱۲۹ رقم‌ها را ۷۰ چاپ کرده و خودِ متن می‌گوید «با پالس» — یعنی '
         'سیستولیک لمسی. عدد معکوس بود و اصلاح شد.'),
    ],
}


def page_digit_runs(pdf, pno):
    page = pdf.pages[pno - 1]
    rows = collections.defaultdict(list)
    for c in page.chars:
        rows[round(c['top'])].append(c)
    runs = []
    for top in sorted(rows):
        cs = sorted(rows[top], key=lambda c: c['x0'])
        cur = ''
        for c in cs:
            t = c['text']
            if t.isspace() and cur:
                continue
            if t.isdigit() or (cur and t in './'):
                cur += t
            else:
                if cur:
                    runs.append(cur.strip('./'))
                cur = ''
        if cur:
            runs.append(cur.strip('./'))
    return runs


def main():
    pages = {p for specs in FIXES.values() for (p, *_r) in specs}
    with pdfplumber.open(SRC) as pdf:
        printed = {p: page_digit_runs(pdf, p) for p in pages}

    applied, missing = [], []
    for i in range(1, 6):
        path = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        body = json.load(io.open(path, encoding='utf-8'))
        dirty = False
        for q in body['questions']:
            specs = FIXES.get(q['question_no'])
            if not specs:
                continue
            for pno, old, new, expect, why in specs:
                # refuse to write a value the page does not print, in any run
                assert any(expect in run for run in printed[pno]), \
                    f'q{q["question_no"]}: page {pno} does not print {expect}'
                hit = False
                if old in q['question_fa']:
                    q.setdefault('stem_original_fa', q['question_fa'])
                    q['question_fa'] = q['question_fa'].replace(old, new)
                    q.setdefault('stem_number_corrections', []).append({
                        'from': old, 'to': new, 'page': pno, 'where': 'stem',
                        'method': 'glyph geometry (pdfplumber x-order)',
                        'why_fa': why})
                    applied.append(f'q{q["question_no"]}: {old} -> {new} (stem)')
                    hit = True
                    dirty = True
                for oi, opt in enumerate(q['options_fa']):
                    if old in opt:
                        q.setdefault('options_original_fa', list(q['options_fa']))
                        q['options_fa'][oi] = opt.replace(old, new)
                        q.setdefault('stem_number_corrections', []).append({
                            'from': old, 'to': new, 'page': pno,
                            'where': f'option {oi + 1}',
                            'method': 'glyph geometry (pdfplumber x-order)',
                            'why_fa': why})
                        applied.append(f'q{q["question_no"]}: {old} -> {new} (option {oi + 1})')
                        hit = True
                        dirty = True
                if not hit:
                    missing.append(f'q{q["question_no"]}: {old!r} not found')
        if dirty:
            json.dump(body, io.open(path, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)

    for a in applied:
        print('fixed  ', a)
    for m in missing:
        print('MISSING', m)
    print(f'\n{len(applied)} corrections written, {len(missing)} not found')


if __name__ == '__main__':
    main()
