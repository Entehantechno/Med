# -*- coding: utf-8 -*-
"""English stems and options for the batch-13 and batch-14 questions.

Rule 16 checked first, as always: these are sittings 93-98, for which the
ministry published no English booklet, so these are hand-written translations.
Where an official English booklet exists (Esfand 1400), merge_official_en.py
uses its wording verbatim instead.

Three translation decisions worth recording:

  q9542 (idx 542): the option "سیپروفلوکساسین 500 گرم" literally reads
  "ciprofloxacin 500 GRAMS". The unit is wrong in the source — the Persian word
  گرم (gram) was printed where میلی‌گرم (milligram) belongs. Unlike the mirrored
  digits, this is not something glyph geometry can settle, because the page
  really does print that word. The English writes "500 mg" and the discrepancy
  is recorded here rather than silently reproduced, since "500 g" of any
  antibiotic is not a dose a student should ever read as normal.

  q9548 (idx 548) carried four mirrored doses that fix_viral_numbers.py has
  since corrected from glyph geometry; that question is not translated in this
  batch, but the same rule applies: the English always quotes the CORRECTED
  value, and apply_en.py's numeric guard re-checks every digit against the
  Persian before writing.

  q9598 (idx 598): the Persian gives the benzathine penicillin dose as 1,200,000
  units. That is a real number on the page (glyphs 1-2-0-0-0-0-0 in printed
  order), not a mirroring artefact, so it is translated as written.
"""

EN6 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    assert all(o.strip() for o in options), idx
    EN6[idx] = {"stem_en": stem, "options_en": options}


# ------------------------------------------------------------ genital ulcers
add(529,
    "A 25-year-old man presents with two large, deep ulcers on the shaft of the penis, present "
    "for two days, which are painful and purulent in appearance. The ulcers have ragged edges and "
    "a soft consistency, and their bases bleed readily on contact with a swab. There is tender "
    "right inguinal lymphadenopathy. Which of the following diagnoses is most likely?",
    ["Genital herpes", "Syphilis", "Lymphogranuloma venereum", "Chancroid"])

add(533,
    "A 20-year-old man presents with fever and painful right inguinal lymphadenopathy. On "
    "examination the nodes are enlarged, tender and erythematous. He reports a small genital "
    "ulcer two weeks earlier that healed spontaneously. What is the most likely diagnosis?",
    ["Chancroid", "Genital herpes", "Syphilis", "Lymphogranuloma venereum"])

add(556,
    "A 25-year-old man attends the clinic with a genital ulcer. On examination the ulcer is "
    "painless and raised, with a firm consistency and a clean base, and a painless unilateral "
    "inguinal lymph node is palpable. What is the most likely diagnosis?",
    ["Chancroid", "Syphilis", "HSV", "Lymphogranuloma venereum"])

add(559,
    "A 25-year-old man presents to the clinic with non-itchy maculopapular lesions over his whole "
    "body, including the palms and soles. Over the past few days he has also had fever, sore "
    "throat and anorexia. On examination there is multiple, non-tender lymphadenopathy. He "
    "reports a painless genital ulcer about four weeks ago. Given his features and the likely "
    "diagnosis, what is the most appropriate treatment?",
    ["Benzathine penicillin G, a single dose of 2.4 million units",
     "Benzathine penicillin G 2.4 million units weekly for three weeks",
     "Ceftriaxone 2 g as a single dose",
     "Ceftriaxone 1 g twice daily for 14 days"])

add(560,
    "Which of the following tests is used to assess the response to treatment of syphilis?",
    ["VDRL", "FTA-ABS", "TPHA (Treponema pallidum haemagglutination test)", "All of the above"])

# ----------------------------------------------------------------- urethritis
add(542,
    "A young man diagnosed with urethritis was treated with ceftriaxone. Two weeks after "
    "receiving the drug he returns with a mucoid discharge and burning and itching of the "
    "urethra. What is the appropriate action for him?",
    ["Ciprofloxacin 500 mg every 12 hours for 7 days",
     "Spectinomycin 1 g intramuscularly as a single dose",
     "Repeat the ceftriaxone injection, 1 g",
     "Azithromycin 1 g as a single dose"])

# ------------------------------------------------------------ mononucleosis
add(598,
    "A 25-year-old man has had fever, exudative pharyngitis and cervical lymphadenopathy for five "
    "days. Investigations show a WBC of 20,000 with 70% lymphocytes together with atypical "
    "lymphocytes. He has no respiratory distress, and three days ago he received an injection of "
    "benzathine penicillin 1,200,000 units. What do you recommend?",
    ["Oral aciclovir", "Prednisolone", "Azithromycin", "Symptomatic treatment"])

add(603,
    "An 18-year-old man presents with fever, severe sore throat and enlarged cervical lymph nodes "
    "for the past 10 days. On examination his temperature is 39 degrees, his tonsils are enlarged "
    "with a white exudate, and there is tender bilateral posterior cervical lymphadenopathy. He "
    "has a generalised maculopapular rash which, he says, appeared two days ago after a doctor "
    "prescribed ampicillin. Investigations show a leucocytosis of 20,000 with 70% lymphocytes, "
    # The Persian writes the counts in the same style throughout — "20 thousand",
    # "100 thousand" — so the English mirrors that wording rather than expanding
    # it to 20,000/100,000. apply_en.py compares digit runs between the two
    # languages, and expanding one number but not the other made 100 vanish from
    # the English and correctly tripped the guard.
    "raised liver enzymes and thrombocytopenia of 100 thousand, and the laboratory reports that more "
    "than 20% of the lymphocytes are large and atypical. The monospot test is positive. Given the "
    "likely diagnosis, a glucocorticoid is required in all of the following EXCEPT",
    ["Airway obstruction from severe tonsillar hypertrophy",
     "Severe thrombocytopenia",
     "A generalised maculopapular rash",
     "Autoimmune haemolytic anaemia"])

# --------------------------------------------------------------- varicella
add(625,
    "A pregnant woman at 20 weeks' gestation, with no history of chickenpox, had close contact "
    "yesterday with a person who has chickenpox. Which of the following do you recommend "
    "regarding prophylactic treatment with aciclovir?",
    ["Immediately after the exposure",
     "Within the first 96 hours of the exposure",
     "When the skin rash appears",
     "Seven days after the exposure"])

# ----------------------------------------------------------------- measles
add(639,
    "A 12-year-old with an uncertain vaccination history develops fever, cough and "
    "conjunctivitis. On examination there are bluish-white spots on the buccal mucosa, which "
    "disappear after two days as a maculopapular rash appears on the head and face. The rash "
    "gradually spreads to the neck, trunk and limbs. What is the most likely diagnosis?",
    ["Rubella", "Measles", "Chickenpox", "Infectious mononucleosis"])

# --------------------------------------------------------------------- HIV
add(661,
    "A 25-year-old man had unprotected sexual intercourse six weeks ago. He presents with fever, "
    "arthralgia, sore throat and a generalised maculopapular rash. Blood tests show a relative "
    "leucopenia. Which of the following is most likely?",
    ["Acute HIV", "Syphilis", "Hepatitis B", "Gonorrhoea"])

add(685,
    "A 35-year-old woman with lupus presents with a positive HIV ELISA. To confirm the diagnosis "
    "the test is repeated, and the second ELISA is reported negative. Which of the following is "
    "correct?",
    ["Because the second test is negative, no further diagnostic action is needed",
     "Because she has lupus, starting antiretroviral treatment is recommended",
     "A Western blot is needed in order to decide",
     "Repeating the HIV ELISA in 3 to 6 months is recommended"])

add(687,
    "A 20-year-old man presents with headache, fever, pharyngitis and cervical adenopathy. He "
    "reports unprotected sexual intercourse 17 days ago. Which test would you request to "
    "diagnose HIV?",
    ["p24 antigen", "CD4 count", "Western blot", "HIV antibody ELISA"])

add(704,
    "An HIV-positive patient with a CD4 count below 200 requires prophylaxis against which of the "
    "following?",
    ["CMV", "Toxoplasmosis", "Pneumocystis carinii", "Mycobacterium avium complex"])
