# -*- coding: utf-8 -*-
"""Micro-lessons, batch 24 — cellulitis, water and animal exposures, necrotising
infection and toxic shock.

The first half of the skin and soft tissue chapter, and the part of the whole
book with the highest stakes per question. Necrotising fasciitis and toxic
shock kill in hours, and both are diagnosed by noticing that THE PATIENT IS
FAR SICKER THAN THE SKIN LOOKS.

The four decisions these questions ask
--------------------------------------
1. IS IT STREP OR STAPH? The whole of ordinary skin infection divides on this,
   and the discriminator is the EDGE of the lesion. A sharply demarcated,
   raised border is erysipelas — Streptococcus pyogenes, treat with penicillin.
   A diffuse lesion with an indistinct edge, or any pus, is Staphylococcus —
   treat with an antistaphylococcal penicillin or a first-generation
   cephalosporin.

2. IS THERE AN EXPOSURE THAT NAMES A DIFFERENT ORGANISM? Fresh water, sea
   water, fish, cats, shellfish in a cirrhotic. Each has one answer, and the
   exam tests them as a set.

3. IS THIS STILL CELLULITIS, OR IS IT NECROTISING? Six questions hinge on
   this, and the answer is never a scan. Pain out of proportion, systemic
   toxicity, hypotension and rapid progression mean THEATRE.

4. IS THIS TOXIC SHOCK? Fever, hypotension, diffuse erythroderma and
   multi-organ involvement, in a patient whose skin may look almost normal.

Reference: Stevens DL et al., "Practice Guidelines for the Diagnosis and
Management of Skin and Soft Tissue Infections: 2014 Update by the Infectious
Diseases Society of America", Clin Infect Dis 2014;59:e10-e52; Harrison's
Principles of Internal Medicine, 21st ed (2022), Ch. 26 (Soft Tissue and
Muscle Infections) and Ch. 143 (Streptococcal Infections).
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


IDSA = ("Stevens DL et al. — Practice Guidelines for the Diagnosis and Management of Skin and "
        "Soft Tissue Infections: 2014 Update by the Infectious Diseases Society of America. "
        "Clin Infect Dis 2014;59(2):e10-e52")
H26 = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 26: Soft Tissue and Muscle Infections"
H143 = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 143: Streptococcal Infections"

# ---------------------------------------------------------------------------
# The strep-versus-staph spine, shared by the ordinary cellulitis questions.
# ---------------------------------------------------------------------------
CELL_FA = [
    "⚠️ **در عفونت پوستی، اولین سؤال همیشه این است: استرپتوکوک یا استافیلوکوک؟**",
    "و **حاشیه‌ی ضایعه** پاسخ را می‌دهد — این تنها معاینه‌ای است که باید یاد بگیرید.",
    "**اریزیپل (باد سرخ) ← استرپتوکوک پیوژن:**",
    "**حاشیه‌ی کاملاً مشخص و برجسته** که با انگشت می‌توان مرزش را حس کرد.",
    "درگیری **درم سطحی و لنفاتیک‌ها** است، پس ضایعه **بالاتر از سطح پوست سالم** می‌ایستد.",
    "**صورت و ساق** شایع‌ترین محل‌هایند، شروعش **ناگهانی** و تب زودرس است.",
    "⚠️ **سلولیت معمولی ← بیشتر استافیلوکوک اورئوس:**",
    "**حاشیه‌ی نامشخص و محو**، چون درگیری **درم عمقی و بافت زیرجلدی** است.",
    "**و قاعده‌ی طلایی دوم: هر جا چرک هست، استافیلوکوک است.**",
    "آبسه، فورونکل، کاربونکل و هر ضایعه‌ی **پورولان** ← استاف تا خلاف آن ثابت شود.",
    "**درمان بر پایه‌ی همین تقسیم‌بندی:**",
    "**اریزیپل ← پنی‌سیلین** (استرپ گروه A هنوز **صددرصد به پنی‌سیلین حساس** است).",
    "**سلولیت ← آنتی‌استافیلوکوکی:** کلوگزاسیلین/نافسیلین/اگزاسیلین، یا **سفازولین/سفالکسین**.",
    "⚠️ **و داروهایی که در عفونت پوستی نباید انتخاب اول باشند:**",
    "**سفالوسپورین‌های نسل سوم خوراکی (سفیکسیم)** ← پوشش **گرم‌مثبت ضعیفی** دارند.",
    "این نکته چهار بار در همین فصل پرسیده شده و پرتکرارترین تله‌ی بلوک است.",
    "**سیپروفلوکساسین** ← گرم‌منفی است؛ روی استرپ و استاف جای اتکا ندارد.",
    "⚠️ **لنفانژیت** (خط قرمز برجسته‌ی دردناک به سمت پروگزیمال) **کلاسیک استرپتوکوکی** است.",
    "**در آلرژی به پنی‌سیلین: کلیندامایسین** — هم استرپ و هم استاف (و حتی MRSA جامعه) را می‌گیرد.",
]
CELL_EN = [
    "WARNING: IN A SKIN INFECTION THE FIRST QUESTION IS ALWAYS — STREPTOCOCCUS OR STAPHYLOCOCCUS?",
    "And THE EDGE OF THE LESION answers it; this is the one examination finding you must learn.",
    "ERYSIPELAS — STREPTOCOCCUS PYOGENES:",
    "A SHARPLY DEMARCATED, RAISED BORDER whose margin can be felt with a finger.",
    "It involves the SUPERFICIAL DERMIS AND LYMPHATICS, so the lesion stands PROUD OF NORMAL SKIN.",
    "THE FACE AND THE LEG are the commonest sites; onset is ABRUPT with early fever.",
    "WARNING, ORDINARY CELLULITIS — more often STAPHYLOCOCCUS AUREUS:",
    "AN INDISTINCT, FADING EDGE, because it involves the DEEP DERMIS AND SUBCUTANEOUS TISSUE.",
    "AND THE SECOND GOLDEN RULE: WHEREVER THERE IS PUS, IT IS STAPHYLOCOCCUS.",
    "Abscess, furuncle, carbuncle and any PURULENT lesion means staph until proven otherwise.",
    "TREATMENT FOLLOWS THAT SAME DIVISION:",
    "ERYSIPELAS — PENICILLIN (group A strep remains 100% PENICILLIN SUSCEPTIBLE).",
    "CELLULITIS — AN ANTISTAPHYLOCOCCAL AGENT: cloxacillin/nafcillin/oxacillin, or CEFAZOLIN/CEPHALEXIN.",
    "WARNING, AND THE DRUGS THAT MUST NOT BE FIRST CHOICE IN SKIN INFECTION:",
    "ORAL THIRD-GENERATION CEPHALOSPORINS (cefixime) have POOR GRAM-POSITIVE COVER.",
    "This point is asked four times in this chapter and is the block's commonest trap.",
    "CIPROFLOXACIN is a gram-negative agent; it cannot be relied on against strep or staph.",
    "WARNING: LYMPHANGITIS (a tender red streak running proximally) IS CLASSICALLY STREPTOCOCCAL.",
    "IN PENICILLIN ALLERGY: CLINDAMYCIN — it covers strep, staph and even community MRSA.",
]

WATER_FA = [
    "⚠️ **در عفونت بافت نرم، «تماس» نام ارگانیسم را می‌گوید. این جدول را حفظ کنید:**",
    "**آب شیرین (رودخانه، دریاچه، زالو) ← آئروموناس هیدروفیلا.**",
    "درمانش **داکسی‌سیکلین + سیپروفلوکساسین یا سفتریاکسون** است، نه بتالاکتام تنها.",
    "⚠️ **آب شور و صدف خام، به‌ویژه در بیمار سیروتیک ← ویبریو ولنیفیکوس.**",
    "**چرا سیروز؟** چون **اضافه‌بار آهن و کاهش فعالیت سیستم رتیکولواندوتلیال**،",
    "به این باکتری اجازه‌ی **باکتریمی سریع** می‌دهد. مرگ‌ومیرش بسیار بالاست.",
    "تابلوی مشخصه‌اش: **تاول‌های هموراژیک** روی اندام‌ها همراه با **شوک سپتیک**.",
    "درمان: **داکسی‌سیکلین + سفتریاکسون**، و اغلب **دبریدمان**.",
    "**ماهی، صدف، گوشت خام (شغل: ماهی‌فروش، قصاب، دامپزشک) ← اریزیپلوتریکس روزیوپاتیه.**",
    "ضایعه‌ی بنفش‌رنگ **بدون چرک** روی دست، به‌کندی گسترش می‌یابد.",
    "⚠️ **نکته‌ی امتحانی: اریزیپلوتریکس ذاتاً به وانکومایسین مقاوم است.**",
    "درمانش **پنی‌سیلین** است؛ سفالوسپورین، کلیندامایسین و کینولون هم مؤثرند.",
    "**گازگرفتگی گربه یا سگ ← پاستورلا مولتوسیدا** ← **آموکسی‌سیلین-کلاوولانات**.",
    "⚠️ **گازگرفتگی سگ در بیمار اسپلنکتومی ← کاپنوسیتوفاگا کانیمورسوس.**",
    "کوکوباسیل **گرم‌منفی** فلور دهان سگ که در فرد بی‌طحال **سپسیس فولمینانت** می‌سازد،",
    "با **پورپورا، DIC و نارسایی چنداندامی**. درمانش **آموکسی‌سیلین-کلاوولانات یا کارباپنم**.",
    "**استخر شنا با کلر ناکافی ← فولیکولیت پسودومونایی** (self-limited، معمولاً بدون آنتی‌بیوتیک).",
    "⚠️ **بیمار نوتروپنیک با ضایعه‌ی نکروتیک مرکزی ← اکتیما گانگرنوزوم ← پسودوموناس آئروژینوزا.**",
]
WATER_EN = [
    "WARNING: IN SOFT TISSUE INFECTION THE EXPOSURE NAMES THE ORGANISM. MEMORISE THIS TABLE:",
    "FRESH WATER (river, lake, leeches) — AEROMONAS HYDROPHILA.",
    "Its treatment is DOXYCYCLINE PLUS CIPROFLOXACIN OR CEFTRIAXONE, not a beta-lactam alone.",
    "WARNING: SALT WATER AND RAW SHELLFISH, ESPECIALLY IN A CIRRHOTIC — VIBRIO VULNIFICUS.",
    "WHY CIRRHOSIS? Because IRON OVERLOAD AND REDUCED RETICULOENDOTHELIAL FUNCTION",
    "let this organism produce RAPID BACTERAEMIA. Its mortality is very high.",
    "Its signature: HAEMORRHAGIC BULLAE on the limbs with SEPTIC SHOCK.",
    "Treatment: DOXYCYCLINE PLUS CEFTRIAXONE, and often DEBRIDEMENT.",
    "FISH, SHELLFISH, RAW MEAT (fishmonger, butcher, vet) — ERYSIPELOTHRIX RHUSIOPATHIAE.",
    "A violaceous, NON-SUPPURATIVE lesion on the hand that spreads slowly.",
    "WARNING, AN EXAM POINT: ERYSIPELOTHRIX IS INTRINSICALLY RESISTANT TO VANCOMYCIN.",
    "Its treatment is PENICILLIN; cephalosporins, clindamycin and quinolones also work.",
    "A CAT OR DOG BITE — PASTEURELLA MULTOCIDA — AMOXICILLIN-CLAVULANATE.",
    "WARNING: A DOG BITE IN AN ASPLENIC PATIENT — CAPNOCYTOPHAGA CANIMORSUS.",
    "A GRAM-NEGATIVE coccobacillus of canine oral flora that causes FULMINANT SEPSIS in the asplenic,",
    "with PURPURA, DIC AND MULTI-ORGAN FAILURE. Treatment: AMOXICILLIN-CLAVULANATE OR A CARBAPENEM.",
    "AN INADEQUATELY CHLORINATED POOL — PSEUDOMONAS FOLLICULITIS (self-limited, usually no antibiotic).",
    "WARNING: A NEUTROPENIC PATIENT WITH A CENTRALLY NECROTIC LESION — ECTHYMA GANGRENOSUM — PSEUDOMONAS AERUGINOSA.",
]

NEC_FA = [
    "⚠️ **فاشئیت نکروزان یک فوریت جراحی است، و تشخیصش بالینی است نه تصویربرداری.**",
    "**علائم هشدار را حفظ کنید — هر کدام به‌تنهایی باید نگرانتان کند:**",
    "⚠️ **یک — درد نامتناسب با یافته‌های ظاهری.** مهم‌ترین و زودرس‌ترین نشانه.",
    "پوست ممکن است فقط کمی قرمز باشد در حالی که بیمار از درد شدید می‌نالد.",
    "**دو — توکسیسیته‌ی سیستمیک: تب بالا، تاکی‌کاردی، افت فشار خون، گیجی.**",
    "**سه — پیشرفت سریع** ضایعه، به‌ویژه **علی‌رغم شروع آنتی‌بیوتیک مناسب**.",
    "**چهار — تاول (بولا)، به‌ویژه هموراژیک؛ اکیموز؛ نکروز پوستی؛ کرپیتاسیون.**",
    "**پنج — بی‌حسی پوست روی ضایعه**، به‌علت تخریب اعصاب سطحی.",
    "⚠️ **و مهم‌ترین قاعده‌ی این بلوک: تصویربرداری نباید جراحی را به تأخیر بیندازد.**",
    "CT و MRI می‌توانند گاز یا ادم فاسیا را نشان دهند، ولی **حساسیتشان کامل نیست**",
    "و **مهم‌تر از آن، وقت می‌برند** — وقتی که بیمار ندارد.",
    "**استاندارد طلایی تشخیص: اکسپلوراسیون جراحی.**",
    "در جراحی، **فاسیای خاکستری، بدون مقاومت به دیسکسیون بلانت، و چرک آبکی بدبو** دیده می‌شود.",
    "**درمان سه پایه دارد و هر سه لازم‌اند:**",
    "**یک — دبریدمان فوری و مکرر** (تنها مداخله‌ای که بقا را واقعاً تغییر می‌دهد).",
    "**دو — آنتی‌بیوتیک وسیع‌الطیف**: وانکومایسین یا لینزولید + پیپراسیلین-تازوباکتام یا کارباپنم.",
    "⚠️ **سه — کلیندامایسین، که در هر رژیمی باید باشد.**",
    "**چرا کلیندامایسین؟** چون **مهارکننده‌ی سنتز پروتئین است و تولید توکسین را متوقف می‌کند**.",
    "بتالاکتام‌ها در فاز ایستای رشد باکتری (اثر Eagle) کم‌اثر می‌شوند؛ کلیندامایسین نمی‌شود.",
    "**در استرپ گروه A مستند: پنی‌سیلین + کلیندامایسین** (پنی‌سیلین به‌خاطر مقاومت احتمالی به کلیندا).",
]
NEC_EN = [
    "WARNING: NECROTISING FASCIITIS IS A SURGICAL EMERGENCY, AND ITS DIAGNOSIS IS CLINICAL, NOT RADIOLOGICAL.",
    "MEMORISE THE WARNING SIGNS — each alone should worry you:",
    "WARNING, ONE — PAIN OUT OF PROPORTION TO THE PHYSICAL FINDINGS. The most important and earliest sign.",
    "The skin may look only mildly red while the patient is in severe pain.",
    "TWO — SYSTEMIC TOXICITY: high fever, tachycardia, hypotension, confusion.",
    "THREE — RAPID PROGRESSION of the lesion, especially DESPITE APPROPRIATE ANTIBIOTICS.",
    "FOUR — BULLAE, especially haemorrhagic; ecchymosis; skin necrosis; crepitus.",
    "FIVE — ANAESTHESIA OF THE OVERLYING SKIN, from destruction of superficial nerves.",
    "WARNING, AND THE MOST IMPORTANT RULE OF THIS BLOCK: IMAGING MUST NOT DELAY SURGERY.",
    "CT and MRI may show gas or fascial oedema, but THEIR SENSITIVITY IS NOT COMPLETE",
    "and, more importantly, THEY TAKE TIME — which this patient does not have.",
    "THE DIAGNOSTIC GOLD STANDARD IS SURGICAL EXPLORATION.",
    "At operation one finds GREY FASCIA, NO RESISTANCE TO BLUNT DISSECTION, and FOUL 'DISHWATER' PUS.",
    "TREATMENT HAS THREE PILLARS AND ALL THREE ARE REQUIRED:",
    "ONE — IMMEDIATE AND REPEATED DEBRIDEMENT (the only intervention that truly changes survival).",
    "TWO — BROAD-SPECTRUM ANTIBIOTICS: vancomycin or linezolid plus piperacillin-tazobactam or a carbapenem.",
    "WARNING, THREE — CLINDAMYCIN, which must be in every regimen.",
    "WHY CLINDAMYCIN? Because IT IS A PROTEIN SYNTHESIS INHIBITOR AND SHUTS DOWN TOXIN PRODUCTION.",
    "Beta-lactams lose potency in the stationary growth phase (the Eagle effect); clindamycin does not.",
    "IN DOCUMENTED GROUP A STREP: PENICILLIN PLUS CLINDAMYCIN (penicillin because of possible clindamycin resistance).",
]

TSS_FA = [
    "⚠️ **سندرم شوک توکسیک: تب + افت فشار خون + اریتم منتشر + درگیری چنداندامی.**",
    "**مکانیسمش را بفهمید تا تابلو منطقی شود: سوپرآنتی‌ژن.**",
    "توکسین (TSST-1 استافیلوکوکی یا اگزوتوکسین پیروژنیک استرپتوکوکی) **بدون پردازش آنتی‌ژنی**،",
    "مستقیماً **MHC کلاس II** را به **گیرنده‌ی سلول T** وصل می‌کند.",
    "⚠️ نتیجه: فعال شدن **تا ۲۰ درصد کل سلول‌های T** به‌جای یک در ده هزار،",
    "و **طوفان سیتوکینی** که نشت مویرگی، شوک و نارسایی چنداندامی می‌سازد.",
    "**دو نوع TSS را از هم جدا کنید:**",
    "**استافیلوکوکی** ← کلاسیک با **تامپون قاعدگی**، ولی امروز بیشتر **غیرقاعدگی** است:",
    "زخم جراحی، پکینگ بینی، سوختگی. **کشت خون معمولاً منفی است** (بیماری توکسینی است).",
    "**اریتم منتشر شبیه آفتاب‌سوختگی** و سپس **پوسته‌ریزی کف دست و پا در ۱ تا ۲ هفته**.",
    "**استرپتوکوکی** ← معمولاً از یک **عفونت بافت نرم مهاجم** (اغلب فاشئیت نکروزان)،",
    "⚠️ و برخلاف نوع استافیلوکوکی، **کشت خون در نیمی از موارد مثبت است**.",
    "**درمان TSS سه جزء دارد:**",
    "**یک — احیای تهاجمی با مایع** (نشت مویرگی حجم زیادی می‌طلبد).",
    "⚠️ **دو — کلیندامایسین، همیشه**، به‌عنوان **مهارکننده‌ی تولید توکسین**.",
    "به‌علاوه‌ی یک داروی ضدباکتریایی مؤثر: **پنی‌سیلین** در استرپ، **وانکومایسین** در شک به MRSA.",
    "**سه — ایمونوگلوبولین وریدی (IVIG)** در موارد شدید، برای خنثی کردن سوپرآنتی‌ژن.",
    "⚠️ **و همیشه: کانون عفونت را پیدا و تخلیه کنید** — تامپون را بردارید، زخم را باز کنید.",
]
TSS_EN = [
    "WARNING: TOXIC SHOCK SYNDROME IS FEVER PLUS HYPOTENSION PLUS DIFFUSE ERYTHRODERMA PLUS MULTI-ORGAN INVOLVEMENT.",
    "UNDERSTAND THE MECHANISM AND THE PICTURE BECOMES LOGICAL: A SUPERANTIGEN.",
    "The toxin (staphylococcal TSST-1 or streptococcal pyrogenic exotoxin) WITHOUT ANTIGEN PROCESSING",
    "binds MHC CLASS II directly to the T CELL RECEPTOR.",
    "WARNING, the result: ACTIVATION OF UP TO 20 PER CENT OF ALL T CELLS instead of one in ten thousand,",
    "and a CYTOKINE STORM that produces capillary leak, shock and multi-organ failure.",
    "SEPARATE THE TWO KINDS OF TSS:",
    "STAPHYLOCOCCAL — classically with a MENSTRUAL TAMPON, but today more often NON-MENSTRUAL:",
    "a surgical wound, nasal packing, a burn. BLOOD CULTURES ARE USUALLY NEGATIVE (it is a toxin disease).",
    "DIFFUSE SUNBURN-LIKE ERYTHRODERMA, then DESQUAMATION OF PALMS AND SOLES AT 1 TO 2 WEEKS.",
    "STREPTOCOCCAL — usually from an INVASIVE SOFT TISSUE INFECTION (often necrotising fasciitis),",
    "WARNING, and unlike the staphylococcal form, BLOOD CULTURES ARE POSITIVE IN HALF OF CASES.",
    "TREATMENT OF TSS HAS THREE COMPONENTS:",
    "ONE — AGGRESSIVE FLUID RESUSCITATION (capillary leak demands large volumes).",
    "WARNING, TWO — CLINDAMYCIN, ALWAYS, as a TOXIN PRODUCTION INHIBITOR.",
    "Plus an effective bactericidal agent: PENICILLIN for strep, VANCOMYCIN if MRSA is suspected.",
    "THREE — INTRAVENOUS IMMUNOGLOBULIN (IVIG) in severe cases, to neutralise the superantigen.",
    "WARNING, AND ALWAYS: FIND AND DRAIN THE FOCUS — remove the tampon, open the wound.",
]


# =========================================================== book:11
add("book:11", "case", "easy",
 "سلولیت ساعد ← پوشش گرم‌مثبت لازم است ← **سفیکسیم مناسب نیست**.",
 "Cellulitis of the forearm needs GRAM-POSITIVE cover, so CEFIXIME IS NOT APPROPRIATE.",
 CELL_FA + [
  "بیمار **۲۶ ساله** با درد، قرمزی، تورم و گرمی میانه‌ی ساعد است — یک **سلولیت ساده**.",
  "دمای دهانی **۳۷ درجه** یعنی بیمار **توکسیک نیست** و درمان سرپایی خوراکی کافی است.",
  "**سه گزینه‌ی دیگر همگی پوشش گرم‌مثبت خوبی دارند:**",
  "**اگزاسیلین** ← پنی‌سیلین مقاوم به پنی‌سیلیناز، داروی کلاسیک استاف حساس به متی‌سیلین.",
  "**اریترومایسین** ← ماکرولید؛ جایگزین در آلرژی به پنی‌سیلین.",
  "**کلیندامایسین** ← هم استرپ، هم استاف، و حتی **MRSA اکتسابی از جامعه** را می‌گیرد.",
  "⚠️ **می‌ماند سفیکسیم — و همین پاسخ است.**",
  "**چرا سفیکسیم برای عفونت پوستی نامناسب است؟**",
  "سفیکسیم یک **سفالوسپورین نسل سوم خوراکی** است، و نسل سوم‌ها با هر پله بالا رفتن،",
  "**پوشش گرم‌منفی بهتر ولی پوشش گرم‌مثبت ضعیف‌تری** پیدا می‌کنند.",
  "⚠️ **سفیکسیم عملاً روی استافیلوکوک اورئوس بی‌اثر است** و روی استرپ هم قابل اتکا نیست.",
  "پس دقیقاً دو ارگانیسمی را از دست می‌دهد که تمام عفونت پوستی را می‌سازند.",
  "**قاعده‌ای که باید بسپارید: در عفونت پوست، سفالوسپورین نسل اول بهتر از نسل سوم است.**",
  "**سفازولین (تزریقی) و سفالکسین (خوراکی)** انتخاب‌های درست‌اند، نه سفیکسیم و سفتریاکسون.",
 ],
 CELL_EN + [
  "A 26-YEAR-OLD with pain, redness, swelling and warmth of the mid-forearm — SIMPLE CELLULITIS.",
  "An oral temperature of 37 means the patient is NOT TOXIC, so oral outpatient therapy suffices.",
  "THE OTHER THREE OPTIONS ALL HAVE GOOD GRAM-POSITIVE COVER:",
  "OXACILLIN — a penicillinase-resistant penicillin, the classical drug for methicillin-sensitive staph.",
  "ERYTHROMYCIN — a macrolide; an alternative in penicillin allergy.",
  "CLINDAMYCIN — covers strep, staph and even COMMUNITY-ACQUIRED MRSA.",
  "WARNING, THAT LEAVES CEFIXIME — AND THAT IS THE ANSWER.",
  "WHY IS CEFIXIME UNSUITABLE FOR A SKIN INFECTION?",
  "Cefixime is an ORAL THIRD-GENERATION CEPHALOSPORIN, and with each generation upwards",
  "cephalosporins gain GRAM-NEGATIVE cover and LOSE GRAM-POSITIVE cover.",
  "WARNING: CEFIXIME IS ESSENTIALLY INACTIVE AGAINST STAPHYLOCOCCUS AUREUS and unreliable against strep.",
  "So it misses precisely the two organisms that cause all of skin infection.",
  "THE RULE TO REMEMBER: IN SKIN INFECTION A FIRST-GENERATION CEPHALOSPORIN BEATS A THIRD.",
  "CEFAZOLIN (intravenous) and CEPHALEXIN (oral) are the right choices, not cefixime or ceftriaxone.",
 ],
 "بیمار **۲۶ ساله** با درد، قرمزی، تورم و گرمی در میانه‌ی ساعد است — یعنی یک **سلولیت ساده**. دمای دهانی **۳۷ درجه** است، پس بیمار **توکسیک نیست** و درمان خوراکی سرپایی کافی است.\n\n"
 "**سه گزینه‌ی دیگر همگی پوشش گرم‌مثبت خوبی دارند:**\n\n"
 "**اگزاسیلین** ← پنی‌سیلین مقاوم به پنی‌سیلیناز؛ داروی کلاسیک استاف حساس به متی‌سیلین\n"
 "**اریترومایسین** ← ماکرولید؛ جایگزین مناسب در آلرژی به پنی‌سیلین\n"
 "**کلیندامایسین** ← هم استرپ، هم استاف، و حتی **MRSA اکتسابی از جامعه**\n\n"
 "⚠️ **می‌ماند سفیکسیم — و همین پاسخ سؤال است.**\n\n"
 "**چرا سفیکسیم برای عفونت پوستی نامناسب است؟**\n\n"
 "سفیکسیم یک **سفالوسپورین نسل سوم خوراکی** است. و یک قاعده‌ی عمومی درباره‌ی سفالوسپورین‌ها هست که باید بدانید: **هرچه نسل بالاتر می‌رود، پوشش گرم‌منفی بهتر و پوشش گرم‌مثبت ضعیف‌تر می‌شود**.\n\n"
 "⚠️ **نتیجه: سفیکسیم عملاً روی استافیلوکوک اورئوس بی‌اثر است** و روی استرپتوکوک هم قابل اتکا نیست. یعنی دقیقاً همان **دو ارگانیسمی** را از دست می‌دهد که تمام عفونت پوستی را می‌سازند.\n\n"
 "**قاعده‌ای که باید با خود ببرید: در عفونت پوست و بافت نرم، سفالوسپورین نسل اول بهتر از نسل سوم است.**\n\n"
 "**سفازولین** (تزریقی) و **سفالکسین** (خوراکی) انتخاب‌های درست‌اند — نه سفیکسیم و نه سفتریاکسون. این نکته در همین فصل **چهار بار** پرسیده شده و پرتکرارترین تله‌ی این بلوک است.",
 "A 26-YEAR-OLD with pain, redness, swelling and warmth of the mid-forearm — SIMPLE CELLULITIS. His oral temperature is 37, so he is NOT TOXIC and oral outpatient therapy suffices.\n\n"
 "THE OTHER THREE OPTIONS ALL HAVE GOOD GRAM-POSITIVE COVER:\n\n"
 "OXACILLIN — a penicillinase-resistant penicillin, the classical drug for methicillin-sensitive staph\n"
 "ERYTHROMYCIN — a macrolide, a suitable alternative in penicillin allergy\n"
 "CLINDAMYCIN — strep, staph and even COMMUNITY-ACQUIRED MRSA\n\n"
 "WARNING, THAT LEAVES CEFIXIME — AND THAT IS THE ANSWER.\n\n"
 "WHY IS CEFIXIME UNSUITABLE FOR A SKIN INFECTION?\n\n"
 "Cefixime is an ORAL THIRD-GENERATION CEPHALOSPORIN. And there is a general rule about cephalosporins you must know: AS THE GENERATION RISES, GRAM-NEGATIVE COVER IMPROVES AND GRAM-POSITIVE COVER WEAKENS.\n\n"
 "WARNING, THE CONSEQUENCE: CEFIXIME IS ESSENTIALLY INACTIVE AGAINST STAPHYLOCOCCUS AUREUS and unreliable against streptococci. It misses precisely the TWO ORGANISMS that cause all of skin infection.\n\n"
 "THE RULE TO TAKE AWAY: IN SKIN AND SOFT TISSUE INFECTION, A FIRST-GENERATION CEPHALOSPORIN BEATS A THIRD.\n\n"
 "CEFAZOLIN (intravenous) and CEPHALEXIN (oral) are the right choices — not cefixime, not ceftriaxone. This point is asked FOUR TIMES in this chapter and is the commonest trap in the block.",
 ["اگزاسیلین پنی‌سیلین مقاوم به پنی‌سیلیناز و داروی کلاسیک استاف حساس به متی‌سیلین است.",
  "پاسخ صحیح — سفیکسیم سفالوسپورین نسل سوم خوراکی است و پوشش گرم‌مثبت قابل اتکایی ندارد.",
  "اریترومایسین یک ماکرولید و جایگزین پذیرفته‌شده در آلرژی به پنی‌سیلین است.",
  "کلیندامایسین هم استرپ و هم استاف (و حتی MRSA جامعه) را پوشش می‌دهد و انتخاب مناسبی است."],
 ["Oxacillin is a penicillinase-resistant penicillin and the classical drug for methicillin-sensitive staph.",
  "Correct — cefixime is an oral third-generation cephalosporin with no reliable gram-positive cover.",
  "Erythromycin is a macrolide and an accepted alternative in penicillin allergy.",
  "Clindamycin covers both strep and staph (and even community MRSA) and is a suitable choice."],
 "عفونت پوست: **نسل اول (سفازولین/سفالکسین) بله، نسل سوم خوراکی (سفیکسیم) نه.**",
 "In skin infection: first-generation cephalosporins (cefazolin, cephalexin) yes; oral third-generation (cefixime) no.",
 [IDSA, H26])


# =========================================================== book:10
add("book:10", "case", "medium",
 "**لنفانژیت** (خط قرمز به سمت پروگزیمال) ← **استرپتوکوک پیوژن**.",
 "LYMPHANGITIS — a red streak running proximally — means STREPTOCOCCUS PYOGENES.",
 CELL_FA + [
  "بیمار **۲۵ ساله** با درد و تورم ساق، تب، و ضایعه‌ای به ابعاد ۳ سانتی‌متر.",
  "⚠️ **و یافته‌ی تعیین‌کننده: «یک خط قرمز برجسته‌ی دردناک که از پروگزیمال ضایعه تا نیمه‌ی ران ادامه دارد».**",
  "**این لنفانژیت است، و لنفانژیت تقریباً همیشه استرپتوکوکی است.**",
  "**چرا استرپتوکوک؟ به‌خاطر آنزیم‌هایش.**",
  "استرپتوکوک پیوژن **هیالورونیداز** («فاکتور انتشار») و **استرپتوکیناز** ترشح می‌کند،",
  "که **ماتریکس بین‌سلولی و فیبرین را تجزیه می‌کنند** و به باکتری اجازه‌ی **گسترش سریع در بافت** می‌دهند.",
  "پس عفونت به‌سرعت وارد **مجاری لنفاوی** می‌شود و آن‌ها را ملتهب می‌کند — همان خط قرمز.",
  "⚠️ **در مقابل، استافیلوکوک اورئوس کوآگولاز تولید می‌کند که فیبرین را لخته می‌کند.**",
  "**نتیجه: استاف عفونت را محدود و دیوارکشی می‌کند — یعنی آبسه می‌سازد، نه لنفانژیت.**",
  "**همین یک تفاوت آنزیمی، دو رفتار بالینی کاملاً متفاوت را توضیح می‌دهد:**",
  "**استرپ = گسترش (سلولیت منتشر، اریزیپل، لنفانژیت). استاف = تجمع (آبسه، فورونکل).**",
  "چرا پسودوموناس نه؟ در فرد **سالم و بدون تروما یا سوختگی**، پسودوموناس مطرح نیست.",
  "چرا آئروموناس نه؟ آن نیازمند **تماس با آب شیرین** است که در شرح حال نیامده.",
 ],
 CELL_EN + [
  "A 25-YEAR-OLD with pain and swelling of the leg, fever, and a 3 cm lesion.",
  "WARNING, AND THE DECISIVE FINDING: 'a tender raised red streak running from the lesion up to mid-thigh'.",
  "THIS IS LYMPHANGITIS, AND LYMPHANGITIS IS ALMOST ALWAYS STREPTOCOCCAL.",
  "WHY STREPTOCOCCUS? BECAUSE OF ITS ENZYMES.",
  "Streptococcus pyogenes secretes HYALURONIDASE (the 'spreading factor') and STREPTOKINASE,",
  "which BREAK DOWN INTERCELLULAR MATRIX AND FIBRIN and let the organism SPREAD RAPIDLY THROUGH TISSUE.",
  "So the infection quickly enters the LYMPHATICS and inflames them — that red streak.",
  "WARNING, BY CONTRAST STAPHYLOCOCCUS AUREUS PRODUCES COAGULASE, WHICH CLOTS FIBRIN.",
  "THE RESULT: staph WALLS THE INFECTION OFF — it makes an abscess, not lymphangitis.",
  "THAT SINGLE ENZYMATIC DIFFERENCE EXPLAINS TWO COMPLETELY DIFFERENT CLINICAL BEHAVIOURS:",
  "STREP MEANS SPREADING (diffuse cellulitis, erysipelas, lymphangitis). STAPH MEANS COLLECTION (abscess, furuncle).",
  "Why not Pseudomonas? In a HEALTHY person with no trauma or burn, Pseudomonas is not in the running.",
  "Why not Aeromonas? That requires FRESH WATER CONTACT, which the history does not mention.",
 ],
 "بیمار **۲۵ ساله** با درد و تورم ساق، تب، و ضایعه‌ای به ابعاد ۳ سانتی‌متر مراجعه کرده است.\n\n"
 "⚠️ **و یافته‌ای که تشخیص را می‌گذارد: «یک خط قرمز برجسته‌ی دردناک که از پروگزیمال ضایعه شروع و تا نیمه‌ی ران ادامه دارد».**\n\n"
 "**این لنفانژیت است — و لنفانژیت تقریباً همیشه استرپتوکوکی است.**\n\n"
 "**اما چرا؟ پاسخ در آنزیم‌های این دو باکتری است، و این زیباترین درس میکروبیولوژی بالینی در کل فصل است:**\n\n"
 "**استرپتوکوک پیوژن** آنزیم‌های **هیالورونیداز** (که به آن «فاکتور انتشار» می‌گویند) و **استرپتوکیناز** ترشح می‌کند. این آنزیم‌ها **ماتریکس بین‌سلولی و فیبرین را تجزیه می‌کنند** و به باکتری اجازه می‌دهند **به‌سرعت در بافت پخش شود**. پس عفونت وارد **مجاری لنفاوی** می‌شود و آن‌ها را ملتهب می‌کند — همان خط قرمزی که در معاینه می‌بینیم.\n\n"
 "⚠️ **در مقابل، استافیلوکوک اورئوس کوآگولاز تولید می‌کند، که دقیقاً کار معکوس می‌کند: فیبرین را لخته می‌کند.** نتیجه این است که استاف عفونت را **محدود و دیوارکشی** می‌کند.\n\n"
 "**پس همین یک تفاوت آنزیمی، دو رفتار بالینی کاملاً متفاوت را می‌سازد:**\n\n"
 "**استرپتوکوک = گسترش** ← سلولیت منتشر، اریزیپل، لنفانژیت\n"
 "**استافیلوکوک = تجمع** ← آبسه، فورونکل، کاربونکل\n\n"
 "**چرا گزینه‌های دیگر رد می‌شوند؟** **پسودوموناس** در فرد سالم و بدون تروما یا سوختگی مطرح نیست. **آئروموناس هیدروفیلا** نیازمند **تماس با آب شیرین** است که در شرح حال ذکری از آن نشده.",
 "A 25-YEAR-OLD presents with pain and swelling of the leg, fever, and a 3 cm lesion.\n\n"
 "WARNING, AND THE FINDING THAT MAKES THE DIAGNOSIS: 'a tender raised red streak running from the lesion up to mid-thigh'.\n\n"
 "THIS IS LYMPHANGITIS — AND LYMPHANGITIS IS ALMOST ALWAYS STREPTOCOCCAL.\n\n"
 "BUT WHY? The answer lies in the enzymes of the two organisms, and it is the most elegant lesson in clinical microbiology in the whole chapter:\n\n"
 "STREPTOCOCCUS PYOGENES secretes HYALURONIDASE (called the 'spreading factor') and STREPTOKINASE. These enzymes BREAK DOWN INTERCELLULAR MATRIX AND FIBRIN and let the organism SPREAD RAPIDLY THROUGH TISSUE. The infection therefore enters the LYMPHATICS and inflames them — the red streak we see on examination.\n\n"
 "WARNING, BY CONTRAST STAPHYLOCOCCUS AUREUS PRODUCES COAGULASE, which does exactly the opposite: IT CLOTS FIBRIN. The result is that staph WALLS THE INFECTION OFF.\n\n"
 "SO THAT SINGLE ENZYMATIC DIFFERENCE CREATES TWO COMPLETELY DIFFERENT CLINICAL BEHAVIOURS:\n\n"
 "STREPTOCOCCUS EQUALS SPREADING — diffuse cellulitis, erysipelas, lymphangitis\n"
 "STAPHYLOCOCCUS EQUALS COLLECTION — abscess, furuncle, carbuncle\n\n"
 "WHY THE OTHER OPTIONS FAIL? PSEUDOMONAS is not considered in a healthy person without trauma or burns. AEROMONAS HYDROPHILA requires FRESH WATER CONTACT, which the history does not mention.",
 ["استاف اورئوس کوآگولاز تولید می‌کند و عفونت را دیوارکشی می‌کند؛ آبسه می‌سازد نه لنفانژیت.",
  "پاسخ صحیح — لنفانژیت به‌علت آنزیم‌های انتشاردهنده‌ی استرپتوکوک پیوژن (هیالورونیداز) رخ می‌دهد.",
  "پسودوموناس در فرد سالم بدون تروما، سوختگی یا نوتروپنی مطرح نیست.",
  "آئروموناس هیدروفیلا نیازمند تماس با آب شیرین است که در شرح حال این بیمار وجود ندارد."],
 ["Staph aureus produces coagulase and walls infection off; it makes an abscess, not lymphangitis.",
  "Correct — lymphangitis results from the spreading enzymes of Streptococcus pyogenes (hyaluronidase).",
  "Pseudomonas is not considered in a healthy person without trauma, burns or neutropenia.",
  "Aeromonas hydrophila requires fresh water contact, which is absent from this history."],
 "**استرپ = گسترش** (هیالورونیداز) ← لنفانژیت. **استاف = تجمع** (کوآگولاز) ← آبسه.",
 "Strep spreads (hyaluronidase) and causes lymphangitis. Staph collects (coagulase) and causes abscesses.",
 [H143, IDSA])


# =========================================================== book:17
add("book:17", "case", "hard",
 "گازگرفتگی سگ در بیمار **اسپلنکتومی** + کوکوباسیل گرم‌منفی ← **کاپنوسیتوفاگا کانیمورسوس**.",
 "A dog bite in an ASPLENIC patient with a gram-negative coccobacillus means CAPNOCYTOPHAGA CANIMORSUS.",
 WATER_FA + [
  "⚠️ **توجه: علائم حیاتی این سؤال تصحیح شده است** (تاکی‌کاردی ۱۱۰ و تاکی‌پنه ۲۶ در دقیقه).",
  "متن استخراج‌شده «min011» و «min26» داشت که اصلاً یک میزان نیستند.",
  "**سه سرنخ در این سؤال هست و هر سه به یک ارگانیسم می‌رسند:**",
  "**یک — اسپلنکتومی.** **دو — گازگرفتگی سگ.** **سه — کوکوباسیل گرم‌منفی در کشت خون.**",
  "⚠️ **کاپنوسیتوفاگا کانیمورسوس بخشی از فلور طبیعی دهان سگ و گربه است.**",
  "در فرد **سالم** معمولاً بی‌آزار است، ولی در فرد **بی‌طحال** فاجعه می‌سازد.",
  "**چرا در بی‌طحال؟ همان منطق پنوموکوک، ولی برای یک گرم‌منفی:**",
  "طحال **فیلتر اصلی خون برای باکتری‌های اپسونیزه** است و **IgM ضدپلی‌ساکارید** می‌سازد.",
  "بدون طحال، باکتری در خون **بی‌مانع تکثیر می‌شود** و ظرف ساعت‌ها به شوک می‌رسد.",
  "**تابلوی مشخصه‌ی این سؤال را ببینید:** تب شدید، **لکوسیتوز ۱۳ هزار**، تاکی‌کاردی ۱۱۰،",
  "تاکی‌پنه ۲۶، **ترومبوسیتوپنی ۶۰ هزار**، **بولاهای هموراژیک** و **شوک سپتیک**.",
  "⚠️ **ترومبوسیتوپنی + بولای هموراژیک + شوک = DIC**، و کاپنوسیتوفاگا کلاسیک آن است.",
  "**درمان: آموکسی‌سیلین-کلاوولانات، یا در بیمار بدحال کارباپنم/پیپراسیلین-تازوباکتام.**",
  "چرا ویبریو ولنیفیکوس نه؟ آن **صدف خام یا آب شور** می‌خواهد، نه گازگرفتگی سگ.",
  "چرا استاف اورئوس نه؟ استاف **گرم‌مثبت** است، و کشت **گرم‌منفی** گزارش شده.",
  "⚠️ **و نکته‌ی پیشگیری: هر بیمار اسپلنکتومی‌شده پس از گازگرفتگی سگ باید**",
  "**بدون استثنا پروفیلاکسی با آموکسی‌سیلین-کلاوولانات بگیرد** — حتی برای زخم جزئی.",
 ],
 WATER_EN + [
  "WARNING, NOTE: THE VITAL SIGNS OF THIS QUESTION HAVE BEEN CORRECTED (tachycardia 110 and respiratory rate 26).",
  "The extracted text read 'min011' and 'min26', which are not rates at all.",
  "THERE ARE THREE CLUES HERE AND ALL THREE CONVERGE ON ONE ORGANISM:",
  "ONE — SPLENECTOMY. TWO — A DOG BITE. THREE — A GRAM-NEGATIVE COCCOBACILLUS IN THE BLOOD CULTURE.",
  "WARNING: CAPNOCYTOPHAGA CANIMORSUS IS PART OF THE NORMAL ORAL FLORA OF DOGS AND CATS.",
  "In a HEALTHY person it is usually harmless; in an ASPLENIC person it is catastrophic.",
  "WHY IN THE ASPLENIC? The same logic as the pneumococcus, but for a gram-negative:",
  "the spleen is THE MAIN BLOOD FILTER FOR OPSONISED BACTERIA and makes ANTI-POLYSACCHARIDE IgM.",
  "Without it, the organism MULTIPLIES UNCHECKED in the blood and reaches shock within hours.",
  "LOOK AT THE PICTURE IN THIS QUESTION: high fever, LEUCOCYTOSIS OF 13,000, tachycardia 110,",
  "respiratory rate 26, THROMBOCYTOPENIA OF 60,000, HAEMORRHAGIC BULLAE and SEPTIC SHOCK.",
  "WARNING: THROMBOCYTOPENIA PLUS HAEMORRHAGIC BULLAE PLUS SHOCK MEANS DIC, and Capnocytophaga is its classic cause.",
  "TREATMENT: AMOXICILLIN-CLAVULANATE, or in a sick patient a carbapenem or piperacillin-tazobactam.",
  "Why not Vibrio vulnificus? That needs RAW SHELLFISH OR SALT WATER, not a dog bite.",
  "Why not Staph aureus? Staph is GRAM-POSITIVE, and the culture reports a GRAM-NEGATIVE.",
  "WARNING, AND A PREVENTIVE POINT: EVERY ASPLENIC PATIENT AFTER A DOG BITE MUST",
  "RECEIVE AMOXICILLIN-CLAVULANATE PROPHYLAXIS WITHOUT EXCEPTION — even for a trivial wound.",
 ],
 "⚠️ **پیش از هر چیز: علائم حیاتی این سؤال تصحیح شده است.** متن استخراج‌شده «تاکی‌کاردی min011» و «تاکی‌پنه min26» داشت که اصلاً یک میزان نیستند؛ صفحه‌ی ۷ کتاب **۱۱۰** و **۲۶** چاپ کرده است. این تاکی‌کاردی و تاکی‌پنه بخشی از شواهد سپسیس‌اند و بدون آن‌ها، بدحالی بیمار از سؤال حذف می‌شد.\n\n"
 "**سه سرنخ در این سؤال هست و هر سه به یک ارگانیسم می‌رسند:**\n\n"
 "**۱. اسپلنکتومی** — **۲. گازگرفتگی سگ** — **۳. کوکوباسیل گرم‌منفی در کشت خون**\n\n"
 "⚠️ **کاپنوسیتوفاگا کانیمورسوس بخشی از فلور طبیعی دهان سگ است.** در فرد سالم معمولاً بی‌آزار است، ولی در فرد **بی‌طحال** فاجعه می‌سازد.\n\n"
 "**چرا در بی‌طحال؟** همان منطق OPSI که در پنوموکوک آموختید، ولی این‌بار برای یک **گرم‌منفی**: طحال **فیلتر اصلی خون برای باکتری‌های اپسونیزه‌شده** است و **IgM ضدپلی‌ساکارید** می‌سازد. بدون طحال، باکتری در خون **بی‌مانع تکثیر می‌شود** و ظرف ساعت‌ها بیمار را به شوک می‌رساند.\n\n"
 "**حالا تابلوی بالینی را ببینید و ببینید چقدر دقیق می‌خواند:**\n\n"
 "تب شدید، **لکوسیتوز ۱۳ هزار**، تاکی‌کاردی **۱۱۰**، تاکی‌پنه **۲۶**، **ترومبوسیتوپنی ۶۰ هزار**، **بولاهای هموراژیک** روی پوست، و **شوک سپتیک**.\n\n"
 "⚠️ **ترومبوسیتوپنی + بولای هموراژیک + شوک = DIC** — و کاپنوسیتوفاگا علت کلاسیک آن در فرد بی‌طحال است.\n\n"
 "**درمان:** آموکسی‌سیلین-کلاوولانات، یا در بیمار بدحال **کارباپنم یا پیپراسیلین-تازوباکتام**.\n\n"
 "**چرا بقیه رد می‌شوند؟** **ویبریو ولنیفیکوس** ← صدف خام یا آب شور می‌خواهد. **استاف اورئوس** ← **گرم‌مثبت** است، ولی کشت **گرم‌منفی** گزارش شده. **پسودوموناس** ← پاتوژن نوتروپنی و سوختگی است.\n\n"
 "⚠️ **و نکته‌ی پیشگیری که جان می‌خرد:** هر بیمار اسپلنکتومی‌شده پس از گازگرفتگی سگ باید **بدون استثنا** پروفیلاکسی آنتی‌بیوتیکی بگیرد — حتی اگر زخم جزئی به نظر برسد.",
 "WARNING, FIRST: THE VITAL SIGNS OF THIS QUESTION HAVE BEEN CORRECTED. The extracted text read 'tachycardia min011' and 'tachypnoea min26', which are not rates at all; page 7 prints 110 and 26. That tachycardia and tachypnoea are part of the evidence of sepsis, and without them the patient's severity vanished from the question.\n\n"
 "THERE ARE THREE CLUES AND ALL THREE CONVERGE ON ONE ORGANISM:\n\n"
 "1. SPLENECTOMY — 2. A DOG BITE — 3. A GRAM-NEGATIVE COCCOBACILLUS IN THE BLOOD CULTURE\n\n"
 "WARNING: CAPNOCYTOPHAGA CANIMORSUS IS PART OF THE NORMAL ORAL FLORA OF DOGS. In a healthy person it is usually harmless; in an ASPLENIC person it is catastrophic.\n\n"
 "WHY IN THE ASPLENIC? The same OPSI logic you learned with the pneumococcus, but this time for a GRAM-NEGATIVE: the spleen is THE MAIN BLOOD FILTER FOR OPSONISED BACTERIA and makes ANTI-POLYSACCHARIDE IgM. Without it the organism MULTIPLIES UNCHECKED and drives the patient into shock within hours.\n\n"
 "NOW LOOK AT THE CLINICAL PICTURE AND SEE HOW PRECISELY IT FITS:\n\n"
 "High fever, LEUCOCYTOSIS OF 13,000, tachycardia 110, respiratory rate 26, THROMBOCYTOPENIA OF 60,000, HAEMORRHAGIC BULLAE on the skin, and SEPTIC SHOCK.\n\n"
 "WARNING: THROMBOCYTOPENIA PLUS HAEMORRHAGIC BULLAE PLUS SHOCK MEANS DIC — and Capnocytophaga is its classic cause in the asplenic.\n\n"
 "TREATMENT: amoxicillin-clavulanate, or in a sick patient A CARBAPENEM OR PIPERACILLIN-TAZOBACTAM.\n\n"
 "WHY THE OTHERS FAIL? VIBRIO VULNIFICUS needs raw shellfish or salt water. STAPH AUREUS is GRAM-POSITIVE, but the culture reports a GRAM-NEGATIVE. PSEUDOMONAS is the pathogen of neutropenia and burns.\n\n"
 "WARNING, AND A PREVENTIVE POINT THAT SAVES LIVES: every asplenic patient after a dog bite must receive antibiotic prophylaxis WITHOUT EXCEPTION — even if the wound looks trivial.",
 ["ویبریو ولنیفیکوس با صدف خام یا آب شور مطرح می‌شود، نه با گازگرفتگی سگ.",
  "پاسخ صحیح — کاپنوسیتوفاگا کانیمورسوس، کوکوباسیل گرم‌منفی فلور دهان سگ، در فرد بی‌طحال سپسیس فولمینانت می‌سازد.",
  "استافیلوکوک اورئوس گرم‌مثبت است، در حالی که کشت خون کوکوباسیل گرم‌منفی گزارش کرده است.",
  "پسودوموناس آئروژینوزا پاتوژن نوتروپنی، سوختگی و بستری طولانی است، نه گازگرفتگی سگ."],
 ["Vibrio vulnificus is considered with raw shellfish or salt water, not with a dog bite.",
  "Correct — Capnocytophaga canimorsus, a gram-negative coccobacillus of canine oral flora, causes fulminant sepsis in the asplenic.",
  "Staphylococcus aureus is gram-positive, whereas the blood culture reports a gram-negative coccobacillus.",
  "Pseudomonas aeruginosa is the pathogen of neutropenia, burns and prolonged admission, not dog bites."],
 "**سگ + بی‌طحال + گرم‌منفی = کاپنوسیتوفاگا.** هر گازگرفتگی در بی‌طحال ← **پروفیلاکسی الزامی**.",
 "Dog plus asplenia plus a gram-negative means Capnocytophaga. Any bite in an asplenic patient requires prophylaxis.",
 [H26, IDSA])


# =========================================================== book:20
add("book:20", "recall", "medium",
 "**اریزیپلوتریکس ذاتاً به وانکومایسین مقاوم است** — این استثنای شناخته‌شده را بدانید.",
 "ERYSIPELOTHRIX IS INTRINSICALLY RESISTANT TO VANCOMYCIN — know this famous exception.",
 WATER_FA + [
  "جوان **ماهی‌فروش** با تورم و قرمزی دست پس از **زخم هنگام پاک کردن ماهی**.",
  "**این تابلوی اریزیپلوئید (erysipeloid) است، بیماری اریزیپلوتریکس روزیوپاتیه.**",
  "**ارگانیسم را بشناسید: باسیل گرم‌مثبت، بدون اسپور، بی‌هوازی اختیاری.**",
  "**مخزنش حیوانات است** — به‌ویژه خوک، ماهی، صدف و طیور.",
  "**پس شغل‌های در معرض: ماهی‌فروش، قصاب، کارگر کشتارگاه، دامپزشک، آشپز.**",
  "**تابلوی بالینی‌اش سه شکل دارد:**",
  "**یک — اریزیپلوئید موضعی (شایع‌ترین):** ضایعه‌ی **بنفش-قرمز** روی انگشت یا دست،",
  "با حاشیه‌ی مشخص، **بدون چرک**، دردناک و **به‌کندی گسترش‌یابنده**.",
  "⚠️ **نبودِ چرک نکته‌ی افتراقی مهمی است** و آن را از سلولیت استافیلوکوکی جدا می‌کند.",
  "**دو — شکل منتشر پوستی.** **سه — شکل سیستمیک با اندوکاردیت** (نادر ولی جدی).",
  "⚠️ **و حالا نکته‌ی اصلی این سؤال: اریزیپلوتریکس ذاتاً به وانکومایسین مقاوم است.**",
  "**چرا؟** چون **پپتیدوگلیکان دیواره‌اش با لیزین به هم متصل است، نه با DAP**،",
  "و وانکومایسین که به انتهای **D-Ala-D-Ala** می‌چسبد، در این ساختار مؤثر نیست.",
  "**همین نکته آن را به یک سؤال امتحانی محبوب تبدیل کرده**، چون وانکومایسین معمولاً",
  "«داروی همه‌ی گرم‌مثبت‌های سخت» تصور می‌شود — و اینجا دقیقاً آن تصور غلط سنجیده می‌شود.",
  "**درمان درست: پنی‌سیلین** (داروی انتخابی)؛ **سفالوسپورین، کلیندامایسین و کینولون** هم مؤثرند.",
 ],
 WATER_EN + [
  "A young FISHMONGER with swelling and redness of the hand after A CUT WHILE CLEANING FISH.",
  "THIS IS ERYSIPELOID, the disease of Erysipelothrix rhusiopathiae.",
  "KNOW THE ORGANISM: a gram-positive, non-sporing, facultatively anaerobic bacillus.",
  "ITS RESERVOIR IS ANIMALS — especially pigs, fish, shellfish and poultry.",
  "SO THE EXPOSED TRADES ARE: fishmonger, butcher, abattoir worker, vet, cook.",
  "ITS CLINICAL PICTURE HAS THREE FORMS:",
  "ONE — LOCALISED ERYSIPELOID (the commonest): a VIOLACEOUS-RED lesion on finger or hand,",
  "sharply marginated, WITHOUT PUS, painful and SLOWLY SPREADING.",
  "WARNING, THE ABSENCE OF PUS IS AN IMPORTANT DISCRIMINATOR that separates it from staphylococcal cellulitis.",
  "TWO — A DIFFUSE CUTANEOUS FORM. THREE — A SYSTEMIC FORM WITH ENDOCARDITIS (rare but serious).",
  "WARNING, AND NOW THE POINT OF THIS QUESTION: ERYSIPELOTHRIX IS INTRINSICALLY RESISTANT TO VANCOMYCIN.",
  "WHY? Because ITS CELL WALL PEPTIDOGLYCAN IS CROSS-LINKED THROUGH LYSINE RATHER THAN DAP,",
  "and vancomycin, which binds the D-Ala-D-Ala terminus, is ineffective against that structure.",
  "THIS IS WHY IT IS A FAVOURITE EXAM QUESTION: vancomycin is usually imagined as",
  "'the drug for every difficult gram-positive' — and this is exactly the misconception being tested.",
  "THE RIGHT TREATMENT: PENICILLIN (drug of choice); cephalosporins, clindamycin and quinolones also work.",
 ],
 "جوان **ماهی‌فروش** با تورم و قرمزی وسیع دست پس از **زخمی شدن هنگام پاک کردن ماهی** بستری شده است. **این تابلوی اریزیپلوئید است** — بیماری **اریزیپلوتریکس روزیوپاتیه**.\n\n"
 "**اول ارگانیسم را بشناسید:** باسیل **گرم‌مثبت**، بدون اسپور، بی‌هوازی اختیاری. مخزنش **حیوانات** است — به‌ویژه خوک، ماهی، صدف و طیور. پس شغل‌های در معرض: **ماهی‌فروش، قصاب، کارگر کشتارگاه، دامپزشک، آشپز**.\n\n"
 "**تابلوی موضعی‌اش مشخص است:** ضایعه‌ی **بنفش-قرمز** روی انگشت یا دست، با حاشیه‌ی مشخص، دردناک، و ⚠️ **بدون چرک** — همین نبودِ چرک نکته‌ی افتراقی مهمی است که آن را از سلولیت استافیلوکوکی جدا می‌کند.\n\n"
 "⚠️ **و حالا نکته‌ی اصلی این سؤال، که یکی از معروف‌ترین استثناهای میکروبیولوژی است:**\n\n"
 "**اریزیپلوتریکس ذاتاً به وانکومایسین مقاوم است.**\n\n"
 "**چرا؟** چون **پپتیدوگلیکان دیواره‌ی سلولی‌اش با لیزین به هم متصل شده، نه با DAP**. وانکومایسین با چسبیدن به انتهای **D-Ala-D-Ala** کار می‌کند، و در این ساختار متفاوت اثری ندارد.\n\n"
 "**و دقیقاً به همین دلیل سؤال امتحانی محبوبی شده است:** در ذهن بیشتر دانشجویان، وانکومایسین «داروی همه‌ی گرم‌مثبت‌های سخت» است. این سؤال همان تصور غلط را می‌سنجد.\n\n"
 "**درمان درست:** **پنی‌سیلین** داروی انتخابی است؛ **سفالوسپورین، کلیندامایسین و فلوروکینولون** هم مؤثرند — یعنی هر سه گزینه‌ی دیگر سؤال قابل قبول‌اند.",
 "A young FISHMONGER is admitted with swelling and extensive redness of the hand after CUTTING HIMSELF WHILE CLEANING FISH. THIS IS ERYSIPELOID — the disease of ERYSIPELOTHRIX RHUSIOPATHIAE.\n\n"
 "FIRST KNOW THE ORGANISM: a GRAM-POSITIVE, non-sporing, facultatively anaerobic bacillus. Its reservoir is ANIMALS — especially pigs, fish, shellfish and poultry. So the exposed trades are FISHMONGER, BUTCHER, ABATTOIR WORKER, VET, COOK.\n\n"
 "ITS LOCAL PICTURE IS DISTINCTIVE: a VIOLACEOUS-RED lesion on the finger or hand, sharply marginated, painful, and WARNING, WITHOUT PUS — that absence of pus is an important discriminator from staphylococcal cellulitis.\n\n"
 "WARNING, AND NOW THE POINT OF THIS QUESTION, one of the most famous exceptions in microbiology:\n\n"
 "ERYSIPELOTHRIX IS INTRINSICALLY RESISTANT TO VANCOMYCIN.\n\n"
 "WHY? Because ITS CELL WALL PEPTIDOGLYCAN IS CROSS-LINKED THROUGH LYSINE RATHER THAN DAP. Vancomycin works by binding the D-Ala-D-Ala terminus and has no effect on that different structure.\n\n"
 "AND THAT IS PRECISELY WHY IT IS A FAVOURITE EXAM QUESTION: in most students' minds vancomycin is 'the drug for every difficult gram-positive'. This question tests that very misconception.\n\n"
 "THE RIGHT TREATMENT: PENICILLIN is the drug of choice; CEPHALOSPORINS, CLINDAMYCIN AND FLUOROQUINOLONES also work — meaning all three other options are acceptable.",
 ["پاسخ صحیح — اریزیپلوتریکس ذاتاً به وانکومایسین مقاوم است و نباید از آن استفاده کرد.",
  "کلیندامایسین یکی از جایگزین‌های مؤثر در اریزیپلوئید است و منعی ندارد.",
  "سفازولین روی اریزیپلوتریکس مؤثر است و در آلرژی به پنی‌سیلین به کار می‌رود.",
  "پنی‌سیلین داروی انتخابی اریزیپلوئید است و دقیقاً همان چیزی است که باید تجویز شود."],
 ["Correct — Erysipelothrix is intrinsically resistant to vancomycin and it must not be used.",
  "Clindamycin is an effective alternative in erysipeloid and is not contraindicated.",
  "Cefazolin is active against Erysipelothrix and is used in penicillin allergy.",
  "Penicillin is the drug of choice for erysipeloid and is exactly what should be prescribed."],
 "**اریزیپلوتریکس ← پنی‌سیلین. وانکومایسین هرگز** (مقاومت ذاتی، پپتیدوگلیکان لیزینی).",
 "Erysipelothrix means penicillin. Never vancomycin: intrinsic resistance from lysine cross-linked peptidoglycan.",
 [IDSA, H26])


# =========================================================== book:23
add("book:23", "case", "medium",
 "**سیروز + صدف خام + تاول هموراژیک** ← **ویبریو ولنیفیکوس**.",
 "CIRRHOSIS plus RAW SHELLFISH plus HAEMORRHAGIC BULLAE means VIBRIO VULNIFICUS.",
 WATER_FA + [
  "بیمار **۵۵ ساله‌ی سیروتیک** پس از سفر به **قشم** و خوردن **صدف خام**،",
  "با تب، لرز، **افت فشار خون** و **ضایعات تاولی هموراژیک منتشر** آمده است.",
  "⚠️ **این سه‌گانه — سیروز، صدف خام، تاول هموراژیک — امضای ویبریو ولنیفیکوس است.**",
  "**ارگانیسم: باسیل گرم‌منفی خمیده‌ی هالوفیل** (نمک‌دوست) که در **آب شور گرم** زندگی می‌کند.",
  "**دو راه ابتلا دارد و هر دو پرسیده می‌شوند:**",
  "**یک — خوردن صدف خام** ← باکتریمی اولیه با ضایعات پوستی ثانویه (همین بیمار).",
  "**دو — تماس زخم با آب شور** ← عفونت زخم که می‌تواند نکروزان شود.",
  "⚠️ **و حالا مهم‌ترین سؤال: چرا سیروز؟**",
  "**دو مکانیسم، و هر دو را باید بدانید:**",
  "**یک — اضافه‌بار آهن.** ویبریو ولنیفیکوس برای رشد به **آهن آزاد** نیاز شدید دارد،",
  "و در سیروز (به‌ویژه با هموکروماتوز یا الکل) **آهن سرم و اشباع ترانسفرین بالاست**.",
  "**دو — اختلال عملکرد سیستم رتیکولواندوتلیال کبد** ← پاکسازی باکتری از خون مختل می‌شود.",
  "**نتیجه: باکتریمی سریع و شوک.** ⚠️ **مرگ‌ومیر در فرم باکتریمیک بیش از ۵۰ درصد است.**",
  "**درمان: داکسی‌سیکلین + سفتریاکسون** (یا سفوتاکسیم)، به‌علاوه‌ی **دبریدمان** در صورت نکروز.",
  "⚠️ **و توصیه‌ی پیشگیری: بیمار سیروتیک هرگز نباید صدف خام بخورد** — این را باید به بیمار گفت.",
 ],
 WATER_EN + [
  "A 55-YEAR-OLD CIRRHOTIC, after a trip to QESHM and eating RAW SHELLFISH,",
  "presents with fever, rigors, HYPOTENSION and DIFFUSE HAEMORRHAGIC BULLAE.",
  "WARNING: THAT TRIAD — CIRRHOSIS, RAW SHELLFISH, HAEMORRHAGIC BULLAE — IS THE SIGNATURE OF VIBRIO VULNIFICUS.",
  "THE ORGANISM: a curved gram-negative HALOPHILIC (salt-loving) bacillus living in WARM SALT WATER.",
  "IT HAS TWO ROUTES OF ENTRY AND BOTH GET ASKED:",
  "ONE — EATING RAW SHELLFISH: primary bacteraemia with secondary skin lesions (this patient).",
  "TWO — A WOUND EXPOSED TO SALT WATER: a wound infection that may become necrotising.",
  "WARNING, AND NOW THE KEY QUESTION: WHY CIRRHOSIS?",
  "TWO MECHANISMS, and you must know both:",
  "ONE — IRON OVERLOAD. Vibrio vulnificus has an intense requirement for FREE IRON,",
  "and in cirrhosis (especially with haemochromatosis or alcohol) SERUM IRON AND TRANSFERRIN SATURATION ARE HIGH.",
  "TWO — IMPAIRED HEPATIC RETICULOENDOTHELIAL FUNCTION, so clearance of bacteria from blood fails.",
  "THE RESULT: RAPID BACTERAEMIA AND SHOCK. WARNING, MORTALITY IN THE BACTERAEMIC FORM EXCEEDS 50 PER CENT.",
  "TREATMENT: DOXYCYCLINE PLUS CEFTRIAXONE (or cefotaxime), with DEBRIDEMENT if there is necrosis.",
  "WARNING, AND A PREVENTIVE POINT: A CIRRHOTIC MUST NEVER EAT RAW SHELLFISH — the patient must be told.",
 ],
 "بیمار **۵۵ ساله‌ی مبتلا به سیروز کبدی** پس از سفر به **قشم** و مصرف **صدف خام**، با تب، لرز، **افت فشار خون** و **ضایعات تاولی هموراژیک منتشر** مراجعه کرده است.\n\n"
 "⚠️ **این سه‌گانه — سیروز + صدف خام + تاول هموراژیک — امضای ویبریو ولنیفیکوس است.**\n\n"
 "**ارگانیسم:** باسیل **گرم‌منفی خمیده‌ی هالوفیل** (نمک‌دوست) که در **آب شور گرم** زندگی می‌کند. دو راه ابتلا دارد:\n\n"
 "**۱. خوردن صدف خام** ← باکتریمی اولیه با ضایعات پوستی ثانویه (بیمار ما)\n"
 "**۲. تماس زخم با آب شور** ← عفونت زخم که می‌تواند نکروزان شود\n\n"
 "⚠️ **و حالا مهم‌ترین بخش: چرا این بیماری در سیروتیک‌ها این‌قدر مرگبار است؟ دو مکانیسم:**\n\n"
 "**۱. اضافه‌بار آهن** — ویبریو ولنیفیکوس برای رشد نیاز شدیدی به **آهن آزاد** دارد. در سیروز (به‌ویژه با هموکروماتوز یا زمینه‌ی الکلی)، **آهن سرم و اشباع ترانسفرین بالاست** و عملاً سفره‌ای برای باکتری پهن می‌شود.\n\n"
 "**۲. اختلال سیستم رتیکولواندوتلیال کبد** — سلول‌های کوپفر کبد سیروتیک نمی‌توانند باکتری را از خون پاک کنند.\n\n"
 "**نتیجه: باکتریمی برق‌آسا و شوک.** ⚠️ **مرگ‌ومیر فرم باکتریمیک بیش از ۵۰ درصد است**، و همین آن را به یک فوریت واقعی تبدیل می‌کند.\n\n"
 "**درمان:** **داکسی‌سیکلین + سفتریاکسون** (یا سفوتاکسیم)، به‌علاوه‌ی **دبریدمان جراحی** اگر نکروز بافتی وجود داشته باشد.\n\n"
 "⚠️ **و توصیه‌ای که باید به هر بیمار سیروتیک داد: هرگز صدف خام نخورید.** این یک توصیه‌ی جانبی نیست؛ پیشگیری از بیماری‌ای است که نیمی از مبتلایانش را می‌کشد.",
 "A 55-YEAR-OLD WITH LIVER CIRRHOSIS, after a trip to QESHM and eating RAW SHELLFISH, presents with fever, rigors, HYPOTENSION and DIFFUSE HAEMORRHAGIC BULLAE.\n\n"
 "WARNING: THAT TRIAD — CIRRHOSIS PLUS RAW SHELLFISH PLUS HAEMORRHAGIC BULLAE — IS THE SIGNATURE OF VIBRIO VULNIFICUS.\n\n"
 "THE ORGANISM: a curved GRAM-NEGATIVE HALOPHILIC (salt-loving) bacillus living in WARM SALT WATER. It has two routes of entry:\n\n"
 "1. EATING RAW SHELLFISH — primary bacteraemia with secondary skin lesions (our patient)\n"
 "2. A WOUND EXPOSED TO SALT WATER — a wound infection that may become necrotising\n\n"
 "WARNING, AND NOW THE KEY PART: WHY IS THIS SO LETHAL IN CIRRHOTICS? Two mechanisms:\n\n"
 "1. IRON OVERLOAD — Vibrio vulnificus has an intense requirement for FREE IRON. In cirrhosis (especially with haemochromatosis or an alcoholic background) SERUM IRON AND TRANSFERRIN SATURATION ARE HIGH, effectively laying a table for the organism.\n\n"
 "2. IMPAIRED HEPATIC RETICULOENDOTHELIAL FUNCTION — the Kupffer cells of a cirrhotic liver cannot clear bacteria from the blood.\n\n"
 "THE RESULT: FULMINANT BACTERAEMIA AND SHOCK. WARNING, MORTALITY IN THE BACTERAEMIC FORM EXCEEDS 50 PER CENT, which makes it a true emergency.\n\n"
 "TREATMENT: DOXYCYCLINE PLUS CEFTRIAXONE (or cefotaxime), with SURGICAL DEBRIDEMENT if there is tissue necrosis.\n\n"
 "WARNING, AND THE ADVICE EVERY CIRRHOTIC MUST BE GIVEN: NEVER EAT RAW SHELLFISH. This is not a side note; it prevents a disease that kills half of those who get it.",
 ["پاسخ صحیح — سیروز، صدف خام و تاول هموراژیک، سه‌گانه‌ی کلاسیک ویبریو ولنیفیکوس است.",
  "کاپنوسیتوفاگا کانیمورسوس با گازگرفتگی سگ در فرد بی‌طحال مطرح می‌شود، نه با صدف خام.",
  "استافیلوکوک اورئوس این تابلوی باکتریمیک با تاول هموراژیک پس از صدف خام را نمی‌سازد.",
  "پسودوموناس آئروژینوزا پاتوژن نوتروپنی و سوختگی است و با مصرف صدف خام ارتباطی ندارد."],
 ["Correct — cirrhosis, raw shellfish and haemorrhagic bullae is the classic triad of Vibrio vulnificus.",
  "Capnocytophaga canimorsus is considered after a dog bite in an asplenic patient, not with raw shellfish.",
  "Staphylococcus aureus does not produce this bacteraemic picture with haemorrhagic bullae after shellfish.",
  "Pseudomonas aeruginosa is the pathogen of neutropenia and burns and is unrelated to raw shellfish."],
 "**سیروز + آب شور/صدف = ویبریو ولنیفیکوس** (آهن آزاد بالا). درمان: **داکسی + سفتریاکسون**.",
 "Cirrhosis plus salt water or shellfish means Vibrio vulnificus (high free iron). Treat with doxycycline plus ceftriaxone.",
 [IDSA, H26])


# =========================================================== book:24
add("book:24", "case", "hard",
 "درد شدید + شوک + پیشرفت سریع ← **فاشئیت نکروزان** ← **مشاوره‌ی جراحی برای دبریدمان**.",
 "Severe pain with shock and rapid progression means NECROTISING FASCIITIS: get a SURGICAL CONSULT FOR DEBRIDEMENT.",
 NEC_FA + [
  "بیمار **۲۸ ساله** پس از **فعالیت بدنی شدید**، با **درد شدید** و تورم ساق از دو روز پیش.",
  "⚠️ **حالا علائم حیاتی را بخوانید، چون تشخیص همان‌جاست:**",
  "**فشار خون ۹۵/۶۰** و **نبض ۱۱۵** — یعنی بیمار **در آستانه‌ی شوک** است.",
  "**لکوسیتوز با شیفت به چپ (۸۷٪ نوتروفیل)** و **کراتینین ۲/۱** — یعنی **نارسایی کلیه**.",
  "**این حجم از اختلال سیستمیک با یک سلولیت ساده نمی‌خواند.**",
  "⚠️ **و ترکیب «درد شدید + توکسیسیته سیستمیک + نارسایی ارگان» یعنی عفونت نکروزان تا خلاف آن ثابت شود.**",
  "**نکته‌ی اپیدمیولوژیک: فعالیت بدنی شدید یک عامل خطر شناخته‌شده است**،",
  "چون **میکروتروما و کوفتگی عضلانی**، بافت را مستعد کاشت باکتری از راه باکتریمی گذرا می‌کند.",
  "**پس چرا مشاوره‌ی جراحی و نه گزینه‌های دیگر؟**",
  "**«سونوگرافی کالرداپلر و هپارین»** ← این یعنی تشخیص **ترومبوز ورید عمقی**.",
  "ولی DVT **تب، لکوسیتوز ۸۷ درصدی، و نارسایی کلیه** نمی‌سازد، و هپارین در عفونت **بی‌فایده** است.",
  "⚠️ **و خطرناک‌تر: تأخیر برای سونوگرافی، ساعت‌های حیاتی را می‌سوزاند.**",
  "**«آنتی‌بیوتیک + اکو»** ← اندوکاردیت این تابلوی موضعی حاد را توضیح نمی‌دهد.",
  "**«آنتی‌بیوتیک + هپارین»** ← آنتی‌بیوتیک لازم است، ولی **بدون دبریدمان کافی نیست**.",
  "**دلیلش را بدانید: در بافت نکروتیک، خون‌رسانی قطع است و آنتی‌بیوتیک به محل نمی‌رسد.**",
  "⚠️ **مرگ‌ومیر فاشئیت نکروزان با تأخیر در جراحی به‌شدت بالا می‌رود** — هر ساعت اهمیت دارد.",
 ],
 NEC_EN + [
  "A 28-YEAR-OLD after STRENUOUS PHYSICAL EXERTION, with SEVERE PAIN and swelling of the leg for two days.",
  "WARNING, NOW READ THE VITAL SIGNS, BECAUSE THE DIAGNOSIS IS THERE:",
  "BLOOD PRESSURE 95/60 and PULSE 115 — the patient is ON THE EDGE OF SHOCK.",
  "LEUCOCYTOSIS WITH A LEFT SHIFT (87% neutrophils) and CREATININE 2.1 — RENAL IMPAIRMENT.",
  "THAT DEGREE OF SYSTEMIC DERANGEMENT DOES NOT FIT SIMPLE CELLULITIS.",
  "WARNING: SEVERE PAIN PLUS SYSTEMIC TOXICITY PLUS ORGAN FAILURE MEANS NECROTISING INFECTION UNTIL PROVEN OTHERWISE.",
  "AN EPIDEMIOLOGICAL POINT: STRENUOUS EXERCISE IS A RECOGNISED RISK FACTOR,",
  "because MICROTRAUMA AND MUSCLE BRUISING seed tissue from a transient bacteraemia.",
  "SO WHY A SURGICAL CONSULT RATHER THAN THE OTHER OPTIONS?",
  "'COLOUR DOPPLER AND HEPARIN' means diagnosing DEEP VEIN THROMBOSIS.",
  "But DVT does not cause FEVER, 87% NEUTROPHILS AND RENAL FAILURE, and heparin is USELESS in infection.",
  "WARNING, AND MORE DANGEROUS: WAITING FOR AN ULTRASOUND BURNS CRITICAL HOURS.",
  "'ANTIBIOTICS PLUS ECHO' — endocarditis does not explain this acute local picture.",
  "'ANTIBIOTICS PLUS HEPARIN' — antibiotics are needed, but WITHOUT DEBRIDEMENT THEY ARE NOT ENOUGH.",
  "KNOW WHY: IN NECROTIC TISSUE THE BLOOD SUPPLY IS GONE AND THE ANTIBIOTIC NEVER ARRIVES.",
  "WARNING: MORTALITY IN NECROTISING FASCIITIS RISES SHARPLY WITH SURGICAL DELAY — every hour counts.",
 ],
 "بیمار **۲۸ ساله** پس از **فعالیت بدنی شدید**، با **درد شدید** و تورم ناحیه‌ی فوقانی ساق از دو روز پیش مراجعه کرده است. در معاینه گرمی، تورم و اریتم دارد و تب خفیف.\n\n"
 "⚠️ **تا اینجا شبیه سلولیت است. اما علائم حیاتی و آزمایش‌ها را بخوانید، چون تشخیص همان‌جاست:**\n\n"
 "**فشار خون ۹۵/۶۰** و **نبض ۱۱۵** ← بیمار **در آستانه‌ی شوک** است\n"
 "**لکوسیتوز با شیفت به چپ (۸۷٪ نوتروفیل)** ← پاسخ التهابی شدید\n"
 "**کراتینین ۲/۱** ← **نارسایی کلیه**\n\n"
 "**این حجم از اختلال سیستمیک با یک سلولیت ساده نمی‌خواند.** ⚠️ **ترکیب «درد شدید + توکسیسیته سیستمیک + نارسایی ارگان» یعنی عفونت نکروزان، تا خلافش ثابت شود.**\n\n"
 "**و یک نکته‌ی اپیدمیولوژیک:** **فعالیت بدنی شدید** یک عامل خطر شناخته‌شده‌ی فاشئیت نکروزان استرپتوکوکی است، چون **میکروتروما و کوفتگی عضلانی** بافت را مستعد کاشت باکتری از راه یک باکتریمی گذرا می‌کند.\n\n"
 "**حالا چرا گزینه‌های دیگر رد می‌شوند؟**\n\n"
 "**«سونوگرافی کالرداپلر و شروع هپارین»** ← این یعنی فکر کردن به **DVT**. اما DVT **تب، نوتروفیلی ۸۷ درصدی و نارسایی کلیه** نمی‌سازد. ⚠️ و خطرناک‌تر اینکه **انتظار برای سونوگرافی، ساعت‌های حیاتی را می‌سوزاند**.\n\n"
 "**«آنتی‌بیوتیک + اکوکاردیوگرافی»** ← اندوکاردیت این تابلوی موضعی و حاد را توضیح نمی‌دهد.\n\n"
 "**«آنتی‌بیوتیک + هپارین»** ← آنتی‌بیوتیک لازم است، ولی **به‌تنهایی کافی نیست**. ⚠️ **دلیلش را بدانید: در بافت نکروتیک خون‌رسانی قطع شده و آنتی‌بیوتیک اصلاً به محل نمی‌رسد.** تنها راه، **برداشتن بافت مرده** است.\n\n"
 "**پس پاسخ: مشاوره‌ی جراحی جهت دبریدمان + شروع آنتی‌بیوتیک.** و به یاد داشته باشید که **مرگ‌ومیر فاشئیت نکروزان با هر ساعت تأخیر در جراحی بالا می‌رود**.",
 "A 28-YEAR-OLD after STRENUOUS PHYSICAL EXERTION presents with SEVERE PAIN and swelling of the upper calf for two days, with warmth, swelling, erythema and a low fever.\n\n"
 "WARNING, SO FAR IT RESEMBLES CELLULITIS. BUT READ THE VITAL SIGNS AND LABORATORY, BECAUSE THE DIAGNOSIS IS THERE:\n\n"
 "BLOOD PRESSURE 95/60 and PULSE 115 — the patient is ON THE EDGE OF SHOCK\n"
 "LEUCOCYTOSIS WITH A LEFT SHIFT (87% neutrophils) — an intense inflammatory response\n"
 "CREATININE 2.1 — RENAL IMPAIRMENT\n\n"
 "THAT DEGREE OF SYSTEMIC DERANGEMENT DOES NOT FIT SIMPLE CELLULITIS. WARNING: SEVERE PAIN PLUS SYSTEMIC TOXICITY PLUS ORGAN FAILURE MEANS NECROTISING INFECTION UNTIL PROVEN OTHERWISE.\n\n"
 "AND AN EPIDEMIOLOGICAL POINT: STRENUOUS EXERTION is a recognised risk factor for streptococcal necrotising fasciitis, because MICROTRAUMA AND MUSCLE BRUISING seed the tissue from a transient bacteraemia.\n\n"
 "NOW WHY DO THE OTHER OPTIONS FAIL?\n\n"
 "'COLOUR DOPPLER AND HEPARIN' means thinking of DVT. But DVT does not produce FEVER, 87% NEUTROPHILIA AND RENAL FAILURE. WARNING, and more dangerously, WAITING FOR THE ULTRASOUND BURNS CRITICAL HOURS.\n\n"
 "'ANTIBIOTICS PLUS ECHOCARDIOGRAPHY' — endocarditis does not explain this acute local picture.\n\n"
 "'ANTIBIOTICS PLUS HEPARIN' — antibiotics are needed but ARE NOT ENOUGH ALONE. WARNING, KNOW WHY: IN NECROTIC TISSUE THE BLOOD SUPPLY IS GONE AND THE ANTIBIOTIC NEVER REACHES THE SITE. The only remedy is REMOVING THE DEAD TISSUE.\n\n"
 "SO THE ANSWER IS: SURGICAL CONSULT FOR DEBRIDEMENT PLUS ANTIBIOTICS. And remember that MORTALITY IN NECROTISING FASCIITIS RISES WITH EVERY HOUR OF SURGICAL DELAY.",
 ["ترومبوز ورید عمقی تب، نوتروفیلی ۸۷ درصدی و نارسایی کلیه نمی‌سازد؛ انتظار برای سونوگرافی وقت حیاتی را می‌سوزاند.",
  "پاسخ صحیح — درد شدید با توکسیسیته سیستمیک و نارسایی کلیه یعنی عفونت نکروزان؛ دبریدمان فوری لازم است.",
  "اندوکاردیت این تابلوی حاد و موضعی را توضیح نمی‌دهد و اکو تصمیم فوری را عوض نمی‌کند.",
  "آنتی‌بیوتیک لازم است ولی در بافت نکروتیک به محل نمی‌رسد؛ هپارین هم در عفونت جایی ندارد."],
 ["Deep vein thrombosis does not cause fever, 87% neutrophilia and renal failure; waiting for ultrasound wastes critical time.",
  "Correct — severe pain with systemic toxicity and renal failure means necrotising infection; urgent debridement is required.",
  "Endocarditis does not explain this acute local picture, and echo does not change the immediate decision.",
  "Antibiotics are needed but cannot reach necrotic tissue; heparin has no role in infection."],
 "**درد نامتناسب + توکسیسیته = اتاق عمل.** تصویربرداری **نباید** جراحی را به تأخیر بیندازد.",
 "Pain out of proportion plus toxicity means the operating theatre. Imaging must not delay surgery.",
 [IDSA, H26])


# =========================================================== book:25
add("book:25", "case", "hard",
 "دیابتی با شوک و درد شدید ران ← **اکسپلور جراحی سریع + آنتی‌بیوتیک وسیع با کلیندامایسین**.",
 "A diabetic in shock with severe thigh pain needs RAPID SURGICAL EXPLORATION plus broad antibiotics INCLUDING CLINDAMYCIN.",
 NEC_FA + [
  "⚠️ **توجه: درجه حرارت این سؤال تصحیح شده است** — صفحه‌ی ۱۰ عدد **۳۸/۳** چاپ کرده،",
  "و متن استخراج‌شده «۸۳ درجه» داشت که با حیات سازگار نیست.",
  "**بیمار: خانم ۵۰ ساله‌ی دیابتی، با شرح حال ظاهراً بی‌خطرِ «کشیدگی عضله‌ی ران».**",
  "⚠️ **و همین «شرح حال بی‌خطر» تله‌ی سؤال است.**",
  "**علائم حیاتی را بخوانید: فشار خون ۸۰/۵۰، نبض ۱۱۰، تنفس ۳۰، تب ۳۸/۳.**",
  "**این شوک سپتیک است**، و در معاینه فقط «اریتم مختصر با تندرنس شدید» دیده می‌شود.",
  "**همین ناهماهنگی — پوست تقریباً سالم ولی بیمار در شوک — تعریف فاشئیت نکروزان است.**",
  "⚠️ **دیابت مهم‌ترین عامل خطر آن است**، به سه دلیل:",
  "**نوروپاتی** (درد و زخم دیرتر حس می‌شود)، **بیماری عروق محیطی** (خون‌رسانی و اکسیژن کم)،",
  "و **اختلال عملکرد نوتروفیل** در هیپرگلیسمی.",
  "**حالا گزینه‌ها را بسنجید — و به یک اصل توجه کنید: هر گزینه‌ای بدون جراحی، غلط است.**",
  "**«سونوگرافی بافت نرم + سه آنتی‌بیوتیک»** ← تصویربرداری به‌جای جراحی؛ تأخیر کشنده.",
  "**«مروپنم + وانکومایسین»** ← پوشش وسیعی است ولی **بدون جراحی** و **بدون کلیندامایسین**.",
  "**«سفتریاکسون + کلیندامایسین + اکسپلور»** ← جراحی دارد و کلیندامایسین هم،",
  "⚠️ ولی **سفتریاکسون پوشش MRSA و بی‌هوازی و پسودوموناس ندارد** — در فاشئیت پلی‌میکروبیال ناکافی است.",
  "**پس پاسخ: وانکومایسین + کلیندامایسین + سیپروفلوکساسین + اکسپلور جراحی سریع.**",
  "**وانکومایسین برای MRSA، سیپروفلوکساسین برای گرم‌منفی‌ها، و کلیندامایسین برای مهار توکسین.**",
 ],
 NEC_EN + [
  "WARNING, NOTE: THE TEMPERATURE IN THIS QUESTION HAS BEEN CORRECTED — page 10 prints 38.3,",
  "and the extracted text read '83 degrees', which is incompatible with life.",
  "THE PATIENT: a 50-year-old diabetic woman with the apparently innocent history of 'a pulled thigh muscle'.",
  "WARNING, AND THAT INNOCENT HISTORY IS THE TRAP OF THE QUESTION.",
  "READ THE VITAL SIGNS: BLOOD PRESSURE 80/50, PULSE 110, RESPIRATORY RATE 30, TEMPERATURE 38.3.",
  "THIS IS SEPTIC SHOCK, and on examination there is only 'mild erythema with marked tenderness'.",
  "THAT MISMATCH — NEARLY NORMAL SKIN IN A SHOCKED PATIENT — IS THE DEFINITION OF NECROTISING FASCIITIS.",
  "WARNING: DIABETES IS ITS MOST IMPORTANT RISK FACTOR, for three reasons:",
  "NEUROPATHY (pain and ulcers are felt late), PERIPHERAL VASCULAR DISEASE (poor perfusion and oxygen),",
  "and IMPAIRED NEUTROPHIL FUNCTION in hyperglycaemia.",
  "NOW WEIGH THE OPTIONS — and note one principle: ANY OPTION WITHOUT SURGERY IS WRONG.",
  "'SOFT TISSUE ULTRASOUND PLUS THREE ANTIBIOTICS' — imaging instead of surgery; a lethal delay.",
  "'MEROPENEM PLUS VANCOMYCIN' — broad cover but WITHOUT SURGERY and WITHOUT CLINDAMYCIN.",
  "'CEFTRIAXONE PLUS CLINDAMYCIN PLUS EXPLORATION' — it has surgery and clindamycin,",
  "WARNING, but CEFTRIAXONE COVERS NEITHER MRSA NOR ANAEROBES NOR PSEUDOMONAS — inadequate for polymicrobial fasciitis.",
  "SO THE ANSWER IS: VANCOMYCIN PLUS CLINDAMYCIN PLUS CIPROFLOXACIN PLUS RAPID SURGICAL EXPLORATION.",
  "VANCOMYCIN for MRSA, CIPROFLOXACIN for gram-negatives, and CLINDAMYCIN to shut down toxin.",
 ],
 "⚠️ **پیش از هر چیز: درجه حرارت این سؤال تصحیح شده است.** متن استخراج‌شده «۸۳ درجه» داشت که با حیات سازگار نیست؛ صفحه‌ی ۱۰ کتاب **۳۸/۳** چاپ کرده است.\n\n"
 "**بیمار خانم ۵۰ ساله‌ی دیابتی است با شرح حالی که در نگاه اول بی‌خطر به نظر می‌رسد: «کشیدگی عضله‌ی ران».** ⚠️ **و دقیقاً همین بی‌خطر به نظر رسیدن، تله‌ی سؤال است.**\n\n"
 "**علائم حیاتی را بخوانید:**\n\n"
 "**فشار خون ۸۰/۵۰** · **نبض ۱۱۰** · **تنفس ۳۰** · **تب ۳۸/۳**\n\n"
 "**این شوک سپتیک است.** و در معاینه چه می‌بینیم؟ فقط «**اریتم مختصر** قدام ران با **تندرنس شدید** در لمس».\n\n"
 "⚠️ **همین ناهماهنگی — پوست تقریباً سالم، ولی بیماری که در شوک است — تعریف فاشئیت نکروزان است.** درد و توکسیسیته از عمق می‌آید، جایی که چشم نمی‌بیند.\n\n"
 "**چرا دیابت مهم‌ترین عامل خطر است؟ سه دلیل:** **نوروپاتی** (درد و زخم دیرتر حس می‌شود)، **بیماری عروق محیطی** (خون‌رسانی و اکسیژن‌رسانی ضعیف)، و **اختلال عملکرد نوتروفیل** در هیپرگلیسمی.\n\n"
 "**حالا گزینه‌ها را بسنجید، با یک اصل راهنما: هر گزینه‌ای که جراحی ندارد، غلط است.**\n\n"
 "**«سونوگرافی بافت نرم + آنتی‌بیوتیک»** ← تصویربرداری به‌جای جراحی؛ تأخیر کشنده است.\n\n"
 "**«مروپنم + وانکومایسین»** ← پوشش وسیعی است ولی **نه جراحی دارد و نه کلیندامایسین**.\n\n"
 "**«سفتریاکسون + کلیندامایسین + اکسپلور»** ← جراحی دارد، کلیندامایسین هم دارد، ⚠️ **ولی سفتریاکسون نه MRSA را می‌پوشاند، نه بی‌هوازی‌ها را، نه پسودوموناس را** — و فاشئیت نکروزان در دیابتی معمولاً **پلی‌میکروبیال** است.\n\n"
 "**پس پاسخ: وانکومایسین + کلیندامایسین + سیپروفلوکساسین + اکسپلور جراحی سریع** — که هر سه بخش پوشش (گرم‌مثبت مقاوم، گرم‌منفی، مهار توکسین) را دارد و جراحی را هم به تأخیر نمی‌اندازد.",
 "WARNING, FIRST: THE TEMPERATURE IN THIS QUESTION HAS BEEN CORRECTED. The extracted text read '83 degrees', which is incompatible with life; page 10 prints 38.3.\n\n"
 "THE PATIENT is a 50-year-old diabetic woman with a history that seems innocent at first glance: 'a pulled thigh muscle'. WARNING, AND THAT VERY INNOCENCE IS THE TRAP.\n\n"
 "READ THE VITAL SIGNS:\n\n"
 "BLOOD PRESSURE 80/50 · PULSE 110 · RESPIRATORY RATE 30 · TEMPERATURE 38.3\n\n"
 "THIS IS SEPTIC SHOCK. And what do we see on examination? Only 'MILD ERYTHEMA' of the anterior thigh with 'MARKED TENDERNESS'.\n\n"
 "WARNING: THAT MISMATCH — NEARLY NORMAL SKIN IN A SHOCKED PATIENT — IS THE DEFINITION OF NECROTISING FASCIITIS. The pain and toxicity come from the depth, where the eye cannot see.\n\n"
 "WHY IS DIABETES THE MOST IMPORTANT RISK FACTOR? Three reasons: NEUROPATHY (pain and ulcers are noticed late), PERIPHERAL VASCULAR DISEASE (poor perfusion and oxygenation), and IMPAIRED NEUTROPHIL FUNCTION in hyperglycaemia.\n\n"
 "NOW WEIGH THE OPTIONS WITH ONE GUIDING PRINCIPLE: ANY OPTION WITHOUT SURGERY IS WRONG.\n\n"
 "'SOFT TISSUE ULTRASOUND PLUS ANTIBIOTICS' — imaging instead of surgery; a lethal delay.\n\n"
 "'MEROPENEM PLUS VANCOMYCIN' — broad cover but NEITHER SURGERY NOR CLINDAMYCIN.\n\n"
 "'CEFTRIAXONE PLUS CLINDAMYCIN PLUS EXPLORATION' — it has surgery and clindamycin, WARNING, BUT CEFTRIAXONE COVERS NEITHER MRSA NOR ANAEROBES NOR PSEUDOMONAS — and necrotising fasciitis in a diabetic is usually POLYMICROBIAL.\n\n"
 "SO THE ANSWER IS: VANCOMYCIN PLUS CLINDAMYCIN PLUS CIPROFLOXACIN PLUS RAPID SURGICAL EXPLORATION — covering resistant gram-positives, gram-negatives and toxin suppression, without delaying the operation.",
 ["سونوگرافی به‌جای جراحی یعنی تأخیر؛ در فاشئیت نکروزان تصویربرداری نباید جایگزین اکسپلور شود.",
  "مروپنم و وانکومایسین پوشش وسیعی است ولی نه جراحی دارد و نه کلیندامایسین برای مهار توکسین.",
  "پاسخ صحیح — پوشش MRSA و گرم‌منفی و مهار توکسین، به‌همراه اکسپلور جراحی سریع.",
  "سفتریاکسون پوشش MRSA، بی‌هوازی و پسودوموناس ندارد و برای فاشئیت پلی‌میکروبیال ناکافی است."],
 ["Ultrasound instead of surgery means delay; in necrotising fasciitis imaging must not replace exploration.",
  "Meropenem plus vancomycin is broad but includes neither surgery nor clindamycin for toxin suppression.",
  "Correct — MRSA and gram-negative cover with toxin suppression, alongside rapid surgical exploration.",
  "Ceftriaxone covers neither MRSA nor anaerobes nor Pseudomonas and is inadequate for polymicrobial fasciitis."],
 "فاشئیت: **جراحی + وسیع‌الطیف + کلیندامایسین (مهار توکسین).** بدون جراحی، هیچ رژیمی کافی نیست.",
 "Fasciitis: surgery plus broad-spectrum cover plus clindamycin for toxin suppression. Without surgery no regimen suffices.",
 [IDSA, H26])


# =========================================================== book:28
add("book:28", "case", "hard",
 "سقط ناایمن + شوک + **بدون تب** ← **کلستریدیوم** (سوردلی/پرفرینجنس).",
 "Unsafe abortion with shock and NO FEVER means CLOSTRIDIUM (sordellii or perfringens).",
 NEC_FA + [
  "⚠️ **توجه: دو عدد این سؤال تصحیح شده است** — صفحه‌ی ۱۲ «فشار خون 70/p» و",
  "«تعداد تنفس 130» چاپ کرده؛ متن استخراج‌شده هر دو را معکوس کرده بود.",
  "**فشار خون سیستولیک ۷۰ با دیاستولیک غیرقابل ثبت، یعنی شوک عمیق** — و همین قلب سؤال است.",
  "**بیمار: خانم ۲۵ ساله، پنج روز پس از سقط غیرقانونی، با خواب‌آلودگی و شوک.**",
  "**ادم گسترده در اندام‌ها، تندرنس هیپوگاستر، ترشحات خونابه‌ای غیرچرکی.**",
  "**آزمایش‌ها: لکوسیت ۲۷۰۰۰، هماتوکریت ۴۵، پلاکت ۹۰۰۰۰، کراتینین ۳.**",
  "⚠️ **و حالا مهم‌ترین یافته، که یافته‌ی «نبودن» است: درجه حرارت ۳۷ — یعنی بدون تب.**",
  "**سندرم شوک توکسیک کلستریدیایی یک تابلوی منحصربه‌فرد دارد که باید حفظ کنید:**",
  "⚠️ **یک — بدون تب یا حتی هیپوترمی.** برخلاف تقریباً هر سپسیس دیگری.",
  "**دو — لکوسیتوز بسیار شدید (اغلب بالای ۵۰ هزار) با شیفت به چپ.**",
  "**سه — هموکونسانتریشن: هماتوکریت بالا** به‌علت **نشت مویرگی شدید**.",
  "**چهار — ادم گسترده و افیوژن** (همان مایعی که از عروق نشت کرده).",
  "**پنج — شوک مقاوم به مایع‌درمانی و نارسایی چنداندامی.**",
  "**شش — ترشحات غیرچرکی**، چون کلستریدیوم پاسخ نوتروفیلی موضعی قوی برنمی‌انگیزد.",
  "**کلستریدیوم سوردلی و پرفرینجنس** پس از سقط، زایمان و جراحی زنان کلاسیک‌اند.",
  "⚠️ **مرگ‌ومیرش بسیار بالاست و درمان: جراحی فوری (اغلب هیسترکتومی) + پنی‌سیلین + کلیندامایسین.**",
  "چرا E. coli یا استرپ گروه B نه؟ آن‌ها معمولاً **تب** می‌دهند و این تابلوی بدون‌تب را نمی‌سازند.",
 ],
 NEC_EN + [
  "WARNING, NOTE: TWO NUMBERS IN THIS QUESTION HAVE BEEN CORRECTED — page 12 prints 'blood pressure 70/p'",
  "and 'respiratory rate 130'; the extraction had mirrored both.",
  "A SYSTOLIC OF 70 WITH AN UNRECORDABLE DIASTOLIC MEANS DEEP SHOCK — and that is the heart of the question.",
  "THE PATIENT: a 25-year-old woman five days after an illegal abortion, drowsy and shocked.",
  "WIDESPREAD LIMB OEDEMA, hypogastric tenderness, SEROSANGUINOUS NON-PURULENT discharge.",
  "LABORATORY: white cells 27,000, haematocrit 45, platelets 90,000, creatinine 3.",
  "WARNING, AND NOW THE MOST IMPORTANT FINDING, WHICH IS AN ABSENCE: TEMPERATURE 37 — NO FEVER.",
  "CLOSTRIDIAL TOXIC SHOCK HAS A UNIQUE PICTURE THAT MUST BE MEMORISED:",
  "WARNING, ONE — NO FEVER, OR EVEN HYPOTHERMIA. Unlike almost any other sepsis.",
  "TWO — VERY MARKED LEUCOCYTOSIS (often above 50,000) with a left shift.",
  "THREE — HAEMOCONCENTRATION: A HIGH HAEMATOCRIT from INTENSE CAPILLARY LEAK.",
  "FOUR — WIDESPREAD OEDEMA AND EFFUSIONS (the fluid that leaked out of the vessels).",
  "FIVE — SHOCK REFRACTORY TO FLUIDS, with multi-organ failure.",
  "SIX — NON-PURULENT DISCHARGE, because clostridia provoke little local neutrophil response.",
  "CLOSTRIDIUM SORDELLII AND PERFRINGENS are classical after abortion, delivery and gynaecological surgery.",
  "WARNING: MORTALITY IS VERY HIGH. TREATMENT: URGENT SURGERY (often hysterectomy) PLUS PENICILLIN PLUS CLINDAMYCIN.",
  "Why not E. coli or group B strep? They usually cause FEVER and do not produce this afebrile picture.",
 ],
 "⚠️ **پیش از هر چیز: دو عدد این سؤال تصحیح شده است.** صفحه‌ی ۱۲ کتاب «**فشار خون 70/p**» و «**تعداد تنفس 130**» چاپ کرده، و متن استخراج‌شده هر دو را معکوس کرده بود. **فشار سیستولیک ۷۰ با دیاستولیک غیرقابل ثبت یعنی شوک عمیق** — و همین، قلب سؤال است.\n\n"
 "**بیمار: خانم ۲۵ ساله، پنج روز پس از سقط غیرقانونی، با خواب‌آلودگی و شوک.** در معاینه **ادم گسترده در اندام‌ها**، تندرنس هیپوگاستر، و **ترشحات خونابه‌ای غیرچرکی** دارد. آزمایش‌ها: لکوسیت **۲۷۰۰۰**، هماتوکریت **۴۵**، پلاکت **۹۰۰۰۰**، کراتینین **۳**.\n\n"
 "⚠️ **و حالا مهم‌ترین یافته‌ی سؤال، که یافته‌ی «نبودن» است: درجه حرارت ۳۷ — یعنی بیمار تب ندارد.**\n\n"
 "**سندرم شوک توکسیک کلستریدیایی یک تابلوی منحصربه‌فرد دارد که باید آن را حفظ کنید:**\n\n"
 "⚠️ **۱. بدون تب یا حتی هیپوترمی** — برخلاف تقریباً هر سپسیس دیگری\n"
 "**۲. لکوسیتوز بسیار شدید** با شیفت به چپ\n"
 "**۳. هموکونسانتریشن (هماتوکریت بالا)** به‌علت **نشت مویرگی شدید**\n"
 "**۴. ادم گسترده و افیوژن** — همان مایعی که از عروق بیرون زده\n"
 "**۵. شوک مقاوم به مایع‌درمانی** و نارسایی چنداندامی\n"
 "**۶. ترشحات غیرچرکی**، چون کلستریدیوم پاسخ نوتروفیلی موضعی قوی برنمی‌انگیزد\n\n"
 "**بیمار ما پنج مورد از این شش را دارد.**\n\n"
 "**کلستریدیوم سوردلی و پرفرینجنس** پس از **سقط، زایمان و جراحی زنان** کلاسیک‌اند. توکسینشان (لتال توکسین سوردلی، آلفاتوکسین پرفرینجنس) **نشت مویرگی عظیم** می‌سازد و همان است که هماتوکریت را بالا و فشار را پایین می‌برد.\n\n"
 "⚠️ **مرگ‌ومیرش بسیار بالاست.** درمان: **جراحی فوری** (اغلب هیسترکتومی) + **پنی‌سیلین + کلیندامایسین**.\n\n"
 "**چرا بقیه رد می‌شوند؟** **E. coli** و **استرپتوکوک گروه B** هم می‌توانند پس از سقط سپسیس بسازند، ولی معمولاً **با تب** — و این تابلوی بدون‌تب با همو‌کونسانتریشن را نمی‌سازند.",
 "WARNING, FIRST: TWO NUMBERS IN THIS QUESTION HAVE BEEN CORRECTED. Page 12 prints 'blood pressure 70/p' and 'respiratory rate 130', and the extraction had mirrored both. A SYSTOLIC OF 70 WITH AN UNRECORDABLE DIASTOLIC MEANS DEEP SHOCK — and that is the heart of the question.\n\n"
 "THE PATIENT: a 25-year-old woman five days after an illegal abortion, drowsy and in shock, with WIDESPREAD LIMB OEDEMA, hypogastric tenderness and SEROSANGUINOUS NON-PURULENT discharge. Laboratory: white cells 27,000, haematocrit 45, platelets 90,000, creatinine 3.\n\n"
 "WARNING, AND NOW THE MOST IMPORTANT FINDING, WHICH IS AN ABSENCE: TEMPERATURE 37 — THE PATIENT HAS NO FEVER.\n\n"
 "CLOSTRIDIAL TOXIC SHOCK HAS A UNIQUE PICTURE YOU MUST MEMORISE:\n\n"
 "WARNING, 1. NO FEVER, OR EVEN HYPOTHERMIA — unlike almost any other sepsis\n"
 "2. VERY MARKED LEUCOCYTOSIS with a left shift\n"
 "3. HAEMOCONCENTRATION (a high haematocrit) from INTENSE CAPILLARY LEAK\n"
 "4. WIDESPREAD OEDEMA AND EFFUSIONS — the fluid that has left the vessels\n"
 "5. SHOCK REFRACTORY TO FLUIDS, with multi-organ failure\n"
 "6. NON-PURULENT DISCHARGE, because clostridia provoke little local neutrophil response\n\n"
 "OUR PATIENT HAS FIVE OF THOSE SIX.\n\n"
 "CLOSTRIDIUM SORDELLII AND PERFRINGENS are classical after ABORTION, DELIVERY AND GYNAECOLOGICAL SURGERY. Their toxins (sordellii lethal toxin, perfringens alpha toxin) cause MASSIVE CAPILLARY LEAK, which is what raises the haematocrit while dropping the pressure.\n\n"
 "WARNING: MORTALITY IS VERY HIGH. Treatment: URGENT SURGERY (often hysterectomy) plus PENICILLIN PLUS CLINDAMYCIN.\n\n"
 "WHY THE OTHERS FAIL? E. COLI and GROUP B STREPTOCOCCUS can also cause post-abortion sepsis, but usually WITH FEVER — they do not produce this afebrile picture with haemoconcentration.",
 ["پاسخ صحیح — شوک بدون تب با لکوسیتوز شدید، ادم گسترده و ترشح غیرچرکی پس از سقط: کلستریدیوم.",
  "E. coli پس از سقط سپسیس می‌سازد ولی معمولاً با تب، و تابلوی همو‌کونسانتریشن کلستریدیایی را ندارد.",
  "استافیلوکوک اورئوس علت شایع سپسیس پس از سقط نیست و این تابلوی بدون تب را نمی‌سازد.",
  "استرپتوکوک گروه B می‌تواند عفونت پس از زایمان بدهد ولی معمولاً با تب همراه است."],
 ["Correct — afebrile shock with marked leucocytosis, widespread oedema and non-purulent discharge after abortion: Clostridium.",
  "E. coli causes post-abortion sepsis but usually with fever, and lacks the clostridial haemoconcentration picture.",
  "Staphylococcus aureus is not a common cause of post-abortion sepsis and does not give this afebrile picture.",
  "Group B streptococcus can cause postpartum infection but is usually accompanied by fever."],
 "**سپسیس پس از سقط + بدون تب + هماتوکریت بالا + ادم = کلستریدیوم.** جراحی فوری لازم است.",
 "Post-abortion sepsis without fever, with a high haematocrit and oedema, means Clostridium. Urgent surgery is required.",
 [H26, IDSA])


# =========================================================== book:61
add("book:61", "case", "hard",
 "TSS شدید ← **کلیندامایسین (مهار توکسین) + لینزولید + ایمونوگلوبولین وریدی**.",
 "Severe TSS needs CLINDAMYCIN (toxin suppression) plus LINEZOLID plus INTRAVENOUS IMMUNOGLOBULIN.",
 TSS_FA + [
  "خانم **۳۰ ساله** با تب، **اریتم جنرالیزه**، بی‌قراری، درد شکم، اسهال و استفراغ.",
  "⚠️ **و کلیدواژه: علائم «طی دوران عادت ماهیانه» شروع شده و تدریجاً شدت یافته است.**",
  "**در معاینه: افت فشار خون (سیستولیک ۸۰) — یعنی شوک.**",
  "**این سندرم شوک توکسیک استافیلوکوکی مرتبط با قاعدگی است.**",
  "**معیارهای تشخیصی TSS استافیلوکوکی را بدانید — هر پنج مورد لازم است:**",
  "**تب بالای ۳۸/۹** · **افت فشار (سیستولیک زیر ۹۰)** · **اریتم منتشر ماکولر**",
  "· **پوسته‌ریزی در ۱ تا ۲ هفته بعد** · **درگیری حداقل سه دستگاه**.",
  "**دستگاه‌ها: گوارشی، عضلانی (CPK بالا)، کلیوی، کبدی، خونی، عصبی، مخاطی.**",
  "⚠️ **حالا چرا این ترکیب سه‌دارویی؟ هر جزء کار متفاوتی می‌کند:**",
  "**کلیندامایسین ← مهار سنتز پروتئین ← توقف تولید توکسین.**",
  "این مهم‌ترین جزء است. بتالاکتام‌ها باکتری را می‌کشند ولی **توکسینِ ساخته‌شده را متوقف نمی‌کنند**،",
  "و بدتر: **لیز باکتری می‌تواند آزادسازی توکسین را موقتاً بیشتر کند**.",
  "**لینزولید ← پوشش MRSA، و خودش هم مهارکننده‌ی سنتز پروتئین است** (اثر ضدتوکسین مضاعف).",
  "⚠️ **ایمونوگلوبولین وریدی ← آنتی‌بادی خنثی‌کننده علیه سوپرآنتی‌ژن.**",
  "IVIG در TSS شدید و مقاوم به مایع توصیه می‌شود، به‌ویژه در نوع استرپتوکوکی.",
  "**چرا گزینه‌های دیگر ناکافی‌اند؟** «استروئید تنها» ← عفونت را درمان نمی‌کند.",
  "«وانکومایسین + IVIG» ← وانکومایسین باکتریسیدال است ولی **مهار توکسین ندارد**.",
  "⚠️ **و همیشه: تامپون را بردارید.** بدون حذف کانون، هیچ دارویی کافی نیست.",
 ],
 TSS_EN + [
  "A 30-YEAR-OLD woman with fever, GENERALISED ERYTHRODERMA, restlessness, abdominal pain, diarrhoea and vomiting.",
  "WARNING, AND THE KEYWORD: the symptoms began DURING HER MENSTRUAL PERIOD and worsened gradually.",
  "ON EXAMINATION: HYPOTENSION (systolic 80) — that is, shock.",
  "THIS IS MENSTRUAL STAPHYLOCOCCAL TOXIC SHOCK SYNDROME.",
  "KNOW THE DIAGNOSTIC CRITERIA OF STAPHYLOCOCCAL TSS — all five are required:",
  "FEVER ABOVE 38.9 · HYPOTENSION (systolic below 90) · DIFFUSE MACULAR ERYTHRODERMA",
  "· DESQUAMATION AT 1 TO 2 WEEKS · INVOLVEMENT OF AT LEAST THREE ORGAN SYSTEMS.",
  "THE SYSTEMS: gastrointestinal, muscular (high CPK), renal, hepatic, haematological, neurological, mucosal.",
  "WARNING, NOW WHY THIS THREE-DRUG COMBINATION? Each part does something different:",
  "CLINDAMYCIN — INHIBITS PROTEIN SYNTHESIS AND THEREFORE STOPS TOXIN PRODUCTION.",
  "This is the most important component. Beta-lactams kill the organism but DO NOT STOP TOXIN ALREADY MADE,",
  "and worse: BACTERIAL LYSIS CAN TRANSIENTLY INCREASE TOXIN RELEASE.",
  "LINEZOLID — MRSA cover, and itself a protein synthesis inhibitor (a double antitoxin effect).",
  "WARNING, INTRAVENOUS IMMUNOGLOBULIN — NEUTRALISING ANTIBODY AGAINST THE SUPERANTIGEN.",
  "IVIG is recommended in severe, fluid-refractory TSS, especially the streptococcal form.",
  "Why are the others inadequate? 'STEROIDS ALONE' does not treat the infection.",
  "'VANCOMYCIN PLUS IVIG' — vancomycin is bactericidal but PROVIDES NO TOXIN SUPPRESSION.",
  "WARNING, AND ALWAYS: REMOVE THE TAMPON. Without removing the focus, no drug is sufficient.",
 ],
 "خانم **۳۰ ساله** با تب، **اریتم جنرالیزه‌ی بدن**، بی‌قراری، درد شکم، اسهال و استفراغ به اورژانس ارجاع شده است.\n\n"
 "⚠️ **و کلیدواژه‌ی سؤال: علائم «طی دوران عادت ماهیانه» شروع شده و تدریجاً شدت یافته است.** در معاینه **افت فشار خون (سیستولیک ۸۰)** دارد — یعنی **شوک**.\n\n"
 "**این سندرم شوک توکسیک استافیلوکوکیِ مرتبط با قاعدگی است.**\n\n"
 "**معیارهای تشخیصی را بدانید:** تب بالای **۳۸/۹**، افت فشار (سیستولیک زیر **۹۰**)، **اریتم منتشر ماکولر**، **پوسته‌ریزی کف دست و پا در ۱ تا ۲ هفته بعد**، و **درگیری حداقل سه دستگاه** (گوارشی، عضلانی، کلیوی، کبدی، خونی، عصبی، مخاطی).\n\n"
 "⚠️ **و حالا مهم‌ترین بخش: چرا این ترکیب سه‌دارویی؟ هر جزء کار متفاوتی می‌کند.**\n\n"
 "**۱. کلیندامایسین ← مهار سنتز پروتئین ← توقف تولید توکسین**\n\n"
 "این مهم‌ترین جزء است و منطقش را باید عمیق بفهمید: **بتالاکتام‌ها باکتری را می‌کشند، ولی توکسینی را که ساخته شده متوقف نمی‌کنند.** بدتر اینکه **لیز شدن باکتری می‌تواند آزادسازی توکسین را موقتاً بیشتر کند**. کلیندامایسین با خاموش کردن کارخانه‌ی پروتئین‌سازی، **جلوی ساخت توکسین جدید را می‌گیرد**.\n\n"
 "**۲. لینزولید ← پوشش MRSA**، و نکته‌ی ظریفش این است که لینزولید **خودش هم مهارکننده‌ی سنتز پروتئین است** — یعنی اثر ضدتوکسین مضاعف.\n\n"
 "⚠️ **۳. ایمونوگلوبولین وریدی ← آنتی‌بادی خنثی‌کننده علیه سوپرآنتی‌ژن.** در TSS شدید و مقاوم به مایع‌درمانی توصیه می‌شود.\n\n"
 "**چرا گزینه‌های دیگر ناکافی‌اند؟** «**استروئید تنها**» عفونت را درمان نمی‌کند. «**وانکومایسین + IVIG**» ← وانکومایسین باکتریسیدال است ولی **هیچ مهار توکسینی ندارد**. «**کلیندامایسین + استروئید**» ← مهار توکسین دارد ولی **پوشش ضدباکتریایی MRSA و ایمونوگلوبولین ندارد**.\n\n"
 "⚠️ **و اقدامی که هیچ دارویی جایش را نمی‌گیرد: تامپون را بردارید.** بدون حذف کانون تولید توکسین، درمان شکست می‌خورد.",
 "A 30-YEAR-OLD woman is referred with fever, GENERALISED ERYTHRODERMA, restlessness, abdominal pain, diarrhoea and vomiting.\n\n"
 "WARNING, AND THE KEYWORD: her symptoms began DURING HER MENSTRUAL PERIOD and worsened gradually. On examination she is HYPOTENSIVE (systolic 80) — that is, IN SHOCK.\n\n"
 "THIS IS MENSTRUAL STAPHYLOCOCCAL TOXIC SHOCK SYNDROME.\n\n"
 "KNOW THE DIAGNOSTIC CRITERIA: fever above 38.9, hypotension (systolic below 90), DIFFUSE MACULAR ERYTHRODERMA, DESQUAMATION OF PALMS AND SOLES AT 1 TO 2 WEEKS, and INVOLVEMENT OF AT LEAST THREE ORGAN SYSTEMS (gastrointestinal, muscular, renal, hepatic, haematological, neurological, mucosal).\n\n"
 "WARNING, AND NOW THE KEY PART: WHY THIS THREE-DRUG COMBINATION? Each component does something different.\n\n"
 "1. CLINDAMYCIN — INHIBITS PROTEIN SYNTHESIS AND THEREFORE STOPS TOXIN PRODUCTION\n\n"
 "This is the most important component, and its logic must be understood deeply: BETA-LACTAMS KILL THE ORGANISM BUT DO NOT STOP TOXIN ALREADY MADE. Worse, BACTERIAL LYSIS CAN TRANSIENTLY INCREASE TOXIN RELEASE. Clindamycin shuts down the protein factory and PREVENTS NEW TOXIN FROM BEING MADE.\n\n"
 "2. LINEZOLID — MRSA COVER, and the subtle point is that linezolid IS ITSELF A PROTEIN SYNTHESIS INHIBITOR, giving a double antitoxin effect.\n\n"
 "WARNING, 3. INTRAVENOUS IMMUNOGLOBULIN — NEUTRALISING ANTIBODY AGAINST THE SUPERANTIGEN, recommended in severe, fluid-refractory TSS.\n\n"
 "WHY ARE THE OTHERS INADEQUATE? 'STEROIDS ALONE' does not treat the infection. 'VANCOMYCIN PLUS IVIG' — vancomycin is bactericidal but PROVIDES NO TOXIN SUPPRESSION. 'CLINDAMYCIN PLUS STEROIDS' has toxin suppression but LACKS MRSA COVER AND IMMUNOGLOBULIN.\n\n"
 "WARNING, AND THE STEP NO DRUG REPLACES: REMOVE THE TAMPON. Without eliminating the focus of toxin production, treatment fails.",
 ["استروئید به‌تنهایی عفونت را درمان نمی‌کند و پوشش ضدباکتریایی و ضدتوکسین ندارد.",
  "وانکومایسین باکتریسیدال است ولی مهار تولید توکسین ندارد؛ کلیندامایسین در این رژیم ضروری است.",
  "کلیندامایسین و استروئید مهار توکسین دارد ولی پوشش MRSA و ایمونوگلوبولین خنثی‌کننده ندارد.",
  "پاسخ صحیح — کلیندامایسین برای مهار توکسین، لینزولید برای پوشش MRSA، و IVIG برای خنثی کردن سوپرآنتی‌ژن."],
 ["Steroids alone do not treat the infection and provide neither antibacterial nor antitoxin cover.",
  "Vancomycin is bactericidal but does not suppress toxin production; clindamycin is essential in this regimen.",
  "Clindamycin plus steroids suppresses toxin but lacks MRSA cover and neutralising immunoglobulin.",
  "Correct — clindamycin for toxin suppression, linezolid for MRSA cover, and IVIG to neutralise the superantigen."],
 "TSS: **کلیندامایسین همیشه** (مهار توکسین) + پوشش ضدباکتریایی + **IVIG** در موارد شدید + **حذف کانون**.",
 "TSS: clindamycin always (toxin suppression), plus antibacterial cover, plus IVIG in severe cases, plus removal of the focus.",
 [IDSA, H143])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book24.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 24 lessons:', len(L))
