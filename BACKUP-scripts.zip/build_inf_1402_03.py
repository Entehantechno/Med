# -*- coding: utf-8 -*-
"""Infectious block of the Khordad-1402 paper, extracted from the OFFICIAL booklets.

Source quality here is the best possible:
  * Persian booklet  — «پیش کارورزی_FA_020318» (both the with-floating and the
    without-floating printings were supplied, so the numbering is cross-checked)
  * English booklet  — «پیش کارورزی_EN_020318»; the English text below is lifted
    VERBATIM from it, never re-translated (project rule 17)
  * Official answer key — two independent scans of the ministry key; every one of
    the nine infectious answers agreed across both, and the same reader scored
    7/8 on the already-verified neurology answers of this sitting.

The paper was printed in two variants. The variant WITH the "floating" (شناور)
questions numbers the infectious block 122–130; the variant WITHOUT them numbers
the overlapping six 103–108. We store the WITH-floating numbering as canonical
because it is the complete set, and record the alternate number in `alt_no`.

Reference for the lessons: Harrison's Principles of Internal Medicine, 21st ed.
"""
import json, os

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'out')
os.makedirs(OUT, exist_ok=True)

YEAR, MONTH, TAG = '۱۴۰۲', 'خرداد', '1402-03'

# (no, alt_no, stem_fa, options_fa, stem_en, options_en, key_index, rationale_fa)
Q = [
 (122, None,
  "کدام‌یک از گزینه‌های زیر در مورد تظاهرات بالینی لپتوسپیروز صحیح است؟",
  ["اکثر بیماران علامت‌دار هستند.",
   "درد عضلانی معمولاً خفیف است.",
   "محل شایع سردرد ناحیه تمپورال است.",
   "درد عضلانی معمولاً در ساق پاها بیشتر است."],
  "Which of the following options is correct about the clinical manifestations of leptospirosis?",
  ["Most patients are symptomatic.",
   "Myalgia is usually mild.",
   "The common site of headache is the temporal region.",
   "Myalgia is usually more prominent in the calves."],
  3,
  "لپتوسپیروز چهار ادعای این سؤال را یکی‌یکی رد می‌کند تا فقط گزینه‌ی آخر بماند. "
  "اول: تخمین زده می‌شود حدود ۹۰ درصد عفونت‌ها خفیف یا کاملاً بدون علامت‌اند، پس «اکثر بیماران علامت‌دار» غلط است. "
  "دوم: میالژی در لپتوسپیروز نه‌تنها خفیف نیست، بلکه یکی از شدیدترین دردهای عضلانی در طب عفونی است — "
  "آن‌قدر که بیمار از لمس ساق پا هم می‌نالد. سوم: سردرد کلاسیک آن فرونتال (پیشانی) و شدید و ضربان‌دار است، نه تمپورال. "
  "و چهارم که پاسخ است: درد به‌طور مشخص در عضلات ساق پا (calf) و کمر متمرکز می‌شود؛ "
  "ترکیب «تب + میالژی شدید ساق + تزریق ملتحمه (conjunctival suffusion)» تابلوی امضایی لپتوسپیروز است. "
  "منطق پاتوفیزیولوژیک هم همین را می‌گوید: اسپیروکت باعث واسکولیت عضلانی می‌شود و گروه‌های عضلانی بزرگ و پرخون بیشترین آسیب را می‌بینند."),

 (123, 103,
  "بیمار آقای ۳۵ ساله با علائم سرفه‌های پروداکتیو، تنگی نفس به همراه تب و لرز مراجعه کرده است. در معاینه "
  "T=40 ºC، RR=40/min و BP=110/70 mmHg است. در سی‌تی‌اسکن ریه کانسالیدیشن در لوب تحتانی ریه راست دیده می‌شود. "
  "بهترین درمان برای این بیمار کدام‌یک از گزینه‌های زیر می‌باشد؟",
  ["درمان سرپایی آزیترومایسین",
   "سفتریاکسون و آزیترومایسین در بخش",
   "سفتریاکسون و آزیترومایسین در ICU",
   "لووفلوکساسین به همراه سفتریاکسون در بخش"],
  "A 35-year-old male patient has referred to a clinic with productive cough and dyspnea along with fever and "
  "chill. On examination, T=40 ºC, BP=110/70 mmHg, and RR=40/min are noted, and consolidation in the right "
  "lower lobe has been seen in the spiral chest CT. Which of the following is the best treatment for this patient?",
  ["Outpatient therapy with azitromycine",
   "Inpatient therapy in the ward with cefteriaxon and azithromycine",
   "Inpatient therapy in the ICU with cefteriaxon and azithromycine",
   "Inpatient therapy in the ward with levofloxacin and cefteriaxon"],
  2,
  "این سؤال در واقع سؤالِ «کجا بستری کنم؟» است، نه «چه آنتی‌بیوتیکی بدهم؟». "
  "دو رقم را ببینید: دمای ۴۰ درجه و مهم‌تر از آن تعداد تنفس ۴۰ در دقیقه. "
  "در معیارهای شدت پنومونی (IDSA/ATS)، RR ≥ ۳۰ به‌تنهایی یکی از معیارهای مینور پذیرش در ICU است و ۴۰ خیلی بالاتر از آن است؛ "
  "دمای ≥ ۴۰ (هیپوترمی/هایپرترمی شدید) هم معیار دیگری است. با دو معیار مینور یا بیشتر، بیمار باید در ICU بستری شود. "
  "رژیم دارویی در هر دو حالت بستری یکسان است (بتالاکتام + ماکرولید یا فلوروکینولون تنفسی)، "
  "پس گزینه‌ی ۲ و ۳ فقط در محل بستری فرق دارند و همین محل، پاسخ را تعیین می‌کند. "
  "نکته‌ی بالینی: تاکی‌پنه‌ی شدید حساس‌ترین علامت زودرس نارسایی تنفسی است و اغلب پیش از افت اشباع اکسیژن ظاهر می‌شود؛ "
  "درمان سرپایی (گزینه‌ی ۱) اینجا خطرناک است."),

 (124, None,
  "بیمار آقای ۳۵ ساله با سابقه کهیر در ساق پا و ضایعات خارش‌دار متحرک در پا که چند روز بعد از علایم پوستی دچار سرفه شده است، "
  "به کلینیک مراجعه کرده است. در آزمایشات انجام‌شده ائوزینوفیلی نوسان‌دار داشته است. براساس شرح حال بهترین راه تشخیص کدام است؟",
  ["آسپیراسیون مغز استخوان",
   "کشت مدفوع",
   "بیوپسی پوست",
   "اسمیر مدفوع"],
  "A 35-year-old man with a history of urticaria on the leg and migrating pruritic skin lesions on the foot, who "
  "developed cough a few days after the skin symptoms, has referred to the clinic. Laboratory tests showed "
  "fluctuating eosinophilia. Based on the history, what is the best diagnostic method?",
  ["Bone marrow aspiration",
   "Stool culture",
   "Skin biopsy",
   "Stool smear"],
  3,
  "سه سرنخ را کنار هم بگذارید: ضایعه‌ی پوستی خارش‌دار که «حرکت می‌کند»، سرفه‌ای که چند روز بعد از آن پیدا می‌شود، "
  "و ائوزینوفیلی که بالا و پایین می‌رود. این دقیقاً چرخه‌ی استرونژیلوئیدس استرکورالیس است. "
  "ضایعه‌ی متحرک همان larva currens است — لارو زیر پوست با سرعت چند سانتی‌متر در ساعت جابه‌جا می‌شود، "
  "که آن را از larva migrans کندِ کرم قلابدار سگ متمایز می‌کند. سرفه هم از عبور لارو از ریه (سندرم لوفلر) می‌آید. "
  "تشخیص یک انگل روده‌ای با یافتن خودِ لارو در مدفوع انجام می‌شود، یعنی اسمیر مستقیم مدفوع. "
  "کشت مدفوع برای باکتری است نه انگل؛ بیوپسی پوست ممکن است لارو را نشان دهد ولی تهاجمی و کم‌بازده است؛ "
  "و آسپیراسیون مغز استخوان جایی در تشخیص انگل روده‌ای ندارد. "
  "نکته‌ی حیاتی: حساسیت یک نمونه‌ی مدفوع پایین است (~۳۰٪)، پس عملاً باید چند نمونه فرستاد."),

 (125, 104,
  "در افراد دچار سوء تغذیه و بیماران مبتلا به HIV، عفونت با شیگلا با کدام‌یک از عوارض زیر بیشتر همراهی دارد؟",
  ["مگاکولون توکسیک",
   "باکتریمی",
   "پرفوریشن روده",
   "اختلالات متابولیک مثل هایپوگلایسمی"],
  "Which complication of shigella is more seen in malnourished and HIV patients?",
  ["Toxic megacolon",
   "Bacteremia",
   "Intestinal perforation",
   "Metabolic abnormalities such as hypoglycemia"],
  1,
  "شیگلا معمولاً یک عفونت «مخاطی» است: باکتری در اپیتلیوم کولون می‌ماند و به‌ندرت وارد خون می‌شود، "
  "به همین دلیل باکتریمی در میزبان سالم نادر است. اما وقتی سیستم ایمنی سلولی یا سد مخاطی ضعیف شود — "
  "یعنی همان دو گروهی که سؤال نام برده: سوءتغذیه‌ی شدید و HIV پیشرفته — باکتری از مخاط عبور می‌کند و "
  "باکتریمی رخ می‌دهد؛ همراه با افزایش چشمگیر مرگ‌ومیر. "
  "بقیه‌ی گزینه‌ها هم عوارض واقعی شیگلوز هستند (مگاکولون توکسیک و پرفوریشن به‌ویژه با S. dysenteriae type 1، "
  "و هیپوگلیسمی در کودکان)، ولی هیچ‌کدام آن اختصاصیتِ ارتباط با نقص ایمنی را ندارند که این سؤال دنبالش است. "
  "درس بالینی: در بیمار HIV مثبت با اسهال خونی، کشت خون هم بفرستید، نه فقط کشت مدفوع."),

 (126, 105,
  "آقای ۷۵ ساله با سابقه سکته مغزی اخیر با علائم تب شدید، سرفه و خلط بدبو و شواهد آبسه در سی‌تی‌اسکن ریه بستری شده است. "
  "آمپی‌سولباکتام برای بیمار شروع شده است و پس از ۲ هفته با توجه به بهبود نسبی علائم بالینی برای بیمار کوآموکسی‌کلاو شروع شده است. "
  "مناسب‌ترین تصمیم در رابطه با طول دوره درمان با کوآموکسی‌کلاو کدام است؟",
  ["تا چهار هفته",
   "تا بهبود یافته‌های رادیولوژیک",
   "تا نرمال شدن ESR و CRP",
   "تا بهبود کامل علائم بالینی"],
  "A 75-year-old patient has been hospitalized with a recent strock followed by a high fever, cough, malodor "
  "sputum, and abssess in the chest CT. Ampisulbactam has been prescribed for the patient, and given a partial "
  "improvement in his clinical symptoms, coamoxiclave was administered after two weeks. Which of the "
  "following is the best decision about the duration of treatment with coamoxiclave?",
  ["Up to 4 weeks",
   "Until the cure of radiologic findings",
   "Until the normalization of ESR and CRP",
   "Until the cure of clinical symptoms"],
  1,
  "آبسه‌ی ریه (اینجا آسپیراسیون پس از سکته، با خلط بدبو که امضای بی‌هوازی‌هاست) یکی از معدود عفونت‌هایی است که "
  "طول درمانش را نه تقویم و نه علائم بالینی، بلکه «تصویر» تعیین می‌کند. "
  "علائم بالینی معمولاً ظرف یک تا دو هفته می‌خوابند، اما حفره‌ی آبسه ماه‌ها طول می‌کشد تا جمع شود؛ "
  "اگر آنتی‌بیوتیک را با بهبود علائم قطع کنید، عود شایع است. "
  "پس قاعده این است: درمان تا زمانی ادامه یابد که گرافی/سی‌تی به یک زخم باقی‌مانده‌ی کوچک و پایدار یا نمای طبیعی برسد — "
  "که در عمل اغلب بین ۳ هفته تا چند ماه طول می‌کشد. به همین دلیل «تا ۴ هفته»ی ثابت هم پاسخ نیست: "
  "برای بعضی بیماران کوتاه و برای بعضی بلند است. ESR و CRP هم نشانگرهای غیراختصاصی‌اند و معیار قطع درمان نیستند."),

 (127, None,
  "بیمار آقای ۳۴ ساله با تب، تعریق شبانه، ضعف و بی‌حالی و کاهش وزن از حدود ۲ ماه قبل و سرفه و درد شکم از ۲ هفته قبل "
  "مراجعه کرده است. در معاینه هپاتواسپلنومگالی و لنفادنوپاتی و در آزمایشات لنفوپنی، افزایش آنزیم‌های کبدی و در گرافی "
  "قفسه سینه انفیلتراسیون بیناب‌بینی (میلیاری) دارد. بر اساس محتمل‌ترین تشخیص کدام بررسی کمک‌کننده است؟",
  ["بیوپسی مغز استخوان",
   "PPD",
   "اسمیر خلط",
   "کشت خلط"],
  "A 34-year-old man has presented with fever, night sweats, weakness, malaise and weight loss for about "
  "2 months, and cough and abdominal pain for 2 weeks. On examination he has hepatosplenomegaly and "
  "lymphadenopathy; laboratory tests show lymphopenia and elevated liver enzymes, and chest radiography "
  "shows an interstitial (miliary) infiltrate. Based on the most likely diagnosis, which investigation is helpful?",
  ["Bone marrow biopsy",
   "PPD",
   "Sputum smear",
   "Sputum culture"],
  0,
  "تابلو، سل میلیاری (منتشر) است: تب و تعریق شبانه و کاهش وزن دو ماهه، به‌علاوه‌ی درگیری چنداُرگانی — "
  "کبد و طحال بزرگ، لنفادنوپاتی، آنزیم‌های کبدی بالا و نمای میلیاری در گرافی. "
  "کلید سؤال این است که در سل میلیاری بار باسیل در ریه کم است، پس تست‌های تنفسی ناامیدکننده‌اند: "
  "اسمیر خلط در اکثر موارد منفی است و کشت خلط هم ۶ تا ۸ هفته طول می‌کشد که برای بیماری‌ای با این شدت خیلی دیر است. "
  "PPD هم در سل منتشر و در حضور لنفوپنی اغلب منفی کاذب می‌شود (آنرژی) و در هر حال هرگز تشخیص قطعی نمی‌دهد. "
  "در مقابل، مغز استخوان در سل میلیاری تقریباً همیشه درگیر است و بیوپسی آن گرانولوم کازئیفیه و باسیل اسیدفاست را "
  "با بازده بالا و سریع نشان می‌دهد؛ مخصوصاً وقتی سیتوپنی هم وجود دارد که خودش اندیکاسیون مستقل بیوپسی است."),

 (128, 106,
  "در بیمار مبتلا به مننژیت ویروسی حاد، کدام گزینه احتمال وجود همزمان انسفالیت را مطرح می‌کند؟",
  ["فوتوفوبی",
   "درد حین حرکت چشم‌ها",
   "تشنج",
   "دردِ گردن (سفتی گردن)"],
  "Which one of the following options suggest the possibility of concurrent encephalitis in a patient with acute "
  "viral meningitis?",
  ["Photophobia",
   "Painfull eye movement",
   "Seizure",
   "Neck stiffness"],
  2,
  "مرز مننژیت و انسفالیت یک چیز است و فقط یک چیز: آیا خودِ پارانشیم مغز درگیر شده یا نه. "
  "فوتوفوبی، درد حرکت چشم و سفتی گردن هر سه از تحریک مننژ می‌آیند — یعنی حتی اگر شدید باشند، "
  "باز هم فقط مننژیت را نشان می‌دهند و پیش‌آگهی را عوض نمی‌کنند. "
  "اما تشنج یعنی نورون‌های قشر مغز درگیر و تحریک شده‌اند؛ همین‌طور اختلال هوشیاری، تغییر شخصیت و نشانه‌های نورولوژیک کانونی. "
  "این تمایز آکادمیک نیست: بیمار مننژیت ویروسی معمولاً خودبه‌خود خوب می‌شود، "
  "ولی بیمار انسفالیت باید فوراً آسیکلوویر وریدی بگیرد تا HSV — که درمان‌نشده مرگ‌ومیر بالای ۷۰ درصد دارد — پوشش داده شود."),

 (129, 107,
  "در کدام‌یک از موارد گازگرفتگی، تجویز آنتی‌بیوتیک پروفیلاکسی را حتی در صورت غیرعفونی بودن زخم توصیه می‌کنید؟",
  ["سگ", "انسان", "گربه", "جوندگان"],
  "Which one of the bite cases should be followed by antibiotic prophylaxis in all cases even if the wound is not "
  "infected?",
  ["Dog", "Human", "Cat", "Rodent"],
  1,
  "این سؤال ظاهراً چهار حیوان را مقایسه می‌کند ولی در واقع یک اصل را می‌پرسد: کدام گازگرفتگی «همیشه» پروفیلاکسی می‌خواهد؟ "
  "پاسخ گازگرفتگی انسان است. دهان انسان فلور پرغلظت و مخلوط هوازی-بی‌هوازی دارد "
  "(از جمله Eikenella corrodens که به بسیاری از آنتی‌بیوتیک‌های رایج مقاوم است) و "
  "میزان عفونت زخم انسانی از همه بالاتر است؛ به‌ویژه زخم clenched-fist روی مفاصل MCP که مستقیم وارد فضای مفصلی می‌شود. "
  "برای همین در تمام موارد کوآموکسی‌کلاو تجویز می‌شود. "
  "گاز گربه هم پرخطر است (سوراخ عمیق و Pasteurella multocida) و بسیاری از منابع آن را هم پرخطر می‌دانند، "
  "ولی قاعده‌ی «در همه‌ی موارد بدون استثنا» درباره‌ی انسان است. "
  "گاز سگ برعکس، زخم پهن‌تری می‌سازد و میزان عفونتش پایین‌تر است، پس پروفیلاکسی انتخابی و بر پایه‌ی خطر است. "
  "جوندگان کمترین خطر را دارند و حتی هاری هم منتقل نمی‌کنند."),

 (130, 108,
  "خانم حامله ۸ هفته، ۵ روز بعد از تماس با بیمار مبتلا به آبله مرغان مراجعه کرده است. سرولوژی VZV منفی است. "
  "تجویز کدام‌یک از موارد زیر در پیشگیری مناسب است؟",
  ["واکسن واریسلا", "VZV IG", "اسیکلوویر وریدی", "والاسیکلوویر خوراکی"],
  "A pregnant woman with the gestational age of 8 weeks has been referred to a clinic 5 days after being exposed "
  "to a chickenpox patient. VZV serology is negative. Which of the following is the most appropriate preventive "
  "measure?",
  ["Varicella vaccine", "VZV IG", "Intravenous acyclovir", "Oral valacyclovir"],
  1,
  "سه قید در صورت سؤال هست و هر سه لازم‌اند: بارداری، سرولوژی منفی (یعنی بدون ایمنی) و فاصله‌ی ۵ روز از تماس. "
  "بارداری یعنی واکسن واریسلا ممنوع است، چون واکسن ویروس زنده‌ی ضعیف‌شده است. "
  "سرولوژی منفی یعنی بیمار واقعاً در معرض خطر است و باید کاری کرد. "
  "و ۵ روز یعنی هنوز داخل پنجره‌ی مؤثر ایمونوگلوبولین هستیم — VariZIG تا ۱۰ روز پس از تماس توصیه می‌شود. "
  "پس ایمن‌سازی غیرفعال با VZV IG پاسخ است: آنتی‌بادی آماده می‌دهد بدون آنکه ویروس زنده وارد کند، "
  "و هم مادر را از پنومونی واریسلایی (که در بارداری مرگ‌ومیر بالایی دارد) و هم جنین را محافظت می‌کند. "
  "آسیکلوویر و والاسیکلوویر داروی درمان‌اند نه پیشگیری استاندارد پس از تماس؛ "
  "اگر IG در دسترس نباشد به‌عنوان جایگزین درجه‌دو مطرح می‌شوند."),
]

LET = ['الف', 'ب', 'ج', 'د']
# Official key as read from BOTH ministry answer-key scans (they agreed 9/9).
OFFICIAL_KEY = {122: 3, 123: 2, 124: 3, 125: 1, 126: 1, 127: 0, 128: 2, 129: 1, 130: 1}


def build():
    rows = []
    for (no, alt, sfa, ofa, sen, oen, key, why) in Q:
        assert len(ofa) == 4 and len(oen) == 4, no
        assert OFFICIAL_KEY[no] == key, f"key mismatch on {no}: sheet={OFFICIAL_KEY[no]} authored={key}"
        rows.append({
            'exam': 'خرداد ۱۴۰۲',
            'exam_tag': '1402-03',
            'subject_fa': 'بیماری‌های عفونی',
            'subject_en': 'Infectious Diseases',
            'question_no': no,
            'alt_question_no': alt,
            'year': YEAR,
            'exam_month': MONTH,
            'sitting_tag': TAG,
            'stem_fa': sfa,
            'options_fa': ofa,
            'stem_en': sen,
            'options_en': oen,
            'correct_index': key,
            'correct_letter': LET[key],
            'key_source': 'official',
            'en_source': 'official_booklet',
            'key_rationale': why,
        })
    path = os.path.join(OUT, f'inf_{TAG.replace("-", "_")}.json')
    with open(path, 'w', encoding='utf-8') as fh:
        json.dump(rows, fh, ensure_ascii=False, indent=1)
    print(f'wrote {len(rows)} questions -> {path}')


if __name__ == '__main__':
    build()
