# -*- coding: utf-8 -*-
"""Micro-lessons, batch 31 — HIV: testing, staging and prophylaxis.

The largest single block in the largest chapter. Roughly sixty questions ask
about HIV, and they cluster into three groups that share almost no knowledge
with each other:

  * TESTING — about twenty questions, nearly all the same question: "the
    screening test is positive, what now?"
  * STAGING AND OPPORTUNISTIC INFECTIONS — which illness defines AIDS, and
    which CD4 count opens the door to which organism
  * PROPHYLAXIS — the CD4 thresholds at which each prophylaxis starts

Each group reduces to one small structure, taught below.

THE TESTING BLOCK, AND A GUIDELINE THAT HAS MOVED UNDER THESE QUESTIONS
------------------------------------------------------------------------
This is the second time in this bank that the exam keys an answer the current
guideline has withdrawn, and it must be handled the same honest way the
clindamycin keys were in the endocarditis chapter.

These sittings were written against the OLD algorithm:
    repeatedly reactive ELISA  ->  confirm with WESTERN BLOT

In 2014 the CDC REMOVED THE WESTERN BLOT from the recommended algorithm
entirely, and the current sequence is:
    1. HIV-1/2 antigen/antibody immunoassay (the old "fourth generation")
    2. if reactive: an HIV-1/HIV-2 ANTIBODY DIFFERENTIATION immunoassay
    3. if that is negative or indeterminate: HIV-1 RNA (NAT)

The reason matters medically and is worth teaching: the Western blot is an
IgG-only assay and turns positive two to three weeks LATER than the screening
test. So in acute HIV — exactly when the patient is most infectious — the
screening test is positive and the Western blot is falsely NEGATIVE. WHO went
further in 2019 and recommends against western blotting altogether.

So the lessons state the keyed answer, and then state plainly that the
confirmatory step is now a differentiation immunoassay plus RNA. A student who
reads them can pass the exam and also not order an obsolete test.

WHAT IS NOT CHANGED
-------------------
The printed keys are NOT corrected. The exam is asking "what did the algorithm
of that era say", every distractor is worse than the keyed option even by
today's standards, and rewriting the key would make the student answer the
real exam wrongly. The same rule as the clindamycin block.

Reference: CDC, "Laboratory Testing for the Diagnosis of HIV Infection:
Updated Recommendations" (2014, revised 2018); Panel on Guidelines for the
Prevention and Treatment of Opportunistic Infections in Adults and Adolescents
with HIV (NIH/CDC/IDSA); Harrison's Principles of Internal Medicine, 21st ed
(2022), Ch. 202 (Human Immunodeficiency Virus Disease: AIDS and Related
Disorders).
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


CDCLAB = ("CDC — Laboratory Testing for the Diagnosis of HIV Infection: Updated Recommendations "
          "(2014; algorithm revised 2018)")
OIGUIDE = ("Panel on Guidelines for the Prevention and Treatment of Opportunistic Infections in "
           "Adults and Adolescents with HIV — NIH/CDC/IDSA")
H202 = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 202: Human "
        "Immunodeficiency Virus Disease: AIDS and Related Disorders")

# ----------------------------------------------------------- the testing tree
TEST_FA = [
    "⚠️ **تشخیص HIV یک آزمایش نیست، یک زنجیره است. و ترتیب زنجیره منطق دارد.**",
    "**اصل حاکم: تست غربالگری حساس است ولی اختصاصی نیست؛ پس هرگز به‌تنهایی تشخیص نمی‌دهد.**",
    "**الایزا (EIA) حساسیتی بالای ۹۹ درصد دارد — یعنی تقریباً هیچ مورد مثبتی را از دست نمی‌دهد.**",
    "⚠️ **ولی در جمعیت کم‌خطر، بیشترِ مثبت‌ها کاذب‌اند** — و این ریاضیات است، نه ضعف آزمایش.",
    "**علل مثبت کاذب الایزا: بارداری، بیماری خودایمن، واکسیناسیون اخیر، عفونت ویروسی حاد، دیالیز.**",
    "**پس گام دوم همیشه تکرار همان الایزا روی همان نمونه است.**",
    "**اگر تکرار منفی شد، آن مثبت اول یک خطای فنی بوده و ماجرا تمام است.**",
    "⚠️ **اگر تکرار هم مثبت شد، آنگاه و فقط آنگاه سراغ تست تأییدی می‌رویم.**",
    "**پاسخ کلید این آزمون‌ها: تأیید با وسترن بلات.** این الگوریتم آن دوره است.",
    "⚠️ **و به‌روزرسانی مهم: CDC از سال ۲۰۱۴ وسترن بلات را کاملاً کنار گذاشت.**",
    "**چرا؟ چون وسترن بلات فقط IgG را می‌بیند و ۲ تا ۳ هفته دیرتر از تست غربالگری مثبت می‌شود.**",
    "**پس در عفونت حاد — دقیقاً وقتی بیمار بیشترین سرایت را دارد — وسترن بلات کاذباً منفی است.**",
    "**الگوریتم امروز: تست ترکیبی آنتی‌ژن/آنتی‌بادی ← تست تفکیک HIV-1 از HIV-2 ← در صورت ابهام، RNA.**",
    "**سازمان جهانی بهداشت هم در ۲۰۱۹ استفاده از وسترن بلات را توصیه نکرد.**",
    "⚠️ **و مفهوم «دوره‌ی پنجره» را جدا یاد بگیرید، چون سؤال‌های دیگری بر پایه‌ی آن ساخته شده‌اند:**",
    "**RNA ویروس از حدود ۱۰ روز پس از تماس قابل شناسایی است.**",
    "**آنتی‌ژن p24 از حدود ۲ هفته. آنتی‌بادی از ۳ تا ۱۲ هفته (اکثریت تا ۶ هفته).**",
    "**پس در تماس تازه، آنتی‌بادی منفی هیچ چیزی را رد نمی‌کند و باید تکرار شود.**",
    "**و در سندرم رتروویرال حاد با آنتی‌بادی منفی، آزمایش انتخابی بار ویروسی (RNA) است.**",
]
TEST_EN = [
    "WARNING: DIAGNOSING HIV IS NOT ONE TEST BUT A CHAIN, and the order of the chain has a logic.",
    "The governing principle: a screening test is sensitive but not specific, so it never diagnoses alone.",
    "The ELISA (EIA) is over 99 per cent sensitive — it misses almost no true case.",
    "WARNING, BUT IN A LOW-RISK POPULATION MOST POSITIVES ARE FALSE — that is arithmetic, not a fault of the assay.",
    "Causes of a false-positive ELISA: pregnancy, autoimmune disease, recent vaccination, acute viral infection, dialysis.",
    "So the second step is always to REPEAT THE SAME ELISA on the same sample.",
    "If the repeat is negative, the first positive was a technical error and the matter ends there.",
    "WARNING: ONLY IF THE REPEAT IS ALSO POSITIVE DO WE MOVE TO A CONFIRMATORY TEST.",
    "The keyed answer in these exams: confirm with WESTERN BLOT. That was the algorithm of the period.",
    "WARNING, AN IMPORTANT UPDATE: THE CDC REMOVED THE WESTERN BLOT ENTIRELY IN 2014.",
    "Why? Because the Western blot sees only IgG and turns positive 2 to 3 weeks LATER than the screening test.",
    "So in acute infection — exactly when the patient is most infectious — the Western blot is FALSELY NEGATIVE.",
    "Today's algorithm: a combined antigen/antibody assay, then an HIV-1/HIV-2 differentiation assay, then RNA if unresolved.",
    "The World Health Organization likewise recommended against western blotting in 2019.",
    "WARNING, AND LEARN THE WINDOW PERIOD SEPARATELY, because other questions are built on it:",
    "Viral RNA is detectable from about 10 days after exposure.",
    "The p24 antigen from about 2 weeks. Antibody from 3 to 12 weeks (most by 6 weeks).",
    "So after a recent exposure a negative antibody excludes nothing and must be repeated.",
    "And in acute retroviral syndrome with negative antibody, the test of choice is the VIRAL LOAD (RNA).",
]

# ------------------------------------------------- CD4 thresholds and staging
CD4_FA = [
    "⚠️ **در HIV، عدد CD4 یک آزمایش نیست — یک ساعت است که می‌گوید کدام عفونت‌ها ممکن شده‌اند.**",
    "**آستانه‌ها را به‌صورت یک نردبان نزولی حفظ کنید، چون سؤال‌ها دقیقاً روی پله‌ها می‌ایستند:**",
    "**بالای ۵۰۰: عملاً مثل فرد سالم؛ بیشتر عفونت‌های باکتریال معمولی.**",
    "**۲۰۰ تا ۵۰۰: کاندیدیای دهانی (برفک)، لکوپلاکی مودار، زونا، سل ریوی، پنومونی باکتریال مکرر.**",
    "⚠️ **زیر ۲۰۰ — مهم‌ترین آستانه: پنوموسیستیس ژیرووسی (PCP).**",
    "**و پروفیلاکسی PCP دقیقاً از همین‌جا شروع می‌شود: کوتریموکسازول روزانه.**",
    "**زیر ۱۰۰: توکسوپلاسموز مغزی و مننژیت کریپتوکوکی.**",
    "**زیر ۵۰: مایکوباکتریوم آویوم منتشر و رتینیت سیتومگالوویروس.**",
    "**پروفیلاکسی MAC با آزیترومایسین هفتگی از همین‌جا شروع می‌شود.**",
    "⚠️ **و یک قاعده‌ی مهم که سؤال‌ها روی آن حساب می‌کنند: پروفیلاکسی قابل قطع شدن است.**",
    "**اگر با درمان ضدرتروویروسی CD4 بالای آستانه برود و بیش از ۳ ماه بماند، پروفیلاکسی قطع می‌شود.**",
    "**برای PCP: CD4 بالای ۲۰۰ به مدت بیش از ۳ ماه. برای توکسوپلاسما: بالای ۲۰۰ با همان شرط.**",
    "**چون بازسازی ایمنی، همان محافظتی را برمی‌گرداند که دارو جایگزینش شده بود.**",
    "⚠️ **و سل استثناست: در HIV، سل در هر شمارش CD4 رخ می‌دهد، حتی بالای ۵۰۰.**",
    "**به همین دلیل سل شایع‌ترین عفونت هم‌زمان و شایع‌ترین علت مرگ در HIV در جهان است.**",
    "**و هرچه CD4 پایین‌تر، تابلوی سل غیرتیپیک‌تر: بدون کاویته، منتشر، با اسمیر منفی.**",
    "**تست پوستی توبرکولین هم در CD4 پایین کاذباً منفی می‌شود (آنرژی).**",
]
CD4_EN = [
    "WARNING: IN HIV THE CD4 COUNT IS NOT A TEST BUT A CLOCK, telling you which infections have become possible.",
    "Memorise the thresholds as a descending ladder, because the questions stand exactly on the rungs:",
    "ABOVE 500: essentially like a healthy person; mostly ordinary bacterial infections.",
    "200 TO 500: oral candidiasis (thrush), hairy leucoplakia, herpes zoster, pulmonary TB, recurrent bacterial pneumonia.",
    "WARNING, BELOW 200 — THE MOST IMPORTANT THRESHOLD: PNEUMOCYSTIS JIROVECII (PCP).",
    "And PCP prophylaxis begins exactly here: daily co-trimoxazole.",
    "BELOW 100: cerebral toxoplasmosis and cryptococcal meningitis.",
    "BELOW 50: disseminated Mycobacterium avium complex and CMV retinitis.",
    "MAC prophylaxis with weekly azithromycin begins here.",
    "WARNING, AND AN IMPORTANT RULE THE QUESTIONS RELY ON: PROPHYLAXIS CAN BE STOPPED.",
    "If antiretroviral therapy lifts the CD4 above the threshold and holds it there for more than 3 months, prophylaxis stops.",
    "For PCP: CD4 above 200 for more than 3 months. For toxoplasma: above 200 on the same condition.",
    "Because immune reconstitution restores the very protection the drug was substituting for.",
    "WARNING, AND TUBERCULOSIS IS THE EXCEPTION: in HIV it occurs at ANY CD4 count, even above 500.",
    "That is why TB is the commonest coinfection and the commonest cause of death in HIV worldwide.",
    "And the lower the CD4, the more atypical the TB: non-cavitary, disseminated, smear-negative.",
    "The tuberculin skin test also becomes falsely negative at low CD4 (anergy).",
]


# =========================================================== book:675
add("book:675", "case", "medium",
 "الایزای مثبت **یک نوبت** ← اول **تکرار همان الایزا**، نه تست تأییدی و نه تشخیص قطعی.",
 "A SINGLE positive ELISA needs the ELISA REPEATED first — not a confirmatory test, and certainly not a diagnosis.",
 TEST_FA + [
  "**در این سؤال، وسوسه‌ی دو گزینه‌ی «پیشرفته» بسیار زیاد است، و هر دو زودهنگام‌اند.**",
  "**وسترن بلات و PCR هر دو گران‌ترند و هر دو در جای خودشان درست‌اند — ولی جایشان اینجا نیست.**",
  "⚠️ **چرا تکرار الایزا مقدم است؟ چون ارزان‌ترین راه حذف خطای فنی است.**",
  "**بخش قابل توجهی از مثبت‌های اول، خطای آزمایشگاهی‌اند: جابه‌جایی نمونه، آلودگی، خطای پیپت.**",
  "**تکرار روی همان نمونه، این‌ها را در یک مرحله حذف می‌کند.**",
  "**و اگر تکرار منفی شد، بیمار از یک تشخیص سنگین و اشتباه نجات پیدا کرده است.**",
  "⚠️ **و نکته‌ی انسانی که در این سؤال هست: اعلام تشخیص HIV بر پایه‌ی یک تست، آسیب‌زاست.**",
  "**پس گزینه‌ی «تشخیص قطعی است» نه‌تنها از نظر علمی غلط، که از نظر بالینی خطرناک است.**",
  "**اعتیاد تزریقی احتمال پیش‌آزمون را بالا می‌برد، ولی الگوریتم را عوض نمی‌کند.**",
 ],
 TEST_EN + [
  "In this question the temptation of the two 'advanced' options is strong, and both are premature.",
  "The Western blot and PCR are both more expensive and both right in their place — but their place is not here.",
  "WARNING, WHY DOES REPEATING THE ELISA COME FIRST? Because it is the cheapest way to remove technical error.",
  "A substantial share of first positives are laboratory errors: sample mix-up, contamination, a pipetting slip.",
  "Repeating on the same sample eliminates all of those in a single step.",
  "And if the repeat is negative, the patient has been spared a heavy and mistaken diagnosis.",
  "WARNING, AND THE HUMAN POINT IN THIS QUESTION: announcing HIV on the strength of one test does harm.",
  "So the option 'the diagnosis is certain' is not merely scientifically wrong, it is clinically dangerous.",
  "Injecting drug use raises the pre-test probability, but it does not change the algorithm.",
 ],
 "این سؤال یک اصل کلی آزمایشگاهی را می‌سنجد که فراتر از HIV است: **ترتیب زنجیره‌ی تشخیصی.**\n\n"
 "**آقای ۲۵ ساله‌ی معتاد تزریقی**، با **یک نوبت الایزای مثبت**. گام بعدی چیست؟\n\n"
 "⚠️ **پاسخ: تکرار همان الایزا.**\n\n"
 "**چرا نه تشخیص قطعی؟** چون الایزا یک **تست غربالگری** است: حساسیتش بالای ۹۹ درصد است "
 "(یعنی تقریباً هیچ بیماری را از دست نمی‌دهد) ولی **ویژگی‌اش کامل نیست**. فهرست علل "
 "مثبت کاذب طولانی است: **بارداری، بیماری خودایمن، واکسیناسیون اخیر، عفونت ویروسی حاد، "
 "دیالیز، و صرفاً خطای فنی آزمایشگاه**.\n\n"
 "**چرا نه وسترن بلات یا PCR؟** این دو گزینه «پیشرفته‌تر» به نظر می‌رسند و دقیقاً به همین "
 "دلیل دام‌اند. **آن‌ها گام سوم‌اند، نه گام دوم.** پیش از خرج کردن یک تست گران تأییدی، باید "
 "**ارزان‌ترین منبع خطا را حذف کرد: خطای فنی**.\n\n"
 "**تکرار الایزا روی همان نمونه، در یک مرحله این‌ها را حذف می‌کند:** جابه‌جایی نمونه، "
 "آلودگی، خطای پیپت‌زنی، و نقص کیت.\n\n"
 "**پس منطق کامل زنجیره:**\n\n"
 "**۱)** الایزای اول مثبت → **۲)** تکرار الایزا → **۳الف)** اگر منفی شد: خطای فنی، تمام. "
 "**۳ب)** اگر مثبت شد: **حالا** تست تأییدی.\n\n"
 "⚠️ **و به‌روزرسانی مهم درباره‌ی گام سوم:**\n\n"
 "در دوره‌ی این آزمون، گام سوم **وسترن بلات** بود. ولی **CDC از سال ۲۰۱۴ وسترن بلات را "
 "کاملاً از الگوریتم حذف کرد.** دلیلش آموزنده است: **وسترن بلات فقط IgG را می‌بیند و "
 "۲ تا ۳ هفته دیرتر از تست غربالگری مثبت می‌شود.** یعنی در **عفونت حاد** — دقیقاً زمانی "
 "که بیمار بیشترین بار ویروسی و بیشترین سرایت را دارد — **وسترن بلات کاذباً منفی است** و "
 "بیمار به‌اشتباه مطمئن می‌شود.\n\n"
 "**الگوریتم امروز:** تست ترکیبی آنتی‌ژن/آنتی‌بادی ← تست **تفکیک HIV-1 از HIV-2** ← در صورت "
 "منفی یا نامشخص بودن، **HIV-1 RNA**.\n\n"
 "**نکته‌ی انسانی:** اعتیاد تزریقی **احتمال پیش‌آزمون** را بالا می‌برد، ولی **الگوریتم را "
 "عوض نمی‌کند**. اعلام یک تشخیص مادام‌العمر بر پایه‌ی یک تست، آسیب روانی و اجتماعی جدی دارد.",
 "This question tests a general laboratory principle that goes beyond HIV: THE ORDER OF THE "
 "DIAGNOSTIC CHAIN.\n\n"
 "A 25-YEAR-OLD MAN WHO INJECTS DRUGS, with ONE POSITIVE ELISA. What next?\n\n"
 "WARNING, THE ANSWER: REPEAT THE SAME ELISA.\n\n"
 "WHY NOT CALL IT DIAGNOSTIC? Because the ELISA is a SCREENING test: over 99 per cent sensitive "
 "(it misses almost no true case) but NOT PERFECTLY SPECIFIC. The false-positive list is long: "
 "PREGNANCY, AUTOIMMUNE DISEASE, RECENT VACCINATION, ACUTE VIRAL INFECTION, DIALYSIS, and simple "
 "laboratory error.\n\n"
 "WHY NOT WESTERN BLOT OR PCR? Those two look 'more advanced', and that is exactly why they are "
 "bait. THEY ARE STEP THREE, NOT STEP TWO. Before spending an expensive confirmatory test, remove "
 "THE CHEAPEST SOURCE OF ERROR: technical error.\n\n"
 "REPEATING THE ELISA ON THE SAME SAMPLE eliminates, in one step: sample mix-up, contamination, a "
 "pipetting slip, and a faulty kit.\n\n"
 "SO THE FULL CHAIN:\n\n"
 "1) first ELISA positive -> 2) repeat the ELISA -> 3a) if negative: technical error, done. "
 "3b) if positive: NOW the confirmatory test.\n\n"
 "WARNING, AND AN IMPORTANT UPDATE ABOUT STEP THREE:\n\n"
 "In the era of this exam, step three was the WESTERN BLOT. But THE CDC REMOVED THE WESTERN BLOT "
 "FROM THE ALGORITHM ENTIRELY IN 2014. The reason is instructive: THE WESTERN BLOT SEES ONLY IgG "
 "AND TURNS POSITIVE 2 TO 3 WEEKS LATER THAN THE SCREENING TEST. So in ACUTE INFECTION — precisely "
 "when the patient has the highest viral load and is most infectious — THE WESTERN BLOT IS FALSELY "
 "NEGATIVE and the patient is wrongly reassured.\n\n"
 "TODAY'S ALGORITHM: a combined antigen/antibody assay, then an HIV-1/HIV-2 DIFFERENTIATION assay, "
 "then HIV-1 RNA if that is negative or indeterminate.\n\n"
 "THE HUMAN POINT: injecting drug use raises the PRE-TEST PROBABILITY but DOES NOT CHANGE THE "
 "ALGORITHM. Announcing a lifelong diagnosis on one test causes real psychological and social harm.",
 ["یک الایزای مثبت هرگز تشخیص قطعی نیست؛ علل مثبت کاذب متعددند.",
  "پاسخ صحیح — تکرار الایزا ارزان‌ترین راه حذف خطای فنی است و گام دوم استاندارد.",
  "وسترن بلات گام سوم است، نه دوم؛ ضمناً از سال ۲۰۱۴ از الگوریتم CDC حذف شده است.",
  "PCR در جای خودش (عفونت حاد یا ابهام تست تأییدی) ارزشمند است، ولی گام دوم نیست."],
 ["One positive ELISA is never diagnostic; the false-positive causes are many.",
  "Correct — repeating the ELISA is the cheapest way to remove technical error and is the standard second step.",
  "The Western blot is step three, not step two; it was also removed from the CDC algorithm in 2014.",
  "PCR is valuable in its place (acute infection or an unresolved confirmatory test) but is not step two."],
 "**غربالگری تشخیص نیست.** اول تکرار، بعد تأیید — و امروز تأیید با تست تفکیک است نه وسترن بلات.",
 "A screening test is not a diagnosis: repeat first, then confirm, and today confirmation is a differentiation assay, not a Western blot.",
 [CDCLAB, H202])


# =========================================================== book:691
add("book:691", "case", "medium",
 "**دو** الایزای مثبت ← حالا نوبت تست تأییدی است (کلید: وسترن بلات؛ امروز: تست تفکیک).",
 "TWO positive ELISAs mean it is now time to confirm (keyed: Western blot; today: a differentiation assay).",
 TEST_FA + [
  "**این سؤال دقیقاً یک پله جلوتر از سؤال قبلی است، و همین تقارن را باید ببینید.**",
  "**آنجا یک الایزای مثبت بود و پاسخ «تکرار». اینجا دو الایزای مثبت است و پاسخ «تأیید».**",
  "⚠️ **دو الایزای مثبت، خطای فنی را عملاً حذف کرده — چون یک خطا دو بار تکرار نمی‌شود.**",
  "**ولی علل بیولوژیک مثبت کاذب هنوز سر جایشان‌اند: بارداری، خودایمنی، واکسیناسیون اخیر.**",
  "**این‌ها با تکرار همان تست از بین نمی‌روند، چون خودِ نمونه واقعاً واکنش می‌دهد.**",
  "**پس حالا به تستی نیاز داریم که مکانیسم متفاوتی داشته باشد و اختصاصی‌تر باشد.**",
  "**پاسخ کلید: وسترن بلات — که پروتئین‌های اختصاصی ویروس را جداگانه نشان می‌دهد.**",
  "⚠️ **و امروز: تست تفکیک آنتی‌بادی HIV-1 از HIV-2، که سریع‌تر، ارزان‌تر و دقیق‌تر است.**",
  "**مزیت اضافه‌اش: HIV-2 را می‌شناسد، در حالی که وسترن بلات آن را به‌اشتباه HIV-1 می‌خواند.**",
  "**و شمارش CD4 اینجا نقشی ندارد: آن برای مرحله‌بندی است، نه برای تشخیص.**",
 ],
 TEST_EN + [
  "This question is exactly one rung above the previous one, and you should see the symmetry.",
  "There it was one positive ELISA and the answer was 'repeat'. Here it is two, and the answer is 'confirm'.",
  "WARNING: TWO POSITIVE ELISAS HAVE EFFECTIVELY REMOVED TECHNICAL ERROR — one slip does not repeat itself.",
  "But the BIOLOGICAL causes of a false positive remain: pregnancy, autoimmunity, recent vaccination.",
  "Those do not vanish on repeating the same test, because the sample genuinely does react.",
  "So now we need a test with a DIFFERENT MECHANISM and greater specificity.",
  "The keyed answer: the Western blot, which displays the individual viral proteins separately.",
  "WARNING, AND TODAY: an HIV-1/HIV-2 ANTIBODY DIFFERENTIATION assay, which is faster, cheaper and more accurate.",
  "Its extra advantage: it recognises HIV-2, whereas the Western blot misreads HIV-2 as HIV-1.",
  "And a CD4 count has no role here: that is for staging, not for diagnosis.",
 ],
 "این سؤال را باید **دقیقاً کنار** سؤال «یک الایزای مثبت» خواند. تقارن این دو، کل الگوریتم "
 "را می‌آموزد.\n\n"
 "**خانم معتاد تزریقی با دو نوبت الایزای مثبت.** جهت تأیید تشخیص چه می‌خواهید؟\n\n"
 "⚠️ **مقایسه‌ی دو سؤال:**\n\n"
 "یک الایزای مثبت: **دو** الایزای مثبت\n"
 "خطای فنی حذف شده؟: **نه** — **بله**\n"
 "علل بیولوژیک مثبت کاذب حذف شده؟: نه — **نه**\n"
 "گام بعدی: **تکرار الایزا** — **تست تأییدی**\n\n"
 "**چرا تکرار دیگر کافی نیست؟** چون **دو بار مثبت شدن، خطای فنی را عملاً حذف کرده است**"
 "یک اشتباه پیپت‌زنی دو بار پشت سر هم تکرار نمی‌شود.\n\n"
 "**ولی علل بیولوژیک هنوز سر جایشان‌اند.** در بارداری یا لوپوس یا پس از واکسیناسیون اخیر، "
 "**خودِ نمونه واقعاً واکنش می‌دهد** — پس هر چند بار هم که الایزا را تکرار کنید، **باز هم "
 "مثبت می‌شود**. تکرار، این دسته را حذف نمی‌کند.\n\n"
 "**پس به تستی نیاز داریم با مکانیسم متفاوت و ویژگی بالاتر.**\n\n"
 "**پاسخ کلید: وسترن بلات.** این تست پروتئین‌های ویروس (gp120، gp41، p24 و...) را روی یک "
 "نوار **جداگانه** نشان می‌دهد، و برای مثبت شدن باید الگوی مشخصی از باندها حاضر باشد"
 "پس بسیار اختصاصی است.\n\n"
 "⚠️ **و به‌روزرسانی مهم که باید بدانید:**\n\n"
 "**CDC از سال ۲۰۱۴ وسترن بلات را از الگوریتم حذف کرد** و سازمان جهانی بهداشت هم در **۲۰۱۹** "
 "توصیه کرد کشورها از آن فاصله بگیرند. جایگزین: **تست تفکیک آنتی‌بادی HIV-1 از HIV-2**.\n\n"
 "**سه دلیل این تغییر:**\n\n"
 "**۱)** وسترن بلات **فقط IgG** را می‌بیند و **۲ تا ۳ هفته دیرتر** مثبت می‌شود — پس در "
 "عفونت حاد **کاذباً منفی** است.\n\n"
 "**۲)** وسترن بلات **HIV-2 را نمی‌شناسد** و آن را به‌اشتباه HIV-1 می‌خواند — که پیامد "
 "درمانی مهمی دارد، چون HIV-2 به برخی داروها ذاتاً مقاوم است.\n\n"
 "**۳)** نتایج **نامشخص (indeterminate)** زیادی می‌دهد که ماه‌ها بیمار را بلاتکلیف "
 "می‌گذارد.\n\n"
 "**و چرا شمارش CD4 نه؟** چون CD4 **برای مرحله‌بندی و تصمیم درمانی** است، نه برای تشخیص. "
 "در فرد سالم هم CD4 پایین می‌تواند علل دیگری داشته باشد.",
 "Read this question DIRECTLY BESIDE the 'one positive ELISA' one. The symmetry teaches the whole "
 "algorithm.\n\n"
 "A WOMAN WHO INJECTS DRUGS WITH TWO POSITIVE ELISAS. What do you want to confirm the diagnosis?\n\n"
 "WARNING, COMPARE THE TWO QUESTIONS:\n\n"
 "One positive ELISA: TWO positive ELISAs\n"
 "Technical error removed?: NO — YES\n"
 "Biological false positives removed?: no — NO\n"
 "Next step: REPEAT THE ELISA — A CONFIRMATORY TEST\n\n"
 "WHY IS REPEATING NO LONGER ENOUGH? Because TWO POSITIVES HAVE EFFECTIVELY ELIMINATED TECHNICAL "
 "ERROR — a pipetting slip does not repeat itself twice in a row.\n\n"
 "BUT THE BIOLOGICAL CAUSES REMAIN. In pregnancy, lupus, or after recent vaccination, THE SAMPLE "
 "GENUINELY REACTS — so however many times you repeat the ELISA it will KEEP being positive. "
 "Repetition cannot remove that class.\n\n"
 "SO WE NEED A TEST WITH A DIFFERENT MECHANISM AND HIGHER SPECIFICITY.\n\n"
 "THE KEYED ANSWER: THE WESTERN BLOT. It displays the viral proteins (gp120, gp41, p24 and others) "
 "SEPARATELY on a strip, and a specific pattern of bands must be present for a positive — so it is "
 "highly specific.\n\n"
 "WARNING, AND AN IMPORTANT UPDATE YOU MUST KNOW:\n\n"
 "THE CDC REMOVED THE WESTERN BLOT FROM THE ALGORITHM IN 2014, and the WHO in 2019 recommended "
 "countries move away from it. The replacement: an HIV-1/HIV-2 ANTIBODY DIFFERENTIATION ASSAY.\n\n"
 "THREE REASONS FOR THE CHANGE:\n\n"
 "1) The Western blot sees ONLY IgG and turns positive 2 TO 3 WEEKS LATER — so in acute infection "
 "it is FALSELY NEGATIVE.\n\n"
 "2) The Western blot DOES NOT RECOGNISE HIV-2 and misreads it as HIV-1 — which matters "
 "therapeutically, since HIV-2 is intrinsically resistant to some drugs.\n\n"
 "3) It produces many INDETERMINATE results that leave patients in limbo for months.\n\n"
 "AND WHY NOT A CD4 COUNT? Because CD4 is for STAGING AND TREATMENT DECISIONS, not for diagnosis. "
 "A low CD4 can have other causes even in a healthy person.",
 ["پاسخ صحیح — پس از دو الایزای مثبت، نوبت تست تأییدی است (امروز تست تفکیک جای وسترن بلات را گرفته).",
  "الایزا همان تست غربالگری است؛ تکرار سوم آن علل بیولوژیک مثبت کاذب را حذف نمی‌کند.",
  "شمارش CD4 برای مرحله‌بندی و تصمیم درمانی است، نه برای تأیید تشخیص.",
  "دو الایزای مثبت بدون تأیید، تشخیص قطعی نیست؛ علل بیولوژیک مثبت کاذب هنوز رد نشده‌اند."],
 ["Correct — after two positive ELISAs it is time to confirm (today a differentiation assay has replaced the Western blot).",
  "The ELISA is the screening test itself; a third repeat does not remove biological false positives.",
  "A CD4 count is for staging and treatment decisions, not for confirming the diagnosis.",
  "Two positive ELISAs without confirmation are not diagnostic; biological false positives are still not excluded."],
 "**تکرار، خطای فنی را حذف می‌کند؛ تست تأییدی، علت بیولوژیک را.** دو کار متفاوت‌اند.",
 "Repetition removes technical error; a confirmatory test removes biological causes. They are two different jobs.",
 [CDCLAB, H202])


# =========================================================== book:695
add("book:695", "case", "hard",
 "سندرم رتروویرال حاد در **هفته‌ی سوم** ← تست سریع مثبت هنوز باید تأیید شود؛ **RNA** حساس‌ترین است.",
 "Acute retroviral syndrome at THREE WEEKS: a positive rapid test still needs confirming, and RNA is the most sensitive.",
 TEST_FA + [
  "⚠️ **این سؤال روی «دوره‌ی پنجره» ایستاده و باید زمان‌بندی نشانگرها را بدانید:**",
  "**RNA ویروس: از حدود ۱۰ روز پس از تماس قابل شناسایی — زودترین نشانگر.**",
  "**آنتی‌ژن p24: از حدود ۲ هفته.**",
  "**آنتی‌بادی: از ۳ تا ۱۲ هفته؛ اکثریت قاطع تا هفته‌ی ۶.**",
  "**بیمار در هفته‌ی سوم است: درست در مرز پیدایش آنتی‌بادی.**",
  "**و علائمش — تب، گلودرد، میالژی، لنفادنوپاتی — تابلوی کلاسیک سندرم رتروویرال حاد است.**",
  "⚠️ **در سندرم رتروویرال حاد، بار ویروسی بسیار بالاست (اغلب بیش از صد هزار کپی).**",
  "**پس اگر بخواهیم زودترین و قطعی‌ترین پاسخ را بگیریم، آزمایش RNA است.**",
  "**ولی سؤال درباره‌ی «قدم بعدی» در یک تست سریعِ مثبت است، نه درباره‌ی حساس‌ترین تست.**",
  "**و قاعده‌ی تغییرناپذیر: هیچ تست سریعی به‌تنهایی تشخیص نمی‌دهد — همیشه باید تأیید شود.**",
  "⚠️ **نکته‌ی حیاتی بالینی: بیمار در این مرحله بیشترین قدرت سرایت را دارد.**",
  "**پس مشاوره‌ی پیشگیری و پرهیز از تماس محافظت‌نشده، هم‌زمان با پیگیری آزمایشگاهی لازم است.**",
 ],
 TEST_EN + [
  "WARNING: THIS QUESTION STANDS ON THE WINDOW PERIOD, and you must know the timing of the markers:",
  "VIRAL RNA: detectable from about 10 days after exposure — the earliest marker.",
  "p24 ANTIGEN: from about 2 weeks.",
  "ANTIBODY: from 3 to 12 weeks; the great majority by week 6.",
  "This patient is at three weeks: exactly on the edge of antibody appearance.",
  "And his symptoms — fever, sore throat, myalgia, lymphadenopathy — are the classic acute retroviral syndrome.",
  "WARNING: IN ACUTE RETROVIRAL SYNDROME THE VIRAL LOAD IS VERY HIGH (often above 100,000 copies).",
  "So if we want the earliest and most definitive answer, the RNA assay gives it.",
  "But the question asks the NEXT STEP after a positive RAPID test, not which test is most sensitive.",
  "And the unchanging rule: NO RAPID TEST DIAGNOSES ALONE — it must always be confirmed.",
  "WARNING, A CRITICAL CLINICAL POINT: at this stage the patient is at his most infectious.",
  "So prevention counselling and abstinence from unprotected contact are needed alongside the laboratory follow-up.",
 ],
 "این سؤال دو مفهوم را هم‌زمان می‌سنجد: **سندرم رتروویرال حاد** و **دوره‌ی پنجره**.\n\n"
 "**مرد جوان، سه هفته پس از تماس پرخطر**، با **تب، گلودرد، میالژی، کاهش وزن و "
 "لنفادنوپاتی**. **تست سریع HIV مثبت** است.\n\n"
 "⚠️ **گام یک — این تابلو چیست؟**\n\n"
 "**سندرم رتروویرال حاد**: یک بیماری شبه‌مونونوکلئوز که **۲ تا ۶ هفته** پس از آلودگی رخ "
 "می‌دهد. علائمش — تب، فارنژیت، لنفادنوپاتی، میالژی، راش — چنان شبیه مونونوکلئوز عفونی "
 "است که **اغلب از قلم می‌افتد**. در ۵۰ تا ۹۰ درصد بیماران رخ می‌دهد ولی کمتر تشخیص داده "
 "می‌شود.\n\n"
 "⚠️ **گام دو — زمان‌بندی نشانگرها، که کلید سؤال است:**\n\n"
 "نشانگر: زمان مثبت شدن\n"
 "**RNA ویروس**: **از ~۱۰ روز**\n"
 "**آنتی‌ژن p24**: از ~۲ هفته\n"
 "**آنتی‌بادی**: **۳ تا ۱۲ هفته** (اکثریت تا ۶ هفته)\n\n"
 "بیمار **در هفته‌ی سوم** است — یعنی **درست روی مرز پیدایش آنتی‌بادی**.\n\n"
 "**گام سه — چرا تست سریع مثبت کافی نیست؟**\n\n"
 "**هیچ تست سریعی به‌تنهایی تشخیص نمی‌دهد.** تست‌های سریع برای **غربالگری در محل** طراحی "
 "شده‌اند و **ویژگی کمتری** از تست‌های آزمایشگاهی دارند. **هر تست سریع مثبت باید با "
 "الگوریتم آزمایشگاهی تأیید شود** — این یک قاعده‌ی بدون استثناست.\n\n"
 "**پاسخ کلید: تکرار تست دو هفته بعد** — یعنی رسیدن به هفته‌ی پنجم، که تا آن زمان "
 "**آنتی‌بادی در اکثریت قاطع بیماران ظاهر شده** و نتیجه قابل تفسیر می‌شود.\n\n"
 "⚠️ **و نکته‌ی مهم امروزی: اگر امکانش باشد، بهترین کار در سندرم رتروویرال حاد، "
 "درخواست بار ویروسی (HIV RNA) است**، چون:\n\n"
 "• در این مرحله **بار ویروسی بسیار بالاست** (اغلب بیش از ۱۰۰٬۰۰۰ کپی در میلی‌لیتر)\n"
 "• **پاسخ فوری** می‌دهد، نه دو هفته بعد\n"
 "• و **همان چیزی است که الگوریتم CDC ۲۰۱۴** برای حل ابهام تجویز می‌کند\n\n"
 "⚠️ **مهم‌ترین پیام بالینی این سؤال:** بیمار در سندرم رتروویرال حاد **بیشترین قدرت "
 "سرایت عمرش** را دارد. پس هم‌زمان با پیگیری آزمایشگاهی، **مشاوره‌ی پیشگیری و پرهیز از "
 "تماس محافظت‌نشده** باید انجام شود — نمی‌توان دو هفته منتظر ماند و هیچ کاری نکرد.",
 "This question tests two concepts at once: ACUTE RETROVIRAL SYNDROME and THE WINDOW PERIOD.\n\n"
 "A YOUNG MAN, THREE WEEKS AFTER A HIGH-RISK EXPOSURE, with FEVER, SORE THROAT, MYALGIA, WEIGHT "
 "LOSS AND LYMPHADENOPATHY. His RAPID HIV TEST IS POSITIVE.\n\n"
 "WARNING, STEP ONE — WHAT IS THIS PICTURE?\n\n"
 "ACUTE RETROVIRAL SYNDROME: a mononucleosis-like illness occurring 2 TO 6 WEEKS after infection. "
 "Its features — fever, pharyngitis, lymphadenopathy, myalgia, rash — resemble infectious "
 "mononucleosis so closely that IT IS OFTEN MISSED. It occurs in 50 to 90 per cent of patients but "
 "is diagnosed far less often.\n\n"
 "WARNING, STEP TWO — THE TIMING OF THE MARKERS, which is the key:\n\n"
 "Marker: Becomes positive\n"
 "VIRAL RNA: from about 10 days\n"
 "p24 ANTIGEN: from about 2 weeks\n"
 "ANTIBODY: 3 TO 12 WEEKS (most by 6)\n\n"
 "The patient is AT THREE WEEKS — exactly ON THE EDGE of antibody appearance.\n\n"
 "STEP THREE — WHY IS A POSITIVE RAPID TEST NOT ENOUGH?\n\n"
 "NO RAPID TEST DIAGNOSES ALONE. Rapid tests are designed for POINT-OF-CARE SCREENING and are LESS "
 "SPECIFIC than laboratory assays. EVERY POSITIVE RAPID TEST MUST BE CONFIRMED BY THE LABORATORY "
 "ALGORITHM — a rule without exception.\n\n"
 "THE KEYED ANSWER: REPEAT THE TEST IN TWO WEEKS — reaching week five, by which time ANTIBODY HAS "
 "APPEARED IN THE great majority and the result becomes interpretable.\n\n"
 "WARNING, AND AN IMPORTANT MODERN POINT: where available, THE BEST ACTION IN ACUTE RETROVIRAL "
 "SYNDROME IS AN HIV RNA VIRAL LOAD, because:\n\n"
 "• at this stage THE VIRAL LOAD IS VERY HIGH (often above 100,000 copies/mL)\n"
 "• it gives an IMMEDIATE answer rather than one in two weeks\n"
 "• and it is exactly what the CDC 2014 algorithm prescribes to resolve ambiguity\n\n"
 "WARNING, THE MOST IMPORTANT CLINICAL MESSAGE: in acute retroviral syndrome the patient is AT THE "
 "MOST INFECTIOUS POINT OF HIS LIFE. So alongside laboratory follow-up, PREVENTION COUNSELLING AND "
 "ABSTINENCE FROM UNPROTECTED CONTACT are essential — one cannot simply wait two weeks and do "
 "nothing.",
 ["پاسخ صحیح — تست سریع مثبت باید تأیید شود، و تکرار پس از دو هفته آنتی‌بادی را قابل تفسیر می‌کند.",
  "الایزا هم یک تست آنتی‌بادی است و در هفته‌ی سوم ممکن است هنوز منفی باشد؛ مشکل زمان است نه نوع تست.",
  "وسترن بلات دیرترین نشانگر است و در عفونت حاد کاذباً منفی می‌شود؛ ضمناً از الگوریتم حذف شده است.",
  "PCR از نظر علمی حساس‌ترین گزینه در این مرحله است، ولی گزینه‌ی کلید تکرار تست است؛ در عمل RNA ارجح است."],
 ["Correct — a positive rapid test must be confirmed, and repeating in two weeks makes the antibody interpretable.",
  "The ELISA is also an antibody test and may still be negative at three weeks; the problem is timing, not the assay.",
  "The Western blot is the latest marker of all and is falsely negative in acute infection; it has also been removed from the algorithm.",
  "PCR is scientifically the most sensitive option at this stage, but the keyed answer is to repeat; in practice RNA is preferable."],
 "**RNA از ۱۰ روز، p24 از ۲ هفته، آنتی‌بادی از ۳ تا ۱۲ هفته.** در عفونت حاد، آنتی‌بادی هنوز نرسیده.",
 "RNA from 10 days, p24 from 2 weeks, antibody from 3 to 12 weeks; in acute infection the antibody has not yet arrived.",
 [CDCLAB, H202])


# =========================================================== book:702
add("book:702", "case", "hard",
 "CD4 پایدار **بالای ۲۰۰ برای بیش از ۳ ماه** ← پروفیلاکسی توکسوپلاسما **قطع می‌شود**.",
 "A CD4 held ABOVE 200 FOR MORE THAN THREE MONTHS means toxoplasma prophylaxis IS STOPPED.",
 CD4_FA + [
  "⚠️ **این سؤال یک قاعده‌ی مهم را می‌سنجد که دانشجویان کمتر به آن فکر می‌کنند: پروفیلاکسی پایان دارد.**",
  "**پروفیلاکسی در HIV یک تجویز مادام‌العمر نیست؛ یک پل موقت است تا ایمنی برگردد.**",
  "**وقتی درمان ضدرتروویروسی CD4 را بالا برد، همان محافظتی که دارو جایگزینش بود برمی‌گردد.**",
  "**پس ادامه دادن دارو فقط عارضه و هزینه و مقاومت اضافه می‌کند، بدون هیچ سودی.**",
  "**آستانه‌های قطع را حفظ کنید:**",
  "**PCP: قطع وقتی CD4 بالای ۲۰۰ و بیش از ۳ ماه پایدار باشد.**",
  "**توکسوپلاسما: قطع وقتی CD4 بالای ۲۰۰ و بیش از ۳ ماه پایدار باشد.**",
  "**MAC: قطع وقتی CD4 بالای ۱۰۰ و بیش از ۳ ماه پایدار باشد.**",
  "⚠️ **شرط «پایداری بیش از ۳ ماه» مهم است: یک اندازه‌گیری تکی کافی نیست.**",
  "**چون CD4 نوسان طبیعی دارد و یک عدد خوب می‌تواند گذرا باشد.**",
  "**در این بیمار، CD4 برابر ۲۵۰ است و ۴ ماه است که در همین حد مانده — هر دو شرط برقرارند.**",
  "**و اگر بعدها CD4 دوباره زیر آستانه رفت، پروفیلاکسی از سر گرفته می‌شود.**",
 ],
 CD4_EN + [
  "WARNING: THIS QUESTION TESTS AN IMPORTANT RULE STUDENTS RARELY THINK ABOUT — PROPHYLAXIS COMES TO AN END.",
  "Prophylaxis in HIV is not a lifelong prescription; it is a temporary bridge until immunity returns.",
  "When antiretroviral therapy raises the CD4, the very protection the drug was substituting for comes back.",
  "Continuing the drug then adds only toxicity, cost and resistance, with no benefit at all.",
  "Memorise the STOPPING thresholds:",
  "PCP: stop when the CD4 is above 200 and has been stable for more than 3 months.",
  "TOXOPLASMA: stop when the CD4 is above 200 and has been stable for more than 3 months.",
  "MAC: stop when the CD4 is above 100 and has been stable for more than 3 months.",
  "WARNING, THE 'STABLE FOR MORE THAN 3 MONTHS' CONDITION MATTERS: a single measurement is not enough.",
  "Because the CD4 fluctuates naturally and one good number may be transient.",
  "In this patient the CD4 is 250 and has held there for 4 months — both conditions are satisfied.",
  "And if the CD4 later falls below the threshold again, prophylaxis is restarted.",
 ],
 "این سؤال یک قاعده‌ی مهم را می‌سنجد که کمتر تدریس می‌شود: **پروفیلاکسی در HIV، مادام‌العمر "
 "نیست.**\n\n"
 "**بیمار HIV مثبت** با **IgG مثبت علیه توکسوپلاسما**، که **۷ ماه است** کوتریموکسازول "
 "پروفیلاکتیک می‌گیرد. **CD4 اکنون ۲۵۰** است و **۴ ماه گذشته هم همین حدود بوده**.\n\n"
 "⚠️ **دو شرط قطع پروفیلاکسی را بررسی کنیم:**\n\n"
 "**شرط یک — آیا CD4 از آستانه گذشته؟** آستانه‌ی توکسوپلاسما **۲۰۰** است. CD4 بیمار "
 "**۲۵۰** است. ✔\n\n"
 "**شرط دو — آیا این وضعیت پایدار است؟** لازم است **بیش از ۳ ماه** بالای آستانه بماند. "
 "در این بیمار **۴ ماه** است. ✔\n\n"
 "**هر دو شرط برقرارند، پس کوتریموکسازول قطع می‌شود.**\n\n"
 "⚠️ **چرا این کار درست است و نه فقط «مجاز»؟**\n\n"
 "**پروفیلاکسی یک پل موقت است، نه یک درمان دائمی.** فلسفه‌اش این است: وقتی ایمنی سلولی "
 "بیمار از کار افتاده، **دارو جای سیستم ایمنی می‌نشیند**. اما وقتی درمان ضدرتروویروسی "
 "**CD4 را بازسازی کرد**، سیستم ایمنی خودش دوباره توانایی مهار توکسوپلاسما را پیدا "
 "می‌کند — و **ادامه دادن دارو فقط ضرر می‌رساند**:\n\n"
 "• **عوارض کوتریموکسازول**: راش (گاه سندرم استیونس-جانسون)، سرکوب مغز استخوان، نارسایی "
 "کلیه، هایپرکالمی\n"
 "• **فشار انتخابی مقاومت**\n"
 "• **بار قرصی اضافه** که پایبندی بیمار به داروهای ضدرتروویروسی اصلی را کم می‌کند\n\n"
 "**جدول آستانه‌های شروع و قطع که باید حفظ شود:**\n\n"
 "عفونت: شروع پروفیلاکسی — قطع پروفیلاکسی\n"
 "**PCP**: CD4 < ۲۰۰ — CD4 > ۲۰۰ برای > ۳ ماه\n"
 "**توکسوپلاسما**: CD4 < ۱۰۰ + IgG مثبت — CD4 > ۲۰۰ برای > ۳ ماه\n"
 "**MAC**: CD4 < ۵۰ — CD4 > ۱۰۰ برای > ۳ ماه\n\n"
 "⚠️ **و چرا شرط «بیش از ۳ ماه» گذاشته شده؟** چون **CD4 نوسان طبیعی روزانه و فصلی دارد** "
 "و یک عدد خوب می‌تواند گذرا باشد. **دو اندازه‌گیری با فاصله‌ی حداقل ۳ ماه** اطمینان "
 "می‌دهد که بازسازی ایمنی واقعی است، نه یک نوسان.\n\n"
 "**و اگر بعدها CD4 دوباره افت کرد؟** پروفیلاکسی **از سر گرفته می‌شود**. این یک تصمیم "
 "برگشت‌پذیر است.",
 "This question tests an important and under-taught rule: PROPHYLAXIS IN HIV IS NOT FOR LIFE.\n\n"
 "AN HIV-POSITIVE PATIENT with POSITIVE TOXOPLASMA IgG, on prophylactic co-trimoxazole FOR SEVEN "
 "MONTHS. The CD4 IS NOW 250 and HAS BEEN AT THAT LEVEL FOR THE PAST FOUR MONTHS.\n\n"
 "WARNING, CHECK THE TWO CONDITIONS FOR STOPPING:\n\n"
 "CONDITION ONE — HAS THE CD4 CROSSED THE THRESHOLD? The toxoplasma threshold is 200. This "
 "patient's CD4 is 250. YES\n\n"
 "CONDITION TWO — IS IT STABLE? It must stay above the threshold FOR MORE THAN 3 MONTHS. In this "
 "patient it has been 4 MONTHS. YES\n\n"
 "BOTH CONDITIONS ARE MET, SO THE CO-TRIMOXAZOLE IS STOPPED.\n\n"
 "WARNING, WHY IS THIS RIGHT AND NOT MERELY PERMISSIBLE?\n\n"
 "PROPHYLAXIS IS A TEMPORARY BRIDGE, NOT A PERMANENT TREATMENT. Its philosophy: while cellular "
 "immunity has failed, THE DRUG STANDS IN FOR THE IMMUNE SYSTEM. But once antiretroviral therapy "
 "HAS REBUILT THE CD4, the immune system can contain toxoplasma by itself — and CONTINUING THE "
 "DRUG ONLY DOES HARM:\n\n"
 "• CO-TRIMOXAZOLE TOXICITY: rash (sometimes Stevens-Johnson syndrome), marrow suppression, renal "
 "impairment, hyperkalaemia\n"
 "• SELECTION PRESSURE FOR RESISTANCE\n"
 "• EXTRA PILL BURDEN, which erodes adherence to the antiretrovirals that actually matter\n\n"
 "THE START AND STOP TABLE TO MEMORISE:\n\n"
 "Infection: Start prophylaxis — Stop prophylaxis\n"
 "PCP: CD4 < 200 — CD4 > 200 for > 3 months\n"
 "TOXOPLASMA: CD4 < 100 with positive IgG — CD4 > 200 for > 3 months\n"
 "MAC: CD4 < 50 — CD4 > 100 for > 3 months\n\n"
 "WARNING, AND WHY THE 'MORE THAN 3 MONTHS' CONDITION? Because THE CD4 FLUCTUATES naturally from "
 "day to day and season to season, and one good number may be transient. TWO MEASUREMENTS AT LEAST "
 "3 MONTHS APART confirm that immune reconstitution is real rather than a fluctuation.\n\n"
 "AND IF THE CD4 LATER FALLS AGAIN? PROPHYLAXIS IS RESTARTED. This is a reversible decision.",
 ["پاسخ صحیح — CD4 بالای ۲۰۰ و پایدار برای بیش از ۳ ماه: شرایط قطع پروفیلاکسی برقرار است.",
  "ادامه دادن دارو در بازسازی ایمنی فقط عارضه و مقاومت و بار قرصی اضافه می‌کند، بدون سود.",
  "تغییر دارو وقتی معنا دارد که عارضه یا شکست باشد؛ اینجا مسئله قطع است نه جایگزینی.",
  "افزودن کلیندامایسین رژیم درمان توکسوپلاسموز فعال است، نه پروفیلاکسی — و بیمار اصلاً بیماری فعال ندارد."],
 ["Correct — a CD4 above 200 held stable for more than 3 months meets the criteria for stopping.",
  "Continuing the drug after immune reconstitution adds only toxicity, resistance and pill burden.",
  "Switching drugs makes sense for toxicity or failure; here the issue is stopping, not substituting.",
  "Adding clindamycin is a regimen for ACTIVE toxoplasmosis, not prophylaxis — and this patient has no active disease."],
 "**پروفیلاکسی یک پل است، نه یک پل دائمی.** بالای آستانه و پایدار برای ۳ ماه = قطع.",
 "Prophylaxis is a bridge, not a permanent one: above the threshold and stable for three months means stop.",
 [OIGUIDE, H202])


# =========================================================== book:706
add("book:706", "case", "hard",
 "CD4=۴۵ + تماس خانگی با سل ← **هر سه**: کوتریموکسازول، آزیترومایسین، و ایزونیازید با ویتامین ب۶.",
 "CD4 of 45 plus a household TB contact needs ALL THREE: co-trimoxazole, azithromycin, and isoniazid with vitamin B6.",
 CD4_FA + [
  "**این سؤال سه تصمیم مستقل را در یک بیمار جمع کرده، و باید هر سه را جداگانه بگیرید.**",
  "**تصمیم یک — CD4 برابر ۴۵ است. کدام آستانه‌ها رد شده‌اند؟**",
  "**زیر ۲۰۰ ← پروفیلاکسی PCP با کوتریموکسازول روزانه.** ✔",
  "**زیر ۵۰ ← پروفیلاکسی MAC با آزیترومایسین هفتگی.** ✔",
  "⚠️ **و دقت کنید: کوتریموکسازول هم‌زمان توکسوپلاسما را هم پوشش می‌دهد — یک دارو، دو کار.**",
  "**تصمیم دو — پدر بیمار هفته‌ی قبل درمان سل شروع کرده. این یعنی تماس نزدیک خانگی.**",
  "**پس درمان عفونت نهفته‌ی سل لازم است: ایزونیازید روزانه.**",
  "⚠️ **و در HIV، بدون منتظر ماندن برای تست پوستی — چون آنرژی، تست را کاذباً منفی می‌کند.**",
  "**تصمیم سه — چرا ویتامین ب۶ (پیریدوکسین) همراه ایزونیازید؟**",
  "**چون ایزونیازید متابولیسم پیریدوکسین را مختل می‌کند و نوروپاتی محیطی می‌سازد.**",
  "**و بیماران HIV مثبت از پیش در معرض نوروپاتی‌اند، پس خطر در آن‌ها بیشتر است.**",
  "**پس پاسخ کامل هر سه جزء را دارد؛ هر گزینه‌ای که یکی را بیندازد، ناقص است.**",
 ],
 CD4_EN + [
  "This question packs three independent decisions into one patient, and each must be taken separately.",
  "DECISION ONE — the CD4 is 45. Which thresholds have been crossed?",
  "BELOW 200 -> PCP prophylaxis with daily co-trimoxazole. YES",
  "BELOW 50 -> MAC prophylaxis with weekly azithromycin. YES",
  "WARNING, AND NOTE: co-trimoxazole simultaneously covers toxoplasma — one drug, two jobs.",
  "DECISION TWO — the patient's father started TB treatment last week. That is a close household contact.",
  "So latent tuberculosis treatment is required: daily isoniazid.",
  "WARNING, AND IN HIV, WITHOUT WAITING FOR A SKIN TEST — because anergy makes it falsely negative.",
  "DECISION THREE — why vitamin B6 (pyridoxine) alongside the isoniazid?",
  "Because isoniazid disturbs pyridoxine metabolism and causes peripheral neuropathy.",
  "And HIV-positive patients are already prone to neuropathy, so their risk is higher still.",
  "So the complete answer contains all three parts; any option that drops one is incomplete.",
 ],
 "این سؤال سه تصمیم کاملاً مستقل را در یک بیمار جمع کرده است. راه درست، گرفتن هر سه تصمیم "
 "**جداگانه** و بعد جمع کردن آن‌هاست.\n\n"
 "**آقای ۲۷ ساله‌ی HIV مثبت** با **CD4 = ۴۵**، که **پدرش هفته‌ی قبل درمان سل را شروع کرده**.\n\n"
 "⚠️ **تصمیم یک — نردبان CD4 را پایین بروید و ببینید کدام پله‌ها رد شده‌اند.**\n\n"
 "آستانه: عفونت — پروفیلاکسی — این بیمار (CD4=۴۵)\n"
 "< ۲۰۰: PCP — **کوتریموکسازول روزانه** — ✔ لازم است\n"
 "< ۱۰۰: توکسوپلاسما — کوتریموکسازول (همان دارو) — ✔ پوشش داده شد\n"
 "< ۵۰: MAC — **آزیترومایسین هفتگی** — ✔ لازم است\n\n"
 "**نکته‌ی زیبا: کوتریموکسازول یک دارو با دو کار است** — هم PCP و هم توکسوپلاسما را "
 "می‌پوشاند. به همین دلیل در فهرست، توکسوپلاسما داروی جداگانه‌ای نمی‌خواهد.\n\n"
 "⚠️ **تصمیم دو — تماس با سل.**\n\n"
 "«**پدر بیمار هفته‌ی قبل تحت درمان TB قرار گرفته**» یعنی **تماس نزدیک و خانگی با یک مورد "
 "فعال سل**. در فرد HIV مثبت، این **بدون هیچ تردیدی** اندیکاسیون **درمان عفونت نهفته‌ی سل** "
 "است: **ایزونیازید روزانه**.\n\n"
 "**و یک نکته‌ی حیاتی:** در HIV با CD4 پایین، **منتظر تست پوستی توبرکولین نمانید**. "
 "**آنرژی** (ناتوانی سیستم ایمنی در پاسخ به تست پوستی) باعث می‌شود تست **کاذباً منفی** "
 "شود. یک PPD منفی در بیماری با CD4=۴۵ **هیچ چیزی را رد نمی‌کند**.\n\n"
 "⚠️ **تصمیم سه — چرا ویتامین ب۶؟**\n\n"
 "**ایزونیازید متابولیسم پیریدوکسین (ب۶) را مختل می‌کند** و شایع‌ترین عارضه‌اش "
 "**نوروپاتی محیطی** است. و بیماران HIV مثبت **از پیش در معرض نوروپاتی‌اند** (هم از خودِ "
 "ویروس، هم از برخی داروهای ضدرتروویروسی). پس **پیریدوکسین ۲۵ تا ۵۰ میلی‌گرم روزانه** یک "
 "همراه اجباری است، نه اختیاری.\n\n"
 "**جمع سه تصمیم: کوتریموکسازول روزانه + آزیترومایسین هفتگی + ایزونیازید روزانه + "
 "ویتامین ب۶ روزانه.** ✅\n\n"
 "**و چرا سه گزینه‌ی دیگر غلط‌اند؟** هر کدام **دقیقاً یک جزء را انداخته‌اند** — یکی "
 "ایزونیازید را، یکی آزیترومایسین را، و یکی کوتریموکسازول را. **این طراحی عمدی است: "
 "سؤال می‌خواهد ببیند آیا هر سه تصمیم را گرفته‌اید یا فقط دو تا.**",
 "This question packs three entirely independent decisions into one patient. The right method is "
 "to take each SEPARATELY and then add them up.\n\n"
 "A 27-YEAR-OLD HIV-POSITIVE MAN with a CD4 OF 45, whose FATHER STARTED TB TREATMENT LAST WEEK.\n\n"
 "WARNING, DECISION ONE — WALK DOWN THE CD4 LADDER AND SEE WHICH RUNGS HAVE BEEN PASSED.\n\n"
 "Threshold: Infection — Prophylaxis — This patient (CD4 45)\n"
 "< 200: PCP — DAILY CO-TRIMOXAZOLE — YES, required\n"
 "< 100: Toxoplasma — co-trimoxazole (same drug) — YES, already covered\n"
 "< 50: MAC — WEEKLY AZITHROMYCIN — YES, required\n\n"
 "AN ELEGANT POINT: CO-TRIMOXAZOLE IS ONE DRUG DOING TWO JOBS — it covers both PCP and toxoplasma. "
 "That is why toxoplasma needs no separate agent on the list.\n\n"
 "WARNING, DECISION TWO — THE TB CONTACT.\n\n"
 "'The patient's father started TB treatment last week' means A CLOSE HOUSEHOLD CONTACT WITH AN "
 "ACTIVE CASE. In an HIV-positive person that is, WITHOUT ANY DOUBT, an indication for LATENT "
 "TUBERCULOSIS TREATMENT: DAILY ISONIAZID.\n\n"
 "AND A CRITICAL POINT: in HIV with a low CD4, DO NOT WAIT FOR A TUBERCULIN SKIN TEST. ANERGY (the "
 "immune system's inability to mount a skin response) makes the test FALSELY NEGATIVE. A negative "
 "PPD in a patient with a CD4 of 45 EXCLUDES NOTHING.\n\n"
 "WARNING, DECISION THREE — WHY VITAMIN B6?\n\n"
 "ISONIAZID DISTURBS PYRIDOXINE (B6) METABOLISM and its commonest adverse effect is PERIPHERAL "
 "NEUROPATHY. And HIV-positive patients are ALREADY PRONE TO NEUROPATHY (from the virus itself and "
 "from some antiretrovirals). So PYRIDOXINE 25 TO 50 MG DAILY is a compulsory companion, not an "
 "optional one.\n\n"
 "ADDING THE THREE DECISIONS: DAILY CO-TRIMOXAZOLE PLUS WEEKLY AZITHROMYCIN PLUS DAILY ISONIAZID "
 "PLUS DAILY VITAMIN B6.\n\n"
 "AND WHY ARE THE OTHER THREE OPTIONS WRONG? Each DROPS EXACTLY ONE COMPONENT — one the isoniazid, "
 "one the azithromycin, one the co-trimoxazole. THAT IS DELIBERATE DESIGN: the question is checking "
 "whether you made all three decisions or only two.",
 ["این گزینه ایزونیازید را انداخته، در حالی که تماس خانگی با سل فعال قطعاً درمان نهفته می‌خواهد.",
  "پاسخ صحیح — CD4 زیر ۵۰ هر دو پروفیلاکسی را می‌طلبد، و تماس با سل ایزونیازید و ب۶ را.",
  "این گزینه آزیترومایسین را انداخته، در حالی که CD4 زیر ۵۰ پروفیلاکسی MAC را الزامی می‌کند.",
  "این گزینه کوتریموکسازول را انداخته، یعنی PCP و توکسوپلاسما هر دو بی‌پوشش می‌مانند."],
 ["This option drops the isoniazid, when a household contact with active TB certainly needs latent treatment.",
  "Correct — a CD4 below 50 demands both prophylaxes, and the TB contact demands isoniazid with B6.",
  "This option drops the azithromycin, when a CD4 below 50 makes MAC prophylaxis mandatory.",
  "This option drops the co-trimoxazole, leaving both PCP and toxoplasma uncovered."],
 "**CD4=۴۵ یعنی هر دو پروفیلاکسی.** و ایزونیازید هرگز بدون ویتامین ب۶ داده نمی‌شود.",
 "A CD4 of 45 means both prophylaxes, and isoniazid is never given without vitamin B6.",
 [OIGUIDE, H202])


# =========================================================== book:700
add("book:700", "case", "medium",
 "HIV + CD4 زیر ۲۰۰ + برفک دهانی + سرفه‌ی دو ماهه ← **بررسی خلط از نظر PCP**.",
 "HIV with a CD4 below 200, oral thrush and two months of cough: EXAMINE THE SPUTUM FOR PCP.",
 CD4_FA + [
  "**سه داده در این سؤال، تشخیص را به یک سمت می‌برند و باید هر سه را کنار هم بگذارید.**",
  "**یک — CD4 زیر ۲۰۰: دقیقاً آستانه‌ی پنوموسیستیس.**",
  "**دو — کاندیدیای دهانی: نشانه‌ی بالینی سرکوب ایمنی پیشرفته، و اغلب همراه PCP دیده می‌شود.**",
  "**سه — سرفه و تنگی نفس با سیر تدریجی دو ماهه.**",
  "⚠️ **تابلوی کلاسیک PCP: سیر تحت‌حاد هفته‌ها، سرفه‌ی خشک، تنگی نفس فعالیتی، تب خفیف.**",
  "**و مشخصه‌ی طلایی‌اش: هیپوکسی نامتناسب با یافته‌های معاینه و گرافی.**",
  "**یعنی بیمار بسیار تنگ‌نفس است ولی سمع ریه تقریباً طبیعی است.**",
  "⚠️ **گرافی ریه: انفیلتراسیون بینابینی منتشر دوطرفه با الگوی پروانه‌ای — و در ۲۰ درصد نرمال.**",
  "**آزمایشگاه: LDH بالا، که هرچند غیراختصاصی است، در PCP تقریباً همیشه بالاست.**",
  "**تشخیص قطعی: دیدن ارگانیسم در خلط القایی یا لاواژ برونکوآلوئولار با رنگ‌آمیزی نقره یا ایمونوفلورسانس.**",
  "**درمان: کوتریموکسازول با دوز بالا، ۲۱ روز.**",
  "⚠️ **و اگر فشار اکسیژن شریانی زیر ۷۰ میلی‌متر جیوه بود، کورتیکواستروئید هم اضافه کنید.**",
 ],
 CD4_EN + [
  "Three pieces of data in this stem point one way, and all three must be put together.",
  "ONE — a CD4 below 200: precisely the pneumocystis threshold.",
  "TWO — oral candidiasis: a clinical marker of advanced immunosuppression, often seen alongside PCP.",
  "THREE — cough and breathlessness with a gradual two-month course.",
  "WARNING, THE CLASSIC PCP PICTURE: a subacute course over weeks, dry cough, exertional dyspnoea, low-grade fever.",
  "And its golden signature: HYPOXIA OUT OF PROPORTION to the examination and the film.",
  "That is, the patient is markedly breathless while the chest sounds almost normal.",
  "WARNING, CHEST FILM: diffuse bilateral interstitial infiltrates in a butterfly pattern — and normal in 20 per cent.",
  "Laboratory: a raised LDH, which although non-specific is almost always high in PCP.",
  "Definitive diagnosis: seeing the organism in induced sputum or bronchoalveolar lavage with silver stain or immunofluorescence.",
  "Treatment: high-dose co-trimoxazole for 21 days.",
  "WARNING, AND IF THE ARTERIAL OXYGEN TENSION IS BELOW 70 MMHG, ADD A CORTICOSTEROID.",
 ],
 "این سؤال یک تمرین «سه داده را کنار هم بگذار» است.\n\n"
 "**آقای ۳۵ ساله‌ی معتاد تزریقی** با **سرفه و تنگی نفس دو ماهه**، **Anti-HIV مثبت**، "
 "**CD4 زیر ۲۰۰**، و **کاندیدیای دهانی** در معاینه.\n\n"
 "⚠️ **سه داده، یک تشخیص:**\n\n"
 "**۱) CD4 زیر ۲۰۰.** این **دقیقاً آستانه‌ی پنوموسیستیس ژیرووسی** است. زیر این عدد، PCP "
 "ممکن می‌شود — و به همین دلیل است که پروفیلاکسی هم از همین‌جا شروع می‌شود.\n\n"
 "**۲) کاندیدیای دهانی (برفک).** این یک **نشانگر بالینی سرکوب ایمنی پیشرفته** است و "
 "**همراهی قوی با PCP** دارد. وجود برفک در بیمار HIV مثبت با علائم تنفسی، احتمال PCP را "
 "به‌شدت بالا می‌برد.\n\n"
 "**۳) سیر دو ماهه‌ی تدریجی.** این **تحت‌حاد** است، نه حاد. پنومونی باکتریال در چند روز "
 "پیشرفت می‌کند؛ **PCP در هفته‌ها** — دقیقاً همین الگو.\n\n"
 "**پس: بررسی خلط از نظر PCP.** ✅\n\n"
 "⚠️ **مشخصه‌ی طلایی PCP که باید بشناسید: هیپوکسی نامتناسب.**\n\n"
 "بیمار **بسیار تنگ‌نفس** است، ولی **سمع ریه تقریباً طبیعی** است و گرافی هم ممکن است کم‌"
 "یافته باشد. این ناهماهنگی بین **شدت علائم** و **کمی یافته‌ها**، تقریباً امضای PCP است. "
 "(علتش این است که ارگانیسم آلوئول‌ها را پر می‌کند و تبادل گاز را مختل می‌کند، بدون آنکه "
 "کنسولیداسیون لوبار بسازد.)\n\n"
 "**سایر یافته‌ها:**\n"
 "• **گرافی:** انفیلتراسیون بینابینی منتشر دوطرفه (الگوی پروانه‌ای) — ولی در **۲۰ درصد "
 "موارد نرمال** است\n"
 "• **LDH بالا** — غیراختصاصی، ولی در PCP تقریباً همیشه بالاست\n"
 "• **تشخیص قطعی:** دیدن ارگانیسم در **خلط القایی** یا **لاواژ برونکوآلوئولار** با "
 "رنگ‌آمیزی نقره یا ایمونوفلورسانس مستقیم (کشت نمی‌شود!)\n\n"
 "**چرا گزینه‌های دیگر نه؟**\n\n"
 "• **آنتی‌ژن کریپتوکوک:** آستانه‌اش CD4 زیر ۱۰۰ است و تابلوی غالبش **مننژیت** است، نه ریوی\n"
 "• **کشت خون برای باسیل اسیدفست:** سل در HIV مهم است، ولی سیر و تابلوی این بیمار و "
 "همراهی برفک، PCP را در اولویت می‌گذارد\n"
 "• **کشت قارچ خلط:** برای قارچ‌های آندمیک، که در این زمینه اولویت ندارند\n\n"
 "**درمان PCP: کوتریموکسازول با دوز بالا به مدت ۲۱ روز.** ⚠️ **و اگر PaO₂ زیر ۷۰ میلی‌متر "
 "جیوه بود، کورتیکواستروئید اضافه کنید** — که مرگ‌ومیر را به‌طور معناداری کم می‌کند.",
 "This question is an exercise in putting three pieces of data together.\n\n"
 "A 35-YEAR-OLD MAN WHO INJECTS DRUGS, with TWO MONTHS of cough and breathlessness, POSITIVE "
 "ANTI-HIV, a CD4 BELOW 200, and ORAL CANDIDIASIS on examination.\n\n"
 "WARNING, THREE PIECES OF DATA, ONE DIAGNOSIS:\n\n"
 "1) CD4 BELOW 200. That is PRECISELY THE PNEUMOCYSTIS JIROVECII THRESHOLD. Below it PCP becomes "
 "possible — which is exactly why prophylaxis also starts here.\n\n"
 "2) ORAL CANDIDIASIS (THRUSH). This is a CLINICAL MARKER OF ADVANCED IMMUNOSUPPRESSION and is "
 "STRONGLY ASSOCIATED WITH PCP. Thrush in an HIV-positive patient with respiratory symptoms sharply "
 "raises the probability of PCP.\n\n"
 "3) A GRADUAL TWO-MONTH COURSE. That is SUBACUTE, not acute. Bacterial pneumonia progresses over "
 "days; PCP OVER WEEKS — exactly this pattern.\n\n"
 "SO: EXAMINE THE SPUTUM FOR PCP.\n\n"
 "WARNING, THE GOLDEN SIGNATURE OF PCP TO RECOGNISE: HYPOXIA OUT OF PROPORTION.\n\n"
 "The patient is MARKEDLY BREATHLESS while THE CHEST SOUNDS ALMOST NORMAL and the film may show "
 "little. That mismatch between SYMPTOM SEVERITY and PAUCITY OF FINDINGS is close to a signature of "
 "PCP. (The reason is that the organism fills the alveoli and wrecks gas exchange without producing "
 "lobar consolidation.)\n\n"
 "OTHER FINDINGS:\n"
 "• FILM: diffuse bilateral interstitial infiltrates in a butterfly pattern — but NORMAL IN 20 PER "
 "CENT of cases\n"
 "• RAISED LDH — non-specific, but almost always high in PCP\n"
 "• DEFINITIVE DIAGNOSIS: seeing the organism in INDUCED SPUTUM or BRONCHOALVEOLAR LAVAGE with "
 "silver stain or direct immunofluorescence (it cannot be cultured)\n\n"
 "WHY NOT THE OTHERS?\n\n"
 "• CRYPTOCOCCAL ANTIGEN: its threshold is a CD4 below 100 and its dominant picture is MENINGITIS, "
 "not pulmonary\n"
 "• BLOOD CULTURE FOR ACID-FAST BACILLI: TB matters greatly in HIV, but this patient's course and "
 "the accompanying thrush put PCP first\n"
 "• FUNGAL SPUTUM CULTURE: for endemic mycoses, which are not the priority in this setting\n\n"
 "TREATMENT OF PCP: HIGH-DOSE CO-TRIMOXAZOLE FOR 21 DAYS. WARNING, AND IF THE PaO2 IS BELOW 70 "
 "MMHG, ADD A CORTICOSTEROID — which significantly reduces mortality.",
 ["آنتی‌ژن کریپتوکوک در CD4 زیر ۱۰۰ و عمدتاً با تابلوی مننژیت مطرح می‌شود، نه سرفه‌ی دو ماهه.",
  "پاسخ صحیح — CD4 زیر ۲۰۰ به‌همراه برفک دهانی و سیر تحت‌حاد تنفسی، PCP را در اولویت می‌گذارد.",
  "سل در HIV بسیار مهم است، ولی برفک و آستانه‌ی CD4 در این بیمار PCP را محتمل‌تر می‌کنند.",
  "کشت قارچی خلط برای قارچ‌های آندمیک است و در این زمینه اولویت تشخیصی ندارد."],
 ["Cryptococcal antigen belongs to a CD4 below 100 and mainly a meningitic picture, not a two-month cough.",
  "Correct — a CD4 below 200 with thrush and a subacute respiratory course puts PCP first.",
  "TB matters greatly in HIV, but the thrush and the CD4 threshold make PCP likelier here.",
  "Fungal sputum culture is for endemic mycoses and is not the diagnostic priority in this setting."],
 "**CD4 زیر ۲۰۰ + برفک + سرفه‌ی هفته‌ها = PCP.** و مشخصه‌اش هیپوکسی نامتناسب است.",
 "A CD4 below 200 with thrush and weeks of cough means PCP, and its signature is hypoxia out of proportion.",
 [OIGUIDE, H202])


# =========================================================== book:669
add("book:669", "case", "medium",
 "پروفیلاکسی پس از مواجهه‌ی شغلی با HIV: **۴ هفته** درمان سه‌دارویی، شروع در **اسرع وقت**.",
 "Occupational HIV post-exposure prophylaxis: FOUR WEEKS of three-drug therapy, started AS SOON AS POSSIBLE.",
 TEST_FA + [
  "⚠️ **پروفیلاکسی پس از مواجهه (PEP) سه عدد دارد که باید حفظ شوند: ۲، ۴ و ۷۲.**",
  "**۲ ساعت — زمان ایده‌آل شروع. هرچه زودتر، مؤثرتر.**",
  "**۴ هفته — مدت کامل درمان.**",
  "**۷۲ ساعت — آخرین مهلت. پس از آن، اثربخشی به‌شدت افت می‌کند.**",
  "**رژیم امروزی: سه دارو، معمولاً تنوفوویر + امتریسیتابین + دولوته‌گراویر (یا رالته‌گراویر).**",
  "⚠️ **و شروع را برای هیچ آزمایشی به تأخیر نیندازید — نه تست منبع، نه تست فرد مواجهه‌یافته.**",
  "**اگر بعداً معلوم شد منبع HIV منفی است، دارو قطع می‌شود. عکسش جبران‌پذیر نیست.**",
  "**خطر انتقال در یک نیدل‌استیک از منبع HIV مثبت حدود ۰٫۳ درصد است.**",
  "**و PEP این خطر را بیش از ۸۰ درصد کاهش می‌دهد.**",
  "⚠️ **پیگیری سرولوژیک: در پایه، ۶ هفته، ۱۲ هفته و ۶ ماه.**",
  "**و در تمام این مدت، پرهیز از اهدای خون و رعایت تماس ایمن لازم است.**",
  "**مقایسه: در تماس با پوست سالم یا بزاق بدون خون، خطر صفر است و PEP لازم نیست.**",
 ],
 TEST_EN + [
  "WARNING: POST-EXPOSURE PROPHYLAXIS (PEP) HAS THREE NUMBERS TO MEMORISE: 2, 4 AND 72.",
  "2 HOURS — the ideal time to start. The sooner, the more effective.",
  "4 WEEKS — the full duration of treatment.",
  "72 HOURS — the outside limit. Beyond it, efficacy falls sharply.",
  "Today's regimen: three drugs, usually tenofovir plus emtricitabine plus dolutegravir (or raltegravir).",
  "WARNING, AND DO NOT DELAY THE START FOR ANY TEST — neither the source's nor the exposed person's.",
  "If the source later proves HIV negative, the drugs are stopped. The reverse cannot be undone.",
  "The transmission risk from a single needlestick with an HIV-positive source is about 0.3 per cent.",
  "And PEP reduces that risk by more than 80 per cent.",
  "WARNING, SEROLOGICAL FOLLOW-UP: at baseline, 6 weeks, 12 weeks and 6 months.",
  "And throughout that period, avoiding blood donation and practising safer sex are required.",
  "For comparison: contact with intact skin or with blood-free saliva carries zero risk and needs no PEP.",
 ],
 "این سؤال یک عدد می‌خواهد، ولی پشت آن عدد یک پروتکل کامل هست که باید بدانید.\n\n"
 "**انترن بخش داخلی**، حین خون‌گیری از **بیمار شناخته‌شده‌ی HIV مثبت**، دچار "
 "**نیدل‌استیک با سوزن خون‌آلود** شده. **مدت درمان پیشگیرانه چقدر است؟**\n\n"
 "**پاسخ: ۴ هفته.**\n\n"
 "⚠️ **سه عددی که باید در کنار هم حفظ شوند — ۲، ۴، ۷۲:**\n\n"
 "عدد: معنا\n"
 "**۲ ساعت**: زمان **ایده‌آل** شروع\n"
 "**۴ هفته**: **مدت کامل** درمان\n"
 "**۷۲ ساعت**: **آخرین مهلت** شروع\n\n"
 "**چرا ۴ هفته؟** این مدت از مطالعات حیوانی و داده‌های مورد-شاهدی به دست آمده و زمانی است "
 "که برای **جلوگیری از استقرار عفونت در سلول‌های هدف** لازم است. کوتاه‌تر از آن، ویروس "
 "فرصت استقرار پیدا می‌کند.\n\n"
 "⚠️ **و مهم‌ترین نکته‌ی عملی: شروع را برای هیچ آزمایشی به تأخیر نیندازید.**\n\n"
 "نه منتظر نتیجه‌ی تست منبع بمانید، نه منتظر تست پایه‌ی خودِ فرد. **منطقش نامتقارن است:**\n\n"
 "• اگر شروع کنید و بعد معلوم شود منبع منفی بوده → **دارو را قطع می‌کنید**، چند روز دارو "
 "بی‌مورد مصرف شده. قابل جبران.\n\n"
 "• اگر منتظر بمانید و پنجره‌ی طلایی از دست برود → **جبران‌ناپذیر است**.\n\n"
 "**رژیم امروزی:** سه دارو — معمولاً **تنوفوویر + امتریسیتابین + دولوته‌گراویر** (یا "
 "رالته‌گراویر). رژیم‌های قدیمی دو دارویی بودند؛ امروز سه‌دارویی استاندارد است.\n\n"
 "**اعداد خطر که ارزش دانستن دارند:**\n\n"
 "نوع مواجهه: خطر انتقال\n"
 "نیدل‌استیک از منبع HIV مثبت: **~۰٫۳٪**\n"
 "پاشیدن به مخاط: ~۰٫۰۹٪\n"
 "**تماس با پوست سالم**: **صفر**\n"
 "**بزاق بدون خون**: **صفر**\n\n"
 "**و PEP این خطر را بیش از ۸۰ درصد کاهش می‌دهد.**\n\n"
 "⚠️ **پیگیری سرولوژیک:** در **پایه، ۶ هفته، ۱۲ هفته و ۶ ماه**. در تمام این مدت، فرد باید "
 "**از اهدای خون خودداری کند** و **تماس جنسی ایمن** داشته باشد.\n\n"
 "**مقایسه‌ی مهم:** در سؤال دیگری از همین فصل، **بزاق بیمار HIV روی دست سالم** ریخته و "
 "پاسخ **«نیاز به اقدام خاصی ندارد»** است. **پوست سالم یک سد کامل است و بزاق بدون خون "
 "ناقل نیست.** تفاوت این دو سؤال، تفاوت **مواجهه‌ی واقعی** و **نگرانی بی‌مورد** است.",
 "This question asks for one number, but behind that number is a whole protocol you must know.\n\n"
 "AN INTERNAL MEDICINE INTERN sustains a NEEDLESTICK WITH A BLOOD-FILLED NEEDLE while taking blood "
 "from a KNOWN HIV-POSITIVE PATIENT. How long should prophylaxis run?\n\n"
 "THE ANSWER: FOUR WEEKS.\n\n"
 "WARNING, THREE NUMBERS TO MEMORISE TOGETHER — 2, 4, 72:\n\n"
 "Number: Meaning\n"
 "2 HOURS: the IDEAL time to start\n"
 "4 WEEKS: the FULL duration\n"
 "72 HOURS: the OUTSIDE LIMIT to start\n\n"
 "WHY FOUR WEEKS? The figure comes from animal studies and case-control data, and is the time "
 "needed TO PREVENT THE VIRUS ESTABLISHING ITSELF IN TARGET CELLS. Anything shorter gives it the "
 "chance to take hold.\n\n"
 "WARNING, AND THE MOST IMPORTANT PRACTICAL POINT: DO NOT DELAY THE START FOR ANY TEST.\n\n"
 "Do not wait for the source's result, nor for the exposed person's baseline. THE LOGIC IS "
 "ASYMMETRIC:\n\n"
 "• Start, then learn the source was negative -> YOU STOP THE DRUGS, having taken a few "
 "unnecessary doses. Recoverable.\n\n"
 "• Wait, and lose the golden window -> IRRECOVERABLE.\n\n"
 "TODAY'S REGIMEN: three drugs — usually TENOFOVIR PLUS EMTRICITABINE PLUS DOLUTEGRAVIR (or "
 "raltegravir). The older regimens used two drugs; three is now standard.\n\n"
 "THE RISK FIGURES WORTH KNOWING:\n\n"
 "Exposure: Transmission risk\n"
 "Needlestick from an HIV-positive source: about 0.3%\n"
 "Mucosal splash: about 0.09%\n"
 "CONTACT WITH INTACT SKIN: ZERO\n"
 "BLOOD-FREE SALIVA: ZERO\n\n"
 "AND PEP REDUCES THAT RISK BY MORE THAN 80 PER CENT.\n\n"
 "WARNING, SEROLOGICAL FOLLOW-UP: at BASELINE, 6 WEEKS, 12 WEEKS AND 6 MONTHS. Throughout, the "
 "person should AVOID DONATING BLOOD and practise SAFER SEX.\n\n"
 "AN IMPORTANT COMPARISON: another question in this chapter has an HIV patient's SALIVA SPILLED ON "
 "INTACT SKIN, and the answer is 'NO ACTION IS NEEDED'. INTACT SKIN IS A COMPLETE BARRIER AND "
 "BLOOD-FREE SALIVA IS NOT INFECTIOUS. The difference between those two questions is the difference "
 "between A REAL EXPOSURE and AN UNDERSTANDABLE WORRY.",
 ["۱۲ هفته مدت پیگیری سرولوژیک است، نه مدت مصرف دارو.",
  "۲ هفته کوتاه‌تر از آن است که از استقرار ویروس در سلول‌های هدف جلوگیری کند.",
  "۸ هفته در هیچ پروتکل استانداردی توصیه نشده و فقط عوارض دارویی را بیشتر می‌کند.",
  "پاسخ صحیح — مدت استاندارد پروفیلاکسی پس از مواجهه ۴ هفته است، با شروع در اسرع وقت."],
 ["Twelve weeks is a serological follow-up interval, not the duration of the drugs.",
  "Two weeks is too short to prevent the virus establishing itself in target cells.",
  "Eight weeks is not recommended in any standard protocol and only adds toxicity.",
  "Correct — the standard post-exposure prophylaxis duration is four weeks, started as soon as possible."],
 "**۲ ساعت ایده‌آل، ۴ هفته مدت، ۷۲ ساعت آخرین مهلت.** و شروع را برای هیچ آزمایشی معطل نکنید.",
 "Two hours is ideal, four weeks is the duration, 72 hours is the deadline; and never delay the start for a test.",
 [CDCLAB, H202])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book31.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 31 lessons:', len(L))
