# -*- coding: utf-8 -*-
"""English stems and options for the batch-15 and batch-16 questions.

Rule 16 checked first, as always: these are sittings 93-98, for which the
ministry published no English booklet, so these are hand-written translations.

Two translation decisions worth recording:

  q9306 (idx 306): the laboratory panel here was entirely mirrored in the
  source and has been repaired from glyph geometry (Na 531 -> 135, WBC 00011 ->
  11000, Hb 41 -> 14, PLT 000302 -> 203000). The English below quotes the
  CORRECTED values, and apply_en.py's numeric guard re-checks every digit
  against the Persian before writing anything. A translation that carried the
  pre-repair numbers would describe a patient who cannot exist.

  q9340 (idx 340): this one was found BY THE TRANSLATION, not before it. The
  Persian stored "mmHg p08" and the English wrote 80, so apply_en.py's numeric
  guard refused the pair and forced a second look at the page. It was right to:
  page 130 prints 8@345.9 0@355.9, so the value really is 80 and the stored
  text was mirrored. fix_gi_numbers.py now repairs it to "80/P". The trailing
  "P" is genuine clinical shorthand — a systolic taken BY PALPATION with no
  audible diastolic — and is preserved rather than "completed" into 80/50, the
  same decision taken for q9830 in the sepsis chapter.
"""

EN7 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    assert all(o.strip() for o in options), idx
    EN7[idx] = {"stem_en": stem, "options_en": options}


# ------------------------------------------------- inflammatory vs secretory
add(286,
    "A student develops fever, nausea, cramping abdominal pain, tenesmus and then diarrhoea two "
    "days after eating a suspect meal out. Stool examination shows abundant white and red blood "
    "cells. All of the following pathogens can cause this syndrome EXCEPT",
    ["Enterotoxigenic E. coli", "Shigella dysenteriae",
     "Campylobacter jejuni", "Yersinia enterocolitica"])

add(297,
    "A person develops watery diarrhoea, nausea and vomiting, without fever or abdominal pain, "
    "5 hours after eating potato salad containing mayonnaise. Which organism is the most likely "
    "cause?",
    ["Clostridium perfringens", "Bacillus cereus", "Staphylococcus aureus", "Vibrio cholerae"])

# ------------------------------------------------------------------- HUS
add(285,
    "A 14-year-old girl is admitted with fever and bloody diarrhoea and is being treated with "
    "ceftriaxone. On the second day of admission she develops a rising creatinine, "
    "thrombocytopenia and anaemia. Stool culture has grown E. coli. Which of the following "
    "actions is correct?",
    ["Add azithromycin", "Add ciprofloxacin",
     "Stop the ceftriaxone and start azithromycin",
     "Stop the ceftriaxone and start no other antibiotic"])

# ---------------------------------------------------------------- cholera
add(332,
    "A 25-year-old man in summer develops high-volume watery diarrhoea 15 times a day for the "
    "past 24 hours, with muscle cramps, nausea and vomiting but no abdominal pain. His stool is "
    "watery, cloudy and the colour of rice water. On examination he is afebrile but has postural "
    "hypotension, tachycardia and reduced skin turgor. Blood tests show a fallen pH and "
    "bicarbonate and a raised creatinine. Which is the most likely causative organism?",
    ["Vibrio cholerae", "Vibrio parahaemolyticus", "Salmonella", "Shigella"])

add(306,
    "A 54-year-old man presents to the emergency department with the sudden onset of severe "
    "watery diarrhoea. On examination he is lethargic, his peripheral pulses are impalpable and "
    "his skin turgor is reduced. His results are Na 135, WBC 11000, Hb 14, PLT 203000, Cr 2 and "
    "K 3.2. Which fluid do you consider most appropriate for correcting his water and "
    "electrolyte losses?",
    ["Third-normal saline in dextrose", "Normal saline",
     "Ringer's lactate", "Dextrose-saline"])

add(340,
    "A 5-year-old child in summer has had watery diarrhoea 10 to 12 times a day for the past 24 "
    "hours. On examination the child is restless and afebrile, the pulses are barely palpable, "
    "and the blood pressure is 80/P mmHg (systolic by palpation). Stool examination shows 0-1 white and red "
    "blood cells. What is the best way to diagnose the causative organism?",
    ["Seeing trophozoites in the stool", "Stool culture on SS medium",
     "Testing the stool for toxin", "Stool culture on TCBS medium"])

add(347,
    "A 25-year-old pregnant woman is brought to the emergency department with the sudden onset of "
    "high-volume watery diarrhoea without fever; she is drowsy and has no palpable pulse. "
    "Alongside correcting her water and electrolytes, which antibiotic is the treatment of choice?",
    ["Doxycycline", "Azithromycin", "Ciprofloxacin", "Amoxicillin"])

# ----------------------------------------------------------- C. difficile
add(308,
    "A 70-year-old man who has been in the ICU for the past 10 days is found to have "
    "Clostridioides difficile toxin in his stool. Which drug most likely caused this clinical "
    "syndrome?",
    ["Fluconazole", "Piperacillin-tazobactam", "Aciclovir", "Clindamycin"])

add(316,
    "An 80-year-old man is currently in the ICU with a stroke and ventilator-associated pneumonia "
    "and is receiving broad-spectrum antibiotics. He has been investigated for Clostridioides "
    "difficile because of bloody diarrhoea, and the toxin is reported positive. The charge nurse "
    "asks your advice about preventing spread to other patients. Which of the following "
    "recommendations has the LEAST effect in preventing transmission of the organism?",
    ["Washing the hands with alcohol",
     "Washing the patient's room with a bleach solution",
     "Washing the hands with soap and water",
     "Restricting antibiotic use"])

add(321,
    "A 25-year-old man with a diabetic foot infection and osteomyelitis presents, after two weeks "
    "of treatment with ciprofloxacin and clindamycin, with bloody diarrhoea and a temperature of "
    "39 degrees. Investigations show a leucocytosis of 17000. Colonoscopy shows colitis with "
    "pseudomembranes. What is your treatment of choice?",
    ["Intravenous metronidazole", "Oral vancomycin",
     "Intravenous metronidazole and vancomycin", "Oral metronidazole and vancomycin"])

# --------------------------------------------------- shigella / salmonella
add(324,
    "A 15-year-old with no underlying disease presents with watery diarrhoea since yesterday. He "
    "is afebrile and shows no evidence of dehydration. Antibiotic treatment is recommended for "
    "which of the following aetiological agents?",
    ["Enterohaemorrhagic E. coli", "Non-typhoidal salmonella",
     "Campylobacter jejuni", "Shigella dysenteriae"])

add(434,
    "A 20-year-old with fever, abdominal pain and bloody diarrhoea, and no history of cardiac "
    "disease, presents for assessment. His stool culture has grown non-typhoidal salmonella. "
    "Which course of action is appropriate for him?",
    ["Cefixime for 3 days", "Ciprofloxacin for one week",
     "Supportive treatment without antibiotics", "Azithromycin for 5 days"])

# ---------------------------------------------------------------- typhoid
add(430,
    "A 17-year-old boy presents with three weeks of step-ladder fever, anorexia, constipation and "
    "abdominal pain. His pain is mainly in the right lower quadrant. On examination he is "
    "somewhat dulled and apathetic, with T 38, PR 74, RR 18 and BP 100/60. Investigations show a "
    "WBC of 3300. Ceftriaxone has been started for him (for 6 days). Given the above, which "
    "diagnostic approach is most appropriate in this patient?",
    ["Bone marrow culture", "Serology", "Blood culture", "Stool culture"])

add(435,
    "A 45-year-old woman had typhoid fever last year and recovered with treatment. At follow-up "
    "one year later her stool culture is still positive for Salmonella typhi. Which course of "
    "action is required?",
    ["Treatment with azithromycin for 4 weeks",
     "Treatment with a cephalosporin for 6 weeks",
     "Treatment with amoxicillin for 6 weeks",
     "Treatment with chloramphenicol for 4 weeks"])
