# -*- coding: utf-8 -*-
"""English stems and options for the batch-11 and batch-12 questions.

Rule 16 checked first, as always: these are sittings 93-98, for which the
ministry published no English booklet, so these are hand-written translations
rather than an official text. Where an official English booklet does exist
(Esfand 1400), its wording is used verbatim instead — see merge_official_en.py.

Two translation decisions worth recording:

  q9761 (idx 761): the Persian option reads "هموگلوبین = 4/5". The Persian
  decimal separator is the slash, so this is 4.5 g/dL, not "4 or 5" and not a
  fraction. Written as "4.5 g/dL". The value was confirmed against the page
  glyphs (4 @ x=399.7, / @ 409.7, 5 @ 414.7), so the printed order really is
  4.5 and the extractor did not mirror it.

  q9805 and q9736 carried mirrored numbers that fix_parasite_numbers.py has
  since corrected from glyph geometry; the English below quotes the CORRECTED
  values, and apply_en.py's numeric guard re-checks every digit against the
  Persian stem before anything is written.
"""

EN5 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    assert all(o.strip() for o in options), idx
    EN5[idx] = {"stem_en": stem, "options_en": options}


# ---------------------------------------------------------------- amoebiasis
add(727,
    "A 30-year-old man presents with lower abdominal pain, cramping and diarrhoea. Stool "
    "examination reports many red blood cells, few white blood cells, and occult blood 3+. "
    "Which organism is the likely cause of his illness?",
    ["Vibrio cholerae", "Entamoeba histolytica", "Giardia", "Shigella"])

add(730,
    "A young man has developed bloody diarrhoea after drinking contaminated water. Stool "
    "examination shows abundant red and white blood cells together with trophozoites of "
    "Entamoeba histolytica. Which of the following is recommended for his treatment?",
    ["Metronidazole", "Ciprofloxacin plus iodoquinol",
     "Metronidazole plus iodoquinol", "Ciprofloxacin"])

add(736,
    "In an asymptomatic person who is a carrier of Entamoeba histolytica cysts, which of the "
    "following is the most appropriate course of action?",
    ["Treat with paromomycin 500 mg three times daily for 7 days",
     "Repeat the stool examination 6 weeks later and, if still positive, treat with iodoquinol",
     "Treat with oral metronidazole only if amoebic colitis develops",
     "No specific action is needed, because the patient is currently asymptomatic"])

add(739,
    "Which is the drug of choice for eradicating the luminal form of amoebiasis?",
    ["Paromomycin", "Metronidazole", "Tinidazole", "Iodoquinol"])

# ---------------------------------------------------------------- giardiasis
add(740,
    "A 35-year-old man presents with abdominal pain and bloody diarrhoea, bloating, belching, "
    "nausea and vomiting. All of the following features are consistent with giardiasis EXCEPT",
    ["Bloody diarrhoea", "Abdominal pain", "Nausea and vomiting", "Bloating"])

add(741,
    "In a patient treated for chronic, recurrent giardiasis in whom the infection nevertheless "
    "persists, which of the following would you recommend investigating?",
    ["Hypogammaglobulinaemia", "Liver ultrasound", "Complement deficiency", "HIV infection"])

# ------------------------------------------------------------- toxoplasmosis
add(746,
    "Transmission of Toxoplasma from mother to fetus is most likely during which period?",
    ["The first trimester", "The second trimester", "The third trimester", "During delivery"])

add(750,
    "A young, non-pregnant, immunocompetent woman presents with cervical lymphadenopathy, and "
    "investigations establish a diagnosis of acute toxoplasmosis. Which treatment is recommended "
    "for her?",
    ["Co-trimoxazole for one month",
     "Pyrimethamine plus sulfadiazine for two months",
     "Intramuscular pentamidine for one month",
     "She needs no drug treatment"])

# ------------------------------------------------------------------ malaria
add(761,
    "A 19-year-old soldier serving on the border of Sistan-Baluchestan and Pakistan presents with "
    "two weeks of intermittent fever, rigors and sweating. The peripheral blood film shows "
    "parasitised red cells containing ring-form trophozoites. Given the most likely diagnosis, "
    "each of the following indicates that the disease is severe EXCEPT",
    ["Haemoglobin 4.5 g/dL", "Platelets 90,000", "Red-coloured urine",
     "A urine output of 250 mL per 24 hours"])

add(765,
    "A 23-year-old man develops headache, fever and rigors after travelling to the south of the "
    "country. The peripheral blood film shows only ring forms and banana-shaped gametocytes. "
    "Which of the following is likely?",
    ["Falciparum malaria", "Vivax malaria", "Ovale malaria", "Malariae malaria"])

add(777,
    "A patient has acquired drug-sensitive vivax malaria following a blood transfusion in one of "
    "the southern cities of the country. Which of the following treatment options is correct for "
    "this patient?",
    ["Chloroquine plus primaquine", "Chloroquine alone",
     "Chloroquine plus mefloquine", "Mefloquine alone"])

add(787,
    "What is the first-line treatment of severe malaria?",
    ["Quinidine", "Artemether-lumefantrine", "Chloroquine", "Artesunate"])

add(789,
    "A 25-year-old man developed fever, rigors and sweating three months ago after returning from "
    "a trip to south-eastern Iran. Investigations at that time reported chloroquine-sensitive "
    "Plasmodium vivax; he was treated with 10 chloroquine tablets, all his symptoms resolved, and "
    "he remained well for three months. A few days ago, with no history of further travel, he "
    "again developed attacks of fever and rigors, and his blood film again reports Plasmodium "
    "vivax. What was the flaw in the treatment given three months ago?",
    ["14 chloroquine tablets should have been given instead of 10",
     "Primaquine was not given for 14 days alongside the chloroquine",
     "Doxycycline was not given for 7 days alongside the chloroquine",
     "Fansidar was not given for 7 days alongside the chloroquine"])

add(790,
    "On which stage of the malaria cycle does pyrimethamine act?",
    ["On the liver phase of vivax and ovale malaria",
     "On the gametocytes of falciparum malaria",
     "On the stage of malaria within the red blood cells",
     "On all of the above"])

add(791,
    "A patient with severe falciparum malaria is brought to the emergency department with a "
    "reduced level of consciousness. Which of the following takes priority?",
    ["Brain CT scan", "Lumbar puncture", "Measuring the blood glucose",
     "Counting the parasites on the peripheral blood film"])

# ---------------------------------------------------------------- helminths
add(807,
    "Which drug can be used safely to treat ascariasis in pregnant women?",
    ["Mebendazole", "Albendazole", "Ivermectin", "Pyrantel pamoate"])

add(814,
    "A 50-year-old patient with rheumatoid arthritis is on high-dose corticosteroid treatment and "
    "is admitted to the infectious diseases ward with septicaemia. Blood culture has grown E. "
    "coli. He gives a history of recurrent urticaria over the buttocks, and complains of "
    "epigastric abdominal pain that is worse with food. What is the most likely causative agent?",
    ["Hookworm", "Strongyloides", "Trichuriasis", "Amoeba"])

add(823,
    "A 50-year-old livestock farmer presents with two months of fever and pain in the upper right "
    "quadrant of the abdomen. Ultrasound reports a cystic lesion with septation, and the serology "
    "sent for hydatid cyst is positive. What do you recommend for this patient?",
    ["Surgery by the PAIR method", "Open surgery with pericystectomy",
     "Albendazole 400 mg daily", "The patient should only be observed"])
