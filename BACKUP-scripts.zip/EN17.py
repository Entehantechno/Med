# -*- coding: utf-8 -*-
"""English stems and options for the batch-35 questions.

HIV transmission, staging, and the first half of the diagnostic algorithm.

Rule 16 checked first, as always: these items come from sittings 93 to 98, for
which the ministry published no English booklet, so these are hand-written
translations rather than official ones.

Translation decisions worth recording
-------------------------------------
q9662 (idx 662) CARRIES A CORRECTED KEY, and the English options are translated
exactly as printed, INCLUDING the option the book keyed. The stem must say what
the paper said; it is the lesson that explains that persistent generalised
lymphadenopathy is category A while cerebral toxoplasmosis has been category C
since 1987. Softening an option in translation would hide the very error the
correction exists to teach.

'COMMONEST' VERSUS 'GREATEST CHANCE' is preserved literally in q9652 and q9655.
The two questions look identical in Persian at a glance and have DIFFERENT
answers, and the only thing separating them is that one says "شایع‌ترین" (the
commonest) and the other "شانس ... بیشتر" (the greater chance). Translating both
as "most likely" would destroy the distinction the pair exists to teach, so
q9652 reads "the commonest route" and q9655 "the greatest chance".

'ESTABLISHED RISK FACTOR' in q9657 keeps the word ESTABLISHED, because that word
is what excludes the fetal scalp electrode, which is avoided as a precaution but
is not as firmly evidenced.

THE CDC CATEGORY LETTERS (A, B, C) and the term AIDS-DEFINING are left in their
standard English forms, because that is how they appear in the source documents
and the whole staging block turns on them.

q9671's numbers are all preserved: 42 years old, 2 admissions, 5 years. The
"twice in five years" is load-bearing in the opposite direction from usual — it
deliberately does NOT meet the "twice in twelve months" definition, which is why
the lesson says the history is a red flag but not AIDS-defining.

q9670's intervals are transcribed exactly as the four options print them
(1-8, 2-5, 3-12 weeks), because the question is decided by comparing bounds.
"""

EN17 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    assert all(o.strip() for o in options), idx
    EN17[idx] = {"stem_en": stem, "options_en": options}


# ==================================================== transmission (batch 35)
add(652,
    "Which of the following is the commonest route of transmission of HIV?",
    ["Heterosexual intercourse",
     "Mother to fetus",
     "Occupational exposure",
     "Transmission of blood products"])

add(653,
    "For transmission of the human immunodeficiency virus (HIV) from an infected person to others, "
    "which of the following routes can cause transmission?",
    ["Saliva",
     "Fluids",
     "Mosquito bite",
     "Breast milk"])

add(654,
    "In which of the following is the probability of HIV transmission greater?",
    ["A human bite",
     "Contact with sweat",
     "Contact with tears",
     "Contact with urine"])

add(655,
    "By which of the following routes is the chance of HIV transmission greater?",
    ["From an infected mother to the fetus during intrauterine life",
     "From an infected mother to the fetus during delivery",
     "Through infusion of infected blood",
     "From an infected mother to the neonate during breastfeeding"])

add(656,
    "Which of the following plays no part in the transmission of HIV?",
    ["Faeces",
     "Urine",
     "Sputum",
     "All of the above"])

add(657,
    "Regarding transmission of HIV from an infected mother to the neonate at the time of delivery, "
    "which of the following is an established risk factor?",
    ["Use of fetal scalp electrodes",
     "Heavy use of narcotics during pregnancy",
     "A long interval between rupture of the amniotic membranes and delivery",
     "The presence of chorioamnionitis at the time of delivery"])

add(658,
    "While you are examining the throat of a patient with HIV, some of his saliva spills onto your "
    "hand. Which is the most appropriate preventive action?",
    ["Perform a PCR test for HIV",
     "Preventive treatment with two antiretroviral drugs",
     "No specific action is required",
     "An antibody ELISA test for HIV"])

add(659,
    "A prison officer comes to you after the saliva of a person with HIV was splashed onto his hand. "
    "Which of the following recommendations do you choose?",
    ["No specific action",
     "Start two-drug chemoprophylaxis",
     "Start three-drug chemoprophylaxis",
     "HIV testing, repeated at one, three and six months"])

add(660,
    "A 27-year-old man presents to you with fever, anorexia and weight loss for about the past month. "
    "In the presence of which of the following histories should the patient be investigated for HIV?",
    ["Smoking opium",
     "Psoriasis",
     "Three episodes of pneumonia in the past year",
     "Admission for meningitis 6 months ago"])


# ========================================================= staging (batch 35)
add(662,
    "All of the following match the clinical features of category C of HIV infection, EXCEPT:",
    ["Cerebral toxoplasmosis",
     "Pneumocystis jirovecii pneumonia",
     "Pulmonary tuberculosis",
     "Persistent generalised lymphadenopathy"])

add(663,
    "In an HIV-positive patient, the presence of which of the following diseases is a criterion "
    "suggesting the AIDS stage?",
    ["Pulmonary tuberculosis",
     "Breast cancer",
     "Lymphocytic leukaemia",
     "Pneumococcal pneumonia"])

add(664,
    "According to the CDC, which of the following is NOT considered AIDS-defining?",
    ["Oesophageal candidiasis",
     "Toxoplasmic encephalitis",
     "Recurrent pneumonia",
     "Oral hairy leucoplakia"])

add(665,
    "Which of the following is NOT related to the manifestations of AIDS?",
    ["Kaposi sarcoma",
     "Oesophageal candidiasis",
     "Pneumococcal pneumonia",
     "Invasive cervical cancer"])

add(666,
    "All of the following are considered AIDS-defining conditions in people with HIV, EXCEPT:",
    ["Oesophageal candidiasis",
     "Pulmonary tuberculosis",
     "CMV retinitis",
     "Oral hairy leucoplakia"])

add(667,
    "A 38-year-old HIV-positive man with gross cachexia and oral candidiasis was admitted three weeks "
    "ago with a diagnosis of chronic pneumonia. He reports no previous episode of pulmonary "
    "infection. Proving which of the following organisms as the cause of his illness would NOT place "
    "him within the definition of the AIDS stage?",
    ["Mycobacterium tuberculosis",
     "Mycobacterium avium complex",
     "Streptococcus pneumoniae",
     "Pneumocystis jirovecii"])

add(668,
    "All of the following statements about acute HIV infection are true, EXCEPT:",
    ["Fever and lymphadenopathy can be features of this period",
     "An opportunistic infection may occur in this period",
     "The CD4 cell count falls",
     "It is diagnosed by an HIV antibody test using ELISA"])


# ============================================== diagnostic chain (batch 35)
add(670,
    "When does anti-HIV antibody become measurable in the blood?",
    ["1 to 8 weeks after infection",
     "2 to 5 weeks after infection",
     "3 to 12 weeks after infection",
     "None of the above"])

add(671,
    "You are seeing a 42-year-old man who has presented with oral ulcers. He is self-employed and is "
    "on a maintenance dose of methadone. In his past medical history he has had 2 admissions for "
    "bacterial pneumonia over the past 5 years. In addition, last year he attended a doctor once for "
    "oral thrush and was treated with nystatin. At present, apart from the aphthous oral lesions, "
    "there is nothing else in his history or examination. Which action do you give priority to in "
    "this patient?",
    ["ANA and anti-DNA",
     "Pathergy test",
     "Anti-HIV 1&2 ELISA",
     "Measurement of serum immunoglobulin levels"])

add(672,
    "A young man of 24 presents to the infectious diseases clinic 4 weeks after unprotected sexual "
    "intercourse, complaining of sore throat, high fever, multiple cervical lymphadenopathy and body "
    "aches, and is worried about having acquired HIV. Which is the appropriate diagnostic action at "
    "this stage?",
    ["Perform a Western blot test",
     "Perform an HIV RNA PCR test",
     "Perform a CD4 count",
     "Perform an ELISA (EIA) test"])

add(673,
    "For diagnosing HIV infection, which of the following options is the most appropriate?",
    ["Two positive ELISA tests and one confirmation by Western blot",
     "One positive ELISA test and two confirmations by Western blot",
     "One positive ELISA test and one confirmation by Western blot",
     "Three positive ELISA tests"])
