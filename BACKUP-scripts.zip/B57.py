# -*- coding: utf-8 -*-
"""Micro-lessons, batch 57 — tuberculosis part seven, completing the chapter
(80 of 80): preventive therapy in the child contact, and the newborn of a
mother with tuberculosis.

THE CHILD CONTACT: ONE RULE, AND ONE AGE THRESHOLD
----------------------------------------------------
    A CHILD UNDER FIVE WHO IS A CLOSE CONTACT OF A SMEAR-POSITIVE CASE
    RECEIVES PREVENTIVE ISONIAZID REGARDLESS OF THE TUBERCULIN RESULT,
    ONCE ACTIVE DISEASE HAS BEEN EXCLUDED.

The reasoning is the same as in HIV, and rests on three facts:

FACT ONE — THE YOUNG CHILD'S IMMUNITY IS IMMATURE. Cell-mediated immunity is
not fully developed, so the tuberculin test is UNRELIABLE and may be falsely
negative even in a genuinely infected child.

FACT TWO — THE STAKES ARE FAR HIGHER THAN IN AN ADULT. An infected adult has
roughly a 10 % lifetime risk. AN INFECTED INFANT UNDER ONE YEAR HAS ABOUT A
40 % RISK OF PROGRESSING TO DISEASE, and — the part that matters most —
a very high risk of the two lethal forms: MILIARY TUBERCULOSIS and
TUBERCULOUS MENINGITIS. Those two are why the whole policy exists.

FACT THREE — THE COST OF THE INTERVENTION IS TRIVIAL. Isoniazid in a child is
remarkably well tolerated: hepatotoxicity, which rises steeply with age in
adults, is RARE in young children.

Asymmetric risks with a cheap remedy always give the same answer: TREAT.

THE STANDARD PATHWAY, WHICH THE BOOK USES REPEATEDLY
------------------------------------------------------
    exclude active disease (history, examination, chest film)
    start isoniazid
    repeat the tuberculin test at 3 months
        if it has CONVERTED — complete a full course (6 to 9 months)
        if it is still NEGATIVE and the source is no longer infectious —
            preventive therapy may be stopped

That three-month repeat is called WINDOW PROPHYLAXIS: the child is covered
through the window period, and the test is then repeated when it has become
interpretable.

THE NEWBORN OF A MOTHER WITH TUBERCULOSIS
-------------------------------------------
    BREASTFEEDING IS NOT STOPPED. Mycobacterium tuberculosis is not
        transmitted in milk, and the antituberculous drugs pass into milk in
        negligible amounts. Separating mother and baby causes far more harm
        than it prevents.
    SEPARATION IS NOT REQUIRED once the mother has been treated for about two
        weeks and is improving; a mask and good ventilation suffice.
    ISONIAZID PROPHYLAXIS IS GIVEN TO THE INFANT for six months.
    BCG IS DEFERRED until isoniazid is finished — because BCG is a LIVE
        vaccine and isoniazid would kill the vaccine strain, wasting it. BCG
        is then given at the end.
    If the mother has been treated long enough that she is no longer
        infectious at delivery, the infant needs no prophylaxis and BCG is
        given normally.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022) —
tuberculosis; WHO consolidated guidelines on tuberculosis, Module 5:
Management of tuberculosis in children and adolescents (2022); Iranian
National Tuberculosis Programme guideline.
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — tuberculosis")
WHO5 = ("WHO consolidated guidelines on tuberculosis, Module 5: Management of "
        "tuberculosis in children and adolescents (2022)")
NTP = "راهنمای کشوری مبارزه با سل — National Tuberculosis Programme guideline"
REFS = [H, WHO5]
REFSN = [H, WHO5, NTP]

# ============================================ CHILD CONTACT
CHILD_FA = [
    "⚠️ **کودک زیر پنج سال در تماس نزدیک، بدون توجه به تست، پروفیلاکسی می‌گیرد.**",
    "**سه دلیل، و هر سه در یک جهت‌اند.**",
    "**دلیل یک: ایمنی سلولی کودک خردسال هنوز نابالغ است.**",
    "**پس تست توبرکولین می‌تواند در کودک واقعاً عفونی هم منفی باشد.**",
    "⚠️ **دلیل دو: خطر در کودک بسیار بزرگ‌تر از بزرگسال است.**",
    "**در بزرگسال حدود ۱۰٪ در طول عمر؛ در شیرخوار زیر یک سال حدود ۴۰٪.**",
    "**و مهم‌تر از عدد، نوع بیماری است.**",
    "**کودک خردسال به دو شکل کشنده می‌رود: سل میلیاری و مننژیت سلی.**",
    "**دلیل سه: هزینه‌ی مداخله ناچیز است.**",
    "**ایزونیازید در کودک بسیار خوب تحمل می‌شود و هپاتوتوکسیسیتی نادر است.**",
    "⚠️ **مسیر استاندارد: رد سل فعال، شروع ایزونیازید، تکرار تست در سه ماه.**",
    "**اگر تبدیل شد، دوره کامل شود؛ اگر منفی ماند و منبع دیگر مسری نیست، قطع.**",
]
CHILD_EN = [
    "WARNING: A CHILD UNDER FIVE IN CLOSE CONTACT RECEIVES PROPHYLAXIS REGARDLESS OF THE TEST.",
    "Three reasons, all pointing the same way.",
    "REASON ONE: the young child's cell-mediated immunity is still immature.",
    "So the tuberculin test can be negative even in a genuinely infected child.",
    "WARNING, REASON TWO: THE RISK IN A CHILD IS FAR GREATER THAN IN AN ADULT.",
    "About 10 % over a lifetime in an adult; ABOUT 40 % IN AN INFANT UNDER ONE YEAR.",
    "And more important than the number is the TYPE of disease.",
    "A young child progresses to the two lethal forms: MILIARY TUBERCULOSIS and TUBERCULOUS MENINGITIS.",
    "REASON THREE: the cost of the intervention is trivial.",
    "Isoniazid is extremely well tolerated in children and hepatotoxicity is rare.",
    "WARNING, THE STANDARD PATHWAY: exclude active disease, start isoniazid, repeat the test at three months.",
    "If it has converted, complete the course; if still negative and the source is no longer infectious, stop.",
]

add("book:272", "recall", "medium",
    "**فرزند شش‌ماهه‌ی بیمار اسمیر مثبت: تست بگیرید، ولی پروفیلاکسی را بدون توجه به آن شروع کنید.**",
    "The six-month-old child of a smear-positive patient: do the test, but start prophylaxis regardless of it.",
    CHILD_FA, CHILD_EN,
    "این سؤال، سنگ‌بنای خوشه‌ی کودکان است — و منطقش دقیقاً همان منطق خوشه‌ی HIV "
    "است، با علتی متفاوت.\n\n"
    "**بیمار: در یک بیمار مبتلا به سل ریوی اسمیر مثبت که دارای یک فرزند ۶ ماهه "
    "است، کدام اقدام را توصیه می‌کنید؟**\n\n"
    "**پاسخ: انجام تست توبرکولین و شروع پروفیلاکسی بدون توجه به نتیجه‌ی آن.**\n\n"
    "⚠️ **دقت کنید که پاسخ دو جزء دارد، و هر دو ضروری‌اند:**\n\n"
    "**جزء اول: تست را انجام بدهید.** چرا؟ چون **نتیجه‌ی پایه‌ای** لازم است. اگر سه "
    "ماه بعد تست را تکرار کنید و مثبت باشد، **فقط با داشتن پایه می‌توانید بگویید "
    "«تبدیل» رخ داده**. بدون پایه، مثبت بودن معنای روشنی ندارد.\n\n"
    "**جزء دوم: پروفیلاکسی را بدون توجه به نتیجه شروع کنید.** و **این جزء، جان کودک "
    "را نجات می‌دهد.**\n\n"
    "**چرا در شیرخوار ۶ ماهه، تست نباید تصمیم بگیرد؟ سه دلیل:**\n\n"
    "**دلیل یک — تست غیرقابل اعتماد است.** ایمنی سلولی در شیرخوار **هنوز نابالغ "
    "است**. پاسخ ازدیاد حساسیت تأخیری ضعیف است، و **کودک واقعاً عفونی می‌تواند تست "
    "منفی داشته باشد**. **در شیرخوار زیر یک سال، منفی کاذب شایع است.**\n\n"
    "⚠️ **دلیل دو — خطر بسیار بزرگ است، و بدتر از آن، نوعش خطرناک است.**\n\n"
    "**در بزرگسال عفونی، خطر بیمار شدن حدود ۱۰٪ در تمام عمر است.** **در شیرخوار زیر "
    "یک سال، حدود ۴۰٪** — یعنی **چهار برابر**.\n\n"
    "**ولی عدد، تنها بخش ماجرا نیست. مهم‌تر این است که کودک خردسال به کدام شکل "
    "بیمار می‌شود:** بزرگسال معمولاً سل ریوی می‌گیرد، ولی **کودک زیر دو سال با احتمال "
    "بسیار بالاتری به سل میلیاری و مننژیت سلی می‌رود** — دو شکلی که **مرگ و ناتوانی "
    "عصبی دائمی** می‌سازند. **کل سیاست پروفیلاکسی کودکان برای پیشگیری از همین دو "
    "شکل نوشته شده است.**\n\n"
    "**دلیل سه — هزینه‌ی مداخله ناچیز است.** ایزونیازید در کودکان **فوق‌العاده خوب "
    "تحمل می‌شود**. **هپاتوتوکسیسیتی که در بزرگسال با سن بالا می‌رود، در کودک خردسال "
    "نادر است.**\n\n"
    "**خطرهای نامتقارن + درمان ارزان و بی‌خطر = همیشه یک پاسخ: درمان کن.**\n\n"
    "**و البته یک شرط الزامی: پیش از شروع، سل فعال رد شود** — شرح حال، معاینه، و "
    "گرافی قفسه‌ی سینه. **در کودک با سل فعال، ایزونیازید تنها یعنی تک‌درمانی و "
    "ساختن مقاومت.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**در صورت مثبت بودن تست، شروع درمان چهاردارویی** — **دو خطا:** اول، تصمیم را "
    "به تست بی‌اعتبار سپرده. دوم، **چهار دارو یعنی درمان بیماری فعال**، در حالی که "
    "تست مثبت فقط **عفونت** را نشان می‌دهد، نه بیماری.\n\n"
    "⚠️ **در صورت مثبت بودن تست، شروع پروفیلاکسی** — **گزینه‌ی فریبنده و نزدیک‌ترین به "
    "درست.** درمان درست است، ولی **شرط غلطی برایش گذاشته**. **اگر تست منفی باشد "
    "(که در شیرخوار محتمل است)، این گزینه کودک را بدون محافظت رها می‌کند** — دقیقاً "
    "همان کودکی که بیشترین خطر را دارد.\n\n"
    "**در صورت منفی بودن تست، شروع پروفیلاکسی** — منطقاً وارونه است: چرا کودک با "
    "تست **مثبت** (که شواهد عفونت دارد) پروفیلاکسی نگیرد؟",
    "This question is the cornerstone of the paediatric cluster — and its logic is exactly that of the HIV cluster, for a different reason.\n\n"
    "THE QUESTION: in a patient with smear-positive pulmonary tuberculosis who has a SIX-MONTH-OLD child, what do you recommend?\n\n"
    "THE ANSWER: DO THE TUBERCULIN TEST AND START PROPHYLAXIS REGARDLESS OF ITS RESULT.\n\n"
    "WARNING: NOTE THAT THE ANSWER HAS TWO PARTS, AND BOTH ARE NECESSARY:\n\n"
    "PART ONE: DO THE TEST. Why? Because A BASELINE IS NEEDED. If you repeat the test in three months and it is positive, ONLY A BASELINE LETS YOU SAY THAT CONVERSION HAS OCCURRED. Without one, a positive result has no clear meaning.\n\n"
    "PART TWO: START PROPHYLAXIS REGARDLESS OF THE RESULT. AND THIS PART SAVES THE CHILD'S LIFE.\n\n"
    "WHY MUST THE TEST NOT DECIDE IN A SIX-MONTH-OLD? THREE REASONS:\n\n"
    "REASON ONE — THE TEST IS UNRELIABLE. Cell-mediated immunity in an infant IS STILL IMMATURE. The delayed hypersensitivity response is weak, and A GENUINELY INFECTED CHILD CAN HAVE A NEGATIVE TEST. IN INFANTS UNDER ONE YEAR, FALSE NEGATIVES ARE COMMON.\n\n"
    "WARNING, REASON TWO — THE RISK IS VERY LARGE, AND WORSE, ITS TYPE IS DANGEROUS.\n\n"
    "IN AN INFECTED ADULT the risk of disease is about 10 % over a lifetime. IN AN INFANT UNDER ONE YEAR IT IS ABOUT 40 % — FOUR TIMES AS HIGH.\n\n"
    "BUT THE NUMBER IS NOT THE WHOLE STORY. What matters more is WHICH FORM the young child develops: an adult usually gets pulmonary disease, but A CHILD UNDER TWO IS FAR MORE LIKELY TO PROGRESS TO MILIARY TUBERCULOSIS AND TUBERCULOUS MENINGITIS — two forms that cause DEATH AND PERMANENT NEUROLOGICAL DISABILITY. THE ENTIRE PAEDIATRIC PROPHYLAXIS POLICY WAS WRITTEN TO PREVENT THOSE TWO.\n\n"
    "REASON THREE — THE COST OF THE INTERVENTION IS TRIVIAL. Isoniazid is REMARKABLY WELL TOLERATED in children. THE HEPATOTOXICITY THAT RISES WITH AGE IN ADULTS IS RARE IN YOUNG CHILDREN.\n\n"
    "ASYMMETRIC RISKS PLUS A CHEAP, SAFE REMEDY ALWAYS GIVE THE SAME ANSWER: TREAT.\n\n"
    "AND ONE MANDATORY CONDITION: EXCLUDE ACTIVE DISEASE FIRST — history, examination and chest film. IN A CHILD WITH ACTIVE DISEASE, ISONIAZID ALONE IS MONOTHERAPY AND BREEDS RESISTANCE.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "'IF THE TEST IS POSITIVE, START FOUR-DRUG TREATMENT' — TWO ERRORS: first, it hands the decision to an unreliable test; second, FOUR DRUGS MEANS TREATING ACTIVE DISEASE, whereas a positive test shows only INFECTION.\n\n"
    "WARNING: 'IF THE TEST IS POSITIVE, START PROPHYLAXIS' — THE SEDUCTIVE OPTION AND THE CLOSEST TO RIGHT. The treatment is correct but IT ATTACHES THE WRONG CONDITION. IF THE TEST IS NEGATIVE (likely in an infant), THIS OPTION LEAVES THE CHILD UNPROTECTED — precisely the child at greatest risk.\n\n"
    "'IF THE TEST IS NEGATIVE, START PROPHYLAXIS' — logically inverted: why would a child with a POSITIVE test, who has evidence of infection, not receive prophylaxis?",
    ["دو خطا: تصمیم را به تست بی‌اعتبار سپرده، و چهار دارو یعنی درمان بیماری فعال نه عفونت.",
     "درمان درست با شرط غلط؛ اگر تست منفی باشد، پرخطرترین کودک را بدون محافظت رها می‌کند.",
     "منطقاً وارونه است؛ چرا کودک با تست مثبت که شواهد عفونت دارد پروفیلاکسی نگیرد؟",
     "پاسخ صحیح — تست برای پایه، و پروفیلاکسی بدون توجه به نتیجه، پس از رد سل فعال."],
    ["Two errors: it hands the decision to an unreliable test, and four drugs treat disease rather than infection.",
     "The right treatment with the wrong condition; a negative test would leave the highest-risk child unprotected.",
     "Logically inverted; why would a child with a positive test, showing infection, not receive prophylaxis?",
     "Correct — the test for a baseline, and prophylaxis regardless of the result, once active disease is excluded."],
    "**در کودک خردسال، تست تصمیم نمی‌گیرد — چون هدف پیشگیری از میلیاری و مننژیت است.**",
    "In a young child the test does not decide — because the aim is to prevent miliary disease and meningitis.",
    REFSN)

add("book:274", "vignette", "medium",
    "**کودک سه‌ساله با PPD منفی: ایزونیازید شروع و PPD در سه ماه تکرار شود.**",
    "A three-year-old with a negative PPD: start isoniazid and repeat the PPD at three months.",
    CHILD_FA, CHILD_EN,
    "این سؤال، **مسیر استاندارد کامل** را می‌پرسد — نه فقط «بده یا نده»، بلکه "
    "**«چطور اداره کن»**.\n\n"
    "**بیمار: خانم ۳۲ ساله با تشخیص سل ریوی اسمیر مثبت، تحت درمان. برای فرزند ۳ "
    "ساله‌ی وی تست PPD انجام شده و نتیجه منفی است.**\n\n"
    "**پاسخ: شروع درمان پروفیلاکسی با ایزونیازید و تکرار PPD بعد از ۳ ماه.**\n\n"
    "**این پاسخ دو حرکت دارد، و هر کدام دلیل روشنی دارد:**\n\n"
    "⚠️ **حرکت اول: شروع فوری ایزونیازید، با وجود تست منفی.**\n\n"
    "**دو دلیل، که با هم کار می‌کنند:**\n\n"
    "**الف) دوره‌ی پنجره.** اگر تماس اخیر بوده، تست می‌تواند **فقط به‌دلیل زودهنگام "
    "بودن** منفی باشد. **تبدیل تست ۲ تا ۱۲ هفته زمان می‌برد.**\n\n"
    "**ب) نابالغی ایمنی.** در کودک ۳ ساله، حتی پس از گذشت زمان کافی هم، پاسخ می‌تواند "
    "ضعیف و منفی کاذب باشد.\n\n"
    "**پس دو راه مستقل وجود دارد که این تست منفی، غلط باشد. و اگر غلط باشد، کودک "
    "در معرض ۲۰ تا ۴۰ درصد خطر بیماری — با احتمال بالای مننژیت سلی — رها شده "
    "است.**\n\n"
    "**حرکت دوم: تکرار PPD بعد از سه ماه.**\n\n"
    "**چرا سه ماه؟** چون **پنجره‌ی حداکثر ۱۲ هفته** است. پس از سه ماه، **تست دیگر "
    "قابل تفسیر است**.\n\n"
    "**و نتیجه‌ی تکرار، مسیر را تعیین می‌کند:**\n\n"
    "**اگر تبدیل شده بود (مثبت شد)** ⇐ **عفونت اثبات شده**؛ دوره‌ی کامل ۶ تا ۹ ماهه "
    "را تمام کنید.\n\n"
    "**اگر همچنان منفی است و مادر دیگر مسری نیست** ⇐ می‌توان پروفیلاکسی را **قطع "
    "کرد**، چون هم پنجره گذشته و هم مواجهه تمام شده.\n\n"
    "**این راهبرد را «پروفیلاکسی پنجره‌ای» (window prophylaxis) می‌نامند: کودک را در "
    "دوره‌ای که تست کور است محافظت کنید، و وقتی تست بینا شد، دوباره تصمیم "
    "بگیرید.**\n\n"
    "⚠️ **نکته‌ی عملی مهم: مادر تحت درمان است.** این خوب است، ولی **مسری بودن تا "
    "حدود دو هفته پس از شروع درمان مؤثر ادامه دارد** — و کودک احتمالاً پیش از تشخیص "
    "مادر هم در معرض بوده. **پس مواجهه‌ی گذشته نمی‌تواند نادیده گرفته شود.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**درمان پروفیلاکسی با ایزونیازید به‌مدت ۹ ماه** — ⚠️ **گزینه‌ی نزدیک، ولی ناقص.** "
    "شروع دارو درست است، ولی **مرحله‌ی بازارزیابی را حذف کرده**. اگر تست سه ماه بعد "
    "منفی بماند و مادر دیگر مسری نباشد، **۶ ماه دارو اضافه‌تر داده‌ایم**.\n\n"
    "⚠️ **اقدام خاصی لازم ندارد، اما سه ماه بعد معاینه شود** — **خطرناک‌ترین گزینه.** "
    "کودک را **در دوره‌ی پنجره بدون محافظت رها می‌کند**. و **مننژیت سلی در کودک "
    "می‌تواند ظرف همان سه ماه رخ دهد و ناتوانی دائمی بگذارد.**\n\n"
    "**تکرار PPD بعد از ۳ ماه و شروع درمان در صورت مثبت بودن** — **دقیقاً همان خطا "
    "با ظاهر علمی‌تر.** **مشاهده‌ی منفعل به‌جای محافظت فعال.**",
    "This question asks for THE COMPLETE STANDARD PATHWAY — not merely 'give or withhold' but 'HOW TO MANAGE'.\n\n"
    "THE PATIENT: a 32-year-old woman with smear-positive pulmonary tuberculosis, on treatment. Her THREE-YEAR-OLD child has had a PPD, and it is NEGATIVE.\n\n"
    "THE ANSWER: START PREVENTIVE ISONIAZID AND REPEAT THE PPD AFTER THREE MONTHS.\n\n"
    "THIS ANSWER HAS TWO MOVES, EACH WITH A CLEAR REASON:\n\n"
    "WARNING, MOVE ONE: START ISONIAZID IMMEDIATELY DESPITE THE NEGATIVE TEST.\n\n"
    "TWO REASONS WORKING TOGETHER:\n\n"
    "(a) THE WINDOW PERIOD. If the exposure was recent, the test may be negative MERELY BECAUSE IT IS TOO EARLY. CONVERSION TAKES 2 TO 12 WEEKS.\n\n"
    "(b) IMMUNE IMMATURITY. In a three-year-old, even after enough time has passed, the response can be weak and falsely negative.\n\n"
    "SO THERE ARE TWO INDEPENDENT ROUTES BY WHICH THIS NEGATIVE TEST COULD BE WRONG. And if it is wrong, THE CHILD HAS BEEN LEFT EXPOSED TO A 20 TO 40 % RISK OF DISEASE, WITH A HIGH CHANCE OF TUBERCULOUS MENINGITIS.\n\n"
    "MOVE TWO: REPEAT THE PPD AFTER THREE MONTHS.\n\n"
    "WHY THREE MONTHS? Because the window is AT MOST 12 WEEKS. After three months THE TEST IS INTERPRETABLE AGAIN.\n\n"
    "AND THE REPEAT RESULT DETERMINES THE PATH:\n\n"
    "IF IT HAS CONVERTED (turned positive) — INFECTION IS PROVEN; complete a full 6- to 9-month course.\n\n"
    "IF IT IS STILL NEGATIVE AND THE MOTHER IS NO LONGER INFECTIOUS — prophylaxis CAN BE STOPPED, since both the window has passed and the exposure has ended.\n\n"
    "THIS STRATEGY IS CALLED WINDOW PROPHYLAXIS: protect the child while the test is blind, and decide again once the test can see.\n\n"
    "WARNING, AN IMPORTANT PRACTICAL POINT: THE MOTHER IS ON TREATMENT. That is good, but INFECTIOUSNESS PERSISTS FOR ABOUT TWO WEEKS AFTER EFFECTIVE TREATMENT BEGINS — and the child was probably exposed before her diagnosis too. SO PAST EXPOSURE CANNOT BE IGNORED.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "'PREVENTIVE ISONIAZID FOR NINE MONTHS' — WARNING, CLOSE BUT INCOMPLETE. Starting the drug is right, but IT OMITS THE REASSESSMENT STEP. If the test remains negative at three months and the mother is no longer infectious, WE WILL HAVE GIVEN SIX UNNECESSARY EXTRA MONTHS.\n\n"
    "WARNING: 'NOTHING SPECIFIC IS NEEDED, JUST EXAMINE HIM IN THREE MONTHS' — THE MOST DANGEROUS OPTION. It LEAVES THE CHILD UNPROTECTED THROUGH THE WINDOW PERIOD. AND TUBERCULOUS MENINGITIS CAN DEVELOP WITHIN THOSE VERY THREE MONTHS AND LEAVE PERMANENT DISABILITY.\n\n"
    "'REPEAT THE PPD AFTER 3 MONTHS AND TREAT IF POSITIVE' — EXACTLY THE SAME ERROR IN A MORE SCIENTIFIC-LOOKING DRESS. PASSIVE OBSERVATION INSTEAD OF ACTIVE PROTECTION.",
    ["شروع دارو درست است ولی مرحله‌ی بازارزیابی سه‌ماهه را حذف کرده و ممکن است شش ماه اضافه بدهد.",
     "خطرناک‌ترین گزینه؛ کودک را در دوره‌ی پنجره بدون محافظت رها می‌کند.",
     "پاسخ صحیح — پروفیلاکسی پنجره‌ای: محافظت فوری، و بازارزیابی وقتی تست بینا شد.",
     "همان خطا با ظاهر علمی‌تر؛ مشاهده‌ی منفعل به‌جای محافظت فعال."],
    ["Starting the drug is right but it omits the three-month reassessment and may add six needless months.",
     "The most dangerous option; it leaves the child unprotected through the window period.",
     "Correct — window prophylaxis: protect at once, reassess when the test can see again.",
     "The same error in a more scientific-looking dress; passive observation instead of active protection."],
    "**پروفیلاکسی پنجره‌ای: در دوره‌ای که تست کور است محافظت کن، و بعد دوباره تصمیم بگیر.**",
    "Window prophylaxis: protect while the test is blind, and decide again afterwards.",
    REFSN)

add("book:276", "vignette", "medium",
    "**کودک چهارساله با اندوراسیون ۲ میلی‌متر: سه ماه ایزونیازید، سپس تکرار PPD.**",
    "A four-year-old with a 2 mm induration: three months of isoniazid, then repeat the PPD.",
    CHILD_FA, CHILD_EN,
    "این سؤال، همان مسیر است، ولی از منظر **پروتکل کشوری** — و عبارت «طبق پروتکل "
    "کشوری» در متن سؤال، عمدی است.\n\n"
    "**بیمار: کودک ۴ ساله در تماس با مادربزرگش که مبتلا به سل ریوی خلط مثبت بوده. "
    "کودک هیچ علامتی از بیماری سل ندارد. تست پوستی PPD انجام شده و ۲ میلی‌متر "
    "اندوراسیون داشت.**\n\n"
    "**پاسخ: سه ماه درمان پیشگیرانه با ایزونیازید، سپس تست PPD انجام شود، سپس "
    "تصمیم‌گیری در مورد ادامه‌ی درمان پیشگیرانه.**\n\n"
    "**سه بخش پاسخ را جدا ببینید:**\n\n"
    "**بخش یک — شروع فوری ایزونیازید، با وجود ۲ میلی‌متر.**\n\n"
    "**۲ میلی‌متر با هر آستانه‌ای منفی است** (کودک زیر ۵ سال: آستانه ۱۰). ⚠️ **ولی در "
    "کودک زیر پنج سال در تماس نزدیک، عدد تست تصمیم را نمی‌گیرد** — به همان سه دلیلی "
    "که می‌دانیم: **ایمنی نابالغ، خطر ۲۰ تا ۴۰ درصدی با احتمال میلیاری و مننژیت، و "
    "بی‌خطری ایزونیازید در کودک**.\n\n"
    "**بخش دو — تکرار تست پس از سه ماه.**\n\n"
    "پنجره‌ی حداکثر ۱۲ هفته گذشته و **تست حالا قابل تفسیر است**.\n\n"
    "**بخش سه — «سپس تصمیم‌گیری در مورد ادامه».**\n\n"
    "**این عبارت، مهم‌ترین بخش پاسخ است**، چون **دو مسیر ممکن را باز نگه می‌دارد:**\n\n"
    "**اگر تست مثبت شد** ⇐ تبدیل رخ داده، **عفونت اثبات شد**؛ دوره‌ی کامل ادامه یابد.\n\n"
    "**اگر منفی ماند و مادربزرگ دیگر مسری نیست** ⇐ می‌توان **قطع کرد**.\n\n"
    "**نکته‌ی مربوط به منبع: مادربزرگ.** تماس با پدربزرگ و مادربزرگ در خانواده‌های "
    "ایرانی بسیار نزدیک و طولانی است — **گاهی نزدیک‌تر از تماس با والدین شاغل**. "
    "**در بررسی تماس، هرگز فقط والدین را نپرسید.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "⚠️ **انجام رادیوگرافی و در صورت غیرطبیعی بودن، درمان پیشگیری** — **دو خطای "
    "منطقی جدی در یک جمله.**\n\n"
    "**خطای اول:** رادیوگرافی **باید** انجام شود، ولی هدفش **رد کردن سل فعال** است — "
    "**نه تصمیم‌گیری درباره‌ی پروفیلاکسی**.\n\n"
    "⚠️ **خطای دوم و بزرگ‌تر: منطق وارونه شده.** اگر گرافی **غیرطبیعی** باشد، آن کودک "
    "احتمالاً **سل فعال** دارد و به **درمان چهاردارویی کامل** نیاز دارد، **نه به "
    "پروفیلاکسی تک‌دارویی**. **دادن ایزونیازید تنها به کودک با سل فعال، مطمئن‌ترین "
    "راه ساختن سل مقاوم به ایزونیازید در یک کودک است.** **این گزینه دقیقاً برعکس "
    "آن چیزی را می‌گوید که باید.**\n\n"
    "**سه ماه ایزونیازید، سپس گرافی ریه** — گرافی **در ابتدا** لازم است، نه در ماه "
    "سوم. **و در ماه سوم، آنچه تصمیم را می‌سازد تست پوستی است، نه گرافی** — چون "
    "دنبال **تبدیل** می‌گردیم، و تبدیل را تست نشان می‌دهد.\n\n"
    "**گرافی و در صورت طبیعی بودن، دوره‌ی کامل ۶ ماه** — ⚠️ **گزینه‌ی نزدیک.** رد سل "
    "فعال با گرافی **درست است**، و شش ماه هم **طول درمان معتبری** است. **ولی مرحله‌ی "
    "بازارزیابی سه‌ماهه را حذف کرده** — که در پروتکل کشوری صراحتاً وجود دارد و "
    "امکان **قطع زودهنگام** را در کودکی که عفونی نشده فراهم می‌کند.",
    "This question follows the same pathway, but from the standpoint of THE NATIONAL PROTOCOL — and the phrase 'according to the national protocol' in the stem is deliberate.\n\n"
    "THE PATIENT: a four-year-old in contact with his grandmother, who had smear-positive pulmonary tuberculosis. The child has no symptoms. His PPD measures 2 MM of induration.\n\n"
    "THE ANSWER: THREE MONTHS OF PREVENTIVE ISONIAZID, THEN REPEAT THE PPD, THEN DECIDE ABOUT CONTINUING.\n\n"
    "SEE THE THREE PARTS SEPARATELY:\n\n"
    "PART ONE — START ISONIAZID AT ONCE DESPITE THE 2 MM.\n\n"
    "TWO MILLIMETRES IS NEGATIVE AGAINST ANY THRESHOLD (a child under five: threshold 10). WARNING: BUT IN A CHILD UNDER FIVE IN CLOSE CONTACT, THE TEST NUMBER DOES NOT DECIDE — for the same three reasons we know: IMMATURE IMMUNITY, A 20 TO 40 % RISK WITH A HIGH CHANCE OF MILIARY DISEASE AND MENINGITIS, AND THE SAFETY OF ISONIAZID IN CHILDREN.\n\n"
    "PART TWO — REPEAT THE TEST AFTER THREE MONTHS.\n\n"
    "The maximum 12-week window has passed and THE TEST IS NOW INTERPRETABLE.\n\n"
    "PART THREE — 'THEN DECIDE ABOUT CONTINUING'.\n\n"
    "THAT PHRASE IS THE MOST IMPORTANT PART OF THE ANSWER, because it KEEPS TWO PATHS OPEN:\n\n"
    "IF THE TEST TURNS POSITIVE — conversion has occurred, INFECTION IS PROVEN; complete the full course.\n\n"
    "IF IT REMAINS NEGATIVE AND THE GRANDMOTHER IS NO LONGER INFECTIOUS — it can be STOPPED.\n\n"
    "A POINT ABOUT THE SOURCE: THE GRANDMOTHER. Contact with grandparents in Iranian families is very close and prolonged — SOMETIMES CLOSER THAN WITH WORKING PARENTS. IN CONTACT TRACING, NEVER ASK ONLY ABOUT THE PARENTS.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "WARNING: 'DO A RADIOGRAPH AND, IF ABNORMAL, GIVE PREVENTIVE TREATMENT' — TWO SERIOUS LOGICAL ERRORS IN ONE SENTENCE.\n\n"
    "THE FIRST ERROR: a radiograph SHOULD be done, but its purpose is TO EXCLUDE ACTIVE DISEASE — NOT TO DECIDE ABOUT PROPHYLAXIS.\n\n"
    "WARNING, THE SECOND AND LARGER ERROR: THE LOGIC IS INVERTED. If the film is ABNORMAL, that child probably has ACTIVE DISEASE and needs FULL FOUR-DRUG TREATMENT, NOT SINGLE-DRUG PROPHYLAXIS. GIVING ISONIAZID ALONE TO A CHILD WITH ACTIVE DISEASE IS THE SUREST WAY TO CREATE ISONIAZID-RESISTANT TUBERCULOSIS IN A CHILD. THIS OPTION SAYS EXACTLY THE OPPOSITE OF WHAT IT SHOULD.\n\n"
    "'THREE MONTHS OF ISONIAZID, THEN A CHEST FILM' — the film is needed AT THE START, not in the third month. AND IN THE THIRD MONTH IT IS THE SKIN TEST THAT DECIDES, NOT THE FILM — because we are looking for CONVERSION, and only the test shows that.\n\n"
    "'A FILM AND, IF NORMAL, A FULL SIX-MONTH COURSE' — WARNING, A CLOSE OPTION. Excluding active disease with a film is RIGHT, and six months IS a valid duration. BUT IT OMITS THE THREE-MONTH REASSESSMENT, which the national protocol explicitly includes and which allows EARLY DISCONTINUATION in a child who was never infected.",
    ["دو خطا؛ گرافی برای رد سل فعال است نه تصمیم پروفیلاکسی، و گرافی غیرطبیعی یعنی درمان کامل نه تک‌دارو.",
     "پاسخ صحیح — سه ماه ایزونیازید، تکرار تست، و سپس تصمیم درباره‌ی ادامه.",
     "گرافی در ابتدا لازم است نه ماه سوم؛ و در ماه سوم تست پوستی تصمیم را می‌سازد نه گرافی.",
     "رد سل فعال درست است ولی مرحله‌ی بازارزیابی سه‌ماهه‌ی پروتکل کشوری را حذف کرده."],
    ["Two errors; the film excludes active disease rather than deciding prophylaxis, and an abnormal film means full treatment.",
     "Correct — three months of isoniazid, repeat the test, then decide about continuing.",
     "The film is needed at the start, not in month three; and at month three the skin test decides, not the film.",
     "Excluding active disease is right but it omits the national protocol's three-month reassessment."],
    "**گرافی برای رد سل فعال است، نه برای تصمیم پروفیلاکسی — و گرافی غیرطبیعی یعنی درمان کامل.**",
    "The film excludes active disease, it does not decide prophylaxis — and an abnormal film means full treatment.",
    REFSN)

add("book:278", "vignette", "medium",
    "**کودک دوساله با PPD منفی: شروع درمان پروفیلاکسی با ایزونیازید.**",
    "A two-year-old with a negative PPD: start preventive isoniazid.",
    CHILD_FA, CHILD_EN,
    "این سؤال، ساده‌ترین شکل قاعده است — و ارزشش در **سن بیمار** است.\n\n"
    "**بیمار: خانم خانه‌داری که اخیراً تشخیص سل ریوی اسمیر مثبت گرفته. کودک ۲ "
    "ساله‌ی وی که بررسی بالینی از نظر سل منفی بوده و PPD منفی دارد.**\n\n"
    "**پاسخ: شروع درمان پروفیلاکسی با ایزونیازید.**\n\n"
    "⚠️ **سن ۲ سال، مهم‌ترین عدد این سؤال است — مهم‌تر از عدد PPD.**\n\n"
    "**چرا؟ خطر پیشرفت به بیماری، شدیداً وابسته به سن است، و منحنی آن U شکل "
    "است:**\n\n"
    "**زیر ۱ سال: خطر بیماری حدود ۴۰٪ · و خطر شکل منتشر (میلیاری یا مننژیت) حدود "
    "۱۰ تا ۲۰٪**\n\n"
    "**۱ تا ۲ سال: خطر بیماری حدود ۲۰ تا ۲۵٪ · خطر شکل منتشر حدود ۲ تا ۵٪**\n\n"
    "**۲ تا ۵ سال: خطر حدود ۵٪**\n\n"
    "**۵ تا ۱۰ سال: کمترین خطر در تمام عمر — «سن طلایی»**\n\n"
    "**نوجوانی و بزرگسالی: دوباره افزایش، حدود ۱۰ تا ۲۰٪**\n\n"
    "**پس کودک ۲ ساله در ناحیه‌ی پرخطر منحنی است، و مهم‌تر از عدد کلی، خطر "
    "بالای مننژیت سلی است.**\n\n"
    "**«بررسی بالینی از نظر سل منفی» یعنی سل فعال رد شده** — پس شرط لازم برای "
    "پروفیلاکسی برآورده است. (در عمل، **گرافی قفسه‌ی سینه هم لازم است**، چون کودک "
    "خردسال می‌تواند سل فعال بدون علامت بالینی داشته باشد.)\n\n"
    "**و «PPD منفی» — همان‌طور که در سه سؤال قبل دیدیم — تصمیم را عوض نمی‌کند.**\n\n"
    "**رژیم: ایزونیازید ۶ تا ۹ ماه**، با تکرار تست در سه ماه طبق پروتکل. (در "
    "راهنماهای امروزی، **3HR** یا **3HP** هم برای کودکان بالای ۲ سال گزینه‌های "
    "مناسبی‌اند و **نرخ تکمیل بسیار بهتری** دارند.)\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "⚠️ **انجام تست PPD یک ماه بعد** — **دو خطا در یک گزینه.**\n\n"
    "**خطای اول: یک ماه برای تبدیل کافی نیست** — پنجره تا **۱۲ هفته** است، پس تست "
    "یک‌ماهه هم می‌تواند منفی کاذب باشد.\n\n"
    "**خطای دوم و بزرگ‌تر: کودک در این یک ماه بدون محافظت است.** و در کودک ۲ ساله، "
    "**مننژیت سلی می‌تواند در همین بازه شروع شود**.\n\n"
    "**شروع درمان سل با رژیم چهاردارویی** — **درمان بیماری فعال در کودکی که "
    "بیماری فعال ندارد.** بررسی بالینی منفی است. **چهار دارو در کودک ۲ ساله یعنی "
    "بار سمّی و پایش پیچیده‌ی بی‌مورد** — به‌ویژه **اتامبوتول که در کودک خردسال به‌دلیل "
    "دشواری سنجش دید رنگی، با احتیاط بیشتری استفاده می‌شود**.\n\n"
    "⚠️ **نیاز به اقدام خاصی نیست** — **خطرناک‌ترین گزینه، و شایع‌ترین خطای واقعی در "
    "بالین.** پزشک تست منفی را می‌بیند، خیالش راحت می‌شود، و کودک را می‌فرستد. **چند "
    "ماه بعد همان کودک با تشنج و کاهش سطح هوشیاری برمی‌گردد — و مننژیت سلی، حتی با "
    "درمان، در بخش بزرگی از موارد ناتوانی عصبی دائمی می‌گذارد.**",
    "This question is the simplest form of the rule — and its value lies in THE PATIENT'S AGE.\n\n"
    "THE PATIENT: a housewife recently diagnosed with smear-positive pulmonary tuberculosis. Her TWO-YEAR-OLD child has a negative clinical assessment for tuberculosis and a NEGATIVE PPD.\n\n"
    "THE ANSWER: START PREVENTIVE ISONIAZID.\n\n"
    "WARNING: THE AGE OF TWO IS THE MOST IMPORTANT NUMBER IN THIS QUESTION — MORE IMPORTANT THAN THE PPD.\n\n"
    "WHY? BECAUSE THE RISK OF PROGRESSION IS STRONGLY AGE-DEPENDENT, AND THE CURVE IS U-SHAPED:\n\n"
    "UNDER 1 YEAR: about a 40 % risk of disease, and a 10 to 20 % risk of DISSEMINATED disease (miliary or meningitis).\n\n"
    "1 TO 2 YEARS: about a 20 to 25 % risk of disease, with a 2 to 5 % risk of dissemination.\n\n"
    "2 TO 5 YEARS: about 5 %.\n\n"
    "5 TO 10 YEARS: the lowest risk of a whole lifetime — the 'golden age'.\n\n"
    "ADOLESCENCE AND ADULTHOOD: rising again, to about 10 to 20 %.\n\n"
    "SO A TWO-YEAR-OLD SITS IN THE HIGH-RISK REGION OF THE CURVE, and more important than the overall figure is THE HIGH RISK OF TUBERCULOUS MENINGITIS.\n\n"
    "'A NEGATIVE CLINICAL ASSESSMENT' MEANS ACTIVE DISEASE IS EXCLUDED — so the precondition for prophylaxis is met. (In practice A CHEST FILM IS ALSO NEEDED, because a young child can have active disease with no clinical signs.)\n\n"
    "AND THE NEGATIVE PPD — as in the three previous questions — DOES NOT CHANGE THE DECISION.\n\n"
    "THE REGIMEN: ISONIAZID FOR 6 TO 9 MONTHS, with a repeat test at three months per protocol. (In current guidance, 3HR or 3HP are also good options for children over two and have MUCH BETTER COMPLETION RATES.)\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "WARNING: 'DO A PPD IN ONE MONTH' — TWO ERRORS IN ONE OPTION.\n\n"
    "THE FIRST ERROR: ONE MONTH IS NOT ENOUGH FOR CONVERSION — the window runs to 12 WEEKS, so a one-month test can also be falsely negative.\n\n"
    "THE SECOND AND LARGER ERROR: THE CHILD IS UNPROTECTED FOR THAT MONTH. And in a two-year-old, TUBERCULOUS MENINGITIS CAN BEGIN WITHIN EXACTLY THAT INTERVAL.\n\n"
    "'START FOUR-DRUG ANTITUBERCULOUS TREATMENT' — TREATING ACTIVE DISEASE IN A CHILD WHO DOES NOT HAVE IT. The clinical assessment is negative. FOUR DRUGS IN A TWO-YEAR-OLD MEANS NEEDLESS TOXIC BURDEN AND COMPLEX MONITORING — especially ETHAMBUTOL, WHICH IS USED MORE CAUTIOUSLY IN SMALL CHILDREN BECAUSE COLOUR VISION IS HARD TO ASSESS.\n\n"
    "WARNING: 'NOTHING SPECIFIC IS NEEDED' — THE MOST DANGEROUS OPTION, AND THE COMMONEST REAL-WORLD ERROR. The doctor sees a negative test, is reassured, and sends the child home. MONTHS LATER THAT SAME CHILD RETURNS WITH SEIZURES AND A FALLING CONSCIOUS LEVEL — and tuberculous meningitis, even treated, leaves permanent neurological disability in a large share of cases.",
    ["پاسخ صحیح — کودک دوساله در ناحیه‌ی پرخطر منحنی سنی است؛ تست منفی تصمیم را عوض نمی‌کند.",
     "دو خطا: یک ماه برای تبدیل کافی نیست، و کودک در این مدت بدون محافظت می‌ماند.",
     "درمان بیماری فعال در کودکی که بررسی بالینی منفی دارد؛ بار سمّی بی‌مورد.",
     "خطرناک‌ترین گزینه و شایع‌ترین خطای بالینی؛ مننژیت سلی ناتوانی دائمی می‌گذارد."],
    ["Correct — a two-year-old sits in the high-risk region of the age curve; a negative test does not change the decision.",
     "Two errors: one month is too short for conversion, and the child is unprotected meanwhile.",
     "Treating active disease in a child whose clinical assessment is negative; needless toxic burden.",
     "The most dangerous option and the commonest real-world error; tuberculous meningitis leaves permanent disability."],
    "**خطر سل در کودک با سن رابطه‌ی U شکل دارد — و زیر پنج سال، مننژیت در کمین است.**",
    "The risk of tuberculosis in a child follows a U-shaped age curve — and under five, meningitis lies in wait.",
    REFSN)

add("book:275", "vignette", "medium",
    "**شیرخوار نه‌ماهه‌ی مادر مسلول: پروفیلاکسی و ارزیابی بالینی هر دو ماه.**",
    "The nine-month-old infant of a mother with tuberculosis: prophylaxis with clinical review every two months.",
    CHILD_FA + [
        "⚠️ **در شیرخوار، پیگیری بالینی منظم بخشی از پروفیلاکسی است، نه جایگزین آن.**",
        "**چون مننژیت سلی در شیرخوار می‌تواند سریع و بی‌سروصدا شروع شود.**",
    ],
    CHILD_EN + [
        "WARNING: IN AN INFANT, REGULAR CLINICAL REVIEW IS PART OF PROPHYLAXIS, NOT A SUBSTITUTE FOR IT.",
        "Because tuberculous meningitis in an infant can begin quickly and quietly.",
    ],
    "این سؤال، **پیگیری** را به مسیر اضافه می‌کند — و در شیرخوار، پیگیری منظم به "
    "اندازه‌ی خود دارو مهم است.\n\n"
    "**بیمار: خانم ۲۷ ساله با سل ریوی اسمیر مثبت، تحت درمان چهاردارویی. جهت کودک "
    "شیرخوار ۹ ماهه‌ی این مادر چه توصیه‌ای می‌کنید؟**\n\n"
    "**پاسخ: در صورت نداشتن سل فعال، پروفیلاکسی دارویی شروع و هر دو ماه ارزیابی "
    "بالینی می‌کنیم.**\n\n"
    "**سه جزء این پاسخ را ببینید:**\n\n"
    "**جزء یک — «در صورت نداشتن سل فعال».** این شرط همیشگی است و **قابل حذف نیست**. "
    "در شیرخوار، رد سل فعال شامل **معاینه، وزن‌گیری، و گرافی قفسه‌ی سینه** است. "
    "⚠️ **در شیرخوار، سل فعال می‌تواند تنها با «رشد نکردن» و بی‌قراری تظاهر کند** — بدون "
    "سرفه و بدون تب واضح.\n\n"
    "**جزء دو — شروع پروفیلاکسی، بدون هیچ شرط دیگری.** توجه کنید که سؤال اصلاً "
    "**عددی از PPD نداده** — و لازم هم ندارد. **شیرخوار ۹ ماهه‌ی مادرِ اسمیر مثبت، "
    "پرخطرترین وضعیت ممکن است**: تماس **بیست‌وچهار ساعته**، در فاصله‌ی **صفر**، و در "
    "سنی که خطر بیماری حدود **۲۰ تا ۴۰ درصد** و خطر مننژیت **بالاترین** است.\n\n"
    "**جزء سه — ارزیابی بالینی هر دو ماه.**\n\n"
    "**چرا پیگیری منظم این‌قدر مهم است؟ سه دلیل:**\n\n"
    "⚠️ **الف) پروفیلاکسی صددرصد مؤثر نیست.** حتی با ایزونیازید، درصد کوچکی از "
    "شیرخواران بیمار می‌شوند. **پیگیری منظم، آن‌ها را زود می‌گیرد.**\n\n"
    "**ب) مننژیت سلی در شیرخوار سریع پیش می‌رود** و علائم اولیه‌اش **مبهم** است: "
    "بی‌قراری، بی‌اشتهایی، استفراغ، خواب‌آلودگی. **تنها راه گرفتنش، دیدن مکرر کودک "
    "است.**\n\n"
    "**ج) پایش وزن و رشد**، حساس‌ترین شاخص عمومی سلامت در شیرخوار است — **افت منحنی "
    "رشد، اغلب نخستین نشانه‌ی بیماری است**.\n\n"
    "**نکته‌ی تکمیلی درباره‌ی شیردهی: مادر باید به شیردهی ادامه دهد.** سل از راه شیر "
    "منتقل نمی‌شود و داروهای ضدسل در مقادیر ناچیز وارد شیر می‌شوند. **جدا کردن مادر "
    "و نوزاد، آسیبش بسیار بیشتر از فایده‌اش است.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "⚠️ **در صورت رادیوگرافی غیرطبیعی، پروفیلاکسی شروع کنیم** — **منطق وارونه، و "
    "خطرناک.** اگر گرافی شیرخوار **غیرطبیعی** باشد، احتمالاً **سل فعال** دارد و به "
    "**درمان کامل چهاردارویی** نیاز دارد، **نه به پروفیلاکسی تک‌دارویی**. "
    "**و برعکس، گرافی طبیعی دقیقاً همان شرطی است که پروفیلاکسی را مجاز می‌کند.**\n\n"
    "**فقط اگر PPD بیش از ۵ میلی‌متر باشد** — **تصمیم را به تستی سپرده که در شیرخوار "
    "۹ ماهه کمترین اعتبار را دارد.** ایمنی سلولی در این سن **نابالغ‌ترین** حالت خود "
    "را دارد.\n\n"
    "**هر سه ماه ارزیابی و شروع پروفیلاکسی فقط در صورت مثبت شدن PPD و گرافی "
    "غیرطبیعی** — **بدترین گزینه، چون سه خطا را جمع کرده:** فاصله‌ی پیگیری طولانی‌تر "
    "· تکیه بر تست بی‌اعتبار · و **شرط گرافی غیرطبیعی که یعنی منتظر ماندن تا بیماری "
    "فعال شود**.",
    "This question adds FOLLOW-UP to the pathway — and in an infant, regular review matters as much as the drug.\n\n"
    "THE PATIENT: a 27-year-old woman with smear-positive pulmonary tuberculosis on four-drug therapy. What do you advise for her NINE-MONTH-OLD infant?\n\n"
    "THE ANSWER: IF ACTIVE DISEASE IS ABSENT, START PROPHYLAXIS AND REVIEW CLINICALLY EVERY TWO MONTHS.\n\n"
    "SEE THE THREE COMPONENTS:\n\n"
    "COMPONENT ONE — 'IF ACTIVE DISEASE IS ABSENT'. This condition is permanent and NOT OPTIONAL. In an infant, excluding active disease means EXAMINATION, WEIGHT CHECK AND A CHEST FILM. WARNING: IN AN INFANT, ACTIVE TUBERCULOSIS CAN PRESENT ONLY AS FAILURE TO THRIVE AND IRRITABILITY — with no cough and no obvious fever.\n\n"
    "COMPONENT TWO — START PROPHYLAXIS, WITH NO FURTHER CONDITION. Note that the question GIVES NO PPD FIGURE AT ALL — and needs none. A NINE-MONTH-OLD INFANT OF A SMEAR-POSITIVE MOTHER IS THE HIGHEST-RISK SITUATION THERE IS: TWENTY-FOUR-HOUR contact, at ZERO distance, at an age when the risk of disease is 20 TO 40 % and the risk of meningitis is at its HIGHEST.\n\n"
    "COMPONENT THREE — CLINICAL REVIEW EVERY TWO MONTHS.\n\n"
    "WHY IS REGULAR FOLLOW-UP SO IMPORTANT? THREE REASONS:\n\n"
    "WARNING, (a) PROPHYLAXIS IS NOT 100 % EFFECTIVE. Even on isoniazid a small proportion of infants fall ill. REGULAR REVIEW CATCHES THEM EARLY.\n\n"
    "(b) TUBERCULOUS MENINGITIS IN AN INFANT MOVES FAST, and its early signs are VAGUE: irritability, poor feeding, vomiting, drowsiness. THE ONLY WAY TO CATCH IT IS TO SEE THE CHILD REPEATEDLY.\n\n"
    "(c) MONITORING WEIGHT AND GROWTH is the most sensitive general index of health in an infant — A FALL ACROSS THE GROWTH CENTILES IS OFTEN THE FIRST SIGN OF DISEASE.\n\n"
    "A SUPPLEMENTARY POINT ON BREASTFEEDING: THE MOTHER SHOULD CONTINUE. Tuberculosis is not transmitted in milk, and the drugs enter milk in negligible amounts. SEPARATING MOTHER AND INFANT DOES FAR MORE HARM THAN GOOD.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "WARNING: 'START PROPHYLAXIS IF THE RADIOGRAPH IS ABNORMAL' — INVERTED AND DANGEROUS LOGIC. If the infant's film is ABNORMAL he probably has ACTIVE DISEASE and needs FULL FOUR-DRUG TREATMENT, NOT SINGLE-DRUG PROPHYLAXIS. AND CONVERSELY, A NORMAL FILM IS PRECISELY THE CONDITION THAT PERMITS PROPHYLAXIS.\n\n"
    "'ONLY IF THE PPD EXCEEDS 5 MM' — IT HANDS THE DECISION TO A TEST THAT IS LEAST VALID IN A NINE-MONTH-OLD. Cell-mediated immunity at this age is at its MOST IMMATURE.\n\n"
    "'REVIEW EVERY THREE MONTHS AND START PROPHYLAXIS ONLY IF THE PPD CONVERTS AND THE FILM IS ABNORMAL' — THE WORST OPTION, GATHERING THREE ERRORS: a longer review interval, reliance on an invalid test, and A REQUIREMENT FOR AN ABNORMAL FILM, WHICH MEANS WAITING FOR ACTIVE DISEASE.",
    ["منطق وارونه؛ گرافی غیرطبیعی یعنی سل فعال و درمان کامل، نه پروفیلاکسی تک‌دارویی.",
     "پاسخ صحیح — پروفیلاکسی پس از رد سل فعال، به‌همراه ارزیابی بالینی منظم هر دو ماه.",
     "تصمیم را به تستی سپرده که در شیرخوار نه‌ماهه کمترین اعتبار را دارد.",
     "بدترین گزینه؛ پیگیری طولانی‌تر، تست بی‌اعتبار، و انتظار تا فعال شدن بیماری."],
    ["Inverted logic; an abnormal film means active disease and full treatment, not single-drug prophylaxis.",
     "Correct — prophylaxis once active disease is excluded, with regular clinical review every two months.",
     "It hands the decision to the test least valid in a nine-month-old.",
     "The worst option; longer intervals, an invalid test, and waiting for active disease to appear."],
    "**در شیرخوار، پیگیری منظم بخشی از پروفیلاکسی است — نه جایگزین آن.**",
    "In an infant, regular follow-up is part of prophylaxis — not a substitute for it.",
    REFSN)

add("book:279", "recall", "medium",
    "**پسربچه‌ی سه‌ساله با PPD ده میلی‌متر: پس از رد بیماری فعال، پروفیلاکسی.**",
    "A three-year-old boy with a 10 mm PPD: after excluding active disease, prophylaxis.",
    CHILD_FA + [
        "⚠️ **در کودک زیر پنج سال، آستانه‌ی PPD ده میلی‌متر است.**",
        "**و همیشه پیش از پروفیلاکسی، بیماری فعال باید رد شود.**",
    ],
    CHILD_EN + [
        "WARNING: IN A CHILD UNDER FIVE THE PPD THRESHOLD IS TEN MILLIMETRES.",
        "And active disease must always be excluded before prophylaxis.",
    ],
    "این سؤال، تفاوت بین دو گزینه‌ی بسیار نزدیک را می‌سنجد — و کلمه‌ای که آن‌ها را "
    "از هم جدا می‌کند، **«پس از رد بیماری فعال»** است.\n\n"
    "**بیمار: پسربچه‌ی سه‌ساله که مادرش مبتلا به سل فعال ریوی اسمیر مثبت است. تست "
    "توبرکولین ۱۰ میلی‌متر گزارش شده است.**\n\n"
    "**پاسخ: شروع پروفیلاکسی با ایزونیازید بعد از رد بیماری فعال.**\n\n"
    "**اول، تفسیر عدد:**\n\n"
    "**۱۰ میلی‌متر در کودک زیر ۵ سال، دقیقاً روی آستانه است — یعنی مثبت.** (و "
    "علاوه بر آن، این کودک **تماس نزدیک** هم هست، که او را به آستانه‌ی **۵** "
    "می‌برد. **پس با هر دو معیار مثبت است.**)\n\n"
    "**پس این کودک قطعاً عفونت نهفته دارد** — برخلاف سؤال‌های قبلی که تست منفی بود "
    "و ما با احتیاط عمل می‌کردیم. **اینجا شواهد قطعی است.**\n\n"
    "⚠️ **حالا نکته‌ی حیاتی: تست مثبت به‌تنهایی نمی‌گوید عفونت نهفته است یا بیماری "
    "فعال.**\n\n"
    "**PPD مثبت فقط یک چیز می‌گوید: «بدن با باسیل سل روبه‌رو شده».** نمی‌گوید "
    "باسیل الان خفته است یا در حال تکثیر.\n\n"
    "**و این تمایز، همه‌چیز را عوض می‌کند:**\n\n"
    "**عفونت نهفته** ⇐ **یک دارو** (ایزونیازید)، ۶ تا ۹ ماه.\n\n"
    "**بیماری فعال** ⇐ **چهار دارو**، ۶ ماه.\n\n"
    "⚠️ **و اگر اشتباه کنید و به کودک با بیماری فعال، ایزونیازید تنها بدهید، عملاً "
    "تک‌درمانی کرده‌اید — و در عرض چند ماه، یک کودک سه‌ساله با سل مقاوم به ایزونیازید "
    "خواهید داشت.** این یکی از بدترین اتفاق‌هایی است که در طب اطفال می‌تواند بیفتد.\n\n"
    "**پس «رد بیماری فعال» یک تشریفات نیست؛ یک ضرورت مطلق است.** و شامل:\n\n"
    "**شرح حال دقیق** (سرفه، تب، تعریق، کاهش وزن، افت منحنی رشد) · **معاینه‌ی کامل** "
    "(از جمله غدد لنفاوی و سمع ریه) · **گرافی قفسه‌ی سینه** — که در کودک الزامی است، "
    "چون **کودک می‌تواند سل فعال بی‌علامت داشته باشد** · و در صورت وجود علامت، "
    "**نمونه‌ی تنفسی** (شست‌وشوی معده یا خلط القایی، چون کودکان خلط نمی‌دهند).\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**درمان با ایزونیازید و ریفامپین به‌مدت ۱۲ ماه** — **نه رژیم عفونت نهفته است و "
    "نه رژیم بیماری فعال.** ۱۲ ماه دو دارو، طولانی‌تر از هر دو استاندارد است و "
    "توجیه ندارد.\n\n"
    "⚠️ **شروع پروفیلاکسی و تکرار PPD بعد از سه ماه** — **گزینه‌ی فریبنده و آموزنده.** "
    "این استراتژی **در سؤال‌های قبلی درست بود** — ولی آنجا تست **منفی** بود و ما "
    "دنبال **تبدیل** می‌گشتیم. ⚠️ **اینجا تست از قبل مثبت است. چه چیزی را قرار است "
    "تکرار کنیم؟ تست مثبت، مثبت می‌ماند. این کار هیچ اطلاعات تازه‌ای نمی‌دهد.**\n\n"
    "**شروع درمان ۴ دارویی** — **درمان بیماری فعال، بدون اثبات آن.** تست مثبت "
    "**عفونت** را نشان می‌دهد، نه بیماری. **اگر ابتدا بیماری فعال را رد کرده باشیم، "
    "چهار دارو یعنی درمان بیش از حد.**",
    "This question tests the difference between two very close options — and the phrase that separates them is 'AFTER EXCLUDING ACTIVE DISEASE'.\n\n"
    "THE PATIENT: a three-year-old boy whose mother has active smear-positive pulmonary tuberculosis. His tuberculin test measures 10 MM.\n\n"
    "THE ANSWER: START PREVENTIVE ISONIAZID AFTER EXCLUDING ACTIVE DISEASE.\n\n"
    "FIRST, INTERPRET THE NUMBER:\n\n"
    "TEN MILLIMETRES IN A CHILD UNDER FIVE SITS EXACTLY ON THE THRESHOLD — meaning positive. (And in addition this child IS A CLOSE CONTACT, which moves him to the 5 mm threshold. SO HE IS POSITIVE BY EITHER CRITERION.)\n\n"
    "SO THIS CHILD DEFINITELY HAS LATENT INFECTION — unlike the previous questions where the test was negative and we acted from caution. HERE THE EVIDENCE IS CONCLUSIVE.\n\n"
    "WARNING, NOW THE VITAL POINT: A POSITIVE TEST ALONE DOES NOT SAY WHETHER THIS IS LATENT INFECTION OR ACTIVE DISEASE.\n\n"
    "A POSITIVE PPD SAYS ONE THING ONLY: 'THE BODY HAS MET THE TUBERCLE BACILLUS'. It does not say whether the bacillus is now dormant or multiplying.\n\n"
    "AND THAT DISTINCTION CHANGES EVERYTHING:\n\n"
    "LATENT INFECTION — ONE DRUG (isoniazid), 6 to 9 months.\n\n"
    "ACTIVE DISEASE — FOUR DRUGS, 6 months.\n\n"
    "WARNING: AND IF YOU GET IT WRONG AND GIVE ISONIAZID ALONE TO A CHILD WITH ACTIVE DISEASE, YOU HAVE GIVEN MONOTHERAPY — AND WITHIN MONTHS YOU WILL HAVE A THREE-YEAR-OLD WITH ISONIAZID-RESISTANT TUBERCULOSIS. That is one of the worst outcomes possible in paediatrics.\n\n"
    "SO 'EXCLUDING ACTIVE DISEASE' IS NOT A FORMALITY BUT AN ABSOLUTE REQUIREMENT. It comprises:\n\n"
    "A CAREFUL HISTORY (cough, fever, sweats, weight loss, faltering growth); A FULL EXAMINATION (including lymph nodes and chest); A CHEST RADIOGRAPH, mandatory in a child because A CHILD CAN HAVE ASYMPTOMATIC ACTIVE DISEASE; and, if any symptom exists, A RESPIRATORY SPECIMEN (gastric lavage or induced sputum, since children do not expectorate).\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "'ISONIAZID AND RIFAMPICIN FOR TWELVE MONTHS' — NEITHER A LATENT-INFECTION REGIMEN NOR AN ACTIVE-DISEASE ONE. Twelve months of two drugs is longer than either standard and has no justification.\n\n"
    "WARNING: 'START PROPHYLAXIS AND REPEAT THE PPD IN THREE MONTHS' — THE SEDUCTIVE AND INSTRUCTIVE OPTION. That strategy WAS RIGHT IN THE PREVIOUS QUESTIONS — but there the test was NEGATIVE and we were looking for CONVERSION. WARNING: HERE THE TEST IS ALREADY POSITIVE. WHAT WOULD WE BE REPEATING? A positive test stays positive. IT YIELDS NO NEW INFORMATION.\n\n"
    "'START FOUR-DRUG TREATMENT' — TREATING ACTIVE DISEASE WITHOUT PROVING IT. A positive test shows INFECTION, not disease. IF ACTIVE DISEASE HAS BEEN EXCLUDED FIRST, FOUR DRUGS IS OVER-TREATMENT.",
    ["نه رژیم عفونت نهفته است و نه بیماری فعال؛ دوازده ماه دو دارو توجیهی ندارد.",
     "پاسخ صحیح — تست مثبت است، پس پس از رد بیماری فعال، پروفیلاکسی تک‌دارویی.",
     "تکرار تستی که از قبل مثبت است هیچ اطلاعات تازه‌ای نمی‌دهد.",
     "تست مثبت عفونت را نشان می‌دهد نه بیماری؛ چهار دارو بدون اثبات، درمان بیش از حد است."],
    ["Neither a latent-infection nor an active-disease regimen; twelve months of two drugs has no justification.",
     "Correct — the test is positive, so after excluding active disease, single-drug prophylaxis.",
     "Repeating a test that is already positive yields no new information.",
     "A positive test shows infection, not disease; four drugs without proof is over-treatment."],
    "**PPD مثبت فقط می‌گوید بدن روبه‌رو شده — نمی‌گوید نهفته است یا فعال. آن را رد کنید.**",
    "A positive PPD says only that the body has met the bacillus — not whether it is latent or active. Exclude disease.",
    REFSN)

add("book:280", "vignette", "medium",
    "**نخستین گام در کودک تماس‌یافته: اثبات یا رد تشخیص سل.**",
    "The first step in an exposed child: prove or exclude the diagnosis of tuberculosis.",
    CHILD_FA + [
        "⚠️ **در سؤالی که «نخستین گام» می‌پرسد، پاسخ تقریباً همیشه تشخیص است.**",
        "**چون تا ندانید کودک عفونی است، نهفته است یا فعال، درمان درست را نمی‌دانید.**",
    ],
    CHILD_EN + [
        "WARNING: WHEN A QUESTION ASKS FOR THE FIRST STEP, THE ANSWER IS ALMOST ALWAYS DIAGNOSIS.",
        "Because until you know whether the child is uninfected, latently infected or diseased, you cannot know the right treatment.",
    ],
    "این سؤال ظاهراً با سؤال‌های قبلی در تضاد است، ولی نیست — و **فهمیدن این "
    "تفاوت، درس اصلی است.**\n\n"
    "**بیمار: مادر کودک سه‌ساله‌ای جهت مشاوره مراجعه می‌کند. همسر وی از دو هفته قبل "
    "با تشخیص سل ریوی خلط مثبت تحت درمان قرار گرفته است. چه رویکردی در نخستین گام "
    "برای این کودک مناسب است؟**\n\n"
    "**پاسخ: اثبات یا رد تشخیص سل ریوی.**\n\n"
    "⚠️ **کلید در دو کلمه‌ی «نخستین گام» است.**\n\n"
    "**سؤال‌های قبلی می‌پرسیدند «چه درمانی؟» و اطلاعات لازم را داده بودند** — گفته "
    "بودند «PPD منفی است»، یا «بررسی بالینی منفی است»، یا «شواهدی از سل فعال "
    "ندارد».\n\n"
    "**این سؤال هیچ‌کدام را نگفته.** ما درباره‌ی این کودک **هیچ نمی‌دانیم**: نه تست، "
    "نه گرافی، نه علائم.\n\n"
    "**و بدون آن اطلاعات، درمان درست را نمی‌توان انتخاب کرد. چون سه مسیر کاملاً "
    "متفاوت پیش رو است:**\n\n"
    "**مسیر یک — کودک عفونی نشده** (تست منفی، خارج از پنجره، منبع دیگر مسری نیست) "
    "⇐ ممکن است اقدامی لازم نباشد.\n\n"
    "**مسیر دو — عفونت نهفته** (تست مثبت، بدون بیماری) ⇐ **ایزونیازید، یک دارو**.\n\n"
    "⚠️ **مسیر سه — بیماری فعال** ⇐ **چهار دارو، درمان کامل**.\n\n"
    "**و انتخاب اشتباه، به‌ویژه بین دو و سه، فاجعه‌بار است:** دادن ایزونیازید تنها به "
    "کودک با سل فعال یعنی **تک‌درمانی** و **ساختن سل مقاوم به ایزونیازید در یک کودک "
    "سه‌ساله**.\n\n"
    "**پس نخستین گام، جمع‌آوری اطلاعات است — یعنی «اثبات یا رد تشخیص».**\n\n"
    "**عملاً یعنی:**\n\n"
    "**شرح حال** (سرفه، تب، تعریق شبانه، کاهش وزن یا افت منحنی رشد) · **معاینه‌ی "
    "کامل** · **تست توبرکولین** · **گرافی قفسه‌ی سینه** · و در صورت وجود علامت یا "
    "گرافی مشکوک، **نمونه‌ی تنفسی** — که در کودک معمولاً **شست‌وشوی معده** (چون کودکان "
    "خلط را می‌بلعند) یا **خلط القایی** است.\n\n"
    "⚠️ **و توجه کنید که این «گام اول» با پروفیلاکسی در تضاد نیست.** در عمل، در "
    "کودک زیر پنج سال، **ارزیابی و پروفیلاکسی هم‌زمان پیش می‌روند** — ارزیابی چند روز "
    "طول می‌کشد و کودک در همان مدت محافظت می‌شود. **ولی سؤال صراحتاً «نخستین گام» "
    "را می‌پرسد، و از نظر منطقی، تشخیص مقدم است.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "**شروع پروفیلاکسی با ایزونیازید** — ⚠️ **در نهایت احتمالاً درست است، ولی نه "
    "به‌عنوان نخستین گام و نه پیش از رد سل فعال.** **خطرش همان تک‌درمانی است.**\n\n"
    "**شروع پروفیلاکسی با ریفامپین** — همان ایراد، به‌علاوه اینکه **ریفامپین تنها، "
    "رژیم درجه‌اول پروفیلاکسی کودکان در پروتکل کشوری نیست** (هرچند 4R امروز در "
    "راهنماهای بین‌المللی جایگاه دارد).\n\n"
    "⚠️ **فالوآپ بالینی به‌مدت ۶ ماه** — **خطرناک‌ترین گزینه.** **مشاهده‌ی منفعل کودک "
    "سه‌ساله‌ای که با پدرِ خلط‌مثبت زندگی می‌کند.** **و مننژیت سلی می‌تواند در همین شش "
    "ماه رخ دهد.**",
    "This question appears to contradict the previous ones, but it does not — AND UNDERSTANDING THAT DIFFERENCE IS THE MAIN LESSON.\n\n"
    "THE PATIENT: the mother of a three-year-old comes for advice. Her husband was diagnosed two weeks ago with smear-positive pulmonary tuberculosis and started treatment. What is the appropriate FIRST STEP for this child?\n\n"
    "THE ANSWER: PROVE OR EXCLUDE THE DIAGNOSIS OF TUBERCULOSIS.\n\n"
    "WARNING: THE KEY LIES IN THE WORDS 'FIRST STEP'.\n\n"
    "THE EARLIER QUESTIONS ASKED 'WHICH TREATMENT?' AND SUPPLIED THE NECESSARY INFORMATION — they told us 'the PPD is negative', or 'the clinical assessment is negative', or 'there is no evidence of active disease'.\n\n"
    "THIS QUESTION SUPPLIES NONE OF THAT. We know NOTHING about this child: no test, no film, no symptoms.\n\n"
    "AND WITHOUT THAT INFORMATION THE RIGHT TREATMENT CANNOT BE CHOSEN, BECAUSE THREE COMPLETELY DIFFERENT PATHS LIE AHEAD:\n\n"
    "PATH ONE — THE CHILD IS NOT INFECTED (negative test, outside the window, the source no longer infectious) — possibly nothing is needed.\n\n"
    "PATH TWO — LATENT INFECTION (positive test, no disease) — ISONIAZID, ONE DRUG.\n\n"
    "WARNING, PATH THREE — ACTIVE DISEASE — FOUR DRUGS, FULL TREATMENT.\n\n"
    "AND CHOOSING WRONGLY, ESPECIALLY BETWEEN TWO AND THREE, IS CATASTROPHIC: giving isoniazid alone to a child with active disease is MONOTHERAPY and CREATES ISONIAZID-RESISTANT TUBERCULOSIS IN A THREE-YEAR-OLD.\n\n"
    "SO THE FIRST STEP IS TO GATHER INFORMATION — that is, TO PROVE OR EXCLUDE THE DIAGNOSIS.\n\n"
    "IN PRACTICE THAT MEANS:\n\n"
    "A HISTORY (cough, fever, night sweats, weight loss or faltering growth); A FULL EXAMINATION; A TUBERCULIN TEST; A CHEST RADIOGRAPH; and, if there are symptoms or a suspicious film, A RESPIRATORY SPECIMEN — usually GASTRIC LAVAGE in a child (because children swallow their sputum) or INDUCED SPUTUM.\n\n"
    "WARNING: AND NOTE THAT THIS 'FIRST STEP' DOES NOT CONFLICT WITH PROPHYLAXIS. In practice, in a child under five, ASSESSMENT AND PROPHYLAXIS PROCEED TOGETHER — the assessment takes a few days and the child is protected meanwhile. BUT THE QUESTION EXPLICITLY ASKS FOR THE FIRST STEP, AND LOGICALLY DIAGNOSIS COMES FIRST.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "'START ISONIAZID PROPHYLAXIS' — WARNING, PROBABLY CORRECT EVENTUALLY, BUT NOT AS THE FIRST STEP AND NOT BEFORE EXCLUDING ACTIVE DISEASE. The risk is monotherapy.\n\n"
    "'START RIFAMPICIN PROPHYLAXIS' — the same objection, plus the fact that RIFAMPICIN ALONE IS NOT THE FIRST-LINE PAEDIATRIC PROPHYLAXIS IN THE NATIONAL PROTOCOL (though 4R has a place in current international guidance).\n\n"
    "WARNING: 'CLINICAL FOLLOW-UP FOR SIX MONTHS' — THE MOST DANGEROUS OPTION. PASSIVE OBSERVATION OF A THREE-YEAR-OLD LIVING WITH A SPUTUM-POSITIVE FATHER. AND TUBERCULOUS MENINGITIS CAN OCCUR WITHIN EXACTLY THOSE SIX MONTHS.",
    ["احتمالاً در نهایت درست است ولی نه به‌عنوان نخستین گام و نه پیش از رد سل فعال.",
     "همان ایراد، به‌علاوه اینکه ریفامپین تنها رژیم درجه‌اول پروفیلاکسی کودکان در پروتکل کشوری نیست.",
     "پاسخ صحیح — تا ندانیم کودک عفونی است، نهفته است یا فعال، درمان درست را نمی‌دانیم.",
     "خطرناک‌ترین گزینه؛ مشاهده‌ی منفعل کودکی که با بیمار خلط‌مثبت زندگی می‌کند."],
    ["Probably right eventually, but not as the first step and not before excluding active disease.",
     "The same objection, plus rifampicin alone is not first-line paediatric prophylaxis in the national protocol.",
     "Correct — until we know whether the child is uninfected, latent or diseased, we cannot know the right treatment.",
     "The most dangerous option; passive observation of a child living with a sputum-positive case."],
    "**در سؤال «نخستین گام»، تشخیص مقدم است — چون درمان اشتباه، مقاومت می‌سازد.**",
    "In a 'first step' question, diagnosis comes first — because the wrong treatment breeds resistance.",
    REFSN)

# ============================================ THE NEWBORN
NEWBORN_FA = [
    "⚠️ **نوزاد مادر مسلول: چهار قاعده را با هم بدانید.**",
    "**قاعده یک: شیردهی قطع نمی‌شود.**",
    "**سل از راه شیر منتقل نمی‌شود و داروها در مقادیر ناچیز وارد شیر می‌شوند.**",
    "**و جدا کردن مادر و نوزاد، آسیبش بسیار بیشتر از فایده‌اش است.**",
    "**قاعده دو: جداسازی لازم نیست، به شرط آنکه مادر حدود دو هفته درمان گرفته باشد.**",
    "**ماسک و تهویه‌ی خوب کافی است.**",
    "⚠️ **قاعده سه: به نوزاد ایزونیازید پیشگیرانه به‌مدت شش ماه بدهید.**",
    "**قاعده چهار: واکسن ب‌ث‌ژ را تا پایان ایزونیازید به تعویق بیندازید.**",
    "**چون ب‌ث‌ژ واکسن زنده است و ایزونیازید سویه‌ی واکسن را می‌کشد.**",
    "**پس واکسن هدر می‌رود؛ در پایان دوره تزریق می‌شود.**",
    "⚠️ **و اگر مادر تا زمان زایمان به‌قدر کافی درمان گرفته و دیگر مسری نیست:**",
    "**نوزاد پروفیلاکسی نمی‌خواهد و ب‌ث‌ژ به‌طور معمول زده می‌شود.**",
]
NEWBORN_EN = [
    "WARNING: THE NEWBORN OF A MOTHER WITH TUBERCULOSIS — KNOW FOUR RULES TOGETHER.",
    "RULE ONE: BREASTFEEDING IS NOT STOPPED.",
    "Tuberculosis is not transmitted in milk, and the drugs enter milk in negligible amounts.",
    "And separating mother and infant does far more harm than good.",
    "RULE TWO: separation is unnecessary once the mother has had about two weeks of treatment.",
    "A mask and good ventilation suffice.",
    "WARNING, RULE THREE: GIVE THE INFANT PREVENTIVE ISONIAZID FOR SIX MONTHS.",
    "RULE FOUR: DEFER BCG UNTIL THE ISONIAZID IS FINISHED.",
    "Because BCG is a LIVE vaccine and isoniazid would kill the vaccine strain.",
    "So the vaccine would be wasted; it is given at the end of the course instead.",
    "WARNING, AND IF THE MOTHER HAS BEEN TREATED LONG ENOUGH BY DELIVERY AND IS NO LONGER INFECTIOUS:",
    "The infant needs no prophylaxis and BCG is given as normal.",
]

add("book:277", "vignette", "medium",
    "**نوزاد مادر تازه‌تشخیص‌داده‌شده: ایزونیازید برای شش ماه.**",
    "The infant of a newly diagnosed mother: isoniazid for six months.",
    NEWBORN_FA, NEWBORN_EN,
    "این سؤال، پرکاربردترین سناریوی زنان و اطفال در فصل سل است.\n\n"
    "**بیمار: دو ماه پس از زایمان، برای مادر سل ریوی اسمیر مثبت تشخیص داده شده و "
    "تحت درمان است. نوزادش در بدو تولد واکسن ب‌ث‌ژ دریافت کرده و اکنون بی‌علامت "
    "است. جهت شیرخوار کدام اقدام مناسب است؟**\n\n"
    "**پاسخ: تجویز ایزونیازید برای ۶ ماه.**\n\n"
    "**زمان‌بندی را دقیق بخوانید — این بخش، تصمیم را می‌سازد:**\n\n"
    "**تشخیص مادر، دو ماه پس از زایمان گذاشته شده.** یعنی **در تمام دوران بارداری "
    "پایانی و دو ماه نخست زندگی نوزاد، مادر درمان‌نشده و مسری بوده**. و "
    "**نزدیک‌ترین تماس ممکن — شیردهی، آغوش، خواب مشترک — در همان دوره رخ داده.**\n\n"
    "⚠️ **پس این نوزاد در معرض شدیدترین مواجهه‌ی ممکن بوده و در پرخطرترین سن ممکن "
    "است: زیر یک سال، با خطر بیماری حدود ۴۰٪ و بالاترین خطر مننژیت سلی و سل "
    "میلیاری.**\n\n"
    "**پس ایزونیازید پیشگیرانه ۶ ماهه، بدون هیچ قید و شرطی.**\n\n"
    "⚠️ **و نکته‌ی مهم درباره‌ی ب‌ث‌ژ: نوزاد در بدو تولد واکسن گرفته — ولی این محافظت "
    "کافی نیست.**\n\n"
    "**ب‌ث‌ژ در برابر شکل‌های منتشر (میلیاری و مننژیت) در کودکان خردسال محافظت "
    "خوبی می‌دهد — حدود ۷۰ تا ۸۰٪ — ولی:**\n\n"
    "**الف) محافظتش کامل نیست** (۲۰ تا ۳۰٪ همچنان آسیب‌پذیرند).\n\n"
    "**ب) در برابر عفونت اولیه و سل ریوی، محافظت بسیار کمتری دارد.**\n\n"
    "**ج) و در برابر مواجهه‌ی شدید و طولانی، ناکافی است.**\n\n"
    "**پس ب‌ث‌ژ قبلی، جای پروفیلاکسی را نمی‌گیرد.**\n\n"
    "**قواعد دیگر نوزاد که باید بدانید:**\n\n"
    "**شیردهی ادامه یابد** — سل از راه شیر منتقل نمی‌شود · **جداسازی لازم نیست** پس "
    "از حدود دو هفته درمان مؤثر مادر · **پیریدوکسین** اضافه شود · و **پس از پایان "
    "ایزونیازید**، اگر نوزاد ب‌ث‌ژ نگرفته بود، آن را تزریق کنید.\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "⚠️ **تغذیه با شیرخشک** — **خطای رایج و پرهزینه.** **سل از راه شیر مادر منتقل "
    "نمی‌شود.** (استثنای بسیار نادر: ماستیت سلی، که تابلوی جداگانه‌ای دارد.) و "
    "داروهای ضدسل در **مقادیر ناچیز** وارد شیر می‌شوند. **قطع شیر مادر، نوزاد را از "
    "ایمنی غیرفعال، تغذیه‌ی بهینه و پیوند عاطفی محروم می‌کند** — و در محیط‌های "
    "کم‌درآمد، **شیرخشک با آب آلوده خودش خطر مرگ می‌سازد**.\n\n"
    "**تجویز ایزونیازید به شرط مثبت بودن PPD** — **تصمیم را به تستی سپرده که در "
    "نوزاد کمترین اعتبار را دارد.** ایمنی سلولی نوزاد **نابالغ‌ترین** است، و "
    "**منفی کاذب بسیار شایع**. **این شرط، پرخطرترین نوزاد را بدون محافظت رها "
    "می‌کند.**\n\n"
    "**تجویز ریفامپین برای ۳ ماه سپس تصمیم‌گیری** — **رژیم غیراستاندارد** برای "
    "پروفیلاکسی نوزاد، و **مرحله‌ی بلاتکلیفی** اضافه می‌کند.",
    "This is the most practically useful obstetric-paediatric scenario in the tuberculosis chapter.\n\n"
    "THE PATIENT: two months after delivery, the mother is diagnosed with smear-positive pulmonary tuberculosis and started on treatment. Her infant received BCG at birth and is currently asymptomatic. What is appropriate for the infant?\n\n"
    "THE ANSWER: ISONIAZID FOR SIX MONTHS.\n\n"
    "READ THE TIMING CAREFULLY — IT MAKES THE DECISION:\n\n"
    "THE MOTHER WAS DIAGNOSED TWO MONTHS AFTER DELIVERY. That means THROUGHOUT LATE PREGNANCY AND THE INFANT'S FIRST TWO MONTHS OF LIFE SHE WAS UNTREATED AND INFECTIOUS. And THE CLOSEST POSSIBLE CONTACT — feeding, holding, sleeping together — OCCURRED IN EXACTLY THAT PERIOD.\n\n"
    "WARNING: SO THIS INFANT HAS HAD THE MOST INTENSE EXPOSURE POSSIBLE AT THE HIGHEST-RISK AGE POSSIBLE: under one year, with about a 40 % risk of disease and the highest risk of tuberculous meningitis and miliary disease.\n\n"
    "SO: PREVENTIVE ISONIAZID FOR SIX MONTHS, UNCONDITIONALLY.\n\n"
    "WARNING, AN IMPORTANT POINT ABOUT BCG: THE INFANT WAS VACCINATED AT BIRTH — BUT THAT PROTECTION IS NOT ENOUGH.\n\n"
    "BCG PROTECTS WELL AGAINST THE DISSEMINATED FORMS (miliary disease and meningitis) IN YOUNG CHILDREN — about 70 to 80 % — BUT:\n\n"
    "(a) THE PROTECTION IS NOT COMPLETE (20 to 30 % remain vulnerable).\n\n"
    "(b) IT PROTECTS FAR LESS AGAINST PRIMARY INFECTION AND PULMONARY DISEASE.\n\n"
    "(c) AND IT IS INADEQUATE AGAINST INTENSE, PROLONGED EXPOSURE.\n\n"
    "SO PRIOR BCG DOES NOT REPLACE PROPHYLAXIS.\n\n"
    "OTHER NEWBORN RULES YOU MUST KNOW:\n\n"
    "CONTINUE BREASTFEEDING — tuberculosis is not transmitted in milk. SEPARATION IS UNNECESSARY once the mother has had about two weeks of effective treatment. ADD PYRIDOXINE. And AFTER THE ISONIAZID IS FINISHED, if the infant had not received BCG, give it then.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "WARNING: FORMULA FEEDING — A COMMON AND COSTLY ERROR. TUBERCULOSIS IS NOT TRANSMITTED IN BREAST MILK. (The very rare exception is tuberculous mastitis, a distinct picture.) And the drugs enter milk in NEGLIGIBLE amounts. STOPPING BREASTFEEDING DEPRIVES THE INFANT OF PASSIVE IMMUNITY, OPTIMAL NUTRITION AND BONDING — and in low-income settings FORMULA MIXED WITH CONTAMINATED WATER IS ITSELF LETHAL.\n\n"
    "'ISONIAZID ONLY IF THE PPD IS POSITIVE' — IT HANDS THE DECISION TO THE TEST LEAST VALID IN A NEWBORN. Neonatal cell-mediated immunity is THE MOST IMMATURE OF ALL, and FALSE NEGATIVES ARE VERY COMMON. THIS CONDITION WOULD LEAVE THE HIGHEST-RISK INFANT UNPROTECTED.\n\n"
    "'RIFAMPICIN FOR 3 MONTHS THEN DECIDE' — A NON-STANDARD REGIMEN for neonatal prophylaxis, and it adds a further period of indecision.",
    ["خطای رایج؛ سل از راه شیر مادر منتقل نمی‌شود و قطع شیر آسیب بسیار بیشتری می‌زند.",
     "پاسخ صحیح — نوزاد در پرخطرترین سن با شدیدترین مواجهه؛ شش ماه ایزونیازید.",
     "تصمیم را به تستی سپرده که در نوزاد کمترین اعتبار را دارد و منفی کاذب شایع است.",
     "رژیم غیراستاندارد برای پروفیلاکسی نوزاد، و یک مرحله‌ی بلاتکلیفی اضافه می‌کند."],
    ["A common error; tuberculosis is not transmitted in breast milk and stopping it does far more harm.",
     "Correct — the highest-risk age with the most intense exposure; six months of isoniazid.",
     "It hands the decision to the test least valid in a newborn, where false negatives are common.",
     "A non-standard neonatal prophylaxis regimen that adds a further period of indecision."],
    "**شیر مادر سل را منتقل نمی‌کند — قطع کردنش آسیبی است که هیچ خطری را کم نمی‌کند.**",
    "Breast milk does not transmit tuberculosis — stopping it is a harm that prevents no risk.",
    REFSN)

add("book:284", "vignette", "medium",
    "**زایمان هشت روز پس از شروع درمان مادر: پروفیلاکسی ایزونیازید شش‌ماهه برای نوزاد.**",
    "Delivery eight days after the mother started treatment: six months of isoniazid prophylaxis for the newborn.",
    NEWBORN_FA, NEWBORN_EN,
    "این سؤال، همه‌ی چهار قاعده‌ی نوزاد را در یک گزینه می‌آزماید — و **سه گزینه‌ی "
    "غلطش، سه باور نادرست رایج را نمایندگی می‌کنند.**\n\n"
    "**بیمار: زنی ۲۴ ساله در هفته‌ی ۳۸ بارداری دچار سل ریوی خلط مثبت شده و تحت "
    "درمان ریفامپین، ایزونیازید، پیرازینامید و اتامبوتول قرار گرفته است. هشت روز "
    "پس از شروع درمان، زایمان کرده است.**\n\n"
    "**پاسخ: پروفیلاکسی با ایزونیازید برای نوزاد شروع گردد و به‌مدت ۶ ماه تکمیل "
    "شود.**\n\n"
    "⚠️ **عدد کلیدی: «هشت روز».**\n\n"
    "**مسری بودن پس از شروع درمان مؤثر، معمولاً حدود دو هفته طول می‌کشد** (و در "
    "بیمار با بار باسیلی بالا یا کاویته، بیشتر). **هشت روز، کمتر از دو هفته است "
    "— پس مادر هنگام زایمان هنوز بالقوه مسری بوده.**\n\n"
    "**و نوزاد در همان اولین ساعات و روزهای زندگی، در نزدیک‌ترین تماس ممکن با او "
    "قرار گرفته — در آسیب‌پذیرترین سن ممکن.**\n\n"
    "**پس پروفیلاکسی لازم است: ایزونیازید ۶ ماه.**\n\n"
    "**حالا سه باور نادرست رایج را که در گزینه‌ها پنهان‌اند بررسی کنیم:**\n\n"
    "⚠️ **باور نادرست یک: «واکسن ب‌ث‌ژ در روز اول تولد تزریق شود».**\n\n"
    "**چرا نادرست است؟ چون ب‌ث‌ژ یک واکسن زنده‌ی ضعیف‌شده است.**\n\n"
    "**و نوزاد قرار است ایزونیازید بگیرد.** **ایزونیازید سویه‌ی واکسن (مایکوباکتریوم "
    "بوویس) را می‌کشد** — پس **واکسن نمی‌تواند ایمنی بسازد و کاملاً هدر می‌رود**.\n\n"
    "**راه درست: ب‌ث‌ژ را به تعویق بیندازید تا دوره‌ی ایزونیازید تمام شود، و سپس "
    "تزریق کنید.** (برخی پروتکل‌ها پیش از تزریق، PPD می‌گیرند.)\n\n"
    "⚠️ **باور نادرست دو: «نوزاد PPD شود و اگر مثبت بود، پروفیلاکسی بگیرد».**\n\n"
    "**چرا نادرست است؟** به دو دلیل که با هم کار می‌کنند:\n\n"
    "**الف) ایمنی سلولی نوزاد نابالغ‌ترین حالت ممکن را دارد** — PPD در نوزاد "
    "**تقریباً بی‌فایده** است.\n\n"
    "**ب) و حتی اگر ایمنی کامل بود، عفونت تازه رخ داده و پنجره‌ی ۲ تا ۱۲ هفته هنوز "
    "نگذشته.** **پس تست حتماً منفی خواهد بود، حتی اگر نوزاد عفونی شده باشد.**\n\n"
    "**این گزینه، پرخطرترین بیمار ممکن را بر اساس بی‌اعتبارترین تست ممکن، بدون "
    "محافظت رها می‌کند.**\n\n"
    "⚠️ **باور نادرست سه: «شیر ندهد و کودک دو هفته از مادر جدا شود».**\n\n"
    "**این باور، شایع‌ترین و پرهزینه‌ترین خطای این حوزه است. سه بخشش را جدا رد "
    "کنیم:**\n\n"
    "**درباره‌ی شیر:** **سل از راه شیر مادر منتقل نمی‌شود.** انتقال از راه **قطرک "
    "تنفسی** است، نه شیر. و داروها در مقادیر ناچیز وارد شیر می‌شوند.\n\n"
    "**درباره‌ی جداسازی:** **مادر هشت روز است که درمان مؤثر می‌گیرد.** با **ماسک "
    "زدن مادر، تهویه‌ی خوب و بهداشت سرفه**، خطر به‌شدت کاهش می‌یابد. **و نوزاد "
    "هم‌زمان ایزونیازید می‌گیرد** — یعنی از دو طرف محافظت می‌شود.\n\n"
    "**درباره‌ی هزینه:** **جداسازی مادر و نوزاد در روزهای نخست، به شیردهی، پیوند "
    "عاطفی و سلامت روان مادر آسیب جدی می‌زند** — آسیبی واقعی، در برابر خطری که "
    "با ماسک و دارو قابل مدیریت است.\n\n"
    "**و با این سؤال، فصل سل کامل می‌شود: ۸۰ از ۸۰.**",
    "This question tests all four newborn rules in a single option — and ITS THREE WRONG OPTIONS REPRESENT THREE COMMON FALSE BELIEFS.\n\n"
    "THE PATIENT: a 24-year-old woman at 38 weeks' gestation develops smear-positive pulmonary tuberculosis and is started on rifampicin, isoniazid, pyrazinamide and ethambutol. EIGHT DAYS after starting treatment she delivers.\n\n"
    "THE ANSWER: START ISONIAZID PROPHYLAXIS FOR THE NEWBORN AND COMPLETE SIX MONTHS.\n\n"
    "WARNING: THE KEY NUMBER IS 'EIGHT DAYS'.\n\n"
    "INFECTIOUSNESS AFTER EFFECTIVE TREATMENT BEGINS USUALLY PERSISTS FOR ABOUT TWO WEEKS (longer with a heavy bacillary load or a cavity). EIGHT DAYS IS LESS THAN TWO WEEKS — SO THE MOTHER WAS STILL POTENTIALLY INFECTIOUS AT DELIVERY.\n\n"
    "AND THE NEWBORN, IN THE VERY FIRST HOURS AND DAYS OF LIFE, IS IN THE CLOSEST POSSIBLE CONTACT WITH HER — AT THE MOST VULNERABLE AGE THERE IS.\n\n"
    "SO PROPHYLAXIS IS REQUIRED: SIX MONTHS OF ISONIAZID.\n\n"
    "NOW EXAMINE THE THREE COMMON FALSE BELIEFS HIDDEN IN THE OPTIONS:\n\n"
    "WARNING, FALSE BELIEF ONE: 'GIVE BCG ON THE FIRST DAY OF LIFE'.\n\n"
    "WHY IS THAT WRONG? BECAUSE BCG IS A LIVE ATTENUATED VACCINE.\n\n"
    "AND THE INFANT IS ABOUT TO RECEIVE ISONIAZID. ISONIAZID KILLS THE VACCINE STRAIN (Mycobacterium bovis) — so THE VACCINE CANNOT GENERATE IMMUNITY AND IS ENTIRELY WASTED.\n\n"
    "THE CORRECT COURSE: DEFER BCG UNTIL THE ISONIAZID COURSE IS COMPLETE, THEN GIVE IT. (Some protocols do a PPD first.)\n\n"
    "WARNING, FALSE BELIEF TWO: 'DO A PPD ON THE NEWBORN AND GIVE PROPHYLAXIS ONLY IF POSITIVE'.\n\n"
    "WHY IS THAT WRONG? For two reasons that compound each other:\n\n"
    "(a) NEONATAL CELL-MEDIATED IMMUNITY IS THE MOST IMMATURE OF ALL — the PPD in a newborn is NEARLY USELESS.\n\n"
    "(b) AND EVEN WITH PERFECT IMMUNITY, THE INFECTION HAS ONLY JUST OCCURRED AND THE 2- TO 12-WEEK WINDOW HAS NOT PASSED. THE TEST WILL CERTAINLY BE NEGATIVE, EVEN IF THE INFANT IS INFECTED.\n\n"
    "THIS OPTION ABANDONS THE HIGHEST-RISK PATIENT POSSIBLE ON THE BASIS OF THE LEAST VALID TEST POSSIBLE.\n\n"
    "WARNING, FALSE BELIEF THREE: 'WITHHOLD BREAST MILK AND SEPARATE THE BABY FOR TWO WEEKS'.\n\n"
    "THIS IS THE COMMONEST AND COSTLIEST ERROR IN THIS FIELD. REJECT ITS THREE PARTS SEPARATELY:\n\n"
    "ON THE MILK: TUBERCULOSIS IS NOT TRANSMITTED IN BREAST MILK. Transmission is by RESPIRATORY DROPLET, not milk. And the drugs enter milk in negligible amounts.\n\n"
    "ON SEPARATION: THE MOTHER HAS HAD EIGHT DAYS OF EFFECTIVE TREATMENT. With A MASK, GOOD VENTILATION AND COUGH HYGIENE the risk falls sharply. AND THE INFANT IS SIMULTANEOUSLY ON ISONIAZID — protected from both sides.\n\n"
    "ON THE COST: SEPARATING MOTHER AND NEWBORN IN THE FIRST DAYS SERIOUSLY DAMAGES BREASTFEEDING, BONDING AND MATERNAL MENTAL HEALTH — a real harm, set against a risk manageable with a mask and a drug.\n\n"
    "AND WITH THIS QUESTION THE TUBERCULOSIS CHAPTER IS COMPLETE: 80 OF 80.",
    ["ب‌ث‌ژ واکسن زنده است و ایزونیازید سویه‌ی واکسن را می‌کشد؛ باید به تعویق بیفتد.",
     "PPD در نوزاد تقریباً بی‌فایده است و پنجره‌ی زمانی هم نگذشته؛ تست حتماً منفی می‌شود.",
     "سل از راه شیر منتقل نمی‌شود و جداسازی آسیبش بیشتر از خطری است که رفع می‌کند.",
     "پاسخ صحیح — مادر هنوز بالقوه مسری بوده؛ ایزونیازید پیشگیرانه شش‌ماهه برای نوزاد."],
    ["BCG is a live vaccine and isoniazid kills the vaccine strain; it must be deferred.",
     "The PPD is nearly useless in a newborn and the window has not passed; the test will certainly be negative.",
     "Tuberculosis is not transmitted in milk, and separation harms more than the risk it removes.",
     "Correct — the mother was still potentially infectious; six months of preventive isoniazid for the newborn."],
    "**ب‌ث‌ژ واکسن زنده است — با ایزونیازید هم‌زمان نزنید، وگرنه هدر می‌رود.**",
    "BCG is a live vaccine — do not give it alongside isoniazid, or it is wasted.",
    REFSN)

add("book:283", "vignette", "medium",
    "**مادری که تا زایمان اسمیرش منفی شده: نوزاد ب‌ث‌ژ معمول را می‌گیرد.**",
    "A mother whose smear has converted to negative by delivery: the newborn receives BCG as normal.",
    NEWBORN_FA, NEWBORN_EN,
    "این سؤال، **نقطه‌ی مقابل** سؤال قبلی است — و مقایسه‌ی این دو، بهترین راه "
    "تثبیت مبحث است.\n\n"
    "**بیمار: خانم ۲۸ ساله که در ماه هفتم بارداری با تشخیص سل ریوی اسمیر مثبت تحت "
    "درمان استاندارد چهاردارویی قرار گرفته، و در ماه نهم بارداری اسمیر خلط وی منفی "
    "شده بود. توصیه برای نوزاد؟**\n\n"
    "**پاسخ: انجام واکسن ضد سل (ب‌ث‌ژ).**\n\n"
    "⚠️ **دو سؤال را کنار هم بگذارید — این مقایسه، همه‌ی مبحث را روشن می‌کند:**\n\n"
    "**سؤال قبلی:** درمان از هفته‌ی ۳۸ شروع شد و **هشت روز بعد** زایمان شد. "
    "⇐ **مادر هنگام زایمان هنوز مسری بود** ⇐ **نوزاد پروفیلاکسی می‌خواهد و ب‌ث‌ژ به "
    "تعویق می‌افتد.**\n\n"
    "**این سؤال:** درمان از **ماه هفتم** شروع شد و تا **ماه نهم اسمیر منفی "
    "شده** ⇐ **حدود دو ماه درمان مؤثر و تبدیل اسمیر به منفی** ⇐ **مادر دیگر مسری "
    "نیست** ⇐ **نوزاد پروفیلاکسی نمی‌خواهد و ب‌ث‌ژ به‌طور معمول زده می‌شود.**\n\n"
    "**پس متغیر تعیین‌کننده، «آیا مادر هنگام زایمان مسری است؟» است — نه اینکه "
    "«آیا مادر سل داشته؟».**\n\n"
    "**و «اسمیر منفی شده» بهترین شاهد ممکن است:** تبدیل اسمیر به منفی، **معیار "
    "عینی و آزمایشگاهی پایان سرایت** است.\n\n"
    "**پس چون نوزاد در معرض مواجهه‌ی معنادار نبوده:**\n\n"
    "**پروفیلاکسی ایزونیازید لازم نیست** ⇐ **و چون ایزونیازید داده نمی‌شود، هیچ مانعی "
    "برای ب‌ث‌ژ وجود ندارد** ⇐ **ب‌ث‌ژ در بدو تولد، طبق برنامه‌ی معمول واکسیناسیون "
    "کشوری.**\n\n"
    "⚠️ **و منطق ب‌ث‌ژ را دوباره ببینید: تنها دلیل به تعویق انداختن ب‌ث‌ژ در سؤال "
    "قبلی، تداخل با ایزونیازید بود.** وقتی ایزونیازید در کار نیست، آن دلیل هم از "
    "بین می‌رود.\n\n"
    "**و ب‌ث‌ژ در ایران بخشی از برنامه‌ی واکسیناسیون بدو تولد است و در برابر سل "
    "میلیاری و مننژیت سلی کودکان محافظت خوبی می‌دهد.**\n\n"
    "**چرا سه گزینه‌ی دیگر رد می‌شوند؟**\n\n"
    "⚠️ **عدم استفاده از شیر مادر** — **همان خطای همیشگی.** سل از راه شیر منتقل "
    "نمی‌شود، و **این مادر اصلاً دیگر مسری نیست**. **قطع شیر در اینجا هیچ توجیهی "
    "ندارد.**\n\n"
    "**شروع داروی ایزونیازید** — **پروفیلاکسی بدون مواجهه.** مادر **اسمیر منفی** "
    "است. **دادن شش ماه دارو به نوزادی که در معرض نبوده، یعنی سمّیت بی‌دلیل** — و "
    "ضمناً **ب‌ث‌ژ را هم بی‌جهت به تعویق می‌اندازد**.\n\n"
    "**جدا کردن نوزاد از مادر** — **بی‌رحمانه و بی‌دلیل.** مادر مسری نیست. "
    "**جداسازی در روزهای نخست، شیردهی و پیوند مادر-نوزاد را به‌شدت آسیب می‌زند** — "
    "بدون آنکه هیچ خطری را رفع کند.\n\n"
    "**درس نهایی این خوشه: در نوزاد مادر مسلول، همیشه یک سؤال بپرسید — «آیا مادر "
    "هنگام زایمان مسری بود؟» پاسخ آن، هر چهار تصمیم (شیر، جداسازی، پروفیلاکسی، "
    "ب‌ث‌ژ) را یک‌جا تعیین می‌کند.**",
    "This question is THE MIRROR IMAGE of the previous one — and comparing the two is the best way to consolidate the topic.\n\n"
    "THE PATIENT: a 28-year-old woman who was diagnosed with smear-positive pulmonary tuberculosis in the SEVENTH MONTH of pregnancy and started standard four-drug therapy, and whose sputum smear HAD BECOME NEGATIVE BY THE NINTH MONTH. What do you advise for the newborn?\n\n"
    "THE ANSWER: GIVE THE BCG VACCINE.\n\n"
    "WARNING: PUT THE TWO QUESTIONS SIDE BY SIDE — THIS COMPARISON ILLUMINATES THE WHOLE TOPIC:\n\n"
    "THE PREVIOUS QUESTION: treatment began at 38 weeks and delivery followed EIGHT DAYS LATER. So THE MOTHER WAS STILL INFECTIOUS AT DELIVERY, and THE INFANT NEEDS PROPHYLAXIS WHILE BCG IS DEFERRED.\n\n"
    "THIS QUESTION: treatment began IN THE SEVENTH MONTH and BY THE NINTH MONTH THE SMEAR HAD CONVERTED. So there were ABOUT TWO MONTHS OF EFFECTIVE TREATMENT WITH SMEAR CONVERSION; THE MOTHER IS NO LONGER INFECTIOUS; THE INFANT NEEDS NO PROPHYLAXIS AND BCG IS GIVEN AS NORMAL.\n\n"
    "SO THE DECIDING VARIABLE IS 'IS THE MOTHER INFECTIOUS AT DELIVERY?' — not 'has the mother had tuberculosis?'.\n\n"
    "AND 'THE SMEAR HAS CONVERTED' IS THE BEST POSSIBLE EVIDENCE: smear conversion is THE OBJECTIVE LABORATORY CRITERION FOR THE END OF INFECTIOUSNESS.\n\n"
    "SO, SINCE THE INFANT HAS HAD NO MEANINGFUL EXPOSURE:\n\n"
    "NO ISONIAZID PROPHYLAXIS IS REQUIRED — AND SINCE NO ISONIAZID IS GIVEN, THERE IS NO OBSTACLE TO BCG — SO BCG IS GIVEN AT BIRTH, ON THE ROUTINE NATIONAL SCHEDULE.\n\n"
    "WARNING: LOOK AGAIN AT THE BCG LOGIC — THE ONLY REASON FOR DEFERRING IT IN THE PREVIOUS QUESTION WAS THE INTERACTION WITH ISONIAZID. With no isoniazid, that reason disappears.\n\n"
    "AND BCG IS PART OF THE BIRTH VACCINATION SCHEDULE IN IRAN and gives good protection against miliary tuberculosis and tuberculous meningitis in children.\n\n"
    "WHY ARE THE OTHER THREE REJECTED?\n\n"
    "WARNING: WITHHOLDING BREAST MILK — THE SAME PERENNIAL ERROR. Tuberculosis is not transmitted in milk, and THIS MOTHER IS NOT EVEN INFECTIOUS ANY MORE. STOPPING BREASTFEEDING HERE HAS NO JUSTIFICATION WHATEVER.\n\n"
    "STARTING ISONIAZID — PROPHYLAXIS WITHOUT EXPOSURE. The mother is SMEAR-NEGATIVE. GIVING SIX MONTHS OF A DRUG TO AN UNEXPOSED INFANT IS NEEDLESS TOXICITY — and it also DEFERS THE BCG FOR NO REASON.\n\n"
    "SEPARATING THE NEWBORN FROM THE MOTHER — CRUEL AND UNNECESSARY. She is not infectious. SEPARATION IN THE FIRST DAYS SEVERELY DAMAGES BREASTFEEDING AND MOTHER-INFANT BONDING — while removing no risk at all.\n\n"
    "THE FINAL LESSON OF THIS CLUSTER: with the newborn of a mother with tuberculosis, always ask ONE QUESTION — 'WAS THE MOTHER INFECTIOUS AT DELIVERY?' Its answer settles all four decisions at once: milk, separation, prophylaxis and BCG.",
    ["خطای همیشگی؛ سل از راه شیر منتقل نمی‌شود و این مادر اصلاً دیگر مسری نیست.",
     "پروفیلاکسی بدون مواجهه؛ سمّیت بی‌دلیل و به‌تعویق‌انداختن بی‌جهت ب‌ث‌ژ.",
     "پاسخ صحیح — مادر اسمیر منفی شده و مسری نیست؛ ب‌ث‌ژ طبق برنامه‌ی معمول.",
     "بی‌رحمانه و بی‌دلیل؛ مادر مسری نیست و جداسازی هیچ خطری را رفع نمی‌کند."],
    ["The perennial error; tuberculosis is not transmitted in milk and this mother is no longer infectious.",
     "Prophylaxis without exposure; needless toxicity and a pointless deferral of BCG.",
     "Correct — the mother's smear has converted and she is not infectious; BCG on the routine schedule.",
     "Cruel and unnecessary; she is not infectious and separation removes no risk at all."],
    "**یک سؤال همه‌چیز را تعیین می‌کند: آیا مادر هنگام زایمان مسری بود؟**",
    "One question settles everything: was the mother infectious at delivery?",
    REFSN)

json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book57.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 57 lessons:', len(L))
