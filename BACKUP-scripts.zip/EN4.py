# -*- coding: utf-8 -*-
"""English stems and options for the batch-10 (sepsis) questions.

These translations carry more numeric weight than any earlier batch: the answer
to a staging question is COMPUTED from the vital signs, so a single wrong digit
changes the correct option. Every number below was taken from the stem AFTER
fix_vitals_geometry.py corrected the mirrored values from glyph geometry, and
apply_en.py re-checks each one before attaching anything.

Rule 16 checked again: these are sittings 93-98, for which no ministry English
booklet exists.
"""

EN4 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    assert all(o.strip() for o in options), idx
    EN4[idx] = {"stem_en": stem, "options_en": options}


add(833,
    "A 65-year-old diabetic man is brought to the emergency department with fever, urinary symptoms "
    "(urinary incontinence and frequency) and drowsiness. Initial assessment shows a fever of 39 "
    "degrees, PR 104/min, tachypnoea at 28/min and a blood pressure of 80/50. After one litre of "
    "normal saline his blood pressure reaches 100/70 and his general condition clearly improves. "
    "Which term best describes this patient's state?",
    ["Severe sepsis", "Sepsis", "Septic shock", "SIRS positive"])

add(834,
    "A 60-year-old man with a 3-year history of BPH presents with fever, dysuria, frequency and "
    "dribbling of urine for 2 days. On examination he is febrile with a pulse of 104, a respiratory "
    "rate of 28/min and a blood pressure of 85/55 mmHg. Blood cultures are negative but the urine "
    "culture is positive. His creatinine is reported as 2. One litre of normal saline is infused "
    "without response, but after infusing norepinephrine his blood pressure rises and his vital "
    "signs improve markedly. Which is the most appropriate description?",
    ["SIRS positive", "Sepsis", "Severe sepsis", "Septic shock"])

add(828,
    "A 45-year-old man develops fever, rigors, nausea and abdominal pain 2 days after a "
    "cholecystectomy. On examination he is lethargic and has become oliguric. His vital signs are "
    "BT 39, RR 40, BP 80/50. Investigations show WBC 16000 with 90% PMN. After giving 3 litres of "
    "normal saline and starting dopamine the patient remains hypotensive. Which of the following "
    "pictures do these findings fit?",
    ["SIRS", "Severe sepsis", "Sepsis syndrome", "Refractory septic shock"])

add(835,
    "A 70-year-old diabetic man is brought to the emergency department with fever and drowsiness. "
    "On examination PR is 100/min, RR is 28/min, T is 38.5 C and BP is 80/40 mmHg, and he is not "
    "oriented to place or time. Investigations show a WBC of 13000, and urinalysis shows pyuria and "
    "bacteriuria. Which of the following stages is this patient in?",
    ["Severe sepsis", "Sepsis", "Septic shock", "Refractory septic shock"])

add(831,
    "An 89-year-old man is admitted with a diagnosis of urosepsis. His blood pressure is 70/50 mmHg "
    "and his haemoglobin is 9 mg/dL. In addition to blood cultures and antibiotics, which of the "
    "following is your first treatment?",
    ["Intravenous hydrocortisone", "Blood transfusion", "Dopamine", "Normal saline"])

add(832,
    "A 70-year-old woman is admitted with fever, rigors, dysuria and urinary frequency. She has a "
    "temperature of 39 degrees Celsius, a pulse of 120 per minute and a systolic blood pressure of "
    "70 mmHg. Which of the following is the first treatment?",
    ["Give normal saline", "Give norepinephrine", "Give epinephrine", "Give dopamine"])

# The blood pressure of this stem is unrecoverable: the book prints "BP=70/P",
# with the systolic glyph simply missing from the PDF. The English therefore
# reports the diastolic exactly as the source does rather than inventing a
# systolic. The answer does not depend on it: the question asks which
# haemodynamic GOAL is recommended, not how to stage this patient.
add(830,
    "You review an elderly patient with fever, weakness and malaise. The patient is drowsy and the "
    "vital signs are T 39.5, BP 70 diastolic (systolic not legible in the source), RR 32/min and HR "
    "130/min. Specimens for microbiological study are taken, broad-spectrum antibiotics are started, "
    "and a central venous catheter and Foley catheter are inserted. Which of the following is among "
    "the recommended haemodynamic goals in treating this patient?",
    ["Reducing the heart rate to below 100/min",
     "Establishing a urine output above 0.2 cc/kg/hr",
     "A mean arterial pressure above 65 mmHg",
     "Reaching a central venous pressure of 15 cmH2O"])

add(844,
    "A hospitalised patient is being treated with vancomycin for Staphylococcus aureus septicaemia. "
    "During the vancomycin infusion the patient develops redness of the face and neck with a "
    "sensation of flushing. What do you recommend to prevent this happening again?",
    ["Change vancomycin to cefazolin",
     "Give hydrocortisone before the vancomycin",
     "Infuse the vancomycin slowly",
     "Change vancomycin to linezolid"])
