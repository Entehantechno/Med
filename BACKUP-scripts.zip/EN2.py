# -*- coding: utf-8 -*-
"""English stems and options for the batch-8 (tetanus) questions.

Same discipline as EN1: hand written, never machine translated, and only for
questions that already carry a hand-written bilingual lesson. apply_en.py
verifies that every multi-digit number in the Persian survives into the English
before attaching anything, because in these vignettes the numbers ARE the
question — 11 years versus 5 years decides the answer.

Rule 16 was checked again for this batch: the ministry's bilingual booklets
cover Esfand 1400 and Khordad 1402, whereas these items come from sittings
93-98, so no official translation exists to reuse.
"""

EN2 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    assert all(o.strip() for o in options), idx
    EN2[idx] = {"stem_en": stem, "options_en": options}


add(368,
    "A 75-year-old farmer with no history of vaccination presents after a deep laceration to the "
    "sole of his foot sustained while working in a field yesterday. On examination the wound looks "
    "clean with no inflammatory signs. Which of the following do you recommend?",
    ["Tetanus immune globulin",
     "Tetanus vaccine",
     "Antibiotic plus vaccine",
     "Tetanus immune globulin plus vaccine"])

add(371,
    "An 8-year-old child injures his hand on a rusty nail while playing in a park. His vaccination "
    "record is complete. Regarding tetanus prophylaxis, which of the following is correct?",
    ["Give TIG and vaccine",
     "No action is needed",
     "Give TIG",
     "Give a single dose of vaccine"])

add(373,
    "A young man presents after being bitten by a rat yesterday. He received his last dose of "
    "tetanus vaccine three years ago. Which of the following is correct for tetanus prophylaxis?",
    ["Adult tetanus-diphtheria vaccine",
     "Tetanus immune globulin",
     "Adult tetanus-diphtheria vaccine plus tetanus immune globulin",
     "No action is required in this regard"])

add(378,
    "A 25-year-old Afghan woman superficially cut her hand while working with a scalpel. On "
    "examination there is a superficial wound on the tip of her right thumb. She has no childhood "
    "vaccination history and recently migrated to Iran. Which action is appropriate?",
    ["Tetanus immunoglobulin plus one dose of adult tetanus-diphtheria vaccine",
     "Start the adult tetanus-diphtheria vaccination series",
     "Tetanus immunoglobulin together with starting adult vaccination",
     "Tetanus immunoglobulin alone"])

add(364,
    "For the prevention of neonatal tetanus, what do you advise a pregnant woman with no history "
    "of tetanus vaccination?",
    ["Two doses of tetanus vaccine (TT) one month apart",
     "Three doses of tetanus vaccine (TT) one month apart",
     "A single dose of tetanus vaccine (TT) is sufficient",
     "Two doses of tetanus vaccine (TT) one month apart plus tetanus immune globulin"])

add(382,
    "A 31-year-old man with a complete tetanus vaccination history is admitted after a road "
    "accident with an extensive thigh laceration. Given that he received his last dose of tetanus "
    "vaccine at the age of 20, what do you recommend for tetanus prophylaxis?",
    ["Tetanus immune globulin",
     "Toxoid",
     "Tetanus immune globulin plus toxoid",
     "No action is needed"])

add(358,
    "By which of the following methods is tetanus diagnosed?",
    ["On the basis of clinical findings",
     "Anaerobic culture of the wound site",
     "Measurement of IgG against tetanus toxin",
     "PCR to detect tetanus toxin"])

add(385,
    "Which of the following definitively diagnoses tetanus?",
    ["Blood PCR for C. tetani",
     "Wound culture for C. tetani",
     "Measurement of serum C. tetani antitoxin",
     "None of the above"])

add(377,
    "A 70-year-old farmer developed weakness, malaise and muscle pain 2 days ago, followed by spasm "
    "of the facial muscles and difficulty swallowing. As the symptoms progressed he was referred to "
    "you with generalised spasms in a decorticate posture, conscious but breathing with difficulty. "
    "On examination the lungs are clear, heart sounds are normal and the abdomen is board-rigid. "
    "There is a 3x2 cm wound between the 2nd and 3rd toes of the left foot with scant purulent "
    "discharge, sustained 10 days ago at work. Vital signs: temperature 37.5 C, pulse 120/min, "
    "blood pressure 90/60 mmHg. Given the most likely diagnosis, and alongside intubation and "
    "haemodynamic resuscitation, which treatment do you consider?",
    ["Wound debridement, metronidazole and TIG",
     "Wound debridement, penicillin and TIG",
     "Wound debridement, vancomycin plus clindamycin",
     "Wound debridement, ceftriaxone and steroid"])

add(366,
    "A 17-year-old woman at 8 weeks of pregnancy has received only her primary childhood vaccines "
    "and none of the subsequent boosters. Regarding tetanus vaccination, which option is correct?",
    ["Two doses four weeks apart are recommended",
     "Three doses at 0, 1 and 6 months are recommended",
     "A single dose is sufficient",
     "Three doses four weeks apart are sufficient"])

add(367,
    "A 42-year-old nomadic woman at 3 weeks of pregnancy, with no history of tetanus vaccination, "
    "attends a health centre for pre-pregnancy care. What is your advice regarding tetanus "
    "vaccination?",
    ["Give tetanus vaccine and tetanus immune globulin",
     "Give two doses of tetanus vaccine at least four weeks apart",
     "Tetanus vaccine is contraindicated because she is pregnant",
     "Give tetanus immune globulin"])
