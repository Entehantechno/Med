# -*- coding: utf-8 -*-
"""Data audit of the parasitology / malaria chapter BEFORE any lesson is written.

Why this runs first
-------------------
Three chapters in a row turned up a fresh CLASS of data defect the moment they
were inspected (mirrored ages, mirrored vital signs, mirrored lab values inside
compound tokens). So the chapter is audited before a single lesson is authored:
a lesson written on top of a corrupt number teaches the wrong medicine.

What this chapter puts at risk is specific. A whole block here asks the student
to decide whether a malaria patient meets the criteria for SEVERE falciparum
disease, and those criteria are pure thresholds:

    haemoglobin < 5 g/dL          arterial pH < 7.25
    bicarbonate < 15 mmol/L       urine output < 400 mL/24 h
    blood glucose < 40 mg/dL      parasitaemia > 5 %

A mirrored decimal does not merely look odd here. "Hb = 4/5" reads as 4.5 g/dL,
which IS severe anaemia — and the printed key names that very option as the one
that is NOT a severity criterion. Un-mirrored to 5.4 g/dL the key becomes
correct. The number and the key stand or fall together, so the number must be
settled from the page itself, not from what makes the key convenient.

Method: the same glyph geometry used for the ages and the vitals. pdfplumber
reports each glyph's x-coordinate, and digits are always drawn left to right
even inside right-to-left script, so sorting a line's glyphs by x0 recovers the
digits in the order the typesetter placed them. Nothing here edits the payload;
this script only REPORTS, so the findings can be judged one by one.
"""
import json, io, os, re, collections

import pdfplumber

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = '/home/user/uploads/بیماری عفونی.pdf'
CHAPTER = 'بیماری‌های انگلی و مالاریا'


def letters(s):
    s = re.sub(r'[\u0660-\u0669\u06F0-\u06F9]', '', s or '')
    return re.sub(r'[^\u0600-\u06FF]', '', s)


def page_lines(pdf):
    out = []
    for pno, page in enumerate(pdf.pages, 1):
        rows = collections.defaultdict(list)
        for c in page.chars:
            rows[round(c['top'])].append(c)
        for top in sorted(rows):
            cs = sorted(rows[top], key=lambda c: c['x0'])
            text = ''.join(c['text'] for c in cs)[::-1]
            digits = ''.join(c['text'] for c in cs if c['text'].isdigit())
            out.append((pno, letters(text), digits, text))
    return out


# Numbers this chapter's answers are computed from, plus the drug doses.
SUSPECT = [
    (r'هموگلوبین\s*=?\s*(\d+/\d+)', 'Hb'),
    (r'gr\s*(\d+/\d+)', 'Hb'),
    (r'بیکربنات\s*(\d{2,3})', 'HCO3'),
    (r'PH[^0-9]{0,8}(\d+\.\d+|\d+/\d+)', 'pH'),
    (r'mg\s*0*(\d{2,4})', 'dose'),
    (r'mμ\s*(\d{2,3})|μm\s*(\d{2,3})', 'egg'),
    (r'(\d{2,3})\s*ساله', 'age'),
    (r'پلاکت\s*=?\s*(\d{4,6})', 'Plt'),
    (r'هماتوکریت\s*زیر\s*(\d{1,3})', 'Hct'),
]


def main():
    qs, flat = [], 0
    for i in range(1, 6):
        p = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        body = json.load(io.open(p, encoding='utf-8'))
        for q in body['questions']:
            if q['chapter_fa'] == CHAPTER:
                qs.append((flat, q))
            flat += 1

    with pdfplumber.open(SRC) as pdf:
        lines = page_lines(pdf)

    index = collections.defaultdict(list)
    for pno, key, digits, text in lines:
        if len(key) >= 12:
            index[key].append((pno, digits, text))

    print(f'{len(qs)} questions in {CHAPTER}\n')
    for idx, q in qs:
        blob = q['question_fa'] + ' || ' + ' | '.join(q['options_fa'])
        hits = []
        for pat, kind in SUSPECT:
            for m in re.finditer(pat, blob):
                val = next(g for g in m.groups() if g)
                hits.append((kind, m.group(0).strip(), val))
        if not hits:
            continue
        # what the page itself printed, for the sentences we can match uniquely
        printed = []
        for piece in re.split(r'(?<=[.؟])\s+', q['question_fa']) + q['options_fa']:
            k = letters(piece)
            if len(k) >= 12 and len(index.get(k, [])) == 1:
                printed.append(index[k][0][1])
        print(f"idx={idx} q{q['question_no']}")
        for kind, txt, val in hits:
            print(f"    {kind:5s} stored={val!r:>10}   in {txt!r}")
        if printed:
            print(f"    page digits: {printed}")
        print()


if __name__ == '__main__':
    main()
