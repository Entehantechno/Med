# -*- coding: utf-8 -*-
"""Infectious-diseases block of the Azar-1404 paper — the LAST sitting held.

This is the strongest source in the whole archive: the Persian booklet, the
ministry's own ENGLISH booklet and the official answer key all exist, so the
keys here are `official` and the English text is lifted verbatim rather than
translated (project rule).

Reference for the lessons: Harrison's Principles of Internal Medicine, 21st ed
— the official 1405 syllabus names it explicitly and lists 35 selected
chapters (see work/infectious/REFERENCE.md).
"""
import json, io, os
LET = ['الف', 'ب', 'ج', 'د']
OUT = '/home/user/work/infectious/out'
os.makedirs(OUT, exist_ok=True)

# (no, stem_fa, options_fa, stem_en, options_en, official_key_index, rationale)
Q = [
 (103,
  "بیمار آقای جوان ۲۵ ساله با تب و لرز دوره‌ای، تهوع و استفراغ، ادرار قهوه‌ای‌رنگ و اسکلرای ایکتریک مراجعه کرده است و کمی خواب‌آلود نیز می‌باشد. در شرح حال، همراهان سابقه‌ی سفر اخیر به مرز بلوچستان را می‌دهند. در بررسی لام خون محیطی گامتوسیت‌های موزی‌شکل به چشم می‌خورد. کدام‌یک از موارد زیر در درمان ایشان صحیح است؟",
  ["درمان خوراکی با داکسی‌سایکلین کفایت می‌کند",
   "بیمار باید فوراً آرتسونات تزریقی دریافت نماید و به مرکز مجهزتر اعزام شود",
   "درمان خوراکی آرتمتر-لومفانترین کفایت می‌کند",
   "درمان با هیدروکسی‌کلروکین کافی است"],
  "A 25-year-old man presented with periodic fever, chills, nausea, vomiting, brown discolouration of urine, and icteric sclera. He is mildly drowsy. In history, his companions mention his recent trip to border of Baluchistan. In the investigation of peripheral blood smear, banana-shaped gametocytes are seen. Which one is correct?",
  ["Oral treatment with doxycycline is sufficient.",
   "The patient must be treated with parenteral artesunate and referred to a more equipped center.",
   "Oral treatment with artemether-lumefantrine is sufficient.",
   "Treatment with hydroxychloroquine is sufficient."],
  1,
  "گامتوسیت موزی‌شکل (هلالی) امضای پلاسمودیوم فالسیپاروم است و هیچ گونه‌ی دیگری این شکل را نمی‌سازد. "
  "سفر به مرز بلوچستان هم منطقه‌ی آندمیک ایران را تأیید می‌کند. حالا نکته‌ی حیاتی، تشخیص مالاریای «شدید» "
  "است: این بیمار هم زردی دارد، هم ادرار قهوه‌ای (همولیز و هموگلوبینوری) و هم اختلال هوشیاری — و هر یک "
  "از این‌ها به‌تنهایی معیار مالاریای شدید است. در مالاریای شدید، درمان خوراکی ممنوع است و آرتسونات "
  "تزریقی داروی انتخابی است که مرگ‌ومیر را نسبت به کینین به‌طور معناداری کم می‌کند."),

 (104,
  "سرباز جوانی که شب گذشته کنسرو خانگی مصرف نموده است، با تاری دید و دوبینی به اورژانس مراجعه کرده و از علائم گوارشی تهوع دارد. بهترین آزمون تشخیصی کدام است؟",
  ["تست PCR بر روی نمونه‌ی مدفوع",
   "کشت مدفوع",
   "انجام LP و آنالیز CSF",
   "جداسازی توکسین از سرم بیمار"],
  "A young soldier consumed homemade, canned food last night. He is presented with blurred vision and diplopia. He has nausea. What is the best diagnostic test?",
  ["PCR test on the stool specimen",
   "Stool culture",
   "Lumbar puncture (LP) and analysis of cerebrospinal fluid (CSF)",
   "Serum toxin assay"],
  3,
  "کنسرو خانگی به‌علاوه‌ی فلج اعصاب کرانیال (تاری دید و دوبینی) یعنی بوتولیسم غذایی تا خلاف آن ثابت شود. "
  "بیماری از خودِ باکتری نمی‌آید، از توکسین از پیش ساخته‌شده در غذا می‌آید که انتشار استیل‌کولین را در "
  "پایانه‌ی عصبی مسدود می‌کند. پس منطقی است که تشخیص قطعی هم بر پایه‌ی یافتن همان توکسین در سرم باشد، "
  "نه یافتن باکتری در مدفوع. نکته‌ی بالینی مهم: نمونه باید پیش از تجویز آنتی‌توکسین گرفته شود، اما درمان "
  "هرگز منتظر جواب آزمایش نمی‌ماند."),

 (105,
  "بیماری به علت تب خفیف، ضعف، درد قسمت تحتانی شکم و اسهال از یک هفته قبل مراجعه می‌کند. اسهال وی بیش از ۱۰ بار در روز، هر بار با حجم کم و تنسموس شدید است. در نمونه‌ی مدفوع بیمار WBC=۵-۱۰/HPF و RBC=many و تروفوزوئیت آنتامبا هیستولیتیکا گزارش می‌شود. درمان انتخابی چیست؟",
  ["مترونیدازول ۱۰ روز",
   "یدوکینول ۲۱ روز",
   "تینیدازول ۳ روز به همراه پارومومایسین ۱۰ روز",
   "مترونیدازول ۷ روز به همراه یدوکینول ۱۰ روز"],
  "A patient presented with low fever, weakness, lower abdominal pain and diarrhea from 1 week ago. Diarrhea is more than 10 times a day with low volume and severe tenesmus. The patient's stool exam shows WBC=5-10 and RBC=many and Entamoeba histolytica trophozoites. What is the treatment choice?",
  ["metronidazole 10 days",
   "iodoquinol 21 days",
   "tinidazole 3 days + paromomycin 10 days",
   "metronidazole 7 days + iodoquinol 10 days"],
  3,
  "کولیت آمیبی دو مرحله‌ی درمانی دارد و دانستن همین دو مرحله کل سؤال را حل می‌کند. مرحله‌ی اول کشتن "
  "تروفوزوئیت‌های مهاجم در دیواره‌ی روده است که با یک نیتروایمیدازول مثل مترونیدازول انجام می‌شود. "
  "مرحله‌ی دوم پاک کردن کیست‌های باقی‌مانده در لومن است، چون مترونیدازول در لومن غلظت کافی پیدا نمی‌کند "
  "و اگر این مرحله انجام نشود بیمار حامل می‌ماند و عود می‌کند. برای همین یک داروی لومینال مثل یدوکینول "
  "یا پارومومایسین لازم است. پس درمان کامل یعنی مترونیدازول به‌علاوه‌ی یدوکینول، نه هیچ‌کدام به‌تنهایی."),

 (106,
  "آقای ۱۸ ساله به علت گاز گرفتگی با سگ مراجعه کرده است. نامبرده حساسیت آنافیلاکسی به داروی پنی‌سیلین دارد. درمان انتخابی اولیه کدام است؟",
  ["کوآموکسی‌کلاو",
   "کلیندامایسین به همراه سیپروفلوکساسین",
   "آمپی‌سیلین به همراه سولباکتام",
   "سفالکسین به همراه کوتریموکسازول"],
  "An 18-year-old man bitten by a dog is referred with a history of anaphylaxis to penicillin. What is the primary treatment choice?",
  ["Co-amoxiclav",
   "Clindamycin + Ciprofloxacin",
   "Ampicillin-Sulbactam",
   "Cephalexin + Co-trimoxazole"],
  1,
  "این سؤال دو قید دارد که باید همزمان رعایت شوند. قید اول پوشش میکروبی است: زخم گازگرفتگی سگ "
  "پلی‌میکروبی است و باید هم پاستورلا مولتوسیدا، هم استافیلوکوک و استرپتوکوک و هم بی‌هوازی‌های دهانی "
  "پوشش داده شوند؛ به همین دلیل انتخاب اول در حالت عادی آموکسی‌سیلین-کلاوولانات است. قید دوم آنافیلاکسی "
  "به پنی‌سیلین است که سه گزینه‌ی حاوی بتالاکتام را یک‌جا حذف می‌کند (سفالکسین هم به‌خاطر واکنش متقاطع و "
  "هم به‌خاطر پوشش ضعیف پاستورلا نامناسب است). ترکیب کلیندامایسین با سیپروفلوکساسین جایگزین استاندارد "
  "است: کلیندامایسین بی‌هوازی‌ها و گرم‌مثبت‌ها را می‌پوشاند و سیپروفلوکساسین پاستورلا را."),

 (107,
  "برای بیماری با شرح حال کاهش هوشیاری از حدود چند ساعت قبل به همراه علائم تاکی‌کاردی، تاکی‌پنه و هایپوکسی، با توجه به وجود کدورت ریوی از نظر نیاز به شروع آنتی‌بیوتیک مشاوره درخواست شده است. بیمار تب نداشته و در آزمایش لکوسیتوز دارد. در این بیمار توصیه‌ی صحیح کدام است؟",
  ["شروع لووفلوکساسین",
   "سندرم مندلسون مطرح است و در حال حاضر نیازی به شروع آنتی‌بیوتیک نیست",
   "سفتریاکسون و کلیندامایسین شروع شود",
   "سفتریاکسون و مترونیدازول شروع شود"],
  "A patient has a history of impaired consciousness from several hours ago and tachycardia, tachypnea and hypoxia. He is being consulted about starting antibiotics regarding haziness in the field of lungs. The patient does not have fever. Leukocytosis is seen in his laboratory tests. Which one is correct?",
  ["Starting Levofloxacin",
   "The Mendelson's syndrome is considered and there is no need to start antibiotics now.",
   "Starting Ceftriaxone and Clindamycin",
   "Starting Ceftriaxone and Metronidazole"],
  1,
  "کلید این سؤال جدا کردن «پنومونیت آسپیراسیون» از «پنومونی آسپیراسیون» است. اینجا بیمار با کاهش "
  "هوشیاری، محتویات اسیدی معده را آسپیره کرده و طی چند ساعت دچار التهاب شیمیایی حاد ریه شده است؛ به این "
  "حالت سندرم مندلسون می‌گویند. شواهد له آن: فاصله‌ی زمانی بسیار کوتاه (چند ساعت)، نبود تب، و لکوسیتوزی "
  "که پاسخ التهابی به آسیب شیمیایی است نه لزوماً عفونت. پنومونی باکتریال آسپیراسیون برعکس، طی روزها "
  "شکل می‌گیرد و معمولاً تب دارد. درمان مندلسون حمایتی است و آنتی‌بیوتیک تجربی فقط فلور را مقاوم می‌کند؛ "
  "اگر پس از ۴۸ ساعت بهبود نیافت یا تب کرد، آن‌وقت آنتی‌بیوتیک شروع می‌شود."),

 (108,
  "آقای ۲۸ ساله مبتلا به اسپوندیلیت آنکیلوزان شدید، کاندید درمان با داروی anti-TNF است. تست TST انجام شده و ۶ میلی‌متر اندوراسیون گزارش شده است. علائم و نشانه‌های بالینی سل وجود ندارد و CXR طبیعی است. توصیه‌ی شما چیست؟",
  ["با توجه به بررسی‌ها سل مطرح نیست و اقدامی نیاز ندارد",
   "درمان چهاردارویی سل با توجه به نقص ایمنی شروع شود",
   "درمان پیشگیرانه‌ی سل با ایزونیازید پیشنهاد می‌شود",
   "برونکوسکوپی جهت بررسی بیشتر توصیه می‌شود"],
  "A 28-year-old male, a known case of severe ankylosing spondylitis, is a candidate of a treatment with anti-TNF. TST test is performed and the induration of 6 mm is reported. Clinical signs and symptoms of tuberculosis are not present. CXR is normal. What is your recommendation?",
  ["Tuberculosis is not considered due to the investigations and no management is needed.",
   "Starting antituberculosis 4 drug regimen due to immunosuppression",
   "Chemoprophylaxis with isoniazid is recommended.",
   "Bronchoscopy is recommended for further evaluation."],
  2,
  "نکته‌ی کلیدی این است که آستانه‌ی مثبت شدن TST ثابت نیست و به گروه خطر بستگی دارد. برای فرد سالم "
  "کم‌خطر آستانه ۱۵ میلی‌متر است، اما برای بیماری که قرار است داروی مهارکننده‌ی TNF بگیرد آستانه به "
  "۵ میلی‌متر کاهش می‌یابد. دلیلش زیستی است: TNF-آلفا همان سیتوکینی است که گرانولوم را منسجم نگه می‌دارد، "
  "پس مهار آن می‌تواند سل نهفته را به سل فعال و اغلب منتشر تبدیل کند. پس ۶ میلی‌متر در این بیمار "
  "«مثبت» است. چون علائم و CXR طبیعی‌اند، تشخیص سل نهفته است نه فعال، و درمان آن تک‌دارویی پیشگیرانه "
  "با ایزونیازید است. رژیم چهاردارویی برای سل فعال است و اینجا اضافه‌درمانی محسوب می‌شود."),
]

out = []
for n, fa, fo, en, eo, ans, why in Q:
    out.append({
        'exam': 'آذر ۱۴۰۴', 'exam_tag': '1404-09', 'question_no': n,
        'subject_fa': 'بیماری‌های عفونی', 'subject_en': 'Infectious Diseases',
        'stem_fa': fa, 'options_fa': fo,
        'stem_en': en, 'options_en': eo,
        'en_source': 'official_english_booklet',
        'correct_index': ans, 'correct_letter': LET[ans],
        'key_source': 'official', 'key_rationale': why,
        'source_file': 'PishKarvarzi-Azar1404 Farsi/English + official key',
        'notes': {
            'sitting': 'آزمون میان‌دوره‌ی الکترونیکی، طراحی دانشگاه علوم پزشکی قزوین.',
            'key': 'کلید رسمی منتشرشده‌ی مرکز سنجش؛ هر شش پاسخ مستقل بر پایه‌ی Harrison 21st ed '
                   'بازبینی و تأیید شد (۶ از ۶ تطابق).',
            'english': 'متن انگلیسی عیناً از دفترچه‌ی انگلیسی رسمی وزارت بهداشت است، نه ترجمه.',
            'reference': "Harrison's Principles of Internal Medicine, 21st ed — منبع رسمی اعلام‌شده "
                         'برای درس عفونی در آزمون‌های اسفند ۱۴۰۴ تا بهمن ۱۴۰۵.'},
    })
    print(f"q{n}: {LET[ans]}) {fo[ans][:52]}")

json.dump(out, io.open(f'{OUT}/inf_1404_09.json', 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print(f'\nsaved {len(out)} infectious questions — Azar-1404 (official key + official English)')
