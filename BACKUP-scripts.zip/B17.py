# -*- coding: utf-8 -*-
"""Micro-lessons, batch 17 — tuberculosis: diagnosis, regimens, drug toxicity.

80 questions with six taught, and unusually high clinical stakes: tuberculosis
is endemic in Iran, so these are decisions a graduate will actually make.

The chapter is organised around four blocks, and each block turns on ONE
number or ONE rule that the exam asks repeatedly.

1. DIAGNOSIS: three sputum smears, and what to do when they are negative.
   Eight questions describe a patient with weeks of cough who has already
   failed a course of ordinary antibiotics, and ask the next step. The answer
   is almost always the smear, and when the smear is negative the national
   programme's algorithm — a trial of antibiotics, then REPEAT the smears —
   is what the keys follow.

2. REGIMENS: 2HRZE/4HR for a new case, and the retreatment question. The book
   asks the previously-treated case four times, and its keys follow the
   classical WHO category II logic. Modern WHO has abandoned category II in
   favour of drug-susceptibility-guided therapy; the lessons teach both and say
   which the exam wants.

3. DRUG TOXICITY: each first-line drug owns one signature adverse effect, and
   twelve questions are simply "which drug did this?". The pairs are worth
   memorising as pairs.

4. LATENT TB: the three PPD thresholds. This is the block where a single
   millimetre changes the answer, which is why fix_tb_numbers.py had to run
   first — one stored PPD was 71 mm where the page prints 17.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022),
Chapter 178 (tuberculosis); WHO Treatment of Tuberculosis Guidelines;
Iranian National TB Programme guidance; ATS Statement on Hepatotoxicity of
Antituberculosis Therapy.
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 178"
WHO = "WHO — Treatment of Tuberculosis: Guidelines for National Programmes"
NTP = "دستورالعمل کشوری مبارزه با سل (Iranian National TB Programme)"
ATS = "ATS Official Statement — Hepatotoxicity of Antituberculosis Therapy"

# The drug/toxicity pairs, repeated verbatim in every drug-toxicity lesson.
TOX_FA = [
    "چهار داروی خط اول سل، هرکدام **یک عارضه‌ی امضایی** دارند؛ آن‌ها را جفت‌جفت حفظ کنید.",
    "**ایزونیازید (H)** ← **نوروپاتی محیطی** و **هپاتیت**.",
    "نوروپاتی ایزونیازید از تداخل با **ویتامین B6 (پیریدوکسین)** می‌آید.",
    "به همین دلیل در گروه‌های پرخطر **پیریدوکسین پیشگیرانه** داده می‌شود.",
    "پرخطرها: **بارداری، دیابت، الکلیسم، نارسایی کلیه، سوءتغذیه، HIV**.",
    "**ریفامپین (R)** ← **رنگ نارنجی ترشحات**، **ترومبوسیتوپنی**، و **القای سیتوکروم P450**.",
    "⚠️ القای P450 مهم‌ترین تداخل بالینی است: **قرص ضدبارداری را بی‌اثر می‌کند**.",
    "ریفامپین همچنین می‌تواند **نفریت بینابینی**، همولیز و سندرم شبه‌آنفلوانزا بدهد.",
    "**پیرازینامید (Z)** ← **هیپراوریسمی و آرتریت نقرسی**، و **هپاتوتوکسیک‌ترین** داروی رژیم.",
    "سازوکار نقرس: متابولیت پیرازینامید **دفع کلیوی اسید اوریک را مهار می‌کند**.",
    "**اتامبوتول (E)** ← **نوریت اپتیک**: کاهش حدت بینایی و **اختلال تشخیص رنگ سبز-قرمز**.",
    "⚠️ و نکته‌ی مهم: **اتامبوتول تنها داروی خط اول است که هپاتوتوکسیک نیست**.",
    "به همین دلیل وقتی داروها را به‌خاطر هپاتیت قطع می‌کنیم، **اتامبوتول می‌تواند بماند**.",
    "**استرپتومایسین (S)** ← **سمیت گوشی و کلیوی**؛ در بارداری ممنوع است.",
]
TOX_EN = [
    "Each of the four first-line TB drugs owns ONE SIGNATURE ADVERSE EFFECT; memorise them as pairs.",
    "ISONIAZID (H) -> PERIPHERAL NEUROPATHY and HEPATITIS.",
    "Isoniazid's neuropathy comes from interference with VITAMIN B6 (pyridoxine).",
    "That is why PROPHYLACTIC PYRIDOXINE is given to high-risk groups.",
    "The high-risk groups: PREGNANCY, DIABETES, ALCOHOLISM, RENAL FAILURE, MALNUTRITION, HIV.",
    "RIFAMPICIN (R) -> ORANGE DISCOLOURATION of secretions, THROMBOCYTOPENIA, and CYTOCHROME P450 INDUCTION.",
    "WARNING: P450 induction is the key clinical interaction — IT INACTIVATES THE ORAL CONTRACEPTIVE PILL.",
    "Rifampicin can also cause INTERSTITIAL NEPHRITIS, haemolysis and a flu-like syndrome.",
    "PYRAZINAMIDE (Z) -> HYPERURICAEMIA AND GOUTY ARTHRITIS, and it is the regimen's MOST HEPATOTOXIC drug.",
    "The gout mechanism: a pyrazinamide metabolite INHIBITS RENAL EXCRETION OF URIC ACID.",
    "ETHAMBUTOL (E) -> OPTIC NEURITIS: reduced acuity and impaired GREEN-RED colour discrimination.",
    "WARNING, an important point: ETHAMBUTOL IS THE ONLY FIRST-LINE DRUG THAT IS NOT HEPATOTOXIC.",
    "That is why, when the drugs are stopped for hepatitis, ETHAMBUTOL MAY BE CONTINUED.",
    "STREPTOMYCIN (S) -> OTOTOXICITY AND NEPHROTOXICITY; contraindicated in pregnancy.",
]

# The PPD thresholds, repeated verbatim in every latent-TB lesson.
PPD_FA = [
    "تست توبرکولین **سه آستانه** دارد، و آستانه به **گروه خطر بیمار** بستگی دارد نه به خود تست.",
    "⚠️ **۵ میلی‌متر یا بیشتر = مثبت** در پرخطرترین گروه‌ها:",
    "**HIV مثبت**، **تماس نزدیک اخیر** با مورد اسمیر مثبت، **پیوند عضو**،",
    "**مصرف کورتیکواستروئید طولانی** یا **مهارکننده‌ی TNF**، و **تغییرات فیبروتیک** در گرافی ریه.",
    "⚠️ **۱۰ میلی‌متر یا بیشتر = مثبت** در گروه‌های با خطر متوسط:",
    "**دیابت**، **نارسایی کلیه و همودیالیز**، **سیلیکوز**، **بدخیمی**، **گاسترکتومی**،",
    "**زندانیان**، **کارکنان بهداشتی**، **معتادان تزریقی**، **مهاجران اخیر**، و **کودکان زیر ۴ سال**.",
    "⚠️ **۱۵ میلی‌متر یا بیشتر = مثبت** در فردی که **هیچ عامل خطری ندارد**.",
    "منطق این سه آستانه ساده است: هرچه **احتمال پیش‌آزمون و خطر پیشرفت** بیشتر باشد، آستانه پایین‌تر.",
    "⚠️ و مهم‌ترین قاعده‌ی ایمنی، پیش از هر پروفیلاکسی: **اول باید سل فعال رد شود**.",
    "چرا؟ چون دادن **ایزونیازید تنها** به بیمار مبتلا به سل فعال، **مقاومت دارویی** می‌سازد.",
    "پس همیشه: شرح حال و معاینه، گرافی قفسه‌ی سینه، و در صورت لزوم اسمیر خلط — بعد پروفیلاکسی.",
    "درمان استاندارد سل نهفته: **ایزونیازید ۶ تا ۹ ماه** (در HIV، ۹ ماه).",
]
PPD_EN = [
    "The tuberculin test has THREE THRESHOLDS, and the threshold depends on THE PATIENT'S RISK GROUP, not on the test.",
    "WARNING, 5 MM OR MORE IS POSITIVE in the highest-risk groups:",
    "HIV POSITIVE, RECENT CLOSE CONTACT with a smear-positive case, ORGAN TRANSPLANT,",
    "prolonged CORTICOSTEROIDS or TNF INHIBITORS, and FIBROTIC CHANGES on the chest film.",
    "WARNING, 10 MM OR MORE IS POSITIVE in intermediate-risk groups:",
    "DIABETES, RENAL FAILURE AND DIALYSIS, SILICOSIS, MALIGNANCY, GASTRECTOMY,",
    "PRISONERS, HEALTHCARE WORKERS, INJECTING DRUG USERS, RECENT IMMIGRANTS, and CHILDREN UNDER 4.",
    "WARNING, 15 MM OR MORE IS POSITIVE in a person with NO RISK FACTOR AT ALL.",
    "The logic of the three thresholds is simple: the higher the pre-test probability and risk of progression, the lower the threshold.",
    "WARNING, and the most important safety rule before any prophylaxis: ACTIVE TB MUST BE EXCLUDED FIRST.",
    "Why? Because giving ISONIAZID ALONE to someone with active disease BREEDS DRUG RESISTANCE.",
    "So always: history and examination, chest radiograph, and sputum smear if needed — then prophylaxis.",
    "Standard treatment of latent TB: ISONIAZID FOR 6 TO 9 MONTHS (9 months in HIV).",
]


# ---------------------------------------------------------------- idx 217
add("book:217", "case", "easy",
 "سرفه‌ی طول‌کشیده + کاویته در قله + شکست آنتی‌بیوتیک = **اسمیر خلط، سه نوبت**.",
 "Prolonged cough + apical cavitation + failed antibiotics = THREE SPUTUM SMEARS.",
 [
  "این پرسش هشت بار در همین فصل به شکل‌های مختلف تکرار شده، پس الگو را یک‌بار خوب بشناسید.",
  "**الگوی مشترک همه‌ی آن‌ها**: سرفه‌ی بیش از دو هفته که به آنتی‌بیوتیک معمول جواب نداده.",
  "⚠️ و پاسخ تقریباً همیشه یکی است: **اسمیر خلط از نظر باسیل اسیدفاست، سه نوبت**.",
  "چرا سه نوبت؟ چون حساسیت یک اسمیر تنها حدود **۵۰ تا ۶۰ درصد** است.",
  "با سه نمونه، حساسیت مجموع به حدود **۸۰ تا ۹۰ درصد** می‌رسد.",
  "نمونه‌ی **صبحگاهی** بهترین است، چون ترشحات شب در ریه جمع شده‌اند.",
  "⚠️ چرا اسمیر بر همه‌ی گزینه‌های گران‌تر اولویت دارد؟ سه دلیل محکم.",
  "دلیل یک: **ارزان، سریع و در دسترس** است — نتیجه در همان روز.",
  "دلیل دو: اسمیر مثبت یعنی بیمار **مسری** است؛ این یک تصمیم **بهداشت عمومی** فوری است.",
  "دلیل سه: تشخیص را قطعی می‌کند و درمان بلافاصله شروع می‌شود.",
  "حالا سرنخ‌های این بیمار را ببینید — همه به سمت سل می‌روند:",
  "**بی‌خانمان** ✓ عامل خطر اپیدمیولوژیک قوی (ازدحام، سوءتغذیه، دسترسی کم به درمان).",
  "**کاشکتیک** ✓ کاهش وزن، از علائم اصلی سل.",
  "**شکست آزیترومایسین و کوآموکسیکلاو** ✓ — باکتری معمول نیست.",
  "⚠️ **انفیلتراسیون کاویتری در قله‌های ریه** ✓ — تقریباً تشخیصی برای **سل ثانویه**.",
  "چرا قله‌ی ریه؟ چون **فشار اکسیژن آنجا بیشترین** است و مایکوباکتریوم **هوازی اجباری** است.",
  "چرا CT اسکن نه؟ گران است، تشخیص قطعی نمی‌دهد، و بیمار را ایزوله نمی‌کند.",
  "چرا برونکوسکوپی نه؟ تهاجمی است و فقط وقتی جا دارد که اسمیرها منفی و شک بالا باشد.",
 ],
 [
  "This question is repeated eight times in this chapter in different guises, so learn the pattern once.",
  "THE COMMON PATTERN: a cough of more than two weeks that has not responded to ordinary antibiotics.",
  "WARNING, and the answer is almost always the same: THREE SPUTUM SMEARS for acid-fast bacilli.",
  "Why three? Because a single smear has a sensitivity of only about 50-60%.",
  "With three specimens the cumulative sensitivity rises to roughly 80-90%.",
  "The MORNING specimen is best, because secretions have pooled overnight.",
  "WARNING, why does the smear take priority over every more expensive option? Three solid reasons.",
  "Reason one: it is CHEAP, FAST AND AVAILABLE — a result the same day.",
  "Reason two: a positive smear means the patient is INFECTIOUS; that is an urgent PUBLIC HEALTH decision.",
  "Reason three: it establishes the diagnosis so treatment can begin at once.",
  "Now look at this patient's clues — all of them point to tuberculosis:",
  "HOMELESS (yes) — a strong epidemiological risk factor (crowding, malnutrition, poor access to care).",
  "CACHECTIC (yes) — weight loss, a cardinal feature of tuberculosis.",
  "FAILED AZITHROMYCIN AND CO-AMOXICLAV (yes) — this is not an ordinary bacterium.",
  "WARNING, CAVITARY INFILTRATION IN THE UPPER LOBES (yes) — nearly diagnostic of POST-PRIMARY tuberculosis.",
  "Why the apex? Because OXYGEN TENSION IS HIGHEST there and Mycobacterium is an OBLIGATE AEROBE.",
  "Why not CT? It is expensive, gives no definitive diagnosis, and does not get the patient isolated.",
  "Why not bronchoscopy? It is invasive, and belongs only where smears are negative and suspicion is high.",
 ],
 "این پرسش هشت بار در همین فصل تکرار شده، پس الگویش را یک‌بار خوب بشناسید: **سرفه‌ی بیش از دو هفته که به آنتی‌بیوتیک معمول جواب نداده** — و پاسخ تقریباً همیشه **اسمیر خلط از نظر باسیل اسیدفاست، سه نوبت** است.\n\n**چرا سه نوبت؟** چون حساسیت یک اسمیر تنها حدود **۵۰ تا ۶۰ درصد** است، ولی با سه نمونه حساسیت مجموع به **۸۰ تا ۹۰ درصد** می‌رسد. نمونه‌ی **صبحگاهی** بهترین است چون ترشحات شب در ریه جمع شده‌اند.\n\n⚠️ **چرا اسمیر بر گزینه‌های گران‌تر اولویت دارد؟** سه دلیل:\n۱. **ارزان، سریع و در دسترس** — نتیجه در همان روز\n۲. اسمیر مثبت یعنی بیمار **مسری** است — یک تصمیم **بهداشت عمومی** فوری\n۳. تشخیص را قطعی می‌کند و درمان بلافاصله شروع می‌شود\n\n**و حالا سرنخ‌های این بیمار، که همه به سل اشاره می‌کنند:**\n• **بی‌خانمان** ← عامل خطر اپیدمیولوژیک قوی\n• **کاشکتیک** ← کاهش وزن، از علائم اصلی سل\n• **شکست آزیترومایسین و کوآموکسیکلاو** ← باکتری معمول نیست\n• ⚠️ **انفیلتراسیون کاویتری در قله‌های ریه** ← تقریباً تشخیصی برای **سل ثانویه**\n\n**چرا سل قله‌ی ریه را می‌گیرد؟** چون **فشار اکسیژن در قله بیشترین** است و مایکوباکتریوم توبرکلوزیس یک **هوازی اجباری** است. همین یک نکته، هم محل سل ثانویه را توضیح می‌دهد و هم اینکه چرا کاویته می‌سازد.\n\n**چرا گزینه‌های دیگر نه؟** CT گران است و تشخیص قطعی نمی‌دهد؛ برونکوسکوپی تهاجمی است و فقط وقتی جا دارد که اسمیرها منفی و شک بالینی بالا باشد؛ اسپیرومتری هیچ ربطی به این تابلو ندارد.",
 "This question is repeated eight times in this chapter, so learn the pattern once: A COUGH OF MORE THAN TWO WEEKS THAT HAS NOT RESPONDED TO ORDINARY ANTIBIOTICS — and the answer is almost always THREE SPUTUM SMEARS for acid-fast bacilli.\n\nWHY THREE? A single smear has a sensitivity of only about 50-60%, but three specimens raise the cumulative sensitivity to 80-90%. The MORNING specimen is best, because secretions pool overnight.\n\nWARNING, WHY DOES THE SMEAR TAKE PRIORITY OVER MORE EXPENSIVE OPTIONS? Three reasons:\n1. CHEAP, FAST AND AVAILABLE — a result the same day\n2. A positive smear means the patient is INFECTIOUS — an urgent PUBLIC HEALTH decision\n3. It establishes the diagnosis so treatment can start at once\n\nAND NOW THIS PATIENT'S CLUES, all pointing to tuberculosis:\n- HOMELESS -> a strong epidemiological risk factor\n- CACHECTIC -> weight loss, a cardinal feature\n- FAILED AZITHROMYCIN AND CO-AMOXICLAV -> not an ordinary bacterium\n- WARNING, CAVITARY INFILTRATION IN THE UPPER LOBES -> nearly diagnostic of POST-PRIMARY tuberculosis\n\nWHY DOES TB FAVOUR THE APEX? Because OXYGEN TENSION IS HIGHEST there and M. tuberculosis is an OBLIGATE AEROBE. That single fact explains both the location of post-primary disease and why it cavitates.\n\nWHY NOT THE OTHERS? CT is expensive and not diagnostic; bronchoscopy is invasive and belongs only where smears are negative with high suspicion; spirometry has no bearing on this picture.",
 ["سی‌تی‌اسکن ریه گران است، تشخیص قطعی نمی‌دهد و تصمیم ایزولاسیون را ممکن نمی‌کند.",
  "اسپیرومتری برای بیماری انسدادی راه هوایی است و در این تابلو جایی ندارد.",
  "برونکوسکوپی و بیوپسی تهاجمی است و فقط وقتی جا دارد که سه اسمیر منفی و شک بالا باشد.",
  "پاسخ صحیح — اسمیر خلط از نظر باسیل اسیدفاست، ارزان، سریع و تعیین‌کننده‌ی مسری بودن بیمار است."],
 ["A chest CT is expensive, not diagnostic, and does not enable the isolation decision.",
  "Spirometry is for obstructive airway disease and has no place in this picture.",
  "Bronchoscopy with biopsy is invasive and belongs only where three smears are negative with high suspicion.",
  "Correct — the sputum smear for acid-fast bacilli is cheap, fast, and determines whether the patient is infectious."],
 "سرفه >۲ هفته + شکست آنتی‌بیوتیک ← **سه اسمیر خلط**. کاویته‌ی قله = سل ثانویه (مایکوباکتریوم هوازی اجباری).",
 "Cough >2 weeks + failed antibiotics -> THREE SPUTUM SMEARS. Apical cavitation = post-primary TB (an obligate aerobe).",
 [H, NTP])


# ---------------------------------------------------------------- idx 224
add("book:224", "case", "medium",
 "اسمیر سه‌بار منفی با شک بالا ← **یک دوره آنتی‌بیوتیک غیرسلی، سپس تکرار اسمیر**.",
 "Three negative smears with high suspicion -> A COURSE OF NON-TB ANTIBIOTICS, THEN REPEAT THE SMEARS.",
 [
  "این سؤال الگوریتم **سل ریوی اسمیر منفی** دستورالعمل کشوری را می‌آزماید.",
  "بیمار همه‌ی سرنخ‌های سل را دارد ولی **هر سه اسمیر منفی** است — یک وضعیت شایع و مهم.",
  "⚠️ نخست بدانید چرا اسمیر منفی می‌شود، حتی وقتی بیمار واقعاً سل دارد.",
  "دلیل بنیادی: اسمیر برای مثبت شدن به **۵۰۰۰ تا ۱۰۰۰۰ باسیل در هر میلی‌لیتر** خلط نیاز دارد.",
  "این آستانه بالاست؛ بیماری با بار باکتریایی کمتر، اسمیر منفی می‌دهد.",
  "پس **اسمیر منفی، سل را رد نمی‌کند** — حدود **۳۰ تا ۵۰ درصد** موارد سل ریوی اسمیر منفی‌اند.",
  "⚠️ حالا الگوریتم دستورالعمل کشوری، که کلید سؤال بر آن بنا شده:",
  "**قدم یک**: سه اسمیر خلط. اگر مثبت ← درمان سل.",
  "**قدم دو**: اگر هر سه منفی ← **یک دوره آنتی‌بیوتیک وسیع‌الطیف غیرسلی** (۱۰ تا ۱۴ روز).",
  "⚠️ نکته‌ی مهم: این آنتی‌بیوتیک نباید **فلوروکینولون** باشد.",
  "چرا؟ چون کینولون‌ها **ضدسل هم هستند** و بیماری را موقتاً بهتر می‌کنند، تشخیص را می‌پوشانند و مقاومت می‌سازند.",
  "**قدم سه**: اگر بیمار بهتر شد ← پنومونی باکتریال بوده، تمام.",
  "**قدم چهار**: اگر بهتر نشد ← **تکرار اسمیرها**، و در صورت لزوم رادیوگرافی، کشت و برونکوسکوپی.",
  "منطق این الگوریتم چیست؟ **رد کردن ارزان‌ترین و شایع‌ترین تشخیص جایگزین**، پیش از رفتن سراغ کارهای گران.",
  "و مهم‌تر: جلوگیری از درمان **بی‌مورد** شش‌ماهه‌ی سل در کسی که پنومونی ساده داشته.",
  "⚠️ چرا «درمان تجربی سل» پاسخ نیست؟ چون هنوز جایگزین ارزان و شایع رد نشده است.",
 ],
 [
  "This question tests the national programme's algorithm for SMEAR-NEGATIVE PULMONARY TUBERCULOSIS.",
  "The patient has every clue for tuberculosis, yet ALL THREE SMEARS ARE NEGATIVE — a common and important situation.",
  "WARNING, first understand why a smear turns negative even in genuine tuberculosis.",
  "The fundamental reason: a smear needs 5,000-10,000 BACILLI PER MILLILITRE of sputum to turn positive.",
  "That threshold is high; disease with a lower bacterial load gives a negative smear.",
  "So A NEGATIVE SMEAR DOES NOT EXCLUDE TUBERCULOSIS — about 30-50% of pulmonary cases are smear-negative.",
  "WARNING, now the national algorithm on which the key rests:",
  "STEP ONE: three sputum smears. If positive -> treat for tuberculosis.",
  "STEP TWO: if all three are negative -> A COURSE OF BROAD-SPECTRUM NON-TB ANTIBIOTICS (10-14 days).",
  "WARNING, an important point: that antibiotic must NOT be a FLUOROQUINOLONE.",
  "Why? Quinolones ARE ALSO ANTI-TUBERCULOUS: they improve the illness temporarily, mask the diagnosis and breed resistance.",
  "STEP THREE: if the patient improves -> it was bacterial pneumonia; done.",
  "STEP FOUR: if not -> REPEAT THE SMEARS, and if needed radiography, culture and bronchoscopy.",
  "What is the logic? EXCLUDE THE CHEAPEST AND COMMONEST ALTERNATIVE first, before expensive investigation.",
  "And more importantly: avoid an unnecessary SIX-MONTH tuberculosis regimen in someone who had simple pneumonia.",
  "WARNING, why is 'empirical TB treatment' not the answer? Because the cheap, common alternative has not yet been excluded.",
 ],
 "این سؤال الگوریتم **سل ریوی اسمیر منفی** دستورالعمل کشوری را می‌آزماید — وضعیتی که در عمل بسیار شایع است.\n\nبیمار همه‌ی سرنخ‌های سل را دارد (سابقه‌ی زندان، تب، کاهش وزن، کدورت در قسمت فوقانی ریه) ولی **هر سه اسمیر منفی** است.\n\n⚠️ **نخست: چرا اسمیر منفی می‌شود، حتی وقتی بیمار واقعاً سل دارد؟**\n\nاسمیر برای مثبت شدن به **۵۰۰۰ تا ۱۰۰۰۰ باسیل در هر میلی‌لیتر** خلط نیاز دارد. این آستانه‌ی بالایی است، و بیماری با بار باکتریایی کمتر اسمیر منفی می‌دهد. به همین دلیل **اسمیر منفی سل را رد نمی‌کند** — حدود **۳۰ تا ۵۰ درصد** موارد سل ریوی اسمیر منفی‌اند.\n\n⚠️ **حالا الگوریتم، که کلید سؤال بر آن بنا شده:**\n\n۱. **سه اسمیر خلط** ← اگر مثبت، درمان سل\n۲. اگر هر سه منفی ← **یک دوره آنتی‌بیوتیک وسیع‌الطیف غیرسلی** (۱۰ تا ۱۴ روز)\n۳. اگر بیمار بهتر شد ← پنومونی باکتریال بوده، تمام\n۴. اگر بهتر نشد ← **تکرار اسمیرها**، و سپس کشت، رادیوگرافی و در صورت لزوم برونکوسکوپی\n\n**منطق این الگوریتم:** رد کردن **ارزان‌ترین و شایع‌ترین تشخیص جایگزین** پیش از رفتن سراغ کارهای گران — و مهم‌تر، جلوگیری از تحمیل یک درمان **بی‌مورد شش‌ماهه‌ی سل** به کسی که فقط پنومونی داشته.\n\n⚠️ **و یک هشدار حیاتی:** آنتی‌بیوتیکی که در قدم دوم می‌دهیم **نباید فلوروکینولون** باشد. چون کینولون‌ها **خودشان ضدسل‌اند**: بیمار موقتاً بهتر می‌شود، تشخیص پوشانده می‌شود، و بدتر از همه، مواجهه‌ی تک‌دارویی **مقاومت** می‌سازد.",
 "This question tests the national algorithm for SMEAR-NEGATIVE PULMONARY TUBERCULOSIS — a very common situation in practice.\n\nThe patient has every clue for tuberculosis (prison history, fever, weight loss, upper-zone opacity) yet ALL THREE SMEARS ARE NEGATIVE.\n\nWARNING, FIRST: WHY DOES A SMEAR TURN NEGATIVE EVEN IN GENUINE TUBERCULOSIS?\n\nA smear needs 5,000-10,000 BACILLI PER MILLILITRE of sputum to turn positive. That is a high threshold, and disease with a lower bacterial load gives a negative smear. This is why A NEGATIVE SMEAR DOES NOT EXCLUDE TUBERCULOSIS — about 30-50% of pulmonary cases are smear-negative.\n\nWARNING, NOW THE ALGORITHM ON WHICH THE KEY RESTS:\n\n1. THREE SPUTUM SMEARS -> if positive, treat for tuberculosis\n2. If all three are negative -> A COURSE OF BROAD-SPECTRUM NON-TB ANTIBIOTICS (10-14 days)\n3. If the patient improves -> it was bacterial pneumonia; done\n4. If not -> REPEAT THE SMEARS, then culture, radiography and bronchoscopy if needed\n\nTHE LOGIC: exclude the CHEAPEST AND COMMONEST ALTERNATIVE before expensive investigation — and, more importantly, avoid imposing an unnecessary SIX-MONTH tuberculosis regimen on someone who merely had pneumonia.\n\nWARNING, A VITAL CAUTION: the antibiotic given at step two must NOT be a FLUOROQUINOLONE. Quinolones ARE THEMSELVES ANTI-TUBERCULOUS: the patient improves temporarily, the diagnosis is masked, and worst of all, monotherapy exposure BREEDS RESISTANCE.",
 ["درمان به‌عنوان پنومونی و تکرار **رادیوگرافی** ناقص است؛ آنچه باید تکرار شود اسمیر است، نه فقط عکس.",
  "شروع درمان تجربی سل پیش از رد کردن پنومونی، ممکن است شش ماه درمان بی‌مورد تحمیل کند.",
  "پاسخ صحیح — یک دوره درمان پنومونی اکتسابی از جامعه و سپس تکرار اسمیر، همان الگوریتم کشوری است.",
  "CT اسکن و تست توبرکولین هیچ‌کدام تشخیص سل فعال را قطعی نمی‌کنند و قدم بعدی نیستند."],
 ["Treating as pneumonia and repeating the RADIOGRAPH is incomplete; what must be repeated is the smear.",
  "Starting empirical TB treatment before excluding pneumonia may impose six needless months of therapy.",
  "Correct — a course of community-acquired pneumonia treatment then repeat smears is the national algorithm.",
  "Neither CT nor a tuberculin test establishes active tuberculosis, and neither is the next step."],
 "اسمیر منفی سل را **رد نمی‌کند** (آستانه ۵۰۰۰–۱۰۰۰۰ باسیل/mL). الگوریتم: آنتی‌بیوتیک غیرکینولون ← **تکرار اسمیر**.",
 "A negative smear DOES NOT EXCLUDE TB (threshold 5,000-10,000 bacilli/mL). Algorithm: non-quinolone antibiotic -> REPEAT SMEARS.",
 [H, NTP, WHO])


# ---------------------------------------------------------------- idx 235
add("book:235", "case", "easy",
 "آرتریت نقرسی حاد در درمان سل = **پیرازینامید** (مهار دفع کلیوی اسید اوریک).",
 "Acute gouty arthritis during TB treatment means PYRAZINAMIDE (it blocks renal uric-acid excretion).",
 TOX_FA + [
  "این بیمار سه هفته پس از شروع رژیم چهاردارویی، **درد و تورم ناگهانی شست پا** پیدا کرده.",
  "و **اسید اوریک بالاست** — تابلوی کلاسیک **آرتریت نقرسی حاد**.",
  "درگیری اولین مفصل متاتارسوفالانژیال نام خاصی دارد: **پودگرا (podagra)**.",
  "⚠️ مقصر: **پیرازینامید**، و سازوکارش دقیق و قابل‌فهم است.",
  "پیرازینامید در بدن به **اسید پیرازینوئیک** متابولیزه می‌شود.",
  "این متابولیت **بازجذب توبولی اورات را زیاد و دفع آن را مهار می‌کند**.",
  "نتیجه: اسید اوریک سرم بالا می‌رود و در مفاصل کریستال می‌سازد.",
  "⚠️ نکته‌ی بالینی مهم: **هیپراوریسمی بدون علامت** با پیرازینامید بسیار شایع است.",
  "و هیپراوریسمی بدون علامت **درمان نمی‌خواهد و دلیل قطع دارو نیست**.",
  "اما **آرتریت نقرسی علامت‌دار** فرق دارد: نیاز به درمان علامتی دارد.",
  "درمان: **NSAID** برای حمله، و در موارد شدید یا مکرر، تعویض پیرازینامید.",
  "⚠️ آلوپورینول در نقرس پیرازینامیدی **کمتر مؤثر** است، چون مکانیسم **دفعی** است نه تولیدی.",
  "پیرازینامید فقط در **دو ماه اول** رژیم است، پس مشکل معمولاً خودمحدودشونده می‌شود.",
 ],
 TOX_EN + [
  "Three weeks after starting the four-drug regimen this patient developed SUDDEN PAIN AND SWELLING OF THE GREAT TOE.",
  "And the URIC ACID IS RAISED — the classic picture of ACUTE GOUTY ARTHRITIS.",
  "Involvement of the first metatarsophalangeal joint has its own name: PODAGRA.",
  "WARNING, the culprit is PYRAZINAMIDE, and its mechanism is precise and understandable.",
  "Pyrazinamide is metabolised to PYRAZINOIC ACID.",
  "That metabolite INCREASES TUBULAR REABSORPTION OF URATE AND INHIBITS ITS EXCRETION.",
  "The result: serum uric acid rises and crystallises in the joints.",
  "WARNING, an important clinical point: ASYMPTOMATIC HYPERURICAEMIA with pyrazinamide is very common.",
  "And asymptomatic hyperuricaemia NEEDS NO TREATMENT and is NOT a reason to stop the drug.",
  "SYMPTOMATIC GOUTY ARTHRITIS is different: it needs symptomatic treatment.",
  "Treatment: an NSAID for the attack, and in severe or recurrent cases, replacing the pyrazinamide.",
  "WARNING: allopurinol is LESS EFFECTIVE in pyrazinamide gout, because the mechanism is EXCRETORY rather than overproduction.",
  "Pyrazinamide is given only in the FIRST TWO MONTHS, so the problem is usually self-limiting.",
 ],
 "این بیمار سه هفته پس از شروع رژیم چهاردارویی ضدسل، دچار **درد و تورم و قرمزی ناگهانی شست پا** شده و **اسید اوریکش بالاست** — تابلوی کلاسیک **آرتریت نقرسی حاد**. (درگیری اولین مفصل متاتارسوفالانژیال نام خاصی دارد: **پودگرا**.)\n\n⚠️ **مقصر پیرازینامید است، و سازوکارش دقیقاً قابل توضیح است:**\n\nپیرازینامید در بدن به **اسید پیرازینوئیک** متابولیزه می‌شود، و این متابولیت **بازجذب توبولی اورات را افزایش و دفع کلیوی آن را مهار می‌کند**. نتیجه: اسید اوریک سرم بالا می‌رود و در مفاصل کریستال می‌سازد.\n\n**دو نکته‌ی بالینی که باید از هم تفکیک شوند:**\n\n• ⚠️ **هیپراوریسمی بدون علامت** با پیرازینامید **بسیار شایع** است — و **درمان نمی‌خواهد و دلیل قطع دارو نیست**.\n• **آرتریت نقرسی علامت‌دار** فرق دارد: **NSAID** برای حمله، و در موارد شدید یا مکرر، تعویض پیرازینامید.\n\n⚠️ و یک نکته‌ی ظریف دارویی: **آلوپورینول در نقرس پیرازینامیدی کمتر مؤثر است**، چون آلوپورینول **تولید** اسید اوریک را کم می‌کند، در حالی که مشکل اینجا **اختلال دفع** است.\n\nخبر خوب اینکه پیرازینامید فقط در **دو ماه اول** رژیم داده می‌شود، پس مشکل معمولاً خودمحدودشونده است.\n\n**جفت‌های دارو-عارضه را با هم حفظ کنید:** ایزونیازید ← نوروپاتی؛ ریفامپین ← رنگ نارنجی و ترومبوسیتوپنی؛ **پیرازینامید ← نقرس**؛ اتامبوتول ← نوریت اپتیک.",
 "Three weeks after starting the four-drug regimen this patient developed SUDDEN PAIN, SWELLING AND REDNESS OF THE GREAT TOE with a RAISED URIC ACID — the classic picture of ACUTE GOUTY ARTHRITIS. (Involvement of the first metatarsophalangeal joint has its own name: PODAGRA.)\n\nWARNING, THE CULPRIT IS PYRAZINAMIDE, AND ITS MECHANISM IS PRECISELY EXPLICABLE:\n\nPyrazinamide is metabolised to PYRAZINOIC ACID, and that metabolite INCREASES TUBULAR REABSORPTION OF URATE AND INHIBITS ITS RENAL EXCRETION. Serum uric acid rises and crystallises in the joints.\n\nTWO CLINICAL POINTS THAT MUST BE KEPT APART:\n\n- WARNING: ASYMPTOMATIC HYPERURICAEMIA with pyrazinamide is VERY COMMON — and NEEDS NO TREATMENT and is NOT a reason to stop the drug.\n- SYMPTOMATIC GOUTY ARTHRITIS is different: an NSAID for the attack, and in severe or recurrent cases, replacing the pyrazinamide.\n\nWARNING, a fine pharmacological point: ALLOPURINOL IS LESS EFFECTIVE in pyrazinamide gout, because allopurinol reduces uric acid PRODUCTION, whereas the problem here is IMPAIRED EXCRETION.\n\nThe good news is that pyrazinamide is given only in the FIRST TWO MONTHS, so the problem is usually self-limiting.\n\nMEMORISE THE DRUG-TOXICITY PAIRS TOGETHER: isoniazid -> neuropathy; rifampicin -> orange secretions and thrombocytopenia; PYRAZINAMIDE -> GOUT; ethambutol -> optic neuritis.",
 ["ایزونیازید نوروپاتی محیطی و هپاتیت می‌دهد، نه هیپراوریسمی و نقرس.",
  "پاسخ صحیح — متابولیت پیرازینامید دفع کلیوی اسید اوریک را مهار می‌کند و آرتریت نقرسی می‌سازد.",
  "اتامبوتول عارضه‌ی امضایی‌اش نوریت اپتیک است، نه نقرس.",
  "ریفامپین رنگ نارنجی ترشحات، ترومبوسیتوپنی و القای P450 می‌دهد، نه هیپراوریسمی."],
 ["Isoniazid causes peripheral neuropathy and hepatitis, not hyperuricaemia and gout.",
  "Correct — a pyrazinamide metabolite inhibits renal uric-acid excretion and produces gouty arthritis.",
  "Ethambutol's signature toxicity is optic neuritis, not gout.",
  "Rifampicin causes orange secretions, thrombocytopenia and P450 induction, not hyperuricaemia."],
 "**پیرازینامید ← نقرس.** ایزونیازید ← نوروپاتی. ریفامپین ← ترومبوسیتوپنی و P450. اتامبوتول ← نوریت اپتیک.",
 "PYRAZINAMIDE -> GOUT. Isoniazid -> neuropathy. Rifampicin -> thrombocytopenia and P450. Ethambutol -> optic neuritis.",
 [H, ATS])


# ---------------------------------------------------------------- idx 252
add("book:252", "case", "medium",
 "ترومبوسیتوپنی و پورپورا در درمان سل = **ریفامپین** ← و **قطع دائمی** لازم است.",
 "Thrombocytopenia and purpura during TB treatment means RIFAMPICIN — and it must be stopped PERMANENTLY.",
 TOX_FA + [
  "این بیمار یک هفته پس از شروع درمان، **راش پتشیال منتشر و ترومبوسیتوپنی** پیدا کرده.",
  "⚠️ مقصر **ریفامپین** است، و سازوکارش **ایمونولوژیک** است نه سمیت مستقیم.",
  "ریفامپین به‌عنوان **هاپتن** روی سطح پلاکت می‌نشیند.",
  "بدن **آنتی‌بادی ضدریفامپین** می‌سازد، و آن آنتی‌بادی به کمپلکس دارو-پلاکت می‌چسبد.",
  "پلاکت‌های پوشیده‌شده در **طحال** برداشته می‌شوند: ترومبوسیتوپنی ایمنی.",
  "⚠️ و پیامد حیاتی این سازوکار: **مواجهه‌ی مجدد، واکنش را شدیدتر می‌کند**.",
  "چون آنتی‌بادی از قبل ساخته شده، دوز بعدی می‌تواند افت پلاکت **سریع و شدید** بدهد.",
  "پس ریفامپین در این بیمار **برای همیشه** کنار گذاشته می‌شود — نه موقتاً.",
  "همین منطق برای سایر واکنش‌های ایمنی ریفامپین هم صادق است.",
  "آن واکنش‌ها: **نفریت بینابینی حاد**، **همولیز**، **شوک**، و **سندرم شبه‌آنفلوانزا**.",
  "⚠️ حالا این را با **هپاتیت ایزونیازید** مقایسه کنید — تفاوت بنیادی است.",
  "هپاتیت ایزونیازید یک واکنش **متابولیک وابسته به دوز** است، نه ایمنی.",
  "پس پس از نرمال شدن آنزیم‌ها، ایزونیازید را می‌توان **با احتیاط دوباره شروع کرد**.",
  "قاعده‌ی کلی: واکنش **ایمونولوژیک** ← قطع دائمی؛ واکنش **متابولیک** ← امکان شروع مجدد.",
  "رژیم جایگزین بدون ریفامپین طولانی‌تر است، چون ریفامپین **قوی‌ترین داروی استریل‌کننده** است.",
 ],
 TOX_EN + [
  "One week after starting treatment this patient developed a GENERALISED PETECHIAL RASH AND THROMBOCYTOPENIA.",
  "WARNING, the culprit is RIFAMPICIN, and the mechanism is IMMUNOLOGICAL rather than direct toxicity.",
  "Rifampicin acts as a HAPTEN, binding to the platelet surface.",
  "The body makes ANTI-RIFAMPICIN ANTIBODY, which binds the drug-platelet complex.",
  "The coated platelets are removed in the SPLEEN: immune thrombocytopenia.",
  "WARNING, and the crucial consequence of that mechanism: RE-EXPOSURE MAKES THE REACTION WORSE.",
  "Because the antibody already exists, the next dose can cause a RAPID AND SEVERE platelet fall.",
  "So rifampicin is abandoned PERMANENTLY in this patient, not temporarily.",
  "The same logic applies to rifampicin's other immune reactions.",
  "Those are: ACUTE INTERSTITIAL NEPHRITIS, HAEMOLYSIS, SHOCK and a FLU-LIKE SYNDROME.",
  "WARNING, now compare this with ISONIAZID HEPATITIS — the difference is fundamental.",
  "Isoniazid hepatitis is a DOSE-RELATED METABOLIC reaction, not an immune one.",
  "So once the enzymes normalise, isoniazid CAN BE CAUTIOUSLY REINTRODUCED.",
  "The general rule: an IMMUNOLOGICAL reaction -> permanent withdrawal; a METABOLIC one -> reintroduction is possible.",
  "A rifampicin-free regimen must run longer, because rifampicin is THE MOST POTENT STERILISING DRUG.",
 ],
 "این بیمار یک هفته پس از شروع درمان ضدسل، دچار **راش پتشیال منتشر و ترومبوسیتوپنی** شده است. ⚠️ مقصر **ریفامپین** است — و فهمیدن **سازوکار** آن، پاسخ سؤالات بعدی این بلوک را هم می‌دهد.\n\n**سازوکار ایمونولوژیک است، نه سمیت مستقیم:**\n\nریفامپین به‌عنوان **هاپتن** روی سطح پلاکت می‌نشیند → بدن **آنتی‌بادی ضدریفامپین** می‌سازد → آنتی‌بادی به کمپلکس دارو-پلاکت می‌چسبد → پلاکت‌های پوشیده‌شده در **طحال** برداشته می‌شوند.\n\n⚠️ **و حالا مهم‌ترین پیامد بالینی این سازوکار: مواجهه‌ی مجدد واکنش را شدیدتر می‌کند.**\n\nچون آنتی‌بادی از قبل ساخته شده، دوز بعدی می‌تواند افت پلاکت **سریع‌تر و شدیدتری** بدهد. به همین دلیل ریفامپین در این بیمار **برای همیشه** کنار گذاشته می‌شود، نه موقتاً.\n\nهمین منطق برای سایر واکنش‌های ایمنی ریفامپین هم صادق است: **نفریت بینابینی حاد، همولیز، شوک، و سندرم شبه‌آنفلوانزا** — همه دلیل قطع دائمی‌اند.\n\n⚠️ **و حالا یک مقایسه‌ی بنیادی که ارزش حفظ کردن دارد:**\n\n• واکنش **ایمونولوژیک** (ترومبوسیتوپنی ریفامپین، نفریت بینابینی) ← **قطع دائمی**، شروع مجدد ممنوع\n• واکنش **متابولیک و وابسته به دوز** (هپاتیت ایزونیازید) ← پس از نرمال شدن آنزیم‌ها، **شروع مجدد با احتیاط ممکن است**\n\nو یک پیامد عملی: رژیم بدون ریفامپین باید **طولانی‌تر** باشد، چون ریفامپین **قوی‌ترین داروی استریل‌کننده** در رژیم است و حذفش مدت درمان را افزایش می‌دهد.",
 "One week after starting antituberculous treatment this patient developed a GENERALISED PETECHIAL RASH AND THROMBOCYTOPENIA. WARNING, the culprit is RIFAMPICIN — and understanding the MECHANISM also answers the rest of this block.\n\nTHE MECHANISM IS IMMUNOLOGICAL, NOT DIRECT TOXICITY:\n\nRifampicin acts as a HAPTEN on the platelet surface -> the body makes ANTI-RIFAMPICIN ANTIBODY -> the antibody binds the drug-platelet complex -> the coated platelets are removed in the SPLEEN.\n\nWARNING, AND THE KEY CLINICAL CONSEQUENCE: RE-EXPOSURE MAKES THE REACTION WORSE.\n\nBecause the antibody already exists, the next dose can produce a FASTER AND MORE SEVERE platelet fall. Rifampicin is therefore abandoned PERMANENTLY in this patient, not temporarily.\n\nThe same logic covers rifampicin's other immune reactions: ACUTE INTERSTITIAL NEPHRITIS, HAEMOLYSIS, SHOCK and a FLU-LIKE SYNDROME — all reasons for permanent withdrawal.\n\nWARNING, AND NOW A FUNDAMENTAL COMPARISON WORTH MEMORISING:\n\n- IMMUNOLOGICAL reactions (rifampicin thrombocytopenia, nephritis) -> PERMANENT WITHDRAWAL\n- METABOLIC, DOSE-RELATED reactions (isoniazid hepatitis) -> cautious reintroduction once enzymes normalise\n\nAnd a practical consequence: a rifampicin-free regimen must run LONGER, because rifampicin is THE MOST POTENT STERILISING DRUG in the regimen and removing it lengthens treatment.",
 ["پاسخ صحیح — ریفامپین از راه ایمنی (هاپتن + آنتی‌بادی) ترومبوسیتوپنی می‌دهد و باید دائمی قطع شود.",
  "اتامبوتول نوریت اپتیک می‌دهد، نه ترومبوسیتوپنی ایمنی.",
  "ایزونیازید نوروپاتی محیطی و هپاتیت می‌دهد؛ ترومبوسیتوپنی از عوارض شاخص آن نیست.",
  "پیرازینامید هیپراوریسمی و هپاتوتوکسیسیتی می‌دهد، نه پورپورای ترومبوسیتوپنیک."],
 ["Correct — rifampicin causes immune thrombocytopenia (hapten plus antibody) and must be stopped permanently.",
  "Ethambutol causes optic neuritis, not immune thrombocytopenia.",
  "Isoniazid causes peripheral neuropathy and hepatitis; thrombocytopenia is not one of its hallmarks.",
  "Pyrazinamide causes hyperuricaemia and hepatotoxicity, not thrombocytopenic purpura."],
 "ترومبوسیتوپنی/نفریت/همولیز = **ریفامپین** ← **قطع دائمی** (ایمونولوژیک). هپاتیت ایزونیازید ← متابولیک، شروع مجدد ممکن.",
 "Thrombocytopenia/nephritis/haemolysis = RIFAMPICIN -> PERMANENT withdrawal (immunological). Isoniazid hepatitis is metabolic; reintroduction is possible.",
 [H, ATS])


# ---------------------------------------------------------------- idx 244
add("book:244", "case", "hard",
 "آنزیم کبدی **بیش از ۵ برابر** (یا **۳ برابر با علامت/زردی**) ← **قطع همه‌ی داروهای هپاتوتوکسیک**.",
 "Enzymes above FIVE times normal — or THREE times WITH symptoms or jaundice — mean STOPPING all hepatotoxic drugs.",
 [
  "هپاتوتوکسیسیتی شایع‌ترین عارضه‌ی جدی درمان سل است، و **دو آستانه‌ی عددی** دارد.",
  "⚠️ **آستانه‌ی یک — بیمار بدون علامت**: قطع وقتی ALT/AST به **۵ برابر حد بالای نرمال** برسد.",
  "⚠️ **آستانه‌ی دو — بیمار علامت‌دار یا با زردی**: قطع در **۳ برابر** حد بالای نرمال.",
  "و یک قاعده‌ی مستقل: **هر افزایش بیلی‌روبین**، صرف‌نظر از آنزیم‌ها، دلیل قطع است.",
  "چرا آستانه‌ی بیمار علامت‌دار پایین‌تر است؟ چون **علامت نشانه‌ی آسیب واقعی سلولی** است، نه سازگاری.",
  "⚠️ نکته‌ی مهم: افزایش خفیف و **بدون علامت** آنزیم‌ها بسیار شایع است.",
  "تا **۲۰ درصد** بیماران افزایش گذرای آنزیم دارند که خودبه‌خود برمی‌گردد — به آن **سازگاری کبدی** می‌گویند.",
  "قطع بی‌مورد دارو در این حالت، خطر **شکست درمان و مقاومت** را زیاد می‌کند.",
  "حالا این بیمار: **زردی**، **تهوع**، بیلی‌روبین **۳**، و آنزیم‌ها حدود **۶ تا ۷ برابر** نرمال.",
  "هم آستانه‌ی علامت‌دار رد شده، هم آستانه‌ی بدون علامت، و هم بیلی‌روبین بالا رفته.",
  "پس **همه‌ی داروهای هپاتوتوکسیک قطع می‌شوند**: ایزونیازید، ریفامپین، پیرازینامید.",
  "⚠️ و **اتامبوتول می‌تواند بماند**، چون تنها داروی خط اول **غیرهپاتوتوکسیک** است.",
  "اگر بیمار بدحال یا شدیداً مسری باشد، رژیم موقت **اتامبوتول + کینولون + آمینوگلیکوزید** داده می‌شود.",
  "**شروع مجدد** پس از نرمال شدن آنزیم‌ها، **یکی‌یکی** و با فاصله انجام می‌شود.",
  "ترتیب معمول: اول **ریفامپین** (کم‌خطرترینِ سه‌تا)، سپس **ایزونیازید**، و در آخر **پیرازینامید**.",
  "⚠️ و اگر پیرازینامید مقصر بوده، معمولاً **دیگر برنمی‌گردد** و رژیم به ۹ ماه تمدید می‌شود.",
 ],
 [
  "Hepatotoxicity is the commonest serious adverse effect of TB treatment, and it has TWO NUMERICAL THRESHOLDS.",
  "WARNING, THRESHOLD ONE — an ASYMPTOMATIC patient: stop when ALT/AST reaches FIVE TIMES the upper limit of normal.",
  "WARNING, THRESHOLD TWO — a SYMPTOMATIC or JAUNDICED patient: stop at THREE TIMES the upper limit.",
  "And an independent rule: ANY RISE IN BILIRUBIN, whatever the enzymes, is a reason to stop.",
  "Why is the symptomatic threshold lower? Because SYMPTOMS INDICATE REAL CELLULAR INJURY rather than adaptation.",
  "WARNING, an important point: a mild, ASYMPTOMATIC enzyme rise is very common.",
  "Up to 20% of patients have a transient rise that settles on its own — this is called HEPATIC ADAPTATION.",
  "Stopping the drugs needlessly in that situation increases the risk of TREATMENT FAILURE AND RESISTANCE.",
  "Now this patient: JAUNDICE, NAUSEA, a bilirubin of 3, and enzymes about SIX TO SEVEN times normal.",
  "The symptomatic threshold is crossed, the asymptomatic one too, and the bilirubin has risen.",
  "So ALL HEPATOTOXIC DRUGS ARE STOPPED: isoniazid, rifampicin and pyrazinamide.",
  "WARNING, and ETHAMBUTOL MAY BE CONTINUED, as the only NON-HEPATOTOXIC first-line drug.",
  "If the patient is unwell or highly infectious, a temporary regimen of ETHAMBUTOL + QUINOLONE + AMINOGLYCOSIDE is used.",
  "REINTRODUCTION, once the enzymes normalise, is done ONE DRUG AT A TIME with intervals.",
  "The usual order: RIFAMPICIN first (the least risky of the three), then ISONIAZID, and PYRAZINAMIDE last.",
  "WARNING: if pyrazinamide was the culprit it is usually NOT reintroduced, and the regimen is extended to 9 months.",
 ],
 "هپاتوتوکسیسیتی شایع‌ترین عارضه‌ی جدی درمان سل است، و مدیریتش بر **دو آستانه‌ی عددی** استوار است که باید دقیقاً حفظ شوند:\n\n⚠️ • **بیمار بدون علامت** ← قطع وقتی ALT/AST به **۵ برابر** حد بالای نرمال برسد\n⚠️ • **بیمار علامت‌دار یا با زردی** ← قطع در **۳ برابر** حد بالای نرمال\n• **هر افزایش بیلی‌روبین** ← صرف‌نظر از آنزیم‌ها، دلیل قطع است\n\n**چرا آستانه‌ی بیمار علامت‌دار پایین‌تر است؟** چون وجود علامت نشان می‌دهد آسیب **واقعی سلولی** است، نه صرفاً سازگاری کبد.\n\n⚠️ **و نکته‌ی معکوس که به‌اندازه‌ی همین مهم است:** افزایش خفیف و **بدون علامت** آنزیم‌ها بسیار شایع است — تا **۲۰ درصد** بیماران آن را تجربه می‌کنند و خودبه‌خود برمی‌گردد. به این پدیده **سازگاری کبدی** می‌گویند، و **قطع بی‌مورد دارو** در این حالت خطر شکست درمان و مقاومت را زیاد می‌کند.\n\n**حالا این بیمار:**\n• **زردی** ✓ • **تهوع** ✓ • **بیلی‌روبین ۳** ✓ • آنزیم‌ها حدود **۶ تا ۷ برابر** نرمال ✓\n\nهر سه معیار قطع رد شده‌اند. پس **همه‌ی داروهای هپاتوتوکسیک قطع می‌شوند**: ایزونیازید، ریفامپین و پیرازینامید.\n\n⚠️ **و یک نکته‌ی عملی مهم: اتامبوتول می‌تواند بماند**، چون **تنها داروی خط اول است که هپاتوتوکسیک نیست**. اگر بیمار بدحال یا شدیداً مسری باشد، رژیم موقت **اتامبوتول + کینولون + آمینوگلیکوزید** داده می‌شود تا کبد بهبود یابد.\n\n**شروع مجدد** پس از نرمال شدن آنزیم‌ها **یکی‌یکی** و با فاصله انجام می‌شود: اول **ریفامپین**، سپس **ایزونیازید**، و در آخر **پیرازینامید**. ⚠️ و اگر پیرازینامید مقصر بوده، معمولاً دیگر برنمی‌گردد و رژیم به **۹ ماه** تمدید می‌شود.",
 "Hepatotoxicity is the commonest serious adverse effect of TB treatment, and its management rests on TWO NUMERICAL THRESHOLDS that must be memorised precisely:\n\nWARNING:\n- ASYMPTOMATIC patient -> stop when ALT/AST reaches FIVE TIMES the upper limit of normal\n- SYMPTOMATIC or JAUNDICED patient -> stop at THREE TIMES the upper limit\n- ANY RISE IN BILIRUBIN -> a reason to stop, whatever the enzymes\n\nWHY IS THE SYMPTOMATIC THRESHOLD LOWER? Because symptoms indicate REAL CELLULAR INJURY rather than mere hepatic adaptation.\n\nWARNING, AND THE CONVERSE POINT, JUST AS IMPORTANT: a mild ASYMPTOMATIC enzyme rise is very common — up to 20% of patients experience it and it settles spontaneously. This is HEPATIC ADAPTATION, and STOPPING THE DRUGS NEEDLESSLY here increases the risk of treatment failure and resistance.\n\nNOW THIS PATIENT:\n- JAUNDICE (yes) - NAUSEA (yes) - BILIRUBIN 3 (yes) - enzymes about SIX TO SEVEN times normal (yes)\n\nAll three stopping criteria are crossed. So ALL HEPATOTOXIC DRUGS ARE STOPPED: isoniazid, rifampicin and pyrazinamide.\n\nWARNING, AN IMPORTANT PRACTICAL POINT: ETHAMBUTOL MAY BE CONTINUED, as THE ONLY FIRST-LINE DRUG THAT IS NOT HEPATOTOXIC. If the patient is unwell or highly infectious, a temporary regimen of ETHAMBUTOL + QUINOLONE + AMINOGLYCOSIDE is used while the liver recovers.\n\nREINTRODUCTION, once the enzymes normalise, is done ONE DRUG AT A TIME with intervals: RIFAMPICIN first, then ISONIAZID, and PYRAZINAMIDE last. WARNING: if pyrazinamide was the culprit it is usually not reintroduced, and the regimen is extended to NINE MONTHS.",
 ["قطع فقط ایزونیازید و ریفامپین ناقص است؛ پیرازینامید هم هپاتوتوکسیک است و باید قطع شود.",
  "قطع سه دارو «به مدت دو هفته» با زمان دلخواه نادرست است؛ معیار، **نرمال شدن آزمایش‌ها** است نه تقویم.",
  "پاسخ صحیح — با زردی و بیلی‌روبین بالا و آنزیم‌های چند برابر، همه‌ی داروهای هپاتوتوکسیک قطع و پس از نرمال شدن یکی‌یکی شروع می‌شوند.",
  "قطع تنها پیرازینامید کافی نیست؛ ایزونیازید و ریفامپین هم هپاتوتوکسیک‌اند و بیمار زردی دارد."],
 ["Stopping only isoniazid and rifampicin is incomplete; pyrazinamide is hepatotoxic too and must also stop.",
  "Stopping three drugs 'for two weeks' sets an arbitrary time; the criterion is NORMALISATION OF THE TESTS, not the calendar.",
  "Correct — with jaundice, a raised bilirubin and enzymes several times normal, all hepatotoxic drugs stop and are reintroduced one at a time.",
  "Stopping pyrazinamide alone is insufficient; isoniazid and rifampicin are hepatotoxic too and the patient is jaundiced."],
 "قطع: **۵ برابر بدون علامت**، **۳ برابر با علامت/زردی**، یا **هر افزایش بیلی‌روبین**. اتامبوتول (غیرهپاتوتوکسیک) می‌ماند.",
 "Stop at FIVE times if asymptomatic, THREE times if symptomatic or jaundiced, or ANY bilirubin rise. Ethambutol (non-hepatotoxic) may stay.",
 [H, ATS])


# ---------------------------------------------------------------- idx 240
add("book:240", "case", "medium",
 "افزایش **خفیف و بدون علامت** آنزیم کبدی (زیر ۲ برابر) ← **هیچ اقدامی لازم نیست**.",
 "A MILD, ASYMPTOMATIC enzyme rise (under twice normal) needs NO ACTION AT ALL.",
 [
  "این سؤال **آینه‌ی** سؤال هپاتیت شدید است، و با هم باید یاد گرفته شوند.",
  "آنجا آنزیم‌ها چند برابر بود و بیمار زردی داشت؛ اینجا هیچ‌کدام.",
  "این بیمار: **AST برابر ۶۰**، **ALT برابر ۶۲**، و **بدون هیچ علامتی**.",
  "با حد بالای نرمال حدود ۴۰، این یعنی حدود **۱/۵ برابر** — یک افزایش **خفیف**.",
  "⚠️ و افزایش خفیف بدون علامت، شایع‌ترین یافته‌ی آزمایشگاهی درمان سل است.",
  "تا **۲۰ درصد** بیماران آن را تجربه می‌کنند، و در اکثریت **خودبه‌خود برمی‌گردد**.",
  "این پدیده نام دارد: **سازگاری کبدی (hepatic adaptation)**.",
  "سازوکارش القای آنزیمی و تطبیق سلول کبدی با دارو است، نه مرگ سلولی.",
  "⚠️ حالا چرا قطع بی‌مورد **خطرناک** است؟ سه دلیل جدی.",
  "دلیل یک: هر وقفه، خطر **شکست درمان** و برگشت بیماری را زیاد می‌کند.",
  "دلیل دو: مواجهه‌ی ناقص و منقطع، **مقاومت دارویی** می‌سازد — بزرگ‌ترین خطر برنامه‌ی سل.",
  "دلیل سه: بیمار مسری بیشتر مسری می‌ماند و دیگران را آلوده می‌کند.",
  "پس در این بیمار: **درمان بدون تغییر ادامه می‌یابد**.",
  "پیگیری: تکرار آزمایش کبدی، و آموزش بیمار که با بروز **تهوع، استفراغ یا زردی** فوراً مراجعه کند.",
  "⚠️ آموزش بیمار مهم‌تر از خودِ آزمایش است: **علامت زودتر از عدد** خطر را نشان می‌دهد.",
 ],
 [
  "This question is the MIRROR of the severe-hepatitis question, and the two should be learned together.",
  "There the enzymes were several times normal and the patient was jaundiced; here neither is true.",
  "This patient: AST 60, ALT 62, and NO SYMPTOMS AT ALL.",
  "With an upper limit around 40, that is roughly ONE AND A HALF TIMES normal — a MILD rise.",
  "WARNING, and a mild asymptomatic rise is the commonest laboratory finding in TB treatment.",
  "Up to 20% of patients experience it, and in most it RESOLVES SPONTANEOUSLY.",
  "The phenomenon has a name: HEPATIC ADAPTATION.",
  "Its mechanism is enzyme induction and hepatocyte adaptation to the drug, not cell death.",
  "WARNING, now why is needless withdrawal DANGEROUS? Three serious reasons.",
  "Reason one: every interruption increases the risk of TREATMENT FAILURE and relapse.",
  "Reason two: partial, interrupted exposure BREEDS DRUG RESISTANCE — the greatest threat to any TB programme.",
  "Reason three: an infectious patient stays infectious longer and infects others.",
  "So in this patient: TREATMENT CONTINUES UNCHANGED.",
  "Follow-up: repeat the liver tests, and teach the patient to return at once if NAUSEA, VOMITING OR JAUNDICE appear.",
  "WARNING: patient education matters more than the test itself — SYMPTOMS WARN EARLIER THAN NUMBERS.",
 ],
 "این سؤال **آینه‌ی** سؤال هپاتیت شدید است، و ارزشش در این است که دقیقاً همان دانش را از سوی مخالف می‌آزماید. آنجا آنزیم‌ها چند برابر بودند و بیمار زردی داشت؛ اینجا **هیچ‌کدام**.\n\n**وضعیت این بیمار:**\n• **AST برابر ۶۰**، **ALT برابر ۶۲** — با حد بالای نرمال حدود ۴۰، یعنی حدود **۱/۵ برابر**\n• **هیچ علامتی ندارد**\n• **معاینه‌ی فیزیکی نرمال**\n\n⚠️ **و این شایع‌ترین یافته‌ی آزمایشگاهی درمان سل است.** تا **۲۰ درصد** بیماران افزایش خفیف و گذرای آنزیم را تجربه می‌کنند، و در اکثریت قاطع **خودبه‌خود برمی‌گردد**. این پدیده نام دارد: **سازگاری کبدی**. سازوکارش القای آنزیمی و تطبیق سلول کبدی با دارو است، **نه مرگ سلولی**.\n\n**پس چرا قطع بی‌مورد دارو خطرناک است؟** سه دلیل جدی:\n\n۱. هر وقفه، خطر **شکست درمان** و برگشت بیماری را زیاد می‌کند\n۲. ⚠️ مواجهه‌ی ناقص و منقطع، **مقاومت دارویی** می‌سازد — بزرگ‌ترین خطر هر برنامه‌ی کنترل سل\n۳. بیمار مسری، **مدت بیشتری مسری** می‌ماند\n\nپس در این بیمار **درمان بدون هیچ تغییری ادامه می‌یابد**.\n\n**پیگیری چیست؟** تکرار آزمایش کبدی در فاصله‌ی مناسب، و — ⚠️ که از خودِ آزمایش مهم‌تر است — **آموزش بیمار** که به محض بروز **تهوع، استفراغ، بی‌اشتهایی یا زردی** فوراً مراجعه کند. چون **علامت زودتر از عدد** خطر واقعی را نشان می‌دهد.\n\n**دو آستانه را کنار هم نگه دارید:** بدون علامت ← **۵ برابر**؛ با علامت یا زردی ← **۳ برابر**. این بیمار در هیچ‌کدام نیست.",
 "This question is the MIRROR of the severe-hepatitis question, testing the same knowledge from the opposite side. There the enzymes were several times normal and the patient was jaundiced; here NEITHER is true.\n\nTHIS PATIENT:\n- AST 60, ALT 62 — with an upper limit around 40, roughly ONE AND A HALF TIMES normal\n- NO SYMPTOMS\n- NORMAL PHYSICAL EXAMINATION\n\nWARNING, AND THIS IS THE COMMONEST LABORATORY FINDING IN TB TREATMENT. Up to 20% of patients have a mild transient enzyme rise, and in the great majority it RESOLVES SPONTANEOUSLY. The phenomenon is called HEPATIC ADAPTATION, and its mechanism is enzyme induction and hepatocyte adaptation, NOT CELL DEATH.\n\nSO WHY IS NEEDLESS WITHDRAWAL DANGEROUS? Three serious reasons:\n\n1. Every interruption raises the risk of TREATMENT FAILURE and relapse\n2. WARNING: partial, interrupted exposure BREEDS DRUG RESISTANCE — the greatest threat to any TB control programme\n3. An infectious patient STAYS INFECTIOUS LONGER\n\nSo in this patient TREATMENT CONTINUES ENTIRELY UNCHANGED.\n\nWHAT IS THE FOLLOW-UP? Repeat the liver tests at a suitable interval and — WARNING, more important than the test itself — TEACH THE PATIENT to return immediately if NAUSEA, VOMITING, ANOREXIA OR JAUNDICE appear. SYMPTOMS WARN EARLIER THAN NUMBERS.\n\nKEEP THE TWO THRESHOLDS TOGETHER: asymptomatic -> FIVE times; symptomatic or jaundiced -> THREE times. This patient meets neither.",
 ["قطع ریفامپین در افزایش خفیف بدون علامت بی‌مورد است و خطر شکست درمان را زیاد می‌کند.",
  "قطع ریفامپین و ایزونیازید در این سطح از آنزیم‌ها کاملاً بی‌مورد و زیان‌بار است.",
  "پاسخ صحیح — افزایش خفیف بدون علامت، سازگاری کبدی است؛ درمان بدون تغییر ادامه می‌یابد.",
  "افزودن کورتون در هپاتوتوکسیسیتی داروهای سل جایی ندارد و اثبات‌شده نیست."],
 ["Stopping rifampicin for a mild asymptomatic rise is unnecessary and raises the risk of treatment failure.",
  "Stopping both rifampicin and isoniazid at this enzyme level is entirely unwarranted and harmful.",
  "Correct — a mild asymptomatic rise is hepatic adaptation; treatment continues unchanged.",
  "Adding a steroid has no established place in antituberculous drug hepatotoxicity."],
 "افزایش **خفیف بدون علامت** = سازگاری کبدی ← ادامه بده. قطع بی‌مورد = شکست درمان و **مقاومت**.",
 "A MILD ASYMPTOMATIC rise is hepatic adaptation -> continue. Needless withdrawal causes failure and RESISTANCE.",
 [H, ATS])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book17.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 17 lessons:', len(L))
