# -*- coding: utf-8 -*-
"""Numeric repairs for the endocarditis chapter (pages 37-51).

Same glyph-geometry method as the eight earlier chapters: pdfplumber gives the
x coordinate of every character, and a number is always PRINTED left to right
even inside right-to-left Persian text, so sorting the digits of a line by x0
recovers the order the page actually shows. Six repairs in five questions.

WHY THIS CHAPTER MATTERED MORE THAN THE DIGIT COUNT SUGGESTS
------------------------------------------------------------
Endocarditis is the chapter where the examiners COUNT. Nine of its thirty-six
questions ask the student to tally Duke criteria, and a Duke criterion turns on
a threshold: fever counts as a minor criterion only at 38 °C or above. A
mirrored temperature therefore does not merely look untidy, it changes the
tally and so changes the correct option. Two of the repairs below are exactly
that case.

THE UNION-OF-PAGES TRAP, MET AGAIN
-----------------------------------
The first pass checked each suspicious number against the digit runs of ALL the
chapter's pages pooled together, and that pass reported only three defects. It
was wrong in both directions, and the reason is the lesson q9172 taught in the
CNS chapter: a page prints many numbers belonging to many questions, so
"the value appears somewhere in the chapter" proves nothing at all.

Pooling the pages hid the real defects behind coincidences. `83` on page 44 is
genuinely printed — but as part of `38/8`, in the SAME question, which is what
proves the extraction mirrored it. `93` is printed on several pages as the year
93 in an exam citation (پره انترنی شهریور ۹۳), which is how a mirrored `39 °C`
sailed through the pooled check unnoticed.

So the scan was redone PER QUESTION, against the digit runs of that question's
OWN page (plus the following page, because a stem can spill across the page
break, as q9172 did). Every fix below names its page, and main() asserts that
the page really prints the run before writing anything.

THE FIVE QUESTIONS
------------------
q9101  page 39   "BP 80/021" -> "BP 120/80"
       The page prints `120` and `80` as separate runs on the line, in that
       order. `021` is not a blood pressure at all. Note this is the same
       patient whose pulse is 120: the extractor placed the systolic value
       after the slash and mirrored it.

q9113  page 44   "8/83 °c" -> "38/8 °c"   and   "93 °c" -> "39 °c"
       This is a Duke-criteria counting question and both temperatures are
       decisive. Option B is the printed key: a woman with rheumatic heart
       disease, a vegetation on echo, and bilateral chest infiltrates. Her
       fever must clear 38 °C for the minor criterion to count; printed as
       "8/83" it reads as either 8.83 or 883 degrees, neither of which is a
       fever. Option C's "93 °c" is the mirror of 39.

q9128  page 50   "mg052" -> "250 mg", "mg006" -> "600 mg", "mg005" -> "500 mg"
       Three doses in one question, each with the unit fused onto the front of
       a mirrored number. The page prints 250, 600 and 500 as clean runs.
       These matter because the question asks for the BEST prophylaxis regimen
       in a penicillin-anaphylactic patient, and a dose is part of judging a
       regimen: clarithromycin 500 mg orally one hour before is a real AHA
       regimen, while "mg005" is not a dose a student can evaluate.

WHAT IS DELIBERATELY NOT TOUCHED
---------------------------------
q9110's "10 سال پیش" and similar plain narrative numbers were checked and are
printed as extracted. q9123's vegetation "0/5 سانتی‌متر" is printed as `0` `5`
on page 48 with the slash between them, i.e. 0.5 cm, which is what the text
already says. No repair is invented where the page agrees with the extraction.
"""
import collections
import io
import json
import os
import re

import pdfplumber

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = '/home/user/uploads/بیماری عفونی.pdf'

# question_no -> [(page, old, new, expected_printed_run, kind, why_fa), ...]
FIXES = {
    9101: [
        # The old text is the bare value, NOT "BP: 80/021". In the stored stem
        # the label and its value are torn apart by the RTL run reordering —
        # "...شده:BP c̊39=T ,30=RR ,120=PR 80/021 را لهای..." — with the label
        # stranded at the front of the vitals and the number left near the end.
        # The first draft of this entry assumed the two were adjacent and the
        # `missing` guard rejected it rather than writing nothing and reporting
        # success. Page 39 prints "BP:" followed by the run 120/80.
        (39, '80/021', '120/80', '120', 'reorder',
         'فشار خون: صفحه ۳۹ رقم‌ها را **۱۲۰ روی ۸۰** چاپ کرده است. در استخراج، عدد '
         'سیستولیک به بعد از خط کسری رفته و معکوس شده و «۰۲۱» ساخته بود، که اصلاً '
         'یک فشار خون نیست. توجه کنید که نبض همین بیمار هم ۱۲۰ است؛ **فشار خون '
         'طبیعی در کنار تاکی‌کاردی و تب**، تصویر بالینی اندوکاردیت تحت‌حاد را '
         'می‌سازد، نه شوک سپتیک.'),
    ],
    9113: [
        (44, '8/83 °c', '38/8 °c', '38', 'reorder',
         '**این تصحیح پاسخ سؤال را نجات می‌دهد.** سؤال می‌پرسد کدام بیمار طبق '
         '**معیارهای دوک** تشخیص اندوکاردیت می‌گیرد، و تب فقط وقتی یک معیار مینور '
         'به حساب می‌آید که **۳۸ درجه یا بالاتر** باشد. صفحه ۴۴ برای این بیمار '
         '**۳۸/۸** چاپ کرده؛ متن استخراج‌شده «۸/۸۳» داشت که نه ۳۸ درجه است و نه '
         'اصلاً یک دمای انسانی. بدون این عدد، گزینه‌ی درست یک معیار مینور کم '
         'می‌آورد.'),
        (44, 'تب، 93 °c', 'تب، 39 °c', '39', 'reorder',
         'درجه حرارت: صفحه ۴۴ رقم‌ها را **۳۹** چاپ کرده است. «۹۳ درجه» معکوس '
         'شده‌ی همان است. این عدد در گزینه‌ی نادرست است ولی باید درست باشد تا '
         'دانشجو بتواند معیارهای هر چهار بیمار را واقعاً بشمارد و ببیند چرا '
         'فقط یکی از آن‌ها تشخیص می‌گیرد.'),
    ],
    9128: [
        (50, 'ازیترومایسین mg052', 'ازیترومایسین 250 mg', '250', 'reorder',
         'دوز آزیترومایسین: صفحه ۵۰ عدد **۲۵۰** را چاپ کرده و در استخراج، واحد به '
         'ابتدای عدد چسبیده و رقم‌ها معکوس شده‌اند.'),
        (50, 'کلیندامایسین mg006', 'کلیندامایسین 600 mg', '600', 'reorder',
         'دوز کلیندامایسین: صفحه ۵۰ عدد **۶۰۰** را چاپ کرده است.'),
        (50, 'کلاریترومایسین mg005', 'کلاریترومایسین 500 mg', '500', 'reorder',
         'دوز کلاریترومایسین: صفحه ۵۰ عدد **۵۰۰** را چاپ کرده است. این عدد مهم '
         'است چون **کلاریترومایسین ۵۰۰ میلی‌گرم خوراکی یک ساعت پیش از پروسیجر** '
         'دقیقاً رژیم استاندارد AHA برای بیمار حساس به پنی‌سیلین است؛ با «mg005» '
         'دانشجو نمی‌تواند بفهمد که گزینه‌ی درست، دوز درست را هم دارد.'),
    ],
}

FOLD = {}
for _i in range(10):
    FOLD[chr(0x0660 + _i)] = str(_i)   # Arabic-Indic
    FOLD[chr(0x06F0 + _i)] = str(_i)   # Persian


def page_digit_runs(pdf, pno):
    """Digit runs of a page in PRINTED (x-ascending) order."""
    page = pdf.pages[pno - 1]
    rows = collections.defaultdict(list)
    for c in page.chars:
        rows[round(c['top'])].append(c)
    runs = []
    for top in sorted(rows):
        cs = sorted(rows[top], key=lambda c: c['x0'])
        cur = ''
        for c in cs:
            t = FOLD.get(c['text'], c['text'])
            # a space must NOT close an open run: kerning sometimes splits a
            # number, and closing on the space invents two numbers out of one
            if t.isspace() and cur:
                continue
            if t.isdigit():
                cur += t
            else:
                if cur:
                    runs.append(cur)
                cur = ''
        if cur:
            runs.append(cur)
    return runs


def main():
    pages = {p for specs in FIXES.values() for (p, *_r) in specs}
    with pdfplumber.open(SRC) as pdf:
        printed = {p: page_digit_runs(pdf, p) for p in pages}

    applied, missing = [], []
    for i in range(1, 6):
        path = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        if not os.path.exists(path):
            continue
        body = json.load(io.open(path, encoding='utf-8'))
        dirty = False
        for q in body['questions']:
            specs = FIXES.get(q['question_no'])
            if not specs:
                continue
            for pno, old, new, expect, kind, why in specs:
                assert expect in printed[pno], \
                    f'q{q["question_no"]}: page {pno} does not print {expect}'
                old_d = [c for c in old if c.isdigit()]
                new_d = [c for c in new if c.isdigit()]
                if kind == 'reorder':
                    assert sorted(old_d) == sorted(new_d), \
                        f'q{q["question_no"]}: {old} -> {new} is not a reordering'
                else:
                    assert kind == 'restore', f'unknown kind {kind!r}'
                    have = collections.Counter(new_d)
                    for ch, n in collections.Counter(old_d).items():
                        assert have[ch] >= n, \
                            f'q{q["question_no"]}: {old} -> {new} loses a printed digit'
                    for run in re.findall(r'\d+', new):
                        assert run in printed[pno], \
                            f'q{q["question_no"]}: page {pno} does not print restored {run}'
                    assert any(w in why for w in ('افتاده', 'باقی مانده', 'حذف')), \
                        f'q{q["question_no"]}: a restore must say a digit was dropped'

                hit = False
                if old in q['question_fa']:
                    q.setdefault('stem_original_fa', q['question_fa'])
                    q['question_fa'] = q['question_fa'].replace(old, new)
                    q.setdefault('stem_number_corrections', []).append({
                        'from': old, 'to': new, 'page': pno, 'where': 'stem',
                        'method': 'glyph geometry (pdfplumber x-order)',
                        'kind': kind, 'why_fa': why})
                    applied.append(f'q{q["question_no"]}: {old} -> {new} (stem)')
                    hit = True
                    dirty = True
                for oi, opt in enumerate(q['options_fa']):
                    if old in opt:
                        q.setdefault('options_original_fa', list(q['options_fa']))
                        q['options_fa'][oi] = opt.replace(old, new)
                        q.setdefault('stem_number_corrections', []).append({
                            'from': old, 'to': new, 'page': pno,
                            'where': f'option {oi + 1}',
                            'method': 'glyph geometry (pdfplumber x-order)',
                            'kind': kind, 'why_fa': why})
                        applied.append(
                            f'q{q["question_no"]}: {old} -> {new} (option {oi + 1})')
                        hit = True
                        dirty = True
                if not hit:
                    # Already applied on an earlier run is NOT a failure.
                    #
                    # This distinction was learned the hard way on this very
                    # script. The first run mistyped one `old` string, wrote
                    # the other five fixes, and then aborted on the assertion
                    # at the end. Re-running after the typo was corrected then
                    # reported the five ALREADY-CORRECT questions as failures,
                    # because their old text is legitimately gone. A repair
                    # script must be idempotent, or a partial write leaves it
                    # unable to tell "I have not done this" from "I cannot".
                    done = (new in q['question_fa']
                            or any(new in o for o in q['options_fa']))
                    if done:
                        applied.append(
                            f'q{q["question_no"]}: {old} -> {new} (already applied)')
                    else:
                        missing.append(f'q{q["question_no"]}: {old!r} not found')
        if dirty:
            json.dump(body, io.open(path, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)

    for a in applied:
        print('  fixed  ', a)
    for m in missing:
        print('  MISSING', m)
    print(f'applied {len(applied)}, missing {len(missing)}')
    assert not missing, 'some fixes did not match the stored text'


if __name__ == '__main__':
    main()
