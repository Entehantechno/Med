# -*- coding: utf-8 -*-
"""English stems and options for batches 37 to 40 — the rest of the viral chapter.

Genital ulcers, urethritis, mononucleosis, varicella zoster, measles, mumps,
rubella and hepatitis. With this file the viral and STI chapter is complete in
both languages.

Rule 16 checked first, as always: these items come from sittings 93 to 98, for
which the ministry published no English booklet, so these are hand-written
translations rather than official ones.

Translation decisions worth recording
-------------------------------------
'PAINFUL' AND 'SOFT' ARE LOAD-BEARING throughout the genital-ulcer block and
are translated literally every time. The entire cluster is decided by the
pain/consistency grid, and softening either word would destroy it. Likewise
UNILATERAL versus BILATERAL for the nodes: that single word is what separates
chancroid from herpes in q9531 versus q9606.

THE TIME INTERVALS in the varicella post-exposure block are preserved exactly
(6 days, 7 days, last week, last week of pregnancy), because the whole cluster
turns on the day-7 rule and an approximated interval would make the keys look
arbitrary.

q9599 CARRIES A SOURCE DEFECT — a platelet count of 1,350,000, which is not a
human value. The English reproduces the printed figure exactly, because the
stem must say what the paper said; the lesson explains that the intended value
was almost certainly 135,000. Same for q9856, whose titre is printed with NO
UNIT at all: the English keeps it unitless. See flag_source_errors_viral.py.

q9642's options are printed in the source as a mixture of English and
transliteration, including two misspellings ('Roswola' for roseola and
'Scartet fever' for scarlet fever). They are rendered as the intended disease
names in correct English, because a misspelling in the SOURCE's own Latin text
is a typographic slip rather than content, and reproducing it would only
confuse an English reader. The Persian side keeps the printed form.

THE VAGINITIS TERMS (clue cell, whiff test, KOH) keep their standard English
forms, because that is how they appear on a laboratory request.
"""

EN19 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    assert all(o.strip() for o in options), idx
    EN19[idx] = {"stem_en": stem, "options_en": options}


# ============================================== genital ulcer (batch 37)
add(531,
    "A young man with a history of suspicious sexual contact has developed a painful, soft, "
    "purulent ulcer with an ill-defined margin. On examination he has unilateral inguinal "
    "lymphadenopathy that is clearly tender on palpation. What is the most likely diagnosis?",
    ["Genital herpes",
     "Lymphogranuloma venereum",
     "A chancre due to syphilis",
     "Chancroid due to Haemophilus ducreyi"])

add(532,
    "A 28-year-old man who had unprotected sexual contact 10 days ago presents with ulcers in the "
    "right groin which began 3 days ago as multiple pustules. The ulcers are deep, purulent and "
    "painful. He also has painful right inguinal lymphadenopathy. Given the above, which of the "
    "following diseases is more likely in this patient?",
    ["Genital herpes",
     "Chancroid",
     "Syphilis",
     "Lymphogranuloma venereum"])

add(606,
    "A young man presents complaining of several painful ulcers on the penis. He also has painful "
    "bilateral inguinal lymphadenopathy. Which of the following diagnoses do you think of most?",
    ["Syphilis",
     "Chancroid",
     "Chlamydial infection",
     "Herpes virus"])

add(608,
    "A 30-year-old man, one week after suspicious sexual contact, has developed fever and burning on "
    "micturition, and on examination has painful vesicular lesions in the genital area together with "
    "painful bilateral inguinal lymphadenopathy. Given the clinical features, what is the most "
    "likely cause?",
    ["Treponema pallidum",
     "Herpes simplex",
     "Papillomavirus",
     "Haemophilus ducreyi"])

add(609,
    "A 25-year-old woman presents with fever and myalgia together with very painful ulcers in the "
    "genital area for the past 3 days. On examination of the genital area, mucosal ulcers and "
    "grouped vesicles are seen on the labia majora and the surrounding skin. With a diagnosis of "
    "genital herpes you request a PCR on the vesicle contents and start her on aciclovir. Which "
    "further investigation do you consider necessary for this patient?",
    ["Measurement of serum immunoglobulins",
     "Ultrasound of the uterus and adnexa",
     "HSV serology",
     "Hysterosalpingography"])

add(610,
    "An intensive care nurse presents with fever, epitrochlear lymphadenopathy and vesiculopustular "
    "lesions of the second finger of the right hand, which have not responded to cephalexin "
    "treatment. She had a similar lesion last year. What is the most likely causative agent?",
    ["Pseudomonas aeruginosa",
     "Varicella zoster virus",
     "Aspergillus fumigatus",
     "Herpes simplex virus"])


# ================================================ urethritis (batches 37, 40)
add(534,
    "A 30-year-old man, one week after suspicious sexual intercourse with an unknown person, "
    "develops fever, generalised body pain, a widespread skin rash, and swelling and restricted "
    "movement in several joints. Two days before these symptoms he also had a purulent urethral "
    "discharge. Which diagnosis is more likely?",
    ["Secondary syphilis",
     "Gonococcal infection",
     "Mycoplasma genitalium infection",
     "Chlamydia trachomatis infection"])

add(537,
    "A 20-year-old woman has developed, for the third time in the past year, fever, polyarthritis of "
    "the small peripheral joints together with pustular skin lesions adjacent to the affected "
    "joints. Her blood culture has grown a Gram-negative diplococcus. While re-treating her, which "
    "diagnostic action do you recommend?",
    ["Measurement of serum immunoglobulin levels",
     "Anti-HIV antibody",
     "Measurement of C1 to C3 activity",
     "Measurement of C5 to C9 activity"])

add(551,
    "A young woman presents with exudative pharyngitis and tender cervical lymphadenopathy. She "
    "reports unprotected sexual contact during the past week. A nasopharyngeal swab grows non-motile "
    "Gram-negative coccobacilli, singly or in pairs. Given the most likely diagnosis, which of the "
    "following do you consider the treatment of choice?",
    ["Doxycycline",
     "Ceftriaxone",
     "Gentamicin",
     "Spectinomycin"])

add(554,
    "A 24-year-old man presents with pain and unilateral swelling of the right testis for the past "
    "week. In his history he reports a discharge from the meatus. Given these features, which of the "
    "following is your treatment recommendation for him?",
    ["Ofloxacin plus azithromycin",
     "Ceftriaxone plus doxycycline",
     "Cefixime plus azithromycin",
     "Gemifloxacin plus doxycycline"])

add(555,
    "A 30-year-old man presents with urethritis and a urethral discharge. Intracellular Gram-negative "
    "diplococci are seen on the discharge smear. Gonococcal treatment with ceftriaxone is started and "
    "he recovers, but after one week, without any further sexual contact, he again develops a mucoid "
    "urethral discharge. Which action is required?",
    ["Treat the gonococcus with another antibiotic, assuming drug resistance",
     "Treat with ceftriaxone plus azithromycin for chlamydia",
     "Treat with azithromycin for chlamydia",
     "None of the above"])

add(535,
    "A sexually active 21-year-old woman presents to the gynaecology clinic complaining of burning, "
    "urinary frequency and a white vaginal discharge. If bacterial vaginosis is strongly suspected, "
    "which of the following argues AGAINST that diagnosis?",
    ["A white vaginal discharge",
     "Clue cells seen in the vaginal discharge",
     "A fishy odour after adding KOH",
     "A vaginal pH of 4.5 or below"])

add(536,
    "A 20-year-old woman with high-risk sexual behaviour presents with dysuria for several days. She "
    "has no suprapubic pain and has not improved on co-trimoxazole. Urinalysis shows 10 to 12 white "
    "cells, and the urine culture is reported as fewer than 10 Gram-positive cocci. What is the most "
    "likely causative agent?",
    ["Chlamydia trachomatis",
     "Staphylococcus epidermidis",
     "Staphylococcus saprophyticus",
     "Trichomonas vaginalis"])

add(538,
    "A 30-year-old sex worker presents with burning, frequency and urgency of micturition for the "
    "past 2 days. She reports no fever and has no significant past medical history. Which of the "
    "following diagnostic actions is NOT recommended as a first step for this patient?",
    ["Pelvic examination",
     "Urinalysis",
     "Urine culture",
     "Ultrasound of the urinary tract"])

add(539,
    "A 40-year-old man who developed urethritis after suspicious sexual contact was treated with "
    "ceftriaxone 250 mg intramuscularly as a single dose and doxycycline for 7 days. Two weeks later "
    "he again has burning on micturition and a urethral discharge. On genital examination no lesion "
    "is seen. Examination of the urethral discharge shows 8 to 10 white cells. Which treatment "
    "regimen is most appropriate?",
    ["Ciprofloxacin plus metronidazole",
     "Metronidazole plus azithromycin",
     "Aciclovir plus tinidazole",
     "Tinidazole plus fluconazole"])

add(543,
    "A married woman presents with recurrent Trichomonas vaginalis infections. Investigation has "
    "shown that the isolated strain is resistant to metronidazole. Which action is NOT correct?",
    ["Treatment with vaginal clindamycin",
     "Treatment with higher doses of metronidazole",
     "Simultaneous treatment with oral and vaginal metronidazole",
     "Treatment with tinidazole"])

add(547,
    "A young man who two weeks ago was treated with a single 1 g dose of azithromycin for urethritis, "
    "after burning on micturition and a purulent urethral discharge following unprotected sexual "
    "contact, has had partial improvement and has now developed the same symptoms again. Which option "
    "do you consider more appropriate for treating him?",
    ["Repeat the single-dose azithromycin",
     "Doxycycline for 7 days",
     "Ciprofloxacin for 3 days",
     "Single-dose cefixime"])

add(548,
    "A 30-year-old man presents after recent sexual contact with burning of the urethra without "
    "urinary frequency and with a urethral discharge. Urinalysis is reported as 10 to 15 white cells, "
    "but the urine culture is negative. What is the best treatment for him?",
    ["Ciprofloxacin 500 mg twice daily for 7 days",
     "Cefixime 400 mg as a single oral dose plus azithromycin 1 g as a single dose",
     "Ceftriaxone 1 g as a single intravenous dose plus doxycycline 100 mg twice daily for a week",
     "Doxycycline 100 mg twice daily for 7 days"])

add(550,
    "A 25-year-old man presents complaining of a purulent urethral discharge. He reports sexual "
    "contact four days ago. Which treatment regimen do you choose, if laboratory testing is not "
    "possible?",
    ["Seven days of oral metronidazole",
     "Seven days of azithromycin plus a single day of ceftriaxone",
     "Seven days of oral azithromycin",
     "Seven days of oral doxycycline"])

add(562,
    "A 20-year-old man with no history of sexual contact comes to you for counselling about HPV "
    "prophylaxis. What is your recommendation?",
    ["Give the HPV vaccine in 3 doses",
     "Give a single dose of HPV vaccine",
     "Given the patient's age, it is not recommended",
     "The HPV vaccine has no indication in men"])


# ============================================ mononucleosis (batch 38)
add(597,
    "A 20-year-old man presents with fever, sore throat and generalised lymphadenopathy. He states "
    "that this is the worst sore throat he has ever experienced. On examination there is a grey "
    "exudate with swelling of the tonsils. Which of the following microorganisms is the more likely "
    "cause?",
    ["Epstein-Barr virus",
     "Adenovirus",
     "Group A streptococcus",
     "Neisseria gonorrhoeae"])

add(599,
    "A young man presents with fever, chills, weakness, sweating and exudative pharyngitis for the "
    "past week. On examination, in addition to the exudative pharyngitis, he has multiple bilateral "
    "painless cervical nodes. His tests show a leucocytosis of 15,000 consisting of 70% "
    "polymorphonuclear cells and 30% lymphocytes, platelets 1,350,000, and a mild rise in the liver "
    "transaminases. Given the most likely diagnosis, which therapeutic action is appropriate?",
    ["Supportive care, rest and analgesia",
     "A single intramuscular dose of benzathine penicillin G",
     "Oral aciclovir for one week",
     "Oral clindamycin for 14 days"])

add(600,
    "A 19-year-old woman has had fever, weakness, malaise, myalgia, sore throat and headache for the "
    "past 7 days. She saw a doctor once but did not improve. On examination her temperature is 39, "
    "the tonsils are enlarged and covered with bilateral exudate, and the spleen is palpable. Her "
    "tests are as follows: WBC 14/700 (14,700), PMN 10%, lymphocytes 90%. What is the best treatment?",
    ["Azithromycin plus rest plus fluids",
     "Erythromycin plus rest plus an antipyretic",
     "Benzathine penicillin plus rest plus an antipyretic",
     "Rest plus an antipyretic plus warm fluids"])


# ============================================ varicella zoster (batches 38, 39)
add(612,
    "A 20-year-old man presents with itchy skin lesions. He has had fever, sore throat and fatigue "
    "for 2 days, and since yesterday skin lesions have been added to the picture. He is currently "
    "febrile, and maculopapular and vesicular lesions on an erythematous base are seen on his face "
    "and trunk. On examination lesions are also evident on the oral mucosa. Given the most likely "
    "diagnosis, which action do you recommend?",
    ["An antihistamine alone is sufficient",
     "Oral aciclovir for 5 days",
     "Oral cephalexin for 10 days",
     "Recommend a biopsy of the lesions"])

add(614,
    "A 25-year-old man presents with fever and skin lesions. The skin lesions take the form of "
    "macules, papules, vesicles and pustules. Which of the following diseases applies to this "
    "patient?",
    ["Chickenpox",
     "Measles",
     "Rubella",
     "Roseola"])

add(615,
    "A 65-year-old woman presents with pain in the axillary region, but examination showed nothing "
    "particular. On review the following day, several vesicles on an erythematous base are seen. "
    "What is the most likely cause of this clinical syndrome?",
    ["Human papillomavirus",
     "Herpes simplex virus",
     "Staphylococcus aureus",
     "Varicella zoster virus"])

add(616,
    "A 55-year-old woman presents complaining of deviation of the face to the right together with "
    "left ear pain and numbness of the tongue. On examination there are painful vesicles in the left "
    "ear canal and a peripheral seventh nerve palsy on the same side. What is your diagnosis?",
    ["Cavernous sinus thrombosis",
     "Ramsay Hunt syndrome",
     "Acute otitis",
     "Bell's palsy"])

add(617,
    "A 53-year-old man presents with unilateral ear pain, and on examination painful vesicular "
    "lesions are evident in the external ear canal together with a seventh nerve palsy on the same "
    "side. Which of the following viruses is the most likely cause of this condition?",
    ["Cytomegalovirus",
     "Herpes simplex",
     "Coxsackievirus",
     "Varicella zoster virus"])

add(619,
    "A schoolchild has developed fever and maculopapular and vesicular skin lesions at different "
    "stages, 5 to 10 mm in size, on the trunk, face, elsewhere on the body and on the oral mucosa. "
    "The occurrence of which of the following complications is LESS likely in this patient?",
    ["Neurological complications",
     "Secondary skin infection",
     "Symptomatic hepatitis",
     "Pneumonia"])

add(622,
    "An 8-year-old girl developed mild fever and malaise in the spring. A day later she developed "
    "maculopapular and vesicular skin lesions at different stages of formation on the trunk, face "
    "and elsewhere on the body. Most of the lesions were small with an erythematous base. The "
    "lesions healed, but about three weeks later the child developed nausea and disturbance of "
    "balance and gait. Which action do you recommend?",
    ["Intravenous aciclovir",
     "Oral aciclovir",
     "Corticosteroid",
     "Supportive care"])

add(624,
    "A 12-year-old girl presents with fever, skin lesions and an occasional cough for the past two "
    "days. On examination of the skin, macules, papules, vesicles and pustules are seen. What is your "
    "recommendation about avoiding close contact with those around her, and for how long?",
    ["Two days from the appearance of the skin lesions",
     "Ten days after all the skin lesions have dried",
     "Ten days after the fever ends",
     "Until all the skin lesions have dried"])

add(626,
    "A 9-year-old boy who received a kidney transplant last year, and whose sister had chickenpox 6 "
    "days ago, comes to you. The child himself gives no history of chickenpox or of vaccination "
    "against it. What is the most appropriate action for his prophylaxis?",
    ["Varicella vaccine",
     "VZIG (varicella zoster specific immunoglobulin)",
     "VZIG plus varicella vaccine",
     "Oral aciclovir from day 7 after exposure"])

add(629,
    "A woman at 24 weeks' gestation attends the clinic and is very worried because of contact 7 days "
    "ago with a child who has active chickenpox. She has no history of previous chickenpox and has "
    "never had the chickenpox vaccine. What do you advise her?",
    ["Give VZIG",
     "Give oral aciclovir",
     "Give two doses of chickenpox vaccine",
     "Give VZIG and the first dose of chickenpox vaccine"])

add(630,
    "A woman at 20 weeks' gestation comes to you and reports that last week, at her child's birthday "
    "party, one of the children was febrile and unwell, and that yesterday she learned the child had "
    "chickenpox. She also states with concern that she has no history of chickenpox. Which action do "
    "you recommend?",
    ["Advise her to receive VZIG",
     "Advise monitoring of vital signs and prompt treatment if fever develops",
     "Advise starting oral aciclovir",
     "Advise immediate chickenpox vaccination"])

add(634,
    "A woman in the last week of pregnancy presents with painful vesiculopapular lesions on the "
    "abdomen and flank. Which of the following actions do you recommend?",
    ["Start oral aciclovir for the mother",
     "Give VZIG to the neonate",
     "Give VZIG to the mother and the neonate",
     "Start intravenous aciclovir for the mother and the neonate"])

add(637,
    "On the obstetric ward, a mother develops painful vesicular lesions in the L1 to L3 dermatomes "
    "one day after delivery, and apart from these lesions has no other symptom. What do you advise "
    "for her neonate?",
    ["Give IVIG as soon as possible",
     "Give aciclovir within the next 3 days",
     "Give IVIG within the next 2 days",
     "No specific action is needed"])


# ==================================== measles, mumps, rubella (batches 38, 39)
add(641,
    "A 23-year-old student is brought to the emergency department with fever and a skin eruption. For "
    "the past five days he has had a dry cough, coryza, photophobia and severe malaise, and for the "
    "past three days an intense red maculopapular rash which began on the forehead and then spread to "
    "the trunk and limbs. On examination his temperature is 39 degrees centigrade, he has bilateral "
    "conjunctivitis, and his oral mucous membranes are severely dehydrated. Which of the following do "
    "you think is the probable diagnosis?",
    ["Rubella",
     "Measles",
     "Erythema infectiosum",
     "Roseola infantum"])

add(642,
    "An 8-year-old child, after a period of fever, cough and conjunctivitis with Koplik spots in the "
    "mouth, develops a generalised confluent maculopapular rash beginning on the head and spreading "
    "downwards. This description matches which clinical syndrome?",
    ["Measles",
     "Rubella",
     "Roseola",
     "Scarlet fever"])

add(643,
    "A 20-year-old soldier who has been undergoing a training course for the past month develops high "
    "fever, anorexia, severe cough and bilateral conjunctivitis. On examination the oral mucosa is red "
    "and inflamed with bluish-white spots opposite the second molars. Since last night he has "
    "developed maculopapular lesions on the face, trunk and limbs. Given the probable diagnosis, which "
    "of the following complications do you think is most likely to occur?",
    ["Laryngotracheobronchitis (croup)",
     "Intestinal perforation",
     "Acute otitis media",
     "Encephalitis"])

add(647,
    "A woman at 8 weeks' gestation comes to you with the following rubella serology: IgG positive, IgM "
    "negative. What is your recommendation for her?",
    ["Repeat the test in two weeks",
     "Perform PCR on amniotic fluid at 20 weeks of pregnancy",
     "Reassure the patient and recommend nothing further, diagnostic or therapeutic",
     "Give the vaccine and specific immunoglobulin"])

add(650,
    "A pregnant woman who has never had rubella and gives no history of rubella vaccination has been "
    "in contact with a patient who has rubella. Which of the following actions is more useful?",
    ["Give rubella vaccine",
     "Give intravenous ribavirin",
     "Give intramuscular immunoglobulin",
     "No action is needed"])

add(651,
    "A 5-year-old girl from Afghanistan, with no clear history of vaccination, presents with fever, "
    "myalgia and anorexia for the past 3 days. Her mother states that since yesterday the patient has "
    "suddenly developed pain and unilateral swelling of the face. On examination there is tenderness "
    "and swelling of the parotid region. Given the probable diagnosis of mumps, which of the following "
    "is correct regarding the time of transmission of the virus to other family members?",
    ["From one week before the onset of symptoms until the onset of parotitis",
     "From one week before the onset of symptoms until 1 week after the onset of symptoms",
     "From the onset of parotitis until its resolution",
     "Given that 3 days have passed since the onset of symptoms, there is no risk of transmission"])


# ============================================ HIV and hepatitis (batches 39, 40)
add(707,
    "A newly identified case of HIV attends the counselling centre. All his clinical examinations are "
    "normal. The patient's CD4 is 600 and his viral load is 500 copies/ml. What is the appropriate "
    "action for him?",
    ["There is no need to start ART for now",
     "Perform a Western blot",
     "Start ART",
     "Start chemoprophylaxis with co-trimoxazole"])

add(849,
    "A 35-year-old woman presents complaining of weakness, malaise, joint pain and diffuse myalgia, "
    "anorexia, jaundice and right upper quadrant pain. On examination she is icteric and the joints "
    "show no obvious arthritis. Her tests show AST 200, ALT 350, anti-LKM and HCVAb positive, and a "
    "first-hour ESR of 80. What is your first action for this patient?",
    ["Azathioprine and prednisone",
     "Liver biopsy",
     "Request an HCV PCR",
     "Ribavirin and interferon"])

add(850,
    "A 34-year-old man who injects drugs presents with right flank pain, anorexia and mild jaundice. "
    "He reports a history of hepatitis B vaccination. His initial tests are as follows. To investigate "
    "hepatitis C, which test is more sensitive at this stage?",
    ["HCV RNA",
     "RIBA",
     "Anti-HBc IgM",
     "Anti-HCV"])

add(856,
    "During an operation a needle has penetrated the surgeon's hand. He has so far received two series "
    "of vaccine against HBV and his antibody titre was finally reported as about 6. What do you think "
    "is the best action for him?",
    ["Give HBV vaccine with one dose of immunoglobulin (HBIG)",
     "Start a third vaccination series (months zero, 1 and 6)",
     "Give two doses of HBIG one month apart",
     "Start drug prophylaxis with tenofovir for one month"])
