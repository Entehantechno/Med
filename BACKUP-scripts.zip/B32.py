# -*- coding: utf-8 -*-
"""Micro-lessons, batch 32 — varicella zoster: exposure, pregnancy and the neonate.

Twenty-five questions in this chapter are about one virus, and eleven of them
ask the same question in different clothes: SOMEONE SUSCEPTIBLE HAS BEEN
EXPOSED TO CHICKENPOX — WHAT DO YOU GIVE? The examiners vary the contact (a
sibling, a birthday party, a hospital ward), the host (pregnant, transplant,
leukaemia) and the interval (5, 6, 7 days), and the answer moves accordingly.

So this batch teaches one decision structure rather than eleven facts.

THE POST-EXPOSURE DECISION, IN THE ORDER IT MUST BE MADE
---------------------------------------------------------
  1. Is the contact SUSCEPTIBLE? No previous chickenpox and no two doses of
     vaccine. If immune, nothing is needed and the question is over.
  2. Is the person at HIGH RISK of severe disease? Pregnancy, significant
     immunosuppression, and the neonate of a mother with peripartum varicella.
  3. HOW LONG since the exposure, and WHICH agent does that allow?
        vaccine       — only within 3 to 5 days, and only if not pregnant and
                        not immunosuppressed (it is a LIVE vaccine)
        VZIG          — up to 10 days, ideally within 96 hours
        aciclovir     — STARTED ON DAY 7, continued to day 14

WHY DAY SEVEN, WHICH IS THE FACT THE EXAM KEEPS TESTING
--------------------------------------------------------
Several of these questions hand the student an exposure 5, 6 or 7 days old and
key the answer to "start aciclovir from day 7". That looks arbitrary until you
see the trial behind it: healthy exposed children given aciclovir IMMEDIATELY
developed clinical varicella in 10 of 13 cases (77%), while those who started
at DAY 7 developed it in 3 of 14 (21%). Starting too early suppresses the
virus before the immune system has seen enough of it to respond, and the
infection simply appears once the drug stops. Waiting until day 7 lets the
drug act at the moment of peak viral replication.

The UKHSA 2024/2025 guidance now makes ORAL ANTIVIRALS FIRST CHOICE for
susceptible pregnant contacts at any stage, with VZIG reserved for those who
cannot take them — so the keys of these questions and current practice agree.

THE NEONATAL WINDOW, THE OTHER FACT THE CHAPTER TESTS REPEATEDLY
-----------------------------------------------------------------
Maternal CHICKENPOX from 5 days before to 2 days after delivery is the danger
window: the baby receives the virus across the placenta but not the antibody,
and untreated mortality reaches 30%. Outside that window, and — crucially —
for maternal SHINGLES at any time, the baby is protected by maternal IgG and
needs nothing. Three questions in this chapter are built on exactly that
distinction, and two of them describe maternal ZOSTER specifically to see
whether the student will treat a baby who does not need it.

Reference: CDC, "Updated Recommendations for Use of VariZIG", MMWR
2013;62(28):574-576; UK Health Security Agency, "Guidelines on post-exposure
prophylaxis for varicella or shingles" (2024/2025); RCOG Green-top Guideline
No. 13, "Chickenpox in Pregnancy" (updated 2024); Harrison's Principles of
Internal Medicine, 21st ed (2022), Ch. 193 (Varicella-Zoster Virus Infections).
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


VARIZIG = ("CDC — Updated Recommendations for Use of VariZIG. MMWR Morb Mortal Wkly Rep "
           "2013;62(28):574-576")
UKHSA = ("UK Health Security Agency — Guidelines on post-exposure prophylaxis (PEP) for "
         "varicella or shingles (2024/2025)")
RCOG13 = ("RCOG Green-top Guideline No. 13 — Chickenpox in Pregnancy (updated 2024)")
H193 = ("Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 193: "
        "Varicella-Zoster Virus Infections")

# --------------------------------------------------- the post-exposure ladder
PEP_FA = [
    "⚠️ **پروفیلاکسی پس از تماس با آبله‌مرغان را با سه سؤال پشت سر هم تصمیم بگیرید.**",
    "**سؤال یک — آیا این فرد اصلاً مستعد است؟**",
    "**مستعد یعنی: نه سابقه‌ی ابتلای قبلی دارد، نه دو دوز واکسن گرفته است.**",
    "**اگر ایمن باشد، هیچ اقدامی لازم نیست و سؤال همان‌جا تمام می‌شود.**",
    "**سؤال دو — آیا در گروه پرخطر است؟ سه گروه: بارداری، نقص ایمنی، و نوزاد.**",
    "⚠️ **سؤال سه — چند روز از تماس گذشته؟ این پاسخ را کاملاً عوض می‌کند.**",
    "**واکسن: فقط تا ۳ تا ۵ روز پس از تماس — و فقط در فرد غیرباردار و بدون نقص ایمنی.**",
    "⚠️ **چون واکسن واریسلا زنده‌ی ضعیف‌شده است: در بارداری و نقص ایمنی ممنوع.**",
    "**VZIG: تا ۱۰ روز پس از تماس، هرچه زودتر بهتر (ایده‌آل ظرف ۹۶ ساعت).**",
    "**آسیکلوویر خوراکی: از روز هفتم شروع می‌شود و تا روز چهاردهم ادامه می‌یابد.**",
    "⚠️ **و حالا مهم‌ترین نکته‌ی این بلوک: چرا روز هفتم و نه فوراً؟**",
    "**یک کارآزمایی روی کودکان سالمِ در معرض تماس، دو زمان‌بندی را مقایسه کرد:**",
    "**شروع فوری ← ۱۰ نفر از ۱۳ نفر (۷۷٪) آبله‌مرغان بالینی گرفتند.**",
    "**شروع در روز هفتم ← فقط ۳ نفر از ۱۴ نفر (۲۱٪).**",
    "⚠️ **چرا؟ شروع خیلی زود، ویروس را پیش از آنکه سیستم ایمنی آن را ببیند سرکوب می‌کند،**",
    "**پس پاسخ ایمنی ساخته نمی‌شود و بیماری به‌محض قطع دارو ظاهر می‌شود.**",
    "**روز هفتم مصادف با اوج تکثیر ویروسی است — همان‌جا که دارو بیشترین اثر را دارد.**",
    "**و راهنمای بریتانیا (UKHSA) امروز آنتی‌ویروال خوراکی را انتخاب اول برای بارداری می‌داند،**",
    "**و VZIG را فقط برای کسی که نمی‌تواند خوراکی بگیرد نگه می‌دارد.**",
    "**دوره‌ی کمون آبله‌مرغان ۱۰ تا ۲۱ روز است — و VZIG می‌تواند آن را تا ۲۸ روز طولانی کند.**",
]
PEP_EN = [
    "WARNING: DECIDE VARICELLA POST-EXPOSURE PROPHYLAXIS WITH THREE QUESTIONS IN ORDER.",
    "QUESTION ONE — is this person susceptible at all?",
    "Susceptible means: no previous chickenpox AND no two doses of vaccine.",
    "If immune, nothing is needed and the question ends there.",
    "QUESTION TWO — is the person in a high-risk group? Three groups: pregnancy, immunosuppression, and the neonate.",
    "WARNING, QUESTION THREE — HOW MANY DAYS SINCE THE EXPOSURE? This changes the answer completely.",
    "VACCINE: only within 3 to 5 days of exposure — and only in someone not pregnant and not immunosuppressed.",
    "WARNING, BECAUSE THE VARICELLA VACCINE IS LIVE ATTENUATED: contraindicated in pregnancy and immunosuppression.",
    "VZIG: up to 10 days after exposure, the sooner the better (ideally within 96 hours).",
    "ORAL ACICLOVIR: STARTED ON DAY 7 and continued to day 14.",
    "WARNING, AND NOW THE KEY POINT OF THIS BLOCK: why day seven rather than at once?",
    "A trial in healthy exposed children compared the two timings:",
    "IMMEDIATE START: 10 of 13 (77 per cent) developed clinical varicella.",
    "START ON DAY 7: only 3 of 14 (21 per cent).",
    "WARNING, WHY? Starting too early suppresses the virus BEFORE the immune system has seen it,",
    "so no immune response is built and the disease simply appears once the drug stops.",
    "Day seven coincides with PEAK VIRAL REPLICATION — where the drug does most good.",
    "And UKHSA guidance today makes oral antivirals FIRST CHOICE in pregnancy,",
    "reserving VZIG for those who cannot take them.",
    "The incubation of chickenpox is 10 to 21 days — and VZIG can stretch it to 28.",
]

# --------------------------------------------------- the disease and neonates
DIS_FA = [
    "⚠️ **آبله‌مرغان را از یک نشانه بشناسید: ضایعات در مراحل مختلف، هم‌زمان.**",
    "**ماکول، پاپول، وزیکول و کراست، همه با هم روی یک ناحیه از پوست.**",
    "**این «پلئومورفیسم» آن را از آبله (که همه‌ی ضایعاتش هم‌مرحله‌اند) جدا می‌کند.**",
    "**انتشارش مرکزگرا است: تنه بیشتر از اندام‌ها، و مخاط دهان هم درگیر می‌شود.**",
    "⚠️ **دوره‌ی سرایت: از ۱ تا ۲ روز پیش از راش تا خشک شدن همه‌ی ضایعات.**",
    "**پس معیار پایان ایزوله «تعداد روز» نیست — «کراست شدن همه‌ی ضایعات» است.**",
    "**و این معمولاً حدود ۵ روز پس از شروع راش طول می‌کشد.**",
    "**ایزولاسیون بیمار بستری: هم قطره‌ای و هم هوابرد (تنفسی)، چون ویروس هوابرد است.**",
    "⚠️ **عوارض را بر حسب میزبان تفکیک کنید — این تفکیک، چند سؤال را حل می‌کند:**",
    "**در کودک سالم: عفونت ثانویه‌ی باکتریال پوست شایع‌ترین عارضه است.**",
    "**و آتاکسی حاد مخچه‌ای، که خوش‌خیم است و بدون مرگ‌ومیر خودبه‌خود خوب می‌شود.**",
    "**در بزرگسال و به‌ویژه باردار: پنومونی واریسلایی، خطرناک‌ترین عارضه.**",
    "⚠️ **پنومونی واریسلایی در بارداری مرگ‌ومیر بالایی دارد و اندیکاسیون آسیکلوویر وریدی است.**",
    "**در نقص ایمنی: بیماری منتشر با درگیری احشا — کبد، ریه و مغز.**",
    "**و انسفالیت آبله‌مرغان، که برخلاف آتاکسی مخچه‌ای، مرگ‌ومیر قابل توجهی دارد.**",
    "⚠️ **و پنجره‌ی خطرناک نوزادی را حفظ کنید: آبله‌مرغان مادر از ۵ روز پیش تا ۲ روز پس از زایمان.**",
    "**در این پنجره، ویروس از جفت می‌گذرد ولی آنتی‌بادی هنوز نرسیده — مرگ‌ومیر تا ۳۰ درصد.**",
    "**پس این نوزاد VZIG می‌خواهد، صرف‌نظر از اینکه مادر گرفته یا نه.**",
    "⚠️ **ولی زونای مادر در هر زمانی، هیچ خطری برای نوزاد ندارد.**",
    "**چون زونا یعنی مادر از قبل ایمن بوده، پس IgG محافظ از جفت عبور کرده است.**",
]
DIS_EN = [
    "WARNING: RECOGNISE CHICKENPOX BY ONE SIGN — LESIONS IN DIFFERENT STAGES AT THE SAME TIME.",
    "Macules, papules, vesicles and crusts, all together on one area of skin.",
    "That pleomorphism separates it from smallpox, in which every lesion is at the same stage.",
    "Its distribution is CENTRIPETAL: trunk more than limbs, and the oral mucosa is involved.",
    "WARNING, INFECTIOUS PERIOD: from 1 to 2 days before the rash until ALL lesions have crusted.",
    "So the criterion for ending isolation is not a NUMBER OF DAYS but CRUSTING OF EVERY LESION.",
    "That usually takes about 5 days from the onset of the rash.",
    "Isolation of an admitted patient: both droplet AND airborne, because the virus is airborne.",
    "WARNING, SEPARATE THE COMPLICATIONS BY HOST — that separation solves several questions:",
    "IN A HEALTHY CHILD: secondary bacterial skin infection is the commonest complication.",
    "And ACUTE CEREBELLAR ATAXIA, which is benign, carries no mortality and resolves by itself.",
    "IN AN ADULT, ESPECIALLY IN PREGNANCY: VARICELLA PNEUMONIA, the most dangerous complication.",
    "WARNING: VARICELLA PNEUMONIA IN PREGNANCY CARRIES HIGH MORTALITY and indicates intravenous aciclovir.",
    "IN IMMUNOSUPPRESSION: disseminated disease with visceral involvement — liver, lung and brain.",
    "And varicella ENCEPHALITIS, which unlike cerebellar ataxia carries substantial mortality.",
    "WARNING, MEMORISE THE DANGEROUS NEONATAL WINDOW: maternal CHICKENPOX from 5 days before to 2 days after delivery.",
    "In that window the virus crosses the placenta but the antibody has not yet followed — mortality up to 30 per cent.",
    "So that neonate needs VZIG, whether or not the mother received any.",
    "WARNING, BUT MATERNAL SHINGLES AT ANY TIME POSES NO RISK TO THE BABY.",
    "Because shingles means the mother was already immune, so protective IgG has crossed the placenta.",
]


# =========================================================== book:621
add("book:621", "recall", "medium",
 "**آتاکسی حاد مخچه‌ای** تنها عارضه‌ی خوش‌خیم و بدون مرگ‌ومیر آبله‌مرغان است.",
 "ACUTE CEREBELLAR ATAXIA is the one benign complication of chickenpox with no mortality.",
 DIS_FA + [
  "**این سؤال چهار عارضه را کنار هم می‌گذارد و می‌پرسد کدام خوش‌خیم است.**",
  "**آتاکسی حاد مخچه‌ای: شایع‌ترین عارضه‌ی عصبی آبله‌مرغان در کودکان.**",
  "**حدود ۱ در ۴۰۰۰ کودک، معمولاً یک هفته پس از راش شروع می‌شود.**",
  "**تابلویش: بی‌تعادلی در راه رفتن، لرزش عمدی، دیس‌آرتری، نیستاگموس.**",
  "⚠️ **و مهم‌ترین ویژگی‌اش: خودبه‌خود و کامل در عرض ۲ تا ۴ هفته خوب می‌شود.**",
  "**بدون درمان اختصاصی، بدون عارضه‌ی ماندگار، و بدون مرگ‌ومیر گزارش‌شده.**",
  "**در مقابل، سه گزینه‌ی دیگر همگی کشنده‌اند:**",
  "**انسفالیت آبله‌مرغان: نادرتر ولی با مرگ‌ومیر ۵ تا ۲۰ درصد و عوارض عصبی ماندگار.**",
  "**پنومونیت واریسلایی: خطرناک‌ترین عارضه در بزرگسال، به‌ویژه باردار و سیگاری.**",
  "**واریسلای پریناتال: مرگ‌ومیر تا ۳۰ درصد در پنجره‌ی ۵ روز پیش تا ۲ روز پس از زایمان.**",
 ],
 DIS_EN + [
  "This question sets four complications side by side and asks which is benign.",
  "ACUTE CEREBELLAR ATAXIA: the commonest neurological complication of chickenpox in children.",
  "About 1 in 4000 children, usually beginning a week after the rash.",
  "Its picture: unsteady gait, intention tremor, dysarthria, nystagmus.",
  "WARNING, AND ITS KEY FEATURE: it resolves completely and spontaneously in 2 to 4 weeks.",
  "No specific treatment, no lasting deficit, and no reported mortality.",
  "By contrast, the other three options are all lethal:",
  "VARICELLA ENCEPHALITIS: rarer but with 5 to 20 per cent mortality and lasting neurological damage.",
  "VARICELLA PNEUMONITIS: the most dangerous complication in adults, above all pregnant women and smokers.",
  "PERINATAL VARICELLA: mortality up to 30 per cent in the window 5 days before to 2 days after delivery.",
 ],
 "یک سؤال حفظی، ولی با یک تمایز بالینی که ارزش عمیق یاد گرفتن دارد: **کدام عارضه‌ی عصبی "
 "آبله‌مرغان می‌ترساند و کدام نمی‌ترساند.**\n\n"
 "**پاسخ: آتاکسی حاد مخچه‌ای.**\n\n"
 "⚠️ **چرا این یکی خوش‌خیم است؟**\n\n"
 "آتاکسی حاد مخچه‌ای شایع‌ترین عارضه‌ی عصبی آبله‌مرغان در کودکان است (حدود **۱ در ۴۰۰۰**). "
 "معمولاً **یک هفته پس از راش** شروع می‌شود و با **بی‌تعادلی راه رفتن، لرزش عمدی، "
 "دیس‌آرتری و نیستاگموس** خودش را نشان می‌دهد.\n\n"
 "**و نکته‌ی تعیین‌کننده: کاملاً و خودبه‌خود در عرض ۲ تا ۴ هفته برطرف می‌شود.** بدون درمان "
 "اختصاصی، بدون نقص ماندگار، و **بدون مرگ‌ومیر گزارش‌شده**. مکانیسمش هم احتمالاً "
 "**ایمنی‌واسطه** است، نه تهاجم مستقیم ویروس — و همین توضیح می‌دهد چرا خودمحدودشونده است.\n\n"
 "**و حالا سه گزینه‌ی دیگر، که همه می‌کشند:**\n\n"
 "**انسفالیت آبله‌مرغان** — نادرتر از آتاکسی، ولی **مرگ‌ومیر ۵ تا ۲۰ درصد** و در بازماندگان "
 "**عوارض عصبی ماندگار**. برخلاف آتاکسی، اینجا التهاب واقعی پارانشیم مغز است.\n\n"
 "**پنومونیت واریسلایی** — **خطرناک‌ترین عارضه در بزرگسالان**. عوامل خطرش: **بارداری، "
 "سیگار، و نقص ایمنی**. در بارداری مرگ‌ومیر بسیار بالاست و **اندیکاسیون قطعی آسیکلوویر "
 "وریدی** است.\n\n"
 "**واریسلای پریناتال** — وقتی مادر در پنجره‌ی **۵ روز پیش تا ۲ روز پس از زایمان** "
 "آبله‌مرغان بگیرد، نوزاد ویروس را از جفت می‌گیرد ولی **آنتی‌بادی محافظ هنوز نرسیده**. "
 "**مرگ‌ومیر تا ۳۰ درصد.**\n\n"
 "⚠️ **قاعده‌ی کلی که از این سؤال بیرون می‌آید:** در آبله‌مرغان، **عارضه‌ی عصبیِ مخچه‌ای "
 "خوش‌خیم است و عارضه‌ی ریوی و مغزی و نوزادی کشنده**. همین یک جمله، چند سؤال این فصل را "
 "پاسخ می‌دهد.",
 "A recall question, but with a clinical distinction worth learning properly: WHICH NEUROLOGICAL "
 "COMPLICATION OF CHICKENPOX SHOULD FRIGHTEN YOU AND WHICH SHOULD NOT.\n\n"
 "THE ANSWER: ACUTE CEREBELLAR ATAXIA.\n\n"
 "WARNING, WHY IS THIS ONE BENIGN?\n\n"
 "Acute cerebellar ataxia is the commonest neurological complication of chickenpox in children "
 "(about 1 IN 4000). It usually begins A WEEK AFTER THE RASH and presents with UNSTEADY GAIT, "
 "INTENTION TREMOR, DYSARTHRIA AND NYSTAGMUS.\n\n"
 "AND THE DECISIVE POINT: IT RESOLVES COMPLETELY AND SPONTANEOUSLY IN 2 TO 4 WEEKS. No specific "
 "treatment, no lasting deficit, and NO REPORTED MORTALITY. Its mechanism is probably "
 "IMMUNE-MEDIATED rather than direct viral invasion — which explains why it is self-limiting.\n\n"
 "AND NOW THE OTHER THREE, ALL OF WHICH KILL:\n\n"
 "VARICELLA ENCEPHALITIS — rarer than the ataxia, but with 5 TO 20 PER CENT MORTALITY and LASTING "
 "NEUROLOGICAL DAMAGE in survivors. Unlike the ataxia, this is true inflammation of brain "
 "parenchyma.\n\n"
 "VARICELLA PNEUMONITIS — THE MOST DANGEROUS COMPLICATION IN ADULTS. Its risk factors: PREGNANCY, "
 "SMOKING and IMMUNOSUPPRESSION. In pregnancy the mortality is very high and it is an ABSOLUTE "
 "INDICATION FOR INTRAVENOUS ACICLOVIR.\n\n"
 "PERINATAL VARICELLA — when the mother develops chickenpox in the window 5 DAYS BEFORE TO 2 DAYS "
 "AFTER DELIVERY, the baby receives the virus across the placenta but THE PROTECTIVE ANTIBODY HAS "
 "NOT YET FOLLOWED. MORTALITY UP TO 30 PER CENT.\n\n"
 "WARNING, THE GENERAL RULE THAT FALLS OUT OF THIS QUESTION: in chickenpox THE CEREBELLAR "
 "COMPLICATION IS BENIGN AND THE PULMONARY, CEREBRAL AND NEONATAL ONES ARE LETHAL. That single "
 "sentence answers several questions in this chapter.",
 ["انسفالیت آبله‌مرغان مرگ‌ومیر ۵ تا ۲۰ درصد دارد و در بازماندگان عوارض عصبی ماندگار می‌گذارد.",
  "پنومونیت واریسلایی خطرناک‌ترین عارضه در بزرگسال است، به‌ویژه در بارداری و سیگاری.",
  "پاسخ صحیح — آتاکسی حاد مخچه‌ای خودبه‌خود در ۲ تا ۴ هفته کامل خوب می‌شود و مرگ‌ومیر ندارد.",
  "واریسلای پریناتال در پنجره‌ی نزدیک زایمان مرگ‌ومیری تا ۳۰ درصد دارد."],
 ["Varicella encephalitis carries 5 to 20 per cent mortality and leaves lasting neurological damage.",
  "Varicella pneumonitis is the most dangerous adult complication, especially in pregnancy and smokers.",
  "Correct — acute cerebellar ataxia resolves completely in 2 to 4 weeks and carries no mortality.",
  "Perinatal varicella in the window around delivery carries mortality up to 30 per cent."],
 "**در آبله‌مرغان، آتاکسی مخچه‌ای خوش‌خیم است؛ ریه و مغز و نوزاد می‌کشند.**",
 "In chickenpox the cerebellar ataxia is benign; the lung, the brain and the neonate are what kill.",
 [H193, VARIZIG])


# =========================================================== book:620
add("book:620", "case", "medium",
 "آبله‌مرغان در **بارداری** ← جدی‌ترین عارضه **پنومونی واریسلایی** است.",
 "Chickenpox IN PREGNANCY: the most serious complication is VARICELLA PNEUMONIA.",
 DIS_FA + [
  "**این سؤال یک قاعده‌ی ساده را می‌سنجد: عارضه‌ی غالب با میزبان تغییر می‌کند.**",
  "**در کودک سالم، عفونت ثانویه‌ی پوست شایع‌ترین عارضه است و پنومونی نادر.**",
  "⚠️ **در بزرگسال، و به‌ویژه در باردار، پنومونی واریسلایی جدی‌ترین خطر است.**",
  "**بروزش در بارداری تا حدود ۱۰ تا ۲۰ درصد موارد آبله‌مرغان بزرگسال گزارش شده.**",
  "**و پیش از دوران آسیکلوویر، مرگ‌ومیرش در بارداری بسیار بالا بود.**",
  "**چرا بارداری خطر را بالا می‌برد؟ دو دلیل مستقل:**",
  "**یک — سرکوب نسبی ایمنی سلولی در بارداری، که کنترل ویروس را ضعیف می‌کند.**",
  "**دو — کاهش ظرفیت باقی‌مانده‌ی ریه با بالا آمدن دیافراگم در سه‌ماهه‌ی سوم.**",
  "⚠️ **علائم هشدار: سرفه، تنگی نفس، تاکی‌پنه — معمولاً ۳ تا ۵ روز پس از راش.**",
  "**هر باردار با آبله‌مرغان و علامت تنفسی باید بستری و آسیکلوویر وریدی بگیرد.**",
  "**سیگار یک عامل خطر مستقل و مهم دیگر است.**",
 ],
 DIS_EN + [
  "This question tests a simple rule: the dominant complication changes with the host.",
  "In a healthy child, secondary skin infection is commonest and pneumonia is rare.",
  "WARNING, IN AN ADULT, AND ABOVE ALL IN PREGNANCY, VARICELLA PNEUMONIA IS THE GRAVEST RISK.",
  "Its incidence in pregnancy is reported in up to 10 to 20 per cent of adult chickenpox cases.",
  "And before the aciclovir era its mortality in pregnancy was very high.",
  "Why does pregnancy raise the risk? Two independent reasons:",
  "ONE — the relative suppression of cellular immunity in pregnancy, which weakens viral control.",
  "TWO — reduced residual lung capacity as the diaphragm rises in the third trimester.",
  "WARNING, THE WARNING SIGNS: cough, breathlessness, tachypnoea — usually 3 to 5 days after the rash.",
  "Any pregnant woman with chickenpox and a respiratory symptom needs admission and intravenous aciclovir.",
  "Smoking is another important independent risk factor.",
 ],
 "این سؤال یک قاعده‌ی مهم را می‌سنجد که در چند سؤال دیگر همین فصل هم به کار می‌آید: "
 "**عارضه‌ی غالب آبله‌مرغان با میزبان عوض می‌شود.**\n\n"
 "**خانم ۲۵ ساله‌ی حامله** با ضایعات ماکولر، پاپولر، وزیکول و پوستول، خارش شدید و تب از "
 "۳ روز پیش. **کدام عارضه در این بیمار جدی‌تر است؟**\n\n"
 "⚠️ **پاسخ: پنومونی واریسلایی.**\n\n"
 "اگر همین سؤال درباره‌ی **یک کودک سالم** بود، پاسخ **عفونت ثانویه‌ی باکتریال پوست** "
 "می‌شد — که در کودکان شایع‌ترین عارضه است. ولی این بیمار **بزرگسال و باردار** است، و "
 "این دو کلمه صورت مسئله را عوض می‌کنند.\n\n"
 "**چرا بارداری خطر پنومونی را این‌قدر بالا می‌برد؟ دو دلیل مستقل و هم‌افزا:**\n\n"
 "**دلیل یک — ایمنی سلولی.** بارداری با یک **سرکوب نسبی و فیزیولوژیک ایمنی سلولی** همراه "
 "است (تا جنین پس زده نشود). و کنترل ویروس واریسلا **کاملاً وابسته به ایمنی سلولی** است. "
 "پس ویروس فرصت انتشار بیشتری پیدا می‌کند.\n\n"
 "**دلیل دو — مکانیک ریه.** در سه‌ماهه‌ی سوم، **بالا آمدن دیافراگم ظرفیت باقی‌مانده‌ی "
 "عملکردی ریه را کم می‌کند**. پس همان میزان درگیری ریوی، نارسایی تنفسی شدیدتری می‌سازد.\n\n"
 "⚠️ **علائم هشدار که باید بشناسید:** سرفه، تنگی نفس و تاکی‌پنه، معمولاً **۳ تا ۵ روز پس "
 "از شروع راش**. **هر زن بارداری که با آبله‌مرغان و یک علامت تنفسی مراجعه کند، باید بستری "
 "شود و آسیکلوویر وریدی بگیرد** — این یک فوریت است، نه یک تصمیم قابل تعویق.\n\n"
 "**چرا سه گزینه‌ی دیگر نه؟** **آنسفالیت** نادرتر است و در بارداری خطر ویژه‌ای ندارد. "
 "**هپاتیت** در آبله‌مرغانِ فرد سالم معمولاً خفیف و بدون علامت است. **عفونت پوستی** شایع "
 "است ولی **جدی‌ترین** نیست — و سؤال دقیقاً کلمه‌ی «جدی‌تر» را به کار برده.\n\n"
 "**عامل خطر مهم دیگری که باید بدانید: سیگار.** سیگاری بودن، مستقل از بارداری، خطر "
 "پنومونی واریسلایی را به‌شدت بالا می‌برد.",
 "This question tests an important rule that recurs in this chapter: THE DOMINANT COMPLICATION OF "
 "CHICKENPOX CHANGES WITH THE HOST.\n\n"
 "A 25-YEAR-OLD PREGNANT WOMAN with macular, papular, vesicular and pustular lesions, intense "
 "itching and fever for three days. WHICH COMPLICATION IS MORE SERIOUS IN THIS PATIENT?\n\n"
 "WARNING, THE ANSWER: VARICELLA PNEUMONIA.\n\n"
 "Had the same question concerned A HEALTHY CHILD, the answer would be SECONDARY BACTERIAL SKIN "
 "INFECTION, the commonest complication in children. But this patient is AN ADULT AND PREGNANT, "
 "and those two words change the problem.\n\n"
 "WHY DOES PREGNANCY RAISE THE PNEUMONIA RISK SO MUCH? Two independent, additive reasons:\n\n"
 "REASON ONE — CELLULAR IMMUNITY. Pregnancy carries a RELATIVE PHYSIOLOGICAL SUPPRESSION OF "
 "CELLULAR IMMUNITY (so the fetus is not rejected). And control of varicella is ENTIRELY DEPENDENT "
 "ON CELLULAR IMMUNITY. So the virus finds more opportunity to disseminate.\n\n"
 "REASON TWO — LUNG MECHANICS. In the third trimester THE RISING DIAPHRAGM REDUCES FUNCTIONAL "
 "RESIDUAL CAPACITY. So the same degree of lung involvement produces more severe respiratory "
 "failure.\n\n"
 "WARNING, THE WARNING SIGNS TO RECOGNISE: cough, breathlessness and tachypnoea, usually 3 TO 5 "
 "DAYS AFTER THE RASH BEGINS. ANY PREGNANT WOMAN PRESENTING WITH CHICKENPOX AND A RESPIRATORY "
 "SYMPTOM MUST BE ADMITTED AND GIVEN INTRAVENOUS ACICLOVIR — this is an emergency, not a decision "
 "that can wait.\n\n"
 "WHY NOT THE OTHER THREE? ENCEPHALITIS is rarer and carries no special pregnancy risk. HEPATITIS "
 "in chickenpox in a healthy person is usually mild and asymptomatic. SKIN INFECTION is common but "
 "not the MOST SERIOUS — and the question uses precisely the word 'more serious'.\n\n"
 "ANOTHER IMPORTANT RISK FACTOR TO KNOW: SMOKING. Independently of pregnancy, smoking sharply "
 "raises the risk of varicella pneumonia.",
 ["آنسفالیت نادرتر است و بارداری خطر ویژه‌ای برای آن ایجاد نمی‌کند.",
  "هپاتیت در آبله‌مرغان فرد سالم معمولاً خفیف و بدون علامت است.",
  "عفونت ثانویه‌ی پوست شایع است ولی جدی‌ترین عارضه نیست؛ سؤال «جدی‌تر» را می‌پرسد.",
  "پاسخ صحیح — پنومونی واریسلایی در بارداری جدی‌ترین عارضه است و آسیکلوویر وریدی می‌خواهد."],
 ["Encephalitis is rarer and pregnancy creates no special risk for it.",
  "Hepatitis in chickenpox in a healthy person is usually mild and asymptomatic.",
  "Secondary skin infection is common but not the most serious; the question asks for 'more serious'.",
  "Correct — varicella pneumonia is the gravest complication in pregnancy and needs intravenous aciclovir."],
 "**عارضه‌ی غالب با میزبان عوض می‌شود: کودک ← پوست، باردار ← ریه، نقص ایمنی ← احشا.**",
 "The dominant complication changes with the host: skin in a child, lung in pregnancy, viscera in immunosuppression.",
 [H193, RCOG13])


# =========================================================== book:623
add("book:623", "case", "medium",
 "دوره‌ی سرایت آبله‌مرغان تا **خشک شدن همه‌ی ضایعات** است — حدود **۵ روز** پس از راش.",
 "Chickenpox stays infectious until EVERY LESION HAS CRUSTED — about 5 days after the rash.",
 DIS_FA + [
  "**این سؤال یک عدد می‌خواهد، ولی پشتش یک اصل است که باید جای عدد یاد بگیرید.**",
  "⚠️ **معیار واقعی پایان سرایت، «کراست شدن همه‌ی ضایعات» است، نه گذشت تعداد روز.**",
  "**ولی چون سؤال عدد می‌خواهد: این معمولاً حدود ۵ روز پس از شروع راش طول می‌کشد.**",
  "**و دوره‌ی سرایت از ۱ تا ۲ روز پیش از ظاهر شدن راش شروع می‌شود —**",
  "⚠️ **یعنی بیمار پیش از آنکه بداند بیمار است، دیگران را آلوده کرده.**",
  "**همین ویژگی، آبله‌مرغان را چنین همه‌گیر می‌کند: میزان حمله‌ی خانگی حدود ۸۵ درصد.**",
  "**راه انتقال دوگانه است و هر دو را باید بدانید:**",
  "**یک — قطرات تنفسی و ذرات هوابرد از دستگاه تنفس.**",
  "**دو — تماس مستقیم با مایع وزیکول‌ها.**",
  "⚠️ **و به همین دلیل ایزولاسیون بستری باید هم تماسی و هم هوابرد باشد.**",
  "**در بیمار دچار نقص ایمنی، ضایعات تازه ممکن است بیش از یک هفته ادامه یابد،**",
  "**پس دوره‌ی سرایتش هم طولانی‌تر است و قاعده‌ی «همه کراست شوند» مهم‌تر می‌شود.**",
 ],
 DIS_EN + [
  "This question wants a number, but behind it is a principle you should learn instead of the number.",
  "WARNING: THE REAL CRITERION FOR THE END OF INFECTIVITY IS THAT EVERY LESION HAS CRUSTED, not that days have passed.",
  "But since the question asks for a figure: that usually takes about 5 days from the onset of the rash.",
  "And infectivity BEGINS 1 to 2 days BEFORE the rash appears —",
  "WARNING: SO THE PATIENT HAS ALREADY INFECTED OTHERS BEFORE KNOWING THEY ARE ILL.",
  "That feature is what makes chickenpox so contagious: the household attack rate is about 85 per cent.",
  "Transmission is by two routes and you must know both:",
  "ONE — respiratory droplets and airborne particles from the respiratory tract.",
  "TWO — direct contact with vesicle fluid.",
  "WARNING, AND THAT IS WHY INPATIENT ISOLATION MUST BE BOTH CONTACT AND AIRBORNE.",
  "In an immunocompromised patient new lesions may keep appearing for more than a week,",
  "so infectivity lasts longer and the 'all crusted' rule matters even more.",
 ],
 "این سؤال در ظاهر یک عدد می‌خواهد، ولی پشتش یک **اصل** هست که ارزشش از عدد بیشتر است.\n\n"
 "**نوجوان ۱۶ ساله** با ضایعات ماکول، پاپول، وزیکول و پوستول خارش‌دار، با تب خفیف از ۲ روز "
 "پیش از راش. **تا چند روز پس از بروز ضایعات باید از تماس نزدیک پرهیز کرد؟**\n\n"
 "**پاسخ: ۵ روز.**\n\n"
 "⚠️ **ولی عدد را حفظ نکنید — اصل را حفظ کنید:**\n\n"
 "> **بیمار تا زمانی مسری است که همه‌ی ضایعاتش کراست (دلمه) ببندند.**\n\n"
 "و در یک فرد سالم، این معمولاً **حدود ۵ روز** پس از شروع راش طول می‌کشد. **پس ۵ روز یک "
 "تخمین است، نه یک قانون.**\n\n"
 "**چرا این تمایز مهم است؟** چون در **بیمار دچار نقص ایمنی**، ضایعات تازه ممکن است **بیش "
 "از یک هفته** ادامه پیدا کند. اگر عدد را حفظ کرده باشید، چنین بیماری را زودتر از موعد از "
 "ایزوله بیرون می‌آورید. اگر **اصل** را بدانید، منتظر کراست شدن می‌مانید.\n\n"
 "⚠️ **و یک نکته‌ی مهم دیگر که در همین سؤال پنهان است: بیمار «۲ روز قبل از بروز علائم» تب "
 "داشته.**\n\n"
 "**دوره‌ی سرایت آبله‌مرغان از ۱ تا ۲ روز پیش از ظاهر شدن راش شروع می‌شود.** یعنی بیمار "
 "**پیش از آنکه بداند آبله‌مرغان دارد، دیگران را آلوده کرده است**. همین ویژگی توضیح می‌دهد "
 "چرا **میزان حمله‌ی خانگی حدود ۸۵ درصد** است و چرا کنترل شیوع آن بدون واکسن تقریباً "
 "ناممکن است.\n\n"
 "**راه انتقال دوگانه است:**\n\n"
 "**یک — قطرات تنفسی و ذرات هوابرد** از دستگاه تنفس (پیش از راش هم فعال است)\n\n"
 "**دو — تماس مستقیم با مایع وزیکول‌ها**\n\n"
 "**و چون یکی از راه‌ها هوابرد است، ایزولاسیون بیمار بستری باید هم «تماسی» و هم «هوابرد» "
 "باشد** — نکته‌ای که سؤال دیگری در همین فصل مستقیماً می‌پرسد.",
 "On the surface this question wants a number, but behind it is a PRINCIPLE worth more than the "
 "number.\n\n"
 "A 16-YEAR-OLD with itchy macules, papules, vesicles and pustules, with mild fever from two days "
 "before the rash. FOR HOW MANY DAYS AFTER THE LESIONS APPEAR SHOULD CLOSE CONTACT BE AVOIDED?\n\n"
 "THE ANSWER: 5 DAYS.\n\n"
 "WARNING, BUT DO NOT MEMORISE THE NUMBER — MEMORISE THE PRINCIPLE:\n\n"
 "> THE PATIENT IS INFECTIOUS UNTIL EVERY LESION HAS CRUSTED.\n\n"
 "And in a healthy person that usually takes ABOUT 5 DAYS from the onset of the rash. SO 5 IS AN "
 "ESTIMATE, NOT A LAW.\n\n"
 "WHY DOES THAT DISTINCTION MATTER? Because in an IMMUNOCOMPROMISED patient new lesions may keep "
 "appearing FOR MORE THAN A WEEK. If you memorised the number you would release such a patient "
 "from isolation too early. If you know the PRINCIPLE you wait for crusting.\n\n"
 "WARNING, AND ANOTHER IMPORTANT POINT HIDDEN IN THIS STEM: the patient had fever 'two days before "
 "the symptoms appeared'.\n\n"
 "CHICKENPOX BECOMES INFECTIOUS 1 TO 2 DAYS BEFORE THE RASH APPEARS. That is, THE PATIENT HAS "
 "ALREADY INFECTED OTHERS BEFORE KNOWING THEY HAVE CHICKENPOX. This feature explains why the "
 "HOUSEHOLD ATTACK RATE IS ABOUT 85 PER CENT and why controlling outbreaks without vaccination is "
 "nearly impossible.\n\n"
 "TRANSMISSION IS BY TWO ROUTES:\n\n"
 "ONE — RESPIRATORY DROPLETS AND AIRBORNE PARTICLES from the respiratory tract (active even before "
 "the rash)\n\n"
 "TWO — DIRECT CONTACT WITH VESICLE FLUID\n\n"
 "AND BECAUSE ONE ROUTE IS AIRBORNE, INPATIENT ISOLATION MUST BE BOTH CONTACT AND AIRBORNE — a "
 "point another question in this chapter asks directly.",
 ["۲ روز بسیار کوتاه است؛ در این زمان هنوز ضایعات تازه در حال ظاهر شدن‌اند.",
  "۳ روز هم کافی نیست، چون معمولاً هنوز همه‌ی ضایعات کراست نبسته‌اند.",
  "پاسخ صحیح — حدود ۵ روز، که زمان معمول کراست بستن همه‌ی ضایعات در فرد سالم است.",
  "۱۴ روز بسیار طولانی‌تر از لازم است و ایزوله‌ی بی‌مورد تحمیل می‌کند."],
 ["Two days is far too short; new lesions are still appearing at that point.",
  "Three days is also inadequate, as not all lesions have usually crusted yet.",
  "Correct — about 5 days, the usual time for all lesions to crust in a healthy person.",
  "Fourteen days is much longer than necessary and imposes needless isolation."],
 "**معیار، کراست شدن همه‌ی ضایعات است، نه تعداد روز.** و سرایت ۲ روز پیش از راش شروع شده.",
 "The criterion is that every lesion has crusted, not a count of days; and infectivity began two days before the rash.",
 [H193, VARIZIG])


# =========================================================== book:628
add("book:628", "case", "hard",
 "کودک **لوسمی تحت شیمی‌درمانی**، تماس ۶ روز پیش ← واکسن ممنوع، VZIG دیر ← **آسیکلوویر**.",
 "A child with LEUKAEMIA on chemotherapy exposed 6 days ago: vaccine forbidden, VZIG late, so ACICLOVIR.",
 PEP_FA + [
  "**سه فیلتر را پشت سر هم اجرا کنید و ببینید چه چیزی باقی می‌ماند.**",
  "**فیلتر یک — آیا مستعد است؟ بله: سابقه‌ی ابتلای قبلی ندارد.**",
  "**فیلتر دو — آیا پرخطر است؟ بله: لوسمی تحت شیمی‌درمانی، یعنی نقص ایمنی شدید.**",
  "⚠️ **فیلتر سه — و اینجا واکسن حذف می‌شود: واکسن واریسلا زنده‌ی ضعیف‌شده است.**",
  "**در نقص ایمنی سلولی، واکسن زنده می‌تواند خودش بیماری منتشر بسازد. ممنوع مطلق.**",
  "**پس بین VZIG و آسیکلوویر می‌مانیم — و زمان تصمیم می‌گیرد.**",
  "**تماس ۶ روز پیش بوده. VZIG تا ۱۰ روز مجاز است، ولی اثرش با گذشت زمان افت می‌کند.**",
  "⚠️ **و پنجره‌ی آسیکلوویر دقیقاً از روز هفتم باز می‌شود — یعنی فردا.**",
  "**پس آسیکلوویر خوراکی از روز هفتم، انتخاب منطبق با زمان‌بندی است.**",
  "**در عمل، اگر VZIG در دسترس باشد ترجیح دارد و آسیکلوویر جایگزین یا مکمل آن است.**",
  "**دوز آسیکلوویر پروفیلاکسی در کودک: ۲۰ میلی‌گرم بر کیلوگرم، چهار بار در روز، ۷ روز.**",
  "⚠️ **و صرف‌نظر از انتخاب، این کودک باید تا روز ۲۸ برای بروز بیماری پایش شود.**",
 ],
 PEP_EN + [
  "Run the three filters in order and see what survives.",
  "FILTER ONE — is he susceptible? Yes: he has no history of previous chickenpox.",
  "FILTER TWO — is he high risk? Yes: leukaemia on chemotherapy, that is severe immunosuppression.",
  "WARNING, FILTER THREE — AND HERE THE VACCINE FALLS: the varicella vaccine is LIVE ATTENUATED.",
  "In cellular immunodeficiency a live vaccine can itself cause disseminated disease. Absolutely contraindicated.",
  "So we are left between VZIG and aciclovir — and the timing decides.",
  "The exposure was 6 days ago. VZIG is permitted up to 10 days, but its effect falls with time.",
  "WARNING, AND THE ACICLOVIR WINDOW OPENS EXACTLY ON DAY SEVEN — that is, tomorrow.",
  "So oral aciclovir from day 7 is the choice that fits the timing.",
  "In practice, if VZIG is available it is preferred, with aciclovir as an alternative or an addition.",
  "The prophylactic aciclovir dose in a child: 20 mg/kg four times daily for 7 days.",
  "WARNING, AND WHATEVER IS CHOSEN, THIS CHILD MUST BE WATCHED FOR DISEASE UNTIL DAY 28.",
 ],
 "این سؤال یکی از بهترین نمونه‌های «سه فیلتر پشت سر هم» در این فصل است.\n\n"
 "**کودک مبتلا به ALL تحت شیمی‌درمانی**، که **شش روز پیش** با برادر مبتلا به آبله‌مرغان "
 "**تماس نزدیک** داشته و **سابقه‌ی ابتلای قبلی ندارد**.\n\n"
 "⚠️ **فیلتر یک — آیا مستعد است؟**\n\n"
 "**بله.** «سابقه‌ی ابتلای قبلی ندارد» صریحاً در صورت سؤال آمده. اگر ابتلای قبلی یا دو دوز "
 "واکسن داشت، **هیچ اقدامی لازم نبود** و سؤال همان‌جا تمام می‌شد.\n\n"
 "⚠️ **فیلتر دو — آیا پرخطر است؟**\n\n"
 "**بله، و به‌شدت.** لوسمی حاد لنفوبلاستیک تحت شیمی‌درمانی = **نقص ایمنی سلولی شدید**. و "
 "کنترل ویروس واریسلا **کاملاً به ایمنی سلولی وابسته** است. در چنین کودکی، آبله‌مرغان "
 "می‌تواند **منتشر** شود و کبد، ریه و مغز را درگیر کند، با مرگ‌ومیر بالا.\n\n"
 "⚠️ **فیلتر سه — و اینجا دو گزینه حذف می‌شوند:**\n\n"
 "**واکسن واریسلا یک واکسن زنده‌ی ضعیف‌شده است.** در بیماری با نقص ایمنی سلولی، **خودِ "
 "ویروس واکسن** می‌تواند تکثیر یابد و بیماری منتشر بسازد. **این یک ممنوعیت مطلق است** — و "
 "همین دو گزینه‌ی حاوی واکسن را از بین می‌برد.\n\n"
 "**پس بین VZIG و آسیکلوویر می‌مانیم. و زمان تصمیم می‌گیرد:**\n\n"
 "• **تماس ۶ روز پیش بوده.** VZIG تا **۱۰ روز** مجاز است، ولی **بیشترین اثرش در ۹۶ ساعت "
 "اول** است و با گذشت زمان افت می‌کند.\n\n"
 "• **و پنجره‌ی آسیکلوویر دقیقاً از روز هفتم باز می‌شود** — یعنی **فردا**.\n\n"
 "**پس آسیکلوویر، انتخاب منطبق با زمان‌بندی این بیمار است.** ✅\n\n"
 "⚠️ **و حالا مهم‌ترین نکته‌ی مفهومی: چرا آسیکلوویر از روز هفتم و نه فوراً؟**\n\n"
 "این عجیب‌ترین بخش قاعده است و دلیلش یک کارآزمایی است. در کودکان سالمِ در معرض تماس:\n\n"
 "• **شروع فوری آسیکلوویر** ← **۱۰ نفر از ۱۳ نفر (۷۷٪)** آبله‌مرغان گرفتند\n"
 "• **شروع در روز هفتم** ← فقط **۳ نفر از ۱۴ نفر (۲۱٪)**\n\n"
 "**چرا؟** شروع خیلی زود، ویروس را **پیش از آنکه سیستم ایمنی آن را ببیند** سرکوب می‌کند. "
 "پس **پاسخ ایمنی ساخته نمی‌شود**، و به‌محض قطع دارو بیماری ظاهر می‌شود. **روز هفتم مصادف "
 "با اوج تکثیر ویروسی است** — همان‌جا که دارو بیشترین اثر را دارد و ایمنی هم فرصت شکل "
 "گرفتن داشته است.\n\n"
 "**نکته‌ی عملی:** در بیمار با نقص ایمنی شدید، اگر **VZIG در دسترس باشد** معمولاً ترجیح "
 "دارد و آسیکلوویر مکمل یا جایگزین آن است. **و در هر حال، این کودک باید تا روز ۲۸ پایش "
 "شود** — چون VZIG می‌تواند دوره‌ی کمون را طولانی کند.",
 "This is one of the clearest 'three filters in a row' questions in the chapter.\n\n"
 "A CHILD WITH ALL ON CHEMOTHERAPY who had CLOSE CONTACT six days ago with a brother who has "
 "chickenpox, and who HAS NO HISTORY OF PREVIOUS INFECTION.\n\n"
 "WARNING, FILTER ONE — IS HE SUSCEPTIBLE?\n\n"
 "YES. 'No history of previous infection' is stated explicitly. Had he had previous disease or two "
 "vaccine doses, NOTHING WOULD BE NEEDED and the question would end there.\n\n"
 "WARNING, FILTER TWO — IS HE HIGH RISK?\n\n"
 "YES, SEVERELY. Acute lymphoblastic leukaemia on chemotherapy means SEVERE CELLULAR "
 "IMMUNODEFICIENCY. And control of varicella is ENTIRELY DEPENDENT ON CELLULAR IMMUNITY. In such a "
 "child chickenpox can DISSEMINATE to liver, lung and brain, with high mortality.\n\n"
 "WARNING, FILTER THREE — AND HERE TWO OPTIONS FALL:\n\n"
 "THE VARICELLA VACCINE IS LIVE ATTENUATED. In a patient with cellular immunodeficiency THE VACCINE "
 "VIRUS ITSELF can replicate and cause disseminated disease. THIS IS AN ABSOLUTE "
 "CONTRAINDICATION — and it destroys both options containing the vaccine.\n\n"
 "SO WE ARE LEFT BETWEEN VZIG AND ACICLOVIR, AND THE TIMING DECIDES:\n\n"
 "• THE EXPOSURE WAS 6 DAYS AGO. VZIG is allowed up to 10 DAYS, but ITS GREATEST EFFECT IS IN THE "
 "FIRST 96 HOURS and it declines thereafter.\n\n"
 "• AND THE ACICLOVIR WINDOW OPENS EXACTLY ON DAY SEVEN — that is, TOMORROW.\n\n"
 "SO ACICLOVIR IS THE CHOICE THAT FITS THIS PATIENT'S TIMING.\n\n"
 "WARNING, AND NOW THE KEY CONCEPT: why aciclovir from day 7 rather than at once?\n\n"
 "This is the strangest part of the rule and its reason is a trial. In healthy exposed children:\n\n"
 "• IMMEDIATE ACICLOVIR -> 10 OF 13 (77 PER CENT) developed chickenpox\n"
 "• START ON DAY 7 -> only 3 OF 14 (21 PER CENT)\n\n"
 "WHY? Starting too early suppresses the virus BEFORE THE IMMUNE SYSTEM HAS SEEN IT. So NO IMMUNE "
 "RESPONSE IS BUILT, and as soon as the drug stops the disease appears. DAY SEVEN COINCIDES WITH "
 "PEAK VIRAL REPLICATION — where the drug does most good and immunity has had time to form.\n\n"
 "A PRACTICAL NOTE: in a severely immunocompromised patient, IF VZIG IS AVAILABLE it is usually "
 "preferred, with aciclovir as an addition or alternative. AND EITHER WAY THIS CHILD MUST BE "
 "WATCHED UNTIL DAY 28, because VZIG can prolong the incubation period.",
 ["VZIG گزینه‌ی معتبری است ولی بیشترین اثرش در ۹۶ ساعت اول است و اینجا ۶ روز گذشته.",
  "واکسن واریسلا زنده‌ی ضعیف‌شده است و در نقص ایمنی سلولی ممنوعیت مطلق دارد.",
  "ایمونوگلوبولین وریدی عمومی جایگزین ضعیف‌تری است و وقتی VZIG یا آسیکلوویر هست ارجح نیست.",
  "پاسخ صحیح — واکسن ممنوع است و با گذشت ۶ روز، آسیکلوویر از روز هفتم انتخاب منطبق با زمان است."],
 ["VZIG is a valid option but works best within 96 hours, and six days have passed here.",
  "The varicella vaccine is live attenuated and absolutely contraindicated in cellular immunodeficiency.",
  "Pooled intravenous immunoglobulin is a weaker substitute and is not preferred when VZIG or aciclovir is available.",
  "Correct — the vaccine is forbidden and, six days out, aciclovir from day 7 fits the timing."],
 "**واکسن زنده در نقص ایمنی ممنوع.** و آسیکلوویر پروفیلاکسی از روز هفتم شروع می‌شود، نه فوراً.",
 "A live vaccine is forbidden in immunodeficiency, and prophylactic aciclovir starts on day seven, not at once.",
 [VARIZIG, UKHSA])


# =========================================================== book:627
add("book:627", "case", "hard",
 "باردار مستعد، تماس **۵ روز پیش** ← واکسن ممنوع (زنده) ← **آسیکلوویر از روز هفتم**.",
 "A susceptible pregnant contact 5 days out: the vaccine is forbidden (live), so ACICLOVIR FROM DAY 7.",
 PEP_FA + [
  "**در بارداری، همان سه فیلتر اجرا می‌شود ولی یک ممنوعیت قطعی اضافه دارد.**",
  "⚠️ **واکسن واریسلا در بارداری ممنوع است، چون زنده‌ی ضعیف‌شده است.**",
  "**پس هر گزینه‌ای که واکسن پیشنهاد کند، بدون بررسی بیشتر حذف می‌شود.**",
  "**می‌ماند: VZIG یا آسیکلوویر — و زمان تعیین می‌کند.**",
  "**تماس ۵ روز پیش بوده، پس هنوز در پنجره‌ی ۱۰ روزه‌ی VZIG هستیم.**",
  "⚠️ **ولی راهنمای امروزی (UKHSA و RCOG) آنتی‌ویروال خوراکی را انتخاب اول می‌داند.**",
  "**آسیکلوویر ۸۰۰ میلی‌گرم چهار بار در روز، از روز ۷ تا روز ۱۴ پس از تماس.**",
  "**VZIG فقط برای کسی که نمی‌تواند خوراکی بگیرد (سوءجذب یا سمیت کلیوی).**",
  "⚠️ **و دلیلش صراحت دارد: اثر VZIG در پیشگیری از آبله‌مرغان بالینی «زیربهینه» است.**",
  "**VZIG بیماری را تخفیف می‌دهد ولی از عفونت جنین جلوگیری نمی‌کند.**",
  "**هدف اصلی پروفیلاکسی در باردار، محافظت از خودِ مادر است، نه جنین.**",
  "**چون پنومونی واریسلایی در بارداری همان چیزی است که مادر را می‌کشد.**",
 ],
 PEP_EN + [
  "In pregnancy the same three filters run, but with one absolute extra prohibition.",
  "WARNING: THE VARICELLA VACCINE IS FORBIDDEN IN PREGNANCY because it is live attenuated.",
  "So any option proposing the vaccine falls without further consideration.",
  "That leaves VZIG or aciclovir — and the timing decides.",
  "The exposure was 5 days ago, so we are still inside the 10-day VZIG window.",
  "WARNING, BUT TODAY'S GUIDANCE (UKHSA and RCOG) MAKES ORAL ANTIVIRALS FIRST CHOICE.",
  "Aciclovir 800 mg four times daily, from day 7 to day 14 after exposure.",
  "VZIG only for someone who cannot take oral medication (malabsorption or renal toxicity).",
  "WARNING, AND THE REASON IS STATED PLAINLY: VZIG's efficacy in PREVENTING clinical chickenpox is suboptimal.",
  "VZIG attenuates the illness but does not prevent fetal infection.",
  "The main aim of prophylaxis in pregnancy is TO PROTECT THE MOTHER, not the fetus.",
  "Because varicella pneumonia in pregnancy is what kills the mother.",
 ],
 "این سؤال همان الگوریتم سؤال قبل را دارد، ولی در یک میزبان متفاوت — و **یک ممنوعیت "
 "اضافه**.\n\n"
 "**خانم ۲۵ ساله‌ی باردار**، تماس با کودک مبتلا به آبله‌مرغان **۵ روز پیش**، **بدون سابقه‌ی "
 "ابتلا و بدون واکسیناسیون**، و **هیچ اقدامی هم انجام نداده**.\n\n"
 "⚠️ **فیلتر یک — مستعد است؟ بله**، صریحاً ذکر شده.\n\n"
 "⚠️ **فیلتر دو — پرخطر است؟ بله**، بارداری یکی از سه گروه پرخطر است.\n\n"
 "⚠️ **فیلتر سه — و اینجا یک ممنوعیت قطعی وارد می‌شود:**\n\n"
 "**واکسن واریسلا یک واکسن زنده‌ی ضعیف‌شده است و در بارداری ممنوع است.** پس گزینه‌ی "
 "«دریافت واکسن در اسرع وقت» **بدون هیچ بررسی دیگری حذف می‌شود** — صرف‌نظر از اینکه چند "
 "روز گذشته باشد.\n\n"
 "**می‌ماند VZIG و آسیکلوویر.** و اینجا سؤال ظریف می‌شود، چون **۵ روز گذشته و هنوز در "
 "پنجره‌ی ۱۰ روزه‌ی VZIG هستیم**. پس چرا آسیکلوویر؟\n\n"
 "⚠️ **پاسخ در راهنمای امروزی است، و منطقش آموزنده:**\n\n"
 "راهنمای **UKHSA** و **RCOG (بازنگری ۲۰۲۴)** صریحاً **آنتی‌ویروال خوراکی را انتخاب اول** "
 "برای تماس باردار مستعد در **هر مرحله‌ی بارداری** می‌دانند، و **VZIG را فقط برای کسی نگه "
 "می‌دارند که نمی‌تواند خوراکی بگیرد** (سوءجذب یا سمیت کلیوی).\n\n"
 "**دلیلش صراحت دارد: اثربخشی VZIG در پیشگیری از آبله‌مرغان بالینی «زیربهینه» است.** "
 "مطالعات نشان داده‌اند VZIG **بیماری را تخفیف می‌دهد** ولی **از عفونت جلوگیری نمی‌کند** — "
 "و در باردار **مانع عفونت جنین هم نمی‌شود**.\n\n"
 "⚠️ **و نکته‌ای که اغلب بد فهمیده می‌شود:**\n\n"
 "> **هدف اصلی پروفیلاکسی در زن باردار، محافظت از خودِ مادر است، نه جنین.**\n\n"
 "چون **پنومونی واریسلایی در بارداری همان چیزی است که مادر را می‌کشد**. محافظت از جنین "
 "یک فایده‌ی ثانوی و نامطمئن است.\n\n"
 "**دوز: آسیکلوویر ۸۰۰ میلی‌گرم چهار بار در روز، از روز ۷ تا روز ۱۴ پس از تماس.** "
 "(یا والاسیکلوویر ۱۰۰۰ میلی‌گرم سه بار در روز، که فراهمی زیستی بهتری دارد.)\n\n"
 "**و به بیمار باید گفت:** حتی با پروفیلاکسی، اگر راشی ظاهر شد **فوراً مراجعه کند**، چون "
 "دوز درمانی و احتمالاً بستری لازم می‌شود.",
 "This question runs the same algorithm as the previous one but in a different host — and with ONE "
 "EXTRA PROHIBITION.\n\n"
 "A 25-YEAR-OLD PREGNANT WOMAN, contact with a child who has chickenpox FIVE DAYS AGO, with NO "
 "PREVIOUS INFECTION AND NO VACCINATION, and who has taken no action.\n\n"
 "WARNING, FILTER ONE — susceptible? YES, stated explicitly.\n\n"
 "WARNING, FILTER TWO — high risk? YES, pregnancy is one of the three high-risk groups.\n\n"
 "WARNING, FILTER THREE — AND HERE AN ABSOLUTE PROHIBITION ENTERS:\n\n"
 "THE VARICELLA VACCINE IS LIVE ATTENUATED AND IS FORBIDDEN IN PREGNANCY. So the option 'give the "
 "vaccine as soon as possible' FALLS WITHOUT ANY FURTHER CONSIDERATION — however many days have "
 "passed.\n\n"
 "THAT LEAVES VZIG AND ACICLOVIR. And here the question becomes subtle, because FIVE DAYS HAVE "
 "PASSED AND WE ARE STILL INSIDE THE 10-DAY VZIG WINDOW. So why aciclovir?\n\n"
 "WARNING, THE ANSWER IS IN CURRENT GUIDANCE, AND ITS LOGIC IS INSTRUCTIVE:\n\n"
 "UKHSA and RCOG (2024 revision) explicitly make ORAL ANTIVIRALS FIRST CHOICE for a susceptible "
 "pregnant contact AT ANY STAGE OF PREGNANCY, and RESERVE VZIG for those who cannot take oral "
 "medication (malabsorption or renal toxicity).\n\n"
 "THE REASON IS STATED PLAINLY: VZIG'S EFFICACY IN PREVENTING CLINICAL CHICKENPOX IS SUBOPTIMAL. "
 "Studies show VZIG ATTENUATES the illness but DOES NOT PREVENT INFECTION — and in pregnancy it "
 "DOES NOT PREVENT FETAL INFECTION EITHER.\n\n"
 "WARNING, AND A POINT OFTEN MISUNDERSTOOD:\n\n"
 "> THE MAIN AIM OF PROPHYLAXIS IN A PREGNANT WOMAN IS TO PROTECT THE MOTHER, NOT THE FETUS.\n\n"
 "Because VARICELLA PNEUMONIA IN PREGNANCY IS WHAT KILLS THE MOTHER. Fetal protection is a "
 "secondary and unreliable benefit.\n\n"
 "THE DOSE: aciclovir 800 mg four times daily, from DAY 7 TO DAY 14 after exposure. (Or valaciclovir "
 "1000 mg three times daily, which has better bioavailability.)\n\n"
 "AND THE PATIENT MUST BE TOLD: even with prophylaxis, if a rash appears she should SEEK CARE "
 "IMMEDIATELY, because a therapeutic dose and probably admission will be needed.",
 ["VZIG در پنجره‌ی زمانی هست ولی راهنمای امروزی آن را فقط برای کسی که نمی‌تواند خوراکی بگیرد نگه می‌دارد.",
  "واکسن واریسلا زنده‌ی ضعیف‌شده است و در بارداری ممنوعیت مطلق دارد.",
  "پاسخ صحیح — آنتی‌ویروال خوراکی انتخاب اول در بارداری است، از روز ۷ تا ۱۴ پس از تماس.",
  "پروفیلاکسی قطعاً توصیه می‌شود: باردار مستعد یکی از سه گروه پرخطر است."],
 ["VZIG is within the window, but current guidance reserves it for those who cannot take oral antivirals.",
  "The varicella vaccine is live attenuated and absolutely contraindicated in pregnancy.",
  "Correct — an oral antiviral is first choice in pregnancy, from day 7 to day 14 after exposure.",
  "Prophylaxis is certainly recommended: a susceptible pregnant contact is one of the three high-risk groups."],
 "**واکسن زنده در بارداری ممنوع.** و هدف پروفیلاکسی در باردار، محافظت از مادر است نه جنین.",
 "A live vaccine is forbidden in pregnancy, and the aim of prophylaxis there is to protect the mother, not the fetus.",
 [UKHSA, RCOG13])


# =========================================================== book:631
add("book:631", "case", "medium",
 "آبله‌مرغان بستری ← ایزولاسیون **هوابرد (تنفسی)** لازم است، نه فقط تماسی.",
 "An admitted chickenpox patient needs AIRBORNE isolation, not merely contact precautions.",
 DIS_FA + [
  "**این سؤال یک تصمیم کنترل عفونت است و پاسخش از راه انتقال ویروس می‌آید.**",
  "⚠️ **ویروس واریسلا زوستر دو راه انتقال دارد و هر دو باید پوشش داده شوند.**",
  "**راه یک — تماس مستقیم با مایع وزیکول‌ها (احتیاطات تماسی).**",
  "**راه دو — ذرات هوابرد از دستگاه تنفس (احتیاطات هوابرد).**",
  "⚠️ **راه دوم است که واریسلا را از بیشتر بیماری‌های وزیکولر جدا می‌کند.**",
  "**ذرات هوابرد ریزند، مدت‌ها معلق می‌مانند و در کل اتاق پخش می‌شوند.**",
  "**پس ماسک جراحی و دستکش کافی نیست: اتاق فشار منفی و ماسک N95 لازم است.**",
  "**سه بیماری کلاسیک با انتقال هوابرد را با هم حفظ کنید: سل، سرخک، و آبله‌مرغان.**",
  "⚠️ **و در راش منتشر آبله‌مرغان یا زونای منتشر، هر دو احتیاط با هم لازم است.**",
  "**در زونای موضعی و پوشیده در فرد سالم، فقط احتیاطات تماسی کافی است.**",
  "**چون در زونای موضعی، ویروس در ترشحات تنفسی نیست و فقط در وزیکول‌هاست.**",
  "**و کارکنان مستعد اصلاً نباید از این بیمار مراقبت کنند.**",
 ],
 DIS_EN + [
  "This is an infection-control decision, and the answer comes from the routes of transmission.",
  "WARNING: VARICELLA ZOSTER VIRUS HAS TWO ROUTES and both must be covered.",
  "ROUTE ONE — direct contact with vesicle fluid (contact precautions).",
  "ROUTE TWO — airborne particles from the respiratory tract (airborne precautions).",
  "WARNING: IT IS THE SECOND ROUTE THAT SEPARATES VARICELLA FROM MOST VESICULAR DISEASES.",
  "Airborne particles are small, stay suspended for a long time and spread through the whole room.",
  "So a surgical mask and gloves are not enough: a negative-pressure room and an N95 respirator are required.",
  "Memorise the three classic airborne diseases together: TUBERCULOSIS, MEASLES and CHICKENPOX.",
  "WARNING, AND IN DISSEMINATED CHICKENPOX OR DISSEMINATED ZOSTER, BOTH precautions are needed together.",
  "In localised, covered zoster in a healthy person, contact precautions alone suffice.",
  "Because in localised zoster the virus is not in respiratory secretions, only in the vesicles.",
  "And susceptible staff should not care for this patient at all.",
 ],
 "این سؤال یک تصمیم **کنترل عفونت** است، و پاسخش مستقیماً از **راه انتقال ویروس** می‌آید.\n\n"
 "**دختر ۲۵ ساله‌ی پیوند کلیه**، یک سال پس از پیوند، با **راش ژنرالیزه‌ی خارش‌دار "
 "پلئومورف پاپولووزیکولر** — یعنی **آبله‌مرغان منتشر در یک بیمار دچار نقص ایمنی**. برای "
 "درمان وریدی بستری می‌شود.\n\n"
 "⚠️ **ویروس واریسلا زوستر دو راه انتقال دارد و پاسخ سؤال در راه دوم است:**\n\n"
 "**راه یک — تماس مستقیم با مایع وزیکول‌ها.** این راه با **احتیاطات تماسی** (دستکش و "
 "گان) پوشش داده می‌شود.\n\n"
 "**راه دو — ذرات هوابرد از دستگاه تنفس.** و **این راه است که واریسلا را از بیشتر "
 "بیماری‌های وزیکولر جدا می‌کند**.\n\n"
 "**چرا هوابرد بودن این‌قدر مهم است؟** چون ذرات هوابرد (کمتر از ۵ میکرون) **مدت‌ها در هوا "
 "معلق می‌مانند و در کل اتاق و حتی راهرو پخش می‌شوند**. پس:\n\n"
 "• **ماسک جراحی کافی نیست** → **ماسک N95** لازم است\n"
 "• **اتاق معمولی کافی نیست** → **اتاق فشار منفی** لازم است\n\n"
 "**پس پاسخ «تنفسی (هوابرد)» است.** ✅\n\n"
 "⚠️ **سه بیماری کلاسیک با انتقال هوابرد را با هم حفظ کنید:**\n\n"
 "> **سل · سرخک · آبله‌مرغان**\n\n"
 "(و در عمل، برای آبله‌مرغان **هر دو احتیاط تماسی و هوابرد** با هم اعمال می‌شوند.)\n\n"
 "**و یک تمایز مهم که سؤال‌های دیگر روی آن حساب می‌کنند:**\n\n"
 "• **آبله‌مرغان یا زونای منتشر** → **هوابرد + تماسی**\n\n"
 "• **زونای موضعی و پوشیده در فرد سالم** → **فقط تماسی**\n\n"
 "**چرا این تفاوت؟** چون در **زونای موضعی**، ویروس **فقط در وزیکول‌هاست و در ترشحات "
 "تنفسی نیست**. ولی در **بیماری منتشر**، ویروس در خون و ترشحات تنفسی هم حضور دارد.\n\n"
 "**و یک نکته‌ی عملی مهم:** **کارکنان مستعد (بدون سابقه‌ی ابتلا و بدون واکسن) اصلاً نباید "
 "از این بیمار مراقبت کنند.** مراقبت باید به کارکنان ایمن سپرده شود.",
 "This is an INFECTION CONTROL decision, and the answer comes directly from THE ROUTES OF "
 "TRANSMISSION.\n\n"
 "A 25-YEAR-OLD KIDNEY TRANSPLANT RECIPIENT, one year post-transplant, with a GENERALISED ITCHY "
 "PLEOMORPHIC PAPULOVESICULAR RASH — that is, DISSEMINATED CHICKENPOX IN AN IMMUNOCOMPROMISED "
 "PATIENT. She is admitted for intravenous treatment.\n\n"
 "WARNING, VARICELLA ZOSTER VIRUS HAS TWO ROUTES, and the answer lies in the second:\n\n"
 "ROUTE ONE — DIRECT CONTACT WITH VESICLE FLUID. Covered by CONTACT PRECAUTIONS (gloves and gown).\n\n"
 "ROUTE TWO — AIRBORNE PARTICLES FROM THE RESPIRATORY TRACT. AND IT IS THIS ROUTE THAT SEPARATES "
 "VARICELLA FROM MOST VESICULAR DISEASES.\n\n"
 "WHY DOES BEING AIRBORNE MATTER SO MUCH? Because airborne particles (under 5 microns) STAY "
 "SUSPENDED FOR A LONG TIME AND SPREAD THROUGH THE WHOLE ROOM and even the corridor. So:\n\n"
 "• A SURGICAL MASK IS NOT ENOUGH -> an N95 RESPIRATOR is required\n"
 "• AN ORDINARY ROOM IS NOT ENOUGH -> a NEGATIVE-PRESSURE ROOM is required\n\n"
 "SO THE ANSWER IS AIRBORNE.\n\n"
 "WARNING, MEMORISE THE THREE CLASSIC AIRBORNE DISEASES TOGETHER:\n\n"
 "> TUBERCULOSIS · MEASLES · CHICKENPOX\n\n"
 "(And in practice, for chickenpox BOTH contact and airborne precautions are applied together.)\n\n"
 "AND AN IMPORTANT DISTINCTION OTHER QUESTIONS RELY ON:\n\n"
 "• DISSEMINATED chickenpox or zoster -> AIRBORNE PLUS CONTACT\n\n"
 "• LOCALISED, COVERED zoster in a healthy person -> CONTACT ONLY\n\n"
 "WHY THE DIFFERENCE? Because in LOCALISED ZOSTER the virus is ONLY IN THE VESICLES AND NOT IN "
 "RESPIRATORY SECRETIONS. In DISSEMINATED disease it is present in blood and respiratory secretions "
 "as well.\n\n"
 "AND A PRACTICAL POINT: SUSCEPTIBLE STAFF (no previous infection, no vaccine) SHOULD NOT CARE FOR "
 "THIS PATIENT AT ALL. Care should be assigned to immune staff.",
 ["احتیاطات قطره‌ای برای ذرات بزرگ‌تر است و ذرات ریز هوابرد واریسلا را متوقف نمی‌کند.",
  "احتیاطات تماسی لازم است ولی به‌تنهایی کافی نیست؛ راه هوابرد پوشش داده نمی‌شود.",
  "پاسخ صحیح — واریسلا هوابرد است و اتاق فشار منفی و ماسک N95 لازم دارد.",
  "احتیاطات استاندارد به‌هیچ‌وجه برای یک بیماری هوابرد کافی نیست."],
 ["Droplet precautions are for larger particles and do not stop the fine airborne particles of varicella.",
  "Contact precautions are needed but not sufficient alone; the airborne route is left uncovered.",
  "Correct — varicella is airborne and requires a negative-pressure room and an N95 respirator.",
  "Standard precautions are in no way adequate for an airborne disease."],
 "**سل، سرخک، آبله‌مرغان: سه بیماری هوابرد.** زونای موضعی ولی فقط تماسی است.",
 "Tuberculosis, measles and chickenpox are the three airborne diseases; localised zoster is contact only.",
 [H193, VARIZIG])


# =========================================================== book:633
add("book:633", "case", "hard",
 "**زونای** مادر پس از زایمان ← نوزاد با IgG مادری محافظت شده ← فقط **آسیکلوویر خوراکی برای مادر**.",
 "MATERNAL SHINGLES after delivery: the baby is protected by maternal IgG, so only ORAL ACICLOVIR FOR THE MOTHER.",
 DIS_FA + [
  "⚠️ **کلید این سؤال یک کلمه است: «دردناک». و کلمه‌ی دوم: «درماتومی».**",
  "**ضایعات وزیکولر دردناک در یک ناحیه‌ی محدود و یک‌طرفه = زونا، نه آبله‌مرغان.**",
  "**و این تمایز، کل پاسخ را عوض می‌کند.**",
  "**زونا یعنی فعال شدن مجدد ویروسی که سال‌ها در گانگلیون خوابیده بود.**",
  "⚠️ **پس مادر از قبل ایمن بوده — و IgG ضدواریسلای او از جفت عبور کرده است.**",
  "**نوزاد این آنتی‌بادی محافظ را دارد و در خطر واریسلای شدید نوزادی نیست.**",
  "**در مقابل، آبله‌مرغانِ مادر در پنجره‌ی ۵ روز پیش تا ۲ روز پس از زایمان خطرناک است،**",
  "**چون آنجا مادر ایمنیِ قبلی نداشته و آنتی‌بادی هنوز ساخته و منتقل نشده است.**",
  "⚠️ **پس قاعده: زونای مادر در هر زمانی، برای نوزاد VZIG لازم ندارد.**",
  "**خودِ مادر ولی درمان می‌خواهد: آسیکلوویر خوراکی، برای کاهش درد و مدت بیماری.**",
  "**و توصیه‌ی عملی: ضایعات را بپوشانید و بهداشت دست را رعایت کنید،**",
  "**چون تماس مستقیم نوزاد با مایع وزیکول همچنان می‌تواند انتقال بدهد.**",
 ],
 DIS_EN + [
  "WARNING: THE KEY TO THIS QUESTION IS ONE WORD — 'PAINFUL'. And the second word: 'DERMATOMAL'.",
  "Painful vesicular lesions in a limited, unilateral area mean SHINGLES, not chickenpox.",
  "And that distinction changes the entire answer.",
  "Shingles means reactivation of a virus that has lain dormant in a ganglion for years.",
  "WARNING: SO THE MOTHER WAS ALREADY IMMUNE — and her anti-varicella IgG has crossed the placenta.",
  "The baby has that protective antibody and is not at risk of severe neonatal varicella.",
  "By contrast, maternal CHICKENPOX in the window 5 days before to 2 days after delivery is dangerous,",
  "because there the mother had no prior immunity and the antibody has not yet been made or transferred.",
  "WARNING, HENCE THE RULE: MATERNAL SHINGLES AT ANY TIME NEEDS NO VZIG FOR THE BABY.",
  "The mother herself does need treatment: oral aciclovir, to reduce pain and duration.",
  "And a practical instruction: cover the lesions and observe hand hygiene,",
  "because direct neonatal contact with vesicle fluid can still transmit the virus.",
 ],
 "این سؤال یکی از بهترین تله‌های فصل است، و کل پاسخ در **دو کلمه‌ی صورت سؤال** پنهان "
 "شده.\n\n"
 "**مادری، روز بعد از زایمان**، با **بثورات وزیکولر در قسمت تحتانی شکم و پهلوی راست**، که "
 "**دردناک** است.\n\n"
 "⚠️ **کلمه‌ی اول: «دردناک». کلمه‌ی دوم: توزیع محدود و یک‌طرفه.**\n\n"
 "**آبله‌مرغان** راشی **منتشر، خارش‌دار** و در **کل بدن** است. **زونا** ضایعه‌ای "
 "**دردناک**، **یک‌طرفه** و محدود به **یک درماتوم** است. توصیف این بیمار — «قسمت تحتانی "
 "شکم و پهلوی راست»، دردناک — **زوناست**.\n\n"
 "**و این تشخیص، کل پاسخ را عوض می‌کند.**\n\n"
 "⚠️ **چرا؟ به این زنجیره‌ی استدلال دقت کنید:**\n\n"
 "**۱)** زونا یعنی **فعال شدن مجدد** ویروسی که سال‌ها در گانگلیون ریشه‌ی خلفی خوابیده بود.\n\n"
 "**۲)** پس مادر **حتماً در گذشته آبله‌مرغان گرفته** — وگرنه ویروسی برای فعال شدن مجدد "
 "نداشت.\n\n"
 "**۳)** پس مادر **IgG ضدواریسلا دارد**.\n\n"
 "**۴)** و **IgG از جفت عبور می‌کند** — پس **نوزاد این آنتی‌بادی محافظ را دریافت کرده "
 "است**.\n\n"
 "**۵)** **نتیجه: نوزاد در خطر واریسلای شدید نوزادی نیست و VZIG لازم ندارد.** ✅\n\n"
 "⚠️ **حالا مقایسه کنید با پنجره‌ی خطرناک:**\n\n"
 "**آبله‌مرغانِ مادر از ۵ روز پیش تا ۲ روز پس از زایمان** خطرناک است — با مرگ‌ومیر تا "
 "**۳۰ درصد**. چرا؟ چون آنجا مادر **ایمنی قبلی نداشته**، ویروس از جفت عبور می‌کند، ولی "
 "**آنتی‌بادی هنوز ساخته نشده که همراهش برود**. نوزاد ویروس را می‌گیرد **بدون محافظ**.\n\n"
 "> **در زونا: ویروسِ محدود + آنتی‌بادیِ حاضر ← نوزاد ایمن**\n"
 "> **در آبله‌مرغان نزدیک زایمان: ویروسِ منتشر + آنتی‌بادیِ غایب ← نوزاد در خطر مرگ**\n\n"
 "**پس اقدام درست: آسیکلوویر خوراکی برای خودِ مادر** — که درد و مدت بیماری را کم می‌کند و "
 "خطر نورالژی پس از زونا را پایین می‌آورد.\n\n"
 "**و یک توصیه‌ی عملی مهم:** ضایعات را **بپوشانید** و **بهداشت دست** رعایت شود. چون هرچند "
 "نوزاد از راه خون محافظت شده، **تماس مستقیم با مایع وزیکول** همچنان می‌تواند انتقال "
 "بدهد — به‌ویژه اگر ضایعه نزدیک محل شیردهی باشد.",
 "This is one of the best traps in the chapter, and the whole answer hides in TWO WORDS of the "
 "stem.\n\n"
 "A MOTHER, THE DAY AFTER DELIVERY, with VESICULAR ERUPTIONS ON THE LOWER ABDOMEN AND RIGHT FLANK, "
 "which are PAINFUL.\n\n"
 "WARNING, THE FIRST WORD: 'PAINFUL'. THE SECOND: a limited, unilateral distribution.\n\n"
 "CHICKENPOX is a GENERALISED, ITCHY rash over the WHOLE BODY. SHINGLES is a PAINFUL, UNILATERAL "
 "lesion confined to ONE DERMATOME. This patient's description — lower abdomen and right flank, "
 "painful — IS SHINGLES.\n\n"
 "AND THAT DIAGNOSIS CHANGES THE ENTIRE ANSWER.\n\n"
 "WARNING, WHY? Follow this chain of reasoning:\n\n"
 "1) Shingles means REACTIVATION of a virus dormant for years in a dorsal root ganglion.\n\n"
 "2) So the mother MUST HAVE HAD CHICKENPOX IN THE PAST — otherwise there would be no virus to "
 "reactivate.\n\n"
 "3) So the mother HAS ANTI-VARICELLA IgG.\n\n"
 "4) And IgG CROSSES THE PLACENTA — so THE BABY HAS ALREADY RECEIVED THAT PROTECTIVE ANTIBODY.\n\n"
 "5) CONCLUSION: THE BABY IS NOT AT RISK OF SEVERE NEONATAL VARICELLA AND NEEDS NO VZIG.\n\n"
 "WARNING, NOW COMPARE WITH THE DANGEROUS WINDOW:\n\n"
 "MATERNAL CHICKENPOX FROM 5 DAYS BEFORE TO 2 DAYS AFTER DELIVERY is dangerous, with mortality up "
 "to 30 PER CENT. Why? Because there the mother HAD NO PRIOR IMMUNITY; the virus crosses the "
 "placenta but THE ANTIBODY HAS NOT YET BEEN MADE to follow it. The baby receives the virus WITHOUT "
 "PROTECTION.\n\n"
 "> IN SHINGLES: limited virus plus antibody present -> the baby is safe\n"
 "> IN PERIPARTUM CHICKENPOX: disseminated virus plus antibody absent -> the baby may die\n\n"
 "SO THE CORRECT ACTION IS ORAL ACICLOVIR FOR THE MOTHER, which reduces pain and duration and "
 "lowers the risk of post-herpetic neuralgia.\n\n"
 "AND AN IMPORTANT PRACTICAL INSTRUCTION: COVER THE LESIONS and observe HAND HYGIENE. Although the "
 "baby is protected haematogenously, DIRECT CONTACT WITH VESICLE FLUID can still transmit the "
 "virus — especially if the lesion is near the feeding site.",
 ["آسیکلوویر وریدی برای مادر و نوزاد بیش از حد تهاجمی است؛ نوزاد اصلاً در معرض خطر نیست.",
  "پاسخ صحیح — این زوناست، پس نوزاد با IgG مادری محافظت شده و فقط مادر درمان می‌خواهد.",
  "VZIG برای نوزاد لازم نیست: زونای مادر یعنی مادر ایمن بوده و آنتی‌بادی منتقل شده است.",
  "واکسیناسیون VZV در نوزاد جایی ندارد؛ واکسن زنده است و در این سن تجویز نمی‌شود."],
 ["Intravenous aciclovir for mother and baby is excessive; the baby is not at risk at all.",
  "Correct — this is shingles, so the baby is protected by maternal IgG and only the mother needs treatment.",
  "VZIG is not needed for the baby: maternal shingles means the mother was immune and antibody has transferred.",
  "VZV vaccination has no place in a neonate; it is a live vaccine and is not given at this age."],
 "**زونای مادر = مادر ایمن بوده = نوزاد آنتی‌بادی دارد.** پنجره‌ی خطر فقط آبله‌مرغان است.",
 "Maternal shingles means the mother was immune and the baby has antibody; only chickenpox creates the danger window.",
 [H193, RCOG13])


# =========================================================== book:636
add("book:636", "case", "medium",
 "زونای مادر **پیش از بارداری** ← هیچ خطری برای نوزاد ← **اقدام خاصی لازم نیست**.",
 "Maternal shingles BEFORE the pregnancy poses no risk to the baby: NO ACTION IS NEEDED.",
 DIS_FA + [
  "**این سؤال همان قاعده‌ی زونا را می‌سنجد، ولی با یک لایه‌ی زمانی اضافه.**",
  "**دو دلیل مستقل، پاسخ را به «هیچ اقدامی» می‌رسانند — و هر دو را باید ببینید.**",
  "⚠️ **دلیل یک — این زوناست، نه آبله‌مرغان. پس مادر از قبل ایمن بوده.**",
  "**IgG ضدواریسلای مادر از جفت عبور کرده و نوزاد را پوشش می‌دهد.**",
  "**دلیل دو — زمان: زونا پیش از بارداری رخ داده، نه نزدیک زایمان.**",
  "**پنجره‌ی خطر نوزادی فقط ۵ روز پیش تا ۲ روز پس از زایمان است.**",
  "⚠️ **حتی اگر این زونا امروز هم بود، باز نوزاد خطری نداشت — چون زوناست.**",
  "**پس هر دو دلیل مستقلاً کافی‌اند و پاسخ قطعی است.**",
  "**سندرم واریسلای مادرزادی هم اینجا مطرح نیست:**",
  "**آن فقط با آبله‌مرغان اولیه در ۲۰ هفته‌ی نخست بارداری رخ می‌دهد، و شیوعش زیر ۲ درصد است.**",
  "⚠️ **و زونای مادر هرگز سندرم واریسلای مادرزادی نمی‌سازد.**",
  "**دادن VZIG یا آسیکلوویر به این نوزاد، درمان بدون بیماری است: هزینه و عارضه بدون فایده.**",
 ],
 DIS_EN + [
  "This question tests the same shingles rule, but with an added layer of timing.",
  "Two independent reasons drive the answer to 'nothing', and you should see both.",
  "WARNING, REASON ONE — this is SHINGLES, not chickenpox. So the mother was already immune.",
  "Her anti-varicella IgG has crossed the placenta and covers the baby.",
  "REASON TWO — the timing: the shingles occurred BEFORE the pregnancy, not near delivery.",
  "The dangerous neonatal window is only 5 days before to 2 days after delivery.",
  "WARNING: EVEN IF THIS SHINGLES WERE TODAY, THE BABY WOULD STILL BE SAFE — because it is shingles.",
  "So each reason suffices on its own and the answer is certain.",
  "Congenital varicella syndrome is not in question here either:",
  "it follows only PRIMARY chickenpox in the first 20 weeks of pregnancy, and even then in under 2 per cent.",
  "WARNING, AND MATERNAL SHINGLES NEVER CAUSES CONGENITAL VARICELLA SYNDROME.",
  "Giving this baby VZIG or aciclovir is treatment without disease: cost and harm without benefit.",
 ],
 "این سؤال همان قاعده‌ی زونای سؤال قبل را می‌سنجد، ولی **یک لایه‌ی زمانی** هم اضافه کرده — "
 "و **هر دو لایه مستقلاً به یک پاسخ می‌رسند**.\n\n"
 "**خانم ۳۲ ساله‌ی حامله‌ی ۳۰ هفته‌ای**، که **۵ روز پیش از بارداری** دچار **زونا در ناحیه‌ی "
 "توراسیک** شده است. **اقدام مناسب برای نوزاد چیست؟**\n\n"
 "⚠️ **دلیل یک — این زوناست، نه آبله‌مرغان.**\n\n"
 "زونا یعنی **فعال شدن مجدد** ویروس خفته. پس مادر **حتماً از قبل آبله‌مرغان گرفته** و "
 "**IgG ضدواریسلا دارد**. آن IgG **از جفت عبور می‌کند** و نوزاد را می‌پوشاند.\n\n"
 "**نتیجه: نوزاد آنتی‌بادی محافظ دارد.**\n\n"
 "⚠️ **دلیل دو — زمان‌بندی.**\n\n"
 "پنجره‌ی خطر واریسلای نوزادی **فقط از ۵ روز پیش تا ۲ روز پس از زایمان** است. این زونا "
 "**پیش از شروع بارداری** رخ داده — یعنی حدود **۳۰ هفته پیش**. کاملاً بیرون از هر پنجره‌ی "
 "خطری.\n\n"
 "**هر دو دلیل مستقلاً کافی‌اند. پاسخ: اقدام خاصی نیاز نیست.** ✅\n\n"
 "⚠️ **و حالا یک نکته‌ی مهم برای تکمیل دانش: سندرم واریسلای مادرزادی.**\n\n"
 "دانشجو ممکن است فکر کند «مادر باردار + ویروس واریسلا = سندرم واریسلای مادرزادی». **این "
 "غلط است، به دو دلیل:**\n\n"
 "**۱)** سندرم واریسلای مادرزادی **فقط با آبله‌مرغان اولیه** رخ می‌دهد، **نه با زونا**. "
 "زونا یک عفونت **موضعی و مهارشده** در فرد **ایمن** است و ویرمی معناداری نمی‌سازد.\n\n"
 "**۲)** حتی با آبله‌مرغان اولیه، این سندرم فقط در **۲۰ هفته‌ی نخست بارداری** و با شیوع "
 "**زیر ۲ درصد** رخ می‌دهد. این بیمار در **هفته‌ی ۳۰** است.\n\n"
 "**تظاهرات سندرم واریسلای مادرزادی (برای شناخت، نه برای این بیمار):** اسکار پوستی با "
 "توزیع درماتومی، هیپوپلازی اندام، ناهنجاری چشمی (کاتاراکت، کوریورتینیت)، میکروسفالی و "
 "عقب‌ماندگی رشد.\n\n"
 "⚠️ **درس عملی این سؤال:** تجویز VZIG یا آسیکلوویر برای این نوزاد **درمان بدون بیماری** "
 "است — هزینه، تزریق و عارضه‌ی احتمالی، بدون هیچ فایده‌ای. **تشخیص درست گاهی یعنی تشخیص "
 "اینکه هیچ کاری لازم نیست.**",
 "This question tests the same shingles rule as the previous one, but adds A LAYER OF TIMING — and "
 "BOTH LAYERS INDEPENDENTLY REACH THE SAME ANSWER.\n\n"
 "A 32-YEAR-OLD WOMAN AT 30 WEEKS' GESTATION who developed THORACIC SHINGLES FIVE DAYS BEFORE THE "
 "PREGNANCY BEGAN. WHAT SHOULD BE DONE FOR HER BABY?\n\n"
 "WARNING, REASON ONE — THIS IS SHINGLES, NOT CHICKENPOX.\n\n"
 "Shingles is REACTIVATION of dormant virus. So the mother MUST HAVE HAD CHICKENPOX BEFORE and HAS "
 "ANTI-VARICELLA IgG. That IgG CROSSES THE PLACENTA and covers the baby.\n\n"
 "CONCLUSION: the baby has protective antibody.\n\n"
 "WARNING, REASON TWO — THE TIMING.\n\n"
 "The neonatal varicella danger window is ONLY 5 DAYS BEFORE TO 2 DAYS AFTER DELIVERY. This "
 "shingles occurred BEFORE THE PREGNANCY EVEN BEGAN — about 30 weeks ago. Completely outside any "
 "window of risk.\n\n"
 "EACH REASON SUFFICES ALONE. THE ANSWER: NO ACTION IS NEEDED.\n\n"
 "WARNING, AND NOW AN IMPORTANT POINT TO COMPLETE THE KNOWLEDGE: CONGENITAL VARICELLA SYNDROME.\n\n"
 "A student may think 'pregnant mother plus varicella virus equals congenital varicella syndrome'. "
 "THAT IS WRONG, for two reasons:\n\n"
 "1) Congenital varicella syndrome follows ONLY PRIMARY CHICKENPOX, NOT SHINGLES. Shingles is a "
 "LOCALISED, CONTAINED infection in an IMMUNE person and produces no meaningful viraemia.\n\n"
 "2) Even with primary chickenpox, the syndrome occurs only in the FIRST 20 WEEKS of pregnancy and "
 "in UNDER 2 PER CENT of cases. This patient is at 30 WEEKS.\n\n"
 "THE FEATURES OF CONGENITAL VARICELLA SYNDROME (for recognition, not for this patient): cicatricial "
 "skin scarring in a dermatomal distribution, limb hypoplasia, ocular abnormalities (cataract, "
 "chorioretinitis), microcephaly and growth restriction.\n\n"
 "WARNING, THE PRACTICAL LESSON: giving this baby VZIG or aciclovir is TREATMENT WITHOUT DISEASE — "
 "cost, an injection and possible harm, with no benefit at all. SOMETIMES THE RIGHT DIAGNOSIS IS "
 "RECOGNISING THAT NOTHING NEEDS DOING.",
 ["پاسخ صحیح — زونای مادر یعنی مادر ایمن بوده و IgG محافظ از جفت عبور کرده است.",
  "VZIG وقتی لازم است که مادر آبله‌مرغان اولیه در پنجره‌ی نزدیک زایمان بگیرد، نه در زونا.",
  "آسیکلوویر برای نوزادی که در معرض خطر نیست، درمان بدون بیماری است.",
  "فامسیکلوویر نیز جایی ندارد؛ مسئله انتخاب دارو نیست، بلکه نبودن هرگونه اندیکاسیون است."],
 ["Correct — maternal shingles means the mother was immune and protective IgG has crossed the placenta.",
  "VZIG is needed when the mother has primary chickenpox in the peripartum window, not for shingles.",
  "Aciclovir for a baby who is not at risk is treatment without disease.",
  "Famciclovir has no place either; the issue is not which drug but that there is no indication at all."],
 "**زونا هرگز سندرم واریسلای مادرزادی نمی‌سازد.** و پنجره‌ی خطر فقط دور زایمان است.",
 "Shingles never causes congenital varicella syndrome, and the danger window is only around delivery.",
 [H193, RCOG13])


# =========================================================== book:632
add("book:632", "case", "hard",
 "آبله‌مرغان در **پیوند کلیه با سرکوب شدید** ← **بستری و آسیکلوویر وریدی فوری**، بدون انتظار سرولوژی.",
 "Chickenpox in a HEAVILY IMMUNOSUPPRESSED transplant patient: ADMIT AND START INTRAVENOUS ACICLOVIR at once, without waiting for serology.",
 DIS_FA + [
  "**در این سؤال، تشخیص آسان است و آنچه سنجیده می‌شود، سرعت و مسیر تصمیم است.**",
  "**تب و گلودرد و آبریزش بینی، سپس ضایعات پوستی، و تماس با خواهر مبتلا ۱۰ روز پیش.**",
  "**۱۰ روز دقیقاً در محدوده‌ی کمون آبله‌مرغان (۱۰ تا ۲۱ روز) است.**",
  "⚠️ **و بیمار تحت سرکوب ایمنی شدید پس از پیوند کلیه است — یعنی گروه پرخطر.**",
  "**در این بیمار، آبله‌مرغان می‌تواند در عرض روزها منتشر شود: کبد، ریه و مغز.**",
  "**مرگ‌ومیر واریسلای منتشر در بیمار پیوندی، بدون درمان، بسیار بالاست.**",
  "⚠️ **پس اصل حاکم: در نقص ایمنی شدید، درمان منتظر تأیید آزمایشگاهی نمی‌ماند.**",
  "**سرولوژی روزها طول می‌کشد، و در همان روزها ویروس منتشر می‌شود.**",
  "**آسیکلوویر وریدی: ۱۰ میلی‌گرم بر کیلوگرم هر ۸ ساعت، ۷ تا ۱۰ روز.**",
  "**چرا وریدی و نه خوراکی؟ چون فراهمی زیستی آسیکلوویر خوراکی فقط ۱۰ تا ۲۰ درصد است،**",
  "**و در بیماری منتشر به غلظت‌های بسیار بالاتری نیاز داریم.**",
  "⚠️ **و آنتی‌بیوتیک اینجا جایی ندارد: عامل ویروسی است، نه باکتریال.**",
 ],
 DIS_EN + [
  "In this question the diagnosis is easy; what is being tested is the SPEED and the ROUTE of the decision.",
  "Fever, sore throat and coryza, then skin lesions, with contact with an affected sister 10 days ago.",
  "Ten days is exactly within the chickenpox incubation period (10 to 21 days).",
  "WARNING, AND THE PATIENT IS HEAVILY IMMUNOSUPPRESSED after a kidney transplant — a high-risk group.",
  "In such a patient chickenpox can disseminate within days: liver, lung and brain.",
  "Untreated disseminated varicella in a transplant recipient carries very high mortality.",
  "WARNING, HENCE THE GOVERNING PRINCIPLE: IN SEVERE IMMUNOSUPPRESSION, TREATMENT DOES NOT WAIT FOR LABORATORY CONFIRMATION.",
  "Serology takes days, and in those days the virus disseminates.",
  "INTRAVENOUS ACICLOVIR: 10 mg/kg every 8 hours for 7 to 10 days.",
  "Why intravenous rather than oral? Because oral aciclovir's bioavailability is only 10 to 20 per cent,",
  "and disseminated disease requires far higher concentrations.",
  "WARNING, AND ANTIBIOTICS HAVE NO PLACE HERE: the agent is viral, not bacterial.",
 ],
 "در این سؤال، **تشخیص آسان است** — و دقیقاً به همین دلیل، آنچه واقعاً سنجیده می‌شود "
 "**سرعت و مسیر تصمیم** است.\n\n"
 "**دختر ۱۷ ساله‌ی پیوند کلیه تحت سرکوب ایمنی شدید**، با **تب، گلودرد و آبریزش بینی از "
 "دیروز** و **چند ضایعه‌ی پوستی از امروز**. **خواهر ۳ ساله‌اش ۱۰ روز پیش** بیماری مشابهی "
 "داشته.\n\n"
 "⚠️ **سه داده که تشخیص را قطعی می‌کنند:**\n\n"
 "**۱) تماس مشخص** با یک مورد فعال.\n\n"
 "**۲) فاصله‌ی ۱۰ روز** — دقیقاً در محدوده‌ی **دوره‌ی کمون آبله‌مرغان (۱۰ تا ۲۱ روز)**.\n\n"
 "**۳) پرودروم تنفسی و سپس ضایعات پوستی** — الگوی کلاسیک.\n\n"
 "**پس این آبله‌مرغان است. سؤال این است که حالا چه کنیم و با چه سرعتی.**\n\n"
 "⚠️ **و پاسخ از یک واقعیت می‌آید: این بیمار در گروه پرخطر است.**\n\n"
 "**سرکوب ایمنی شدید پس از پیوند کلیه** یعنی **ایمنی سلولی از کار افتاده** — و کنترل "
 "واریسلا **کاملاً وابسته به ایمنی سلولی** است. در چنین بیماری، آبله‌مرغان می‌تواند **ظرف "
 "چند روز منتشر شود**:\n\n"
 "• **کبد** → هپاتیت فولمینانت\n"
 "• **ریه** → پنومونیت واریسلایی\n"
 "• **مغز** → انسفالیت\n"
 "• **انعقاد** → DIC\n\n"
 "**مرگ‌ومیر واریسلای منتشر در بیمار پیوندی، بدون درمان، بسیار بالاست.**\n\n"
 "⚠️ **پس اصل حاکم:**\n\n"
 "> **در نقص ایمنی شدید، درمان منتظر تأیید آزمایشگاهی نمی‌ماند.**\n\n"
 "**چرا گزینه‌ی «سرولوژی، سپس آسیکلوویر خوراکی» غلط است؟** دو خطا دارد:\n\n"
 "**خطای اول — انتظار.** سرولوژی روزها طول می‌کشد. در همان روزها ویروس منتشر می‌شود و "
 "پنجره‌ی طلایی درمان از دست می‌رود.\n\n"
 "**خطای دوم — راه خوراکی.** **فراهمی زیستی آسیکلوویر خوراکی فقط ۱۰ تا ۲۰ درصد است.** "
 "برای بیماری منتشر در بیمار پیوندی، به **غلظت‌های بسیار بالاتر** نیاز داریم که فقط با "
 "**راه وریدی** به دست می‌آید.\n\n"
 "**پس: بستری + آسیکلوویر وریدی، ۱۰ میلی‌گرم بر کیلوگرم هر ۸ ساعت، ۷ تا ۱۰ روز.** ✅\n\n"
 "**و چرا دو گزینه‌ی آنتی‌بیوتیکی غلط‌اند؟** چون **عامل ویروسی است، نه باکتریال**. "
 "سفالکسین و سفازولین هیچ اثری روی ویروس ندارند. (آنتی‌بیوتیک فقط اگر **عفونت ثانویه‌ی "
 "باکتریال پوست** اضافه شود مطرح می‌شود.)\n\n"
 "**و نکته‌ی کنترل عفونت:** این بیمار باید در **ایزولاسیون هوابرد و تماسی** بستری شود.",
 "In this question THE DIAGNOSIS IS EASY — and precisely for that reason, what is really being "
 "tested is THE SPEED AND ROUTE OF THE DECISION.\n\n"
 "A 17-YEAR-OLD KIDNEY TRANSPLANT RECIPIENT ON HEAVY IMMUNOSUPPRESSION, with FEVER, SORE THROAT AND "
 "CORYZA SINCE YESTERDAY and A FEW SKIN LESIONS TODAY. Her 3-YEAR-OLD SISTER HAD A SIMILAR ILLNESS "
 "10 DAYS AGO.\n\n"
 "WARNING, THREE PIECES OF DATA MAKE THE DIAGNOSIS CERTAIN:\n\n"
 "1) A DEFINITE CONTACT with an active case.\n\n"
 "2) AN INTERVAL OF 10 DAYS — exactly within the CHICKENPOX INCUBATION PERIOD (10 to 21 days).\n\n"
 "3) A RESPIRATORY PRODROME FOLLOWED BY SKIN LESIONS — the classic pattern.\n\n"
 "SO THIS IS CHICKENPOX. The question is what to do now, and how fast.\n\n"
 "WARNING, AND THE ANSWER COMES FROM ONE FACT: THIS PATIENT IS IN A HIGH-RISK GROUP.\n\n"
 "HEAVY IMMUNOSUPPRESSION AFTER KIDNEY TRANSPLANT means CELLULAR IMMUNITY HAS FAILED — and control "
 "of varicella is ENTIRELY DEPENDENT ON CELLULAR IMMUNITY. In such a patient chickenpox can "
 "DISSEMINATE WITHIN DAYS:\n\n"
 "• LIVER -> fulminant hepatitis\n"
 "• LUNG -> varicella pneumonitis\n"
 "• BRAIN -> encephalitis\n"
 "• COAGULATION -> DIC\n\n"
 "UNTREATED DISSEMINATED VARICELLA IN A TRANSPLANT RECIPIENT CARRIES VERY HIGH MORTALITY.\n\n"
 "WARNING, HENCE THE GOVERNING PRINCIPLE:\n\n"
 "> IN SEVERE IMMUNOSUPPRESSION, TREATMENT DOES NOT WAIT FOR LABORATORY CONFIRMATION.\n\n"
 "WHY IS 'SEROLOGY, THEN ORAL ACICLOVIR' WRONG? It contains two errors:\n\n"
 "ERROR ONE — WAITING. Serology takes days. In those days the virus disseminates and the golden "
 "window is lost.\n\n"
 "ERROR TWO — THE ORAL ROUTE. ORAL ACICLOVIR'S BIOAVAILABILITY IS ONLY 10 TO 20 PER CENT. "
 "Disseminated disease in a transplant recipient needs FAR HIGHER CONCENTRATIONS, attainable only "
 "INTRAVENOUSLY.\n\n"
 "SO: ADMIT PLUS INTRAVENOUS ACICLOVIR, 10 mg/kg every 8 hours for 7 to 10 days.\n\n"
 "AND WHY ARE THE TWO ANTIBIOTIC OPTIONS WRONG? Because THE AGENT IS VIRAL, NOT BACTERIAL. "
 "Cephalexin and cefazolin have no effect on a virus. (Antibiotics arise only if SECONDARY "
 "BACTERIAL SKIN INFECTION supervenes.)\n\n"
 "AND AN INFECTION-CONTROL POINT: this patient must be admitted under AIRBORNE AND CONTACT "
 "ISOLATION.",
 ["انتظار برای سرولوژی، پنجره‌ی طلایی درمان را از دست می‌دهد و راه خوراکی هم غلظت کافی نمی‌سازد.",
  "پاسخ صحیح — در نقص ایمنی شدید، بستری و آسیکلوویر وریدی فوری، بدون انتظار برای تأیید.",
  "سفالکسین یک آنتی‌بیوتیک است و روی ویروس واریسلا هیچ اثری ندارد.",
  "سفازولین نیز آنتی‌بیوتیک است؛ بستری درست است ولی داروی انتخابی اشتباه است."],
 ["Waiting for serology loses the golden treatment window, and the oral route cannot reach adequate levels.",
  "Correct — in severe immunosuppression, admit and start intravenous aciclovir at once, without waiting for confirmation.",
  "Cephalexin is an antibiotic and has no effect on varicella virus.",
  "Cefazolin is also an antibiotic; admission is right but the drug chosen is wrong."],
 "**در نقص ایمنی شدید، درمان منتظر آزمایش نمی‌ماند.** و فراهمی خوراکی آسیکلوویر فقط ۱۰ تا ۲۰ درصد است.",
 "In severe immunosuppression treatment does not wait for a test, and oral aciclovir is only 10 to 20 per cent bioavailable.",
 [H193, VARIZIG])


# =========================================================== book:635
add("book:635", "case", "medium",
 "زونای درماتومی در **HIV** ← **والاسیکلوویر**؛ عبور نکردن از خط وسط، تشخیص را می‌سازد.",
 "Dermatomal shingles in HIV: VALACICLOVIR. Not crossing the midline is what makes the diagnosis.",
 DIS_FA + [
  "⚠️ **یک عبارت در صورت سؤال، تشخیص را قطعی می‌کند: «از خط وسط عبور نکرده».**",
  "**این تعریف یک ضایعه‌ی درماتومی است، و درماتومی یعنی زونا.**",
  "**چون ویروس در گانگلیون ریشه‌ی خلفی یک طرف خوابیده و در همان درماتوم بیدار می‌شود.**",
  "**عصب یک درماتوم از خط وسط رد نمی‌شود، پس راش هم رد نمی‌شود.**",
  "**و ضایعات «دردناک» بودن هم زونا را از عفونت‌های باکتریال پوست جدا می‌کند.**",
  "⚠️ **در بیمار HIV مثبت، زونا معنای خاصی دارد: نشانگر افت ایمنی سلولی است.**",
  "**زونا در HIV می‌تواند در CD4 نسبتاً بالا (۲۰۰ تا ۵۰۰) هم رخ دهد،**",
  "**و اغلب اولین نشانه‌ی بالینی نقص ایمنی است — گاهی پیش از آنکه HIV تشخیص داده شود.**",
  "**درمان: والاسیکلوویر ۱۰۰۰ میلی‌گرم سه بار در روز، ۷ روز.**",
  "**یا آسیکلوویر ۸۰۰ میلی‌گرم پنج بار در روز، یا فامسیکلوویر ۵۰۰ میلی‌گرم سه بار در روز.**",
  "⚠️ **والاسیکلوویر بر آسیکلوویر خوراکی ترجیح دارد: فراهمی زیستی سه تا پنج برابر بیشتر.**",
  "**و شروع در ۷۲ ساعت اول، خطر نورالژی پس از زونا را به‌طور معناداری کم می‌کند.**",
 ],
 DIS_EN + [
  "WARNING: ONE PHRASE IN THE STEM SETTLES THE DIAGNOSIS — 'has not crossed the midline'.",
  "That is the definition of a dermatomal lesion, and dermatomal means shingles.",
  "Because the virus lies dormant in a dorsal root ganglion on one side and wakes in that dermatome.",
  "The nerve of one dermatome does not cross the midline, so neither does the rash.",
  "And the lesions being PAINFUL also separates shingles from bacterial skin infection.",
  "WARNING, IN AN HIV-POSITIVE PATIENT, SHINGLES CARRIES A SPECIAL MEANING: it marks falling cellular immunity.",
  "Shingles in HIV can occur at a relatively high CD4 (200 to 500),",
  "and is often the FIRST clinical sign of immunodeficiency — sometimes before HIV is even diagnosed.",
  "TREATMENT: valaciclovir 1000 mg three times daily for 7 days.",
  "Or aciclovir 800 mg five times daily, or famciclovir 500 mg three times daily.",
  "WARNING: VALACICLOVIR IS PREFERRED OVER ORAL ACICLOVIR — three to five times the bioavailability.",
  "And starting within the first 72 hours significantly reduces the risk of post-herpetic neuralgia.",
 ],
 "این سؤال با **یک عبارت** حل می‌شود، و آن عبارت عمداً در صورت سؤال گذاشته شده.\n\n"
 "**آقای ۲۹ ساله‌ی HIV مثبت بدون مصرف دارو**، **بدون تب**، با **ضایعات دردناک قرمز در "
 "ناحیه‌ی فالنکس** که **از خط وسط عبور نکرده** و طی ۳ روز بدتر شده.\n\n"
 "⚠️ **عبارت کلیدی: «از خط وسط عبور نکرده».**\n\n"
 "این **تعریف یک ضایعه‌ی درماتومی** است. و **درماتومی یعنی زونا**.\n\n"
 "**چرا زونا از خط وسط عبور نمی‌کند؟** چون ویروس در **گانگلیون ریشه‌ی خلفی یک طرف** خوابیده "
 "و هنگام فعال شدن مجدد، **در امتداد همان عصب حسی** پیش می‌رود. و **عصب حسی یک درماتوم از "
 "خط وسط بدن رد نمی‌شود**. پس راش هم رد نمی‌شود.\n\n"
 "**و کلمه‌ی «دردناک» سرنخ دوم است:** زونا ذاتاً دردناک است (درد نوروپاتیک، اغلب پیش از "
 "ظاهر شدن راش)، در حالی که عفونت‌های باکتریال پوست بیشتر با **گرمی و قرمزی گسترده** "
 "مشخص می‌شوند و از خط وسط هم می‌توانند رد شوند.\n\n"
 "**پس تشخیص: زونا. و درمان: والاسیکلوویر.** ✅\n\n"
 "⚠️ **چرا والاسیکلوویر و نه آسیکلوویر خوراکی؟**\n\n"
 "**والاسیکلوویر پیش‌داروی آسیکلوویر است با فراهمی زیستی سه تا پنج برابر بیشتر.** یعنی:\n\n"
 "• غلظت خونی بالاتر و پایدارتر\n"
 "• **سه بار در روز** به‌جای **پنج بار در روز** → پایبندی بهتر بیمار\n\n"
 "**دوز: والاسیکلوویر ۱۰۰۰ میلی‌گرم سه بار در روز، ۷ روز.**\n\n"
 "⚠️ **و نکته‌ی مهم دیگر: زونا در بیمار HIV مثبت چه معنایی دارد؟**\n\n"
 "زونا در HIV **نشانگر افت ایمنی سلولی** است. برخلاف بیشتر عفونت‌های فرصت‌طلب که آستانه‌ی "
 "CD4 مشخصی دارند، **زونا می‌تواند در CD4 نسبتاً بالا (۲۰۰ تا ۵۰۰) هم رخ دهد** — و اغلب "
 "**اولین نشانه‌ی بالینی نقص ایمنی** است، گاهی حتی **پیش از آنکه HIV تشخیص داده شود**.\n\n"
 "**پس در هر بزرگسال جوان با زونا، به‌ویژه اگر عوامل خطر داشته باشد، تست HIV را در نظر "
 "بگیرید.** (در این بیمار HIV از قبل شناخته شده است.)\n\n"
 "**چرا سه گزینه‌ی دیگر نه؟** **داکسی‌سیکلین** و **پیپراسیلین-تازوباکتام** آنتی‌بیوتیک‌اند "
 "و روی ویروس بی‌اثر. **گان‌سیکلوویر** برای **سیتومگالوویروس** است، نه واریسلا زوستر، و "
 "سمیت مغز استخوان قابل توجهی دارد.\n\n"
 "**و یک نکته‌ی درمانی طلایی: شروع درمان در ۷۲ ساعت اول، خطر نورالژی پس از زونا را "
 "به‌طور معناداری کم می‌کند.**",
 "This question is solved by ONE PHRASE, deliberately placed in the stem.\n\n"
 "A 29-YEAR-OLD HIV-POSITIVE MAN NOT ON TREATMENT, AFEBRILE, with PAINFUL RED LESIONS on the "
 "phalanx region that HAVE NOT CROSSED THE MIDLINE and have worsened over three days.\n\n"
 "WARNING, THE KEY PHRASE: 'HAS NOT CROSSED THE MIDLINE'.\n\n"
 "That is THE DEFINITION OF A DERMATOMAL LESION. And DERMATOMAL MEANS SHINGLES.\n\n"
 "WHY DOES SHINGLES NOT CROSS THE MIDLINE? Because the virus lies dormant in A DORSAL ROOT GANGLION "
 "ON ONE SIDE and, on reactivating, travels ALONG THAT SENSORY NERVE. And THE SENSORY NERVE OF ONE "
 "DERMATOME DOES NOT CROSS THE MIDLINE. So neither does the rash.\n\n"
 "AND THE WORD 'PAINFUL' IS THE SECOND CLUE: shingles is inherently painful (neuropathic pain, often "
 "preceding the rash), whereas bacterial skin infections are marked more by WARMTH AND SPREADING "
 "REDNESS and can cross the midline.\n\n"
 "SO THE DIAGNOSIS IS SHINGLES, AND THE TREATMENT IS VALACICLOVIR.\n\n"
 "WARNING, WHY VALACICLOVIR RATHER THAN ORAL ACICLOVIR?\n\n"
 "VALACICLOVIR IS A PRODRUG OF ACICLOVIR WITH THREE TO FIVE TIMES THE BIOAVAILABILITY. That means:\n\n"
 "• higher and more sustained blood levels\n"
 "• THREE times daily instead of FIVE -> better adherence\n\n"
 "DOSE: valaciclovir 1000 mg three times daily for 7 days.\n\n"
 "WARNING, AND ANOTHER IMPORTANT POINT: WHAT DOES SHINGLES MEAN IN AN HIV-POSITIVE PATIENT?\n\n"
 "Shingles in HIV MARKS FALLING CELLULAR IMMUNITY. Unlike most opportunistic infections with a "
 "definite CD4 threshold, SHINGLES CAN OCCUR AT A RELATIVELY HIGH CD4 (200 TO 500) — and is often "
 "THE FIRST CLINICAL SIGN OF IMMUNODEFICIENCY, sometimes even BEFORE HIV IS DIAGNOSED.\n\n"
 "SO IN ANY YOUNG ADULT WITH SHINGLES, ESPECIALLY WITH RISK FACTORS, CONSIDER AN HIV TEST. (In this "
 "patient HIV is already known.)\n\n"
 "WHY NOT THE OTHER THREE? DOXYCYCLINE and PIPERACILLIN-TAZOBACTAM are antibiotics and inactive "
 "against a virus. GANCICLOVIR is for CYTOMEGALOVIRUS, not varicella zoster, and carries "
 "considerable marrow toxicity.\n\n"
 "AND A GOLDEN THERAPEUTIC POINT: STARTING TREATMENT WITHIN THE FIRST 72 HOURS SIGNIFICANTLY REDUCES "
 "THE RISK OF POST-HERPETIC NEURALGIA.",
 ["داکسی‌سیکلین یک آنتی‌بیوتیک است و روی ویروس واریسلا زوستر اثری ندارد.",
  "گان‌سیکلوویر داروی سیتومگالوویروس است، نه زونا، و سمیت مغز استخوان قابل توجهی دارد.",
  "پیپراسیلین-تازوباکتام آنتی‌بیوتیک وسیع‌الطیف است و در عفونت ویروسی جایی ندارد.",
  "پاسخ صحیح — زونا با والاسیکلوویر درمان می‌شود؛ فراهمی زیستی‌اش سه تا پنج برابر آسیکلوویر خوراکی است."],
 ["Doxycycline is an antibiotic and has no effect on varicella zoster virus.",
  "Ganciclovir is a cytomegalovirus drug, not a shingles drug, and carries considerable marrow toxicity.",
  "Piperacillin-tazobactam is a broad-spectrum antibiotic with no place in a viral infection.",
  "Correct — shingles is treated with valaciclovir, whose bioavailability is three to five times that of oral aciclovir."],
 "**عبور نکردن از خط وسط = درماتومی = زونا.** و در جوان با زونا، به HIV فکر کنید.",
 "Not crossing the midline means dermatomal, which means shingles; and in a young adult with shingles, think of HIV.",
 [H193, VARIZIG])


# =========================================================== book:638
add("book:638", "recall", "medium",
 "دوره‌ی کمون آبله‌مرغان **۱۰ تا ۲۱ روز** است، نه ۵ تا ۸ روز — این جمله‌ی غلط است.",
 "The incubation of chickenpox is 10 TO 21 DAYS, not 5 to 8 — that is the false statement.",
 PEP_FA + [
  "**این سؤال منفی است: باید جمله‌ی غلط را پیدا کنید، پس سه جمله باید درست باشند.**",
  "⚠️ **دوره‌ی کمون آبله‌مرغان ۱۰ تا ۲۱ روز است، به‌طور معمول حدود ۱۴ تا ۱۶ روز.**",
  "**«۵ تا ۸ روز» بسیار کوتاه‌تر از واقعیت است و همان جمله‌ی غلط سؤال است.**",
  "**چرا این عدد اهمیت عملی دارد؟ چون تمام تصمیم‌های پروفیلاکسی بر آن استوارند:**",
  "**پنجره‌ی ۱۰ روزه‌ی VZIG، شروع آسیکلوویر در روز ۷، و پایش تا روز ۲۱.**",
  "⚠️ **و اگر VZIG داده شود، کمون می‌تواند تا ۲۸ روز طولانی شود — پس پایش هم تا ۲۸ روز.**",
  "**سه جمله‌ی دیگر همگی درست‌اند و ارزش مرور دارند:**",
  "**VZIG در زن باردار سرم‌منفی یک گزینه‌ی پیشگیری است (هرچند امروز انتخاب دوم).**",
  "**واکسن زوستر در افراد بالای ۵۰ تا ۶۰ سال از بروز زونا پیشگیری می‌کند.**",
  "⚠️ **دقت کنید که واکسن زوستر با واکسن واریسلا فرق دارد: قدرت آنتی‌ژنی بسیار بالاتر.**",
  "**و نسل جدیدش (نوترکیب) غیرزنده است، پس در نقص ایمنی هم قابل استفاده است.**",
  "**و آسیکلوویر پروفیلاکسی در افراد پرخطر سرم‌منفی، توصیه‌ی معتبری است.**",
 ],
 PEP_EN + [
  "This is a negative question: find the FALSE statement, so three statements must be true.",
  "WARNING: THE INCUBATION OF CHICKENPOX IS 10 TO 21 DAYS, typically about 14 to 16.",
  "'5 to 8 days' is far shorter than reality and is the false statement.",
  "Why does that number matter practically? Because every prophylaxis decision rests on it:",
  "the 10-day VZIG window, starting aciclovir on day 7, and observation to day 21.",
  "WARNING, AND IF VZIG IS GIVEN THE INCUBATION MAY STRETCH TO 28 DAYS — so observation extends to 28 too.",
  "The other three statements are all true and worth reviewing:",
  "VZIG is an option for prophylaxis in a seronegative pregnant woman (though second choice today).",
  "The zoster vaccine prevents shingles in people over 50 to 60.",
  "WARNING, NOTE THAT THE ZOSTER VACCINE DIFFERS FROM THE VARICELLA VACCINE: far greater antigenic potency.",
  "And its newer recombinant form is non-live, so it can be used in immunosuppression as well.",
  "And prophylactic aciclovir in high-risk seronegative people is a valid recommendation.",
 ],
 "یک سؤال **منفی**: باید **جمله‌ی غلط** را پیدا کنید. پس سه جمله درست‌اند و یکی نیست.\n\n"
 "⚠️ **جمله‌ی غلط: «دوره‌ی کمون عفونت اولیه ۵ تا ۸ روز است.»**\n\n"
 "**دوره‌ی کمون واقعی آبله‌مرغان: ۱۰ تا ۲۱ روز، به‌طور معمول حدود ۱۴ تا ۱۶ روز.**\n\n"
 "**چرا این عدد فقط یک عدد حفظی نیست؟** چون **تمام تصمیم‌های پروفیلاکسی این فصل بر آن "
 "استوارند**:\n\n"
 "• **پنجره‌ی ۱۰ روزه‌ی VZIG** — که فقط در برابر کمون ۲۱ روزه معنا دارد\n"
 "• **شروع آسیکلوویر در روز ۷** — که مصادف با اوج تکثیر ویروسی در همین کمون است\n"
 "• **پایش فرد در معرض تماس تا روز ۲۱**\n\n"
 "⚠️ **و یک نکته‌ی مهم: اگر VZIG داده شود، کمون می‌تواند تا ۲۸ روز طولانی شود.** پس پایش "
 "هم باید تا **۲۸ روز** ادامه یابد. اگر کسی کمون را ۵ تا ۸ روز بداند، بیمار را روز نهم از "
 "پایش خارج می‌کند — و بیماری روز پانزدهم ظاهر می‌شود.\n\n"
 "**حالا سه جمله‌ی درست را مرور کنیم، چون هر سه ارزش دانستن دارند:**\n\n"
 "**۱) «در زنان حامله‌ی سرم‌منفی از VZIG به‌عنوان پیشگیری می‌توان استفاده کرد.»** ✔ درست "
 "است. (هرچند راهنمای امروزی **آنتی‌ویروال خوراکی را انتخاب اول** می‌داند و VZIG را برای "
 "کسی نگه می‌دارد که نمی‌تواند خوراکی بگیرد.)\n\n"
 "**۲) «واکسن واریسلازوستر در افراد بالای ۶۰ سال در پیشگیری از بروز زونا مؤثر است.»** ✔ "
 "درست است.\n\n"
 "⚠️ **و اینجا یک تمایز مهم:** **واکسن زوستر با واکسن واریسلا فرق دارد.** واکسن زوستر "
 "**قدرت آنتی‌ژنی بسیار بالاتری** دارد، چون هدفش **تقویت ایمنی موجود** است نه ایجاد ایمنی "
 "جدید. و **نسل جدیدش (نوترکیب، Shingrix) غیرزنده است** — پس برخلاف واکسن واریسلا، "
 "**در نقص ایمنی هم قابل استفاده است**.\n\n"
 "**۳) «تجویز آسیکلوویر به‌عنوان پیشگیری در افراد پرخطر سرم‌منفی توصیه می‌شود.»** ✔ درست "
 "است — همان قاعده‌ی «آسیکلوویر از روز هفتم» که در چند سؤال دیگر این فصل آزموده شده.",
 "A NEGATIVE question: find the FALSE statement. So three are true and one is not.\n\n"
 "WARNING, THE FALSE STATEMENT: 'the incubation period of primary infection is 5 to 8 days'.\n\n"
 "THE TRUE INCUBATION OF CHICKENPOX: 10 TO 21 DAYS, typically about 14 to 16.\n\n"
 "WHY IS THIS MORE THAN A NUMBER TO MEMORISE? Because EVERY PROPHYLAXIS DECISION IN THIS CHAPTER "
 "RESTS ON IT:\n\n"
 "• THE 10-DAY VZIG WINDOW — which only makes sense against a 21-day incubation\n"
 "• STARTING ACICLOVIR ON DAY 7 — coinciding with peak viral replication within that incubation\n"
 "• OBSERVING AN EXPOSED CONTACT TO DAY 21\n\n"
 "WARNING, AND AN IMPORTANT POINT: IF VZIG IS GIVEN THE INCUBATION CAN STRETCH TO 28 DAYS. So "
 "observation must continue to 28 DAYS. Someone who believes the incubation is 5 to 8 days would "
 "release the patient from observation on day nine — and the disease would appear on day fifteen.\n\n"
 "NOW LET US REVIEW THE THREE TRUE STATEMENTS, all worth knowing:\n\n"
 "1) 'VZIG can be used for prophylaxis in seronegative pregnant women.' TRUE. (Though current "
 "guidance makes ORAL ANTIVIRALS FIRST CHOICE and reserves VZIG for those who cannot take them.)\n\n"
 "2) 'The varicella-zoster vaccine is effective in preventing shingles in people over 60.' TRUE.\n\n"
 "WARNING, AND HERE AN IMPORTANT DISTINCTION: THE ZOSTER VACCINE DIFFERS FROM THE VARICELLA VACCINE. "
 "The zoster vaccine has FAR GREATER ANTIGENIC POTENCY, because its purpose is to BOOST EXISTING "
 "IMMUNITY rather than create new immunity. And its NEWER RECOMBINANT FORM (Shingrix) IS NON-LIVE — "
 "so unlike the varicella vaccine, IT CAN BE USED IN IMMUNOSUPPRESSION.\n\n"
 "3) 'Prophylactic aciclovir is recommended in high-risk seronegative people.' TRUE — the same "
 "'aciclovir from day seven' rule tested in several other questions in this chapter.",
 ["پاسخ صحیح — این جمله غلط است: کمون آبله‌مرغان ۱۰ تا ۲۱ روز است، نه ۵ تا ۸ روز.",
  "درست است؛ VZIG در زن باردار سرم‌منفی یک گزینه‌ی پیشگیری معتبر است.",
  "درست است؛ واکسن زوستر در سالمندان از بروز زونا پیشگیری می‌کند.",
  "درست است؛ آسیکلوویر پروفیلاکسی در افراد پرخطر سرم‌منفی توصیه می‌شود."],
 ["Correct — this statement is false: the chickenpox incubation is 10 to 21 days, not 5 to 8.",
  "True; VZIG is a valid prophylactic option in a seronegative pregnant woman.",
  "True; the zoster vaccine prevents shingles in older adults.",
  "True; prophylactic aciclovir is recommended in high-risk seronegative people."],
 "**کمون ۱۰ تا ۲۱ روز** — و با VZIG تا ۲۸ روز. تمام تصمیم‌های پروفیلاکسی بر همین عدد سوارند.",
 "The incubation is 10 to 21 days, and up to 28 with VZIG; every prophylaxis decision rides on that number.",
 [H193, VARIZIG])


json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book32.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 32 lessons:', len(L))
