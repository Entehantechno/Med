# -*- coding: utf-8 -*-
"""Numeric repair for the HIV cluster of the viral chapter (book:650-709).

METHOD, UNCHANGED FROM THE TEN EARLIER CHAPTERS
------------------------------------------------
pdfplumber gives the x coordinate of every glyph. A number is always DRAWN
left to right even inside right-to-left Persian text, so sorting a line's
characters by x0 recovers the digits in the order the typesetter placed them.
Anything the extractor produced that disagrees with that order is a defect of
extraction, not of the book.

WHAT THE SWEEP FOUND, AND WHY ONLY ONE REPAIR
----------------------------------------------
Every question of the cluster that still lacked a lesson (45 of them) was run
through the line-level checker. It reported four disagreements and one real
defect; the four disagreements were all the SAME artefact and all false:

    q9696  "36" and "10"   the stem wraps across two printed lines, and the
    q9696  "200"           checker matched only the first line, so the digits
    q9698  "180"           of the continuation looked absent
    q9701  "95"

Reading pages 257 to 259 by hand shows every one of those numbers printed
exactly as stored — 36-year-old, >10 per cent weight loss, CD4 < 200, CD4 180,
CD4 95. Nothing is repaired there, because inventing a repair where the page
agrees with the extraction is the worst thing this tool could do.

THE ONE REAL DEFECT
-------------------
q9707  page 261  viral load "5 copy/ml" -> "500 copy/ml"

This is the DROPPED-DIGIT shape (kind='restore'), not a mirrored one. The
printed line reads

    500copy/ml  رامیب دول لاریو و تسا 600 رامیب. CD4 تسا لامرن یو ینیلاب

and the glyph run at x = 70.8, 80.8, 90.8 is '5', '0', '0' — three characters
in ascending x, i.e. the page prints 500. The extractor kept only the leading
'5' because the fused Latin token "500copy/ml" straddles the direction change
at the start of an RTL line, the same place the endocarditis chapter lost
digits.

WHY THIS ONE MATTERS MORE THAN MOST
------------------------------------
The question is: a newly diagnosed patient, entirely asymptomatic, CD4 600,
viral load 500 copies/mL — start ART or not? The whole point is that the
answer is START ART ANYWAY, because since START and TEMPRANO (2015) treatment
is recommended at ANY CD4 count and ANY viral load. A student who reads the
viral load as "5 copies/mL" is being shown a number that is essentially
undetectable, which makes the distractor "no ART needed for now" look
defensible for a reason the examiner never intended. The corrupted digit does
not merely make the stem ugly; it makes the wrong answer attractive.

WHAT IS DELIBERATELY LEFT ALONE
--------------------------------
q9662's printed key is wrong, but that is an ANSWER defect and not a numeric
one; it is handled in fix_key_hiv_category.py, which is a separate script for
a separate class of problem.
"""
import collections
import io
import json
import os
import re

import pdfplumber

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = '/home/user/uploads/بیماری عفونی.pdf'

# question_no -> [(page, old, new, expected_printed_run, kind, why_fa), ...]
FIXES = {
    9707: [
        (261, '5 copy/ml', '500 copy/ml', '500', 'restore',
         'بار ویروسی بیمار: صفحه ۲۶۱ عدد **۵۰۰** را چاپ کرده است، ولی در استخراج دو '
         'رقم صفر **افتاده** بود و «5 copy/ml» باقی مانده بود. مختصات گلیف‌ها این را '
         'قطعی می‌کند: سه نویسه‌ی «۵»، «۰» و «۰» به‌ترتیب در x برابر ۷۰٫۸، ۸۰٫۸ و ۹۰٫۸ '
         'چاپ شده‌اند. این عدد **تعیین‌کننده‌ی معنای سؤال** است: با ویرال لود ۵۰۰ و '
         'CD4 برابر ۶۰۰، سؤال می‌پرسد آیا در بیمار **بی‌علامت با ایمنی خوب** هم باید '
         'ART شروع کرد — و پاسخ **بله** است، چون از مطالعات START و TEMPRANO به بعد، '
         'درمان در **هر CD4 و هر بار ویروسی** توصیه می‌شود. اگر دانشجو عدد را «۵ کپی» '
         'بخواند، عملاً بار ویروسی **غیرقابل‌شناسایی** می‌بیند و گزینه‌ی نادرست «فعلاً '
         'نیازی به ART نیست» بی‌جهت موجه جلوه می‌کند.'),
    ],
}

FOLD = {}
for _i in range(10):
    FOLD[chr(0x0660 + _i)] = str(_i)   # Arabic-Indic
    FOLD[chr(0x06F0 + _i)] = str(_i)   # Persian


def page_digit_runs(pdf, pno):
    """Digit runs of a page in PRINTED (x-ascending) order."""
    page = pdf.pages[pno - 1]
    rows = collections.defaultdict(list)
    for c in page.chars:
        rows[round(c['top'])].append(c)
    runs = []
    for top in sorted(rows):
        cs = sorted(rows[top], key=lambda c: c['x0'])
        cur = ''
        for c in cs:
            t = FOLD.get(c['text'], c['text'])
            # a space must NOT close an open run: kerning sometimes splits a
            # number, and closing on the space invents two numbers out of one
            if t.isspace() and cur:
                continue
            if t.isdigit():
                cur += t
            else:
                if cur:
                    runs.append(cur)
                cur = ''
        if cur:
            runs.append(cur)
    return runs


def main():
    pages = {p for specs in FIXES.values() for (p, *_r) in specs}
    with pdfplumber.open(SRC) as pdf:
        printed = {p: page_digit_runs(pdf, p) for p in pages}

    applied, missing = [], []
    for i in range(1, 6):
        path = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        if not os.path.exists(path):
            continue
        body = json.load(io.open(path, encoding='utf-8'))
        dirty = False
        for q in body['questions']:
            specs = FIXES.get(q['question_no'])
            if not specs:
                continue
            for pno, old, new, expect, kind, why in specs:
                assert expect in printed[pno], \
                    f'q{q["question_no"]}: page {pno} does not print {expect}'
                old_d = [c for c in old if c.isdigit()]
                new_d = [c for c in new if c.isdigit()]
                if kind == 'reorder':
                    assert sorted(old_d) == sorted(new_d), \
                        f'q{q["question_no"]}: {old} -> {new} is not a reordering'
                else:
                    assert kind == 'restore', f'unknown kind {kind!r}'
                    have = collections.Counter(new_d)
                    for ch, n in collections.Counter(old_d).items():
                        assert have[ch] >= n, \
                            f'q{q["question_no"]}: {old} -> {new} loses a printed digit'
                    for run in re.findall(r'\d+', new):
                        assert run in printed[pno], \
                            f'q{q["question_no"]}: page {pno} does not print restored {run}'
                    assert any(w in why for w in ('افتاده', 'باقی مانده', 'حذف')), \
                        f'q{q["question_no"]}: a restore must say a digit was dropped'

                hit = False
                if old in q['question_fa']:
                    q.setdefault('stem_original_fa', q['question_fa'])
                    q['question_fa'] = q['question_fa'].replace(old, new)
                    q.setdefault('stem_number_corrections', []).append({
                        'from': old, 'to': new, 'page': pno, 'where': 'stem',
                        'method': 'glyph geometry (pdfplumber x-order)',
                        'kind': kind, 'why_fa': why})
                    applied.append(f'q{q["question_no"]}: {old} -> {new} (stem)')
                    hit = True
                    dirty = True
                for oi, opt in enumerate(q['options_fa']):
                    if old in opt:
                        q.setdefault('options_original_fa', list(q['options_fa']))
                        q['options_fa'][oi] = opt.replace(old, new)
                        q.setdefault('stem_number_corrections', []).append({
                            'from': old, 'to': new, 'page': pno,
                            'where': f'option {oi + 1}',
                            'method': 'glyph geometry (pdfplumber x-order)',
                            'kind': kind, 'why_fa': why})
                        applied.append(
                            f'q{q["question_no"]}: {old} -> {new} (option {oi + 1})')
                        hit = True
                        dirty = True
                if not hit:
                    # Already applied on an earlier run is NOT a failure.
                    done = (new in q['question_fa']
                            or any(new in o for o in q['options_fa']))
                    if done:
                        applied.append(
                            f'q{q["question_no"]}: {old} -> {new} (already applied)')
                    else:
                        missing.append(f'q{q["question_no"]}: {old!r} not found')
        if dirty:
            json.dump(body, io.open(path, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)

    for a in applied:
        print('  ', a)
    assert not missing, missing
    assert applied, 'no repair matched; the script did nothing'
    print(f'numeric repairs: {len(applied)}')


if __name__ == '__main__':
    main()
