# -*- coding: utf-8 -*-
"""Cross-check the archive against the hand-built neurology bank.

The neurology bank was extracted booklet-by-booklet months before this archive
existed, from a partly different set of source files. If the two agree, the
generic parser is trustworthy enough to seed the remaining subjects from.

Matching has to be fuzzy on purpose: the bank was typed with proper Persian
orthography (ZWNJ, Persian digits) while the archive preserves whatever the PDF
emitted. We therefore compare on letters only — no digits, no ZWNJ, no spaces.
"""
import json, os, re, unicodedata, collections

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..', '..'))
ARCHIVE = os.path.join(HERE, 'archive.json')
BANK = os.path.join(ROOT, 'project', 'tools', 'neurology-bank', 'bank.json')

MON = {'خرداد': '03', 'شهریور': '06', 'آبان': '08', 'آذر': '09', 'اسفند': '12'}
FA = str.maketrans('۰۱۲۳۴۵۶۷۸۹', '0123456789')


def key(s):
    """Letters only: drops digits, ZWNJ, punctuation and every kind of space."""
    s = unicodedata.normalize('NFKC', s or '')
    s = s.translate(str.maketrans({'ي': 'ی', 'ك': 'ک'}))
    s = re.sub(r'[\u200c\u200f\u200e]', '', s)
    s = re.sub(r'[^\u0600-\u06FFa-zA-Z]', '', s)
    return re.sub(r'[۰-۹0-9]', '', s)


def similarity(a, b):
    """Character-trigram overlap.

    Exact substring matching is too brittle here: three of the source booklets
    were exported with a damaged font, so the archive spells a handful of words
    with a letter missing ("عضلانی" -> "عیوهنی"). Those are still obviously the
    same question, and a trigram measure says so, whereas `in` does not.
    """
    if not a or not b:
        return 0.0
    ta = {a[i:i + 3] for i in range(len(a) - 2)}
    tb = {b[i:i + 3] for i in range(len(b) - 2)}
    if not ta:
        return 0.0
    return len(ta & tb) / len(ta)


def run():
    arc = json.load(open(ARCHIVE, encoding='utf-8'))
    bank = json.load(open(BANK, encoding='utf-8'))
    qs = bank if isinstance(bank, list) else bank['questions']

    by_sitting = collections.defaultdict(list)
    for a in arc['questions']:
        if a['subject'] == 'مغز و اعصاب':
            by_sitting[a['sitting'].replace('-nf', '')].append(a)

    tested = matched = 0
    misses = []
    for q in qs:
        y, m = q.get('exam_year'), q.get('exam_month')
        if not y:
            continue
        yy = y.translate(FA)
        if len(yy) == 2:
            yy = '13' + yy
        tag = f'{yy}-{MON.get(m, "")}'
        cands = by_sitting.get(tag)
        if not cands:
            continue
        tested += 1
        k = key(q['stem_fa'])[:120]
        best = max((similarity(k, key(c['stem_fa'])) for c in cands), default=0)
        # 0.5 trigram overlap on a 120-character prefix is far beyond chance for
        # two unrelated clinical vignettes, but loose enough to survive a few
        # dropped letters from a broken font.
        if best >= 0.5:
            matched += 1
        else:
            misses.append((tag, q['question_no'], round(best, 2), q['stem_fa'][:58]))

    pct = matched / tested * 100 if tested else 0
    print(f'neurology items cross-checkable : {tested}')
    print(f'  matched in archive            : {matched}  ({pct:.1f}%)')
    if misses:
        print(f'  unmatched                     : {len(misses)}')
        for t, n, sc, s in misses[:10]:
            print(f'    {t} q{n} (best {sc}): {s}')
    return pct


if __name__ == '__main__':
    run()
