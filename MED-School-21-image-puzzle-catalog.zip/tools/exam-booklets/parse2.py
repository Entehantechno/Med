# -*- coding: utf-8 -*-
"""Structure the RTL-corrected text into questions — the number-safe pipeline.

Same job as parse.py, but reading rtl/<tag>.json (produced by extract_rtl.py)
instead of the PDF directly. That single change is what makes the ages, lab
values and vital signs correct: extract_rtl already put every digit run the
right way round, so nothing here has to guess about numbers again.

Everything else (subject headings, the three option layouts, the reversed
question number used as a checksum) is carried over unchanged, because those
parts were already verified 100% against the neurology bank.
"""
import json, os, re, sys, glob

HERE = os.path.dirname(os.path.abspath(__file__))
RTL, OUT = os.path.join(HERE, 'rtl'), os.path.join(HERE, 'out2')
os.makedirs(OUT, exist_ok=True)

FA_DIGITS = str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', '01234567890123456789')
ANY_DIGIT = '0-9۰-۹٠-٩'
AR_FOLD = str.maketrans({'ي': 'ی', 'ك': 'ک', 'ة': 'ه', 'أ': 'ا', 'إ': 'ا', 'آ': 'ا', 'ؤ': 'و'})

SUBJECTS_RAW = {
    'داخلی': 'داخلی', 'بیماریهایداخلی': 'داخلی',
    'جراحی': 'جراحی', 'بیماریهایجراحی': 'جراحی',
    'کودکان': 'کودکان', 'بیماریهایکودکان': 'کودکان', 'اطفال': 'کودکان',
    'زنان': 'زنان و زایمان', 'زنانوزایمان': 'زنان و زایمان', 'زنانومامایی': 'زنان و زایمان',
    'مغزواعصاب': 'مغز و اعصاب', 'نورولوژی': 'مغز و اعصاب', 'اعصابومغز': 'مغز و اعصاب',
    'عفونی': 'عفونی', 'بیماریهایعفونی': 'عفونی',
    'روانپزشکی': 'روان‌پزشکی', 'اعصابوروان': 'روان‌پزشکی', 'روان': 'روان‌پزشکی',
    'رادیولوژی': 'رادیولوژی', 'تصویربرداری': 'رادیولوژی',
    'پاتولوژی': 'پاتولوژی', 'آسیبشناسی': 'پاتولوژی',
    'قلب': 'قلب', 'پوست': 'پوست', 'بیماریهایپوست': 'پوست',
    'چشم': 'چشم', 'گوشوحلقوبینی': 'گوش و حلق و بینی', 'گوشحلقوبینی': 'گوش و حلق و بینی',
    'ارتوپدی': 'ارتوپدی', 'اورولوژی': 'اورولوژی',
    'پزشکیقانونی': 'پزشکی قانونی', 'اخلاقپزشکی': 'اخلاق پزشکی', 'اخلاقپزشک': 'اخلاق پزشکی',
    'اپیدمیولوژی': 'اپیدمیولوژی و آمار', 'آمارواپیدمیولوژی': 'اپیدمیولوژی و آمار',
    'پزشکیاجتماعی': 'پزشکی اجتماعی', 'بهداشت': 'پزشکی اجتماعی',
    'فارماکولوژی': 'فارماکولوژی', 'داروشناسی': 'فارماکولوژی',
    'ژنتیک': 'ژنتیک', 'طباورژانس': 'طب اورژانس', 'اورژانس': 'طب اورژانس',
}


def norm_key(s):
    s = s.translate(AR_FOLD)
    return re.sub(r'[\s\u200c\u200f\u200e:()\-–—.،]', '', s)


SUBJECTS = {norm_key(k): v for k, v in SUBJECTS_RAW.items()}

NOISE = re.compile(
    r'آزمون\s*:?\s*پیش\s*کارورزی|آزمون\s*جامع\s*پیش|مدت\s*آزمون|صفحه\s*\d+|^\s*\d+\s*$|'
    r'وزارت\s*بهداشت|معاونت\s*آموزشی|مرکز\s*سنجش|دبیرخانه|جمهوری\s*اسلامی|'
    r'مشخصات\s*داوطلب|تذکرات\s*مهم|نمره\s*منفی|کلان\s*منطقه|'
    # The konkur.in watermark is stamped on every page and, on RTL pages, comes
    # out reversed ("in.konkur.www"). Match both directions or it survives as a
    # fake option.
    r'www\.konkur\.in|forum\.konkur\.in|konkur\.in|in\.konkur\.|konkur|'
    r'ReportControl|ReportAzmoon|TestId=|دانشکده\s*پزشکی|'
    r'^\d+/\d+/\d+,?\s|^\s*\d+\.\d+\.\d+\.\d+|'
    # The Rasht exporter prints an empty "منبع:" (reference) row after every
    # question. Before the glyph repair runs it still contains the NUL hole, so
    # match both spellings — otherwise it survives as a fourth "option".
    r'^\s*:?\s*(?:منبع|من\x00ع|من\ufffdع)\s*:?\s*$|آزمون\s*میان\s*دوره|کشوری\s*-\s*فارسی'
)

Q_START = re.compile(
    rf'^\s*[-–ـ]?\s*([{ANY_DIGIT}]{{1,3}})\s*[-–ـ]\s*(.*)$'
    rf'|^\s*[-–ـ]\s*([{ANY_DIGIT}]{{1,3}})\s*(.*)$'
    rf'|^\s*([{ANY_DIGIT}]{{1,3}})\s+و\s+(.{{8,}})$'
)
OPT_PREFIX = re.compile(r'^\s*(?:الف|ب|ج|د)\s*[)(\-–.]?\s+(.*)$')
INLINE_OPTS = re.compile(r'(?:^|\s)(الف|ب|ج|د)\s*[)(]\s*')
MID_Q = re.compile(rf'(?<=\s)([{ANY_DIGIT}]{{1,3}}\s*[-–ـ]\s)')
TAIL = re.compile(r'اعتراض|سایت\s*مرکز\s*سنجش|راه\s*های\s*ارتباطی')


def explode(raw):
    parts = MID_Q.split(raw)
    if len(parts) <= 1:
        return [raw]
    out, cur = [], parts[0]
    for i in range(1, len(parts), 2):
        out.append(cur)
        cur = parts[i] + (parts[i + 1] if i + 1 < len(parts) else '')
    out.append(cur)
    return [p for p in out if p.strip()]


def split_inline_options(lines):
    out = []
    for ln in lines:
        marks = list(INLINE_OPTS.finditer(ln))
        if len(marks) >= 3:
            if marks[0].start() > 0:
                head = ln[:marks[0].start()].strip()
                if head:
                    out.append(head)
            for i, m in enumerate(marks):
                end = marks[i + 1].start() if i + 1 < len(marks) else len(ln)
                out.append(f'{m.group(1)}) {ln[m.end():end].strip()}')
        else:
            out.append(ln)
    return out


# Booklets exported through the Rasht exam-report system print no subject
# headings at all. A bare word that merely LOOKS like one ("روان", "اورژانس")
# then hijacks the rest of the paper — 1403-03 ended up with 60 "neurology"
# questions that way. For these we skip heading detection entirely and let
# infer.py borrow the ranges from a sibling sitting instead.
NO_HEADINGS = {'1400-03', '1402-03', '1403-03', '1403-03-nf'}


def parse(tag):
    src = os.path.join(RTL, f'{tag}.json')
    doc = json.load(open(src, encoding='utf-8'))
    rows, subject, buf, stop = [], '', None, False
    for page in doc['pages']:
        if stop:
            break
        for chunk in page['lines']:
            for raw in explode(chunk):
                s = raw.replace('\xa0', ' ').replace('\u200f', '').strip()
                if not s or NOISE.search(s):
                    continue
                if TAIL.search(s) and len(rows) > 150:
                    stop = True
                    break
                k = norm_key(s)
                if tag not in NO_HEADINGS and k in SUBJECTS and len(s) < 30:
                    subject = SUBJECTS[k]
                    continue
                m = Q_START.match(s)
                if m:
                    g = m.groups()
                    num = (g[0] or g[2] or g[4] or '').translate(FA_DIGITS)
                    rest = (g[1] or g[3] or g[5] or '').strip()
                    if buf:
                        rows.append(buf)
                    buf = {'printed_no': num, 'subject': subject,
                           'page': page['page'], 'lines': [rest] if rest else []}
                    continue
                if buf is not None:
                    buf['lines'].append(s)
    if buf:
        rows.append(buf)

    # Checksum pass: the printed number may still read either way round, so keep
    # whichever interpretation keeps the sequence monotonic and drop rows that
    # fit neither (false positives from the mid-line splitter).
    kept, expect = [], 1
    for r in rows:
        raw = r['printed_no'] or '0'
        cands = {int(raw), int(raw[::-1] or 0)}
        if expect in cands:
            r['real_no'] = expect
            kept.append(r)
            expect += 1
        elif kept and expect + 1 in cands:
            r['real_no'] = expect + 1
            kept.append(r)
            expect += 2
    rows = kept if len(kept) >= 0.9 * len(rows) else [
        dict(r, real_no=i) for i, r in enumerate(rows, 1)]

    questions = []
    for r in rows:
        lines = split_inline_options(r['lines'])
        marked = [(i, m.group(1)) for i, l in enumerate(lines) if (m := OPT_PREFIX.match(l))]
        if len(marked) >= 4:
            first = marked[-4][0]
            opts = [t for _, t in marked[-4:]]
            stem = ' '.join(lines[:first]).strip()
        else:
            opts = lines[-4:] if len(lines) >= 5 else []
            stem = ' '.join(lines[:-4] if opts else lines).strip()

        # A stem that does not end in a question mark or colon has usually
        # swallowed the first option: the exporter put the question text and
        # option A on the same physical line, so our "last four lines" rule
        # took options B-E and left A glued to the stem. Split it back off at
        # the question mark, which is where the stem genuinely ends.
        if opts and stem and not re.search(r'[؟?:]\s*$', stem):
            m = re.search(r'[؟?]\s*', stem)
            if m and m.end() < len(stem) - 3:
                head, tail = stem[:m.end()].strip(), stem[m.end():].strip()
                if tail and len(tail) < 120:
                    stem, opts = head, ([tail] + opts)[:4]
        questions.append({
            'no': r['real_no'], 'printed_no': r['printed_no'],
            'subject': r['subject'], 'page': r['page'],
            'stem_fa': stem, 'options_fa': [o.strip() for o in opts],
        })
    return {'tag': tag, 'ok': True, 'pages': len(doc['pages']),
            'count': len(questions), 'questions': questions}


if __name__ == '__main__':
    tags = sys.argv[1:] or sorted(os.path.basename(p)[:-5] for p in glob.glob(os.path.join(RTL, '*.json')))
    for t in tags:
        d = parse(t)
        json.dump(d, open(os.path.join(OUT, f'{t}.json'), 'w', encoding='utf-8'),
                  ensure_ascii=False, indent=1)
        subs = {}
        for q in d['questions']:
            subs[q['subject'] or '?'] = subs.get(q['subject'] or '?', 0) + 1
        top = ', '.join(f'{k}={v}' for k, v in sorted(subs.items(), key=lambda x: -x[1])[:5])
        print(f'{t:14} {d["count"]:3} q | {top}')
