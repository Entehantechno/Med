# -*- coding: utf-8 -*-
"""Attach official English + printed subject headers to archive sitting 1402-03."""
import io, json, os

HERE = os.path.dirname(os.path.abspath(__file__))
EN = os.path.join(HERE, 'out', 'en_1402_03.json')
ARCHIVE = os.path.join(HERE, 'archive.json')


def main():
    pair = {r['question_no']: r for r in json.load(io.open(EN, encoding='utf-8'))}
    arch = json.load(io.open(ARCHIVE, encoding='utf-8'))
    n = 0
    for q in arch['questions']:
        if q.get('sitting') != '1402-03':
            continue
        p = pair.get(q.get('no'))
        if not p:
            continue
        q['stem_en'] = p['stem_en']
        q['options_en'] = p['options_en']
        q['en_source'] = 'official_booklet'
        q['subject'] = p['subject_fa']
        q['subject_en'] = p['subject_en']
        q['subject_inferred'] = False
        n += 1
    note = arch.get('note') or ''
    if 'Khordad-1402' not in note:
        arch['note'] = (note + ' | Khordad-1402 carries the ministry\'s own '
                        'English booklet (en_source: official_booklet).').strip(' |')
    arch.setdefault('totals', {})['with_official_english'] = sum(
        1 for q in arch['questions'] if q.get('en_source') == 'official_booklet')
    json.dump(arch, io.open(ARCHIVE, 'w', encoding='utf-8'), ensure_ascii=False)
    print(f'attached official EN+subjects to {n} archive rows')
    print('with_official_english', arch['totals']['with_official_english'])


if __name__ == '__main__':
    main()
