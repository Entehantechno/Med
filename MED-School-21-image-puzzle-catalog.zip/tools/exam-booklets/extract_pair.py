# -*- coding: utf-8 -*-
"""Extract a matched Persian/English ministry booklet pair.

Why this matters
----------------
The user's standing rule: when an exam publishes its own English booklet, use
THAT translation, never ours. Esfand-1400 published both, so this pair gives us
200 questions across 16 subjects with ministry-authored English on both the
stem and every option — the highest-quality bilingual source we have.

Pairing strategy
----------------
Both booklets number their questions 1..200 in the same order, so the question
number is the join key. We parse each side independently and then match on the
number, refusing to pair anything where the option counts disagree.

Persian side quirks (already solved in extract_rtl):
  * visual glyph order, digits silently reversed
  * lam-alef written as "ال" (سواالت for سوالات)
Latin fragments inside Persian lines come out reversed ("calprotectin Stool"
for "Stool calprotectin"); those are option texts and we take the ENGLISH side
for them anyway, so we do not try to repair them.
"""
import json, io, os, re, sys
import pdfplumber

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from extract_rtl import unreverse, fold, is_visual

HERE = os.path.dirname(os.path.abspath(__file__))
FA_PDF = '/home/user/uploads/پیش کارورزی - فارسی.pdf'
EN_PDF = '/home/user/uploads/پیش کارورزی - انگلیسی.pdf'

EXAM = {'year': 1400, 'year_fa': '۱۴۰۰', 'month': 'اسفند', 'month_en': 'Esfand',
        'date': '1400/12/12'}

SUBJECTS_EN = [
    'Internal Medicine', 'General Surgery', 'Pediatric', 'Obstetrics and gynecology',
    'Neurology', 'Infectious Diseases', 'Radiology', 'Pathology', 'Psychiatry',
    'Dermatology', 'Bone and joint surgery', 'Urology', 'Ophthalmology',
    'Pharmacology', 'Medical Ethics',
]
SUBJ_FA = {
    'Internal Medicine': 'داخلی', 'General Surgery': 'جراحی', 'Pediatric': 'کودکان',
    'Obstetrics and gynecology': 'زنان و زایمان', 'Neurology': 'نورولوژی',
    'Infectious Diseases': 'بیماری‌های عفونی', 'Radiology': 'رادیولوژی',
    'Pathology': 'پاتولوژی', 'Psychiatry': 'روان‌پزشکی', 'Dermatology': 'پوست',
    'Bone and joint surgery': 'ارتوپدی', 'Urology': 'اورولوژی',
    'Ophthalmology': 'چشم‌پزشکی', 'Pharmacology': 'فارماکولوژی',
    'Medical Ethics': 'اخلاق پزشکی',
}

EN_Q = re.compile(r'^\s*(\d{1,3})\s*-\s*(.*)$')
EN_OPT = re.compile(r'^\s*([a-d])\)\s*(.*)$')
FA_Q = re.compile(r'^\s*([0-9۰-۹]{1,3})\s*-\s*(.*)$')
FA_OPT = re.compile(r'^\s*(الف|ب|ج|د)\)\s*(.*)$')
FA_IX = {'الف': 0, 'ب': 1, 'ج': 2, 'د': 3}
DIG = str.maketrans('۰۱۲۳۴۵۶۷۸۹', '0123456789')


# The booklet ends with an objection form ("In the Name of God / The
# Secretariat ..."). Its text would otherwise be swallowed into question 200's
# last option, so stop reading at that boundary.
EN_END = re.compile(r'^(In the Name of God|The Secretariat of Education Council)')


def en_lines():
    out = []
    with pdfplumber.open(EN_PDF) as pdf:
        for i, p in enumerate(pdf.pages):
            if i == 0:
                continue                     # cover page
            for ln in (p.extract_text() or '').split('\n'):
                s = re.sub(r'\s+', ' ', ln).strip()
                if not s:
                    continue
                if EN_END.match(s):
                    return out
                out.append(s)
    return out


def fa_lines():
    out = []
    with pdfplumber.open(FA_PDF) as pdf:
        for p in pdf.pages:
            t = p.extract_text() or ''
            if not t.strip():
                continue
            t = fold(t)
            vis = is_visual(t)
            for ln in t.split('\n'):
                s = unreverse(ln) if vis else ln
                s = re.sub(r'\s+', ' ', s).strip()
                if s and not re.match(r'^صفحه\s*\d+$', s) and not RUNNING_HEAD.match(s):
                    out.append(s)
    return join_orphan_markers(out)


# The page header repeats on every page and would otherwise be swallowed into
# whichever option text was still open across the page break.
RUNNING_HEAD = re.compile(r'^آزمون جامع پیش\s*کارورزی')


# When an option's text is entirely Latin ("Stool calprotectin"), the RTL
# exporter emits the text on one line and the bare marker "الف)" on the NEXT
# line, because the marker is the only right-to-left run. Detected by a line
# that is nothing but a marker; the text belongs to the line just above.
ORPHAN = re.compile(r'^(الف|ب|ج|د)\)\s*$')


def join_orphan_markers(lines):
    out = []
    for ln in lines:
        m = ORPHAN.match(ln)
        if m and out:
            # the previous line was the option body
            body = out.pop()
            out.append(f'{m.group(1)}) {body}')
            continue
        # Same split the other way round: a marker glued to a trailing Persian
        # word ("د) سنجش") whose Latin body sat on the line before ("CA19-9").
        m2 = re.match(r'^(الف|ب|ج|د)\)\s*(.+)$', ln)
        if m2 and out and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9./-]*', out[-1]):
            body = out.pop()
            out.append(f'{m2.group(1)}) {m2.group(2)} {body}')
            continue
        out.append(ln)
    return out


def parse(lines, qre, ore, ix_of, subject_names):
    """Cut a booklet into {no: {stem, options, subject}}."""
    qs, cur, subject = {}, None, ''
    for ln in lines:
        if ln in subject_names:
            subject = ln
            continue
        mo = ore.match(ln)
        if mo and cur is not None:
            cur['_last'] = ix_of(mo.group(1))
            cur['opts'][cur['_last']] = mo.group(2).strip()
            continue
        mq = qre.match(ln)
        # a question number only starts a new item if we are not mid-options
        if mq and (cur is None or cur['opts']):
            no = int(mq.group(1).translate(DIG))
            if 1 <= no <= 200 and no not in qs:
                cur = {'no': no, 'stem': [mq.group(2).strip()], 'opts': {},
                       'subject': subject}
                qs[no] = cur
                continue
        if cur is None:
            continue
        if cur['opts'] and '_last' in cur:
            cur['opts'][cur['_last']] += ' ' + ln
        else:
            cur['stem'].append(ln)
    return qs


# Page furniture that bleeds into whichever option was still open when the page
# broke. Stripped from the tail of every field rather than filtered by line,
# because the exporter sometimes glues it on without a newline.
TRAILER = re.compile(
    r'\s*(Page\s*\d+|Comprehensive Exam of Pre-Internship[^|]*|'
    r'آزمون جامع پیش\s*کارورزی[^|]*|صفحه\s*\d+)\s*$')


def tidy(s):
    s = re.sub(r'\s+', ' ', s or '').strip()
    prev = None
    while prev != s:                 # trailers can stack: "Page2 Comprehensive…"
        prev = s
        s = TRAILER.sub('', s).strip()
    return s.strip(' :.-')


def main():
    en = parse(en_lines(), EN_Q, EN_OPT, lambda c: 'abcd'.index(c), set(SUBJECTS_EN))
    fa = parse(fa_lines(), FA_Q, FA_OPT, lambda c: FA_IX[c], set(SUBJ_FA.values()))
    print(f'parsed  EN: {len(en)}   FA: {len(fa)}')

    rows, skipped = [], []
    for no in sorted(set(en) | set(fa)):
        e, f = en.get(no), fa.get(no)
        if not e or not f:
            skipped.append((no, 'missing side'))
            continue
        eo = [tidy(e['opts'].get(i, '')) for i in range(4)]
        fo = [tidy(f['opts'].get(i, '')) for i in range(4)]
        if not all(eo) or not all(fo):
            skipped.append((no, f'options en={sum(1 for x in eo if x)} fa={sum(1 for x in fo if x)}'))
            continue
        subj_en = e['subject'] or ''
        rows.append({
            'question_no': no,
            'subject_en': subj_en,
            'subject_fa': SUBJ_FA.get(subj_en, f['subject'] or ''),
            'stem_fa': tidy(' '.join(f['stem'])),
            'stem_en': tidy(' '.join(e['stem'])),
            'options_fa': fo,
            'options_en': eo,
            'en_source': 'official_booklet',
            **EXAM,
        })

    os.makedirs(os.path.join(HERE, 'out'), exist_ok=True)
    dest = os.path.join(HERE, 'out', 'pair_1400_12.json')
    json.dump(rows, io.open(dest, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

    import collections
    c = collections.Counter(r['subject_fa'] for r in rows)
    print(f'paired: {len(rows)}   skipped: {len(skipped)}')
    print('subjects: ' + ', '.join(f'{k}={v}' for k, v in c.most_common()))
    if skipped[:8]:
        print('skipped sample:', skipped[:8])
    print('->', dest)


if __name__ == '__main__':
    main()
