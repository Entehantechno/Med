# -*- coding: utf-8 -*-
"""Make Shahrivar-1403 (with floating) 200 questions that match the printed key.

Two parser artefacts:
  * q72+q73 are one vignette split mid-sentence (short-stature boy).
  * q195 is leftover option text (\"IL د)\") from q194.
After the merge and drop, numbering matches the official 1..200 key table
(verified: phenytoin becomes q97 = ب, status epilepticus q99 = د).
"""
import json, io, os

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, 'out2', '1403-06.json')
KEY = os.path.join(HERE, 'keys', '1403-06.json')


def main():
    d = json.load(io.open(SRC, encoding='utf-8'))
    qs = d['questions']
    by = {q['no']: q for q in qs}
    a, b = by[72], by[73]
    a['stem_fa'] = (a.get('stem_fa') or '').rstrip() + ' ' + (b.get('stem_fa') or '').lstrip()
    a['options_fa'] = b.get('options_fa') or a.get('options_fa') or []
    a['options_incomplete'] = len(a['options_fa']) != 4

    keep = []
    for q in qs:
        if q['no'] == 73 or q['no'] == 195:
            continue
        keep.append(q)
    keep.sort(key=lambda q: q['no'])
    for i, q in enumerate(keep, 1):
        q['printed_no'] = str(q.get('printed_no') or q['no'])
        q['no'] = i

    d['questions'] = keep
    d['count'] = len(keep)
    d['aligned_to_official_key'] = True
    json.dump(d, io.open(SRC, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

    key = {int(k): int(v) for k, v in json.load(io.open(KEY, encoding='utf-8')).items()
           if k.isdigit()}
    checks = {
        97: (1, 'فنی'),   # phenytoin
        99: (3, 'صرع استاتوس'),
        100: (0, 'آسیکلوویر'),
    }
    print(f'1403-06 now {len(keep)} questions')
    for no, (want, needle) in checks.items():
        q = keep[no - 1]
        hit = needle in (q['stem_fa'] or '')
        print(f'  q{no}: key={key.get(no)} want={want} needle={hit} {q["stem_fa"][:70]}')
    assert len(keep) == 200
    assert 'فنی' in keep[96]['stem_fa']
    assert 'استاتوس' in keep[98]['stem_fa']


if __name__ == '__main__':
    main()
