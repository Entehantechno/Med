# -*- coding: utf-8 -*-
"""Recover the glyphs the Rasht-exported booklets dropped (post-RTL pipeline).

Three sittings (1402-03, 1403-03, 1403-03-nf) were exported with a broken font
map: two letters came out as U+0000 everywhere. extract_rtl.py already folded
the presentation forms to plain Persian, so unlike the first-generation repair
we are working with ordinary letters and can use the *language* to decide.

Two letters account for essentially all of it — ی and پ — and Persian
orthography separates them cleanly:

  * ی is by far the more common, and it is the only one of the two that appears
    word-finally or before a space ("زیر", "این", "صحیح", "بیمار").
  * پ almost always starts a syllable and is followed by a vowel-carrying
    letter, and in this corpus it shows up in a small, closed set of words
    (پزشک, پرسش, پیش, پاسخ, سپس …).

So we run a dictionary pass first — it is exact, and it covers the bulk — then
fall back to ی, which is the safe default given the frequency gap. Anything the
dictionary contradicts is left visible as U+FFFD rather than guessed.
"""
import json, os, re, glob

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'out2')
M = '\ufffd'

# Three letters were lost, not two: ی, ب and پ. Their frequencies are wildly
# uneven — ی dominates — and each has a distinct signature in the surrounding
# characters, so a short ordered rule list beats any single heuristic.
#
# Longest patterns first, because "منبع" must win before the bare "من" prefix
# rule ever sees it.
WORDS = [
    ('\u200c', ''),                        # stray ZWNJ next to a hole
    # --- پ ---
    (M + 'زشک', 'پزشک'), (M + 'رسش', 'پرسش'), (M + 'اسخ', 'پاسخ'),
    (M + 'روتئ', 'پروتئ'), (M + 'وست', 'پوست'), (M + 'لاکت', 'پلاکت'),
    ('س' + M + 'س ', 'سپس '), (M + 'یشگیری', 'پیشگیری'),
    (M + 'ونکس' + M + 'ون', 'پونکسیون'), (M + 'ونکسیون', 'پونکسیون'),
    (M + 'رفرینجنس', 'پرفرینجنس'),
    (M + 'نومون', 'پنومون'), (M + 'نی سیلین', 'پنی سیلین'),
    # --- ب ---
    ('من' + M + 'ع', 'منبع'), ('ر ' + M + 'رر', 'ر برر'), (M + 'ررس', 'بررس'),
    (M + 'یمار', 'بیمار'), (M + 'رای', 'برای'), (M + 'اید', 'باید'),
    (M + 'اشد', 'باشد'), (M + 'دون', 'بدون'), (M + 'الا', 'بالا'),
    (M + 'عد', 'بعد'), (M + 'هتر', 'بهتر'), ('تجر' + M + 'ی', 'تجربی'),
    ('متا' + M + 'ول', 'متابول'), ('تو' + M + 'رکل', 'توبرکل'),
    ('لن' + M + 'وپ', 'لنفوپ'), (M + 'یوپس', 'بیوپس'),
    # --- ی (everything else, but spell out the frequent ones) ---
    ('ز' + M + 'ر', 'زیر'), ('ا' + M + 'ن', 'این'), ('صح' + M + 'ح', 'صحیح'),
    ('تر' + M + 'ن', 'ترین'), ('تجو' + M + 'ز', 'تجویز'), ('تزر' + M + 'ق', 'تزریق'),
    ('تعر' + M + 'ق', 'تعریق'), ('اسم' + M + 'ر', 'اسمیر'), ('مث' + M + 'ت', 'مثبت'),
    ('س' + M + 'نه', 'سینه'), ('ن' + M + 'ز', 'نیز'), ('ه' + M + 'چ', 'هیچ'),
    ('م' + M + ' ', 'می '), ('رس' + M + ' ', 'رسی '), ('کو' + M + ' ', 'کوی '),
    # a hole INSIDE a word that already contains ب is ی, not another ب
    ('باکتر' + M + 'وم', 'باکتریوم'), ('اعت' + M + 'اد', 'اعتیاد'),
    ('اس' + M + 'ون', 'اسیون'), ('کس' + M + 'ون', 'کسیون'),
    ('ترک' + M + 'اد', 'ترکیاد'), ('آنت' + M + ' ', 'آنتی '),
]

# Letter-level: which side the hole joins tells us nothing now that the forms
# are folded, so we use position in the WORD instead.
NONJOIN_LEFT = set('ادذرزژو')   # letters that never connect to the next one


def repair(s):
    if M not in s:
        return s, 0
    before = s.count(M)
    for a, b in WORDS:
        s = s.replace(a, b)

    out = []
    for i, ch in enumerate(s):
        if ch != M:
            out.append(ch)
            continue
        prev = s[i - 1] if i else ' '
        nxt = s[i + 1] if i + 1 < len(s) else ' '
        starts_word = (i == 0 or prev in ' ([«\u200c' or prev in NONJOIN_LEFT)
        # After the dictionary pass the remainder is overwhelmingly ی: it is the
        # commonest letter in Persian and the only one of the three that occurs
        # word-finally or before a space. ب is the sane default for a hole that
        # clearly STARTS a word, since پ is several times rarer and its frequent
        # words are already covered above. Guessing ی everywhere else costs at
        # most a rare typo; guessing پ would corrupt common words.
        out.append('ب' if (starts_word and nxt.isalpha()) else 'ی')
    s = ''.join(out)
    return s, before - s.count(M)


def run():
    total_before = total_fixed = 0
    for f in sorted(glob.glob(os.path.join(OUT, '*.json'))):
        d = json.load(open(f, encoding='utf-8'))
        if not d.get('ok'):
            continue
        n_before = n_fixed = 0
        for q in d['questions']:
            # parse2 leaves the hole as a raw NUL; normalise to the visible marker
            q['stem_fa'] = q['stem_fa'].replace('\x00', M)
            q['options_fa'] = [o.replace('\x00', M) for o in q['options_fa']]
            n_before += q['stem_fa'].count(M) + sum(o.count(M) for o in q['options_fa'])
            q['stem_fa'], k = repair(q['stem_fa'])
            n_fixed += k
            fixed_opts = []
            for o in q['options_fa']:
                o2, k2 = repair(o)
                n_fixed += k2
                fixed_opts.append(o2)
            q['options_fa'] = fixed_opts
        if n_before:
            json.dump(d, open(f, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
            print(f'{d["tag"]:14} {n_before:5} broken -> repaired {n_fixed:5}, left {n_before - n_fixed:4}')
        total_before += n_before
        total_fixed += n_fixed
    if total_before:
        print(f'\ntotal {total_before} broken glyphs, {total_fixed} repaired '
              f'({total_fixed / total_before * 100:.1f}%)')


if __name__ == '__main__':
    run()
