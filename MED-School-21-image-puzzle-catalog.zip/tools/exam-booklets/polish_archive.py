# -*- coding: utf-8 -*-
"""Polish the freshly extracted archive.

1. Apply a closed dictionary of Rasht-export letter holes that the generic
   glyph repair guessed as ی/ب when the word was actually something else.
2. Overlay official English (and printed subject headers) for the two sittings
   that published a ministry English booklet.
3. Recover missing option lists from that English booklet when the Persian
   parse lost the four choices.
"""
import io, json, os, re, collections

HERE = os.path.dirname(os.path.abspath(__file__))
ARCHIVE = os.path.join(HERE, 'archive.json')
EN_1402 = os.path.join(HERE, 'out', 'en_1402_03.json')
PAIR_1400 = os.path.join(HERE, 'out', 'pair_1400_12.json')
PAIR_1402_OUT = os.path.join(HERE, 'pair_1402_03.json')
PAIR_1400_OUT = os.path.join(HERE, 'pair_1400_12.json')

# Longest first. Only unambiguous medical/Persian words the Rasht font broke.
TERMS = [
    ('کالریترومایسین', 'کلاریترومایسین'),
    ('پیتوبرازول', 'پنتوپرازول'),
    ('بتراسیکلین', 'تتراسیکلین'),
    ('اُمیرازول', 'امپرازول'),
    ('امیرازول', 'امپرازول'),
    ('اندوسکوبی', 'اندوسکوپی'),
    ('فاموتیدبن', 'فاموتیدین'),
    ('خونربزی', 'خونریزی'),
    ('خونریری', 'خونریزی'),
    ('عالئم', 'علایم'),
    ('عالیم', 'علایم'),
    ('عالمت', 'علامت'),
    ('بروداکتیو', 'پروداکتیو'),
    ('آنتی ییوتیک', 'آنتی‌بیوتیک'),
    ('آنتیییوتیک', 'آنتی‌بیوتیک'),
    ('بروفیالکسی', 'پروفیلاکسی'),
    ('پروفیالکسی', 'پروفیلاکسی'),
    ('الموتیریژین', 'لاموتریژین'),
    ('اختالل', 'اختلال'),
    ('حمالت', 'حملات'),
    ('وساس', 'وسواس'),
    ('نسیت', 'نسبت'),
    ('شابع', 'شایع'),
    ('قیولی', 'قبولی'),
    ('نتابج', 'نتایج'),
    ('می برسید', 'می‌پرسید'),
    ('می برسد', 'می‌پرسد'),
    ('رادبوگرافی', 'رادیوگرافی'),
    ('پابول', 'پاپول'),
    ('ماکولو پابولر', 'ماکولوپاپولر'),
    ('چسینده', 'چسبنده'),
    ('پالکی', 'پلاکی'),
    ('گراوید', 'گراوید'),
    ('کنتراندیکاسیون', 'کنترااندیکاسیون'),
    ('کنتراندیکه', 'کنترااندیکه'),
    ('متوتروکسات', 'متوترکسات'),
    ('هاییرترمی', 'هایپرترمی'),
    ('همی پارزی', 'همی‌پارزی'),
    ('دیس پپسی', 'دیس‌پپسی'),
]


def polish_text(s):
    if not s:
        return s
    for a, b in TERMS:
        s = s.replace(a, b)
    return s


def apply_terms(q):
    q['stem_fa'] = polish_text(q.get('stem_fa') or '')
    q['options_fa'] = [polish_text(o) for o in (q.get('options_fa') or [])]


def main():
    arch = json.load(io.open(ARCHIVE, encoding='utf-8'))
    en1402 = {r['question_no']: r for r in json.load(io.open(EN_1402, encoding='utf-8'))}
    pair1400 = {r['question_no']: r for r in json.load(io.open(PAIR_1400, encoding='utf-8'))}

    n_term = n_en = n_subj = n_opt = 0
    pair1402 = []
    pair1400_out = []

    for q in arch['questions']:
        before = q.get('stem_fa', '')
        apply_terms(q)
        if q.get('stem_fa') != before or any(
                polish_text(o) != o for o in (q.get('options_fa') or [])):
            n_term += 1

        sitting, no = q.get('sitting'), q.get('no')
        rec = None
        if sitting == '1402-03':
            rec = en1402.get(no)
        elif sitting == '1400-12':
            rec = pair1400.get(no)

        if rec:
            if rec.get('stem_en'):
                q['stem_en'] = rec['stem_en']
                q['options_en'] = rec.get('options_en') or []
                q['en_source'] = 'official_booklet'
                n_en += 1
            if rec.get('subject_fa'):
                q['subject'] = rec['subject_fa']
                q['subject_en'] = rec.get('subject_en')
                q['subject_inferred'] = False
                n_subj += 1
            if len(q.get('options_fa') or []) != 4 and rec.get('options_en'):
                # keep the official English choices so the item is usable
                q['options_fa'] = list(rec['options_en'])
                q['options_fa_source'] = 'official_en_booklet'
                q.pop('options_incomplete', None)
                n_opt += 1

        if sitting == '1402-03':
            pair1402.append({
                'question_no': no,
                'subject_fa': q.get('subject'),
                'subject_en': q.get('subject_en'),
                'stem_fa': q.get('stem_fa'),
                'stem_en': q.get('stem_en'),
                'options_fa': q.get('options_fa'),
                'options_en': q.get('options_en'),
                'en_source': q.get('en_source'),
                'year': 1402, 'month': 'خرداد', 'sitting': '1402-03',
            })
        if sitting == '1400-12' and rec:
            pair1400_out.append({
                'question_no': no,
                'subject_fa': rec.get('subject_fa') or q.get('subject'),
                'subject_en': rec.get('subject_en'),
                'stem_fa': rec.get('stem_fa') or q.get('stem_fa'),
                'stem_en': rec.get('stem_en'),
                'options_fa': rec.get('options_fa') or q.get('options_fa'),
                'options_en': rec.get('options_en'),
                'en_source': 'official_booklet',
                'year': 1400, 'month': 'اسفند', 'sitting': '1400-12',
            })

    by_subj = collections.Counter(q.get('subject') for q in arch['questions'])
    arch['totals']['by_subject'] = dict(by_subj.most_common())
    arch['totals']['questions'] = len(arch['questions'])
    arch['totals']['with_official_english'] = sum(
        1 for q in arch['questions'] if q.get('en_source') == 'official_booklet')
    arch['totals']['options_incomplete'] = sum(
        1 for q in arch['questions'] if len(q.get('options_fa') or []) != 4)
    note = arch.get('note') or ''
    extra = ('Official English attached for Esfand-1400 and Khordad-1402 '
             '(en_source: official_booklet). Khordad-1402 subjects come from '
             'the ministry English headers, not the inferred 1402-06 map.')
    if 'Khordad-1402' not in note:
        arch['note'] = (note + ' | ' + extra).strip(' |')

    json.dump(arch, io.open(ARCHIVE, 'w', encoding='utf-8'), ensure_ascii=False)
    pair1402.sort(key=lambda r: r['question_no'])
    pair1400_out.sort(key=lambda r: r['question_no'])
    json.dump(pair1402, io.open(PAIR_1402_OUT, 'w', encoding='utf-8'),
              ensure_ascii=False, indent=1)
    json.dump(pair1400_out, io.open(PAIR_1400_OUT, 'w', encoding='utf-8'),
              ensure_ascii=False, indent=1)

    print(f'term repairs on {n_term} questions')
    print(f'official EN attached: {n_en}')
    print(f'subjects overwritten from official EN: {n_subj}')
    print(f'options recovered from EN: {n_opt}')
    print(f'archive questions: {arch["totals"]["questions"]}')
    print(f'with official English: {arch["totals"]["with_official_english"]}')
    print(f'options incomplete: {arch["totals"]["options_incomplete"]}')
    print('1402-03 pair', len(pair1402), '1400-12 pair', len(pair1400_out))


if __name__ == '__main__':
    main()
