# -*- coding: utf-8 -*-
"""Parse the official key tables printed at the end of Shahrivar-1403 booklets."""
import json, io, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                '..', 'neurology-bank', 'newexams'))
from parse_key_geom import parse

HERE = os.path.dirname(os.path.abspath(__file__))
PDF = os.path.join(HERE, 'pdf', '1403-06.pdf')
OUT = os.path.join(HERE, 'keys', '1403-06.json')

# parse_key_geom: pages are 0-based. Key tables are pages 40 and 41
# (0-index 40, 41). Right half = lower numbers.
# For page 40: right starts at 1, left at 51
# For page 41: right starts at 101, left at 151
# The original script used (40, 1, 51), (41, 101, 151) on a different file
# that had a cover offset. Our hubmed file: pages 40-41 are the key (0-index).


def main():
    key = parse(PDF, [(40, 1, 51), (41, 101, 151)])
    print('parsed', len(key), '/200')
    # sanity from booklet Q1: osmotic diarrhea → magnesium laxatives = ب = 1
    # Q99 status epilepticus first IV = lorazepam = د = 3 (from neuro official)
    checks = {1: None, 99: 3, 93: 1}
    for q, want in checks.items():
        got = key.get(q)
        print(f'  q{q}: {got} (want {want})')
    payload = {
        '_meta': {
            'sitting': '1403-06',
            'title_fa': 'کلید رسمی پیش‌کارورزی با دروس شناور — شهریور ۱۴۰۳',
            'source': 'جدول پاسخنامهٔ انتهای دفترچهٔ هاب‌مد 1403-06.pdf',
            'variant': 'with_floating',
        },
        **{str(k): int(v) for k, v in sorted(key.items())},
    }
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    json.dump(payload, io.open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('->', OUT)


if __name__ == '__main__':
    main()
