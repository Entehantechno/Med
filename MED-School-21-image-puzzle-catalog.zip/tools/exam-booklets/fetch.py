# -*- coding: utf-8 -*-
"""Download one pre-internship booklet PDF and keep it under pdf/.

hubmed.ir serves the files but blocks this sandbox directly, so everything goes
through the Wayback Machine's `2id_` (identity) endpoint, which returns the
original bytes rather than a rewritten HTML page.
"""
import os, subprocess, sys, json

HERE = os.path.dirname(os.path.abspath(__file__))
PDF = os.path.join(HERE, 'pdf')
os.makedirs(PDF, exist_ok=True)

BASE = 'https://hubmed.ir/wp-content/uploads'

# tag -> (folder, url-encoded filename).  `tag` is <year>-<month>[-nf] where the
# -nf suffix marks the printing WITHOUT the floating (شناور) subjects.
SOURCES = {
 '1403-12':    ('2025/02', '%D9%BE%D8%B1%D9%87-%D8%A7%DB%8C%D9%86%D8%AA%D8%B1%D9%86%DB%8C-%D8%A7%D8%B3%D9%81%D9%86%D8%AF-%DB%B1%DB%B4%DB%B0%DB%B3.pdf'),
 '1403-06':    ('2025/02', '%D9%BE%D8%B1%D9%87_%D8%A7%DB%8C%D9%86%D8%AA%D8%B1%D9%86%DB%8C_%D8%A8%D8%A7_%D8%AF%D8%B1%D9%88%D8%B3_%D8%B4%D9%86%D8%A7%D9%88%D8%B1_%D8%B4%D9%87%D8%B1%DB%8C%D9%88%D8%B1_%DB%B1%DB%B4%DB%B0%DB%B3.pdf'),
 '1403-06-nf': ('2025/02', '%D9%BE%D8%B1%D9%87_%D8%A7%DB%8C%D9%86%D8%AA%D8%B1%D9%86%DB%8C_%D8%A8%D8%AF%D9%88%D9%86_%D8%AF%D8%B1%D9%88%D8%B3_%D8%B4%D9%86%D8%A7%D9%88%D8%B1_%D8%B4%D9%87%D8%B1%DB%8C%D9%88%D8%B1_%DB%B1%DB%B4%DB%B0%DB%B3.pdf'),
 '1403-03':    ('2024/08', '%D9%BE%D8%B1%D9%87_%D8%A7%DB%8C%D9%86%D8%AA%D8%B1%D9%86%DB%8C_%D8%A8%D8%A7_%D8%AF%D8%B1%D9%88%D8%B3_%D8%B4%D9%86%D8%A7%D9%88%D8%B1_%D8%AE%D8%B1%D8%AF%D8%A7%D8%AF_%DB%B1%DB%B4%DB%B0%DB%B3.pdf'),
 '1403-03-nf': ('2024/08', '%D9%BE%D8%B1%D9%87_%D8%A7%DB%8C%D9%86%D8%AA%D8%B1%D9%86%DB%8C_%D8%A8%D8%AF%D9%88%D9%86_%D8%AF%D8%B1%D9%88%D8%B3_%D8%B4%D9%86%D8%A7%D9%88%D8%B1_%D8%AE%D8%B1%D8%AF%D8%A7%D8%AF_%DB%B1%DB%B4%DB%B0%DB%B3.pdf'),
 '1402-12':    ('2024/04', '%D9%BE%D8%B1%D9%87_%D8%A7%DB%8C%D9%86%D8%AA%D8%B1%D9%86%DB%8C_%D8%A8%D8%A7_%D8%AF%D8%B1%D9%88%D8%B3_%D8%B4%D9%86%D8%A7%D9%88%D8%B1_%D8%A7%D8%B3%D9%81%D9%86%D8%AF_%DB%B1%DB%B4%DB%B0%DB%B2.pdf'),
 '1402-12-nf': ('2024/04', '%D9%BE%D8%B1%D9%87_%D8%A7%DB%8C%D9%86%D8%AA%D8%B1%D9%86%DB%8C_%D8%A8%D8%AF%D9%88%D9%86_%D8%AF%D8%B1%D9%88%D8%B3_%D8%B4%D9%86%D8%A7%D9%88%D8%B1_%D8%A7%D8%B3%D9%81%D9%86%D8%AF_%DB%B1%DB%B4%DB%B0%DB%B2.pdf'),
 '1402-06':    ('2024/04', '%D9%BE%D8%B1%D9%87_%D8%A7%DB%8C%D9%86%D8%AA%D8%B1%D9%86%DB%8C_%D8%A8%D8%A7_%D8%AF%D8%B1%D9%88%D8%B3_%D8%B4%D9%86%D8%A7%D9%88%D8%B1_%D8%B4%D9%87%D8%B1%DB%8C%D9%88%D8%B1_%DB%B1%DB%B4%DB%B0%DB%B2.pdf'),
 '1402-06-nf': ('2024/04', '%D9%BE%D8%B1%D9%87_%D8%A7%DB%8C%D9%86%D8%AA%D8%B1%D9%86%DB%8C_%D8%A8%D8%AF%D9%88%D9%86_%D8%AF%D8%B1%D9%88%D8%B3_%D8%B4%D9%86%D8%A7%D9%88%D8%B1_%D8%B4%D9%87%D8%B1%DB%8C%D9%88%D8%B1_%DB%B1%DB%B4%DB%B0%DB%B2.pdf'),
 '1402-03':    ('2024/04', '%D9%BE%D8%B1%D9%87_%D8%A7%DB%8C%D9%86%D8%AA%D8%B1%D9%86%DB%8C_%D8%A8%D8%A7_%D8%AF%D8%B1%D9%88%D8%B3_%D8%B4%D9%86%D8%A7%D9%88%D8%B1_%D8%AE%D8%B1%D8%AF%D8%A7%D8%AF_%DB%B1%DB%B4%DB%B0%DB%B2.pdf'),
 '1401-12':    ('2024/04', '%D9%BE%D8%B1%D9%87_%D8%A7%DB%8C%D9%86%D8%AA%D8%B1%D9%86%DB%8C_%D8%A8%D8%A7_%D8%AF%D8%B1%D9%88%D8%B3_%D8%B4%D9%86%D8%A7%D9%88%D8%B1_%D8%A7%D8%B3%D9%81%D9%86%D8%AF_%DB%B1%DB%B4%DB%B0%DB%B1.pdf'),
 '1401-12-nf': ('2024/04', '%D9%BE%D8%B1%D9%87_%D8%A7%DB%8C%D9%86%D8%AA%D8%B1%D9%86%DB%8C_%D8%A8%D8%AF%D9%88%D9%86_%D8%AF%D8%B1%D9%88%D8%B3_%D8%B4%D9%86%D8%A7%D9%88%D8%B1_%D8%A7%D8%B3%D9%81%D9%86%D8%AF_%DB%B1%DB%B4%DB%B0%DB%B1.pdf'),
 '1401-09':    ('2024/04', '%D9%BE%D8%B1%D9%87-%D8%A7%DB%8C%D9%86%D8%AA%D8%B1%D9%86%DB%8C-%D8%A2%D8%B0%D8%B1-%DB%B1%DB%B4%DB%B0%DB%B1.pdf'),
 '1401-06':    ('2024/04', '%D9%BE%D8%B1%D9%87-%D8%A7%DB%8C%D9%86%D8%AA%D8%B1%D9%86%DB%8C-%D8%B4%D9%87%D8%B1%DB%8C%D9%88%D8%B1-%DB%B1%DB%B4%DB%B0%DB%B1.pdf'),
 '1400-12':    ('2024/04', '%D9%BE%D8%B1%D9%87-%D8%A7%DB%8C%D9%86%D8%AA%D8%B1%D9%86%DB%8C-%D8%A7%D8%B3%D9%81%D9%86%D8%AF-%DB%B1%DB%B4%DB%B0%DB%B0.pdf'),
 '1400-08':    ('2024/04', '%D9%BE%D8%B1%D9%87-%D8%A7%DB%8C%D9%86%D8%AA%D8%B1%D9%86%DB%8C-%D8%A2%D8%A8%D8%A7%D9%86-%DB%B1%DB%B4%DB%B0%DB%B0.pdf'),
 '1400-06':    ('2024/04', '%D9%BE%D8%B1%D9%87-%D8%A7%DB%8C%D9%86%D8%AA%D8%B1%D9%86%DB%8C-%D8%B4%D9%87%D8%B1%DB%8C%D9%88%D8%B1-%DB%B1%DB%B4%DB%B0%DB%B0.pdf'),
 '1400-03':    ('2024/04', '%D9%BE%D8%B1%D9%87-%D8%A7%DB%8C%D9%86%D8%AA%D8%B1%D9%86%DB%8C-%D8%AE%D8%B1%D8%AF%D8%A7%D8%AF-%DB%B1%DB%B4%DB%B0%DB%B0.pdf'),
}


def fetch(tag, force=False):
    folder, name = SOURCES[tag]
    url = f'{BASE}/{folder}/{name}'
    dest = os.path.join(PDF, f'{tag}.pdf')
    if os.path.exists(dest) and os.path.getsize(dest) > 50_000 and not force:
        return dest, 'cached'
    # Wayback identity endpoint — the direct host refuses this sandbox.
    cmd = ['curl', '-sL', '--max-time', '180', '-o', dest,
           f'https://web.archive.org/web/2id_/{url}']
    subprocess.run(cmd, check=False)
    if not os.path.exists(dest) or os.path.getsize(dest) < 50_000:
        return None, 'failed'
    with open(dest, 'rb') as fh:
        if fh.read(5) != b'%PDF-':
            os.remove(dest)
            return None, 'not-a-pdf'
    return dest, 'downloaded'


if __name__ == '__main__':
    tags = sys.argv[1:] or sorted(SOURCES)
    for t in tags:
        p, how = fetch(t)
        size = f'{os.path.getsize(p)/1024/1024:.1f} MB' if p else '-'
        print(f'{t:14} {how:12} {size}')
