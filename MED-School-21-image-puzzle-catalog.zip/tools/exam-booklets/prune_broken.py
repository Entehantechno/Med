# -*- coding: utf-8 -*-
"""Drop the handful of archive entries whose Persian stem did not survive parsing.

Found by a new guard test rather than by inspection: 11 of 3226 questions
(0.34%) have an empty or non-Persian stem — a page-break or column-order case
the parser mishandled. Four of them have no options either.

A question with no stem cannot teach or test anything; leaving it in means a
student eventually opens a blank card. Since these are a fraction of a percent
and the source PDFs remain available for a future re-parse, removing them is
better than shipping them. Each removal is logged so the loss is auditable.
"""
import json, io, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
TARGETS = [
    os.path.join(HERE, 'archive.json'),
    '/home/user/project/tools/exam-booklets/archive.json',
]
FA = re.compile(r'[\u0600-\u06FF]')


def broken(q):
    """Only remove what is genuinely unusable.

    A stem with no Persian at all is a parse failure and can never be shown.
    Missing OPTIONS are a different matter: 61 archive items have a perfectly
    good question stem but lost their choices to a page break. Those still have
    value as full-text reference (which is what the archive is for), so they
    stay and are flagged instead.
    """
    stem = (q.get('stem_fa') or '').strip()
    if not FA.search(stem):
        return 'stem has no Persian'
    if len(stem) < 15:
        return 'stem too short to be a question'
    return None


def main():
    for path in TARGETS:
        if not os.path.exists(path):
            continue
        a = json.load(io.open(path, encoding='utf-8'))
        qs = a['questions']
        keep, dropped = [], []
        for q in qs:
            why = broken(q)
            if why:
                dropped.append((q.get('sitting'), q.get('no'), why))
            else:
                # keep, but mark the ones whose options did not survive so the
                # site can exclude them from anything that needs choices
                if len(q.get('options_fa') or []) != 4:
                    q['options_incomplete'] = True
                keep.append(q)
        a['questions'] = keep

        # keep the published totals honest
        import collections
        by_subj = collections.Counter(q.get('subject') for q in keep)
        a['totals']['questions'] = len(keep)
        a['totals']['by_subject'] = dict(by_subj.most_common())
        a['totals']['dropped_unparsable'] = len(dropped)
        a['totals']['options_incomplete'] = sum(
            1 for q in keep if q.get('options_incomplete'))
        a['totals']['with_official_english'] = sum(
            1 for q in keep if q.get('en_source') == 'official_booklet')

        json.dump(a, io.open(path, 'w', encoding='utf-8'), ensure_ascii=False)
        print(f'{path}: kept {len(keep)}, dropped {len(dropped)}')
        for d in dropped:
            print('   -', d)


if __name__ == '__main__':
    main()
