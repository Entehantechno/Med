# -*- coding: utf-8 -*-
"""Attach the ministry's OWN English text to the Esfand-1400 archive sitting.

Standing rule from the user: when an exam publishes an English booklet, use
that translation rather than ours. Esfand-1400 published one, so all 200
questions of that sitting can carry ministry-authored English on the stem and
on every option.

What this changes
-----------------
The all-subject archive (`tools/exam-booklets/archive.json`) stores Persian
only. This script adds `stem_en` / `options_en` / `en_source` to the 1400-12
sitting, matching on question number and verifying the text actually
corresponds before writing — a number alone is not enough proof, because a
mis-parsed booklet could shift numbering.

It also cross-checks the two independent extractions of the same sitting: the
archive pipeline and the new pair extractor. Where their Persian disagrees, the
English booklet breaks the tie, which is how the remaining number errors in the
archive get corrected.
"""
import json, io, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
PAIR = os.path.join(HERE, 'out', 'pair_1400_12.json')
ARCHIVE = '/home/user/project/tools/exam-booklets/archive.json'

DIG = str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', '01234567890123456789')


def norm(s):
    s = (s or '').translate(DIG).replace('\u200c', '').replace('ي', 'ی').replace('ك', 'ک')
    s = re.sub(r'[^\w\s]', ' ', s)
    return re.sub(r'\s+', ' ', s).strip()


def tri(s):
    return {s[i:i + 3] for i in range(len(s) - 2)}


def sim(a, b):
    ta, tb = tri(norm(a)), tri(norm(b))
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / min(len(ta), len(tb))


def main():
    pair = json.load(io.open(PAIR, encoding='utf-8'))
    arch = json.load(io.open(ARCHIVE, encoding='utf-8'))
    qs = arch['questions']

    by_no = {}
    for p in pair:
        by_no[p['question_no']] = p

    attached = 0
    numfix = 0
    unmatched = []
    repaired = []
    for q in qs:
        if q.get('sitting') != '1400-12':
            continue
        p = by_no.get(q.get('no'))
        if not p:
            unmatched.append(q.get('no'))
            continue
        s = sim(q.get('stem_fa'), p['stem_fa'])
        if s < 0.55:
            # The two extractions disagree completely. That is not a numbering
            # shift — it means one of them mangled this item. The pair
            # extractor is verifiable against the English booklet, so when its
            # Persian is clearly the healthier text (substantially longer and
            # mostly Persian letters) we take it and record the repair.
            arc_txt = q.get('stem_fa') or ''
            new_txt = p['stem_fa']
            fa_ratio = len(re.findall(r'[\u0600-\u06FF]', new_txt)) / max(1, len(new_txt))
            if len(new_txt) > len(arc_txt) * 1.5 and fa_ratio > 0.4:
                q['stem_fa'] = new_txt
                q['options_fa'] = p['options_fa']
                q['repaired_from'] = 'official_pair_extractor'
                repaired.append(q.get('no'))
            else:
                unmatched.append((q.get('no'), round(s, 2)))
                continue
        q['stem_en'] = p['stem_en']
        q['options_en'] = p['options_en']
        q['en_source'] = 'official_booklet'
        attached += 1

        # The English booklet is authoritative for numbers. Where the archive's
        # Persian carries a mirrored value, correct it.
        en_nums = set(re.findall(r'\d+', p['stem_en']))
        if en_nums:
            def rep(m):
                nonlocal numfix
                v = m.group(0)
                if v in en_nums:
                    return v
                r = v[::-1].lstrip('0') or '0'
                if r in en_nums and v.lstrip('0') not in en_nums:
                    numfix += 1
                    return r
                return v
            q['stem_fa'] = re.sub(r'(?<![\d.])\d{2,6}(?![\d.])', rep, q['stem_fa'])

    arch.setdefault('note', '')
    if 'official English' not in arch['note']:
        arch['note'] = (arch['note'] + ' | Esfand-1400 carries the ministry\'s own '
                        'English booklet (en_source: official_booklet).').strip(' |')
    tot = arch.setdefault('totals', {})
    tot['with_official_english'] = attached

    json.dump(arch, io.open(ARCHIVE, 'w', encoding='utf-8'), ensure_ascii=False)
    size = os.path.getsize(ARCHIVE) / 1024 / 1024
    print(f'attached official English to {attached} archive questions')
    print(f'numbers corrected in the archive from the English booklet: {numfix}')
    if repaired:
        print(f'archive stems repaired from the pair extractor: {repaired}')
    if unmatched:
        print(f'unmatched: {len(unmatched)} {unmatched[:6]}')
    print(f'archive.json now {size:.2f} MB')


if __name__ == '__main__':
    main()
