# -*- coding: utf-8 -*-
"""Pull one subject out of the archive, choosing the best printing per sitting.

Each exam was printed twice — with and without the floating subjects — and the
two use different question numbers. The fuller printing carries more questions
of every subject, so for bank-building we want that one; but which file is
which cannot be read off the filename reliably (they were mislabelled once
already). So we simply take, per sitting, whichever printing yields more
questions of the requested subject, and record which file that was.
"""
import json, os, sys, collections

HERE = os.path.dirname(os.path.abspath(__file__))


def pick(subject, archive=None):
    archive = archive or os.path.join(HERE, 'archive.json')
    qs = json.load(open(archive, encoding='utf-8'))['questions']
    by_file = collections.defaultdict(list)
    for q in qs:
        if q['subject'] == subject:
            by_file[q['sitting']].append(q)

    best = {}
    for tag, rows in by_file.items():
        base = tag.replace('-nf', '')
        if base not in best or len(rows) > len(best[base]):
            best[base] = sorted(rows, key=lambda r: r['no'])
    return dict(sorted(best.items()))


if __name__ == '__main__':
    subject = sys.argv[1] if len(sys.argv) > 1 else 'عفونی'
    got = pick(subject)
    total = sum(len(v) for v in got.values())
    print(f'{subject}: {total} questions across {len(got)} sittings\n')
    for base, rows in got.items():
        src = rows[0]['sitting']
        nums = f"{rows[0]['no']}–{rows[-1]['no']}"
        print(f'  {base}  ({src:11}) {len(rows):2} q   #{nums}')
