# -*- coding: utf-8 -*-
"""Final ambiguity pass on patient ages.

extract_rtl gets almost every number right by looking at what the digit run
touches. What it cannot settle is a two-digit age that is mirror-symmetric in
meaning: "خانمی 03 ساله" and "دختر 71 ساله" are both syntactically fine, yet
one of them is obviously wrong — there is no 3-year-old woman written "03" and
no 71-year-old described as "دختر" (girl).

So we finish the job with evidence the layout cannot provide: Persian itself.

  1. A leading zero is never printed in an age. "03" can only be 30.
  2. The noun that introduces the patient bounds the age:
       نوزاد/شیرخوار  -> under 2        دختر/پسر  -> under 18
       کودک           -> under 15       خانم/آقا/مرد/زن -> 14 and over
     When the printed value violates the bound and its reverse satisfies it,
     the reverse is the reading.

Everything that is plausible either way round is LEFT ALONE and flagged in
`age_uncertain`, because inventing a patient's age is worse than admitting we
could not tell.
"""
import json, os, re, glob, collections

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'out2')

# noun -> (min_age, max_age) that the word itself implies
BOUNDS = [
    (r'نوزاد|شیرخوار|نوزادی', 0, 2),
    (r'دختر\s*بچه|پسر\s*بچه|بچه', 0, 15),
    (r'کودک|طفل', 0, 15),
    # 19 rather than 18: "پسر ۱۹ ساله" is ordinary Persian, and the tighter
    # bound made the rule abstain on exactly the cases it should have decided.
    (r'دختر|پسر', 0, 19),
    (r'نوجوان', 10, 19),
    (r'سرباز|دانشجو|جوان', 17, 40),
    (r'خانم|آقا|آقای|مرد|زن|بیمار\s*خانم|بیمار\s*آقای', 14, 100),
]

# Ages above this were once treated as implausible, on the theory that "آقای 96"
# is really 69. That heuristic is now DISABLED.
#
# The ministry's Esfand-1400 sitting is published in Persian AND English, and
# the English prints ages in Latin digits, which no mirroring can touch. Its
# question 180 reads "A 91-year-old diabetic lady in ICU ...". The Persian says
# ۹۱ too. The heuristic rewrote it to 19 — inventing a 19-year-old with a
# 91-year-old's disease. Two more items were corrupted the same way.
# Nonagenarians are uncommon in vignettes but not impossible, and "uncommon" is
# not evidence about any individual question.
#
# The 90/90 agreement with the official English comes from the semantic bounds
# above, which reason from the words the question itself uses. This rule
# contributed only mismatches, so it is gone.
UNLIKELY_OVER = None
AGE = re.compile(r'(?<![\d])(\d{1,3})(\s*ساله|\s*سال\s*ه|\s*ساله\s*ای|\s*سال)')


def bounds_for(prefix):
    for pat, lo, hi in BOUNDS:
        if re.search(pat, prefix):
            return lo, hi
    return None


def fix_stem(stem):
    """Return (new_stem, n_fixed, uncertain_values)."""
    fixed, uncertain = 0, []

    def rep(m):
        nonlocal fixed
        raw, tail = m.group(1), m.group(2)
        # rule 1: a printed leading zero is impossible in an age
        if len(raw) == 2 and raw[0] == '0':
            fixed += 1
            return raw[::-1] + tail
        if len(raw) != 2:
            return m.group(0)
        val, rev = int(raw), int(raw[::-1])
        if val == rev:
            return m.group(0)                       # 22, 33 … nothing to decide
        # rule 2: the introducing noun constrains the age
        prefix = stem[max(0, m.start() - 30):m.start()]
        b = bounds_for(prefix)
        if b:
            lo, hi = b
            ok, ok_rev = lo <= val <= hi, lo <= rev <= hi
            if ok and not ok_rev:
                return m.group(0)
            if ok_rev and not ok:
                fixed += 1
                return str(rev) + tail
        if UNLIKELY_OVER is not None and val > UNLIKELY_OVER and rev <= UNLIKELY_OVER:
            fixed += 1
            return str(rev) + tail
        uncertain.append(raw)
        return m.group(0)

    return AGE.sub(rep, stem), fixed, uncertain


def run():
    tot_fixed = tot_unc = 0
    for f in sorted(glob.glob(os.path.join(OUT, '*.json'))):
        d = json.load(open(f, encoding='utf-8'))
        if not d.get('ok'):
            continue
        nf = nu = 0
        for q in d['questions']:
            q['stem_fa'], k, unc = fix_stem(q['stem_fa'])
            nf += k
            if unc:
                q['age_uncertain'] = unc
                nu += 1
        if nf or nu:
            json.dump(d, open(f, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        print(f'{d["tag"]:14} corrected {nf:3} age(s), {nu:3} left uncertain')
        tot_fixed += nf
        tot_unc += nu
    print(f'\ntotal: {tot_fixed} ages corrected, {tot_unc} flagged uncertain')


if __name__ == '__main__':
    run()
