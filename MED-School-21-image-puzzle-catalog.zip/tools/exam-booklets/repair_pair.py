# -*- coding: utf-8 -*-
"""Repair the Persian side of the Esfand-1400 pair using the English booklet.

The Persian PDF has the usual RTL export damage:
  * ages and lab numbers with their digits reversed (65 for 56, 06 for 60)
  * the lam-alef ligature written as "ال" (عالیم for علائم)
  * Latin fragments inside Persian lines reversed word-wise
    ("Stool calprotectin" -> "calprotectin Stool")

Normally each of those needs a heuristic. Here we have something far better:
the ministry's OWN English booklet for the same 200 questions. That gives an
authoritative reading for every number, so ages and lab values are corrected by
agreement rather than by guessing — and where the two disagree in a way that is
NOT a digit reversal, we leave the Persian alone and flag it, because that means
our assumption failed rather than the PDF being wrong.
"""
import json, io, os, re, sys, collections

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, 'out', 'pair_1400_12.json')

WORD = re.compile(r'[\u0600-\u06FF\u200c]+')
CLEAN_SOURCES = [
    '/home/user/work/infectious/import-payload.json',
] + [f'/home/user/project/tools/neurology-bank/import-payload.part{i:02d}.json'
     for i in range(1, 8)]


def clean_vocab():
    v = collections.Counter()
    for p in CLEAN_SOURCES:
        if not os.path.exists(p):
            continue
        for q in json.load(io.open(p, encoding='utf-8')).get('questions', []):
            blob = ' '.join([
                q.get('question_fa') or '', ' '.join(q.get('options_fa') or []),
                q.get('explanation_fa') or '',
                ' '.join((q.get('micro') or {}).get('points_fa') or []),
            ])
            for w in WORD.findall(blob):
                v[w.replace('\u200c', '')] += 1
    return v


def ligature_fixes(tokens, vocab):
    """"ال" written for "لا" — same vocabulary evidence as the book importer."""
    fixes = {}
    for tok in tokens:
        bare = tok.replace('\u200c', '')
        if 'ال' not in bare or vocab.get(bare, 0) >= 2:
            continue
        cands = {bare[:m.start()] + 'لا' + bare[m.start() + 2:]
                 for m in re.finditer('ال', bare)}
        cands.add(bare.replace('ال', 'لا'))
        best, score = None, 0
        for c in cands:
            if vocab.get(c, 0) > score:
                best, score = c, vocab[c]
        if best and score >= 2:
            fixes[tok] = best
    return fixes


def unreverse_latin_runs(s):
    """"calprotectin Stool" -> "Stool calprotectin".

    Only flips runs of 2+ Latin words that carry no Persian between them; a
    single Latin word cannot be word-order damaged.
    """
    def rep(m):
        words = m.group(0).split()
        return ' '.join(reversed(words)) if len(words) > 1 else m.group(0)
    return re.sub(r'(?:[A-Za-z][A-Za-z0-9./\'-]*)(?:\s+[A-Za-z][A-Za-z0-9./\'-]*)+', rep, s)


def fix_numbers(fa, en):
    """Correct reversed digit runs in the Persian using the English as truth.

    For each number in the Persian stem, if its reversal appears in the English
    and it does not itself appear there, the Persian copy is mirrored: swap it.
    Conservative by construction — no English evidence, no change.
    """
    en_nums = set(re.findall(r'\d+', en))
    if not en_nums:
        return fa, 0
    fixed = 0

    def rep(m):
        nonlocal fixed
        v = m.group(0)
        if v in en_nums:
            return v
        r = v[::-1].lstrip('0') or '0'
        if r in en_nums and v.lstrip('0') not in en_nums:
            fixed += 1
            return r
        return v

    fa = re.sub(r'(?<![\d.])\d{2,6}(?![\d.])', rep, fa)

    # A leading zero in an age is impossible ("05 ساله"), so it is a mirrored
    # number even when the English booklet phrased that sentence differently
    # and gave us nothing to compare against.
    def age(m):
        nonlocal fixed
        fixed += 1
        return m.group(1) + '0 '

    fa = re.sub(r'(?<![\d.])0(\d)\s*(?=ساله)', age, fa)
    return fa, fixed


def main():
    rows = json.load(io.open(SRC, encoding='utf-8'))
    vocab = clean_vocab()

    toks = collections.Counter()
    for r in rows:
        for f in [r['stem_fa']] + r['options_fa']:
            for w in WORD.findall(f):
                toks[w] += 1
    lig = ligature_fixes(toks, vocab)
    print(f'clean vocabulary: {len(vocab)}   ligature repairs: {len(lig)}')
    for k, v in sorted(lig.items(), key=lambda x: -toks[x[0]])[:10]:
        print(f'   {k} -> {v}  (x{toks[k]})')

    def apply_words(s):
        return WORD.sub(lambda m: lig.get(m.group(0), m.group(0)), s)

    n_num = 0
    for r in rows:
        r['stem_fa'] = apply_words(r['stem_fa'])
        r['options_fa'] = [apply_words(o) for o in r['options_fa']]
        r['stem_fa'], k = fix_numbers(r['stem_fa'], r['stem_en'])
        n_num += k
        # Latin option bodies are word-reversed on the Persian side; the English
        # booklet already has them correct, so only tidy the Persian copy.
        r['options_fa'] = [unreverse_latin_runs(o) for o in r['options_fa']]
        r['stem_fa'] = re.sub(r'\s{2,}', ' ', r['stem_fa']).strip()

    json.dump(rows, io.open(SRC, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(f'numbers corrected from the English booklet: {n_num}')

    # verify
    bad = []
    for r in rows:
        fa = re.findall(r'(\d{1,3})\s*ساله', r['stem_fa'])
        en = re.findall(r'(\d{1,3})[\s-]*year', r['stem_en'])
        if fa and en and fa[0] != en[0]:
            bad.append((r['question_no'], fa[0], en[0]))
    print(f'ages still disagreeing with the English booklet: {len(bad)} {bad[:5]}')
    blob = ' '.join(r['stem_fa'] + ' '.join(r['options_fa']) for r in rows)
    for w in ('عالیم', 'مبتال', 'سواالت', 'اختالل'):
        print(f'  residual {w}: {blob.count(w)}')


if __name__ == '__main__':
    main()
