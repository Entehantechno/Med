# -*- coding: utf-8 -*-
"""Fill in subject labels for the booklets that printed none.

Three sittings were exported through a university exam-report system that
dropped the subject headings. Their question ORDER is still the standard
national layout, so we borrow the subject ranges from a sibling booklet of the
same shape — same question count and same printing variant (with/without the
floating subjects) — and mark every borrowed label `subject_inferred: true` so
it is never mistaken for something the booklet actually printed.
"""
import json, os, glob, sys

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "out2")

# unlabelled tag -> reference tag of the same shape
PAIRS = {
    '1400-03':    '1400-06',      # both are 200-q "with floating" prints
    # 1402-03 must NOT borrow 1402-06: the ministry English booklet of
    # that sitting has a different block order (neuro at 97-102, not mid-obgyn).
    # polish_archive.py overlays the official headers instead.
    '1403-03':    '1403-06',
    '1403-03-nf': '1403-06-nf',
}


def ranges_of(ref):
    out, cur = [], None
    for q in ref['questions']:
        if not cur or q['subject'] != cur['s']:
            if cur:
                out.append(cur)
            cur = {'s': q['subject'], 'a': q['no'], 'b': q['no']}
        else:
            cur['b'] = q['no']
    if cur:
        out.append(cur)
    return out


def run():
    for tag, ref_tag in PAIRS.items():
        p, rp = os.path.join(OUT, f'{tag}.json'), os.path.join(OUT, f'{ref_tag}.json')
        if not (os.path.exists(p) and os.path.exists(rp)):
            print(f'{tag:14} skip (missing file)')
            continue
        d, ref = json.load(open(p, encoding='utf-8')), json.load(open(rp, encoding='utf-8'))
        if not d.get('ok') or not ref.get('ok'):
            print(f'{tag:14} skip (unparsed)')
            continue
        if abs(d["count"] - ref["count"]) > 10:
            print(f'{tag:14} skip (shape mismatch {d["count"]} vs {ref["count"]})')
            continue
        by_no = {}
        for r in ranges_of(ref):
            for n in range(r['a'], r['b'] + 1):
                by_no[n] = r['s']
        filled = 0
        for q in d['questions']:
            if not q.get('subject') and by_no.get(q['no']):
                q['subject'] = by_no[q['no']]
                q['subject_inferred'] = True
                filled += 1
        d['subject_source'] = f'inferred from {ref_tag}'
        json.dump(d, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        inf = sum(1 for q in d['questions'] if q['subject'] == 'عفونی')
        print(f'{tag:14} filled {filled:3} labels from {ref_tag}  (infectious={inf})')


if __name__ == '__main__':
    run()
