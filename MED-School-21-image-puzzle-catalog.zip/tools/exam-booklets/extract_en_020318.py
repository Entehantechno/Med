# -*- coding: utf-8 -*-
"""Parse the official English booklet of Khordad-1402 (exam code 020318).

Quirks of this electronic paper:
  * no a)/b)/c)/d) markers — last four lines of each item are the options
  * some options LOOK like question numbers (\"2-3\", \"4-11\") so a new item
    is started only when the number is strictly greater than the last one
  * subject headers are standalone lines; a few blocks (surgery, ophthalmology,
    epidemiology) have no printed English header and are filled from the
    official block order of this sitting
"""
import io, json, os, re
import pdfplumber

HERE = os.path.dirname(os.path.abspath(__file__))
EN_PDF = '/home/user/uploads/136207551soalat pishkarvarzi  4.pdf'
OUT = os.path.join(HERE, 'out', 'en_1402_03.json')

EN_Q = re.compile(r'^(\d{1,3})-\s*(.*)$')
SKIP = re.compile(
    r'^(آزمون|Page\s*\d+|Comprehensive|In the Name of God|'
    r'The Secretariat|Ministry of Health|مدت آزمون)',
    re.I,
)
# Exact (or prefix) headers printed in THIS booklet.
HEADERS = {
    'internal medicine': ('داخلی', 'Internal Medicine', 'major'),
    'pediatric': ('کودکان', 'Pediatrics', 'major'),
    'pediatrics': ('کودکان', 'Pediatrics', 'major'),
    'obstetrics and gynecology': ('زنان و زایمان', 'Obstetrics and Gynecology', 'major'),
    'neurology': ('مغز و اعصاب', 'Neurology', 'minor'),
    'infectious': ('عفونی', 'Infectious Diseases', 'minor'),
    'infectious diseases': ('عفونی', 'Infectious Diseases', 'minor'),
    'radiology': ('رادیولوژی', 'Radiology', 'minor'),
    'psychiatry': ('روانپزشکی', 'Psychiatry', 'minor'),
    'dermatology': ('پوست', 'Dermatology', 'minor'),
    'bone and joint surgery': ('ارتوپدی', 'Orthopedics', 'minor'),
    'urology': ('اورولوژی', 'Urology', 'minor'),
    'otorhinolaryngology (ear, nose & throat)': ('گوش و حلق و بینی', 'ENT', 'minor'),
    'pharmacology': ('فارماکولوژی', 'Pharmacology', 'minor'),
    'medical ethics': ('اخلاق پزشکی', 'Medical Ethics', 'minor'),
    'pathology': ('پاتولوژی', 'Pathology', 'minor'),
    'medical genetics': ('ژنتیک پزشکی', 'Medical Genetics', 'minor'),
    'medical physics': ('فیزیک پزشکی', 'Medical Physics', 'minor'),
    'immunology': ('ایمونولوژی', 'Immunology', 'minor'),
    'nutrition science': ('تغذیه', 'Nutrition', 'minor'),
}

# Blocks that have no English header in this paper, keyed by first question.
IMPLIED = {
    43: ('جراحی', 'Surgery', 'major'),
    139: ('چشم‌پزشکی', 'Ophthalmology', 'minor'),
    151: ('آمار و اپیدمیولوژی', 'Statistics & Epidemiology', 'minor'),
}

TRAILER = re.compile(
    r'(آزمون:?\s*پیش|مدت آزمون|_EN_020318|روﺎﻨﺷﺎﺑ)',
    re.I,
)


def tidy(s):
    s = re.sub(r'\s+', ' ', s or '').strip()
    s = TRAILER.split(s)[0].strip()
    return s.strip(' :.-')


def header_of(ln):
    # Printed headers in this booklet never end with a period. A line like
    # "infectious diseases." is a wrapped sentence, not a subject banner.
    raw = ln.strip()
    if raw.endswith('.'):
        return None
    k = raw.lower()
    if k in HEADERS:
        return HEADERS[k]
    for key, val in HEADERS.items():
        if k == key or k.startswith(key + ' '):
            return val
    return None


def lines():
    out = []
    with pdfplumber.open(EN_PDF) as pdf:
        for p in pdf.pages:
            for ln in (p.extract_text() or '').split('\n'):
                s = re.sub(r'\s+', ' ', ln).strip()
                if not s or SKIP.match(s) or TRAILER.search(s):
                    continue
                out.append(s)
    return out


def parse(ls):
    qs, cur, subject = {}, None, HEADERS['internal medicine']
    last_no = 0
    for ln in ls:
        h = header_of(ln)
        if h and not EN_Q.match(ln):
            subject = h
            continue
        mq = EN_Q.match(ln)
        if mq:
            no = int(mq.group(1))
            # options like "2-3" / "4-11" must not open a new item
            if last_no < no <= 200 and (cur is None or no == last_no + 1 or no > last_no):
                # only accept monotonic (allow small gaps)
                if no <= last_no:
                    if cur is not None:
                        cur['opts'].append(ln)
                    continue
                if no in IMPLIED:
                    subject = IMPLIED[no]
                cur = {'no': no, 'stem': [mq.group(2).strip()], 'opts': [],
                       'subject': subject}
                qs[no] = cur
                last_no = no
                continue
        if cur is None:
            continue
        cur['opts'].append(ln)
    for cur in qs.values():
        body = [x for x in cur['opts'] if x.strip()]
        if len(body) >= 4:
            cur['stem_extra'] = body[:-4]
            cur['opts'] = body[-4:]
        else:
            cur['stem_extra'] = []
            cur['opts'] = body
    return qs


def main():
    qs = parse(lines())
    rows, bad = [], []
    for no in range(1, 201):
        q = qs.get(no)
        if not q:
            bad.append((no, 'missing'))
            continue
        opts = [tidy(x) for x in q['opts']]
        if len(opts) != 4 or not all(opts):
            bad.append((no, f'opts={len(opts)} {opts}'))
        fa, en, track = q['subject']
        stem = tidy(' '.join([q['stem'][0]] + (q.get('stem_extra') or [])))
        rows.append({
            'question_no': no,
            'subject_fa': fa, 'subject_en': en, 'subject_track': track,
            'stem_en': stem,
            'options_en': (opts + [''] * 4)[:4],
            'en_source': 'official_booklet',
            'year': 1402, 'year_fa': '۱۴۰۲',
            'month': 'خرداد', 'month_en': 'Khordad',
            'date': '1402/03/18', 'sitting': '1402-03',
        })
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    json.dump(rows, io.open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    from collections import Counter
    print(f'parsed {len(rows)}  bad {len(bad)} {bad[:8]}')
    print('subjects:', Counter(r['subject_fa'] for r in rows))
    prev = None
    for r in rows:
        if r['subject_fa'] != prev:
            print(f"  q{r['question_no']:3} {r['subject_fa']} / {r['subject_en']}")
            prev = r['subject_fa']
    print('->', OUT)


if __name__ == '__main__':
    main()
