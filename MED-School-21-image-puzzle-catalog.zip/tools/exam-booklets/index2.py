# -*- coding: utf-8 -*-
"""Merge every parsed booklet into one all-subjects index.

This is the file every future subject starts from. Instead of re-downloading a
booklet and re-solving the same four Persian-PDF traps, a new subject pipeline
just filters `archive.json` by `subject` and writes its lessons.
"""
import json, os, glob, collections

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'out2')

MONTH_FA = {'03': 'خرداد', '06': 'شهریور', '08': 'آبان', '09': 'آذر', '12': 'اسفند'}


def build():
    sittings, all_q = [], []
    for f in sorted(glob.glob(os.path.join(OUT, '*.json'))):
        d = json.load(open(f, encoding='utf-8'))
        if not d.get('ok'):
            sittings.append({'tag': d['tag'], 'ok': False, 'reason': d.get('reason')})
            continue
        tag = d['tag']
        base = tag.replace('-nf', '')
        year, month = base.split('-')
        variant = 'no_floating' if tag.endswith('-nf') else 'with_floating'
        counts = collections.Counter(q['subject'] or '?' for q in d['questions'])
        sittings.append({
            'tag': tag, 'ok': True, 'year': f'1{year[1:]}' if False else year,
            'month': MONTH_FA.get(month, month), 'month_num': month,
            'variant': variant, 'count': d['count'],
            'subject_source': d.get('subject_source', 'printed headings'),
            'subjects': dict(sorted(counts.items(), key=lambda x: -x[1])),
        })
        for q in d['questions']:
            all_q.append({**q, 'sitting': tag, 'year': year,
                          'month': MONTH_FA.get(month, month), 'variant': variant})

    by_subject = collections.Counter(q['subject'] or '?' for q in all_q)
    doc = {
        'generated_for': 'MED School — pre-internship all-subjects question archive',
        'note': ('Text extracted from the official ministry booklets. Question '
                 'numbering comes from order of appearance, cross-checked against '
                 'the printed number read in both directions, because these PDFs '
                 'emit Persian digits reversed.'),
        'sittings': sittings,
        'totals': {'sittings_ok': sum(1 for s in sittings if s['ok']),
                   'questions': len(all_q),
                   'by_subject': dict(by_subject.most_common())},
        'questions': all_q,
    }
    dest = os.path.join(HERE, 'archive.json')
    json.dump(doc, open(dest, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    mb = os.path.getsize(dest) / 1024 / 1024
    print(f'sittings parsed : {doc["totals"]["sittings_ok"]}')
    print(f'questions       : {doc["totals"]["questions"]}')
    print(f'archive         : {dest} ({mb:.1f} MB)')
    print('\nby subject:')
    for k, v in by_subject.most_common():
        print(f'  {v:5}  {k}')


if __name__ == '__main__':
    build()
