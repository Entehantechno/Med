# -*- coding: utf-8 -*-
"""Fold Arabic presentation forms back to ordinary Persian letters.

Several booklets extract as Unicode presentation forms (U+FE70–U+FEFF): the
same letter appears as four different codepoints depending on how it joined in
the original typesetting. The text LOOKS right but is unsearchable — a query
for «سل» will not match «ﺳﻞ» — and it breaks the dedupe fingerprint. NFKC
normalisation collapses all four shapes back to the base letter.

We also fix the two Arabic letters that Persian spells differently (ي→ی, ك→ک)
and drop the zero-width marks the exporters sprinkle in, so the same word from
two different booklets compares equal.
"""
import json, glob, os, re, unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'out2')

AR_FOLD = str.maketrans({'ي': 'ی', 'ك': 'ک', 'ﻻ': 'لا', 'ة': 'ه',
                         '\u200e': '', '\u200f': '', '\ufeff': ''})
# Arabic-Indic digits survive NFKC, so fold them explicitly — otherwise «٥٦»
# and «56» are different strings and every dedupe/lookup silently misses.
DIGITS = str.maketrans('٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹', '01234567890123456789')
WS = re.compile(r'[ \t\u00a0]+')

POST_FIXES = [
    ('زبر', 'زیر'), ('اسمبر', 'اسمیر'), ('تویرکلوز', 'توبرکلوز'),
    ('تویرکولین', 'توبرکولین'), ('متایولیک', 'متابولیک'), ('جین اکسیرت', 'جین اکسپرت'),
    ('ییﻦ', 'بین'), ('یین ', 'بین '), ('ایتدا', 'ابتدا'), ('یررسی', 'بررسی'),
    ('یرای', 'برای'), ('یهترین', 'بهترین'), ('یاشد', 'باشد'), ('یدون', 'بدون'),
    ('یالا', 'بالا'), ('یعد', 'بعد'), ('یار ', 'بار '), ('یاردار', 'باردار'),
    ('یستری', 'بستری'), ('ییمار', 'بیمار'), ('ییماری', 'بیماری'),
    # the 1402-12 export also swapped ل->ه inside a few very common words
    ('عهت', 'علت'), ('مراوعه', 'مراجعه'), ('سواله', 'ساله'), ('عهایم', 'علایم'),
    ('عهامت', 'علامت'), ('حمهات', 'حملات'), ('سوال', 'سوال'), ('وهت', 'جهت'),
    ('تزریهی', 'تزریقی'), ('سابهه', 'سابقه'), ('پروفیهاکوی', 'پروفیلاکسی'),
    # the 1403-12 export dropped ل entirely inside some words and mangled others
    ('سا های', 'ساله‌ای'), ('سوا ه', 'ساله'), ('سا ه', 'ساله'),
    ('عیوهنی', 'عضلانی'), ('سوردرد', 'سردرد'), ('سوا', 'سا'),
    ('شودید', 'شدید'), ('شوکایت', 'شکایت'), ('پارسوتزی', 'پارستزی'),
    ('اسوت', 'است'), ('صوب ', 'صبح '), ('تشو', 'تشن'), ('سومت', 'سمت'),
    ('راسوت', 'راست'), ('مراجعه اسوت', 'مراجعه است'), ('ضوعف', 'ضعف'),
    ('پزشوکی', 'پزشکی'), ('پرسود', 'پرسد'), ('ب ندتر', 'بلندتر'),
]


# Trap #4: inside the running text the digits of a multi-digit number are
# emitted in visual (right-to-left) order, so "خانم06 ساله" is really a
# 60-year-old and "از 0 روز قبل" lost a digit entirely. We can only repair the
# cases that are unambiguous, and we do it conservatively:
#
#   * a 2-digit run glued to a Persian word and followed by « ساله» is an age.
#     When it starts with 0 ("خانم06 ساله") the reading is unambiguous, because
#     a leading zero is never printed: it must be 60.
#   * When it does NOT start with 0 ("آقای52 ساله") BOTH readings are legal —
#     25 and 52 are equally plausible ages — so we leave it alone and flag it.
#     Callers building a question bank must read those few against the PDF.
#
# Anything else (lab values, doses, durations) is left exactly as extracted:
# silently "fixing" a creatinine or a drug dose would be far worse than leaving
# a reversed one that a reviewer can spot against the PDF.
AGE = re.compile(r'(?<=[\u0600-\u06FF])(\d{2})(?=\s*ساله)')


def fix_ages(s):
    def rep(m):
        d = m.group(1)
        return d[::-1] if d.startswith('0') else d
    return AGE.sub(rep, s)


def word_fixes(s):
    for a, b in POST_FIXES:
        s = s.replace(a, b)
    return s


def norm(s):
    if not s:
        return s
    s = unicodedata.normalize('NFKC', s)   # presentation forms -> base letters
    s = s.translate(AR_FOLD).translate(DIGITS)
    s = word_fixes(s)
    s = fix_ages(s)
    return WS.sub(' ', s).strip()


AMBIG_AGE = re.compile(r'(?<=[\u0600-\u06FF])(\d{2})(?=\s*ساله)')


def run():
    touched = ambiguous = 0
    for f in sorted(glob.glob(os.path.join(OUT, '*.json'))):
        d = json.load(open(f, encoding='utf-8'))
        if not d.get('ok'):
            continue
        changed = False
        for q in d['questions']:
            a, b = q['stem_fa'], [o for o in q['options_fa']]
            q['stem_fa'] = norm(a)
            q['options_fa'] = [norm(o) for o in b]
            if q['stem_fa'] != a or q['options_fa'] != b:
                changed = True
        for q in d['questions']:
            # flag the ages we deliberately did not touch, so a reviewer can
            # find them instead of trusting a possibly-reversed number
            hits = [m.group(1) for m in AMBIG_AGE.finditer(q['stem_fa'])
                    if not m.group(1).startswith('0')]
            if hits:
                q['age_reading_ambiguous'] = hits
                ambiguous += 1
                changed = True
        if changed:
            json.dump(d, open(f, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
            touched += 1
    print(f'normalised {touched} booklet file(s); '
          f'{ambiguous} question(s) carry an ambiguous age to verify')


if __name__ == '__main__':
    run()
