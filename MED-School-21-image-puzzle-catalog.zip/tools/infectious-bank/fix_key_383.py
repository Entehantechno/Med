# -*- coding: utf-8 -*-
"""Correct book q9383 — same tetanus-table error as q9382.

A construction worker with a deep soil wound who received tetanus vaccine
12 years ago. The book gives Td + TIG. Harrison Table 304-1 and CDC: with a
prior series (≥3 doses implied by 'received the vaccine 12 years ago' as a
last-dose statement) TIG is never indicated. Twelve years exceeds the 5-year
dirty-wound booster threshold, so Td alone is due.
"""
import json, io, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
TARGET_NO = 9383

FA = ('کلید چاپی «واکسن Td به همراه ایمونوگلوبولین» است، ولی جدول ۳۰۴-۱ هریسون و CDC '
      'می‌گویند با سابقه‌ی سری قبلی، TIG در هیچ زخمی اندیکاسیون ندارد. ۱۲ سال فقط '
      'آستانه‌ی ۵ساله‌ی زخم کثیف را رد کرده، پس یک Td یادآور لازم است — نه TIG. '
      'این همان تصحیح سؤال ۹۳۸۲ همین فصل است.')
EN = ("The printed key is 'Td plus immunoglobulin', but Harrison Table 304-1 and CDC "
      "state that with a prior series TIG is not indicated for any wound. Twelve years "
      "only crosses the 5-year dirty-wound booster threshold, so one Td is due — not TIG. "
      "This is the same correction as question 9382 of this chapter.")
SRC = ("Harrison's Principles of Internal Medicine, 21st ed (2022), Table 304-1; "
       "CDC — Clinical Guidance for Wound Management to Prevent Tetanus (ACIP)")


def main():
    for i in range(1, 6):
        p = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        if not os.path.exists(p):
            continue
        body = json.load(io.open(p, encoding='utf-8'))
        changed = False
        for q in body['questions']:
            if q.get('question_no') != TARGET_NO:
                continue
            idx = None
            for j, o in enumerate(q['options_fa']):
                t = re.sub(r'\s+', '', o)
                if 'Td' in o and 'ایمونوگلوبولین' not in t and 'تتابولین' not in t:
                    if idx is not None:
                        sys.exit('ambiguous Td-only option')
                    idx = j
            if idx is None:
                sys.exit('could not find Td-only option')
            if q.get('key_corrected') and q['correct_index'] == idx:
                print('already corrected')
                return
            q['original_correct_index'] = q['correct_index']
            q['correct_index'] = idx
            q['key_corrected'] = True
            q['key_correction_fa'] = FA
            q['key_correction_en'] = EN
            q['key_correction_source'] = SRC
            changed = True
            print(f'q{TARGET_NO}: {q["original_correct_index"]} -> {idx}')
        if changed:
            json.dump(body, io.open(p, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)


if __name__ == '__main__':
    main()
