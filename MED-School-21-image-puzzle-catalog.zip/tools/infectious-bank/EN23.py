# -*- coding: utf-8 -*-
"""English stems and options for batches 58–59 (remaining endocarditis and UTI).

Rule 16 checked first: these book items have no ministry English booklet, so
the translations are authored. Multi-digit numbers are carried through so
apply_en's digit guard will pass.
"""

EN23 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    assert all(o.strip() for o in options), idx
    EN23[idx] = {"stem_en": stem, "options_en": options}


# =========================================================== endocarditis
add(101,
    "A young man who injects drugs presents with fever and breathlessness for the past two weeks. "
    "Examination: T 39 C, RR 30, PR 120, BP 120/80, diffuse pulmonary crackles, Osler nodes on the "
    "fingers and linear haemorrhages in the nail beds. Blood culture is positive. What is the most "
    "likely diagnosis?",
    ["Endocarditis", "Brucellosis", "Typhoid fever", "Pulmonary tuberculosis"])

add(102,
    "A 24-year-old injecting drug user presents with cough, sputum and sudden breathlessness. He is "
    "febrile. Diffuse crackles are heard in the lungs. There is a maculopapular rash on the skin and "
    "ecchymotic lesions on the feet. The spleen is enlarged. Cardiac auscultation is normal. Which "
    "diagnosis is most likely?",
    ["Infective endocarditis", "Pneumonia", "Septicaemia", "None of the above"])

add(104,
    "An injecting drug user presents with fever of 38 C for one week and breathlessness for two days. "
    "A single blood culture has grown Staphylococcus epidermidis sensitive to vancomycin. What is the "
    "most appropriate next step?",
    ["Repeat the blood culture and perform echocardiography",
     "Intravenous vancomycin with a diagnosis of sepsis",
     "Intravenous vancomycin and echocardiography",
     "CT of the lungs and treatment for embolism"])

add(105,
    "A young injecting drug user presents with high fever, breathlessness, haemorrhagic lesions of "
    "the palms and soles, and conjunctival petechiae for several days. The urine contains white and "
    "red cells. Which investigation has priority for a definitive diagnosis?",
    ["Blood culture plus echocardiography",
     "CT pulmonary angiography plus arterial blood gas analysis",
     "CT of the lungs",
     "Urine culture plus ultrasound of the kidneys and urinary tract"])

add(107,
    "A patient has had fever of 39 C, intracranial haemorrhage, respiratory distress and palmo-plantar "
    "skin lesions for several days. Several successive daily blood cultures are positive and the "
    "rheumatoid factor is positive. Despite appropriate antibiotics the fever and other symptoms are "
    "still present after 4 days. Given the most likely diagnosis, which of the following has the "
    "greatest diagnostic value?",
    ["A peripheral blood film", "Echocardiography", "A lung scan", "Wright serology"])

add(108,
    "A 65-year-old man presents with fever, rigors, sweating, anorexia and weight loss for the past "
    "month. His temperature is about 38 C. Conjunctival petechiae and erythematous lesions of the "
    "soles are seen. Which of the following takes priority in diagnosing the disease?",
    ["Chest radiograph", "Peripheral blood smear", "Complete blood count", "Echocardiography"])

add(114,
    "Which of the following is a MAJOR clinical criterion for the diagnosis of infective endocarditis?",
    ["Fever of 38 C or higher",
     "Septic pulmonary emboli",
     "Osler nodes on the fingers",
     "New valvular regurgitation on echocardiography"])

add(115,
    "Which of the following findings, if it occurs in a patient with fever and rigors, counts as a "
    "MAJOR criterion for infective endocarditis?",
    ["One of three blood cultures taken one hour apart becoming positive",
     "A white-cell count above 14000 or below 4000",
     "New valvular regurgitation that was not previously present",
     "The presence of a prosthetic heart valve"])

add(116,
    "A 28-year-old injecting drug user is brought to the emergency department with high fever and "
    "breathlessness. He is alert but tachycardic, and his respiratory rate is 32 per minute. Last "
    "year he was admitted with infective endocarditis. Examination shows a petechia on the right "
    "palpebral conjunctiva and ecchymotic lesions of the palms and soles. The chest film shows "
    "scattered pip-like infiltrates in both lungs. Suspecting recurrent endocarditis, how many Duke "
    "criteria do you count for him?",
    ["1 major and 2 minors", "5 minor criteria", "1 major and 4 minors", "2 minor criteria"])

add(117,
    "A 24-year-old man with a history of injecting psychoactive drugs is brought to the emergency "
    "department with high fevers and a reduced conscious level (drowsiness). He has not taken "
    "antibiotics in this illness. He is admitted and given broad-spectrum antibiotics and supportive "
    "care. After 48 hours, without an antipyretic, the fever has gone and he is improving, and the "
    "symptoms do not return during the admission. All of the following diagnoses are possible EXCEPT",
    ["Typhoid fever", "Endocarditis", "Septicaemia", "Meningitis"])

add(118,
    "An 18-year-old man with a history of a VSD presents with fever of 39 C and a disturbed conscious "
    "level. Examination shows a grade 4/6 murmur and painless palmo-plantar skin lesions. Tests "
    "report leucocytosis and a positive rheumatoid factor. One blood culture has isolated "
    "Staphylococcus aureus. Vital signs: pulse / BP 80, HR 120, BT 39. Given the most likely "
    "diagnosis, what do you recommend?",
    ["Echocardiography",
     "Send further blood-culture samples",
     "CT of the brain",
     "Start treatment for endocarditis"])

add(125,
    "A young woman with haemoptysis is to undergo rigid bronchoscopy. She had treated infective "
    "endocarditis about 2 years ago. What is the correct advice about the need for, and the method "
    "of, endocarditis prevention?",
    ["Recommend 1 g of oral amoxicillin beforehand",
     "Recommend oral clindamycin in two doses, before and after",
     "Recommend ampicillin and gentamicin during the bronchoscopy",
     "The patient does not need prevention"])

add(130,
    "A 10-year-old boy who had VSD surgery 3 months ago, incompletely repaired, is to undergo "
    "drainage of a dental abscess. He reports immediate hypersensitivity to penicillin. Which of the "
    "following is appropriate for endocarditis prophylaxis?",
    ["Clindamycin", "Vancomycin", "Cephalexin", "He does not need prophylaxis"])

add(131,
    "A 30-year-old woman with a prosthetic heart valve is to undergo gingival surgery. For antibiotic "
    "prophylaxis, given that she has immediate hypersensitivity to penicillin, which option do you "
    "suggest?",
    ["Cephalexin", "Ciprofloxacin", "Clindamycin", "She does not need prophylaxis"])

# =========================================================== UTI
add(499,
    "A 70-year-old man in hospital develops fever and a painful swollen epididymis four days after "
    "a Foley catheter was placed. The urine shows 20 to 22 white cells per HPF. What is the most "
    "likely cause?",
    ["Candida", "Group B streptococcus", "Staphylococcus epidermidis", "Klebsiella"])

add(501,
    "A 65-year-old man with a CVA has had an indwelling urinary catheter for about three weeks "
    "because of incontinence. Routine tests show pyuria (WBC 20–30) and a urine culture of E. coli "
    "105 CFU/ml, with a normal CBC. He is not febrile and reports no particular problem. What is "
    "the appropriate action?",
    ["Change the catheter and send another urine culture",
     "Long-term prophylaxis with co-trimoxazole",
     "Treat for one week with ciprofloxacin",
     "No action is needed"])

add(502,
    "A 50-year-old man with a spinal cord injury for three years and a long-term urinary catheter "
    "attends. His urine culture has grown E. coli with a colony count greater than 10000, and the "
    "urine microscopy reports WBC 1–2, RBC 0–1 and plentiful bacteria. He has no clinical features "
    "of a urinary tract infection. What action do you consider appropriate?",
    ["Repeat the urine culture and, if still positive, give ciprofloxacin for 7 days",
     "Give ciprofloxacin for 10 days and then long-term prophylaxis",
     "Give ciprofloxacin for 14 days and then repeat the urine culture",
     "No specific action is needed"])

add(504,
    "A 60-year-old woman presents with two positive urine cultures of Klebsiella pneumoniae at a "
    "count of 105. She has no dysuria or frequency and the physical examination is normal. Ultrasound "
    "of the kidneys and bladder is reported normal. Which treatment do you recommend?",
    ["Trimethoprim-sulfamethoxazole", "Nitrofurantoin", "Ciprofloxacin", "She does not need treatment"])

add(510,
    "A 40-year-old woman's urine culture has grown more than one hundred thousand colonies of "
    "Escherichia coli on two occasions. She has no symptoms at all. In which of the following "
    "circumstances does this person need treatment?",
    ["Bladder biopsy", "A kidney stone", "Biliary cirrhosis", "Diabetes mellitus"])

add(511,
    "A young woman with no underlying disease, married for a few months and not pregnant, presents "
    "with dysuria and frequency. She has no fever, and the only positive finding on examination is "
    "suprapubic tenderness. What is the most appropriate step for this patient?",
    ["Prescribe an oral antibiotic",
     "Ultrasound of the kidneys and urinary tract",
     "Request blood cultures and a urine culture",
     "Prescribe an anti-inflammatory drug"])

add(512,
    "A 30-year-old non-pregnant woman with no underlying disease presents with dysuria, frequency "
    "and urgency and no history of high-risk sexual behaviour. She has no fever and no flank "
    "tenderness. She reports no previous urinary tract infection. What is the preferred step?",
    ["An antibiotic", "Ultrasound", "A urine culture", "A blood culture"])

add(514,
    "A 24-year-old woman presents with dysuria, frequency and fever for the past 2 days. The external "
    "genital examination is normal. She has pyuria. No other cause for the fever has been found. Her "
    "other vital signs are stable. She reports no similar previous episode. Which of the following "
    "antibiotic regimens is NOT appropriate as empiric treatment?",
    ["Co-trimoxazole", "Nitrofurantoin", "Ciprofloxacin", "Ampicillin-sulbactam"])

add(515,
    "A 25-year-old married woman presents with dysuria and frequency for the past three days. She is "
    "not febrile and has no nausea or vomiting. She has no previous similar episode and no underlying "
    "heart disease. She is not pregnant. Which diagnostic-therapeutic approach do you consider "
    "appropriate?",
    ["Perform urine analysis and culture and decide on that basis",
     "Prescribe ciprofloxacin for three days",
     "Prescribe co-trimoxazole for ten days",
     "Prescribe nitrofurantoin for 5 to 7 days"])

add(516,
    "A young woman presents with dysuria and frequency since yesterday. She has no fever, nausea, "
    "vomiting or flank pain. She is not pregnant and has no known underlying disease or anatomical "
    "problem of the urinary tract. You have decided to treat her for a urinary tract infection. "
    "Which of the following drugs is associated with the least collateral damage to the gastrointestinal "
    "flora and the lowest risk of antibiotic-associated diarrhoea?",
    ["Nitrofurantoin", "Ciprofloxacin", "Co-trimoxazole", "Ampicillin"])

add(518,
    "A woman 3 months pregnant has a positive urine culture for E. coli on routine testing. She has "
    "no clinical symptoms and no fever. What is the appropriate treatment?",
    ["She does not need drug treatment",
     "Oral co-trimoxazole",
     "Injectable gentamicin",
     "Oral nitrofurantoin"])

add(519,
    "A pregnant woman at 30 weeks presents with symptoms of cystitis. The urine has pyuria. The "
    "culture has grown E. coli sensitive to nitrofurantoin, ciprofloxacin, cefixime and gentamicin. "
    "Which drug is the best choice for this patient?",
    ["Nitrofurantoin", "Ciprofloxacin", "Cefixime", "Gentamicin"])

add(520,
    "A 60-year-old man with bladder cancer undergoes cystoscopy and catheterisation so that a bladder "
    "biopsy can be taken. He then develops a urinary tract infection that does not respond to the "
    "usual treatments (a third-generation cephalosporin, an aminoglycoside alone, a quinolone). Which "
    "regimen is better to try?",
    ["Co-trimoxazole",
     "Ticarcillin / tazobactam",
     "Ampicillin plus gentamicin",
     "All of the above"])

add(521,
    "In all of the following diseases treatment is a single dose of antibiotic EXCEPT",
    ["Gonococcal urethritis", "Streptococcal pharyngitis", "Primary syphilis", "Cystitis"])

add(522,
    "A 54-year-old man was admitted with chronic bacterial prostatitis and received standard treatment. "
    "He returns two months after finishing treatment and is again diagnosed with chronic bacterial "
    "prostatitis. What is the appropriate action?",
    ["Use two oral antibiotics for 4 weeks",
     "Increase the dose of the antibiotic used previously",
     "Combine an oral with an injectable antibiotic for 14 days",
     "Extend the duration of treatment to 12 weeks"])

add(523,
    "A 62-year-old diabetic woman presents with T 39.3 C. Laboratory investigation shows WBC 25000 "
    "and the urine is packed with white cells. After 72 hours of ceftriaxone she is still febrile. "
    "A radiograph shows gas in the parenchyma of the kidneys. What is the diagnosis?",
    ["Papillary necrosis",
     "Antibiotic resistance",
     "Perinephric abscess",
     "Emphysematous pyelonephritis"])

add(524,
    "A patient presents with dysuria and frequency. Which of the following findings most suggests "
    "progression to pyelonephritis?",
    ["Darkening of the urine", "Urinary urgency", "Suprapubic pain", "Fever"])

add(526,
    "A woman 38 weeks pregnant presents with right flank pain and fever. Ultrasound reports obstruction "
    "of the ureter and swelling of the right pyelocalyceal system. What is the treatment of choice?",
    ["Intravenous co-trimoxazole",
     "Intravenous gentamicin",
     "Intravenous ceftriaxone plus gentamicin",
     "Intravenous nitrofurantoin"])

add(527,
    "A 25-year-old woman at 30 weeks of pregnancy presents to the emergency department with shaking "
    "rigors and dysuria since last night. Examination shows pain in the back and the right flank. "
    "At the time of examination BT is 38.6 and PR is 85, and the urine analysis reports many WBC. "
    "What is the appropriate treatment?",
    ["Intravenous ceftriaxone plus intravenous vancomycin",
     "Oral nitrofurantoin plus intravenous amikacin",
     "Intravenous ampicillin plus intravenous gentamicin",
     "Intravenous vancomycin alone is enough"])
