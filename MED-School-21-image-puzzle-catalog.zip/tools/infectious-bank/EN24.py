# -*- coding: utf-8 -*-
"""English stems for batch 60 (remaining sepsis / febrile-patient items)."""

EN24 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    EN24[idx] = {"stem_en": stem, "options_en": options}


add(1,
    "A 38-year-old woman attends with a fever pattern of 3 to 10 days of fever followed by 3 to 10 "
    "days without fever (a repeating pattern). She is admitted to the infectious-diseases ward and "
    "investigation reports splenomegaly and a high LDH. Which of the following diseases does this "
    "clinical picture match?",
    ["Hodgkin lymphoma", "Familial Mediterranean fever", "Relapsing fever", "Falciparum malaria"])

add(3,
    "An 8-year-old child presents with fever of 39 C, a maculopapular rash and scattered vesicles. "
    "There is also a history of a seizure. In addition to treating the underlying disease, you would "
    "give all of the following drugs to lower the fever EXCEPT",
    ["Ibuprofen", "Diclofenac", "Aspirin", "Paracetamol"])

add(4,
    "A 10-year-old child presents with fever of 39 C, myalgia, cough and sore throat that began "
    "suddenly yesterday afternoon. Given the most likely diagnosis, all of the following drugs are "
    "used in treatment EXCEPT",
    ["Paracetamol", "Dextromethorphan", "Aspirin", "Ibuprofen"])

add(6,
    "In the definition of FUO (fever of unknown origin), which of the following is NOT an obligatory "
    "initial step for that definition?",
    ["Performing blood cultures", "ESR", "ANA", "CT of the abdomen and pelvis"])

add(7,
    "A 35-year-old man presents with fever for the past 4 weeks and no underlying disease. The fever "
    "has been documented on two occasions. Clinical examination finds no pathological finding. Which "
    "of the following investigations has priority over the others?",
    ["Echocardiography", "CT of the chest", "Upper endoscopy", "Ultrasound of the abdomen and pelvis"])

add(711,
    "A young woman presents with vaginal discharge and itch. Examination shows a white, thick, "
    "sticky, curd-like cottage-cheese discharge. All of the following can predispose to this problem "
    "EXCEPT",
    ["Previous antibiotic use", "Previous antipsychotic use", "Diabetes mellitus", "HIV/AIDS"])

add(712,
    "A 30-year-old woman presents with cottage-cheese discharge and vaginal itch. She has a severe "
    "allergy to the azole family of drugs. Which of the following treatments is appropriate?",
    ["Nystatin", "Flucytosine", "Micafungin", "Amphotericin B"])

add(713,
    "A patient with leukaemia is admitted with candida oesophagitis. She has a severe allergy to the "
    "azole family. What is the most appropriate treatment?",
    ["Nystatin", "Flucytosine", "Nitazoxanide", "Caspofungin"])

add(714,
    "A young woman presents with painless sticky white patches in the mouth, especially on the tongue, "
    "extending to the pharynx. She reports no known disease. Staining with 10% KOH shows hyphae and "
    "pseudohyphae. What is the appropriate next step?",
    ["Request blood cultures", "Request a blood glucose", "Request an HIV test", "Perform endoscopy"])

add(715,
    "A 30-year-old man has had pain in the throat on swallowing for about 4 days. He injects drugs. "
    "He looks well and his vital signs are normal. Examination of the pharynx shows white lesions that "
    "come off easily with a tongue depressor, and the mucosa beneath is only mildly erythematous. What "
    "treatment should be given and which test most helps to diagnose his underlying disease?",
    ["Oral fluconazole and HIV antibodies in the blood",
     "Oral penicillin and a CBC",
     "Oral aciclovir and HSV type-1 antibody in the blood",
     "Oral metronidazole and a Gram stain and culture of the pharyngeal lesions"])

add(716,
    "A 70-year-old man who has a urinary catheter for BPH is about to undergo a urologic operation. "
    "His urine culture has grown Candida albicans. He has no clinical symptoms at all. What is the "
    "most appropriate step?",
    ["He does not need treatment",
     "Bladder irrigation with amphotericin",
     "Treat the patient after the operation",
     "Start treatment with oral fluconazole"])

add(717,
    "A 67-year-old woman is in ICU with a large diabetic foot ulcer and fasciitis. A Foley catheter "
    "has been placed and the urine culture has grown Candida albicans. She is not febrile and has no "
    "urinary symptoms. Which of the following do you do for her?",
    ["Start amphotericin B", "Start fluconazole", "Start caspofungin",
     "Remove the Foley catheter and repeat the urine culture"])

add(718,
    "A 35-year-old patient with a previous cavitary tuberculosis attends with a dry cough, fatigue "
    "and haemoptysis. A local wheeze is heard. Chest CT reports a fungus ball suspected to be an "
    "aspergilloma. What is the most likely species?",
    ["A. fumigatus", "A. niger", "A. flavus", "A. nidulans"])

add(719,
    "Fever, sweats, productive cough and weight loss together with destruction of lung tissue and "
    "formation of multiple pulmonary cavities are features of which form of aspergillosis?",
    ["Chronic pulmonary aspergillosis", "Aspergilloma",
     "Allergic bronchopulmonary aspergillosis", "Invasive pulmonary aspergillosis"])

add(720,
    "A 50-year-old patient with COPD has had weight loss, fever, sweats and a productive cough for "
    "the past 2 months. The chest radiograph shows diffuse infiltration with formation of multiple "
    "cavities. Tuberculosis is excluded. Which fungus can be involved in these symptoms?",
    ["Aspergillus", "Candida", "Cryptococcus", "Mucormycosis"])

add(721,
    "A patient with lupus on prolonged corticosteroid treatment at above-physiologic doses presents "
    "with cough, sputum and weight loss for about 2 to 3 months. Chest CT shows cavitary lesions in "
    "both lungs, especially on the right, and bronchoscopy and biopsy show septate branching mould "
    "filaments under the microscope. Which option is correct?",
    ["Candida infection", "Aspergillus infection", "Mucormycosis", "Sporotrichosis"])

add(722,
    "A 50-year-old man undergoes a right lung lobectomy after a road accident. One year after the "
    "operation he develops fever, weight loss, chest pain, anorexia and cough lasting more than 3 "
    "months. Smear and culture of sputum are negative for bacteria and for BK. CXR and chest CT show "
    "multiple cavitary lesions at the operative site with irregular walls and ball-like masses inside "
    "some cavities. Bronchoscopy is performed and samples are again negative for bacteria and BK. "
    "Which diagnosis is most likely?",
    ["Pulmonary tuberculosis", "Nocardia infection", "Aspergillus infection", "Pneumococcal infection"])

add(723,
    "A 24-year-old man with AML presents after several courses of chemotherapy with fever, neutropenia "
    "and cough. Chest CT shows multiple nodules in both lungs. The serum galactomannan test is positive "
    "and the sputum shows thin septate fungal hyphae. What is the treatment of choice?",
    ["Voriconazole", "Fluconazole", "Amphotericin B", "Posaconazole"])

add(724,
    "In severe immunodeficiency with disseminated aspergillosis, which organ is most often involved?",
    ["The brain", "The skin", "Bone", "The liver"])

add(725,
    "A patient presents with breathlessness and a chronic cough. He reports passing casts and dark "
    "brown sputum. Tests show eosinophilia and an IgE of 1351. Which of the following diagnostic "
    "methods is more appropriate for finding the cause?",
    ["Aspergillus fumigatus skin-prick test", "PFT (spirometry)",
     "High-resolution CT of the lung (HRCT)", "Sputum smear and culture"])

add(726,
    "A kidney-transplant recipient presents with fever and pain in the right maxillary sinus and is "
    "treated for sinusitis. Despite treatment the disease progresses and he develops diplopia and "
    "bloody nasal discharge. Examination shows unilateral chemosis and proptosis together with "
    "necrosis of the palate. What is the most likely diagnosis?",
    ["Aspergillus", "Mucormycosis", "Cavernous-sinus thrombosis", "Pseudomonas aeruginosa"])

add(829,
    "A 60-year-old man is brought to the emergency department with fever and a reduced conscious "
    "level. Examination: RR 20/min, BP 80/60 mmHg, PR 120/min, axillary temperature 38 C. The urine "
    "has pyuria and bacteriuria. One hour after intravenous normal saline his blood pressure reaches "
    "100/90 mmHg. Which diagnosis does his clinical state match?",
    ["Systemic inflammatory response syndrome", "Sepsis", "Severe sepsis", "Septic shock"])

add(836,
    "A 70-year-old patient is brought to the emergency department with fever, a reduced conscious "
    "level and oliguria. The initial diagnosis is severe sepsis with no identified source. Which of "
    "the following is the preferred initial empiric treatment?",
    ["Vancomycin plus gentamicin plus cefepime",
     "Cefazolin plus gentamicin",
     "Piperacillin/tazobactam plus gentamicin",
     "None of the above"])

add(837,
    "A 70-year-old man is brought to the emergency department with a reduced conscious level, fever "
    "of 39 C, a respiratory rate of 30 per minute and a blood pressure of 80/40. Empiric antibiotics "
    "are started for suspected septic shock. Which regimen do you choose?",
    ["Ampicillin plus ceftriaxone plus metronidazole",
     "Ampicillin plus ceftriaxone plus gentamicin plus vancomycin",
     "Ampicillin plus piperacillin/tazobactam plus gentamicin plus vancomycin",
     "Ampicillin plus piperacillin/tazobactam plus gentamicin"])

add(838,
    "A 57-year-old woman presents with weakness and malaise since yesterday. She looks ill and toxic. "
    "Vital signs: PR 100/min, temperature 38.5, BP 80, RR 82. History and the initial examination "
    "identify no source of infection. Fluids and laboratory investigation have been started. Which "
    "antibiotic regimen is recommended?",
    ["Cefazolin plus gentamicin", "Imipenem plus vancomycin",
     "Cloxacillin plus ciprofloxacin", "Ciprofloxacin plus amikacin"])

add(839,
    "A 38-year-old man presents with fever and rigors. Examination: RR 32/min, T 39.8 C, BP 85/50 mmHg. "
    "An abdominal surgical scar is seen; the family say the operation was for ITP (idiopathic "
    "thrombocytopenic purpura). Given his background and symptoms, which antibiotic do you prescribe?",
    ["Cefotaxime plus vancomycin", "Meropenem plus amikacin",
     "Tazocin plus clindamycin", "Ciprofloxacin plus imipenem"])

add(840,
    "A 25-year-old man is brought to the emergency department with fever, tachycardia, tachypnoea and "
    "a blood pressure of 85/60 mmHg. The fever began yesterday and there is no history of respiratory, "
    "gastrointestinal or urinary symptoms. No source of infection or fever is found on the present "
    "examination. He had a splenectomy one year ago. What is the preferred treatment until blood and "
    "urine culture results are ready?",
    ["Ciprofloxacin plus clindamycin", "Vancomycin plus gentamicin",
     "Ceftriaxone plus vancomycin", "Metronidazole plus penicillin"])

add(841,
    "Which of the following are complications of septic shock?",
    ["Adrenal insufficiency", "Acute tubular necrosis of the kidneys",
     "Suppression of the immune system", "All of the above"])

add(842,
    "You review a young man. He was admitted 2 weeks ago with fever and drowsiness. His vital signs "
    "on admission were blood pressure 58, pulse 120 and temperature 39 C. Six months ago he had a "
    "splenectomy after trauma and intra-abdominal bleeding. He has now fully recovered and you plan "
    "to discharge him. You recommend vaccination against all of the following pathogens EXCEPT",
    ["Streptococcus pneumoniae", "Salmonella Typhi", "Haemophilus influenzae", "Neisseria meningitidis"])

add(843,
    "A soldier who was recently splenectomised is admitted with fever, myalgia, pink lesions of the "
    "trunk, limbs and conjunctiva, hypotension and oliguria. The lesions were first maculopapular and "
    "blanched on pressure but later became haemorrhagic. Tests show metabolic acidosis and a raised "
    "PT. Which of the following microorganisms is LEAST likely in the diagnosis?",
    ["Neisseria meningitidis", "Staphylococcus epidermidis",
     "Streptococcus pneumoniae", "Haemophilus influenzae"])

add(845,
    "A 67-year-old woman developed fever and a reduced conscious level last night after three days of "
    "dysuria and frequency. Examination: T 39 C, PR 100/min, BP 85/45 mmHg, RR 30/min. An arterial "
    "blood gas is requested. Which report is most likely?",
    ["pH 7.25, PCO2 50", "pH 7.5, PCO2 28", "pH 7.48, HCO3 30", "pH 7.23, HCO3 13"])
