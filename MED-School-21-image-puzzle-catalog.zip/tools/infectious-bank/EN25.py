# -*- coding: utf-8 -*-
"""English stems for batch 61 (remaining toxin-mediated items)."""

EN25 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    EN25[idx] = {"stem_en": stem, "options_en": options}


add(356,
    "An 81-year-old man is brought to the emergency department because of stiffness and pain in the "
    "jaw and facial muscles together with difficulty swallowing for the past 3 days. Initially he has "
    "no fever, and there is rigidity of the abdominal muscles. What is the most likely diagnosis?",
    ["Tetanus", "Encephalitis", "Hypercalcaemia", "A retropharyngeal abscess"])

add(357,
    "A 62-year-old farmer presents with severe painful spasm of the upper limbs and locking of the "
    "teeth. He is not febrile. RR is 18 and he has a 3×3 cm wound on the shin. Which method do you "
    "use as the best diagnostic method for this patient?",
    ["Isolating bacterial spores from the wound",
     "Measuring the serum antitoxin level",
     "Diagnosis based on the clinical findings",
     "Biopsy and sending muscle enzymes"])

add(359,
    "A 50-year-old patient presents to the emergency department with trismus, dysphagia, neck "
    "stiffness and severe muscle pain. He reports a crash and an open wound of the shin 7 days ago. "
    "During the examination he develops spasm of the abdominal and limb muscles, and there is scant "
    "discharge at the wound. Which of the following is more helpful for diagnosing this disease?",
    ["Culture of the wound discharge",
     "The clinical findings and the history of the crash",
     "Analysis of the cerebrospinal fluid",
     "Looking for toxin in the serum"])

add(360,
    "In a 25-year-old who completed his primary tetanus vaccination but later did not receive booster "
    "doses, what do you recommend?",
    ["Whenever he attends he should receive only one dose of Td",
     "He should receive two doses of Tdap at least four weeks apart",
     "He should again receive three doses of Tdap in the usual way",
     "He should receive one dose of Td only when dirty wounds occur"])

add(362,
    "In a pregnant woman in the fourth month of pregnancy with a history of incomplete vaccination, "
    "which of the following do you recommend to prevent neonatal tetanus?",
    ["Td vaccine to the mother after delivery",
     "One dose of Td",
     "Tetanus immunoglobulin to the newborn after delivery",
     "Two doses of Td 4 weeks apart"])

add(363,
    "A 24-year-old pregnant woman who does not know her vaccination history attends. Her mother says "
    "she never received vaccine. Which of the following is correct for preventing neonatal tetanus?",
    ["One dose of TT to the mother",
     "Two doses of TT 4 weeks apart to the mother",
     "Three doses of TT 4 weeks apart to the mother",
     "The national newborn vaccination programme is enough for prevention"])

add(365,
    "In a war-refugee camp an 18-year-old woman in her first pregnancy with no vaccination history "
    "attends the clinic. What do you advise her about tetanus vaccination?",
    ["Two doses of toxoid 4 weeks apart",
     "One dose of toxoid now and one dose of TIG at delivery",
     "3 doses of DTP two months apart",
     "After delivery her vaccination should be done together with her child's"])

add(369,
    "A 13-year-old boy from Afghanistan with an unknown vaccination history presents because a nail "
    "went into the sole of his foot while he was playing. After first aid, which of the following is "
    "recommended to prevent tetanus?",
    ["Tetanus vaccination, one dose",
     "TIG and tetanus vaccination",
     "TIG, two doses",
     "Tetanus vaccination in two doses one month apart"])

add(370,
    "A 27-year-old woman in the ninth month of pregnancy has a nail enter the sole of her foot. She "
    "received complete prenatal care and was given tetanus vaccine in the seventh month of pregnancy. "
    "What is the best step to prevent tetanus in this patient?",
    ["Give one dose of Td",
     "Give one dose of TIG",
     "Give one dose of vaccine plus TIG",
     "No specific action is needed"])

add(372,
    "A 5-year-old child sustains a deep hand wound while playing in the garden. Given that his infant "
    "vaccination history is complete, which of the following do you consider correct for tetanus "
    "prevention?",
    ["He does not need a preventive intervention",
     "Repeat one booster dose",
     "Give one dose of TIG",
     "Give TIG and a tetanus booster together"])

add(374,
    "A climber has developed extensive frostbite of the fingers. His primary vaccination series is "
    "complete and he received a tetanus booster 4 years ago. He is referred to you for advice. What "
    "is the most correct step?",
    ["He should receive one dose of tetanus vaccine",
     "No specific action is needed to prevent tetanus",
     "An injection of one dose of TIG is essential",
     "He should receive one dose of vaccine and one dose of TIG"])

add(375,
    "A 45-year-old man presents to the emergency department with a gradual onset of difficulty "
    "swallowing and an inability to open his mouth. He reports a skin wound after falling from a "
    "horse about 10 days ago. Vital signs are normal and apart from an impaired gag reflex the rest "
    "of the neurological examination is normal. After cutaneous stimulation he develops spasm of the "
    "head and neck. What is the most appropriate step?",
    ["Perform a brain CT, blood cultures and start antibiotics",
     "Start broad-spectrum antibiotics and investigate cranial and spinal sources",
     "Admit to a general ward, smear and culture the foot wound and start antitoxin and antibiotic",
     "Admit to intensive care and start antitoxin"])

add(376,
    "A young man has a tibial fracture after a motorcycle crash and is admitted to the emergency "
    "department. 24 hours after admission he develops severe pain at the trauma site and 4 hours "
    "after that severe swelling of the area, a fall in blood pressure and fever. A stained smear of "
    "the wound discharge shows Gram-positive bacilli. What action do you consider appropriate?",
    ["Give meropenem and vancomycin — clinical follow-up",
     "Emergency surgical debridement — give metronidazole",
     "Emergency surgical debridement — give vancomycin",
     "Give ceftriaxone and clindamycin — operate if there is no clinical response"])

add(379,
    "A 25-year-old man is admitted with a diagnosis of tetanus. Which option is true about immunising "
    "him against tetanus?",
    ["Having tetanus gives lifelong immunity and he does not need vaccination",
     "After recovery one dose of tetanus vaccine is given",
     "Tetanus vaccination is given in two doses",
     "A complete course of tetanus vaccination is given"])

add(380,
    "A 40-year-old woman attends because a drawing-pin went into her foot at home. She does not know "
    "when she last received tetanus vaccine. Which option do you choose to prevent tetanus?",
    ["Tetanus vaccine and immunoglobulin",
     "Vaccine alone",
     "Tetanus immunoglobulin",
     "No action is needed"])

add(381,
    "A 30-year-old soldier who received his last tetanus vaccine dose 15 years ago sustains a wound "
    "contaminated with soil in an operational area. What is the correct step to prevent tetanus?",
    ["Give one dose of Td and TIG together",
     "Give one dose of TIG into the wound",
     "Give one dose of Td and ten days of intravenous penicillin",
     "Give two doses of Td and one dose of intravenous metronidazole"])

add(383,
    "A young construction worker presents with a deep wound of the foot contaminated with soil. He "
    "received tetanus vaccine 12 years ago. What do you suggest?",
    ["Give Td vaccine",
     "Give Td vaccine together with one dose of tetanus immunoglobulin",
     "Give tetanus immunoglobulin",
     "No preventive action is needed"])

add(384,
    "A 26-year-old man presents with a dog bite of the right forearm. What measures do you recommend?",
    ["Wash with povidone-iodine + adult tetanus vaccine + rabies vaccine and RIG",
     "Wash with soap and water + rabies vaccine and RIG",
     "Wash with soap and water + adult tetanus vaccine + rabies vaccine and RIG",
     "Wash with povidone + rabies vaccine and RIG"])

add(386,
    "A 13-year-old girl has had weakness, malaise, sore throat and a low fever for 6 days. She saw a "
    "doctor but did not improve, and since yesterday her speech has been nasal and fluids come out of "
    "her nose when she swallows. Examination shows a swollen neck and a grey exudate on the tonsil, "
    "uvula and pharynx. A direct smear shows club-shaped Gram-positive bacilli. What is the appropriate "
    "treatment?",
    ["Symptomatic treatment + intravenous immunoglobulin",
     "Antibiotic + corticosteroid",
     "Symptomatic treatment + corticosteroid",
     "Antibiotic + antitoxin"])

add(387,
    "For which of the following diseases do you recommend respiratory isolation?",
    ["Pulmonary anthrax", "Pertussis", "Tuberculous meningitis", "Mumps"])

add(388,
    "A 15-year-old boy presents with repeated paroxysmal coughs and pertussis is suspected. To prevent "
    "transmission, for how long after starting azithromycin does the patient need isolation?",
    ["2 days", "5 days", "2 weeks", "3 weeks"])

add(389,
    "A newborn is in the NICU with a diagnosis of neonatal tetanus because of inability to feed and "
    "muscle spasm. The presence of which of the following would make you expect a better prognosis?",
    ["The presence of fever",
     "An incubation period of less than 6 days",
     "A high birth weight",
     "Birth of the infant before term"])

add(390,
    "A 65-year-old man is brought to the emergency department with inability to speak or swallow and "
    "diffuse limb stiffness beginning 2 days ago. He has no fever. He is fully alert. But on "
    "examination the mouth opens with difficulty and there is severe rigidity on flexing the neck and "
    "the limbs. He is a retired man whose only activity has been gardening at home. He has no memory "
    "of ever receiving any vaccine and takes no drugs. Given the most likely diagnosis, which of the "
    "following complications do you consider expected?",
    ["A fall in the conscious level", "Respiratory failure",
     "Limb paralysis", "Skin eruptions"])

add(391,
    "A pregnant housewife presents with a sudden onset of double vision and sore throat together with "
    "weakness. Examination shows bilateral drooping of the eyelids and a dry mouth; her temperature "
    "is normal and she is fully alert. What is your first diagnosis?",
    ["Botulism", "Tetanus", "A brain abscess", "Guillain–Barré syndrome"])

add(392,
    "A young man develops gastrointestinal symptoms 48 hours after eating canned fish, then symmetric "
    "cranial-nerve palsies that descend to involve the legs. He also complains of double vision and "
    "ptosis. He is alert. He has no fever and no neck stiffness. The spinal fluid is normal. Which of "
    "the following is most likely?",
    ["Viral encephalitis", "Bacillus cereus infection",
     "Tick paralysis", "Botulism"])

add(393,
    "A 35-year-old man presents with nausea, vomiting and abdominal pain followed by diplopia, "
    "dysarthria, dysphonia and dysphagia. He is alert, T is 36.2, and examination shows ptosis and "
    "palsy of several cranial nerves. During the admission he develops respiratory failure and is "
    "intubated. Which finding may be observed in this patient?",
    ["Ascending paralysis",
     "Normal deep tendon reflexes",
     "A sensory disturbance",
     "Pleocytosis and a raised CSF protein"])

add(394,
    "A 20-year-old man is admitted one day after eating canned food with abdominal pain, dizziness, "
    "dysphagia and dysarthria. Which of the following symptoms and signs is against a diagnosis of "
    "botulism?",
    ["A normal gag reflex",
     "Having a fever above 38 C",
     "The presence of a progressive descending paralysis",
     "Normal deep tendon reflexes"])

add(395,
    "All of the following findings are seen in botulism EXCEPT",
    ["Bilateral descending paralysis", "Fever", "Diplopia", "Dysarthria"])

add(396,
    "The presence of which of the following clinical findings makes a diagnosis of botulism unlikely?",
    ["Cranial-nerve palsies",
     "Respiratory distress and use of the accessory muscles of respiration",
     "Descending paralysis and reduced tendon reflexes",
     "Mydriasis and a reduced pupillary reflex"])

add(397,
    "A person attends the clinic with weakness and malaise after eating canned food. Normality of "
    "which of the following findings is against a diagnosis of botulism?",
    ["The deep tendon reflexes",
     "Full alertness",
     "The cranial-nerve examination",
     "The temperature"])

add(398,
    "A 35-year-old man presents 24 hours after eating home-canned food with nausea and vomiting and "
    "then progressive double vision and difficulty speaking and swallowing. Examination shows dry "
    "oral mucosa and he has urinary retention. Which of the following methods helps to reach a "
    "definitive aetiological diagnosis?",
    ["Toxicological testing of a sample of the suspected food",
     "Culture of the suspected food",
     "Culture of clinical samples (blood, urine, stool)",
     "Looking for antigen in a cerebrospinal-fluid sample"])

add(399,
    "A 24-year-old male worker is brought to the emergency department this evening. He is alert but "
    "answers questions with difficulty. He says that 3 days ago he ate canned beans and that on the "
    "same day his foot was wounded by an unknown dog. He complains of nausea and several vomits, "
    "severe weakness of the head and neck, dysphagia, double vision and dysphonia; he has no fever "
    "and his mouth is dry. His tendon reflexes are normal. Given the history and the most likely "
    "diagnosis, which treatment do you prefer?",
    ["Give rabies vaccine plus rabies immunoglobulin and trivalent botulinum antitoxin and observe",
     "Give rabies vaccine as the first dose and send the patient to ICU",
     "Give rabies vaccine and immunoglobulin and send the patient to ICU",
     "Give trivalent botulinum antitoxin and send the patient to ICU for intubation"])

add(400,
    "A 25-year-old young man who lives in a student dormitory presents with weakness of the upper "
    "limbs and blurred vision. On examination he is not febrile, the pupils do not respond properly "
    "to light and the gag reflex is impaired. Given the most likely diagnosis, what do you recommend?",
    ["Antitoxin + metronidazole",
     "Antitoxin + gentamicin",
     "Antitoxin + dexamethasone",
     "Antitoxin + respiratory support"])

add(401,
    "A 25-year-old man presents 18 hours after eating canned fish with double vision, blurred vision, "
    "a dry mouth and weakness of the upper limbs. Examination shows ptosis and an impaired swallow "
    "reflex. All of the following are recommended in this patient EXCEPT",
    ["Admit the patient to the ICU",
     "Give antitoxin",
     "Give gentamicin",
     "Examine a sample of the food he ate"])
