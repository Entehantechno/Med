# -*- coding: utf-8 -*-
"""Correct two printed keys in the urinary tract infection chapter.

Both were caught while writing the batch-9 lessons, and both are corrected the
same way every other key correction in this bank has been: the original index
is preserved, a bilingual justification and a citation are attached, and the
lesson opens by telling the student the printed key was changed.

--------------------------------------------------------------------------
idx 500 — asymptomatic diabetic woman, pre-employment urinalysis
--------------------------------------------------------------------------
The stem states the patient "has no symptoms". Despite a positive culture,
heavy pyuria and a positive nitrite, that makes this asymptomatic bacteriuria,
not urinary tract infection. The book answers "start antibiotics".

IDSA's 2019 asymptomatic bacteriuria guideline recommends AGAINST screening or
treating patients with diabetes — a STRONG recommendation on moderate-quality
evidence, because trials show treatment does not reduce symptomatic infection
or pyelonephritis in this group. The guideline also states explicitly that
pyuria is not an indication to treat.

Diabetes makes asymptomatic bacteriuria more COMMON (up to 27% of diabetic
women); it does not make it worth treating. Correct answer: no action needed.

--------------------------------------------------------------------------
idx 525 — myasthenia gravis with suspected pyelonephritis, which to avoid?
--------------------------------------------------------------------------
The book answers "co-trimoxazole". Every myasthenia source says the opposite:

  * The FDA has carried a BOXED WARNING on fluoroquinolones since 2011 for
    exacerbation of myasthenia gravis — its strongest warning class.
  * The Myasthenia Gravis Foundation of America cautionary drug list places
    sulfa drugs, including trimethoprim/sulfamethoxazole, among the "good
    alternatives" with no or rare reports of exacerbation.
  * Narayanaswami et al. (J Clin Med 2021;10:1537), reviewing drugs that worsen
    myasthenia, state: "MG exacerbation has not been reported after the use of
    cephalosporins, sulfa drugs (including trimethoprim/sulfamethoxazole), and
    clindamycin."

So cefixime, ampicillin and co-trimoxazole are all usable, and the drug that
must be excluded is ciprofloxacin. This is the most clinically dangerous of the
corrections so far: a student who memorises the printed key would infer that
ciprofloxacin is the safe choice, which is the exact inverse of the truth.

Options are matched by TEXT rather than by a fixed index, so a reordering of
the payload can never silently point a correction at the wrong answer.
"""
import json, io, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))

CORRECTIONS = {
    9500: {
        # the option meaning "no specific action is needed"
        'match': lambda t: 'نیاز' in t and 'اقدام' in t,
        'fa': ('صورت سؤال صریح می‌گوید بیمار «علامتی ندارد»، پس تشخیص باکتریوری بدون علامت است '
               'نه عفونت ادراری. راهنمای IDSA سال ۲۰۱۹ با توصیه‌ی قوی و شواهد با کیفیت متوسط '
               'می‌گوید بیماران دیابتی را برای باکتریوری بدون علامت نه غربالگری و نه درمان کنید، '
               'چون کارآزمایی‌ها نشان داده‌اند درمان خطر عفونت علامت‌دار و پیلونفریت را کم نمی‌کند. '
               'همین راهنما تصریح می‌کند که پیوری در فرد بدون علامت اندیکاسیون درمان نیست.'),
        'en': ("The stem states the patient 'has no symptoms', so this is asymptomatic bacteriuria, "
               "not urinary tract infection. The 2019 IDSA guideline gives a strong recommendation on "
               "moderate-quality evidence against screening or treating patients with diabetes, because "
               "trials show treatment does not reduce symptomatic infection or pyelonephritis. The same "
               "guideline states explicitly that pyuria is not an indication to treat."),
        'src': ('IDSA Clinical Practice Guideline for the Management of Asymptomatic Bacteriuria (2019); '
                "Harrison's Principles of Internal Medicine, 21st ed (2022), Ch. 130"),
    },
    9514: {
        # febrile UTI = pyelonephritis; nitrofurantoin has no tissue level
        'match': lambda t: 'نیتروفورانتوئین' in t or 'نیتروفورانتویین' in t,
        'fa': ('کلید چاپی «سیپروفلوکساسین» است، ولی صورت سؤال تب دو روزه بدون منبع دیگر دارد، '
               'پس تشخیص پیلونفریت است نه سیستیت. نیتروفورانتوئین فقط در ادرار غلیظ می‌شود و '
               'سطح بافتی و خونی کافی برای پارانشیم کلیه ندارد؛ بنابراین داروی نامناسب همین است. '
               'سیپروفلوکساسین ۷روزه رژیم IDSA برای پیلونفریت سرپایی است و نباید حذف شود.'),
        'en': ("The printed key is 'ciprofloxacin', but the stem gives two days of fever with no "
               "other source, so this is pyelonephritis, not cystitis. Nitrofurantoin only "
               "concentrates in urine and has no adequate tissue or serum level for the renal "
               "parenchyma; that is therefore the inappropriate drug. Seven days of ciprofloxacin "
               "is the IDSA outpatient regimen for pyelonephritis and must not be excluded."),
        'src': ("IDSA guideline on uncomplicated cystitis and pyelonephritis (2011); "
                "Harrison's Principles of Internal Medicine, 21st ed (2022), Ch. 130"),
    },
    9525: {
        'match': lambda t: 'سیپروفلوکساسین' in t,
        'fa': ('کلید چاپی «کوتریموکسازول» است، ولی منابع میاستنی گراو خلاف آن را می‌گویند. '
               'سازمان غذا و داروی آمریکا از سال ۲۰۱۱ برای فلوروکینولون‌ها هشدار جعبه‌سیاه درباره‌ی '
               'تشدید میاستنی گراو گذاشته است — بالاترین سطح هشدار. در مقابل، فهرست داروهای احتیاطی '
               'MGFA و مرور Narayanaswami و همکاران (J Clin Med 2021;10:1537) سولفونامیدها از جمله '
               'کوتریموکسازول را در دسته‌ی جایگزین‌های بی‌خطر قرار می‌دهند و می‌نویسند با سفالوسپورین‌ها، '
               'سولفاها و کلیندامایسین تشدید میاستنی گزارش نشده است. پس دارویی که باید حذف شود '
               'سیپروفلوکساسین است، نه کوتریموکسازول.'),
        'en': ("The printed key is 'co-trimoxazole', but the myasthenia literature says the opposite. "
               "Since 2011 the FDA has carried a boxed warning on fluoroquinolones for exacerbation of "
               "myasthenia gravis, its strongest warning class. By contrast the MGFA cautionary drug list "
               "and the review by Narayanaswami et al. (J Clin Med 2021;10:1537) place sulfonamides, "
               "including co-trimoxazole, among the safe alternatives, stating that exacerbation has not "
               "been reported with cephalosporins, sulfa drugs or clindamycin. The drug to exclude is "
               "therefore ciprofloxacin, not co-trimoxazole."),
        'src': ('FDA boxed warning (2011) on fluoroquinolones in myasthenia gravis; '
                'Myasthenia Gravis Foundation of America — Cautionary Drugs; '
                'Narayanaswami P et al., J Clin Med 2021;10:1537'),
    },
}


def main():
    done = 0
    for i in range(1, 6):
        p = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        if not os.path.exists(p):
            continue
        body = json.load(io.open(p, encoding='utf-8'))
        changed = False
        for q in body['questions']:
            spec = CORRECTIONS.get(q.get('question_no'))
            if not spec:
                continue

            idx = None
            for j, o in enumerate(q['options_fa']):
                if spec['match'](re.sub(r'\s+', '', o)):
                    if idx is not None:
                        sys.exit(f'q{q["question_no"]}: option match is ambiguous; aborting')
                    idx = j
            if idx is None:
                sys.exit(f'q{q["question_no"]}: could not identify the target option; aborting')

            if q.get('key_corrected') and q['correct_index'] == idx:
                print(f'q{q["question_no"]}: already corrected')
                continue
            if q['correct_index'] == idx:
                sys.exit(f'q{q["question_no"]}: key already points there; check the matcher')

            q['original_correct_index'] = q['correct_index']
            q['correct_index'] = idx
            q['key_corrected'] = True
            q['key_correction_fa'] = spec['fa']
            q['key_correction_en'] = spec['en']
            q['key_correction_source'] = spec['src']
            changed = True
            done += 1
            print(f'q{q["question_no"]}: key {q["original_correct_index"]} -> {idx} '
                  f'({q["options_fa"][idx].strip()})')
        if changed:
            json.dump(body, io.open(p, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)
    print(f'corrected {done} key(s)')


if __name__ == '__main__':
    main()
