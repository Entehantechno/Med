# -*- coding: utf-8 -*-
"""Micro-lessons, batch 58 — remaining endocarditis items (14), completing
the chapter (36 of 36).

Three clusters cover almost every remaining question:

  RIGHT-SIDED IDU. Injecting drug use seeds the tricuspid valve. The murmur
  is often absent. The lungs, not the brain, take the emboli. Blood cultures
  plus echocardiography make the diagnosis; a single coagulase-negative
  staphylococcus is a contaminant until proven otherwise.

  MODIFIED DUKE. Two majors, or one major plus three minors, or five minors,
  make definite IE. The majors are tightly defined microbiology and evidence
  of endocardial involvement (including NEW regurgitation). Fever, IDU or a
  predisposing heart condition, vascular phenomena and immunologic phenomena
  are each ONE minor, however many lesions sit inside that category.

  PROPHYLAXIS. Only high-risk hearts AND gingival / apical / mucosal-perforating
  dental work. Respiratory and GI endoscopy do not qualify. Immediate penicillin
  allergy takes clindamycin (or azithromycin), never a first-generation
  cephalosporin.

Reference: Harrison's Principles of Internal Medicine, 21st ed (2022),
Ch. 128 Infective Endocarditis; AHA 2007/2021 prevention guideline.
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 128: Infective Endocarditis"
AHA = "Wilson W et al. AHA guideline on prevention of infective endocarditis. Circulation 2007; 2021 update"

IDU_FA = [
    "⚠️ **معتاد تزریقی = اندوکاردیت سمت راست تا خلافش ثابت شود.**",
    "**دریچه‌ی درگیر معمولاً تریکوسپید است**، چون ورید محیطی مستقیم به قلب راست می‌ریزد.",
    "**عامل اول استافیلوکوک اورئوس** است — تهاجمی، حاد، و باکتریمی پایدار.",
    "⚠️ **سوفل تریکوسپید اغلب شنیده نمی‌شود** یا خیلی نرم است؛ نبود سوفل تشخیص را رد نمی‌کند.",
    "**آمبولی سمت راست به ریه می‌رود** نه به مغز: تنگی نفس، سرفه، خلط، انفیلترای پراکنده.",
    "**آمبولی سپتیک ریه** معیار مینور عروقی دوک است و گاهی تنها تظاهر ریوی است.",
    "**پدیده‌های محیطی** (جین‌وی، اسپلینتر، پتشی ملتحمه) در سمت راست کمترند ولی اگر بودند، تشخیص را محکم می‌کنند.",
    "**گلومرولونفریت** (خون و گلبول سفید در ادرار) پدیده‌ی ایمونولوژیک است.",
    "⚠️ **تشخیص قطعی = کشت خون‌های متعدد + اکوکاردیوگرافی**، نه سی‌تی ریه به‌تنهایی.",
    "**یک کشت منفرد استاف اپیدرمیدیس آلودگی است** تا با تکرار ثابت شود.",
]
IDU_EN = [
    "WARNING: AN INJECTING DRUG USER HAS RIGHT-SIDED ENDOCARDITIS UNTIL PROVEN OTHERWISE.",
    "The valve is usually the TRICUSPID, because a peripheral vein drains straight into the right heart.",
    "The leading organism is STAPHYLOCOCCUS AUREUS — aggressive, acute, and persistently bacteraemic.",
    "WARNING: A TRICUSPID MURMUR IS OFTEN ABSENT or very soft; its absence does not exclude the diagnosis.",
    "RIGHT-SIDED EMBOLI GO TO THE LUNG, not the brain: breathlessness, cough, sputum, scattered infiltrates.",
    "SEPTIC PULMONARY EMBOLI are a Duke vascular minor and may be the only pulmonary finding.",
    "PERIPHERAL PHENOMENA (Janeway, splinters, conjunctival petechiae) are less common on the right, but if present they lock the diagnosis.",
    "GLOMERULONEPHRITIS (red and white cells in the urine) is an immunologic phenomenon.",
    "WARNING: DEFINITIVE DIAGNOSIS IS SERIAL BLOOD CULTURES PLUS ECHOCARDIOGRAPHY, not a chest CT alone.",
    "A SINGLE CULTURE OF S. EPIDERMIDIS IS A CONTAMINANT until repeats prove otherwise.",
]

DUKE_FA = [
    "⚠️ **تشخیص قطعی دوک: ۲ ماژور، یا ۱ ماژور + ۳ مینور، یا ۵ مینور.**",
    "**ماژور ۱ — میکروب‌شناسی تعریف‌شده:** دو کشت جدا با ارگانیسم تیپیک، یا باکتریمی پایدار، یا یک کشت کوکسیلا.",
    "⚠️ **یک کشت منفرد استاف اورئوس ماژور نیست** — فقط مینور میکروبیولوژیک است.",
    "**ماژور ۲ — درگیری اندوکارد:** وژتاسیون، آبسه‌ی حلقه، یا **نارسایی دریچه‌ای جدید**.",
    "**مینورها هر کدام یک سبدند، نه یک ضایعه:** تب ≥۳۸ · زمینه (دریچه‌ی مصنوعی، CHD، IE قبلی، IDU).",
    "**پدیده‌های عروقی (یک مینور):** جین‌وی، پتشی ملتحمه، آمبولی سپتیک ریه، ICH، آنوریسم میکوتیک.",
    "**پدیده‌های ایمونولوژیک (یک مینور):** اسلر، راث، گلومرولونفریت، فاکتور روماتوئید.",
    "**کشت که به ماژور نرسد** هم یک مینور است.",
    "⚠️ **تب، لکوسیتوز، دریچه‌ی مصنوعی به‌تنهایی ماژور نیستند.**",
    "**آمبولی عفونی ریه مینور عروقی است، نه ماژور.**",
]
DUKE_EN = [
    "WARNING: DEFINITE DUKE IE IS 2 MAJORS, OR 1 MAJOR + 3 MINORS, OR 5 MINORS.",
    "MAJOR 1 — DEFINED MICROBIOLOGY: two separate cultures of a typical organism, or persistent bacteraemia, or a single Coxiella culture.",
    "WARNING: A SINGLE S. AUREUS CULTURE IS NOT A MAJOR — it is only a microbiologic minor.",
    "MAJOR 2 — ENDOCARDIAL INVOLVEMENT: a vegetation, a ring abscess, or NEW VALVULAR REGURGITATION.",
    "MINORS ARE BASKETS, NOT LESIONS: fever ≥38 · predisposition (prosthesis, CHD, previous IE, IDU).",
    "VASCULAR PHENOMENA (one minor): Janeway, conjunctival petechiae, septic pulmonary emboli, ICH, mycotic aneurysm.",
    "IMMUNOLOGIC PHENOMENA (one minor): Osler, Roth, glomerulonephritis, rheumatoid factor.",
    "A CULTURE THAT FALLS SHORT OF MAJOR is also one minor.",
    "WARNING: FEVER, LEUCOCYTOSIS AND A PROSTHETIC VALVE ALONE ARE NOT MAJORS.",
    "SEPTIC PULMONARY EMBOLI ARE A VASCULAR MINOR, NOT A MAJOR.",
]

PROPH_FA = [
    "⚠️ **پروفیلاکسی فقط وقتی هر دو شرط با هم باشند: قلب پرخطر + کار دندان‌پزشکی مخاط‌دار.**",
    "**قلب پرخطر:** دریچه‌ی مصنوعی یا ترمیم با پروتز · IE قبلی · CHD سیانوتیک ترمیم‌نشده یا شانت باقی‌مانده · پیوند قلب با والولوپاتی.",
    "**کار دندان‌پزشکی واجد شرایط:** دست‌کاری لثه، ناحیه‌ی پری‌آپیکال، یا سوراخ کردن مخاط دهان (از جمله درناژ آبسه‌ی دندانی).",
    "⚠️ **برونکوسکوپی، آندوسکوپی گوارش و سیستوسکوپی پروفیلاکسی نمی‌خواهند** — مگر برش مخاط.",
    "**رژیم استاندارد:** آموکسی‌سیلین ۲ گرم خوراکی یک ساعت قبل.",
    "⚠️ **حساسیت فوری به پنی‌سیلین:** کلیندامایسین (یا آزیترومایسین/کلاریترومایسین). **سفالکسین ممنوع است.**",
    "**وانکومایسین** جایگزین وریدی است اگر بیمار نتواند خوراکی بگیرد — خط اول حساسیت نیست.",
    "**VSD کاملاً ترمیم‌شده پس از ۶ ماه** دیگر پرخطر نیست؛ **نقص باقی‌مانده** همچنان پرخطر است.",
    "⚠️ **IE درمان‌شده‌ی دو سال پیش به‌تنهایی، برای برونکوسکوپی کافی نیست.**",
    "**سیپروفلوکساسین رژیم پروفیلاکسی دندانی نیست.**",
]
PROPH_EN = [
    "WARNING: PROPHYLAXIS ONLY WHEN BOTH CONDITIONS ARE MET: A HIGH-RISK HEART AND QUALIFYING DENTAL WORK.",
    "HIGH-RISK HEARTS: prosthetic valve or prosthetic repair · previous IE · unrepaired cyanotic CHD or residual shunt · transplanted heart with valvulopathy.",
    "QUALIFYING DENTAL WORK: gingival manipulation, the periapical region, or perforation of oral mucosa (including drainage of a dental abscess).",
    "WARNING: BRONCHOSCOPY, GI ENDOSCOPY AND CYSTOSCOPY DO NOT NEED PROPHYLAXIS — unless mucosa is incised.",
    "STANDARD REGIMEN: amoxicillin 2 g orally one hour before.",
    "WARNING: IMMEDIATE PENICILLIN ALLERGY: clindamycin (or azithromycin/clarithromycin). CEPHALEXIN IS FORBIDDEN.",
    "VANCOMYCIN is the intravenous alternative if the patient cannot take oral drugs — not first-line for allergy.",
    "A FULLY REPAIRED VSD AFTER 6 MONTHS is no longer high-risk; A RESIDUAL DEFECT still is.",
    "WARNING: TREATED IE TWO YEARS AGO IS NOT ENOUGH, BY ITSELF, TO PROPHYLAX A BRONCHOSCOPY.",
    "CIPROFLOXACIN IS NOT A DENTAL-PROPHYLAXIS REGIMEN.",
]

REFS_IE = [H]
REFS_PR = [H, AHA]

# =========================================================== IDU diagnosis
add("book:101", "vignette", "easy",
    "**معتاد تزریقی + تب + تنگی نفس + اسلر + اسپلینتر + کشت مثبت ← اندوکاردیت.**",
    "An injecting drug user with fever, breathlessness, Osler nodes, splinters and a positive culture has endocarditis.",
    IDU_FA + [
        "اسلر و اسپلینتر پدیده‌های کلاسیک محیطی‌اند و تشخیص افتراقی را باریک می‌کنند.",
        "بروسلوز تب و درد استخوان می‌دهد، نه اسلر و خونریزی خطی ناخن.",
        "تیفوئید رزئولا و برادی‌کاردی نسبی می‌دهد، نه ندول انگشت.",
        "سل ریوی مزمن است و باکتریمی پایدار با پدیده‌ی محیطی نمی‌سازد.",
    ],
    IDU_EN + [
        "Osler nodes and splinters are classical peripheral phenomena and narrow the differential.",
        "Brucellosis gives fever and bone pain, not Osler nodes and linear nail-bed haemorrhages.",
        "Typhoid gives rose spots and relative bradycardia, not finger nodules.",
        "Pulmonary tuberculosis is chronic and does not produce sustained bacteraemia with peripheral phenomena.",
    ],
    "معتاد تزریقی با تب و تنگی نفس، تا خلافش ثابت شود **اندوکاردیت سمت راست** است. اینجا علاوه بر زمینه‌ی IDU، **ندول اسلر، خونریزی خطی بستر ناخن و کشت خون مثبت** هم هست — یعنی پدیده‌ی ایمونولوژیک + پدیده‌ی عروقی + میکروب‌شناسی. این سه‌گانه تشخیص را از حد «محتمل» به «تقریباً قطعی» می‌برد.\n\n"
    "⚠️ **چرا ریه‌ها درگیرند؟** چون دریچه‌ی تریکوسپید آمبولی را به شریان ریوی می‌فرستد، نه به سیستمیک. رال منتشر و تنگی نفس همان آمبولی سپتیک ریه است.\n\n"
    "**بروسلوز** در ایران شایع است و تب طول‌کشیده می‌دهد، ولی اسلر و اسپلینتر مال اندوکاردیت‌اند نه مال تب مالت. **تیفوئید** رزئولا و برادی‌کاردی نسبی می‌خواهد. **سل ریوی** سیر ماه‌هاست و باکتریمی پایدار با پدیده‌ی پوستی نمی‌سازد.",
    "An injecting drug user with fever and breathlessness has RIGHT-SIDED ENDOCARDITIS until proven otherwise. Here, on top of the IDU setting, there are OSLER NODES, SPLINTER HAEMORRHAGES and a POSITIVE BLOOD CULTURE — an immunologic phenomenon plus a vascular phenomenon plus microbiology. That triad moves the diagnosis from 'likely' to 'almost certain'.\n\n"
    "WARNING: WHY ARE THE LUNGS INVOLVED? Because the tricuspid valve throws emboli into the pulmonary artery, not the systemic circuit. The diffuse crackles and breathlessness ARE the septic pulmonary emboli.\n\n"
    "BRUCELLOSIS is common in Iran and causes prolonged fever, but Osler nodes and splinters belong to endocarditis, not to Malta fever. TYPHOID wants rose spots and relative bradycardia. PULMONARY TUBERCULOSIS runs over months and does not produce sustained bacteraemia with skin phenomena.",
    ["پاسخ صحیح — IDU + تب + اسلر + اسپلینتر + کشت مثبت، تعریف بالینی اندوکاردیت است.",
     "بروسلوز تب طول‌کشیده می‌دهد ولی پدیده‌های محیطی کلاسیک اندوکاردیت را نمی‌سازد.",
     "تیفوئید رزئولا و برادی‌کاردی نسبی می‌خواهد، نه ندول اسلر و اسپلینتر.",
     "سل ریوی سیر مزمن دارد و باکتریمی پایدار با پدیده‌ی پوستی نمی‌دهد."],
    ["Correct — IDU plus fever plus Osler nodes plus splinters plus a positive culture is the clinical definition of endocarditis.",
     "Brucellosis causes prolonged fever but not the classical peripheral phenomena of endocarditis.",
     "Typhoid wants rose spots and relative bradycardia, not Osler nodes and splinters.",
     "Pulmonary tuberculosis is chronic and does not produce sustained bacteraemia with skin phenomena."],
    "**IDU + تب + پدیده‌ی محیطی = اندوکاردیت سمت راست.** ریه، نه مغز، بستر آمبولی است.",
    "IDU plus fever plus a peripheral phenomenon means right-sided endocarditis. The lung, not the brain, is the embolic bed.",
    REFS_IE)

add("book:102", "vignette", "medium",
    "**سمع قلب نرمال، تشخیص را رد نمی‌کند — تریکوسپید اغلب خاموش است.**",
    "A normal heart examination does not exclude the diagnosis — the tricuspid is often silent.",
    IDU_FA + [
        "این بیمار دقیقاً همان تله را دارد: سمع قلب نرمال + درگیری واضح ریه و پوست و طحال.",
        "پنومونی ساده طحال بزرگ و ضایعات اکیموتیک پا نمی‌سازد.",
        "«سپتی‌سمی» توصیف است نه تشخیص؛ منبع را باید نام ببرید.",
        "«هیچ‌کدام» وقتی تابلو کلاسیک سمت راست کامل است، قابل دفاع نیست.",
    ],
    IDU_EN + [
        "This patient is exactly that trap: a normal heart examination with obvious lung, skin and splenic involvement.",
        "Simple pneumonia does not enlarge the spleen or put ecchymotic lesions on the feet.",
        "'Septicaemia' is a description, not a diagnosis; the source still has to be named.",
        "'None of the above' is indefensible when the right-sided picture is complete.",
    ],
    "جوان معتاد تزریقی با سرفه، خلط، تنگی نفس ناگهانی، تب، رال منتشر، راش ماکولوپاپولر، ضایعات اکیموتیک پا و **طحال بزرگ** آمده — و سمع قلب **نرمال** است.\n\n"
    "⚠️ **تله‌ی سؤال همین «سمع نرمال» است.** دانشجو فکر می‌کند بدون سوفل اندوکاردیت نیست. در سمت راست، نارسایی تریکوسپید اغلب آرام است و در اورژانس شلوغ شنیده نمی‌شود. **نبود سوفل تشخیص را رد نمی‌کند.**\n\n"
    "آنچه تشخیص را می‌سازد، **مجموعه‌ی آمبولی ریوی سپتیک + پدیده‌ی پوستی + اسپلنومگالی + زمینه‌ی IDU** است. پنومونی این مجموعه را توضیح نمی‌دهد. «سپتی‌سمی» فقط می‌گوید باکتری در خون است؛ منبع را باید نام برد — و منبع در این زمینه دریچه‌ی تریکوسپید است.",
    "A young injecting drug user presents with cough, sputum, sudden breathlessness, fever, diffuse crackles, a maculopapular rash, ecchymotic lesions on the feet and SPLENOMEGALY — and the heart examination is NORMAL.\n\n"
    "WARNING: THE TRAP IS THAT 'NORMAL AUSCULTATION'. The student thinks endocarditis needs a murmur. On the right side, tricuspid regurgitation is often quiet and is missed in a busy emergency room. ABSENCE OF A MURMUR DOES NOT EXCLUDE THE DIAGNOSIS.\n\n"
    "What makes the diagnosis is the CLUSTER of septic pulmonary emboli plus skin phenomena plus splenomegaly plus the IDU setting. Pneumonia does not explain that cluster. 'Septicaemia' only says there is bacteria in the blood; the source still has to be named — and in this setting the source is the tricuspid valve.",
    ["پاسخ صحیح — سمت راست اغلب بدون سوفل است؛ آمبولی ریه + پوست + طحال + IDU تشخیص را می‌سازد.",
     "پنومونی طحال بزرگ و ضایعات اکیموتیک پا نمی‌سازد.",
     "سپتی‌سمی توصیف است نه تشخیص؛ منبع در این زمینه دریچه‌ی تریکوسپید است.",
     "وقتی تابلوی کلاسیک سمت راست کامل است، «هیچ‌کدام» قابل دفاع نیست."],
    ["Correct — the right side is often silent; lung emboli plus skin plus spleen plus IDU make the diagnosis.",
     "Pneumonia does not enlarge the spleen or put ecchymoses on the feet.",
     "Septicaemia is a description, not a diagnosis; the source in this setting is the tricuspid valve.",
     "'None of the above' is indefensible when the classical right-sided picture is complete."],
    "**نبود سوفل، اندوکاردیت راست را رد نمی‌کند.** ریه را ببین، نه فقط قلب را.",
    "Absence of a murmur does not exclude right-sided endocarditis. Look at the lung, not only the heart.",
    REFS_IE)

add("book:104", "vignette", "medium",
    "**یک کشت استاف اپیدرمیدیس = آلودگی تا خلافش ثابت شود. تکرار کشت + اکو.**",
    "A single S. epidermidis culture is a contaminant until proven otherwise. Repeat cultures plus an echo.",
    IDU_FA + [
        "استاف اپیدرمیدیس شایع‌ترین آلوده‌کننده‌ی پوستی کشت خون است.",
        "برای اینکه کوآگولاز‌منفی ماژور شود، باید **پایدار** باشد — یعنی چند کشت جدا.",
        "شروع وانکومایسین فقط به‌خاطر یک کشت، هم تشخیص را خراب می‌کند هم مقاومت می‌سازد.",
        "سی‌تی ریه آمبولی را نشان می‌دهد ولی منبع قلبی را ثابت نمی‌کند.",
    ],
    IDU_EN + [
        "S. epidermidis is the commonest skin contaminant of blood cultures.",
        "For a coagulase-negative staphylococcus to become a major, it must be PERSISTENT — several separate cultures.",
        "Starting vancomycin on a single culture both ruins the diagnosis and breeds resistance.",
        "A chest CT can show emboli but does not prove a cardiac source.",
    ],
    "معتاد تزریقی با تب و تنگی نفس آمده و **یک نوبت** کشت، استاف اپیدرمیدیس حساس به وانکومایسین گزارش شده.\n\n"
    "⚠️ **استاف اپیدرمیدیس شایع‌ترین آلوده‌کننده‌ی کشت خون است.** یک بطری مثبت، تا وقتی تکرار نشود، آلودگی است نه باکتریمی. در معیار دوک، کوآگولازمنفی فقط وقتی ماژور می‌شود که **پایدار** باشد.\n\n"
    "**اقدام درست: تکرار کشت‌ها (پیش از آنتی‌بیوتیک) + اکوکاردیوگرافی.** اگر کشت‌های بعدی منفی ماندند و اکو تمیز بود، آن یک کشت را دور بریزید. اگر تکرار شد یا وژتاسیون دیده شد، آن‌وقت درمان کنید.\n\n"
    "شروع وانکومایسین همین حالا دو ضرر دارد: کشت‌های بعدی را منفی می‌کند و یک گلیکوپپتید را برای آلودگی مصرف می‌کند. سی‌تی ریه هم منبع را نشان نمی‌دهد.",
    "An injecting drug user presents with fever and breathlessness, and a SINGLE culture has grown vancomycin-sensitive S. epidermidis.\n\n"
    "WARNING: S. EPIDERMIDIS IS THE COMMONEST BLOOD-CULTURE CONTAMINANT. One positive bottle, until it is repeated, is contamination and not bacteraemia. Under Duke, a coagulase-negative staphylococcus becomes a major only when it is PERSISTENT.\n\n"
    "THE RIGHT STEP: REPEAT THE CULTURES (before antibiotics) PLUS ECHOCARDIOGRAPHY. If later cultures stay negative and the echo is clean, discard that one isolate. If it repeats or a vegetation is seen, then treat.\n\n"
    "Starting vancomycin now does two harms: it sterilises later cultures and spends a glycopeptide on a contaminant. A chest CT also fails to prove the source.",
    ["پاسخ صحیح — یک کشت کوآگولازمنفی آلودگی است؛ تکرار کشت و اکو قدم بعدی است.",
     "وانکومایسین برای «سپسیس» بر اساس یک کشت آلودگی، تشخیص را خراب و مقاومت می‌سازد.",
     "اکو لازم است ولی بدون تکرار کشت، یک کوآگولازمنفی را قطعی کرده‌اید.",
     "سی‌تی ریه آمبولی را نشان می‌دهد نه منبع قلبی را."],
    ["Correct — a single coagulase-negative culture is a contaminant; repeat cultures and an echo are the next step.",
     "Vancomycin for 'sepsis' on one contaminant culture ruins the diagnosis and breeds resistance.",
     "An echo is needed, but without repeat cultures you have treated a coagulase-negative isolate as proven.",
     "A chest CT shows emboli, not a cardiac source."],
    "**یک کشت اپیدرمیدیس = آلودگی.** تکرار کن، بعد درمان کن.",
    "A single epidermidis culture is a contaminant. Repeat it, then treat.",
    REFS_IE)

add("book:105", "vignette", "easy",
    "**جین‌وی + پتشی ملتحمه + ادرار فعال + IDU ← کشت خون و اکو، نه سی‌تی ریه.**",
    "Janeway lesions plus conjunctival petechiae plus an active urine plus IDU: blood cultures and an echo, not a chest CT.",
    IDU_FA + [
        "ضایعات هموراژیک کف دست و پا = جین‌وی (پدیده‌ی عروقی).",
        "پتشی ملتحمه هم پدیده‌ی عروقی است.",
        "گلبول سفید و قرمز ادرار = گلومرولونفریت ایمونولوژیک.",
        "سی‌تی آنژیو ریه آمبولی غیرعفونی را می‌جوید؛ اینجا منبع قلب است.",
    ],
    IDU_EN + [
        "Haemorrhagic lesions of the palms and soles are Janeway lesions (vascular).",
        "Conjunctival petechiae are also vascular.",
        "White and red cells in the urine are immunologic glomerulonephritis.",
        "CT pulmonary angiography hunts sterile emboli; here the source is the heart.",
    ],
    "جوان معتاد تزریقی با تب، تنگی نفس، **ضایعات هموراژیک کف دست و پا (جین‌وی)**، **پتشی ملتحمه** و **ادرار فعال** آمده. سؤال «تشخیص قطعی» را می‌پرسد.\n\n"
    "⚠️ **دو آزمونی که تشخیص اندوکاردیت را قطعی می‌کنند کشت خون و اکوکاردیوگرافی‌اند** — همان دو معیار ماژور دوک. بقیه‌ی تصویربرداری‌ها عوارض را نشان می‌دهند، خود بیماری را نه.\n\n"
    "سی‌تی آنژیو ریه برای آمبولی ترومبوآمبولیک است. سی‌تی ساده ریه انفیلترا را می‌بیند ولی منبع را ثابت نمی‌کند. کشت ادرار و سونوی کلیه گلومرولونفریت ایمونولوژیک را از پیلونفریت جدا نمی‌کند و اولویت ندارد.",
    "A young injecting drug user presents with fever, breathlessness, HAEMORRHAGIC PALMO-PLANTAR LESIONS (Janeway), CONJUNCTIVAL PETECHIAE and an ACTIVE URINE. The question asks for the DEFINITIVE diagnosis.\n\n"
    "WARNING: THE TWO TESTS THAT MAKE ENDOCARDITIS DEFINITIVE ARE BLOOD CULTURES AND ECHOCARDIOGRAPHY — the two Duke majors. Other imaging shows complications, not the disease itself.\n\n"
    "CT pulmonary angiography is for thrombo-embolic emboli. A plain chest CT sees infiltrates but does not prove the source. Urine culture and renal ultrasound do not separate immunologic glomerulonephritis from pyelonephritis and are not the priority.",
    ["پاسخ صحیح — تشخیص قطعی اندوکاردیت با کشت خون و اکوکاردیوگرافی گذاشته می‌شود.",
     "سی‌تی آنژیو ریه آمبولی استریل را می‌جوید، نه منبع دریچه‌ای را.",
     "سی‌تی ریه عارضه را می‌بیند نه تشخیص قطعی را.",
     "کشت ادرار اولویت ندارد؛ ادرار فعال اینجا گلومرولونفریت ایمونولوژیک است."],
    ["Correct — endocarditis is made definitive by blood cultures and echocardiography.",
     "CT pulmonary angiography hunts sterile emboli, not a valvular source.",
     "A chest CT sees a complication, not the definitive diagnosis.",
     "Urine culture is not the priority; the active urine here is immunologic glomerulonephritis."],
    "**تشخیص قطعی IE = کشت خون + اکو.** بقیه‌ی تصویرها عارضه‌اند.",
    "Definitive IE is blood cultures plus an echo. Every other image is a complication.",
    REFS_IE)

add("book:107", "vignette", "medium",
    "**ICH + جین‌وی + کشت‌های متعدد + RF+ + تب مقاوم ← اکو، نه اسمیر و رایت.**",
    "ICH plus Janeway plus serial positive cultures plus RF plus persistent fever: an echo, not a smear or a Wright.",
    IDU_FA + DUKE_FA + [
        "خونریزی داخل مغزی در IE یعنی آمبولی سپتیک یا آنوریسم میکوتیک — هر دو عروقی‌اند.",
        "فاکتور روماتوئید مثبت پدیده‌ی ایمونولوژیک است، نه لوپوس.",
        "تب پس از چهار روز آنتی‌بیوتیک در استاف اورئوس غیرمعمول نیست؛ شکست درمان نیست.",
        "اسمیر خون محیطی مالاریا و رایت بروسلوز را می‌جویند؛ اینجا تصویر IE کامل است.",
    ],
    IDU_EN + DUKE_EN + [
        "Intracranial haemorrhage in IE means a septic embolus or a mycotic aneurysm — both vascular.",
        "A positive rheumatoid factor is an immunologic phenomenon, not lupus.",
        "Fever after four days of antibiotics is not unusual in S. aureus; it is not treatment failure.",
        "A peripheral smear hunts malaria and a Wright hunts brucellosis; here the IE picture is already complete.",
    ],
    "تب ۳۹، **خونریزی داخل مغزی**، دیسترس تنفسی، ضایعات کف دست و پا، **چند کشت مثبت متوالی** و **RF مثبت**. تب پس از چهار روز آنتی‌بیوتیک مانده. «ارزشمندترین اقدام تشخیصی» چیست؟\n\n"
    "این بیمار از همین حالا **قطعی دوک** است: کشت‌های پایدار (ماژور) + پدیده‌ی عروقی (ICH و جین‌وی) + پدیده‌ی ایمونولوژیک (RF) + تب. آنچه هنوز نداریم **تصویر دریچه** است — و همان اکو است که وژتاسیون، آبسه‌ی حلقه یا نارسایی جدید را نشان می‌دهد و تصمیم جراحی را می‌سازد.\n\n"
    "⚠️ تب چهارروزه در IE استافی، شکست درمان نیست؛ متوسط فروکش تب چند روز است. اسمیر محیطی و رایت وقتی تصویر این‌قدر اختصاصی است، حواس‌پرتی‌اند. اسکن ریه عارضه را می‌بیند نه دریچه را.",
    "Fever of 39, INTRACRANIAL HAEMORRHAGE, respiratory distress, palmo-plantar lesions, SEVERAL SUCCESSIVE POSITIVE CULTURES and a POSITIVE RF. The fever is still there after four days of antibiotics. What is the highest-yield diagnostic step?\n\n"
    "This patient already has DEFINITE DUKE IE: persistent cultures (major) plus vascular phenomena (ICH and Janeway) plus an immunologic phenomenon (RF) plus fever. What we still do not have is AN IMAGE OF THE VALVE — and that echo is what shows the vegetation, the ring abscess or the new regurgitation and decides about surgery.\n\n"
    "WARNING: four days of fever in staphylococcal IE is not treatment failure; defervescence often takes several days. A peripheral smear and a Wright are distractions when the picture is this specific. A lung scan sees a complication, not the valve.",
    ["اسمیر محیطی مالاریا را می‌جوید؛ این تصویر اندوکاردیت است نه تب رقصان.",
     "پاسخ صحیح — اکو وژتاسیون و عارضه‌ی دریچه‌ای را نشان می‌دهد و تصمیم جراحی را می‌سازد.",
     "اسکن ریه عارضه‌ی آمبولیک را می‌بیند، نه منبع را.",
     "سرولوژی رایت بروسلوز را می‌جوید؛ کشت پایدار و ICH و RF تصویر IE است."],
    ["A peripheral smear hunts malaria; this picture is endocarditis, not a swinging fever.",
     "Correct — the echo shows the vegetation and the valvular complication and decides about surgery.",
     "A lung scan sees the embolic complication, not the source.",
     "A Wright hunts brucellosis; persistent cultures plus ICH plus RF is the picture of IE."],
    "**وقتی کشت پایدار است، اکو قدم بعدی است — حتی اگر تب چهار روز مانده باشد.**",
    "Once the cultures are persistent, the echo is the next step — even if the fever has lasted four days.",
    REFS_IE)

add("book:108", "vignette", "easy",
    "**پتشی ملتحمه + ضایعه‌ی کف پا + تب یک‌ماهه ← اکو اولویت تشخیصی است.**",
    "Conjunctival petechiae plus a sole lesion plus a month of fever: the echo is the diagnostic priority.",
    IDU_FA + [
        "گزینه‌ها کشت خون ندارند؛ در میان باقی‌مانده، اکو اختصاصی‌ترین است.",
        "گرافی قفسه و CBC غیر اختصاصی‌اند و تشخیص را عوض نمی‌کنند.",
        "اسمیر محیطی مالاریا و بدخیمی خونی را می‌جوید؛ پدیده‌ی محیطی مال آن‌ها نیست.",
        "در عمل کشت خون را پیش از اکو می‌گیرید — ولی آن گزینه این‌جا نیست.",
    ],
    IDU_EN + [
        "The options do not include blood cultures; among what remains, the echo is the most specific.",
        "A chest film and a CBC are non-specific and do not change the diagnosis.",
        "A peripheral smear hunts malaria and a blood cancer; those do not make peripheral phenomena.",
        "In practice you draw cultures before the echo — but that option is not here.",
    ],
    "مرد ۶۵ ساله با یک ماه تب، پتشی ملتحمه و ضایعات اریتماتوی کف پا. در گزینه‌ها کشت خون نیست؛ بین گرافی قفسه، اسمیر محیطی، CBC و اکو، کدام اولویت تشخیصی است؟\n\n"
    "پتشی ملتحمه و ضایعه‌ی کف پا (جین‌وی) پدیده‌های عروقی‌اند. در بیمار تب‌دار، این ترکیب **اندوکاردیت** را بالای فهرست می‌برد. اکوکاردیوگرافی تنها آزمونی است که مستقیماً وژتاسیون را نشان می‌دهد.\n\n"
    "⚠️ در بالین واقعی **اول کشت خون، بعد اکو** — چون آنتی‌بیوتیک را نباید پیش از کشت شروع کرد. اینجا کشت در گزینه‌ها نیست، پس اکو پاسخ است. گرافی و CBC و اسمیر هیچ‌کدام پدیده‌ی محیطی را توضیح نمی‌دهند.",
    "A 65-year-old man with a month of fever, conjunctival petechiae and erythematous sole lesions. Blood cultures are not among the options; between a chest film, a peripheral smear, a CBC and an echo, which is the diagnostic priority?\n\n"
    "Conjunctival petechiae and a sole lesion (Janeway) are vascular phenomena. In a febrile patient that combination puts ENDOCARDITIS at the top of the list. Echocardiography is the only test that shows a vegetation directly.\n\n"
    "WARNING: IN REAL LIFE CULTURES FIRST, THEN THE ECHO — because antibiotics must not start before cultures. Cultures are not listed here, so the echo is the answer. A film, a CBC and a smear explain none of the peripheral phenomena.",
    ["گرافی قفسه غیر اختصاصی است و پدیده‌ی محیطی را توضیح نمی‌دهد.",
     "اسمیر محیطی مالاریا یا بدخیمی خونی را می‌جوید، نه جین‌وی و پتشی ملتحمه را.",
     "شمارش سلولی التهاب را نشان می‌دهد نه منبع را.",
     "پاسخ صحیح — در میان گزینه‌ها اکو تنها آزمونی است که وژتاسیون را مستقیم می‌بیند."],
    ["A chest film is non-specific and does not explain the peripheral phenomena.",
     "A peripheral smear hunts malaria or a blood cancer, not Janeway lesions and conjunctival petechiae.",
     "A blood count shows inflammation, not a source.",
     "Correct — among the options the echo is the only test that sees a vegetation directly."],
    "**پدیده‌ی محیطی + تب طول‌کشیده = اکو.** کشت را در بالین اول بگیرید.",
    "A peripheral phenomenon plus prolonged fever means an echo. In real life, draw the cultures first.",
    REFS_IE)

# =========================================================== Duke criteria
add("book:114", "recall", "easy",
    "**نارسایی دریچه‌ای جدید ماژور است. تب، آمبولی ریه و اسلر مینورند.**",
    "New valvular regurgitation is a major. Fever, pulmonary emboli and Osler nodes are minors.",
    DUKE_FA,
    DUKE_EN,
    "سؤال مستقیم ماژور را می‌پرسد.\n\n"
    "⚠️ **تنها ماژور در این چهار گزینه، مشاهده‌ی نارسایی دریچه‌ای جدید در اکو است.** این دقیقاً نیمه‌ی دوم معیار ماژور «درگیری اندوکارد» است — حتی اگر وژتاسیون دیده نشود.\n\n"
    "**تب ≥۳۸** مینور است — شایع‌ترین و کم‌اختصاص‌ترین.\n\n"
    "**آمبولی عفونی ریه** پدیده‌ی عروقی است = یک مینور. دانشجو آن را با درگیری قلبی عوضی می‌گیرد.\n\n"
    "**گره‌های اسلر** پدیده‌ی ایمونولوژیک است = یک مینور.",
    "The question asks directly for a major.\n\n"
    "WARNING: THE ONLY MAJOR AMONG THESE FOUR OPTIONS IS NEW VALVULAR REGURGITATION ON THE ECHO. That is exactly the second half of the 'endocardial involvement' major — even if no vegetation is seen.\n\n"
    "FEVER ≥38 is a minor — the commonest and least specific.\n\n"
    "SEPTIC PULMONARY EMBOLI are a vascular phenomenon = one minor. Students confuse them with cardiac involvement.\n\n"
    "OSLER NODES are an immunologic phenomenon = one minor.",
    ["تب معیار مینور است، شایع‌ترین و کم‌اختصاص‌ترین.",
     "آمبولی عفونی ریه پدیده‌ی عروقی و مینور است، نه ماژور.",
     "گره‌های اسلر پدیده‌ی ایمونولوژیک و مینورند.",
     "پاسخ صحیح — نارسایی دریچه‌ای جدید یکی از دو معیار ماژور دوک است."],
    ["Fever is a minor, the commonest and least specific.",
     "Septic pulmonary emboli are a vascular phenomenon and a minor, not a major.",
     "Osler nodes are an immunologic phenomenon and a minor.",
     "Correct — new valvular regurgitation is one of the two Duke majors."],
    "**ماژور = کشت تعریف‌شده یا درگیری اندوکارد (وژتاسیون / نارسایی جدید).** بقیه مینورند.",
    "A major is defined microbiology or endocardial involvement (vegetation / new regurgitation). Everything else is a minor.",
    REFS_IE)

add("book:115", "recall", "easy",
    "**رگورژیتاسیون جدید ماژور است. یک کشت از سه تا، لکوسیتوز و پروتز مینور یا هیچ‌اند.**",
    "New regurgitation is a major. One of three cultures, leucocytosis and a prosthesis are minor or nothing.",
    DUKE_FA,
    DUKE_EN,
    "همان قاعده، با تله‌های تازه‌تر.\n\n"
    "**بروز رگورژیتاسیون جدید که قبلاً نبوده** = ماژور. این را حفظ نکنید؛ بفهمید: یعنی دریچه تازه خراب شده، پس اندوکارد درگیر است.\n\n"
    "**یک نوبت کشت از سه کشت** به تعریف ماژور نمی‌رسد. برای ارگانیسم تیپیک **دو کشت جدا** لازم است. یک کشت فقط مینور میکروبیولوژیک است — و اگر فاصله‌ها و پایداری رعایت نشده باشد، حتی همان را هم نمی‌دهد.\n\n"
    "**لکوسیتوز** اصلاً معیار دوک نیست.\n\n"
    "**دریچه‌ی مصنوعی** زمینه‌ی مستعد است = مینور، نه ماژور.",
    "The same rule, with fresher traps.\n\n"
    "NEW REGURGITATION THAT WAS NOT THERE BEFORE is a major. Do not memorise it; understand it: the valve has just broken, so the endocardium is involved.\n\n"
    "ONE OF THREE CULTURES does not meet the major definition. A typical organism needs TWO SEPARATE CULTURES. One culture is only a microbiologic minor — and if timing and persistence are not met, not even that.\n\n"
    "LEUCOCYTOSIS is not a Duke criterion at all.\n\n"
    "A PROSTHETIC VALVE is a predisposing condition = a minor, not a major.",
    ["یک کشت از سه تا به تعریف ماژور نمی‌رسد؛ برای ارگانیسم تیپیک دو کشت جدا لازم است.",
     "لکوسیتوز اصلاً معیار دوک نیست.",
     "پاسخ صحیح — رگورژیتاسیون جدید یعنی درگیری اندوکارد و ماژور است.",
     "دریچه‌ی مصنوعی زمینه‌ی مستعد و مینور است، نه ماژور."],
    ["One of three cultures does not meet the major; a typical organism needs two separate cultures.",
     "Leucocytosis is not a Duke criterion at all.",
     "Correct — new regurgitation means endocardial involvement and is a major.",
     "A prosthetic valve is a predisposing condition and a minor, not a major."],
    "**یک کشت ≠ ماژور. پروتز ≠ ماژور. لکوسیتوز اصلاً معیار نیست.**",
    "One culture is not a major. A prosthesis is not a major. Leucocytosis is not a criterion at all.",
    REFS_IE)

add("book:116", "vignette", "hard",
    "**بدون کشت و بدون اکو ماژوری در کار نیست. زمینه‌ + تب + پدیده‌ی عروقی = سه مینور.**",
    "With no culture and no echo there is no major. Predisposition plus fever plus vascular phenomena is three minors.",
    DUKE_FA + [
        "این سؤال گزینه‌ی «۳ مینور» ندارد؛ کلید چاپی «۲ مینور» است.",
        "شمارش درست دوک: IDU/IE قبلی (یک زمینه‌) + تب + سبد عروقی (جین‌وی + پتشی + انفیلترای ریه).",
        "چند ضایعه‌ی عروقی را جدا نشمارید — همه یک مینورند.",
        "پس تشخیص قطعی نیست؛ حداکثر IE محتمل (possible) است.",
    ],
    DUKE_EN + [
        "This question has no '3 minors' option; the printed key is '2 minors'.",
        "The true Duke count: IDU/previous IE (one predisposition) + fever + the vascular basket (Janeway + petechiae + lung infiltrates).",
        "Do not count several vascular lesions separately — they are one minor.",
        "So this is not definite IE; at most it is possible IE.",
    ],
    "معتاد تزریقی با تب بالا، تنگی نفس، RR=۳۲، **سابقه‌ی IE سال گذشته**، پتشی ملتحمه، ضایعات اکیموتیک کف دست و پا، و انفیلترای پراکنده‌ی دو طرفه. کشت و اکو ذکر نشده. چند معیار؟\n\n"
    "⚠️ **ماژوری در کار نیست** — نه کشت تعریف‌شده هست نه تصویر دریچه. انفیلترای ریه آمبولی سپتیک است و **مینور عروقی**، نه ماژور.\n\n"
    "**شمارش درست مینورها:**\n"
    "۱. زمینه: IDU و IE قبلی — **یک** مینور (سبد استعداد، نه دو سبد)\n"
    "۲. تب\n"
    "۳. پدیده‌ی عروقی: جین‌وی + پتشی ملتحمه + آمبولی ریه — باز **یک** سبد\n\n"
    "جمع = **۳ مینور** = IE محتمل (possible)، نه قطعی. گزینه‌ها ۳ مینور ندارند. کلید چاپی **۲ مینور** است و زمینه‌ را جدا نشمرده. در امتحان اگر ۳ مینور بود همان را بزنید؛ روش درست همین سبدهاست نه شمردن ضایعه به ضایعه (که ۵ مینور غلط می‌سازد).",
    "An injecting drug user with high fever, breathlessness, RR 32, PREVIOUS IE LAST YEAR, conjunctival petechiae, palmo-plantar ecchymoses and bilateral scattered infiltrates. No culture and no echo are mentioned. How many criteria?\n\n"
    "WARNING: THERE IS NO MAJOR — neither defined microbiology nor an image of the valve. The lung infiltrates are septic emboli and a VASCULAR MINOR, not a major.\n\n"
    "THE TRUE MINOR COUNT:\n"
    "1. Predisposition: IDU and previous IE — ONE minor (one basket, not two)\n"
    "2. Fever\n"
    "3. Vascular phenomena: Janeway + conjunctival petechiae + pulmonary emboli — again ONE basket\n\n"
    "Total = 3 MINORS = possible, not definite, IE. The options do not list 3 minors. The printed key is 2 MINORS and has not counted predisposition separately. In the exam, if 3 minors is listed, take it; the right method is these baskets, not lesion-by-lesion counting (which falsely makes 5 minors).",
    ["بدون کشت و اکو ماژوری نیست؛ انفیلترای ریه مینور عروقی است.",
     "پنج مینور فقط اگر هر ضایعه‌ی عروقی را جدا بشمارید ساخته می‌شود؛ دوک این کار را نمی‌کند.",
     "باز یک ماژور اختراع شده؛ تصویر ریه ماژور نیست.",
     "پاسخ کلید منبع — ۲ مینور (تب + عروقی). شمارش کامل دوک ۳ مینور است و در گزینه‌ها نیست."],
    ["With no culture and no echo there is no major; the lung infiltrates are a vascular minor.",
     "Five minors is produced only by counting each vascular lesion separately; Duke does not do that.",
     "Again a major has been invented; a lung image is not a major.",
     "Printed key — 2 minors (fever + vascular). The complete Duke count is 3 minors, which is not listed."],
    "**سبد بشمار، نه ضایعه.** چند جین‌وی هنوز یک مینور عروقی است.",
    "Count baskets, not lesions. Several Janeway spots are still one vascular minor.",
    REFS_IE)

add("book:117", "vignette", "medium",
    "**تب که ظرف ۴۸ ساعت با آنتی‌بیوتیک قطع شود و برنگردد، اندوکاردیت نیست.**",
    "A fever that breaks within 48 hours on antibiotics and does not return is not endocarditis.",
    IDU_FA + [
        "در IE استافی، متوسط زمان بی‌تب شدن چند روز تا یک هفته است، نه ۴۸ ساعت.",
        "وژتاسیون یک پناهگاه بدون عروق است؛ با دو روز دارو پاک نمی‌شود.",
        "سپسیس ساده‌ی بدون کانون، مننژیت درمان‌شده و حتی تیفوئید می‌توانند در ۴۸ ساعت آرام شوند.",
        "قطع کامل تب و ماندن بهبود در طول بستری، IE را از فهرست خارج می‌کند.",
    ],
    IDU_EN + [
        "In staphylococcal IE the median time to defervescence is several days to a week, not 48 hours.",
        "A vegetation is an avascular sanctuary; two days of drug will not clear it.",
        "Uncomplicated sepsis, treated meningitis and even typhoid can settle within 48 hours.",
        "Complete defervescence that holds for the rest of the admission takes IE off the list.",
    ],
    "معتاد تزریقی با تب بالا و کاهش هوشیاری، بدون آنتی‌بیوتیک قبلی، وسیع‌الطیف می‌گیرد و **ظرف ۴۸ ساعت بدون تب‌بر، تب قطع می‌شود و در بستری برنمی‌گردد**. همه‌ی تشخیص‌ها مطرح است **بجز**؟\n\n"
    "⚠️ **اندوکاردیت این‌طور رفتار نمی‌کند.** وژتاسیون پناهگاه بدون عروق است. حتی با آنتی‌بیوتیک درست، تب IE — به‌ویژه استاف اورئوس — معمولاً **۳ تا ۷ روز** می‌ماند. قطع کامل در ۴۸ ساعت و ماندن بهبود، با بقای وژتاسیون نمی‌خواند.\n\n"
    "سپتی‌سمی بدون کانون دریچه‌ای می‌تواند سریع پاسخ دهد. مننژیت باکتریایی با آنتی‌بیوتیک مناسب در همین بازه آرام می‌شود. تیفوئید هم گاهی در چند روز اول فروکش می‌کند. پس تنها تشخیصی که این سیر آن را تقریباً رد می‌کند، اندوکاردیت است.",
    "An injecting drug user with high fever and a reduced conscious level, previously untreated, is given broad-spectrum antibiotics and WITHIN 48 HOURS, WITHOUT AN ANTIPYRETIC, THE FEVER BREAKS AND DOES NOT RETURN. All of the diagnoses are possible EXCEPT?\n\n"
    "WARNING: ENDOCARDITIS DOES NOT BEHAVE LIKE THIS. A vegetation is an avascular sanctuary. Even on the right antibiotic, the fever of IE — especially S. aureus — usually lasts 3 TO 7 DAYS. Complete defervescence in 48 hours that then holds is incompatible with a surviving vegetation.\n\n"
    "Septicaemia without a valvular focus can respond quickly. Bacterial meningitis on appropriate antibiotics settles in the same window. Typhoid sometimes defervesces in the first few days too. So the one diagnosis this course almost excludes is endocarditis.",
    ["تیفوئید می‌تواند ظرف چند روز به سفالوسپورین پاسخ دهد.",
     "پاسخ صحیح — تب IE در ۴۸ ساعت کامل قطع نمی‌شود و برنمی‌گردد؛ وژتاسیون پناهگاه است.",
     "سپتی‌سمی بدون کانون دریچه‌ای می‌تواند سریع بی‌تب شود.",
     "مننژیت باکتریایی درمان‌شده در همین بازه آرام می‌شود."],
    ["Typhoid can respond to a cephalosporin within a few days.",
     "Correct — the fever of IE does not break completely in 48 hours and stay down; a vegetation is a sanctuary.",
     "Septicaemia without a valvular focus can defervesce quickly.",
     "Treated bacterial meningitis settles in the same window."],
    "**تب IE روزها می‌ماند. قطع ۴۸ساعته‌ی پایدار = تقریباً هر چیزی هست جز اندوکاردیت.**",
    "IE fever lasts days. A sustained 48-hour break means almost anything except endocarditis.",
    REFS_IE)

add("book:118", "vignette", "hard",
    "**یک کشت استاف + ۵ مینور = قطعی. درمان را برای اکو و کشت بیشتر معطل نکن.**",
    "One staphylococcal culture plus 5 minors is definite. Do not hold treatment for an echo or more cultures.",
    DUKE_FA + [
        "VSD = زمینه. تب ۳۹ = تب. جین‌وی بی‌درد = عروقی. RF+ = ایمونولوژیک. یک کشت استاف = مینور میکروبی.",
        "پنج مینور = تشخیص قطعی؛ ماژور لازم نیست.",
        "اختلال هوشیاری یعنی آمبولی مغز؛ سی‌تی لازم است ولی درمان را عقب نمی‌اندازد.",
        "یک کشت استاف را ماژور حساب نکنید — همین‌جا نیازی هم نیست.",
    ],
    DUKE_EN + [
        "VSD is predisposition. Fever of 39 is fever. Painless Janeway is vascular. RF+ is immunologic. One S. aureus culture is a microbiologic minor.",
        "Five minors is definite; no major is required.",
        "Altered consciousness means a cerebral embolus; a CT is needed but must not delay treatment.",
        "Do not promote a single staphylococcal culture to a major — you do not need to here.",
    ],
    "۱۸ ساله با VSD، تب ۳۹، اختلال هوشیاری، سوفل ۴/۶، ضایعه‌ی بی‌درد کف دست و پا (جین‌وی)، لکوسیتوز، **RF مثبت** و **یک نوبت کشت استاف اورئوس**. اقدام؟\n\n"
    "مینورها را سبد به سبد بشمارید:\n"
    "۱. زمینه (VSD)\n"
    "۲. تب\n"
    "۳. عروقی (جین‌وی)\n"
    "۴. ایمونولوژیک (RF)\n"
    "۵. میکروبیولوژیک (یک کشت استاف — به ماژور نرسیده)\n\n"
    "⚠️ **۵ مینور = اندوکاردیت قطعی.** دیگر لازم نیست برای ماژور صبر کنید. درمان را همین حالا شروع کنید.\n\n"
    "اکو و کشت‌های بیشتر را **هم‌زمان** بگیرید، ولی تصمیم را به آن‌ها گره نزنید. سی‌تی مغز برای آمبولی لازم است اما آنتی‌بیوتیک را عقب نمی‌اندازد. سوفل ۴/۶ به نفع درگیری است ولی بدون اکو هنوز ماژور «نارسایی جدید» ثابت نشده — و لازم هم نیست.",
    "An 18-year-old with a VSD, fever of 39, altered consciousness, a 4/6 murmur, painless palmo-plantar lesions (Janeway), leucocytosis, a POSITIVE RF and a SINGLE S. AUREUS CULTURE. What next?\n\n"
    "Count the minors basket by basket:\n"
    "1. Predisposition (VSD)\n"
    "2. Fever\n"
    "3. Vascular (Janeway)\n"
    "4. Immunologic (RF)\n"
    "5. Microbiologic (one S. aureus culture — short of a major)\n\n"
    "WARNING: 5 MINORS IS DEFINITE ENDOCARDITIS. You no longer need to wait for a major. Start treatment now.\n\n"
    "Obtain an echo and further cultures IN PARALLEL, but do not hitch the decision to them. A brain CT is needed for the embolus but must not delay antibiotics. The 4/6 murmur favours involvement but without an echo the 'new regurgitation' major is not yet proved — and it does not need to be.",
    ["اکو را هم‌زمان بگیرید ولی درمان قطعی را برای آن معطل نکنید.",
     "کشت بیشتر مفید است ولی با ۵ مینور دیگر برای تشخیص لازم نیست.",
     "سی‌تی مغز آمبولی را نشان می‌دهد؛ درمان را عقب نمی‌اندازد.",
     "پاسخ صحیح — پنج مینور یعنی تشخیص قطعی؛ درمان اندوکاردیت را شروع کنید."],
    ["Obtain the echo in parallel, but do not hold definite treatment for it.",
     "More cultures are useful but with 5 minors they are no longer needed for the diagnosis.",
     "A brain CT shows the embolus; it must not delay treatment.",
     "Correct — five minors means a definite diagnosis; start endocarditis treatment."],
    "**۵ مینور = قطعی.** یک کشت استاف را ماژور نکن؛ لازم هم نداری.",
    "5 minors is definite. Do not promote a single staphylococcal culture to a major; you do not need to.",
    REFS_IE)

# =========================================================== prophylaxis
add("book:125", "vignette", "medium",
    "**برونکوسکوپی — حتی Rigid — پروفیلاکسی اندوکاردیت نمی‌خواهد.**",
    "Bronchoscopy — even rigid — does not need endocarditis prophylaxis.",
    PROPH_FA,
    PROPH_EN,
    "خانم جوان با هموپتزی کاندید **برونکوسکوپی Rigid** است. دو سال پیش IE درمان‌شده داشته.\n\n"
    "دو شرط را جدا چک کنید:\n\n"
    "**قلب:** IE قبلی = پرخطر. شرط اول برقرار است.\n\n"
    "⚠️ **اقدام:** برونکوسکوپی — حتی نوع Rigid — در راهنمای AHA **اقدام واجد شرایط نیست**، مگر مخاط را برش دهید. هموپتزی به‌معنای بیوپسی نیست.\n\n"
    "پس شرط دوم برقرار نیست و **پروفیلاکسی لازم نیست.** آموکسی‌سیلین، کلیندامایسین و آمپی‌سیلین+جنتامایسین همه رژیم‌های واقعی‌اند که این‌جا اندیکاسیون ندارند. مصرف بی‌جایشان فقط مقاومت و واکنش دارویی می‌سازد.",
    "A young woman with haemoptysis is listed for RIGID BRONCHOSCOPY. She had treated IE two years ago.\n\n"
    "Check the two conditions separately:\n\n"
    "THE HEART: previous IE = high-risk. First condition met.\n\n"
    "WARNING, THE PROCEDURE: bronchoscopy — even the rigid kind — is NOT a qualifying procedure in the AHA guideline, unless mucosa is incised. Haemoptysis does not mean a biopsy.\n\n"
    "So the second condition is not met and NO PROPHYLAXIS IS NEEDED. Amoxicillin, clindamycin and ampicillin-plus-gentamicin are all real regimens that have no indication here. Using them anyway only breeds resistance and drug reactions.",
    ["آموکسی‌سیلین رژیم درست دندانی است، ولی برونکوسکوپی دندان‌پزشکی نیست.",
     "کلیندامایسین برای حساسیت پنی‌سیلین در کار دندانی است، نه برای برونکوسکوپی.",
     "آمپی‌سیلین و جنتامایسین رژیم قدیمی گوارشی است و دیگر توصیه نمی‌شود.",
     "پاسخ صحیح — برونکوسکوپی پروفیلاکسی نمی‌خواهد، حتی با سابقه‌ی IE."],
    ["Amoxicillin is the right dental regimen, but bronchoscopy is not dental work.",
     "Clindamycin is for penicillin allergy in dental work, not for bronchoscopy.",
     "Ampicillin plus gentamicin is an obsolete gastrointestinal regimen and is no longer recommended.",
     "Correct — bronchoscopy does not need prophylaxis, even with previous IE."],
    "**قلب پرخطر کافی نیست؛ اقدام هم باید دندانیِ مخاط‌دار باشد.** برونکوسکوپی نه.",
    "A high-risk heart is not enough; the procedure must also be qualifying dental work. Bronchoscopy is not.",
    REFS_PR)

add("book:130", "vignette", "medium",
    "**VSD ناقص‌ترمیم + درناژ آبسه‌ی دندان + حساسیت فوری ← کلیندامایسین.**",
    "An incompletely repaired VSD plus drainage of a dental abscess plus immediate allergy: clindamycin.",
    PROPH_FA,
    PROPH_EN,
    "پسر ۱۰ ساله، جراحی VSD سه ماه پیش که **ناقص ترمیم شده**، کاندید **درناژ آبسه‌ی دندانی**، با **حساسیت فوری به پنی‌سیلین**.\n\n"
    "هر دو شرط برقرار است:\n"
    "- قلب: شانت باقی‌مانده پس از ترمیم CHD = پرخطر (و تازه سه ماه از جراحی گذشته، حتی ترمیم کامل هم تا ۶ ماه پرخطر است).\n"
    "- اقدام: درناژ آبسه‌ی دندان = دست‌کاری مخاط/پری‌آپیکال.\n\n"
    "⚠️ **حساسیت فوری یعنی آنافیلاکسی یا کهیر فوری — سفالکسین ممنوع است** چون واکنش متقاطع واقعی است. کلیندامایسین خوراکی انتخاب استاندارد امتحانی است. (AHA ۲۰۲۱ کلیندامایسین را به‌خاطر Clostridioides difficile کنار گذاشته و آزیترومایسین یا داکسی‌سیکلین را ترجیح می‌دهد؛ در کلید این کتاب هنوز کلیندامایسین است.)\n\n"
    "وانکومایسین جایگزین وریدی است نه خط اول. «نیاز ندارد» هر دو شرط را نادیده می‌گیرد.",
    "A 10-year-old boy, VSD surgery three months ago that was INCOMPLETELY REPAIRED, listed for DRAINAGE OF A DENTAL ABSCESS, with IMMEDIATE PENICILLIN ALLERGY.\n\n"
    "Both conditions are met:\n"
    "- Heart: a residual shunt after CHD repair is high-risk (and it is only three months since surgery, so even a complete repair would still be high-risk until 6 months).\n"
    "- Procedure: drainage of a dental abscess = gingival / periapical work.\n\n"
    "WARNING: IMMEDIATE ALLERGY MEANS ANAPHYLAXIS OR IMMEDIATE URTICARIA — CEPHALEXIN IS FORBIDDEN because cross-reactivity is real. Oral clindamycin is the standard examination choice. (AHA 2021 dropped clindamycin because of Clostridioides difficile and prefers azithromycin or doxycycline; this book's key is still clindamycin.)\n\n"
    "Vancomycin is the intravenous alternative, not first-line. 'Not needed' ignores both conditions.",
    ["پاسخ صحیح — شانت باقی‌مانده + کار دندانی + حساسیت فوری = کلیندامایسین.",
     "وانکومایسین جایگزین وریدی است، نه خط اول خوراکی.",
     "سفالکسین در حساسیت فوری به پنی‌سیلین ممنوع است.",
     "نقص باقی‌مانده پرخطر است و درناژ آبسه کار دندانی واجد شرایط است."],
    ["Correct — residual shunt plus dental work plus immediate allergy means clindamycin.",
     "Vancomycin is the intravenous alternative, not first-line oral therapy.",
     "Cephalexin is forbidden in immediate penicillin allergy.",
     "A residual defect is high-risk and drainage of an abscess is qualifying dental work."],
    "**حساسیت فوری + کار دندانی = کلیندامایسین. سفالکسین را در آنافیلاکسی فراموش کن.**",
    "Immediate allergy plus dental work means clindamycin. Forget cephalexin in anaphylaxis.",
    REFS_PR)

add("book:131", "vignette", "easy",
    "**دریچه‌ی مصنوعی + جراحی لثه + حساسیت فوری ← باز هم کلیندامایسین.**",
    "A prosthetic valve plus gingival surgery plus immediate allergy: clindamycin again.",
    PROPH_FA,
    PROPH_EN,
    "خانم ۳۰ ساله با **دریچه‌ی مصنوعی**، کاندید **جراحی لثه**، حساسیت فوری به پنی‌سیلین.\n\n"
    "این ساده‌ترین شکل همان قاعده است:\n"
    "- دریچه‌ی مصنوعی = پرخطرترین قلب ممکن\n"
    "- جراحی لثه = دقیق‌ترین مصداق کار دندانی واجد شرایط\n"
    "- حساسیت فوری = سفالکسین حذف، کلیندامایسین انتخاب\n\n"
    "سیپروفلوکساسین رژیم پروفیلاکسی دندانی نیست (برای برخی اقدامات گوارشی قدیمی مطرح بوده و امروز هم توصیه نمی‌شود). «نیاز ندارد» هر دو شرط روشن را نادیده می‌گیرد.",
    "A 30-year-old woman with a PROSTHETIC VALVE, listed for GINGIVAL SURGERY, with immediate penicillin allergy.\n\n"
    "This is the simplest form of the same rule:\n"
    "- A prosthetic valve = the highest-risk heart there is\n"
    "- Gingival surgery = the cleanest example of qualifying dental work\n"
    "- Immediate allergy = drop cephalexin, choose clindamycin\n\n"
    "Ciprofloxacin is not a dental-prophylaxis regimen (it featured in older gastrointestinal protocols and is not recommended now either). 'Not needed' ignores two obvious conditions.",
    ["سفالکسین در حساسیت فوری به پنی‌سیلین ممنوع است.",
     "سیپروفلوکساسین رژیم پروفیلاکسی دندانی نیست.",
     "پاسخ صحیح — دریچه‌ی مصنوعی + جراحی لثه + حساسیت فوری = کلیندامایسین.",
     "هر دو شرط پروفیلاکسی برقرار است؛ حذف آن خطا است."],
    ["Cephalexin is forbidden in immediate penicillin allergy.",
     "Ciprofloxacin is not a dental-prophylaxis regimen.",
     "Correct — prosthetic valve plus gingival surgery plus immediate allergy means clindamycin.",
     "Both conditions for prophylaxis are met; omitting it is an error."],
    "**دریچه‌ی مصنوعی + لثه = همیشه پروفیلاکسی.** حساسیت فوری مسیر دارو را عوض می‌کند، نه اصل را.",
    "A prosthetic valve plus gingiva always means prophylaxis. Immediate allergy changes the drug, not the principle.",
    REFS_PR)

json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book58.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 58 lessons:', len(L))
