# -*- coding: utf-8 -*-
"""Correct two meningococcal-prophylaxis keys.

q9197 — pregnant classroom teacher: printed ciprofloxacin. She is not a close
contact, and cipro is not preferred in pregnancy (CDC wants ceftriaxone, which
is not listed). Correct to 'no specific action'.

q9203 — isolation plus roommate PEP: printed 'no isolation + azithromycin'.
Meningococcus needs droplet isolation for 24 h; roommates get rifampicin.
Correct to large-droplet isolation + rifampicin.
"""
import json, io, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
CORRECTIONS = {
    9197: {
        'match': lambda t: 'نیاز' in t and 'اقدام' in t,
        'fa': ('کلید چاپی سیپروفلوکساسین است. معلم کلاس بدون تماس با ترشحات اوروفارنکس '
               'تماس نزدیک CDC نیست، و سیپروفلوکساسین در بارداری ارجح نیست (سفتریاکسون ارجح است '
               'و در گزینه‌ها نیست). بنابراین «نیاز به اقدام خاصی نیست» درست است.'),
        'en': ("The printed key is ciprofloxacin. A classroom teacher without oropharyngeal "
               "secretions is not a CDC close contact, and ciprofloxacin is not preferred in "
               "pregnancy (ceftriaxone is, and is not listed). So 'no specific action' is right."),
        'src': 'CDC meningococcal chemoprophylaxis; Harrison 21 — meningococcal disease',
    },
    9203: {
        'match': lambda t: 'درشت' in t and 'ریفامپین' in t,
        'fa': ('کلید چاپی «نیازی به ایزولاسیون ندارد + آزیترومایسین» است. مننگوکوک تا ۲۴ ساعت '
               'پس از آنتی‌بیوتیک مؤثر ایزولاسیون قطره‌ای (قطرات درشت) می‌خواهد و هم‌اتاقی '
               'ریفامپین می‌گیرد.'),
        'en': ("The printed key is 'no isolation + azithromycin'. Meningococcus needs droplet "
               "(large-droplet) isolation for 24 hours after effective antibiotics, and a "
               "roommate receives rifampicin."),
        'src': 'CDC isolation precautions; Harrison 21 — meningococcal disease',
    },
}


def main():
    done = 0
    for i in range(1, 6):
        p = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        if not os.path.exists(p):
            continue
        body = json.load(io.open(p, encoding='utf-8'))
        changed = False
        for q in body['questions']:
            spec = CORRECTIONS.get(q.get('question_no'))
            if not spec:
                continue
            idx = None
            for j, o in enumerate(q['options_fa']):
                if spec['match'](re.sub(r'\s+', '', o)):
                    if idx is not None:
                        sys.exit(f'q{q["question_no"]}: ambiguous')
                    idx = j
            if idx is None:
                sys.exit(f'q{q["question_no"]}: no match {q["options_fa"]}')
            if q.get('key_corrected') and q['correct_index'] == idx:
                print(f'q{q["question_no"]}: already')
                continue
            q['original_correct_index'] = q['correct_index']
            q['correct_index'] = idx
            q['key_corrected'] = True
            q['key_correction_fa'] = spec['fa']
            q['key_correction_en'] = spec['en']
            q['key_correction_source'] = spec['src']
            changed = True
            done += 1
            print(f'q{q["question_no"]}: {q["original_correct_index"]} -> {idx}')
        if changed:
            json.dump(body, io.open(p, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)
    print('corrected', done)


if __name__ == '__main__':
    main()
