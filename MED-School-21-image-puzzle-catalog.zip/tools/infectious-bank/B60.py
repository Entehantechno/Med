# -*- coding: utf-8 -*-
"""Micro-lessons, batch 60 — remaining sepsis / febrile-patient items (31),
completing the chapter (44 of 44).

Four clusters:

  FEVER PATTERN AND FUO. Pel-Ebstein (Hodgkin) is days-on / days-off with a
  high LDH and a spleen. Aspirin is forbidden in a febrile child with a viral
  picture (Reye). Classical FUO does not require an abdominal CT to be named.

  CANDIDA. Cottage-cheese vaginitis is local (nystatin if the azole is
  forbidden). Thrush that scrapes off in an adult without a reason is HIV.
  Candiduria is colonisation until a mucosal-bleeding urologic procedure, or
  until the catheter comes out.

  ASPERGILLUS VERSUS MUCOR. Septate branching = aspergillus. Ribbon aseptate
  = mucor. A fungus ball in an old cavity is A. fumigatus. Invasive disease
  in neutropenia is voriconazole. Palatal necrosis in a transplant is mucor.

  OLD SEPSIS LADDER AND ASPLENIA. Hypotension that rises after a litre is
  severe sepsis, not shock. Unknown-source shock wants an anti-pseudomonal
  beta-lactam plus vancomycin. Asplenia wants cefotaxime/ceftriaxone plus
  vancomycin, and later the three encapsulated vaccines — not typhoid.

Reference: Harrison 21 — fever and FUO; candidiasis; aspergillosis; mucormycosis;
sepsis and septic shock.
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = "Harrison's Principles of Internal Medicine, 21st ed (2022)"
REFS_F = [f"{H} — fever, FUO and antipyretics"]
REFS_C = [f"{H} — candidiasis"]
REFS_A = [f"{H} — aspergillosis and mucormycosis"]
REFS_S = [f"{H} — sepsis, septic shock and asplenia"]

FEVER_FA = [
    "⚠️ **تب Pel-Ebstein = چند روز تب / چند روز بی‌تب، تکرارشونده → هوچکین تا خلافش ثابت شود.**",
    "اسپلنومگالی و LDH بالا همان لنفوم را محکم می‌کنند، نه یک عفونت ساده.",
    "FMF حمله‌های ۱۲ تا ۷۲ ساعته با سروzit است، نه ۳ تا ۱۰ روز کامل.",
    "تب راجعه (بورلیا) چرخه‌ی کوتاه‌تری دارد و LDH و طحال هوچکین را نمی‌سازد.",
    "فالسیپاروم تب پیوسته یا نامنظم می‌دهد، نه هفته‌های سلامتی تمیز.",
    "⚠️ **در کودک تب‌دار ویروسی (واریسلا یا آنفلوانزا) آسپیرین ممنوع است — سندرم رای.**",
    "استامینوفن و ایبوپروفن تب‌برهای مجاز کودک‌اند.",
    "**FUO کلاسیک:** تب >۳۸٫۳ بیش از ۳ هفته + یک هفته بررسی بدون تشخیص.",
    "اقدامات اولیه‌ی اجباری تعریف: شرح حال، معاینه، CBC، کشت خون، ESR؛ ANA گاهی.",
    "⚠️ **سی‌تی شکم و لگن جزو تعریف اولیه نیست** — تصویربرداری مرحله‌ی بعد است.",
]
FEVER_EN = [
    "WARNING: PEL-EBSTEIN FEVER = several days on / several days off, repeating → HODGKIN until proven otherwise.",
    "Splenomegaly and a high LDH lock in the lymphoma, not a simple infection.",
    "FMF attacks last 12 to 72 hours with serositis, not a full 3 to 10 days.",
    "Relapsing fever (Borrelia) has a shorter cycle and does not make Hodgkin's LDH and spleen.",
    "Falciparum gives continuous or irregular fever, not clean weeks of wellness.",
    "WARNING: IN A FEBRILE CHILD WITH A VIRAL PICTURE (varicella or influenza) ASPIRIN IS FORBIDDEN — REYE SYNDROME.",
    "Paracetamol and ibuprofen are the permitted paediatric antipyretics.",
    "CLASSICAL FUO: fever >38.3 for more than 3 weeks plus one week of investigation without a diagnosis.",
    "The definition's obligatory first steps: history, examination, CBC, blood cultures, ESR; ANA sometimes.",
    "WARNING: ABDOMINAL AND PELVIC CT IS NOT PART OF THE INITIAL DEFINITION — imaging is the next stage.",
]

CAND_FA = [
    "⚠️ **ترشح پنیری چسبنده + خارش = کاندیدای واژن.**",
    "زمینه‌ها: آنتی‌بیوتیک، دیابت، بارداری، استروئید، HIV — نه آنتی‌سایکوتیک به‌تنهایی.",
    "واژینیت موضعی است: اگر آزول ممنوع بود **نیستاتین موضعی** کافی است.",
    "اکینوکاندین و آمفوتریسین مال بیماری تهاجمی‌اند، نه خارش واژن.",
    "⚠️ **ازوفاژیت کاندیدایی در لوسمی سیستمیک است: اگر آزول نرود، کاسپوفونژین.**",
    "نیستاتین ازوفاژیت را درمان نمی‌کند چون به مخاط عمقی نمی‌رسد.",
    "⚠️ **برفک دهان بالغ بدون دلیل = HIV تا خلافش ثابت شود.**",
    "پلاک سفید که با آبسلانگ کنده می‌شود کاندیداست؛ دیفتری می‌چسبد و خونریزی می‌دهد.",
    "کاندیدوری سوند = کلونیزاسیون. سوند را درآور و کشت را تکرار کن — مگر عمل مخاط‌دار در پیش باشد.",
    "پیش از TURP یا بیوپسی، کاندیدوری را با فلوکونازول خوراکی پاک کنید.",
]
CAND_EN = [
    "WARNING: COTTAGE-CHEESE STICKY DISCHARGE PLUS ITCH IS VAGINAL CANDIDA.",
    "The settings: antibiotics, diabetes, pregnancy, steroids, HIV — not an antipsychotic on its own.",
    "Vaginitis is local: if an azole is forbidden, TOPICAL NYSTATIN is enough.",
    "An echinocandin and amphotericin belong to invasive disease, not to vaginal itch.",
    "WARNING: CANDIDA OESOPHAGITIS IN LEUKAEMIA IS SYSTEMIC: if the azole cannot be used, CASPOFUNGIN.",
    "Nystatin does not treat oesophagitis because it does not reach deep mucosa.",
    "WARNING: ORAL THRUSH IN AN ADULT WITH NO REASON IS HIV UNTIL PROVEN OTHERWISE.",
    "A white plaque that scrapes off with a tongue depressor is candida; diphtheria sticks and bleeds.",
    "Catheter candiduria is colonisation. Take the catheter out and repeat the culture — unless a mucosal procedure is planned.",
    "Before a TURP or a biopsy, clear candiduria with oral fluconazole.",
]

ASP_FA = [
    "⚠️ **هایفای باریک سپتات منشعب = آسپرژیلوس. رibbon پهن بدون دیواره = موکور.**",
    "کاندیدا مخمر و سودوهایف است، نه mold سپتات.",
    "**توپ قارچی در حفره‌ی قدیمی (سل، سارکوئید، جراحی) = آسپرژیلوما، معمولاً A. fumigatus.**",
    "تظاهر کلاسیک آسپرژیلوما هموپتزی است، نه تب و کاهش وزن.",
    "⚠️ **تب + کاهش وزن + حفره‌های متعدد در COPD یا پس از حفره = آسپرژیلوز ریوی مزمن.**",
    "آسپرژیلوز مهاجم مال نوتروپنی حاد است، نه ماه‌ها سرفه در COPD.",
    "ABPA = آسم یا CF + خلط قهوه‌ای + ائوزینوفیلی + IgE خیلی بالا؛ غربال با skin prick.",
    "گالاکتومانان + هایفای سپتات در نوتروپن = مهاجم؛ خط اول **وریکونازول**.",
    "فلوکونازول روی آسپرژیلوس اثر ندارد.",
    "⚠️ **نکروز سقف دهان + پروپتوز + پیوند یا دیابت = موکور** تا خلافش ثابت شود.",
    "شایع‌ترین عضو خارج ریوی آسپرژیلوز منتشر، **مغز** است.",
]
ASP_EN = [
    "WARNING: THIN SEPTATE BRANCHING HYPHAE = ASPERGILLUS. A WIDE ASEPTATE RIBBON = MUCOR.",
    "Candida is a yeast with pseudohyphae, not a septate mould.",
    "A FUNGUS BALL IN AN OLD CAVITY (TB, sarcoid, surgery) IS AN ASPERGILLOMA, usually A. fumigatus.",
    "The classical presentation of an aspergilloma is haemoptysis, not fever and weight loss.",
    "WARNING: FEVER + WEIGHT LOSS + MULTIPLE CAVITIES IN COPD OR AFTER A CAVITY = CHRONIC PULMONARY ASPERGILLOSIS.",
    "Invasive aspergillosis belongs to acute neutropenia, not to months of cough in COPD.",
    "ABPA = asthma or CF + brownish plugs + eosinophilia + a very high IgE; screen with a skin-prick test.",
    "Galactomannan plus septate hyphae in a neutropenic = invasive disease; first line VORICONAZOLE.",
    "Fluconazole has no activity against Aspergillus.",
    "WARNING: PALATAL NECROSIS + PROPTOSIS + A TRANSPLANT OR DIABETES = MUCOR until proven otherwise.",
    "The commonest extrapulmonary organ in disseminated aspergillosis is THE BRAIN.",
]

SEP_FA = [
    "⚠️ **نردبان قدیمی امتحان: SIRS → سپسیس → سپسیس شدید → شوک سپتیک.**",
    "SIRS: دو تا از تب/هیپوترمی، تاکی‌کاردی، تاکی‌پنه، لکوسیتوز/لکوپنی.",
    "سپسیس = SIRS + عفونت. سپسیس شدید = سپسیس + اختلال عضو **یا افت فشاری که به مایع جواب می‌دهد**.",
    "⚠️ **شوک سپتیک = افت فشار که پس از مایع کافی نمی‌آید و وازوپرسور می‌خواهد.**",
    "منبع نامعلوم بدحال: ضدپسودومونا (سفپیم یا پیپ-تازو یا کارباپنم) + وانکومایسین.",
    "سفتریاکسون پسودومونا را نمی‌پوشاند؛ سفازولین MRSA و پسودومونا را نه.",
    "⚠️ **بی‌طحالی = پاتوژن کپسول‌دار: پنوموکوک، هموفیلوس، مننگوکوک.**",
    "رژیم فوری OPSI: سفتریاکسون یا سفوتاکسیم + وانکومایسین (پنوموکوک مقاوم).",
    "واکسن بی‌طحالی: پنوموکوک، Hib، مننگوکوک — **نه سالمونلا تیفی** مگر سفر.",
    "استاف اپیدرمیدیس کپسول‌دار OPSI نیست.",
    "زودترین ABG سپسیس آلکالوز تنفسی است (هیپرونتیلاسیون)؛ بعد اسیدوز لاکتیک می‌آید.",
]
SEP_EN = [
    "WARNING: THE OLD EXAMINATION LADDER: SIRS → sepsis → severe sepsis → septic shock.",
    "SIRS: two of fever/hypothermia, tachycardia, tachypnoea, leucocytosis/leucopenia.",
    "Sepsis = SIRS + infection. Severe sepsis = sepsis + organ dysfunction OR hypotension that ANSWERS TO FLUID.",
    "WARNING: SEPTIC SHOCK = HYPOTENSION THAT DOES NOT RISE AFTER ADEQUATE FLUID AND NEEDS A VASOPRESSOR.",
    "A sick unknown source: an anti-pseudomonal (cefepime or pip-tazo or a carbapenem) plus vancomycin.",
    "Ceftriaxone does not cover Pseudomonas; cefazolin covers neither MRSA nor Pseudomonas.",
    "WARNING: ASPLENIA = THE ENCAPSULATED PATHOGENS: pneumococcus, Haemophilus, meningococcus.",
    "The immediate OPSI regimen: ceftriaxone or cefotaxime plus vancomycin (resistant pneumococcus).",
    "Asplenia vaccines: pneumococcus, Hib, meningococcus — NOT Salmonella Typhi unless travelling.",
    "S. epidermidis is not an encapsulated OPSI organism.",
    "The earliest ABG of sepsis is respiratory alkalosis (hyperventilation); lactic acidosis comes next.",
]


def dump():
    json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                      'lessons_book60.json'), 'w', encoding='utf-8'),
              ensure_ascii=False, indent=1)
    print('batch 60 lessons:', len(L))


# ---- fever / FUO
add("book:1", "vignette", "medium",
    "**چند روز تب / چند روز سلامتی + طحال + LDH بالا = تب Pel-Ebstein هوچکین.**",
    "Days of fever / days of wellness plus a spleen plus a high LDH is Hodgkin's Pel-Ebstein fever.",
    FEVER_FA, FEVER_EN,
    "زن ۳۸ ساله با چرخه‌ی ۳ تا ۱۰ روز تب و ۳ تا ۱۰ روز بی‌تب، اسپلنومگالی و LDH بالا.\n\n"
    "این الگوی Pel-Ebstein است و در امتحان تا خلافش ثابت شود **لنفوم هوچکین** است. LDH مارکر تخریب سلولی لنفوم است و طحال همان غده‌ی درگیر.\n\n"
    "FMF حمله‌های چند ساعته تا حداکثر سه روز با درد سروzit می‌دهد، نه ده روز تب کامل. تب راجعه بورلیایی چرخه‌ی کوتاه‌تری دارد و این LDH را نمی‌سازد. فالسیپاروم بیمار را بین حمله‌ها این‌قدر سالم تحویل نمی‌دهد.",
    "A 38-year-old woman with a cycle of 3 to 10 days of fever and 3 to 10 days off, splenomegaly and a high LDH.\n\n"
    "This is the Pel-Ebstein pattern and in the exam is HODGKIN LYMPHOMA until proven otherwise. LDH is a marker of lymphoma cell turnover and the spleen is the involved node.\n\n"
    "FMF gives attacks of a few hours to at most three days with serositis, not ten full days of fever. Borrelial relapsing fever has a shorter cycle and does not make this LDH. Falciparum does not hand the patient back this well between paroxysms.",
    ["پاسخ صحیح — تب Pel-Ebstein به‌همراه طحال و LDH الگوی هوچکین است.",
     "FMF حمله‌ی کوتاه با سروzit است، نه چرخه‌ی ۳ تا ۱۰ روزه با LDH بالا.",
     "تب راجعه بورلیایی چرخه‌ی کوتاه‌تری دارد و این تصویر لنفوم را نمی‌سازد.",
     "فالسیپاروم تب پیوسته یا نامنظم می‌دهد، نه هفته‌های سلامتی تمیز."],
    ["Correct — Pel-Ebstein fever with a spleen and a high LDH is the Hodgkin pattern.",
     "FMF is a short attack with serositis, not a 3-to-10-day cycle with a high LDH.",
     "Borrelial relapsing fever has a shorter cycle and does not make this lymphoma picture.",
     "Falciparum gives continuous or irregular fever, not clean weeks of wellness."],
    "**چرخه‌ی چندروزه + LDH + طحال = هوچکین.** عفونت را این‌قدر مرتب زمان‌بندی نمی‌کند.",
    "A several-day cycle plus LDH plus a spleen is Hodgkin. Infection does not time itself this neatly.",
    REFS_F)

add("book:3", "vignette", "easy",
    "**کودک تب‌دار با وزیکول منتشر: هر تب‌بری بده جز آسپیرین — رای.**",
    "A febrile child with scattered vesicles: give any antipyretic except aspirin — Reye.",
    FEVER_FA, FEVER_EN,
    "کودک ۸ ساله، تب ۳۹، راش ماکولوپاپولر و وزیکول منتشر، سابقه‌ی تشنج. تب‌برها به‌جز؟\n\n"
    "تابلو واریسلا است. ⚠️ **آسپیرین در کودک با بیماری ویروسی — به‌ویژه واریسلا و آنفلوانزا — سندرم رای می‌سازد** (آنسفالوپاتی + نارسایی کبد). ایبوپروفن، دیکلوفناک و پاراستامول تب را پایین می‌آورند بدون آن خطر.",
    "An 8-year-old, fever 39, a maculopapular rash and scattered vesicles, a history of seizure. Which antipyretic is out?\n\n"
    "The picture is varicella. WARNING: ASPIRIN IN A CHILD WITH A VIRAL ILLNESS — ESPECIALLY VARICELLA AND INFLUENZA — CAUSES REYE SYNDROME (encephalopathy plus liver failure). Ibuprofen, diclofenac and paracetamol bring the fever down without that risk.",
    ["ایبوپروفن تب‌بر مجاز کودک است.",
     "دیکلوفناک هم NSAID مجازی است و رای نمی‌سازد.",
     "پاسخ صحیح — آسپیرین در واریسلا و آنفلوانزای کودک سندرم رای می‌سازد.",
     "پاراستامول (استامینوفن) خط اول تب کودک است."],
    ["Ibuprofen is a permitted paediatric antipyretic.",
     "Diclofenac is also a permitted NSAID and does not cause Reye.",
     "Correct — aspirin in childhood varicella and influenza causes Reye syndrome.",
     "Paracetamol (acetaminophen) is first-line for childhood fever."],
    "**کودک + ویروس + آسپیرین = رای.** استامینوفن بده.",
    "A child plus a virus plus aspirin is Reye. Give paracetamol.",
    REFS_F)

add("book:4", "vignette", "easy",
    "**شروع ناگهانی تب و بدن‌درد و سرفه در کودک = آنفلوانزا. باز هم نه آسپیرین.**",
    "Sudden fever, myalgia and cough in a child is influenza. Again, no aspirin.",
    FEVER_FA, FEVER_EN,
    "کودک ۱۰ ساله، تب ۳۹ از بعدازظهر دیروز، بدن‌درد، سرفه، گلودرد ناگهانی. همه‌ی داروها به‌جز آسپیرین.\n\n"
    "شروع ناگهانی همان امضای آنفلوانزا است. دکسترومتورفان سرفه را کم می‌کند، استامینوفن و ایبوپروفن تب را. آسپیرین همان رای را می‌سازد.",
    "A 10-year-old, fever 39 since yesterday afternoon, myalgia, cough, sudden sore throat. Every drug except aspirin.\n\n"
    "The sudden start is the signature of influenza. Dextromethorphan eases the cough, paracetamol and ibuprofen the fever. Aspirin makes the same Reye.",
    ["استامینوفن تب‌بر مجاز است.",
     "دکسترومتورفان ضدسرفه علامتی آنفلوانزا است.",
     "پاسخ صحیح — آسپیرین در آنفلوانزای کودک سندرم رای می‌سازد.",
     "ایبوپروفن تب‌بر مجاز است."],
    ["Paracetamol is a permitted antipyretic.",
     "Dextromethorphan is a symptomatic cough suppressant in influenza.",
     "Correct — aspirin in childhood influenza causes Reye syndrome.",
     "Ibuprofen is a permitted antipyretic."],
    "**شروع ناگهانی در کودک = آنفلوانزا تا خلافش ثابت شود. آسپیرین خط قرمز است.**",
    "A sudden start in a child is influenza until proven otherwise. Aspirin is the red line.",
    REFS_F)

add("book:6", "recall", "medium",
    "**سی‌تی شکم جزو تعریف اولیه‌ی FUO نیست — کشت خون و ESR هستند.**",
    "An abdominal CT is not part of the initial definition of FUO — blood cultures and an ESR are.",
    FEVER_FA, FEVER_EN,
    "کدام اقدام جزو اقدامات اولیه‌ی اجباری تعریف FUO نیست؟\n\n"
    "تعریف کلاسیک Petersdorf: تب بیش از ۳۸٫۳ به‌مدت بیش از ۳ هفته که یک هفته بررسی اولیه تشخیص نداده. آن بررسی اولیه CBC، اسمیر، کشت خون، ادرار، ESR و گاهی ANA و CXR است.\n\n"
    "سی‌تی شکم و لگن ابزار مرحله‌ی دوم است — وقتی شرح حال، معاینه و آزمایش‌های پایه خالی ماندند. بدون آن‌ها هم می‌توان بیمار را FUO نامید.",
    "Which step is NOT among the obligatory first steps of the FUO definition?\n\n"
    "The classical Petersdorf definition: fever above 38.3 for more than 3 weeks that one week of initial investigation has not diagnosed. That initial investigation is a CBC, a smear, blood cultures, urine, an ESR and sometimes an ANA and a CXR.\n\n"
    "Abdominal and pelvic CT is a second-stage tool — when history, examination and the basic tests have come up empty. The patient can still be named FUO without it.",
    ["کشت خون جزو حداقل تعریف است.",
     "ESR جزو غربال اولیه‌ی FUO است.",
     "ANA در بسیاری از پروتکل‌های اولیه هست.",
     "پاسخ صحیح — سی‌تی شکم و لگن تصویربرداری مرحله‌ی بعد است، نه جزء تعریف."],
    ["Blood cultures are part of the definitional minimum.",
     "An ESR is part of the initial FUO screen.",
     "An ANA is in many initial protocols.",
     "Correct — abdominal and pelvic CT is next-stage imaging, not part of the definition."],
    "**FUO را با شرح حال و کشت می‌سازی، نه با سی‌تی.** سی‌تی قدم بعدی است.",
    "You make FUO with a history and cultures, not with a CT. The CT is the next step.",
    REFS_F)

add("book:7", "vignette", "medium",
    "**FUO با معاینه خالی: اول سونوی شکم — ارزان‌ترین نگاه به آبسه و طحال.**",
    "FUO with an empty examination: abdominal ultrasound first — the cheapest look at an abscess and the spleen.",
    FEVER_FA, FEVER_EN,
    "مرد ۳۵ ساله، ۴ هفته تب تأییدشده، معاینه خالی. بین اکو، سی‌تی قفسه، آندوسکوپی فوقانی و سونوی شکم، کدام مقدم است؟\n\n"
    "بدون سوفل و بدون IDU اکو اولویت ندارد. بدون علامت تنفسی سی‌تی قفسه زود است. آندوسکوپی کاملاً بی‌نشانه است.\n\n"
    "سونوی شکم آبسه، لنفادنوپاتی، کبد و طحال را بدون اشعه و ارزان می‌بیند و در الگوریتم FUO معمولاً نخستین تصویر است.",
    "A 35-year-old man, 4 weeks of documented fever, an empty examination. Between an echo, a chest CT, an upper endoscopy and an abdominal ultrasound, which comes first?\n\n"
    "With no murmur and no IDU an echo is not the priority. With no respiratory symptom a chest CT is early. Endoscopy is entirely unprompted.\n\n"
    "Abdominal ultrasound sees an abscess, lymphadenopathy, the liver and the spleen without radiation and cheaply, and is usually the first image in an FUO algorithm.",
    ["اکو وقتی سوفل، IDU یا پدیده‌ی محیطی باشد مقدم است.",
     "سی‌تی قفسه با علامت تنفسی یا CXR غیرطبیعی می‌آید.",
     "آندوسکوپی بدون علامت گوارشی جای این مرحله نیست.",
     "پاسخ صحیح — سونوی شکم ارزان‌ترین و مقدم‌ترین تصویر FUO با معاینه خالی است."],
    ["An echo comes first when there is a murmur, IDU or a peripheral phenomenon.",
     "A chest CT comes with a respiratory symptom or an abnormal CXR.",
     "Endoscopy has no place at this stage without a gastrointestinal symptom.",
     "Correct — abdominal ultrasound is the cheapest and earliest image in FUO with an empty examination."],
    "**در FUO از ارزان و بی‌اشعه شروع کن.** سونو شکم پیش از اکو و سی‌تی.",
    "In FUO start cheap and without radiation. Abdominal ultrasound before an echo and a CT.",
    REFS_F)

# ---- candida
add("book:711", "vignette", "easy",
    "**ترشح پنیری: آنتی‌بیوتیک و دیابت و HIV زمینه‌اند — آنتی‌سایکوتیک نه.**",
    "Cottage-cheese discharge: antibiotics, diabetes and HIV are settings — an antipsychotic is not.",
    CAND_FA, CAND_EN,
    "ترشح سفید غلیظ چسبنده‌ی پنیری = کاندیدای واژن. زمینه‌های کلاسیک فلور را به‌هم می‌زنند یا ایمنی مخاط را: آنتی‌بیوتیک، دیابت، HIV، بارداری، استروئید.\n\n"
    "آنتی‌سایکوتیک به‌تنهایی هیچ‌کدام را نمی‌کند (مگر با دیابت ناشی از دارو، که صورت سؤال آن را جدا نیاورده).",
    "A thick sticky cottage-cheese white discharge is vaginal candida. The classical settings disturb flora or mucosal immunity: antibiotics, diabetes, HIV, pregnancy, steroids.\n\n"
    "An antipsychotic on its own does none of those (unless it has caused diabetes, which the stem has not listed separately).",
    ["آنتی‌بیوتیک فلور واژن را می‌کشد و کاندیدا جا باز می‌کند.",
     "پاسخ صحیح — آنتی‌سایکوتیک به‌تنهایی زمینه‌ساز کاندیدای واژن نیست.",
     "دیابت قند مخاط را بالا می‌برد و کاندیدا رشد می‌کند.",
     "HIV ایمنی مخاطی را می‌شکند."],
    ["Antibiotics kill vaginal flora and candida takes the space.",
     "Correct — an antipsychotic on its own is not a setting for vaginal candida.",
     "Diabetes raises mucosal glucose and candida grows.",
     "HIV breaks mucosal immunity."],
    "**پنیر واژن = کاندیدا.** زمینه‌اش آنتی‌بیوتیک و قند و HIV است، نه روان‌پزشکی.",
    "Vaginal cheese is candida. Its settings are antibiotics, sugar and HIV, not psychiatry.",
    REFS_C)

add("book:712", "vignette", "easy",
    "**واژینیت کاندیدایی + حساسیت آزول = نیستاتین موضعی، نه آمفوتریسین.**",
    "Candida vaginitis plus azole allergy is topical nystatin, not amphotericin.",
    CAND_FA, CAND_EN,
    "زن ۳۰ ساله، ترشح پنیری، حساسیت شدید به آزول‌ها. نیستاتین پلی‌ان موضعی است و به خون نمی‌رسد — برای واژینیت کافی و بی‌خطر است.\n\n"
    "فلوسیتوزین هرگز تک‌دارو نیست. میکورونژین/مایکافونژین IV برای تهاجمی است. آمفوتریسین سمّی و سیستمیک است.",
    "A 30-year-old woman, cottage-cheese discharge, severe azole allergy. Nystatin is a topical polyene that does not reach the blood — enough and safe for vaginitis.\n\n"
    "Flucytosine is never monotherapy. Micafungin is intravenous for invasive disease. Amphotericin is toxic and systemic.",
    ["پاسخ صحیح — نیستاتین موضعی جایگزین آزول در واژینیت است.",
     "فلوسیتوزین تک‌دارو مقاومت سریع می‌سازد و مال این بیماری نیست.",
     "اکینوکاندین IV برای واژینیت بیش‌درمانی است.",
     "آمفوتریسین سمّی سیستمیک است؛ خارش واژن این را نمی‌خواهد."],
    ["Correct — topical nystatin is the azole substitute in vaginitis.",
     "Flucytosine as monotherapy breeds resistance fast and does not belong to this disease.",
     "An intravenous echinocandin is over-treatment for vaginitis.",
     "Amphotericin is systemically toxic; vaginal itch does not want it."],
    "**موضعی را موضعی درمان کن.** واژینیت ≠ ازوفاژیت ≠ کاندیدمی.",
    "Treat a local disease locally. Vaginitis is not oesophagitis and is not candidaemia.",
    REFS_C)

add("book:713", "vignette", "medium",
    "**ازوفاژیت کاندیدایی لوسمی + حساسیت آزول = کاسپوفونژین.**",
    "Candida oesophagitis in leukaemia plus azole allergy is caspofungin.",
    CAND_FA, CAND_EN,
    "ازوفاژیت یعنی درگیری مخاط عمقی؛ نیستاتین به آنجا نمی‌رسد. فلوسایتوزین تک‌دارو نیست. نیتازوکسانید ضد انگل است.\n\n"
    "اکینوکاندین (کاسپوفونژین) خط اول جایگزین آزول در کاندیدای تهاجمی مخاطی و سیستمیک است.",
    "Oesophagitis means deep mucosal involvement; nystatin does not reach there. Flucytosine is not monotherapy. Nitazoxanide is an antiparasitic.\n\n"
    "An echinocandin (caspofungin) is the first-line azole substitute in invasive mucosal and systemic candida.",
    ["نیستاتین ازوفاژیت را درمان نمی‌کند.",
     "فلوسایتوزین هرگز تنها داده نمی‌شود.",
     "نیتازوکسانید داروی ژل‌یا و کریپتوسپوریدیوم است.",
     "پاسخ صحیح — کاسپوفونژین جایگزین سیستمیک آزول در ازوفاژیت کاندیدایی است."],
    ["Nystatin does not treat oesophagitis.",
     "Flucytosine is never given alone.",
     "Nitazoxanide is a drug for Giardia and Cryptosporidium.",
     "Correct — caspofungin is the systemic azole substitute in candida oesophagitis."],
    "**ازوفاژیت = سیستمیک.** اگر آزول نرفت، اکینوکاندین.",
    "Oesophagitis is systemic. If the azole is gone, an echinocandin.",
    REFS_C)

add("book:714", "vignette", "medium",
    "**برفک دهان بالغِ بی‌دلیل: HIV بخواه — نه قند و نه آندوسکوپی.**",
    "Unexplained oral thrush in an adult: ask for HIV — not a glucose and not an endoscopy.",
    CAND_FA, CAND_EN,
    "پلاک سفید بدون درد روی زبان تا فارنکس که KOH هایفا و سودوهایفا می‌دهد = برفک. در جوان بدون دندان مصنوعی و بدون آنتی‌بیوتیک، ⚠️ **این یک بیماری معرف HIV است.**\n\n"
    "قند خون زمینه‌ی ضعیف‌تری است. کشت خون در حال عمومی خوب بی‌مورد است. آندوسکوپی وقتی درد بلع باشد برای ازوفاژیت است.",
    "Painless white plaques on the tongue to the pharynx that show hyphae and pseudohyphae on KOH is thrush. In a young adult with no denture and no antibiotic, WARNING: THIS IS AN HIV-INDICATOR DISEASE.\n\n"
    "A blood glucose is a weaker setting. A blood culture in someone who looks well is out of place. Endoscopy is for oesophagitis when swallow is painful.",
    ["کشت خون در برفک بدون بدحالی لازم نیست.",
     "قند زمینه‌ی ضعیف‌تری است و اولویت اول HIV است.",
     "پاسخ صحیح — برفک بی‌دلیل بالغ تا خلافش ثابت شود HIV است.",
     "آندوسکوپی مال درد بلع و ازوفاژیت است."],
    ["A blood culture is not needed for thrush without systemic illness.",
     "Glucose is a weaker setting and HIV is the first priority.",
     "Correct — unexplained thrush in an adult is HIV until proven otherwise.",
     "Endoscopy belongs to painful swallowing and oesophagitis."],
    "**برفک بالغ = HIV را از دست نده.** قند را بعداً هم می‌شود گرفت.",
    "Adult thrush: do not miss HIV. The glucose can be taken later too.",
    REFS_C)

add("book:715", "vignette", "medium",
    "**ضایعه‌ی سفید که به‌راحتی کنده می‌شود در معتاد = فلوکونازول + سرولوژی HIV.**",
    "A white lesion that scrapes off easily in an injecting drug user is fluconazole plus an HIV serology.",
    CAND_FA, CAND_EN,
    "IDU، درد بلع، پلاک سفید که با آبسلانگ می‌رود و زیرش مختصر قرمز است. این برفک/ازوفاژیت خفیف کاندیداست نه دیفتری (می‌چسبد) نه HSV (زخم) نه آنژین ونسان (نکروز بدبو).\n\n"
    "درمان فلوکونازول خوراکی است و زمینه‌ی اجباری در IDU، HIV است.",
    "An injecting drug user, painful swallowing, a white plaque that comes off with a tongue depressor and is mildly red underneath. This is candida thrush or mild oesophagitis, not diphtheria (it sticks), not HSV (ulcers) and not Vincent's angina (foul necrosis).\n\n"
    "Treatment is oral fluconazole and the obligatory underlying test in an IDU is HIV.",
    ["پاسخ صحیح — پلاک کننده‌شونده کاندیداست؛ فلوکونازول بده و HIV را بجوی.",
     "پنی‌سیلین مال استرپ و دیفتری است؛ این ضایعه نمی‌چسبد.",
     "اسیکلوویر مال زخم‌های HSV است نه پلاک سفید کننده‌شونده.",
     "مترونیدازول مال آنژین ونسان است."],
    ["Correct — a scrapable plaque is candida; give fluconazole and hunt HIV.",
     "Penicillin is for strep and diphtheria; this lesion does not stick.",
     "Aciclovir is for HSV ulcers, not a scrapable white plaque.",
     "Metronidazole is for Vincent's angina."],
    "**کنده شد = کاندیدا. نکنده‌شد = دیفتری.** IDU را همیشه HIV کن.",
    "It scraped off, so it is candida. It did not, so it is diphtheria. Always HIV-test an IDU.",
    REFS_C)

add("book:716", "vignette", "medium",
    "**کاندیدوری پیش از عمل اورولوژی: فلوکونازول الان، نه بعد از عمل.**",
    "Candiduria before a urologic operation: fluconazole now, not after the operation.",
    CAND_FA, CAND_EN,
    "۷۰ ساله با BPH و سوند، کشت کاندیدا البیکانس، بی‌علامت، **کاندید عمل اورولوژی**.\n\n"
    "کاندیدوری بی‌علامت معمولاً درمان نمی‌شود — مگر اقدام با خونریزی مخاط. این همان استثناست. فلوکونازول خوراکی البیکانس را پاک می‌کند. شستشوی آمفوتریسین منسوخ است. درمان بعد از عمل یعنی باکتریمی/کاندیدمی حین عمل را پذیرفته‌اید.",
    "A 70-year-old with BPH and a catheter, a Candida albicans culture, no symptoms, LISTED FOR A UROLOGIC OPERATION.\n\n"
    "Asymptomatic candiduria is not usually treated — except before a mucosal-bleeding procedure. That is this exception. Oral fluconazole clears albicans. Amphotericin bladder irrigation is obsolete. Treating after the operation means you have accepted candidaemia during it.",
    ["بدون عمل، درمان لازم نبود؛ اینجا عمل در پیش است.",
     "شستشوی مثانه با آمفوتریسین دیگر توصیه نمی‌شود.",
     "درمان پس از عمل برای پیشگیری از کاندیدمی دیر است.",
     "پاسخ صحیح — پیش از دست‌کاری مجرا فلوکونازول خوراکی کاندیدوری را پاک می‌کند."],
    ["Without an operation, no treatment would be needed; here an operation is planned.",
     "Amphotericin bladder irrigation is no longer recommended.",
     "Treatment after the operation is too late to prevent candidaemia.",
     "Correct — oral fluconazole before the urethra is instrumented clears candiduria."],
    "**کاندیدوری = سوند را درآور. اگر عمل است، اول فلوکونازول.**",
    "Candiduria: take the catheter out. If there is an operation, fluconazole first.",
    REFS_C)

add("book:717", "vignette", "easy",
    "**کاندیدوری ICU بدون تب: سوند را درآور و کشت را تکرار کن — دارو نده.**",
    "ICU candiduria without fever: take the catheter out and repeat the culture — do not give a drug.",
    CAND_FA, CAND_EN,
    "۶۷ ساله ICU، فاشئیت دیابتی، فولی، کاندیدا البیکانس در ادرار، **بدون تب و بدون علامت ادراری**.\n\n"
    "این کلونیزاسیون سوند است نه عفونت. خروج سوند در بخش بزرگی کشت را منفی می‌کند. آمفوتریسین، فلوکونازول و کاسپوفونژین این‌جا فقط مقاومت و سمّیت می‌سازند. (اگر نوتروپن بود یا عمل مجرا داشت، داستان عوض می‌شد.)",
    "A 67-year-old in ICU, a diabetic fasciitis, a Foley, Candida albicans in the urine, NO FEVER AND NO URINARY SYMPTOMS.\n\n"
    "This is catheter colonisation, not infection. Removing the catheter clears the culture in a large share. Amphotericin, fluconazole and caspofungin here only breed resistance and toxicity. (If she were neutropenic or listed for a urethral procedure, the story would change.)",
    ["آمفوتریسین برای کلونیزاسیون بیش‌درمانی و سمی است.",
     "فلوکونازول وقتی عمل مجرا در پیش باشد می‌آید، نه در بی‌علامت ICU.",
     "کاسپوفونژین مال کاندیدمی است.",
     "پاسخ صحیح — سوند را درآورید و کشت را تکرار کنید."],
    ["Amphotericin is over-treatment and toxic for colonisation.",
     "Fluconazole comes when a urethral procedure is planned, not in an asymptomatic ICU patient.",
     "Caspofungin belongs to candidaemia.",
     "Correct — take the catheter out and repeat the culture."],
    "**کاندیدوری بی‌علامت را دارو نده — سوند را بکش.**",
    "Do not drug asymptomatic candiduria — pull the catheter.",
    REFS_C)

# ---- aspergillus / mucor
add("book:718", "vignette", "easy",
    "**توپ قارچی در حفره‌ی سلی = تقریباً همیشه A. fumigatus.**",
    "A fungus ball in a tuberculous cavity is almost always A. fumigatus.",
    ASP_FA, ASP_EN,
    "حفره‌ی قدیمی سل، سرفه‌ی خشک، خستگی، هموپتزی، ویز موضعی، توپ قارچی در سی‌تی. شایع‌ترین گونه **A. fumigatus** است. niger بیشتر اتومایکوزیس گوش است، flavus سینوس و منطقه‌ی گرم، nidulans نادر.",
    "An old tuberculous cavity, dry cough, fatigue, haemoptysis, a local wheeze, a fungus ball on CT. The commonest species is A. FUMIGATUS. A. niger is more otomycosis, A. flavus sinus and the tropics, A. nidulans rare.",
    ["پاسخ صحیح — آسپرژیلوما در بیش از ۹۰ درصد موارد A. fumigatus است.",
     "A. niger بیشتر گوش خارجی را می‌گیرد.",
     "A. flavus در سینوس و مناطق گرم شایع‌تر است.",
     "A. nidulans گونه‌ی نادر بیمارستانی است."],
    ["Correct — an aspergilloma is A. fumigatus in more than 90 per cent of cases.",
     "A. niger more often takes the external ear.",
     "A. flavus is commoner in the sinus and in the tropics.",
     "A. nidulans is a rare nosocomial species."],
    "**توپ قارچی = fumigatus تا خلافش ثابت شود.** niger را برای گوش بگذار.",
    "A fungus ball is fumigatus until proven otherwise. Leave niger for the ear.",
    REFS_A)

add("book:719", "recall", "medium",
    "**تب و کاهش وزن و حفره‌های متعدد = آسپرژیلوز ریوی مزمن، نه توپ خاموش.**",
    "Fever, weight loss and multiple cavities is chronic pulmonary aspergillosis, not a silent ball.",
    ASP_FA, ASP_EN,
    "آسپرژیلوما اغلب فقط هموپتزی می‌دهد. ABPA آسم و ائوزینوفیل می‌خواهد. مهاجم نوتروپنی روزهاست نه ماه‌ها تخریب. تب و تعریق و خلط و کاهش وزن با حفره‌های متعدد تعریف **CPA / CNPA** است.",
    "An aspergilloma often gives only haemoptysis. ABPA wants asthma and eosinophils. Invasive disease is days of neutropenia, not months of destruction. Fever, sweats, sputum and weight loss with multiple cavities is the definition of CPA / CNPA.",
    ["پاسخ صحیح — تخریب و حفره‌ی متعدد با علائم سیستمیک یعنی شکل مزمن.",
     "آسپرژیلوما توپ داخل حفره‌ی قدیمی است و معمولاً تب نمی‌دهد.",
     "ABPA بیماری آلرژیک راه‌های هوایی است نه تخریب پارانشیم.",
     "مهاجم مال نوتروپنی حاد است."],
    ["Correct — destruction and multiple cavities with systemic symptoms mean the chronic form.",
     "An aspergilloma is a ball inside an old cavity and does not usually give fever.",
     "ABPA is an allergic airway disease, not parenchymal destruction.",
     "Invasive disease belongs to acute neutropenia."],
    "**توپ بی‌تب = آسپرژیلوما. حفره‌ی تبدار = مزمن. نوتروپن حاد = مهاجم.**",
    "An afebrile ball is an aspergilloma. A febrile cavity is chronic. Acute neutropenia is invasive.",
    REFS_A)

add("book:720", "vignette", "medium",
    "**COPD + دو ماه تب و حفره + سل منفی = آسپرژیلوس مزمن.**",
    "COPD plus two months of fever and cavities plus negative TB is chronic aspergillus.",
    ASP_FA, ASP_EN,
    "کاندیدا پنومونی حفره‌ای در میزبان طبیعی نمی‌سازد. کریپتوکوک بیشتر ندول در پیوند است. موکور حاد و برق‌آسا در دیابت/نوتروپن است نه دو ماه. آسپرژیلوس تنها قارچی است که در COPD حفره‌ی مزمن می‌سازد.",
    "Candida does not make a cavitary pneumonia in a normal host. Cryptococcus is more a nodule in a transplant. Mucor is acute and fulminant in a diabetic or a neutropenic, not two months. Aspergillus is the only fungus that makes a chronic cavity in COPD.",
    ["پاسخ صحیح — آسپرژیلوس عامل CPA در COPD است.",
     "کاندیدا پاتوژن پارانشیم ریه‌ی سالم نیست.",
     "کریپتوکوک بیشتر ندول در پیوندی است.",
     "موکور سیر روزها دارد نه دو ماه."],
    ["Correct — Aspergillus is the cause of CPA in COPD.",
     "Candida is not a pathogen of healthy lung parenchyma.",
     "Cryptococcus is more a nodule in a transplant recipient.",
     "Mucor runs over days, not two months."],
    "**سل را رد کردی و COPD حفره ساخت؟ آسپرژیلوس.**",
    "You have excluded TB and COPD has made a cavity? Aspergillus.",
    REFS_A)

add("book:721", "vignette", "medium",
    "**کورتون طولانی + حفره + mold سپتات منشعب = آسپرژیلوس، نه موکور.**",
    "Prolonged steroids plus a cavity plus a septate branching mould is aspergillus, not mucor.",
    ASP_FA, ASP_EN,
    "لوپوس با کورتون بالاتر از فیزیولوژیک = میزبان آسپرژیلوز نیمه‌تهاجمی/مزمن. میکروسکوپ تصمیم را می‌گیرد: septate branching = آسپرژیلوس. موکور دیواره ندارد و پهن است. کاندیدا مخمر است. اسپوروتریکس گره‌های لنفاوی پوستی است.",
    "Lupus on above-physiologic steroids is a host for semi-invasive or chronic aspergillosis. The microscope decides: septate branching = aspergillus. Mucor has no septa and is wide. Candida is a yeast. Sporothrix is cutaneous lymphatic nodules.",
    ["کاندیدا مخمر و سودوهایفا است نه mold سپتات.",
     "پاسخ صحیح — هایفای سپتات منشعب تعریف بافتی آسپرژیلوس است.",
     "موکور ribbon بدون دیواره است.",
     "اسپوروتریکس بیماری گره‌ای پوست است نه حفره‌ی ریه."],
    ["Candida is a yeast with pseudohyphae, not a septate mould.",
     "Correct — septate branching hyphae are the histologic definition of aspergillus.",
     "Mucor is an aseptate ribbon.",
     "Sporothrix is a nodular skin disease, not a lung cavity."],
    "**سپتات = آسپرژیلوس. بدون دیواره = موکور.** این دو را با چشم عوضی نگیر.",
    "Septate is aspergillus. No wall is mucor. Do not swap those two with your eyes.",
    REFS_A)

add("book:722", "vignette", "medium",
    "**یک سال پس از لوبکتومی، حفره با توپ قارچی و BK منفی = آسپرژیلوس.**",
    "A year after a lobectomy, a cavity with a fungus ball and a negative BK is aspergillus.",
    ASP_FA, ASP_EN,
    "حفره‌ی جراحی یک لانه‌ی آماده است. توپ داخل حفره + BK منفی مکرر، سل و نوکاردیا و پنوموکوک را کنار می‌زند. نوکاردیا فیلامان اسیدفست نسبی است نه توپ. پنوموکوک حاد است.",
    "A surgical cavity is a ready nest. A ball inside the cavity plus repeatedly negative BK puts TB, nocardia and pneumococcus aside. Nocardia is a partially acid-fast filament, not a ball. Pneumococcus is acute.",
    ["سل با اسمیر و کشت مکرر منفی و توپ قارچی نمی‌خواند.",
     "نوکاردیا توپ داخل حفره نمی‌سازد.",
     "پاسخ صحیح — توپ در حفره‌ی بعد از جراحی امضای آسپرژیلوس است.",
     "پنوموکوک بیماری حاد چندروزه است نه سه ماه."],
    ["TB does not fit repeatedly negative smears and cultures and a fungus ball.",
     "Nocardia does not make a ball inside a cavity.",
     "Correct — a ball in a post-surgical cavity is the signature of aspergillus.",
     "Pneumococcus is an acute illness of a few days, not three months."],
    "**هر حفره‌ی قدیمی می‌تواند آسپرژیلوما بسازد — حتی حفره‌ی جراح.**",
    "Any old cavity can grow an aspergilloma — even the surgeon's cavity.",
    REFS_A)

add("book:723", "vignette", "medium",
    "**نوتروپن + گالاکتومانان + هایفای سپتات = وریکونازول، نه فلوکونازول.**",
    "A neutropenic plus galactomannan plus septate hyphae is voriconazole, not fluconazole.",
    ASP_FA, ASP_EN,
    "AML، تب نوتروپنیک، ندول‌های متعدد، گالاکتومانان مثبت، هایفای باریک سپتات = آسپرژیلوز مهاجم. خط اول IDSA/ECIL **وریکونازول** است. فلوکونازول هیچ فعالیتی ندارد. آمفوتریسین جایگزین است نه ارجح. پوساکونازول بیشتر پروفیلاکسی است.",
    "AML, febrile neutropenia, multiple nodules, a positive galactomannan, thin septate hyphae = invasive aspergillosis. First line IDSA/ECIL is VORICONAZOLE. Fluconazole has no activity. Amphotericin is the alternative, not the preferred. Posaconazole is more prophylaxis.",
    ["پاسخ صحیح — وریکونازول خط اول آسپرژیلوز مهاجم است.",
     "فلوکونازول روی آسپرژیلوس اثر ندارد.",
     "آمفوتریسین جایگزین است وقتی وریکونازول نرود.",
     "پوساکونازول بیشتر پیشگیری در AML است تا درمان حمله‌ی حاد."],
    ["Correct — voriconazole is first-line for invasive aspergillosis.",
     "Fluconazole has no activity against Aspergillus.",
     "Amphotericin is the alternative when voriconazole cannot be used.",
     "Posaconazole is more prophylaxis in AML than treatment of an acute attack."],
    "**گالاکتومانان مثبت در نوتروپن = وریکونازول امروز، نه فردا.**",
    "A positive galactomannan in a neutropenic means voriconazole today, not tomorrow.",
    REFS_A)

add("book:724", "recall", "easy",
    "**آسپرژیلوز منتشر در نقص شدید: شایع‌ترین عضو خارج ریه مغز است.**",
    "Disseminated aspergillosis in severe immunodeficiency: the commonest extrapulmonary organ is the brain.",
    ASP_FA, ASP_EN,
    "آسپرژیلوس آنژیواینویزیو است و از ریه به مغز آمبولی سپتیک می‌فرستد. آبسه‌ی مغزی و انفارکت هموراژیک شایع‌ترین تظاهر خارج ریوی است. پوست و استخوان و کبد ممکن‌اند ولی کمتر.",
    "Aspergillus is angio-invasive and throws septic emboli from the lung to the brain. A brain abscess and a haemorrhagic infarct are the commonest extrapulmonary presentation. Skin and bone and liver are possible but less common.",
    ["پاسخ صحیح — مغز شایع‌ترین عضو خارج ریوی آسپرژیلوز منتشر است.",
     "پوست تظاهر کمتر شایعی است.",
     "استخوان نادر است.",
     "کبد از مغز شایع‌تر نیست."],
    ["Correct — the brain is the commonest extrapulmonary organ of disseminated aspergillosis.",
     "Skin is a less common presentation.",
     "Bone is rare.",
     "The liver is not commoner than the brain."],
    "**آسپرژیلوس عاشق رگ است و رگ عاشق مغز.** هر نوتروپن با افت هوشیاری را تصویر کن.",
    "Aspergillus loves vessels and vessels love the brain. Image every neutropenic whose conscious level falls.",
    REFS_A)

add("book:725", "vignette", "medium",
    "**خلط قهوه‌ای + ائوزینوفیل + IgE ۱۳۵۱ = ABPA؛ غربال با skin prick فومیگاتوس.**",
    "Brownish plugs plus eosinophils plus an IgE of 1351 is ABPA; screen with an A. fumigatus skin-prick.",
    ASP_FA, ASP_EN,
    "معیارهای ABPA با skin test فوری شروع می‌شوند. اگر منفی باشد تشخیص تقریباً می‌افتد. PFT انسداد را نشان می‌دهد نه علت را. HRCT برونشکتازی مرکزی را می‌بیند ولی قدم اول نیست. اسمیر خلط حساس و اختصاصی نیست.",
    "ABPA criteria start with an immediate skin test. If it is negative the diagnosis almost falls. A PFT shows obstruction, not the cause. HRCT sees central bronchiectasis but is not the first step. A sputum smear is neither sensitive nor specific.",
    ["پاسخ صحیح — skin prick فومیگاتوس غربال ضروری ABPA است.",
     "اسپیرومتری انسداد را می‌گوید نه علت را.",
     "HRCT مفید است ولی قدم اول تشخیصی نیست.",
     "کشت خلط ممکن است کلونیزاسیون را نشان دهد نه بیماری آلرژیک را."],
    ["Correct — an A. fumigatus skin-prick is the essential ABPA screen.",
     "Spirometry reports obstruction, not the cause.",
     "HRCT is useful but is not the first diagnostic step.",
     "A sputum culture may show colonisation, not allergic disease."],
    "**IgE خیلی بالا + خلط قهوه‌ای = ABPA.** اول پوست را بخاران.",
    "A very high IgE plus brownish plugs is ABPA. Scratch the skin first.",
    REFS_A)

add("book:726", "vignette", "hard",
    "**پیوند کلیه + سینوزیت پیشرونده + نکروز کام = موکور، نه آسپرژیلوس.**",
    "A kidney transplant plus progressive sinusitis plus palatal necrosis is mucor, not aspergillus.",
    ASP_FA, ASP_EN,
    "تریاد کلاسیک موکور رینوسربرال: میزبان (دیابت، پیوند، آهن)، سینوزیت مقاوم، و **نکروز سیاه کام یا توربین**. دوبینی و پروپتوز یعنی مدار و سینوس کاورنو درگیر شده — آن عارضه است نه تشخیص اول.\n\n"
    "آسپرژیلوس سینوس هم مهاجم می‌شود ولی نکروز سریع کام امضای موکور است. پسودومونا در نوتروپن اکتما گانگرنوزوم پوست می‌سازد.",
    "The classical triad of rhino-cerebral mucor: a host (diabetes, a transplant, iron), refractory sinusitis, and BLACK NECROSIS OF THE PALATE OR TURBINATE. Diplopia and proptosis mean the orbit and cavernous sinus are involved — that is a complication, not the first diagnosis.\n\n"
    "Sinus aspergillus also invades, but rapid palatal necrosis is the signature of mucor. Pseudomonas in a neutropenic makes ecthyma gangrenosum of the skin.",
    ["آسپرژیلوس سینوس مهاجم است ولی نکروز برق‌آسای کام امضای موکور است.",
     "پاسخ صحیح — پیوند + نکروز کام + پروپتوز = موکور رینوسربرال.",
     "ترومبوز سینوس کاورنو عارضه است نه علت.",
     "پسودومونا بیشتر پوست و اکتما می‌سازد تا نکروز کام."],
    ["Sinus aspergillus invades, but fulminant palatal necrosis is the signature of mucor.",
     "Correct — a transplant plus palatal necrosis plus proptosis is rhino-cerebral mucor.",
     "Cavernous-sinus thrombosis is a complication, not the cause.",
     "Pseudomonas more often makes skin ecthyma than palatal necrosis."],
    "**کام سیاه در پیوندی = موکور تا وقتی جراح بافت ندهد.** آسپرژیلوس این‌قدر سریع نمی‌خورد.",
    "A black palate in a transplant is mucor until the surgeon gives you tissue. Aspergillus does not eat this fast.",
    REFS_A)

# ---- sepsis ladder / asplenia
add("book:829", "vignette", "medium",
    "**افت فشار که با یک لیتر نرمال‌سالین برمی‌گردد = سپسیس شدید، نه شوک.**",
    "Hypotension that comes back after one litre of saline is severe sepsis, not shock.",
    SEP_FA, SEP_EN,
    "۶۰ ساله، تب، کاهش هوشیاری، RR ۲۰، BP ۸۰/۶۰، PR ۱۲۰، T ۳۸، پیوری. پس از یک لیتر BP به ۱۰۰/۹۰ می‌رسد.\n\n"
    "عفونت ادراری هست، SIRS هست (تب، تاکی‌کاردی)، افت فشار هست که **به مایع جواب داده**. در نردبان قدیمی این **سپسیس شدید** است. شوک وقتی است که بعد از مایع کافی هنوز وازوپرسور بخواهد. SIRS تنها عفونت را حساب نکرده. سپسیس بدون کلمه‌ی شدید اختلال عضو را کم می‌آورد.\n\n"
    "Sepsis-3 این پله را برداشته؛ امتحان ایران هنوز همان نردبان را می‌پرسد.",
    "A 60-year-old, fever, a reduced conscious level, RR 20, BP 80/60, PR 120, T 38, pyuria. After one litre the BP rises to 100/90.\n\n"
    "There is a urinary infection, there is SIRS (fever, tachycardia), there is hypotension that HAS ANSWERED TO FLUID. On the old ladder this is SEVERE SEPSIS. Shock is when after enough fluid he still needs a vasopressor. SIRS alone has not counted the infection. Sepsis without the word severe under-calls the organ dysfunction.\n\n"
    "Sepsis-3 has removed this rung; the Iranian exam still asks for the old ladder.",
    ["SIRS عفونت را در خود ندارد؛ اینجا پیوری هست.",
     "سپسیس بدون «شدید» اختلال عضو و افت فشار را کم می‌گوید.",
     "پاسخ صحیح — افت فشار پاسخ‌دهنده به مایع در عفونت یعنی سپسیس شدید.",
     "شوک وقتی است که فشار پس از مایع برنگردد."],
    ["SIRS does not contain the infection; here there is pyuria.",
     "Sepsis without 'severe' under-calls the organ dysfunction and the hypotension.",
     "Correct — infection plus hypotension that answers to fluid is severe sepsis.",
     "Shock is when the pressure does not come back after fluid."],
    "**مایع دادی و فشار آمد = شدید. مایع دادی و فشار نآمد = شوک.**",
    "You gave fluid and the pressure rose: severe. You gave fluid and it did not: shock.",
    REFS_S)

add("book:836", "vignette", "medium",
    "**سپسیس شدید با منبع نامعلوم: سفپیم + جنتامایسین + وانکومایسین.**",
    "Severe sepsis with an unknown source: cefepime plus gentamicin plus vancomycin.",
    SEP_FA, SEP_EN,
    "۷۰ ساله، تب، کاهش هوشیاری، اولیگوری، severe sepsis بدون منبع. باید MRSA و پسودومونا و روده‌ای را با هم پوشاند: سفپیم (ضدپسودومونا) + جنتامایسین + وانکومایسین.\n\n"
    "سفازولین MRSA و پسودومونا را ندارد. پیپ-تازو + جنتامایسین MRSA ندارد.",
    "A 70-year-old, fever, a reduced conscious level, oliguria, severe sepsis with no source. MRSA and Pseudomonas and enterics must be covered together: cefepime (anti-pseudomonal) plus gentamicin plus vancomycin.\n\n"
    "Cefazolin has neither MRSA nor Pseudomonas. Pip-tazo plus gentamicin has no MRSA.",
    ["پاسخ صحیح — سفپیم ضدپسودومونا است و با وانکومایسین MRSA را هم می‌گیرد.",
     "سفازولین برای منبع نامعلوم بدحال خیلی تنگ است.",
     "پیپ-تازو + جنتامایسین MRSA را جا می‌گذارد.",
     "یکی از رژیم‌های فهرست درست است؛ «هیچ‌کدام» غلط است."],
    ["Correct — cefepime is anti-pseudomonal and with vancomycin also takes MRSA.",
     "Cefazolin is far too narrow for a sick unknown source.",
     "Pip-tazo plus gentamicin leaves MRSA out.",
     "One of the listed regimens is right; 'none of the above' is wrong."],
    "**منبع نامعلوم بدحال = ضدپسودومونا + MRSA.** یکی را جا نگذار.",
    "A sick unknown source means anti-pseudomonal plus MRSA. Do not leave either out.",
    REFS_S)

add("book:837", "vignette", "medium",
    "**شوک سپتیک: پیپ-تازو + جنتامایسین + وانکومایسین. سفتریاکسون پسودومونا نیست.**",
    "Septic shock: pip-tazo plus gentamicin plus vancomycin. Ceftriaxone is not anti-pseudomonal.",
    SEP_FA, SEP_EN,
    "۷۰ ساله، کاهش هوشیاری، تب ۳۹، RR ۳۰، BP ۸۰/۴۰ — شوک. سفتریاکسون + مترونیدازول شکم جامعه را می‌پوشاند نه پسودومونا و MRSA را. سفتریاکسون + وانکو + جنتامایسین MRSA دارد ولی بتالاکتام ضدپسودومونا ندارد. پیپ-تازو + جنتامایسین MRSA ندارد.\n\n"
    "سه‌داروی پیپ-تازو + جنتا + وانکو هر سه سوراخ را می‌بندد.",
    "A 70-year-old, a reduced conscious level, fever 39, RR 30, BP 80/40 — shock. Ceftriaxone plus metronidazole covers community abdomen, not Pseudomonas and MRSA. Ceftriaxone plus vanco plus gentamicin has MRSA but no anti-pseudomonal beta-lactam. Pip-tazo plus gentamicin has no MRSA.\n\n"
    "The three-drug pip-tazo plus gentamicin plus vancomycin closes all three holes.",
    ["سفتریاکسون + مترونیدازول پسودومونا و MRSA را ندارد.",
     "سفتریاکسون بتالاکتام ضدپسودومونا نیست.",
     "پاسخ صحیح — پیپ-تازو + جنتامایسین + وانکومایسین پوشش شوک منبع‌نامعلوم است.",
     "بدون وانکومایسین MRSA جا می‌ماند."],
    ["Ceftriaxone plus metronidazole has neither Pseudomonas nor MRSA.",
     "Ceftriaxone is not an anti-pseudomonal beta-lactam.",
     "Correct — pip-tazo plus gentamicin plus vancomycin is the cover for unknown-source shock.",
     "Without vancomycin, MRSA is left out."],
    "**شوک = وسیع‌ترین پوشش معقول از دقیقه صفر.** سفتریاکسون این کاره نیست.",
    "Shock means the widest reasonable cover from minute zero. Ceftriaxone is not that drug.",
    REFS_S)

add("book:838", "vignette", "medium",
    "**توکسیک، منبع نامعلوم: ایمی‌پنم + وانکومایسین.**",
    "Toxic, unknown source: imipenem plus vancomycin.",
    SEP_FA, SEP_EN,
    "۵۷ ساله ill و توکسیک، T ۳۸٫۵، PR ۱۰۰، BP ۸۰، RR (احتمالاً ۲۲؛ ۸۲ نویز استخراج است)، منبع نامعلوم. کارباپنم پوشش گرم‌منفی مقاوم و بی‌هوازی است و وانکومایسین MRSA را اضافه می‌کند. سفازولین+جنتا و کلوگزا+سیپرو و سیپرو+آمیکاسین هر سه تنگ‌اند.",
    "A 57-year-old, ill and toxic, T 38.5, PR 100, BP 80, RR (probably 22; 82 is extraction noise), unknown source. A carbapenem covers resistant Gram-negatives and anaerobes and vancomycin adds MRSA. Cefazolin plus gentamicin, cloxacillin plus cipro and cipro plus amikacin are all too narrow.",
    ["سفازولین + جنتامایسین برای بدحال منبع‌نامعلوم تنگ است.",
     "پاسخ صحیح — کارباپنم به‌علاوه‌ی وانکومایسین پوشش منبع نامعلوم توکسیک است.",
     "کلوگزاسیلین فقط استاف حساس را می‌گیرد.",
     "کینولون + آمینوگلیکوزید MRSA و بسیاری از بی‌هوازی‌ها را جا می‌گذارد."],
    ["Cefazolin plus gentamicin is too narrow for a sick unknown source.",
     "Correct — a carbapenem plus vancomycin is the cover for a toxic unknown source.",
     "Cloxacillin only takes sensitive staph.",
     "A quinolone plus an aminoglycoside leaves out MRSA and many anaerobes."],
    "**توکسیک + منبع نامعلوم = کارباپنم و وانکو.** تنگ نرو.",
    "Toxic plus an unknown source means a carbapenem and vanco. Do not go narrow.",
    REFS_S)

add("book:839", "vignette", "hard",
    "**اسکار جراحی ITP یعنی بی‌طحالی. شوک: سفوتاکسیم + وانکومایسین.**",
    "An ITP surgical scar means asplenia. Shock: cefotaxime plus vancomycin.",
    SEP_FA, SEP_EN,
    "۳۸ ساله، تب، RR ۳۲، T ۳۹٫۸، BP ۸۵/۵۰، اسکار جراحی به‌خاطر ITP = **اسپلنکتومی**. این OPSI است نه سپسیس منبع‌نامعلوم معمولی.\n\n"
    "هدف پنوموکوک (از جمله مقاوم)، مننگوکوک و هموفیلوس است: سفالوسپورین نسل سه + وانکومایسین. مروپنم+آمیکاسین کپسول‌دار را بیش از حد «بیمارستانی» می‌بیند. تازوسین+کلیندا مننگوکوک را خوب نمی‌پوشاند.",
    "A 38-year-old, fever, RR 32, T 39.8, BP 85/50, a surgical scar for ITP = SPLENECTOMY. This is OPSI, not ordinary unknown-source sepsis.\n\n"
    "The target is pneumococcus (including resistant), meningococcus and Haemophilus: a third-generation cephalosporin plus vancomycin. Meropenem plus amikacin looks at the encapsulated organisms too 'nosocomially'. Tazocin plus clindamycin covers meningococcus poorly.",
    ["پاسخ صحیح — در OPSI سفالوسپورین نسل سه به‌علاوه‌ی وانکومایسین انتخاب اول است.",
     "کارباپنم + آمیکاسین تمرکز را از کپسول‌دار جامعه برمی‌دارد.",
     "تازوسین + کلیندامایسین پوشش مننگوکوک قابل اعتمادی نیست.",
     "سیپرو + ایمی‌پنم رژیم استاندارد OPSI نیست."],
    ["Correct — in OPSI a third-generation cephalosporin plus vancomycin is first choice.",
     "A carbapenem plus amikacin takes the focus off the community encapsulated organisms.",
     "Tazocin plus clindamycin is not reliable cover for meningococcus.",
     "Cipro plus imipenem is not the standard OPSI regimen."],
    "**اسکار ITP را ببین: طحال نیست.** سفتریاکسون/سفوتاکسیم + وانکو، نه پیپ-تازو.",
    "See the ITP scar: there is no spleen. Ceftriaxone/cefotaxime plus vanco, not pip-tazo.",
    REFS_S)

add("book:840", "vignette", "medium",
    "**اسپلنکتومی + شوک بدون منبع: سفتریاکسون + وانکومایسین.**",
    "Splenectomy plus shock with no source: ceftriaxone plus vancomycin.",
    SEP_FA, SEP_EN,
    "۲۵ ساله، تب، تاکی‌کاردی، تاکی‌پنه، BP ۸۵/۶۰، منبع پیدا نشد، اسپلنکتومی یک سال پیش. همان OPSI. سیپرو+کلیندا و مترونیدازول+پنی‌سیلین کپسول‌دار مقاوم را نمی‌پوشانند. وانکو+جنتا مننگوکوک را ضعیف می‌گیرد.",
    "A 25-year-old, fever, tachycardia, tachypnoea, BP 85/60, no source found, a splenectomy one year ago. The same OPSI. Cipro plus clindamycin and metronidazole plus penicillin do not cover resistant encapsulated organisms. Vanco plus gentamicin takes meningococcus poorly.",
    ["سیپروفلوکساسین + کلیندامایسین پوشش استاندارد کپسول‌دار نیست.",
     "وانکومایسین + جنتامایسین مننگوکوک را ضعیف می‌گیرد.",
     "پاسخ صحیح — سفتریاکسون + وانکومایسین رژیم فوری OPSI است.",
     "مترونیدازول + پنی‌سیلین پنوموکوک مقاوم را از دست می‌دهد."],
    ["Ciprofloxacin plus clindamycin is not standard encapsulated cover.",
     "Vancomycin plus gentamicin takes meningococcus poorly.",
     "Correct — ceftriaxone plus vancomycin is the immediate OPSI regimen.",
     "Metronidazole plus penicillin misses resistant pneumococcus."],
    "**بی‌طحالی را در هر شوک جوانی بپرس.** رژیمش با سپسیس بیمارستانی یکی نیست.",
    "Ask about asplenia in every young shock. Its regimen is not the hospital-sepsis one.",
    REFS_S)

add("book:841", "recall", "easy",
    "**شوک سپتیک هر سه را می‌سازد: نارسایی آدرنال، ATN، و سرکوب ایمنی.**",
    "Septic shock makes all three: adrenal failure, ATN, and immune suppression.",
    SEP_FA, SEP_EN,
    "کورتیزول در شوک مصرف می‌شود و خونریزی دوطرفه‌ی آدرنال (واترهاوس) هم ممکن است. کلیه با هیپوپرفیوژن ATN می‌گیرد. خود سپسیس ایمنی را از کار می‌اندازد (immune paralysis) و عفونت دوم می‌سازد. پس همه.",
    "Cortisol is consumed in shock and bilateral adrenal haemorrhage (Waterhouse) is also possible. The kidney takes ATN from hypoperfusion. Sepsis itself shuts immunity down (immune paralysis) and invites a second infection. So all of them.",
    ["نارسایی آدرنال هم نسبی و هم مطلق در شوک دیده می‌شود.",
     "ATN عارضه‌ی کلاسیک هیپوپرفیوژن شوک است.",
     "سرکوب ایمنی پس از فاز التهابی بخشی از خود بیماری است.",
     "پاسخ صحیح — هر سه عارضه‌ی شناخته‌شده‌ی شوک سپتیک‌اند."],
    ["Adrenal failure is seen in shock both relatively and absolutely.",
     "ATN is the classical hypoperfusion complication of shock.",
     "Immune suppression after the inflammatory phase is part of the disease itself.",
     "Correct — all three are recognised complications of septic shock."],
    "**شوک فقط فشار نیست: کلیه، آدرنال و ایمنی را هم می‌برد.**",
    "Shock is not only pressure: it also takes the kidney, the adrenals and immunity.",
    REFS_S)

add("book:842", "vignette", "easy",
    "**واکسن بی‌طحالی: پنوموکوک، Hib، مننگوکوک. تیفوئید مال سفر است نه مال طحال.**",
    "Asplenia vaccines: pneumococcus, Hib, meningococcus. Typhoid is for travel, not for the spleen.",
    SEP_FA, SEP_EN,
    "جوان اسپلنکتومی‌شده پس از تروما، حالا خوب شده و ترخیص می‌شود. سه واکسن کپسول‌دار اجباری‌اند. واکسن تیفوئید برای سفر به منطقه‌ی اندمیک است، نه برای بی‌طحالی به‌تنهایی.",
    "A young man splenectomised after trauma, now well and going home. The three encapsulated vaccines are mandatory. The typhoid vaccine is for travel to an endemic area, not for asplenia on its own.",
    ["پنوموکوک خطرناک‌ترین پاتوژن OPSI است و واکسنش اجباری است.",
     "پاسخ صحیح — سالمونلا تیفی واکسن روتین بی‌طحالی نیست.",
     "هموفیلوس آنفلوانزا نوع b باید داده شود.",
     "مننگوکوک باید داده شود."],
    ["Pneumococcus is the most dangerous OPSI pathogen and its vaccine is mandatory.",
     "Correct — Salmonella Typhi is not a routine asplenia vaccine.",
     "Haemophilus influenzae type b must be given.",
     "Meningococcus must be given."],
    "**بی‌طحالی = سه کپسول. تیفوئید را برای گذرنامه بگذار.**",
    "Asplenia is three capsules. Leave typhoid for the passport.",
    REFS_S)

add("book:843", "vignette", "medium",
    "**پورپورای برق‌آسا در سرباز بی‌طحال: مننگوکوک و پنوموکوک. اپیدرمیدیس نه.**",
    "Fulminant purpura in an asplenic soldier: meningococcus and pneumococcus. Not epidermidis.",
    SEP_FA, SEP_EN,
    "ضایعات صورتی که بعد هموراژیک شده‌اند + شوک + اسیدوز + PT بالا = پورپورای فولمینانت / DIC. در بی‌طحالی مننگوکوک کلاسیک این تابلو است؛ پنوموکوک و هموفیلوس هم OPSI می‌سازند. استاف اپیدرمیدیس نه کپسول‌دار است نه این پورپورا را می‌سازد.",
    "Pink lesions that later became haemorrhagic plus shock plus acidosis plus a high PT is purpura fulminans / DIC. In asplenia meningococcus is the classic author of this picture; pneumococcus and Haemophilus also make OPSI. S. epidermidis is neither encapsulated nor the author of this purpura.",
    ["مننگوکوک کلاسیک‌ترین عامل پورپورای فولمینانت است.",
     "پاسخ صحیح — استاف اپیدرمیدیس پاتوژن OPSI و پورپورای فولمینانت نیست.",
     "پنوموکوک شایع‌ترین علت مرگ OPSI است.",
     "هموفیلوس هم کپسول‌دار OPSI است."],
    ["Meningococcus is the most classic cause of purpura fulminans.",
     "Correct — S. epidermidis is not an OPSI pathogen and does not make purpura fulminans.",
     "Pneumococcus is the commonest cause of OPSI death.",
     "Haemophilus is also an encapsulated OPSI organism."],
    "**پورپورای فولمینانت را با اپیدرمیدیس عوضی نگیر.** آن آلودگی کشت است، این قاتل است.",
    "Do not confuse purpura fulminans with epidermidis. That one is a culture contaminant; this one is a killer.",
    REFS_S)

add("book:845", "vignette", "hard",
    "**زودترین ABG سپسیس: pH بالا و PCO2 پایین — آلکالوز تنفسی هیپرونتیلاسیون.**",
    "The earliest ABG of sepsis: a high pH and a low PCO2 — the respiratory alkalosis of hyperventilation.",
    SEP_FA, SEP_EN,
    "۶۷ ساله پس از سه روز سیستیت، از دیشب تب و کاهش هوشیاری، T ۳۹، PR ۱۰۰، BP ۸۵/۴۵، RR حدود ۳۰.\n\n"
    "گزینه‌ها RTLاند. کلید چاپی pH ۷٫۵ و PCO2 ۲۸ است: **آلکالوز تنفسی**. متون امتحانی ایران زودترین اختلال اسید-باز سپسیس را هیپرونتیلاسیون می‌دانند.\n\n"
    "اگر شوک بماند، اسیدوز لاکتیک می‌آید (pH ۷٫۲۳ و HCO3 ۱۳ — گزینه‌ی آخر). هر دو را بلد باشید؛ این سؤال فاز زود را می‌خواهد.",
    "A 67-year-old after three days of cystitis, fever and a reduced conscious level since last night, T 39, PR 100, BP 85/45, RR about 30.\n\n"
    "The options are RTL. The printed key is pH 7.5 and PCO2 28: RESPIRATORY ALKALOSIS. Iranian examination texts take hyperventilation as the earliest acid-base disorder of sepsis.\n\n"
    "If the shock stays, lactic acidosis arrives (pH 7.23 and HCO3 13 — the last option). Know both; this question wants the early phase.",
    ["pH پایین با PCO2 بالا اسیدوز تنفسی است و الگوی سپسیس نیست.",
     "پاسخ صحیح — pH ۷٫۵ و PCO2 ۲۸ آلکالوز تنفسی زودرس سپسیس است.",
     "pH بالا با HCO3 بالا آلکالوز متابولیک است.",
     "اسیدوز متابولیک لاکتیک مرحله‌ی بعد شوک است، نه نخستین گزارش."],
    ["A low pH with a high PCO2 is respiratory acidosis and is not the sepsis pattern.",
     "Correct — pH 7.5 and PCO2 28 is the early respiratory alkalosis of sepsis.",
     "A high pH with a high HCO3 is metabolic alkalosis.",
     "Lactic metabolic acidosis is the later stage of shock, not the first report."],
    "**اول نفس تند pH را بالا می‌برد؛ بعد لاکتات پایین می‌آورد.** هر دو مرحله را بشناس.",
    "First the fast breathing raises the pH; then lactate brings it down. Know both stages.",
    REFS_S)

dump()
