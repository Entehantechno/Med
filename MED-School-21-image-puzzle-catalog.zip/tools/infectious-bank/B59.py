# -*- coding: utf-8 -*-
"""Micro-lessons, batch 59 — remaining urinary-tract items (19), completing
the chapter (29 of 29).

Four rules do almost all of the work:

  ASYMPTOMATIC BACTERIURIA is not treated — not in diabetics, not in catheterised
  patients, not in older women — except in pregnancy and before a mucosal-bleeding
  urologic procedure (biopsy, TURP). Pyuria does not change that.

  UNCOMPLICATED CYSTITIS in a non-pregnant woman is a clinical diagnosis.
  First-line is nitrofurantoin (least collateral damage). Fluoroquinolones are
  reserved. Culture is not required on a first episode.

  FEVER TURNS CYSTITIS INTO PYELONEPHRITIS. Nitrofurantoin has no tissue level
  and is then the WRONG drug. That is why q9514's printed key (ciprofloxacin)
  is corrected to nitrofurantoin.

  PREGNANCY: treat even asymptomatic bacteriuria. Avoid TMP-SMX in the first
  trimester and at term, avoid fluoroquinolones always, avoid nitrofurantoin
  near term. Pyelonephritis is an inpatient intravenous beta-lactam (classic
  textbook: ampicillin plus gentamicin).

Reference: Harrison 21 Ch. 130; IDSA ASB 2019; IDSA cystitis/pyelo 2011.
"""
import json, io, os

L = {}


def add(key, style, diff, lead_fa, lead_en, pts_fa, pts_en, exp_fa, exp_en,
        why_fa, why_en, gold_fa, gold_en, refs):
    assert len(pts_fa) == len(pts_en) and len(pts_fa) >= 10, key
    assert len(why_fa) == 4 and len(why_en) == 4, key
    L[key] = {
        "style": style, "difficulty": diff,
        "micro": {"lead_fa": lead_fa, "lead_en": lead_en,
                  "points_fa": pts_fa, "points_en": pts_en},
        "explanation_fa": exp_fa, "explanation_en": exp_en,
        "why_fa": why_fa, "why_en": why_en,
        "golden_fa": gold_fa, "golden_en": gold_en, "refs": refs,
    }


H = "Harrison's Principles of Internal Medicine, 21st ed (2022) — Ch. 130: Urinary Tract Infections"
IDSA_ASB = "Nicolle LE et al. IDSA clinical practice guideline for the management of asymptomatic bacteriuria. Clin Infect Dis 2019"
IDSA_UTI = "Gupta K et al. IDSA guideline on uncomplicated cystitis and pyelonephritis. Clin Infect Dis 2011"

ASB_FA = [
    "⚠️ **باکتریوری بدون علامت درمان نمی‌شود — مگر بارداری یا اقدام تهاجمی ادراری.**",
    "**تعریف:** کشت مثبت (≥۱۰⁵ در زن، یا کاتتر ≥۱۰³) **بدون** علامت موضعی یا سیستمیک.",
    "⚠️ **پیوری، نیتریت مثبت و حتی هماچوری تشخیص را عوض نمی‌کنند.**",
    "**دیابت درمان نمی‌خواهد.** دیابت باکتریوری را شایع‌تر می‌کند، نه خطرناک‌تر.",
    "**سوند دائم تقریباً همیشه کلونیزه است.** درمان فقط مقاومت می‌سازد.",
    "**سنگ، سیروز و «کشت مثبت مجدد» هم اندیکاسیون درمان نیستند.**",
    "**تنها دو استثنای محکم:** بارداری، و بیوپسی/TURP/اقدام با خونریزی مخاط.",
    "در آن دو استثنا، **پیش از اقدام درمان کنید** تا باکتریمی پیشگیری شود.",
    "تعویض سوند به‌تنهایی کلونیزاسیون را «درمان» نمی‌کند و لازم هم نیست.",
    "پروفیلاکسی طولانی‌مدت در حامل سوند، مقاومت می‌سازد و توصیه نمی‌شود.",
]
ASB_EN = [
    "WARNING: ASYMPTOMATIC BACTERIURIA IS NOT TREATED — EXCEPT IN PREGNANCY OR BEFORE AN INVASIVE UROLOGIC PROCEDURE.",
    "DEFINITION: a positive culture (≥10⁵ in a woman, or catheter ≥10³) WITHOUT local or systemic symptoms.",
    "WARNING: PYURIA, A POSITIVE NITRITE AND EVEN HAEMATURIA DO NOT CHANGE THE DIAGNOSIS.",
    "DIABETES IS NOT A REASON TO TREAT. Diabetes makes bacteriuria more common, not more dangerous.",
    "A LONG-TERM CATHETER IS ALMOST ALWAYS COLONISED. Treatment only breeds resistance.",
    "STONES, CIRRHOSIS AND A 'REPEAT POSITIVE CULTURE' ARE NOT INDICATIONS TO TREAT EITHER.",
    "ONLY TWO FIRM EXCEPTIONS: pregnancy, and biopsy / TURP / a mucosal-bleeding procedure.",
    "In those two exceptions, TREAT BEFORE THE PROCEDURE to prevent bacteraemia.",
    "Changing the catheter alone does not 'treat' colonisation and is not required.",
    "Long-term prophylaxis in a catheter carrier breeds resistance and is not recommended.",
]

CYS_FA = [
    "⚠️ **سیستیت بدون عارضه تشخیص بالینی است: سوزش + تکرر ± فوریت، بدون تب و بدون پهلو.**",
    "در زن غیرباردار سالم، **کشت لازم نیست** — به‌ویژه در اولین اپیزود.",
    "سونوگرافی و کشت خون مال پیلونفریت یا پیچیده است، نه این تابلو.",
    "⚠️ **خط اول: نیتروفورانتوئین ۵ روز** (یا فسفومایسین تک‌دوز، یا TMP-SMX سه روز اگر مقاومت محلی <۲۰٪).",
    "**نیتروفورانتوئین کمترین آسیب جانبی (collateral damage) را به فلور روده می‌زند.**",
    "فلوروکینولون‌ها مؤثرند ولی **رزرو** می‌شوند — FDA و IDSA هر دو.",
    "آمپی‌سیلین به‌خاطر مقاومت بالا دیگر تجربی نیست.",
    "دوره‌ی کوتریموکسازول استاندارد **۳ روز** است نه ۱۰ روز.",
    "⚠️ **تب یعنی پیلونفریت تا خلافش ثابت شود** — نیتروفورانتوئین آن را درمان نمی‌کند.",
    "نیتروفورانتوئین سطح بافتی و خونی کافی ندارد؛ فقط در ادرار غلیظ می‌شود.",
]
CYS_EN = [
    "WARNING: UNCOMPLICATED CYSTITIS IS A CLINICAL DIAGNOSIS: dysuria plus frequency ± urgency, without fever and without flank pain.",
    "In a healthy non-pregnant woman, A CULTURE IS NOT REQUIRED — especially on a first episode.",
    "Ultrasound and blood cultures belong to pyelonephritis or complicated infection, not this picture.",
    "WARNING, FIRST LINE: NITROFURANTOIN FOR 5 DAYS (or single-dose fosfomycin, or 3-day TMP-SMX if local resistance is <20%).",
    "NITROFURANTOIN DOES THE LEAST COLLATERAL DAMAGE to bowel flora.",
    "Fluoroquinolones work but are RESERVED — both the FDA and IDSA say so.",
    "Ampicillin is no longer empiric because of high resistance.",
    "The standard TMP-SMX course is 3 DAYS, not 10.",
    "WARNING: FEVER MEANS PYELONEPHRITIS UNTIL PROVEN OTHERWISE — nitrofurantoin does not treat it.",
    "Nitrofurantoin has no adequate tissue or serum level; it only concentrates in urine.",
]

PREG_FA = [
    "⚠️ **باکتریوری بارداری، حتی بی‌علامت، همیشه درمان می‌شود** — خطر پیلونفریت و زایمان زودرس.",
    "**سه‌ماهه‌ی اول:** از TMP-SMX پرهیز کنید (آنتاگونیسم فولات، نقص لوله).",
    "**نزدیک ترم:** از TMP-SMX (کرن‌ایکتروس) و از نیتروفورانتوئین (همولیز نوزاد) پرهیز کنید.",
    "**فلوروکینولون در تمام بارداری ممنوع است.**",
    "برای سیستیت و ASB اواسط بارداری: نیتروفورانتوئین یا یک بتالاکتام خوراکی (سفیکسیم).",
    "⚠️ **پیلونفریت بارداری بستری است و وریدی شروع می‌شود** — نه نیتروفورانتوئین خوراکی.",
    "رژیم کلاسیک کتاب: **آمپی‌سیلین + جنتامایسین**. امروز سفتریاکسون تنها هم رایج است.",
    "انسداد و هیدرونفروز، پوشش را گسترده‌تر و اورولوژی را به میدان می‌کشد.",
    "جنتامایسین تنها برای پیلونفریت بارداری ترجیح ندارد.",
    "نیتروفورانتوئین وریدی وجود عملی ندارد و پیلونفریت را نمی‌پوشاند.",
]
PREG_EN = [
    "WARNING: BACTERIURIA IN PREGNANCY, EVEN IF ASYMPTOMATIC, IS ALWAYS TREATED — risk of pyelonephritis and preterm labour.",
    "FIRST TRIMESTER: avoid TMP-SMX (folate antagonism, neural-tube defects).",
    "NEAR TERM: avoid TMP-SMX (kernicterus) and nitrofurantoin (neonatal haemolysis).",
    "FLUOROQUINOLONES ARE FORBIDDEN THROUGHOUT PREGNANCY.",
    "For mid-pregnancy cystitis and ASB: nitrofurantoin or an oral beta-lactam (cefixime).",
    "WARNING: PYELONEPHRITIS IN PREGNANCY IS AN INPATIENT, INTRAVENOUS START — not oral nitrofurantoin.",
    "The classic textbook regimen: AMPICILLIN PLUS GENTAMICIN. Ceftriaxone monotherapy is common today.",
    "Obstruction and hydronephrosis widen cover and bring urology in.",
    "Gentamicin alone is not preferred for pyelonephritis in pregnancy.",
    "Intravenous nitrofurantoin is not a practical option and does not cover pyelonephritis.",
]

REFS_ASB = [H, IDSA_ASB]
REFS_CYS = [H, IDSA_UTI]
REFS_PR = [H, IDSA_ASB, IDSA_UTI]

# =========================================================== catheter / ASB
add("book:499", "vignette", "medium",
    "**اپیدیدیمیت چهار روز پس از فولی بیمارستانی ← روده‌ای گرم‌منفی؛ در این گزینه‌ها کلبسیلا.**",
    "Epididymitis four days after a hospital Foley: an enteric Gram-negative; among these options, Klebsiella.",
    ASB_FA + [
        "اپیدیدیمیت پس از سوند، عفونت بالارونده از فلور روده‌ای است نه از پوست.",
        "شایع‌ترین عامل کلی E. coli است؛ در این گزینه‌ها E. coli نیست.",
        "کلبسیلا دومین انتروباکترال شایع در UTI مرتبط با کاتتر است.",
        "کاندیدا پس از سوند طولانی و آنتی‌بیوتیک گسترده مطرح است، نه روز چهارم.",
        "استاف اپیدرمیدیس و استرپتوکوک B عوامل معمول اپیدیدیمیت بیمارستانی نیستند.",
    ],
    ASB_EN + [
        "Post-catheter epididymitis is an ascending infection from bowel flora, not from skin.",
        "Overall the commonest cause is E. coli; E. coli is not among these options.",
        "Klebsiella is the second commonest enterobacterial in catheter-associated UTI.",
        "Candida is considered after a prolonged catheter and broad antibiotics, not on day four.",
        "S. epidermidis and group B streptococcus are not usual causes of nosocomial epididymitis.",
    ],
    "مرد ۷۰ ساله‌ی بستری، **چهار روز پس از فولی** تب و درد و تورم اپیدیدیم گرفته؛ ادرار ۲۰–۲۲ گلبول سفید دارد.\n\n"
    "این اپیدیدیمیت بالارونده‌ی مرتبط با کاتتر است. فلور مسئول، **روده‌ای گرم‌منفی** است: اشرشیا کلی اول، بعد کلبسیلا و پروتئوس و گاهی پسودوموناس.\n\n"
    "در گزینه‌ها اشرشیا کلی نیست. ⚠️ **پس کلبسیلا تنها انتروباکترال فهرست است و پاسخ است.**\n\n"
    "کاندیدا مال سوندهای چند هفته‌ای و آنتی‌بیوتیک طولانی است. استاف اپیدرمیدیس فلور پوست است نه مجرا. استرپتوکوک B در زن باردار اهمیت دارد نه در این زمینه.",
    "A 70-year-old inpatient develops fever and a painful swollen epididymis FOUR DAYS AFTER A FOLEY; the urine has 20–22 white cells.\n\n"
    "This is ascending catheter-associated epididymitis. The responsible flora is ENTERIC GRAM-NEGATIVE: E. coli first, then Klebsiella and Proteus and sometimes Pseudomonas.\n\n"
    "E. coli is not listed. WARNING: KLEBSIELLA IS THEREFORE THE ONLY ENTEROBACTERIAL ON THE LIST AND IS THE ANSWER.\n\n"
    "Candida belongs to catheters left for weeks and to prolonged antibiotics. S. epidermidis is skin flora, not urethral flora. Group B streptococcus matters in pregnant women, not here.",
    ["کاندیدا پس از سوند طولانی و آنتی‌بیوتیک گسترده مطرح است، نه روز چهارم.",
     "استرپتوکوک گروه B عامل معمول اپیدیدیمیت مرتبط با کاتتر نیست.",
     "استاف اپیدرمیدیس فلور پوست است و این مسیر بالارونده‌ی روده‌ای نیست.",
     "پاسخ صحیح — در غیاب اشرشیا کلی، کلبسیلا شایع‌ترین گرم‌منفی روده‌ای فهرست است."],
    ["Candida is considered after a prolonged catheter and broad antibiotics, not on day four.",
     "Group B streptococcus is not a usual cause of catheter-associated epididymitis.",
     "S. epidermidis is skin flora and this is not an ascending enteric path.",
     "Correct — in the absence of E. coli, Klebsiella is the commonest enteric Gram-negative on the list."],
    "**کاتتر کوتاه‌مدت + اپیدیدیمیت = گرم‌منفی روده‌ای.** اگر کلی نبود، کلبسیلا.",
    "A short-term catheter plus epididymitis means an enteric Gram-negative. If E. coli is missing, take Klebsiella.",
    REFS_ASB)

add("book:501", "vignette", "easy",
    "**سوند سه هفته + پیوری + کشت مثبت + بدون علامت = هیچ اقدامی لازم نیست.**",
    "A three-week catheter plus pyuria plus a positive culture plus no symptoms: nothing needs doing.",
    ASB_FA,
    ASB_EN,
    "مرد ۶۵ ساله پس از CVA، سوند ادراری **سه هفته**، پیوری ۲۰–۳۰، کشت اشرشیا کلی ۱۰⁵، **CBC نرمال، بدون تب، بدون شکایت**.\n\n"
    "این تعریف کتابی **باکتریوری بدون علامت در حامل سوند** است. IDSA ۲۰۱۹ با توصیه‌ی قوی می‌گوید **نه غربالگری کنید نه درمان**. پیوری تقریباً در همه‌ی سوندهای طولانی هست و اندیکاسیون نیست.\n\n"
    "درمان یک هفته سیپروفلوکساسین فقط مقاومت می‌سازد. پروفیلاکسی طولانی کوتریموکسازول بدتر است. تعویض سوند و تکرار کشت هم در فرد بی‌علامت چیزی را عوض نمی‌کند — سوند جدید ظرف ۴۸ ساعت دوباره کلونیزه می‌شود.",
    "A 65-year-old man after a CVA, a urinary catheter for THREE WEEKS, pyuria 20–30, an E. coli culture of 10⁵, a NORMAL CBC, NO FEVER, NO COMPLAINTS.\n\n"
    "This is the textbook definition of ASYMPTOMATIC BACTERIURIA IN A CATHETER CARRIER. IDSA 2019 gives a strong recommendation: DO NOT SCREEN AND DO NOT TREAT. Pyuria is present in almost every long-term catheter and is not an indication.\n\n"
    "A week of ciprofloxacin only breeds resistance. Long-term co-trimoxazole prophylaxis is worse. Changing the catheter and repeating the culture also changes nothing in an asymptomatic person — the new catheter is recolonised within 48 hours.",
    ["تعویض سوند کلونیزاسیون را درمان نمی‌کند و سوند جدید دوباره کلونیزه می‌شود.",
     "پروفیلاکسی طولانی‌مدت فقط مقاومت می‌سازد.",
     "درمان سیپروفلوکساسین در بی‌علامت حامل سوند ممنوع است.",
     "پاسخ صحیح — باکتریوری بدون علامت حامل سوند درمان و پیگیری خاصی نمی‌خواهد."],
    ["Changing the catheter does not treat colonisation, and the new catheter is recolonised.",
     "Long-term prophylaxis only breeds resistance.",
     "Ciprofloxacin is forbidden in an asymptomatic catheter carrier.",
     "Correct — asymptomatic bacteriuria in a catheter carrier needs no treatment and no special follow-up."],
    "**سوند + کشت مثبت + بی‌علامت = دست نزن.** پیوری تو را گول نزند.",
    "A catheter plus a positive culture plus no symptoms: do not touch it. Do not let pyuria fool you.",
    REFS_ASB)

add("book:502", "vignette", "easy",
    "**آسیب نخاع + سوند دائم + کشت مثبت + ادرار بدون پیوری + بی‌علامت = هیچ.**",
    "Spinal injury plus a long-term catheter plus a positive culture plus no pyuria plus no symptoms: nothing.",
    ASB_FA,
    ASB_EN,
    "مرد ۵۰ ساله، آسیب نخاعی سه ساله، سوند دائم، کشت اشرشیا کلی >۱۰٬۰۰۰، **WBC ادرار ۱–۲**، بدون علامت.\n\n"
    "دو نشانه این را از عفونت جدا می‌کند: نبود علامت، و **نبود پیوری**. کلنی‌کانت ۱۰⁴ در حامل سوند حتی به آستانه‌ی تفسیر هم همیشه نمی‌رسد؛ با ادرار تقریباً خالی از گلبول سفید، این کلونیزاسیون محض است.\n\n"
    "هیچ‌کدام از رژیم‌های ۷ و ۱۰ و ۱۴ روزه‌ی سیپروفلوکساسین جایی ندارند. تکرار کشت فقط یک عدد دیگر به پرونده اضافه می‌کند.",
    "A 50-year-old man, a spinal injury three years ago, a long-term catheter, an E. coli culture >10,000, URINE WBC 1–2, no symptoms.\n\n"
    "Two findings separate this from infection: the absence of symptoms, and THE ABSENCE OF PYURIA. A colony count of 10⁴ in a catheter carrier does not even always meet the interpretive threshold; with an almost cell-free urine this is pure colonisation.\n\n"
    "None of the 7-, 10- or 14-day ciprofloxacin regimens has a place. Repeating the culture only adds another number to the file.",
    ["تکرار کشت و درمان ۷روزه یعنی درمان کلونیزاسیون؛ مقاومت می‌سازد.",
     "ده روز دارو به‌علاوه‌ی پروفیلاکسی، دو خطا روی هم است.",
     "چهارده روز و تکرار کشت، درمان یک کشت بی‌علامت است.",
     "پاسخ صحیح — کلونیزاسیون سوند دائم بدون علامت و بدون پیوری اقدامی نمی‌خواهد."],
    ["Repeating the culture and treating for 7 days is treating colonisation; it breeds resistance.",
     "Ten days of drug plus prophylaxis is two errors stacked.",
     "Fourteen days and a repeat culture is treating an asymptomatic isolate.",
     "Correct — colonisation of a long-term catheter without symptoms and without pyuria needs nothing."],
    "**پیوری منفی + بی‌علامت = کلونیزاسیون، نه UTI.** عدد کشت را درمان نکن.",
    "No pyuria plus no symptoms is colonisation, not UTI. Do not treat a culture number.",
    REFS_ASB)

add("book:504", "vignette", "easy",
    "**زن ۶۰ ساله، دو کشت کلبسیلا، بدون علامت، سونوی طبیعی ← درمان نکن.**",
    "A 60-year-old woman, two Klebsiella cultures, no symptoms, a normal ultrasound: do not treat.",
    ASB_FA,
    ASB_EN,
    "زن ۶۰ ساله، دو نوبت کشت کلبسیلا پنومونیه ۱۰⁵، **بدون سوزش و تکرر**، معاینه و سونوی کلیه و مثانه طبیعی.\n\n"
    "دو کشت مثبت فقط تشخیص باکتریوری را محکم می‌کند، نه اندیکاسیون درمان را. در زن غیرباردار — حتی مسن — IDSA صریح است: درمان نکنید. سونوی طبیعی سنگ و انسداد را هم برداشته.\n\n"
    "تری‌متوپریم-سولفامتوکسازول، نیتروفورانتوئین و سیپروفلوکساسین هر سه داروهای واقعی سیستیت‌اند که این‌جا بیمار سیستیت ندارد.",
    "A 60-year-old woman, two cultures of Klebsiella pneumoniae at 10⁵, NO DYSURIA AND NO FREQUENCY, a normal examination and a normal renal and bladder ultrasound.\n\n"
    "Two positive cultures only secure the diagnosis of bacteriuria, not the indication to treat. In a non-pregnant woman — even an older one — IDSA is explicit: do not treat. The normal ultrasound has also removed stones and obstruction.\n\n"
    "Trimethoprim-sulfamethoxazole, nitrofurantoin and ciprofloxacin are all real cystitis drugs for a patient who does not have cystitis.",
    ["کوتریموکسازول داروی سیستیت است؛ این بیمار سیستیت ندارد.",
     "نیتروفورانتوئین هم همین‌طور؛ باکتریوری بدون علامت زن مسن درمان نمی‌شود.",
     "سیپروفلوکساسین در بی‌علامت فقط مقاومت و Clostridioides می‌سازد.",
     "پاسخ صحیح — دو کشت مثبت بدون علامت در زن غیرباردار درمان نمی‌خواهد."],
    ["Co-trimoxazole is a cystitis drug; this patient does not have cystitis.",
     "Nitrofurantoin likewise; asymptomatic bacteriuria in an older woman is not treated.",
     "Ciprofloxacin in an asymptomatic patient only breeds resistance and Clostridioides.",
     "Correct — two positive cultures without symptoms in a non-pregnant woman do not need treatment."],
    "**دو کشت، هنوز باکتریوری است نه عفونت.** علامت است که درمان را روشن می‌کند.",
    "Two cultures are still bacteriuria, not infection. Symptoms are what turn the treatment on.",
    REFS_ASB)

add("book:510", "recall", "medium",
    "**باکتریوری بدون علامت فقط پیش از بیوپسی مثانه درمان می‌شود — نه برای سنگ، سیروز یا دیابت.**",
    "Asymptomatic bacteriuria is treated only before a bladder biopsy — not for a stone, cirrhosis or diabetes.",
    ASB_FA,
    ASB_EN,
    "زن ۴۰ ساله، دو کشت اشرشیا کلی >۱۰۰٬۰۰۰، **هیچ علامتی ندارد**. در کدام شرط درمان لازم است؟\n\n"
    "تنها استثنای غیر بارداری، **اقدام اورولوژی با خونریزی مخاط** است: بیوپسی مثانه، TURP، سنگ‌شکنی از راه مجرا. دلیل: ورود باکتری به خون هنگام آسیب مخاط.\n\n"
    "⚠️ **دیابت شایع‌ترین تله است.** کارآزمایی‌ها نشان داده‌اند درمان ASB در دیابت، پیلونفریت بعدی را کم نمی‌کند. سنگ کلیه بدون برنامه‌ی مداخله هم همین‌طور. سیروز صفراوی هیچ جایگاهی در این فهرست ندارد.",
    "A 40-year-old woman, two E. coli cultures >100,000, NO SYMPTOMS AT ALL. Under which condition does she need treatment?\n\n"
    "The only non-pregnancy exception is A UROLOGIC PROCEDURE WITH MUCOSAL BLEEDING: bladder biopsy, TURP, transurethral lithotripsy. The reason: bacteria enter the blood when mucosa is injured.\n\n"
    "WARNING: DIABETES IS THE COMMONEST TRAP. Trials show that treating ASB in diabetes does not reduce later pyelonephritis. A kidney stone with no planned intervention is the same. Biliary cirrhosis has no place on this list.",
    ["پاسخ صحیح — بیوپسی مثانه خونریزی مخاط می‌سازد و باکتریوری باید پیش از آن پاک شود.",
     "سنگ بدون برنامه‌ی مداخله اندیکاسیون درمان ASB نیست.",
     "سیروز صفراوی هیچ ربطی به تصمیم درمان باکتریوری ندارد.",
     "دیابت باکتریوری را شایع می‌کند ولی درمانش سودی ندارد."],
    ["Correct — a bladder biopsy makes the mucosa bleed, and bacteriuria must be cleared before it.",
     "A stone with no planned intervention is not an indication to treat ASB.",
     "Biliary cirrhosis has nothing to do with the decision to treat bacteriuria.",
     "Diabetes makes bacteriuria commoner but treating it does not help."],
    "**استثناهای ASB را روی انگشت بشمار: بارداری، بیوپسی/TURP.** دیابت در این فهرست نیست.",
    "Count the ASB exceptions on your fingers: pregnancy, biopsy/TURP. Diabetes is not on that list.",
    REFS_ASB)

# =========================================================== cystitis
add("book:511", "vignette", "easy",
    "**عروس تازه‌ازدواج‌کرده، سوزش و تکرر، فقط تندرنس سوپراپوبیک ← آنتی‌بیوتیک خوراکی.**",
    "A newly married woman, dysuria and frequency, only suprapubic tenderness: oral antibiotics.",
    CYS_FA,
    CYS_EN,
    "زن جوان سالم، چند ماه از ازدواج، سوزش و تکرر، **بدون تب**، تنها یافته تندرنس سوپراپوبیک. این **honeymoon cystitis** است — سیستیت بدون عارضه‌ی پس از شروع فعالیت جنسی.\n\n"
    "تشخیص بالینی است و درمان **تجربی خوراکی** است. سونو، کشت خون و کشت ادرار این تابلو را لازم ندارند. داروی ضدالتهاب علامت را کم می‌کند ولی عفونت را درمان نمی‌کند.",
    "A healthy young woman, a few months into marriage, dysuria and frequency, NO FEVER, the only finding suprapubic tenderness. This is HONEYMOON CYSTITIS — uncomplicated cystitis after the start of sexual activity.\n\n"
    "The diagnosis is clinical and treatment is EMPIRIC AND ORAL. Ultrasound, blood cultures and even a urine culture are not required for this picture. An anti-inflammatory eases symptoms but does not treat the infection.",
    ["پاسخ صحیح — سیستیت بدون عارضه درمان تجربی خوراکی می‌خواهد، نه تصویربرداری.",
     "سونوگرافی مال عفونت پیچیده یا پیلونفریت است.",
     "کشت خون و حتی کشت ادرار در اولین سیستیت ساده لازم نیست.",
     "ضدالتهاب علامت را کم می‌کند ولی باکتری را نمی‌کشد."],
    ["Correct — uncomplicated cystitis needs empiric oral treatment, not imaging.",
     "Ultrasound belongs to complicated infection or pyelonephritis.",
     "Blood cultures and even a urine culture are not needed on a first simple cystitis.",
     "An anti-inflammatory eases symptoms but does not kill the bacterium."],
    "**سیستیت ساده = شرح حال + آنتی‌بیوتیک.** آزمایش را برای شکست درمان بگذار.",
    "Simple cystitis is a history plus an antibiotic. Save the tests for treatment failure.",
    REFS_CYS)

add("book:512", "vignette", "easy",
    "**همان تابلو، بدون سابقه‌ی قبلی: باز هم آنتی‌بیوتیک، نه کشت و نه سونو.**",
    "The same picture, no previous episode: antibiotics again, not a culture and not an ultrasound.",
    CYS_FA,
    CYS_EN,
    "زن ۳۰ ساله‌ی غیرباردار، سوزش و تکرر و فوریت، بدون رفتار پرخطر، **بدون تب و بدون تندرنس پهلو**، بدون سابقه‌ی UTI. ارجح‌ترین اقدام؟\n\n"
    "دقیقاً همان سیستیت بدون عارضه. IDSA: در زن سالم با علائم تیپیک، **حتی کشت ادرار هم ضروری نیست**. سونو و کشت خون کاملاً بی‌موردند.\n\n"
    "کشت را وقتی می‌گیرید که: عفونت پیچیده باشد، باردار باشد، مرد باشد، تب داشته باشد، یا درمان تجربی شکست بخورد.",
    "A 30-year-old non-pregnant woman, dysuria and frequency and urgency, no high-risk sexual behaviour, NO FEVER AND NO FLANK TENDERNESS, no previous UTI. The preferred step?\n\n"
    "Exactly the same uncomplicated cystitis. IDSA: in a healthy woman with typical symptoms, EVEN A URINE CULTURE IS NOT ESSENTIAL. Ultrasound and blood cultures are entirely out of place.\n\n"
    "You culture when: the infection is complicated, she is pregnant, the patient is a man, there is fever, or empiric treatment has failed.",
    ["پاسخ صحیح — در سیستیت تیپیک زن سالم، آنتی‌بیوتیک تجربی کافی است.",
     "سونو مال پیچیده یا مشکوک به سنگ و انسداد است.",
     "کشت ادرار در اولین اپیزود تیپیک الزامی نیست.",
     "کشت خون مال پیلونفریت یا سپسیس است."],
    ["Correct — in typical cystitis in a healthy woman, empiric antibiotics are enough.",
     "Ultrasound belongs to complicated infection or suspected stone and obstruction.",
     "A urine culture is not mandatory on a first typical episode.",
     "A blood culture belongs to pyelonephritis or sepsis."],
    "**تب و پهلو را بپرس. اگر هر دو منفی‌اند، درمان کن و بفرست.**",
    "Ask about fever and the flank. If both are negative, treat and send her home.",
    REFS_CYS)

add("book:514", "vignette", "hard",
    "⚠️ **تب یعنی پیلونفریت. نیتروفورانتوئین سطح بافتی ندارد — کلید منبع تصحیح شد.**",
    "WARNING: fever means pyelonephritis. Nitrofurantoin has no tissue level — the source key was corrected.",
    CYS_FA + [
        "⚠️ کلید چاپی «سیپروفلوکساسین» بود؛ از نظر Harrison و IDSA نادرست است.",
        "دیزوری + تکرر + تب بدون منبع دیگر = پیلونفریت حاد، حتی اگر حال عمومی خوب باشد.",
        "نیتروفورانتوئین فقط در ادرار غلیظ می‌شود و پارانشیم کلیه را درمان نمی‌کند.",
        "سیپروفلوکساسین خط اول سرپایی پیلونفریت است اگر مقاومت محلی اجازه دهد.",
    ],
    CYS_EN + [
        "WARNING: the printed key was 'ciprofloxacin'; Harrison and IDSA say that is wrong.",
        "Dysuria plus frequency plus fever with no other source is acute pyelonephritis, even if she looks well.",
        "Nitrofurantoin only concentrates in urine and does not treat the renal parenchyma.",
        "Ciprofloxacin is first-line outpatient therapy for pyelonephritis if local resistance allows.",
    ],
    "⚠️ **تصحیح کلید:** منبع «سیپروفلوکساسین» را نامناسب دانسته؛ از نظر مرجع این انتخاب درست است و داروی نامناسب **نیتروفورانتوئین** است.\n\n"
    "زن ۲۴ ساله، دیزوری، تکرار ادرار و **تب دو روزه**، ژنیتال خارجی طبیعی، پیوری، منبع تب دیگری پیدا نشده، Vital پایدار.\n\n"
    "تب یعنی عفونت از مخاط مثانه گذشته و به پارانشیم کلیه رسیده است. این دیگر سیستیت نیست؛ **پیلونفریت** است — حتی اگر بیمار «بدحال» نباشد.\n\n"
    "نیتروفورانتوئین به بافت و خون نمی‌رسد. دادن آن به پیلونفریت یعنی درمان‌نکردن کلیه. سیپروفلوکساسین ۷روزه رژیم IDSA برای پیلونفریت سرپایی است. کوتریموکسازول اگر حساس باشد قابل قبول است. آمپی‌سیلین-سولباکتام پوشش بتالاکتامی است که در بستری استفاده می‌شود.",
    "WARNING: KEY CORRECTION. The source marked ciprofloxacin as inappropriate; the reference says that choice is correct and the inappropriate drug is NITROFURANTOIN.\n\n"
    "A 24-year-old woman, dysuria, frequency and TWO DAYS OF FEVER, a normal external genital examination, pyuria, no other source of fever found, stable vitals.\n\n"
    "Fever means the infection has left the bladder mucosa and reached the renal parenchyma. This is no longer cystitis; it is PYELONEPHRITIS — even if she does not look 'ill'.\n\n"
    "Nitrofurantoin does not reach tissue or blood. Giving it for pyelonephritis means not treating the kidney. Seven days of ciprofloxacin is the IDSA regimen for outpatient pyelonephritis. Co-trimoxazole is acceptable if the isolate is susceptible. Ampicillin-sulbactam is a beta-lactam cover used in inpatients.",
    ["کوتریموکسازول در پیلونفریت اگر مقاومت محلی پایین باشد قابل قبول است.",
     "پاسخ صحیح (کلید تصحیح‌شده) — نیتروفورانتوئین سطح بافتی ندارد و پیلونفریت را درمان نمی‌کند.",
     "سیپروفلوکساسین خط اول سرپایی پیلونفریت است، نه داروی نامناسب.",
     "آمپی‌سیلین-سولباکتام پوشش بستری معتبری است، هرچند مقاومت آمپی‌سیلین تنها بالاست."],
    ["Co-trimoxazole is acceptable in pyelonephritis if local resistance is low.",
     "Correct (key corrected) — nitrofurantoin has no tissue level and does not treat pyelonephritis.",
     "Ciprofloxacin is first-line outpatient therapy for pyelonephritis, not the inappropriate drug.",
     "Ampicillin-sulbactam is a valid inpatient cover, even though ampicillin alone has high resistance."],
    "**تب = پیلونفریت. نیتروفورانتوئین را همان‌جا کنار بگذار.**",
    "Fever means pyelonephritis. Put nitrofurantoin down at once.",
    REFS_CYS)

add("book:515", "vignette", "medium",
    "**سیستیت بدون تب: نیتروفورانتوئین ۵ تا ۷ روز. سیپروفلوکساسین رزرو است.**",
    "Afebrile cystitis: nitrofurantoin for 5 to 7 days. Ciprofloxacin is reserved.",
    CYS_FA,
    CYS_EN,
    "زن ۲۵ ساله‌ی متأهل، سوزش و تکرار سه روزه، **بدون تب، بدون تهوع**، بدون سابقه‌ی قبلی، غیرباردار. رویکرد؟\n\n"
    "سیستیت بدون عارضه‌ی کلاسیک. کشت‌اول لازم نیست. سیپروفلوکساسین سه‌روزه مؤثر است ولی IDSA آن را **رزرو** کرده (collateral damage و FDA warning). کوتریموکسازول **ده‌روزه** هم بیش‌درمانی است — دوره‌ی استاندارد ۳ روز است.\n\n"
    "نیتروفورانتوئین ۵ روز (در برخی متون تا ۷ روز) خط اول است. عدد «۷-۰» صورت سؤال، نویز استخراج «۵–۷» است؛ معنا همان دوره‌ی کوتاه نیتروفورانتوئین است.",
    "A 25-year-old married woman, three days of dysuria and frequency, NO FEVER, NO NAUSEA, no previous episode, not pregnant. The approach?\n\n"
    "Classical uncomplicated cystitis. Culture-first is not required. Three days of ciprofloxacin works but IDSA has RESERVED it (collateral damage and the FDA warning). TEN days of co-trimoxazole is also over-treatment — the standard course is 3 days.\n\n"
    "Nitrofurantoin for 5 days (in some texts up to 7) is first-line. The '0–7' in the stem is extraction noise for '5–7'; the meaning is a short nitrofurantoin course.",
    ["کشت‌اول در سیستیت تیپیک زن سالم لازم نیست و درمان را عقب می‌اندازد.",
     "سیپروفلوکساسین مؤثر است ولی رزرو است و خط اول نیست.",
     "کوتریموکسازول ده‌روزه بیش‌درمانی است؛ دوره‌ی استاندارد سه روز است.",
     "پاسخ صحیح — نیتروفورانتوئین ۵ تا ۷ روز خط اول سیستیت بدون عارضه است."],
    ["Culture-first is not needed in typical cystitis in a healthy woman and it delays treatment.",
     "Ciprofloxacin works but is reserved and is not first-line.",
     "Ten days of co-trimoxazole is over-treatment; the standard course is three days.",
     "Correct — nitrofurantoin for 5 to 7 days is first-line for uncomplicated cystitis."],
    "**سیستیت ساده: نیترو ۵ روز. کینولون را برای پیلونفریت و پروستات نگه دار.**",
    "Simple cystitis: nitrofurantoin for 5 days. Save the quinolone for pyelonephritis and the prostate.",
    REFS_CYS)

add("book:516", "recall", "medium",
    "**کمترین آسیب جانبی به فلور روده: نیتروفورانتوئین.**",
    "The least collateral damage to bowel flora: nitrofurantoin.",
    CYS_FA,
    CYS_EN,
    "زن جوان، سیستیت ساده، می‌پرسد کدام دارو **کمترین collateral damage** را به فلور گوارشی و کمترین خطر اسهال آنتی‌بیوتیکی دارد.\n\n"
    "نیتروفورانتوئین تقریباً فقط در ادرار غلیظ می‌شود و به روده و بافت نمی‌رسد؛ فلور کولون را به‌هم نمی‌زند و C. difficile نادر است. سیپروفلوکساسین، کوتریموکسازول و به‌ویژه آمپی‌سیلین هر سه فلور روده را درو می‌کنند. آمپی‌سیلین بدنام‌ترین عامل اسهال آنتی‌بیوتیکی در این فهرست است.",
    "A young woman, simple cystitis; the question asks which drug does THE LEAST COLLATERAL DAMAGE to gut flora and carries the lowest risk of antibiotic-associated diarrhoea.\n\n"
    "Nitrofurantoin concentrates almost only in urine and does not reach bowel or tissue; it leaves colonic flora alone and C. difficile is rare. Ciprofloxacin, co-trimoxazole and especially ampicillin all scythe through bowel flora. Ampicillin is the most notorious cause of antibiotic-associated diarrhoea on this list.",
    ["پاسخ صحیح — نیتروفورانتوئین به روده نمی‌رسد و کمترین آسیب جانبی را دارد.",
     "سیپروفلوکساسین از بدنام‌ترین داروها از نظر collateral damage و C. difficile است.",
     "کوتریموکسازول فلور روده را تغییر می‌دهد و خط اول «کم‌آسیب» نیست.",
     "آمپی‌سیلین کلاسیک‌ترین عامل اسهال آنتی‌بیوتیکی در این فهرست است."],
    ["Correct — nitrofurantoin does not reach the bowel and does the least collateral damage.",
     "Ciprofloxacin is among the most notorious drugs for collateral damage and C. difficile.",
     "Co-trimoxazole alters bowel flora and is not the 'low-damage' first choice.",
     "Ampicillin is the most classic cause of antibiotic-associated diarrhoea on this list."],
    "**اگر سؤال «کمترین آسیب فلور» بود، جواب نیتروفورانتوئین است — چون اصلاً به روده نمی‌رود.**",
    "If the question is 'least flora damage', the answer is nitrofurantoin — because it never reaches the bowel.",
    REFS_CYS)

add("book:521", "recall", "medium",
    "**تک‌دوز کلاسیک مال گونوره، فارنژیت استرپ و سیفلیس اولیه است — نه سیستیت.**",
    "The classic single dose belongs to gonorrhoea, strep pharyngitis and primary syphilis — not to cystitis.",
    CYS_FA + [
        "یورتریت گونوکوکی: سفتریاکسون عضلانی تک‌دوز.",
        "فارنژیت استرپتوکوکی: پنی‌سیلین بنزاتین عضلانی تک‌دوز (جایگزین ۱۰ روز خوراکی).",
        "سیفلیس اولیه: بنزاتین پنی‌سیلین ۲٫۴ میلیون تک‌دوز.",
        "سیستیت: دوره‌ی استاندارد ۳ تا ۵ روز است. فسفومایسین ۳ گرم تک‌دوز استثنای امروزی است که این کتاب نمی‌پرسد.",
    ],
    CYS_EN + [
        "Gonococcal urethritis: a single intramuscular dose of ceftriaxone.",
        "Streptococcal pharyngitis: a single intramuscular dose of benzathine penicillin (the alternative to 10 oral days).",
        "Primary syphilis: benzathine penicillin 2.4 million units as a single dose.",
        "Cystitis: the standard course is 3 to 5 days. Fosfomycin 3 g once is the modern exception this book is not asking about.",
    ],
    "«در همه‌ی موارد زیر درمان تک‌دوز است به‌استثناء».\n\n"
    "سه بیماری کلاسیک تک‌دوز دارند: گونوره (سفتریاکسون)، فارنژیت استرپ (بنزاتین پنی‌سیلین)، سیفلیس اولیه (بنزاتین ۲٫۴ میلیون). سیستیت در متون همین کتاب **۳ تا ۵ روز** است.\n\n"
    "نکته‌ی امروزی برای خودتان: **فسفومایسین ۳ گرم تک‌دوز** امروز رژیم معتبر سیستیت است. اگر در آزمونی فسفومایسین در گزینه بود، تک‌دوز دیگر ممیزه نیست. این سؤال همان تمایز کلاسیک را می‌خواهد.",
    "'In all of the following, treatment is a single dose EXCEPT'.\n\n"
    "Three diseases classically have a single dose: gonorrhoea (ceftriaxone), strep pharyngitis (benzathine penicillin), primary syphilis (benzathine 2.4 million). Cystitis in this book's texts is 3 TO 5 DAYS.\n\n"
    "A modern note for yourself: FOSFOMYCIN 3 g ONCE is now a valid cystitis regimen. If an exam lists fosfomycin, 'single dose' is no longer the discriminator. This question wants the classical distinction.",
    ["یورتریت گونوکوکی با سفتریاکسون عضلانی تک‌دوز درمان می‌شود.",
     "فارنژیت استرپتوکوکی با بنزاتین پنی‌سیلین تک‌دوز درمان می‌شود.",
     "سیفلیس اولیه بنزاتین پنی‌سیلین ۲٫۴ میلیون تک‌دوز می‌گیرد.",
     "پاسخ صحیح — سیستیت در این منبع دوره‌ی چندروزه دارد، نه تک‌دوز کلاسیک."],
    ["Gonococcal urethritis is treated with a single intramuscular dose of ceftriaxone.",
     "Streptococcal pharyngitis is treated with a single dose of benzathine penicillin.",
     "Primary syphilis receives benzathine penicillin 2.4 million units once.",
     "Correct — in this source cystitis is a several-day course, not a classical single dose."],
    "**تک‌دوز امتحانی: گونوره، استرپ گلو، سیفلیس. سیستیت را ۳ تا ۵ روز بده.**",
    "The examination single-doses: gonorrhoea, strep throat, syphilis. Give cystitis 3 to 5 days.",
    REFS_CYS)

add("book:524", "recall", "easy",
    "**نشانی که سیستیت را به پیلونفریت بدل می‌کند تب است — نه رنگ ادرار و نه درد سوپراپوبیک.**",
    "The finding that turns cystitis into pyelonephritis is fever — not the colour of the urine and not suprapubic pain.",
    CYS_FA,
    CYS_EN,
    "سوزش و تکرر دارد؛ کدام نشانه بیشتر به نفع صعود به پیلونفریت است؟\n\n"
    "**تب** یعنی پاسخ سیستمیک و درگیری پارانشیم. فوریت و درد سوپراپوبیک علائم خود مثانه‌اند. پررنگ شدن ادرار غلیظ شدن است نه عفونت بالا.\n\n"
    "بقیه‌ی علائم هشدار پیلونفریت که باید بدانید: درد پهلو، تندرنس زاویه‌ی دنده‌ای-مهره‌ای، تهوع و استفراغ، لرز تکان‌دهنده.",
    "He has dysuria and frequency; which finding most suggests ascent to pyelonephritis?\n\n"
    "FEVER means a systemic response and parenchymal involvement. Urgency and suprapubic pain are symptoms of the bladder itself. Darker urine is concentration, not upper-tract infection.\n\n"
    "The other pyelonephritis warning symptoms you must know: flank pain, costovertebral-angle tenderness, nausea and vomiting, shaking rigors.",
    ["پررنگ شدن ادرار غلیظ شدن است، نه صعود عفونت.",
     "فوریت علامت سیستیت است نه پیلونفریت.",
     "درد سوپراپوبیک درد خود مثانه است.",
     "پاسخ صحیح — تب یعنی پاسخ سیستمیک و درگیری کلیه."],
    ["Darker urine is concentration, not ascent of infection.",
     "Urgency is a cystitis symptom, not a pyelonephritis one.",
     "Suprapubic pain is pain from the bladder itself.",
     "Correct — fever means a systemic response and renal involvement."],
    "**مثانه درد پایین می‌دهد. کلیه تب و پهلو می‌دهد.**",
    "The bladder hurts low down. The kidney gives fever and a flank.",
    REFS_CYS)

# =========================================================== special / pregnancy
add("book:518", "vignette", "medium",
    "**ASB سه‌ماهه‌ی اول بارداری: نیتروفورانتوئین خوراکی. کوتریموکسازول را نده.**",
    "First-trimester ASB in pregnancy: oral nitrofurantoin. Do not give co-trimoxazole.",
    PREG_FA,
    PREG_EN,
    "باردار ۳ ماهه، کشت روتین اشرشیا کلی، **بدون علامت و بدون تب**.\n\n"
    "این تنها موقعیت شایع است که ASB **حتماً** درمان می‌شود — چون یک‌چهارم به پیلونفریت می‌روند و خطر زایمان زودرس بالا می‌رود.\n\n"
    "در سه‌ماهه‌ی اول کوتریموکسازول آنتاگونیست فولات است. جنتامایسین تزریقی برای زن بی‌علامت بیش‌درمانی و اتوتوکسیک برای جنین است. نیتروفورانتوئین خوراکی انتخاب عملی این گزینه‌هاست (برخی منابع در سه‌ماهه‌ی اول بتالاکتام را ترجیح می‌دهند؛ آن گزینه این‌جا نیست).",
    "A woman 3 months pregnant, a routine E. coli culture, NO SYMPTOMS AND NO FEVER.\n\n"
    "This is the one common situation in which ASB MUST be treated — because a quarter progress to pyelonephritis and the risk of preterm labour rises.\n\n"
    "In the first trimester co-trimoxazole is a folate antagonist. Injectable gentamicin is over-treatment for an asymptomatic woman and ototoxic to the fetus. Oral nitrofurantoin is the practical choice among these options (some sources prefer a beta-lactam in the first trimester; that option is not here).",
    ["باکتریوری بارداری حتی بی‌علامت درمان می‌شود؛ «نیازی نیست» خطرناک است.",
     "کوتریموکسازول در سه‌ماهه‌ی اول آنتاگونیست فولات است.",
     "جنتامایسین تزریقی برای ASB بیش‌درمانی و برای جنین اتوتوکسیک است.",
     "پاسخ صحیح — نیتروفورانتوئین خوراکی درمان استاندارد ASB اوایل بارداری در این گزینه‌هاست."],
    ["Bacteriuria in pregnancy is treated even if asymptomatic; 'not needed' is dangerous.",
     "Co-trimoxazole is a folate antagonist in the first trimester.",
     "Injectable gentamicin is over-treatment for ASB and ototoxic to the fetus.",
     "Correct — oral nitrofurantoin is the standard treatment of early-pregnancy ASB among these options."],
    "**باردار + کشت مثبت = درمان کن، حتی اگر حالش خوب است.** سه‌ماهه‌ی اول: نه TMP-SMX.",
    "Pregnant plus a positive culture means treat, even if she feels well. First trimester: no TMP-SMX.",
    REFS_PR)

add("book:519", "vignette", "hard",
    "**سیستیت هفته‌ی ۳۰: سفیکسیم. نیترو نزدیک ترم و کینولون در بارداری خط می‌خورند.**",
    "Cystitis at week 30: cefixime. Nitrofurantoin near term and a quinolone in pregnancy are struck out.",
    PREG_FA,
    PREG_EN,
    "باردار ۳۰ هفته، علائم سیستیت، پیوری، اشرشیا کلی حساس به نیترو و سیپرو و سفیکسیم و جنتامایسین.\n\n"
    "حساسیت آزمایشگاه ≠ انتخاب بالینی.\n\n"
    "- سیپروفلوکساسین در بارداری روی غضروف جنین اثر می‌گذارد → حذف.\n"
    "- جنتامایسین تزریقی برای سیستیت بیش‌درمانی و اتوتوکسیک است → حذف.\n"
    "- نیتروفورانتوئین نزدیک ترم خطر همولیز نوزاد (به‌ویژه G6PD) دارد؛ هفته‌ی ۳۰ در مرز احتیاط کتاب است.\n"
    "- **سفیکسیم** بتالاکتام خوراکی بی‌خطر در بارداری است و برای سیستیت هفته‌ی ۳۰ انتخاب تمیز این فهرست است.",
    "A woman at 30 weeks, symptoms of cystitis, pyuria, E. coli sensitive to nitrofurantoin, ciprofloxacin, cefixime and gentamicin.\n\n"
    "Laboratory susceptibility ≠ the clinical choice.\n\n"
    "- Ciprofloxacin in pregnancy affects fetal cartilage → out.\n"
    "- Injectable gentamicin is over-treatment for cystitis and ototoxic → out.\n"
    "- Nitrofurantoin near term risks neonatal haemolysis (especially G6PD); week 30 sits on this book's caution line.\n"
    "- CEFIXIME is an oral beta-lactam safe in pregnancy and is the clean choice for cystitis at week 30 on this list.",
    ["نیتروفورانتوئین نزدیک ترم به‌خاطر همولیز نوزاد احتیاط دارد.",
     "سیپروفلوکساسین در تمام بارداری ممنوع است.",
     "پاسخ صحیح — سفیکسیم بتالاکتام خوراکی بی‌خطر و مناسب سیستیت اواخر بارداری است.",
     "جنتامایسین تزریقی برای سیستیت بیش‌درمانی است."],
    ["Nitrofurantoin near term carries a caution because of neonatal haemolysis.",
     "Ciprofloxacin is forbidden throughout pregnancy.",
     "Correct — cefixime is a safe oral beta-lactam and is suitable for late-pregnancy cystitis.",
     "Injectable gentamicin is over-treatment for cystitis."],
    "**حساسیت آزمایشگاه را با ایمنی بارداری ضرب کن.** هفته‌ی ۳۰: سفیکسیم، نه کینولون و نه نیتروِ نزدیک‌ترم.",
    "Multiply laboratory susceptibility by pregnancy safety. At week 30: cefixime, not a quinolone and not near-term nitrofurantoin.",
    REFS_PR)

add("book:520", "vignette", "hard",
    "**UTI پس از بیوپسی مثانه که به سفالوسپورین و کینولون جواب نمی‌دهد ← انتروکوک: آمپی‌سیلین + جنتامایسین.**",
    "A UTI after bladder biopsy that ignores cephalosporins and quinolones is enterococcus: ampicillin plus gentamicin.",
    ASB_FA + [
        "انتروکوک فلور روده است و پس از دست‌کاری مجرا به میدان می‌آید.",
        "انتروکوک به سفالوسپورین‌ها مقاومت ذاتی دارد.",
        "آمینوگلیکوزید تنها باکتریواستاتیک/ضعیف است؛ برای کشتن، سینرژی با بتالاکتام لازم است.",
        "کینولون‌ها پوشش انتروکوک قابل اعتمادی ندارند.",
        "آمپی‌سیلین + جنتامایسین رژیم کلاسیک سینرژیک انتروکوک است.",
    ],
    ASB_EN + [
        "Enterococcus is bowel flora and steps forward after the urethra is instrumented.",
        "Enterococcus is intrinsically resistant to cephalosporins.",
        "An aminoglycoside alone is bacteriostatic or weak; killing needs synergy with a beta-lactam.",
        "Quinolones do not reliably cover enterococcus.",
        "Ampicillin plus gentamicin is the classic synergistic enterococcal regimen.",
    ],
    "مرد ۶۰ ساله با کانسر مثانه، سیستوسکوپی و سوند و **بیوپسی مثانه**، بعد UTI که به سفالوسپورین نسل سه، آمینوگلیکوزید تنها و کینولون جواب نداده.\n\n"
    "⚠️ **این امضای انتروکوک است.** سه سرنخ با هم:\n"
    "۱. دست‌کاری اخیر مجرا\n"
    "۲. مقاومت ذاتی به سفالوسپورین\n"
    "۳. شکست کینولون و آمینوگلیکوزید تنها\n\n"
    "درمان: **آمپی‌سیلین + جنتامایسین** — بتالاکتام دیواره را باز می‌کند تا آمینوگلیکوزید وارد شود (سینرژی). کوتریموکسازول در بدن روی انتروکوک قابل اعتماد نیست. تیکارسیلین/تازوباکتام برای E. faecalis ضعیف‌تر از آمپی‌سیلین است.",
    "A 60-year-old man with bladder cancer, cystoscopy and a catheter and a BLADDER BIOPSY, then a UTI that has ignored a third-generation cephalosporin, an aminoglycoside alone and a quinolone.\n\n"
    "WARNING: THIS IS THE SIGNATURE OF ENTEROCOCCUS. Three clues together:\n"
    "1. Recent instrumentation of the urethra\n"
    "2. Intrinsic resistance to cephalosporins\n"
    "3. Failure of a quinolone and of an aminoglycoside alone\n\n"
    "Treatment: AMPICILLIN PLUS GENTAMICIN — the beta-lactam opens the wall so the aminoglycoside can enter (synergy). Co-trimoxazole is not reliable against enterococcus in the body. Ticarcillin/tazobactam is weaker than ampicillin for E. faecalis.",
    ["کوتریموکسازول در بدن روی انتروکوک قابل اعتماد نیست.",
     "تیکارسیلین/تازوباکتام برای فکالیس ضعیف‌تر از آمپی‌سیلین است.",
     "پاسخ صحیح — آمپی‌سیلین + جنتامایسین رژیم سینرژیک کلاسیک انتروکوک پس از دست‌کاری مجراست.",
     "همه‌ی موارد درست نیست؛ فقط رژیم آمپی‌سیلین و جنتامایسین این الگو را می‌پوشاند."],
    ["Co-trimoxazole is not reliable against enterococcus in the body.",
     "Ticarcillin/tazobactam is weaker than ampicillin for E. faecalis.",
     "Correct — ampicillin plus gentamicin is the classic synergistic regimen for enterococcus after instrumentation.",
     "Not all of the above; only ampicillin plus gentamicin covers this pattern."],
    "**دست‌کاری مجرا + شکست سفالوسپورین = انتروکوک.** آمپی‌سیلین را با جنتامایسین جفت کن.",
    "Urethral instrumentation plus cephalosporin failure means enterococcus. Pair ampicillin with gentamicin.",
    REFS_ASB)

add("book:522", "vignette", "medium",
    "**عود پروستاتیت مزمن باکتریال ← همان دارو را ۱۲ هفته بده، نه دو دارو و نه تزریقی کوتاه.**",
    "Relapsed chronic bacterial prostatitis: give the same drug for 12 weeks, not two drugs and not a short intravenous course.",
    [
        "پروستات یک غده‌ی چرب با نفوذ دارویی بد است؛ دوره‌ی کوتاه شکست می‌خورد.",
        "پروستاتیت حاد: ۲ تا ۴ هفته. پروستاتیت مزمن باکتریال: **حداقل ۴ تا ۶ هفته**.",
        "⚠️ **عود پس از دوره‌ی استاندارد یعنی نفوذ ناکافی زمانی، نه لزوماً مقاومت.**",
        "پاسخ منطقی: **همان کلاس (معمولاً فلوروکینولون) را تا ۱۲ هفته ادامه بده.**",
        "دو آنتی‌بیوتیک خوراکی ۴ هفته همان دوره‌ی شکست‌خورده را تکرار می‌کند.",
        "بالا بردن دوز، سطح داخل پروستات را معجزه‌آسا زیاد نمی‌کند.",
        "ترکیب خوراکی و تزریقی ۱۴ روز برای یک بیماری مزمن مضحکانه کوتاه است.",
        "آلفا بلوکر و NSAID علامت را کم می‌کنند ولی عفونت را ریشه‌کن نمی‌کنند.",
        "اگر ۱۲ هفته هم شکست خورد، آن‌وقت کشت و حساسیت و گاهی رزکسیون مطرح می‌شود.",
        "تشخیص قطعی با آزمون ۴لیوان Meares–Stamey است؛ درمان را روی حدس کوتاه نبند.",
    ],
    [
        "The prostate is a fatty gland with poor drug penetration; a short course fails.",
        "Acute prostatitis: 2 to 4 weeks. Chronic bacterial prostatitis: AT LEAST 4 TO 6 WEEKS.",
        "WARNING: RELAPSE AFTER A STANDARD COURSE MEANS INSUFFICIENT TIME OF PENETRATION, NOT NECESSARILY RESISTANCE.",
        "The logical answer: CONTINUE THE SAME CLASS (usually a fluoroquinolone) FOR 12 WEEKS.",
        "Two oral antibiotics for 4 weeks repeats the course that already failed.",
        "Raising the dose does not magically raise the level inside the prostate.",
        "A 14-day mix of oral and intravenous drug is absurdly short for a chronic disease.",
        "An alpha-blocker and an NSAID ease symptoms but do not eradicate infection.",
        "If 12 weeks also fails, then culture and susceptibility and sometimes resection come into play.",
        "Definitive diagnosis is the 4-glass Meares–Stamey test; do not hang treatment on a short guess.",
    ],
    "مرد ۵۴ ساله با پروستاتیت مزمن باکتریال دوره‌ی استاندارد گرفته و **دو ماه بعد عود** کرده.\n\n"
    "پروستات نفوذ دارویی بدی دارد. شکست زودهنگام معمولاً یعنی **مدت کافی نبوده**، نه اینکه دارو عوض شود. فلوروکینولون‌ها (سیپرو، لووفلوکساسین) بهترین نفوذ را دارند و در عود، همان کلاس تا **۱۲ هفته** ادامه می‌یابد.\n\n"
    "دو دارو برای ۴ هفته همان شکست را تکرار می‌کند. افزایش دوز سمّیت می‌آورد نه نفوذ. ۱۴ روز تزریقی برای بیماری مزمن کوتاه است.",
    "A 54-year-old man received a standard course for chronic bacterial prostatitis and RELAPSED TWO MONTHS LATER.\n\n"
    "The prostate has poor drug penetration. Early failure usually means THE DURATION WAS TOO SHORT, not that the drug must change. Fluoroquinolones (ciprofloxacin, levofloxacin) penetrate best, and at relapse the same class is continued for 12 WEEKS.\n\n"
    "Two drugs for 4 weeks repeats the same failure. Raising the dose adds toxicity, not penetration. Fourteen intravenous days is short for a chronic disease.",
    ["دو آنتی‌بیوتیک خوراکی ۴ هفته همان دوره‌ی شکست‌خورده را تکرار می‌کند.",
     "افزایش دوز نفوذ داخل پروستات را به‌اندازه‌ی افزایش مدت زیاد نمی‌کند.",
     "ترکیب خوراکی و تزریقی ۱۴ روز برای بیماری مزمن کوتاه است.",
     "پاسخ صحیح — عود یعنی مدت را تا ۱۲ هفته تمدید کنید، نه اینکه کلاس را عوض کنید."],
    ["Two oral antibiotics for 4 weeks repeats the course that already failed.",
     "Raising the dose does not raise prostatic levels the way extending the duration does.",
     "A 14-day mix of oral and intravenous drug is short for a chronic disease.",
     "Correct — relapse means extend the duration to 12 weeks, not change the class."],
    "**پروستات زمان می‌خواهد نه دوز بیشتر.** عود مزمن = ۱۲ هفته.",
    "The prostate wants time, not a bigger dose. Chronic relapse means 12 weeks.",
    [H])

add("book:523", "vignette", "medium",
    "**دیابتی بدحال + گاز در پارانشیم کلیه = پیلونفریت آمفیزماتو. اورژانس جراحی است.**",
    "A sick diabetic plus gas in the renal parenchyma is emphysematous pyelonephritis. It is a surgical emergency.",
    [
        "⚠️ **گاز در پارانشیم کلیه یعنی پیلونفریت آمفیزماتو تا خلافش ثابت شود.**",
        "تقریباً همیشه در **دیابتی بدحال** دیده می‌شود.",
        "عامل شایع اشرشیا کلی یا کلبسیلا است که گلوکز را تخمیر و گاز می‌سازد.",
        "تب مقاوم ۷۲ساعته یعنی عفونت از آنتی‌بیوتیک تنها فرمان نمی‌برد.",
        "درمان: احیا + آنتی‌بیوتیک وسیع + **درناژ Percutaneous یا نفرکتومی**.",
        "نکروز پاپیلری هم در دیابت هست ولی گاز نمی‌سازد؛ هماچوری و تکه بافت در ادرار می‌دهد.",
        "مقاومت آنتی‌بیوتیکی تب را نگه می‌دارد ولی گاز را توضیح نمی‌دهد.",
        "آبسه‌ی اطراف کلیه ممکن است گاز داشته باشد، ولی صورت سؤال صریح می‌گوید گاز **در پارانشیم**.",
        "سی‌تی بهترین تصویر است؛ گرافی ساده وقتی گاز زیاد باشد کافی است.",
        "مرگ بدون جراحی یا درناژ بالا است — این را با پیلونفریت معمولی عوضی نگیرید.",
    ],
    [
        "WARNING: GAS IN THE RENAL PARENCHYMA IS EMPHYSEMATOUS PYELONEPHRITIS UNTIL PROVEN OTHERWISE.",
        "It is seen almost always in a SICK DIABETIC.",
        "The usual organisms are E. coli or Klebsiella, which ferment glucose and make gas.",
        "Fever still present at 72 hours means the infection is not obeying antibiotics alone.",
        "Treatment: resuscitation plus broad antibiotics plus PERCUTANEOUS DRAINAGE OR NEPHRECTOMY.",
        "Papillary necrosis also occurs in diabetes but does not make gas; it sheds blood and tissue into the urine.",
        "Antibiotic resistance keeps the fever going but does not explain the gas.",
        "A perinephric abscess may contain gas, but the stem is explicit: gas IN THE PARENCHYMA.",
        "CT is the best image; a plain film is enough when the gas is plentiful.",
        "Death without surgery or drainage is high — do not confuse this with ordinary pyelonephritis.",
    ],
    "زن ۶۲ ساله‌ی دیابتی، تب ۳۹٫۳، WBC ۲۵۰۰۰، گلبول سفید فراوان در ادرار، پس از ۷۲ ساعت سفتریاکسون هنوز تب‌دار، و **گاز در پارانشیم کلیه‌ها**.\n\n"
    "این تعریف پیلونفریت آمفیزماتو است. دیابت + گاز + بدحالی سه‌گانه‌ی تشخیص‌اند. نکروز پاپیلری گاز ندارد. مقاومت دارویی گاز نمی‌سازد. آبسه‌ی اطراف کلیه بیرون پارانشیم است.\n\n"
    "اقدام بعدی در بالین: سی‌تی برای درجه‌بندی، اورولوژی برای درناژ یا نفرکتومی، و ارتقای آنتی‌بیوتیک. سفتریاکسون تنها اینجا کافی نیست.",
    "A 62-year-old diabetic woman, fever 39.3, WBC 25,000, heavy pyuria, still febrile after 72 hours of ceftriaxone, and GAS IN THE RENAL PARENCHYMA.\n\n"
    "That is the definition of emphysematous pyelonephritis. Diabetes plus gas plus being sick is the diagnostic triad. Papillary necrosis has no gas. Drug resistance does not make gas. A perinephric abscess sits outside the parenchyma.\n\n"
    "The next bedside steps: a CT for staging, urology for drainage or nephrectomy, and escalation of antibiotics. Ceftriaxone alone is not enough here.",
    ["نکروز پاپیلری گاز نمی‌سازد.",
     "مقاومت آنتی‌بیوتیکی تب را نگه می‌دارد ولی گاز پارانشیم را توضیح نمی‌دهد.",
     "آبسه‌ی اطراف کلیه بیرون پارانشیم است؛ صورت سؤال گاز داخل پارانشیم را گفته.",
     "پاسخ صحیح — گاز در پارانشیم کلیه‌ی دیابتی یعنی پیلونفریت آمفیزماتو."],
    ["Papillary necrosis does not make gas.",
     "Antibiotic resistance keeps the fever going but does not explain parenchymal gas.",
     "A perinephric abscess sits outside the parenchyma; the stem said gas inside it.",
     "Correct — gas in a diabetic kidney's parenchyma is emphysematous pyelonephritis."],
    "**دیابت + گاز کلیه = آمفیزماتو.** آنتی‌بیوتیک تنها کافی نیست؛ درناژ یا نفرکتومی.",
    "Diabetes plus renal gas is emphysematous. Antibiotics alone are not enough; drain or remove the kidney.",
    [H])

add("book:526", "vignette", "hard",
    "**پیلونفریت انسدادی هفته‌ی ۳۸: سفتریاکسون + جنتامایسین وریدی. نیترو و کوتریموکسازول خط می‌خورند.**",
    "Obstructed pyelonephritis at week 38: intravenous ceftriaxone plus gentamicin. Nitrofurantoin and co-trimoxazole are struck out.",
    PREG_FA,
    PREG_EN,
    "حامله‌ی ۳۸ هفته، درد فلانک راست و تب، سونو: **انسداد حالب و هیدرونفروز راست**.\n\n"
    "این پیلونفریت ساده نیست؛ **پیلونفریت انسدادی نزدیک ترم** است — اورژانس مشترک عفونی و زنان و اورولوژی.\n\n"
    "- کوتریموکسازول وریدی نزدیک ترم → کرن‌ایکتروس.\n"
    "- جنتامایسین تنها پوشش ناقص و اتوتوکسیک است.\n"
    "- نیتروفورانتوئین وریدی وجود عملی ندارد و پیلونفریت/انسداد را نمی‌پوشاند.\n"
    "- **سفتریاکسون + جنتامایسین وریدی** پوشش گرم‌منفی وسیع برای عفونت انسدادی بدحال است. هم‌زمان باید انسداد رفع شود (استنت یا نفروستومی) و زایمان در تصمیم باشد.",
    "A woman at 38 weeks, right flank pain and fever, ultrasound: RIGHT URETERIC OBSTRUCTION AND HYDRONEPHROSIS.\n\n"
    "This is not simple pyelonephritis; it is OBSTRUCTED PYELONEPHRITIS NEAR TERM — a shared emergency of infectious diseases, obstetrics and urology.\n\n"
    "- Intravenous co-trimoxazole near term → kernicterus.\n"
    "- Gentamicin alone is incomplete cover and ototoxic.\n"
    "- Intravenous nitrofurantoin is not a practical drug and does not cover pyelonephritis or obstruction.\n"
    "- CEFTRIAXONE PLUS GENTAMICIN INTRAVENOUSLY is broad Gram-negative cover for a sick obstructed infection. At the same time the obstruction must be relieved (a stent or a nephrostomy) and delivery is on the table.",
    ["کوتریموکسازول نزدیک ترم خطر کرن‌ایکتروس دارد.",
     "جنتامایسین تنها برای پیلونفریت انسدادی پوشش ناکافی است.",
     "پاسخ صحیح — سفتریاکسون به‌علاوه‌ی جنتامایسین پوشش وریدی وسیع این اورژانس است.",
     "نیتروفورانتوئین پیلونفریت و انسداد را درمان نمی‌کند."],
    ["Co-trimoxazole near term risks kernicterus.",
     "Gentamicin alone is inadequate cover for obstructed pyelonephritis.",
     "Correct — ceftriaxone plus gentamicin is the broad intravenous cover for this emergency.",
     "Nitrofurantoin does not treat pyelonephritis or obstruction."],
    "**انسداد + تب در بارداری = وریدی وسیع + رفع انسداد.** نیترو این‌جا هیچ کاره است.",
    "Obstruction plus fever in pregnancy means broad intravenous cover plus relief of the obstruction. Nitrofurantoin has no job here.",
    REFS_PR)

add("book:527", "vignette", "medium",
    "**پیلونفریت بارداری هفته‌ی ۳۰: آمپی‌سیلین + جنتامایسین وریدی. وانکومایسین جایی ندارد.**",
    "Pyelonephritis in pregnancy at week 30: intravenous ampicillin plus gentamicin. Vancomycin has no place.",
    PREG_FA,
    PREG_EN,
    "۲۵ ساله، بارداری ۳۰ هفته، لرز تکان‌دهنده، سوزش ادرار، تندرنس فلانک راست، تب ۳۸٫۶، نبض ۸۵، WBC ادرار many.\n\n"
    "این پیلونفریت حاد بارداری است: بستری، مایع، و آنتی‌بیوتیک **وریدی** تا ۴۸ ساعت بی‌تب شود، بعد خوراکی تا تکمیل ۱۰–۱۴ روز.\n\n"
    "رژیم کلاسیک کتاب‌های ایرانی و Harrison نسل قبل: **آمپی‌سیلین + جنتامایسین** (انتروکوک + گرم‌منفی). امروز سفتریاکسون تنها جایگزین رایج است.\n\n"
    "سفتریاکسون + وانکومایسین پوشش MRSA می‌دهد که این تابلو نمی‌خواهد. نیتروفورانتوئین خوراکی پیلونفریت را درمان نمی‌کند. وانکومایسین تنها گرم‌منفی را نمی‌پوشاند.",
    "A 25-year-old, 30 weeks pregnant, shaking rigors, dysuria, right flank tenderness, fever 38.6, pulse 85, urine WBC many.\n\n"
    "This is acute pyelonephritis of pregnancy: admit, fluids, and INTRAVENOUS antibiotics until she has been afebrile for 48 hours, then oral drugs to complete 10–14 days.\n\n"
    "The classic regimen of Iranian books and earlier Harrison: AMPICILLIN PLUS GENTAMICIN (enterococcus plus Gram-negatives). Ceftriaxone alone is the common modern substitute.\n\n"
    "Ceftriaxone plus vancomycin adds MRSA cover this picture does not need. Oral nitrofurantoin does not treat pyelonephritis. Vancomycin alone misses Gram-negatives.",
    ["وانکومایسین در کنار سفتریاکسون پوشش MRSA بی‌مورد به این تابلو اضافه می‌کند.",
     "نیتروفورانتوئین خوراکی پیلونفریت را درمان نمی‌کند.",
     "پاسخ صحیح — آمپی‌سیلین + جنتامایسین رژیم کلاسیک وریدی پیلونفریت بارداری است.",
     "وانکومایسین تنها گرم‌منفی روده‌ای را نمی‌پوشاند."],
    ["Vancomycin beside ceftriaxone adds needless MRSA cover to this picture.",
     "Oral nitrofurantoin does not treat pyelonephritis.",
     "Correct — ampicillin plus gentamicin is the classic intravenous regimen for pyelonephritis in pregnancy.",
     "Vancomycin alone misses enteric Gram-negatives."],
    "**پیلونفریت بارداری = بستری + وریدی.** رژیم کتاب: آمپی‌سیلین + جنتامایسین.",
    "Pyelonephritis in pregnancy means admit plus intravenous drugs. The book regimen: ampicillin plus gentamicin.",
    REFS_PR)

json.dump(L, io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'lessons_book59.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('batch 59 lessons:', len(L))
