# -*- coding: utf-8 -*-
"""English stems for batch 64 (remaining CNS). Numbers carried through."""
EN28 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    EN28[idx] = {"stem_en": stem, "options_en": options}


add(133, "A 20-year-old soldier presents with headache, fever, neck stiffness and a reduced conscious level. Initially he has irregular breathing, bradycardia and a raised blood pressure. Suspecting bacterial meningitis, which complication explains his findings?",
    ["Raised intracranial pressure", "Intracranial haemorrhage", "Brain abscesses", "Brain herniation"])
add(137, "A 60-year-old man with no underlying disease presents with fever, headache, nausea and vomiting. He has neck stiffness. Which organism is LEAST likely to cause his disease?",
    ["Streptococcus pneumoniae", "Neisseria meningitidis", "Haemophilus influenzae", "Listeria monocytogenes"])
add(138, "A 28-year-old man has had severe fever and headache with repeated vomiting since yesterday. He had head trauma three weeks ago. He is drowsy with neck stiffness. Lumbar puncture shows a bacterial-meningitis CSF. Which organism is more likely?",
    ["Streptococcus pneumoniae", "Escherichia coli", "Pseudomonas aeruginosa", "Listeria monocytogenes"])
add(139, "A 25-year-old is brought in with high fever, headache, vomiting and neck stiffness. He is stuporous. There is no rash; neck stiffness and Kernig's test are positive. CSF points to bacterial meningitis and the CSF culture is positive after two days. Which organism is most prevalent at this age?",
    ["Streptococcus pneumoniae", "Listeria monocytogenes", "Staphylococcus aureus", "Haemophilus influenzae type b"])
add(140, "A 45-year-old woman is admitted with fever, nausea, vomiting and neck stiffness. She drinks alcohol daily and has a basal skull fracture after a head blow. What is the commonest causative organism?",
    ["Pneumococcus", "Meningococcus", "Listeria", "Gram-negative bacilli"])
add(144, "A previously well 35-year-old is brought in with fever and headache since yesterday and has neck stiffness. He had a crash and a head blow 2 weeks ago. What should be done?",
    ["Blood cultures and CSF aspiration and treat according to the CSF",
     "Brain CT then CSF aspiration and treat according to the CSF",
     "Brain CT and blood cultures and start empiric antibiotics at the same time",
     "Blood cultures and CSF aspiration and start empiric antibiotics at the same time"])
add(146, "A 35-year-old man presents with severe headache, nausea and vomiting and a history of frontal and anterior ethmoid sinusitis. Temperature 37 C, heart rate 100, respiratory rate 20. Neck stiffness, a positive Kernig and right hemiparesis. What is the next diagnostic step?",
    ["LP", "EEG", "CT brain", "Blood cultures on two occasions"])
add(147, "A 20-year-old man presents with headache and fever since yesterday and has neck stiffness. He had head trauma three days ago. What is the order of first steps?",
    ["Brain scan — LP — blood cultures — start antibiotics",
     "Blood cultures — brain scan — LP — start antibiotics",
     "Blood cultures — start antibiotics — brain scan — LP",
     "Start antibiotics — brain scan — LP"])
add(148, "A 25-year-old is brought in with fever, drowsiness, headache and a seizure. He is drowsy and febrile but Kernig and Brudzinski are negative. Papilloedema cannot be assessed; the rest of the neurological examination is normal. What is the order of steps?",
    ["Take blood cultures and start empiric antibiotics then CT or MRI",
     "Start empiric antibiotics and do an LP then CT or MRI",
     "Do an LP and CT or MRI then start empiric antibiotics",
     "Do an LP and blood cultures then start empiric antibiotics"])
add(149, "A 45-year-old woman with ovarian cancer is brought in with fever, headache and vomiting since last night. She is drowsy and answers incorrectly. She has neck stiffness. What is recommended?",
    ["Do an LP and start antibiotics within one hour",
     "Start antibiotics then send her for a brain CT",
     "Send her for a brain CT then LP then antibiotics",
     "Take blood cultures and send her for a CT"])
add(150, "A 50-year-old man is brought in with fever, headache, neck stiffness and a conscious level of GCS 8. Fundoscopy shows bilateral papilloedema. What is the correct order?",
    ["Blood cultures, LP, start treatment",
     "Blood cultures, start treatment, brain CT",
     "Blood cultures, LP, a neurology consult",
     "LP, brain CT, treatment"])
add(151, "A 25-year-old develops headache, vomiting and fever 3 days after a crash and probable head trauma. He is drowsy, has fever 39 C and neck stiffness. Suspecting acute bacterial meningitis, which emergency step should be taken?",
    ["An emergency brain CT and antibiotics only after no focal lesion is confirmed",
     "After blood cultures and initial tests, start emergency antibiotics. Then brain CT and LP",
     "Blood cultures and initial tests, then LP, then antibiotics",
     "Because he has acute bacterial meningitis start the first antibiotic dose before anything else"])
add(153, "What is the gold standard for diagnosing tuberculous meningitis?",
    ["CSF culture for tuberculosis", "CSF PCR", "CSF smear for acid-fast bacilli", "All of the above"])
add(154, "A 24-year-old man presents with fever, headache, nausea and vomiting and has neck stiffness. CSF: white cells 2500 with neutrophil predominance, glucose 32 mg/dl, protein 150 mg/dl, pressure 200 mmH2O. Which diagnosis is raised?",
    ["Aseptic meningitis", "Bacterial meningitis", "Herpes encephalitis", "A brain abscess"])
add(155, "A 24-year-old woman with fever for two days and severe headache with projectile vomiting since last night is brought in drowsy. She has neck stiffness. After fundoscopy an LP is done. Given the CSF analysis, what is the most likely agent?",
    ["Mycobacterium tuberculosis", "Herpes simplex virus", "Haemophilus influenzae", "Streptococcus pneumoniae"])
add(157, "A 50-year-old develops headache, fever and vomiting after a crash and a basal skull fracture. CSF: WBC 1000 with PMN 80% and MN 20%, glucose 20 mg/dl, protein 200 mg/dl. Which agent is more responsible?",
    ["Streptococcus pneumoniae", "Neisseria meningococcus", "HSV", "Haemophilus influenzae"])
add(158, "A 27-year-old man has had severe fever and headache with repeated vomiting for 2 days and is brought in drowsy. He has neck stiffness and petechial and purpuric rashes on the trunk and limbs. LP: WBC 1050 with PMN 80% L 20, Glu 32 mg/dl, protein 150 mg/dl, blood glucose 115 mg/dl. A brother had a similar illness a few days ago. Which pathogen is more likely on the CSF smear?",
    ["Gram-negative cocci", "Gram-positive cocci", "Gram-negative bacilli", "Gram-positive bacilli"])
add(160, "A 17-year-old schoolgirl from Mashhad has had headache, nausea, vomiting and photophobia for 2 days. She has no underlying disease. She is alert and oriented, vitals are stable, and there is no focal neurology or papilloedema. LP: leucocytes 270 with 90% lymphocytes, protein 85, glucose 67 (simultaneous blood glucose 95). Which aetiology is more likely?",
    ["Mycobacterium tuberculosis", "A fungus", "Enterovirus", "Herpes simplex type I"])
add(162, "A previously well 23-year-old woman presents to a psychiatric hospital with an acute start of delirium and headache for 2 days. She is referred because of fever. Apart from fever and a disturbed content of consciousness there is nothing else. CSF: leucocytes 60 with lymphocyte predominance, protein 80, glucose 68 (simultaneous 90). Which diagnosis is more likely?",
    ["TB meningitis", "Pneumococcal meningitis", "Herpes encephalitis", "Listeria meningitis"])
add(164, "A young woman is admitted with meningitis and has an LP. CSF: 200 WBC with 90% lymphocytes, protein 70 mg, glucose 70 mg with a simultaneous blood glucose of 110 mg. What is the likely organism?",
    ["Herpes simplex", "Meningococcus", "Pneumococcus", "Mycobacterium tuberculosis"])
add(165, "A 65-year-old man is brought in with fever 38 C, headache, behavioural change and drowsiness over the past 3 weeks. LP yields CSF at a relatively high pressure. Which CSF formula fits tuberculous meningitis better?",
    ["WBC raised to 10000 with PMN predominance, a low glucose and a high protein",
     "WBC raised to 50 with lymphocyte predominance, a normal glucose, a reduced protein",
     "WBC raised to 500 with lymphocyte predominance, a low glucose and a high protein",
     "WBC high at 1000 with PMN predominance, a low glucose, a normal protein"])
add(168, "A patient with chronic leukaemia presents with headache, fever and visual disturbance for one month. Neck stiffness is positive. CSF: 50 lymphocytes, glucose 40 mg/dl, protein 60 mg/dl. Brain CT is normal. India-ink stain shows encapsulated particles. Which is raised?",
    ["Histoplasma", "Candida albicans", "Cryptococcus", "Aspergillus"])
add(169, "A 28-year-old man presents with headache since yesterday plus nausea and vomiting. Vitals: T 38.5 C orally, BP 110/80 mmHg, PR 95/min, RR 20/min. On lying him down, flexing the neck feels stiff and he complains of neck pain. Given the likely diagnosis, which option has priority?",
    ["Start antibiotic treatment before one hour",
     "Perform a brain CT",
     "A plain film of the cervical vertebrae",
     "Give a corticosteroid and an analgesic together"])
add(170, "A 25-year-old is brought in with fever and headache since yesterday and a reduced conscious level since the morning of admission. What is the most appropriate treatment?",
    ["Aciclovir", "Valaciclovir + meropenem", "Ceftazidime + vancomycin",
     "Ceftriaxone + vancomycin + aciclovir"])
add(172, "A 39-year-old man is brought in with fever and headache for 3 days. He had a cold one week ago. He has no underlying disease, is alert and answers correctly, and has no trauma. T=38 C and he has neck stiffness. After fundoscopy an LP is done. CSF: WBC 500 → PMN 62%, glucose 38 mg/dl, protein 88 mg/dl. What is the empiric treatment of choice until further tests?",
    ["Ceftriaxone + vancomycin",
     "Ampicillin + aciclovir + ceftriaxone",
     "Cefotaxime + vancomycin + aciclovir",
     "Cefotaxime + ampicillin"])
add(173, "A 32-year-old man presents with fever, headache and neck stiffness since yesterday. He has taken no antibiotic and has no underlying disease. He is alert with mild neck stiffness. CSF: WBC 800/mm3, PMN 85%, Glu 20 mg/dl, Pro 90 mg/dl. Fluid is sent for culture and smear. Until the cause is known, which regimen is preferred?",
    ["Ceftriaxone + vancomycin", "Ceftriaxone",
     "Ampicillin + ceftazidime + vancomycin", "We only observe the patient"])
add(174, "A 20-year-old soldier is brought in with fever, severe headache, repeated vomiting and drowsiness, all starting in the past 24 hours. Fever 39 C, mid-size symmetric pupils and neck stiffness. LP: WBC 5000 with PMN 90%, glucose 15 mg/dl, protein 150 mg/dl. Which regimen is appropriate?",
    ["Meropenem + ampicillin + vancomycin", "Ceftriaxone + ampicillin",
     "Ceftriaxone + vancomycin", "Ceftriaxone + metronidazole"])
add(175, "A 19-year-old dormitory student is brought in confused with a falling conscious level. Last year he had head trauma in a road crash, was in hospital one week and was discharged without surgery. He is febrile and drowsy with neck stiffness. Several students in the dormitory have had upper respiratory infections in the past two weeks. After blood cultures, which treatment do you give until further tests?",
    ["Cefepime + vancomycin", "Ampicillin + gentamicin + vancomycin",
     "Ceftriaxone + vancomycin", "Penicillin + doxycycline"])
add(176, "A 23-year-old woman is brought in with fever, headache and vomiting. She is a little drowsy and has neck stiffness. Last week she had a crash and a head blow. Which antibiotic regimen should be started?",
    ["Ampicillin + ceftriaxone + gentamicin",
     "Cefotaxime + flucloxacillin + gentamicin",
     "Cefotaxime + vancomycin",
     "Ceftriaxone + aciclovir"])
add(177, "A 20-year-old is brought in with fever and rigors, nausea, vomiting and headache starting 24 hours ago. He is alert, has neck stiffness and a normal neurological examination. CSF: WBC 300 (PMN 95%, LYMPH 5%), protein 95, glucose 30 (serum glucose 90). If Gram-positive diplococci are seen on the CSF smear, what is the appropriate empiric treatment until the culture?",
    ["Penicillin", "Ceftriaxone", "Ceftriaxone + vancomycin", "Cefotaxime + dexamethasone"])
add(178, "A woman is admitted to the emergency department with acute meningitis. She is in the second trimester of pregnancy. Which regimen is more appropriate to start?",
    ["Ceftriaxone + vancomycin + gentamicin",
     "Vancomycin + ceftriaxone + ampicillin",
     "Vancomycin + ampicillin + rifampicin",
     "Ceftriaxone + ampicillin + gentamicin"])
add(181, "A 65-year-old diabetic man who takes his drugs irregularly presents with fever and headache. Acute meningitis is diagnosed and CSF is obtained. CSF: Pro 100 mg/dl, Glu 50 mg/dl, PMN 82%, WBC 1300; simultaneous blood glucose 200. Until the CSF culture, which regimen should be given?",
    ["Ceftriaxone + vancomycin", "Ampicillin + cefotaxime",
     "Ampicillin + ceftriaxone + vancomycin", "Penicillin + cloxacillin + ceftazidime"])
add(182, "A 58-year-old woman is brought in with fever, headache, neck stiffness and a changed conscious level. After a brain CT an LP is done. CSF: about 2500 white cells with PMN 75%, glucose 30 mg/dl, protein 195 mg/dl. Until the CSF culture, which regimen do you recommend?",
    ["Ceftriaxone + vancomycin + ampicillin", "Cefotaxime + ampicillin",
     "Cefepime + vancomycin", "Ceftriaxone + vancomycin"])
add(183, "A 32-year-old man presents with fever and headache. He reports an upper-jaw dental infection for 2 weeks. Brain CT shows a 3 cm lesion in the temporal lobe. After blood cultures, what is the preferred treatment?",
    ["Imipenem + vancomycin", "Imipenem + gentamicin",
     "Ceftriaxone + metronidazole", "Vancomycin + metronidazole"])
add(185, "A 33-year-old woman with recurrent sinusitis is under observation in the emergency department with acute meningitis. What is the best empiric regimen?",
    ["Ceftazidime + vancomycin",
     "Ceftriaxone + metronidazole + vancomycin",
     "Ceftazidime + ampicillin + vancomycin",
     "Ampicillin + cefotaxime"])
add(187, "A 50-year-old man with gastric cancer on chemotherapy presents with headache, fever and nausea. Brudzinski's sign is positive. The blood count is about two thousand leucocytes (25% neutrophils). Until further tests, which regimen do you recommend?",
    ["Ampicillin + cefotaxime", "Cefepime + vancomycin",
     "Ampicillin + ceftazidime + vancomycin", "Ampicillin + meropenem + metronidazole"])
add(188, "A soldier is brought in with fever and drowsiness since last night and a headache. He has neck stiffness and petechial skin eruptions on the distal lower limbs. On arrival BT 38.5, BP 110/70, RR 20, PR 85. An LP is done and ceftriaxone + vancomycin is started at once. Gram stain of the CSF shows Gram-negative diplococci. How do you continue treatment?",
    ["Add aciclovir to the initial regimen",
     "Add ampicillin to the initial regimen",
     "Continue ceftriaxone and stop vancomycin",
     "Continue ceftriaxone and vancomycin"])
add(190, "A previously well 15-year-old presents with fever, headache, nausea and vomiting for two days. On arrival he is alert. There is no focal neurology. Fundoscopy is normal. CSF: WBC 250, Pr 60, Glu 75, Lym 90%. What is the appropriate step?",
    ["Lower the fever", "Open a reliable intravenous line",
     "Give dexamethasone after injecting antibiotics",
     "Give antibiotics before the smear and culture of the CSF are ready"])
add(191, "A 55-year-old presents with fever and rigors, headache and restlessness. He reports head trauma one week ago. He has neck stiffness. CSF: WBC 500 (PMN 20%, L 80%), glucose 40, Pr 800, smear negative. Given the most likely diagnosis, which treatment helps more?",
    ["Four-drug TB treatment + dexamethasone",
     "Three-drug brucellosis treatment + dexamethasone",
     "Vancomycin + ceftriaxone + aciclovir",
     "Meropenem + ampicillin + amphotericin B"])
add(193, "A medical-ward staff member has had close contact with the oropharyngeal secretions of a patient with meningococcal meningitis. For drug prophylaxis, which option do you NOT recommend?",
    ["Rifampicin", "Azithromycin", "Ceftriaxone", "Amoxicillin"])
add(194, "A 5-year-old is brought from a nursery with fever and widespread skin lesions. He is febrile and drowsy with a stiff neck. The lesions do not blanch. Microscopy of a stained scrape shows Gram-negative diplococci. What do you suggest for prophylaxis of the other children?",
    ["No prophylaxis is needed",
     "Single-dose intramuscular ceftriaxone",
     "Rifampicin for 2 days",
     "Single-dose ciprofloxacin"])
add(195, "A patient has a CSF leak. Which drug do you use to prevent meningococcal meningitis?",
    ["Penicillin", "A fluoroquinolone", "Rifampin", "Doxycycline"])
add(196, "A 12-year-old boy has an LP for fever, a reduced conscious level and headache. The CSF smear shows Gram-negative diplococci. He has a 3-year-old sister. What is the appropriate drug prophylaxis?",
    ["Give the sister rifampicin for 4 days",
     "Give the sister one intramuscular dose of ceftriaxone",
     "Give rifampicin to all family members",
     "No drug prophylaxis is needed"])
add(197, "A 32-year-old woman teacher in month 5 of pregnancy attends because one of her pupils has meningococcal meningitis. What is the most appropriate step?",
    ["Prevention with ciprofloxacin", "Prevention with rifampicin",
     "Start treatment for meningococcal meningitis", "No specific action is needed"])
add(198, "A pregnant nurse has been in close contact with a 10-year-old with fever, headache, vomiting, cutaneous purpura and neck stiffness and had to intubate the patient. Which prophylaxis is preferred?",
    ["Rifampicin as a single dose",
     "Rifampicin twice daily for three days",
     "Ceftriaxone IM as a single dose",
     "Ciprofloxacin twice daily for three days"])
add(200, "A nurse contacted the secretions of a patient with meningococcal meningitis while suctioning. She is pregnant. Which prophylaxis is correct?",
    ["Rifampicin 600 mg every 12 hours for 4 doses",
     "Ciprofloxacin 500 mg every 12 hours for 4 doses",
     "Rifampicin 600 mg every 12 hours for 2 doses",
     "Ceftriaxone 250 mg intramuscularly as a single dose"])
add(201, "A 19-year-old dormitory student presents with fever, a falling conscious level and a petechial-purpuric rash and is resuscitated on arrival. He is treated as meningococcal meningitis. What do you advise for the infectious-diseases resident who resuscitated him, who is also pregnant?",
    ["Clindamycin capsules 15 mg every 8 hours for 2 days",
     "No action is needed",
     "A single intramuscular dose of ceftriaxone 250 mg",
     "Rifampicin 600 mg every 12 hours for 2 days"])
add(202, "A 22-year-old man presents with fever, headache, nausea and vomiting and meningeal irritation. CSF Gram stain reports Gram-negative diplococci. For prophylaxis of his pregnant wife, which do you recommend?",
    ["Rifampicin", "Cefixime", "Ceftriaxone", "Ciprofloxacin"])
add(203, "You see a young dormitory student with fever, a falling conscious level and non-blanching skin lesions. Symptoms began two days ago with headache, nausea and vomiting. An LP is done. Gram stain of the CSF shows many Gram-negative diplococci. Which option best matches appropriate isolation of the patient and post-exposure prophylaxis for his roommates?",
    ["Fine respiratory droplets — rifampicin",
     "No isolation is needed — azithromycin",
     "Large respiratory droplets — rifampicin",
     "Large respiratory droplets — cefixime"])
add(204, "In a patient with acute bacterial meningitis mortality is increased in all of the following EXCEPT",
    ["Coma on admission",
     "A seizure one day after the fever breaks",
     "Age over 60 years",
     "Signs of a raised ICP"])
add(353, "A 37-year-old woman attends for delivery. Pain and myalgia began two days ago. She has fever 39 C. Delivery is vaginal and the newborn's Apgar is normal. On day three the newborn develops fever and respiratory distress and widespread petechial rashes. The abdomen shows hepatosplenomegaly. Liver biopsy reports multiple microabscesses and granulomas. What is the most likely organism in mother and infant?",
    ["Streptococcus agalactiae", "Mycobacterium tuberculosis", "Brucella melitensis", "Listeria monocytogenes"])
add(354, "A young woman in month six of pregnancy presents with fever, myalgia, arthralgia, headache and diarrhoea since yesterday. A peripheral-blood smear shows an anaerobic Gram-positive diphtheroid-like bacterium. She reports severe penicillin allergy. Suspecting Listeria monocytogenes bacteraemia, what is the most appropriate treatment?",
    ["Imipenem", "Vancomycin", "Gentamicin", "Co-trimoxazole"])
add(355, "A 30-year-old man on chemotherapy for lung cancer presents with fever and tachycardia. Blood culture grows Listeria monocytogenes. He thinks he has a severe penicillin allergy. What is your treatment of choice?",
    ["Imipenem", "Co-trimoxazole", "Ceftriaxone", "Piperacillin"])
