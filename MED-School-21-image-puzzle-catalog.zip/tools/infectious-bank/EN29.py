# -*- coding: utf-8 -*-
"""English stems for batch 65 (remaining zoonoses)."""
EN29 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    EN29[idx] = {"stem_en": stem, "options_en": options}


add(404, "A herdsman bitten by a dog attends hospital. He says he completed rabies vaccine last year. What do you advise to prevent rabies?",
    ["We recommend a full rabies vaccine course",
     "We reassure him that no specific action is needed",
     "We give three rabies vaccine doses on days 0, 7 and 21",
     "We give two vaccine doses on days 0 and 3"])
add(405, "A veterinarian who has just received a pre-exposure rabies course is bitten by a rabid dog. Which step is correct?",
    ["Two vaccine doses + wound care + RIG",
     "Two vaccine doses + wound care",
     "3 vaccine doses + wound care + RIG",
     "3 vaccine doses + wound care"])
add(406, "A Karaj zoo guard bitten by a raccoon is referred for prevention. Rabies vaccination was completed in the past. What do you advise now?",
    ["Vaccination and immunoglobulin",
     "Two vaccine doses alone",
     "Measure the rabies antibody titre and decide on the result",
     "Given a complete vaccination history no specific action is needed"])
add(407, "A 54-year-old ranger is bitten by a fox while freeing it from a trap. He has had pre-exposure rabies vaccination. What is appropriate prevention?",
    ["No action is needed", "Give rabies vaccine in 5 doses",
     "Give rabies vaccine in two doses on 0 and 3", "Give RIG"])
add(408, "A woman 36 weeks pregnant, vaccinated against rabies 2 years ago, attends after a neighbour's dog bite. The wound is assessed as mild. After washing, what rabies prophylaxis is appropriate?",
    ["Give rabies immunoglobulin",
     "Give 2 rabies vaccine doses and immunoglobulin",
     "Give 2 rabies vaccine doses",
     "Defer prophylaxis until after delivery"])
add(413, "A 28-year-old woman at week 18 of pregnancy is brought after a dog bite. Her husband says this dog has bitten several other people in the past 3 days and has not been seen again in the village. What do you recommend?",
    ["Because of pregnancy vaccine and immunoglobulin are contraindicated; follow her for symptoms",
     "Vaccinate on days 0, 7 and 21 after contact",
     "Vaccinate on days 0, 3, 7 and 14 and inject immunoglobulin at the first visit",
     "RIG injection alone is enough"])
add(417, "A young woman's hand is bitten by a household dog. All of the animal's usual vaccines have been given. To prevent infection at the bite, which is recommended?",
    ["Co-amoxiclav tablets", "A cephalexin capsule", "A gentamicin injection", "No drug is needed"])
add(418, "The fingertip of a young man on steroids for rheumatoid arthritis is bitten by a stray dog. Which drug is more appropriate to prevent infection?",
    ["Trimethoprim-sulfamethoxazole", "Benzathine penicillin",
     "Amoxicillin-clavulanate", "Cephalexin"])
add(420, "Which antibiotic is used to prevent bite infection?",
    ["Co-trimoxazole", "Amoxicillin-clavulanate", "Clindamycin", "Cefazolin"])
add(422, "Which of the following is chosen as rabies post-exposure prophylaxis?",
    ["Wash with soap and water and suture the tear + RIG and rabies vaccine on days 0-3-5-14-28",
     "Wash with soap and water and inject RIG with rabies vaccine on days 0-7-21 or 28 + tetanus vaccine",
     "Clean with soap and water — debride the wound, tetanus vaccine and an antibiotic + RIG + rabies vaccine on days 0-3-7-14",
     "Clean with soap and water — debride — tetanus vaccine + antibiotic + RIG + rabies vaccine on days 0-5-14-28"])
add(439, "A 16-year-old girl from a village near Sarab presents with fever, sweats and a limp for 3 weeks. She has painful limited movement of the right knee and hip. She gives no past illness. What is the most likely diagnosis?",
    ["Tuberculous arthritis", "Brucellosis", "Septic arthritis", "Reiter syndrome"])
add(441, "A 6-year-old village child has had fever, night sweats, anorexia, limb pain and a limp for about one month. He is febrile with sacroiliac tenderness. Which organism is more likely?",
    ["Staphylococcus aureus", "Mycobacterium tuberculosis", "Brucella melitensis", "Salmonella Typhi"])
add(442, "All of the following favour spinal involvement from brucellosis EXCEPT",
    ["Pons sign", "A psoas abscess", "A parrot beak", "Sclerosis"])
add(445, "In which of the following bones is brucellar osteomyelitis commoner?",
    ["The femur", "The upper lumbar vertebrae", "The upper thoracic vertebrae", "The cervical vertebrae"])
add(446, "A pregnant woman has recently developed brucellosis. Regarding the outcome of her pregnancy, all of the following are correct EXCEPT",
    ["There is a chance of miscarriage", "There is a chance of stillbirth",
     "There is a chance of fetal malformations", "The pregnancy may continue without any problem"])
add(448, "A 35-year-old veterinarian presents with fever, weakness, fatigue and anorexia for 20 days and low-back pain for 10 days. What is the first diagnostic step?",
    ["Blood culture", "MRI of the lumbar vertebrae", "A Wright test", "PPD"])
add(449, "A 23-year-old herdsman presents with fever and a limp. Symptoms began 10 days ago with pain and limited movement of the right knee, then settled and the left wrist was involved, then the left knee. There is now mild swelling of the right knee with limited active and passive movement. The rest of the examination is normal except for epididymo-orchitis. Given the most likely diagnosis, which step is more appropriate?",
    ["Request serum HLA-B27", "Request a serum Wright", "MRI with contrast of the affected knee", "Request serum RF"])
add(450, "A 23-year-old abattoir worker is admitted with fever, headache, nausea and vomiting. LP shows lymphocytic pleocytosis with a raised ADA. He has hepatic granulomas that on biopsy are non-caseating and AFB-negative. The Wright titre is 1/640. Which step is correct?",
    ["Start four-drug antituberculous treatment",
     "Start appropriate treatment for neurobrucellosis",
     "Start four-drug TB treatment + a corticosteroid",
     "Do a peripheral-blood PCR for brucellosis"])
add(451, "A young woman presents with prolonged fever and bone and joint pain. She has eaten unpasteurised dairy. Apart from fever the examination is normal. The Wright test is positive at a titre of 1/640. What is the most likely diagnosis?",
    ["Typhoid fever", "Brucellosis", "Bone tuberculosis", "Malaria"])
add(453, "A woman from Isfahan province who eats local cheese presents with fever, drenching sweats, headache and low-back pain for two weeks. Fever has not broken despite cefixime. Which of the following results argues AGAINST brucellosis?",
    ["Wright 1/160", "Coombs Wright 1/320", "2ME 1/20", "Negative blood culture"])
add(454, "A patient was treated for brucellosis and improved. Which option is correct about further follow-up?",
    ["Follow IgG serology for 2 years",
     "Follow clinical symptoms and the patient's weight for 2 years",
     "Follow IgG serology and clinical symptoms for 1 year",
     "No follow-up is needed"])
add(455, "A young village woman presents with fever, rigors and sweats for one month with bone pain and has positive Brucella serology. You decide on doxycycline and rifampicin. Which is appropriate for following response and relapse?",
    ["Clinical follow-up during treatment and serologic after treatment ends",
     "Serologic follow-up after treatment for 2 years",
     "Monthly serologic follow-up during and after treatment",
     "Clinical follow-up during treatment and for 2 years after treatment ends"])
add(457, "A patient treated with a standard brucellosis regimen has had a good clinical response. What do you advise about further follow-up?",
    ["We follow him for weight loss and general condition for 2 years",
     "We check Brucella serology (Wright) every 2 months for 2 years",
     "We do a Rose Bengal test 6 months after treatment",
     "We check Wright and Coombs Wright every 3 months for one year"])
add(460, "A young man from Wapani presents with fever and diagnostic tests show a Wright titre of 1/640. What is the appropriate treatment?",
    ["Doxycycline + rifampicin both for 6 weeks",
     "Doxycycline + gentamicin both for 6 weeks",
     "Co-trimoxazole + rifampicin both for 6 weeks",
     "Co-trimoxazole + gentamicin both for 6 weeks"])
add(461, "A middle-aged herdsman presents with fever, night sweats and bone pain and has a Wright titre of 1/320. What is recommended?",
    ["Start co-trimoxazole + rifampicin for six weeks",
     "Treat with streptomycin + doxycycline both for six weeks",
     "Treat with doxycycline + rifampicin both for six weeks",
     "Repeat the Wright test after three weeks"])
add(463, "A 26-year-old woman who is 8 weeks pregnant presents with fever, sweats and joint pain. Wright is 1/320 and 2ME is 1/40. What is the appropriate regimen?",
    ["High-dose co-trimoxazole",
     "Rifampicin with high-dose co-trimoxazole",
     "Doxycycline + co-trimoxazole",
     "Streptomycin + rifampicin"])
add(465, "A woman 5 months pregnant presents with a diagnosis of brucellosis. What is your regimen of choice?",
    ["Rifampicin + co-trimoxazole", "Doxycycline + rifampicin",
     "Streptomycin + rifampicin", "Ciprofloxacin + co-trimoxazole"])
add(466, "A young woman in the third month of pregnancy presents with fever, rigors, sweats, myalgia and arthralgia for two weeks. Labs: leukopenia WBC 3500, ESR 10, AST 30, ALT 40, Wright 1/320. What is the most appropriate regimen?",
    ["Daily streptomycin + rifampicin for 6 weeks",
     "Daily streptomycin for 3 weeks + rifampicin for 6 weeks",
     "Doxycycline + rifampicin for 6 weeks",
     "Co-trimoxazole + rifampicin for 6 weeks"])
add(467, "A pregnant woman in the fifth month is investigated for low-back pain, fever and night sweats. Wright is 1/320 and 2ME is 1/160. What is suggested?",
    ["Defer treatment until delivery", "Streptomycin + doxycycline",
     "Co-trimoxazole + rifampicin", "Ciprofloxacin + rifampicin"])
add(468, "A young woman in the second trimester, working in the central health-network laboratory, is admitted with fever 39.5 C, cervical adenopathy, splenomegaly and thrombocytopenia. Peripheral smear is negative for malaria and Borrelia; serum Wright and 2ME are positive. What is the best treatment choice?",
    ["Ciprofloxacin + rifampicin", "Doxycycline + rifampicin",
     "Co-trimoxazole + ampicillin", "Co-trimoxazole + rifampicin"])
add(469, "A brucellar patient with Wright 1/1280 and 2ME 1/160 receives standard treatment. He returns for follow-up 6 months later. He has no complaint. ESR is normal. Wright is 1/320 and 2ME is 1/80. What do you advise?",
    ["Suspecting relapse we give another course of treatment",
     "Given the tests and his being asymptomatic, no retreatment is needed",
     "We repeat the tests in two weeks and treat if the titre rises",
     "We make retreatment longer"])
add(470, "A patient with fever and general body pain and Wright 1/320 and 2ME 1/160 was treated with doxycycline for 6 weeks and streptomycin for 3 weeks. At the end of treatment Wright is 1/160 and 2ME is 1/40. His sense of fatigue has not gone but other symptoms have improved. What is the best approach?",
    ["Drug resistance is raised and blood culture and an antibiogram are needed",
     "The patient is regarded as improved and no further action is needed",
     "Give doxycycline and rifampicin for another 6 weeks",
     "Continue doxycycline for another 3 months"])
add(472, "A 40-year-old man presents with fever, headache and myalgia for three weeks. No focus of infection is found. Wright is 1/320 and 2ME is 1/80. Which regimen is preferred?",
    ["Ceftriaxone", "Ciprofloxacin", "Doxycycline + co-trimoxazole", "Doxycycline + streptomycin"])
add(473, "A 45-year-old herdsman presents with fever, night sweats, weight loss and low-back pain for one month. He is not toxic. Wright titre is 1/320. What is the gold-standard treatment?",
    ["Co-trimoxazole + doxycycline", "Streptomycin + doxycycline",
     "Tetracycline + co-trimoxazole", "Rifampicin + co-trimoxazole"])
add(474, "A young village man presents with fever, rigors and musculoskeletal pain for 2 weeks. Titres: Wright 1/640, 2ME 1/320. Apart from fever there is nothing else. About one year ago he was treated for brucellosis for 6 weeks with doxycycline + streptomycin. What is the most appropriate treatment now?",
    ["Doxycycline + streptomycin for 12 weeks",
     "Doxycycline + rifampicin for 6 weeks",
     "Rifampicin + co-trimoxazole for 12 weeks",
     "Rifampicin + co-trimoxazole for 6 weeks"])
add(476, "A 30-year-old woman is treated for brucellosis. Which test is appropriate to follow the response to treatment?",
    ["Wright", "Coombs Wright", "2ME", "Rose Bengal"])
add(477, "A veterinarian has a needlestick while injecting livestock with brucellosis vaccine. Which step is correct to prevent infection?",
    ["Co-trimoxazole + gentamicin for two weeks",
     "Rifampicin + streptomycin for two months",
     "Doxycycline for 6 weeks",
     "Rifampicin for 4 weeks"])
add(478, "A veterinary employee inoculates brucella vaccine into his own hand while vaccinating animals. What prophylaxis do you consider appropriate?",
    ["This vaccine is killed and no specific action is needed",
     "The vaccine immunises him and no specific action is needed",
     "Six weeks of treatment with rifampicin and doxycycline is recommended",
     "Do a Wright test six weeks later"])
add(480, "A veterinary technician says that while vaccinating animals against Brucella the needle entered the muscle beside his left hand. What is appropriate?",
    ["Oral clindamycin for 6 weeks",
     "No specific action is needed; return if he becomes febrile",
     "Ceftriaxone for two weeks",
     "Rifampicin plus doxycycline for 6 weeks"])
add(481, "While a laboratory worker was handling serum from a brucellosis patient, some serum splashed into his eye. Besides washing the eye with water, what is appropriate?",
    ["No further action is needed",
     "Rifampicin for three weeks",
     "Doxycycline for three weeks",
     "Rifampicin and doxycycline for three weeks"])
add(482, "Which of the following is true of Brucella endocarditis?",
    ["A treatment course of at least 3 months is enough",
     "In most cases surgical intervention is needed",
     "Treatment is two drugs such as tetracycline and rifampicin",
     "In most cases the mitral valve is involved"])
add(484, "A woman rice farmer presents with fever, headache and myalgia for 5 days. She has bilateral conjunctivitis. Skin and sclerae are icteric. There is a maculopapular rash on the upper half of the body and hepatosplenomegaly. Labs: AST 90, ALT 100, AP 380, total bilirubin 12 mg/dl, Cr 3, platelets 100000/μL, WBC 14000/μL, Hb 11 g/dl. What is the most likely diagnosis?",
    ["CCHF", "Malaria", "Leptospirosis", "Salmonellosis"])
add(485, "A farmer from Gorgan is admitted with a sudden start of fever and rigors, myalgia, headache, nausea and vomiting for 2 days. He looks ill. Besides fever he has non-exudative conjunctival redness, splenomegaly and muscle tenderness. Labs show leucocytosis, a raised serum creatinine and proteinuria. Which diagnosis is more likely?",
    ["Typhoid", "Brucellosis", "Malaria", "Leptospirosis"])
add(488, "A 35-year-old farmer and herdsman presents with sudden fever and rigors starting 5 days ago, plus myalgia and headache; since yesterday he has jaundice, melaena, abdominal pain, breathlessness and a cough with bloody sputum. He is icteric and febrile with maculopapular and petechial lesions on the limbs, severe muscle tenderness, RUQ tenderness and BP 90/50 mmHg. Labs: leucocytosis, thrombocytopenia, pyuria and granular casts, Cr 2.5 mg/dl, urea 80 mg/dl, total bilirubin 4.5 mg/dl, direct 2 mg/dl, AST 100, ALT 120 and a raised CPK. Which is more likely?",
    ["CHF", "Influenza", "Leptospirosis", "Acute viral hepatitis"])
add(489, "A patient develops fever one week after returning from a trip to northern Iran. After one week of fever he develops pulmonary and skin symptoms, myalgia and a cough. He has non-exudative conjunctival injection, a red throat without exudate, wet rales at the lung bases, maculopapular rashes, subicterus and meningism. Which diagnosis is more likely?",
    ["Brucellosis", "Malaria", "Leptospirosis", "Salmonellosis"])
add(490, "A 50-year-old woman farmer is admitted with fever, rigors, headache, haematuria and myalgia. The conjunctivae are red. She is slightly confused. BP 90/60. Labs: Cr 2, direct bili 20, total bili 25, O2 sat 85%. What is the most likely diagnosis?",
    ["Weil's syndrome", "Enteric fever", "Septic shock", "Endemic typhus"])
add(491, "A 27-year-old man who keeps rodents in the veterinary animal house presents with fever and a rash. He has maculopapular eruptions, myalgia, jaundice and obvious conjunctivitis. Creatinine is reported high. What is the most likely diagnosis?",
    ["Typhus", "Brucellosis", "Leptospirosis", "Melioidosis"])
add(492, "A young farmer from a northern province presented with fever and body pain and was treated symptomatically. One week later he returns with fever, low blood pressure and obvious scleral icterus. Emergency labs: creatinine 3, a 4-fold rise in liver enzymes, a high CPK and raised direct and indirect bilirubin. What is the most likely diagnosis?",
    ["Weil's disease (Leptospirosis)", "Borreliosis", "Viral hepatitis", "Brucellosis"])
