# -*- coding: utf-8 -*-
"""Correct book q9089 — influenza in a high-risk adult (BMI 42) within 48 h.

The book answers azithromycin. The lungs are clear, the onset is yesterday,
and BMI 42 is a CDC high-risk criterion. Harrison and CDC: oseltamivir.
"""
import json, io, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
TARGET_NO = 9089
FA = ('کلید چاپی آزیترومایسین است، ولی ریه پاک است و این آنفلوانزاست نه پنومونی. '
      'BMI برابر ۴۲ معیار پرخطر CDC است و شروع از دیروز داخل پنجره‌ی ۴۸ ساعته است. '
      'CDC/ACIP و Harrison اسلتامیویر را در این وضعیت توصیه می‌کنند، نه ماکرولید.')
EN = ("The printed key is azithromycin, but the lungs are clear and this is influenza, "
      "not pneumonia. A BMI of 42 is a CDC high-risk criterion and onset yesterday is "
      "inside the 48-hour window. CDC/ACIP and Harrison recommend oseltamivir here, "
      "not a macrolide.")
SRC = ("CDC/ACIP influenza antiviral guidance; "
       "Harrison's Principles of Internal Medicine, 21st ed (2022) — influenza")


def main():
    for i in range(1, 6):
        p = os.path.join(HERE, f'import-payload.book.part{i:02d}.json')
        if not os.path.exists(p):
            continue
        body = json.load(io.open(p, encoding='utf-8'))
        changed = False
        for q in body['questions']:
            if q.get('question_no') != TARGET_NO:
                continue
            idx = None
            for j, o in enumerate(q['options_fa']):
                if 'اسلتامیویر' in o or 'اوسیل' in o or 'اوسلت' in o:
                    if idx is not None:
                        sys.exit('ambiguous oseltamivir option')
                    idx = j
            if idx is None:
                sys.exit('oseltamivir option not found: ' + repr(q['options_fa']))
            if q.get('key_corrected') and q['correct_index'] == idx:
                print('already corrected')
                return
            q['original_correct_index'] = q['correct_index']
            q['correct_index'] = idx
            q['key_corrected'] = True
            q['key_correction_fa'] = FA
            q['key_correction_en'] = EN
            q['key_correction_source'] = SRC
            changed = True
            print(f'q{TARGET_NO}: {q["original_correct_index"]} -> {idx}')
        if changed:
            json.dump(body, io.open(p, 'w', encoding='utf-8'),
                      ensure_ascii=False, indent=1)


if __name__ == '__main__':
    main()
