# -*- coding: utf-8 -*-
"""English stems for batch 63 (remaining skin/soft-tissue items)."""
EN27 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    EN27[idx] = {"stem_en": stem, "options_en": options}


add(9, "A patient has lower-limb varices and venous stasis and repeatedly develops cellulitis. Which organism causes it?",
    ["Streptococcus pyogenes", "Staphylococcus epidermidis", "Haemophilus influenzae", "Candida albicans"])
add(12, "A previously well young person develops cellulitis around a skin scratch on the forearm. All of the following antibiotics are effective EXCEPT",
    ["Cefazolin", "Ceftriaxone", "Clindamycin", "Oxacillin"])
add(13, "A previously well young labourer presents with a painful 4×4 cm swelling of the left shin and fever. The swelling has no clear edge and there is no regional adenopathy. Other vitals are stable. What is the appropriate outpatient treatment?",
    ["Cloxacillin", "Cefixime", "Oral penicillin", "Ciprofloxacin"])
add(14, "A previously well 25-year-old athlete develops swelling and redness of the front of the shin. There is warmth and erythema with an indistinct edge of about 5×5 cm. What is the most appropriate antibiotic?",
    ["Cloxacillin", "Cefixime", "Azithromycin", "Ceftriaxone"])
add(15, "A 20-year-old man presents with swelling of the left shin. It is swollen, erythematous, warm and tender. He is not febrile. Which drug is the treatment of choice?",
    ["Nafcillin", "Vancomycin", "Ciprofloxacin", "Gentamicin"])
add(16, "A young man was attacked by the household cat about 3 hours ago. Bite marks are visible on the right forearm. The wound has been washed with soap and water. Which further preventive step do you recommend?",
    ["Continuous washing with povidone-iodine and alcohol",
     "Suture the wound and take cephalexin",
     "Take clindamycin if fever and rigors appear",
     "Take co-amoxiclav"])
add(18, "A 37-year-old man develops a wound after swimming in a river and then pain, swelling, redness and warmth of the left forearm with fever and tachycardia. What is the most likely organism?",
    ["Aeromonas hydrophila", "Erysipelothrix rhusiopathiae", "Vibrio vulnificus", "Pasteurella multocida"])
add(19, "A young man develops cellulitis of the foot after swimming in a river. He has fever and systemic symptoms. What is the most likely organism?",
    ["Pseudomonas aeruginosa", "Aeromonas hydrophila", "Proteus mirabilis", "Vibrio vulnificus"])
add(21, "Several schoolchildren develop itchy vesicular and papulofollicular lesions on an erythematous background on the trunk and buttocks after swimming in a pool. They have no fever; some have mild ear pain. What is the most likely cause?",
    ["Adenovirus", "Herpes virus", "Staphylococcus aureus", "Pseudomonas"])
add(22, "A patient with acute leukaemia becomes febrile a few days after chemotherapy. Examination shows several haemorrhagic vesicles with surrounding erythema and central necrosis forming ulcers on the trunk. What is the most likely cause?",
    ["Pseudomonas aeruginosa", "Staphylococcus aureus", "Candida albicans", "Aspergillus fumigatus"])
add(27, "A 60-year-old woman is brought in with fever, hypotension and tachycardia. She is febrile and has a very painful bullous lesion with an erythematous edge on the right lower leg. What is your most important step given the suspected diagnosis?",
    ["Start a broad-spectrum antibiotic", "MRI of the lower limb", "A surgical consult", "Request blood cultures"])
add(29, "A young woman is on the obstetric ward after an illegal abortion for an unwanted pregnancy. She is hypotensive, no fever is reported, and the white-cell count is raised. Which organism is responsible?",
    ["Streptococcus pyogenes", "Staphylococcus aureus", "Clostridium sordellii", "Gardnerella vaginalis"])
add(31, "10 employees of an organisation present with upper-limb skin lesions: an ulcer with a black centre, induration and wide non-pitting oedema out of proportion to the lesion. The lesions are painless. None reports animal contact. Which prescription is more logical?",
    ["Penicillin for 60 days", "Amoxicillin for 10 days", "Ciprofloxacin for 60 days", "Doxycycline for 10 days"])
add(32, "A 50-year-old farmer noticed a wound on his fingers 5 days ago. Since yesterday the swelling has progressed with redness and duskiness. A smear shows cuboidal Gram-positive rods and few PMNs. Given the most likely diagnosis, all of the following treatments are appropriate EXCEPT",
    ["Doxycycline", "Ciprofloxacin", "Penicillin", "Cefixime"])
add(33, "A 40-year-old man presents with fever, nausea, vomiting and severe abdominal pain. He is a forest ranger and often contacts small rodents, especially rabbits. He has high fever, abdominal tenderness and hepatosplenomegaly. What is the most likely diagnosis?",
    ["Tularemia", "Brucellosis", "Leptospirosis", "Cat-scratch disease"])
add(34, "In bioterrorism, which of the following is NOT Category A?",
    ["Anthrax (Bacillus anthracis)", "Typhus fever (Rickettsia prowazekii)",
     "Plague (Yersinia pestis)", "Tularemia (Francisella tularensis)"])
add(35, "Which set of findings most suggests streptococcal pharyngitis?",
    ["Fever, sore throat and tonsillar hypertrophy in an 8-year-old",
     "Sore throat, headache, sneezing and nasal blockage in a 22-year-old man",
     "Burning and itching of the throat, cough, nasal blockage and exudate in a 6-year-old",
     "Fever, burning and itching of the throat, rhinorrhoea, myalgia and exudate in a 32-year-old woman"])
add(37, "A 2-year-old presents with fever and a sore throat. T is 39 C, there is pharyngeal exudate and anterior-chain adenopathy. All of the following fit streptococcal pharyngitis EXCEPT",
    ["The patient's age", "Anterior-chain adenopathy", "Pharyngeal exudate", "Being febrile"])
add(40, "To treat streptococcal pharyngitis in a 12-year-old boy with a non-anaphylactic penicillin allergy, which drug do you prescribe?",
    ["Cephalexin", "Co-trimoxazole", "Amoxicillin", "Clindamycin"])
add(41, "An 8-year-old boy presents with fever and a sore throat. There is pinpoint white exudate in the pharynx and anterior cervical adenopathy. Given the most likely organism, which treatment do you choose?",
    ["Benzathine penicillin", "Ceftriaxone", "Doxycycline", "Levofloxacin"])
add(42, "A 15-year-old boy with purulent sore throat and fever received one intramuscular dose of benzathine penicillin. A throat culture two weeks later still grows group A beta-haemolytic streptococcus. His 7-year-old sister has a history of rheumatic fever. What do you do?",
    ["Oral erythromycin for 14 days with clindamycin in the first 4 days",
     "One intramuscular dose of benzathine penicillin",
     "Oral penicillin for ten days with rifampicin in the last 4 days",
     "Azithromycin 500 mg daily for 7 days"])
add(43, "Which treatment is recommended to eradicate asymptomatic group A streptococcal throat colonisation?",
    ["Co-amoxiclav", "Vancomycin", "Penicillin V + rifampicin", "Clindamycin + rifampicin"])
add(46, "A 20-year-old woman presents with fever, rigors and a sore throat. She has no rhinorrhoea, sneezing or cough. The tonsils are deeply red. A rapid throat-swab test is negative. What is the next step?",
    ["Symptomatic treatment only", "Treat with injectable penicillin",
     "Send a throat sample for PCR", "Obtain a throat culture"])
add(48, "The parents of a 3-year-old with a streptococcal skin infection (impetigo) are worried about complications. Which complication is likely?",
    ["Post-streptococcal glomerulonephritis", "Rheumatic fever", "Fever and a seizure", "Sepsis"])
add(49, "What is the cause of erysipelas?",
    ["Staphylococcus aureus", "Streptococcus pyogenes", "Both", "Neither"])
add(50, "A 40-year-old man suddenly develops swelling and redness over the nose that spreads onto both cheeks. The swelling has a sharp border. After 2–3 days a bulla appears. An appropriate antibiotic is started but the lesion still widens. Which organism is more likely?",
    ["Streptococcus pyogenes", "Staphylococcus aureus", "Pseudomonas aeruginosa", "Streptococcus viridans"])
add(51, "An elderly woman presents with a warm, slightly tender, sharply bordered erythematous facial lesion, seen symmetrically. What is first-line treatment?",
    ["Vancomycin", "Penicillin", "Clindamycin", "Cephalexin"])
add(52, "A 65-year-old hypertensive woman suddenly develops fever and redness of the forehead and cheeks. The areas are painful, erythematous, sharply bordered and raised. Which antibiotic is more appropriate as first-line empiric treatment?",
    ["Penicillin", "Cephalexin", "Levofloxacin", "Vancomycin"])
add(53, "A 25-year-old presents with pain, swelling and redness of the right shin with fever and rigors for 3 days, gradually worsening. Vitals are stable and pain is mild to moderate. Last year after penicillin for pharyngitis he developed urticaria within 1 hour and anaphylactic shock. Which treatment is appropriate?",
    ["Cloxacillin", "Cephalexin", "Clindamycin", "Metronidazole"])
add(54, "In severely ill streptococcal toxic shock, which regimen (in addition to clindamycin) is preferred?",
    ["Meropenem", "Penicillin", "Vancomycin", "Intravenous immunoglobulin"])
add(56, "A young man has a mild skin infection due to methicillin-resistant S. aureus. Which oral antibiotic is recommended?",
    ["Cephalexin", "Cloxacillin", "Clindamycin", "Ciprofloxacin"])
add(57, "You see a 17-year-old boy with fever, drowsiness, general toxicity and hypotension. Symptoms began three days ago with fever, myalgia and transient watery diarrhoea. Examination shows redness of the face to the neck and upper trunk. Tests show thrombocytopenia, leucocytosis, azotaemia and a raised CPK. What is the most likely diagnosis?",
    ["Measles", "Stevens–Johnson syndrome", "S4", "Toxic shock syndrome"])
add(58, "A 24-year-old village youth is brought in with severe watery diarrhoea and a reduced conscious level. There is diffuse erythema of the head, neck and anterior chest. Tests show leucocytosis, a raised creatinine, a low platelet count and a markedly raised CPK. Vitals: BP 85/45, RR 32, PR 125, T 39.5. Which diagnosis fits best?",
    ["Meningococcaemia", "Toxic shock syndrome", "Crimean-Congo", "Infective endocarditis"])
add(59, "A young woman on day 4 of menses develops high fever of 39 C, nausea, vomiting, diarrhoea, myalgia and arthralgia. The illness progresses rapidly; she becomes delirious. Examination: fever, hypotension, conjunctival and oral mucosal hyperaemia, and whole-body erythroderma. Tests: leucocytosis, thrombocytopenia, raised liver enzymes. Which disease is more likely?",
    ["Meningococcaemia", "Toxic shock syndrome", "Viral haemorrhagic fever", "Kawasaki disease"])
add(60, "A previously well 24-year-old single woman is admitted with fever, weakness and severe myalgia since yesterday, plus nausea, vomiting and diarrhoea. BP 95/60, pulse 115, temperature 39.7. Apart from cold extremities and a faint diffuse erythematous rash on the face, trunk and less on the limbs there is nothing else. WBC 19000, platelets 120000, creatinine 1.3. Given the most likely diagnosis, which agent is more likely?",
    ["Clostridium sordellii", "Neisseria meningitidis", "Pseudomonas aeruginosa", "Staphylococcus aureus"])
add(62, "What is the commonest cause of surgical-wound infection?",
    ["Pseudomonas aeruginosa", "Staphylococcus saprophyticus", "Staphylococcus aureus", "Streptococcus pyogenes"])
add(63, "An 8-year-old in winter develops fever and a productive cough with blood streaks a few days after recovering from influenza. The chest film shows round air-containing lesions in the mid-zones with scattered infiltrate. What is the most likely cause?",
    ["Staphylococcus aureus", "Pseudomonas aeruginosa", "Klebsiella pneumoniae", "Mycoplasma pneumoniae"])
add(64, "A youth in winter develops fever of 39 C, severe myalgia and a cough and improves with symptomatic treatment. Ten days later he again has high fever, a cough with bloody sputum and breathlessness. The chest film shows multiple small thin-walled cavities in both lungs. What is the most likely cause?",
    ["Nocardia asteroides", "Staphylococcus aureus", "Streptococcus pneumoniae", "Haemophilus influenzae"])
add(65, "A 40-year-old man on haemodialysis three times weekly for 2 years is admitted with fever, rigors, cough and bloody sputum for one week, diagnosed as pneumonia. The chest film reports several pneumatoceles in both lungs. Which organism is the commonest cause?",
    ["Klebsiella pneumoniae", "Staphylococcus aureus", "Streptococcus pneumoniae", "Mycobacterium tuberculosis"])
add(66, "A 3-month-old infant is brought in with fever, short breathing and respiratory failure. The chest film shows thin-walled cavities and a pneumothorax. Cover of which organism is essential before microbiology results?",
    ["Haemophilus influenzae", "Streptococcus pneumoniae", "Staphylococcus aureus", "Moraxella catarrhalis"])
add(67, "An injecting drug user presents with 20 days of fever and back pain. MRI of the spine reports L1-L2 spondylodiscitis (12) and an epidural abscess. What is the most likely cause?",
    ["Brucella abortus", "Pseudomonas aeruginosa", "Candida albicans", "Staphylococcus aureus"])
add(71, "A 50-year-old woman presents with pain and swelling of the left knee. She is febrile. A Gram stain of the joint fluid shows Gram-positive cocci. What is the appropriate treatment?",
    ["Ceftriaxone", "Levofloxacin", "Ceftazidime", "Vancomycin"])
add(72, "In an ICU patient with nosocomial sinusitis, until endoscopic sinus-culture results are ready, cover of which pathogens is essential?",
    ["Legionella species and anaerobes", "Haemophilus influenzae and anaerobes",
     "Staphylococcus aureus and Gram-negative bacilli", "Staphylococcus epidermidis and Candida species"])
