# -*- coding: utf-8 -*-
"""English stems for batch 62 (remaining respiratory items)."""
EN26 = {}


def add(idx, stem, options):
    assert len(options) == 4, idx
    EN26[idx] = {"stem_en": stem, "options_en": options}


add(74,
    "A 30-year-old man presents to the emergency department with a sudden onset of cough, fever and "
    "shaking rigors. Examination shows crackles at the right lung base together with dullness in the "
    "same area. A Gram stain of the sputum reports Gram-positive diplococci. Which microorganism is "
    "the most likely cause?",
    ["Haemophilus influenzae", "Streptococcus pneumoniae",
     "Staphylococcus aureus", "Mycoplasma pneumoniae"])

add(79,
    "The 23-valent pneumococcal polysaccharide vaccine is NOT recommended for prevention in which of "
    "the following?",
    ["C5–C9 complement deficiency", "Cystic fibrosis", "Diabetes mellitus", "Coeliac disease"])

add(80,
    "Vaccination against Streptococcus pneumoniae is recommended in all of the following EXCEPT",
    ["Acute hepatitis", "A cochlear implant", "A kidney transplant", "Severe asthma"])

add(83,
    "A 40-year-old man presents with fever and a productive cough for the past 2 days. Auscultation "
    "and a radiograph raise the diagnosis of pneumonia. He has no particular past history and has "
    "taken no antibiotic in the past 3 months. All of the following can be recommended for treatment "
    "EXCEPT",
    ["Ciprofloxacin", "Azithromycin", "Clarithromycin", "Doxycycline"])

add(84,
    "A 25-year-old presents with fever, sore throat, weakness and myalgia for 4 days, with a dry "
    "cough added gradually. He is febrile. Auscultation shows wheeze and crackles, and the chest "
    "film shows segmental involvement and atelectasis. Which treatment do you NOT consider appropriate?",
    ["Azithromycin", "Clarithromycin", "Ciprofloxacin", "Levofloxacin"])

add(85,
    "A 60-year-old patient with controlled heart failure presents with fever and a productive cough "
    "for three days. Rales are heard at the right lung base. The chest radiograph also shows opacity "
    "at the right base. Given the patient's vital signs, which regimen do you recommend?",
    ["Amoxicillin", "Levofloxacin", "Ceftriaxone", "Cefixime"])

add(87,
    "A 45-year-old non-smoker presents with fever, rigors and a productive cough for three days. He "
    "has no particular past history and takes no drugs. A plain chest film shows opacity of the lower "
    "lobe of the left lung. Until further diagnostic steps are ready, which of the following drugs is "
    "more appropriate?",
    ["Azithromycin", "Cefixime", "Co-amoxiclav", "Co-trimoxazole"])

add(89,
    "A 30-year-old man presents to the emergency department with fever, rigors, myalgia and a dry "
    "cough since yesterday. Examination: oral temperature 38.5 C, heart rate 88, respiratory rate 19, "
    "blood pressure 130/70 mmHg, body-mass index 42 kg/m2, mild pharyngeal erythema and a normal chest. "
    "What is the treatment of choice?",
    ["Paracetamol tablets with advice to take fluids and rest",
     "Azithromycin", "Amantadine", "Oseltamivir"])

add(92,
    "A young male smoker presents with fever, a productive cough and chest pain for three days. The "
    "chest radiograph shows a left lobar infiltrate. Stain and culture of the sputum report "
    "pneumococcus. What is the most appropriate outpatient treatment?",
    ["Azithromycin 250 mg daily",
     "Doxycycline 100 mg twice daily",
     "Amoxicillin 1 g every 8 hours",
     "Levofloxacin 500 mg daily"])

add(93,
    "A patient has had fever, rigors and a cough with copious purulent sputum since yesterday. "
    "Examination: fever 40 C, respiratory rate 24, pulse 110, blood pressure 120/80, and crackles at "
    "the right lower lung. The CBC shows leucocytosis (WBC 25000) with PMN predominance. What is the "
    "most appropriate first step?",
    ["Sputum and blood cultures and a chest film, then treat according to the results",
     "Sputum culture and a lung CT and an appropriate antibiotic",
     "A chest film and an appropriate antibiotic",
     "Sputum PCR and serology and treatment according to the results"])

add(94,
    "A 75-year-old woman has felt feverish with scattered coughs for two days; today the coughs have "
    "become severe and are accompanied by mild breathlessness, right-sided pleuritic pain and scant "
    "blood-streaked sputum. About one week ago she had a mild sore throat and a runny nose. "
    "Examination: T 38.5 C and rales at the right base. What is the most important diagnostic test?",
    ["Gram stain and culture of sputum", "CBC with differential and blood cultures",
     "A nuclear ventilation-perfusion scan", "CXR"])

add(96,
    "All of the following antibiotics inhibit cell-wall synthesis EXCEPT",
    ["Gentamicin", "Vancomycin", "Imipenem", "Ampicillin"])

add(563,
    "A healthy young athlete suddenly develops headache, fever, rigors, severe myalgia, a dry cough "
    "and a sore throat in winter. Examination shows fever and mild redness with scant discharge at "
    "the back of the pharynx. What is the most appropriate step?",
    ["A cough syrup + a gentamicin injection",
     "Paracetamol + drinking fluids",
     "Aspirin + an amoxicillin capsule",
     "A cefixime capsule + aspirin"])

add(565,
    "A 25-year-old with no underlying disease presents with fever, a sore throat and conjunctivitis. "
    "He is febrile and a white exudate is seen on the tonsils. Which treatment is preferred?",
    ["Benzathine penicillin", "Supportive treatment", "Oseltamivir", "Ceftriaxone"])

add(566,
    "A 75-year-old man presents in winter with rhinorrhoea, sneezing and a sore throat since noon "
    "yesterday. He also has nasal blockage, aching, fatigue and a mild headache. He has no fever; "
    "heart and lung sounds are normal. What treatment do you choose?",
    ["A systemic decongestant and paracetamol",
     "A topical decongestant and an azithromycin tablet",
     "A topical decongestant and an amantadine tablet",
     "Benzathine penicillin and a paracetamol tablet"])

add(567,
    "In autumn a 30-year-old woman with no underlying disease develops high fever, headache, myalgia "
    "and a dry cough after travelling to Karbala. Examination: fever 39 C, respiratory rate 14, pulse "
    "75, blood pressure 120/80. The lungs and the rest of the examination are normal. What is the "
    "most appropriate step?",
    ["Paracetamol + oral fluids",
     "A cough syrup + levofloxacin",
     "One dose of dexamethasone + intravenous fluids",
     "One dose of hydrocortisone + oseltamivir"])

add(568,
    "A young woman presents with sneezing, rhinorrhoea and a sore throat for 2 days. She currently "
    "has no fever. The throat has no exudate but is erythematous. Which do you choose as treatment?",
    ["Penicillin", "Supportive treatment", "Azithromycin", "Cefixime"])

add(569,
    "An elderly man with chronic lung disease presents 2 weeks after returning from Hajj with fever, "
    "rhinorrhoea, diarrhoea and severe breathlessness. Tests show a rise in creatinine and LDH, and "
    "MERS-CoV PCR on respiratory secretions is positive. What is your treatment advice?",
    ["Ribavirin", "Prednisolone", "Interferon alfa-2b", "Supportive measures are enough"])

add(570,
    "Several children at a primary school have developed bilateral conjunctivitis, a sore throat, "
    "cervical adenopathy and fever after returning from a summer camp. Examination of the eye shows "
    "a granular appearance of the bulbar and palpebral conjunctiva. Which virus is more likely "
    "responsible?",
    ["Influenza", "Adenovirus", "Coronavirus", "Rhinovirus"])

add(572,
    "Which of the following is NOT a common manifestation of influenza?",
    ["A skin rash", "Myalgia", "Sore throat", "Headache"])

add(573,
    "In influenza caused by the novel H1N1 virus all of the following are common EXCEPT",
    ["Severe myalgia", "Shaking rigors", "High fever",
     "A severe sore throat without exudate"])

add(574,
    "All of the following people are at high risk of influenza EXCEPT",
    ["A 70-year-old man", "A woman with CHF", "A 6-year-old child", "A pregnant woman"])

add(576,
    "Which of the following groups is NOT prone to complications of influenza?",
    ["A diabetic", "Renal failure", "A hemoglobinopathy",
     "The first trimester of pregnancy"])

add(577,
    "Which of the following are complications of influenza virus?",
    ["Reye's syndrome", "Toxic shock syndrome", "Transverse myelitis", "All of the above"])

add(578,
    "A 25-year-old man suddenly developed fever, headache, myalgia and a cough 4 days ago. Since "
    "today he also has progressive breathlessness. There is a history of contact with a similar "
    "patient. The chest film shows diffuse interstitial infiltrates. Which complication is raised?",
    ["Secondary bacterial pneumonia", "Primary viral pneumonia",
     "Mixed viral-bacterial pneumonia", "Viral tracheobronchitis"])

add(580,
    "During an influenza epidemic a 30-year-old man presents with high fever, cough and progressive "
    "breathlessness that began yesterday. The chest radiograph shows multiple small thin-walled "
    "cavities. In antibiotic treatment, covering which microorganism is essential?",
    ["Staphylococcus aureus", "Mycobacterium tuberculosis",
     "Klebsiella pneumoniae", "Mycoplasma pneumoniae"])

add(582,
    "A 42-year-old patient with IHD and COPD presents in autumn with fever and a productive cough "
    "since last night. He is alert, tachypnoeic and in respiratory distress, and crackles are heard "
    "in both lungs. The chest film shows bilateral patchy infiltrates. He had flu-like symptoms 4 "
    "days ago and his wife had influenza one week ago. Which pathogens are more likely?",
    ["Streptococcus pneumoniae — Mycoplasma pneumoniae",
     "Streptococcus pneumoniae — Staphylococcus aureus",
     "Legionella — E. coli",
     "Mycoplasma pneumoniae — Staphylococcus aureus"])

add(583,
    "A 30-year-old woman presents with acute influenza and is treated symptomatically, but 3 days "
    "after a relative improvement she suddenly develops fever, a productive cough with fully rusty "
    "sputum, rigors and chest pain. The chest film shows pulmonary involvement and consolidation. "
    "In your view, pneumonia with which of the following organisms is LESS likely?",
    ["Pseudomonas aeruginosa", "Staphylococcus aureus",
     "Streptococcus pneumoniae", "Haemophilus influenzae"])

add(584,
    "Which of the following statements about preventing influenza is WRONG?",
    ["Giving vaccine to a woman 5 months pregnant",
     "Amantadine to a person on chemotherapy",
     "Giving vaccine to a healthy 70-year-old with no underlying disease",
     "Giving vaccine to a young diabetic"])

add(586,
    "During an H1N1 influenza epidemic the following people, if exposed to a case, need oseltamivir "
    "prophylaxis EXCEPT",
    ["A haemodialysis patient", "A diabetic patient",
     "A kidney-transplant patient", "A corneal-transplant patient"])

add(587,
    "Which of the following is NOT an indication for influenza vaccine?",
    ["A 25-year-old woman in the first month of pregnancy",
     "A 75-year-old man with COPD",
     "A 3-month-old infant with a history of low birth weight",
     "A 35-year-old man with BMI >40"])

add(589,
    "The vaccination officer, because the number of influenza vaccine doses is low, asks you which "
    "group to prioritise. Which group has priority?",
    ["Chronic heart and lung disease", "BMI ≥ 25 kg/m2",
     "Age over 45 years", "Health-care personnel"])

add(590,
    "In which of the following do you NOT recommend inactivated influenza vaccine?",
    ["A history of fever after the first dose of vaccine",
     "A patient with HIV and a CD4 below 200",
     "Age under 6 months",
     "A history of multiple sclerosis"])

add(592,
    "In an epidemic of influenza B a child develops high fever, rigors, headache, myalgia and a "
    "cough. Wheeze is heard in the lungs. If the patient has a history of asthma, what is the most "
    "appropriate regimen?",
    ["Paracetamol + oseltamivir", "Aspirin + zanamivir",
     "Aspirin + amantadine", "Paracetamol + rimantadine"])

add(594,
    "Oseltamivir has been started for a patient with influenza. What is the commonest adverse effect "
    "of this drug?",
    ["Rash", "Nausea", "Headache", "Dizziness"])
