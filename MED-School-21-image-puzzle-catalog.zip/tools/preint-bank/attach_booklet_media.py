# -*- coding: utf-8 -*-
"""Attach official booklet films + teaching diagrams. Run after lesson apply."""
import json, glob, os

HERE = os.path.dirname(os.path.abspath(__file__))

OFFICIAL = {
    (1403, "رادیولوژی", 111): {
        "image": "/uploads/booklet-1403-q111-lbo.jpg",
        "image_caption_fa": "گرافی خوابیده (A) و دمر (B) دفترچه شهریور ۱۴۰۳ — پیکان روی کولون گشاد.",
        "image_caption_en": "Official Shahrivar 1403 supine (A) and prone (B) films — arrow on dilated colon.",
        "teach": "/uploads/booklet-1403-q111-lbo.jpg",
        "teach_fa": "فیلم رسمی دفترچه: هاسترا و پیکان روی حلقه کولون = انسداد روده بزرگ / ولوولوس.",
        "teach_en": "Official film: haustra and the arrow on a colonic loop = large-bowel obstruction / volvulus.",
    },
    (1403, "پوست", 128): {
        "image": "/uploads/booklet-1403-q128-elbow.jpg",
        "image_caption_fa": "رادیوگرافی رسمی دفترچه: دررفتگی خلفی آرنج.",
        "image_caption_en": "Official booklet radiograph: posterior elbow dislocation.",
        "teach": "/uploads/booklet-1403-q128-elbow.jpg",
        "teach_fa": "فیلم رسمی: اولکرانون پشت کندیل هومروس. جااندازی بسته. زخم ۷ cm = گوستیلیو II.",
        "teach_en": "Official film: olecranon behind the humeral condyle. Closed reduction. 7 cm wound = Gustilo II.",
    },
    (1403, "پاتولوژی", 178): {
        "image": "/uploads/booklet-1403-q178-pedigree.png",
        "image_caption_fa": "شجره چاپ‌شده دفترچه شهریور ۱۴۰۳.",
        "image_caption_en": "Printed Shahrivar 1403 pedigree.",
        "teach": "/uploads/teach-inheritance.svg",
        "teach_fa": "شکل دفترچه زن مبتلا و پدر→پسر دارد → AD.",
        "teach_en": "Printed tree has affected women and father-to-son → AD.",
        "key_corrected": True,
        "original_correct_index": 1,
        "correct_index": 0,
        "key_correction_fa": "تصحیح کلید: شجره چاپ‌شده پدر به پسر و زن مبتلا دارد؛ اتوزوم غالب است نه XR.",
        "key_correction_en": "Key correction: printed pedigree has father-to-son and affected women; it is AD, not XR.",
        "key_correction_source": "Thompson pedigree rules",
        "golden_fa": "شکل دفترچه: زن مبتلا + پدر→پسر = **اتوزوم غالب** نه XR.",
        "golden_en": "Printed figure: affected woman + father-to-son = **AD**, not XR.",
        "explanation_fa": "تصحیح کلید چاپی XR: در شکل رسمی هم زن قرمز مبتلا هست هم انتقال پدر به پسر. XR پدر X را به پسر نمی‌دهد. کلید درست اتوزوم غالب است.",
        "explanation_en": "Key correction of printed XR: the official figure has fully affected women and father-to-son. XR cannot give the father's X to a son. Correct key is autosomal dominant.",
        "options_why_fa": [
            "پاسخ صحیح پس از تصحیح — شکل رسمی زن مبتلا و پدر→پسر دارد: اتوزوم غالب.",
            "کلید چاپی XR است؛ XR پدر X را به پسر نمی‌دهد.",
            "XD پدر مبتلا همه دخترها را مبتلا می‌کند ولی پسرها را نه.",
            "AR پرش نسل و والدین سالم می‌خواهد؛ اینجا هر نسل مبتلا دارد.",
        ],
        "options_why_en": [
            "Correct after the key fix — official figure has affected women and father-to-son: AD.",
            "Printed key is XR; XR cannot give a father's X to a son.",
            "XD: affected father hits every daughter, not sons.",
            "AR wants skipped generations and well parents.",
        ],
    },
    (1402, "ژنتیک پزشکی", 180): {
        "image": "/uploads/booklet-1402-q180-pedigree.png",
        "image_caption_fa": "شجره چاپ‌شده دفترچه خرداد ۱۴۰۲.",
        "image_caption_en": "Printed Khordad 1402 pedigree.",
        "teach": "/uploads/booklet-1402-q180-pedigree.png",
        "teach_fa": "فیلم رسمی: خط دوگانه = ازدواج فامیلی؛ دو جنس مبتلا = AR = CF.",
        "teach_en": "Official figure: double bar = consanguinity; both sexes = AR = CF.",
    },
    (1402, "جراحی", 59): {
        "image": "/uploads/booklet-1402-q59-ea.jpg",
        "image_caption_fa": "گرافی نوزاد دفترچه خرداد ۱۴۰۲: لوله در کیسه بالایی + گاز روده.",
        "image_caption_en": "Official Khordad 1402 newborn film: tube coiled in the upper pouch + bowel gas.",
        "teach": "/uploads/booklet-1402-q59-ea.jpg",
        "teach_fa": "فیلم رسمی: NG پیچیده در پوچ + گاز شکم = آترزی مری با فیستول دیستال.",
        "teach_en": "Official film: coiled NG in the pouch + abdominal gas = EA with distal TEF.",
    },
}

TEACH_BY_CONCEPT = {
    "apoptosis-no-inflammation": ("/uploads/teach-apoptosis-necrosis.svg",
        "آپوپتوز: کوچک و بی‌التهاب. نکروز: پاره و پرالتهاب.",
        "Apoptosis: small, no inflammation. Necrosis: ruptured and inflamed."),
    "stage-vs-grade": ("/uploads/teach-tnm.svg",
        "TNM جای تومور است. تمایز درجه است.",
        "TNM is where the tumour is. Differentiation is grade."),
    "clubfoot-equinus": ("/uploads/teach-cave-clubfoot.svg",
        "CAVE: کاووس، اداکشن، واروس، اکوینوس.",
        "CAVE: cavus, adductus, varus, equinus."),
    "pecam-diapedesis": ("/uploads/teach-diapedesis.svg",
        "غلتیدن سلکتین → چسبیدن اینتگرین → عبور PECAM-1.",
        "Roll on selectin → stick with integrin → cross on PECAM-1."),
    "eccentric-series-sarcomere": ("/uploads/teach-hypertrophy.svg",
        "فشار = هم‌مرکز. حجم = برون‌مرکز.",
        "Pressure = concentric. Volume = eccentric."),
    "xr-pedigree": ("/uploads/teach-inheritance.svg",
        "XR: پسرها، بدون پدر→پسر.",
        "XR: boys, no father-to-son."),
    "cf-ar-pedigree": ("/uploads/teach-inheritance.svg",
        "AR: والدین سالم، دو جنس، خویشاوندی.",
        "AR: well parents, both sexes, consanguinity."),
    "ar-recurrence-25": ("/uploads/teach-inheritance.svg",
        "ناقل×ناقل AR: ۲۵٪ بیمار.",
        "AR carrier × carrier: 25% ill."),
    "farm-open-penicillin": ("/uploads/teach-gustilo.svg",
        "۷ cm = II. مزرعه یا >۱۰ cm = III.",
        "7 cm = II. Farm or >10 cm = III."),
    "open-elbow-closed-reduce": ("/uploads/teach-gustilo.svg",
        "زخم ۷ cm تایپ II است نه III.",
        "A 7 cm wound is type II, not III."),
}


def apply():
    files = sorted(glob.glob(os.path.join(HERE, "import-payload.archive.part*.json")))
    n_img = n_teach = n_key = 0
    for path in files:
        body = json.load(open(path, encoding="utf-8"))
        changed = False
        for q in body["questions"]:
            key = (int(q.get("year_num") or 0), q.get("subject_fa"), int(q.get("question_no") or 0))
            spec = OFFICIAL.get(key)
            if spec:
                q["image"] = spec["image"]
                q["image_caption_fa"] = spec["image_caption_fa"]
                q["image_caption_en"] = spec["image_caption_en"]
                q["media"] = {
                    "url": spec["image"], "kind": "image",
                    "caption_fa": spec["image_caption_fa"],
                    "caption_en": spec["image_caption_en"],
                }
                micro = q.get("micro") or {}
                micro["media"] = {
                    "url": spec["teach"], "kind": "image",
                    "caption_fa": spec["teach_fa"],
                    "caption_en": spec["teach_en"],
                }
                q["micro"] = micro
                if spec.get("key_corrected"):
                    q["original_correct_index"] = spec["original_correct_index"]
                    q["correct_index"] = spec["correct_index"]
                    q["key_corrected"] = True
                    q["key_correction_fa"] = spec["key_correction_fa"]
                    q["key_correction_en"] = spec["key_correction_en"]
                    q["key_correction_source"] = spec["key_correction_source"]
                    q["golden_fa"] = spec["golden_fa"]
                    q["golden_en"] = spec["golden_en"]
                    q["explanation_fa"] = spec["explanation_fa"]
                    q["explanation_en"] = spec["explanation_en"]
                    if spec.get("options_why_fa"):
                        q["options_why_fa"] = spec["options_why_fa"]
                        q["options_why_en"] = spec["options_why_en"]
                    n_key += 1
                n_img += 1
                changed = True
                continue
            concept = q.get("concept") or ""
            if concept in TEACH_BY_CONCEPT and q.get("needs_lesson") is False:
                url, cap_fa, cap_en = TEACH_BY_CONCEPT[concept]
                micro = q.get("micro") or {}
                if not micro.get("media"):
                    micro["media"] = {"url": url, "kind": "image", "caption_fa": cap_fa, "caption_en": cap_en}
                    q["micro"] = micro
                    n_teach += 1
                    changed = True
        if changed:
            json.dump(body, open(path, "w", encoding="utf-8"), ensure_ascii=False)
    print(f"official films on {n_img}; teaching figures on {n_teach}; key fixes {n_key}")


if __name__ == "__main__":
    apply()
