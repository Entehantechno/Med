# -*- coding: utf-8 -*-
"""Khordad-1402 remaining majors: internal 24–42, peds 71–80, OB 91–96.

Skip 19 (garbled). Official English stems/options are never rewritten.
Internal 25 FA stem is scan-truncated — keep verbatim; teach from official EN.
Internal 40 EN options are misaligned in the ministry booklet — keep verbatim.
"""
import json, glob, os

HERE = os.path.dirname(os.path.abspath(__file__))
L = {}


def add(subj, no, **kw):
    L[(subj, no)] = kw


def pts(fa, en):
    return {"lead_fa": fa[0], "lead_en": en[0], "points_fa": fa[1:], "points_en": en[1:]}


add("داخلی", 24,
    chapter_fa="استخوان / پوکی استخوان", chapter_en="Bone / osteoporosis",
    options_why_fa=[
        "پاسخ صحیح — ویتامین A زیاد تحلیل استخوان را بیشتر می‌کند و پیشگیری نیست.",
        "ورزش تحمل وزن دانسیته را حفظ می‌کند.",
        "ویتامین D جذب کلسیم را بالا می‌برد.",
        "سیگار تحلیل استخوان را تشدید می‌کند؛ قطعش پیشگیری است.",
    ],
    options_why_en=[
        "Correct — excess vitamin A increases bone resorption and is not prevention.",
        "Weight-bearing exercise preserves density.",
        "Vitamin D raises calcium absorption.",
        "Smoking worsens bone loss; stopping it is prevention.",
    ],
    explanation_fa=(
        "پیشگیری پوکی استخوان: کلسیم و ویتامین D کافی، ورزش تحمل وزن، قطع سیگار و الکل، "
        "و درمان هیپوگنادیسم. رتینوئید و ویتامین A زیاد استئوکلاست را تحریک می‌کند."
    ),
    explanation_en=(
        "Osteoporosis prevention is enough calcium and vitamin D, weight-bearing exercise, "
        "stopping smoke and excess alcohol, and treating hypogonadism. Excess vitamin A "
        "stimulates osteoclasts."
    ),
    micro=pts(
        ["ویتامین A پیشگیری پوکی استخوان نیست؛ ورزش و D و ترک سیگار هستند.",
         "NOF: کلسیم ۱۲۰۰ میلی‌گرم بعد از یائسگی.",
         "ویتامین D هدف سرم معمولاً بالای ۲۰ تا ۳۰.",
         "پیاده‌روی و مقاومت بهتر از شنای تنهاست.",
         "گلوکوکورتیکوئید شایع‌ترین علت ثانویه است.",
         "FRAX تصمیم دارو را می‌سازد.",
         "بیس‌فسفونات خط اول درمان است نه پیشگیری همگانی.",
         "هیپرویتامینوز A شکستگی می‌دهد.",
         "ایزوترتینوئین طولانی را در جوان پایش کن.",
         "DEXA از ۶۵ سالگی یا زودتر اگر خطر باشد.",
         "زمین‌خوردن را جداگانه کم کن."],
        ["Vitamin A is not osteoporosis prevention; exercise, D and stopping smoke are.",
         "NOF: about 1200 mg calcium after menopause.",
         "Vitamin D target is usually above 20–30 ng/ml.",
         "Walking and resistance beat swimming alone.",
         "Glucocorticoids are the commonest secondary cause.",
         "FRAX decides about drugs.",
         "A bisphosphonate is first-line treatment, not universal prevention.",
         "Hypervitaminosis A causes fractures.",
         "Watch long isotretinoin in the young.",
         "DEXA from 65, or earlier if risk is high.",
         "Fall-proof the house separately."],
    ),
    golden_fa="پوکی: D و ورزش و ترک سیگار. ویتامین A نه.",
    golden_en="Osteoporosis: D, exercise, stop smoking. Not vitamin A.",
    refs=["Harrison 21 — Osteoporosis"],
    concept="osteo-not-vita", concept_fa="ویتامین A و پوکی", concept_en="Vitamin A not osteoporosis")

add("داخلی", 25,
    chapter_fa="خون / TTP پس از زایمان", chapter_en="Heme / postpartum TTP",
    options_why_fa=[
        "آنتی‌بیوتیک مال سپسیس یا پیلونفریت است؛ اینجا همولیز میکروآنژیوپاتیک است.",
        "فشار ۱۵۰/۹۰ اورژانس فشار نیست؛ پلاسما اولویت دارد.",
        "پلاکت بدون پلاسما در TTP ترومبوز را بدتر می‌کند.",
        "پاسخ صحیح — TTP/aHUS پس از زایمان با تعویض پلاسما درمان می‌شود.",
    ],
    options_why_en=[
        "Antibiotics are for sepsis or pyelo; this is microangiopathic hemolysis.",
        "150/90 is not a hypertensive emergency; plasma comes first.",
        "Platelets without plasma can worsen TTP thrombosis.",
        "Correct — postpartum TTP/aHUS is treated with plasmapheresis.",
    ],
    explanation_fa=(
        "صورت فارسی اسکن ناقص است و دست‌نخورده ماند. متن انگلیسی رسمی: خانم ۳۵ ساله "
        "پس از زایمان با خواب‌آلودگی، فشار ۱۵۰/۹۰ و هماچوری. تصویر TTP/HUS است. "
        "درمان فوری پلاسمافرز است نه آنتی‌بیوتیک و نه پلاکت تنها."
    ),
    explanation_en=(
        "The official English booklet: a 35-year-old after delivery, lethargic, "
        "BP 150/90, heavy hematuria. That is TTP/HUS. Immediate treatment is plasma exchange."
    ),
    micro=pts(
        [" pentad کلاسیک TTP دیگر اجباری نیست؛ MAHA + ترومبوسیتوپنی کافی است.",
         "ADAMTS13 خیلی پایین TTP را ثابت می‌کند.",
         "پس از زایمان aHUS هم هست؛ باز پلاسما شروع می‌شود.",
         "HELLP معمولاً قبل یا حین زایمان است و فشار بالاتر دارد.",
         "پلاکت را تا شروع پلاسما نگه دار مگر خونریزی تهدیدکننده.",
         "کورتیکواستروئید همراه پلاسما در TTP رایج است.",
         "کاپلاسیزوماب در TTP ایمنی‌زاد اضافه می‌شود.",
         "دیالیز کلیه را نجات می‌دهد ولی علت را درمان نمی‌کند.",
         "اکلامپسی تشنج و کلونوس می‌دهد.",
         "هر MAHA پس از زایمان را اورژانس هماتولوژی بدان.",
         "متن فارسی دفترچه ناقص است؛ از انگلیسی رسمی درس بگیر."],
        ["The classic TTP pentad is no longer required; MAHA plus thrombocytopenia is enough.",
         "Very low ADAMTS13 proves TTP.",
         "Postpartum aHUS exists; still start plasma.",
         "HELLP is usually before or during birth and the pressure is higher.",
         "Hold platelets until plasma starts unless bleeding threatens life.",
         "Steroid with plasma is common in TTP.",
         "Caplacizumab is added in immune TTP.",
         "Dialysis saves the kidney but does not treat the cause.",
         "Eclampsia gives seizures and clonus.",
         "Treat every postpartum MAHA as a hematology emergency.",
         "The Persian scan is truncated; learn from the official English."],
    ),
    golden_fa="پس از زایمان + خواب‌آلودگی + هماچوری: پلاسمافرز.",
    golden_en="Postpartum lethargy plus hematuria: plasmapheresis.",
    refs=["Harrison 21 — TTP / HUS"],
    concept="postpartum-ttp", concept_fa="TTP پس از زایمان", concept_en="Postpartum TTP")

add("داخلی", 26,
    chapter_fa="کلیه / سنگ", chapter_en="Kidney / stones",
    options_why_fa=[
        "اسید اوریک در ادرار اسیدی رسوب می‌کند.",
        "پاسخ صحیح — حلالیت اگزالات کلسیم تقریباً مستقل از pH ادرار است.",
        "سیستین در ادرار اسیدی رسوب می‌کند.",
        "فسفات کلسیم در ادرار قلیایی رسوب می‌کند.",
    ],
    options_why_en=[
        "Uric acid precipitates in acid urine.",
        "Correct — calcium oxalate solubility is almost independent of urine pH.",
        "Cystine precipitates in acid urine.",
        "Calcium phosphate precipitates in alkaline urine.",
    ],
    explanation_fa=(
        "قلیایی کردن ادرار سنگ اوریک و سیستین را حل می‌کند. اسیدی کردن برای استروویت "
        "گاهی مطرح است. اگزالات کلسیم شایع‌ترین سنگ است و pH ادرار حلالیتش را عوض نمی‌کند."
    ),
    explanation_en=(
        "Alkalinising urine dissolves uric acid and cystine. Acidifying is sometimes "
        "discussed for struvite. Calcium oxalate is the commonest stone and urine pH "
        "does not change its solubility."
    ),
    micro=pts(
        ["اگزالات کلسیم ≈ ۷۰ درصد سنگ‌هاست.",
         "هیپرکلسیوری و هیپراگزالوری و هیپوسیتراتوری خطر را می‌برند.",
         "سیترات مهارکننده طبیعی است.",
         "اوریک اسید رادیولوسنت است.",
         "سیستین شش‌ضلعی است.",
         "استروویت سنگ عفونت است (لوله copi).",
         "آب زیاد درمان همه سنگ‌هاست.",
         "تیازید کلسیم ادرار را کم می‌کند.",
         "آلکالینیزاسیون با سیترات پتاسیم است.",
         "pH هدف اوریک حدود ۶٫۵ است.",
         "اگزالات را با pH درمان نکن."],
        ["Calcium oxalate is about 70% of stones.",
         "Hypercalciuria, hyperoxaluria and hypocitraturia raise risk.",
         "Citrate is the natural inhibitor.",
         "Uric acid is radiolucent.",
         "Cystine is hexagonal.",
         "Struvite is the infection stone.",
         "Water is treatment for every stone.",
         "A thiazide lowers urine calcium.",
         "Alkalinise with potassium citrate.",
         "Uric-acid pH target is about 6.5.",
         "Do not treat oxalate with pH."],
    ),
    golden_fa="اگزالات کلسیم از pH ادرار مستقل است.",
    golden_en="Calcium oxalate is independent of urine pH.",
    refs=["Harrison 21 — Nephrolithiasis"],
    concept="caox-ph", concept_fa="اگزالات و pH", concept_en="CaOx and pH")

add("داخلی", 27,
    chapter_fa="کلیه / هماچوری", chapter_en="Kidney / hematuria",
    options_why_fa=[
        "IgA هماچوری سینفارنژیتيک کلاسیک است.",
        "پاسخ صحیح — بیماری تغییر حداقل پروتئین نفروتیک می‌دهد نه هماچوری ایزوله.",
        "آلپورت هماچوری پایدار خانوادگی است.",
        "غشای پایه نازک هماچوری خوش‌خیم می‌دهد.",
    ],
    options_why_en=[
        "IgA is classic synpharyngitic hematuria.",
        "Correct — minimal-change disease gives nephrotic protein, not isolated hematuria.",
        "Alport is persistent familial hematuria.",
        "Thin basement membrane gives benign hematuria.",
    ],
    explanation_fa=(
        "مرد ۳۰ ساله با کراتینین طبیعی، پروتئین ۱+ و خون ۳+ و ۳۰ گلبول. این گلومرولونفریت "
        "خفیف یا هماچوری خانوادگی است. MCD ادم و آلبومین پایین و پروتئین بالای ۳٫۵ می‌خواهد."
    ),
    explanation_en=(
        "A 30-year-old with normal creatinine, 1+ protein and 3+ blood is mild GN or "
        "familial hematuria. MCD wants oedema, low albumin and more than 3.5 g of protein."
    ),
    micro=pts(
        ["هماچوری گلومرولی: دیسمورف و کست گلبول.",
         "IgA یک تا دو روز بعد از URI خون می‌دهد.",
         "PSGN یک تا سه هفته فاصله دارد.",
         "آلپورت: کاهش شنوایی و عدسی.",
         "TBM خوش‌خیم است و بیوپسی لازم ندارد اگر خانواده سالم باشد.",
         "MCD شایع‌ترین نفروتیک کودک است.",
         "بالغ MCD را با NSAID و لنفوم فکر کن.",
         "بیوپسی اگر پروتئین زیاد یا Cr بالا یا کست باشد.",
         "سیستوسکوپی مال هماچوری غیرگلومرولی سن بالا است.",
         "سؤال بجز یعنی سه تا هماچوری می‌دهند.",
         "پروتئین ۱+ نفروتیک نیست."],
        ["Glomerular hematuria: dysmorphic cells and red-cell casts.",
         "IgA bleeds one to two days after a URI.",
         "PSGN waits one to three weeks.",
         "Alport: hearing loss and lens problems.",
         "TBM is benign; skip biopsy if the family is well.",
         "MCD is the commonest childhood nephrotic syndrome.",
         "In adults think of NSAIDs and lymphoma with MCD.",
         "Biopsy if protein is heavy or Cr is up or casts are present.",
         "Cystoscopy is for nonglomerular hematuria in older adults.",
         "An except stem means three answers cause hematuria.",
         "1+ protein is not nephrotic."],
    ),
    golden_fa="هماچوری ایزوله: MCD نیست.",
    golden_en="Isolated hematuria is not MCD.",
    refs=["Harrison 21 — Glomerular disease"],
    concept="mcd-not-hematuria", concept_fa="MCD نه هماچوری", concept_en="MCD not hematuria")

add("داخلی", 28,
    chapter_fa="کلیه / ائوزینوفیلوری", chapter_en="Kidney / eosinophiluria",
    options_why_fa=[
        "پاسخ صحیح — واسکولیت عروق کوچک RPGN و کست می‌دهد نه ائوزینوفیل ادرار.",
        "UTI گاهی ائوزینوفیل ادرار می‌دهد.",
        "نفریت اینترستیشیل آلرژیک کلاسیک Hansel مثبت است.",
        "آمبولی کلسترول بعد از کاتتر ائوزینوفیلوری می‌دهد.",
    ],
    options_why_en=[
        "Correct — small-vessel vasculitis is RPGN and casts, not urine eosinophils.",
        "UTI can show urine eosinophils.",
        "Allergic interstitial nephritis is the classic Hansel-positive disease.",
        "Cholesterol emboli after a catheter give eosinophiluria.",
    ],
    explanation_fa=(
        "رنگ Hansel ائوزینوفیل ادرار را برای AIN و آمبولی کلسترول و گاهی عفونت نشان می‌دهد. "
        "حساسیت پایین است. واسکولیت ANCA هماچوری فعال و کرسنت می‌سازد نه ائوزینوفیلوری."
    ),
    explanation_en=(
        "Hansel stain shows urine eosinophils in AIN, cholesterol emboli and sometimes "
        "infection. Sensitivity is low. ANCA vasculitis makes an active sediment and crescents, "
        "not eosinophiluria."
    ),
    micro=pts(
        ["AIN: تب، راش، ائوزینوفیلی خون بعد از دارو.",
         "بتالاکتام و PPI و NSAID شایع‌اند.",
         "Hansel منفی AIN را رد نمی‌کند.",
         "آمبولی کلسترول: livedo و انگشت آبی بعد از آنژیو.",
         "ائوزینوفیلی سیستمیک در کلسترول هم هست.",
         "RPGN را با ANCA و anti-GBM بجوی.",
         "بیوپسی کلیه تشخیص قطعی واسکولیت است.",
         "استروئید در AIN شدید زود کمک می‌کند.",
         "قطع داروی مقصر قدم اول AIN است.",
         "سؤال بجز یعنی سه تا Hansel می‌دهند.",
         "رسوب فعال ≠ ائوزینوفیل."],
        ["AIN: fever, rash, blood eosinophils after a drug.",
         "Beta-lactams, PPIs and NSAIDs are common.",
         "A negative Hansel does not exclude AIN.",
         "Cholesterol emboli: livedo and a blue toe after angio.",
         "Systemic eosinophilia happens in cholesterol emboli too.",
         "Hunt RPGN with ANCA and anti-GBM.",
         "Kidney biopsy proves vasculitis.",
         "Steroid helps early in severe AIN.",
         "Stop the culprit drug first in AIN.",
         "An except stem means three answers are Hansel-positive.",
         "An active sediment is not eosinophils."],
    ),
    golden_fa="ائوزینوفیلوری: AIN و کلسترول. واسکولیت کوچک نه.",
    golden_en="Eosinophiluria: AIN and cholesterol. Not small-vessel vasculitis.",
    refs=["Harrison 21 — Acute interstitial nephritis"],
    concept="hansel-not-vasculitis", concept_fa="هانسل نه واسکولیت", concept_en="Hansel not vasculitis")

add("داخلی", 29,
    chapter_fa="کلیه / میلوم", chapter_en="Kidney / myeloma",
    options_why_fa=[
        "داپلر عروق برای تنگی شریان است؛ ادم دوطرف و درد استخوان را توضیح نمی‌دهد.",
        "بیوپسی قدم بعد تشخیص است نه اول.",
        "پاسخ صحیح — بدون رتینوپاتی و با درد استخوان، SPEP/UPEP میلوم را می‌جوید.",
        "ANCA برای RPGN است نه پروتئین سبک.",
    ],
    options_why_en=[
        "Vessel Doppler is for renal-artery stenosis; it does not explain bilateral oedema and bone pain.",
        "Biopsy is the next diagnostic step, not the first.",
        "Correct — no retinopathy plus bone pain: SPEP/UPEP hunts myeloma.",
        "ANCA is for RPGN, not light-chain disease.",
    ],
    explanation_fa=(
        "دیابت پنج‌ساله بدون رتینوپاتی بعید است نفروپاتی دیابتی کلاسیک بسازد. درد استخوان "
        "و ادم دو طرف میلوم و آمیلوئید را فریاد می‌زند. اول الکتروفورز سرم و ادرار."
    ),
    explanation_en=(
        "Five years of diabetes without retinopathy is unlikely to be classic diabetic "
        "nephropathy. Bone pain and bilateral oedema shout myeloma or amyloid. First SPEP and UPEP."
    ),
    micro=pts(
        ["نفروپاتی دیابتی معمولاً بعد از رتینوپاتی می‌آید.",
         "پروتئین سبک روی دیپستیک کم دیده می‌شود؛ UPEP لازم است.",
         "CRAB: کلسیم، کلیه، آنمی، استخوان.",
         "FLC سرم حساس‌تر از SPEP تنهاست.",
         "آمیلوئید AL کلیه بزرگ و نفروتیک می‌دهد.",
         "بیوپسی بعد از یافتن پروتئین مونوکلونال.",
         "ANCA اگر رسوب فعال و افت سریع Cr باشد.",
         "تنگی شریان کلیه نامتقارن و ACEI-rise است.",
         "سونوگرافی اندازه کلیه را می‌گوید.",
         "در سالمند نفروتیک همیشه میلوم را در لیست بگذار.",
         "درمان میلوم کلیه را هم بهتر می‌کند."],
        ["Diabetic nephropathy usually follows retinopathy.",
         "Light chains hide from the dipstick; you need UPEP.",
         "CRAB: calcium, renal, anaemia, bone.",
         "Serum FLC is more sensitive than SPEP alone.",
         "AL amyloid gives large kidneys and nephrotic syndrome.",
         "Biopsy after you find a monoclonal protein.",
         "ANCA if the sediment is active and Cr is crashing.",
         "Renal-artery stenosis is asymmetric and ACEI-rise.",
         "Ultrasound tells kidney size.",
         "In a nephrotic elder always list myeloma.",
         "Treating myeloma also helps the kidney."],
    ),
    golden_fa="ادم + درد استخوان بدون رتینوپاتی: الکتروفورز.",
    golden_en="Oedema plus bone pain without retinopathy: electrophoresis.",
    refs=["Harrison 21 — Plasma cell disorders"],
    concept="spep-myeloma-kidney", concept_fa="الکتروفورز میلوم", concept_en="SPEP myeloma kidney")

add("داخلی", 30,
    chapter_fa="قلب / میترال", chapter_en="Heart / mitral",
    options_why_fa=[
        "پاسخ صحیح — سوفل دیاستولیک آپکس + AF در زن میانسال = تنگی روماتیسمی میترال.",
        "تنگی آئورت سوفل سیستولیک است نه دیاستولیک آپکس.",
        "PDA بدون پرفشاری ریه ماشین مداوم است نه دیاستول خالص.",
        "نارسایی تریکوسپید سیستولیک لبه استرنوم است.",
    ],
    options_why_en=[
        "Correct — an apical diastolic murmur plus AF in a middle-aged woman is rheumatic MS.",
        "Aortic stenosis is a systolic murmur, not an apical diastolic one.",
        "PDA without pulmonary hypertension is continuous machinery, not pure diastole.",
        "TR is systolic at the sternal edge.",
    ],
    explanation_fa=(
        "روماتیسم هنوز در ایران علت شایع MS است. تنگی میترال دهلیز چپ را گشاد و AF می‌سازد. "
        "سوفل rumble دیاستولیک با opening snap کلاسیک است."
    ),
    explanation_en=(
        "Rheumatic disease is still a common cause of MS in Iran. Mitral stenosis dilates "
        "the left atrium and makes AF. The rumble with an opening snap is classic."
    ),
    micro=pts(
        ["سطح دریچه زیر ۱٫۵ سانتی‌مترمربع تنگی مهم است.",
         "P2 بلند یعنی پرفشاری شریان ریوی.",
         "وارفارین در MS + AF واجب است حتی اگر CHA2DS2 پایین باشد.",
         "بتابلوکر دیاستول را برای پر شدن طولانی می‌کند.",
         "PMBV اگر دریچه مناسب و لخته نباشد.",
         "تنگی آئورت پیر کلسیفیه است و سیستولیک.",
         "نارسایی میترال هولوسیستولیک آپکس به آگزیلا است.",
         "ASD سوفل ثابت دو نیمه‌ای دارد نه rumble خالص.",
         "اکو تشخیص را قطعی می‌کند.",
         "بارداری MS را بحرانی می‌کند.",
         "پروفیلاکسی روماتیسم را در جوان فراموش نکن."],
        ["An area under 1.5 cm² is important stenosis.",
         "A loud P2 means pulmonary hypertension.",
         "Warfarin is mandatory in MS plus AF even if CHA2DS2 is low.",
         "A beta-blocker lengthens diastole for filling.",
         "PMBV if the valve is suitable and there is no clot.",
         "Aortic stenosis in the old is calcific and systolic.",
         "MR is holosystolic at the apex to the axilla.",
         "ASD has a fixed split, not a pure rumble.",
         "Echo makes the diagnosis.",
         "Pregnancy makes MS critical.",
         "Do not forget rheumatic prophylaxis in the young."],
    ),
    golden_fa="سوفل دیاستولیک آپکس + AF = MS روماتیسمی.",
    golden_en="Apical diastolic murmur plus AF is rheumatic MS.",
    refs=["Harrison 21 — Valvular heart disease"],
    concept="rheumatic-ms", concept_fa="تنگی میترال روماتیسمی", concept_en="Rheumatic MS")

add("داخلی", 31,
    chapter_fa="قلب / فیبریلاسیون دهلیزی", chapter_en="Heart / AF",
    options_why_fa=[
        "پاسخ صحیح — AF با پاسخ سریع و فشار پایدار: کنترل سرعت با دیلتiazem.",
        "کاردیوورژن برای ناپایدار همودینامیک است نه فشار ۱۷۰/۹۰.",
        "بتابلوکر منطقی است ولی آسپرین به‌جای ضدانعقاد غلط است.",
        "وراپامیل کنترل سرعت می‌کند اما وارفارین بدون محاسبه CHA2DS2 عجله است و گزینه ترکیبی غلط چیده شده.",
    ],
    options_why_en=[
        "Correct — fast AF with stable pressure: rate control with diltiazem.",
        "Cardioversion is for hemodynamic instability, not 170/90.",
        "A beta-blocker is reasonable but aspirin is not anticoagulation.",
        "Verapamil rate-controls, but jumping to warfarin without CHA2DS2 and pairing it this way is the wrong package.",
    ],
    explanation_fa=(
        "مرد پایدار با irregularly irregular و ضربان ۱۴۰ نیاز به کنترل سرعت دارد. "
        "بلوک‌کننده کلسیم غیردی‌هیدروپیریدین خط اول است اگر نارسایی قلب نباشد. "
        "شوک الکتریکی وقتی فشار می‌افتد یا ادم حاد ریه است."
    ),
    explanation_en=(
        "A stable man with irregularly irregular rate 140 needs rate control. A non-DHP "
        "calcium blocker is first-line if there is no heart failure. Shock when pressure "
        "collapses or there is acute pulmonary oedema."
    ),
    micro=pts(
        ["هدف سرعت معمولاً زیر ۱۱۰ در حال استراحت است (RACE II).",
         "دیلتiazem و وراپامیل در EF پایین ممنوع‌اند.",
         "اگر HFrEF باشد بتابلوکر یا دیگوکسین.",
         "آسپرین جای وارفارین یا DOAC را نمی‌گیرد.",
         "CHA2DS2-VASc تصمیم ضدانعقاد است.",
         "اگر بیش از ۴۸ ساعت باشد قبل از ریتم TEE یا ۳ هفته ضدانعقاد.",
         "سیگاری بودن خطر عروق را بالا می‌برد ولی الگوریتم را عوض نمی‌کند.",
         "فشار ۱۷۰ را جداگانه آرام پایین بیاور.",
         "آمiodارون کنترل ریتم است نه قدم اول پایدار.",
         "ECG را برای pre-excitation ببین؛ WPW + AF پروکائینامید می‌خواهد نه AV blocker.",
         "این بیمار WPW ندارد."],
        ["Rate target is usually under 110 at rest (RACE II).",
         "Diltiazem and verapamil are forbidden when EF is low.",
         "If HFrEF, a beta-blocker or digoxin.",
         "Aspirin does not replace warfarin or a DOAC.",
         "CHA2DS2-VASc decides anticoagulation.",
         "If longer than 48 hours, TEE or 3 weeks of anticoagulant before rhythm.",
         "Smoking raises vascular risk but not this algorithm.",
         "Bring 170 down gently and separately.",
         "Amiodarone is rhythm control, not the first stable step.",
         "Check the ECG for pre-excitation; WPW plus AF wants procainamide, not an AV blocker.",
         "This patient does not have WPW."],
    ),
    golden_fa="AF پایدار تند: دیلتiazem. شوک مال ناپایدار است.",
    golden_en="Stable fast AF: diltiazem. Shock is for the unstable.",
    refs=["Harrison 21 — Atrial fibrillation"],
    concept="af-diltiazem", concept_fa="دیلتiazem در AF", concept_en="Diltiazem in AF")

add("داخلی", 32,
    chapter_fa="فشار / نقرس", chapter_en="Hypertension / gout",
    options_why_fa=[
        "لوزارتان اوریک اسید را کمی پایین می‌آورد؛ قطعش نقرس را بهتر نمی‌کند.",
        "آملودیپین روی اورات اثری ندارد و فشار را خوب گرفته.",
        "پاسخ صحیح — تیازید اوریک اسید را بالا می‌برد و حمله نقرس می‌سازد.",
        "بیزوپرولول خط اول نقرس نیست اما مقصر اصلی تیازید است.",
    ],
    options_why_en=[
        "Losartan slightly lowers uric acid; stopping it does not help gout.",
        "Amlodipine does not touch urate and the pressure is already good.",
        "Correct — a thiazide raises uric acid and triggers gout.",
        "Bisoprolol is not first-line in gout but the main culprit is the thiazide.",
    ],
    explanation_fa=(
        "فشار ۱۲۵/۸۰ خوب است. دو حمله نقرس و اورات ۱۰ یعنی داروهای بالابرنده اورات را قطع کن. "
        "هیدروکلروتیازید کلاسیک این کار را می‌کند. لوزارتان اتفاقاً اوریکوزوریک ضعیف است."
    ),
    explanation_en=(
        "125/80 is fine. Two gout attacks and a urate of 10 mean stop urate-raising drugs. "
        "Hydrochlorothiazide classically does that. Losartan is actually a weak uricosuric."
    ),
    micro=pts(
        ["تیازید و لوپ اورات را بالا می‌برند.",
         "لوزارتان تنها ARB اوریکوزوریک است.",
         "آسپرین کم‌دوز اورات را کمی بالا می‌برد.",
         "هدف اورات در نقرس معمولاً زیر ۶ است.",
         "آلوپورینول را در حمله حاد قطع نکن اگر از قبل می‌خورده.",
         "فشار هدف این سن اغلب زیر ۱۳۰ است؛ اینجا رسیده.",
         "به‌جای تیازید بلوک کلسیم یا لوزارتان را نگه دار.",
         "بیزوپرولول را بی‌دلیل قطع نکن.",
         "کاهش وزن و الکل را هم بگو.",
         "CKD دوز تیازید را محدود می‌کند.",
         "حمله حاد: کلشی‌سین یا NSAID یا استروئید."],
        ["Thiazides and loops raise urate.",
         "Losartan is the only uricosuric ARB.",
         "Low-dose aspirin raises urate a little.",
         "Gout urate target is usually under 6.",
         "Do not stop allopurinol in an acute attack if he was already on it.",
         "BP target at this age is often under 130; he is there.",
         "Keep the calcium blocker or losartan instead of the thiazide.",
         "Do not stop bisoprolol without a reason.",
         "Also talk about weight and alcohol.",
         "CKD limits the thiazide dose.",
         "Acute attack: colchicine or NSAID or steroid."],
    ),
    golden_fa="نقرس + تیازید: تیازید را قطع کن.",
    golden_en="Gout plus a thiazide: stop the thiazide.",
    refs=["Harrison 21 — Hypertension; Gout"],
    concept="hctz-gout", concept_fa="تیازید و نقرس", concept_en="Thiazide and gout")

add("داخلی", 33,
    chapter_fa="قلب / تامپوناد", chapter_en="Heart / tamponade",
    options_why_fa=[
        "پاسخ صحیح — alternans + صدای خفه + jugular برجسته = اکو برای پریکارد.",
        "آنژیو برای سندرم کرونری است نه تامپوناد.",
        "گرافی قلب بطری ممکن است نشان دهد ولی حساسیت ندارد.",
        "اسکن پرفیوژن برای آمبولی است.",
    ],
    options_why_en=[
        "Correct — alternans plus muffled sounds plus raised JVP is echo for the pericardium.",
        "Angio is for a coronary syndrome, not tamponade.",
        "A chest film may show a water-bottle heart but it is insensitive.",
        "A perfusion scan is for embolism.",
    ],
    explanation_fa=(
        "سرطان پستان و ماستکتومی زمینه بدخیمی پریکارد است. سه‌گانه بک + electrical alternans "
        "یعنی Tamponade تا خلافش ثابت شود. اکو کنار تخت تشخیص و راهنمای درناژ است."
    ),
    explanation_en=(
        "Breast cancer and mastectomy set the scene for malignant pericardial disease. "
        "Beck's triad plus electrical alternans is tamponade until proven otherwise. "
        "Bedside echo diagnoses and guides drainage."
    ),
    micro=pts(
        ["سه‌گانه بک: افت فشار، صدای خفه، jugular بالا.",
         "پولسوس پارادوکسوس کلاسیک است.",
         "alternans یعنی قلب در کیسه مایع تاب می‌خورد.",
         "اکو: کلاپس دیاستولیک اتاق راست.",
         "درناژ اگر ناپایدار فوری است.",
         "بدخیمی علت شایع تامپوناد بزرگ است.",
         "آنژیو وقت را برای پریکاردیوسنتز تلف می‌کند.",
         "آمبولی گالن و S1P2 می‌دهد نه alternans.",
         "ECG ولتاژ کم هم هست.",
         "CT وقتی پایدار و شک به توده باشد.",
         "بعد از درناژ پنجره پریکارد اگر عود بدخیم باشد."],
        ["Beck: low pressure, muffled sounds, high JVP.",
         "Pulsus paradoxus is classic.",
         "Alternans means the heart is swinging in fluid.",
         "Echo: diastolic collapse of the right chambers.",
         "Drain immediately if unstable.",
         "Malignancy is a common cause of a large tamponade.",
         "Angio wastes time that belongs to pericardiocentesis.",
         "PE gives gallop and loud P2, not alternans.",
         "Low ECG voltage is also there.",
         "CT when stable and you suspect a mass.",
         "A pericardial window if malignant fluid returns."],
    ),
    golden_fa="alternans + صدای خفه: اکو. آنژیو نه.",
    golden_en="Alternans plus muffled sounds: echo. Not angio.",
    refs=["Harrison 21 — Pericardial disease"],
    concept="tamponade-echo", concept_fa="اکو تامپوناد", concept_en="Tamponade echo")

add("داخلی", 34,
    chapter_fa="قلب / STEMI", chapter_en="Heart / STEMI",
    options_why_fa=[
        "پاسخ صحیح — فیبرینولیز شکست‌خورده در ۹۰ دقیقه یعنی PCI نجات (rescue).",
        "نصف دوز استرپتوکیناز هیچ پروتکلی نیست.",
        "تنکتپلاز بعد از استرپتوکیناز خونریزی مغزی می‌سازد (فیبرینولیز مضاعف).",
        "بی‌عملی اینفارکت را کامل می‌کند.",
    ],
    options_why_en=[
        "Correct — failed fibrinolysis at 90 minutes is rescue PCI.",
        "Half-dose streptokinase is not a protocol.",
        "Tenecteplase after streptokinase makes intracranial bleeding (double lytic).",
        "Doing nothing completes the infarct.",
    ],
    explanation_fa=(
        "تصحیح کلید دفترچه: گزینهٔ چاپی «فعلاً اقدامی لازم نیست» با راهنمای AHA/ESC "
        "مخالف است. شکست ترومبولیز یعنی درد و ST ماندگار بعد از ۶۰–۹۰ دقیقه؛ قدم بعد "
        "اعزام برای rescue PCI است نه دوز دوم لیتیک."
    ),
    explanation_en=(
        "Key correction: the printed 'no further action' contradicts AHA/ESC. Failed "
        "thrombolysis is ongoing pain and ST at 60–90 minutes; next is transfer for "
        "rescue PCI, not a second lytic."
    ),
    micro=pts(
        ["موفقیت لیتیک: کاهش بیش از ۵۰ درصد ST و قطع درد.",
         "استرپتوکیناز آنتی‌ژنیک است؛ تا ۶ ماه تکرار نکن.",
         "تنکتپلاز وزن‌محور و تک‌بولوس است — به‌عنوان داروی اول.",
         "فیبرینولیز مضاعف ممنوع است.",
         "زمان تماس تا بالون هدف زیر ۱۲۰ دقیقه است.",
         "اگر PCI اولیه در دسترس نباشد لیتیک سپس آنژیو.",
         "درمان ضدپلاکت و ضدانعقاد را همزمان بده.",
         "شوک کاردیوژنیک اندیکاسیون آنژیو فوری است.",
         "نیم‌دوز هیچ جایی در شکست لیتیک ندارد.",
         "کلید چاپی را با راهنما اصلاح کردیم.",
         "انتقال را معطل نوار سوم نکن."],
        ["Lytic success: more than 50% ST fall and pain gone.",
         "Streptokinase is antigenic; do not repeat within 6 months.",
         "Tenecteplase is weight-based and single-bolus — as the first drug.",
         "Double fibrinolysis is forbidden.",
         "Contact-to-balloon target is under 120 minutes.",
         "If primary PCI is not available, lytic then angio.",
         "Give antiplatelet and anticoagulant at the same time.",
         "Cardiogenic shock is immediate angio.",
         "Half dose has no place in failed lysis.",
         "We corrected the printed key against the guideline.",
         "Do not wait for a third tracing to transfer."],
    ),
    golden_fa="لیتیک شکست: rescue PCI. دوز دوم نده.",
    golden_en="Failed lytic: rescue PCI. Do not give a second dose.",
    refs=["Harrison 21 / AHA STEMI 2013–2025"],
    concept="rescue-pci", concept_fa="PCI نجات", concept_en="Rescue PCI",
    key_corrected=True, original_correct_index=3, correct_index=0,
    key_correction_fa="کلید چاپی «اقدامی لازم نیست» خلاف راهنمای STEMI است؛ شکست فیبرینولیز یعنی اعزام برای rescue PCI.",
    key_correction_en="The printed 'no further action' contradicts STEMI guidance; failed fibrinolysis means transfer for rescue PCI.",
    key_correction_source="AHA/ESC STEMI; Harrison 21")

add("داخلی", 35,
    chapter_fa="ریه / منحنی اکسیژن", chapter_en="Lung / oxygen curve",
    options_why_fa=[
        "اسیدوز منحنی را راست می‌برد (آزادسازی).",
        "تب منحنی را راست می‌برد.",
        "CO2 بالا منحنی را راست می‌برد (بور).",
        "پاسخ صحیح — افت 2,3-DPG تمایل Hb به O2 را بالا می‌برد (چپ).",
    ],
    options_why_en=[
        "Acidosis shifts the curve right (unloading).",
        "Fever shifts the curve right.",
        "High CO2 shifts the curve right (Bohr).",
        "Correct — low 2,3-DPG raises Hb affinity for O2 (left shift).",
    ],
    explanation_fa=(
        "شیفت چپ یعنی Hb اکسیژن را محکم نگه می‌دارد: آلکالوز، سرما، افت DPG، CO، مت‌هموگلوبین. "
        "ذخیره خونی کهنه DPG کم دارد."
    ),
    explanation_en=(
        "A left shift means Hb holds oxygen tightly: alkalosis, cold, low DPG, CO, methaemoglobin. "
        "Old banked blood is low in DPG."
    ),
    micro=pts(
        ["راست: اسید، تب، CO2، DPG بالا — بافت اکسیژن می‌گیرد.",
         "چپ: برعکس + CO و HbF.",
         "P50 طبیعی حدود ۲۷ میلی‌متر جیوه است.",
         "ارتفاع DPG را بالا می‌برد (شیفت راست جبرانی).",
         "هیپوفسفاتمی DPG را کم می‌کند.",
         "مسمومیت CO شیفت چپ شدید است.",
         "HbF تمایل بالا دارد تا جنین اکسیژن بگیرد.",
         "بور یعنی اثر CO2 و H+.",
         "سؤال «تمایل را بالا می‌برد» یعنی شیفت چپ.",
         "ونتیلاتور هیپرونتیله شیفت چپ می‌سازد.",
         "ترانسفیوژن زیاد گلبول کهنه اکسیژن‌رسانی را ضعیف می‌کند."],
        ["Right: acid, fever, CO2, high DPG — tissues get oxygen.",
         "Left: the opposite plus CO and HbF.",
         "Normal P50 is about 27 mmHg.",
         "Altitude raises DPG (compensatory right shift).",
         "Hypophosphataemia lowers DPG.",
         "CO poisoning is a severe left shift.",
         "HbF has high affinity so the fetus can take oxygen.",
         "Bohr is the CO2 and H+ effect.",
         "'Increases affinity' means a left shift.",
         "A hyperventilated ventilator makes a left shift.",
         "Lots of old red cells weaken oxygen delivery."],
    ),
    golden_fa="تمایل بالا = شیفت چپ = افت 2,3-DPG.",
    golden_en="High affinity is a left shift is low 2,3-DPG.",
    refs=["Harrison 21 — Gas transport"],
    concept="dpg-left-shift", concept_fa="DPG و شیفت چپ", concept_en="DPG left shift")

add("داخلی", 36,
    chapter_fa="ریه / پلور", chapter_en="Lung / pleura",
    options_why_fa=[
        "امپیم گلوکز را خیلی پایین می‌آورد.",
        "پاسخ صحیح — آمبولی معمولاً گلوکز پلور را پایین نمی‌آورد.",
        "سل پلور گلوکز را کم می‌کند.",
        "پلوریت لوپوس گلوکز را کم می‌کند.",
    ],
    options_why_en=[
        "Empyema drops pleural glucose a lot.",
        "Correct — PE usually does not lower pleural glucose.",
        "TB pleurisy lowers glucose.",
        "Lupus pleuritis lowers glucose.",
    ],
    explanation_fa=(
        "گلوکز پلور زیر ۶۰ در امپیم، روماتوئید، سل، لوپوس و بدخیمی دیده می‌شود. "
        "افیوژن آمبولی اگزودای نوتروفیلی با گلوکز نزدیک سرم است."
    ),
    explanation_en=(
        "Pleural glucose under 60 is seen in empyema, rheumatoid, TB, lupus and malignancy. "
        "A PE effusion is a neutrophil exudate with glucose near serum."
    ),
    micro=pts(
        ["لایت: پروتئین پلور/سرم بالای ۰٫۵ یا LDH بالای ۰٫۶ اگزودا است.",
         "pH زیر ۷٫۲ در امپیم یعنی لوله سینه.",
         "آدنوزین دآمیناز بالا به نفع سل است.",
         "لوپوس: ANA و LE cell در مایع.",
         "روماتوئید گلوکز را نزدیک صفر می‌کند.",
         "آمبولی: درد پلورتیک و D-dimer و CTPA.",
         "سؤال «کمتر مطرح» یعنی گلوکز ۵۰ با آمبولی نمی‌خواند.",
         "سیتولوژی بدخیمی را بگیر اگر سن بالا است.",
         "کشت و گرم در هر امپیم مشکوک.",
         "سونوگرافی محل پونکسیون را امن می‌کند.",
         "تری‌گلیسیرید بالا یعنی شیلوتوراکس."],
        ["Light: pleural/serum protein above 0.5 or LDH above 0.6 is an exudate.",
         "pH under 7.2 in empyema means a chest tube.",
         "High ADA favours TB.",
         "Lupus: ANA and LE cells in the fluid.",
         "Rheumatoid drives glucose near zero.",
         "PE: pleuritic pain, D-dimer and CTPA.",
         "'Less probable' means glucose 50 does not fit PE.",
         "Get cytology if the patient is older.",
         "Gram and culture in every suspected empyema.",
         "Ultrasound makes the tap safer.",
         "High triglycerides mean chylothorax."],
    ),
    golden_fa="گلوکز پلور پایین: امپیم و سل و لوپوس. آمبولی نه.",
    golden_en="Low pleural glucose: empyema, TB, lupus. Not PE.",
    refs=["Harrison 21 — Pleural disease"],
    concept="pleural-glucose-pe", concept_fa="گلوکز پلور و آمبولی", concept_en="Pleural glucose PE")

add("داخلی", 37,
    chapter_fa="ریه / هموپتزی", chapter_en="Lung / hemoptysis",
    options_why_fa=[
        "پاسخ صحیح — ABG در هموپتزی کم‌حجم پایدار قدم اول نیست.",
        "عکس قفسه سینه اولین تصویر است.",
        "کراتینین واسکولیت و سندرم ریه-کلیه را غربال می‌کند.",
        "آنالیز ادرار همان سندرم را می‌جوید.",
    ],
    options_why_en=[
        "Correct — ABG is not first-line in small-volume stable hemoptysis.",
        "A chest film is the first image.",
        "Creatinine screens vasculitis and pulmonary-renal syndrome.",
        "Urinalysis hunts the same syndrome.",
    ],
    explanation_fa=(
        "هموپتزی خفیف اول: عکس سینه، CBC، انعقاد، Cr، ادرار. گاز خون وقتی دیسترس "
        "یا هیپوکسی بالینی است. برونکوسکوپی اگر تصویر منفی و خون ادامه یابد."
    ),
    explanation_en=(
        "Mild hemoptysis first: chest film, CBC, coagulation, Cr, urine. Blood gas when "
        "there is distress or clinical hypoxia. Bronchoscopy if imaging is negative and bleeding continues."
    ),
    micro=pts(
        ["شایع‌ترین علت در بزرگسال برونشیت و برونشکتازی و سل است.",
         "هموپتزی وسیع از راه هوایی تهدید می‌کند نه کم‌خونی.",
         "بیمار را روی سمت خون‌ریزیان بخوابان.",
         "Goodpasture و GPA ادرار فعال دارند.",
         "سیتی آنژیو محل را بهتر از عکس می‌بیند اگر پایدار نیست.",
         "ABG مدیریت تهویه است نه تشخیص علت خون.",
         "سابقه خانوادگی منفی سرطان را رد نمی‌کند ولی قدم را عوض نمی‌کند.",
         "سیگار برونشیت مزمن می‌سازد.",
         "INR را اگر وارفارین می‌خورد بگیر.",
         "سؤال بجز یعنی سه تست اول لازم‌اند.",
         "اکسی‌متری ساده جای ABG را در پایدار می‌گیرد."],
        ["Common adult causes are bronchitis, bronchiectasis and TB.",
         "Massive hemoptysis threatens the airway, not the haemoglobin.",
         "Lie the patient on the bleeding side.",
         "Goodpasture and GPA have an active urine.",
         "CT angio sees the site better than a film if unstable.",
         "ABG manages ventilation; it does not find the bleed.",
         "A negative family history does not exclude cancer but does not change the first step.",
         "Smoking makes chronic bronchitis.",
         "Check INR if on warfarin.",
         "An except stem means three first tests are needed.",
         "Simple oximetry replaces ABG in the stable."],
    ),
    golden_fa="هموپتزی کم پایدار: عکس و ادرار و Cr. ABG نه.",
    golden_en="Small stable hemoptysis: film, urine and Cr. Not ABG.",
    refs=["Harrison 21 — Hemoptysis"],
    concept="hemoptysis-not-abg", concept_fa="هموپتزی نه ABG", concept_en="Hemoptysis not ABG")

add("داخلی", 38,
    chapter_fa="ریه / GOLD", chapter_en="Lung / GOLD",
    options_why_fa=[
        "A یعنی علامت کم و خطر کم؛ یک بستری خطر را بالا می‌برد.",
        "B علامت زیاد و خطر کم است؛ این بیمار فقط سربالایی نفس کم می‌آورد (mMRC ۱).",
        "پاسخ صحیح — یک بستری = خطر بالا و علامت کم = گروه C در GOLD ABCD همان دوره.",
        "D هم علامت زیاد هم خطر بالا می‌خواهد.",
    ],
    options_why_en=[
        "A is low symptom and low risk; one admission raises risk.",
        "B is high symptom and low risk; this man is only breathless on hills (mMRC 1).",
        "Correct — one admission is high risk and low symptom is group C in that era's GOLD ABCD.",
        "D wants both high symptom and high risk.",
    ],
    explanation_fa=(
        "دفترچه خرداد ۱۴۰۲ هنوز GOLD گروه‌بندی ABCD را می‌خواهد (نه ABE سال ۲۰۲۳). "
        "mMRC ۱ = علامت کم. یک بستری به‌خاطر تشدید = خطر بالا → C."
    ),
    explanation_en=(
        "The Khordad 1402 booklet still wants GOLD ABCD (not 2023 ABE). "
        "mMRC 1 is low symptom. One exacerbation admission is high risk → C."
    ),
    micro=pts(
        ["mMRC ۰–۱ علامت کم؛ ۲ یا بیشتر علامت زیاد.",
         "CAT زیر ۱۰ هم علامت کم است.",
         "خطر بالا: ۲ تشدید سرپایی یا ۱ بستری.",
         "GOLD ۲۰۲۳ گروه E همه تشدیدی‌هاست.",
         "درمان C: LAMA خط اول.",
         "A: برونکودیلاتور کوتاه‌اثر کافی است.",
         "B: LABA+LAMA.",
         "استروئید استنشاقی اگر ائوزینوفیل بالا یا تشدید مکرر.",
         "ترک سیگار از هر دارو مهم‌تر است.",
         "اکسیژن اگر PaO2 پایدار زیر ۵۵ باشد.",
         "برای آزمون ۱۴۰۲ همان ABCD را حفظ کن."],
        ["mMRC 0–1 is low symptom; 2 or more is high.",
         "CAT under 10 is also low symptom.",
         "High risk: two outpatient exacerbations or one admission.",
         "GOLD 2023 group E is all exacerbators.",
         "Treat C with a LAMA first.",
         "A: a short-acting bronchodilator is enough.",
         "B: LABA plus LAMA.",
         "Inhaled steroid if eosinophils are high or exacerbations repeat.",
         "Stopping smoke beats any drug.",
         "Oxygen if stable PaO2 is under 55.",
         "For the 1402 exam keep ABCD."],
    ),
    golden_fa="بستری یک‌بار + mMRC ۱ = GOLD C.",
    golden_en="One admission plus mMRC 1 is GOLD C.",
    refs=["Harrison 21 / GOLD 2017–2022 ABCD"],
    concept="gold-c", concept_fa="GOLD گروه C", concept_en="GOLD group C")

add("داخلی", 39,
    chapter_fa="ریه / آسم بارداری", chapter_en="Lung / asthma pregnancy",
    options_why_fa=[
        "بودزوناید ICS انتخابی بارداری است.",
        "پاسخ صحیح — اومالیزوماب دادهٔ ایمنی کافی در بارداری ندارد و در آزمون منع محسوب می‌شود.",
        "آلبوترول SABA نجات است و مجاز است.",
        "مونته‌لوکاست در صورت نیاز ادامه می‌یابد.",
    ],
    options_why_en=[
        "Budesonide is the preferred ICS in pregnancy.",
        "Correct — omalizumab lacks enough pregnancy safety data and is treated as contraindicated in this exam.",
        "Albuterol is the rescue SABA and is allowed.",
        "Montelukast may continue if needed.",
    ],
    explanation_fa=(
        "آسم کنترل‌نشده برای جنین از دارو خطرناک‌تر است. ICS و SABA و مونته‌لوکاست "
        "ادامه می‌یابند. آنتی‌IgE در دفترچه منع مطلق نوشته شده؛ همان را نگه می‌داریم."
    ),
    explanation_en=(
        "Uncontrolled asthma is more dangerous to the fetus than the drugs. ICS, SABA and "
        "montelukast continue. Anti-IgE is printed as contraindicated in the booklet; we keep that key."
    ),
    micro=pts(
        ["یک‌سوم آسم بارداری بدتر می‌شود.",
         "بودزوناید بیشترین داده را دارد.",
         "از سیستمیک در حمله کوتاه نترس.",
         "تئوفیلین دیگر خط اول نیست.",
         "GINA امروز بیولوژیک را در موارد شدید ادامه می‌دهد؛ آزمون ۱۴۰۲ اومالیزوماب را منع می‌داند.",
         "هیپوکسی مادر هیپوکسی جنین است.",
         "پیک فلوی خانگی را ادامه بده.",
         "آلرژن و دود را حذف کن.",
         "سزارین فقط برای اندیکاسیون مامایی.",
         "پروستاگلاندین F2α برونکواسپاسم می‌دهد.",
         "کلید رسمی را عوض نکردیم."],
        ["A third of pregnancy asthma gets worse.",
         "Budesonide has the most data.",
         "Do not fear a short systemic course in an attack.",
         "Theophylline is no longer first-line.",
         "Today's GINA continues biologics in severe disease; the 1402 exam treats omalizumab as contraindicated.",
         "Maternal hypoxia is fetal hypoxia.",
         "Keep home peak flow.",
         "Remove allergen and smoke.",
         "Caesarean only for obstetric reasons.",
         "Prostaglandin F2α causes bronchospasm.",
         "We did not change the official key."],
    ),
    golden_fa="آسم بارداری: بودزوناید و سالبوتامول بله. اومالیزوماب در این آزمون نه.",
    golden_en="Pregnant asthma: budesonide and albuterol yes. Omalizumab no on this paper.",
    refs=["Harrison 21 — Asthma; NAEPP pregnancy"],
    concept="omalizumab-pregnancy", concept_fa="اومالیزوماب بارداری", concept_en="Omalizumab pregnancy")

add("داخلی", 40,
    chapter_fa="خون / پیشگیری VTE", chapter_en="Heme / VTE prophylaxis",
    options_why_fa=[
        "آسپرین برای پیشگیری بستری سرطان کافی نیست.",
        "هپارین UFH درست است ولی LMWH در سرطان ترجیح دارد.",
        "پاسخ صحیح — انوکساپارین استاندارد پیشگیری در سرطان بستری است.",
        "وارفارین شروع آهسته و تداخل زیاد دارد؛ پروفیلاکسی حاد نیست.",
    ],
    options_why_en=[
        "The official English options are misaligned with the Persian (aspirin leaked into the stem). Learn from the Persian key: LMWH.",
        "UFH works but LMWH is preferred in cancer.",
        "Warfarin is not acute prophylaxis.",
        "Surgery is not a drug and is not the printed English match for the Persian enoxaparin key.",
    ],
    explanation_fa=(
        "سرطان فعال + بستری + بی‌حرکتی = خطر بالای VTE. راهنما LMWH (انوکساپارین) "
        "را برای پروفیلاکسی ترجیح می‌دهد. دفترچه انگلیسی گزینه‌ها را جابه‌جا چاپ کرده؛ متن را دست نمی‌زنیم."
    ),
    explanation_en=(
        "Active cancer plus bed rest is high VTE risk. Guidelines prefer LMWH (enoxaparin) "
        "for prophylaxis. The English booklet jumbles the options; we keep them verbatim."
    ),
    micro=pts(
        ["پادوا و IMPROVE خطر بستری را می‌سنجند.",
         "در سرطان LMWH از وارفارین بهتر مطالعه شده.",
         "DOAC در برخی سرطان‌های معده خونریزی بیشتر دارد.",
         "آسپرین مال ارتوپدی انتخابی است نه سرطان بستری.",
         "کلیرانس کلیه دوز انوکساپارین را کم می‌کند.",
         "اگر CrCl خیلی پایین باشد UFH بهتر است.",
         "کنتراندیکاسیون: خونریزی فعال و پلاکت خیلی پایین.",
         "جوراب فشاری اگر دارو ممنوع باشد.",
         "مدت: تا زمانی که بستری و بی‌حرکت است.",
         "گزینه انگلیسی را حفظ کن؛ پاسخ فارسی انوکساپارین است.",
         "آلزایمر به‌تنهایی ضد انعقاد نیست."],
        ["Padua and IMPROVE score hospital risk.",
         "In cancer LMWH is better studied than warfarin.",
         "DOACs bleed more in some GI cancers.",
         "Aspirin is for selected orthopaedics, not inpatient cancer.",
         "Kidney clearance lowers the enoxaparin dose.",
         "If CrCl is very low, UFH is safer.",
         "Contraindication: active bleed and very low platelets.",
         "Compression if drugs are forbidden.",
         "Duration: while admitted and immobile.",
         "Keep the English options; the Persian answer is enoxaparin.",
         "Alzheimer alone is not an anticoagulant."],
    ),
    golden_fa="سرطان بستری: انوکساپارین. آسپرین نه.",
    golden_en="Inpatient cancer: enoxaparin. Not aspirin.",
    refs=["Harrison 21 — VTE; ASCO prophylaxis"],
    concept="cancer-lmwh-ppx", concept_fa="انوکساپارین سرطان", concept_en="Cancer LMWH ppx")

add("داخلی", 41,
    chapter_fa="تغذیه / مارکر", chapter_en="Nutrition / markers",
    options_why_fa=[
        "پاسخ صحیح — آلبومین نیمه‌عمر حدود ۲۰ روز دارد و وضعیت درازمدت را نشان می‌دهد.",
        "پره‌آلبومین نیمه‌عمر ۲ روز دارد؛ حاد است.",
        "CRP التهاب است نه ذخیره پروتئین.",
        "ترانسفورین متوسط است و از آهن اثر می‌گیرد.",
    ],
    options_why_en=[
        "Correct — albumin's half-life is about 20 days and reflects long-term status.",
        "Prealbumin's half-life is 2 days; it is acute.",
        "CRP is inflammation, not a protein store.",
        "Transferrin is intermediate and is moved by iron.",
    ],
    explanation_fa=(
        "آلبومین برای روند هفته‌ها مفید است ولی در التهاب حاد پایین می‌آید و اختصاصی نیست. "
        "پره‌آلبومین پاسخ کوتاه به تغذیه را می‌سنجد."
    ),
    explanation_en=(
        "Albumin is useful over weeks but falls in acute inflammation and is not specific. "
        "Prealbumin tracks a short feeding response."
    ),
    micro=pts(
        ["نیمه‌عمر آلبومین ≈ ۲۰ روز.",
         "پره‌آلبومین = ترانس‌تیرتین ≈ ۲ روز.",
         "هر دو negative acute-phase هستند.",
         "CRP تفسیر هر دو را خراب می‌کند.",
         "ترانسفرین آهن و التهاب را قاطی می‌کند.",
         "بهترین ارزیابی تغذیه شرح حال و وزن و معاینه است.",
         "NRS-2002 غربال بیمار بستری است.",
         "آلبومین پیش‌آگهی مرگ را بهتر از تغذیه خالص می‌گوید.",
         "اِدم آلبومین را رقیق می‌کند.",
         "سؤال «درازمدت» یعنی آلبومین.",
         "برای پیگیری روزانه تغذیه پره‌آلبومین بهتر است."],
        ["Albumin half-life is about 20 days.",
         "Prealbumin is transthyretin, about 2 days.",
         "Both are negative acute-phase proteins.",
         "CRP ruins the reading of both.",
         "Transferrin mixes iron and inflammation.",
         "The best nutrition assessment is history, weight and exam.",
         "NRS-2002 screens inpatients.",
         "Albumin predicts death better than it measures pure nutrition.",
         "Oedema dilutes albumin.",
         "'Long-term' means albumin.",
         "For day-to-day feeding follow-up, prealbumin is better."],
    ),
    golden_fa="تغذیه درازمدت: آلبومین. حاد: پره‌آلبومین.",
    golden_en="Long-term nutrition: albumin. Acute: prealbumin.",
    refs=["Harrison 21 — Malnutrition"],
    concept="albumin-long-term", concept_fa="آلبومین درازمدت", concept_en="Long-term albumin")

add("داخلی", 42,
    chapter_fa="شوک / SVR", chapter_en="Shock / SVR",
    options_why_fa=[
        "هیپوولمیک SVR را جبرانی بالا می‌برد.",
        "کاردیوژنیک هم SVR بالاست.",
        "پاسخ صحیح — شوک سپتیکdistributive است و SVR پایین است.",
        "تامپوناد انسدادی است و SVR بالا می‌ماند.",
    ],
    options_why_en=[
        "Hypovolemic shock raises SVR in compensation.",
        "Cardiogenic shock also has a high SVR.",
        "Correct — septic shock is distributive and SVR is low.",
        "Tamponade is obstructive and SVR stays high.",
    ],
    explanation_fa=(
        "فقط شوک توزیعی (سپسیس، آنافیلاکسی، نوروژنیک) مقاومت سیستمیک را کم می‌کند. "
        "بقیه با انقباض عروق جبران می‌کنند."
    ),
    explanation_en=(
        "Only distributive shock (sepsis, anaphylaxis, neurogenic) drops SVR. "
        "The others compensate with vasoconstriction."
    ),
    micro=pts(
        ["سپسیس: CO اغلب بالاست و پوست گرم است.",
         "هیپوولمیک: CO پایین و پوست سرد.",
         "کاردیوژنیک: ریه خیس و CVP بالا.",
         "تامپوناد: pulsus و jugular و صدای خفه.",
         "نوروژنیک برادی و پوست خشک است.",
         "لاکتات را در هر شوک بگیر.",
         "سوروایوینگ سپسیس: مایع و آنتی‌بیوتیک ساعت اول.",
         "نوراپی‌نفرین وازوپرسور اول سپسیس است.",
         "SVR را از (MAP-CVP)/CO حساب می‌کنند.",
         "سؤال فقط سپسیس SVR را کم می‌کند.",
         "شوک اسپاینال را با حجم تنها درمان نکن."],
        ["Sepsis: CO is often high and the skin is warm.",
         "Hypovolemia: low CO and cold skin.",
         "Cardiogenic: wet lungs and high CVP.",
         "Tamponade: pulsus, JVP and muffled sounds.",
         "Neurogenic is bradycardic with dry skin.",
         "Lactate in every shock.",
         "Surviving Sepsis: fluid and antibiotics in the first hour.",
         "Noradrenaline is the first septic pressor.",
         "SVR is (MAP-CVP)/CO.",
         "Only sepsis among these options drops SVR.",
         "Do not treat spinal shock with volume alone."],
    ),
    golden_fa="SVR پایین = شوک سپتیک (توزیعی).",
    golden_en="Low SVR is septic (distributive) shock.",
    refs=["Harrison 21 — Shock"],
    concept="septic-low-svr", concept_fa="SVR سپسیس", concept_en="Septic SVR")

# ---------- Pediatrics 71–80 ----------
add("کودکان", 71,
    chapter_fa="روماتولوژی / ARF", chapter_en="Rheum / ARF",
    options_why_fa=[
        "JIA تب و مهاجرت ۳روزه این‌گونه ندارد.",
        "SLE در ۶سالگی با این الگوی مهاجرت نادر است.",
        "کاواساکی مخاط و دست و کرونر می‌خواهد نه آرتریت مهاجر تنها.",
        "پاسخ صحیح — آرتریت مهاجر + تب بالا + ESR = تب روماتیسمی (جونز).",
    ],
    options_why_en=[
        "JIA does not migrate like this over three days.",
        "SLE at 6 with this migratory pattern is rare.",
        "Kawasaki wants mucosa, hands and coronaries, not lone migratory arthritis.",
        "Correct — migratory arthritis plus high fever plus ESR is rheumatic fever (Jones).",
    ],
    explanation_fa=(
        "آرتریت روماتیسمی بزرگ، مهاجر، بسیار دردناک و به NSAID سریع جواب می‌دهد. "
        "برای جونز کامل یک معیار بزرگ دیگر یا شواهد استرپ لازم است ولی در آزمون این تصویر ARF است."
    ),
    explanation_en=(
        "Rheumatic arthritis is large, migratory, very painful and answers NSAIDs fast. "
        "Full Jones needs another major or strep evidence, but in the exam this picture is ARF."
    ),
    micro=pts(
        ["جونز بزرگ: کاردیت، آرتریت، کوره‌آ، اریتم مارژیناتوم، ندول.",
         "شواهد استرپ: ASO یا کشت.",
         "آرتریت JIA پایدار و کمتر مهاجر است.",
         "کاواساکی حداقل ۵ روز تب و معیار پوستی.",
         "پروفیلاکسی پنی‌سیلین بعد از ARF واجب است.",
         "کاردیت را با اکو بجوی.",
         "آسپرین یا ناپروکسن برای آرتریت.",
         "کوره‌آ دیر می‌آید و خودمحدود است.",
         "ASO ممکن است در کوره‌آ پایین باشد.",
         "سؤال تشخیص است نه درمان.",
         "مهاجرت روزبه‌روز کلید است."],
        ["Jones majors: carditis, arthritis, chorea, erythema marginatum, nodules.",
         "Strep evidence: ASO or a culture.",
         "JIA arthritis stays and migrates less.",
         "Kawasaki needs 5 days of fever and skin criteria.",
         "Penicillin prophylaxis after ARF is mandatory.",
         "Hunt carditis with echo.",
         "Aspirin or naproxen for the arthritis.",
         "Chorea comes late and is self-limited.",
         "ASO may be low in chorea.",
         "The question is diagnosis, not treatment.",
         "Day-to-day migration is the key."],
    ),
    golden_fa="آرتریت مهاجر تب‌دار کودک: تب روماتیسمی.",
    golden_en="Feverish migratory arthritis in a child is rheumatic fever.",
    refs=["Nelson — Acute rheumatic fever"],
    concept="arf-migratory", concept_fa="آرتریت مهاجر ARF", concept_en="ARF migratory")

add("کودکان", 72,
    chapter_fa="غدد / DKA", chapter_en="Endo / DKA",
    options_why_fa=[
        "ادم ریه با مایع زیاد است نه با بیکربنات تنها.",
        "پاسخ صحیح — بیکربنات در DKA خطر ادم مغز را بالا می‌برد.",
        "کلسیم با بیکربنات پایین می‌آید نه بالا.",
        "پتاسیم با انسولین و بیکربنات می‌افتد نه بالا می‌رود.",
    ],
    options_why_en=[
        "Pulmonary oedema is from too much fluid, not bicarbonate alone.",
        "Correct — bicarbonate in DKA raises the risk of cerebral oedema.",
        "Calcium falls with bicarbonate, it does not rise.",
        "Potassium falls with insulin and bicarbonate, it does not rise.",
    ],
    explanation_fa=(
        "کودک DKA (قند ۴۵۰، pH ۷٫۱۵، HCO3 ۷). بیکربنات فقط در pH خیلی پایین و شوک "
        "بحث می‌شود. عارضه ترسناک ادم مغز است؛ بیکربنات PaCO2 و اسمول را جابه‌جا می‌کند."
    ),
    explanation_en=(
        "A child in DKA (glucose 450, pH 7.15, HCO3 7). Bicarbonate is only debated at "
        "extreme pH and shock. The feared complication is cerebral oedema; bicarbonate jerks PaCO2 and osmolality."
    ),
    micro=pts(
        ["ادم مغز: سردرد، افت هوشیاری، برادی بعد از شروع درمان.",
         "درمان ادم: مانیتول یا سالین ۳٪ و بالا نگه داشتن سر.",
         "مایع را حساب‌شده بده؛ بولوس تکراری خطر است.",
         "انسولین را یک ساعت بعد از مایع شروع کن.",
         "پتاسیم را قبل از انسولین اگر پایین است جبران کن.",
         "بیکربنات روتین ممنوع است.",
         "قند را بالای ۲۰۰ نگه دار با دکستروز.",
         "سن پایین و pH خیلی پایین خطر ادم را بیشتر می‌کند.",
         "اینجا پزشک مقیم بیکربنات داده؛ عارضه محتمل ادم مغز است.",
         "هیپرکالمی کاذب اسیدوز است؛ با درمان می‌افتد.",
         "هیپوکلسمی تتانی بیکربنات است نه هیپرکلسمی."],
        ["Cerebral oedema: headache, falling consciousness, bradycardia after treatment starts.",
         "Treat oedema with mannitol or 3% saline and a raised head.",
         "Give fluid by the book; repeat boluses are dangerous.",
         "Start insulin an hour after fluid.",
         "Replace potassium before insulin if it is low.",
         "Routine bicarbonate is forbidden.",
         "Keep glucose above 200 with dextrose.",
         "Young age and very low pH raise oedema risk.",
         "Here the resident gave bicarbonate; the likely complication is cerebral oedema.",
         "Hyperkalaemia is artefact of acidosis; it falls with treatment.",
         "Bicarbonate tetany is hypocalcaemia, not hypercalcaemia."],
    ),
    golden_fa="بیکربنات در DKA کودک: ادم مغز.",
    golden_en="Bicarbonate in childhood DKA means cerebral oedema.",
    refs=["Nelson / ISPAD — DKA"],
    concept="dka-bicarb-edema", concept_fa="بیکربنات و ادم مغز", concept_en="DKA bicarb oedema")

add("کودکان", 73,
    chapter_fa="ریه / ARDS", chapter_en="Lung / ARDS",
    options_why_fa=[
        "برونشیولیت معمولاً شیرخوار است و CO2 این‌قدر با هیپوکسی شدید کمتر است.",
        "سیاه‌سرفه لنفوسیت خیلی بالا و آپنه می‌خواهد.",
        "پاسخ صحیح — هیپوکسی شدید، ارتشاح دوطرفه، قلب طبیعی، تروپونین نرمال = ARDS.",
        "میوکاردیت تروپونین و قلب بزرگ می‌خواهد.",
    ],
    options_why_en=[
        "Bronchiolitis is usually an infant and CO2 is less extreme with this hypoxia.",
        "Pertussis wants very high lymphocytes and apnoea.",
        "Correct — severe hypoxia, bilateral infiltrates, normal heart, normal troponin is ARDS.",
        "Myocarditis wants troponin and a big heart.",
    ],
    explanation_fa=(
        "کودک قبلاً سالم با تب و سیانوز، PaO2 ۴۰، ارتشاح دوطرفه، اندازه قلب و تروپونین طبیعی. "
        "تعریف برلین ARDS است (پنومونی جرقه زده)."
    ),
    explanation_en=(
        "A previously well child with fever and cyanosis, PaO2 40, bilateral infiltrates, "
        "normal heart size and troponin. That is Berlin ARDS (pneumonia is the spark)."
    ),
    micro=pts(
        ["برلین: شروع ظرف یک هفته، دوطرفه، نه فقط نارسایی قلب.",
         "شدت با P/F تعیین می‌شود.",
         "درمان: تهویه محافظ ریه و PEEP.",
         "مایع را محدود کن.",
         "آنتی‌بیوتیک اگر عفونت باشد.",
         "میوکاردیت گالوپ و آنزیم بالا دارد.",
         "برونشیولیت ویزینگ و فصل RSV است.",
         "سیاه‌سرفه حمله سرفه و whoop.",
         "PaCO2 ۵۵ یعنی خستگی تنفسی؛ لوله لازم است.",
         "سورفاکتانت در کودک نقش محدود دارد.",
         "اکمو اگر هیپوکسی مقاوم باشد."],
        ["Berlin: onset within a week, bilateral, not just heart failure.",
         "Severity is the P/F ratio.",
         "Treat with lung-protective ventilation and PEEP.",
         "Restrict fluid.",
         "Antibiotics if infection is there.",
         "Myocarditis has a gallop and high enzymes.",
         "Bronchiolitis is wheeze and RSV season.",
         "Pertussis is paroxysms and a whoop.",
         "PaCO2 55 means respiratory fatigue; intubate.",
         "Surfactant has a limited role in children.",
         "ECMO if hypoxia is refractory."],
    ),
    golden_fa="ارتشاح دوطرفه + قلب نرمال + هیپوکسی = ARDS.",
    golden_en="Bilateral infiltrates plus a normal heart plus hypoxia is ARDS.",
    refs=["Nelson — ARDS"],
    concept="peds-ards", concept_fa="ARDS کودکان", concept_en="Pediatric ARDS")

add("کودکان", 74,
    chapter_fa="ایمنی‌سازی / OPV", chapter_en="Immunization / OPV",
    options_why_fa=[
        "استفراغ زود یعنی دوز بلعیده نشده؛ باید تکرار شود.",
        "پاسخ صحیح — اگر تا کمتر از حدود ۳۰ دقیقه استفراغ کرد، OPV را دوباره بده.",
         "عوض کردن به IPV برای استفراغ ساده لازم نیست.",
         "هر دو واکسن با هم برای این سناریو indikaسیون ندارد.",
    ],
    options_why_en=[
        "Early vomiting means the dose was not swallowed; it must be repeated.",
        "Correct — if the infant vomits within about 30 minutes, give OPV again.",
        "Switching to IPV is not needed for simple vomiting.",
        "Giving both vaccines is not indicated for this scene.",
    ],
    explanation_fa=(
        "دستور برنامه ایمن‌سازی: اگر نوزاد بلافاصله یا تا نیم ساعت بعد از قطره فلج استفراغ کرد، "
        "همان دوز تکرار می‌شود. IPV جایگزین استفراغ نیست."
    ),
    explanation_en=(
        "Immunisation programmes: if the newborn vomits immediately or within about 30 minutes "
        "of OPV, repeat that dose. IPV does not replace a vomited drop."
    ),
    micro=pts(
        ["OPV زنده خوراکی است و ایمنی مخاطی می‌سازد.",
         "IPV کشته تزریقی است.",
         "ایران هنوز OPV بدو تولد می‌دهد.",
         "VAPP عارضه نادر OPV است.",
         "اگر اسهال شدید باشد بعضی برنامه‌ها دوز را نمی‌شمارند.",
         "۲۰ دقیقه کاملاً داخل پنجره تکرار است.",
         "حال عمومی خوب یعنی علت جراحی نیست.",
         "شیر خوردن مانع OPV نیست.",
         "تکرار دوز اضافی ضرر ایمنی ندارد.",
         "ثبت دوز تکرار در کارت واکسن.",
         "IPV در نقص ایمنی به‌جای OPV است نه استفراغ."],
        ["OPV is live oral and builds mucosal immunity.",
         "IPV is killed and injected.",
         "Iran still gives birth-dose OPV.",
         "VAPP is a rare OPV complication.",
         "Some programmes do not count a dose given in severe diarrhoea.",
         "20 minutes is well inside the repeat window.",
         "Looking well means this is not a surgical cause.",
         "Breastfeeding does not block OPV.",
         "An extra repeat dose does not harm immunity.",
         "Write the repeat on the vaccine card.",
         "IPV replaces OPV in immunodeficiency, not in vomiting."],
    ),
    golden_fa="استفراغ زیر ۳۰ دقیقه بعد از OPV: همان قطره را تکرار کن.",
    golden_en="Vomiting within 30 minutes of OPV: repeat the same drop.",
    refs=["Nelson / EPI — OPV"],
    concept="opv-vomit-repeat", concept_fa="تکرار OPV", concept_en="Repeat OPV")

add("کودکان", 75,
    chapter_fa="جراحی نوزاد / انسداد", chapter_en="Neonatal surgery / obstruction",
    options_why_fa=[
        "ایلئوس مکونیوم لوپ‌های متسع زیاد می‌دهد.",
        "مالروتاسیون با ولولوس انسداد دیستال می‌سازد.",
        "آترزی ژژنوم لوپ‌های متعدد می‌دهد.",
        "پاسخ صحیح — آترزی دئودنوم double bubble است نه لوپ‌های پرشمار.",
    ],
    options_why_en=[
        "Meconium ileus gives many dilated loops.",
        "Malrotation with volvulus can obstruct distally.",
        "Jejunal atresia gives multiple loops.",
        "Correct — duodenal atresia is a double bubble, not countless loops.",
    ],
    explanation_fa=(
        "استفراغ صفراوی + عدم دفع مکونیوم + لوپ‌های متعدد یعنی انسداد پایین‌تر از دئودنوم. "
        "آترزی دئودنوم فقط دو حباب هوا دارد."
    ),
    explanation_en=(
        "Bilious vomiting plus no meconium plus many loops means obstruction below the duodenum. "
        "Duodenal atresia has only two air bubbles."
    ),
    micro=pts(
        ["هر استفراغ صفراوی نوزاد اورژانس است.",
         "عکس ایستاده شکم اولین تصویر است.",
         "upper GI series برای مالروتاسیون.",
         "ایلئوس مکونیوم = CF تا خلافش ثابت شود.",
         "آترزی ایلئوم لوپ‌های زیاد و سطوح مایع.",
         "double bubble + گاز دیستال = استنوز نه آترزی کامل.",
         "داون با آترزی دئودنوم همراه است.",
         "NGT و مایع و جراحی.",
         "سؤال بجز یعنی دئودنوم این عکس را نمی‌سازد.",
         "ولولوس میدگات تهدید روده است.",
         "تنقیه حاجب گاهی ایلئوس مکونیوم را باز می‌کند."],
        ["Any bilious vomit in a newborn is an emergency.",
         "A plain abdominal film is the first image.",
         "An upper GI series for malrotation.",
         "Meconium ileus is CF until proven otherwise.",
         "Ileal atresia is many loops and fluid levels.",
         "Double bubble plus distal gas is stenosis, not complete atresia.",
         "Down syndrome travels with duodenal atresia.",
         "NGT, fluid and surgery.",
         "An except stem means the duodenum does not make this film.",
         "Midgut volvulus threatens the bowel.",
         "A contrast enema sometimes opens meconium ileus."],
    ),
    golden_fa="لوپ‌های زیاد: دئودنوم نیست. Double bubble مال دئودنوم است.",
    golden_en="Many loops are not duodenum. Double bubble is duodenum.",
    refs=["Nelson — Intestinal obstruction"],
    concept="not-duodenal-atresia", concept_fa="نه آترزی دئودنوم", concept_en="Not duodenal atresia")

add("کودکان", 76,
    chapter_fa="ایمنی / SCID", chapter_en="Immunity / SCID",
    options_why_fa=[
        "پاسخ صحیح — عفونت از ۲ماهگی، برفک، بدون لوزه، شکست رشد = SCID (T و B).",
        "XLA بعد از ۶ماه است و برفک ویروسی/قارچی نمی‌دهد.",
        "CGD آبسه کاتالاز مثبت و گرانولوم است نه برفک.",
        "CF ریه و پانکراس است؛ لوزه را حذف نمی‌کند.",
    ],
    options_why_en=[
        "Correct — infection from 2 months, thrush, no tonsils, failure to thrive is SCID (T and B).",
        "XLA starts after 6 months and does not give viral/fungal thrush.",
        "CGD is catalase-positive abscesses and granulomas, not thrush.",
        "CF is lung and pancreas; it does not erase tonsils.",
    ],
    explanation_fa=(
        "نقص ایمنی ترکیبی شدید هم لنفوسیت T و هم اغلب B را می‌گیرد. عفونت زود، فرصت‌طلب، "
        "بدون بافت لنفاوی. پیوند مغز استخوان درمان است. واکسن زنده ممنوع."
    ),
    explanation_en=(
        "SCID takes T cells and often B cells. Early opportunistic infection, no lymphoid "
        "tissue. Bone-marrow transplant is the treatment. No live vaccines."
    ),
    micro=pts(
        ["ALC پایین اولین سرنخ SCID است.",
         "TREC نوزادی غربال می‌کند.",
         "XLA: B صفر و بعد از اتمام IgG مادر.",
         "برفک یعنی T خراب است.",
         "CGD: NBT/DHR غیرطبیعی.",
         "CF: عرق و سودومونا.",
         "خانواده غیرمنسوب SCID را رد نمی‌کند.",
         "ایزوله و IVIG و پیوند.",
         "BCG در SCID منتشر می‌شود.",
         "وزن ۷ کیلو در ۲سالگی FTT شدید است.",
         "مننژیت و اوتیت چرکی مکرر الگو است."],
        ["A low ALC is the first SCID clue.",
         "Newborn TREC screens for it.",
         "XLA: zero B cells after maternal IgG wanes.",
         "Thrush means T cells are broken.",
         "CGD: abnormal NBT/DHR.",
         "CF: sweat test and Pseudomonas.",
         "Unrelated parents do not exclude SCID.",
         "Isolate, IVIG and transplant.",
         "BCG disseminates in SCID.",
         "7 kg at 2 years is severe FTT.",
         "Repeated purulent otitis and meningitis is the pattern."],
    ),
    golden_fa="برفک + بدون لوزه + عفونت از نوزادی = SCID.",
    golden_en="Thrush plus no tonsils plus infection from infancy is SCID.",
    refs=["Nelson — Primary immunodeficiency"],
    concept="scid-thrush", concept_fa="SCID و برفک", concept_en="SCID thrush")

add("کودکان", 77,
    chapter_fa="عفونی / کاواساکی", chapter_en="ID / Kawasaki",
    options_why_fa=[
        "NSAID مال آرتریت است نه کاواساکی کامل.",
        "استروئید تنها خط اول نیست.",
        "پاسخ صحیح — کاواساکی کامل: IVIG به‌علاوه آسپرین.",
        "درمان محافظه‌کارانه آنوریسم کرونر می‌سازد.",
    ],
    options_why_en=[
        "NSAIDs are for arthritis, not complete Kawasaki.",
        "Steroid alone is not first-line.",
        "Correct — complete Kawasaki: IVIG plus aspirin.",
        "Conservative care makes coronary aneurysms.",
    ],
    explanation_fa=(
        "تب یک هفته + کنژونکتیویت غیرچرکی + زبان توت‌فرنگی + راش + پوسته دور ناخن = کاواساکی. "
        "IVIG در ۱۰ روز اول آنوریسم را کم می‌کند."
    ),
    explanation_en=(
        "A week of fever plus nonsuppurative conjunctivitis plus strawberry tongue plus rash "
        "plus periungual peel is Kawasaki. IVIG in the first 10 days cuts aneurysms."
    ),
    micro=pts(
        ["۵ معیار پوستی-مخاطی + تب ۵ روز.",
         "پوسته دور ناخن در فاز تحت‌حاد است.",
         "آسپرین ضدالتهاب بعد ضدپلاکت.",
         "اکو کرونر در تشخیص و پیگیری.",
         "مقاوم: دوز دوم IVIG یا استروئید یا اینفلیکسیماب.",
         "اسکارلت زبان توت‌فرنگی دارد ولی پوسته کاواساکی نوک انگشت است.",
         "سرخک سرفه و کنژونکتیویت دارد اما واکسن و کوپلیک.",
         "BSA در ادرار کاواساکی شایع است و استریل است.",
         "گلوکوکورتیکوئید اول در پرخطر اضافه می‌شود نه تنها.",
         "واکسن زنده را ۱۱ ماه بعد از IVIG عقب بینداز.",
         "درمان را معطل اکو نکن."],
        ["Five mucocutaneous criteria plus 5 days of fever.",
         "Periungual peel is the subacute phase.",
         "Aspirin is anti-inflammatory then antiplatelet.",
         "Echo the coronaries at diagnosis and follow-up.",
         "Resistant: a second IVIG or steroid or infliximab.",
         "Scarlet fever has a strawberry tongue but Kawasaki peels the fingertips.",
         "Measles has cough and conjunctivitis but vaccine and Koplik.",
         "Sterile pyuria is common in Kawasaki.",
         "Steroid is added first in high-risk disease, not given alone.",
         "Delay live vaccines 11 months after IVIG.",
         "Do not wait for the echo to treat."],
    ),
    golden_fa="کاواساکی: IVIG. صبر نکن.",
    golden_en="Kawasaki: IVIG. Do not wait.",
    refs=["Nelson / AHA Kawasaki"],
    concept="kawasaki-ivig", concept_fa="IVIG کاواساکی", concept_en="Kawasaki IVIG")

add("کودکان", 78,
    chapter_fa="مایع / دهیدراتاسیون", chapter_en="Fluids / dehydration",
    options_why_fa=[
        "۵٪ خفیف است: فقط تشنگی و مخاط کمی خشک.",
        "۶٪ هنوز خفیف-متوسط مرزی است؛ فونتانل فرورفته و تورگور کم متوسط است.",
        "پاسخ صحیح — بی‌قراری، تشنگی، تورگور کم، فونتانل فرورفته، نبض لمس‌شدنی = حدود ۱۰٪.",
        "۱۵٪ شوک است: نبض ضعیف و لتارژی.",
    ],
    options_why_en=[
        "5% is mild: just thirst and a slightly dry mouth.",
        "6% is still borderline mild-moderate; a sunken fontanelle and poor turgor are moderate.",
        "Correct — irritable, thirsty, poor turgor, sunken fontanelle, palpable pulses is about 10%.",
        "15% is shock: weak pulses and lethargy.",
    ],
    explanation_fa=(
        "طبق جدول نلسون: متوسط ≈ ۱۰٪ وزن (۵۰–۱۰۰ میلی‌لیتر/کیلو). نبض هنوز لمس می‌شود "
        "پس شوک ۱۵٪ نیست. خفیف ۵٪ فونتانل را فرو نمی‌برد."
    ),
    explanation_en=(
        "Nelson's table: moderate is about 10% of weight (50–100 ml/kg). Pulses are still "
        "palpable so this is not 15% shock. Mild 5% does not sink the fontanelle."
    ),
    micro=pts(
        ["خفیف ۵٪: ادرار کم و تشنگی.",
         "متوسط ۱۰٪: تورگور، چشم و فونتانل فرورفته، تاکی‌کاردی.",
         "شدید ۱۵٪: شوک، لتارژی، پرشدگی کاپیلر طولانی.",
         "ORS اگر هوشیار و بدون شوک.",
         "شوک: ۲۰ میلی‌لیتر/کیلو سالین بولوس.",
         "سدیم را برای نوع هیپوناترمی/هیپر ببین.",
         "این شیرخوار بی‌قرار است نه لتارژیک.",
         "نبض لمس‌شدنی شوک کامل را رد می‌کند.",
         "درصد تقریبی است نه آزمایشگاه.",
         "بعد از محاسبه، کمبود را در ۲۴ ساعت جبران کن.",
         "پتاسیم را بعد از ادرار کردن اضافه کن."],
        ["Mild 5%: oliguria and thirst.",
         "Moderate 10%: turgor, sunken eyes and fontanelle, tachycardia.",
         "Severe 15%: shock, lethargy, long capillary refill.",
         "ORS if awake and not shocked.",
         "Shock: 20 ml/kg saline bolus.",
         "Check sodium for hypo/hyper type.",
         "This infant is irritable, not lethargic.",
         "Palpable pulses exclude full shock.",
         "The percent is clinical, not a lab.",
         "After the sum, replace the deficit over 24 hours.",
         "Add potassium after the child urinates."],
    ),
    golden_fa="فونتانل فرورفته + نبض لمس‌شدنی ≈ ۱۰٪.",
    golden_en="Sunken fontanelle plus palpable pulses is about 10%.",
    refs=["Nelson — Dehydration"],
    concept="dehydration-10", concept_fa="دهیدراتاسیون ۱۰٪", concept_en="10 percent dehydration")

add("کودکان", 79,
    chapter_fa="غدد / ریکتز", chapter_en="Endo / rickets",
    options_why_fa=[
        "هیپرپاراتیروئیدی اولیه کلسیم را بالا می‌برد.",
        "ریکتز هیپوفسفاتمیک ویتامین D طبیعی دارد.",
        "گزینه ج در فارسی اسکن‌شده جابه‌جا است؛ تشخیص آزمایش = ریکتز تغذیه‌ای.",
        "پاسخ صحیح پس از تصحیح — Ca نرمال، PO4 پایین، ALP خیلی بالا، 25OHD پایین = ریکتز تغذیه‌ای.",
    ],
    options_why_en=[
        "Primary hyperparathyroidism raises calcium.",
        "Hypophosphatemic rickets has normal vitamin D.",
        "Correct on the official English options — nutritional rickets.",
        "Pseudohypoparathyroidism has high phosphate.",
    ],
    explanation_fa=(
        "تصحیح کلید: آزمایش دفترچه انگلیسی Ca نرمال، فسفات پایین، ALP بالا، 25OHD پایین است. "
        "این ریکتز کمبود ویتامین D است نه هیپوفسفاتمیک. در فارسی گزینهٔ ج و د به‌خاطر اسکن جابه‌جا "
        "چیده شده‌اند؛ پاسخ پزشکی ریکتز تغذیه‌ای است."
    ),
    explanation_en=(
        "Key correction: the official English labs are normal calcium, low phosphate, high ALP, "
        "low 25OHD. That is nutritional rickets, not hypophosphatemic rickets."
    ),
    micro=pts(
        ["ریکتز تغذیه‌ای: 25OHD پایین.",
         "هیپوفسفاتمیک (XLH): D طبیعی، فسفات خیلی پایین، FGF23.",
         "هیپرپارا: Ca بالا، PO4 پایین، PTH بالا.",
         "سودوهیپوپارا: Ca پایین، PO4 بالا.",
         "مچ پهن و فونتانل باز نشانه بالینی ریکتز است.",
         "درمان تغذیه‌ای: ویتامین D و کلسیم.",
         "XLH: بوپروسیوماب یا فسفات + کالیسیتریول.",
         "آلکالین فسفاتاز در هر ریکتز فعال بالاست.",
         "گزینهٔ الف فارسی در واقع خط آزمایش است نه تشخیص.",
         "متن انگلیسی رسمی را مبنا گذاشتیم.",
         "وزن‌گیری بد و تأخیر راه رفتن با ریکتز می‌خواند."],
        ["Nutritional rickets: low 25OHD.",
         "Hypophosphatemic (XLH): normal D, very low phosphate, FGF23.",
         "Hyperpara: high Ca, low PO4, high PTH.",
         "Pseudohypopara: low Ca, high PO4.",
         "Wide wrists and an open fontanelle are clinical rickets.",
         "Treat nutritional disease with vitamin D and calcium.",
         "XLH: burosumab or phosphate plus calcitriol.",
         "ALP is high in any active rickets.",
         "Persian option A is actually the lab line, not a diagnosis.",
         "We used the official English text.",
         "Poor weight gain and late walking fit rickets."],
    ),
    golden_fa="25OHD پایین = ریکتز تغذیه‌ای نه XLH.",
    golden_en="Low 25OHD is nutritional rickets, not XLH.",
    refs=["Nelson — Rickets"],
    concept="nutritional-rickets", concept_fa="ریکتز تغذیه‌ای", concept_en="Nutritional rickets",
    key_corrected=True, original_correct_index=2, correct_index=3,
    key_correction_fa="آزمایش رسمی 25OHD پایین است؛ تشخیص ریکتز تغذیه‌ای است نه هیپوفسفاتمیک. کلید چاپی به‌خاطر جابه‌جایی گزینه اصلاح شد.",
    key_correction_en="Official labs show low 25OHD; the diagnosis is nutritional rickets, not hypophosphatemic. The printed key was option-shifted.",
    key_correction_source="Nelson; Harrison mineral metabolism")

add("کودکان", 80,
    chapter_fa="متابولیک / گالاکتوزمی", chapter_en="Metabolic / galactosemia",
    options_why_fa=[
        "پاسخ صحیح — زردی + کاتاراکت + هیپوگلیسمی نوزاد = گالاکتوزمی (مسیر کربوهیدرات).",
        "آمینواسید (مثلاً تیروزینمی) کاتاراکت کلاسیک ندارد.",
        "اسید چرب با گرسنگی و هیپوکetotic است نه کاتاراکت.",
        "ویتامین کاتاراکت و هپاتواسپلنومگالی نمی‌سازد.",
    ],
    options_why_en=[
        "Correct — neonatal jaundice plus cataract plus hypoglycemia is galactosemia (carbohydrate path).",
        "Amino acids (e.g. tyrosinemia) do not classically make cataracts.",
        "Fatty-acid oxidation is fasting hypoketotic hypoglycemia, not cataracts.",
        "A vitamin defect does not make cataracts and hepatosplenomegaly.",
    ],
    explanation_fa=(
        "نقص GALT گالاکتوزمی کلاسیک است. شیر لاکتوز را به گلوکز و گالاکتوز می‌شکند. "
        "درمان قطع فوری شیر و شیر خشک بدون گالاکتوز. E.coli سپسیس همراه شایع است."
    ),
    explanation_en=(
        "GALT deficiency is classic galactosemia. Milk splits lactose into glucose and galactose. "
        "Treat by stopping milk at once and using a galactose-free formula. E. coli sepsis is a common partner."
    ),
    micro=pts(
        ["تریاد: نارسایی کبد، کاتاراکت، E.coli.",
         "کاهنده ادرار مثبت است در حالی که گلوکز نوار منفی است.",
         "آنزیم GALT در اریتروسیت تشخیص است.",
         "مسیر کربوهیدرات: گالاکتوز و فروکتوز.",
         "فروکتوزمی بعد از شروع میوه است نه روز ۲۵ با شیر.",
         "تیروزینمی بوی کلم و سوکسینیل‌استون.",
         "MCAD هیپوگلیسمی بدون کاتاراکت.",
         "غربال نوزاد را پیگیری کن.",
         "حتی شیر مادر را قطع کن.",
         "عقب‌ماندگی اگر دیر درمان شود.",
         "سؤال مسیر متابولیسم است نه نام آنزیم."],
        ["Triad: liver failure, cataract, E. coli.",
         "Urine reducing substances are positive while the glucose strip is negative.",
         "Red-cell GALT is the diagnosis.",
         "Carbohydrate path: galactose and fructose.",
         "Fructose intolerance starts after fruit, not on day 25 of milk.",
         "Tyrosinemia is cabbage smell and succinylacetone.",
         "MCAD is hypoglycemia without cataract.",
         "Follow the newborn screen.",
         "Stop even breast milk.",
         "Delay causes intellectual disability.",
         "The question is the pathway, not the enzyme name."],
    ),
    golden_fa="کاتاراکت + زردی نوزاد = گالاکتوزمی = کربوهیدرات.",
    golden_en="Neonatal cataract plus jaundice is galactosemia is carbohydrate.",
    refs=["Nelson — Galactosemia"],
    concept="galactosemia-carb", concept_fa="گالاکتوزمی کربوهیدرات", concept_en="Galactosemia carbohydrate")

# ---------- OB 91–96 ----------
add("زنان و زایمان", 91,
    chapter_fa="آناتومی / شریان واژینال", chapter_en="Anatomy / vaginal artery",
    options_why_fa=[
        "پاسخ صحیح — شریان واژینال شاخه شریان ایلیاک داخلی (هیپوگاستریک) است.",
        "آئورت شریان تخمدانی را می‌دهد نه واژینال را.",
        "شریان تخمدانی از آئورت می‌آید.",
        "ایلیاک خارجی فمورال می‌شود نه واژن.",
    ],
    options_why_en=[
        "Correct — the vaginal artery is a branch of the internal iliac (hypogastric).",
        "The aorta gives the ovarian artery, not the vaginal.",
        "The ovarian artery comes from the aorta.",
        "The external iliac becomes the femoral, not the vagina.",
    ],
    explanation_fa=(
        "ایلیاک داخلی قدامی: رحمی، واژینال، مثانه‌ای فوقانی، پودندال داخلی. "
        "لیگاسیون هیپوگاستریک خونریزی لگنی را کم می‌کند چون کولترال می‌ماند."
    ),
    explanation_en=(
        "Anterior internal iliac: uterine, vaginal, superior vesical, internal pudendal. "
        "Hypogastric ligation cuts pelvic bleeding because collaterals remain."
    ),
    micro=pts(
        ["هیپوگاستریک = ایلیاک داخلی.",
         "شریان رحمی از همین تنه است و حالب را صلیب می‌کند.",
         "شریان واژینال گاهی از رحمی می‌آید.",
         "تخمدان راست و چپ از آئورت؛ چپ به ورید کلیوی می‌ریزد.",
         "ایلیاک خارجی زیر اینگوینال فمورال است.",
         "پودندال داخلی پرینه را می‌دهد.",
         "در خونریزی پس از زایمان اگر رحم جمع باشد به پارگی فکر کن.",
         "لیگاسیون هیپوگاستریک باروری را حفظ می‌کند.",
         "آناتومی آزمون را با شاخه‌های قدامی حفظ کن.",
         "شریان ساکرال میانی از آئورت است نه واژن.",
         "نام هیپوگاستریک در دفترچه‌ها هنوز رایج است."],
        ["Hypogastric is the internal iliac.",
         "The uterine artery is from the same trunk and crosses the ureter.",
         "The vaginal artery sometimes comes off the uterine.",
         "Both ovaries from the aorta; the left vein drains to the renal vein.",
         "The external iliac becomes femoral under the inguinal ligament.",
         "The internal pudendal supplies the perineum.",
         "If the uterus is firm after birth and she bleeds, think laceration.",
         "Hypogastric ligation preserves fertility.",
         "Learn the anterior branches for the exam.",
         "The middle sacral artery is from the aorta, not the vagina.",
         "Booklets still say hypogastric."],
    ),
    golden_fa="شریان واژینال از هیپوگاستریک (ایلیاک داخلی).",
    golden_en="The vaginal artery is from the hypogastric (internal iliac).",
    refs=["Williams — Pelvic anatomy"],
    concept="vaginal-hypogastric", concept_fa="شریان واژینال", concept_en="Vaginal artery")

add("زنان و زایمان", 92,
    chapter_fa="بارداری نابجا / MTX", chapter_en="Ectopic / MTX",
    options_why_fa=[
        "ساک بالای ۳٫۵ سانتی‌متر منع نسبی است نه مطلق.",
        "ضربان قلب جنین منع نسبی/قوی است نه همیشه مطلق.",
        "پاسخ صحیح — شیردهی منع مطلق متوترکسات است.",
        "مایع صفاق اگر همودینامیک پایدار باشد منع مطلق نیست.",
    ],
    options_why_en=[
        "A sac over 3.5 cm is a relative contraindication.",
        "Fetal heartbeat is a relative/strong contraindication, not always absolute.",
        "Correct — breastfeeding is an absolute contraindication to methotrexate.",
        "Peritoneal fluid is not absolute if she is stable.",
    ],
    explanation_fa=(
        "MTX در شیر می‌رود و برای نوزاد سمی است. منع مطلق دیگر: ناپایداری، نقص ایمنی، "
        "بیماری ریوی/کبدی/کلیوی فعال، دیسکرازی خون، حساسیت MTX. اندازه و FHR نسبی‌اند."
    ),
    explanation_en=(
        "MTX enters milk and is toxic to the infant. Other absolutes: instability, "
        "immunodeficiency, active lung/liver/kidney disease, blood dyscrasia, MTX allergy. "
        "Size and FHR are relative."
    ),
    micro=pts(
        ["βhCG خیلی بالا موفقیت MTX را کم می‌کند.",
         "پارگی و شوک یعنی جراحی.",
         "لوکوورین در رژیم چنددوزه است.",
         "روز ۴ تا ۷ hCG باید ۱۵ درصد افت کند.",
         "از ضدالتهاب و آفتاب و اسیدفولیک اضافه پرهیز بگو.",
         "شیردهی را تا پاک شدن MTX قطع کن — پس الان منع است.",
         "حاملگی داخل رحمی همزمان منع است.",
         "درد روز ۳ تا ۷ جداشدن و تهدید نیست همیشه.",
         "ساک ۳٫۵ در بسیاری پروتکل‌ها نسبی است.",
         "مایع Cul-de-sac کم در پایدار قابل قبول است.",
         "Williams شیردهی را مطلق می‌داند."],
        ["A very high βhCG lowers MTX success.",
         "Rupture and shock mean surgery.",
         "Leucovorin is in the multidose regimen.",
         "hCG should fall 15% from day 4 to 7.",
         "Tell her to avoid NSAIDs, sun and extra folate.",
         "Stop breastfeeding until MTX is cleared — so it is contraindicated now.",
         "A simultaneous intrauterine pregnancy is a contraindication.",
         "Pain on days 3–7 is not always rupture.",
         "A 3.5 cm sac is relative in many protocols.",
         "A little cul-de-sac fluid is acceptable if stable.",
         "Williams calls breastfeeding absolute."],
    ),
    golden_fa="MTX و شیردهی: منع مطلق.",
    golden_en="MTX and breastfeeding: absolute contraindication.",
    refs=["Williams / ACOG — Ectopic pregnancy"],
    concept="mtx-breastfeed", concept_fa="متوترکسات شیردهی", concept_en="MTX breastfeeding")

add("زنان و زایمان", 93,
    chapter_fa="شیردهی / عفونت", chapter_en="Lactation / infection",
    options_why_fa=[
        "HIV در ایران منع شیردهی است (جایگزین امن).",
        "گالاکتوزمی نوزاد منع مطلق شیر مادر است.",
        "پاسخ صحیح — سل درمان‌شده و غیرمسری اجازه شیردهی دارد.",
        "آمفتامین در شیر می‌رود و منع است.",
    ],
    options_why_en=[
        "In Iran HIV is a contraindication when formula is safe.",
        "Neonatal galactosemia is an absolute contraindication to breast milk.",
        "Correct — treated, noninfectious TB may breastfeed.",
        "Amphetamine enters milk and is forbidden.",
    ],
    explanation_fa=(
        "سل فعال درمان‌نشده: جدایی تا دو هفته درمان و غیرمسری شدن. بعد شیردهی با ماسک "
        "و درمان مادر مجاز است. ایزونیازید با B6 برای مادر بی‌خطر است."
    ),
    explanation_en=(
        "Untreated active TB: separate until two weeks of treatment and noninfectious. "
        "Then breastfeeding with a mask and maternal therapy is allowed. Isoniazid plus B6 is safe for the mother."
    ),
    micro=pts(
        ["منع مطلق شیر: گالاکتوزمی، HIV در کشور با شیر خشک امن، HTLV، سل فعال حفره‌ای درمان‌نشده.",
         "هپاتیت B: شیردهی بعد از HBIG و واکسن نوزاد مجاز است.",
         "هپاتیت C: شیردهی مگر نوک سینه خون‌ریزی کند.",
         "مواد مخدر و آمفتامین و کوکائین منع‌اند.",
         "الکل و سیگار کاهش/احتیاط.",
         "ماستیت ادامه شیردهی از همان پستان است.",
         "آبسه: تخلیه و شیردهی از سمت مقابل.",
         "سؤال «می‌تواند» یعنی سل درمان‌شده.",
         "گالاکتوزمی را با کاتاراکت نوزاد قاطی نکن — اینجا تشخیص نوزاد است.",
         "WHO در آفریقا HIV را گاهی اجازه می‌دهد؛ آزمون ایران منع می‌داند.",
         "درمان سل را قطع نکن."],
        ["Absolute milk bans: galactosemia, HIV where formula is safe, HTLV, untreated cavitary TB.",
         "Hepatitis B: feed after HBIG and vaccine.",
         "Hepatitis C: feed unless the nipple is bleeding.",
         "Illicits, amphetamine and cocaine are banned.",
         "Alcohol and smoke: reduce or caution.",
         "Mastitis: keep feeding from that breast.",
         "Abscess: drain and feed from the other side.",
         "'Allowed' means treated TB.",
         "Do not mix galactosemia with the neonatal cataract question — here it is the baby's diagnosis.",
         "WHO sometimes allows HIV feeding in Africa; the Iranian exam forbids it.",
         "Do not stop TB treatment."],
    ),
    golden_fa="سل درمان‌شده: شیر بده. HIV و گالاکتوزمی نه.",
    golden_en="Treated TB: breastfeed. HIV and galactosemia: no.",
    refs=["Williams / AAP breastfeeding"],
    concept="tb-breastfeed", concept_fa="سل و شیردهی", concept_en="TB breastfeeding")

add("زنان و زایمان", 94,
    chapter_fa="عفونی / زگیل بارداری", chapter_en="ID / wart pregnancy",
    options_why_fa=[
        "TCA در بارداری مجاز است.",
        "کرایوتراپی مجاز است.",
        "پاسخ صحیح — پودوفیلین تراتوژن است و در بارداری ممنوع.",
        "لیزر تخریبی مجاز است.",
    ],
    options_why_en=[
        "TCA is allowed in pregnancy.",
        "Cryotherapy is allowed.",
        "Correct — podophyllin is teratogenic and forbidden in pregnancy.",
        "Destructive laser is allowed.",
    ],
    explanation_fa=(
        "زگیل تناسلی بارداری را با روش فیزیکی (کرایو، TCA، لیزر، coblation) درمان کن. "
        "پودوفیلین، پودوفیلوکس، ایمی‌کیمود و اینترفرون ممنوع‌اند."
    ),
    explanation_en=(
        "Treat pregnancy genital warts with physical methods (cryo, TCA, laser, coblation). "
        "Podophyllin, podofilox, imiquimod and interferon are forbidden."
    ),
    micro=pts(
        ["HPV ۶ و ۱۱ زگیل؛ ۱۶ و ۱۸ سرطان.",
         "بارداری زگیل را بزرگ می‌کند.",
         "سزارین فقط اگر راه تولد مسدود یا خونریزی باشد.",
         "پاپیلومای حنجره نوزاد نادر است.",
         "TCA سوزش موضعی می‌دهد.",
         "کرایو تاول و ترشح می‌دهد.",
         "پودوفیلین نوروپاتی و مرگ جنین گزارش شده.",
         "ایمی‌کیمود هم در بارداری توصیه نمی‌شود.",
         "مشاهده اگر ضایعه کوچک و بی‌علامت باشد رواست.",
         "شریک را هم نگاه کن.",
         "واکسن HPV در بارداری روتین شروع نمی‌شود."],
        ["HPV 6 and 11 are warts; 16 and 18 are cancer.",
         "Pregnancy grows warts.",
         "Caesarean only if the birth canal is blocked or bleeding.",
         "Neonatal laryngeal papilloma is rare.",
         "TCA burns locally.",
         "Cryo makes blisters and discharge.",
         "Podophyllin has neuropathy and fetal death reports.",
         "Imiquimod is also not advised in pregnancy.",
         "Watchful waiting is fine if the lesion is small and quiet.",
         "Look at the partner too.",
         "Do not routinely start HPV vaccine in pregnancy."],
    ),
    golden_fa="زگیل بارداری: TCA و کرایو. پودوفیلین نه.",
    golden_en="Pregnancy warts: TCA and cryo. Not podophyllin.",
    refs=["Williams / CDC STI pregnancy"],
    concept="podophyllin-pregnancy", concept_fa="پودوفیلین بارداری", concept_en="Podophyllin pregnancy")

add("زنان و زایمان", 95,
    chapter_fa="خونریزی پس از زایمان", chapter_en="Postpartum hemorrhage",
    options_why_fa=[
        "آتونی رحم شل است نه منقبض.",
        "اختلال انعقاد خون جاری و غیرلخته می‌دهد؛ رحم ممکن است شل باشد.",
        "پاسخ صحیح — رحم سفت + خون روشن بعد از فورسپس = پارگی کانال.",
        "جفت باقی‌مانده رحم را پر و اغلب شل نگه می‌دارد.",
    ],
    options_why_en=[
        "Atony is a soft uterus, not a contracted one.",
        "Coagulopathy is a trickle of unclotted blood; the uterus may be soft.",
        "Correct — a firm uterus plus bright blood after forceps is a canal laceration.",
        "Retained placenta keeps the uterus full and often soft.",
    ],
    explanation_fa=(
        "چهار T: تون، تروما، بافت، ترومبین. فورسپس تروما است. معاینه سرویکس و واژن "
        "زیر نور خوب واجب است."
    ),
    explanation_en=(
        "Four Ts: tone, trauma, tissue, thrombin. Forceps is trauma. Examine cervix and "
        "vagina under good light."
    ),
    micro=pts(
        ["آتونی شایع‌ترین PPH است.",
         "اگر رحم سنگ است به تروما برو.",
         "فورسپس و واکیوم و ماکروزومی پارگی می‌سازند.",
         "هماتوم پنهان را با درد یک‌طرفه فکر کن.",
         "اکسی‌توسین خط اول آتونی است.",
         "ترانگزامیک اسید زود کمک می‌کند.",
         "باقی جفت را با دست یا کورتاژ بردار.",
         "DIC بعد از Abruption و مرده داخل رحم.",
         "خون روشن شریانی‌تر از خون تیره آتونی است.",
         "ترمیم را لایه به لایه انجام بده.",
         "اگر پارگی تا رحم رفت لاپاراتومی."],
        ["Atony is the commonest PPH.",
         "If the uterus is a rock, go to trauma.",
         "Forceps, vacuum and macrosomia tear the canal.",
         "Think of a hidden hematoma with one-sided pain.",
         "Oxytocin is first-line for atony.",
         "Tranexamic acid helps early.",
         "Take retained placenta with a hand or curettage.",
         "DIC follows abruption and a dead fetus.",
         "Bright blood is more arterial than the dark blood of atony.",
         "Repair layer by layer.",
         "If the tear reaches the uterus, laparotomy."],
    ),
    golden_fa="رحم سفت + فورسپس + خون روشن = پارگی.",
    golden_en="Firm uterus plus forceps plus bright blood is a laceration.",
    refs=["Williams — Postpartum hemorrhage"],
    concept="pph-laceration", concept_fa="پارگی PPH", concept_en="PPH laceration")

add("زنان و زایمان", 96,
    chapter_fa="غدد / تیروئید بارداری", chapter_en="Endo / thyroid pregnancy",
    options_why_fa=[
        "T3 توتال مثل T4 بالا می‌رود نه پایین.",
        "TSH در اوایل بارداری کمی پایین می‌آید نه بالا.",
        "TBG بالا می‌رود نه پایین.",
        "پاسخ صحیح — استروژن TBG را بالا می‌برد و T4 توتال زیاد می‌شود.",
    ],
    options_why_en=[
        "Total T3 rises like T4; it does not fall.",
        "TSH dips a little in early pregnancy; it does not rise.",
        "TBG rises, it does not fall.",
        "Correct — estrogen raises TBG and total T4 rises.",
    ],
    explanation_fa=(
        "آزاد T4 تقریباً ثابت می‌ماند (یا کمی در سه‌ماهه اول تحت hCG بالا می‌رود). "
        "آزمایش را با بازه بارداری بخوان نه غیرحامله."
    ),
    explanation_en=(
        "Free T4 stays almost flat (or rises a little in the first trimester under hCG). "
        "Read labs on a pregnancy interval, not a nonpregnant one."
    ),
    micro=pts(
        ["hCG TSH را در سه‌ماهه اول سرکوب می‌کند.",
         "TBG از هفته ۱۶ دو برابر می‌شود.",
         "T4 توتال حدود ۱٫۵ برابر غیرحامله است.",
         "آزاد T4 روش‌ها فرق دارند؛ ترجیح برخی مراکز T4 توتال تنظیم‌شده است.",
         "هیپوتیروئید: لووتیروکسین را حدود ۳۰ درصد زیاد کن.",
         "هدف TSH سه‌ماهه اول معمولاً زیر ۲٫۵.",
         "PTU سه‌ماهه اول؛ متی‌مازول بعد.",
         "آنتی‌بادی گیرنده از جفت رد می‌شود.",
         "ید کافی ۲۵۰ میکروگرم است.",
         "سؤال فیزیولوژی است نه بیماری.",
         "کاهش TSH اوایل طبیعی است."],
        ["hCG suppresses TSH in the first trimester.",
         "TBG doubles by week 16.",
         "Total T4 is about 1.5 times the nonpregnant value.",
         "Free T4 assays disagree; some centres prefer adjusted total T4.",
         "Hypothyroid: raise levothyroxine about 30%.",
         "First-trimester TSH target is usually under 2.5.",
         "PTU in the first trimester; methimazole after.",
         "Receptor antibody crosses the placenta.",
         "Iodine need is about 250 micrograms.",
         "This question is physiology, not disease.",
         "A low-normal TSH early on is normal."],
    ),
    golden_fa="بارداری: TBG و T4 توتال بالا. TSH اول پایین.",
    golden_en="Pregnancy: TBG and total T4 up. TSH down early.",
    refs=["Williams / ATA pregnancy thyroid"],
    concept="tbg-pregnancy", concept_fa="TBG بارداری", concept_en="Pregnancy TBG")


def apply():
    files = sorted(glob.glob(os.path.join(HERE, "import-payload.archive.part*.json")))
    n = 0
    for path in files:
        body = json.load(open(path, encoding="utf-8"))
        changed = False
        for q in body["questions"]:
            if int(q.get("year_num") or 0) != 1402:
                continue
            rec = L.get((q["subject_fa"], int(q.get("question_no") or 0)))
            if not rec:
                continue
            for k in ("chapter_fa", "chapter_en", "options_why_fa", "options_why_en",
                      "explanation_fa", "explanation_en", "micro", "golden_fa", "golden_en",
                      "refs", "concept", "concept_fa", "concept_en"):
                q[k] = rec[k]
            q["needs_lesson"] = False
            q["lesson_part"] = 1
            if rec.get("key_corrected"):
                q["original_correct_index"] = rec["original_correct_index"]
                q["correct_index"] = rec["correct_index"]
                q["key_corrected"] = True
                q["key_correction_fa"] = rec["key_correction_fa"]
                q["key_correction_en"] = rec["key_correction_en"]
                q["key_correction_source"] = rec["key_correction_source"]
            n += 1
            changed = True
        if changed:
            json.dump(body, open(path, "w", encoding="utf-8"), ensure_ascii=False)
    print(f"applied lessons to {n} Khordad-1402 questions")
    print("keys:", ", ".join(f"{s} q{no}" for s, no in sorted(L)))


if __name__ == "__main__":
    apply()
