# -*- coding: utf-8 -*-
"""Sanity-check the Khordad-1402 archive payloads before they hit the bank."""
import glob, json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
LET = 'الفبجد'


def main():
    files = sorted(glob.glob(os.path.join(HERE, 'import-payload.archive.part*.json')))
    if not files:
        print('no payloads'); return 1
    rows = []
    for f in files:
        d = json.load(open(f, encoding='utf-8'))
        assert d.get('program') == 'preint'
        assert d.get('questions')
        rows.extend(d['questions'])

    nos = [(r.get('year_num'), r.get('month'), r['question_no']) for r in rows]
    errs = []
    if len(rows) < 395:
        errs.append(f'too few questions: {len(rows)}')
    if len(nos) != len(set(nos)):
        errs.append('duplicate (year, month, question_no)')
    en = sum(1 for r in rows if r.get('en_source') == 'official_booklet' and r.get('question_en'))
    if en < 195:
        errs.append(f'too little official English: {en}')

    q1 = next(r for r in rows if r['question_no'] == 1 and r.get('year_num') == 1402)
    if q1['correct_index'] != 2:
        errs.append(f'Q1 key {q1["correct_index"]} want 2 (bismuth quadruple after macrolide)')
    if 'Helicobacter' not in q1.get('question_en', ''):
        errs.append('Q1 missing official English Helicobacter')
    if q1['subject_fa'] != 'داخلی':
        errs.append(f'Q1 subject {q1["subject_fa"]}')

    q97 = next(r for r in rows if r['question_no'] == 97 and r.get('year_num') == 1402)
    if q97['subject_fa'] != 'مغز و اعصاب':
        errs.append(f'Q97 should be neurology, got {q97["subject_fa"]}')
    if q97['correct_index'] != 0:
        errs.append(f'Q97 cluster headache key {q97["correct_index"]} want 0')

    q99 = next(r for r in rows if r['question_no'] == 99)
    if not q99.get('key_corrected') or q99['correct_index'] != 1:
        errs.append(f'Q99 should be corrected to headache/vomiting, got {q99.get("correct_index")} corr={q99.get("key_corrected")}')

    for r in rows:
        if not (0 <= r['correct_index'] <= 3):
            errs.append(f'q{r["question_no"]} bad key')
        if len(r.get('options_fa') or []) != 4:
            errs.append(f'q{r["question_no"]} options_fa')
        if r.get('year_num') == 1402 and r.get('en_source') != 'official_booklet':
            errs.append(f'q{r["question_no"]} en_source {r.get("en_source")}')

    q97b = next(r for r in rows if r['question_no'] == 97 and r.get('year_num') == 1403)
    if q97b['correct_index'] != 1 or 'فنی' not in q97b['question_fa']:
        errs.append(f'1403-06 q97 should be phenytoin/ب, got {q97b["correct_index"]}')
    q99b = next(r for r in rows if r['question_no'] == 99 and r.get('year_num') == 1403)
    if q99b['correct_index'] != 3 or 'استاتوس' not in q99b['question_fa']:
        errs.append(f'1403-06 q99 should be status/د, got {q99b["correct_index"]}')

    print(f'{len(rows)} questions in {len(files)} files; official EN on {en}')
    print(f'Q1 {LET[q1["correct_index"]]}  Q97 {LET[q97["correct_index"]]}  Q99 {LET[q99["correct_index"]]} (corrected)')
    if errs:
        print('FAIL')
        for e in errs[:20]:
            print(' ', e)
        return 1
    print('OK')
    return 0


if __name__ == '__main__':
    sys.exit(main())
