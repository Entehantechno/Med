# -*- coding: utf-8 -*-
"""Khordad-1402 majors cluster 4 (surgery 55–58, internal 20–23, peds 69–70, OB 89–90).

Official English stems/options are never rewritten.
Internal 22 EN options are misaligned in the ministry booklet — keep verbatim.
"""
import json, glob, os

HERE = os.path.dirname(os.path.abspath(__file__))
L = {}


def add(subj, no, **kw):
    L[(subj, no)] = kw


add("جراحی", 55,
    chapter_fa="پستان / BIRADS", chapter_en="Breast / BIRADS",
    options_why_fa=[
        "اکسیزیون با حاشیه درمان است نه قدم تشخیصی اول؛ اول بافت لازم است.",
        "پیگیری ۶ ماهه مال BIRADS ۳ است نه ۴a.",
        "پاسخ صحیح — BIRADS ۴a یعنی ۲ تا ۱۰ درصد بدخیمی؛ core needle تشخیص را قطعی می‌کند.",
        "شیمی‌درمانی بدون پاتولوژی هیچ‌وقت شروع نمی‌شود.",
    ],
    options_why_en=[
        "Excision with a margin is treatment, not the first diagnostic step; you need tissue first.",
        "Six-month follow-up is for BIRADS 3, not 4a.",
        "Correct — BIRADS 4a is a 2–10% chance of cancer; a core needle makes the diagnosis.",
        "Chemotherapy is never started without pathology.",
    ],
    explanation_fa=(
        "ضایعه سفت ۲ سانتی‌متری با BIRADS ۴a نیاز به نمونه‌برداری دارد نه پیگیری و نه عمل "
        "فوری و نه شیمی‌درمانی. استاندارد امروز core needle است چون هم تشخیص می‌دهد و هم "
        "برای جراحی بعدی نقشه می‌سازد."
    ),
    explanation_en=(
        "A firm 2 cm lesion that is BIRADS 4a needs a tissue sample, not observation, "
        "immediate wide excision or chemotherapy. Today's standard is a core needle: it "
        "makes the diagnosis and plans any later surgery."
    ),
    micro={
        "lead_fa": "BIRADS ۴a یعنی بیوپسی، نه پیگیری و نه شیمی‌درمانی.",
        "lead_en": "BIRADS 4a means biopsy, not follow-up and not chemotherapy.",
        "points_fa": [
            "BIRADS ۲ خوش‌خیم قطعی است.",
            "BIRADS ۳ احتمالاً خوش‌خیم است؛ پیگیری کوتاه.",
            "BIRADS ۴a تا ۴c طیف بدخیمی ۲ تا ۹۵ درصد است.",
            "BIRADS ۵ تقریباً قطعی بدخیم است و باز هم بافت می‌خواهد.",
            "آگزیلا منفی شیمی‌درمانی نئوادجوانت را بدون پاتولوژی توجیه نمی‌کند.",
            "FNA سیتولوژی است؛ core بافت معماری را نگه می‌دارد.",
            "مارکرهای گیرنده روی core قابل اندازه‌گیری‌اند.",
            "اکسیزیون اول وقتی لازم است که core ممکن نباشد یا نتیجه ناهماهنگ باشد.",
            "سونوگرافی آگزیلا درگیری غده را غربال می‌کند.",
            "هر ضایعه لمس‌شدنی سفت در ۴۰ سالگی تا خلافش ثابت شود جدی است.",
        ],
        "points_en": [
            "BIRADS 2 is definitely benign.",
            "BIRADS 3 is probably benign; short-interval follow-up.",
            "BIRADS 4a to 4c spans a 2–95% chance of cancer.",
            "BIRADS 5 is almost certainly malignant and still needs tissue.",
            "A negative axilla does not justify neoadjuvant chemo without pathology.",
            "FNA is cytology; a core keeps architecture.",
            "Receptor markers can be read on a core.",
            "Go to excision first only if a core is impossible or the result does not fit.",
            "Axillary ultrasound screens for node disease.",
            "Any firm palpable lesion at 40 is serious until proven otherwise.",
        ],
    },
    golden_fa="BIRADS ۴a = core needle. پیگیری مال ۳ است.",
    golden_en="BIRADS 4a is a core needle. Follow-up is for 3.",
    refs=["Schwartz — Breast; ACR BIRADS"],
    concept="birads-4a-core", concept_fa="بیوپسی BIRADS ۴a", concept_en="BIRADS 4a core biopsy")

add("جراحی", 56,
    chapter_fa="تیروئید / FNA", chapter_en="Thyroid / FNA",
    options_why_fa=[
        "نتیجه خوش‌خیم هنوز پیگیری سونوگرافیک می‌خواهد؛ رها کردن کامل غلط است.",
        "پاسخ صحیح — بعد از FNA خوش‌خیم (ندول آدنوماتوئید) سونوگرافی ۱۲ ماه بعد کافی است.",
        "لوبکتومی برای Bethesda IV یا مشکوک است نه بعد از تکرار خوش‌خیم.",
        "تیروئیدکتومی توتال اصلاً جای این ندول بی‌علامت نیست.",
    ],
    options_why_en=[
        "A benign result still needs ultrasound follow-up; walking away completely is wrong.",
        "Correct — after a benign FNA (adenomatoid nodule) an ultrasound in 12 months is enough.",
        "Lobectomy is for Bethesda IV or a suspicious lesion, not after a repeat benign FNA.",
        "Total thyroidectomy has no place in this asymptomatic nodule.",
    ],
    explanation_fa=(
        "AUS اول تکرار FNA می‌خواهد. تکرار خوش‌خیم شد و اندازه ثابت است. ATA می‌گوید "
        "پیگیری سونوگرافی ۱۲ تا ۲۴ ماه بعد. جراحی الان ضرری بی‌فایده است."
    ),
    explanation_en=(
        "A first AUS needs a repeat FNA. The repeat is benign and the size is stable. "
        "ATA says follow with ultrasound at 12–24 months. Surgery now is harm without benefit."
    ),
    micro={
        "lead_fa": "AUS را تکرار کن. اگر خوش‌خیم شد سونوگرافی سال بعد، نه عمل.",
        "lead_en": "Repeat an AUS. If it is then benign, ultrasound next year — not an operation.",
        "points_fa": [
            "بتسدا III = AUS/FLUS؛ خطر بدخیمی حدود ۵ تا ۱۵ درصد.",
            "تکرار FNA یا آزمایش مولکولی قدم بعد AUS است.",
            "بتسدا II خوش‌خیم است؛ پیگیری تصویر.",
            "بتسدا IV (فولیکولار نئوپلاسم) معمولاً لوبکتومی می‌خواهد.",
            "بتسدا V و VI جراحی است.",
            "ندول داغ با TSH پایین کمتر بدخیم است.",
            "رشد واضح یا علائم فشاری جراحی را برمی‌گرداند.",
            "ندول ۲ سانتی بی‌علامت با FNA خوش‌خیم عمل نمی‌شود.",
            "سونوگرافی پرخطر (حاشیه نامنظم، میکروکلسیفیکاسیون) آستانه FNA را پایین می‌آورد.",
            "بیمار را از خطر باقی‌مانده کوچک ولی واقعی خبردار کن.",
        ],
        "points_en": [
            "Bethesda III is AUS/FLUS; cancer risk is about 5–15%.",
            "Repeat FNA or a molecular test is the next step after AUS.",
            "Bethesda II is benign; image follow-up.",
            "Bethesda IV (follicular neoplasm) usually needs a lobectomy.",
            "Bethesda V and VI are surgery.",
            "A hot nodule with a low TSH is less often malignant.",
            "Clear growth or compressive symptoms bring surgery back.",
            "A 2 cm asymptomatic nodule with a benign FNA is not operated.",
            "High-risk ultrasound (irregular margin, microcalcification) lowers the FNA threshold.",
            "Tell the patient a small residual risk remains.",
        ],
    },
    golden_fa="FNA خوش‌خیم بعد از AUS = سونوگرافی ۱۲ ماه بعد.",
    golden_en="A benign FNA after AUS is an ultrasound in 12 months.",
    refs=["Schwartz / ATA — Thyroid nodule"],
    concept="aus-then-benign", concept_fa="AUS سپس خوش‌خیم", concept_en="AUS then benign")

add("جراحی", 57,
    chapter_fa="کبد / کیست هیداتید", chapter_en="Liver / hydatid cyst",
    options_why_fa=[
        "پیگیری تنها کیست ساده بدون دخترکیست را می‌توان صبر کرد؛ اینجا هیداتید محتمل است.",
        "پاسخ صحیح — کیست داخل کیست یعنی هیداتید؛ قدم بعد سرولوژی است نه سوزن.",
        "آسپیراسیون خطر آنافیلاکسی و کاشت صفاقی دارد.",
        "بیوپسی سوزنی همان خطر نشت اسکولکس را دارد.",
    ],
    options_why_en=[
        "Observation is for a simple cyst without daughter cysts; here hydatid is likely.",
        "Correct — cysts inside a cyst mean hydatid; the next step is serology, not a needle.",
        "Aspiration risks anaphylaxis and peritoneal seeding.",
        "A needle biopsy has the same leak-of-scolices risk.",
    ],
    explanation_fa=(
        "کیست کبدی حاوی چند کیست کوچک تصویر کلاسیک هیداتید (اکینوکوکوس) است. تشخیص با "
        "سرولوژی تأیید می‌شود. سوزن ممنوع است مگر در پروتکل PAIR کنترل‌شده."
    ),
    explanation_en=(
        "A liver cyst holding several smaller cysts is classic hydatid (Echinococcus). "
        "Confirm with serology. A needle is forbidden except in a controlled PAIR protocol."
    ),
    micro={
        "lead_fa": "دخترکیست = هیداتید. سرولوژی بله، FNA نه.",
        "lead_en": "Daughter cysts are hydatid. Serology yes, FNA no.",
        "points_fa": [
            "میزبان قطعی سگ است؛ انسان میزبان واسط.",
            "کبد شایع‌ترین عضو است؛ بعد ریه.",
            "ELISA IgG حساس است؛ ممکن است منفی کاذب بدهد.",
            "CT یا MRI دیواره و دخترکیست را بهتر می‌بیند.",
            "درمان: آلبندازول ± جراحی یا PAIR انتخابی.",
            "اسپیلاژ حین عمل آنافیلاکسی و عود می‌سازد.",
            "کیست ساده تک‌حفره‌ای بدون دیواره ضخیم هیداتید نیست.",
            "آبسه آمیبی تب و لکوسیتوز و سفر می‌دهد.",
            "کیستادنوم صفراوی سپتوم ظریف بدون دخترکیست دارد.",
            "در مناطق اندمیک ایران همیشه هیداتید را در لیست بگذار.",
        ],
        "points_en": [
            "The definitive host is the dog; humans are intermediate.",
            "The liver is the commonest organ, then the lung.",
            "IgG ELISA is sensitive; false negatives happen.",
            "CT or MRI sees the wall and daughter cysts better.",
            "Treat with albendazole plus surgery or selected PAIR.",
            "Spill at operation causes anaphylaxis and recurrence.",
            "A simple unilocular cyst without a thick wall is not hydatid.",
            "An amoebic abscess gives fever, leucocytosis and travel.",
            "A biliary cystadenoma has fine septa without daughter cysts.",
            "In endemic Iran always keep hydatid on the list.",
        ],
    },
    golden_fa="کیست داخل کیست کبد: سرولوژی. سوزن نزن.",
    golden_en="Cysts inside a liver cyst: serology. Do not put a needle in.",
    refs=["Schwartz — Hydatid disease"],
    concept="hydatid-serology", concept_fa="سرولوژی هیداتید", concept_en="Hydatid serology")

add("جراحی", 58,
    chapter_fa="طحال / ترومبوسیتوز", chapter_en="Spleen / thrombocytosis",
    options_why_fa=[
        "۹۰۰ هزار الان خطرناک است؛ سه ماه صبر بدون ضدپلاکت دیر است.",
        "طحال فرعی پلاکت را پایین می‌آورد نه بالا.",
        "وارفارین برای ترومبوسیتوز واکنشی اندیکاسیون ندارد.",
        "پاسخ صحیح — پلاکت بالای حدود یک میلیون بعد از اسپلنکتومی با آسپرین پوشش داده می‌شود.",
    ],
    options_why_en=[
        "900,000 is already high; waiting three months with no antiplatelet is late.",
        "An accessory spleen would lower platelets, not raise them.",
        "Warfarin has no role in reactive post-splenectomy thrombocytosis.",
        "Correct — a platelet count near a million after splenectomy is covered with aspirin.",
    ],
    explanation_fa=(
        "بعد از برداشتن طحال پلاکت واکنشی بالا می‌رود و اوج آن هفته‌های اول است. "
        "اگر به حدود یک میلیون نزدیک شد آسپرین با دوز کم برای پیشگیری ترومبوز وریدی احشایی "
        "داده می‌شود. وارفارین و جستجوی طحال فرعی اینجا بی‌ربط‌اند."
    ),
    explanation_en=(
        "After the spleen comes out, platelets rise reactively and peak in the first weeks. "
        "When they approach a million, low-dose aspirin is given to prevent visceral venous "
        "thrombosis. Warfarin and a hunt for an accessory spleen are irrelevant here."
    ),
    micro={
        "lead_fa": "پلاکت خیلی بالا بعد از اسپلنکتومی = آسپرین، نه وارفارین.",
        "lead_en": "Very high platelets after splenectomy mean aspirin, not warfarin.",
        "points_fa": [
            "ترومبوسیتوز واکنشی روزهای ۷ تا ۲۰ به اوج می‌رسد.",
            "آستانه رایج آسپرین حدود ۷۵۰ هزار تا یک میلیون است.",
            "ترومبوز ورید پورت و طحالی عارضه شناخته‌شده است.",
            "واکسن کپسول‌دار (پنوموکوک، مننگوکوک، هموفیلوس) قبل یا بعد عمل واجب است.",
            "طحال فرعی علت ترومبوسیتوپنی پایدار است نه ترومبوسیتوز.",
            "اگر پلاکت قبل عمل هم بالا بود CML و essential را فکر کن.",
            "هیدراته نگه داشتن کمک می‌کند.",
            "آسپرین را تا افت پلاکت ادامه بده.",
            "آنتی‌کوآگولان فقط اگر لخته ثابت شد.",
            "حال عمومی خوب ردکننده ترومبوسیتوز نیست.",
        ],
        "points_en": [
            "Reactive thrombocytosis peaks around days 7–20.",
            "A common aspirin threshold is about 750,000 to a million.",
            "Portal and splenic vein thrombosis is a known complication.",
            "Encapsulated-organism vaccines (pneumococcus, meningococcus, Hib) are mandatory.",
            "An accessory spleen causes persistent thrombocytopenia, not thrombocytosis.",
            "If platelets were high before surgery, think of CML and essential thrombocythaemia.",
            "Keep the patient hydrated.",
            "Continue aspirin until the count falls.",
            "Anticoagulate only if a clot is proven.",
            "Looking well does not rule out dangerous thrombocytosis.",
        ],
    },
    golden_fa="بعد از اسپلنکتومی پلاکت ۹۰۰ هزار: آسپرین بده.",
    golden_en="After splenectomy a platelet count of 900,000 means give aspirin.",
    refs=["Schwartz — Splenectomy"],
    concept="post-splenectomy-asa", concept_fa="آسپرین بعد از اسپلنکتومی", concept_en="Post-splenectomy aspirin")

add("داخلی", 20,
    chapter_fa="تیروئید / ندول", chapter_en="Thyroid / nodule",
    options_why_fa=[
        "پاسخ صحیح — TSH سرکوب‌شده یعنی اول اسکن ایزوتوپ؛ ندول داغ بندرت بدخیم است.",
        "متی‌مازول بدون اثبات پرکاری بالینی و اسکن زود است.",
        "پردنیزولون مال تیروئیدیت تحت‌حاد دردناک است نه ندول تنها.",
        "FNA وقتی TSH پایین است قدم اول نیست؛ اول اسکن.",
    ],
    options_why_en=[
        "Correct — a suppressed TSH means a radioisotope scan first; a hot nodule is rarely malignant.",
        "Methimazole is early without proven clinical hyperthyroidism and a scan.",
        "Prednisolone is for painful subacute thyroiditis, not a lone nodule.",
        "FNA is not first when TSH is low; scan first.",
    ],
    explanation_fa=(
        "طبق ATA اگر TSH پایین باشد قبل از FNA اسکن تکنسیوم یا ید انجام می‌شود. "
        "ندول داغ practically از بدخیمی معاف است و FNA لازم ندارد."
    ),
    explanation_en=(
        "Per ATA, if TSH is low do a technetium or iodine scan before FNA. "
        "A hot nodule is practically exempt from cancer and does not need FNA."
    ),
    micro={
        "lead_fa": "ندول + TSH پایین = اسکن اول. FNA مال ندول سرد است.",
        "lead_en": "A nodule plus a low TSH is a scan first. FNA is for a cold nodule.",
        "points_fa": [
            "TSH اولین آزمایش هر ندول تیروئید است.",
            "اگر TSH طبیعی یا بالا بود سونوگرافی و در صورت اندیکاسیون FNA.",
            "ندول سرد شانس بدخیمی بیشتری دارد.",
            "ندول داغ را می‌توان با ید رادیواکتیو یا جراحی درمان کرد اگر پرکار باشد.",
            "متی‌مازول برای کنترل علامت است نه تشخیص ندول.",
            "استروئید در درد گردن و ESR بالای تیروئیدیت دکورون است.",
            "کلسیتونین روتین نیست مگر شک به مدولاری.",
            "اندازه ۳ سانتی به‌تنهایی FNA را جلو نمی‌اندازد وقتی TSH پایین است.",
            "بارداری اسکن را عوض می‌کند؛ اینجا مطرح نیست.",
            "سونوگرافی را هم بگیر ولی تصمیم بافت را اسکن مشخص می‌کند.",
        ],
        "points_en": [
            "TSH is the first test for every thyroid nodule.",
            "If TSH is normal or high, ultrasound and FNA if indicated.",
            "A cold nodule has a higher chance of cancer.",
            "A hot nodule can be treated with radioiodine or surgery if it is overactive.",
            "Methimazole is for symptom control, not for diagnosing a nodule.",
            "Steroid is for neck pain and a high ESR in de Quervain thyroiditis.",
            "Calcitonin is not routine unless you suspect medullary disease.",
            "A 3 cm size alone does not jump the queue to FNA when TSH is low.",
            "Pregnancy changes the scan plan; it is not in play here.",
            "Still get an ultrasound, but the scan decides about tissue.",
        ],
    },
    golden_fa="TSH پایین + ندول = اسکن. FNA نکن اول.",
    golden_en="Low TSH plus a nodule is a scan. Do not FNA first.",
    refs=["Harrison 21 — Thyroid nodule; ATA"],
    concept="low-tsh-scan", concept_fa="اسکن ندول با TSH پایین", concept_en="Scan first if TSH is low")

add("داخلی", 21,
    chapter_fa="آدرنال / آدیسون", chapter_en="Adrenal / Addison",
    options_why_fa=[
        "آنتی‌اسید تهوع و کاهش وزن و پیگمان را توضیح نمی‌دهد.",
        "بالا بردن لووتیروکسین قبل از رد نارسایی آدرنال می‌تواند بحران آدرنال بسازد.",
        "پاسخ صحیح — هیپرپیگمانتاسیون + کاهش وزن + تهوع در کم‌کاری تیروئید = کورتیزول صبحگاهی.",
        "مهار دگزامتازون برای کوشینگ است؛ اینجا تصویر نارسایی است نه زیادی.",
    ],
    options_why_en=[
        "An antacid does not explain nausea, weight loss and pigment.",
        "Raising levothyroxine before excluding adrenal failure can precipitate an adrenal crisis.",
        "Correct — hyperpigmentation plus weight loss plus nausea in hypothyroidism is an 8 a.m. cortisol.",
        "Dexamethasone suppression is for Cushing; this picture is failure, not excess.",
    ],
    explanation_fa=(
        "سندرم پلی‌گلاندولار خودایمن (اشمیت): هاشیموتو به‌علاوه آدیسون. مخاط پیگمانته "
        "ACTH بالا را فریاد می‌زند. اول کورتیزول صبح، بعد ACTH و در صورت نیاز تست سیناتن."
    ),
    explanation_en=(
        "Autoimmune polyglandular (Schmidt) syndrome: Hashimoto plus Addison. Pigmented "
        "mucosa shouts a high ACTH. First an 8 a.m. cortisol, then ACTH and a Synacthen test if needed."
    ),
    micro={
        "lead_fa": "کم‌کاری تیروئید + پیگمان + لاغری = آدیسون را رد کن قبل از زیاد کردن تیروکسین.",
        "lead_en": "Hypothyroidism plus pigment plus weight loss: exclude Addison before raising thyroxine.",
        "points_fa": [
            "هیپرپیگمانتاسیون مال نارسایی اولیه است نه ثانویه.",
            "کورتیزول صبح زیر ۳ تقریباً تشخیصی است؛ بالای ۱۵ رد می‌کند.",
            "بین این دو ACTH و Synacthen لازم است.",
            "درمان: هیدروکورتیزون و در اولیه فلودروکورتیزون.",
            "لووتیروکسین را بعد از استروئید شروع یا تنظیم کن.",
            "الکترولیت: سدیم پایین و پتاسیم بالا کلاسیک است.",
            "تست مهار دگزامتازون مال غربال کوشینگ است.",
            "تهوع مزمن در جوان با پیگمان زخم معده نیست.",
            "آنتی‌بادی ۲۱-هیدروکسیلاز تشخیص را حمایت می‌کند.",
            "کارت هشدار استروئید و آموزش استرس دوز بده.",
        ],
        "points_en": [
            "Hyperpigmentation is primary failure, not secondary.",
            "An 8 a.m. cortisol below 3 is almost diagnostic; above 15 excludes it.",
            "Between those, you need ACTH and Synacthen.",
            "Treat with hydrocortisone and, in primary disease, fludrocortisone.",
            "Start or adjust levothyroxine after steroid.",
            "Electrolytes: low sodium and high potassium are classic.",
            "Dexamethasone suppression screens for Cushing.",
            "Chronic nausea in a young adult with pigment is not a peptic ulcer.",
            "21-hydroxylase antibodies support the diagnosis.",
            "Give a steroid alert card and teach a stress dose.",
        ],
    },
    golden_fa="پیگمان + لاغری در هاشیموتو: کورتیزول ۸ صبح.",
    golden_en="Pigment plus weight loss in Hashimoto: 8 a.m. cortisol.",
    refs=["Harrison 21 — Adrenal insufficiency"],
    concept="schmidt-am-cortisol", concept_fa="کورتیزول صبح اشمیت", concept_en="Schmidt AM cortisol")

add("داخلی", 22,
    chapter_fa="دیابت / پایش", chapter_en="Diabetes / monitoring",
    options_why_fa=[
        "اگر کنترل خوب است HbA1c دو بار در سال کافی است نه چهار بار.",
        "در سالمند با عارضه هدف شل‌تر است نه time-in-range بالای ۷۰ درصد سخت.",
        "پاسخ صحیح — پروفایل لیپید یک تا دو بار در سال در دیابت توصیه می‌شود.",
        "آنتی‌پلاکت برای همه دیابتی‌ها نیست؛ فقط ASCVD یا خطر خیلی بالا.",
    ],
    options_why_en=[
        "This English line is the start of the elderly-target option; a tight time-in-range goal is wrong in a frail elder with complications.",
        "The ministry English booklet split the elderly option across two lines; time-in-range above 70% is not the frail-elder target.",
        "Correct — checking lipids 1–2 times a year is recommended.",
        "Antiplatelets are not for every diabetic; only those with ASCVD or very high risk.",
    ],
    explanation_fa=(
        "پایش استاندارد دیابت: HbA1c اگر پایدار باشد هر ۶ ماه، لیپید سالی یک تا دو بار، "
        "آلبومین ادرار سالانه، معاینه چشم. آسپرین اولیه برای همه منسوخ است."
    ),
    explanation_en=(
        "Standard diabetes monitoring: HbA1c every 6 months if stable, lipids once or twice "
        "a year, yearly urine albumin, eye exam. Primary aspirin for everyone is obsolete."
    ),
    micro={
        "lead_fa": "دیابت پایدار: A1c دو بار در سال، لیپید ۱–۲ بار. آسپرین برای همه نه.",
        "lead_en": "Stable diabetes: A1c twice a year, lipids 1–2 times. Aspirin is not for everyone.",
        "points_fa": [
            "A1c چهار بار مال تغییر درمان یا کنترل بد است.",
            "هدف سالمند شکننده اغلب A1c حدود ۷٫۵ تا ۸٫۵ است.",
            "استاتین در دیابت بالای ۴۰ تقریباً همیشگی است.",
            "لیپید را بعد از شروع استاتین دوباره چک کن.",
            "ضدپلاکت اولیه فقط اگر خطر ۱۰ ساله خیلی بالا باشد.",
            "فشار هدف معمولاً زیر ۱۳۰/۸۰ در قابل تحمل‌هاست.",
            "واکسن آنفلوانزا و پنوموکوک را فراموش نکن.",
            "پای دیابتی را هر ویزیت ببین.",
            "time-in-range ابزار CGM است نه هدف سالمند عارضه‌دار.",
            "متن انگلیسی دفترچه این سؤال جابه‌جا شکسته؛ گزینه درست همان لیپید است.",
        ],
        "points_en": [
            "A1c four times a year is for a change of therapy or poor control.",
            "A frail elder's target is often an A1c around 7.5–8.5.",
            "A statin is almost routine in diabetes after 40.",
            "Recheck lipids after starting a statin.",
            "Primary antiplatelet only if 10-year risk is very high.",
            "Blood-pressure target is usually under 130/80 if tolerated.",
            "Do not forget influenza and pneumococcal vaccines.",
            "Look at the diabetic foot every visit.",
            "Time-in-range is a CGM tool, not the frail-elder target.",
            "The English booklet splits this item awkwardly; the right choice is still lipids.",
        ],
    },
    golden_fa="پایش دیابت: لیپید ۱–۲ بار در سال درست است. آسپرین همگانی غلط است.",
    golden_en="Diabetes follow-up: lipids 1–2 times a year is right. Universal aspirin is wrong.",
    refs=["Harrison 21 — Diabetes mellitus; ADA Standards"],
    concept="dm-lipid-monitor", concept_fa="پایش لیپید دیابت", concept_en="Diabetes lipid monitoring")

add("داخلی", 23,
    chapter_fa="دیابت / دارو", chapter_en="Diabetes / drugs",
    options_why_fa=[
        "لیراگلوتاید در ASCVD خوب است ولی علائم گوارشی متفورمین را بدتر می‌کند.",
        "پاسخ صحیح — امپاگلیفلوزین سود قلبی ثابت دارد، وزن کم می‌کند و گوارش را اذیت نمی‌کند.",
        "پیوگلیتازون احتباس مایع می‌دهد و در بیماری قلبی اول نیست.",
        "لیناگلیپتین A1c را کم کم می‌آورد و سود قلبی SGLT2 را ندارد.",
    ],
    options_why_en=[
        "Liraglutide is good in ASCVD but would worsen this patient's metformin-type gut symptoms.",
        "Correct — empagliflozin has proven heart benefit, loses weight and does not upset the gut.",
        "Pioglitazone retains fluid and is not first in heart disease.",
        "Linagliptin drops A1c only a little and lacks the SGLT2 heart benefit.",
    ],
    explanation_fa=(
        "مرد ۵۲ ساله با بیماری قلبی، BMI ۳۲، A1c هشت و عدم تحمل گوارشی متفورمین. "
        "ADA در ASCVD افزودن SGLT2 یا GLP-1 را می‌خواهد. این‌جا SGLT2 منطقی‌تر است."
    ),
    explanation_en=(
        "A 52-year-old man with heart disease, BMI 32, A1c of 8 and metformin-type gut "
        "intolerance. ADA wants an SGLT2 or a GLP-1 in ASCVD. Here the SGLT2 is the cleaner add."
    ),
    micro={
        "lead_fa": "دیابت + ASCVD + نفخ متفورمین = امپاگلیفلوزین نه لیراگلوتاید.",
        "lead_en": "Diabetes plus ASCVD plus metformin bloating is empagliflozin, not liraglutide.",
        "points_fa": [
            "EMPA-REG مرگ قلبی را کم کرد.",
            "SGLT2 در نارسایی قلب و CKD هم سود دارد.",
            "عارضه: عفونت تناسلی و به‌ندرت کتواسیدوز نرمال‌قند.",
            "GLP-1 برای کاهش وزن قوی‌تر است ولی تهوع شایع است.",
            "DPP-4 خنثی قلبی و ضعیف است.",
            "TZD در نارسایی قلب ممنوع است.",
            "گلی‌کلازید سولفونیل‌اوره است و هیپوگلیسمی می‌دهد؛ نگهش دار مگر هیپو.",
            "کراتینین ۰٫۹ برای SGLT2 مناسب است.",
            "اگر ادم یا شکستگی اولویت داشت SGLT2 باز هم بهتر از پیو است.",
            "هدف A1c در این سن و ASCVD معمولاً زیر ۷ است.",
        ],
        "points_en": [
            "EMPA-REG cut cardiovascular death.",
            "SGLT2 also helps heart failure and CKD.",
            "Side effects: genital infection and rarely euglycaemic ketoacidosis.",
            "A GLP-1 is stronger for weight but nausea is common.",
            "A DPP-4 is heart-neutral and weak.",
            "A TZD is forbidden in heart failure.",
            "Gliclazide is a sulfonylurea and causes hypos; keep it unless he hypos.",
            "A creatinine of 0.9 is fine for an SGLT2.",
            "If oedema or fracture were the priority, SGLT2 still beats pio.",
            "The A1c target at this age with ASCVD is usually under 7.",
        ],
    },
    golden_fa="ASCVD + عدم تحمل گوارشی: SGLT2 (امپاگلیفلوزین).",
    golden_en="ASCVD plus gut intolerance: an SGLT2 (empagliflozin).",
    refs=["Harrison 21 — Diabetes; ADA / EMPA-REG"],
    concept="empa-ascvd", concept_fa="امپاگلیفلوزین در ASCVD", concept_en="Empagliflozin in ASCVD")

add("کودکان", 69,
    chapter_fa="پوست / درماتیت پوشک", chapter_en="Skin / diaper dermatitis",
    options_why_fa=[
        "پاسخ صحیح — بدون نشانه آلرژی غذایی، حذف لبنیات مادر کمترین اولویت را دارد.",
        "کاندیدا در پوشک شایع است و ضدقارچ اغلب لازم می‌شود.",
        "استروئید ضعیف التهاب تحریک تماسی را آرام می‌کند.",
        "آنتی‌هیستامین خوراکی خارش را کم می‌کند و در اگزما استفاده می‌شود.",
    ],
    options_why_en=[
        "Correct — without other food-allergy signs, stopping the mother's dairy is the least useful step.",
        "Candida is common in the diaper and an antifungal is often needed.",
        "A weak steroid calms irritant inflammation.",
        "An oral antihistamine cuts itch and is used in eczema.",
    ],
    explanation_fa=(
        "راش اگزمایی پوشک معمولاً تحریک + کاندیدا است. سد محافظ، ضدقارچ و استروئید ضعیف "
        "درمان‌اند. حذف شیر مادر بدون استفراغ و خون در مدفوع و درماتیت منتشر افراط است."
    ),
    explanation_en=(
        "An eczematous diaper rash is usually irritant plus candida. A barrier, an antifungal "
        "and a weak steroid are the treatment. Dropping the mother's milk without vomiting, "
        "blood in the stool or widespread dermatitis is overreach."
    ),
    micro={
        "lead_fa": "پوشک اگزمایی: ضدقارچ و استروئید ضعیف. لبنیات مادر را اول قطع نکن.",
        "lead_en": "Diaper eczema: antifungal and a weak steroid. Do not stop the mother's dairy first.",
        "points_fa": [
            "تحریک آمونیاک و رطوبت شایع‌ترین علت است.",
            "چین‌ها در کاندیدا درگیرند؛ در تحریک خالص چین‌ها سالم‌اند.",
            "ساتلایت پوسچول یعنی کاندیدا.",
            "هیدروکورتیزون یک درصد کوتاه‌مدت کافی است.",
            "استروئید قوی پوست پوشک را نازک می‌کند.",
            "تعویض مکرر و کرم زینک پایه است.",
            "CMPA معمولاً اسهال خونی یا کهیر منتشر دارد.",
            "آنتی‌هیستامین خواب‌آور در شیرخوار با احتیاط است ولی در گزینه‌ها از حذف لبنیات مفیدتر است.",
            "پسوریازیس پوشک مرز مشخص دارد.",
            "اگر ۳ هفته مقاوم شد به درماتیت سبورئیک و هیستوسیتوز فکر کن.",
        ],
        "points_en": [
            "Ammonia and wetness are the commonest cause.",
            "Folds are involved in candida; they are spared in pure irritant disease.",
            "Satellite pustules mean candida.",
            "One-percent hydrocortisone for a short time is enough.",
            "A strong steroid thins diaper skin.",
            "Frequent changes and zinc paste are the base.",
            "CMPA usually has bloody diarrhoea or widespread hives.",
            "A sedating antihistamine in an infant needs care, but it is still more useful here than dropping dairy.",
            "Diaper psoriasis has a sharp edge.",
            "If it lasts 3 weeks, think of seborrhoeic dermatitis and histiocytosis.",
        ],
    },
    golden_fa="کمترین کار در راش پوشک ایزوله: قطع لبنیات مادر.",
    golden_en="The least useful step in isolated diaper rash is stopping the mother's dairy.",
    refs=["Nelson — Diaper dermatitis"],
    concept="diaper-not-dairy", concept_fa="راش پوشک نه لبنیات", concept_en="Diaper rash not dairy")

add("کودکان", 70,
    chapter_fa="اعصاب / استاتوس", chapter_en="Neurology / status",
    options_why_fa=[
        "دیازپام رکتال بنزودیازپین استاندارد بدون رگ است.",
        "لورازپام داخل بینی جذب سریع دارد و توصیه می‌شود.",
        "میدازولام بوکال خط اول بسیاری از پروتکل‌های پیش‌بیمارستانی است.",
        "پاسخ صحیح — فنوباربیتال عضلانی جذب آهسته و غیرقابل‌پیش‌بینی دارد و قدم بعد نیست.",
    ],
    options_why_en=[
        "Rectal diazepam is the standard benzodiazepine when there is no drip.",
        "Intranasal lorazepam is absorbed fast and is advised.",
        "Buccal midazolam is first-line in many pre-hospital protocols.",
        "Correct — intramuscular phenobarbital is absorbed slowly and unpredictably and is not the next step.",
    ],
    explanation_fa=(
        "استاتوس بعد از ۱۵ دقیقه یعنی بنزودیازپین فوری. بدون رگ: رکتال، بوکال، داخل بینی "
        "یا میدازولام عضلانی. فنوباربیتال عضلانی برای این مرحله طراحی نشده؛ فنوباربیتال "
        "وریدی بعد از بنزودیازپین است."
    ),
    explanation_en=(
        "Status at 15 minutes means an immediate benzodiazepine. With no drip: rectal, "
        "buccal, intranasal or intramuscular midazolam. Intramuscular phenobarbital is not "
        "built for this step; intravenous phenobarbital comes after a benzodiazepine."
    ),
    micro={
        "lead_fa": "استاتوس بدون رگ: بنزودیازپین از هر راهی غیر از فنوباربیتال عضلانی.",
        "lead_en": "Status with no drip: a benzodiazepine by any route except intramuscular phenobarbital.",
        "points_fa": [
            "تعریف عملی: تشنج بیش از ۵ دقیقه یا تکرار بدون هوشیاری.",
            "ABC و اکسیژن همزمان با دارو.",
            "دوز میدازولام بوکال حدود ۰٫۳ تا ۰٫۵ میلی‌گرم بر کیلوگرم.",
            "دیازپام رکتال ۰٫۵ میلی‌گرم بر کیلوگرم.",
            "میدازولام عضلانی در RAMPART ثابت شده است.",
            "فنوباربیتال، فنی‌توئین و لوتیراستام خط دوم وریدی‌اند.",
            "گلوکز را در هر کودک چک کن.",
            "اگر تشنج از ۲۰–۳۰ دقیقه گذشت بیهوشی و ICU.",
            "فنوباربیتال عضلانی ذخیره Dilantin-era است و توصیه روز نیست.",
            "سؤال «بجز» یعنی سه تا درست‌اند.",
        ],
        "points_en": [
            "Working definition: a seizure over 5 minutes or repeats without waking.",
            "ABC and oxygen together with the drug.",
            "Buccal midazolam is about 0.3–0.5 mg/kg.",
            "Rectal diazepam is 0.5 mg/kg.",
            "Intramuscular midazolam is proven in RAMPART.",
            "Phenobarbital, phenytoin and levetiracetam are second-line intravenous drugs.",
            "Check glucose in every child.",
            "If the seizure passes 20–30 minutes, anaesthesia and ICU.",
            "Intramuscular phenobarbital is a Dilantin-era leftover and is not today's advice.",
            "An 'except' stem means three answers are right.",
        ],
    },
    golden_fa="استاتوس بدون IV: بنزودیازپین. فنوباربیتال عضلانی نه.",
    golden_en="Status without an IV: a benzodiazepine. Not intramuscular phenobarbital.",
    refs=["Nelson / APLS — Status epilepticus"],
    concept="status-no-im-phb", concept_fa="استاتوس بدون فنوباربیتال عضلانی", concept_en="Status not IM phenobarbital")

add("زنان و زایمان", 89,
    chapter_fa="رشد جنین / FGR زودرس", chapter_en="Fetal growth / early FGR",
    options_why_fa=[
        "FGR خیلی زود آنئوپلوئیدی شایع دارد؛ کاریوتایپ منطقی است.",
        "آنومالی اسکن ناهنجاری ساختاری را نشان می‌دهد.",
        "عفونت داخل‌رحمی (CMV و توکسو) علت کلاسیک FGR زودرس است.",
        "پاسخ صحیح — افزایش کالری مادر رشد پاتولوژیک هفته ۱۸ را درست نمی‌کند.",
    ],
    options_why_en=[
        "Very early FGR often has aneuploidy; a karyotype is reasonable.",
        "An anomaly scan shows a structural defect.",
        "Intrauterine infection (CMV and toxo) is a classic cause of early FGR.",
        "Correct — raising the mother's calories does not fix pathologic growth at 18 weeks.",
    ],
    explanation_fa=(
        "وزن زیر صدک ۳ در ۱۸ هفتگی FGR زودرس است نه جنین کوچک سالم. باید ژنتیک، "
        "آنومالی و عفونت را بجویید. رژیم پرکالری مال محدودیت دیررس خفیف یا مادر گرسنه است."
    ),
    explanation_en=(
        "Weight under the 3rd centile at 18 weeks is early FGR, not a healthy small fetus. "
        "Hunt genetics, anomalies and infection. Extra calories are for late mild restriction or a hungry mother."
    ),
    micro={
        "lead_fa": "FGR هفته ۱۸: کاریوتایپ و عفونت و آنومالی. کالری اضافی نه.",
        "lead_en": "FGR at 18 weeks: karyotype, infection and anomaly scan. Not extra calories.",
        "points_fa": [
            "زودرس یعنی قبل از ۳۲ هفته یا خیلی کوچک خیلی زود.",
            "علل: تریزومی، عفونت، نارسایی جفت شدید، ناهنجاری.",
            "داپلر شریان نافی و رحمی پیش‌آگهی را می‌گوید.",
            "CMV شایع‌ترین عفونت مادرزادی مرتبط است.",
            "آمنیوسنتز هم کاریوتایپ هم PCR عفونت می‌دهد.",
            "NIPT جایگزین آمنیوسنتز تشخیصی نیست.",
            "کالری مادر وزن جنین پاتولوژیک را بالا نمی‌برد.",
            "ترک سیگار در هر سنی مفید است ولی اینجا گزینه نیست.",
            "تصمیم ختم به سن، داپلر و NST بستگی دارد.",
            "سؤال بجز یعنی سه کار درست‌اند.",
        ],
        "points_en": [
            "Early means before 32 weeks or very small very soon.",
            "Causes: trisomy, infection, severe placental failure, malformation.",
            "Umbilical and uterine Doppler tell the outlook.",
            "CMV is the commonest linked congenital infection.",
            "Amniocentesis gives both karyotype and infection PCR.",
            "NIPT does not replace diagnostic amniocentesis.",
            "Maternal calories do not lift pathologic fetal weight.",
            "Stopping smoking helps at any age but is not an option here.",
            "When to deliver depends on age, Doppler and the NST.",
            "An except stem means three actions are right.",
        ],
    },
    golden_fa="FGR خیلی زود: بررسی علت. کالری مادر را زیاد نکن به‌عنوان درمان.",
    golden_en="Very early FGR: find the cause. Do not treat it with extra maternal calories.",
    refs=["Williams — Fetal growth restriction"],
    concept="early-fgr-not-calories", concept_fa="FGR زودرس نه کالری", concept_en="Early FGR not calories")

add("زنان و زایمان", 90,
    chapter_fa="جفت سرراهی", chapter_en="Placenta previa",
    options_why_fa=[
        "پاسخ صحیح — جفت سرراهی در ۳۷ هفته و یک روز یعنی سزارین همین حالا.",
        "بتامتازون بعد از ۳۷ هفته سودی ندارد؛ ریه رسیده است.",
        "زایمان واژینال با جفت سرراهی ممنوع است.",
        "صبر تا ۳۹ هفته خطر خونریزی شدید را بی‌دلیل نگه می‌دارد.",
    ],
    options_why_en=[
        "Correct — placenta previa at 37 weeks and 1 day means caesarean now.",
        "Betamethasone after 37 weeks does not help; the lungs are mature.",
        "A vaginal birth with previa is forbidden.",
        "Waiting to 39 weeks leaves a needless risk of heavy bleeding.",
    ],
    explanation_fa=(
        "ACOG سزارین برنامه‌ریزی‌شده جفت سرراهی را ۳۶ تا ۳۷ هفته و ۶ روز می‌گذارد. "
        "این مادر از پنجره گذشته؛ باید ختم شود. استروئید ترم لازم نیست."
    ),
    explanation_en=(
        "ACOG schedules caesarean for placenta previa at 36 to 37 weeks and 6 days. "
        "This mother is past that window; she should be delivered. Term steroid is not needed."
    ),
    micro={
        "lead_fa": "پرویا در ۳۷ به‌علاوه ۱: سزارین. استروئید و انتظار نه.",
        "lead_en": "Previa at 37 plus 1: caesarean. No steroid and no waiting.",
        "points_fa": [
            "پرویا یعنی جفت روی سوراخ داخلی سرویکس.",
            "علامت کلاسیک: خون قرمز بی‌درد در سه ماهه سوم.",
            "تشخیص با سونوگرافی ترانس‌واژینال است نه معاینه انگشتی.",
            "معاینه دیجیتال می‌تواند خونریزی катастроفه بسازد.",
            "پنجره ترم زودرس برای پرویا پایدار بدون خونریزی: ۳۶+۰ تا ۳۷+۶.",
            "اگر خونریزی فعال یا درد باشد زودتر سزارین کن.",
            "استروئید تا ۳۴ هفته (گاهی ۳۶+۶ در موارد انتخابی) است نه ۳۷+۱.",
            "جفت سرراهی + سزارین قبلی = شک به آکرتا.",
            "ذخیره خون و تیم آماده واجب است.",
            "زایمان قبلی واژینال پرویا را واژینال نمی‌کند.",
        ],
        "points_en": [
            "Previa means the placenta covers the internal os.",
            "Classic sign: painless bright blood in the third trimester.",
            "Diagnose with transvaginal ultrasound, not a digital exam.",
            "A digital exam can cause catastrophic bleeding.",
            "The early-term window for stable unbleeding previa is 36+0 to 37+6.",
            "If there is active bleeding or pain, caesarean sooner.",
            "Steroid is to 34 weeks (sometimes 36+6 in selected cases), not 37+1.",
            "Previa plus a prior caesarean means think of accreta.",
            "Blood on standby and a ready team are mandatory.",
            "A prior vaginal birth does not make previa vaginal.",
        ],
    },
    golden_fa="جفت سرراهی ترم: سزارین الان. بتامتازون ۳۷ هفته لازم نیست.",
    golden_en="Term previa: caesarean now. Betamethasone is not needed at 37 weeks.",
    refs=["Williams / ACOG — Placenta previa"],
    concept="previa-37-cs", concept_fa="سزارین پرویا ۳۷ هفته", concept_en="Previa CS at 37 weeks")


def apply():
    files = sorted(glob.glob(os.path.join(HERE, "import-payload.archive.part*.json")))
    n = 0
    for path in files:
        body = json.load(open(path, encoding="utf-8"))
        changed = False
        for q in body["questions"]:
            if int(q.get("year_num") or 0) != 1402:
                continue
            rec = L.get((q["subject_fa"], q["question_no"])) or L.get((q["subject_fa"], int(q.get("question_no") or 0)))
            if not rec:
                continue
            for k in ("chapter_fa", "chapter_en", "options_why_fa", "options_why_en",
                      "explanation_fa", "explanation_en", "micro", "golden_fa", "golden_en",
                      "refs", "concept", "concept_fa", "concept_en"):
                q[k] = rec[k]
            q["needs_lesson"] = False
            q["lesson_part"] = 1
            if rec.get("key_corrected"):
                q["original_correct_index"] = rec["original_correct_index"]
                q["correct_index"] = rec["correct_index"]
                q["key_corrected"] = True
                q["key_correction_fa"] = rec["key_correction_fa"]
                q["key_correction_en"] = rec["key_correction_en"]
                q["key_correction_source"] = rec["key_correction_source"]
            n += 1
            changed = True
        if changed:
            json.dump(body, open(path, "w", encoding="utf-8"), ensure_ascii=False)
    print(f"applied lessons to {n} Khordad-1402 questions")
    print("keys:", ", ".join(f"{s} q{no}" for s, no in sorted(L)))


if __name__ == "__main__":
    apply()
