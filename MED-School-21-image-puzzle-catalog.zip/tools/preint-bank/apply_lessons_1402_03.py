# -*- coding: utf-8 -*-
"""Attach complete bilingual microlessons to Khordad-1402 official items.

Covers: internal Q1–Q10, infectious Q103–Q108, neurology Q97–Q102.
Official English from the ministry booklet is never rewritten.
Two printed keys are corrected against Harrison / Aminoff (Q8, Q10).
Q102 Persian options are restored from the official English four-way split.
"""
import json, glob, os, copy

HERE = os.path.dirname(os.path.abspath(__file__))

# (subject_fa, no) -> lesson fields
L = {}


def add(subj, no, **kw):
    L[(subj, no)] = kw


# ─────────────────────────── INTERNAL 1–10 ───────────────────────────
add("داخلی", 1,
    chapter_fa="گوارش", chapter_en="Gastroenterology",
    options_why_fa=[
        "رژیم سه‌گانه‌ی کلاریترومایسین پس از ماکرولید اخیر شکست می‌خورد؛ مقاومت القا شده است.",
        "چهارگانه با کلاریترومایسین هنوز ماکرولید دارد و همان مقاومت را دور نمی‌زند.",
        "پاسخ صحیح — چهارگانه‌ی بیسموت خط اول پس از مواجهه با ماکرولید است.",
        "ریفابوتین رژیم نجات است، نه خط اول در بیماری که هرگز درمان ریشه‌کنی نگرفته.",
    ],
    options_why_en=[
        "Clarithromycin triple therapy fails after a recent macrolide; resistance has been induced.",
        "A clarithromycin-containing quadruple still uses a macrolide and does not bypass that resistance.",
        "Correct — bismuth quadruple is first-line after macrolide exposure.",
        "Rifabutin is salvage, not first-line in a patient never treated for eradication.",
    ],
    explanation_fa=(
        "سؤال دو قید دارد: آنتی‌ژن مدفوع هلیکوباکتر مثبت است پس عفونت فعال است، "
        "و سه ماه پیش آزیترومایسین گرفته. ماکرولیدها مقاومت متقاطع دارند؛ "
        "کلاریترومایسین پس از آزیترومایسین عملاً بی‌اثر می‌شود. خط اول در این حالت "
        "چهارگانه‌ی بیسموت است: بیسموت + تتراسیکلین + مترونیدازول + PPI. "
        "ریفابوتین برای شکست‌های مکرر نگه داشته می‌شود."
    ),
    explanation_en=(
        "Two constraints: a positive stool antigen means active infection, and "
        "azithromycin three months ago. Macrolides cross-resist, so clarithromycin "
        "after azithromycin is effectively useless. First-line is then bismuth "
        "quadruple: bismuth, tetracycline, metronidazole and a PPI. Rifabutin is "
        "reserved for repeated failures."
    ),
    micro={
        "lead_fa": "ماکرولید اخیر = کلاریترومایسین را کنار بگذار. خط اول: چهارگانه‌ی بیسموت.",
        "lead_en": "A recent macrolide retires clarithromycin. First-line is bismuth quadruple.",
        "points_fa": [
            "آنتی‌ژن مدفوع هلیکوباکتر عفونت فعال را نشان می‌دهد، نه فقط مواجهه‌ی گذشته.",
            "سرولوژی این کار را نمی‌کند و پس از ریشه کنی مدت‌ها مثبت می‌ماند.",
            "آزیترومایسین و کلاریترومایسین مقاومت متقاطع دارند.",
            "پس از هر ماکرولید اخیر، رژیم سه‌گانه‌ی کلاریترومایسین خط اول نیست.",
            "چهارگانه‌ی بیسموت: بیسموت ساب‌سیترات + تتراسیکلین + مترونیدازول + PPI.",
            "مدت معمول ۱۴ روز است و PPI باید دوز کامل باشد.",
            "ریفابوتین رژیم نجات پس از شکست‌های مکرر است.",
            "پس از درمان، ریشه کنی را با آنتی‌ژن مدفوع یا UBT چهار هفته بعد تأیید کنید.",
            "بیسموت مدفوع را سیاه می‌کند؛ این عارضه است نه خونریزی.",
            "تتراسیکلین در بارداری و کودکان ممنوع است.",
        ],
        "points_en": [
            "H. pylori stool antigen indicates active infection, not merely past exposure.",
            "Serology cannot do that job and stays positive long after eradication.",
            "Azithromycin and clarithromycin share cross-resistance.",
            "After any recent macrolide, clarithromycin triple therapy is not first-line.",
            "Bismuth quadruple: bismuth subcitrate + tetracycline + metronidazole + a PPI.",
            "The usual course is 14 days and the PPI must be full-dose.",
            "Rifabutin is salvage after repeated failures.",
            "Confirm eradication with stool antigen or UBT four weeks after treatment.",
            "Bismuth turns the stool black; that is a side-effect, not bleeding.",
            "Tetracycline is contraindicated in pregnancy and in children.",
        ],
    },
    golden_fa="ماکرولید اخیر → چهارگانه‌ی بیسموت ۱۴ روز. ریفابوتین = نجات.",
    golden_en="Recent macrolide → 14-day bismuth quadruple. Rifabutin is salvage.",
    refs=["Harrison's 21st ed — H. pylori and peptic ulcer disease"],
    concept="gi-hpylori", concept_fa="ریشه کنی هلیکوباکتر پس از ماکرولید",
    concept_en="H. pylori eradication after a macrolide")

add("داخلی", 2,
    chapter_fa="گوارش", chapter_en="Gastroenterology",
    options_why_fa=[
        "آندوسکوپی برای زنگ خطر یا سن بالا است؛ بیمار ۳۲ ساله و بدون زنگ خطر است.",
        "پاسخ صحیح — دیس‌پپسی بدون زنگ خطر در جوان، درمان تجربی مهار اسید است.",
        "سرولوژی هلیکوباکتر منفی است؛ ریشه کنی تجربی بی‌مورد است.",
        "UBT وقتی لازم است که بخواهیم عفونت را ثابت کنیم؛ سرولوژی همین حالا منفی است و تابلو زنگ خطر ندارد.",
    ],
    options_why_en=[
        "Endoscopy is for alarm features or older age; she is 32 with none.",
        "Correct — uninvestigated dyspepsia without alarm in a young adult is empirical acid suppression.",
        "H. pylori serology is already negative, so empirical eradication is pointless.",
        "UBT is for proving infection; serology is already negative and there are no alarms.",
    ],
    explanation_fa=(
        "دیس‌پپسی بدون زنگ خطر در فرد زیر شصت سال نیاز به آندوسکوپی فوری ندارد. "
        "زنگ خطرها کاهش وزن، دیسفاژی، خونریزی، آنمی و سابقه‌ی خانوادگی سرطان معده هستند؛ "
        "هیچ‌کدام اینجا نیست. سابقه‌ی زخم NSAID در مادر سرطان نیست. سرولوژی منفی است "
        "پس ریشه کنی تجربی غلط است. درمان تجربی با مهارکننده‌ی اسید (اینجا فاموتیدین) "
        "گام اول منطقی است."
    ),
    explanation_en=(
        "Dyspepsia without alarm features in someone under sixty does not need "
        "immediate endoscopy. Alarms are weight loss, dysphagia, bleeding, anaemia "
        "and a family history of gastric cancer; none are present. A mother's NSAID "
        "ulcer is not gastric cancer. Serology is negative so empirical eradication "
        "is wrong. Empirical acid suppression (here famotidine) is the first step."
    ),
    micro={
        "lead_fa": "دیس‌پپسی جوان بدون زنگ خطر = مهار اسید تجربی، نه آندوسکوپی و نه ریشه کنی کور.",
        "lead_en": "Young dyspepsia without alarms means empirical acid suppression, not endoscopy or blind eradication.",
        "points_fa": [
            "زنگ خطر دیس‌پپسی: کاهش وزن، دیسفاژی، اودینوفاژی، خونریزی، آنمی، استفراغ مداوم.",
            "سابقه‌ی خانوادگی سرطان معده در بستگان درجه یک هم زنگ خطر است.",
            "زخم NSAID مادر سرطان معده نیست و آندوسکوپی را واجب نمی‌کند.",
            "در کمتر از شصت سال بدون زنگ خطر، آندوسکوپی خط اول نیست.",
            "سرولوژی هلیکوباکتر مواجهه‌ی گذشته را نشان می‌دهد و پس از درمان مثبت می‌ماند.",
            "اینجا سرولوژی منفی است، پس ریشه کنی تجربی جایی ندارد.",
            "مهار اسید تجربی با PPI یا آنتاگونیست H2 گام اول است.",
            "اگر پاسخ نداد، آن‌گاه UBT یا آندوسکوپی مطرح می‌شود.",
            "سیری زودرس به‌تنهایی زنگ خطر نیست مگر با کاهش وزن همراه شود.",
        ],
        "points_en": [
            "Dyspepsia alarms: weight loss, dysphagia, odynophagia, bleeding, anaemia, persistent vomiting.",
            "A first-degree family history of gastric cancer is also an alarm.",
            "A mother's NSAID ulcer is not gastric cancer and does not mandate endoscopy.",
            "Under sixty without alarms, endoscopy is not first-line.",
            "H. pylori serology reflects past exposure and stays positive after treatment.",
            "Serology is already negative, so empirical eradication has no role.",
            "Empirical acid suppression with a PPI or H2-blocker is the first step.",
            "If that fails, then UBT or endoscopy comes into play.",
            "Early satiety alone is not an alarm unless weight loss accompanies it.",
        ],
    },
    golden_fa="زیر ۶۰ + بدون زنگ خطر = مهار اسید تجربی. سرولوژی منفی = ریشه کنی نده.",
    golden_en="Under 60 plus no alarms = empirical acid suppression. Negative serology = do not eradicate.",
    refs=["Harrison's 21st ed — Approach to dyspepsia"],
    concept="gi-dyspepsia", concept_fa="دیس‌پپسی بدون زنگ خطر",
    concept_en="Dyspepsia without alarm features")

add("داخلی", 3,
    chapter_fa="گوارش", chapter_en="Gastroenterology",
    options_why_fa=[
        "پاسخ صحیح — HBsAg منفی + Anti-HBc IgM مثبت = پنجره‌ی حاد هپاتیت B.",
        "سویه‌ی precore معمولاً HBeAg منفی است ولی HBsAg مثبت می‌ماند.",
        "ناقل HBsAg مثبت و آنزیم طبیعی دارد، نه هپاتیت حاد با ALT پانصد.",
        "بهبودی Anti-HBs مثبت و IgM منفی است.",
    ],
    options_why_en=[
        "Correct — HBsAg negative plus Anti-HBc IgM positive is the acute hepatitis B window.",
        "A precore mutant is usually HBeAg-negative but remains HBsAg-positive.",
        "A carrier is HBsAg-positive with normal enzymes, not an ALT of 500.",
        "Recovery is Anti-HBs positive and IgM negative.",
    ],
    explanation_fa=(
        "ALT و AST چند صد واحد با بیلی‌روبین مستقیم یعنی هپاتیت حاد هپاتوسلولار. "
        "HAV و HCV منفی‌اند. الگوی HBV این است: HBsAg منفی، Anti-HBc IgM مثبت. "
        "این همان پنجره‌ی تشخیصی حاد است که آنتی‌ژن سطحی از سرم پاک شده و هنوز "
        "Anti-HBs ظاهر نشده. Precore HBsAg را منفی نمی‌کند. ناقل و بهبودی این "
        "آنزیم‌ها و این IgM را نمی‌سازند."
    ),
    explanation_en=(
        "ALT and AST in the hundreds with conjugated bilirubin mean acute "
        "hepatocellular hepatitis. HAV and HCV are negative. The HBV pattern is "
        "HBsAg negative and Anti-HBc IgM positive: the acute diagnostic window, "
        "when surface antigen has cleared and Anti-HBs has not yet appeared. "
        "A precore mutant does not make HBsAg vanish. A carrier or recovery "
        "cannot produce these enzymes and this IgM."
    ),
    micro={
        "lead_fa": "HBsAg− و Anti-HBc IgM+ = پنجره‌ی هپاتیت B حاد. آنزیم بالا را با ناقل اشتباه نگیرید.",
        "lead_en": "HBsAg− plus Anti-HBc IgM+ is the acute hepatitis B window. Do not confuse high enzymes with a carrier.",
        "points_fa": [
            "هپاتیت حاد: ALT/AST چند صد تا چند هزار، بیلی‌روبین متغیر.",
            "Anti-HBc IgM نشانه‌ی عفونت حاد یا شعله‌وری اخیر است.",
            "پنجره: HBsAg رفته و Anti-HBs هنوز نیامده؛ فقط IgM هست.",
            "ناقل مزمن: HBsAg مثبت، آنزیم طبیعی، IgM منفی.",
            "بهبودی: Anti-HBs مثبت، HBsAg منفی، IgM منفی.",
            "سویه‌ی precore HBeAg نمی‌سازد ولی HBsAg را حفظ می‌کند.",
            "سونوگرافی طبیعی انسداد صفراوی خارج‌کبدی را کنار می‌گذارد.",
            "AlkP فقط کمی بالا یعنی الگوی هپاتوسلولار است نه کلستاتیک.",
        ],
        "points_en": [
            "Acute hepatitis: ALT/AST in the hundreds to thousands, variable bilirubin.",
            "Anti-HBc IgM marks acute infection or a recent flare.",
            "The window: HBsAg gone, Anti-HBs not yet present; only IgM remains.",
            "Chronic carrier: HBsAg positive, normal enzymes, IgM negative.",
            "Recovery: Anti-HBs positive, HBsAg negative, IgM negative.",
            "A precore mutant makes no HBeAg but keeps HBsAg.",
            "A normal ultrasound excludes extrahepatic biliary obstruction.",
            "Only mildly raised ALP means a hepatocellular, not cholestatic, pattern.",
        ],
    },
    golden_fa="پنجره‌ی HBV: HBsAg− / Anti-HBc IgM+ / Anti-HBs−.",
    golden_en="HBV window: HBsAg− / Anti-HBc IgM+ / Anti-HBs−.",
    refs=["Harrison's 21st ed — Acute viral hepatitis"],
    concept="gi-hbv", concept_fa="پنجره‌ی سرولوژیک هپاتیت B",
    concept_en="Hepatitis B serologic window")

add("داخلی", 4,
    chapter_fa="گوارش", chapter_en="Gastroenterology",
    options_why_fa=[
        "پاسخ صحیح — خون روشن مقعدی با شوک یعنی تا ثابت نشود خونریزی فوقانی شدید است؛ اول آندوسکوپی فوقانی.",
        "کولونوسکوپی در بیمار ناپایدار و بدون آمادگی روده خطرناک و کم‌بازده است.",
        "رکتوسیگموئیدوسکوپی منبع پروگزیمال و خونریزی فوقانی را از دست می‌دهد.",
        "CT آنژیو وقتی است که آندوسکوپی منبع را پیدا نکرده یا بیمار برای آندوسکوپی مناسب نیست.",
    ],
    options_why_en=[
        "Correct — bright red rectal blood with shock is massive upper bleeding until proven otherwise; upper endoscopy first.",
        "Colonoscopy in an unstable, unprepped patient is dangerous and low-yield.",
        "Rectosigmoidoscopy misses a proximal source and any upper bleed.",
        "CT angiography is for when endoscopy has failed or the patient cannot be scoped.",
    ],
    explanation_fa=(
        "هماتوشزی با شوک (فشار ۸۵ و نبض ۱۱۵) تا خلافش ثابت نشود خونریزی گوارشی "
        "فوقانی حجیم است؛ خون آن‌قدر سریع می‌آید که فرصت ملنا شدن ندارد. BUN بالا "
        "نسبت به کراتینین همین را تقویت می‌کند. پس پس از احیا، اولین اقدام تشخیصی "
        "آندوسکوپی فوقانی است نه کولونوسکوپی."
    ),
    explanation_en=(
        "Hematochezia with shock (BP 85, pulse 115) is massive upper GI bleeding "
        "until proven otherwise; blood transits too fast to become melaena. A BUN "
        "high relative to creatinine supports that. After resuscitation the first "
        "diagnostic step is upper endoscopy, not colonoscopy."
    ),
    micro={
        "lead_fa": "خون روشن + شوک = خونریزی فوقانی حجیم تا خلاف آن ثابت شود → آندوسکوپی فوقانی.",
        "lead_en": "Bright red blood plus shock is massive upper bleeding until proven otherwise → upper endoscopy.",
        "points_fa": [
            "هماتوشزی معمولاً منبع تحتانی است مگر با ناپایداری همودینامیک همراه شود.",
            "در شوک، خون فوقانی آن‌قدر سریع می‌رسد که ملنا نمی‌شود.",
            "نسبت BUN به کراتینین بالا به نفع منبع فوقانی است.",
            "اول احیا، بعد آندوسکوپی فوقانی در ۱۲ ساعت.",
            "کولونوسکوپی در بیمار ناپایدار بدون آمادگی روده خطرناک است.",
            "CT آنژیو برای خونریزی مداوم پس از آندوسکوپی منفی است.",
            "اریترومایسین پیش از آندوسکوپی معده را خالی می‌کند و دید را بهتر می‌کند.",
        ],
        "points_en": [
            "Hematochezia is usually lower unless it comes with haemodynamic instability.",
            "In shock, upper blood transits too fast to become melaena.",
            "A high BUN-to-creatinine ratio favours an upper source.",
            "Resuscitate first, then upper endoscopy within 12 hours.",
            "Colonoscopy in an unstable, unprepped patient is dangerous.",
            "CT angiography is for ongoing bleeding after a negative endoscopy.",
            "Erythromycin before endoscopy empties the stomach and improves the view.",
        ],
    },
    golden_fa="هماتوشزی + شوک → آندوسکوپی فوقانی، نه کولونوسکوپی.",
    golden_en="Hematochezia plus shock → upper endoscopy, not colonoscopy.",
    refs=["Harrison's 21st ed — GI bleeding"],
    concept="gi-bleed", concept_fa="هماتوشزی در شوک",
    concept_en="Hematochezia in shock")

add("داخلی", 5,
    chapter_fa="گوارش", chapter_en="Gastroenterology",
    options_why_fa=[
        "پاسخ صحیح — پس از احیای مایع، قدم تشخیصی اسهال حاد عفونی کشت و بررسی میکروبی مدفوع است.",
        "سونوگرافی در اسهال آبکی حاد بدون شکم حاد چیزی اضافه نمی‌کند.",
        "کالپروتکتین برای افتراق IBD مزمن است نه اسهال سه‌روزه.",
        "کولونوسکوپی در اسهال حاد بدون خون و بدون ایمنی مختل خط اول نیست.",
    ],
    options_why_en=[
        "Correct — after fluids, the diagnostic step in acute infectious diarrhoea is stool microbiology.",
        "Ultrasound adds nothing in acute watery diarrhoea without an acute abdomen.",
        "Calprotectin separates chronic IBD, not a three-day illness.",
        "Colonoscopy is not first-line in acute diarrhoea without blood or immunosuppression.",
    ],
    explanation_fa=(
        "سالمند با اسهال آبکی حاد و دهیدراتاسیون: اول مایع، بعد تشخیص علت عفونی. "
        "کشت و آزمون‌های میکروبی مدفوع (از جمله بررسی کلستریدیوئیدس دیفیسیل در "
        "بیمار بستری/سالمند) قدم درست است. کالپروتکتین و کولونوسکوپی مال بیماری "
        "مزمن‌اند."
    ),
    explanation_en=(
        "An older adult with acute watery diarrhoea and dehydration: fluids first, "
        "then an infectious work-up. Stool microbiology (including C. difficile in "
        "the elderly or hospitalised) is the right next test. Calprotectin and "
        "colonoscopy belong to chronic disease."
    ),
    micro={
        "lead_fa": "اسهال حاد پس از مایع = میکروبیولوژی مدفوع. کالپروتکتین مال مزمن است.",
        "lead_en": "Acute diarrhoea after fluids = stool microbiology. Calprotectin is for chronic disease.",
        "points_fa": [
            "در اسهال حاد اول وضعیت حجم را اصلاح کنید.",
            "سپس اگر اسهال شدید، خونی، یا در سالمند/ایمنی‌نقص است، مدفوع را بفرستید.",
            "در سالمند بستری همیشه C. difficile را هم در نظر بگیرید.",
            "کالپروتکتین مارکر التهاب مزمن روده‌ای است.",
            "کولونوسکوپی در هفته‌ی اول اسهال آبکی به‌ندرت لازم است.",
        ],
        "points_en": [
            "In acute diarrhoea correct the volume status first.",
            "Then if diarrhoea is severe, bloody, or in the elderly/immunocompromised, send stool.",
            "In a hospitalised older adult always consider C. difficile as well.",
            "Calprotectin is a marker of chronic intestinal inflammation.",
            "Colonoscopy is rarely needed in the first week of watery diarrhoea.",
        ],
    },
    golden_fa="اسهال حاد: مایع، بعد مدفوع. کالپروتکتین و کولونوسکوپی برای بعد.",
    golden_en="Acute diarrhoea: fluids, then stool. Calprotectin and colonoscopy come later.",
    refs=["Harrison's 21st ed — Acute infectious diarrhoea"],
    concept="gi-diarrhea", concept_fa="اسهال حاد سالمند",
    concept_en="Acute diarrhoea in the elderly")

add("داخلی", 6,
    chapter_fa="گوارش", chapter_en="Gastroenterology",
    options_why_fa=[
        "درد راجعه هفته‌ای یک‌بار با معیار روم سازگار است.",
        "تغییر دفعات دفع یکی از معیارهای روم ۴ است.",
        "پاسخ صحیح — اسهال شبانه ارگانیک است و IBS را رد می‌کند.",
        "بهبود درد با دفع جزء معیار روم است.",
    ],
    options_why_en=[
        "Pain once a week fits Rome criteria.",
        "A change in stool frequency is a Rome IV criterion.",
        "Correct — nocturnal diarrhoea is organic and excludes IBS.",
        "Pain easing with defecation is a Rome criterion.",
    ],
    explanation_fa=(
        "IBS تشخیص ایجابی با روم ۴ است اما چند پرچم قرمز آن را باطل می‌کند: "
        "اسهال شبانه، خون، کاهش وزن، آنمی، شروع بعد از پنجاه سال. اسهال شبانه "
        "یعنی بیماری بیمار را از خواب بیدار می‌کند و کارکردی نیست."
    ),
    explanation_en=(
        "IBS is a positive Rome IV diagnosis, but red flags void it: nocturnal "
        "diarrhoea, blood, weight loss, anaemia, onset after fifty. Nocturnal "
        "diarrhoea means the disease wakes the patient and is not functional."
    ),
    micro={
        "lead_fa": "اسهال شبانه = ارگانیک. IBS بیمار را از خواب بیدار نمی‌کند.",
        "lead_en": "Nocturnal diarrhoea is organic. IBS does not wake the patient.",
        "points_fa": [
            "روم ۴: درد راجعه حداقل یک روز در هفته در سه ماه اخیر.",
            "همراه با دو مورد از: ارتباط با دفع، تغییر دفعات، تغییر قوام.",
            "پرچم قرمز: خون، کاهش وزن، آنمی، اسهال شبانه، شروع دیرهنگام.",
            "اسهال شبانه به نفع IBD، مال‌جذب یا عفونت مزمن است.",
            "IBS تشخیص حذف نیست؛ باید معیار داشته باشد و پرچم قرمز نداشته باشد.",
        ],
        "points_en": [
            "Rome IV: recurrent pain at least one day a week in the last three months.",
            "Plus two of: related to defecation, change in frequency, change in form.",
            "Red flags: blood, weight loss, anaemia, nocturnal diarrhoea, late onset.",
            "Nocturnal diarrhoea favours IBD, malabsorption or chronic infection.",
            "IBS is not a diagnosis of exclusion; it needs criteria and no red flags.",
        ],
    },
    golden_fa="IBS بیدار نمی‌کند. اسهال شبانه را ارگانیک بگیرید.",
    golden_en="IBS does not wake people. Treat nocturnal diarrhoea as organic.",
    refs=["Harrison's 21st ed — Irritable bowel syndrome"],
    concept="gi-ibs", concept_fa="رد IBS با اسهال شبانه",
    concept_en="Excluding IBS by nocturnal diarrhoea")

add("داخلی", 7,
    chapter_fa="خون", chapter_en="Hematology",
    options_why_fa=[
        "همولیز ایمنی رتیکولوسیت بالا و بیلی‌روبین غیرمستقیم می‌دهد.",
        "هموگلوبینوپاتی هم همولیز با MCV طبیعی می‌سازد.",
        "پاسخ صحیح — کمبود B12 مگالوبلاستیک است: MCV بالا و رتیکولوسیت پایین یا طبیعی، نه ۱۴٪.",
        "کمبود G6PD همولیز حاد با رتیکولوسیت بالا می‌دهد.",
    ],
    options_why_en=[
        "Immune haemolysis produces a high reticulocyte count and unconjugated bilirubin.",
        "A haemoglobinopathy also causes haemolysis with a normal MCV.",
        "Correct — B12 deficiency is megaloblastic: high MCV and a low or normal reticulocyte count, not 14%.",
        "G6PD deficiency causes acute haemolysis with a high reticulocyte count.",
    ],
    explanation_fa=(
        "Hb ۶، رتیکولوسیت ۱۴٪، بیلی‌روبین غیرمستقیم ۷ و MCV ۹۲ یعنی همولیز "
        "نورموسیتیک. کمبود B12 گلبول درشت و تولید ناکافی می‌سازد، نه همولیز "
        "با رتیکولوسیت دورقمی. پس B12 با این تابلو جور نیست."
    ),
    explanation_en=(
        "Hb 6, reticulocytes 14%, unconjugated bilirubin 7 and MCV 92 mean "
        "normocytic haemolysis. B12 deficiency makes large cells and under-production, "
        "not double-digit reticulocytes. So B12 does not fit."
    ),
    micro={
        "lead_fa": "رتیکولوسیت بالا + بیلی‌روبین غیرمستقیم = همولیز. B12 این را نمی‌سازد.",
        "lead_en": "High reticulocytes plus unconjugated bilirubin mean haemolysis. B12 does not do that.",
        "points_fa": [
            "همولیز: LDH بالا، هاپتوگلوبین پایین، بیلی‌روبین غیرمستقیم، رتیکولوسیت بالا.",
            "ادرار چای‌رنگ می‌تواند هموگلوبینوری همولیز داخل‌عروقی باشد.",
            "کمبود B12: MCV معمولاً بیش از ۱۱۰، رتیکولوسیت پایین.",
            "نوتروپنی و ترومبوسیتوپنی خفیف در B12 شایع است؛ اینجا پلاکت و WBC طبیعی‌اند.",
            "سؤال «مطرح نیست» یعنی گزینه‌ای که مکانیسمش تولید است نه تخریب.",
        ],
        "points_en": [
            "Haemolysis: high LDH, low haptoglobin, unconjugated bilirubin, high reticulocytes.",
            "Tea-coloured urine can be haemoglobinuria from intravascular haemolysis.",
            "B12 deficiency: MCV usually over 110, reticulocytes low.",
            "Mild neutropenia and thrombocytopenia are common in B12; here platelets and WBC are normal.",
            "A 'which is NOT' question wants the option whose mechanism is under-production, not destruction.",
        ],
    },
    golden_fa="رتیک ۱۴٪ + MCV طبیعی = همولیز. B12 مگالوبلاستیک است.",
    golden_en="Retic 14% plus normal MCV is haemolysis. B12 is megaloblastic.",
    refs=["Harrison's 21st ed — Hemolytic anemias; Megaloblastic anemias"],
    concept="heme-hemolysis", concept_fa="افتراق همولیز از کمبود B12",
    concept_en="Separating haemolysis from B12 deficiency")

add("داخلی", 8,
    chapter_fa="خون", chapter_en="Hematology",
    key_corrected=True,
    original_correct_index=3,
    correct_index=0,
    key_correction_fa=(
        "کلید چاپی کربوکسی‌هموگلوبین را زده. EPO پایین یعنی پلی‌سیتمی اولیه (ورا)؛ "
        "قدم بعد JAK2 است. کربوکسی‌هموگلوبین مال پلی‌سیتمی ثانویه‌ی سیگار است که EPO بالا یا طبیعی دارد."
    ),
    key_correction_en=(
        "The printed key marks carboxyhaemoglobin. Low EPO means primary polycythaemia (vera); "
        "the next step is JAK2. Carboxyhaemoglobin belongs to smoking-related secondary polycythaemia, which has high or normal EPO."
    ),
    key_correction_source="Harrison's 21st ed",
    options_why_fa=[
        "پاسخ صحیح (تصحیح کلید) — EPO پایین = پلی‌سیتمی ورا تا خلافش ثابت شود → JAK2.",
        "اشباع اکسیژن برای پلی‌سیتمی ثانویه‌ی هیپوکسی است؛ آنجا EPO بالا می‌رود.",
        "فریتین ذخیره‌ی آهن است و تشخیص را عوض نمی‌کند.",
        "کربوکسی‌هموگلوبین سیگار را نشان می‌دهد ولی با EPO پایین جور نیست.",
    ],
    options_why_en=[
        "Correct (key corrected) — low EPO is polycythaemia vera until proven otherwise → JAK2.",
        "Oxygen saturation is for hypoxia-driven secondary polycythaemia, where EPO rises.",
        "Ferritin is iron stores and does not change the diagnosis.",
        "Carboxyhaemoglobin tracks smoking but does not fit a low EPO.",
    ],
    explanation_fa=(
        "تصحیح کلید رسمی. هموگلوبین ۱۸ و پلاکت ۵۶۰ با EPO کاهش‌یافته سه‌گانه‌ی "
        "پلی‌سیتمی ورا است نه اریتروسیتوز سیگار. در هیپوکسی و کربوکسی‌هموگلوبین "
        "بالا، کلیه EPO را زیاد می‌کند. اینجا EPO کم است، پس کلونال است و قدم بعد "
        "جهش JAK2 V617F است."
    ),
    explanation_en=(
        "Official key corrected. Haemoglobin 18 and platelets 560 with a low EPO "
        "is the triad of polycythaemia vera, not smoking erythrocytosis. In hypoxia "
        "and high carboxyhaemoglobin the kidney raises EPO. Here EPO is low, so the "
        "process is clonal and the next step is JAK2 V617F."
    ),
    micro={
        "lead_fa": "EPO پایین = ورا = JAK2. EPO بالا = ثانویه (سیگار، هیپوکسی).",
        "lead_en": "Low EPO means vera and JAK2. High EPO means secondary (smoking, hypoxia).",
        "points_fa": [
            "پلی‌سیتمی ورا یک نئوپلاسم میلوپرولیفراتیو JAK2 مثبت است.",
            "EPO در ورا پایین است چون تولید گلبول از کنترل کلیه خارج شده.",
            "در اریتروسیتوز سیگار، کربوکسی‌هموگلوبین بالا و EPO معمولاً بالاست.",
            "ترومبوسیتوز همراه به نفع ورا است نه ثانویه.",
            "معیار تشخیص: Hb بالا + JAK2 + یکی از مغز استخوان یا EPO پایین.",
            "سردرد و خارش پس از حمام داغ کلاسیک ورا هستند.",
            "خطر اصلی ترومبوز است؛ آسپرین و فلبوتومی پایه‌ی درمان‌اند.",
        ],
        "points_en": [
            "Polycythaemia vera is a JAK2-positive myeloproliferative neoplasm.",
            "EPO is low in vera because red-cell production has escaped renal control.",
            "In smoking erythrocytosis, carboxyhaemoglobin is high and EPO is usually high.",
            "Accompanying thrombocytosis favours vera, not secondary disease.",
            "Diagnostic criteria: high Hb + JAK2 + either marrow or low EPO.",
            "Headache and aquagenic pruritus are classic for vera.",
            "The main risk is thrombosis; aspirin and venesection are the base of treatment.",
        ],
    },
    golden_fa="EPO↓ + Hb↑ + پلاکت↑ = ورا → JAK2. سیگار EPO را بالا می‌برد نه پایین.",
    golden_en="Low EPO + high Hb + high platelets = vera → JAK2. Smoking raises EPO, it does not lower it.",
    refs=["Harrison's 21st ed — Polycythemia vera"],
    concept="heme-pv", concept_fa="پلی‌سیتمی ورا در برابر سیگار",
    concept_en="Polycythaemia vera versus smoking")

add("داخلی", 9,
    chapter_fa="گوارش", chapter_en="Gastroenterology",
    options_why_fa=[
        "آدنوکارسینوم ریه بیشتر با غیرسیگاری و جهش EGFR مرتبط است.",
        "اسکواموس ریه با سیگار مرتبط است ولی الکل و مایعات داغ نقش اصلی ندارند.",
        "آدنوکارسینوم مری از مری بارت و GERD می‌آید نه از الکل و چای داغ.",
        "پاسخ صحیح — اسکواموس مری: سیگار + الکل + نوشیدنی داغ.",
    ],
    options_why_en=[
        "Lung adenocarcinoma is more tied to never-smokers and EGFR mutations.",
        "Lung squamous is smoking-related but alcohol and hot drinks are not its main drivers.",
        "Oesophageal adenocarcinoma comes from Barrett and GERD, not alcohol and hot tea.",
        "Correct — oesophageal squamous: smoking + alcohol + hot drinks.",
    ],
    explanation_fa=(
        "سه عامل همزمان فقط در کارسینوم سلول سنگفرشی مری جمع می‌شوند: سیگار، "
        "الکل و نوشیدنی بسیار داغ (آسیب حرارتی مخاط). آدنوکارسینوم مری داستان "
        "بارت است."
    ),
    explanation_en=(
        "Three factors coincide only in oesophageal squamous-cell carcinoma: "
        "smoking, alcohol and very hot drinks (thermal mucosal injury). "
        "Oesophageal adenocarcinoma is a Barrett story."
    ),
    micro={
        "lead_fa": "سیگار + الکل + داغ = اسکواموس مری. بارت = آدنوکارسینوم مری.",
        "lead_en": "Smoking + alcohol + heat = oesophageal squamous. Barrett = oesophageal adenocarcinoma.",
        "points_fa": [
            "اسکواموس مری در دو سوم فوقانی شایع‌تر است.",
            "آدنوکارسینوم مری در محل اتصال و از مری بارت می‌آید.",
            "مایعات داغ یک عامل مستقل اسکواموس در مطالعات آسیایی و ایرانی است.",
            "سیگار برای هر دو نوع ریه خطر است ولی سه‌گانه‌ی سؤال مال مری اسکواموس است.",
        ],
        "points_en": [
            "Oesophageal squamous is commoner in the upper two thirds.",
            "Oesophageal adenocarcinoma sits at the junction and comes from Barrett.",
            "Hot drinks are an independent squamous risk in Asian and Iranian studies.",
            "Smoking raises both lung types, but the stem's triad is oesophageal squamous.",
        ],
    },
    golden_fa="داغ + سیگار + الکل = اسکواموس مری.",
    golden_en="Heat + smoking + alcohol = oesophageal squamous.",
    refs=["Harrison's 21st ed — Esophageal cancer"],
    concept="gi-esophagus-ca", concept_fa="ریسک‌فاکتور سرطان مری",
    concept_en="Oesophageal cancer risk factors")

add("داخلی", 10,
    chapter_fa="خون", chapter_en="Hematology",
    key_corrected=True,
    original_correct_index=1,
    correct_index=3,
    key_correction_fa=(
        "کلید چاپی CLL را زده. میلوسیت، متامیلوسیت، بازوفیل ۴٪ و طحال تا ناف یعنی CML، نه CLL "
        "(لنفوسیت بالغ)."
    ),
    key_correction_en=(
        "The printed key marks CLL. Myelocytes, metamyelocytes, 4% basophils and a spleen to the umbilicus "
        "are CML, not CLL (mature lymphocytes)."
    ),
    key_correction_source="Harrison's 21st ed",
    options_why_fa=[
        "AML با بلاست و نارسایی مغز استخوان است، نه با طحال عظیم و بازوفیل.",
        "CLL لنفوسیت بالغ زیاد می‌کند، نه میلوسیت و بازوفیل.",
        "ALL بیماری کودک و بلاست لنفوئید است.",
        "پاسخ صحیح (تصحیح کلید) — شیفت به چپ + بازوفیلی + اسپلنومگالی = CML.",
    ],
    options_why_en=[
        "AML is blasts and marrow failure, not a huge spleen and basophils.",
        "CLL expands mature lymphocytes, not myelocytes and basophils.",
        "ALL is a disease of children and lymphoid blasts.",
        "Correct (key corrected) — left shift + basophilia + splenomegaly = CML.",
    ],
    explanation_fa=(
        "تصحیح کلید رسمی. WBC ۳۴ هزار با میلوسیت و متامیلوسیت، بازوفیل ۴٪ و طحال "
        "تا ناف تعریف CML مزمن است. CLL افتراق ساده‌ای دارد: اسمیر پر از لنفوسیت "
        "بالغ است نه پیش‌ساز میلوئید."
    ),
    explanation_en=(
        "Official key corrected. A WBC of 34 thousand with myelocytes and "
        "metamyelocytes, 4% basophils and a spleen to the umbilicus is chronic-phase "
        "CML. CLL is easily separated: the smear is mature lymphocytes, not myeloid precursors."
    ),
    micro={
        "lead_fa": "بازوفیل + میلوسیت + طحال بزرگ = CML تا خلافش ثابت شود.",
        "lead_en": "Basophils + myelocytes + a big spleen is CML until proven otherwise.",
        "points_fa": [
            "CML سه‌فاز دارد: مزمن، تسریع، بلاست.",
            "فاز مزمن: WBC بالا، شیفت به چپ، بازوفیلی، اسپلنومگالی، حال عمومی نسبتاً خوب.",
            "کروموزوم فیلادلفیا t(9;22) و BCR-ABL تشخیص را قطعی می‌کند.",
            "درمان خط اول مهارکننده‌ی تیروزین کیناز (ایماتینیب و نسل بعد) است.",
            "CLL: لنفوسیت بالغ، لنفادنوپاتی، در سالمند.",
            "AML: بلاست ≥۲۰٪، نارسایی مغز، عفونت و خونریزی.",
            "LAP score در CML پایین و در واکنش لکوئید بالا است.",
        ],
        "points_en": [
            "CML has three phases: chronic, accelerated, blast.",
            "Chronic phase: high WBC, left shift, basophilia, splenomegaly, relatively preserved wellbeing.",
            "The Philadelphia chromosome t(9;22) and BCR-ABL settle the diagnosis.",
            "First-line treatment is a tyrosine-kinase inhibitor (imatinib and later generations).",
            "CLL: mature lymphocytes, lymphadenopathy, older adults.",
            "AML: blasts ≥20%, marrow failure, infection and bleeding.",
            "LAP score is low in CML and high in a leukaemoid reaction.",
        ],
    },
    golden_fa="بازوفیلی + پیش‌ساز میلوئید + طحال = CML. CLL لنفوسیت است.",
    golden_en="Basophilia + myeloid precursors + spleen = CML. CLL is lymphocytes.",
    refs=["Harrison's 21st ed — Chronic myeloid leukemia"],
    concept="heme-cml", concept_fa="تشخیص CML",
    concept_en="Diagnosing CML")

# ─────────────────────────── INFECTIOUS 103–108 ───────────────────────────
add("عفونی", 103,
    chapter_fa="عفونت‌های دستگاه تنفسی", chapter_en="Respiratory Tract Infections",
    options_why_fa=[
        "RR ۴۰ و تب ۴۰ معیار بستری و احتمالاً ICU است؛ سرپایی خطرناک است.",
        "در بخش برای پنومونی بستری معمولی است، اما RR ۴۰ معیار ماژور ICU است.",
        "پاسخ صحیح — نارسایی تنفسی (RR≥۳۰) = مراقبت ویژه + بتا‌لاکتام و ماکرولید.",
        "لووفلوکساسین به‌علاوه‌ی سفتریاکسون پوشش مضاعف فلوروکینولون است و ICU را حل نمی‌کند.",
    ],
    options_why_en=[
        "RR 40 and fever 40 are admission and likely ICU criteria; outpatient care is unsafe.",
        "Ward care fits ordinary admitted pneumonia, but RR 40 is a major ICU criterion.",
        "Correct — respiratory failure (RR≥30) means intensive care plus a beta-lactam and a macrolide.",
        "Levofloxacin plus ceftriaxone is redundant fluoroquinolone cover and does not address the ICU need.",
    ],
    explanation_fa=(
        "پنومونی اکتسابی از جامعه با تب ۴۰ و RR ۴۰. معیارهای ATS برای ICU: "
        "شوک نیازمند وازوپرسور یا نارسایی تنفسی نیازمند ونتیلاسیون؛ RR بالای ۳۰ "
        "یکی از معیارهای ماژور/مینور است که بستری در مراقبت ویژه را توجیه می‌کند. "
        "رژیم ICU: بتا‌لاکتام (سفتریاکسون) + ماکرولید."
    ),
    explanation_en=(
        "Community-acquired pneumonia with fever 40 and RR 40. ATS ICU criteria: "
        "shock needing vasopressors or respiratory failure needing ventilation; "
        "RR over 30 is a major/minor criterion that justifies intensive care. "
        "ICU regimen: a beta-lactam (ceftriaxone) plus a macrolide."
    ),
    micro={
        "lead_fa": "RR≥۳۰ در پنومونی = فکر ICU. رژیم: سفتریاکسون + آزیترومایسین.",
        "lead_en": "RR≥30 in pneumonia means think ICU. Regimen: ceftriaxone plus azithromycin.",
        "points_fa": [
            "CURB-65 و PSI محل بستری را مشخص می‌کنند؛ معیار ATS محل ICU را.",
            "معیار ماژور ICU: شوک یا نیاز به تهویه‌ی مکانیکی.",
            "معیار مینور: RR≥۳۰، PaO2/FiO2 پایین، مولتی‌لوبار، اوره بالا، لکوپنی، ترمبوسیتوپنی، هیپوترمی، گیجی.",
            "سه مینور یا یک ماژور = ICU.",
            "پوشش پنوموکوک مقاوم و آتیپیک‌ها با بتا‌لاکتام + ماکرولید.",
            "فلوروکینولون تنفسی جایگزین ماکرولید است نه افزودنی همیشگی.",
            "در ICU اگر پسودوموناس مطرح باشد پوشش جداگانه لازم است؛ اینجا زمینه‌ای نیست.",
        ],
        "points_en": [
            "CURB-65 and PSI decide the ward; ATS criteria decide the ICU.",
            "Major ICU criteria: shock or need for mechanical ventilation.",
            "Minor: RR≥30, low PaO2/FiO2, multilobar, high urea, leukopenia, thrombocytopenia, hypothermia, confusion.",
            "Three minor or one major means ICU.",
            "Cover resistant pneumococcus and atypicals with a beta-lactam plus a macrolide.",
            "A respiratory fluoroquinolone replaces the macrolide; it is not a routine add-on.",
            "If Pseudomonas is likely the cover changes; there is no such background here.",
        ],
    },
    golden_fa="پنومونی + RR ۴۰ → ICU + سفتریاکسون و آزیترومایسین.",
    golden_en="Pneumonia plus RR 40 → ICU plus ceftriaxone and azithromycin.",
    refs=["Harrison's 21st ed — Community-acquired pneumonia", "IDSA/ATS CAP guidelines"],
    concept="cap-icu", concept_fa="پنومونی و معیار ICU",
    concept_en="Pneumonia and ICU criteria")

add("عفونی", 104,
    chapter_fa="عفونت‌های گوارشی و اسهال", chapter_en="Gastrointestinal Infections and Diarrhoea",
    options_why_fa=[
        "مگاکولون توکسیک عارضه‌ی شیگلا در هر میزبانی است، نه ویژه‌ی HIV.",
        "پاسخ صحیح — در سوءتغذیه و HIV شیگلا به‌راحتی به خون می‌رود.",
        "پرفوراسیون نادر است و به HIV اختصاص ندارد.",
        "اختلال متابولیک در هر اسهال شدید دیده می‌شود.",
    ],
    options_why_en=[
        "Toxic megacolon is a Shigella complication in any host, not specific to HIV.",
        "Correct — in malnutrition and HIV, Shigella readily enters the blood.",
        "Perforation is rare and not HIV-specific.",
        "Metabolic upset is seen in any severe diarrhoea.",
    ],
    explanation_fa=(
        "شیگلا در میزبان سالم معمولاً در مخاط می‌ماند. وقتی ایمنی سلولی یا "
        "سد مخاطی خراب باشد (HIV، سوءتغذیه، کودک خردسال) باکتریمی شیگلایی "
        "شایع می‌شود و همین وجه تمایز سؤال است."
    ),
    explanation_en=(
        "In an immunocompetent host Shigella usually stays in the mucosa. When "
        "cellular immunity or the mucosal barrier is broken (HIV, malnutrition, "
        "young children) Shigella bacteraemia becomes common, and that is the "
        "distinction the question wants."
    ),
    micro={
        "lead_fa": "شیگلا + HIV یا سوءتغذیه = باکتریمی. در میزبان سالم تهاجم خونی نادر است.",
        "lead_en": "Shigella plus HIV or malnutrition means bacteraemia. Bloodstream invasion is rare in a healthy host.",
        "points_fa": [
            "شیگلا دوز عفونی بسیار پایینی دارد و از فرد به فرد می‌رود.",
            "تابلوی کلاسیک دیسانتری است: اسهال کم‌حجم خونی با تنسموس.",
            "باکتریمی در میزبان سالم نادر است.",
            "در HIV، سوءتغذیه و کودکان خردسال باکتریمی شایع می‌شود.",
            "مگاکولون توکسیک عارضه‌ی کولیت شدید است نه ویژه‌ی نقص ایمنی.",
            "درمان: فلوروکینولون یا آزیترومایسین بسته به مقاومت منطقه‌ای.",
        ],
        "points_en": [
            "Shigella has a very low infectious dose and spreads person to person.",
            "The classic picture is dysentery: small-volume bloody stool with tenesmus.",
            "Bacteraemia is rare in a healthy host.",
            "In HIV, malnutrition and young children bacteraemia becomes common.",
            "Toxic megacolon is a complication of severe colitis, not specific to immunodeficiency.",
            "Treatment: a fluoroquinolone or azithromycin depending on local resistance.",
        ],
    },
    golden_fa="شیگلا در HIV/سوءتغذیه به خون می‌رود.",
    golden_en="In HIV or malnutrition, Shigella goes to blood.",
    refs=["Harrison's 21st ed — Shigellosis"],
    concept="shigella-bacteremia", concept_fa="باکتریمی شیگلا",
    concept_en="Shigella bacteraemia")

add("عفونی", 105,
    chapter_fa="عفونت‌های دستگاه تنفسی", chapter_en="Respiratory Tract Infections",
    options_why_fa=[
        "چهار هفته برای بسیاری از آبسه‌ها کوتاه است؛ معیار، تصویر است نه تقویم.",
        "پاسخ صحیح — آنتی‌بیوتیک آبسه‌ی ریه تا محو شدن حفره در تصویر ادامه می‌یابد.",
        "ESR و CRP از تصویر عقب می‌مانند یا غیر اختصاصی‌اند.",
        "علائم بالینی زودتر از حفره خوب می‌شوند؛ قطع زودهنگام عود می‌دهد.",
    ],
    options_why_en=[
        "Four weeks is short for many abscesses; the yardstick is the image, not the calendar.",
        "Correct — antibiotics for lung abscess continue until the cavity has gone on imaging.",
        "ESR and CRP lag behind the image or are non-specific.",
        "Symptoms improve before the cavity does; stopping early invites relapse.",
    ],
    explanation_fa=(
        "آبسه‌ی ریه پس از سکته (آسپیراسیون) با خلط بدبو. درمان طولانی است و "
        "نقطه‌ی پایان محو رادیولوژیک حفره است، نه تعداد هفته و نه فقط حال عمومی."
    ),
    explanation_en=(
        "A lung abscess after a stroke (aspiration) with foul sputum. Treatment "
        "is prolonged and the stop-point is radiographic resolution of the cavity, "
        "not a week-count or symptoms alone."
    ),
    micro={
        "lead_fa": "آبسه‌ی ریه را تا پاک شدن حفره در تصویر درمان کنید، نه تا خوب شدن حال.",
        "lead_en": "Treat a lung abscess until the cavity has gone on the film, not until the patient feels better.",
        "points_fa": [
            "آبسه‌ی ریه اغلب عارضه‌ی آسپیراسیون است (سکته، الکل، صرع).",
            "خلط بدبو به نفع بی‌هوازی‌های دهانی است.",
            "درمان انتخابی آمپی‌سیلین-سولباکتام یا کلیندامایسین است.",
            "مدت معمول ۴ تا ۸ هفته است ولی معیار، CT یا گرافی است.",
            "درناژ جراحی فقط برای شکست درمان یا عارضه است.",
        ],
        "points_en": [
            "Lung abscess is often a complication of aspiration (stroke, alcohol, epilepsy).",
            "Foul sputum favours oral anaerobes.",
            "Drugs of choice are ampicillin-sulbactam or clindamycin.",
            "Duration is often 4 to 8 weeks but the criterion is CT or the radiograph.",
            "Surgical drainage is only for failure or complication.",
        ],
    },
    golden_fa="آبسه‌ی ریه: آنتی‌بیوتیک تا محو حفره.",
    golden_en="Lung abscess: antibiotics until the cavity vanishes.",
    refs=["Harrison's 21st ed — Lung abscess"],
    concept="lung-abscess", concept_fa="طول درمان آبسه‌ی ریه",
    concept_en="Duration of therapy for lung abscess")

add("عفونی", 106,
    chapter_fa="عفونت‌های سیستم عصبی مرکزی", chapter_en="CNS Infections",
    options_why_fa=[
        "فوتوفوبی علامت مننژ است نه پارانشیم مغز.",
        "درد حرکت چشم هم مننژیسم است.",
        "پاسخ صحیح — تشنج یعنی درگیری پارانشیم = انسفالیت همزمان.",
        "سفتی گردن تعریف مننژیت است نه انسفالیت.",
    ],
    options_why_en=[
        "Photophobia is a meningeal sign, not a parenchymal one.",
        "Pain on eye movement is also meningism.",
        "Correct — a seizure means parenchymal involvement = concurrent encephalitis.",
        "Neck stiffness defines meningitis, not encephalitis.",
    ],
    explanation_fa=(
        "مننژیت التهاب پرده است: تب، سردرد، سفتی گردن، فوتوفوبی. انسفالیت "
        "التهاب خود مغز است: اختلال شعور، تشنج، نقص فوکال. تشنج از پرده نمی‌آید."
    ),
    explanation_en=(
        "Meningitis is inflammation of the lining: fever, headache, stiff neck, "
        "photophobia. Encephalitis is inflammation of the brain itself: altered "
        "mind, seizure, focal deficit. A seizure does not come from the meninges."
    ),
    micro={
        "lead_fa": "تشنج و گیجی = مغز (انسفالیت). سفتی گردن و فوتوفوبی = پرده (مننژیت).",
        "lead_en": "Seizure and confusion mean brain (encephalitis). Stiff neck and photophobia mean lining (meningitis).",
        "points_fa": [
            "مننگوانسفالیت یعنی هر دو با هم، شایع در HSV و بعضی انتروویروس‌ها.",
            "HSV تمپورال را می‌گیرد: تب + رفتار غیرعادی + تشنج.",
            "اگر انسفالیت مطرح است، آسیکلوویر را پیش از MRI و PCR شروع کنید.",
            "CSF در ویرال: لنفوسیت، قند طبیعی، پروتئین کمی بالا.",
        ],
        "points_en": [
            "Meningoencephalitis means both together, common with HSV and some enteroviruses.",
            "HSV hits the temporal lobe: fever + odd behaviour + seizure.",
            "If encephalitis is possible, start aciclovir before MRI and PCR.",
            "Viral CSF: lymphocytes, normal glucose, slightly high protein.",
        ],
    },
    golden_fa="مننژیت = پرده. انسفالیت = تشنج و شعور.",
    golden_en="Meningitis is the lining. Encephalitis is seizure and mind.",
    refs=["Harrison's 21st ed — Viral meningitis and encephalitis", "Aminoff 2021"],
    concept="cns-meningoencephalitis", concept_fa="افتراق مننژیت از انسفالیت",
    concept_en="Separating meningitis from encephalitis")

add("عفونی", 107,
    chapter_fa="عفونت‌های پوست، بافت نرم و گازگرفتگی", chapter_en="Skin, Soft Tissue and Bite Infections",
    options_why_fa=[
        "گاز سگ را در زخم کم‌عمق سالم می‌توان گاهی فقط شست؛ پروفیلاکسی همیشگی نیست.",
        "پاسخ صحیح — گاز انسان همیشه پرخطر است (فلور دهان + بی‌هوازی) و حتی زخم تمیز پروفیلاکسی می‌گیرد.",
        "گاز گربه بسیار پرخطر است و معمولاً پروفیلاکسی می‌گیرد، ولی کلید رسمی این دفترچه انسان را خواسته.",
        "جوندگان کمتر عفونی می‌کنند و پروفیلاکسی روتین ندارند.",
    ],
    options_why_en=[
        "A shallow dog bite in a healthy host can sometimes be washed only; prophylaxis is not automatic.",
        "Correct — a human bite is always high-risk (oral flora plus anaerobes) and even a clean wound gets prophylaxis.",
        "Cat bites are very high-risk and usually get prophylaxis, but this paper's official key asks for human.",
        "Rodents infect less often and do not get routine prophylaxis.",
    ],
    explanation_fa=(
        "کلید رسمی «انسان» است. گاز انسان فلور دهانی غنی از بی‌هوازی و "
        "Eikenella را به عمق مفصل و تاندون دست می‌برد و حتی اگر هنوز عفونی "
        "به نظر نرسد پروفیلاکسی می‌گیرد. گاز گربه هم در عمل تقریباً همیشه "
        "پروفیلاکسی می‌شود؛ در این سؤال باید گزینه‌ی مورد نظر دفترچه را حفظ کرد."
    ),
    explanation_en=(
        "The official key is human. A human bite drives oral anaerobes and "
        "Eikenella deep into hand tendons and joints, so it gets prophylaxis "
        "even before it looks infected. Cat bites are also almost always "
        "prophylaxed in practice; here we keep the booklet's intended option."
    ),
    micro={
        "lead_fa": "گاز انسان (و عملاً گربه) حتی زخم تمیز پروفیلاکسی می‌خواهد. جونده معمولاً نه.",
        "lead_en": "Human bites (and in practice cat bites) get prophylaxis even if clean. Rodents usually do not.",
        "points_fa": [
            "گاز انسان: استرپ، استاف، Eikenella، بی‌هوازی.",
            "محل شایع دست است و نزدیک تاندون و مفصل.",
            "گاز گربه: پاستورلا، سوراخ عمیق، عفونت تا ۵۰٪.",
            "داروی انتخابی کوآموکسی‌کلاو است.",
            "آلرژی پنی‌سیلین: کلیندامایسین + سیپروفلوکساسین یا کوتریموکسازول.",
            "کزاز و هاری را جداگانه بسنجید.",
        ],
        "points_en": [
            "Human bite: strep, staph, Eikenella, anaerobes.",
            "The usual site is the hand, close to tendon and joint.",
            "Cat bite: Pasteurella, deep puncture, infection up to 50%.",
            "Drug of choice is co-amoxiclav.",
            "Penicillin allergy: clindamycin plus ciprofloxacin or co-trimoxazole.",
            "Assess tetanus and rabies separately.",
        ],
    },
    golden_fa="انسان (رسمی) و گربه: پروفیلاکسی حتی زخم تمیز. دارو: کوآموکسی‌کلاو.",
    golden_en="Human (official) and cat: prophylaxis even if clean. Drug: co-amoxiclav.",
    refs=["Harrison's 21st ed — Infectious complications of bites"],
    concept="human-bite", concept_fa="پروفیلاکسی گاز انسان",
    concept_en="Human-bite prophylaxis")

add("عفونی", 108,
    chapter_fa="عفونت‌های ویروسی و منتقله از راه جنسی", chapter_en="Viral and Sexually Transmitted Infections",
    options_why_fa=[
        "واکسن واریسلا زنده است و در بارداری مطلقاً ممنوع است.",
        "پاسخ صحیح — سرولوژی منفی + تماس + بارداری = VZIG هرچه زودتر (تا ۱۰ روز).",
        "آسیکلوویر وریدی برای بیماری منتشر مادر است نه پیشگیری پس از تماس.",
        "وال‌آسیکلوویر خوراکی پیشگیری استاندارد تماس در بارداری نیست.",
    ],
    options_why_en=[
        "Varicella vaccine is live and absolutely forbidden in pregnancy.",
        "Correct — negative serology + exposure + pregnancy = VZIG as soon as possible (up to 10 days).",
        "Intravenous aciclovir is for disseminated maternal disease, not post-exposure prevention.",
        "Oral valaciclovir is not standard post-exposure prevention in pregnancy.",
    ],
    explanation_fa=(
        "باردار سرو‌منفی پنج روز پس از تماس با آبله‌مرغان. واکسن زنده ممنوع است. "
        "ایمونوگلوبولین واریسلا-زوستر تا ده روز پس از تماس خطر بیماری شدید مادر "
        "و واریسلای مادرزادی را کم می‌کند."
    ),
    explanation_en=(
        "A seronegative pregnant woman five days after chickenpox exposure. "
        "Live vaccine is forbidden. Varicella-zoster immunoglobulin within ten "
        "days of exposure reduces severe maternal disease and congenital varicella."
    ),
    micro={
        "lead_fa": "باردار سرو‌منفی + تماس واریسلا = VZIG، نه واکسن زنده.",
        "lead_en": "Seronegative pregnancy plus varicella contact = VZIG, not live vaccine.",
        "points_fa": [
            "آبله‌مرغان در بارداری می‌تواند پنومونی مادر و سندرم واریسلای مادرزادی بدهد.",
            "بیشترین خطر ناهنجاری جنین در بیست هفته‌ی اول است.",
            "اول سرولوژی؛ اگر IgG مثبت باشد ایمنی دارد و کاری لازم نیست.",
            "اگر منفی است، VZIG هرچه زودتر تا حداکثر ده روز.",
            "واکسن MMR و واریسلا در بارداری ممنوع‌اند.",
            "اگر مادر ضایعه زد، آسیکلوویر درمان است نه فقط پیشگیری.",
            "نوزاد مادر مبتلا حول زایمان HBIG/VZIG و گاهی آسیکلوویر می‌گیرد.",
        ],
        "points_en": [
            "Chickenpox in pregnancy can cause maternal pneumonia and congenital varicella syndrome.",
            "The greatest risk of fetal malformation is in the first twenty weeks.",
            "Check serology first; if IgG is positive she is immune and nothing is needed.",
            "If negative, give VZIG as soon as possible, at latest by day ten.",
            "MMR and varicella vaccines are forbidden in pregnancy.",
            "If the mother develops lesions, aciclovir is treatment, not mere prevention.",
            "A newborn whose mother is infectious around delivery gets HBIG/VZIG and sometimes aciclovir.",
        ],
    },
    golden_fa="باردار −IgG + تماس = VZIG تا روز ۱۰. واکسن زنده ممنوع.",
    golden_en="Pregnant, IgG negative, exposed = VZIG by day 10. Live vaccine forbidden.",
    refs=["Harrison's 21st ed — Varicella-zoster virus", "CDC varicella in pregnancy"],
    concept="vzv-pregnancy", concept_fa="تماس واریسلا در بارداری",
    concept_en="Varicella exposure in pregnancy")

# ─────────────────────────── NEUROLOGY 97–102 ───────────────────────────
add("مغز و اعصاب", 97,
    chapter_fa="سردرد", chapter_en="Headache",
    options_why_fa=[
        "پاسخ صحیح — سردرد خوشه‌ای تنها سردرد اولیه‌ای است که در مردان شایع‌تر است.",
        "میگرن در زنان حدود سه برابر شایع‌تر است.",
        "افزایش فشار ایدیوپاتیک تقریباً منحصر به زنان جوان دارای اضافه‌وزن است.",
        "سردرد تنشی در زنان کمی شایع‌تر است.",
    ],
    options_why_en=[
        "Correct — cluster is the only primary headache more common in men.",
        "Migraine is about three times commoner in women.",
        "Idiopathic intracranial hypertension is almost confined to young women with overweight.",
        "Tension headache is slightly commoner in women.",
    ],
    explanation_fa=(
        "از میان سردردهای اولیه فقط خوشه‌ای در مردان غالب است (نسبت حدود سه به یک). "
        "حملات کوتاه بسیار شدید دور چشم با اشک و رینوره، در فصل‌ها تکرار می‌شوند."
    ),
    explanation_en=(
        "Among primary headaches only cluster is male-predominant (about three to one). "
        "Attacks are short, extremely severe, orbital, with tearing and rhinorrhoea, "
        "coming in seasonal bouts."
    ),
    micro={
        "lead_fa": "خوشه‌ای = مرد. میگرن و IIH و تا حدی تنشی = زن.",
        "lead_en": "Cluster is male. Migraine, IIH and to an extent tension are female.",
        "points_fa": [
            "سردرد خوشه‌ای: درد دور چشمی یک‌طرفه، ۱۵ تا ۱۸۰ دقیقه، چندین بار در روز.",
            "علائم اتونوم همان سمت: اشک، احتقان بینی، پتوز، میوز.",
            "بیمار بی‌قرار است و راه می‌رود؛ برخلاف میگرن که دراز می‌کشد.",
            "حمله‌ی حاد: اکسیژن ۱۰۰٪ یا تریپتان زیرجلدی.",
            "پیشگیری: وراپامیل.",
            "میگرن: تهوع، فوتوفوبی، ترجیح سکوت و تاریکی، غالب زنان.",
            "IIH: زن جوان چاق، ادم دیسک، تاری گذرا، نبض در گوش.",
        ],
        "points_en": [
            "Cluster: unilateral orbital pain, 15 to 180 minutes, several times a day.",
            "Ipsilateral autonomic signs: tearing, nasal congestion, ptosis, miosis.",
            "The patient is restless and paces; a migraineur lies still.",
            "Acute attack: 100% oxygen or subcutaneous triptan.",
            "Prevention: verapamil.",
            "Migraine: nausea, photophobia, preference for quiet darkness, female-predominant.",
            "IIH: young woman with overweight, disc swelling, transient visual obscurations, pulsatile tinnitus.",
        ],
    },
    golden_fa="تنها سردرد اولیه‌ی مردانه = خوشه‌ای. حمله: O2 یا تریپتان. پیشگیری: وراپامیل.",
    golden_en="The only male primary headache is cluster. Attack: oxygen or triptan. Prevention: verapamil.",
    refs=["Aminoff 2021 — Headache and facial pain"],
    concept="cluster-sex", concept_fa="جنسیت در سردرد خوشه‌ای",
    concept_en="Sex ratio in cluster headache")

add("مغز و اعصاب", 98,
    chapter_fa="کما و مسمومیت", chapter_en="Coma and intoxication",
    options_why_fa=[
        "اوپیوئید مردمک ته‌سنجاقی و هیپوترمی می‌دهد نه تب.",
        "پاسخ صحیح — آنتی‌کولینرژیک تعریق را می‌بندد: داغ، خشک، قرمز، دلیریوم.",
        "الکل گشادکننده‌ی عروق و معمولاً هیپوترم است.",
        "باربیتورات مثل سایر سرکوب‌کننده‌ها دما را پایین می‌آورد.",
    ],
    options_why_en=[
        "Opioids give pinpoint pupils and hypothermia, not fever.",
        "Correct — anticholinergics shut down sweating: hot, dry, red, delirious.",
        "Alcohol vasodilates and usually lowers temperature.",
        "Barbiturates, like other depressants, drop temperature.",
    ],
    explanation_fa=(
        "یادیار آنتی‌کولینرژیک: داغ مثل خرگوش، خشک مثل استخوان، قرمز مثل چغندر، "
        "کور مثل خفاش، دیوانه مثل کلاه‌دوز. مهار غدد عرق راه دفع گرما را می‌بندد "
        "و هیپرترمی می‌سازد. سه گزینه‌ی دیگر سرکوب‌کننده‌ی CNS و هیپوترم‌اند."
    ),
    explanation_en=(
        "Anticholinergic mnemonic: hot as a hare, dry as a bone, red as a beet, "
        "blind as a bat, mad as a hatter. Blocking sweat glands closes the heat-loss "
        "path and produces hyperthermia. The other three are CNS depressants and hypothermic."
    ),
    micro={
        "lead_fa": "کما + پوست داغ و خشک = آنتی‌کولینرژیک. اوپیوئید و الکل و باربیتورات سرد می‌کنند.",
        "lead_en": "Coma plus hot dry skin is anticholinergic. Opioids, alcohol and barbiturates cool the patient.",
        "points_fa": [
            "آنتی‌کولینرژیک‌ها: آنتی‌هیستامین، TCA، آتروپین، برخی گیاهان.",
            "مردمک گشاد و غیرواکنشی است.",
            "روده و مثانه ساکت‌اند (احتباس ادرار).",
            "اوپیوئید: مردمک ته‌سنجاقی، برادی‌پنه، پاسخ به نالوکسان.",
            "سمپاتومیمتیک (کوکائین، آمفتامین) هم تب می‌دهد ولی پوست معمولاً مرطوب است.",
            "سروتونین و NMS هم هیپرترمی‌اند ولی تابلوی دیگری دارند.",
        ],
        "points_en": [
            "Anticholinergics: antihistamines, TCAs, atropine, some plants.",
            "Pupils are large and poorly reactive.",
            "Bowel and bladder are quiet (urinary retention).",
            "Opioid: pinpoint pupils, bradypnoea, naloxone response.",
            "Sympathomimetics (cocaine, amphetamine) also fever, but the skin is usually wet.",
            "Serotonin syndrome and NMS also hyperthermia, with a different picture.",
        ],
    },
    golden_fa="هیپرترمی در کما: آنتی‌کولینرژیک (خشک) یا سمپاتومیمتیک (مرطوب).",
    golden_en="Hyperthermia in coma: anticholinergic (dry) or sympathomimetic (wet).",
    refs=["Aminoff 2021 — Coma; Harrison's — Poisoning"],
    concept="anticholinergic-coma", concept_fa="هیپرترمی آنتی‌کولینرژیک",
    concept_en="Anticholinergic hyperthermia")

add("مغز و اعصاب", 99,
    chapter_fa="سکته", chapter_en="Stroke",
    options_why_fa=[
        "افت هوشیاری در هر دو نوع سکته ممکن است و افتراق‌دهنده نیست.",
        "پاسخ صحیح — سردرد و استفراغ یعنی افزایش ICP از حجم اضافه؛ به نفع خونریزی است.",
        "آفازی به محل ضایعه بستگی دارد نه به خون یا ایسکمی.",
        "تشنج در هر دو دیده می‌شود و اختصاصی نیست.",
    ],
    options_why_en=[
        "Loss of consciousness occurs in both stroke types and does not discriminate.",
        "Correct — headache and vomiting mean raised ICP from added volume; they favour haemorrhage.",
        "Aphasia depends on lesion site, not on blood versus ischaemia.",
        "Seizure is seen in both and is not specific.",
    ],
    explanation_fa=(
        "تصحیح کلید چاپی که آفازی را زده بود. آفازی مکان است نه مکانیسم. "
        "خونریزی یک توده‌ی اضافه می‌سازد، ICP را بالا می‌برد و سردرد و استفراغ "
        "می‌دهد؛ در ساعات اول ایسکمی این‌ها نادرند."
    ),
    explanation_en=(
        "The printed key marked aphasia and was corrected. Aphasia is location, "
        "not mechanism. Haemorrhage adds a mass, raises ICP and produces headache "
        "and vomiting; those are uncommon in the first hours of ischaemia."
    ),
    micro={
        "lead_fa": "خونریزی = توده = سردرد و استفراغ. آفازی = کجا، نه چه نوعی.",
        "lead_en": "Haemorrhage is a mass, hence headache and vomiting. Aphasia is where, not which type.",
        "points_fa": [
            "علائم بیشتر به نفع ICH: شروع حین فعالیت، سردرد شدید، استفراغ، افت سریع هوشیاری، فشار خیلی بالا.",
            "ایسکمی اغلب در سکون شروع می‌شود و سردرد برجسته ندارد.",
            "تشخیص قطعی با CT بدون کنتراست در دقایق اول است.",
            "هر دو می‌توانند همی‌پارزی بدهند؛ نوع را از همراهان بپرسید نه از ضعف.",
            "آفازی = نیمکره‌ی غالب، چه خون چه لخته.",
        ],
        "points_en": [
            "Features favouring ICH: onset during activity, severe headache, vomiting, rapid coma, very high BP.",
            "Ischaemia often begins at rest and lacks prominent headache.",
            "Definitive early test is non-contrast CT.",
            "Both can cause hemiparesis; ask the companions, not the weakness, for the type.",
            "Aphasia means the dominant hemisphere, whether blood or clot.",
        ],
    },
    golden_fa="ICH را با سردرد و استفراغ بشناس، نه با آفازی.",
    golden_en="Recognise ICH by headache and vomiting, not by aphasia.",
    refs=["Aminoff 2021 — Cerebrovascular disease"],
    concept="ich-vs-ischemia", concept_fa="افتراق خونریزی از ایسکمی",
    concept_en="Haemorrhage versus ischaemia")

add("مغز و اعصاب", 100,
    chapter_fa="نوروپاتی", chapter_en="Neuropathy",
    options_why_fa=[
        "نوروپاتی دیابتی اتونوم را خیلی درگیر می‌کند؛ گفتن «دیده نمی‌شود» غلط است.",
        "پاسخ صحیح — الیاف ضخیم حس عمقی را می‌برند و آتاکسی حسی می‌سازند.",
        "آتروفی در بیماری طولانی دیده می‌شود و تشخیص را رد نمی‌کند.",
        "بابینسکی علامت راه‌ی هرمی است نه نوروپاتی محیطی.",
    ],
    options_why_en=[
        "Diabetic neuropathy involves autonomic fibres often; saying it is absent is wrong.",
        "Correct — large fibres carry proprioception and their loss produces sensory ataxia.",
        "Atrophy appears in long-standing disease and does not refute the diagnosis.",
        "Babinski is a pyramidal sign, not a feature of peripheral neuropathy.",
    ],
    explanation_fa=(
        "پارستزی دستکش‌جوراب، آرفلکسی و دیابت طولانی = پلی‌نوروپاتی دیابتی. "
        "الیاف ضخیم حس وضعیت را می‌برند؛ بیمار در تاریکی می‌افتد (رومبرگ). "
        "اتونوم شایع است، آتروفی ممکن است، بابنسکی نباید باشد."
    ),
    explanation_en=(
        "Glove-and-stocking paraesthesia, areflexia and long diabetes = diabetic "
        "polyneuropathy. Large fibres carry joint position; the patient falls in "
        "the dark (Romberg). Autonomic involvement is common, atrophy is possible, "
        "Babinski should be absent."
    ),
    micro={
        "lead_fa": "دیابت + دستکش‌جوراب + آرفلکسی = پلی‌نوروپاتی. حس عمقی می‌رود؛ بابنسکی نمی‌آید.",
        "lead_en": "Diabetes + glove-and-stocking + areflexia = polyneuropathy. Position sense goes; Babinski does not come.",
        "points_fa": [
            "شایع‌ترین نوروپاتی جهان نوروپاتی دیابتی است.",
            "شروع از پا، تقارن، پیشرفت صعودی.",
            "الیاف نازک: درد سوزشی و اتونوم.",
            "الیاف ضخیم: ارتعاش، وضعیت، آتاکسی، آرفلکسی.",
            "رومبرگ مثبت یعنی وابستگی به بینایی برای تعادل.",
            "درمان: کنترل قند + داروهای درد نوروپاتیک (گاباپنتین، دولوکستین).",
        ],
        "points_en": [
            "The world's commonest neuropathy is diabetic.",
            "It starts in the feet, is symmetric and ascends.",
            "Small fibres: burning pain and autonomic features.",
            "Large fibres: vibration, position, ataxia, areflexia.",
            "A positive Romberg means vision is being used for balance.",
            "Treatment: glucose control + neuropathic-pain drugs (gabapentin, duloxetine).",
        ],
    },
    golden_fa="پلی‌نوروپاتی دیابتی: حس عمقی↓، رفلکس↓، اتونوم+. بابنسکی ندارد.",
    golden_en="Diabetic polyneuropathy: position sense down, reflexes down, autonomic up. No Babinski.",
    refs=["Aminoff 2021 — Peripheral neuropathies"],
    concept="diabetic-neuropathy", concept_fa="پلی‌نوروپاتی دیابتی",
    concept_en="Diabetic polyneuropathy")

add("مغز و اعصاب", 101,
    chapter_fa="صرع", chapter_en="Epilepsy",
    options_why_fa=[
        "در ابسانس آگاهی قطع می‌شود؛ حفظ هوشیاری مال فوکال ساده است.",
        "از دست رفتن تون و افتادن مال آتونیک است؛ در ابسانس تون می‌ماند.",
        "گیجی طولانی پس از حمله مال تونیک-کلونیک یا فوکال پیچیده است.",
        "پاسخ صحیح — پلک زدن و اتوماتیسم ظریف در دو سوم ابسانس‌ها دیده می‌شود.",
    ],
    options_why_en=[
        "Awareness is lost in absence; preserved awareness is simple focal.",
        "Loss of tone and a fall is atonic; tone is kept in absence.",
        "A long post-ictal period belongs to tonic-clonic or complex focal seizures.",
        "Correct — blinking and fine automatisms are seen in two thirds of absences.",
    ],
    explanation_fa=(
        "ابسانس حمله‌ی چندثانیه‌ای قطع آگاهی است بدون افتادن و بدون گیجی بعد. "
        "اتوماتیسم ظریف (پلک، جویدن) شایع است. EEG: کمپلکس نیزه‌موج ۳ هرتز. "
        "داروی اول اتوسوکسیماید."
    ),
    explanation_en=(
        "Absence is a few seconds of lost awareness without a fall and without "
        "afterwards confusion. Fine automatisms (blink, chew) are common. EEG: "
        "3 Hz spike-and-wave. First drug ethosuximide."
    ),
    micro={
        "lead_fa": "ابسانس: چند ثانیه، نمی‌افتد، گیج نمی‌ماند، اغلب پلک می‌زند.",
        "lead_en": "Absence: a few seconds, no fall, no lingering confusion, often blinking.",
        "points_fa": [
            "سن تیپیک کودک دبستان است.",
            "روزها ده‌ها حمله ممکن است؛ افت تحصیلی سرنخ است.",
            "هیپروتنیلاسیون حمله را برمی‌انگیزد.",
            "اتوسوکسیماید خط اول ابسانس تنها است.",
            "والپروات اگر تونیک-کلونیک هم باشد.",
            "کاربامازپین ابسانس را بدتر می‌کند.",
        ],
        "points_en": [
            "Typical age is primary-school children.",
            "Dozens of attacks a day are possible; falling grades are a clue.",
            "Hyperventilation provokes an attack.",
            "Ethosuximide is first-line for absence alone.",
            "Valproate if tonic-clonic seizures coexist.",
            "Carbamazepine makes absence worse.",
        ],
    },
    golden_fa="ابسانس: ۳ هرتز، نمی‌افتد، پست‌ایکتال ندارد. اتوسوکسیماید.",
    golden_en="Absence: 3 Hz, no fall, no post-ictal phase. Ethosuximide.",
    refs=["Aminoff 2021 — Epilepsy"],
    concept="absence", concept_fa="تشنج غیاب",
    concept_en="Absence seizure")

add("مغز و اعصاب", 102,
    chapter_fa="بیماری‌های دمیلینه", chapter_en="Demyelinating disease",
    options_fa_fix=[
        "مطالعه الکترودیاگنوستیک (نوار عصب-عضله)",
        "الکتروانسفالوگرافی (نوار مغز)",
        "بررسی مایع مغزی نخاعی",
        "سی‌تی‌اسکن مغز",
    ],
    options_why_fa=[
        "EMG-NCS بیماری محیطی است؛ ام‌اس مرکزی است.",
        "EEG برای تشنج است نه پلاک دمیلینه.",
        "پاسخ صحیح — باند الیگوکلونال در CSF تشخیص ام‌اس را حمایت می‌کند.",
        "سی‌تی پلاک ماده سفید را نمی‌بیند؛ MRI آزمون تصویربرداری است که در گزینه‌ها نیست.",
    ],
    options_why_en=[
        "EMG-NCS is for peripheral disease; MS is central.",
        "EEG is for seizures, not demyelinating plaques.",
        "Correct — oligoclonal bands in CSF support the diagnosis of MS.",
        "CT misses white-matter plaques; MRI is the imaging test and is not listed.",
    ],
    explanation_fa=(
        "نوریت اپتیک + علامت لرمیت = دو ضایعه در دو جا و دو زمان: ام‌اس. "
        "از میان گزینه‌ها فقط CSF (باند الیگوکلونال) کمک تشخیصی است. "
        "آزمون تصویربرداری ارجح MRI است که اینجا نیامده."
    ),
    explanation_en=(
        "Optic neuritis plus Lhermitte = two lesions in two places and times: MS. "
        "Of the listed tests only CSF (oligoclonal bands) helps. The preferred "
        "imaging test is MRI, which is not listed."
    ),
    micro={
        "lead_fa": "نوریت اپتیک + لرمیت = ام‌اس. تأیید آزمایشگاهی در این گزینه‌ها: CSF.",
        "lead_en": "Optic neuritis plus Lhermitte is MS. The laboratory confirmation among these options is CSF.",
        "points_fa": [
            "علامت لرمیت: شوک برقی با خم کردن گردن = ضایعه‌ی ستون خلفی گردن.",
            "نوریت اپتیک: تاری یک‌چشمی دردناک، RAPD، کاهش دید رنگی.",
            "معیار مک‌دونالد: پراکندگی در مکان و زمان.",
            "MRI مغز و نخاع با گادولینیوم آزمون تصویربرداری انتخابی است.",
            "CSF: باند الیگوکلونال که در سرم نیست.",
            "سی‌تی برای پلاک ام‌اس حساس نیست.",
            "نوار عصب محیطی طبیعی است؛ این بیماری CNS است.",
        ],
        "points_en": [
            "Lhermitte: electric shock on neck flexion = a dorsal-column cervical lesion.",
            "Optic neuritis: painful monocular blur, RAPD, washed-out colour.",
            "McDonald criteria: dissemination in space and time.",
            "MRI of brain and cord with gadolinium is the imaging test of choice.",
            "CSF: oligoclonal bands absent from serum.",
            "CT is insensitive for MS plaques.",
            "Peripheral nerve conduction is normal; this is a CNS disease.",
        ],
    },
    golden_fa="لرمیت + نوریت اپتیک → ام‌اس. در این گزینه‌ها CSF؛ در عمل MRI.",
    golden_en="Lhermitte plus optic neuritis → MS. Among these options CSF; in practice MRI.",
    refs=["Aminoff 2021 — Multiple sclerosis"],
    concept="ms-diagnosis", concept_fa="تشخیص ام‌اس",
    concept_en="Diagnosing MS")


def apply():
    files = sorted(glob.glob(os.path.join(HERE, "import-payload.archive.part*.json")))
    n = 0
    for path in files:
        body = json.load(open(path, encoding="utf-8"))
        changed = False
        for q in body["questions"]:
            if q.get("year_num") != 1402:
                continue
            rec = L.get((q["subject_fa"], q["question_no"]))
            if not rec:
                continue
            if rec.get("options_fa_fix"):
                q["options_fa"] = rec["options_fa_fix"]
            if rec.get("key_corrected"):
                q["original_correct_index"] = rec["original_correct_index"]
                q["correct_index"] = rec["correct_index"]
                q["key_corrected"] = True
                q["key_correction_fa"] = rec["key_correction_fa"]
                q["key_correction_en"] = rec["key_correction_en"]
                q["key_correction_source"] = rec["key_correction_source"]
            q["chapter_fa"] = rec["chapter_fa"]
            q["chapter_en"] = rec["chapter_en"]
            q["options_why_fa"] = rec["options_why_fa"]
            q["options_why_en"] = rec["options_why_en"]
            q["explanation_fa"] = rec["explanation_fa"]
            q["explanation_en"] = rec["explanation_en"]
            q["micro"] = rec["micro"]
            q["golden_fa"] = rec["golden_fa"]
            q["golden_en"] = rec["golden_en"]
            q["refs"] = rec["refs"]
            q["concept"] = rec["concept"]
            q["concept_fa"] = rec["concept_fa"]
            q["concept_en"] = rec["concept_en"]
            q["needs_lesson"] = False
            q["lesson_part"] = 1
            n += 1
            changed = True
        if changed:
            json.dump(body, open(path, "w", encoding="utf-8"), ensure_ascii=False)
    print(f"applied lessons to {n} Khordad-1402 questions")
    print("keys:", ", ".join(f"{s} q{no}" for s, no in sorted(L)))


if __name__ == "__main__":
    apply()
