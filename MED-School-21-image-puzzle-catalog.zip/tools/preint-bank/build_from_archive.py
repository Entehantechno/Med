# -*- coding: utf-8 -*-
"""Build official-import payloads for every pre-internship sitting that has
both extracted stems (archive.json) and an official answer key.

Questions ship as bank-only (searchable + exam-sim) until a microlesson is
written. Official English is attached when a ministry booklet exists.
"""
import io, json, os, re, hashlib

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..'))
ARCHIVE = os.path.join(ROOT, 'tools', 'exam-booklets', 'archive.json')
KEYS = os.path.join(ROOT, 'tools', 'exam-booklets', 'keys')
EN_1402 = os.path.join(ROOT, 'tools', 'exam-booklets', 'out', 'en_1402_03.json')
PAIR_1400 = os.path.join(ROOT, 'tools', 'exam-booklets', 'pair_1400_12.json')
OUT = HERE

MONTH = {
    'خرداد': ('خرداد', 'Khordad', 'midterm'),
    'شهریور': ('شهریور', 'Shahrivar', 'main'),
    'اسفند': ('اسفند', 'Esfand', 'main'),
    'آذر': ('آذر', 'Azar', 'midterm'),
    'آبان': ('آبان', 'Aban', 'midterm'),
    'دی': ('دی', 'Dey', 'midterm'),
}

# Map archive subject labels onto the seeded topic names / tracks.
SUBJECT = {
    'داخلی': ('داخلی', 'Internal Medicine', 'major'),
    'جراحی': ('جراحی', 'Surgery', 'major'),
    'کودکان': ('کودکان', 'Pediatrics', 'major'),
    'زنان و زایمان': ('زنان و زایمان', 'Obstetrics and Gynecology', 'major'),
    'مغز و اعصاب': ('مغز و اعصاب', 'Neurology', 'minor'),
    'نورولوژی': ('مغز و اعصاب', 'Neurology', 'minor'),
    'عفونی': ('عفونی', 'Infectious Diseases', 'minor'),
    'بیماری‌های عفونی': ('عفونی', 'Infectious Diseases', 'minor'),
    'پوست': ('پوست', 'Dermatology', 'minor'),
    'پاتولوژی': ('پاتولوژی', 'Pathology', 'minor'),
    'روان‌پزشکی': ('روانپزشکی', 'Psychiatry', 'minor'),
    'روانپزشکی': ('روانپزشکی', 'Psychiatry', 'minor'),
    'رادیولوژی': ('رادیولوژی', 'Radiology', 'minor'),
    'فارماکولوژی': ('فارماکولوژی', 'Pharmacology', 'minor'),
    'گوش و حلق و بینی': ('گوش و حلق و بینی', 'ENT', 'minor'),
    'ارتوپدی': ('ارتوپدی', 'Orthopedics', 'minor'),
    'اورولوژی': ('اورولوژی', 'Urology', 'minor'),
    'چشم‌پزشکی': ('چشم‌پزشکی', 'Ophthalmology', 'minor'),
    'اپیدمیولوژی و آمار': ('آمار و اپیدمیولوژی', 'Statistics & Epidemiology', 'minor'),
    'اخلاق پزشکی': ('اخلاق پزشکی', 'Medical Ethics', 'minor'),
    'ژنتیک': ('ژنتیک پزشکی', 'Medical Genetics', 'minor'),
    'ژنتیک پزشکی': ('ژنتیک پزشکی', 'Medical Genetics', 'minor'),
    'ایمونولوژی': ('ایمونولوژی', 'Immunology', 'minor'),
    'تغذیه': ('تغذیه', 'Nutrition', 'minor'),
    'فیزیک پزشکی': ('فیزیک پزشکی', 'Medical Physics', 'minor'),
}

YEAR_FA = {
    '1400': '۱۴۰۰', '1401': '۱۴۰۱', '1402': '۱۴۰۲', '1403': '۱۴۰۳',
    '1404': '۱۴۰۴', '1399': '۱۳۹۹', '1398': '۱۳۹۸',
}


def load_key(path):
    raw = json.load(io.open(path, encoding='utf-8'))
    out = {}
    for k, v in raw.items():
        if k.startswith('_'):
            continue
        try:
            out[int(k)] = int(v)
        except (TypeError, ValueError):
            continue
    return out


def clean(s):
    s = (s or '').replace('\x00', '')
    s = s.replace('\ufffd', '')
    s = re.sub(r'\s+', ' ', s).strip()
    return s


def main():
    arch = json.load(io.open(ARCHIVE, encoding='utf-8'))
    qs = arch['questions']

    en_by = {}
    if os.path.exists(EN_1402):
        for r in json.load(io.open(EN_1402, encoding='utf-8')):
            en_by[('1402-03', r['question_no'])] = r
    if os.path.exists(PAIR_1400):
        for r in json.load(io.open(PAIR_1400, encoding='utf-8')):
            en_by[('1400-12', r['question_no'])] = r

    jobs = [
        ('1402-03', os.path.join(KEYS, '1402-03.json'), 'with_floating'),
        ('1403-06', os.path.join(KEYS, '1403-06.json'), 'with_floating'),
    ]

    all_rows = []
    report = []
    for sitting, key_path, variant in jobs:
        if not os.path.exists(key_path):
            report.append(f'{sitting}: KEY MISSING {key_path}')
            continue
        key = load_key(key_path)
        pool = [q for q in qs if q.get('sitting') == sitting and q.get('variant') == variant]
        if not pool:
            pool = [q for q in qs if q.get('sitting') == sitting]
        used = 0
        skipped = 0
        with_en = 0
        for q in pool:
            no = int(q.get('no') or 0)
            if no not in key:
                skipped += 1
                continue
            en_rec = en_by.get((sitting, no)) or {}
            opts = [clean(x) for x in (q.get('options_fa') or [])]
            fa_opts_from_en = False
            if len(opts) != 4 or not all(opts):
                en_opts = [clean(x) for x in (en_rec.get('options_en') or [])]
                if len(en_opts) == 4 and all(en_opts):
                    opts = en_opts
                    fa_opts_from_en = True
                else:
                    skipped += 1
                    continue
            stem = clean(q.get('stem_fa') or '')
            if len(stem) < 20:
                skipped += 1
                continue
            ans = key[no]
            if not (0 <= ans <= 3):
                skipped += 1
                continue
            if en_rec.get('subject_fa'):
                fa, en, track = (en_rec['subject_fa'], en_rec['subject_en'],
                                 en_rec.get('subject_track') or 'minor')
            else:
                fa, en, track = SUBJECT.get(q.get('subject') or '',
                                            (q.get('subject') or 'متفرقه',
                                             'Other', 'minor'))
            year = str(q.get('year') or sitting.split('-')[0])
            month_fa = q.get('month') or ''
            m_fa, m_en, kind = MONTH.get(month_fa, (month_fa, month_fa, 'main'))
            en_rec = en_by.get((sitting, no)) or {}
            row = {
                'question_no': no,
                'subject_fa': fa,
                'subject_en': en,
                'subject_track': track,
                'chapter_fa': f'آزمون {m_fa} {YEAR_FA.get(year, year)}',
                'chapter_en': f'{m_en} {year} paper',
                'question_fa': stem,
                'question_en': clean(en_rec.get('stem_en') or ''),
                'options_fa': opts,
                'options_en': en_rec.get('options_en') or ['', '', '', ''],
                'correct_index': ans,
                'year': YEAR_FA.get(year, year),
                'year_num': int(year),
                'month': m_fa,
                'month_en': m_en,
                'sitting': kind,
                'scope': 'ملی',
                'scope_en': 'national',
                'label_fa': f'پیش‌کارورزی {m_fa} {YEAR_FA.get(year, year)}',
                'label_en': f'Pre-internship {m_en} {year}',
                'exam_type': 'preinternship',
                'source': 'دفترچه رسمی مرکز سنجش آموزش پزشکی',
                'license': 'official_ministry_booklet',
                'key_source': 'official',
                'en_source': en_rec.get('en_source') or '',
                'needs_lesson': True,
                'difficulty': 'medium',
                'type': 'mcq',
                'answerMode': 'choice',
            }
            if fa_opts_from_en:
                row['options_fa_source'] = 'official_en_booklet'
            # Official key of Q99 (ICH vs ischemic) marks aphasia; the
            # discriminating feature is headache+vomiting (Aminoff).
            if sitting == '1402-03' and no == 99 and ans == 2:
                row['original_correct_index'] = 2
                row['correct_index'] = 1
                row['key_corrected'] = True
                row['key_correction_fa'] = (
                    'کلید چاپی گزینهٔ «آفازی» را زده؛ آفازی به محل ضایعه بستگی دارد '
                    'نه به نوع سکته. سردرد و استفراغ نشانهٔ افزایش فشار داخل‌جمجمه '
                    'و به نفع خون‌ریزی است.'
                )
                row['key_correction_en'] = (
                    'The printed key marks aphasia; aphasia is location-dependent. '
                    'Headache and vomiting reflect raised ICP and favour ICH.'
                )
                row['key_correction_source'] = 'Aminoff 2021'
                row['explanation_fa'] = 'تصحیح کلید رسمی. ' + row['key_correction_fa']
                row['explanation_en'] = 'Official key corrected. ' + row['key_correction_en']
            if row['question_en']:
                with_en += 1
            else:
                row['question_en'] = ''
            all_rows.append(row)
            used += 1
        report.append(f'{sitting}: imported {used}  skipped {skipped}  official_en {with_en}  key_size {len(key)}  pool {len(pool)}')

    # Dedup by fingerprint of FA stem (same sitting+number is already unique).
    seen = set()
    uniq = []
    for r in all_rows:
        fp = re.sub(r'\s+', ' ', r['question_fa'])[:220]
        if fp in seen:
            continue
        seen.add(fp)
        uniq.append(r)

    os.makedirs(OUT, exist_ok=True)
    # Split by subject so bankbootstrap picks them up as named parts.
    by_subj = {}
    for r in uniq:
        by_subj.setdefault(r['subject_fa'], []).append(r)

    parts = []
    # One payload per subject keeps files under the 2 MB HTTP limit and
    # gives bankbootstrap a stable subject_fa to log.
    idx = 1
    for subj, rows in sorted(by_subj.items(), key=lambda kv: (-len(kv[1]), kv[0])):
        rows.sort(key=lambda r: (r['year_num'], r['month'], r['question_no']))
        body = {
            'program': 'preint',
            'subject_fa': rows[0]['subject_fa'],
            'subject_en': rows[0]['subject_en'],
            'subject_track': rows[0]['subject_track'],
            'exam_type': 'preinternship',
            'maxPerLesson': 15,
            'source': 'دفترچه رسمی مرکز سنجش آموزش پزشکی',
            'license': 'official_ministry_booklet',
            'questions': rows,
        }
        name = f'import-payload.archive.part{idx:02d}.json'
        dest = os.path.join(OUT, name)
        json.dump(body, io.open(dest, 'w', encoding='utf-8'), ensure_ascii=False)
        parts.append((name, subj, len(rows), os.path.getsize(dest)))
        idx += 1

    print('REPORT')
    for line in report:
        print(' ', line)
    print(f'total unique {len(uniq)}  files {len(parts)}')
    for name, subj, n, sz in parts:
        print(f'  {name:40} {n:4}  {subj:20}  {sz/1024:.1f} KB')

    # Re-attach authored microlessons so a rebuild does not wipe them.
    apply = os.path.join(HERE, 'apply_lessons_1402_03.py')
    if os.path.exists(apply):
        import runpy
        runpy.run_path(apply, run_name='__main__')


if __name__ == '__main__':
    main()
