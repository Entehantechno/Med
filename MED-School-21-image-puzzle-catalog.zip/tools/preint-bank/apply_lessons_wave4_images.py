# -*- coding: utf-8 -*-
"""Wave 4: last two booklet items (1403 radio 111, derm 128).
Teaching SVGs attach at runtime via schematics.js — no ministry film on disk.
"""
import json, glob, os

HERE = os.path.dirname(os.path.abspath(__file__))
L = {}


def add(subj, no, year=1403, **kw):
    L[(year, subj, no)] = kw


def pts(fa, en):
    return {"lead_fa": fa[0], "lead_en": en[0], "points_fa": fa[1:], "points_en": en[1:]}


add("رادیولوژی", 111,
    chapter_fa="شکم / انسداد روده بزرگ", chapter_en="Abdomen / large-bowel obstruction",
    options_why_fa=[
        "انسداد مکانیک روده باریک حلقه‌های مرکزی و سطح مایع متعدد است؛ هاسترای محیطی و کات‌آف کولون ندارد.",
        "پرفوراسیون اولسر هوای آزاد زیر دیافراگم می‌خواهد؛ گرافی خوابیده+دمر برای هوا آزاد انتخاب اول نیست (ایستاده/دکوبیتوس چپ).",
        "ایلئوس پانکراتیت همهٔ روده‌ها را یکدست گشاد می‌کند و گاز تا رکتوم می‌رود.",
        "پاسخ صحیح — درد بالای شکم + گرافی خوابیده و دمر: کولون محیطی گشاد، کات‌آف، گاز رکتوم در دمر پر نمی‌شود = **انسداد روده بزرگ**.",
    ],
    options_why_en=[
        "Mechanical SBO is central loops and many air-fluid levels; it does not show peripheral haustra and a colonic cutoff.",
        "A perforated ulcer wants free air under the diaphragm; supine+prone is not the first film for free air (erect / left decubitus).",
        "Pancreatic ileus dilates all bowel evenly and gas still reaches the rectum.",
        "Correct — upper abdominal pain + supine and prone films: peripheral dilated colon, a cutoff, rectum empty on prone = **large-bowel obstruction**.",
    ],
    explanation_fa="جفت خوابیده/دمر توزیع گاز را نشان می‌دهد: اگر در دمر گاز به رکتوم نرود انسداد کامل کولون است. ولوولوس سیگموئید و تومور چپ شایع‌اند. هوای آزاد را با ایستاده جدا کن. طرح آموزشی جای فیلم دفترچه می‌نشیند.",
    explanation_en="The supine/prone pair shows gas shift: if prone gas never reaches the rectum, the colon is fully obstructed. Sigmoid volvulus and a left-sided tumour are common. Separate free air on an erect film. A teaching schematic stands in for the missing booklet radiograph.",
    micro=pts(
        ["خوابیده+دمر = توزیع گاز کولون.",
         "کولون محیطی و هاسترا دارد.",
         "باریک مرکزی و والو دارد.",
         "دمر بدون گاز رکتوم = LBO کامل.",
         "ایلئوس رکتوم را پر می‌کند.",
         "هوای آزاد = پرفوراسیون؛ فیلم ایستاده.",
         "ولوولوس سیگموئید قهوهٔ دانه.",
         "سecal >۱۲ cm خطر پاره شدن.",
         "CT بعد از گرافی اگر پایدار است.",
         "NGT و جراحی برای انسداد مکانیک.",
         "Felson / Sabiston obstruction."],
        ["Supine+prone = colonic gas shift.",
         "Colon is peripheral and has haustra.",
         "Small bowel is central and has valvulae.",
         "Prone rectum empty = complete LBO.",
         "Ileus still fills the rectum.",
         "Free air = perforation; take an erect film.",
         "Sigmoid volvulus is a coffee bean.",
         "Cecum >12 cm risks perforation.",
         "CT after the plain film if the patient is stable.",
         "NGT and surgery for a mechanical block.",
         "Felson / Sabiston obstruction."],
    ),
    golden_fa="خوابیده و دمر + کولون گشاد بدون گاز رکتوم: **انسداد روده بزرگ**.",
    golden_en="Supine and prone + dilated colon and an empty rectum: **large-bowel obstruction**.",
    refs=["Felson chest/abdomen", "Sabiston obstruction"],
    concept="lbo-supine-prone", concept_fa="LBO خوابیده دمر", concept_en="LBO supine prone",
    question_en="A 20-year-old woman has severe upper abdominal pain. Supine and prone abdominal films are taken. Given the image, the most likely diagnosis is:",
    options_en=["Mechanical small-bowel obstruction", "Perforated peptic ulcer", "Ileus after pancreatitis", "Large-bowel obstruction"])

add("پوست", 128,
    chapter_fa="ارتوپدی / دررفتگی آرنج باز", chapter_en="Ortho / open elbow dislocation",
    options_why_fa=[
        "گچ بلند ۶ هفته درمان دررفتگی حاد دفرمهٔ باز نیست؛ اول جااندازی.",
        "جنتامایسین مال گوستیلیو III است؛ زخم ۷ cm تایپ **II** است و سفازولین تنها کافی است.",
        "پاسخ صحیح — دررفتگی خلفی آرنج (طرح آموزشی فیلم دفترچه) معمولاً **بسته جا می‌رود**؛ بعد ثبات را بسنج.",
        "گوستیلیو III زخم >۱۰ cm یا لهیدگی شدید/آلودگی مزرعه است؛ ۷ cm تایپ II است.",
    ],
    options_why_en=[
        "A 6-week long-arm cast is not the treatment of an acute deformed open dislocation; reduce first.",
        "Gentamicin is for Gustilo III; a 7 cm wound is type **II** and cefazolin alone is enough.",
        "Correct — a posterior elbow dislocation (teaching stand-in for the booklet film) is usually **reduced closed**; then test stability.",
        "Gustilo III is a wound >10 cm or severe crush/farm dirt; 7 cm is type II.",
    ],
    explanation_fa="سقوط دوچرخه + ساعد دفرمه + زخم ۷ cm = دررفتگی باز آرنج تا خلاف ثابت شود. جااندازی بسته اورژانس، معاینه عصب (اولنار/مدین/اینتراوسئوس) و نبض براکیال. گوستیلیو: I<۱ cm، II ۱–۱۰، III>۱۰. طرح آموزشی جای رادیوگرافی دفترچه است.",
    explanation_en="A bicycle fall + a deformed forearm + a 7 cm wound is an open elbow dislocation until proven otherwise. Emergency closed reduction, then the nerves (ulnar/median/PIN) and the brachial pulse. Gustilo: I<1 cm, II 1–10, III>10. The schematic stands in for the missing radiograph.",
    micro=pts(
        ["دررفتگی آرنج معمولاً بسته جا می‌رود.",
         "زخم ۷ cm = گوستیلیو II نه III.",
         "II: سفازولین؛ III: +جنتا (±پنی‌سیلین مزرعه).",
         "گچ تنها درمان دفرمیتهٔ حاد نیست.",
         "بعد جااندازی گرافی و ثبات.",
         "اگر ناپایدار یا خرد شد: جراحی.",
         "عصب اولنار و PIN را بنویس.",
         "نبض را قبل و بعد جااندازی بگیر.",
         "مونتجیا: اولنا + سر رادیوس؛ بزرگسال اغلب فیکس اولنا.",
         "کزاز را چک کن.",
         "Rockwood / Gustilo."],
        ["An elbow dislocation usually reduces closed.",
         "A 7 cm wound = Gustilo II, not III.",
         "II: cefazolin; III: +gent (±penicillin on a farm).",
         "A cast alone is not treatment of an acute deformity.",
         "After reduction: a film and a stability exam.",
         "Unstable or a fracture: operate.",
         "Write down the ulnar nerve and PIN.",
         "Feel the pulse before and after reduction.",
         "Monteggia: ulna + radial head; adults often fix the ulna.",
         "Check tetanus.",
         "Rockwood / Gustilo."],
    ),
    golden_fa="زخم ۷ cm ساعد + دررفتگی: **جااندازی بسته**؛ گوستیلیو II نه III.",
    golden_en="A 7 cm forearm wound + a dislocation: **closed reduction**; Gustilo II, not III.",
    refs=["Rockwood", "Gustilo-Anderson"],
    concept="open-elbow-closed-reduce", concept_fa="جااندازی بسته آرنج", concept_en="Closed reduce elbow",
    question_en="A 20-year-old fell from a race bicycle, has a 7 cm bleeding wound on the right forearm and a deformed limb. Given the radiograph, which statement is correct?",
    options_en=["The fracture can be treated with 6 weeks in a long-arm cast", "Antibiotics are a first-generation cephalosporin plus gentamicin", "The dislocation is usually reduced closed", "The open-fracture wound is Gustilo type 3"])


def apply():
    files = sorted(glob.glob(os.path.join(HERE, "import-payload.archive.part*.json")))
    n = 0
    for path in files:
        body = json.load(open(path, encoding="utf-8"))
        changed = False
        for q in body["questions"]:
            rec = L.get((int(q.get("year_num") or 0), q.get("subject_fa"), int(q.get("question_no") or 0)))
            if not rec:
                continue
            for k in ("chapter_fa", "chapter_en", "options_why_fa", "options_why_en",
                      "explanation_fa", "explanation_en", "micro", "golden_fa", "golden_en",
                      "refs", "concept", "concept_fa", "concept_en"):
                q[k] = rec[k]
            if rec.get("question_en") and q.get("en_source") != "official_booklet":
                q["question_en"] = rec["question_en"]
                q["options_en"] = rec.get("options_en") or q.get("options_en")
                q["en_source"] = "teaching_translation"
            q["needs_lesson"] = False
            q["lesson_part"] = 1
            n += 1
            changed = True
        if changed:
            json.dump(body, open(path, "w", encoding="utf-8"), ensure_ascii=False)
    print(f"applied lessons to {n} questions")
    print("keys:", ", ".join(f"{y} {s} q{no}" for y, s, no in sorted(L)))


if __name__ == "__main__":
    apply()
