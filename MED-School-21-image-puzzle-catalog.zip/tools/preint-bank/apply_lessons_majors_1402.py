# -*- coding: utf-8 -*-
"""Bilingual microlessons for Khordad-1402 majors: surgery, peds, OB/GYN.

Official English stems/options from the ministry booklet are never rewritten.
Competitive path: one representative cluster per major (max topics, min Q).
"""
import json, glob, os

HERE = os.path.dirname(os.path.abspath(__file__))
L = {}


def add(subj, no, **kw):
    L[(subj, no)] = kw


# ─────────────────────────── SURGERY 43–46 ───────────────────────────
add("جراحی", 43,
    chapter_fa="عفونت نسج نرم", chapter_en="Soft-tissue infection",
    options_why_fa=[
        "کمپرس سرد و کنترل قند برای سلولیت خفیف است، نه برای فاسییت نکروزان.",
        "درناژ تحت سونوگرافی مال آبسهٔ لوکالیزه است؛ اینجا بافت مرده وسیع است.",
        "پوشش گرم‌مثبت و بی‌هوازی لازم است ولی بدون دبریدمان بیمار می‌میرد.",
        "پاسخ صحیح — فاسییت نکروزان: آنتی‌بیوتیک وسیع‌الطیف به‌علاوهٔ دبریدمان فوری.",
    ],
    options_why_en=[
        "Cold compress and sugar control are for mild cellulitis, not necrotising fasciitis.",
        "Ultrasound-guided drainage is for a localised abscess; here the dead tissue is extensive.",
        "Gram-positive and anaerobic cover is needed, but without debridement the patient dies.",
        "Correct — necrotising fasciitis: broad-spectrum antibiotics plus immediate debridement.",
    ],
    explanation_fa=(
        "دیابتی با درد شدید کشاله، ادم وسیع‌تر از اریتم، بی‌حسی پوست، تاول و بوی بد "
        "تعریف بالینی فاسییت نکروزان است. درد نامتناسب و حس پوست رفته یعنی نکروز "
        "زیرجلد. نجات جان دبریدمان جراحی فوری است؛ آنتی‌بیوتیک تنها کافی نیست."
    ),
    explanation_en=(
        "A diabetic with severe groin pain, oedema beyond the erythema, numb skin, "
        "blisters and a foul smell is clinical necrotising fasciitis. Pain out of "
        "proportion and lost skin sensation mean subcutaneous necrosis. Survival "
        "is immediate surgical debridement; antibiotics alone are not enough."
    ),
    micro={
        "lead_fa": "درد نامتناسب + بی‌حسی پوست + تاول در دیابتی = فاسییت نکروزان → اتاق عمل همین حالا.",
        "lead_en": "Pain out of proportion + numb skin + blisters in a diabetic is necrotising fasciitis → theatre now.",
        "points_fa": [
            "فاسییت نکروزان عفونت عمقی فاشیا است نه سلولیت سطحی.",
            "درد بسیار بیشتر از ظاهر پوست است.",
            "ادم فراتر از اریتم، کپیتاسیون، تاول و حس‌رفتگی پوست کلاسیک‌اند.",
            "دیابت، چاقی و نقص ایمنی زمینه‌اند.",
            "نوع ۱ پلی‌میکروبی (بی‌هوازی + گرم‌منفی) در دیابتی شایع است.",
            "نوع ۲ استرپ گروه A در میزبان سالم‌تر است.",
            "امتیاز LRINEC آزمایشگاهی کمکی است، تشخیص بالینی است.",
            "درمان: احیا + پیپراسیلین-تازوباکتام یا کارباپنم + کلینداماییسین + ونکومایسین، و دبریدمان.",
            "کلینداماییسین تولید توکسین استرپ را کم می‌کند.",
            "تأخیر دبریدمان مرگ‌ومیر را چند برابر می‌کند.",
        ],
        "points_en": [
            "Necrotising fasciitis is deep fascia, not superficial cellulitis.",
            "Pain is far greater than the skin appearance.",
            "Oedema beyond erythema, crepitus, blisters and anaesthesia are classic.",
            "Diabetes, obesity and immunodeficiency are the usual background.",
            "Type 1 is polymicrobial (anaerobes + Gram-negatives) and common in diabetics.",
            "Type 2 is group-A strep in a healthier host.",
            "The LRINEC score is an adjunct; the diagnosis is clinical.",
            "Treat with resuscitation + piperacillin-tazobactam or a carbapenem + clindamycin + vancomycin, and debridement.",
            "Clindamycin cuts streptococcal toxin production.",
            "Delaying debridement multiplies mortality.",
        ],
    },
    golden_fa="فاسییت نکروزان: دبریدمان فوری + آنتی‌بیوتیک وسیع. آنتی‌بیوتیک تنها = مرگ.",
    golden_en="Necrotising fasciitis: immediate debridement plus broad antibiotics. Antibiotics alone means death.",
    refs=["Schwartz / Sabiston — Necrotizing soft-tissue infection"],
    concept="nec-fasciitis", concept_fa="فاسییت نکروزان", concept_en="Necrotising fasciitis")

add("جراحی", 44,
    chapter_fa="ترومای قفسه سینه", chapter_en="Chest trauma",
    options_why_fa=[
        "پاسخ صحیح — شکستگی دنده ۲ و ۳ + مدیاستن پهن = شک به آئورت؛ CT با کنتراست.",
        "لاپاروسکوپی تشخیصی برای شکم ناپایدار است؛ اینجا شکم مطرح نیست.",
        "توراکوسکوپی تشخیصی قدم اول تصویربرداری عروق نیست.",
        "فقط مانیتورینگ یک پارگی آئورت را از دست می‌دهد.",
    ],
    options_why_en=[
        "Correct — 2nd and 3rd rib fractures plus a wide mediastinum mean aortic injury until proven otherwise; contrast CT.",
        "Diagnostic laparoscopy is for an unstable abdomen; the abdomen is not the issue here.",
        "Diagnostic thoracoscopy is not the first vascular imaging step.",
        "Ward monitoring alone misses an aortic tear.",
    ],
    explanation_fa=(
        "ترومای پرسرعت موتور با شکستگی دنده‌های اول تا سوم و مدیاستن پهن "
        "تا خلافش ثابت نشود پارگی آئورت نزولی در لیگامان شریانی است. بیمار "
        "پایدار است پس CT آنژیو قفسه سینه قدم درست است نه انتقال به بخش."
    ),
    explanation_en=(
        "High-speed motorcycle trauma with upper-rib fractures and a wide "
        "mediastinum is a descending aortic tear at the ligamentum arteriosum "
        "until proven otherwise. The patient is stable, so chest CT angiography "
        "is the right step, not a ward transfer."
    ),
    micro={
        "lead_fa": "دنده ۱–۳ شکسته + مدیاستن پهن = CT آنژیو قفسه برای آئورت.",
        "lead_en": "Broken ribs 1–3 plus a wide mediastinum means chest CT angiography for the aorta.",
        "points_fa": [
            "آئورت نزولی درست بعد از ساب‌کلاوین چپ در شتاب ناگهانی پاره می‌شود.",
            "دنده‌های اول و دوم محافظت‌شده‌اند؛ شکستنشان یعنی نیروی زیاد.",
            "علائم رادیوگرافی: مدیاستن پهن، کانتور آئورت محو، انحراف NGT، شکستگی دنده بالا.",
            "بیمار ناپایدار با شک قوی به اتاق عمل یا اتاق هیبرید می‌رود.",
            "بیمار پایدار CT آنژیو می‌گیرد.",
            "درمان انتخابی امروز استنت گرافت داخل‌عروقی است.",
            "لاپاروسکوپی و توراکوسکوپی این تشخیص را نمی‌دهند.",
        ],
        "points_en": [
            "The descending aorta tears just beyond the left subclavian in sudden deceleration.",
            "The first and second ribs are protected; breaking them means huge force.",
            "Radiograph clues: wide mediastinum, lost aortic contour, NGT deviation, high rib fractures.",
            "An unstable patient with a strong suspicion goes to theatre or a hybrid room.",
            "A stable patient gets CT angiography.",
            "Today's treatment of choice is an endovascular stent graft.",
            "Laparoscopy and thoracoscopy do not make this diagnosis.",
        ],
    },
    golden_fa="مدیاستن پهن بعد از ترومای پرسرعت = CT آنژیو، نه مشاهده.",
    golden_en="A wide mediastinum after high-speed trauma is CT angiography, not observation.",
    refs=["ATLS 10 / Schwartz — Blunt aortic injury"],
    concept="blunt-aorta", concept_fa="آسیب آئورت بلانت", concept_en="Blunt aortic injury")

add("جراحی", 45,
    chapter_fa="ترومای نافذ", chapter_en="Penetrating trauma",
    options_why_fa=[
        "پاسخ صحیح — مسیر گلوله توراکوآبدومینال + شوک = احیا و اتاق عمل، نه تصویر.",
        "لاواژ صفاق در ناپایدار وقت تلف می‌کند و تصمیم را عوض نمی‌کند.",
        "سونوگرافی در شوک تأخیر جراحی است.",
        "CT شکم مخصوص بیمار پایدار است.",
    ],
    options_why_en=[
        "Correct — a thoraco-abdominal bullet track plus shock means resuscitate and go to theatre, not imaging.",
        "Peritoneal lavage in an unstable patient wastes time and will not change the decision.",
        "Ultrasound in shock delays the operation.",
        "Abdominal CT is for the stable patient.",
    ],
    explanation_fa=(
        "ورود زیر لبه دنده خلف راست و خروج بالای ناف یعنی مسیر از قفسه به شکم. "
        "فشار ۹۰ روی ۷۰ و نبض ۱۱۰ شوک کلاس III است. در ترومای نافذ ناپایدار "
        "تصویربرداری جایی ندارد؛ احیا همزمان با انتقال به اتاق عمل است."
    ),
    explanation_en=(
        "Entry below the right costal margin posteriorly and exit above the "
        "umbilicus is a chest-to-abdomen track. BP 90/70 and pulse 110 is class "
        "III shock. Unstable penetrating trauma is not imaged; resuscitate on "
        "the way to the operating room."
    ),
    micro={
        "lead_fa": "نافذ + شوک = اتاق عمل. CT مال پایدار است.",
        "lead_en": "Penetrating plus shock means theatre. CT is for the stable.",
        "points_fa": [
            "ناحیه توراکوآبدومینال: نوک اسکاپول تا لبه دنده تا ناف.",
            "گلوله این ناحیه می‌تواند دیافراگم، کبد، ریه و کولون را با هم بزند.",
            "شوک در نافذ = خونریزی داخل‌صفاق یا توراکس تا خلافش ثابت شود.",
            "ATLS: راه هوایی، تنفس، گردش خون؛ دو رگ درشت و خون.",
            "DPL و سونوگرافی FAST در پایدار برای شک کمک‌اند نه در شوک واضح.",
            "لاپاراتومی اکسپلوراتیو استاندارد ناپایدار نافذ شکم است.",
            "اگر قفسه هم درگیر است، توراکوتومی همزمان ممکن است لازم شود.",
        ],
        "points_en": [
            "The thoraco-abdominal zone runs from the scapular tip to the costal margin to the umbilicus.",
            "A missile here can hit diaphragm, liver, lung and colon together.",
            "Shock in penetrating trauma is intra-abdominal or thoracic bleeding until proven otherwise.",
            "ATLS: airway, breathing, circulation; two large-bore lines and blood.",
            "DPL and FAST help the equivocal stable patient, not frank shock.",
            "Exploratory laparotomy is the standard for unstable penetrating abdomen.",
            "If the chest is also involved a simultaneous thoracotomy may be needed.",
        ],
    },
    golden_fa="گلوله توراکوآبدومینال + شوک → OR. تصویر نگیر.",
    golden_en="Thoraco-abdominal GSW plus shock → OR. Do not image.",
    refs=["ATLS 10 — Penetrating abdominal trauma"],
    concept="gsw-shock", concept_fa="گلوله و شوک", concept_en="Gunshot and shock")

add("جراحی", 46,
    chapter_fa="فتق", chapter_en="Hernia",
    options_why_fa=[
        "جااندازی موفق و ترخیص، خطر نکروز خاموش و عود فوری را نادیده می‌گیرد.",
        "پاسخ صحیح — فتقی که دیگر جا نمی‌رود (incarcerated) را جا بینداز و همان بستری جراحی زودرس کن.",
        "جراحی اورژانس بدون جااندازی مال علائم پریتونیت یا شک به استرانگولاسیون است.",
        "CT وقتی لازم است که تشخیص نامعلوم باشد؛ اینجا فتق واضح است.",
    ],
    options_why_en=[
        "Successful reduction and discharge ignores silent necrosis and early recurrence.",
        "Correct — a hernia that no longer reduces (incarcerated) is reduced and then kept for early surgery.",
        "Emergency surgery without reduction is for peritonitis or suspected strangulation.",
        "CT is for an unclear diagnosis; here the hernia is obvious.",
    ],
    explanation_fa=(
        "سابقه فتق قابل جااندازی که حالا دردناک است و درازکش برنمی‌گردد یعنی "
        "incarceration. تب و لکوسیتوز و التهاب پوست ندارد پس استرانگولاسیون "
        "مطرح نیست. جااندازی آرام مجاز است و بعد باید در همان بستری ترمیم شود "
        "چون محتویات آسیب‌دیده ممکن است برگشته باشند."
    ),
    explanation_en=(
        "A previously reducible hernia that is now painful and stays out when "
        "lying down is incarceration. There is no fever, leucocytosis or skin "
        "inflammation, so strangulation is unlikely. Gentle reduction is allowed "
        "and then the patient stays for early repair, because injured contents "
        "may have been reduced."
    ),
    micro={
        "lead_fa": "فتق گیرکرده بدون پریتونیت: جا بینداز، بستری کن، زود عمل کن. ترخیص نکن.",
        "lead_en": "Incarcerated hernia without peritonitis: reduce, admit, operate early. Do not discharge.",
        "points_fa": [
            "قابل جااندازی: محتویات با درازکش یا فشار برمی‌گردد.",
            "Incarcerated: گیر کرده ولی هنوز زنده است.",
            "Strangulated: خون‌رسانی قطع شده؛ تب، لکوسیتوز، پوست قرمز، درد مقاوم.",
            "جااندازی در استرانگولاسیون ممنوع است.",
            "بعد از جااندازی موفق هم باید ترمیم زودرس کرد.",
            "فتق فمورال در زن بیشتر استرانگوله می‌شود.",
            "CT برای توده نامشخص یا شک به انسداد پیچیده است.",
        ],
        "points_en": [
            "Reducible: contents go back when the patient lies down or with pressure.",
            "Incarcerated: stuck but still viable.",
            "Strangulated: blood supply gone; fever, leucocytosis, red skin, relentless pain.",
            "Do not reduce a strangulated hernia.",
            "Even after a successful reduction, repair early.",
            "Femoral hernias in women strangulate more often.",
            "CT is for an unclear mass or complex obstruction.",
        ],
    },
    golden_fa="Incarcerated بدون پریتونیت → جااندازی + جراحی زودرس. ترخیص ممنوع.",
    golden_en="Incarcerated without peritonitis → reduce plus early surgery. No discharge.",
    refs=["Schwartz — Groin hernia"],
    concept="incarcerated-hernia", concept_fa="فتق گیرکرده", concept_en="Incarcerated hernia")

# ─────────────────────────── PEDS 61–64 ───────────────────────────
add("کودکان", 61,
    chapter_fa="عفونت‌های استرپتوکوکی", chapter_en="Streptococcal infections",
    options_why_fa=[
        "کوتریموکسازول استرپ پیوژن را نمی‌کشد و خط اول مخملک نیست.",
        "سفیکسیم پوشش استرپ دارد ولی انتخاب اول پنی‌سیلین یا آموکسی‌سیلین است.",
        "پاسخ صحیح — مخملک = استرپ گروه A؛ درمان انتخابی آموکسی‌سیلین خوراکی است.",
        "سیپروفلوکساسین در کودک به‌خاطر مفصل ممنوع است و استرپ را هم خط اول نیست.",
    ],
    options_why_en=[
        "Co-trimoxazole does not kill Streptococcus pyogenes and is not first-line for scarlet fever.",
        "Cefixime covers strep but first choice is penicillin or amoxicillin.",
        "Correct — scarlet fever is group-A strep; the drug of choice is oral amoxicillin.",
        "Ciprofloxacin is avoided in children because of joints and is not first-line for strep.",
    ],
    explanation_fa=(
        "تب + راش ماکولوپاپولر ریز + زبان توت‌فرنگی + لوزه قرمز و پتشی کام "
        "مخملک است (اگزوتوکسین استرپ گروه A). درمان برای ریشه‌کنی حلق و پیشگیری "
        "از تب روماتیسمی آموکسی‌سیلین یا پنی‌سیلین است."
    ),
    explanation_en=(
        "Fever plus a fine maculopapular rash plus strawberry tongue plus red "
        "tonsils and palatal petechiae is scarlet fever (group-A strep "
        "exotoxin). Treatment to clear the throat and prevent rheumatic fever "
        "is amoxicillin or penicillin."
    ),
    micro={
        "lead_fa": "زبان توت‌فرنگی + راش سنباده‌ای + لوزه = مخملک → آموکسی‌سیلین.",
        "lead_en": "Strawberry tongue + sandpaper rash + tonsils = scarlet fever → amoxicillin.",
        "points_fa": [
            "عامل: استرپتوکوک پیوژن و اگزوتوکسین پیروژنیک.",
            "راش از تنه شروع می‌شود و در چین‌ها خط پاستیا می‌سازد.",
            "دور لب رنگ‌پریده است (فیلتروم).",
            "کشت حلق یا رپید تست تشخیص را قطعی می‌کند ولی تابلوی کلاسیک درمان را عقب نمی‌اندازد.",
            "مدت درمان ۱۰ روز است تا تب روماتیسمی پیشگیری شود.",
            "گلومرولونفریت پس از استرپ را آنتی‌بیوتیک دیرهنگام جلوگیری نمی‌کند.",
            "آلرژی پنی‌سیلین: سفالکسین یا کلینداماییسین یا ماکرولید.",
            "کوتریموکسازول و فلوروکینولون انتخاب نیستند.",
        ],
        "points_en": [
            "Cause: Streptococcus pyogenes and a pyrogenic exotoxin.",
            "The rash starts on the trunk and makes Pastia's lines in the folds.",
            "The perioral area is pale (the filtrum).",
            "Throat culture or a rapid test confirms, but a classic picture should not delay treatment.",
            "Treat for 10 days to prevent rheumatic fever.",
            "Late antibiotics do not prevent post-strep glomerulonephritis.",
            "Penicillin allergy: cephalexin, clindamycin or a macrolide.",
            "Co-trimoxazole and fluoroquinolones are not the choice.",
        ],
    },
    golden_fa="مخملک = آموکسی‌سیلین ۱۰ روز. سیپروفلوکساسین مال کودک نیست.",
    golden_en="Scarlet fever = 10 days of amoxicillin. Ciprofloxacin is not for children.",
    refs=["Nelson — Group A streptococcal infections"],
    concept="scarlet", concept_fa="مخملک", concept_en="Scarlet fever")

add("کودکان", 62,
    chapter_fa="اگزانتم‌های ویروسی", chapter_en="Viral exanthems",
    options_why_fa=[
        "پاسخ صحیح — وزیکول اشکی در تنه و صورت با پرودرم تب = واریسلا.",
        "هرپس سیمپلکس معمولاً موضعی دور دهان یا ژنژیوستوماتیت است نه منتشر تنه.",
        "کوکساکی A دست‌پا‌دهان است: وزیکول کف دست و پا و دهان، نه تنه غالب.",
        "روزئولا بعد از افت تب راش ماکولر می‌دهد، وزیکول ندارد.",
    ],
    options_why_en=[
        "Correct — teardrop vesicles on trunk and face after a febrile prodrome is varicella.",
        "Herpes simplex is usually local around the mouth or gingivostomatitis, not a trunk-wide crop.",
        "Coxsackie A is hand-foot-mouth: vesicles on palms, soles and mouth, not a trunk-dominant crop.",
        "Roseola is a macular rash after the fever breaks; it has no vesicles.",
    ],
    explanation_fa=(
        "شیرخوار با تب و بی‌اشتهایی یک‌روزه و بعد پاپول، وزیکول اشکی و دلمه "
        "در تنه و صورت تصویر کلاسیک آبله‌مرغان است. ضایعات در چند مرحله همزمان "
        "دیده می‌شوند."
    ),
    explanation_en=(
        "An infant with a one-day febrile prodrome then papules, teardrop "
        "vesicles and crusts on trunk and face is classic chickenpox. Lesions "
        "in several stages are present at once."
    ),
    micro={
        "lead_fa": "وزیکول اشکی چندمرحله‌ای روی تنه = واریسلا. روزئولا وزیکول ندارد.",
        "lead_en": "Multistage teardrop vesicles on the trunk are varicella. Roseola has no vesicles.",
        "points_fa": [
            "واریسلا: پرودرم کوتاه، شروع از پوست سر و تنه، مرکزگریز.",
            "چند نسل ضایعه همزمان: پاپول، وزیکول، دلمه.",
            "خارش شدید است.",
            "عوارض: عفونت ثانویه پوست، پنومونی، انسفالیت مخچه‌ای.",
            "آسیکلوویر در نوزاد، ایمنی‌نقص و نوجوان دیررس توصیه می‌شود.",
            "واکسن زنده است و در بارداری و ایمنی‌نقص شدید ممنوع است.",
            "روزئولا (HHV-6): تب ۳ روزه سپس راش بعد از قطع تب.",
            "دست‌پا‌دهان: کف دست و پا، نه تنه غالب.",
        ],
        "points_en": [
            "Varicella: short prodrome, starts on scalp and trunk, centripetal.",
            "Several generations at once: papule, vesicle, crust.",
            "Itch is intense.",
            "Complications: secondary skin infection, pneumonia, cerebellar encephalitis.",
            "Aciclovir is advised in newborns, the immunocompromised and late adolescents.",
            "The vaccine is live and forbidden in pregnancy and severe immunodeficiency.",
            "Roseola (HHV-6): three days of fever then a rash after defervescence.",
            "Hand-foot-mouth: palms and soles, not a trunk-dominant crop.",
        ],
    },
    golden_fa="تنه + وزیکول اشکی چندسن = واریسلا. روزئولا بعد از قطع تب و بدون وزیکول است.",
    golden_en="Trunk plus multistage teardrop vesicles is varicella. Roseola follows defervescence and has no vesicles.",
    refs=["Nelson — Varicella-zoster"],
    concept="varicella-rash", concept_fa="راش واریسلا", concept_en="Varicella rash")

add("کودکان", 63,
    chapter_fa="مراقبت نوزاد / مانا", chapter_en="Newborn care / IMCI",
    options_why_fa=[
        "ارجاع فوری مال عفونت منتشر یا قرمزی در حال گسترش و حال بد است.",
        "سفتریاکسون عضلانی مال نشانه خطر عفونت باکتریال جدی است.",
        "موپیروسین برای ایمپتیگوی موضعی است نه بند ناف تمیز بدون گسترش.",
        "پاسخ صحیح — مانا: قرمزی محدود بند ناف بدون تب = تمیز کردن با آب هنگام تعویض پوشک.",
    ],
    options_why_en=[
        "Urgent referral is for spreading infection or a sick infant.",
        "Intramuscular ceftriaxone is for danger signs of serious bacterial infection.",
        "Mupirocin is for local impetigo, not a clean umbilicus without spread.",
        "Correct — IMCI: limited umbilical redness without fever means clean with water at each diaper change.",
    ],
    explanation_fa=(
        "نوزاد ترم ۵روزه بدون تب با فقط قرمزی دور ناف و بدون گسترش، طبق مانا "
        "عفونت موضعی خفیف بند ناف است. اقدام: بهداشت بند ناف با آب تمیز هنگام "
        "تعویض پوشک و آموزش علائم هشدار. آنتی‌بیوتیک سیستمیک و ارجاع مال گسترش "
        "یا حال عمومی بد است."
    ),
    explanation_en=(
        "A well, afebrile 5-day-old with only periumbilical redness and no "
        "spread is, by IMCI (MANA), mild local omphalitis. Action: clean the "
        "stump with clean water at each diaper change and teach danger signs. "
        "Systemic antibiotics and referral are for spread or a sick infant."
    ),
    micro={
        "lead_fa": "ناف قرمز محدود + نوزاد سرحال = آب و پوشک. گسترش یا تب = ارجاع.",
        "lead_en": "Limited red umbilicus in a well baby is water and diapers. Spread or fever means refer.",
        "points_fa": [
            "مانا همان IMCI ایرانی است.",
            "علائم خطر نوزاد: تب یا هایپوترمی، شیر نخوردن، لتارژی، تشنج، تنفس تند.",
            "اومفالیت شدید: قرمزی پیشرونده، ترشح چرکی، سفتی جدار، حال بد.",
            "اومفالیت شدید اورژانس است (خطر پریتونیت و سپسیس).",
            "مراقبت معمول بند ناف: خشک و تمیز نگه داشتن، الکل روتین لازم نیست.",
            "کلرهگزیدین در مناطق با مرگ نوزادی بالا توصیه شده، نه موپیروسین خانگی.",
            "آموزش علائم هشدار به والدین بخشی از مانا است.",
            "ترشح خونی خشک بند ناف در روزهای اول طبیعی است و عفونت نیست.",
            "فتق ناف نوزاد جدا از اومفالیت است و معمولاً خودبه‌خود بسته می‌شود.",
            "اگر قرمزی در کمتر از یک روز دور شکم پخش شد، همان روز ارجاع فوری است.",
        ],
        "points_en": [
            "MANA is the Iranian IMCI.",
            "Newborn danger signs: fever or hypothermia, not feeding, lethargy, seizure, fast breathing.",
            "Severe omphalitis: spreading redness, pus, abdominal-wall firmness, a sick infant.",
            "Severe omphalitis is an emergency (peritonitis and sepsis).",
            "Usual cord care: keep it dry and clean; routine alcohol is not required.",
            "Chlorhexidine is advised in high-NMR settings, not home mupirocin.",
            "Teaching parents the danger signs is part of IMCI.",
            "A dry bloody cord stump in the first days is normal, not infection.",
            "An umbilical hernia is separate from omphalitis and usually closes on its own.",
            "If redness spreads over the abdomen in under a day, refer the same day.",
        ],
    },
    golden_fa="ناف قرمز محدود بدون تب در مانا = تمیز کردن با آب. آنتی‌بیوتیک مال گسترش است.",
    golden_en="Limited red umbilicus without fever in IMCI is water cleaning. Antibiotics are for spread.",
    refs=["WHO IMCI / دستورالعمل مانا"],
    concept="omphalitis-imci", concept_fa="اومفالیت خفیف مانا", concept_en="Mild omphalitis IMCI")

add("کودکان", 64,
    chapter_fa="لنفادنوپاتی و بدخیمی", chapter_en="Lymphadenopathy and malignancy",
    options_why_fa=[
        "آسپیراسیون مغز استخوان وقتی است که بلاست یا سیтопеنی شدید باشد؛ اینجا پلاکت و Hb نسبتاً خوب‌اند.",
        "پاسخ صحیح — تب طول‌کشیده + تعریق شبانه + لنفادنوپاتی = اول گرافی قفسه سینه (مدیاستن / سل).",
        "سونوگرافی گردن اندازه را می‌گوید ولی تشخیص سیستمیک را عوض نمی‌کند.",
        "بیوپسی قدم بعدی است بعد از تصویر ساده قفسه، نه اولین اقدام.",
    ],
    options_why_en=[
        "Marrow aspiration is for blasts or severe cytopenia; here platelets and Hb are fairly preserved.",
        "Correct — prolonged fever + night sweats + nodes = chest radiograph first (mediastinum / TB).",
        "Neck ultrasound reports size but does not change the systemic work-up.",
        "Biopsy is the next step after a plain chest film, not the first action.",
    ],
    explanation_fa=(
        "علائم B یک‌ماهه و لنفادنوپاتی گردنی دوطرفه بدون درد، لنفوم یا سل را "
        "بالا می‌برد. کم‌تهاجم‌ترین و ضروری‌ترین قدم گرافی قفسه سینه است: "
        "مدیاستن پهن لنفوم و انفیلتراسیون سل را نشان می‌دهد و مسیر بیوپسی را "
        "عوض می‌کند."
    ),
    explanation_en=(
        "A month of B symptoms and painless bilateral cervical nodes raises "
        "lymphoma or tuberculosis. The least invasive essential step is a "
        "chest radiograph: a wide mediastinum points to lymphoma and an "
        "infiltrate to TB, and that changes how you biopsy."
    ),
    micro={
        "lead_fa": "علائم B + غده گردن → اول CXR. مغز استخوان اول نیست.",
        "lead_en": "B symptoms plus a neck node → CXR first. Marrow is not first.",
        "points_fa": [
            "علائم B: تب، کاهش وزن، تعریق شبانه.",
            "غده بدخیم: سفت، بدون درد، ثابت، بالای یک سانتی‌متر پایدار.",
            "CXR مدیاستن، ناف ریه و پارانشیم را ارزان می‌بیند.",
            "سل در ایران همیشه در تشخیص افتراقی لنفادنوپاتی مزمن است.",
            "بیوپسی اکسیزیونال بهتر از FNA برای لنفوم است.",
            "مغز استخوان وقتی CBC بلاست یا سیтопеنی دو یا سه رده دارد.",
            "اینجا نوتروفیل و لنفوسیت متعادل و پلاکت طبیعی است.",
        ],
        "points_en": [
            "B symptoms: fever, weight loss, night sweats.",
            "A malignant node is firm, painless, fixed and persists above one centimetre.",
            "A chest radiograph cheaply sees mediastinum, hila and parenchyma.",
            "In Iran TB is always in the differential of chronic lymphadenopathy.",
            "Excisional biopsy beats FNA for lymphoma.",
            "Marrow is for blasts or two- or three-lineage cytopenia.",
            "Here neutrophils and lymphocytes are balanced and platelets are normal.",
        ],
    },
    golden_fa="لنفادنوپاتی + علائم B: اول CXR، بعد بیوپسی. مغز استخوان آخر است.",
    golden_en="Lymphadenopathy plus B symptoms: CXR first, then biopsy. Marrow is last.",
    refs=["Nelson — Lymphadenopathy; Lymphoma"],
    concept="peds-b-symptoms", concept_fa="علائم B کودک", concept_en="Paediatric B symptoms")

# ─────────────────────────── OB/GYN 81–84 ───────────────────────────
add("زنان و زایمان", 81,
    chapter_fa="نازایی و تخمک‌گذاری", chapter_en="Infertility and ovulation",
    options_why_fa=[
        "BBT بعد از تخمک‌گذاری بالا می‌رود؛ گذشته‌نگر است نه پیش‌بینی.",
        "پاسخ صحیح — جهش LH ادراری ۲۴ تا ۳۶ ساعت قبل از تخمک‌گذاری را خبر می‌دهد.",
        "پروژسترون وسط لوتئال فقط می‌گوید تخمک‌گذاری رخ داده است.",
        "بیوپسی اندومتر هم گذشته‌نگر و تهاجمی است.",
    ],
    options_why_en=[
        "BBT rises after ovulation; it is retrospective, not predictive.",
        "Correct — a urinary LH surge announces ovulation 24 to 36 hours ahead.",
        "Mid-luteal progesterone only says ovulation has already happened.",
        "Endometrial biopsy is also retrospective and invasive.",
    ],
    explanation_fa=(
        "تنها روش آینده‌نگر در گزینه‌ها کیت LH ادراری است. پیک LH محرک "
        "تخمک‌گذاری است و حدود یک شبانه‌روز زودتر در ادرار دیده می‌شود. "
        "بقیه روش‌ها بعد از وقوع را ثبت می‌کنند."
    ),
    explanation_en=(
        "The only prospective method among the options is a urinary LH kit. "
        "The LH peak triggers ovulation and appears in urine about a day "
        "earlier. The others only record that ovulation has already occurred."
    ),
    micro={
        "lead_fa": "فقط کیت LH آینده‌نگر است. BBT و پروژسترون بعد از واقعه‌اند.",
        "lead_en": "Only the LH kit is prospective. BBT and progesterone are after the fact.",
        "points_fa": [
            "سیکل: فولیکولار (استروژن) → جهش LH → تخمک‌گذاری → لوتئال (پروژسترون).",
            "کیت را از روز ۱۰–۱۲ سیکل شروع می‌کنند.",
            "نزدیکی یا IUI همان روز و فردای جهش LH برنامه‌ریزی می‌شود.",
            "BBT حداقل ۰٫۳ درجه بعد از تخمک‌گذاری بالا می‌ماند.",
            "پروژسترون روز ۲۱ سیکل ۲۸روزه اگر بالای ۳ نانوگرم باشد تخمک‌گذاری رخ داده.",
            "بیوپسی اندومتر دیگر برای تأیید تخمک‌گذاری روتین نیست.",
            "سونوگرافی سریال فولیکول هم آینده‌نگر است ولی در گزینه‌ها نیست.",
        ],
        "points_en": [
            "Cycle: follicular (oestrogen) → LH surge → ovulation → luteal (progesterone).",
            "Start the kit on day 10–12 of the cycle.",
            "Time intercourse or IUI on the day of the surge and the next day.",
            "BBT stays at least 0.3 degrees higher after ovulation.",
            "Day-21 progesterone above 3 ng/ml on a 28-day cycle means ovulation occurred.",
            "Endometrial biopsy is no longer routine to confirm ovulation.",
            "Serial follicle ultrasound is also prospective but is not listed.",
        ],
    },
    golden_fa="آینده‌نگر = کیت LH. گذشته‌نگر = BBT و پروژسترون.",
    golden_en="Prospective is the LH kit. Retrospective are BBT and progesterone.",
    refs=["Williams / Speroff — Detection of ovulation"],
    concept="lh-kit", concept_fa="کیت LH", concept_en="LH kit")

add("زنان و زایمان", 82,
    chapter_fa="خونریزی غیرطبیعی رحم", chapter_en="Abnormal uterine bleeding",
    options_why_fa=[
        "ترانکسامیک اسید ضدفیبرینولیز است و خونریزی را کم می‌کند؛ استروژن تنها نیست.",
        "NSAID پروستاگلاندین را کم می‌کند و حجم خونریزی را می‌کاهد.",
        "پروژستین خوراکی اندومتر را پایدار می‌کند و درمان استاندارد AUB است.",
        "پاسخ صحیح — استروژن تنها در ۴۵ ساله با اندومتر پرولیفراتیو ممنوع است (هیپرپلازی و سرطان).",
    ],
    options_why_en=[
        "Tranexamic acid is antifibrinolytic and reduces bleeding; it is not unopposed oestrogen.",
        "NSAIDs cut prostaglandins and reduce menstrual volume.",
        "Oral progestin stabilises the endometrium and is standard AUB treatment.",
        "Correct — oestrogen alone is forbidden in a 45-year-old with proliferative endometrium (hyperplasia and cancer).",
    ],
    explanation_fa=(
        "AUB در حوالی یائسگی با بیوپسی پرولیفراتیو یعنی استروژن بدون پروژسترون "
        "اندومتر را جلو برده. درمان طولانی‌مدت نباید دوباره استروژن تنها باشد. "
        "پروژستین، NSAID و ترانکسامیک اسید مجازند."
    ),
    explanation_en=(
        "Perimenopausal AUB with a proliferative biopsy means unopposed "
        "oestrogen has driven the endometrium. Long-term treatment must not "
        "be oestrogen alone again. Progestin, NSAIDs and tranexamic acid are allowed."
    ),
    micro={
        "lead_fa": "AUB حوالی یائسگی: استروژن تنها نده. پروژستین یا ضدفیبرینولیز بده.",
        "lead_en": "Perimenopausal AUB: do not give oestrogen alone. Give progestin or an antifibrinolytic.",
        "points_fa": [
            "طبقه‌بندی PALM-COEIN علت ساختمانی و غیرساختمانی را جدا می‌کند.",
            "بعد از ۴۵ سال بیوپسی اندومتر برای رد هیپرپلازی واجب است.",
            "اندومتر پرولیفراتیو یعنی تحت استروژن بوده، نه ترشح‌کننده.",
            "استروژن بدون پروژستین هیپرپلازی و آدنوکارسینوم می‌سازد.",
            "IUD لوونورژسترل هم درمان عالی AUB است.",
            "ترانکسامیک اسید در روزهای خونریزی مصرف می‌شود نه مداوم هورمونی.",
            "اگر بیوپسی هیپرپلازی آتیپیک بدهد، مسیر سرطان است نه فقط دارو.",
            "سونوگرافی برای رد پولیپ و میوم قبل از درمان طبی لازم است.",
            "هورمون ترکیبی خوراکی در غیرسیگاری بدون میگرن اورا هم گزینه است.",
            "جراحی وقتی است که پاتولوژی بد یا شکست درمان طبی باشد.",
        ],
        "points_en": [
            "PALM-COEIN splits structural from non-structural causes.",
            "After 45 an endometrial biopsy is mandatory to exclude hyperplasia.",
            "Proliferative endometrium means it has been under oestrogen, not secretory.",
            "Oestrogen without progestin makes hyperplasia and adenocarcinoma.",
            "A levonorgestrel IUD is also excellent treatment for AUB.",
            "Tranexamic acid is taken on bleeding days, not as continuous hormone.",
        ],
    },
    golden_fa="استروژن تنها در AUB پری‌منوپوز ممنوع است.",
    golden_en="Oestrogen alone is forbidden in perimenopausal AUB.",
    refs=["Williams / ACOG — AUB"],
    concept="aub-estrogen", concept_fa="استروژن تنها در AUB", concept_en="Unopposed oestrogen in AUB")

add("زنان و زایمان", 83,
    chapter_fa="یائسگی", chapter_en="Menopause",
    options_why_fa=[
        "هورمون‌درمانی برای پیشگیری اولیه قلبی بعد از WHI ممنوع است و در سیگاری خطر ترومبوز دارد.",
        "هورمون برای پیشگیری اولیه استئوپروز در زن بدون گرگرفتگی ده سال بعد از یائسگی توصیه نمی‌شود.",
        "پاسخ صحیح — زن ۶۰ ساله سیگاری ده سال بعد از یائسگی باید دانسیتومتری شود.",
        "فیتواستروژن اثر ثابت‌شده پیشگیری شکستگی ندارد.",
    ],
    options_why_en=[
        "Hormone therapy for primary cardiac prevention is forbidden after WHI and raises thrombosis risk in smokers.",
        "Hormone for primary osteoporosis prevention is not advised in a woman without flushes ten years after menopause.",
        "Correct — a 60-year-old smoker ten years after menopause should have densitometry.",
        "Phyto-oestrogens have no proven fracture-prevention effect.",
    ],
    explanation_fa=(
        "پنجره هورمون‌درمانی زیر ۶۰ سال و کمتر از ۱۰ سال از یائسگی است و فقط "
        "برای علائم وازوموتور. این بیمار ۶۰ ساله، سیگاری و بدون گرگرفتگی است. "
        "کار درست غربالگری پوکی استخوان است (سن ≥۶۵ یا زودتر با عامل خطر)."
    ),
    explanation_en=(
        "The hormone-therapy window is under 60 and within 10 years of "
        "menopause, and only for vasomotor symptoms. This patient is 60, a "
        "smoker and flush-free. The right act is osteoporosis screening "
        "(age ≥65, or earlier with a risk factor)."
    ),
    micro={
        "lead_fa": "هورمون بعد از ۶۰ یا بعد از ۱۰ سال از یائسگی برای پیشگیری نده. DEXA بده.",
        "lead_en": "Do not give hormone after 60 or after 10 years from menopause for prevention. Give DEXA.",
        "points_fa": [
            "WHI نشان داد استروژن+پروژستین سکته و ترومبوز و سرطان پستان را زیاد می‌کند.",
            "سیگار خودش عامل ترومبوز و یائسگی زودتر است.",
            "اندیکاسیون HRT: گرگرفتگی آزاردهنده، آتروفی ژنیتواورینری، یائسگی زودرس.",
            "غربالگری DEXA: ≥۶۵ سال یا جوان‌تر با FRAX بالا / سیگار / استروئید / شکستگی قبلی.",
            "درمان پوکی: بیسفسفونات، دنوزومب، اصلاح کلسیم و ویتامین D، ترک سیگار.",
            "فیتواستروژن جایگزین هورمون نیست.",
            "ترک سیگار مهم‌ترین مداخله سبک زندگی برای استخوان و قلب است.",
            "کلسیم ۱۲۰۰ میلی‌گرم و ویتامین D ۸۰۰ واحد در این سن پایه است.",
            "اگر T-score ≤ −۲٫۵ یا شکستگی قبلی باشد درمان دارویی شروع می‌شود.",
            "هورمون واژینال موضعی برای خشکی ولو واژینال سیستمیک نیست و جداگانه مجاز است.",
        ],
        "points_en": [
            "WHI showed oestrogen+progestin raises stroke, thrombosis and breast cancer.",
            "Smoking itself is a thrombosis risk and brings menopause earlier.",
            "HRT indications: troublesome flushes, genitourinary atrophy, premature menopause.",
            "DEXA screen: ≥65 years, or younger with high FRAX / smoking / steroids / prior fracture.",
            "Treat osteoporosis with a bisphosphonate, denosumab, calcium and vitamin D, and stopping smoking.",
            "Phyto-oestrogen is not a hormone substitute.",
            "Stopping smoking is the most important lifestyle step for bone and heart.",
            "Calcium 1200 mg and vitamin D 800 units are the base at this age.",
            "Start drug treatment if T-score is ≤ −2.5 or there is a prior fracture.",
            "Local vaginal oestrogen for dryness is not systemic and is separately allowed.",
        ],
    },
    golden_fa="۶۰ ساله سیگاری بدون گرگرفتگی = DEXA، نه HRT.",
    golden_en="A 60-year-old smoker without flushes gets DEXA, not HRT.",
    refs=["Williams / NAMS — Menopause and osteoporosis"],
    concept="menopause-dexa", concept_fa="غربالگری پوکی بعد از یائسگی", concept_en="Postmenopausal DEXA")

add("زنان و زایمان", 84,
    chapter_fa="زایمان", chapter_en="Labour and delivery",
    options_why_fa=[
        "پاسخ صحیح — اپی‌زیاتومی روتین در زایمان اول دیگر توصیه نمی‌شود.",
        "اپی‌زیاتومی واقعاً خطر پارگی درجه ۳ و ۴ را زیاد می‌کند؛ این جمله درست است.",
        "اندیکاسیون واقعی: زایمان ابزاری و دیسترس و نزول طول‌کشیده.",
        "زمان درست بعد از نزول کامل و درست قبل از خروج سر است.",
    ],
    options_why_en=[
        "Correct — routine episiotomy in a first birth is no longer recommended.",
        "Episiotomy really does raise 3rd- and 4th-degree tears; that sentence is true.",
        "True indications: instrumental birth, distress and prolonged descent.",
        "The right moment is after full descent, just before the head delivers.",
    ],
    explanation_fa=(
        "اپی‌زیاتومی انتخابی است نه روتین. شواهد نشان داد برش روتین در زایمان "
        "اول پارگی شدید را کم نمی‌کند و گاهی بیشتر می‌کند. بنابراین جمله "
        "«در زایمان اول به‌صورت معمول انجام می‌شود» غلط است."
    ),
    explanation_en=(
        "Episiotomy is selective, not routine. Evidence showed a routine cut "
        "in a first birth does not reduce severe tears and sometimes increases "
        "them. So the sentence 'it is done routinely in the first delivery' is false."
    ),
    micro={
        "lead_fa": "اپی‌زیاتومی روتین منسوخ است. فقط برای ابزار، دیسترس یا دیستوشی.",
        "lead_en": "Routine episiotomy is obsolete. Only for instruments, distress or dystocia.",
        "points_fa": [
            "مدیولترال از خط وسط امن‌تر از مدین است (کمتر به اسفنکتر می‌رسد).",
            "مدین راحت‌تر ترمیم می‌شود ولی پارگی درجه ۴ بیشتر دارد.",
            "ترمیم لایه‌به‌لایه با نخ قابل جذب.",
            "عوارض: درد، هماتوم، عفونت، دیسپارونی، بی‌اختیاری گاز.",
            "محافظت پرینه و زایمان کنترل‌شده سر جای برش روتین را گرفته.",
            "دیستوشی شانه ممکن است اپی‌زیاتومی مدیولترال بخواهد.",
            "بی‌حسی کافی قبل از برش، درد بعد را کم می‌کند.",
            "ترمیم باید در نور خوب و با شناسایی اسفنکتر باشد.",
            "اپی‌زیاتومی پیشگیری از بی‌اختیاری ادرار نیست.",
        ],
        "points_en": [
            "Mediolateral is safer than midline (less sphincter involvement).",
            "Midline is easier to repair but has more fourth-degree tears.",
            "Repair layer by layer with absorbable suture.",
            "Complications: pain, haematoma, infection, dyspareunia, flatal incontinence.",
            "Perineal protection and a controlled head delivery have replaced the routine cut.",
            "Shoulder dystocia may need a mediolateral episiotomy.",
            "Adequate anaesthesia before the cut reduces later pain.",
            "Repair needs good light and identification of the sphincter.",
            "Episiotomy does not prevent urinary incontinence.",
        ],
    },
    golden_fa="اپی‌زیاتومی روتین در زایمان اول غلط است.",
    golden_en="Routine episiotomy in a first birth is wrong.",
    refs=["Williams — Episiotomy"],
    concept="episiotomy", concept_fa="اپی‌زیاتومی", concept_en="Episiotomy")


def apply():
    files = sorted(glob.glob(os.path.join(HERE, "import-payload.archive.part*.json")))
    n = 0
    for path in files:
        body = json.load(open(path, encoding="utf-8"))
        changed = False
        for q in body["questions"]:
            if q.get("year_num") != 1402:
                continue
            rec = L.get((q["subject_fa"], q["question_no"]))
            if not rec:
                continue
            q["chapter_fa"] = rec["chapter_fa"]
            q["chapter_en"] = rec["chapter_en"]
            q["options_why_fa"] = rec["options_why_fa"]
            q["options_why_en"] = rec["options_why_en"]
            q["explanation_fa"] = rec["explanation_fa"]
            q["explanation_en"] = rec["explanation_en"]
            q["micro"] = rec["micro"]
            q["golden_fa"] = rec["golden_fa"]
            q["golden_en"] = rec["golden_en"]
            q["refs"] = rec["refs"]
            q["concept"] = rec["concept"]
            q["concept_fa"] = rec["concept_fa"]
            q["concept_en"] = rec["concept_en"]
            q["needs_lesson"] = False
            q["lesson_part"] = 1
            n += 1
            changed = True
        if changed:
            json.dump(body, open(path, "w", encoding="utf-8"), ensure_ascii=False)
    print(f"applied lessons to {n} Khordad-1402 major questions")
    print("keys:", ", ".join(f"{s} q{no}" for s, no in sorted(L)))


if __name__ == "__main__":
    apply()
