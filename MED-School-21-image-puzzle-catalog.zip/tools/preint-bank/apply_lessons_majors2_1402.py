# -*- coding: utf-8 -*-
"""Next Khordad-1402 major cluster: internal 11–14, surgery 47–50, peds 65–66, OB 85–86.

Official English stems/options from the ministry booklet are never rewritten.
"""
import json, glob, os

HERE = os.path.dirname(os.path.abspath(__file__))
L = {}


def add(subj, no, **kw):
    L[(subj, no)] = kw


# ─────────────────────────── INTERNAL 11–14 ───────────────────────────
add("داخلی", 11,
    chapter_fa="خون / ITP", chapter_en="Hematology / ITP",
    options_why_fa=[
        "پردنیزولون مال ITP علامت‌دار یا پلاکت زیر حدود ۳۰ هزار است؛ اینجا ۶۰ هزار و بی‌علامت است.",
        "تزریق پلاکت مال خونریزی تهدیدکنندهٔ حیات است نه عدد آزمایشگاهی تنها.",
        "IVIG مال خونریزی فعال یا نیاز به افزایش سریع پلاکت پیش از جراحی است.",
        "پاسخ صحیح — ITP تازه، بی‌علامت، پلاکت ۶۰ هزار: فقط پیگیری.",
    ],
    options_why_en=[
        "Prednisolone is for symptomatic ITP or platelets roughly below 30 000; here they are 60 000 and she is well.",
        "Platelet transfusion is for life-threatening bleeding, not a laboratory number alone.",
        "IVIG is for active bleeding or a need to raise platelets fast before surgery.",
        "Correct — new asymptomatic ITP with platelets of 60 000 is observation only.",
    ],
    explanation_fa=(
        "زن جوان بی‌علامت با ترومبوسیتوپنی ایزوله، اسمیر فقط کمبود پلاکت، ANA و HIV و HCV منفی "
        "و LDH و ESR نرمال، ITP اولیه است. آستانهٔ درمان معمولاً خونریزی یا پلاکت کمتر از ۳۰ هزار "
        "است. ۶۰ هزار بدون علامت فقط پیگیری سرپایی می‌خواهد."
    ),
    explanation_en=(
        "A well young woman with isolated thrombocytopenia, a smear that only lacks platelets, "
        "negative ANA/HIV/HCV and normal LDH/ESR has primary ITP. Treatment is usually reserved "
        "for bleeding or platelets under about 30 000. Sixty thousand without symptoms is outpatient follow-up."
    ),
    micro={
        "lead_fa": "ITP بی‌علامت و پلاکت بالای ۳۰–۵۰ هزار = نگاه کن، دارو نده.",
        "lead_en": "Asymptomatic ITP with platelets above 30–50 000 means watch, do not treat.",
        "points_fa": [
            "ITP: تخریب ایمنی پلاکت؛ مغز استخوان معمولاً جبران می‌کند.",
            "تشخیص طردی است: اسمیر، ویروس، لوپوس و دارو را کنار بگذار.",
            "اسمیر تکه‌تکهٔ پلاکت طبیعی است؛ شیستوسیت TTP را می‌گوید.",
            "LDH و بیلی‌روبین بالا همولیز را مطرح می‌کند نه ITP خالص.",
            "خط اول علامت‌دار: کورتیکواستروئید؛ IVIG اگر عجله باشد.",
            "ترانسفیوژن پلاکت به‌تنهایی عمر کوتاه دارد مگر با IVIG در خونریزی شدید.",
            "طحال‌برداری یا آگونیست TPO مال مقاوم مزمن است.",
            "حاملگی و جراحی آستانه را بالاتر می‌برند.",
            "از NSAID و آسپرین تا پلاکت پایدار پرهیز کن.",
            "پیگیری: آموزش پتشی، خونریزی مخاطی و مراجعهٔ فوری.",
        ],
        "points_en": [
            "ITP is immune platelet destruction; the marrow usually compensates.",
            "It is a diagnosis of exclusion: smear, viruses, lupus and drugs.",
            "Platelet fragments on the smear are normal; schistocytes mean TTP.",
            "High LDH or bilirubin points to haemolysis, not pure ITP.",
            "First-line when symptomatic: a corticosteroid; IVIG if you need speed.",
            "Platelets alone last hours unless paired with IVIG in severe bleed.",
            "Splenectomy or a TPO agonist is for chronic refractory disease.",
            "Pregnancy and surgery raise the treatment threshold.",
            "Avoid NSAIDs and aspirin until the count is stable.",
            "Follow-up: teach petechiae, mucosal bleeding and when to return.",
        ],
    },
    golden_fa="ITP بی‌علامت با پلاکت ۶۰ هزار = پیگیری. استروئید مال خونریزی یا عدد خیلی پایین است.",
    golden_en="Asymptomatic ITP at 60 000 platelets is follow-up. Steroids are for bleeding or a much lower count.",
    refs=["Harrison 21 — Immune thrombocytopenia"],
    concept="itp-observe", concept_fa="مشاهده ITP", concept_en="Observe ITP")

add("داخلی", 12,
    chapter_fa="طب انتقال خون", chapter_en="Transfusion medicine",
    options_why_fa=[
        "ادامهٔ تزریق با آنتی‌هیستامین در ادم صورت خطرناک است؛ واکنش ممکن است پیشرفت کند.",
        "توقف و آنتی‌هیستامین برای کهیر ساده بدون ادم راه هوایی کافی است؛ اینجا ادم صورت هست.",
        "پاسخ صحیح — کهیر منتشر + ادم صورت = آنژیوادم؛ تزریق را قطع کن و آدرنالین بده.",
        "ادامهٔ تزریق حتی با آدرنالین آنتی‌ژن را همچنان وارد می‌کند.",
    ],
    options_why_en=[
        "Continuing the unit plus an antihistamine is unsafe once the face is swollen; the reaction can progress.",
        "Pause plus antihistamine is enough for simple urticaria without airway oedema; here the face is swollen.",
        "Correct — widespread hive plus facial oedema is angio-oedema; stop the unit and give adrenaline.",
        "Continuing the unit even with adrenaline still pours in antigen.",
    ],
    explanation_fa=(
        "راش خارش‌دار منتشر و ادم صورت حین واحد دوم، واکنش آلرژیک بیش از کهیر ساده است "
        "(آنژیوادم). حتی با فشار پایدار، تزریق را فوراً قطع کن، رگ را باز نگه دار و آدرنالین "
        "بده. آنتی‌هیستامین کمکی است نه جایگزین."
    ),
    explanation_en=(
        "A widespread itchy rash and facial oedema during the second unit is more than simple "
        "urticaria (angio-oedema). Even with stable blood pressure, stop the unit at once, keep "
        "the line, and give adrenaline. Antihistamine is an adjunct, not a substitute."
    ),
    micro={
        "lead_fa": "ادم صورت حین ترانسفیوژن = قطع واحد + آدرنالین. کهیر تنها = قطع موقت + آنتی‌هیستامین.",
        "lead_en": "Facial oedema during transfusion means stop the unit plus adrenaline. Hives alone means a pause plus antihistamine.",
        "points_fa": [
            "واکنش آلرژیک خفیف: کهیر بدون افت فشار.",
            "آنژیوادم یا برونکواسپاسم یا شوک = آنافیلاکسی تا خلافش ثابت شود.",
            "آدرنالین عضلانی یا زیرجلدی ۰٫۳–۰٫۵ میلی‌گرم در ران.",
            "همهٔ واکنش‌های جدی: توقف، نرمال سالین، اطلاع بانک خون.",
            "همولیتیک حاد: تب، درد کمر، هموگلوبینوری؛ نه کهیر غالب.",
            "TRALI: هیپوکسی و انفیلتراسیون دوطرفه در ۶ ساعت.",
            "TACO: ادم ریهٔ حجم‌اضافه با فشار بالا.",
            "سابقهٔ کهیر مکرر: شستشوی محصول یا آنتی‌هیستامین پیش‌دارو.",
            "کمبود IgA: خطر آنافیلاکسی با پلاسمای معمولی.",
            "واحد را برای بررسی به بانک برگردان.",
        ],
        "points_en": [
            "Mild allergic: hives without a blood-pressure drop.",
            "Angio-oedema, bronchospasm or shock is anaphylaxis until proven otherwise.",
            "Adrenaline 0.3–0.5 mg IM or subcutaneous in the thigh.",
            "Every serious reaction: stop, saline, tell the blood bank.",
            "Acute haemolytic: fever, back pain, haemoglobinuria — not hive-dominant.",
            "TRALI: hypoxia and bilateral infiltrates within 6 hours.",
            "TACO: volume-overload pulmonary oedema with high pressure.",
            "Recurrent hives: washed product or premedication.",
            "IgA deficiency: anaphylaxis risk with ordinary plasma.",
            "Send the unit back to the bank for work-up.",
        ],
    },
    golden_fa="ادم صورت حین پک‌سل = قطع + آدرنالین. تزریق را ادامه نده.",
    golden_en="Facial oedema during packed cells means stop plus adrenaline. Do not continue the unit.",
    refs=["Harrison 21 — Transfusion reactions"],
    concept="tx-angioedema", concept_fa="آنژیوادم ترانسفیوژن", concept_en="Transfusion angio-oedema")

add("داخلی", 13,
    chapter_fa="روماتولوژی / ستون فقرات", chapter_en="Rheumatology / spine",
    options_why_fa=[
        "استئوپروز درد مکانیکی مداوم یا شکستگی فشاری می‌دهد، نه تسکین با نشستن و علامت سبد خرید.",
        "اسپوندیلیت درد التهابی شبانه با خشکی صبحگاهی است، با حرکت بهتر می‌شود نه با نشستن.",
        "پاسخ صحیح — درد ایستادن/راه رفتن که با نشستن و خم شدن روی سبد کم می‌شود = تنگی کانال.",
        "فتق دیسک معمولاً درد تیرکشندهٔ رادیکولر یک‌طرفه است و خم شدن به جلو آن را بدتر می‌کند.",
    ],
    options_why_en=[
        "Osteoporosis gives constant mechanical pain or a crush fracture, not relief on sitting and a shopping-cart sign.",
        "Spondylitis is inflammatory night pain with morning stiffness that eases with movement, not with sitting.",
        "Correct — standing/walking pain that eases on sitting and on leaning over a cart is spinal stenosis.",
        "A disc herniation is usually unilateral radicular pain that worsens on forward flexion.",
    ],
    explanation_fa=(
        "لنگش عصبی: درد کمر و پا با راه رفتن و ایستادن، تسکین با نشستن و فلکسیون کمر "
        "(علامت سبد خرید) تعریف تنگی کانال کمری است. دیسک برعکس با خم شدن بدتر می‌شود."
    ),
    explanation_en=(
        "Neurogenic claudication — back and leg pain on walking and standing, eased by sitting "
        "and lumbar flexion (the shopping-cart sign) — is lumbar spinal stenosis. A disc does the opposite on flexion."
    ),
    micro={
        "lead_fa": "سبد خرید = تنگی کانال. خم شدن به جلو دیسک را بدتر و تنگی را بهتر می‌کند.",
        "lead_en": "Shopping cart means stenosis. Forward flexion worsens a disc and eases stenosis.",
        "points_fa": [
            "تنگی کانال: هیپرتروفی فاست و لیگامان فلاوم + برآمدگی دیسک در مسن.",
            "لنگش عروقی با ایستادن درجا بهتر می‌شود؛ عصبی با فلکسیون.",
            "دوچرخه‌سواری اغلب در تنگی قابل تحمل است.",
            "MRI روش انتخابی تصویربرداری است.",
            "درمان اول: فیزیوتراپی فلکسوری، ضددرد، کاهش وزن.",
            "جراحی دکمپرسیون مال نقص پیشرونده یا شکست درمان طبی است.",
            "سندرم دم‌اسب اورژانس است (بی‌اختیاری + زین اسب).",
            "استئوپروز را با سنجش تراکم و شکستگی فشاری جدا کن.",
            "اسپوندیلیت در جوان با HLA-B27 و ساکروایلئیت است.",
            "رادیکولوپاتی حاد دیسک معمولاً زیر ۵۰ سال است.",
        ],
        "points_en": [
            "Stenosis: facet and ligamentum-flavum hypertrophy plus disc bulge in older adults.",
            "Vascular claudication eases on standing still; neurogenic eases on flexion.",
            "Cycling is often tolerated in stenosis.",
            "MRI is the imaging of choice.",
            "First treatment: flexion physiotherapy, analgesia, weight loss.",
            "Decompression is for progressive deficit or failed medical care.",
            "Cauda equina is an emergency (incontinence plus saddle anaesthesia).",
            "Separate osteoporosis with densitometry and a crush fracture.",
            "Spondylitis is a young HLA-B27 patient with sacroiliitis.",
            "Acute disc radiculopathy is usually under 50.",
        ],
    },
    golden_fa="درد راه رفتن که با سبد خرید بهتر می‌شود = تنگی کانال، نه دیسک.",
    golden_en="Walking pain that eases over a shopping cart is stenosis, not a disc.",
    refs=["Harrison 21 — Spinal stenosis"],
    concept="spinal-stenosis", concept_fa="تنگی کانال نخاعی", concept_en="Spinal stenosis")

add("داخلی", 14,
    chapter_fa="تصویربرداری عضلانی‌اسکلتی", chapter_en="Musculoskeletal imaging",
    options_why_fa=[
        "کیست بیکر پشت زانو با سونوگرافی به‌خوبی دیده می‌شود.",
        "پارگی روتاتور کاف با سونوگرافی دینامیک قابل تشخیص است.",
        "پاسخ صحیح — نکروز آواسکولر استخوان را سونوگرافی نمی‌بیند؛ MRI استاندارد طلایی است.",
        "بورسیت و تاندینیت سطحی کاربرد کلاسیک سونوگرافی هستند.",
    ],
    options_why_en=[
        "A Baker cyst behind the knee is well seen on ultrasound.",
        "A rotator-cuff tear can be diagnosed with dynamic ultrasound.",
        "Correct — ultrasound does not see avascular necrosis of bone; MRI is the gold standard.",
        "Superficial bursitis and tendinitis are classic ultrasound uses.",
    ],
    explanation_fa=(
        "سونوگرافی بافت نرم سطحی، تاندون، بورس و کیست را می‌بیند. نکروز آواسکولر سر استخوان "
        "(مثلاً فمور) داخل استخوان است و در مراحل اولیه فقط در MRI روشن می‌شود. بنابراین "
        "AVN استثنای فهرست است."
    ),
    explanation_en=(
        "Ultrasound sees superficial soft tissue, tendon, bursa and cysts. Avascular necrosis "
        "lives inside bone and in early stages lights up only on MRI. So AVN is the exception on the list."
    ),
    micro={
        "lead_fa": "AVN = MRI. سونوگرافی مال تاندون و بورس و کیست است نه مغز استخوان.",
        "lead_en": "AVN is MRI. Ultrasound is for tendon, bursa and cyst, not marrow.",
        "points_fa": [
            "علل AVN: استروئید، الکل، تروما، سلول داسی، باروتروما.",
            "شایع‌ترین محل: سر فمور.",
            "رادیوگرافی ساده دیر مثبت می‌شود (هلال و کلاپس).",
            "MRI حساس‌ترین روش زودهنگام است.",
            "اسکن استخوان جایگزین ضعیف‌تر وقتی MRI نباشد.",
            "سونوگرافی داپلر التهاب سطحی و مایع را نشان می‌دهد.",
            "روتاتور کاف: سونوگرافی ارزان و دینامیک؛ MRI اگر جراحی مطرح باشد.",
            "کیست بیکر را از DVT با سونوگرافی جدا کن.",
            "سؤال «بجز» یعنی سه تا درست‌اند و یکی بیرون است.",
            "اگر درد هیپ در مصرف‌کنندهٔ استروئید دیدی، مستقیم به MRI فکر کن.",
        ],
        "points_en": [
            "AVN causes: steroids, alcohol, trauma, sickle cell, barotrauma.",
            "Commonest site: the femoral head.",
            "Plain films turn positive late (crescent and collapse).",
            "MRI is the most sensitive early test.",
            "A bone scan is a weaker substitute when MRI is unavailable.",
            "Doppler ultrasound shows superficial inflammation and fluid.",
            "Rotator cuff: cheap dynamic ultrasound; MRI if surgery is on the table.",
            "Separate a Baker cyst from DVT with ultrasound.",
            "An 'except' stem means three are true and one is out.",
            "Hip pain in a steroid user means think MRI at once.",
        ],
    },
    golden_fa="نکروز آواسکولر را سونوگرافی نمی‌بیند؛ MRI بخواه.",
    golden_en="Ultrasound misses avascular necrosis; ask for MRI.",
    refs=["Harrison 21 — Osteonecrosis; musculoskeletal ultrasound"],
    concept="avn-mri", concept_fa="AVN و MRI", concept_en="AVN and MRI")

# ─────────────────────────── SURGERY 47–50 ───────────────────────────
add("جراحی", 47,
    chapter_fa="تروما / بلع مواد سوزاننده", chapter_en="Trauma / caustic ingestion",
    options_why_fa=[
        "NG کور مال سوزاننده ممنوع است؛ خطر پرفوراسیون دارد.",
        "لاپاراتومی مال پریتونیت یا سوراخ واضح است؛ بیمار پایدار است.",
        "خنثی‌سازی با شیر یا سفیده منسوخ است و آسیب حرارتی می‌سازد.",
        "پاسخ صحیح — پایدار بعد از سوزاننده: آندوسکوپی در ۲۴ ساعت اول برای درجه‌بندی.",
    ],
    options_why_en=[
        "A blind NG is forbidden after caustic injury; it can perforate.",
        "Laparotomy is for peritonitis or a clear hole; she is stable.",
        "Neutralising with milk or egg white is obsolete and adds thermal injury.",
        "Correct — a stable caustic ingestion gets endoscopy within 24 hours for grading.",
    ],
    explanation_fa=(
        "لوله بازکن قلیایی است. در بیمار پایدار با سوختگی دهان، قدم تشخیصی آندوسکوپی "
        "محتاطانه پس از پایدارسازی (معمولاً ۶ تا ۲۴ ساعت) است. NG، خنثی‌سازی و استفراغ القایی "
        "ممنوع‌اند."
    ),
    explanation_en=(
        "Drain cleaner is alkali. In a stable patient with oral burns the diagnostic step is "
        "careful endoscopy after stabilisation (usually 6 to 24 hours). NG, neutralisation and induced vomiting are forbidden."
    ),
    micro={
        "lead_fa": "سوزاننده پایدار = آندوسکوپی. NG نگذار، شیر نده، استفراغ نگیر.",
        "lead_en": "Stable caustic means endoscopy. No NG, no milk, no vomiting.",
        "points_fa": [
            "قلیا نکروز مایع و نفوذ عمقی می‌دهد؛ اسید نکروز انعقادی.",
            "ABC و راه هوایی اول است اگر استریدور یا ادم حلق باشد.",
            "عکس سینه و شکم برای هوای آزاد.",
            "آندوسکوپی درجهٔ ۰ تا ۳ را مشخص می‌کند.",
            "درجهٔ ۳ عمیق خطر سوراخ و بعداً تنگی دارد.",
            "استروئید روتین دیگر توصیه نمی‌شود.",
            "PPI و NPO تا مشخص شدن درجه.",
            "عارضهٔ دیررس: تنگی مری و خطر سرطان اسکوآموس.",
            "لاواژ معده و شارکول جایی ندارند.",
            "روان‌پزشکی بعد از اقدام اورژانس برای خودکشی واجب است.",
        ],
        "points_en": [
            "Alkali liquefies and bores deep; acid coagulates.",
            "ABC and the airway come first if there is stridor or pharyngeal oedema.",
            "Chest and abdominal films look for free air.",
            "Endoscopy grades 0 to 3.",
            "Deep grade 3 risks perforation and later stricture.",
            "Routine steroids are no longer advised.",
            "PPI and nil-by-mouth until the grade is known.",
            "Late: oesophageal stricture and squamous-cancer risk.",
            "Gastric lavage and charcoal have no role.",
            "Psychiatry after the emergency step is mandatory after a suicide attempt.",
        ],
    },
    golden_fa="بلع لوله بازکن پایدار → آندوسکوپی. خنثی نکن و NG نگذار.",
    golden_en="Stable drain-cleaner ingestion → endoscopy. Do not neutralise and do not place an NG.",
    refs=["Schwartz / ATLS — Caustic ingestion"],
    concept="caustic-endo", concept_fa="آندوسکوپی سوزاننده", concept_en="Caustic endoscopy")

add("جراحی", 48,
    chapter_fa="زخم پپتیک / انسداد خروجی معده", chapter_en="Peptic ulcer / gastric outlet obstruction",
    options_why_fa=[
        "آنترکتومی قدم اول نیست؛ اول احیا و دکمپرسیون.",
        "پاسخ صحیح — استفراغ طول‌کشیده = آلکالوز هیپوکلرمیک هیپوکالمیک؛ NG و سالین اول است.",
        "بالون آندوسکوپیک بعد از پایدارسازی و شکست درمان طبی مطرح می‌شود.",
        "جراحی کاهندهٔ اسید انتخاب اولیهٔ امروز نیست (PPI و ارادیکاسیون هلیکوباکتر).",
    ],
    options_why_en=[
        "Antrectomy is not first; resuscitate and decompress first.",
        "Correct — prolonged vomiting is hypochloraemic hypokalaemic alkalosis; NG and saline come first.",
        "Endoscopic balloon comes after stabilisation and failed medical care.",
        "Acid-reducing surgery is not today's first choice (PPI and Helicobacter eradication).",
    ],
    explanation_fa=(
        "قطع PPI زخم دئودنوم را شعله‌ور کرده و خروجی معده را بسته است. بیمار ده روز استفراغ "
        "کرده پس حجم و پتاسیم و کلر از دست داده. اول NG برای دکمپرسیون و نرمال سالین با پتاسیم، "
        "بعد PPI وریدی و تصمیم جراحی یا بالون."
    ),
    explanation_en=(
        "Stopping the PPI flared a duodenal ulcer and closed the outlet. Ten days of vomiting "
        "has cost volume, potassium and chloride. First an NG to decompress and normal saline "
        "with potassium, then IV PPI, then a decision about surgery or a balloon."
    ),
    micro={
        "lead_fa": "GOO زخم: اول NG و سالین. چاقو بعد از احیاست.",
        "lead_en": "Ulcer GOO: NG and saline first. The knife comes after resuscitation.",
        "points_fa": [
            "علل GOO: زخم دئودنوم، سرطان آنتر، تنگی سوزاننده.",
            "استفراغ جهندهٔ غذای کهنه و succussion splash کلاسیک‌اند.",
            "آلکالوز متابولیک Paradoxical aciduria تا کلر جبران شود.",
            "سرم پتاسیم ممکن است دیر پایین بیاید؛ کمبود کل بدن زیاد است.",
            "PPI وریدی و درمان هلیکوباکتر بخش طبی است.",
            "بسیاری از انسدادهای التهابی با دکمپرسیون باز می‌شوند.",
            "جراحی اگر بعد از ۷۲ ساعت باز نشد یا بدخیمی ثابت شد.",
            "امروز بای‌پس یا آنترکتومی انتخابی‌اند نه روتین فوری.",
            "آندوسکوپی تشخیصی بعد از شستشوی معده.",
            "قطع خودسرانهٔ PPI را در شرح حال بپرس.",
        ],
        "points_en": [
            "GOO causes: duodenal ulcer, antral cancer, caustic stricture.",
            "Projectile stale-food vomiting and a succussion splash are classic.",
            "Metabolic alkalosis with paradoxical aciduria until chloride is replaced.",
            "Serum potassium may fall late; total-body deficit is large.",
            "IV PPI and Helicobacter treatment are the medical limb.",
            "Many inflammatory obstructions open with decompression.",
            "Operate if it is still closed after 72 hours or cancer is proven.",
            "Today a bypass or antrectomy is selective, not an immediate routine.",
            "Diagnostic endoscopy after the stomach is washed out.",
            "Ask about self-stopping PPI in the history.",
        ],
    },
    golden_fa="انسداد خروجی معده بعد از قطع PPI: NG + سالین اول. جراحی اول نیست.",
    golden_en="Gastric-outlet obstruction after stopping a PPI: NG plus saline first. Surgery is not first.",
    refs=["Schwartz — Gastric outlet obstruction"],
    concept="goo-ng", concept_fa="NG در GOO", concept_en="NG in GOO")

add("جراحی", 49,
    chapter_fa="انسداد روده", chapter_en="Bowel obstruction",
    options_why_fa=[
        "درد کولیکی خودِ انسداد مکانیکی است، نه نشانهٔ ایسکمی.",
        "درد مبهم دور ناف درد احشایی ساده است.",
        "پاسخ صحیح — تندرنس موضعی یعنی پریتونئوم درگیر شده؛ نگران استرانگولاسیون باش.",
        "استفراغ صفراوی در انسداد پروگزیمال شایع است و به‌تنهایی ایسکمی نیست.",
    ],
    options_why_en=[
        "Colic is mechanical obstruction itself, not a sign of ischaemia.",
        "Dull periumbilical pain is simple visceral pain.",
        "Correct — localised tenderness means the peritoneum is involved; worry about strangulation.",
        "Bilious vomiting is common in proximal obstruction and is not ischaemia by itself.",
    ],
    explanation_fa=(
        "بعد از لاپاراتومی شایع‌ترین انسداد چسبندگی است. کولیک، استفراغ و درد احشایی انتظار "
        "می‌رود. وقتی درد موضعی و تندرنس پیدا می‌شود دیواره در حال نکروز است و باید سریع‌تر "
        "به اتاق عمل فکر کرد."
    ),
    explanation_en=(
        "After a laparotomy the usual obstruction is adhesions. Colic, vomiting and visceral "
        "pain are expected. Once pain localises and tenderness appears the wall is dying and you should think of theatre sooner."
    ),
    micro={
        "lead_fa": "انسداد + تندرنس موضعی = ترس از رودهٔ مرده. کولیک تنها ترسناک نیست.",
        "lead_en": "Obstruction plus localised tenderness means fear dead bowel. Colic alone is not frightening.",
        "points_fa": [
            "علائم خطر ایسکمی: تب، تاکی‌کاردی، لکوسیتوز، اسیدوز لاکتیک، تندرنس.",
            "درد مداوم جای کولیک متناوب را می‌گیرد.",
            "CT با کنتراست دیواره نازک یا پنوماتوز را نشان می‌دهد.",
            "چسبندگی: اول NPO، NG، مایع؛ ۲۴–۴۸ ساعت اگر پیشرفتی نبود جراحی.",
            "فتق گیرکرده را در معاینه از قلم نینداز.",
            "هرنی داخلی و ولولوس زودتر جراحی می‌خواهند.",
            "استفراغ مدفوعی انسداد دیستال طول‌کشیده است نه ایسکمی خاص.",
            "لاکتات حساس است ولی اختصاصی نیست.",
            "ضد درد مخدر تشخیص تندرنس را پنهان نکند.",
            "سابقهٔ جراحی = اول به چسبندگی فکر کن تا تومور، مگر پرچم قرمز بدخیمی.",
        ],
        "points_en": [
            "Ischaemia red flags: fever, tachycardia, leucocytosis, lactic acidosis, tenderness.",
            "Continuous pain replaces intermittent colic.",
            "Contrast CT shows a thin wall or pneumatosis.",
            "Adhesions: first NPO, NG, fluid; operate at 24–48 hours if no progress.",
            "Do not miss an incarcerated hernia on the exam.",
            "Internal hernia and volvulus need earlier surgery.",
            "Faeculent vomiting is a long distal obstruction, not specific ischaemia.",
            "Lactate is sensitive but not specific.",
            "Do not let opioids hide tenderness.",
            "Prior surgery means think adhesions before tumour unless there are malignant red flags.",
        ],
    },
    golden_fa="در انسداد، تندرنس موضعی یعنی ایسکمی تا خلافش ثابت شود.",
    golden_en="In obstruction, localised tenderness is ischaemia until proven otherwise.",
    refs=["Schwartz — Small-bowel obstruction"],
    concept="sbo-ischemia", concept_fa="ایسکمی در انسداد", concept_en="Ischaemia in obstruction")

add("جراحی", 50,
    chapter_fa="آپاندیسیت", chapter_en="Appendicitis",
    options_why_fa=[
        "آپاندکتومی فوری لازم نیست؛ التهاب فروکش کرده و حال عمومی خوب است.",
        "آنتی‌بیوتیک خوراکی سه‌هفته‌ای به‌تنهایی برنامهٔ استاندارد نیست.",
        "آپاندکتومی فاصله‌دار سه‌هفته‌ای بدون رد سرطان در ۴۷ ساله ناقص است.",
        "پاسخ صحیح — بعد از ۴۰ سال، اول کولونوسکوپی برای رد سرطان سکوم، بعد تصمیم برای آپاندکتومی فاصله‌دار.",
    ],
    options_why_en=[
        "Immediate appendectomy is not needed; the inflammation has settled and he is well.",
        "Three weeks of oral antibiotic alone is not the standard plan.",
        "An interval appendectomy at three weeks without excluding cancer in a 47-year-old is incomplete.",
        "Correct — after 40, colonoscopy first to exclude caecal cancer, then decide on interval appendectomy.",
    ],
    explanation_fa=(
        "آبسهٔ آپاندیس درناژ شده و بیمار خوب است. در میانسال تودهٔ ایلئوسکال می‌تواند سرطان "
        "باشد نه فقط آپاندیس. کولونوسکوپی (یا حداقل تصویر کولون) قبل از آپاندکتومی انتخابی "
        "بهترین قدم است."
    ),
    explanation_en=(
        "An appendiceal abscess has been drained and he is well. In middle age an ileocaecal "
        "mass can be cancer, not just the appendix. Colonoscopy (or at least colonic imaging) "
        "before an elective appendectomy is the best next step."
    ),
    micro={
        "lead_fa": "آبسهٔ آپاندیس در بالای ۴۰ سال: کولونوسکوپی، بعد تصمیم عمل.",
        "lead_en": "An appendiceal abscess over 40: colonoscopy, then decide on an operation.",
        "points_fa": [
            "آپاندیسیت عارضه‌دار: فlegمون یا آبسه.",
            "آبسهٔ قابل درناژ: آنتی‌بیوتیک + درناژ پوستی.",
            "آپاندکتومی فاصله‌دار ۶–۸ هفته بعد در انتخابی‌ها.",
            "شواهد جدید بعضی بیماران را بدون عمل بعدی هم اداره می‌کنند.",
            "اما سن بالا، کم‌خونی، کاهش وزن = رد سرطان واجب است.",
            "سرطان سکوم می‌تواند آپاندیسیت تقلید کند.",
            "کولونوسکوپی هم پولیپ همزمان را می‌بیند.",
            "اگر حین درناژ مدفوع یا توده سفت بود، تصویربرداری کامل‌تر کن.",
            "آنتی‌بیوتیک طولانی به‌جای تشخیص، عفونت را فقط می‌پوشاند.",
            "بیمار را برای درد راجعه و تب آموزش بده.",
        ],
        "points_en": [
            "Complicated appendicitis: phlegmon or abscess.",
            "A drainable abscess: antibiotics plus percutaneous drainage.",
            "Interval appendectomy at 6–8 weeks in selected patients.",
            "Newer evidence manages some patients without a later operation.",
            "But older age, anaemia or weight loss makes excluding cancer mandatory.",
            "Caecal cancer can mimic appendicitis.",
            "Colonoscopy also finds a synchronous polyp.",
            "If drainage showed faeces or a hard mass, image more completely.",
            "Long antibiotics instead of a diagnosis only hide infection.",
            "Teach the patient about recurrent pain and fever.",
        ],
    },
    golden_fa="آبسهٔ آپاندیس در میانسال → کولونوسکوپی قبل از آپاندکتومی انتخابی.",
    golden_en="An appendiceal abscess in middle age → colonoscopy before an elective appendectomy.",
    refs=["Schwartz — Appendicitis; colonoscopy after abscess"],
    concept="interval-appy-colo", concept_fa="کولونوسکوپی بعد از آبسه آپاندیس", concept_en="Colonoscopy after appendiceal abscess")

# ─────────────────────────── PEDS 65–66 ───────────────────────────
add("کودکان", 65,
    chapter_fa="هماتولوژی / فقر آهن", chapter_en="Haematology / iron deficiency",
    options_why_fa=[
        "پک‌سل مال ناپایداری یا نارسایی قلب است؛ کودک پایدار است.",
        "اریتروپوئیتین مال نارسایی کلیه است نه فقر آهن تغذیه‌ای.",
        "پاسخ صحیح — کم‌خونی میکروسیتیک با RDW بالا، پلاکت واکنشی و مکمل نامنظم = آهن خوراکی درمانی.",
        "فولات ماکروسیتیک یا RDW متفاوت می‌دهد؛ MCV اینجا ۷۰ است.",
    ],
    options_why_en=[
        "Packed cells are for instability or heart failure; the child is stable.",
        "Erythropoietin is for renal failure, not dietary iron deficiency.",
        "Correct — microcytic anaemia with a high RDW, reactive platelets and irregular supplements is therapeutic oral iron.",
        "Folate gives a macrocytic picture; the MCV here is 70.",
    ],
    explanation_fa=(
        "شیرخوار یک‌ساله رنگ‌پریده با مکمل نامنظم، Hb ۶، MCV ۷۰، RDW ۱۶، پلاکت بالا و بدون "
        "هپاتواسپلنومگالی تصویر کلاسیک فقر آهن تغذیه‌ای است. پایدار است پس آهن خوراکی ۳–۶ "
        "میلی‌گرم/کیلو عنصر آهن، نه تزریق خون."
    ),
    explanation_en=(
        "A pale one-year-old with irregular supplements, Hb 6, MCV 70, RDW 16, high platelets "
        "and no organomegaly is classic dietary iron deficiency. She is stable, so therapeutic "
        "oral iron 3–6 mg/kg of elemental iron, not a transfusion."
    ),
    micro={
        "lead_fa": "شیرخوار پایدار با MCV پایین و RDW بالا = آهن خوراکی. خون نده.",
        "lead_en": "A stable toddler with a low MCV and high RDW gets oral iron. Do not transfuse.",
        "points_fa": [
            "اوج فقر آهن: ۶ ماه تا ۲ سال، شیر گاو زیاد، غذای کم‌آهن.",
            "پلاکت واکنشی در IDA شایع است.",
            "RDW بالا IDA را از تالاسمی مینور (RDW نرمال) جدا می‌کند.",
            "تالاسمی معمولاً Hb بالاتر و MCV خیلی پایین‌تر نسبت به Hb دارد.",
            "پاسخ رتیکولوسیت ۳–۵ روز بعد از آهن شروع می‌شود.",
            "درمان را حداقل ۳ ماه بعد از نرمال شدن Hb ادامه بده تا ذخیره پر شود.",
            "ترانسفوزیون اگر نارسایی قلب، اختلال هوشیاری یا Hb بسیار پایین ناپایدار باشد.",
            "هپاتواسپلنومگالی به همولیز یا بدخیمی می‌برد نه IDA ساده.",
            "فریتین پایین تشخیص را قطعی می‌کند ولی تابلوی کلاسیک درمان را عقب نمی‌اندازد.",
            "آموزش: آهن بین غذا با ویتامین C، نه همزمان با شیر.",
        ],
        "points_en": [
            "Peak iron deficiency: 6 months to 2 years, excess cow's milk, low-iron food.",
            "Reactive thrombocytosis is common in IDA.",
            "A high RDW separates IDA from thalassaemia minor (normal RDW).",
            "Thalassaemia usually has a higher Hb and a much lower MCV for that Hb.",
            "The reticulocyte response starts 3–5 days after iron.",
            "Continue treatment at least 3 months after Hb normalises to fill stores.",
            "Transfuse if there is heart failure, altered consciousness or an unstable very low Hb.",
            "Organomegaly points to haemolysis or malignancy, not simple IDA.",
            "A low ferritin confirms, but a classic picture should not delay treatment.",
            "Teach: iron between meals with vitamin C, not with milk.",
        ],
    },
    golden_fa="IDA پایدار کودک = آهن خوراکی درمانی. پک‌سل مال ناپایدار است.",
    golden_en="Stable childhood IDA is therapeutic oral iron. Packed cells are for the unstable child.",
    refs=["Nelson — Iron-deficiency anaemia"],
    concept="peds-ida", concept_fa="فقر آهن کودک", concept_en="Paediatric IDA")

add("کودکان", 66,
    chapter_fa="نفرولوژی / پروتئینوری", chapter_en="Nephrology / proteinuria",
    options_why_fa=[
        "سندرم نفروتیک پروتئین بالای ۴۰ میلی‌گرم/متر مربع/ساعت یا حدود ۳ گرم در روز و ادم می‌خواهد؛ ۶۰۰ میلی‌گرم و پسر سالم است.",
        "نفرتیک هماچوری، فشار بالا و الیگوری می‌خواهد که نیست.",
        "پروتئینوری گذرا با تب و ورزش است و نمونهٔ ۲۴ساعته پایدار ۶۰۰ میلی‌گرم نمی‌دهد.",
        "پاسخ صحیح — پروتئین ظهر مثبت، اول صبح منفی، پسر بلند لاغر نوجوان = ارتواستاتیک.",
    ],
    options_why_en=[
        "Nephrotic syndrome wants more than about 3 g/day and oedema; he has 600 mg and is well.",
        "Nephritic wants haematuria, hypertension and oliguria, which are absent.",
        "Transient proteinuria is fever and exercise and does not give a steady 600 mg in 24 hours.",
        "Correct — afternoon dipstick positive, first-morning negative, tall thin adolescent = orthostatic.",
    ],
    explanation_fa=(
        "پروتئینوری ارتواستاتیک در نوجوان قدبلند شایع و خوش‌خیم است: روز مثبت، درازکش شبانه "
        "منفی. پروتئین ۲۴ساعته معمولاً زیر ۱ گرم می‌ماند. بیوپسی و استروئید لازم نیست."
    ),
    explanation_en=(
        "Orthostatic proteinuria in a tall adolescent is common and benign: positive by day, "
        "negative after a night lying down. The 24-hour protein usually stays under 1 g. No biopsy and no steroids."
    ),
    micro={
        "lead_fa": "نوجوان سالم، صبح منفی و عصر مثبت = ارتواستاتیک. نفروتیک نیست.",
        "lead_en": "A well adolescent, negative in the morning and positive in the afternoon, is orthostatic. It is not nephrotic.",
        "points_fa": [
            "تشخیص با نمونهٔ اول صبح (نسبت پروتئین به کراتینین).",
            "اگر صبح هم مثبت بود مسیر گلومرول را برو.",
            "حد نفروتیک کودکان: ۳۵۰ میلی‌گرم/میلی‌مول یا ۴۰ mg/m²/h.",
            "۶۰۰ میلی‌گرم در ۲۴ ساعت خفیف است.",
            "پیش‌آگهی عالی است؛ سالی یک‌بار پیگیری کافی است.",
            "ورزش و تب پروتئین گذرا می‌سازند.",
            "اورتواستاتیک را با فشار خون و ادرار کامل رد عفونت و نفریت کن.",
            "بیوپسی اگر هماچوری، کاهش عملکرد، هیپوکمپلمان یا پروتئین پایدار صبح باشد.",
            "مهار ACE لازم نیست مگر پروتئین غیرارتواستاتیک پایدار.",
            "به خانواده اطمینان بده که کلیه خراب نیست.",
        ],
        "points_en": [
            "Diagnose with a first-morning protein/creatinine ratio.",
            "If the morning sample is also positive, take the glomerular path.",
            "Paediatric nephrotic threshold: 350 mg/mmol or 40 mg/m²/h.",
            "600 mg in 24 hours is mild.",
            "The outlook is excellent; yearly follow-up is enough.",
            "Exercise and fever make transient protein.",
            "Rule out infection and nephritis with blood pressure and a full urine.",
            "Biopsy if there is haematuria, falling function, low complement or persistent morning protein.",
            "An ACE inhibitor is not needed unless non-orthostatic protein persists.",
            "Reassure the family the kidney is not failing.",
        ],
    },
    golden_fa="پروتئینوری نوجوان سالم که صبح منفی است = ارتواستاتیک.",
    golden_en="Proteinuria in a well adolescent that is negative in the morning is orthostatic.",
    refs=["Nelson — Orthostatic proteinuria"],
    concept="orthostatic-protein", concept_fa="پروتئینوری ارتواستاتیک", concept_en="Orthostatic proteinuria")

# ─────────────────────────── OB/GYN 85–86 ───────────────────────────
add("زنان و زایمان", 85,
    chapter_fa="عفونت‌های آمیزشی", chapter_en="Sexually transmitted infection",
    options_why_fa=[
        "شانکروئید زخم دردناک با لبهٔ نامنظم و باسیل دوکری است، وزیکول دسته‌ای ندارد.",
        "LGV ابتدا پاپول گذراست و غدهٔ شیار grooved دیرتر می‌آید، تب وزیکول ژنیتال غالب نیست.",
        "سیفلیس شانکر دردناک نیست و وزیکول نمی‌دهد.",
        "پاسخ صحیح — وزیکول ژنیتال + غدهٔ دردناک + تب و بی‌حالی = هرپس اولیه.",
    ],
    options_why_en=[
        "Chancroid is a painful ragged ulcer from Ducrey's bacillus; it has no clustered vesicles.",
        "LGV starts as a fleeting papule and the grooved node comes later; fever plus genital vesicles is not the picture.",
        "Syphilis is a painless chancre and does not vesiculate.",
        "Correct — genital vesicles plus tender nodes plus fever and malaise is primary herpes.",
    ],
    explanation_fa=(
        "عفونت اولیهٔ HSV-2 (گاهی HSV-1) با سندرم سیستمیک، وزیکول‌های دردناک و لنفادنوپاتی "
        "دوطرفه مشخص می‌شود. درمان آسیکلوویر یا والاسیکلوویر است، نه آنتی‌بیوتیک باکتریایی."
    ),
    explanation_en=(
        "Primary HSV-2 (sometimes HSV-1) is a systemic illness with painful vesicles and "
        "bilateral lymphadenopathy. Treat with aciclovir or valaciclovir, not a bacterial antibiotic."
    ),
    micro={
        "lead_fa": "وزیکول دردناک ژنیتال + تب = هرپس. شانکر سیفلیس درد ندارد.",
        "lead_en": "Painful genital vesicles plus fever is herpes. A syphilitic chancre does not hurt.",
        "points_fa": [
            "اولیه شدیدتر از عود است.",
            "عود با پرودرم سوزش موضعی و بدون تب زیاد است.",
            "تشخیص: PCR از کف وزیکول.",
            "درمان حملهٔ اول ۷–۱۰ روز.",
            "در بارداری نزدیک ترم با ضایعه فعال، سزارین.",
            "شانکروئید: زخم عمیق چرکی، هموفیلوس دوکری، بیشتر در مناطق خاص.",
            "LGV: کلامیدیا L1–L3، غدهٔ چرکی و فیستول.",
            "سیفلیس: RPR/VDRL + تأیید ترپونمال.",
            "همهٔ زخم‌های ژنیتال را برای HIV و سیفلیس هم غربال کن.",
            "آموزش: کاندوم عود را کم می‌کند ولی صفر نمی‌کند.",
        ],
        "points_en": [
            "The first attack is worse than recurrences.",
            "Recurrence has a local burning prodrome and little fever.",
            "Diagnose with PCR from the vesicle floor.",
            "Treat a first episode for 7–10 days.",
            "Near term with an active lesion, deliver by caesarean.",
            "Chancroid: deep purulent ulcer, H. ducreyi, geographically limited.",
            "LGV: Chlamydia L1–L3, a suppurating node and fistula.",
            "Syphilis: RPR/VDRL plus a treponemal confirmatory test.",
            "Screen every genital ulcer for HIV and syphilis too.",
            "Teach: condoms cut recurrences but not to zero.",
        ],
    },
    golden_fa="وزیکول ژنیتال تب‌دار = هرپس. سیفلیس وزیکول و درد ندارد.",
    golden_en="Febrile genital vesicles are herpes. Syphilis has neither vesicles nor pain.",
    refs=["Williams / Harrison 21 — Genital herpes"],
    concept="hsv-primary", concept_fa="هرپس اولیه", concept_en="Primary herpes")

add("زنان و زایمان", 86,
    chapter_fa="یائسگی / آتروفی ژنیتواورینری", chapter_en="Menopause / genitourinary atrophy",
    options_why_fa=[
        "بتامتازون مال لیکن اسکلروزوس با پلاک سفید و خراش است، نه فقط از دست رفتن روگا.",
        "مترونیدازول مال واژینوز یا تریکوموناس با ترشح است؛ ترشح غیرطبیعی ندارد.",
        "پاسخ صحیح — سندرم ژنیتواورینری یائسگی: استروژن واژینال موضعی خط اول است.",
        "استروژن خوراکی سیستمیک برای این شکایت موضعی لازم نیست و در ۶۵ ساله خط اول نیست.",
    ],
    options_why_en=[
        "Betamethasone is for lichen sclerosus with white plaques and scratches, not mere loss of rugae.",
        "Metronidazole is for vaginosis or trichomonas with discharge; there is no abnormal discharge.",
        "Correct — genitourinary syndrome of menopause: vaginal oestrogen is first-line.",
        "Systemic oral oestrogen is not needed for this local complaint and is not first-line at 65.",
    ],
    explanation_fa=(
        "خشکی، سوزش، از بین رفتن چین‌های واژن و پرینهٔ براق بدون ترشح چرکی، آتروفی استروژن‌محروم "
        "است. استروژن کرم یا حلقهٔ واژینال کم‌دوز علائم را اصلاح می‌کند و اثر سیستمیک ناچیز دارد."
    ),
    explanation_en=(
        "Dryness, burning, lost vaginal folds and a shiny perineum without pus is oestrogen-deprivation "
        "atrophy. Low-dose vaginal cream or a ring fixes the symptoms with negligible systemic effect."
    ),
    micro={
        "lead_fa": "واژن خشک براق بعد از یائسگی = استروژن موضعی، نه استروئید و نه مترونیدازول.",
        "lead_en": "A dry shiny vagina after menopause is local oestrogen, not a steroid and not metronidazole.",
        "points_fa": [
            "GSM قبلاً آتروفیک واژینیت نام داشت.",
            "pH واژن بالا می‌رود و لاکتوباسیل کم می‌شود.",
            "علائم ادراری (سوزش، عفونت مکرر) هم جزء GSM است.",
            "مرطوب‌کننده و لوبریکانت خط کمکی‌اند.",
            "استروژن واژینال در بازماندهٔ سرطان پستان با مشورت انکولوژی.",
            "لیکن اسکلروزوس: پلاک سفید، فیوژن لبه‌ها، خطر اسکوآموس؛ استروئید خیلی قوی.",
            "کاندیدا ترشح پنیری و خارش در سن باروری می‌دهد.",
            "هورمون سیستمیک فقط اگر گرگرفتگی همزمان و در پنجرهٔ سنی باشد.",
            "پاسخ درمانی چند هفته طول می‌کشد؛ ادامهٔ نگهداری لازم است.",
            "بیوپسی اگر زخم، توده یا عدم پاسخ باشد.",
        ],
        "points_en": [
            "GSM used to be called atrophic vaginitis.",
            "Vaginal pH rises and lactobacilli fall.",
            "Urinary burning and recurrent UTI are part of GSM.",
            "Moisturisers and lubricants are adjuncts.",
            "Vaginal oestrogen after breast cancer needs the oncologist's say.",
            "Lichen sclerosus: white plaques, fused labia, squamous risk; ultra-potent steroid.",
            "Candida is a curdy discharge and itch in reproductive years.",
            "Systemic hormone only if there are flushes as well and she is still in the age window.",
            "Response takes weeks; maintenance is needed.",
            "Biopsy if there is an ulcer, a mass or no response.",
        ],
    },
    golden_fa="خشکی ولوواژن یائسگی بدون ترشح = استروژن موضعی.",
    golden_en="Postmenopausal vulvovaginal dryness without discharge is topical oestrogen.",
    refs=["Williams / NAMS — Genitourinary syndrome of menopause"],
    concept="gsm-local-estrogen", concept_fa="استروژن موضعی GSM", concept_en="Local oestrogen for GSM")


def apply():
    files = sorted(glob.glob(os.path.join(HERE, "import-payload.archive.part*.json")))
    n = 0
    for path in files:
        body = json.load(open(path, encoding="utf-8"))
        changed = False
        for q in body["questions"]:
            if int(q.get("year_num") or 0) != 1402:
                continue
            rec = L.get((q["subject_fa"], q["question_no"])) or L.get((q["subject_fa"], int(q.get("question_no") or 0)))
            if not rec:
                continue
            q["chapter_fa"] = rec["chapter_fa"]
            q["chapter_en"] = rec["chapter_en"]
            q["options_why_fa"] = rec["options_why_fa"]
            q["options_why_en"] = rec["options_why_en"]
            q["explanation_fa"] = rec["explanation_fa"]
            q["explanation_en"] = rec["explanation_en"]
            q["micro"] = rec["micro"]
            q["golden_fa"] = rec["golden_fa"]
            q["golden_en"] = rec["golden_en"]
            q["refs"] = rec["refs"]
            q["concept"] = rec["concept"]
            q["concept_fa"] = rec["concept_fa"]
            q["concept_en"] = rec["concept_en"]
            q["needs_lesson"] = False
            q["lesson_part"] = 1
            n += 1
            changed = True
        if changed:
            json.dump(body, open(path, "w", encoding="utf-8"), ensure_ascii=False)
    print(f"applied lessons to {n} Khordad-1402 questions")
    print("keys:", ", ".join(f"{s} q{no}" for s, no in sorted(L)))


if __name__ == "__main__":
    apply()
