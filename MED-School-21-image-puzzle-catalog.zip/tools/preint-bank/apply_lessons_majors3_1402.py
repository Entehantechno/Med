# -*- coding: utf-8 -*-
"""Khordad-1402 majors next cluster + one printed-key correction (chorio / CS).

Official English stems/options are never rewritten.
"""
import json, glob, os

HERE = os.path.dirname(os.path.abspath(__file__))
L = {}


def add(subj, no, **kw):
    L[(subj, no)] = kw


add("جراحی", 51,
    chapter_fa="کولون / دیورتیکولیت", chapter_en="Colon / diverticulitis",
    options_why_fa=[
        "رژیم پرفیبر مال پیشگیری بعد از فروکش التهاب است نه حملهٔ حاد شدید.",
        "پاسخ صحیح — درد و تندرنس شدید LLQ یعنی دیورتیکولیت حاد؛ بستری و آنتی‌بیوتیک وریدی.",
        "کولونوسکوپی اورژانس در التهاب حاد خطر پرفوراسیون دارد؛ ۶ هفته بعد انجام می‌شود.",
        "لاپاراتومی مال پریتونیت ژنرالیزه یا پرفوراسیون آزاد است؛ بقیه شکم نرم است.",
    ],
    options_why_en=[
        "A high-fibre diet is for prevention after the attack settles, not for a severe acute episode.",
        "Correct — severe LLQ pain and tenderness is acute diverticulitis; admit and give IV antibiotics.",
        "Emergency colonoscopy in acute inflammation risks perforation; do it six weeks later.",
        "Laparotomy is for generalised peritonitis or free perforation; the rest of the abdomen is soft.",
    ],
    explanation_fa=(
        "درد و تندرنس محدود ربع تحتانی چپ در مسن، تا خلافش ثابت شود دیورتیکولیت است. "
        "وقتی درد شدید است بستری و پوشش گرم‌منفی و بی‌هوازی لازم است. کولونوسکوپی و جراحی "
        "اورژانس مال عارضهٔ آزادند."
    ),
    explanation_en=(
        "Severe localised left-lower-quadrant pain in an older adult is diverticulitis until "
        "proven otherwise. When the pain is severe, admit and cover Gram-negatives and anaerobes. "
        "Emergency colonoscopy and laparotomy are for free complications."
    ),
    micro={
        "lead_fa": "LLQ شدید = دیورتیکولیت → بستری و آنتی‌بیوتیک. کولونوسکوپی الان نه.",
        "lead_en": "Severe LLQ is diverticulitis → admit and antibiotics. Not colonoscopy now.",
        "points_fa": [
            "دیورتیکول سیگموئید در غرب و ایران شایع است.",
            "Hinchey آبسه و پرفوراسیون را درجه‌بندی می‌کند.",
            "حملات خفیف بدون تندرنس شدید گاهی سرپایی درمان می‌شوند.",
            "تندرنس شدید، تب، ناتوانی خوراکی = بستری.",
            "پوشش: سیپروفلوکساسین+مترونیدازول یا پیپراسیلین-تازوباکتام.",
            "آبسه بزرگ درناژ پوستی می‌خواهد.",
            "پریتونیت ژنرالیزه Hartmann یا لاواژ لاپاراسکوپیک است.",
            "کولونوسکوپی ۶ هفته بعد برای رد سرطان.",
            "رژیم پرفیبر بعد از فروکش عود را کم می‌کند.",
            "CT روش تصویر انتخابی است نه کولونوسکوپی حاد.",
        ],
        "points_en": [
            "Sigmoid diverticula are common in the West and in Iran.",
            "Hinchey grades abscess and perforation.",
            "Mild attacks without severe tenderness can sometimes be treated as an outpatient.",
            "Severe tenderness, fever or inability to eat means admit.",
            "Cover with ciprofloxacin plus metronidazole, or piperacillin-tazobactam.",
            "A large abscess needs percutaneous drainage.",
            "Generalised peritonitis is Hartmann or laparoscopic lavage.",
            "Colonoscopy at six weeks excludes cancer.",
            "High fibre after settling cuts recurrences.",
            "CT is the imaging of choice, not acute colonoscopy.",
        ],
    },
    golden_fa="دیورتیکولیت شدید: بستری + آنتی‌بیوتیک. کولونوسکوپی اورژانس نکن.",
    golden_en="Severe diverticulitis: admit plus antibiotics. Do not do emergency colonoscopy.",
    refs=["Schwartz — Diverticulitis"],
    concept="diverticulitis-iv", concept_fa="دیورتیکولیت بستری", concept_en="Admit diverticulitis")

add("جراحی", 52,
    chapter_fa="سرطان کولون", chapter_en="Colon cancer",
    options_why_fa=[
        "پاسخ صحیح — کولون راست گشاد است؛ تومور تا کم‌خونی و تودهٔ دیررس بی‌علامت می‌ماند.",
        "کولون نزولی قطر کمتر دارد و زود انسداد می‌دهد.",
        "سیگموئید هم تنگ است و تغییر اجابت و انسداد زود است.",
        "رکتوم خون روشن و تنسموس می‌دهد و زود علامت می‌دهد.",
    ],
    options_why_en=[
        "Correct — the right colon is wide; a tumour stays silent until anaemia and a late mass.",
        "The descending colon is narrower and obstructs earlier.",
        "The sigmoid is also narrow, so habit change and obstruction come early.",
        "The rectum gives bright blood and tenesmus and declares itself early.",
    ],
    explanation_fa=(
        "سکوم و کولون صعودی ظرفیت زیادی دارند. تومور راست با خونریزی مخفی و کم‌خونی فقر آهن "
        "در مسن خود را نشان می‌دهد نه با انسداد. چپ و رکتوم زودتر علامت مکانیکی می‌دهند."
    ),
    explanation_en=(
        "The caecum and ascending colon have a large capacity. A right-sided tumour shows up "
        "as occult bleeding and iron-deficiency anaemia in an older adult, not as obstruction. "
        "The left colon and rectum declare themselves mechanically earlier."
    ),
    micro={
        "lead_fa": "تومور راست = کم‌خونی خاموش. تومور چپ = انسداد.",
        "lead_en": "A right-sided tumour is silent anaemia. A left-sided tumour is obstruction.",
        "points_fa": [
            "کم‌خونی فقر آهن جدید بعد از ۵۰ سال = کولونوسکوپی تا خلافش ثابت شود.",
            "تومور چپ: مدفوع باریک، درد قولنجی، انسداد.",
            "تومور رکتوم: خون روشن، تنسموس، احساس تخلیهٔ ناقص.",
            "CEA برای پیگیری است نه غربالگری.",
            "غربالگری متوسط‌خطر از ۵۰ (یا ۴۵) با FIT یا کولونوسکوپی.",
            "مرحله‌بندی CT سینه شکم لگن.",
            "درمان اصلی رزکسیون + برداشت غدد.",
            "شیمی‌درمانی ادجوانت در مرحلهٔ III.",
            "سندرم لینچ بیشتر راست را می‌گیرد.",
            "سؤال «بی‌علامت تا پیشرفته» تقریباً همیشه راست است.",
        ],
        "points_en": [
            "New iron-deficiency anaemia after 50 is colonoscopy until proven otherwise.",
            "Left tumour: pencil stools, colic, obstruction.",
            "Rectal tumour: bright blood, tenesmus, incomplete emptying.",
            "CEA is for follow-up, not screening.",
            "Average-risk screening from 50 (or 45) with FIT or colonoscopy.",
            "Stage with chest-abdomen-pelvis CT.",
            "Main treatment is resection plus nodes.",
            "Adjuvant chemotherapy in stage III.",
            "Lynch syndrome favours the right side.",
            "A 'silent until advanced' stem is almost always the right colon.",
        ],
    },
    golden_fa="سرطان بی‌علامت تا دیررس = کولون راست.",
    golden_en="A cancer that stays silent until late is the right colon.",
    refs=["Schwartz — Colorectal cancer"],
    concept="right-colon-silent", concept_fa="تومور خاموش راست", concept_en="Silent right-colon tumour")

add("جراحی", 53,
    chapter_fa="کیسه صفرا", chapter_en="Gallbladder",
    options_why_fa=[
        "پاسخ صحیح — کوله سیستیت حاد سنگی در فرد مناسب عمل: کوله سیستکتومی لاپاراسکوپیک در ۷۲ ساعت اول.",
        "کوله سیستوستومی مال بیمار خیلی بدحال یا نامناسب عمل است.",
        "ERCP مال ایکتر، کلانژیت یا سنگ مجرا است؛ اینجا ایکتر ندارد.",
        "تأخیر دو هفته‌ای مکتب قدیمی است و عود و چسبندگی را زیاد می‌کند.",
    ],
    options_why_en=[
        "Correct — acute calculous cholecystitis in a fit patient is laparoscopic cholecystectomy in the first 72 hours.",
        "Cholecystostomy is for a patient who is too sick or unfit for theatre.",
        "ERCP is for jaundice, cholangitis or a duct stone; there is no jaundice here.",
        "A two-week delay is the old school and raises recurrence and adhesions.",
    ],
    explanation_fa=(
        "تب مختصر، تندرنس ربع فوقانی راست، سنگ و جدار ضخیم بدون ایکتر، کوله سیستیت حاد است. "
        "استاندارد امروز عمل زودهنگام در همان بستری است نه انتظار دو هفته‌ای."
    ),
    explanation_en=(
        "Low-grade fever, right-upper-quadrant tenderness, stones and a thick wall without "
        "jaundice is acute cholecystitis. Today's standard is early surgery on the same admission, not a two-week wait."
    ),
    micro={
        "lead_fa": "کوله سیستیت حاد مناسب عمل = لاپاراسکوپی زود. ERCP مال ایکتر است.",
        "lead_en": "Acute cholecystitis in a fit patient is early laparoscopy. ERCP is for jaundice.",
        "points_fa": [
            "معیار توکیو: علامت موضعی + یافته سیستمیک + تصویر.",
            "سونوگرافی اول است: سنگ، جدار، علامت مورفی سونوگرافیک.",
            "پنجره طلایی عمل: ۲۴–۷۲ ساعت.",
            "آنتی‌بیوتیک تا عمل: پوشش روده‌ای.",
            "ERCP اگر بیلی‌روبین بالا، مجرای گشاد یا سنگ CBD.",
            "کوله سیستوستومی پوستی در ICU و ASA بالا.",
            "تأخیر انتخابی عود کولیک و کوله سیستیت می‌آورد.",
            "اگر امفیزماتو یا پرفوراسیون باشد اورژانس‌تر است.",
            "حاملگی سه‌ماهه دوم هم لاپاراسکوپی مجاز است.",
            "بعد از عمل زودهنگام اقامت کوتاه‌تر است.",
        ],
        "points_en": [
            "Tokyo criteria: local sign plus a systemic finding plus imaging.",
            "Ultrasound first: stone, wall, sonographic Murphy.",
            "The golden window is 24–72 hours.",
            "Antibiotics until theatre: gut cover.",
            "ERCP if bilirubin is high, the duct is wide or there is a CBD stone.",
            "Percutaneous cholecystostomy in ICU and high ASA.",
            "Delayed elective surgery brings recurrent colic and cholecystitis.",
            "Emphysematous or perforated disease is more urgent.",
            "Laparoscopy is allowed in the second trimester.",
            "Early surgery shortens the stay.",
        ],
    },
    golden_fa="کوله سیستیت حاد: عمل در چند روز اول. دو هفته صبر نکن.",
    golden_en="Acute cholecystitis: operate in the first few days. Do not wait two weeks.",
    refs=["Schwartz / Tokyo guidelines — Cholecystitis"],
    concept="early-chole", concept_fa="کوله سیستکتومی زودرس", concept_en="Early cholecystectomy")

add("جراحی", 54,
    chapter_fa="پانکراتیت", chapter_en="Pancreatitis",
    options_why_fa=[
        "پاسخ صحیح — اگر خوراکی تحمل نشد تغذیه نازوژژنال ارجح است و روده را زنده نگه می‌دارد.",
        "آنالوگ سوماتواستاتین مرگ‌ومیر را کم نکرده و روتین نیست.",
        "آنتی‌بیوتیک تجربی در پانکراتیت استریل توصیه نمی‌شود.",
        "دبریدمان فقط برای نکروز عفونی علامت‌دار است نه «اغلب».",
    ],
    options_why_en=[
        "Correct — if the patient cannot eat, nasojejunal feeding is preferred and keeps the gut alive.",
        "A somatostatin analogue has not cut mortality and is not routine.",
        "Empiric antibiotics are not advised in sterile pancreatitis.",
        "Debridement is only for infected symptomatic necrosis, not 'often'.",
    ],
    explanation_fa=(
        "در پانکراتیت حاد تغذیه روده‌ای زودهنگام بهتر از TPN است. اگر معده تحمل نکرد "
        "لوله ژژنال می‌گذارند. آنتی‌بیوتیک پیشگیرانه و اکتروتاید و جراحی زودهنگام جایی ندارند."
    ),
    explanation_en=(
        "In acute pancreatitis early enteral feeding beats TPN. If the stomach is not tolerated "
        "a jejunal tube is placed. Prophylactic antibiotics, octreotide and early surgery have no role."
    ),
    micro={
        "lead_fa": "پانکراتیت: غذا از روده اگر شد، حتی با نازوژژنال. آنتی‌بیوتیک روتین نه.",
        "lead_en": "Pancreatitis: feed the gut if you can, even via nasojejunal. No routine antibiotics.",
        "points_fa": [
            "احیا با کریستالوئید و کنترل درد پایه است.",
            "علل: سنگ و الکل را اول بجو.",
            "تغذیه خوراکی وقتی درد کم شد شروع می‌شود.",
            "نازومعده فقط برای استفراغ مقاوم.",
            "آنتی‌بیوتیک اگر نکروز عفونی یا کلانژیت ثابت شد.",
            "تشخیص عفونت: گاز در نکروز یا FNA.",
            "مداخله نکروز دیر (بعد از ۴ هفته) و ترجیحاً گام‌به‌گام.",
            "اکتروتاید فایده ثابت ندارد.",
            "ERCP زودهنگام فقط کلانژیت یا سنگ گیرکرده.",
            "سندرم کمپارتمان و ARDS را پایش کن.",
        ],
        "points_en": [
            "Resuscitation with crystalloid and pain control are the base.",
            "Hunt stones and alcohol first.",
            "Start oral feeding when the pain eases.",
            "A nasogastric tube is only for relentless vomiting.",
            "Antibiotics if infected necrosis or cholangitis is proven.",
            "Infection: gas in the necrosis or FNA.",
            "Intervene on necrosis late (after 4 weeks) and preferably step-up.",
            "Octreotide has no proven benefit.",
            "Early ERCP only for cholangitis or an impacted stone.",
            "Watch for compartment syndrome and ARDS.",
        ],
    },
    golden_fa="پانکراتیت: تغذیه روده‌ای (حتی نازوژژنال) بله. آنتی‌بیوتیک تجربی نه.",
    golden_en="Pancreatitis: enteral feeding (even nasojejunal) yes. Empiric antibiotics no.",
    refs=["Schwartz / IAP-APA — Acute pancreatitis"],
    concept="pancreatitis-nj", concept_fa="تغذیه نازوژژنال پانکراتیت", concept_en="NJ feeding in pancreatitis")

add("داخلی", 15,
    chapter_fa="روماتولوژی / آرتریت روماتوئید", chapter_en="Rheumatology / rheumatoid arthritis",
    options_why_fa=[
        "پاسخ صحیح — پلی‌آرتریت قرینه MCP و PIP + ESR بالا = anti-CCP برای قطعی کردن RA.",
        "anti-Scl-70 مال اسکلرودرمی منتشر است نه این الگوی مفصل.",
        "آنتی‌کاردیولیپین مال APS و ترومبوز/سقط است.",
        "anti-dsDNA مال لوپوس فعال کلیوی است.",
    ],
    options_why_en=[
        "Correct — symmetric MCP and PIP polyarthritis plus a high ESR is anti-CCP to confirm RA.",
        "Anti-Scl-70 is for diffuse scleroderma, not this joint pattern.",
        "Anticardiolipin is for APS and thrombosis or miscarriage.",
        "Anti-dsDNA is for active lupus nephritis.",
    ],
    explanation_fa=(
        "درگیری قرینه مفاصل کوچک دست به‌جز DIP تصویر کلاسیک RA است. اختصاصی‌ترین سرولوژی "
        "anti-CCP است. بقیه آنتی‌بادی‌ها بیماری‌های دیگر را می‌گویند."
    ),
    explanation_en=(
        "Symmetric small-joint disease of the hands sparing the DIP is classic RA. The most "
        "specific serology is anti-CCP. The other antibodies name other diseases."
    ),
    micro={
        "lead_fa": "MCP و PIP قرینه = anti-CCP. DIP مال استئوآرتریت و پسوریازیس است.",
        "lead_en": "Symmetric MCP and PIP is anti-CCP. DIP is osteoarthritis or psoriasis.",
        "points_fa": [
            "RF حساس‌تر و CCP اختصاصی‌تر است.",
            "هر دو با هم پیش‌آگهی اروزیو را بالا می‌برند.",
            "تشخیص بالینی است؛ سرولوژی منفی RA را رد نمی‌کند.",
            "ESR و CRP فعالیت را می‌سنجند نه تشخیص قطعی.",
            "درمان زود با DMARD (متوترکسات) مفصل را نجات می‌دهد.",
            "Scl-70: فیبروز ریه و پوست سفت.",
            "dsDNA و کمپلمان پایین: نفریت لوپوس.",
            "کاردیولیپین: APS.",
            "رادیوگرافی دست: اروزیون و استئوپنی جنب‌مفصلی.",
            "ندول روماتوئید و درگیری گردن را فراموش نکن.",
        ],
        "points_en": [
            "RF is more sensitive and CCP more specific.",
            "Both together raise the erosive outlook.",
            "The diagnosis is clinical; seronegative RA exists.",
            "ESR and CRP measure activity, not a final diagnosis.",
            "Early DMARD (methotrexate) saves the joint.",
            "Scl-70: lung fibrosis and tight skin.",
            "dsDNA and low complement: lupus nephritis.",
            "Cardiolipin: APS.",
            "Hand films: erosions and periarticular osteopenia.",
            "Do not forget rheumatoid nodules and the cervical spine.",
        ],
    },
    golden_fa="پلی‌آرتریت قرینه دست: anti-CCP بخواه نه Scl-70 و dsDNA.",
    golden_en="Symmetric hand polyarthritis: ask for anti-CCP, not Scl-70 or dsDNA.",
    refs=["Harrison 21 — Rheumatoid arthritis"],
    concept="anti-ccp", concept_fa="anti-CCP", concept_en="Anti-CCP")

add("داخلی", 16,
    chapter_fa="اسپوندیلوآرتروپاتی", chapter_en="Spondyloarthropathy",
    options_why_fa=[
        "پسوریازیس بیشتر پلاک اکستانسور است نه فقط کف دست و پا + اورتریت و کنژنکتیویت همزمان.",
        "پاسخ صحیح — آرتریت + ضایعه کف دست‌وپا + کنژنکتیویت + اورتریت = ری‌اکتیو (رایتر).",
        "آرتریت روده‌ای با IBD ثابت می‌شود که اینجا نیست.",
        "اسپوندیلیت آنکیلوزان کمردرد التهابی غالب است و پوست کف دست نمی‌دهد.",
    ],
    options_why_en=[
        "Psoriasis is mostly extensor plaques, not just palms and soles plus urethritis and conjunctivitis together.",
        "Correct — arthritis plus palmoplantar lesions plus conjunctivitis plus urethritis is reactive (Reiter).",
        "Enteropathic arthritis needs established IBD, which is not here.",
        "Ankylosing spondylitis is mostly inflammatory back pain and does not give palmoplantar skin.",
    ],
    explanation_fa=(
        "سه‌گانه کلاسیک رایتر: آرتریت، اورتریت، کنژنکتیویت. کراتودرما بلنوراژیکوم کف دست و پا "
        "را می‌گیرد. بعد از عفونت گوارشی یا ادراری-تناسلی می‌آید."
    ),
    explanation_en=(
        "The classic Reiter triad is arthritis, urethritis and conjunctivitis. Keratoderma "
        "blennorrhagicum hits palms and soles. It follows a gut or genitourinary infection."
    ),
    micro={
        "lead_fa": "نمی‌توانم ببینم، ادرار کنم، راه بروم = ری‌اکتیو.",
        "lead_en": "Can't see, can't pee, can't climb a tree = reactive.",
        "points_fa": [
            "محرک: کلامیدیا، سالمونلا، شیگلا، یرسینیا، کمپیلوباکتر.",
            "HLA-B27 زمینه را می‌سازد.",
            "درمان: NSAID؛ اگر عفونت فعال کلامیدیا بود آنتی‌بیوتیک.",
            "استروئید داخل مفصل برای مونوآرتریت مقاوم.",
            "پسوریازیس ناخن و DIP و پلاک اکستانسور دارد.",
            "IBD اسهال مزمن و خون می‌دهد.",
            "AS: ساکروایلئیت دوطرفه و محدودیت قفسه.",
            "ایریت حاد قدامی در کل گروه اسپوندیلو شایع است.",
            "کشت مدفوع و ادرار و PCR کلامیدیا در حمله اول.",
            "HIV را در ری‌اکتیو شدید رد کن.",
        ],
        "points_en": [
            "Triggers: Chlamydia, Salmonella, Shigella, Yersinia, Campylobacter.",
            "HLA-B27 is the background.",
            "Treat with an NSAID; add an antibiotic if Chlamydia is still active.",
            "Intra-articular steroid for a stubborn monoarthritis.",
            "Psoriasis has nails, DIP and extensor plaques.",
            "IBD gives chronic bloody diarrhoea.",
            "AS: bilateral sacroiliitis and a stiff chest.",
            "Acute anterior uveitis is common across the spondylo group.",
            "Stool and urine culture and Chlamydia PCR on the first attack.",
            "Exclude HIV in severe reactive disease.",
        ],
    },
    golden_fa="آرتریت + اورتریت + کنژنکتیویت + کف دست‌وپا = ری‌اکتیو.",
    golden_en="Arthritis plus urethritis plus conjunctivitis plus palms and soles is reactive.",
    refs=["Harrison 21 — Reactive arthritis"],
    concept="reactive-arthritis", concept_fa="آرتریت ری‌اکتیو", concept_en="Reactive arthritis")

add("داخلی", 17,
    chapter_fa="شانه / کپسولیت چسبنده", chapter_en="Shoulder / adhesive capsulitis",
    options_why_fa=[
        "NSAID درد را کم می‌کند و مجاز است.",
        "تزریق داخل‌مفصلی گلوکوکورتیکوئید التهاب کپسول را کم می‌کند.",
        "فیزیوتراپی و کشش تدریجی درمان اصلی دامنه حرکت است.",
        "پاسخ صحیح — بی‌حرکتی کپسولیت را بدتر می‌کند و توصیه نمی‌شود.",
    ],
    options_why_en=[
        "An NSAID cuts pain and is allowed.",
        "An intra-articular glucocorticoid cuts capsular inflammation.",
        "Physiotherapy and gradual stretch are the main range treatment.",
        "Correct — immobilisation makes frozen shoulder worse and is not advised.",
    ],
    explanation_fa=(
        "کپسولیت چسبنده (شانه یخ‌زده) در دیابت شایع است. درمان فعال است: ضددرد، تزریق و "
        "حرکت. آتل و بی‌حرکتی چسبندگی را بیشتر می‌کند."
    ),
    explanation_en=(
        "Adhesive capsulitis (frozen shoulder) is common in diabetes. Treatment is active: "
        "analgesia, injection and movement. A sling and rest make adhesions worse."
    ),
    micro={
        "lead_fa": "شانه یخ‌زده را حرکت بده. بی‌حرکت نگذار.",
        "lead_en": "Move a frozen shoulder. Do not rest it.",
        "points_fa": [
            "سه فاز: درد، خشکی، ذوب.",
            "محدودیت فعال و غیرفعال در همه جهات، به‌ویژه چرخش خارجی.",
            "دیابت و کم‌کاری تیروئید زمینه‌اند.",
            "تشخیص بالینی است؛ MRI برای رد پارگی کاف.",
            "NSAID و تزریق و فیزیوتراپی خط اول‌اند.",
            "هیدرودیلاتاسیون در مقاوم‌ها.",
            "دستکاری زیر بیهوشی یا آرترولیز دیر و نادر است.",
            "بهبود خودبه‌خود ماه‌ها تا دو سال طول می‌کشد.",
            "بی‌حرکتی بعد از immobilisation شانه هم همین را می‌سازد — پیشگیری با حرکت زود.",
            "سؤال «صحیح نیست» یعنی سه تا درست‌اند.",
        ],
        "points_en": [
            "Three phases: painful, frozen, thawing.",
            "Active and passive loss in all planes, especially external rotation.",
            "Diabetes and hypothyroidism are the background.",
            "The diagnosis is clinical; MRI excludes a cuff tear.",
            "NSAID, injection and physiotherapy are first-line.",
            "Hydrodilatation in stubborn cases.",
            "Manipulation under anaesthesia or arthrolysis is late and rare.",
            "Spontaneous recovery takes months to two years.",
            "Shoulder rest after immobilisation causes the same picture — prevent it with early movement.",
            "A 'which is not correct' stem means three are right.",
        ],
    },
    golden_fa="کپسولیت چسبنده: حرکت و تزریق. بی‌حرکتی غلط است.",
    golden_en="Frozen shoulder: move and inject. Immobilisation is wrong.",
    refs=["Harrison 21 — Frozen shoulder"],
    concept="frozen-shoulder", concept_fa="شانه یخ‌زده", concept_en="Frozen shoulder")

add("داخلی", 18,
    chapter_fa="لوپوس", chapter_en="Lupus",
    options_why_fa=[
        "اندوکاردیت لیбمن-ساکس دریچه‌ای است ولی امروز علت اول مرگ نیست.",
        "پنومونیت لوپوسی نادر است.",
        "پریکاردیت constrictive در لوپوس شایع نیست.",
        "پاسخ صحیح — نفریت لوپوس هنوز مهم‌ترین عامل مرگ مرتبط با خود بیماری است.",
    ],
    options_why_en=[
        "Libman-Sacks endocarditis is real but is not today's leading cause of death.",
        "Lupus pneumonitis is rare.",
        "Constrictive pericarditis is uncommon in lupus.",
        "Correct — lupus nephritis is still the leading disease-related cause of death.",
    ],
    explanation_fa=(
        "درمان مدرن عفونت و بیماری قلبی را پررنگ کرده، اما در سؤال‌های آزمون داخلی ایران "
        "مهم‌ترین عامل مرگ مرتبط با فعالیت لوپوس نفریت (به‌ویژه کلاس IV) است."
    ),
    explanation_en=(
        "Modern treatment has made infection and heart disease more visible, but in Iranian "
        "internal-medicine exams the leading disease-related killer in lupus is nephritis (especially class IV)."
    ),
    micro={
        "lead_fa": "مرگ لوپوس در آزمون داخلی = نفریت. عفونت را هم همیشه در بالین در نظر بگیر.",
        "lead_en": "Lupus death in an internal exam is nephritis. Always consider infection at the bedside too.",
        "points_fa": [
            "کلاس III و IV پیش‌آگهی بدتری دارند.",
            "dsDNA بالا و کمپلمان پایین فعالیت کلیوی را نشان می‌دهد.",
            "درمان القایی: مایکوفنولات یا سیکلوفسفامید + استروئید.",
            "نگهداری: مایکوفنولات یا آزاتیوپرین.",
            "عفونت به خاطر استروئید و ایمونوساپرسیو قاتل مهم بالینی است.",
            "آترواسکلروز زودرس قاتل دیررس است.",
            "لیبمن-ساکس بیشتر آمبولی می‌دهد تا مرگ مستقیم.",
            "پریکاردیت شایع است ولی تامپوناد نادر.",
            "پایش ادرار و کراتینین در هر ویزیت لوپوس.",
            "بارداری نفریت را شعله می‌کند.",
        ],
        "points_en": [
            "Classes III and IV have a worse outlook.",
            "High dsDNA and low complement mark renal activity.",
            "Induction: mycophenolate or cyclophosphamide plus steroid.",
            "Maintenance: mycophenolate or azathioprine.",
            "Infection from steroids and immunosuppression is a major bedside killer.",
            "Early atherosclerosis is the late killer.",
            "Libman-Sacks embolises more than it kills directly.",
            "Pericarditis is common but tamponade is rare.",
            "Check urine and creatinine at every lupus visit.",
            "Pregnancy flares nephritis.",
        ],
    },
    golden_fa="در آزمون: مهم‌ترین مرگ لوپوس = نفریت.",
    golden_en="In the exam: the leading lupus death is nephritis.",
    refs=["Harrison 21 — SLE; lupus nephritis"],
    concept="lupus-nephritis-mortality", concept_fa="مرگ نفریت لوپوس", concept_en="Lupus nephritis mortality")

add("کودکان", 67,
    chapter_fa="ارتوپدی کودکان / هیپ", chapter_en="Paediatric orthopaedics / hip",
    options_why_fa=[
        "درد شدید و تندرنس به نفع سپتیک آرتریت است نه سینویت گذرا.",
        "لکوسیتوز معیار کوچر برای عفونت است.",
        "WBC بالای مایع مفصل عفونت را می‌گوید.",
        "پاسخ صحیح — نبود تب قوی‌ترین یافته به نفع سینویت گذراست.",
    ],
    options_why_en=[
        "Severe pain and tenderness favour septic arthritis, not transient synovitis.",
        "Leucocytosis is a Kocher criterion for infection.",
        "A high synovial WBC means infection.",
        "Correct — being afebrile is the strongest finding for transient synovitis.",
    ],
    explanation_fa=(
        "معیارهای کوچر: تب، عدم تحمل وزن، ESR/CRP بالا، WBC بالا. هرچه بیشتر، احتمال چرک "
        "مفصل بیشتر است. کودک بدون تب خیلی کمتر سپتیک است."
    ),
    explanation_en=(
        "Kocher criteria: fever, non-weight-bearing, high ESR/CRP, high WBC. The more you "
        "have, the more likely the joint is pus. An afebrile child is much less often septic."
    ),
    micro={
        "lead_fa": "هیپ دردناک بدون تب = بیشتر سینویت گذرا. تب = سپتیک را جدی بگیر.",
        "lead_en": "A painful hip without fever is usually transient synovitis. Fever means take septic seriously.",
        "points_fa": [
            "سینویت گذرا بعد از ویروس تنفسی در ۳–۸ سال.",
            "سپتیک آرتریت هیپ اورژانس است (تخریب غضروف در ساعت).",
            "سونوگرافی افیوژن را می‌بیند ولی استریل را از چرک جدا نمی‌کند.",
            " Aspiration وقتی شک عفونت بالاست.",
            "CRP سریع‌ترین آزمایش پیگیری است.",
            "درمان سینویت: استراحت نسبی و NSAID و پیگیری ۲۴ ساعت.",
            "درمان سپتیک: درناژ و آنتی‌بیوتیک وریدی.",
            "لنگش بدون تب را هم اگر بدتر شد دوباره ببین.",
            "پرتس و SCFE را در سن مناسب رد کن.",
            "عدم تحمل کامل وزن یک پرچم قرمز است.",
        ],
        "points_en": [
            "Transient synovitis follows a respiratory virus at 3–8 years.",
            "Septic hip is an emergency (cartilage dies in hours).",
            "Ultrasound sees an effusion but does not separate sterile from pus.",
            "Aspirate when infection is likely.",
            "CRP is the fastest follow-up lab.",
            "Treat synovitis with relative rest, an NSAID and a 24-hour review.",
            "Treat septic disease with drainage and IV antibiotics.",
            "Review a limp without fever if it worsens.",
            "Exclude Perthes and SCFE at the right age.",
            "Complete refusal to bear weight is a red flag.",
        ],
    },
    golden_fa="افتراق هیپ کودک: نبود تب به نفع سینویت گذراست.",
    golden_en="Child hip: no fever favours transient synovitis.",
    refs=["Nelson — Transient synovitis vs septic arthritis"],
    concept="transient-synovitis", concept_fa="سینویت گذرای هیپ", concept_en="Transient hip synovitis")

add("کودکان", 68,
    chapter_fa="آلرژی / اورژانس", chapter_en="Allergy / emergency",
    options_why_fa=[
        "پاسخ صحیح — غذا + کهیر/فلاشینگ + استفراغ + افت فشار و تاکی‌پنه = آنافیلاکسی.",
        "استاتوس تشنج تونیک-کلونیک دارد نه فلاشینگ و استفراغ غذایی.",
        "مسمومیت غذایی اسهال دسته‌جمعی می‌دهد نه شوک در نیم ساعت.",
        "سنکوپ ساده پوست قرمز و تاکی‌پنه ۴۱ نمی‌دهد.",
    ],
    options_why_en=[
        "Correct — food plus hives/flushing plus vomiting plus low pressure and tachypnoea is anaphylaxis.",
        "Status epilepticus is tonic-clonic, not flushing and food vomiting.",
        "Food poisoning is shared diarrhoea, not shock in half an hour.",
        "Simple syncope does not give red skin and a respiratory rate of 41.",
    ],
    explanation_fa=(
        "آنافیلاکسی معیار بالینی دارد: پوست به‌علاوه درگیری تنفس یا گردش یا گوارش بعد از "
        "مواجهه محتمل. اینجا هر سه سیستم هست. درمان آدرنالین عضلانی فوری است."
    ),
    explanation_en=(
        "Anaphylaxis is a clinical diagnosis: skin plus breathing or circulation or gut after "
        "a likely exposure. All three systems are here. Treatment is immediate intramuscular adrenaline."
    ),
    micro={
        "lead_fa": "غذا + پوست + شوک = آنافیلاکسی → آدرنالین ران، نه آنتی‌هیستامین اول.",
        "lead_en": "Food plus skin plus shock is anaphylaxis → thigh adrenaline, not antihistamine first.",
        "points_fa": [
            "دوز کودک: ۰٫۰۱ mg/kg از ۱:۱۰۰۰ عضلانی، حداکثر ۰٫۳–۰٫۵.",
            "تکرار هر ۵–۱۵ دقیقه اگر لازم شد.",
            "درازکش با پا بالا؛ راه هوایی را باز نگه دار.",
            "آنتی‌هیستامین و استروئید کمکی‌اند نه نجات‌دهنده.",
            "فاز دوفازی تا ۷۲ ساعت ممکن است؛ مشاهده لازم است.",
            "تجویز قلم آدرنالین و آموزش خانواده.",
            "سنکوپ رنگ‌پریده و برادی است نه فلاشینگ و تاکی.",
            "تشنج حرکات ریتمیک و وضعیت بعد از حمله دارد.",
            "مسمومیت ساعات بعد اسهال می‌دهد.",
            "شیر گاو و بادام‌زمینی و کنجد در ایران شایع‌اند.",
        ],
        "points_en": [
            "Child dose: 0.01 mg/kg of 1:1000 IM, max 0.3–0.5.",
            "Repeat every 5–15 minutes if needed.",
            "Lie the child flat with legs up; keep the airway.",
            "Antihistamine and steroid are adjuncts, not the rescue.",
            "A biphasic wave can come within 72 hours; observe.",
            "Prescribe an adrenaline pen and teach the family.",
            "Syncope is pale and slow, not flushed and tachycardic.",
            "Seizure has rhythmic movement and a post-ictal state.",
            "Poisoning gives diarrhoea hours later.",
            "Cow's milk, peanut and sesame are common in Iran.",
        ],
    },
    golden_fa="شوک بعد از غذا با پوست قرمز = آنافیلاکسی. آدرنالین اول.",
    golden_en="Shock after food with red skin is anaphylaxis. Adrenaline first.",
    refs=["Nelson / WAO — Anaphylaxis"],
    concept="peds-anaphylaxis", concept_fa="آنافیلاکسی کودک", concept_en="Paediatric anaphylaxis")

add("زنان و زایمان", 87,
    chapter_fa="پیشگیری / HPV", chapter_en="Prevention / HPV",
    options_why_fa=[
        "واکسن جای غربالگری سرویکس را نمی‌گیرد.",
        "آلودگی قبلی کنتراندیکاسیون نیست؛ تیپ‌های دیگر را می‌پوشاند.",
        "پاسخ صحیح — شیردهی مانعی برای واکسن HPV نیست.",
        "شروع روتین از ۹ سال است نه ۷.",
    ],
    options_why_en=[
        "The vaccine does not replace cervical screening.",
        "Prior infection is not a contraindication; other types are still covered.",
        "Correct — breastfeeding is not a barrier to HPV vaccine.",
        "Routine start is age 9, not 7.",
    ],
    explanation_fa=(
        "واکسن HPV غیرفعال/پروتئینی است و در شیردهی مجاز است. غربالگری ادامه دارد. "
        "شروع توصیه معمولاً ۹–۱۴ سال است."
    ),
    explanation_en=(
        "HPV vaccine is inactivated/protein and is allowed in breastfeeding. Screening "
        "continues. The usual start is 9–14 years."
    ),
    micro={
        "lead_fa": "HPV در شیردهی مجاز است. غربالگری را قطع نکن.",
        "lead_en": "HPV vaccine is fine in breastfeeding. Do not stop screening.",
        "points_fa": [
            "هدف: تیپ‌های ۱۶ و ۱۸ و زگیل ۶ و ۱۱.",
            "بهترین اثر قبل از شروع فعالیت جنسی است.",
            "اگر دیرتر هم آمد باز هم بده.",
            "حاملگی معمولاً تزریق را عقب می‌اندازد؛ شیردهی نه.",
            "عارضه شایع: درد محل و سنکوپ وازوواگال — ۱۵ دقیقه بنشیند.",
            "پاپیلوما ویروس زنده نیست؛ ایمنی سلولی قوی می‌سازد.",
            "غربالگری از ۲۵ (یا طبق پروتکل ملی) ادامه دارد.",
            "زگیل فعال درمان موضعی می‌خواهد جدا از واکسن.",
            "HIV و ایمنی‌نقص از فواید واکسن محروم نمی‌شوند.",
            "سه دوز اگر بعد از ۱۵ سال شروع شود.",
        ],
        "points_en": [
            "Target: types 16 and 18 and warts 6 and 11.",
            "Best effect is before sexual debut.",
            "Give it even if she presents later.",
            "Pregnancy usually delays a dose; breastfeeding does not.",
            "Common: local pain and vasovagal syncope — sit 15 minutes.",
            "It is not a live papillomavirus; it builds strong cellular immunity.",
            "Screening from 25 (or the national protocol) continues.",
            "Active warts need local treatment separate from the vaccine.",
            "HIV and immunodeficiency still benefit.",
            "Three doses if started after 15.",
        ],
    },
    golden_fa="واکسن HPV در شیردهی مجاز است و غربالگری را حذف نمی‌کند.",
    golden_en="HPV vaccine is allowed in breastfeeding and does not cancel screening.",
    refs=["Williams / CDC — HPV vaccine"],
    concept="hpv-breastfeed", concept_fa="واکسن HPV شیردهی", concept_en="HPV vaccine in breastfeeding")

add("زنان و زایمان", 88,
    chapter_fa="عفونت داخل‌آمنیون", chapter_en="Intra-amniotic infection",
    options_why_fa=[
        "پاسخ صحیح پس از تصحیح — کوریوآمنیونیت: آنتی‌بیوتیک فوری و زایمان؛ راه زایمان اندیکاسیون مامایی است نه سزارین اجباری.",
        "سزارین اورژانس فقط به‌خاطر کوریو لازم نیست.",
        "کلید چاپی این گزینه را زده؛ آنتی‌بیوتیک را نباید تا بعد از سزارین عقب انداخت و خود کوریو اندیکاسیون سزارین نیست.",
        "۴۸ ساعت صبر کردن منبع عفونت را در رحم نگه می‌دارد.",
    ],
    options_why_en=[
        "Correct after the key fix — chorioamnionitis: immediate antibiotics and delivery; the route is obstetric, not automatic caesarean.",
        "Emergency caesarean is not required for chorio alone.",
        "The printed key marks this; do not delay antibiotics until after caesarean, and chorio itself is not a caesarean indication.",
        "Waiting 48 hours leaves the source in the uterus.",
    ],
    explanation_fa=(
        "تصحیح کلید چاپی که سزارین فوری و آنتی‌بیوتیک بعد از زایمان را زده بود. "
        "کوریوآمنیونیت (تب + تاکی‌کاردی + لکوسیتوز بعد از پارگی طول‌کشیده) یعنی شروع فوری "
        "آنتی‌بیوتیک وسیع و پیشبرد زایمان. راه زایمان را اندیکاسیون مامایی تعیین می‌کند؛ "
        "سزارین تنها به‌خاطر کوریو لازم نیست و عقب انداختن آنتی‌بیوتیک تا بعد از عمل غلط است."
    ),
    explanation_en=(
        "Correction of the printed key that marked emergency caesarean and antibiotics only "
        "after birth. Chorioamnionitis (fever plus tachycardia plus leucocytosis after prolonged "
        "rupture) means start broad antibiotics at once and deliver. The route is obstetric; "
        "chorio alone is not a caesarean indication, and delaying antibiotics until after surgery is wrong."
    ),
    micro={
        "lead_fa": "کوریو: آنتی‌بیوتیک همین حالا + زایمان. سزارین اجباری نیست.",
        "lead_en": "Chorio: antibiotics now plus delivery. Caesarean is not mandatory.",
        "points_fa": [
            "تعریف: تب مادر + یکی از تاکی‌کاردی مادر/جنین، لکوسیتوز، ترشح بدبو، حساسیت رحم.",
            "عامل: صعود پلی‌میکروبی بعد از PROM.",
            "درمان: آمپی‌سیلین + جنتامایسین؛ در سزارین کلیندامایسین یا مترونیدازول اضافه کن.",
            "زایمان را تسریع کن؛ القای واژینال اگر مامایی اجازه دهد.",
            "سزارین اگر دیسترس جنین، عدم پیشرفت یا اندیکاسیون قبلی.",
            "تأخیر آنتی‌بیوتیک سپسیس مادر و نوزاد را زیاد می‌کند.",
            "نوزاد را از نظر سپسیس زودرس پایش کن.",
            "استروئید اگر نارس و هنوز زایمان فوری نیست طبق پروتکل.",
            "ترشح چرکی لازم نیست برای تشخیص.",
            "منبع Williams و ACOG صریحاً می‌گویند IAI به‌تنهایی CS نمی‌خواهد.",
        ],
        "points_en": [
            "Definition: maternal fever plus one of maternal/fetal tachycardia, leucocytosis, foul discharge, uterine tenderness.",
            "Cause: polymicrobial ascent after PROM.",
            "Treat with ampicillin plus gentamicin; add clindamycin or metronidazole at caesarean.",
            "Expedite birth; induce vaginally if obstetrics allows.",
            "Caesarean if fetal distress, failure to progress or a prior indication.",
            "Delaying antibiotics raises maternal and neonatal sepsis.",
            "Watch the newborn for early-onset sepsis.",
            "Steroid if preterm and birth is not immediate, per protocol.",
            "Pus is not required for the diagnosis.",
            "Williams and ACOG say IAI alone does not mandate CS.",
        ],
    },
    golden_fa="کوریوآمنیونیت: آنتی‌بیوتیک فوری و زایمان. سزارین اجباری نیست.",
    golden_en="Chorioamnionitis: immediate antibiotics and delivery. Caesarean is not mandatory.",
    refs=["Williams / ACOG — Intraamniotic infection"],
    concept="chorio-induce", concept_fa="کوریوآمنیونیت و راه زایمان", concept_en="Chorioamnionitis and route",
    correct_index=0,
    original_correct_index=2,
    key_corrected=True,
    key_correction_fa="کلید چاپی سزارین فوری و آنتی‌بیوتیک بعد از زایمان را زده؛ کوریو اندیکاسیون سزارین نیست و آنتی‌بیوتیک باید فوری شروع شود.",
    key_correction_en="The printed key marks emergency caesarean and antibiotics after birth; chorio is not a CS indication and antibiotics must start at once.",
    key_correction_source="Williams / ACOG IAI")


def apply():
    files = sorted(glob.glob(os.path.join(HERE, "import-payload.archive.part*.json")))
    n = 0
    for path in files:
        body = json.load(open(path, encoding="utf-8"))
        changed = False
        for q in body["questions"]:
            if int(q.get("year_num") or 0) != 1402:
                continue
            rec = L.get((q["subject_fa"], q["question_no"])) or L.get((q["subject_fa"], int(q.get("question_no") or 0)))
            if not rec:
                continue
            for k in ("chapter_fa", "chapter_en", "options_why_fa", "options_why_en",
                      "explanation_fa", "explanation_en", "micro", "golden_fa", "golden_en",
                      "refs", "concept", "concept_fa", "concept_en"):
                q[k] = rec[k]
            q["needs_lesson"] = False
            q["lesson_part"] = 1
            if rec.get("key_corrected"):
                q["original_correct_index"] = rec["original_correct_index"]
                q["correct_index"] = rec["correct_index"]
                q["key_corrected"] = True
                q["key_correction_fa"] = rec["key_correction_fa"]
                q["key_correction_en"] = rec["key_correction_en"]
                q["key_correction_source"] = rec["key_correction_source"]
            n += 1
            changed = True
        if changed:
            json.dump(body, open(path, "w", encoding="utf-8"), ensure_ascii=False)
    print(f"applied lessons to {n} Khordad-1402 questions")
    print("keys:", ", ".join(f"{s} q{no}" for s, no in sorted(L)))


if __name__ == "__main__":
    apply()
