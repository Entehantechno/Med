#!/usr/bin/env python3
"""Convert the cleaned neurology bank into the payload shape expected by
POST /api/admin/official-question-import/{preview,commit}.

Only questions that already have an authored lesson are exported, so the import
can be run incrementally as more lessons are written.

By default only cluster REPRESENTATIVES are exported: the competitive path
should teach maximum breadth, so near-duplicate reprints of the same question
stay off the path. Use --include-variants to export everything, or
--variants-to-premium to keep them available behind premium.
"""
import json, argparse, os, glob

BASE = os.path.dirname(os.path.abspath(__file__))


def build(only_done=True, max_per_lesson=15, overflow=False,
          include_variants=False, variants_to_premium=False):
    bank = json.load(open(os.path.join(BASE, 'bank.json'), encoding='utf-8'))

    rows = []
    for r in bank:
        if only_done and not r.get('explanation_fa'):
            continue
        is_rep = r.get('is_representative', True)
        if not is_rep and not (include_variants or variants_to_premium):
            continue
        rows.append(r)

    # Respect the evidence-based ordering produced by sequence.py. Questions
    # without a seq (not yet sequenced) keep their original order at the end.
    rows.sort(key=lambda r: (r.get('seq') if r.get('seq') is not None else 10**6,
                             r['question_no']))

    questions = []
    for r in rows:
        why_fa = (r.get('why_fa') or ['', '', '', ''])[:4]
        why_en = (r.get('why_en') or ['', '', '', ''])[:4]
        while len(why_fa) < 4:
            why_fa.append('')
        while len(why_en) < 4:
            why_en.append('')

        # The "پاسخنامه" block: the reasoning for this specific question.
        expl_fa = r.get('explanation_fa')
        expl_en = r.get('explanation_en', '')

        # The "درسنامه" block: a standalone micro-lesson that teaches the topic
        # from scratch, so a learner who has never met it can still learn it.
        micro = None
        m = r.get('micro') or {}
        if m.get('lead_fa') or m.get('points_fa'):
            micro = {
                'lead_fa': m.get('lead_fa', ''), 'lead_en': m.get('lead_en', ''),
                'golden_fa': r.get('golden_fa', ''), 'golden_en': r.get('golden_en', ''),
                'points_fa': m.get('points_fa', []), 'points_en': m.get('points_en', []),
                'options_fa': why_fa, 'options_en': why_en,
                'source_fa': '؛ '.join(r.get('refs', [])),
                'source_en': '; '.join(r.get('refs', [])),
            }

        is_rep = r.get('is_representative', True)
        q = {
            'question_no': r['question_no'],
            'subject_fa': r['subject_fa'], 'subject_en': r['subject_en'],
            # neurology is a MINOR subject of the pre-internship exam; the majors
            # are internal medicine, surgery, paediatrics and obstetrics
            'subject_track': r.get('subject_track', 'minor'),
            'chapter_fa': r['chapter_fa'], 'chapter_en': r['chapter_en'],
            'question_fa': r['stem_fa'],
            'question_en': r.get('stem_en', ''),
            'options_fa': r['options_fa'],
            'options_en': r.get('options_en', []),
            'options_why_fa': why_fa,
            'options_why_en': why_en,
            'correct_index': r['correct_index'],
            'explanation_fa': expl_fa,
            'explanation_en': expl_en,
            'difficulty': r.get('difficulty', 'medium'),
            'type': 'mcq', 'answerMode': 'choice',
            'exam_type': r['exam_type'],
            # --- exam provenance, kept queryable ------------------------------
            'year': r.get('exam_year', ''),
            'year_num': r.get('exam_year_num'),
            'month': r.get('exam_month', ''),
            'month_en': r.get('exam_month_en', ''),
            'sitting': r.get('exam_sitting', ''),
            'pole': r.get('exam_pole', ''),
            'poles': r.get('exam_poles', []),
            'scope': r.get('exam_scope', ''),
            'scope_en': r.get('exam_scope_en', ''),
            'label_fa': r.get('exam_label_fa', ''),
            'label_en': r.get('exam_label_en', ''),
            'question_style': r.get('question_style', ''),
            'concept': r.get('concept', ''),
            'concept_fa': r.get('concept_fa', ''),
            'concept_en': r.get('concept_en', ''),
            'seq': r.get('seq'),
            # Which lesson part sequence.py placed this question in. Sending it
            # lets the server reuse the balanced, concept-mixed grouping instead
            # of re-chunking greedily (which would leave stragglers like a
            # 1-question lesson at the end of a chapter).
            'lesson_part': r.get('lesson_part'),
            'repeat_count': r.get('repeat_count', 1),
            'repeat_sources': r.get('repeat_sources', []),
            'cluster_id': r.get('cluster_id', ''),
            'is_representative': is_rep,
            'tags': r.get('tags', []),
            'source': r['source'],
            'license': 'public_past_exam_review_required',
        }
        if micro:
            q['micro'] = micro
        # variants never take a free path slot
        if not is_rep and variants_to_premium:
            q['premium'] = True
        questions.append(q)

    return {
        'program': 'preint',
        'subject_fa': 'نورولوژی', 'subject_en': 'Neurology', 'subject_track': 'minor',
        'maxPerLesson': max_per_lesson,
        'overflowToPremium': overflow,
        'exam_type': 'پره‌انترنی',
        'source': 'مجموعه سؤالات پره‌انترنی نورولوژی (آزمون‌های سراسری ۹۳ تا ۹۸)',
        'license': 'public_past_exam_review_required',
        'questions': questions,
    }


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--all', action='store_true',
                    help='include questions that do not have a lesson yet')
    ap.add_argument('--max-per-lesson', type=int, default=15)
    ap.add_argument('--overflow-to-premium', action='store_true',
                    help='send questions beyond maxPerLesson to premium instead of '
                         'splitting them into additional free lesson parts')
    ap.add_argument('--include-variants', action='store_true',
                    help='also export near-duplicate reprints onto the free path')
    ap.add_argument('--variants-to-premium', action='store_true',
                    help='export near-duplicate reprints but mark them premium')
    ap.add_argument('-o', '--out', default=os.path.join(BASE, 'import-payload.json'))
    # The server accepts a 2 MB JSON body. A fully authored bank is ~7 MB, so a
    # single payload would be rejected once the bank passes ~170 questions.
    # Splitting keeps every request comfortably inside that limit without
    # loosening the server-wide body cap, which protects memory and throughput.
    ap.add_argument('--chunk-size', type=int, default=100,
                    help='questions per import file (0 = single file)')
    a = ap.parse_args()
    payload = build(only_done=not a.all, max_per_lesson=a.max_per_lesson,
                    overflow=a.overflow_to_premium,
                    include_variants=a.include_variants,
                    variants_to_premium=a.variants_to_premium)
    qs = payload['questions']
    stem = a.out[:-5] if a.out.endswith('.json') else a.out
    chunked = bool(a.chunk_size) and len(qs) > a.chunk_size

    # Write the chunked companions used by import-bank.mjs.
    #
    # When the bank is chunked we deliberately do NOT keep the single-file
    # payload as well. `import-bank.mjs` prefers the .partNN.json files and
    # ignores the single file, so keeping both would ship an exact duplicate of
    # the whole bank (4+ MB) inside every release ZIP for no benefit.
    chunk_paths = []
    if chunked:
        for stale in glob.glob(f'{stem}.part*.json'):
            os.remove(stale)
        for idx in range(0, len(qs), a.chunk_size):
            part = dict(payload)
            part['questions'] = qs[idx:idx + a.chunk_size]
            cp = f'{stem}.part{idx // a.chunk_size + 1:02d}.json'
            json.dump(part, open(cp, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
            chunk_paths.append(cp)
        if os.path.exists(a.out):
            os.remove(a.out)
    else:
        for stale in glob.glob(f'{stem}.part*.json'):
            os.remove(stale)
        json.dump(payload, open(a.out, 'w', encoding='utf-8'),
                  ensure_ascii=False, indent=1)
    n = len(qs)
    prem = sum(1 for q in qs if q.get('premium'))
    micro = sum(1 for q in qs if q.get('micro'))
    en = sum(1 for q in qs if q.get('question_en'))
    meta = sum(1 for q in qs if q.get('year') and q.get('month') and q.get('pole'))
    from collections import Counter
    written = ', '.join(os.path.basename(c) for c in chunk_paths) if chunked \
        else os.path.basename(a.out)
    print(f"wrote {written}")
    print(f"  questions: {n} (premium variants: {prem})")
    print(f"  with micro-lesson: {micro} | with English: {en} | full exam metadata: {meta}")
    print(f"  by year: {dict(sorted(Counter(q.get('year','?') for q in qs).items()))}")
    print(f"  by style: {dict(Counter(q.get('question_style','?') for q in qs))}")
    print(f"  by difficulty: {dict(Counter(q.get('difficulty','?') for q in qs))}")
    size_mb = (sum(os.path.getsize(c) for c in chunk_paths) if chunked
               else os.path.getsize(a.out)) / 1024 / 1024
    print(f"  payload size: {size_mb:.2f} MB (server body limit: 2 MB)")
    if chunk_paths:
        biggest = max(os.path.getsize(c) for c in chunk_paths) / 1024 / 1024
        print(f"  split into {len(chunk_paths)} chunk(s), largest {biggest:.2f} MB")
        print("  single-file payload not kept: the chunks already hold the whole bank")
    elif size_mb > 1.8:
        print("  \u26a0\ufe0f  payload is close to the 2 MB server limit \u2014 use --chunk-size")
