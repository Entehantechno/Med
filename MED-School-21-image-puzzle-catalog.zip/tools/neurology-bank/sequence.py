#!/usr/bin/env python3
"""Order the questions of each chapter into an evidence-based learning sequence.

Implements the algorithm described in PEDAGOGY.md:

  1. cluster questions by concept
  2. prioritise high-yield repeats (asked in 2+ exam sittings)
  3. distribute concepts across lessons so every lesson mixes several topics
  4. inside each lesson:
       - grade difficulty from easy to hard (schema building first)
       - never place two same-concept questions back to back (local interleaving)
       - never place two same-style questions back to back
       - finish on an easy question (peak-end rule)
  5. verify that no concept is left out

Writes `seq` (0-based position) onto every question; `to_import.py` sorts by it.
"""
import json, os, sys
from collections import defaultdict, Counter

BASE = os.path.dirname(os.path.abspath(__file__))
DIFF_RANK = {"easy": 0, "medium": 1, "hard": 2}


def interleave_by_concept(items):
    """Greedy reordering that avoids adjacent same-concept and same-style items."""
    remaining = list(items)
    out = []
    while remaining:
        prev_c = out[-1]["concept"] if out else None
        prev_s = out[-1].get("question_style") if out else None
        # prefer a candidate that clashes with neither the concept nor the style
        pick = next((x for x in remaining
                     if x["concept"] != prev_c and x.get("question_style") != prev_s), None)
        if pick is None:  # relax the style rule
            pick = next((x for x in remaining if x["concept"] != prev_c), None)
        if pick is None:  # nothing left but a same-concept item
            pick = remaining[0]
        remaining.remove(pick)
        out.append(pick)
    return out


def order_lesson(items):
    """Easy → hard, locally interleaved, ending on an easy question."""
    if len(items) <= 2:
        return items
    items = sorted(items, key=lambda r: (DIFF_RANK.get(r.get("difficulty", "medium"), 1),
                                         -r.get("repeat_count", 1)))
    # hold back one easy item for the finish (peak-end rule)
    finisher = items[0] if DIFF_RANK.get(items[0].get("difficulty", "medium"), 1) == 0 else None
    body = [x for x in items if x is not finisher]
    body = interleave_by_concept(body)
    if finisher is None:
        # no easy item available: move the least difficult remaining item to the end
        easiest = min(body, key=lambda r: DIFF_RANK.get(r.get("difficulty", "medium"), 1))
        if easiest is not body[-1] and len(body) > 3:
            body.remove(easiest)
            body.append(easiest)
        return body
    return body + [finisher]


def spread_concepts(items, per_lesson):
    """Deal questions into lessons round-robin by concept so each lesson mixes topics."""
    buckets = defaultdict(list)
    for r in items:
        buckets[r["concept"]].append(r)
    # inside a concept, high-yield repeats first
    for c in buckets:
        buckets[c].sort(key=lambda r: (-r.get("repeat_count", 1),
                                       DIFF_RANK.get(r.get("difficulty", "medium"), 1)))
    # order concepts by size so the biggest are spread widest
    order = sorted(buckets, key=lambda c: -len(buckets[c]))
    n_lessons = max(1, (len(items) + per_lesson - 1) // per_lesson)
    lessons = [[] for _ in range(n_lessons)]
    i = 0
    while any(buckets[c] for c in order):
        for c in order:
            if not buckets[c]:
                continue
            # find the emptiest lesson that does not yet hold this concept
            cand = sorted(range(n_lessons), key=lambda k: (len(lessons[k]),
                                                           sum(1 for x in lessons[k] if x["concept"] == c)))
            placed = False
            for k in cand:
                if len(lessons[k]) < per_lesson:
                    lessons[k].append(buckets[c].pop(0))
                    placed = True
                    break
            if not placed:
                lessons[cand[0]].append(buckets[c].pop(0))
            i += 1
    return lessons


def main(per_lesson=15, only_authored=True):
    path = os.path.join(BASE, "bank.json")
    bank = json.load(open(path, encoding="utf-8"))

    pool = [r for r in bank
            if r.get("is_representative", True) and (r.get("explanation_fa") or not only_authored)]

    by_chapter = defaultdict(list)
    for r in pool:
        by_chapter[r["chapter_num"]].append(r)

    seq = 0
    report = []
    for ch in sorted(by_chapter, key=lambda c: min(x["question_no"] for x in by_chapter[c])):
        items = by_chapter[ch]
        lessons = spread_concepts(items, per_lesson)
        for li, lesson in enumerate(lessons, 1):
            ordered = order_lesson(lesson)
            for r in ordered:
                r["seq"] = seq
                r["lesson_part"] = li
                seq += 1
            report.append((items[0]["chapter_fa"], li, ordered))

    json.dump(bank, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)

    # ---- quality report ---------------------------------------------------
    print(f"sequenced {len(pool)} questions into {len(report)} lesson(s)\n")
    adj_concept = adj_style = 0
    ends_easy = 0
    for chapter, li, lesson in report:
        concepts = [x["concept"] for x in lesson]
        styles = [x.get("question_style") for x in lesson]
        ac = sum(1 for a, b in zip(concepts, concepts[1:]) if a == b)
        as_ = sum(1 for a, b in zip(styles, styles[1:]) if a == b)
        adj_concept += ac
        adj_style += as_
        last_easy = DIFF_RANK.get(lesson[-1].get("difficulty", "medium"), 1) <= 1
        ends_easy += 1 if last_easy else 0
        print(f"— {chapter} / بخش {li}: {len(lesson)} سؤال | "
              f"{len(set(concepts))} مفهوم | تکرار مفهوم مجاور: {ac} | پایان آسان: {'✓' if last_easy else '✗'}")
    total_pairs = sum(len(l) - 1 for _, _, l in report)
    print(f"\nadjacent same-concept pairs: {adj_concept}/{total_pairs}")
    print(f"adjacent same-style pairs:   {adj_style}/{total_pairs}")
    print(f"lessons ending on an easy/medium question: {ends_easy}/{len(report)}")

    # ---- coverage check ---------------------------------------------------
    all_concepts = {r["concept"] for r in pool}
    covered = {r["concept"] for r in pool if "seq" in r}
    missing = all_concepts - covered
    if missing:
        print(f"\n❌ concepts missing from the path: {sorted(missing)}")
        return 1
    print(f"\n✅ coverage: all {len(all_concepts)} concept(s) present in the path")
    return 0


if __name__ == "__main__":
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 15
    sys.exit(main(per_lesson=n))
