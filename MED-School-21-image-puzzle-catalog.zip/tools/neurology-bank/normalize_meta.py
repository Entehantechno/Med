#!/usr/bin/env python3
"""Normalise and enrich the exam metadata on every question.

Goal: make the bank fully filterable — by year, month, sitting, pole, chapter,
question style and difficulty — so the learning path and the admin panel can
slice it any way they need.

Produces / repairs these fields on each record:

  exam_year        two-digit Persian year as a string, e.g. '۹۵'
  exam_year_num    the same as an int, e.g. 95            (sortable)
  exam_month       Persian month name, e.g. 'اسفند'
  exam_sitting     'main' (اسفند/شهریور) or 'midterm' (آذر/اردیبهشت/…)
  exam_pole        cleaned pole name, e.g. 'مشهد'
  exam_poles       list, for the rows that name several poles at once
  exam_scope       'ملی' when the sitting was nationwide, else 'قطبی'
  exam_label_fa    a human-readable label, e.g. 'پره‌انترنی اسفند ۹۵ — قطب مشهد'
  exam_label_en    the English equivalent
  question_style   'case' | 'recall' | 'negative' | 'image'
  difficulty       'easy' | 'medium' | 'hard'  (heuristic, admin-overridable)
  tags             a flat list of filter tags used by the UI
"""
import json, os, re, sys
from collections import Counter

BASE = os.path.dirname(os.path.abspath(__file__))
FA_DIGITS = '۰۱۲۳۴۵۶۷۸۹'

MONTHS = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
          'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند']
MONTH_EN = {'فروردین': 'Farvardin', 'اردیبهشت': 'Ordibehesht', 'خرداد': 'Khordad',
            'تیر': 'Tir', 'مرداد': 'Mordad', 'شهریور': 'Shahrivar', 'مهر': 'Mehr',
            'آبان': 'Aban', 'آذر': 'Azar', 'دی': 'Dey', 'بهمن': 'Bahman',
            'اسفند': 'Esfand'}
# the two main national sittings; everything else is an interim/midterm exam
MAIN_MONTHS = {'اسفند', 'شهریور'}

# pole spellings seen in the source, mapped to a canonical name
POLE_FIX = {
    'هواز': 'اهواز', 'شبراز': 'شیراز', 'مشترک': 'کشوری',
    'میاندوره': 'کشوری', 'میان دوره': 'کشوری',
}
POLE_EN = {
    'کشوری': 'National', 'آزاد': 'Azad', 'مشهد': 'Mashhad', 'اهواز': 'Ahvaz',
    'کرمان': 'Kerman', 'شمال': 'North', 'کرمانشاه': 'Kermanshah',
    'تبریز': 'Tabriz', 'شیراز': 'Shiraz', 'اصفهان': 'Isfahan',
    'تهران': 'Tehran', 'زنجان': 'Zanjan', 'همدان': 'Hamedan',
}


def fa_to_int(s):
    try:
        return int(''.join(str(FA_DIGITS.index(c)) for c in s))
    except ValueError:
        return None


def parse_source(src):
    """Pull year, month and pole(s) out of the free-text source line."""
    out = {'year': '', 'month': '', 'poles': []}
    if not src:
        return out

    m = re.search(r'(' + '|'.join(MONTHS) + r')\s*([۰-۹]{4}|[۰-۹]{2})', src)
    if m:
        out['month'] = m.group(1)
        out['year'] = m.group(2)
    else:
        y = re.search(r'([۰-۹]{4}|[۰-۹]{2})', src)
        if y:
            out['year'] = y.group(1)

    # everything after the dash is the pole description
    tail = src.split('-', 1)[1] if '-' in src else ''
    # 'هشت قطب مشترک' means a sitting shared by all eight poles → national
    if re.search(r'هشت\s*قطب|چند\s*قطب|همه\s*ی?\s*قطب', tail):
        return {'year': out['year'], 'month': out['month'], 'poles': ['کشوری']}
    tail = re.sub(r'قطب|مشترک|میان\s*دوره‌?ی?|کشوری\s*$', ' ', tail)
    tail = tail.replace('ی کشوری', ' ')
    parts = re.split(r'\s*(?:و|،)\s*', tail)
    poles = []
    for p in parts:
        p = p.strip(' .ـی')
        if not p or len(p) < 3:
            continue
        p = POLE_FIX.get(p, p)
        if p not in poles:
            poles.append(p)
    if not poles and re.search(r'کشوری|مشترک|میان\s*دوره', src):
        poles = ['کشوری']
    out['poles'] = poles
    return out


def classify_style(r):
    stem = r['stem_fa']
    if re.search(r'به\s*جز|بجز|بغیر|غلط|نادرست|صحیح\s*نیست|نمی\s*باشد', stem):
        return 'negative'
    if re.search(r'شکل|تصویر|نمودار|پریمتری|گراف', stem):
        return 'image'
    # a clinical vignette names a patient and an age
    if re.search(r'(آقای|خانم|مرد|زن|بیمار|پسر|دختر|جوان)\s*[۰-۹]', stem) or 'ساله' in stem:
        return 'case'
    return 'recall'


def estimate_difficulty(r):
    """Cheap, transparent heuristic. Admins can override it in the panel."""
    score = 0
    stem = r['stem_fa']
    if len(stem) > 260:
        score += 1                      # long vignette
    if classify_style(r) == 'negative':
        score += 1                      # inverted logic
    if r.get('repeat_count', 1) >= 2:
        score -= 1                      # asked repeatedly → core material
    # options that are long and wordy are usually harder to discriminate
    if sum(len(o) for o in r['options_fa']) / 4 > 40:
        score += 1
    if score <= -1:
        return 'easy'
    if score >= 2:
        return 'hard'
    return 'medium'


def main():
    path = os.path.join(BASE, 'bank.json')
    bank = json.load(open(path, encoding='utf-8'))

    for r in bank:
        p = parse_source(r.get('source', ''))
        year = p['year'] or r.get('year') or r.get('exam_year') or ''
        yn = fa_to_int(year) if year else None
        # guard against the reversed-digit bug ever coming back
        if yn is not None and len(year) == 2 and not 85 <= yn <= 99:
            rev = fa_to_int(year[::-1])
            if rev is not None and 85 <= rev <= 99:
                year, yn = year[::-1], rev

        month = p['month'] or r.get('exam_month') or ''
        poles = p['poles'] or ([r['exam_pole']] if r.get('exam_pole') else [])
        poles = [POLE_FIX.get(x, x) for x in poles]

        sitting = 'main' if month in MAIN_MONTHS else ('midterm' if month else '')
        national = (not poles) or poles == ['کشوری']

        r['exam_year'] = year
        r['exam_year_num'] = yn
        r['exam_month'] = month
        r['exam_month_en'] = MONTH_EN.get(month, '')
        r['exam_sitting'] = sitting
        r['exam_pole'] = poles[0] if poles else ''
        r['exam_poles'] = poles
        r['exam_scope'] = 'ملی' if national else 'قطبی'
        r['exam_scope_en'] = 'National' if national else 'Regional'

        pole_fa = '، '.join(poles) if poles else ''
        label = f"پره‌انترنی {month} {year}".strip()
        if pole_fa and pole_fa != 'کشوری':
            label += f' — قطب {pole_fa}'
        elif pole_fa:
            label += ' — کشوری'
        r['exam_label_fa'] = label
        pole_en = ', '.join(POLE_EN.get(x, x) for x in poles) if poles else ''
        # English label uses Gregorian-style Latin digits for the Persian year
        year_latin = ('' if yn is None else (str(yn) if yn > 1000 else f'13{yn}'))
        r['exam_label_en'] = (
            ' '.join(x for x in ['Pre-internship', MONTH_EN.get(month, ''), year_latin] if x)
            + (f' — {pole_en}' if pole_en else '')
        )

        r['question_style'] = classify_style(r)
        r['difficulty'] = estimate_difficulty(r)

        tags = [
            f"subject:{r['subject_en'].lower()}",
            f"chapter:{r['chapter_num']}",
            f"year:{year}" if year else None,
            f"month:{MONTH_EN.get(month, '')}" if month else None,
            f"sitting:{sitting}" if sitting else None,
            f"scope:{r['exam_scope_en'].lower()}",
            f"style:{r['question_style']}",
            f"difficulty:{r['difficulty']}",
        ]
        if r.get('repeat_count', 1) >= 2:
            tags.append('high-yield')
        if not r.get('is_representative', True):
            tags.append('variant')
        r['tags'] = [t for t in tags if t]

    json.dump(bank, open(path, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

    print(f'normalised {len(bank)} questions\n')
    def show(label, key):
        c = Counter(str(r.get(key, '')) for r in bank)
        missing = c.pop('', 0) + c.pop('None', 0)
        top = ', '.join(f'{k}={v}' for k, v in sorted(c.items(), key=lambda x: -x[1])[:8])
        print(f'{label:16s} missing={missing:3d} | {top}')
    show('year', 'exam_year')
    show('month', 'exam_month')
    show('sitting', 'exam_sitting')
    show('scope', 'exam_scope')
    show('pole', 'exam_pole')
    show('style', 'question_style')
    show('difficulty', 'difficulty')
    return 0


if __name__ == '__main__':
    sys.exit(main())
