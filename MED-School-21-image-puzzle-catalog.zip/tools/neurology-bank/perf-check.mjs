/**
 * Performance guard for the growing question bank.
 *
 * The bank is heading for 605 richly-authored cards (~9.6 KB each, so ~5.5 MB
 * of card JSON). Every round adds more, so we need a way to prove the learner
 * API does not get slower as it grows — the site must stay fast.
 *
 * What it does:
 *   1. Times the learner endpoints that matter most (path, lesson, review).
 *   2. Optionally inflates the bank to full size with synthetic cards
 *      (--scale 605) so we measure the FUTURE state, not just today's.
 *   3. Fails if any endpoint exceeds its budget.
 *
 * Usage:
 *   node tools/neurology-bank/perf-check.mjs [baseURL] [--scale N]
 *
 * Budgets are deliberately generous for a sql.js (in-memory SQLite) backend on
 * modest hardware; they are there to catch a REGRESSION, not to micro-tune.
 */
const BASE = process.argv.find((a) => a.startsWith('http')) || 'http://localhost:4320';
const scaleArg = process.argv.indexOf('--scale');
const SCALE = scaleArg > -1 ? Number(process.argv[scaleArg + 1]) : 0;

// endpoint -> max acceptable p95 in milliseconds
const BUDGET = {
  'GET /api/learn/path': 400,
  'GET /api/learn/home': 400,
  'GET /api/learn/review': 500,
  'GET /api/learn/lesson': 600,
};

async function login(username, password) {
  const r = await fetch(`${BASE}/api/auth/login`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ username, password }),
  });
  const j = await r.json();
  if (!j.token) throw new Error(`login failed for ${username}: ${JSON.stringify(j)}`);
  return j.token;
}

const auth = (t) => ({ authorization: `Bearer ${t}` });

async function timeIt(label, fn, runs = 12) {
  const ms = [];
  for (let i = 0; i < runs; i += 1) {
    const t0 = performance.now();
    await fn();
    ms.push(performance.now() - t0);
  }
  ms.sort((a, b) => a - b);
  const p50 = ms[Math.floor(ms.length * 0.5)];
  const p95 = ms[Math.floor(ms.length * 0.95)] ?? ms[ms.length - 1];
  return { label, p50, p95, max: ms[ms.length - 1] };
}

/** Push synthetic cards so we can measure the bank at its final size. */
async function inflate(adminTok, target) {
  const existing = await (await fetch(`${BASE}/api/admin/learn-cards?limit=5000`, { headers: auth(adminTok) })).json();
  const have = (existing.cards || []).length;
  const need = target - have;
  if (need <= 0) return have;

  // Build cards the same shape and size as real authored ones, so the
  // measurement reflects real payload weight rather than empty stubs.
  const filler = (n, len) => Array.from({ length: n }, (_, i) => `نکته آموزشی شماره ${i} ${'مطلب '.repeat(len)}`);
  // The server's dedupe fingerprint normalises every digit to '#', so numbering
  // the stems would make them all look identical and only one would import.
  // Spell the index out in words instead, so each stem is genuinely distinct.
  const W = ['الف', 'ب', 'پ', 'ت', 'ث', 'ج', 'چ', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز', 'ژ', 'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ک', 'گ', 'ل', 'م', 'ن', 'و', 'ه', 'ی'];
  const word = (i) => {
    let out = '', x = i;
    do { out = `${W[x % W.length]}${out ? ' ' : ''}${out}`; x = Math.floor(x / W.length); } while (x > 0);
    return out;
  };
  const questions = Array.from({ length: need }, (_, i) => ({
    question_no: 10000 + i,
    subject_fa: 'نورولوژی', subject_en: 'Neurology',
    chapter_fa: `فصل بار سنجی ${word(Math.floor(i / 15))}`,
    chapter_en: `Load test chapter ${word(Math.floor(i / 15))}`,
    question_fa: `سؤال بار سنجی ${word(i)} برای اندازه گیری کارایی سامانه در مقیاس کامل`,
    question_en: `Load test question ${word(i)} used to measure API performance at full scale`,
    options_fa: ['گزینه الف', 'گزینه ب', 'گزینه ج', 'گزینه د'],
    options_en: ['Option A', 'Option B', 'Option C', 'Option D'],
    options_why_fa: filler(4, 12), options_why_en: filler(4, 12),
    correct_index: i % 4,
    explanation_fa: `پاسخنامه ${'توضیح مفصل '.repeat(60)}`,
    explanation_en: `Answer key ${'detailed explanation '.repeat(60)}`,
    micro: {
      lead_fa: 'جمله کلیدی '.repeat(8), lead_en: 'Lead sentence '.repeat(8),
      golden_fa: 'نکته طلایی '.repeat(8), golden_en: 'Golden point '.repeat(8),
      points_fa: filler(9, 10), points_en: filler(9, 10),
      source_fa: 'Aminoff 2021', source_en: 'Aminoff 2021',
    },
    difficulty: 'medium', question_style: 'case', seq: i,
    lesson_part: (i % 15) + 1,
  }));

  // Post in chunks: the server body limit is 2 MB and these cards are large,
  // so a single request would be silently rejected and we would measure the
  // wrong scale.
  const CHUNK = 60;
  let added = 0;
  for (let i = 0; i < questions.length; i += CHUNK) {
    const res = await fetch(`${BASE}/api/admin/official-question-import/commit`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', ...auth(adminTok) },
      body: JSON.stringify({
        program: 'preint', subject_fa: 'نورولوژی', subject_en: 'Neurology',
        maxPerLesson: 15, questions: questions.slice(i, i + CHUNK),
      }),
    });
    if (!res.ok) throw new Error(`inflate chunk failed: HTTP ${res.status} ${(await res.text()).slice(0, 160)}`);
    const j = await res.json();
    added += j.inserted || 0;
  }
  return have + added;
}

const run = async () => {
  const learner = await login('learner', 'demo');

  let total = null;
  if (SCALE) {
    const admin = await login('admin', 'demo');
    process.stdout.write(`inflating bank to ${SCALE} cards… `);
    total = await inflate(admin, SCALE);
    console.log(`now ${total} cards`);
  }

  // find a real lesson node to open
  const path = await (await fetch(`${BASE}/api/learn/path`, { headers: auth(learner) })).json();
  let nodeId = null;
  for (const t of path.topics || []) {
    const n = (t.nodes || []).find((x) => !x.locked);
    if (n) { nodeId = n.id; break; }
  }

  const results = [];
  results.push(await timeIt('GET /api/learn/path', () => fetch(`${BASE}/api/learn/path`, { headers: auth(learner) }).then((r) => r.text())));
  results.push(await timeIt('GET /api/learn/home', () => fetch(`${BASE}/api/learn/home`, { headers: auth(learner) }).then((r) => r.text())));
  results.push(await timeIt('GET /api/learn/review', () => fetch(`${BASE}/api/learn/review`, { headers: auth(learner) }).then((r) => r.text())));
  if (nodeId) {
    results.push(await timeIt('GET /api/learn/lesson', () => fetch(`${BASE}/api/learn/lesson/${nodeId}`, { headers: auth(learner) }).then((r) => r.text())));
  }

  console.log(`\nendpoint timings${total ? ` at ${total} cards` : ''}:`);
  const failures = [];
  for (const r of results) {
    const budget = BUDGET[r.label];
    const ok = !budget || r.p95 <= budget;
    if (!ok) failures.push(`${r.label}: p95 ${r.p95.toFixed(0)}ms exceeds budget ${budget}ms`);
    console.log(`  ${ok ? '✓' : '✗'} ${r.label.padEnd(26)} p50 ${r.p50.toFixed(0).padStart(5)}ms   p95 ${r.p95.toFixed(0).padStart(5)}ms   (budget ${budget ?? '—'}ms)`);
  }

  if (failures.length) {
    console.log('\n❌ performance budget exceeded:');
    failures.forEach((f) => console.log('  -', f));
    process.exit(1);
  }
  console.log('\n✅ all endpoints inside their performance budget');
};

run().catch((e) => { console.error(e); process.exit(1); });
