#!/usr/bin/env python3
"""Cluster near-duplicate questions and pick one representative per cluster.

Why this exists
---------------
The source PDF reprints the same question across exam years and poles. Some
reprints are byte-identical, others are reworded, and a few even shuffle the
options (so the answer LETTER differs while the answer TEXT is the same).

The competitive learning path should teach the maximum breadth of topics, so we
keep one representative per cluster on the free path and mark the rest as
`variant`. A variant is not deleted: high-yield repeats carry real signal about
what the exam loves, so each representative records how many times the concept
was asked and in which exams.

Outputs (written back into bank.json):
  cluster_id        stable id shared by all members of a cluster
  is_representative True for the single question kept on the path
  variant_of        uid of the representative (only on non-representatives)
  repeat_count      how many times this concept appeared across exams
  repeat_sources    the exam sittings it appeared in
  answer_conflict   True when cluster members disagree on the answer TEXT
"""
import json, re, os, sys
from collections import defaultdict

BASE = os.path.dirname(os.path.abspath(__file__))
THRESHOLD = 0.62

STOP = set(
    'در از به با که را این برای است شده می‌شود کدام زیر مورد بیمار سال ساله آقای خانم '
    'مراجعه کرده معاینه شما وی او یک های ای بوده دارد و یا اما ولی نیز هم بر طور صورت '
    'علت دلیل چه کجا چیست کدامیک زیر گزینه موارد کدام‌یک'.split()
)

def toks(s):
    s = re.sub(r'[^\w\u0600-\u06FF ]', ' ', s)
    return {w for w in s.split() if len(w) > 2 and w not in STOP}

def jaccard(a, b):
    return len(a & b) / len(a | b) if a and b else 0.0

# words that only pad the wording and must not create a false "conflict"
_FILLER = ('بیماری', 'شروع', 'نخاع', 'در', 'سمت', 'نیمهی', 'نیمه', 'حملهی', 'حمله',
           'اتفاق', 'میافتد', 'های', 'ی')

def norm_ans(r):
    """The answer TEXT, normalised — comparable even when options are shuffled
    or reworded. Strips punctuation, filler words and the Persian ezafe so that
    'نیمهی جانبی چپ' and 'نیمهی جانبی نخاع در سمت چپ' compare equal."""
    t = r['options_fa'][r['correct_index']]
    # normalise the Persian zero-width non-joiner and Arabic/Persian variants so
    # that 'می‌افتد' and 'میافتد' compare equal
    t = t.replace('\u200c', '').replace('\u064a', '\u06cc').replace('\u0643', '\u06a9')
    t = re.sub(r'[^\w\u0600-\u06FF ]', ' ', t)
    words = [w for w in t.split() if w not in _FILLER]
    return ''.join(sorted(words))

def build_clusters(bank):
    T = [(r['uid'], toks(r['stem_fa'] + ' ' + ' '.join(r['options_fa'])), r) for r in bank]
    parent = {}
    def find(x):
        parent.setdefault(x, x)
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb
    for i in range(len(T)):
        for j in range(i + 1, len(T)):
            # only compare inside the same chapter — cheap and avoids false hits
            if T[i][2]['chapter_num'] != T[j][2]['chapter_num']:
                continue
            if jaccard(T[i][1], T[j][1]) >= THRESHOLD:
                union(T[i][0], T[j][0])
    groups = defaultdict(list)
    for uid in list(parent):
        groups[find(uid)].append(uid)
    return [sorted(v) for v in groups.values() if len(v) > 1]

def main():
    path = os.path.join(BASE, 'bank.json')
    bank = json.load(open(path, encoding='utf-8'))
    by_uid = {r['uid']: r for r in bank}

    # reset previous run
    for r in bank:
        for k in ('cluster_id', 'is_representative', 'variant_of',
                  'repeat_count', 'repeat_sources', 'answer_conflict'):
            r.pop(k, None)

    clusters = build_clusters(bank)
    conflicts = []

    for n, group in enumerate(clusters, 1):
        cid = f'cl-{n:03d}'
        members = [by_uid[u] for u in group]
        answers = {norm_ans(m) for m in members}
        # Some clusters are mirror images of one question: the same concept
        # asked with the sides swapped, so the keys legitimately differ. These
        # are documented in notes.cluster_note during source review. They are
        # not answer conflicts, and all members stay on the path because
        # practising the side-switch is exactly what defeats rote memorisation.
        mirrored = all((m.get('notes') or {}).get('cluster_note') for m in members)
        conflict = len(answers) > 1 and not mirrored
        if conflict:
            conflicts.append((cid, group, [m['options_fa'][m['correct_index']] for m in members]))

        # representative = the member with a lesson already written, otherwise
        # the one with the longest stem (usually the most complete wording)
        rep = next((m for m in members if m.get('explanation_fa')), None)
        if rep is None:
            rep = max(members, key=lambda m: len(m['stem_fa']))

        sources = sorted({m['source'] for m in members})
        for m in members:
            m['cluster_id'] = cid
            m['is_representative'] = mirrored or (m['uid'] == rep['uid'])
            m['repeat_count'] = len(members)
            m['repeat_sources'] = sources
            if conflict:
                m['answer_conflict'] = True
            if mirrored:
                m['mirror_variant'] = True
            elif m['uid'] != rep['uid']:
                m['variant_of'] = rep['uid']

    # everything not in a cluster is its own representative
    for r in bank:
        if 'cluster_id' not in r:
            r['is_representative'] = True
            r['repeat_count'] = 1

    json.dump(bank, open(path, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

    reps = sum(1 for r in bank if r['is_representative'])
    print(f'clusters: {len(clusters)} | questions in clusters: {sum(len(g) for g in clusters)}')
    print(f'representatives kept for the path: {reps} / {len(bank)}')
    print(f'variants suppressed: {len(bank) - reps}')
    if conflicts:
        print(f'\n⚠️  {len(conflicts)} cluster(s) disagree on the answer — review needed:')
        for cid, group, answers in conflicts:
            print(f'  {cid}: {group}')
            for u, a in zip(group, answers):
                print(f'      {u} → {a}')
    return 0

if __name__ == '__main__':
    sys.exit(main())
