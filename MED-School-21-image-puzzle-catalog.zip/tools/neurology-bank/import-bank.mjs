/**
 * Import the neurology bank into a running MED School server.
 *
 * The server accepts a 2 MB JSON body (see express.json in server/src/app.js).
 * A fully authored 605-question bank is roughly 7 MB, so it must be sent in
 * chunks. `to_import.py` writes `import-payload.partNN.json` files for exactly
 * this purpose; this script posts them in order and reports the totals.
 *
 * Raising the server-wide body limit was deliberately avoided: it applies to
 * every endpoint and a larger cap means more memory per request and a bigger
 * denial-of-service surface, which would slow the site down for everyone.
 *
 * Usage:
 *   node tools/neurology-bank/import-bank.mjs [baseURL] [--user admin] [--pass demo]
 */
import { readFileSync, existsSync, readdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const BASE = process.argv.find((a) => a.startsWith('http')) || 'http://localhost:4320';
const argOf = (name, dflt) => {
  const i = process.argv.indexOf(`--${name}`);
  return i > -1 ? process.argv[i + 1] : dflt;
};

const files = (() => {
  const parts = readdirSync(HERE)
    .filter((f) => /^import-payload\.part\d+\.json$/.test(f))
    .sort();
  if (parts.length) return parts.map((f) => join(HERE, f));
  const single = join(HERE, 'import-payload.json');
  if (existsSync(single)) return [single];
  throw new Error('no import payload found — run `python3 to_import.py` first');
})();

const run = async () => {
  const r = await fetch(`${BASE}/api/auth/login`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ username: argOf('user', 'admin'), password: argOf('pass', 'demo') }),
  });
  const { token } = await r.json();
  if (!token) throw new Error('login failed');

  let inserted = 0;
  let attached = 0;
  for (const f of files) {
    const body = readFileSync(f, 'utf8');
    const mb = Buffer.byteLength(body) / 1024 / 1024;
    if (mb > 2) {
      console.log(`✗ ${f.split('/').pop()} is ${mb.toFixed(2)} MB and exceeds the 2 MB server limit`);
      console.log('  re-run: python3 to_import.py --chunk-size 60');
      process.exit(1);
    }
    const res = await fetch(`${BASE}/api/admin/official-question-import/commit`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
      body,
    });
    if (!res.ok) {
      console.log(`✗ ${f.split('/').pop()} → HTTP ${res.status} ${(await res.text()).slice(0, 200)}`);
      process.exit(1);
    }
    const j = await res.json();
    inserted += j.inserted || 0;
    attached += j.attached || 0;
    console.log(`✓ ${f.split('/').pop().padEnd(30)} ${mb.toFixed(2)} MB → inserted ${j.inserted}, attached ${j.attached}`);
  }
  console.log(`\n✅ imported ${inserted} card(s), attached ${attached} to the path`);
};

run().catch((e) => { console.error(e); process.exit(1); });
