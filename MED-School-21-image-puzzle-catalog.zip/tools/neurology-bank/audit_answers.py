#!/usr/bin/env python3
"""Heuristic answer audit for the neurology bank.

This does NOT replace clinical review — it flags questions whose printed key is
statistically or structurally suspicious so a human checks them first:

  * duplicate option text inside one question (a printing error, like the GBS CSF
    question where two options were identical)
  * clusters whose members disagree on the answer TEXT
  * "except / wrong" stems, where the key is inverted more often by typists
  * options that are obviously non-parallel (one option far longer than others)
  * keys pointing at an option that is a strict substring of another option
  * high-yield concepts (repeated across ≥2 exam sittings) so they get priority
"""
import json, os, re, sys
from collections import Counter, defaultdict

BASE = os.path.dirname(os.path.abspath(__file__))
LETTERS = ['الف', 'ب', 'ج', 'د']

def norm(s):
    return re.sub(r'[^\w\u0600-\u06FF]', '', s)

def main():
    bank = json.load(open(os.path.join(BASE, 'bank.json'), encoding='utf-8'))
    flags = defaultdict(list)

    for r in bank:
        uid = r['uid']
        opts = r['options_fa']
        ci = r['correct_index']

        # 1. identical options inside one question
        seen = Counter(norm(o) for o in opts)
        dupes = [o for o, c in seen.items() if c > 1 and o]
        if dupes:
            flags['duplicate_options'].append(uid)

        # 2. negative stems ("except", "wrong", "is not")
        if re.search(r'به\s*جز|بجز|بغیر|غلط|نادرست|صحیح\s*نیست|نمی\s*باشد', r['stem_fa']):
            flags['negative_stem'].append(uid)

        # 3. key points at an option contained inside another option
        key = norm(opts[ci])
        for i, o in enumerate(opts):
            if i != ci and key and key in norm(o) and key != norm(o):
                flags['key_substring_of_other'].append(uid)
                break

        # 4. wildly non-parallel option lengths
        lens = [len(o) for o in opts]
        if max(lens) > 4 * max(1, min(lens)) and max(lens) > 40:
            flags['nonparallel_options'].append(uid)

        # 5. unresolved cluster answer conflicts
        if r.get('answer_conflict') and not (r.get('notes') or {}).get('cluster_note'):
            flags['cluster_answer_conflict'].append(uid)

        # 6. already-corrected keys (for the record)
        if (r.get('notes') or {}).get('answer_key_correction'):
            flags['corrected_keys'].append(uid)

    # high-yield: concepts asked in 2+ sittings
    high_yield = [r['uid'] for r in bank
                  if r.get('is_representative') and r.get('repeat_count', 1) >= 2]

    total = len(bank)
    print(f'bank: {total} questions')
    print(f'representatives: {sum(1 for r in bank if r.get("is_representative"))}')
    print(f'high-yield repeats (asked in ≥2 sittings): {len(high_yield)} → {high_yield}')
    print()
    order = ['duplicate_options', 'cluster_answer_conflict', 'key_substring_of_other',
             'nonparallel_options', 'negative_stem', 'corrected_keys']
    hard = ('duplicate_options', 'cluster_answer_conflict')
    problems = 0
    for k in order:
        v = flags.get(k, [])
        if not v:
            continue
        mark = '❌' if k in hard else 'ℹ️ '
        if k in hard:
            problems += len(v)
        print(f'{mark} {k}: {len(v)}')
        print(f'     {v[:20]}{" …" if len(v) > 20 else ""}')
    if problems:
        print(f'\n❌ {problems} question(s) need a human answer review')
        return 1
    print('\n✅ no structural answer problems left')
    return 0

if __name__ == '__main__':
    sys.exit(main())
