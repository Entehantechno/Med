#!/usr/bin/env python3
"""Assign a concept tag to every question.

Why: the learning path must guarantee topical coverage and must avoid putting two
questions about the same concept back to back (local interleaving). Both need a
concept label finer than the chapter but coarser than the individual question.

Tagging is keyword-based and deliberately transparent: each concept lists the
Persian terms that identify it. A question gets the concept whose keywords score
highest; ties fall back to the chapter-level generic concept.
"""
import json, os, re, sys
from collections import Counter, defaultdict

BASE = os.path.dirname(os.path.abspath(__file__))

# concept_id -> (Persian label, English label, [keywords])
CONCEPTS = {
    # ---- ch4: epilepsy and other seizure disorders -------------------------
    # Pinned to chapter 4 through CONCEPT_CHAPTERS, so listing this block first
    # only decides ties *within* the chapter: a status-epilepticus stem must
    # land on sz-status rather than on the generic seizure bucket.
    "sz-status-complications": (u"عوارض حالت صرعی", "Complications of status epilepticus",
                       [u"هیپرترمی", u"لاکتیک", u"اسیدوز", u"لکوسیتوز", u"لوکوسیتوز", u"پلئوسیتوز",
                        u"هیپرگلایسمی", u"هیپرگلوکوزواری", u"آسیب اضافی", u"نیازمند به مداخله"]),
    "sz-status":      (u"حالت صرعی و درمان اورژانسی آن", "Status epilepticus and its emergency treatment",
                       [u"استاتوس", u"Status", u"status", u"حالت صرعی", u"تشنج مداوم", u"لورازپام",
                        u"دیازپام", u"پروپوفول", u"پنتوباربیتال", u"می‌دازولام", u"میدازولام",
                        u"mg/kg", u"mg/min", u"بدون برگشت هوشیاری", u"بدون بهبود هوشیاری",
                        u"پشت سرهم", u"در حال تشنج", u"راه هوایی", u"ABC"]),
    "sz-pregnancy":   (u"صرع در بارداری و شیردهی", "Epilepsy in pregnancy and lactation",
                       [u"بارداری", u"باردار", u"حاملگی", u"حامله", u"شیردهی", u"جنین", u"اسیدفولیک",
                        u"اسید فولیک", u"فولات", u"ویتامین K", u"نقص عصبی", u"تراتوژن",
                        u"ماه دوم بارداری", u"هفتهی ۱۲"]),
    "sz-drug-effects": (u"عوارض داروهای ضد تشنج", "Adverse effects of antiepileptic drugs",
                       [u"گلوکوم", u"سنگ کلیه", u"نارسایی کلیه", u"ویگاباترین", u"افزایش وزن", u"کاهش وزن", u"عوارض احتمالی", u"علت گلوکوم"]),
    "sz-childhood-syndromes": (u"سندرم‌های صرعی کودکان", "Childhood epilepsy syndromes",
                       [u"لنوکس", u"گاستو", u"اسپاسم شیرخوارگی", u"میوکلونوس نوزادی",
                        u"هیپسآریتمی", u"هیپس آریتمی", u"عقب افتادگی ذهنی", u"اختلال شناختی",
                        u"کمتر از ۴ هرتز", u"آتونیک", u"ابسانس اتیپیک", u"اتیپیک", u"۱/۵ هرتز"]),
    "sz-jme":         (u"صرع میوکلونیک جوانان", "Juvenile myoclonic epilepsy",
                       [u"میوکلونیک", u"میوکلونی", u"پرش", u"پرشی", u"حرکات پرشی", u"صبحگاهی",
                        u"صبحها", u"صبح ها", u"بیدار شدن از خواب", u"برخاستن از خواب", u"بیخوابی",
                        u"بی‌خوابی", u"جوانان", u"JME"]),
    "sz-temporal":    (u"صرع لوب تمپورال و تشنج کانونی", "Temporal lobe epilepsy and focal seizures",
                       [u"تمپورال", u"لمپورال", u"اتوماتیسم", u"Automatism", u"automatism",
                        u"پارشیل کمپلکس", u"پارسیل مرکب", u"پارشیل ساده", u"پارسیل ساده",
                        u"complex partial", u"Complex partial", u"Simple partial", u"partial",
                        u"C. P. S", u"CPS", u"بوی ناخوشایند", u"توهم بویایی", u"توهم بینایی",
                        u"اپیگاستر", u"ملچ", u"لیسیدن لبها", u"جویدن", u"بلع", u"آسیب لوب تمپورال",
                        u"حرکاتی شبیه", u"حرکات تکراری بیهدف", u"وقایع حین حمله"]),
    "sz-principles":  (u"اصول شروع، تنظیم و قطع درمان ضد صرع", "Principles of starting, adjusting and stopping antiepileptic therapy",
                       [u"استراتژی", u"سطح سرمی", u"داروی دوم", u"مونوتراپی", u"تک درمانی",
                        u"حداکثر دوز قابل تحمل", u"قطع دارو", u"قطع کنیم", u"عدم پاسخ درمانی",
                        u"اضافه کنیم", u"کنترل و درمان تشنج", u"نمی‌پذیرید", u"اقدام تشخیصی بعدی",
                        u"اولین اقدام", u"الکترولیت", u"بهترین داروی انتخابی", u"داروی انتخابی کدام"]),
    "sz-focal-rx":    (u"درمان تشنج کانونی", "Treatment of focal seizures",
                       [u"جکسونی", u"مارش", u"چرخش سر", u"حرکت تونیک در اندام",
                        u"تونیک کلونیک اندام فوقانی سمت", u"فلج تاد", u"ضعف اندام پس از",
                        u"ضایعه فوکال", u"ضایعه ی فوکال", u"پرش دست راست", u"پرشی دست راست",
                        u"تشنج فوکال", u"قطع ناگهانی داروی آرامبخش", u"بلافاصله تشنج جنرالیزه"]),
    "sz-absence":     (u"صرع ابسانس", "Absence epilepsy",
                       [u"ابسانس", u"آبسانس", u"ابسنس", u"ایسانس", u"Absence", u"absence",
                        u"خیرگی", u"خیره شدن", u"مات شدگی", u"مات شدن", u"سه هرتز", u"۳ هرتز",
                        u"اتوسوکسیماید", u"اتوسوکسامید", u"اتوسوکسماید", u"اتوسوکسمید",
                        u"اتوسوکساماید", u"اتوسوکساید", u"اتوموکسیماید", u"Ethosuximide",
                        u"Ethosuxemide", u"سوزنی- موجی", u"پلک زدن", u"3cycle", u"persecond",
                        u"سه سیکل در ثانیه"]),
    "sz-vs-syncope":  (u"افتراق تشنج از سنکوپ و سودوسیژر", "Distinguishing seizure from syncope and pseudoseizure",
                       [u"سنکوپ", u"Pseudoseizure", u"pseudoseizure", u"سودوسیژر", u"psychogenic",
                        u"روانی", u"افت هوشیاری", u"افتراق", u"زخمی شدن زبان", u"Tongue Biting",
                        u"گزش زبان", u"بی اختیاری ادراری", u"بیاختیاری ادرار", u"حالت ایستاده",
                        u"اطمینان بخشی"]),
    "sz-todd":        (u"فلج تاد", "Todd's paralysis",
                       [u"Todd", u"تاد", u"Todd’s", u"Todd paralysis"]),

    # ---- ch3: cerebrovascular disease --------------------------------------
    # Listed first and pinned to chapter 3 through CONCEPT_CHAPTERS, so the order
    # only decides ties *within* the chapter: a carotid-dissection stem must land
    # on dissection rather than on the generic stroke-syndrome bucket.
    "cvst":           (u"ترومبوز سینوس وریدی مغز", "Cerebral venous sinus thrombosis",
                       [u"سینوس ساژیتال", u"دلتا", u"delta", u"Delta", u"سینوس وریدی", u"ترمبوز سینوس",
                        u"ترومبوز سینوس", u"ورید گالن", u"ادم پاپی", u"آدم پاپی", u"پس از زایمان",
                        u"بعد از زایمان", u"OCP", u"قرص جلوگیری", u"روزهداری", u"ونوگرافی",
                        u"آنتیکواگولان", u"آنتی‌کواگولانت", u"آنتی‌کوآگولانت", u"هپارین"]),
    "artery-dissection": (u"دیسکسیون شریان گردنی", "Cervical artery dissection",
                       [u"دیسکسیون", u"discection", u"dissection", u"Dissection", u"دایسکشن",
                        u"درد گردن", u"درد سر و گردن", u"ورزش شدید", u"ورزشکار"]),
    "sah-complications": (u"خونریزی زیرعنکبوتیه و عوارض آن", "Subarachnoid haemorrhage and its complications",
                       [u"وازو اسپاسم", u"وازواسپاسم", u"ساب اراکنوئید", u"زیرعنکبوتیه",
                        u"تحت عنکبوتیه", u"رتین", u"هیدرو سفالی", u"فلکسیون گردن"]),
    "ich-management": (u"خونریزی داخل مغزی و درمان آن", "Intracerebral haemorrhage and its management",
                       [u"ICH", u"آمیلوئید آنژیوپاتی", u"خونریزی لوبار", u"خونریزی مخچه",
                        u"خونریزی بوتامن", u"خونریزی تالاموس", u"تخلیهی هماتوم", u"تخلیه‌ی هماتوم",
                        u"مانیتول", u"دگزامتازون", u"انسفالوپاتی هیپرتانسیو", u"۲۳۰/۱۲۰", u"230/120"]),
    "stroke-acute-rx": (u"درمان حاد سکته و ترومبولیز", "Acute stroke treatment and thrombolysis",
                       [u"TPA", u"tPA", u"TPA", u"rt- PA", u"rtpa", u"ترومبولیتیک", u"پلاسمینوژن",
                        u"اندارترکتومی", u"اندآرترکتومی", u"استنت کاروتید", u"آنژیوپلاستی",
                        u"کلوپیدگرول", u"Aspirin", u"آسپیرین", u"وارفارین", u"فشار خون بالای بیمار",
                        u"ارزش کمتری", u"اولویت تشخیص"]),
    "tia":            (u"حمله‌ی ایسکمیک گذرا", "Transient ischaemic attack",
                       [u"TIA", u"ایسکمی گذرا", u"گذرای", u"ABCD2", u"بهبودی کامل در عرض",
                        u"بهبودی نسبی", u"آمموروزیس", u"آموروزیس", u"کوری گذرا", u"نابینایی گذرا",
                        u"داپلر عروق کاروتید", u"داپلر ترانس کرانیال", u"داسی شکل", u"کاروتید داخلی"]),
    "stroke-mechanism": (u"مکانیسم و انواع سکته", "Stroke mechanisms and subtypes",
                       [u"آمبولیک", u"لاکونر", u"لاکونار", u"آتروترومبوتیک", u"کاردیو آمبولیک",
                        u"هروئین", u"واسکولیت", u"ایسکمیک از هموراژیک", u"قابل پیشبینی"]),
    "brainstem-stroke": (u"سندرم‌های عروقی ساقه‌ی مغز", "Brainstem vascular syndromes",
                       [u"لترال مدولا", u"لاترال مدولا", u"والنبرگ", u"Weber", u"Benedict",
                        u"Fovill", u"Nottnogel", u"Nothnagel", u"بازیلار", u"بازیلر", u"Basilar",
                        u"PICA", u"AICA", u"SCA", u"مخچه ای فوقانی", u"مخچهای فوقانی",
                        u"اینفریور سربلار", u"سوپریور سربلار", u"ورتبروبازیلر", u"ورتبرال",
                        u"گردش خون خلفی", u"حرکات عمودی چشم", u"کوادری پلژیک", u"پونز",
                        u"CPM", u"انسفالیت ساقه", u"حرکت چشم راست به خارج", u"کج شدن صورت"]),
    "stroke-territory": (u"قلمروهای عروقی نیمکره", "Hemispheric arterial territories",
                       [u"مغزی قدامی", u"مغزی میانی", u"مغزی خلفی", u"MCA", u"ACA", u"PCA",
                        u"شاخه ی فوقانی", u"شاخهی فوقانی", u"شاخه ی تحتانی", u"شاخهی تحتانی",
                        u"لنتیکولواستریات", u"occipital pole", u"دو شاخه شدن", u"تنهی شریان",
                        u"Anterior Cerebral", u"Middle Cerebral", u"Posterior Inferior",
                        u"اندام تحتانی راست به همراه بیاختیاری"]),

    # ---- ch11: multiple sclerosis and demyelinating disease ----------------
    # This block is listed first on purpose. Every concept below is pinned to
    # chapter 11 through CONCEPT_CHAPTERS, so putting it first only decides
    # ties *within* the chapter: an aquaporin-4 stem must land on nmosd rather
    # than on the generic MS-diagnosis bucket.
    "nmosd":          (u"نوروميليت اپتیکا و طیف آن", "Neuromyelitis optica spectrum disorder",
                       [u"Neuromyelitis", u"نوروميليت", u"دویک", u"Devic", u"آکواپورین", u"Aquaporin",
                        u"NMO", u"ریتوکسیماب", u"Rituximab", u"مایکوفنولات", u"Mycophenolate",
                        u"میتوکسانترون", u"Mitoxantrone", u"پلاک طولی", u"C3 تا C7", u"C2 تا C6",
                        u"C6 الی T2", u"T2 تا T8", u"سه سطح تغییر سیگنال", u"آزاتیوپرین"]),
    "ms-pregnancy":   (u"ام‌اس و بارداری", "Multiple sclerosis and pregnancy",
                       [u"بارداری", u"باردار", u"زایمان", u"تریمستر", u"سه ماه اول پس از",
                        u"سه ماه سوم بارداری", u"حاملگی"]),
    "ms-dmt":         (u"درمان اصلاح‌کننده‌ی ام‌اس", "Disease-modifying therapy in MS",
                       [u"اینترفرون", u"Interferon", u"فینگولیمود", u"Fingolimod", u"ناتالیزوماب",
                        u"Natalizumab", u"گلاتیرامر", u"Glatiramer", u"Dimethyl fumarate",
                        u"دی‌متیل فومارات", u"خط اول درمان", u"JC virus", u"جایگزینی با کدام"]),
    "ms-relapse-rx":  (u"درمان حمله‌ی حاد ام‌اس", "Treatment of acute MS relapse",
                       [u"متیل پردنیزولون", u"متیل‌پردنیزولون", u"Methylprednisolone", u"پالس",
                        u"پلاسمافرز", u"پلاسمافرزیس", u"پلاسما فرز", u"IVIG", u"ایمونوگلوبولین",
                        u"استروئید", u"پاسخ مناسبی دیده نشد", u"کاربامازپین", u"دیزارتری"]),
    "ms-symptomatic": (u"درمان علامتی ام‌اس", "Symptomatic treatment in MS",
                       [u"خستگی شدید", u"آمانتادین", u"ammantadine", u"Amantadine", u"تکرر ادرار",
                        u"دترسور", u"اکسی بوتینین", u"Oxybutynin", u"Tolterodine", u"Solifenacin",
                        u"Bethanechol", u"دنیزیل", u"ریواستیگمین", u"اختلال حافظه", u"Cognitive"]),
    "ms-prognosis":   (u"پیش‌آگهی ام‌اس", "Prognosis of multiple sclerosis",
                       [u"پروگنوز", u"پیش آگهی", u"پیشآگهی", u"پیش‌آگهی", u"عوامل مطلوب",
                        u"عود در سال اول", u"نشان دهنده", u"پروگنوز بدتر", u"پروگنوز بهتر",
                        u"پیشآگهی بد", u"پیش آگهی بد", u"را بدتر نماید", u"جنس مذکر",
                        u"جنس مؤنث", u"شروع بعد از", u"سن شروع", u"آتاکسی مخچهای",
                        u"علائم پیرامیدال", u"شروع با علائم", u"شروع بیماری با"]),
    "ms-workup":      (u"تصویربرداری و آزمایش‌های ام‌اس", "Imaging and laboratory work-up in MS",
                       [u"Black hole", u"بلک هول", u"اولیگوکلونال", u"الیگوکلونال", u"OCB",
                        u"گادولینیوم", u"مادهی حاجب", u"ماده‌ی حاجب", u"پتانسیل فراخوانده",
                        u"visual evoked", u"VEP", u"دقت تشخیصی", u"اقدام تشخیصی", u"روش تشخیصی",
                        u"آنتینوکلئار", u"آنتی نوکلئار", u"ضروری نیست", u"کرایتریا", u"criteria",
                        u"امآرای مغز و نخاع", u"MRI"]),
    "ms-diagnosis":   (u"تشخیص و علائم ام‌اس", "Diagnosis and clinical features of MS",
                       [u"ام اس", u"اماس", u"MS", u"مولتیپل اسکلروزیس", u"مالتیپل اسکلروز",
                        u"multiple sclerosis", u"Multiple sclerosis", u"دمیلینه", u"نوریت اپتیک",
                        u"مارکوس گان", u"لرمیت", u"internuclear", u"شروع بیماری",
                        u"اوج بروز", u"مناطق گرمسیر", u"شرایط اقتصادی", u"سه برابر زنان"]),

    # ---- ch1: neurologic examination ---------------------------------------
    "aphasia":        ("آفازی و اختلالات زبان", "Aphasia and language disorders",
                       ["آفازی", "بروکا", "ورنیکه", "تکلم", "زبان", "نئولوژیسم", "پارافازی", "دیس‌آرتری", "دیس آرتری"]),
    "pupil":          ("مردمک و رفلکس نوری", "Pupil and light reflex",
                       ["مردمک", "رفلکس نوری", "آنیزوکوری", "هورنر", "RAPD", "میوز", "میدریاز"]),
    "optic-nerve":    ("عصب اپتیک و نوروپاتی", "Optic nerve and neuropathy",
                       ["عصب اپتیک", "دیسک اپتیک", "نوریت", "پاپی‌ادم", "پاپی ادم", "NAION", "بینایی چشم"]),
    "eye-movement":   ("حرکات چشم و فلج نگاه", "Eye movements and gaze palsy",
                       ["دوبینی", "تروکلئار", "ابدوسنس", "اکولوموتور", "INO", "MLF", "PPRF", "نگاه", "نیستاگموس", "یک و نیم"]),
    "visual-field":   ("میدان بینایی", "Visual fields",
                       ["میدان بینایی", "همیانوپی", "کوادرانتانوپی", "کیاسما", "پریمتری", "اسکوتوم", "تمپورال دو طرف"]),
    "cortical-sens":  ("حس قشری و نگلکت", "Cortical sensation and neglect",
                       ["گرافستزی", "استریوگنوزی", "آگرافستزی", "extinction", "نگلکت", "حس کورتیکال", "حس‌های کورتیکال"]),
    "gait":           ("اختلالات راه رفتن", "Gait disorders",
                       ["راه رفتن", "gait", "آپراکسی", "استپاژ", "رومبرگ", "تعادل", "چسبیده است"]),
    "cerebellum":     ("مخچه و آتاکسی", "Cerebellum and ataxia",
                       ["مخچه", "آتاکسی", "دیسمتری", "ورمیس", "cerebell", "خونریزی مخچه"]),

    # ---- ch8: headache -----------------------------------------------------
    "migraine-dx":    ("تشخیص می‌گرن", "Migraine diagnosis",
                       ["می‌گرن", "میگرن", "اورا", "ضربان دار", "ضرباندار", "فوتوفوبی"]),
    "migraine-rx":    ("درمان و پیشگیری می‌گرن", "Migraine treatment and prophylaxis",
                       ["پروفیلاکسی", "پیشگیری", "توپیرامات", "پروپرانولول", "والپروات", "آمی‌تریپتیلین",
                        "تریپتان", "سوماتریپتان", "ارگوتامین"]),
    "moh":            ("سردرد ناشی از مصرف بیش از حد دارو", "Medication overuse headache",
                       ["مصرف بیش از حد", "هر روز دچار سردرد", "قطع مسکن", "کدئین", "روزانه سردرد", "بازگشتی"]),
    "headache-preg":  ("سردرد در بارداری", "Headache in pregnancy",
                       ["باردار", "بارداری", "حامله", "تریمستر", "هفته‌ی ۳۶", "هفته ۲۴"]),
    "cluster-tac":    ("سردرد خوشه‌ای و TACها", "Cluster headache and TACs",
                       ["کلاستر", "خوشه‌ای", "خوشه ای", "اشک ریزش", "اشک‌ریزش", "گرفتگی بینی", "بیقراری", "بی‌قراری"]),
    "other-primary":  ("سایر سردردهای اولیه", "Other primary headaches",
                       ["ایندومتاسین", "ورزشی", "سرفه", "همی‌کرانیا", "تنشی"]),
    "raised-icp":     ("افزایش فشار داخل جمجمه", "Raised intracranial pressure",
                       ["فشار داخل جمجمه", "پسودوتومور", "ایدیوپاتیک اینتراکراینال", "IIH", "پاپی‌ادم"]),
    "facial-pain":    ("درد صورت و نورالژی", "Facial pain and neuralgia",
                       ["نورالژی", "تری ژمینال", "تری‌ژمینال", "درد صورت", "کاربامازپین"]),
    "secondary-ha":   ("سردرد ثانویه و پرچم قرمز", "Secondary headache and red flags",
                       ["آرتریت تمپورال", "سلول ژانت", "خونریزی زیرعنکبوتیه", "تندرلاین", "ESR", "سدیمان"]),

    # ---- ch8 (second half): facial pain, GCA, raised ICP, SAH ---------------
    # These four are listed before the migraine concepts on purpose: a stem that
    # names carbamazepine, an ESR, papilloedema or a thunderclap headache belongs
    # to one of them even when it also uses generic headache words, and ties go
    # to the first match.
    "trigeminal-neuralgia": (u"نورالژی تری‌ژمینال و درد صورت", "Trigeminal neuralgia and facial pain",
                       [u"تری ژمینال", u"تریژمینال", u"نورالژی", u"شوک مانند", u"تیر کشنده",
                        u"خنجری", u"رعدآسای لحظه", u"کاربامازپین", u"Oxcarbazepine", u"اکسکاربازپین",
                        u"ماگزیلری", u"ماندیبولار", u"لمس صورت", u"مسواک زدن", u"جویدن",
                        u"SUNCT", u"لاموتریژین", u"زوستر", u"ضایعات پوستی"]),
    "giant-cell-arteritis": (u"آرتریت سلول ژانت", "Giant cell arteritis",
                       [u"آرتریت تمپورال", u"سلول ژانت", u"شقیقه", u"تمپورال", u"ESR", u"سدیمان",
                        u"بیوپسی شریان", u"پردنیزولون", u"پردنیزلون", u"کورتون", u"شانه کردن",
                        u"تندرنس", u"تنرنس", u"پلیمیالژی", u"کاهش وزن", u"لنگش فک", u"نگران کننده"]),
    "raised-icp-iih": (u"افزایش فشار داخل جمجمه و پسودوتومور", "Raised intracranial pressure and pseudotumour",
                       [u"ادم پاپی", u"آدم پاپی", u"ادم دیسک", u"ورم دیسک", u"پاپی ادم",
                        u"پسودوتومور", u"سودوتومور", u"فشار CSF", u"فشار مایع مغزی",
                        u"استازولامید", u"ایزوترتینوئین", u"هایپرویتامینوز", u"بطنها",
                        u"slit", u"Slit", u"وزوز گوش", u"سرفه تشدید", u"سرفه شروع", u"اوایل صبح",
                        u"استفراغ صبحگاهی", u"ونوگرافی"]),
    "sah-thunderclap": (u"خونریزی زیرعنکبوتیه و سردرد رعدآسا", "Subarachnoid haemorrhage and thunderclap headache",
                       [u"ساب آراکنوئید", u"سابآراکنوئید", u"ساب آرکنوئید", u"Subarachnoid",
                        u"رعدآسا", u"بدترین سردرد", u"شدیدترین سردرد", u"ساب هیالوئید",
                        u"وازواسپاسم", u"آنوریسم", u"سفتی گردن", u"رژیدیتی گردن", u"ردور گردن",
                        u"سیتیاسکن مغز", u"سیتیاسکن نرمال", u"پونکسیون کمری", u"پانکسیون کمری",
                        u"سردرد بسیار شدید", u"به اوج خودش رسیده", u"Hemicrania Continua",
                        u"Cervicocephalic", u"داپلر ترانس",
                        u"خونریزی مجدد", u"با نشستن", u"دراز کشیدن برطرف", u"سوزن LP", u"سوزن"]),
    # ---- ch9: vertigo and vestibular disorders -----------------------------
    "vertigo-central":(u"افتراق سرگیجه مرکزی از محیطی", "Central vs peripheral vertigo",
                       [u"مرکزی", u"سنترال", u"Central", u"ساقه", u"نیستاگموس عمودی",
                        u"نیستاگموس bidirectional", u"head trust", u"head impulse", u"تصویربرداری مغزی"]),
    "bppv":           (u"سرگیجه وضعیتی خوش‌خیم", "Benign paroxysmal positional vertigo",
                       [u"هال پایک", u"هالپایک", u"Dix", u"Epley", u"اپلی", u"Repositioning",
                        u"وضعیتی", u"latency", u"خستگی"]),
    "meniere":        (u"بیماری منیر و علائم حلزونی", "Meniere disease and cochlear symptoms",
                       [u"منیر", u"وزوز", u"تینیتوس", u"پری در گوش", u"پری گوش", u"اودیومتری",
                        u"ادیومتری", u"کاهش شنوایی", u"نورینوم آکوستیک"]),
    "vest-neuritis":  (u"نوریت دهلیزی و سمیت گوشی", "Vestibular neuritis and ototoxicity",
                       [u"نوریت وستیبولار", u"نوریت دهلیزی", u"کالریک", u"جنتامایسین",
                        u"پردنیزولون", u"لابیرنتیت"]),



    # ---- ch10: dementia and amnestic syndromes -----------------------------
    "alzheimer":      (u"بیماری آلزایمر", "Alzheimer disease",
                       [u"آلزایمر", u"حافظهی اخیر", u"حافظه‌ی اخیر", u"حافظهی کوتاه",
                        u"ممانتین", u"دونپزیل", u"دانپزیل", u"گالانتامین", u"ریواستیگمین",
                        u"کورتیکال", u"سابکورتیکال", u"رفلکسهای اولیه", u"دمانس کورتیکال",
                        u"تظاهرات زودرس", u"آفازی آنومیک", u"بدبینی", u"ترازودون",
                        u"Quetipine", u"آژیناسیون"]),
    "ftd-huntington": (u"دمانس فرونتوتمپورال و هانتینگتون", "Frontotemporal dementia and Huntington",
                       [u"فرونتوتمپورال", u"Fronto- temporal", u"تغییرات شخصیتی", u"بیتفاوتی",
                        u"هانتینگتون", u"کودیت", u"ALS", u"گوشه گیری"]),
    "lewy-parkinson-plus": (u"اجسام لوی و سندرم‌های پارکینسون-پلاس", "Lewy body and Parkinson-plus syndromes",
                       [u"لوی", u"لووی", u"توهمات بینایی", u"هالوسیناسیون بینایی", u"نوسان",
                        u"فوق هسته", u"supranuclear", u"کورتیکوبازال", u"کورتیکوپازال",
                        u"دست راست وی غیر ارادی", u"آگرافستزی", u"نگاه عمودی"]),
    "nph-cjd":        (u"هیدروسفالی با فشار طبیعی و پریون", "Normal pressure hydrocephalus and prion disease",
                       [u"NPH", u"هیدروسفالی", u"شانت", u"شنت", u"بطنها", u"بطن‌ها",
                        u"کروتزفلد", u"کروتسفلد", u"کروتسد", u"پریون", u"میوکلونوس",
                        u"بیاختیاری ادرار", u"بی‌اختیاری ادرار", u"اختلال راه رفتن",
                        u"دیلاتاسیون بطن", u"آلبومین", u"تست های تیروئیدی", u"Normal Pressure", u"shuffling"]),

    # ---- ch13: diseases of the peripheral nerves ----------------------------
    # GBS is listed first on purpose: a stem naming areflexia with ascending
    # weakness is a GBS item even when it also mentions a sensory level as a
    # distractor, and ties go to the first match.
    # The GBS block is split three ways so a 28-item concept does not dominate
    # the chapter. Treatment is listed first because a stem naming plasma
    # exchange or IVIG is a treatment item even when it also recites the
    # diagnostic features, and ties go to the first match.
    "gbs-treatment":  (u"درمان سندرم گیلن‌باره", "Guillain-Barré treatment",
                       [u"پلاسمافرز", u"پلاسمافرزیس", u"تعویض پلاسما", u"Plasma Exchange",
                        u"ایمونوگلوبولین", u"ایمنوگلوبولین", u"ایمن گلوبولین", u"IVIG",
                        u"کورتیکواستروئید", u"متیل پردنیزولون", u"کورتون وریدی", u"هپارین",
                        u"بستری در آی سی", u"بستری در ICU", u"پیش آگهی بد", u"سود نخواهد برد",
                        u"پیشنهاد نمیکنید", u"توصیه نمیکنید", u"بدتر شدن مسیر"]),
    "gbs-csf":        (u"مایع مغزی-نخاعی در گیلن‌باره", "CSF in Guillain-Barré",
                       [u"دیسوسیاسیون", u"آنالیز مایع نخاعی", u"محتملترین آنالیز",
                        u"قند ۷۰", u"قند 70", u"رنگ شفاف", u"رنگ کدر", u"پروتئین CSF",
                        u"WBC بالای", u"سلول ۱۰", u"پروتئین 135", u"یافتهی پاراکلینیک",
                        u"اولیگوکلونال", u"هایپوکالمی"]),
    "gbs":            (u"تشخیص و معیارهای گیلن‌باره", "Guillain-Barré diagnosis and criteria",
                       [u"گیلن باره", u"گیلن‌باره", u"گلین باره", u"گیلن پاره", u"آرفلکسی",
                        u"ضعف پیشرونده", u"بالا رونده", u"بالارونده",
                        u"میلر فیشر", u"GQIb", u"GQ1b", u"سطح حسی", u"اسفنگتری",
                        u"پارزی فاشیال", u"فلج عضلات صورت", u"عصب هفتم کرانیال", u"کامپیلوباکتر",
                        u"به ضرر تشخیص", u"به نفع تشخیص", u"فلج 4 اندام", u"فلج پیشرونده ۴ اندام",
                        u"پلک های خود را"]),
    "cidp-mnd":       (u"CIDP و بیماری نورون حرکتی", "CIDP and motor neuron disease",
                       [u"CIDP", u"میلین زدای التهابی مزمن", u"دمیلینه", u"Amyotrophic",
                        u"لترال اسکلروزیس", u"فاسیکولاسیون", u"ریلوزول", u"Riluzole",
                        u"آتروفی زبان", u"اینتراوسئوس", u"نورون محرکه", u"هافمن",
                        u"Oppenheim", u"کلونوس", u"Inclusion Body", u"Spinal Muscular"]),
    "toxic-neuropathy": (u"نوروپاتی سمی و متابولیک", "Toxic and metabolic neuropathy",
                       [u"سرب", u"آرسنیک", u"آرسینک", u"تالیوم", u"جیوه", u"wrist drop",
                        u"افتادگی مچ", u"ارگانوفسفره", u"پورفیری", u"نقاش", u"تعمیرکار",
                        u"کولیکی", u"یورمیا", u"سیروز کبدی", u"آکرومگالی", u"هیپرتیروئیدیسم",
                        u"جذام", u"اولنار ضخیم", u"هیپوپیگمانته", u"پلینوروپاتی"]),
    "radiculopathy":  (u"رادیکولوپاتی و آسیب ریشه", "Radiculopathy and root lesions",
                       [u"ریشهی نخاعی", u"ریشه ی نخاعی", u"رادیکولوپاتی", u"C5", u"C6", u"C7", u"C8",
                        u"L4", u"L5", u"S1", u"بای سپس", u"تری سپس", u"موسکولوکوتانئوس",
                        u"پنجه پا", u"پاشنه پا", u"کمردرد", u"کمر درد", u"درد کمربندی",
                        u"تینل", u"تونل کارپ", u"مچ دست"]),
    # ---- ch14: muscle diseases ---------------------------------------------
    "inflam-myopathy":(u"میوپاتی التهابی", "Inflammatory myopathy",
                       [u"میوپاتی التهابی", u"درماتومیوزیت", u"پلیمیوزیت", u"پلی میوزیت",
                        u"هلیوتروپ", u"بنفش در پلک", u"سیکلوسپورین", u"پردنیزولون"]),
    "ibm":            (u"میوزیت انکلوزیون‌بادی", "Inclusion body myositis",
                       [u"انکلوزیون", u"اینکلوژن", u"Inclusion body", u"IBM",
                        u"واکوئله", u"آمیلوئید", u"فلکسیون انگشتان", u"چهار سر ران"]),
    "dystrophy":      (u"دیستروفی‌های عضلانی", "Muscular dystrophies",
                       [u"دیستروفی", u"دوشن", u"بکر", u"گاورز", u"Gower", u"پسودو هیپرتروفی",
                        u"هیپرتروفی ساق", u"امری دریفوس", u"فاسیو", u"میوتونیک", u"کنتراکچر",
                        u"هیپوتروفی عضلات ساق", u"راه رفتن اردکی", u"کیفوز", u"ناقلین",
                        u"X- link", u"اسکاپولا", u"سوت"]),
    "periodic-paral": (u"فلج دوره‌ای و کانالوپاتی", "Periodic paralysis and channelopathy",
                       [u"فلج دورهای", u"فلج دوره", u"هیپوکالمیک", u"استازولامید",
                        u"پرکربوهیدرات", u"تیروتوکسیکوز", u"الکترولیت", u"periodic paral",
                        u"کم کربوهیدرات", u"فلج شل حاد", u"کم نمک"]),


    # ---- ch15: neuromuscular transmission disorders ------------------------
    "mg-diagnosis":   (u"تشخیص میاستنی گراویس", "Myasthenia gravis diagnosis",
                       [u"میاستنی", u"پتوز", u"تنسیلون", u"ادروفونیوم", u"تودماغی",
                        u"خستگی", u"تحریک مکرر", u"استیل کولین", u"استیلکولین",
                        u"single fiber", u"پست سیناپتیک", u"نوروماسکولار",
                        u"رفلکس مردمک", u"پاسخ مردمک", u"بدون درگیری مردمک"]),
    "mg-treatment":   (u"درمان میاستنی و کریز", "Myasthenia treatment and crisis",
                       [u"تیمکتومی", u"تیموس", u"تیموما", u"پلاسما فرز", u"پلاسمافرز", u"پلاسما فرز",
                        u"مستینون", u"پیریدوستیگمین", u"پنی سیلامین", u"پروپرانولول",
                        u"برداشتن تیموس", u"عوارض دارویی", u"اسهال", u"میوز",
                        u"تابلوی مشابه", u"سلسپت", u"Cellcept", u"کدام درمان را پیشنهاد"]),
    "lems-botulism":  (u"لامبرت-ایتون و بوتولیسم", "Lambert-Eaton and botulism",
                       # "لامبرت"/"ایتون" alone also appear as distractors in MG stems, so
                       # require the fuller disease-defining terms instead.
                       [u"سندروم آیتون", u"سندرم لامبرت", u"لامبرت - ایتون", u"بوتولیسم",
                        u"خشکی دهان", u"می‌دریاز",
                        u"میدریاز", u"پره سیناپتیک", u"کانال", u"گوانیدین", u"دیفتری",
                        u"ضد سم", u"پاسخ نمی", u"عدم پاسم", u"میلر فیشر", u"یبوست",
                        u"تحریک مکرر اعصاب حرکتی با فرکانس بالا"]),

    # ---- ch16: diseases of the spinal cord ---------------------------------
    "cord-hemisect":  (u"سندرم براون-سکار", "Brown-Sequard syndrome",
                       [u"براون", u"سکار", u"سکوارد", u"Hemisection", u"Hemi cord", u"نیمهی جانبی",
                        u"نیمه‌ی جانبی", u"قطع نیمهی نخاع", u"حس عمقی"]),
    "cord-syndromes": (u"سایر سندرم‌های نخاعی", "Other spinal cord syndromes",
                       [u"سنترال کورد", u"Central cord", u"انتریورکورد", u"شریان قدامی طناب",
                        u"میلیت عرضی", u"سطح حسی", u"نخاع توراسیک", u"دم اسب"]),

    # ---- ch12: movement disorders ------------------------------------------
    # Wilson is listed before the parkinsonism concepts on purpose: a stem that
    # names ceruloplasmin, urinary copper or a Kayser-Fleischer ring is a Wilson
    # item even when it also describes rigidity, and ties go to the first match.
    "wilson":         (u"بیماری ویلسون", "Wilson disease",
                       [u"ویلسون", u"Kayser", u"کایزر", u"سرولوپلاسمین", u"مس ادرار", u"مس در بیوپسی",
                        u"سطح سرمی مس", u"giant panda", u"پاندا", u"حلقه ی قهوهای", u"حلقهی قهوهای",
                        u"هالروردن", u"هالرودن", u"نوروآکانتوسیتوز", u"پنیسیلامین"]),
    "parkinson-dx":   (u"تشخیص پارکینسون و پارکینسونیسم آتیپیک", "Parkinson disease diagnosis and atypical parkinsonism",
                       [u"پارکینسون", u"رژیدیتی", u"رژیدیته", u"ریجیدیتی", u"چرخ دنده", u"چرخ‌دنده",
                        u"صورت ماسکه", u"قیافهی ماسکه", u"هیپوکینزی", u"هایپوکینزی", u"قامت خمیده",
                        u"کورتیکوبازال", u"فلج فوق هسته", u"لوی بادی", u"آپراکسی", u"festinating",
                        u"در حالت استراحت", u"کندی حرکات"]),
    "parkinson-rx":   (u"درمان پارکینسون و عوارض لوودوپا", "Parkinson treatment and levodopa complications",
                       [u"لوودوپا", u"Levodopa", u"لودوپا", u"لوردوپا", u"دیسکینزی", u"آمانتادین",
                        u"سلژیلین", u"انتوکاپن", u"انتاکاپون", u"On- Off", u"آگونسیت دوپامین",
                        u"آگونیست دوپامین", u"محدود کردن مصرف پروتئین", u"مؤثرتر است"]),
    "essential-tremor": (u"ترمور اسانسیل", "Essential tremor",
                       [u"Essential tremor", u"لرزش سر", u"ترمور سر", u"لرزش صدا", u"پروپرانولول",
                        u"نگاه داشتن دستها", u"نگهداشتن دستها", u"وضعیت کشیده", u"کارهای ظریف",
                        u"فعالیت های ظریف", u"سابقه‌ی مثبت لرزش", u"مشکل مشابه در خانواده"]),
    "chorea-ballism": (u"کره و بالیسم", "Chorea and ballismus",
                       [u"کره", u"همی بالیسم", u"همیبالیسم", u"بالیسم", u"همیبالیسموس", u"آتتوز",
                        u"آتتوزیس", u"ساب تالامیک", u"حرکات پرتابی", u"سیدنهام", u"پنیسیلین",
                        u"عفونت چرکی گلو"]),
    "tics-tourette":  (u"تیک و سندرم توره", "Tics and Tourette syndrome",
                       [u"تیک", u"توره", u"دولاتوره", u"بالابردن شانه", u"بالا بردن شانه",
                        u"صاف کردن صدا", u"قادر به کنترل", u"با استرس بدتر"]),
    "rls-tardive":    (u"سندرم پای بی‌قرار، آکاتیژیا و دیسکینزی تاردیو", "Restless legs, akathisia and tardive dyskinesia",
                       [u"پای بیقرار", u"پای بی‌قرار", u"آکاتیژیا", u"اکاتژیا", u"تاردیو",
                        u"متوکلوپرامید", u"تترابنازین", u"حرکت دادن پاها", u"فروس سولفات",
                        u"دوپامینرژیک", u"آگونیست دوپامین", u"زانو تا مچ", u"حرکات تکرار شوندهی لبها"]),

    # ---- ch2: coma and other disorders of consciousness --------------------
    "consciousness-states": (u"سطوح هوشیاری و سندرم قفل‌شدگی", "States of consciousness and locked-in syndrome",
                       [u"Locked", u"قفل", u"vegetative", u"Vegatative", u"نباتی", u"brain death",
                        u"مرگ مغزی", u"Minimally conscious", u"حرکات عمودی چشم", u"حرکت عمودی چشم",
                        u"حرکات عمودی", u"کوادری پلژیک", u"اکولوسفالیک", u"قدام پونز"]),
    "coma-oculomotor": (u"رفلکس‌های چشمی در کما", "Ocular reflexes in coma",
                       [u"کالریک", u"چرخش افقی سر", u"چرخاندهایم", u"حرکت دادن سر", u"سر بیمار را",
                        u"چشم عروسکی", u"انحراف تونیک", u"شستوشوی", u"آب سرد", u"انحراف چشم"]),
    "coma-approach": (u"رویکرد به بیمار کمایی", "Approach to the comatose patient",
                       [u"نورولوژیک بودن علت کما", u"علائم فوکال", u"علائم عصبی فوکال", u"GCS",
                        u"تیامین", u"نالوکسان", u"فلومازنیل", u"دکستروز", u"راه هوایی",
                        u"اقدامات اورژانسی", u"هیپوترم", u"آنتی کولینرژیک", u"B2- transferin",
                        u"Rhinorrhea", u"confusional", u"سایکوتیک", u"در اولویت",
                        u"GCS", u"نمرهی GCS", u"پوزچر", u"پاسخ به تحریک اصوات"]),
    "coma-breathing": (u"الگوهای تنفسی در کما", "Breathing patterns in coma",
                       [u"تنفس", u"آپنوستیک", u"apneustic", u"ataxic", u"cheyne",
                        u"hypoventilation", u"دامنه و فرکانس"]),
    "coma-pupil": (u"مردمک و موضعی‌سازی در کما", "Pupil and localisation in coma",
                       [u"pin point", u"pinpoint", u"نوک سوزنی", u"ته سوزنی", u"مردمکهای بسیار کوچک",
                        u"می‌دریاز", u"میدریاز", u"ارگانوفسفات", u"ارگانو فسفره", u"اپیوئید", u"اپیوم",
                        u"تریاک", u"نوروسیفلیس", u"خونریزی پونز", u"خونریزی پونس", u"خونریزی تالاموس",
                        u"پایین و داخل", u"هیپرترمی"]),
    # ---- ch6: CNS infections -----------------------------------------------
    "bact-meningitis": (u"مننژیت باکتریال", "Bacterial meningitis",
                       [u"مننژیت", u"مننگوکوک", u"پنوموکوک", u"سفتریاکسون", u"ونکومایسین",
                        u"دگزامتازون", u"سفتازیدیم", u"شانت", u"آمپیسیلین",
                        u"سفتی گردن", u"پونکسیون لومبار", u"کشت خون", u"آنتیبیوتیک تجربی"]),
    "hsv-encephalitis":(u"انسفالیت هرپسی", "Herpes encephalitis",
                       [u"انسفالیت", u"هرپس", u"HSV", u"آسیکلوویر", u"تمپورال دو طرف",
                        u"تمپورال دوطرف", u"تمپورال دوطرفه", u"بویایی", u"نکروزان",
                        u"هموراژیک", u"اختلال رفتاری", u"پلئوستیوز", u"EEG"]),
    "cns-tb-viral":   (u"مننژیت سلی و ویروسی", "Tuberculous and viral meningitis",
                       [u"سلی", u"ایزونیازید", u"ریفامپین", u"انترو ویروس", u"تابستان",
                        u"لنفوسیت", u"تعریق شبانه"]),

    # ---- ch7: neurologic complications of systemic disease -----------------
    "endocrine-neuro":(u"عوارض عصبی اختلالات غدد", "Neurologic complications of endocrine disease",
                       [u"هیپوتیروئید", u"لووتیروکسین", u"relaxation", u"Relaxation",
                        u"تونل کارپ", u"یبوست", u"برگشت رفلکس"]),
    "metabolic-enceph":(u"انسفالوپاتی متابولیک و پورفیری", "Metabolic encephalopathy and porphyria",
                       [u"آستریکسی", u"انسفالوپاتی کبدی", u"دکستروز", u"کولیکی",
                        u"پورفیری", u"اپیوم", u"سرب"]),
    "cord-b12":       (u"میلوپاتی تغذیه‌ای و کمبود ب دوازده", "Nutritional myelopathy and B12 deficiency",
                       [u"B12", u"کوبالامین", u"گاسترکتومی", u"لرمیت", u"مگالوبلاستیک",
                        u"پلاکتهای جاینت", u"جاینت", u"فولات", u"تیامین"]),
    "anterior-horn":  (u"شاخ قدامی و پولیو", "Anterior horn cell disease and polio",
                       [u"Postpolio", u"پولیو", u"فاسیکولاسیون", u"آتروفیک", u"کوتاهی اندام"]),
}

CHAPTER_FALLBACK = {
    "فصل اول": "neuro-exam-general",
    "فصل چهارم": "seizure-general",
    "فصل هشتم": "headache-general",
    "فصل ششم": "cns-infection-general",
    "فصل هفتم": "systemic-neuro-general",
    "فصل نهم": "vertigo-general",
    "فصل چهاردهم": "muscle-general",
    "فصل پانزدهم": "nmj-general",
    "فصل دهم": "dementia-general",
    "فصل شانزدهم": "cord-general",
    "فصل سیزدهم": "peripheral-nerve-general",
    "فصل دوم": "coma-general",
    "فصل دوازدهم": "movement-general",
}

# A keyword can legitimately belong to two chapters — "نیستاگموس" appears both in
# gaze-palsy items (ch1) and vertigo items (ch9). Restricting a concept to its
# home chapters stops one chapter stealing another's questions.
CONCEPT_CHAPTERS = {
    # Every ch4 concept is pinned: words such as "بارداری", "خیرگی", "پرش" and
    # "اسیدوز" also live in the MS, coma and headache chapters.
    "sz-status-complications": {"فصل چهارم"},
    "sz-status":               {"فصل چهارم"},
    "sz-pregnancy":            {"فصل چهارم"},
    "sz-drug-effects":         {"فصل چهارم"},
    "sz-jme":                  {"فصل چهارم"},
    "sz-absence":              {"فصل چهارم"},
    "sz-childhood-syndromes":  {"فصل چهارم"},
    "sz-temporal":             {"فصل چهارم"},
    "sz-focal-rx":             {"فصل چهارم"},
    "sz-vs-syncope":           {"فصل چهارم"},
    "sz-principles":           {"فصل چهارم"},
    "sz-todd":                 {"فصل چهارم"},
    "cvst":               {"فصل سوم"},
    "artery-dissection":  {"فصل سوم"},
    "sah-complications":  {"فصل سوم"},
    "ich-management":     {"فصل سوم"},
    "stroke-acute-rx":    {"فصل سوم"},
    "tia":                {"فصل سوم"},
    "stroke-mechanism":   {"فصل سوم"},
    "brainstem-stroke":   {"فصل سوم"},
    "stroke-territory":   {"فصل سوم"},
    "nmosd":            {"فصل یازدهم"},
    "ms-pregnancy":     {"فصل یازدهم"},
    "ms-dmt":           {"فصل یازدهم"},
    "ms-relapse-rx":    {"فصل یازدهم"},
    "ms-symptomatic":   {"فصل یازدهم"},
    "ms-prognosis":     {"فصل یازدهم"},
    "ms-workup":        {"فصل یازدهم"},
    "ms-diagnosis":     {"فصل یازدهم"},
    "vertigo-central": {"فصل نهم"},
    "bppv":            {"فصل نهم"},
    "meniere":         {"فصل نهم"},
    "vest-neuritis":   {"فصل نهم"},
    # "بیقراری" also appears in cluster-headache stems; keep that concept in its
    # own chapters so it cannot claim an encephalitis question.
    "cluster-tac":      {"فصل هشتم"},
    # "پیشگیری"/"پروفیلاکسی" appear in prophylaxis stems across many chapters;
    # keep the migraine treatment concept inside the headache chapter.
    "migraine-rx":      {"فصل هشتم"},
    "migraine-dx":      {"فصل هشتم"},
    "headache-preg":    {"فصل هشتم"},
    "bact-meningitis":  {"فصل ششم"},
    "hsv-encephalitis": {"فصل ششم"},
    "cns-tb-viral":     {"فصل ششم"},
    "endocrine-neuro":  {"فصل هفتم"},
    "metabolic-enceph": {"فصل هفتم"},
    # "مردمک" appears in MG stems only to say the pupil is SPARED, so keep the
    # ch1 pupil concept out of the neuromuscular chapter.
    "pupil":            {"فصل اول"},
    # ch1 examination concepts ("آفازی", "راه رفتن", "حس کورتیکال") appear inside
    # dementia stems as component findings; keep them in their home chapters.
    "cortical-sens":         {"فصل اول"},
    "alzheimer":             {"فصل دهم"},
    "ftd-huntington":        {"فصل دهم"},
    "lewy-parkinson-plus":   {"فصل دهم"},
    "nph-cjd":               {"فصل دهم"},
    "mg-diagnosis":     {"فصل پانزدهم"},
    "mg-treatment":     {"فصل پانزدهم"},
    "lems-botulism":    {"فصل پانزدهم"},
    "inflam-myopathy":  {"فصل چهاردهم"},
    "ibm":              {"فصل چهاردهم"},
    "dystrophy":        {"فصل چهاردهم"},
    "periodic-paral":   {"فصل چهاردهم"},
    "cord-hemisect":   {"فصل شانزدهم"},
    "cord-syndromes":  {"فصل شانزدهم"},
    "cord-b12":        {"فصل شانزدهم"},
    "anterior-horn":   {"فصل شانزدهم"},
    "parkinson-dx":    {"فصل دوازدهم"},
    "parkinson-rx":    {"فصل دوازدهم"},
    "essential-tremor":{"فصل دوازدهم"},
    "chorea-ballism":  {"فصل دوازدهم"},
    "tics-tourette":   {"فصل دوازدهم"},
    "wilson":          {"فصل دوازدهم"},
    "rls-tardive":     {"فصل دوازدهم"},
    # "کاربامازپین" is a distractor in an essential-tremor stem, so keep the
    # facial-pain concept inside the headache chapter.
    "facial-pain":     {"فصل هشتم"},
    "consciousness-states": {"فصل دوم"},
    "coma-oculomotor":  {"فصل دوم"},
    "coma-pupil":       {"فصل دوم"},
    "coma-approach":    {"فصل دوم"},
    "coma-breathing":   {"فصل دوم"},
    "trigeminal-neuralgia": {"فصل هشتم"},
    "giant-cell-arteritis": {"فصل هشتم"},
    "raised-icp-iih":      {"فصل هشتم"},
    "sah-thunderclap":     {"فصل هشتم"},
    "gbs":              {"فصل سیزدهم"},
    "gbs-treatment":    {"فصل سیزدهم"},
    "gbs-csf":          {"فصل سیزدهم"},
    "cidp-mnd":         {"فصل سیزدهم"},
    "toxic-neuropathy": {"فصل سیزدهم"},
    "radiculopathy":    {"فصل سیزدهم"},
    "eye-movement":    {"فصل اول"},
    # "تعادل"/"رومبرگ"/"آتاکسی"/"دیس‌آرتری" are generic balance and speech words
    # that appear inside vertigo and cord stems as incidental findings. Keeping
    # these three concepts out of ch9/ch16 leaves those chapters tagged by their
    # own diagnostic concepts instead.
    "gait":            {"فصل اول"},
    "visual-field":    {"فصل اول"},
    # ch11 has its own optic-neuritis handling inside ms-diagnosis / nmosd.
    "optic-nerve":     {"فصل اول", "فصل سوم", "فصل پنجم"},
    "secondary-ha":    {"فصل هشتم"},
    "aphasia":         {"فصل اول"},
    "cerebellum":      {"فصل اول"},
}


def score(text, keywords):
    t = text.replace("\u200c", " ")
    return sum(1 for k in keywords if k.replace("\u200c", " ") in t)


def main():
    path = os.path.join(BASE, "bank.json")
    bank = json.load(open(path, encoding="utf-8"))

    for r in bank:
        blob = " ".join([r["stem_fa"]] + r["options_fa"])
        best, best_score = None, 0
        for cid, (fa, en, kws) in CONCEPTS.items():
            allowed = CONCEPT_CHAPTERS.get(cid)
            if allowed and r["chapter_num"] not in allowed:
                continue
            s = score(blob, kws)
            if s > best_score:
                best, best_score = cid, s
        if best is None:
            best = CHAPTER_FALLBACK.get(r["chapter_num"], "general")
            r["concept_fa"] = r["chapter_fa"]
            r["concept_en"] = r["chapter_en"]
        else:
            r["concept_fa"] = CONCEPTS[best][0]
            r["concept_en"] = CONCEPTS[best][1]
        r["concept"] = best
        # keep the tag list in sync
        tags = [t for t in (r.get("tags") or []) if not t.startswith("concept:")]
        tags.append(f"concept:{best}")
        r["tags"] = tags

    json.dump(bank, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)

    by_chapter = defaultdict(Counter)
    for r in bank:
        by_chapter[r["chapter_fa"]][r["concept"]] += 1

    print(f"tagged {len(bank)} questions with {len(CONCEPTS)} concepts\n")
    for ch in ["اصول معاینه عصبی", "سردرد و درد صورت و افزایش فشار داخل جمجمه"]:
        if ch not in by_chapter:
            continue
        print(f"— {ch}")
        for cid, n in by_chapter[ch].most_common():
            print(f"    {n:3d}  {cid}")
        print()
    untagged = sum(1 for r in bank if r["concept"].endswith("general"))
    print(f"questions on the generic chapter fallback: {untagged}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
