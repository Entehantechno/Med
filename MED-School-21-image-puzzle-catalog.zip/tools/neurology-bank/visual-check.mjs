/**
 * Visual smoke check for the neurology question bank.
 *
 * Renders the learner-facing lesson in three viewports (Persian desktop,
 * Persian mobile, English desktop) and saves a screenshot of each so a human
 * can confirm the new bilingual lessons and micro-lesson blocks actually look
 * right — not just that the API returns them.
 *
 * Usage:  node tools/neurology-bank/visual-check.mjs [baseURL] [outDir]
 * Assumes a server is already running with the bank imported.
 */
import { chromium } from '@playwright/test';
import { mkdirSync } from 'node:fs';

const BASE = process.argv[2] || 'http://localhost:4320';
const OUT = process.argv[3] || '/tmp/neuro-shots';

// The imported chapter we want to see rendered end to end.
const TARGET_LESSON = process.env.NEURO_LESSON || 'سرگیجه و اختلالات سیستم وستیبولار';
// The path renders node titles in the active UI language, so we need both.
const TARGET_LESSON_EN = process.env.NEURO_LESSON_EN || 'Dizziness and Vestibular Disorders';
// Path node ids that gate TARGET_LESSON. Marked complete before screenshotting.
const UNLOCK = (process.env.NEURO_UNLOCK || '103,104,105,106,107,108,109')
  .split(',').map((x) => Number(x.trim())).filter(Boolean);

const VIEWS = [
  { name: 'fa-desktop', width: 1440, height: 950, lang: 'fa' },
  { name: 'fa-mobile', width: 390, height: 844, lang: 'fa' },
  { name: 'en-desktop', width: 1440, height: 950, lang: 'en' },
];

/** Clear the prerequisite lessons so the chapter we want to photograph unlocks.
 *  Learner progress lives on the server, so this only has to run once for the
 *  whole check rather than once per viewport. */
async function unlockOnce(base, nodeIds) {
  const r = await fetch(`${base}/api/auth/login`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ username: 'learner', password: 'demo' }),
  });
  const { token } = await r.json();
  // Answering questions costs hearts, and repeated runs drain them until the
  // lesson endpoint returns 402. Top them up so the check is repeatable.
  await fetch(`${base}/api/learn/hearts/refill`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
  }).catch(() => {});
  for (const id of nodeIds) {
    await fetch(`${base}/api/learn/lesson/${id}/finish`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
      body: JSON.stringify({ correct: 3, total: 3, xp: 20, stars: 3 }),
    }).catch(() => {});
  }
}

async function login(page) {
  await page.goto(`${BASE}/`, { waitUntil: 'domcontentloaded' });
  await page.evaluate(async (base) => {
    const r = await fetch(`${base}/api/auth/login`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ username: 'learner', password: 'demo' }),
    });
    const j = await r.json();
    if (j.token) localStorage.setItem('medlab_token', j.token);
  }, BASE);
}

const run = async () => {
  mkdirSync(OUT, { recursive: true });
  await unlockOnce(BASE, UNLOCK);
  const browser = await chromium.launch();
  const problems = [];

  for (const v of VIEWS) {
    const ctx = await browser.newContext({
      viewport: { width: v.width, height: v.height },
      locale: v.lang === 'fa' ? 'fa-IR' : 'en-US',
    });
    const page = await ctx.newPage();
    const errors = [];
    page.on('pageerror', (e) => errors.push(String(e)));
    page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });

    await login(page);
    await page.evaluate((lang) => localStorage.setItem('medlab_lang', lang), v.lang);
    await page.goto(`${BASE}/learn`, { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(3000);
    await page.screenshot({ path: `${OUT}/${v.name}-1-home.png`, fullPage: true });

    // Walk into the learning path and open the imported neurology chapter, so
    // the screenshot really shows a bank question with its bilingual stem and
    // micro-lesson rather than the generic seeded content.
    const pathLink = page.getByText(v.lang === 'fa' ? 'مسیر یادگیری' : 'Learning path').first();
    if (await pathLink.count()) {
      await pathLink.click();
      await page.waitForTimeout(2500);
      await page.screenshot({ path: `${OUT}/${v.name}-2-path.png`, fullPage: true });

      // Path nodes are buttons whose title attribute is the lesson name.
      const wanted = v.lang === 'fa' ? TARGET_LESSON : TARGET_LESSON_EN;
      // fall back to the Persian title: chapters imported without an English
      // name render their Persian title in both languages
      let chapter = page.locator(`button[title="${wanted}"]`).first();
      if (!(await chapter.count())) chapter = page.locator(`button[title="${TARGET_LESSON}"]`).first();
      if (await chapter.count()) {
        await chapter.scrollIntoViewIfNeeded();
        await page.waitForTimeout(400);
        await chapter.click();
        await page.waitForTimeout(3000);
        await page.screenshot({ path: `${OUT}/${v.name}-3-lesson.png`, fullPage: true });

        // Answer, then submit, so the shot also captures the explanation and
        // the درسنامه (micro-lesson) panel — the parts this round added.
        // MCQ choices render with the shared .opt class
        const opts = page.locator('button.opt');
        if (await opts.count()) await opts.first().click().catch(() => {});
        await page.waitForTimeout(700);
        const check = page.locator('button', { hasText: v.lang === 'fa' ? /^بررسی$/ : /^Check$/ }).first();
        if (await check.count()) {
          await check.click().catch(() => {});
          await page.waitForTimeout(2500);
          await page.screenshot({ path: `${OUT}/${v.name}-4-explanation.png`, fullPage: true });
          const after = await page.evaluate(() => document.body.innerText);
          // headings used by the card renderer in each language
          const wants = v.lang === 'fa'
            ? /پاسخنامه|درسنامه/
            : /Answer key|Quick lesson|Golden point/i;
          if (!wants.test(after)) {
            problems.push(`${v.name}: no explanation / micro-lesson panel after answering`);
          }
        } else {
          problems.push(`${v.name}: submit button not found`);
        }
      } else {
        problems.push(`${v.name}: imported lesson "${wanted}" not found on the path`);
      }
    }

    const text = await page.evaluate(() => document.body.innerText);
    if (text.length < 200) problems.push(`${v.name}: page looks empty (${text.length} chars)`);
    // ignore benign network noise from optional endpoints
    const real = errors.filter((e) => !/404|favicon|manifest|sw\.js/i.test(e));
    if (real.length) problems.push(`${v.name}: ${real.length} console error(s): ${real[0]}`);

    console.log(`✓ ${v.name} — ${text.length} chars, ${real.length} error(s)`);
    await ctx.close();
    // the API rate-limits bursts; pause between viewports so a later run is
    // not reported as a false "console error"
    await new Promise((r) => setTimeout(r, 4000));
  }

  await browser.close();
  if (problems.length) {
    console.log('\n❌ visual problems:');
    problems.forEach((p) => console.log('  -', p));
    process.exit(1);
  }
  console.log(`\n✅ all ${VIEWS.length} views rendered cleanly → ${OUT}`);
};

run().catch((e) => { console.error(e); process.exit(1); });
