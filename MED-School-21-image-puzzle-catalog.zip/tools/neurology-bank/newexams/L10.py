# -*- coding: utf-8 -*-
"""Micro-lessons, batch 10 — Esfand 1399 and Shahrivar 1400."""
import json, io
L = {}

L["1399-12:114"] = {
 "stem_en": "Which of the following is a sign of poor prognosis in multiple sclerosis?",
 "options_en": ["Onset before the age of 40", "Onset with sensory symptoms",
                "Male sex", "Onset with optic neuritis"],
 "micro": {
  "lead_fa": "جنس مذکر تنها عامل بد در میان چهار گزینه است؛ سه گزینه‌ی دیگر همگی پیش‌آگهی خوب می‌سازند.",
  "lead_en": "Male sex is the only adverse factor among the four; the other three all indicate a good prognosis.",
  "points_fa": [
   "پیش‌آگهی ام‌اس را با چند عامل ساده در همان مراجعه‌ی اول می‌توان تخمین زد.",
   "عوامل پیش‌آگهی خوب: جنس مؤنث، سن کم هنگام شروع و حمله‌ی اول کوتاه.",
   "شروع با علائم حسی یا نوریت اپتیک نشانه‌ی سیر خفیف‌تر است.",
   "بهبود کامل پس از حمله‌ی اول و فاصله‌ی طولانی تا حمله‌ی دوم هم خوب است.",
   "عوامل پیش‌آگهی بد: جنس مذکر و سن بالا هنگام شروع بیماری.",
   "شروع با علائم حرکتی، مخچه‌ای یا اسفنکتری سیر بدتری را پیش‌بینی می‌کند.",
   "درگیری چند سیستم در همان حمله‌ی اول نشانه‌ی بار بیماری بیشتر است.",
   "بار ضایعات بالا در MRI اولیه با ناتوانی بیشتر در بلندمدت همراه است.",
   "فرم پیشرونده‌ی اولیه بدترین پیش‌آگهی را دارد و در مردان مسن‌تر شایع‌تر است."
  ],
  "points_en": [
   "Prognosis in multiple sclerosis can be estimated with a few simple factors at first presentation.",
   "Good prognostic factors: female sex, younger age at onset and a short first attack.",
   "Onset with sensory symptoms or optic neuritis signals a milder course.",
   "Full recovery after the first attack and a long interval to the second are also favourable.",
   "Adverse factors: male sex and older age at disease onset.",
   "Onset with motor, cerebellar or sphincter symptoms predicts a worse course.",
   "Involvement of several systems in the first attack signals a higher disease burden.",
   "A heavy lesion load on the initial MRI correlates with greater long-term disability.",
   "Primary progressive disease has the worst prognosis and is commoner in older men."
  ]
 },
 "explanation_fa": "این سؤال حفظی نیست، بلکه یک فهرست دوستونی را می‌آزماید. ستون خوب و ستون بد را که بشناسید، هر شکلی از این سؤال را می‌توانید حل کنید. اینجا سه گزینه از ستون خوب آمده‌اند: شروع قبل از چهل سالگی یعنی سن پایین که مطلوب است، شروع با علائم حسی مطلوب است، و شروع با نوریت اپتیک هم مطلوب است. فقط یک گزینه از ستون بد آمده و آن جنس مذکر است. علت زیستی این تفاوت جالب است: ام‌اس در زنان دو تا سه برابر شایع‌تر است اما وقتی مردی مبتلا می‌شود، احتمال سیر پیشرونده و انباشت ناتوانی در او بیشتر است. پس شیوع بالاتر در زنان با شدت بیشتر در مردان همراه می‌شود.",
 "explanation_en": "This item is not about memorising facts but about a two-column list. Once you know the good column and the bad column you can solve any version of this question. Here three options come from the good column: onset before forty is a young age and favourable, onset with sensory symptoms is favourable, and onset with optic neuritis is favourable. Only one option comes from the bad column, and that is male sex. The biological reason is interesting. Multiple sclerosis is two to three times commoner in women. But when a man is affected, he is more likely to follow a progressive course and accumulate disability. So higher prevalence in women pairs with greater severity in men.",
 "why_fa": [
  "شروع قبل از چهل سالگی عامل پیش‌آگهی خوب است. هرچه سن شروع پایین‌تر باشد، ذخیره‌ی ترمیمی سیستم عصبی بیشتر است.",
  "شروع با علائم حسی مثل پارستزی نشانه‌ی سیر خفیف‌تر است، چون معمولاً بهبود کامل می‌یابد و ناتوانی نمی‌گذارد.",
  "پاسخ صحیح — جنس مذکر عامل پیش‌آگهی بد است. مردان مبتلا بیشتر به فرم پیشرونده می‌روند و ناتوانی سریع‌تری جمع می‌کنند.",
  "شروع با نوریت اپتیک از مطلوب‌ترین شروع‌هاست. بینایی معمولاً طی هفته‌ها برمی‌گردد و ناتوانی حرکتی به جا نمی‌ماند."
 ],
 "why_en": [
  "Onset before forty is a good prognostic factor. The younger the onset, the greater the nervous system's repair reserve.",
  "Onset with sensory symptoms such as paresthesia signals a milder course, since these usually recover fully without disability.",
  "Correct — male sex is an adverse factor. Affected men more often follow a progressive course and accumulate disability faster.",
  "Onset with optic neuritis is among the most favourable presentations. Vision usually returns over weeks and no motor disability remains."
 ],
 "golden_fa": "خوب: زن، جوان، حسی، نوریت اپتیک. بد: مرد، مسن، حرکتی، مخچه‌ای.",
 "golden_en": "Good: female, young, sensory, optic neuritis. Bad: male, older, motor, cerebellar.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 7: Multiple sclerosis, prognosis",
  "Confavreux C, Vukusic S. Natural history of multiple sclerosis. Brain 2006;129:606-16"
 ]
}

L["1399-12:115"] = {
 "stem_en": "A patient presents with fluctuating cognitive impairment, no clear early amnesia, well-formed visual hallucinations and parkinsonism. What is the most likely diagnosis?",
 "options_en": ["Huntington disease", "Dementia with Lewy bodies",
                "Progressive supranuclear palsy", "Vascular dementia"],
 "micro": {
  "lead_fa": "همان سه‌گانه‌ی هسته‌ای، این بار در برابر سه دمانس دیگر آزموده می‌شود.",
  "lead_en": "The same core triad, this time tested against three other dementias.",
  "points_fa": [
   "دمانس با اجسام لویی سه ویژگی هسته‌ای دارد: نوسان، توهم بینایی و پارکینسونیسم.",
   "این بیماری از تجمع پروتئین آلفا-سینوکلئین در نورون‌های قشری می‌آید.",
   "همان پروتئین در بیماری پارکینسون هم رسوب می‌کند، ولی محل تجمع فرق دارد.",
   "توهم‌های بینایی زودرس و شکل‌یافته‌اند و بیمار اغلب از آن‌ها نمی‌ترسد.",
   "برای افتراق باید بدانید هر دمانس دیگر امضای متفاوتی دارد.",
   "هانتینگتون: کره، تغییرات روانی و سابقه‌ی خانوادگی اتوزومال غالب.",
   "فلج فوق هسته‌ای پیشرونده: زمین‌خوردن زودرس و ناتوانی در نگاه عمودی.",
   "دمانس عروقی: افت پله‌ای، علائم فوکال و سکته‌های متعدد در تصویربرداری.",
   "درمان انتخابی مهارکننده‌ی کولین‌استراز است و نورولپتیک‌ها باید پرهیز شوند."
  ],
  "points_en": [
   "Dementia with Lewy bodies has three core features: fluctuation, visual hallucinations and parkinsonism.",
   "It arises from alpha-synuclein protein accumulating in cortical neurons.",
   "The same protein deposits in Parkinson disease, but in a different distribution.",
   "The visual hallucinations are early and well formed, and often not frightening to the patient.",
   "To discriminate, know that each other dementia has a different signature.",
   "Huntington disease: chorea, psychiatric change and an autosomal dominant family history.",
   "Progressive supranuclear palsy: early falls and an inability to look vertically.",
   "Vascular dementia: stepwise decline, focal signs and multiple infarcts on imaging.",
   "Treatment of choice is a cholinesterase inhibitor and neuroleptics should be avoided."
  ]
 },
 "explanation_fa": "صورت سؤال چهار عنصر می‌دهد و هر چهار عنصر روی یک تشخیص جمع می‌شوند. نوسان شناختی یعنی بیمار در ساعاتی هوشیار و در ساعاتی گیج است. غیاب فراموشی اولیه یعنی الگو با آلزایمر فرق دارد. توهم بینایی شکل‌یافته یعنی بیمار آدم‌ها یا حیوانات دقیق و واضح می‌بیند. و پارکینسونیسم یعنی برادی‌کینزی و ریژیدیتی در معاینه هست. حالا به گزینه‌ها نگاه کنید: هر سه گزینه‌ی دیگر بیماری‌هایی هستند که علائم حرکتی دارند، پس سؤال عمداً روی «پارکینسونیسم» تله گذاشته است. کلید افتراق، دو عنصر دیگر است: فقط دمانس با اجسام لویی است که نوسان شناختی و توهم بینایی زودرس را با هم دارد.",
 "explanation_en": "The stem gives four elements and all four converge on one diagnosis. Cognitive fluctuation means the patient is lucid at some hours and confused at others. Absent early amnesia means the pattern differs from Alzheimer disease. Well-formed visual hallucinations mean the patient sees detailed people or animals. And parkinsonism means bradykinesia and rigidity on examination. Now look at the options: all three alternatives are diseases with motor features, so the question deliberately baits you with parkinsonism. The discriminating key is the other two elements: only dementia with Lewy bodies combines cognitive fluctuation with early visual hallucinations.",
 "why_fa": [
  "هانتینگتون با کره یعنی حرکات پرشی و رقصان مشخص می‌شود، نه پارکینسونیسم. سابقه‌ی خانوادگی اتوزومال غالب هم دارد که در صورت سؤال نیامده است.",
  "پاسخ صحیح — نوسان شناختی، توهم بینایی شکل‌یافته و پارکینسونیسم با هم امضای دمانس با اجسام لویی است.",
  "فلج فوق هسته‌ای پیشرونده با زمین‌خوردن‌های زودرس به عقب و ناتوانی در نگاه عمودی به پایین شناخته می‌شود. توهم بینایی و نوسان شناختی از ویژگی‌های آن نیست.",
  "دمانس عروقی سیر پله‌ای دارد و با علائم فوکال و سابقه‌ی سکته همراه است. نوسان آن با نوسان لوی بادی فرق دارد و توهم شکل‌یافته‌ی زودرس ندارد."
 ],
 "why_en": [
  "Huntington disease is marked by chorea, that is jerky dancing movements, not parkinsonism. It also has an autosomal dominant family history, absent from the stem.",
  "Correct — cognitive fluctuation, well-formed visual hallucinations and parkinsonism together are the signature of dementia with Lewy bodies.",
  "Progressive supranuclear palsy is known for early backward falls and inability to look down. Visual hallucinations and cognitive fluctuation are not its features.",
  "Vascular dementia declines stepwise with focal signs and a stroke history. Its fluctuation differs from that of Lewy body disease and it lacks early formed hallucinations."
 ],
 "golden_fa": "نوسان + توهم بینایی + پارکینسونیسم = لوی بادی. زمین‌خوردن + نگاه عمودی = PSP.",
 "golden_en": "Fluctuation plus visual hallucinations plus parkinsonism means Lewy body. Falls plus vertical gaze palsy means PSP.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 5: Dementia, differential diagnosis",
  "McKeith IG et al. Diagnosis and management of dementia with Lewy bodies: fourth consensus report. Neurology 2017;89:88-100"
 ]
}

L["1399-12:116"] = {
 "stem_en": "A child presents with sudden brief episodes of impaired consciousness without loss of limb control, lasting a few seconds and repeating many times a day. The EEG shows bilateral spike-wave discharges at three per second. Which drug is recommended?",
 "options_en": ["Gabapentin", "Carbamazepine", "Ethosuximide", "Phenytoin"],
 "micro": {
  "lead_fa": "امواج سه هرتز اسپایک-موج منتشر در کودک، یعنی صرع غیاب و داروی آن اتوسوکسیماید است.",
  "lead_en": "Generalised three-hertz spike-and-wave in a child means absence epilepsy, treated with ethosuximide.",
  "points_fa": [
   "صرع غیاب کودکی معمولاً بین چهار تا ده سالگی شروع می‌شود.",
   "هر حمله فقط پنج تا پانزده ثانیه طول می‌کشد و بیمار خیره و بی‌حرکت می‌ماند.",
   "بیمار نمی‌افتد و تون عضلانی را از دست نمی‌دهد، پس با تشنج تونیک اشتباه نمی‌شود.",
   "پس از حمله هیچ گیجی وجود ندارد و کودک بلافاصله فعالیت را ادامه می‌دهد.",
   "حملات ممکن است ده‌ها بار در روز تکرار شوند و افت تحصیلی بسازند.",
   "سه دقیقه تنفس عمیق سریع اغلب حمله را در مطب راه می‌اندازد.",
   "نوار مغزی الگوی کاملاً مشخصی دارد: اسپایک-موج منتشر و قرینه با فرکانس سه هرتز.",
   "اتوسوکسیماید با مهار کانال کلسیم نوع T در تالاموس این مدار را قطع می‌کند.",
   "کاربامازپین، فنی‌توئین و گاباپنتین حملات غیاب را تشدید می‌کنند و ممنوع‌اند."
  ],
  "points_en": [
   "Childhood absence epilepsy usually starts between four and ten years of age.",
   "Each attack lasts only five to fifteen seconds with the child staring and motionless.",
   "The child does not fall and does not lose muscle tone, so it is not confused with a tonic seizure.",
   "There is no postictal confusion and the child resumes activity immediately.",
   "Attacks may repeat dozens of times a day and cause school underachievement.",
   "Three minutes of rapid deep breathing often provokes an attack in the clinic.",
   "The EEG pattern is completely characteristic: generalised symmetric three-hertz spike-and-wave.",
   "Ethosuximide blocks T-type calcium channels in the thalamus and interrupts this circuit.",
   "Carbamazepine, phenytoin and gabapentin aggravate absence seizures and are contraindicated."
  ]
 },
 "explanation_fa": "صورت سؤال یک تصویر بالینی و یک یافته‌ی پاراکلینیک می‌دهد که هر دو منحصربه‌فردند. تصویر بالینی: اختلال هوشیاری ناگهانی، بسیار کوتاه، بدون افتادن و بدون گیجی بعدی، ده‌ها بار در روز. یافته‌ی نوار مغز: اسپایک-موج دوطرفه با فرکانس سه در ثانیه. این الگوی نواری تقریباً مساوی تشخیص صرع غیاب است. حالا نکته‌ی خطرناک بالینی: سه گزینه‌ی دیگر داروهایی هستند که کانال سدیم را مهار می‌کنند و همگی صرع غیاب را نه‌تنها درمان نمی‌کنند بلکه بدتر می‌کنند. دلیلش این است که مکانیسم غیاب از مدار تالاموکورتیکال و کانال کلسیم نوع T می‌آید، نه از کانون کانال سدیمی. اتوسوکسیماید دقیقاً همان کانال کلسیم را می‌بندد.",
 "explanation_en": "The stem gives one clinical picture and one paraclinical finding, both unique. Clinical picture: sudden, very brief impairment of consciousness, no fall, no postictal confusion, dozens of times a day. EEG finding: bilateral spike-and-wave at three per second. That EEG pattern is nearly equivalent to the diagnosis of absence epilepsy. Now the dangerous clinical point: the other three options are sodium channel blockers, and all of them not only fail to treat absence seizures but make them worse. The reason is that absence arises from the thalamocortical circuit and T-type calcium channels, not from a sodium-channel focus. Ethosuximide closes exactly that calcium channel.",
 "why_fa": [
  "گاباپنتین برای درد نوروپاتیک و تشنج فوکال به کار می‌رود و در صرع‌های ژنرالیزه‌ی اولیه از جمله غیاب می‌تواند حملات را تشدید کند.",
  "کاربامازپین در تشنج فوکال بسیار مؤثر است اما در صرع غیاب ممنوع است و می‌تواند تعداد حملات را چند برابر کند.",
  "پاسخ صحیح — اتوسوکسیماید کانال کلسیم نوع T نورون‌های تالاموس را مهار می‌کند و در مطالعه‌ی مقایسه‌ای، بهترین تعادل اثربخشی و تحمل‌پذیری را در صرع غیاب داشت.",
  "فنی‌توئین مثل کاربامازپین مسدودکننده‌ی کانال سدیم است و در صرع غیاب اثری ندارد و می‌تواند آن را بدتر کند."
 ],
 "why_en": [
  "Gabapentin is used for neuropathic pain and focal seizures and can aggravate primary generalised epilepsies including absence.",
  "Carbamazepine is highly effective in focal seizures but is contraindicated in absence epilepsy and can multiply attack frequency.",
  "Correct — ethosuximide inhibits T-type calcium channels in thalamic neurons and, in the head-to-head trial, gave the best balance of efficacy and tolerability in absence epilepsy.",
  "Phenytoin, like carbamazepine, is a sodium channel blocker; it is ineffective in absence epilepsy and can worsen it."
 ],
 "golden_fa": "سه هرتز اسپایک-موج = غیاب = اتوسوکسیماید. کاربامازپین و فنی‌توئین آن را بدتر می‌کنند.",
 "golden_en": "Three-hertz spike-and-wave means absence, treated with ethosuximide. Carbamazepine and phenytoin make it worse.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 12: Absence seizures",
  "Glauser TA et al. Ethosuximide, valproic acid, and lamotrigine in childhood absence epilepsy. N Engl J Med 2010;362:790-9"
 ]
}

L["1399-12:117"] = {
 "stem_en": "A 35-year-old woman in the first week after delivery develops severe headache, seizures, reduced consciousness and papilloedema. MRI shows bilateral thalamic signal change resembling two beans stuck together. What is the most likely diagnosis?",
 "options_en": ["Vertebral artery thrombosis", "Deep cerebral vein thrombosis",
                "Idiopathic intracranial hypertension", "Middle cerebral artery embolism"],
 "micro": {
  "lead_fa": "تغییر سیگنال قرینه در هر دو تالاموس، امضای انفارکت وریدی سیستم عمقی است.",
  "lead_en": "Symmetric signal change in both thalami is the signature of a deep venous system infarct.",
  "points_fa": [
   "سیستم وریدی عمقی مغز شامل ورید مغزی داخلی، ورید گالن و سینوس مستقیم است.",
   "این سیستم خون تالاموس، عقده‌های قاعده‌ای و ماده‌ی سفید عمقی را تخلیه می‌کند.",
   "چون تخلیه‌ی دو طرف به یک مسیر مشترک می‌رسد، انسداد آن ضایعه‌ی قرینه می‌سازد.",
   "هیچ شریانی به‌تنهایی نمی‌تواند هر دو تالاموس را همزمان و قرینه درگیر کند.",
   "پس ضایعه‌ی دوطرفه‌ی تالاموس تا خلاف آن ثابت نشود، وریدی است.",
   "دوره‌ی نفاس یکی از پرخطرترین حالت‌های پروترومبوتیک است.",
   "ترومبوز وریدی عمقی شدیدترین فرم ترومبوز وریدی مغز است و افت هوشیاری سریع دارد.",
   "تشخیص با MR ونوگرافی یا CT ونوگرافی انجام می‌شود.",
   "درمان ضدانعقاد فوری با هپارین است و در موارد وخیم ترومبولیز داخل وریدی مطرح می‌شود."
  ],
  "points_en": [
   "The deep cerebral venous system includes the internal cerebral veins, the vein of Galen and the straight sinus.",
   "It drains the thalami, basal ganglia and deep white matter.",
   "Because both sides drain into one shared channel, occlusion produces a symmetric lesion.",
   "No single artery can involve both thalami symmetrically at the same time.",
   "So a bilateral thalamic lesion is venous until proven otherwise.",
   "The puerperium is one of the most prothrombotic states.",
   "Deep venous thrombosis is the most severe form of cerebral venous thrombosis, with rapid loss of consciousness.",
   "Diagnosis is by MR venography or CT venography.",
   "Treatment is immediate anticoagulation with heparin, with endovascular thrombolysis considered in critical cases."
  ]
 },
 "explanation_fa": "این سؤال یک نکته‌ی آناتومیک را به یک تصویر رادیولوژیک گره می‌زند. توصیف «دو لوبیای به هم چسبیده در تالاموس» یعنی هر دو تالاموس قرینه درگیر شده‌اند. حالا از خودتان بپرسید کدام انسداد عروقی می‌تواند چنین الگویی بسازد. شریان‌های مغزی هر کدام یک نیمکره را می‌دهند، پس انسداد شریانی معمولاً یک‌طرفه است. اما سیستم وریدی عمقی متفاوت است: وریدهای مغزی داخلی از دو طرف به هم می‌رسند و در ورید گالن یکی می‌شوند. اگر این مسیر مشترک بسته شود، هر دو تالاموس همزمان دچار احتقان و انفارکت می‌شوند. زمینه هم کاملاً می‌خواند: هفته‌ی اول پس از زایمان از پروترومبوتیک‌ترین دوره‌های زندگی است.",
 "explanation_en": "This item ties an anatomical point to a radiological image. The description of two beans stuck together in the thalamus means both thalami are symmetrically involved. Now ask which vascular occlusion can produce that pattern. Each cerebral artery supplies one hemisphere, so arterial occlusion is usually unilateral. The deep venous system is different: the internal cerebral veins from both sides converge into the vein of Galen. If that shared channel occludes, both thalami become congested and infarcted at once. The setting fits perfectly too: the first week postpartum is one of the most prothrombotic periods of life.",
 "why_fa": [
  "ترومبوز شریان ورتبرال ساقه‌ی مغز و مخچه را درگیر می‌کند و علائم کرانیال و آتاکسی می‌دهد، نه ضایعه‌ی قرینه‌ی تالاموس.",
  "پاسخ صحیح — انسداد سیستم وریدی عمقی هر دو تالاموس را همزمان درگیر می‌کند. زمینه‌ی نفاس، تشنج و افت هوشیاری هم کاملاً سازگار است.",
  "افزایش فشار داخل جمجمه ایدیوپاتیک ضایعه‌ی پارانشیمی نمی‌سازد. در آن MRI جز نشانه‌های غیرمستقیم فشار بالا، پارانشیم طبیعی است.",
  "آمبولی شریان مغزی میانی ضایعه‌ی یک‌طرفه در قشر و عقده‌های قاعده‌ای می‌دهد و همی‌پارزی و آفازی می‌سازد، نه درگیری قرینه‌ی تالاموس."
 ],
 "why_en": [
  "Vertebral artery thrombosis involves the brainstem and cerebellum, causing cranial nerve signs and ataxia, not a symmetric thalamic lesion.",
  "Correct — occlusion of the deep venous system involves both thalami simultaneously. The puerperal setting, seizures and reduced consciousness all fit.",
  "Idiopathic intracranial hypertension does not create parenchymal lesions. Apart from indirect signs of raised pressure, the MRI parenchyma is normal.",
  "Middle cerebral artery embolism gives a unilateral cortical and basal ganglia lesion with hemiparesis and aphasia, not symmetric thalamic involvement."
 ],
 "golden_fa": "تالاموس دوطرفه و قرینه = وریدی تا خلافش ثابت شود. نفاس = پروترومبوتیک.",
 "golden_en": "Bilateral symmetric thalami mean venous until proven otherwise; the puerperium is prothrombotic.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 13: Deep cerebral venous thrombosis",
  "Saposnik G et al. Diagnosis and management of cerebral venous thrombosis: AHA/ASA statement. Stroke 2011;42:1158-92"
 ]
}

L["1399-12:118"] = {
 "stem_en": "In a patient diagnosed with Guillain-Barre syndrome, which cerebrospinal fluid finding is expected?",
 "options_en": ["Low glucose", "Lymphocytes above 100", "Low LDH", "High protein"],
 "micro": {
  "lead_fa": "پروتئین بالا با سلول طبیعی، همان جدایی آلبومینوسیتولوژیک کلاسیک گیلن باره است.",
  "lead_en": "High protein with a normal cell count is the classic albuminocytological dissociation of Guillain-Barre syndrome.",
  "points_fa": [
   "گیلن باره پلی‌رادیکولونوروپاتی حاد التهابی و با واسطه‌ی ایمنی است.",
   "معمولاً یک تا سه هفته پس از یک عفونت تنفسی یا گوارشی شروع می‌شود.",
   "کامپیلوباکتر ژژونی شایع‌ترین عامل محرک شناخته‌شده است.",
   "ضعف صعودی و قرینه است و رفلکس‌های وتری زود از بین می‌روند.",
   "التهاب در ریشه‌های عصبی، سد خون-عصب را نشت‌پذیر می‌کند.",
   "پروتئین از ریشه‌های ملتهب به مایع نخاعی نشت می‌کند و مقدارش بالا می‌رود.",
   "اما التهاب سلولی نیست، پس شمارش سلول مایع نخاعی طبیعی می‌ماند.",
   "این ترکیب را جدایی آلبومینوسیتولوژیک می‌نامند و در هفته‌ی اول ممکن است هنوز دیده نشود.",
   "قند مایع نخاعی طبیعی است؛ کاهش آن مننژیت باکتریال یا سلی را مطرح می‌کند."
  ],
  "points_en": [
   "Guillain-Barre syndrome is an acute inflammatory immune-mediated polyradiculoneuropathy.",
   "It usually begins one to three weeks after a respiratory or gastrointestinal infection.",
   "Campylobacter jejuni is the commonest recognised trigger.",
   "Weakness is ascending and symmetric and tendon reflexes disappear early.",
   "Inflammation at the nerve roots makes the blood-nerve barrier leaky.",
   "Protein leaks from the inflamed roots into the cerebrospinal fluid and its level rises.",
   "But the inflammation is not cellular, so the CSF cell count stays normal.",
   "This combination is called albuminocytological dissociation and may be absent in the first week.",
   "CSF glucose is normal; a low glucose suggests bacterial or tuberculous meningitis."
  ]
 },
 "explanation_fa": "برای پاسخ به این سؤال باید بدانید مکانیسم بیماری چگونه ترکیب مایع نخاعی را عوض می‌کند. در گیلن باره، پاسخ ایمنی به میلین ریشه‌های عصبی حمله می‌کند. این التهاب موضعی سد خون-عصب را نشت‌پذیر می‌کند، پس پروتئین پلاسما به فضای زیرعنکبوتیه راه پیدا می‌کند و غلظت پروتئین مایع نخاعی بالا می‌رود. اما این التهاب با هجوم گلبول سفید به مایع همراه نیست، پس شمارش سلول‌ها طبیعی می‌ماند. همین تفکیک، یعنی پروتئین بالا با سلول طبیعی، جدایی آلبومینوسیتولوژیک نام دارد. یک نکته‌ی عملی مهم: این یافته ممکن است در هفته‌ی اول بیماری هنوز ظاهر نشده باشد، پس نتیجه‌ی طبیعی در روزهای نخست تشخیص را رد نمی‌کند.",
 "explanation_en": "To answer this you need to know how the disease mechanism changes the CSF composition. In Guillain-Barre syndrome the immune response attacks the myelin of nerve roots. This local inflammation makes the blood-nerve barrier leaky, so plasma protein reaches the subarachnoid space and the CSF protein concentration rises. But the inflammation does not bring white cells into the fluid, so the cell count remains normal. That dissociation, high protein with a normal cell count, is called albuminocytological dissociation. One practical point: the finding may not yet be present in the first week, so a normal result in the early days does not exclude the diagnosis.",
 "why_fa": [
  "کاهش قند مایع نخاعی نشانه‌ی مصرف قند توسط باکتری یا سلول‌های التهابی است و مننژیت باکتریال، سلی یا قارچی را مطرح می‌کند. در گیلن باره قند طبیعی است.",
  "افزایش لنفوسیت بالای صد به نفع مننژیت ویروسی یا سلی است. اگر در بیمار مشکوک به گیلن باره سلول بالا دیدید، باید به HIV یا لنفوم یا بیماری لایم فکر کنید.",
  "کاهش LDH در مایع نخاعی یافته‌ی تعریف‌شده‌ای در گیلن باره نیست و در ارزیابی روتین این بیماری اندازه‌گیری نمی‌شود.",
  "پاسخ صحیح — نشت پروتئین از ریشه‌های ملتهب، پروتئین مایع نخاعی را بالا می‌برد در حالی که شمارش سلول طبیعی می‌ماند."
 ],
 "why_en": [
  "Low CSF glucose reflects consumption by bacteria or inflammatory cells and suggests bacterial, tuberculous or fungal meningitis. In Guillain-Barre syndrome glucose is normal.",
  "Lymphocytes above one hundred favour viral or tuberculous meningitis. If you see a high cell count in suspected Guillain-Barre syndrome, think of HIV, lymphoma or Lyme disease.",
  "A low CSF LDH is not a defined finding in Guillain-Barre syndrome and is not measured in its routine workup.",
  "Correct — protein leaking from the inflamed roots raises CSF protein while the cell count stays normal."
 ],
 "golden_fa": "پروتئین بالا + سلول طبیعی = جدایی آلبومینوسیتولوژیک = گیلن باره.",
 "golden_en": "High protein plus normal cells means albuminocytological dissociation, the hallmark of Guillain-Barre syndrome.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 9: Guillain-Barre syndrome",
  "Willison HJ, Jacobs BC, van Doorn PA. Guillain-Barre syndrome. Lancet 2016;388:717-27"
 ]
}

L["1400-06:114"] = {
 "stem_en": "A 45-year-old man reports that after coughing or sneezing he develops a bilateral pressing headache lasting about 30 minutes and then resolving. The headache is not throbbing and has no nausea or vomiting. His neurological examination is normal. What do you recommend as the next step?",
 "options_en": ["Lumbar puncture with pressure measurement", "Brain MRI",
                "Start amitriptyline and titrate up until symptoms are controlled",
                "Give naproxen when the headache occurs"],
 "micro": {
  "lead_fa": "سردرد سرفه‌ای پیش از هر درمانی باید تصویربرداری شود، چون ممکن است ثانویه باشد.",
  "lead_en": "A cough headache must be imaged before any treatment, because it may be secondary.",
  "points_fa": [
   "سردرد سرفه‌ای سردردی است که با سرفه، عطسه، زور زدن یا خم شدن راه می‌افتد.",
   "این سردردها به دو دسته‌ی اولیه و ثانویه تقسیم می‌شوند.",
   "فرم اولیه خوش‌خیم است و معمولاً در مردان بالای چهل سال دیده می‌شود.",
   "فرم ثانویه در حدود چهل درصد موارد است و همیشه باید رد شود.",
   "شایع‌ترین علت ثانویه ناهنجاری کیاری نوع یک است، یعنی فتق لوزه‌های مخچه.",
   "علل دیگر: تومورهای حفره‌ی خلفی، هیدروسفالی و آنوریسم.",
   "سرفه فشار داخل شکم و قفسه‌ی سینه را بالا می‌برد و فشار مایع نخاعی را منتقل می‌کند.",
   "اگر مسیر جریان مایع نخاعی تنگ باشد، این فشار درد می‌سازد.",
   "MRI مغز با تمرکز بر محل اتصال جمجمه و گردن، تصویربرداری انتخابی است."
  ],
  "points_en": [
   "Cough headache is a headache triggered by coughing, sneezing, straining or bending.",
   "These headaches fall into primary and secondary groups.",
   "The primary form is benign and usually seen in men over forty.",
   "The secondary form accounts for about forty percent of cases and must always be excluded.",
   "The commonest secondary cause is Chiari type one malformation, herniation of the cerebellar tonsils.",
   "Other causes: posterior fossa tumours, hydrocephalus and aneurysm.",
   "Coughing raises intra-abdominal and intrathoracic pressure, which is transmitted to the CSF.",
   "If the CSF flow pathway is narrowed, that pressure produces pain.",
   "Brain MRI focused on the craniocervical junction is the imaging of choice."
  ]
 },
 "explanation_fa": "این سؤال یک اصل کلی سردردشناسی را می‌آزماید: هر سردردی که با مانور والسالوا راه بیفتد، تا رد شدن علت ساختاری، ثانویه فرض می‌شود. حتی اگر معاینه‌ی عصبی کاملاً طبیعی باشد، نمی‌توان ناهنجاری کیاری یا تومور حفره‌ی خلفی را رد کرد، چون این ضایعات ممکن است تا مدت‌ها علامت فوکال ندهند. پس اقدام بعدی درمان نیست، تصویربرداری است. دو گزینه‌ی درمانی که مطرح شده‌اند، آمی‌تریپتیلین و ناپروکسن، هر دو برای فرم اولیه‌ی خوش‌خیم منطقی‌اند اما زودهنگام‌اند و می‌توانند تشخیص یک ضایعه‌ی قابل درمان را ماه‌ها به تأخیر بیندازند. پونکسیون کمری هم پیش از تصویربرداری خطرناک است، چون اگر ضایعه‌ی فضاگیر حفره‌ی خلفی وجود داشته باشد خطر فتق مغزی دارد.",
 "explanation_en": "This item tests a general headache principle: any headache triggered by a Valsalva manoeuvre is assumed secondary until a structural cause is excluded. Even a completely normal neurological examination cannot rule out a Chiari malformation or a posterior fossa tumour, because such lesions may give no focal signs for a long time. So the next step is not treatment but imaging. The two treatment options offered, amitriptyline and naproxen, are both reasonable for the benign primary form but are premature and could delay diagnosis of a treatable lesion by months. Lumbar puncture before imaging is also dangerous, because a posterior fossa mass would create a risk of herniation.",
 "why_fa": [
  "پونکسیون کمری پیش از تصویربرداری در سردرد سرفه‌ای خطرناک است. اگر ضایعه‌ی فضاگیر حفره‌ی خلفی وجود داشته باشد، برداشت مایع می‌تواند فتق لوزه‌های مخچه را تسریع کند.",
  "پاسخ صحیح — MRI مغز با توجه به محل اتصال جمجمه و گردن، ناهنجاری کیاری و ضایعات حفره‌ی خلفی را نشان می‌دهد و پیش‌شرط هر تصمیم درمانی است.",
  "آمی‌تریپتیلین برای سردرد تنشی مزمن و پیشگیری میگرن کاربرد دارد. تجویز آن پیش از رد کردن علت ساختاری، تشخیص را به تأخیر می‌اندازد.",
  "ناپروکسن در فرم اولیه‌ی سردرد سرفه‌ای مؤثر است و ایندومتاسین هم گزینه‌ی خوبی است، اما فقط پس از آنکه MRI طبیعی باشد."
 ],
 "why_en": [
  "Lumbar puncture before imaging is dangerous in cough headache. If a posterior fossa mass is present, removing fluid can precipitate tonsillar herniation.",
  "Correct — brain MRI with attention to the craniocervical junction shows Chiari malformation and posterior fossa lesions and is a prerequisite for any treatment decision.",
  "Amitriptyline is used for chronic tension headache and migraine prevention. Prescribing it before excluding a structural cause delays the diagnosis.",
  "Naproxen is effective in primary cough headache and indomethacin is also a good option, but only after the MRI proves normal."
 ],
 "golden_fa": "سردرد با سرفه و زور زدن = اول MRI، بعد درمان. کیاری یک را از قلم نیندازید.",
 "golden_en": "Headache on coughing or straining means MRI first, treatment later. Do not miss Chiari type one.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 6: Cough headache and secondary headache",
  "Pascual J, Gonzalez-Mandly A et al. Headaches precipitated by cough, prolonged exercise or sexual activity. J Headache Pain 2008;9:259-66"
 ]
}

L["1400-06:115"] = {
 "stem_en": "A 30-year-old man presents with severe progressive weakness of all four limbs since last week. On examination he has bilateral peripheral facial nerve palsy with generalised areflexia. CSF shows high protein with no cells. Given the likely diagnosis, which treatment is NOT appropriate?",
 "options_en": ["Prednisolone", "IVIG", "Plasmapheresis", "Heparin for DVT prophylaxis"],
 "micro": {
  "lead_fa": "کورتیکواستروئید در گیلن باره بی‌اثر است و کارآزمایی‌ها این را روشن نشان داده‌اند.",
  "lead_en": "Corticosteroids are ineffective in Guillain-Barre syndrome, as trials have clearly shown.",
  "points_fa": [
   "گیلن باره با ضعف صعودی قرینه، آرفلکسی و جدایی آلبومینوسیتولوژیک شناخته می‌شود.",
   "فلج صورت دوطرفه یکی از شایع‌ترین درگیری‌های عصب کرانیال در این بیماری است.",
   "دو درمان اختصاصی مؤثر وجود دارد: ایمونوگلوبولین وریدی و پلاسمافرز.",
   "این دو اثر یکسانی دارند و ترکیبشان مزیت اضافه‌ای ندارد.",
   "شروع درمان در دو هفته‌ی اول بیشترین سود را دارد.",
   "کورتیکواستروئید در کارآزمایی‌های تصادفی هیچ سودی نشان نداد و ممکن است بهبود را کند کند.",
   "این نکته گیلن باره را از فرم مزمن یعنی CIDP جدا می‌کند که به استروئید پاسخ می‌دهد.",
   "مراقبت حمایتی حیاتی است: پایش ظرفیت حیاتی ریه و ریتم قلب.",
   "بی‌حرکتی خطر ترومبوز ورید عمقی را بالا می‌برد، پس پروفیلاکسی هپارین لازم است."
  ],
  "points_en": [
   "Guillain-Barre syndrome is recognised by ascending symmetric weakness, areflexia and albuminocytological dissociation.",
   "Bilateral facial palsy is one of the commonest cranial nerve involvements in this disease.",
   "Two effective specific treatments exist: intravenous immunoglobulin and plasmapheresis.",
   "They are equally effective and combining them adds no benefit.",
   "Starting treatment within the first two weeks gives the greatest benefit.",
   "Corticosteroids showed no benefit in randomised trials and may even slow recovery.",
   "This point separates Guillain-Barre syndrome from its chronic form CIDP, which does respond to steroids.",
   "Supportive care is vital: monitor vital capacity and cardiac rhythm.",
   "Immobility raises deep vein thrombosis risk, so heparin prophylaxis is needed."
  ]
 },
 "explanation_fa": "ابتدا تشخیص را قطعی کنید: ضعف پیش‌رونده‌ی چهار اندام طی یک هفته، فلج صورت دوطرفه، آرفلکسی منتشر و پروتئین بالای مایع نخاعی بدون سلول. این چهار یافته با هم فقط یک تشخیص می‌سازند و آن گیلن باره است. حالا سؤال می‌پرسد کدام درمان مناسب نیست. سه گزینه بخشی از مراقبت استاندارد‌اند: ایمونوگلوبولین وریدی و پلاسمافرز دو درمان اختصاصی مؤثرند و هپارین برای پیشگیری از ترومبوز در بیمار بی‌حرکت لازم است. پردنیزولون اما استثناست. کارآزمایی‌های تصادفی نشان داده‌اند کورتیکواستروئید در گیلن باره سودی ندارد و حتی ممکن است سرعت بهبود را کم کند. این یکی از نکاتی است که دانشجویان زیاد اشتباه می‌کنند، چون در بیشتر بیماری‌های خودایمنی عصبی استروئید کار می‌کند.",
 "explanation_en": "First settle the diagnosis: progressive weakness of all four limbs over a week, bilateral facial palsy, generalised areflexia and high CSF protein without cells. Those four findings together allow only one diagnosis, Guillain-Barre syndrome. Now the question asks which treatment is inappropriate. Three options are part of standard care: intravenous immunoglobulin and plasmapheresis are the two effective specific treatments, and heparin prevents thrombosis in an immobile patient. Prednisolone is the exception. Randomised trials have shown corticosteroids give no benefit in Guillain-Barre syndrome and may even slow recovery. This is a frequently missed point, because steroids work in most other autoimmune neurological diseases.",
 "why_fa": [
  "پاسخ صحیح (گزینه‌ی نامناسب) — پردنیزولون و سایر کورتیکواستروئیدها در گیلن باره بی‌اثرند. کاکرین نشان داده استروئید خوراکی حتی می‌تواند بهبود را کندتر کند.",
  "ایمونوگلوبولین وریدی با دوز دو گرم بر کیلوگرم طی پنج روز، یکی از دو درمان اختصاصی مؤثر است و معمولاً به دلیل سهولت اجرا ترجیح داده می‌شود.",
  "پلاسمافرز اثری معادل ایمونوگلوبولین دارد و آنتی‌بادی‌های مهاجم را از گردش خون خارج می‌کند. در دو هفته‌ی اول بیشترین سود را دارد.",
  "هپارین پروفیلاکسی در بیمار بستری و بی‌حرکت با ضعف شدید اندام‌ها ضروری است، چون خطر ترومبوز ورید عمقی و آمبولی ریه بالاست."
 ],
 "why_en": [
  "Correct answer (the inappropriate option) — prednisolone and other corticosteroids are ineffective in Guillain-Barre syndrome. Cochrane evidence shows oral steroids may even slow recovery.",
  "Intravenous immunoglobulin at two grams per kilogram over five days is one of the two effective specific treatments and is usually preferred for ease of administration.",
  "Plasmapheresis is equivalent to immunoglobulin and removes the offending antibodies from the circulation. It gives the greatest benefit in the first two weeks.",
  "Heparin prophylaxis is essential in an immobile inpatient with severe limb weakness, because deep vein thrombosis and pulmonary embolism risk is high."
 ],
 "golden_fa": "گیلن باره: IVIG یا پلاسمافرز، هرگز کورتیکواستروئید. CIDP برعکس به استروئید پاسخ می‌دهد.",
 "golden_en": "Guillain-Barre: IVIG or plasmapheresis, never corticosteroids. CIDP is the opposite and responds to steroids.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 9: Guillain-Barre syndrome, management",
  "Hughes RAC, Brassington R et al. Corticosteroids for Guillain-Barre syndrome. Cochrane Database Syst Rev 2016;10:CD001446"
 ]
}

L["1400-06:116"] = {
 "stem_en": "A 30-year-old woman taking an oral contraceptive pill comes to the emergency department with headache, vomiting and a focal seizure. Examination shows papilloedema. What are the diagnosis and treatment respectively?",
 "options_en": ["SAH, phenytoin", "CVST, anticoagulation", "SDH, craniectomy",
                "PRES (posterior reversible encephalopathy), blood pressure control and phenytoin"],
 "micro": {
  "lead_fa": "پس از تشخیص ترومبوز وریدی، درمان ضدانعقاد است حتی اگر خون‌ریزی وریدی هم وجود داشته باشد.",
  "lead_en": "Once venous thrombosis is diagnosed, treatment is anticoagulation even when a venous haemorrhage is present.",
  "points_fa": [
   "این سؤال دو مرحله دارد: تشخیص و سپس درمان، و باید هر دو درست باشند.",
   "قرص ضدبارداری استروژن‌دار خطر ترومبوز وریدی مغز را چند برابر می‌کند.",
   "سه‌گانه‌ی سردرد، تشنج و ادم پاپی در زن جوان، ترومبوز وریدی را در صدر می‌گذارد.",
   "تشنج فوکال به این دلیل رخ می‌دهد که احتقان وریدی قشر را تحریک‌پذیر می‌کند.",
   "درمان استاندارد هپارین وریدی یا هپارین با وزن مولکولی کم است.",
   "نکته‌ی کلیدی: وجود انفارکت خون‌ریزی‌دهنده منع مصرف ضدانعقاد نیست.",
   "دلیلش این است که مشکل اصلی انسداد جریان خروجی است و باید باز شود.",
   "پس از فاز حاد، ضدانعقاد خوراکی سه تا دوازده ماه ادامه می‌یابد.",
   "درمان ضدتشنج فقط در صورت بروز تشنج داده می‌شود، نه به‌صورت پیشگیرانه‌ی روتین."
  ],
  "points_en": [
   "This item has two steps, diagnosis then treatment, and both must be right.",
   "Estrogen-containing oral contraceptives multiply the risk of cerebral venous thrombosis.",
   "The triad of headache, seizure and papilloedema in a young woman puts venous thrombosis first.",
   "The focal seizure occurs because venous congestion makes the cortex irritable.",
   "Standard treatment is intravenous heparin or low molecular weight heparin.",
   "Key point: a haemorrhagic infarct is not a contraindication to anticoagulation.",
   "The reason is that the underlying problem is outflow obstruction, which must be relieved.",
   "After the acute phase, oral anticoagulation continues for three to twelve months.",
   "Antiseizure treatment is given only if a seizure has occurred, not as routine prophylaxis."
  ]
 },
 "explanation_fa": "این سؤال از نوع دو ستونی است، یعنی باید هم تشخیص و هم درمان درست باشد و یک اشتباه در هر ستون گزینه را باطل می‌کند. تشخیص روشن است: زن جوان با قرص ضدبارداری، سردرد، استفراغ، تشنج فوکال و ادم پاپی. این ترکیب ترومبوز سینوس وریدی مغز است. حالا میان گزینه‌ها فقط یکی این تشخیص را دارد و درمانش هم درست است. نکته‌ی آموزشی مهم که باید به خاطر بسپارید این است: بسیاری از دانشجویان می‌ترسند در بیماری که ممکن است انفارکت خون‌ریزی‌دهنده داشته باشد ضدانعقاد بدهند. اما در ترومبوز وریدی این ترس نابجاست. مشکل اصلی بسته بودن راه خروج خون است و تا آن باز نشود، احتقان و خون‌ریزی بیشتر می‌شود. مطالعات نشان داده‌اند هپارین حتی در حضور خون‌ریزی ایمن است.",
 "explanation_en": "This is a two-column item: both the diagnosis and the treatment must be right, and one error in either column invalidates the option. The diagnosis is clear: a young woman on an oral contraceptive with headache, vomiting, a focal seizure and papilloedema. That combination is cerebral venous sinus thrombosis. Only one option carries that diagnosis with the right treatment. The important teaching point to remember is this: many students hesitate to anticoagulate a patient who may have a haemorrhagic infarct. In venous thrombosis that fear is misplaced. The underlying problem is a blocked outflow, and until it is opened the congestion and bleeding get worse. Studies show heparin is safe even with haemorrhage present.",
 "why_fa": [
  "خون‌ریزی زیرعنکبوتیه با سردرد رعدآسای ناگهانی شروع می‌شود، نه با سیر تدریجی. ضمناً فنی‌توئین درمان آن نیست و درمان اصلی بستن آنوریسم است.",
  "پاسخ صحیح — تشخیص ترومبوز سینوس وریدی مغز است و درمان آن ضدانعقاد با هپارین، حتی در حضور انفارکت خون‌ریزی‌دهنده.",
  "هماتوم ساب‌دورال نیاز به سابقه‌ی ضربه دارد و در زن جوان بدون تروما بسیار نامحتمل است. ادم پاپی دوطرفه هم الگوی معمول آن نیست.",
  "سندرم انسفالوپاتی خلفی برگشت‌پذیر با فشار خون بسیار بالا، اختلال بینایی و ضایعات اکسیپیتال در MRI همراه است. صورت سؤال هیچ اشاره‌ای به فشار خون بالا ندارد."
 ],
 "why_en": [
  "Subarachnoid haemorrhage begins with a sudden thunderclap headache, not a gradual course. Phenytoin is also not its treatment; securing the aneurysm is.",
  "Correct — the diagnosis is cerebral venous sinus thrombosis and the treatment is heparin anticoagulation, even with a haemorrhagic infarct.",
  "Subdural haematoma requires a history of trauma and is very unlikely in a young woman without injury. Bilateral papilloedema is also not its usual pattern.",
  "Posterior reversible encephalopathy syndrome comes with very high blood pressure, visual disturbance and occipital lesions on MRI. The stem mentions no hypertension."
 ],
 "golden_fa": "CVT = هپارین، حتی با خون‌ریزی. راه خروج بسته را باید باز کرد.",
 "golden_en": "CVT means heparin, even with haemorrhage: the blocked outflow must be reopened.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 13: Cerebral venous thrombosis, treatment",
  "Ferro JM, Bousser MG et al. European Stroke Organisation guideline for cerebral venous thrombosis. Eur J Neurol 2017;24:1203-13"
 ]
}

L["1400-06:117"] = {
 "stem_en": "A 19-year-old patient has had one episode of generalised seizure. Which of the following is a risk factor for seizure recurrence?",
 "options_en": ["Normal neurological examination", "Postictal paralysis",
                "No family history of epilepsy", "Age under 50"],
 "micro": {
  "lead_fa": "فلج تاد نشانه‌ی ضایعه‌ی ساختاری کانونی است و خطر عود را بالا می‌برد.",
  "lead_en": "Todd paralysis indicates a focal structural lesion and raises the recurrence risk.",
  "points_fa": [
   "پس از یک تشنج بدون تحریک، احتمال عود در دو سال حدود سی تا چهل درصد است.",
   "تصمیم به شروع دارو به همین برآورد خطر عود بستگی دارد.",
   "عوامل افزاینده‌ی خطر عود: ضایعه‌ی ساختاری در تصویربرداری مغز.",
   "نوار مغز غیرطبیعی با تخلیه‌های صرعی، خطر را تقریباً دو برابر می‌کند.",
   "معاینه‌ی عصبی غیرطبیعی یا سابقه‌ی آسیب مغزی قبلی هم خطر را بالا می‌برد.",
   "تشنج شبانه و شروع فوکال نیز از عوامل خطر عود هستند.",
   "فلج تاد ضعف گذرای پس از تشنج است که تا ساعت‌ها طول می‌کشد.",
   "این ضعف نشان می‌دهد تشنج کانونی بوده و احتمالاً ضایعه‌ی ساختاری وجود دارد.",
   "در مقابل، معاینه‌ی طبیعی و نوار مغز طبیعی خطر عود را پایین می‌آورد."
  ],
  "points_en": [
   "After a single unprovoked seizure, the two-year recurrence risk is about thirty to forty percent.",
   "The decision to start medication depends on this risk estimate.",
   "Factors raising recurrence risk: a structural lesion on brain imaging.",
   "An abnormal EEG with epileptiform discharges roughly doubles the risk.",
   "An abnormal neurological examination or a history of prior brain injury also raise it.",
   "Nocturnal seizures and focal onset are further recurrence risk factors.",
   "Todd paralysis is transient postictal weakness lasting up to hours.",
   "This weakness indicates the seizure was focal and a structural lesion probably exists.",
   "By contrast, a normal examination and a normal EEG lower the recurrence risk."
  ]
 },
 "explanation_fa": "این سؤال یک منطق ساده دارد: سه گزینه عوامل کاهنده‌ی خطرند و یکی افزاینده. معاینه‌ی نورولوژی طبیعی یعنی احتمالاً ضایعه‌ی ساختاری وجود ندارد، پس خطر عود کمتر است. نبود سابقه‌ی خانوادگی صرع هم خطر را پایین می‌آورد. سن زیر پنجاه سال هم به‌خودی‌خود عامل خطر نیست. اما فلج متعاقب حمله، یعنی فلج تاد، یک نشانه‌ی هشدار مهم است. چرا؟ چون این ضعف گذرا نشان می‌دهد تشنج از یک کانون مشخص در قشر حرکتی شروع شده و پس از حمله همان ناحیه موقتاً از کار افتاده است. وجود کانون یعنی به احتمال زیاد یک ضایعه‌ی ساختاری زیربنایی وجود دارد، و ضایعه‌ی ساختاری قوی‌ترین پیش‌بینی‌کننده‌ی عود تشنج است.",
 "explanation_en": "The logic here is simple: three options lower the risk and one raises it. A normal neurological examination means a structural lesion is unlikely, so recurrence risk is lower. No family history of epilepsy also lowers the risk. Age under fifty is not in itself a risk factor. But postictal paralysis, that is Todd paralysis, is an important warning sign. Why? Because this transient weakness shows the seizure began at a defined focus in the motor cortex, and after the attack that same area is temporarily non-functional. A focus means an underlying structural lesion is likely, and a structural lesion is the strongest predictor of seizure recurrence.",
 "why_fa": [
  "معاینه‌ی نورولوژیک طبیعی نشانه‌ی خوبی است و احتمال عود را کاهش می‌دهد، چون به نفع نبودن ضایعه‌ی ساختاری است.",
  "پاسخ صحیح — فلج تاد نشان می‌دهد تشنج شروع کانونی داشته و احتمال ضایعه‌ی ساختاری زمینه‌ای را بالا می‌برد. این قوی‌ترین گروه عوامل خطر عود است.",
  "عدم وجود سابقه‌ی خانوادگی صرع خطر را کم می‌کند، نه زیاد. سابقه‌ی مثبت خانوادگی است که ممکن است خطر را بالا ببرد.",
  "سن زیر پنجاه سال به‌خودی‌خود عامل خطر عود نیست. آنچه اهمیت دارد وجود یا نبود ضایعه‌ی ساختاری و یافته‌های نوار مغز است."
 ],
 "why_en": [
  "A normal neurological examination is a favourable sign and lowers recurrence risk, because it argues against a structural lesion.",
  "Correct — Todd paralysis shows the seizure had a focal onset and raises the likelihood of an underlying structural lesion, the strongest group of recurrence risk factors.",
  "Absence of a family history lowers rather than raises the risk. It is a positive family history that may increase it.",
  "Age under fifty is not itself a recurrence risk factor. What matters is the presence or absence of a structural lesion and the EEG findings."
 ],
 "golden_fa": "فلج تاد = تشنج کانونی = ضایعه‌ی ساختاری محتمل = خطر عود بالا.",
 "golden_en": "Todd paralysis means a focal seizure, a likely structural lesion and a high recurrence risk.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 12: First seizure, recurrence risk",
  "Krumholz A et al. Evidence-based guideline: management of an unprovoked first seizure in adults. Neurology 2015;84:1705-13"
 ]
}

L["1400-06:118"] = {
 "stem_en": "Which of the following symptoms is rare in multiple sclerosis?",
 "options_en": ["Paresthesia", "Aphasia", "Ataxia", "Diplopia"],
 "micro": {
  "lead_fa": "ام‌اس بیماری ماده‌ی سفید است و آفازی نیاز به آسیب قشر خاکستری زبانی دارد.",
  "lead_en": "Multiple sclerosis is a white matter disease, whereas aphasia requires damage to language cortex.",
  "points_fa": [
   "ام‌اس پلاک‌های دمیلینه در ماده‌ی سفید سیستم عصبی مرکزی می‌سازد.",
   "محل‌های محبوب پلاک‌ها: اطراف بطن‌ها، عصب اپتیک، ساقه‌ی مغز، مخچه و نخاع.",
   "علائم حسی مثل پارستزی و بی‌حسی شایع‌ترین شکایت اولیه‌اند.",
   "نوریت اپتیک با درد حرکت چشم و افت دید یک‌طرفه بسیار شایع است.",
   "دوبینی از درگیری فاسیکولوس طولی داخلی و افتالموپلژی بین‌هسته‌ای می‌آید.",
   "آتاکسی و ترمور اینتنشن از پلاک‌های مخچه و مسیرهای آن ناشی می‌شوند.",
   "خستگی، اسپاستیسیته و اختلال مثانه هم بسیار شایع‌اند.",
   "آفازی نیازمند درگیری قشر زبانی نیمکره‌ی غالب است که پلاک‌ها معمولاً آنجا نمی‌نشینند.",
   "علائم قشری مثل آفازی و تشنج در ام‌اس ممکن است ولی نادرند."
  ],
  "points_en": [
   "Multiple sclerosis produces demyelinating plaques in central nervous system white matter.",
   "Favoured plaque sites: periventricular regions, optic nerve, brainstem, cerebellum and spinal cord.",
   "Sensory symptoms such as paresthesia and numbness are the commonest initial complaints.",
   "Optic neuritis with painful eye movement and unilateral visual loss is very common.",
   "Diplopia arises from involvement of the medial longitudinal fasciculus and internuclear ophthalmoplegia.",
   "Ataxia and intention tremor come from cerebellar plaques and their pathways.",
   "Fatigue, spasticity and bladder dysfunction are also very common.",
   "Aphasia requires involvement of dominant hemisphere language cortex, where plaques rarely sit.",
   "Cortical symptoms such as aphasia and seizures are possible in multiple sclerosis but rare."
  ]
 },
 "explanation_fa": "پاسخ این سؤال از یک اصل آناتومیک می‌آید. ام‌اس در اصل بیماری ماده‌ی سفید است، یعنی به غلاف میلین آکسون‌ها حمله می‌کند. پس هر علامتی که از قطع شدن یک مسیر عصبی بیاید، در ام‌اس شایع است. پارستزی از قطع مسیرهای حسی می‌آید، دوبینی از قطع فاسیکولوس طولی داخلی در ساقه‌ی مغز، و آتاکسی از قطع مسیرهای مخچه‌ای. هر سه علامت مسیری هستند. اما آفازی فرق دارد. زبان کار شبکه‌ای از نورون‌های قشر خاکستری در نیمکره‌ی غالب است، نه کار یک مسیر سفید. پلاک‌های ام‌اس معمولاً در ماده‌ی خاکستری قشری نمی‌نشینند، بنابراین آفازی در ام‌اس نادر است. البته ضایعات قشری در ام‌اس پیشرفته گزارش شده‌اند، اما در مقایسه با سه گزینه‌ی دیگر بسیار کم‌شمارند.",
 "explanation_en": "The answer comes from an anatomical principle. Multiple sclerosis is fundamentally a white matter disease: it attacks the myelin sheath of axons. So any symptom arising from interruption of a tract is common in the disease. Paresthesia comes from interrupted sensory pathways, diplopia from interruption of the medial longitudinal fasciculus in the brainstem, and ataxia from interrupted cerebellar pathways. All three are tract symptoms. Aphasia is different. Language is the work of a network of grey matter cortical neurons in the dominant hemisphere, not of a white tract. Multiple sclerosis plaques rarely sit in cortical grey matter, so aphasia is rare. Cortical lesions have been reported in advanced disease, but they are far less frequent than the other three.",
 "why_fa": [
  "پارستزی شایع‌ترین علامت اولیه‌ی ام‌اس است و از پلاک در ستون خلفی یا مسیر اسپاینوتالامیک می‌آید.",
  "پاسخ صحیح — آفازی نیازمند درگیری قشر زبانی است و در ام‌اس که بیماری ماده‌ی سفید است نادر شمرده می‌شود.",
  "آتاکسی از پلاک‌های مخچه و پدانکول‌های آن ناشی می‌شود و همراه با ترمور اینتنشن و دیزآرتری، سه‌گانه‌ی شارکو را می‌سازد.",
  "دوبینی در ام‌اس شایع است و کلاسیک‌ترین شکل آن افتالموپلژی بین‌هسته‌ای دوطرفه در فرد جوان است که تقریباً تشخیصی است."
 ],
 "why_en": [
  "Paresthesia is the commonest initial symptom of multiple sclerosis, arising from plaques in the posterior columns or spinothalamic tract.",
  "Correct — aphasia requires language cortex involvement and is considered rare in multiple sclerosis, a white matter disease.",
  "Ataxia arises from cerebellar plaques and its peduncles and, with intention tremor and dysarthria, forms the Charcot triad.",
  "Diplopia is common in multiple sclerosis, and its most classic form, bilateral internuclear ophthalmoplegia in a young person, is nearly diagnostic."
 ],
 "golden_fa": "ام‌اس = ماده‌ی سفید. علائم مسیری شایع، علائم قشری مثل آفازی نادر.",
 "golden_en": "Multiple sclerosis is white matter: tract symptoms are common, cortical symptoms like aphasia are rare.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 7: Multiple sclerosis, clinical features",
  "Thompson AJ et al. Diagnosis of multiple sclerosis: 2017 revisions of the McDonald criteria. Lancet Neurol 2018;17:162-73"
 ]
}

json.dump(L, io.open('/home/user/work/lessons/L10.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('L10:', len(L))
