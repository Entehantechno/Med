#!/bin/bash
# Rebuild the whole post-98 expansion from scratch.
# Safe to re-run: every step is idempotent and the bank is restored from git-clean
# state by merge_new.py only adding uids that do not exist yet.
set -e
cd /home/user
echo "=== 1. build extracted question sets"
for s in rebuild_all build_batch2 build_1402_03 build_97 build_1404_06 build_1404_09 \
         build_1401_12 build_99_1400; do
  python3 work/$s.py >/dev/null
done
# Azar-97: seven of eight items already exist in the bank (verified by similarity
# check against neuro-076/239/019/227/425/172/379). Keep only q121.
python3 - <<'PY'
import json,io
p='/home/user/work/out/neuro_1397_09.json'
d=json.load(io.open(p,encoding='utf-8'))
json.dump([q for q in d if q['question_no'] not in {114,115,116,117,118,119,120}],
          io.open(p,'w',encoding='utf-8'), ensure_ascii=False, indent=1)
PY
echo "=== 2. merge questions + lessons into bank.json"
python3 work/merge_new.py | head -2
python3 work/merge_lessons.py | head -2

echo "=== 3. re-apply tool fixes (4-digit years, missing-lesson crashes)"
cd project/tools/neurology-bank
python3 - <<'PY'
import io,re
for p,subs in [
 ('normalize_meta.py',[
   ("    m = re.search(r'(' + '|'.join(MONTHS) + r')\\s*([۰-۹]{2})', src)",
    "    m = re.search(r'(' + '|'.join(MONTHS) + r')\\s*([۰-۹]{4}|[۰-۹]{2})', src)"),
   ("        y = re.search(r'([۰-۹]{2})', src)","        y = re.search(r'([۰-۹]{4}|[۰-۹]{2})', src)"),
   ("        if yn is not None and not 85 <= yn <= 99:",
    "        if yn is not None and len(year) == 2 and not 85 <= yn <= 99:"),
   ("        year_latin = f'13{yn}' if yn is not None else ''",
    "        year_latin = ('' if yn is None else (str(yn) if yn > 1000 else f'13{yn}'))")]),
 ('validate.py',[
   ("            if not 85 <= n <= 99:\n                errors.append(f\"{uid}: implausible exam year {y} (digit reversal?)\")",
    "            ok = (85 <= n <= 99) if len(y) == 2 else (1400 <= n <= 1410)\n"
    "            if not ok:\n                errors.append(f\"{uid}: implausible exam year {y} (digit reversal?)\")"),
   ("        if not r['explanation_fa']:","        if not r.get('explanation_fa'):")]),
 ('to_import.py',[("if only_done and not r['explanation_fa']:",
                  "if only_done and not r.get('explanation_fa'):")])]:
    s=io.open(p,encoding='utf-8').read()
    for o,n in subs:
        if o in s: s=s.replace(o,n)
    for f in ('explanation_fa','explanation_en','why_fa','why_en','golden_fa',
              'golden_en','stem_en','options_en','micro','refs'):
        s=re.sub(rf"r\['{f}'\]", f"r.get('{f}')", s)
    io.open(p,'w',encoding='utf-8').write(s)
PY

echo "=== 4. source-error fix + subject track"
python3 - <<'PY'
import json,io
p='bank.json'; b=json.load(io.open(p,encoding='utf-8'))
# (a) the Shahrivar-1403 sensory-aphasia item printed two identical options
for r in b:
    if 'آفازی حسی مربوط به آسیب کدام ناحیه' in r.get('stem_fa','') \
       and r['options_fa'][1]==r['options_fa'][3]:
        r['options_fa'][3]='لوب تمپورال مغلوب'
        if r.get('options_en'): r['options_en'][3]='Non-dominant temporal lobe'
        r.setdefault('notes',{})['source_option_error']=(
          'گزینه‌های «ب» و «د» در دفترچه‌ی مبدأ یکسان چاپ شده بودند. سه گزینه‌ی دیگر ترکیب '
          'غالب/مغلوب × پریتال/تمپورال را می‌سازند، پس گزینه‌ی چهارم به‌ناچار «لوب تمپورال '
          'مغلوب» است و بر همین اساس بازسازی شد. کلید تغییر نکرد.')
# (b) neurology is a MINOR subject in the pre-internship exam, not a major one.
#     The majors are internal medicine, surgery, paediatrics and obstetrics.
#     Recorded so the platform can weight and filter by track.
for r in b:
    r['subject_track'] = 'minor'
    r['subject_track_fa'] = 'مینور'
json.dump(b, io.open(p,'w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('source fix + subject_track applied to', len(b), 'records')
PY

echo "=== 4b. teach to_import.py about the exam track"
python3 - <<'PYX'
import io
p='to_import.py'; s=io.open(p,encoding='utf-8').read()
a = "            'subject_fa': r['subject_fa'], 'subject_en': r['subject_en'],"
b = ("            'subject_fa': r['subject_fa'], 'subject_en': r['subject_en'],\n"
     "            # neurology is a MINOR subject of the pre-internship exam; the majors\n"
     "            # are internal medicine, surgery, paediatrics and obstetrics\n"
     "            'subject_track': r.get('subject_track', 'minor'),")
c = "        'subject_fa': 'نورولوژی', 'subject_en': 'Neurology',"
d = "        'subject_fa': 'نورولوژی', 'subject_en': 'Neurology', 'subject_track': 'minor',"
if "'subject_track'" not in s:
    s = s.replace(a,b,1).replace(c,d,1)
    io.open(p,'w',encoding='utf-8').write(s)
    print('  to_import.py now emits subject_track')
else:
    print('  to_import.py already emits subject_track')
PYX

echo "=== 4c. teach the server importer about major/minor tracks"
cd /home/user && python3 work/patch_server.py
cd /home/user/project/tools/neurology-bank

echo "=== 5. pipeline"
python3 normalize_meta.py | grep -E "^year|^sitting"
python3 tag_concepts.py >/dev/null
python3 dedupe.py | tail -2
python3 sequence.py 15 | tail -2
python3 audit_answers.py | tail -2
python3 validate.py | tail -3
rm -f import-payload.part*.json
python3 to_import.py --chunk-size 100 | grep -E "questions:|split into"
echo "=== DONE"
