# -*- coding: utf-8 -*-
"""Bilingual micro-lessons, batch 2 — rest of Shahrivar-1403."""
import json, io
L = {}

L["1403-06:100"] = {
 "stem_en": "A patient presenting shortly after symptom onset is thought to have HSV encephalitis. However, CSF PCR and analysis are negative. What is the next step?",
 "options_en": ["Continue acyclovir and repeat the LP",
                "Stop acyclovir to avoid nephrotoxicity",
                "Repeat the PCR on the same sample",
                "Send the sample to an outside laboratory for re-testing"],
 "micro": {
  "lead_fa": "PCR منفی در ۷۲ ساعت اول آنسفالیت هرپسی را رد نمی‌کند؛ آسیکلوویر ادامه می‌یابد و LP تکرار می‌شود.",
  "lead_en": "A negative PCR in the first 72 hours does not exclude HSV encephalitis; continue acyclovir and repeat the LP.",
  "points_fa": [
   "PCR ویروس هرپس در مایع نخاع حساسیت حدود ۹۶ درصد دارد، اما نه از همان ساعت اول.",
   "در سه روز نخست بیماری، بار ویروسی هنوز پایین است و آزمون می‌تواند منفی شود.",
   "پس منفی بودن زودهنگام PCR ارزش رد کردن ندارد و «منفی کاذب» شمرده می‌شود.",
   "درمان باید ادامه یابد و LP در فاصله‌ی سه تا هفت روز تکرار شود.",
   "دلیل این سخت‌گیری، مرگ‌ومیر بیماری است: بدون درمان بیش از هفتاد درصد.",
   "با آسیکلوویر به‌موقع، مرگ‌ومیر به حدود بیست تا سی درصد کاهش می‌یابد.",
   "هر روز تأخیر در شروع درمان، پیامد عصبی را به‌طور معناداری بدتر می‌کند.",
   "پس قاعده روشن است: در شک بالینی، آسیکلوویر پیش از نتیجه‌ی آزمایش شروع می‌شود.",
   "MRI هم کمک‌کننده است و درگیری لوب تمپورال داخلی و اینسولا را زودتر از سی‌تی نشان می‌دهد."
  ],
  "points_en": [
   "HSV PCR in CSF has about 96 per cent sensitivity, but not from the very first hour.",
   "In the first three days the viral load may still be too low and the test can be negative.",
   "So an early negative PCR has no exclusionary value and counts as a false negative.",
   "Treatment must continue and the LP be repeated after three to seven days.",
   "The reason for this caution is mortality: over seventy per cent without treatment.",
   "With timely acyclovir, mortality falls to roughly twenty to thirty per cent.",
   "Every day of delay significantly worsens the neurological outcome.",
   "The rule is therefore clear: on clinical suspicion, start acyclovir before the result.",
   "MRI also helps, showing medial temporal and insular involvement earlier than CT."
  ]
 },
 "explanation_fa": "این سؤال یک اصل مهم بالینی را می‌آزماید: تفسیر آزمون منفی در زمان نادرست. PCR ویروس هرپس در مایع نخاع حساسیت بالایی دارد، اما این حساسیت مربوط به زمانی است که بار ویروسی به حد کافی رسیده باشد. در سه روز نخست بیماری، آزمون می‌تواند منفی کاذب بدهد و صورت سؤال هم صریحاً می‌گوید بیمار «مدت کوتاهی پس از شروع علائم» مراجعه کرده است. حالا تصمیم بالینی را بسنجید: اگر درمان را قطع کنید و تشخیص درست بوده باشد، با بیماری‌ای طرفید که مرگ‌ومیر بدون درمانش بیش از هفتاد درصد است و بازماندگانش عوارض شناختی شدید پیدا می‌کنند. در مقابل، ادامه‌ی چند روز آسیکلوویر در بیماری که در نهایت هرپس نداشته، ضرر چندانی ندارد. پس منطق روشن است: آسیکلوویر را ادامه دهید و LP را ظرف سه تا هفت روز تکرار کنید.",
 "explanation_en": "This item tests an important clinical principle: interpreting a negative test taken at the wrong time. HSV PCR in CSF is highly sensitive, but that sensitivity applies once the viral load is high enough. In the first three days the test can be falsely negative, and the stem explicitly says the patient presented 'shortly after symptom onset'. Now weigh the decision: if you stop treatment and the diagnosis was right, you face a disease with over seventy per cent mortality untreated, and survivors suffer severe cognitive damage. Against that, a few more days of acyclovir in someone who turns out not to have herpes costs little. The logic is clear: continue acyclovir and repeat the LP within three to seven days.",
 "why_fa": [
  "پاسخ صحیح — PCR در سه روز اول می‌تواند منفی کاذب باشد. با توجه به مرگ‌ومیر بالای بیماری، درمان ادامه می‌یابد و LP تکرار می‌شود.",
  "قطع آسیکلوویر خطرناک‌ترین انتخاب است. نفروتوکسیسیتی آسیکلوویر با هیدراتاسیون کافی و انفوزیون آهسته قابل پیشگیری است و در برابر مرگ‌ومیر هفتاد درصدی بیماری وزنی ندارد.",
  "تکرار PCR روی همان نمونه کمکی نمی‌کند، چون مشکل خطای آزمایشگاهی نیست بلکه پایین بودن بار ویروسی در همان نمونه است. باید نمونه‌ی تازه در زمان دیرتر گرفته شود.",
  "ارسال به آزمایشگاه دیگر هم همان اشکال را دارد: نمونه همان نمونه است و اگر ویروس در آن کم باشد، هیچ آزمایشگاهی نمی‌تواند آن را پیدا کند. ضمناً وقت گران‌بها تلف می‌شود."
 ],
 "why_en": [
  "Correct — PCR can be falsely negative in the first three days. Given the disease's high mortality, treatment continues and the LP is repeated.",
  "Stopping acyclovir is the most dangerous option. Its nephrotoxicity is preventable with hydration and slow infusion, and carries no weight against seventy per cent mortality.",
  "Repeating the PCR on the same sample does not help, because the problem is not laboratory error but low viral load in that sample. A fresh, later sample is needed.",
  "Sending it elsewhere has the same flaw: it is the same sample, and if the virus is scarce in it no laboratory can find it. It also wastes precious time."
 ],
 "golden_fa": "PCR منفی زودهنگام هرپس را رد نمی‌کند. آسیکلوویر را ادامه دهید و چند روز بعد LP را تکرار کنید.",
 "golden_en": "An early negative PCR does not exclude herpes. Continue acyclovir and repeat the LP a few days later.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 4: Herpes simplex encephalitis",
  "Tunkel AR et al. IDSA guidelines for the management of encephalitis. Clin Infect Dis 2008;47:303-27"
 ]
}

L["1403-06:101"] = {
 "stem_en": "Sensory aphasia results from damage to which area of the brain?",
 "options_en": ["Dominant parietal lobe", "Non-dominant parietal lobe",
                "Dominant temporal lobe", "Non-dominant parietal lobe"],
 "micro": {
  "lead_fa": "آفازی حسی همان آفازی ورنیکه است و ضایعه‌اش در لوب تمپورال نیمکره‌ی غالب قرار دارد.",
  "lead_en": "Sensory aphasia is Wernicke aphasia, and its lesion lies in the temporal lobe of the dominant hemisphere.",
  "points_fa": [
   "آفازی حسی نام دیگر آفازی ورنیکه است؛ «حسی» یعنی نقص در درک زبان، نه در تولید آن.",
   "ناحیه‌ی ورنیکه در قسمت خلفی شکنج تمپورال فوقانی نیمکره‌ی غالب قرار دارد.",
   "کار این ناحیه رمزگشایی معنای کلمات شنیده‌شده است.",
   "با آسیب آن، دستگاه تولید گفتار سالم می‌ماند پس بیمار روان صحبت می‌کند.",
   "اما محتوا از کنترل معنایی خارج می‌شود و کلمات بی‌معنا تولید می‌شوند.",
   "این الگو را word salad می‌نامند و با پارافازی و نئولوژیسم همراه است.",
   "در بیش از نود درصد راست‌دست‌ها نیمکره‌ی غالب زبان، نیمکره‌ی چپ است.",
   "ناحیه‌ی ورنیکه از شاخه‌ی تحتانی شریان مغزی میانی خون می‌گیرد.",
   "چون از قشر حرکتی دور است، این بیماران معمولاً همی‌پارزی ندارند."
  ],
  "points_en": [
   "Sensory aphasia is another name for Wernicke aphasia; 'sensory' means a deficit of comprehension, not production.",
   "Wernicke's area lies in the posterior superior temporal gyrus of the dominant hemisphere.",
   "Its job is decoding the meaning of heard words.",
   "When it is damaged the speech-production apparatus stays intact, so the patient speaks fluently.",
   "But content escapes semantic control and meaningless words are produced.",
   "This pattern is called word salad and comes with paraphasias and neologisms.",
   "In over ninety per cent of right-handers the dominant language hemisphere is the left.",
   "Wernicke's area is supplied by the inferior division of the middle cerebral artery.",
   "Being far from motor cortex, these patients usually have no hemiparesis."
  ]
 },
 "explanation_fa": "برای پاسخ به این سؤال باید دو معادل‌سازی را بدانید. اول اینکه «آفازی حسی» همان آفازی ورنیکه است؛ کلمه‌ی حسی اینجا به معنای نقص در درک زبان است، در برابر آفازی حرکتی یا بروکا که نقص در تولید کلام دارد. دوم اینکه ناحیه‌ی ورنیکه کجاست: قسمت خلفی شکنج تمپورال فوقانی نیمکره‌ی غالب. پس پاسخ لوب تمپورال غالب است. برای تثبیت مطلب، سه‌گانه‌ی ارزیابی زبان را به یاد بیاورید: روانی، درک و تکرار. در ورنیکه تکلم روان است اما هم درک و هم تکرار مختل‌اند. در بروکا برعکس، تکلم غیرروان و تلگرافی است ولی درک نسبتاً سالم می‌ماند. نکته‌ی بالینی مهم اینکه بیمار ورنیکه از نقص خود بی‌خبر است و گاه به اشتباه با تشخیص اختلال روان‌پزشکی بستری می‌شود.",
 "explanation_en": "Two equivalences answer this item. First, 'sensory aphasia' is Wernicke aphasia; sensory here means a comprehension deficit, as opposed to motor or Broca aphasia which impairs production. Second, where Wernicke's area sits: the posterior superior temporal gyrus of the dominant hemisphere. So the answer is the dominant temporal lobe. To consolidate, recall the three pillars of language assessment: fluency, comprehension and repetition. In Wernicke aphasia speech is fluent but both comprehension and repetition are impaired. In Broca aphasia the reverse holds: speech is non-fluent and telegraphic but comprehension is relatively spared. Clinically it matters that the Wernicke patient is unaware of the deficit and is sometimes admitted with a mistaken psychiatric diagnosis.",
 "why_fa": [
  "لوب پریتال غالب مسئول محاسبه، نوشتن و جهت‌یابی راست و چپ است؛ آسیب آن سندرم گرستمن می‌سازد نه آفازی حسی.",
  "لوب پریتال مغلوب با آسیب خود بی‌توجهی به نیمه‌ی مقابل فضا (neglect) و آنوزوگنوزی ایجاد می‌کند، نه اختلال زبان.",
  "پاسخ صحیح — ناحیه‌ی ورنیکه در قسمت خلفی شکنج تمپورال فوقانی نیمکره‌ی غالب است و آسیب آن آفازی حسی می‌سازد.",
  "این گزینه تکرار گزینه‌ی «ب» است و در دفترچه‌ی اصلی هم عیناً همین‌طور چاپ شده بود؛ به‌هرحال لوب پریتال مغلوب ربطی به زبان ندارد."
 ],
 "why_en": [
  "The dominant parietal lobe handles calculation, writing and left-right orientation; damage produces Gerstmann syndrome, not sensory aphasia.",
  "Damage to the non-dominant parietal lobe causes contralateral neglect and anosognosia, not a language disorder.",
  "Correct — Wernicke's area lies in the posterior superior temporal gyrus of the dominant hemisphere and its damage causes sensory aphasia.",
  "This option repeats option B and was printed identically in the original booklet; in any case the non-dominant parietal lobe has no language role."
 ],
 "golden_fa": "آفازی حسی = ورنیکه = تمپورال غالب. آفازی حرکتی = بروکا = فرونتال غالب.",
 "golden_en": "Sensory aphasia = Wernicke = dominant temporal. Motor aphasia = Broca = dominant frontal.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 1: Disorders of language",
  "Adams and Victor's Principles of Neurology, 12th ed — Aphasia and related disorders"
 ],
 "notes_source": "گزینه‌های «ب» و «د» در دفترچه‌ی مبدأ یکسان چاپ شده بودند (هر دو «لوب پریتال مغلوب»). متن اصلی حفظ شد و در توضیح گزینه‌ها به آن اشاره شد."
}

L["1403-06:102"] = {
 "stem_en": "Regarding idiopathic seventh cranial nerve palsy, which statement is correct?",
 "options_en": ["The commonest age of onset is between 50 and 60 years",
                "The face deviates towards the affected side",
                "Seventh nerve palsy cannot be a sign of multiple sclerosis",
                "Hemifacial spasm is a late and rare complication of seventh nerve palsy"],
 "micro": {
  "lead_fa": "همی‌فاسیال اسپاسم از عوارض دیررس و نادر فلج بل است و از بازسازی نابجای آکسون‌ها می‌آید.",
  "lead_en": "Hemifacial spasm is a late, rare complication of Bell palsy, caused by aberrant axonal regeneration.",
  "points_fa": [
   "فلج بل شایع‌ترین علت فلج حاد و یک‌طرفه‌ی عصب صورت است.",
   "این فلج از نوع محیطی است، پس تمام نیمه‌ی صورت از جمله پیشانی درگیر می‌شود.",
   "در فلج مرکزی برعکس، پیشانی سالم می‌ماند چون از هر دو نیمکره عصب می‌گیرد.",
   "صورت به سمت سالم منحرف می‌شود، چون عضلات آن سمت بدون مقاومت می‌کشند.",
   "اوج بروز آن بین ۱۵ تا ۴۵ سالگی است، نه دهه‌ی پنجم و ششم.",
   "بیشتر بیماران ظرف سه هفته شروع به بهبود می‌کنند و اکثریت کاملاً خوب می‌شوند.",
   "اما گاهی آکسون‌های در حال بازسازی مسیر را اشتباه می‌روند.",
   "این بازسازی نابجا دو پیامد دیررس می‌سازد: همی‌فاسیال اسپاسم و اشک تمساح.",
   "در اشک تمساح، رشته‌های بزاقی به غده‌ی اشکی می‌روند و بیمار هنگام غذا خوردن اشک می‌ریزد."
  ],
  "points_en": [
   "Bell palsy is the commonest cause of acute unilateral facial nerve palsy.",
   "It is a peripheral palsy, so the whole half of the face including the forehead is involved.",
   "In a central palsy the forehead is spared, because it receives bilateral cortical input.",
   "The face deviates towards the healthy side, whose muscles pull unopposed.",
   "Peak incidence is between 15 and 45 years, not the fifth and sixth decades.",
   "Most patients begin to improve within three weeks and the majority recover fully.",
   "Sometimes, however, regenerating axons take the wrong path.",
   "This aberrant regeneration causes two late sequelae: hemifacial spasm and crocodile tears.",
   "In crocodile tears, salivary fibres reach the lacrimal gland so the patient weeps while eating."
  ]
 },
 "explanation_fa": "این سؤال چهار ادعا درباره‌ی فلج بل مطرح می‌کند و باید درست را بیابید. پاسخ به مکانیسم ترمیم عصب برمی‌گردد. در فلج بل غلاف میلین و گاه خود آکسون آسیب می‌بیند و سپس بازسازی آغاز می‌شود. مشکل اینجاست که آکسون‌های در حال رشد همیشه لوله‌ی اصلی خود را پیدا نمی‌کنند و ممکن است وارد مسیر عضله‌ی دیگری شوند. نتیجه‌ی این بازسازی نابجا دو پدیده‌ی دیررس است: همی‌فاسیال اسپاسم که در آن انقباض‌های غیرارادی نیمه‌ی صورت رخ می‌دهد، و سینکینزی مانند اشک تمساح که در آن بیمار هنگام غذا خوردن اشک می‌ریزد چون رشته‌های بزاقی اشتباهاً به غده‌ی اشکی رسیده‌اند. سه ادعای دیگر غلط‌اند: اوج بروز بیماری جوانی است نه دهه‌ی پنجم، صورت به سمت سالم منحرف می‌شود نه ناسالم، و فلج عصب هفتم می‌تواند اولین تظاهر ام‌اس باشد.",
 "explanation_en": "The item offers four claims about Bell palsy and asks which is true. The answer turns on the mechanism of nerve repair. In Bell palsy the myelin sheath and sometimes the axon are injured, and regeneration then begins. The difficulty is that growing axons do not always find their original tube and may enter the pathway of a different muscle. This aberrant regeneration produces two late phenomena: hemifacial spasm, with involuntary contractions of one side of the face, and synkinesis such as crocodile tears, where the patient weeps while eating because salivary fibres have mistakenly reached the lacrimal gland. The other three claims are false: peak incidence is in young adulthood not the fifth decade, the face deviates towards the healthy side, and seventh nerve palsy can indeed be a first presentation of MS.",
 "why_fa": [
  "غلط است. اوج بروز فلج بل بین ۱۵ تا ۴۵ سالگی است. شروع فلج صورت در سنین بالاتر باید شک به علت ثانویه مانند تومور را برانگیزد.",
  "غلط است. عضلات سمت فلج کار نمی‌کنند، پس عضلات سمت سالم بدون مقاومت می‌کشند و صورت به سمت سالم منحرف می‌شود.",
  "غلط است. پلاک دمیلینه در محل خروج عصب هفتم از ساقه‌ی مغز می‌تواند فلج صورت بسازد و گاهی اولین تظاهر ام‌اس در فرد جوان است.",
  "پاسخ صحیح — همی‌فاسیال اسپاسم از بازسازی نابجای آکسون‌ها پس از فلج بل ناشی می‌شود و عارضه‌ای دیررس و نسبتاً نادر است."
 ],
 "why_en": [
  "False. Peak incidence of Bell palsy is between 15 and 45 years. Onset at an older age should raise suspicion of a secondary cause such as tumour.",
  "False. The paralysed side's muscles do not work, so the healthy side pulls unopposed and the face deviates towards the healthy side.",
  "False. A demyelinating plaque at the seventh nerve's exit from the brainstem can cause facial palsy, sometimes as the first presentation of MS in a young patient.",
  "Correct — hemifacial spasm results from aberrant axonal regeneration after Bell palsy and is a late, relatively rare complication."
 ],
 "golden_fa": "در فلج بل صورت به سمت سالم منحرف می‌شود. بازسازی نابجای آکسون دو یادگار دیررس می‌گذارد: همی‌فاسیال اسپاسم و اشک تمساح.",
 "golden_en": "In Bell palsy the face deviates towards the healthy side. Aberrant regeneration leaves two late souvenirs: hemifacial spasm and crocodile tears.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 6: Facial nerve palsy",
  "Baugh RF et al. Clinical practice guideline: Bell's palsy. Otolaryngol Head Neck Surg 2013;149(3 Suppl):S1-27"
 ]
}
json.dump(L, io.open('/home/user/work/lessons/L2.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('batch 2:', len(L), 'lessons')
