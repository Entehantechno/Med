# -*- coding: utf-8 -*-
"""Geometry-based parser for the pre-internship answer-key tables.

Plain text extraction is unusable on these PDFs: Persian digits come out in visual
(reversed) order ("۳۴۳" is really 151) and the RTL columns interleave. We therefore
work from pdfplumber coordinates.

Layout facts established by inspecting the Shahrivar-1403 booklet:
  * Each key page holds two identical half-tables. The page is right-to-left, so the
    RIGHT half (larger x) carries the LOWER question numbers.
  * Inside a half-table the four option columns also run right-to-left: the header
    reads الف@208  ب@170  ج@130  د@90 for the left half. So the right-most column is
    الف and the left-most is د.
  * Question numbers and the "×" glyphs sit on slightly different baselines, so a
    row must be rebuilt by matching each × to the nearest number at a similar y,
    not by assuming they share a text line.

Row ORDER supplies the question number (the printed digits are reversed and cannot
be used). Verified against q93 and q99 of that booklet.
"""
import json, re, pdfplumber

OPTS = ['الف', 'ب', 'ج', 'د']


def parse_page(page, base_right, base_left):
    ws = page.extract_words()

    # ---- header: option label -> x centre, for each half-table
    hdr_rows = {}
    for w in ws:
        t = w['text'].strip()
        lab = 'الف' if t in ('فلا', 'الف') else (t if t in ('ب', 'ج', 'د') else None)
        if lab:
            hdr_rows.setdefault(round(w['top']), []).append((lab, (w['x0'] + w['x1']) / 2))
    hdr = next((v for k, v in sorted(hdr_rows.items()) if len(v) >= 8), None)
    if not hdr:
        return {}
    hdr.sort(key=lambda p: p[1])
    left_hdr, right_hdr = hdr[:4], hdr[4:]          # smaller x first
    boundary = (left_hdr[-1][1] + right_hdr[0][1]) / 2

    marks = [w for w in ws if w['text'].strip() in ('×', 'x', 'X', '✕')]

    # ---- rows: order the × of each half by y, that order gives the question number
    out = {}
    for half_hdr, base, pick in ((left_hdr, base_left, lambda x: x < boundary),
                                 (right_hdr, base_right, lambda x: x >= boundary)):
        cols = {lab: x for lab, x in half_hdr}
        half = sorted((m for m in marks if pick((m['x0'] + m['x1']) / 2)),
                      key=lambda m: m['top'])
        for i, m in enumerate(half):
            xc = (m['x0'] + m['x1']) / 2
            lab = min(cols, key=lambda L: abs(cols[L] - xc))
            out[base + i] = OPTS.index(lab)
    return out


def parse(path, pages):
    out = {}
    with pdfplumber.open(path) as pdf:
        for pageno, br, bl in pages:
            out.update(parse_page(pdf.pages[pageno], br, bl))
    return out


if __name__ == '__main__':
    key = parse('/home/user/uploads/hubmed/hm-1403-06s.pdf',
                [(40, 1, 51), (41, 101, 151)])
    print('parsed', len(key), '/200')
    checks = {93: 1, 99: 3}    # phenytoin ; lorazepam first in status
    ok = True
    for q, want in checks.items():
        got = key.get(q)
        good = got == want
        ok &= good
        print(f'  q{q}: got {OPTS[got] if got is not None else "-"} '
              f'want {OPTS[want]}', '✅' if good else '❌')
    if ok:
        json.dump({str(k): v for k, v in sorted(key.items())},
                  open('/home/user/work/key_1403_06.json', 'w', encoding='utf-8'))
        print('saved ✅')
