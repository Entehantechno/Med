# -*- coding: utf-8 -*-
"""Micro-lessons, batch 8 — completing Shahrivar-1404."""
import json, io
L = {}

L["1404-06:94"] = {
 "stem_en": "You see a patient complaining of headache. It is unilateral and throbbing, sometimes with nausea, and lasts several hours. Which group of drugs is more effective for preventing this patient's attacks?",
 "options_en": ["Lamotrigine, sodium valproate, sumatriptan",
                "Sodium valproate, verapamil, ergotamine",
                "Nortriptyline, verapamil, sodium valproate",
                "Verapamil, nortriptyline, rizatriptan"],
 "micro": {
  "lead_fa": "تریپتان و ارگوتامین داروی حمله‌ی حادند، نه پیشگیری؛ هر گزینه‌ای که آن‌ها را دارد حذف می‌شود.",
  "lead_en": "Triptans and ergotamine treat the acute attack, not prevention; any option containing them is out.",
  "points_fa": [
   "درمان میگرن دو شاخه‌ی کاملاً جدا دارد: قطع حمله و پیشگیری از حمله.",
   "داروی حمله‌ی حاد وقتی درد شروع شد مصرف می‌شود: تریپتان‌ها، ارگوتامین و NSAID.",
   "داروی پیشگیری هر روز مصرف می‌شود تا فراوانی و شدت حملات کم شود.",
   "چهار گروه اصلی پیشگیری: بتابلوکر، ضد صرع، ضد افسردگی سه‌حلقه‌ای و مسدودکننده‌ی کلسیم.",
   "پروپرانولول و متوپرولول از بتابلوکرها بیشترین شواهد را دارند.",
   "توپیرامات و والپروات سدیم از ضد صرع‌ها خط اول‌اند.",
   "آمی‌تریپتیلین و نورتریپتیلین از سه‌حلقه‌ای‌ها استفاده می‌شوند.",
   "وراپامیل بیشتر در سردرد خوشه‌ای کاربرد دارد اما در میگرن هم به کار می‌رود.",
   "مصرف مکرر داروی حمله‌ی حاد خودش سردرد ناشی از مصرف بیش از حد دارو می‌سازد."
  ],
  "points_en": [
   "Migraine treatment has two entirely separate arms: aborting the attack and preventing it.",
   "Acute drugs are taken once pain starts: triptans, ergotamine and NSAIDs.",
   "Preventives are taken daily to reduce attack frequency and severity.",
   "Four main preventive classes: beta-blockers, anticonvulsants, tricyclics and calcium blockers.",
   "Among beta-blockers, propranolol and metoprolol have the strongest evidence.",
   "Among anticonvulsants, topiramate and sodium valproate are first-line.",
   "Among tricyclics, amitriptyline and nortriptyline are used.",
   "Verapamil is mainly for cluster headache but is also used in migraine.",
   "Overusing acute medication itself causes medication-overuse headache."
  ]
 },
 "explanation_fa": "این سؤال یک راه‌حل حذفی زیبا دارد. ابتدا تشخیص روشن است: سردرد یک‌طرفه، ضربان‌دار، همراه با تهوع و چند ساعته یعنی میگرن. حالا به‌جای اینکه دنبال گزینه‌ی درست بگردید، دنبال داروهای حمله‌ی حاد بگردید و هر گزینه‌ای که آن‌ها را دارد کنار بگذارید. سوماتریپتان و ریزاتریپتان هر دو تریپتان و داروی حمله‌اند. ارگوتامین هم داروی حمله است. با همین یک قاعده سه گزینه حذف می‌شوند و تنها گزینه‌ی باقی‌مانده نورتریپتیلین، وراپامیل و والپروات سدیم است که هر سه پیشگیرانه‌اند. نکته‌ی بالینی مهم اینکه اشتباه گرفتن این دو شاخه پیامد واقعی دارد: بیماری که به‌جای پیشگیری، مکرر داروی حمله مصرف می‌کند دچار سردرد ناشی از مصرف بیش از حد دارو می‌شود که خودش مشکل تازه‌ای است.",
 "explanation_en": "This item has an elegant elimination route. The diagnosis is clear: unilateral throbbing headache with nausea lasting hours means migraine. Now, instead of hunting for the right answer, hunt for acute drugs and discard any option containing them. Sumatriptan and rizatriptan are both triptans and both acute. Ergotamine is acute too. That single rule eliminates three options, leaving nortriptyline, verapamil and sodium valproate — all three preventive. One clinical point matters: confusing the two arms has real consequences, because a patient who takes acute medication frequently instead of a preventive develops medication-overuse headache, a new problem in itself.",
 "why_fa": [
  "سوماتریپتان داروی حمله‌ی حاد است، نه پیشگیری. لاموتریژین هم در میگرن جایگاه پیشگیرانه‌ی جاافتاده‌ای ندارد و بیشتر برای اورای میگرنی مطرح شده است.",
  "ارگوتامین داروی قطع حمله است و مصرف مکررش سردرد ناشی از مصرف بیش از حد دارو می‌سازد. پس این ترکیب برای پیشگیری مناسب نیست.",
  "پاسخ صحیح — هر سه دارو پیشگیرانه‌اند: نورتریپتیلین از سه‌حلقه‌ای‌ها، وراپامیل از مسدودکننده‌های کلسیم و والپروات سدیم از ضد صرع‌ها.",
  "ریزاتریپتان مثل سوماتریپتان داروی حمله‌ی حاد است. وجود آن در این ترکیب، گزینه را از فهرست پیشگیری خارج می‌کند."
 ],
 "why_en": [
  "Sumatriptan is an acute drug, not a preventive. Lamotrigine also has no established preventive role in migraine and is mainly discussed for aura.",
  "Ergotamine aborts attacks, and frequent use causes medication-overuse headache. This combination is unsuitable for prevention.",
  "Correct — all three are preventives: nortriptyline a tricyclic, verapamil a calcium blocker and sodium valproate an anticonvulsant.",
  "Rizatriptan, like sumatriptan, is an acute drug. Its presence disqualifies this combination from the preventive list."
 ],
 "golden_fa": "تریپتان و ارگوتامین = حمله. بتابلوکر، ضد صرع، سه‌حلقه‌ای و وراپامیل = پیشگیری.",
 "golden_en": "Triptans and ergotamine = acute. Beta-blockers, anticonvulsants, tricyclics and verapamil = prevention.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 6: Migraine prophylaxis",
  "Silberstein SD et al. Evidence-based guideline update: pharmacologic treatment for episodic migraine prevention. Neurology 2012;78:1337-45"
 ]
}

L["1404-06:95"] = {
 "stem_en": "The artery of Adamkiewicz supplies which part of the spinal cord?",
 "options_en": ["Lower cervical and upper thoracic", "Upper and lower thoracic",
                "Lower thoracic and upper lumbar", "Lumbosacral"],
 "micro": {
  "lead_fa": "شریان آدامکیویچ بزرگ‌ترین شریان رادیکولار قدامی است و دو سوم تحتانی نخاع را تغذیه می‌کند.",
  "lead_en": "The artery of Adamkiewicz is the largest anterior radicular artery and feeds the lower two-thirds of the cord.",
  "points_fa": [
   "نخاع از یک شریان اسپاینال قدامی و دو شریان اسپاینال خلفی خون می‌گیرد.",
   "شریان اسپاینال قدامی دو سوم قدامی مقطع نخاع را تغذیه می‌کند.",
   "این شریان در طول مسیرش از شریان‌های رادیکولار تقویت می‌شود.",
   "بزرگ‌ترین آن‌ها شریان آدامکیویچ است که معمولاً بین T9 تا L2 وارد می‌شود.",
   "در بیش از هشتاد درصد افراد از سمت چپ منشعب می‌شود.",
   "این شریان توراسیک تحتانی و لومبار فوقانی را خون‌رسانی می‌کند.",
   "ناحیه‌ی T4 تا T8 کم‌ترین خون‌رسانی جانبی را دارد و «منطقه‌ی مرزی» نامیده می‌شود.",
   "همین ناحیه در افت فشار یا جراحی آئورت بیشترین آسیب را می‌بیند.",
   "سندرم شریان اسپاینال قدامی: فلج + از دست رفتن درد و حرارت با حفظ حس عمقی."
  ],
  "points_en": [
   "The cord is supplied by one anterior and two posterior spinal arteries.",
   "The anterior spinal artery feeds the anterior two-thirds of the cord in cross-section.",
   "Along its course it is reinforced by radicular arteries.",
   "The largest of these is the artery of Adamkiewicz, usually entering between T9 and L2.",
   "In over eighty per cent of people it arises on the left.",
   "It supplies the lower thoracic and upper lumbar cord.",
   "The T4-T8 region has the poorest collateral supply and is called the watershed zone.",
   "That zone suffers most during hypotension or aortic surgery.",
   "Anterior spinal artery syndrome: paralysis with loss of pain and temperature but preserved proprioception."
  ]
 },
 "explanation_fa": "این یک سؤال آناتومیک مستقیم است، اما اهمیت بالینی‌اش آن را به یاد ماندنی می‌کند. شریان اسپاینال قدامی که دو سوم قدامی نخاع را تغذیه می‌کند، در طول مسیرش از شریان‌های رادیکولار تقویت می‌شود. بزرگ‌ترین این شریان‌ها آدامکیویچ است که معمولاً بین مهره‌های T9 تا L2 و در بیش از هشتاد درصد موارد از سمت چپ وارد می‌شود. قلمرو خون‌رسانی آن توراسیک تحتانی و لومبار فوقانی است. اهمیت بالینی این نکته در جراحی آئورت است: هنگام ترمیم آنوریسم آئورت توراکوابدومینال، اگر این شریان قطع یا مسدود شود، بیمار دچار سندرم شریان اسپاینال قدامی و پاراپلژی می‌شود. الگوی حسی این سندرم هم آموزنده است: حس درد و حرارت از بین می‌رود اما حس عمقی و ارتعاش سالم می‌ماند، چون ستون خلفی از شریان‌های اسپاینال خلفی خون می‌گیرد.",
 "explanation_en": "This is a direct anatomical question, but its clinical importance makes it memorable. The anterior spinal artery, which feeds the anterior two-thirds of the cord, is reinforced along its course by radicular arteries. The largest of these is the artery of Adamkiewicz, usually entering between T9 and L2 and, in over eighty per cent of people, from the left. Its territory is the lower thoracic and upper lumbar cord. The clinical relevance lies in aortic surgery: during thoracoabdominal aneurysm repair, sacrificing or occluding this artery causes anterior spinal artery syndrome and paraplegia. The sensory pattern of that syndrome is instructive too — pain and temperature are lost while proprioception and vibration are preserved, because the posterior columns are supplied by the posterior spinal arteries.",
 "why_fa": [
  "ناحیه‌ی سرویکال تحتانی و توراسیک فوقانی از شاخه‌های شریان ورتبرال و شریان‌های رادیکولار گردنی خون می‌گیرد، نه از آدامکیویچ.",
  "درست است که بخشی از توراسیک را می‌پوشاند، اما توراسیک فوقانی خارج از قلمرو آدامکیویچ است و در واقع منطقه‌ی مرزی کم‌خون محسوب می‌شود.",
  "پاسخ صحیح — شریان آدامکیویچ معمولاً بین T9 تا L2 وارد می‌شود و توراسیک تحتانی و لومبار فوقانی را خون‌رسانی می‌کند.",
  "ناحیه‌ی لومبوساکرال تحتانی و مخروط نخاعی خون‌رسانی جداگانه‌ای از شریان‌های ایلیاک داخلی و ساکرال دارند."
 ],
 "why_en": [
  "The lower cervical and upper thoracic cord is supplied by vertebral artery branches and cervical radicular arteries, not by Adamkiewicz.",
  "It does cover part of the thoracic cord, but the upper thoracic segment lies outside its territory and is in fact the poorly perfused watershed zone.",
  "Correct — the artery of Adamkiewicz usually enters between T9 and L2 and supplies the lower thoracic and upper lumbar cord.",
  "The lower lumbosacral cord and conus have their own supply from internal iliac and sacral branches."
 ],
 "golden_fa": "آدامکیویچ: بین T9 تا L2، اغلب از چپ، تغذیه‌کننده‌ی توراسیک تحتانی و لومبار فوقانی. خطرش در جراحی آئورت است.",
 "golden_en": "Adamkiewicz: enters T9-L2, usually on the left, feeding the lower thoracic and upper lumbar cord. Its risk is in aortic surgery.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 9: Vascular supply of the spinal cord",
  "Adams and Victor's Principles of Neurology, 12th ed — Spinal cord vascular disease"
 ]
}

L["1404-06:96"] = {
 "stem_en": "Which of the following patients with multiple sclerosis has the better prognosis?",
 "options_en": ["A 30-year-old man whose disease began with optic neuritis",
                "A 30-year-old woman whose disease began with optic neuritis",
                "A 50-year-old man whose disease began with cerebellar symptoms",
                "A 50-year-old woman whose disease began with cerebellar symptoms"],
 "micro": {
  "lead_fa": "سه عامل را هم‌زمان بسنجید: جنس مؤنث، سن پایین‌تر و شروع با نوریت اپتیک — بهترین ترکیب برنده است.",
  "lead_en": "Weigh three factors at once: female sex, younger age and onset with optic neuritis — the best combination wins.",
  "points_fa": [
   "پیش‌آگهی ام‌اس را می‌توان از همان حمله‌ی اول تا حدی پیش‌بینی کرد.",
   "جنس مؤنث پیش‌آگهی بهتری دارد؛ مردان بیشتر به سیر پیشرونده می‌روند.",
   "سن شروع پایین‌تر بهتر است، چون ظرفیت ترمیم و پلاستیسیتی مغز بیشتر است.",
   "شروع با علائم حسی یا نوریت اپتیک نشانه‌ی خوبی است.",
   "دلیلش این است که مسیرهای حسی و بینایی ظرفیت جبران بهتری دارند.",
   "در مقابل، شروع با علائم مخچه‌ای یا حرکتی پیش‌آگهی بدتری دارد.",
   "آتاکسی مخچه‌ای به‌سختی جبران می‌شود و ناتوانی ماندگار می‌گذارد.",
   "سیر عودکننده-بهبودیابنده بهتر از سیر پیشرونده‌ی اولیه است.",
   "بار کم ضایعات در MRI اولیه هم نشانه‌ی سیر خوش‌خیم‌تر است."
  ],
  "points_en": [
   "MS prognosis can be partly predicted from the very first attack.",
   "Female sex carries a better outlook; men more often follow a progressive course.",
   "Younger onset is better, because the brain has more capacity for repair and plasticity.",
   "Onset with sensory symptoms or optic neuritis is favourable.",
   "The reason is that sensory and visual pathways compensate better.",
   "Onset with cerebellar or motor symptoms carries a worse prognosis.",
   "Cerebellar ataxia compensates poorly and leaves lasting disability.",
   "A relapsing-remitting course is better than primary progressive disease.",
   "A low lesion burden on the initial MRI also signals a more benign course."
  ]
 },
 "explanation_fa": "این سؤال هوشمندانه سه عامل پیش‌آگهی را هم‌زمان در چهار گزینه ترکیب کرده است، پس باید هر سه را با هم بسنجید. عامل اول جنس است: مؤنث بهتر از مذکر. عامل دوم سن است: سی سال بهتر از پنجاه سال، چون مغز جوان‌تر ظرفیت ترمیم بیشتری دارد. عامل سوم نوع علامت آغازین است: نوریت اپتیک بهتر از علائم مخچه‌ای، چون مسیر بینایی ظرفیت جبران خوبی دارد در حالی که آتاکسی مخچه‌ای به‌سختی جبران می‌شود و ناتوانی ماندگار می‌گذارد. حالا گزینه‌ها را بسنجید: خانم سی‌ساله با شروع نوریت اپتیک هر سه عامل مطلوب را با هم دارد، پس بهترین پیش‌آگهی از آنِ اوست. در نقطه‌ی مقابل، آقای پنجاه‌ساله با شروع مخچه‌ای هر سه عامل نامطلوب را دارد و بدترین پیش‌آگهی را خواهد داشت.",
 "explanation_en": "This item cleverly combines three prognostic factors across four options, so you must weigh all three together. The first is sex: female beats male. The second is age: thirty beats fifty, because a younger brain has more repair capacity. The third is the presenting symptom: optic neuritis beats cerebellar signs, because the visual pathway compensates well whereas cerebellar ataxia compensates poorly and leaves lasting disability. Now score the options: the thirty-year-old woman presenting with optic neuritis has all three favourable factors together, so hers is the best prognosis. At the opposite pole, the fifty-year-old man with cerebellar onset carries all three unfavourable factors and will do worst.",
 "why_fa": [
  "این بیمار سن مطلوب و شروع مطلوب دارد اما جنس مذکر عامل پیش‌آگهی بد است. پس یک درجه پایین‌تر از گزینه‌ی درست قرار می‌گیرد.",
  "پاسخ صحیح — این بیمار هر سه عامل مطلوب را با هم دارد: جنس مؤنث، سن سی سال و شروع با نوریت اپتیک.",
  "بدترین ترکیب ممکن است: جنس مذکر، سن پنجاه سال و شروع با علائم مخچه‌ای که هر سه پیش‌آگهی بد محسوب می‌شوند.",
  "جنس مؤنث تنها عامل مطلوب این بیمار است، اما سن بالا و شروع مخچه‌ای هر دو پیش‌آگهی را بدتر می‌کنند."
 ],
 "why_en": [
  "This patient has a favourable age and onset, but male sex is an adverse factor. So he ranks one step below the correct answer.",
  "Correct — this patient has all three favourable factors together: female sex, age thirty, and onset with optic neuritis.",
  "The worst possible combination: male sex, age fifty and cerebellar onset, all three adverse.",
  "Female sex is this patient's only favourable factor; older age and cerebellar onset both worsen the outlook."
 ],
 "golden_fa": "خوب: زن، جوان، نوریت اپتیک. بد: مرد، مسن، مخچه‌ای. سؤال را با شمردن عوامل مطلوب هر گزینه حل کنید.",
 "golden_en": "Good: female, young, optic neuritis. Bad: male, older, cerebellar. Solve it by counting each option's favourable factors.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 6: Multiple sclerosis, prognosis",
  "Confavreux C, Vukusic S. Natural history of multiple sclerosis. Brain 2006;129:606-16"
 ]
}
json.dump(L, io.open('/home/user/work/lessons/L8.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('batch 8:', len(L), 'lessons')
