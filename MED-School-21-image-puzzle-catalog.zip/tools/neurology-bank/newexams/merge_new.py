# -*- coding: utf-8 -*-
"""Merge the 47 post-98 questions into bank.json with correct chapter mapping.

New uids continue from neuro-605 (neuro-606 …). Each record keeps two new fields
that older records do not have:
  key_source     'official' or 'derived_aminoff'
  key_rationale  the medical reasoning, when the key had to be derived
and, where the ministry published an English booklet, en_source =
'official_english_booklet' marking stem_en/options_en as the ministry's own words.
"""
import json, io, glob, re

BANK = '/home/user/project/tools/neurology-bank/bank.json'
bank = json.load(io.open(BANK, encoding='utf-8'))
existing = {r['uid'] for r in bank}
next_n = max(int(u.split('-')[1]) for u in existing) + 1

# Re-running this script must not duplicate anything. A question is identified by
# its (sitting, question number) pair, which the earlier run stored in `source`
# and `question_no`; build that index once so we can skip what is already in.
def _seen_key(rec):
    return (rec.get('exam_month', ''), rec.get('year', ''), rec.get('question_no'))
already = {_seen_key(r) for r in bank if r.get('key_source')}

CH = {
 'exam':      ('اصول معاینه عصبی', 'Principles of the Neurologic Examination', 'فصل اول'),
 'coma':      ('کما و سایر اختلالات هوشیاری', 'Coma and Other Disorders of Consciousness', 'فصل دوم'),
 'stroke':    ('بیماری های عروقی مغز', 'Cerebrovascular Diseases', 'فصل سوم'),
 'seizure':   ('صرع و سایر اختلالات تشنجی', 'Epilepsy and Seizure Disorders', 'فصل چهارم'),
 'infection': ('عفونت های سیستم عصبی مرکزی', 'Infections of the Central Nervous System', 'فصل ششم'),
 'headache':  ('سردرد و درد صورت و افزایش فشار داخل جمجمه',
               'Headache, Facial Pain and Raised Intracranial Pressure', 'فصل هشتم'),
 'dementia':  ('زوال عقل و سندرومهای فراموشی', 'Dementia and Amnestic Syndromes', 'فصل دهم'),
 'ms':        ('ام اس و سایر بیماری های دمیلینیزان',
               'Multiple Sclerosis and Other Demyelinating Diseases', 'فصل یازدهم'),
 'movement':  ('اختلالات حرکتی', 'Movement Disorders', 'فصل دوازدهم'),
 'nerve':     ('بیماری های اعصاب محیطی', 'Diseases of the Peripheral Nerves', 'فصل سیزدهم'),
 'muscle':    ('بیماری های عضلانی', 'Muscle Diseases', 'فصل چهاردهم'),
 'nmj':       ('اختلالات انتقالی عصبی- عضلانی', 'Neuromuscular Junction Disorders', 'فصل پانزدهم'),
 'cord':      ('بیماری های نخاع', 'Diseases of the Spinal Cord', 'فصل شانزدهم'),
 'dizziness': ('سرگیجه و اختلالات سیستم وستیبولار',
               'Dizziness and Vestibular Disorders', 'فصل نهم'),
 'systemic':  ('عوارض نورولوژیک بیماری های سیستمیک',
               'Neurologic Complications of Systemic Disease', 'فصل هفتم'),
}

# hand-assigned chapter per question — safer than keyword guessing
CHAPTER_OF = {
 ('1403-06', 97): 'seizure',  ('1403-06', 98): 'movement', ('1403-06', 99): 'seizure',
 ('1403-06',100): 'infection',('1403-06',101): 'exam',     ('1403-06',102): 'nerve',
 ('1403-12', 98): 'movement', ('1403-12', 99): 'stroke',   ('1403-12',100): 'ms',
 ('1403-12',101): 'muscle',   ('1403-12',102): 'coma',
 ('1402-12', 97): 'infection',('1402-12', 98): 'nerve',    ('1402-12', 99): 'exam',
 ('1402-12',100): 'headache', ('1402-12',101): 'infection',('1402-12',102): 'muscle',
 ('1400-12',114): 'ms',       ('1400-12',115): 'movement', ('1400-12',116): 'nerve',
 ('1400-12',117): 'infection',('1400-12',118): 'stroke',   ('1400-12',119): 'muscle',
 ('1400-12',120): 'movement', ('1400-12',121): 'nerve',
 ('1399-06',114): 'cord',     ('1399-06',115): 'seizure',  ('1399-06',116): 'dementia',
 ('1399-06',117): 'stroke',
 ('1399-12',114): 'ms',       ('1399-12',115): 'dementia', ('1399-12',116): 'seizure',
 ('1399-12',117): 'stroke',   ('1399-12',118): 'nerve',
 ('1400-06',114): 'headache', ('1400-06',115): 'nerve',    ('1400-06',116): 'stroke',
 ('1400-06',117): 'seizure',  ('1400-06',118): 'ms',
 ('1401-06',114): 'headache', ('1401-06',115): 'dementia', ('1401-06',116): 'nmj',
 ('1401-06',117): 'movement',
 ('1402-06', 97): 'headache', ('1402-06', 98): 'nerve',    ('1402-06', 99): 'coma',
 ('1402-06',100): 'movement',
 ('1397-09',121): 'muscle',
 ('1404-06', 91): 'stroke',   ('1404-06', 92): 'seizure',  ('1404-06', 93): 'coma',
 ('1404-06', 94): 'headache', ('1404-06', 95): 'cord',     ('1404-06', 96): 'ms',
 # Esfand-1401 main sitting — was entirely missing from the bank
 ('1401-12',114): 'headache', ('1401-12',115): 'seizure',  ('1401-12',116): 'systemic',
 ('1401-12',117): 'dizziness', ('1401-12',118): 'headache', ('1401-12',119): 'movement',
 ('1401-12',120): 'movement', ('1401-12',121): 'stroke',
 # Dey-1399 and Aban-1400 mid-terms — also missing
 ('1399-10',114): 'stroke',   ('1399-10',115): 'seizure',  ('1399-10',116): 'nmj',
 ('1399-10',117): 'coma',     ('1399-10',118): 'headache', ('1399-10',119): 'ms',
 ('1399-10',120): 'dementia', ('1399-10',121): 'movement',
 ('1400-08',114): 'muscle',   ('1400-08',115): 'coma',     ('1400-08',116): 'exam',
 ('1400-08',117): 'seizure',  ('1400-08',118): 'seizure',  ('1400-08',119): 'headache',
 ('1400-08',120): 'dementia', ('1400-08',121): 'ms',
 # Azar-1404 — the last sitting held (Esfand-1404 was cancelled by the ministry)
 ('1404-09', 97): 'nmj',      ('1404-09', 98): 'nerve',    ('1404-09', 99): 'headache',
 ('1404-09',100): 'exam',     ('1404-09',101): 'seizure',  ('1404-09',102): 'ms',
 ('1397-10',114): 'cord',     ('1397-10',115): 'headache', ('1397-10',116): 'seizure',
 ('1397-10',117): 'ms',       ('1397-10',118): 'coma',     ('1397-10',119): 'seizure',
 ('1397-10',120): 'movement', ('1397-10',121): 'headache',
 ('1402-03',114): 'headache', ('1402-03',115): 'coma',     ('1402-03',116): 'stroke',
 ('1402-03',117): 'nerve',    ('1402-03',118): 'seizure',  ('1402-03',119): 'ms',
 ('1402-03',120): 'exam',     ('1402-03',121): 'movement',
}

YEAR = {'1397-09': ('۹۷','آذر'), '1397-10': ('۹۷','دی'),
        '1404-06': ('۱۴۰۴','شهریور'), '1404-09': ('۱۴۰۴','آذر'),
        '1401-12': ('۱۴۰۱','اسفند'), '1399-10': ('۹۹','دی'),
        '1400-08': ('۱۴۰۰','آبان'),
        '1399-06': ('۹۹','شهریور'), '1399-12': ('۹۹','اسفند'),
        '1400-06': ('۱۴۰۰','شهریور'), '1400-12': ('۱۴۰۰','اسفند'),
        '1401-06': ('۱۴۰۱','شهریور'), '1402-06': ('۱۴۰۲','شهریور'),
        '1402-03': ('۱۴۰۲','خرداد'),
        '1402-12': ('۱۴۰۲','اسفند'), '1403-06': ('۱۴۰۳','شهریور'),
        '1403-12': ('۱۴۰۳','اسفند')}

new = []
for f in sorted(glob.glob('/home/user/work/out/neuro_*.json')):
    new += json.load(io.open(f, encoding='utf-8'))
new.sort(key=lambda q: (q['exam_tag'], q['question_no']))

added = []
for q in new:
    tag, no = q['exam_tag'], q['question_no']
    ch = CHAPTER_OF.get((tag, no))
    if not ch:
        print('!! no chapter for', tag, no); continue
    fa, en, num = CH[ch]
    yr, mo = YEAR[tag]
    if (mo, yr, no) in already:
        continue                      # this sitting/question is already in the bank
    already.add((mo, yr, no))
    uid = f'neuro-{next_n:03d}'; next_n += 1
    rec = {
        'uid': uid, 'question_no': no,
        'subject_fa': 'نورولوژی', 'subject_en': 'Neurology',
        'chapter_fa': fa, 'chapter_en': en, 'chapter_num': num,
        'stem_fa': q['stem_fa'], 'options_fa': q['options_fa'],
        'correct_index': q['correct_index'], 'correct_letter': q['correct_letter'],
        'exam_type': 'پره‌انترنی', 'year': yr, 'exam_month': mo,
        'exam_pole': 'کشوری', 'source': f'پره‌انترنی {mo} {yr}',
        'notes': q.get('notes', {}),
        'key_source': q.get('key_source', 'official'),
    }
    if q.get('key_rationale'):
        rec['key_rationale'] = q['key_rationale']
    if q.get('stem_en'):
        rec['stem_en'] = q['stem_en']
        rec['options_en'] = q['options_en']
        rec['en_source'] = q['en_source']
    bank.append(rec); added.append(rec)

json.dump(bank, io.open(BANK, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

from collections import Counter
print(f'added {len(added)} questions -> bank now {len(bank)}')
print('\nby chapter:')
for c, n in Counter(r['chapter_fa'] for r in added).most_common():
    print(f'  {n:2d}  {c}')
print('\nby sitting:')
for s, n in sorted(Counter(f"{r['exam_month']} {r['year']}" for r in added).items()):
    print(f'  {n:2d}  {s}')
print(f"\nofficial keys: {sum(1 for r in added if r['key_source']=='official')}")
print(f"official English: {sum(1 for r in added if r.get('en_source'))}")
