# -*- coding: utf-8 -*-
"""Micro-lessons, batch 12 — Shahrivar 1402 and Esfand 1402."""
import json, io
L = {}

L["1402-06:97"] = {
 "stem_en": "A 25-year-old man complains of a unilateral nocturnal headache lasting about an hour, accompanied by restlessness and tearing. Which headache type is most likely?",
 "options_en": ["Tension type", "Classic migraine", "Trigeminal neuralgia", "Cluster"],
 "micro": {
  "lead_fa": "بی‌قراری و اشک‌ریزش با سردرد شبانه‌ی یک‌ساعته، امضای سردرد خوشه‌ای است.",
  "lead_en": "Restlessness and tearing with a one-hour nocturnal headache are the signature of cluster headache.",
  "points_fa": [
   "سردرد خوشه‌ای شدیدترین سردرد شناخته‌شده است و به آن سردرد خودکشی هم می‌گویند.",
   "برخلاف بیشتر سردردها، در مردان چهار تا پنج برابر شایع‌تر است.",
   "درد همیشه یک‌طرفه و پشت یا اطراف چشم است و هرگز سمت عوض نمی‌کند.",
   "هر حمله پانزده دقیقه تا سه ساعت طول می‌کشد.",
   "حملات ریتم شبانه‌روزی دارند و اغلب یک تا دو ساعت پس از خواب رخ می‌دهند.",
   "علائم اتونوم همراه، بخش تعریف‌کننده‌ی تشخیص‌اند.",
   "این علائم عبارت‌اند از اشک‌ریزش، قرمزی چشم، آبریزش بینی و پتوز.",
   "بی‌قراری کلید افتراق از میگرن است: بیمار خوشه‌ای راه می‌رود، بیمار میگرنی دراز می‌کشد.",
   "درمان حمله اکسیژن صددرصد و سوماتریپتان زیرجلدی است؛ پیشگیری با وراپامیل."
  ],
  "points_en": [
   "Cluster headache is the most severe known headache and is called the suicide headache.",
   "Unlike most headaches it is four to five times commoner in men.",
   "Pain is always unilateral, behind or around the eye, and never switches sides.",
   "Each attack lasts fifteen minutes to three hours.",
   "Attacks follow a circadian rhythm and often occur one to two hours after falling asleep.",
   "The accompanying autonomic features are part of the diagnostic definition.",
   "These include tearing, conjunctival injection, nasal discharge and ptosis.",
   "Restlessness is the key discriminator from migraine: the cluster patient paces, the migraine patient lies down.",
   "Attack treatment is one hundred percent oxygen and subcutaneous sumatriptan; prevention is with verapamil."
  ]
 },
 "explanation_fa": "چهار سرنخ در صورت سؤال هست و هر چهار به یک تشخیص می‌رسند. اول جنس و سن: مرد جوان، که سردرد خوشه‌ای در همین گروه شایع‌ترین است. دوم زمان: شبانه، که ریتم شبانه‌روزی مشخصه‌ی این سردرد است و حملات معمولاً بیمار را از خواب بیدار می‌کنند. سوم مدت: حدود یک ساعت، که دقیقاً در بازه‌ی پانزده دقیقه تا سه ساعت می‌نشیند. و چهارم و مهم‌ترین سرنخ، ترکیب بی‌قراری و اشک‌ریزش. بی‌قراری اینجا نکته‌ی طلایی است. بیمار میگرنی از نور و صدا فرار می‌کند و در اتاق تاریک دراز می‌کشد، اما بیمار سردرد خوشه‌ای نمی‌تواند آرام بگیرد و مدام راه می‌رود یا سر خود را می‌کوبد. اشک‌ریزش هم نشانه‌ی فعال شدن مسیر تریژمینو-اتونوم است.",
 "explanation_en": "There are four clues in the stem and all four converge on one diagnosis. First, sex and age: a young man, the group in which cluster headache is commonest. Second, timing: nocturnal, reflecting the circadian rhythm of this headache, whose attacks typically wake the patient. Third, duration: about an hour, sitting exactly in the fifteen-minute to three-hour window. And fourth, the most important clue, the combination of restlessness and tearing. Restlessness is the golden point here. A migraine patient flees light and sound and lies down in a dark room, whereas a cluster patient cannot keep still and paces or bangs their head. Tearing signals activation of the trigeminal-autonomic pathway.",
 "why_fa": [
  "سردرد تنشی دوطرفه، فشارنده و با شدت خفیف تا متوسط است. علائم اتونوم ندارد و بیمار را از خواب بیدار نمی‌کند.",
  "میگرن کلاسیک با اورا شروع می‌شود، معمولاً چهار تا هفتاد و دو ساعت طول می‌کشد و بیمار در سکون و تاریکی آرام می‌گیرد، نه در حرکت.",
  "نورالژی تریژمینال درد برق‌آسای چند ثانیه‌ای است که با لمس صورت راه می‌افتد، نه سردرد یک‌ساعته با اشک‌ریزش.",
  "پاسخ صحیح — سردرد یک‌طرفه‌ی شبانه‌ی یک‌ساعته با بی‌قراری و اشک‌ریزش در مرد جوان، تصویر کلاسیک سردرد خوشه‌ای است."
 ],
 "why_en": [
  "Tension headache is bilateral, pressing and mild to moderate. It has no autonomic features and does not wake the patient.",
  "Classic migraine begins with an aura, usually lasts four to seventy-two hours, and the patient settles in stillness and darkness rather than moving about.",
  "Trigeminal neuralgia is a few seconds of electric pain triggered by touching the face, not a one-hour headache with tearing.",
  "Correct — a unilateral nocturnal one-hour headache with restlessness and tearing in a young man is the classic picture of cluster headache."
 ],
 "golden_fa": "خوشه‌ای: مرد، شبانه، یک‌طرفه، اشک‌ریزش، بی‌قرار. میگرنی: دراز می‌کشد، خوشه‌ای: راه می‌رود.",
 "golden_en": "Cluster: male, nocturnal, unilateral, tearing, restless. The migraine patient lies down; the cluster patient paces.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 6: Cluster headache",
  "Hoffmann J, May A. Diagnosis, pathophysiology, and management of cluster headache. Lancet Neurol 2018;17:75-83"
 ]
}

L["1402-06:98"] = {
 "stem_en": "A 50-year-old woman presents with symmetric weakness of the lower limbs and then the upper limbs starting two days ago. She reports a cold two weeks earlier. On examination she cannot stand unaided and tendon reflexes are reduced. Given the likely diagnosis, all of the following are correct EXCEPT:",
 "options_en": ["Giving a corticosteroid", "Starting plasmapheresis",
                "Giving prophylactic heparin", "ICU monitoring"],
 "micro": {
  "lead_fa": "همان قاعده‌ی طلایی: در گیلن باره کورتیکواستروئید جایی ندارد.",
  "lead_en": "The same golden rule: corticosteroids have no place in Guillain-Barre syndrome.",
  "points_fa": [
   "شرح حال کلاسیک: عفونت تنفسی یا گوارشی، سپس ضعف صعودی قرینه طی روزها.",
   "کاهش یا نبود رفلکس‌های وتری از یافته‌های کلیدی معاینه است.",
   "خطرناک‌ترین عارضه نارسایی تنفسی است و در حدود بیست تا سی درصد رخ می‌دهد.",
   "بنابراین پایش ظرفیت حیاتی ریه در بخش ویژه ضروری است.",
   "قاعده‌ی بیست-سی-چهل: ظرفیت حیاتی زیر بیست میلی‌لیتر بر کیلوگرم هشدار است.",
   "بی‌ثباتی اتونوم هم شایع است: نوسان فشار خون و آریتمی قلبی.",
   "درمان اختصاصی فقط دو گزینه دارد: ایمونوگلوبولین وریدی یا پلاسمافرز.",
   "پلاسمافرز آنتی‌بادی‌ها و کمپلمان را از پلاسما پاک می‌کند.",
   "کورتیکواستروئید در کارآزمایی‌ها بی‌اثر بوده و توصیه نمی‌شود."
  ],
  "points_en": [
   "The classic history: a respiratory or gastrointestinal infection, then ascending symmetric weakness over days.",
   "Reduced or absent tendon reflexes is a key examination finding.",
   "The most dangerous complication is respiratory failure, occurring in about twenty to thirty percent.",
   "Monitoring vital capacity in a critical care setting is therefore essential.",
   "The twenty-thirty-forty rule: a vital capacity under twenty millilitres per kilogram is a warning.",
   "Autonomic instability is also common: blood pressure swings and cardiac arrhythmia.",
   "Specific treatment has only two options: intravenous immunoglobulin or plasmapheresis.",
   "Plasmapheresis clears antibodies and complement from the plasma.",
   "Corticosteroids were ineffective in trials and are not recommended."
  ]
 },
 "explanation_fa": "این سؤال همان اصل مهم را از زاویه‌ی دیگری می‌آزماید، پس ارزش تکرار دارد. تشخیص از شرح حال قطعی است: عفونت تنفسی دو هفته قبل، ضعف قرینه‌ای که از پایین شروع شده و بالا رفته، و کاهش رفلکس‌های وتری. این گیلن باره است. حالا سه گزینه اقدام درست‌اند و یکی نادرست. پلاسمافرز یکی از دو درمان اختصاصی مؤثر است. هپارین پروفیلاکسی در بیماری که نمی‌تواند بایستد ضروری است چون خطر ترومبوز ورید عمقی بالاست. مراقبت در بخش ویژه هم به‌خاطر خطر نارسایی تنفسی و بی‌ثباتی اتونوم لازم است؛ حتی بیمارانی که در ابتدا خوب به نظر می‌رسند می‌توانند طی ساعت‌ها بدتر شوند. تنها گزینه‌ی نادرست کورتیکواستروئید است که در این بیماری هیچ سودی ندارد.",
 "explanation_en": "This item tests the same important principle from another angle, so it is worth repeating. The diagnosis is certain from the history: a respiratory infection two weeks earlier, symmetric weakness starting low and ascending, and reduced tendon reflexes. This is Guillain-Barre syndrome. Now three options are correct actions and one is not. Plasmapheresis is one of the two effective specific treatments. Prophylactic heparin is essential in a patient who cannot stand, because deep vein thrombosis risk is high. ICU monitoring is needed for the risk of respiratory failure and autonomic instability; even patients who look well initially can deteriorate within hours. The only incorrect option is the corticosteroid, which gives no benefit in this disease.",
 "why_fa": [
  "پاسخ صحیح (گزینه‌ی نادرست) — کورتیکواستروئید در گیلن باره اثری ندارد. کارآزمایی‌های تصادفی هیچ سودی نشان نداده‌اند و استروئید خوراکی ممکن است بهبود را کند کند.",
  "پلاسمافرز درمان اختصاصی مؤثر است و هرچه زودتر در دو هفته‌ی اول شروع شود، سود بیشتری دارد.",
  "هپارین پروفیلاکسی در بیمار بی‌حرکت با ضعف شدید اندام‌ها ضروری است تا از ترومبوز ورید عمقی و آمبولی ریه جلوگیری شود.",
  "مراقبت در بخش ویژه برای پایش ظرفیت حیاتی و ریتم قلب لازم است، چون نارسایی تنفسی و آریتمی می‌توانند سریع بروز کنند."
 ],
 "why_en": [
  "Correct answer (the incorrect option) — corticosteroids have no effect in Guillain-Barre syndrome. Randomised trials showed no benefit and oral steroids may slow recovery.",
  "Plasmapheresis is an effective specific treatment and the earlier it starts within the first two weeks, the greater the benefit.",
  "Prophylactic heparin is essential in an immobile patient with severe limb weakness, to prevent deep vein thrombosis and pulmonary embolism.",
  "ICU care is needed to monitor vital capacity and cardiac rhythm, because respiratory failure and arrhythmia can develop rapidly."
 ],
 "golden_fa": "گیلن باره: IVIG یا پلاسمافرز + پایش تنفس + پروفیلاکسی ترومبوز. استروئید هرگز.",
 "golden_en": "Guillain-Barre: IVIG or plasmapheresis, respiratory monitoring and thrombosis prophylaxis. Never steroids.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 9: Guillain-Barre syndrome, management",
  "Hughes RAC et al. Corticosteroids for Guillain-Barre syndrome. Cochrane Database Syst Rev 2016;10:CD001446"
 ]
}

L["1402-06:99"] = {
 "stem_en": "A 55-year-old patient with ischaemic stroke is admitted to the ICU. On examination he is quadriplegic and can only make vertical eye movements and blink. Where is the lesion?",
 "options_en": ["Anterior pons", "Medulla", "Frontal cortex", "Cerebellum"],
 "micro": {
  "lead_fa": "سندرم قفل‌شدگی از انفارکت قسمت قدامی پونز می‌آید و حرکت عمودی چشم را حفظ می‌کند.",
  "lead_en": "Locked-in syndrome arises from an anterior pontine infarct and preserves vertical eye movement.",
  "points_fa": [
   "قسمت قدامی پونز مسیرهای کورتیکواسپاینال و کورتیکوبولبار را در خود دارد.",
   "انسداد شریان بازیلار این ناحیه را دچار انفارکت می‌کند.",
   "نتیجه فلج چهار اندام و فلج عضلات صورت، جویدن، بلع و تکلم است.",
   "هسته‌ی عصب ششم هم در پونز است، پس حرکت افقی چشم از بین می‌رود.",
   "اما هسته‌ی عصب سوم در مغز میانی و بالاتر از ضایعه قرار دارد.",
   "بنابراین حرکت عمودی چشم و پلک زدن سالم می‌ماند.",
   "بسیار مهم: سیستم فعال‌کننده‌ی مشبک صعودی آسیب نمی‌بیند، پس بیمار کاملاً هوشیار است.",
   "بیمار همه چیز را می‌شنود و می‌فهمد اما فقط با چشم می‌تواند ارتباط بگیرد.",
   "این حالت را نباید با کما یا حالت رویشی اشتباه گرفت؛ خطای فاجعه‌باری است."
  ],
  "points_en": [
   "The anterior pons carries the corticospinal and corticobulbar tracts.",
   "Basilar artery occlusion infarcts this region.",
   "The result is quadriplegia plus paralysis of facial, chewing, swallowing and speech muscles.",
   "The sixth nerve nucleus is also in the pons, so horizontal eye movement is lost.",
   "But the third nerve nucleus lies in the midbrain, above the lesion.",
   "So vertical eye movement and blinking are preserved.",
   "Crucially, the ascending reticular activating system is spared, so the patient is fully conscious.",
   "The patient hears and understands everything but can communicate only with the eyes.",
   "This state must not be mistaken for coma or a vegetative state; that is a catastrophic error."
  ]
 },
 "explanation_fa": "این سؤال یک نقشه‌برداری آناتومیک دقیق می‌خواهد. از یافته‌ها شروع کنید. بیمار کوادری‌پلژیک است، یعنی هر دو مسیر کورتیکواسپاینال قطع شده‌اند و ضایعه باید در جایی باشد که این دو مسیر نزدیک هم عبور می‌کنند: ساقه‌ی مغز. بیمار حرکت افقی چشم ندارد اما حرکت عمودی و پلک زدن دارد. حرکت افقی به عصب ششم و مرکز نگاه افقی در پونز نیاز دارد، پس پونز درگیر است. حرکت عمودی به عصب سوم و مرکز نگاه عمودی در مغز میانی نیاز دارد، و چون سالم است پس ضایعه پایین‌تر از مغز میانی است. جمع این دو یعنی پونز. و چون بیمار هوشیار است، ضایعه باید در قسمت قدامی پونز باشد نه در تگمنتوم که سیستم فعال‌کننده‌ی مشبک آنجاست.",
 "explanation_en": "This item demands precise anatomical mapping. Start from the findings. The patient is quadriplegic, so both corticospinal tracts are interrupted and the lesion must lie where those tracts run close together: the brainstem. He has no horizontal eye movement but retains vertical movement and blinking. Horizontal gaze needs the sixth nerve and the pontine horizontal gaze centre, so the pons is involved. Vertical gaze needs the third nerve and the midbrain vertical gaze centre, and since it is intact the lesion lies below the midbrain. Together that means the pons. And because the patient is conscious, the lesion must be in the anterior pons rather than the tegmentum, where the reticular activating system sits.",
 "why_fa": [
  "پاسخ صحیح — انفارکت قدام پونز مسیرهای حرکتی را قطع می‌کند اما تگمنتوم و مغز میانی سالم می‌مانند، پس هوشیاری و حرکت عمودی چشم حفظ می‌شود.",
  "ضایعه‌ی مدولا سندرم‌هایی مانند والنبرگ می‌سازد که با آتاکسی، اختلال بلع و از دست رفتن حس متقاطع همراه است، نه کوادری‌پلژی با حرکت عمودی چشم.",
  "ضایعه‌ی کورتکس فرونتال دوطرفه بسیار نامحتمل است و اگر رخ دهد هوشیاری و رفتار را به‌شدت مختل می‌کند. الگوی حرکات چشم هم متفاوت است.",
  "ضایعه‌ی مخچه آتاکسی، دیس‌متری و نیستاگموس می‌دهد. مخچه مسیر حرکتی نزولی ندارد، پس فلج چهار اندام نمی‌سازد."
 ],
 "why_en": [
  "Correct — an anterior pontine infarct cuts the motor tracts while sparing the tegmentum and midbrain, so consciousness and vertical eye movement are preserved.",
  "A medullary lesion produces syndromes such as Wallenberg with ataxia, dysphagia and crossed sensory loss, not quadriplegia with vertical eye movement.",
  "A bilateral frontal cortical lesion is very unlikely and would severely disturb consciousness and behaviour. The eye movement pattern would also differ.",
  "A cerebellar lesion gives ataxia, dysmetria and nystagmus. The cerebellum has no descending motor tract, so it cannot cause quadriplegia."
 ],
 "golden_fa": "کوادری‌پلژی + فقط حرکت عمودی چشم + هوشیار = قفل‌شدگی = قدام پونز.",
 "golden_en": "Quadriplegia plus vertical eye movement only plus full consciousness means locked-in syndrome from the anterior pons.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 4: Locked-in syndrome",
  "Aminoff MJ et al. Clinical Neurology, 11th ed (2021) — Ch. 13: Basilar artery occlusion"
 ]
}

L["1402-06:100"] = {
 "stem_en": "A 50-year-old patient complains of hand tremor. On examination his steps are short, and rest tremor of the right hand and right-sided rigidity are evident. His MRI is normal. Which treatment do you suggest?",
 "options_en": ["Tetrabenazine", "Primidone", "Levodopa", "D-penicillamine"],
 "micro": {
  "lead_fa": "شروع یک‌طرفه، لرزش استراحت، ریژیدیتی و قدم‌های کوتاه با MRI طبیعی، یعنی پارکینسون ایدیوپاتیک.",
  "lead_en": "Unilateral onset, rest tremor, rigidity and short steps with a normal MRI mean idiopathic Parkinson disease.",
  "points_fa": [
   "بیماری پارکینسون تشخیص بالینی است و MRI برای رد کردن علل ثانویه انجام می‌شود.",
   "MRI طبیعی در واقع به نفع تشخیص است، چون پارکینسونیسم عروقی را رد می‌کند.",
   "عدم تقارن مشخصه‌ی بارز پارکینسون ایدیوپاتیک است.",
   "لرزش، ریژیدیتی و برادی‌کینزی معمولاً از یک سمت شروع می‌شوند.",
   "قدم‌های کوتاه یا shuffling gait از تظاهرات برادی‌کینزی محوری است.",
   "لوودوپا مؤثرترین درمان همه‌ی علائم حرکتی است.",
   "پاسخ خوب به لوودوپا خودش یک معیار تأییدی تشخیص است.",
   "هر داروی دیگری در گزینه‌ها برای یک اختلال حرکتی متفاوت طراحی شده است.",
   "شناختن این تناظرهای دارو-بیماری، کلید حل سریع این نوع سؤال است."
  ],
  "points_en": [
   "Parkinson disease is a clinical diagnosis and MRI is done to exclude secondary causes.",
   "A normal MRI actually supports the diagnosis, because it excludes vascular parkinsonism.",
   "Asymmetry is a prominent hallmark of idiopathic Parkinson disease.",
   "Tremor, rigidity and bradykinesia usually begin on one side.",
   "Short or shuffling steps are a manifestation of axial bradykinesia.",
   "Levodopa is the most effective treatment for all motor features.",
   "A good levodopa response is itself a supportive diagnostic criterion.",
   "Every other drug in the options was designed for a different movement disorder.",
   "Knowing these drug-disease pairings is the key to solving this type of question quickly."
  ]
 },
 "explanation_fa": "بهترین راه حل این سؤال، تناظر دارو به بیماری است. اول تشخیص را بگذارید: لرزش در حال استراحت، ریژیدیتی، قدم‌های کوتاه و همه یک‌طرفه، به‌علاوه‌ی MRI طبیعی. این پارکینسون ایدیوپاتیک است و توجه کنید که طبیعی بودن MRI نقطه‌ی ضعف نیست بلکه نقطه‌ی قوت است، چون پارکینسونیسم عروقی و هیدروسفالی را کنار می‌گذارد. حالا چهار دارو را نگاه کنید: تترابنازین برای کره، پریمیدون برای ترمور اسانسیل، لوودوپا برای پارکینسون و دی‌پنی‌سیلامین برای بیماری ویلسون. هر کدام آدرس روشنی دارند. تنها گزینه‌ای که به تشخیص ما می‌خورد لوودوپا است. این نوع سؤال را می‌توان در چند ثانیه حل کرد اگر این چهار تناظر را از قبل بدانید.",
 "explanation_en": "The best way to solve this is drug-to-disease pairing. First fix the diagnosis: rest tremor, rigidity, short steps, all unilateral, plus a normal MRI. This is idiopathic Parkinson disease, and note that the normal MRI is a strength rather than a weakness, because it excludes vascular parkinsonism and hydrocephalus. Now look at the four drugs: tetrabenazine for chorea, primidone for essential tremor, levodopa for Parkinson disease, and D-penicillamine for Wilson disease. Each has a clear address. The only option matching our diagnosis is levodopa. This type of question can be solved in seconds if you know those four pairings in advance.",
 "why_fa": [
  "تترابنازین مهارکننده‌ی VMAT2 است و دوپامین را تخلیه می‌کند. برای کره‌ی هانتینگتون و دیسکینزی تأخیری کاربرد دارد و در پارکینسون علائم را بدتر می‌کند.",
  "پریمیدون برای ترمور اسانسیل است. لرزش این بیمار در حالت استراحت است، نه حین عمل، پس تشخیص متفاوت است.",
  "پاسخ صحیح — لوودوپا مؤثرترین درمان علائم حرکتی پارکینسون است و پاسخ خوب به آن تشخیص را هم تأیید می‌کند.",
  "دی‌پنی‌سیلامین شلاتور مس و درمان بیماری ویلسون است. ویلسون معمولاً زیر چهل سالگی و با علائم کبدی و حلقه‌ی کایزر-فلایشر بروز می‌کند."
 ],
 "why_en": [
  "Tetrabenazine is a VMAT2 inhibitor that depletes dopamine. It treats Huntington chorea and tardive dyskinesia and would worsen parkinsonism.",
  "Primidone is for essential tremor. This patient's tremor is at rest rather than on action, so the diagnosis differs.",
  "Correct — levodopa is the most effective treatment for the motor features of Parkinson disease and a good response also supports the diagnosis.",
  "D-penicillamine is a copper chelator treating Wilson disease, which usually presents under forty with hepatic signs and Kayser-Fleischer rings."
 ],
 "golden_fa": "تترابنازین←کره، پریمیدون←ترمور اسانسیل، لوودوپا←پارکینسون، دی‌پنی‌سیلامین←ویلسون.",
 "golden_en": "Tetrabenazine for chorea, primidone for essential tremor, levodopa for Parkinson, D-penicillamine for Wilson.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 11: Movement disorders, pharmacotherapy",
  "Postuma RB et al. MDS clinical diagnostic criteria for Parkinson's disease. Mov Disord 2015;30:1591-601"
 ]
}

L["1402-12:97"] = {
 "stem_en": "A patient with fever, headache and reduced consciousness is a candidate for lumbar puncture. Which of the following is a contraindication to this procedure?",
 "options_en": ["Scoliosis of the vertebral column", "Normal pressure hydrocephalus",
                "Local infection at the puncture site", "Ischaemic stroke one year ago"],
 "micro": {
  "lead_fa": "عفونت پوستی در محل ورود سوزن، باکتری را مستقیم به فضای زیرعنکبوتیه می‌برد.",
  "lead_en": "Skin infection at the needle entry site would carry bacteria straight into the subarachnoid space.",
  "points_fa": [
   "پونکسیون کمری برای تشخیص مننژیت، انسفالیت و خون‌ریزی زیرعنکبوتیه ضروری است.",
   "چهار منع مصرف اصلی دارد که باید حفظ باشند.",
   "اول: افزایش فشار داخل جمجمه با اثر توده‌ای، به‌خاطر خطر فتق مغزی.",
   "دوم: عفونت پوست یا بافت نرم در محل ورود سوزن.",
   "سوم: اختلال انعقادی شدید یا شمارش پلاکت زیر پنجاه هزار.",
   "چهارم: بی‌ثباتی شدید قلبی-تنفسی که وضعیت‌دهی بیمار را خطرناک می‌کند.",
   "علت منع دوم روشن است: سوزن باکتری را از پوست به مایع نخاعی می‌برد.",
   "نتیجه‌اش می‌تواند مننژیت ایاتروژنیک باشد که به‌خودی‌خود کشنده است.",
   "در این موارد باید محل دیگری انتخاب شود یا عفونت پوست ابتدا درمان شود."
  ],
  "points_en": [
   "Lumbar puncture is essential for diagnosing meningitis, encephalitis and subarachnoid haemorrhage.",
   "It has four main contraindications worth memorising.",
   "First: raised intracranial pressure with mass effect, because of herniation risk.",
   "Second: infection of skin or soft tissue at the needle entry site.",
   "Third: severe coagulopathy or a platelet count below fifty thousand.",
   "Fourth: severe cardiorespiratory instability making positioning dangerous.",
   "The reason for the second is clear: the needle carries bacteria from skin into the CSF.",
   "The result can be iatrogenic meningitis, itself potentially fatal.",
   "In such cases choose another site or treat the skin infection first."
  ]
 },
 "explanation_fa": "برای پاسخ باید فهرست منع مصرف‌های پونکسیون کمری را بشناسید و سه گزینه‌ی مزاحم را رد کنید. اسکولیوز پونکسیون را از نظر فنی سخت‌تر می‌کند و ممکن است به راهنمایی فلوروسکوپی نیاز شود، اما منع مصرف نیست. هیدروسفالی با فشار طبیعی نه‌تنها منع مصرف نیست، بلکه پونکسیون کمری در آن هم ابزار تشخیصی است و هم گاهی درمان علامتی، چون برداشتن مایع می‌تواند راه رفتن بیمار را موقتاً بهتر کند. سابقه‌ی سکته‌ی ایسکمیک یک سال قبل کاملاً بی‌ربط است و هیچ اثری بر ایمنی امروز ندارد. اما عفونت موضعی در محل پونکسیون منع مصرف مطلق است، چون سوزن هنگام عبور، باکتری‌های پوست را با خود به فضای زیرعنکبوتیه می‌برد و می‌تواند مننژیت ایاتروژنیک بسازد.",
 "explanation_en": "To answer this you need the contraindication list for lumbar puncture and must reject three distractors. Scoliosis makes the procedure technically harder and may require fluoroscopic guidance, but it is not a contraindication. Normal pressure hydrocephalus is not only not a contraindication but one where lumbar puncture is both a diagnostic tool and sometimes symptomatic treatment, since removing fluid can transiently improve gait. An ischaemic stroke a year ago is entirely irrelevant and has no bearing on today's safety. But local infection at the puncture site is an absolute contraindication, because the needle carries skin bacteria into the subarachnoid space as it passes and can cause iatrogenic meningitis.",
 "why_fa": [
  "اسکولیوز فقط انجام کار را از نظر فنی دشوارتر می‌کند و ممکن است نیاز به هدایت تصویری داشته باشد، اما منع مصرف محسوب نمی‌شود.",
  "هیدروسفالی با فشار نرمال منع مصرف نیست. برعکس، آزمون برداشت مایع نخاعی بخشی از ارزیابی این بیماران برای تصمیم به شانت‌گذاری است.",
  "پاسخ صحیح — عفونت پوست یا بافت نرم در محل ورود سوزن منع مصرف مطلق است، چون خطر انتقال باکتری به فضای زیرعنکبوتیه دارد.",
  "سابقه‌ی سکته‌ی ایسکمیک یک سال قبل ارتباطی با ایمنی پونکسیون کمری امروز ندارد، مگر آنکه بیمار داروی ضدانعقاد مصرف کند."
 ],
 "why_en": [
  "Scoliosis only makes the procedure technically harder and may need image guidance, but it is not a contraindication.",
  "Normal pressure hydrocephalus is not a contraindication. On the contrary, a CSF tap test is part of assessing these patients for shunting.",
  "Correct — infection of skin or soft tissue at the needle entry site is an absolute contraindication, because of the risk of seeding bacteria into the subarachnoid space.",
  "An ischaemic stroke a year ago has no bearing on the safety of lumbar puncture today, unless the patient is on anticoagulants."
 ],
 "golden_fa": "منع LP: فشار بالا با اثر توده‌ای، عفونت محل ورود، اختلال انعقاد، بی‌ثباتی حیاتی.",
 "golden_en": "LP contraindications: raised pressure with mass effect, infection at the site, coagulopathy and haemodynamic instability.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 2: Lumbar puncture",
  "Engelborghs S et al. Consensus guidelines for lumbar puncture. Alzheimers Dement 2017;8:111-26"
 ]
}

L["1402-12:98"] = {
 "stem_en": "A patient presents with gradually progressive paraparesis over the past week. Examination shows generalised hyporeflexia and bilateral facial palsy. Which paraclinical method is appropriate for diagnosis?",
 "options_en": ["EEG", "EMG-NCS", "Lumbar MRI", "Cervical MRA"],
 "micro": {
  "lead_fa": "هایپورفلکسی و فلج صورت دوطرفه یعنی مشکل محیطی است، پس نوار عصب و عضله را انتخاب کنید.",
  "lead_en": "Hyporeflexia with bilateral facial palsy means a peripheral problem, so choose nerve conduction studies.",
  "points_fa": [
   "اولین سؤال در هر ضعف حاد این است: نورون حرکتی فوقانی یا تحتانی؟",
   "ضایعه‌ی نورون حرکتی فوقانی رفلکس‌ها را زیاد و بابنسکی را مثبت می‌کند.",
   "ضایعه‌ی نورون حرکتی تحتانی رفلکس‌ها را کم یا حذف می‌کند.",
   "در این بیمار هایپورفلکسی منتشر داریم، پس مشکل محیطی است.",
   "فلج صورت دوطرفه یک نشانه‌ی کمیاب و ارزشمند است.",
   "علل فلج صورت دوطرفه: گیلن باره، سارکوئیدوز، بیماری لایم و HIV.",
   "ترکیب پاراپارزی پیش‌رونده، آرفلکسی و فلج صورت دوطرفه یعنی گیلن باره.",
   "نوار عصب و عضله کندی سرعت هدایت و افزایش لتانسی موج F را نشان می‌دهد.",
   "افزایش لتانسی موج F زودترین یافته است چون ریشه‌های پروگزیمال زودتر درگیر می‌شوند."
  ],
  "points_en": [
   "The first question in any acute weakness is: upper or lower motor neuron?",
   "An upper motor neuron lesion increases reflexes and gives a positive Babinski.",
   "A lower motor neuron lesion reduces or abolishes reflexes.",
   "This patient has generalised hyporeflexia, so the problem is peripheral.",
   "Bilateral facial palsy is a rare and valuable sign.",
   "Causes of bilateral facial palsy: Guillain-Barre syndrome, sarcoidosis, Lyme disease and HIV.",
   "Progressive paraparesis with areflexia and bilateral facial palsy means Guillain-Barre syndrome.",
   "Nerve conduction studies show slowed conduction velocity and prolonged F-wave latency.",
   "Prolonged F-wave latency is the earliest finding because proximal roots are affected first."
  ]
 },
 "explanation_fa": "این سؤال یک تمرین موضع‌یابی است. با دو یافته‌ی معاینه شروع کنید. هایپورفلکسی ژنرالیزه بلافاصله می‌گوید مشکل در نورون حرکتی تحتانی یا اعصاب محیطی است، نه در نخاع یا مغز که رفلکس‌ها را زیاد می‌کنند. فلج فاسیال دوطرفه هم می‌گوید اعصاب کرانیال درگیرند، پس یک ضایعه‌ی موضعی در نخاع نمی‌تواند همه چیز را توضیح دهد. این دو با هم یک پلی‌رادیکولونوروپاتی منتشر را نشان می‌دهند، یعنی گیلن باره. حالا میان گزینه‌ها: نوار مغز برای صرع است و اینجا کاربردی ندارد. MRI کمری اگر مشکل نخاعی بود مفید بود، اما آن حالت رفلکس‌ها را زیاد می‌کرد نه کم. آنژیوگرافی MR گردن عروق را می‌بیند و بی‌ربط است. نوار عصب و عضله تنها ابزاری است که مستقیماً اعصاب محیطی را می‌سنجد.",
 "explanation_en": "This item is a localisation exercise. Start with two examination findings. Generalised hyporeflexia immediately says the problem is in the lower motor neuron or peripheral nerves, not the cord or brain, which would increase reflexes. Bilateral facial palsy says cranial nerves are involved, so a focal cord lesion cannot explain everything. Together they indicate a diffuse polyradiculoneuropathy, that is Guillain-Barre syndrome. Now among the options: EEG is for epilepsy and is useless here. Lumbar MRI would help if the problem were spinal, but that would raise reflexes rather than lower them. Cervical MR angiography looks at vessels and is irrelevant. Nerve conduction study is the only tool that directly assesses peripheral nerves.",
 "why_fa": [
  "نوار مغز فعالیت الکتریکی قشر را ثبت می‌کند و برای صرع و انسفالوپاتی کاربرد دارد. در ضعف محیطی هیچ اطلاعاتی نمی‌دهد.",
  "پاسخ صحیح — نوار عصب و عضله کندی هدایت، بلوک هدایتی و افزایش لتانسی موج F را نشان می‌دهد و پلی‌نوروپاتی دمیلینه را تأیید می‌کند.",
  "MRI کمری برای فشار روی نخاع یا ریشه‌ها مفید است. اما ضایعه‌ی فشارنده‌ی نخاعی فلج صورت دوطرفه نمی‌سازد و رفلکس‌ها را زیاد می‌کند.",
  "آنژیوگرافی MR گردن عروق کاروتید و ورتبرال را بررسی می‌کند و هیچ ارتباطی با پاراپارزی محیطی و فلج صورت ندارد."
 ],
 "why_en": [
  "EEG records cortical electrical activity and is used for epilepsy and encephalopathy. It gives no information in peripheral weakness.",
  "Correct — nerve conduction studies show slowed conduction, conduction block and prolonged F-wave latency, confirming a demyelinating polyneuropathy.",
  "Lumbar MRI helps with cord or root compression. But a compressive cord lesion does not cause bilateral facial palsy and would raise reflexes.",
  "Cervical MR angiography assesses the carotid and vertebral vessels and has no relation to peripheral paraparesis and facial palsy."
 ],
 "golden_fa": "رفلکس کم = محیطی = EMG-NCS. رفلکس زیاد = مرکزی = MRI.",
 "golden_en": "Low reflexes mean peripheral, so EMG-NCS. High reflexes mean central, so MRI.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 9: Guillain-Barre syndrome, electrodiagnosis",
  "Aminoff MJ et al. Clinical Neurology, 11th ed (2021) — Ch. 2: Electrodiagnostic studies"
 ]
}

L["1402-12:99"] = {
 "stem_en": "Which of the following is an advantage of magnetic resonance imaging over brain CT?",
 "options_en": ["Lower cost", "Shorter imaging time",
                "Better visualisation of calcification", "Detection of demyelinating plaques"],
 "micro": {
  "lead_fa": "MRI ماده‌ی سفید را با کنتراست بالا نشان می‌دهد، پس پلاک‌های دمیلینه فقط در آن دیده می‌شوند.",
  "lead_en": "MRI shows white matter with high contrast, so demyelinating plaques are visible only on it.",
  "points_fa": [
   "سی‌تی از اشعه‌ی ایکس و تفاوت چگالی بافت‌ها تصویر می‌سازد.",
   "MRI از رفتار پروتون‌های آب در میدان مغناطیسی تصویر می‌سازد.",
   "همین تفاوت بنیادی، نقاط قوت هر کدام را تعیین می‌کند.",
   "برتری سی‌تی: سرعت، در دسترس بودن، ارزانی و دیدن خون حاد و استخوان و کلسیفیکاسیون.",
   "به همین دلیل در تروما و سکته‌ی حاد، سی‌تی اولین تصویربرداری است.",
   "برتری MRI: کنتراست عالی بافت نرم و تفکیک ماده‌ی سفید از خاکستری.",
   "توالی FLAIR پلاک‌های دمیلینه را روشن و واضح نشان می‌دهد.",
   "MRI برای حفره‌ی خلفی و ساقه‌ی مغز بسیار بهتر است چون آرتیفکت استخوانی ندارد.",
   "توالی انتشاری MRI انفارکت حاد را در چند دقیقه‌ی اول نشان می‌دهد."
  ],
  "points_en": [
   "CT builds its image from X-rays and differences in tissue density.",
   "MRI builds its image from the behaviour of water protons in a magnetic field.",
   "That fundamental difference determines each modality's strengths.",
   "CT advantages: speed, availability, low cost and visualising acute blood, bone and calcification.",
   "That is why CT is the first imaging study in trauma and acute stroke.",
   "MRI advantages: excellent soft tissue contrast and separation of white from grey matter.",
   "The FLAIR sequence shows demyelinating plaques brightly and clearly.",
   "MRI is far better for the posterior fossa and brainstem because it has no bone artefact.",
   "Diffusion-weighted MRI shows an acute infarct within the first few minutes."
  ]
 },
 "explanation_fa": "این سؤال با یک منطق ساده حل می‌شود: سه گزینه در واقع برتری سی‌تی هستند و فقط یکی برتری MRI. قیمت پایین‌تر مال سی‌تی است؛ MRI چند برابر گران‌تر است. زمان کوتاه‌تر هم مال سی‌تی است؛ یک سی‌تی مغز چند ثانیه طول می‌کشد در حالی که MRI بیست تا چهل دقیقه زمان می‌برد. مشاهده‌ی بهتر کلسیفیکاسیون هم قطعاً مال سی‌تی است، چون کلسیم اشعه‌ی ایکس را شدید جذب می‌کند و روشن دیده می‌شود، اما در MRI معمولاً سیگنال پایینی دارد و ممکن است اصلاً دیده نشود. تنها گزینه‌ی باقی‌مانده، تشخیص پلاک‌های دمیلینه، دقیقاً نقطه‌ی قوت MRI است. پلاک‌های ام‌اس تغییرات ظریفی در محتوای آب ماده‌ی سفید ایجاد می‌کنند که سی‌تی اصلاً نمی‌بیند ولی توالی FLAIR در MRI آن‌ها را روشن نشان می‌دهد.",
 "explanation_en": "This item is solved by a simple logic: three options are actually CT advantages and only one is an MRI advantage. Lower cost belongs to CT; MRI is several times more expensive. Shorter time also belongs to CT; a head CT takes seconds whereas MRI takes twenty to forty minutes. Better visualisation of calcification is definitely CT's, because calcium absorbs X-rays strongly and appears bright, whereas on MRI it usually has low signal and may be invisible. The only remaining option, detection of demyelinating plaques, is exactly MRI's strength. Multiple sclerosis plaques cause subtle changes in white matter water content that CT cannot see at all, while the FLAIR sequence on MRI displays them brightly.",
 "why_fa": [
  "قیمت پایین‌تر برتری سی‌تی است. MRI به‌طور معمول چند برابر سی‌تی هزینه دارد و در دسترس بودنش هم کمتر است.",
  "زمان کوتاه‌تر هم برتری سی‌تی است. سرعت بالای سی‌تی دلیل اصلی استفاده از آن در تروما و سکته‌ی حاد است.",
  "کلسیفیکاسیون در سی‌تی بسیار بهتر دیده می‌شود چون کلسیم چگالی بالایی دارد. در MRI کلسیم سیگنال کمی دارد و ممکن است از قلم بیفتد.",
  "پاسخ صحیح — کنتراست عالی MRI در ماده‌ی سفید، پلاک‌های دمیلینه‌ی ام‌اس را نشان می‌دهد؛ چیزی که سی‌تی قادر به دیدن آن نیست."
 ],
 "why_en": [
  "Lower cost is a CT advantage. MRI routinely costs several times more and is also less available.",
  "Shorter time is also a CT advantage. CT's speed is the main reason it is used in trauma and acute stroke.",
  "Calcification is much better seen on CT because calcium has high density. On MRI calcium has low signal and may be missed.",
  "Correct — MRI's excellent white matter contrast reveals demyelinating plaques, which CT cannot see."
 ],
 "golden_fa": "سی‌تی: سریع، ارزان، خون حاد، استخوان، کلسیم. MRI: ماده‌ی سفید، حفره‌ی خلفی، پلاک دمیلینه.",
 "golden_en": "CT: fast, cheap, acute blood, bone, calcium. MRI: white matter, posterior fossa, demyelinating plaques.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 2: Neuroimaging, CT versus MRI",
  "Wattjes MP et al. MAGNIMS-CMSC-NAIMS consensus recommendations on the use of MRI in multiple sclerosis. Lancet Neurol 2021;20:653-70"
 ]
}

L["1402-12:100"] = {
 "stem_en": "A 24-year-old woman presents with recurrent headache attacks. During attacks she has nausea and intolerance of light and sound. Over the past three months her headache frequency has risen to once a week. All of the following are appropriate for preventive treatment EXCEPT:",
 "options_en": ["Topiramate", "Propranolol", "Sumatriptan", "Amitriptyline"],
 "micro": {
  "lead_fa": "سوماتریپتان داروی قطع حمله است و هرگز به‌عنوان پیشگیری روزانه تجویز نمی‌شود.",
  "lead_en": "Sumatriptan is an abortive drug and is never prescribed as daily prevention.",
  "points_fa": [
   "تهوع، ترس از نور و ترس از صدا سه علامت همراه کلاسیک میگرن‌اند.",
   "افزایش فراوانی حملات اندیکاسیون شروع درمان پیشگیرانه است.",
   "فهرست پیشگیری میگرن را با چهار گروه به یاد بسپارید.",
   "بتابلوکرها: پروپرانولول و متوپرولول، خط اول با شواهد قوی.",
   "ضد صرع‌ها: توپیرامات و والپروات سدیم، هر دو خط اول.",
   "ضد افسردگی‌های سه‌حلقه‌ای: آمی‌تریپتیلین، به‌ویژه اگر بی‌خوابی هم باشد.",
   "مسدودکننده‌های کلسیم: فلوناریزین و وراپامیل.",
   "داروهای جدیدتر: آنتی‌بادی‌های ضد CGRP برای موارد مقاوم.",
   "تریپتان‌ها در هیچ‌کدام از این گروه‌ها نیستند و فقط برای حمله‌اند."
  ],
  "points_en": [
   "Nausea, photophobia and phonophobia are the three classic accompaniments of migraine.",
   "Rising attack frequency is an indication to start preventive treatment.",
   "Remember the migraine preventive list as four groups.",
   "Beta-blockers: propranolol and metoprolol, first-line with strong evidence.",
   "Anticonvulsants: topiramate and sodium valproate, both first-line.",
   "Tricyclic antidepressants: amitriptyline, especially if insomnia coexists.",
   "Calcium blockers: flunarizine and verapamil.",
   "Newer agents: anti-CGRP antibodies for refractory cases.",
   "Triptans belong to none of these groups and are only for attacks."
  ]
 },
 "explanation_fa": "این سؤال یکی از پرتکرارترین الگوهای بانک است و همیشه یک شکل دارد: سه داروی پیشگیرانه و یک داروی حمله. اول تشخیص را بگذارید که آسان است: حملات مکرر سردرد با تهوع، ترس از نور و ترس از صدا در خانم جوان، یعنی میگرن. سپس دقت کنید سؤال از درمان پیشگیرانه می‌پرسد و می‌خواهد استثنا را پیدا کنید. توپیرامات از ضد صرع‌ها، پروپرانولول از بتابلوکرها و آمی‌تریپتیلین از سه‌حلقه‌ای‌ها همگی در فهرست پیشگیری خط اول‌اند. سوماتریپتان اما تریپتان است، یعنی آگونیست انتخابی گیرنده‌های سروتونین 1B و 1D که برای قطع حمله‌ی در جریان طراحی شده است. مصرف روزانه‌ی آن نه‌تنها پیشگیری نمی‌کند بلکه سردرد ناشی از مصرف بیش از حد دارو می‌سازد.",
 "explanation_en": "This is one of the most repeated patterns in the bank and always has the same shape: three preventive drugs and one abortive. First fix the diagnosis, which is easy: recurrent headache attacks with nausea, photophobia and phonophobia in a young woman means migraine. Then note that the question asks about preventive treatment and wants the exception. Topiramate from the anticonvulsants, propranolol from the beta-blockers and amitriptyline from the tricyclics are all first-line preventives. Sumatriptan, however, is a triptan, a selective serotonin 1B and 1D receptor agonist designed to abort an attack in progress. Taking it daily does not prevent anything and instead produces medication-overuse headache.",
 "why_fa": [
  "توپیرامات ضد صرع و از داروهای خط اول پیشگیری میگرن است. در بیماران با اضافه وزن مزیت دارد اما در بارداری باید پرهیز شود.",
  "پروپرانولول بتابلوکر و شاید شناخته‌شده‌ترین داروی پیشگیری میگرن است. در آسم و برادی‌کاردی منع مصرف دارد.",
  "پاسخ صحیح (گزینه‌ی نامناسب) — سوماتریپتان داروی قطع حمله است. مصرف بیش از ده روز در ماه سردرد ناشی از مصرف بیش از حد دارو می‌سازد.",
  "آمی‌تریپتیلین ضد افسردگی سه‌حلقه‌ای و از داروهای پیشگیری میگرن است، به‌ویژه وقتی بیمار بی‌خوابی یا سردرد تنشی همزمان دارد."
 ],
 "why_en": [
  "Topiramate is an anticonvulsant and a first-line migraine preventive. It has an advantage in overweight patients but must be avoided in pregnancy.",
  "Propranolol is a beta-blocker and perhaps the best-known migraine preventive. It is contraindicated in asthma and bradycardia.",
  "Correct answer (the inappropriate option) — sumatriptan is an abortive drug. Using it more than ten days a month causes medication-overuse headache.",
  "Amitriptyline is a tricyclic antidepressant and a migraine preventive, especially useful when the patient also has insomnia or coexisting tension headache."
 ],
 "golden_fa": "پیشگیری میگرن: بتابلوکر، ضد صرع، سه‌حلقه‌ای، مسدودکننده‌ی کلسیم. تریپتان فقط برای حمله.",
 "golden_en": "Migraine prevention: beta-blockers, anticonvulsants, tricyclics, calcium blockers. Triptans are for attacks only.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 6: Migraine prophylaxis",
  "Silberstein SD et al. Evidence-based guideline update: pharmacologic treatment for episodic migraine prevention. Neurology 2012;78:1337-45"
 ]
}

L["1402-12:101"] = {
 "stem_en": "In treating herpes meningoencephalitis with acyclovir, which laboratory abnormality is expected?",
 "options_en": ["Leukopenia", "Thrombocytopenia", "Rising creatinine", "Rising liver enzymes"],
 "micro": {
  "lead_fa": "آسیکلوویر در توبول‌های کلیه کریستال می‌سازد و کراتینین را بالا می‌برد.",
  "lead_en": "Acyclovir crystallises in the renal tubules and raises creatinine.",
  "points_fa": [
   "انسفالیت هرپسی شایع‌ترین انسفالیت ویروسی کشنده و یک اورژانس عصبی است.",
   "درمان باید پیش از تأیید PCR و بر اساس شک بالینی شروع شود.",
   "دوز آسیکلوویر ده میلی‌گرم بر کیلوگرم هر هشت ساعت وریدی برای چهارده تا بیست‌ویک روز است.",
   "این دوز بالا و طولانی، عارضه‌ی کلیوی را شایع می‌کند.",
   "آسیکلوویر در ادرار حل‌پذیری کمی دارد و در توبول‌ها رسوب می‌کند.",
   "نتیجه‌اش نفروپاتی کریستالی و نارسایی حاد کلیه است.",
   "پیشگیری با هیدراتاسیون کافی و تزریق آهسته طی حداقل یک ساعت انجام می‌شود.",
   "پایش کراتینین در طول درمان الزامی است و دوز باید با کلیرانس تنظیم شود.",
   "عارضه‌ی دیگر نوروتوکسیسیته است: گیجی، توهم و لرزش، به‌ویژه در نارسایی کلیه."
  ],
  "points_en": [
   "Herpes encephalitis is the commonest fatal viral encephalitis and a neurological emergency.",
   "Treatment must begin on clinical suspicion, before PCR confirmation.",
   "The acyclovir dose is ten milligrams per kilogram every eight hours intravenously for fourteen to twenty-one days.",
   "This high, prolonged dose makes renal toxicity common.",
   "Acyclovir has low urinary solubility and precipitates in the tubules.",
   "The result is crystal nephropathy and acute kidney injury.",
   "Prevention is by adequate hydration and slow infusion over at least an hour.",
   "Monitoring creatinine during treatment is mandatory and the dose must be adjusted for clearance.",
   "The other adverse effect is neurotoxicity: confusion, hallucinations and tremor, especially in renal failure."
  ]
 },
 "explanation_fa": "پاسخ این سؤال از فارماکولوژی آسیکلوویر می‌آید و مکانیسمش کاملاً فیزیکی و قابل فهم است. آسیکلوویر عمدتاً از کلیه دفع می‌شود و در ادرار حل‌پذیری پایینی دارد. وقتی دوز بالا و وریدی داده شود، غلظت دارو در توبول‌های کلیه از حد اشباع بالاتر می‌رود و بلورهای آسیکلوویر رسوب می‌کنند. این بلورها مجرای توبول را می‌بندند و نفروپاتی کریستالی می‌سازند که خودش را با بالا رفتن کراتینین نشان می‌دهد. نکته‌ی عملی مهم این است که این عارضه تا حد زیادی قابل پیشگیری است: بیمار را خوب هیدراته کنید و دارو را طی حداقل یک ساعت انفوزیون کنید، نه به‌صورت بولوس. و در طول درمان کراتینین را مرتب چک کنید.",
 "explanation_en": "The answer comes from acyclovir pharmacology and the mechanism is purely physical and easy to grasp. Acyclovir is mainly renally excreted and has low urinary solubility. When given at high intravenous doses, its concentration in the renal tubules exceeds saturation and acyclovir crystals precipitate. These crystals obstruct the tubular lumen and cause crystal nephropathy, which shows itself as a rising creatinine. The important practical point is that this complication is largely preventable: hydrate the patient well and infuse the drug over at least an hour rather than as a bolus. And check the creatinine regularly during treatment.",
 "why_fa": [
  "لکوپنی از عوارض شاخص گان‌سیکلوویر و والگان‌سیکلوویر است، نه آسیکلوویر. آسیکلوویر سرکوب مغز استخوان چشمگیری ندارد.",
  "ترومبوسیتوپنی هم عارضه‌ی معمول آسیکلوویر نیست. در موارد بسیار نادر میکروآنژیوپاتی ترومبوتیک گزارش شده است.",
  "پاسخ صحیح — رسوب کریستال آسیکلوویر در توبول‌های کلیه نفروپاتی کریستالی می‌سازد و کراتینین را بالا می‌برد. با هیدراتاسیون و انفوزیون آهسته پیشگیری می‌شود.",
  "افزایش آنزیم‌های کبدی گاهی خفیف و گذرا دیده می‌شود، اما عارضه‌ی شاخص و مورد انتظار آسیکلوویر نیست و در پایش روتین اولویت ندارد."
 ],
 "why_en": [
  "Leukopenia is a characteristic effect of ganciclovir and valganciclovir, not acyclovir. Acyclovir does not markedly suppress the bone marrow.",
  "Thrombocytopenia is also not a usual acyclovir effect. Thrombotic microangiopathy has been reported only very rarely.",
  "Correct — acyclovir crystals precipitating in the renal tubules cause crystal nephropathy and raise creatinine. Prevent it with hydration and slow infusion.",
  "Mild transient liver enzyme rises are occasionally seen, but this is not the characteristic expected effect of acyclovir and is not the monitoring priority."
 ],
 "golden_fa": "آسیکلوویر وریدی = نفروتوکسیک. هیدراته کنید، آهسته انفوزیون کنید، کراتینین را بپایید.",
 "golden_en": "Intravenous acyclovir is nephrotoxic: hydrate, infuse slowly and monitor creatinine.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 1: Herpes simplex encephalitis, treatment",
  "Fleischer R, Johnson M. Acyclovir nephrotoxicity: a case report and review. Case Rep Med 2010;2010:602783"
 ]
}

L["1402-12:102"] = {
 "stem_en": "A 45-year-old man presents with progressive muscle weakness. He reports difficulty climbing stairs and combing his hair. Examination shows hypertrophy of the calf muscles. Given the diagnosis, which sign is expected on examination?",
 "options_en": ["Tinel", "Gowers", "Uthoff", "Lhermitte"],
 "micro": {
  "lead_fa": "ضعف پروگزیمال با هایپرتروفی کاذب ساق، یعنی دیستروفی عضلانی و علامت گاورز.",
  "lead_en": "Proximal weakness with pseudohypertrophy of the calves means muscular dystrophy and the Gowers sign.",
  "points_fa": [
   "بالا رفتن از پله عضلات کمربند لگنی می‌خواهد و شانه زدن مو عضلات کمربند شانه‌ای.",
   "ناتوانی در هر دو یعنی ضعف پروگزیمال دوطرفه، الگوی کلاسیک میوپاتی.",
   "هایپرتروفی ساق در دیستروفی‌ها هایپرتروفی کاذب است.",
   "کاذب یعنی حجم عضله زیاد شده اما با چربی و بافت فیبروز، نه با فیبر عضلانی سالم.",
   "دیستروفی بکر فرم خفیف‌تر دیستروفینوپاتی است و می‌تواند در بزرگسالی بروز کند.",
   "علامت گاورز راهبرد جبرانی برای بلند شدن از زمین با ضعف کمربند لگنی است.",
   "بیمار ابتدا چهار دست و پا می‌شود و سپس با دست‌ها روی ران‌ها بالا می‌رود.",
   "این علامت به کودکان محدود نیست و در هر ضعف پروگزیمال شدید دیده می‌شود.",
   "کراتین کیناز سرم در دیستروفینوپاتی‌ها بسیار بالا می‌رود."
  ],
  "points_en": [
   "Climbing stairs needs pelvic girdle muscles and combing hair needs shoulder girdle muscles.",
   "Inability to do both means bilateral proximal weakness, the classic myopathic pattern.",
   "Calf hypertrophy in dystrophies is pseudohypertrophy.",
   "Pseudo means the muscle bulk has grown with fat and fibrous tissue, not healthy fibres.",
   "Becker dystrophy is the milder dystrophinopathy and can present in adulthood.",
   "The Gowers sign is a compensatory strategy for rising from the floor with pelvic girdle weakness.",
   "The patient first goes onto all fours, then walks the hands up the thighs.",
   "This sign is not limited to children and appears in any severe proximal weakness.",
   "Serum creatine kinase is markedly raised in dystrophinopathies."
  ]
 },
 "explanation_fa": "این سؤال دو مرحله دارد. مرحله‌ی اول تشخیص است. ناتوانی در بالا رفتن از پله و شانه زدن مو، هر دو کارهایی هستند که به عضلات پروگزیمال نیاز دارند، پس بیمار ضعف پروگزیمال دارد. هایپرتروفی عضلات ساق هم سرنخ دوم است و در دیستروفی‌های عضلانی دیده می‌شود؛ به آن هایپرتروفی کاذب می‌گویند چون عضله با چربی و بافت همبند جایگزین شده و بزرگ به نظر می‌رسد بدون آنکه قوی باشد. پس تشخیص دیستروفی عضلانی است، احتمالاً از نوع بکر که در بزرگسالی بروز می‌کند. مرحله‌ی دوم شناخت علامت مربوطه است. سه گزینه‌ی دیگر به بیماری‌های کاملاً متفاوتی تعلق دارند و فقط گاورز است که به ضعف کمربند لگنی مربوط می‌شود.",
 "explanation_en": "This item has two steps. Step one is the diagnosis. Difficulty climbing stairs and combing hair are both tasks requiring proximal muscles, so the patient has proximal weakness. Calf hypertrophy is the second clue and is seen in muscular dystrophies. It is called pseudohypertrophy because the muscle has been replaced by fat and connective tissue. It looks large without being strong. So the diagnosis is a muscular dystrophy, probably the Becker type presenting in adulthood. Step two is knowing the relevant sign. The other three options belong to entirely different diseases, and only Gowers relates to pelvic girdle weakness.",
 "why_fa": [
  "علامت تینل با ضربه زدن روی عصب فشرده‌شده مثبت می‌شود و پارستزی در قلمرو آن عصب می‌دهد. این نشانه‌ی سندرم تونل کارپال است، نه میوپاتی.",
  "پاسخ صحیح — علامت گاورز راهبرد بیمار برای بلند شدن از زمین با ضعف کمربند لگنی است و در دیستروفی عضلانی مورد انتظار است.",
  "پدیده‌ی اوتوف تشدید موقت علائم ام‌اس با بالا رفتن دمای بدن است، مثلاً پس از حمام گرم یا ورزش.",
  "علامت لرمیت احساس شوک برقی هنگام خم کردن گردن است و از پلاک ستون خلفی نخاع گردنی در ام‌اس می‌آید."
 ],
 "why_en": [
  "The Tinel sign is elicited by tapping over a compressed nerve, producing paresthesia in its territory. It indicates carpal tunnel syndrome, not myopathy.",
  "Correct — the Gowers sign is the patient's strategy for rising from the floor with pelvic girdle weakness and is expected in muscular dystrophy.",
  "The Uthoff phenomenon is a temporary worsening of multiple sclerosis symptoms with a rise in body temperature, such as after a hot bath or exercise.",
  "The Lhermitte sign is an electric shock sensation on neck flexion, arising from a posterior column plaque in the cervical cord in multiple sclerosis."
 ],
 "golden_fa": "ضعف پروگزیمال + هایپرتروفی کاذب ساق = دیستروفی = گاورز. اوتوف و لرمیت مال ام‌اس‌اند.",
 "golden_en": "Proximal weakness plus calf pseudohypertrophy means dystrophy and the Gowers sign. Uthoff and Lhermitte belong to multiple sclerosis.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 9: Muscular dystrophies",
  "Aminoff MJ et al. Clinical Neurology, 11th ed (2021) — Ch. 3: Eponymous neurological signs"
 ]
}

json.dump(L, io.open('/home/user/work/lessons/L12.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('L12:', len(L))
