# -*- coding: utf-8 -*-
"""Micro-lessons, batch 4 — Esfand-1400 (official English booklet supplies stem_en)."""
import json, io
L = {}

L["1400-12:117"] = {
 "micro": {
  "lead_fa": "تب + اختلال رفتار + تشنج + درگیری لوب تمپورال = آنسفالیت هرپسی، و آزمون انتخابی PCR در مایع نخاع است.",
  "lead_en": "Fever + behavioural change + seizure + temporal lobe involvement = HSV encephalitis, and CSF PCR is the test of choice.",
  "points_fa": [
   "ویروس هرپس سیمپلکس شایع‌ترین علت آنسفالیت ویروسی پراکنده و کشنده است.",
   "این ویروس تمایل خاصی به لوب تمپورال داخلی و قشر اوربیتوفرونتال دارد.",
   "همین تمایل، تصویر بالینی را می‌سازد: اختلال حافظه، رفتار عجیب و توهم بویایی.",
   "تشنج در بیش از نیمی از بیماران رخ می‌دهد و اغلب از همان لوب تمپورال شروع می‌شود.",
   "PCR ویروس در مایع نخاع حساسیت حدود ۹۶ و ویژگی حدود ۹۹ درصد دارد.",
   "این آزمون ظرف چند ساعت جواب می‌دهد و جایگزین بیوپسی مغز شده است.",
   "کشت ویروس از مایع نخاع تقریباً همیشه منفی است و ارزش بالینی ندارد.",
   "آنتی‌بادی اختصاصی دیر مثبت می‌شود، پس فقط برای تشخیص گذشته‌نگر به کار می‌آید.",
   "MRI حساس‌تر از سی‌تی است و درگیری تمپورال را زودتر نشان می‌دهد."
  ],
  "points_en": [
   "Herpes simplex virus is the commonest cause of sporadic, fatal viral encephalitis.",
   "It has a particular affinity for the medial temporal lobe and orbitofrontal cortex.",
   "That affinity shapes the clinical picture: memory impairment, bizarre behaviour and olfactory hallucinations.",
   "Seizures occur in over half of patients and often arise from the same temporal lobe.",
   "CSF PCR has about 96 per cent sensitivity and 99 per cent specificity.",
   "It returns a result within hours and has replaced brain biopsy.",
   "Viral culture from CSF is almost always negative and clinically useless.",
   "Specific antibody turns positive late, so it serves only retrospective diagnosis.",
   "MRI is more sensitive than CT and shows temporal involvement earlier."
  ]
 },
 "explanation_fa": "چهار سرنخ این بیمار به یک تشخیص می‌رسند: تب، اختلال حافظه، رفتار عجیب و غریب، و تشنج ژنرالیزه. سرنخ پنجم تصویربرداری است که هایپودنسیته و ادم در لوب‌های تمپورال نشان می‌دهد. مجموع این‌ها آنسفالیت هرپسی است. ویروس هرپس تمایل خاصی به لوب تمپورال داخلی و قشر اوربیتوفرونتال دارد، و همین تمایل توضیح می‌دهد چرا علائم حافظه‌ای و رفتاری در صدر تظاهرات‌اند. حالا سراغ آزمون تشخیصی برویم. PCR ویروس در مایع نخاع حساسیت حدود ۹۶ درصد و ویژگی حدود ۹۹ درصد دارد و ظرف چند ساعت جواب می‌دهد؛ این آزمون جایگزین بیوپسی مغز شده است. نکته‌ی حیاتی درمانی: آسیکلوویر باید بر پایه‌ی شک بالینی و پیش از رسیدن جواب شروع شود، چون هر روز تأخیر پیامد را بدتر می‌کند.",
 "explanation_en": "Four clues converge on one diagnosis: fever, memory impairment, bizarre behaviour and a generalised seizure. A fifth comes from imaging, showing hypodensity and oedema in the temporal lobes. Together these mean HSV encephalitis. The virus has a particular affinity for the medial temporal lobe and orbitofrontal cortex, which explains why memory and behavioural symptoms dominate. Now the diagnostic test. CSF PCR has about 96 per cent sensitivity and 99 per cent specificity and returns within hours; it has replaced brain biopsy. One treatment point is vital: acyclovir must be started on clinical suspicion before the result arrives, because every day of delay worsens the outcome.",
 "why_fa": [
  "آنالیز ساده‌ی مایع نخاع پلئوسیتوز لنفوسیتی و گاه گلبول قرمز نشان می‌دهد، اما هیچ‌کدام اختصاصی نیستند و تشخیص را قطعی نمی‌کنند.",
  "کشت ویروس هرپس از مایع نخاع تقریباً همیشه منفی است، چون بار ویروسی آزاد در مایع بسیار کم است. ارزش بالینی ندارد.",
  "آنتی‌بادی اختصاصی در مایع نخاع معمولاً پس از هفته‌ی اول مثبت می‌شود. برای تصمیم درمانی فوری دیر است و فقط ارزش گذشته‌نگر دارد.",
  "پاسخ صحیح — PCR ویروس در مایع نخاع با حساسیت حدود ۹۶ درصد و جواب‌دهی چند ساعته، آزمون انتخابی آنسفالیت هرپسی است."
 ],
 "why_en": [
  "Routine CSF analysis shows lymphocytic pleocytosis and sometimes red cells, but none of this is specific or diagnostic.",
  "Viral culture of HSV from CSF is almost always negative because free virus in the fluid is scarce. It has no clinical value.",
  "Specific CSF antibody usually turns positive after the first week. That is too late for an urgent treatment decision and serves only retrospectively.",
  "Correct — CSF viral PCR, with about 96 per cent sensitivity and a result within hours, is the test of choice for HSV encephalitis."
 ],
 "golden_fa": "لوب تمپورال + تب + رفتار عجیب = هرپس. PCR بگیرید، اما آسیکلوویر را منتظر جواب نگذارید.",
 "golden_en": "Temporal lobe + fever + bizarre behaviour = herpes. Send the PCR, but do not make acyclovir wait for it.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 4: Herpes simplex encephalitis",
  "Tunkel AR et al. IDSA guidelines for the management of encephalitis. Clin Infect Dis 2008;47:303-27"
 ]
}

L["1400-12:118"] = {
 "micro": {
  "lead_fa": "ضعف پا بیشتر از دست به‌علاوه‌ی بی‌اختیاری ادرار، امضای شریان مغزی قدامی است.",
  "lead_en": "Leg weakness exceeding arm weakness plus urinary incontinence is the signature of the anterior cerebral artery.",
  "points_fa": [
   "هومونکولوس حرکتی روی شکنج پیش‌مرکزی به ترتیب خاصی چیده شده است.",
   "صورت و دست در سطح خارجی نیمکره‌اند و پا در سطح داخلی، نزدیک شیار بین‌نیمکره‌ای.",
   "شریان مغزی میانی سطح خارجی را خون‌رسانی می‌کند، پس صورت و دست را درگیر می‌کند.",
   "شریان مغزی قدامی سطح داخلی را خون‌رسانی می‌کند، پس پا را درگیر می‌کند.",
   "همین تفاوت آناتومیک، مهم‌ترین ابزار موضعی‌سازی سکته‌ی نیمکره‌ای است.",
   "مرکز کنترل ارادی مثانه هم در سطح داخلی و در قلمرو ACA قرار دارد.",
   "پس بی‌اختیاری ادرار در سکته‌ی ACA شایع است و در MCA نادر.",
   "سایر علائم ACA: آبولیا، بی‌تفاوتی، رفلکس گرسپ و آپراکسی راه رفتن.",
   "در سکته‌ی MCA برعکس، آفازی یا نگلکت به‌همراه ضعف صورت و دست دیده می‌شود."
  ],
  "points_en": [
   "The motor homunculus on the precentral gyrus is laid out in a particular order.",
   "Face and hand sit on the lateral surface; the leg sits medially, near the interhemispheric fissure.",
   "The middle cerebral artery supplies the lateral surface, so it affects face and arm.",
   "The anterior cerebral artery supplies the medial surface, so it affects the leg.",
   "This anatomical difference is the single best tool for localising a hemispheric stroke.",
   "The centre for voluntary bladder control also lies medially, in ACA territory.",
   "So urinary incontinence is common in ACA stroke and rare in MCA stroke.",
   "Other ACA features: abulia, apathy, grasp reflex and gait apraxia.",
   "MCA stroke instead shows aphasia or neglect together with face and arm weakness."
  ]
 },
 "explanation_fa": "این سؤال با یک نکته‌ی آناتومیک ساده حل می‌شود. به نسبت ضعف دقت کنید: اندام فوقانی ۴/۵ اما اندام تحتانی ۲/۵، یعنی پا به‌مراتب بیشتر از دست درگیر است. حالا هومونکولوس حرکتی را روی نقشه‌ی عروق بگذارید. صورت و دست روی سطح خارجی نیمکره‌اند و از شریان مغزی میانی خون می‌گیرند، اما پا روی سطح داخلی و نزدیک شیار بین‌نیمکره‌ای قرار دارد و قلمرو شریان مغزی قدامی است. پس الگوی «پا بیشتر از دست» یعنی ACA. سرنخ دوم بی‌اختیاری ادرار است که همین تشخیص را تأیید می‌کند، چون مرکز کنترل ارادی مثانه هم روی سطح داخلی و در همان قلمرو است. برای تثبیت، الگوی معکوس را هم به یاد بسپارید: در سکته‌ی MCA صورت و دست بیشتر از پا درگیر می‌شوند و آفازی یا نگلکت همراهی می‌کند.",
 "explanation_en": "A simple anatomical point solves this item. Note the ratio of weakness: upper limb 4/5 but lower limb 2/5, so the leg is far weaker than the arm. Now lay the motor homunculus over the vascular map. Face and hand occupy the lateral surface and are supplied by the middle cerebral artery, whereas the leg lies medially near the interhemispheric fissure, in anterior cerebral artery territory. So a 'leg worse than arm' pattern means ACA. The second clue, urinary incontinence, confirms it, because the centre for voluntary bladder control also lies medially in the same territory. To consolidate, remember the reverse pattern: in MCA stroke face and arm are affected more than the leg, accompanied by aphasia or neglect.",
 "why_fa": [
  "شاخه‌ی فوقانی MCA قشر حرکتی صورت و دست را خون‌رسانی می‌کند و آفازی بروکا می‌سازد. الگوی آن ضعف دست بیشتر از پاست، یعنی برعکس این بیمار.",
  "شاخه‌ی تحتانی MCA قشر شنوایی و ناحیه‌ی ورنیکه را می‌پوشاند و آفازی حسی می‌سازد. معمولاً ضعف حرکتی چشمگیری ایجاد نمی‌کند.",
  "پاسخ صحیح — ضعف پا بیشتر از دست به‌همراه بی‌اختیاری ادرار، الگوی کلاسیک انسداد شریان مغزی قدامی است.",
  "شریان مغزی خلفی لوب اکسیپیتال را خون‌رسانی می‌کند و انسداد آن همیانوپی هومونیموس می‌دهد، نه ضعف حرکتی اندام‌ها."
 ],
 "why_en": [
  "The superior division of the MCA supplies face and hand motor cortex and causes Broca aphasia. Its pattern is arm worse than leg, the reverse of this patient.",
  "The inferior division of the MCA covers auditory cortex and Wernicke's area, causing sensory aphasia. It rarely produces significant motor weakness.",
  "Correct — leg weakness exceeding arm weakness together with urinary incontinence is the classic pattern of anterior cerebral artery occlusion.",
  "The posterior cerebral artery supplies the occipital lobe; its occlusion causes homonymous hemianopia, not limb weakness."
 ],
 "golden_fa": "پا بیشتر از دست + بی‌اختیاری ادرار = ACA. دست و صورت بیشتر از پا + آفازی = MCA.",
 "golden_en": "Leg worse than arm + incontinence = ACA. Face and arm worse than leg + aphasia = MCA.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 13: Anterior circulation syndromes",
  "Adams and Victor's Principles of Neurology, 12th ed — Cerebrovascular diseases"
 ]
}

L["1400-12:119"] = {
 "micro": {
  "lead_fa": "ضعف پس از بیداری به‌دنبال ورزش سنگین با پتاسیم پایین، فلج دوره‌ای هیپوکالمیک است؛ وعده‌ی پرکربوهیدرات محرک حمله است نه درمان.",
  "lead_en": "Weakness on waking after heavy exercise with low potassium is hypokalaemic periodic paralysis; a high-carbohydrate meal triggers attacks rather than treating them.",
  "points_fa": [
   "فلج دوره‌ای هیپوکالمیک یک کانالوپاتی ارثی با وراثت اتوزومال غالب است.",
   "جهش معمولاً در کانال کلسیمی دی‌هیدروپیریدین یا کانال سدیمی عضله رخ می‌دهد.",
   "در حمله، پتاسیم از خون به داخل سلول عضلانی جابه‌جا می‌شود، نه اینکه از بدن دفع شود.",
   "غشای عضله بیش از حد قطبی می‌شود و دیگر پتانسیل عمل تولید نمی‌کند.",
   "نتیجه ضعف فلاسید است که رفلکس‌ها را کم یا محو می‌کند اما حس را دست‌نخورده می‌گذارد.",
   "دو محرک اصلی حمله: استراحت پس از ورزش سنگین، و وعده‌ی پرکربوهیدرات.",
   "کربوهیدرات انسولین ترشح می‌کند و انسولین پتاسیم را به داخل سلول می‌راند.",
   "پس رژیم درست کم‌کربوهیدرات و کم‌نمک است، نه پرکربوهیدرات.",
   "استازولامید با ایجاد اسیدوز خفیف متابولیک از حملات پیشگیری می‌کند."
  ],
  "points_en": [
   "Hypokalaemic periodic paralysis is an inherited channelopathy with autosomal dominant transmission.",
   "The mutation usually lies in the muscle dihydropyridine calcium channel or the sodium channel.",
   "During an attack potassium shifts from blood into muscle cells rather than being lost from the body.",
   "The muscle membrane becomes over-polarised and can no longer fire action potentials.",
   "The result is flaccid weakness with reduced or absent reflexes but entirely normal sensation.",
   "Two main triggers: rest after heavy exercise, and a high-carbohydrate meal.",
   "Carbohydrate releases insulin, and insulin drives potassium into the cell.",
   "So the correct diet is low in carbohydrate and low in salt, not high in carbohydrate.",
   "Acetazolamide prevents attacks by producing a mild metabolic acidosis."
  ]
 },
 "explanation_fa": "ابتدا تشخیص را بسازید. پسر نوجوانی که پس از بیداری از خواب دچار ضعف چهار اندام شده، عصر قبلش ورزش سنگین کرده، پتاسیم خونش پایین است و علائمش ظرف بیست‌وچهار ساعت خودبه‌خود برطرف می‌شود: این تصویر فلج دوره‌ای هیپوکالمیک است. مکانیسم را بفهمید تا پاسخ روشن شود. در این بیماری پتاسیم از بدن دفع نمی‌شود، بلکه از خون به داخل سلول عضلانی جابه‌جا می‌شود؛ غشا بیش از حد قطبی می‌شود و عضله دیگر پاسخ نمی‌دهد. حالا سؤال منفی را حل کنید: کدام توصیه غلط است؟ هر چیزی که پتاسیم را به داخل سلول براند حمله را بدتر می‌کند، و وعده‌ی پرکربوهیدرات دقیقاً همین کار را می‌کند چون انسولین ترشح می‌کند. پس رژیم درست کم‌کربوهیدرات و کم‌نمک است. سه گزینه‌ی دیگر توصیه‌های درستی هستند.",
 "explanation_en": "Build the diagnosis first. An adolescent boy with four-limb weakness on waking, after heavy exercise the previous evening, with low serum potassium and spontaneous recovery within twenty-four hours: this is hypokalaemic periodic paralysis. Understand the mechanism and the answer follows. Potassium is not lost from the body; it shifts from blood into muscle cells, over-polarising the membrane so the muscle no longer responds. Now solve the negative stem: which recommendation is wrong? Anything that drives potassium into cells worsens attacks, and a high-carbohydrate meal does exactly that by releasing insulin. The correct diet is therefore low in carbohydrate and low in salt. The other three options are sound advice.",
 "why_fa": [
  "قرص کلرور پتاسیم درمان درست حمله‌ی حاد است و پتاسیم سرم را بالا می‌برد تا غشای عضله به حالت طبیعی برگردد.",
  "استازولامید داروی پیشگیری جاافتاده‌ی این بیماری است. با ایجاد اسیدوز خفیف متابولیک از جابه‌جایی پتاسیم به داخل سلول جلوگیری می‌کند.",
  "پرهیز از سرما توصیه‌ی درستی است، چون سرما یکی از محرک‌های شناخته‌شده‌ی حمله در فلج‌های دوره‌ای است.",
  "پاسخ صحیح — این توصیه غلط است. رژیم پرکربوهیدرات با ترشح انسولین پتاسیم را به داخل سلول می‌راند و دقیقاً حمله را شروع می‌کند. رژیم درست کم‌کربوهیدرات است."
 ],
 "why_en": [
  "Potassium chloride tablets are the correct treatment of an acute attack, raising serum potassium so the muscle membrane returns to normal.",
  "Acetazolamide is an established preventive for this disease, producing a mild metabolic acidosis that opposes the intracellular potassium shift.",
  "Avoiding cold is sound advice, since cold is a recognised trigger of attacks in the periodic paralyses.",
  "Correct — this advice is wrong. A high-carbohydrate diet releases insulin, drives potassium into cells and precipitates the very attack. The right diet is low-carbohydrate."
 ],
 "golden_fa": "فلج دوره‌ای هیپوکالمیک: پتاسیم گم نشده، فقط جابه‌جا شده. کربوهیدرات و انسولین آن را به داخل سلول می‌رانند، پس محرک حمله‌اند.",
 "golden_en": "In hypokalaemic periodic paralysis potassium is not lost, only shifted. Carbohydrate and insulin drive it inward, so they trigger attacks.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 10: Periodic paralyses",
  "Statland JM et al. Review of the diagnosis and treatment of periodic paralysis. Muscle Nerve 2018;57:522-30"
 ]
}

L["1400-12:120"] = {
 "micro": {
  "lead_fa": "کره + تغییر شخصیت + آتروفی هسته‌ی دمدار در میان‌سالی، سه‌گانه‌ی بیماری هانتینگتون است.",
  "lead_en": "Chorea + personality change + caudate atrophy in midlife is the triad of Huntington disease.",
  "points_fa": [
   "هانتینگتون یک بیماری اتوزومال غالب با تکرار سه‌گانه‌ی CAG در ژن هانتینگتین است.",
   "شروع علائم معمولاً بین سی تا پنجاه سالگی است.",
   "هرچه تعداد تکرارها بیشتر باشد، بیماری زودتر شروع می‌شود؛ به آن پدیده‌ی anticipation می‌گویند.",
   "نورون‌های خاردار میانی هسته‌ی دمدار و پوتامن زودتر از همه از بین می‌روند.",
   "این نورون‌ها مهاری‌اند، پس با مرگشان مهار برداشته می‌شود و حرکات اضافی ظاهر می‌شوند.",
   "کره یعنی حرکات سریع، نامنظم و غیرقابل پیش‌بینی که از عضوی به عضو دیگر می‌پرد.",
   "در تصویربرداری، آتروفی کودیت شاخ قدامی بطن جانبی را گشاد می‌کند.",
   "این نما را «باکس‌کار» یا بطن جعبه‌ای می‌نامند.",
   "سه‌گانه‌ی بالینی بیماری: اختلال حرکتی، اختلال روان‌پزشکی و زوال شناختی."
  ],
  "points_en": [
   "Huntington disease is autosomal dominant, caused by a CAG triplet repeat in the huntingtin gene.",
   "Onset is usually between thirty and fifty years.",
   "The more repeats, the earlier the onset — a phenomenon called anticipation.",
   "The medium spiny neurons of the caudate and putamen degenerate first.",
   "These neurons are inhibitory, so their loss releases inhibition and excess movement appears.",
   "Chorea means rapid, irregular, unpredictable movements that flit from one body part to another.",
   "On imaging, caudate atrophy widens the frontal horn of the lateral ventricle.",
   "This appearance is called the box-car ventricle.",
   "The clinical triad: movement disorder, psychiatric disturbance and cognitive decline."
  ]
 },
 "explanation_fa": "سه سرنخ این سؤال دقیقاً سه‌گانه‌ی بیماری هانتینگتون را می‌سازند. اول کره: حرکات سریع، نامنظم و غیرقابل پیش‌بینی. دوم تغییرات شخصیتی و عاطفی که اغلب حتی پیش از اختلال حرکتی شروع می‌شوند و ممکن است سال‌ها با تشخیص افسردگی یا اختلال شخصیت درمان شوند. سوم و قطعی‌کننده، آتروفی هسته‌ی دمدار در تصویربرداری. مکانیسم را بدانید تا مطلب در ذهنتان بماند: نورون‌های خاردار میانی هسته‌ی دمدار و پوتامن که ماهیت مهاری دارند زودتر از همه از بین می‌روند، و با برداشته شدن مهار، حرکات اضافی ظاهر می‌شوند. نمای تصویربرداری هم زیباست: آتروفی کودیت شاخ قدامی بطن جانبی را گشاد می‌کند و نمای «باکس‌کار» می‌سازد. سن سی‌وهشت سالگی هم با شروع تیپیک بیماری که بین سی تا پنجاه سالگی است می‌خواند.",
 "explanation_en": "Three clues assemble exactly the Huntington triad. First chorea: rapid, irregular, unpredictable movements. Second, personality and emotional change, which often precedes the movement disorder and may be treated for years as depression or a personality disorder. Third and decisive, caudate atrophy on imaging. Learn the mechanism and it will stick: the medium spiny neurons of the caudate and putamen, which are inhibitory, degenerate first, and releasing that inhibition unmasks excess movement. The imaging sign is elegant too: caudate atrophy widens the frontal horn of the lateral ventricle, producing the box-car appearance. An age of thirty-eight also fits the typical onset between thirty and fifty.",
 "why_fa": [
  "پاسخ صحیح — کره به‌همراه تغییر شخصیت و آتروفی هسته‌ی دمدار در میان‌سالی، سه‌گانه‌ی تشخیصی بیماری هانتینگتون است.",
  "بیماری پارکینسون اختلال حرکتی کم‌حرکتی است: برادی‌کینزی، ریژیدیتی و ترمور استراحت. کره در آن دیده نمی‌شود مگر به‌عنوان عارضه‌ی درمان با لوودوپا.",
  "کره سیدنهام پس از عفونت استرپتوکوکی در کودکان رخ می‌دهد، خودمحدودشونده است و آتروفی کودیت ایجاد نمی‌کند. سن این بیمار هم با آن نمی‌خواند.",
  "بیماری ویلسون معمولاً پیش از چهل سالگی و اغلب در نوجوانی شروع می‌شود و با حلقه‌ی کایزر-فلایشر و درگیری کبد همراه است. در MRI درگیری پوتامن و مغز میانی بارزتر است."
 ],
 "why_en": [
  "Correct — chorea with personality change and caudate atrophy in midlife is the diagnostic triad of Huntington disease.",
  "Parkinson disease is a hypokinetic disorder: bradykinesia, rigidity and rest tremor. Chorea appears only as a complication of levodopa therapy.",
  "Sydenham chorea follows streptococcal infection in children, is self-limiting and causes no caudate atrophy. The patient's age does not fit.",
  "Wilson disease usually begins before forty and often in adolescence, with Kayser-Fleischer rings and liver involvement. MRI shows putaminal and midbrain changes."
 ],
 "golden_fa": "کره + روان‌پریشی + آتروفی کودیت = هانتینگتون. مرگ نورون مهاری، مهار را برمی‌دارد و حرکت اضافی می‌سازد.",
 "golden_en": "Chorea + psychiatric change + caudate atrophy = Huntington. Losing inhibitory neurons releases inhibition and unmasks excess movement.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 11: Huntington disease",
  "Bates GP et al. Huntington disease. Nat Rev Dis Primers 2015;1:15005"
 ]
}

L["1400-12:121"] = {
 "micro": {
  "lead_fa": "درد شکم + علائم روان‌پزشکی + نوروپاتی پروگزیمال، سه‌گانه‌ی پورفیری حاد متناوب است.",
  "lead_en": "Abdominal pain + psychiatric symptoms + proximal neuropathy is the triad of acute intermittent porphyria.",
  "points_fa": [
   "پورفیری حاد متناوب از نقص آنزیم پورفوبیلینوژن دآمیناز در مسیر ساخت هم ناشی می‌شود.",
   "پیش‌سازهای سمی انباشته می‌شوند و به اعصاب آسیب می‌زنند.",
   "شایع‌ترین علامت، درد شدید و کولیکی شکم بدون یافته‌ی جراحی است.",
   "بسیاری از این بیماران به‌اشتباه تحت لاپاراتومی قرار می‌گیرند.",
   "علائم روان‌پزشکی شامل بی‌قراری، اضطراب، سایکوز و گاه توهم است.",
   "نوروپاتی آن عمدتاً حرکتی است و برخلاف گیلن-باره پروگزیمال شروع می‌شود.",
   "اغلب از اندام فوقانی آغاز می‌شود، نه از پاها.",
   "ادرار پس از ماندن در نور به رنگ قرمز تیره یا پورت‌واین درمی‌آید.",
   "محرک‌های حمله: داروهای القاکننده‌ی سیتوکروم P450، روزه‌داری، الکل و عفونت."
  ],
  "points_en": [
   "Acute intermittent porphyria results from deficiency of porphobilinogen deaminase in haem synthesis.",
   "Toxic precursors accumulate and damage nerves.",
   "The commonest symptom is severe colicky abdominal pain with no surgical findings.",
   "Many of these patients undergo an unnecessary laparotomy.",
   "Psychiatric features include restlessness, anxiety, psychosis and sometimes hallucinations.",
   "Its neuropathy is predominantly motor and, unlike Guillain-Barré, begins proximally.",
   "It often starts in the upper limbs rather than the legs.",
   "Urine turns dark red or port-wine coloured after standing in light.",
   "Attack triggers: cytochrome P450-inducing drugs, fasting, alcohol and infection."
  ]
 },
 "explanation_fa": "این بیمار سه دسته علامت دارد که کنار هم فقط به یک تشخیص می‌رسند. اول علائم گوارشی: درد کولیکی شکم، یبوست و استفراغ. دوم علائم روان‌پزشکی: بی‌قراری و سایکوز. سوم و در ادامه، نوروپاتی پیشرونده. این سه‌گانه پورفیری حاد متناوب است. نکته‌ی افتراقی کلیدی که این سؤال روی آن تمرکز دارد، الگوی نوروپاتی است: در پورفیری نوروپاتی عمدتاً حرکتی و پروگزیمال است و اغلب از اندام فوقانی شروع می‌شود، در حالی که گیلن-باره صعودی است و از پاها بالا می‌آید. ضمناً درد شکم و سایکوز اصلاً در گیلن-باره جایی ندارند. برای تکمیل تصویر: تب و لکوسیتوز هم در حمله‌ی پورفیری دیده می‌شوند و همین باعث می‌شود بیمار به‌اشتباه شکم حاد جراحی تشخیص داده شود.",
 "explanation_en": "This patient has three symptom clusters that together point to only one diagnosis. First, gastrointestinal: colicky abdominal pain, constipation and vomiting. Second, psychiatric: restlessness and psychosis. Third, and following on, a progressive neuropathy. That triad is acute intermittent porphyria. The key discriminator this item targets is the neuropathy pattern: in porphyria it is predominantly motor and proximal, often starting in the upper limbs, whereas Guillain-Barré ascends from the legs. Moreover, abdominal pain and psychosis have no place in Guillain-Barré. To complete the picture: fever and leukocytosis also occur in a porphyric attack, which is why these patients are often misdiagnosed as a surgical acute abdomen.",
 "why_fa": [
  "پلی‌میوزیت ضعف پروگزیمال قرینه می‌دهد، اما با درد شکم، یبوست و سایکوز همراه نیست و سیر آن هفته‌ها تا ماه‌هاست، نه دو هفته با این تابلوی سیستمیک.",
  "پاسخ صحیح — سه‌گانه‌ی درد شکم، علائم روان‌پزشکی و نوروپاتی پروگزیمال حرکتی، تشخیص پورفیری حاد متناوب را می‌سازد.",
  "گیلن-باره نوروپاتی صعودی و عمدتاً دیستال است که از پاها شروع می‌شود. درد شکم، یبوست، تب و سایکوز از تظاهرات آن نیستند.",
  "بوتولیسم فلج نزولی و قرینه می‌دهد که از اعصاب کرانیال شروع می‌شود، همراه با مردمک گشاد و خشکی دهان. سیر آن ساعت‌هاست نه دو هفته."
 ],
 "why_en": [
  "Polymyositis causes symmetrical proximal weakness but not abdominal pain, constipation or psychosis, and evolves over weeks to months rather than two weeks with this systemic picture.",
  "Correct — the triad of abdominal pain, psychiatric symptoms and a proximal motor neuropathy establishes acute intermittent porphyria.",
  "Guillain-Barré is an ascending, predominantly distal neuropathy beginning in the legs. Abdominal pain, constipation, fever and psychosis are not features.",
  "Botulism causes a descending symmetrical paralysis starting with the cranial nerves, with dilated pupils and dry mouth. It evolves over hours, not two weeks."
 ],
 "golden_fa": "درد شکم + سایکوز + نوروپاتی = پورفیری. نوروپاتی آن پروگزیمال و از دست شروع می‌شود، برخلاف گیلن-باره که از پا بالا می‌آید.",
 "golden_en": "Abdominal pain + psychosis + neuropathy = porphyria. Its neuropathy is proximal and starts in the arms, unlike Guillain-Barré which ascends from the legs.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 9: Porphyric neuropathy",
  "Bissell DM et al. Porphyria. N Engl J Med 2017;377:862-72"
 ]
}
json.dump(L, io.open('/home/user/work/lessons/L4.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('batch 4:', len(L), 'lessons')
