# -*- coding: utf-8 -*-
"""Micro-lessons, batch 11 — Shahrivar 1401 and Khordad 1402."""
import json, io
L = {}

L["1401-06:114"] = {
 "stem_en": "A 65-year-old woman has had a progressive headache for a month that responds poorly to analgesics. It is sometimes throbbing and mostly left-sided. Vital signs are normal. She has tenderness over the left temporal region. Neurological examination is normal. Laboratory results: haemoglobin 10.7, WBC 11,000 with neutrophil predominance, platelets 495,000, ESR 100 (normal up to 45). Which action takes priority?",
 "options_en": ["Obtain brain imaging", "Start prednisolone",
                "Start intravenous antibiotics", "Give oral sumatriptan"],
 "micro": {
  "lead_fa": "آرتریت تمپورال یک اورژانس چشمی است؛ استروئید را پیش از هر اقدام دیگری شروع کنید.",
  "lead_en": "Temporal arteritis is an ophthalmic emergency; start steroids before anything else.",
  "points_fa": [
   "آرتریت سلول ژانت واسکولیت شریان‌های متوسط و بزرگ در افراد بالای پنجاه سال است.",
   "شریان تمپورال سطحی شایع‌ترین شریان درگیر و منشأ نام بیماری است.",
   "علائم کلیدی: سردرد جدید، تندرنس پوست سر و لنگش فک هنگام جویدن.",
   "لنگش فک اختصاصی‌ترین علامت بالینی است.",
   "ESR بالای پنجاه تقریباً همیشه دیده می‌شود و CRP هم بالا می‌رود.",
   "کم‌خونی بیماری مزمن و ترومبوسیتوز واکنشی هم شایع‌اند.",
   "خطرناک‌ترین عارضه، نوروپاتی ایسکمیک قدامی عصب اپتیک و کوری دائمی است.",
   "کوری در یک چشم اگر درمان نشود، طی روزها به چشم دیگر سرایت می‌کند.",
   "بیوپسی شریان تمپورال استاندارد طلایی است اما نباید درمان را به تعویق بیندازد."
  ],
  "points_en": [
   "Giant cell arteritis is a vasculitis of medium and large arteries in people over fifty.",
   "The superficial temporal artery is the commonest vessel involved and gives the disease its name.",
   "Key features: new headache, scalp tenderness and jaw claudication on chewing.",
   "Jaw claudication is the most specific clinical sign.",
   "An ESR above fifty is almost always present and CRP is also raised.",
   "Anaemia of chronic disease and reactive thrombocytosis are common too.",
   "The most feared complication is anterior ischaemic optic neuropathy and permanent blindness.",
   "If untreated, blindness in one eye spreads to the other within days.",
   "Temporal artery biopsy is the gold standard but must not delay treatment."
  ]
 },
 "explanation_fa": "این سؤال قصد دارد ببیند آیا فوریت را می‌شناسید یا نه. تشخیص سخت نیست: زن بالای پنجاه سال، سردرد جدید و پیش‌رونده‌ی یک‌ماهه، تندرنس تمپورال، ESR صد، کم‌خونی و ترومبوسیتوز. این مجموعه آرتریت سلول ژانت است. سؤال اصلی این است که اولویت چیست. سه گزینه‌ی دیگر همگی «کار بعدی منطقی» به نظر می‌رسند اما هیچ‌کدام فوری نیستند. نکته این است که در این بیماری، شریان اپتیک خلفی می‌تواند در هر ساعتی بسته شود و کوری حاصل برگشت‌ناپذیر است. پس قاعده‌ی طلایی این است: به‌محض شک بالینی قوی، کورتیکواستروئید با دوز بالا را شروع کنید و بعد بیوپسی بگیرید. بیوپسی تا حدود دو هفته پس از شروع استروئید هنوز مثبت می‌ماند، پس چیزی از دست نمی‌رود.",
 "explanation_en": "This item checks whether you recognise the urgency. The diagnosis is not hard: a woman over fifty, a new progressive headache for a month, temporal tenderness, ESR of one hundred, anaemia and thrombocytosis. That set is giant cell arteritis. The real question is what takes priority. The other three options all look like reasonable next steps but none is urgent. The point is that in this disease the posterior ciliary artery can occlude at any hour and the resulting blindness is irreversible. So the golden rule is: as soon as clinical suspicion is strong, start high-dose corticosteroids and arrange the biopsy afterwards. The biopsy stays positive for about two weeks after starting steroids, so nothing is lost.",
 "why_fa": [
  "تصویربرداری مغز در این تابلو یافته‌ی مفیدی نمی‌دهد و فقط وقت می‌برد. معاینه‌ی نورولوژیک طبیعی است و نشانه‌ای از ضایعه‌ی فضاگیر وجود ندارد.",
  "پاسخ صحیح — پردنیزولون با دوز یک میلی‌گرم بر کیلوگرم باید فوراً شروع شود تا از نوروپاتی ایسکمیک عصب اپتیک و کوری دائمی جلوگیری شود.",
  "آنتی‌بیوتیک وریدی جایی ندارد چون بیمار تب ندارد و کانون عفونی مشخصی وجود ندارد. لکوسیتوز خفیف واکنش التهابی سیستمیک است، نه عفونت.",
  "سوماتریپتان داروی حمله‌ی میگرن است. تجویز آن در واسکولیت شریانی نه‌تنها بی‌فایده بلکه به‌خاطر اثر انقباض عروقی بالقوه خطرناک است."
 ],
 "why_en": [
  "Brain imaging yields nothing useful in this picture and only costs time. The neurological examination is normal with no sign of a mass lesion.",
  "Correct — prednisolone at one milligram per kilogram must be started immediately to prevent ischaemic optic neuropathy and permanent blindness.",
  "Intravenous antibiotics have no place because there is no fever and no identified infectious focus. The mild leukocytosis is a systemic inflammatory response, not infection.",
  "Sumatriptan is a migraine abortive. In an arterial vasculitis it is not only useless but potentially harmful because of its vasoconstrictor effect."
 ],
 "golden_fa": "سردرد جدید بالای ۵۰ سال + ESR بالا + تندرنس تمپورال = استروئید فوری، بیوپسی بعداً.",
 "golden_en": "New headache over fifty plus high ESR plus temporal tenderness means steroids now, biopsy later.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 6: Giant cell arteritis",
  "Hunder GG et al. ACR criteria for the classification of giant cell arteritis. Arthritis Rheum 1990;33:1122-8"
 ]
}

L["1401-06:115"] = {
 "stem_en": "In evaluating a 65-year-old man presenting with memory problems that impair daily function, which of the following is NOT routinely checked?",
 "options_en": ["Electroencephalogram", "Serum B12 level", "Thyroid function tests", "Syphilis serology"],
 "micro": {
  "lead_fa": "نوار مغز جزو بررسی روتین دمانس نیست و فقط در شرایط خاص درخواست می‌شود.",
  "lead_en": "EEG is not part of the routine dementia workup and is requested only in special situations.",
  "points_fa": [
   "هدف بررسی اولیه‌ی دمانس، پیدا کردن علت‌های قابل برگشت است.",
   "علت‌های قابل برگشت حدود پنج تا ده درصد موارد را می‌سازند اما ارزش جستجو دارند.",
   "آزمایش‌های روتین: شمارش کامل سلولی، الکترولیت‌ها، کلسیم، قند و عملکرد کلیه و کبد.",
   "سطح ویتامین B12 باید چک شود چون کمبودش دمانس قابل برگشت می‌سازد.",
   "تست عملکرد تیروئید لازم است چون کم‌کاری تیروئید با کندی شناختی تظاهر می‌کند.",
   "سرولوژی سیفلیس در بررسی استاندارد گنجانده می‌شود چون نوروسیفلیس درمان‌پذیر است.",
   "تصویربرداری ساختاری با CT یا MRI یک بار برای همه توصیه می‌شود.",
   "نوار مغز فقط وقتی لازم است که به بیماری کروتزفلد-یاکوب یا صرع پنهان شک کنیم.",
   "دلیریوم هم اندیکاسیون نوار مغز است، چون کندی منتشر امواج را نشان می‌دهد."
  ],
  "points_en": [
   "The aim of the initial dementia workup is to find reversible causes.",
   "Reversible causes make up about five to ten percent of cases but are worth seeking.",
   "Routine tests: full blood count, electrolytes, calcium, glucose, renal and liver function.",
   "Vitamin B12 must be checked because deficiency produces a reversible dementia.",
   "Thyroid function is needed because hypothyroidism presents with cognitive slowing.",
   "Syphilis serology is included in the standard workup because neurosyphilis is treatable.",
   "Structural imaging with CT or MRI is recommended once for everyone.",
   "EEG is needed only when Creutzfeldt-Jakob disease or occult epilepsy is suspected.",
   "Delirium is also an EEG indication, since it shows diffuse slowing."
  ]
 },
 "explanation_fa": "برای پاسخ باید بدانید فلسفه‌ی بررسی اولیه‌ی دمانس چیست. هدف اصلی این نیست که نوع دژنراتیو دمانس را قطعی کنیم، بلکه این است که علت‌های قابل درمان را از دست ندهیم. سه گزینه‌ی B12، عملکرد تیروئید و سرولوژی سیفلیس دقیقاً همین کار را می‌کنند: هر سه به دنبال بیماری‌ای هستند که اگر پیدا شود، درمانش می‌تواند شناخت را برگرداند. نوار مغز اما در این چارچوب نمی‌گنجد. نوار مغز در دمانس آلزایمر معمولاً فقط کندی غیراختصاصی نشان می‌دهد که چیزی به تشخیص اضافه نمی‌کند. اندیکاسیون آن محدود است: شک به بیماری کروتزفلد-یاکوب که کمپلکس‌های تیزموج دوره‌ای می‌دهد، شک به تشنج پنهان، یا افتراق دلیریوم از دمانس.",
 "explanation_en": "To answer this you need the philosophy of the initial dementia workup. Its main goal is not to prove which degenerative dementia is present but to avoid missing treatable causes. The three options of B12, thyroid function and syphilis serology do exactly that: each looks for a disease whose treatment could restore cognition. EEG does not fit this framework. In Alzheimer dementia the EEG usually shows only non-specific slowing that adds nothing to the diagnosis. Its indications are narrow: suspected Creutzfeldt-Jakob disease, which produces periodic sharp wave complexes, suspected occult seizures, or distinguishing delirium from dementia.",
 "why_fa": [
  "پاسخ صحیح — نوار مغز بررسی روتین دمانس نیست. فقط در شک به کروتزفلد-یاکوب، تشنج پنهان یا دلیریوم درخواست می‌شود.",
  "سطح B12 سرم باید در همه‌ی بیماران دمانس اندازه‌گیری شود، چون کمبود آن دمانس، نوروپاتی و دژنراسیون ترکیبی نخاع می‌سازد که قابل برگشت است.",
  "تست عملکرد تیروئید روتین است چون کم‌کاری تیروئید می‌تواند دقیقاً شبیه دمانس تظاهر کند و با لووتیروکسین کاملاً برگردد.",
  "سرولوژی سیفلیس در راهنماهای استاندارد بررسی دمانس گنجانده شده است، چون نوروسیفلیس با پنی‌سیلین درمان‌پذیر است."
 ],
 "why_en": [
  "Correct — EEG is not a routine dementia test. It is requested only for suspected Creutzfeldt-Jakob disease, occult seizures or delirium.",
  "Serum B12 should be measured in every dementia patient, because deficiency causes a reversible dementia, neuropathy and subacute combined degeneration.",
  "Thyroid function testing is routine because hypothyroidism can mimic dementia exactly and reverse completely with levothyroxine.",
  "Syphilis serology is included in standard dementia workup guidelines, because neurosyphilis is treatable with penicillin."
 ],
 "golden_fa": "بررسی دمانس دنبال علت قابل برگشت است: B12، تیروئید، سیفلیس، تصویربرداری. نوار مغز روتین نیست.",
 "golden_en": "The dementia workup hunts reversible causes: B12, thyroid, syphilis and imaging. EEG is not routine.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 5: Dementia, laboratory evaluation",
  "Knopman DS et al. Practice parameter: diagnosis of dementia. Neurology 2001;56:1143-53"
 ]
}

L["1401-06:116"] = {
 "stem_en": "A 52-year-old woman presents with fluctuating right eyelid droop together with bilateral fatigability of the arm and shoulder muscles for about six months. Which method has the greatest diagnostic value for her?",
 "options_en": ["Brain MRI", "Lumbar puncture", "Single fiber EMG", "Mediastinal CT scan"],
 "micro": {
  "lead_fa": "الکترومیوگرافی تک‌فیبر حساس‌ترین آزمون تشخیصی میاستنی گراویس است.",
  "lead_en": "Single fiber EMG is the most sensitive diagnostic test for myasthenia gravis.",
  "points_fa": [
   "میاستنی گراویس بیماری خودایمنی محل اتصال عصب و عضله است.",
   "آنتی‌بادی به گیرنده‌ی استیل‌کولین صفحه‌ی محرکه را تخریب می‌کند.",
   "علامت مشخصه خستگی‌پذیری است: ضعف با فعالیت بدتر و با استراحت بهتر می‌شود.",
   "پتوز و دوبینی شایع‌ترین علائم اولیه‌اند و در بیش از نیمی از بیماران شروع بیماری‌اند.",
   "نوسان در طول روز مشخصه‌ی کلیدی است؛ عصرها بدتر است.",
   "آنتی‌بادی ضدگیرنده‌ی استیل‌کولین در حدود هشتاد و پنج درصد فرم عمومی مثبت است.",
   "تحریک عصبی تکراری کاهش پاسخ بیش از ده درصد را نشان می‌دهد اما حساسیتش متوسط است.",
   "الکترومیوگرافی تک‌فیبر حساسیت بالای نود و پنج درصد دارد و افزایش jitter را می‌سنجد.",
   "سی‌تی مدیاستن برای یافتن تیموما لازم است اما آزمون تشخیصی خود بیماری نیست."
  ],
  "points_en": [
   "Myasthenia gravis is an autoimmune disease of the neuromuscular junction.",
   "Antibodies against the acetylcholine receptor destroy the motor endplate.",
   "The hallmark is fatigability: weakness worsens with activity and improves with rest.",
   "Ptosis and diplopia are the commonest initial symptoms and open the disease in over half of patients.",
   "Fluctuation through the day is a key feature; it is worse in the evening.",
   "Anti-acetylcholine receptor antibodies are positive in about eighty-five percent of generalised cases.",
   "Repetitive nerve stimulation shows a decrement over ten percent but has moderate sensitivity.",
   "Single fiber EMG has a sensitivity above ninety-five percent and measures increased jitter.",
   "Mediastinal CT is needed to find a thymoma but is not a diagnostic test for the disease itself."
  ]
 },
 "explanation_fa": "دو کلمه‌ی صورت سؤال تشخیص را می‌سازند: «نوسان‌دار» و «خستگی‌پذیری». پتوزی که در طول روز بالا و پایین می‌رود و ضعف عضلاتی که با فعالیت بدتر می‌شود، الگوی اختصاصی اختلال محل اتصال عصب و عضله است. پس تشخیص میاستنی گراویس است. حالا سؤال می‌پرسد کدام روش بیشترین ارزش تشخیصی را دارد. توجه کنید که سؤال دنبال «ارزش تشخیصی بیشتر» است، نه دنبال «اقدام بعدی». MRI مغز و پونکسیون کمری هیچ ربطی به این بیماری ندارند. سی‌تی مدیاستن گرچه در ارزیابی هر بیمار میاستنی لازم است، اما تیموما را می‌جوید نه خود بیماری را و در بیشتر بیماران طبیعی است. الکترومیوگرافی تک‌فیبر با سنجش پراکندگی زمانی انتقال در صفحه‌ی محرکه، حساس‌ترین ابزار تأیید است.",
 "explanation_en": "Two words in the stem make the diagnosis: fluctuating and fatigability. Ptosis that rises and falls through the day and muscle weakness that worsens with activity are the specific pattern of a neuromuscular junction disorder. So the diagnosis is myasthenia gravis. Now the question asks which method has the greatest diagnostic value, not what the next step is. Brain MRI and lumbar puncture are unrelated to this disease. Mediastinal CT, although required in the assessment of every myasthenic patient, looks for a thymoma rather than for the disease itself and is normal in most patients. Single fiber EMG, by measuring the temporal variability of transmission at the endplate, is the most sensitive confirmatory tool.",
 "why_fa": [
  "MRI مغز وقتی ارزش دارد که به ضایعه‌ی ساقه‌ی مغز یا فشار روی عصب سوم شک داشته باشیم. الگوی خستگی‌پذیر و نوسان‌دار با آن سازگار نیست.",
  "پونکسیون کمری در میاستنی گراویس هیچ اندیکاسیونی ندارد و مایع نخاعی در این بیماری طبیعی است.",
  "پاسخ صحیح — الکترومیوگرافی تک‌فیبر افزایش jitter را در صفحه‌ی محرکه نشان می‌دهد و با حساسیت بالای نود و پنج درصد، حساس‌ترین آزمون تشخیصی است.",
  "سی‌تی مدیاستن برای غربالگری تیموما لازم است که در حدود ده تا پانزده درصد بیماران دیده می‌شود، اما نتیجه‌ی طبیعی آن تشخیص را رد نمی‌کند."
 ],
 "why_en": [
  "Brain MRI has value when a brainstem lesion or third nerve compression is suspected. A fatigable, fluctuating pattern does not fit that.",
  "Lumbar puncture has no indication in myasthenia gravis and the cerebrospinal fluid is normal in this disease.",
  "Correct — single fiber EMG demonstrates increased jitter at the endplate and, with sensitivity above ninety-five percent, is the most sensitive diagnostic test.",
  "Mediastinal CT is needed to screen for thymoma, found in about ten to fifteen percent of patients, but a normal scan does not exclude the diagnosis."
 ],
 "golden_fa": "نوسان + خستگی‌پذیری = میاستنی. حساس‌ترین آزمون = EMG تک‌فیبر. سی‌تی مدیاستن برای تیموما.",
 "golden_en": "Fluctuation plus fatigability means myasthenia. The most sensitive test is single fiber EMG; mediastinal CT is for thymoma.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 9: Myasthenia gravis, diagnosis",
  "Gilhus NE. Myasthenia gravis. N Engl J Med 2016;375:2570-81"
 ]
}

L["1401-06:117"] = {
 "stem_en": "A 60-year-old man presents with rest tremor, rigidity, frequent falls and slowness of movement beginning six months ago. Which feature is INCONSISTENT with a diagnosis of Parkinson disease?",
 "options_en": ["Rest tremor", "Rigidity", "Frequent falls", "Bradykinesia"],
 "micro": {
  "lead_fa": "زمین‌خوردن زودرس یک پرچم قرمز است و باید شما را به سندرم‌های پارکینسون‌پلاس ببرد.",
  "lead_en": "Early falls are a red flag that should push you toward the Parkinson-plus syndromes.",
  "points_fa": [
   "چهار علامت اصلی پارکینسونیسم: لرزش استراحت، ریژیدیتی، برادی‌کینزی و بی‌ثباتی وضعیتی.",
   "در بیماری پارکینسون این علائم به ترتیب و با نظم خاصی ظاهر می‌شوند.",
   "شروع معمولاً یک‌طرفه است و سال‌ها همان سمت غالب می‌ماند.",
   "بی‌ثباتی وضعیتی و زمین‌خوردن دیرترین علامت است و معمولاً پس از پنج سال می‌آید.",
   "پس زمین‌خوردن در سال اول با بیماری پارکینسون ایدیوپاتیک نمی‌خواند.",
   "پرچم‌های قرمز دیگر: پیشرفت سریع، تقارن کامل، پاسخ ضعیف به لوودوپا.",
   "افت فشار وضعیتی زودرس و اختلال زودرس اسفنکتر هم پرچم قرمزند.",
   "زمین‌خوردن زودرس با فلج نگاه عمودی، فلج فوق هسته‌ای پیشرونده را مطرح می‌کند.",
   "زمین‌خوردن زودرس با اختلال اتونوم، مالتیپل سیستم آتروفی را مطرح می‌کند."
  ],
  "points_en": [
   "The four cardinal signs of parkinsonism: rest tremor, rigidity, bradykinesia and postural instability.",
   "In Parkinson disease these appear in a particular, orderly sequence.",
   "Onset is usually unilateral and stays predominantly on that side for years.",
   "Postural instability and falls come last, usually after five years.",
   "So falling within the first year does not fit idiopathic Parkinson disease.",
   "Other red flags: rapid progression, complete symmetry and poor levodopa response.",
   "Early orthostatic hypotension and early sphincter dysfunction are also red flags.",
   "Early falls with vertical gaze palsy suggest progressive supranuclear palsy.",
   "Early falls with autonomic failure suggest multiple system atrophy."
  ]
 },
 "explanation_fa": "این سؤال چهار علامت را کنار هم می‌گذارد که سه‌تایشان کاملاً معمول‌اند و یکی از نظر زمانی جا نمی‌افتد. لرزش استراحت، ریژیدیتی و کندی حرکات هر سه از علائم اصلی و زودرس بیماری پارکینسون‌اند. اما سقوط مکرر داستان دیگری دارد. بی‌ثباتی وضعیتی گرچه جزو چهار علامت اصلی پارکینسونیسم است، در بیماری پارکینسون ایدیوپاتیک آخرین علامتی است که ظاهر می‌شود و معمولاً چند سال پس از شروع می‌آید. در این بیمار بیماری فقط شش ماه است شروع شده و بیمار همین حالا سقوط مکرر دارد. این ناسازگاری زمانی یک پرچم قرمز است و باید شما را به سمت سندرم‌های پارکینسون‌پلاس ببرد، به‌ویژه فلج فوق هسته‌ای پیشرونده که با زمین‌خوردن‌های زودرس به عقب شناخته می‌شود.",
 "explanation_en": "The item lays out four signs, three entirely typical and one that does not fit the timeline. Rest tremor, rigidity and slowness of movement are all cardinal and early features of Parkinson disease. Frequent falls are a different story. Postural instability, though one of the four cardinal signs of parkinsonism, is the last to appear in idiopathic Parkinson disease and usually arrives several years after onset. In this patient the illness is only six months old and he is already falling repeatedly. That timing mismatch is a red flag and should push you toward a Parkinson-plus syndrome, especially progressive supranuclear palsy, which is known for early backward falls.",
 "why_fa": [
  "لرزش استراحت از علائم کلاسیک و زودرس بیماری پارکینسون است و معمولاً یک‌طرفه و با فرکانس چهار تا شش هرتز شروع می‌شود.",
  "ریژیدیتی از نوع چرخ‌دنده‌ای در معاینه‌ی مچ و آرنج، یافته‌ی معمول و مورد انتظار بیماری پارکینسون است.",
  "پاسخ صحیح — سقوط مکرر در شش ماه اول با پارکینسون ایدیوپاتیک ناسازگار است. بی‌ثباتی وضعیتی در این بیماری معمولاً پس از پنج سال می‌آید.",
  "کندی حرکات یا برادی‌کینزی علامت اجباری تشخیص پارکینسونیسم است و بدون آن اصلاً نمی‌توان تشخیص گذاشت."
 ],
 "why_en": [
  "Rest tremor is a classic early feature of Parkinson disease and usually begins unilaterally at four to six hertz.",
  "Cogwheel rigidity at the wrist and elbow is a usual and expected finding in Parkinson disease.",
  "Correct — frequent falls within the first six months are inconsistent with idiopathic Parkinson disease, where postural instability usually appears after five years.",
  "Bradykinesia is the obligatory sign for diagnosing parkinsonism; without it the diagnosis cannot be made at all."
 ],
 "golden_fa": "زمین‌خوردن زودرس = پرچم قرمز = پارکینسون‌پلاس، نه پارکینسون ایدیوپاتیک.",
 "golden_en": "Early falls are a red flag pointing to Parkinson-plus, not idiopathic Parkinson disease.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 11: Parkinsonism, red flags",
  "Postuma RB et al. MDS clinical diagnostic criteria for Parkinson's disease. Mov Disord 2015;30:1591-601"
 ]
}

L["1402-03:117"] = {
 "micro": {
  "lead_fa": "پلی‌نوروپاتی دیابتی همه‌ی رشته‌ها را می‌گیرد؛ حس عمقی هم درگیر می‌شود و آتاکسی حسی می‌سازد.",
  "lead_en": "Diabetic polyneuropathy involves all fibre types; proprioception is affected and produces sensory ataxia.",
  "points_fa": [
   "پلی‌نوروپاتی قرینه‌ی دیستال شایع‌ترین عارضه‌ی عصبی دیابت است.",
   "الگوی درگیری «جوراب و دستکش» است و همیشه از پاها شروع می‌شود.",
   "دلیل شروع از پاها این است که بلندترین آکسون‌ها زودتر آسیب می‌بینند.",
   "این نوروپاتی همه‌ی انواع رشته را درگیر می‌کند: نازک، ضخیم و اتونوم.",
   "رشته‌های نازک درد و حرارت را می‌برند؛ آسیبشان سوزش و درد نوروپاتیک می‌دهد.",
   "رشته‌های ضخیم حس عمقی و ارتعاش را می‌برند؛ آسیبشان آتاکسی حسی می‌سازد.",
   "در آتاکسی حسی، علامت رومبرگ مثبت است و بیمار با بستن چشم تعادلش را از دست می‌دهد.",
   "درگیری اتونوم شایع است: افت فشار وضعیتی، گاستروپارزی و اختلال تعریق.",
   "چون نوروپاتی محیطی است، رفلکس‌ها کم می‌شوند و بابنسکی منفی می‌ماند."
  ],
  "points_en": [
   "Distal symmetric polyneuropathy is the commonest neurological complication of diabetes.",
   "The pattern is stocking and glove and always begins in the feet.",
   "Feet are affected first because the longest axons are damaged earliest.",
   "This neuropathy involves all fibre types: small, large and autonomic.",
   "Small fibres carry pain and temperature; their damage gives burning neuropathic pain.",
   "Large fibres carry proprioception and vibration; their damage produces sensory ataxia.",
   "In sensory ataxia the Romberg sign is positive and the patient loses balance on closing the eyes.",
   "Autonomic involvement is common: orthostatic hypotension, gastroparesis and sweating abnormalities.",
   "Because the neuropathy is peripheral, reflexes diminish and Babinski stays negative."
  ]
 },
 "explanation_fa": "تشخیص از صورت سؤال روشن است: خانم ۶۵ ساله با دیابت هشت‌ساله، پارستزی دیستال که تدریجاً بالا آمده و رفلکس‌های کاهش‌یافته. این پلی‌نوروپاتی قرینه‌ی دیستال دیابتی است. حالا باید بدانید این نوروپاتی چه چیزهایی می‌دهد و چه چیزهایی نمی‌دهد. نکته‌ی کلیدی این است که پلی‌نوروپاتی دیابتی انتخابی نیست، یعنی همه‌ی انواع رشته را درگیر می‌کند. وقتی رشته‌های ضخیم که حس عمقی را می‌برند آسیب ببینند، مغز از موقعیت اندام‌ها بی‌خبر می‌ماند و آتاکسی حسی رخ می‌دهد. این آتاکسی با چشم باز جبران می‌شود اما با بستن چشم بیمار تلوتلو می‌خورد، که همان علامت رومبرگ است. سه گزینه‌ی دیگر هر کدام حقیقتی را وارونه گفته‌اند.",
 "explanation_en": "The diagnosis is clear from the stem: a 65-year-old woman with eight years of diabetes, distal paresthesia ascending gradually and reduced reflexes. This is diabetic distal symmetric polyneuropathy. Now you need to know what this neuropathy does and does not produce. The key point is that diabetic polyneuropathy is not selective: it involves all fibre types. When the large fibres carrying proprioception are damaged, the brain loses track of limb position and sensory ataxia results. This ataxia is compensated with the eyes open but the patient sways when the eyes close, which is the Romberg sign. Each of the other three options inverts a fact.",
 "why_fa": [
  "نادرست است. درگیری اتونوم در نوروپاتی دیابتی شایع است و افت فشار وضعیتی، گاستروپارزی، اختلال نعوظ و اختلال تعریق می‌سازد.",
  "پاسخ صحیح — آسیب رشته‌های ضخیم حس عمقی را از بین می‌برد و آتاکسی حسی با علامت رومبرگ مثبت ایجاد می‌کند.",
  "نادرست است. آتروفی عضلانی دیستال در نوروپاتی‌های مزمن انتظار می‌رود و به نفع تشخیص است، نه به ضرر آن.",
  "نادرست است. بابنسکی نشانه‌ی ضایعه‌ی نورون حرکتی فوقانی است. در نوروپاتی محیطی رفلکس‌ها کم می‌شوند و پاسخ کف پایی خم‌کننده می‌ماند."
 ],
 "why_en": [
  "False. Autonomic involvement is common in diabetic neuropathy, producing orthostatic hypotension, gastroparesis, erectile dysfunction and sweating abnormalities.",
  "Correct — large fibre damage abolishes proprioception and produces sensory ataxia with a positive Romberg sign.",
  "False. Distal muscle atrophy is expected in chronic neuropathies and supports rather than opposes the diagnosis.",
  "False. Babinski indicates an upper motor neuron lesion. In peripheral neuropathy reflexes diminish and the plantar response stays flexor."
 ],
 "golden_fa": "نوروپاتی دیابتی همه‌ی رشته‌ها را می‌گیرد: درد از رشته‌ی نازک، آتاکسی حسی از رشته‌ی ضخیم، افت فشار از اتونوم.",
 "golden_en": "Diabetic neuropathy hits all fibres: pain from small fibres, sensory ataxia from large fibres, orthostatic hypotension from autonomic fibres.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 9: Diabetic polyneuropathy",
  "Pop-Busui R et al. Diabetic neuropathy: a position statement by the ADA. Diabetes Care 2017;40:136-54"
 ]
}

L["1402-03:118"] = {
 "micro": {
  "lead_fa": "در حمله‌ی غیاب هوشیاری قطع می‌شود اما تون عضلانی حفظ می‌ماند و اتوماتیسم‌های ظریف دیده می‌شود.",
  "lead_en": "In an absence attack consciousness is interrupted but muscle tone is preserved, with fine automatisms.",
  "points_fa": [
   "حمله‌ی غیاب قطع ناگهانی و کوتاه هوشیاری است که پنج تا پانزده ثانیه طول می‌کشد.",
   "بیمار وسط جمله می‌ایستد، خیره می‌شود و بعد بدون توضیح ادامه می‌دهد.",
   "هوشیاری در حمله قطع می‌شود؛ همین آن را از خیال‌بافی جدا می‌کند.",
   "تون عضلانی حفظ می‌شود، پس بیمار نمی‌افتد و اشیاء از دستش نمی‌افتد.",
   "اتوماتیسم‌های ظریف شایع‌اند: پلک زدن سریع، حرکات جویدن و مالیدن انگشتان.",
   "پس از حمله هیچ گیجی وجود ندارد و بیمار بلافاصله به حالت عادی برمی‌گردد.",
   "نبود مرحله‌ی گیجی، مهم‌ترین تفاوت با تشنج فوکال با اختلال آگاهی است.",
   "الگوی نوار مغز اسپایک-موج منتشر سه هرتز است.",
   "درمان با اتوسوکسیماید یا والپروات سدیم است؛ لاموتریژین گزینه‌ی سوم است."
  ],
  "points_en": [
   "An absence attack is a sudden brief interruption of consciousness lasting five to fifteen seconds.",
   "The patient stops mid-sentence, stares, then continues without explanation.",
   "Consciousness is interrupted during the attack; that separates it from daydreaming.",
   "Muscle tone is preserved, so the patient does not fall and does not drop objects.",
   "Fine automatisms are common: rapid blinking, chewing movements and finger rubbing.",
   "There is no postictal confusion and the patient returns to normal immediately.",
   "Absence of a postictal phase is the most important difference from focal impaired-awareness seizures.",
   "The EEG pattern is generalised three-hertz spike-and-wave.",
   "Treatment is ethosuximide or sodium valproate, with lamotrigine as a third option."
  ]
 },
 "explanation_fa": "این سؤال چهار جمله می‌دهد و می‌خواهد جمله‌ی درست را پیدا کنید، پس باید تصویر بالینی حمله‌ی غیاب را دقیق بشناسید. جمله‌ی اول می‌گوید هوشیاری حفظ می‌شود، که اشتباه است؛ اصلاً نام این حمله «غیاب» است چون بیمار غایب می‌شود. جمله‌ی دوم می‌گوید کنترل اندام‌ها از دست می‌رود، که هم اشتباه است؛ ویژگی مهم غیاب دقیقاً این است که تون عضلانی حفظ می‌شود و بیمار نمی‌افتد. جمله‌ی سوم گیجی طولانی پس از حمله را می‌گوید، که برعکس واقعیت است؛ نبود گیجی پس از حمله یکی از مشخصات کلیدی غیاب است. جمله‌ی چهارم درست است: پلک زدن سریع، حرکات جویدن و نشانه‌های ظریف حرکتی همان اتوماتیسم‌هایی هستند که در حمله‌ی غیاب دیده می‌شوند.",
 "explanation_en": "This item gives four statements and asks you to find the true one, so you need an exact picture of an absence attack. The first says consciousness is maintained, which is wrong; the attack is called absence precisely because the patient is absent. The second says limb control is lost, also wrong; a key feature of absence is that muscle tone is preserved and the patient does not fall. The third claims a long postictal phase, the opposite of reality; the absence of postictal confusion is one of the defining features. The fourth is true: rapid blinking, chewing movements and fine motor signs are exactly the automatisms seen during an absence attack.",
 "why_fa": [
  "نادرست است. هوشیاری در حمله‌ی غیاب قطع می‌شود و بیمار به محیط پاسخ نمی‌دهد؛ همین ویژگی نام بیماری را ساخته است.",
  "نادرست است. حفظ تون عضلانی مشخصه‌ی غیاب است. اگر بیمار بیفتد، باید به تشنج آتونیک یا تونیک فکر کرد.",
  "نادرست است. غیاب هیچ مرحله‌ی گیجی پس از حمله ندارد و بیمار بلافاصله فعالیت را از سر می‌گیرد.",
  "پاسخ صحیح — پلک زدن سریع، حرکات جویدن و اتوماتیسم‌های ظریف در بیش از نیمی از حملات غیاب دیده می‌شوند، به‌ویژه در حملات طولانی‌تر."
 ],
 "why_en": [
  "False. Consciousness is interrupted in an absence attack and the patient does not respond to the environment; that feature gives the disorder its name.",
  "False. Preserved muscle tone is characteristic of absence. If the patient falls, think of an atonic or tonic seizure.",
  "False. Absence has no postictal confusion and the patient resumes activity immediately.",
  "Correct — rapid blinking, chewing movements and fine automatisms occur in over half of absence attacks, especially the longer ones."
 ],
 "golden_fa": "غیاب: هوشیاری قطع، تون حفظ، اتوماتیسم ظریف، بدون گیجی بعدی.",
 "golden_en": "Absence: consciousness interrupted, tone preserved, fine automatisms, no postictal confusion.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 12: Generalised seizures, absence",
  "Fisher RS et al. ILAE operational classification of seizure types. Epilepsia 2017;58:522-30"
 ]
}

L["1402-03:119"] = {
 "micro": {
  "lead_fa": "نوریت اپتیک به‌علاوه‌ی علامت لرمیت یعنی دو محل جدا؛ مایع نخاعی باندهای الیگوکلونال را نشان می‌دهد.",
  "lead_en": "Optic neuritis plus Lhermitte sign means two separate sites; the CSF shows oligoclonal bands.",
  "points_fa": [
   "علامت لرمیت احساس شوک برقی در ستون فقرات و اندام‌ها هنگام خم کردن گردن است.",
   "این علامت از پلاک دمیلینه در ستون خلفی نخاع گردنی می‌آید.",
   "نوریت اپتیک با افت دید یک‌طرفه و درد هنگام حرکت چشم مشخص می‌شود.",
   "پس این بیمار دو ضایعه در دو محل جدا دارد: عصب اپتیک و نخاع گردنی.",
   "معیار مک‌دونالد نیازمند پراکندگی در مکان و پراکندگی در زمان است.",
   "مایع نخاعی در ام‌اس باندهای الیگوکلونال IgG نشان می‌دهد که در سرم نیستند.",
   "این باندها در بیش از هشتاد و پنج درصد بیماران ام‌اس مثبت‌اند.",
   "شاخص IgG مایع نخاعی هم بالا می‌رود و نشانه‌ی تولید موضعی آنتی‌بادی است.",
   "MRI حساس‌ترین ابزار است اما در میان گزینه‌های این سؤال وجود ندارد."
  ],
  "points_en": [
   "Lhermitte sign is an electric shock sensation down the spine and limbs on neck flexion.",
   "It arises from a demyelinating plaque in the posterior columns of the cervical cord.",
   "Optic neuritis is marked by unilateral visual loss and pain on eye movement.",
   "So this patient has two lesions at two separate sites: the optic nerve and the cervical cord.",
   "The McDonald criteria require dissemination in space and dissemination in time.",
   "CSF in multiple sclerosis shows oligoclonal IgG bands that are absent from serum.",
   "These bands are positive in over eighty-five percent of patients with the disease.",
   "The CSF IgG index also rises, indicating local antibody production.",
   "MRI is the most sensitive tool but is not among this question's options."
  ]
 },
 "explanation_fa": "اول باید ببینید صورت سؤال چه می‌گوید. خانم ۲۵ ساله با تاری دید یک‌طرفه، یعنی نوریت اپتیک. و احساس شوک برقی هنگام خم کردن گردن، یعنی علامت لرمیت که از پلاک نخاع گردنی می‌آید. پس دو ضایعه در دو محل جدا داریم و تشخیص محتمل ام‌اس است. حالا میان چهار گزینه باید آزمونی را انتخاب کنید که تشخیص را تأیید کند. نوار عصب و عضله بیماری عصب محیطی را می‌سنجد و ام‌اس بیماری سیستم عصبی مرکزی است. نوار مغز برای صرع است. سی‌تی اسکن مغز برای دیدن پلاک‌های دمیلینه بسیار ناکارآمد است، چون این پلاک‌ها در سی‌تی معمولاً دیده نمی‌شوند. تنها گزینه‌ی باقی‌مانده بررسی مایع مغزی نخاعی است که باندهای الیگوکلونال را نشان می‌دهد.",
 "explanation_en": "First read what the stem says. A 25-year-old woman with unilateral blurred vision, that is optic neuritis. And an electric shock sensation on neck flexion, that is Lhermitte sign from a cervical cord plaque. So there are two lesions at two separate sites and the likely diagnosis is multiple sclerosis. Now among four options you must pick a test that confirms it. Nerve conduction studies assess peripheral nerve disease, whereas multiple sclerosis is a central nervous system disorder. EEG is for epilepsy. Brain CT is very poor at showing demyelinating plaques, which are usually invisible on it. The only remaining option is cerebrospinal fluid examination, which shows oligoclonal bands.",
 "why_fa": [
  "مطالعه‌ی الکترودیاگنوستیک اعصاب محیطی و عضلات را می‌سنجد. ام‌اس بیماری سیستم عصبی مرکزی است و این آزمون در آن طبیعی است.",
  "الکتروانسفالوگرافی برای بررسی صرع و انسفالوپاتی کاربرد دارد. در ام‌اس نقش تشخیصی ندارد.",
  "پاسخ صحیح — بررسی مایع مغزی نخاعی باندهای الیگوکلونال IgG و افزایش شاخص IgG را نشان می‌دهد که تولید موضعی آنتی‌بادی در سیستم عصبی مرکزی را ثابت می‌کند.",
  "سی‌تی‌اسکن مغز حساسیت بسیار پایینی برای پلاک‌های دمیلینه دارد. اگر تصویربرداری بخواهیم، MRI با گادولینیوم انتخاب درست است."
 ],
 "why_en": [
  "Electrodiagnostic studies assess peripheral nerves and muscles. Multiple sclerosis is a central disorder and this test is normal in it.",
  "Electroencephalography is used for epilepsy and encephalopathy. It has no diagnostic role in multiple sclerosis.",
  "Correct — cerebrospinal fluid examination shows oligoclonal IgG bands and a raised IgG index, proving local antibody production within the central nervous system.",
  "Brain CT has very low sensitivity for demyelinating plaques. If imaging is wanted, gadolinium-enhanced MRI is the right choice."
 ],
 "golden_fa": "لرمیت = پلاک نخاع گردنی. نوریت اپتیک + لرمیت = ام‌اس. تأیید با باندهای الیگوکلونال مایع نخاعی.",
 "golden_en": "Lhermitte means a cervical cord plaque. Optic neuritis plus Lhermitte means multiple sclerosis, confirmed by CSF oligoclonal bands.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 7: Multiple sclerosis, investigations",
  "Thompson AJ et al. Diagnosis of multiple sclerosis: 2017 revisions of the McDonald criteria. Lancet Neurol 2018;17:162-73"
 ]
}

L["1402-03:120"] = {
 "stem_en": "Which sign on neurological examination favours sensory ataxia over cerebellar ataxia?",
 "options_en": ["Nystagmus", "Veering to one side while standing",
                "Falling with the eyes open", "Lifting and stamping the feet hard on the ground"],
 "micro": {
  "lead_fa": "راه رفتن کوبنده جبران بیمار برای نبود بازخورد حس عمقی است.",
  "lead_en": "The stamping gait is the patient's compensation for absent proprioceptive feedback.",
  "points_fa": [
   "تعادل از سه منبع تغذیه می‌شود: بینایی، دستگاه دهلیزی و حس عمقی.",
   "مخچه این سه ورودی را ترکیب می‌کند و حرکت را هماهنگ می‌سازد.",
   "در آتاکسی مخچه‌ای، خود پردازشگر خراب است و بستن چشم کمک زیادی نمی‌کند.",
   "پس علامت رومبرگ در آتاکسی مخچه‌ای منفی یا فقط کمی مثبت است.",
   "در آتاکسی حسی، ورودی حس عمقی قطع شده اما بینایی سالم است.",
   "بیمار با چشم باز جبران می‌کند، پس با بستن چشم ناگهان می‌افتد: رومبرگ مثبت.",
   "این بیمار پاها را بالا می‌آورد و محکم به زمین می‌کوبد تا بازخورد حسی بسازد.",
   "به این الگو راه رفتن کوبنده یا stamping gait می‌گویند.",
   "نیستاگموس، دیزآرتری و دیس‌متری نشانه‌های مخچه‌ای‌اند، نه حسی."
  ],
  "points_en": [
   "Balance is fed by three sources: vision, the vestibular system and proprioception.",
   "The cerebellum integrates these three inputs and coordinates movement.",
   "In cerebellar ataxia the processor itself is damaged and closing the eyes helps little.",
   "So the Romberg sign is negative or only slightly positive in cerebellar ataxia.",
   "In sensory ataxia the proprioceptive input is cut but vision is intact.",
   "The patient compensates with the eyes open, so closing them causes a sudden fall: a positive Romberg.",
   "Such patients lift the feet and stamp them down hard to generate sensory feedback.",
   "This pattern is called a stamping gait.",
   "Nystagmus, dysarthria and dysmetria are cerebellar signs, not sensory ones."
  ]
 },
 "explanation_fa": "برای حل این سؤال باید بدانید تفاوت بنیادی این دو آتاکسی کجاست. در آتاکسی مخچه‌ای، دستگاه پردازش تعادل خراب است؛ حتی اگر همه‌ی ورودی‌ها سالم باشند، خروجی هماهنگ نمی‌شود. اما در آتاکسی حسی، پردازشگر سالم است و فقط یک ورودی، یعنی حس عمقی، قطع شده است. این تفاوت دو پیامد بالینی دارد. اول اینکه بیمار آتاکسی حسی می‌تواند با چشم جبران کند، پس با چشم باز نسبتاً خوب است و با بستن چشم می‌افتد. دوم اینکه بیمار برای گرفتن بازخورد بیشتر از کف پا، پاها را بالا می‌آورد و محکم به زمین می‌کوبد. این کوبیدن یک راهبرد جبرانی هوشمندانه است و در آتاکسی مخچه‌ای دیده نمی‌شود.",
 "explanation_en": "To solve this you need the fundamental difference between the two ataxias. In cerebellar ataxia the balance processor is broken; even with intact inputs the output is uncoordinated. In sensory ataxia the processor is intact and only one input, proprioception, is cut. This difference has two clinical consequences. First, the sensory ataxic patient can compensate with vision, so is relatively steady with the eyes open and falls when they close. Second, to gain more feedback from the soles, the patient lifts the feet and stamps them down hard. That stamping is a clever compensatory strategy and is not seen in cerebellar ataxia.",
 "why_fa": [
  "نیستاگموس نشانه‌ی درگیری مخچه یا دستگاه دهلیزی است. در آتاکسی حسی خالص، حرکات چشم طبیعی است.",
  "انحراف به یک سمت حین ایستادن بیشتر در ضایعات یک‌طرفه‌ی مخچه یا دهلیزی دیده می‌شود و اختصاصی آتاکسی حسی نیست.",
  "افتادن با چشم‌های باز به نفع آتاکسی مخچه‌ای است، چون در آتاکسی حسی بیمار با کمک بینایی خودش را نگه می‌دارد.",
  "پاسخ صحیح — بلند کردن و کوبیدن محکم پاها راهبرد جبرانی برای تولید بازخورد حسی است و مشخصه‌ی آتاکسی حسی است."
 ],
 "why_en": [
  "Nystagmus indicates cerebellar or vestibular involvement. In pure sensory ataxia eye movements are normal.",
  "Veering to one side while standing is more typical of a unilateral cerebellar or vestibular lesion and is not specific to sensory ataxia.",
  "Falling with the eyes open favours cerebellar ataxia, because in sensory ataxia vision keeps the patient upright.",
  "Correct — lifting and stamping the feet is a compensatory strategy to generate sensory feedback and characterises sensory ataxia."
 ],
 "golden_fa": "آتاکسی حسی: رومبرگ مثبت + راه رفتن کوبنده. آتاکسی مخچه‌ای: نیستاگموس + افتادن با چشم باز.",
 "golden_en": "Sensory ataxia: positive Romberg plus stamping gait. Cerebellar ataxia: nystagmus plus falling with eyes open.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 3: Gait and balance examination",
  "Aminoff MJ et al. Clinical Neurology, 11th ed (2021) — Ch. 8: Ataxia, differential diagnosis"
 ]
}

L["1402-03:121"] = {
 "stem_en": "A 70-year-old man has had rest tremor of the hand, slowness of movement and limb rigidity for a year. Given the most likely diagnosis, which treatment is preferred?",
 "options_en": ["Amantadine", "Levodopa-carbidopa", "Pramipexole (dopamine agonist)", "Trihexyphenidyl"],
 "micro": {
  "lead_fa": "در بیمار بالای شصت‌وپنج سال، لوودوپا مؤثرترین و کم‌عارضه‌ترین انتخاب اول است.",
  "lead_en": "In a patient over sixty-five, levodopa is the most effective first choice with the fewest adverse effects.",
  "points_fa": [
   "لرزش استراحت، برادی‌کینزی و ریژیدیتی سه‌گانه‌ی تشخیصی بیماری پارکینسون است.",
   "علت بیماری از دست رفتن نورون‌های دوپامینرژیک ماده‌ی سیاه است.",
   "لوودوپا پیش‌ساز دوپامین است و از سد خونی-مغزی عبور می‌کند.",
   "کربی‌دوپا مهارکننده‌ی دکربوکسیلاز محیطی است و تهوع را کم می‌کند.",
   "لوودوپا مؤثرترین دارو برای همه‌ی علائم حرکتی پارکینسون است.",
   "انتخاب داروی اول عمدتاً به سن بیمار بستگی دارد.",
   "در بیماران مسن، لوودوپا ترجیح دارد چون تحمل‌پذیری بهتری دارد.",
   "در بیماران جوان، آگونیست دوپامین برای تأخیر در دیسکینزی مطرح می‌شود.",
   "آگونیست‌ها در سالمندان خطر توهم، خواب‌آلودگی و اختلال کنترل تکانه دارند."
  ],
  "points_en": [
   "Rest tremor, bradykinesia and rigidity form the diagnostic triad of Parkinson disease.",
   "The cause is loss of dopaminergic neurons in the substantia nigra.",
   "Levodopa is a dopamine precursor that crosses the blood-brain barrier.",
   "Carbidopa is a peripheral decarboxylase inhibitor that reduces nausea.",
   "Levodopa is the most effective drug for all motor features of Parkinson disease.",
   "The choice of first drug depends largely on the patient's age.",
   "In older patients levodopa is preferred because it is better tolerated.",
   "In younger patients a dopamine agonist may be used to delay dyskinesia.",
   "Agonists in the elderly risk hallucinations, somnolence and impulse control disorders."
  ]
 },
 "explanation_fa": "تشخیص از سه‌گانه‌ی صورت سؤال روشن است و بحث اصلی انتخاب دارو است. اینجا یک قاعده‌ی سنی کاربردی وجود دارد. در بیمار جوان، نگرانی اصلی این است که سال‌ها بعد دیسکینزی ناشی از لوودوپا ظاهر شود، پس ممکن است با آگونیست دوپامین شروع کنیم. اما در بیمار هفتادساله معادله فرق می‌کند. اولاً امید به سالیانی که دیسکینزی مشکل‌ساز شود کمتر است. ثانیاً و مهم‌تر، آگونیست‌های دوپامین در سالمندان عوارض شناختی و روانی جدی می‌سازند: توهم، سردرگمی، خواب‌آلودگی ناگهانی و اختلال کنترل تکانه. پس در این بیمار لوودوپا-کربی‌دوپا هم مؤثرترین است و هم ایمن‌ترین. دو گزینه‌ی دیگر یعنی آمانتادین و تری‌هگزی‌فنیدیل اثر ضعیف‌تری دارند و در سالمندان عوارض شناختی می‌سازند.",
 "explanation_en": "The diagnosis is clear from the triad in the stem and the real issue is drug choice. There is a practical age rule here. In a younger patient the main concern is levodopa-induced dyskinesia years later, so we might start with a dopamine agonist. In a seventy-year-old the equation changes. First, there are fewer years for dyskinesia to become a problem. Second and more importantly, dopamine agonists cause serious cognitive and psychiatric adverse effects in the elderly: hallucinations, confusion, sudden sleep attacks and impulse control disorders. So in this patient levodopa-carbidopa is both the most effective and the safest. The other two options, amantadine and trihexyphenidyl, are weaker and cause cognitive side effects in the elderly.",
 "why_fa": [
  "آمانتادین اثر ضدپارکینسونی خفیفی دارد و بیشتر برای کاهش دیسکینزی ناشی از لوودوپا به کار می‌رود. برای درمان اولیه‌ی علائم اصلی کافی نیست.",
  "پاسخ صحیح — لوودوپا-کربی‌دوپا مؤثرترین درمان علائم حرکتی است و در بیمار هفتادساله انتخاب اول محسوب می‌شود.",
  "پرامی‌پکسول در بیماران جوان‌تر برای تأخیر در دیسکینزی مطرح است، اما در سالمندان خطر توهم، خواب‌آلودگی و اختلال کنترل تکانه دارد.",
  "تری‌هگزی‌فنیدیل آنتی‌کولینرژیک است و فقط روی لرزش اثر محدودی دارد. در سالمندان به‌خاطر گیجی، احتباس ادرار و اختلال حافظه باید پرهیز شود."
 ],
 "why_en": [
  "Amantadine has a mild antiparkinsonian effect and is used mainly to reduce levodopa-induced dyskinesia. It is not enough as initial therapy for the cardinal features.",
  "Correct — levodopa-carbidopa is the most effective treatment for motor symptoms and is the first choice in a seventy-year-old.",
  "Pramipexole is considered in younger patients to delay dyskinesia, but in the elderly it risks hallucinations, somnolence and impulse control disorders.",
  "Trihexyphenidyl is an anticholinergic with only limited effect on tremor. It should be avoided in the elderly because of confusion, urinary retention and memory impairment."
 ],
 "golden_fa": "پارکینسون در سالمند = لوودوپا. در جوان = آگونیست دوپامین برای تأخیر دیسکینزی.",
 "golden_en": "Parkinson disease in the elderly means levodopa; in the young, a dopamine agonist to delay dyskinesia.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 11: Parkinson disease, treatment",
  "PD MED Collaborative Group. Long-term effectiveness of dopamine agonists and MAOB inhibitors compared with levodopa. Lancet 2014;384:1196-205"
 ]
}

json.dump(L, io.open('/home/user/work/lessons/L11.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('L11:', len(L))
