# -*- coding: utf-8 -*-
"""Micro-lessons, batch 9 — Azar/Dey 1397 and Shahrivar 1399."""
import json, io
L = {}

L["1397-09:121"] = {
 "stem_en": "A 25-year-old woman presents with progressive proximal weakness of the upper and lower limbs beginning five years ago. Which gait disorder is she most likely to show?",
 "options_en": ["Festinating gait", "Steppage gait", "Apraxic gait", "Waddling gait"],
 "micro": {
  "lead_fa": "ضعف پروگزیمال یعنی عضلات کمربند لگنی؛ لگن در هر قدم پایین می‌افتد و راه رفتن اردک‌وار می‌شود.",
  "lead_en": "Proximal weakness means pelvic girdle muscles; the hip drops with every step and the gait becomes waddling.",
  "points_fa": [
   "الگوی راه رفتن در نورولوژی یک نشانه‌ی تشخیصی مستقل است، نه یک جزئیات فرعی.",
   "ضعف پروگزیمال مزمن در جوانی معمولاً منشأ عضلانی دارد، یعنی میوپاتی یا دیستروفی.",
   "عضله‌ی گلوتئوس مدیوس وظیفه دارد هنگام تک‌پا ایستادن، لگن سمت مقابل را بالا نگه دارد.",
   "وقتی این عضله ضعیف شود، لگن سمت مقابل می‌افتد و به آن علامت ترندلنبورگ می‌گویند.",
   "دوطرفه شدن این افتادگی، تنه را در هر قدم به چپ و راست می‌چرخاند: Waddling gait.",
   "Steppage gait مال ضعف دیستال و افتادگی پاست، مثلاً در فلج عصب پرونئال.",
   "Festinating gait قدم‌های کوتاه و شتاب‌گیرنده‌ی بیماری پارکینسون است.",
   "Apraxic gait حالت چسبیدن پا به زمین در ضایعات لوب فرونتال و هیدروسفالی است.",
   "علامت گاورز (بالا رفتن از روی بدن خود) همراه شایع همین ضعف کمربند لگنی است."
  ],
  "points_en": [
   "Gait pattern is an independent diagnostic sign in neurology, not a side detail.",
   "Chronic proximal weakness in a young adult usually has a muscle origin: myopathy or dystrophy.",
   "Gluteus medius keeps the opposite hip level during single-leg stance.",
   "When it weakens, the opposite hip drops, which is the Trendelenburg sign.",
   "When this happens bilaterally, the trunk sways side to side with each step: a waddling gait.",
   "Steppage gait belongs to distal weakness and foot drop, as in peroneal palsy.",
   "Festinating gait is the short, accelerating stride of Parkinson disease.",
   "Apraxic gait is the magnetic, stuck-to-the-floor walk of frontal lesions and hydrocephalus.",
   "Gower sign, climbing up one's own body, commonly accompanies this pelvic girdle weakness."
  ]
 },
 "explanation_fa": "کلید این سؤال یک نگاشت ساده است: محل ضعف را پیدا کنید، الگوی راه رفتن خودش می‌آید. صورت سؤال صریح گفته ضعف پروگزیمال است، پس عضلات کمربند لگنی گرفتارند. مهم‌ترین عضله‌ی این کمربند برای راه رفتن گلوتئوس مدیوس است. کار این عضله در فاز تک‌پا این است که لگن سمت مخالف را بالا نگه دارد. اگر ضعیف شود لگن مقابل می‌افتد و بیمار برای جبران، تنه را به سمت پای تکیه‌گاه خم می‌کند. حالا اگر همین اتفاق در هر دو سمت بیفتد، بیمار در هر قدم تنه را به یک سمت می‌اندازد و راه رفتنش شبیه اردک می‌شود. سیر پنج‌ساله و سن ۲۵ سال هم با یک دیستروفی عضلانی کمربندی سازگار است.",
 "explanation_en": "The key here is a simple mapping: find where the weakness is and the gait follows. The stem explicitly says proximal, so the pelvic girdle muscles are involved. The most important girdle muscle for walking is gluteus medius. Its job in single-leg stance is to hold the opposite hip up. If it weakens, the opposite hip drops and the patient compensates by leaning the trunk toward the stance leg. When this happens on both sides, the trunk swings side to side with every step and the gait looks duck-like. A five-year course in a 25-year-old fits a limb-girdle muscular dystrophy.",
 "why_fa": [
  "Festinating gait نشانه‌ی پارکینسون است: قدم‌های کوتاه و شتاب‌گیرنده با تنه‌ی خمیده. این بیمار نه برادی‌کینزی دارد و نه ریژیدیتی.",
  "Steppage gait وقتی رخ می‌دهد که دورسی‌فلکسور مچ ضعیف باشد و بیمار زانو را بالا بیاورد تا نوک پا به زمین نگیرد. این ضعف دیستال است، نه پروگزیمال.",
  "Apraxic gait در ضایعات دوطرفه‌ی لوب فرونتال و هیدروسفالی با فشار طبیعی دیده می‌شود. در آن قدرت عضلانی سالم است ولی برنامه‌ریزی حرکت مختل است.",
  "پاسخ صحیح — ضعف دوطرفه‌ی گلوتئوس مدیوس، تنه را در هر قدم به چپ و راست می‌چرخاند و همان راه رفتن اردک‌وار را می‌سازد."
 ],
 "why_en": [
  "Festinating gait belongs to Parkinson disease: short accelerating steps with a stooped trunk. This patient has neither bradykinesia nor rigidity.",
  "Steppage gait occurs when ankle dorsiflexors are weak and the patient lifts the knee to clear the toes. That is distal, not proximal, weakness.",
  "Apraxic gait is seen in bilateral frontal lesions and normal-pressure hydrocephalus. Muscle strength is intact but motor planning fails.",
  "Correct — bilateral gluteus medius weakness swings the trunk side to side with each step, producing the waddling gait."
 ],
 "golden_fa": "ضعف پروگزیمال ← اردک‌وار. ضعف دیستال ← استپاژ. پارکینسون ← فستیناتینگ. فرونتال ← اپراکسیک.",
 "golden_en": "Proximal weakness leads to waddling. Distal weakness leads to steppage. Parkinson leads to festinating. Frontal lesions lead to apraxic gait.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 9: Motor deficits, gait disorders",
  "Aminoff MJ et al. Clinical Neurology, 11th ed (2021) — Ch. 9: Myopathies, limb-girdle dystrophy"
 ]
}

L["1397-10:115"] = {
 "stem_en": "A 30-year-old woman has attacks of severe unilateral throbbing headache with nausea and vomiting. Each attack lasts 2 to 42 hours and occurs 4 to 5 times a month, impairing her function. Which treatment do you recommend to prevent these headaches?",
 "options_en": ["Topiramate", "Metoclopramide", "Sumatriptan", "Ergotamine"],
 "micro": {
  "lead_fa": "چهار تا پنج حمله در ماه با اختلال عملکرد یعنی بیمار به درمان پیشگیرانه‌ی روزانه نیاز دارد.",
  "lead_en": "Four to five disabling attacks a month means this patient needs daily preventive therapy.",
  "points_fa": [
   "میگرن سردردی یک‌طرفه، ضربان‌دار، متوسط تا شدید و همراه تهوع یا ترس از نور است.",
   "هر حمله‌ی درمان‌نشده بین چهار تا هفتاد و دو ساعت طول می‌کشد.",
   "درمان دو شاخه دارد: قطع حمله‌ی حاد و پیشگیری از تکرار حمله.",
   "معیار شروع پیشگیری: بیش از چهار حمله در ماه یا حملات ناتوان‌کننده یا شکست درمان حاد.",
   "خط اول پیشگیری: پروپرانولول، توپیرامات، والپروات سدیم و آمی‌تریپتیلین.",
   "توپیرامات در بیماران چاق مزیت دارد چون وزن را کم می‌کند.",
   "عوارض توپیرامات: پارستزی، اختلال تمرکز، سنگ کلیه و گلوکوم حاد.",
   "تریپتان‌ها آگونیست گیرنده‌ی سروتونین 1B/1D و فقط برای قطع حمله‌اند.",
   "مصرف بیش از ده روز در ماه از داروی حاد، سردرد ناشی از مصرف بیش از حد دارو می‌سازد."
  ],
  "points_en": [
   "Migraine is a unilateral, throbbing, moderate-to-severe headache with nausea or photophobia.",
   "Each untreated attack lasts between four and seventy-two hours.",
   "Treatment has two arms: aborting the acute attack and preventing recurrence.",
   "Start prevention when attacks exceed four a month, are disabling, or acute therapy fails.",
   "First-line preventives: propranolol, topiramate, sodium valproate and amitriptyline.",
   "Topiramate has an advantage in obese patients because it reduces weight.",
   "Topiramate side effects: paresthesia, poor concentration, kidney stones and acute glaucoma.",
   "Triptans are serotonin 1B/1D receptor agonists and are only for aborting attacks.",
   "Using acute medication more than ten days a month causes medication-overuse headache."
  ]
 },
 "explanation_fa": "این سؤال دو مرحله دارد و مرحله‌ی دوم مهم‌تر است. مرحله‌ی اول تشخیص است که آسان است: سردرد یک‌طرفه‌ی ضربان‌دار با تهوع و استفراغ در یک خانم جوان، یعنی میگرن. مرحله‌ی دوم انتخاب شاخه‌ی درمانی است. صورت سؤال با دو قرینه‌ی صریح می‌گوید پیشگیری می‌خواهد: چهار تا پنج حمله در ماه و اختلال عملکرد. حالا سه گزینه‌ی دیگر را نگاه کنید. سوماتریپتان و ارگوتامین هر دو داروی قطع حمله‌اند و اگر روزانه مصرف شوند فقط سردرد جدید می‌سازند. متوکلوپرامید هم داروی کمکی برای تهوع در همان حمله‌ی حاد است. پس تنها گزینه‌ای که در فهرست پیشگیری قرار می‌گیرد توپیرامات است.",
 "explanation_en": "This item has two steps and the second matters more. Step one is the diagnosis, which is easy: unilateral throbbing headache with nausea and vomiting in a young woman means migraine. Step two is choosing the treatment arm. The stem gives two explicit cues that prevention is wanted: four to five attacks a month and impaired function. Now look at the other three options. Sumatriptan and ergotamine are both abortive drugs and, taken daily, would only create a new headache. Metoclopramide is an adjunct for nausea within the acute attack. So the only option on the preventive list is topiramate.",
 "why_fa": [
  "پاسخ صحیح — توپیرامات از ضد صرع‌های خط اول پیشگیری میگرن است و شواهد قوی دارد. در بیماران با اضافه وزن مزیت دوگانه دارد.",
  "متوکلوپرامید ضد تهوع و کمک‌درمان حمله‌ی حاد است. اثر پیشگیرانه ندارد و مصرف طولانی آن خطر اختلالات حرکتی دارد.",
  "سوماتریپتان تریپتان و داروی قطع حمله است. برای پیشگیری تجویز نمی‌شود و مصرف مکررش سردرد بازگشتی می‌سازد.",
  "ارگوتامین هم داروی حمله‌ی حاد است و امروز جایگاه محدودی دارد. مصرف منظم آن باعث ارگوتیسم و سردرد مزمن می‌شود."
 ],
 "why_en": [
  "Correct — topiramate is a first-line anticonvulsant preventive for migraine with strong evidence. In overweight patients it offers a double benefit.",
  "Metoclopramide is an antiemetic adjunct for the acute attack. It has no preventive effect and long-term use risks movement disorders.",
  "Sumatriptan is a triptan and an abortive drug. It is not prescribed for prevention and frequent use causes rebound headache.",
  "Ergotamine is also abortive and now has a limited role. Regular use causes ergotism and chronic headache."
 ],
 "golden_fa": "بیش از چهار حمله در ماه = وقت پیشگیری. پیشگیری یعنی توپیرامات، پروپرانولول، والپروات، آمی‌تریپتیلین.",
 "golden_en": "More than four attacks a month means it is time for prevention: topiramate, propranolol, valproate or amitriptyline.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 6: Migraine, prophylactic therapy",
  "Silberstein SD et al. Evidence-based guideline update: pharmacologic treatment for episodic migraine prevention. Neurology 2012;78:1337-45"
 ]
}

L["1397-10:119"] = {
 "stem_en": "A 30-year-old man had a transient loss of consciousness with a fall. In distinguishing seizure from syncope, which of the following most favours a seizure?",
 "options_en": ["Pallor and sweating before the event", "Rapid recovery of consciousness after the event",
                "Lateral tongue biting", "Occurrence after prolonged standing"],
 "micro": {
  "lead_fa": "گاز گرفتن کناره‌ی زبان اختصاصی‌ترین نشانه‌ی بالینی به نفع تشنج است.",
  "lead_en": "Lateral tongue biting is the most specific clinical sign favouring a seizure.",
  "points_fa": [
   "افتراق تشنج از سنکوپ بیشتر با شرح حال انجام می‌شود تا با آزمایش.",
   "سنکوپ معمولاً پیش‌درآمد دارد: تاری دید، وزوز گوش، رنگ‌پریدگی و تعریق سرد.",
   "این پیش‌درآمد نشانه‌ی افت خون‌رسانی مغز است و چند ثانیه تا چند دقیقه طول می‌کشد.",
   "محرک‌های سنکوپ: ایستادن طولانی، گرما، درد، دیدن خون و سرفه یا ادرار کردن.",
   "بازگشت هوشیاری در سنکوپ سریع و کامل است، معمولاً زیر یک دقیقه.",
   "در تشنج، مرحله‌ی پس از حمله با گیجی طولانی و خواب‌آلودگی همراه است.",
   "گاز گرفتن کناره‌ی زبان ویژگی حدود نود درصد دارد اما حساسیت کمی دارد.",
   "گاز گرفتن نوک زبان اختصاصی نیست و در سنکوپ هم دیده می‌شود.",
   "بی‌اختیاری ادرار در هر دو رخ می‌دهد و ارزش افتراقی کمی دارد."
  ],
  "points_en": [
   "Separating seizure from syncope is done mainly by history, not by tests.",
   "Syncope usually has a prodrome: blurred vision, tinnitus, pallor and cold sweat.",
   "That prodrome reflects falling cerebral perfusion and lasts seconds to minutes.",
   "Syncope triggers: prolonged standing, heat, pain, the sight of blood, coughing or micturition.",
   "Recovery in syncope is rapid and complete, usually under a minute.",
   "After a seizure, the postictal phase brings prolonged confusion and drowsiness.",
   "Lateral tongue biting is about ninety percent specific but has low sensitivity.",
   "Biting the tip of the tongue is not specific and also occurs in syncope.",
   "Urinary incontinence happens in both and has little discriminating value."
  ]
 },
 "explanation_fa": "این سؤال کلاسیک است و هر گزینه یک ویژگی سنکوپ یا تشنج را می‌آزماید. رنگ‌پریدگی و تعریق قبل از حمله همان پیش‌درآمد وازوواگال است که از افت خون‌رسانی مغز می‌آید و به نفع سنکوپ است. بازگشت سریع هوشیاری هم مشخصه‌ی سنکوپ است، چون به‌محض دراز کشیدن بیمار خون‌رسانی برمی‌گردد؛ در مقابل تشنج تونیک-کلونیک تقریباً همیشه مرحله‌ی گیجی پس از حمله دارد. حمله در حالت ایستادن طولانی هم محرک کلاسیک سنکوپ وازوواگال است. تنها گزینه‌ای که به سمت تشنج می‌رود گاز گرفتن کناره‌ی زبان است. دلیلش مکانیکی است: در فاز تونیک، فک‌ها محکم روی هم قفل می‌شوند و زبان بین دندان‌های آسیا گیر می‌کند. به همین دلیل جای گاز در کناره است نه نوک زبان.",
 "explanation_en": "This is a classic item and each option tests one feature of syncope or seizure. Pallor and sweating beforehand are the vasovagal prodrome caused by falling cerebral perfusion, and favour syncope. Rapid recovery also characterises syncope, because perfusion returns the moment the patient lies flat; a tonic-clonic seizure almost always has a postictal confusional phase instead. An event after prolonged standing is the classic vasovagal trigger. The only option pointing to seizure is lateral tongue biting. The reason is mechanical: in the tonic phase the jaws clamp shut and the tongue is caught between the molars. That is why the bite mark sits on the side rather than the tip.",
 "why_fa": [
  "رنگ‌پریدگی و تعریق سرد قبل از حمله، پیش‌درآمد وازوواگال است و از فعال شدن سیستم پاراسمپاتیک می‌آید. این یافته به نفع سنکوپ است.",
  "بازگشت سریع هوشیاری مشخصه‌ی سنکوپ است. تشنج تونیک-کلونیک معمولاً گیجی و خواب‌آلودگی چند ده دقیقه‌ای به دنبال دارد.",
  "پاسخ صحیح — قفل شدن فک در فاز تونیک زبان را بین دندان‌های آسیا می‌گیرد و کناره‌ی زبان زخم می‌شود. این نشانه ویژگی بالایی دارد.",
  "ایستادن طولانی محرک شناخته‌شده‌ی سنکوپ وازوواگال است، به‌ویژه در محیط گرم و شلوغ. تشنج معمولاً به وضعیت بدن وابسته نیست."
 ],
 "why_en": [
  "Pallor and cold sweat beforehand are the vasovagal prodrome from parasympathetic activation. This finding favours syncope.",
  "Rapid recovery characterises syncope. A tonic-clonic seizure usually leaves tens of minutes of confusion and drowsiness.",
  "Correct — jaw clamping in the tonic phase traps the tongue between the molars and injures its lateral border. This sign is highly specific.",
  "Prolonged standing is a well-known vasovagal trigger, especially in a hot crowded place. Seizures are usually independent of posture."
 ],
 "golden_fa": "کناره‌ی زبان + گیجی طولانی = تشنج. پیش‌درآمد رنگ‌پریدگی + بازگشت سریع = سنکوپ.",
 "golden_en": "Lateral tongue plus prolonged confusion means seizure. Pallor prodrome plus rapid recovery means syncope.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 12: Seizures and syncope",
  "Benbadis SR, Wolgamuth BR et al. Value of tongue biting in the diagnosis of seizures. Arch Intern Med 1995;155:2346-9"
 ]
}

L["1397-10:120"] = {
 "stem_en": "A 65-year-old patient complains of hand tremor. The tremor worsens when holding a glass or writing and is absent at rest. His father had a similar history. Which treatment is most appropriate?",
 "options_en": ["Levodopa", "Propranolol", "Trihexyphenidyl", "Tetrabenazine"],
 "micro": {
  "lead_fa": "لرزش هنگام عمل، غیاب در استراحت و سابقه‌ی خانوادگی سه‌گانه‌ی ترمور اسانسیل است.",
  "lead_en": "Action tremor, absent at rest, plus a family history is the triad of essential tremor.",
  "points_fa": [
   "لرزش را همیشه بر اساس زمان بروزش دسته‌بندی کنید: استراحت، وضعیتی یا حین عمل.",
   "لرزش استراحت وقتی دیده می‌شود که اندام کاملاً تکیه‌گاه دارد و شل است.",
   "لرزش استراحت با فرکانس چهار تا شش هرتز مشخصه‌ی بیماری پارکینسون است.",
   "لرزش وضعیتی و حین عمل هنگام نگه داشتن لیوان یا نوشتن ظاهر می‌شود.",
   "ترمور اسانسیل شایع‌ترین اختلال حرکتی است و اغلب اتوزومال غالب ارث می‌رسد.",
   "این لرزش معمولاً دوطرفه است و سر و صدا را هم می‌تواند درگیر کند.",
   "مصرف مقدار کمی الکل موقتاً لرزش اسانسیل را کم می‌کند، که یک سرنخ تشخیصی است.",
   "خط اول دارویی: پروپرانولول یا پریمیدون؛ هر دو اثر مشابه دارند.",
   "در موارد مقاوم و ناتوان‌کننده، تحریک عمقی مغز در هسته‌ی VIM تالاموس مؤثر است."
  ],
  "points_en": [
   "Always classify tremor by when it appears: at rest, on posture, or during action.",
   "Rest tremor is seen when the limb is fully supported and relaxed.",
   "A four-to-six-hertz rest tremor characterises Parkinson disease.",
   "Postural and action tremor appears when holding a glass or writing.",
   "Essential tremor is the commonest movement disorder and is often autosomal dominant.",
   "It is usually bilateral and may also involve the head and voice.",
   "A small amount of alcohol transiently reduces essential tremor, which is a diagnostic clue.",
   "First-line drugs: propranolol or primidone; both have comparable efficacy.",
   "For refractory disabling cases, deep brain stimulation of the thalamic VIM nucleus works."
  ]
 },
 "explanation_fa": "صورت سؤال سه سرنخ کنار هم گذاشته و هر سه یک جهت را نشان می‌دهند. اول اینکه لرزش هنگام نگه داشتن لیوان و نوشتن تشدید می‌شود، یعنی لرزش وضعیتی و حین عمل است. دوم اینکه در حالت استراحت وجود ندارد، که مستقیماً پارکینسون را کنار می‌گذارد چون لرزش پارکینسون دقیقاً برعکس است. سوم سابقه‌ی مشابه در پدر، که الگوی وراثت اتوزومال غالب ترمور اسانسیل را نشان می‌دهد. پس تشخیص ترمور اسانسیل است و درمان خط اول پروپرانولول یا پریمیدون. سه گزینه‌ی دیگر هر کدام برای یک اختلال حرکتی دیگر ساخته شده‌اند و در ترمور اسانسیل جایی ندارند.",
 "explanation_en": "The stem stacks three clues that all point the same way. First, the tremor worsens when holding a glass and writing, so it is postural and action tremor. Second, it is absent at rest, which directly excludes Parkinson disease because the parkinsonian tremor is exactly the opposite. Third, the father had the same problem, matching the autosomal dominant inheritance of essential tremor. So the diagnosis is essential tremor and first-line treatment is propranolol or primidone. The other three options each belong to a different movement disorder and have no role here.",
 "why_fa": [
  "لوودوپا درمان بیماری پارکینسون است. اینجا لرزش در استراحت وجود ندارد و برادی‌کینزی یا ریژیدیتی هم گزارش نشده است.",
  "پاسخ صحیح — پروپرانولول بتابلوکر غیرانتخابی و خط اول ترمور اسانسیل است. در آسم و بلوک قلبی باید محتاط بود و پریمیدون جایگزین می‌شود.",
  "تری‌هگزی‌فنیدیل آنتی‌کولینرژیک است و بیشتر در دیستونی و لرزش پارکینسونی جوانان به کار می‌رود. در سالمندان خطر گیجی و اختلال شناختی دارد.",
  "تترابنازین مهارکننده‌ی VMAT2 است و برای کره‌ی هانتینگتون و دیسکینزی تأخیری کاربرد دارد، نه ترمور اسانسیل."
 ],
 "why_en": [
  "Levodopa treats Parkinson disease. Here there is no rest tremor and no bradykinesia or rigidity is reported.",
  "Correct — propranolol is a non-selective beta-blocker and first-line for essential tremor. Use caution in asthma and heart block, where primidone substitutes.",
  "Trihexyphenidyl is an anticholinergic used mainly in dystonia and young-onset parkinsonian tremor. In the elderly it risks confusion and cognitive impairment.",
  "Tetrabenazine is a VMAT2 inhibitor used for Huntington chorea and tardive dyskinesia, not for essential tremor."
 ],
 "golden_fa": "لرزش حین عمل + سابقه‌ی خانوادگی = ترمور اسانسیل = پروپرانولول یا پریمیدون.",
 "golden_en": "Action tremor plus family history means essential tremor, treated with propranolol or primidone.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 11: Tremor, essential tremor",
  "Deuschl G, Raethjen J et al. Treatment of patients with essential tremor. Lancet Neurol 2011;10:148-61"
 ]
}

L["1397-10:121"] = {
 "stem_en": "A 45-year-old woman presents with severe lancinating pain in the right cheek and jaw. The pain lasts a few seconds and is triggered by brushing her teeth or touching her face. Neurological examination is normal. What is the treatment of choice?",
 "options_en": ["Carbamazepine", "Gabapentin", "Amitriptyline", "Indomethacin"],
 "micro": {
  "lead_fa": "درد چند ثانیه‌ای برق‌آسا در قلمرو عصب تریژمینال با نقطه‌ی محرک، یعنی نورالژی تریژمینال.",
  "lead_en": "A few seconds of electric-shock pain in the trigeminal territory with a trigger zone means trigeminal neuralgia.",
  "points_fa": [
   "نورالژی تریژمینال دردی تیرکشنده و بسیار کوتاه در قلمرو عصب پنجم است.",
   "شاخه‌های ماگزیلاری و ماندیبولار بیشتر از شاخه‌ی افتالمیک درگیر می‌شوند.",
   "درد از چند ثانیه تا حداکثر دو دقیقه طول می‌کشد و بین حملات بیمار بی‌درد است.",
   "نقطه‌ی محرک ویژگی کلیدی است: مسواک زدن، لمس صورت، جویدن یا باد سرد.",
   "در فرم کلاسیک، فشار حلقه‌ی شریان سربلار فوقانی بر ریشه‌ی عصب علت است.",
   "معاینه‌ی عصبی طبیعی است؛ کاهش حس صورت باید شما را به دنبال علت ثانویه بفرستد.",
   "شروع زیر چهل سالگی یا درگیری دوطرفه، ام‌اس را مطرح می‌کند و MRI لازم است.",
   "کاربامازپین خط اول است و پاسخ سریع به آن ارزش تشخیصی هم دارد.",
   "در مقاومت دارویی، جراحی رفع فشار میکروواسکولار درمان قطعی است."
  ],
  "points_en": [
   "Trigeminal neuralgia is a lancinating, very brief pain in the fifth nerve territory.",
   "The maxillary and mandibular divisions are involved more often than the ophthalmic.",
   "Pain lasts seconds up to two minutes and the patient is pain-free between attacks.",
   "A trigger zone is the key feature: brushing teeth, touching the face, chewing or cold wind.",
   "In the classic form, a loop of the superior cerebellar artery compresses the nerve root.",
   "The examination is normal; facial sensory loss should send you looking for a secondary cause.",
   "Onset under forty or bilateral involvement suggests multiple sclerosis and warrants MRI.",
   "Carbamazepine is first-line and a rapid response to it also carries diagnostic value.",
   "When drugs fail, microvascular decompression surgery is the definitive treatment."
  ]
 },
 "explanation_fa": "برای رسیدن به پاسخ باید چهار مشخصه‌ی صورت سؤال را کنار هم بگذارید. محل درد گونه و فک راست است که قلمرو شاخه‌های دوم و سوم عصب تریژمینال را می‌سازد. کیفیت درد تیرکشنده و برق‌آسا است. مدت آن فقط چند ثانیه است، که آن را از میگرن و سردرد خوشه‌ای جدا می‌کند. و مهم‌تر از همه یک نقطه‌ی محرک دارد: مسواک زدن یا لمس صورت حمله را راه می‌اندازد. این چهار ویژگی با هم تعریف کتابی نورالژی تریژمینال است و طبیعی بودن معاینه هم فرم کلاسیک را تأیید می‌کند. کاربامازپین با مهار کانال سدیم وابسته به ولتاژ، شلیک خودبه‌خودی ریشه‌ی عصب را خاموش می‌کند و درمان انتخابی است.",
 "explanation_en": "To reach the answer, put four features of the stem together. The site is the right cheek and jaw, the territory of the second and third trigeminal divisions. The quality is lancinating and electric. The duration is only seconds, which separates it from migraine and cluster headache. Most importantly there is a trigger zone: brushing the teeth or touching the face sets off an attack. Together these four features are the textbook definition of trigeminal neuralgia, and the normal examination confirms the classic form. Carbamazepine blocks voltage-gated sodium channels, silences the spontaneous firing of the nerve root, and is the treatment of choice.",
 "why_fa": [
  "پاسخ صحیح — کاربامازپین با مسدود کردن کانال سدیم، تخلیه‌ی الکتریکی نابجای ریشه‌ی تریژمینال را مهار می‌کند. پیش از شروع باید سدیم و شمارش سلولی چک شود.",
  "گاباپنتین در نورالژی تریژمینال فقط خط دوم یا داروی افزودنی است. اثربخشی آن کمتر از کاربامازپین و اکس‌کاربازپین است.",
  "آمی‌تریپتیلین برای درد نوروپاتیک مداوم و سوزشی مفید است، مثل نورالژی پس از زونا. برای درد برق‌آسای کوتاه انتخاب اول نیست.",
  "ایندومتاسین پاسخ اختصاصی در همی‌کرانیا کانتینوآ و همی‌کرانیای حمله‌ای دارد. آن سردردها ساعت‌ها یا دقیقه‌ها طول می‌کشند، نه چند ثانیه."
 ],
 "why_en": [
  "Correct — carbamazepine blocks sodium channels and suppresses ectopic firing of the trigeminal root. Check sodium and blood counts before starting.",
  "Gabapentin is only second-line or an add-on in trigeminal neuralgia. It is less effective than carbamazepine and oxcarbazepine.",
  "Amitriptyline helps continuous burning neuropathic pain such as post-herpetic neuralgia. It is not first choice for brief electric pain.",
  "Indomethacin gives a specific response in hemicrania continua and paroxysmal hemicrania. Those headaches last hours or minutes, not seconds."
 ],
 "golden_fa": "درد ثانیه‌ای صورت + نقطه‌ی محرک + معاینه‌ی طبیعی = نورالژی تریژمینال = کاربامازپین.",
 "golden_en": "Seconds-long facial pain plus a trigger zone plus a normal examination means trigeminal neuralgia, treated with carbamazepine.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 6: Trigeminal neuralgia",
  "Cruccu G, Di Stefano G, Truini A. Trigeminal neuralgia. N Engl J Med 2020;383:754-62"
 ]
}

L["1399-06:114"] = {
 "stem_en": "A 60-year-old diabetic woman developed severe midline back pain after surgery, together with severe bilateral lower limb weakness. On examination the deep tendon reflexes in the lower limbs are absent, and she has sphincter dysfunction and impaired pain and temperature sensation in both lower limbs. What is the most likely diagnosis?",
 "options_en": ["Infectious myelopathy", "Traumatic myelopathy", "Spinal cord infarction", "Transverse myelitis"],
 "micro": {
  "lead_fa": "شروع ناگهانی با درد پشت پس از جراحی، همراه با از دست رفتن درد و حرارت و حفظ حس عمقی، یعنی انفارکتوس شریان اسپاینال قدامی.",
  "lead_en": "Sudden onset with back pain after surgery, loss of pain and temperature with preserved proprioception, means anterior spinal artery infarction.",
  "points_fa": [
   "نخاع یک شریان اسپاینال قدامی و دو شریان اسپاینال خلفی دارد.",
   "شریان قدامی دو سوم قدامی مقطع نخاع را تغذیه می‌کند، شامل شاخ قدامی و مسیر اسپاینوتالامیک.",
   "ستون خلفی که حس عمقی و لمس ظریف را می‌برد، از شریان‌های خلفی خون می‌گیرد.",
   "پس در انسداد شریان قدامی، درد و حرارت می‌رود اما حس عمقی سالم می‌ماند.",
   "این جدا شدن دو دسته حس، امضای تشخیصی سندرم شریان اسپاینال قدامی است.",
   "شروع بسیار ناگهانی است و اغلب با درد شدید در خط وسط پشت آغاز می‌شود.",
   "علت‌های شایع: جراحی آئورت، افت شدید فشار خون، دایسکشن و آترواسکلروز.",
   "دیابت و بیماری عروقی زمینه‌ای خطر را بالا می‌برد.",
   "در فاز حاد شوک نخاعی داریم: فلج شل و آرفلکسی که بعداً به اسپاستیسیته تبدیل می‌شود."
  ],
  "points_en": [
   "The cord has one anterior spinal artery and two posterior spinal arteries.",
   "The anterior artery supplies the anterior two-thirds, including anterior horns and spinothalamic tracts.",
   "The posterior columns, carrying proprioception and fine touch, are fed by the posterior arteries.",
   "So when the anterior artery occludes, pain and temperature are lost but proprioception survives.",
   "This dissociated sensory loss is the diagnostic signature of anterior spinal artery syndrome.",
   "Onset is very abrupt and often begins with severe midline back pain.",
   "Common causes: aortic surgery, severe hypotension, dissection and atherosclerosis.",
   "Diabetes and underlying vascular disease raise the risk.",
   "In the acute phase there is spinal shock: flaccid paralysis and areflexia that later become spastic."
  ]
 },
 "explanation_fa": "چهار عنصر صورت سؤال را جدا کنید تا پاسخ روشن شود. زمینه: بیمار دیابتی و سالمند است و همین حالا جراحی شده، یعنی هم عروق آسیب‌دیده دارد و هم احتمال افت فشار حین عمل. شروع: درد شدید در خط وسط پشت که مشخصه‌ی ایسکمی حاد نخاع است. الگوی حرکتی: پاراپارزی شدید با آرفلکسی، که در فاز حاد شوک نخاعی طبیعی است. و مهم‌ترین بخش، الگوی حسی: فقط درد و حرارت مختل شده است. اگر کل مقطع نخاع درگیر بود، مثل میلیت عرضی، حس عمقی هم می‌رفت. حفظ حس عمقی یعنی ستون خلفی سالم است و آسیب فقط به قلمرو شریان اسپاینال قدامی محدود شده است.",
 "explanation_en": "Separate the four elements of the stem and the answer emerges. Background: an elderly diabetic woman just out of surgery, so she has both damaged vessels and a chance of intraoperative hypotension. Onset: severe midline back pain, the hallmark of acute cord ischaemia. Motor pattern: severe paraparesis with areflexia, normal in the acute spinal shock phase. And the most important part, the sensory pattern: only pain and temperature are impaired. If the whole cord cross-section were involved, as in transverse myelitis, proprioception would go too. Preserved proprioception means the posterior columns are intact and the damage is confined to the anterior spinal artery territory.",
 "why_fa": [
  "میلوپاتی عفونی مثل آبسه‌ی اپیدورال معمولاً تب و افزایش نشانگرهای التهابی دارد و طی روزها پیش می‌رود، نه ناگهانی. الگوی جدا شدن حس هم نمی‌سازد.",
  "میلوپاتی تروماتیک نیاز به سابقه‌ی ضربه‌ی مستقیم به ستون فقرات دارد که در صورت سؤال ذکر نشده است.",
  "پاسخ صحیح — شروع ناگهانی پس از جراحی با درد پشت و از دست رفتن انتخابی درد و حرارت، تصویر کامل سندرم شریان اسپاینال قدامی است.",
  "میلیت عرضی معمولاً طی ساعت‌ها تا چند روز پیش می‌رود و همه‌ی مسیرهای حسی از جمله ستون خلفی را می‌گیرد. سطح حسی کامل دارد نه جدا شده."
 ],
 "why_en": [
  "Infectious myelopathy such as epidural abscess usually brings fever and raised inflammatory markers and evolves over days, not suddenly. It also does not produce dissociated sensory loss.",
  "Traumatic myelopathy requires a history of direct spinal injury, which the stem does not mention.",
  "Correct — abrupt onset after surgery with back pain and selective loss of pain and temperature is the full picture of anterior spinal artery syndrome.",
  "Transverse myelitis usually evolves over hours to days and affects all sensory tracts including the posterior columns. It gives a complete, not a dissociated, sensory level."
 ],
 "golden_fa": "درد و حرارت رفته، حس عمقی مانده، شروع ناگهانی = شریان اسپاینال قدامی.",
 "golden_en": "Pain and temperature lost, proprioception preserved, abrupt onset means anterior spinal artery infarction.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 9: Spinal cord vascular disease",
  "Aminoff MJ et al. Clinical Neurology, 11th ed (2021) — Ch. 10: Sensory dissociation and cord syndromes"
 ]
}

L["1399-06:115"] = {
 "stem_en": "A 25-year-old man with a history of seizures who stopped his medication on his own has been brought to the emergency department with continuous seizures since this morning. Regarding his management, which of the following is NOT correct?",
 "options_en": ["Giving intravenous lorazepam or diazepam", "Starting intravenous phenytoin",
                "Using midazolam if seizures continue", "Treating cerebral oedema and starting corticosteroids"],
 "micro": {
  "lead_fa": "حالت صرعی یک نردبان درمانی ثابت دارد و کورتیکواستروئید هیچ پله‌ای از آن نیست.",
  "lead_en": "Status epilepticus has a fixed treatment ladder and corticosteroids are not one of its rungs.",
  "points_fa": [
   "حالت صرعی یعنی تشنج بیش از پنج دقیقه یا تشنج‌های پیاپی بدون بازگشت هوشیاری.",
   "این یک اورژانس واقعی است چون آسیب نورونی با گذشت زمان جمع می‌شود.",
   "شایع‌ترین علت در بیمار صرعی شناخته‌شده، قطع خودسرانه‌ی دارو است.",
   "پله‌ی اول: بنزودیازپین وریدی، لورازپام چهار میلی‌گرم یا دیازپام ده میلی‌گرم.",
   "همزمان باید راه هوایی، اکسیژن، قند خون و الکترولیت‌ها بررسی شوند.",
   "پله‌ی دوم: داروی ضدصرع وریدی مثل فنی‌توئین، فوس‌فنی‌توئین، والپروات یا لواتیراستام.",
   "دوز بارگیری فنی‌توئین بیست میلی‌گرم بر کیلوگرم است، با سرعت کمتر از پنجاه میلی‌گرم در دقیقه.",
   "پله‌ی سوم در مقاومت: بیهوشی عمومی با میدازولام، پروپوفول یا تیوپنتال در ICU.",
   "کورتیکواستروئید فقط جای ادم واسوژنیک اطراف تومور یا آبسه دارد، نه در خود حالت صرعی."
  ],
  "points_en": [
   "Status epilepticus means a seizure lasting over five minutes or repeated seizures without recovery.",
   "It is a true emergency because neuronal injury accumulates with time.",
   "The commonest cause in a known epileptic is stopping medication without advice.",
   "Step one: intravenous benzodiazepine, lorazepam four milligrams or diazepam ten milligrams.",
   "At the same time secure the airway and check oxygen, glucose and electrolytes.",
   "Step two: an intravenous antiseizure drug such as phenytoin, fosphenytoin, valproate or levetiracetam.",
   "The phenytoin loading dose is twenty milligrams per kilogram at under fifty milligrams per minute.",
   "Step three if refractory: general anaesthesia with midazolam, propofol or thiopental in the ICU.",
   "Corticosteroids only have a place for vasogenic oedema around a tumour or abscess, not in status itself."
  ]
 },
 "explanation_fa": "این سؤال از نوع «کدام غلط است» است، پس باید نردبان درمانی حالت صرعی را در ذهن داشته باشید و ببینید کدام گزینه بیرون از آن است. سه گزینه‌ی اول دقیقاً سه پله‌ی استاندارد را می‌گویند: بنزودیازپین وریدی برای قطع فوری، سپس فنی‌توئین وریدی برای جلوگیری از عود، و در صورت ادامه، میدازولام و بیهوشی. گزینه‌ی چهارم اما درمان ادم مغزی و کورتیکواستروئید را پیشنهاد می‌کند. در این بیمار علت روشن است و قطع خودسرانه‌ی دارو است؛ نه ضایعه‌ی فضاگیری وجود دارد و نه ادم واسوژنیک. کورتیکواستروئید نه تشنج را قطع می‌کند و نه از عود جلوگیری می‌کند، و تجویز آن فقط وقت طلایی را هدر می‌دهد و عوارضی مانند هایپرگلیسمی اضافه می‌کند.",
 "explanation_en": "This is a NOT question, so hold the status epilepticus ladder in mind and find the option outside it. The first three options are exactly the three standard rungs: an intravenous benzodiazepine to stop the seizure now, then intravenous phenytoin to prevent recurrence, then midazolam and anaesthesia if it continues. The fourth option proposes treating cerebral oedema with corticosteroids. In this patient the cause is clear, namely stopping medication; there is no mass lesion and no vasogenic oedema. Corticosteroids neither abort the seizure nor prevent recurrence, and giving them only wastes golden time while adding harms such as hyperglycaemia.",
 "why_fa": [
  "لورازپام یا دیازپام وریدی پله‌ی اول استاندارد است و باید در همان دقایق نخست داده شود. این اقدام صحیح است.",
  "فنی‌توئین وریدی پله‌ی دوم است و پس از بنزودیازپین برای جلوگیری از عود بارگیری می‌شود. این اقدام هم صحیح است.",
  "میدازولام در حالت صرعی مقاوم برای القای بیهوشی به کار می‌رود و نیاز به مانیتورینگ در ICU دارد. این هم صحیح است.",
  "پاسخ صحیح (گزینه‌ی نادرست) — کورتیکواستروئید در حالت صرعی ناشی از قطع دارو جایی ندارد. فقط در ادم واسوژنیک اطراف تومور یا آبسه اندیکاسیون دارد."
 ],
 "why_en": [
  "Intravenous lorazepam or diazepam is the standard first rung and must be given in the first minutes. This step is correct.",
  "Intravenous phenytoin is the second rung, loaded after the benzodiazepine to prevent recurrence. This is also correct.",
  "Midazolam is used to induce anaesthesia in refractory status and requires ICU monitoring. This is correct too.",
  "Correct answer (the false statement) — corticosteroids have no place in status caused by drug withdrawal. They are indicated only for vasogenic oedema around a tumour or abscess."
 ],
 "golden_fa": "نردبان حالت صرعی: بنزودیازپین ← فنی‌توئین ← بیهوشی. کورتیکواستروئید در این نردبان نیست.",
 "golden_en": "Status ladder: benzodiazepine, then phenytoin, then anaesthesia. Corticosteroids are not on this ladder.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 12: Status epilepticus",
  "Glauser T et al. Evidence-based guideline: treatment of convulsive status epilepticus. Epilepsy Curr 2016;16:48-61"
 ]
}

L["1399-06:116"] = {
 "stem_en": "An 82-year-old woman has been brought to clinic with fluctuating cognitive impairment without clear early amnesia and with visual hallucinations for about six months. On examination parkinsonism is evident. Which diagnosis is most likely?",
 "options_en": ["Frontotemporal dementia", "Alzheimer disease", "Dementia with Lewy bodies", "Wilson disease"],
 "micro": {
  "lead_fa": "نوسان شناختی، توهم بینایی و پارکینسونیسم سه‌گانه‌ی اصلی دمانس با اجسام لویی است.",
  "lead_en": "Cognitive fluctuation, visual hallucinations and parkinsonism are the core triad of dementia with Lewy bodies.",
  "points_fa": [
   "دمانس با اجسام لویی دومین علت شایع دمانس دژنراتیو پس از آلزایمر است.",
   "سه ویژگی هسته‌ای دارد: نوسان توجه و هوشیاری، توهم بینایی شکل‌یافته و پارکینسونیسم.",
   "نوسان یعنی بیمار در یک ساعت هوشیار و شفاف و ساعتی بعد گیج و خواب‌آلود است.",
   "توهم‌ها معمولاً بینایی، دقیق و شکل‌یافته‌اند: آدم‌ها یا حیوانات کوچک.",
   "برخلاف آلزایمر، حافظه در مراحل اول نسبتاً حفظ می‌شود و توجه بیشتر آسیب می‌بیند.",
   "اختلال رفتاری خواب REM اغلب سال‌ها قبل از دمانس ظاهر می‌شود.",
   "قاعده‌ی یک‌ساله: اگر پارکینسونیسم بیش از یک سال قبل از دمانس باشد، دمانس بیماری پارکینسون است.",
   "حساسیت شدید به داروهای نورولپتیک وجود دارد و هالوپریدول می‌تواند خطرناک باشد.",
   "درمان علامتی با مهارکننده‌های کولین‌استراز مثل ریواستیگمین پاسخ خوبی می‌دهد."
  ],
  "points_en": [
   "Dementia with Lewy bodies is the second commonest degenerative dementia after Alzheimer disease.",
   "It has three core features: fluctuating attention, well-formed visual hallucinations and parkinsonism.",
   "Fluctuation means the patient is lucid one hour and confused or drowsy the next.",
   "Hallucinations are typically visual, detailed and well formed: people or small animals.",
   "Unlike Alzheimer disease, memory is relatively spared early while attention suffers more.",
   "REM sleep behaviour disorder often appears years before the dementia.",
   "The one-year rule: if parkinsonism precedes dementia by over a year, it is Parkinson disease dementia.",
   "There is severe neuroleptic sensitivity and haloperidol can be dangerous.",
   "Symptomatic treatment with cholinesterase inhibitors such as rivastigmine works well."
  ]
 },
 "explanation_fa": "این سؤال سه‌گانه‌ی هسته‌ای را تقریباً کلمه‌به‌کلمه در صورت سؤال گذاشته است. اول «اختلال شناختی نوسان‌کننده» که یعنی توجه و هوشیاری در طول روز بالا و پایین می‌رود. دوم «بدون فراموشی واضح اولیه» که یک نشانه‌ی منفی مهم است و آلزایمر را کنار می‌گذارد، چون آلزایمر با فراموشی حافظه‌ی اخیر شروع می‌شود. سوم «توهم بینایی» که در آلزایمر اگر هم بیاید دیرهنگام است ولی در این بیماری زودرس و شکل‌یافته است. و چهارم «پارکینسونیسم در معاینه». وقتی این چهار عنصر کنار هم بیایند، تشخیص دمانس با اجسام لویی است. نکته‌ی درمانی حیاتی هم این است که برای کنترل توهم هرگز نباید هالوپریدول داد، چون این بیماران حساسیت شدید به نورولپتیک دارند.",
 "explanation_en": "This item places the core triad almost word for word in the stem. First, fluctuating cognition, meaning attention and alertness rise and fall through the day. Second, no clear early amnesia, an important negative that excludes Alzheimer disease, which begins with recent-memory loss. Third, visual hallucinations, which in Alzheimer disease appear late if at all but here are early and well formed. Fourth, parkinsonism on examination. When these four elements come together the diagnosis is dementia with Lewy bodies. The crucial management point is never to give haloperidol for the hallucinations, because these patients have severe neuroleptic sensitivity.",
 "why_fa": [
  "دمانس فرونتوتمپورال با تغییر شخصیت، بی‌بندوباری اجتماعی یا اختلال زبان شروع می‌شود و معمولاً زیر شصت‌وپنج سالگی است. توهم بینایی و پارکینسونیسم زودرس ندارد.",
  "بیماری آلزایمر با فراموشی حافظه‌ی اخیر آغاز می‌شود و افت آن پیوسته است نه نوسانی. صورت سؤال صریحاً غیاب فراموشی اولیه را ذکر کرده است.",
  "پاسخ صحیح — نوسان شناختی، توهم بینایی شکل‌یافته و پارکینسونیسم با هم، تعریف دمانس با اجسام لویی است.",
  "بیماری ویلسون اختلال متابولیسم مس است و معمولاً پیش از چهل سالگی با علائم کبدی، دیستونی و حلقه‌ی کایزر-فلایشر بروز می‌کند. در بیمار ۸۲ ساله بسیار بعید است."
 ],
 "why_en": [
  "Frontotemporal dementia begins with personality change, social disinhibition or language impairment and is usually under sixty-five. It lacks early visual hallucinations and parkinsonism.",
  "Alzheimer disease begins with recent-memory loss and declines steadily rather than fluctuating. The stem explicitly denies early amnesia.",
  "Correct — fluctuating cognition, well-formed visual hallucinations and parkinsonism together define dementia with Lewy bodies.",
  "Wilson disease is a copper metabolism disorder presenting before forty with hepatic signs, dystonia and Kayser-Fleischer rings. It is very unlikely at eighty-two."
 ],
 "golden_fa": "نوسان + توهم بینایی + پارکینسونیسم = لوی بادی. هرگز هالوپریدول ندهید.",
 "golden_en": "Fluctuation plus visual hallucinations plus parkinsonism means Lewy body dementia. Never give haloperidol.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 5: Dementia with Lewy bodies",
  "McKeith IG et al. Diagnosis and management of dementia with Lewy bodies: fourth consensus report. Neurology 2017;89:88-100"
 ]
}

L["1399-06:117"] = {
 "stem_en": "A 31-year-old woman taking an oral contraceptive pill presents to the emergency department with headache, nausea and vomiting that began a week ago and gradually worsened, plus one seizure this morning. Examination shows bilateral papilloedema and no focal neurological signs. What is the most likely diagnosis?",
 "options_en": ["Cerebral venous sinus thrombosis", "Subarachnoid haemorrhage",
                "Idiopathic intracranial hypertension", "Bacterial meningitis"],
 "micro": {
  "lead_fa": "زن جوان + قرص ضدبارداری + سردرد پیش‌رونده + تشنج + ادم پاپی = ترومبوز سینوس وریدی مغز.",
  "lead_en": "Young woman, oral contraceptive, progressive headache, seizure and papilloedema equal cerebral venous sinus thrombosis.",
  "points_fa": [
   "ترومبوز سینوس وریدی مغز خروج خون از مغز را مسدود می‌کند، نه ورود آن را.",
   "نتیجه‌اش بالا رفتن فشار وریدی، ادم مغزی و افزایش فشار داخل جمجمه است.",
   "شایع‌ترین علامت سردرد است که در بیش از نود درصد بیماران دیده می‌شود.",
   "این سردرد برخلاف خون‌ریزی زیرعنکبوتیه معمولاً طی روزها بدتر می‌شود، نه ناگهانی.",
   "تشنج در حدود چهل درصد بیماران رخ می‌دهد که برای یک بیماری عروقی رقم بالایی است.",
   "عوامل خطر: قرص ضدبارداری، بارداری و نفاس، ترومبوفیلی، دهیدراتاسیون و عفونت.",
   "ادم پاپی دوطرفه نشانه‌ی مزمن شدن افزایش فشار داخل جمجمه است.",
   "روش تشخیصی انتخابی MR ونوگرافی یا CT ونوگرافی است.",
   "درمان ضدانعقاد با هپارین است، حتی اگر انفارکت وریدی خون‌ریزی‌دهنده وجود داشته باشد."
  ],
  "points_en": [
   "Cerebral venous sinus thrombosis blocks blood leaving the brain, not blood entering it.",
   "The result is raised venous pressure, cerebral oedema and increased intracranial pressure.",
   "Headache is the commonest symptom, present in over ninety percent of patients.",
   "Unlike subarachnoid haemorrhage this headache usually worsens over days rather than striking suddenly.",
   "Seizures occur in about forty percent, a high figure for a vascular disease.",
   "Risk factors: oral contraceptives, pregnancy and puerperium, thrombophilia, dehydration and infection.",
   "Bilateral papilloedema indicates that raised intracranial pressure has become established.",
   "The investigation of choice is MR venography or CT venography.",
   "Treatment is anticoagulation with heparin, even when there is a haemorrhagic venous infarct."
  ]
 },
 "explanation_fa": "پنج قطعه‌ی این پازل را کنار هم بگذارید. زن جوان است و قرص ضدبارداری مصرف می‌کند، یعنی حالت پروترومبوتیک دارد. سردرد یک هفته است و بتدریج بدتر شده، پس نه ناگهانی است و نه مزمن پایدار. یک حمله‌ی تشنج داشته است. ادم پاپی دوطرفه دارد، یعنی فشار داخل جمجمه بالا رفته و مدتی است بالاست. و علائم فوکال ندارد، یعنی هنوز انفارکت وریدی بزرگی شکل نگرفته است. تنها تشخیصی که همه‌ی این پنج قطعه را همزمان توضیح می‌دهد ترومبوز سینوس وریدی است. توجه کنید که ترکیب «سردرد پیش‌رونده + تشنج» کلید افتراق از افزایش فشار ایدیوپاتیک است، چون آن بیماری تشنج نمی‌سازد.",
 "explanation_en": "Put the five pieces of this puzzle together. She is a young woman on an oral contraceptive, so she is in a prothrombotic state. The headache has lasted a week and worsened gradually, so it is neither sudden nor chronically stable. She has had one seizure. She has bilateral papilloedema, so intracranial pressure is raised and has been raised for a while. And she has no focal signs, so no large venous infarct has formed yet. The only diagnosis that explains all five pieces at once is venous sinus thrombosis. Note that the combination of progressive headache plus seizure is the key discriminator from idiopathic intracranial hypertension, which does not cause seizures.",
 "why_fa": [
  "پاسخ صحیح — ترکیب حالت پروترومبوتیک، سردرد پیش‌رونده، تشنج و ادم پاپی تصویر کلاسیک ترومبوز سینوس وریدی است. با MR ونوگرافی تأیید و با هپارین درمان می‌شود.",
  "خون‌ریزی زیرعنکبوتیه با سردرد رعدآسا شروع می‌شود که در عرض ثانیه به اوج می‌رسد. سیر یک‌هفته‌ای و تدریجی با آن سازگار نیست.",
  "افزایش فشار داخل جمجمه ایدیوپاتیک هم سردرد و ادم پاپی می‌دهد اما تشنج جزو تظاهرات آن نیست. ضمناً پیش از پذیرفتن آن باید ترومبوز وریدی رد شود.",
  "مننژیت باکتریال معمولاً تب، سفتی گردن و شروع سریع‌تر دارد. صورت سؤال هیچ نشانه‌ی عفونی ذکر نکرده است."
 ],
 "why_en": [
  "Correct — a prothrombotic state with progressive headache, seizure and papilloedema is the classic picture of venous sinus thrombosis, confirmed by MR venography and treated with heparin.",
  "Subarachnoid haemorrhage starts as a thunderclap headache peaking within seconds. A gradual one-week course does not fit.",
  "Idiopathic intracranial hypertension also gives headache and papilloedema, but seizures are not part of it. It is also a diagnosis of exclusion after ruling out venous thrombosis.",
  "Bacterial meningitis usually brings fever, neck stiffness and a faster onset. The stem mentions no infectious features."
 ],
 "golden_fa": "OCP + سردرد پیش‌رونده + تشنج + ادم پاپی = CVT. تشخیص با MRV، درمان با هپارین.",
 "golden_en": "Oral contraceptive plus progressive headache plus seizure plus papilloedema equals CVT: diagnose with MRV, treat with heparin.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 13: Cerebral venous thrombosis",
  "Saposnik G et al. Diagnosis and management of cerebral venous thrombosis: AHA/ASA statement. Stroke 2011;42:1158-92"
 ]
}

json.dump(L, io.open('/home/user/work/lessons/L9.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('L9:', len(L))
