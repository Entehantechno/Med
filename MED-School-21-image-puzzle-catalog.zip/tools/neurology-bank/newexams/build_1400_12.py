# -*- coding: utf-8 -*-
"""Neurology block of the Esfand-1400 paper (q114..q121).

This sitting is special: the user supplied BOTH the official Persian booklet and
the official English booklet, so `stem_en` / `options_en` are taken VERBATIM from
the ministry's own translation rather than being translated here.

No full key was published (only the corrections notice, which lists no neurology
item), so answers are derived from the reference and tagged
key_source='derived_aminoff' with a written rationale.
"""
import json, io

LET = ['الف', 'ب', 'ج', 'د']

Q = [
 dict(n=114,
  fa="کدام‌یک از موارد زیر نشانه‌ی پیش‌آگهی بد در بیماری «ام‌اس» است؟",
  fo=["سن شروع قبل از ۴۰ سالگی", "شروع با علائم مخچه‌ای", "حملات عود و بهبودی", "جنس مؤنث"],
  en="Which of the following may indicate a poor prognosis in MS?",
  eo=["Age of onset before 40 years", "Onset with cerebellar symptoms",
      "Recurrent attacks and recoveries", "Female gender"],
  ans=1,
  why="شروع با علائم مخچه‌ای یا حرکتی پیش‌آگهی بدتری دارد، چون بازگشت عملکرد در این مسیرها ضعیف‌تر "
      "است. سه گزینه‌ی دیگر همگی از عوامل پیش‌آگهی خوب‌اند: شروع زیر ۴۰ سال، سیر عودکننده-بهبودیابنده "
      "و جنس مؤنث."),
 dict(n=115,
  fa="کدام‌یک از موارد زیر در بیماری پارکینسون، آتیپیک محسوب می‌شود؟",
  fo=["برادی‌کینزی", "ریژیدیتی", "ترمور", "دمانس"],
  en="Which of the following is considered atypical in Parkinson's disease?",
  eo=["Bradykinesia", "Rigidity", "Tremor", "Dementia"],
  ans=3,
  why="برادی‌کینزی، ریژیدیتی و ترمور استراحت سه‌گانه‌ی حرکتی خودِ پارکینسون‌اند. زوال عقل در سال‌های "
      "نخست بیماری یک «پرچم قرمز» است و به سمت پارکینسونیسم آتیپیک، به‌ویژه دمانس با اجسام لویی، "
      "اشاره می‌کند."),
 dict(n=116,
  fa="بیماری به‌علت زخم‌های تروفیک و سیانوز در نواحی پشت دست‌ها، ساعد، پا، گوش و بینی مراجعه کرده است. بیمار همچنین اختلال حسی درد و حرارت دارد اما رفلکس‌های وتری نرمال است. کدام‌یک از پلی‌نوروپاتی‌های زیر بیشتر مطرح است؟",
  fo=["لپر لپروماتوزیس", "آمیلوئیدوزیس", "واسکولیت", "آمیوتروفی دیابتی"],
  en="A patient presented with trophic ulcers and cyanosis in the back of the hands, forearms, ears, and nose. The patient has difficulty in pain and heat sensation, but tendons reflexes are normal. Which of the following polyneuropathies is most probable?",
  eo=["Lepromatous leprosy", "Amyloidosis", "Vasculitis", "Diabetic amyotrophy"],
  ans=0,
  why="توزیع ضایعات کلید تشخیص است: پشت دست، گوش و بینی سردترین نواحی بدن‌اند و مایکوباکتریوم لپره "
      "دمای پایین را ترجیح می‌دهد. از دست رفتن حس درد و حرارت با حفظ رفلکس‌های وتری یعنی درگیری "
      "انتخابی رشته‌های نازک، و همین بی‌حسی باعث زخم تروفیک تکرارشونده می‌شود."),
 dict(n=117,
  fa="بیمار خانم ۴۰ ساله‌ای است که از ۴ روز قبل دچار تب، اختلال حافظه و رفتارهای عجیب و غریب شده است. بیمار در اورژانس یک نوبت حمله GTC داشته است. در CT scan مغزی، شواهد ادم و هایپودنسیته در لوب‌های تمپورال رویت شد. با توجه به محتمل‌ترین تشخیص کدام تست حساسیت بالاتری دارد؟",
  fo=["آنالیز ساده مایع مغزی-نخاعی", "کشت ویروس از مایع مغزی-نخاعی",
      "آنتی‌بادی ویروس در مایع مغزی-نخاعی", "PCR ویروس در مایع مغزی-نخاعی"],
  en="A 40-year-old woman with a history of amnesia has experienced bizarre behaviour and fever since 4 days ago. The patient had several GTCs. In the brain CT scan, evidence of hypodensity and edema in temporal lobes was detected. According to the most probable diagnosis, which of the following has the most sensitivity for the diagnosis?",
  eo=["Cell count and protein of CSF", "Virus culture in CSF",
      "Antibody of virus in CSF", "Virus PCR in CSF"],
  ans=3,
  why="تب + اختلال حافظه و رفتار + تشنج + درگیری لوب تمپورال یعنی آنسفالیت هرپسی. PCR ویروس در مایع "
      "نخاع حساسیت حدود ۹۶ درصد دارد و آزمون انتخابی است. کشت ویروس از CSF تقریباً همیشه منفی است و "
      "آنتی‌بادی دیر مثبت می‌شود، پس به درد تشخیص حاد نمی‌خورد."),
 dict(n=118,
  fa="بیمار آقای ۶۰ ساله با سابقه دیابت است که به‌علت ضعف ناگهانی اندام‌های سمت راست با شروع از دو ساعت قبل مراجعه کرده است. در معاینه فورس اندام فوقانی راست ۴/۵ و اندام تحتانی راست ۲/۵ است. بیمار از اختلال اسفنکتری شکایت دارد. درگیری کدام‌یک از شاخه‌های شریانی محتمل‌تر است؟",
  fo=["شاخه فوقانی MCA", "شاخه تحتانی MCA", "ACA", "PCA"],
  en="A 60-year-old man with a history of DM is admitted to the emergency room with the complaint of acute right side weakness. On the examination, right upper extremity and right lower extremity forces were 4/5 and 2/5, respectively. The patient had also urinary incontinency. Which artery of circle of Willis is most probably involved?",
  eo=["Superior division of MCA", "Inferior division of MCA", "ACA", "PCA"],
  ans=2,
  why="ضعف پا بیشتر از دست، به‌علاوه‌ی بی‌اختیاری ادرار، امضای شریان مغزی قدامی است. روی هومونکولوس، "
      "پا و مرکز کنترل مثانه در سطح داخلی نیمکره قرار دارند که قلمرو ACA است. در سکته‌ی MCA برعکس "
      "است: دست و صورت بیشتر از پا درگیر می‌شوند."),
 dict(n=119,
  fa="بیمار پسر ۱۲ ساله‌ای است که صبح روز مراجعه دچار ضعف چهار اندام پس از برخاستن از خواب شده است. بیمار عصر روز قبل از مراجعه فوتبال بازی کرده است. در آزمایش‌های انجام شده، بجز پتاسیم پایین در خون، یافته غیرطبیعی دیگری ندارد. علائم بیمار پس از ۲۴ ساعت بهبود می‌یابد. همه‌ی درمان‌های زیر را برای بیمار در نظر می‌گیریم، بجز:",
  fo=["قرص کلرور پتاسیم", "استازولامید", "پرهیز از سرما", "توصیه به رژیم پرکربوهیدرات و کم‌نمک"],
  en="A 12-year-old boy was admitted to the emergency department complaining of four extremities paresis after waking up in the morning. One day before, he had played football. The only abnormal test was low level of potassium in serum. Symptoms improved after 24 hours. All of the followings are recommended EXCEPT:",
  eo=["Potassium tablet", "Acetazolamide", "Avoidance of the cold",
      "Diet of high carbohydrate and low salt"],
  ans=3,
  why="سؤال منفی است. تصویر، فلج دوره‌ای هیپوکالمیک است: ضعف پس از بیداری، به‌دنبال ورزش سنگین روز "
      "قبل، با پتاسیم پایین و بهبود خودبه‌خود. دقیقاً همین وعده‌ی پرکربوهیدرات است که با ترشح انسولین "
      "پتاسیم را به داخل سلول می‌راند و حمله را شروع می‌کند، پس توصیه به رژیم پرکربوهیدرات غلط است. "
      "پرهیز از سرما هم توصیه‌ی درستی است چون سرما محرک شناخته‌شده‌ی حمله است."),
 dict(n=120,
  fa="بیمار آقای ۳۸ ساله‌ای است که با اختلال حرکتی به‌صورت Chorea، تغییرات شخصیتی و عاطفی با شروع از ۳ سال قبل مراجعه کرده است. در Brain MRI بیمار شواهد آتروفی کورتکس و هسته‌ی Caudate مشاهده می‌شود. محتمل‌ترین تشخیص کدام است؟",
  fo=["بیماری هانتینگتون", "بیماری پارکینسون", "کره سیدنهام", "بیماری ویلسون"],
  en="A 38-year-old man has presented with chorea, personality and emotional changes since 3 years ago. On the brain MRI, evidence of atrophy of caudate and cortex was detected. The most probable diagnosis is:",
  eo=["Huntington's disease", "Parkinson disease", "Sydenham's chorea", "Wilson's disease"],
  ans=0,
  why="کره + تغییر شخصیت + آتروفی هسته‌ی دمدار در میان‌سالی، سه‌گانه‌ی بیماری هانتینگتون است. "
      "آتروفی کودیت باعث گشاد شدن شاخ قدامی بطن جانبی و نمای «باکس‌کار» می‌شود. کره‌ی سیدنهام "
      "بیماری کودکان پس از عفونت استرپتوکوکی و خودمحدودشونده است."),
 dict(n=121,
  fa="خانم ۲۵ ساله‌ای از ۲ هفته قبل دچار درد کولیکی شکم، یبوست، تب، استفراغ، لکوسیتوز، بی‌قراری و سایکوز شده است. به‌دنبال آن دچار ناتوانی پیشرونده در اندام‌ها به‌ویژه پروگزیمال اندام فوقانی شده است. بهترین تشخیص کدام است؟",
  fo=["پلی‌میوزیت", "پورفیری", "سندرم گیلن-باره", "بوتولیسم"],
  en="A 25-year-old woman has suffered from abdominal colic pain, constipation, fever, vomiting, leukocytosis, restlessness, and psychosis since 2 weeks ago. Following that, she experienced progressive disability in extremities particularly in upper proximal extremities. What is the best possible diagnosis?",
  eo=["Polymyositis", "Porphyria", "Guillian-Barré Syndrome", "Botulism"],
  ans=1,
  why="سه‌گانه‌ی درد شکم + علائم روان‌پزشکی + نوروپاتی، پورفیری حاد متناوب را می‌سازد. نکته‌ی افتراقی "
      "مهم این است که نوروپاتی پورفیری برخلاف گیلن-باره عمدتاً حرکتی و پروگزیمال است و اغلب از اندام "
      "فوقانی شروع می‌شود. درد شکم و سایکوز هم در گیلن-باره جایی ندارند."),
]

out = []
for q in Q:
    out.append({
        'exam': 'اسفند ۱۴۰۰', 'exam_tag': '1400-12', 'question_no': q['n'],
        'stem_fa': q['fa'], 'options_fa': q['fo'],
        'stem_en': q['en'], 'options_en': q['eo'],
        'en_source': 'official_english_booklet',
        'correct_index': q['ans'], 'correct_letter': LET[q['ans']],
        'key_source': 'derived_aminoff', 'key_rationale': q['why'],
        'source_file': 'پیش کارورزی - فارسی.pdf + پیش کارورزی - انگلیسی.pdf',
    })
    print(f"q{q['n']}: {LET[q['ans']]}) {q['fo'][q['ans']]}  |  {q['eo'][q['ans']]}")

json.dump(out, io.open('/home/user/work/out/neuro_1400_12.json', 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('\nsaved', len(out), 'questions WITH OFFICIAL ENGLISH')
