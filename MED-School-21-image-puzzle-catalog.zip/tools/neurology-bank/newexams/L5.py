# -*- coding: utf-8 -*-
"""Micro-lessons, batch 5 — Khordad-1402 (six items carry the ministry's English)."""
import json, io
L = {}

L["1402-03:114"] = {
 "micro": {
  "lead_fa": "سردرد خوشه‌ای تنها سردرد اولیه‌ای است که در مردان شایع‌تر است؛ بقیه در زنان غالب‌اند.",
  "lead_en": "Cluster headache is the only primary headache commoner in men; the others predominate in women.",
  "points_fa": [
   "سردرد خوشه‌ای در مردان حدود سه برابر زنان دیده می‌شود.",
   "درد یک‌طرفه، شدید و اطراف چشم است و ۱۵ دقیقه تا ۳ ساعت طول می‌کشد.",
   "حملات در دوره‌های خوشه‌ای چند هفته‌ای تکرار می‌شوند و اغلب شبانه‌اند.",
   "علائم اتونوم همان سمت همراهی می‌کنند: اشک‌ریزش، احتقان بینی و پتوز.",
   "برخلاف میگرن، بیمار بی‌قرار است و راه می‌رود؛ بیمار میگرنی بی‌حرکت دراز می‌کشد.",
   "میگرن در زنان حدود سه برابر مردان است، به دلیل نقش نوسان استروژن.",
   "سردرد تنشی شایع‌ترین سردرد اولیه است و آن هم در زنان بیشتر دیده می‌شود.",
   "افزایش فشار ایدیوپاتیک داخل جمجمه تقریباً منحصر به زنان جوان با اضافه‌وزن است.",
   "نسبت زن به مرد در این بیماری حدود هشت به یک است."
  ],
  "points_en": [
   "Cluster headache is about three times commoner in men than women.",
   "The pain is unilateral, severe and periorbital, lasting 15 minutes to 3 hours.",
   "Attacks recur in cluster periods of several weeks and are often nocturnal.",
   "Ipsilateral autonomic features accompany it: lacrimation, nasal congestion and ptosis.",
   "Unlike migraine, the patient is restless and paces; the migraineur lies still.",
   "Migraine is about three times commoner in women, reflecting oestrogen fluctuation.",
   "Tension-type headache is the commonest primary headache and also predominates in women.",
   "Idiopathic intracranial hypertension is almost confined to young overweight women.",
   "Its female-to-male ratio is roughly eight to one."
  ]
 },
 "explanation_fa": "این سؤال یک نکته‌ی اپیدمیولوژیک را می‌آزماید که به‌راحتی فراموش می‌شود. اکثر سردردهای اولیه در زنان شایع‌ترند و همین قاعده‌ی کلی باعث می‌شود دانشجو گزینه‌ی درست را رد کند. اما سردرد خوشه‌ای استثناست: در مردان حدود سه برابر زنان دیده می‌شود. برای تثبیت مطلب، تصویر بالینی آن را کنار این نکته بگذارید. مرد میان‌سالی که شب‌ها با درد شدید اطراف یک چشم از خواب می‌پرد، همان سمت اشک می‌ریزد و بینی‌اش گرفته می‌شود، و برخلاف بیمار میگرنی نمی‌تواند آرام بگیرد و در اتاق راه می‌رود. سه گزینه‌ی دیگر همگی در زنان غالب‌اند: میگرن حدود سه برابر، سردرد تنشی کمی بیشتر، و افزایش فشار ایدیوپاتیک داخل جمجمه با نسبت چشمگیر هشت به یک که تقریباً منحصر به زنان جوان با اضافه‌وزن است.",
 "explanation_en": "This item tests an epidemiological point that is easy to forget. Most primary headaches are commoner in women, and that general rule tempts students to reject the right option. Cluster headache is the exception: about three times commoner in men. To fix it in memory, pair the fact with the clinical picture. A middle-aged man woken at night by severe pain around one eye, with lacrimation and nasal blockage on the same side, who unlike a migraineur cannot keep still and paces the room. The other three all predominate in women: migraine roughly threefold, tension-type slightly, and idiopathic intracranial hypertension with a striking eight-to-one ratio, almost confined to young overweight women.",
 "why_fa": [
  "پاسخ صحیح — سردرد خوشه‌ای تنها سردرد اولیه‌ای است که در مردان شایع‌تر است، با نسبت حدود سه به یک.",
  "میگرن در زنان حدود سه برابر مردان شایع‌تر است و نوسان استروژن نقش مهمی در آن دارد؛ به همین دلیل با قاعدگی و بارداری تغییر می‌کند.",
  "افزایش فشار ایدیوپاتیک داخل جمجمه تقریباً منحصر به زنان جوان با اضافه‌وزن است و نسبت زن به مرد در آن حدود هشت به یک است.",
  "سردرد تنشی شایع‌ترین سردرد اولیه است و آن هم اندکی در زنان بیشتر دیده می‌شود."
 ],
 "why_en": [
  "Correct — cluster headache is the only primary headache commoner in men, at roughly three to one.",
  "Migraine is about three times commoner in women, with oestrogen fluctuation playing a major role; hence its variation with menstruation and pregnancy.",
  "Idiopathic intracranial hypertension is almost confined to young overweight women, with a female-to-male ratio of about eight to one.",
  "Tension-type headache is the commonest primary headache and is also slightly commoner in women."
 ],
 "golden_fa": "قاعده: سردردهای اولیه زنانه‌اند، جز خوشه‌ای که مردانه است. بی‌قراری هم آن را از میگرن جدا می‌کند.",
 "golden_en": "Rule: primary headaches favour women, except cluster which favours men. Restlessness also separates it from migraine.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 6: Cluster headache",
  "ICHD-3: The International Classification of Headache Disorders, 3rd edition. Cephalalgia 2018;38:1-211"
 ]
}

L["1402-03:115"] = {
 "micro": {
  "lead_fa": "سندرم آنتی‌کولینرژیک تعریق را مهار می‌کند، پس راه اصلی دفع گرما بسته می‌شود و دما بالا می‌رود.",
  "lead_en": "The anticholinergic syndrome blocks sweating, so the main route of heat loss closes and temperature rises.",
  "points_fa": [
   "استیل‌کولین واسطه‌ی عصبی غدد عرق است، حتی با اینکه این غدد سمپاتیک‌اند.",
   "پس مسدود شدن گیرنده‌ی موسکارینی، تعریق را متوقف می‌کند.",
   "بدن مهم‌ترین راه دفع گرمای خود را از دست می‌دهد و هایپرترمی می‌سازد.",
   "یادیار کلاسیک: داغ مثل خرگوش صحرایی، قرمز مثل چغندر، خشک مثل استخوان.",
   "و ادامه‌اش: کور مثل خفاش (میدریاز) و دیوانه مثل کلاه‌دوز (دلیریوم).",
   "پوست در این سندرم خشک است؛ همین آن را از سندرم سمپاتومیمتیک جدا می‌کند.",
   "در مسمومیت با آمفتامین و کوکائین هم دما بالا می‌رود، اما پوست خیس از عرق است.",
   "سه گزینه‌ی دیگر همگی سرکوب‌کننده‌ی سیستم عصبی مرکزی‌اند و هیپوترمی می‌سازند.",
   "اپیوئید مردمک نوک‌سوزنی می‌دهد، در نقطه‌ی مقابل میدریاز آنتی‌کولینرژیک."
  ],
  "points_en": [
   "Acetylcholine is the transmitter to sweat glands, even though they are sympathetic.",
   "So blocking muscarinic receptors stops sweating.",
   "The body loses its main route of heat loss and becomes hyperthermic.",
   "The classic mnemonic: hot as a hare, red as a beet, dry as a bone.",
   "And it continues: blind as a bat (mydriasis) and mad as a hatter (delirium).",
   "The skin is dry in this syndrome, which separates it from the sympathomimetic toxidrome.",
   "Amphetamine and cocaine also raise temperature, but the skin is drenched in sweat.",
   "The other three options are all CNS depressants and cause hypothermia.",
   "Opioids give pinpoint pupils, the opposite of anticholinergic mydriasis."
  ]
 },
 "explanation_fa": "برای پاسخ باید بدانید کدام مسمومیت دما را بالا می‌برد و کدام پایین می‌آورد. سه گزینه‌ی اوپیوم، الکل و باربیتورات همگی سرکوب‌کننده‌ی سیستم عصبی مرکزی‌اند؛ متابولیسم را کم می‌کنند، عروق محیطی را گشاد می‌کنند و نتیجه هیپوترمی است، نه هایپرترمی. اما داروهای آنتی‌کولینرژیک داستان دیگری دارند. غدد عرق با وجود اینکه از سیستم سمپاتیک عصب می‌گیرند، واسطه‌ی عصبی‌شان استیل‌کولین است. پس وقتی گیرنده‌ی موسکارینی مسدود شود، تعریق متوقف می‌شود و بدن مهم‌ترین راه دفع گرمای خود را از دست می‌دهد. یادیار کلاسیک این سندرم کل تصویر را می‌سازد: داغ مثل خرگوش صحرایی، قرمز مثل چغندر، خشک مثل استخوان، کور مثل خفاش و دیوانه مثل کلاه‌دوز. نکته‌ی افتراقی مهم: در مسمومیت سمپاتومیمتیک هم دما بالا می‌رود، اما آنجا پوست خیس از عرق است در حالی که اینجا کاملاً خشک است.",
 "explanation_en": "To answer you must know which poisoning raises temperature and which lowers it. Opium, alcohol and barbiturates are all CNS depressants; they reduce metabolism, dilate peripheral vessels and produce hypothermia, not hyperthermia. Anticholinergic drugs are different. Although sweat glands are sympathetically innervated, their transmitter is acetylcholine. So when muscarinic receptors are blocked, sweating stops and the body loses its main route of heat loss. The classic mnemonic captures the whole picture: hot as a hare, red as a beet, dry as a bone, blind as a bat and mad as a hatter. One discriminator matters: sympathomimetic poisoning also raises temperature, but there the skin is drenched in sweat whereas here it is bone dry.",
 "why_fa": [
  "مسمومیت با اوپیوم سه‌گانه‌ی کاهش هوشیاری، تضعیف تنفس و مردمک نوک‌سوزنی می‌دهد و دمای بدن را پایین می‌آورد، نه بالا.",
  "پاسخ صحیح — مسدود شدن گیرنده‌ی موسکارینی تعریق را متوقف می‌کند و بدن راه اصلی دفع گرما را از دست می‌دهد، پس هایپرترمی رخ می‌دهد.",
  "مسمومیت با الکل به دلیل گشاد شدن عروق محیطی و کاهش متابولیسم، هیپوترمی می‌سازد. این یکی از علل شایع هیپوترمی در اورژانس است.",
  "باربیتورات‌ها سرکوب‌کننده‌ی قوی سیستم عصبی مرکزی‌اند و متابولیسم پایه را کم می‌کنند، پس دمای بدن افت می‌کند."
 ],
 "why_en": [
  "Opium poisoning gives the triad of depressed consciousness, respiratory depression and pinpoint pupils, and lowers body temperature rather than raising it.",
  "Correct — blocking muscarinic receptors stops sweating and the body loses its main route of heat loss, so hyperthermia develops.",
  "Alcohol poisoning causes hypothermia through peripheral vasodilatation and reduced metabolism. It is a common cause of hypothermia in the emergency department.",
  "Barbiturates are potent CNS depressants that lower basal metabolism, so body temperature falls."
 ],
 "golden_fa": "آنتی‌کولینرژیک = داغ و خشک. سمپاتومیمتیک = داغ و خیس. سرکوب‌کننده‌ها = سرد.",
 "golden_en": "Anticholinergic = hot and dry. Sympathomimetic = hot and wet. Depressants = cold.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 3: Coma, toxic causes",
  "Goldfrank's Toxicologic Emergencies, 11th ed — Anticholinergic toxidrome"
 ]
}

L["1402-03:116"] = {
 "micro": {
  "lead_fa": "خون‌ریزی مغزی توده‌ی اضافه می‌سازد و فشار داخل جمجمه را بالا می‌برد، پس سردرد و استفراغ می‌دهد.",
  "lead_en": "An intracerebral haemorrhage adds mass and raises intracranial pressure, so it causes headache and vomiting.",
  "points_fa": [
   "سکته‌ی ایسکمیک از انسداد رگ می‌آید و بافت را بدون افزودن حجم دچار مرگ می‌کند.",
   "خون‌ریزی برعکس، حجم اضافه‌ای وارد جمجمه‌ی بسته می‌کند.",
   "جمجمه فضای ثابتی دارد، پس هر حجم اضافه فشار داخل جمجمه را بالا می‌برد.",
   "افزایش فشار، سردرد ناگهانی و استفراغ می‌سازد؛ استفراغ اغلب بدون تهوع مقدماتی است.",
   "همین دو علامت، بهترین سرنخ بالینی به نفع خون‌ریزی در ساعات اول‌اند.",
   "کاهش سطح هوشیاری هم در خون‌ریزی شایع‌تر است اما در سکته‌ی بزرگ ایسکمیک هم رخ می‌دهد.",
   "آفازی به محل ضایعه بستگی دارد نه به نوع آن، پس ارزش افتراقی ندارد.",
   "تشنج در هر دو ممکن است و در خون‌ریزی لوبار کمی شایع‌تر است.",
   "نکته‌ی حیاتی: هیچ علامت بالینی قطعی نیست و افتراق فقط با سی‌تی‌اسکن ممکن است."
  ],
  "points_en": [
   "Ischaemic stroke follows vessel occlusion and kills tissue without adding volume.",
   "Haemorrhage instead introduces extra volume into a closed skull.",
   "The skull is a fixed space, so any added volume raises intracranial pressure.",
   "Raised pressure produces sudden headache and vomiting, often without preceding nausea.",
   "These two symptoms are the best clinical clue favouring haemorrhage in the early hours.",
   "Depressed consciousness is also commoner in haemorrhage but occurs in large infarcts too.",
   "Aphasia depends on lesion location rather than type, so it has no discriminating value.",
   "Seizures can occur in both and are slightly commoner in lobar haemorrhage.",
   "The crucial point: no clinical sign is definitive; only CT can distinguish them."
  ]
 },
 "explanation_fa": "این سؤال از شما می‌خواهد بین دو نوع سکته افتراق بالینی بگذارید و پاسخ به یک اصل فیزیکی ساده برمی‌گردد. جمجمه یک جعبه‌ی بسته با حجم ثابت است. در سکته‌ی ایسکمیک، رگی بسته می‌شود و بافت می‌میرد، اما در ساعات اول حجم اضافه‌ای وارد جمجمه نمی‌شود. در خون‌ریزی برعکس، یک توده‌ی خونی جدید به فضای بسته اضافه می‌شود و بلافاصله فشار داخل جمجمه بالا می‌رود. نتیجه‌ی مستقیم این افزایش فشار، سردرد ناگهانی و استفراغ است. پس همین دو علامت بهترین سرنخ بالینی به نفع خون‌ریزی در ساعات نخست‌اند. سه گزینه‌ی دیگر ارزش افتراقی کمتری دارند: آفازی فقط به محل ضایعه بستگی دارد، و افت هوشیاری و تشنج در هر دو نوع ممکن است. اما نکته‌ی حیاتی بالینی را فراموش نکنید: هیچ علامتی قطعی نیست و افتراق قطعی فقط با سی‌تی‌اسکن بدون تزریق ممکن است، که پیش از هر تصمیم درمانی الزامی است.",
 "explanation_en": "This item asks you to distinguish two stroke types clinically, and the answer rests on a simple physical principle. The skull is a closed box of fixed volume. In ischaemic stroke a vessel occludes and tissue dies, but no extra volume enters the skull in the early hours. In haemorrhage, by contrast, a new blood mass is added to that closed space and intracranial pressure rises immediately. The direct consequence is sudden headache and vomiting, making these two the best clinical clue for haemorrhage early on. The other options discriminate less well: aphasia depends only on lesion location, while depressed consciousness and seizures occur in both. But never forget the crucial clinical point: no sign is definitive, and only a non-contrast CT can distinguish them — which is mandatory before any treatment decision.",
 "why_fa": [
  "افت هوشیاری در خون‌ریزی شایع‌تر است، اما در سکته‌ی ایسکمیک وسیع یا انسداد شریان بازیلار هم رخ می‌دهد. ارزش افتراقی آن کمتر از سردرد و استفراغ است.",
  "پاسخ صحیح — سردرد و استفراغ از افزایش حاد فشار داخل جمجمه ناشی می‌شوند که ویژگی خون‌ریزی است، چون توده‌ی اضافه وارد فضای بسته‌ی جمجمه می‌شود.",
  "آفازی به محل ضایعه بستگی دارد نه به نوع آن. هر ضایعه‌ای در نیمکره‌ی غالب، چه ایسکمیک و چه هموراژیک، می‌تواند آفازی بسازد.",
  "تشنج در هر دو نوع سکته ممکن است رخ دهد. در خون‌ریزی لوبار کمی شایع‌تر است اما به‌عنوان معیار افتراقی قابل اتکا نیست."
 ],
 "why_en": [
  "Depressed consciousness is commoner in haemorrhage but also occurs in large infarcts or basilar occlusion. It discriminates less well than headache and vomiting.",
  "Correct — headache and vomiting arise from the acute rise in intracranial pressure that characterises haemorrhage, as extra mass enters the closed skull.",
  "Aphasia depends on lesion location, not type. Any dominant-hemisphere lesion, ischaemic or haemorrhagic, can cause it.",
  "Seizures can occur with either stroke type. They are slightly commoner in lobar haemorrhage but are not a reliable discriminator."
 ],
 "golden_fa": "خون‌ریزی حجم اضافه می‌آورد، پس سردرد و استفراغ می‌دهد. اما تصمیم نهایی فقط با سی‌تی است.",
 "golden_en": "Haemorrhage adds volume, so it causes headache and vomiting. But only CT settles the question.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 13: Intracerebral haemorrhage",
  "Greenberg SM et al. 2022 AHA/ASA Guideline for the Management of Spontaneous Intracerebral Hemorrhage. Stroke 2022;53:e282-e361"
 ]
}
json.dump(L, io.open('/home/user/work/lessons/L5.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('batch 5:', len(L), 'lessons')
