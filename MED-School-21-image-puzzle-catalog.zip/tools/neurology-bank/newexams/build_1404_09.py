# -*- coding: utf-8 -*-
"""Neurology block of the Azar-1404 mid-term paper — the LAST sitting held.

Source: konkur.in mirror of the Qazvin University electronic mid-term paper,
three files — Persian booklet, official ENGLISH booklet and the official key.
The neurology block is items 97-102, printed under the "مغز و اعصاب" header.

Unlike most sittings this one has a real published answer key (not just a
corrections notice), so every key here is `official`. The English stems and
options are lifted verbatim from the ministry's own English booklet rather
than translated, per the project rule.

Note on Esfand-1404: that sitting was CANCELLED by the ministry (a GPA
threshold replaced it), so Azar-1404 is the most recent paper in existence.
"""
import json, io, os
LET = ['الف', 'ب', 'ج', 'د']
OUT = '/home/user/work/out'
os.makedirs(OUT, exist_ok=True)

# (no, stem_fa, options_fa, stem_en, options_en, official_key_index, rationale)
Q = [
 (97,
  "خانم ۳۰ ساله‌ای با شکایت از افتادگی پلک چشم چپ که از ۲ ماه قبل شروع شده است مراجعه کرده است و مشکل بیمار عصرها تشدید می‌شود. در آزمایش‌ها آنتی‌بادی ضد گیرنده استیل‌کولین مثبت است. کدام مورد در مورد بیماری ایشان صحیح است؟",
  ["درگیری اتونوم وجود ندارد",
   "درگیری عضلات صاف وجود دارد",
   "در صورت پیشرفت بیماری، آتروفی عضلانی بارز است",
   "رفلکس وتری کاهش می‌یابد"],
  "A 30-year-old woman presented with a complaint of left-side ptosis from 2 month ago. Her problem is accelerated in evenings. In laboratory tests, anti-acetylcholine receptor anti-body was positive. Which one is correct?",
  ["Autonomic system involvement is not present.",
   "Smooth muscle involvement is present.",
   "Muscle atrophy is present in delayed stage of the disease.",
   "Deep tendon reflex is decreased."],
  0,
  "پتوز نوسان‌دار با تشدید عصرگاهی و آنتی‌بادی مثبت ضد گیرنده استیل‌کولین، تشخیص میاستنی گراویس "
  "را قطعی می‌کند. آنتی‌بادی به گیرنده‌ی نیکوتینی صفحه‌ی محرکه‌ی عضله‌ی مخطط حمله می‌کند و آن "
  "گیرنده در سیستم اتونوم و عضله‌ی صاف وجود ندارد، پس درگیری اتونوم و عضله‌ی صاف رخ نمی‌دهد. "
  "آتروفی عضلانی هم مشخصه‌ی میاستنی نیست چون مشکل انتقال عصبی-عضلانی است نه دنرواسیون. "
  "رفلکس‌های وتری در میاستنی طبیعی می‌مانند؛ کاهش رفلکس با سندرم لمبرت-ایتون فرق می‌کند."),

 (98,
  "یک خانم ۵۱ ساله با شکایت ضعف پیش‌رونده، قرینه و بالارونده‌ی چهار اندام، دو روز بعد از تزریق واکسن آنفولانزا به اورژانس مراجعه کرده است. در معاینه کوادری‌پارزی دارد، معاینه‌ی حسی نرمال است، رفلکس‌های وتری وجود ندارد و پاسخ پلانتار دوطرفه رو به پایین است. محتمل‌ترین تشخیص کدام است؟",
  ["سندرم گیلن باره", "مولتیپل اسکلروزیس", "حمله‌ی عروقی مغز", "میلیت عرضی"],
  "A 51-year-old woman presented to the emergency room with symmetric ascending progressive quadriparesia 2 days after influenza vaccine injection. Sensory examination is normal, deep tendon reflex is absent and bilateral plantar reflex is down. What is the most probable diagnosis?",
  ["Guillain barre syndrome", "Multiple sclerosis",
   "Cerebrovascular attack", "Transvers myelitis"],
  0,
  "چهار یافته این تشخیص را می‌سازند و هر چهار به یک سمت می‌روند: ضعف صعودی و قرینه، آرفلکسی "
  "منتشر، پاسخ پلانتار خم‌کننده (یعنی نورون حرکتی فوقانی سالم است) و محرک ایمنی اخیر یعنی "
  "واکسن. این ترکیب سندرم گیلن باره است. ام‌اس و سکته و میلیت عرضی هر سه ضایعه‌ی مرکزی‌اند و "
  "رفلکس‌ها را زیاد و بابنسکی را مثبت می‌کنند، دقیقاً برعکس این بیمار."),

 (99,
  "پاتوفیزیولوژی کدام‌یک از انواع سردردها، پایین آمدن آستانه‌ی درد به علت افزایش حساسیت مرکزی است؟",
  ["سردرد میگرنی", "سردرد خوشه‌ای", "سردرد تنشی", "نورالژی تری‌ژمینال"],
  "Decreased threshold of pain because of increasing central sensitization is pathophysiology of which kind of headache?",
  ["Migraine headache", "Cluster headache", "Tension headache", "Trigeminal neuralgia"],
  2,
  "هر سردرد مکانیسم غالب متفاوتی دارد. سردرد تنشی از حساس‌سازی مرکزی می‌آید: نورون‌های شاخ "
  "خلفی و هسته‌ی تریژمینال بیش‌ازحد تحریک‌پذیر می‌شوند و آستانه‌ی درد پایین می‌آید، به‌طوری که "
  "لمس عضلات پریکرانیال هم دردناک می‌شود. میگرن مکانیسم متفاوتی دارد و با افسردگی گسترنده‌ی "
  "قشری و فعال شدن مسیر تریژمینو-واسکولار توضیح داده می‌شود. سردرد خوشه‌ای از فعال شدن "
  "هیپوتالاموس خلفی و مسیر تریژمینو-اتونوم می‌آید. نورالژی تریژمینال هم فشار عروقی بر ریشه‌ی "
  "عصب و تخلیه‌ی نابجای آن است، یعنی مکانیسم محیطی نه مرکزی."),

 (100,
  "آقای ۴۰ ساله‌ای با سابقه‌ی دیابت با اختلال تکلم حاد مراجعه کرده است. در بررسی، درک کلام بیمار کاملاً سالم است و روان صحبت می‌کند، اما وقتی خودکار را نشان می‌دهید نمی‌تواند نام ببرد و توانایی تکرار کلام شما را نیز ندارد. محتمل‌ترین نوع اختلال تکلم (آفازی) کدام است؟",
  ["ورنیکه", "گلوبال", "کاندکشن (هدایتی)", "بروکا"],
  "A 40-year-old man with a history of diabetes presented with acute speech disorder. On examination, compression and fluency of speech are normal. He has disorder in naming pen and repeating the doctor's speech. What is the most probable speech disorder (aphasia)?",
  ["Wernicke", "Global", "Conductive", "Brocha"],
  2,
  "آفازی‌ها را با سه سؤال دسته‌بندی کنید: روانی گفتار، درک، و تکرار. اینجا گفتار روان است و درک "
  "هم سالم، پس ورنیکه (درک مختل)، بروکا (گفتار غیرروان) و گلوبال (هر دو مختل) کنار می‌روند. "
  "تنها چیزی که خراب است تکرار و نام‌بردن است. این الگوی دقیق آفازی کاندکشن است که از قطع "
  "فاسیکولوس آرکوئات، یعنی دسته‌ی رابط ناحیه‌ی ورنیکه و بروکا، ناشی می‌شود."),

 (101,
  "کدام نوع تشنج به‌صورت حملات کوتاه اختلال هوشیاری (زیر ۲۰ ثانیه) بدون کانفیوژن پس از حمله و بدون سقوط بروز می‌کند؟",
  ["تونیک-کلونیک ژنرالیزه", "غیاب (ابسانس)", "آتونیک", "پارشیال ساده"],
  "Which kind of seizure has brief spell of loss of consciousness (less than 20 seconds) without postictal confusion and drop?",
  ["Generalized tonic-clonic", "Absence", "Atonic", "Simple partial"],
  1,
  "سه قید صورت سؤال هر سه گزینه‌ی دیگر را حذف می‌کنند. «زیر بیست ثانیه و بدون کانفیوژن بعدی» "
  "تونیک-کلونیک ژنرالیزه را رد می‌کند که دقیقه‌ها طول می‌کشد و مرحله‌ی گیجی طولانی دارد. «بدون "
  "سقوط» تشنج آتونیک را رد می‌کند که تعریفش از دست رفتن ناگهانی تون و افتادن است. «اختلال "
  "هوشیاری» پارشیال ساده را رد می‌کند که طبق تعریف هوشیاری در آن حفظ می‌شود. تنها گزینه‌ی "
  "باقی‌مانده حمله‌ی غیاب است."),

 (102,
  "خانم ۲۹ ساله‌ای با شکایت پاراپارزی و بی‌اختیاری ادرار از چهار روز قبل مراجعه کرده است. بیمار سابقه‌ی تاری دید ناگهانی چشم راست را ذکر می‌کند که بدون درمان طی دو هفته بهبود یافته است. در معاینه پاراپارزی به همراه رفلکس‌های تاندونی نرمال، علامت بابینسکی دوطرفه و مردمک مارکوس گان سمت راست دارد. اولین اقدام تشخیصی کدام است؟",
  ["سی‌تی‌اسکن مغز بدون کنتراست",
   "مطالعه‌ی هدایت عصبی و EMG سوزنی",
   "MRI مغز و نخاع",
   "سی‌تی میلوگرافی"],
  "A 29-year-old woman presented with a complaint of paraparesia and urinary incontinency from 4 days ago. She notes the history of sudden right-side blurred vision, which was self-limited. On examination, she has right-side Marcus Gunn and bilateral Babinski sign. Deep tendon reflex is normal. What is the first diagnosis step?",
  ["Non contrast CT of the head", "Nerve conduction study and needle EMG",
   "Brain and spinal cord MRI", "CT myelography"],
  2,
  "بیمار دو ضایعه در دو زمان و دو مکان جدا دارد: نوریت اپتیک راست در گذشته (که مردمک مارکوس "
  "گان یعنی نقص آوران نسبی، اثر باقی‌مانده‌ی آن است) و ضایعه‌ی نخاعی فعلی (پاراپارزی، بی‌اختیاری "
  "ادرار، بابینسکی دوطرفه). این همان پراکندگی در مکان و زمان معیار مک‌دونالد است، پس تشخیص "
  "ام‌اس مطرح است. تصویربرداری انتخابی MRI مغز و نخاع است. سی‌تی پلاک‌های دمیلینه را نشان "
  "نمی‌دهد، نوار عصب و عضله برای بیماری محیطی است و بابینسکی مثبت می‌گوید ضایعه مرکزی است."),
]

out = []
for n, fa, fo, en, eo, ans, why in Q:
    out.append({
        'exam': 'آذر ۱۴۰۴', 'exam_tag': '1404-09', 'question_no': n,
        'stem_fa': fa, 'options_fa': fo,
        'stem_en': en, 'options_en': eo,
        'en_source': 'official_english_booklet',
        'correct_index': ans, 'correct_letter': LET[ans],
        'key_source': 'official',
        'key_rationale': why,
        'source_file': 'PishKarvarzi-Azar1404-Farsi/English + official key',
        'notes': {
            'sitting': 'آزمون میان‌دوره‌ی الکترونیکی، طراحی دانشگاه علوم پزشکی قزوین.',
            'key': 'کلید رسمی منتشرشده‌ی مرکز سنجش؛ هر شش پاسخ با استدلال مستقل بر پایه‌ی '
                   'Aminoff 2021 نیز بازبینی و تأیید شد.',
            'english': 'متن انگلیسی عیناً از دفترچه‌ی انگلیسی رسمی وزارت بهداشت برداشته شده '
                       'است، نه ترجمه‌ی ما.',
            'last_sitting': 'آزمون اسفند ۱۴۰۴ توسط وزارت بهداشت لغو شد و شرط معدل جایگزین آن '
                            'گردید، بنابراین آذر ۱۴۰۴ آخرین آزمون برگزارشده است.'},
    })
    print(f"q{n}: {LET[ans]}) {fo[ans][:50]}")

json.dump(out, io.open(f'{OUT}/neuro_1404_09.json', 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print(f'\nsaved {len(out)} questions — Azar-1404, the last sitting held (official key + official English)')
