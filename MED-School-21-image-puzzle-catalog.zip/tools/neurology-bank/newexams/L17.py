# -*- coding: utf-8 -*-
"""Micro-lessons, batch 17 — Aban-1400 mid-term. Completes the bank."""
import json, io
L = {}

L["1400-08:114"] = {
 "stem_en": "On neurological examination you ask the patient to make a fist and then open it quickly after five seconds. The patient opens the fist with a delay. Which of the following does this confirm?",
 "options_en": ["Rigidity", "Myotonia", "Spasticity", "Hypotonia"],
 "micro": {
  "lead_fa": "تأخیر در شل شدن پس از انقباض ارادی، تعریف بالینی میوتونی است.",
  "lead_en": "Delayed relaxation after a voluntary contraction is the clinical definition of myotonia.",
  "points_fa": [
   "میوتونی یعنی شل شدن عضله پس از یک انقباض ارادی به تأخیر بیفتد.",
   "علت آن تحریک‌پذیری غیرطبیعی غشای خود فیبر عضلانی است، نه مشکل عصبی.",
   "اختلال در کانال کلر یا کانال سدیم غشای عضله باعث ادامه‌ی شلیک الکتریکی می‌شود.",
   "مشخصه‌ی مهم آن پدیده‌ی گرم‌شدن است: با تکرار حرکت میوتونی کمتر می‌شود.",
   "در معاینه با درخواست مشت کردن و باز کردن سریع دست آزموده می‌شود.",
   "میوتونی ضربه‌ای هم وجود دارد: ضربه به عضله‌ی تنار گودی پایدار می‌سازد.",
   "شایع‌ترین بیماری همراه آن دیستروفی میوتونیک نوع یک است.",
   "میوتونی مادرزادی یا بیماری تامسن هم علت دیگر آن است.",
   "رژیدیتی و اسپاستیسیته افزایش تون در حرکت غیرفعال‌اند، نه تأخیر ارادی."
  ],
  "points_en": [
   "Myotonia means delayed relaxation of a muscle after a voluntary contraction.",
   "It is caused by abnormal excitability of the muscle fibre membrane itself, not a nerve problem.",
   "A chloride or sodium channel defect in the muscle membrane lets electrical firing continue.",
   "An important feature is the warm-up phenomenon: myotonia lessens with repeated movement.",
   "It is tested by asking the patient to make a fist and open it quickly.",
   "Percussion myotonia also exists: tapping the thenar muscle produces a sustained dimple.",
   "The commonest associated disease is myotonic dystrophy type one.",
   "Myotonia congenita, or Thomsen disease, is another cause.",
   "Rigidity and spasticity are increases in tone on passive movement, not delayed voluntary relaxation."
  ]
 },
 "explanation_fa": "برای پاسخ باید بین چهار اصطلاح مربوط به تون عضلانی تمایز بگذارید، و نکته‌ی جداکننده این است که کدام‌یک به حرکت ارادی مربوط می‌شود و کدام به حرکت غیرفعال. رژیدیتی و اسپاستیسیته هر دو در معاینه‌ی غیرفعال کشف می‌شوند، یعنی وقتی شما اندام بیمار را حرکت می‌دهید و مقاومت حس می‌کنید؛ هیچ‌کدام به تأخیر در شل شدن ارادی مربوط نیستند. هیپوتونی هم کاهش تون است که دقیقاً برعکس این تصویر است. اما میوتونی مستقیماً به همین پدیده اشاره دارد: بیمار می‌خواهد مشت را باز کند و نمی‌تواند سریع باز کند. مکانیسم آن هم در خود عضله است نه در عصب؛ اختلال کانال یونی غشای فیبر عضلانی باعث می‌شود شلیک الکتریکی پس از قطع فرمان ارادی ادامه یابد. نکته‌ی جالب اینکه با تکرار حرکت بهتر می‌شود، پدیده‌ای که به آن گرم‌شدن می‌گویند.",
 "explanation_en": "To answer you must distinguish four terms about muscle tone, and the separating point is which relate to voluntary and which to passive movement. Rigidity and spasticity are both found on passive examination, when you move the patient's limb and feel resistance; neither concerns delayed voluntary relaxation. Hypotonia is reduced tone, the exact opposite of this picture. Myotonia refers directly to this phenomenon: the patient wants to open the fist and cannot do so quickly. Its mechanism lies in the muscle itself rather than the nerve; an ion channel defect in the fibre membrane lets electrical firing continue after the voluntary command stops. Interestingly it improves with repetition, a phenomenon called warm-up.",
 "why_fa": [
  "رژیدیتی افزایش تون در حرکت غیرفعال در تمام جهات است و در پارکینسونیسم دیده می‌شود، نه تأخیر در باز کردن ارادی مشت.",
  "پاسخ صحیح — تأخیر در شل شدن پس از انقباض ارادی، تعریف میوتونی است و از تحریک‌پذیری غشای فیبر عضلانی می‌آید.",
  "اسپاستیسیته افزایش تون وابسته به سرعت در حرکت غیرفعال است و نشانه‌ی ضایعه‌ی نورون حرکتی فوقانی است.",
  "هیپوتونی کاهش تون عضلانی است و دقیقاً برعکس تصویر این بیمار است که مشکلش در شل شدن است."
 ],
 "why_en": [
  "Rigidity is increased tone on passive movement in all directions, seen in parkinsonism, not delayed voluntary fist opening.",
  "Correct — delayed relaxation after voluntary contraction defines myotonia and arises from muscle fibre membrane excitability.",
  "Spasticity is velocity-dependent increased tone on passive movement and indicates an upper motor neuron lesion.",
  "Hypotonia is reduced muscle tone, the exact opposite of this patient's picture, whose problem is in relaxing."
 ],
 "golden_fa": "تأخیر در باز کردن مشت = میوتونی = مشکل غشای عضله. با تکرار بهتر می‌شود.",
 "golden_en": "Delayed fist opening means myotonia, a muscle membrane problem that improves with repetition.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 9: Myotonic disorders",
  "Aminoff MJ et al. Clinical Neurology, 11th ed (2021) — Ch. 3: Examination of muscle tone"
 ]
}

L["1400-08:115"] = {
 "stem_en": "The breathing of a comatose patient is irregular. It has no particular rhythm and each breath differs from the next in rhythm and depth. Which type of breathing in a patient with reduced consciousness does this suggest?",
 "options_en": ["Cheyne-Stokes", "Kussmaul", "Apneustic", "Ataxic"],
 "micro": {
  "lead_fa": "بی‌نظمی کامل در ریتم و عمق، امضای تنفس آتاکسیک و آسیب مدولاست.",
  "lead_en": "Complete irregularity in both rhythm and depth is the signature of ataxic breathing and medullary damage.",
  "points_fa": [
   "الگوهای تنفسی در کما یک نقشه‌ی عمودی از سطح آسیب ساقه‌ی مغز می‌سازند.",
   "هرچه ضایعه پایین‌تر برود، الگوی تنفسی نامنظم‌تر می‌شود.",
   "تنفس شین استوک الگویی دوره‌ای با افزایش و کاهش تدریجی عمق و سپس مکث است.",
   "شین استوک به آسیب دوطرفه‌ی نیمکره‌ها یا دیانسفال اشاره دارد و منظم است.",
   "هیپرونتیلاسیون نوروژنیک مرکزی تنفس عمیق و سریع و منظم است و به مغز میانی مربوط می‌شود.",
   "تنفس آپنوستیک مکث طولانی در انتهای دم دارد و به آسیب پونز اشاره می‌کند.",
   "تنفس آتاکسیک یا بیوت کاملاً بی‌نظم است، هم در ریتم و هم در عمق.",
   "این الگو از آسیب مرکز تنفسی در مدولا یعنی پایین‌ترین سطح می‌آید.",
   "تنفس آتاکسیک هشدار قریب‌الوقوع بودن آپنه است و نیاز به حمایت تنفسی دارد."
  ],
  "points_en": [
   "Breathing patterns in coma form a vertical map of the level of brainstem damage.",
   "The lower the lesion, the more irregular the breathing pattern becomes.",
   "Cheyne-Stokes breathing is a cyclic pattern of gradually rising and falling depth then a pause.",
   "Cheyne-Stokes indicates bilateral hemispheric or diencephalic damage and is regular.",
   "Central neurogenic hyperventilation is deep, fast, regular breathing relating to the midbrain.",
   "Apneustic breathing has a prolonged pause at end-inspiration and indicates pontine damage.",
   "Ataxic or Biot breathing is completely irregular in both rhythm and depth.",
   "This pattern comes from damage to the respiratory centre in the medulla, the lowest level.",
   "Ataxic breathing warns of impending apnoea and calls for ventilatory support."
  ]
 },
 "explanation_fa": "برای حل این سؤال یک قاعده‌ی ساده کافی است: هرچه ضایعه در ساقه‌ی مغز پایین‌تر باشد، تنفس نامنظم‌تر می‌شود. حالا کلمات کلیدی صورت سؤال را ببینید: «ریتم خاصی ندارد» و «هر نفس با نفس بعدی از جهت ریتم و عمق فرق می‌کند». این یعنی بی‌نظمی کامل، که تعریف تنفس آتاکسیک است و به آن تنفس بیوت هم می‌گویند. این الگو از آسیب مرکز تنفسی در مدولا می‌آید، یعنی پایین‌ترین سطح ساقه‌ی مغز، و به همین دلیل هشداری جدی است که آپنه نزدیک است. سه گزینه‌ی دیگر همگی الگوی منظمی دارند: شین استوک نوسان دوره‌ای و قابل پیش‌بینی است، آپنوستیک مکث ثابتی در انتهای دم دارد، و کاسمول تنفس عمیق و منظم اسیدوز متابولیک است که اصلاً به ساقه‌ی مغز مربوط نمی‌شود.",
 "explanation_en": "One simple rule solves this: the lower the brainstem lesion, the more irregular the breathing. Now look at the key words in the stem: no particular rhythm, and each breath differing from the next in rhythm and depth. That means complete irregularity, which defines ataxic breathing, also called Biot breathing. This pattern comes from damage to the respiratory centre in the medulla, the lowest level of the brainstem, and is therefore a serious warning that apnoea is near. The other three all have regular patterns: Cheyne-Stokes is a cyclic and predictable oscillation, apneustic has a fixed pause at end-inspiration. And Kussmaul is the deep regular breathing of metabolic acidosis, unrelated to the brainstem.",
 "why_fa": [
  "تنفس شین استوک الگویی دوره‌ای و منظم با افزایش و کاهش تدریجی عمق است، پس با بی‌نظمی کامل توصیف‌شده نمی‌خواند.",
  "تنفس کاسمول عمیق و منظم است و پاسخ جبرانی به اسیدوز متابولیک محسوب می‌شود، نه نشانه‌ی آسیب ساقه‌ی مغز.",
  "تنفس آپنوستیک مکث طولانی و تکرارشونده در انتهای دم دارد، پس الگوی مشخصی دارد و کاملاً بی‌نظم نیست.",
  "پاسخ صحیح — تنفس آتاکسیک هم در ریتم و هم در عمق کاملاً بی‌نظم است و نشانه‌ی آسیب مدولا و هشدار آپنه است."
 ],
 "why_en": [
  "Cheyne-Stokes breathing is a cyclic, regular pattern of gradually rising and falling depth, so it does not match the complete irregularity described.",
  "Kussmaul breathing is deep and regular, a compensatory response to metabolic acidosis rather than a sign of brainstem damage.",
  "Apneustic breathing has a prolonged repeating pause at end-inspiration, so it has a definite pattern and is not completely irregular.",
  "Correct — ataxic breathing is completely irregular in both rhythm and depth, indicating medullary damage and warning of apnoea."
 ],
 "golden_fa": "دیانسفال=شین استوک، مغز میانی=هیپرونتیلاسیون، پونز=آپنوستیک، مدولا=آتاکسیک.",
 "golden_en": "Diencephalon means Cheyne-Stokes, midbrain hyperventilation, pons apneustic, medulla ataxic.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 4: Respiratory patterns in coma",
  "Posner JB, Saper CB et al. Plum and Posner's Diagnosis of Stupor and Coma, 5th ed"
 ]
}

L["1400-08:116"] = {
 "stem_en": "Which of the following statements about reflex examination is correct?",
 "options_en": ["Elbow flexion is C5-C6 and the median nerve",
                "Elbow extension is C6-C7 and the radial nerve",
                "Plantar flexion of the foot is S1 and the posterior tibial nerve",
                "Knee extension is L1-L2 and the femoral nerve"],
 "micro": {
  "lead_fa": "هر رفلکس دو مختصات دارد، ریشه و عصب، و هر دو باید درست باشند.",
  "lead_en": "Each reflex has two coordinates, root and nerve, and both must be right.",
  "points_fa": [
   "رفلکس‌های وتری اصلی چهارتا هستند و باید ریشه و عصب هرکدام را بدانید.",
   "رفلکس بایسپس یعنی فلکسیون آرنج: ریشه C5-C6 و عصب موسکولوکوتانئوس.",
   "رفلکس برادیورادیالیس هم C5-C6 است اما عصبش رادیال است.",
   "رفلکس تریسپس یعنی اکستانسیون آرنج: ریشه C7-C8 و عصب رادیال.",
   "رفلکس پاتلار یعنی اکستانسیون زانو: ریشه L3-L4 و عصب فمورال.",
   "رفلکس آشیل یعنی پلانتارفلکسیون مچ پا: ریشه S1 و عصب تیبیال.",
   "یک راه یادسپاری عددی: ۱-۲ زانو نیست، ۳-۴ زانوست، ۵-۶ بایسپس، ۷-۸ تریسپس.",
   "S1 برای آشیل و S1-S2 گاهی ذکر می‌شود.",
   "عصب مدیان رفلکس وتری اصلی ندارد و فلکسور آرنج را عصب‌دهی نمی‌کند."
  ],
  "points_en": [
   "There are four main tendon reflexes and you must know the root and nerve of each.",
   "The biceps reflex, elbow flexion: root C5-C6 and the musculocutaneous nerve.",
   "The brachioradialis reflex is also C5-C6 but its nerve is the radial.",
   "The triceps reflex, elbow extension: root C7-C8 and the radial nerve.",
   "The patellar reflex, knee extension: root L3-L4 and the femoral nerve.",
   "The Achilles reflex, ankle plantar flexion: root S1 and the tibial nerve.",
   "A numeric mnemonic: one-two is not the knee, three-four is the knee, five-six biceps, seven-eight triceps.",
   "S1 serves the Achilles, sometimes given as S1-S2.",
   "The median nerve has no main tendon reflex and does not supply the elbow flexor."
  ]
 },
 "explanation_fa": "این سؤال چهار جفت «ریشه و عصب» می‌دهد و باید جفتی را پیدا کنید که هر دو جزئش درست باشد؛ همین موضوع سؤال را دشوار می‌کند چون سه گزینه فقط یک جزء غلط دارند و به نظر آشنا می‌آیند. گزینه‌ی اول ریشه‌اش درست است، فلکسیون آرنج واقعاً C5-C6 است، اما عصبش موسکولوکوتانئوس است نه مدیان. گزینه‌ی دوم عصبش درست است، تریسپس واقعاً از عصب رادیال است، اما ریشه‌اش C7-C8 است نه C6-C7. گزینه‌ی چهارم هم عصبش درست است، اکستانسیون زانو واقعاً از عصب فمورال است، اما ریشه‌اش L3-L4 است نه L1-L2. تنها گزینه‌ای که هر دو جزئش درست است، رفلکس آشیل است: پلانتارفلکسیون مچ پا از ریشه‌ی S1 و عصب تیبیال. راهبرد حل چنین سؤالاتی این است که هر جزء را جداگانه چک کنید نه اینکه گزینه را به‌صورت کلی «آشنا» ببینید.",
 "explanation_en": "This item gives four root-and-nerve pairs and asks for the one where both parts are right. That is what makes it hard. This is because three options have only one wrong part and look familiar. The first has the right root, elbow flexion really is C5-C6, but its nerve is musculocutaneous, not median. The second has the right nerve, triceps really is radial, but its root is C7-C8, not C6-C7. The fourth also has the right nerve, knee extension really is femoral, but its root is L3-L4, not L1-L2. The only option correct in both parts is the Achilles reflex: ankle plantar flexion from root S1 via the tibial nerve. The strategy for such items is to check each component separately rather than judging the option as broadly familiar.",
 "why_fa": [
  "نادرست است. فلکسیون آرنج یعنی رفلکس بایسپس، ریشه‌ی C5-C6 درست است اما عصب آن موسکولوکوتانئوس است نه مدیان.",
  "نادرست است. اکستانسیون آرنج یعنی رفلکس تریسپس، عصب رادیال درست است اما ریشه‌ی آن C7-C8 است نه C6-C7.",
  "پاسخ صحیح — رفلکس آشیل یعنی پلانتارفلکسیون مچ پا، از ریشه‌ی S1 می‌آید و توسط عصب تیبیال منتقل می‌شود.",
  "نادرست است. اکستانسیون زانو یعنی رفلکس پاتلار، عصب فمورال درست است اما ریشه‌ی آن L3-L4 است نه L1-L2."
 ],
 "why_en": [
  "False. Elbow flexion is the biceps reflex; the C5-C6 root is right but its nerve is musculocutaneous, not median.",
  "False. Elbow extension is the triceps reflex; the radial nerve is right but its root is C7-C8, not C6-C7.",
  "Correct — the Achilles reflex, ankle plantar flexion, comes from root S1 and travels via the tibial nerve.",
  "False. Knee extension is the patellar reflex; the femoral nerve is right but its root is L3-L4, not L1-L2."
 ],
 "golden_fa": "بایسپس C5-6 موسکولوکوتانئوس، تریسپس C7-8 رادیال، پاتلار L3-4 فمورال، آشیل S1 تیبیال.",
 "golden_en": "Biceps C5-6 musculocutaneous, triceps C7-8 radial, patellar L3-4 femoral, Achilles S1 tibial.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 3: The reflex examination",
  "Aminoff MJ et al. Clinical Neurology, 11th ed (2021) — Ch. 9: Radiculopathy and root levels"
 ]
}

L["1400-08:117"] = {
 "stem_en": "An 11-year-old boy has had jerky limb movements during the day for the past six months, especially just after waking. Which of the following drugs is most appropriate for treatment?",
 "options_en": ["Ethosuximide", "Gabapentin", "Valproic acid", "Phenytoin"],
 "micro": {
  "lead_fa": "پرش صبحگاهی در نوجوان یعنی صرع میوکلونیک جوانان و داروی انتخابی والپروات است.",
  "lead_en": "Morning jerks in an adolescent mean juvenile myoclonic epilepsy, and valproate is the drug of choice.",
  "points_fa": [
   "صرع میوکلونیک جوانان معمولاً بین دوازده تا هجده سالگی شروع می‌شود.",
   "مشخصه‌ی آن پرش‌های میوکلونیک دوطرفه و کوتاه اندام‌های فوقانی است.",
   "این پرش‌ها در ساعات اول پس از بیدار شدن بیشترین شدت را دارند.",
   "بیمار اغلب می‌گوید صبح‌ها فنجان یا مسواک از دستش می‌افتد.",
   "کم‌خوابی، خستگی و الکل مهم‌ترین محرک‌های حمله‌اند.",
   "این سندرم سه نوع حمله دارد: میوکلونیک، غیاب و تونیک-کلونیک ژنرالیزه.",
   "نوار مغز پلی‌اسپایک-موج منتشر با فرکانس چهار تا شش هرتز نشان می‌دهد.",
   "والپروئیک اسید هر سه نوع حمله را پوشش می‌دهد و مؤثرترین انتخاب است.",
   "در دختران به دلیل تراتوژنیسیته، لواتیراستام یا لاموتریژین ترجیح داده می‌شود."
  ],
  "points_en": [
   "Juvenile myoclonic epilepsy usually starts between twelve and eighteen years of age.",
   "It is characterised by brief bilateral myoclonic jerks of the upper limbs.",
   "These jerks are most intense in the first hours after waking.",
   "Patients often say they drop a cup or toothbrush in the morning.",
   "Sleep deprivation, fatigue and alcohol are the main triggers.",
   "The syndrome has three seizure types: myoclonic, absence and generalised tonic-clonic.",
   "The EEG shows generalised polyspike-and-wave at four to six hertz.",
   "Valproic acid covers all three seizure types and is the most effective choice.",
   "In girls, because of teratogenicity, levetiracetam or lamotrigine is preferred."
  ]
 },
 "explanation_fa": "دو کلمه‌ی صورت سؤال تشخیص را می‌سازند: «حرکات پرشی» و «ابتدای بیدار شدن از خواب». این دو با هم در یک نوجوان، تصویر کتابی صرع میوکلونیک جوانان است. حالا انتخاب دارو. این یک صرع ژنرالیزه‌ی ایدیوپاتیک است و سه نوع حمله دارد: میوکلونیک، غیاب و تونیک-کلونیک. پس داروی مناسب باید هر سه را پوشش دهد و والپروئیک اسید دقیقاً همین کار را می‌کند. حالا چرا بقیه غلط‌اند و این نکته بالینی مهمی است: اتوسوکسیماید فقط روی حملات غیاب اثر دارد و میوکلونوس را پوشش نمی‌دهد. فنی‌توئین و گاباپنتین هر دو مسدودکننده‌ی کانال سدیم‌اند و در صرع‌های ژنرالیزه‌ی اولیه نه‌تنها کمکی نمی‌کنند بلکه می‌توانند پرش‌های میوکلونیک را تشدید کنند. یک نکته‌ی عملی: در بیمار دختر، به‌خاطر تراتوژنیسیته‌ی والپروات، لواتیراستام ترجیح داده می‌شود.",
 "explanation_en": "Two phrases in the stem make the diagnosis: jerky movements and just after waking. Together in an adolescent, that is the textbook picture of juvenile myoclonic epilepsy. Now the drug choice. This is an idiopathic generalised epilepsy with three seizure types: myoclonic, absence and tonic-clonic. So the right drug must cover all three, and valproic acid does exactly that. Why the others are wrong is an important clinical point: ethosuximide works only on absence seizures and does not cover myoclonus. Phenytoin and gabapentin are both sodium channel blockers that not only fail to help in primary generalised epilepsies but can aggravate myoclonic jerks. A practical note: in a female patient, because of valproate's teratogenicity, levetiracetam is preferred.",
 "why_fa": [
  "اتوسوکسیماید فقط برای حملات غیاب مؤثر است و روی پرش‌های میوکلونیک و تشنج تونیک-کلونیک اثری ندارد.",
  "گاباپنتین برای درد نوروپاتیک و تشنج فوکال است و در صرع‌های ژنرالیزه‌ی اولیه می‌تواند میوکلونوس را بدتر کند.",
  "پاسخ صحیح — والپروئیک اسید هر سه نوع حمله‌ی صرع میوکلونیک جوانان را پوشش می‌دهد و مؤثرترین انتخاب است.",
  "فنی‌توئین مسدودکننده‌ی کانال سدیم است و در این سندرم می‌تواند پرش‌های میوکلونیک را تشدید کند."
 ],
 "why_en": [
  "Ethosuximide is effective only for absence seizures and has no effect on myoclonic jerks or tonic-clonic seizures.",
  "Gabapentin is for neuropathic pain and focal seizures and can worsen myoclonus in primary generalised epilepsies.",
  "Correct — valproic acid covers all three seizure types of juvenile myoclonic epilepsy and is the most effective choice.",
  "Phenytoin is a sodium channel blocker and can aggravate myoclonic jerks in this syndrome."
 ],
 "golden_fa": "پرش صبحگاهی در نوجوان = JME = والپروات. در دختران لواتیراستام.",
 "golden_en": "Morning jerks in an adolescent mean JME and valproate; in girls, levetiracetam.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 12: Juvenile myoclonic epilepsy",
  "Genton P et al. Juvenile myoclonic epilepsy: an update. Epilepsy Behav 2013;28:S1-S6"
 ]
}

L["1400-08:118"] = {
 "stem_en": "A 4-year-old child has had a seizure following fever. All of the following in the history and examination increase the chance of recurrence EXCEPT:",
 "options_en": ["Presence of a focal neurological deficit on examination",
                "If the seizure occurred above one year of age",
                "The seizure being focal or lasting more than 15 minutes",
                "A family history of seizures"],
 "micro": {
  "lead_fa": "هرچه کودک هنگام اولین تشنج کوچک‌تر باشد خطر عود بیشتر است، پس سن بالاتر عامل خطر نیست.",
  "lead_en": "The younger the child at the first seizure, the higher the recurrence risk, so older age is not a risk factor.",
  "points_fa": [
   "تشنج ناشی از تب شایع‌ترین اختلال تشنجی کودکان است و در دو تا پنج درصد رخ می‌دهد.",
   "به دو دسته تقسیم می‌شود: ساده و پیچیده.",
   "تشنج ساده ژنرالیزه، کوتاه‌تر از پانزده دقیقه و بدون تکرار در بیست‌وچهار ساعت است.",
   "تشنج پیچیده فوکال است یا بیش از پانزده دقیقه طول می‌کشد یا تکرار می‌شود.",
   "عوامل خطر عود: سن کم هنگام اولین حمله، به‌ویژه زیر دوازده تا هجده ماه.",
   "سابقه‌ی خانوادگی تشنج ناشی از تب یا صرع هم خطر را بالا می‌برد.",
   "تب کوتاه‌مدت پیش از تشنج و دمای پایین‌تر هنگام تشنج نیز عامل خطرند.",
   "نقص عصبی زمینه‌ای یا تأخیر تکاملی خطر تبدیل به صرع را بالا می‌برد.",
   "احتمال کلی عود حدود سی درصد است و با هر عامل خطر بالاتر می‌رود."
  ],
  "points_en": [
   "Febrile seizure is the commonest seizure disorder of childhood, occurring in two to five percent.",
   "It divides into two groups: simple and complex.",
   "A simple febrile seizure is generalised, under fifteen minutes and does not recur within twenty-four hours.",
   "A complex one is focal, or lasts over fifteen minutes, or recurs.",
   "Recurrence risk factors: young age at the first attack, especially under twelve to eighteen months.",
   "A family history of febrile seizures or epilepsy also raises the risk.",
   "A short fever before the seizure and a lower temperature at seizure onset are also risk factors.",
   "An underlying neurological deficit or developmental delay raises the risk of progressing to epilepsy.",
   "Overall recurrence risk is about thirty percent and rises with each risk factor."
  ]
 },
 "explanation_fa": "این سؤال از نوع «همه بجز» است، پس باید فهرست عوامل خطر عود را بدانید و گزینه‌ای را پیدا کنید که بیرون از آن است، یا حتی برعکس آن. سه گزینه در فهرست هستند: نقص فوکال عصبی نشان‌دهنده‌ی زمینه‌ی مغزی غیرطبیعی است و خطر را بالا می‌برد؛ تشنج فوکال یا طولانی‌تر از پانزده دقیقه یعنی تشنج پیچیده که خطر بیشتری دارد؛ و سابقه‌ی خانوادگی مثبت هم عامل خطر شناخته‌شده است. اما گزینه‌ی سن دقیقاً وارونه‌ی واقعیت را می‌گوید. قاعده این است که هرچه کودک هنگام اولین تشنج کوچک‌تر باشد، خطر عود بیشتر است، و آستانه‌ی مهم زیر دوازده تا هجده ماهگی است. منطقش هم روشن است: کودکی که در شش‌ماهگی اولین تشنج را داشته، سال‌های بیشتری از دوره‌ی حساس پیش رو دارد تا کودکی که در سه‌سالگی شروع کرده. پس شروع در بالای یک‌سالگی عامل محافظتی نسبی است، نه عامل خطر.",
 "explanation_en": "This is an all-except item, so you need the recurrence risk list and must find the option outside it, or even opposite to it. Three options are on the list: a focal neurological deficit indicates an abnormal underlying brain and raises risk. A focal seizure or one over fifteen minutes is a complex febrile seizure with higher risk. And a positive family history is a recognised risk factor. The age option, however, states the exact reverse of reality. The rule is that the younger the child at the first seizure, the higher the recurrence risk, with the key threshold under twelve to eighteen months. The logic is clear: a child whose first seizure came at six months has more years of the susceptible period ahead than one who started at three years. So onset above one year is relatively protective, not a risk factor.",
 "why_fa": [
  "نقص فوکال عصبی در معاینه نشان‌دهنده‌ی ناهنجاری زمینه‌ای مغز است و هم خطر عود و هم خطر تبدیل به صرع را بالا می‌برد.",
  "پاسخ صحیح (گزینه‌ی نادرست) — قاعده برعکس است: هرچه سن اولین تشنج پایین‌تر باشد خطر عود بیشتر است، به‌ویژه زیر یک سال.",
  "تشنج فوکال یا طولانی‌تر از پانزده دقیقه تعریف تشنج پیچیده است و با خطر بالاتر عود و صرع همراه است.",
  "سابقه‌ی خانوادگی تشنج ناشی از تب یا صرع، زمینه‌ی ژنتیکی را نشان می‌دهد و عامل خطر شناخته‌شده‌ی عود است."
 ],
 "why_en": [
  "A focal neurological deficit on examination indicates an underlying brain abnormality and raises both recurrence and epilepsy risk.",
  "Correct answer (the false option) — the rule is the reverse: the younger the age at the first seizure, the higher the recurrence risk, especially under one year.",
  "A focal seizure or one lasting over fifteen minutes defines a complex febrile seizure, carrying higher recurrence and epilepsy risk.",
  "A family history of febrile seizures or epilepsy indicates genetic predisposition and is a recognised recurrence risk factor."
 ],
 "golden_fa": "تشنج تبی: سن کمتر = خطر بیشتر. پیچیده بودن، نقص عصبی و سابقه‌ی خانوادگی هم خطر را بالا می‌برند.",
 "golden_en": "Febrile seizure: younger age means higher risk; complexity, neurological deficit and family history also raise it.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 12: Febrile seizures",
  "AAP Subcommittee. Neurodiagnostic evaluation of the child with a simple febrile seizure. Pediatrics 2011;127:389-94"
 ]
}

L["1400-08:119"] = {
 "stem_en": "Which of the following headaches can be a cause of thunderclap headache?",
 "options_en": ["Migraine", "Tension", "Cluster", "Trigeminal neuralgia"],
 "micro": {
  "lead_fa": "سردرد رعدآسا یعنی اوج شدت در کمتر از یک دقیقه؛ میان سردردهای اولیه، میگرن می‌تواند چنین باشد.",
  "lead_en": "Thunderclap headache means peak intensity in under a minute; among primary headaches, migraine can present this way.",
  "points_fa": [
   "سردرد رعدآسا سردردی است که در کمتر از یک دقیقه به اوج شدت می‌رسد.",
   "این یک توصیف زمانی است، نه یک تشخیص؛ همیشه باید علتش را جست.",
   "اولویت مطلق رد کردن علل ثانویه‌ی خطرناک است.",
   "در صدر آن‌ها خون‌ریزی زیرعنکبوتیه است که تا اثبات خلاف باید فرض شود.",
   "علل ثانویه‌ی دیگر: ترومبوز سینوس وریدی، دایسکشن شریانی و سندرم RCVS.",
   "بررسی اولیه سی‌تی بدون کنتراست است و اگر منفی بود پونکسیون کمری.",
   "پس از رد کردن همه‌ی علل ثانویه، می‌توان به سردرد اولیه فکر کرد.",
   "میان سردردهای اولیه، میگرن می‌تواند گاهی با شروع بسیار ناگهانی تظاهر کند.",
   "سردرد تنشی تدریجی است و سردرد خوشه‌ای طی دقایق اوج می‌گیرد نه ثانیه‌ها."
  ],
  "points_en": [
   "Thunderclap headache is a headache reaching peak intensity in under a minute.",
   "It is a temporal description, not a diagnosis; its cause must always be sought.",
   "The absolute priority is excluding dangerous secondary causes.",
   "Foremost among them is subarachnoid haemorrhage, assumed until proven otherwise.",
   "Other secondary causes: venous sinus thrombosis, arterial dissection and RCVS.",
   "Initial workup is non-contrast CT, and lumbar puncture if it is negative.",
   "Only after excluding all secondary causes can a primary headache be considered.",
   "Among primary headaches, migraine can occasionally present with a very abrupt onset.",
   "Tension headache is gradual, and cluster headache peaks over minutes rather than seconds."
  ]
 },
 "explanation_fa": "اول باید بدانید سردرد رعدآسا اصلاً یک تشخیص نیست، بلکه توصیف سرعت شروع است: دردی که در کمتر از یک دقیقه به اوج می‌رسد. مهم‌ترین درس بالینی این است که چنین سردردی تا رد شدن خون‌ریزی زیرعنکبوتیه، اورژانس محسوب می‌شود و باید با سی‌تی بدون کنتراست و در صورت منفی بودن با پونکسیون کمری بررسی شود. اما این سؤال چیز دیگری می‌پرسد: میان چهار سردرد اولیه، کدام می‌تواند به این شکل تظاهر کند؟ سردرد تنشی طی ساعت‌ها به‌تدریج شکل می‌گیرد. سردرد خوشه‌ای گرچه بسیار شدید است، طی چند دقیقه اوج می‌گیرد نه چند ثانیه. نورالژی تریژمینال درد برق‌آسای چندثانیه‌ای صورت است که با لمس راه می‌افتد، نه سردردی منتشر. تنها میگرن است که در منابع به‌عنوان یک علت اولیه‌ی احتمالی سردرد رعدآسا فهرست می‌شود.",
 "explanation_en": "First understand that thunderclap headache is not a diagnosis at all but a description of onset speed: pain reaching peak intensity in under a minute. The most important clinical lesson is that such a headache is an emergency until subarachnoid haemorrhage is excluded, investigated with non-contrast CT and, if negative, lumbar puncture. But this item asks something else: among four primary headaches, which can present this way? Tension headache builds gradually over hours. Cluster headache, though very severe, peaks over minutes rather than seconds. Trigeminal neuralgia is a few seconds of electric facial pain triggered by touch, not a diffuse headache. Only migraine is listed in the literature as a possible primary cause of thunderclap headache.",
 "why_fa": [
  "پاسخ صحیح — میگرن تنها سردرد اولیه‌ی این فهرست است که می‌تواند گاهی با شروع بسیار ناگهانی و رعدآسا تظاهر کند.",
  "سردرد تنشی طی ساعت‌ها به‌تدریج شکل می‌گیرد و فشارنده و دوطرفه است، پس با شروع ثانیه‌ای سازگار نیست.",
  "سردرد خوشه‌ای بسیار شدید است اما طی چند دقیقه به اوج می‌رسد، نه در کمتر از یک دقیقه.",
  "نورالژی تریژمینال درد برق‌آسای چندثانیه‌ای در قلمرو عصب پنجم است که با لمس صورت راه می‌افتد، نه سردرد رعدآسا."
 ],
 "why_en": [
  "Correct — migraine is the only primary headache on this list that can occasionally present with a very abrupt thunderclap onset.",
  "Tension headache builds gradually over hours and is pressing and bilateral, so it does not fit a seconds-long onset.",
  "Cluster headache is very severe but peaks over several minutes, not in under a minute.",
  "Trigeminal neuralgia is a few seconds of electric pain in the fifth nerve territory triggered by facial touch, not a thunderclap headache."
 ],
 "golden_fa": "رعدآسا = اوج زیر یک دقیقه = اول SAH را رد کنید. میان اولیه‌ها فقط میگرن.",
 "golden_en": "Thunderclap means peak under a minute: exclude SAH first; among primary headaches only migraine.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 6: Thunderclap headache",
  "Schwedt TJ, Matharu MS, Dodick DW. Thunderclap headache. Lancet Neurol 2006;5:621-31"
 ]
}

L["1400-08:120"] = {
 "stem_en": "A 70-year-old woman presents with dementia, visual hallucinations and parkinsonism. Her cognitive problems vary through the day. Which of the following diseases could this be?",
 "options_en": ["Vascular dementia", "Dementia with Lewy bodies",
                "Progressive supranuclear palsy", "Frontotemporal dementia"],
 "micro": {
  "lead_fa": "نوسان شناختی، توهم بینایی و پارکینسونیسم سه‌گانه‌ی هسته‌ای دمانس با اجسام لویی است.",
  "lead_en": "Cognitive fluctuation, visual hallucinations and parkinsonism are the core triad of dementia with Lewy bodies.",
  "points_fa": [
   "دمانس با اجسام لویی از تجمع آلفا-سینوکلئین در نورون‌های قشری می‌آید.",
   "سه ویژگی هسته‌ای دارد: نوسان شناختی، توهم بینایی و پارکینسونیسم.",
   "نوسان یعنی بیمار در ساعاتی شفاف و در ساعاتی گیج و خواب‌آلود است.",
   "توهم‌ها بینایی، شکل‌یافته و زودرس‌اند: آدم‌ها یا حیوانات کوچک.",
   "اختلال رفتاری خواب REM اغلب سال‌ها پیش از دمانس ظاهر می‌شود.",
   "قاعده‌ی یک‌ساله: اگر پارکینسونیسم بیش از یک سال زودتر باشد، دمانس پارکینسون است.",
   "حساسیت شدید به نورولپتیک وجود دارد و هالوپریدول می‌تواند کشنده باشد.",
   "برای کنترل توهم باید از کوئتیاپین یا کلوزاپین استفاده کرد، نه نورولپتیک تیپیک.",
   "درمان شناختی با مهارکننده‌ی کولین‌استراز مثل ریواستیگمین پاسخ خوبی می‌دهد."
  ],
  "points_en": [
   "Dementia with Lewy bodies arises from alpha-synuclein accumulating in cortical neurons.",
   "It has three core features: cognitive fluctuation, visual hallucinations and parkinsonism.",
   "Fluctuation means the patient is lucid at some hours and confused or drowsy at others.",
   "The hallucinations are visual, well formed and early: people or small animals.",
   "REM sleep behaviour disorder often appears years before the dementia.",
   "The one-year rule: if parkinsonism precedes by over a year, it is Parkinson disease dementia.",
   "There is severe neuroleptic sensitivity and haloperidol can be fatal.",
   "To control hallucinations use quetiapine or clozapine, not a typical neuroleptic.",
   "Cognitive treatment with a cholinesterase inhibitor such as rivastigmine works well."
  ]
 },
 "explanation_fa": "صورت سؤال سه ویژگی هسته‌ای را تقریباً کلمه‌به‌کلمه آورده است: دمانس با توهم بینایی، علائم پارکینسونیسم، و مشکلات شناختی متغیر در طول روز. وقتی این سه با هم بیایند، تشخیص دمانس با اجسام لویی است و نیازی به سرنخ بیشتری نیست. برای اطمینان سه گزینه‌ی دیگر را کنار بگذارید: دمانس عروقی افت پله‌ای دارد و با علائم فوکال و سابقه‌ی سکته همراه است؛ فلج فوق هسته‌ای پیشرونده با زمین‌خوردن‌های زودرس و ناتوانی در نگاه عمودی مشخص می‌شود و توهم بینایی زودرس ندارد؛ دمانس فرونتوتمپورال با تغییر شخصیت و بی‌بندوباری اجتماعی یا اختلال زبان شروع می‌شود. نکته‌ی درمانی حیاتی که همیشه باید همراه این تشخیص به یاد بیاورید: هرگز برای کنترل توهم این بیماران هالوپریدول ندهید، چون حساسیت شدید به نورولپتیک دارند و واکنش می‌تواند کشنده باشد.",
 "explanation_en": "The stem lists the three core features almost word for word: dementia with visual hallucinations, parkinsonian signs, and cognitive problems varying through the day. When those three come together the diagnosis is dementia with Lewy bodies and no further clue is needed. To be sure, set aside the other three: vascular dementia declines stepwise with focal signs and a stroke history. Progressive supranuclear palsy is marked by early falls and inability to look vertically and lacks early visual hallucinations. Frontotemporal dementia begins with personality change, social disinhibition or language impairment. The vital treatment point to recall alongside this diagnosis: never give haloperidol to control these patients' hallucinations. This is because they have severe neuroleptic sensitivity and the reaction can be fatal.",
 "why_fa": [
  "دمانس عروقی سیر پله‌ای دارد و با علائم فوکال عصبی و شواهد سکته در تصویربرداری همراه است، نه توهم بینایی زودرس.",
  "پاسخ صحیح — نوسان شناختی در طول روز، توهم بینایی و پارکینسونیسم با هم، امضای دمانس با اجسام لویی است.",
  "فلج فوق هسته‌ای پیشرونده با زمین‌خوردن‌های زودرس و فلج نگاه عمودی مشخص می‌شود و توهم بینایی از ویژگی‌های آن نیست.",
  "دمانس فرونتوتمپورال با تغییر شخصیت، بی‌بندوباری اجتماعی یا اختلال زبان شروع می‌شود و معمولاً زیر شصت‌وپنج سالگی است."
 ],
 "why_en": [
  "Vascular dementia declines stepwise with focal neurological signs and imaging evidence of stroke, not early visual hallucinations.",
  "Correct — cognitive fluctuation through the day, visual hallucinations and parkinsonism together are the signature of dementia with Lewy bodies.",
  "Progressive supranuclear palsy is marked by early falls and vertical gaze palsy; visual hallucinations are not among its features.",
  "Frontotemporal dementia begins with personality change, social disinhibition or language impairment and is usually under sixty-five."
 ],
 "golden_fa": "نوسان + توهم بینایی + پارکینسونیسم = لوی بادی. هرگز هالوپریدول ندهید.",
 "golden_en": "Fluctuation plus visual hallucinations plus parkinsonism means Lewy body; never give haloperidol.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 5: Dementia with Lewy bodies",
  "McKeith IG et al. Diagnosis and management of dementia with Lewy bodies: fourth consensus report. Neurology 2017;89:88-100"
 ]
}

L["1400-08:121"] = {
 "stem_en": "A 25-year-old woman presents with blurred vision for the past year. She also complains of paresthesia and sphincter dysfunction. Which of the following is NOT needed to diagnose her disease?",
 "options_en": ["MRI", "Lumbar puncture", "Assessing the sensory level on examination",
                "Nerve conduction study and EMG"],
 "micro": {
  "lead_fa": "ام‌اس بیماری سیستم عصبی مرکزی است، پس نوار عصب و عضله که محیطی را می‌سنجد جایی ندارد.",
  "lead_en": "Multiple sclerosis is a central disease, so nerve conduction studies, which assess the periphery, have no role.",
  "points_fa": [
   "زن جوان با تاری دید، پارستزی و اختلال اسفنکتری، تا خلاف آن ثابت نشود ام‌اس دارد.",
   "تاری دید نشانه‌ی نوریت اپتیک است و اختلال اسفنکتری به ضایعه‌ی نخاعی اشاره دارد.",
   "پس دو محل جدا در سیستم عصبی مرکزی درگیرند.",
   "MRI مغز و نخاع استاندارد طلایی است و پلاک‌های دمیلینه را نشان می‌دهد.",
   "MRI پراکندگی در مکان و با ضایعات تقویت‌شونده، پراکندگی در زمان را اثبات می‌کند.",
   "پونکسیون کمری باندهای الیگوکلونال IgG را نشان می‌دهد که در بیش از هشتاد و پنج درصد مثبت است.",
   "بررسی سطح حسی در معاینه به موضع‌یابی ضایعه‌ی نخاعی کمک می‌کند.",
   "پتانسیل برانگیخته‌ی بینایی هم می‌تواند نوریت اپتیک خاموش را آشکار کند.",
   "نوار عصب و عضله فقط عصب محیطی و عضله را می‌سنجد و در ام‌اس طبیعی است."
  ],
  "points_en": [
   "A young woman with blurred vision, paresthesia and sphincter dysfunction has multiple sclerosis until proven otherwise.",
   "Blurred vision indicates optic neuritis and sphincter dysfunction points to a cord lesion.",
   "So two separate sites in the central nervous system are involved.",
   "MRI of brain and cord is the gold standard and shows demyelinating plaques.",
   "MRI proves dissemination in space and, with enhancing lesions, dissemination in time.",
   "Lumbar puncture shows oligoclonal IgG bands, positive in over eighty-five percent.",
   "Assessing the sensory level on examination helps localise the cord lesion.",
   "Visual evoked potentials can also reveal a silent optic neuritis.",
   "Nerve conduction studies assess only peripheral nerve and muscle and are normal in multiple sclerosis."
  ]
 },
 "explanation_fa": "این سؤال یک اصل ساده ولی بسیار پرکاربرد را می‌آزماید: ابزار تشخیصی را باید با محل بیماری تطبیق داد. تشخیص اینجا ام‌اس است؛ زن جوان با نوریت اپتیک (تاری دید)، پارستزی و اختلال اسفنکتری که همگی به سیستم عصبی مرکزی اشاره دارند. حالا سه اقدام دیگر را ببینید: MRI مغز و نخاع پلاک‌های دمیلینه را مستقیم نشان می‌دهد و استاندارد طلایی است؛ پونکسیون کمری باندهای الیگوکلونال را می‌یابد که سنتز موضعی آنتی‌بادی در سیستم عصبی مرکزی را اثبات می‌کند؛ و بررسی سطح حسی در معاینه به تعیین محل ضایعه‌ی نخاعی کمک می‌کند. هر سه در قلمرو مرکزی کار می‌کنند. اما نوار عصب و عضله ابزار سنجش عصب محیطی و عضله است و در بیماری ماده‌ی سفید مرکزی کاملاً طبیعی خواهد بود، پس اطلاعاتی به تشخیص اضافه نمی‌کند.",
 "explanation_en": "This item tests a simple but widely useful principle: match the diagnostic tool to the site of disease. The diagnosis here is multiple sclerosis; a young woman with optic neuritis (blurred vision), paresthesia and sphincter dysfunction, all pointing to the central nervous system. Now consider the other three actions: MRI of brain and cord directly shows demyelinating plaques and is the gold standard. Lumbar puncture finds oligoclonal bands proving local antibody synthesis within the central nervous system. And assessing the sensory level helps localise the cord lesion. All three work in the central domain. Nerve conduction studies, however, are a tool for peripheral nerve and muscle and would be entirely normal in a central white matter disease. So they add nothing to the diagnosis.",
 "why_fa": [
  "MRI مغز و نخاع استاندارد طلایی تشخیص ام‌اس است و پلاک‌های دمیلینه و پراکندگی در مکان و زمان را نشان می‌دهد.",
  "پونکسیون کمری باندهای الیگوکلونال IgG را آشکار می‌کند که در بیش از هشتاد و پنج درصد بیماران ام‌اس مثبت است.",
  "بررسی سطح حسی در معاینه‌ی بالینی به موضع‌یابی ضایعه‌ی نخاعی کمک می‌کند و بخشی از ارزیابی استاندارد است.",
  "پاسخ صحیح — نوار عصب و عضله فقط اعصاب محیطی و عضله را می‌سنجد و در ام‌اس که بیماری مرکزی است طبیعی می‌ماند."
 ],
 "why_en": [
  "MRI of brain and cord is the gold standard for diagnosing multiple sclerosis and shows plaques and dissemination in space and time.",
  "Lumbar puncture reveals oligoclonal IgG bands, positive in over eighty-five percent of patients with the disease.",
  "Assessing the sensory level on clinical examination helps localise the cord lesion and is part of the standard evaluation.",
  "Correct — nerve conduction studies assess only peripheral nerves and muscle and stay normal in multiple sclerosis, a central disease."
 ],
 "golden_fa": "ام‌اس = مرکزی. MRI و LP بله، نوار عصب و عضله نه.",
 "golden_en": "Multiple sclerosis is central: MRI and LP yes, nerve conduction studies no.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 7: Multiple sclerosis, investigations",
  "Thompson AJ et al. Diagnosis of multiple sclerosis: 2017 revisions of the McDonald criteria. Lancet Neurol 2018;17:162-73"
 ]
}

json.dump(L, io.open('/home/user/work/lessons/L17.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('L17:', len(L))
