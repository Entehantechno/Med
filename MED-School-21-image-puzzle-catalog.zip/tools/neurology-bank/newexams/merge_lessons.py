# -*- coding: utf-8 -*-
"""Merge authored micro-lessons into bank.json.

Lesson files are keyed by "<exam_tag>:<question_no>" rather than uid, because uids
are assigned at merge time. English stem/options are only written when the lesson
supplies them; for the Esfand-1400 sitting they already came from the ministry's
official English booklet and must not be overwritten.
"""
import json, io, glob

BANK = '/home/user/project/tools/neurology-bank/bank.json'
bank = json.load(io.open(BANK, encoding='utf-8'))
by_key = {}
for r in bank:
    if 'exam_tag_key' in r:
        by_key[r['exam_tag_key']] = r

# rebuild the lookup from year/month, matching how merge_new.py wrote them
MONTH2TAG = {('۱۴۰۴','شهریور'):'1404-06', ('۱۴۰۴','آذر'):'1404-09',
             ('۱۴۰۱','اسفند'):'1401-12', ('۹۹','دی'):'1399-10',
             ('۱۴۰۰','آبان'):'1400-08',
             ('۹۷','آذر'):'1397-09', ('۹۷','دی'):'1397-10',
             ('۹۹','شهریور'):'1399-06', ('۹۹','اسفند'):'1399-12',
             ('۱۴۰۰','شهریور'):'1400-06', ('۱۴۰۰','اسفند'):'1400-12',
             ('۱۴۰۱','شهریور'):'1401-06', ('۱۴۰۲','خرداد'):'1402-03',
             ('۱۴۰۲','شهریور'):'1402-06',
             ('۱۴۰۲','اسفند'):'1402-12', ('۱۴۰۳','شهریور'):'1403-06',
             ('۱۴۰۳','اسفند'):'1403-12'}
lookup = {}
for r in bank:
    t = MONTH2TAG.get((r.get('year'), r.get('exam_month')))
    if t and r.get('key_source'):          # only the newly added records
        lookup[f"{t}:{r['question_no']}"] = r

FIELDS = ('stem_en','options_en','micro','explanation_fa','explanation_en',
          'why_fa','why_en','golden_fa','golden_en','refs')

merged, unknown = 0, []
for f in sorted(glob.glob('/home/user/work/lessons/L*.json')):
    for key, les in json.load(io.open(f, encoding='utf-8')).items():
        rec = lookup.get(key)
        if rec is None:
            unknown.append(key); continue
        for k in FIELDS:
            if k in les:
                # never overwrite the ministry's official English
                if k in ('stem_en','options_en') and rec.get('en_source'):
                    continue
                rec[k] = les[k]
        if les.get('notes_source'):
            rec.setdefault('notes', {})['source_note'] = les['notes_source']
        merged += 1

json.dump(bank, io.open(BANK, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
new_recs = [r for r in bank if r.get('key_source')]
done = sum(1 for r in new_recs if r.get('explanation_fa'))
en   = sum(1 for r in new_recs if r.get('stem_en'))
print(f'merged {merged} lesson(s)')
if unknown:
    print('  unknown keys:', unknown)
print(f'  new questions: {len(new_recs)} | with lesson: {done} | with English: {en}')
