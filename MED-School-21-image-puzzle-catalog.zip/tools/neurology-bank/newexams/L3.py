# -*- coding: utf-8 -*-
"""Micro-lessons, batch 3 — Esfand-1400. stem_en/options_en come from the ministry's
own English booklet, so only the teaching text is authored here."""
import json, io
L = {}

L["1400-12:114"] = {
 "micro": {
  "lead_fa": "پیش‌آگهی ام‌اس را با یک قاعده به یاد بیاورید: هرچه شروع جوان‌تر، زنانه‌تر و حسی‌تر باشد بهتر است؛ شروع حرکتی و مخچه‌ای بدتر.",
  "lead_en": "Recall MS prognosis with one rule: the younger, more female and more sensory the onset, the better; motor and cerebellar onset is worse.",
  "points_fa": [
   "ام‌اس سیر بسیار متغیری دارد و پیش‌بینی آن از همان حمله‌ی اول ممکن است.",
   "عوامل پیش‌آگهی خوب: جنس مؤنث، شروع زیر چهل سال و سیر عودکننده-بهبودیابنده.",
   "شروع با علائم حسی یا نوریت اپتیک هم نشانه‌ی خوبی است.",
   "دلیلش این است که مسیرهای حسی و بینایی ظرفیت ترمیم و جبران بهتری دارند.",
   "عوامل پیش‌آگهی بد: جنس مذکر، شروع بالای چهل سال و سیر پیشرونده از ابتدا.",
   "شروع با علائم مخچه‌ای یا حرکتی هم پیش‌آگهی را بدتر می‌کند.",
   "آتاکسی مخچه‌ای به‌سختی جبران می‌شود و ناتوانی ماندگار می‌گذارد.",
   "بار ضایعات در MRI اولیه و وجود باندهای الیگوکلونال هم ارزش پیش‌بینی دارند.",
   "فاصله‌ی طولانی بین دو حمله‌ی نخست، نشانه‌ی سیر خوش‌خیم‌تر است."
  ],
  "points_en": [
   "MS has a highly variable course, and prediction is possible from the first attack.",
   "Good prognostic factors: female sex, onset under forty, and a relapsing-remitting course.",
   "Onset with sensory symptoms or optic neuritis is also favourable.",
   "The reason is that sensory and visual pathways have better capacity for repair and compensation.",
   "Poor prognostic factors: male sex, onset over forty, and a progressive course from the start.",
   "Onset with cerebellar or motor symptoms also worsens the outlook.",
   "Cerebellar ataxia compensates poorly and leaves lasting disability.",
   "Lesion burden on the initial MRI and the presence of oligoclonal bands also predict.",
   "A long interval between the first two attacks signals a more benign course."
  ]
 },
 "explanation_fa": "برای پاسخ به این سؤال کافی است فهرست عوامل پیش‌آگهی خوب و بد ام‌اس را بشناسید و ببینید کدام گزینه در فهرست بد قرار می‌گیرد. سه گزینه‌ی شروع زیر چهل سالگی، سیر عودکننده-بهبودیابنده و جنس مؤنث همگی از عوامل پیش‌آگهی خوب‌اند. تنها گزینه‌ی باقی‌مانده شروع با علائم مخچه‌ای است که واقعاً نشانه‌ی پیش‌آگهی بد محسوب می‌شود. منطق پشت این تفکیک آموزنده است: مسیرهای حسی و بینایی ظرفیت جبران بالایی دارند و بیمار پس از حمله معمولاً به وضعیت قبلی برمی‌گردد، اما آتاکسی مخچه‌ای و ضعف حرکتی به‌سختی جبران می‌شوند و ناتوانی ماندگار به جا می‌گذارند. توجه کنید که این سؤال در آزمون‌های مختلف با گزینه‌های متفاوت تکرار شده است؛ در نسخه‌ای دیگر «جنس مذکر» کلید بوده است. پس به‌جای حفظ کردن یک پاسخ، کل فهرست را بشناسید.",
 "explanation_en": "This item simply requires knowing the lists of good and bad prognostic factors in MS and spotting which option belongs to the bad list. Onset under forty, a relapsing-remitting course and female sex are all favourable. The only remaining option, onset with cerebellar symptoms, is genuinely a poor prognostic sign. The logic behind the split is instructive: sensory and visual pathways compensate well and the patient usually returns to baseline after an attack, whereas cerebellar ataxia and motor weakness compensate poorly and leave lasting disability. Note that this question recurs across sittings with different option sets; in another version 'male sex' was the key. So learn the whole list rather than memorising one answer.",
 "why_fa": [
  "شروع پیش از چهل سالگی از عوامل پیش‌آگهی خوب است. هرچه بیمار جوان‌تر باشد، ظرفیت ترمیم و پلاستیسیتی مغزش بیشتر است.",
  "پاسخ صحیح — شروع با علائم مخچه‌ای پیش‌آگهی بد است، چون آتاکسی مخچه‌ای به‌سختی جبران می‌شود و ناتوانی ماندگار می‌گذارد.",
  "سیر عودکننده-بهبودیابنده از عوامل پیش‌آگهی خوب است. الگوی نامطلوب، سیر پیشرونده‌ی اولیه بدون دوره‌های بهبود است.",
  "جنس مؤنث پیش‌آگهی بهتری دارد. مردان بیشتر به سمت سیر پیشرونده می‌روند و ناتوانی سریع‌تری پیدا می‌کنند."
 ],
 "why_en": [
  "Onset before forty is a good prognostic factor. The younger the patient, the greater the capacity for repair and plasticity.",
  "Correct — onset with cerebellar symptoms carries a poor prognosis, because cerebellar ataxia compensates poorly and leaves lasting disability.",
  "A relapsing-remitting course is favourable. The unfavourable pattern is primary progressive disease without remissions.",
  "Female sex carries a better prognosis. Men more often follow a progressive course and accrue disability faster."
 ],
 "golden_fa": "خوب: زن، جوان، حسی، عودکننده-بهبودیابنده. بد: مرد، مسن، مخچه‌ای یا حرکتی، پیشرونده.",
 "golden_en": "Good: female, young, sensory, relapsing-remitting. Bad: male, older, cerebellar or motor, progressive.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 6: Multiple sclerosis, prognosis",
  "Confavreux C, Vukusic S. Natural history of multiple sclerosis. Brain 2006;129:606-16"
 ]
}

L["1400-12:115"] = {
 "micro": {
  "lead_fa": "زوال عقل در سال‌های نخست پارکینسون یک پرچم قرمز است و به پارکینسونیسم آتیپیک اشاره می‌کند.",
  "lead_en": "Dementia in the early years of parkinsonism is a red flag pointing to atypical parkinsonism.",
  "points_fa": [
   "سه‌گانه‌ی حرکتی بیماری پارکینسون: برادی‌کینزی، ریژیدیتی و ترمور استراحت.",
   "برادی‌کینزی برای تشخیص الزامی است و باید همراه یکی از دو مورد دیگر باشد.",
   "شروع علائم نامتقارن است و پاسخ خوب به لوودوپا تشخیص را تأیید می‌کند.",
   "زوال عقل در پارکینسون رخ می‌دهد اما معمولاً پس از سال‌ها، نه در ابتدا.",
   "اگر دمانس در سال اول ظاهر شود، تشخیص به سمت دمانس با اجسام لویی می‌رود.",
   "قاعده‌ی یک‌ساله همین است: دمانس پیش از یک سال یعنی لویی بادی، پس از آن یعنی دمانس پارکینسون.",
   "سایر پرچم‌های قرمز: سقوط زودرس، فلج نگاه عمودی و افت فشار وضعیتی شدید.",
   "سقوط زودرس و فلج نگاه عمودی به فلج فوق هسته‌ای پیشرونده اشاره می‌کنند.",
   "اختلال شدید اتونوم زودرس به مالتیپل سیستم آتروفی اشاره می‌کند."
  ],
  "points_en": [
   "The motor triad of Parkinson disease: bradykinesia, rigidity and rest tremor.",
   "Bradykinesia is mandatory for diagnosis and must accompany one of the other two.",
   "Onset is asymmetric, and a good levodopa response supports the diagnosis.",
   "Dementia does occur in Parkinson disease but usually after years, not at the outset.",
   "If dementia appears in the first year, the diagnosis shifts to dementia with Lewy bodies.",
   "That is the one-year rule: dementia before one year means Lewy body, after it means Parkinson disease dementia.",
   "Other red flags: early falls, vertical gaze palsy and severe orthostatic hypotension.",
   "Early falls and vertical gaze palsy point to progressive supranuclear palsy.",
   "Severe early autonomic failure points to multiple system atrophy."
  ]
 },
 "explanation_fa": "این سؤال از شما می‌خواهد ویژگی‌های اصلی پارکینسون را از پرچم‌های قرمز جدا کنید. برادی‌کینزی، ریژیدیتی و ترمور استراحت سه‌گانه‌ی حرکتی خودِ بیماری‌اند و هیچ‌کدام آتیپیک نیستند. اما زوال عقل داستان دیگری دارد. درست است که بیماران پارکینسون در نهایت ممکن است دچار دمانس شوند، اما این معمولاً پس از سال‌ها بیماری حرکتی رخ می‌دهد. اگر دمانس زودهنگام و همزمان با علائم حرکتی ظاهر شود، باید به پارکینسونیسم آتیپیک شک کنید، به‌ویژه دمانس با اجسام لویی. قاعده‌ی عملی که در بالین استفاده می‌شود «قاعده‌ی یک سال» است: اگر دمانس ظرف یک سال از شروع علائم حرکتی بیاید، تشخیص دمانس با اجسام لویی است؛ اگر سال‌ها بعد بیاید، دمانس بیماری پارکینسون نامیده می‌شود.",
 "explanation_en": "This item asks you to separate the core features of Parkinson disease from its red flags. Bradykinesia, rigidity and rest tremor are the disease's own motor triad and none is atypical. Dementia is different. Parkinson patients may eventually become demented, but usually after years of motor disease. If dementia appears early, alongside the motor features, suspect atypical parkinsonism, especially dementia with Lewy bodies. The practical bedside rule is the 'one-year rule': dementia within a year of motor onset means dementia with Lewy bodies; dementia arising years later is called Parkinson disease dementia.",
 "why_fa": [
  "برادی‌کینزی یعنی کندی و کاهش دامنه‌ی حرکات ارادی و برای تشخیص پارکینسون الزامی است. کاملاً تیپیک است.",
  "ریژیدیتی از نوع چرخ‌دنده‌ای یکی از سه علامت اصلی حرکتی پارکینسون است و آتیپیک محسوب نمی‌شود.",
  "ترمور استراحت با فرکانس چهار تا شش هرتز و الگوی حبه‌شماری، شاخص‌ترین علامت پارکینسون است.",
  "پاسخ صحیح — زوال عقل زودرس در پارکینسون آتیپیک است و به تشخیص‌هایی مانند دمانس با اجسام لویی اشاره می‌کند."
 ],
 "why_en": [
  "Bradykinesia means slowness and decrementing amplitude of voluntary movement and is mandatory for the diagnosis. Entirely typical.",
  "Cogwheel rigidity is one of the three core motor features of Parkinson disease and is not atypical.",
  "Rest tremor at four to six hertz with a pill-rolling quality is the most characteristic sign of Parkinson disease.",
  "Correct — early dementia is atypical for Parkinson disease and points to diagnoses such as dementia with Lewy bodies."
 ],
 "golden_fa": "دمانس زودرس در پارکینسونیسم = پرچم قرمز. قاعده‌ی یک سال: زودتر از یک سال یعنی لویی بادی.",
 "golden_en": "Early dementia in parkinsonism = red flag. The one-year rule: earlier than one year means Lewy body.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 11: Parkinsonism and its mimics",
  "Postuma RB et al. MDS clinical diagnostic criteria for Parkinson's disease. Mov Disord 2015;30:1591-1601"
 ]
}

L["1400-12:116"] = {
 "micro": {
  "lead_fa": "زخم تروفیک در سردترین نقاط بدن به‌علاوه‌ی از دست رفتن انتخابی حس درد و حرارت، یعنی جذام لپروماتوز.",
  "lead_en": "Trophic ulcers at the body's coolest sites plus selective loss of pain and temperature mean lepromatous leprosy.",
  "points_fa": [
   "مایکوباکتریوم لپره در دمای پایین‌تر از دمای مرکزی بدن بهتر رشد می‌کند.",
   "پس اعصاب سطحی نواحی سرد را ترجیح می‌دهد: پشت دست، ساعد، گوش، بینی و پا.",
   "همین توزیع، مهم‌ترین سرنخ تشخیصی این بیماری است.",
   "باکتری رشته‌های نازک حس درد و حرارت را زودتر و بیشتر درگیر می‌کند.",
   "رفلکس‌های وتری از رشته‌های ضخیم می‌آیند، پس تا مدت‌ها سالم می‌مانند.",
   "همین تفکیک، الگوی «نوروپاتی رشته‌ی نازک» را می‌سازد.",
   "بیمار درد و حرارت را حس نمی‌کند، پس متوجه سوختگی و زخم نمی‌شود.",
   "نتیجه، زخم‌های تروفیک تکرارشونده و بی‌درد در همان نواحی است.",
   "در معاینه اعصاب محیطی سطحی مانند عصب اولنار و پرونئال ضخیم و قابل لمس‌اند."
  ],
  "points_en": [
   "Mycobacterium leprae grows best below core body temperature.",
   "It therefore favours superficial nerves in cool areas: back of the hands, forearms, ears, nose and feet.",
   "That distribution is the single most useful diagnostic clue.",
   "The organism affects the thin pain and temperature fibres earlier and more severely.",
   "Tendon reflexes travel in thick fibres, so they are preserved for a long time.",
   "This dissociation produces the 'small-fibre neuropathy' pattern.",
   "The patient cannot feel pain or heat, so does not notice burns and wounds.",
   "The result is recurrent, painless trophic ulcers at those same sites.",
   "On examination superficial peripheral nerves such as ulnar and peroneal are thickened and palpable."
  ]
 },
 "explanation_fa": "دو سرنخ این سؤال را حل می‌کند و هر دو به یک مکانیسم برمی‌گردند. سرنخ اول توزیع ضایعات است: پشت دست، ساعد، گوش، بینی و پا. این‌ها دقیقاً سردترین نقاط بدن‌اند و مایکوباکتریوم لپره باکتری‌ای است که دمای پایین را ترجیح می‌دهد، پس اعصاب سطحی همین نواحی را درگیر می‌کند. سرنخ دوم الگوی حسی است: اختلال حس درد و حرارت با حفظ رفلکس‌های وتری. این یعنی رشته‌های نازک درگیر شده‌اند اما رشته‌های ضخیم سالم مانده‌اند، که الگوی نوروپاتی رشته‌ی نازک است. حالا زنجیره را ببندید: بیمار درد را حس نمی‌کند، پس هنگام سوختن یا زخمی شدن متوجه نمی‌شود و آسیب تکرار می‌شود؛ نتیجه‌اش زخم‌های تروفیک بدون درد است. نکته‌ی معاینه‌ای مهم اینکه در جذام، اعصاب محیطی سطحی ضخیم و قابل لمس می‌شوند.",
 "explanation_en": "Two clues solve this item and both trace to one mechanism. The first is the distribution: back of the hands, forearms, ears, nose and feet — precisely the body's coolest sites. Mycobacterium leprae prefers low temperature, so it attacks the superficial nerves of exactly these regions. The second clue is the sensory pattern: impaired pain and temperature with preserved tendon reflexes. That means thin fibres are affected while thick fibres are spared — the small-fibre neuropathy pattern. Now close the chain: the patient cannot feel pain, so does not notice burns or injuries, and the damage repeats; the result is painless trophic ulceration. A useful examination point: in leprosy the superficial peripheral nerves become thickened and palpable.",
 "why_fa": [
  "پاسخ صحیح — توزیع ضایعات در سردترین نقاط بدن به‌علاوه‌ی نوروپاتی رشته‌ی نازک با حفظ رفلکس‌ها، تصویر کلاسیک جذام لپروماتوز است.",
  "نوروپاتی آمیلوئید هم رشته‌های نازک را درگیر می‌کند، اما الگوی توزیعش طول‌وابسته و از پاها به بالاست، نه محدود به نواحی سرد. ضمناً اختلال اتونوم شدید دارد.",
  "نوروپاتی واسکولیتی معمولاً به شکل مونونوریت مولتیپلکس ظاهر می‌شود: درگیری ناگهانی و دردناک اعصاب منفرد، همراه با علائم سیستمیک. الگوی آن با این بیمار نمی‌خواند.",
  "آمیوتروفی دیابتی یک رادیکولوپلکسوپاتی لومبوساکرال است که با درد شدید ران و ضعف پروگزیمال پا ظاهر می‌شود، نه زخم گوش و بینی."
 ],
 "why_en": [
  "Correct — lesions at the body's coolest sites plus a small-fibre neuropathy with preserved reflexes is the classic picture of lepromatous leprosy.",
  "Amyloid neuropathy also affects thin fibres, but its distribution is length-dependent from the feet upward, not confined to cool areas, and it causes severe autonomic failure.",
  "Vasculitic neuropathy usually presents as mononeuritis multiplex: abrupt, painful involvement of individual nerves with systemic features. The pattern does not fit.",
  "Diabetic amyotrophy is a lumbosacral radiculoplexopathy presenting with severe thigh pain and proximal leg weakness, not ulcers of the ear and nose."
 ],
 "golden_fa": "جذام سرما را دوست دارد: گوش، بینی و پشت دست. رشته‌ی نازک می‌رود، رفلکس می‌ماند، زخم بی‌درد می‌آید.",
 "golden_en": "Leprosy loves the cold: ears, nose, backs of hands. Thin fibres go, reflexes stay, painless ulcers follow.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 9: Peripheral neuropathies, leprosy",
  "Adams and Victor's Principles of Neurology, 12th ed — Diseases of the peripheral nerves"
 ]
}
json.dump(L, io.open('/home/user/work/lessons/L3.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('batch 3:', len(L), 'lessons')
