# -*- coding: utf-8 -*-
"""Micro-lessons, batch 13 — Esfand 1403 (completing the bank)."""
import json, io
L = {}

L["1403-12:98"] = {
 "stem_en": "A 65-year-old man is evaluated for recurrent falls. On examination he has bradykinesia and rigidity. He cannot voluntarily look upward. What is the most likely diagnosis?",
 "options_en": ["Huntington disease", "Progressive supranuclear palsy",
                "Dementia with Lewy bodies", "Multiple system atrophy"],
 "micro": {
  "lead_fa": "زمین‌خوردن زودرس به‌علاوه‌ی فلج نگاه عمودی، دو نشانه‌ی تعریف‌کننده‌ی فلج فوق هسته‌ای پیشرونده است.",
  "lead_en": "Early falls plus vertical gaze palsy are the two defining signs of progressive supranuclear palsy.",
  "points_fa": [
   "سندرم‌های پارکینسون‌پلاس بیماری‌هایی هستند که پارکینسونیسم به‌علاوه‌ی چیز دیگر دارند.",
   "همه‌ی آن‌ها پاسخ ضعیفی به لوودوپا می‌دهند و سریع‌تر پیش می‌روند.",
   "فلج فوق هسته‌ای پیشرونده با زمین‌خوردن‌های زودرس به عقب شروع می‌شود.",
   "علامت اختصاصی آن فلج نگاه عمودی است، به‌ویژه نگاه به پایین.",
   "کلمه‌ی فوق هسته‌ای یعنی مشکل بالاتر از هسته‌های حرکتی چشم است.",
   "پس مانور چشم عروسکی حرکت چشم را برمی‌گرداند، چون مسیر رفلکسی سالم است.",
   "مالتیپل سیستم آتروفی با نارسایی اتونوم شدید و آتاکسی مخچه‌ای مشخص می‌شود.",
   "دمانس لوی بادی با نوسان شناختی و توهم بینایی زودرس همراه است.",
   "پارکینسونیسم قرینه و پاسخ ضعیف به لوودوپا در همه‌ی این سندرم‌ها مشترک است."
  ],
  "points_en": [
   "Parkinson-plus syndromes are diseases with parkinsonism plus something else.",
   "All respond poorly to levodopa and progress faster.",
   "Progressive supranuclear palsy begins with early backward falls.",
   "Its specific sign is vertical gaze palsy, especially downgaze.",
   "The word supranuclear means the problem lies above the ocular motor nuclei.",
   "So the doll's eye manoeuvre restores eye movement, because the reflex pathway is intact.",
   "Multiple system atrophy is marked by severe autonomic failure and cerebellar ataxia.",
   "Dementia with Lewy bodies comes with cognitive fluctuation and early visual hallucinations.",
   "Symmetric parkinsonism and a poor levodopa response are shared by all these syndromes."
  ]
 },
 "explanation_fa": "این سؤال دو نشانه‌ی کلیدی را کنار هم می‌گذارد و هر دو به یک تشخیص اشاره دارند. اول زمین‌خوردن‌های مکرر که پیش از هر چیز دیگری آمده‌اند. در بیماری پارکینسون ایدیوپاتیک، زمین‌خوردن آخرین علامتی است که ظاهر می‌شود، پس زمین‌خوردن زودرس یک پرچم قرمز است. دوم ناتوانی در نگاه ارادی به بالا، که یک نشانه‌ی چشمی بسیار اختصاصی است. کلمه‌ی «فوق هسته‌ای» در نام بیماری دقیقاً همین را توضیح می‌دهد: هسته‌های حرکتی چشم سالم‌اند اما فرمان ارادی از بالادست نمی‌رسد. برای اثبات این نکته می‌توانید مانور چشم عروسکی انجام دهید؛ اگر سر بیمار را حرکت دهید، چشم‌ها به‌درستی حرکت می‌کنند چون مسیر رفلکسی از هسته‌ها می‌گذرد و آسیب ندیده است.",
 "explanation_en": "This item places two key signs side by side and both point to one diagnosis. First, recurrent falls, which came before anything else. In idiopathic Parkinson disease falling is the last sign to appear, so early falls are a red flag. Second, inability to look up voluntarily, a highly specific ocular sign. The word supranuclear in the disease name explains exactly this: the ocular motor nuclei are intact but the voluntary command from upstream does not arrive. You can prove the point with the doll's eye manoeuvre. If you move the patient's head, the eyes move correctly. The reflex pathway runs through the nuclei and is undamaged.",
 "why_fa": [
  "هانتینگتون با کره، تغییرات روانی و زوال عقل مشخص می‌شود و سابقه‌ی خانوادگی اتوزومال غالب دارد. فلج نگاه عمودی از ویژگی‌های آن نیست.",
  "پاسخ صحیح — زمین‌خوردن زودرس به‌همراه ناتوانی در نگاه ارادی عمودی، تصویر کلاسیک فلج فوق هسته‌ای پیشرونده است.",
  "دمانس لوی بادی با نوسان شناختی و توهم بینایی زودرس همراه است که هیچ‌کدام در صورت سؤال ذکر نشده‌اند.",
  "مالتیپل سیستم آتروفی با نارسایی اتونوم برجسته مانند افت فشار وضعیتی و اختلال ادراری، یا با آتاکسی مخچه‌ای بروز می‌کند، نه با فلج نگاه عمودی."
 ],
 "why_en": [
  "Huntington disease is marked by chorea, psychiatric change and dementia with an autosomal dominant family history. Vertical gaze palsy is not among its features.",
  "Correct — early falls together with inability to look up voluntarily is the classic picture of progressive supranuclear palsy.",
  "Dementia with Lewy bodies comes with cognitive fluctuation and early visual hallucinations, neither of which the stem mentions.",
  "Multiple system atrophy presents with prominent autonomic failure such as orthostatic hypotension and urinary dysfunction, or with cerebellar ataxia, not with vertical gaze palsy."
 ],
 "golden_fa": "زمین‌خوردن زودرس + فلج نگاه عمودی = PSP. اتونوم شدید = MSA. توهم و نوسان = لوی بادی.",
 "golden_en": "Early falls plus vertical gaze palsy means PSP. Severe autonomic failure means MSA. Hallucinations and fluctuation mean Lewy body.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 11: Progressive supranuclear palsy",
  "Hoglinger GU et al. Clinical diagnosis of progressive supranuclear palsy: MDS criteria. Mov Disord 2017;32:853-64"
 ]
}

L["1403-12:99"] = {
 "stem_en": "A 27-year-old woman develops severe headache a few days after delivery and had a seizure on the morning of admission. Contrast-enhanced brain CT reports an empty delta sign. Which treatment is preferred?",
 "options_en": ["Aspirin", "Heparin", "rtPA", "Conservative"],
 "micro": {
  "lead_fa": "علامت دلتای خالی یعنی لخته در سینوس ساژیتال فوقانی؛ درمان هپارین است.",
  "lead_en": "The empty delta sign means a clot in the superior sagittal sinus; the treatment is heparin.",
  "points_fa": [
   "علامت دلتای خالی در سی‌تی با تزریق ماده‌ی حاجب دیده می‌شود.",
   "دیواره‌ی سینوس ساژیتال فوقانی رنگ می‌گیرد اما مرکز آن به‌خاطر لخته تیره می‌ماند.",
   "این تصویر یک مثلث توخالی می‌سازد و از همین رو دلتای خالی نام گرفته است.",
   "این علامت تقریباً تشخیصی ترومبوز سینوس وریدی مغز است.",
   "دوره‌ی نفاس پرخطرترین زمان برای این عارضه در زنان جوان است.",
   "درمان استاندارد ضدانعقاد با هپارین یا هپارین با وزن مولکولی کم است.",
   "هدف درمان جلوگیری از گسترش لخته و باز شدن مسیر خروجی خون است.",
   "وجود انفارکت خون‌ریزی‌دهنده منع مصرف هپارین نیست.",
   "پس از فاز حاد، وارفارین یا داروی خوراکی مستقیم برای سه تا دوازده ماه ادامه می‌یابد."
  ],
  "points_en": [
   "The empty delta sign is seen on contrast-enhanced CT.",
   "The wall of the superior sagittal sinus enhances while its centre stays dark because of clot.",
   "This produces a hollow triangle, hence the name empty delta.",
   "The sign is nearly diagnostic of cerebral venous sinus thrombosis.",
   "The puerperium is the highest-risk period for this complication in young women.",
   "Standard treatment is anticoagulation with heparin or low molecular weight heparin.",
   "The aim is to stop clot propagation and reopen the venous outflow.",
   "The presence of a haemorrhagic infarct is not a contraindication to heparin.",
   "After the acute phase, warfarin or a direct oral anticoagulant continues for three to twelve months."
  ]
 },
 "explanation_fa": "این سؤال یک علامت رادیولوژیک نام‌دار را می‌آزماید و سپس درمان را می‌پرسد. ابتدا علامت دلتای خالی را بفهمید. وقتی ماده‌ی حاجب تزریق می‌شود، دیواره‌ی سینوس ساژیتال فوقانی که پر از عروق کوچک است رنگ می‌گیرد و روشن می‌شود. اما اگر داخل سینوس لخته باشد، مرکز آن تیره می‌ماند. مقطع عرضی سینوس ساژیتال مثلثی است، پس تصویر نهایی یک مثلث با حاشیه‌ی روشن و مرکز تیره می‌شود که به آن دلتای خالی می‌گویند. زمینه هم کاملاً می‌خواند: چند روز پس از زایمان، سردرد شدید و تشنج. پس تشخیص ترومبوز سینوس وریدی است و درمان استاندارد آن هپارین است. نکته‌ی مهمی که باید بدانید این است که rtPA درمان سکته‌ی ایسکمیک شریانی است و در ترومبوز وریدی درمان خط اول نیست.",
 "explanation_en": "This item tests a named radiological sign and then asks for treatment. First understand the empty delta sign. When contrast is injected, the wall of the superior sagittal sinus, rich in small vessels, enhances and appears bright. But if there is clot inside the sinus, its centre stays dark. The sagittal sinus is triangular in cross-section, so the final image is a triangle with a bright rim and a dark centre, called the empty delta. The setting fits perfectly: a few days postpartum, severe headache and a seizure. So the diagnosis is venous sinus thrombosis and the standard treatment is heparin. An important point to know is that rtPA treats arterial ischaemic stroke and is not first-line for venous thrombosis.",
 "why_fa": [
  "آسپیرین ضدپلاکت است و برای پیشگیری ثانویه‌ی سکته‌ی شریانی کاربرد دارد. لخته‌ی وریدی عمدتاً فیبرینی است و به ضدانعقاد نیاز دارد، نه ضدپلاکت.",
  "پاسخ صحیح — هپارین درمان استاندارد ترومبوز سینوس وریدی است و باید فوراً شروع شود، حتی اگر انفارکت خون‌ریزی‌دهنده وجود داشته باشد.",
  "rtPA برای سکته‌ی ایسکمیک شریانی در پنجره‌ی زمانی مشخص تجویز می‌شود. در ترومبوز وریدی درمان خط اول نیست و فقط در موارد بسیار وخیم مطرح می‌شود.",
  "درمان محافظه‌کارانه در این بیماری خطرناک است، چون لخته گسترش می‌یابد و انفارکت وریدی و افزایش فشار داخل جمجمه بدتر می‌شود."
 ],
 "why_en": [
  "Aspirin is an antiplatelet used for secondary prevention of arterial stroke. Venous clot is mainly fibrin-based and needs anticoagulation rather than antiplatelet therapy.",
  "Correct — heparin is the standard treatment for venous sinus thrombosis and must be started immediately, even with a haemorrhagic infarct.",
  "rtPA is given for arterial ischaemic stroke within a defined time window. It is not first-line for venous thrombosis and is considered only in critical cases.",
  "Conservative management is dangerous here, because the clot propagates and venous infarction and raised intracranial pressure worsen."
 ],
 "golden_fa": "دلتای خالی = ترومبوز سینوس ساژیتال = هپارین فوری.",
 "golden_en": "Empty delta sign means sagittal sinus thrombosis, treated with immediate heparin.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 13: Cerebral venous sinus thrombosis",
  "Ferro JM et al. European Stroke Organisation guideline for cerebral venous thrombosis. Eur J Neurol 2017;24:1203-13"
 ]
}

L["1403-12:100"] = {
 "stem_en": "A 48-year-old woman with multiple sclerosis presents with paresthesia of the right limbs. Her disease began two years ago with right optic neuritis, from which she recovered. Which of the following indicates a poor prognosis in this patient?",
 "options_en": ["Her age", "Her sex", "Her disease course", "Onset with optic neuritis"],
 "micro": {
  "lead_fa": "سن چهل‌وهشت سال هنگام شروع، تنها عامل نامطلوب در این بیمار است.",
  "lead_en": "Onset at forty-eight is the only unfavourable factor in this patient.",
  "points_fa": [
   "برای حل این سؤال باید همه‌ی مشخصات بیمار را یک‌به‌یک بررسی کنید.",
   "این بیمار زن است، که عامل پیش‌آگهی خوب است.",
   "شروع بیماری او با نوریت اپتیک بوده، که عامل پیش‌آگهی خوب است.",
   "او پس از حمله‌ی اول بهبود کامل داشته، که خودش عامل مطلوبی است.",
   "سیر بیماری او عودکننده-بهبودیابنده است، که بهتر از فرم پیشرونده است.",
   "اما بیماری او دو سال پیش شروع شده، یعنی در چهل‌وشش سالگی.",
   "سن بالای چهل سال هنگام شروع، عامل پیش‌آگهی بد است.",
   "در سن بالاتر، ظرفیت ترمیم میلین و انعطاف‌پذیری مغز کمتر است.",
   "شروع دیرهنگام همچنین با احتمال بیشتر تبدیل به فرم پیشرونده‌ی ثانویه همراه است."
  ],
  "points_en": [
   "To solve this you must check each of the patient's characteristics one by one.",
   "This patient is female, which is a good prognostic factor.",
   "Her disease began with optic neuritis, which is a good prognostic factor.",
   "She recovered fully from the first attack, itself a favourable feature.",
   "Her course is relapsing-remitting, better than a progressive form.",
   "But her disease began two years ago, that is at forty-six.",
   "Onset over the age of forty is an adverse prognostic factor.",
   "At an older age, myelin repair capacity and brain plasticity are lower.",
   "Later onset also carries a higher chance of converting to secondary progressive disease."
  ]
 },
 "explanation_fa": "این سؤال روش کار متفاوتی می‌خواهد. به‌جای اینکه یک فهرست کلی از عوامل پیش‌آگهی بپرسد، مشخصات یک بیمار خاص را می‌دهد و می‌خواهد شما آن‌ها را با فهرست تطبیق دهید. پس مشخصات را جدا کنید. جنس: زن، که مطلوب است. شروع بیماری: نوریت اپتیک، که مطلوب است. نتیجه‌ی حمله‌ی اول: بهبودی کامل، که مطلوب است. سیر: دو سال پیش یک حمله و حالا یک حمله‌ی دیگر، پس عودکننده-بهبودیابنده است که نسبت به فرم پیشرونده مطلوب است. تنها چیزی که می‌ماند سن است. بیمار الان چهل‌وهشت ساله است و بیماری از دو سال پیش یعنی چهل‌وشش سالگی شروع شده. شروع بالای چهل سال عامل پیش‌آگهی بد است، پس پاسخ سن بیمار است.",
 "explanation_en": "This item asks for a different working method. Instead of asking for a general list of prognostic factors, it gives one patient's characteristics and wants you to match them against the list. So separate them out. Sex: female, favourable. Disease onset: optic neuritis, favourable. Outcome of the first attack: full recovery, favourable. Course: one attack two years ago and another now, so relapsing-remitting, favourable compared with a progressive form. The only thing left is age. She is now forty-eight and the disease began two years ago at forty-six. Onset over forty is an adverse prognostic factor, so the answer is her age.",
 "why_fa": [
  "پاسخ صحیح — شروع بیماری در چهل‌وشش سالگی یعنی بالای چهل سال، که عامل پیش‌آگهی بد شمرده می‌شود.",
  "جنس مؤنث عامل پیش‌آگهی خوب است. مردان مبتلا به ام‌اس سیر بدتری دارند.",
  "سیر بیماری او عودکننده-بهبودیابنده است که پیش‌آگهی بهتری نسبت به فرم پیشرونده‌ی اولیه دارد.",
  "شروع با نوریت اپتیک از مطلوب‌ترین شروع‌هاست، به‌ویژه وقتی مثل این بیمار بهبودی کامل داشته باشد."
 ],
 "why_en": [
  "Correct — onset at forty-six, that is over forty, is regarded as an adverse prognostic factor.",
  "Female sex is a good prognostic factor. Men with multiple sclerosis follow a worse course.",
  "Her course is relapsing-remitting, which has a better prognosis than the primary progressive form.",
  "Onset with optic neuritis is among the most favourable presentations, especially when, as here, recovery was complete."
 ],
 "golden_fa": "در سؤال «کدام بد است»، همه‌ی مشخصات بیمار را با فهرست خوب و بد تطبیق دهید.",
 "golden_en": "In a which-is-adverse question, match every patient characteristic against the good and bad lists.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 7: Multiple sclerosis, prognosis",
  "Confavreux C, Vukusic S. Natural history of multiple sclerosis. Brain 2006;129:606-16"
 ]
}

L["1403-12:101"] = {
 "stem_en": "A 52-year-old woman presents with muscle weakness for two months. Examination shows skin manifestations: erythema over the extensor surfaces of the finger joints and a violaceous discolouration of the eyelids and cheeks. Proximal limb strength is 4 out of 5. What is the first-line treatment?",
 "options_en": ["Azathioprine", "Corticosteroid", "Intravenous immunoglobulin", "Plasmapheresis"],
 "micro": {
  "lead_fa": "راش هلیوتروپ و پاپول گوترون یعنی درماتومیوزیت و درمان خط اول کورتیکواستروئید است.",
  "lead_en": "Heliotrope rash and Gottron papules mean dermatomyositis, and first-line treatment is a corticosteroid.",
  "points_fa": [
   "درماتومیوزیت میوپاتی التهابی با تظاهرات پوستی مشخص است.",
   "راش هلیوتروپ تغییر رنگ بنفش پلک بالا است و تقریباً تشخیصی است.",
   "پاپول گوترون برجستگی قرمز روی سطح پشتی مفاصل انگشتان است.",
   "این دو یافته‌ی پوستی، درماتومیوزیت را از پلی‌میوزیت جدا می‌کنند.",
   "ضعف عضلانی قرینه و پروگزیمال است و طی هفته‌ها تا ماه‌ها پیش می‌رود.",
   "کراتین کیناز سرم بالا می‌رود و آنتی‌بادی‌های اختصاصی میوزیت مثبت می‌شوند.",
   "درماتومیوزیت در بزرگسالان با بدخیمی همراهی دارد و باید غربالگری شود.",
   "درمان خط اول کورتیکواستروئید با دوز بالا است: پردنیزولون یک میلی‌گرم بر کیلوگرم.",
   "داروهای سرکوب‌کننده‌ی ایمنی مثل آزاتیوپرین یا متوترکسات به‌عنوان صرفه‌جو اضافه می‌شوند."
  ],
  "points_en": [
   "Dermatomyositis is an inflammatory myopathy with characteristic skin features.",
   "The heliotrope rash is a violaceous discolouration of the upper eyelids and is nearly diagnostic.",
   "Gottron papules are red raised lesions over the dorsal surfaces of the finger joints.",
   "These two skin findings separate dermatomyositis from polymyositis.",
   "Muscle weakness is symmetric and proximal, progressing over weeks to months.",
   "Serum creatine kinase rises and myositis-specific antibodies turn positive.",
   "Adult dermatomyositis is associated with malignancy and screening is required.",
   "First-line treatment is high-dose corticosteroid: prednisolone one milligram per kilogram.",
   "Immunosuppressants such as azathioprine or methotrexate are added as steroid-sparing agents."
  ]
 },
 "explanation_fa": "تشخیص این سؤال از دو یافته‌ی پوستی می‌آید که هر دو نام‌دار و اختصاصی‌اند. تغییر رنگ بنفش روی پلک همان راش هلیوتروپ است که نامش را از رنگ گل هلیوتروپ گرفته است. اریتم روی سطوح اکستانسور مفاصل انگشتان همان پاپول گوترون است. این دو با هم به‌علاوه‌ی ضعف پروگزیمال، تشخیص درماتومیوزیت را قطعی می‌کنند. حالا درمان. در بیماری‌های خودایمنی التهابی، منطق درمان همیشه از قوی‌ترین و سریع‌ترین سرکوب‌کننده شروع می‌شود و آن کورتیکواستروئید است. پردنیزولون با دوز یک میلی‌گرم بر کیلوگرم خط اول است. سه گزینه‌ی دیگر جایگاه دارند اما نه در خط اول: آزاتیوپرین صرفه‌جوی استروئید است، ایمونوگلوبولین برای موارد مقاوم یا شدید، و پلاسمافرز اصلاً جایگاه اثبات‌شده‌ای در این بیماری ندارد. یک نکته‌ی حیاتی را هم فراموش نکنید: در بزرگسال مبتلا به درماتومیوزیت باید غربالگری بدخیمی انجام شود.",
 "explanation_en": "The diagnosis here comes from two skin findings, both named and specific. The violaceous discolouration of the eyelids is the heliotrope rash, named after the colour of the heliotrope flower. The erythema over the extensor surfaces of the finger joints is Gottron papules. Together with proximal weakness these settle the diagnosis of dermatomyositis. Now treatment. In inflammatory autoimmune diseases the logic always starts with the strongest and fastest suppressant, which is a corticosteroid. Prednisolone at one milligram per kilogram is first-line. The other three options have roles but not first-line: azathioprine is steroid-sparing, immunoglobulin is for refractory or severe cases, and plasmapheresis has no proven role in this disease at all. And do not forget one vital point: an adult with dermatomyositis needs malignancy screening.",
 "why_fa": [
  "آزاتیوپرین داروی سرکوب‌کننده‌ی ایمنی و صرفه‌جوی استروئید است. معمولاً پس از شروع کورتیکواستروئید اضافه می‌شود تا دوز آن را کم کند، نه به‌جای آن.",
  "پاسخ صحیح — کورتیکواستروئید با دوز بالا خط اول درمان درماتومیوزیت است و باید هرچه زودتر شروع شود.",
  "ایمونوگلوبولین وریدی در موارد مقاوم به استروئید یا بیماری شدید با درگیری بلع مؤثر است، اما درمان خط اول نیست و گران هم هست.",
  "پلاسمافرز در درماتومیوزیت جایگاه اثبات‌شده‌ای ندارد و کارآزمایی‌های کنترل‌شده سودی برای آن نشان نداده‌اند."
 ],
 "why_en": [
  "Azathioprine is an immunosuppressant and steroid-sparing agent. It is usually added after starting a corticosteroid to reduce its dose, not instead of it.",
  "Correct — high-dose corticosteroid is first-line treatment for dermatomyositis and should be started as soon as possible.",
  "Intravenous immunoglobulin helps in steroid-refractory cases or severe disease with swallowing involvement, but it is not first-line and is expensive.",
  "Plasmapheresis has no proven role in dermatomyositis and controlled trials have shown no benefit."
 ],
 "golden_fa": "هلیوتروپ + گوترون = درماتومیوزیت = استروئید خط اول + غربالگری بدخیمی.",
 "golden_en": "Heliotrope plus Gottron means dermatomyositis: steroids first-line plus malignancy screening.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 9: Inflammatory myopathies",
  "Dalakas MC. Inflammatory muscle diseases. N Engl J Med 2015;372:1734-47"
 ]
}

L["1403-12:102"] = {
 "stem_en": "A 20-year-old man is evaluated two months after trauma. He opens his eyes spontaneously but does not speak with those around him and cannot move his limbs voluntarily. He has a normal sleep-wake cycle. Which clinical state does he have?",
 "options_en": ["Vegetative state", "Locked-in syndrome", "Brain death", "Semicoma"],
 "micro": {
  "lead_fa": "چشم باز به‌علاوه‌ی چرخه‌ی خواب طبیعی اما بدون هیچ آگاهی، تعریف حالت رویشی است.",
  "lead_en": "Eyes open with a normal sleep cycle but no awareness at all defines the vegetative state.",
  "points_fa": [
   "هوشیاری دو جزء دارد: بیداری و آگاهی، و این دو می‌توانند از هم جدا شوند.",
   "بیداری کار ساقه‌ی مغز و سیستم فعال‌کننده‌ی مشبک است.",
   "آگاهی کار قشر مغز و ارتباطات آن است.",
   "در کما هر دو از بین می‌روند: چشم بسته است و آگاهی هم نیست.",
   "در حالت رویشی، ساقه سالم است اما قشر به‌شدت آسیب دیده است.",
   "پس بیمار چشم باز می‌کند و چرخه‌ی خواب و بیداری دارد، اما هیچ آگاهی ندارد.",
   "بیمار حرکات هدفمند ندارد و به دستور پاسخ نمی‌دهد.",
   "در سندرم قفل‌شدگی برعکس است: آگاهی کامل ولی خروجی حرکتی قطع شده است.",
   "مرگ مغزی یعنی همه‌ی عملکردهای مغز و ساقه از بین رفته و آپنه‌ی دائمی وجود دارد."
  ],
  "points_en": [
   "Consciousness has two components, wakefulness and awareness, and they can dissociate.",
   "Wakefulness is the work of the brainstem and the reticular activating system.",
   "Awareness is the work of the cerebral cortex and its connections.",
   "In coma both are lost: the eyes are closed and there is no awareness.",
   "In the vegetative state the brainstem is intact but the cortex is severely damaged.",
   "So the patient opens the eyes and has sleep-wake cycles but has no awareness.",
   "There are no purposeful movements and no response to command.",
   "Locked-in syndrome is the opposite: full awareness with the motor output cut off.",
   "Brain death means all brain and brainstem function is lost with permanent apnoea."
  ]
 },
 "explanation_fa": "کلید فهم این سؤال، جدا کردن دو جزء هوشیاری است. بیداری یعنی چشم باز و چرخه‌ی خواب و بیداری، که کار ساقه‌ی مغز است. آگاهی یعنی درک خود و محیط و پاسخ هدفمند، که کار قشر است. حالا بیمار را بررسی کنید. چشم‌ها خودبه‌خود باز می‌شوند و چرخه‌ی خواب طبیعی دارد، پس بیداری حفظ شده و ساقه سالم است. اما با اطرافیان حرف نمی‌زند و حرکت ارادی ندارد، پس آگاهی از بین رفته و قشر آسیب دیده است. این جدایی دقیقاً تعریف حالت رویشی است. برای افتراق از سندرم قفل‌شدگی توجه کنید که در آنجا بیمار کاملاً آگاه است و با حرکت عمودی چشم ارتباط برقرار می‌کند، در حالی که این بیمار هیچ راه ارتباطی ندارد. و مرگ مغزی هم منتفی است چون در مرگ مغزی بیمار چشم باز نمی‌کند و چرخه‌ی خواب ندارد.",
 "explanation_en": "The key to this item is separating the two components of consciousness. Wakefulness means open eyes and sleep-wake cycles, the work of the brainstem. Awareness means perception of self and environment with purposeful responses, the work of the cortex. Now examine the patient. His eyes open spontaneously and his sleep cycle is normal, so wakefulness is preserved and the brainstem is intact. But he does not speak and has no voluntary movement, so awareness is lost and the cortex is damaged. That dissociation is exactly the definition of the vegetative state. To distinguish it from locked-in syndrome, note that there the patient is fully aware and communicates with vertical eye movements, whereas this patient has no channel of communication at all. And brain death is excluded, because in brain death the patient does not open the eyes and has no sleep cycle.",
 "why_fa": [
  "پاسخ صحیح — بیداری حفظ‌شده با چشم باز و چرخه‌ی خواب طبیعی در کنار نبود کامل آگاهی، تعریف حالت رویشی است.",
  "در سندرم قفل‌شدگی بیمار کاملاً هوشیار و آگاه است و با حرکات عمودی چشم و پلک زدن ارتباط برقرار می‌کند. این بیمار هیچ ارتباطی ندارد.",
  "در مرگ مغزی همه‌ی عملکردهای ساقه از بین رفته‌اند، پس بیمار چشم باز نمی‌کند، رفلکس ساقه ندارد و آزمون آپنه مثبت است.",
  "نیمه‌کما اصطلاح قدیمی و مبهمی است که به کاهش نسبی سطح هوشیاری اشاره دارد. حفظ کامل چرخه‌ی خواب و بیداری با آن سازگار نیست."
 ],
 "why_en": [
  "Correct — preserved wakefulness with open eyes and a normal sleep cycle alongside complete absence of awareness defines the vegetative state.",
  "In locked-in syndrome the patient is fully conscious and aware and communicates with vertical eye movements and blinking. This patient has no communication.",
  "In brain death all brainstem functions are lost, so the patient does not open the eyes, has no brainstem reflexes and has a positive apnoea test.",
  "Semicoma is an old and vague term for a partially reduced level of consciousness. A fully preserved sleep-wake cycle does not fit it."
 ],
 "golden_fa": "بیدار ولی ناآگاه = رویشی. آگاه ولی بی‌حرکت = قفل‌شدگی. نه بیدار نه آگاه = کما.",
 "golden_en": "Awake but unaware means vegetative. Aware but immobile means locked-in. Neither awake nor aware means coma.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 4: Disorders of consciousness",
  "Giacino JT et al. Practice guideline update: disorders of consciousness. Neurology 2018;91:450-60"
 ]
}

json.dump(L, io.open('/home/user/work/lessons/L13.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('L13:', len(L))
