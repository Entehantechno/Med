# -*- coding: utf-8 -*-
"""Micro-lessons, batch 14 — Azar 1404, the last sitting held.

English stems and options are NOT written here: they came verbatim from the
ministry's official English booklet and merge_lessons.py must not overwrite them.
"""
import json, io
L = {}

L["1404-09:97"] = {
 "micro": {
  "lead_fa": "آنتی‌بادی میاستنی فقط به گیرنده‌ی نیکوتینی عضله‌ی مخطط حمله می‌کند، پس اتونوم و عضله‌ی صاف سالم می‌مانند.",
  "lead_en": "The myasthenia antibody attacks only the nicotinic receptor of skeletal muscle, so autonomic and smooth muscle are spared.",
  "points_fa": [
   "میاستنی گراویس بیماری خودایمنی محل اتصال عصب و عضله است.",
   "آنتی‌بادی به گیرنده‌ی نیکوتینی استیل‌کولین در صفحه‌ی محرکه حمله می‌کند.",
   "این گیرنده فقط در عضله‌ی مخطط ارادی وجود دارد.",
   "گیرنده‌های اتونوم از نوع موسکارینی و نیکوتینی گانگلیونی‌اند و هدف این آنتی‌بادی نیستند.",
   "پس علائم اتونوم مانند خشکی دهان یا احتباس ادرار در میاستنی دیده نمی‌شود.",
   "عضله‌ی صاف اصلاً صفحه‌ی محرکه‌ی نیکوتینی ندارد و درگیر نمی‌شود.",
   "آتروفی عضلانی رخ نمی‌دهد چون عصب سالم است و دنرواسیون واقعی وجود ندارد.",
   "رفلکس‌های وتری در میاستنی طبیعی می‌مانند و همین آن را از لمبرت-ایتون جدا می‌کند.",
   "در سندرم لمبرت-ایتون رفلکس‌ها کم می‌شوند و علائم اتونوم هم وجود دارد."
  ],
  "points_en": [
   "Myasthenia gravis is an autoimmune disease of the neuromuscular junction.",
   "The antibody attacks the nicotinic acetylcholine receptor at the motor endplate.",
   "That receptor exists only in voluntary skeletal muscle.",
   "Autonomic receptors are muscarinic or ganglionic nicotinic and are not this antibody's target.",
   "So autonomic symptoms such as dry mouth or urinary retention do not occur in myasthenia.",
   "Smooth muscle has no nicotinic endplate at all and is not involved.",
   "Muscle atrophy does not occur because the nerve is intact and there is no true denervation.",
   "Tendon reflexes stay normal in myasthenia, which separates it from Lambert-Eaton syndrome.",
   "In Lambert-Eaton syndrome reflexes are reduced and autonomic features are present."
  ]
 },
 "explanation_fa": "این سؤال تشخیص را رایگان می‌دهد و در عوض می‌خواهد بدانید بیماری دقیقاً چه چیزی را درگیر می‌کند و چه چیزی را نه. پتوز نوسان‌دار با تشدید عصرگاهی و آنتی‌بادی مثبت، یعنی میاستنی گراویس. حالا کلید حل، یک نکته‌ی مولکولی است: آنتی‌بادی به گیرنده‌ی نیکوتینی استیل‌کولین در صفحه‌ی محرکه‌ی عضله‌ی مخطط می‌چسبد و همان‌جا می‌ماند. سیستم اتونوم گیرنده‌ی متفاوتی دارد و عضله‌ی صاف اصلاً صفحه‌ی محرکه‌ی نیکوتینی ندارد، پس هیچ‌کدام درگیر نمی‌شوند. آتروفی هم رخ نمی‌دهد چون عصب سالم است و مشکل فقط در انتقال پیام است. رفلکس‌های وتری هم طبیعی می‌مانند، که تفاوت مهمی با سندرم لمبرت-ایتون است؛ در آن سندرم آنتی‌بادی به کانال کلسیم پیش‌سیناپسی می‌چسبد و هم رفلکس‌ها کم می‌شوند و هم علائم اتونوم پیدا می‌شود.",
 "explanation_en": "This item gives you the diagnosis for free and instead asks what the disease does and does not involve. Fluctuating ptosis worse in the evening with a positive antibody means myasthenia gravis. The key to solving it is one molecular point: the antibody binds the nicotinic acetylcholine receptor at the skeletal muscle endplate and stays there. The autonomic system uses different receptors and smooth muscle has no nicotinic endplate at all, so neither is involved. Atrophy does not occur because the nerve is intact and the problem is purely one of transmission. Tendon reflexes also stay normal, an important contrast with Lambert-Eaton syndrome, where the antibody binds the presynaptic calcium channel and both reflex loss and autonomic features appear.",
 "why_fa": [
  "پاسخ صحیح — آنتی‌بادی فقط گیرنده‌ی نیکوتینی عضله‌ی مخطط را هدف می‌گیرد، پس سیستم اتونوم دست‌نخورده می‌ماند.",
  "نادرست است. عضله‌ی صاف صفحه‌ی محرکه‌ی نیکوتینی ندارد و در میاستنی گراویس درگیر نمی‌شود.",
  "نادرست است. آتروفی عضلانی نیازمند دنرواسیون است، اما در میاستنی عصب سالم است و فقط انتقال پیام مختل شده.",
  "نادرست است. رفلکس‌های وتری در میاستنی طبیعی می‌مانند. کاهش رفلکس نشانه‌ی سندرم لمبرت-ایتون است."
 ],
 "why_en": [
  "Correct — the antibody targets only the skeletal muscle nicotinic receptor, so the autonomic system is left untouched.",
  "False. Smooth muscle has no nicotinic endplate and is not involved in myasthenia gravis.",
  "False. Muscle atrophy requires denervation, but in myasthenia the nerve is intact and only transmission fails.",
  "False. Tendon reflexes stay normal in myasthenia. Reduced reflexes point to Lambert-Eaton syndrome."
 ],
 "golden_fa": "میاستنی: فقط عضله‌ی مخطط. اتونوم سالم، عضله‌ی صاف سالم، رفلکس طبیعی، بدون آتروفی.",
 "golden_en": "Myasthenia hits skeletal muscle only: autonomic spared, smooth muscle spared, reflexes normal, no atrophy.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 9: Myasthenia gravis",
  "Gilhus NE. Myasthenia gravis. N Engl J Med 2016;375:2570-81"
 ]
}

L["1404-09:98"] = {
 "micro": {
  "lead_fa": "پاسخ پلانتار رو به پایین یعنی نورون حرکتی فوقانی سالم است؛ همین سه گزینه‌ی مرکزی را حذف می‌کند.",
  "lead_en": "A downgoing plantar response means the upper motor neuron is intact, which eliminates all three central options.",
  "points_fa": [
   "در هر ضعف حاد، اول تعیین کنید ضایعه مرکزی است یا محیطی.",
   "ضایعه‌ی مرکزی رفلکس‌ها را زیاد و پاسخ پلانتار را رو به بالا (بابینسکی مثبت) می‌کند.",
   "ضایعه‌ی محیطی رفلکس‌ها را کم یا حذف و پاسخ پلانتار را رو به پایین نگه می‌دارد.",
   "این بیمار آرفلکسی و پلانتار رو به پایین دارد، پس ضایعه محیطی است.",
   "گیلن باره پس از یک محرک ایمنی مثل عفونت یا واکسن شروع می‌شود.",
   "ضعف صعودی و قرینه است و از پاها به بالا پیش می‌رود.",
   "معاینه‌ی حسی می‌تواند طبیعی باشد چون فرم شایع عمدتاً حرکتی است.",
   "خطر اصلی نارسایی تنفسی است، پس پایش ظرفیت حیاتی الزامی است.",
   "درمان ایمونوگلوبولین وریدی یا پلاسمافرز است، نه کورتیکواستروئید."
  ],
  "points_en": [
   "In any acute weakness, first decide whether the lesion is central or peripheral.",
   "A central lesion raises reflexes and turns the plantar response upgoing (positive Babinski).",
   "A peripheral lesion reduces or abolishes reflexes and keeps the plantar response downgoing.",
   "This patient has areflexia and downgoing plantars, so the lesion is peripheral.",
   "Guillain-Barre syndrome follows an immune trigger such as an infection or vaccine.",
   "Weakness is ascending and symmetric, progressing upward from the legs.",
   "Sensory examination can be normal because the common form is predominantly motor.",
   "The main danger is respiratory failure, so vital capacity monitoring is mandatory.",
   "Treatment is intravenous immunoglobulin or plasmapheresis, not corticosteroids."
  ]
 },
 "explanation_fa": "این سؤال با یک یافته‌ی کوچک حل می‌شود که خیلی‌ها از آن رد می‌شوند: پاسخ پلانتار دوطرفه رو به پایین است. سه گزینه‌ی دیگر یعنی ام‌اس، سکته‌ی مغزی و میلیت عرضی همگی بیماری‌های نورون حرکتی فوقانی‌اند و اگر هر کدام باعث کوادری‌پارزی شوند، حتماً بابینسکی مثبت و رفلکس‌های زیاد می‌سازند. اما این بیمار دقیقاً برعکس است: رفلکس‌های وتری اصلاً وجود ندارند و پلانتار خم‌کننده است. پس ضایعه محیطی است. حالا بقیه‌ی شرح حال هم می‌خواند: ضعف قرینه و صعودی، شروع طی دو روز، و یک محرک ایمنی واضح یعنی واکسن آنفولانزا. این تصویر کامل سندرم گیلن باره است. نکته‌ی عملی اینکه معاینه‌ی حسی طبیعی تشخیص را رد نمی‌کند، چون فرم شایع این بیماری عمدتاً حرکتی است.",
 "explanation_en": "This item is solved by one small finding that many readers skip: the plantar responses are bilaterally downgoing. The other three options, multiple sclerosis, stroke and transverse myelitis, are all upper motor neuron diseases. If any of them caused quadriparesis, they would give a positive Babinski and brisk reflexes. This patient is exactly the opposite: tendon reflexes are entirely absent and the plantars are flexor. So the lesion is peripheral. The rest of the history now fits: symmetric ascending weakness over two days and a clear immune trigger, the influenza vaccine. That is the complete picture of Guillain-Barre syndrome. A practical point is that a normal sensory examination does not exclude the diagnosis, because the common form is predominantly motor.",
 "why_fa": [
  "پاسخ صحیح — ضعف صعودی قرینه، آرفلکسی، پلانتار رو به پایین و محرک ایمنی اخیر، تصویر کلاسیک سندرم گیلن باره است.",
  "ام‌اس بیماری ماده‌ی سفید مرکزی است و رفلکس‌ها را زیاد و بابینسکی را مثبت می‌کند. ضمناً معمولاً چهار اندام را طی دو روز قرینه نمی‌گیرد.",
  "حمله‌ی عروقی مغز معمولاً یک‌طرفه و ناگهانی است و علائم نورون حرکتی فوقانی می‌دهد، نه آرفلکسی منتشر.",
  "میلیت عرضی سطح حسی مشخص و علائم نورون حرکتی فوقانی زیر آن سطح می‌سازد. حس طبیعی و آرفلکسی با آن سازگار نیست."
 ],
 "why_en": [
  "Correct — symmetric ascending weakness, areflexia, downgoing plantars and a recent immune trigger form the classic picture of Guillain-Barre syndrome.",
  "Multiple sclerosis is a central white matter disease that raises reflexes and gives a positive Babinski. It also rarely affects all four limbs symmetrically over two days.",
  "A cerebrovascular attack is usually unilateral and sudden with upper motor neuron signs, not diffuse areflexia.",
  "Transverse myelitis produces a defined sensory level with upper motor neuron signs below it. Normal sensation with areflexia does not fit."
 ],
 "golden_fa": "پلانتار رو به پایین + آرفلکسی = محیطی. محرک ایمنی + ضعف صعودی = گیلن باره.",
 "golden_en": "Downgoing plantars plus areflexia means peripheral; an immune trigger plus ascending weakness means Guillain-Barre.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 9: Guillain-Barre syndrome",
  "Willison HJ, Jacobs BC, van Doorn PA. Guillain-Barre syndrome. Lancet 2016;388:717-27"
 ]
}

L["1404-09:99"] = {
 "micro": {
  "lead_fa": "هر سردرد یک مکانیسم امضادار دارد؛ حساس‌سازی مرکزی مال سردرد تنشی است.",
  "lead_en": "Each headache has a signature mechanism; central sensitisation belongs to tension headache.",
  "points_fa": [
   "سردرد تنشی شایع‌ترین سردرد اولیه است و دوطرفه و فشارنده احساس می‌شود.",
   "مکانیسم اصلی آن حساس‌سازی مرکزی است، نه گرفتگی ساده‌ی عضله.",
   "حساس‌سازی مرکزی یعنی نورون‌های شاخ خلفی و هسته‌ی تریژمینال بیش‌ازحد تحریک‌پذیر شده‌اند.",
   "نتیجه‌اش پایین آمدن آستانه‌ی درد است؛ محرکی که قبلاً درد نبود حالا درد می‌سازد.",
   "به همین دلیل لمس عضلات پریکرانیال در معاینه دردناک می‌شود.",
   "میگرن مکانیسم دیگری دارد: افسردگی گسترنده‌ی قشری و فعال شدن مسیر تریژمینو-واسکولار.",
   "در میگرن پپتید CGRP آزاد می‌شود و همین هدف داروهای جدید است.",
   "سردرد خوشه‌ای از فعال شدن هیپوتالاموس خلفی و رفلکس تریژمینو-اتونوم می‌آید.",
   "نورالژی تریژمینال مکانیسم محیطی دارد: فشار عروق بر ریشه و شلیک نابجای عصب."
  ],
  "points_en": [
   "Tension headache is the commonest primary headache, felt as bilateral and pressing.",
   "Its main mechanism is central sensitisation, not simple muscle spasm.",
   "Central sensitisation means dorsal horn and trigeminal nucleus neurons have become hyperexcitable.",
   "The result is a lowered pain threshold: a stimulus that was not painful before now hurts.",
   "That is why palpating the pericranial muscles becomes tender on examination.",
   "Migraine has a different mechanism: cortical spreading depression and trigeminovascular activation.",
   "In migraine the peptide CGRP is released, and that is the target of the newer drugs.",
   "Cluster headache arises from posterior hypothalamic activation and the trigeminal-autonomic reflex.",
   "Trigeminal neuralgia has a peripheral mechanism: vascular compression of the root and ectopic firing."
  ]
 },
 "explanation_fa": "این سؤال بر خلاف بیشتر سؤالات سردرد، تصویر بالینی نمی‌دهد و مستقیم سراغ مکانیسم می‌رود. پس باید برای هر سردرد یک مکانیسم امضادار در ذهن داشته باشید. حساس‌سازی مرکزی یعنی نورون‌های مسیر درد در شاخ خلفی و هسته‌ی تریژمینال آن‌قدر تحریک‌پذیر شده‌اند که آستانه‌ی درد پایین می‌آید. این همان مکانیسمی است که امروز برای سردرد تنشی پذیرفته شده است و توضیح می‌دهد چرا در معاینه، لمس ساده‌ی عضلات دور جمجمه برای این بیماران دردناک است. برای سه گزینه‌ی دیگر مکانیسم‌ها کاملاً متفاوت‌اند: میگرن با افسردگی گسترنده‌ی قشری و آزاد شدن CGRP، سردرد خوشه‌ای با فعال شدن هیپوتالاموس خلفی، و نورالژی تریژمینال با فشار عروقی روی ریشه‌ی عصب که یک مکانیسم محیطی است، نه مرکزی.",
 "explanation_en": "Unlike most headache items, this one gives no clinical picture and goes straight to mechanism, so you need a signature mechanism in mind for each headache. Central sensitisation means the pain-pathway neurons in the dorsal horn and trigeminal nucleus have become so excitable that the pain threshold falls. That is the mechanism now accepted for tension headache, and it explains why simply palpating the pericranial muscles is tender in these patients. The mechanisms for the other three are entirely different: migraine through cortical spreading depression and CGRP release, cluster headache through posterior hypothalamic activation, and trigeminal neuralgia through vascular compression of the nerve root, which is a peripheral rather than a central mechanism.",
 "why_fa": [
  "میگرن با افسردگی گسترنده‌ی قشری و فعال شدن مسیر تریژمینو-واسکولار توضیح داده می‌شود. حساس‌سازی مرکزی در میگرن مزمن هم نقش دارد، اما مکانیسم تعریف‌کننده‌ی آن نیست.",
  "سردرد خوشه‌ای از فعال شدن هیپوتالاموس خلفی و رفلکس تریژمینو-اتونوم می‌آید که علائم اتونوم مثل اشک‌ریزش را توضیح می‌دهد.",
  "پاسخ صحیح — سردرد تنشی مکانیسم حساس‌سازی مرکزی دارد که آستانه‌ی درد را پایین می‌آورد و تندرنس عضلات پریکرانیال می‌سازد.",
  "نورالژی تریژمینال مکانیسم محیطی دارد: فشار حلقه‌ی شریان بر ریشه‌ی عصب و تخلیه‌ی الکتریکی نابجا، نه حساس‌سازی مرکزی."
 ],
 "why_en": [
  "Migraine is explained by cortical spreading depression and trigeminovascular activation. Central sensitisation contributes in chronic migraine but is not its defining mechanism.",
  "Cluster headache arises from posterior hypothalamic activation and the trigeminal-autonomic reflex, which explains its autonomic features such as tearing.",
  "Correct — tension headache is driven by central sensitisation, which lowers the pain threshold and produces pericranial muscle tenderness.",
  "Trigeminal neuralgia has a peripheral mechanism: an arterial loop compressing the nerve root with ectopic discharge, not central sensitisation."
 ],
 "golden_fa": "تنشی = حساس‌سازی مرکزی. میگرن = CGRP و تریژمینو-واسکولار. خوشه‌ای = هیپوتالاموس. نورالژی = فشار عروقی.",
 "golden_en": "Tension means central sensitisation, migraine means CGRP and trigeminovascular, cluster means hypothalamus, neuralgia means vascular compression.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 6: Tension-type headache",
  "Bendtsen L. Central sensitization in tension-type headache. Cephalalgia 2000;20:486-508"
 ]
}

L["1404-09:100"] = {
 "micro": {
  "lead_fa": "گفتار روان، درک سالم، ولی تکرار خراب — این ترکیب فقط آفازی کاندکشن است.",
  "lead_en": "Fluent speech, intact comprehension, impaired repetition: that combination is conduction aphasia alone.",
  "points_fa": [
   "برای دسته‌بندی آفازی سه چیز را جدا بسنجید: روانی گفتار، درک، و تکرار.",
   "روانی یعنی بیمار جملات را با طول و آهنگ طبیعی می‌سازد.",
   "درک یعنی بیمار دستورهای شفاهی را می‌فهمد و اجرا می‌کند.",
   "تکرار یعنی بیمار می‌تواند جمله‌ای را که شما گفتید عیناً بازگو کند.",
   "آفازی بروکا: غیرروان، درک سالم، تکرار مختل، ضایعه در لوب فرونتال تحتانی.",
   "آفازی ورنیکه: روان ولی بی‌معنی، درک مختل، تکرار مختل، ضایعه در تمپورال فوقانی خلفی.",
   "آفازی گلوبال: هم گفتار و هم درک و هم تکرار مختل، ضایعه‌ی وسیع.",
   "آفازی کاندکشن: روان، درک سالم، ولی تکرار به‌طور نامتناسب بد است.",
   "علت کاندکشن قطع فاسیکولوس آرکوئات است که ورنیکه را به بروکا وصل می‌کند."
  ],
  "points_en": [
   "To classify aphasia, assess three things separately: fluency, comprehension and repetition.",
   "Fluency means the patient produces sentences of normal length and rhythm.",
   "Comprehension means the patient understands and follows spoken commands.",
   "Repetition means the patient can echo back a sentence you have just said.",
   "Broca aphasia: non-fluent, comprehension intact, repetition impaired, lesion in inferior frontal lobe.",
   "Wernicke aphasia: fluent but meaningless, comprehension impaired, repetition impaired, lesion in posterior superior temporal lobe.",
   "Global aphasia: speech, comprehension and repetition all impaired, from a large lesion.",
   "Conduction aphasia: fluent, comprehension intact, but repetition disproportionately poor.",
   "Conduction aphasia is caused by interruption of the arcuate fasciculus linking Wernicke to Broca."
  ]
 },
 "explanation_fa": "برای این سؤال یک جدول سه‌ستونی در ذهن بسازید و بیمار را در آن بگذارید. ستون اول روانی گفتار: صورت سؤال می‌گوید روان صحبت می‌کند، پس بروکا و گلوبال حذف می‌شوند چون هر دو غیرروان‌اند. ستون دوم درک: می‌گوید درک کلام کاملاً سالم است، پس ورنیکه هم حذف می‌شود چون مشخصه‌اش اختلال درک است. ستون سوم تکرار: می‌گوید بیمار نمی‌تواند کلام پزشک را تکرار کند. حالا فقط یک آفازی می‌ماند که این سه ویژگی را با هم دارد و آن کاندکشن است. توضیح آناتومیک هم روشن است: ناحیه‌ی ورنیکه که درک را می‌سازد سالم است، ناحیه‌ی بروکا که گفتار را می‌سازد هم سالم است، اما دسته‌ی سفیدی که این دو را به هم وصل می‌کند یعنی فاسیکولوس آرکوئات قطع شده است. پس بیمار می‌فهمد و می‌تواند حرف بزند، ولی نمی‌تواند چیزی را که شنیده مستقیم به بخش گویایی منتقل کند.",
 "explanation_en": "Build a three-column table in your head and place the patient in it. Column one, fluency: the stem says he speaks fluently, so Broca and global are out, since both are non-fluent. Column two, comprehension: it says comprehension is entirely intact, so Wernicke is out too, as impaired comprehension defines it. Column three, repetition: he cannot repeat the doctor's speech. Only one aphasia now has all three features, and that is conduction aphasia. The anatomical explanation is clear: Wernicke's area, which builds comprehension, is intact, and Broca's area, which builds speech, is intact, but the white matter bundle joining them, the arcuate fasciculus, is interrupted. So the patient understands and can speak, but cannot relay what he has just heard directly to the speech output region.",
 "why_fa": [
  "آفازی ورنیکه با اختلال درک مشخص می‌شود. اینجا درک کلام کاملاً سالم است، پس این تشخیص رد می‌شود.",
  "آفازی گلوبال یعنی هم گفتار و هم درک به‌شدت مختل باشند. این بیمار روان صحبت می‌کند و می‌فهمد، پس گلوبال نیست.",
  "پاسخ صحیح — گفتار روان، درک سالم و تکرار مختل، سه‌گانه‌ی آفازی کاندکشن است که از قطع فاسیکولوس آرکوئات می‌آید.",
  "آفازی بروکا غیرروان است؛ بیمار با تلاش و جملات کوتاه حرف می‌زند. روان بودن گفتار این بیمار آن را رد می‌کند."
 ],
 "why_en": [
  "Wernicke aphasia is defined by impaired comprehension. Here comprehension is entirely intact, so this is excluded.",
  "Global aphasia means both speech and comprehension are severely impaired. This patient is fluent and understands, so it is not global.",
  "Correct — fluent speech, intact comprehension and impaired repetition are the triad of conduction aphasia, caused by interruption of the arcuate fasciculus.",
  "Broca aphasia is non-fluent; the patient speaks effortfully in short phrases. This patient's fluency excludes it."
 ],
 "golden_fa": "روان + درک سالم + تکرار خراب = کاندکشن = فاسیکولوس آرکوئات.",
 "golden_en": "Fluent plus intact comprehension plus poor repetition equals conduction aphasia from the arcuate fasciculus.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 1: Disorders of language, aphasia",
  "Damasio AR. Aphasia. N Engl J Med 1992;326:531-9"
 ]
}

L["1404-09:101"] = {
 "micro": {
  "lead_fa": "سه قید سؤال — کوتاه، بدون گیجی بعدی، بدون سقوط — هر سه گزینه‌ی دیگر را حذف می‌کند.",
  "lead_en": "The stem's three constraints — brief, no postictal confusion, no fall — eliminate all three other options.",
  "points_fa": [
   "حمله‌ی غیاب قطع ناگهانی هوشیاری است که پنج تا بیست ثانیه طول می‌کشد.",
   "بیمار خیره می‌ماند و به محیط پاسخ نمی‌دهد، ولی نمی‌افتد.",
   "تون عضلانی حفظ می‌شود، پس چیزی از دست بیمار نمی‌افتد.",
   "پس از حمله هیچ گیجی وجود ندارد و بیمار بلافاصله فعالیت را ادامه می‌دهد.",
   "نبود مرحله‌ی گیجی، مهم‌ترین تفاوت با تشنج تونیک-کلونیک است.",
   "تشنج تونیک-کلونیک دقیقه‌ها طول می‌کشد و ده‌ها دقیقه گیجی به جا می‌گذارد.",
   "تشنج آتونیک با از دست رفتن ناگهانی تون و سقوط تعریف می‌شود.",
   "تشنج پارشیال ساده طبق تعریف هوشیاری را حفظ می‌کند.",
   "نوار مغز در غیاب، اسپایک-موج منتشر سه هرتز نشان می‌دهد."
  ],
  "points_en": [
   "An absence attack is a sudden interruption of consciousness lasting five to twenty seconds.",
   "The patient stares and does not respond to the environment, but does not fall.",
   "Muscle tone is preserved, so nothing drops from the patient's hands.",
   "There is no postictal confusion and the patient resumes activity at once.",
   "Absence of a postictal phase is the most important difference from a tonic-clonic seizure.",
   "A tonic-clonic seizure lasts minutes and leaves tens of minutes of confusion.",
   "An atonic seizure is defined by sudden loss of tone and a fall.",
   "A simple partial seizure preserves consciousness by definition.",
   "The EEG in absence shows generalised three-hertz spike-and-wave."
  ]
 },
 "explanation_fa": "این سؤال را می‌توان کاملاً با حذف حل کرد، بدون اینکه اصلاً به گزینه‌ی درست فکر کنید. صورت سؤال سه قید می‌گذارد و هر قید یک گزینه را می‌کشد. قید اول «زیر بیست ثانیه و بدون کانفیوژن پس از حمله» تشنج تونیک-کلونیک ژنرالیزه را حذف می‌کند، چون آن حمله دقیقه‌ها طول می‌کشد و مرحله‌ی گیجی طولانی دارد. قید دوم «بدون سقوط» تشنج آتونیک را حذف می‌کند، چون تعریف آتونیک دقیقاً از دست رفتن ناگهانی تون و افتادن است. قید سوم «اختلال هوشیاری» تشنج پارشیال ساده را حذف می‌کند، چون در پارشیال ساده هوشیاری طبق تعریف حفظ می‌شود و همین آن را از پارشیال کمپلکس جدا می‌کند. تنها گزینه‌ای که هر سه قید را همزمان برآورده می‌کند حمله‌ی غیاب است.",
 "explanation_en": "This item can be solved entirely by elimination without ever thinking about the right answer. The stem sets three constraints and each one kills an option. The first, under twenty seconds with no postictal confusion, eliminates the generalised tonic-clonic seizure, which lasts minutes and has a long confusional phase. The second, no drop, eliminates the atonic seizure, whose very definition is sudden loss of tone with a fall. The third, impaired consciousness, eliminates the simple partial seizure, in which consciousness is preserved by definition, and that is exactly what separates simple from complex partial. The only option satisfying all three constraints at once is the absence attack.",
 "why_fa": [
  "تشنج تونیک-کلونیک ژنرالیزه یک تا سه دقیقه طول می‌کشد، با سقوط همراه است و پس از آن گیجی و خواب‌آلودگی طولانی دارد.",
  "پاسخ صحیح — حمله‌ی غیاب کوتاه است، تون عضلانی را حفظ می‌کند و هیچ مرحله‌ی گیجی پس از حمله ندارد.",
  "تشنج آتونیک با از دست رفتن ناگهانی تون عضلانی و سقوط تعریف می‌شود، که صورت سؤال صریحاً آن را نفی کرده است.",
  "تشنج پارشیال ساده طبق تعریف هوشیاری را حفظ می‌کند، در حالی که سؤال از اختلال هوشیاری صحبت می‌کند."
 ],
 "why_en": [
  "A generalised tonic-clonic seizure lasts one to three minutes, involves a fall and leaves prolonged confusion and drowsiness.",
  "Correct — an absence attack is brief, preserves muscle tone and has no postictal confusion.",
  "An atonic seizure is defined by sudden loss of muscle tone and a fall, which the stem explicitly excludes.",
  "A simple partial seizure preserves consciousness by definition, whereas the stem describes impaired consciousness."
 ],
 "golden_fa": "کوتاه + بدون گیجی + بدون سقوط + هوشیاری مختل = غیاب.",
 "golden_en": "Brief plus no confusion plus no fall plus impaired consciousness equals absence.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 12: Classification of seizures",
  "Fisher RS et al. ILAE operational classification of seizure types. Epilepsia 2017;58:522-30"
 ]
}

L["1404-09:102"] = {
 "micro": {
  "lead_fa": "مردمک مارکوس گان یادگار نوریت اپتیک گذشته است؛ با ضایعه‌ی نخاعی امروز، دو زمان و دو مکان می‌سازد.",
  "lead_en": "A Marcus Gunn pupil is the relic of a past optic neuritis; with today's cord lesion it makes two times and two places.",
  "points_fa": [
   "معیار مک‌دونالد برای تشخیص ام‌اس دو شرط دارد: پراکندگی در مکان و پراکندگی در زمان.",
   "پراکندگی در مکان یعنی حداقل دو ناحیه‌ی متفاوت سیستم عصبی مرکزی درگیر باشند.",
   "پراکندگی در زمان یعنی این درگیری‌ها در دو مقطع زمانی جدا رخ داده باشند.",
   "مردمک مارکوس گان همان نقص آوران نسبی مردمک است.",
   "این نشانه با آزمون تاباندن متناوب نور بین دو چشم آشکار می‌شود.",
   "وجود آن نشان می‌دهد عصب اپتیک همان سمت قبلاً آسیب دیده است.",
   "بابینسکی دوطرفه و بی‌اختیاری ادرار به ضایعه‌ی نخاعی اشاره دارد.",
   "پس این بیمار عصب اپتیک راست (گذشته) و نخاع (حال) را درگیر دارد.",
   "تصویربرداری انتخابی MRI مغز و نخاع با و بدون گادولینیوم است."
  ],
  "points_en": [
   "The McDonald criteria for multiple sclerosis need two things: dissemination in space and in time.",
   "Dissemination in space means at least two different central nervous system regions are involved.",
   "Dissemination in time means those involvements occurred at two separate moments.",
   "The Marcus Gunn pupil is the relative afferent pupillary defect.",
   "It is revealed by the swinging flashlight test between the two eyes.",
   "Its presence shows the optic nerve on that side was previously damaged.",
   "Bilateral Babinski signs and urinary incontinence point to a cord lesion.",
   "So this patient has the right optic nerve (past) and the spinal cord (present) involved.",
   "The imaging of choice is MRI of brain and spinal cord with and without gadolinium."
  ]
 },
 "explanation_fa": "کلید این سؤال شناختن معنای مردمک مارکوس گان است. تاری دید ناگهانی چشم راست که خودبه‌خود بهبود یافت، یک نوریت اپتیک بوده است؛ و مردمک مارکوس گان امروز، اثر باقی‌مانده‌ی همان حمله است، یعنی سند مکتوب آن. حالا بیمار یک ضایعه‌ی تازه هم دارد: پاراپارزی، بی‌اختیاری ادرار و بابینسکی دوطرفه که همگی به نخاع اشاره می‌کنند. پس دو ضایعه در دو مکان جدا و دو زمان جدا داریم، که همان معیار مک‌دونالد و تعریف ام‌اس است. حالا اقدام تشخیصی: MRI مغز و نخاع تنها ابزاری است که هم پلاک‌های مغز و هم ضایعه‌ی نخاع را نشان می‌دهد. سی‌تی اسکن پلاک‌های دمیلینه را اصلاً نمی‌بیند. نوار عصب و عضله برای بیماری محیطی است، در حالی که بابینسکی مثبت صریحاً می‌گوید ضایعه مرکزی است. سی‌تی میلوگرافی هم روش تهاجمی قدیمی است که امروز جای خود را به MRI داده است.",
 "explanation_en": "The key here is knowing what a Marcus Gunn pupil means. The sudden right-eye blurring that resolved on its own was an optic neuritis, and today's Marcus Gunn pupil is the residue of that attack, its written record. The patient now also has a new lesion: paraparesis, urinary incontinence and bilateral Babinski signs, all pointing to the cord. So there are two lesions in two separate places at two separate times, which is the McDonald criterion and the definition of multiple sclerosis. As for the diagnostic step, MRI of brain and spinal cord is the only tool that shows both the brain plaques and the cord lesion. CT cannot see demyelinating plaques at all. Nerve conduction studies are for peripheral disease, whereas the positive Babinski says plainly that the lesion is central. CT myelography is an older invasive technique that MRI has replaced.",
 "why_fa": [
  "سی‌تی‌اسکن بدون کنتراست برای خون‌ریزی حاد و تروما خوب است، اما پلاک‌های دمیلینه را نشان نمی‌دهد و در این بیمار طبیعی خواهد بود.",
  "نوار عصب و عضله اعصاب محیطی را می‌سنجد. بابینسکی دوطرفه نشانه‌ی صریح ضایعه‌ی نورون حرکتی فوقانی است، پس مشکل مرکزی است نه محیطی.",
  "پاسخ صحیح — MRI مغز و نخاع پلاک‌های دمیلینه را در هر دو محل نشان می‌دهد و پراکندگی در مکان و زمان را مستند می‌کند.",
  "سی‌تی میلوگرافی روش تهاجمی و قدیمی است که فقط ساختار کانال نخاعی را نشان می‌دهد. امروز MRI جایگزین آن شده است."
 ],
 "why_en": [
  "Non-contrast CT is good for acute haemorrhage and trauma, but it does not show demyelinating plaques and would be normal in this patient.",
  "Nerve conduction studies assess peripheral nerves. Bilateral Babinski signs plainly indicate an upper motor neuron lesion, so the problem is central, not peripheral.",
  "Correct — MRI of brain and spinal cord shows the demyelinating plaques in both locations and documents dissemination in space and time.",
  "CT myelography is an older invasive technique showing only the spinal canal's structure. MRI has replaced it."
 ],
 "golden_fa": "مارکوس گان = نوریت اپتیک گذشته. آن + ضایعه‌ی نخاعی = دو مکان و دو زمان = ام‌اس = MRI مغز و نخاع.",
 "golden_en": "Marcus Gunn means past optic neuritis. Add a cord lesion and you have two places and two times: multiple sclerosis. Image with MRI of brain and cord.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 7: Multiple sclerosis, diagnosis",
  "Thompson AJ et al. Diagnosis of multiple sclerosis: 2017 revisions of the McDonald criteria. Lancet Neurol 2018;17:162-73"
 ]
}

json.dump(L, io.open('/home/user/work/lessons/L14.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('L14:', len(L))
