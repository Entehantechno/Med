# -*- coding: utf-8 -*-
"""Micro-lessons, batch 16 — Dey-1399 mid-term."""
import json, io
L = {}

L["1399-10:114"] = {
 "stem_en": "Which of the following signs can be seen in ischaemic stroke of BOTH the anterior (carotid) and the posterior (vertebrobasilar) circulation?",
 "options_en": ["Hemianopia", "Hemineglect", "Ataxia", "Peripheral facial nerve palsy"],
 "micro": {
  "lead_fa": "راه بینایی از هر دو قلمرو عبور می‌کند، پس همی‌آنوپی تنها علامت مشترک است.",
  "lead_en": "The visual pathway crosses both territories, so hemianopia is the only shared sign.",
  "points_fa": [
   "راه بینایی طولانی‌ترین مسیر حسی مغز است و از پشت چشم تا قشر اکسیپیتال ادامه دارد.",
   "پس از کیاسما، تراکت بینایی به جسم زانویی جانبی در تالاموس می‌رسد.",
   "از آنجا تشعشع بینایی از میان لوب‌های تمپورال و پاریتال می‌گذرد.",
   "این بخش از مسیر در قلمرو شریان مغزی میانی یعنی گردش قدامی است.",
   "سرانجام مسیر به قشر اکسیپیتال می‌رسد که شریان مغزی خلفی آن را تغذیه می‌کند.",
   "پس ضایعه در هر دو قلمرو می‌تواند همی‌آنوپی هومونیموس بسازد.",
   "همی‌نگلکت از قشر پاریتال غیرغالب می‌آید که کاملاً قدامی است.",
   "آتاکسی از مخچه می‌آید که خونش را از سیستم ورتبروبازیلار می‌گیرد.",
   "فلج محیطی فاسیال از هسته‌ی عصب هفتم در پونز می‌آید که خلفی است."
  ],
  "points_en": [
   "The visual pathway is the brain's longest sensory route, running from behind the eye to occipital cortex.",
   "After the chiasm, the optic tract reaches the lateral geniculate body in the thalamus.",
   "From there the optic radiation passes through the temporal and parietal lobes.",
   "That part of the route lies in middle cerebral artery territory, the anterior circulation.",
   "Finally the pathway reaches occipital cortex, fed by the posterior cerebral artery.",
   "So a lesion in either territory can produce a homonymous hemianopia.",
   "Hemineglect comes from non-dominant parietal cortex, which is entirely anterior.",
   "Ataxia comes from the cerebellum, supplied by the vertebrobasilar system.",
   "Peripheral facial palsy comes from the seventh nerve nucleus in the pons, which is posterior."
  ]
 },
 "explanation_fa": "این سؤال یک اصل آناتومیک زیبا را می‌آزماید: چرا یک علامت می‌تواند به دو قلمرو عروقی تعلق داشته باشد؟ پاسخ در طول مسیر نهفته است. راه بینایی از تالاموس شروع می‌شود، به‌صورت تشعشع بینایی از میان لوب تمپورال و پاریتال می‌گذرد و در قشر اکسیپیتال پایان می‌یابد. بخش میانی این مسیر یعنی تشعشع بینایی در قلمرو شریان مغزی میانی است که از کاروتید می‌آید، اما مقصد نهایی یعنی قشر اکسیپیتال در قلمرو شریان مغزی خلفی است که از سیستم ورتبروبازیلار می‌آید. پس قطع مسیر در هر یک از این دو نقطه همی‌آنوپی هومونیموس می‌سازد. سه گزینه‌ی دیگر هر کدام آدرس منحصربه‌فردی دارند: همی‌نگلکت فقط قدامی، و آتاکسی و فلج محیطی فاسیال فقط خلفی.",
 "explanation_en": "This item tests an elegant anatomical principle: why can one sign belong to two vascular territories? The answer lies in the length of the route. The visual pathway starts at the thalamus, passes as the optic radiation through the temporal and parietal lobes, and ends in occipital cortex. Its middle segment, the optic radiation, lies in middle cerebral artery territory from the carotid. But its final destination, the occipital cortex, is in posterior cerebral artery territory from the vertebrobasilar system. So interrupting the pathway at either point produces a homonymous hemianopia. The other three options each have a unique address: hemineglect only anterior, and ataxia and peripheral facial palsy only posterior.",
 "why_fa": [
  "پاسخ صحیح — راه بینایی هم از قلمرو شریان مغزی میانی (تشعشع بینایی) و هم از قلمرو شریان مغزی خلفی (قشر اکسیپیتال) عبور می‌کند.",
  "همی‌نگلکت از ضایعه‌ی لوب پاریتال غیرغالب می‌آید که در قلمرو شریان مغزی میانی و کاملاً قدامی است.",
  "آتاکسی نشانه‌ی درگیری مخچه یا مسیرهای آن است و مخچه فقط از سیستم ورتبروبازیلار خون می‌گیرد.",
  "فلج محیطی عصب فاسیال از آسیب هسته‌ی عصب هفتم در پونز ناشی می‌شود که در قلمرو خلفی است."
 ],
 "why_en": [
  "Correct — the visual pathway passes through both middle cerebral artery territory (the optic radiation) and posterior cerebral artery territory (the occipital cortex).",
  "Hemineglect arises from a non-dominant parietal lesion in middle cerebral artery territory and is entirely anterior.",
  "Ataxia indicates cerebellar involvement, and the cerebellum is supplied only by the vertebrobasilar system.",
  "Peripheral facial palsy arises from damage to the seventh nerve nucleus in the pons, in the posterior territory."
 ],
 "golden_fa": "راه بینایی طولانی است و از هر دو قلمرو می‌گذرد، پس همی‌آنوپی مشترک است.",
 "golden_en": "The visual pathway is long and crosses both territories, so hemianopia is the shared sign.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 13: Vascular territories",
  "Aminoff MJ et al. Clinical Neurology, 11th ed (2021) — Ch. 7: Disorders of vision, visual field defects"
 ]
}

L["1399-10:115"] = {
 "stem_en": "\"More or less coordinated involuntary movements during or immediately after a seizure, such as scratching, chewing and swallowing, which the patient usually does not remember\" describes which state in epilepsy?",
 "options_en": ["Aura", "Automatism", "Prodromal", "Postictal"],
 "micro": {
  "lead_fa": "اتوماتیسم رفتار هماهنگ ولی بی‌هدف در حالت اختلال آگاهی است که بیمار آن را به یاد نمی‌آورد.",
  "lead_en": "An automatism is coordinated but purposeless behaviour during impaired awareness, which the patient does not recall.",
  "points_fa": [
   "اتوماتیسم حرکت هماهنگ ولی بی‌هدفی است که در حین اختلال آگاهی رخ می‌دهد.",
   "بیمار پس از حمله هیچ خاطره‌ای از انجام آن ندارد؛ همین کلید تشخیص است.",
   "شایع‌ترین شکل آن اورو-بوکال است: جویدن، بلعیدن و ملچ‌ملوچ.",
   "شکل‌های دیگر شامل مالیدن دست، ور رفتن با لباس و راه رفتن بی‌هدف است.",
   "اتوماتیسم بیشتر در تشنج فوکال با اختلال آگاهی و منشأ لوب تمپورال دیده می‌شود.",
   "اورا با آن کاملاً فرق دارد: اورا خودش یک تشنج فوکال آگاهانه است.",
   "چون در اورا آگاهی حفظ است، بیمار آن را به‌خوبی به یاد می‌آورد و توصیف می‌کند.",
   "پرودرومال حالت‌های مبهم مثل تحریک‌پذیری ساعت‌ها تا روزها پیش از حمله است.",
   "پست‌ایکتال دوره‌ی گیجی و خواب‌آلودگی پس از پایان تشنج است."
  ],
  "points_en": [
   "An automatism is a coordinated but purposeless movement occurring during impaired awareness.",
   "The patient has no memory of performing it afterwards, and that is the diagnostic key.",
   "The commonest form is oro-buccal: chewing, swallowing and lip-smacking.",
   "Other forms include hand rubbing, fumbling with clothes and aimless walking.",
   "Automatisms are seen most often in focal seizures with impaired awareness of temporal lobe origin.",
   "An aura is entirely different: an aura is itself a focal aware seizure.",
   "Because awareness is preserved in an aura, the patient remembers and describes it well.",
   "The prodrome is a vague state such as irritability hours to days before the attack.",
   "The postictal phase is the confusion and drowsiness after the seizure ends."
  ]
 },
 "explanation_fa": "برای پاسخ به این سؤال باید چهار اصطلاح مربوط به زمان‌بندی تشنج را از هم جدا کنید و هر کدام یک نشانه‌ی افتراقی دارند. صورت سؤال سه ویژگی داده: حرکات هماهنگ ولی غیرارادی، وقوع حین یا بلافاصله بعد از حمله، و فراموشی. این دقیقاً تعریف اتوماتیسم است. برای اطمینان، بقیه را رد کنید. اورا در واقع خودش یک تشنج فوکال آگاهانه است و مهم‌ترین ویژگی‌اش این است که بیمار آن را کاملاً به یاد می‌آورد و می‌تواند توصیفش کند؛ پس فراموشی آن را رد می‌کند. پرودرومال ساعت‌ها یا روزها پیش از حمله است، نه حین آن. پست‌ایکتال حالت گیجی و خواب‌آلودگی پس از حمله است، نه یک رفتار حرکتی هماهنگ. نکته‌ی بالینی مفید: اتوماتیسم اورو-بوکال قوی‌ترین سرنخ به نفع منشأ لوب تمپورال است.",
 "explanation_en": "To answer this you must separate four terms about seizure timing, each with its own discriminating feature. The stem gives three: coordinated but involuntary movements, occurrence during or right after the attack, and amnesia for it. That is exactly the definition of an automatism. To be sure, exclude the others. An aura is itself a focal aware seizure, and its key feature is that the patient remembers and can describe it, so amnesia rules it out. The prodrome occurs hours or days before, not during. The postictal state is confusion and drowsiness after the seizure, not a coordinated motor behaviour. A useful clinical point: oro-buccal automatisms are the strongest clue to a temporal lobe origin.",
 "why_fa": [
  "اورا در واقع یک تشنج فوکال آگاهانه است و بیمار آن را کاملاً به یاد می‌آورد. فراموشی ذکرشده در سؤال با آن سازگار نیست.",
  "پاسخ صحیح — اتوماتیسم حرکت هماهنگ ولی بی‌هدف در حالت اختلال آگاهی است و بیمار آن را به یاد نمی‌آورد.",
  "حالت پرودرومال ساعت‌ها تا روزها پیش از حمله رخ می‌دهد و شامل تغییرات مبهم خلقی است، نه حرکات حین حمله.",
  "پست‌ایکتال دوره‌ی پس از حمله با گیجی و خواب‌آلودگی است. خود این دوره یک رفتار حرکتی هماهنگ محسوب نمی‌شود."
 ],
 "why_en": [
  "An aura is in fact a focal aware seizure and the patient remembers it completely. The amnesia described in the stem does not fit.",
  "Correct — an automatism is coordinated but purposeless movement during impaired awareness, which the patient does not recall.",
  "The prodromal state occurs hours to days before the attack and consists of vague mood changes, not movements during the seizure.",
  "The postictal phase is the period after the seizure with confusion and drowsiness. It is not itself a coordinated motor behaviour."
 ],
 "golden_fa": "اتوماتیسم = حرکت هماهنگ + آگاهی مختل + فراموشی. اورا = آگاه و به‌یادماندنی.",
 "golden_en": "Automatism means coordinated movement plus impaired awareness plus amnesia; an aura is aware and remembered.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 12: Focal seizures and automatisms",
  "Fisher RS et al. ILAE operational classification of seizure types. Epilepsia 2017;58:522-30"
 ]
}

L["1399-10:116"] = {
 "stem_en": "Which of the following is correct about myasthenia gravis?",
 "options_en": ["It has an age restriction and is commoner in men",
                "Cranial muscle involvement is the commonest presenting feature",
                "Smooth muscle involvement and reduced tendon reflexes are present",
                "Anti-acetylcholine receptor antibody is positive in all generalised myasthenia patients"],
 "micro": {
  "lead_fa": "بیش از نیمی از بیماران با پتوز و دوبینی شروع می‌کنند، پس درگیری کرانیال شایع‌ترین تظاهر آغازین است.",
  "lead_en": "Over half of patients begin with ptosis and diplopia, so cranial involvement is the commonest presenting feature.",
  "points_fa": [
   "میاستنی گراویس توزیع سنی دوقله‌ای دارد، نه محدودیت سنی.",
   "قله‌ی اول زنان بیست تا چهل ساله و قله‌ی دوم مردان بالای شصت سال است.",
   "پس در مجموع نمی‌توان گفت در آقایان شایع‌تر است.",
   "بیش از پنجاه درصد بیماران با علائم چشمی شروع می‌کنند: پتوز و دوبینی.",
   "درگیری بولبار مثل اختلال بلع و تکلم هم از تظاهرات کرانیال شایع است.",
   "عضله‌ی صاف گیرنده‌ی نیکوتینی صفحه‌ی محرکه ندارد، پس درگیر نمی‌شود.",
   "رفلکس‌های وتری در میاستنی طبیعی می‌مانند؛ کاهش آن‌ها به لمبرت-ایتون اشاره دارد.",
   "آنتی‌بادی ضد گیرنده در حدود هشتاد و پنج درصد فرم عمومی مثبت است، نه صد درصد.",
   "بیماران سرونگاتیو اغلب آنتی‌بادی ضد MuSK یا LRP4 دارند."
  ],
  "points_en": [
   "Myasthenia gravis has a bimodal age distribution, not an age restriction.",
   "The first peak is women aged twenty to forty and the second is men over sixty.",
   "So overall it cannot be said to be commoner in men.",
   "Over fifty percent of patients begin with ocular symptoms: ptosis and diplopia.",
   "Bulbar involvement such as swallowing and speech difficulty is another common cranial presentation.",
   "Smooth muscle has no nicotinic endplate receptor and is not involved.",
   "Tendon reflexes stay normal in myasthenia; their reduction points to Lambert-Eaton.",
   "The anti-receptor antibody is positive in about eighty-five percent of generalised cases, not all.",
   "Seronegative patients often carry anti-MuSK or anti-LRP4 antibodies."
  ]
 },
 "explanation_fa": "این سؤال چهار ادعا می‌دهد و می‌خواهد درست را بیابید، پس باید هر چهار را جداگانه بسنجید. ادعای اول دو خطا دارد: میاستنی محدودیت سنی ندارد بلکه توزیع دوقله‌ای دارد، و در مجموع در زنان کمی شایع‌تر است نه مردان. ادعای سوم هم دو خطا دارد: عضله‌ی صاف گیرنده‌ی نیکوتینی صفحه‌ی محرکه ندارد پس درگیر نمی‌شود، و رفلکس‌های وتری در میاستنی طبیعی می‌مانند؛ اگر رفلکس کم شده بود باید به سندرم لمبرت-ایتون فکر کرد. ادعای چهارم روی کلمه‌ی «تمام» می‌لغزد. آنتی‌بادی ضد گیرنده در حدود هشتاد و پنج درصد فرم عمومی مثبت است. پس منفی بودن آن تشخیص را رد نمی‌کند و باید آنتی‌بادی ضد MuSK را هم چک کرد. می‌ماند ادعای دوم که درست است: بیش از نیمی از بیماران با پتوز و دوبینی شروع می‌کنند.",
 "explanation_en": "This item offers four claims and asks for the true one, so each must be weighed separately. The first has two errors: myasthenia has no age restriction but a bimodal distribution, and overall it is slightly commoner in women, not men. The third also has two errors: smooth muscle has no nicotinic endplate receptor and is not involved. And tendon reflexes stay normal in myasthenia. Reduced reflexes should make you think of Lambert-Eaton syndrome. The fourth trips on the word all: the anti-receptor antibody is positive in about eighty-five percent of generalised cases. So a negative result does not exclude the diagnosis and anti-MuSK should also be checked. That leaves the second, which is true: over half of patients begin with ptosis and diplopia.",
 "why_fa": [
  "نادرست است. میاستنی توزیع سنی دوقله‌ای دارد و محدودیت سنی ندارد؛ ضمناً در مجموع در زنان کمی شایع‌تر است.",
  "پاسخ صحیح — بیش از پنجاه درصد بیماران با علائم چشمی یعنی پتوز و دوبینی شروع می‌کنند، که تظاهر کرانیال است.",
  "نادرست است. عضله‌ی صاف صفحه‌ی محرکه‌ی نیکوتینی ندارد و رفلکس‌های وتری در میاستنی طبیعی می‌مانند.",
  "نادرست است. آنتی‌بادی ضد گیرنده در حدود هشتاد و پنج درصد فرم عمومی مثبت است، نه در تمام بیماران."
 ],
 "why_en": [
  "False. Myasthenia has a bimodal age distribution with no age restriction, and overall it is slightly commoner in women.",
  "Correct — over fifty percent of patients begin with ocular symptoms, ptosis and diplopia, which are cranial features.",
  "False. Smooth muscle has no nicotinic endplate and tendon reflexes stay normal in myasthenia.",
  "False. The anti-receptor antibody is positive in about eighty-five percent of generalised cases, not in all patients."
 ],
 "golden_fa": "میاستنی: دوقله‌ای، شروع چشمی، رفلکس طبیعی، آنتی‌بادی ۸۵ درصد نه ۱۰۰ درصد.",
 "golden_en": "Myasthenia: bimodal, ocular onset, normal reflexes, antibody positive in 85 percent not 100.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 9: Myasthenia gravis",
  "Gilhus NE. Myasthenia gravis. N Engl J Med 2016;375:2570-81"
 ]
}

L["1399-10:117"] = {
 "stem_en": "A patient with reduced consciousness was found in the street and brought to hospital by ambulance. There is no companion and no sign of trauma. After stabilising the patient's general condition, which action do you prioritise as an emergency?",
 "options_en": ["Intravenous injection of 25 g dextrose solution", "Brain CT scan",
                "Electrocardiography", "Urine and blood toxicology screening"],
 "micro": {
  "lead_fa": "هیپوگلیسمی هم شایع است، هم در ثانیه‌ها قابل تشخیص، و هم ظرف دقایق آسیب دائمی می‌سازد.",
  "lead_en": "Hypoglycaemia is common, diagnosable in seconds, and causes permanent damage within minutes.",
  "points_fa": [
   "در کمای با علت نامعلوم، اقدامات فوری بر اساس سرعت آسیب اولویت‌بندی می‌شوند.",
   "مغز ذخیره‌ی گلوکز ندارد و کاملاً به عرضه‌ی لحظه‌ای وابسته است.",
   "پس هیپوگلیسمی ظرف دقایق می‌تواند آسیب نورونی برگشت‌ناپذیر بسازد.",
   "قند انگشتی در چند ثانیه انجام می‌شود و ارزان‌ترین آزمون بالینی است.",
   "اگر امکان اندازه‌گیری فوری نبود، باید دکستروز تجربی تزریق شود.",
   "در بیمار مشکوک به سوءتغذیه یا الکلیسم باید تیامین پیش از گلوکز داده شود.",
   "دلیلش پیشگیری از انسفالوپاتی ورنیکه است که با بار گلوکز تسریع می‌شود.",
   "پس از قند، ارزیابی راه هوایی و علائم حیاتی و سپس معاینه‌ی عصبی می‌آید.",
   "تصویربرداری و سم‌شناسی مراحل بعدی‌اند و فوریت دقیقه‌ای ندارند."
  ],
  "points_en": [
   "In coma of unknown cause, urgent actions are prioritised by how fast damage occurs.",
   "The brain stores no glucose and depends entirely on moment-to-moment supply.",
   "So hypoglycaemia can cause irreversible neuronal injury within minutes.",
   "A fingerstick glucose takes seconds and is the cheapest bedside test there is.",
   "If immediate measurement is impossible, empirical dextrose must be given.",
   "In a patient suspected of malnutrition or alcoholism, thiamine must precede glucose.",
   "The reason is to prevent Wernicke encephalopathy, which a glucose load can precipitate.",
   "After glucose come airway and vital sign assessment, then the neurological examination.",
   "Imaging and toxicology are later steps without minute-by-minute urgency."
  ]
 },
 "explanation_fa": "در اورژانس، اولویت‌بندی بر اساس این است که کدام مشکل سریع‌تر آسیب دائمی می‌سازد و کدام سریع‌تر قابل رفع است. هیپوگلیسمی در هر دو معیار برنده است. مغز هیچ ذخیره‌ی گلوکزی ندارد، پس افت قند ظرف دقایق نورون‌ها را می‌کشد؛ در مقابل تشخیص آن با یک قطره خون و چند ثانیه ممکن است و درمانش یک تزریق ساده است. پس در هر بیمار با کاهش هوشیاری و علت نامعلوم، قند خون اولین چیزی است که باید بررسی یا تجربی درمان شود. سه گزینه‌ی دیگر همگی در جای خود لازم‌اند اما هیچ‌کدام این فوریت دقیقه‌ای را ندارند. یک نکته‌ی ایمنی حیاتی را هم به خاطر بسپارید: در بیمار مشکوک به سوءتغذیه یا مصرف الکل، باید تیامین را پیش از گلوکز داد، وگرنه بار گلوکز می‌تواند انسفالوپاتی ورنیکه را تسریع کند.",
 "explanation_en": "In emergencies, priority is set by which problem causes permanent damage fastest and which is fixed fastest. Hypoglycaemia wins on both counts. The brain has no glucose store, so a fall in glucose kills neurons within minutes. Meanwhile it is diagnosed with one drop of blood in seconds and treated with a simple injection. So in any patient with reduced consciousness of unknown cause, blood glucose is the first thing to check or treat empirically. The other three options are all necessary in their place but none carries this minute-by-minute urgency. Remember one vital safety point: in a patient suspected of malnutrition or alcohol use, thiamine must be given before glucose, otherwise the glucose load can precipitate Wernicke encephalopathy.",
 "why_fa": [
  "پاسخ صحیح — هیپوگلیسمی شایع‌ترین علت قابل درمان فوری کاهش هوشیاری است و تأخیر در آن آسیب برگشت‌ناپذیر می‌سازد.",
  "سی‌تی‌اسکن مغزی برای رد خون‌ریزی و ضایعه‌ی فضاگیر لازم است، اما پس از اطمینان از قند خون و پایداری بیمار انجام می‌شود.",
  "الکتروکاردیوگرافی برای بررسی آریتمی و ایسکمی مفید است، ولی اولویت اول در کمای با علت نامعلوم نیست.",
  "غربالگری سم‌شناسی در تشخیص مسمومیت کمک‌کننده است اما نتیجه‌اش زمان می‌برد و درمان فوری را هدایت نمی‌کند."
 ],
 "why_en": [
  "Correct — hypoglycaemia is the commonest immediately treatable cause of reduced consciousness and delay causes irreversible damage.",
  "Brain CT is needed to exclude haemorrhage and mass lesions, but it comes after confirming glucose and stabilising the patient.",
  "Electrocardiography helps assess arrhythmia and ischaemia, but it is not the first priority in coma of unknown cause.",
  "Toxicology screening helps diagnose poisoning, but results take time and do not guide immediate treatment."
 ],
 "golden_fa": "کمای نامعلوم: اول قند خون. در مشکوک به سوءتغذیه، تیامین پیش از گلوکز.",
 "golden_en": "Coma of unknown cause: glucose first. In suspected malnutrition, thiamine before glucose.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 4: Approach to the comatose patient",
  "Edlow JA et al. Diagnosis of reversible causes of coma. Lancet 2014;384:2064-76"
 ]
}

L["1399-10:118"] = {
 "stem_en": "A 30-year-old man presents with unilateral headaches behind the right orbit accompanied by tearing, conjunctival redness and nasal congestion, beginning two weeks ago. The headache recurs at least three times a day and each attack lasts about an hour on average. He has had similar headaches in previous years with the same history, which resolved after a few weeks. Which is the preferred treatment in the acute phase?",
 "options_en": ["Dexamethasone 8 mg intramuscularly", "Intravenous ketorolac",
                "One hundred percent oxygen for 10 minutes", "Indomethacin 100 mg suppository"],
 "micro": {
  "lead_fa": "اکسیژن صددرصد در سردرد خوشه‌ای هم سریع اثر می‌کند و هم هیچ عارضه‌ای ندارد.",
  "lead_en": "One hundred percent oxygen works fast in cluster headache and has no adverse effects at all.",
  "points_fa": [
   "سردرد خوشه‌ای شدیدترین سردرد شناخته‌شده است و در مردان جوان شایع‌تر است.",
   "درد یک‌طرفه و پشت چشم است و هرگز سمت عوض نمی‌کند.",
   "هر حمله پانزده دقیقه تا سه ساعت طول می‌کشد و روزی چند بار تکرار می‌شود.",
   "علائم اتونوم همان سمت جزو تعریف است: اشک‌ریزش، قرمزی چشم، آبریزش بینی.",
   "الگوی خوشه‌ای یعنی دوره‌های چندهفته‌ای که با فاصله‌ی ماه‌ها یا سال‌ها تکرار می‌شوند.",
   "درمان حمله دو گزینه دارد: اکسیژن صددرصد و سوماتریپتان زیرجلدی.",
   "اکسیژن با ماسک بدون بازدم مجدد و جریان ۱۲ تا ۱۵ لیتر در دقیقه داده می‌شود.",
   "این کار در حدود هفتاد درصد بیماران ظرف پانزده دقیقه حمله را قطع می‌کند.",
   "وراپامیل داروی پیشگیری است و کورتیکواستروئید فقط پل زدن تا اثر آن است."
  ],
  "points_en": [
   "Cluster headache is the most severe headache known and is commoner in young men.",
   "The pain is unilateral and behind the eye and never switches sides.",
   "Each attack lasts fifteen minutes to three hours and recurs several times a day.",
   "Ipsilateral autonomic features are part of the definition: tearing, conjunctival redness, rhinorrhoea.",
   "The cluster pattern means bouts of several weeks recurring after months or years.",
   "Acute treatment has two options: one hundred percent oxygen and subcutaneous sumatriptan.",
   "Oxygen is given by non-rebreather mask at twelve to fifteen litres a minute.",
   "This aborts the attack within fifteen minutes in about seventy percent of patients.",
   "Verapamil is the preventive drug and corticosteroids only bridge until it takes effect."
  ]
 },
 "explanation_fa": "تشخیص از پنج سرنخ صورت سؤال قطعی است: مرد جوان، درد یک‌طرفه پشت چشم، علائم اتونوم همان سمت، حملات کوتاه و مکرر روزانه، و الگوی خوشه‌ای که سال‌های قبل هم تکرار شده. این سردرد خوشه‌ای است. حالا نکته‌ی کلیدی سؤال: تفاوت درمان حمله و درمان پیشگیری. اکسیژن صددرصد یکی از دو درمان استاندارد حمله‌ی حاد است؛ مکانیسمش انقباض عروق مغزی و مهار فعالیت مسیر تریژمینال است و در حدود هفتاد درصد بیماران ظرف پانزده دقیقه حمله را قطع می‌کند، آن هم بدون هیچ عارضه‌ای. دگزامتازون فقط برای پل زدن تا اثر داروی پیشگیری مثل وراپامیل استفاده می‌شود و حمله‌ی در جریان را قطع نمی‌کند. کتورولاک برای دردی به این شدت کند و ناکافی است. ایندومتاسین پاسخ اختصاصی در همی‌کرانیای حمله‌ای دارد، نه در سردرد خوشه‌ای.",
 "explanation_en": "The diagnosis is certain from five clues in the stem: a young man, unilateral retro-orbital pain, ipsilateral autonomic features, short attacks recurring several times daily. And a cluster pattern that recurred in previous years. This is cluster headache. Now the key point: the difference between abortive and preventive treatment. One hundred percent oxygen is one of the two standard acute treatments. It works by cerebral vasoconstriction and inhibiting trigeminal activity, aborting the attack within fifteen minutes in about seventy percent of patients, with no adverse effects at all. Dexamethasone is used only to bridge until a preventive such as verapamil takes effect and does not abort an attack in progress. Ketorolac is too slow and weak for pain this severe. Indomethacin gives a specific response in paroxysmal hemicrania, not in cluster headache.",
 "why_fa": [
  "دگزامتازون برای پل زدن تا اثر داروی پیشگیری در دوره‌ی خوشه‌ای به کار می‌رود، اما حمله‌ی در جریان را قطع نمی‌کند.",
  "کتورولاک یک NSAID تزریقی است و برای دردی با این شدت و سرعت اوج‌گیری، کند و ناکافی است.",
  "پاسخ صحیح — اکسیژن صددرصد با ماسک بدون بازدم مجدد در حدود هفتاد درصد بیماران ظرف پانزده دقیقه حمله را قطع می‌کند و بی‌عارضه است.",
  "ایندومتاسین پاسخ اختصاصی و تشخیصی در همی‌کرانیای حمله‌ای و همی‌کرانیا کانتینوآ دارد، نه در سردرد خوشه‌ای."
 ],
 "why_en": [
  "Dexamethasone is used to bridge until a preventive takes effect during a cluster bout, but it does not abort an attack in progress.",
  "Ketorolac is an injectable NSAID and is too slow and weak for pain of this severity and rapidity.",
  "Correct — one hundred percent oxygen by non-rebreather mask aborts the attack within fifteen minutes in about seventy percent of patients, with no adverse effects.",
  "Indomethacin gives a specific diagnostic response in paroxysmal hemicrania and hemicrania continua, not in cluster headache."
 ],
 "golden_fa": "سردرد خوشه‌ای: حمله = اکسیژن یا سوماتریپتان زیرجلدی. پیشگیری = وراپامیل.",
 "golden_en": "Cluster headache: abort with oxygen or subcutaneous sumatriptan; prevent with verapamil.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 6: Cluster headache management",
  "Cohen AS, Burns B, Goadsby PJ. High-flow oxygen for treatment of cluster headache. JAMA 2009;302:2451-7"
 ]
}

L["1399-10:119"] = {
 "stem_en": "A patient with multiple sclerosis experiences an electric shock sensation in the limbs on flexing the neck. This sign indicates what?",
 "options_en": ["Cervical cord injury", "Active occipital plaques",
                "Multiple brainstem involvement", "Thoracic cord injury"],
 "micro": {
  "lead_fa": "محرک علامت لرمیت خم کردن گردن است، پس ضایعه باید در نخاع گردنی باشد.",
  "lead_en": "The trigger for Lhermitte sign is neck flexion, so the lesion must be in the cervical cord.",
  "points_fa": [
   "علامت لرمیت احساس شوک برقی است که با خم کردن گردن ایجاد می‌شود.",
   "این احساس از پشت گردن به سمت پایین و اندام‌ها می‌دود.",
   "مکانیسم آن مکانیکی است: خم شدن گردن نخاع گردنی را می‌کشد.",
   "آکسون‌های دمیلینه‌ی ستون خلفی در برابر این کشش بسیار حساس‌اند.",
   "کشش باعث تخلیه‌ی الکتریکی نابجا و خودبه‌خودی این آکسون‌ها می‌شود.",
   "چون محرک خم شدن گردن است، محل پلاک هم باید گردنی باشد.",
   "این علامت اختصاصی ام‌اس نیست و در چند بیماری دیگر هم دیده می‌شود.",
   "کمبود ویتامین B12، اسپوندیلوز گردنی و آسیب پس از رادیوتراپی از علل دیگرند.",
   "در معاینه با خم کردن فعال گردن به سمت جلو آزموده می‌شود."
  ],
  "points_en": [
   "Lhermitte sign is an electric shock sensation produced by flexing the neck.",
   "The sensation runs from the back of the neck down into the limbs.",
   "The mechanism is mechanical: neck flexion stretches the cervical cord.",
   "Demyelinated posterior column axons are highly sensitive to that stretch.",
   "The stretch triggers ectopic spontaneous discharge in those axons.",
   "Because the trigger is neck flexion, the plaque must be cervical.",
   "The sign is not specific to multiple sclerosis and occurs in several other conditions.",
   "Vitamin B12 deficiency, cervical spondylosis and post-radiation injury are other causes.",
   "It is tested by actively flexing the neck forward during examination."
  ]
 },
 "explanation_fa": "این علامت را می‌توان کاملاً از روی مکانیک آن استدلال کرد، بدون حفظ کردن. وقتی گردن را خم می‌کنید، کانال نخاعی گردنی بلندتر می‌شود و نخاع داخل آن کشیده می‌شود. حالا اگر آکسون‌های ستون خلفی نخاع گردنی غلاف میلین خود را از دست داده باشند، در برابر این کشش مکانیکی بسیار تحریک‌پذیر می‌شوند و تخلیه‌ی الکتریکی نابجا می‌کنند. مغز این تخلیه را به‌صورت شوک برقی در امتداد اندام‌ها تفسیر می‌کند. نکته‌ی کلیدی همین‌جاست: چون حرکتی که علامت را راه می‌اندازد خم کردن گردن است، محل ضایعه هم باید همان جایی باشد که با این حرکت کشیده می‌شود، یعنی نخاع گردنی. پلاک اکسیپیتال یا ساقه‌ی مغز با خم کردن گردن کشیده نمی‌شوند و نخاع توراسیک هم تحت تأثیر این حرکت نیست. یک نکته‌ی مهم بالینی: این علامت اختصاصی ام‌اس نیست و در کمبود B12 و اسپوندیلوز گردنی هم دیده می‌شود.",
 "explanation_en": "This sign can be reasoned out entirely from its mechanics without memorising. When you flex the neck, the cervical spinal canal lengthens and the cord inside it is stretched. If the posterior column axons of the cervical cord have lost their myelin sheath, they become highly excitable to that mechanical stretch and fire ectopically. The brain interprets that discharge as an electric shock running down the limbs. Here is the key point: because the movement that triggers the sign is neck flexion, the lesion must lie where that movement stretches, namely the cervical cord. An occipital or brainstem plaque is not stretched by neck flexion, and the thoracic cord is unaffected by it. One important clinical note: the sign is not specific to multiple sclerosis and also occurs in B12 deficiency and cervical spondylosis.",
 "why_fa": [
  "پاسخ صحیح — خم کردن گردن نخاع گردنی را می‌کشد و آکسون‌های دمیلینه‌ی ستون خلفی همان‌جا تخلیه‌ی نابجا می‌کنند.",
  "پلاک‌های اکسیپیتال روی بینایی اثر می‌گذارند و با خم کردن گردن کشیده نمی‌شوند، پس علامت لرمیت نمی‌سازند.",
  "درگیری ساقه‌ی مغز علائمی مثل دوبینی، سرگیجه و دیزآرتری می‌دهد، نه شوک برقی وابسته به حرکت گردن.",
  "نخاع توراسیک با خم کردن گردن کشیده نمی‌شود. محرک مکانیکی این علامت اختصاصاً ناحیه‌ی گردنی را درگیر می‌کند."
 ],
 "why_en": [
  "Correct — neck flexion stretches the cervical cord and the demyelinated posterior column axons there fire ectopically.",
  "Occipital plaques affect vision and are not stretched by neck flexion, so they cannot produce Lhermitte sign.",
  "Brainstem involvement gives diplopia, vertigo and dysarthria, not a neck-movement-dependent electric shock.",
  "The thoracic cord is not stretched by neck flexion. The mechanical trigger of this sign specifically involves the cervical region."
 ],
 "golden_fa": "لرمیت = کشش نخاع گردنی = پلاک ستون خلفی گردنی. اختصاصی ام‌اس نیست.",
 "golden_en": "Lhermitte means cervical cord stretch and a posterior column cervical plaque; it is not specific to multiple sclerosis.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 7: Multiple sclerosis, clinical signs",
  "Aminoff MJ et al. Clinical Neurology, 11th ed (2021) — Ch. 10: Spinal cord syndromes"
 ]
}

L["1399-10:120"] = {
 "stem_en": "Which of the following types of dementia is reversible?",
 "options_en": ["Frontotemporal dementia", "Alzheimer disease",
                "Normal pressure hydrocephalus", "Vascular dementia"],
 "micro": {
  "lead_fa": "هیدروسفالی با فشار طبیعی با شانت درمان‌پذیر است، پس تنها دمانس برگشت‌پذیر این فهرست است.",
  "lead_en": "Normal pressure hydrocephalus is treatable with a shunt, so it is the only reversible dementia here.",
  "points_fa": [
   "حدود پنج تا ده درصد دمانس‌ها علت قابل برگشت دارند و ارزش جستجو دارند.",
   "علل قابل برگشت: کمبود B12، کم‌کاری تیروئید، نوروسیفلیس، افسردگی و هیدروسفالی.",
   "هیدروسفالی با فشار طبیعی سه‌گانه‌ی مشخصی دارد که باید حفظ باشد.",
   "این سه‌گانه: اختلال راه رفتن، بی‌اختیاری ادرار و زوال شناختی.",
   "راه رفتن مغناطیسی است، یعنی پاها انگار به زمین چسبیده‌اند.",
   "اختلال راه رفتن معمولاً اولین علامت و بهترین پاسخ‌دهنده به درمان است.",
   "بطن‌ها گشاد می‌شوند بدون آنکه فشار مایع نخاعی به‌طور پایدار بالا باشد.",
   "آزمون تپ یعنی برداشتن مایع نخاعی، ارزش تشخیصی و پیش‌بینی پاسخ به شانت دارد.",
   "درمان قطعی شانت بطنی-صفاقی است که می‌تواند علائم را چشمگیر بهتر کند."
  ],
  "points_en": [
   "About five to ten percent of dementias have a reversible cause and are worth seeking.",
   "Reversible causes: B12 deficiency, hypothyroidism, neurosyphilis, depression and hydrocephalus.",
   "Normal pressure hydrocephalus has a distinct triad worth memorising.",
   "The triad: gait disturbance, urinary incontinence and cognitive decline.",
   "The gait is magnetic, as though the feet are stuck to the floor.",
   "Gait disturbance is usually the first symptom and responds best to treatment.",
   "The ventricles enlarge without the CSF pressure being persistently raised.",
   "The tap test, removing CSF, has diagnostic value and predicts shunt response.",
   "Definitive treatment is a ventriculoperitoneal shunt, which can improve symptoms markedly."
  ]
 },
 "explanation_fa": "این سؤال یک اصل بالینی مهم را می‌آزماید: در هر بیمار دمانس باید علل قابل برگشت را جستجو کرد، چون گرچه کم‌شمارند، از دست دادنشان یعنی محروم کردن بیمار از درمان. سه گزینه‌ی دیگر همگی برگشت‌ناپذیرند: آلزایمر و دمانس فرونتوتمپورال بیماری‌های دژنراتیو با تجمع پروتئین‌های غیرطبیعی‌اند و دمانس عروقی نتیجه‌ی انفارکت‌های تجمع‌یافته است که بافت از دست رفته برنمی‌گردد. اما هیدروسفالی با فشار طبیعی متفاوت است؛ در آن مشکل اصلی اختلال جذب مایع نخاعی و گشاد شدن بطن‌هاست، نه مرگ نورون. پس اگر با شانت بطنی-صفاقی مایع اضافه تخلیه شود، فشار روی بافت مغز برداشته می‌شود و علائم می‌توانند به‌طور چشمگیر بهتر شوند. سه‌گانه‌ی آن را با یک جمله به یاد بسپارید: راه رفتن مغناطیسی، بی‌اختیاری ادرار و فراموشی.",
 "explanation_en": "This item tests an important clinical principle: in every dementia patient, reversible causes must be sought, because although few, missing them deprives the patient of treatment. The other three options are all irreversible: Alzheimer and frontotemporal dementia are degenerative diseases with abnormal protein accumulation. And vascular dementia results from accumulated infarcts where the lost tissue does not return. Normal pressure hydrocephalus is different; there the core problem is impaired CSF absorption and ventricular enlargement, not neuronal death. So if a ventriculoperitoneal shunt drains the excess fluid, pressure on brain tissue is relieved and symptoms can improve markedly. Remember its triad in one phrase: magnetic gait, urinary incontinence and forgetfulness.",
 "why_fa": [
  "دمانس فرونتوتمپورال یک بیماری دژنراتیو با تجمع پروتئین تاو یا TDP-43 است و برگشت‌پذیر نیست.",
  "بیماری آلزایمر با تجمع پلاک آمیلوئید و کلاف‌های نوروفیبریلاری و مرگ نورونی همراه است و درمان قطعی ندارد.",
  "پاسخ صحیح — هیدروسفالی با فشار طبیعی با شانت بطنی-صفاقی قابل درمان است و علائم می‌توانند چشمگیر بهتر شوند.",
  "دمانس عروقی از انفارکت‌های تجمع‌یافته می‌آید. می‌توان از پیشرفت آن پیشگیری کرد اما آسیب موجود برگشت‌پذیر نیست."
 ],
 "why_en": [
  "Frontotemporal dementia is a degenerative disease with tau or TDP-43 accumulation and is not reversible.",
  "Alzheimer disease involves amyloid plaques, neurofibrillary tangles and neuronal death, with no definitive cure.",
  "Correct — normal pressure hydrocephalus is treatable with a ventriculoperitoneal shunt and symptoms can improve markedly.",
  "Vascular dementia arises from accumulated infarcts. Progression can be prevented but existing damage is not reversible."
 ],
 "golden_fa": "دمانس برگشت‌پذیر: هیدروسفالی فشار طبیعی، B12، تیروئید، سیفلیس، افسردگی.",
 "golden_en": "Reversible dementias: normal pressure hydrocephalus, B12, thyroid, syphilis and depression.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 5: Reversible dementias",
  "Williams MA, Malm J. Diagnosis and treatment of idiopathic normal pressure hydrocephalus. Continuum 2016;22:579-99"
 ]
}

L["1399-10:121"] = {
 "stem_en": "A teacher reports that recently, whenever she intends to write, her hand adopts an abnormal posture. She also has difficulty with other fine tasks such as buttoning clothes. Where do you refer her?",
 "options_en": ["Endocrinologist to assess for parathyroid disorders",
                "Psychiatrist for psychotherapy",
                "Neurologist for botulinum toxin injection",
                "Physiotherapy centre for physiotherapy"],
 "micro": {
  "lead_fa": "دیستونی وابسته به تکلیف یک اختلال حرکتی واقعی است و درمان انتخابی آن سم بوتولینوم است.",
  "lead_en": "Task-specific dystonia is a genuine movement disorder and its treatment of choice is botulinum toxin.",
  "points_fa": [
   "دیستونی انقباض هم‌زمان عضلات موافق و مخالف است که وضعیت غیرطبیعی می‌سازد.",
   "دیستونی کانونی فقط یک ناحیه‌ی بدن را درگیر می‌کند.",
   "کرامپ نویسندگان شکل وابسته به تکلیف دیستونی دست است.",
   "ویژگی کلیدی آن وابستگی به تکلیف است: فقط هنگام نوشتن ظاهر می‌شود.",
   "در حالت استراحت و در بسیاری از کارهای دیگر دست کاملاً طبیعی است.",
   "همین ویژگی در گذشته باعث می‌شد به‌اشتباه آن را روان‌زاد بدانند.",
   "امروز می‌دانیم اختلال در پردازش حسی-حرکتی عقده‌های قاعده‌ای علت آن است.",
   "درمان انتخابی تزریق موضعی سم بوتولینوم در عضلات درگیر است.",
   "سم بوتولینوم آزادسازی استیل‌کولین در صفحه‌ی محرکه را مسدود می‌کند."
  ],
  "points_en": [
   "Dystonia is simultaneous contraction of agonist and antagonist muscles producing an abnormal posture.",
   "Focal dystonia involves only one body region.",
   "Writer's cramp is the task-specific form of hand dystonia.",
   "Its key feature is task specificity: it appears only during writing.",
   "At rest and during many other activities the hand is entirely normal.",
   "That very feature once led to it being wrongly considered psychogenic.",
   "We now know it results from abnormal sensorimotor processing in the basal ganglia.",
   "Treatment of choice is local botulinum toxin injection into the affected muscles.",
   "Botulinum toxin blocks acetylcholine release at the motor endplate."
  ]
 },
 "explanation_fa": "کلید این سؤال شناختن مفهوم «وابستگی به تکلیف» است. دست بیمار در حالت عادی طبیعی است، اما به‌محض شروع نوشتن به وضعیت غیرطبیعی می‌رود. این الگو مشخصه‌ی دیستونی کانونی وابسته به تکلیف است که به آن کرامپ نویسندگان می‌گویند. نکته‌ی مهم آموزشی این است که در گذشته همین ویژگی عجیب باعث می‌شد پزشکان آن را مشکلی روانی بدانند و بیمار را به روان‌پزشک بفرستند؛ اما امروز می‌دانیم علت آن اختلال در پردازش حسی-حرکتی در عقده‌های قاعده‌ای است و یک بیماری نورولوژیک تمام‌عیار است. درمان انتخابی تزریق موضعی سم بوتولینوم در عضلات درگیر است که با مسدود کردن آزادسازی استیل‌کولین، انقباض بیش‌ازحد را کاهش می‌دهد. اختلال پاراتیروئید هیپوکلسمی و تتانی می‌سازد که دوطرفه و مستقل از تکلیف است، پس با این تصویر نمی‌خواند.",
 "explanation_en": "The key here is recognising task specificity. The patient's hand is normal ordinarily, but the moment she starts writing it adopts an abnormal posture. That pattern characterises task-specific focal dystonia, known as writer's cramp. An important teaching point is that this very peculiarity once led doctors to consider it psychological and refer patients to psychiatry. We now know it results from abnormal sensorimotor processing in the basal ganglia and is a fully neurological disease. Treatment of choice is local botulinum toxin injection into the affected muscles, which reduces excessive contraction by blocking acetylcholine release. A parathyroid disorder would cause hypocalcaemia and tetany, which is bilateral and independent of task, so it does not fit this picture.",
 "why_fa": [
  "اختلال پاراتیروئید با هیپوکلسمی و تتانی تظاهر می‌کند که دوطرفه و مستقل از نوع فعالیت است، نه وابسته به تکلیف نوشتن.",
  "ارجاع به روان‌پزشک خطای کلاسیک در این بیماری است. وابستگی به تکلیف عجیب به نظر می‌رسد اما منشأ آن عقده‌های قاعده‌ای است، نه روان.",
  "پاسخ صحیح — تزریق موضعی سم بوتولینوم درمان انتخابی دیستونی کانونی است و با مسدود کردن انتقال عصبی-عضلانی انقباض را کم می‌کند.",
  "فیزیوتراپی و بازآموزی حرکتی نقش کمکی دارند اما به‌تنهایی درمان اصلی دیستونی کانونی محسوب نمی‌شوند."
 ],
 "why_en": [
  "A parathyroid disorder presents with hypocalcaemia and tetany, which is bilateral and independent of activity, not specific to writing.",
  "Referral to psychiatry is the classic error in this condition. Task specificity seems odd but the origin is the basal ganglia, not the mind.",
  "Correct — local botulinum toxin injection is the treatment of choice for focal dystonia, reducing contraction by blocking neuromuscular transmission.",
  "Physiotherapy and motor retraining have a supporting role but are not the primary treatment for focal dystonia alone."
 ],
 "golden_fa": "دست فقط هنگام نوشتن خراب می‌شود = دیستونی وابسته به تکلیف = سم بوتولینوم، نه روان‌درمانی.",
 "golden_en": "A hand that fails only when writing means task-specific dystonia: botulinum toxin, not psychotherapy.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 11: Focal dystonia",
  "Albanese A et al. Phenomenology and classification of dystonia: a consensus update. Mov Disord 2013;28:863-73"
 ]
}

json.dump(L, io.open('/home/user/work/lessons/L16.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('L16:', len(L))
