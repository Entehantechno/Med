# -*- coding: utf-8 -*-
"""Micro-lessons, batch 7 — Shahrivar-1404, the last main sitting held."""
import json, io
L = {}

L["1404-06:91"] = {
 "stem_en": "A 28-year-old woman on oral contraceptives for the past month presents with headache and seizures. Brain MRI shows a 'two adjacent beans' appearance in the thalami. Which diagnosis and which vessel are most likely?",
 "options_en": ["Cerebral venous thrombosis (CVT) — deep cerebral vein",
                "Acute ischaemic stroke (AIS) — basilar artery",
                "Cerebral venous thrombosis (CVT) — superior sagittal sinus",
                "Acute ischaemic stroke (AIS) — posterior cerebral artery"],
 "micro": {
  "lead_fa": "ادم متقارن دو تالاموس یعنی ترومبوز سیستم وریدی عمقی مغز، و OCP یکی از قوی‌ترین محرک‌های آن است.",
  "lead_en": "Symmetric oedema of both thalami means deep cerebral venous thrombosis, and the pill is one of its strongest triggers.",
  "points_fa": [
   "سیستم وریدی عمقی مغز شامل ورید مغزی داخلی، ورید بازال و ورید بزرگ گالن است.",
   "این سیستم خون تالاموس، هسته‌های قاعده‌ای و ماده‌ی سفید عمقی را تخلیه می‌کند.",
   "چون هر دو تالاموس به یک سیستم می‌ریزند، انسدادش ادم متقارن دوطرفه می‌سازد.",
   "همین تقارن، نمای «دو لوبیای به هم چسبیده» را در MRI می‌سازد.",
   "درگیری تالاموس دوطرفه علت‌های محدودی دارد و این یکی از مهم‌ترین‌هاست.",
   "قرص ضد بارداری خطر ترومبوز وریدی مغز را چند برابر می‌کند.",
   "سایر عوامل خطر: بارداری و نفاس، کم‌آبی، ترومبوفیلی و عفونت.",
   "درمان ضدانعقاد است، حتی اگر انفارکت وریدی خون‌ریزی‌دار شده باشد.",
   "علت این استثنا آن است که خون‌ریزی نتیجه‌ی احتقان است و با باز شدن سینوس برطرف می‌شود."
  ],
  "points_en": [
   "The deep cerebral venous system comprises the internal cerebral veins, basal veins and the great vein of Galen.",
   "It drains the thalami, basal ganglia and deep white matter.",
   "Because both thalami drain into one system, its occlusion causes symmetric bilateral oedema.",
   "That symmetry produces the 'two adjacent beans' appearance on MRI.",
   "Bilateral thalamic involvement has few causes, and this is among the most important.",
   "Oral contraceptives multiply the risk of cerebral venous thrombosis.",
   "Other risk factors: pregnancy and the puerperium, dehydration, thrombophilia and infection.",
   "Treatment is anticoagulation, even when the venous infarct has become haemorrhagic.",
   "That exception holds because the bleeding results from congestion and resolves once the sinus opens."
  ]
 },
 "explanation_fa": "دو سرنخ این سؤال را حل می‌کنند. سرنخ اول تصویربرداری است: نمای «دو لوبیای به هم چسبیده» در تالاموس یعنی هر دو تالاموس متقارن دچار ادم شده‌اند. حالا بپرسید کدام رگ خون هر دو تالاموس را می‌برد. پاسخ سیستم وریدی عمقی است، یعنی وریدهای مغزی داخلی و ورید بزرگ گالن. چون این سیستم مشترک است، انسدادش ضایعه‌ی متقارن دوطرفه می‌سازد؛ چیزی که در انسداد شریانی به‌ندرت دیده می‌شود. سرنخ دوم مصرف قرص ضد بارداری است که یکی از قوی‌ترین عوامل خطر ترومبوز وریدی مغز محسوب می‌شود. سردرد و تشنج هم با همین تشخیص می‌خوانند، چون افزایش فشار وریدی و ادم قشری هر دو تشنج‌زا هستند. اگر سینوس ساژیتال فوقانی درگیر بود، ضایعه در نواحی پاراساژیتال دیده می‌شد نه تالاموس.",
 "explanation_en": "Two clues solve this item. The first is the imaging: a 'two adjacent beans' appearance in the thalami means both thalami are symmetrically oedematous. Now ask which vessel drains both. The answer is the deep venous system — the internal cerebral veins and the great vein of Galen. Because that system is shared, its occlusion produces a symmetric bilateral lesion, something arterial occlusion rarely does. The second clue is the oral contraceptive, one of the strongest risk factors for cerebral venous thrombosis. Headache and seizures fit too, since raised venous pressure and cortical oedema are both epileptogenic. Had the superior sagittal sinus been involved, the lesion would sit in parasagittal regions rather than the thalami.",
 "why_fa": [
  "پاسخ صحیح — ادم متقارن دو تالاموس یعنی انسداد سیستم وریدی عمقی که خون هر دو تالاموس را می‌برد. مصرف OCP هم عامل خطر کلاسیک این تشخیص است.",
  "انسداد شریان بازیلار ساقه‌ی مغز و مخچه را درگیر می‌کند و معمولاً با کاهش شدید هوشیاری و علائم متقاطع ساقه ظاهر می‌شود، نه ادم متقارن تالاموس در یک زن جوان.",
  "ترومبوز سینوس ساژیتال فوقانی درست است که شایع‌ترین محل CVT است، اما ضایعه‌اش در نواحی پاراساژیتال و کورتکس دیده می‌شود نه در تالاموس دوطرفه.",
  "شریان مغزی خلفی لوب اکسیپیتال و بخشی از تالاموس را خون می‌دهد، اما انسداد آن یک‌طرفه است و همیانوپی می‌سازد. ضایعه‌ی متقارن دوطرفه با آن نمی‌خواند."
 ],
 "why_en": [
  "Correct — symmetric oedema of both thalami means occlusion of the deep venous system that drains them both. The pill is the classic risk factor.",
  "Basilar occlusion affects the brainstem and cerebellum, usually with markedly reduced consciousness and crossed brainstem signs, not symmetric thalamic oedema in a young woman.",
  "Superior sagittal sinus thrombosis is indeed the commonest site of CVT, but its lesions lie in parasagittal cortex rather than in both thalami.",
  "The posterior cerebral artery supplies the occipital lobe and part of the thalamus, but its occlusion is unilateral and causes hemianopia. A symmetric bilateral lesion does not fit."
 ],
 "golden_fa": "تالاموس دوطرفه متقارن = وریدهای عمقی. قرص ضد بارداری + سردرد + تشنج = تا خلافش ثابت نشده CVT.",
 "golden_en": "Symmetric bilateral thalami = deep veins. The pill + headache + seizure = CVT until proven otherwise.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 13: Cerebral venous thrombosis",
  "Saposnik G et al. Diagnosis and management of cerebral venous thrombosis: AHA/ASA statement. Stroke 2011;42:1158-92"
 ]
}

L["1404-06:92"] = {
 "stem_en": "A young man with childhood-onset epilepsy stops taking phenytoin and develops repeated generalised tonic-clonic seizures without regaining consciousness between them. What is the correct first treatment step?",
 "options_en": ["Start intravenous phenytoin in a drip",
                "Give intravenous diazepam and start phenytoin in normal saline",
                "Rapid intubation and start intravenous midazolam",
                "Insert a nasogastric tube and gavage high-dose phenytoin"],
 "micro": {
  "lead_fa": "حالت صرعی دو گام پشت‌سرهم دارد: اول بنزودیازپین برای قطع سریع، بعد داروی طولانی‌اثر برای جلوگیری از بازگشت.",
  "lead_en": "Status epilepticus needs two consecutive steps: a benzodiazepine to stop it fast, then a long-acting drug to stop it returning.",
  "points_fa": [
   "حملات مکرر بدون بازگشت هوشیاری در فواصل، تعریف حالت صرعی است.",
   "قطع ناگهانی داروی ضد تشنج یکی از شایع‌ترین محرک‌های آن است.",
   "هر دقیقه تأخیر مهم است، چون گیرنده‌های گابا از غشا برداشته می‌شوند.",
   "با ادامه‌ی تشنج، بنزودیازپین کم‌اثرتر می‌شود؛ به آن مقاومت وابسته به زمان می‌گویند.",
   "پس گام اول همیشه بنزودیازپین وریدی است: لورازپام یا دیازپام.",
   "اما بنزودیازپین اثر کوتاهی دارد و به‌تنهایی کافی نیست.",
   "بلافاصله باید داروی طولانی‌اثر شروع شود تا حمله برنگردد.",
   "فنی‌توئین، فوس‌فنی‌توئین، والپروات و لوتیراستام همگی برای این گام مناسب‌اند.",
   "اینتوباسیون و بیهوشی با میدازولام یا پروپوفول برای حالت صرعی مقاوم نگه داشته می‌شود."
  ],
  "points_en": [
   "Repeated seizures without recovery between them define status epilepticus.",
   "Abrupt withdrawal of an anticonvulsant is one of its commonest triggers.",
   "Every minute counts, because GABA receptors are internalised from the membrane.",
   "As the seizure continues the benzodiazepine loses potency — time-dependent pharmacoresistance.",
   "So the first step is always an intravenous benzodiazepine: lorazepam or diazepam.",
   "But a benzodiazepine is short-acting and not enough on its own.",
   "A long-acting agent must follow immediately to prevent recurrence.",
   "Phenytoin, fosphenytoin, valproate and levetiracetam all suit this second step.",
   "Intubation and anaesthesia with midazolam or propofol are reserved for refractory status."
  ]
 },
 "explanation_fa": "کلمه‌ی «اولین» در صورت سؤال تعیین‌کننده است. ابتدا تشخیص را قطعی کنید: حملات مکرر تونیک-کلونیک بدون بازگشت هوشیاری در فواصل، یعنی حالت صرعی. علتش هم روشن است، قطع خودسرانه‌ی فنی‌توئین. حالا الگوریتم درمان را به یاد بیاورید که دو گام پشت‌سرهم دارد. گام اول بنزودیازپین وریدی است، چون سریع‌ترین اثر را دارد و هر دقیقه تأخیر کار را سخت‌تر می‌کند؛ با ادامه‌ی تشنج گیرنده‌های گابا از سطح غشا برداشته می‌شوند و دارو کم‌اثرتر می‌شود. اما بنزودیازپین اثر کوتاهی دارد، پس گام دوم بلافاصله می‌آید: داروی طولانی‌اثر برای جلوگیری از بازگشت حمله. گزینه‌ی درست دقیقاً همین ترکیب دو گامی را دارد. شروع فنی‌توئین به‌تنهایی گام اول را جا می‌اندازد و اینتوباسیون هم برای حالت مقاوم است، نه شروع درمان.",
 "explanation_en": "The word 'first' decides this item. Establish the diagnosis first: repeated tonic-clonic seizures without recovery between them means status epilepticus, here triggered by stopping phenytoin. Now recall the algorithm, which has two consecutive steps. Step one is an intravenous benzodiazepine, because it acts fastest and every minute of delay makes control harder — as the seizure continues, GABA receptors are internalised and the drug loses potency. But a benzodiazepine is short-acting, so step two follows immediately: a long-acting agent to prevent recurrence. The correct option contains exactly that two-step combination. Starting phenytoin alone skips step one, and intubation belongs to refractory status rather than initial treatment.",
 "why_fa": [
  "شروع فنی‌توئین به‌تنهایی گام اول را جا می‌اندازد. فنی‌توئین شروع اثر کندی دارد و تا رسیدن به سطح درمانی، تشنج ادامه می‌یابد و آسیب نورونی بیشتر می‌شود.",
  "پاسخ صحیح — این گزینه دقیقاً الگوریتم دو گامی را اجرا می‌کند: بنزودیازپین وریدی برای قطع سریع تشنج، و بلافاصله فنی‌توئین برای جلوگیری از بازگشت.",
  "اینتوباسیون و میدازولام وریدی درمان حالت صرعی مقاوم است، یعنی وقتی خط اول و دوم شکست خورده باشند. به‌عنوان اولین اقدام تهاجمی و زودهنگام است.",
  "گاواژ نازوگاستریک در بیمار تشنجی نه ممکن است و نه ایمن؛ خطر آسپیراسیون دارد و جذب گوارشی هم بسیار کندتر از آن است که به درد اورژانس بخورد."
 ],
 "why_en": [
  "Starting phenytoin alone skips the first step. Phenytoin has a slow onset, and the seizure continues while levels build, adding neuronal injury.",
  "Correct — this option executes the two-step algorithm exactly: an intravenous benzodiazepine to stop the seizure fast, then phenytoin to prevent recurrence.",
  "Intubation with intravenous midazolam treats refractory status, once first- and second-line drugs have failed. As an opening move it is invasive and premature.",
  "Nasogastric gavage in a seizing patient is neither feasible nor safe; it risks aspiration and enteral absorption is far too slow for an emergency."
 ],
 "golden_fa": "حالت صرعی: اول بنزودیازپین، بلافاصله بعد داروی طولانی‌اثر. هیچ‌کدام به‌تنهایی کافی نیست.",
 "golden_en": "Status epilepticus: benzodiazepine first, long-acting agent immediately after. Neither alone is enough.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 12: Status epilepticus",
  "Glauser T et al. Evidence-based guideline: treatment of convulsive status epilepticus. Epilepsy Curr 2016;16:48-61"
 ]
}

L["1404-06:93"] = {
 "stem_en": "Which breathing pattern indicates involvement of a lower part of the brain?",
 "options_en": ["Cheyne-Stokes", "Apneustic", "Central neurogenic hyperventilation", "Ataxic"],
 "micro": {
  "lead_fa": "الگوهای تنفسی یک نردبان از دیانسفال تا مدولا می‌سازند؛ هرچه پایین‌تر، بی‌نظم‌تر.",
  "lead_en": "Breathing patterns form a ladder from diencephalon down to medulla; the lower you go, the more irregular.",
  "points_fa": [
   "تنفس شین استوکس الگوی موجی با افزایش و کاهش تدریجی عمق و سپس آپنه است.",
   "این الگو به اختلال در سطح دیانسفال یا نیمکره‌های دوطرفه اشاره می‌کند.",
   "هیپرونتیلاسیون نوروژنیک مرکزی تنفس سریع و عمیق مداوم است و به مغز میانی مربوط می‌شود.",
   "تنفس آپنوستیک مکث طولانی در انتهای دم دارد و نشانه‌ی ضایعه‌ی پونز است.",
   "تنفس آتاکسیک یا بیوت کاملاً بی‌نظم است، هم در عمق و هم در فاصله.",
   "این الگو از آسیب مرکز تنفسی مدولا می‌آید که پایین‌ترین سطح ساقه است.",
   "مدولا آخرین خط دفاعی است، پس تنفس آتاکسیک هشدار آپنه‌ی قریب‌الوقوع است.",
   "پیشرفت این الگوها از بالا به پایین را فتق رو-به-دم می‌نامند.",
   "دیدن تنفس آتاکسیک یعنی بیمار باید فوراً حمایت تنفسی شود."
  ],
  "points_en": [
   "Cheyne-Stokes breathing waxes and wanes in depth and then pauses.",
   "It points to dysfunction at the diencephalic level or in both hemispheres.",
   "Central neurogenic hyperventilation is sustained rapid deep breathing and localises to the midbrain.",
   "Apneustic breathing has a long pause at end-inspiration and signals a pontine lesion.",
   "Ataxic or Biot breathing is entirely irregular in both depth and timing.",
   "It arises from damage to the medullary respiratory centre, the lowest brainstem level.",
   "The medulla is the last line, so ataxic breathing warns of imminent apnoea.",
   "This top-to-bottom progression is called rostro-caudal herniation.",
   "Seeing ataxic breathing means the patient needs immediate ventilatory support."
  ]
 },
 "explanation_fa": "این سؤال یک نقشه‌ی عمودی از ساقه‌ی مغز را می‌آزماید. الگوهای تنفسی در کما مثل یک نردبان‌اند و هرچه ضایعه پایین‌تر برود، تنفس بی‌نظم‌تر می‌شود. بالاترین پله شین استوکس است که به دیانسفال یا نیمکره‌های دوطرفه اشاره می‌کند؛ الگویی موجی با افزایش و کاهش تدریجی عمق. پله‌ی بعد هیپرونتیلاسیون نوروژنیک مرکزی است که مربوط به مغز میانی می‌شود. پایین‌تر تنفس آپنوستیک قرار دارد با مکث طولانی در انتهای دم که نشانه‌ی پونز است. و پایین‌ترین پله تنفس آتاکسیک است: کاملاً بی‌نظم، هم در عمق و هم در فاصله، که از آسیب مرکز تنفسی مدولا می‌آید. چون مدولا آخرین سطح است، دیدن این الگو یعنی آپنه نزدیک است و بیمار باید فوراً حمایت تنفسی شود.",
 "explanation_en": "This item tests a vertical map of the brainstem. Breathing patterns in coma form a ladder, and the lower the lesion the more irregular the breathing. The top rung is Cheyne-Stokes, pointing to the diencephalon or both hemispheres, with its waxing and waning depth. Next comes central neurogenic hyperventilation, localising to the midbrain. Lower still is apneustic breathing, with its long end-inspiratory pause, signalling the pons. The lowest rung is ataxic breathing: wholly irregular in depth and timing, arising from damage to the medullary respiratory centre. Because the medulla is the last level, seeing this pattern means apnoea is near and the patient needs immediate ventilatory support.",
 "why_fa": [
  "تنفس شین استوکس بالاترین سطح این نردبان است و به اختلال دیانسفال یا نیمکره‌های دوطرفه اشاره می‌کند، نه به قسمت پایینی مغز.",
  "تنفس آپنوستیک نشانه‌ی ضایعه‌ی پونز است که پایین‌تر از مغز میانی ولی بالاتر از مدولا قرار دارد. پس پایین‌ترین سطح نیست.",
  "هیپرونتیلاسیون نوروژنیک مرکزی به مغز میانی مربوط است و در نردبان تنفسی جایگاه میانی-بالایی دارد.",
  "پاسخ صحیح — تنفس آتاکسیک از آسیب مرکز تنفسی مدولا می‌آید که پایین‌ترین سطح ساقه‌ی مغز است و هشدار آپنه‌ی قریب‌الوقوع محسوب می‌شود."
 ],
 "why_en": [
  "Cheyne-Stokes sits at the top of this ladder, pointing to diencephalic or bihemispheric dysfunction rather than a lower part of the brain.",
  "Apneustic breathing signals a pontine lesion — below the midbrain but above the medulla, so not the lowest level.",
  "Central neurogenic hyperventilation localises to the midbrain and occupies a mid-to-upper position on the ladder.",
  "Correct — ataxic breathing arises from the medullary respiratory centre, the lowest brainstem level, and warns of imminent apnoea."
 ],
 "golden_fa": "نردبان تنفس: شین استوکس (دیانسفال) ← هیپرونتیلاسیون (مغز میانی) ← آپنوستیک (پونز) ← آتاکسیک (مدولا).",
 "golden_en": "The breathing ladder: Cheyne-Stokes (diencephalon) → hyperventilation (midbrain) → apneustic (pons) → ataxic (medulla).",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 3: Breathing patterns in coma",
  "Plum and Posner's Diagnosis of Stupor and Coma, 4th ed"
 ]
}
json.dump(L, io.open('/home/user/work/lessons/L7.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('batch 7:', len(L), 'lessons')
