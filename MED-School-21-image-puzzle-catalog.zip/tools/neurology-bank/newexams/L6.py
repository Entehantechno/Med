# -*- coding: utf-8 -*-
"""Micro-lessons, batch 6 — Dey-1397 mid-term."""
import json, io
L = {}

L["1397-10:114"] = {
 "stem_en": "In a patient suspected of amyotrophic lateral sclerosis (ALS), which of the following findings argues AGAINST the diagnosis?",
 "options_en": ["Dysphagia", "Impaired urinary control",
                "Fasciculations in limb muscles", "Babinski sign"],
 "micro": {
  "lead_fa": "ALS فقط نورون حرکتی را می‌گیرد؛ اسفنکتر، حس و حرکات چشم تا آخر سالم می‌مانند.",
  "lead_en": "ALS attacks only motor neurons; sphincters, sensation and eye movements are spared to the end.",
  "points_fa": [
   "ALS بیماری دژنراتیو نورون حرکتی است و هم‌زمان نورون فوقانی و تحتانی را درگیر می‌کند.",
   "درگیری نورون تحتانی: آتروفی، ضعف و فاسیکولاسیون در عضلات.",
   "درگیری نورون فوقانی: افزایش رفلکس، اسپاستیسیتی و علامت بابنسکی.",
   "همزیستی این دو الگو در یک بیمار، امضای تشخیصی ALS است.",
   "درگیری بولبار دیسفاژی، دیس‌آرتری و ضعف زبان می‌سازد.",
   "اما سه چیز در ALS تقریباً همیشه سالم می‌ماند: اسفنکترها، حس و حرکات چشم.",
   "علتش این است که نورون‌های اونوف (کنترل اسفنکتر) به‌طور انتخابی مقاوم‌اند.",
   "پس بی‌اختیاری ادرار یک پرچم قرمز است و باید تشخیص را زیر سؤال ببرد.",
   "در چنین حالتی باید به ضایعه‌ی نخاعی، میلوپاتی گردنی یا ام‌اس فکر کرد."
  ],
  "points_en": [
   "ALS is a degenerative motor neuron disease affecting upper and lower neurons together.",
   "Lower motor neuron signs: atrophy, weakness and fasciculations.",
   "Upper motor neuron signs: hyperreflexia, spasticity and the Babinski sign.",
   "The coexistence of both patterns in one patient is the diagnostic signature of ALS.",
   "Bulbar involvement produces dysphagia, dysarthria and tongue weakness.",
   "But three things are almost always spared in ALS: sphincters, sensation and eye movements.",
   "Onuf's nucleus neurons, which control the sphincters, are selectively resistant.",
   "So urinary incontinence is a red flag that should challenge the diagnosis.",
   "In that case consider a spinal cord lesion, cervical myelopathy or MS."
  ]
 },
 "explanation_fa": "این سؤال منفی است و می‌خواهد بداند کدام علامت با ALS نمی‌خواند. برای پاسخ باید بدانید ALS چه چیزی را می‌گیرد و چه چیزی را نمی‌گیرد. این بیماری منحصراً نورون حرکتی را هدف می‌گیرد، آن هم هر دو نوعش: نورون تحتانی که آتروفی و فاسیکولاسیون می‌دهد، و نورون فوقانی که بابنسکی و اسپاستیسیتی می‌سازد. درگیری بولبار هم دیسفاژی می‌دهد. پس سه گزینه‌ی اختلال بلع، فاسیکولاسیون و بابنسکی همگی انتظار می‌روند. اما ALS سه چیز را تقریباً همیشه سالم می‌گذارد: اسفنکترها، حس و حرکات چشم. دلیل جالبی هم دارد؛ نورون‌های هسته‌ی اونوف که اسفنکتر را کنترل می‌کنند به‌طور انتخابی در برابر این بیماری مقاوم‌اند. پس بی‌اختیاری ادرار یک پرچم قرمز است و باید شما را به سمت تشخیص‌های دیگری مثل میلوپاتی گردنی یا ام‌اس ببرد.",
 "explanation_en": "This is a negative-stem item asking which finding does not fit ALS. To answer you must know what ALS attacks and what it spares. The disease targets motor neurons exclusively, both kinds: lower motor neurons producing atrophy and fasciculations, and upper motor neurons producing the Babinski sign and spasticity. Bulbar involvement adds dysphagia. So dysphagia, fasciculations and Babinski are all expected. But ALS almost always spares three things: sphincters, sensation and eye movements. There is an elegant reason — the neurons of Onuf's nucleus, which control the sphincters, are selectively resistant. Urinary incontinence is therefore a red flag that should redirect you towards cervical myelopathy or MS.",
 "why_fa": [
  "اختلال بلع از درگیری بولبار می‌آید و در ALS شایع است. در برخی بیماران حتی اولین تظاهر بیماری همین است.",
  "پاسخ صحیح — اسفنکترها در ALS تا مراحل پایانی سالم می‌مانند، چون نورون‌های هسته‌ی اونوف به‌طور انتخابی مقاوم‌اند. بی‌اختیاری ادرار به ضرر تشخیص است.",
  "فاسیکولاسیون نشانه‌ی کلاسیک درگیری نورون حرکتی تحتانی است و یکی از ارکان تشخیص ALS محسوب می‌شود.",
  "علامت بابنسکی نشانه‌ی درگیری نورون حرکتی فوقانی است. وجود همزمان آن با فاسیکولاسیون، امضای تشخیصی ALS است."
 ],
 "why_en": [
  "Dysphagia reflects bulbar involvement and is common in ALS. In some patients it is the presenting feature.",
  "Correct — sphincters are spared in ALS until the terminal stages, because Onuf's nucleus neurons are selectively resistant. Incontinence argues against the diagnosis.",
  "Fasciculation is the classic sign of lower motor neuron involvement and one of the pillars of ALS diagnosis.",
  "The Babinski sign indicates upper motor neuron involvement. Its coexistence with fasciculations is the diagnostic signature of ALS."
 ],
 "golden_fa": "ALS سه چیز را نمی‌گیرد: اسفنکتر، حس و حرکات چشم. بی‌اختیاری ادرار یعنی تشخیص را بازنگری کنید.",
 "golden_en": "ALS spares three things: sphincters, sensation and eye movements. Incontinence means rethink the diagnosis.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 9: Motor neuron disease",
  "Brooks BR et al. El Escorial revisited: revised criteria for the diagnosis of ALS. Amyotroph Lateral Scler 2000;1:293-9"
 ]
}

L["1397-10:116"] = {
 "stem_en": "What is the treatment of choice for a patient whose seizures consist of objects involuntarily dropping from the hands in sudden jerks, particularly in the mornings?",
 "options_en": ["Phenobarbital", "Carbamazepine", "Phenytoin", "Sodium valproate"],
 "micro": {
  "lead_fa": "افتادن اشیا از دست در صبح یعنی میوکلونی صبحگاهی، و آن یعنی صرع میوکلونیک جوانان.",
  "lead_en": "Objects dropping from the hands in the morning means morning myoclonus, and that means juvenile myoclonic epilepsy.",
  "points_fa": [
   "صرع میوکلونیک جوانان معمولاً بین ۱۲ تا ۱۸ سالگی شروع می‌شود.",
   "علامت شاخص آن پرش‌های کوتاه شانه و بازو در ساعات اول پس از بیداری است.",
   "بیمار هوشیار است و شکایتش اغلب همین است که صبح‌ها لیوان از دستش می‌افتد.",
   "بی‌خوابی، خستگی، الکل و نور چشمک‌زن محرک‌های شناخته‌شده‌اند.",
   "در بیشتر بیماران در نهایت تشنج تونیک-کلونیک هم اضافه می‌شود.",
   "نوار مغز پلی‌اسپایک-موج چهار تا شش هرتز و اغلب حساسیت به نور نشان می‌دهد.",
   "این یک صرع ژنرالیزه‌ی ژنتیکی است، پس داروی وسیع‌الطیف لازم دارد.",
   "والپروات هر سه نوع حمله را پوشش می‌دهد: میوکلونی، ابسانس و تونیک-کلونیک.",
   "کاربامازپین و فنی‌توئین باریک‌الطیف‌اند و می‌توانند پرش‌ها را بدتر کنند."
  ],
  "points_en": [
   "Juvenile myoclonic epilepsy usually begins between the ages of 12 and 18.",
   "Its hallmark is brief jerks of the shoulders and arms in the first hours after waking.",
   "The patient is fully awake and often complains that the cup drops in the morning.",
   "Sleep deprivation, fatigue, alcohol and flashing lights are recognised triggers.",
   "Most patients eventually add generalised tonic-clonic seizures.",
   "The EEG shows 4-6 Hz polyspike-and-wave and often photosensitivity.",
   "This is a genetic generalised epilepsy, so it needs a broad-spectrum drug.",
   "Valproate covers all three seizure types: myoclonic, absence and tonic-clonic.",
   "Carbamazepine and phenytoin are narrow-spectrum and can worsen the jerks."
  ]
 },
 "explanation_fa": "توصیف صورت سؤال ظریف اما تشخیصی است. افتادن غیرارادی اشیا از دست به شکل ناگهانی و پرشی، آن هم به‌ویژه صبح‌ها، دقیقاً همان میوکلونی صبحگاهی است. بیمار در این لحظات کاملاً هوشیار است و فقط یک پرش کوتاه در شانه و بازو حس می‌کند. این توصیف تقریباً اختصاصی صرع میوکلونیک جوانان است. چرا صبح؟ چون آستانه‌ی تشنج در ساعات اول پس از بیداری پایین‌ترین حد خود را دارد و بی‌خوابی شب قبل آن را بیشتر پایین می‌آورد. حالا انتخاب دارو: این یک صرع ژنرالیزه‌ی ژنتیکی است، پس داروی وسیع‌الطیف لازم دارد. از میان گزینه‌ها فقط والپروات سدیم این ویژگی را دارد و هر سه نوع حمله را پوشش می‌دهد. نکته‌ی هشداردهنده اینکه کاربامازپین و فنی‌توئین در این بیماری نه‌تنها بی‌اثرند بلکه می‌توانند پرش‌ها را تشدید کنند.",
 "explanation_en": "The stem's description is subtle but diagnostic. Objects dropping involuntarily from the hands in sudden jerks, especially in the mornings, is precisely morning myoclonus. The patient is fully conscious during these moments and feels only a brief jerk of the shoulder and arm. That description is almost specific for juvenile myoclonic epilepsy. Why mornings? Because the seizure threshold is at its lowest in the first hours after waking, and sleep loss the night before lowers it further. Now the drug: this is a genetic generalised epilepsy needing a broad-spectrum agent. Of the options only sodium valproate qualifies, covering all three seizure types. A warning worth remembering: carbamazepine and phenytoin are not merely ineffective here — they can aggravate the jerks.",
 "why_fa": [
  "فنوباربیتال میوکلونی را تا حدی کم می‌کند اما خواب‌آلودگی و اختلال تمرکز می‌سازد. برای نوجوانی که درس می‌خواند انتخاب مناسبی نیست.",
  "کاربامازپین باریک‌الطیف است و در صرع میوکلونیک جوانان می‌تواند پرش‌ها و حملات ابسانس را تشدید کند. تجویز آن یک خطای شایع بالینی است.",
  "فنی‌توئین بر تشنج تونیک-کلونیک اثر دارد اما بر میوکلونی بی‌اثر است و می‌تواند آن را بدتر کند.",
  "پاسخ صحیح — والپروات سدیم داروی انتخابی صرع میوکلونیک جوانان است و هر سه نوع حمله یعنی میوکلونی، ابسانس و تونیک-کلونیک را پوشش می‌دهد."
 ],
 "why_en": [
  "Phenobarbital reduces myoclonus somewhat but causes sedation and impairs concentration. It is a poor choice for a studying adolescent.",
  "Carbamazepine is narrow-spectrum and can aggravate the jerks and absences of juvenile myoclonic epilepsy. Prescribing it is a common clinical error.",
  "Phenytoin works on tonic-clonic seizures but not on myoclonus, and may worsen it.",
  "Correct — sodium valproate is the drug of choice for juvenile myoclonic epilepsy, covering all three seizure types."
 ],
 "golden_fa": "لیوان که صبح از دست می‌افتد، اسمش JME است. داروی وسیع‌الطیف بدهید، نه کاربامازپین.",
 "golden_en": "The cup that drops in the morning is called JME. Give a broad-spectrum drug, not carbamazepine.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 12: Juvenile myoclonic epilepsy",
  "Glauser T et al. ILAE treatment guidelines. Epilepsia 2013;54:551-63"
 ]
}

L["1397-10:117"] = {
 "stem_en": "Macular oedema is an adverse effect of which disease-modifying drug for multiple sclerosis?",
 "options_en": ["Natalizumab", "Fingolimod", "Interferon beta-1b", "Glatiramer acetate"],
 "micro": {
  "lead_fa": "ادم ماکولا عارضه‌ی شاخص فینگولیمود است، پس معاینه‌ی چشم پیش و پس از شروع الزامی است.",
  "lead_en": "Macular oedema is the signature adverse effect of fingolimod, so eye examination before and after starting is mandatory.",
  "points_fa": [
   "فینگولیمود گیرنده‌ی اسفنگوزین-۱-فسفات را تنظیم‌کاهشی می‌کند.",
   "نتیجه اینکه لنفوسیت‌ها در غدد لنفاوی حبس می‌شوند و به سیستم عصبی نمی‌رسند.",
   "همین گیرنده در سلول‌های اندوتلیال شبکیه هم هست و نفوذپذیری عروق را تغییر می‌دهد.",
   "پیامدش ادم ماکولا است که معمولاً در سه تا چهار ماه اول ظاهر می‌شود.",
   "دیابت و یووئیت قبلی خطر آن را بالا می‌برند.",
   "پس معاینه‌ی چشم پیش از شروع و سه تا چهار ماه بعد الزامی است.",
   "عارضه‌ی دیگر فینگولیمود برادیکاردی در نخستین دوز است که پایش شش‌ساعته می‌طلبد.",
   "ناتالیزوماب عارضه‌ی شاخصش لکوانسفالوپاتی چندکانونی پیشرونده (PML) است.",
   "اینترفرون علائم شبه‌آنفلوانزا و افزایش آنزیم کبدی می‌دهد و گلاتیرامر واکنش محل تزریق."
  ],
  "points_en": [
   "Fingolimod down-regulates the sphingosine-1-phosphate receptor.",
   "Lymphocytes are consequently trapped in lymph nodes and never reach the nervous system.",
   "The same receptor exists on retinal endothelial cells and alters vascular permeability.",
   "The result is macular oedema, usually appearing in the first three to four months.",
   "Diabetes and previous uveitis raise the risk.",
   "Eye examination before starting and three to four months later is therefore mandatory.",
   "Fingolimod's other hallmark is first-dose bradycardia, requiring six hours of monitoring.",
   "Natalizumab's signature risk is progressive multifocal leukoencephalopathy (PML).",
   "Interferon causes flu-like symptoms and raised liver enzymes; glatiramer causes injection-site reactions."
  ]
 },
 "explanation_fa": "این سؤال حفظی به نظر می‌رسد اما مکانیسم دارد و با فهم مکانیسم ماندگار می‌شود. فینگولیمود از راه تنظیم‌کاهشی گیرنده‌ی اسفنگوزین-۱-فسفات کار می‌کند؛ این کار لنفوسیت‌ها را در غدد لنفاوی حبس می‌کند تا به سیستم عصبی مرکزی نرسند. اما همین گیرنده در سلول‌های اندوتلیال شبکیه هم وجود دارد، و مهار آن نفوذپذیری عروق شبکیه را تغییر می‌دهد و ادم ماکولا می‌سازد. این عارضه معمولاً در سه تا چهار ماه اول درمان ظاهر می‌شود و در بیماران دیابتی یا با سابقه‌ی یووئیت شایع‌تر است؛ به همین دلیل معاینه‌ی چشم پیش از شروع دارو و حدود سه ماه بعد الزامی است. برای تفکیک از بقیه، عارضه‌ی شاخص هر کدام را جداگانه به خاطر بسپارید: ناتالیزوماب خطر PML، اینترفرون علائم شبه‌آنفلوانزا، و گلاتیرامر واکنش موضعی محل تزریق.",
 "explanation_en": "This looks like a pure memory item but it has a mechanism, and understanding it makes the fact stick. Fingolimod works by down-regulating the sphingosine-1-phosphate receptor, trapping lymphocytes in lymph nodes so they never reach the central nervous system. But the same receptor sits on retinal endothelial cells, and blocking it alters retinal vascular permeability, producing macular oedema. The complication usually appears in the first three to four months and is commoner in diabetics or those with previous uveitis; hence the mandatory eye examination before starting and again around three months. To separate the others, learn each one's signature: natalizumab risks PML, interferon causes flu-like symptoms, and glatiramer causes injection-site reactions.",
 "why_fa": [
  "ناتالیزوماب عارضه‌ی شاخصش لکوانسفالوپاتی چندکانونی پیشرونده است. پیش از شروع آن باید آنتی‌بادی ضد ویروس JC بررسی شود.",
  "پاسخ صحیح — ادم ماکولا عارضه‌ی شناخته‌شده‌ی فینگولیمود است و از اثر آن بر گیرنده‌ی S1P در اندوتلیوم شبکیه ناشی می‌شود.",
  "اینترفرون بتا علائم شبه‌آنفلوانزا پس از تزریق، افزایش آنزیم‌های کبدی و لکوپنی می‌دهد. اثری بر ماکولا ندارد.",
  "گلاتیرامر استات عمدتاً واکنش موضعی محل تزریق و گاهی واکنش سیستمیک گذرا با تنگی نفس و تپش قلب می‌دهد."
 ],
 "why_en": [
  "Natalizumab's signature complication is progressive multifocal leukoencephalopathy. JC virus antibody must be checked before starting it.",
  "Correct — macular oedema is a recognised adverse effect of fingolimod, arising from its action on S1P receptors in retinal endothelium.",
  "Interferon beta causes post-injection flu-like symptoms, raised liver enzymes and leukopenia. It has no macular effect.",
  "Glatiramer acetate mainly causes injection-site reactions and occasionally a transient systemic reaction with dyspnoea and palpitations."
 ],
 "golden_fa": "فینگولیمود: چشم و قلب را بپا. ادم ماکولا در ماه‌های اول، برادیکاردی در نخستین دوز.",
 "golden_en": "Fingolimod: watch the eye and the heart. Macular oedema in the early months, bradycardia with the first dose.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 6: Disease-modifying therapy in MS",
  "Jain N, Bhatti MT. Fingolimod-associated macular edema. Neurology 2012;78:672-80"
 ]
}

L["1397-10:118"] = {
 "micro": {
  "lead_fa": "مردمک کوچک ولی واکنش‌دهنده + پوسچر دکورتیکه = اختلال در سطح دیانسفال.",
  "lead_en": "Small but reactive pupils + decorticate posturing = dysfunction at the diencephalic level.",
  "points_fa": [
   "در کما، مردمک و پوسچر با هم سطح ضایعه را در محور عمودی مغز مشخص می‌کنند.",
   "سطح دیانسفال: مردمک کوچک اما واکنش‌دهنده به نور، و پوسچر دکورتیکه.",
   "پوسچر دکورتیکه یعنی خم شدن آرنج و مچ با اکستانسیون پاها.",
   "علتش قطع مسیر کورتیکواسپاینال بالای هسته‌ی قرمز و آزاد ماندن مسیر روبرواسپاینال است.",
   "سطح میدبرین: مردمک میدپوزیشن و بی‌واکنش، و پوسچر دسربره.",
   "پوسچر دسربره یعنی اکستانسیون و چرخش داخلی هر چهار اندام.",
   "سطح پونز: مردمک نوک‌سوزنی ولی واکنش‌دهنده، و رفلکس کالریک از بین می‌رود.",
   "سطح مدولا: تنفس نامنظم آتاکسیک و در نهایت آپنه و افت فشار.",
   "پیشرفت این نشانه‌ها از بالا به پایین را فتق رو-به-دم می‌نامند و اورژانس واقعی است."
  ],
  "points_en": [
   "In coma, pupils and posture together localise the lesion along the brain's vertical axis.",
   "Diencephalic level: small but light-reactive pupils, with decorticate posturing.",
   "Decorticate posturing means elbow and wrist flexion with leg extension.",
   "It reflects interruption of the corticospinal tract above the red nucleus, freeing the rubrospinal tract.",
   "Midbrain level: mid-position, unreactive pupils with decerebrate posturing.",
   "Decerebrate posturing means extension and internal rotation of all four limbs.",
   "Pontine level: pinpoint but reactive pupils, with loss of caloric responses.",
   "Medullary level: irregular ataxic breathing, then apnoea and hypotension.",
   "This top-to-bottom progression is called rostro-caudal herniation and is a true emergency."
  ]
 },
 "explanation_fa": "معاینه‌ی بیمار کمایی یک نقشه‌ی عمودی از مغز به شما می‌دهد، و دو نشانه‌ی کلیدی این نقشه مردمک و پوسچر هستند. این بیمار مردمک کوچک دو میلی‌متری دارد اما به نور واکنش می‌دهد، رفلکس اکولوسفالیک هم سالم است، و با تحریک دردناک پوسچر دکورتیکه می‌گیرد. این ترکیب دقیقاً الگوی اختلال در سطح دیانسفال است. مکانیسم پوسچر دکورتیکه آموزنده است: وقتی مسیر کورتیکواسپاینال بالاتر از هسته‌ی قرمز قطع شود، مسیر روبرواسپاینال که فلکسورهای اندام فوقانی را تحریک می‌کند بدون مهار می‌ماند، پس دست‌ها خم می‌شوند. حالا سلسله‌مراتب را به یاد بسپارید: اگر ضایعه به میدبرین برسد، مردمک‌ها میدپوزیشن و بی‌واکنش می‌شوند و پوسچر به دسربره تبدیل می‌شود. در پونز مردمک نوک‌سوزنی می‌شود و در مدولا تنفس نامنظم و در نهایت آپنه رخ می‌دهد.",
 "explanation_en": "Examining a comatose patient gives you a vertical map of the brain, and its two key markers are the pupils and the posture. This patient has small two-millimetre pupils that still react to light, intact oculocephalic reflexes, and decorticate posturing to pain. That combination is exactly the diencephalic pattern. The mechanism of decorticate posturing is instructive: when the corticospinal tract is interrupted above the red nucleus, the rubrospinal tract that drives upper-limb flexors is left unopposed, so the arms flex. Now learn the hierarchy: if the lesion descends to the midbrain, pupils become mid-position and unreactive and posturing turns decerebrate. At the pons pupils become pinpoint, and at the medulla breathing becomes irregular and finally apnoeic.",
 "why_fa": [
  "پاسخ صحیح — مردمک کوچک ولی واکنش‌دهنده، رفلکس‌های ساقه‌ی سالم و پوسچر دکورتیکه، سه‌گانه‌ی اختلال در سطح دیانسفال است.",
  "در ضایعه‌ی میدبرین مردمک‌ها میدپوزیشن (حدود ۵ میلی‌متر) و بی‌واکنش به نور می‌شوند و پوسچر دسربره است، نه دکورتیکه.",
  "در ضایعه‌ی پونز مردمک‌ها نوک‌سوزنی می‌شوند و رفلکس‌های حرکتی چشم از بین می‌روند. در این بیمار رفلکس اکولوسفالیک سالم است.",
  "ضایعه‌ی مدولا با اختلال تنفسی آتاکسیک، افت فشار خون و در نهایت آپنه ظاهر می‌شود، نه با پوسچر دکورتیکه."
 ],
 "why_en": [
  "Correct — small but reactive pupils, intact brainstem reflexes and decorticate posturing form the diencephalic triad.",
  "A midbrain lesion gives mid-position (about 5 mm) pupils unreactive to light, with decerebrate rather than decorticate posturing.",
  "A pontine lesion gives pinpoint pupils and loss of ocular motor reflexes. This patient's oculocephalic reflex is intact.",
  "A medullary lesion presents with ataxic breathing, hypotension and eventually apnoea, not decorticate posturing."
 ],
 "golden_fa": "دیانسفال: مردمک کوچک واکنش‌دهنده + دکورتیکه. میدبرین: مردمک میدپوزیشن بی‌واکنش + دسربره.",
 "golden_en": "Diencephalon: small reactive pupils + decorticate. Midbrain: mid-position unreactive pupils + decerebrate.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 3: Examination of the comatose patient",
  "Plum and Posner's Diagnosis of Stupor and Coma, 4th ed"
 ]
}
json.dump(L, io.open('/home/user/work/lessons/L6.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('batch 6:', len(L), 'lessons')
