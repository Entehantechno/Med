# -*- coding: utf-8 -*-
"""Bilingual micro-lessons, batch 1 — Shahrivar-1403 (official key)."""
import json, io
L = {}

L["1403-06:97"] = {
 "stem_en": "A 32-year-old woman with refractory epilepsy for 10 years is treated with phenobarbital, phenytoin, lamotrigine and levetiracetam. On examination you notice hirsutism and gingival hypertrophy. These adverse effects are caused by which of the following drugs?",
 "options_en": ["Phenobarbital", "Phenytoin", "Lamotrigine", "Levetiracetam"],
 "micro": {
  "lead_fa": "هیپرپلازی لثه به‌علاوه‌ی پرمویی، امضای اختصاصی فنی‌توئین است و از تحریک فیبروبلاست‌ها می‌آید.",
  "lead_en": "Gingival hyperplasia plus hirsutism is the specific signature of phenytoin, driven by fibroblast stimulation.",
  "points_fa": [
   "فنی‌توئین فیبروبلاست‌های لثه را تحریک می‌کند تا کلاژن بیشتری بسازند و لثه حجیم شود.",
   "این عارضه در حدود نیمی از بیماران رخ می‌دهد و در جوان‌ترها شایع‌تر است.",
   "بهداشت خوب دهان شدت آن را کم می‌کند اما به‌طور کامل جلویش را نمی‌گیرد.",
   "همین اثر روی فولیکول مو باعث پرمویی صورت و اندام‌ها می‌شود.",
   "سایر عوارض مزمن فنی‌توئین درشتی خطوط چهره، آکنه و آتروفی مخچه است.",
   "در مسمومیت حاد، نیستاگموس و آتاکسی و دیس‌آرتری ظاهر می‌شود.",
   "سینتیک فنی‌توئین غیرخطی است، پس افزایش کوچک دوز می‌تواند سطح خونی را ناگهان بالا ببرد.",
   "فنوباربیتال خواب‌آلودگی و در کودکان بیش‌فعالی می‌دهد، نه تغییر لثه.",
   "لاموتریژین خطر بثورات پوستی و سندرم استیونس-جانسون دارد و لوتیراستام تغییرات خلقی."
  ],
  "points_en": [
   "Phenytoin stimulates gingival fibroblasts to make more collagen, so the gums enlarge.",
   "This affects about half of patients and is commoner in younger ones.",
   "Good oral hygiene reduces its severity but does not fully prevent it.",
   "The same effect on hair follicles produces facial and limb hirsutism.",
   "Other chronic phenytoin effects are coarsened facial features, acne and cerebellar atrophy.",
   "In acute toxicity, nystagmus, ataxia and dysarthria appear.",
   "Phenytoin kinetics are non-linear, so a small dose rise can suddenly raise blood levels.",
   "Phenobarbital causes sedation and hyperactivity in children, not gum changes.",
   "Lamotrigine risks rash and Stevens-Johnson syndrome; levetiracetam causes mood change."
  ]
 },
 "explanation_fa": "این سؤال یک الگوی کلاسیک شناسایی دارو از روی عارضه است. بیمار چهار داروی ضد تشنج می‌گیرد و باید بدانید کدام‌یک این دو عارضه‌ی خاص را با هم می‌سازد. فنی‌توئین فیبروبلاست‌های لثه را تحریک می‌کند تا کلاژن بیشتری تولید کنند و نتیجه‌اش هیپرپلازی لثه است که در حدود نیمی از بیماران دیده می‌شود. همین مکانیسم روی فولیکول مو هم اثر می‌گذارد و پرمویی می‌سازد. مجموعه‌ی عوارض مزمن فنی‌توئین را به‌عنوان یک بسته به خاطر بسپارید: هیپرپلازی لثه، هیرسوتیسم، درشتی خطوط چهره، آکنه و در مصرف طولانی آتروفی مخچه. سه داروی دیگر الگوی عارضه‌ی کاملاً متفاوتی دارند: فنوباربیتال خواب‌آلودگی، لاموتریژین بثورات پوستی و لوتیراستام تحریک‌پذیری و تغییرات خلقی.",
 "explanation_en": "This item follows the classic pattern of identifying a drug from its side effect. The patient takes four anticonvulsants and you must know which one produces these two effects together. Phenytoin stimulates gingival fibroblasts to produce more collagen, causing the gingival hyperplasia seen in about half of patients. The same mechanism acts on hair follicles to produce hirsutism. Memorise phenytoin's chronic effects as one package: gingival hyperplasia, hirsutism, coarsened facial features, acne and, with long use, cerebellar atrophy. The other three drugs have entirely different side-effect profiles: phenobarbital causes sedation, lamotrigine rash, and levetiracetam irritability and mood change.",
 "why_fa": [
  "فنوباربیتال خواب‌آلودگی، کندی شناختی و در کودکان بیش‌فعالی متناقض می‌دهد. هیچ اثری بر بافت لثه یا رشد مو ندارد.",
  "پاسخ صحیح — فنی‌توئین با تحریک فیبروبلاست‌ها هم هیپرپلازی لثه و هم هیرسوتیسم می‌سازد؛ این دو با هم امضای اختصاصی آن هستند.",
  "لاموتریژین عارضه‌ی شاخصش بثورات پوستی است که می‌تواند تا سندرم استیونس-جانسون پیش برود. به همین دلیل تیتراسیون آن باید بسیار آهسته باشد.",
  "لوتیراستام عمدتاً عوارض رفتاری و خلقی مانند تحریک‌پذیری و افسردگی دارد و از نظر عوارض جسمی یکی از تمیزترین داروهای ضد تشنج است."
 ],
 "why_en": [
  "Phenobarbital causes sedation, cognitive slowing and paradoxical hyperactivity in children. It has no effect on gum tissue or hair growth.",
  "Correct — phenytoin stimulates fibroblasts to produce both gingival hyperplasia and hirsutism; together these are its specific signature.",
  "Lamotrigine's hallmark adverse effect is rash, which can progress to Stevens-Johnson syndrome. This is why its titration must be very slow.",
  "Levetiracetam mainly causes behavioural and mood effects such as irritability and depression, and is one of the cleanest anticonvulsants for physical side effects."
 ],
 "golden_fa": "لثه‌ی حجیم + پرمویی = فنی‌توئین. این دو را همیشه با هم به یاد بیاورید.",
 "golden_en": "Swollen gums + hirsutism = phenytoin. Always recall these two together.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 12: Antiepileptic drug adverse effects",
  "Brunton LL et al. Goodman & Gilman's The Pharmacological Basis of Therapeutics, 13th ed — Phenytoin"
 ]
}

L["1403-06:98"] = {
 "stem_en": "A 10-year-old boy with attention deficit hyperactivity disorder (ADHD) is brought to the clinic for unusual movements and sounds. Symptoms began two years ago with grunting and throat clearing. During the examination he began blinking repeatedly; his eye examination is normal. Throughout the visit he intermittently shrugged his shoulders, and the shoulder movement stopped abruptly. Which other condition is he likely to have?",
 "options_en": ["Delusion", "Hallucination", "Obsessive-compulsive disorder", "Panic attacks"],
 "micro": {
  "lead_fa": "تیک حرکتی و صوتی بیش از یک سال یعنی سندرم توره، و دو همراه شایع آن ADHD و وسواس فکری-عملی هستند.",
  "lead_en": "Motor and vocal tics lasting over a year mean Tourette syndrome, whose two commonest comorbidities are ADHD and OCD.",
  "points_fa": [
   "تیک حرکتی ناگهانی، سریع و کلیشه‌ای است؛ مثل پلک زدن مکرر یا بالا انداختن شانه.",
   "تیک صوتی هم همان ویژگی‌ها را دارد؛ مثل خرخر کردن یا صاف کردن گلو.",
   "برای تشخیص سندرم توره، هر دو نوع تیک باید بیش از یک سال ادامه داشته باشند.",
   "شروع معمولاً بین ۴ تا ۶ سالگی است و شدت آن در نوجوانی به اوج می‌رسد.",
   "بیمار می‌تواند تیک را برای مدت کوتاهی مهار کند اما احساس فشار درونی می‌کند.",
   "پس از انجام تیک، آن حس ناخوشایند مقدماتی برطرف می‌شود؛ به آن premonitory urge می‌گویند.",
   "همین حس فشار و رهایی، پل مفهومی میان تیک و وسواس فکری-عملی است.",
   "حدود نیمی از بیماران توره معیارهای وسواس فکری-عملی را هم دارند.",
   "ADHD هم در حدود شصت درصد موارد همراه است، که در این بیمار از قبل تشخیص داده شده."
  ],
  "points_en": [
   "A motor tic is sudden, rapid and stereotyped, such as repeated blinking or shoulder shrugging.",
   "A vocal tic shares the same features, such as grunting or throat clearing.",
   "Tourette syndrome requires both types of tic persisting for more than one year.",
   "Onset is usually between ages 4 and 6, with peak severity in adolescence.",
   "The patient can suppress a tic briefly but feels mounting inner tension.",
   "Performing the tic relieves that unpleasant preceding sensation, called the premonitory urge.",
   "That tension-and-relief cycle is the conceptual bridge between tics and OCD.",
   "About half of Tourette patients also meet criteria for obsessive-compulsive disorder.",
   "ADHD accompanies roughly sixty per cent of cases, and was already diagnosed here."
  ]
 },
 "explanation_fa": "ابتدا تشخیص را بسازید. کودک هم تیک صوتی دارد (خرخر کردن و صاف کردن گلو) و هم تیک حرکتی (پلک زدن مکرر و بالا انداختن شانه)، و علائم بیش از یک سال طول کشیده است؛ این دقیقاً تعریف سندرم توره است. حالا سؤال درباره‌ی بیماری همراه است. سه‌گانه‌ی معروف توره را به خاطر بسپارید: خود تیک، ADHD و اختلال وسواس فکری-عملی. ADHD در حدود شصت درصد و وسواس در حدود پنجاه درصد بیماران دیده می‌شود، و در این بیمار ADHD از قبل تشخیص داده شده است. ارتباط مفهومی وسواس با تیک هم جالب است: بیمار توره پیش از هر تیک یک حس فشار درونی دارد که با انجام تیک رها می‌شود، و همین چرخه‌ی فشار و رهایی شبیه رابطه‌ی وسواس فکری با عمل اجباری است. هذیان و توهم به اسکیزوفرنی تعلق دارند و ارتباطی با توره ندارند.",
 "explanation_en": "Build the diagnosis first. The boy has both vocal tics (grunting, throat clearing) and motor tics (repeated blinking, shoulder shrugging), lasting over a year — exactly the definition of Tourette syndrome. The question then asks about comorbidity. Remember the Tourette triad: the tics themselves, ADHD and obsessive-compulsive disorder. ADHD accompanies about sixty per cent and OCD about fifty per cent of patients, and ADHD is already diagnosed here. The conceptual link with OCD is elegant: before each tic the patient feels a premonitory urge that is relieved by performing it, and that tension-relief cycle mirrors the relationship between an obsession and its compulsion. Delusions and hallucinations belong to schizophrenia and have no link with Tourette.",
 "why_fa": [
  "هذیان یک باور ثابت و نادرست است که به اختلالات سایکوتیک مانند اسکیزوفرنی تعلق دارد. ارتباط شناخته‌شده‌ای با سندرم توره ندارد.",
  "توهم ادراک بدون محرک بیرونی است و آن هم از علائم اختلالات سایکوتیک است، نه از همراهان توره.",
  "پاسخ صحیح — اختلال وسواس فکری-عملی در حدود نیمی از بیماران توره دیده می‌شود و همراه با ADHD دو همراه اصلی این سندرم است.",
  "حملات پانیک یک اختلال اضطرابی است. هرچند اضطراب در بیماران توره شایع‌تر از جمعیت عادی است، اما پانیک همراهی شاخص و کلاسیک آن محسوب نمی‌شود."
 ],
 "why_en": [
  "A delusion is a fixed false belief belonging to psychotic disorders such as schizophrenia. It has no recognised link with Tourette syndrome.",
  "A hallucination is perception without an external stimulus, again a feature of psychotic disorders rather than a Tourette comorbidity.",
  "Correct — obsessive-compulsive disorder occurs in about half of Tourette patients and, with ADHD, is one of the syndrome's two main comorbidities.",
  "Panic attacks are an anxiety disorder. Although anxiety is commoner in Tourette than in the general population, panic is not its classic comorbidity."
 ],
 "golden_fa": "سه‌گانه‌ی توره: تیک + ADHD + وسواس فکری-عملی. حس فشار پیش از تیک، پل مفهومی آن با وسواس است.",
 "golden_en": "The Tourette triad: tics + ADHD + OCD. The premonitory urge is the conceptual bridge to OCD.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 11: Tics and Tourette syndrome",
  "Robertson MM. A personal 35 year perspective on Gilles de la Tourette syndrome. Lancet Psychiatry 2015;2:68-87"
 ]
}

L["1403-06:99"] = {
 "stem_en": "A 30-year-old woman presents in status epilepticus. Which of the following drugs should be given intravenously first?",
 "options_en": ["Sodium valproate", "Fosphenytoin", "Levetiracetam", "Lorazepam"],
 "micro": {
  "lead_fa": "خط اول حالت صرعی همیشه بنزودیازپین است، و در میان آن‌ها لورازپام وریدی به دلیل اثر طولانی‌ترش انتخاب اول است.",
  "lead_en": "First-line treatment of status epilepticus is always a benzodiazepine, and intravenous lorazepam is preferred for its longer duration.",
  "points_fa": [
   "حالت صرعی یعنی تشنج بیش از پنج دقیقه یا حملات پشت‌سرهم بدون بازگشت هوشیاری.",
   "هر دقیقه تأخیر، کنترل تشنج را سخت‌تر می‌کند چون گیرنده‌های گابا از سطح غشا برداشته می‌شوند.",
   "به همین دلیل بنزودیازپین باید در همان دقایق اول داده شود، نه پس از انجام آزمایش‌ها.",
   "بنزودیازپین‌ها گیرنده‌ی گابا-آ را تقویت می‌کنند و مهار سریع می‌سازند.",
   "لورازپام کمتر از دیازپام محلول در چربی است، پس آهسته‌تر از مغز خارج می‌شود.",
   "نتیجه اینکه اثر ضد تشنج لورازپام حدود ۱۲ ساعت می‌ماند، اما دیازپام تنها ۲۰ تا ۳۰ دقیقه.",
   "پس از بنزودیازپین باید بلافاصله داروی طولانی‌اثر وریدی شروع شود تا حمله برنگردد.",
   "فوس‌فنی‌توئین، والپروات و لوتیراستام همگی گزینه‌های خط دوم‌اند و اثربخشی مشابهی دارند.",
   "اگر راه وریدی در دسترس نباشد، میدازولام عضلانی جایگزین مناسبی است."
  ],
  "points_en": [
   "Status epilepticus means a seizure over five minutes, or repeated seizures without recovery between them.",
   "Every minute of delay makes control harder, because GABA receptors are internalised from the membrane.",
   "So the benzodiazepine must be given in the first minutes, not after the laboratory work-up.",
   "Benzodiazepines potentiate the GABA-A receptor and produce rapid inhibition.",
   "Lorazepam is less lipid-soluble than diazepam, so it leaves the brain more slowly.",
   "Its anticonvulsant effect therefore lasts about 12 hours, whereas diazepam lasts only 20-30 minutes.",
   "A longer-acting intravenous agent must follow immediately to prevent recurrence.",
   "Fosphenytoin, valproate and levetiracetam are all second-line and of comparable efficacy.",
   "If no intravenous access is available, intramuscular midazolam is a good alternative."
  ]
 },
 "explanation_fa": "کلمه‌ی «ابتدا» در صورت سؤال تعیین‌کننده است. هر چهار دارو در درمان حالت صرعی جایگاه دارند، اما ترتیبشان فرق می‌کند. خط اول همیشه بنزودیازپین است، چون سریع‌ترین اثر را دارد و هر دقیقه تأخیر اهمیت دارد: با ادامه‌ی تشنج، گیرنده‌های گابا از سطح غشای نورون برداشته می‌شوند و دارو کم‌اثرتر می‌شود. در میان بنزودیازپین‌ها لورازپام ترجیح دارد چون کمتر محلول در چربی است و آهسته‌تر از مغز خارج می‌شود، پس اثرش حدود دوازده ساعت می‌ماند در حالی که دیازپام تنها بیست تا سی دقیقه اثر می‌کند. سه گزینه‌ی دیگر داروهای خط دوم‌اند که بلافاصله پس از بنزودیازپین داده می‌شوند تا از بازگشت حمله جلوگیری کنند؛ مطالعه‌ی ESETT نشان داد اثربخشی فوس‌فنی‌توئین، والپروات و لوتیراستام تقریباً یکسان است.",
 "explanation_en": "The word 'first' decides this item. All four drugs have a place in status epilepticus, but the order differs. First-line is always a benzodiazepine because it acts fastest, and every minute counts: as the seizure continues, GABA receptors are internalised from the neuronal membrane and the drug becomes less effective. Among benzodiazepines lorazepam is preferred because it is less lipid-soluble and leaves the brain more slowly, so its effect lasts about twelve hours while diazepam lasts only twenty to thirty minutes. The other three are second-line agents given immediately after the benzodiazepine to prevent recurrence; the ESETT trial showed fosphenytoin, valproate and levetiracetam to be of essentially equal efficacy.",
 "why_fa": [
  "سدیم والپروات وریدی داروی خط دوم مؤثری است، اما پس از بنزودیازپین داده می‌شود. شروع اثر آن به اندازه‌ی بنزودیازپین سریع نیست.",
  "فوس‌فنی‌توئین پیش‌داروی فنی‌توئین است و می‌تواند سریع‌تر انفوزیون شود، اما همچنان خط دوم محسوب می‌شود.",
  "لوتیراستام وریدی هم خط دوم است و در مطالعه‌ی ESETT اثربخشی مشابه دو داروی دیگر داشت. جایگاهش پس از بنزودیازپین است.",
  "پاسخ صحیح — لورازپام وریدی خط اول حالت صرعی است. به دلیل حلالیت کمتر در چربی، اثر ضد تشنج آن حدود دوازده ساعت باقی می‌ماند."
 ],
 "why_en": [
  "Intravenous sodium valproate is an effective second-line agent but is given after the benzodiazepine. Its onset is not as fast.",
  "Fosphenytoin is a phenytoin prodrug that can be infused faster, but it remains a second-line drug.",
  "Intravenous levetiracetam is also second-line and performed comparably in the ESETT trial. Its place is after the benzodiazepine.",
  "Correct — intravenous lorazepam is first-line for status epilepticus. Being less lipid-soluble, its anticonvulsant effect lasts about twelve hours."
 ],
 "golden_fa": "اول بنزودیازپین، بعد داروی طولانی‌اثر. لورازپام بر دیازپام ترجیح دارد چون دوازده ساعت در مغز می‌ماند.",
 "golden_en": "Benzodiazepine first, then a long-acting agent. Lorazepam beats diazepam because it stays in the brain for twelve hours.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 12: Status epilepticus",
  "Glauser T et al. Evidence-based guideline: treatment of convulsive status epilepticus. Epilepsy Curr 2016;16:48-61",
  "Kapur J et al. Randomized trial of three anticonvulsant medications for status epilepticus (ESETT). N Engl J Med 2019;381:2103-13"
 ]
}
json.dump(L, io.open('/home/user/work/lessons/L1.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('batch 1:', len(L), 'lessons')
