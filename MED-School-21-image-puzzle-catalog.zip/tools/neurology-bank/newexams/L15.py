# -*- coding: utf-8 -*-
"""Micro-lessons, batch 15 — Esfand-1401 (the main sitting that was missing)."""
import json, io
L = {}

L["1401-12:114"] = {
 "stem_en": "A 10-year-old boy presents with attacks of headache, especially in the periorbital region, for the past year. The headaches last 4 to 6 hours and are sometimes accompanied by nausea and double vision. Family history of headache is positive. His examination is entirely normal with no papilloedema, and his MRI is normal. Given the most likely diagnosis, which cranial nerve is most commonly involved?",
 "options_en": ["Trigeminal", "Oculomotor", "Trochlear", "Abducens"],
 "micro": {
  "lead_fa": "میگرن با دوبینی در کودک یعنی میگرن افتالموپلژیک و شایع‌ترین عصب درگیر عصب سوم است.",
  "lead_en": "Migraine with diplopia in a child means ophthalmoplegic migraine, and the third nerve is most often involved.",
  "points_fa": [
   "میگرن افتالموپلژیک یک اختلال نادر است که بیشتر در کودکان و نوجوانان دیده می‌شود.",
   "تصویر آن سردرد میگرنی است که با فلج یکی از اعصاب حرکتی چشم همراه می‌شود.",
   "درد معمولاً پری‌اوربیتال است و ساعت‌ها پیش از فلج چشمی شروع می‌شود.",
   "شایع‌ترین عصب درگیر، عصب سوم یعنی اکولوموتور است.",
   "درگیری عصب سوم پتوز، انحراف چشم به خارج و پایین، و گاهی گشادی مردمک می‌دهد.",
   "فلج چشمی معمولاً طی روزها تا هفته‌ها به‌طور کامل برمی‌گردد.",
   "تشخیص فقط پس از رد کردن آنوریسم و ضایعه‌ی فضاگیر با تصویربرداری گذاشته می‌شود.",
   "طبیعی بودن MRI و نبود ادم پاپی در این بیمار همین رد کردن را انجام داده است.",
   "امروزه این اختلال را نوروپاتی کرانیال عودکننده‌ی دردناک هم می‌نامند."
  ],
  "points_en": [
   "Ophthalmoplegic migraine is a rare disorder seen mostly in children and adolescents.",
   "Its picture is a migrainous headache accompanied by palsy of an ocular motor nerve.",
   "The pain is usually periorbital and begins hours before the eye palsy.",
   "The nerve most often involved is the third, the oculomotor.",
   "Third nerve involvement gives ptosis, an eye deviated down and out, and sometimes a dilated pupil.",
   "The ocular palsy usually recovers fully over days to weeks.",
   "The diagnosis is made only after imaging excludes an aneurysm or mass lesion.",
   "The normal MRI and absent papilloedema in this patient have done exactly that.",
   "The disorder is now also called recurrent painful ophthalmoplegic neuropathy."
  ]
 },
 "explanation_fa": "این سؤال دو مرحله دارد. مرحله‌ی اول رسیدن به تشخیص است و صورت سؤال همه‌ی قطعات را داده: کودک با حملات سردرد یک‌ساله، مدت چهار تا شش ساعت، همراهی با تهوع، سابقه‌ی خانوادگی مثبت، معاینه‌ی طبیعی و MRI نرمال. این‌ها با هم میگرن را قطعی می‌کنند و همراهی دوبینی، آن را به فرم افتالموپلژیک می‌برد. مرحله‌ی دوم دانستن این است که کدام عصب بیشتر گرفتار می‌شود. سه عصب می‌توانند حرکت چشم را مختل کنند: سوم، چهارم و ششم. در میگرن افتالموپلژیک به‌طور مشخص عصب سوم شایع‌ترین است، و محل درد یعنی پری‌اوربیتال هم با همین می‌خواند. توجه کنید که عصب پنجم اصلاً عصب حرکتی چشم نیست، پس نمی‌تواند دوبینی بسازد.",
 "explanation_en": "This item has two steps. The first is reaching the diagnosis, and the stem supplies every piece: a child with a year of headache attacks lasting four to six hours, accompanied by nausea, with a positive family history, a normal examination and a normal MRI. Together these settle migraine, and the accompanying diplopia makes it the ophthalmoplegic form. The second step is knowing which nerve is most often affected. Three nerves can disturb eye movement: the third, fourth and sixth. In ophthalmoplegic migraine the third is distinctly the commonest, and the periorbital site of pain fits it too. Note that the fifth nerve is not an ocular motor nerve at all, so it cannot cause diplopia.",
 "why_fa": [
  "عصب تریژمینال حسی صورت و حرکتی عضلات جونده است. این عصب حرکت کره‌ی چشم را کنترل نمی‌کند، پس دوبینی نمی‌سازد.",
  "پاسخ صحیح — عصب اکولوموتور شایع‌ترین عصب درگیر در میگرن افتالموپلژیک است و پتوز و انحراف چشم می‌دهد.",
  "عصب تروکلئار فقط عضله‌ی مایل فوقانی را عصب می‌دهد و درگیری آن در این اختلال بسیار کمتر گزارش شده است.",
  "عصب ابدوسنس بیشتر در افزایش فشار داخل جمجمه درگیر می‌شود. نبود ادم پاپی و MRI طبیعی این احتمال را کم می‌کند."
 ],
 "why_en": [
  "The trigeminal nerve carries facial sensation and supplies the muscles of mastication. It does not move the globe, so it cannot cause diplopia.",
  "Correct — the oculomotor nerve is the commonest nerve involved in ophthalmoplegic migraine, producing ptosis and eye deviation.",
  "The trochlear nerve supplies only the superior oblique muscle and is far less often reported in this disorder.",
  "The abducens nerve is more often involved in raised intracranial pressure. The absent papilloedema and normal MRI make that unlikely."
 ],
 "golden_fa": "میگرن + دوبینی در کودک = افتالموپلژیک = عصب سوم. اول آنوریسم را با تصویربرداری رد کنید.",
 "golden_en": "Migraine plus diplopia in a child means ophthalmoplegic migraine and the third nerve; exclude an aneurysm by imaging first.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 6: Migraine variants",
  "Gelfand AA et al. Ophthalmoplegic migraine as a cranial neuropathy. Cephalalgia 2012;32:1117-21"
 ]
}

L["1401-12:115"] = {
 "stem_en": "When lamotrigine is added to which other drug must its starting dose be very low and its escalation much slower?",
 "options_en": ["Valproic acid", "Phenytoin", "Carbamazepine", "Phenobarbital"],
 "micro": {
  "lead_fa": "والپروات متابولیسم لاموتریژین را مهار می‌کند، پس سطح آن بالا می‌رود و خطر راش جدی زیاد می‌شود.",
  "lead_en": "Valproate inhibits lamotrigine metabolism, so its level rises and the risk of a serious rash climbs.",
  "points_fa": [
   "لاموتریژین از راه گلوکورونیداسیون در کبد پاک می‌شود، نه از راه سیتوکروم P450.",
   "والپروئیک اسید همین آنزیم گلوکورونیل ترانسفراز را مهار می‌کند.",
   "نتیجه این است که نیمه‌عمر لاموتریژین تقریباً دو برابر می‌شود.",
   "خطرناک‌ترین عارضه‌ی لاموتریژین بثورات پوستی جدی است.",
   "این شامل سندرم استیونس-جانسون و نکرولیز اپیدرمی سمی می‌شود.",
   "احتمال این عارضه مستقیماً به دوز شروع و سرعت افزایش دوز بستگی دارد.",
   "پس در ترکیب با والپروات باید دوز شروع نصف و تیتراسیون آهسته‌تر باشد.",
   "فنی‌توئین، کاربامازپین و فنوباربیتال برعکس القاکننده‌ی آنزیم‌اند.",
   "با آن‌ها سطح لاموتریژین پایین می‌آید و دوز بالاتری لازم می‌شود."
  ],
  "points_en": [
   "Lamotrigine is cleared by hepatic glucuronidation, not by cytochrome P450.",
   "Valproic acid inhibits that same glucuronyl transferase enzyme.",
   "The result is that lamotrigine's half-life roughly doubles.",
   "Lamotrigine's most dangerous adverse effect is a serious skin rash.",
   "This includes Stevens-Johnson syndrome and toxic epidermal necrolysis.",
   "The likelihood depends directly on the starting dose and the speed of escalation.",
   "So when combined with valproate the starting dose must be halved and titration slowed.",
   "Phenytoin, carbamazepine and phenobarbital are the opposite: enzyme inducers.",
   "With them lamotrigine levels fall and a higher dose is needed."
  ]
 },
 "explanation_fa": "این سؤال یک تداخل دارویی کلاسیک را می‌آزماید که پیامد بالینی واقعی و گاهی کشنده دارد. لاموتریژین با گلوکورونیداسیون کبدی دفع می‌شود. والپروئیک اسید این مسیر را مهار می‌کند، پس اگر دو دارو با هم داده شوند سطح خونی لاموتریژین به‌شدت بالا می‌رود. حالا چرا این مهم است؟ چون خطرناک‌ترین عارضه‌ی لاموتریژین بثورات پوستی شدید مثل سندرم استیونس-جانسون است و احتمال بروز آن مستقیماً با دوز شروع و سرعت افزایش دوز رابطه دارد. پس در حضور والپروات باید با نصف دوز معمول شروع کرد و بسیار آهسته‌تر بالا رفت. سه داروی دیگر دقیقاً برعکس‌اند: فنی‌توئین، کاربامازپین و فنوباربیتال همگی القاکننده‌ی آنزیمی‌اند و لاموتریژین را سریع‌تر پاک می‌کنند، پس با آن‌ها دوز بالاتر لازم است نه پایین‌تر.",
 "explanation_en": "This item tests a classic drug interaction with a real and sometimes fatal clinical consequence. Lamotrigine is eliminated by hepatic glucuronidation. Valproic acid inhibits that pathway, so giving the two together raises lamotrigine blood levels sharply. Why does that matter? Because lamotrigine's most dangerous adverse effect is a severe rash such as Stevens-Johnson syndrome, and its likelihood relates directly to the starting dose and speed of escalation. So in the presence of valproate you must start at half the usual dose and climb far more slowly. The other three drugs are exactly the opposite: phenytoin, carbamazepine and phenobarbital are all enzyme inducers that clear lamotrigine faster. So with them a higher dose is needed, not a lower one.",
 "why_fa": [
  "پاسخ صحیح — والپروئیک اسید گلوکورونیداسیون لاموتریژین را مهار و نیمه‌عمر آن را دو برابر می‌کند، پس دوز شروع باید نصف و تیتراسیون آهسته‌تر باشد.",
  "فنی‌توئین القاکننده‌ی آنزیمی است و سطح لاموتریژین را پایین می‌آورد. با آن دوز بالاتری لازم است، نه پایین‌تر.",
  "کاربامازپین هم القاکننده‌ی قوی است و کلیرانس لاموتریژین را بالا می‌برد، پس اثر معکوس والپروات دارد.",
  "فنوباربیتال نیز القاکننده‌ی آنزیمی است و سطح لاموتریژین را کاهش می‌دهد."
 ],
 "why_en": [
  "Correct — valproic acid inhibits lamotrigine glucuronidation and doubles its half-life, so the starting dose must be halved and titration slowed.",
  "Phenytoin is an enzyme inducer that lowers lamotrigine levels. With it a higher dose is needed, not a lower one.",
  "Carbamazepine is also a strong inducer that raises lamotrigine clearance, the opposite of valproate's effect.",
  "Phenobarbital is likewise an enzyme inducer and reduces lamotrigine levels."
 ],
 "golden_fa": "والپروات + لاموتریژین = سطح بالا = راش. نصف دوز، تیتراسیون آهسته.",
 "golden_en": "Valproate plus lamotrigine means high levels and rash: halve the dose and titrate slowly.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 12: Antiseizure drug interactions",
  "Patsalos PN, Perucca E. Clinically important drug interactions in epilepsy. Lancet Neurol 2003;2:347-56"
 ]
}

L["1401-12:116"] = {
 "stem_en": "A 50-year-old woman presents with a sudden hypertensive crisis. Her blood pressure on admission is 250/120 mmHg. If hypertensive encephalopathy develops, all of the following neurological features are common EXCEPT:",
 "options_en": ["Headache", "Visual disturbance", "Seizure", "Hemiparesis"],
 "micro": {
  "lead_fa": "انسفالوپاتی هایپرتنسیو اختلالی منتشر است؛ علامت کانونی مثل همی‌پارزی یعنی چیز دیگری در کار است.",
  "lead_en": "Hypertensive encephalopathy is a diffuse disorder; a focal sign like hemiparesis means something else is going on.",
  "points_fa": [
   "عروق مغز توانایی خودتنظیمی دارند و جریان خون را در بازه‌ی وسیعی از فشار ثابت نگه می‌دارند.",
   "وقتی فشار از سقف این بازه بگذرد، خودتنظیمی شکست می‌خورد.",
   "نتیجه پرخونی، نشت مایع از عروق و ادم واسوژنیک منتشر است.",
   "چون آسیب منتشر است، علائم هم منتشرند نه کانونی.",
   "شایع‌ترین علائم: سردرد، تهوع و استفراغ، گیجی و کاهش هوشیاری.",
   "اختلال بینایی شایع است چون نواحی اکسیپیتال بیشترین آسیب‌پذیری را دارند.",
   "همین توزیع اکسیپیتال، پایه‌ی نام سندرم PRES است.",
   "تشنج ژنرالیزه هم به دلیل تحریک‌پذیری منتشر قشر شایع است.",
   "بروز علامت کانونی باید شما را به سکته یا خون‌ریزی داخل مغزی ببرد."
  ],
  "points_en": [
   "Cerebral vessels autoregulate, holding blood flow constant across a wide pressure range.",
   "When pressure exceeds the ceiling of that range, autoregulation fails.",
   "The result is hyperperfusion, leakage from vessels and diffuse vasogenic oedema.",
   "Because the injury is diffuse, the symptoms are diffuse rather than focal.",
   "The commonest features: headache, nausea and vomiting, confusion and reduced consciousness.",
   "Visual disturbance is common because the occipital regions are most vulnerable.",
   "That occipital distribution underlies the name of the PRES syndrome.",
   "Generalised seizures are also common because of diffuse cortical irritability.",
   "A focal sign should send you looking for a stroke or intracerebral haemorrhage."
  ]
 },
 "explanation_fa": "برای حل این سؤال باید مکانیسم بیماری را بشناسید، نه فهرست علائم را حفظ کنید. در فشار خون بسیار بالا، خودتنظیمی عروق مغز شکست می‌خورد و مایع از عروق به بافت نشت می‌کند. این ادم در سراسر مغز پخش می‌شود، به‌ویژه در نواحی خلفی و اکسیپیتال که خون‌رسانی سمپاتیک کمتری دارند. حالا از این مکانیسم نتیجه بگیرید: چون آسیب منتشر است، علائم هم باید منتشر باشند. سردرد از کشیده شدن ساختارهای حساس به درد می‌آید، اختلال بینایی از درگیری اکسیپیتال، و تشنج از تحریک‌پذیری منتشر قشر. اما همی‌پارزی یک علامت کانونی است و با ادم منتشر توضیح داده نمی‌شود. اگر در بیمار با بحران فشار خون همی‌پارزی دیدید، باید فوراً به سکته‌ی ایسکمیک یا خون‌ریزی داخل مغزی فکر کنید، چون مدیریت فشار خون در آن دو کاملاً متفاوت است.",
 "explanation_en": "To solve this you need the mechanism rather than a memorised symptom list. At very high blood pressure, cerebral autoregulation fails and fluid leaks from vessels into tissue. This oedema spreads throughout the brain, especially in the posterior and occipital regions, which have less sympathetic innervation. Now reason from that mechanism: because the injury is diffuse, the symptoms must be diffuse. Headache comes from stretching pain-sensitive structures, visual disturbance from occipital involvement, and seizures from diffuse cortical irritability. Hemiparesis, however, is a focal sign and is not explained by diffuse oedema. If you see hemiparesis in a hypertensive crisis, think immediately of ischaemic stroke or intracerebral haemorrhage, because blood pressure management in those two is entirely different.",
 "why_fa": [
  "سردرد شایع‌ترین علامت انسفالوپاتی هایپرتنسیو است و از افزایش فشار داخل جمجمه و کشیده شدن ساختارهای حساس به درد می‌آید.",
  "اختلال بینایی از تاری تا کوری قشری شایع است، چون ادم بیشترین شدت را در نواحی اکسیپیتال دارد.",
  "تشنج ژنرالیزه از تحریک‌پذیری منتشر قشر ناشی می‌شود و از تظاهرات شناخته‌شده‌ی این حالت است.",
  "پاسخ صحیح — همی‌پارزی علامتی کانونی است و با ادم منتشر توضیح داده نمی‌شود. وجود آن سکته یا خون‌ریزی را مطرح می‌کند."
 ],
 "why_en": [
  "Headache is the commonest feature of hypertensive encephalopathy, from raised intracranial pressure stretching pain-sensitive structures.",
  "Visual disturbance from blurring to cortical blindness is common, because the oedema is most severe in occipital regions.",
  "Generalised seizures arise from diffuse cortical irritability and are a recognised manifestation.",
  "Correct — hemiparesis is a focal sign not explained by diffuse oedema. Its presence suggests a stroke or haemorrhage."
 ],
 "golden_fa": "انسفالوپاتی هایپرتنسیو = منتشر. علامت کانونی = سکته یا خون‌ریزی، نه خود انسفالوپاتی.",
 "golden_en": "Hypertensive encephalopathy is diffuse; a focal sign means stroke or haemorrhage, not the encephalopathy itself.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 13: Hypertensive encephalopathy",
  "Bartynski WS. Posterior reversible encephalopathy syndrome. AJNR 2008;29:1036-42"
 ]
}

L["1401-12:117"] = {
 "stem_en": "In a patient complaining of vertigo with nystagmus on examination, which finding favours a peripheral cause?",
 "options_en": ["The direction of the patient's fall matching the direction of the nystagmus",
                "Presence of vertical nystagmus",
                "Suppression of the nystagmus by visual fixation",
                "Mild but constant vertigo"],
 "micro": {
  "lead_fa": "مهار نیستاگموس با تثبیت نگاه یعنی مسیر بینایی می‌تواند جبران کند، و این نشانه‌ی محیطی بودن است.",
  "lead_en": "Suppression of nystagmus by fixation means vision can compensate, and that indicates a peripheral cause.",
  "points_fa": [
   "افتراق سرگیجه‌ی محیطی از مرکزی یکی از پرتکرارترین تصمیم‌های بالینی است.",
   "در ضایعه‌ی محیطی، دستگاه دهلیزی گوش داخلی یا عصب هشتم آسیب دیده است.",
   "چون مغز و مخچه سالم‌اند، مسیر بینایی می‌تواند بخشی از اختلال را جبران کند.",
   "پس با خیره شدن به یک نقطه، نیستاگموس محیطی کم می‌شود.",
   "با عینک فرنزل که تثبیت را حذف می‌کند، همان نیستاگموس آشکارتر می‌شود.",
   "نیستاگموس محیطی همیشه یک‌جهته و افقی-چرخشی است و جهتش تغییر نمی‌کند.",
   "نیستاگموس عمودی یا جهت‌عوض‌کن تقریباً همیشه مرکزی است.",
   "در سرگیجه‌ی محیطی بیمار به سمت گوش بیمار می‌افتد، یعنی خلاف فاز تند نیستاگموس.",
   "سرگیجه‌ی محیطی معمولاً شدید و حمله‌ای است؛ مرکزی خفیف‌تر ولی پایدارتر."
  ],
  "points_en": [
   "Separating peripheral from central vertigo is one of the commonest clinical decisions.",
   "In a peripheral lesion, the inner ear labyrinth or the eighth nerve is damaged.",
   "Because the brain and cerebellum are intact, vision can compensate for part of the disturbance.",
   "So fixing the gaze on a point reduces peripheral nystagmus.",
   "With Frenzel goggles, which remove fixation, that same nystagmus becomes more obvious.",
   "Peripheral nystagmus is always unidirectional and horizontal-torsional and never changes direction.",
   "Vertical or direction-changing nystagmus is almost always central.",
   "In peripheral vertigo the patient falls toward the affected ear, opposite the fast phase.",
   "Peripheral vertigo is usually severe and episodic; central vertigo is milder but more persistent."
  ]
 },
 "explanation_fa": "برای حل این سؤال یک اصل ساده کافی است: در ضایعه‌ی محیطی، پردازشگر مرکزی سالم است و می‌تواند جبران کند؛ در ضایعه‌ی مرکزی خود پردازشگر خراب است. حالا هر گزینه را با این اصل بسنجید. مهار نیستاگموس با تثبیت نگاه یعنی وقتی بیمار به نقطه‌ای خیره می‌شود، سیستم بینایی سالم وارد عمل می‌شود و عدم تقارن دهلیزی را می‌پوشاند. این فقط وقتی ممکن است که مغز سالم باشد، پس نشانه‌ی محیطی بودن است. عملاً هم از همین استفاده می‌شود: با عینک فرنزل تثبیت را حذف می‌کنید و نیستاگموس محیطی پررنگ‌تر می‌شود. سه گزینه‌ی دیگر همگی به مرکزی اشاره دارند: نیستاگموس عمودی تقریباً همیشه مرکزی است، سرگیجه‌ی خفیف ولی دائمی الگوی مرکزی است، و در سرگیجه‌ی محیطی جهت افتادن خلاف فاز تند نیستاگموس است نه یکسان با آن.",
 "explanation_en": "One simple principle solves this: in a peripheral lesion the central processor is intact and can compensate, whereas in a central lesion the processor itself is broken. Now test each option against it. Suppression of nystagmus by fixation means that when the patient stares at a point, the intact visual system steps in and masks the vestibular asymmetry. That is possible only if the brain is intact, so it indicates a peripheral cause. This is used in practice: remove fixation with Frenzel goggles and peripheral nystagmus becomes more prominent. The other three all point centrally: vertical nystagmus is almost always central, mild but constant vertigo is a central pattern. And in peripheral vertigo the fall is opposite the fast phase rather than matching it.",
 "why_fa": [
  "در سرگیجه‌ی محیطی بیمار به سمت گوش بیمار و خلاف فاز تند نیستاگموس می‌افتد. یکسان بودن این دو جهت الگوی محیطی نیست.",
  "نیستاگموس عمودی تقریباً همیشه نشانه‌ی ضایعه‌ی مرکزی در ساقه‌ی مغز یا مخچه است و هرگز محیطی محسوب نمی‌شود.",
  "پاسخ صحیح — مهار نیستاگموس با تثبیت بینایی نشان می‌دهد مسیرهای مرکزی سالم‌اند و می‌توانند جبران کنند، پس ضایعه محیطی است.",
  "سرگیجه‌ی خفیف ولی دائمی الگوی مرکزی است. سرگیجه‌ی محیطی معمولاً بسیار شدید و حمله‌ای و کوتاه‌مدت است."
 ],
 "why_en": [
  "In peripheral vertigo the patient falls toward the affected ear, opposite the fast phase. The two directions matching is not a peripheral pattern.",
  "Vertical nystagmus almost always indicates a central lesion in the brainstem or cerebellum and is never peripheral.",
  "Correct — suppression by visual fixation shows the central pathways are intact and able to compensate, so the lesion is peripheral.",
  "Mild but constant vertigo is a central pattern. Peripheral vertigo is usually very severe, episodic and short-lived."
 ],
 "golden_fa": "مهار با تثبیت = محیطی. نیستاگموس عمودی یا جهت‌عوض‌کن = مرکزی.",
 "golden_en": "Suppression by fixation means peripheral; vertical or direction-changing nystagmus means central.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 8: Vertigo, peripheral versus central",
  "Kattah JC et al. HINTS to diagnose stroke in the acute vestibular syndrome. Stroke 2009;40:3504-10"
 ]
}

L["1401-12:118"] = {
 "stem_en": "A 30-year-old woman in the second month of pregnancy presents to the emergency department with an acute headache. It is unilateral and accompanied by nausea, vomiting and photophobia. The headache began two days ago and paracetamol has helped temporarily. She reports a history of migraine before pregnancy. Her examination is normal and fundoscopy shows no papilloedema. Given the likely diagnosis, which treatment is preferred?",
 "options_en": ["Intravenous ergotamine", "Subcutaneous sumatriptan",
                "Intravenous valproate", "Intravenous chlorpromazine"],
 "micro": {
  "lead_fa": "در حمله‌ی میگرن در بارداری، ارگوتامین و والپروات ممنوع‌اند و کلروپرومازین ایمن‌ترین گزینه است.",
  "lead_en": "In a migraine attack during pregnancy, ergotamine and valproate are forbidden and chlorpromazine is the safest choice.",
  "points_fa": [
   "میگرن در بارداری معمولاً بهتر می‌شود، ولی حملات می‌توانند ادامه یابند.",
   "پیش از درمان باید علل ثانویه‌ی خطرناک بارداری رد شوند.",
   "مهم‌ترین آن‌ها ترومبوز سینوس وریدی، پره‌اکلامپسی و سکته است.",
   "معاینه‌ی طبیعی، نبود ادم پاپی و سابقه‌ی مشابه قبلی به نفع میگرن ساده است.",
   "خط اول درمان استامینوفن است که در این بیمار کافی نبوده است.",
   "ارگوتامین در بارداری منع مطلق دارد چون رحم را منقبض می‌کند.",
   "والپروات قوی‌ترین تراتوژن ضدصرع‌هاست و نقص لوله‌ی عصبی می‌سازد.",
   "متوکلوپرامید و کلروپرومازین هر دو در بارداری ایمن شمرده می‌شوند.",
   "این دو هم ضد تهوع‌اند و هم اثر مستقل ضد درد میگرن دارند."
  ],
  "points_en": [
   "Migraine usually improves in pregnancy, but attacks can continue.",
   "Before treating, dangerous pregnancy-specific secondary causes must be excluded.",
   "The most important are venous sinus thrombosis, pre-eclampsia and stroke.",
   "A normal examination, absent papilloedema and a matching prior history favour simple migraine.",
   "First-line treatment is paracetamol, which was insufficient in this patient.",
   "Ergotamine is absolutely contraindicated in pregnancy because it contracts the uterus.",
   "Valproate is the most potent teratogen among anticonvulsants and causes neural tube defects.",
   "Metoclopramide and chlorpromazine are both considered safe in pregnancy.",
   "Both are antiemetics and also have an independent antimigraine analgesic effect."
  ]
 },
 "explanation_fa": "این سؤال دو لایه دارد و لایه‌ی دوم مهم‌تر است. لایه‌ی اول تشخیص است که آسان است: سردرد یک‌طرفه با تهوع و فتوفوبی در بیماری با سابقه‌ی میگرن، معاینه‌ی طبیعی و بدون ادم پاپی، یعنی حمله‌ی میگرن. لایه‌ی دوم انتخاب دارویی ایمن در سه‌ماهه‌ی اول است. اینجا باید دو دارو را فوراً حذف کنید. ارگوتامین منع مصرف مطلق دارد چون آلکالوئید ارگوت رحم را منقبض می‌کند و خطر سقط و محدودیت رشد جنین دارد. والپروات هم شناخته‌شده‌ترین تراتوژن میان ضدصرع‌هاست و نقص لوله‌ی عصبی می‌سازد؛ اصلاً نباید در بارداری تجویز شود. می‌ماند سوماتریپتان و کلروپرومازین. سوماتریپتان امروز نسبتاً ایمن‌تر تلقی می‌شود اما انتخاب اول اورژانسی نیست. کلروپرومازین که یک فنوتیازین است هم تهوع را کنترل می‌کند و هم درد میگرن را، و در بارداری تجربه‌ی ایمنی طولانی دارد.",
 "explanation_en": "This item has two layers and the second matters more. The first is the diagnosis, which is easy: a unilateral headache with nausea and photophobia in someone with a migraine history, a normal examination and no papilloedema, means a migraine attack. The second is choosing a drug that is safe in the first trimester. Two options must be eliminated at once. Ergotamine is absolutely contraindicated because ergot alkaloids contract the uterus, risking miscarriage and fetal growth restriction. Valproate is the best-known teratogen among anticonvulsants and causes neural tube defects; it should never be prescribed in pregnancy. That leaves sumatriptan and chlorpromazine. Sumatriptan is now regarded as relatively safer but is not the first emergency choice. Chlorpromazine, a phenothiazine, controls both the nausea and the migraine pain and has a long safety record in pregnancy.",
 "why_fa": [
  "ارگوتامین در بارداری منع مصرف مطلق دارد. آلکالوئیدهای ارگوت رحم را منقبض می‌کنند و خطر سقط و محدودیت رشد جنین دارند.",
  "سوماتریپتان امروز نسبتاً ایمن‌تر از گذشته تلقی می‌شود، اما در اورژانس بارداری انتخاب اول نیست و شواهد آن کمتر است.",
  "والپروات تراتوژن شناخته‌شده‌ای است و نقص لوله‌ی عصبی و اختلال شناختی جنین می‌سازد. در بارداری هرگز نباید داده شود.",
  "پاسخ صحیح — کلروپرومازین تزریقی هم ضد تهوع است و هم ضد درد میگرن، و در بارداری بی‌خطرترین گزینه‌ی این فهرست است."
 ],
 "why_en": [
  "Ergotamine is absolutely contraindicated in pregnancy. Ergot alkaloids contract the uterus and risk miscarriage and fetal growth restriction.",
  "Sumatriptan is now considered relatively safer than before, but it is not the first emergency choice in pregnancy and its evidence base is smaller.",
  "Valproate is a well-known teratogen causing neural tube defects and fetal cognitive impairment. It must never be given in pregnancy.",
  "Correct — intravenous chlorpromazine is both an antiemetic and an antimigraine analgesic, and is the safest option on this list in pregnancy."
 ],
 "golden_fa": "میگرن در بارداری: استامینوفن، بعد کلروپرومازین یا متوکلوپرامید. ارگوتامین و والپروات ممنوع.",
 "golden_en": "Migraine in pregnancy: paracetamol, then chlorpromazine or metoclopramide. Ergotamine and valproate are forbidden.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 6: Headache in pregnancy",
  "Negro A et al. Headache and pregnancy: a systematic review. J Headache Pain 2017;18:106"
 ]
}

L["1401-12:119"] = {
 "stem_en": "Which of the following drugs can worsen the symptoms of restless legs syndrome?",
 "options_en": ["Fluoxetine", "Ropinirole", "Clonazepam", "Ferrous sulfate"],
 "micro": {
  "lead_fa": "سه گزینه درمان‌اند و فقط یکی تشدیدکننده؛ ضدافسردگی سروتونرژیک علائم را بدتر می‌کند.",
  "lead_en": "Three options are treatments and only one is an aggravator: serotonergic antidepressants worsen the symptoms.",
  "points_fa": [
   "سندرم پای بی‌قرار میل مقاومت‌ناپذیر به حرکت دادن پاها همراه با احساس ناخوشایند است.",
   "علائم در استراحت بدتر و با حرکت بهتر می‌شوند و شب‌ها اوج می‌گیرند.",
   "دو مکانیسم اصلی دارد: کمبود دوپامین مرکزی و کمبود آهن مغزی.",
   "آهن کوفاکتور تیروزین هیدروکسیلاز و لازم برای ساخت دوپامین است.",
   "پس اندازه‌گیری فریتین بخش الزامی بررسی است و زیر ۷۵ باید درمان شود.",
   "درمان دارویی: آگونیست دوپامین مثل پرامی‌پکسول و روپینیرول، یا لیگاند آلفا۲دلتا.",
   "بنزودیازپین‌ها مثل کلونازپام کیفیت خواب را بهتر می‌کنند.",
   "تشدیدکننده‌ها: ضدافسردگی‌های سروتونرژیک، آنتی‌هیستامین‌ها و ضد دوپامین‌ها.",
   "بوپروپیون تنها ضدافسردگی است که معمولاً علائم را بدتر نمی‌کند."
  ],
  "points_en": [
   "Restless legs syndrome is an irresistible urge to move the legs with an unpleasant sensation.",
   "Symptoms worsen at rest, improve with movement and peak at night.",
   "It has two main mechanisms: central dopamine deficiency and brain iron deficiency.",
   "Iron is a cofactor for tyrosine hydroxylase and is needed to synthesise dopamine.",
   "So measuring ferritin is a mandatory part of the workup, and a level under 75 should be treated.",
   "Drug treatment: dopamine agonists such as pramipexole and ropinirole, or alpha-2-delta ligands.",
   "Benzodiazepines such as clonazepam improve sleep quality.",
   "Aggravators: serotonergic antidepressants, antihistamines and dopamine antagonists.",
   "Bupropion is the one antidepressant that usually does not worsen symptoms."
  ]
 },
 "explanation_fa": "بهترین راه حل این سؤال، شناختن الگوی آن است: سه گزینه درمان‌اند و یکی تشدیدکننده. روپینیرول آگونیست دوپامین و خط اول درمان است. کلونازپام برای بهبود خواب استفاده می‌شود. فروس سولفات وقتی فریتین پایین است می‌تواند علائم را کاملاً برطرف کند، چون آهن برای ساخت دوپامین لازم است. فقط فلوکستین می‌ماند. مکانیسمش قابل استدلال است: فلوکستین یک مهارکننده‌ی بازجذب سروتونین است و افزایش سروتونین در مغز به‌طور غیرمستقیم انتقال دوپامینی را مهار می‌کند. چون خود بیماری از کمبود عملکرد دوپامین می‌آید، این کار علائم را بدتر می‌کند. نکته‌ی عملی مهم برای بالین: اگر بیماری با افسردگی و سندرم پای بی‌قرار همزمان دارید، بوپروپیون گزینه‌ی بهتری است چون اثر دوپامینرژیک دارد.",
 "explanation_en": "The best way to solve this is to recognise its pattern: three options are treatments and one is an aggravator. Ropinirole is a dopamine agonist and first-line therapy. Clonazepam is used to improve sleep. Ferrous sulfate can abolish symptoms entirely when ferritin is low, because iron is needed to make dopamine. That leaves fluoxetine. Its mechanism is reasonable: fluoxetine is a serotonin reuptake inhibitor, and raising brain serotonin indirectly inhibits dopaminergic transmission. Since the disease itself arises from deficient dopamine function, this makes symptoms worse. An important practical point: if a patient has both depression and restless legs syndrome, bupropion is a better choice because of its dopaminergic action.",
 "why_fa": [
  "پاسخ صحیح — فلوکستین با افزایش سروتونین، انتقال دوپامینی را مهار می‌کند و علائم سندرم پای بی‌قرار را تشدید می‌کند.",
  "روپینیرول آگونیست گیرنده‌ی دوپامین و از داروهای خط اول درمان این سندرم است، پس علائم را بهتر می‌کند نه بدتر.",
  "کلونازپام کیفیت خواب را بهتر می‌کند و به‌عنوان درمان کمکی در این سندرم به کار می‌رود.",
  "فروس سولفات وقتی فریتین پایین است درمان مؤثری است، چون آهن کوفاکتور ساخت دوپامین در مغز است."
 ],
 "why_en": [
  "Correct — fluoxetine raises serotonin, which inhibits dopaminergic transmission and aggravates restless legs syndrome.",
  "Ropinirole is a dopamine receptor agonist and a first-line treatment for this syndrome, so it improves rather than worsens symptoms.",
  "Clonazepam improves sleep quality and is used as adjunctive treatment in this syndrome.",
  "Ferrous sulfate is effective treatment when ferritin is low, because iron is a cofactor for dopamine synthesis in the brain."
 ],
 "golden_fa": "پای بی‌قرار: دوپامین کم + آهن کم. SSRI و آنتی‌هیستامین بدترش می‌کنند.",
 "golden_en": "Restless legs: low dopamine plus low iron. SSRIs and antihistamines make it worse.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 11: Restless legs syndrome",
  "Allen RP et al. Restless legs syndrome/Willis-Ekbom disease diagnostic criteria. Sleep Med 2014;15:860-73"
 ]
}

L["1401-12:120"] = {
 "stem_en": "A 50-year-old man with a 30-year history of bipolar disorder presents with bradykinesia and bilateral upper limb rest tremor on examination. All of the following drugs could be causing his parkinsonism EXCEPT:",
 "options_en": ["Haloperidol", "Lithium", "Sodium valproate", "Carbamazepine"],
 "micro": {
  "lead_fa": "پارکینسونیسم دارویی قرینه است و سریع می‌آید؛ کاربامازپین در فهرست عوامل آن نیست.",
  "lead_en": "Drug-induced parkinsonism is symmetric and comes on fast; carbamazepine is not on its list of causes.",
  "points_fa": [
   "پارکینسونیسم دارویی دومین علت شایع پارکینسونیسم پس از بیماری پارکینسون است.",
   "دو نشانه آن را از پارکینسون ایدیوپاتیک جدا می‌کند: تقارن دو طرف و شروع سریع‌تر.",
   "در این بیمار هم ترمور و برادی‌کینزی هر دو دوطرفه‌اند.",
   "شایع‌ترین عامل، آنتی‌سایکوتیک‌های تیپیک مثل هالوپریدول با مسدود کردن گیرنده‌ی D2 هستند.",
   "متوکلوپرامید هم یک عامل بسیار شایع و اغلب فراموش‌شده است.",
   "لیتیوم ترمور شایع می‌سازد و در مصرف طولانی علائم اکستراپیرامیدال هم می‌دهد.",
   "والپروات با مصرف مزمن پارکینسونیسم و ترمور برگشت‌پذیر ایجاد می‌کند.",
   "عوارض شاخص کاربامازپین متفاوت است: آتاکسی، دوبینی، هیپوناترمی و راش.",
   "پس از قطع داروی مسبب، بهبود ممکن است تا چند ماه طول بکشد."
  ],
  "points_en": [
   "Drug-induced parkinsonism is the second commonest cause of parkinsonism after Parkinson disease.",
   "Two features separate it from the idiopathic disease: bilateral symmetry and faster onset.",
   "In this patient both the tremor and bradykinesia are bilateral.",
   "The commonest culprits are typical antipsychotics such as haloperidol, which block D2 receptors.",
   "Metoclopramide is also a very common and often forgotten cause.",
   "Lithium commonly causes tremor and, with long use, extrapyramidal features too.",
   "Valproate with chronic use produces a reversible parkinsonism and tremor.",
   "Carbamazepine's characteristic adverse effects are different: ataxia, diplopia, hyponatraemia and rash.",
   "After stopping the offending drug, recovery may take several months."
  ]
 },
 "explanation_fa": "اول به الگو نگاه کنید، نه به فهرست داروها. بیمار برادی‌کینزی و ترمور استراحت دوطرفه دارد و سابقه‌ی سی‌ساله‌ی مصرف داروهای روان‌پزشکی. تقارن دو طرف مهم‌ترین سرنخ است، چون بیماری پارکینسون ایدیوپاتیک تقریباً همیشه یک‌طرفه شروع می‌شود و سال‌ها نامتقارن می‌ماند. پس این پارکینسونیسم دارویی است. حالا سه داروی مسبب را بشناسید: هالوپریدول به‌عنوان آنتی‌سایکوتیک تیپیک با مسدود کردن قوی گیرنده‌ی D2 کلاسیک‌ترین عامل است؛ لیتیوم ترمور و در مصرف طولانی علائم اکستراپیرامیدال می‌دهد؛ و والپروات پارکینسونیسم مزمن و برگشت‌پذیر می‌سازد که خیلی‌ها از آن غافل‌اند. کاربامازپین اما در این فهرست نیست. عوارض شاخص آن آتاکسی مخچه‌ای، دوبینی، هیپوناترمی و بثورات پوستی است، نه پارکینسونیسم.",
 "explanation_en": "Look at the pattern first, not the drug list. The patient has bradykinesia and bilateral rest tremor with thirty years of psychiatric medication. Bilateral symmetry is the crucial clue, because idiopathic Parkinson disease almost always begins unilaterally and stays asymmetric for years. So this is drug-induced parkinsonism. Now know the three culprits: haloperidol, a typical antipsychotic, is the classic cause through strong D2 blockade. Lithium causes tremor and, with long use, extrapyramidal features. And valproate produces a chronic reversible parkinsonism that many overlook. Carbamazepine is not on this list. Its characteristic effects are cerebellar ataxia, diplopia, hyponatraemia and rash, not parkinsonism.",
 "why_fa": [
  "هالوپریدول آنتی‌سایکوتیک تیپیک و شایع‌ترین عامل پارکینسونیسم دارویی است، چون گیرنده‌ی D2 را قوی مسدود می‌کند.",
  "لیتیوم به‌طور شایع ترمور می‌سازد و در مصرف طولانی‌مدت می‌تواند علائم اکستراپیرامیدال کامل بدهد.",
  "سدیم والپروات با مصرف مزمن پارکینسونیسم برگشت‌پذیری ایجاد می‌کند که پس از قطع دارو طی ماه‌ها بهتر می‌شود.",
  "پاسخ صحیح — کاربامازپین عامل شناخته‌شده‌ی پارکینسونیسم نیست. عوارض شاخص آن آتاکسی، دوبینی، هیپوناترمی و راش است."
 ],
 "why_en": [
  "Haloperidol is a typical antipsychotic and the commonest cause of drug-induced parkinsonism through strong D2 blockade.",
  "Lithium commonly causes tremor and with long-term use can produce full extrapyramidal features.",
  "Sodium valproate with chronic use causes a reversible parkinsonism that improves over months after stopping.",
  "Correct — carbamazepine is not a recognised cause of parkinsonism. Its characteristic effects are ataxia, diplopia, hyponatraemia and rash."
 ],
 "golden_fa": "پارکینسونیسم قرینه + دارو = پارکینسونیسم دارویی. هالوپریدول، لیتیوم، والپروات بله؛ کاربامازپین نه.",
 "golden_en": "Symmetric parkinsonism plus medication means drug-induced: haloperidol, lithium and valproate yes, carbamazepine no.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 11: Drug-induced parkinsonism",
  "Shin HW, Chung SJ. Drug-induced parkinsonism. J Clin Neurol 2012;8:15-21"
 ]
}

L["1401-12:121"] = {
 "stem_en": "All of the following features favour a stroke in the vertebrobasilar territory EXCEPT:",
 "options_en": ["Ataxia", "Dysphagia", "Amaurosis fugax", "Cortical blindness"],
 "micro": {
  "lead_fa": "آموروزیس فوگاکس از شریان افتالمیک می‌آید که شاخه‌ی کاروتید است، پس علامت گردش قدامی است.",
  "lead_en": "Amaurosis fugax arises from the ophthalmic artery, a carotid branch, so it is an anterior circulation sign.",
  "points_fa": [
   "مغز دو منبع خونی دارد: گردش قدامی از کاروتیدها و گردش خلفی از ورتبرال‌ها.",
   "گردش قدامی نیمکره‌ها، چشم و بیشتر قشر حرکتی و حسی را تغذیه می‌کند.",
   "گردش خلفی ساقه‌ی مغز، مخچه، تالاموس و لوب اکسیپیتال را تغذیه می‌کند.",
   "شریان افتالمیک اولین شاخه‌ی شریان کاروتید داخلی است.",
   "پس هر علامت چشمی یک‌طرفه از جنس کوری گذرا، به کاروتید اشاره دارد.",
   "آموروزیس فوگاکس مهم‌ترین علامت هشدار تنگی کاروتید است.",
   "آتاکسی از درگیری مخچه می‌آید که خون خود را از گردش خلفی می‌گیرد.",
   "دیس‌فاژی از هسته‌های بولبار در مدولا می‌آید که باز هم خلفی است.",
   "کوری کورتیکال از انفارکت دوطرفه‌ی اکسیپیتال یعنی هر دو شریان مغزی خلفی است."
  ],
  "points_en": [
   "The brain has two blood supplies: anterior from the carotids and posterior from the vertebrals.",
   "The anterior circulation feeds the hemispheres, the eye and most motor and sensory cortex.",
   "The posterior circulation feeds the brainstem, cerebellum, thalamus and occipital lobe.",
   "The ophthalmic artery is the first branch of the internal carotid artery.",
   "So any unilateral transient visual loss points to the carotid.",
   "Amaurosis fugax is the most important warning sign of carotid stenosis.",
   "Ataxia comes from cerebellar involvement, supplied by the posterior circulation.",
   "Dysphagia comes from the bulbar nuclei in the medulla, again posterior.",
   "Cortical blindness comes from bilateral occipital infarction, that is both posterior cerebral arteries."
  ]
 },
 "explanation_fa": "این سؤال یک نکته‌ی آناتومیک را می‌آزماید که تشخیص آن نیازمند دانستن مسیر شریان‌هاست. آموروزیس فوگاکس یعنی کوری گذرای یک چشم که بیماران اغلب آن را «پرده‌ای که پایین آمد» توصیف می‌کنند. علت آن آمبولی به شریان افتالمیک است، و شریان افتالمیک اولین شاخه‌ی شریان کاروتید داخلی است. پس این علامت کاملاً به گردش خون قدامی تعلق دارد و در واقع مهم‌ترین علامت هشدار تنگی کاروتید است؛ دیدن آن باید فوراً شما را به سمت سونوگرافی داپلر کاروتید ببرد. سه گزینه‌ی دیگر همگی خلفی‌اند: آتاکسی از مخچه، دیس‌فاژی از هسته‌های بولبار مدولا، و کوری کورتیکال از انفارکت هر دو لوب اکسیپیتال. یک تله‌ی مهم را هم توجه کنید: کوری کورتیکال دوطرفه است و خلفی، در حالی که آموروزیس یک‌طرفه است و قدامی؛ هر دو مشکل بینایی‌اند ولی از دو قلمرو کاملاً متفاوت.",
 "explanation_en": "This item tests an anatomical point that requires knowing the arterial route. Amaurosis fugax is transient loss of vision in one eye, which patients often describe as a curtain coming down. Its cause is an embolus to the ophthalmic artery, and the ophthalmic artery is the first branch of the internal carotid. So this sign belongs entirely to the anterior circulation and is in fact the most important warning sign of carotid stenosis. Seeing it should send you straight to carotid Doppler ultrasound. The other three are all posterior: ataxia from the cerebellum, dysphagia from the bulbar nuclei of the medulla, and cortical blindness from infarction of both occipital lobes. Note one important trap: cortical blindness is bilateral and posterior, whereas amaurosis is unilateral and anterior; both are visual problems but from entirely different territories.",
 "why_fa": [
  "آتاکسی از درگیری مخچه یا مسیرهای آن می‌آید و مخچه از شریان‌های مخچه‌ای که شاخه‌ی سیستم ورتبروبازیلارند خون می‌گیرد.",
  "دیس‌فاژی از درگیری هسته‌های بولبار در مدولا ناشی می‌شود، مثلاً در سندرم والنبرگ که انفارکت خلفی کلاسیک است.",
  "پاسخ صحیح — آموروزیس فوگاکس از آمبولی به شریان افتالمیک می‌آید که شاخه‌ی کاروتید داخلی است، پس علامت گردش قدامی است.",
  "کوری کورتیکال از انفارکت دوطرفه‌ی لوب اکسیپیتال ناشی می‌شود که هر دو شریان مغزی خلفی را درگیر می‌کند و کاملاً خلفی است."
 ],
 "why_en": [
  "Ataxia comes from the cerebellum or its pathways, and the cerebellum is fed by cerebellar arteries branching off the vertebrobasilar system.",
  "Dysphagia arises from the bulbar nuclei in the medulla, as in Wallenberg syndrome, the classic posterior infarct.",
  "Correct — amaurosis fugax comes from an embolus to the ophthalmic artery, a branch of the internal carotid, so it is an anterior circulation sign.",
  "Cortical blindness results from bilateral occipital infarction involving both posterior cerebral arteries and is entirely posterior."
 ],
 "golden_fa": "آموروزیس فوگاکس = کاروتید = قدامی. آتاکسی، دیس‌فاژی، کوری کورتیکال = خلفی.",
 "golden_en": "Amaurosis fugax means carotid and anterior; ataxia, dysphagia and cortical blindness mean posterior.",
 "refs": [
  "Aminoff MJ, Greenberg DA, Simon RP. Clinical Neurology, 11th ed (2021) — Ch. 13: Anterior versus posterior circulation stroke",
  "Biousse V, Trobe JD. Transient monocular visual loss. Am J Ophthalmol 2005;140:717-21"
 ]
}

json.dump(L, io.open('/home/user/work/lessons/L15.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('L15:', len(L))
