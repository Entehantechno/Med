# -*- coding: utf-8 -*-
"""Neurology block of the Khordad-1402 mid-term paper (q114..q121).

The user supplied the ministry's own Persian AND English booklets for this sitting
(exam code 020318), so stem_en/options_en are taken verbatim from the official
English paper for the six items it contains. The Persian booklet carries two extra
neurology items (sensory ataxia, Parkinson treatment) that the English one omits;
those keep Persian only.

Persian text was read by OCR — the embedded text layer of this PDF mangles many
letters. No full key was published for this mid-term sitting, so answers are
derived from Aminoff 2021 and tagged accordingly.
"""
import json, io, os
LET = ['الف','ب','ج','د']
OUT = '/home/user/work/out'; os.makedirs(OUT, exist_ok=True)

Q = [
 dict(n=114,
  fa="کدام‌یک از اختلالات سردرد زیر در مردان شایع‌تر از زنان است؟",
  fo=["خوشه‌ای", "میگرن", "افزایش فشار داخل جمجمه ایدیوپاتیک", "تنشی"],
  en="Which of the following headache disorders is more prevalent among males compared to females?",
  eo=["Cluster", "Migraine", "Idiopathic intracranial hypertension", "Tension"],
  ans=0,
  why="سردرد خوشه‌ای تنها سردرد اولیه‌ای است که در مردان شایع‌تر است، با نسبت حدود سه به یک. "
      "میگرن و سردرد تنشی هر دو در زنان شایع‌ترند، و افزایش فشار ایدیوپاتیک تقریباً منحصر به "
      "زنان جوان با اضافه‌وزن است."),
 dict(n=115,
  fa="در کدام‌یک از علل ایجادکننده کاهش هوشیاری، هایپرترمی دیده می‌شود؟",
  fo=["مسمومیت با اوپیوم", "مسمومیت با داروهای آنتی‌کولینرژیک",
      "مسمومیت با الکل", "مسمومیت با باربیتورات‌ها"],
  en="Hyperthermia is seen in which of the following causes of coma?",
  eo=["Opium toxicity", "Overdose with anticholinergic drugs",
      "Alcohol toxicity", "Overdose with barbiturates"],
  ans=1,
  why="سندرم آنتی‌کولینرژیک با یک جمله‌ی یادیار شناخته می‌شود: داغ مثل خرگوش صحرایی، قرمز مثل چغندر، "
      "خشک مثل استخوان، کور مثل خفاش و دیوانه مثل کلاه‌دوز. مهار تعریق راه اصلی دفع گرما را می‌بندد، "
      "پس دمای بدن بالا می‌رود. سه مسمومیت دیگر همگی سرکوب‌کننده‌اند و هیپوترمی می‌سازند."),
 dict(n=116,
  fa="آقای ۷۵ ساله‌ای با شکایت همی‌پارزی راست از یک ساعت قبل به اورژانس مراجعه کرده است. وجود کدام علامت بالینی بیشتر به نفع تشخیص سکته مغزی هموراژیک در مقایسه با سکته مغزی ایسکمیک می‌باشد؟",
  fo=["افت هوشیاری", "سردرد و استفراغ", "آفازی", "تشنج"],
  en="A 75-year-old male presented to the emergency ward with right side hemiparesis since one hour ago. Which symptom is more probable in intracranial hemorrhage in comparison to ischemic stroke?",
  eo=["Loss of consciousness", "Headache and vomiting", "Aphasia", "Seizure"],
  ans=1,
  why="خون‌ریزی داخل مغزی توده‌ای اضافه می‌سازد و فشار داخل جمجمه را بالا می‌برد. همین افزایش فشار "
      "سردرد و استفراغ می‌دهد که در ساعات اول سکته‌ی ایسکمیک نادر است. آفازی به محل ضایعه بستگی "
      "دارد نه به نوع آن، و افت هوشیاری در هر دو ممکن است."),
 dict(n=117,
  fa="خانم ۶۵ ساله به دلیل پارستزی دیستال اندام‌های تحتانی از یک سال گذشته که تدریجاً تا زیر زانو گسترش داشته، مراجعه کرده است. سابقه پرفشاری خون و دیابت ملیتوس از ۸ سال قبل دارد. در معاینات نورولوژیک، معاینه اعصاب کرانیال و قدرت عضلانی طبیعی است. رفلکس‌های وتری اندام فوقانی کاهش یافته است و در اندام تحتانی وجود ندارد. با توجه به محتمل‌ترین تشخیص، کدام‌یک از موارد زیر صحیح است؟",
  fo=["تغییرات اتونوم دیده نمی‌شود",
      "اختلال حس عمقی و آتاکسی حسی از علایم بیماری است",
      "وجود آتروفی در معاینه به ضرر تشخیص است",
      "در اغلب بیماران علامت بابنسکی دیده می‌شود"],
  en="A 65-year-old lady presented with complaints of progressive paresthesia in distal lower limbs, reaching below the knees since last year. She has been diagnosed with hypertension and diabetes since 8 years ago. Neurologic examination shows intact cranial nerve and motor forces. Deep tendon reflexes are decreased in both upper limb and absent in lower limbs. With regard to the most possible diagnosis, which statement is TRUE?",
  eo=["Autonomic involvement is not seen.",
      "Abnormal position sense and sensory ataxia is one of the disease symptoms.",
      "Muscle atrophy in examination is against the diagnosis.",
      "Babinski sign is frequently detected."],
  ans=1,
  why="پلی‌نوروپاتی دیابتی رشته‌های ضخیم را هم درگیر می‌کند، و همین حس عمقی را از بین می‌برد و "
      "آتاکسی حسی می‌سازد. سه گزینه‌ی دیگر غلط‌اند: درگیری اتونوم در دیابت بسیار شایع است، "
      "آتروفی در موارد پیشرفته دیده می‌شود، و بابنسکی مثبت نشانه‌ی درگیری نورون حرکتی فوقانی "
      "است که با نوروپاتی محیطی نمی‌خواند."),
 dict(n=118,
  fa="در مورد حمله تشنجی غیاب (ابسانس)، کدام مورد زیر صحیح است؟",
  fo=["حین تشنج هوشیاری حفظ می‌شود",
      "از دست رفتن کنترل اندام‌ها حین تشنج از مشخصات بیماری است",
      "گیجی (پست‌ایکتال) طولانی پس از تشنج وجود دارد",
      "پلک زدن سریع، حرکات جویدن و نشانه‌های خفیف حرکتی در حین تشنج دیده می‌شود"],
  en="Which of the following statements is TRUE about absence seizure?",
  eo=["Consciousness is maintained during seizure.",
      "Loss of limb control occurs during seizure.",
      "Long postictal phase is a feature of this seizure.",
      "Frequent blinking, automatism, and fine limb movements can be observed during the seizure."],
  ans=3,
  why="ابسانس تیپیک حملات چندثانیه‌ای با قطع ناگهانی آگاهی است، اما تون عضلانی حفظ می‌شود پس "
      "بیمار نمی‌افتد. در حدود دو سوم موارد نشانه‌های حرکتی ظریف مثل پلک زدن سریع، حرکات جویدن "
      "و اتوماتیسم دیده می‌شود. نبود دوره‌ی پس از تشنج، مشخصه‌ی افتراقی مهم آن از تشنج کانونی است."),
 dict(n=119,
  fa="خانم جوان ۲۵ ساله با شکایت تاری دید چشم راست از یک هفته قبل مراجعه کرده است. بیمار اظهار می‌دارد با خم کردن گردن دچار احساس شوک برقی در اندام‌ها می‌شود. با توجه به محتمل‌ترین تشخیص، کدام روش زیر جهت تایید تشخیص بیماری کمک‌کننده است؟",
  fo=["مطالعه الکترودیاگنوستیک (نوار عصب-عضله)", "الکتروانسفالوگرافی (نوار مغز)",
      "بررسی مایع مغزی نخاعی", "سی‌تی‌اسکن مغز"],
  en="A 25-year-old young lady presented with complaints of unilateral blurred vision since last week. She has experienced shock-like sensation in limbs with neck flexion. Regarding the most possible diagnosis, which of the following tests is helpful to confirm the diagnosis?",
  eo=["Electrodiagnostic study (EMG-NCS)", "Electroencephalography (EEG)",
      "Cerebrospinal fluid (CSF) examination", "Brain CT-scan"],
  ans=2,
  why="نوریت اپتیک در زن جوان به‌همراه علامت لرمیت یعنی دو ضایعه در دو جای متفاوت سیستم عصبی "
      "مرکزی، که تشخیص ام‌اس را مطرح می‌کند. از میان گزینه‌ها فقط بررسی مایع نخاع کمک‌کننده است، "
      "چون باندهای الیگوکلونال را نشان می‌دهد. سی‌تی برای دیدن پلاک دمیلینه ناکافی است؛ آزمون "
      "ارجح MRI است که در گزینه‌ها نیامده."),
 dict(n=120,
  fa="کدام علامت در معاینه نورولوژیک، به نفع آتاکسی حسی در مقایسه با آتاکسی مخچه‌ای می‌باشد؟",
  fo=["نیستاگموس", "انحراف به یک سمت حین ایستادن",
      "افتادن با چشم‌های باز", "بلند کردن و کوبیدن محکم پاها به زمین"],
  ans=3,
  why="در آتاکسی حسی مغز نمی‌داند پاها کجا هستند، پس بیمار آن‌ها را بلند می‌کند و محکم به زمین "
      "می‌کوبد تا بازخورد حسی بیشتری بگیرد؛ به این راه رفتن stamping gait می‌گویند. نیستاگموس "
      "نشانه‌ی مخچه است، و افتادن با چشم باز هم مخچه‌ای است چون در آتاکسی حسی بیمار با چشم باز "
      "جبران می‌کند و فقط با بستن چشم می‌افتد (رومبرگ مثبت)."),
 dict(n=121,
  fa="آقایی ۷۰ ساله از یک سال قبل دچار لرزش دست حین استراحت، کندی حرکات و رژیدیتی اندام‌ها شده است. با توجه به محتمل‌ترین تشخیص، کدام درمان ارجح است؟",
  fo=["آمانتادین", "لوودوپا-کربی‌دوپا", "پرامی‌پکسول (آگونیست دوپامین)", "تری‌هگزی‌فنیدیل"],
  ans=1,
  why="در بیمار مسن‌تر از ۶۵ تا ۷۰ سال، لوودوپا-کربی‌دوپا درمان انتخابی پارکینسون است. آگونیست‌های "
      "دوپامین در این سن خطر توهم، گیجی و افت فشار وضعیتی را بالا می‌برند و بیشتر برای بیماران "
      "جوان‌تر نگه داشته می‌شوند. آنتی‌کولینرژیک‌هایی مثل تری‌هگزی‌فنیدیل در سالمندان به دلیل "
      "اثر بر شناخت باید پرهیز شوند."),
]

out=[]
for q in Q:
    rec = {'exam':'خرداد ۱۴۰۲','exam_tag':'1402-03','question_no':q['n'],
           'stem_fa':q['fa'],'options_fa':q['fo'],
           'correct_index':q['ans'],'correct_letter':LET[q['ans']],
           'key_source':'derived_aminoff','key_rationale':q['why'],
           'source_file':'soalat pishkarvarzi FA/EN 020318'}
    if q.get('en'):
        rec.update({'stem_en':q['en'],'options_en':q['eo'],
                    'en_source':'official_english_booklet'})
    out.append(rec)
    mark = '🇬🇧' if q.get('en') else '  '
    print(f"{mark} q{q['n']}: {LET[q['ans']]}) {q['fo'][q['ans']][:45]}")
json.dump(out, io.open(f'{OUT}/neuro_1402_03.json','w',encoding='utf-8'),
          ensure_ascii=False, indent=1)
print(f"\nsaved {len(out)} | with official English: {sum(1 for r in out if r.get('en_source'))}")
