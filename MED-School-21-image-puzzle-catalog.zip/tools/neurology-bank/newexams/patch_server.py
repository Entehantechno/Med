# -*- coding: utf-8 -*-
"""Teach the official-question importer that subjects have a major/minor track.

The pre-internship exam splits its subjects in two. The four MAJORS (internal
medicine, surgery, paediatrics, obstetrics) carry most of the questions and marks;
everything else — neurology included — is a MINOR. The importer used to hard-code
every imported subject as "major", which mislabelled the neurology bank.

Idempotent: running it twice changes nothing.
"""
import io, sys

ADMIN = '/home/user/project/server/src/routes/admin.js'
TEST = '/home/user/project/server/test/api.test.js'

OLD_TOPIC = '''function officialTopic({ program, subject_fa, subject_en }, dryRun = false) {
  const slug = `official-${officialSlug(subject_en || subject_fa)}`;
  const row = db.prepare("SELECT * FROM topics WHERE slug=?").get(slug);
  if (row) return row;
  if (dryRun) return { id: `dry-topic:${slug}`, slug, name_fa: subject_fa || "سؤالات رسمی", name_en: subject_en || "Official questions" };
  const maxOrd = db.prepare("SELECT COALESCE(MAX(ord),0) m FROM topics WHERE program=?").get(program).m || 0;
  const info = db.prepare("INSERT INTO topics (slug,name_fa,name_en,parent,budget,color,icon,ord,active,program) VALUES (?,?,?,?,?,?,?,?,1,?)")
    .run(slug, subject_fa || subject_en || "سؤالات رسمی", subject_en || subject_fa || "Official questions", "major", 0, "#6d5bd0", "book", maxOrd + 1, program);
  return db.prepare("SELECT * FROM topics WHERE id=?").get(info.lastInsertRowid);
}'''

NEW_TOPIC = '''// The pre-internship exam splits its subjects into two tracks. The four majors
// (internal medicine, surgery, paediatrics, obstetrics) carry far more questions and
// marks than the minors, which include neurology, psychiatry, ENT, ophthalmology and
// the rest. An importer may state the track per question via `subject_track`; when it
// does not, fall back to the known major list instead of assuming "major".
const OFFICIAL_MAJOR_SUBJECTS = new Set([
  "internal medicine", "surgery", "pediatrics", "paediatrics",
  "obstetrics", "obstetrics and gynecology", "gynecology",
  "داخلی", "جراحی", "کودکان", "زنان", "زنان و زایمان",
]);
function officialTrack({ subject_fa, subject_en, subject_track }) {
  if (subject_track === "major" || subject_track === "minor") return subject_track;
  const fa = String(subject_fa || "").trim().toLowerCase();
  const en = String(subject_en || "").trim().toLowerCase();
  return (OFFICIAL_MAJOR_SUBJECTS.has(fa) || OFFICIAL_MAJOR_SUBJECTS.has(en)) ? "major" : "minor";
}
function officialTopic({ program, subject_fa, subject_en, subject_track }, dryRun = false) {
  const slug = `official-${officialSlug(subject_en || subject_fa)}`;
  const row = db.prepare("SELECT * FROM topics WHERE slug=?").get(slug);
  if (row) return row;
  const track = officialTrack({ subject_fa, subject_en, subject_track });
  if (dryRun) return { id: `dry-topic:${slug}`, slug, parent: track, name_fa: subject_fa || "سؤالات رسمی", name_en: subject_en || "Official questions" };
  const maxOrd = db.prepare("SELECT COALESCE(MAX(ord),0) m FROM topics WHERE program=?").get(program).m || 0;
  const info = db.prepare("INSERT INTO topics (slug,name_fa,name_en,parent,budget,color,icon,ord,active,program) VALUES (?,?,?,?,?,?,?,?,1,?)")
    .run(slug, subject_fa || subject_en || "سؤالات رسمی", subject_en || subject_fa || "Official questions", track, 0, "#6d5bd0", "book", maxOrd + 1, program);
  return db.prepare("SELECT * FROM topics WHERE id=?").get(info.lastInsertRowid);
}'''

PLAN_OLD = ("plan.push({ fingerprint: fp, question_no: q.question_no || plan.length + 1, "
            "duplicate, overflow, route: data.source_meta.route, subject_fa: q.subject_fa, "
            "chapter_fa: q.chapter_fa, part, data });")
PLAN_NEW = ("plan.push({ fingerprint: fp, question_no: q.question_no || plan.length + 1, "
            "duplicate, overflow, route: data.source_meta.route, subject_fa: q.subject_fa, "
            "chapter_fa: q.chapter_fa, part,\n"
            "      // surface the resolved topic so a reviewer can see which exam track the\n"
            "      // subject lands in (major vs minor) before committing the import\n"
            "      topic: { slug: topic.slug, parent: topic.parent, name_fa: topic.name_fa }, data });")

CALLS = [
 ('const topic = officialTopic({ program, subject_fa: q.subject_fa || body.subject_fa, subject_en: q.subject_en || body.subject_en }, true);',
  'const topic = officialTopic({ program, subject_fa: q.subject_fa || body.subject_fa, subject_en: q.subject_en || body.subject_en, subject_track: q.subject_track || body.subject_track }, true);'),
 ('const topic = officialTopic({ program, subject_fa: d.source_meta.subject_fa, subject_en: d.source_meta.subject_en }, false);',
  'const topic = officialTopic({ program, subject_fa: d.source_meta.subject_fa, subject_en: d.source_meta.subject_en, subject_track: d.source_meta.subject_track }, false);'),
]

TEST_ANCHOR = '''  it("preview keeps why_fa on every option and marks the right answer", async () => {'''

TEST_NEW = '''  it("files an imported subject under its exam track, not always major", async () => {
    // Neurology is a MINOR subject of the pre-internship exam; only internal
    // medicine, surgery, paediatrics and obstetrics are majors. The importer used
    // to hard-code "major" for everything.
    const tk = await token("admin");
    const minor = await request(app).post("/api/admin/official-question-import/preview")
      .set("Authorization", `Bearer ${tk}`).send(sample());
    expect(minor.status).toBe(200);
    expect(minor.body.plan[0].topic.parent).toBe("minor");

    const majorBody = sample();
    majorBody.subject_fa = "داخلی";
    majorBody.subject_en = "Internal medicine";
    majorBody.questions[0].subject_fa = "داخلی";
    majorBody.questions[0].subject_en = "Internal medicine";
    const major = await request(app).post("/api/admin/official-question-import/preview")
      .set("Authorization", `Bearer ${tk}`).send(majorBody);
    expect(major.status).toBe(200);
    expect(major.body.plan[0].topic.parent).toBe("major");

    // an explicit subject_track always wins over the name-based guess
    const forced = sample();
    forced.subject_track = "major";
    const res = await request(app).post("/api/admin/official-question-import/preview")
      .set("Authorization", `Bearer ${tk}`).send(forced);
    expect(res.status).toBe(200);
    expect(res.body.plan[0].topic.parent).toBe("major");
  });

  it("preview keeps why_fa on every option and marks the right answer", async () => {'''


def patch(path, pairs, label):
    s = io.open(path, encoding='utf-8').read()
    done = 0
    for old, new in pairs:
        if new in s:
            continue
        if old not in s:
            print(f'  !! anchor missing in {label}: {old[:60]}...')
            continue
        s = s.replace(old, new, 1)
        done += 1
    io.open(path, 'w', encoding='utf-8').write(s)
    return done


n = patch(ADMIN, [(OLD_TOPIC, NEW_TOPIC), (PLAN_OLD, PLAN_NEW)] + CALLS, 'admin.js')
m = patch(TEST, [(TEST_ANCHOR, TEST_NEW)], 'api.test.js')
print(f'admin.js: {n} edit(s) | api.test.js: {m} edit(s)')
