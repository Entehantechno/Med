#!/usr/bin/env python3
"""Split over-long sentences in the authored lessons.

Rationale (PEDAGOGY.md §8): difficulty must come from retrieval effort, not from
tangled prose. Long sentences add extraneous cognitive load and hurt learning.

The script is conservative: it only splits at connectives where a full stop keeps
the meaning intact, and it never touches text that is already within limits. Any
sentence it cannot split safely is reported so a human can rewrite it.
"""
import json, os, re, sys

BASE = os.path.dirname(os.path.abspath(__file__))
MAX_FA, MAX_EN = 34, 28
# validate.py also caps the *mean* prose sentence length of a field. A text can
# sit under the per-sentence cap and still read as a wall of long sentences, so
# we run a second, stricter pass that pulls the average down to these targets.
# They are set one word below the validator's limits to leave a safety margin.
MEAN_FA, MEAN_EN = 25, 23

# Persian connectives that almost always start an independent clause.
FA_SPLITS = [
    (r'، که ', '. این '),
    (r'، یعنی ', '. یعنی '),
    (r'، و در ', '. در '),
    (r'، و به ', '. به '),
    (r'، و همین ', '. همین '),
    (r'، به همین دلیل ', '. به همین دلیل '),
    (r'، بنابراین ', '. بنابراین '),
    (r'، در نتیجه ', '. در نتیجه '),
    (r'، پس ', '. پس '),
    (r'، اما ', '. اما '),
    (r'، ولی ', '. ولی '),
    (r'، در حالی که ', '. در مقابل، '),
    (r'، ضمناً ', '. ضمناً '),
    (r'، همچنین ', '. همچنین '),
    (r'؛ ', '. '),
    (r'، و ', '. '),
    # em-dash asides read as a second sentence; split them last so the
    # meaning-preserving connectives above always win.
    (r' — به همین دلیل ', '. به همین دلیل '),
    (r' — یعنی ', '. یعنی '),
    (r' — ', '. '),
    # a colon that introduces a full clause (not a list) is a sentence boundary
    (r'COLON', '. '),
]
EN_SPLITS = [
    (r', and its ', '. Its '),
    (r', and the ', '. The '),
    (r', and that ', '. That '),
    (r', which means ', '. This means '),
    (r', making ', '. This makes '),
    (r', giving ', '. This gives '),
    (r', with ', '. It has '),
    (r', although ', '. Although '),
    (r', though ', '. Although '),
    (r', and this ', '. This '),
    (r', so ', '. So '),
    (r', which is why ', '. That is why '),
    (r', therefore ', '. Therefore '),
    (r', but ', '. But '),
    (r', whereas ', '. By contrast, '),
    (r', while ', '. Meanwhile, '),
    (r'; ', '. '),
    (r', because ', '. This is because '),
    (r', since ', '. This is because '),
    (r', and ', '. '),
    (r' — which is why ', '. That is why '),
    (r' — that is ', '. That is '),
    (r' — ', '. '),
    (r'COLON', '. '),
]


def _colon_matches(sentence):
    """Colon positions that introduce a clause rather than a list.

    Splitting "reason: because X" into two sentences reads naturally, but doing
    the same to "three nuclei: A, B and C" would leave a dangling fragment, so
    we skip colons whose tail looks like an enumeration.
    """
    out = []
    for m in re.finditer(r':\s+', sentence):
        tail = sentence[m.end():]
        if tail.count('\u060c') + tail.count(',') >= 2:
            continue
        out.append(m)
    return out


def sents(text):
    parts = re.split(r'(?<=[.!?؟])\s+', text)
    return [p for p in parts if p.strip()]


def wc(s):
    return len(s.split())


def split_long(sentence, lang):
    """Try to break one long sentence into shorter ones."""
    limit = MAX_FA if lang == 'fa' else MAX_EN
    rules = FA_SPLITS if lang == 'fa' else EN_SPLITS
    if wc(sentence) <= limit:
        return [sentence]
    for pat, rep in rules:
        m = _colon_matches(sentence) if pat == 'COLON' else list(re.finditer(pat, sentence))
        if not m:
            continue
        # split at the connective nearest the middle for the most even halves
        mid = len(sentence) / 2
        best = min(m, key=lambda x: abs(x.start() - mid))
        head = sentence[:best.start()].rstrip(' ،,;؛')
        # keep exactly one space between the connective and the rest of the clause
        tail = rep.lstrip() + sentence[best.end():].lstrip()
        if wc(head) < 4 or wc(tail) < 4:
            continue
        head = head.rstrip('.') + '.'
        out = []
        for piece in (head, tail):
            out.extend(split_long(piece.strip(), lang))
        return out
    return [sentence]


def _validator_sentences(text):
    """Mirror validate.py's sentence splitter so we measure what it measures."""
    parts = re.split(r'[.!?؟\n]+|؛', text)
    return [p.strip() for p in parts if len(p.strip().split()) > 2]


def _is_list_sentence(s):
    """Same enumeration exemption validate.py applies."""
    if ':' not in s and '\u2014' not in s:
        return False
    tail = s.split(':', 1)[-1]
    return tail.count('\u060c') + tail.count(',') >= 2


def _mean_prose(text):
    prose = [s for s in _validator_sentences(text) if not _is_list_sentence(s)]
    if not prose:
        return 0.0, []
    return sum(wc(s) for s in prose) / len(prose), prose


def reduce_mean(text, lang):
    """Second pass: keep splitting the longest sentence until the mean fits.

    The per-sentence pass leaves texts that are technically legal yet still read
    heavily, because every sentence sits just under the cap. Here we repeatedly
    take the longest sentence and try to break it, stopping as soon as the mean
    is inside target or nothing more can be split safely.
    """
    target = MEAN_FA if lang == 'fa' else MEAN_EN
    rules = FA_SPLITS if lang == 'fa' else EN_SPLITS
    changed = 0
    for _ in range(12):
        mean, prose = _mean_prose(text)
        if mean <= target or not prose:
            break
        longest = max(prose, key=wc)
        if wc(longest) < 12:      # nothing left worth breaking
            break
        replacement = None
        for pat, rep in rules:
            m = _colon_matches(longest) if pat == 'COLON' else list(re.finditer(pat, longest))
            if not m:
                continue
            mid = len(longest) / 2
            best = min(m, key=lambda x: abs(x.start() - mid))
            head = longest[:best.start()].rstrip(' ،,;؛')
            tail = rep.lstrip() + longest[best.end():].lstrip()
            if wc(head) < 4 or wc(tail) < 4:
                continue
            replacement = head.rstrip('.') + '. ' + tail
            break
        if replacement is None:
            break
        text = text.replace(longest, replacement, 1)
        changed += 1
    return text, changed


def fix(text, lang, rounds=2):
    if not text:
        return text, 0
    out, changed = [], 0
    for s in sents(text):
        pieces = split_long(s, lang)
        if len(pieces) > 1:
            changed += 1
        out.extend(pieces)
    result = ' '.join(out)
    result, n2 = reduce_mean(result, lang)
    changed += n2
    result = re.sub(r'\s+', ' ', result).strip()
    result = re.sub(r'\.\s*\.', '.', result)
    # guard against words fused during splitting
    result = re.sub(r'([.!?؟])([^\s\d])', r'\1 \2', result)
    result = re.sub(r'\s+([.،؛,])', r'\1', result)
    result = re.sub(r'\s+', ' ', result).strip()
    return result, changed


def main():
    path = os.path.join(BASE, 'bank.json')
    bank = json.load(open(path, encoding='utf-8'))
    total, stubborn = 0, []

    for r in bank:
        if not r.get('explanation_fa'):
            continue
        for key, lang in [('explanation_fa', 'fa'), ('explanation_en', 'en'),
                          ('golden_fa', 'fa'), ('golden_en', 'en')]:
            if r.get(key):
                new, n = fix(r[key], lang)
                r[key] = new
                total += n
        for key, lang in [('why_fa', 'fa'), ('why_en', 'en')]:
            if r.get(key):
                fixed = []
                for w in r[key]:
                    new, n = fix(w, lang)
                    fixed.append(new)
                    total += n
                r[key] = fixed
        m = r.get('micro') or {}
        for lang in ('fa', 'en'):
            for key in (f'lead_{lang}',):
                if m.get(key):
                    new, n = fix(m[key], lang)
                    m[key] = new
                    total += n
            pts = m.get(f'points_{lang}') or []
            newpts = []
            for pt in pts:
                new, n = fix(pt, lang)
                newpts.append(new)
                total += n
            if pts:
                m[f'points_{lang}'] = newpts

        # report anything still over the limit
        for key, lang in [('explanation_fa', 'fa'), ('explanation_en', 'en'),
                          ('golden_fa', 'fa'), ('golden_en', 'en')]:
            if not r.get(key):
                continue
            lim = MAX_FA if lang == 'fa' else MAX_EN
            for s in sents(r[key]):
                if wc(s) > lim:
                    stubborn.append(f"{r['uid']}.{key}: {wc(s)} words — {s[:60]}...")

    json.dump(bank, open(path, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(f'split {total} long sentence(s)')
    if stubborn:
        print(f'\n⚠️  {len(stubborn)} sentence(s) still too long — needs a human rewrite:')
        for s in stubborn[:20]:
            print('   ', s)
    return 0


if __name__ == '__main__':
    sys.exit(main())
