#!/usr/bin/env python3
"""Merge authored lesson files (lessons/*.json) into bank.json."""
import json, glob, os

BASE = os.path.dirname(os.path.abspath(__file__))
FIELDS = ('stem_en', 'options_en', 'micro', 'explanation_fa', 'explanation_en',
          'why_fa', 'why_en', 'golden_fa', 'golden_en', 'refs')

def main():
    path = os.path.join(BASE, 'bank.json')
    bank = json.load(open(path, encoding='utf-8'))
    by_uid = {r['uid']: r for r in bank}
    merged, unknown = 0, []
    for f in sorted(glob.glob(os.path.join(BASE, 'lessons', '*.json'))):
        for uid, les in json.load(open(f, encoding='utf-8')).items():
            if uid not in by_uid:
                unknown.append(uid); continue
            r = by_uid[uid]
            for k in FIELDS:
                if k in les:
                    r[k] = les[k]
            merged += 1
    json.dump(bank, open(path, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    done = sum(1 for r in bank if r.get('explanation_fa'))
    en   = sum(1 for r in bank if r.get('stem_en'))
    mic  = sum(1 for r in bank if r.get('micro'))
    print(f'merged {merged} lesson(s)')
    if unknown: print(f'  ⚠️ unknown uids: {unknown}')
    print(f'  FA lessons: {done}/{len(bank)} ({done/len(bank):.0%})')
    print(f'  EN complete: {en}/{len(bank)} | micro-lessons: {mic}/{len(bank)}')

if __name__ == '__main__':
    main()
