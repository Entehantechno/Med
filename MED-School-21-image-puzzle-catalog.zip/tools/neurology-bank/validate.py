#!/usr/bin/env python3
"""Quality gate for the neurology question bank.

Checks every authored lesson for structural and content errors that are easy to
introduce by hand and hard to spot by eye. Exits non-zero when a hard error is
found so it can be wired into CI.
"""
import json, os, re, sys

BASE = os.path.dirname(os.path.abspath(__file__))
LETTERS = ['الف', 'ب', 'ج', 'د']
MIN_EXPL = 400          # a real teaching note, not a one-liner
MIN_WHY = 40            # each distractor needs a real reason
MIN_GOLDEN = 40
MIN_LEAD = 40           # the micro-lesson one-liner
MIN_POINTS = 4          # teaching points per micro-lesson
REQUIRED_REF = 'Aminoff'  # the agreed primary reference for neurology

# The 16 chapters the source book actually contains. Chapter 7 was recovered
# after it was found merged into chapter 6 (see README "خطاهای منبع").
EXPECTED_CHAPTERS = {
    'فصل اول', 'فصل دوم', 'فصل سوم', 'فصل چهارم', 'فصل پنجم', 'فصل ششم',
    'فصل هفتم', 'فصل هشتم', 'فصل نهم', 'فصل دهم', 'فصل یازدهم', 'فصل دوازدهم',
    'فصل سیزدهم', 'فصل چهاردهم', 'فصل پانزدهم', 'فصل شانزدهم', 'فصل هفدهم',
}

# --- readability limits (see PEDAGOGY.md §8) -----------------------------
# Difficulty must come from retrieval effort, not from tangled prose.
# Calibrated against the authored corpus (median sentence = 17 words in both
# languages). The caps target the long tail — the sentences that genuinely tax a
# reader — rather than penalising normal explanatory prose.
MAX_SENT_WORDS_FA = 34   # Persian runs longer than English for the same content
MAX_SENT_WORDS_EN = 30
MAX_MEAN_WORDS_FA = 26
MAX_MEAN_WORDS_EN = 24


def sentences(text, lang):
    import re as _re
    parts = _re.split(r'[.!?؟\n]+|؛', text)
    return [p.strip() for p in parts if len(p.strip().split()) > 2]


def _is_list_sentence(s):
    """A 'label: a, b, c' enumeration reads as a visual list, not as prose, so the
    plain word count overstates its difficulty. We allow these to run longer."""
    import re as _re
    if ':' not in s and '\u2014' not in s:
        return False
    tail = s.split(':', 1)[-1]
    return tail.count('\u060c') + tail.count(',') >= 2


def readability_problems(text, lang, label, uid):
    """Flag sentences that are too long to read comfortably."""
    out = []
    ss = sentences(text, lang)
    if not ss:
        return out
    # enumerations get a 50% allowance
    ss_prose = [s for s in ss if not _is_list_sentence(s)]
    ss_list = [s for s in ss if _is_list_sentence(s)]
    lim = MAX_SENT_WORDS_FA if lang == 'fa' else MAX_SENT_WORDS_EN
    mean_lim = MAX_MEAN_WORDS_FA if lang == 'fa' else MAX_MEAN_WORDS_EN
    list_lim = int(lim * 1.5)

    for s in ss_prose:
        n = len(s.split())
        if n > lim:
            out.append(f"{uid}: {label} has a {n}-word prose sentence (limit {lim}): "
                       f"\u00ab{s[:70]}...\u00bb")
    for s in ss_list:
        n = len(s.split())
        if n > list_lim:
            out.append(f"{uid}: {label} has a {n}-word enumeration (limit {list_lim}): "
                       f"\u00ab{s[:70]}...\u00bb")
    if ss_prose:
        mean = sum(len(s.split()) for s in ss_prose) / len(ss_prose)
        if mean > mean_lim:
            out.append(f"{uid}: {label} mean prose sentence {mean:.1f} words "
                       f"(limit {mean_lim})")
    return out

def main():
    bank = json.load(open(os.path.join(BASE, 'bank.json'), encoding='utf-8'))
    errors, warnings = [], []
    seen_stems = {}

    for r in bank:
        uid = r['uid']

        # ---- structural checks that apply to every row -------------------
        if len(r['options_fa']) != 4:
            errors.append(f"{uid}: expected 4 options, found {len(r['options_fa'])}")
        if not isinstance(r['correct_index'], int) or not 0 <= r['correct_index'] <= 3:
            errors.append(f"{uid}: correct_index out of range: {r['correct_index']!r}")
        if any(not str(o).strip() for o in r['options_fa']):
            errors.append(f"{uid}: has an empty option")
        if len(r['stem_fa'].strip()) < 20:
            errors.append(f"{uid}: stem is suspiciously short")

        # duplicate stems across the bank (same question imported twice)
        key = re.sub(r'\s+', '', r['stem_fa'])[:120]
        if key in seen_stems:
            warnings.append(f"{uid}: stem looks like a duplicate of {seen_stems[key]}")
        else:
            seen_stems[key] = uid

        # Chapter-integrity guard. The source PDF prints one chapter heading
        # without its colon ("فصل هفتمعوارض..."), which made the extractor miss
        # chapter 7 entirely and file its questions under chapter 6. Pin the
        # expected chapter set so a future re-extraction cannot silently lose a
        # chapter again.
        if r['chapter_num'] not in EXPECTED_CHAPTERS:
            errors.append(f"{uid}: unknown chapter {r['chapter_num']!r}")

        # reversed-digit regression guard: Persian exam years must be 85..99
        y = r.get('exam_year', '')
        if y:
            n = int(''.join(str('۰۱۲۳۴۵۶۷۸۹'.index(c)) for c in y))
            ok = (85 <= n <= 99) if len(y) == 2 else (1400 <= n <= 1410)
            if not ok:
                errors.append(f"{uid}: implausible exam year {y} (digit reversal?)")

        # ---- lesson checks only for rows that have one --------------------
        if not r.get('explanation_fa'):
            continue

        if len(r.get('explanation_fa')) < MIN_EXPL:
            errors.append(f"{uid}: explanation too short ({len(r.get('explanation_fa'))} chars)")

        why = r.get('why_fa') or []
        if len(why) != 4:
            errors.append(f"{uid}: why_fa must have 4 entries, found {len(why)}")
        else:
            for i, w in enumerate(why):
                if len(w.strip()) < MIN_WHY:
                    errors.append(f"{uid}: why_fa[{i}] ({LETTERS[i]}) too short")
            ci = r['correct_index']
            # the rationale of the correct option must mark it as correct
            if 'پاسخ صحیح' not in why[ci]:
                errors.append(f"{uid}: why_fa[{ci}] should start with 'پاسخ صحیح' (correct option)")
            # and no distractor may claim to be correct
            for i, w in enumerate(why):
                if i != ci and 'پاسخ صحیح' in w:
                    errors.append(f"{uid}: why_fa[{i}] wrongly claims to be the correct answer")

        if len(r.get('golden_fa', '')) < MIN_GOLDEN:
            errors.append(f"{uid}: golden tip missing or too short")
        if not r.get('refs'):
            errors.append(f"{uid}: no references")
        elif not any(REQUIRED_REF in ref for ref in r.get('refs')):
            errors.append(f"{uid}: references must include {REQUIRED_REF} (agreed primary source)")

        # ---- English completeness -----------------------------------------
        if not r.get('stem_en'):
            errors.append(f"{uid}: missing English stem")
        opts_en = r.get('options_en') or []
        if len(opts_en) != len(r['options_fa']):
            errors.append(f"{uid}: options_en must mirror options_fa "
                          f"({len(opts_en)} vs {len(r['options_fa'])})")
        elif any(not o.strip() for o in opts_en):
            errors.append(f"{uid}: an English option is empty")
        if not r.get('explanation_en'):
            errors.append(f"{uid}: missing English explanation")
        if len(r.get('golden_en', '')) < MIN_GOLDEN:
            errors.append(f"{uid}: English golden tip missing or too short")
        why_en = r.get('why_en') or []
        if len(why_en) != 4 or any(len(w.strip()) < MIN_WHY for w in why_en):
            errors.append(f"{uid}: why_en incomplete")
        else:
            ci = r['correct_index']
            if 'Correct' not in why_en[ci]:
                errors.append(f"{uid}: why_en[{ci}] should start with 'Correct'")
            for i, w in enumerate(why_en):
                if i != ci and w.strip().startswith('Correct'):
                    errors.append(f"{uid}: why_en[{i}] wrongly claims to be correct")

        # ---- readability -----------------------------------------------
        for txt, lang, label in [
            (r.get('explanation_fa'), 'fa', 'explanation_fa'),
            (r.get('explanation_en', ''), 'en', 'explanation_en'),
            (r.get('golden_fa', ''), 'fa', 'golden_fa'),
            (r.get('golden_en', ''), 'en', 'golden_en'),
        ]:
            if txt:
                errors.extend(readability_problems(txt, lang, label, uid))
        m0 = r.get('micro') or {}
        for lang in ('fa', 'en'):
            for i, pt in enumerate(m0.get(f'points_{lang}') or []):
                errors.extend(readability_problems(pt, lang, f'micro.points_{lang}[{i}]', uid))

        # ---- micro-lesson (درسنامه) ----------------------------------------
        m = r.get('micro') or {}
        if not m:
            errors.append(f"{uid}: missing micro-lesson block")
        else:
            for lang in ('fa', 'en'):
                if len(m.get(f'lead_{lang}', '')) < MIN_LEAD:
                    errors.append(f"{uid}: micro lead_{lang} missing or too short")
                pts = m.get(f'points_{lang}') or []
                if len(pts) < MIN_POINTS:
                    errors.append(f"{uid}: micro points_{lang} needs ≥{MIN_POINTS} "
                                  f"teaching points (has {len(pts)})")
                elif any(len(p.strip()) < 30 for p in pts):
                    errors.append(f"{uid}: a micro points_{lang} entry is too short")

    done = sum(1 for r in bank if r.get('explanation_fa'))
    print(f"bank: {len(bank)} questions | lessons authored: {done} ({done/len(bank):.0%})")
    for w in warnings:
        print(f"  ⚠️  {w}")
    if errors:
        print(f"\n❌ {len(errors)} error(s):")
        for e in errors:
            print(f"  - {e}")
        return 1
    print("✅ all authored lessons pass the quality gate")
    return 0

if __name__ == '__main__':
    sys.exit(main())
