/* ================================================================
   flashcard-types.test.js — KF / puzzle persist, drawing approve-reject,
   questionnaires admin does not 500.
   ================================================================ */
import { describe, it, expect, beforeAll } from "vitest";
import { execSync } from "child_process";
import request from "supertest";
import { initDb } from "../src/db.js";
import { createApp } from "../src/app.js";

let app;
const login = (u, p = "demo") => request(app).post("/api/auth/login").send({ username: u, password: p });
async function token(u, p = "demo") { return (await login(u, p)).body.token; }
const A = (tk) => ({ Authorization: `Bearer ${tk}` });

beforeAll(async () => {
  execSync("node src/seed.js --force", { cwd: process.cwd(), stdio: "ignore" });
  await initDb();
  app = createApp();
});

describe("questionnaires admin", () => {
  it("lists forms and responses for a teacher (the tab that used to white-screen)", async () => {
    const tk = await token("teacher");
    const forms = await request(app).get("/api/questionnaires/admin/forms").set(A(tk));
    expect(forms.status).toBe(200);
    expect(Array.isArray(forms.body.forms)).toBe(true);
    const resp = await request(app).get("/api/questionnaires/admin/responses").set(A(tk));
    expect(resp.status).toBe(200);
    expect(Array.isArray(resp.body.responses)).toBe(true);
  });
});

describe("flashcard KF and puzzle payloads persist", () => {
  it("stores a Key Feature card with vignette + items", async () => {
    const tk = await token("teacher");
    const created = await request(app).post("/api/flashcards").set(A(tk)).send({
      title_fa: "کی‌اف نمونه", title_en: "KF sample", type: "kf", difficulty: "medium",
      kf: {
        vignette_fa: "آقای ۴۵ ساله با درد قفسه سینه",
        vignette_en: "45-year-old man with chest pain",
        items: [
          { kind: "short", prompt_fa: "تشخیص محتمل؟", prompt_en: "Likely dx?", answer_fa: "STEMI", answer_en: "STEMI", accept_fa: ["MI"], accept_en: ["MI"] },
          { kind: "mcq", prompt_fa: "اولین اقدام؟", prompt_en: "First step?", options_fa: ["ECG", "CXR", "CT", "MRI"], options_en: ["ECG", "CXR", "CT", "MRI"], correct: 0 },
        ],
      },
    });
    expect(created.status).toBe(200);
    expect(created.body.id).toBeTruthy();
    const list = await request(app).get("/api/flashcards").set(A(tk));
    const card = list.body.find((c) => c.id === created.body.id);
    expect(card.type).toBe("kf");
    expect(card.kf.vignette_fa).toContain("درد قفسه سینه");
    expect(card.kf.items.length).toBe(2);
    expect(card.kf.items[1].correct).toBe(0);
  });

  it("stores an image-label puzzle card", async () => {
    const tk = await token("teacher");
    const created = await request(app).post("/api/flashcards").set(A(tk)).send({
      title_fa: "پازل بافت", title_en: "Histology puzzle", type: "puzzle",
      imageUrl: "/uploads/demo-histo.png",
      puzzle: {
        imageUrl: "/uploads/demo-histo.png",
        pins: [
          { x: 32, y: 40, label_fa: "گلومرول", label_en: "Glomerulus" },
          { x: 70, y: 55, label_fa: "توبول", label_en: "Tubule" },
        ],
        distractors_fa: ["کپسول بومن"],
        distractors_en: ["Bowman capsule"],
      },
    });
    expect(created.status).toBe(200);
    const list = await request(app).get("/api/flashcards").set(A(tk));
    const card = list.body.find((c) => c.id === created.body.id);
    expect(card.type).toBe("puzzle");
    expect(card.puzzle.pins.length).toBe(2);
    expect(card.puzzle.pins[0].label_en).toBe("Glomerulus");
    expect(card.puzzle.distractors_en).toContain("Bowman capsule");
  });
});

describe("drawing approve / reject inbox", () => {
  it("teacher inbox is empty-ok, student is forbidden", async () => {
    const ttk = await token("teacher");
    const inbox = await request(app).get("/api/classes/drawing-inbox").set(A(ttk));
    expect(inbox.status).toBe(200);
    expect(Array.isArray(inbox.body.reviews)).toBe(true);
    const stk = await token("40012345");
    const denied = await request(app).get("/api/classes/drawing-inbox").set(A(stk));
    expect(denied.status).toBe(403);
  });

  it("pending drawing stays unscored until the teacher approves it", async () => {
    const ttk = await token("teacher");
    const users = (await request(app).get("/api/users").set(A(ttk))).body;
    const stu = users.find((u) => u.username === "40012345");
    const card = await request(app).post("/api/flashcards").set(A(ttk)).send({
      title_fa: "رسم بافت", title_en: "Draw tissue", type: "drawing",
      drawing: { prompt_fa: "بافت پوششی سنگفرشی را بکشید", prompt_en: "Draw squamous epithelium", rubric_fa: ["لایه"], rubric_en: ["layer"] },
    });
    expect(card.status).toBe(200);
    const cid = (await request(app).post("/api/classes").set(A(ttk))
      .send({ name_en: "Draw class", name_fa: "کلاس نقاشی" })).body.id;
    await request(app).put(`/api/classes/${cid}/members`).set(A(ttk)).send({ userIds: [stu.id] });
    const put = await request(app).put(`/api/classes/${cid}/flashcards`).set(A(ttk))
      .send({ flashcards: [{ flashcard_id: card.body.id, graded: true, weight: 1 }] });
    expect(put.status).toBe(200);

    const stk = await token("40012345");
    const finish = await request(app).post(`/api/classes/${cid}/flashcard/${card.body.id}/finish`).set(A(stk)).send({
      score: 0,
      durationSec: 30,
      answers: [{
        order: 1, card_id: card.body.id, type: "drawing",
        question_fa: "بافت پوششی سنگفرشی را بکشید", question_en: "Draw squamous epithelium",
        solved: true, points: 0, proposedPoints: 80, pendingApproval: true,
        drawing: { preview: "data:image/png;base64,aaa", strokeCount: 4, pointsFrac: 0.8, approval: { status: "pending" } },
      }],
    });
    expect(finish.status).toBe(200);
    expect(finish.body.score).toBe(0);

    const inbox = await request(app).get("/api/classes/drawing-inbox").set(A(ttk));
    expect(inbox.status).toBe(200);
    const row = inbox.body.reviews.find((r) => r.classId === cid && r.status === "pending");
    expect(row).toBeTruthy();
    expect(row.proposedPoints).toBe(80);

    const approve = await request(app)
      .post(`/api/classes/${cid}/drawing-reviews/${row.attemptId}/${row.answerIndex}`)
      .set(A(ttk)).send({ status: "approved", points: 80, feedback: "خوب" });
    expect(approve.status).toBe(200);
    expect(approve.body.score).toBe(80);
    expect(approve.body.review.status).toBe("approved");

    const after = await request(app).get("/api/classes/drawing-inbox").set(A(ttk));
    const updated = after.body.reviews.find((r) => r.attemptId === row.attemptId && r.answerIndex === row.answerIndex);
    expect(updated.status).toBe("approved");
    expect(updated.points).toBe(80);
  });

  it("rejecting a drawing keeps the attempt at zero", async () => {
    const ttk = await token("teacher");
    const users = (await request(app).get("/api/users").set(A(ttk))).body;
    const stu = users.find((u) => u.username === "40067890");
    const card = await request(app).post("/api/flashcards").set(A(ttk)).send({
      title_fa: "رسم رد", title_en: "Reject draw", type: "drawing",
      drawing: { prompt_fa: "بکش", prompt_en: "Draw" },
    });
    const cid = (await request(app).post("/api/classes").set(A(ttk))
      .send({ name_en: "Reject class", name_fa: "رد" })).body.id;
    await request(app).put(`/api/classes/${cid}/members`).set(A(ttk)).send({ userIds: [stu.id] });
    await request(app).put(`/api/classes/${cid}/flashcards`).set(A(ttk))
      .send({ flashcards: [{ flashcard_id: card.body.id, graded: true }] });
    const stk = await token("40067890");
    await request(app).post(`/api/classes/${cid}/flashcard/${card.body.id}/finish`).set(A(stk)).send({
      score: 0, answers: [{
        order: 1, card_id: card.body.id, type: "drawing", pendingApproval: true, points: 0, proposedPoints: 50,
        drawing: { preview: "data:image/png;base64,bbb", strokeCount: 1, approval: { status: "pending" } },
      }],
    });
    const inbox = await request(app).get(`/api/classes/${cid}/drawing-reviews`).set(A(ttk));
    const row = inbox.body.reviews[0];
    const rej = await request(app)
      .post(`/api/classes/${cid}/drawing-reviews/${row.attemptId}/${row.answerIndex}`)
      .set(A(ttk)).send({ status: "rejected" });
    expect(rej.status).toBe(200);
    expect(rej.body.score).toBe(0);
    expect(rej.body.review.status).toBe("rejected");
  });
});
