import { describe, it, expect } from "vitest";
import { readFileSync, readdirSync } from "fs";
import { dirname, join } from "path";
import { fileURLToPath } from "url";

const here = dirname(fileURLToPath(import.meta.url));
const bank = join(here, "../../tools/preint-bank");

function loadAll() {
  const files = readdirSync(bank)
    .filter((n) => /^import-payload\.archive\.part\d+\.json$/.test(n))
    .sort();
  const rows = [];
  for (const n of files) {
    const body = JSON.parse(readFileSync(join(bank, n), "utf8"));
    expect(body.program).toBe("preint");
    expect(Array.isArray(body.questions)).toBe(true);
    rows.push(...body.questions);
  }
  return rows;
}

describe("official booklet import", () => {
  const rows = loadAll();
  const y1402 = rows.filter((r) => r.year_num === 1402);
  const y1403 = rows.filter((r) => r.year_num === 1403);

  it("ships 200 keyed items per sitting (400 total)", () => {
    expect(y1402).toHaveLength(200);
    expect(y1403).toHaveLength(200);
    expect(rows).toHaveLength(400);
    expect(new Set(y1402.map((r) => r.question_no)).size).toBe(200);
    expect(new Set(y1403.map((r) => r.question_no)).size).toBe(200);
  });

  it("uses the ministry English booklet for Khordad 1402", () => {
    const official = y1402.filter((r) => r.en_source === "official_booklet" && r.question_en);
    expect(official.length).toBe(200);
    const q1 = y1402.find((r) => r.question_no === 1);
    expect(q1.question_en).toMatch(/Helicobacter pylori/i);
    expect(q1.options_en[2]).toMatch(/Bismuth/i);
  });

  it("keeps the official key for 1402 Q1 (bismuth quadruple after a recent macrolide)", () => {
    const q1 = y1402.find((r) => r.question_no === 1);
    expect(q1.correct_index).toBe(2);
    expect(q1.subject_fa).toBe("داخلی");
  });

  it("labels the 1402 neurology block from the English header", () => {
    const neuro = y1402.filter((r) => r.subject_fa === "مغز و اعصاب").map((r) => r.question_no).sort((a, b) => a - b);
    expect(neuro).toEqual([97, 98, 99, 100, 101, 102]);
  });

  it("corrects the printed 1402 ICH key (aphasia → headache and vomiting)", () => {
    const q = y1402.find((r) => r.question_no === 99);
    expect(q.key_corrected).toBe(true);
    expect(q.original_correct_index).toBe(2);
    expect(q.correct_index).toBe(1);
    expect(q.explanation_fa).toMatch(/تصحیح/);
    expect(q.key_correction_source).toMatch(/Aminoff/);
  });

  it("aligns Shahrivar 1403 with the printed key (phenytoin q97=ب, status q99=د)", () => {
    const p = y1403.find((r) => r.question_no === 97);
    expect(p.question_fa).toMatch(/فنی/);
    expect(p.correct_index).toBe(1);
    const s = y1403.find((r) => r.question_no === 99);
    expect(s.question_fa).toMatch(/استاتوس/);
    expect(s.correct_index).toBe(3);
  });

  it("corrects the printed 1402 chorioamnionitis key (CS after delayed antibiotics → induce now)", () => {
    const q = y1402.find((r) => r.question_no === 88 && r.subject_fa === "زنان و زایمان");
    expect(q.key_corrected).toBe(true);
    expect(q.original_correct_index).toBe(2);
    expect(q.correct_index).toBe(0);
    expect(q.explanation_fa).toMatch(/تصحیح/);
    expect(q.key_correction_source).toMatch(/ACOG|Williams/);
  });

  it("teaches Khordad 1402 internal 24 as vitamin A exception for osteoporosis", () => {
    const q = y1402.find((r) => r.question_no === 24 && r.subject_fa === "داخلی");
    expect(q.needs_lesson).toBe(false);
    expect(q.correct_index).toBe(0);
    expect(q.question_en).toMatch(/osteoporosis/i);
    expect(q.options_en[0]).toMatch(/vitamin A/i);
    expect(q.micro.points_fa.length).toBeGreaterThanOrEqual(10);
  });

  it("corrects failed-lytic STEMI key to rescue PCI", () => {
    const q = y1402.find((r) => r.question_no === 34 && r.subject_fa === "داخلی");
    expect(q.key_corrected).toBe(true);
    expect(q.original_correct_index).toBe(3);
    expect(q.correct_index).toBe(0);
    expect(q.explanation_fa).toMatch(/تصحیح|اصلاح/);
  });

  it("teaches Khordad 1402 surgery 55 as core needle for BIRADS 4a", () => {
    const q = y1402.find((r) => r.question_no === 55 && r.subject_fa === "جراحی");
    expect(q.needs_lesson).toBe(false);
    expect(q.correct_index).toBe(2);
    expect(q.micro.points_fa.length).toBeGreaterThanOrEqual(10);
    expect(q.options_why_fa[2]).toMatch(/پاسخ صحیح/);
  });

  it("keeps untaught cards bank-only and taught cards fully lessoned", () => {
    const taught = rows.filter((r) => r.needs_lesson === false);
    const pending = rows.filter((r) => r.needs_lesson !== false);
    expect(taught.length).toBe(400);
    expect(taught.every((r) => !!(r.micro && (r.micro.lead_fa || r.micro.golden_fa)))).toBe(true);
    expect(taught.filter((r) => r.year_num === 1403 && r.question_no >= 17).every((r) => (r.micro?.points_fa || []).length >= 10)).toBe(true);
    expect(taught.every((r) => (r.explanation_fa || "").length > 40)).toBe(true);
    expect(pending.every((r) => r.needs_lesson === true)).toBe(true);
    expect(taught.length + pending.length).toBe(rows.length);
  });

  it("corrects the printed 1403 barracks hepatitis key to anti-HAV IgM", () => {
    const q = y1403.find((r) => r.question_no === 4 && r.subject_fa === "داخلی");
    expect(q.needs_lesson).toBe(false);
    expect(q.key_corrected).toBe(true);
    expect(q.original_correct_index).toBe(3);
    expect(q.correct_index).toBe(1);
    expect(q.explanation_fa).toMatch(/تصحیح|اصلاح/);
    expect(q.key_correction_source).toMatch(/Harrison/);
  });

  it("teaches Shahrivar 1403 majors wave 2 (internal 17–40, surgery 53–60, peds 73–80)", () => {
    const wave = y1403.filter((r) =>
      (r.subject_fa === "داخلی" && r.question_no >= 17 && r.question_no <= 40)
      || (r.subject_fa === "جراحی" && r.question_no >= 53 && r.question_no <= 60)
      || (r.subject_fa === "کودکان" && r.question_no >= 73 && r.question_no <= 80)
    );
    expect(wave).toHaveLength(40);
    expect(wave.every((r) => r.needs_lesson === false)).toBe(true);
    expect(wave.every((r) => (r.micro?.points_fa || []).length >= 10)).toBe(true);
    const thyroid = wave.find((r) => r.question_no === 17 && r.subject_fa === "داخلی");
    expect(thyroid.correct_index).toBe(1);
    expect(thyroid.golden_fa).toMatch(/میکروکلسیف/);
    const pylorus = wave.find((r) => r.question_no === 53 && r.subject_fa === "جراحی");
    expect(pylorus.correct_index).toBe(0);
    expect(pylorus.options_why_fa[0]).toMatch(/پاسخ صحیح/);
  });

  it("corrects 1403 PTHrP, CML blast 12%, and SVT cardioversion keys", () => {
    const pth = y1403.find((r) => r.question_no === 22 && r.subject_fa === "داخلی");
    expect(pth.key_corrected).toBe(true);
    expect(pth.original_correct_index).toBe(1);
    expect(pth.correct_index).toBe(2);
    expect(pth.explanation_fa).toMatch(/تصحیح/);
    const cml = y1403.find((r) => r.question_no === 25 && r.subject_fa === "داخلی");
    expect(cml.key_corrected).toBe(true);
    expect(cml.original_correct_index).toBe(0);
    expect(cml.correct_index).toBe(2);
    const svt = y1403.find((r) => r.question_no === 31 && r.subject_fa === "داخلی");
    expect(svt.key_corrected).toBe(true);
    expect(svt.original_correct_index).toBe(0);
    expect(svt.correct_index).toBe(1);
    expect(svt.key_correction_source).toMatch(/ACLS|Harrison/);
  });

  it("teaches 1403 infect, neuro, psych, ENT, radio and stats including image q111", () => {
    const infect = y1403.filter((r) => r.subject_fa === "عفونی");
    expect(infect).toHaveLength(6);
    expect(infect.every((r) => r.needs_lesson === false)).toBe(true);
    const neuro = y1403.filter((r) => r.subject_fa === "مغز و اعصاب");
    expect(neuro.every((r) => r.needs_lesson === false)).toBe(true);
    expect(y1403.find((r) => r.question_no === 99 && r.subject_fa === "مغز و اعصاب").correct_index).toBe(3);
    const radio111 = y1403.find((r) => r.question_no === 111 && r.subject_fa === "رادیولوژی");
    expect(radio111.needs_lesson).toBe(false);
    expect(radio111.correct_index).toBe(3);
    expect(radio111.golden_fa).toMatch(/روده بزرگ/);
    expect(radio111.image).toMatch(/booklet-1403-q111/);
    const radio = y1403.filter((r) => r.subject_fa === "رادیولوژی");
    expect(radio.every((r) => r.needs_lesson === false)).toBe(true);
  });

  it("corrects 1403 rabies cat-III and chi-square keys, plus 1402 Graves and PAD", () => {
    const rab = y1403.find((r) => r.question_no === 152 && r.subject_fa === "آمار و اپیدمیولوژی");
    expect(rab.key_corrected).toBe(true);
    expect(rab.original_correct_index).toBe(1);
    expect(rab.correct_index).toBe(2);
    expect(rab.explanation_fa).toMatch(/تصحیح/);
    const chi = y1403.find((r) => r.question_no === 153 && r.subject_fa === "آمار و اپیدمیولوژی");
    expect(chi.key_corrected).toBe(true);
    expect(chi.correct_index).toBe(3);
    const graves = y1402.find((r) => r.question_no === 19 && r.subject_fa === "داخلی");
    expect(graves.needs_lesson).toBe(false);
    expect(graves.key_corrected).toBe(true);
    expect(graves.correct_index).toBe(1);
    expect(graves.en_source).toBe("official_booklet");
    const pad = y1402.find((r) => r.question_no === 60 && r.subject_fa === "جراحی");
    expect(pad.key_corrected).toBe(true);
    expect(pad.original_correct_index).toBe(3);
    expect(pad.correct_index).toBe(2);
    expect(y1402.find((r) => r.question_no === 59 && r.subject_fa === "جراحی").needs_lesson).toBe(false);
  });

  it("teaches 1403 pharma/ethics/derm and 1402 psych/ethics/pharma/ENT/uro", () => {
    const ph = y1403.filter((r) => r.subject_fa === "فارماکولوژی");
    expect(ph).toHaveLength(9);
    expect(ph.every((r) => r.needs_lesson === false)).toBe(true);
    expect(y1403.find((r) => r.question_no === 157 && r.subject_fa === "فارماکولوژی").correct_index).toBe(0);
    const d128 = y1403.find((r) => r.question_no === 128 && r.subject_fa === "پوست");
    expect(d128.needs_lesson).toBe(false);
    expect(d128.correct_index).toBe(2);
    expect(d128.golden_fa).toMatch(/جااندازی بسته/);
    const path166 = y1403.find((r) => r.question_no === 166 && r.subject_fa === "پاتولوژی");
    expect(path166.needs_lesson).toBe(false);
    expect((path166.micro?.points_fa || []).length).toBeGreaterThanOrEqual(10);
    expect(y1402.filter((r) => r.subject_fa === "روانپزشکی").every((r) => r.needs_lesson === false)).toBe(true);
    expect(y1402.filter((r) => r.subject_fa === "اورولوژی").every((r) => r.needs_lesson === false)).toBe(true);
  });

  it("corrects motilin, bone-scan, echolalia, JNA and sialolith keys", () => {
    const mot = y1403.find((r) => r.question_no === 159 && r.subject_fa === "فارماکولوژی");
    expect(mot.key_corrected).toBe(true);
    expect(mot.original_correct_index).toBe(3);
    expect(mot.correct_index).toBe(2);
    expect(mot.explanation_fa).toMatch(/تصحیح/);
    const scan = y1403.find((r) => r.question_no === 132 && r.subject_fa === "پوست");
    expect(scan.key_corrected).toBe(true);
    expect(scan.correct_index).toBe(0);
    const echo = y1402.find((r) => r.question_no === 117 && r.subject_fa === "روانپزشکی");
    expect(echo.key_corrected).toBe(true);
    expect(echo.correct_index).toBe(2);
    expect(echo.en_source).toBe("official_booklet");
    const jna = y1402.find((r) => r.question_no === 147 && r.subject_fa === "گوش و حلق و بینی");
    expect(jna.key_corrected).toBe(true);
    expect(jna.original_correct_index).toBe(3);
    expect(jna.correct_index).toBe(1);
    const stone = y1402.find((r) => r.question_no === 148 && r.subject_fa === "گوش و حلق و بینی");
    expect(stone.correct_index).toBe(1);
  });

  it("teaches remaining 1402 minors and 1403 path/derm2 including the two image cards", () => {
    const pending = rows.filter((r) => r.needs_lesson !== false);
    expect(pending).toHaveLength(0);
    const wave1402 = y1402.filter((r) =>
      ["پاتولوژی", "پوست", "ارتوپدی", "رادیولوژی", "آمار و اپیدمیولوژی", "ایمونولوژی", "تغذیه", "فیزیک پزشکی", "ژنتیک پزشکی"].includes(r.subject_fa)
      || r.subject_fa.includes("چشم")
    );
    expect(wave1402.length).toBeGreaterThanOrEqual(65);
    expect(wave1402.every((r) => r.needs_lesson === false)).toBe(true);
    expect(wave1402.every((r) => (r.micro?.points_fa || []).length >= 10)).toBe(true);
    expect(y1402.every((r) => r.en_source === "official_booklet")).toBe(true);
    const p1403 = y1403.filter((r) => r.subject_fa === "پاتولوژی");
    expect(p1403).toHaveLength(35);
    expect(p1403.every((r) => r.needs_lesson === false)).toBe(true);
    expect(y1403.find((r) => r.question_no === 133 && r.subject_fa === "پوست").needs_lesson).toBe(false);
    expect(y1403.find((r) => r.question_no === 166 && r.subject_fa === "پاتولوژی").golden_fa).toMatch(/التهاب/);
  });

  it("corrects 1403 trisomy/MMR/MG/G-CSF/measles-IG and 1402 TH17 keys", () => {
    const ped = y1403.find((r) => r.question_no === 178 && r.subject_fa === "پاتولوژی");
    expect(ped.image).toMatch(/booklet-1403-q178/);
    expect(ped.key_corrected).toBe(true);
    expect(ped.correct_index).toBe(0);
    expect(ped.explanation_fa).toMatch(/تصحیح/);
    const ea = y1402.find((r) => r.question_no === 59 && r.subject_fa === "جراحی");
    expect(ea.image).toMatch(/booklet-1402-q59/);
    const cfped = y1402.find((r) => r.question_no === 180 && r.subject_fa === "ژنتیک پزشکی");
    expect(cfped.image).toMatch(/booklet-1402-q180/);
    const tri = y1403.find((r) => r.question_no === 174 && r.subject_fa === "پاتولوژی");
    expect(tri.key_corrected).toBe(true);
    expect(tri.original_correct_index).toBe(1);
    expect(tri.correct_index).toBe(0);
    expect(tri.explanation_fa).toMatch(/تصحیح|اصلاح/);
    const mmr = y1403.find((r) => r.question_no === 189 && r.subject_fa === "پاتولوژی");
    expect(mmr.key_corrected).toBe(true);
    expect(mmr.correct_index).toBe(0);
    expect(mmr.options_fa[0]).toMatch(/MMR/);
    const mg = y1403.find((r) => r.question_no === 191 && r.subject_fa === "پاتولوژی");
    expect(mg.correct_index).toBe(0);
    expect(mg.explanation_fa).toMatch(/تصحیح/);
    const gcsf = y1403.find((r) => r.question_no === 193 && r.subject_fa === "پاتولوژی");
    expect(gcsf.original_correct_index).toBe(2);
    expect(gcsf.correct_index).toBe(3);
    expect(gcsf.options_fa[3]).toMatch(/G-CSF/);
    const ig = y1403.find((r) => r.question_no === 195 && r.subject_fa === "پاتولوژی");
    expect(ig.original_correct_index).toBe(0);
    expect(ig.correct_index).toBe(3);
    expect(ig.options_fa[3]).toMatch(/سرخک/);
    const th = y1402.find((r) => r.question_no === 192 && r.subject_fa === "ایمونولوژی");
    expect(th.key_corrected).toBe(true);
    expect(th.original_correct_index).toBe(3);
    expect(th.correct_index).toBe(2);
    expect(th.options_en[2]).toMatch(/TH17/i);
    expect(th.en_source).toBe("official_booklet");
    expect(th.explanation_fa).toMatch(/تصحیح/);
  });
});
