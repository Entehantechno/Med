/* load-env.js — must be imported BEFORE anything that reads process.env
   (DATA_DIR, JWT_SECRET, AI_API_KEY, PORT).

   On a cPanel host the operator should not have to create files by hand:
   if `.env` is missing and `.env.ready` shipped with the zip, we copy it. */
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "..");
const ENV_FILE = path.join(ROOT, ".env");
const READY_FILE = path.join(ROOT, ".env.ready");
const SERVER_ENV = path.join(ROOT, "server", ".env");

try {
  if (!fs.existsSync(ENV_FILE) && fs.existsSync(READY_FILE)) {
    fs.copyFileSync(READY_FILE, ENV_FILE);
    console.log("✓ created .env from the bundled .env.ready (no manual step needed)");
  }
} catch (e) {
  console.warn("could not auto-create .env:", e?.message || e);
}

dotenv.config({ path: ENV_FILE });
if (fs.existsSync(SERVER_ENV)) dotenv.config({ path: SERVER_ENV, override: false });
