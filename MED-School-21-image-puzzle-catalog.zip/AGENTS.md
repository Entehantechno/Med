# MED School — AI Agent Operating Rules

این فایل برای همه AI coding agentهاست. قبل از هر تغییر در این پروژه باید خوانده شود.

## اصل‌های غیرقابل نقض

1. ظاهر کلی سایت را بدون درخواست مستقیم تغییر نده.
2. پروژه روی هاست کوچک cPanel/CloudLinux NodeJS Selector اجرا می‌شود؛ dependency سنگین اضافه نکن.
3. ساختار ZIP باید مثل نسخه سالم باشد: فایل‌ها مستقیم در ریشه ZIP باشند، نه داخل پوشه اضافی.
4. داخل ZIP نهایی نباید `node_modules` باشد.
5. داخل ZIP نهایی نباید دیتای runtime باشد: `medschool-data/`، `data/`، `*.db`، `*.sqlite`، `*.sqlite3`.
6. Startup file روی هاست: `server/src/index.js`.
7. Node.js 20+ هدف اصلی است.
8. قبل از تحویل، build و تست‌های مرتبط را اجرا کن.
9. اگر تست SEO سرور خطای `Client not built yet` داد، اول `cd client && npm run build` اجرا کن.
10. همه قابلیت‌های آموزشی/پژوهشی باید خاموش/روشن و تحت کنترل ادمین/استاد باشند.
11. هیچ API key، token یا credential واقعی را در کد ننویس.
12. قبل از تغییرات live/آپدیت هاست، اول بکاپ فایل‌ها و دیتابیس/پوشه داده گرفته شود.

## معماری پروژه

- Frontend: React + Vite در `client/`
- Backend: Express + sql.js در `server/`
- دیتای پایدار روی هاست: `DATA_DIR=../medschool-data`
- مسیر build کلاینت: `client/dist`
- مسیر تست سرور: `server/test`
- مسیر e2e: `e2e/`

## قوانین سرعت

- مسیر عمومی و landing باید سبک بماند.
- Admin و LearnApp باید lazy باشند.
- SupportWidget، Login، InstallPrompt و ابزارهای جانبی باید lazy باشند.
- فونت‌ها را زیاد نکن؛ فارسی با Vazirmatn و heading با Estedad کافی است.
- اگر chunk جدید بزرگ شد، علت را توضیح بده و قبل از تحویل کم کن.

## قوانین امنیت

- auth/cookie/CSRF/CSP را بدون دلیل تغییر نده.
- فایل آپلود باید با MIME + extension + magic bytes کنترل شود.
- APIهای حساس باید no-store باشند.
- در کد از string concatenation برای SQL با input کاربر استفاده نکن.
- اطلاعات دانشجو/استاد/پژوهش باید حداقل‌سازی شود.

## قوانین تست

حداقل قبل از تحویل:

```bash
cd client && npm install --no-audit --no-fund && npm run build
cd ../server && npm install --no-audit --no-fund && npm test
```

اگر تغییر UI داشتی:

```bash
cd e2e && npm install --no-audit --no-fund && npx playwright install chromium && npm test
```

## قوانین packaging

```bash
zip -qr /home/user/MED-School-10-<name>.zip . \
  -x '*/node_modules/*' 'node_modules/*' \
     'medschool-data/*' 'medschool-data/**' 'data/*' 'data/**' \
     '*.db' '*.db-shm' '*.db-wal' '*.sqlite' '*.sqlite3' \
     '*/test-results/*' '*/playwright-report/*' 'test-results/*' 'playwright-report/*' \
     'e2e-data/*' 'e2e-data/**' '*/e2e-data/*' \
     'qa-artifacts/*' 'qa-artifacts/**' 'qa-shots/*' 'qa-shots/**' \
     'tools/neurology-bank/import-payload.json' \
     '.git/*' '.cache/*' 'client/.vite/*' 'server/.cache/*' \
     '*.log' '.DS_Store'
```

**چرا این استثناها؟** `qa-artifacts/` و `qa-shots/` خروجی اسکرین‌شات تست‌های e2e
هستند و هر بار اجرای تست دوباره ساخته می‌شوند؛ حدود ۱۳ مگابایت تصویر بی‌مصرف در ZIP.
`import-payload.json` هم وقتی بانک تکه‌شده باشد یک کپی دقیق ۴ مگابایتی از تکه‌هاست و
`import-bank.mjs` اصلاً از آن استفاده نمی‌کند. با این استثناها حجم ZIP از حدود
۲۰ مگابایت به حدود ۷ مگابایت می‌رسد.

بعد بررسی کن:
- `package.json` در ریشه ZIP باشد.
- `server/src/index.js` داخل ZIP باشد.
- `client/dist/index.html` داخل ZIP باشد.
- `node_modules` داخل ZIP نباشد.
- `medschool-data` یا فایل دیتابیس داخل ZIP نباشد.
- حتماً این چک اجرا شود:

```bash
node scripts/check-release-zip.mjs /home/user/MED-School-10-<name>.zip
```

## نکتهٔ ویدیوی بررسی‌شده درباره آپدیت سایت live

در ویدیوی Hozhi درباره ارتقای سایت با Claude Code، نکته‌های عملی مهمی بود که برای این پروژه هم لازم است:

- قبل از آپدیت سایت live، بکاپ فایل‌ها و دیتابیس/پوشه داده گرفته شود.
- تغییر دیتابیس باید افزایشی و امن باشد؛ دستورهای تخریبی مثل `DROP`/`DELETE` برای آپگرید عادی ممنوع است.
- فایل تنظیمات live مثل `.env` نباید بدون توجه جایگزین شود، چون ممکن است دامنه، SMTP یا کلیدهای واقعی را از بین ببرد.
- قبل از تحویل، SEO (`robots.txt`/`sitemap.xml`)، امنیت، build، تست و ساختار ZIP جداگانه چک شود.
- فایل‌های cache، گزارش تست، دیتابیس محلی و فولدرهای داده نباید در ZIP آپلود مستقیم قرار بگیرند.
