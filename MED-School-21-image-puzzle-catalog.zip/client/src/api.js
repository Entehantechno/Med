/* Thin fetch wrapper that injects the JWT and parses JSON. */
const TOKEN_KEY = "medlab_token";

export function getToken() { return localStorage.getItem(TOKEN_KEY); }
export function setToken(t) { t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY); }

async function req(method, path, body) {
  const headers = { "Content-Type": "application/json" };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(`/api${path}`, {
    method, headers, credentials: "same-origin", body: body ? JSON.stringify(body) : undefined,
  });
  if (res.status === 401) { setToken(null); }
  const ct = res.headers.get("content-type") || "";
  const data = ct.includes("json") ? await res.json() : await res.text();
  if (!res.ok) {
    const msg = (data && (data.message_fa || data.message_en || data.error)) || `HTTP ${res.status}`;
    const err = new Error(msg);
    err.data = data;
    err.status = res.status;
    throw err;
  }
  return data;
}

export const api = {
  get: (p) => req("GET", p),
  post: (p, b) => req("POST", p, b),
  put: (p, b) => req("PUT", p, b),
  del: (p) => req("DELETE", p),
  // convenience
  login: (username, password) => req("POST", "/auth/login", { username, password }),
  register: (payload) => req("POST", "/auth/register", payload),
  me: () => req("GET", "/auth/me"),
  csvUrl: () => `/api/reports/export.csv`,
};
