import { useState, useMemo } from "react";
import { useApp } from "../context.jsx";
import Icon from "./Icon.jsx";

/* Reusable table with a search box and click-to-sort column headers.
   Props:
     columns: [{ key, label, render?(row), sortValue?(row), sortable?=true, thStyle? }]
     rows:    array of objects
     searchKeys: optional array of keys/functions to match the search text against
                 (defaults to every column's sortValue/text)
     initialSort: { key, dir } — dir "asc" | "desc"
     empty:   node shown when there are no rows after filtering
     rowKey:  (row,i) => key
*/
export default function DataTable({ columns, rows, searchKeys, initialSort, empty, rowKey, searchPlaceholder }) {
  const { t } = useApp();
  const [q, setQ] = useState("");
  const [sort, setSort] = useState(initialSort || { key: null, dir: "asc" });

  const textOf = (row, col) => {
    if (col.sortValue) return col.sortValue(row);
    const v = row[col.key];
    return v == null ? "" : v;
  };

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return rows;
    const keys = searchKeys || columns.map((c) => (row) => textOf(row, c));
    return rows.filter((row) =>
      keys.some((k) => {
        const val = typeof k === "function" ? k(row) : row[k];
        return String(val ?? "").toLowerCase().includes(needle);
      })
    );
  }, [rows, q, columns, searchKeys]);

  const sorted = useMemo(() => {
    if (!sort.key) return filtered;
    const col = columns.find((c) => c.key === sort.key);
    if (!col) return filtered;
    const arr = [...filtered].sort((a, b) => {
      let x = textOf(a, col), y = textOf(b, col);
      const nx = Number(x), ny = Number(y);
      if (!isNaN(nx) && !isNaN(ny) && x !== "" && y !== "") { x = nx; y = ny; }
      else { x = String(x).toLowerCase(); y = String(y).toLowerCase(); }
      if (x < y) return -1; if (x > y) return 1; return 0;
    });
    return sort.dir === "desc" ? arr.reverse() : arr;
  }, [filtered, sort, columns]);

  const toggleSort = (key) =>
    setSort((s) => (s.key === key ? { key, dir: s.dir === "asc" ? "desc" : "asc" } : { key, dir: "asc" }));

  return (
    <div>
      <div className="dt-search">
        <Icon name="search" size={16} />
        <input value={q} onChange={(e) => setQ(e.target.value)}
          placeholder={searchPlaceholder || t("searchPlaceholder")} />
        {q && <button className="dt-clear" onClick={() => setQ("")} aria-label="clear"><Icon name="close" size={14} /></button>}
      </div>
      <div className="table-wrap">
        <table>
          <thead><tr>
            {columns.map((c) => {
              const canSort = c.sortable !== false;
              const active = sort.key === c.key;
              return (
                <th key={c.key} style={{ ...(c.thStyle || {}), ...(canSort ? { cursor: "pointer", userSelect: "none" } : {}) }}
                  onClick={canSort ? () => toggleSort(c.key) : undefined}>
                  {c.label}
                  {canSort && <span className="dt-sort">{active ? (sort.dir === "asc" ? " ▲" : " ▼") : " ⇅"}</span>}
                </th>
              );
            })}
          </tr></thead>
          <tbody>
            {sorted.length === 0 ? (
              <tr><td colSpan={columns.length} className="small muted center" style={{ padding: 20 }}>
                {empty || t("noData")}</td></tr>
            ) : sorted.map((row, i) => (
              <tr key={rowKey ? rowKey(row, i) : (row.id ?? i)}>
                {columns.map((c) => <td key={c.key}>{c.render ? c.render(row) : row[c.key]}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
