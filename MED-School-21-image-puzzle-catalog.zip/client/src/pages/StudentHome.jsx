import { useEffect, useState } from "react";
import { useApp } from "../context.jsx";
import { api } from "../api.js";
import { TopBar, Pill } from "../components/UI.jsx";
import { biField } from "../i18n.js";
import { fmtDateTime } from "../utils/date.js";
import StatNum from "../components/StatNum.jsx";
import Icon from "../components/Icon.jsx";
import { SkeletonCards } from "../components/Skeleton.jsx";

export default function StudentHome({ go }) {
  const { t, user, lang } = useApp();
  const [data, setData] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const [exams, classes, mine] = await Promise.all([
          api.get("/exams"), api.get("/classes"), api.get("/reports/my"),
        ]);
        setData({ exams, classes, mine });
      } catch { setData({ exams: [], classes: [], mine: [] }); }
    })();
  }, []);

  if (!data) return (
    <div className="app"><TopBar onHome={() => go("home")} />
      <div className="container"><div className="section-title"><h2>{t("welcome")} </h2></div><SkeletonCards /></div>
    </div>
  );

  const activeExams = data.exams.filter((e) => e.state === "open");
  const hasExams = data.exams.length > 0;
  const hasClasses = data.classes.length > 0;

  // Modules shown to a student: their CLASSES are the single entry point — the
  // teacher activates virtual-patient cases INSIDE a class, so we no longer show
  // a separate "Virtual patients" module (its purpose overlaps with classes).
  // Exams appear here only when the student actually has scheduled exams.
  const modules = [];
  if (hasExams) modules.push({ key: "exams", ico: "exam", bg: "var(--grad-purple)",
    title: t("modExams"), desc: t("modExamsDesc"), badge: activeExams.length });
  if (hasClasses) modules.push({ key: "classes", ico: "class", bg: "var(--grad-primary)",
    title: t("modClasses"), desc: t("modClassesDesc") });

  return (
    <div className="app">
      <TopBar onHome={() => go("home")} />
      <div className="container">
        <div className="section-title"><h2>{t("welcome")}، {lang === "fa" ? user.name_fa : user.name_en} </h2></div>

        {/* Active exams banner — the most important thing for a student */}
        {activeExams.length > 0 && (
          <div className="card mb16" style={{ borderInlineStart: "4px solid var(--ok)" }}>
            <div className="section-title" style={{ marginBottom: 12 }}>
              <h4 style={{ color: "var(--ok)", borderBottom: "none", padding: 0 }}><Icon name="circleCheck" size={16} /> {t("activeExams")}</h4>
            </div>
            <div className="grid" style={{ gap: 10 }}>
              {activeExams.map((e) => (
                <div className="case-item" key={e.id}>
                  <div>
                    <strong>{biField(e, "title", lang)}</strong>
                    <div className="case-meta">
                      <Pill kind="active">{t("stateOpen")}</Pill>
                      <span className="tag"><Icon name="clock" size={16} /> {e.duration_min} {t("min")}</span>
                      <span className="tag"><Icon name="clock" size={16} /> {fmtDateTime(e.ends_at, lang)}</span>
                    </div>
                  </div>
                  <button className="btn btn-accent" onClick={() => go("exams")}>{t("enterExam")}</button>
                </div>
              ))}
            </div>
          </div>
        )}

        {modules.length === 0 ? (
          <div className="card empty-state">
            <div className="ico"><Icon name="inbox" size={30} /></div>
            <h3>{t("noExamsAssigned")}</h3>
            <div className="muted small mt8">{t("noExamsAssignedDesc")}</div>
          </div>
        ) : (
          <div className={`grid grid-${Math.min(modules.length, 3)} mb16`}>
            {modules.map((m) => (
              <button className="card mod-card mod-card-row" key={m.key} onClick={() => go(m.key)}>
                <div className="mod-ico" style={{ background: m.bg, position: "relative" }}><Icon name={m.ico} size={26} />
                  {m.badge > 0 && <span style={{ position: "absolute", top: -6, insetInlineEnd: -6,
                    background: "var(--ok)", color: "#fff", borderRadius: 999, fontSize: ".62rem",
                    fontWeight: 800, padding: "1px 7px" }}>{m.badge}</span>}
                </div>
                <div className="mod-card-body">
                  <h3>{m.title}</h3><p>{m.desc}</p>
                </div>
                <Icon name={lang === "fa" ? "chevronLeft" : "chevronRight"} size={18} className="mod-card-go" />
              </button>
            ))}
          </div>
        )}

        {/* At-a-glance counters that ALSO navigate — a student can always reach
            their exams / classes / progress straight from the home. */}
        <div className="grid grid-3">
          <button className="card stat-card stat-card-link" onClick={() => go("exams")}>
            <div className="num"><StatNum value={data.exams.length} /></div><div className="lbl">{t("myExams")}</div></button>
          <button className="card stat-card stat-card-link" onClick={() => go("classes")}>
            <div className="num"><StatNum value={data.classes.length} /></div><div className="lbl">{t("myClasses")}</div></button>
          <button className="card stat-card stat-card-link" onClick={() => go("classes")}>
            <div className="num"><StatNum value={data.mine.length} /></div><div className="lbl">{t("myProgress")}</div></button>
        </div>
      </div>
    </div>
  );
}
