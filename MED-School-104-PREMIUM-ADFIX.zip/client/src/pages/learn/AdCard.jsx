import { useApp } from "../../context.jsx";
import { api } from "../../api.js";

/* High-end motion ad — research-backed 10-15s loop, gradient + blur orb + glass pills.
   Respects prefers-reduced-motion (no animation) and premium (never shown to premium).
   Used for all 7 slots: home, path, lesson-intro, between-lessons, sidebar, review, leaderboard. */
export function AdCard({ ad, variant = "default" }) {
  const { t, lang } = useApp();
  if (!ad) return null;
  const click = () => { api.post(`/learn/ads/${ad.id}/click`).catch(() => {}); };
  const isFa = lang === "fa";
  // variant tweaks: intro is more compact & centered, between is celebratory
  const isIntro = variant === "intro";
  const isBetween = variant === "between";
  return (
    <div
      className={`ad-card motion-ad motion-ad--${variant}`}
      style={{
        background: `linear-gradient(135deg, ${ad.bg} 0%, ${ad.bg} 55%, #0f172ae6 100%)`,
        borderRadius: 16,
        padding: isIntro ? "18px 20px" : "16px 18px",
        color: "#fff",
        position: "relative",
        overflow: "hidden",
        boxShadow: "0 12px 32px -12px rgba(0,0,0,.35), 0 4px 12px -4px rgba(0,0,0,.2)",
        isolation: "isolate",
      }}
    >
      {/* blur orb — decorative, motion-safe */}
      <div
        aria-hidden="true"
        style={{
          position: "absolute",
          insetInlineEnd: "-18%",
          top: "-22%",
          width: 180,
          height: 180,
          background: "radial-gradient(ellipse at center, rgba(255,255,255,.18), transparent 70%)",
          borderRadius: "50%",
          filter: "blur(8px)",
          pointerEvents: "none",
          zIndex: 0,
        }}
      />
      <div
        aria-hidden="true"
        style={{
          position: "absolute",
          insetInlineStart: "8%",
          bottom: "-18%",
          width: 220,
          height: 120,
          background: `radial-gradient(ellipse at center, ${ad.bg}66, transparent 70%)`,
          borderRadius: "50%",
          filter: "blur(12px)",
          opacity: 0.9,
          pointerEvents: "none",
          zIndex: 0,
        }}
      />
      {/* diagonal stripe subtle */}
      <div
        aria-hidden="true"
        style={{
          position: "absolute",
          inset: 0,
          background: `repeating-linear-gradient(135deg, rgba(255,255,255,.04) 0 12px, transparent 12px 24px)`,
          opacity: 0.5,
          pointerEvents: "none",
          zIndex: 0,
        }}
      />
      <div style={{ position: "relative", zIndex: 1 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6, flexWrap: "wrap" }}>
          <span
            style={{
              fontSize: ".62rem",
              fontWeight: 800,
              opacity: 0.9,
              background: "rgba(255,255,255,.18)",
              padding: "2px 8px",
              borderRadius: 999,
              backdropFilter: "blur(6px)",
              border: "1px solid rgba(255,255,255,.22)",
            }}
          >
            {t("sponsored")}{ad.sponsor ? ` · ${ad.sponsor}` : ""}
          </span>
          {isIntro && (
            <span style={{ fontSize: ".68rem", opacity: 0.85, background: "rgba(255,255,255,.14)", padding: "2px 8px", borderRadius: 999 }}>
              {isFa ? "تبلیغ" : "Ad"}
            </span>
          )}
        </div>
        {ad.image && <img className="ad-image" src={ad.image} alt="" style={{ borderRadius: 12, marginBottom: 10 }} />}
        {ad.title && (
          <h4 style={{ margin: "0 0 6px", color: "#fff", fontWeight: 900, lineHeight: 1.35, fontSize: isIntro ? "1.05rem" : "1rem", textShadow: "0 1px 2px rgba(0,0,0,.25)" }}>
            {ad.title}
          </h4>
        )}
        {ad.body && <p style={{ margin: "0 0 12px", fontSize: ".88rem", opacity: 0.96, lineHeight: 1.7 }}>{ad.body}</p>}
        {/* glass pills — trust signals */}
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 12 }}>
          <span style={pillStyle}>✓ {isFa ? "هاریسون" : "Harrison"}</span>
          <span style={pillStyle}>✓ {isFa ? "ماندگاری ۲٪" : "2% retention"}</span>
          <span style={pillStyle}>✓ {isFa ? "مرور ۵ دقیقه‌ای" : "5-min review"}</span>
        </div>
        {(ad.cta || ad.url) && (
          <a
            className="ad-cta"
            href={ad.url || undefined}
            target={ad.url && ad.url !== "#" ? "_blank" : undefined}
            rel="noreferrer"
            onClick={click}
            style={{
              display: "inline-block",
              background: "rgba(255,255,255,.96)",
              color: "#1e2b3d",
              fontWeight: 900,
              padding: "8px 18px",
              borderRadius: 999,
              fontSize: ".88rem",
              textDecoration: "none",
              boxShadow: "0 8px 16px -10px rgba(0,0,0,.45)",
              border: "1px solid rgba(255,255,255,.6)",
            }}
          >
            {ad.cta || t("startNow")}
          </a>
        )}
      </div>
    </div>
  );
}

const pillStyle = {
  fontSize: ".7rem",
  fontWeight: 700,
  background: "rgba(255,255,255,.14)",
  border: "1px solid rgba(255,255,255,.22)",
  padding: "3px 8px",
  borderRadius: 999,
  backdropFilter: "blur(6px)",
  color: "#fff",
};
