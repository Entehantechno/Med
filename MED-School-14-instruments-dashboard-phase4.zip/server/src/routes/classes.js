/* ================================================================
   classes.js — Classrooms: teacher creates a class, adds cases,
   enrolls students. Students take the class cases to earn a class
   grade (replacing the traditional logbook).
   ================================================================ */
import { Router } from "express";
import { db, persistNow } from "../db.js";
import { authRequired, requireRole } from "../lib/auth.js";
import bcrypt from "bcryptjs";
import { audit } from "../lib/audit.js";
import { sessionsForAttempt } from "../lib/vplogging.js";

const r = Router();

const genCode = () =>
  "MED-" + Math.floor(1000 + Math.random() * 9000);


const currentUniversityId = (user) => db.prepare("SELECT university_id FROM users WHERE id=?").get(user.id)?.university_id || null;
const studentByNo = (sno) => {
  const sn = String(sno || "").trim();
  if (!sn) return null;
  return db.prepare("SELECT id, username, student_no, name_fa, name_en, university_id FROM users WHERE (student_no=? OR username=?) AND role='student'").get(sn, sn) || null;
};
function createStudentForUniversity({ sno, name = "", universityId, createdBy }) {
  const sn = String(sno || "").trim();
  if (!sn || !universityId) return null;
  const existing = studentByNo(sn);
  if (existing) return existing;
  const info = db.prepare("INSERT INTO users (username,password_hash,name_fa,name_en,student_no,role,status,university_id) VALUES (?,?,?,?,?,'student','active',?)")
    .run(sn, bcrypt.hashSync(sn, 12), name || sn, name || sn, sn, universityId);
  return { id: info.lastInsertRowid, username: sn, student_no: sn, name_fa: name || sn, name_en: name || sn, university_id: universityId, createdBy };
}

function caseTitle(row) {
  if (!row?.data_json) return {};
  const cd = JSON.parse(row.data_json);
  return { title_fa: cd.title_fa, title_en: cd.title_en, difficulty: row.difficulty, version: row.version };
}
function flashTitle(row) {
  if (!row?.data_json) return {};
  let cd = {}; try { cd = JSON.parse(row.data_json); } catch { /* */ }
  // title_* = the teacher/admin-facing LABEL (never shown to students).
  // q_* = the actual QUESTION shown to students (question text preferred).
  const q_fa = cd.questionText_fa || cd.q_fa || cd.front_fa || cd.title_fa || "";
  const q_en = cd.questionText_en || cd.q_en || cd.front_en || cd.title_en || "";
  return {
    title_fa: cd.title_fa || q_fa, title_en: cd.title_en || q_en,
    q_fa, q_en,
    difficulty: row.difficulty, version: row.version,
  };
}

/* ---- List classes ----
   Teachers/admins see all; students see only their enrolled classes. */
r.get("/", authRequired, (req, res) => {
  let classes;
  if (req.user.role === "student") {
    classes = db.prepare(
      `SELECT c.* FROM classes c
         JOIN class_members m ON m.class_id = c.id
       WHERE m.user_id=? AND c.active=1 ORDER BY c.id DESC`
    ).all(req.user.id);
  } else if (req.user.role === "teacher") {
    const uni = currentUniversityId(req.user);
    classes = db.prepare("SELECT * FROM classes WHERE active=1 AND university_id=? ORDER BY id DESC").all(uni || -1);
  } else {
    classes = db.prepare("SELECT * FROM classes WHERE active=1 ORDER BY id DESC").all();
  }
  const out = classes.map((cl) => {
    const nCases = db.prepare("SELECT COUNT(*) n FROM class_cases WHERE class_id=?").get(cl.id).n;
    const nStudents = db.prepare("SELECT COUNT(*) n FROM class_members WHERE class_id=?").get(cl.id).n;
    return { ...cl, nCases, nStudents };
  });
  res.json(out);
});

/* ---- Class detail (cases + members + per-student grade) ---- */
r.get("/:id", authRequired, (req, res) => {
  const cl = db.prepare("SELECT * FROM classes WHERE id=?").get(req.params.id);
  if (!cl) return res.status(404).json({ error: "not found" });
  if (req.user.role === "teacher" && cl.university_id !== currentUniversityId(req.user)) return res.status(403).json({ error: "wrong_university" });

  // student must be a member
  if (req.user.role === "student") {
    const mem = db.prepare("SELECT 1 FROM class_members WHERE class_id=? AND user_id=?").get(cl.id, req.user.id);
    if (!mem) return res.status(403).json({ error: "not enrolled" });
  }

  const cases = db.prepare(
    `SELECT cc.case_id, cc.weight, c.data_json, c.difficulty, c.version
       FROM class_cases cc JOIN cases c ON c.id = cc.case_id
     WHERE cc.class_id=?`
  ).all(cl.id).map((row) => ({ case_id: row.case_id, weight: row.weight, ...caseTitle(row) }));

  // Flashcard sets attached to the class (graded or practice-only).
  const flashcards = db.prepare(
    `SELECT cf.flashcard_id, cf.weight, cf.graded, f.data_json, f.difficulty, f.version
       FROM class_flashcards cf JOIN flashcards f ON f.id = cf.flashcard_id
     WHERE cf.class_id=?`
  ).all(cl.id).map((row) => ({ flashcard_id: row.flashcard_id, weight: row.weight, graded: row.graded, ...flashTitle(row) }));

  // Best attempt per case for grade calculation
  const bestCase = (userId, caseId) =>
    db.prepare("SELECT MAX(score) s FROM attempts WHERE user_id=? AND case_id=? AND class_id=?").get(userId, caseId, cl.id).s;
  const bestFlash = (userId, fid) =>
    db.prepare("SELECT MAX(score) s FROM class_flashcard_attempts WHERE user_id=? AND flashcard_id=? AND class_id=?").get(userId, fid, cl.id).s;

  const gradedFlash = flashcards.filter((f) => f.graded);

  const computeGrade = (userId) => {
    let sum = 0, wsum = 0, caseDone = 0, flashDone = 0;
    const perCase = cases.map((cc) => {
      const best = bestCase(userId, cc.case_id);
      if (best != null) { sum += best * cc.weight; caseDone++; }
      wsum += cc.weight;
      return { case_id: cc.case_id, best };
    });
    const perFlash = flashcards.map((cf) => {
      const best = bestFlash(userId, cf.flashcard_id);
      if (best != null) {
        flashDone++;
        if (cf.graded) { sum += best * cf.weight; }
      }
      if (cf.graded) wsum += cf.weight;   // only graded flashcards affect the grade
      return { flashcard_id: cf.flashcard_id, best, graded: !!cf.graded };
    });
    const grade = wsum ? Math.round(sum / wsum) : 0;
    return { grade, doneCount: caseDone, caseDone, totalCases: cases.length,
             flashDone, totalFlash: flashcards.length, gradedFlash: gradedFlash.length, perCase, perFlash };
  };

  if (req.user.role === "student") {
    const g = computeGrade(req.user.id);
    const withUsage = cases.map((cc) => {
      const used = db.prepare("SELECT COUNT(*) n FROM attempts WHERE user_id=? AND case_id=? AND class_id=?").get(req.user.id, cc.case_id, cl.id).n;
      const best = g.perCase.find((p) => p.case_id === cc.case_id)?.best;
      return { ...cc, attemptsUsed: used, best };
    });
    const flashUsage = flashcards.map((cf) => {
      const used = db.prepare("SELECT COUNT(*) n FROM class_flashcard_attempts WHERE user_id=? AND flashcard_id=? AND class_id=?").get(req.user.id, cf.flashcard_id, cl.id).n;
      const best = g.perFlash.find((p) => p.flashcard_id === cf.flashcard_id)?.best;
      return { ...cf, attemptsUsed: used, best };
    });
    return res.json({ class: cl, cases: withUsage, flashcards: flashUsage, grade: g.grade,
                      doneCount: g.doneCount, maxAttempts: cl.max_attempts });
  }

  // teacher/admin view: members with grades + usage detail
  const members = db.prepare(
    `SELECT u.id,u.name_fa,u.name_en,u.student_no
       FROM class_members m JOIN users u ON u.id=m.user_id
     WHERE m.class_id=? ORDER BY u.id`
  ).all(cl.id).map((u) => ({ ...u, ...computeGrade(u.id) }));

  res.json({ class: cl, cases, flashcards, members });
});

/* ---- Create class ---- */
const GRADING_ROLES = ["history", "overall", "both"];
/* A class may be enrolled in a research study, which is what makes consent
   enforceable for it. Returns the study id only when the study really exists. */
function resolveStudyId(v) {
  const id = Number(v) || 0;
  if (!id) return null;
  return db.prepare("SELECT id FROM research_studies WHERE id=?").get(id)?.id || null;
}
const HISTORY_FORMS = ["general", "internal", "obgyn", "cardio", "peds", "psych"];
r.post("/", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const { name_fa, name_en, desc_fa, desc_en, maxAttempts = 1, gradingRole = "both",
          historyForm = "general", logTranscript = false, studyId = null } = req.body || {};
  let code = genCode();
  for (let i = 0; i < 5; i++) {
    const exists = db.prepare("SELECT 1 FROM classes WHERE code=?").get(code);
    if (!exists) break; code = genCode();
  }
  const role = GRADING_ROLES.includes(gradingRole) ? gradingRole : "both";
  const hform = HISTORY_FORMS.includes(historyForm) ? historyForm : "general";
  const study = resolveStudyId(studyId);
  if (studyId && !study) return res.status(400).json({ error: "study_not_found" });
  const uni = currentUniversityId(req.user) || Number(req.body?.university_id || 0) || 1;
  if (req.user.role === "teacher" && !uni) return res.status(400).json({ error: "university_required", message_fa: "برای استاد انتخاب دانشگاه الزامی است." });
  const info = db.prepare(
    `INSERT INTO classes (name_fa,name_en,desc_fa,desc_en,code,owner_id,max_attempts,grading_role,history_form,university_id,log_transcript,study_id)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`
  ).run(name_fa, name_en, desc_fa, desc_en, code, req.user.id, maxAttempts, role, hform, uni,
        // Conversation logging is OFF unless the teacher explicitly asks for it.
        logTranscript === true ? 1 : 0, study);
  audit(req, "class.create", "class", { id: info.lastInsertRowid, log_transcript: logTranscript === true, study_id: study });
  res.json({ id: info.lastInsertRowid, code });
});

/* ---- Update class basic info ---- */
r.put("/:id", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const { name_fa, name_en, desc_fa, desc_en, maxAttempts, gradingRole, historyForm,
          liveBoardEnabled, liveBoardAnonymous, logTranscript, studyId } = req.body || {};
  const cur = db.prepare("SELECT grading_role, history_form, university_id, live_board_enabled, live_board_anonymous, log_transcript, study_id FROM classes WHERE id=?").get(req.params.id);
  if (!cur) return res.status(404).json({ error: "not found" });
  if (req.user.role === "teacher" && cur.university_id !== currentUniversityId(req.user)) return res.status(403).json({ error: "wrong_university" });
  const role = GRADING_ROLES.includes(gradingRole) ? gradingRole : (cur?.grading_role || "both");
  const hform = HISTORY_FORMS.includes(historyForm) ? historyForm : (cur?.history_form || "general");
  /* A field the caller did not send keeps its stored value. The previous
     `liveBoardEnabled === false ? 0 : 1` flipped the live board ON whenever a
     caller omitted the key (e.g. the quick edit modal), which silently
     published the class leaderboard. */
  const liveOn  = liveBoardEnabled  === undefined ? !!cur.live_board_enabled  : !!liveBoardEnabled;
  const liveAnon = liveBoardAnonymous === undefined ? !!cur.live_board_anonymous : !!liveBoardAnonymous;
  const logOn   = logTranscript     === undefined ? !!cur.log_transcript      : logTranscript === true;
  // Enrolling a class in a study is what makes consent enforceable for it.
  if (studyId !== undefined && studyId !== null && studyId !== "" && !resolveStudyId(studyId)) {
    return res.status(400).json({ error: "study_not_found" });
  }
  const study = studyId === undefined ? (cur.study_id || null) : (resolveStudyId(studyId) || null);
  db.prepare(
    "UPDATE classes SET name_fa=?,name_en=?,desc_fa=?,desc_en=?,max_attempts=?,grading_role=?,history_form=?,live_board_enabled=?,live_board_anonymous=?,log_transcript=?,study_id=? WHERE id=?"
  ).run(name_fa, name_en, desc_fa, desc_en, maxAttempts ?? 1, role, hform, liveOn ? 1 : 0, liveAnon ? 1 : 0, logOn ? 1 : 0, study, req.params.id);
  audit(req, "class.update", "class", { id: Number(req.params.id), log_transcript: logOn, live_board_enabled: liveOn, study_id: study });
  res.json({ ok: true, logTranscript: logOn, studyId: study });
});
r.delete("/:id", authRequired, requireRole("teacher", "admin"), (req, res) => {
  db.prepare("UPDATE classes SET active=0 WHERE id=?").run(req.params.id);
  res.json({ ok: true });
});

/* ---- Set the class's cases (replace list) ---- */
r.put("/:id/cases", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const { cases = [] } = req.body || {}; // [{case_id, weight}]
  const cid = req.params.id;
  const cl = db.prepare("SELECT * FROM classes WHERE id=?").get(cid);
  if (!cl) return res.status(404).json({ error: "not_found" });
  if (req.user.role === "teacher" && cl.university_id !== currentUniversityId(req.user)) return res.status(403).json({ error: "wrong_university" });
  const allowed = cases.filter((c) => db.prepare("SELECT 1 FROM cases WHERE id=? AND active=1 AND COALESCE(university_id,1)=?").get(c.case_id, cl.university_id || 1));
  const tx = db.transaction(() => {
    db.prepare("DELETE FROM class_cases WHERE class_id=?").run(cid);
    const ins = db.prepare("INSERT OR IGNORE INTO class_cases (class_id,case_id,weight) VALUES (?,?,?)");
    for (const c of allowed) ins.run(cid, c.case_id, c.weight || 1);
  });
  tx(); persistNow();
  res.json({ ok: true, added: allowed.length, skipped: cases.length - allowed.length });
});

/* ---- Set the class's flashcard sets (replace list) ---- */
r.put("/:id/flashcards", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const { flashcards = [] } = req.body || {}; // [{flashcard_id, weight, graded}]
  const cid = req.params.id;
  const cl = db.prepare("SELECT * FROM classes WHERE id=?").get(cid);
  if (!cl) return res.status(404).json({ error: "not_found" });
  if (req.user.role === "teacher" && cl.university_id !== currentUniversityId(req.user)) return res.status(403).json({ error: "wrong_university" });
  const allowed = flashcards.filter((f) => db.prepare("SELECT 1 FROM flashcards WHERE id=? AND active=1 AND COALESCE(university_id,1)=?").get(f.flashcard_id, cl.university_id || 1));
  const tx = db.transaction(() => {
    db.prepare("DELETE FROM class_flashcards WHERE class_id=?").run(cid);
    const ins = db.prepare("INSERT OR IGNORE INTO class_flashcards (class_id,flashcard_id,weight,graded) VALUES (?,?,?,?)");
    for (const f of allowed) ins.run(cid, f.flashcard_id, f.weight || 1, f.graded === false ? 0 : 1);
  });
  tx();
  persistNow();
  res.json({ ok: true, added: allowed.length, skipped: flashcards.length - allowed.length });
});

/* ---- Student submits a class flashcard-set score (0..100). Best is kept. ---- */
r.post("/:id/flashcard/:fid/finish", authRequired, requireRole("student"), (req, res) => {
  const cid = parseInt(req.params.id, 10), fid = parseInt(req.params.fid, 10);
  const info = classFlashcardInfo(req.user.id, cid, fid);
  if (!info.allowed) return res.status(403).json({ error: "not allowed" });
  if (info.remaining <= 0) return res.status(429).json({ error: "no attempts left", remaining: 0 });
  const score = Math.max(0, Math.min(100, parseInt(req.body?.score, 10) || 0));
  const answers = Array.isArray(req.body?.answers) ? req.body.answers : [];
  const durationSec = Math.max(0, Number(req.body?.durationSec || 0) || 0);
  db.prepare("INSERT INTO class_flashcard_attempts (class_id,flashcard_id,user_id,score,answers_json,duration_sec) VALUES (?,?,?,?,?,?)")
    .run(cid, fid, req.user.id, score, JSON.stringify(answers), durationSec);
  persistNow();
  res.json({ ok: true, score });
});

/* ---- Set the class's members (replace list) ---- */
r.put("/:id/members", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const { userIds = [] } = req.body || {};
  const cid = req.params.id;
  const cl = db.prepare("SELECT * FROM classes WHERE id=?").get(cid);
  if (!cl) return res.status(404).json({ error: "not_found" });
  if (req.user.role === "teacher" && cl.university_id !== currentUniversityId(req.user)) return res.status(403).json({ error: "wrong_university" });
  const allowed = userIds.filter((uid) => db.prepare("SELECT 1 FROM users WHERE id=? AND role='student' AND university_id=?").get(uid, cl.university_id));
  const skipped = userIds.length - allowed.length;
  const tx = db.transaction(() => {
    db.prepare("DELETE FROM class_members WHERE class_id=?").run(cid);
    const ins = db.prepare("INSERT OR IGNORE INTO class_members (class_id,user_id) VALUES (?,?)");
    for (const uid of allowed) ins.run(cid, uid);
  });
  tx();
  persistNow();
  res.json({ ok: true, added: allowed.length, skipped });
});

r.post("/:id/members/resolve", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const cl = db.prepare("SELECT * FROM classes WHERE id=?").get(req.params.id);
  if (!cl) return res.status(404).json({ error: "not_found" });
  if (req.user.role === "teacher" && cl.university_id !== currentUniversityId(req.user)) return res.status(403).json({ error: "wrong_university" });
  const raw = Array.isArray(req.body?.studentNos) ? req.body.studentNos : String(req.body?.studentNos || "").split(/[\s,;]+/);
  const names = req.body?.names || {};
  const createMissing = !!req.body?.createMissing;
  const existing = [], missing = [], wrongUniversity = [], created = [];
  for (const x of raw.map((v) => String(v).trim()).filter(Boolean)) {
    let u = studentByNo(x);
    if (!u && createMissing) { u = createStudentForUniversity({ sno: x, name: names[x] || x, universityId: cl.university_id, createdBy: req.user.id }); if (u) created.push(u); }
    if (!u) { missing.push(x); continue; }
    if (u.university_id !== cl.university_id) { wrongUniversity.push({ student_no: x, existing: u }); continue; }
    existing.push(u);
  }
  const unique = [...new Map(existing.map((u) => [u.id, u])).values()];
  if (req.body?.attach !== false) {
    const ins = db.prepare("INSERT OR IGNORE INTO class_members (class_id,user_id) VALUES (?,?)");
    for (const u of unique) ins.run(cl.id, u.id);
    persistNow();
  }
  res.json({ existing: unique, missing, wrongUniversity, created, attached: req.body?.attach === false ? 0 : unique.length });
});

const parseJson = (s, fb) => { try { return JSON.parse(s || ""); } catch { return fb; } };
function drawingStatus(ans) { return ans?.drawing?.approval?.status || (ans?.pendingApproval ? "pending" : "none"); }
r.get("/:id/drawing-reviews", authRequired, requireRole("teacher", "admin"), (req,res)=>{
  const cl = db.prepare("SELECT * FROM classes WHERE id=?").get(req.params.id); if(!cl) return res.status(404).json({error:"not_found"});
  if (req.user.role === "teacher" && cl.university_id !== currentUniversityId(req.user)) return res.status(403).json({ error: "wrong_university" });
  const rows = db.prepare(`SELECT a.*,u.name_fa,u.name_en,u.student_no FROM class_flashcard_attempts a LEFT JOIN users u ON u.id=a.user_id WHERE a.class_id=? ORDER BY a.id DESC`).all(cl.id);
  const reviews=[];
  for(const row of rows){ const answers=parseJson(row.answers_json,[]); (Array.isArray(answers)?answers:[]).forEach((ans,idx)=>{ if(ans?.type==='drawing' && ans.drawing?.preview) reviews.push({source:'class', attemptId:row.id, answerIndex:idx, classId:cl.id, card_id:ans.card_id, order:ans.order, student:{id:row.user_id,name_fa:row.name_fa,name_en:row.name_en,student_no:row.student_no}, score:row.score, question_fa:ans.question_fa, question_en:ans.question_en, proposedPoints:ans.proposedPoints||0, points:ans.points||0, status:drawingStatus(ans), drawing:ans.drawing, created_at:row.created_at}); }); }
  res.json({ reviews });
});
r.post("/:id/drawing-reviews/:attemptId/:answerIndex", authRequired, requireRole("teacher", "admin"), (req,res)=>{
  const cl = db.prepare("SELECT * FROM classes WHERE id=?").get(req.params.id); if(!cl) return res.status(404).json({error:"not_found"});
  if (req.user.role === "teacher" && cl.university_id !== currentUniversityId(req.user)) return res.status(403).json({ error: "wrong_university" });
  const at=db.prepare("SELECT * FROM class_flashcard_attempts WHERE id=? AND class_id=?").get(req.params.attemptId, cl.id); if(!at) return res.status(404).json({error:"attempt_not_found"});
  const answers=parseJson(at.answers_json,[]); const idx=Number(req.params.answerIndex), ans=answers[idx]; if(!ans||ans.type!=="drawing") return res.status(404).json({error:"drawing_not_found"});
  const prev=Number(ans.points||0), proposed=Math.max(0, Number(req.body?.points ?? ans.proposedPoints ?? ans.drawing?.pointsFrac*100 ?? 0)||0);
  const status=req.body?.status === "approved" ? "approved" : "rejected";
  ans.points=status==='approved'?proposed:0; ans.solved=status==='approved'; ans.pendingApproval=false; ans.drawing={...(ans.drawing||{}), approval:{status, feedback:req.body?.feedback||"", reviewer_id:req.user.id, reviewed_at:new Date().toISOString(), points:ans.points}}; answers[idx]=ans;
  const newScore=Math.max(0, Math.min(100, Math.round((Number(at.score)||0)-prev+Number(ans.points||0))));
  db.prepare("UPDATE class_flashcard_attempts SET score=?, answers_json=? WHERE id=?").run(newScore, JSON.stringify(answers), at.id);
  persistNow(); res.json({ok:true, score:newScore, review:ans.drawing.approval});
});


function pct(n, d) { return d ? Math.round((Number(n || 0) / Number(d || 1)) * 100) : 0; }
function addAgg(map, key, label_fa, label_en, score, total = 100) {
  if (!key) return;
  const it = map[key] ||= { key, label_fa: label_fa || key, label_en: label_en || label_fa || key, sum: 0, total: 0, n: 0 };
  it.sum += Number(score || 0); it.total += Number(total || 100); it.n++;
}
function aggRows(map) { return Object.values(map).map((x) => ({ ...x, avg: pct(x.sum, x.total) })).sort((a, b) => a.avg - b.avg); }
function parseSafe(s, fb) { try { return JSON.parse(s || ""); } catch { return fb; } }
function classAnalyticsPayload(cl) {
  const members = db.prepare(`SELECT u.id,u.name_fa,u.name_en,u.student_no FROM class_members m JOIN users u ON u.id=m.user_id WHERE m.class_id=?`).all(cl.id);
  const byStudent = [];
  const topicAgg = {}, itemAgg = {}, criterionAgg = {};
  let totalAttempts = 0, pendingDrawings = 0;
  for (const u of members) {
    const vp = db.prepare("SELECT * FROM attempts WHERE class_id=? AND user_id=? AND type='vp'").all(cl.id, u.id);
    const fl = db.prepare("SELECT a.*, f.data_json FROM class_flashcard_attempts a LEFT JOIN flashcards f ON f.id=a.flashcard_id WHERE a.class_id=? AND a.user_id=?").all(cl.id, u.id);
    totalAttempts += vp.length + fl.length;
    const scores = [];
    for (const a of vp) {
      scores.push(Number(a.score || 0));
      const ev = parseSafe(a.eval_json, {});
      if (ev.sectionScores) {
        for (const [k, v] of Object.entries(ev.sectionScores)) addAgg(criterionAgg, `vp:${k}`, k, k, v, 100);
      }
      if (Array.isArray(ev.results)) for (const r of ev.results) addAgg(criterionAgg, `crit:${r.label || r.id}`, r.label || r.id, r.label || r.id, r.done ? 100 : 0, 100);
    }
    for (const a of fl) {
      scores.push(Number(a.score || 0));
      const card = parseSafe(a.data_json, {});
      const answers = parseSafe(a.answers_json, []);
      for (const ans of Array.isArray(answers) ? answers : []) {
        const topic = ans.category_fa || ans.title_fa || card.category_fa || card.title_fa || "فلش‌کارت";
        addAgg(topicAgg, topic, topic, ans.category_en || card.category_en || topic, ans.points || 0, ans.proposedPoints || 100);
        addAgg(itemAgg, `card:${ans.card_id || a.flashcard_id}:${ans.order || 0}`, ans.question_fa || ans.title_fa || topic, ans.question_en || ans.title_en || topic, ans.points || 0, ans.proposedPoints || 100);
        if (ans.pendingApproval || ans.drawing?.approval?.status === 'pending') pendingDrawings++;
      }
    }
    const avg = scores.length ? Math.round(scores.reduce((x, y) => x + y, 0) / scores.length) : null;
    byStudent.push({ ...u, attempts: scores.length, avg });
  }
  const topics = aggRows(topicAgg), items = aggRows(itemAgg), criteria = aggRows(criterionAgg);
  const students = byStudent.sort((a,b)=>(a.avg ?? -1)-(b.avg ?? -1));
  return {
    class: { id: cl.id, name_fa: cl.name_fa, name_en: cl.name_en, code: cl.code },
    summary: { students: members.length, attempts: totalAttempts, pendingDrawings },
    strengths: topics.filter((x) => x.avg >= 75).sort((a,b)=>b.avg-a.avg).slice(0, 8),
    weaknesses: topics.filter((x) => x.avg < 70).slice(0, 8),
    itemWeaknesses: items.slice(0, 12),
    criterionWeaknesses: criteria.slice(0, 12),
    supportNeeded: students.filter((s) => s.avg != null && s.avg < 70).slice(0, 10),
    topStudents: [...byStudent].filter((s)=>s.avg!=null).sort((a,b)=>b.avg-a.avg).slice(0, 10),
  };
}
r.get("/:id/analytics", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const cl = db.prepare("SELECT * FROM classes WHERE id=?").get(req.params.id);
  if (!cl) return res.status(404).json({ error: "not_found" });
  if (req.user.role === "teacher" && cl.university_id !== currentUniversityId(req.user)) return res.status(403).json({ error: "wrong_university" });
  res.json(classAnalyticsPayload(cl));
});

/* ---- Teacher/admin: review a student's attempts in this class, INCLUDING the
   full AI conversation transcript + the section-by-section evaluation, so they
   can verify the AI's scoring and the student's history-taking. ---- */
function canManageClass(user, cl) {
  return user.role === "admin" || (user.role === "teacher" && cl.owner_id === user.id);
}

/* ---- Teacher display: live classroom competition board.
   Poll-friendly (no WebSocket dependency): teacher opens this on the projector;
   the client refreshes every few seconds. Optional anonymization protects
   students when the board is shown publicly. */
r.get("/:id/live-board", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const cl = db.prepare("SELECT * FROM classes WHERE id=?").get(req.params.id);
  if (!cl) return res.status(404).json({ error: "not found" });
  if (!canManageClass(req.user, cl)) return res.status(403).json({ error: "not your class" });

  const members = db.prepare(`SELECT u.id,u.name_fa,u.name_en,u.student_no
    FROM class_members m JOIN users u ON u.id=m.user_id WHERE m.class_id=?`).all(cl.id);
  const caseCount = db.prepare("SELECT COUNT(*) n FROM class_cases WHERE class_id=?").get(cl.id).n;
  const flashCount = db.prepare("SELECT COUNT(*) n FROM class_flashcards WHERE class_id=?").get(cl.id).n;
  const anonymize = !!cl.live_board_anonymous || req.query.anon === "1";
  const alias = (i) => `MED-${String(i + 1).padStart(2, "0")}`;

  const rows = members.map((u, i) => {
    const caseBest = db.prepare(`SELECT COUNT(*) done, AVG(best) avgScore FROM (
      SELECT case_id, MAX(score) best FROM attempts
      WHERE class_id=? AND user_id=? AND type='vp' GROUP BY case_id
    )`).get(cl.id, u.id) || {};
    const flashBest = db.prepare(`SELECT COUNT(*) done, AVG(best) avgScore FROM (
      SELECT flashcard_id, MAX(score) best FROM class_flashcard_attempts
      WHERE class_id=? AND user_id=? GROUP BY flashcard_id
    )`).get(cl.id, u.id) || {};
    const latest = db.prepare(`SELECT created_at, score, kind FROM (
      SELECT created_at, score, 'case' kind FROM attempts WHERE class_id=? AND user_id=?
      UNION ALL
      SELECT created_at, score, 'flashcard' kind FROM class_flashcard_attempts WHERE class_id=? AND user_id=?
    ) ORDER BY created_at DESC LIMIT 1`).get(cl.id, u.id, cl.id, u.id) || null;
    const done = (caseBest.done || 0) + (flashBest.done || 0);
    const total = caseCount + flashCount;
    const scores = [caseBest.avgScore, flashBest.avgScore].filter((x) => x != null);
    const avg = scores.length ? Math.round(scores.reduce((a,b)=>a+Number(b),0)/scores.length) : null;
    const grade = avg == null ? 0 : avg;
    return {
      user_id: u.id,
      displayName: anonymize ? alias(i) : (u.name_fa || u.name_en || alias(i)),
      name_fa: anonymize ? alias(i) : u.name_fa,
      name_en: anonymize ? alias(i) : u.name_en,
      student_no: anonymize ? "" : u.student_no,
      done, total, progress: total ? Math.round((done / total) * 100) : 0,
      score: avg, grade, latest,
    };
  }).sort((a, b) => (b.grade - a.grade) || (b.progress - a.progress) || String(a.displayName).localeCompare(String(b.displayName)))
    .map((r, i) => ({ ...r, rank: i + 1 }));

  res.json({ class: { id: cl.id, name_fa: cl.name_fa, name_en: cl.name_en, code: cl.code,
    live_board_enabled: !!cl.live_board_enabled, live_board_anonymous: !!cl.live_board_anonymous },
    totals: { students: members.length, items: caseCount + flashCount, cases: caseCount, flashcards: flashCount },
    updatedAt: new Date().toISOString(), ranked: rows });
});

/* ---- Live-board drill-down: questions and answers for one student.
   Used when a teacher clicks a student on the classroom display. */
r.get("/:id/live-board/:userId/details", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const cl = db.prepare("SELECT * FROM classes WHERE id=?").get(req.params.id);
  if (!cl) return res.status(404).json({ error: "not found" });
  if (!canManageClass(req.user, cl)) return res.status(403).json({ error: "not your class" });
  const uid = Number(req.params.userId);
  const mem = db.prepare(`SELECT u.id,u.name_fa,u.name_en,u.student_no FROM class_members m JOIN users u ON u.id=m.user_id WHERE m.class_id=? AND u.id=?`).get(cl.id, uid);
  if (!mem) return res.status(404).json({ error: "not member" });

  const vpRows = db.prepare(`SELECT a.id, a.case_id, a.score, a.transcript_json, a.eval_json, a.duration_sec, a.created_at, c.data_json
    FROM attempts a LEFT JOIN cases c ON c.id=a.case_id
    WHERE a.class_id=? AND a.user_id=? AND a.type='vp'
    ORDER BY a.id DESC LIMIT 20`).all(cl.id, uid).map((a) => {
      const cd = parseJson(a.data_json, {});
      return { kind: "vp", attemptId: a.id, case_id: a.case_id, title_fa: cd.title_fa || "", title_en: cd.title_en || "", score: a.score, duration_sec: a.duration_sec, created_at: a.created_at, transcript: parseJson(a.transcript_json, {}), eval: parseJson(a.eval_json, {}) };
    });

  const flashRows = db.prepare(`SELECT a.id, a.flashcard_id, a.score, a.answers_json, a.duration_sec, a.created_at, f.data_json
    FROM class_flashcard_attempts a LEFT JOIN flashcards f ON f.id=a.flashcard_id
    WHERE a.class_id=? AND a.user_id=?
    ORDER BY a.id DESC LIMIT 30`).all(cl.id, uid).map((a) => {
      const fd = parseJson(a.data_json, {});
      return { kind: "flashcard", attemptId: a.id, flashcard_id: a.flashcard_id, title_fa: fd.title_fa || "", title_en: fd.title_en || "", score: a.score, duration_sec: a.duration_sec, created_at: a.created_at, answers: parseJson(a.answers_json, []) };
    });

  res.json({ student: mem, attempts: [...flashRows, ...vpRows].sort((x, y) => String(y.created_at || "").localeCompare(String(x.created_at || ""))) });
});

// list a member's attempts (summary) for a class
r.get("/:id/members/:userId/attempts", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const cl = db.prepare("SELECT * FROM classes WHERE id=?").get(req.params.id);
  if (!cl) return res.status(404).json({ error: "not found" });
  if (!canManageClass(req.user, cl)) return res.status(403).json({ error: "not your class" });
  const rows = db.prepare(
    `SELECT a.id, a.case_id, a.score, a.turns, a.tests, a.imaging_count, a.ddx_count,
            a.duration_sec, a.lang, a.created_at, c.data_json
       FROM attempts a LEFT JOIN cases c ON c.id = a.case_id
      WHERE a.user_id=? AND a.class_id=? AND a.type='vp'
      ORDER BY a.created_at DESC`
  ).all(req.params.userId, cl.id).map((row) => {
    const cd = row.data_json ? JSON.parse(row.data_json) : {};
    return {
      id: row.id, case_id: row.case_id, caseTitle_fa: cd.title_fa, caseTitle_en: cd.title_en,
      score: row.score, turns: row.turns, tests: row.tests, imaging: row.imaging_count,
      ddx: row.ddx_count, durationSec: row.duration_sec, lang: row.lang, created_at: row.created_at,
    };
  });
  res.json({ attempts: rows });
});

// full detail of a single attempt: transcript + evaluation (with section scores)
r.get("/:id/attempts/:attemptId", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const cl = db.prepare("SELECT * FROM classes WHERE id=?").get(req.params.id);
  if (!cl) return res.status(404).json({ error: "not found" });
  if (!canManageClass(req.user, cl)) return res.status(403).json({ error: "not your class" });
  const a = db.prepare("SELECT * FROM attempts WHERE id=? AND class_id=?").get(req.params.attemptId, cl.id);
  if (!a) return res.status(404).json({ error: "attempt not found" });
  const u = db.prepare("SELECT id, name_fa, name_en, student_no FROM users WHERE id=?").get(a.user_id);
  const cd = a.case_id ? db.prepare("SELECT data_json FROM cases WHERE id=?").get(a.case_id) : null;
  const caseData = cd ? JSON.parse(cd.data_json) : {};
  let transcript = null, evalRes = null;
  try { transcript = JSON.parse(a.transcript_json || "null"); } catch { /* */ }
  try { evalRes = JSON.parse(a.eval_json || "null"); } catch { /* */ }
  res.json({
    attempt: {
      id: a.id, score: a.score, lang: a.lang, created_at: a.created_at,
      durationSec: a.duration_sec, turns: a.turns,
      caseTitle_fa: caseData.title_fa, caseTitle_en: caseData.title_en,
    },
    student: u, transcript, eval: evalRes,
  });
});

/* ---- Conversation log for one attempt (teacher/admin only) ----
   Returns the timestamped interaction log when the class had logging ON. When
   logging was OFF the attempt has no transcript and this says so explicitly,
   rather than returning an empty array that could be mistaken for "the student
   said nothing". */
r.get("/:id/attempts/:attemptId/session-log", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const cl = db.prepare("SELECT * FROM classes WHERE id=?").get(req.params.id);
  if (!cl) return res.status(404).json({ error: "not found" });
  if (!canManageClass(req.user, cl)) return res.status(403).json({ error: "not your class" });
  const a = db.prepare("SELECT * FROM attempts WHERE id=? AND class_id=?").get(req.params.attemptId, cl.id);
  if (!a) return res.status(404).json({ error: "attempt not found" });
  const logs = sessionsForAttempt(a.id);
  const u = db.prepare("SELECT id, name_fa, name_en, student_no FROM users WHERE id=?").get(a.user_id);
  res.json({
    attempt: { id: a.id, score: a.score, duration_sec: a.duration_sec, created_at: a.created_at },
    student: u,
    loggingEnabled: logs.length ? logs[0].logging_enabled : !!cl.log_transcript,
    sessions: logs,
  });
});

/* ---- CSV export of every logged conversation in a class ----
   One row per event, so the file can be pivoted in any stats package. Columns
   are fixed-width ASCII so no encoding surprises in Excel/SPSS/R. */
r.get("/:id/conversation-log.csv", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const cl = db.prepare("SELECT * FROM classes WHERE id=?").get(req.params.id);
  if (!cl) return res.status(404).json({ error: "not found" });
  if (!canManageClass(req.user, cl)) return res.status(403).json({ error: "not your class" });
  if (!cl.log_transcript) return res.status(409).json({ error: "logging_disabled" });

  const esc = (v) => { const x = v == null ? "" : String(v); return /[,\n\r"]/.test(x) ? `"${x.replace(/"/g, '""')}"` : x; };
  const header = ["session_id","user_id","student_no","case_id","attempt_id","seq","at_ms","kind","text","detail","started_at"];
  const lines = [header.join(",")];

  const sessions = db.prepare(
    `SELECT s.*, u.student_no FROM vp_sessions s LEFT JOIN users u ON u.id=s.user_id
      WHERE s.class_id=? AND s.logging_enabled=1 ORDER BY s.id, 1`
  ).all(cl.id);
  for (const s of sessions) {
    const events = db.prepare("SELECT seq,at_ms,kind,payload_json FROM vp_session_events WHERE session_id=? ORDER BY seq").all(s.id);
    for (const e of events) {
      let p = {}; try { p = JSON.parse(e.payload_json); } catch { /* */ }
      const { text, query, tab, note, source, found, ...rest } = p;
      lines.push([
        s.id, s.user_id, s.student_no || "", s.case_id, s.attempt_id || "",
        e.seq, e.at_ms, e.kind,
        esc(text ?? ""), esc(JSON.stringify({ ...(query ? { query } : {}), ...(tab ? { tab } : {}), ...(note ? { note } : {}), ...(source ? { source } : {}), ...(found != null ? { found } : {}), ...rest })),
        esc(s.started_at),
      ].join(","));
    }
  }
  audit(req, "class.conversation_export", "class", { id: cl.id, sessions: sessions.length });
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="conversation-log-${cl.code || cl.id}.csv"`);
  res.send("\uFEFF" + lines.join("\n"));
});

/* ---- Teacher/admin: gradebook CSV including the SEPARATE history score
   (extern criterion), other-sections score, and overall — per student. Uses
   each student's best attempt per case. Deterministic, no cost. ---- */
r.get("/:id/gradebook.csv", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const cl = db.prepare("SELECT * FROM classes WHERE id=?").get(req.params.id);
  if (!cl) return res.status(404).json({ error: "not found" });
  if (!canManageClass(req.user, cl)) return res.status(403).json({ error: "not your class" });
  const fa = req.query.lang !== "en";
  const members = db.prepare(
    `SELECT u.id, u.name_fa, u.name_en, u.student_no
       FROM class_members m JOIN users u ON u.id = m.user_id
      WHERE m.class_id=? ORDER BY u.id`
  ).all(cl.id);

  const esc = (v) => { const s = v == null ? "" : String(v); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  const header = [
    fa ? "نام" : "name", fa ? "شمارهٔ‌دانشجویی" : "student_no",
    fa ? "نمرهٔ‌شرح‌حال(اکسترن)" : "history_score_extern",
    fa ? "نمرهٔ‌سایر" : "other_score",
    fa ? "نمرهٔ‌کلی(اینترن)" : "overall_score_intern",
    fa ? "تعداد‌آزمون" : "attempts",
  ];
  const lines = [header.map(esc).join(",")];

  for (const u of members) {
    // best attempt (by score) per case for this student in this class
    const rows = db.prepare(
      `SELECT case_id, MAX(score) AS best, COUNT(*) AS n FROM attempts
        WHERE user_id=? AND class_id=? AND type='vp' GROUP BY case_id`
    ).all(u.id, cl.id);
    let hSum = 0, hN = 0, oSum = 0, oN = 0, allSum = 0, allN = 0, attempts = 0;
    for (const row of rows) {
      attempts += row.n;
      const a = db.prepare(
        "SELECT eval_json, score FROM attempts WHERE user_id=? AND class_id=? AND case_id=? ORDER BY score DESC LIMIT 1"
      ).get(u.id, cl.id, row.case_id);
      let ev = null; try { ev = JSON.parse(a?.eval_json || "null"); } catch { /* */ }
      const ss = ev?.sectionScores;
      if (ss?.history != null) { hSum += ss.history; hN++; }
      if (ss?.other != null) { oSum += ss.other; oN++; }
      const overall = ss?.overall != null ? ss.overall : (a?.score ?? 0);
      allSum += overall; allN++;
    }
    const avg = (s, n) => (n ? Math.round(s / n) : "");
    const line = [
      fa ? (u.name_fa || u.name_en || "") : (u.name_en || u.name_fa || ""), u.student_no || "",
      avg(hSum, hN), avg(oSum, oN), avg(allSum, allN), attempts,
    ];
    lines.push(line.map(esc).join(","));
  }
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="gradebook-${cl.code || cl.id}.csv"`);
  res.send("\uFEFF" + lines.join("\n"));
});

/* ================================================================
   Teacher progress dashboard for a whole class.
   The protocol requires the professor to see every student's progress
   profile (radar + line) and to hand a remedial scenario to anyone
   scoring below 6/10.
   ================================================================ */
const REMEDIAL_THRESHOLD = 6;      // out of 10, per the protocol

/* The score that counts for an attempt. A teacher's review overrides the AI,
   and a rejected attempt counts as zero. This is the ONE definition used by
   both the dashboard and the remedial selection, so the two can never disagree
   about who is below the threshold. */
function effectiveScore100(a) {
  if (a.teacher_status === "adjusted" && a.teacher_score != null) return a.teacher_score;
  if (a.teacher_status === "rejected") return 0;
  return a.score;
}

/* Compute the whole class's progress profiles. Shared by GET /:id/progress and
   POST /:id/remedial. */
function classProgress(cl) {
  const members = db.prepare(
    `SELECT u.id, u.student_no, COALESCE(u.name_fa,u.name_en,u.username) AS name
       FROM class_members m JOIN users u ON u.id=m.user_id WHERE m.class_id=? ORDER BY u.student_no`
  ).all(cl.id);
  const J = (x) => { try { return JSON.parse(x); } catch { return null; } };

  const students = members.map((u) => {
    const rows = db.prepare(
      `SELECT id, score, eval_json, teacher_status, teacher_score, created_at
         FROM attempts WHERE user_id=? AND class_id=? AND type='vp' ORDER BY created_at ASC`
    ).all(u.id, cl.id);

    // Line: the score that counts, over time. The protocol reports out of 10;
    // attempts store a 0-100 percentage.
    const line = rows.map((a) => {
      const s100 = effectiveScore100(a);
      return { at: a.created_at, score: s100, aiScore: a.score,
               score10: Math.round(((s100 || 0) / 10) * 10) / 10 };
    });

    // Radar: pass rate per checklist criterion across this student's attempts.
    const agg = {};
    for (const a of rows) {
      const ev = J(a.eval_json); if (!ev || !Array.isArray(ev.results)) continue;
      for (const it of ev.results) {
        const key = it.label || it.id; if (!key) continue;
        agg[key] = agg[key] || { done: 0, total: 0 };
        agg[key].total += 1; if (it.done) agg[key].done += 1;
      }
    }
    const radar = Object.entries(agg).map(([label, v]) => ({
      label, value: v.total ? Math.round((v.done / v.total) * 100) : 0,
    }));

    const latest = line.length ? line[line.length - 1].score10 : null;
    const best = line.length ? Math.max(...line.map((p2) => p2.score10)) : null;
    return {
      userId: u.id, studentNo: u.student_no || "", name: u.name || "",
      attempts: rows.length, latest, best,
      needsRemedial: latest != null && latest < REMEDIAL_THRESHOLD,
      line, radar,
    };
  });

  const withScore = students.filter((x) => x.latest != null);
  return {
    classId: cl.id, threshold: REMEDIAL_THRESHOLD,
    totals: {
      students: students.length,
      notStarted: students.filter((x) => x.attempts === 0).length,
      needsRemedial: students.filter((x) => x.needsRemedial).length,
      mean: withScore.length
        ? Math.round((withScore.reduce((a, x) => a + x.latest, 0) / withScore.length) * 10) / 10
        : null,
    },
    students,
  };
}

r.get("/:id/progress", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const cl = db.prepare("SELECT * FROM classes WHERE id=?").get(req.params.id);
  if (!cl) return res.status(404).json({ error: "not found" });
  if (!canManageClass(req.user, cl)) return res.status(403).json({ error: "not your class" });
  res.json(classProgress(cl));
});

/* Assign a remedial scenario to everyone below the threshold (or to an
   explicit list). Uses exam_assignments, which the standalone case list
   already reads, so the student sees it with no client change. */
r.post("/:id/remedial", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const cl = db.prepare("SELECT * FROM classes WHERE id=?").get(req.params.id);
  if (!cl) return res.status(404).json({ error: "not found" });
  if (!canManageClass(req.user, cl)) return res.status(403).json({ error: "not your class" });

  const caseId = Number(req.body?.caseId || 0);
  if (!caseId) return res.status(400).json({ error: "case_required" });
  if (!db.prepare("SELECT id FROM cases WHERE id=?").get(caseId)) return res.status(404).json({ error: "case_not_found" });

  const explicit = Array.isArray(req.body?.userIds) ? req.body.userIds.map(Number).filter(Boolean) : null;
  /* Derive the targets from the very same progress computation the dashboard
     shows. Reading `attempts.score` directly here (as an earlier version did)
     ignored a teacher's override, so the dashboard could flag a student as
     needing remedial while this endpoint selected nobody. */
  const targets = explicit
    || classProgress(cl).students.filter((x) => x.needsRemedial).map((x) => x.userId);

  const maxAttempts = Math.max(1, Number(req.body?.maxAttempts) || 2);
  const byUser = new Map(db.prepare("SELECT id, user_id FROM exam_assignments WHERE case_id=?")
    .all(caseId).map((e) => [e.user_id, e.id]));
  let created = 0, updated = 0;
  for (const uid of targets) {
    if (byUser.has(uid)) {
      db.prepare("UPDATE exam_assignments SET active=1, max_attempts=?, assigned_by=? WHERE id=?")
        .run(maxAttempts, req.user.id, byUser.get(uid));
      updated++;
    } else {
      db.prepare("INSERT INTO exam_assignments (user_id,case_id,assigned_by,max_attempts,active) VALUES (?,?,?,?,1)")
        .run(uid, caseId, req.user.id, maxAttempts);
      created++;
    }
  }
  persistNow();
  audit(req, "class.remedial_assigned", "class",
        { id: cl.id, caseId, students: targets.length, threshold: REMEDIAL_THRESHOLD });
  res.json({ ok: true, caseId, assigned: targets.length, created, updated,
             threshold: REMEDIAL_THRESHOLD, userIds: targets });
});

export default r;

/* ---- shared helper for exam.js: is this student allowed to take
        this case within this class, and how many attempts remain? ---- */
export function classAttemptInfo(userId, classId, caseId) {
  const cl = db.prepare("SELECT * FROM classes WHERE id=? AND active=1").get(classId);
  if (!cl) return { allowed: false };
  const member = db.prepare("SELECT 1 FROM class_members WHERE class_id=? AND user_id=?").get(classId, userId);
  const hasCase = db.prepare("SELECT 1 FROM class_cases WHERE class_id=? AND case_id=?").get(classId, caseId);
  if (!member || !hasCase) return { allowed: false };
  const used = db.prepare(
    "SELECT COUNT(*) n FROM attempts WHERE user_id=? AND case_id=? AND class_id=?"
  ).get(userId, caseId, classId).n;
  return { allowed: true, remaining: Math.max(0, (cl.max_attempts ?? 1) - used), maxAttempts: cl.max_attempts ?? 1 };
}

/* ---- Is this student allowed to take this flashcard set in this class,
        and how many attempts remain? ---- */
export function classFlashcardInfo(userId, classId, flashcardId) {
  const cl = db.prepare("SELECT * FROM classes WHERE id=? AND active=1").get(classId);
  if (!cl) return { allowed: false };
  const member = db.prepare("SELECT 1 FROM class_members WHERE class_id=? AND user_id=?").get(classId, userId);
  const has = db.prepare("SELECT 1 FROM class_flashcards WHERE class_id=? AND flashcard_id=?").get(classId, flashcardId);
  if (!member || !has) return { allowed: false };
  const used = db.prepare(
    "SELECT COUNT(*) n FROM class_flashcard_attempts WHERE user_id=? AND flashcard_id=? AND class_id=?"
  ).get(userId, flashcardId, classId).n;
  return { allowed: true, remaining: Math.max(0, (cl.max_attempts ?? 1) - used), maxAttempts: cl.max_attempts ?? 1 };
}
