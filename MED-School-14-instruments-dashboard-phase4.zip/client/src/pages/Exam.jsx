import { useEffect, useRef, useState } from "react";
import { useApp } from "../context.jsx";
import { api, getToken } from "../api.js";
import { TopBar, Spinner } from "../components/UI.jsx";
import { biField } from "../i18n.js";
import OrderSearch from "../components/OrderSearch.jsx";
import { LAB_TESTS, IMAGING_STUDIES } from "../data/medical-catalog.js";
import { useAntiCheat } from "../utils/antiCheat.js";
import Icon from "../components/Icon.jsx";

/* Human-readable reason for a 403 from the exam endpoints. The server sends a
   machine-readable `reason` so the student is told WHAT happened (out of
   attempts vs. never assigned) instead of seeing the exam silently reset. */
function refusalMessage(e, t, lang) {
  const reason = e?.data?.reason;
  if (reason === "attempts_exhausted") return t("attemptsExhausted");
  if (reason === "window") return lang === "fa" ? "پنجرهٔ زمانی این آزمون بسته است." : "This exam's time window is closed.";
  return e?.message || t("errorGeneric");
}

export default function Exam({ caseId, classId, examId, examDuration, antiCheat, go, home }) {
  const { t, lang } = useApp();
  const [caseData, setCaseData] = useState(null);
  const [settings, setSettings] = useState({ duration: 15 });
  const [phase, setPhase] = useState("exam"); // exam | evaluating | report
  const [messages, setMessages] = useState([]);
  const [typing, setTyping] = useState(false);
  const [input, setInput] = useState("");
  const [tab, setTab] = useState("history");
  const [tests, setTests] = useState([]);
  const [imaging, setImaging] = useState([]);
  const [ddx, setDdx] = useState([]);
  const [finalDx, setFinalDx] = useState("");
  const [timeLeft, setTimeLeft] = useState(null);
  const [evalRes, setEvalRes] = useState(null);
  const [error, setError] = useState("");   // server-side refusal (e.g. attempts exhausted)
  /* Research consent. `null` = not checked yet. The gate is checked BEFORE the
     encounter is opened, so no session row and no transcript can exist for a
     participant who has not agreed to take part. */
  const [consent, setConsent] = useState(null);
  const [consentBusy, setConsentBusy] = useState(false);
  /* Conversation logging (research). The server decides whether this encounter
     is recorded at all (per-class switch); we buffer timestamped events here and
     send them with the evaluation. The buffer is only uploaded when the server
     said logging is on, so nothing leaves the browser otherwise. */
  const sessionIdRef = useRef(null);
  const eventsRef = useRef([]);
  const loggingRef = useRef(false);
  const logEvent = (kind, extra = {}) => {
    if (!loggingRef.current) return;
    eventsRef.current.push({ kind, atMs: Date.now() - startRef.current, ...extra });
  };
  const { leaves } = useAntiCheat(!!examId && antiCheat && phase === "exam");
  const startRef = useRef(Date.now());
  const chatEnd = useRef(null);

  useEffect(() => {
    (async () => {
      const [c, s] = await Promise.all([api.get(`/cases/${caseId}`), api.get("/settings/exam")]);
      // Prefer the specific exam's duration when launched from a scheduled exam.
      const mins = examDuration || s.duration || 15;
      setCaseData(c); setSettings(s); setTimeLeft(mins * 60);
      // If this class/exam belongs to a research study, the participant must
      // agree before anything is recorded — so ask first, then open the session.
      let cs = null;
      try {
        cs = await api.get(`/research/consent/status?classId=${classId || ""}&examId=${examId || ""}`);
        setConsent(cs);
      } catch { setConsent({ required: false, granted: true }); }
      if (cs && cs.required && !cs.granted) return;
      // Open the encounter server-side: it stamps the real start time and tells
      // us whether this class has conversation logging switched on.
      try {
        const sess = await api.post("/exam/session-start", { caseId, classId, examId, lang });
        sessionIdRef.current = sess.sessionId;
        loggingRef.current = !!sess.loggingEnabled;
      } catch { /* the encounter still works without a session row */ }
    })();
  }, [caseId]);

  const agreeConsent = async () => {
    setConsentBusy(true);
    try {
      await api.post("/research/consent", { study_id: consent.studyId });
      const fresh = await api.get(`/research/consent/status?classId=${classId || ""}&examId=${examId || ""}`);
      setConsent(fresh);
      logEvent("consent_granted", { studyId: consent.studyId });
      const sess = await api.post("/exam/session-start", { caseId, classId, examId, lang });
      sessionIdRef.current = sess.sessionId;
      loggingRef.current = !!sess.loggingEnabled;
    } catch (e) { setError(e?.message || t("errorGeneric")); }
    finally { setConsentBusy(false); }
  };
  const declineConsent = async () => {
    setConsentBusy(true);
    try { await api.post("/research/consent/withdraw", { study_id: consent.studyId, note: "declined at entry" }); }
    catch { /* declining needs no record to succeed */ }
    finally { setConsentBusy(false); go(classId ? "classes" : examId ? "exams" : "caseList"); }
  };

  /* An abandoned session is meaningful for the study (it is a dropout data
     point, and the partial transcript shows where they got stuck). Uses fetch
     with keepalive rather than sendBeacon because the auth token has to travel
     as a header, which sendBeacon cannot set. */
  useEffect(() => () => {
    if (!sessionIdRef.current || !loggingRef.current || !eventsRef.current.length) return;
    try {
      fetch("/api/exam/session-abandon", {
        method: "POST", keepalive: true, credentials: "same-origin",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken()}` },
        body: JSON.stringify({ sessionId: sessionIdRef.current, events: eventsRef.current }),
      }).catch(() => {});
    } catch { /* best-effort */ }
  }, []);

  useEffect(() => {
    if (timeLeft == null || phase !== "exam") return;
    if (timeLeft <= 0) { finish(); return; }
    const id = setTimeout(() => setTimeLeft((x) => x - 1), 1000);
    return () => clearTimeout(id);
  }, [timeLeft, phase]);

  useEffect(() => { chatEnd.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, typing]);

  const fmt = (s) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

  const send = async () => {
    const text = input.trim(); if (!text) return;
    const priorHistory = messages;               // conversation so far (for LLM memory)
    setMessages((m) => [...m, { role: "student", text }]);
    logEvent("student_msg", { text });
    setInput(""); setTyping(true);
    try {
      const reply = await api.post("/exam/patient-reply",
        { caseId, userText: text, history: priorHistory, lang, classId, examId });
      setMessages((m) => [...m, { role: "patient", text: reply.text }]);
      // `source` distinguishes a real model turn from the deterministic
      // fallback — that distinction matters when analysing the transcripts.
      logEvent("patient_msg", { text: reply.text, source: reply.source });
    } catch (e) {
      setMessages((m) => [...m, { role: "patient", text: "…" }]);
      if (e?.status === 403) setError(refusalMessage(e, t, lang));
    } finally { setTyping(false); }
  };

  // When a student orders a test/imaging, fetch the lab/radiology report and
  // drop it into the chat (recorded result, or "normal" if not in the chart).
  const orderResult = async (kind, query) => {
    if (!query || !query.trim()) return;
    setTyping(true);
    try {
      const r = await api.post("/exam/order", { caseId, kind, query: query.trim(), lang, classId, examId });
      setMessages((m) => [...m, { role: "lab", text: r.text, imageUrl: r.imageUrl || null }]);
      logEvent(kind === "imaging" ? "imaging_order" : "lab_order", { query: query.trim() });
      logEvent(kind === "imaging" ? "imaging_result" : "lab_result",
        { query: query.trim(), text: r.text, found: r.found });
    } catch (e) {
      setMessages((m) => [...m, { role: "lab", text: "…" }]);
      if (e?.status === 403) setError(refusalMessage(e, t, lang));
    } finally { setTyping(false); }
  };

  const finish = async () => {
    setPhase("evaluating");
    const session = { messages, tests, imaging, ddx, finalDx };
    const durationSec = Math.round((Date.now() - startRef.current) / 1000);
    logEvent("finish", {});
    try {
      const res = await api.post("/exam/evaluate", {
        caseId, session, lang, durationSec, classId, examId,
        sessionId: sessionIdRef.current,
        events: loggingRef.current ? eventsRef.current : [],
      });
      eventsRef.current = [];   // uploaded; don't resend if the view re-mounts
      setEvalRes(res); setPhase("report");
    } catch (e) {
      // Bouncing back with no explanation left students stuck on a finished
      // exam. Name the reason (usually: the attempt limit is reached).
      setError(refusalMessage(e, t, lang));
      setPhase("exam");
    }
  };

  if (!caseData) return <div className="app"><TopBar onHome={home} /><Spinner /></div>;

  if (phase === "evaluating")
    return (
      <div className="app"><TopBar onHome={home} />
        <div className="center-screen"><div className="card center" style={{ maxWidth: 420 }}>
          <div style={{ fontSize: 44 }}><Icon name="brain" size={30} /></div>
          <h3 className="mt8">{t("evaluating")}</h3>
          <div className="muted small mt8">ASKI checklist · AI examiner</div>
        </div></div>
      </div>
    );

  /* ---- Informed consent (research participation) ---- */
  if (consent && consent.required && !consent.granted) {
    const fa = lang === "fa";
    const text = fa ? (consent.consentTextFa || consent.consentTextEn) : (consent.consentTextEn || consent.consentTextFa);
    const withdrew = consent.reason === "consent_withdrawn";
    return (
      <div className="app"><TopBar onHome={home} />
        <div className="center-screen">
          <div className="card" style={{ maxWidth: 620, textAlign: fa ? "right" : "left" }}>
            <h3><Icon name="shield" size={18} /> {fa ? "رضایت آگاهانهٔ پژوهشی" : "Informed research consent"}</h3>
            <div className="muted small mt4">{fa ? consent.titleFa : consent.titleEn}</div>
            <div className="row gap8 mt8 small" style={{ flexWrap: "wrap" }}>
              {consent.ethicsCode && <span className="tag">{fa ? "کد اخلاق" : "Ethics code"}: {consent.ethicsCode}</span>}
              {consent.protocolVersion && <span className="tag">{fa ? "نسخهٔ پروتکل" : "Protocol"}: {consent.protocolVersion}</span>}
            </div>
            {withdrew && (
              <div className="err-banner mt12">
                {fa ? "شما پیش‌تر از این مطالعه انصراف داده‌اید. برای شرکت دوباره باید رضایت خود را ثبت کنید."
                    : "You previously withdrew from this study. To take part again you must give consent again."}
              </div>
            )}
            <div className="card mt12" style={{ background: "var(--panel2)", maxHeight: 300, overflow: "auto", whiteSpace: "pre-wrap" }}>
              {text || (fa ? "متن رضایت‌نامه هنوز توسط پژوهشگر ثبت نشده است. تا ثبت آن نمی‌توانید شرکت کنید."
                            : "The consent wording has not been recorded by the researcher yet. You cannot take part until it is.")}
            </div>
            <div className="row gap8 mt12" style={{ flexWrap: "wrap" }}>
              <button className="btn btn-primary" onClick={agreeConsent} disabled={consentBusy || !text}>
                {fa ? "موافقم و شرکت می‌کنم" : "I agree and take part"}
              </button>
              <button className="btn btn-ghost" onClick={declineConsent} disabled={consentBusy}>
                {fa ? "انصراف" : "Decline"}
              </button>
            </div>
            <div className="small muted mt8">
              {fa ? "شرکت اختیاری است و هر زمان می‌توانید انصراف دهید. انصراف بر نمرهٔ درسی شما اثری ندارد."
                  : "Taking part is voluntary and you may withdraw at any time. Declining does not affect your course grade."}
            </div>
            {error && <div className="err-banner mt8">{error}</div>}
          </div>
        </div>
      </div>
    );
  }

  if (phase === "report")
    return <Report caseData={caseData} evalRes={evalRes} settings={settings}
      onBack={() => go(examId ? "exams" : classId ? "classes" : "caseList")} home={home} />;

  return (
    <div className="app">
      <TopBar onHome={home} />
      <div className="container">
        <div className="section-title">
          <div>
            <h2>{biField(caseData, "title", lang)}</h2>
            <span className="small muted">{t("chief")}: {biField(caseData, "chief", lang)}</span>
          </div>
          <div style={{ textAlign: "end" }}>
            <div className="small muted">{t("examTimer")}</div>
            <div className="timer">{fmt(timeLeft ?? 0)}</div>
          </div>
        </div>
        {!!examId && antiCheat && leaves > 0 && (
          <div className="err-banner mb16"><Icon name="warn" size={16} /> {t("antiCheatWarn")} ({leaves})</div>
        )}
        {!!error && (
          <div className="err-banner mb16">
            <Icon name="warn" size={16} /> {error}
            <button className="btn btn-ghost btn-sm" style={{ marginInlineStart: 8 }} onClick={() => setError("")}>{t("close")}</button>
          </div>
        )}
        <div className="exam-layout">
          <div className="card chat-box">
            <div style={{ fontWeight: 700, marginBottom: 8 }}><Icon name="chat" size={16} /> {t("patientChat")}</div>
            <div className="chat-msgs">
              {messages.length === 0 && !typing &&
                <div className="muted small center" style={{ margin: "auto" }}>{t("typeMessage")}</div>}
              {messages.map((m, i) => (
                m.role === "lab" ? (
                  <div key={i} className="msg msg-lab" style={{ alignSelf: "center", background: "var(--panel2, #eef3f9)", border: "1px dashed var(--border)", borderRadius: 12, maxWidth: "92%", textAlign: "start" }}>
                    <div>{m.text}</div>
                    {m.imageUrl && <a href={m.imageUrl} target="_blank" rel="noreferrer"><img src={m.imageUrl} alt="" style={{ width: "100%", borderRadius: 8, marginTop: 8, border: "1px solid var(--border)" }} /></a>}
                  </div>
                ) : (
                  <div key={i} className={`msg msg-${m.role === "student" ? "student" : "patient"}`}>{m.text}</div>
                )
              ))}
              {typing && <div className="msg msg-patient msg-typing">{t("aiThinking")}</div>}
              <div ref={chatEnd} />
            </div>
            <div className="chat-input">
              <input value={input} onChange={(e) => setInput(e.target.value)}
                placeholder={t("typeMessage")} onKeyDown={(e) => e.key === "Enter" && send()} />
              <button className="btn btn-primary" onClick={send}>{t("send")}</button>
            </div>
          </div>

          <div className="card side-panel">
            <div className="tabs">
              {["history", "tests", "imaging", "images", "dx"].map((id) => (
                <button key={id} className={`tab ${tab === id ? "active" : ""}`} onClick={() => { setTab(id); logEvent("tab_switch", { tab: id }); }}>
                  {t(id === "history" ? "tabHistory" : id === "tests" ? "tabTests"
                    : id === "imaging" ? "tabImaging" : id === "images" ? "tabImages" : "tabDx")}
                </button>
              ))}
            </div>
            <div className="tab-content">
              {tab === "history" && <HistoryTab c={caseData} t={t} lang={lang} />}
              {tab === "tests" && <OrderTab label={t("orderTest")} listLabel={t("orderedTests")}
                catalog={LAB_TESTS} items={tests} setItems={setTests} lang={lang} t={t}
                onOrder={(q) => orderResult("lab", q)} />}
              {tab === "imaging" && <OrderTab label={t("orderImaging")} listLabel={t("orderedImaging")}
                catalog={IMAGING_STUDIES} items={imaging} setItems={setImaging} lang={lang} t={t}
                onOrder={(q) => orderResult("imaging", q)} />}
              {tab === "images" && <ImagesTab c={caseData} t={t} lang={lang} />}
              {tab === "dx" && <DxTab ddx={ddx} setDdx={setDdx} finalDx={finalDx} setFinalDx={setFinalDx} t={t}
                onDdx={(x) => logEvent("ddx_add", { text: x })}
                onFinalDx={(x) => logEvent("final_dx", { text: x })} />}
            </div>
            <button className="btn btn-accent btn-block mt16" onClick={finish}>✓ {t("finishExam")}</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function ImagesTab({ c, t, lang }) {
  const imgs = (c.images || []).filter((im) => im.url);
  if (!imgs.length) return <div className="small muted center" style={{ padding: 20 }}>{t("noImages")}</div>;
  return (
    <div style={{ display: "grid", gap: 12 }}>
      {imgs.map((im, i) => (
        <div key={i}>
          <a href={im.url} target="_blank" rel="noreferrer">
            <img src={im.url} alt="" style={{ width: "100%", borderRadius: 12, border: "1px solid var(--border)" }} />
          </a>
          <div className="small muted mt8">{(lang === "fa" ? im.label_fa : im.label_en) || im.label_en || im.label_fa || ""}</div>
        </div>
      ))}
    </div>
  );
}

function HistoryTab({ c, t, lang }) {
  // The student must TAKE the history from the patient via the chat.
  // Only basic demographics are shown here (as observed on entering the room).
  const Row = ({ k, val }) => <div className="info-row"><span>{k}</span><span>{val}</span></div>;
  return (
    <>
      <label className="small muted">{t("patientCard")}</label>
      <Row k={t("age")} val={c.age} />
      <Row k={t("sex")} val={t(c.sex)} />
      <Row k={t("chief")} val={biField(c, "chief", lang)} />
      <div className="divider" />
      <div className="ddle-question" style={{ margin: 0 }}>
        <Icon name="chat" size={16} /> {t("takeHistoryNote")}
      </div>
    </>
  );
}

function OrderTab({ label, listLabel, catalog, items, setItems, lang, t, onOrder }) {
  const add = (v) => {
    const val = (v || "").trim();
    if (!val) return;
    // avoid duplicates (case-insensitive)
    if (items.some((x) => x.toLowerCase() === val.toLowerCase())) return;
    setItems([...items, val]);
    // fetch the lab/radiology report for this order and show it in the chat
    onOrder?.(val);
  };
  return (
    <>
      <div className="field"><label>{label}</label>
        <OrderSearch catalog={catalog} lang={lang} onAdd={add} />
      </div>
      <label className="small muted">{listLabel}</label>
      <div>{items.length ? items.map((x, i) => (
        <span className="chip" key={i}>{x}<button onClick={() => setItems(items.filter((_, j) => j !== i))}>✕</button></span>
      )) : <div className="small muted mt8">{t("noneYet")}</div>}</div>
    </>
  );
}

function DxTab({ ddx, setDdx, finalDx, setFinalDx, t, onDdx, onFinalDx }) {
  const [v, setV] = useState("");
  const add = () => { if (v.trim()) { setDdx([...ddx, v.trim()]); onDdx?.(v.trim()); setV(""); } };
  return (
    <>
      <div className="field"><label>{t("ddx")}</label>
        <div className="inline-form">
          <input value={v} onChange={(e) => setV(e.target.value)} placeholder={t("addDdx")}
            onKeyDown={(e) => e.key === "Enter" && add()} />
          <button className="btn btn-primary btn-sm" onClick={add}>{t("add")}</button>
        </div>
        <div className="mt8">{ddx.map((x, i) => (
          <span className="chip" key={i}>{x}<button onClick={() => setDdx(ddx.filter((_, j) => j !== i))}>✕</button></span>
        ))}</div>
      </div>
      <div className="divider" />
      <div className="field"><label>{t("finalDx")}</label>
        <input value={finalDx} onChange={(e) => setFinalDx(e.target.value)}
          onBlur={(e) => onFinalDx?.(e.target.value)} placeholder={t("enterFinalDx")} />
      </div>
    </>
  );
}

function Report({ caseData, evalRes, settings, onBack, home }) {
  const { t, lang } = useApp();
  const e = evalRes;
  const List = ({ arr, fallback }) => arr && arr.length
    ? <ul className="list-clean">{arr.map((x, i) => <li key={i}>{x}</li>)}</ul>
    : <div className="small muted">{fallback || "-"}</div>;

  return (
    <div className="app">
      <TopBar onHome={home} />
      <div className="container">
        <div className="section-title">
          <h2>{t("report")} — {biField(caseData, "title", lang)}</h2>
          <button className="btn btn-ghost btn-sm" onClick={onBack}>{t("backToCases")}</button>
        </div>
        <div className="grid grid-2">
          <div className="card center">
            <div className="score-ring" style={{ "--pct": `${e.score * 3.6}deg` }}><div className="val">{e.score}</div></div>
            <div className="lbl muted mt8">{t("finalScore")} / 100</div>
            <div className="tag mt8" style={{ fontWeight: 800 }}>{lang === "fa" ? "امتیاز از ۱۰" : "Score / 10"}: {e.score10 ?? Math.round((e.score || 0) / 10)}</div>
            {e.xpReward && (
              <div className="vp-xp-reward mt8" style={{ marginTop: 12 }}>
                {e.xpReward.awarded > 0 ? (
                  <div className="tag" style={{ background: "rgba(224,165,46,.16)", color: "var(--xp,#e0a52e)", border: "1px solid rgba(224,165,46,.4)", fontWeight: 800, fontSize: ".95rem", padding: "6px 12px" }}>
                    +{e.xpReward.awarded} XP {lang === "fa" ? "به رنکینگ" : "to ranking"}
                  </div>
                ) : (
                  <div className="small muted">
                    {lang === "fa"
                      ? `بهترین امتیاز قبلی‌ات ${e.xpReward.prevBest}٪ بود — این‌بار XP جدیدی اضافه نشد.`
                      : `Your previous best was ${e.xpReward.prevBest}% — no new XP this time.`}
                  </div>
                )}
                <div className="small muted mt8">{lang === "fa" ? `سقف XP این کیس: ${e.xpReward.xpMax}` : `Case XP cap: ${e.xpReward.xpMax}`}</div>
              </div>
            )}
          </div>
          <div className="card">
            <h4 className="mb8"><Icon name="check" size={16} /> {t("checklist")}</h4>
            {e.results.map((r) => (
              <div className="check-item" key={r.id}>
                <div className={`status ${r.done ? "st-done" : "st-miss"}`}>{r.done ? "✓" : "✕"}</div>
                <div style={{ flex: 1 }}>
                  {r.label}
                  {/* per-item examiner reasoning from the LLM (OSCE scoring) */}
                  {r.reason && <div className="small muted" style={{ marginTop: 2 }}>{r.reason}</div>}
                </div>
                <span className="tag">{t("weight")} {r.weight}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Per-section scores: history is graded separately from the rest, plus
            an overall score. For an EXTERN the teacher grades on history; for an
            INTERN on the overall. Both are always shown — the teacher decides. */}
        {e.sectionScores && (e.sectionScores.hasHistory || e.sectionScores.sections?.length > 1) && (
          <div className="card mt16">
            <h4 className="mb8"><Icon name="chart" size={16} /> {lang === "fa" ? "نمرهٔ تفکیکی بخش‌ها" : "Scores by section"}</h4>
            <div className="grid grid-3" style={{ gap: 12, marginBottom: 12 }}>
              {e.sectionScores.history != null && (
                <div className="card center" style={{ borderInlineStart: "4px solid var(--primary)" }}>
                  <div className="big" style={{ fontSize: "1.7rem" }}>{e.sectionScores.history}%</div>
                  <div className="small muted">{lang === "fa" ? "شرح‌حال (ملاک اکسترن)" : "History (extern)"}</div>
                </div>
              )}
              {e.sectionScores.other != null && (
                <div className="card center" style={{ borderInlineStart: "4px solid var(--gold)" }}>
                  <div className="big" style={{ fontSize: "1.7rem" }}>{e.sectionScores.other}%</div>
                  <div className="small muted">{lang === "fa" ? "سایر موارد" : "Other sections"}</div>
                </div>
              )}
              <div className="card center" style={{ borderInlineStart: "4px solid var(--green)" }}>
                <div className="big" style={{ fontSize: "1.7rem" }}>{e.sectionScores.overall}%</div>
                <div className="small muted">{lang === "fa" ? "کلی (ملاک اینترن)" : "Overall (intern)"}</div>
              </div>
            </div>
            {/* detailed bar per section */}
            {e.sectionScores.sections?.map((s) => (
              <div className="check-item" key={s.key} style={{ alignItems: "center" }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700 }}>{s.label} <span className="small muted">({s.items} {lang === "fa" ? "مورد" : "items"})</span></div>
                  <div className="pbar sm"><span style={{ width: `${s.score}%`, background: s.score >= 70 ? "var(--green)" : s.score < 40 ? "var(--danger)" : "var(--gold)" }} /></div>
                </div>
                <span className="tag">{s.score}%</span>
              </div>
            ))}
          </div>
        )}

        {settings.showAiAnalysis && (
          <>
            <div className="grid grid-2 mt16">
              <div className="card"><h4 style={{ color: "var(--ok)" }}><Icon name="strength" size={16} /> {t("strengths")}</h4><List arr={e.strengths} /></div>
              <div className="card"><h4 style={{ color: "var(--danger)" }}><Icon name="warn" size={16} /> {t("weaknesses")}</h4><List arr={e.weaknesses} /></div>
            </div>
            <div className="grid grid-2 mt16">
              <div className="card"><h4 style={{ color: "var(--warn)" }}><Icon name="pin" size={16} /> {t("missed")}</h4><List arr={e.missed} fallback="✓" /></div>
              <div className="card"><h4 style={{ color: "var(--warn)" }}><Icon name="repeat" size={16} /> {t("commonMistakes")}</h4><List arr={e.commonMistakes} /></div>
            </div>
            {e.suggestion && <div className="card mt16"><h4><Icon name="bulb" size={16} /> {t("suggestion")}</h4><div className="small mt8">{e.suggestion}</div></div>}
          </>
        )}

        {settings.showMicro && e.microlearning && (
          <div className="mt16">
            <h4 style={{ marginBottom: 8 }}><Icon name="book" size={16} /> {t("microlearning")}</h4>
            <div className="micro-box">{e.microlearning}</div>
            <div className="small muted mt8">{t("microNote")}</div>
          </div>
        )}
      </div>
    </div>
  );
}
