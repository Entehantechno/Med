import { describe, it, expect, vi } from "vitest";
import fs from "node:fs";
import vm from "node:vm";
import { sanitizeCaseForPatient } from "../src/lib/ai-engine.js";

function worker() {
  const handlers = {};
  const caches = {
    open: vi.fn(),
    match: vi.fn(),
    delete: vi.fn(async () => true),
    keys: vi.fn(async () => ["medschool-old-api", "medschool-old-img"]),
  };
  const fetch = vi.fn(async () => ({
    ok: true,
    headers: new Headers({ "Cache-Control": "private, no-store" }),
  }));
  const clients = { claim: vi.fn(async () => {}) };
  vm.runInNewContext(
    fs.readFileSync(
      new URL("../../client/public/sw.js", import.meta.url),
      "utf8",
    ),
    {
      self: {
        addEventListener: (name, handler) => {
          handlers[name] = handler;
        },
        location: { origin: "https://example.test" },
        clients,
      },
      caches,
      fetch,
      URL,
      Response,
      Headers,
      clients,
    },
  );
  return { handlers, caches, fetch };
}

describe("private academic data is never served from the offline cache", () => {
  for (const pathname of [
    "/api/academic/policies",
    "/api/cases",
    "/api/classes/1",
    "/api/reports/my",
    "/uploads/academic/university-1/photo.png",
    "/uploads/snd_legacy.mp3",
    "/uploads/platform/photo.png",
  ]) {
    it(`uses network-only with no-store for ${pathname}`, async () => {
      const w = worker();
      const request = {
        url: `https://example.test${pathname}`,
        method: "GET",
        destination: "image",
      };
      let response;
      w.handlers.fetch({
        request,
        respondWith: (p) => {
          response = p;
        },
      });
      await response;
      expect(w.fetch).toHaveBeenCalledWith(request, { cache: "no-store" });
      expect(w.caches.open).not.toHaveBeenCalled();
      expect(w.caches.match).not.toHaveBeenCalled();
    });
  }
  it("purges caches from an older worker when activating the security release", async () => {
    const w = worker();
    let pending;
    w.handlers.activate({
      waitUntil: (p) => {
        pending = p;
      },
    });
    await pending;
    expect(w.caches.delete).toHaveBeenCalledWith("medschool-old-api");
    expect(w.caches.delete).toHaveBeenCalledWith("medschool-old-img");
  });
  it("removes faculty provenance from the patient model chart", () => {
    const s = sanitizeCaseForPatient({
      chief_fa: "درد",
      reference_snapshot: { teaching_basis_fa: "خصوصی" },
      reference_policy_id: 1,
      reference_snapshot_json: "private",
      reference: { private: true },
    });
    expect(s).toEqual({ chief_fa: "درد" });
  });
});
