import { randomUUID } from "node:crypto";
import { db } from "../../src/db.js";
import { referenceSnapshotForPolicy } from "../../src/lib/reference-governance.js";

// Synthetic, faculty-authored content only: never pretend a test model has read
// Harrison or grant an approval to the production seed's legacy policy.
export function attachSyntheticReference(caseIds = [1]) {
  const referenceId = db
    .prepare(
      `INSERT INTO reference_catalog
    (code,title_en,short_title,rights_status) VALUES (?,?,?,'open_license')`,
    )
    .run(
      "synthetic-course-notes-" + randomUUID(),
      "Synthetic faculty learning notes",
      "Test faculty notes",
    ).lastInsertRowid;
  const policyId = db
    .prepare(
      `INSERT INTO course_reference_policies
    (university_id,course_code,reference_id,source_anchor,teaching_basis_fa,status,approved_by,approved_at)
    VALUES (1,?,?,'Test unit 1: chronological history',?,'approved',1,datetime('now'))`,
    )
    .run(
      "synthetic-course-" + randomUUID(),
      referenceId,
      "محتوای ساختگی آزمون: زمان شروع علامت را صریح بپرسید و پاسخ بیمار را ثبت کنید.",
    ).lastInsertRowid;
  const snapshot = referenceSnapshotForPolicy(policyId);
  for (const id of caseIds)
    db.prepare(
      "UPDATE cases SET reference_policy_id=?,reference_snapshot_json=? WHERE id=?",
    ).run(policyId, JSON.stringify(snapshot), id);
  return snapshot;
}
