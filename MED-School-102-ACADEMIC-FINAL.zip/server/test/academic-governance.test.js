import {
  beforeAll,
  afterAll,
  afterEach,
  describe,
  expect,
  it,
  vi,
} from "vitest";
import request from "supertest";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
let db, app, gov, zip, portable, logging, engine, tokens, u2, policy, caseId;
const temp = fs.mkdtempSync(path.join(os.tmpdir(), "med-academic-test-"));
const auth = (role) => ({ Authorization: `Bearer ${tokens[role]}` });
const policyInput = (code) => ({
  course_code: code,
  course_name_fa: "داخلی",
  reference_id: 1,
  source_anchor: "Faculty review: history-taking",
  teaching_basis_fa:
    "یادداشت مستقل مدرس: زمان شروع علامت و ترتیب رویدادها را از بیمار بپرسید.",
  status: "approved",
});
beforeAll(async () => {
  vi.stubEnv("DATA_DIR", temp);
  vi.stubEnv("DB_FILE", "test.db");
  vi.stubEnv("AI_API_KEY", "");
  ({ db } = await import("../src/db.js"));
  const { initDb } = await import("../src/db.js");
  await initDb();
  const { createApp } = await import("../src/app.js");
  app = createApp();
  gov = await import("../src/lib/reference-governance.js");
  zip = await import("../src/lib/portable-zip.js");
  portable = await import("../src/routes/portable.js");
  logging = await import("../src/lib/vplogging.js");
  engine = await import("../src/lib/ai-engine.js");
  const { signToken } = await import("../src/lib/auth.js");
  u2 = db
    .prepare(
      "INSERT INTO universities(name_en,code) VALUES ('Other University','OTHER')",
    )
    .run().lastInsertRowid;
  tokens = {};
  for (const [key, role, uni] of [
    ["admin", "admin", 1],
    ["teacher", "teacher", 1],
    ["student", "student", 1],
    ["other", "teacher", u2],
    ["learner", "learner", null],
  ]) {
    const id = db
      .prepare(
        "INSERT INTO users(username,password_hash,role,status,university_id) VALUES (?,?,?,'active',?)",
      )
      .run(key, "unusable", role, uni).lastInsertRowid;
    tokens[key] = signToken(
      db.prepare("SELECT * FROM users WHERE id=?").get(id),
    );
  }
  const result = await request(app)
    .post("/api/academic/policies")
    .set(auth("teacher"))
    .send(policyInput("internal"));
  expect(result.status).toBe(201);
  policy = result.body.policy;
  const c = await request(app)
    .post("/api/cases")
    .set(auth("teacher"))
    .send({
      title_fa: "کیس تست",
      reference_policy_id: policy.id,
      diagnosis_fa: "یافتهٔ آموزشی",
      chief_fa: "علامت تست",
    });
  expect(c.status).toBe(200);
  caseId = c.body.id;
});
afterEach(() => vi.unstubAllGlobals());
afterAll(() => {
  vi.unstubAllEnvs(); /* sql.js flushes at process exit; temp location is never shipped. */
});

describe("approved references and encounter provenance", () => {
  it("requires authentication and an academic role", async () => {
    expect((await request(app).get("/api/academic/references")).status).toBe(
      401,
    );
    expect(
      (await request(app).get("/api/academic/references").set(auth("learner")))
        .status,
    ).toBe(403);
  });
  it("seeds Harrison as metadata only, without any textbook payload", () => {
    const ref = gov.listReferenceCatalog()[0];
    expect(ref.rights_status).toBe("metadata_only");
    expect(ref.edition).toContain("22");
    expect(ref).not.toHaveProperty("content");
  });
  it("rejects approval with no faculty basis or unsupported licensed text mode", async () => {
    for (const change of [
      { teaching_basis_fa: "" },
      { content_mode: "licensed_excerpt" },
    ]) {
      const r = await request(app)
        .post("/api/academic/policies")
        .set(auth("teacher"))
        .send({ ...policyInput("bad-policy"), ...change });
      expect(r.status).toBe(422);
    }
  });
  it("cannot bind a foreign policy; invalid updates do not create history", async () => {
    const other = await request(app)
      .post("/api/academic/policies")
      .set(auth("other"))
      .send(policyInput("foreign"));
    expect(other.status).toBe(201);
    const count = db.prepare("SELECT COUNT(*) n FROM case_versions").get().n;
    const r = await request(app)
      .put(`/api/cases/${caseId}`)
      .set(auth("teacher"))
      .send({ reference_policy_id: other.body.policy.id });
    expect(r.status).toBe(422);
    expect(db.prepare("SELECT COUNT(*) n FROM case_versions").get().n).toBe(
      count,
    );
  });
  it("checks snapshots independently of object key ordering and fails closed after tampering", () => {
    const s = gov.referenceSnapshotForPolicy(policy.id);
    expect(gov.parseReferenceSnapshot(s).ready).toBe(true);
    // Reorder top-level only; retain nested data exactly.
    const reordered = Object.fromEntries(
      Object.keys(s)
        .sort()
        .map((k) => [k, s[k]]),
    );
    expect(gov.parseReferenceSnapshot(reordered).ready).toBe(true);
    expect(
      gov.parseReferenceSnapshot({ ...s, source_anchor: "forged page" })
        .readiness.code,
    ).toBe("snapshot_integrity_failed");
    expect(
      gov.snapshotForCaseRow({
        reference_policy_id: policy.id,
        reference_snapshot_json: "{broken",
      }).ready,
    ).toBe(false);
    expect(gov.publicReferenceSnapshot(s)).not.toHaveProperty(
      "teaching_basis_fa",
    );
  });
  it("pins session snapshots across explicit later policy edits", async () => {
    const before = gov.snapshotForCaseRow(
      db.prepare("SELECT * FROM cases WHERE id=?").get(caseId),
    );
    const sid = logging.startSession({
      userId: 2,
      caseId,
      lang: "fa",
    }).sessionId;
    const r = await request(app)
      .put(`/api/academic/policies/${policy.id}`)
      .set(auth("teacher"))
      .send({ source_anchor: "Faculty review: chronology and clarification" });
    expect(r.status).toBe(200);
    const after = gov.snapshotForCaseRow(
      db.prepare("SELECT * FROM cases WHERE id=?").get(caseId),
    );
    expect(after.policy_version).toBe(before.policy_version + 1);
    expect(
      gov.parseReferenceSnapshot(
        logging.getSession(sid).reference_snapshot_json,
      ),
    ).toEqual(before);
    expect(
      gov.snapshotForCaseRow(
        db.prepare("SELECT * FROM cases WHERE id=?").get(caseId),
      ),
    ).toEqual(after);
  });
  it("stores the session reference on the attempt and returns only public provenance on replay", async () => {
    const { setSetting } = await import("../src/routes/content.js");
    setSetting("ai", {});
    setSetting("ai_vpatient", {});
    setSetting("exam", { showAiAnalysis: true, showMicro: true });
    const start = await request(app)
      .post("/api/exam/session-start")
      .set(auth("teacher"))
      .send({ caseId });
    expect(start.status).toBe(200);
    const snapshot = logging.getSession(
      start.body.sessionId,
    ).reference_snapshot_json;
    const result = await request(app)
      .post("/api/exam/evaluate")
      .set(auth("teacher"))
      .send({
        caseId,
        sessionId: start.body.sessionId,
        session: { messages: [] },
      });
    expect(result.status).toBe(200);
    const row = db
      .prepare("SELECT * FROM attempts WHERE id=?")
      .get(result.body.attemptId);
    expect(row.reference_snapshot_json).toBe(snapshot);
    expect(result.body.reference.ready).toBe(true);
    expect(result.body.reference).not.toHaveProperty("teaching_basis_fa");
    const replay = await request(app)
      .post("/api/exam/evaluate")
      .set(auth("teacher"))
      .send({ caseId, sessionId: start.body.sessionId });
    expect(replay.body.replayed).toBe(true);
    expect(replay.body.reference).toEqual(result.body.reference);
  });
  it("uses faculty constraints internally and adds only the approved citation", async () => {
    const snap = gov.referenceSnapshotForPolicy(policy.id);
    const text =
      "### تمرین\nزمان شروع علامت را از بیمار بپرسید و ترتیب رویدادها را در شرح‌حال ثبت کنید.";
    let system;
    vi.stubGlobal(
      "fetch",
      vi.fn(async (_url, init) => {
        system = JSON.parse(init.body).messages[0].content;
        return {
          ok: true,
          status: 200,
          json: async () => ({
            choices: [
              {
                message: {
                  content: JSON.stringify({
                    strengths: [],
                    weaknesses: [],
                    missed: [],
                    commonMistakes: [],
                    suggestion: "تمرین",
                    microlearning: text,
                  }),
                },
              },
            ],
          }),
        };
      }),
    );
    const r = await engine.enrichEvaluationWithLLM({
      base: { results: [], strengths: [], missed: [] },
      caseData: {},
      session: {},
      lang: "fa",
      prompts: {},
      aiCfg: {
        provider: "OpenRouter",
        model: "synthetic-test",
        apiKey: "synthetic-only",
      },
      referenceSnapshot: snap,
      referenceContract: gov.referencePromptContract(snap),
    });
    expect(r.feedbackSource).toBe("llm");
    expect(system).toContain(snap.teaching_basis_fa);
    expect(gov.decorateMicrolearning(r.microlearning, snap)).toContain(
      snap.source_anchor,
    );
  });
  it("accepts checklist feedback without generating a lesson for an unapproved source", async () => {
    const snap = gov.referenceSnapshotForPolicy(null);
    let system;
    vi.stubGlobal(
      "fetch",
      vi.fn(async (_url, init) => {
        system = JSON.parse(init.body).messages[0].content;
        return {
          ok: true,
          status: 200,
          json: async () => ({
            choices: [
              {
                message: {
                  content: JSON.stringify({
                    strengths: [],
                    weaknesses: [],
                    missed: [],
                    commonMistakes: [],
                    suggestion: "تمرین",
                    microlearning: "",
                  }),
                },
              },
            ],
          }),
        };
      }),
    );
    const r = await engine.enrichEvaluationWithLLM({
      base: { results: [], strengths: [], missed: [] },
      caseData: {},
      session: {},
      lang: "fa",
      prompts: {},
      aiCfg: {
        provider: "OpenRouter",
        model: "synthetic-test",
        apiKey: "synthetic-only",
      },
      referenceSnapshot: snap,
      referenceContract: gov.referencePromptContract(snap),
    });
    expect(r.feedbackSource).toBe("llm");
    expect(system).toContain("Return microlearning as an empty string");
    expect(r.microlearning).toBe("");
    expect(
      gov.decorateMicrolearning("untrusted generated lesson", snap),
    ).not.toContain("untrusted");
  });
});

describe("tenant boundaries", () => {
  it("honors the admin target, not the admin account university", async () => {
    const r = await request(app)
      .post("/api/cases")
      .set(auth("admin"))
      .send({ university_id: u2, title_fa: "target" });
    expect(r.status).toBe(200);
    expect(
      db.prepare("SELECT university_id FROM cases WHERE id=?").get(r.body.id)
        .university_id,
    ).toBe(u2);
  });
  it("rejects cross-tenant case access even through a corrupt assignment", async () => {
    const otherCase = db
      .prepare("INSERT INTO cases(data_json,university_id) VALUES ('{}',?)")
      .run(u2).lastInsertRowid;
    db.prepare(
      "INSERT INTO exam_assignments(user_id,case_id) VALUES (3,?)",
    ).run(otherCase);
    expect(
      (await request(app).get(`/api/cases/${otherCase}`).set(auth("student")))
        .status,
    ).toBe(403);
    expect(
      (
        await request(app)
          .post("/api/exam/session-start")
          .set(auth("student"))
          .send({ caseId: otherCase })
      ).status,
    ).toBe(403);
  });
  it("does not use a stale university cache after a staff transfer", async () => {
    expect(
      (await request(app).get(`/api/cases/${caseId}`).set(auth("teacher")))
        .status,
    ).toBe(200);
    db.prepare("UPDATE users SET university_id=? WHERE username='teacher'").run(
      u2,
    );
    expect(
      (await request(app).get(`/api/cases/${caseId}`).set(auth("teacher")))
        .status,
    ).toBe(403);
    db.prepare(
      "UPDATE users SET university_id=1 WHERE username='teacher'",
    ).run();
  });
  it("stores tenant audio privately and denies anonymous/cross-tenant GET, HEAD and Range", async () => {
    const r = await request(app)
      .post("/api/upload/audio")
      .set(auth("teacher"))
      .attach(
        "audio",
        Buffer.concat([Buffer.from("ID3"), Buffer.alloc(64)]),
        "lung.mp3",
      );
    expect(r.status).toBe(200);
    expect(r.body.url).toContain("/uploads/academic/");
    const own = await request(app).get(r.body.url).set(auth("teacher"));
    expect(own.status).toBe(200);
    expect(own.headers["cache-control"]).toContain("no-store");
    for (const verb of ["get", "head"]) {
      expect((await request(app)[verb](r.body.url)).status).toBe(404);
      expect(
        (
          await request(app)
            [verb](r.body.url)
            .set(auth("other"))
            .set("Range", "bytes=0-4")
        ).status,
      ).toBe(404);
    }
    const library = await request(app)
      .get("/api/upload/library")
      .set(auth("other"));
    expect(library.body.items.some((x) => x.url === r.body.url)).toBe(false);
  });
  it("gates legacy academic files and their cache headers", async () => {
    const filename = "snd_legacy-check.mp3";
    fs.writeFileSync(path.join(temp, "uploads", filename), "ID3test");
    db.prepare("INSERT INTO cases(data_json,university_id) VALUES (?,1)").run(
      JSON.stringify({ lungSound: `/uploads/${filename}` }),
    );
    const own = await request(app)
      .get(`/uploads/${filename}`)
      .set(auth("teacher"));
    expect(own.status).toBe(200);
    expect(own.headers["cache-control"]).toBe("private, no-store");
    expect(
      (await request(app).get(`/uploads/${filename}`).set(auth("other")))
        .status,
    ).toBe(404);
    expect((await request(app).get(`/uploads/${filename}`)).status).toBe(404);
  });
  it("keeps explicitly platform-shared uploads reachable by their physical URL", async () => {
    const r = await request(app)
      .post("/api/upload/audio")
      .set(auth("admin"))
      .attach(
        "audio",
        Buffer.concat([Buffer.from("ID3"), Buffer.alloc(64)]),
        "public.mp3",
      );
    expect(r.status).toBe(200);
    expect(r.body.url).toContain("/uploads/platform/");
    expect((await request(app).get(r.body.url)).status).toBe(200);
  });
});

describe("partial portable preview: read-only validation, never false restore success", () => {
  it("exports only the chosen tenant and declares exclusions", () => {
    const bundle = portable.createUniversityBundle(
      db.prepare("SELECT * FROM universities WHERE id=1").get(),
    );
    const checked = portable.validateUniversityBundle(bundle.buffer);
    expect(checked.ok).toBe(true);
    expect(checked.restorable).toBe(false);
    expect(checked.manifest.scope.complete).toBe(false);
    expect(checked.data.cases.every((c) => c.university_id === 1)).toBe(true);
    expect(checked.data.identities.every((u) => u.university_id === 1)).toBe(
      true,
    );
    expect(JSON.stringify(checked.data.identities)).not.toContain(
      "password_hash",
    );
  });
  it("detects file tampering even when the ZIP CRC is rebuilt", () => {
    const bundle = portable.createUniversityBundle(
      db.prepare("SELECT * FROM universities WHERE id=1").get(),
    );
    const entries = zip.readPortableZip(bundle.buffer);
    entries.find((e) => e.path.endsWith("/cases.json")).data =
      Buffer.from("[]");
    expect(() =>
      portable.validateUniversityBundle(zip.createPortableZip(entries)),
    ).toThrow("file_checksum_invalid");
  });
  it("rejects import before any database write", async () => {
    const before = db.prepare("SELECT COUNT(*) n FROM cases").get().n;
    const r = await request(app)
      .post("/api/academic/portable/import")
      .set(auth("admin"))
      .send({ university_id: 1 });
    expect(r.status).toBe(501);
    expect(r.body.databaseChanged).toBe(false);
    expect(db.prepare("SELECT COUNT(*) n FROM cases").get().n).toBe(before);
  });
  it("rejects traversal, aliases, duplicate names, truncated and oversized archives", () => {
    for (const name of [
      "../x",
      "/x",
      "a/../x",
      "a\\x",
      "C:x",
      "a//b",
      "a\u0000b",
    ])
      expect(zip.safeArchivePath(name)).toBeNull();
    expect(() =>
      zip.createPortableZip([
        { path: "a", data: "x" },
        { path: "a", data: "y" },
      ]),
    ).toThrow();
    const b = zip.createPortableZip([
      { path: "academic/test.json", data: "z".repeat(10000) },
    ]);
    expect(() => zip.readPortableZip(b, { maxExpandedBytes: 100 })).toThrow();
    expect(() => zip.readPortableZip(b.subarray(0, b.length - 10))).toThrow();
  });
});
