/* ================================================================
   vp-stability.test.js — durability / abuse cases for the virtual
   patient so a crafted client cannot 500 the exam or leak keys.
   ================================================================ */
import { describe, it, expect, beforeAll } from "vitest";
import { execSync } from "child_process";
import request from "supertest";
import { initDb } from "../src/db.js";
import { createApp } from "../src/app.js";
import { detectExamRequest } from "../src/lib/ai-engine.js";

let app;
const login = (u, p = "demo") => request(app).post("/api/auth/login").send({ username: u, password: p });
async function token(u, p = "demo") { return (await login(u, p)).body.token; }
const A = (tk) => ({ Authorization: `Bearer ${tk}` });

beforeAll(async () => {
  execSync("node src/seed.js --force", { cwd: process.cwd(), stdio: "ignore" });
  await initDb();
  app = createApp();
});

async function studentId(tk, username) {
  const users = (await request(app).get("/api/users").set(A(tk))).body;
  return users.find((u) => u.username === username).id;
}

async function makeClass(tk, stuId, caseId, extra = {}) {
  const created = await request(app).post("/api/classes").set(A(tk))
    .send({ name_en: `Stab ${Math.random()}`, name_fa: "پایداری", gradingRole: extra.gradingRole || "both",
            maxAttempts: extra.maxAttempts ?? 8,
            logTranscript: extra.logTranscript === true, gradingRubric: extra.gradingRubric });
  const cid = created.body.id;
  await request(app).put(`/api/classes/${cid}/members`).set(A(tk)).send({ userIds: [stuId] });
  await request(app).put(`/api/classes/${cid}/cases`).set(A(tk)).send({ cases: [{ case_id: caseId, weight: 1 }] });
  return cid;
}

describe("detectExamRequest does not steal history questions", () => {
  it("station commands and explicit requests are exam-mode", () => {
    expect(detectExamRequest("معاینه")).toBe(true);
    expect(detectExamRequest("معاینه فیزیکی")).toBe(true);
    expect(detectExamRequest("لطفاً بیمار را معاینه کنید و یافته‌ها را بگویید")).toBe(true);
    expect(detectExamRequest("examine the patient")).toBe(true);
    expect(detectExamRequest("vital signs")).toBe(true);
    expect(detectExamRequest("علائم حیاتی را بگویید")).toBe(true);
  });

  it("past-history and everyday language stay in the patient's voice", () => {
    expect(detectExamRequest("آیا قبلاً معاینه شده‌اید؟")).toBe(false);
    expect(detectExamRequest("قبلا معاینه شدید؟")).toBe(false);
    expect(detectExamRequest("Have you been examined before?")).toBe(false);
    expect(detectExamRequest("Did anyone examine you at the ER?")).toBe(false);
    expect(detectExamRequest("فعالیت فیزیکی دارید؟")).toBe(false);
    expect(detectExamRequest("I have an exam tomorrow")).toBe(false);
  });
});

describe("evaluate never 500s on abusive payloads", () => {
  it("null / empty session still returns a numeric score", async () => {
    const ttk = await token("teacher");
    const stuId = await studentId(ttk, "40012345");
    const cid = await makeClass(ttk, stuId, 1);
    const stk = await token("40012345");
    const r = await request(app).post("/api/exam/evaluate").set(A(stk))
      .send({ caseId: 1, classId: cid, lang: "fa", durationSec: 10, session: null });
    expect(r.status).toBe(200);
    expect(typeof r.body.score).toBe("number");
  });

  it("huge message arrays and unicode do not crash", async () => {
    const ttk = await token("teacher");
    const stuId = await studentId(ttk, "40022334");
    const cid = await makeClass(ttk, stuId, 1);
    const stk = await token("40022334");
    const messages = [];
    for (let i = 0; i < 400; i++) {
      messages.push({ role: "student", text: "سلام 🙂 \u200f" + "س".repeat(200) });
      messages.push({ role: "patient", text: "درد قفسه سینه" });
    }
    const r = await request(app).post("/api/exam/evaluate").set(A(stk))
      .send({ caseId: 1, classId: cid, lang: "fa", durationSec: 30,
              session: { messages, tests: ["ecg"], imaging: [], ddx: ["ACS"], finalDx: "ACS", problemList: "درد" } });
    expect(r.status).toBe(200);
    expect(typeof r.body.score).toBe("number");
  });

  it("SQL-looking chat text is stored as text, not executed", async () => {
    const ttk = await token("teacher");
    const stuId = await studentId(ttk, "40067890");
    const cid = await makeClass(ttk, stuId, 1, { logTranscript: true });
    const stk = await token("40067890");
    const poison = "درد قفسه سینه'; DROP TABLE users; --";
    const sess = await request(app).post("/api/exam/session-start").set(A(stk))
      .send({ caseId: 1, classId: cid, lang: "fa" });
    expect(sess.status).toBe(200);
    const reply = await request(app).post("/api/exam/patient-reply").set(A(stk))
      .send({ caseId: 1, classId: cid, lang: "fa", userText: poison, history: [] });
    // Either the input filter rejects it (400) or the exam engine treats it as
    // ordinary text (200). In both cases the users table must still exist.
    expect([200, 400]).toContain(reply.status);
    const ev = await request(app).post("/api/exam/evaluate").set(A(stk))
      .send({ caseId: 1, classId: cid, lang: "fa", durationSec: 12,
              sessionId: sess.body.sessionId,
              events: [{ kind: "student_msg", atMs: 1, text: "سلام درد قفسه سینه" }],
              session: { messages: [{ role: "student", text: "سلام درد قفسه سینه" }], tests: [], imaging: [], ddx: [], finalDx: "" } });
    expect(ev.status).toBe(200);
    const still = await request(app).get("/api/users").set(A(ttk));
    expect(still.status).toBe(200);
    expect(Array.isArray(still.body)).toBe(true);
    expect(still.body.some((u) => u.username === "teacher")).toBe(true);
  });

  it("five parallel evaluates on the same class all succeed", async () => {
    const ttk = await token("teacher");
    const usernames = ["40011223", "40022334", "40033445", "40044556", "40055667"];
    const ids = [];
    for (const u of usernames) ids.push(await studentId(ttk, u));
    const created = await request(app).post("/api/classes").set(A(ttk))
      .send({ name_en: `Par ${Math.random()}`, name_fa: "موازی", gradingRole: "history", maxAttempts: 3 });
    const cid = created.body.id;
    await request(app).put(`/api/classes/${cid}/members`).set(A(ttk)).send({ userIds: ids });
    await request(app).put(`/api/classes/${cid}/cases`).set(A(ttk)).send({ cases: [{ case_id: 1, weight: 1 }] });
    const session = { messages: [{ role: "student", text: "سلام" }], tests: [], imaging: [], ddx: [], finalDx: "", problemList: [] };
    const reqs = await Promise.all(usernames.map(async (u) => {
      const stk = await token(u);
      return request(app).post("/api/exam/evaluate").set(A(stk))
        .send({ caseId: 1, classId: cid, lang: "fa", durationSec: 8, session });
    }));
    expect(reqs.every((r) => r.status === 200)).toBe(true);
    expect(reqs.every((r) => typeof r.body.score === "number")).toBe(true);
  });
});

describe("answer-key surfaces stay closed to students", () => {
  it("GET /checklists and /checklists-meta are teacher/admin only", async () => {
    const stk = await token("40012345");
    const a = await request(app).get("/api/checklists").set(A(stk));
    const b = await request(app).get("/api/checklists-meta").set(A(stk));
    expect(a.status).toBe(403);
    expect(b.status).toBe(403);
  });

  it("student case payload does not include checklist_id", async () => {
    const ttk = await token("teacher");
    const stuId = await studentId(ttk, "40033445");
    const cid = await makeClass(ttk, stuId, 1);
    const stk = await token("40033445");
    const r = await request(app).get("/api/cases/1").set(A(stk));
    expect(r.status).toBe(200);
    expect(r.body.checklist_id).toBeUndefined();
    expect(r.body.ddx_fa).toBeUndefined();
    expect(r.body.diagnosis_fa).toBeUndefined();
  });
});

describe("class rubric override actually changes the intern score", () => {
  it("intern class with only history+exam in the rubric scores 100 on a history+exam session", async () => {
    const ttk = await token("teacher");
    const stuId = await studentId(ttk, "40044556");
    const cl = await request(app).post("/api/checklists").set(A(ttk)).send({
      name_fa: "پایداری", name_en: "stability rubric",
      items: [
        { id: "h1", section: "history", weight: 2, fa: "معرفی", en: "Intro", keys: ["سلام", "hello"] },
        { id: "e1", section: "exam", weight: 2, fa: "معاینه", en: "Exam", keys: ["معاینه", "examine"] },
        { id: "w1", section: "workup", weight: 8, fa: "ECG", en: "ECG", keys: ["ecg"] },
      ],
    });
    const c = await request(app).post("/api/cases").set(A(ttk)).send({
      title_fa: "کیس پایداری نمره", title_en: "Rubric stability case",
      age: 40, sex: "male", chief_fa: "درد", chief_en: "Pain",
      checklist_id: cl.body.id,
    });
    const rubric = {
      roles: {
        extern: { sections: ["history", "exam"], weightMode: "items" },
        intern: { sections: ["history", "exam"], weightMode: "items" },
      },
    };
    const classId = await makeClass(ttk, stuId, c.body.id, { gradingRole: "overall", gradingRubric: rubric });
    const stk = await token("40044556");
    const r = await request(app).post("/api/exam/evaluate").set(A(stk)).send({
      caseId: c.body.id, classId, lang: "fa", durationSec: 20,
      session: {
        messages: [
          { role: "student", text: "سلام من دکتر هستم" },
          { role: "student", text: "لطفاً بیمار را معاینه کنید" },
        ],
        tests: [], imaging: [], ddx: [], finalDx: "", problemList: [],
      },
    });
    expect(r.status).toBe(200);
    expect(r.body.meta.gradingScope).toBe("intern");
    expect(r.body.sectionScores.intern).toBe(100);
    expect(r.body.score).toBe(100);            // intern class uses intern rubric, not overall
    expect(r.body.sectionScores.overall).toBeLessThan(100); // workup still failed overall
    expect(r.body.meta.rubric.roles.intern.sections).toEqual(["history", "exam"]);
  });

  it("GET /settings/vp_grading returns a normalised default rubric to teachers", async () => {
    const ttk = await token("teacher");
    const r = await request(app).get("/api/settings/vp_grading").set(A(ttk));
    expect(r.status).toBe(200);
    expect(r.body.roles.extern.sections).toEqual(["history", "exam", "problem_list", "ddx"]);
    expect(r.body.roles.intern.weightMode).toBe("items");
  });

  it("a student cannot read or write the grading panel", async () => {
    const stk = await token("40012345");
    const g = await request(app).get("/api/settings/vp_grading").set(A(stk));
    const p = await request(app).put("/api/settings/vp_grading").set(A(stk)).send({});
    expect(g.status).toBe(403);
    expect(p.status).toBe(403);
  });
});

describe("same-university teachers can review a class they did not create", () => {
  it("peer teacher can fetch the conversation CSV of a classmate's class", async () => {
    const ttk = await token("teacher");
    const atk = await token("admin");
    const peerName = `teacher_peer_${Date.now()}`;
    const created = await request(app).post("/api/users").set(A(atk)).send({
      username: peerName, password: "demo", name_fa: "همکار", name_en: "Peer",
      role: "teacher", university_id: 1,
    });
    expect(created.status).toBe(200);
    const stuId = await studentId(ttk, "40055667");
    const cid = await makeClass(ttk, stuId, 1, { logTranscript: true });
    const stk = await token("40055667");
    const sess = await request(app).post("/api/exam/session-start").set(A(stk)).send({ caseId: 1, classId: cid });
    await request(app).post("/api/exam/evaluate").set(A(stk)).send({
      caseId: 1, classId: cid, lang: "fa", durationSec: 15,
      sessionId: sess.body.sessionId,
      events: [{ kind: "student_msg", atMs: 10, text: "سلام" }, { kind: "finish", atMs: 20 }],
      session: { messages: [{ role: "student", text: "سلام" }], tests: [], imaging: [], ddx: [], finalDx: "" },
    });
    const ptk = await token(peerName, "demo");
    const csv = await request(app).get(`/api/classes/${cid}/conversation-log.csv`).set(A(ptk));
    expect(csv.status).toBe(200);
    expect(csv.text).toContain("student_msg");
  });
});
