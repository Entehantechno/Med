/* ================================================================
   vp-realistic-grading.test.js — round 27 fixes
     1. a bare "what is your problem?" must NOT tick "introduce self &
        obtain consent" (keyword match used to fire on the PATIENT's "سلام")
     2. legacy checklists without `section` are classified from wording, so
        the extern and intern scores differ when workup/dx/plan were skipped
     3. history & physical exam are one station: a physical-exam request and a
        review of systems are ALWAYS scored
     4. the mock patient drip-feeds: chief complaint first, details on demand
     5. with an LLM key: the checklist scorer receives evidence rules + the
        admin evaluator prompt; the micro-lesson is never empty (dedicated
        retry when the model drops it)
     6. prompt defaults upgrade in place unless the admin edited them
   ================================================================ */
import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { execSync } from "child_process";
import request from "supertest";
import { initDb, db } from "../src/db.js";
import { createApp } from "../src/app.js";
import { inferSection, normalizeChecklistItems } from "../src/lib/history-sections.js";
import { patientReply, rosCovered } from "../src/lib/ai-engine.js";
import { upgradeDefaultPrompts, DEFAULT_PROMPTS, PATIENT_DEFAULTS_HISTORY } from "../src/lib/vp-prompts.js";

let app;
const A = (tk) => ({ Authorization: `Bearer ${tk}` });
async function token(u, p = "demo") {
  return (await request(app).post("/api/auth/login").send({ username: u, password: p })).body.token;
}

beforeAll(async () => {
  execSync("node src/seed.js --force", { cwd: process.cwd(), stdio: "ignore" });
  await initDb();
  app = createApp();
});

describe("section inference for legacy checklist items", () => {
  it("classifies workup / diagnosis / management / exam rows from their wording", () => {
    expect(inferSection({ fa: "درخواست ECG", en: "Order ECG" })).toBe("workup");
    expect(inferSection({ fa: "درخواست تروپونین", en: "Order troponin" })).toBe("workup");
    expect(inferSection({ fa: "تشخیص صحیح STEMI/ACS", en: "Correct STEMI/ACS diagnosis" })).toBe("diagnosis");
    expect(inferSection({ fa: "بیان برنامه درمان اولیه", en: "State initial management" })).toBe("management");
    expect(inferSection({ fa: "ذکر علامت مورفی", en: "Mention Murphy's sign" })).toBe("exam");
    expect(inferSection({ fa: "معرفی خود و کسب رضایت", en: "Introduce self & consent" })).toBe("history");
    expect(inferSection({ fa: "پرسش ماهیت و انتشار درد", en: "Ask pain character & radiation" })).toBe("history");
    // explicit section always wins
    expect(inferSection({ section: "communication", fa: "درخواست ECG", en: "Order ECG" })).toBe("communication");
    expect(normalizeChecklistItems([{ en: "Order ECG" }])[0].section).toBe("workup");
  });
});

describe("deterministic grading is evidence-based", () => {
  it("a bare 'what is your problem?' does not tick intro/consent, and extern != intern", async () => {
    const tk = await token("40012345");
    const r = await request(app).post("/api/exam/evaluate").set(A(tk)).send({
      caseId: 1, classId: 1, lang: "fa",
      session: {
        messages: [
          { role: "student", text: "مشکل شما چیست؟" },
          { role: "patient", text: "سلام دکتر، قفسه سینه‌ام درد می‌کند" },   // patient says سلام — must not credit the student
        ],
        tests: [], imaging: [], ddx: [], finalDx: "", problemList: [],
      },
    });
    expect(r.status).toBe(200);
    const byId = Object.fromEntries(r.body.results.map((x) => [x.id, x]));
    expect(byId.i1.done).toBe(false);          // introduce self & consent
    expect(byId.i4.section).toBe("workup");    // legacy row classified
    expect(byId.i6.section).toBe("diagnosis");
    expect(byId.i7.section).toBe("management");
    // physical exam + ROS are always-scored items
    expect(byId.px01?.section).toBe("exam");
    expect(byId.px01?.done).toBe(false);
    expect(byId.ros01?.section).toBe("history");
    expect(byId.ros01?.done).toBe(false);
  });

  it("extern and intern scores differ when the workup/diagnosis/plan were skipped", async () => {
    const tk = await token("40012345");
    const r = await request(app).post("/api/exam/evaluate").set(A(tk)).send({
      caseId: 1, classId: 1, lang: "fa",
      session: {
        messages: [
          { role: "student", text: "سلام، من دکتر احمدی هستم، اجازه می‌دهید چند سؤال بپرسم؟" },
          { role: "student", text: "درد چه جور دردی است و به جایی انتشار دارد؟" },
          { role: "student", text: "دیابت یا فشار خون دارید؟ سیگار می‌کشید؟ در خانواده سابقهٔ قلبی هست؟" },
          { role: "student", text: "لطفاً علائم حیاتی و معاینهٔ قلب را انجام دهید" },
          { role: "student", text: "تب یا لرز داشتید؟ سرفه یا تنگی نفس؟ تهوع یا استفراغ؟ مشکل ادراری؟" },
        ],
        tests: [], imaging: [], ddx: ["ACS", "آمبولی ریه"], finalDx: "",
        problemList: ["درد قفسهٔ سینهٔ حاد", "دیابت نوع ۲", "فشار خون بالا"],
      },
    });
    expect(r.status).toBe(200);
    const ss = r.body.sectionScores;
    expect(ss.extern).toBe(100);
    expect(ss.intern).toBeLessThan(ss.extern);   // ECG/troponin/dx/plan missing (13 of 33 weight)
    expect(ss.intern).toBeLessThan(80);
  });

  it("rosCovered needs at least three other systems or an explicit ROS question", () => {
    expect(rosCovered("درد کجاست؟")).toBe(false);
    expect(rosCovered("تب دارید؟")).toBe(false);
    expect(rosCovered("تب دارید؟ سرفه؟ تهوع یا استفراغ؟")).toBe(true);
    expect(rosCovered("Any other symptoms anywhere else?")).toBe(true);
  });
});

describe("mock patient drip-feeds information", () => {
  const c = {
    chief_fa: "درد ربع فوقانی راست شکم از دیشب",
    history_fa: "درد پس از غذای چرب شروع شده، به شانه راست انتشار دارد، همراه با تهوع و استفراغ.",
    pmh_fa: "ندارد", diagnosis_fa: "کوله‌سیستیت حاد",
  };
  const ask = (q) => patientReply({ caseData: c, userText: q, lang: "fa", prompts: {}, aiCfg: {} });
  it("chief complaint only, then details on request", async () => {
    const cc = await ask("مشکل شما چیست؟");
    expect(cc.text).toContain("درد ربع فوقانی راست شکم");
    expect(cc.text).not.toContain("انتشار");
    expect(cc.text).not.toContain("تهوع");
    const rad = await ask("درد به جایی انتشار دارد؟");
    expect(rad.text).toContain("شانه راست");
    expect(rad.text).not.toContain("تهوع");
    const fever = await ask("تب دارید؟");
    expect(fever.text).toMatch(/نه/);
    const nausea = await ask("تهوع دارید؟");
    expect(nausea.text).toContain("تهوع");
  });
});

describe("LLM path: evidence rules, admin evaluator prompt, non-empty micro-lesson", () => {
  let atk, llm, port;
  const seen = { sys: [], calls: 0 };
  beforeAll(async () => {
    atk = await token("admin");
    const http = await import("http");
    llm = http.createServer((rq, rs) => {
      if (!(rq.url.endsWith("/chat/completions") && rq.method === "POST")) { rs.writeHead(404); return rs.end(); }
      let b = ""; rq.on("data", (ch) => (b += ch)); rq.on("end", () => {
        let p = {}; try { p = JSON.parse(b); } catch { /* */ }
        seen.calls++;
        const sys = (p.messages || []).find((m) => m.role === "system")?.content || "";
        seen.sys.push(sys);
        const json = p.response_format?.type === "json_object";
        let content;
        if (json && /RUBRIC/.test((p.messages || []).find((m) => m.role === "user")?.content || "")) {
          // checklist scorer → only ros01 done, everything else not done
          const ids = [...((p.messages || []).find((m) => m.role === "user")?.content || "").matchAll(/"id":"([^"]+)"/g)].map((m) => m[1]);
          content = JSON.stringify({ items: ids.map((id) => ({ id, done: id === "ros01", reason: "r" })) });
        } else if (json) {
          // enrichment → model "forgets" the micro-lesson
          content = JSON.stringify({ strengths: ["s"], weaknesses: ["w"], missed: ["m"], commonMistakes: ["c"], suggestion: "sg", microlearning: "" });
        } else {
          content = "درسنامهٔ اختصاصی\n۱. معرفی خود و کسب رضایت: در ابتدای هر ویزیت خود را معرفی کنید و اجازه بگیرید.\n۲. مرور سیستم‌ها: علائم سایر سیستم‌ها را غربال کنید.\n۳. معاینهٔ فیزیکی هدفمند را فراموش نکنید.";
        }
        rs.writeHead(200, { "content-type": "application/json" });
        rs.end(JSON.stringify({ choices: [{ message: { role: "assistant", content } }] }));
      });
    });
    await new Promise((r) => llm.listen(0, r));
    port = llm.address().port;
    await request(app).put("/api/settings/ai").set(A(atk))
      .send({ provider: "Custom", baseUrl: `http://localhost:${port}/v1`, apiKey: "sk-test", model: "fake" });
    await request(app).put("/api/prompts").set(A(atk)).send({ evaluator_fa: "EVAL_MARKER_4411 " + DEFAULT_PROMPTS.evaluator_fa });
  });
  it("admin-edited evidence rules and disclosure text replace the shipped defaults (nothing is hard-coded)", async () => {
    await request(app).put("/api/prompts").set(A(atk)).send({
      evaluator_rules_fa: "RULES_MARKER_9001 فقط گفته‌های دانشجو",
      patient_disclosure_fa: "DISCLOSURE_MARKER_9002 کوتاه جواب بده",
    });
    const tk = await token("40067890");
    seen.sys.length = 0; seen.calls = 0;
    const c = await request(app).post("/api/exam/patient-reply").set(A(tk))
      .send({ caseId: 1, classId: 1, userText: "مشکل شما چیست؟", history: [], lang: "fa" });
    expect(c.status).toBe(200);
    expect(seen.sys.some((s) => s.includes("DISCLOSURE_MARKER_9002"))).toBe(true);
    seen.sys.length = 0;
    const r = await request(app).post("/api/exam/evaluate").set(A(tk)).send({
      caseId: 1, classId: 1, lang: "fa",
      session: { messages: [{ role: "student", text: "مشکل شما چیست؟" }], tests: [], imaging: [], ddx: [], finalDx: "", problemList: [] },
    });
    expect(r.status).toBe(200);
    const scorerSys = seen.sys.find((s) => /RUBRIC of checklist items/.test(s));
    expect(scorerSys).toContain("RULES_MARKER_9001");
    expect(scorerSys).not.toContain("قواعد شاهد (الزامی)");
    // restore
    await request(app).put("/api/prompts").set(A(atk)).send({
      evaluator_rules_fa: DEFAULT_PROMPTS.evaluator_rules_fa, patient_disclosure_fa: DEFAULT_PROMPTS.patient_disclosure_fa,
    });
  });

  afterAll(async () => {
    try { llm.close(); } catch { /* */ }
    await request(app).put("/api/settings/ai").set(A(atk)).send({ provider: "", baseUrl: "", apiKey: "", clearApiKey: true, model: "" });
  });

  it("scorer prompt carries the evidence rules + admin evaluator text; micro-lesson is filled by the retry", async () => {
    const tk = await token("40067890");   // Maryam: enrolled in class 1, fresh attempt budget
    seen.sys.length = 0; seen.calls = 0;
    const r = await request(app).post("/api/exam/evaluate").set(A(tk)).send({
      caseId: 1, classId: 1, lang: "fa",
      session: { messages: [{ role: "student", text: "مشکل شما چیست؟" }], tests: [], imaging: [], ddx: [], finalDx: "", problemList: [] },
    });
    expect(r.status).toBe(200);
    expect(r.body.meta.scoredBy).toBe("llm");
    const scorerSys = seen.sys.find((s) => /RUBRIC of checklist items/.test(s));
    expect(scorerSys).toBeTruthy();
    expect(scorerSys).toContain("EVAL_MARKER_4411");                 // admin evaluator prompt reached the scorer
    expect(scorerSys).toContain("قواعد شاهد");                        // evidence rules (Persian, lang=fa) reached the scorer
    // LLM judged ros01 done → deterministic result overridden
    expect(r.body.results.find((x) => x.id === "ros01").done).toBe(true);
    expect(r.body.results.find((x) => x.id === "i1").done).toBe(false);
    // micro-lesson came from the dedicated retry, not empty
    expect(r.body.microlearning).toContain("درسنامهٔ اختصاصی");
    expect(seen.calls).toBe(3);   // scorer + enrich + micro retry
  });
});

describe("prompt defaults upgrade safely", () => {
  it("replaces untouched old defaults, keeps admin edits, adds missing keys", () => {
    db.prepare("UPDATE prompts SET value=? WHERE key='patient_fa'").run(PATIENT_DEFAULTS_HISTORY.patient_fa[0]);
    db.prepare("UPDATE prompts SET value=? WHERE key='patient_en'").run("ADMIN CUSTOM TEXT");
    db.prepare("DELETE FROM prompts WHERE key='micro_en'").run();
    const n = upgradeDefaultPrompts(db);
    expect(n).toBeGreaterThanOrEqual(2);
    const get = (k) => db.prepare("SELECT value FROM prompts WHERE key=?").get(k)?.value;
    expect(get("patient_fa")).toBe(DEFAULT_PROMPTS.patient_fa);
    expect(get("patient_en")).toBe("ADMIN CUSTOM TEXT");
    expect(get("micro_en")).toBe(DEFAULT_PROMPTS.micro_en);
    expect(DEFAULT_PROMPTS.patient_fa).toMatch(/ذره‌ذره/);
    expect(upgradeDefaultPrompts(db)).toBe(0);   // idempotent
  });
});

describe("vp_policy — admin-editable auto items, ROS threshold, star cut-offs", () => {
  it("normalizes and clamps; defaults match the shipped behaviour", async () => {
    const { normalizeVpPolicy, starsForScore, DEFAULT_VP_POLICY } = await import("../src/lib/vp-policy.js");
    expect(normalizeVpPolicy(null)).toEqual(DEFAULT_VP_POLICY);
    const p = normalizeVpPolicy({ autoItems: { ros: { weight: 99, minSystems: 0 }, ddx: { enabled: false } }, stars: { cuts: [50, 10, 30, 70, 90, 95] }, homeCaseTile: "always" });
    expect(p.autoItems.ros.weight).toBe(20);
    expect(p.autoItems.ros.minSystems).toBe(1);
    expect(p.autoItems.ddx.enabled).toBe(false);
    expect(p.stars.cuts).toEqual([10, 30, 50, 70, 90]);
    expect(p.homeCaseTile).toBe("always");
    expect(starsForScore(74, [20, 40, 60, 75, 90])).toBe(3);
    expect(normalizeVpPolicy({ stars: { cuts: [1, 2] } }).stars.cuts).toEqual(DEFAULT_VP_POLICY.stars.cuts);
  });

  it("admin PUT /settings/vp_policy changes what the engine scores; students can read it, not write it", async () => {
    const atk = await token("admin", "demo");
    const stk = await token("40012345");
    const w = await request(app).put("/api/settings/vp_policy").set(A(stk)).send({ autoItems: { ros: { enabled: false } } });
    expect(w.status).toBe(403);
    const rd = await request(app).get("/api/settings/vp_policy").set(A(stk));
    expect(rd.status).toBe(200);
    expect(rd.body.stars.cuts).toEqual([20, 40, 60, 75, 90]);

    // turn off the auto ROS item and re-weight the exam item
    const up = await request(app).put("/api/settings/vp_policy").set(A(atk))
      .send({ autoItems: { ros: { enabled: false }, physicalExam: { weight: 5 } } });
    expect(up.status).toBe(200);
    const { evaluate } = await import("../src/lib/ai-engine.js");
    const { getSetting } = await import("../src/routes/content.js");
    const checklist = { items: [{ id: "a", fa: "معرفی خود", en: "Introduce self", keys: ["دکتر هستم"], weight: 1, section: "history" }] };
    const ev = evaluate({ caseData: { chief_fa: "x", diagnosis_fa: "y" }, checklist, session: { messages: [] }, lang: "fa", policy: getSetting("vp_policy", null) });
    const ids = ev.results.map((r) => r.id);
    expect(ids).not.toContain("ros01");
    expect(ev.results.find((r) => r.id === "px01").weight).toBe(5);
    // restore defaults
    await request(app).put("/api/settings/vp_policy").set(A(atk)).send({});
  });
});
