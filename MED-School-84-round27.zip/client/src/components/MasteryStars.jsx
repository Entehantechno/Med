/* MasteryStars — 5-star mastery indicator for a virtual-patient case.

   Why stars (research notes, round 27):
   • Learners rank "progress indicators / achievements / immediate feedback"
     as the most motivating game elements — far above leaderboards or virtual
     currency (best-worst-scaling survey, 2025). Stars are a compact progress
     indicator, so they fit that top tier.
   • Star ranks work as a "performance-progression" loop: the student's own
     best result becomes the next target, which nudges REPLAY of a case
     (Angry-Birds-style 2-star pass / 3-star mastery). That is exactly what
     we want for OSCE practice — repeat the station until it is clean.
   • Meta-analyses warn the effect flips negative when the mechanic is about
     COMPETITION / social comparison. So: criterion-referenced (fixed cut-offs
     on the score), private to the student, never a ranking against peers.
   • Design rule: stars must never REPLACE the diagnostic feedback; they sit
     next to the score and the checklist, which stay the source of truth.

   Thresholds (score /100, same for every case so the meaning is stable) —
   shipped defaults, ADMIN-EDITABLE in Admin → Virtual-patient grading:
     ★☆☆☆☆  ≥ 20     ★★☆☆☆ ≥ 40     ★★★☆☆ ≥ 60 (pass)
     ★★★★☆  ≥ 75     ★★★★★ ≥ 90 (mastery)
   0 stars when never attempted / below cut 1. Purely presentational. */
import { useApp } from "../context.jsx";
import { useVpPolicy, starsForScore as starsFor, DEFAULT_CUTS } from "../lib/vpPolicy.js";

export const STAR_CUTS = DEFAULT_CUTS;
export const starsForScore = starsFor;

/* `cuts` / `forceShow` are for the admin preview; normal callers read the
   admin policy (settings.vp_policy) through useVpPolicy(). */
export default function MasteryStars({ score, size = 16, className = "", showLabel = true, title, cuts: cutsProp, forceShow = false }) {
  const { lang } = useApp();
  const policy = useVpPolicy();
  const fa = lang === "fa";
  if (!forceShow && !cutsProp && policy?.stars?.enabled === false) return null;
  const cuts = Array.isArray(cutsProp) && cutsProp.length === 5 ? cutsProp : (policy?.stars?.cuts || DEFAULT_CUTS);
  const attempted = score != null && Number.isFinite(Number(score));
  const n = attempted ? starsFor(score, cuts) : 0;
  const label = !attempted
    ? (fa ? "هنوز انجام نشده" : "Not attempted yet")
    : n === 5 ? (fa ? "تسلط کامل" : "Mastered")
    : n >= 3 ? (fa ? "قبول — برای تسلط دوباره تلاش کن" : "Passed — retry for mastery")
    : (fa ? "نیاز به تمرین بیشتر" : "Needs more practice");
  const tip = title || (attempted
    ? (fa ? `بهترین نمرهٔ شما: ${score} — ${n} از ۵ ستاره` : `Your best: ${score} — ${n}/5 stars`)
    : label);
  return (
    <span className={`mastery-stars ${className}`} title={tip}
      role="img" aria-label={fa ? `${n} از ۵ ستاره` : `${n} of 5 stars`}>
      {Array.from({ length: 5 }, (_, i) => (
        <svg key={i} width={size} height={size} viewBox="0 0 24 24" aria-hidden="true"
          className={`mastery-star ${i < n ? "lit" : ""}`}>
          <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14l-5-4.87 6.91-1.01L12 2Z"
            fill={i < n ? "#f6c343" : "none"} stroke={i < n ? "#e0a91c" : "currentColor"}
            strokeWidth="1.4" strokeLinejoin="round" opacity={i < n ? 1 : 0.38} />
        </svg>
      ))}
      {showLabel && <span className="mastery-label small muted">{label}</span>}
    </span>
  );
}
