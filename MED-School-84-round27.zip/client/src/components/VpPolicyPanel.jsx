/* VpPolicyPanel — admin editor for settings.vp_policy (round 27).
   Everything the v84 virtual-patient changes introduced as a "number" or a
   "rule" lives here so the admin can change it: auto-scored items + weights,
   the ROS threshold, the mastery-star cut-offs, and the student-home tile. */
import { useEffect, useState } from "react";
import { useApp } from "../context.jsx";
import { api } from "../api.js";
import { Spinner, useToast } from "./UI.jsx";
import Icon from "./Icon.jsx";
import MasteryStars from "./MasteryStars.jsx";
import { invalidateVpPolicy, loadVpPolicy } from "../lib/vpPolicy.js";

export const DEFAULT_VP_POLICY = {
  autoItems: {
    problemList: { enabled: true, weight: 3 },
    ddx: { enabled: true, weight: 3 },
    physicalExam: { enabled: true, weight: 3 },
    ros: { enabled: true, weight: 2, minSystems: 3 },
  },
  stars: { enabled: true, cuts: [20, 40, 60, 75, 90] },
  homeCaseTile: "auto",
};

export default function VpPolicyPanel() {
  const { t, lang } = useApp();
  const fa = lang === "fa";
  const toast = useToast();
  const [p, setP] = useState(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const load = () => {
    setErr("");
    api.get("/settings/vp_policy").then(setP).catch((e) => { setErr(String(e.message || e)); setP({ __err: true }); });
  };
  useEffect(() => { load(); }, []);
  if (p?.__err || err) return <div className="card empty-state"><div className="ico">⚠️</div><h3>{err || "error"}</h3><button className="btn btn-ghost mt16" onClick={() => { setP(null); load(); }}>{fa ? "تلاش دوباره" : "Retry"}</button></div>;
  if (!p) return <Spinner />;

  const setItem = (k, patch) => setP((s) => ({ ...s, autoItems: { ...s.autoItems, [k]: { ...s.autoItems[k], ...patch } } }));
  const setCut = (i, v) => setP((s) => { const cuts = [...s.stars.cuts]; cuts[i] = Math.max(0, Math.min(100, Number(v) || 0)); return { ...s, stars: { ...s.stars, cuts } }; });
  const save = async () => {
    setBusy(true);
    try { const d = await api.put("/settings/vp_policy", p); setP(d && d.autoItems ? d : p); invalidateVpPolicy(); loadVpPolicy(true); toast(t("saved")); }
    catch (e) { toast(e.message || "error"); }
    finally { setBusy(false); }
  };
  const rows = [
    ["problemList", t("vpPolicyPl")], ["ddx", t("vpPolicyDdx")], ["physicalExam", t("vpPolicyPx")], ["ros", t("vpPolicyRos")],
  ];
  return (
    <div className="card">
      <div className="section-title">
        <h4><Icon name="settings" size={16} /> {t("vpPolicy")}</h4>
        <div style={{ display: "flex", gap: 8 }}>
          <button className="btn btn-ghost btn-sm" onClick={() => setP(JSON.parse(JSON.stringify(DEFAULT_VP_POLICY)))}>{t("vpPolicyReset")}</button>
          <button className="btn btn-primary btn-sm" disabled={busy} onClick={save}>{t("save")}</button>
        </div>
      </div>
      <p className="small muted mb16">{t("vpPolicyHint")}</p>

      <div className="small muted mb8"><Icon name="check" size={15} /> {t("vpPolicyAutoItems")}</div>
      {rows.map(([k, label]) => {
        const it = p.autoItems[k];
        return (
          <div key={k} className="toggle-row" style={{ gap: 10, flexWrap: "wrap" }}>
            <label style={{ cursor: "pointer", flex: 1, display: "flex", alignItems: "center", gap: 10, minWidth: 220 }}>
              <input type="checkbox" checked={!!it.enabled} onChange={() => setItem(k, { enabled: !it.enabled })} style={{ width: 18, height: 18 }} />
              <span>{label}</span>
            </label>
            {it.enabled && (
              <span className="small muted" style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                {t("vpPolicyWeight")}
                <input type="number" min="0" max="20" step="1" value={it.weight} style={{ width: 70 }}
                  onChange={(e) => setItem(k, { weight: e.target.value })} />
              </span>
            )}
            {k === "ros" && it.enabled && (
              <span className="small muted" style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                {t("vpPolicyRosMin")}
                <input type="number" min="1" max="10" step="1" value={it.minSystems} style={{ width: 70 }}
                  onChange={(e) => setItem(k, { minSystems: e.target.value })} />
              </span>
            )}
          </div>
        );
      })}

      <div className="divider" />
      <div className="small muted mb8"><Icon name="trophy" size={15} /> {t("vpPolicyStars")}</div>
      <label className="toggle-row" style={{ cursor: "pointer" }}>
        <span>{t("vpPolicyStarsOn")}</span>
        <div className={`switch ${p.stars.enabled ? "on" : ""}`} onClick={() => setP((s) => ({ ...s, stars: { ...s.stars, enabled: !s.stars.enabled } }))} />
      </label>
      {p.stars.enabled && (
        <div className="mt8">
          <div className="small muted mb8">{t("vpPolicyCuts")}</div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
            {p.stars.cuts.map((c, i) => (
              <label key={i} className="small" style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
                {"★".repeat(i + 1)}
                <input type="number" min="0" max="100" value={c} style={{ width: 64 }} onChange={(e) => setCut(i, e.target.value)} />
              </label>
            ))}
          </div>
          <div className="small muted mt8" style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
            {[35, 62, 88, 95].map((v) => <span key={v}>{v}% → <MasteryStars score={v} size={14} showLabel={false} cuts={p.stars.cuts} /></span>)}
          </div>
        </div>
      )}

      <div className="divider" />
      <div className="field">
        <label><Icon name="home" size={14} /> {t("vpPolicyTile")}</label>
        <select value={p.homeCaseTile} onChange={(e) => setP((s) => ({ ...s, homeCaseTile: e.target.value }))}>
          <option value="auto">{t("vpPolicyTileAuto")}</option>
          <option value="always">{t("vpPolicyTileAlways")}</option>
          <option value="never">{t("vpPolicyTileNever")}</option>
        </select>
      </div>
    </div>
  );
}
