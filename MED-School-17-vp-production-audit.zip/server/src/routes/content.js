/* ================================================================
   content.js — Cases, flashcards, checklists, users, prompts,
   settings CRUD (with content versioning on cases & flashcards).
   ================================================================ */
import { Router } from "express";
import bcrypt from "bcryptjs";
import { db, persistNow } from "../db.js";
import { authRequired, requireRole } from "../lib/auth.js";
import { toCSV, parseCSV } from "../lib/csv.js";
import { normalizeRubric } from "../lib/grading-rubric.js";

const r = Router();
const parse = (row, extra = {}) => ({ ...JSON.parse(row.data_json), id: row.id, version: row.version, difficulty: row.difficulty, university_id: row.university_id || null, ...extra });
function tenantFilterFor(user) { return user.role === "teacher" ? currentUniversityId(user) : null; }

/* BUGFIX (answer leak): case payloads returned to students/learners used to be
   the FULL data_json — diagnosis, teaching objectives, exam findings, lab and
   imaging answers were sitting in the student's browser (devtools-readable).
   The UI only ever needs the card fields + the medical images, so for those
   roles we whitelist exactly those. Teachers/admins still get the full record
   (they author the cases). */
const STUDENT_SAFE_CASE_FIELDS = [
  "id", "version", "difficulty", "title_fa", "title_en",
  "specialty_fa", "specialty_en", "age", "sex",
  "chief_fa", "chief_en", "images", "history_form",
];
const STUDENT_SAFE_EXTRAS = new Set(["maxAttempts", "attemptsUsed", "university_id", "active"]);
function studentSafeCase(full) {
  const safe = {};
  for (const k of STUDENT_SAFE_CASE_FIELDS) if (full?.[k] !== undefined) safe[k] = full[k];
  // keep any caller-added non-data values (maxAttempts, attemptsUsed, ...)
  // but NEVER copy numeric answer-key fields such as checklist_id.
  for (const [k, v] of Object.entries(full || {})) {
    if (STUDENT_SAFE_CASE_FIELDS.includes(k)) continue;
    if (STUDENT_SAFE_EXTRAS.has(k) && typeof v !== "string" && typeof v !== "object") safe[k] = v;
  }
  return safe;
}
function canManageUniResource(user, row) { return user.role === "admin" || (user.role === "teacher" && (row.university_id || 1) === currentUniversityId(user)); }

/* ---------------- Exam access helpers ---------------- */
// Returns the set of case_ids a student is allowed to access.
export function assignedCaseIds(userId) {
  const rows = db.prepare(
    "SELECT case_id FROM exam_assignments WHERE user_id=? AND active=1"
  ).all(userId);
  return new Set(rows.map((r) => r.case_id));
}
export function canAccessCase(user, caseId) {
  if (user.role !== "student") return true;          // staff can access everything
  const cid = Number(caseId);
  // (1) directly assigned via exam_assignments
  if (assignedCaseIds(user.id).has(cid)) return true;
  // (2) case attached to an ACTIVE class the student is enrolled in.
  //     Deactivating a class must revoke its students' access to the class's
  //     cases (otherwise a student could keep reaching them by case id).
  const viaClass = db.prepare(
    `SELECT 1 FROM class_cases cc
       JOIN classes c ON c.id = cc.class_id
       JOIN class_members m ON m.class_id = cc.class_id
      WHERE cc.case_id=? AND m.user_id=? AND c.active=1 LIMIT 1`
  ).get(cid, user.id);
  if (viaClass) return true;
  // (3) case belongs to a scheduled exam the student is a participant of.
  //     Exam cases are stored as a JSON array column, so scan the participant's
  //     exams and check their case_ids.
  const examRows = db.prepare(
    `SELECT e.case_ids FROM exams e
       JOIN exam_participants p ON p.exam_id = e.id
      WHERE p.user_id=? AND e.active=1`
  ).all(user.id);
  for (const row of examRows) {
    try {
      const ids = JSON.parse(row.case_ids || "[]");
      if (Array.isArray(ids) && ids.map(Number).includes(cid)) return true;
    } catch { /* ignore malformed */ }
  }
  return false;
}

/* ---------------- CASES ---------------- */
r.get("/cases", authRequired, (req, res) => {
  let rows = db.prepare("SELECT * FROM cases WHERE active=1 ORDER BY id").all();
  const uni = tenantFilterFor(req.user);
  if (uni) rows = rows.filter((row) => (row.university_id || 1) === uni);
  let list = rows.map((row) => parse(row, { checklist_id: row.checklist_id }));
  // Never ship answer data to the student/learner side of the app.
  if (req.user.role === "student" || req.user.role === "learner") list = list.map(studentSafeCase);
  // Students only see cases the admin/teacher assigned to them.
  if (req.user.role === "student") {
    const allowed = assignedCaseIds(req.user.id);
    list = list
      .filter((c) => allowed.has(c.id))
      .map((c) => {
        const a = db.prepare(
          "SELECT max_attempts FROM exam_assignments WHERE user_id=? AND case_id=? AND active=1"
        ).get(req.user.id, c.id);
        // Count ONLY standalone attempts against this direct assignment.
        // Attempts made inside a class/exam (class_id / exam_id set) are spent
        // against those containers' quotas and must not eat this budget.
        const used = db.prepare(
          "SELECT COUNT(*) n FROM attempts WHERE user_id=? AND case_id=? AND class_id IS NULL AND exam_id IS NULL"
        ).get(req.user.id, c.id).n;
        return { ...c, maxAttempts: a?.max_attempts ?? 1, attemptsUsed: used };
      });
  }
  res.json(list);
});
r.get("/cases/:id", authRequired, (req, res) => {
  const row = db.prepare("SELECT * FROM cases WHERE id=?").get(req.params.id);
  if (!row) return res.status(404).json({ error: "not found" });
  if (req.user.role === "teacher" && !canManageUniResource(req.user, row)) return res.status(403).json({ error: "wrong_university" });
  if (!canAccessCase(req.user, req.params.id))
    return res.status(403).json({ error: "not assigned to this exam" });
  const full = parse(row, { checklist_id: row.checklist_id });
  res.json((req.user.role === "student" || req.user.role === "learner") ? studentSafeCase(full) : full);
});
r.post("/cases", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const { difficulty = "medium", checklist_id = 1, ...data } = req.body || {};
  const uni = currentUniversityId(req.user) || Number(req.body?.university_id || 0) || 1;
  const info = db.prepare(
    "INSERT INTO cases (version,difficulty,checklist_id,data_json,university_id) VALUES (1,?,?,?,?)"
  ).run(difficulty, checklist_id, JSON.stringify(data), uni);
  res.json({ id: info.lastInsertRowid, version: 1 });
});
r.put("/cases/:id", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const row = db.prepare("SELECT * FROM cases WHERE id=?").get(req.params.id);
  if (!row) return res.status(404).json({ error: "not found" });
  if (!canManageUniResource(req.user, row)) return res.status(403).json({ error: "wrong_university" });
  // archive current version (versioning)
  db.prepare("INSERT INTO case_versions (case_id,version,data_json) VALUES (?,?,?)")
    .run(row.id, row.version, row.data_json);
  const { difficulty = row.difficulty, checklist_id = row.checklist_id, ...data } = req.body || {};
  const newVersion = row.version + 1;
  db.prepare("UPDATE cases SET version=?,difficulty=?,checklist_id=?,data_json=?,updated_at=datetime('now') WHERE id=?")
    .run(newVersion, difficulty, checklist_id, JSON.stringify(data), row.id);
  res.json({ id: row.id, version: newVersion });
});
r.delete("/cases/:id", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const row = db.prepare("SELECT * FROM cases WHERE id=?").get(req.params.id);
  if (!row) return res.status(404).json({ error: "not found" });
  if (!canManageUniResource(req.user, row)) return res.status(403).json({ error: "wrong_university" });
  db.prepare("UPDATE cases SET active=0 WHERE id=?").run(req.params.id);
  res.json({ ok: true });
});
r.get("/cases/:id/versions", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const rows = db.prepare("SELECT version,data_json,archived_at FROM case_versions WHERE case_id=? ORDER BY version DESC").all(req.params.id);
  res.json(rows.map((v) => ({ version: v.version, archived_at: v.archived_at, data: JSON.parse(v.data_json) })));
});

/* ---------------- FLASHCARDS ---------------- */
r.get("/flashcards", authRequired, (req, res) => {
  let rows = db.prepare("SELECT * FROM flashcards WHERE active=1 ORDER BY id").all();
  const uniId = tenantFilterFor(req.user);
  if (uniId) rows = rows.filter((row) => (row.university_id || 1) === uniId);
  // University side: exclude cards that belong to the competitive-learner track
  // (pre-internship path cards & learner-authored personal cards). Legacy cards
  // without a `track` are treated as university content for backward compatibility.
  const uni = rows.filter((row) => {
    try { return JSON.parse(row.data_json).track !== "learn"; } catch { return true; }
  });
  res.json(uni.map((row) => parse(row)));
});
r.post("/flashcards", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const { difficulty = "medium", ...data } = req.body || {};
  data.track = "uni"; // teacher/admin-authored cards belong to the university track
  const uni = currentUniversityId(req.user) || Number(req.body?.university_id || 0) || 1;
  const info = db.prepare("INSERT INTO flashcards (version,difficulty,data_json,university_id) VALUES (1,?,?,?)")
    .run(difficulty, JSON.stringify(data), uni);
  res.json({ id: info.lastInsertRowid, version: 1 });
});
r.put("/flashcards/:id", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const row = db.prepare("SELECT * FROM flashcards WHERE id=?").get(req.params.id);
  if (!row) return res.status(404).json({ error: "not found" });
  if (!canManageUniResource(req.user, row)) return res.status(403).json({ error: "wrong_university" });
  db.prepare("INSERT INTO flashcard_versions (flashcard_id,version,data_json) VALUES (?,?,?)")
    .run(row.id, row.version, row.data_json);
  const { difficulty = row.difficulty, ...data } = req.body || {};
  const newVersion = row.version + 1;
  db.prepare("UPDATE flashcards SET version=?,difficulty=?,data_json=?,updated_at=datetime('now') WHERE id=?")
    .run(newVersion, difficulty, JSON.stringify(data), row.id);
  res.json({ id: row.id, version: newVersion });
});
r.delete("/flashcards/:id", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const row = db.prepare("SELECT * FROM flashcards WHERE id=?").get(req.params.id);
  if (!row) return res.status(404).json({ error: "not found" });
  if (!canManageUniResource(req.user, row)) return res.status(403).json({ error: "wrong_university" });
  db.prepare("UPDATE flashcards SET active=0 WHERE id=?").run(req.params.id);
  res.json({ ok: true });
});

/* ---------------- CSV IMPORT / EXPORT ---------------- */
const CASE_COLS = ["title_fa","title_en","specialty_fa","specialty_en","age","sex","difficulty",
  "chief_fa","chief_en","history_fa","history_en","pmh_fa","pmh_en","meds_fa","meds_en",
  "diagnosis_fa","diagnosis_en","objectives_fa","objectives_en"];
const CARD_COLS = ["title_fa","title_en","category_fa","category_en","difficulty","questionType",
  "answerMode","questionText_fa","questionText_en","correct_fa","correct_en","options_fa","options_en",
  "hints_fa","hints_en"];

// Export cases → CSV
r.get("/cases-export.csv", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const rows = db.prepare("SELECT * FROM cases WHERE active=1 ORDER BY id").all()
    .map((row) => { const d = JSON.parse(row.data_json); return { ...d, difficulty: row.difficulty }; });
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", "attachment; filename=cases.csv");
  res.send(toCSV(rows, CASE_COLS));
});

// Import cases from CSV (bulk create)
r.post("/cases-import", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const { csv } = req.body || {};
  if (!csv) return res.status(400).json({ error: "no csv" });
  let rows;
  try { rows = parseCSV(csv); } catch { return res.status(400).json({ error: "invalid csv" }); }
  const ins = db.prepare("INSERT INTO cases (version,difficulty,checklist_id,data_json) VALUES (1,?,1,?)");
  let count = 0;
  const tx = db.transaction(() => {
    for (const row of rows) {
      if (!row.title_en && !row.title_fa) continue;
      const { difficulty = "medium", age, ...rest } = row;
      const data = { ...rest, age: +age || 0,
        vitals: { bp: "120/80", hr: "75", rr: "16", temp: "37", spo2: "98%" }, images: [] };
      ins.run(difficulty, JSON.stringify(data));
      count++;
    }
  });
  tx();
  res.json({ ok: true, imported: count });
});

// Export flashcards → CSV (options as "|"-separated)
r.get("/flashcards-export.csv", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const rows = db.prepare("SELECT * FROM flashcards WHERE active=1 ORDER BY id").all()
    .filter((row) => { try { return JSON.parse(row.data_json).track !== "learn"; } catch { return true; } })
    .map((row) => {
    const d = JSON.parse(row.data_json);
    const correct = (d.options || []).find((o) => o.correct) || {};
    return {
      title_fa: d.title_fa, title_en: d.title_en, category_fa: d.category_fa, category_en: d.category_en,
      difficulty: row.difficulty, questionType: d.questionType || "image", answerMode: d.answerMode || "choice",
      questionText_fa: d.questionText_fa || "", questionText_en: d.questionText_en || "",
      correct_fa: correct.fa || "", correct_en: correct.en || "",
      options_fa: (d.options || []).map((o) => o.fa).join(" | "),
      options_en: (d.options || []).map((o) => o.en).join(" | "),
      hints_fa: (d.hints_fa || []).join(" | "), hints_en: (d.hints_en || []).join(" | "),
    };
  });
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", "attachment; filename=flashcards.csv");
  res.send(toCSV(rows, CARD_COLS));
});

// Import flashcards from CSV
r.post("/flashcards-import", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const { csv } = req.body || {};
  if (!csv) return res.status(400).json({ error: "no csv" });
  let rows;
  try { rows = parseCSV(csv); } catch { return res.status(400).json({ error: "invalid csv" }); }
  const ins = db.prepare("INSERT INTO flashcards (version,difficulty,data_json) VALUES (1,?,?)");
  let count = 0;
  const tx = db.transaction(() => {
    for (const row of rows) {
      if (!row.title_en && !row.title_fa) continue;
      const fa = (row.options_fa || "").split("|").map((s) => s.trim()).filter(Boolean);
      const en = (row.options_en || "").split("|").map((s) => s.trim()).filter(Boolean);
      const n = Math.max(fa.length, en.length);
      const options = [];
      for (let i = 0; i < n; i++) {
        const of = fa[i] || en[i] || "", oe = en[i] || fa[i] || "";
        options.push({ fa: of, en: oe,
          correct: (row.correct_fa && of === row.correct_fa) || (row.correct_en && oe === row.correct_en) });
      }
      if (options.length && !options.some((o) => o.correct)) options[0].correct = true;
      const data = {
        track: "uni",
        title_fa: row.title_fa, title_en: row.title_en,
        category_fa: row.category_fa, category_en: row.category_en,
        questionType: row.questionType || "image", answerMode: row.answerMode || "choice",
        questionText_fa: row.questionText_fa || "", questionText_en: row.questionText_en || "",
        color: "#bcd7f0", imageUrl: "", options,
        hints_fa: (row.hints_fa || "").split("|").map((s) => s.trim()).filter(Boolean),
        hints_en: (row.hints_en || "").split("|").map((s) => s.trim()).filter(Boolean),
      };
      ins.run(row.difficulty || "medium", JSON.stringify(data));
      count++;
    }
  });
  tx();
  res.json({ ok: true, imported: count });
});

/* ---------------- CUSTOM CATALOGS (teacher/admin) ---------------- */
r.get("/catalogs", authRequired, (req, res) => {
  const rows = db.prepare("SELECT * FROM catalogs ORDER BY id DESC").all();
  res.json(rows.map((c) => ({ id: c.id, name_fa: c.name_fa, name_en: c.name_en, items: JSON.parse(c.items_json || "[]") })));
});
r.post("/catalogs", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const { name_fa, name_en, items = [] } = req.body || {};
  const info = db.prepare("INSERT INTO catalogs (name_fa,name_en,items_json,owner_id) VALUES (?,?,?,?)")
    .run(name_fa, name_en, JSON.stringify(items), req.user.id);
  res.json({ id: info.lastInsertRowid });
});
r.put("/catalogs/:id", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const { name_fa, name_en, items = [] } = req.body || {};
  db.prepare("UPDATE catalogs SET name_fa=?,name_en=?,items_json=? WHERE id=?")
    .run(name_fa, name_en, JSON.stringify(items), req.params.id);
  res.json({ ok: true });
});
r.delete("/catalogs/:id", authRequired, requireRole("teacher", "admin"), (req, res) => {
  db.prepare("DELETE FROM catalogs WHERE id=?").run(req.params.id);
  res.json({ ok: true });
});

/* ---------------- CHECKLISTS ---------------- */
r.get("/checklists", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const rows = db.prepare("SELECT * FROM checklists ORDER BY id").all();
  res.json(rows.map((row) => ({ id: row.id, name_fa: row.name_fa, name_en: row.name_en, items: JSON.parse(row.items_json) })));
});
// Scoring sections + the internal-medicine complete-history template (so the
// admin checklist editor can label items by section and one-click insert the
// full internal history form). Deterministic, no cost.
r.get("/checklists-meta", authRequired, requireRole("teacher", "admin"), async (req, res) => {
  const { SECTIONS, HISTORY_FORMS, buildHistoryItems, buildInternalHistoryItems } = await import("../lib/history-sections.js");
  // forms: [{ key, fa, en, items:[...] }] so the editor can one-click insert any
  // specialty history form; internalHistory kept for backward-compat.
  const forms = HISTORY_FORMS.map((f) => ({ key: f.key, fa: f.fa, en: f.en, items: buildHistoryItems(f.key) }));
  res.json({ sections: SECTIONS, forms, internalHistory: buildInternalHistoryItems() });
});
r.put("/checklists/:id", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const { name_fa, name_en, items } = req.body || {};
  db.prepare("UPDATE checklists SET name_fa=?,name_en=?,items_json=? WHERE id=?")
    .run(name_fa, name_en, JSON.stringify(items || []), req.params.id);
  persistNow();
  res.json({ ok: true });
});
r.post("/checklists", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const { name_fa, name_en, items } = req.body || {};
  const info = db.prepare("INSERT INTO checklists (name_fa,name_en,items_json) VALUES (?,?,?)")
    .run(name_fa || "چک‌لیست جدید", name_en || "New checklist", JSON.stringify(items || []));
  persistNow();
  res.json({ id: info.lastInsertRowid });
});
r.delete("/checklists/:id", authRequired, requireRole("teacher", "admin"), (req, res) => {
  db.prepare("DELETE FROM checklists WHERE id=?").run(req.params.id);
  persistNow();
  res.json({ ok: true });
});

/* ---------------- USERS ---------------- */

function currentUniversityId(user) {
  if (!user?.id) return null;
  try { return db.prepare("SELECT university_id FROM users WHERE id=?").get(user.id)?.university_id || null; }
  catch { return null; }
}
function studentByNo(sno) {
  const sn = String(sno || "").trim();
  if (!sn) return null;
  return db.prepare("SELECT id, username, student_no, name_fa, name_en, university_id FROM users WHERE (student_no=? OR username=?) AND role='student'").get(sn, sn) || null;
}
function publicExistingStudent(u) { return u ? { id: u.id, username: u.username, student_no: u.student_no, name_fa: u.name_fa, name_en: u.name_en, university_id: u.university_id } : null; }

r.get("/users", authRequired, requireRole("teacher", "admin"), (req, res) => {
  let rows = db.prepare("SELECT id,username,student_no,name_fa,name_en,role,status,university_id FROM users ORDER BY id").all();
  if (req.user.role === "teacher") {
    const uni = currentUniversityId(req.user);
    rows = rows.filter((u) => u.university_id === uni && (u.role === "student" || u.role === "teacher"));
  }
  // Optional ?role= filter (used by the student search box in exams/classes).
  if (req.query.role) rows = rows.filter((u) => u.role === req.query.role);
  // attach assigned case ids for students
  const asg = db.prepare("SELECT case_id FROM exam_assignments WHERE user_id=? AND active=1");
  res.json(rows.map((u) => u.role === "student"
    ? { ...u, caseIds: asg.all(u.id).map((a) => a.case_id) }
    : u));
});

/* ---------------- EXAM ASSIGNMENTS ---------------- */
// List assignments for one student
r.get("/assignments/:userId", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const rows = db.prepare(
    `SELECT ea.*, c.data_json FROM exam_assignments ea
       LEFT JOIN cases c ON c.id = ea.case_id
     WHERE ea.user_id=? AND ea.active=1`
  ).all(req.params.userId);
  res.json(rows.map((a) => {
    const cd = a.data_json ? JSON.parse(a.data_json) : {};
    return { id: a.id, case_id: a.case_id, max_attempts: a.max_attempts,
             title_fa: cd.title_fa, title_en: cd.title_en };
  }));
});
// Replace the full set of a student's assignments (case IDs)
r.put("/assignments/:userId", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const { caseIds = [], maxAttempts = 1 } = req.body || {};
  const uid = req.params.userId;
  const tx = db.transaction(() => {
    db.prepare("UPDATE exam_assignments SET active=0 WHERE user_id=?").run(uid);
    const up = db.prepare(
      `INSERT INTO exam_assignments (user_id,case_id,assigned_by,max_attempts,active)
       VALUES (?,?,?,?,1)
       ON CONFLICT(user_id,case_id) DO UPDATE SET active=1, max_attempts=excluded.max_attempts`
    );
    for (const cid of caseIds) up.run(uid, cid, req.user.id, maxAttempts);
  });
  tx();
  res.json({ ok: true });
});
// Create a user. For students, the student number is the username.
// Optionally assign the new student to one or more exams (case IDs) in one step.
r.post("/users", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const { studentNo, username, password, name_fa, name_en, role = "student", caseIds = [], maxAttempts = 1 } = req.body || {};
  const uname = role === "student" ? String(studentNo || username || "").trim() : String(username || "").trim();
  if (!uname) return res.status(400).json({ error: "username/student number required" });
  if (role === "student") {
    const exists = studentByNo(uname);
    if (exists) return res.status(409).json({ error: "student_no_exists", message_fa: "این شماره دانشجویی قبلاً در سامانه وجود دارد.", existing: publicExistingStudent(exists) });
  }
  let university_id = req.body?.university_id ? Number(req.body.university_id) : null;
  if (req.user.role === "teacher") university_id = currentUniversityId(req.user);
  if ((role === "student" || role === "teacher") && !university_id) return res.status(400).json({ error: "university_required", message_fa: "برای استاد و دانشجو انتخاب دانشگاه الزامی است." });
  const pwd = password && String(password).trim() ? password : uname; // default password = student number
  const tx = db.transaction(() => {
    const info = db.prepare(
      "INSERT INTO users (username,password_hash,name_fa,name_en,student_no,role,status,university_id) VALUES (?,?,?,?,?,?, 'active',?)"
    ).run(uname, bcrypt.hashSync(pwd, 12), name_fa, name_en, role === "student" ? uname : null, role, university_id);
    const uid = info.lastInsertRowid;
    if (role === "student" && Array.isArray(caseIds)) {
      const ins = db.prepare(
        "INSERT OR IGNORE INTO exam_assignments (user_id,case_id,assigned_by,max_attempts) VALUES (?,?,?,?)"
      );
      for (const cid of caseIds) ins.run(uid, cid, req.user.id, maxAttempts);
    }
    return uid;
  });
  try {
    const id = tx();
    res.json({ id, username: uname, defaultPassword: pwd });
  } catch (e) { res.status(400).json({ error: "username / student number already exists" }); }
});

// Bulk-import students from a CSV/pasted text.
// Accepts columns: name (or first name), family (or last name), student_no (or studentNo/id).
// Header row optional. For each student: username = student number, password = student number.
r.post("/users/import", authRequired, requireRole("teacher", "admin"), (req, res) => {
  let { csv = "", university_id } = req.body || {};
  // a teacher's imported students are pinned to the teacher's own university.
  if (req.user.role === "teacher") {
    const me = db.prepare("SELECT university_id FROM users WHERE id=?").get(req.user.id);
    university_id = me?.university_id || university_id || null;
  }
  const lines = String(csv).split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  if (!lines.length) return res.status(400).json({ error: "empty" });

  // Detect and skip a header row if present.
  const headerRe = /(name|نام|family|خانوادگ|student|شماره|no|id)/i;
  const first = lines[0].split(/[,;\t]/).map((s) => s.trim().toLowerCase());
  const hasHeader = first.some((c) => headerRe.test(c));
  const dataLines = hasHeader ? lines.slice(1) : lines;

  const insUser = db.prepare(
    "INSERT INTO users (username,password_hash,name_fa,name_en,student_no,role,status,university_id) VALUES (?,?,?,?,?, 'student','active', ?)"
  );
  const findByNo = db.prepare("SELECT id FROM users WHERE student_no=? OR username=?");

  let created = 0, skipped = 0;
  const errors = [], duplicates = [];
  const tx = db.transaction(() => {
    dataLines.forEach((line, i) => {
      const cols = line.split(/[,;\t]/).map((s) => s.trim());
      // Flexible: [name, family, student_no]  OR  [full name, student_no]  OR  [student_no]
      let name = "", family = "", sno = "";
      if (cols.length >= 3) { [name, family, sno] = cols; }
      else if (cols.length === 2) { [name, sno] = cols; }
      else { sno = cols[0]; }
      sno = String(sno || "").trim();
      if (!sno) { errors.push(`${t_line(i, hasHeader)}: ${req_no_sno()}`); skipped++; return; }
      const fullName = [name, family].filter(Boolean).join(" ").trim() || sno;
      const existing = findByNo.get(sno, sno);
      if (existing) { duplicates.push({ student_no: sno, id: existing.id }); skipped++; return; } // already exists
      try {
        insUser.run(sno, bcrypt.hashSync(sno, 12), fullName, fullName, sno, university_id || null);
        created++;
      } catch (e) { errors.push(`${sno}: ${e.message}`); skipped++; }
    });
  });
  try { tx(); } catch (e) { return res.status(400).json({ error: e.message }); }
  res.json({ created, skipped, total: dataLines.length, duplicates, errors: errors.slice(0, 20) });
});
function t_line(i, hasHeader) { return `line ${i + 1 + (hasHeader ? 1 : 0)}`; }
function req_no_sno() { return "missing student number"; }

// Reset a user's password (admin/teacher)
r.put("/users/:id/password", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const { password } = req.body || {};
  if (!password) return res.status(400).json({ error: "password required" });
  db.prepare("UPDATE users SET password_hash=? WHERE id=?").run(bcrypt.hashSync(password, 12), req.params.id);
  res.json({ ok: true });
});
r.put("/users/:id/status", authRequired, requireRole("teacher", "admin"), (req, res) => {
  db.prepare("UPDATE users SET status=? WHERE id=?").run(req.body.status, req.params.id);
  res.json({ ok: true });
});

/* ---------------- PROMPTS (admin only) ---------------- */
r.get("/prompts", authRequired, requireRole("admin"), (req, res) => {
  const rows = db.prepare("SELECT * FROM prompts").all();
  const out = {}; rows.forEach((p) => (out[p.key] = p.value));
  res.json(out);
});
r.put("/prompts", authRequired, requireRole("admin"), (req, res) => {
  const up = db.prepare("INSERT INTO prompts (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value");
  for (const [k, v] of Object.entries(req.body || {})) up.run(k, String(v ?? ""));
  persistNow();
  res.json({ ok: true });
});

/* ---------------- SETTINGS ---------------- */
export function getSetting(key, fallback) {
  const row = db.prepare("SELECT value FROM settings WHERE key=?").get(key);
  return row ? JSON.parse(row.value) : fallback;
}
export function setSetting(key, obj) {
  db.prepare("INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value")
    .run(key, JSON.stringify(obj));
  persistNow();
  return obj;
}
// keys that hold provider/API-key config → admin-only (never leak the key)
const ADMIN_ONLY_SETTINGS = new Set(["ai", "blog_image_ai"]);
r.get("/settings/:key", authRequired, (req, res) => {
  const key = req.params.key;
  // AI/provider settings are ADMIN-ONLY (contain the API key / provider config)
  if (ADMIN_ONLY_SETTINGS.has(key) && req.user.role !== "admin")
    return res.status(403).json({ error: "admin only" });
  if (key === "vp_grading") {
    if (!["teacher", "admin"].includes(req.user.role)) return res.status(403).json({ error: "forbidden" });
    return res.json(normalizeRubric(getSetting("vp_grading", null)));
  }
  const s = getSetting(key, {});
  res.json(s);
});
r.put("/settings/:key", authRequired, (req, res) => {
  const key = req.params.key;
  if (ADMIN_ONLY_SETTINGS.has(key)) {
    // AI / image-provider configuration: admin only
    if (req.user.role !== "admin") return res.status(403).json({ error: "admin only" });
  } else {
    // other settings (exam, etc.): teacher or admin
    if (!["teacher", "admin"].includes(req.user.role)) return res.status(403).json({ error: "forbidden" });
  }
  const body = key === "vp_grading" ? normalizeRubric(req.body || {}) : (req.body || {});
  db.prepare("INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value")
    .run(key, JSON.stringify(body));
  res.json({ ok: true, ...(key === "vp_grading" ? body : {}) });
});

export default r;
