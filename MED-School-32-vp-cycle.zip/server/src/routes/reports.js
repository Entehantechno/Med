/* ================================================================
   reports.js — Research analytics, exam results & CSV export.
   ================================================================ */
import { Router } from "express";
import { db, persistNow } from "../db.js";
import { authRequired, requireRole } from "../lib/auth.js";
import { toCSV } from "../lib/csv.js";

const r = Router();

const attemptsQuery = `
  SELECT a.*, u.name_fa AS student_fa, u.name_en AS student_en, u.student_no AS student_no,
         c.data_json AS case_json,
         e.title_fa AS exam_fa, e.title_en AS exam_en,
         e.study_id AS exam_study_id, cl.study_id AS class_study_id
  FROM attempts a
  LEFT JOIN users u ON u.id = a.user_id
  LEFT JOIN cases c ON c.id = a.case_id
  LEFT JOIN exams e ON e.id = a.exam_id
  LEFT JOIN classes cl ON cl.id = a.class_id
  ORDER BY a.created_at DESC`;

function mapRow(a) {
  let caseTitleFa = "فلش‌کارت", caseTitleEn = "Flashcards";
  if (a.case_json) {
    try {
      const cd = JSON.parse(a.case_json);
      caseTitleFa = cd.title_fa; caseTitleEn = cd.title_en;
    } catch { /* corrupt case payload must not 500 the student's home */ }
  }
  return {
    id: a.id, user_id: a.user_id, type: a.type, score: a.score,
    turns: a.turns, tests: a.tests, imaging_count: a.imaging_count, ddx_count: a.ddx_count,
    hints: a.hints, total_questions: a.total_questions, correct_count: a.correct_count,
    wrong_count: a.wrong_count, duration_sec: a.duration_sec, lang: a.lang,
    content_version: a.content_version, created_at: a.created_at,
    student_fa: a.student_fa, student_en: a.student_en, student_no: a.student_no,
    case_fa: caseTitleFa, case_en: caseTitleEn,
    exam_id: a.exam_id, exam_fa: a.exam_fa, exam_en: a.exam_en,
    study_id: a.exam_study_id || a.class_study_id || null,
    research: !!(a.exam_study_id || a.class_study_id),
    // teacher review of the AI score
    teacher_status: a.teacher_status || null, teacher_score: a.teacher_score ?? null,
    teacher_feedback: a.teacher_feedback || "", reviewed_at: a.reviewed_at || null,
    // the score that "counts": teacher override when adjusted, else AI score
    final_score: (a.teacher_status === "adjusted" && a.teacher_score != null) ? a.teacher_score
               : (a.teacher_status === "rejected" ? 0 : a.score),
  };
}
function rowsWithNames() {
  return db.prepare(attemptsQuery).all().map(mapRow);
}
function filterRows(rows, q = {}) {
  let out = rows;
  if (q.type) out = out.filter((a) => a.type === q.type);
  if (q.examId && q.examId !== "all") {
    if (q.examId === "none") out = out.filter((a) => !a.exam_id);
    else out = out.filter((a) => String(a.exam_id) === String(q.examId));
  }
  if (q.research === "1" || q.research === "true") out = out.filter((a) => a.research);
  return out;
}
const J = (s, d) => { try { return s ? JSON.parse(s) : d; } catch { return d; } };

/* Dashboard summary */
r.get("/summary", authRequired, requireRole("teacher", "admin"), (req, res) => {
  try {
  const students = db.prepare("SELECT COUNT(*) n FROM users WHERE role='student'").get().n;
  const cases = db.prepare("SELECT COUNT(*) n FROM cases WHERE active=1").get().n;
  const cards = db.prepare("SELECT COUNT(*) n FROM flashcards WHERE active=1").get().n;
  const attempts = db.prepare("SELECT COUNT(*) n FROM attempts").get().n;
  const exams = db.prepare("SELECT COUNT(*) n FROM exams WHERE active=1").get().n;
  const avg = db.prepare("SELECT AVG(score) a FROM attempts").get().a || 0;
  const recent = rowsWithNames().slice(0, 6);
  res.json({ students, cases, cards, attempts, exams, avgScore: Math.round(avg), recent });
  } catch (e) {
    res.status(500).json({ error: "summary_failed", stage: "boot", message: String(e.message || e).slice(0, 200) });
  }
});

/* Full attempts list (optionally filtered by type: vp | flash) */
r.get("/attempts", authRequired, requireRole("teacher", "admin"), (req, res) => {
  try { res.json(filterRows(rowsWithNames(), req.query)); }
  catch (e) { res.status(500).json({ error: "attempts_failed", stage: "boot", message: String(e.message || e).slice(0, 200) }); }
});

/* CSV export (optionally by type) */
r.get("/export.csv", authRequired, requireRole("teacher", "admin"), (req, res) => {
  let rows = filterRows(rowsWithNames(), req.query);
  const flat = rows.map((a) => ({
    id: a.id, student: a.student_en, student_no: a.student_no,
    exam: a.exam_en || "-", case: a.case_en, type: a.type, score: a.score,
    turns: a.turns, tests: a.tests, imaging: a.imaging_count, ddx: a.ddx_count,
    total_questions: a.total_questions, correct: a.correct_count, wrong: a.wrong_count,
    hints: a.hints, duration_sec: a.duration_sec, lang: a.lang,
    content_version: a.content_version, created_at: a.created_at,
  }));
  const cols = ["id","student","student_no","exam","case","type","score","turns","tests","imaging","ddx",
    "total_questions","correct","wrong","hints","duration_sec","lang","content_version","created_at"];
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  const suffix = req.query.examId && req.query.examId !== "all" ? `exam_${req.query.examId}` : (req.query.type || "all");
  res.setHeader("Content-Disposition", `attachment; filename=results_${suffix}.csv`);
  res.send(toCSV(flat, cols));
});

/* Student's own progress (detailed) */
r.get("/my", authRequired, (req, res) => {
  try {
  const rows = db.prepare(
    `SELECT a.*, c.data_json AS case_json, e.title_fa AS exam_fa, e.title_en AS exam_en
       FROM attempts a
       LEFT JOIN cases c ON c.id = a.case_id
       LEFT JOIN exams e ON e.id = a.exam_id
     WHERE a.user_id=? ORDER BY a.created_at DESC`
  ).all(req.user.id).map(mapRow);
  res.json(rows);
  } catch (e) {
    res.status(500).json({ error: "progress_load_failed", stage: "boot", message: String(e.message || e).slice(0, 200) });
  }
});

/* ---- Single attempt: full log (transcript + evaluation) for teacher review ---- */
r.get("/attempts/:id", authRequired, requireRole("teacher", "admin"), (req, res) => {
  try {
  const a = db.prepare(`
    SELECT a.*, u.name_fa AS student_fa, u.name_en AS student_en, u.student_no,
           c.data_json AS case_json, e.title_fa AS exam_fa, e.title_en AS exam_en
      FROM attempts a
      LEFT JOIN users u ON u.id=a.user_id
      LEFT JOIN cases c ON c.id=a.case_id
      LEFT JOIN exams e ON e.id=a.exam_id
     WHERE a.id=?`).get(req.params.id);
  if (!a) return res.status(404).json({ error: "not found" });
  const base = mapRow(a);
  res.json({
    ...base,
    transcript: J(a.transcript_json, {}),   // { messages, tests, imaging, ddx, finalDx }
    eval: J(a.eval_json, {}),                // { score, score10, results[], strengths[], ... }
    reviewed_by: a.reviewed_by || null,
  });
  } catch (e) {
    res.status(500).json({ error: "attempt_load_failed", stage: "boot", message: String(e.message || e).slice(0, 200) });
  }
});

/* ---- Delete a report/attempt (teacher/admin) ---- */
r.delete("/attempts/:id", authRequired, requireRole("teacher", "admin"), (req, res) => {
  const a = db.prepare("SELECT id FROM attempts WHERE id=?").get(req.params.id);
  if (!a) return res.status(404).json({ error: "not found" });
  db.prepare("DELETE FROM attempts WHERE id=?").run(req.params.id);
  persistNow();
  res.json({ ok: true });
});

/* ---- Teacher reviews the AI score: approve | adjust (with score) | reject + feedback ---- */
r.put("/attempts/:id/review", authRequired, requireRole("teacher", "admin"), (req, res) => {
  try {
  const a = db.prepare("SELECT * FROM attempts WHERE id=?").get(req.params.id);
  if (!a) return res.status(404).json({ error: "not found" });
  const b = req.body || {};
  const status = ["approved", "adjusted", "rejected"].includes(b.status) ? b.status : "approved";
  let teacherScore = null;
  if (status === "adjusted") teacherScore = Math.max(0, Math.min(100, parseInt(b.teacher_score, 10) || 0));
  const feedback = String(b.teacher_feedback || "").slice(0, 4000);
  db.prepare(`UPDATE attempts SET teacher_status=?, teacher_score=?, teacher_feedback=?,
    reviewed_by=?, reviewed_at=datetime('now') WHERE id=?`)
    .run(status, teacherScore, feedback, req.user.id, a.id);
  persistNow();
  res.json({ ok: true, status, teacher_score: teacherScore });
  } catch (e) {
    res.status(500).json({ error: "review_failed", stage: "boot", message: String(e.message || e).slice(0, 200) });
  }
});

/* ---- Per-student progress series for radar + line charts ----
   Radar: average score per checklist criterion across the student's VP attempts.
   Line:  score over time. Teacher/admin can query any student; a learner/student
   can only query themselves. */
r.get("/progress/:userId", authRequired, (req, res) => {
  const uid = parseInt(req.params.userId, 10);
  const isStaff = ["teacher", "admin", "content_manager", "support"].includes(req.user.role);
  if (!isStaff && req.user.id !== uid) return res.status(403).json({ error: "forbidden" });
  const rows = db.prepare(
    "SELECT id, score, eval_json, teacher_status, teacher_score, created_at, type FROM attempts WHERE user_id=? AND type='vp' ORDER BY created_at ASC"
  ).all(uid);
  const J = (s) => { try { return JSON.parse(s); } catch { return null; } };
  // line series: the score that counts, over time
  const line = rows.map((a) => ({
    at: a.created_at,
    score: (a.teacher_status === "adjusted" && a.teacher_score != null) ? a.teacher_score
         : (a.teacher_status === "rejected" ? 0 : a.score),
    aiScore: a.score,
  }));
  // radar: aggregate per-criterion pass-rate across attempts
  const agg = {};   // label -> { done, total }
  for (const a of rows) {
    const ev = J(a.eval_json); if (!ev || !Array.isArray(ev.results)) continue;
    for (const it of ev.results) {
      const key = it.label || it.id;
      if (!key) continue;
      agg[key] = agg[key] || { done: 0, total: 0 };
      agg[key].total += 1;
      if (it.done) agg[key].done += 1;
    }
  }
  const radar = Object.entries(agg).map(([label, v]) => ({
    label, value: v.total ? Math.round((v.done / v.total) * 100) : 0,
  }));
  res.json({ line, radar, attempts: rows.length });
});

/* A specific student's full record (teacher/admin) — for the report card */
r.get("/student/:userId", authRequired, requireRole("teacher", "admin"), (req, res) => {
  try {
  const u = db.prepare("SELECT id,name_fa,name_en,student_no,role FROM users WHERE id=?").get(req.params.userId);
  if (!u) return res.status(404).json({ error: "not found" });
  const rows = db.prepare(
    `SELECT a.*, c.data_json AS case_json, e.title_fa AS exam_fa, e.title_en AS exam_en
       FROM attempts a
       LEFT JOIN cases c ON c.id = a.case_id
       LEFT JOIN exams e ON e.id = a.exam_id
     WHERE a.user_id=? ORDER BY a.created_at ASC`
  ).all(req.params.userId).map((a) => ({
    ...mapRow(a),
    transcript: J(a.transcript_json, {}),
    eval: J(a.eval_json, {}),
  }));
  res.json({ student: u, attempts: rows });
  } catch (e) {
    res.status(500).json({ error: "student_report_failed", stage: "boot", message: String(e.message || e).slice(0, 200) });
  }
});

export default r;
