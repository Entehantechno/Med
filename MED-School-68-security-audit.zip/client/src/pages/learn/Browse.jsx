import { useEffect, useMemo, useState } from "react";
import { useApp } from "../../context.jsx";
import { api } from "../../api.js";
import Icon from "../../components/Icon.jsx";
import { Spinner, Modal } from "../../components/UI.jsx";
import { TYPE_MAP, MicroLesson } from "./QuestionTypes.jsx";
import Emphasis from "../../components/Emphasis.jsx";

/* Learner-facing question browser.
 *
 * The learning path decides what you SHOULD study next; this page is for when
 * you already know what you want — "headache questions from 1404", "every
 * negative-stem item in Neurology". It exposes the same classification the
 * admin has, with the two rules faceted search is expected to follow:
 * OR inside one facet, AND across facets.
 *
 * Counts next to each option come from the server, recomputed against the
 * other active filters, so the numbers stay honest as you drill down and an
 * option that would return nothing is never offered.
 */

const FACETS = [
  { key: "subject", label: "examSubjectLabel" },
  { key: "examType", label: "examTypeLabel" },
  { key: "chapter", label: "chapterLabel", dependsOn: "subject" },
  { key: "concept", label: "conceptLabel", dependsOn: "chapter" },
  { key: "year", label: "examYearLabel" },
  { key: "month", label: "examMonthLabel" },
  { key: "sitting", label: "sittingLabel", localize: true },
  { key: "scope", label: "scopeLabel" },
  { key: "exam", label: "examSittingLabel" },
  { key: "style", label: "styleLabel", localize: true },
  { key: "difficulty", label: "difficulty", localize: true },
];

const EMPTY = { subject: "", examType: "", chapter: "", concept: "", year: "", month: "", sitting: "", scope: "", exam: "", style: "", difficulty: "", q: "" };

export default function Browse() {
  const { t, lang } = useApp();
  const [fil, setFil] = useState(EMPTY);
  const [term, setTerm] = useState("");
  const [sort, setSort] = useState("newest_exam");
  const [page, setPage] = useState(1);
  const [data, setData] = useState(null);
  const [busy, setBusy] = useState(false);
  const [open, setOpen] = useState(null);      // card being previewed
  const [showFil, setShowFil] = useState(false);

  // Localised label for the machine values the API returns.
  const vLabel = (facet, v) => {
    const map = {
      sitting: { main: t("sittingMain"), midterm: t("sittingMid") },
      style: { case: t("styleCase"), recall: t("styleRecall"), negative: t("styleNegative"), image: t("styleImage") },
      difficulty: { easy: t("easy"), medium: t("medium"), hard: t("hard") },
    };
    return map[facet]?.[v] || v;
  };

  const qs = useMemo(() => {
    const p = new URLSearchParams({ lang, sort, page: String(page), per: "20" });
    for (const [k, v] of Object.entries(fil)) if (v) p.set(k, v);
    if (term.trim()) p.set("q", term.trim());
    return p.toString();
  }, [fil, term, sort, page, lang]);

  useEffect(() => {
    let alive = true;
    setBusy(true);
    api.get(`/learn/browse?${qs}`)
      .then((d) => { if (alive) setData(d); })
      .catch(() => { if (alive) setData({ cards: [], total: 0, facets: {} }); })
      .finally(() => { if (alive) setBusy(false); });
    return () => { alive = false; };
  }, [qs]);

  // Changing a parent facet clears its children, otherwise you can end up with
  // "subject = Neurology, chapter = <a Cardiology chapter>" and zero results.
  const setF = (k, v) => {
    setPage(1);
    setFil((s) => {
      const next = { ...s, [k]: v };
      if (k === "subject") { next.chapter = ""; next.concept = ""; }
      if (k === "chapter") next.concept = "";
      return next;
    });
  };

  const active = Object.entries(fil).filter(([, v]) => v).length + (term.trim() ? 1 : 0);
  const facets = data?.facets || {};
  const total = data?.total || 0;
  const pages = Math.max(1, Math.ceil(total / 20));

  return (
    <div className="browse-page">
      <div className="browse-head">
        <div>
          <h2 className="h2"><Icon name="search" size={18} /> {t("browseTitle")}</h2>
          <p className="muted small mb0">{t("browseDesc")}</p>
        </div>
        <button className={`btn btn-sm ${showFil || active ? "btn-primary" : "btn-ghost"}`} onClick={() => setShowFil((v) => !v)}>
          <Icon name="settings" size={14} /> {t("browseFilters")}{active ? ` (${active})` : ""}
        </button>
      </div>

      <div className="browse-search">
        <Icon name="search" size={15} />
        <input
          value={term}
          onChange={(e) => { setTerm(e.target.value); setPage(1); }}
          placeholder={t("browseSearch")}
          aria-label={t("browseSearch")}
        />
        <select value={sort} onChange={(e) => setSort(e.target.value)} aria-label={t("sortByLabel")}>
          <option value="newest_exam">{t("sort_newest_exam")}</option>
          <option value="oldest_exam">{t("sort_oldest_exam")}</option>
          <option value="last_modified">{t("sort_last_modified")}</option>
        </select>
      </div>

      {showFil && (
        <div className="card browse-filters">
          <div className="browse-filter-grid">
            {FACETS.map((f) => {
              let opts = facets[f.key] || [];
              // hierarchical facets: only offer children of the chosen parent
              if (f.key === "chapter" && fil.subject) opts = opts.filter((o) => o.subject === fil.subject);
              if (f.key === "concept") {
                if (fil.subject) opts = opts.filter((o) => o.subject === fil.subject);
                if (fil.chapter) opts = opts.filter((o) => o.chapter === fil.chapter);
              }
              if (!opts.length) return null;
              return (
                <label className="field" key={f.key}>
                  <span>{t(f.label)}</span>
                  <select value={fil[f.key]} onChange={(e) => setF(f.key, e.target.value)}>
                    <option value="">{t("anyValue")}</option>
                    {opts.map((o) => (
                      <option key={o.value} value={o.value}>
                        {(f.localize ? vLabel(f.key, o.value) : o.label)} ({o.count})
                      </option>
                    ))}
                  </select>
                </label>
              );
            })}
          </div>
          {active > 0 && (
            <button className="btn btn-ghost btn-sm" onClick={() => { setFil(EMPTY); setTerm(""); setPage(1); }}>
              <Icon name="close" size={13} /> {t("browseReset")}
            </button>
          )}
        </div>
      )}

      {data?.premiumRequired && (
        <div className="card browse-premium-gate">
          <div style={{ fontWeight: 800 }}>{t("browsePremiumTitle")}</div>
          <p className="muted small">{t("browsePremiumBody")}</p>
          <button className="btn btn-accent" type="button" onClick={() => window.dispatchEvent(new CustomEvent("medlab-go", { detail: "premium" }))}>
            <Icon name="crown" size={15} /> {t("browseGoPremium")}
          </button>
        </div>
      )}
      <div className="browse-count muted small">
        {busy ? <Spinner /> : t("browseResults").replace("{n}", total)}
      </div>

      {!busy && !total && <div className="card muted center pad24" role="status">{t("browseEmpty")}</div>}

      <ul className="browse-list">
        {(data?.cards || []).map((c) => (
          <li key={c.id} className="browse-item card">
            <button className="browse-item-main" onClick={() => setOpen(c.id)}>
              <p className="browse-q">{c.q}</p>
              <div className="browse-meta">
                {c.chapter && <span className="chip">{c.chapter}</span>}
                {c.concept && <span className="chip chip-soft">{c.concept}</span>}
                {c.examType && <span className="chip chip-soft">{c.examType === "دستیاری" ? t("examTypeResidency") : t("examTypePreint")}</span>}
                {c.exam && <span className="chip chip-exam" dir="auto">{c.exam}</span>}
                {c.keyless && <span className="chip" title={t("keylessTitle")}>🔑 {t("keylessBadge")}</span>}
                {c.style && <span className="chip chip-soft">{vLabel("style", c.style)}</span>}
                {c.premium && <span className="chip chip-premium" title={t("premiumOnlyShort")}><Icon name="crown" size={11} /> {t("premiumShort")}</span>}
                {c.attempted && <span className="chip chip-done"><Icon name="check" size={11} /></span>}
              </div>
            </button>
          </li>
        ))}
      </ul>

      {pages > 1 && (
        <div className="browse-pager">
          <button className="btn btn-ghost btn-sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)} aria-label={t("prev")}>‹</button>
          <span className="muted small" dir="ltr" aria-live="polite">{page} / {pages}</span>
          <button className="btn btn-ghost btn-sm" disabled={page >= pages} onClick={() => setPage((p) => p + 1)} aria-label={t("next")}>›</button>
        </div>
      )}

      {open != null && <BrowseCard id={open} onClose={() => setOpen(null)} />}
    </div>
  );
}

/* Preview one question with its answer key and micro-lesson.
 *
 * Deliberately read-only: browsing is for looking things up, so answering here
 * must not consume hearts, break a streak or disturb the SRS schedule that the
 * learning path depends on. The learner picks an option, reveals the answer,
 * and reads the same درسنامه they would see in a lesson — nothing is recorded.
 */
function BrowseCard({ id, onClose }) {
  const { t } = useApp();
  const [card, setCard] = useState(null);
  const [sel, setSel] = useState(null);
  const [checked, setChecked] = useState(false);
  useEffect(() => {
    setSel(null); setChecked(false);
    api.get(`/learn/browse/${id}`).then((d) => setCard(d.card)).catch(() => setCard(null));
  }, [id]);

  const Body = card ? (TYPE_MAP[card.type] || TYPE_MAP.mcq) : null;
  const keyless = !!(card.source_meta && (card.source_meta.keyless || card.source_meta.key_available === false));
  const canCheck = card && Body && !keyless && (Body.canCheck ? Body.canCheck({ sel }) : sel != null);

  return (
    <Modal onClose={onClose} title={t("browseStudy")} wide>
      {!card ? <Spinner /> : (
        <div className="browse-preview">
          <p className="browse-preview-q">{card.q}</p>
          <Body card={card} checked={checked} sel={sel} setSel={setSel} isCorrect={checked && Body.judge?.(card, { sel })} />
          {keyless && (
            <div className="explain-box mt12" style={{ background: "rgba(213,160,27,.10)" }}>
              <b>🔑 {t("keylessTitle")}</b>
              <Emphasis as="p" text={t("keylessNotice")} />
            </div>
          )}
          {!checked && !keyless && (
            <button className="btn btn-primary mt12" disabled={!canCheck} onClick={() => setChecked(true)}>
              {t("checkAnswer") || "بررسی"}
            </button>
          )}
          {keyless && card.explain?.text && (
            <div className="explain-box mt12"><b>{t("answerKey")}</b><Emphasis as="p" text={card.explain.text} /></div>
          )}
          {checked && card.explain?.text && (
            <div className="explain-box mt12"><b>{t("answerKey")}</b><Emphasis as="p" text={card.explain.text} /></div>
          )}
          {checked && <MicroLesson micro={card.micro} defaultOpen />}
        </div>
      )}
    </Modal>
  );
}
