import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    environment: "node",
    include: ["test/**/*.test.js"],
    testTimeout: 20000,
    fileParallelism: false, // shared SQLite/app
    // The suite fires many requests from one "IP"; disable rate limiting by
    // default. The dedicated security test flips this env per-request to verify
    // the limiter actually engages.
    env: { DISABLE_RATE_LIMIT: "1" },
  },
});
