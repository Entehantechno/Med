/* Pre-internship (پره‌انترنی) national exam blueprint.
   Question budgets sourced from published Iranian pre-internship exam breakdowns
   (200 single-best-answer MCQs). Used to seed topics + a gamified learning path. */

export const TOPICS = [
  // --- Internal medicine sub-specialties (grouped under "internal") ---
  { slug: "gi",        name_fa: "گوارش",             name_en: "Gastroenterology", parent: "internal", budget: 8,  color: "#e0912e", icon: "stomach" },
  { slug: "pulmo",     name_fa: "ریه و مسمومیت",     name_en: "Pulmonology",      parent: "internal", budget: 10, color: "#2f7fd1", icon: "flask" },
  { slug: "nephro",    name_fa: "نفرولوژی",          name_en: "Nephrology",       parent: "internal", budget: 7,  color: "#2569b0", icon: "flask" },
  { slug: "heme",      name_fa: "خون و انکولوژی",     name_en: "Hematology-Oncology", parent: "internal", budget: 7, color: "#e0544f", icon: "flask" },
  { slug: "endo",      name_fa: "غدد",               name_en: "Endocrinology",    parent: "internal", budget: 5,  color: "#22a06b", icon: "flask" },
  { slug: "rheum",     name_fa: "روماتولوژی",         name_en: "Rheumatology",     parent: "internal", budget: 5,  color: "#6d5bd0", icon: "flask" },
  { slug: "cardio",    name_fa: "قلب و عروق",         name_en: "Cardiology",       parent: "internal", budget: 4,  color: "#e0568a", icon: "flask" },
  // --- Major clinical subjects ---
  { slug: "surgery",   name_fa: "جراحی",             name_en: "Surgery",          parent: "major", budget: 24, color: "#2f7fd1", icon: "check" },
  { slug: "peds",      name_fa: "کودکان",            name_en: "Pediatrics",       parent: "major", budget: 24, color: "#22a06b", icon: "patient" },
  { slug: "obgyn",     name_fa: "زنان و زایمان",      name_en: "Obstetrics & Gynecology", parent: "major", budget: 19, color: "#e0568a", icon: "patient" },
  // --- Minor subjects ---
  { slug: "path",      name_fa: "پاتولوژی",          name_en: "Pathology",        parent: "minor", budget: 9,  color: "#6d5bd0", icon: "brain" },
  { slug: "infect",    name_fa: "عفونی",             name_en: "Infectious Diseases", parent: "minor", budget: 9, color: "#e0912e", icon: "flask" },
  { slug: "neuro",     name_fa: "مغز و اعصاب",        name_en: "Neurology",        parent: "minor", budget: 8,  color: "#2569b0", icon: "brain" },
  { slug: "psych",     name_fa: "روانپزشکی",         name_en: "Psychiatry",       parent: "minor", budget: 7,  color: "#6d5bd0", icon: "brain" },
  { slug: "derm",      name_fa: "پوست",              name_en: "Dermatology",      parent: "minor", budget: 7,  color: "#e0a52e", icon: "patient" },
  { slug: "ortho",     name_fa: "ارتوپدی",           name_en: "Orthopedics",      parent: "minor", budget: 7,  color: "#22a06b", icon: "check" },
  { slug: "pharm",     name_fa: "فارماکولوژی",        name_en: "Pharmacology",     parent: "minor", budget: 7,  color: "#e0544f", icon: "flask" },
  { slug: "uro",       name_fa: "اورولوژی",          name_en: "Urology",          parent: "minor", budget: 6,  color: "#2f7fd1", icon: "patient" },
  { slug: "ophth",     name_fa: "چشم‌پزشکی",         name_en: "Ophthalmology",    parent: "minor", budget: 6,  color: "#2569b0", icon: "patient" },
  { slug: "ent",       name_fa: "گوش و حلق و بینی",   name_en: "ENT",              parent: "minor", budget: 6,  color: "#e0568a", icon: "patient" },
  { slug: "radio",     name_fa: "رادیولوژی",         name_en: "Radiology",        parent: "minor", budget: 6,  color: "#647184", icon: "image" },
  { slug: "stats",     name_fa: "آمار و اپیدمیولوژی", name_en: "Statistics & Epidemiology", parent: "minor", budget: 6, color: "#22a06b", icon: "chart" },
  { slug: "ethics",    name_fa: "اخلاق پزشکی",        name_en: "Medical Ethics",   parent: "minor", budget: 3,  color: "#6d5bd0", icon: "book" },
  // --- Floating (basic-science) subjects added since 1401 ---
  { slug: "genetics",  name_fa: "ژنتیک پزشکی",       name_en: "Medical Genetics", parent: "floating", budget: 5, color: "#e0a52e", icon: "brain" },
  { slug: "immuno",    name_fa: "ایمونولوژی",        name_en: "Immunology",       parent: "floating", budget: 8, color: "#e0544f", icon: "flask" },
  { slug: "nutrition", name_fa: "تغذیه",             name_en: "Nutrition",        parent: "floating", budget: 5, color: "#22a06b", icon: "flask" },
  { slug: "physics",   name_fa: "فیزیک پزشکی",       name_en: "Medical Physics",  parent: "floating", budget: 5, color: "#2f7fd1", icon: "chart" },
];

export const PARENTS = {
  internal: { name_fa: "دروس داخلی", name_en: "Internal Medicine" },
  major:    { name_fa: "دروس ماژور", name_en: "Major Subjects" },
  minor:    { name_fa: "دروس مینور", name_en: "Minor Subjects" },
  floating: { name_fa: "دروس شناور", name_en: "Floating Subjects" },
};

/* A pool of sample pre-internship style MCQ flashcards per topic.
   Each: { q_fa, q_en, options:[{fa,en,correct}], explain_fa, explain_en }.
   Kept concise but medically representative for demo/seed purposes. */
export const SAMPLE_QUESTIONS = {
  gi: [
    { q_fa: "شایع‌ترین علت خونریزی گوارشی فوقانی کدام است؟", q_en: "Most common cause of upper GI bleeding?",
      options: [["زخم پپتیک","Peptic ulcer disease",true],["واریس مری","Esophageal varices",false],["پارگی مالوری-وایس","Mallory-Weiss tear",false],["سرطان معده","Gastric cancer",false]],
      ex_fa: "زخم پپتیک شایع‌ترین علت خونریزی گوارشی فوقانی است.", ex_en: "PUD is the most common cause of upper GI bleeding.",
      // demo rich media: an image on the question + an answer-key (پاسخنامه) with a video embed
      media: { url: "/uploads/demo-melena-endoscopy.svg", kind: "image", caption_fa: "نمای آندوسکوپیک زخم پپتیک", caption_en: "Endoscopic view of a peptic ulcer" },
      explain: {
        text_fa: "زخم پپتیک شایع‌ترین علت است؛ ابتدا بیمار را تثبیت کنید (مایع/خون) و سپس آندوسکوپی انجام دهید.",
        text_en: "PUD is the most common cause; stabilize the patient first (fluids/blood), then perform endoscopy.",
        media: { url: "https://www.aparat.com/v/demoGIbleed", kind: "embed", caption_fa: "ویدیوی کوتاه: رویکرد به خونریزی گوارشی فوقانی", caption_en: "Short video: approach to upper GI bleeding" },
      } },
    { q_fa: "نشانگر سرولوژیک تشخیصی سلیاک کدام است؟", q_en: "Diagnostic serologic marker for celiac disease?",
      options: [["Anti-tTG IgA","Anti-tTG IgA",true],["ANA","ANA",false],["Anti-mitochondrial","Anti-mitochondrial Ab",false],["ASCA","ASCA",false]],
      ex_fa: "آنتی‌بادی ضد ترانس‌گلوتامیناز بافتی (IgA) اولین تست غربالگری است.", ex_en: "Anti-tTG IgA is the first-line screening test." },
    { q_fa: "درمان خط اول هلیکوباکتر پیلوری کدام است؟", q_en: "First-line therapy for H. pylori?",
      options: [["مهارکننده پمپ پروتون + دو آنتی‌بیوتیک","PPI + two antibiotics",true],["فقط PPI","PPI alone",false],["فقط مترونیدازول","Metronidazole alone",false],["سوکرالفات","Sucralfate",false]],
      ex_fa: "رژیم سه‌گانه: PPI + کلاریترومایسین + آموکسی‌سیلین.", ex_en: "Triple therapy: PPI + clarithromycin + amoxicillin." },
  ],
  cardio: [
    { q_fa: "اولین اقدام در STEMI حاد کدام است؟", q_en: "First step in acute STEMI?",
      options: [["آسپیرین + reperfusion فوری","Aspirin + urgent reperfusion",true],["فقط استراحت","Rest only",false],["وارفارین","Warfarin",false],["دیورتیک","Diuretic",false]],
      ex_fa: "آسپرین و ریپرفیوژن (PCI اولیه یا فیبرینولیز) سریع نجات‌بخش است.", ex_en: "Aspirin + prompt reperfusion (primary PCI or fibrinolysis)." },
    { q_fa: "یافته ECG کلاسیک در پریکاردیت حاد؟", q_en: "Classic ECG finding in acute pericarditis?",
      options: [["بالا رفتن منتشر ST","Diffuse ST elevation",true],["موج Q عمیق","Deep Q waves",false],["QT کوتاه","Short QT",false],["بلوک شاخه‌ای","Bundle branch block",false]],
      ex_fa: "بالا رفتن منتشر مقعر ST و افت PR مشخصه است.", ex_en: "Diffuse concave ST elevation with PR depression." },
  ],
  peds: [
    { q_fa: "شایع‌ترین علت مننژیت باکتریال در نوزادان؟", q_en: "Most common cause of neonatal bacterial meningitis?",
      options: [["استرپتوکوک گروه B","Group B Streptococcus",true],["مننگوکوک","Meningococcus",false],["پنوموکوک","Pneumococcus",false],["هموفیلوس","H. influenzae",false]],
      ex_fa: "GBS شایع‌ترین علت در نوزادان است (به همراه E. coli و لیستریا).", ex_en: "GBS is the top neonatal cause (with E. coli, Listeria)." },
    { q_fa: "واکسن BCG در برنامه ایمن‌سازی ایران چه زمانی تزریق می‌شود؟", q_en: "When is BCG given in Iran's immunization schedule?",
      options: [["بدو تولد","At birth",true],["۲ ماهگی","2 months",false],["۶ ماهگی","6 months",false],["۱۲ ماهگی","12 months",false]],
      ex_fa: "BCG در بدو تولد تزریق می‌شود.", ex_en: "BCG is given at birth." },
  ],
  obgyn: [
    { q_fa: "غربالگری دیابت بارداری معمولاً در چه هفته‌ای انجام می‌شود؟", q_en: "Gestational diabetes screening is usually done at?",
      options: [["هفته ۲۴ تا ۲۸","24–28 weeks",true],["هفته ۸","8 weeks",false],["هفته ۱۲","12 weeks",false],["هفته ۳۶","36 weeks",false]],
      ex_fa: "غربالگری GDM بین هفته ۲۴ تا ۲۸ انجام می‌شود.", ex_en: "GDM screening is at 24–28 weeks." },
    { q_fa: "شایع‌ترین علت خونریزی بعد از زایمان؟", q_en: "Most common cause of postpartum hemorrhage?",
      options: [["آتونی رحم","Uterine atony",true],["پارگی سرویکس","Cervical laceration",false],["احتباس جفت","Retained placenta",false],["اختلال انعقاد","Coagulopathy",false]],
      ex_fa: "آتونی رحم شایع‌ترین علت PPH است.", ex_en: "Uterine atony is the leading cause of PPH." },
  ],
  surgery: [
    { q_fa: "نشانه McBurney در کدام بیماری مثبت است؟", q_en: "McBurney's point tenderness suggests?",
      options: [["آپاندیسیت حاد","Acute appendicitis",true],["کوله‌سیستیت","Cholecystitis",false],["پانکراتیت","Pancreatitis",false],["دیورتیکولیت","Diverticulitis",false]],
      ex_fa: "حساسیت نقطه مک‌بورنی مشخصه آپاندیسیت حاد است.", ex_en: "McBurney point tenderness is classic for appendicitis." },
    { q_fa: "علامت Murphy مثبت به نفع چیست؟", q_en: "A positive Murphy's sign indicates?",
      options: [["کوله‌سیستیت حاد","Acute cholecystitis",true],["آپاندیسیت","Appendicitis",false],["انسداد روده","Bowel obstruction",false],["سنگ کلیه","Renal colic",false]],
      ex_fa: "علامت مورفی مثبت به نفع کوله‌سیستیت حاد است.", ex_en: "Positive Murphy's sign points to acute cholecystitis." },
  ],
  neuro: [
    { q_fa: "پنجره درمانی tPA در سکته ایسکمیک چند ساعت است؟", q_en: "tPA window in ischemic stroke?",
      options: [["تا ۴.۵ ساعت","Up to 4.5 hours",true],["تا ۲۴ ساعت","Up to 24 hours",false],["تا ۱۲ ساعت","Up to 12 hours",false],["بدون محدودیت","No limit",false]],
      ex_fa: "پنجره IV tPA تا ۴.۵ ساعت از شروع علائم است.", ex_en: "IV tPA window is up to 4.5 hours from onset." },
  ],
  infect: [
    { q_fa: "درمان خط اول سیفلیس اولیه کدام است؟", q_en: "First-line treatment of primary syphilis?",
      options: [["بنزاتین پنی‌سیلین G","Benzathine penicillin G",true],["آزیترومایسین","Azithromycin",false],["داکسی‌سایکلین","Doxycycline",false],["سفتریاکسون","Ceftriaxone",false]],
      ex_fa: "بنزاتین پنی‌سیلین G تک‌دوز درمان انتخابی است.", ex_en: "Single-dose benzathine penicillin G is the treatment of choice." },
  ],
  psych: [
    { q_fa: "حداقل مدت علائم برای تشخیص اسکیزوفرنی؟", q_en: "Minimum symptom duration for schizophrenia diagnosis?",
      options: [["۶ ماه","6 months",true],["۱ ماه","1 month",false],["۲ هفته","2 weeks",false],["۱ سال","1 year",false]],
      ex_fa: "برای تشخیص اسکیزوفرنی حداقل ۶ ماه علائم لازم است.", ex_en: "Schizophrenia requires ≥6 months of symptoms." },
  ],
  endo: [
    { q_fa: "معیار تشخیص دیابت با HbA1c کدام است؟", q_en: "HbA1c diagnostic threshold for diabetes?",
      options: [["≥ ۶.۵٪","≥ 6.5%",true],["≥ ۵.۷٪","≥ 5.7%",false],["≥ ۷.۵٪","≥ 7.5%",false],["≥ ۸٪","≥ 8%",false]],
      ex_fa: "HbA1c ≥ ۶.۵٪ معیار تشخیص دیابت است.", ex_en: "HbA1c ≥ 6.5% is diagnostic for diabetes." },
  ],
  nephro: [
    { q_fa: "شایع‌ترین علت نارسایی کلیه پیش‌کلیوی (prerenal)؟", q_en: "Most common cause of prerenal AKI?",
      options: [["کاهش حجم داخل عروقی","Volume depletion",true],["گلومرولونفریت","Glomerulonephritis",false],["انسداد مجاری","Obstruction",false],["نکروز حاد توبولی","ATN",false]],
      ex_fa: "هایپوولمی شایع‌ترین علت AKI پیش‌کلیوی است.", ex_en: "Hypovolemia is the top cause of prerenal AKI." },
  ],
  heme: [
    { q_fa: "شایع‌ترین کم‌خونی در جهان کدام است؟", q_en: "Most common anemia worldwide?",
      options: [["فقر آهن","Iron deficiency",true],["کم‌خونی سیدروبلاستیک","Sideroblastic",false],["آپلاستیک","Aplastic",false],["همولیتیک","Hemolytic",false]],
      ex_fa: "کم‌خونی فقر آهن شایع‌ترین کم‌خونی است.", ex_en: "Iron deficiency anemia is the most common anemia." },
  ],
  pulmo: [
    { q_fa: "اولین قدم تشخیصی در آمبولی ریه با احتمال بالا و پایداری همودینامیک؟", q_en: "Initial test for suspected PE (stable, high probability)?",
      options: [["CT آنژیوگرافی ریه","CT pulmonary angiography",true],["D-dimer","D-dimer",false],["اکوکاردیوگرافی","Echocardiography",false],["گرافی قفسه سینه","Chest X-ray",false]],
      ex_fa: "CTPA تست انتخابی در احتمال بالای PE است.", ex_en: "CTPA is the test of choice in high-probability PE." },
  ],
  rheum: [
    { q_fa: "آنتی‌بادی اختصاصی لوپوس (SLE) کدام است؟", q_en: "Antibody most specific for SLE?",
      options: [["Anti-dsDNA","Anti-dsDNA",true],["RF","Rheumatoid factor",false],["Anti-CCP","Anti-CCP",false],["ANCA","ANCA",false]],
      ex_fa: "Anti-dsDNA و Anti-Smith اختصاصی SLE هستند.", ex_en: "Anti-dsDNA and Anti-Smith are specific for SLE." },
  ],
  path: [
    { q_fa: "تغییر برگشت‌ناپذیر سلولی کدام است؟", q_en: "Which is an irreversible cell injury?",
      options: [["نکروز","Necrosis",true],["تورم سلولی","Cellular swelling",false],["تجمع چربی","Fatty change",false],["آتروفی","Atrophy",false]],
      ex_fa: "نکروز آسیب برگشت‌ناپذیر سلولی است.", ex_en: "Necrosis is irreversible cell injury." },
  ],
  derm: [
    { q_fa: "ضایعه هدف (target lesion) مشخصه کدام بیماری است؟", q_en: "Target lesions are characteristic of?",
      options: [["اریتم مولتی‌فرم","Erythema multiforme",true],["پسوریازیس","Psoriasis",false],["پمفیگوس","Pemphigus",false],["لیکن پلان","Lichen planus",false]],
      ex_fa: "ضایعات هدف مشخصه اریتم مولتی‌فرم است.", ex_en: "Target lesions characterize erythema multiforme." },
  ],
  ortho: [
    { q_fa: "شایع‌ترین شکستگی مچ دست در سالمندان؟", q_en: "Most common wrist fracture in the elderly?",
      options: [["کولیس","Colles fracture",true],["اسمیت","Smith fracture",false],["اسکافوئید","Scaphoid",false],["بارتون","Barton",false]],
      ex_fa: "شکستگی کولیس شایع‌ترین شکستگی مچ در سالمندان است.", ex_en: "Colles fracture is the most common wrist fracture in the elderly." },
  ],
  pharm: [
    { q_fa: "آنتی‌دوت مسمومیت با استامینوفن کدام است؟", q_en: "Antidote for acetaminophen toxicity?",
      options: [["N-استیل‌سیستئین","N-acetylcysteine",true],["نالوکسان","Naloxone",false],["فلومازنیل","Flumazenil",false],["آتروپین","Atropine",false]],
      ex_fa: "N-استیل‌سیستئین آنتی‌دوت مسمومیت با استامینوفن است.", ex_en: "N-acetylcysteine is the antidote for acetaminophen overdose." },
  ],
  uro: [
    { q_fa: "شایع‌ترین محل سنگ ادراری برای گیر افتادن؟", q_en: "Most common site of ureteral stone impaction?",
      options: [["محل اتصال حالب-مثانه","Ureterovesical junction",true],["لگنچه کلیه","Renal pelvis",false],["مثانه","Bladder",false],["پیشابراه","Urethra",false]],
      ex_fa: "UVJ باریک‌ترین نقطه و شایع‌ترین محل گیر سنگ است.", ex_en: "The UVJ is the narrowest point and commonest impaction site." },
  ],
  ophth: [
    { q_fa: "اورژانس چشمی با درد شدید، قرمزی و مردمک نیمه‌گشاد؟", q_en: "Painful red eye with mid-dilated pupil is?",
      options: [["گلوکوم زاویه بسته حاد","Acute angle-closure glaucoma",true],["ورم ملتحمه","Conjunctivitis",false],["بلفاریت","Blepharitis",false],["کاتاراکت","Cataract",false]],
      ex_fa: "گلوکوم حاد زاویه‌بسته اورژانس چشمی است.", ex_en: "Acute angle-closure glaucoma is an ophthalmic emergency." },
  ],
  ent: [
    { q_fa: "شایع‌ترین علت اوتیت مدیای حاد؟", q_en: "Most common cause of acute otitis media?",
      options: [["استرپتوکوک پنومونیه","S. pneumoniae",true],["سودوموناس","Pseudomonas",false],["استاف اورئوس","S. aureus",false],["کلبسیلا","Klebsiella",false]],
      ex_fa: "پنوموکوک شایع‌ترین علت AOM است.", ex_en: "S. pneumoniae is the leading cause of AOM." },
  ],
  radio: [
    { q_fa: "بهترین روش تصویربرداری اولیه برای سنگ کلیه؟", q_en: "Best initial imaging for renal stones?",
      options: [["CT بدون کنتراست","Non-contrast CT",true],["MRI","MRI",false],["گرافی ساده","Plain X-ray",false],["PET","PET",false]],
      ex_fa: "CT اسپیرال بدون کنتراست استاندارد طلایی سنگ ادراری است.", ex_en: "Non-contrast helical CT is the gold standard for urinary stones." },
  ],
  stats: [
    { q_fa: "کدام شاخص احتمال منفی بودن تست در افراد سالم را نشان می‌دهد؟", q_en: "Which measures the chance a healthy person tests negative?",
      options: [["ویژگی (specificity)","Specificity",true],["حساسیت","Sensitivity",false],["شیوع","Prevalence",false],["بروز","Incidence",false]],
      ex_fa: "ویژگی = نسبت افراد سالم با تست منفی.", ex_en: "Specificity = true negatives among the healthy." },
  ],
  ethics: [
    { q_fa: "اصل احترام به خودمختاری بیمار بیشتر با کدام مفهوم مرتبط است؟", q_en: "Respect for patient autonomy is best reflected by?",
      options: [["رضایت آگاهانه","Informed consent",true],["سودرسانی","Beneficence",false],["عدالت","Justice",false],["ضرر نرساندن","Non-maleficence",false]],
      ex_fa: "رضایت آگاهانه تجلی اصل خودمختاری بیمار است.", ex_en: "Informed consent embodies patient autonomy." },
  ],
  genetics: [
    { q_fa: "بیماری اتوزومال مغلوب کدام است؟", q_en: "Which is an autosomal recessive disease?",
      options: [["فیبروز کیستیک","Cystic fibrosis",true],["هانتینگتون","Huntington disease",false],["مارفان","Marfan syndrome",false],["نوروفیبروماتوز","Neurofibromatosis",false]],
      ex_fa: "فیبروز کیستیک اتوزومال مغلوب است.", ex_en: "Cystic fibrosis is autosomal recessive." },
  ],
  immuno: [
    { q_fa: "واکنش ازدیاد حساسیت نوع I توسط کدام آنتی‌بادی واسطه می‌شود؟", q_en: "Type I hypersensitivity is mediated by?",
      options: [["IgE","IgE",true],["IgG","IgG",false],["IgM","IgM",false],["IgA","IgA",false]],
      ex_fa: "واکنش نوع I (آنافیلاکسی) با IgE واسطه می‌شود.", ex_en: "Type I (anaphylaxis) is IgE-mediated." },
  ],
  nutrition: [
    { q_fa: "کمبود ویتامین C کدام بیماری را ایجاد می‌کند؟", q_en: "Vitamin C deficiency causes?",
      options: [["اسکوربوت","Scurvy",true],["بری‌بری","Beriberi",false],["پلاگر","Pellagra",false],["راشیتیسم","Rickets",false]],
      ex_fa: "کمبود ویتامین C باعث اسکوربوت می‌شود.", ex_en: "Vitamin C deficiency causes scurvy." },
  ],
  physics: [
    { q_fa: "کدام روش تصویربرداری از پرتوهای یون‌ساز استفاده نمی‌کند؟", q_en: "Which imaging modality uses NO ionizing radiation?",
      options: [["MRI","MRI",true],["CT","CT",false],["رادیوگرافی","X-ray",false],["اسکن هسته‌ای","Nuclear scan",false]],
      ex_fa: "MRI از میدان مغناطیسی استفاده می‌کند نه پرتو یون‌ساز.", ex_en: "MRI uses magnetic fields, not ionizing radiation." },
  ],
};

/* =====================================================================
   BASIC SCIENCES program (علوم پایه) — a separate Duolingo-style course.
   Topics + sample MCQ pool, same shape as the pre-internship data above.
   ===================================================================== */
export const BASIC_TOPICS = [
  { slug: "anatomy",   name_fa: "آناتومی",        name_en: "Anatomy",        parent: "basic", budget: 20, color: "#e0568a", icon: "patient" },
  { slug: "physio",    name_fa: "فیزیولوژی",       name_en: "Physiology",     parent: "basic", budget: 18, color: "#2f7fd1", icon: "activity" },
  { slug: "biochem",   name_fa: "بیوشیمی",         name_en: "Biochemistry",   parent: "basic", budget: 16, color: "#22a06b", icon: "flask" },
  { slug: "histology", name_fa: "بافت‌شناسی",      name_en: "Histology",      parent: "basic", budget: 12, color: "#6d5bd0", icon: "brain" },
  { slug: "embryo",    name_fa: "جنین‌شناسی",      name_en: "Embryology",     parent: "basic", budget: 10, color: "#e0912e", icon: "patient" },
  { slug: "micro",     name_fa: "میکروب‌شناسی",    name_en: "Microbiology",   parent: "basic", budget: 14, color: "#e0544f", icon: "flask" },
  { slug: "biophys",   name_fa: "بیوفیزیک",        name_en: "Biophysics",     parent: "basic", budget: 8,  color: "#2569b0", icon: "chart" },
];

// merge basic-science questions into the same SAMPLE_QUESTIONS map
Object.assign(SAMPLE_QUESTIONS, {
  anatomy: [
    { q_fa: "عصب فرنیک از کدام ریشه‌های نخاعی منشأ می‌گیرد؟", q_en: "The phrenic nerve arises from which spinal roots?",
      options: [["C3-C5","C3-C5",true],["C1-C3","C1-C3",false],["T1-T4","T1-T4",false],["L1-L3","L1-L3",false]],
      ex_fa: "«C3،4،5 دیافراگم را زنده نگه می‌دارد» — عصب فرنیک از C3 تا C5.", ex_en: "\"C3,4,5 keep the diaphragm alive\" — phrenic nerve is C3-C5." },
    { q_fa: "بزرگ‌ترین استخوان بدن انسان کدام است؟", q_en: "Largest bone in the human body?",
      options: [["فمور","Femur",true],["تیبیا","Tibia",false],["هومروس","Humerus",false],["لگن","Pelvis",false]],
      ex_fa: "فمور (استخوان ران) بلندترین و قوی‌ترین استخوان است.", ex_en: "The femur is the longest and strongest bone." },
    { q_fa: "کدام دریچهٔ قلبی بین دهلیز چپ و بطن چپ است؟", q_en: "Which valve lies between the left atrium and left ventricle?",
      options: [["میترال","Mitral",true],["تریکوسپید","Tricuspid",false],["آئورت","Aortic",false],["پولمونر","Pulmonary",false]],
      ex_fa: "دریچهٔ میترال (دولختی) بین دهلیز و بطن چپ قرار دارد.", ex_en: "The mitral (bicuspid) valve is between the left atrium and ventricle." },
  ],
  physio: [
    { q_fa: "هورمون تنظیم‌کنندهٔ اصلی قند خون که آن را کاهش می‌دهد کدام است؟", q_en: "Main hormone that lowers blood glucose?",
      options: [["انسولین","Insulin",true],["گلوکاگون","Glucagon",false],["کورتیزول","Cortisol",false],["اپی‌نفرین","Epinephrine",false]],
      ex_fa: "انسولین از سلول‌های بتای پانکراس ترشح و قند خون را کاهش می‌دهد.", ex_en: "Insulin from pancreatic beta cells lowers blood glucose." },
    { q_fa: "واحد عملکردی کلیه کدام است؟", q_en: "Functional unit of the kidney?",
      options: [["نفرون","Nephron",true],["گلومرول","Glomerulus",false],["نفریدیوم","Nephridium",false],["توبول","Tubule",false]],
      ex_fa: "نفرون واحد عملکردی کلیه است.", ex_en: "The nephron is the kidney's functional unit." },
    { q_fa: "منحنی تفکیک اکسی‌هموگلوبین با اسیدوز به کدام سمت جابه‌جا می‌شود؟", q_en: "Acidosis shifts the oxy-hemoglobin curve to which side?",
      options: [["راست","Right",true],["چپ","Left",false],["بدون تغییر","No change",false],["بالا","Up",false]],
      ex_fa: "اثر بوهر: اسیدوز منحنی را به راست می‌برد (آزادسازی اکسیژن بیشتر).", ex_en: "Bohr effect: acidosis shifts the curve right (more O2 release)." },
  ],
  biochem: [
    { q_fa: "محصول نهایی گلیکولیز در شرایط هوازی کدام است؟", q_en: "End product of glycolysis under aerobic conditions?",
      options: [["پیرووات","Pyruvate",true],["لاکتات","Lactate",false],["استیل‌کوآ","Acetyl-CoA",false],["گلوکز","Glucose",false]],
      ex_fa: "در شرایط هوازی، گلیکولیز به پیرووات ختم می‌شود.", ex_en: "Aerobically, glycolysis ends in pyruvate." },
    { q_fa: "کمبود کدام ویتامین باعث اسکوربوت (scurvy) می‌شود؟", q_en: "Deficiency of which vitamin causes scurvy?",
      options: [["ویتامین C","Vitamin C",true],["ویتامین D","Vitamin D",false],["ویتامین B12","Vitamin B12",false],["ویتامین K","Vitamin K",false]],
      ex_fa: "کمبود ویتامین C سنتز کلاژن را مختل و اسکوربوت ایجاد می‌کند.", ex_en: "Vitamin C deficiency impairs collagen synthesis → scurvy." },
    { q_fa: "چرخهٔ کربس در کدام اندامک سلولی رخ می‌دهد؟", q_en: "Where does the Krebs cycle occur?",
      options: [["میتوکندری","Mitochondria",true],["سیتوپلاسم","Cytoplasm",false],["هسته","Nucleus",false],["ریبوزوم","Ribosome",false]],
      ex_fa: "چرخهٔ کربس در ماتریکس میتوکندری انجام می‌شود.", ex_en: "The Krebs cycle runs in the mitochondrial matrix." },
  ],
  histology: [
    { q_fa: "کدام نوع بافت پوششی مری را می‌پوشاند؟", q_en: "Which epithelium lines the esophagus?",
      options: [["سنگفرشی مطبق","Stratified squamous",true],["مکعبی ساده","Simple cuboidal",false],["استوانه‌ای ساده","Simple columnar",false],["مطبق انتقالی","Transitional",false]],
      ex_fa: "مری با اپیتلیوم سنگفرشی مطبق غیرشاخی پوشیده شده است.", ex_en: "The esophagus is lined by non-keratinized stratified squamous epithelium." },
    { q_fa: "سلول‌های کوپفر در کدام اندام یافت می‌شوند؟", q_en: "Kupffer cells are found in which organ?",
      options: [["کبد","Liver",true],["کلیه","Kidney",false],["ریه","Lung",false],["طحال","Spleen",false]],
      ex_fa: "سلول‌های کوپفر ماکروفاژهای مقیم کبد هستند.", ex_en: "Kupffer cells are the resident macrophages of the liver." },
  ],
  embryo: [
    { q_fa: "لولهٔ عصبی از کدام لایهٔ زایا مشتق می‌شود؟", q_en: "The neural tube derives from which germ layer?",
      options: [["اکتودرم","Ectoderm",true],["مزودرم","Mesoderm",false],["اندودرم","Endoderm",false],["تروفوبلاست","Trophoblast",false]],
      ex_fa: "لولهٔ عصبی از اکتودرم (نورواکتودرم) منشأ می‌گیرد.", ex_en: "The neural tube arises from ectoderm (neuroectoderm)." },
    { q_fa: "لقاح به‌طور طبیعی در کدام قسمت رخ می‌دهد؟", q_en: "Where does fertilization normally occur?",
      options: [["آمپولای لولهٔ فالوپ","Ampulla of the fallopian tube",true],["رحم","Uterus",false],["تخمدان","Ovary",false],["دهانهٔ رحم","Cervix",false]],
      ex_fa: "لقاح معمولاً در آمپولای لولهٔ رحمی انجام می‌شود.", ex_en: "Fertilization usually occurs in the ampulla of the uterine tube." },
  ],
  micro: [
    { q_fa: "رنگ‌آمیزی گرم باکتری‌های گرم‌مثبت را به چه رنگی نشان می‌دهد؟", q_en: "Gram-positive bacteria appear what color on Gram stain?",
      options: [["بنفش","Purple",true],["صورتی/قرمز","Pink/Red",false],["سبز","Green",false],["آبی روشن","Light blue",false]],
      ex_fa: "گرم‌مثبت‌ها به‌دلیل پپتیدوگلیکان ضخیم بنفش می‌مانند.", ex_en: "Gram-positives retain crystal violet (purple) due to thick peptidoglycan." },
    { q_fa: "عامل سل (توبرکلوزیس) کدام است؟", q_en: "Causative agent of tuberculosis?",
      options: [["مایکوباکتریوم توبرکلوزیس","Mycobacterium tuberculosis",true],["استرپتوکوک","Streptococcus",false],["کلبسیلا","Klebsiella",false],["لژیونلا","Legionella",false]],
      ex_fa: "مایکوباکتریوم توبرکلوزیس عامل سل و اسیدفست است.", ex_en: "M. tuberculosis (acid-fast) causes TB." },
  ],
  biophys: [
    { q_fa: "واحد اندازه‌گیری فشار خون کدام است؟", q_en: "Unit used to measure blood pressure?",
      options: [["mmHg","mmHg",true],["پاسکال خالص","Pure Pascal",false],["نیوتن","Newton",false],["وات","Watt",false]],
      ex_fa: "فشار خون برحسب میلی‌متر جیوه (mmHg) بیان می‌شود.", ex_en: "Blood pressure is expressed in millimeters of mercury (mmHg)." },
    { q_fa: "کدام نوع پرتو در MRI استفاده می‌شود؟", q_en: "Which is used in MRI imaging?",
      options: [["میدان مغناطیسی و امواج رادیویی","Magnetic field & radio waves",true],["پرتو ایکس","X-rays",false],["پرتو گاما","Gamma rays",false],["فراصوت","Ultrasound",false]],
      ex_fa: "MRI از میدان مغناطیسی قوی و امواج رادیویی استفاده می‌کند.", ex_en: "MRI uses a strong magnetic field and radio waves." },
  ],
});
