import { useEffect, useState, useMemo } from "react";
import { useApp } from "../../context.jsx";
import { api } from "../../api.js";
import Icon from "../../components/Icon.jsx";

/* Mind-maps: two modes
   1. Classic — built from hand-written درسنامه (topic → lessons)
   2. Bank — premium MindMap + Approach graphs, bidirectionally linked to Qbank
*/

const SYSTEMS = [
  { id: "", label_fa: "همه دستگاه‌ها", label_en: "All systems" },
  { id: "cardio", label_fa: "قلب", label_en: "Cardio" },
  { id: "pulmo", label_fa: "ریه", label_en: "Pulmo" },
  { id: "gastro", label_fa: "گوارش", label_en: "Gastro" },
  { id: "nephro", label_fa: "کلیه", label_en: "Nephro" },
  { id: "endo", label_fa: "غدد", label_en: "Endo" },
  { id: "neuro", label_fa: "مغز و اعصاب", label_en: "Neuro" },
  { id: "heme", label_fa: "خون", label_en: "Heme" },
  { id: "infect", label_fa: "عفونی", label_en: "Infect" },
  { id: "emergency", label_fa: "اورژانس", label_en: "Emergency" },
];
const TYPES = [
  { id: "", label_fa: "همه", label_en: "All" },
  { id: "mind", label_fa: "مایندمپ", label_en: "Mind" },
  { id: "approach", label_fa: "اپروچ", label_en: "Approach" },
];

function systemColor(s) {
  const map = { cardio: "#e0533d", pulmo: "#2f7fd1", gastro: "#22a06b", nephro: "#6d28d9", endo: "#f59e0b", neuro: "#0ea5e9", heme: "#be123c", infect: "#16a34a", emergency: "#dc2626", other: "#64748b" };
  return map[s] || "#2f7fd1";
}
function branchColor(b) {
  const m = { definition: "#1e40af", etiology: "#7c3aed", patho: "#dc2626", clinical: "#ea580c", workup: "#0369a1", treatment: "#15803d", complication: "#991b1b", start: "#1e3a8a", question: "#7c2d12", action: "#14532d", ddx: "#6b21a8" };
  return m[b] || "#334155";
}

export default function Mindmap({ onBack }) {
  const { t, lang } = useApp();
  const [mode, setMode] = useState("bank"); // bank | classic
  // classic
  const [topics, setTopics] = useState(null);
  const [active, setActive] = useState(null);
  const [map, setMap] = useState(null);
  // bank
  const [bank, setBank] = useState(null);
  const [filterSys, setFilterSys] = useState("");
  const [filterType, setFilterType] = useState("");
  const [detail, setDetail] = useState(null); // selected bank slug detail
  const [detailLoading, setDetailLoading] = useState(false);
  const [nodeQ, setNodeQ] = useState(null); // { concept, items }
  // auto-open from question → mindmap navigation (sessionStorage)
  useEffect(() => {
    try {
      const slug = sessionStorage.getItem("openMindmap");
      if (slug && mode === "bank") {
        sessionStorage.removeItem("openMindmap");
        openBank(slug);
      }
    } catch {}
  }, [mode]);
  const [toast, setToast] = useState("");

  // classic topics
  useEffect(() => {
    if (mode !== "classic") return;
    api.get(`/learn/mindmap/topics?lang=${lang}`).then((d) => setTopics(d.topics || [])).catch(() => setTopics([]));
  }, [lang, mode]);

  // bank list
  useEffect(() => {
    if (mode !== "bank") return;
    setBank(null);
    const qs = new URLSearchParams({ lang });
    if (filterSys) qs.set("system", filterSys);
    if (filterType) qs.set("type", filterType);
    api.get(`/learn/mindmap-bank?${qs.toString()}`).then(setBank).catch(() => setBank({ items: [], total: 0 }));
  }, [lang, mode, filterSys, filterType]);

  const openClassic = (slug) => {
    setActive(slug); setMap(null);
    api.get(`/learn/mindmap/${slug}?lang=${lang}`).then(setMap).catch(() => setMap({ empty: true, branches: [] }));
  };

  const openBank = (slug) => {
    setDetail(null); setDetailLoading(true); setNodeQ(null);
    api.get(`/learn/mindmap-bank/${slug}?lang=${lang}`).then((d) => { setDetail(d); setDetailLoading(false); }).catch(() => setDetailLoading(false));
  };

  const openQuestionsFor = (concept, mindmapSlug) => {
    const qs = new URLSearchParams({ lang });
    if (concept) qs.set("concept", concept);
    if (mindmapSlug) qs.set("mindmap", mindmapSlug);
    api.get(`/learn/questions/by-concept?${qs.toString()}`).then((d) => {
      setNodeQ({ concept: concept || mindmapSlug, items: d.items || [] });
      if (!d.items || d.items.length === 0) setToast(lang === "fa" ? "سؤالی برای این گره یافت نشد" : "No questions for this node");
    }).catch(() => setToast("خطا"));
  };

  const sysLabel = (id) => {
    const f = SYSTEMS.find((x) => x.id === id);
    return f ? (lang === "fa" ? f.label_fa : f.label_en) : id;
  };

  // ---------- BANK DETAIL GRAPH ----------
  const GraphView = ({ data }) => {
    if (data.locked) {
      return (
        <div className="card" style={{ textAlign: "center", padding: 28, border: "2px dashed #f59e0b", background: "#fffbeb" }}>
          <div style={{ fontSize: 42 }}>🔒</div>
          <h3 style={{ margin: "8px 0" }}>{lang === "fa" ? "این نقشه ویژهٔ پرمیوم است" : "Premium only"}</h3>
          <div className="muted small" style={{ marginBottom: 12 }}>{lang === "fa" ? "با ارتقا به پرمیوم، ۳۰+ مایندمپ و اپروچِ لینک‌دار به بانک را باز کنید — ۳ نقشه برای آشنایی رایگان است." : "Upgrade to Premium to unlock 30+ linked maps — 3 are free to preview."}</div>
          <button type="button" className="btn btn-primary" onClick={() => window.dispatchEvent(new CustomEvent("medlab-go", { detail: "premium" }))}>
            {lang === "fa" ? "ارتقا به پرمیوم" : "Upgrade"}
          </button>
        </div>
      );
    }
    const nodes = data.nodes || [];
    const edges = data.edges || [];
    // auto-layout if x/y are 0: use simple layered layout
    const hasPos = nodes.some((n) => n.x !== 0 || n.y !== 0);
    // compute bounds for SVG
    const pad = 24;
    const W = 720, H = 520;
    // if no pos, we will render as cards grid instead of absolute
    if (!hasPos || nodes.length > 12) {
      return (
        <div>
          <div className="grid" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(220px,1fr))", gap: 12 }}>
            {nodes.map((n) => (
              <button key={n.id} type="button" onClick={() => openQuestionsFor(n.id, data.slug)}
                className="card" style={{ textAlign: "start", cursor: "pointer", borderInlineStart: `4px solid ${branchColor(n.branch)}`, padding: "12px 14px" }}>
                <div className="small" style={{ color: branchColor(n.branch), fontWeight: 800, fontSize: 11, letterSpacing: ".04em" }}>{n.branch}</div>
                <div style={{ fontWeight: 700, marginTop: 6, lineHeight: 1.4 }}>{lang === "fa" ? n.label_fa : n.label_en}</div>
                <div className="small muted" style={{ marginTop: 6 }}>↗ {lang === "fa" ? "سؤالات مرتبط" : "related Qs"}</div>
              </button>
            ))}
          </div>
          {/* edges as list */}
          {edges.length > 0 && (
            <div className="card mt16" style={{ background: "#f8fafc" }}>
              <div className="small" style={{ fontWeight: 700, marginBottom: 8 }}>{lang === "fa" ? "ارتباط‌ها" : "Links"}</div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                {edges.map((e, i) => (
                  <span key={i} className="badge" style={{ background: "#e0f2fe", color: "#0c4a6e", padding: "4px 8px", borderRadius: 999 }}>{e.from} → {e.to} {e.label ? `(${e.label})` : ""}</span>
                ))}
              </div>
            </div>
          )}
        </div>
      );
    }
    // absolute graph with SVG edges
    // normalize x/y to fit W,H
    const xs = nodes.map((n) => n.x), ys = nodes.map((n) => n.y);
    const minX = Math.min(...xs), maxX = Math.max(...xs), minY = Math.min(...ys), maxY = Math.max(...ys);
    const scaleX = (maxX - minX) || 1, scaleY = (maxY - minY) || 1;
    const norm = (n) => ({
      ...n,
      _x: pad + ((n.x - minX) / scaleX) * (W - pad * 2 - 160) + 80,
      _y: pad + ((n.y - minY) / scaleY) * (H - pad * 2 - 60) + 30,
    });
    const N = nodes.map(norm);
    const idPos = Object.fromEntries(N.map((n) => [n.id, n]));
    return (
      <div className="card" style={{ overflow: "hidden", padding: 0, position: "relative", background: "#f8fafc", border: "1px solid #e2e8f0" }}>
        <div style={{ position: "relative", width: "100%", height: H, overflow: "auto" }}>
          <svg width={W} height={H} style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
            {edges.map((e, i) => {
              const a = idPos[e.from], b = idPos[e.to];
              if (!a || !b) return null;
              return (
                <g key={i}>
                  <line x1={a._x} y1={a._y} x2={b._x} y2={b._y} stroke="#94a3b8" strokeWidth={2} markerEnd="url(#arrow)" />
                  {e.label ? <text x={(a._x + b._x) / 2} y={(a._y + b._y) / 2 - 6} fontSize={11} fill="#64748b" textAnchor="middle">{e.label}</text> : null}
                </g>
              );
            })}
            <defs><marker id="arrow" viewBox="0 0 10 10" refX={8} refY={5} markerWidth={8} markerHeight={8} orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="#94a3b8" /></marker></defs>
          </svg>
          {N.map((n) => (
            <button key={n.id} type="button" onClick={() => openQuestionsFor(n.id, data.slug)}
              style={{
                position: "absolute", left: n._x - 80, top: n._y - 28, width: 160,
                background: "#fff", border: `2px solid ${branchColor(n.branch)}`, borderRadius: 12, padding: "8px 10px",
                boxShadow: "0 4px 12px rgba(0,0,0,.08)", cursor: "pointer", textAlign: "center", lineHeight: 1.3
              }}>
              <div style={{ fontSize: 10, fontWeight: 800, color: branchColor(n.branch), letterSpacing: ".04em" }}>{n.branch}</div>
              <div style={{ fontSize: 12, fontWeight: 700, marginTop: 4 }}>{lang === "fa" ? n.label_fa : n.label_en}</div>
            </button>
          ))}
        </div>
        <div className="small muted" style={{ padding: "8px 12px", borderTop: "1px solid #e2e8f0", background: "#fff" }}>
          {lang === "fa" ? "روی هر گره بزنید → سؤالات مرتبط را ببینید" : "Tap any node → see linked questions"}
        </div>
      </div>
    );
  };

  if (toast) setTimeout(() => setToast(""), 2500);

  // ---------- RENDER ----------
  return (
    <div className="page">
      <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
        <button type="button" className={`btn ${mode === "bank" ? "btn-primary" : "btn-ghost"} btn-sm`} onClick={() => setMode("bank")}>
          ⭐ {lang === "fa" ? "بانکِ مایندمپ (پرمیوم)" : "MindMap Bank (Premium)"}
        </button>
        <button type="button" className={`btn ${mode === "classic" ? "btn-primary" : "btn-ghost"} btn-sm`} onClick={() => setMode("classic")}>
          🗺️ {lang === "fa" ? "نقشه‌های درسی" : "Lesson maps"}
        </button>
      </div>

      {/* ===== BANK MODE ===== */}
      {mode === "bank" && (
        <>
          {/* Detail */}
          {detailLoading && <div className="card"><div className="skeleton" style={{ height: 300 }} /></div>}
          {detail && !detailLoading && (
            <div>
              <div className="section-title">
                <h2 style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <span style={{ width: 36, height: 36, borderRadius: 10, display: "grid", placeItems: "center", background: systemColor(detail.system), color: "#fff", fontSize: 18 }}>
                    {detail.type === "approach" ? "🧭" : "🧠"}
                  </span>
                  {detail.title}
                  <span className="badge" style={{ background: systemColor(detail.system), color: "#fff", fontSize: 11, padding: "2px 8px", borderRadius: 999 }}>{sysLabel(detail.system)}</span>
                  <span className="badge" style={{ background: detail.type === "approach" ? "#fef3c7" : "#dbeafe", color: "#92400e", fontSize: 11 }}>{detail.type}</span>
                </h2>
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setDetail(null); setNodeQ(null); }}>
                  <Icon name={lang === "fa" ? "chevronRight" : "chevronLeft"} size={15} /> {lang === "fa" ? "بازگشت به بانک" : "Back to bank"}
                </button>
              </div>
              <div className="card" style={{ background: "#f8fafc", border: "1px solid #e2e8f0" }}>
                <div className="small muted">{detail.summary}</div>
              </div>
              <div className="mt16"><GraphView data={detail} /></div>

              {/* related questions */}
              {detail.related && detail.related.length > 0 && (
                <div className="card mt16">
                  <div style={{ fontWeight: 800, marginBottom: 8 }}>{lang === "fa" ? "سؤالات مرتبط (نمونه)" : "Related questions"}</div>
                  <div style={{ display: "grid", gap: 8 }}>
                    {detail.related.map((q) => (
                      <div key={q.id} className="card" style={{ padding: "10px 12px", background: "#fff", border: "1px solid #e2e8f0", display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8 }}>
                        <div style={{ fontSize: 13, lineHeight: 1.4 }}>{q.stem || `Q#${q.id}`}</div>
                        <button type="button" className="btn btn-ghost btn-sm" onClick={() => { window.dispatchEvent(new CustomEvent("medlab-toast", { detail: lang === "fa" ? "برای تمرین به «مرور بانک» بروید و فیلتر کنید" : "Go to Browse to practice" })); window.dispatchEvent(new CustomEvent("medlab-go", { detail: "browse" })); }}>
                          {lang === "fa" ? "تمرین" : "Practice"}
                        </button>
                      </div>
                    ))}
                  </div>
                  <button type="button" className="btn btn-ghost btn-sm mt16" onClick={() => openQuestionsFor(null, detail.slug)}>
                    {lang === "fa" ? "همهٔ سؤالات این نقشه" : "All questions for this map"} →
                  </button>
                </div>
              )}

              {/* node questions modal */}
              {nodeQ && (
                <div className="card mt16" style={{ border: "1.5px solid #2f7fd1" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <b>{lang === "fa" ? `سؤالات: ${nodeQ.concept}` : `Questions: ${nodeQ.concept}`}</b>
                    <button type="button" className="btn btn-ghost btn-sm" onClick={() => setNodeQ(null)}>✕</button>
                  </div>
                  {nodeQ.items.length === 0 ? (
                    <div className="small muted mt16">{lang === "fa" ? "موردی یافت نشد — ادمین می‌تواند لینک‌ها را کامل کند." : "No linked questions yet — admin can complete links."}</div>
                  ) : (
                    <div style={{ display: "grid", gap: 8, marginTop: 12 }}>
                      {nodeQ.items.map((q) => (
                        <div key={q.id} className="card" style={{ padding: "10px 12px", display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8 }}>
                          <div style={{ fontSize: 13 }}>{q.q ? q.q.slice(0, 90) : `Q#${q.id}`} {q.premium ? " 👑" : ""}</div>
                          <button type="button" className="btn btn-primary btn-sm" onClick={() => { window.dispatchEvent(new CustomEvent("medlab-go", { detail: "browse" })); }}>
                            {lang === "fa" ? "حل" : "Solve"}
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              <button type="button" className="btn btn-ghost btn-block mt16" onClick={() => { setDetail(null); setNodeQ(null); }}>{lang === "fa" ? "بازگشت" : "Back"}</button>
            </div>
          )}

          {/* List */}
          {!detail && !detailLoading && (
            <>
              <div className="card" style={{ display: "flex", flexWrap: "wrap", gap: 10, alignItems: "center", justifyContent: "space-between" }}>
                <div>
                  <h3 style={{ margin: 0, fontSize: 16 }}>{lang === "fa" ? "بانکِ مایندمپ و اپروچ" : "MindMap & Approach Bank"}</h3>
                  <div className="small muted">{lang === "fa" ? "۳۰+ نقشهٔ لینک‌دار به بانک — ۳ تا رایگان برای آشنایی، بقیه پرمیوم" : "30+ maps linked to Qbank — 3 free to preview, rest premium"}</div>
                </div>
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                  <select value={filterSys} onChange={(e) => setFilterSys(e.target.value)} className="input" style={{ minWidth: 140, height: 36 }}>
                    {SYSTEMS.map((s) => <option key={s.id} value={s.id}>{lang === "fa" ? s.label_fa : s.label_en}</option>)}
                  </select>
                  <select value={filterType} onChange={(e) => setFilterType(e.target.value)} className="input" style={{ minWidth: 120, height: 36 }}>
                    {TYPES.map((t2) => <option key={t2.id} value={t2.id}>{lang === "fa" ? t2.label_fa : t2.label_en}</option>)}
                  </select>
                </div>
              </div>

              {!bank ? (
                <div className="card mt16"><div className="skeleton" style={{ height: 180 }} /></div>
              ) : bank.items.length === 0 ? (
                <div className="card empty-state mt16"><div className="ico">🧠</div><h3>{lang === "fa" ? "چیزی یافت نشد" : "Nothing found"}</h3></div>
              ) : (
                <>
                  <div className="small muted mt16" style={{ display: "flex", justifyContent: "space-between" }}>
                    <span>{bank.total} {lang === "fa" ? "نقشه" : "maps"} {bank.previews ? `· ${lang === "fa" ? `${bank.previews} رایگان` : `${bank.previews} free`}` : ""}</span>
                    <span>{lang === "fa" ? "⭐ = پرمیوم" : "⭐ = premium"}</span>
                  </div>
                  <div className="grid grid-2 mt16">
                    {bank.items.map((it) => (
                      <button key={it.slug} type="button" onClick={() => openBank(it.slug)}
                        className="card" style={{
                          textAlign: "start", cursor: "pointer", position: "relative", overflow: "hidden",
                          border: it.locked ? "1.5px dashed #f59e0b" : "1px solid #e2e8f0",
                          background: it.locked ? "#fffbeb" : "#fff",
                          opacity: it.locked ? 0.95 : 1
                        }}>
                        {it.locked && <span style={{ position: "absolute", top: 10, insetInlineEnd: 10, background: "#f59e0b", color: "#fff", fontSize: 11, padding: "2px 8px", borderRadius: 999 }}>🔒 {lang === "fa" ? "پرمیوم" : "Premium"}</span>}
                        {it.isPreview && !it.locked && <span style={{ position: "absolute", top: 10, insetInlineEnd: 10, background: "#22a06b", color: "#fff", fontSize: 11, padding: "2px 8px", borderRadius: 999 }}>{lang === "fa" ? "رایگان" : "Free"}</span>}
                        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                          <span style={{ width: 44, height: 44, borderRadius: 12, display: "grid", placeItems: "center", background: systemColor(it.system), color: "#fff", fontSize: 20, flexShrink: 0 }}>
                            {it.type === "approach" ? "🧭" : "🧠"}
                          </span>
                          <div style={{ minWidth: 0 }}>
                            <div style={{ fontWeight: 800, fontSize: 14, lineHeight: 1.3, display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap" }}>
                              {it.title}
                              {it.is_premium && <span style={{ fontSize: 12 }}>⭐</span>}
                            </div>
                            <div className="small muted" style={{ marginTop: 4, lineHeight: 1.4 }}>{it.summary?.slice(0, 90)}</div>
                            <div style={{ display: "flex", gap: 6, marginTop: 8, flexWrap: "wrap" }}>
                              <span className="badge" style={{ background: systemColor(it.system), color: "#fff", fontSize: 11, padding: "2px 8px", borderRadius: 999 }}>{sysLabel(it.system)}</span>
                              <span className="badge" style={{ background: it.type === "approach" ? "#fef3c7" : "#dbeafe", color: "#374151", fontSize: 11 }}>{it.type === "approach" ? (lang === "fa" ? "اپروچ" : "Approach") : (lang === "fa" ? "مایندمپ" : "Mind")}</span>
                              <span className="badge" style={{ background: "#f1f5f9", color: "#475569", fontSize: 11 }}>{it.level}</span>
                            </div>
                          </div>
                        </div>
                        <div className="small muted" style={{ marginTop: 10, display: "flex", gap: 6, alignItems: "center" }}>
                          <span>{it.nodes?.length || 0} {lang === "fa" ? "گره" : "nodes"}</span> · <span>{it.edges?.length || 0} {lang === "fa" ? "یال" : "edges"}</span>
                          <span style={{ marginInlineStart: "auto", color: "#2f7fd1", fontWeight: 700 }}>{lang === "fa" ? "مشاهده →" : "View →"}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                  {bank.items.some((x) => x.locked) && (
                    <div className="card mt16" style={{ background: "linear-gradient(135deg,#1e40af,#7c3aed)", color: "#fff", border: "none" }}>
                      <div style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap", justifyContent: "space-between" }}>
                        <div>
                          <div style={{ fontWeight: 800 }}>{lang === "fa" ? "۳ نقشه رایگان، بقیه با پرمیوم" : "3 free maps, rest with Premium"}</div>
                          <div className="small" style={{ opacity: .9 }}>{lang === "fa" ? "هر گره به سؤالات بانک لینک است — دوکلیک تا تسلط" : "Every node links to Qbank — 2 clicks to mastery"}</div>
                        </div>
                        <button type="button" className="btn" style={{ background: "#fff", color: "#1e40af", fontWeight: 800 }} onClick={() => window.dispatchEvent(new CustomEvent("medlab-go", { detail: "premium" }))}>
                          {lang === "fa" ? "ارتقا به پرمیوم" : "Upgrade"}
                        </button>
                      </div>
                    </div>
                  )}
                </>
              )}
            </>
          )}
          <button type="button" className="btn btn-ghost btn-block mt16" onClick={onBack}>{t("back")}</button>
        </>
      )}

      {/* ===== CLASSIC MODE (old) ===== */}
      {mode === "classic" && (
        <>
          {!topics ? (
            <div className="card"><div className="skeleton" style={{ height: 200 }} /></div>
          ) : active && map ? (
            <div>
              <div className="section-title">
                <h2><span style={{ fontSize: "1.4rem" }}>{map.topic?.emoji}</span> {map.topic?.title}</h2>
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setActive(null); setMap(null); }}>
                  <Icon name={lang === "fa" ? "chevronRight" : "chevronLeft"} size={15} /> {t("mindmapAll")}
                </button>
              </div>
              {map.empty ? (
                <div className="card empty-state"><div className="ico">🗺️</div><h3>{t("mindmapEmpty")}</h3><div className="small muted">{t("mindmapEmptyHint")}</div></div>
              ) : (
                <div className="mindmap">
                  <div className="mm-root" style={{ background: map.topic?.color || "#2f7fd1" }}>
                    <span style={{ fontSize: "1.5rem" }}>{map.topic?.emoji}</span> {map.topic?.title}
                  </div>
                  <div className="mm-branches">
                    {map.branches.map((br, i) => (
                      <div className="mm-branch" key={i}>
                        <div className="mm-lesson">{br.emoji ? <span>{br.emoji} </span> : null}{br.lesson}</div>
                        <ul className="mm-leaves">
                          {br.children.map((c, j) => (
                            <li key={j} className={`mm-leaf ${c.kind}`}>
                              <span className="mm-dot">{c.kind === "golden" ? "⭐" : "•"}</span>
                              <span>{c.label}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              <button type="button" className="btn btn-ghost btn-block mt16" onClick={onBack}>{t("back")}</button>
            </div>
          ) : (
            <>
              <div className="section-title"><h2>🗺️ {t("mindmaps")}</h2></div>
              <div className="muted small mb16">{t("mindmapsHint")}</div>
              {topics.filter((tp) => tp.hasContent).length === 0 ? (
                <div className="card empty-state"><div className="ico">🗺️</div><h3>{t("mindmapEmpty")}</h3></div>
              ) : (
                <div className="grid grid-2">
                  {topics.filter((tp) => tp.hasContent).map((tp) => (
                    <button type="button" key={tp.slug} className="card mm-card" onClick={() => openClassic(tp.slug)} style={{ textAlign: "start", cursor: "pointer" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                        <span className="mm-emoji" style={{ background: tp.color || "#2f7fd1" }}>{tp.emoji}</span>
                        <div>
                          <div style={{ fontWeight: 800 }}>{tp.title}</div>
                          <div className="small muted">{tp.branches} {t("mindmapLessons")}</div>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              )}
              <button type="button" className="btn btn-ghost btn-block mt16" onClick={onBack}>{t("back")}</button>
            </>
          )}
        </>
      )}

      {toast && (
        <div style={{ position: "fixed", bottom: 88, left: "50%", transform: "translateX(-50%)", background: "#0f172a", color: "#fff", padding: "10px 16px", borderRadius: 999, fontSize: 13, zIndex: 50, boxShadow: "0 8px 24px rgba(0,0,0,.2)" }}>
          {toast}
        </div>
      )}
    </div>
  );
}
