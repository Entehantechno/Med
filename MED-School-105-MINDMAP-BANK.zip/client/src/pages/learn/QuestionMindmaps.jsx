import { useEffect, useState } from "react";
import { useApp } from "../../context.jsx";
import { api } from "../../api.js";

/* Small chip row: from a question → its linked mindmaps.
   Used in Browse, Flashcards, Lesson, etc. Two clicks to mastery. */
export default function QuestionMindmaps({ questionId }) {
  const { lang } = useApp();
  const [maps, setMaps] = useState(null);

  useEffect(() => {
    if (!questionId) return;
    setMaps(null);
    api.get(`/learn/questions/${questionId}/mindmaps?lang=${lang}`).then((d) => setMaps(d.mindmaps || [])).catch(() => setMaps([]));
  }, [questionId, lang]);

  if (!maps || maps.length === 0) return null;

  return (
    <div style={{ display: "flex", flexWrap: "wrap", gap: 8, alignItems: "center", marginTop: 10 }}>
      <span className="small muted" style={{ fontSize: 12 }}>{lang === "fa" ? "🧠 نقشه‌های مرتبط:" : "🧠 Linked maps:"}</span>
      {maps.map((m) => (
        <button key={m.slug} type="button"
          onClick={() => {
            // navigate to mindmap detail via event — LearnApp listens to medlab-go
            // store the slug in session to auto-open it
            try { sessionStorage.setItem("openMindmap", m.slug); } catch {}
            window.dispatchEvent(new CustomEvent("medlab-go", { detail: "mindmap" }));
            window.dispatchEvent(new CustomEvent("medlab-toast", { detail: lang === "fa" ? `باز کردن: ${m.title}` : `Opening: ${m.title}` }));
          }}
          className="badge" style={{
            background: m.type === "approach" ? "#fef3c7" : "#dbeafe",
            color: "#1e293b", border: "1px solid #e2e8f0", padding: "4px 10px", borderRadius: 999, fontSize: 12, cursor: "pointer", display: "flex", alignItems: "center", gap: 6
          }}>
          {m.type === "approach" ? "🧭" : "🧠"} {m.title}
        </button>
      ))}
    </div>
  );
}
