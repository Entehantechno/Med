import { useEffect, useState } from "react";
import { api } from "../../api.js";

export default function MindmapBankAdmin() {
  const [items, setItems] = useState(null);
  const [editing, setEditing] = useState(null);
  const [msg, setMsg] = useState("");

  const load = () => {
    api.get("/admin/mindmap-bank?lang=fa").then((d) => setItems(d.items || [])).catch(() => setItems([]));
  };
  useEffect(load, []);

  const save = async () => {
    if (!editing?.slug || !editing?.title_fa) return setMsg("slug و عنوان فارسی required");
    try {
      const g = editing.graph || JSON.parse(editing.graph_json || "{}");
      if (!g.nodes) throw new Error("graph.nodes missing");
      await api.post("/admin/mindmap-bank", { ...editing, graph: g });
      setMsg("ذخیره شد");
      setEditing(null);
      load();
    } catch (e) { setMsg(e.message || "خطا"); }
  };

  const del = async (slug) => {
    if (!confirm(`حذف ${slug}؟`)) return;
    await api.delete(`/admin/mindmap-bank/${slug}`);
    load();
  };

  const seed = async () => {
    await api.post("/admin/mindmap-bank/seed");
    load();
    setMsg("seed شد");
  };

  if (!items) return <div className="card"><div className="skeleton" style={{ height: 200 }} /></div>;

  return (
    <div className="page">
      <div className="section-title"><h2>🧠 بانک مایندمپ و اپروچ (پرمیوم)</h2>
        <div style={{ display: "flex", gap: 8 }}>
          <button type="button" className="btn btn-ghost btn-sm" onClick={seed}>seed 11</button>
          <button type="button" className="btn btn-primary btn-sm" onClick={() => setEditing({ slug: "", title_fa: "", title_en: "", type: "mind", system: "other", level: "core", summary_fa: "", summary_en: "", graph_json: JSON.stringify({ nodes: [{ id: "a", label_fa: "شروع", label_en: "Start", branch: "start", x: 0, y: 0 }], edges: [] }, null, 2) })}>+ جدید</button>
        </div>
      </div>
      {msg && <div className="card" style={{ background: "#f0fdf4", border: "1px solid #bbf7d0", padding: 10 }}>{msg}</div>}
      <div className="card">
        <div style={{ overflow: "auto" }}>
          <table className="table" style={{ width: "100%", minWidth: 700 }}>
            <thead><tr><th>slug</th><th>عنوان</th><th>type</th><th>system</th><th>nodes</th><th></th></tr></thead>
            <tbody>
              {items.map((it) => (
                <tr key={it.slug}>
                  <td style={{ fontFamily: "monospace", fontSize: 12 }}>{it.slug}</td>
                  <td>{it.title}</td>
                  <td>{it.type}</td>
                  <td>{it.system}</td>
                  <td>{it.nodes?.length || 0}</td>
                  <td style={{ display: "flex", gap: 6 }}>
                    <button type="button" className="btn btn-ghost btn-sm" onClick={() => setEditing({ ...it, graph_json: JSON.stringify(it.graph, null, 2) })}>ویرایش</button>
                    <button type="button" className="btn btn-ghost btn-sm" style={{ color: "#dc2626" }} onClick={() => del(it.slug)}>حذف</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {editing && (
        <div className="card mt16" style={{ border: "1.5px solid #2f7fd1" }}>
          <h3>{editing.id ? "ویرایش" : "جدید"}</h3>
          <div className="grid grid-2" style={{ gap: 12 }}>
            <label>slug<input className="input" value={editing.slug} onChange={(e) => setEditing({ ...editing, slug: e.target.value })} /></label>
            <label>type<select className="input" value={editing.type} onChange={(e) => setEditing({ ...editing, type: e.target.value })}><option value="mind">mind</option><option value="approach">approach</option></select></label>
            <label>system<input className="input" value={editing.system} onChange={(e) => setEditing({ ...editing, system: e.target.value })} placeholder="cardio/pulmo/nephro/..." /></label>
            <label>level<select className="input" value={editing.level} onChange={(e) => setEditing({ ...editing, level: e.target.value })}><option value="core">core</option><option value="high_yield">high_yield</option><option value="emergency">emergency</option></select></label>
            <label>title_fa<input className="input" value={editing.title_fa} onChange={(e) => setEditing({ ...editing, title_fa: e.target.value })} /></label>
            <label>title_en<input className="input" value={editing.title_en} onChange={(e) => setEditing({ ...editing, title_en: e.target.value })} /></label>
            <label>summary_fa<input className="input" value={editing.summary_fa} onChange={(e) => setEditing({ ...editing, summary_fa: e.target.value })} /></label>
            <label>summary_en<input className="input" value={editing.summary_en} onChange={(e) => setEditing({ ...editing, summary_en: e.target.value })} /></label>
          </div>
          <label style={{ marginTop: 12 }}>graph_json (nodes + edges)<textarea className="input" rows={14} style={{ fontFamily: "monospace", fontSize: 12 }} value={editing.graph_json} onChange={(e) => setEditing({ ...editing, graph_json: e.target.value })} /></label>
          <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
            <button type="button" className="btn btn-primary" onClick={save}>ذخیره</button>
            <button type="button" className="btn btn-ghost" onClick={() => setEditing(null)}>لغو</button>
          </div>
          <div className="small muted" style={{ marginTop: 8 }}>
            فرمت هر node: {"{ id, label_fa, label_en, branch, x, y }"} — branch: definition/etiology/patho/clinical/workup/treatment/complication/start/question/action
          </div>
        </div>
      )}

      <div className="card mt16">
        <h4>لینک به بانک سؤالات</h4>
        <div className="small muted">هر گره با `question_mindmap_links` به سؤالات لینک می‌شود. از طریق API:</div>
        <pre className="small" style={{ background: "#f8fafc", padding: 10, borderRadius: 8, overflow: "auto" }}>
{`POST /api/admin/mindmap-bank/link  { question_id, mindmap_slug, node_slug, weight }
POST /api/admin/mindmap-bank/unlink { question_id, mindmap_slug }`}
        </pre>
      </div>
    </div>
  );
}
