import { useEffect, useRef, useId, useState } from "react";
import { createPortal } from "react-dom";
import { useApp } from "../context.jsx";
import Icon from "./Icon.jsx";
import { useScrollLock } from "../utils/useScrollLock.js";

/* MED School logo mark (graduation cap in a rounded square). */
function LogoMark() {
  return (
    <div className="logo">
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor"
        strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M2 8l10-4 10 4-10 4L2 8Z" />
        <path d="M6 10.5V15c0 1.1 2.7 2.5 6 2.5s6-1.4 6-2.5v-4.5M22 8v5" />
      </svg>
    </div>
  );
}

export function TopBar({ onHome }) {
  const { t, user, toggleLang, logout, lang, theme, toggleTheme } = useApp();
  // Publish the real header height so sticky elements (path progress card,
  // unit headers) can sit exactly beneath it on every viewport.
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current; if (!el) return;
    const set = () => document.documentElement.style.setProperty("--topbar-h", `${el.offsetHeight}px`);
    set();
    const ro = typeof ResizeObserver !== "undefined" ? new ResizeObserver(set) : null;
    ro?.observe(el);
    return () => ro?.disconnect();
  }, []);
  const goProfile = () => window.dispatchEvent(new CustomEvent("medlab-nav", { detail: "profile" }));
  return (
    <div className="topbar" ref={ref}>
      <button type="button" className="brand" style={{ cursor: "pointer", background: "none", border: "none", padding: 0, textAlign: "start" }} onClick={onHome} aria-label={t("appName")}>
        <LogoMark />
        <div><h1>{t("appName")}</h1><p>{t("appSub")}</p></div>
      </button>
      <div className="topbar-actions">
        {user && (
          <button type="button" className="btn btn-sm btn-ghost" onClick={goProfile} title={t("profile")}>
            <Icon name="user" size={16} /> <span className="small">{lang === "fa" ? user.name_fa : user.name_en}</span>
          </button>
        )}
        <button type="button" className="btn btn-sm btn-ghost icon-btn" onClick={toggleTheme} title={theme === "light" ? t("darkMode") : t("lightMode")} aria-label={theme === "light" ? t("darkMode") : t("lightMode")}>
          <Icon name={theme === "light" ? "moon" : "sun"} size={16} />
        </button>
        <button type="button" className="btn btn-sm btn-ghost" onClick={toggleLang}><Icon name="globe" size={16} /> <span className="icon-lang-label">{t("otherLang")}</span></button>
        {user && <button type="button" className="btn btn-sm btn-danger icon-btn" onClick={logout} title={t("logout")} aria-label={t("logout")}><Icon name="logout" size={16} /></button>}
      </div>
    </div>
  );
}

export function Toast({ msg }) {
  if (!msg) return null;
  return <div className="toast">{msg}</div>;
}

export function Spinner({ label }) {
  return <div className="loading-screen"><div className="spinner" />{label && <div className="muted">{label}</div>}</div>;
}

export function Pill({ kind, children }) {
  return <span className={`pill pill-${kind}`}>{children}</span>;
}

export function Modal({ title, children, onClose: closeCallback, onSave, saveLabel, wide, saveDisabled = false }) {
  const { t } = useApp();
  const [saving,setSaving]=useState(false),[saveError,setSaveError]=useState('');
  const savingRef=useRef(false),errorRef=useRef(null);
  const onClose=()=>{if(!savingRef.current)closeCallback?.();};
  const submit=async()=>{if(savingRef.current||saveDisabled)return;savingRef.current=true;setSaving(true);setSaveError('');try{await onSave?.()}catch(e){setSaveError(e.message||String(e))}finally{savingRef.current=false;setSaving(false)}};
  useEffect(()=>{if(saveError)errorRef.current?.focus()},[saveError]);
  const dialogRef=useRef(null),titleId=useId();
  useEffect(()=>{
    const previous=document.activeElement,dialog=dialogRef.current;
    dialog?.focus();
    const trap=e=>{
      if(e.key!=='Tab'||!dialog)return;
      const visible=el=>{for(let x=el;x&&x!==dialog;x=x.parentElement){const style=getComputedStyle(x);if(x.hidden||style.display==='none'||style.visibility==='hidden')return false;}return true;};
      const items=[...dialog.querySelectorAll('button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea:not(:disabled),a[href],[tabindex="0"]')].filter(visible);
      if(!items.length){e.preventDefault();dialog.focus();return;}
      if(e.shiftKey&&(document.activeElement===items[0]||document.activeElement===dialog)){e.preventDefault();items.at(-1).focus();}
      else if(!e.shiftKey&&(document.activeElement===items.at(-1)||document.activeElement===dialog)){e.preventDefault();items[0].focus();}
    };
    dialog?.addEventListener('keydown',trap);
    return()=>{dialog?.removeEventListener('keydown',trap);if(previous?.isConnected)previous.focus();};
  },[]);

  useScrollLock(true);
  // Escape closes the dialog (standard modal affordance).
  useEffect(() => {
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);
  // Render through a PORTAL on <body>. Many page wrappers (.card, .container)
  // run CSS entrance animations that animate `transform` (softPop / pageIn);
  // an element with an active/filling transform becomes the containing block
  // for position:fixed descendants, so the dialog would anchor to the middle
  // of the (very long) page instead of the viewport — forcing admins to scroll
  // for ages to reach the create-card form. Portaling to <body> removes every
  // such ancestor so .modal-back is always viewport-fixed.
  // See: react.dev/reference/react-dom/createPortal (dialogs use case).
  if (typeof document === "undefined") return null;
  return createPortal(
    <div className="modal-back" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className={`modal${wide ? " modal-wide" : ""}`} ref={dialogRef} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby={titleId}>
        <h3 id={titleId}>{title}</h3>
        <div className="modal-body">{saveError&&<div ref={errorRef} tabIndex={-1} role="alert" className="err-banner">{saveError}</div>}<fieldset disabled={saving} style={{border:0,padding:0,margin:0,minWidth:0}}>{children}</fieldset></div>
        <div className="modal-actions">
          <button type="button" className="btn btn-ghost" disabled={saving} onClick={onClose}>{t("cancel")}</button>
          {onSave && <button type="button" className="btn btn-primary" disabled={saveDisabled||saving} onClick={submit}>{saveLabel || t("save")}</button>}
        </div>
      </div>
    </div>,
    document.body
  );
}

export function StarRating({ score, lang = "fa" }) {
  if (score == null) return null;
  let stars = 0;
  if (score >= 90) stars = 5;
  else if (score >= 75) stars = 4;
  else if (score >= 60) stars = 3;
  else if (score >= 45) stars = 2;
  else if (score > 0) stars = 1;

  return (
    <span className="star-rating" title={lang === "fa" ? `بالاترین نمره: ${score}٪ (${stars} از ۵ ستاره)` : `Best score: ${score}% (${stars}/5 stars)`}
      style={{ display: "inline-flex", alignItems: "center", gap: 2, marginInlineStart: 8, verticalAlign: "middle" }}>
      {[1, 2, 3, 4, 5].map((i) => (
        <span key={i} style={{ color: i <= stars ? "#f59e0b" : "var(--muted-border, #cbd5e1)", fontSize: "0.95rem", lineHeight: 1 }}>
          {i <= stars ? "★" : "☆"}
        </span>
      ))}
      <span className="small muted" style={{ marginInlineStart: 4, fontWeight: 700, fontSize: ".72rem" }}>
        {score}%
      </span>
    </span>
  );
}

export function useToast() {
  // simple imperative toast via state lifted in App; return via window event
  return (msg) => {
    window.dispatchEvent(new CustomEvent("medlab-toast", { detail: msg }));
  };
}
