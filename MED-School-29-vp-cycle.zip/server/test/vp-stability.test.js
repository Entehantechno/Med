/* ================================================================
   vp-stability.test.js — durability / abuse cases for the virtual
   patient so a crafted client cannot 500 the exam or leak keys.
   ================================================================ */
import { describe, it, expect, beforeAll } from "vitest";
import { execSync } from "child_process";
import request from "supertest";
import { initDb } from "../src/db.js";
import { createApp } from "../src/app.js";
import { detectExamRequest, findRecordedResult } from "../src/lib/ai-engine.js";
import { catalogContainsQuery, DEFAULT_LAB_TESTS, DEFAULT_IMAGING } from "../src/data/order-catalog-defaults.js";

let app;
const login = (u, p = "demo") => request(app).post("/api/auth/login").send({ username: u, password: p });
async function token(u, p = "demo") { return (await login(u, p)).body.token; }
const A = (tk) => ({ Authorization: `Bearer ${tk}` });

beforeAll(async () => {
  execSync("node src/seed.js --force", { cwd: process.cwd(), stdio: "ignore" });
  await initDb();
  app = createApp();
});

async function studentId(tk, username) {
  const users = (await request(app).get("/api/users").set(A(tk))).body;
  return users.find((u) => u.username === username).id;
}

async function makeClass(tk, stuId, caseId, extra = {}) {
  const created = await request(app).post("/api/classes").set(A(tk))
    .send({ name_en: `Stab ${Math.random()}`, name_fa: "پایداری", gradingRole: extra.gradingRole || "both",
            maxAttempts: extra.maxAttempts ?? 8,
            logTranscript: extra.logTranscript === true, gradingRubric: extra.gradingRubric });
  const cid = created.body.id;
  await request(app).put(`/api/classes/${cid}/members`).set(A(tk)).send({ userIds: [stuId] });
  await request(app).put(`/api/classes/${cid}/cases`).set(A(tk)).send({ cases: [{ case_id: caseId, weight: 1 }] });
  return cid;
}

describe("detectExamRequest does not steal history questions", () => {
  it("station commands and explicit requests are exam-mode", () => {
    expect(detectExamRequest("معاینه")).toBe(true);
    expect(detectExamRequest("معاینه فیزیکی")).toBe(true);
    expect(detectExamRequest("لطفاً بیمار را معاینه کنید و یافته‌ها را بگویید")).toBe(true);
    expect(detectExamRequest("examine the patient")).toBe(true);
    expect(detectExamRequest("vital signs")).toBe(true);
    expect(detectExamRequest("علائم حیاتی را بگویید")).toBe(true);
    expect(detectExamRequest("شکم را معاینه می‌کنم")).toBe(true);
    expect(detectExamRequest("سمع قلب")).toBe(true);
    expect(detectExamRequest("فشار خون")).toBe(true);
    expect(detectExamRequest("listen to the heart")).toBe(true);
    expect(detectExamRequest("blood pressure")).toBe(true);
  });

  it("past-history and everyday language stay in the patient's voice", () => {
    expect(detectExamRequest("آیا قبلاً معاینه شده‌اید؟")).toBe(false);
    expect(detectExamRequest("قبلا معاینه شدید؟")).toBe(false);
    expect(detectExamRequest("Have you been examined before?")).toBe(false);
    expect(detectExamRequest("Did anyone examine you at the ER?")).toBe(false);
    expect(detectExamRequest("فعالیت فیزیکی دارید؟")).toBe(false);
    expect(detectExamRequest("I have an exam tomorrow")).toBe(false);
    expect(detectExamRequest("فشار خون دارید؟")).toBe(false);
    expect(detectExamRequest("سابقه فشار خون دارید؟")).toBe(false);
    expect(detectExamRequest("آیا فشار خون بالا دارید؟")).toBe(false);
    expect(detectExamRequest("Do you have high blood pressure?")).toBe(false);
    expect(detectExamRequest("Have you ever had hypertension?")).toBe(false);
    expect(detectExamRequest("داروی فشار خون می‌گیرید؟")).toBe(false);
    expect(detectExamRequest("فشار خون بیمار را بگیرید")).toBe(true);
  });
});

describe("findRecordedResult and order catalog matching", () => {
  it("empty query does not match the first recorded result", () => {
    const caseData = { labResults: [{ name_fa: "تروپونین", name_en: "Troponin", result_fa: "بالا" }] };
    expect(findRecordedResult(caseData, "lab", "")).toBeNull();
    expect(findRecordedResult(caseData, "lab", "   ")).toBeNull();
    expect(findRecordedResult(caseData, "lab", "تروپونین")?.name_en).toBe("Troponin");
  });

  it("catalog accepts real lab/imaging names and rejects unknowns", () => {
    expect(catalogContainsQuery(DEFAULT_LAB_TESTS, "تروپونین")).toBe(true);
    expect(catalogContainsQuery(DEFAULT_LAB_TESTS, "کراتینین")).toBe(true);
    expect(catalogContainsQuery(DEFAULT_LAB_TESTS, "منیزیم")).toBe(true);
    expect(catalogContainsQuery(DEFAULT_IMAGING, "ECG")).toBe(true);
    expect(catalogContainsQuery(DEFAULT_LAB_TESTS, "ECG")).toBe(false);
    expect(catalogContainsQuery(DEFAULT_LAB_TESTS, "")).toBe(false);
    expect(catalogContainsQuery(DEFAULT_LAB_TESTS, "zzzzz-not-a-lab")).toBe(false);
  });

  it("short recorded-result aliases do not reverse-match unrelated queries", () => {
    const caseData = { labResults: [{ name_fa: "پتاسیم", name_en: "Potassium", aliases: ["k"], result_fa: "بالا" }] };
    expect(findRecordedResult(caseData, "lab", "serum")).toBeNull();
    expect(findRecordedResult(caseData, "lab", "cbc")).toBeNull();
    expect(findRecordedResult(caseData, "lab", "پتاسیم")?.name_en).toBe("Potassium");
  });
});

describe("evaluate never 500s on abusive payloads", () => {
  it("null / empty session still returns a numeric score", async () => {
    const ttk = await token("teacher");
    const stuId = await studentId(ttk, "40012345");
    const cid = await makeClass(ttk, stuId, 1);
    const stk = await token("40012345");
    const r = await request(app).post("/api/exam/evaluate").set(A(stk))
      .send({ caseId: 1, classId: cid, lang: "fa", durationSec: 10, session: null });
    expect(r.status).toBe(200);
    expect(typeof r.body.score).toBe("number");
  });

  it("huge message arrays and unicode do not crash", async () => {
    const ttk = await token("teacher");
    const stuId = await studentId(ttk, "40022334");
    const cid = await makeClass(ttk, stuId, 1);
    const stk = await token("40022334");
    const messages = [];
    for (let i = 0; i < 400; i++) {
      messages.push({ role: "student", text: "سلام 🙂 \u200f" + "س".repeat(200) });
      messages.push({ role: "patient", text: "درد قفسه سینه" });
    }
    const r = await request(app).post("/api/exam/evaluate").set(A(stk))
      .send({ caseId: 1, classId: cid, lang: "fa", durationSec: 30,
              session: { messages, tests: ["ecg"], imaging: [], ddx: ["ACS"], finalDx: "ACS", problemList: "درد" } });
    expect(r.status).toBe(200);
    expect(typeof r.body.score).toBe("number");
  });

  it("SQL-looking chat text is stored as text, not executed", async () => {
    const ttk = await token("teacher");
    const stuId = await studentId(ttk, "40067890");
    const cid = await makeClass(ttk, stuId, 1, { logTranscript: true });
    const stk = await token("40067890");
    const poison = "درد قفسه سینه'; DROP TABLE users; --";
    const sess = await request(app).post("/api/exam/session-start").set(A(stk))
      .send({ caseId: 1, classId: cid, lang: "fa" });
    expect(sess.status).toBe(200);
    const reply = await request(app).post("/api/exam/patient-reply").set(A(stk))
      .send({ caseId: 1, classId: cid, lang: "fa", userText: poison, history: [] });
    // Either the input filter rejects it (400) or the exam engine treats it as
    // ordinary text (200). In both cases the users table must still exist.
    expect([200, 400]).toContain(reply.status);
    const ev = await request(app).post("/api/exam/evaluate").set(A(stk))
      .send({ caseId: 1, classId: cid, lang: "fa", durationSec: 12,
              sessionId: sess.body.sessionId,
              events: [{ kind: "student_msg", atMs: 1, text: "سلام درد قفسه سینه" }],
              session: { messages: [{ role: "student", text: "سلام درد قفسه سینه" }], tests: [], imaging: [], ddx: [], finalDx: "" } });
    expect(ev.status).toBe(200);
    const still = await request(app).get("/api/users").set(A(ttk));
    expect(still.status).toBe(200);
    expect(Array.isArray(still.body)).toBe(true);
    expect(still.body.some((u) => u.username === "teacher")).toBe(true);
  });

  it("five parallel evaluates on the same class all succeed", async () => {
    const ttk = await token("teacher");
    const usernames = ["40011223", "40022334", "40033445", "40044556", "40055667"];
    const ids = [];
    for (const u of usernames) ids.push(await studentId(ttk, u));
    const created = await request(app).post("/api/classes").set(A(ttk))
      .send({ name_en: `Par ${Math.random()}`, name_fa: "موازی", gradingRole: "history", maxAttempts: 3 });
    const cid = created.body.id;
    await request(app).put(`/api/classes/${cid}/members`).set(A(ttk)).send({ userIds: ids });
    await request(app).put(`/api/classes/${cid}/cases`).set(A(ttk)).send({ cases: [{ case_id: 1, weight: 1 }] });
    const session = { messages: [{ role: "student", text: "سلام" }], tests: [], imaging: [], ddx: [], finalDx: "", problemList: [] };
    const reqs = await Promise.all(usernames.map(async (u) => {
      const stk = await token(u);
      return request(app).post("/api/exam/evaluate").set(A(stk))
        .send({ caseId: 1, classId: cid, lang: "fa", durationSec: 8, session });
    }));
    expect(reqs.every((r) => r.status === 200)).toBe(true);
    expect(reqs.every((r) => typeof r.body.score === "number")).toBe(true);
  });
});

describe("answer-key surfaces stay closed to students", () => {
  it("GET /checklists and /checklists-meta are teacher/admin only", async () => {
    const stk = await token("40012345");
    const a = await request(app).get("/api/checklists").set(A(stk));
    const b = await request(app).get("/api/checklists-meta").set(A(stk));
    expect(a.status).toBe(403);
    expect(b.status).toBe(403);
  });

  it("student case payload does not include checklist_id", async () => {
    const ttk = await token("teacher");
    const stuId = await studentId(ttk, "40033445");
    const cid = await makeClass(ttk, stuId, 1);
    const stk = await token("40033445");
    const r = await request(app).get("/api/cases/1").set(A(stk));
    expect(r.status).toBe(200);
    expect(r.body.checklist_id).toBeUndefined();
    expect(r.body.ddx_fa).toBeUndefined();
    expect(r.body.diagnosis_fa).toBeUndefined();
  });
});

describe("class rubric override actually changes the intern score", () => {
  it("intern class with only history+exam in the rubric scores 100 on a history+exam session", async () => {
    const ttk = await token("teacher");
    const stuId = await studentId(ttk, "40044556");
    const cl = await request(app).post("/api/checklists").set(A(ttk)).send({
      name_fa: "پایداری", name_en: "stability rubric",
      items: [
        { id: "h1", section: "history", weight: 2, fa: "معرفی", en: "Intro", keys: ["سلام", "hello"] },
        { id: "e1", section: "exam", weight: 2, fa: "معاینه", en: "Exam", keys: ["معاینه", "examine"] },
        { id: "w1", section: "workup", weight: 8, fa: "ECG", en: "ECG", keys: ["ecg"] },
      ],
    });
    const c = await request(app).post("/api/cases").set(A(ttk)).send({
      title_fa: "کیس پایداری نمره", title_en: "Rubric stability case",
      age: 40, sex: "male", chief_fa: "درد", chief_en: "Pain",
      checklist_id: cl.body.id,
    });
    const rubric = {
      roles: {
        extern: { sections: ["history", "exam"], weightMode: "items" },
        intern: { sections: ["history", "exam"], weightMode: "items" },
      },
    };
    const classId = await makeClass(ttk, stuId, c.body.id, { gradingRole: "overall", gradingRubric: rubric });
    const stk = await token("40044556");
    const r = await request(app).post("/api/exam/evaluate").set(A(stk)).send({
      caseId: c.body.id, classId, lang: "fa", durationSec: 20,
      session: {
        messages: [
          { role: "student", text: "سلام من دکتر هستم" },
          { role: "student", text: "لطفاً بیمار را معاینه کنید" },
        ],
        tests: [], imaging: [], ddx: [], finalDx: "", problemList: [],
      },
    });
    expect(r.status).toBe(200);
    expect(r.body.meta.gradingScope).toBe("intern");
    expect(r.body.sectionScores.intern).toBe(100);
    expect(r.body.meta.internScore).toBe(100);
    expect(r.body.meta.internScore).not.toBe(r.body.sectionScores.overall);
    expect(r.body.score).toBe(100);            // intern class uses intern rubric, not overall
    expect(r.body.sectionScores.overall).toBeLessThan(100); // workup still failed overall
    expect(r.body.meta.rubric.roles.intern.sections).toEqual(["history", "exam"]);
  });

  it("GET /settings/vp_grading returns a normalised default rubric to teachers", async () => {
    const ttk = await token("teacher");
    const r = await request(app).get("/api/settings/vp_grading").set(A(ttk));
    expect(r.status).toBe(200);
    expect(r.body.roles.extern.sections).toEqual(["history", "exam", "problem_list", "ddx"]);
    expect(r.body.roles.intern.weightMode).toBe("items");
  });

  it("a student cannot read or write the grading panel", async () => {
    const stk = await token("40012345");
    const g = await request(app).get("/api/settings/vp_grading").set(A(stk));
    const p = await request(app).put("/api/settings/vp_grading").set(A(stk)).send({});
    expect(g.status).toBe(403);
    expect(p.status).toBe(403);
  });
});

describe("same-university teachers can review a class they did not create", () => {
  it("peer teacher can fetch the conversation CSV of a classmate's class", async () => {
    const ttk = await token("teacher");
    const atk = await token("admin");
    const peerName = `teacher_peer_${Date.now()}`;
    const created = await request(app).post("/api/users").set(A(atk)).send({
      username: peerName, password: "demo", name_fa: "همکار", name_en: "Peer",
      role: "teacher", university_id: 1,
    });
    expect(created.status).toBe(200);
    const stuId = await studentId(ttk, "40055667");
    const cid = await makeClass(ttk, stuId, 1, { logTranscript: true });
    const stk = await token("40055667");
    const sess = await request(app).post("/api/exam/session-start").set(A(stk)).send({ caseId: 1, classId: cid });
    await request(app).post("/api/exam/evaluate").set(A(stk)).send({
      caseId: 1, classId: cid, lang: "fa", durationSec: 15,
      sessionId: sess.body.sessionId,
      events: [{ kind: "student_msg", atMs: 10, text: "سلام" }, { kind: "finish", atMs: 20 }],
      session: { messages: [{ role: "student", text: "سلام" }], tests: [], imaging: [], ddx: [], finalDx: "" },
    });
    const ptk = await token(peerName, "demo");
    const csv = await request(app).get(`/api/classes/${cid}/conversation-log.csv`).set(A(ptk));
    expect(csv.status).toBe(200);
    expect(csv.text).toContain("student_msg");
  });
});


describe("VP cycle named stages (zip 28)", () => {
  it("GET /cases/:id names stage on 403 access and 404 case for a student with no assignments", async () => {
    const atk = await token("admin");
    const sno = `vp28_${Date.now()}`;
    const created = await request(app).post("/api/users").set(A(atk)).send({
      studentNo: sno, password: "demo", name_fa: "بی‌کیس", name_en: "No cases",
      role: "student", university_id: 1, caseIds: [],
    });
    expect(created.status).toBe(200);
    const stk = await token(sno, "demo");
    const forbidden = await request(app).get("/api/cases/1").set(A(stk));
    expect(forbidden.status).toBe(403);
    expect(forbidden.body.stage).toBe("access");
    const missing = await request(app).get("/api/cases/999999").set(A(stk));
    expect(missing.status).toBe(404);
    expect(missing.body.stage).toBe("case");
  });

  it("scheduled exam with max_attempts=1 then evaluate returns attempts_exhausted", async () => {
    const ttk = await token("teacher");
    const atk = await token("admin");
    const sno = `vp28e_${Date.now()}`;
    const created = await request(app).post("/api/users").set(A(atk)).send({
      studentNo: sno, password: "demo", name_fa: "یک‌بار", name_en: "Once",
      role: "student", university_id: 1, caseIds: [],
    });
    expect(created.status).toBe(200);
    const now = new Date(Date.now() - 3600e3).toISOString();
    const end = new Date(Date.now() + 86400e3).toISOString();
    const exam = await request(app).post("/api/exams").set(A(ttk)).send({
      title_en: "One shot VP", title_fa: "یک‌بار",
      case_ids: [1], starts_at: now, ends_at: end, duration_min: 20, max_attempts: 1,
    });
    expect(exam.status).toBe(200);
    const part = await request(app).put(`/api/exams/${exam.body.id}/participants`).set(A(ttk))
      .send({ studentNos: [sno] });
    expect(part.status).toBe(200);
    const stk = await token(sno, "demo");
    const session = {
      messages: [{ role: "student", text: "سلام من دکتر هستم" }, { role: "patient", text: "درد دارم" }],
      tests: ["ecg"], imaging: [], ddx: ["STEMI"], finalDx: "STEMI",
    };
    const first = await request(app).post("/api/exam/evaluate").set(A(stk))
      .send({ caseId: 1, examId: exam.body.id, lang: "fa", durationSec: 40, session });
    expect(first.status).toBe(200);
    const second = await request(app).post("/api/exam/evaluate").set(A(stk))
      .send({ caseId: 1, examId: exam.body.id, lang: "fa", durationSec: 40, session });
    expect(second.status).toBe(403);
    expect(second.body.reason).toBe("attempts_exhausted");
    expect(second.body.stage).toBe("evaluate");
  });

  it("learner hub GET /learn/vpatient returns JSON with enabled", async () => {
    const ltk = await token("learner", "demo");
    const res = await request(app).get("/api/learn/vpatient").set(A(ltk));
    expect(res.status).toBe(200);
    expect(String(res.headers["content-type"] || "")).toMatch(/json/);
    expect(typeof res.body.enabled).toBe("boolean");
  });

  it("student class cycle: consent status → session → chat → order → evaluate", async () => {
    const ttk = await token("teacher");
    const stuId = await studentId(ttk, "40033445");
    const cid = await makeClass(ttk, stuId, 1, { maxAttempts: 3 });
    const stk = await token("40033445");
    const consent = await request(app).get(`/api/research/consent/status?classId=${cid}`).set(A(stk));
    expect(consent.status).toBe(200);
    const sess = await request(app).post("/api/exam/session-start").set(A(stk))
      .send({ caseId: 1, classId: cid, lang: "fa" });
    expect(sess.status).toBe(200);
    expect(sess.body.sessionId).toBeTruthy();
    const chat = await request(app).post("/api/exam/patient-reply").set(A(stk))
      .send({ caseId: 1, classId: cid, userText: "سلام درد قفسه سینه دارید؟", history: [], lang: "fa" });
    expect(chat.status).toBe(200);
    expect(String(chat.body.text || "").trim()).toBeTruthy();
    const order = await request(app).post("/api/exam/order").set(A(stk))
      .send({ caseId: 1, classId: cid, kind: "lab", query: "تروپونین", lang: "fa" });
    expect(order.status).toBe(200);
    expect(String(order.body.text || "").trim()).toBeTruthy();
    const ev = await request(app).post("/api/exam/evaluate").set(A(stk))
      .send({
        caseId: 1, classId: cid, lang: "fa", durationSec: 30, sessionId: sess.body.sessionId,
        session: {
          messages: [
            { role: "student", text: "سلام درد قفسه سینه دارید؟" },
            { role: "patient", text: chat.body.text },
          ],
          tests: ["تروپونین"], imaging: [], ddx: ["STEMI"], finalDx: "STEMI",
        },
      });
    expect(ev.status).toBe(200);
    expect(ev.body.score).toBeGreaterThanOrEqual(0);
  });
  it("GET /cases/:id 404 stage case when inactive for a learner; teacher still reads it", async () => {
    const ttk = await token("teacher");
    const created = await request(app).post("/api/cases").set(A(ttk))
      .send({ title_en: "Inactive VP", title_fa: "غیرفعال", chief_en: "x", chief_fa: "x" });
    expect(created.status).toBe(200);
    const del = await request(app).delete(`/api/cases/${created.body.id}`).set(A(ttk));
    expect(del.status).toBe(200);
    const ltk = await token("learner");
    const r = await request(app).get(`/api/cases/${created.body.id}`).set(A(ltk));
    expect(r.status).toBe(404);
    expect(r.body.stage).toBe("case");
    const teacherRead = await request(app).get(`/api/cases/${created.body.id}`).set(A(ttk));
    expect(teacherRead.status).toBe(200);
    const start = await request(app).post("/api/exam/session-start").set(A(ltk))
      .send({ caseId: created.body.id, lang: "fa" });
    expect(start.status).toBe(404);
    expect(start.body.stage).toBe("case");
  });

  it("POST /research/consent missing study_id is 400 with stage consent", async () => {
    const stk = await token("40012345");
    const r = await request(app).post("/api/research/consent").set(A(stk)).send({});
    expect(r.status).toBe(400);
    expect(r.body.stage).toBe("consent");
    expect(r.body.error).toBe("bad_study_id");
  });

  it("GET /exams and /classes and /cases as a student return JSON arrays (boot lists)", async () => {
    const stk = await token("40012345");
    for (const path of ["/api/exams", "/api/classes", "/api/cases"]) {
      const r = await request(app).get(path).set(A(stk));
      expect(r.status, path).toBe(200);
      expect(String(r.headers["content-type"] || "")).toMatch(/json/);
      expect(Array.isArray(r.body), path).toBe(true);
    }
    const mine = await request(app).get("/api/reports/my").set(A(stk));
    expect(mine.status).toBe(200);
    expect(Array.isArray(mine.body)).toBe(true);
  });
});
