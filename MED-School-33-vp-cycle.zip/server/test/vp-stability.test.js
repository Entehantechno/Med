/* ================================================================
   vp-stability.test.js — durability / abuse cases for the virtual
   patient so a crafted client cannot 500 the exam or leak keys.
   ================================================================ */
import { describe, it, expect, beforeAll } from "vitest";
import { execSync } from "child_process";
import { readFileSync } from "fs";
import { join } from "path";
import request from "supertest";
import { initDb, db } from "../src/db.js";
import { createApp } from "../src/app.js";
import { detectExamRequest, findRecordedResult } from "../src/lib/ai-engine.js";
import { catalogContainsQuery, DEFAULT_LAB_TESTS, DEFAULT_IMAGING } from "../src/data/order-catalog-defaults.js";

let app;
const login = (u, p = "demo") => request(app).post("/api/auth/login").send({ username: u, password: p });
async function token(u, p = "demo") { return (await login(u, p)).body.token; }
const A = (tk) => ({ Authorization: `Bearer ${tk}` });

beforeAll(async () => {
  execSync("node src/seed.js --force", { cwd: process.cwd(), stdio: "ignore" });
  await initDb();
  app = createApp();
});

async function studentId(tk, username) {
  const users = (await request(app).get("/api/users").set(A(tk))).body;
  return users.find((u) => u.username === username).id;
}

async function makeClass(tk, stuId, caseId, extra = {}) {
  const created = await request(app).post("/api/classes").set(A(tk))
    .send({ name_en: `Stab ${Math.random()}`, name_fa: "پایداری", gradingRole: extra.gradingRole || "both",
            maxAttempts: extra.maxAttempts ?? 8,
            logTranscript: extra.logTranscript === true, gradingRubric: extra.gradingRubric });
  const cid = created.body.id;
  await request(app).put(`/api/classes/${cid}/members`).set(A(tk)).send({ userIds: [stuId] });
  await request(app).put(`/api/classes/${cid}/cases`).set(A(tk)).send({ cases: [{ case_id: caseId, weight: 1 }] });
  return cid;
}

describe("detectExamRequest does not steal history questions", () => {
  it("station commands and explicit requests are exam-mode", () => {
    expect(detectExamRequest("معاینه")).toBe(true);
    expect(detectExamRequest("معاینه فیزیکی")).toBe(true);
    expect(detectExamRequest("لطفاً بیمار را معاینه کنید و یافته‌ها را بگویید")).toBe(true);
    expect(detectExamRequest("examine the patient")).toBe(true);
    expect(detectExamRequest("vital signs")).toBe(true);
    expect(detectExamRequest("علائم حیاتی را بگویید")).toBe(true);
    expect(detectExamRequest("شکم را معاینه می‌کنم")).toBe(true);
    expect(detectExamRequest("سمع قلب")).toBe(true);
    expect(detectExamRequest("فشار خون")).toBe(true);
    expect(detectExamRequest("listen to the heart")).toBe(true);
    expect(detectExamRequest("blood pressure")).toBe(true);
  });

  it("past-history and everyday language stay in the patient's voice", () => {
    expect(detectExamRequest("آیا قبلاً معاینه شده‌اید؟")).toBe(false);
    expect(detectExamRequest("قبلا معاینه شدید؟")).toBe(false);
    expect(detectExamRequest("Have you been examined before?")).toBe(false);
    expect(detectExamRequest("Did anyone examine you at the ER?")).toBe(false);
    expect(detectExamRequest("فعالیت فیزیکی دارید؟")).toBe(false);
    expect(detectExamRequest("I have an exam tomorrow")).toBe(false);
    expect(detectExamRequest("فشار خون دارید؟")).toBe(false);
    expect(detectExamRequest("سابقه فشار خون دارید؟")).toBe(false);
    expect(detectExamRequest("آیا فشار خون بالا دارید؟")).toBe(false);
    expect(detectExamRequest("Do you have high blood pressure?")).toBe(false);
    expect(detectExamRequest("Have you ever had hypertension?")).toBe(false);
    expect(detectExamRequest("داروی فشار خون می‌گیرید؟")).toBe(false);
    expect(detectExamRequest("فشار خون بیمار را بگیرید")).toBe(true);
  });
});

describe("findRecordedResult and order catalog matching", () => {
  it("empty query does not match the first recorded result", () => {
    const caseData = { labResults: [{ name_fa: "تروپونین", name_en: "Troponin", result_fa: "بالا" }] };
    expect(findRecordedResult(caseData, "lab", "")).toBeNull();
    expect(findRecordedResult(caseData, "lab", "   ")).toBeNull();
    expect(findRecordedResult(caseData, "lab", "تروپونین")?.name_en).toBe("Troponin");
  });

  it("catalog accepts real lab/imaging names and rejects unknowns", () => {
    expect(catalogContainsQuery(DEFAULT_LAB_TESTS, "تروپونین")).toBe(true);
    expect(catalogContainsQuery(DEFAULT_LAB_TESTS, "کراتینین")).toBe(true);
    expect(catalogContainsQuery(DEFAULT_LAB_TESTS, "منیزیم")).toBe(true);
    expect(catalogContainsQuery(DEFAULT_IMAGING, "ECG")).toBe(true);
    expect(catalogContainsQuery(DEFAULT_LAB_TESTS, "ECG")).toBe(false);
    expect(catalogContainsQuery(DEFAULT_LAB_TESTS, "")).toBe(false);
    expect(catalogContainsQuery(DEFAULT_LAB_TESTS, "zzzzz-not-a-lab")).toBe(false);
  });

  it("short recorded-result aliases do not reverse-match unrelated queries", () => {
    const caseData = { labResults: [{ name_fa: "پتاسیم", name_en: "Potassium", aliases: ["k"], result_fa: "بالا" }] };
    expect(findRecordedResult(caseData, "lab", "serum")).toBeNull();
    expect(findRecordedResult(caseData, "lab", "cbc")).toBeNull();
    expect(findRecordedResult(caseData, "lab", "پتاسیم")?.name_en).toBe("Potassium");
  });
});

describe("evaluate never 500s on abusive payloads", () => {
  it("null / empty session still returns a numeric score", async () => {
    const ttk = await token("teacher");
    const stuId = await studentId(ttk, "40012345");
    const cid = await makeClass(ttk, stuId, 1);
    const stk = await token("40012345");
    const r = await request(app).post("/api/exam/evaluate").set(A(stk))
      .send({ caseId: 1, classId: cid, lang: "fa", durationSec: 10, session: null });
    expect(r.status).toBe(200);
    expect(typeof r.body.score).toBe("number");
  });

  it("huge message arrays and unicode do not crash", async () => {
    const ttk = await token("teacher");
    const stuId = await studentId(ttk, "40022334");
    const cid = await makeClass(ttk, stuId, 1);
    const stk = await token("40022334");
    const messages = [];
    for (let i = 0; i < 400; i++) {
      messages.push({ role: "student", text: "سلام 🙂 \u200f" + "س".repeat(200) });
      messages.push({ role: "patient", text: "درد قفسه سینه" });
    }
    const r = await request(app).post("/api/exam/evaluate").set(A(stk))
      .send({ caseId: 1, classId: cid, lang: "fa", durationSec: 30,
              session: { messages, tests: ["ecg"], imaging: [], ddx: ["ACS"], finalDx: "ACS", problemList: "درد" } });
    expect(r.status).toBe(200);
    expect(typeof r.body.score).toBe("number");
  });

  it("SQL-looking chat text is stored as text, not executed", async () => {
    const ttk = await token("teacher");
    const stuId = await studentId(ttk, "40067890");
    const cid = await makeClass(ttk, stuId, 1, { logTranscript: true });
    const stk = await token("40067890");
    const poison = "درد قفسه سینه'; DROP TABLE users; --";
    const sess = await request(app).post("/api/exam/session-start").set(A(stk))
      .send({ caseId: 1, classId: cid, lang: "fa" });
    expect(sess.status).toBe(200);
    const reply = await request(app).post("/api/exam/patient-reply").set(A(stk))
      .send({ caseId: 1, classId: cid, lang: "fa", userText: poison, history: [] });
    // Either the input filter rejects it (400) or the exam engine treats it as
    // ordinary text (200). In both cases the users table must still exist.
    expect([200, 400]).toContain(reply.status);
    const ev = await request(app).post("/api/exam/evaluate").set(A(stk))
      .send({ caseId: 1, classId: cid, lang: "fa", durationSec: 12,
              sessionId: sess.body.sessionId,
              events: [{ kind: "student_msg", atMs: 1, text: "سلام درد قفسه سینه" }],
              session: { messages: [{ role: "student", text: "سلام درد قفسه سینه" }], tests: [], imaging: [], ddx: [], finalDx: "" } });
    expect(ev.status).toBe(200);
    const still = await request(app).get("/api/users").set(A(ttk));
    expect(still.status).toBe(200);
    expect(Array.isArray(still.body)).toBe(true);
    expect(still.body.some((u) => u.username === "teacher")).toBe(true);
  });

  it("five parallel evaluates on the same class all succeed", async () => {
    const ttk = await token("teacher");
    const usernames = ["40011223", "40022334", "40033445", "40044556", "40055667"];
    const ids = [];
    for (const u of usernames) ids.push(await studentId(ttk, u));
    const created = await request(app).post("/api/classes").set(A(ttk))
      .send({ name_en: `Par ${Math.random()}`, name_fa: "موازی", gradingRole: "history", maxAttempts: 3 });
    const cid = created.body.id;
    await request(app).put(`/api/classes/${cid}/members`).set(A(ttk)).send({ userIds: ids });
    await request(app).put(`/api/classes/${cid}/cases`).set(A(ttk)).send({ cases: [{ case_id: 1, weight: 1 }] });
    const session = { messages: [{ role: "student", text: "سلام" }], tests: [], imaging: [], ddx: [], finalDx: "", problemList: [] };
    const reqs = await Promise.all(usernames.map(async (u) => {
      const stk = await token(u);
      return request(app).post("/api/exam/evaluate").set(A(stk))
        .send({ caseId: 1, classId: cid, lang: "fa", durationSec: 8, session });
    }));
    expect(reqs.every((r) => r.status === 200)).toBe(true);
    expect(reqs.every((r) => typeof r.body.score === "number")).toBe(true);
  });
});

describe("answer-key surfaces stay closed to students", () => {
  it("GET /checklists and /checklists-meta are teacher/admin only", async () => {
    const stk = await token("40012345");
    const a = await request(app).get("/api/checklists").set(A(stk));
    const b = await request(app).get("/api/checklists-meta").set(A(stk));
    expect(a.status).toBe(403);
    expect(b.status).toBe(403);
  });

  it("student case payload does not include checklist_id", async () => {
    const ttk = await token("teacher");
    const stuId = await studentId(ttk, "40033445");
    const cid = await makeClass(ttk, stuId, 1);
    const stk = await token("40033445");
    const r = await request(app).get("/api/cases/1").set(A(stk));
    expect(r.status).toBe(200);
    expect(r.body.checklist_id).toBeUndefined();
    expect(r.body.ddx_fa).toBeUndefined();
    expect(r.body.diagnosis_fa).toBeUndefined();
  });
});

describe("class rubric override actually changes the intern score", () => {
  it("intern class with only history+exam in the rubric scores 100 on a history+exam session", async () => {
    const ttk = await token("teacher");
    const stuId = await studentId(ttk, "40044556");
    const cl = await request(app).post("/api/checklists").set(A(ttk)).send({
      name_fa: "پایداری", name_en: "stability rubric",
      items: [
        { id: "h1", section: "history", weight: 2, fa: "معرفی", en: "Intro", keys: ["سلام", "hello"] },
        { id: "e1", section: "exam", weight: 2, fa: "معاینه", en: "Exam", keys: ["معاینه", "examine"] },
        { id: "w1", section: "workup", weight: 8, fa: "ECG", en: "ECG", keys: ["ecg"] },
      ],
    });
    const c = await request(app).post("/api/cases").set(A(ttk)).send({
      title_fa: "کیس پایداری نمره", title_en: "Rubric stability case",
      age: 40, sex: "male", chief_fa: "درد", chief_en: "Pain",
      checklist_id: cl.body.id,
    });
    const rubric = {
      roles: {
        extern: { sections: ["history", "exam"], weightMode: "items" },
        intern: { sections: ["history", "exam"], weightMode: "items" },
      },
    };
    const classId = await makeClass(ttk, stuId, c.body.id, { gradingRole: "overall", gradingRubric: rubric });
    const stk = await token("40044556");
    const r = await request(app).post("/api/exam/evaluate").set(A(stk)).send({
      caseId: c.body.id, classId, lang: "fa", durationSec: 20,
      session: {
        messages: [
          { role: "student", text: "سلام من دکتر هستم" },
          { role: "student", text: "لطفاً بیمار را معاینه کنید" },
        ],
        tests: [], imaging: [], ddx: [], finalDx: "", problemList: [],
      },
    });
    expect(r.status).toBe(200);
    expect(r.body.meta.gradingScope).toBe("intern");
    expect(r.body.sectionScores.intern).toBe(100);
    expect(r.body.meta.internScore).toBe(100);
    expect(r.body.meta.internScore).not.toBe(r.body.sectionScores.overall);
    expect(r.body.score).toBe(100);            // intern class uses intern rubric, not overall
    expect(r.body.sectionScores.overall).toBeLessThan(100); // workup still failed overall
    expect(r.body.meta.rubric.roles.intern.sections).toEqual(["history", "exam"]);
  });

  it("GET /settings/vp_grading returns a normalised default rubric to teachers", async () => {
    const ttk = await token("teacher");
    const r = await request(app).get("/api/settings/vp_grading").set(A(ttk));
    expect(r.status).toBe(200);
    expect(r.body.roles.extern.sections).toEqual(["history", "exam", "problem_list", "ddx"]);
    expect(r.body.roles.intern.weightMode).toBe("items");
  });

  it("a student cannot read or write the grading panel", async () => {
    const stk = await token("40012345");
    const g = await request(app).get("/api/settings/vp_grading").set(A(stk));
    const p = await request(app).put("/api/settings/vp_grading").set(A(stk)).send({});
    expect(g.status).toBe(403);
    expect(p.status).toBe(403);
  });
});

describe("same-university teachers can review a class they did not create", () => {
  it("peer teacher can fetch the conversation CSV of a classmate's class", async () => {
    const ttk = await token("teacher");
    const atk = await token("admin");
    const peerName = `teacher_peer_${Date.now()}`;
    const created = await request(app).post("/api/users").set(A(atk)).send({
      username: peerName, password: "demo", name_fa: "همکار", name_en: "Peer",
      role: "teacher", university_id: 1,
    });
    expect(created.status).toBe(200);
    const stuId = await studentId(ttk, "40055667");
    const cid = await makeClass(ttk, stuId, 1, { logTranscript: true });
    const stk = await token("40055667");
    const sess = await request(app).post("/api/exam/session-start").set(A(stk)).send({ caseId: 1, classId: cid });
    await request(app).post("/api/exam/evaluate").set(A(stk)).send({
      caseId: 1, classId: cid, lang: "fa", durationSec: 15,
      sessionId: sess.body.sessionId,
      events: [{ kind: "student_msg", atMs: 10, text: "سلام" }, { kind: "finish", atMs: 20 }],
      session: { messages: [{ role: "student", text: "سلام" }], tests: [], imaging: [], ddx: [], finalDx: "" },
    });
    const ptk = await token(peerName, "demo");
    const csv = await request(app).get(`/api/classes/${cid}/conversation-log.csv`).set(A(ptk));
    expect(csv.status).toBe(200);
    expect(csv.text).toContain("student_msg");
  });
});


describe("VP cycle named stages (zip 28)", () => {
  it("GET /cases/:id names stage on 403 access and 404 case for a student with no assignments", async () => {
    const atk = await token("admin");
    const sno = `vp28_${Date.now()}`;
    const created = await request(app).post("/api/users").set(A(atk)).send({
      studentNo: sno, password: "demo", name_fa: "بی‌کیس", name_en: "No cases",
      role: "student", university_id: 1, caseIds: [],
    });
    expect(created.status).toBe(200);
    const stk = await token(sno, "demo");
    const forbidden = await request(app).get("/api/cases/1").set(A(stk));
    expect(forbidden.status).toBe(403);
    expect(forbidden.body.stage).toBe("access");
    const missing = await request(app).get("/api/cases/999999").set(A(stk));
    expect(missing.status).toBe(404);
    expect(missing.body.stage).toBe("case");
  });

  it("scheduled exam with max_attempts=1 then evaluate returns attempts_exhausted", async () => {
    const ttk = await token("teacher");
    const atk = await token("admin");
    const sno = `vp28e_${Date.now()}`;
    const created = await request(app).post("/api/users").set(A(atk)).send({
      studentNo: sno, password: "demo", name_fa: "یک‌بار", name_en: "Once",
      role: "student", university_id: 1, caseIds: [],
    });
    expect(created.status).toBe(200);
    const now = new Date(Date.now() - 3600e3).toISOString();
    const end = new Date(Date.now() + 86400e3).toISOString();
    const exam = await request(app).post("/api/exams").set(A(ttk)).send({
      title_en: "One shot VP", title_fa: "یک‌بار",
      case_ids: [1], starts_at: now, ends_at: end, duration_min: 20, max_attempts: 1,
    });
    expect(exam.status).toBe(200);
    const part = await request(app).put(`/api/exams/${exam.body.id}/participants`).set(A(ttk))
      .send({ studentNos: [sno] });
    expect(part.status).toBe(200);
    const stk = await token(sno, "demo");
    const session = {
      messages: [{ role: "student", text: "سلام من دکتر هستم" }, { role: "patient", text: "درد دارم" }],
      tests: ["ecg"], imaging: [], ddx: ["STEMI"], finalDx: "STEMI",
    };
    const first = await request(app).post("/api/exam/evaluate").set(A(stk))
      .send({ caseId: 1, examId: exam.body.id, lang: "fa", durationSec: 40, session });
    expect(first.status).toBe(200);
    const second = await request(app).post("/api/exam/evaluate").set(A(stk))
      .send({ caseId: 1, examId: exam.body.id, lang: "fa", durationSec: 40, session });
    expect(second.status).toBe(403);
    expect(second.body.reason).toBe("attempts_exhausted");
    expect(second.body.stage).toBe("evaluate");
  });

  it("learner hub GET /learn/vpatient returns JSON with enabled", async () => {
    const ltk = await token("learner", "demo");
    const res = await request(app).get("/api/learn/vpatient").set(A(ltk));
    expect(res.status).toBe(200);
    expect(String(res.headers["content-type"] || "")).toMatch(/json/);
    expect(typeof res.body.enabled).toBe("boolean");
  });

  it("student class cycle: consent status → session → chat → order → evaluate", async () => {
    const ttk = await token("teacher");
    const stuId = await studentId(ttk, "40033445");
    const cid = await makeClass(ttk, stuId, 1, { maxAttempts: 3 });
    const stk = await token("40033445");
    const consent = await request(app).get(`/api/research/consent/status?classId=${cid}`).set(A(stk));
    expect(consent.status).toBe(200);
    const sess = await request(app).post("/api/exam/session-start").set(A(stk))
      .send({ caseId: 1, classId: cid, lang: "fa" });
    expect(sess.status).toBe(200);
    expect(sess.body.sessionId).toBeTruthy();
    const chat = await request(app).post("/api/exam/patient-reply").set(A(stk))
      .send({ caseId: 1, classId: cid, userText: "سلام درد قفسه سینه دارید؟", history: [], lang: "fa" });
    expect(chat.status).toBe(200);
    expect(String(chat.body.text || "").trim()).toBeTruthy();
    const order = await request(app).post("/api/exam/order").set(A(stk))
      .send({ caseId: 1, classId: cid, kind: "lab", query: "تروپونین", lang: "fa" });
    expect(order.status).toBe(200);
    expect(String(order.body.text || "").trim()).toBeTruthy();
    const ev = await request(app).post("/api/exam/evaluate").set(A(stk))
      .send({
        caseId: 1, classId: cid, lang: "fa", durationSec: 30, sessionId: sess.body.sessionId,
        session: {
          messages: [
            { role: "student", text: "سلام درد قفسه سینه دارید؟" },
            { role: "patient", text: chat.body.text },
          ],
          tests: ["تروپونین"], imaging: [], ddx: ["STEMI"], finalDx: "STEMI",
        },
      });
    expect(ev.status).toBe(200);
    expect(ev.body.score).toBeGreaterThanOrEqual(0);
  });
  it("GET /cases/:id 404 stage case when inactive for a learner; teacher still reads it", async () => {
    const ttk = await token("teacher");
    const created = await request(app).post("/api/cases").set(A(ttk))
      .send({ title_en: "Inactive VP", title_fa: "غیرفعال", chief_en: "x", chief_fa: "x" });
    expect(created.status).toBe(200);
    const del = await request(app).delete(`/api/cases/${created.body.id}`).set(A(ttk));
    expect(del.status).toBe(200);
    const ltk = await token("learner");
    const r = await request(app).get(`/api/cases/${created.body.id}`).set(A(ltk));
    expect(r.status).toBe(404);
    expect(r.body.stage).toBe("case");
    const teacherRead = await request(app).get(`/api/cases/${created.body.id}`).set(A(ttk));
    expect(teacherRead.status).toBe(200);
    const start = await request(app).post("/api/exam/session-start").set(A(ltk))
      .send({ caseId: created.body.id, lang: "fa" });
    expect(start.status).toBe(404);
    expect(start.body.stage).toBe("case");
  });

  it("POST /research/consent missing study_id is 400 with stage consent", async () => {
    const stk = await token("40012345");
    const r = await request(app).post("/api/research/consent").set(A(stk)).send({});
    expect(r.status).toBe(400);
    expect(r.body.stage).toBe("consent");
    expect(r.body.error).toBe("bad_study_id");
  });

  it("GET /exams and /classes and /cases as a student return JSON arrays (boot lists)", async () => {
    const stk = await token("40012345");
    for (const path of ["/api/exams", "/api/classes", "/api/cases"]) {
      const r = await request(app).get(path).set(A(stk));
      expect(r.status, path).toBe(200);
      expect(String(r.headers["content-type"] || "")).toMatch(/json/);
      expect(Array.isArray(r.body), path).toBe(true);
    }
    const mine = await request(app).get("/api/reports/my").set(A(stk));
    expect(mine.status).toBe(200);
    expect(Array.isArray(mine.body)).toBe(true);
  });
});

describe("zip-30 admin/teacher VP wiring + corrupt payloads", () => {
  it("Admin.jsx actually mounts VpConversations when that tab is selected", () => {
    const src = readFileSync(join(process.cwd(), "../client/src/pages/Admin.jsx"), "utf8");
    expect(src).toMatch(/tab === ["']vpConversations["']\s*&&\s*<VpConversations/);
    expect(src).toMatch(/function VpConversations/);
    expect(src).toMatch(/api\.get\("\/cases"\)\.then\(\(d\) => setCases\(Array\.isArray\(d\) \? d : \[\]\)\)/);
    expect(src).toMatch(/api\.get\("\/classes"\)\.then\(\(d\) => setClasses/);
    expect(src).toMatch(/api\.get\("\/exams"\)\.then\(\(d\) => setExams/);
    expect(src).toContain("p?.__err || loadErr");
    expect(src).toMatch(/reports\/attempts\?type=\$\{type\}/);
    expect(src).toMatch(/\.catch\(\(e\) => \{ setRows\(\[\]\)/);
  });

  it("GET /classes/conversations is JSON even with an empty inbox", async () => {
    const ttk = await token("teacher");
    const r = await request(app).get("/api/classes/conversations").set(A(ttk));
    expect(r.status).toBe(200);
    expect(Array.isArray(r.body.attempts)).toBe(true);
  });

  it("student class detail hides a deactivated case; teacher still sees it", async () => {
    const ttk = await token("teacher");
    const stuId = await studentId(ttk, "40012345");
    const created = await request(app).post("/api/cases").set(A(ttk))
      .send({ title_en: "Soon inactive", title_fa: "غیرفعال‌شونده", chief_en: "x", chief_fa: "x" });
    expect(created.status).toBe(200);
    const cid = await makeClass(ttk, stuId, created.body.id);
    const del = await request(app).delete(`/api/cases/${created.body.id}`).set(A(ttk));
    expect(del.status).toBe(200);
    const stk = await token("40012345");
    const studentView = await request(app).get(`/api/classes/${cid}`).set(A(stk));
    expect(studentView.status).toBe(200);
    expect((studentView.body.cases || []).some((c) => c.case_id === created.body.id)).toBe(false);
    const teacherView = await request(app).get(`/api/classes/${cid}`).set(A(ttk));
    expect(teacherView.status).toBe(200);
    const row = (teacherView.body.cases || []).find((c) => c.case_id === created.body.id);
    expect(row).toBeTruthy();
    expect(row.active).toBe(false);
    const start = await request(app).post("/api/exam/session-start").set(A(stk))
      .send({ caseId: created.body.id, classId: cid, lang: "fa" });
    expect(start.status).toBe(404);
    expect(start.body.stage).toBe("case");
  });

  it("corrupt case data_json does not 500 class detail or member attempts", async () => {
    const ttk = await token("teacher");
    const stuId = await studentId(ttk, "40012345");
    const created = await request(app).post("/api/cases").set(A(ttk))
      .send({ title_en: "Corrupt JSON", title_fa: "خراب", chief_en: "x", chief_fa: "x" });
    expect(created.status).toBe(200);
    const cid = await makeClass(ttk, stuId, created.body.id);
    db.prepare("UPDATE cases SET data_json=? WHERE id=?").run("NOT JSON", created.body.id);
    const teacherView = await request(app).get(`/api/classes/${cid}`).set(A(ttk));
    expect(teacherView.status).toBe(200);
    expect(String(teacherView.headers["content-type"] || "")).toMatch(/json/);
    const attempts = await request(app).get(`/api/classes/${cid}/members/${stuId}/attempts`).set(A(ttk));
    expect(attempts.status).toBe(200);
    expect(Array.isArray(attempts.body.attempts)).toBe(true);
  });

  it("evaluate still 200 when the case checklist JSON is corrupt", async () => {
    const ttk = await token("teacher");
    const ch = await request(app).post("/api/checklists").set(A(ttk))
      .send({ name_fa: "خراب", name_en: "corrupt", items: [{ id: "x", text_fa: "a", text_en: "a", weight: 1 }] });
    expect(ch.status).toBe(200);
    db.prepare("UPDATE checklists SET items_json=? WHERE id=?").run("NOT JSON", ch.body.id);
    const lists = await request(app).get("/api/checklists").set(A(ttk));
    expect(lists.status).toBe(200);
    const created = await request(app).post("/api/cases").set(A(ttk))
      .send({ title_en: "Bad checklist", title_fa: "چک‌لیست خراب", chief_en: "x", chief_fa: "x", checklist_id: ch.body.id });
    expect(created.status).toBe(200);
    const stuId = await studentId(ttk, "40012345");
    const cid = await makeClass(ttk, stuId, created.body.id);
    const stk = await token("40012345");
    const ev = await request(app).post("/api/exam/evaluate").set(A(stk))
      .send({
        caseId: created.body.id, classId: cid, lang: "fa", durationSec: 12,
        session: { messages: [{ role: "student", text: "سلام" }], tests: [], imaging: [], ddx: [], finalDx: "" },
      });
    expect(ev.status).toBe(200);
    expect(ev.body.score).toBeGreaterThanOrEqual(0);
  });

  it("corrupt exam case_ids is an empty list, not HTML 500", async () => {
    const ttk = await token("teacher");
    const now = new Date().toISOString();
    const end = new Date(Date.now() + 3600_000).toISOString();
    const created = await request(app).post("/api/exams").set(A(ttk)).send({
      title_en: "Corrupt ids", title_fa: "خراب", case_ids: [1], starts_at: now, ends_at: end, duration_min: 20,
    });
    expect(created.status).toBe(200);
    db.prepare("UPDATE exams SET case_ids=? WHERE id=?").run("NOT JSON", created.body.id);
    const list = await request(app).get("/api/exams").set(A(ttk));
    expect(list.status).toBe(200);
    const row = list.body.find((e) => e.id === created.body.id);
    expect(row).toBeTruthy();
    expect(Array.isArray(row.case_ids)).toBe(true);
    expect(row.case_ids).toEqual([]);
  });
});

describe("zip-31 teacher review + settings guards", () => {
  it("corrupt exam settings JSON does not 500 GET /settings/exam or /order-catalog", async () => {
    const prev = db.prepare("SELECT value FROM settings WHERE key='exam'").get();
    db.prepare("INSERT INTO settings (key,value) VALUES ('exam',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run("NOT JSON");
    try {
      const stk = await token("40012345");
      const r = await request(app).get("/api/settings/exam").set(A(stk));
      expect(r.status).toBe(200);
      expect(String(r.headers["content-type"] || "")).toMatch(/json/);
      const oc = await request(app).get("/api/order-catalog").set(A(stk));
      expect(oc.status).toBe(200);
      expect(Array.isArray(oc.body.labs)).toBe(true);
      expect(Array.isArray(oc.body.imaging)).toBe(true);
    } finally {
      if (prev) db.prepare("UPDATE settings SET value=? WHERE key='exam'").run(prev.value);
      else db.prepare("DELETE FROM settings WHERE key='exam'").run();
    }
  });

  it("class attempt detail exposes teacher review fields and keeps an adjustment", async () => {
    const ttk = await token("teacher");
    const stuId = await studentId(ttk, "40012345");
    const cid = await makeClass(ttk, stuId, 1, { logTranscript: true });
    const stk = await token("40012345");
    const sess = await request(app).post("/api/exam/session-start").set(A(stk))
      .send({ caseId: 1, classId: cid, lang: "fa" });
    expect(sess.status).toBe(200);
    const ev = await request(app).post("/api/exam/evaluate").set(A(stk)).send({
      caseId: 1, classId: cid, lang: "fa", durationSec: 15, sessionId: sess.body.sessionId,
      session: { messages: [{ role: "student", text: "سلام" }, { role: "lab", text: "Troponin high" }], tests: [], imaging: [], ddx: [], finalDx: "" },
    });
    expect(ev.status).toBe(200);
    const detail = await request(app).get(`/api/classes/${cid}/attempts/${ev.body.attemptId}`).set(A(ttk));
    expect(detail.status).toBe(200);
    expect(detail.body.attempt.id).toBe(ev.body.attemptId);
    expect(detail.body.attempt).toHaveProperty("teacher_status");
    expect(detail.body.attempt).toHaveProperty("teacher_score");
    expect(detail.body.attempt).toHaveProperty("teacher_feedback");
    const rev = await request(app).put(`/api/reports/attempts/${ev.body.attemptId}/review`).set(A(ttk))
      .send({ status: "adjusted", teacher_score: 77, teacher_feedback: "ok" });
    expect(rev.status).toBe(200);
    const again = await request(app).get(`/api/classes/${cid}/attempts/${ev.body.attemptId}`).set(A(ttk));
    expect(again.status).toBe(200);
    expect(again.body.attempt.teacher_status).toBe("adjusted");
    expect(again.body.attempt.teacher_score).toBe(77);
    expect(again.body.attempt.teacher_feedback).toBe("ok");
  });
});

describe("zip-32 teacher results + daily reward + assignments", () => {
  it("GET /reports/attempts as teacher is a JSON array", async () => {
    const ttk = await token("teacher");
    const r = await request(app).get("/api/reports/attempts?type=vp").set(A(ttk));
    expect(r.status).toBe(200);
    expect(Array.isArray(r.body)).toBe(true);
  });

  it("GET /assignments/:userId survives corrupt case JSON", async () => {
    const ttk = await token("teacher");
    const stuId = await studentId(ttk, "40012345");
    const created = await request(app).post("/api/cases").set(A(ttk))
      .send({ title_en: "Asg corrupt", title_fa: "تخصیص خراب", chief_en: "x", chief_fa: "x" });
    expect(created.status).toBe(200);
    const put = await request(app).put(`/api/assignments/${stuId}`).set(A(ttk))
      .send({ caseIds: [created.body.id], maxAttempts: 1 });
    expect(put.status).toBe(200);
    db.prepare("UPDATE cases SET data_json=? WHERE id=?").run("NOT JSON", created.body.id);
    const r = await request(app).get(`/api/assignments/${stuId}`).set(A(ttk));
    expect(r.status).toBe(200);
    expect(Array.isArray(r.body)).toBe(true);
  });

  it("student class list nCases ignores deactivated cases", async () => {
    const ttk = await token("teacher");
    const stuId = await studentId(ttk, "40012345");
    const created = await request(app).post("/api/cases").set(A(ttk))
      .send({ title_en: "Count inactive", title_fa: "شمارش", chief_en: "x", chief_fa: "x" });
    const cid = await makeClass(ttk, stuId, created.body.id);
    await request(app).delete(`/api/cases/${created.body.id}`).set(A(ttk));
    const stk = await token("40012345");
    const list = await request(app).get("/api/classes").set(A(stk));
    expect(list.status).toBe(200);
    const row = list.body.find((c) => c.id === cid);
    expect(row).toBeTruthy();
    expect(row.nCases).toBe(0);
  });

  it("daily-reward with a non-daily caseId is 400 stage report", async () => {
    const atk = await token("admin");
    await request(app).put("/api/admin/vpatient").set(A(atk))
      .send({ config: { enabled: true, premium_only: false, in_daily: true, daily_gems: 15 } });
    const ltk = await token("learner");
    const r = await request(app).post("/api/learn/vpatient/daily-reward").set(A(ltk)).send({ caseId: 999999 });
    expect(r.status).toBe(400);
    expect(r.body.error).toBe("not_daily_case");
    expect(r.body.stage).toBe("report");
  });
});

describe("zip-33 assigned-case home + corrupt banks", () => {
  it("StudentHome surfaces direct-assigned cases as a caseList module", () => {
    const src = readFileSync(join(process.cwd(), "../client/src/pages/StudentHome.jsx"), "utf8");
    expect(src).toContain('key: "caseList"');
    expect(src).toContain('api.get("/cases"');
  });

  it("GET /cases/:id with corrupt JSON is 404 stage case", async () => {
    const ttk = await token("teacher");
    const created = await request(app).post("/api/cases").set(A(ttk))
      .send({ title_en: "Corrupt case", title_fa: "خراب", chief_en: "x", chief_fa: "x" });
    expect(created.status).toBe(200);
    db.prepare("UPDATE cases SET data_json=? WHERE id=?").run("NOT JSON", created.body.id);
    const r = await request(app).get(`/api/cases/${created.body.id}`).set(A(ttk));
    expect(r.status).toBe(404);
    expect(r.body.stage).toBe("case");
  });

  it("GET /flashcards survives a corrupt card", async () => {
    const ttk = await token("teacher");
    const created = await request(app).post("/api/flashcards").set(A(ttk))
      .send({ title_en: "Corrupt card", title_fa: "کارت خراب", questionText_en: "q", questionText_fa: "س" });
    expect(created.status).toBe(200);
    db.prepare("UPDATE flashcards SET data_json=? WHERE id=?").run("NOT JSON", created.body.id);
    const r = await request(app).get("/api/flashcards").set(A(ttk));
    expect(r.status).toBe(200);
    expect(Array.isArray(r.body)).toBe(true);
  });

  it("GET /cases-export.csv survives a corrupt case", async () => {
    const ttk = await token("teacher");
    const created = await request(app).post("/api/cases").set(A(ttk))
      .send({ title_en: "Csv corrupt", title_fa: "خروجی", chief_en: "x", chief_fa: "x" });
    db.prepare("UPDATE cases SET data_json=? WHERE id=?").run("NOT JSON", created.body.id);
    const r = await request(app).get("/api/cases-export.csv").set(A(ttk));
    expect(r.status).toBe(200);
    expect(String(r.headers["content-type"] || "")).toMatch(/csv/i);
  });

  it("GET /reports/progress/:userId as teacher is JSON", async () => {
    const ttk = await token("teacher");
    const stuId = await studentId(ttk, "40012345");
    const r = await request(app).get(`/api/reports/progress/${stuId}`).set(A(ttk));
    expect(r.status).toBe(200);
    expect(Array.isArray(r.body.line)).toBe(true);
    expect(Array.isArray(r.body.radar)).toBe(true);
  });

  it("GET /admin/vpatient/cases as admin is JSON", async () => {
    const atk = await token("admin");
    const r = await request(app).get("/api/admin/vpatient/cases").set(A(atk));
    expect(r.status).toBe(200);
    expect(Array.isArray(r.body.cases)).toBe(true);
  });
});
