/* ================================================================
   master-bank.test.js — guards for the authoritative competitive
   question bank that ships in tools/master-bank.

   The bank is the bilingual pre-internship collection plus the
   residency (دستیاری) collection taken from the official medschool
   archive, split by tools/master-bank/build.mjs into numbered import
   payload parts. These tests lock the structural and editorial
   invariants the importer, curator and exam simulator rely on:

     1. part files exist, are numbered contiguously and match the
        bankbootstrap filename family;
     2. every question has a Persian stem, four Persian options and a
        valid single key — or is explicitly marked keyless (no official
        key / multi-answer item), in which case it never enters a graded
        surface;
     3. subjects/chapters/years cover the full competitive syllabus;
     4. residency classification is stable (the distribution is the
        audited anchor set);
     5. no stem is duplicated within a bank.
   ================================================================ */
import { describe, it, expect } from "vitest";
import { createHash } from "node:crypto";
import { readFileSync, readdirSync, existsSync } from "fs";
import { dirname, join } from "path";
import { fileURLToPath } from "url";

const here = dirname(fileURLToPath(import.meta.url));
const bank = join(here, "../../tools/master-bank");

/* Same family grammar as bankbootstrap.js payloadFiles(). */
const PART_RE = /^import-payload\.(master-preint|master-residency)\.part(\d+)\.json$/;

function loadFamily(family) {
  const files = readdirSync(bank)
    .filter((n) => PART_RE.test(n))
    .sort();
  const parts = [];
  for (const n of files) {
    const m = n.match(PART_RE);
    if (m[1] !== family) continue;
    const body = JSON.parse(readFileSync(join(bank, n), "utf8"));
    parts.push({ name: n, index: Number(m[2]), body });
  }
  return parts.sort((a, b) => a.index - b.index);
}

describe("master bank payload structure", () => {
  it("ships contiguous numbered parts for both exam families", () => {
    for (const [family, expectedParts] of [["master-preint", 51], ["master-residency", 3]]) {
      const parts = loadFamily(family);
      expect(parts.map((p) => p.index)).toEqual(Array.from({ length: expectedParts }, (_, i) => i + 1));
      for (const p of parts) expect(Array.isArray(p.body.questions)).toBe(true);
    }
  });

  it("keeps every part at or below the 220-question split (last part carries the remainder)", () => {
    for (const family of ["master-preint", "master-residency"]) {
      const parts = loadFamily(family);
      for (const p of parts.slice(0, -1)) expect(p.body.questions.length).toBe(220);
      expect(parts.at(-1).body.questions.length).toBeGreaterThan(0);
      expect(parts.at(-1).body.questions.length).toBeLessThanOrEqual(220);
    }
  });

  it("declares the competitive program, exam type and overflow-to-premium on every part", () => {
    const pre = loadFamily("master-preint");
    for (const p of pre) {
      expect(p.body.program).toBe("preint");
      expect(p.body.exam_type).toBe("preinternship");
      expect(p.body.overflowToPremium).toBe(true);
      expect(p.body.maxPerLesson).toBeGreaterThan(0);
      expect(p.body.part.n).toBe(p.index);
    }
    const res = loadFamily("master-residency");
    for (const p of res) {
      // both competitive banks run under the app's "preint" program; the
      // residency collection is distinguished by exam_type
      expect(p.body.program).toBe("preint");
      expect(p.body.exam_type).toBe("residency");
      expect(p.body.overflowToPremium).toBe(true);
      expect(p.body.part.n).toBe(p.index);
    }
  });
});

describe("master pre-internship bank", () => {
  const parts = loadFamily("master-preint");
  const rows = parts.flatMap((p) => p.body.questions);

  it("contains 11,120 audited questions (11,089 keyed + 31 explicitly keyless)", () => {
    expect(rows).toHaveLength(11120);
    const keyless = rows.filter((r) => r.keyless === true || r.correct_index === null);
    expect(keyless).toHaveLength(31);
    const lowConf = keyless.filter((r) => r.key_source === "low-confidence");
    expect(lowConf.map((r) => r.tags[0]).sort()).toEqual(
      ["QB-00584", "QB-00707", "QB-01104", "QB-01248"].sort()
    );
    const multi = keyless.filter((r) => r.key_source === "multi-answer");
    expect(multi).toHaveLength(27);
    for (const r of multi) expect(r.tags).toContain("multi-answer");
    expect(rows.filter((r) => !r.keyless).length).toBe(11089);
  });

  it("keeps part22 reviewed multi-answer items ungraded and the imaging correction explicit", () => {
    for (const id of ["QB-04877", "QB-04880"]) {
      const q = rows.find((r) => r.tags[0] === id);
      expect(q.keyless).toBe(true);
      expect(q.correct_index).toBeNull();
      expect(q.key_source).toBe("multi-answer");
      expect(q.tags).toContain("multi-answer");
      expect(q.options_why_fa.filter((w) => w.startsWith("گزینه صحیح: "))).toHaveLength(2);
    }
    const imaging = rows.find((r) => r.tags[0] === "QB-04886");
    expect(imaging.correct_index).toBe(0);
    expect(imaging.key_source).toBe("registry-corrected");
    expect(imaging.options_fa[0]).toBe("گرافی قفسه ی صدری در حالت بازدم عمیق");
  });

  it("keeps part22 batch2 educational structure and explicit option reasoning", () => {
    const batch = parts.find((p) => p.index === 22).body.questions.slice(30, 60);
    expect(batch).toHaveLength(30);
    for (const q of batch) {
      expect(q.explanation_fa.length).toBeGreaterThan(300);
      expect(q.micro.lead_fa.length).toBeGreaterThan(20);
      expect(q.micro.golden_fa.length).toBeGreaterThan(20);
      expect(q.micro.points_fa).toHaveLength(4);
      expect(new Set(q.micro.points_fa).size).toBe(4);
      expect(q.micro.points_fa.every((p) => p.length > 20)).toBe(true);
      expect(q.options_why_fa).toHaveLength(4);
      q.options_why_fa.forEach((why, i) => {
        if (!q.keyless) {
          expect(why.startsWith(i === q.correct_index ? "گزینه صحیح: " : "دلیل رد گزینه: ")).toBe(true);
        } else {
          expect(/^(گزینه صحیح: |دلیل رد گزینه: )/.test(why)).toBe(true);
        }
      });
    }
  });

  it("gives every card a Persian stem, four options and a usable key", () => {
    for (const r of rows) {
      expect((r.question_fa || "").trim().length).toBeGreaterThan(12);
      expect(Array.isArray(r.options_fa)).toBe(true);
      expect(r.options_fa).toHaveLength(4);
      expect(r.options_fa.every((o) => String(o || "").trim().length > 0)).toBe(true);
      if (r.keyless === true) {
        expect(r.correct_index === null).toBe(true);
      } else {
        expect(Number.isInteger(r.correct_index)).toBe(true);
        expect(r.correct_index).toBeGreaterThanOrEqual(0);
        expect(r.correct_index).toBeLessThanOrEqual(3);
        expect(["official", "rapid", "registry-corrected"]).toContain(r.key_source);
      }
    }
  });

  it("attaches four option rationales and a lesson to every keyed card", () => {
    for (const r of rows.filter((x) => !x.keyless)) {
      expect(Array.isArray(r.options_why_fa)).toBe(true);
      expect(r.options_why_fa).toHaveLength(4);
      expect((r.explanation_fa || "").trim().length).toBeGreaterThan(40);
    }
  });

  it("has no duplicated stems and no duplicated question tags", () => {
    const stems = new Set();
    const tags = new Set();
    for (const r of rows) {
      expect(stems.has(r.question_fa)).toBe(false);
      stems.add(r.question_fa);
      const id = (r.tags || [])[0];
      expect(id).toBeTruthy();
      expect(tags.has(id)).toBe(false);
      tags.add(id);
    }
  });

  it("covers every competitive exam year 1393–1400 and 1402–1403", () => {
    const byYear = {};
    for (const r of rows) byYear[r.year_num] = (byYear[r.year_num] || 0) + 1;
    for (const y of [1393, 1394, 1395, 1396, 1397, 1398, 1399, 1400, 1402, 1403]) {
      expect(byYear[y]).toBeGreaterThan(100);
    }
  });

  it("labels every question with a subject (chapter when the booklet gives one)", () => {
    for (const r of rows) {
      expect((r.subject_fa || "").trim()).toBeTruthy();
      expect(["major", "minor"]).toContain(r.subject_track);
    }
    // chapters are populated wherever the booklet grouped questions by them;
    // the newer 1402/1403 sittings were not chapter-headed in the source
    expect(rows.filter((r) => (r.chapter_fa || "").trim()).length).toBeGreaterThan(3000);
  });
});

describe("master residency (دستیاری) bank", () => {
  const parts = loadFamily("master-residency");
  const rows = parts.flatMap((p) => p.body.questions);

  it("contains 484 questions, all keyed, in 220/220/44 parts", () => {
    expect(parts.map((p) => p.body.questions.length)).toEqual([220, 220, 44]);
    expect(rows).toHaveLength(484);
    expect(rows.every((r) => r.keyless !== true && Number.isInteger(r.correct_index))).toBe(true);
    for (const r of rows) {
      expect(r.key_source).toBe("official");
      expect(r.options_fa).toHaveLength(4);
      expect(Array.isArray(r.options_why_fa) && r.options_why_fa).toHaveLength(4);
    }
  });

  it("holds the audited subject distribution (classification anchors)", () => {
    const counts = {};
    for (const r of rows) counts[r.subject_fa] = (counts[r.subject_fa] || 0) + 1;
    expect(counts).toEqual({
      "داخلی": 114,
      "جراحی": 49,
      "اورولوژی": 22,
      "کودکان": 76,
      "نورولوژی": 20,
      "زنان و زایمان": 50,
      "بیماری‌های عفونی": 30,
      "رادیولوژی": 8,
      "پاتولوژی": 14,
      "روانپزشکی": 16,
      "پوست": 14,
      "ارتوپدی": 14,
      "چشم‌پزشکی": 12,
      "گوش و حلق و بینی": 12,
      "آمار و اپیدمیولوژی": 14,
      "فارماکولوژی": 13,
      "اخلاق پزشکی": 5,
      "ایمنی‌شناسی": 1,
    });
  });

  it("covers all three audited residency courses (51, 52, 53)", () => {
    const tags = rows.flatMap((r) => r.tags || []);
    expect(tags.filter((t) => t === "residency-course-۵۱").length).toBe(158);
    expect(tags.filter((t) => t === "residency-course-۵۲").length).toBe(126);
    expect(tags.filter((t) => t === "residency-course-۵۳").length).toBe(200);
  });
});

describe("master bank sources", () => {
  it("keeps the raw extraction sources out of the payload directory listing contract", () => {
    // sources/ is a build input (~100 MB) and must never be treated as a payload.
    // Since v66 the lean release ships only the numbered payload parts (the
    // build script and raw sources stay in the dev tree), so build.mjs is
    // optional here — what matters is that no stray JSON sits next to the parts.
    expect(existsSync(join(bank, "sources"))).toBe(false);
    const stray = readdirSync(bank).filter(
      (n) => n.endsWith(".json") && !PART_RE.test(n)
    );
    expect(stray).toEqual([]);
  });
});


// round48 is a versioned continuation, not permission to weaken historical guards.
// For later edited records the old full hash must equal the new PRE-EDIT full
// hash; round48 then checks all protected fields against that baseline.
const round49Baseline = JSON.parse(readFileSync(join(here, "fixtures/round49-preservation.json"), "utf8"));
const round48Baseline = JSON.parse(readFileSync(join(here, "fixtures/round48-preservation.json"), "utf8"));

// round47: the user explicitly deferred six items. Hashes were taken from
// round46 BEFORE normalising away only the authorised Persian teaching fields.
describe("round47 exact editorial boundaries", () => {
  const fixture = JSON.parse(readFileSync(join(here, "fixtures/round47-preservation.json"), "utf8"));
  const stable = (x) => Array.isArray(x) ? x.map(stable)
    : x && typeof x === "object"
      ? Object.fromEntries(Object.keys(x).sort().map((k) => [k, stable(x[k])])) : x;
  const digest = (x) => createHash("sha256").update(JSON.stringify(stable(x))).digest("hex");
  const current = Object.fromEntries([22, 23].map((part) => [part,
    JSON.parse(readFileSync(join(bank, `import-payload.master-preint.part${part}.json`), "utf8"))]));

  it("preserves every non-educational field, all keys and every out-of-scope question", () => {
    let changed = 0;
    for (const part of [22, 23]) {
      const { questions, ...metadata } = current[part];
      expect(digest(metadata)).toBe(fixture.parts[part].metadata);
      expect(questions).toHaveLength(fixture.parts[part].questions.length);
      questions.forEach((q, index) => {
        const baseline = fixture.parts[part].questions[index];
        const check = JSON.parse(JSON.stringify(q));
        if (baseline.edited) {
          expect(digest(q), baseline.id).not.toBe(baseline.full);
          changed++;
          delete check.explanation_fa;
          delete check.options_why_fa;
          for (const key of ["lead_fa", "golden_fa", "points_fa"]) delete check.micro[key];
        }
        const later = round48Baseline.parts[part].questions[index];
        let expected = baseline.protected;
        if (later.edited) {
          expect(baseline.edited, baseline.id).toBe(false); // disjoint releases
          expect(later.full, baseline.id).toBe(baseline.full); // baseline continuity
          delete check.explanation_fa;
          delete check.options_why_fa;
          for (const key of ["lead_fa", "golden_fa", "points_fa"]) delete check.micro[key];
          expected = later.protected;
        }
        expect(digest(check), baseline.id).toBe(expected);
      });
    }
    expect(changed).toBe(194);
  });

  it("keeps all six deferred questions entirely identical to round46", () => {
    expect(fixture.scope).toHaveLength(200);
    expect(fixture.deferred.sort()).toEqual(["22:142", "22:145", "22:166", "22:174", "22:214", "23:32"].sort());
    for (const id of fixture.deferred) {
      const [part, number] = id.split(":").map(Number);
      expect(digest(current[part].questions[number - 1])).toBe(fixture.parts[part].questions[number - 1].full);
      expect(fixture.parts[part].questions[number - 1].edited).toBe(false);
    }
  });

  it("provides 194 case interpretations, four explicit rationales and four clinical points", () => {
    const explanations = new Set();
    const leads = new Set();
    for (const part of [22, 23]) {
      current[part].questions.forEach((q, index) => {
        if (!fixture.parts[part].questions[index].edited) return;
        expect(q.explanation_fa.length).toBeGreaterThan(300);
        expect(q.options_why_fa).toHaveLength(4);
        expect(new Set(q.options_why_fa).size).toBe(4);
        q.options_why_fa.forEach((why, i) => {
          expect(why.startsWith(i === q.correct_index ? "گزینه صحیح: " : "دلیل رد گزینه: ")).toBe(true);
          expect(why.length).toBeGreaterThan(35);
        });
        expect(q.micro.lead_fa.length).toBeGreaterThan(20);
        expect(q.micro.lead_fa).not.toContain("\n");
        expect(q.micro.golden_fa.length).toBeGreaterThan(20);
        expect(q.micro.points_fa).toHaveLength(4);
        expect(new Set(q.micro.points_fa).size).toBe(4);
        expect(q.micro.points_fa.every((point) => point.includes(":") && point.length > 20)).toBe(true);
        explanations.add(q.explanation_fa);
        leads.add(q.micro.lead_fa);
      });
    }
    expect(explanations.size).toBe(194);
    expect(leads.size).toBe(194);
  });

  it("preserves other payloads byte-for-byte except the explicitly guarded round48 continuation", () => {
    expect(Object.keys(fixture.otherBanks)).toHaveLength(52);
    for (const [name, expected] of Object.entries(fixture.otherBanks)) {
      if (name === "import-payload.master-preint.part24.json") {
        // Every part24 record/field is checked below. Its pre-edit file must
        // still be byte-identical to the round46/round47 historical file.
        expect(round48Baseline.originalFullBanks[name], name).toBe(expected);
      } else {
        expect(createHash("sha256").update(readFileSync(join(bank, name))).digest("hex"), name).toBe(expected);
      }
    }
  });
});

// round48 baseline is from the SHA-256-verified round47 ZIP, never post-edit data.
describe("round48 exact editorial boundaries", () => {
  const fixture = round48Baseline;
  const stable = (x) => Array.isArray(x) ? x.map(stable)
    : x && typeof x === "object"
      ? Object.fromEntries(Object.keys(x).sort().map((k) => [k, stable(x[k])])) : x;
  const digest = (x) => createHash("sha256").update(JSON.stringify(stable(x))).digest("hex");
  const current = Object.fromEntries([22, 23, 24].map((part) => [part,
    JSON.parse(readFileSync(join(bank, `import-payload.master-preint.part${part}.json`), "utf8"))]));
  const scope = [
    ...Array.from({ length: 180 }, (_, i) => `23:${i + 41}`),
    ...Array.from({ length: 20 }, (_, i) => `24:${i + 1}`),
  ];
  const deferred = [68, 77, 88, 95, 98, 102, 118, 137, 144, 152, 157, 163, 176, 182, 190, 195, 202, 203].map((n) => `23:${n}`);
  const edited = scope.filter((id) => !deferred.includes(id));

  it("changes exactly 182 approved records and only the five Persian teaching fields", () => {
    expect(fixture.baseline_sha256).toBe("97e6bebdf7d9f501384f6a9e80c9311be9b928254c2384c8040cd60e45ced666");
    expect(fixture.scope).toEqual(scope);
    expect(fixture.deferred).toEqual(deferred);
    expect(fixture.edited).toEqual(edited);
    const changed = [];
    for (const part of [22, 23, 24]) {
      const { questions, ...metadata } = current[part];
      expect(digest(metadata)).toBe(fixture.parts[part].metadata);
      expect(questions).toHaveLength(fixture.parts[part].questions.length);
      questions.forEach((q, index) => {
        const baseline = fixture.parts[part].questions[index];
        const id = `${part}:${index + 1}`;
        expect(baseline.id).toBe(id);
        expect(baseline.edited).toBe(edited.includes(id));
        const check = JSON.parse(JSON.stringify(q));
        if (baseline.edited) {
          expect(digest(q), id).not.toBe(baseline.full);
          changed.push(id);
          delete check.explanation_fa;
          delete check.options_why_fa;
          for (const key of ["lead_fa", "golden_fa", "points_fa"]) delete check.micro[key];
        }
        const later = round49Baseline.parts[part].questions[index];
        let expected = baseline.protected;
        if (later.edited) {
          expect(baseline.edited, id).toBe(false);
          expect(later.full, id).toBe(baseline.full);
          delete check.explanation_fa;
          delete check.options_why_fa;
          for (const key of ["lead_fa", "golden_fa", "points_fa"]) delete check.micro[key];
          expected = later.protected;
        }
        expect(digest(check), id).toBe(expected);
      });
    }
    expect(changed).toEqual(edited);
    expect(changed).toHaveLength(182);
  });

  it("keeps the 18 newly deferred and six earlier deferred records entirely unchanged", () => {
    const prior = ["22:142", "22:145", "22:166", "22:174", "22:214", "23:32"];
    expect(fixture.prior_deferred).toEqual(prior);
    for (const id of [...prior, ...deferred]) {
      const [part, number] = id.split(":").map(Number);
      const baseline = fixture.parts[part].questions[number - 1];
      expect(baseline.edited).toBe(false);
      expect(digest(current[part].questions[number - 1]), id).toBe(baseline.full);
    }
  });

  it("provides 182 distinct case explanations and leads with four rationales and structured points", () => {
    const explanations = new Set(), leads = new Set();
    for (const id of edited) {
      const [part, number] = id.split(":").map(Number);
      const q = current[part].questions[number - 1];
      expect(q.explanation_fa.length, id).toBeGreaterThan(300);
      expect(q.options_why_fa, id).toHaveLength(4);
      expect(new Set(q.options_why_fa).size, id).toBe(4);
      q.options_why_fa.forEach((why, i) => {
        expect(why.startsWith(i === q.correct_index ? "گزینه صحیح: " : "دلیل رد گزینه: "), id).toBe(true);
        expect(why.length, id).toBeGreaterThan(35);
      });
      expect(q.micro.lead_fa.length, id).toBeGreaterThan(20);
      expect(q.micro.lead_fa, id).not.toContain("\n");
      expect(q.micro.golden_fa.length, id).toBeGreaterThan(20);
      expect(q.micro.points_fa, id).toHaveLength(4);
      expect(new Set(q.micro.points_fa).size, id).toBe(4);
      expect(q.micro.points_fa.every((point) => point.includes(":") && point.length > 20), id).toBe(true);
      explanations.add(q.explanation_fa);
      leads.add(q.micro.lead_fa);
    }
    expect(explanations.size).toBe(182);
    expect(leads.size).toBe(182);
  });

  it("leaves all 51 other bank payloads byte-identical and preserves the exact filename inventory", () => {
    expect(Object.keys(fixture.otherBanks)).toHaveLength(51);
    expect(readdirSync(bank).filter((name) => PART_RE.test(name)).sort()).toEqual(Object.keys(fixture.originalFullBanks).sort());
    for (const [name, expected] of Object.entries(fixture.otherBanks)) {
      expect(createHash("sha256").update(readFileSync(join(bank, name))).digest("hex"), name).toBe(expected);
    }
  });
});

// round49 baseline is from the SHA-256-verified round48 ZIP, never post-edit data.
describe("round49 exact editorial boundaries", () => {
  const fixture = round49Baseline;
  const stable = (x) => Array.isArray(x) ? x.map(stable)
    : x && typeof x === "object"
      ? Object.fromEntries(Object.keys(x).sort().map((k) => [k, stable(x[k])])) : x;
  const digest = (x) => createHash("sha256").update(JSON.stringify(stable(x))).digest("hex");
  const current = Object.fromEntries([22, 23, 24].map((part) => [part,
    JSON.parse(readFileSync(join(bank, `import-payload.master-preint.part${part}.json`), "utf8"))]));
  const scope = Array.from({ length: 200 }, (_, i) => `24:${i + 21}`);
  const deferred = [48, 50, 58, 66, 76, 85, 97, 102, 108, 113, 123, 146, 147, 171, 193, 201, 213].map((n) => `24:${n}`);
  const edited = scope.filter((id) => !deferred.includes(id));

  it("changes exactly 183 approved records and only the five Persian teaching fields", () => {
    expect(fixture.baseline_sha256).toBe("fc90ff35ecb1ff9706aa751e27b043cfd6c7e0b84de07d42a058f559a745c4c9");
    expect(fixture.scope).toEqual(scope);
    expect(fixture.deferred).toEqual(deferred);
    expect(fixture.edited).toEqual(edited);
    const changed = [];
    for (const part of [22, 23, 24]) {
      const { questions, ...metadata } = current[part];
      expect(digest(metadata)).toBe(fixture.parts[part].metadata);
      expect(questions).toHaveLength(fixture.parts[part].questions.length);
      questions.forEach((q, index) => {
        const baseline = fixture.parts[part].questions[index];
        const id = `${part}:${index + 1}`;
        expect(baseline.id).toBe(id);
        expect(baseline.edited).toBe(edited.includes(id));
        const check = JSON.parse(JSON.stringify(q));
        if (baseline.edited) {
          expect(digest(q), id).not.toBe(baseline.full);
          changed.push(id);
          delete check.explanation_fa;
          delete check.options_why_fa;
          for (const key of ["lead_fa", "golden_fa", "points_fa"]) delete check.micro[key];
        }
        expect(digest(check), id).toBe(baseline.protected);
      });
    }
    expect(changed).toEqual(edited);
    expect(changed).toHaveLength(183);
  });

  it("keeps the 17 newly deferred and 24 earlier deferred records entirely unchanged", () => {
    const prior = ["22:142", "22:145", "22:166", "22:174", "22:214", "23:32", "23:68", "23:77", "23:88", "23:95", "23:98", "23:102", "23:118", "23:137", "23:144", "23:152", "23:157", "23:163", "23:176", "23:182", "23:190", "23:195", "23:202", "23:203"];
    expect(fixture.prior_deferred).toEqual(prior);
    for (const id of [...prior, ...deferred]) {
      const [part, number] = id.split(":").map(Number);
      const baseline = fixture.parts[part].questions[number - 1];
      expect(baseline.edited).toBe(false);
      expect(digest(current[part].questions[number - 1]), id).toBe(baseline.full);
    }
  });

  it("provides 183 distinct case explanations and leads with four rationales and structured points", () => {
    const explanations = new Set(), leads = new Set();
    for (const id of edited) {
      const [part, number] = id.split(":").map(Number);
      const q = current[part].questions[number - 1];
      expect(q.explanation_fa.length, id).toBeGreaterThan(300);
      expect(q.options_why_fa, id).toHaveLength(4);
      expect(new Set(q.options_why_fa).size, id).toBe(4);
      q.options_why_fa.forEach((why, i) => {
        expect(why.startsWith(i === q.correct_index ? "گزینه صحیح: " : "دلیل رد گزینه: "), id).toBe(true);
        expect(why.length, id).toBeGreaterThan(35);
      });
      expect(q.micro.lead_fa.length, id).toBeGreaterThan(20);
      expect(q.micro.lead_fa, id).not.toContain("\n");
      expect(q.micro.golden_fa.length, id).toBeGreaterThan(20);
      expect(q.micro.points_fa, id).toHaveLength(4);
      expect(new Set(q.micro.points_fa).size, id).toBe(4);
      expect(q.micro.points_fa.every((point) => point.includes(":") && point.length > 20), id).toBe(true);
      explanations.add(q.explanation_fa);
      leads.add(q.micro.lead_fa);
    }
    expect(explanations.size).toBe(183);
    expect(leads.size).toBe(183);
  });

  it("leaves all 51 other bank payloads byte-identical and preserves the exact filename inventory", () => {
    expect(Object.keys(fixture.otherBanks)).toHaveLength(51);
    expect(readdirSync(bank).filter((name) => PART_RE.test(name)).sort()).toEqual(Object.keys(fixture.originalFullBanks).sort());
    for (const [name, expected] of Object.entries(fixture.otherBanks)) {
      expect(createHash("sha256").update(readFileSync(join(bank, name))).digest("hex"), name).toBe(expected);
    }
  });
});
