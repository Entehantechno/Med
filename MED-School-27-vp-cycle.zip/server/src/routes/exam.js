/* ================================================================
   exam.js — Virtual patient chat + evaluation + flashcard submit.
   All AI logic lives server-side; prompts pulled from DB.
   ================================================================ */
import { Router } from "express";
import { db } from "../db.js";
import { authRequired, requireRole } from "../lib/auth.js";
import { patientReply, evaluate, scoreChecklistWithLLM, enrichEvaluationWithLLM, labImagingResult, AI_PROVIDERS, asMessages, resolveAiConfig } from "../lib/ai-engine.js";
import { getSetting, canAccessCase } from "./content.js";
import { DEFAULT_LAB_TESTS, DEFAULT_IMAGING, cleanOrderList, catalogContainsQuery } from "../data/order-catalog-defaults.js";
import { classAttemptInfo } from "./classes.js";
import { examAccess } from "./exams.js";
import { getVpatientConfig, awardVpatientXp, getVpatientAiEffective, getVpatientPromptsEffective, vpatientAccess } from "../lib/vpatient.js";
import { isEnabled } from "../lib/flags.js";
import { audit } from "../lib/audit.js";
import { startSession, getSession, finishSession, loggingEnabledFor, serverElapsedSec } from "../lib/vplogging.js";
import { normalizeRubric, parseClassRubric } from "../lib/grading-rubric.js";

function resolveClassRubric(classId) {
  const global = normalizeRubric(getSetting("vp_grading", null));
  if (!classId) return global;
  const cl = db.prepare("SELECT grading_json FROM classes WHERE id=?").get(classId);
  return parseClassRubric(cl) || global;
}
import { assertConsent, studyForContext } from "../lib/consent.js";
import { recordStudyEvent } from "../lib/research-log.js";
import { getProfile } from "../lib/gamify.js";

// Access is granted by a scheduled exam, class enrollment, OR direct assignment.
//
// Returns { allowed, reason } where reason explains a refusal so the client can
// show something better than a generic 403.
//
// IMPORTANT: this also enforces the attempt BUDGET server-side. The UI disables
// the "start" button once attempts are used up, but a direct API call must be
// refused too — otherwise a student can replay the same scenario unlimited
// times, which pollutes the class gradebook and (for a research study) destroys
// the one-attempt-per-student guarantee the analysis relies on.
function hasAccess(user, caseId, classId, examId) {
  // Competitive learners reach virtual patients through the gated learner
  // feature, NOT class/exam assignments — so check the vpatient access config.
  // Learners are deliberately unlimited (best-score XP policy handles farming).
  if (user.role === "learner") {
    try {
      const p = getProfile(user.id);
      const vp = vpatientAccess(p, user.role);
      return vp.ok ? { allowed: true } : { allowed: false, reason: vp.reason || "off" };
    } catch {
      return { allowed: false, reason: "off" };
    }
  }
  if (user.role !== "student") return { allowed: true };   // teachers/admins: full access (QA)

  /* Research consent gates participation, not grading. If this class/exam
     belongs to a study that requires consent and this student has not given it,
     they cannot enter the encounter at all — which also means no conversation
     can be logged before consent exists. Checked here so every entry point
     (patient-reply, order, evaluate, session-start) inherits it. */
  const consent = assertConsent(user, { classId, examId });
  if (!consent.ok) {
    return { allowed: false, reason: consent.reason, studyId: consent.studyId,
             titleFa: consent.titleFa, titleEn: consent.titleEn,
             consentTextFa: consent.consentTextFa, consentTextEn: consent.consentTextEn,
             ethicsCode: consent.ethicsCode, protocolVersion: consent.protocolVersion };
  }

  const deny = (reason) => ({ allowed: false, reason });
  const budget = (info) => {
    if (!info?.allowed) return deny(info?.reason || "not_assigned");
    // Infinity means "not capped" (staff / learner paths); otherwise count down.
    if (info.remaining === Infinity || info.remaining == null) return { allowed: true };
    if (info.remaining <= 0) return deny("attempts_exhausted");
    return { allowed: true, remaining: info.remaining };
  };

  if (examId) return budget(examAccess(user.id, examId, caseId));
  if (classId) return budget(classAttemptInfo(user.id, classId, caseId));

  if (!canAccessCase(user, caseId)) return deny("not_assigned");

  /* No container was named in the request (the standalone case list). Omitting
     classId must not become a way around the cap, so we work out the budget for
     EVERY path that grants access and refuse only when all of them are spent.
     A student enrolled in two classes that both use this case still has a
     legitimate attempt left for the class that hasn't used its quota. */
  const cid = Number(caseId);
  const budgets = [];

  // (a) every active class that both contains the case and has this student
  const grantingClasses = db.prepare(
    `SELECT c.id, c.max_attempts FROM class_cases cc
       JOIN classes c ON c.id = cc.class_id
       JOIN class_members m ON m.class_id = c.id
      WHERE cc.case_id=? AND m.user_id=? AND c.active=1`
  ).all(cid, user.id);
  for (const cl of grantingClasses) {
    const used = db.prepare(
      "SELECT COUNT(*) n FROM attempts WHERE user_id=? AND case_id=? AND class_id=?"
    ).get(user.id, cid, cl.id).n;
    budgets.push({ kind: "class", id: cl.id, remaining: (cl.max_attempts ?? 1) - used });
  }

  // (b) a direct assignment (this is what the standalone /cases list shows)
  const asg = db.prepare(
    "SELECT max_attempts FROM exam_assignments WHERE user_id=? AND case_id=? AND active=1"
  ).get(user.id, cid);
  if (asg) {
    const used = db.prepare(
      "SELECT COUNT(*) n FROM attempts WHERE user_id=? AND case_id=? AND class_id IS NULL AND exam_id IS NULL"
    ).get(user.id, cid).n;
    budgets.push({ kind: "assignment", id: null, remaining: (asg.max_attempts ?? 1) - used });
  }

  if (!budgets.length) return { allowed: true };        // access via a scheduled exam, etc.
  const best = budgets.reduce((a, b) => (b.remaining > a.remaining ? b : a));
  if (best.remaining <= 0) return deny("attempts_exhausted");
  /* Attribute the attempt to the container whose quota it is spending. Without
     this the attempt would be stored with class_id NULL and would be invisible
     to every budget — i.e. the cap would never actually bite. */
  return { allowed: true, remaining: best.remaining,
    attributedClassId: best.kind === "class" ? best.id : null };
}

/* 403 with a machine-readable reason so the client can say WHY (out of attempts
   vs. never assigned) instead of a generic "not assigned". */
function denyAccess(res, acc, stage = "access") {
  const reason = acc?.reason || "not_assigned";
  const msg = reason === "attempts_exhausted" ? "attempts exhausted"
    : (reason === "consent_required" || reason === "consent_withdrawn") ? "consent required"
    : reason === "off" ? "virtual patient is off"
    : reason === "premium" ? "premium required"
    : reason === "window" ? "exam window closed"
    : "not assigned to this exam";
  // Carrying the study id lets the client jump straight to the consent screen
  // instead of showing a dead-end error. `stage` names the step that refused
  // so the UI can say WHERE the path stopped (session / chat / order / evaluate).
  const extra = acc?.studyId ? {
    studyId: acc.studyId, titleFa: acc.titleFa || "", titleEn: acc.titleEn || "",
    consentTextFa: acc.consentTextFa || "", consentTextEn: acc.consentTextEn || "",
    ethicsCode: acc.ethicsCode || "", protocolVersion: acc.protocolVersion || "",
  } : {};
  return res.status(403).json({ error: msg, reason, stage, ...extra });
}

/* Whether a competitive learner may use the virtual patient right now (feature
   flag + admin switch + optional premium-only). Best-effort require to avoid a
   hard import cycle. */
function learnerVpatientAllowed(user) {
  try {
    const cfg = getVpatientConfig();
    if (!isEnabled("virtual_patient") || !cfg.enabled) return false;
    if (!cfg.premium_only) return true;
    const p = db.prepare("SELECT premium, premium_until FROM learner_profiles WHERE user_id=?").get(user.id);
    if (!p) return false;
    const active = p.premium && (!p.premium_until || new Date(p.premium_until).getTime() >= Date.now());
    return !!active;
  } catch { return false; }
}

// Duration is client-reported, so it is never trusted blindly: it is coerced to
// a finite number of seconds and clamped to a sane window. A negative, NaN or
// absurd value would otherwise flow straight into the research dataset.
const MAX_SESSION_SEC = 6 * 60 * 60;   // 6h hard ceiling for one encounter
function clampDuration(raw) {
  const n = Number(raw);
  if (!Number.isFinite(n) || n < 0) return 0;
  return Math.min(MAX_SESSION_SEC, Math.round(n));
}

const r = Router();

function loadPrompts() {
  const rows = db.prepare("SELECT * FROM prompts").all();
  const out = {}; rows.forEach((p) => (out[p.key] = p.value));
  return out;
}

/* Pick the AI config + prompts for THIS request. Competitive learners (free
   virtual patient, not a class/exam) use the SEPARATE vpatient config; everyone
   else (students, teachers, admins, scheduled exams) uses the shared university
   config. This keeps the two flows fully independent yet code-shared. */
function engineContext(req, body = {}) {
  const isCompetitive = req.user.role === "learner" && !body.classId && !body.examId;
  if (isCompetitive) {
    return { aiCfg: getVpatientAiEffective(), prompts: getVpatientPromptsEffective(), competitive: true };
  }
  return { aiCfg: resolveAiConfig(getSetting("ai", {})), prompts: loadPrompts(), competitive: false };
}
function loadCase(id) {
  const row = db.prepare("SELECT * FROM cases WHERE id=?").get(id);
  if (!row) return null;
  try {
    return { ...JSON.parse(row.data_json), id: row.id, version: row.version, checklist_id: row.checklist_id };
  } catch {
    return null;
  }
}
function loadChecklist(id) {
  const row = db.prepare("SELECT * FROM checklists WHERE id=?").get(id);
  return row ? { id: row.id, items: JSON.parse(row.items_json) } : { items: [] };
}

/* ---- Open an encounter ----
   Called the moment the student enters the case. The server stamps the start
   time here so the recorded duration does not depend on the client's clock, and
   resolves the privacy decision ONCE (snapshot of the class/exam logging
   switch) so a later toggle cannot reinterpret data already collected.
   The row exists even if the student never finishes — an abandoned session is
   itself meaningful for a study (dropout), and it holds no content when
   logging is off. */
r.post("/session-start", authRequired, (req, res) => {
  try {
  const { caseId, classId, examId, lang = "fa" } = req.body || {};
  const caseData = loadCase(caseId);
  if (!caseData) return res.status(404).json({ error: "case not found", stage: "case" });
  const acc = hasAccess(req.user, caseId, classId, examId);
  if (!acc.allowed) return denyAccess(res, acc, "session");
  const ownerClassId = classId || acc.attributedClassId || null;
  const studyId = studyForContext({ classId: ownerClassId, examId })?.id || null;
  const s = startSession({
    userId: req.user.id, caseId: caseData.id,
    classId: ownerClassId, examId: examId || null, lang,
    studyId,
  });
  // Tell the UI which criterion this class grades on, so the student sees it
  // before finishing (extern = up to the differential dx, intern = all sections).
  let gradingScope = "overall";
  if (ownerClassId) {
    const role = db.prepare("SELECT grading_role FROM classes WHERE id=?").get(ownerClassId)?.grading_role;
    if (role === "history") gradingScope = "extern";
    else if (role === "overall") gradingScope = "intern";
  }
  const gradingRubric = resolveClassRubric(ownerClassId);
  if (studyId) {
    recordStudyEvent({
      studyId, userId: req.user.id, eventType: "session_started",
      contextType: examId ? "exam" : "class", contextId: examId || ownerClassId,
      data: { caseId: caseData.id, sessionId: s.sessionId },
    });
  }
  res.json({ ...s, gradingScope, gradingRubric });
  } catch (e) {
    res.status(500).json({ error: "session_failed", stage: "session", message: String(e.message || e).slice(0, 200) });
  }
});

/* ---- Abandoned encounter ----
   Fired from the browser when the student leaves mid-session. Closes the
   session and stores whatever was logged so far. Ownership is enforced inside
   finishSession(), so one student cannot close another's session. */
r.post("/session-abandon", authRequired, (req, res) => {
  const { sessionId, events = [] } = req.body || {};
  if (!sessionId) return res.status(400).json({ error: "session_id_required", stage: "session" });
  const out = finishSession({ sessionId, userId: req.user.id, events, durationSec: 0, attemptId: null });
  if (out.error) return res.status(out.error === "session_not_found" ? 404 : 403).json({ error: out.error, stage: "session" });
  res.json({ ok: true, stored: out.stored, loggingEnabled: out.loggingEnabled });
});

/* ---- Patient chat turn ---- */
r.post("/patient-reply", authRequired, async (req, res) => {
  try {
    const { caseId, userText, history = [], lang = "fa", classId, examId } = req.body || {};
    const acc = hasAccess(req.user, caseId, classId, examId);
    if (!acc.allowed) return denyAccess(res, acc, "chat");
    const text = String(userText || "").trim();
    if (!text) return res.status(400).json({ error: "text_required", stage: "chat" });
    const caseData = loadCase(caseId);
    if (!caseData) return res.status(404).json({ error: "case not found", stage: "case" });
    const { aiCfg, prompts } = engineContext(req, req.body);
    const result = await patientReply({ caseData, userText: text, history, lang, prompts, aiCfg });
    res.json(result);
  } catch (e) {
    res.status(500).json({ error: "chat_failed", stage: "chat", message: String(e.message || e).slice(0, 200) });
  }
});

/* ---- Order a lab test or imaging study -> lab/radiology report in the chat ----
   If the case chart has a recorded result → return it (with an image if any).
   Otherwise the student is told it's NORMAL (AI-worded when a key is set, else a
   deterministic template). `kind` = "lab" | "imaging". */
r.post("/order", authRequired, async (req, res) => {
  try {
    const { caseId, kind = "lab", query = "", lang = "fa", classId, examId } = req.body || {};
    const caseData = loadCase(caseId);
    if (!caseData) return res.status(404).json({ error: "case not found", stage: "case" });
    // Access / attempt budget FIRST so an exhausted student still gets 403
    // (not 400 not_in_catalog) when they post a query that isn't in that kind.
    const acc = hasAccess(req.user, caseId, classId, examId);
    if (!acc.allowed) return denyAccess(res, acc, "order");
    const q = String(query || "").trim();
    if (!q) return res.status(400).json({ error: "query_required", stage: "order" });
    const kindN = kind === "imaging" ? "imaging" : "lab";
    const cat = kindN === "imaging"
      ? cleanOrderList(getSetting("order_catalog_imaging", null), DEFAULT_IMAGING)
      : cleanOrderList(getSetting("order_catalog_lab", null), DEFAULT_LAB_TESTS);
    if (!catalogContainsQuery(cat, q)) {
      return res.status(400).json({ error: "not_in_catalog", stage: "order" });
    }
    const { aiCfg, prompts } = engineContext(req, req.body);
    const result = await labImagingResult({
      caseData, kind: kindN, query: q, lang, prompts, aiCfg,
    });
    res.json(result);
  } catch (e) {
    res.status(500).json({ error: "order_failed", stage: "order", message: String(e.message || e).slice(0, 200) });
  }
});

/* ---- Finish exam -> evaluate + store attempt ---- */
r.post("/evaluate", authRequired, async (req, res) => {
  try {
  const { caseId, lang = "fa", durationSec = 0, classId, examId,
          sessionId = null, events = [] } = req.body || {};
  const session = (req.body?.session && typeof req.body.session === "object") ? req.body.session : {};
  const caseData = loadCase(caseId);
  if (!caseData) return res.status(404).json({ error: "case not found", stage: "case" });
  const acc = hasAccess(req.user, caseId, classId, examId);
  if (!acc.allowed) return denyAccess(res, acc, "evaluate");
  const checklist = loadChecklist(caseData.checklist_id);
  const globalSettings = getSetting("exam", {});
  const { aiCfg, prompts } = engineContext(req, req.body);

  // Per-exam settings override the global defaults when this is a scheduled exam.
  let showAi = globalSettings.showAiAnalysis, showMicro = globalSettings.showMicro;
  if (examId) {
    const ex = db.prepare("SELECT show_ai, show_micro FROM exams WHERE id=?").get(examId);
    if (ex) { showAi = !!ex.show_ai; showMicro = !!ex.show_micro; }
  }

  /* Grading scope from the class the student took this in:
       grading_role "history"  → EXTERN  (score = history + exam + problem list + ddx)
       grading_role "overall"  → INTERN  (score = all sections)
       grading_role "both"/∅   → overall (report still shows both criteria).
     This is what the teacher selected when creating the class; before this
     existed the stored score was ALWAYS the overall one. */
  const ownerClassId = classId || acc.attributedClassId || null;
  let gradingScope = "overall";
  if (ownerClassId) {
    const cl = db.prepare("SELECT grading_role FROM classes WHERE id=?").get(ownerClassId);
    const role = cl?.grading_role;
    if (role === "history") gradingScope = "extern";
    else if (role === "overall") gradingScope = "intern";
  }
  const gradingRubric = resolveClassRubric(ownerClassId);

  // 1) Deterministic keyword checklist score (always available; the AI-free base).
  let evalResult = evaluate({ caseData, checklist, session, lang, scope: gradingScope, rubric: gradingRubric });
  // 2) When an AI key is configured, RE-SCORE the OSCE checklist with the LLM,
  //    which judges each item from the whole encounter (context-aware, not
  //    keyword-matching). Falls back to the keyword score on any error.
  evalResult = await scoreChecklistWithLLM({
    base: evalResult, caseData, checklist, session, lang, aiCfg,
  });
  // 3) Enrich the qualitative feedback + personalized micro-lesson with the LLM.
  evalResult = await enrichEvaluationWithLLM({
    base: evalResult, caseData, session, lang, prompts, aiCfg, scope: gradingScope,
  });
  // 4) Apply the class's grading scope to the FINAL stored score. Externs are
  //    graded up to and including the problem list; interns on every section.
  //    (Fallbacks keep old checklists — without exam/problem-list items —
  //    scoring sanely: extern → history-only score, then overall.)
  const ss = evalResult.sectionScores || {};
  let finalScore = ss.overall ?? evalResult.score ?? 0;
  if (gradingScope === "extern") finalScore = ss.extern ?? ss.history ?? finalScore;
  else if (gradingScope === "intern") finalScore = ss.intern ?? ss.overall ?? finalScore;
  if (finalScore != null) {
    evalResult.score = finalScore;
    evalResult.score10 = Math.round(finalScore / 10);
  }
  // /10 score for OSCE-style review (kept alongside the % for the UI + teacher).
  if (evalResult.score10 == null) evalResult.score10 = Math.round((evalResult.score || 0) / 10);
  evalResult.meta = {
    ...(evalResult.meta || {}),
    gradingScope,
    externScore: ss.extern ?? ss.history ?? null,
    internScore: ss.intern ?? ss.overall ?? null,
  };

  const studentTurns = asMessages(session.messages).filter((m) => m.role === "student").length;
  // Client-reported duration is validated, not trusted: coerce + clamp, and keep
  // the RAW value alongside so an analyst can spot tampering in the study data.
  const durationValidated = clampDuration(durationSec);
  evalResult.meta = {
    ...(evalResult.meta || {}),
    durationSecClient: Number.isFinite(Number(durationSec)) ? Number(durationSec) : null,
    durationSecUsed: durationValidated,
    scoredBy: evalResult.source || "mock",
  };
  // A research study must be able to tell WHICH attempts were LLM-scored and
  // which silently fell back to keyword scoring. Surface + audit it.
  if (evalResult.scoreFallback) {
    evalResult.meta.scoreFallback = evalResult.scoreFallback;
    try {
      audit(req, "vpatient.scoring_fallback", "attempt", {
        caseId: caseData.id, classId: classId || null, examId: examId || null,
        stage: evalResult.scoreFallback.stage, error: String(evalResult.scoreFallback.error || "").slice(0, 500),
        hadApiKey: !!aiCfg?.apiKey,
      });
    } catch { /* auditing must never break the exam */ }
  }

  // strip sections disabled by settings
  const out = { ...evalResult };
  if (!showAi) {
    out.strengths = out.weaknesses = out.missed = out.commonMistakes = [];
    out.suggestion = "";
  }
  if (!showMicro) out.microlearning = "";

  /* PRIVACY: the transcript is stored ONLY when logging is switched on for this
     class/exam. With logging off the attempt still gets its score (grading must
     keep working) but attempts.transcript_json stays NULL — "we did not record
     this conversation" is then literally true, not just a UI claim. */
  const vpSession = sessionId ? getSession(sessionId) : null;
  const logging = vpSession ? !!vpSession.logging_enabled : loggingEnabledFor(ownerClassId, examId);
  evalResult.meta.loggingEnabled = logging;

  const transcriptObj = logging ? {
    ...session,
    microlearning: out.microlearning || "",
    strengths: out.strengths || [],
    weaknesses: out.weaknesses || [],
    suggestion: out.suggestion || "",
  } : null;

  const info = db.prepare(
    `INSERT INTO attempts (user_id,type,case_id,class_id,exam_id,content_version,score,transcript_json,eval_json,
       turns,tests,imaging_count,ddx_count,hints,duration_sec,lang)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
  ).run(
    req.user.id, "vp", caseData.id, ownerClassId, examId || null, caseData.version, evalResult.score,
    transcriptObj ? JSON.stringify(transcriptObj) : null, JSON.stringify(evalResult),
    studentTurns,
    (session.tests || []).length, (session.imaging || []).length, (session.ddx || []).length,
    0, durationValidated, lang
  );

  /* Close the session and persist the timestamped interaction log (when on).
     The server-side start stamp also gives a duration the client cannot fake;
     we keep the smaller of the two so a tampered client value can only ever
     understate, never inflate, the recorded encounter length. */
  let logResult = { stored: 0, loggingEnabled: logging, dropped: 0 };
  if (vpSession) {
    const serverElapsed = serverElapsedSec(vpSession);
    /* The server-measured wall clock is the honest number. A client may claim
       more than it actually spent, so take the smaller of the two; the raw
       client value stays in meta.durationSecClient so tampering is auditable. */
    const finalDuration = Math.max(0, Math.round(Math.min(durationValidated, serverElapsed)));
    logResult = finishSession({ sessionId: vpSession.id, userId: req.user.id, events, durationSec: finalDuration, attemptId: info.lastInsertRowid });
    db.prepare("UPDATE attempts SET duration_sec=? WHERE id=?").run(finalDuration, info.lastInsertRowid);
    evalResult.meta.durationSecServer = Math.round(serverElapsed);
    // What actually landed in attempts.duration_sec, so an analyst never has to
    // guess which of the two candidate values the row holds.
    evalResult.meta.durationSecRecorded = finalDuration;
  }
  out.meta = evalResult.meta;
  out.logging = { enabled: logResult.loggingEnabled, eventsStored: logResult.stored, eventsDropped: logResult.dropped };
  const studyId = studyForContext({ classId: ownerClassId, examId })?.id || null;
  if (studyId) {
    recordStudyEvent({
      studyId, userId: req.user.id, eventType: "session_finished",
      contextType: examId ? "exam" : "class", contextId: examId || ownerClassId,
      data: { attemptId: info.lastInsertRowid, caseId: caseData.id, score: evalResult.score, type: "vp" },
    });
  }

  // ---- Competitive ranking XP (learners only) ----
  // The auto-evaluator's score% is converted to ranking XP via the admin-set
  // per-case cap. Best-score policy: replaying only tops up XP if you do better,
  // so ranking reflects best performance and can't be farmed. (No effect for
  // students/teachers/admins or for scheduled class exams.)
  if (req.user.role === "learner" && !classId && !examId) {
    try {
      const award = awardVpatientXp(req.user.id, caseData, evalResult.score);
      out.xpReward = {
        awarded: award.awarded, xpMax: award.xpMax,
        best: award.best, prevBest: award.prevBest, scorePct: evalResult.score,
      };
      const { getProfile } = await import("../lib/gamify.js");
      out.profile = getProfile(req.user.id);
    } catch { /* XP is best-effort; the evaluation still returns */ }
  }

  res.json({ attemptId: info.lastInsertRowid, ...out });
  } catch (e) {
    res.status(500).json({ error: "evaluate_failed", stage: "evaluate", message: String(e.message || e).slice(0, 200) });
  }
});

/* ---- Flashcard practice submit (multiple choice / search) ---- */
r.post("/flashcard-result", authRequired, (req, res) => {
  const { score, hints = 0, durationSec = 0, lang = "fa", examId,
          total = 0, correct = 0, wrong = 0, answers = [] } = req.body || {};
  // Enforce the exam's attempt limit for scheduled flashcard exams too.
  if (examId && req.user.role === "student") {
    const acc = examAccess(req.user.id, examId, null);
    if (!acc.allowed) return res.status(403).json({ error: "attempts exhausted", reason: acc.reason });
  }
  const info = db.prepare(
    `INSERT INTO attempts (user_id,type,case_id,exam_id,content_version,score,transcript_json,
       turns,tests,hints,total_questions,correct_count,wrong_count,duration_sec,lang)
     VALUES (?,?,?,?,?,?,?,0,0,?,?,?,?,?,?)`
  ).run(req.user.id, "flash", null, examId || null, 1, score,
        JSON.stringify({ answers: Array.isArray(answers) ? answers : [] }),
        hints, total, correct, wrong, durationSec, lang);
  if (examId) {
    const studyId = studyForContext({ examId })?.id || null;
    if (studyId) {
      recordStudyEvent({
        studyId, userId: req.user.id, eventType: "flashcard_finished",
        contextType: "exam", contextId: examId,
        data: { attemptId: info.lastInsertRowid, score, type: "flash" },
      });
    }
  }
  res.json({ attemptId: info.lastInsertRowid });
});

/* ---- List available AI providers (admin only) ---- */
r.get("/ai-providers", authRequired, requireRole("admin", "teacher"), (req, res) => {
  res.json(Object.entries(AI_PROVIDERS).map(([key, v]) => ({ key, label: v.label, base: v.base })));
});

/* ---- Test AI connection (admin/teacher) — hits the SAME path the VP chat uses. ---- */
r.post("/ai-test", authRequired, requireRole("admin", "teacher"), async (req, res) => {
  const aiCfg = resolveAiConfig(getSetting("ai", {}));
  if (!aiCfg.apiKey) return res.json({ connected: false, mode: "mock", message: "No API key — using mock engine." });
  try {
    const lang = req.body?.lang === "en" ? "en" : "fa";
    // Use a realistic mini-case so the admin sees a genuine patient-style reply.
    const result = await patientReply({
      caseData: lang === "fa"
        ? { chief_fa: "درد قفسه سینه", history_fa: "درد فشارنده از یک ساعت پیش، انتشار به بازوی چپ" }
        : { chief_en: "chest pain", history_en: "pressure-like pain for an hour, radiating to left arm" },
      userText: lang === "fa" ? "سلام، چه مشکلی دارید؟" : "Hello, what brings you in today?",
      lang, prompts: loadPrompts(), aiCfg,
    }, { throwOnError: true });   // surface the REAL provider error to the admin
    const ok = result.source === "llm";
    const cur = getSetting("ai", {});
    db.prepare("UPDATE settings SET value=? WHERE key='ai'").run(JSON.stringify({ ...cur, connected: ok }));
    res.json({
      connected: ok, mode: result.source,
      provider: aiCfg.provider || "", model: aiCfg.model || "",
      sample: result.text || "",
    });
  } catch (e) {
    res.json({ connected: false, mode: "mock", message: String(e.message) });
  }
});

export default r;
