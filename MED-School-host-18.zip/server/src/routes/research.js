import express from "express";
import { db, persistNow } from "../db.js";
import { authRequired, requireRole } from "../lib/auth.js";

const r = express.Router();
const admin = [authRequired, requireRole("admin", "teacher", "content_manager")];
const parse = (x, fb) => { try { return JSON.parse(x || ""); } catch { return fb; } };
const cleanStudy = (s) => s && ({ ...s, active: !!s.active, consent_required: !!s.consent_required });

r.get("/studies", ...admin, (req, res) => {
  res.json({ studies: db.prepare("SELECT * FROM research_studies ORDER BY active DESC,id DESC").all().map(cleanStudy) });
});

r.post("/studies", ...admin, (req, res) => {
  const b = req.body || {};
  const info = db.prepare(`INSERT INTO research_studies
    (title_fa,title_en,description_fa,description_en,domain,active,consent_required,created_by)
    VALUES (?,?,?,?,?,?,?,?)`).run(
    b.title_fa || "", b.title_en || "", b.description_fa || "", b.description_en || "",
    b.domain || "general", b.active ? 1 : 0, b.consent_required === false ? 0 : 1, req.user.id
  );
  persistNow();
  res.json(cleanStudy(db.prepare("SELECT * FROM research_studies WHERE id=?").get(info.lastInsertRowid)));
});

// Full admin control: edit or activate/deactivate a study without deleting data.
r.put("/studies/:id", ...admin, (req, res) => {
  const id = Number(req.params.id || 0);
  const old = db.prepare("SELECT * FROM research_studies WHERE id=?").get(id);
  if (!old) return res.status(404).json({ error: "not_found" });
  const b = req.body || {};
  db.prepare(`UPDATE research_studies SET
    title_fa=?, title_en=?, description_fa=?, description_en=?, domain=?, active=?, consent_required=?, updated_at=datetime('now')
    WHERE id=?`).run(
    b.title_fa ?? old.title_fa ?? "", b.title_en ?? old.title_en ?? "",
    b.description_fa ?? old.description_fa ?? "", b.description_en ?? old.description_en ?? "",
    b.domain ?? old.domain ?? "general",
    b.active === undefined ? old.active : (b.active ? 1 : 0),
    b.consent_required === undefined ? old.consent_required : (b.consent_required ? 1 : 0), id
  );
  persistNow();
  res.json(cleanStudy(db.prepare("SELECT * FROM research_studies WHERE id=?").get(id)));
});

r.get("/events", ...admin, (req, res) => {
  const rows = db.prepare(`SELECT e.*, s.title_fa, s.title_en, COALESCE(u.name_fa,u.name_en,u.username) AS user_name, u.role AS user_role
    FROM research_events e
    LEFT JOIN research_studies s ON s.id=e.study_id
    LEFT JOIN users u ON u.id=e.user_id
    ORDER BY e.id DESC LIMIT 1000`).all();
  res.json({ events: rows.map((x) => ({ ...x, data: parse(x.data_json, {}) })) });
});

r.post("/event", authRequired, (req, res) => {
  const b = req.body || {};
  db.prepare(`INSERT INTO research_events
    (study_id,user_id,event_type,context_type,context_id,data_json) VALUES (?,?,?,?,?,?)`).run(
    b.study_id || null, req.user.id, b.event_type || "custom", b.context_type || null,
    b.context_id || null, JSON.stringify(b.data || {})
  );
  persistNow();
  res.json({ ok: true });
});

export default r;
