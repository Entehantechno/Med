import express from "express";
import { db, persistNow } from "../db.js";
import { authRequired, requireRole } from "../lib/auth.js";

const r = express.Router();
const admin = [authRequired, requireRole("admin", "teacher", "content_manager")];
const parse = (x, fb) => { try { return JSON.parse(x || ""); } catch { return fb; } };
const clean = (f) => f && ({ ...f, active: !!f.active, anonymous: !!f.anonymous, require_after_finish: !!f.require_after_finish, questions: parse(f.questions_json, []) });
const nid = (v) => (v === "" || v === null || v === undefined ? null : Number(v) || null);
const scopeOf = (v) => ["general", "class", "exam"].includes(v) ? v : "general";
const questionsOf = (b) => Array.isArray(b.questions) ? b.questions : [];

r.get("/admin/forms", ...admin, (req, res) => {
  res.json({ forms: db.prepare("SELECT * FROM questionnaire_forms ORDER BY active DESC,id DESC").all().map(clean) });
});

r.post("/admin/forms", ...admin, (req, res) => {
  const b = req.body || {};
  const qs = questionsOf(b);
  const info = db.prepare(`INSERT INTO questionnaire_forms
    (title_fa,title_en,description_fa,description_en,scope,class_id,exam_id,questions_json,active,require_after_finish,anonymous,created_by)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`).run(
    b.title_fa || "", b.title_en || "", b.description_fa || "", b.description_en || "",
    scopeOf(b.scope), nid(b.class_id), nid(b.exam_id), JSON.stringify(qs),
    b.active === false ? 0 : 1, b.require_after_finish === false ? 0 : 1, b.anonymous === false ? 0 : 1, req.user.id
  );
  persistNow();
  res.json(clean(db.prepare("SELECT * FROM questionnaire_forms WHERE id=?").get(info.lastInsertRowid)));
});

// Full admin control: edit/toggle an existing questionnaire without deleting responses.
r.put("/admin/forms/:id", ...admin, (req, res) => {
  const id = Number(req.params.id || 0);
  const old = db.prepare("SELECT * FROM questionnaire_forms WHERE id=?").get(id);
  if (!old) return res.status(404).json({ error: "not_found" });
  const b = req.body || {};
  db.prepare(`UPDATE questionnaire_forms SET
    title_fa=?, title_en=?, description_fa=?, description_en=?, scope=?, class_id=?, exam_id=?,
    questions_json=?, active=?, require_after_finish=?, anonymous=?, updated_at=datetime('now')
    WHERE id=?`).run(
    b.title_fa ?? old.title_fa ?? "", b.title_en ?? old.title_en ?? "",
    b.description_fa ?? old.description_fa ?? "", b.description_en ?? old.description_en ?? "",
    scopeOf(b.scope ?? old.scope), nid(b.class_id ?? old.class_id), nid(b.exam_id ?? old.exam_id),
    JSON.stringify(Array.isArray(b.questions) ? b.questions : parse(old.questions_json, [])),
    b.active === undefined ? old.active : (b.active ? 1 : 0),
    b.require_after_finish === undefined ? old.require_after_finish : (b.require_after_finish ? 1 : 0),
    b.anonymous === undefined ? old.anonymous : (b.anonymous ? 1 : 0), id
  );
  persistNow();
  res.json(clean(db.prepare("SELECT * FROM questionnaire_forms WHERE id=?").get(id)));
});

r.get("/prompts", authRequired, (req, res) => {
  const type = req.query.contextType || "general";
  const id = Number(req.query.contextId || 0) || null;
  const col = type === "class" ? "class_id" : type === "exam" ? "exam_id" : "id";
  const rows = db.prepare(`SELECT * FROM questionnaire_forms WHERE active=1 AND (scope='general' OR (scope=? AND (${col}=? OR ${col} IS NULL))) ORDER BY id DESC LIMIT 5`).all(type, id);
  const done = new Set(db.prepare("SELECT form_id FROM questionnaire_responses WHERE user_id=?").all(req.user.id).map((r) => r.form_id));
  res.json({ forms: rows.map(clean).filter((f) => !done.has(f.id)) });
});

r.post("/:id/responses", authRequired, (req, res) => {
  const id = Number(req.params.id);
  const f = db.prepare("SELECT * FROM questionnaire_forms WHERE id=? AND active=1").get(id);
  if (!f) return res.status(404).json({ error: "not_found" });
  db.prepare(`INSERT OR REPLACE INTO questionnaire_responses
    (form_id,user_id,context_type,context_id,answers_json,created_at) VALUES (?,?,?,?,?,datetime('now'))`).run(
    id, req.user.id, req.body?.contextType || f.scope, req.body?.contextId || f.class_id || f.exam_id || null,
    JSON.stringify(req.body?.answers || {})
  );
  persistNow();
  res.json({ ok: true });
});

r.get("/admin/responses", ...admin, (req, res) => {
  const rows = db.prepare(`SELECT qr.*, q.title_fa, q.title_en, COALESCE(u.name_fa,u.name_en,u.username) AS user_name, u.role AS user_role
    FROM questionnaire_responses qr
    LEFT JOIN questionnaire_forms q ON q.id=qr.form_id
    LEFT JOIN users u ON u.id=qr.user_id
    ORDER BY qr.id DESC LIMIT 1000`).all();
  res.json({ responses: rows.map((x) => ({ ...x, answers: parse(x.answers_json, {}) })) });
});

export default r;
