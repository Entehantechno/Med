/* ================================================================
   exam.js — Virtual patient chat + evaluation + flashcard submit.
   All AI logic lives server-side; prompts pulled from DB.
   ================================================================ */
import { Router } from "express";
import { db } from "../db.js";
import { authRequired, requireRole } from "../lib/auth.js";
import { patientReply, evaluate, scoreChecklistWithLLM, enrichEvaluationWithLLM, labImagingResult, AI_PROVIDERS } from "../lib/ai-engine.js";
import { getSetting, canAccessCase } from "./content.js";
import { classAttemptInfo } from "./classes.js";
import { examAccess } from "./exams.js";
import { getVpatientConfig, awardVpatientXp, getVpatientAiEffective, getVpatientPromptsEffective } from "../lib/vpatient.js";
import { isEnabled } from "../lib/flags.js";
import { getProfile } from "../lib/gamify.js";

// Access is granted by a scheduled exam, class enrollment, OR direct assignment.
function hasAccess(user, caseId, classId, examId) {
  // Competitive learners reach virtual patients through the gated learner
  // feature, NOT class/exam assignments — so check the vpatient access config.
  if (user.role === "learner") return learnerVpatientAllowed(user);
  if (user.role !== "student") return true;   // teachers/admins: full access (QA)
  if (examId) return examAccess(user.id, examId, caseId).allowed;
  if (classId) return classAttemptInfo(user.id, classId, caseId).allowed;
  return canAccessCase(user, caseId);
}

/* Whether a competitive learner may use the virtual patient right now (feature
   flag + admin switch + optional premium-only). Best-effort require to avoid a
   hard import cycle. */
function learnerVpatientAllowed(user) {
  try {
    const cfg = getVpatientConfig();
    if (!isEnabled("virtual_patient") || !cfg.enabled) return false;
    if (!cfg.premium_only) return true;
    const p = db.prepare("SELECT premium, premium_until FROM learner_profiles WHERE user_id=?").get(user.id);
    if (!p) return false;
    const active = p.premium && (!p.premium_until || new Date(p.premium_until).getTime() >= Date.now());
    return !!active;
  } catch { return false; }
}

// How many attempts a student is still allowed for a given case.
function attemptsRemaining(user, caseId) {
  if (user.role !== "student") return Infinity;
  const a = db.prepare(
    "SELECT max_attempts FROM exam_assignments WHERE user_id=? AND case_id=? AND active=1"
  ).get(user.id, caseId);
  if (!a) return 0;
  const used = db.prepare(
    "SELECT COUNT(*) n FROM attempts WHERE user_id=? AND case_id=?"
  ).get(user.id, caseId).n;
  return Math.max(0, (a.max_attempts ?? 1) - used);
}

const r = Router();

function loadPrompts() {
  const rows = db.prepare("SELECT * FROM prompts").all();
  const out = {}; rows.forEach((p) => (out[p.key] = p.value));
  return out;
}

/* Pick the AI config + prompts for THIS request. Competitive learners (free
   virtual patient, not a class/exam) use the SEPARATE vpatient config; everyone
   else (students, teachers, admins, scheduled exams) uses the shared university
   config. This keeps the two flows fully independent yet code-shared. */
function engineContext(req, body = {}) {
  const isCompetitive = req.user.role === "learner" && !body.classId && !body.examId;
  if (isCompetitive) {
    return { aiCfg: getVpatientAiEffective(), prompts: getVpatientPromptsEffective(), competitive: true };
  }
  return { aiCfg: getSetting("ai", {}), prompts: loadPrompts(), competitive: false };
}
function loadCase(id) {
  const row = db.prepare("SELECT * FROM cases WHERE id=?").get(id);
  if (!row) return null;
  return { ...JSON.parse(row.data_json), id: row.id, version: row.version, checklist_id: row.checklist_id };
}
function loadChecklist(id) {
  const row = db.prepare("SELECT * FROM checklists WHERE id=?").get(id);
  return row ? { id: row.id, items: JSON.parse(row.items_json) } : { items: [] };
}

/* ---- Patient chat turn ---- */
r.post("/patient-reply", authRequired, async (req, res) => {
  const { caseId, userText, history = [], lang = "fa", classId, examId } = req.body || {};
  const caseData = loadCase(caseId);
  if (!caseData) return res.status(404).json({ error: "case not found" });
  if (!hasAccess(req.user, caseId, classId, examId))
    return res.status(403).json({ error: "not assigned to this exam" });
  const { aiCfg, prompts } = engineContext(req, req.body);
  const result = await patientReply({ caseData, userText, history, lang, prompts, aiCfg });
  res.json(result);
});

/* ---- Order a lab test or imaging study -> lab/radiology report in the chat ----
   If the case chart has a recorded result → return it (with an image if any).
   Otherwise the student is told it's NORMAL (AI-worded when a key is set, else a
   deterministic template). `kind` = "lab" | "imaging". */
r.post("/order", authRequired, async (req, res) => {
  const { caseId, kind = "lab", query = "", lang = "fa", classId, examId } = req.body || {};
  const caseData = loadCase(caseId);
  if (!caseData) return res.status(404).json({ error: "case not found" });
  if (!hasAccess(req.user, caseId, classId, examId))
    return res.status(403).json({ error: "not assigned to this exam" });
  const { aiCfg, prompts } = engineContext(req, req.body);
  const result = await labImagingResult({
    caseData, kind: kind === "imaging" ? "imaging" : "lab",
    query: String(query || "").trim(), lang, prompts, aiCfg,
  });
  res.json(result);
});

/* ---- Finish exam -> evaluate + store attempt ---- */
r.post("/evaluate", authRequired, async (req, res) => {
  const { caseId, session, lang = "fa", durationSec = 0, classId, examId } = req.body || {};
  const caseData = loadCase(caseId);
  if (!caseData) return res.status(404).json({ error: "case not found" });
  if (!hasAccess(req.user, caseId, classId, examId))
    return res.status(403).json({ error: "not assigned to this exam" });
  const checklist = loadChecklist(caseData.checklist_id);
  const globalSettings = getSetting("exam", {});
  const { aiCfg, prompts } = engineContext(req, req.body);

  // Per-exam settings override the global defaults when this is a scheduled exam.
  let showAi = globalSettings.showAiAnalysis, showMicro = globalSettings.showMicro;
  if (examId) {
    const ex = db.prepare("SELECT show_ai, show_micro FROM exams WHERE id=?").get(examId);
    if (ex) { showAi = !!ex.show_ai; showMicro = !!ex.show_micro; }
  }

  // 1) Deterministic keyword checklist score (always available; the AI-free base).
  let evalResult = evaluate({ caseData, checklist, session, lang });
  // 2) When an AI key is configured, RE-SCORE the OSCE checklist with the LLM,
  //    which judges each item from the whole encounter (context-aware, not
  //    keyword-matching). Falls back to the keyword score on any error.
  evalResult = await scoreChecklistWithLLM({
    base: evalResult, caseData, checklist, session, lang, aiCfg,
  });
  // 3) Enrich the qualitative feedback + personalized micro-lesson with the LLM.
  evalResult = await enrichEvaluationWithLLM({
    base: evalResult, caseData, session, lang, prompts, aiCfg,
  });
  // /10 score for OSCE-style review (kept alongside the % for the UI + teacher).
  if (evalResult.score10 == null) evalResult.score10 = Math.round((evalResult.score || 0) / 10);

  // strip sections disabled by settings
  const out = { ...evalResult };
  if (!showAi) {
    out.strengths = out.weaknesses = out.missed = out.commonMistakes = [];
    out.suggestion = "";
  }
  if (!showMicro) out.microlearning = "";

  const studentTurns = (session.messages || []).filter((m) => m.role === "student").length;
  const info = db.prepare(
    `INSERT INTO attempts (user_id,type,case_id,class_id,exam_id,content_version,score,transcript_json,eval_json,
       turns,tests,imaging_count,ddx_count,hints,duration_sec,lang)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
  ).run(
    req.user.id, "vp", caseData.id, classId || null, examId || null, caseData.version, evalResult.score,
    JSON.stringify(session), JSON.stringify(evalResult),
    studentTurns,
    (session.tests || []).length, (session.imaging || []).length, (session.ddx || []).length,
    0, durationSec, lang
  );

  // ---- Competitive ranking XP (learners only) ----
  // The auto-evaluator's score% is converted to ranking XP via the admin-set
  // per-case cap. Best-score policy: replaying only tops up XP if you do better,
  // so ranking reflects best performance and can't be farmed. (No effect for
  // students/teachers/admins or for scheduled class exams.)
  if (req.user.role === "learner" && !classId && !examId) {
    try {
      const award = awardVpatientXp(req.user.id, caseData, evalResult.score);
      out.xpReward = {
        awarded: award.awarded, xpMax: award.xpMax,
        best: award.best, prevBest: award.prevBest, scorePct: evalResult.score,
      };
      const { getProfile } = await import("../lib/gamify.js");
      out.profile = getProfile(req.user.id);
    } catch { /* XP is best-effort; the evaluation still returns */ }
  }

  res.json({ attemptId: info.lastInsertRowid, ...out });
});

/* ---- Flashcard practice submit (multiple choice / search) ---- */
r.post("/flashcard-result", authRequired, (req, res) => {
  const { score, hints = 0, durationSec = 0, lang = "fa", examId,
          total = 0, correct = 0, wrong = 0, answers = [] } = req.body || {};
  // Enforce the exam's attempt limit for scheduled flashcard exams too.
  if (examId && req.user.role === "student") {
    const acc = examAccess(req.user.id, examId, null);
    if (!acc.allowed) return res.status(403).json({ error: "attempts exhausted", reason: acc.reason });
  }
  const info = db.prepare(
    `INSERT INTO attempts (user_id,type,case_id,exam_id,content_version,score,transcript_json,
       turns,tests,hints,total_questions,correct_count,wrong_count,duration_sec,lang)
     VALUES (?,?,?,?,?,?,?,0,0,?,?,?,?,?,?)`
  ).run(req.user.id, "flash", null, examId || null, 1, score,
        JSON.stringify({ answers: Array.isArray(answers) ? answers : [] }),
        hints, total, correct, wrong, durationSec, lang);
  res.json({ attemptId: info.lastInsertRowid });
});

/* ---- List available AI providers (admin only) ---- */
r.get("/ai-providers", authRequired, requireRole("admin"), (req, res) => {
  res.json(Object.entries(AI_PROVIDERS).map(([key, v]) => ({ key, label: v.label, base: v.base })));
});

/* ---- Test AI connection (admin only) ---- */
r.post("/ai-test", authRequired, requireRole("admin"), async (req, res) => {
  const aiCfg = getSetting("ai", {});
  if (!aiCfg.apiKey) return res.json({ connected: false, mode: "mock", message: "No API key — using mock engine." });
  try {
    const lang = req.body?.lang === "en" ? "en" : "fa";
    // Use a realistic mini-case so the admin sees a genuine patient-style reply.
    const result = await patientReply({
      caseData: lang === "fa"
        ? { chief_fa: "درد قفسه سینه", history_fa: "درد فشارنده از یک ساعت پیش، انتشار به بازوی چپ" }
        : { chief_en: "chest pain", history_en: "pressure-like pain for an hour, radiating to left arm" },
      userText: lang === "fa" ? "سلام، چه مشکلی دارید؟" : "Hello, what brings you in today?",
      lang, prompts: loadPrompts(), aiCfg,
    }, { throwOnError: true });   // surface the REAL provider error to the admin
    const ok = result.source === "llm";
    const cur = getSetting("ai", {});
    db.prepare("UPDATE settings SET value=? WHERE key='ai'").run(JSON.stringify({ ...cur, connected: ok }));
    res.json({
      connected: ok, mode: result.source,
      provider: aiCfg.provider || "", model: aiCfg.model || "",
      sample: result.text || "",
    });
  } catch (e) {
    res.json({ connected: false, mode: "mock", message: String(e.message) });
  }
});

export default r;
