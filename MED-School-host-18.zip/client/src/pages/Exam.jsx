import { useEffect, useRef, useState } from "react";
import { useApp } from "../context.jsx";
import { api } from "../api.js";
import { TopBar, Spinner } from "../components/UI.jsx";
import { biField } from "../i18n.js";
import OrderSearch from "../components/OrderSearch.jsx";
import { LAB_TESTS, IMAGING_STUDIES } from "../data/medical-catalog.js";
import { useAntiCheat } from "../utils/antiCheat.js";
import Icon from "../components/Icon.jsx";

export default function Exam({ caseId, classId, examId, examDuration, antiCheat, go, home }) {
  const { t, lang } = useApp();
  const [caseData, setCaseData] = useState(null);
  const [settings, setSettings] = useState({ duration: 15 });
  const [phase, setPhase] = useState("exam"); // exam | evaluating | report
  const [messages, setMessages] = useState([]);
  const [typing, setTyping] = useState(false);
  const [input, setInput] = useState("");
  const [tab, setTab] = useState("history");
  const [tests, setTests] = useState([]);
  const [imaging, setImaging] = useState([]);
  const [ddx, setDdx] = useState([]);
  const [finalDx, setFinalDx] = useState("");
  const [timeLeft, setTimeLeft] = useState(null);
  const [evalRes, setEvalRes] = useState(null);
  const { leaves } = useAntiCheat(!!examId && antiCheat && phase === "exam");
  const startRef = useRef(Date.now());
  const chatEnd = useRef(null);

  useEffect(() => {
    (async () => {
      const [c, s] = await Promise.all([api.get(`/cases/${caseId}`), api.get("/settings/exam")]);
      // Prefer the specific exam's duration when launched from a scheduled exam.
      const mins = examDuration || s.duration || 15;
      setCaseData(c); setSettings(s); setTimeLeft(mins * 60);
    })();
  }, [caseId]);

  useEffect(() => {
    if (timeLeft == null || phase !== "exam") return;
    if (timeLeft <= 0) { finish(); return; }
    const id = setTimeout(() => setTimeLeft((x) => x - 1), 1000);
    return () => clearTimeout(id);
  }, [timeLeft, phase]);

  useEffect(() => { chatEnd.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, typing]);

  const fmt = (s) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

  const send = async () => {
    const text = input.trim(); if (!text) return;
    const priorHistory = messages;               // conversation so far (for LLM memory)
    setMessages((m) => [...m, { role: "student", text }]);
    setInput(""); setTyping(true);
    try {
      const { text: reply } = await api.post("/exam/patient-reply",
        { caseId, userText: text, history: priorHistory, lang, classId, examId });
      setMessages((m) => [...m, { role: "patient", text: reply }]);
    } catch {
      setMessages((m) => [...m, { role: "patient", text: "…" }]);
    } finally { setTyping(false); }
  };

  // When a student orders a test/imaging, fetch the lab/radiology report and
  // drop it into the chat (recorded result, or "normal" if not in the chart).
  const orderResult = async (kind, query) => {
    if (!query || !query.trim()) return;
    setTyping(true);
    try {
      const r = await api.post("/exam/order", { caseId, kind, query: query.trim(), lang, classId, examId });
      setMessages((m) => [...m, { role: "lab", text: r.text, imageUrl: r.imageUrl || null }]);
    } catch {
      setMessages((m) => [...m, { role: "lab", text: "…" }]);
    } finally { setTyping(false); }
  };

  const finish = async () => {
    setPhase("evaluating");
    const session = { messages, tests, imaging, ddx, finalDx };
    const durationSec = Math.round((Date.now() - startRef.current) / 1000);
    try {
      const res = await api.post("/exam/evaluate", { caseId, session, lang, durationSec, classId, examId });
      setEvalRes(res); setPhase("report");
    } catch { setPhase("exam"); }
  };

  if (!caseData) return <div className="app"><TopBar onHome={home} /><Spinner /></div>;

  if (phase === "evaluating")
    return (
      <div className="app"><TopBar onHome={home} />
        <div className="center-screen"><div className="card center" style={{ maxWidth: 420 }}>
          <div style={{ fontSize: 44 }}><Icon name="brain" size={30} /></div>
          <h3 className="mt8">{t("evaluating")}</h3>
          <div className="muted small mt8">ASKI checklist · AI examiner</div>
        </div></div>
      </div>
    );

  if (phase === "report")
    return <Report caseData={caseData} evalRes={evalRes} settings={settings}
      onBack={() => go(examId ? "exams" : classId ? "classes" : "caseList")} home={home} />;

  return (
    <div className="app">
      <TopBar onHome={home} />
      <div className="container">
        <div className="section-title">
          <div>
            <h2>{biField(caseData, "title", lang)}</h2>
            <span className="small muted">{t("chief")}: {biField(caseData, "chief", lang)}</span>
          </div>
          <div style={{ textAlign: "end" }}>
            <div className="small muted">{t("examTimer")}</div>
            <div className="timer">{fmt(timeLeft ?? 0)}</div>
          </div>
        </div>
        {!!examId && antiCheat && leaves > 0 && (
          <div className="err-banner mb16"><Icon name="warn" size={16} /> {t("antiCheatWarn")} ({leaves})</div>
        )}
        <div className="exam-layout">
          <div className="card chat-box">
            <div style={{ fontWeight: 700, marginBottom: 8 }}><Icon name="chat" size={16} /> {t("patientChat")}</div>
            <div className="chat-msgs">
              {messages.length === 0 && !typing &&
                <div className="muted small center" style={{ margin: "auto" }}>{t("typeMessage")}</div>}
              {messages.map((m, i) => (
                m.role === "lab" ? (
                  <div key={i} className="msg msg-lab" style={{ alignSelf: "center", background: "var(--panel2, #eef3f9)", border: "1px dashed var(--border)", borderRadius: 12, maxWidth: "92%", textAlign: "start" }}>
                    <div>{m.text}</div>
                    {m.imageUrl && <a href={m.imageUrl} target="_blank" rel="noreferrer"><img src={m.imageUrl} alt="" style={{ width: "100%", borderRadius: 8, marginTop: 8, border: "1px solid var(--border)" }} /></a>}
                  </div>
                ) : (
                  <div key={i} className={`msg msg-${m.role === "student" ? "student" : "patient"}`}>{m.text}</div>
                )
              ))}
              {typing && <div className="msg msg-patient msg-typing">{t("aiThinking")}</div>}
              <div ref={chatEnd} />
            </div>
            <div className="chat-input">
              <input value={input} onChange={(e) => setInput(e.target.value)}
                placeholder={t("typeMessage")} onKeyDown={(e) => e.key === "Enter" && send()} />
              <button className="btn btn-primary" onClick={send}>{t("send")}</button>
            </div>
          </div>

          <div className="card side-panel">
            <div className="tabs">
              {["history", "tests", "imaging", "images", "dx"].map((id) => (
                <button key={id} className={`tab ${tab === id ? "active" : ""}`} onClick={() => setTab(id)}>
                  {t(id === "history" ? "tabHistory" : id === "tests" ? "tabTests"
                    : id === "imaging" ? "tabImaging" : id === "images" ? "tabImages" : "tabDx")}
                </button>
              ))}
            </div>
            <div className="tab-content">
              {tab === "history" && <HistoryTab c={caseData} t={t} lang={lang} />}
              {tab === "tests" && <OrderTab label={t("orderTest")} listLabel={t("orderedTests")}
                catalog={LAB_TESTS} items={tests} setItems={setTests} lang={lang} t={t}
                onOrder={(q) => orderResult("lab", q)} />}
              {tab === "imaging" && <OrderTab label={t("orderImaging")} listLabel={t("orderedImaging")}
                catalog={IMAGING_STUDIES} items={imaging} setItems={setImaging} lang={lang} t={t}
                onOrder={(q) => orderResult("imaging", q)} />}
              {tab === "images" && <ImagesTab c={caseData} t={t} lang={lang} />}
              {tab === "dx" && <DxTab ddx={ddx} setDdx={setDdx} finalDx={finalDx} setFinalDx={setFinalDx} t={t} />}
            </div>
            <button className="btn btn-accent btn-block mt16" onClick={finish}>✓ {t("finishExam")}</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function ImagesTab({ c, t, lang }) {
  const imgs = (c.images || []).filter((im) => im.url);
  if (!imgs.length) return <div className="small muted center" style={{ padding: 20 }}>{t("noImages")}</div>;
  return (
    <div style={{ display: "grid", gap: 12 }}>
      {imgs.map((im, i) => (
        <div key={i}>
          <a href={im.url} target="_blank" rel="noreferrer">
            <img src={im.url} alt="" style={{ width: "100%", borderRadius: 12, border: "1px solid var(--border)" }} />
          </a>
          <div className="small muted mt8">{(lang === "fa" ? im.label_fa : im.label_en) || im.label_en || im.label_fa || ""}</div>
        </div>
      ))}
    </div>
  );
}

function HistoryTab({ c, t, lang }) {
  // The student must TAKE the history from the patient via the chat.
  // Only basic demographics are shown here (as observed on entering the room).
  const Row = ({ k, val }) => <div className="info-row"><span>{k}</span><span>{val}</span></div>;
  return (
    <>
      <label className="small muted">{t("patientCard")}</label>
      <Row k={t("age")} val={c.age} />
      <Row k={t("sex")} val={t(c.sex)} />
      <Row k={t("chief")} val={biField(c, "chief", lang)} />
      <div className="divider" />
      <div className="ddle-question" style={{ margin: 0 }}>
        <Icon name="chat" size={16} /> {t("takeHistoryNote")}
      </div>
    </>
  );
}

function OrderTab({ label, listLabel, catalog, items, setItems, lang, t, onOrder }) {
  const add = (v) => {
    const val = (v || "").trim();
    if (!val) return;
    // avoid duplicates (case-insensitive)
    if (items.some((x) => x.toLowerCase() === val.toLowerCase())) return;
    setItems([...items, val]);
    // fetch the lab/radiology report for this order and show it in the chat
    onOrder?.(val);
  };
  return (
    <>
      <div className="field"><label>{label}</label>
        <OrderSearch catalog={catalog} lang={lang} onAdd={add} />
      </div>
      <label className="small muted">{listLabel}</label>
      <div>{items.length ? items.map((x, i) => (
        <span className="chip" key={i}>{x}<button onClick={() => setItems(items.filter((_, j) => j !== i))}>✕</button></span>
      )) : <div className="small muted mt8">{t("noneYet")}</div>}</div>
    </>
  );
}

function DxTab({ ddx, setDdx, finalDx, setFinalDx, t }) {
  const [v, setV] = useState("");
  const add = () => { if (v.trim()) { setDdx([...ddx, v.trim()]); setV(""); } };
  return (
    <>
      <div className="field"><label>{t("ddx")}</label>
        <div className="inline-form">
          <input value={v} onChange={(e) => setV(e.target.value)} placeholder={t("addDdx")}
            onKeyDown={(e) => e.key === "Enter" && add()} />
          <button className="btn btn-primary btn-sm" onClick={add}>{t("add")}</button>
        </div>
        <div className="mt8">{ddx.map((x, i) => (
          <span className="chip" key={i}>{x}<button onClick={() => setDdx(ddx.filter((_, j) => j !== i))}>✕</button></span>
        ))}</div>
      </div>
      <div className="divider" />
      <div className="field"><label>{t("finalDx")}</label>
        <input value={finalDx} onChange={(e) => setFinalDx(e.target.value)} placeholder={t("enterFinalDx")} />
      </div>
    </>
  );
}

function Report({ caseData, evalRes, settings, onBack, home }) {
  const { t, lang } = useApp();
  const e = evalRes;
  const List = ({ arr, fallback }) => arr && arr.length
    ? <ul className="list-clean">{arr.map((x, i) => <li key={i}>{x}</li>)}</ul>
    : <div className="small muted">{fallback || "-"}</div>;

  return (
    <div className="app">
      <TopBar onHome={home} />
      <div className="container">
        <div className="section-title">
          <h2>{t("report")} — {biField(caseData, "title", lang)}</h2>
          <button className="btn btn-ghost btn-sm" onClick={onBack}>{t("backToCases")}</button>
        </div>
        <div className="grid grid-2">
          <div className="card center">
            <div className="score-ring" style={{ "--pct": `${e.score * 3.6}deg` }}><div className="val">{e.score}</div></div>
            <div className="lbl muted mt8">{t("finalScore")} / 100</div>
            <div className="tag mt8" style={{ fontWeight: 800 }}>{lang === "fa" ? "امتیاز از ۱۰" : "Score / 10"}: {e.score10 ?? Math.round((e.score || 0) / 10)}</div>
            {e.xpReward && (
              <div className="vp-xp-reward mt8" style={{ marginTop: 12 }}>
                {e.xpReward.awarded > 0 ? (
                  <div className="tag" style={{ background: "rgba(224,165,46,.16)", color: "var(--xp,#e0a52e)", border: "1px solid rgba(224,165,46,.4)", fontWeight: 800, fontSize: ".95rem", padding: "6px 12px" }}>
                    +{e.xpReward.awarded} XP {lang === "fa" ? "به رنکینگ" : "to ranking"}
                  </div>
                ) : (
                  <div className="small muted">
                    {lang === "fa"
                      ? `بهترین امتیاز قبلی‌ات ${e.xpReward.prevBest}٪ بود — این‌بار XP جدیدی اضافه نشد.`
                      : `Your previous best was ${e.xpReward.prevBest}% — no new XP this time.`}
                  </div>
                )}
                <div className="small muted mt8">{lang === "fa" ? `سقف XP این کیس: ${e.xpReward.xpMax}` : `Case XP cap: ${e.xpReward.xpMax}`}</div>
              </div>
            )}
          </div>
          <div className="card">
            <h4 className="mb8"><Icon name="check" size={16} /> {t("checklist")}</h4>
            {e.results.map((r) => (
              <div className="check-item" key={r.id}>
                <div className={`status ${r.done ? "st-done" : "st-miss"}`}>{r.done ? "✓" : "✕"}</div>
                <div style={{ flex: 1 }}>
                  {r.label}
                  {/* per-item examiner reasoning from the LLM (OSCE scoring) */}
                  {r.reason && <div className="small muted" style={{ marginTop: 2 }}>{r.reason}</div>}
                </div>
                <span className="tag">{t("weight")} {r.weight}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Per-section scores: history is graded separately from the rest, plus
            an overall score. For an EXTERN the teacher grades on history; for an
            INTERN on the overall. Both are always shown — the teacher decides. */}
        {e.sectionScores && (e.sectionScores.hasHistory || e.sectionScores.sections?.length > 1) && (
          <div className="card mt16">
            <h4 className="mb8"><Icon name="chart" size={16} /> {lang === "fa" ? "نمرهٔ تفکیکی بخش‌ها" : "Scores by section"}</h4>
            <div className="grid grid-3" style={{ gap: 12, marginBottom: 12 }}>
              {e.sectionScores.history != null && (
                <div className="card center" style={{ borderInlineStart: "4px solid var(--primary)" }}>
                  <div className="big" style={{ fontSize: "1.7rem" }}>{e.sectionScores.history}%</div>
                  <div className="small muted">{lang === "fa" ? "شرح‌حال (ملاک اکسترن)" : "History (extern)"}</div>
                </div>
              )}
              {e.sectionScores.other != null && (
                <div className="card center" style={{ borderInlineStart: "4px solid var(--gold)" }}>
                  <div className="big" style={{ fontSize: "1.7rem" }}>{e.sectionScores.other}%</div>
                  <div className="small muted">{lang === "fa" ? "سایر موارد" : "Other sections"}</div>
                </div>
              )}
              <div className="card center" style={{ borderInlineStart: "4px solid var(--green)" }}>
                <div className="big" style={{ fontSize: "1.7rem" }}>{e.sectionScores.overall}%</div>
                <div className="small muted">{lang === "fa" ? "کلی (ملاک اینترن)" : "Overall (intern)"}</div>
              </div>
            </div>
            {/* detailed bar per section */}
            {e.sectionScores.sections?.map((s) => (
              <div className="check-item" key={s.key} style={{ alignItems: "center" }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700 }}>{s.label} <span className="small muted">({s.items} {lang === "fa" ? "مورد" : "items"})</span></div>
                  <div className="pbar sm"><span style={{ width: `${s.score}%`, background: s.score >= 70 ? "var(--green)" : s.score < 40 ? "var(--danger)" : "var(--gold)" }} /></div>
                </div>
                <span className="tag">{s.score}%</span>
              </div>
            ))}
          </div>
        )}

        {settings.showAiAnalysis && (
          <>
            <div className="grid grid-2 mt16">
              <div className="card"><h4 style={{ color: "var(--ok)" }}><Icon name="strength" size={16} /> {t("strengths")}</h4><List arr={e.strengths} /></div>
              <div className="card"><h4 style={{ color: "var(--danger)" }}><Icon name="warn" size={16} /> {t("weaknesses")}</h4><List arr={e.weaknesses} /></div>
            </div>
            <div className="grid grid-2 mt16">
              <div className="card"><h4 style={{ color: "var(--warn)" }}><Icon name="pin" size={16} /> {t("missed")}</h4><List arr={e.missed} fallback="✓" /></div>
              <div className="card"><h4 style={{ color: "var(--warn)" }}><Icon name="repeat" size={16} /> {t("commonMistakes")}</h4><List arr={e.commonMistakes} /></div>
            </div>
            {e.suggestion && <div className="card mt16"><h4><Icon name="bulb" size={16} /> {t("suggestion")}</h4><div className="small mt8">{e.suggestion}</div></div>}
          </>
        )}

        {settings.showMicro && e.microlearning && (
          <div className="mt16">
            <h4 style={{ marginBottom: 8 }}><Icon name="book" size={16} /> {t("microlearning")}</h4>
            <div className="micro-box">{e.microlearning}</div>
            <div className="small muted mt8">{t("microNote")}</div>
          </div>
        )}
      </div>
    </div>
  );
}
