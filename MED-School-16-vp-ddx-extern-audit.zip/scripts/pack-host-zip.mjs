#!/usr/bin/env node
/* Lean Hetzner/cPanel zip: source + built client + bank payloads.
   Excludes reports, node_modules, previous zips, runtime DBs, .env. */
import { execFileSync } from "node:child_process";
import { existsSync, unlinkSync, writeFileSync } from "node:fs";
import path from "node:path";

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const out = process.argv[2] || path.join(root, "MED-School-host.zip");
process.chdir(root);

const raw = execFileSync("find", [".", "-type", "f", "-print"], { encoding: "utf8", maxBuffer: 80 * 1024 * 1024 });
const skip = [
  /(^|\/)node_modules\//,
  /(^|\/)\.git\//,
  /(^|\/)\.arena\//,
  /(^|\/)e2e-data\//,
  /(^|\/)medschool-data\//,
  /(^|\/)playwright-report\//,
  /(^|\/)test-results\//,
  /(^|\/)__pycache__\//,
  /(^|\/)\.venv\//,
  /\.zip$/i,
  /\.(db|sqlite|sqlite3)(-|$|\.)/i,
  /(^|\/)گزارش-/,
  /(^|\/)\.env$/,
  /(^|\/)\.env\.ready$/,
  /client\/dist\/.*\.map$/,
];
const files = raw.split("\n")
  .map((s) => s.replace(/^\.\//, "").trim())
  .filter(Boolean)
  .filter((f) => !skip.some((rx) => rx.test(f)));

if (existsSync(out)) unlinkSync(out);
const listPath = "/tmp/medschool-host-zip.list";
writeFileSync(listPath, files.join("\n") + "\n");
execFileSync("zip", ["-q", "-X", "-9", out, "-@"], {
  input: files.join("\n") + "\n",
  maxBuffer: 80 * 1024 * 1024,
});
console.log(`Wrote ${out} (${files.length} files)`);
