import { useState, useMemo, useRef, useEffect } from "react";
import { useApp } from "../context.jsx";

/* Renders non-MCQ exam questions authored by teachers, working with the RAW
   flashcard data_json shape. Supported: truefalse | fill | match | order |
   drawing | stepwise. Reports correctness once via onGraded(isRight, detail).
   Drawing is deliberately teacher-reviewed: it is submitted as pending and its
   proposed score is not counted until the instructor approves it. */
function shuffle(a) { const x = [...a]; for (let i = x.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [x[i], x[j]] = [x[j], x[i]]; } return x; }
function norm(s) { return String(s || "").trim().toLowerCase().replace(/\s+/g, " "); }
const arr = (x) => Array.isArray(x) ? x : String(x || "").split(/[,\n]/).map((v) => v.trim()).filter(Boolean);
const stepLabel = (s, k, fa) => fa ? (s[`${k}_fa`] || s[k] || "") : (s[`${k}_en`] || s[k] || "");

function LocalHints({ hints, showHints, fa }) {
  const [n, setN] = useState(0);
  const list = Array.isArray(hints) ? hints : [];
  if (!showHints || !list.length) return null;
  return <div className="local-hints">
    {Array.from({ length: n }).map((_, i) => <div className="ddle-question ddle-hint" key={i}><b>{fa ? "هینت" : "Hint"} {i + 1}:</b> {typeof list[i] === "object" ? (list[i].text || list[i].label || "") : String(list[i] || "")}</div>)}
    {n < list.length && <button className="btn btn-ghost btn-sm" onClick={() => setN((x) => x + 1)}>💡 {fa ? "نمایش هینت" : "Show hint"}</button>}
  </div>;
}

export default function ExamOtherType({ card, lang, done, showCorrect, showHints = true, hints = [], onGraded }) {
  const { t } = useApp();
  const [sel, setSel] = useState(card.type === "match" ? { pairs: {}, activeLeft: null } : card.type === "order" ? [] : null);
  const [checked, setChecked] = useState(false);
  const [right, setRight] = useState(false);
  const fa = lang === "fa";

  const pairs = card.pairs || [];
  const left = useMemo(() => pairs.map((p, i) => ({ id: i, text: fa ? p[0] : p[1] })), [card.id, fa]);
  const rightCol = useMemo(() => shuffle(pairs.map((p, i) => ({ id: i, text: fa ? p[2] : p[3] }))), [card.id, fa]);
  const orderItems = fa ? (card.items_fa || []) : (card.items_en || []);
  const orderPool = useMemo(() => shuffle(orderItems.map((text, i) => ({ id: i, text }))), [card.id, fa]);

  const judge = () => {
    if (card.type === "truefalse") return sel === !!card.answer;
    if (card.type === "fill") {
      const accepted = (fa ? (card.accept_fa || [card.blank_fa]) : (card.accept_en || [card.blank_en])).filter(Boolean);
      const list = accepted.length ? accepted : [fa ? card.blank_fa : card.blank_en];
      return list.some((a) => norm(a) === norm(sel));
    }
    if (card.type === "match") return left.every((l) => sel?.pairs?.[l.id] === l.id);
    if (card.type === "order") return (sel || []).length === orderItems.length && (sel || []).every((c, i) => c.id === i);
    return false;
  };
  const canCheck = () => {
    if (card.type === "truefalse") return sel != null;
    if (card.type === "fill") return !!(sel && String(sel).trim());
    if (card.type === "match") return sel && Object.keys(sel.pairs || {}).length === left.length;
    if (card.type === "order") return (sel || []).length === orderItems.length;
    return false;
  };
  const check = () => { const r = judge(); setRight(r); setChecked(true); onGraded(r, { answer: sel }); };

  if (card.type === "drawing") return <DrawingQuestion card={card} lang={lang} checked={checked} setChecked={setChecked} onGraded={onGraded} hints={hints} showHints={showHints} />;
  if (card.type === "stepwise") return <StepwiseQuestion card={card} lang={lang} showCorrect={showCorrect} checked={checked} setChecked={setChecked} onGraded={onGraded} hints={hints} showHints={showHints} />;

  return (
    <div>
      <LocalHints hints={hints} showHints={showHints && !checked} fa={fa} />
      {card.type === "truefalse" && (
        <div className="mc-options">
          {[{ v: true, l: fa ? "درست" : "True" }, { v: false, l: fa ? "نادرست" : "False" }].map((o) => {
            let cls = "mc-opt";
            if (checked) { if (o.v === !!card.answer) cls += " correct"; else if (o.v === sel) cls += " wrong"; }
            else if (o.v === sel) cls += " sel";
            return <button key={String(o.v)} className={cls} disabled={checked} onClick={() => setSel(o.v)}>{o.l}</button>;
          })}
        </div>
      )}
      {card.type === "fill" && (
        <div>
          <input className="fill-input" value={sel || ""} disabled={checked} placeholder={fa ? "پاسخ را تایپ کنید…" : "Type your answer…"} onChange={(e) => setSel(e.target.value)} />
          {checked && !right && showCorrect && <div className="small mt8" style={{ color: "var(--danger)" }}>{fa ? "پاسخ درست" : "Answer"}: {fa ? card.blank_fa : card.blank_en}</div>}
        </div>
      )}
      {card.type === "match" && (
        <div className="match-grid">
          <div className="match-col">{left.map((l) => {
            const connected = sel?.pairs?.[l.id] != null; let cls = "opt match-item";
            if (sel?.activeLeft === l.id) cls += " sel"; if (connected && !checked) cls += " connected"; if (checked) cls += sel?.pairs?.[l.id] === l.id ? " ok" : " bad";
            return <button key={l.id} className={cls} disabled={checked} onClick={() => setSel((s) => ({ ...s, activeLeft: l.id }))}>{l.text}</button>;
          })}</div>
          <div className="match-col">{rightCol.map((rr) => {
            const used = Object.values(sel?.pairs || {}).includes(rr.id); let cls = "opt match-item"; if (used && !checked) cls += " connected";
            return <button key={rr.id} className={cls} disabled={checked || (used && sel?.activeLeft == null)} onClick={() => setSel((s) => (s.activeLeft == null ? s : { pairs: { ...s.pairs, [s.activeLeft]: rr.id }, activeLeft: null }))}>{rr.text}</button>;
          })}</div>
        </div>
      )}
      {card.type === "order" && (
        <div>
          <div className="order-slots">{(sel || []).map((c, i) => <span key={c.id} className={`chip order-chip ${checked ? (c.id === i ? "ok" : "bad") : ""}`}>{i + 1}. {c.text}</span>)}{!checked && (sel || []).length > 0 && <button className="chip order-undo" onClick={() => setSel((s) => s.slice(0, -1))}>↩</button>}</div>
          <div className="order-pool">{orderPool.map((it) => { const usedIt = (sel || []).find((c) => c.id === it.id); return <button key={it.id} className="opt order-word" disabled={checked || !!usedIt} style={{ opacity: usedIt ? .35 : 1 }} onClick={() => setSel((s) => [...(s || []), it])}>{it.text}</button>; })}</div>
        </div>
      )}
      {checked && <div className={`ddle-banner ${right ? "ok" : "bad"}`} style={{ marginTop: 12 }}>{right ? `✓ ${t("correct")}` : t("incorrect")}</div>}
      {!checked && <button className="btn btn-primary btn-block mt16" disabled={!canCheck()} onClick={check}>{t("checkAns") || t("send")}</button>}
    </div>
  );
}

function DrawingQuestion({ card, lang, checked, setChecked, onGraded, hints, showHints }) {
  const fa = lang === "fa";
  const canvasRef = useRef(null);
  const drawingRef = useRef(false);
  const lastRef = useRef(null);
  const [strokeCount, setStrokeCount] = useState(0);
  const [snapshots, setSnapshots] = useState([]);
  const [redoStack, setRedoStack] = useState([]);
  const [rubricDone, setRubricDone] = useState({});
  const [brush, setBrush] = useState({ color: "#111827", size: 3, tool: "pen", grid: false });
  const drawing = card.drawing || {};
  const rubric = (fa ? (drawing.rubric_fa || []) : (drawing.rubric_en || [])).filter(Boolean);
  const prompt = (fa ? drawing.prompt_fa : drawing.prompt_en) || (fa ? card.questionText_fa : card.questionText_en) || "";

  const saveSnap = () => setSnapshots((s) => [...s.slice(-12), canvasRef.current.toDataURL("image/png")]);
  const restore = (src) => {
    const c = canvasRef.current, ctx = c.getContext("2d"), r = c.getBoundingClientRect(), img = new Image();
    img.onload = () => { ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, r.width, r.height); ctx.drawImage(img, 0, 0, r.width, r.height); };
    img.src = src;
  };

  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const cssW = Math.min(760, Math.max(300, canvas.parentElement?.clientWidth || 520));
    const cssH = Math.round(cssW * 0.62), dpr = window.devicePixelRatio || 1;
    canvas.width = cssW * dpr; canvas.height = cssH * dpr; canvas.style.width = "100%"; canvas.style.height = `${cssH}px`;
    const ctx = canvas.getContext("2d"); ctx.scale(dpr, dpr); ctx.lineCap = "round"; ctx.lineJoin = "round"; ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, cssW, cssH);
    setSnapshots([canvas.toDataURL("image/png")]); setRedoStack([]); setStrokeCount(0);
  }, [card.id]);

  const pos = (e) => { const c = canvasRef.current, r = c.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; };
  const drawLine = (from, to) => {
    const ctx = canvasRef.current.getContext("2d");
    const tool = brush.tool;
    ctx.globalCompositeOperation = tool === "eraser" ? "destination-out" : "source-over";
    ctx.globalAlpha = tool === "highlighter" ? 0.32 : 1;
    ctx.strokeStyle = tool === "eraser" ? "rgba(0,0,0,1)" : brush.color;
    ctx.lineWidth = tool === "eraser" ? brush.size * 3 : tool === "highlighter" ? brush.size * 4 : brush.size;
    ctx.beginPath(); ctx.moveTo(from.x, from.y); ctx.lineTo(to.x, to.y); ctx.stroke();
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = "source-over";
  };
  const down = (e) => { if (checked) return; e.preventDefault(); drawingRef.current = true; lastRef.current = pos(e); canvasRef.current.setPointerCapture?.(e.pointerId); };
  const move = (e) => { if (!drawingRef.current || checked) return; e.preventDefault(); const p = pos(e); drawLine(lastRef.current, p); lastRef.current = p; };
  const up = (e) => { if (!drawingRef.current) return; drawingRef.current = false; setStrokeCount((n) => n + 1); setRedoStack([]); saveSnap(); try { canvasRef.current.releasePointerCapture?.(e.pointerId); } catch {} };
  const clear = () => { const c = canvasRef.current, ctx = c.getContext("2d"), r = c.getBoundingClientRect(); ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, r.width, r.height); setStrokeCount(0); setRedoStack([]); setSnapshots([c.toDataURL("image/png")]); };
  const undo = () => { if (snapshots.length <= 1) return; const next = snapshots.slice(0, -1); setRedoStack((r) => [snapshots[snapshots.length - 1], ...r].slice(0, 12)); setSnapshots(next); restore(next[next.length - 1]); setStrokeCount((n) => Math.max(0, n - 1)); };
  const redo = () => { if (!redoStack.length) return; const [first, ...rest] = redoStack; setRedoStack(rest); setSnapshots((s) => [...s, first]); restore(first); setStrokeCount((n) => n + 1); };
  const finish = () => {
    const checkedCount = Object.values(rubricDone).filter(Boolean).length;
    const total = rubric.length || 1;
    const pointsFrac = rubric.length ? checkedCount / total : (strokeCount > 0 ? 1 : 0);
    const preview = canvasRef.current?.toDataURL("image/jpeg", 0.55) || "";
    setChecked(true);
    onGraded(true, { requiresApproval: true, pointsFrac, drawing: { strokeCount, rubricChecked: checkedCount, rubricTotal: rubric.length, pointsFrac, preview, approval: { status: "pending" } } });
  };

  return <div className="drawing-q">
    <div className="ddle-question ddle-hint"><b>{fa ? "تکلیف نقاشی:" : "Drawing task:"}</b> {prompt}</div>
    <LocalHints hints={hints} showHints={showHints && !checked} fa={fa} />
    {drawing.referenceImageUrl && <div className="drawing-ref"><img src={drawing.referenceImageUrl} alt="" /></div>}
    <div className="drawing-toolbar">
      <button className={`chip-btn ${brush.tool === "pen" ? "on" : ""}`} onClick={() => setBrush((b)=>({...b,tool:"pen"}))} disabled={checked}>✏️ {fa ? "قلم" : "Pen"}</button>
      <button className={`chip-btn ${brush.tool === "eraser" ? "on" : ""}`} onClick={() => setBrush((b)=>({...b,tool:"eraser"}))} disabled={checked}>🧽 {fa ? "پاک‌کن" : "Eraser"}</button>
      <button className={`chip-btn ${brush.tool === "highlighter" ? "on" : ""}`} onClick={() => setBrush((b)=>({...b,tool:"highlighter"}))} disabled={checked}>🖍️ {fa ? "هایلایت" : "Highlighter"}</button>
      {["#111827", "#2563eb", "#dc2626", "#16a34a", "#f59e0b"].map((c) => <button key={c} aria-label={c} className={`draw-color ${brush.color===c?'on':''}`} style={{ background: c }} onClick={() => setBrush((b)=>({...b,color:c,tool:b.tool==='eraser'?'pen':b.tool}))} disabled={checked} />)}
      <label className="small muted">{fa ? "ضخامت" : "Size"}<input type="range" min="2" max="14" value={brush.size} onChange={(e)=>setBrush((b)=>({...b,size:+e.target.value}))} disabled={checked}/></label>
      <button className="btn btn-ghost btn-sm" onClick={undo} disabled={checked || snapshots.length<=1}>{fa ? "برگشت" : "Undo"}</button>
      <button className="btn btn-ghost btn-sm" onClick={redo} disabled={checked || !redoStack.length}>{fa ? "بازگشت دوباره" : "Redo"}</button>
      <button className="btn btn-ghost btn-sm" onClick={clear} disabled={checked}>{fa ? "پاک کردن همه" : "Clear"}</button>
    </div>
    <canvas ref={canvasRef} className={`drawing-canvas ${brush.grid ? "grid" : ""}`} onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up} onPointerLeave={up} aria-label={fa ? "بوم نقاشی پاسخ" : "Drawing answer canvas"} />
    {rubric.length > 0 && <div className="drawing-rubric"><div className="small muted">{fa ? "پس از کشیدن، معیارهایی را که رعایت کرده‌اید علامت بزنید. نمره نهایی بعد از تأیید استاد ثبت می‌شود." : "Check the criteria you met. Final score is recorded after teacher approval."}</div>{rubric.map((r, i) => <label className="toggle-row" key={i}><span>{r}</span><input type="checkbox" checked={!!rubricDone[i]} disabled={checked} onChange={(e)=>setRubricDone((s)=>({...s,[i]:e.target.checked}))}/></label>)}</div>}
    {checked ? <div className="ddle-banner ok">✓ {fa ? "نقاشی ثبت شد و در انتظار تأیید استاد است" : "Drawing submitted and pending teacher approval"}</div> : <button className="btn btn-primary btn-block mt16" disabled={strokeCount===0} onClick={finish}>{fa ? "ثبت نقاشی برای بررسی استاد" : "Submit for teacher review"}</button>}
  </div>;
}

function StepwiseQuestion({ card, lang, showCorrect, checked, setChecked, onGraded, hints, showHints }) {
  const { t } = useApp();
  const fa = lang === "fa";
  const steps = card.steps || [];
  const [answers, setAnswers] = useState({});
  const [stepResults, setStepResults] = useState(null);
  const renderInput = (s, i) => {
    const type = s.answerType || s.type || "autocomplete";
    if (type === "truefalse") return <div className="mc-options compact"><button className={`mc-opt ${answers[i] === "true" ? "sel" : ""}`} disabled={checked} onClick={() => setAnswers((a)=>({...a,[i]:"true"}))}>{fa ? "درست" : "True"}</button><button className={`mc-opt ${answers[i] === "false" ? "sel" : ""}`} disabled={checked} onClick={() => setAnswers((a)=>({...a,[i]:"false"}))}>{fa ? "نادرست" : "False"}</button></div>;
    const opts = fa ? (s.options_fa || []) : (s.options_en || []);
    if (type === "mcq" && opts.length) return <div className="mc-options compact">{opts.map((o, j) => <button key={j} className={`mc-opt ${answers[i] === o ? "sel" : ""}`} disabled={checked} onClick={() => setAnswers((a)=>({...a,[i]:o}))}>{o}</button>)}</div>;
    return <textarea rows="2" value={answers[i] || ""} disabled={checked} onChange={(e)=>setAnswers((a)=>({...a,[i]:e.target.value}))} placeholder={fa ? "پاسخ این مرحله…" : "Answer this step…"}/>;
  };
  const canCheck = steps.length && steps.every((_, i) => String(answers[i] || "").trim());
  const finish = () => {
    const res = steps.map((s, i) => {
      const accepted = arr(fa ? (s.accept_fa || s.answer_fa) : (s.accept_en || s.answer_en));
      const correct = accepted.length ? accepted.some((a) => norm(a) === norm(answers[i])) : !!String(answers[i] || "").trim();
      return { index: i + 1, prompt: stepLabel(s, "prompt", fa), answer: answers[i] || "", correct, expected: accepted[0] || "", answerType: s.answerType || s.type || "autocomplete" };
    });
    const okCount = res.filter((x) => x.correct).length;
    const pointsFrac = steps.length ? okCount / steps.length : 0;
    setStepResults(res); setChecked(true); onGraded(okCount === steps.length, { stepResults: res, pointsFrac });
  };
  return <div className="stepwise-q">
    <LocalHints hints={hints} showHints={showHints && !checked} fa={fa} />
    {steps.length === 0 ? <div className="ddle-banner bad">{fa ? "برای این سؤال مرحله‌ای هنوز مرحله‌ای ثبت نشده است." : "No steps are configured for this stepwise question."}</div> : steps.map((s, i) => {
      const res = stepResults?.[i];
      return <div key={i} className={`step-card ${res ? (res.correct ? 'ok' : 'bad') : ''}`}><div className="step-no">{fa ? `مرحله ${i+1}` : `Step ${i+1}`} · {(s.answerType || s.type || "autocomplete")}</div><div className="step-prompt">{stepLabel(s, "prompt", fa)}</div>{stepLabel(s, "hint", fa) && !checked && <div className="small muted">💡 {stepLabel(s, "hint", fa)}</div>}{renderInput(s, i)}{checked && showCorrect && !res?.correct && <div className="small" style={{color:'var(--danger)'}}>{fa ? "پاسخ مورد انتظار:" : "Expected:"} {res?.expected}</div>}{checked && stepLabel(s, "explanation", fa) && <div className="small muted">{stepLabel(s, "explanation", fa)}</div>}</div>;
    })}
    {checked && <div className={`ddle-banner ${stepResults?.every((x)=>x.correct)?'ok':'bad'}`} style={{marginTop:12}}>{stepResults?.filter((x)=>x.correct).length || 0}/{steps.length} {fa ? "مرحله درست" : "steps correct"}</div>}
    {!checked && <button className="btn btn-primary btn-block mt16" disabled={!canCheck} onClick={finish}>{t("checkAns") || t("send")}</button>}
  </div>;
}
