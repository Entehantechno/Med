import { useState, useRef, useEffect, useMemo } from "react";
import { useApp } from "../context.jsx";
import Icon from "./Icon.jsx";

/* Smart search box for ordering lab tests / imaging studies.
   - Filters a bilingual catalog with fuzzy matching.
   - Click a suggestion (or press Enter) to add it to the ordered list.
   - Also allows a free-text custom order (Enter with no exact match). */
function norm(s) {
  return (s || "").toString().toLowerCase()
    .replace(/[ي]/g, "ی").replace(/[ك]/g, "ک")
    .replace(/[ًٌٍَُِّْ]/g, "").replace(/\s+/g, " ").trim();
}

export default function OrderSearch({ catalog, lang, onAdd, placeholder }) {
  const { t } = useApp();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [hi, setHi] = useState(0);
  const boxRef = useRef(null);

  const items = useMemo(() => catalog.map((o) => ({
    label: lang === "fa" ? o.fa : o.en, sub: lang === "fa" ? o.en : o.fa,
  })), [catalog, lang]);

  const results = useMemo(() => {
    const nq = norm(q);
    if (!nq) return items.slice(0, 40);
    return items
      .map((it) => {
        const a = norm(it.label), b = norm(it.sub);
        let score = -1;
        if (a === nq || b === nq) score = 100;
        else if (a.startsWith(nq) || b.startsWith(nq)) score = 80;
        else if (a.includes(nq) || b.includes(nq)) score = 60;
        else {
          const sub = (hay) => { let j = 0; for (const ch of hay) if (ch === nq[j]) j++; return j === nq.length; };
          if (sub(a) || sub(b)) score = 30;
        }
        return { ...it, score };
      })
      .filter((x) => x.score >= 0)
      .sort((x, y) => y.score - x.score);
  }, [q, items]);

  useEffect(() => { setHi(0); }, [q]);
  useEffect(() => {
    const onDoc = (e) => { if (boxRef.current && !boxRef.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  const commit = (label) => {
    const v = (label ?? q).trim();
    if (!v) return;
    onAdd(v);
    setQ(""); setOpen(false);
  };

  const onKey = (e) => {
    if (e.key === "ArrowDown") { e.preventDefault(); setOpen(true); setHi((h) => Math.min(h + 1, results.length - 1)); }
    else if (e.key === "ArrowUp") { e.preventDefault(); setHi((h) => Math.max(h - 1, 0)); }
    else if (e.key === "Enter") { e.preventDefault(); commit(results[hi]?.label); }
    else if (e.key === "Escape") setOpen(false);
  };

  const highlight = (label) => {
    const nq = norm(q); if (!nq) return label;
    const idx = norm(label).indexOf(nq);
    if (idx < 0) return label;
    return (<>{label.slice(0, idx)}<mark style={{ background: "rgba(47,127,209,.18)", color: "inherit", borderRadius: 4 }}>{label.slice(idx, idx + q.length)}</mark>{label.slice(idx + q.length)}</>);
  };

  return (
    <div className="search-answer" ref={boxRef}>
      <div className="search-input-wrap">
        <span className="search-ico"><Icon name="search" size={16} /></span>
        <input value={q} onChange={(e) => { setQ(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)} onKeyDown={onKey}
          placeholder={placeholder || t("searchOrderPh")} autoComplete="off" />
        <button className="btn btn-green btn-sm" style={{ margin: "5px" }} onClick={() => commit()}>{t("add")}</button>
      </div>
      {open && (
        <div className="search-list">
          {results.length ? results.map((it, k) => (
            <button key={k} type="button" className={`search-opt ${k === hi ? "hi" : ""}`}
              onMouseEnter={() => setHi(k)} onClick={() => commit(it.label)}>
              <span className="opt-main">{highlight(it.label)}</span>
              {it.sub && <span className="opt-sub">{it.sub}</span>}
            </button>
          )) : <div className="search-empty">{t("noMatch")} — <b onClick={() => commit()} style={{ cursor: "pointer", color: "var(--primary)" }}>{t("addCustom")}</b></div>}
        </div>
      )}
    </div>
  );
}
