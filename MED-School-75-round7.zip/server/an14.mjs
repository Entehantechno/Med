process.env.DATA_DIR="/home/user/Med/.work/data";
const { db, initDb } = await import("./src/db.js"); await initDb();
const { allSyllabi } = await import("./src/data/path-syllabus.js");
const { classifyCard } = await import("./src/lib/pathcurator.js");
const cnt={}; for(const r of db.prepare("SELECT id,data_json FROM flashcards WHERE active=1").all()){let d;try{d=JSON.parse(r.data_json)}catch{continue}; if(d.track!=="learn"||d.source_meta?.kind!=="past_exam_import")continue; const s=(await import("./src/data/path-syllabus.js")).syllabusFor(d.topic); if(!s)continue; const ch=classifyCard({id:r.id,d},s); if(ch)(cnt[d.topic]??={})[ch.slug]=((cnt[d.topic]??={})[ch.slug]||0)+1;}
const syl=allSyllabi();
const topics=db.prepare("SELECT id,slug,name_fa FROM topics WHERE program='preint' AND active=1 ORDER BY ord").all();
let tf=0,tp=0,tn=0,tpn=0; const lines=[];
for(const t of topics){ const nodes=db.prepare("SELECT title_fa,premium,card_ids FROM path_nodes WHERE topic_id=? AND active=1 ORDER BY ord,id").all(t.id);
 if(!nodes.length) continue;
 let f=0,p=0,pn=0; const chapters=new Set();
 for(const n of nodes){const c=JSON.parse(n.card_ids).length; if(n.premium){p+=c;pn++}else f+=c; chapters.add(n.title_fa.replace(/ — تمرین بیشتر 👑| \(.*?\)| \(بخش \d+\)/g,''));}
 const s=syl[t.slug]||[]; const missing=s.filter(ch=>!chapters.has(ch.fa)&&!(cnt[t.slug]?.[ch.slug])).map(ch=>ch.fa);
 const few=s.filter(ch=>!chapters.has(ch.fa)&&(cnt[t.slug]?.[ch.slug])).map(ch=>`${ch.fa} (${cnt[t.slug][ch.slug]})`);
 tf+=f;tp+=p;tn+=nodes.length;tpn+=pn;
 lines.push(`| ${t.name_fa} | ${nodes.length-pn} | ${pn} | ${f} | ${p} | ${missing.length? missing.join('، '):'—'} | ${few.length? few.join('، '):'—'} |`);
}
console.log(`| درس | گره رایگان | گره پلاس | سؤال رایگان | سؤال پلاس | فصل‌های بدون سؤال | فصل‌های کم‌سؤال (در «مرور جامع») |\n|---|---|---|---|---|---|---|`);
console.log(lines.join('\n'));
console.log(`\nجمع: گره ${tn} (رایگان ${tn-tpn}، پلاس ${tpn}) — سؤال رایگان ${tf}، سؤال پلاس ${tp}`);
