/* ================================================================
   master-bank.test.js — guards for the authoritative competitive
   question bank that ships in tools/master-bank.

   The bank is the bilingual pre-internship collection plus the
   residency (دستیاری) collection taken from the official medschool
   archive, split by tools/master-bank/build.mjs into numbered import
   payload parts. These tests lock the structural and editorial
   invariants the importer, curator and exam simulator rely on:

     1. part files exist, are numbered contiguously and match the
        bankbootstrap filename family;
     2. every question has a Persian stem, four Persian options and a
        valid single key — or is explicitly marked keyless (no official
        key / multi-answer item), in which case it never enters a graded
        surface;
     3. subjects/chapters/years cover the full competitive syllabus;
     4. residency classification is stable (the distribution is the
        audited anchor set);
     5. no stem is duplicated within a bank.
   ================================================================ */
import { describe, it, expect } from "vitest";
import { readFileSync, readdirSync, existsSync } from "fs";
import { dirname, join } from "path";
import { fileURLToPath } from "url";

const here = dirname(fileURLToPath(import.meta.url));
const bank = join(here, "../../tools/master-bank");

/* Same family grammar as bankbootstrap.js payloadFiles(). */
const PART_RE = /^import-payload\.(master-preint|master-residency)\.part(\d+)\.json$/;

function loadFamily(family) {
  const files = readdirSync(bank)
    .filter((n) => PART_RE.test(n))
    .sort();
  const parts = [];
  for (const n of files) {
    const m = n.match(PART_RE);
    if (m[1] !== family) continue;
    const body = JSON.parse(readFileSync(join(bank, n), "utf8"));
    parts.push({ name: n, index: Number(m[2]), body });
  }
  return parts.sort((a, b) => a.index - b.index);
}

describe("master bank payload structure", () => {
  it("ships contiguous numbered parts for both exam families", () => {
    for (const [family, expectedParts] of [["master-preint", 51], ["master-residency", 3]]) {
      const parts = loadFamily(family);
      expect(parts.map((p) => p.index)).toEqual(Array.from({ length: expectedParts }, (_, i) => i + 1));
      for (const p of parts) expect(Array.isArray(p.body.questions)).toBe(true);
    }
  });

  it("keeps every part at or below the 220-question split (last part carries the remainder)", () => {
    for (const family of ["master-preint", "master-residency"]) {
      const parts = loadFamily(family);
      for (const p of parts.slice(0, -1)) expect(p.body.questions.length).toBe(220);
      expect(parts.at(-1).body.questions.length).toBeGreaterThan(0);
      expect(parts.at(-1).body.questions.length).toBeLessThanOrEqual(220);
    }
  });

  it("declares the competitive program, exam type and overflow-to-premium on every part", () => {
    const pre = loadFamily("master-preint");
    for (const p of pre) {
      expect(p.body.program).toBe("preint");
      expect(p.body.exam_type).toBe("preinternship");
      expect(p.body.overflowToPremium).toBe(true);
      expect(p.body.maxPerLesson).toBeGreaterThan(0);
      expect(p.body.part.n).toBe(p.index);
    }
    const res = loadFamily("master-residency");
    for (const p of res) {
      // both competitive banks run under the app's "preint" program; the
      // residency collection is distinguished by exam_type
      expect(p.body.program).toBe("preint");
      expect(p.body.exam_type).toBe("residency");
      expect(p.body.overflowToPremium).toBe(true);
      expect(p.body.part.n).toBe(p.index);
    }
  });
});

describe("master pre-internship bank", () => {
  const parts = loadFamily("master-preint");
  const rows = parts.flatMap((p) => p.body.questions);

  it("contains 11,120 audited questions (11,091 keyed + 29 explicitly keyless)", () => {
    expect(rows).toHaveLength(11120);
    const keyless = rows.filter((r) => r.keyless === true || r.correct_index === null);
    expect(keyless).toHaveLength(29);
    const lowConf = keyless.filter((r) => r.key_source === "low-confidence");
    expect(lowConf.map((r) => r.tags[0]).sort()).toEqual(
      ["QB-00584", "QB-00707", "QB-01104", "QB-01248"].sort()
    );
    const multi = keyless.filter((r) => r.key_source === "multi-answer");
    expect(multi).toHaveLength(25);
    for (const r of multi) expect(r.tags).toContain("multi-answer");
    expect(rows.filter((r) => !r.keyless).length).toBe(11091);
  });

  it("gives every card a Persian stem, four options and a usable key", () => {
    for (const r of rows) {
      expect((r.question_fa || "").trim().length).toBeGreaterThan(12);
      expect(Array.isArray(r.options_fa)).toBe(true);
      expect(r.options_fa).toHaveLength(4);
      expect(r.options_fa.every((o) => String(o || "").trim().length > 0)).toBe(true);
      if (r.keyless === true) {
        expect(r.correct_index === null).toBe(true);
      } else {
        expect(Number.isInteger(r.correct_index)).toBe(true);
        expect(r.correct_index).toBeGreaterThanOrEqual(0);
        expect(r.correct_index).toBeLessThanOrEqual(3);
        expect(["official", "rapid", "registry-corrected"]).toContain(r.key_source);
      }
    }
  });

  it("attaches four option rationales and a lesson to every keyed card", () => {
    for (const r of rows.filter((x) => !x.keyless)) {
      expect(Array.isArray(r.options_why_fa)).toBe(true);
      expect(r.options_why_fa).toHaveLength(4);
      expect((r.explanation_fa || "").trim().length).toBeGreaterThan(40);
    }
  });

  it("has no duplicated stems and no duplicated question tags", () => {
    const stems = new Set();
    const tags = new Set();
    for (const r of rows) {
      expect(stems.has(r.question_fa)).toBe(false);
      stems.add(r.question_fa);
      const id = (r.tags || [])[0];
      expect(id).toBeTruthy();
      expect(tags.has(id)).toBe(false);
      tags.add(id);
    }
  });

  it("covers every competitive exam year 1393–1400 and 1402–1403", () => {
    const byYear = {};
    for (const r of rows) byYear[r.year_num] = (byYear[r.year_num] || 0) + 1;
    for (const y of [1393, 1394, 1395, 1396, 1397, 1398, 1399, 1400, 1402, 1403]) {
      expect(byYear[y]).toBeGreaterThan(100);
    }
  });

  it("labels every question with a subject (chapter when the booklet gives one)", () => {
    for (const r of rows) {
      expect((r.subject_fa || "").trim()).toBeTruthy();
      expect(["major", "minor"]).toContain(r.subject_track);
    }
    // chapters are populated wherever the booklet grouped questions by them;
    // the newer 1402/1403 sittings were not chapter-headed in the source
    expect(rows.filter((r) => (r.chapter_fa || "").trim()).length).toBeGreaterThan(3000);
  });
});

describe("master residency (دستیاری) bank", () => {
  const parts = loadFamily("master-residency");
  const rows = parts.flatMap((p) => p.body.questions);

  it("contains 484 questions, all keyed, in 220/220/44 parts", () => {
    expect(parts.map((p) => p.body.questions.length)).toEqual([220, 220, 44]);
    expect(rows).toHaveLength(484);
    expect(rows.every((r) => r.keyless !== true && Number.isInteger(r.correct_index))).toBe(true);
    for (const r of rows) {
      expect(r.key_source).toBe("official");
      expect(r.options_fa).toHaveLength(4);
      expect(Array.isArray(r.options_why_fa) && r.options_why_fa).toHaveLength(4);
    }
  });

  it("holds the audited subject distribution (classification anchors)", () => {
    const counts = {};
    for (const r of rows) counts[r.subject_fa] = (counts[r.subject_fa] || 0) + 1;
    expect(counts).toEqual({
      "داخلی": 114,
      "جراحی": 49,
      "اورولوژی": 22,
      "کودکان": 76,
      "نورولوژی": 20,
      "زنان و زایمان": 50,
      "بیماری‌های عفونی": 30,
      "رادیولوژی": 8,
      "پاتولوژی": 14,
      "روانپزشکی": 16,
      "پوست": 14,
      "ارتوپدی": 14,
      "چشم‌پزشکی": 12,
      "گوش و حلق و بینی": 12,
      "آمار و اپیدمیولوژی": 14,
      "فارماکولوژی": 13,
      "اخلاق پزشکی": 5,
      "ایمنی‌شناسی": 1,
    });
  });

  it("covers all three audited residency courses (51, 52, 53)", () => {
    const tags = rows.flatMap((r) => r.tags || []);
    expect(tags.filter((t) => t === "residency-course-۵۱").length).toBe(158);
    expect(tags.filter((t) => t === "residency-course-۵۲").length).toBe(126);
    expect(tags.filter((t) => t === "residency-course-۵۳").length).toBe(200);
  });
});

describe("master bank sources", () => {
  it("keeps the raw extraction sources out of the payload directory listing contract", () => {
    // sources/ is a build input (~100 MB) and must never be treated as a payload
    expect(existsSync(join(bank, "build.mjs"))).toBe(true);
    const stray = readdirSync(bank).filter(
      (n) => n.endsWith(".json") && !PART_RE.test(n)
    );
    expect(stray).toEqual([]);
  });
});
