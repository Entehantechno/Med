/* ================================================================
   pathcurator.test.js — two-tier competitive content:
   1. every subject gets clearly-titled, subtitled curated stages,
   2. every overflow question becomes premium bank content,
   3. premium users draw from the full bank in exam simulation,
      free users only from curated stages; browse gate is card-level.
   ================================================================ */
import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { execSync } from "child_process";
import request from "supertest";
import { initDb, db, persistNow } from "../src/db.js";
import { createApp } from "../src/app.js";
import { commitOfficialImport } from "../src/routes/admin.js";
import { curateOfficialPath } from "../src/lib/pathcurator.js";

let app;
async function token(u, p = "demo") {
  return (await request(app).post("/api/auth/login").send({ username: u, password: p })).body.token;
}
const A = (tk) => ({ Authorization: `Bearer ${tk}` });
const MARK = "زیکوریتور";

function q(i, { subject, subjectEn, chapter, chapterEn, examType, year }) {
  // NOTE: the importer fingerprint collapses digit runs, so the per-question
  // uniqueness must come from a letter token, not the question number.
  const token = "گ".repeat(i + 1);
  return {
    question_no: i,
    question_fa: `سؤال آزمایشی ${MARK} با نشانهٔ یکتای ${token} دربارهٔ ${chapter}؟`,
    question_en: `Curator test question unique token ${"z".repeat(i + 1)} about ${chapterEn}`,
    options_fa: ["الف", "ب", "ج", "د"],
    options_en: ["a", "b", "c", "d"],
    correct_index: i % 4,
    options_why_fa: ["درست/غلط", "درست/غلط", "درست/غلط", "درست/غلط"],
    explanation_fa: `توضیح کامل درسنامه‌ای سؤال ${i} برای پوشش مسیر.`,
    explanation_en: `Full rationale for question ${i}.`,
    subject_fa: subject, subject_en: subjectEn,
    chapter_fa: chapter, chapter_en: chapterEn || chapter,
    year, month: "خرداد", sitting: "main", exam_type: examType,
  };
}

beforeAll(async () => {
  execSync("node src/seed.js --force", { cwd: process.cwd(), stdio: "ignore" });
  await initDb();
  app = createApp();

  const questions = [];
  let n = 0;
  // 25 neurology questions for ONE chapter → curated stage (10) + premium (15)
  for (let i = 0; i < 25; i++) questions.push(q(++n, {
    subject: "نورولوژی", subjectEn: "Neurology", chapter: `سردرد ${MARK}`,
    chapterEn: "Headache test", examType: i % 2 ? "preinternship" : "پره‌انترنی", year: "۱۴۰۳",
  }));
  // internal-medicine questions routed by chapter prefix to seeded sub-topics
  const internals = [
    ["خون / ITP", "Heme / ITP", "heme"],
    ["ریه / آسم", "Lung / asthma", "pulmo"],
    ["قلب / STEMI", "Heart / STEMI", "cardio"],
  ];
  for (const [chapter, chapterEn] of internals) {
    for (let i = 0; i < 4; i++) questions.push(q(++n, {
      subject: "داخلی", subjectEn: "Internal Medicine", chapter: `${chapter} ${MARK}`,
      chapterEn: `${chapterEn} test`, examType: "preinternship", year: "۱۴۰۲",
    }));
  }
  // a brand-new subject with only 3 questions → still gets a covered stage
  for (let i = 0; i < 3; i++) questions.push(q(++n, {
    subject: `درس نو ${MARK}`, subjectEn: "Curator New Subject", chapter: `فصل نو ${MARK}`,
    chapterEn: "New chapter", examType: "پره‌انترنی", year: "۱۴۰۱",
  }));

  const res = commitOfficialImport({ program: "preint", maxPerLesson: 15, questions }, null);
  expect(res.inserted).toBe(questions.length);
  global.__curatorInserted = res.inserted;
});

afterAll(() => {
  // remove every test card, then the test stages and the synthetic topic
  const ids = [];
  for (const c of db.prepare("SELECT id, data_json FROM flashcards").all()) {
    let d; try { d = JSON.parse(c.data_json); } catch { continue; }
    if (JSON.stringify(d).includes(MARK)) ids.push(c.id);
  }
  const tx = db.transaction(() => {
    for (const n of db.prepare("SELECT id, card_ids FROM path_nodes").all()) {
      let list = []; try { list = JSON.parse(n.card_ids || "[]"); } catch { /* */ }
      const kept = list.filter((id) => !ids.includes(id));
      if (kept.length !== list.length) {
        db.prepare("UPDATE path_nodes SET card_ids=? WHERE id=?").run(JSON.stringify(kept), n.id);
      }
      const title = String(db.prepare("SELECT title_fa FROM path_nodes WHERE id=?").get(n.id)?.title_fa || "");
      if ((kept.length === 0 && title.includes(MARK)) || title.includes(MARK)) {
        db.prepare("DELETE FROM path_nodes WHERE id=?").run(n.id);
      }
    }
    const t = db.prepare("SELECT id FROM topics WHERE name_fa LIKE ?").get(`%${MARK}%`);
    if (t) db.prepare("DELETE FROM topics WHERE id=?").run(t.id);
    for (const id of ids) {
      db.prepare("DELETE FROM flashcards WHERE id=?").run(id);
      db.prepare("DELETE FROM card_revisions WHERE card_id=?").run(id);
    }
    // do not leak premium state into later test files (shared SQLite)
    const learner = db.prepare("SELECT id FROM users WHERE username='learner'").get();
    if (learner) db.prepare("UPDATE learner_profiles SET premium=0, premium_until=NULL WHERE user_id=?").run(learner.id);
  });
  tx();
  persistNow();
});

describe("path curator: titled free stages + premium bank", () => {
  it("keeps ~one stage per chapter with explicit title+subtitle and pushes the rest to the premium bank", () => {
    const out = curateOfficialPath({ force: true });
    expect(out.ok).toBe(true);
    expect(out.topicsCovered).toBeGreaterThanOrEqual(4); // neuro + 3 internal + new subject

    const neuro = db.prepare("SELECT id FROM topics WHERE slug='neuro' AND program='preint'").get();
    const stage = db.prepare("SELECT * FROM path_nodes WHERE topic_id=? AND title_fa LIKE ?").get(neuro.id, `%سردرد ${MARK}%`);
    expect(stage).toBeTruthy();
    expect(stage.curated).toBe(1);
    expect(stage.active).toBe(1);
    const stageIds = JSON.parse(stage.card_ids);
    expect(stageIds.length).toBe(12); // 10 curated + subject floor tops up to 12
    expect(stage.subtitle_fa).toContain("۱۴۰۳"); // exam-year span explicit
    expect(stage.subtitle_en).toBeTruthy();

    // the other 15 neurology questions are premium bank content
    const rows = db.prepare("SELECT data_json FROM flashcards").all();
    let pathN = 0, bankN = 0;
    for (const r of rows) {
      let d; try { d = JSON.parse(r.data_json); } catch { continue; }
      if ((d.q_fa || "").includes(`سردرد ${MARK}`)) {
        if (d.premium) bankN++; else pathN++;
        expect(d.source_meta.exam_type).toBe("پره‌انترنی"); // canonical vocabulary
      }
    }
    expect(pathN).toBe(12);
    expect(bankN).toBe(13);
  });

  it("routes internal-medicine chapters to the seven seeded sub-topics (no parallel umbrella topic)", () => {
    for (const [slug, prefix] of [["heme", "خون"], ["pulmo", "ریه"], ["cardio", "قلب"]]) {
      const topic = db.prepare("SELECT id FROM topics WHERE slug=? AND program='preint'").get(slug);
      // every test card of that chapter resolved to the seeded sub-topic
      const cardRows = db.prepare("SELECT data_json FROM flashcards").all().filter((r) => {
        let d; try { d = JSON.parse(r.data_json); } catch { return false; }
        return (d.source_meta?.chapter_fa || "").startsWith(prefix) && (d.q_fa || "").includes(MARK);
      });
      expect(cardRows.length).toBe(4);
      cardRows.forEach((r) => expect(JSON.parse(r.data_json).topic).toBe(slug));
      // and the sub-topic has a live curated stage mentioning that section
      const nodes = db.prepare("SELECT title_fa, card_ids, curated FROM path_nodes WHERE topic_id=? AND active=1").all(topic.id);
      expect(nodes.some((n) => n.curated && n.title_fa.includes(prefix))).toBe(true);
    }
    const umbrella = db.prepare("SELECT id FROM topics WHERE slug='official-internal-medicine' AND active=1").get();
    expect(umbrella).toBeFalsy();
  });

  it("covers even a tiny brand-new subject with an explicit stage", () => {
    const t = db.prepare("SELECT id FROM topics WHERE name_fa LIKE ?").get(`%درس نو ${MARK}%`);
    expect(t).toBeTruthy();
    const n = db.prepare("SELECT * FROM path_nodes WHERE topic_id=? AND active=1").get(t.id);
    expect(n).toBeTruthy();
    expect(JSON.parse(n.card_ids).length).toBe(3);
    expect(n.title_fa).toBeTruthy();
  });

  it("is idempotent — a second run yields the same stages/cards without duplication", () => {
    const before = db.prepare("SELECT COUNT(*) n FROM path_nodes WHERE curated=1").get().n;
    const out = curateOfficialPath({ force: true });
    const after = db.prepare("SELECT COUNT(*) n FROM path_nodes WHERE curated=1").get().n;
    expect(after).toBe(before);
    expect(out.pathCards + out.premiumCards).toBeGreaterThan(0);
  });
});

describe("learner-facing rules over the curated bank", () => {
  it("the path payload exposes each stage subtitle", async () => {
    const ltk = await token("learner");
    const d = (await request(app).get("/api/learn/path").set(A(ltk))).body;
    const neuro = d.topics.find((t) => t.slug === "neuro");
    const stage = neuro.nodes.find((n) => n.title.includes(`سردرد ${MARK}`));
    expect(stage.subtitle).toBeTruthy();
  });

  it("free learners: browse shows path cards but not the premium bank beyond 3 teasers; detail gate matches the list", async () => {
    const ltk = await token("learner");
    const list = (await request(app).get(`/api/learn/browse?chapter=${encodeURIComponent("سردرد زیکوریتور")}`).set(A(ltk))).body;
    expect(list.premiumRequired).toBe(true);
    const shownIds = list.cards.map((c) => c.id);
    const premiumShown = list.cards.filter((c) => c.premium);
    expect(premiumShown.length).toBeLessThanOrEqual(3);
    // the 10 free curated cards are all open
    const freeOpen = await Promise.all(shownIds.filter((id) => !list.cards.find((c) => c.id === id).premium)
      .map((id) => request(app).get(`/api/learn/browse/${id}`).set(A(ltk))));
    freeOpen.forEach((r) => expect(r.status).toBe(200));
    // a premium card that is NOT among the teasers is 402
    const rows = db.prepare("SELECT id, data_json FROM flashcards").all();
    const premiumIds = rows.filter((r) => {
      let d; try { d = JSON.parse(r.data_json); } catch { return false; }
      return d.premium && (d.q_fa || "").includes("سردرد");
    }).map((r) => r.id);
    const teaserIds = new Set(premiumShown.map((c) => c.id));
    const locked = premiumIds.find((id) => !teaserIds.has(id));
    expect(locked).toBeTruthy();
    const denied = await request(app).get(`/api/learn/browse/${locked}`).set(A(ltk));
    expect(denied.status).toBe(402);
    // premium library stays closed to free users
    const lib = await request(app).get("/api/learn/library").set(A(ltk));
    expect(lib.status).toBe(402);
  });

  it("free exam simulation never draws a premium bank card", async () => {
    const ltk = await token("learner");
    const seen = new Set();
    for (let i = 0; i < 4; i++) {
      const r = await request(app).post("/api/learn/exam-sim/start").set(A(ltk)).send({ n: 40, topics: ["neuro"] });
      expect(r.status).toBe(200);
      r.body.cards.forEach((c) => seen.add(c.id));
    }
    const premium = new Set();
    for (const r of db.prepare("SELECT id, data_json FROM flashcards").all()) {
      let d; try { d = JSON.parse(r.data_json); } catch { continue; }
      if (d.premium) premium.add(r.id);
    }
    expect([...seen].filter((id) => premium.has(id)).length).toBe(0);
  });

  it("premium exam simulation and library cover the full bank", async () => {
    const learner = db.prepare("SELECT id FROM users WHERE username='learner'").get();
    db.prepare("UPDATE learner_profiles SET premium=1, premium_until='2030-01-01' WHERE user_id=?").run(learner.id);
    persistNow();
    const ltk = await token("learner");
    const lib = await request(app).get("/api/learn/library").set(A(ltk));
    expect(lib.status).toBe(200);
    const neuroGroup = lib.body.categories.find((c) => c.name.includes("نورولوژی"));
    expect(neuroGroup).toBeTruthy();
    expect(neuroGroup.count).toBeGreaterThanOrEqual(13);
    // across several draws, premium bank cards appear in a topic-scoped sim
    const seen = new Set();
    for (let i = 0; i < 6; i++) {
      const r = await request(app).post("/api/learn/exam-sim/start").set(A(ltk)).send({ n: 60, topics: ["neuro"] });
      r.body.cards.forEach((c) => seen.add(c.id));
    }
    const premium = new Set();
    for (const r of db.prepare("SELECT id, data_json FROM flashcards").all()) {
      let d; try { d = JSON.parse(r.data_json); } catch { continue; }
      if (d.premium && d.topic === "neuro") premium.add(r.id);
    }
    expect([...seen].filter((id) => premium.has(id)).length).toBeGreaterThan(0);
  });

  it("admin can re-trigger curation over HTTP", async () => {
    const atk = await token("admin");
    const r = await request(app).post("/api/admin/learn-path/curate").set(A(atk));
    expect(r.status).toBe(200);
    expect(r.body.ok).toBe(true);
  });
});
