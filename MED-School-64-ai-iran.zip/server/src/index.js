/* ================================================================
   index.js — Server launcher
   ================================================================ */
import "./load-env.js";
import { initDb, reloadDb, initSchema, db } from "./db.js";
import { createApp } from "./app.js";
import { runStreakReminders } from "./lib/notify.js";
import { execSync } from "child_process";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 4000;

async function main() {
  await initDb();                 // load the WASM SQLite engine first
  initSchema();                   // ensure all tables exist before we query them

  // FIRST-RUN ONLY seeding: if the database has no users, load the demo/content
  // seed once. On every later start (even after code changes) the existing data
  // is preserved — user accounts, exams, flashcards, attempts, everything stays.
  const existing = db.prepare("SELECT COUNT(*) n FROM users").get()?.n ?? 0;
  if (existing === 0) {
    console.log("🌱 First run — seeding initial content (this happens only once)…");
    try {
      execSync("node " + path.join(__dirname, "seed.js"), { stdio: "inherit", env: process.env });
      await reloadDb();           // force-reload the freshly-written database file
      initSchema();               // run any migrations on the reloaded DB
    } catch (e) {
      console.error("Seed failed:", e.message);
    }
  } else {
    console.log(`✓ Existing database detected (${existing} users) — data preserved, no seeding.`);
  }

  try { const { ensureDefaultEducationPosts } = await import("./lib/blog.js"); const n = ensureDefaultEducationPosts(); if (n) console.log(`📝 ensured ${n} default education blog post change(s)`); } catch (e) { console.warn("default blog posts skipped", e?.message || e); }

  // Load the past-exam question banks that ship with the release. This is
  // idempotent — questions already present are skipped by fingerprint — so it
  // is safe on every restart, and it means a fresh deployment comes up with a
  // populated learning path instead of an empty one.
  try {
    const { ensureQuestionBanks } = await import("./lib/bankbootstrap.js");
    const r = await ensureQuestionBanks();
    if (r && r.inserted) {
      const who = r.subjects.length ? ` (${r.subjects.join("، ")})` : "";
      console.log(`📚 imported ${r.inserted} official exam question(s)${who}; bank now ${r.after} cards`);
    } else if (r && r.after) {
      console.log(`📚 question bank ready — ${r.after} cards already present`);
    } else if (r && r.failed) {
      console.warn(`📚 question bank import had ${r.failed} problem file(s)`);
    }
    if (r?.curation && !r.curation.skipped && !r.curation.empty) {
      const c = r.curation;
      console.log(`🛣️  curated competitive path: ${c.topicsCovered} subjects, ${c.stages} titled stages, ${c.pathCards} free-path questions, ${c.premiumCards} premium-bank questions`);
    }
  } catch (e) {
    console.warn("question bank import skipped:", e?.message || e);
  }

  try {
    const { getSetting } = await import("./routes/content.js");
    const { resolveAiConfig } = await import("./lib/ai-engine.js");
    const ai = resolveAiConfig(getSetting("ai", {}));
    if (ai.apiKey) {
      console.log(`✓ Virtual-patient AI path ready (${ai.provider || "custom"} / ${ai.model || "default"})`);
    } else {
      console.log("✓ Virtual-patient AI path ready — mock until an API key is saved in Admin → AI");
    }
  } catch (e) {
    console.warn("AI path check skipped:", e?.message || e);
  }

  const app = createApp();
  const server = app.listen(PORT, () => console.log(`🎓 MED School API running on http://localhost:${PORT}`));
  // Slowloris / hung-connection protection (must satisfy headersTimeout > requestTimeout).
  server.requestTimeout = 60_000;   // 60s to send the full request
  server.headersTimeout = 65_000;   // a bit longer for headers
  server.keepAliveTimeout = 30_000; // close idle keep-alive sockets

  // Streak-reminder scheduler: check hourly for learners who risk losing a streak.
  const tick = async () => {
    try { const n = await runStreakReminders(); if (n) console.log(`🔔 sent ${n} streak reminders`); } catch (e) { /* */ }
    // Admin analytics scheduler: daily health-alert notifications + weekly digest
    // (self-gated by per-day/per-week de-dup tags, so it's safe to call hourly).
    try { const { runAdminAnalyticsScheduler } = await import("./lib/analytics-notify.js"); const m = await runAdminAnalyticsScheduler(); if (m) console.log(`📊 sent ${m} admin analytics notifications`); } catch (e) { /* */ }
  };
  setTimeout(tick, 15000);                 // once shortly after boot
  setInterval(tick, 60 * 60 * 1000);       // then hourly
}

main().catch((e) => { console.error("Startup failed:", e); process.exit(1); });
