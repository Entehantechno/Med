#!/usr/bin/env node
/* ================================================================
 * build.mjs — turn the authoritative ministry master booklets (Markdown)
 * into sharded import payloads the server bootstraps itself with.
 *
 * SOURCE OF TRUTH
 * ---------------
 * The two bilingual master booklets shipped by the ministry team:
 *
 *   sources/بانک_کامل_دوزبانه_سوالات_و_درسنامه_پره_انترنی.md   (pre-internship)
 *   sources/بانک_تجمعی_کامل_دوزبانه_دستیاری_نسخه_جاری.md      (residency)
 *
 * They are deliberately NOT shipped inside the release zip (the preint file
 * alone is ~100 MB). Put them under tools/master-bank/sources yourself or
 * point MB_SOURCE_DIR at the folder containing them, then run:
 *
 *   node tools/master-bank/build.mjs
 *
 * OUTPUT
 * ------
 *   import-payload.master-preint.partNN.json
 *   import-payload.master-residency.partNN.json
 *
 * The `bankbootstrap` loader picks both families up automatically on the
 * next server start; the import is idempotent (fingerprint-based), and the
 * path curator reorganises everything afterwards.
 * ================================================================ */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const SOURCE_DIR = process.env.MB_SOURCE_DIR || path.join(__dirname, "sources");
const PART_SIZE = Number(process.env.MB_PART_SIZE || 220);

const PREINT_MD = process.env.MB_PREINT_MD
  || path.join(SOURCE_DIR, "بانک_کامل_دوزبانه_سوالات_و_درسنامه_پره_انترنی.md");
const RESIDENCY_MD = process.env.MB_RESIDENCY_MD
  || path.join(SOURCE_DIR, "بانک_تجمعی_کامل_دوزبانه_دستیاری_نسخه_جاری.md");

// ESM import of the shared parser (same code the admin tooling can use).
const parser = await import("../../server/src/lib/masterbank-md.js");
const { parsePreintMaster, parseResidencyMaster } = parser;

function readMd(file) {
  if (!fs.existsSync(file)) {
    console.error(`[master-bank] missing source file: ${file}`);
    process.exit(1);
  }
  return fs.readFileSync(file, "utf8");
}

/* Split one question list into numbered payload parts. Each part is a FULLY
 * formed import body so bankbootstrap can commit them independently; part
 * numbering only keeps lesson/chunk ordering stable across files. */
function writeParts({ family, questions, meta }) {
  // Remove any older payload files for this family before writing, so deleted
  // questions cannot linger in a stale, higher-numbered part.
  for (const name of fs.readdirSync(__dirname)) {
    if (name.startsWith(`import-payload.${family}.part`) && name.endsWith(".json")) {
      fs.rmSync(path.join(__dirname, name));
    }
  }
  const total = Math.max(1, Math.ceil(questions.length / PART_SIZE));
  const written = [];
  for (let i = 0; i < total; i++) {
    const slice = questions.slice(i * PART_SIZE, (i + 1) * PART_SIZE);
    const n = String(i + 1).padStart(2, "0");
    const body = {
      program: meta.program,
      exam_type: meta.exam_type,
      source: meta.source,
      license: "official_ministry_booklet",
      maxPerLesson: meta.maxPerLesson,
      overflowToPremium: true,
      duplicates: "skip",
      part: { family, n: i + 1, total, count: slice.length },
      questions: slice,
    };
    const file = path.join(__dirname, `import-payload.${family}.part${n}.json`);
    fs.writeFileSync(file, JSON.stringify(body));
    const kb = Math.round(fs.statSync(file).size / 1024);
    written.push({ file: path.basename(file), count: slice.length, kb });
  }
  return written;
}

function report(family, label, parsed, written) {
  const q = parsed.questions || [];
  const keyless = q.filter((x) => x.keyless === true).length;
  const withLesson = q.filter((x) =>
    (x.explanation_fa && x.explanation_fa.trim()) ||
    (Array.isArray(x.options_why_fa) && x.options_why_fa.some((w) => (w || "").trim())) ||
    (x.micro && ((x.micro.golden_fa || "").trim() || (x.micro.lead_fa || "").trim()))
  ).length;
  const withEn = q.filter((x) => x.question_en && x.question_en.trim()).length;
  console.log(`\n[${family}] ${label}`);
  console.log(`  questions      ${q.length}` + (parsed.stats ? ` (stats: ${JSON.stringify(parsed.stats)})` : ""));
  console.log(`  with lesson    ${withLesson}`);
  console.log(`  with EN stem   ${withEn}`);
  console.log(`  keyless        ${keyless}  (import as browse-only bank cards)`);
  for (const w of written) console.log(`  wrote ${w.file}  ${w.count} questions  (${w.kb} KB)`);
}

/* ---------------- pre-internship ---------------- */
console.log("[master-bank] parsing pre-internship master booklet…");
const preMd = readMd(PREINT_MD);
const pre = parsePreintMaster(preMd);
const preWritten = writeParts({
  family: "master-preint",
  questions: pre.questions,
  meta: {
    program: "preint",
    exam_type: "preinternship",
    source: "بانک کامل دوزبانه رسمی پیش‌کارورزی (نسخهٔ ۰۰۵)",
    maxPerLesson: 15,
  },
});
report("master-preint", "pre-internship", pre, preWritten);

/* ---------------- residency ---------------- */
console.log("[master-bank] parsing residency master booklet…");
const resMd = readMd(RESIDENCY_MD);
const res = parseResidencyMaster(resMd);
const resWritten = writeParts({
  family: "master-residency",
  questions: res.questions,
  meta: {
    program: "preint",
    exam_type: "residency",
    source: "بانک تجمعی دوزبانه دستیاری — دوره‌های ۴۹–۵۳",
    maxPerLesson: 12,
  },
});
report("master-residency", "residency", res, resWritten);

console.log("\n[master-bank] done.");
